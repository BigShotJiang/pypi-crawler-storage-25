# pycrome/renderer.py

from pycrome.parser import UINode
from pycrome.theme import (
    get_theme,
    apply_overrides,
    generate_css_variables,
    generate_runtime_theme_js,
    THEMES
)


class Renderer:
    def __init__(self, theme_name: str = "dark", window_attrs: dict = None):
        self.theme_name = theme_name
        base_theme = get_theme(theme_name)
        # Apply any colour overrides from Window attributes
        if window_attrs:
            self.theme = apply_overrides(base_theme, window_attrs)
        else:
            self.theme = base_theme

    def render(self, nodes: list[UINode]) -> str:
        body_html = ""
        for node in nodes:
            body_html += self._render_node(node)
        css = self._base_css()
        return self._html_shell(css, body_html)

    def _render_node(self, node: UINode) -> str:
        method = f"_render_{node.component.lower()}"
        if hasattr(self, method):
            return getattr(self, method)(node)
        return self._render_generic(node)

    def _render_window(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-window">{children_html}</div>'

    def _render_sidebar(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        width = node.attrs.get("width", 220)
        return (
            f'<div class="pc-sidebar" style="width:{width}px">'
            f'{children_html}'
            f'</div>'
        )

    def _render_navitem(self, node: UINode) -> str:
        label = node.attrs.get("label", "")
        icon = node.attrs.get("icon", "")
        route = node.attrs.get("route", "#")
        return (
            f'<div class="pc-navitem" onclick="pycromeNavigate(\'{route}\')">'
            f'<span class="pc-nav-icon">{self._icon(icon)}</span>'
            f'<span class="pc-nav-label">{label}</span>'
            f'</div>'
        )

    def _render_mainpanel(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-mainpanel">{children_html}</div>'

    def _render_screen(self, node: UINode) -> str:
        """Render a screen component that can be shown/hidden via navigation."""
        screen_id = node.attrs.get("id", "")
        is_default = node.attrs.get("default", "false").lower() == "true"
        default_class = "pc-screen-default" if is_default else ""
        
        children_html = "".join(self._render_node(c) for c in node.children)
        
        return f"""
        <div class="pc-screen {default_class}" id="screen-{screen_id}" data-route="{screen_id}">
            {children_html}
        </div>
        """

    def _render_header(self, node: UINode) -> str:
        title = node.attrs.get("title", "")
        subtitle = node.attrs.get("subtitle", "")
        sub_html = f'<p class="pc-header-sub">{subtitle}</p>' if subtitle else ""
        return (
            f'<div class="pc-header">'
            f'<h1 class="pc-header-title">{title}</h1>'
            f'{sub_html}'
            f'</div>'
        )

    def _render_button(self, node: UINode) -> str:
        label = node.attrs.get("label", "Button")
        style = node.attrs.get("style", "primary")
        onclick = node.attrs.get("onclick", "")
        icon = node.attrs.get("icon", "")
        button_type = node.attrs.get("type", "button")
        css_class = f"pc-btn pc-btn-{style}"

        # JS-native calls go through directly, Python backend calls go through pycromeCall
        js_native = (
            onclick.startswith("pycromeOpenModal") or
            onclick.startswith("pycromeCloseModal") or
            onclick.startswith("pycromeConfirm") or
            onclick.startswith("pycromePopulateModal") or
            onclick.startswith("pycromeDeleteStudent") or
            onclick.startswith("navigate(") or
            onclick.startswith("pycromeNavigate") or
            onclick == ""
        )

        if js_native:
            click_handler = onclick
        else:
            # Python backend call, use single quotes inside to avoid HTML attribute conflict
            fn = onclick.replace('"', "'")
            click_handler = f"pycromeCall('{fn}')"

        icon_html = self._icon(icon) if icon else ""

        return (
            f'<button class="{css_class}" onclick="{click_handler}" type="{button_type}">'
            f'{icon_html}'
            f'{f"<span>{label}</span>" if icon_html else label}'
            f'</button>'
        )

    def _render_table(self, node: UINode) -> str:
        table_id = node.attrs.get("id", "pc_table")
        source = node.attrs.get("source", "")
        sticky_first = node.attrs.get("sticky_first", "false").lower() == "true"
        resizable = node.attrs.get("resizable", "true").lower() == "true"
        selectable = node.attrs.get("selectable", "false").lower() == "true"
        on_row_click = node.attrs.get("on_row_click", "")
        paginate = node.attrs.get("paginate", "false").lower() == "true"
        page_size = int(node.attrs.get("page_size", "20"))

        columns = [c for c in node.children if c.component == "Column"]
        headers = "".join(
            f'<th data-field="{col.attrs.get("field", "")}">{col.attrs.get("label", col.attrs.get("field", ""))}</th>'
            for col in columns
        )
        col_fields = [col.attrs.get("field", "") for col in columns]
        fields_js = str(col_fields)
        
        table_class = "pc-table"
        if sticky_first:
            table_class += " sticky-first"
        if resizable:
            table_class += " resizable-columns"
        if selectable:
            table_class += " selectable-rows"

        # Build pagination HTML if enabled
        pagination_html = ""
        if paginate and source:
            pagination_html = f"""
            <div class="pc-pagination">
                <span class="pc-pagination-info" id="{table_id}_info">Loading...</span>
                <div class="pc-pagination-controls" id="{table_id}_pages"></div>
            </div>
            """

        # Build table script for non-paginated tables
        table_script = ""
        if not paginate:
            table_script = f"""
            <script>
            (function() {{
                const tableId = '{table_id}';
                const source = '{source}';
                const fields = {fields_js};
                const onRowClick = '{on_row_click}';
                
                async function loadTableData() {{
                    if (!source) return;
                    
                    // Check if pycromeCall is available
                    if (typeof window.pycromeCall !== 'function') {{
                        console.error('pycromeCall not available, retrying...');
                        setTimeout(loadTableData, 100);
                        return;
                    }}
                    
                    try {{
                        const data = await window.pycromeCall(source);
                        const tbody = document.getElementById(tableId + '_body');
                        if (!tbody) return;
                        
                        if (!data || !Array.isArray(data) || !data.length) {{
                            tbody.innerHTML = '<tr><td colspan="{len(columns)}" class="pc-empty">No records found</td></tr>';
                            return;
                        }}
                        
                        let html = '';
                        for (let i = 0; i < data.length; i++) {{
                            const row = data[i];
                            const rowDataStr = JSON.stringify(row).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
                            let clickHandler = '';
                            if (onRowClick) {{
                                clickHandler = 'onclick="if (typeof pycromeHandleRowClick === \\\'function\\\') pycromeHandleRowClick(\\\'' + tableId + '\\\', this, \\\'' + onRowClick + '\\\')"';
                            }}
                            html += '<tr data-row-index="' + i + '" data-row-data="' + rowDataStr + '" ' + clickHandler + ' title="Click to select • Double-click to edit">';
                            for (let j = 0; j < fields.length; j++) {{
                                const value = row[fields[j]] !== undefined && row[fields[j]] !== null ? row[fields[j]] : '';
                                html += '<td>' + value + '</td>';
                            }}
                            html += '</tr>';
                        }}
                        tbody.innerHTML = html;
                        setTimeout(initColumnResizing, 50);
                    }} catch (e) {{
                        console.error('Error loading table data:', e);
                        const tbody = document.getElementById(tableId + '_body');
                        if (tbody) {{
                            tbody.innerHTML = '<tr><td colspan="{len(columns)}" class="pc-empty">Error loading data</td></tr>';
                        }}
                    }}
                }}
                
                // Wait for pywebview to be ready
                if (window.pywebview) {{
                    window.addEventListener('pywebviewready', loadTableData);
                }}
                
                // Also try after DOM ready
                if (document.readyState === 'complete') {{
                    setTimeout(loadTableData, 100);
                }} else {{
                    document.addEventListener('DOMContentLoaded', function() {{
                        setTimeout(loadTableData, 100);
                    }});
                }}
            }})();
            </script>
            """

        # Build pagination script if enabled
        pagination_script = ""
        if paginate and source:
            pagination_script = f"""
            <script>
            (function() {{
                const tableId = '{table_id}';
                const source = '{source}';
                const fields = {fields_js};
                const pageSize = {page_size};
                const onRowClick = '{on_row_click}';
                const totalColumns = {len(columns)};
                
                let currentPage = 1;
                let totalPages = 1;
                let allData = [];
                
                function renderPage(page) {{
                    const tbody = document.getElementById(tableId + '_body');
                    const infoSpan = document.getElementById(tableId + '_info');
                    const pagesDiv = document.getElementById(tableId + '_pages');
                    
                    if (!tbody) return;
                    
                    const start = (page - 1) * pageSize;
                    const end = Math.min(start + pageSize, allData.length);
                    const pageData = allData.slice(start, end);
                    
                    let html = '';
                    for (let i = 0; i < pageData.length; i++) {{
                        const row = pageData[i];
                        const actualIndex = start + i;
                        const rowDataStr = JSON.stringify(row).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
                        let clickHandler = '';
                        if (onRowClick) {{
                            clickHandler = 'onclick="if (typeof pycromeHandleRowClick === \\\'function\\\') pycromeHandleRowClick(\\\'' + tableId + '\\\', this, \\\'' + onRowClick + '\\\')"';
                        }}
                        html += '<tr data-row-index="' + actualIndex + '" data-row-data="' + rowDataStr + '" ' + clickHandler + ' title="Click to select • Double-click to edit">';
                        for (let j = 0; j < fields.length; j++) {{
                            const value = row[fields[j]] !== undefined && row[fields[j]] !== null ? row[fields[j]] : '';
                            html += '<td>' + value + '</td>';
                        }}
                        html += '</tr>';
                    }}
                    tbody.innerHTML = html;
                    
                    // Update info
                    if (infoSpan) {{
                        const showing = allData.length ? start + 1 : 0;
                        infoSpan.textContent = 'Showing ' + showing + '-' + end + ' of ' + allData.length + ' records';
                    }}
                    
                    // Update pagination controls
                    if (pagesDiv) {{
                        let pagesHtml = '';
                        
                        // Previous button
                        pagesHtml += '<button class="pc-pagination-btn" ' + (page === 1 ? 'disabled' : '') + ' onclick="window[\\'navigate_' + tableId + '\\'](' + (page - 1) + ')">«</button>';
                        
                        // Page numbers
                        const maxVisible = 5;
                        let startPage = Math.max(1, page - Math.floor(maxVisible / 2));
                        let endPage = Math.min(totalPages, startPage + maxVisible - 1);
                        
                        if (endPage - startPage < maxVisible - 1) {{
                            startPage = Math.max(1, endPage - maxVisible + 1);
                        }}
                        
                        for (let i = startPage; i <= endPage; i++) {{
                            pagesHtml += '<button class="pc-pagination-btn' + (i === page ? ' active' : '') + '" onclick="window[\\'navigate_' + tableId + '\\'](' + i + ')">' + i + '</button>';
                        }}
                        
                        // Next button
                        pagesHtml += '<button class="pc-pagination-btn" ' + (page === totalPages ? 'disabled' : '') + ' onclick="window[\\'navigate_' + tableId + '\\'](' + (page + 1) + ')">»</button>';
                        
                        pagesDiv.innerHTML = pagesHtml;
                    }}
                    
                    setTimeout(initColumnResizing, 50);
                }}
                
                window['navigate_' + tableId] = function(page) {{
                    if (page < 1 || page > totalPages) return;
                    currentPage = page;
                    renderPage(page);
                }};
                
                async function loadTableData() {{
                    if (!source) return;
                    
                    // Check if pycromeCall is available
                    if (typeof window.pycromeCall !== 'function') {{
                        console.error('pycromeCall not available, retrying...');
                        setTimeout(loadTableData, 100);
                        return;
                    }}
                    
                    try {{
                        const data = await window.pycromeCall(source);
                        const tbody = document.getElementById(tableId + '_body');
                        if (!tbody) return;
                        
                        if (!data || !Array.isArray(data) || !data.length) {{
                            tbody.innerHTML = '<tr><td colspan="' + totalColumns + '" class="pc-empty">No records found</td></tr>';
                            const infoSpan = document.getElementById(tableId + '_info');
                            if (infoSpan) infoSpan.textContent = 'No records found';
                            const pagesDiv = document.getElementById(tableId + '_pages');
                            if (pagesDiv) pagesDiv.innerHTML = '';
                            return;
                        }}
                        
                        allData = data;
                        totalPages = Math.ceil(allData.length / pageSize);
                        currentPage = 1;
                        renderPage(1);
                    }} catch (e) {{
                        console.error('Error loading table data:', e);
                        const tbody = document.getElementById(tableId + '_body');
                        if (tbody) {{
                            tbody.innerHTML = '<tr><td colspan="' + totalColumns + '" class="pc-empty">Error loading data</td></tr>';
                        }}
                    }}
                }}
                
                // Wait for pywebview to be ready
                if (window.pywebview) {{
                    window.addEventListener('pywebviewready', loadTableData);
                }}
                
                // Also try after DOM ready
                if (document.readyState === 'complete') {{
                    setTimeout(loadTableData, 100);
                }} else {{
                    document.addEventListener('DOMContentLoaded', function() {{
                        setTimeout(loadTableData, 100);
                    }});
                }}
            }})();
            </script>
            """

        return f"""
        <div class="pc-table-container">
            <div class="pc-table-wrapper">
                <table class="{table_class}" id="{table_id}" data-source="{source}">
                    <thead><tr>{headers}</tr></thead>
                    <tbody id="{table_id}_body">
                        <tr><td colspan="{len(columns)}" class="pc-loading">
                            <div class="pc-spinner"></div> Loading...
                        </td></tr>
                    </tbody>
                </table>
            </div>
            {pagination_html}
        </div>
        {table_script}
        {pagination_script}
        """

    def _render_input(self, node: UINode) -> str:
        placeholder = node.attrs.get("placeholder", "")
        id_ = node.attrs.get("id", "pc_input")
        onchange = node.attrs.get("onchange", "")
        icon = node.attrs.get("icon", "")
        handler = f'pycromeCall("{onchange}", this.value)' if onchange else ""
        
        if icon:
            return (
                f'<div class="pc-input-wrapper">'
                f'<span class="pc-input-icon">{self._icon(icon)}</span>'
                f'<input class="pc-input pc-input-with-icon" id="{id_}" '
                f'placeholder="{placeholder}" '
                f'onchange="{handler}" />'
                f'</div>'
            )
        
        return (
            f'<input class="pc-input" id="{id_}" '
            f'placeholder="{placeholder}" '
            f'onchange="{handler}" />'
        )

    def _render_card(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-card">{children_html}</div>'

    def _render_label(self, node: UINode) -> str:
        text = node.attrs.get("text", "")
        icon = node.attrs.get("icon", "")
        icon_html = self._icon(icon) if icon else ""
        return f'<p class="pc-label">{icon_html} {text}</p>'

    def _render_divider(self, node: UINode) -> str:
        return '<hr class="pc-divider" />'

    def _render_spacer(self, node: UINode) -> str:
        size = node.attrs.get("size", 16)
        return f'<div style="height:{size}px"></div>'

    def _render_row(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        gap   = node.attrs.get("gap", "16")
        wrap  = node.attrs.get("wrap", "true")
        align = node.attrs.get("align", "stretch")
        return (
            f'<div style="display:flex;gap:{gap}px;'
            f'flex-wrap:{"wrap" if wrap == "true" else "nowrap"};'
            f'align-items:{align};margin-bottom:16px">'
            f'{children_html}</div>'
        )

    def _render_col(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        span  = node.attrs.get("span", "1")
        gap   = node.attrs.get("gap", "16")
        align = node.attrs.get("align", "flex-start")
        return (
            f'<div style="display:flex;flex-direction:column;'
            f'gap:{gap}px;flex:{span};align-items:{align}">'
            f'{children_html}</div>'
        )

    def _render_searchbar(self, node: UINode) -> str:
        placeholder = node.attrs.get("placeholder", "Search...")
        id_         = node.attrs.get("id", "pc_search")
        target      = node.attrs.get("target", "")
        onchange    = node.attrs.get("onchange", "")

        # If target table specified, wire up live filter
        filter_js = ""
        if target:
            filter_js = f"pycromeFilterTable('{target}', this.value);"
        if onchange:
            filter_js += f" pycromeCall('{onchange}', this.value);"

        return f"""
        <div class="pc-searchbar-wrapper">
            <span class="pc-searchbar-icon"><i data-feather="search"></i></span>
            <input class="pc-searchbar" id="{id_}"
                placeholder="{placeholder}"
                oninput="{filter_js} this.nextElementSibling.classList.toggle('visible', this.value.length > 0)"
                onkeydown="if(event.key==='Escape'){{ this.value=''; {filter_js} this.nextElementSibling.classList.remove('visible'); }}" />
            <button class="pc-searchbar-clear" onclick="
                this.previousElementSibling.value='';
                this.classList.remove('visible');
                {filter_js.replace('this.value', "''") if filter_js else ''}
            "><i data-feather="x"></i></button>
        </div>
        """

    def _render_statcard(self, node: UINode) -> str:
        label    = node.attrs.get("label", "")
        value    = node.attrs.get("value", "0")
        icon     = node.attrs.get("icon", "activity")
        color    = node.attrs.get("color", "primary")
        trend    = node.attrs.get("trend", "")
        trend_up = node.attrs.get("trend_up", "true") == "true"
        source   = node.attrs.get("source", "")
        id_      = node.attrs.get("id", f"statcard_{label.replace(' ', '_').lower()}")

        colour_map = {
            "primary": ("rgba(79,70,229,0.15)",  "var(--primary)"),
            "success": ("rgba(16,185,129,0.15)", "var(--success)"),
            "danger":  ("rgba(239,68,68,0.15)",  "var(--danger)"),
            "warning": ("rgba(245,158,11,0.15)", "var(--warning)"),
            "info":    ("rgba(79,70,229,0.15)",  "var(--primary)"),
        }
        bg, stroke = colour_map.get(color, colour_map["primary"])

        trend_html = ""
        if trend:
            direction = "up" if trend_up else "down"
            icon_name = "trending-up" if trend_up else "trending-down"
            trend_html = f"""
            <div class="pc-statcard-trend {direction}">
                <i data-feather="{icon_name}"></i>
                <span>{trend}</span>
            </div>"""

        load_js = ""
        if source:
            load_js = f"""
            <script>
            window.addEventListener('pywebviewready', function() {{
                pycromeCall('{source}').then(function(result) {{
                    if (result && result.value !== undefined) {{
                        const el = document.getElementById('{id_}_value');
                        if (el) el.textContent = result.value;
                    }}
                    if (result && result.trend !== undefined) {{
                        const el = document.getElementById('{id_}_trend');
                        if (el) el.textContent = result.trend;
                    }}
                }});
            }});
            </script>"""

        return f"""
        <div class="pc-statcard">
            <div class="pc-statcard-icon" style="background:{bg}">
                <i data-feather="{self._icon_name(icon)}" style="stroke:{stroke}"></i>
            </div>
            <div class="pc-statcard-body">
                <div class="pc-statcard-value" id="{id_}_value">{value}</div>
                <div class="pc-statcard-label">{label}</div>
                {trend_html}
            </div>
        </div>
        {load_js}
        """

    def _render_toolbar(self, node: UINode) -> str:
        children_html = ""
        for child in node.children:
            if child.component == "ToolbarItem":
                children_html += self._render_toolbaritem(child)
            else:
                children_html += self._render_node(child)
        return f'<div class="pc-toolbar">{children_html}</div>'

    def _render_toolbaritem(self, node: UINode) -> str:
        if node.attrs.get("separator", "false") == "true":
            return '<div class="pc-toolbar-separator"></div>'
        return self._render_button(node)

    def _render_breadcrumb(self, node: UINode) -> str:
        items_html = ""
        children   = [c for c in node.children if c.component == "BreadcrumbItem"]
        for i, child in enumerate(children):
            label  = child.attrs.get("label", "")
            route  = child.attrs.get("route", "")
            active = i == len(children) - 1
            cls    = "pc-breadcrumb-item active" if active else "pc-breadcrumb-item"
            click  = f"onclick=\"navigate('{route}')\"" if route and not active else ""
            items_html += f'<span class="{cls}" {click}>{label}</span>'
            if not active:
                items_html += '<span class="pc-breadcrumb-sep"><i data-feather="chevron-right"></i></span>'
        return f'<div class="pc-breadcrumb">{items_html}</div>'

    def _render_tabs(self, node: UINode) -> str:
        tabs      = [c for c in node.children if c.component == "Tab"]
        tabs_id   = node.attrs.get("id", "pc_tabs")
        tab_btns  = ""
        tab_panels = ""

        for i, tab in enumerate(tabs):
            label    = tab.attrs.get("label", f"Tab {i+1}")
            tab_id   = tab.attrs.get("id", f"tab_{i}")
            icon     = tab.attrs.get("icon", "")
            active   = "active" if i == 0 else ""
            icon_html = f'<i data-feather="{self._icon_name(icon)}"></i>' if icon else ""
            tab_btns += f"""
            <button class="pc-tab-btn {active}"
                    onclick="pycromeSwitchTab('{tabs_id}', '{tab_id}', this)">
                {icon_html}{label}
            </button>"""
            children_html = "".join(self._render_node(c) for c in tab.children)
            tab_panels += f"""
            <div class="pc-tab-panel {active}" id="{tabs_id}_{tab_id}">
                {children_html}
            </div>"""

        return f"""
        <div class="pc-tabs" id="{tabs_id}">
            <div class="pc-tabs-header">{tab_btns}</div>
            {tab_panels}
        </div>"""

    def _render_badge(self, node: UINode) -> str:
        text  = node.attrs.get("text", "")
        style = node.attrs.get("style", "info")
        return f'<span class="pc-badge pc-badge-{style}">{text}</span>'

    def _render_tooltip(self, node: UINode) -> str:
        text          = node.attrs.get("text", "")
        children_html = "".join(self._render_node(c) for c in node.children)
        return f"""
        <div class="pc-tooltip-wrapper">
            {children_html}
            <div class="pc-tooltip">{text}</div>
        </div>"""

    def _render_dropdown(self, node: UINode) -> str:
        label    = node.attrs.get("label", "Options")
        icon     = node.attrs.get("icon", "chevron-down")
        style    = node.attrs.get("style", "primary")
        dd_id    = node.attrs.get("id", f"dd_{label.replace(' ','_').lower()}")
        items    = [c for c in node.children if c.component == "DropdownItem"]
        items_html = ""

        for item in items:
            if item.attrs.get("separator", "false") == "true":
                items_html += '<div class="pc-dropdown-divider"></div>'
                continue
            item_label  = item.attrs.get("label", "")
            item_icon   = item.attrs.get("icon", "")
            item_danger = "danger" if item.attrs.get("style", "") == "danger" else ""
            item_onclick = item.attrs.get("onclick", "")
            icon_html   = f'<i data-feather="{self._icon_name(item_icon)}"></i>' if item_icon else ""
            js_native_item = (
                item_onclick.startswith("pycrome") or
                item_onclick.startswith("navigate") or
                item_onclick == ""
            )
            click = item_onclick if js_native_item else f"pycromeCall('{item_onclick}')"
            items_html += f"""
            <div class="pc-dropdown-item {item_danger}"
                onclick="pycromeCloseDropdown('{dd_id}'); {click}">
                {icon_html}{item_label}
            </div>"""

        return f"""
        <div class="pc-dropdown" id="{dd_id}">
            <button class="pc-btn pc-btn-{style}"
                    onclick="pycromeToggleDropdown('{dd_id}')"
                    style="margin-bottom:0">
                {label} <i data-feather="{self._icon_name(icon)}"></i>
            </button>
            <div class="pc-dropdown-menu" id="{dd_id}_menu">
                {items_html}
            </div>
        </div>"""

    def _render_contextmenu(self, node: UINode) -> str:
        menu_id = node.attrs.get("id", "pc_context")
        target  = node.attrs.get("target", "")
        items   = [c for c in node.children if c.component == "ContextMenuItem"]
        items_html = ""

        for item in items:
            if item.attrs.get("separator", "false") == "true":
                items_html += '<div class="pc-context-divider"></div>'
                continue
            item_label  = item.attrs.get("label", "")
            item_icon   = item.attrs.get("icon", "")
            item_danger = "danger" if item.attrs.get("style", "") == "danger" else ""
            item_onclick = item.attrs.get("onclick", "")
            icon_html   = f'<i data-feather="{self._icon_name(item_icon)}"></i>' if item_icon else ""
            js_native_item = (
                item_onclick.startswith("pycrome") or
                item_onclick.startswith("navigate") or
                item_onclick == ""
            )
            click = item_onclick if js_native_item else f"pycromeCall('{item_onclick}')"
            items_html += f"""
            <div class="pc-context-item {item_danger}"
                onclick="pycromeCloseContext(); {click}">
                {icon_html}{item_label}
            </div>"""

        attach_js = ""
        if target:
            attach_js = f"""
            <script>
            document.addEventListener('DOMContentLoaded', function() {{
                const target = document.getElementById('{target}');
                if (target) {{
                    target.addEventListener('contextmenu', function(e) {{
                        e.preventDefault();
                        pycromeShowContext('{menu_id}', e.clientX, e.clientY);
                    }});
                }}
            }});
            </script>"""

        return f"""
        <div class="pc-context-menu" id="{menu_id}">
            {items_html}
        </div>
        {attach_js}"""

    def _render_datepicker(self, node: UINode) -> str:
        id_         = node.attrs.get("id", "pc_date")
        label       = node.attrs.get("label", "")
        placeholder = node.attrs.get("placeholder", "Select date")
        required    = node.attrs.get("required", "false") == "true"
        value       = node.attrs.get("value", "")
        req_attr    = "required" if required else ""
        label_html  = f'<label class="pc-form-label" for="{id_}">{label}</label>' if label else ""

        return f"""
        <div class="pc-form-field">
            {label_html}
            <input type="date" class="pc-datepicker" id="{id_}" name="{id_}"
                value="{value}" placeholder="{placeholder}" {req_attr} />
        </div>"""

    def _render_fileupload(self, node: UINode) -> str:
        id_    = node.attrs.get("id", "pc_file")
        accept = node.attrs.get("accept", "*")
        hint   = node.attrs.get("hint", "PNG, JPG, PDF up to 10MB")
        label  = node.attrs.get("label", "Click to upload or drag and drop")

        return f"""
        <div class="pc-fileupload" id="{id_}_dropzone"
            onclick="document.getElementById('{id_}').click()"
            ondragover="event.preventDefault(); this.classList.add('dragover')"
            ondragleave="this.classList.remove('dragover')"
            ondrop="event.preventDefault(); this.classList.remove('dragover'); pycromeHandleFileDrop(event, '{id_}')">
            <div class="pc-fileupload-icon"><i data-feather="upload-cloud"></i></div>
            <div class="pc-fileupload-text">{label}</div>
            <div class="pc-fileupload-hint">{hint}</div>
            <input type="file" id="{id_}" style="display:none" accept="{accept}"
                onchange="pycromeHandleFileSelect(this, '{id_}')">
        </div>"""

    def _render_toggle(self, node: UINode) -> str:
        id_      = node.attrs.get("id", "pc_toggle")
        label    = node.attrs.get("label", "")
        checked  = node.attrs.get("checked", "false") == "true"
        onchange = node.attrs.get("onchange", "")
        checked_attr = "checked" if checked else ""
        change_js    = f"pycromeCall('{onchange}', this.checked)" if onchange else ""

        return f"""
        <label class="pc-toggle-wrapper">
            <div class="pc-toggle">
                <input type="checkbox" id="{id_}" name="{id_}" {checked_attr}
                    onchange="{change_js}">
                <div class="pc-toggle-track"></div>
                <div class="pc-toggle-thumb"></div>
            </div>
            <span class="pc-toggle-label">{label}</span>
        </label>"""

    def _render_progressbar(self, node: UINode) -> str:
        label   = node.attrs.get("label", "")
        value   = node.attrs.get("value", "0")
        max_val = node.attrs.get("max", "100")
        color   = node.attrs.get("color", "")
        source  = node.attrs.get("source", "")
        id_     = node.attrs.get("id", "pc_progress")

        try:
            pct = min(100, max(0, int(float(value)) * 100 // int(float(max_val))))
        except Exception:
            pct = 0

        load_js = ""
        if source:
            load_js = f"""
            <script>
            window.addEventListener('pywebviewready', function() {{
                pycromeCall('{source}').then(function(result) {{
                    if (result && result.value !== undefined) {{
                        const fill = document.getElementById('{id_}_fill');
                        const val  = document.getElementById('{id_}_val');
                        if (fill) fill.style.width = result.value + '%';
                        if (val)  val.textContent  = result.value + '%';
                    }}
                }});
            }});
            </script>"""

        return f"""
        <div class="pc-progressbar-wrapper">
            <div class="pc-progressbar-header">
                <span class="pc-progressbar-label">{label}</span>
                <span class="pc-progressbar-value" id="{id_}_val">{pct}%</span>
            </div>
            <div class="pc-progressbar-track">
                <div class="pc-progressbar-fill {color}" id="{id_}_fill"
                    style="width:{pct}%"></div>
            </div>
        </div>
        {load_js}"""

    def _render_notificationbell(self, node: UINode) -> str:
        count  = node.attrs.get("count", "0")
        source = node.attrs.get("source", "")
        id_    = node.attrs.get("id", "pc_notif")

        badge_html = f'<div class="pc-notification-badge" id="{id_}_badge">{count}</div>' if count != "0" else \
                    f'<div class="pc-notification-badge" id="{id_}_badge" style="display:none">{count}</div>'

        load_js = ""
        if source:
            load_js = f"""
            <script>
            window.addEventListener('pywebviewready', function() {{
                pycromeCall('{source}').then(function(result) {{
                    if (result && result.count !== undefined) {{
                        const badge = document.getElementById('{id_}_badge');
                        if (badge) {{
                            badge.textContent = result.count;
                            badge.style.display = result.count > 0 ? 'flex' : 'none';
                        }}
                    }}
                }});
            }});
            </script>"""

        return f"""
        <div class="pc-notification-bell" id="{id_}" title="Notifications">
            <i data-feather="bell"></i>
            {badge_html}
        </div>
        {load_js}"""

    def _render_accordion(self, node: UINode) -> str:
        items      = [c for c in node.children if c.component == "AccordionItem"]
        items_html = ""
        for i, item in enumerate(items):
            title         = item.attrs.get("title", f"Item {i+1}")
            open_cls      = "open" if item.attrs.get("open", "false") == "true" else ""
            children_html = "".join(self._render_node(c) for c in item.children)
            items_html += f"""
            <div class="pc-accordion-item {open_cls}">
                <div class="pc-accordion-header"
                    onclick="this.parentElement.classList.toggle('open')">
                    <span>{title}</span>
                    <i data-feather="chevron-down"></i>
                </div>
                <div class="pc-accordion-body">{children_html}</div>
            </div>"""
        return f'<div class="pc-accordion">{items_html}</div>'

    def _render_stepper(self, node: UINode) -> str:
        items      = [c for c in node.children if c.component == "StepperItem"]
        active_idx = int(node.attrs.get("active", "0"))
        items_html = ""
        for i, item in enumerate(items):
            label = item.attrs.get("label", f"Step {i+1}")
            if i < active_idx:
                cls    = "completed"
                circle = '<i data-feather="check"></i>'
            elif i == active_idx:
                cls    = "active"
                circle = str(i + 1)
            else:
                cls    = ""
                circle = str(i + 1)
            items_html += f"""
            <div class="pc-stepper-item {cls}">
                <div class="pc-stepper-circle">{circle}</div>
                <div class="pc-stepper-label">{label}</div>
            </div>"""
        return f'<div class="pc-stepper">{items_html}</div>'

    def _render_chart(self, node: UINode) -> str:
        title   = node.attrs.get("title", "")
        type_   = node.attrs.get("type", "bar")
        source  = node.attrs.get("source", "")
        id_     = node.attrs.get("id", "pc_chart")
        height  = node.attrs.get("height", "300")

        load_js = ""
        if source:
            load_js = f"""
            <script>
            window.addEventListener('pywebviewready', function() {{
                pycromeCall('{source}').then(function(data) {{
                    if (!data) return;
                    pycromeRenderChart('{id_}_canvas', '{type_}', data);
                }});
            }});
            </script>"""

        return f"""
        <div class="pc-chart-wrapper">
            <div class="pc-chart-title">{title}</div>
            <canvas id="{id_}_canvas" height="{height}"></canvas>
        </div>
        {load_js}"""

    def _render_datagrid(self, node: UINode) -> str:
        grid_id = node.attrs.get("id", "pc_grid")
        source  = node.attrs.get("source", "")
        onsave  = node.attrs.get("onsave", "")
        columns = [c for c in node.children if c.component == "GridColumn"]

        headers = "".join(
            f'<th>{col.attrs.get("label", col.attrs.get("field", ""))}</th>'
            for col in columns
        )
        col_fields   = [col.attrs.get("field", "") for col in columns]
        col_editable = [col.attrs.get("editable", "false") == "true" for col in columns]
        fields_js    = str(col_fields)
        editable_js  = str(col_editable).lower()

        return f"""
        <div class="pc-table-wrapper">
            <table class="pc-table pc-datagrid" id="{grid_id}">
                <thead><tr>{headers}</tr></thead>
                <tbody id="{grid_id}_body">
                    <tr><td colspan="{len(columns)}" class="pc-loading">Loading...</td></tr>
                </tbody>
            </table>
        </div>
        <script>
        (function() {{
            const fields   = {fields_js};
            const editable = {editable_js};
            const gridId   = '{grid_id}';
            const onsave   = '{onsave}';

            function loadGrid() {{
                pycromeCall('{source}').then(function(data) {{
                    if (!data) return;
                    const tbody = document.getElementById(gridId + '_body');
                    tbody.innerHTML = data.map((row, ri) => `
                        <tr data-row-index="${{ri}}">
                            ${{fields.map((f, fi) => {{
                                const val = row[f] || '';
                                if (editable[fi]) {{
                                    return `<td class="editable"
                                        ondblclick="pycromeGridEdit(this, '${{gridId}}', ${{ri}}, '${{f}}')"
                                        data-field="${{f}}" data-value="${{val}}">${{val}}</td>`;
                                }}
                                return `<td>${{val}}</td>`;
                            }}).join('')}}
                        </tr>
                    `).join('');
                }});
            }}

            window.addEventListener('pywebviewready', loadGrid);
        }})();
        </script>"""

    def _render_navbar(self, node: UINode) -> str:
        brand    = node.attrs.get("brand", "")
        icon     = node.attrs.get("icon", "layout")
        children_html = "".join(self._render_node(c) for c in node.children)
        return f"""
        <div class="pc-navbar">
            <div class="pc-navbar-brand">
                <i data-feather="{self._icon_name(icon)}"></i>
                <span>{brand}</span>
            </div>
            <div class="pc-navbar-actions">{children_html}</div>
        </div>"""

    def _icon_name(self, name: str) -> str:
        """Return the feather icon name for a given alias."""
        icon_map = {
            "grid": "grid", "users": "users", "money": "dollar-sign",
            "settings": "settings", "home": "home", "reports": "bar-chart-2",
            "fees": "credit-card", "logout": "log-out", "search": "search",
            "add": "plus-circle", "edit": "edit-2", "delete": "trash-2",
            "save": "save", "cancel": "x-circle", "refresh": "refresh-cw",
            "download": "download", "upload": "upload", "info": "info",
            "warning": "alert-triangle", "error": "alert-circle",
            "success": "check-circle", "menu": "menu", "more": "more-vertical",
            "close": "x", "check": "check", "calendar": "calendar",
            "clock": "clock", "phone": "phone", "mail": "mail",
            "lock": "lock", "eye": "eye", "file": "file",
            "folder": "folder", "database": "database", "activity": "activity",
            "trending-up": "trending-up", "trending-down": "trending-down",
            "chevron-down": "chevron-down", "chevron-right": "chevron-right",
            "chevron-left": "chevron-left", "arrow-left": "arrow-left",
            "bell": "bell", "star": "star", "heart": "heart",
            "printer": "printer", "share": "share-2", "copy": "copy",
            "layout": "layout", "list": "list", "tag": "tag",
            "user": "user", "user-plus": "user-plus", "shield": "shield",
            "key": "key", "globe": "globe", "map": "map-pin",
            "image": "image", "camera": "camera", "mic": "mic",
            "upload-cloud": "upload-cloud", "gift": "gift", "award": "award",
            "dollar-sign": "dollar-sign", "check-circle": "check-circle",
        }
        return icon_map.get(name, name)

    def _render_themeswitcher(self, node: UINode) -> str:
        """Render a theme switcher widget with dots for available themes."""
        from pycrome.theme import THEMES
        
        themes = list(THEMES.keys())
        dots_html = ""
        for theme_name in themes:
            active_class = "active" if theme_name == self.theme_name else ""
            theme_colors = THEMES[theme_name]
            bg_color = theme_colors.get("primary", "#4f46e5")
            dots_html += (
                f'<div class="pc-theme-dot {active_class}" '
                f'style="background: {bg_color};" '
                f'data-theme="{theme_name}" '
                f'onclick="pycromeSetTheme(\'{theme_name}\')" '
                f'title="{theme_name.capitalize()} Theme"></div>'
            )
        
        return f"""
        <div class="pc-theme-switcher">
            <p>Theme</p>
            <div class="pc-theme-dots">
                {dots_html}
            </div>
        </div>
        """

    def _render_generic(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-{node.component.lower()}">{children_html}</div>'

    def _render_topnav(self, node: UINode) -> str:
        brand      = node.attrs.get("brand", "")
        icon       = node.attrs.get("icon", "layout")
        children   = node.children
        nav_items  = [c for c in children if c.component == "TopNavItem"]
        actions    = [c for c in children if c.component != "TopNavItem"]

        items_html = "".join(self._render_topnavitem(c) for c in nav_items)
        actions_html = "".join(self._render_node(c) for c in actions)

        brand_html = ""
        if brand:
            brand_html = f"""
            <div class="pc-topnav-brand">
                <div class="pc-topnav-brand-icon">
                    <i data-feather="{self._icon_name(icon)}"></i>
                </div>
                <span class="pc-topnav-brand-name">{brand}</span>
            </div>"""

        actions_section = ""
        if actions_html:
            actions_section = f'<div class="pc-topnav-actions">{actions_html}</div>'

        return f"""
        <div class="pc-topnav" id="pc_topnav">
            {brand_html}
            <div class="pc-topnav-items" id="pc_topnav_items">
                {items_html}
            </div>
            {actions_section}
        </div>"""

    def _render_topnavitem(self, node: UINode) -> str:
        label   = node.attrs.get("label", "")
        icon    = node.attrs.get("icon", "")
        module  = node.attrs.get("module", label.lower())
        active  = node.attrs.get("active", "false") == "true"
        active_cls = "active" if active else ""
        icon_html  = f'<i data-feather="{self._icon_name(icon)}"></i>' if icon else ""
        tooltip    = node.attrs.get("tooltip", label)

        return f"""
        <div class="pc-topnav-item {active_cls} pc-tooltip-wrapper"
            id="topnav_{module}"
            onclick="pycromeSwitchModule('{module}')"
            title="{tooltip}">
            {icon_html}
            <span>{label}</span>
            <div class="pc-tooltip">{tooltip}</div>
        </div>"""

    def _render_collapsiblesidebar(self, node: UINode) -> str:
        collapsed     = node.attrs.get("collapsed", "false") == "true"
        collapsed_cls = "collapsed" if collapsed else ""

        # Group SidebarItems and Trees by module
        from collections import defaultdict
        module_items = defaultdict(list)
        
        for child in node.children:
            if child.component == "SidebarItem":
                mod = child.attrs.get("module", "default")
                module_items[mod].append(("item", child))
            elif child.component == "Tree":
                mod = child.attrs.get("module", "default")
                module_items[mod].append(("tree", child))
            elif child.component == "Divider":
                # Attach divider to all current modules as a separator
                for mod in module_items:
                    module_items[mod].append(("divider", None))

        panels_html = ""
        for mod_name, items in module_items.items():
            items_html = ""
            first_route = ""
            
            for kind, child in items:
                if kind == "divider":
                    items_html += '<hr class="pc-divider" style="margin:6px 8px"/>'
                elif kind == "item":
                    items_html += self._render_sidebaritem(child)
                    if not first_route:
                        first_route = child.attrs.get("route", "")
                elif kind == "tree":
                    items_html += self._render_tree(child)
                    # Try to get first route from tree items
                    if not first_route:
                        first_tree_item = self._find_first_tree_route(child)
                        if first_tree_item:
                            first_route = first_tree_item

            panels_html += f"""
            <div class="pc-module-sidebar" id="sidebar_{mod_name}"
                data-module="{mod_name}"
                data-default-route="{first_route}">
                <div class="pc-sidebar-header">
                    <span class="pc-sidebar-section-title">{mod_name.capitalize()}</span>
                    <div class="pc-sidebar-toggle"
                        onclick="pycromeToggleSidebar()"
                        title="Toggle sidebar">
                        <i data-feather="chevrons-left"></i>
                    </div>
                </div>
                <div class="pc-sidebar-items">
                    {items_html}
                </div>
            </div>"""

        # User profile panel at bottom
        user_profile_html = """
            <div class="pc-sidebar-user" id="pc_sidebar_user">
                <div class="pc-sidebar-user-avatar" id="pc_user_avatar">A</div>
                <div class="pc-sidebar-user-info">
                    <div class="pc-sidebar-user-name" id="pc_user_name">Administrator</div>
                    <div class="pc-sidebar-user-role" id="pc_user_role">admin</div>
                </div>
            </div>"""

        return f"""
        <div class="pc-collapsible-sidebar {collapsed_cls}"
            id="pc_collapsible_sidebar">
            {panels_html}
            {user_profile_html}
        </div>"""

    def _find_first_tree_route(self, tree_node: UINode) -> str:
        """Recursively find the first route in a Tree component."""
        for child in tree_node.children:
            if child.component == "TreeItem":
                route = child.attrs.get("route", "")
                if route:
                    return route
            elif child.component == "TreeGroup":
                route = self._find_first_tree_route(child)
                if route:
                    return route
        return ""

    def _render_sidebaritem(self, node: UINode) -> str:
        label   = node.attrs.get("label", "")
        icon    = node.attrs.get("icon", "")
        route   = node.attrs.get("route", "")
        module  = node.attrs.get("module", "")  # ← ADD THIS
        onclick = node.attrs.get("onclick", "")
        active  = node.attrs.get("active", "false") == "true"
        active_cls = "active" if active else ""
        icon_html  = f'<i data-feather="{self._icon_name(icon)}"></i>' if icon else ""

        if route:
            click_handler = f"pycromeNavigate('{route}')"
        elif onclick:
            js_native = (
                onclick.startswith("pycrome") or
                onclick.startswith("navigate") or
                onclick == ""
            )
            click_handler = onclick if js_native else f"pycromeCall('{onclick}')"
        else:
            click_handler = ""

        # Build data-module attribute only if module is provided
        module_attr = f' data-module="{module}"' if module else ''

        return f"""
        <div class="pc-sidebar-item {active_cls}"
            id="sidebar_item_{route or label.lower().replace(' ', '_')}"
            onclick="{click_handler}"
            data-route="{route}"
            data-label="{label}"{module_attr}>
            {icon_html}
            <span class="pc-sidebar-item-label">{label}</span>
            <div class="pc-sidebar-tooltip">{label}</div>
        </div>"""

    def _render_statusbar(self, node: UINode) -> str:
        children   = node.children
        items_html = "".join(self._render_statusitem(c)
                            for c in children if c.component == "StatusItem")
        return f"""
        <div class="pc-statusbar" id="pc_statusbar">
            {items_html}
            <div class="pc-statusbar-spacer"></div>
            <div class="pc-statusbar-item" id="pc_statusbar_clock">
                <i data-feather="clock"></i>
                <span id="pc_clock">--:--:--</span>
            </div>
        </div>"""

    def _render_statusitem(self, node: UINode) -> str:
        text    = node.attrs.get("text", "")
        icon    = node.attrs.get("icon", "")
        id_     = node.attrs.get("id", "")
        dot     = node.attrs.get("dot", "")
        source  = node.attrs.get("source", "")

        icon_html = f'<i data-feather="{self._icon_name(icon)}"></i>' if icon else ""
        dot_html  = f'<span class="pc-statusbar-dot {dot}"></span>' if dot else ""
        id_attr   = f'id="{id_}"' if id_ else ""

        load_js = ""
        if source and id_:
            load_js = f"""
            <script>
            window.addEventListener('pywebviewready', function() {{
                pycromeCall('{source}').then(function(result) {{
                    if (result && result.text !== undefined) {{
                        const el = document.getElementById('{id_}');
                        if (el) el.querySelector('span:last-child').textContent = result.text;
                    }}
                    if (result && result.dot !== undefined) {{
                        const el = document.getElementById('{id_}');
                        if (el) {{
                            const dot = el.querySelector('.pc-statusbar-dot');
                            if (dot) dot.className = 'pc-statusbar-dot ' + result.dot;
                        }}
                    }}
                }});
            }});
            </script>"""

        return f"""
        <div class="pc-statusbar-item" {id_attr}>
            {dot_html}{icon_html}
            <span>{text}</span>
        </div>
        {load_js}"""

    def _render_appbody(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-app-body">{children_html}</div>'

    def _render_contentarea(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-content-area" id="pc_content_area">{children_html}</div>'

    def _render_applayout(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-app-layout">{children_html}</div>'

    def _render_tree(self, node: UINode) -> str:
        children_html = "".join(self._render_node(c) for c in node.children)
        id_ = node.attrs.get("id", "pc_tree")
        return f'<div class="pc-tree" id="{id_}">{children_html}</div>'

    def _render_treegroup(self, node: UINode) -> str:
        label    = node.attrs.get("label", "")
        icon     = node.attrs.get("icon", "")
        badge    = node.attrs.get("badge", "")
        open_    = node.attrs.get("open", "false") == "true"
        module   = node.attrs.get("module", "")
        group_id = node.attrs.get("id", f"tg_{label.lower().replace(' ', '_')}")
        open_cls = "open" if open_ else ""

        icon_html  = f'<span class="pc-tree-group-icon"><i data-feather="{self._icon_name(icon)}"></i></span>' if icon else ""
        badge_html = f'<span class="pc-tree-group-badge">{badge}</span>' if badge else ""

        # Module switching if specified
        click_js = f"pycromeToggleTreeGroup('{group_id}')"
        if module:
            click_js = f"pycromeSwitchModule('{module}'); pycromeToggleTreeGroup('{group_id}')"

        children_html = "".join(self._render_node(c) for c in node.children)

        return f"""
        <div class="pc-tree-group {open_cls}" id="{group_id}">
            <div class="pc-tree-group-header"
                onclick="{click_js}"
                data-label="{label}">
                {icon_html}
                <span class="pc-tree-group-label">{label}</span>
                {badge_html}
                <span class="pc-tree-arrow">
                    <i data-feather="chevron-right"></i>
                </span>
            </div>
            <div class="pc-tree-children">
                {children_html}
            </div>
        </div>"""

    def _render_treeitem(self, node: UINode) -> str:
        label   = node.attrs.get("label", "")
        icon    = node.attrs.get("icon", "")
        route   = node.attrs.get("route", "")
        onclick = node.attrs.get("onclick", "")
        badge   = node.attrs.get("badge", "")
        active  = node.attrs.get("active", "false") == "true"
        active_cls = "active" if active else ""

        icon_html  = f'<span class="pc-tree-item-icon"><i data-feather="{self._icon_name(icon)}"></i></span>' if icon else ""
        badge_html = f'<span class="pc-tree-item-badge">{badge}</span>' if badge else ""

        if route:
            click_handler = f"pycromeNavigate('{route}')"
        elif onclick:
            js_native = (
                onclick.startswith("pycrome") or
                onclick.startswith("navigate") or
                onclick == ""
            )
            click_handler = onclick if js_native else f"pycromeCall('{onclick}')"
        else:
            click_handler = ""

        return f"""
        <div class="pc-tree-item {active_cls}"
            id="tree_item_{route or label.lower().replace(' ', '_')}"
            onclick="{click_handler}"
            data-route="{route}"
            data-label="{label}">
            {icon_html}
            <span class="pc-tree-item-label">{label}</span>
            {badge_html}
        </div>"""

    def _icon(self, name: str) -> str:
        """Return Feather icon HTML markup for the given icon name."""
        return f'<i data-feather="{self._icon_name(name)}"></i>'
        icon_map = {
            "grid": "grid",
            "users": "users",
            "money": "dollar-sign",
            "settings": "settings",
            "home": "home",
            "reports": "bar-chart-2",
            "fees": "credit-card",
            "logout": "log-out",
            "search": "search",
            "add": "plus-circle",
            "edit": "edit",
            "delete": "trash-2",
            "save": "save",
            "cancel": "x-circle",
            "refresh": "refresh-cw",
            "download": "download",
            "upload": "upload",
            "info": "info",
            "warning": "alert-triangle",
            "error": "alert-circle",
            "success": "check-circle",
            "menu": "menu",
            "more": "more-vertical",
            "close": "x",
            "check": "check",
            "chevron-left": "chevron-left",
            "chevron-right": "chevron-right",
            "chevron-up": "chevron-up",
            "chevron-down": "chevron-down",
            "arrow-left": "arrow-left",
            "arrow-right": "arrow-right",
            "arrow-up": "arrow-up",
            "arrow-down": "arrow-down",
            "mail": "mail",
            "lock": "lock",
            "unlock": "unlock",
            "eye": "eye",
            "eye-off": "eye-off",
            "calendar": "calendar",
            "clock": "clock",
            "map": "map-pin",
            "phone": "phone",
            "globe": "globe",
            "link": "link",
            "file": "file",
            "folder": "folder",
            "image": "image",
            "video": "video",
            "music": "music",
            "mic": "mic",
            "camera": "camera",
            "sun": "sun",
            "moon": "moon",
            "help": "help-circle",
            "star": "star",
            "heart": "heart",
            "share": "share-2",
            "printer": "printer",
            "database": "database",
            "server": "server",
            "wifi": "wifi",
            "bluetooth": "bluetooth",
            "battery": "battery",
            "shield": "shield",
            "activity": "activity",
            "award": "award",
            "book": "book",
            "briefcase": "briefcase",
            "code": "code",
            "command": "command",
            "compass": "compass",
            "copy": "copy",
            "cpu": "cpu",
            "disc": "disc",
            "flag": "flag",
            "gift": "gift",
            "hash": "hash",
            "key": "key",
            "layout": "layout",
            "list": "list",
            "loader": "loader",
            "maximize": "maximize",
            "minimize": "minimize",
            "monitor": "monitor",
            "package": "package",
            "pause": "pause",
            "play": "play",
            "power": "power",
            "radio": "radio",
            "repeat": "repeat",
            "send": "send",
            "sliders": "sliders",
            "speaker": "speaker",
            "tag": "tag",
            "target": "target",
            "thermometer": "thermometer",
            "thumbs-up": "thumbs-up",
            "thumbs-down": "thumbs-down",
            "toggle-left": "toggle-left",
            "toggle-right": "toggle-right",
            "tool": "tool",
            "trending-up": "trending-up",
            "trending-down": "trending-down",
            "tv": "tv",
            "umbrella": "umbrella",
            "user": "user",
            "user-plus": "user-plus",
            "user-minus": "user-minus",
            "user-check": "user-check",
            "user-x": "user-x",
            "volume": "volume-2",
            "volume-x": "volume-x",
            "watch": "watch",
            "zap": "zap",
        }
        
        feather_name = icon_map.get(name, name)
        return f'<i data-feather="{feather_name}"></i>'

    def _base_css(self) -> str:
        css_vars = generate_css_variables(self.theme)
        return f"""
        {css_vars}

        * {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
            background: var(--bg-primary);
            color: var(--text-primary);
            font-family: var(--font);
            font-size: 14px;
            height: 100vh;
            overflow: hidden;
        }}

        .pc-window {{
            display: flex;
            height: 100vh;
            width: 100vw;
        }}

        .pc-sidebar {{
            background: var(--bg-surface);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            padding: 24px 12px;
            gap: 4px;
            min-height: 100vh;
        }}

        .pc-navitem {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 12px;
            border-radius: var(--radius);
            cursor: pointer;
            color: var(--text-secondary);
            transition: all 0.15s ease;
        }}

        .pc-navitem:hover {{
            background: var(--bg-elevated);
            color: var(--text-primary);
        }}

        .pc-navitem.active {{
            background: var(--primary);
            color: white;
        }}

        .pc-nav-icon {{
            display: flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
        }}

        .pc-nav-icon svg {{
            width: 18px;
            height: 18px;
            stroke-width: 2;
        }}

        .pc-navitem.active .pc-nav-icon svg {{
            stroke: white;
        }}

        .pc-nav-label {{ font-size: 14px; font-weight: 500; }}

        .pc-mainpanel {{
            flex: 1;
            padding: 32px;
            overflow-y: auto;
            background: var(--bg-primary);
        }}

        .pc-screen {{
            display: none;
            width: 100%;
        }}

        .pc-screen.active {{
            display: block;
        }}

        .pc-screen-default {{
            display: block;
        }}

        .pc-header {{ margin-bottom: 24px; }}
        .pc-header-title {{
            font-size: 24px;
            font-weight: 700;
            color: var(--text-primary);
        }}
        .pc-header-sub {{
            font-size: 14px;
            color: var(--text-secondary);
            margin-top: 4px;
        }}

        .pc-btn {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border: none;
            border-radius: var(--radius);
            padding: 9px 18px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.15s ease;
            margin-bottom: 16px;
        }}

        .pc-btn svg {{
            width: 16px;
            height: 16px;
            stroke-width: 2;
        }}

        .pc-btn-primary {{ background: var(--primary); color: white; }}
        .pc-btn-primary svg {{ stroke: white; }}
        .pc-btn-primary:hover {{ background: var(--primary-hover); }}
        .pc-btn-danger {{ background: var(--danger); color: white; }}
        .pc-btn-danger svg {{ stroke: white; }}
        .pc-btn-danger:hover {{ background: var(--danger-hover); }}

        .pc-table-wrapper {{
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            overflow-x: auto;
            overflow-y: visible;
            margin-bottom: 16px;
            max-width: 100%;
        }}

        .pc-table {{
            width: 100%;
            border-collapse: collapse;
            min-width: 100%;
            table-layout: auto;
        }}

        .pc-table th {{
            background: var(--bg-elevated);
            padding: 12px 16px;
            text-align: left;
            font-size: 13px;
            font-weight: 700;
            color: var(--text-primary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 2px solid var(--primary);
            white-space: nowrap;
            position: relative;
            user-select: none;
        }}

        .pc-table th::after {{
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            cursor: col-resize;
            background: transparent;
        }}

        .pc-table th:hover::after {{
            background: var(--primary);
            opacity: 0.3;
        }}

        .pc-table td {{
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 300px;
        }}

        .pc-table tbody tr {{
            cursor: default;
            transition: background 0.15s ease;
        }}

        /* Row selection styles - more specific to override hover */
        .pc-table.selectable-rows tbody tr.selected,
        .pc-table.selectable-rows tbody tr.selected:hover {{
            background: var(--primary) !important;
            color: white;
        }}

        .pc-table.selectable-rows tbody tr.selected td,
        .pc-table.selectable-rows tbody tr.selected:hover td {{
            color: white !important;
        }}

        /* For sticky first column */
        .pc-table.sticky-first.selectable-rows tbody tr.selected td:first-child,
        .pc-table.sticky-first.selectable-rows tbody tr.selected:hover td:first-child {{
            background: var(--primary) !important;
        }}

        /* Hover state for non-selected rows */
        .pc-table.selectable-rows tbody tr:hover:not(.selected) {{
            background: var(--bg-elevated);
        }}

        .pc-table.selectable-rows tbody tr {{
            cursor: pointer;
        }}

        .pc-table.sticky-first tbody tr:hover:not(.selected) td:first-child {{
            background: var(--bg-elevated);
        }}

        .pc-empty, .pc-loading {{
            text-align: center;
            color: var(--text-muted);
            padding: 32px;
        }}

        .pc-input-wrapper {{
            position: relative;
            display: flex;
            align-items: center;
            margin-bottom: 16px;
        }}

        .pc-input-icon {{
            position: absolute;
            left: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 16px;
            height: 16px;
        }}

        .pc-input-icon svg {{
            width: 16px;
            height: 16px;
            stroke: var(--text-muted);
            stroke-width: 2;
        }}

        .pc-input {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            color: var(--text-primary);
            font-size: 14px;
            padding: 9px 14px;
            width: 100%;
            outline: none;
            transition: border 0.15s ease;
            margin-bottom: 16px;
        }}

        .pc-input-with-icon {{
            padding-left: 40px;
        }}

        .pc-input:focus {{ border-color: var(--primary); }}

        .pc-card {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 20px;
            margin-bottom: 16px;
        }}

        .pc-divider {{
            border: none;
            border-top: 1px solid var(--border);
            margin: 16px 0;
        }}

        .pc-label {{
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 8px;
        }}

        .pc-label svg {{
            width: 14px;
            height: 14px;
            stroke: var(--text-muted);
            stroke-width: 2;
        }}

        .pc-theme-switcher {{
            margin-top: auto;
            padding: 12px;
            border-top: 1px solid var(--border);
        }}

        .pc-theme-switcher p {{
            font-size: 11px;
            color: var(--text-muted);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }}

        .pc-theme-dots {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }}

        .pc-theme-dot {{
            width: 24px;
            height: 24px;
            border-radius: 50%;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.15s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}

        .pc-theme-dot:hover {{
            transform: scale(1.1);
            border-color: var(--primary);
        }}

        .pc-theme-dot.active {{
            border-color: var(--text-primary);
            box-shadow: 0 0 0 2px var(--primary);
        }}

        /* Modal styles */
        .pc-modal-overlay {{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: none;  /* Change from flex to none */
            align-items: center;
            justify-content: center;
            z-index: 1000;
            backdrop-filter: blur(4px);
        }}

        .pc-modal-overlay.active {{
            display: flex;
        }}

        .pc-modal {{
            background: var(--bg-surface);
            border-radius: var(--radius-lg);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            width: 90%;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            animation: pcModalFadeIn 0.2s ease;
        }}

        @keyframes pcModalFadeIn {{
            from {{
                opacity: 0;
                transform: translateY(-20px);
            }}
            to {{
                opacity: 1;
                transform: translateY(0);
            }}
        }}

        .pc-modal-header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
        }}

        .pc-modal-title {{
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            margin: 0;
        }}

        .pc-modal-close {{
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--radius-sm);
            transition: background 0.15s ease;
        }}

        .pc-modal-close:hover {{
            background: var(--bg-elevated);
        }}

        .pc-modal-close svg {{
            width: 20px;
            height: 20px;
            stroke: var(--text-secondary);
        }}

        .pc-modal-body {{
            padding: 24px;
            overflow-y: auto;
        }}

        /* Form styles */
        .pc-form {{
            display: flex;
            flex-direction: column;
            gap: 20px;
        }}

        .pc-form-field {{
            display: flex;
            flex-direction: column;
            gap: 6px;
        }}

        .pc-form-label {{
            font-size: 14px;
            font-weight: 500;
            color: var(--text-primary);
        }}

        .pc-select {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            color: var(--text-primary);
            font-size: 14px;
            padding: 9px 14px;
            width: 100%;
            outline: none;
            transition: border 0.15s ease;
            cursor: pointer;
        }}

        .pc-select:focus {{
            border-color: var(--primary);
        }}

        .pc-textarea {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            color: var(--text-primary);
            font-size: 14px;
            padding: 9px 14px;
            width: 100%;
            outline: none;
            transition: border 0.15s ease;
            resize: vertical;
            font-family: var(--font);
        }}

        .pc-textarea:focus {{
            border-color: var(--primary);
        }}

        .pc-form-actions {{
            display: flex;
            gap: 12px;
            justify-content: flex-end;
            margin-top: 8px;
        }}

        .pc-form-actions .pc-btn {{
            margin-bottom: 0;
        }}

/* ── Toast Notifications ── */
        .pc-toast-container {{
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 10px;
            pointer-events: none;
        }}

        .pc-toast {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 18px;
            border-radius: var(--radius);
            font-size: 14px;
            font-weight: 500;
            color: white;
            min-width: 280px;
            max-width: 400px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.3);
            pointer-events: all;
            animation: pcToastIn 0.3s ease;
            cursor: pointer;
        }}

        .pc-toast.hiding {{
            animation: pcToastOut 0.3s ease forwards;
        }}

        .pc-toast-success {{ background: var(--success); }}
        .pc-toast-error   {{ background: var(--danger); }}
        .pc-toast-warning {{ background: var(--warning); color: #1a1a1a; }}
        .pc-toast-info    {{ background: var(--primary); }}

        .pc-toast-icon {{ 
            display: flex; 
            align-items: center;
            flex-shrink: 0;
        }}

        .pc-toast-icon svg {{
            width: 18px;
            height: 18px;
            stroke: white;
            stroke-width: 2.5;
        }}

        .pc-toast-warning .pc-toast-icon svg {{ stroke: #1a1a1a; }}

        .pc-toast-message {{ flex: 1; line-height: 1.4; }}

        .pc-toast-close {{
            background: none;
            border: none;
            color: inherit;
            cursor: pointer;
            opacity: 0.7;
            padding: 0;
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }}

        .pc-toast-close:hover {{ opacity: 1; }}
        .pc-toast-close svg {{ width: 16px; height: 16px; stroke: currentColor; }}

        @keyframes pcToastIn {{
            from {{ opacity: 0; transform: translateX(100%); }}
            to   {{ opacity: 1; transform: translateX(0); }}
        }}

        @keyframes pcToastOut {{
            from {{ opacity: 1; transform: translateX(0); }}
            to   {{ opacity: 0; transform: translateX(100%); }}
        }}

        /* ── Loading Spinner ── */
        .pc-spinner {{
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid var(--border);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: pcSpin 0.7s linear infinite;
        }}

        .pc-spinner-lg {{
            width: 36px;
            height: 36px;
            border-width: 3px;
        }}

        @keyframes pcSpin {{
            to {{ transform: rotate(360deg); }}
        }}

        .pc-loading-row {{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 40px;
            color: var(--text-muted);
        }}

        /* ── Confirmation Dialog ── */
        .pc-confirm-overlay {{
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.6);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9998;
            backdrop-filter: blur(2px);
        }}

        .pc-confirm-overlay.active {{ display: flex; }}

        .pc-confirm-dialog {{
            background: var(--bg-surface);
            border-radius: var(--radius-lg);
            padding: 28px;
            width: 380px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
            animation: pcModalFadeIn 0.2s ease;
        }}

        .pc-confirm-icon {{
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: rgba(239,68,68,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
        }}

        .pc-confirm-icon svg {{
            width: 24px;
            height: 24px;
            stroke: var(--danger);
            stroke-width: 2;
        }}

        .pc-confirm-title {{
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 8px;
        }}

        .pc-confirm-message {{
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 24px;
            line-height: 1.5;
        }}

        .pc-confirm-actions {{
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        }}

        .pc-confirm-actions .pc-btn {{ margin-bottom: 0; }}

        /* ── Form Validation ── */
        .pc-input.invalid,
        .pc-select.invalid,
        .pc-textarea.invalid {{
            border-color: var(--danger);
            background: rgba(239,68,68,0.05);
        }}

        .pc-field-error {{
            font-size: 12px;
            color: var(--danger);
            margin-top: 4px;
            display: none;
        }}

        .pc-field-error.visible {{ display: block; }}

        .pc-form-field.has-error .pc-field-error {{ display: block; }}
        .pc-form-field.has-error .pc-input,
        .pc-form-field.has-error .pc-select,
        .pc-form-field.has-error .pc-textarea {{
            border-color: var(--danger);
        }}

        /* ── Error Screen ── */
        .pc-error-screen {{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            padding: 40px;
            text-align: center;
            background: var(--bg-primary);
        }}

        .pc-error-icon {{
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: rgba(239,68,68,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 24px;
        }}

        .pc-error-icon svg {{
            width: 32px;
            height: 32px;
            stroke: var(--danger);
            stroke-width: 2;
        }}

        .pc-error-title {{
            font-size: 22px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 12px;
        }}

        .pc-error-detail {{
            font-size: 14px;
            color: var(--text-secondary);
            max-width: 500px;
            line-height: 1.6;
            font-family: monospace;
            background: var(--bg-surface);
            padding: 16px;
            border-radius: var(--radius);
            border: 1px solid var(--border);
            text-align: left;
            white-space: pre-wrap;
            word-break: break-all;
        }}

/* ── SearchBar ── */
        .pc-searchbar-wrapper {{
            position: relative;
            display: flex;
            align-items: center;
            margin-bottom: 16px;
        }}

        .pc-searchbar-icon {{
            position: absolute;
            left: 12px;
            display: flex;
            align-items: center;
            color: var(--text-muted);
        }}

        .pc-searchbar-icon svg {{
            width: 16px;
            height: 16px;
            stroke: var(--text-muted);
            stroke-width: 2;
        }}

        .pc-searchbar {{
            width: 100%;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            color: var(--text-primary);
            font-size: 14px;
            padding: 9px 14px 9px 38px;
            outline: none;
            transition: border 0.15s ease;
        }}

        .pc-searchbar:focus {{ border-color: var(--primary); }}

        .pc-searchbar-clear {{
            position: absolute;
            right: 10px;
            background: none;
            border: none;
            cursor: pointer;
            color: var(--text-muted);
            display: none;
            align-items: center;
            padding: 4px;
            border-radius: var(--radius-sm);
        }}

        .pc-searchbar-clear.visible {{ display: flex; }}
        .pc-searchbar-clear:hover {{ color: var(--text-primary); }}
        .pc-searchbar-clear svg {{ width: 14px; height: 14px; stroke: currentColor; }}

        /* ── StatCard ── */
        .pc-statcard {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 20px 24px;
            display: flex;
            align-items: flex-start;
            gap: 16px;
            flex: 1;
            min-width: 180px;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }}

        .pc-statcard:hover {{
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
        }}

        .pc-statcard-icon {{
            width: 44px;
            height: 44px;
            border-radius: var(--radius);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }}

        .pc-statcard-icon svg {{
            width: 22px;
            height: 22px;
            stroke-width: 2;
        }}

        .pc-statcard-body {{ flex: 1; }}

        .pc-statcard-value {{
            font-size: 26px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1.2;
        }}

        .pc-statcard-label {{
            font-size: 13px;
            color: var(--text-secondary);
            margin-top: 4px;
        }}

        .pc-statcard-trend {{
            font-size: 12px;
            margin-top: 6px;
            display: flex;
            align-items: center;
            gap: 4px;
        }}

        .pc-statcard-trend.up   {{ color: var(--success); }}
        .pc-statcard-trend.down {{ color: var(--danger); }}

        .pc-statcard-trend svg {{
            width: 14px;
            height: 14px;
            stroke: currentColor;
            stroke-width: 2.5;
        }}

        .pc-statcards-row {{
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }}

        /* ── Toolbar ── */
        .pc-toolbar {{
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }}

        .pc-toolbar-separator {{
            width: 1px;
            height: 24px;
            background: var(--border);
            margin: 0 4px;
        }}

        .pc-toolbar .pc-btn {{
            margin-bottom: 0;
            padding: 7px 14px;
            font-size: 13px;
        }}

        /* ── Pagination ── */
        .pc-pagination {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 16px;
            border-top: 1px solid var(--border);
            background: var(--bg-surface);
            border-radius: 0 0 var(--radius-lg) var(--radius-lg);
        }}

        .pc-pagination-info {{
            font-size: 13px;
            color: var(--text-secondary);
        }}

        .pc-pagination-controls {{
            display: flex;
            align-items: center;
            gap: 4px;
        }}

        .pc-page-btn {{
            min-width: 32px;
            height: 32px;
            border: 1px solid var(--border);
            background: var(--bg-surface);
            color: var(--text-secondary);
            border-radius: var(--radius-sm);
            cursor: pointer;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.15s ease;
            padding: 0 8px;
        }}

        .pc-page-btn:hover:not(:disabled) {{
            background: var(--bg-elevated);
            color: var(--text-primary);
            border-color: var(--primary);
        }}

        .pc-page-btn.active {{
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }}

        .pc-page-btn:disabled {{
            opacity: 0.4;
            cursor: not-allowed;
        }}

        .pc-page-btn svg {{
            width: 14px;
            height: 14px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        .pc-page-size-select {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            color: var(--text-secondary);
            font-size: 13px;
            padding: 4px 8px;
            outline: none;
            cursor: pointer;
        }}

        /* ── Breadcrumb ── */
        .pc-breadcrumb {{
            display: flex;
            align-items: center;
            gap: 6px;
            margin-bottom: 16px;
            font-size: 13px;
        }}

        .pc-breadcrumb-item {{
            color: var(--text-secondary);
            cursor: pointer;
            transition: color 0.15s ease;
        }}

        .pc-breadcrumb-item:hover {{ color: var(--primary); }}

        .pc-breadcrumb-item.active {{
            color: var(--text-primary);
            font-weight: 500;
            cursor: default;
        }}

        .pc-breadcrumb-sep {{
            color: var(--text-muted);
        }}

        .pc-breadcrumb-sep svg {{
            width: 14px;
            height: 14px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        /* ── Tabs ── */
        .pc-tabs {{
            margin-bottom: 24px;
        }}

        .pc-tabs-header {{
            display: flex;
            border-bottom: 2px solid var(--border);
            gap: 0;
            margin-bottom: 20px;
        }}

        .pc-tab-btn {{
            padding: 10px 20px;
            background: none;
            border: none;
            border-bottom: 2px solid transparent;
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            margin-bottom: -2px;
            transition: all 0.15s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }}

        .pc-tab-btn:hover {{ color: var(--text-primary); }}

        .pc-tab-btn.active {{
            color: var(--primary);
            border-bottom-color: var(--primary);
        }}

        .pc-tab-btn svg {{
            width: 16px;
            height: 16px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        .pc-tab-panel {{ display: none; }}
        .pc-tab-panel.active {{ display: block; }}

        /* ── Badge ── */
        .pc-badge {{
            display: inline-flex;
            align-items: center;
            padding: 2px 8px;
            border-radius: 99px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }}

        .pc-badge-success  {{ background: rgba(16,185,129,0.15); color: var(--success); }}
        .pc-badge-danger   {{ background: rgba(239,68,68,0.15);  color: var(--danger); }}
        .pc-badge-warning  {{ background: rgba(245,158,11,0.15); color: var(--warning); }}
        .pc-badge-info     {{ background: rgba(79,70,229,0.15);  color: var(--primary); }}
        .pc-badge-muted    {{ background: var(--bg-elevated);    color: var(--text-muted); }}

        /* ── Tooltip ── */
        .pc-tooltip-wrapper {{
            position: relative;
            display: inline-flex;
        }}

        .pc-tooltip {{
            position: absolute;
            bottom: calc(100% + 8px);
            left: 50%;
            transform: translateX(-50%);
            background: #1e1e2e;
            color: #e2e8f0;
            font-size: 12px;
            padding: 6px 10px;
            border-radius: var(--radius-sm);
            white-space: nowrap;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.15s ease;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }}

        .pc-tooltip::after {{
            content: '';
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            border: 5px solid transparent;
            border-top-color: #1e1e2e;
        }}

        .pc-tooltip-wrapper:hover .pc-tooltip {{ opacity: 1; }}

        /* ── Dropdown ── */
        .pc-dropdown {{
            position: relative;
            display: inline-block;
        }}

        .pc-dropdown-menu {{
            position: absolute;
            top: calc(100% + 4px);
            left: 0;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: 0 8px 24px rgba(0,0,0,0.2);
            min-width: 180px;
            z-index: 1000;
            display: none;
            overflow: hidden;
        }}

        .pc-dropdown-menu.open {{ display: block; }}

        .pc-dropdown-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            font-size: 14px;
            color: var(--text-primary);
            cursor: pointer;
            transition: background 0.1s ease;
        }}

        .pc-dropdown-item:hover {{ background: var(--bg-elevated); }}

        .pc-dropdown-item.danger {{ color: var(--danger); }}

        .pc-dropdown-item svg {{
            width: 16px;
            height: 16px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        .pc-dropdown-divider {{
            height: 1px;
            background: var(--border);
            margin: 4px 0;
        }}

        /* ── Context Menu ── */
        .pc-context-menu {{
            position: fixed;
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: 0 8px 24px rgba(0,0,0,0.25);
            min-width: 180px;
            z-index: 9999;
            display: none;
            overflow: hidden;
            animation: pcContextIn 0.1s ease;
        }}

        .pc-context-menu.open {{ display: block; }}

        @keyframes pcContextIn {{
            from {{ opacity: 0; transform: scale(0.95); }}
            to   {{ opacity: 1; transform: scale(1); }}
        }}

        .pc-context-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            font-size: 14px;
            color: var(--text-primary);
            cursor: pointer;
            transition: background 0.1s ease;
        }}

        .pc-context-item:hover {{ background: var(--bg-elevated); }}
        .pc-context-item.danger {{ color: var(--danger); }}

        .pc-context-item svg {{
            width: 16px;
            height: 16px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        .pc-context-divider {{
            height: 1px;
            background: var(--border);
            margin: 4px 0;
        }}

        /* ── DatePicker ── */
        .pc-datepicker {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            color: var(--text-primary);
            font-size: 14px;
            padding: 9px 14px;
            width: 100%;
            outline: none;
            transition: border 0.15s ease;
            cursor: pointer;
        }}

        .pc-datepicker:focus {{ border-color: var(--primary); }}

        /* ── FileUpload ── */
        .pc-fileupload {{
            border: 2px dashed var(--border);
            border-radius: var(--radius-lg);
            padding: 32px;
            text-align: center;
            cursor: pointer;
            transition: all 0.15s ease;
            background: var(--bg-surface);
        }}

        .pc-fileupload:hover {{
            border-color: var(--primary);
            background: var(--bg-elevated);
        }}

        .pc-fileupload.dragover {{
            border-color: var(--primary);
            background: rgba(79,70,229,0.05);
        }}

        .pc-fileupload-icon {{
            margin-bottom: 12px;
            color: var(--text-muted);
        }}

        .pc-fileupload-icon svg {{
            width: 36px;
            height: 36px;
            stroke: currentColor;
            stroke-width: 1.5;
        }}

        .pc-fileupload-text {{
            font-size: 14px;
            color: var(--text-secondary);
        }}

        .pc-fileupload-hint {{
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 4px;
        }}

        /* ── Toggle ── */
        .pc-toggle-wrapper {{
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
            cursor: pointer;
        }}

        .pc-toggle {{
            position: relative;
            width: 44px;
            height: 24px;
            flex-shrink: 0;
        }}

        .pc-toggle input {{
            opacity: 0;
            width: 0;
            height: 0;
            position: absolute;
        }}

        .pc-toggle-track {{
            position: absolute;
            inset: 0;
            background: var(--border);
            border-radius: 99px;
            transition: background 0.2s ease;
            cursor: pointer;
        }}

        .pc-toggle input:checked + .pc-toggle-track {{
            background: var(--primary);
        }}

        .pc-toggle-thumb {{
            position: absolute;
            top: 3px;
            left: 3px;
            width: 18px;
            height: 18px;
            background: white;
            border-radius: 50%;
            transition: transform 0.2s ease;
            pointer-events: none;
        }}

        .pc-toggle input:checked ~ .pc-toggle-thumb {{
            transform: translateX(20px);
        }}

        .pc-toggle-label {{
            font-size: 14px;
            color: var(--text-primary);
            user-select: none;
        }}

        /* ── ProgressBar ── */
        .pc-progressbar-wrapper {{
            margin-bottom: 16px;
        }}

        .pc-progressbar-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
            font-size: 13px;
        }}

        .pc-progressbar-label {{ color: var(--text-secondary); }}
        .pc-progressbar-value {{ color: var(--text-primary); font-weight: 600; }}

        .pc-progressbar-track {{
            height: 8px;
            background: var(--bg-elevated);
            border-radius: 99px;
            overflow: hidden;
        }}

        .pc-progressbar-fill {{
            height: 100%;
            border-radius: 99px;
            background: var(--primary);
            transition: width 0.5s ease;
        }}

        .pc-progressbar-fill.success {{ background: var(--success); }}
        .pc-progressbar-fill.danger  {{ background: var(--danger); }}
        .pc-progressbar-fill.warning {{ background: var(--warning); }}

        /* ── Notification Bell ── */
        .pc-notification-bell {{
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: var(--radius);
            cursor: pointer;
            color: var(--text-secondary);
            transition: all 0.15s ease;
        }}

        .pc-notification-bell:hover {{
            background: var(--bg-elevated);
            color: var(--text-primary);
        }}

        .pc-notification-bell svg {{
            width: 20px;
            height: 20px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        .pc-notification-badge {{
            position: absolute;
            top: 4px;
            right: 4px;
            width: 16px;
            height: 16px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            font-size: 10px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--bg-primary);
        }}

        /* ── Navbar (top bar) ── */
        .pc-navbar {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            height: 56px;
            background: var(--bg-surface);
            border-bottom: 1px solid var(--border);
            flex-shrink: 0;
        }}

        .pc-navbar-brand {{
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            font-weight: 700;
            color: var(--text-primary);
        }}

        .pc-navbar-brand svg {{
            width: 24px;
            height: 24px;
            stroke: var(--primary);
            stroke-width: 2;
        }}

        .pc-navbar-actions {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}

        /* ── Sidebar brand area ── */
        .pc-sidebar-brand {{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0 12px 20px;
            margin-bottom: 8px;
            border-bottom: 1px solid var(--border);
        }}

        .pc-sidebar-brand-icon {{
            width: 32px;
            height: 32px;
            background: var(--primary);
            border-radius: var(--radius);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }}

        .pc-sidebar-brand-icon svg {{
            width: 18px;
            height: 18px;
            stroke: white;
            stroke-width: 2;
        }}

        .pc-sidebar-brand-name {{
            font-size: 15px;
            font-weight: 700;
            color: var(--text-primary);
        }}

        .pc-sidebar-brand-version {{
            font-size: 11px;
            color: var(--text-muted);
        }}

        /* ── Accordion ── */
        .pc-accordion {{
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            overflow: hidden;
            margin-bottom: 16px;
        }}

        .pc-accordion-item {{
            border-bottom: 1px solid var(--border);
        }}

        .pc-accordion-item:last-child {{ border-bottom: none; }}

        .pc-accordion-header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 20px;
            cursor: pointer;
            background: var(--bg-surface);
            font-size: 14px;
            font-weight: 500;
            color: var(--text-primary);
            transition: background 0.15s ease;
            user-select: none;
        }}

        .pc-accordion-header:hover {{ background: var(--bg-elevated); }}

        .pc-accordion-header svg {{
            width: 16px;
            height: 16px;
            stroke: var(--text-muted);
            stroke-width: 2;
            transition: transform 0.2s ease;
            flex-shrink: 0;
        }}

        .pc-accordion-item.open .pc-accordion-header svg {{
            transform: rotate(180deg);
        }}

        .pc-accordion-body {{
            display: none;
            padding: 16px 20px;
            background: var(--bg-primary);
            font-size: 14px;
            color: var(--text-secondary);
            line-height: 1.6;
        }}

        .pc-accordion-item.open .pc-accordion-body {{ display: block; }}

        /* ── Stepper ── */
        .pc-stepper {{
            display: flex;
            align-items: flex-start;
            gap: 0;
            margin-bottom: 32px;
        }}

        .pc-stepper-item {{
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
        }}

        .pc-stepper-item:not(:last-child)::after {{
            content: '';
            position: absolute;
            top: 16px;
            left: 50%;
            width: 100%;
            height: 2px;
            background: var(--border);
        }}

        .pc-stepper-item.completed:not(:last-child)::after {{
            background: var(--primary);
        }}

        .pc-stepper-circle {{
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: 2px solid var(--border);
            background: var(--bg-surface);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
            z-index: 1;
            transition: all 0.2s ease;
        }}

        .pc-stepper-item.active .pc-stepper-circle {{
            border-color: var(--primary);
            background: var(--primary);
            color: white;
        }}

        .pc-stepper-item.completed .pc-stepper-circle {{
            border-color: var(--primary);
            background: var(--primary);
            color: white;
        }}

        .pc-stepper-label {{
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 8px;
            text-align: center;
        }}

        .pc-stepper-item.active .pc-stepper-label {{
            color: var(--primary);
            font-weight: 500;
        }}

        /* ── Charts container ── */
        .pc-chart-wrapper {{
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 20px;
            margin-bottom: 16px;
        }}

        .pc-chart-title {{
            font-size: 15px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 16px;
        }}

        /* ── DataGrid inline editing ── */
        .pc-datagrid td.editable:hover {{
            background: var(--bg-elevated);
            cursor: text;
        }}

        .pc-datagrid td.editing {{
            padding: 0;
        }}

        .pc-datagrid-input {{
            width: 100%;
            height: 100%;
            background: var(--bg-surface);
            border: 2px solid var(--primary);
            color: var(--text-primary);
            font-size: 14px;
            padding: 11px 16px;
            outline: none;
        }}

        /* ── Keyboard shortcut hint ── */
        .pc-kbd {{
            display: inline-flex;
            align-items: center;
            padding: 2px 6px;
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: 11px;
            color: var(--text-muted);
            font-family: monospace;
        }}

        /* ── TopNav ── */
        .pc-topnav {{
            display: flex;
            align-items: center;
            height: 52px;
            background: var(--bg-surface);
            border-bottom: 1px solid var(--border);
            padding: 0 16px;
            gap: 4px;
            flex-shrink: 0;
            position: relative;
            z-index: 100;
        }}

        .pc-topnav-brand {{
            display: flex;
            align-items: center;
            gap: 10px;
            padding-right: 20px;
            border-right: 1px solid var(--border);
            margin-right: 8px;
            text-decoration: none;
            flex-shrink: 0;
        }}

        .pc-topnav-brand-icon {{
            width: 30px;
            height: 30px;
            background: var(--primary);
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
        }}

        .pc-topnav-brand-icon svg {{
            width: 16px;
            height: 16px;
            stroke: white;
            stroke-width: 2;
        }}

        .pc-topnav-brand-name {{
            font-size: 15px;
            font-weight: 700;
            color: var(--text-primary);
            white-space: nowrap;
        }}

        .pc-topnav-items {{
            display: flex;
            align-items: center;
            gap: 2px;
            flex: 1;
            overflow-x: auto;
            scrollbar-width: none;
        }}

        .pc-topnav-items::-webkit-scrollbar {{ display: none; }}

        .pc-topnav-item {{
            display: flex;
            align-items: center;
            gap: 7px;
            padding: 7px 14px;
            border-radius: var(--radius);
            cursor: pointer;
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
            white-space: nowrap;
            transition: all 0.15s ease;
            border: 1px solid transparent;
            position: relative;
        }}

        .pc-topnav-item:hover {{
            background: var(--bg-elevated);
            color: var(--text-primary);
        }}

        .pc-topnav-item.active {{
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }}

        .pc-topnav-item.active svg {{
            stroke: white;
        }}

        .pc-topnav-item svg {{
            width: 15px;
            height: 15px;
            stroke: currentColor;
            stroke-width: 2;
            flex-shrink: 0;
        }}

        .pc-topnav-actions {{
            display: flex;
            align-items: center;
            gap: 8px;
            margin-left: auto;
            flex-shrink: 0;
            padding-left: 16px;
            border-left: 1px solid var(--border);
        }}

        .pc-topnav-user {{
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 6px 10px;
            border-radius: var(--radius);
            cursor: pointer;
            transition: background 0.15s ease;
        }}

        .pc-topnav-user:hover {{ background: var(--bg-elevated); }}

        .pc-topnav-avatar {{
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 700;
            color: white;
            flex-shrink: 0;
        }}

        .pc-topnav-username {{
            font-size: 13px;
            font-weight: 500;
            color: var(--text-primary);
            max-width: 120px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}

        .pc-topnav-role {{
            font-size: 11px;
            color: var(--text-muted);
        }}

        /* ── Collapsible Sidebar ── */
        .pc-app-body {{
            display: flex;
            flex: 1;
            overflow: hidden;
            min-height: 0;
        }}

        .pc-collapsible-sidebar {{
            background: var(--bg-surface);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            width: 220px;
            min-width: 220px;
            transition: width 0.25s ease, min-width 0.25s ease;
            overflow: hidden;
            position: relative;
            flex-shrink: 0;
        }}

        .pc-collapsible-sidebar.collapsed {{
            width: 56px;
            min-width: 56px;
        }}

        .pc-sidebar-toggle {{
            display: flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            border-radius: var(--radius-sm);
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            cursor: pointer;
            color: var(--text-muted);
            transition: all 0.15s ease;
            flex-shrink: 0;
        }}

        .pc-sidebar-toggle:hover {{
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }}

        .pc-sidebar-toggle svg {{
            width: 14px;
            height: 14px;
            stroke: currentColor;
            stroke-width: 2;
            transition: transform 0.25s ease;
        }}

        .pc-collapsible-sidebar.collapsed .pc-sidebar-toggle svg {{
            transform: rotate(180deg);
        }}

        .pc-sidebar-header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 12px 8px;
            border-bottom: 1px solid var(--border);
            min-height: 44px;
            flex-shrink: 0;
        }}

        .pc-sidebar-section-title {{
            font-size: 11px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.08em;
            white-space: nowrap;
            overflow: hidden;
            transition: opacity 0.2s ease;
        }}

        .pc-collapsible-sidebar.collapsed .pc-sidebar-section-title {{
            opacity: 0;
            width: 0;
        }}

        .pc-sidebar-items {{
            display: flex;
            flex-direction: column;
            padding: 8px 6px;
            gap: 2px;
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
        }}

        .pc-sidebar-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 9px 10px;
            border-radius: var(--radius);
            cursor: pointer;
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
            white-space: nowrap;
            transition: all 0.15s ease;
            position: relative;
            overflow: hidden;
            text-decoration: none;
        }}

        .pc-sidebar-item:hover {{
            background: var(--bg-elevated);
            color: var(--text-primary);
        }}

        .pc-sidebar-item.active {{
            background: rgba(79,70,229,0.12);
            color: var(--primary);
        }}

        .pc-sidebar-item.active svg {{
            stroke: var(--primary);
        }}

        .pc-sidebar-item svg {{
            width: 17px;
            height: 17px;
            stroke: currentColor;
            stroke-width: 2;
            flex-shrink: 0;
        }}

        .pc-sidebar-item-label {{
            flex: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            transition: opacity 0.2s ease, width 0.25s ease;
        }}

        .pc-collapsible-sidebar.collapsed .pc-sidebar-item-label {{
            opacity: 0;
            width: 0;
            overflow: hidden;
        }}

        /* Tooltip on collapsed sidebar */
        .pc-sidebar-item .pc-sidebar-tooltip {{
            position: absolute;
            left: calc(100% + 12px);
            top: 50%;
            transform: translateY(-50%);
            background: #1e1e2e;
            color: #e2e8f0;
            font-size: 12px;
            font-weight: 500;
            padding: 6px 10px;
            border-radius: var(--radius-sm);
            white-space: nowrap;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.15s ease;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }}

        .pc-sidebar-item .pc-sidebar-tooltip::before {{
            content: '';
            position: absolute;
            right: 100%;
            top: 50%;
            transform: translateY(-50%);
            border: 5px solid transparent;
            border-right-color: #1e1e2e;
        }}

        .pc-collapsible-sidebar.collapsed .pc-sidebar-item:hover .pc-sidebar-tooltip {{
            opacity: 1;
        }}

        /* Module panels - only active module sidebar shows */
        .pc-module-sidebar {{
            display: none;
            flex-direction: column;
            height: 100%;
        }}

        .pc-module-sidebar.active {{
            display: flex;
        }}

        /* When sidebar is collapsed, ensure active module sidebar is visible */
        .pc-collapsible-sidebar.collapsed .pc-module-sidebar.active {{
            display: flex !important;
            overflow: visible !important;
        }}

        /* Ensure all parent containers allow overflow */
        .pc-collapsible-sidebar,
        .pc-collapsible-sidebar.collapsed,
        .pc-module-sidebar,
        .pc-module-sidebar.active,
        .pc-sidebar-items {{
            overflow: visible !important;
        }}

        /* Tooltip must be visible */
        .pc-collapsible-sidebar.collapsed .pc-sidebar-item:hover .pc-sidebar-tooltip {{
            opacity: 1 !important;
            display: block !important;
            visibility: visible !important;
            z-index: 99999 !important;
        }}

        /* ── StatusBar ── */
        .pc-statusbar {{
            display: flex;
            align-items: center;
            height: 26px;
            background: var(--bg-surface);
            border-top: 1px solid var(--border);
            padding: 0 12px;
            gap: 0;
            flex-shrink: 0;
            font-size: 12px;
            color: var(--text-muted);
        }}

        .pc-statusbar-item {{
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 0 10px;
            height: 100%;
            border-right: 1px solid var(--border);
            white-space: nowrap;
        }}

        .pc-statusbar-item:first-child {{
            padding-left: 0;
        }}

        .pc-statusbar-item:last-child {{
            border-right: none;
        }}

        .pc-statusbar-item svg {{
            width: 11px;
            height: 11px;
            stroke: currentColor;
            stroke-width: 2;
            flex-shrink: 0;
        }}

        .pc-statusbar-dot {{
            width: 6px;
            height: 6px;
            border-radius: 50%;
            flex-shrink: 0;
        }}

        .pc-statusbar-dot.online  {{ background: var(--success); }}
        .pc-statusbar-dot.offline {{ background: var(--danger); }}
        .pc-statusbar-dot.warning {{ background: var(--warning); }}

        .pc-statusbar-spacer {{
            flex: 1;
        }}

        .pc-statusbar-message {{
            flex: 1;
            text-align: center;
            font-style: italic;
        }}

        /* ── Full app layout ── */
        .pc-app-layout {{
            display: flex;
            flex-direction: column;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
        }}

        .pc-content-area {{
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 24px;
            background: var(--bg-primary);
        }}

        /* ── Tree Navigation ── */
        .pc-tree {{
            display: flex;
            flex-direction: column;
            gap: 1px;
            padding: 4px 0;
        }}

        .pc-tree-group {{
            display: flex;
            flex-direction: column;
        }}

        .pc-tree-group-header {{
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: var(--radius);
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            transition: all 0.15s ease;
            user-select: none;
            position: relative;
        }}

        .pc-tree-group-header:hover {{
            background: var(--bg-elevated);
            color: var(--text-primary);
        }}

        .pc-tree-group-header.active {{
            color: var(--primary);
        }}

        .pc-tree-group-icon {{
            display: flex;
            align-items: center;
            justify-content: center;
            width: 18px;
            height: 18px;
            flex-shrink: 0;
        }}

        .pc-tree-group-icon svg {{
            width: 16px;
            height: 16px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        .pc-tree-group-label {{
            flex: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}

        .pc-tree-arrow {{
            display: flex;
            align-items: center;
            justify-content: center;
            width: 16px;
            height: 16px;
            flex-shrink: 0;
            transition: transform 0.2s ease;
        }}

        .pc-tree-arrow svg {{
            width: 14px;
            height: 14px;
            stroke: var(--text-muted);
            stroke-width: 2.5;
        }}

        .pc-tree-group.open > .pc-tree-group-header .pc-tree-arrow {{
            transform: rotate(90deg);
        }}

        .pc-tree-group-badge {{
            font-size: 10px;
            font-weight: 700;
            background: var(--bg-elevated);
            color: var(--text-muted);
            padding: 1px 6px;
            border-radius: 99px;
            flex-shrink: 0;
        }}

        .pc-tree-group.open > .pc-tree-group-header .pc-tree-group-badge {{
            background: rgba(79,70,229,0.15);
            color: var(--primary);
        }}

        /* Tree children container */
        .pc-tree-children {{
            overflow: hidden;
            max-height: 0;
            transition: max-height 0.25s ease;
            padding-left: 16px;
        }}

        .pc-tree-group.open > .pc-tree-children {{
            max-height: 600px;
        }}

        /* Tree items */
        .pc-tree-item {{
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 7px 12px;
            border-radius: var(--radius);
            cursor: pointer;
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
            transition: all 0.15s ease;
            position: relative;
            text-decoration: none;
        }}

        .pc-tree-item:hover {{
            background: var(--bg-elevated);
            color: var(--text-primary);
        }}

        .pc-tree-item.active {{
            background: rgba(79,70,229,0.1);
            color: var(--primary);
            font-weight: 600;
        }}

        .pc-tree-item.active::before {{
            content: '';
            position: absolute;
            left: 0;
            top: 20%;
            bottom: 20%;
            width: 3px;
            background: var(--primary);
            border-radius: 0 3px 3px 0;
        }}

        .pc-tree-item.active svg {{
            stroke: var(--primary);
        }}

        .pc-tree-item-icon {{
            display: flex;
            align-items: center;
            justify-content: center;
            width: 16px;
            height: 16px;
            flex-shrink: 0;
        }}

        .pc-tree-item-icon svg {{
            width: 15px;
            height: 15px;
            stroke: currentColor;
            stroke-width: 2;
        }}

        .pc-tree-item-label {{
            flex: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}

        .pc-tree-item-badge {{
            font-size: 10px;
            font-weight: 700;
            background: var(--danger);
            color: white;
            padding: 1px 5px;
            border-radius: 99px;
            flex-shrink: 0;
        }}

        /* Connector line */
        .pc-tree-children {{
            border-left: 1px solid var(--border);
            margin-left: 20px;
        }}

        /* Collapsed state in sidebar */
        .pc-collapsible-sidebar.collapsed .pc-tree-group-label,
        .pc-collapsible-sidebar.collapsed .pc-tree-item-label,
        .pc-collapsible-sidebar.collapsed .pc-tree-arrow,
        .pc-collapsible-sidebar.collapsed .pc-tree-group-badge,
        .pc-collapsible-sidebar.collapsed .pc-tree-item-badge {{
            opacity: 0;
            width: 0;
            overflow: hidden;
        }}

        .pc-collapsible-sidebar.collapsed .pc-tree-children {{
            display: none;
        }}

        .pc-collapsible-sidebar.collapsed .pc-tree-group-header,
        .pc-collapsible-sidebar.collapsed .pc-tree-item {{
            justify-content: center;
            padding: 8px;
        }}

        /* Tooltip on collapsed tree items */
        .pc-collapsible-sidebar.collapsed .pc-tree-item:hover::after,
        .pc-collapsible-sidebar.collapsed .pc-tree-group-header:hover::after {{
            content: attr(data-label);
            position: absolute;
            left: calc(100% + 12px);
            top: 50%;
            transform: translateY(-50%);
            background: #1e1e2e;
            color: #e2e8f0;
            font-size: 12px;
            font-weight: 500;
            padding: 6px 10px;
            border-radius: var(--radius-sm);
            white-space: nowrap;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            text-transform: none;
            letter-spacing: normal;
        }}

        .pc-collapsible-sidebar.collapsed .pc-tree-item:hover::before {{
            content: '';
            position: absolute;
            left: calc(100% + 7px);
            top: 50%;
            transform: translateY(-50%);
            border: 5px solid transparent;
            border-right-color: #1e1e2e;
            z-index: 9999;
        }}

        /* ── Sidebar User Profile ── */
        .pc-sidebar-user {{
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px;
            border-top: 1px solid var(--border);
            margin-top: auto;
            cursor: pointer;
            transition: background 0.15s ease;
            flex-shrink: 0;
        }}

        .pc-sidebar-user:hover {{
            background: var(--bg-elevated);
        }}

        .pc-sidebar-user-avatar {{
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            font-size: 13px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }}

        .pc-sidebar-user-info {{
            flex: 1;
            overflow: hidden;
            transition: opacity 0.2s ease;
        }}

        .pc-sidebar-user-name {{
            font-size: 13px;
            font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}

        .pc-sidebar-user-role {{
            font-size: 11px;
            color: var(--text-muted);
            text-transform: capitalize;
        }}

        .pc-collapsible-sidebar.collapsed .pc-sidebar-user-info {{
            opacity: 0;
            width: 0;
            overflow: hidden;
        }}

        .pc-collapsible-sidebar.collapsed .pc-sidebar-user {{
            justify-content: center;
        }}

        /* Tooltip on collapsed user profile */
        .pc-collapsible-sidebar.collapsed .pc-sidebar-user:hover::after {{
            content: attr(data-name);
            position: absolute;
            left: calc(100% + 12px);
            top: 50%;
            transform: translateY(-50%);
            background: #1e1e2e;
            color: #e2e8f0;
            font-size: 12px;
            padding: 6px 10px;
            border-radius: var(--radius-sm);
            white-space: nowrap;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }}

        /* Module sidebar must fill height properly */
        .pc-module-sidebar {{
            display: none;
            flex-direction: column;
            flex: 1;
            min-height: 0;
            overflow: hidden;
        }}

        .pc-module-sidebar.active {{
            display: flex;
        }}

        .pc-sidebar-items {{
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 8px 6px;
            gap: 2px;
            display: flex;
            flex-direction: column;
        }}

        /* ContentArea must fill remaining space */
        .pc-content-area {{
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 24px;
            background: var(--bg-primary);
            min-height: 0;
        }}

        /* Screens hidden by default */
        .pc-screen {{
            display: none;
            width: 100%;
        }}

        .pc-screen.active {{
            display: block;
        }}
        """

    def _html_shell(self, css: str, body: str) -> str:
        themes_js = generate_runtime_theme_js(THEMES)
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PyCrome App</title>
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>{css}</style>
</head>
<body>
    <!-- ═══════════════════════════════════════════════════════════ -->
    <!-- BRIDGE - MUST BE BEFORE ANY CONTENT -->
    <!-- ═══════════════════════════════════════════════════════════ -->
    <script>
        window.pycromeCall = async function(func, ...args) {{
            const fn = func.replace(/[(][^)]*[)]/, '').trim();
            
            // Wait for API with exponential backoff
            const waitForApi = (retries = 0, maxRetries = 20) => {{
                if (window.pywebview && window.pywebview.api) {{
                    return Promise.resolve(true);
                }}
                if (retries >= maxRetries) {{
                    return Promise.reject(new Error('PyWebView API timeout after ' + (maxRetries * 100) + 'ms'));
                }}
                const delay = Math.min(100 * Math.pow(1.5, retries), 1000); // Exponential: 100, 150, 225, 337, 505, 757, 1000...
                return new Promise(resolve => {{
                    setTimeout(() => resolve(waitForApi(retries + 1, maxRetries)), delay);
                }});
            }};
            
            try {{
                await waitForApi();
                
                if (typeof window.pywebview.api[fn] === 'function') {{
                    const result = await window.pywebview.api[fn](...args);
                    if (result === null || result === undefined) return null;
                    return typeof result === 'string' ? JSON.parse(result) : result;
                }}
                console.warn('PyCrome: function not found:', fn);
            }} catch(e) {{
                console.error('PyCrome bridge error:', e);
            }}
            return null;
        }};
        console.log('✅ PyCrome Bridge registered BEFORE body');
    </script>

    {body}

    <!-- Toast Container -->
    <div class="pc-toast-container" id="pc-toast-container"></div>

    <!-- Confirmation Dialog -->
    <div class="pc-confirm-overlay" id="pc-confirm-overlay">
        <div class="pc-confirm-dialog">
            <div class="pc-confirm-icon">
                <i data-feather="alert-triangle"></i>
            </div>
            <div class="pc-confirm-title" id="pc-confirm-title">Are you sure?</div>
            <div class="pc-confirm-message" id="pc-confirm-message"></div>
            <div class="pc-confirm-actions">
                <button class="pc-btn pc-btn-primary"
                        onclick="pycromeConfirmCancel()"
                        style="background:var(--bg-elevated);color:var(--text-primary);margin-bottom:0">
                    Cancel
                </button>
                <button class="pc-btn pc-btn-danger" id="pc-confirm-ok" style="margin-bottom:0">
                    Confirm
                </button>
            </div>
        </div>
    </div>

    <script>
        // ═══════════════════════════════════════════════════════════
        // ALL FUNCTIONS DEFINED ONCE
        // ═══════════════════════════════════════════════════════════

        // All themes for runtime switching
        {themes_js}

        let pcCurrentTheme = '{self.theme_name}';
        let pcCurrentRoute = 'dashboard';
        let pcCurrentModule = '';
        let isNavigating = false;
        let pcSelectedRowData = null;
        let pcSidebarCollapsed = false;
        let pcModuleDefaults = {{}};

        // ── Storage wrapper ──
        const storage = {{
            getItem: function(key) {{
                try {{ return localStorage.getItem(key); }}
                catch(e) {{ return this._memory[key] || null; }}
            }},
            setItem: function(key, value) {{
                try {{ localStorage.setItem(key, value); }}
                catch(e) {{ this._memory[key] = value; }}
            }},
            _memory: {{}}
        }};

        // ── Feather Icons ──
        function initFeatherIcons() {{
            if (typeof feather !== 'undefined') {{
                feather.replace({{ width: 18, height: 18, 'stroke-width': 2 }});
            }}
        }}

        // ── Theme System ──
        function pycromeSetTheme(themeName) {{
            const theme = PYCROME_THEMES[themeName];
            if (!theme) return;
            const root = document.documentElement;
            Object.entries(theme).forEach(([key, value]) => {{
                root.style.setProperty(key, value);
            }});
            pcCurrentTheme = themeName;
            document.querySelectorAll('.pc-theme-dot').forEach(dot => {{
                dot.classList.toggle('active', dot.dataset.theme === themeName);
            }});
            storage.setItem('pycrome_theme', themeName);
            initFeatherIcons();
        }}

        // ── Module Switching ──
        function pycromeSwitchModule(moduleName) {{
            if (pcCurrentModule === moduleName) return;
            pcCurrentModule = moduleName;

            document.querySelectorAll('.pc-topnav-item').forEach(item => {{
                item.classList.toggle('active', item.id === 'topnav_' + moduleName);
            }});

            document.querySelectorAll('.pc-module-sidebar').forEach(panel => {{
                panel.classList.toggle('active', panel.dataset.module === moduleName);
            }});

            const firstItem = document.querySelector(
                '.pc-sidebar-item[data-module="' + moduleName + '"]'
            );
            
            if (firstItem && firstItem.dataset.route) {{
                navigateTo(firstItem.dataset.route);
                updateSidebarActive(firstItem.dataset.route);
            }}

            storage.setItem('pycrome_module', moduleName);
            if (typeof initFeatherIcons === 'function') initFeatherIcons();
        }}

        function pycromeRegisterModuleDefault(module, route) {{
            pcModuleDefaults[module] = route;
        }}

        // ── Navigation ──
        function navigateTo(route) {{
            if (isNavigating) return;
            isNavigating = true;

            document.querySelectorAll('.pc-screen').forEach(screen => {{
                screen.classList.remove('active');
            }});

            const targetScreen = document.getElementById(`screen-${{route}}`);
            if (targetScreen) {{
                targetScreen.classList.add('active');
                pcCurrentRoute = route;
                const newHash = `#${{route}}`;
                if (window.location.hash !== newHash) {{
                    history.pushState(null, null, newHash);
                }}
                updateActiveNavItem(route);
                updateSidebarActive(route);
                pycromeSetTreeActive(route);
                pycromeSetStatus('Ready');
                setTimeout(initColumnResizing, 50);
            }}

            isNavigating = false;
        }}

        function pycromeNavigate(route) {{ navigateTo(route); }}
        function navigate(route) {{ navigateTo(route); }}

        function updateActiveNavItem(route) {{
            document.querySelectorAll('.pc-navitem').forEach(item => {{
                const onclick = item.getAttribute('onclick') || '';
                item.classList.toggle('active', onclick.includes(`'${{route}}'`));
            }});
        }}

        function updateSidebarActive(route) {{
            document.querySelectorAll('.pc-sidebar-item').forEach(item => {{
                item.classList.toggle('active', item.dataset.route === route);
            }});
        }}

        function initNavigation() {{
            const defaultScreen = document.querySelector('.pc-screen-default');
            const firstScreen   = document.querySelector('.pc-screen');
            let initialRoute    = 'dashboard';
            if (defaultScreen) initialRoute = defaultScreen.id.replace('screen-', '');
            else if (firstScreen) initialRoute = firstScreen.id.replace('screen-', '');
            const hash = window.location.hash.slice(1);
            navigateTo(hash || initialRoute);
        }}

        // ── Tree Navigation ──
        function pycromeToggleTreeGroup(groupId) {{
            const group = document.getElementById(groupId);
            if (!group) return;
            group.classList.toggle('open');
            initFeatherIcons();
        }}

        function pycromeOpenTreeGroup(groupId) {{
            const group = document.getElementById(groupId);
            if (group) {{
                group.classList.add('open');
                initFeatherIcons();
            }}
        }}

        function pycromeCloseTreeGroup(groupId) {{
            const group = document.getElementById(groupId);
            if (group) group.classList.remove('open');
        }}

        function pycromeSetTreeActive(route) {{
            document.querySelectorAll('.pc-tree-item').forEach(item => {{
                item.classList.remove('active');
            }});

            const target = document.querySelector(
                `.pc-tree-item[data-route="${{route}}"]`
            );
            if (target) {{
                target.classList.add('active');
                const parentGroup = target.closest('.pc-tree-group');
                if (parentGroup && !parentGroup.classList.contains('open')) {{
                    parentGroup.classList.add('open');
                    initFeatherIcons();
                }}
            }}
        }}

        // ── Column Resizing ──
        function initColumnResizing() {{
            document.querySelectorAll('.pc-table th').forEach(header => {{
                if (header.dataset.resizeInitialized) return;
                header.dataset.resizeInitialized = 'true';

                let isResizing = false, startX, startWidth;

                header.addEventListener('mousedown', function(e) {{
                    const rect = header.getBoundingClientRect();
                    if (rect.right - e.clientX < 10) {{
                        isResizing = true;
                        startX     = e.clientX;
                        startWidth = header.offsetWidth;

                        const onMouseMove = (e) => {{
                            if (!isResizing) return;
                            const width = Math.max(50, startWidth + (e.clientX - startX));
                            header.style.width    = width + 'px';
                            header.style.minWidth = width + 'px';
                        }};

                        const onMouseUp = () => {{
                            isResizing = false;
                            document.removeEventListener('mousemove', onMouseMove);
                            document.removeEventListener('mouseup',   onMouseUp);
                        }};

                        document.addEventListener('mousemove', onMouseMove);
                        document.addEventListener('mouseup',   onMouseUp);
                        e.preventDefault();
                    }}
                }});
            }});
        }}

        // ── Row Click (Single = select, Double = edit) ──
        let pcRowClickTimer = null;
        let pcLastClickedRow = null;

        function pycromeHandleRowClick(tableId, row, funcName) {{
            if (event) event.stopPropagation();
            
            if (pcRowClickTimer) {{
                clearTimeout(pcRowClickTimer);
                pcRowClickTimer = null;
            }}
            
            let rowData = null;
            try {{
                const encodedData = row.dataset.rowData;
                if (encodedData) {{
                    rowData = JSON.parse(encodedData.replace(/&quot;/g, '"'));
                }}
            }} catch(e) {{
                console.error('Failed to parse row data:', e);
                return false;
            }}
            
            const isDoubleClick = (pcLastClickedRow === row);
            
            if (isDoubleClick) {{
                pcLastClickedRow = null;
                
                const table = document.getElementById(tableId);
                if (table) {{
                    table.querySelectorAll('tbody tr').forEach(tr => {{
                        tr.classList.remove('selected');
                    }});
                }}
                row.classList.add('selected');
                pcSelectedRowData = rowData;
                
                const editOverlay = document.querySelector('.pc-modal-overlay[id*="edit"]');
                
                if (editOverlay) {{
                    const modalId = editOverlay.id.replace('modal-', '').replace('-overlay', '');
                    pycromePopulateModal(modalId, rowData);
                    pycromeOpenModal(modalId);
                }} else {{
                    toast.warning('Edit modal not found.');
                }}
            }} else {{
                pcLastClickedRow = row;
                
                pcRowClickTimer = setTimeout(() => {{
                    pcLastClickedRow = null;
                    pcRowClickTimer = null;
                }}, 300);
                
                const table = document.getElementById(tableId);
                if (table) {{
                    table.querySelectorAll('tbody tr').forEach(tr => {{
                        tr.classList.remove('selected');
                    }});
                }}
                row.classList.add('selected');
                pcSelectedRowData = rowData;
            }}
            
            return false;
        }}

        function pycromePopulateModal(modalId, data) {{
            const overlay = document.getElementById(`modal-${{modalId}}-overlay`);
            if (!overlay) return;
            
            if (!data) return;
            
            const fields = overlay.querySelectorAll('input, select, textarea');
            
            fields.forEach(field => {{
                const fieldName = field.name || field.id;
                
                let value = null;
                
                if (data[fieldName] !== undefined) {{
                    value = data[fieldName];
                }} else if (fieldName.startsWith('edit_')) {{
                    const baseName = fieldName.replace('edit_', '');
                    if (data[baseName] !== undefined) {{
                        value = data[baseName];
                    }}
                }} else if (data['student_' + fieldName] !== undefined) {{
                    value = data['student_' + fieldName];
                }} else {{
                    const lowerFieldName = fieldName.toLowerCase();
                    for (const [key, val] of Object.entries(data)) {{
                        if (key.toLowerCase() === lowerFieldName || 
                            key.toLowerCase().replace('student_', '') === lowerFieldName ||
                            key.toLowerCase().replace('edit_', '') === lowerFieldName) {{
                            value = val;
                            break;
                        }}
                    }}
                }}
                
                if (value !== null && value !== undefined) {{
                    field.value = value;
                }}
            }});
        }}

        // ── Modal System ──
        function pycromeOpenModal(modalId) {{
            const overlay = document.getElementById(`modal-${{modalId}}-overlay`);
            if (overlay) {{
                overlay.classList.add('active');
                setTimeout(() => {{
                    const firstInput = overlay.querySelector('input:not([readonly]), select, textarea');
                    if (firstInput) firstInput.focus();
                }}, 100);
                initFeatherIcons();
            }}
        }}

        function pycromeCloseModal(modalId) {{
            const overlay = document.getElementById(`modal-${{modalId}}-overlay`);
            if (overlay) {{
                overlay.classList.remove('active');
                const form = overlay.querySelector('form');
                if (form) {{
                    form.reset();
                    form.querySelectorAll('.pc-form-field').forEach(f => {{
                        f.classList.remove('has-error');
                    }});
                    form.querySelectorAll('.pc-field-error').forEach(e => {{
                        e.classList.remove('visible');
                    }});
                }}
            }}
        }}

        function pycromeDeleteStudent() {{
            pycromeConfirm(
                'This will permanently delete this student record. This cannot be undone.',
                function() {{
                    const data = pcSelectedRowData || {{}};
                    pycromeCall('delete_student', data).then(result => {{
                        if (result && result.success) {{
                            pycromeCloseModal('edit-student');
                            toast.success(result.message || 'Student deleted successfully.');
                            pcSelectedRowData = null;
                        }} else {{
                            toast.error(result ? result.message : 'Delete failed.');
                        }}
                    }});
                }},
                'Delete Student'
            );
        }}

        // Close modal on overlay click
        document.addEventListener('click', function(e) {{
            if (e.target.classList.contains('pc-modal-overlay')) {{
                const modalId = e.target.id.replace('modal-', '').replace('-overlay', '');
                pycromeCloseModal(modalId);
            }}
        }});

        // Close modal on Escape
        document.addEventListener('keydown', function(e) {{
            if (e.key === 'Escape') {{
                const visibleModal = document.querySelector('.pc-modal-overlay.active');
                if (visibleModal) {{
                    const modalId = visibleModal.id.replace('modal-', '').replace('-overlay', '');
                    pycromeCloseModal(modalId);
                }}
            }}
        }});

        // ── Toast System ──
        const TOAST_ICONS = {{
            success: 'check-circle',
            error:   'alert-circle',
            warning: 'alert-triangle',
            info:    'info'
        }};

        let toastCounter = 0;

        function pycromeToast(message, type = 'info', duration = 4000) {{
            const container = document.getElementById('pc-toast-container');
            if (!container) return;

            const id   = 'toast-' + (++toastCounter);
            const icon = TOAST_ICONS[type] || 'info';

            const toast = document.createElement('div');
            toast.className = `pc-toast pc-toast-${{type}}`;
            toast.id        = id;
            toast.innerHTML = `
                <span class="pc-toast-icon"><i data-feather="${{icon}}"></i></span>
                <span class="pc-toast-message">${{message}}</span>
                <button class="pc-toast-close" onclick="pycromeRemoveToast('${{id}}')">
                    <i data-feather="x"></i>
                </button>
            `;

            toast.onclick = function(e) {{
                if (!e.target.closest('.pc-toast-close')) {{
                    pycromeRemoveToast(id);
                }}
            }};

            container.appendChild(toast);
            initFeatherIcons();

            if (duration > 0) {{
                setTimeout(() => pycromeRemoveToast(id), duration);
            }}

            return id;
        }}

        function pycromeRemoveToast(id) {{
            const toast = document.getElementById(id);
            if (!toast) return;
            toast.classList.add('hiding');
            setTimeout(() => toast.remove(), 300);
        }}

        const toast = {{
            success: (msg, dur) => pycromeToast(msg, 'success', dur),
            error:   (msg, dur) => pycromeToast(msg, 'error',   dur || 6000),
            warning: (msg, dur) => pycromeToast(msg, 'warning', dur),
            info:    (msg, dur) => pycromeToast(msg, 'info',    dur),
        }};

        // ── Loading States ──
        function pycromeSetLoading(elementId, isLoading, message = 'Loading...') {{
            const el = document.getElementById(elementId);
            if (!el) return;
            if (isLoading) {{
                el.dataset.originalHtml = el.innerHTML;
                el.innerHTML = `
                    <div class="pc-loading-row">
                        <div class="pc-spinner"></div>
                        <span>${{message}}</span>
                    </div>`;
            }} else {{
                if (el.dataset.originalHtml !== undefined) {{
                    el.innerHTML = el.dataset.originalHtml;
                    delete el.dataset.originalHtml;
                }}
            }}
        }}

        function pycromeSetButtonLoading(btn, isLoading, loadingText = 'Please wait...') {{
            if (!btn) return;
            if (isLoading) {{
                btn.dataset.originalText = btn.innerHTML;
                btn.disabled = true;
                btn.innerHTML = `<div class="pc-spinner" style="width:16px;height:16px;border-width:2px;margin-right:8px"></div>${{loadingText}}`;
            }} else {{
                btn.disabled  = false;
                btn.innerHTML = btn.dataset.originalText || btn.innerHTML;
                initFeatherIcons();
            }}
        }}

        // ── Confirmation Dialog ──
        let confirmCallback = null;

        function pycromeConfirm(message, onConfirm, title = 'Are you sure?') {{
            document.getElementById('pc-confirm-title').textContent   = title;
            document.getElementById('pc-confirm-message').textContent = message;
            document.getElementById('pc-confirm-overlay').classList.add('active');
            confirmCallback = onConfirm;
            initFeatherIcons();
        }}

        function pycromeConfirmCancel() {{
            document.getElementById('pc-confirm-overlay').classList.remove('active');
            confirmCallback = null;
        }}

        document.getElementById('pc-confirm-ok').addEventListener('click', function() {{
            document.getElementById('pc-confirm-overlay').classList.remove('active');
            if (typeof confirmCallback === 'function') confirmCallback();
            confirmCallback = null;
        }});

        // ── Form Validation ──
        function pycromeValidateForm(formEl) {{
            let valid = true;

            formEl.querySelectorAll('.pc-form-field').forEach(field => {{
                field.classList.remove('has-error');
                const errorEl = field.querySelector('.pc-field-error');
                if (errorEl) errorEl.classList.remove('visible');
            }});

            formEl.querySelectorAll('input[required], select[required], textarea[required]').forEach(input => {{
                const field = input.closest('.pc-form-field');

                const addError = (msg) => {{
                    valid = false;
                    if (!field) return;
                    field.classList.add('has-error');
                    let errorEl = field.querySelector('.pc-field-error');
                    if (!errorEl) {{
                        errorEl = document.createElement('span');
                        errorEl.className = 'pc-field-error';
                        field.appendChild(errorEl);
                    }}
                    errorEl.textContent = msg;
                    errorEl.classList.add('visible');
                }};

                if (!input.value.trim()) {{
                    addError('This field is required');
                    return;
                }}

                if (input.type === 'email' && !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(input.value)) {{
                    addError('Enter a valid email address');
                    return;
                }}

                if (input.type === 'number' && isNaN(Number(input.value))) {{
                    addError('Enter a valid number');
                }}
            }});

            return valid;
        }}

        // ── Form Submit ──
        function pycromeHandleSubmit(event, funcName) {{
            event.preventDefault();
            const form = event.target;

            if (!pycromeValidateForm(form)) {{
                toast.warning('Please fill in all required fields.');
                return false;
            }}

            const btn = form.querySelector('button[type="submit"]');
            if (btn) pycromeSetButtonLoading(btn, true);

            const formData = {{}};
            form.querySelectorAll('input, select, textarea').forEach(field => {{
                if (field.name) formData[field.name] = field.value;
            }});

            if (funcName) {{
                pycromeCall(funcName, formData)
                    .then(result => {{
                        if (btn) pycromeSetButtonLoading(btn, false);

                        if (result && result.success) {{
                            toast.success(result.message || 'Saved successfully.');
                            const modal = form.closest('.pc-modal-overlay');
                            if (modal) {{
                                const modalId = modal.id
                                    .replace('modal-', '')
                                    .replace('-overlay', '');
                                pycromeCloseModal(modalId);
                            }}
                            if (result.refresh) location.reload();
                            if (result.reload_table) {{
                                const tbody = document.getElementById(result.reload_table + '_body');
                                if (tbody) {{
                                    tbody.innerHTML = `
                                        <tr><td colspan="20">
                                            <div class="pc-loading-row">
                                                <div class="pc-spinner"></div>
                                                <span>Refreshing...</span>
                                            </div>
                                        </td></tr>`;
                                }}
                            }}
                        }} else {{
                            toast.error(result?.message || 'Something went wrong.');
                        }}
                    }})
                    .catch(err => {{
                        if (btn) pycromeSetButtonLoading(btn, false);
                        toast.error('Request failed. Please try again.');
                        console.error('Submit error:', err);
                    }});
            }}

            return false;
        }}

        // ── Table Filter (SearchBar) ──
        function pycromeFilterTable(tableId, query) {{
            const tbody = document.getElementById(tableId + '_body');
            if (!tbody) return;
            const q = query.toLowerCase().trim();
            tbody.querySelectorAll('tr').forEach(row => {{
                const text = row.textContent.toLowerCase();
                row.style.display = (!q || text.includes(q)) ? '' : 'none';
            }});
        }}

        // ── Tabs ──
        function pycromeSwitchTab(tabsId, tabId, btn) {{
            const container = document.getElementById(tabsId);
            if (!container) return;
            container.querySelectorAll('.pc-tab-btn').forEach(b => b.classList.remove('active'));
            container.querySelectorAll('.pc-tab-panel').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            const panel = document.getElementById(tabsId + '_' + tabId);
            if (panel) panel.classList.add('active');
        }}

        // ── Dropdown ──
        function pycromeToggleDropdown(id) {{
            const menu = document.getElementById(id + '_menu');
            if (menu) menu.classList.toggle('open');
        }}

        function pycromeCloseDropdown(id) {{
            const menu = document.getElementById(id + '_menu');
            if (menu) menu.classList.remove('open');
        }}

        document.addEventListener('click', function(e) {{
            if (!e.target.closest('.pc-dropdown')) {{
                document.querySelectorAll('.pc-dropdown-menu.open').forEach(m => {{
                    m.classList.remove('open');
                }});
            }}
        }});

        // ── Context Menu ──
        function pycromeShowContext(menuId, x, y) {{
            pycromeCloseContext();
            const menu = document.getElementById(menuId);
            if (!menu) return;
            menu.style.left = x + 'px';
            menu.style.top  = y + 'px';
            menu.classList.add('open');
            initFeatherIcons();
        }}

        function pycromeCloseContext() {{
            document.querySelectorAll('.pc-context-menu.open').forEach(m => {{
                m.classList.remove('open');
            }});
        }}

        document.addEventListener('click', function(e) {{
            if (!e.target.closest('.pc-context-menu')) pycromeCloseContext();
        }});

        document.addEventListener('contextmenu', function(e) {{
            if (!e.target.closest('[data-context-menu]')) pycromeCloseContext();
        }});

        // ── File Upload ──
        function pycromeHandleFileSelect(input, id) {{
            if (input.files && input.files[0]) {{
                const file = input.files[0];
                const dropzone = document.getElementById(id + '_dropzone');
                if (dropzone) {{
                    dropzone.querySelector('.pc-fileupload-text').textContent = file.name;
                    dropzone.querySelector('.pc-fileupload-hint').textContent =
                        (file.size / 1024).toFixed(1) + ' KB';
                }}
            }}
        }}

        function pycromeHandleFileDrop(event, id) {{
            const file = event.dataTransfer.files[0];
            if (file) {{
                const input = document.getElementById(id);
                if (input) {{
                    const dt = new DataTransfer();
                    dt.items.add(file);
                    input.files = dt.files;
                    pycromeHandleFileSelect(input, id);
                }}
            }}
        }}

        // ── DataGrid inline edit ──
        function pycromeGridEdit(cell, gridId, rowIndex, field) {{
            if (cell.classList.contains('editing')) return;
            const current = cell.dataset.value || cell.textContent;
            cell.classList.add('editing');
            cell.innerHTML = `<input class="pc-datagrid-input" value="${{current}}"
                onblur="pycromeGridSave(this, '${{gridId}}', ${{rowIndex}}, '${{field}}')"
                onkeydown="if(event.key==='Enter') this.blur(); if(event.key==='Escape') pycromeGridCancel(this, '${{current}}')">`;
            cell.querySelector('input').focus();
        }}

        function pycromeGridSave(input, gridId, rowIndex, field) {{
            const cell  = input.parentElement;
            const value = input.value;
            cell.classList.remove('editing');
            cell.dataset.value = value;
            cell.textContent   = value;
        }}

        function pycromeGridCancel(input, original) {{
            const cell = input.parentElement;
            cell.classList.remove('editing');
            cell.textContent = original;
        }}

        // ── Charts (Chart.js) - WITH RETRY LOGIC ──
        function pycromeRenderChart(canvasId, type, data, retries = 0) {{
            const canvas = document.getElementById(canvasId);
            if (!canvas) {{
                console.warn(`Canvas not found: ${{canvasId}}, retrying...`);
                if (retries < 10) {{
                    setTimeout(() => pycromeRenderChart(canvasId, type, data, retries + 1), 500);
                }}
                return;
            }}
            
            if (typeof Chart === 'undefined') {{
                console.warn(`Chart.js not loaded yet for ${{canvasId}}, retrying...`);
                if (retries < 10) {{
                    setTimeout(() => pycromeRenderChart(canvasId, type, data, retries + 1), 500);
                }}
                return;
            }}
            
            try {{
                // Destroy existing chart if it exists
                if (canvas.chart) {{
                    canvas.chart.destroy();
                }}
                
                canvas.chart = new Chart(canvas, {{
                    type: type,
                    data: {{
                        labels: data.labels || [],
                        datasets: (data.datasets || []).map(ds => ({{
                            ...ds,
                            backgroundColor: ds.backgroundColor || 'rgba(79,70,229,0.5)',
                            borderColor: ds.borderColor || 'rgba(79,70,229,1)',
                            borderWidth: 2,
                        }}))
                    }},
                    options: {{
                        responsive: true,
                        maintainAspectRatio: true,
                        plugins: {{
                            legend: {{
                                labels: {{ 
                                    color: getComputedStyle(document.documentElement)
                                        .getPropertyValue('--text-primary') || '#333' 
                                }}
                            }}
                        }},
                        scales: type !== 'pie' && type !== 'doughnut' && type !== 'polarArea' ? {{
                            x: {{ 
                                ticks: {{ color: 'var(--text-secondary)' }},
                                grid: {{ color: 'var(--border)' }} 
                            }},
                            y: {{ 
                                ticks: {{ color: 'var(--text-secondary)' }},
                                grid: {{ color: 'var(--border)' }} 
                            }}
                        }} : {{}}
                    }}
                }});
                console.log(`Chart rendered successfully: ${{canvasId}}`);
            }} catch(e) {{
                console.error('Chart creation error:', e);
            }}
        }}

        // ── Collapsible Sidebar ──
        function pycromeToggleSidebar() {{
            const sidebar = document.getElementById('pc_collapsible_sidebar');
            if (!sidebar) return;

            pcSidebarCollapsed = !pcSidebarCollapsed;
            sidebar.classList.toggle('collapsed', pcSidebarCollapsed);
            storage.setItem('pycrome_sidebar_collapsed', pcSidebarCollapsed ? '1' : '0');
            initFeatherIcons();
        }}

        function pycromeSetSidebarCollapsed(collapsed) {{
            const sidebar = document.getElementById('pc_collapsible_sidebar');
            if (!sidebar) return;
            pcSidebarCollapsed = collapsed;
            sidebar.classList.toggle('collapsed', collapsed);
        }}

        // ── StatusBar ──
        function pycromeSetStatus(message, duration = 5000) {{
            const bar = document.getElementById('pc_statusbar_message');
            if (bar) {{
                bar.textContent = message;
                if (duration > 0) {{
                    setTimeout(() => {{ bar.textContent = 'Ready'; }}, duration);
                }}
            }}
        }}

        function pycromeUpdateStatusItem(id, text, dot) {{
            const item = document.getElementById(id);
            if (!item) return;
            const span = item.querySelector('span:last-child');
            if (span && text !== undefined) span.textContent = text;
            const dotEl = item.querySelector('.pc-statusbar-dot');
            if (dotEl && dot !== undefined) {{
                dotEl.className = 'pc-statusbar-dot ' + dot;
            }}
        }}

        // ── Clock ──
        function pycromeStartClock() {{
            function tick() {{
                const now   = new Date();
                const hh    = String(now.getHours()).padStart(2, '0');
                const mm    = String(now.getMinutes()).padStart(2, '0');
                const ss    = String(now.getSeconds()).padStart(2, '0');
                const dd    = String(now.getDate()).padStart(2, '0');
                const mo    = String(now.getMonth() + 1).padStart(2, '0');
                const yyyy  = now.getFullYear();
                const clock = document.getElementById('pc_clock');
                if (clock) clock.textContent = `${{dd}}/${{mo}}/${{yyyy}} ${{hh}}:${{mm}}:${{ss}}`;
            }}
            tick();
            setInterval(tick, 1000);
        }}

        // ── TopNav user display ──
        function pycromeSetTopNavUser(fullName, role) {{
            const usernameEl = document.getElementById('pc_topnav_username');
            const roleEl     = document.getElementById('pc_topnav_role');
            const avatarEl   = document.getElementById('pc_topnav_avatar');

            if (usernameEl) usernameEl.textContent = fullName || '';
            if (roleEl)     roleEl.textContent     = role || '';
            if (avatarEl)   avatarEl.textContent   = (fullName || 'U')[0].toUpperCase();
        }}

        // ── Table Data Loader ──
        async function loadTableData(tableId, source) {{
            if (!source) return;
            const funcName = source.replace(/[()]/g, '').trim();
            try {{
                const data = await pycromeCall(funcName);
                if (data && Array.isArray(data)) {{
                    const tbody = document.getElementById(tableId + '_body');
                    const table = document.getElementById(tableId);
                    if (tbody && table) {{
                        const headers = Array.from(table.querySelectorAll('th')).map(th => 
                            th.getAttribute('data-field') || th.textContent.toLowerCase().replace(/\\s+/g, '_')
                        );
                        if (data.length === 0) {{
                            tbody.innerHTML = `<tr><td colspan="${{headers.length || 1}}" class="pc-empty">No records found</td></tr>`;
                        }} else {{
                            tbody.innerHTML = data.map(row => 
                                `<tr>${{headers.map(f => `<td>${{row[f] !== undefined ? row[f] : ''}}</td>`).join('')}}</tr>`
                            ).join('');
                        }}
                    }}
                }}
            }} catch (e) {{
                console.error('Table load error:', e);
            }}
        }}

        function initTables() {{
            document.querySelectorAll('.pc-table').forEach(table => {{
                const source = table.getAttribute('data-source') || table.getAttribute('source');
                if (source) {{
                    loadTableData(table.id, source);
                }}
            }});
        }}

        // ── Keyboard Shortcuts ──
        document.addEventListener('keydown', function(e) {{
            const ctrl = e.ctrlKey || e.metaKey;
            if (ctrl && e.key === 'f') {{
                e.preventDefault();
                const search = document.querySelector('.pc-searchbar');
                if (search) {{ search.focus(); search.select(); }}
            }}
            if (ctrl && e.key === 'n') {{
                e.preventDefault();
                const addBtn = document.querySelector('.pc-btn-primary');
                if (addBtn) addBtn.click();
            }}
            if (e.key === 'Escape') {{
                const visibleModal = document.querySelector('.pc-modal-overlay.active');
                if (visibleModal) {{
                    const modalId = visibleModal.id.replace('modal-', '').replace('-overlay', '');
                    pycromeCloseModal(modalId);
                }}
                document.querySelectorAll('.pc-dropdown-menu.open, .pc-context-menu.open').forEach(m => {{
                    m.classList.remove('open');
                }});
            }}
        }});

        // ── Mutation Observer ──
        const observer = new MutationObserver(function(mutations) {{
            mutations.forEach(function(mutation) {{
                if (mutation.addedNodes.length) initFeatherIcons();
            }});
        }});
        observer.observe(document.body, {{ childList: true, subtree: true }});

        // ═══════════════════════════════════════════════════════════
        // CORE API FUNCTION
        // ═══════════════════════════════════════════════════════════
        window.pycromeCall = async function(func, ...args) {{
            const fn = func.replace(/[(][^)]*[)]/, '').trim();
            
            // Wait for API with retries
            for (let retries = 0; retries < 30; retries++) {{
                if (window.pywebview && window.pywebview.api) {{
                    break;
                }}
                await new Promise(r => setTimeout(r, 100));
            }}
            
            if (!window.pywebview || !window.pywebview.api) {{
                console.error('API not available after waiting');
                return null;
            }}
            
            try {{
                if (typeof window.pywebview.api[fn] === 'function') {{
                    const result = await window.pywebview.api[fn](...args);
                    return result === null || result === undefined ? null : 
                           typeof result === 'string' ? JSON.parse(result) : result;
                }}
                console.warn('Function not found:', fn);
            }} catch(e) {{
                console.error('Bridge error:', e);
            }}
            return null;
        }};

        // ═══════════════════════════════════════════════════════════
        // TABLE LOADER
        // ═══════════════════════════════════════════════════════════
        async function initTables() {{
            const tables = document.querySelectorAll('.pc-table[data-source]');
            console.log('Loading ' + tables.length + ' tables');
            
            for (const table of tables) {{
                const source = table.getAttribute('data-source');
                if (!source) continue;
                
                const funcName = source.replace(/[()]/g, '').trim();
                const tbody = document.getElementById(table.id + '_body');
                if (!tbody) continue;
                
                try {{
                    tbody.innerHTML = '<tr><td colspan="20"><div class="pc-loading-row"><div class="pc-spinner"></div><span>Loading...</span></div></td></tr>';
                    const data = await window.pycromeCall(funcName);
                    
                    if (data && Array.isArray(data)) {{
                        const headers = Array.from(table.querySelectorAll('th')).map(th => 
                            th.getAttribute('data-field') || th.textContent.toLowerCase().replace(/\\s+/g, '_')
                        );
                        
                        if (data.length === 0) {{
                            tbody.innerHTML = '<tr><td colspan="' + (headers.length || 1) + '" class="pc-empty">No records found</td></tr>';
                        }} else {{
                            let html = '';
                            for (const row of data) {{
                                html += '<tr>';
                                for (const h of headers) {{
                                    const val = row[h] !== undefined && row[h] !== null ? row[h] : '';
                                    html += '<td>' + val + '</td>';
                                }}
                                html += '</tr>';
                            }}
                            tbody.innerHTML = html;
                        }}
                        console.log('Loaded ' + table.id + ': ' + data.length + ' rows');
                    }}
                }} catch(e) {{
                    console.error('Failed to load ' + table.id, e);
                    tbody.innerHTML = '<tr><td colspan="20" class="pc-empty error">Failed to load data</td></tr>';
                }}
            }}
        }}

        // ═══════════════════════════════════════════════════════════
        // MAIN INITIALIZATION
        // ═══════════════════════════════════════════════════════════
        async function initializeApp() {{
            console.log('Initializing app...');
            
            // Wait for API
            while (!window.pywebview || !window.pywebview.api) {{
                await new Promise(r => setTimeout(r, 50));
            }}
            
            console.log('API ready');
            
            // Restore sidebar state
            const savedCollapsed = storage.getItem('pycrome_sidebar_collapsed');
            if (savedCollapsed === '1') {{
                const sidebar = document.getElementById('pc_collapsible_sidebar');
                if (sidebar) sidebar.classList.add('collapsed');
            }}
            
            // Restore theme
            const savedTheme = storage.getItem('pycrome_theme');
            if (savedTheme) pycromeSetTheme(savedTheme);
            
            // Start clock
            pycromeStartClock();
            
            // Load user info
            if (window.pywebview.api.get_session_info) {{
                try {{
                    const info = await window.pywebview.api.get_session_info();
                    if (info) {{
                        const usernameEl = document.getElementById('pc_topnav_username');
                        const roleEl = document.getElementById('pc_topnav_role');
                        const avatarEl = document.getElementById('pc_topnav_avatar');
                        if (usernameEl) usernameEl.textContent = info.full_name || '';
                        if (roleEl) roleEl.textContent = info.role || '';
                        if (avatarEl) avatarEl.textContent = (info.full_name || 'U')[0].toUpperCase();
                    }}
                }} catch(e) {{
                    console.warn('Session info failed:', e);
                }}
            }}
            
            // Initialize navigation
            initNavigation();
            
            // Load tables
            await initTables();
            
            // Restore module
            const savedModule = storage.getItem('pycrome_module');
            if (savedModule) {{
                pycromeSwitchModule(savedModule);
            }}
            
            console.log('App ready');
        }}

        // Expose globals
        window.pycromeRenderChart = pycromeRenderChart;
        window.pycromeSwitchModule = pycromeSwitchModule;
        window.initTables = initTables;
        
        // Start the app
        if (document.readyState === 'loading') {{
            document.addEventListener('DOMContentLoaded', () => initializeApp());
        }} else {{
            initializeApp();
        }}
    </script>
</body>
</html>"""

    def _render_modal(self, node: UINode) -> str:
        """Render a modal dialog."""
        modal_id = node.attrs.get("id", "pc_modal")
        title = node.attrs.get("title", "Modal")
        width = node.attrs.get("width", "500")
        show_close = node.attrs.get("show_close", "true").lower() == "true"
        
        children_html = "".join(self._render_node(c) for c in node.children)
        
        close_button = ""
        if show_close:
            close_button = f'<button class="pc-modal-close" onclick="pycromeCloseModal(\'{modal_id}\')">{self._icon("close")}</button>'
        
        return f"""
        <div class="pc-modal-overlay" id="modal-{modal_id}-overlay">
            <div class="pc-modal" id="modal-{modal_id}" style="max-width: {width}px;">
                <div class="pc-modal-header">
                    <h3 class="pc-modal-title">{title}</h3>
                    {close_button}
                </div>
                <div class="pc-modal-body">
                    {children_html}
                </div>
            </div>
        </div>
        """

    def _render_form(self, node: UINode) -> str:
        """Render a form container."""
        form_id = node.attrs.get("id", "")
        onsubmit = node.attrs.get("onsubmit", "")
        
        children_html = "".join(self._render_node(c) for c in node.children)
        
        submit_handler = f'onsubmit="return pycromeHandleSubmit(event, \'{onsubmit}\')"' if onsubmit else ""
        
        return f"""
        <form class="pc-form" id="{form_id}" {submit_handler}>
            {children_html}
        </form>
        """

    def _render_formfield(self, node: UINode) -> str:
        """Render a form field with label and input."""
        label = node.attrs.get("label", "")
        field_id = node.attrs.get("id", "")
        field_type = node.attrs.get("type", "text")
        placeholder = node.attrs.get("placeholder", "")
        required = node.attrs.get("required", "false").lower() == "true"
        value = node.attrs.get("value", "")
        readonly = node.attrs.get("readonly", "false").lower() == "true"
        
        required_attr = "required" if required else ""
        readonly_attr = "readonly" if readonly else ""
        
        return f"""
        <div class="pc-form-field">
            <label class="pc-form-label" for="{field_id}">{label}</label>
            <input class="pc-input" type="{field_type}" id="{field_id}" name="{field_id}" 
                placeholder="{placeholder}" value="{value}" {required_attr} {readonly_attr} />
        </div>
        """

    def _render_select(self, node: UINode) -> str:
        """Render a select dropdown."""
        label = node.attrs.get("label", "")
        field_id = node.attrs.get("id", "")
        required = node.attrs.get("required", "false").lower() == "true"
        
        required_attr = "required" if required else ""
        
        options_html = ""
        for child in node.children:
            if child.component == "Option":
                opt_value = child.attrs.get("value", "")
                opt_label = child.attrs.get("label", opt_value)
                selected = child.attrs.get("selected", "false").lower() == "true"
                selected_attr = "selected" if selected else ""
                options_html += f'<option value="{opt_value}" {selected_attr}>{opt_label}</option>'
        
        return f"""
        <div class="pc-form-field">
            <label class="pc-form-label" for="{field_id}">{label}</label>
            <select class="pc-select" id="{field_id}" name="{field_id}" {required_attr}>
                {options_html}
            </select>
        </div>
        """

    def _render_textarea(self, node: UINode) -> str:
        """Render a textarea."""
        label = node.attrs.get("label", "")
        field_id = node.attrs.get("id", "")
        placeholder = node.attrs.get("placeholder", "")
        rows = node.attrs.get("rows", "4")
        required = node.attrs.get("required", "false").lower() == "true"
        value = node.attrs.get("value", "")
        
        required_attr = "required" if required else ""
        
        return f"""
        <div class="pc-form-field">
            <label class="pc-form-label" for="{field_id}">{label}</label>
            <textarea class="pc-textarea" id="{field_id}" name="{field_id}" 
                    placeholder="{placeholder}" rows="{rows}" {required_attr}>{value}</textarea>
        </div>
        """

    def _render_formactions(self, node: UINode) -> str:
        """Render form action buttons container."""
        children_html = "".join(self._render_node(c) for c in node.children)
        return f'<div class="pc-form-actions">{children_html}</div>'