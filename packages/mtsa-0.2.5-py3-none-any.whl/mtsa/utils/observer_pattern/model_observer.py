import fastavro
import os

class ModelObserver():
    def __init__(self, **kwargs) -> None:
        self.avro_file_name = ""
        
    def update(self, args):
        self.__create_avro_file(args)

    def __create_avro_file(self, args):
        schema = args["schema_avro"]
        avro_file_name = self.avro_file_name_with_path
        data = args["data"]
        os.makedirs(os.path.dirname(avro_file_name), exist_ok=True)
        
        if os.path.isfile(avro_file_name):
            with open(avro_file_name, "a+b") as f_out:
                fastavro.writer(f_out, schema, data,codec="deflate")
        else:    
            with open(avro_file_name, "wb") as f_out:
                fastavro.writer(f_out, schema, data,codec="deflate")
                
   

        

                     
        
        