import numpy as np

class ObservableModel:
    def __init__(self):
        super().__init__()
        self.observers = []

    def attach_observer(self, observer):
        self.observers.append(observer)

    def dettach_observer(self, observer):
        self.observers.remove(observer)
        
    def notify_observers(self, **kwargs):

        processed = {
            k: v.clone() if hasattr(v, "clone") else v
            for k, v in kwargs.items()
        }

        schemaAvro, data = self.__proxy_notify_observers(**processed)
        for observer in self.observers:
            observer.update(schemaAvro=schemaAvro, data=data)
        
    def __convert(self, value):
        """
        Converte tensores / numpy para tipos Python.
        """
        if hasattr(value, "detach"):
            value = value.detach()

        if hasattr(value, "cpu"):
            value = value.cpu()

        if hasattr(value, "numpy"):
            value = value.numpy()

        if hasattr(value, "tolist"):
            try:
                value = value.tolist()
            except:
                pass

        if hasattr(value, "item"):
            try:
                value = value.item()
            except:
                pass
            
        if not isinstance(value, (int, float, str, list, dict, bool, type(None))):
            return str(value)

        return value
     
    def __infer_avro_type(self, value):

        if value is None:
            return ["null", "string"]

        if isinstance(value, bool):
            return "boolean"

        if isinstance(value, int):
            return "int"

        if isinstance(value, float):
            return "double"

        if isinstance(value, str):
            return "string"

        if isinstance(value, dict):
            return {"type": "map", "values": "double"}

        if isinstance(value, list):

            if len(value) == 0:
                return {"type": "array", "items": "double"}

            if isinstance(value[0], list):
                return {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": "double"
                    }
                }

            return {"type": "array", "items": "double"}

        return "string"

    def __proxy_notify_observers(self, **kwargs):

        processed = {}
        fields = []

        for key, value in kwargs.items():

            value = self.__convert(value)

            processed[key] = value

            fields.append({
                "name": key,
                "type": self.__infer_avro_type(value)
            })

        schema_avro = {
            "type": "record",
            "name": "GANF_Network",
            "fields": fields
        }

        data = [processed]

        return schema_avro, data

