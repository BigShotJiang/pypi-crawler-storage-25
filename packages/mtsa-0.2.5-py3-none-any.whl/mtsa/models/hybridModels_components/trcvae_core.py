import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.nn.init import xavier_uniform_
from torch.nn.utils import clip_grad_value_
from torch.utils.data import DataLoader
from tqdm import tqdm
import time
from mtsa.utils.observer_pattern.observable_model import ObservableModel
from mtsa.models.hybridModels_components.gnn import GNN
from mtsa.models.hybridModels_components.cvae import CVAE
from types import SimpleNamespace
from torch.utils.data import Dataset

DEFAULT_EPOCHS = 20
DEFAULT_MAX_ITER = 2
DEFAULT_LR = 0.001


class TRCVAEcore(ObservableModel, nn.Module):
    def __init__(
        self,
        input_size=1,
        hidden_size=32,
        dropout=0.0,
        rho_max=float(1e16),
        max_iteraction=2,
        learning_rate=float(1e-3),
        alpha=0.0,
        weight_decay=float(5e-4),
        epochs=20,
        device=None,
        CVAE_hidden_dims=[400, 128],
        CVAE_latent_dim=64,
    ):
        super().__init__()
        self.adjacent_matrix = None
        self.rho_max = rho_max
        self.max_iteraction = max_iteraction
        self.learning_rate = learning_rate
        self.alpha = alpha
        self.weight_decay = weight_decay
        self.epochs = epochs
        self.epoch_times = []
        self._initial_adjacent_matrix = None

        if device != None:
            self.device = device
        else:
            self.device = torch.device(
                f"cuda:{str(str(0))}" if torch.cuda.is_available() else "cpu"
            )

        # Reducing dimensionality
        self.rnn = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            batch_first=True,
            dropout=dropout,
            device=self.device,
        )

        # Graph Neural Networks model
        self.gcn = GNN(input_size=hidden_size, hidden_size=hidden_size)
        self.gcn.to(device=self.device)

        # probability density estimation
        self.cvae = CVAE(
            device=self.device,
            cond_dim=hidden_size,
            input_dim=input_size,
            hidden_dims=CVAE_hidden_dims,
            latent_dim=CVAE_latent_dim,
        )
        self.cvae.to(device=self.device)
        self.to(device=self.device)

    @property
    def name(self):
        return "TRCVAEBaseModel " + self.summary()

    @property
    def adjacent_matrix(self):
        return self._adjacent_matrix

    @property
    def initial_adjacent_matrix(self):
        return self._initial_adjacent_matrix

    @initial_adjacent_matrix.setter
    def initial_adjacent_matrix(self, adjacent_matrix):
        if self._initial_adjacent_matrix is None:
            self._initial_adjacent_matrix = adjacent_matrix

    @adjacent_matrix.setter
    def adjacent_matrix(self, adjacent_matrix):
        self._adjacent_matrix = adjacent_matrix

    @property
    def epoch_times(self):
        return self._epoch_times

    @epoch_times.setter
    def epoch_times(self, epoch_times):
        self._epoch_times = epoch_times

    def summary(self):
        return repr(self)

    def fit(
        self,
        X,
        y=None,
        batch_size=None,
        epochs=None,
        max_iteraction=None,
        learning_rate=None,
        isWaveData=False,
    ):
        torch.cuda.manual_seed(10)
        random.seed(10)
        np.random.seed(10)
        torch.manual_seed(10)
        torch.autograd.set_detect_anomaly(True)

        loss_best = 100
        self.isWaveData = isWaveData
        h_A_old = np.inf
        h_tol = float(1e-6)
        rho = 1.0

        dimension = X.shape[-1]
        self.adjacent_matrix = self.__init_adjacent_matrix(X.data)
        self.initial_adjacent_matrix = self.adjacent_matrix.detach().clone()

        dataloaders = self.__create_dataLoader(
            torch.tensor(X),
            batch_size=batch_size if batch_size is not None else 32,
        )
        adjacent_matrix = self.adjacent_matrix

        self.__fitCore(
            loss_best,
            h_A_old,
            h_tol,
            dimension,
            dataloaders,
            adjacent_matrix,
            rho,
            epochs=epochs if epochs is not None else DEFAULT_EPOCHS,
            max_iteraction=(
                max_iteraction if max_iteraction is not None else DEFAULT_MAX_ITER
            ),
            learning_rate=learning_rate if learning_rate is not None else DEFAULT_LR,
        )

        self.is_fitted_ = True

    def predict(self, X):
        return self.__forward(X, self.adjacent_matrix)

    def score_samples(self, X):
        return self.__score_data(X=X)


    def __forward(self, x, A):
        # x: N X K X L X D
        full_shape = x.shape

        # reshape: N*K, L, D
        x = x.reshape((x.shape[0] * x.shape[1], x.shape[2], x.shape[3]))
        h, _ = self.rnn(x)

        # resahpe: N, K, L, H
        h = h.reshape((full_shape[0], full_shape[1], h.shape[1], h.shape[2]))

        h = self.gcn(h, A)

        # reshappe N*K*L,H
        h = h.reshape((-1, h.shape[3]))
        x = x.reshape((-1, full_shape[3]))

        recon_batch, mu, logvar = self.cvae(x, h)
        loss = self.cvae.loss_function(recon_batch, x, mu, logvar)

        return -loss

    def __fitCore(
        self,
        loss_best,
        h_A_old,
        h_tol,
        dimension,
        dataloaders,
        adjacent_matrix,
        rho,
        epochs,
        max_iteraction,
        learning_rate,
    ):
        foward_count = 0
        for j in range(max_iteraction):
            while rho < self.rho_max:
                learning_rate = self.learning_rate  # np.math.pow(0.1, epoch // 100)
                optimizer = torch.optim.Adam(
                    [
                        {
                            "params": self.parameters(),
                            "weight_decay": self.weight_decay,
                        },
                        {"params": [adjacent_matrix]},
                    ],
                    lr=learning_rate,
                    weight_decay=0.0,
                )

                for epoch in tqdm(
                    range(epochs),
                    desc=f"trainning epochs for {str(j + 1)} iteraction.",
                    unit="epochs",
                ):
                    start_time = time.time()
                    loss_train = []
                    epoch += 1
                    self.train()

                    for dataloader in dataloaders:
                        for x in dataloader:
                            x = x.to(self.device)

                            optimizer.zero_grad()
                            loss = -self.__forward(x, adjacent_matrix)
                            h = (
                                torch.trace(
                                    torch.matrix_exp(adjacent_matrix * adjacent_matrix)
                                )
                                - dimension
                            )

                            c_over_2_hA_sq = 0.5 * rho * h * h
                            lambda_hA = self.alpha * h
                            total_loss = loss + c_over_2_hA_sq + lambda_hA
                            # if self.logger is not None:
                            #     self.logger.log_metrics({
                            #         "mse": self.cvae.last_mse_loss,
                            #         "kl": self.cvae.last_kld_loss,
                            #         "msePLUSkl": self.cvae.last_mse_loss + self.cvae.last_kld_loss,
                            #         "c_over_2_hA_sq": c_over_2_hA_sq,
                            #         "lambda_hA": lambda_hA,
                            #         "total_loss": total_loss.item()
                            #         }, tag=f"epoch{epoch}_iteraction{j+1}"
                            #     )

                            h.to(self.device)
                            total_loss.backward()
                            clip_grad_value_(self.parameters(), 1)
                            optimizer.step()
                            loss_train.append(loss.item())
                            adjacent_matrix.data.copy_(
                                torch.clamp(adjacent_matrix.data, min=0, max=1)
                            )
                            foward_count += 1
                            if np.mean(loss_train) < loss_best:
                                self.loss_best = np.mean(loss_train)
                                self.adjacent_matrix = adjacent_matrix

                    end_time = time.time()
                    self.epoch_times.append(end_time - start_time)

                del optimizer
                torch.cuda.empty_cache()

                if h.item() > 0.5 * h_A_old:
                    rho *= 10
                else:
                    break

            h_A_old = h.item()
            self.alpha += rho * h.item()

            if h_A_old <= h_tol or rho >= self.rho_max:
                break

            # super().notify_observers(adjacent_matrix, epoch, h, total_loss, "final matrix", learning_rate=learning_rate, batch_size=self.batch_size)

    def __score_data(self, X):
        dataloaders = self.__create_dataLoader(
            X, window_size=1,
        )
        result = []
        for dataloader in dataloaders:
            for x in dataloader:
                x = x.to(self.device)
                result.append(self.predict(X=x))
        score = torch.tensor(result).mean()
        return score

    def __create_dataLoader(self, X, batch_size=32, window_size=12):
        X = self.__create_dataframe(X)
        dataloaders = []
        for x in X:
            x_dataloader = DataLoader(
                TRCVAEcore.Data(x, window_size=window_size),
                batch_size=batch_size,
                shuffle=False,
                num_workers=0,
                persistent_workers=False,
            )
            dataloaders.append(x_dataloader)
        return dataloaders

    def __create_dataframe(self, X):
        dataframes = []
        
        if X.ndim == 2: 
            X_Tensor = X.reshape(1,X.shape[0],X.shape[1])
        elif X.ndim == 4: 
            X_Tensor = X.reshape(X.shape[0] * X.shape[1], X.shape[2], X.shape[3])
        elif X.ndim == 3:
            X_Tensor = X
        else:
            raise ValueError("X should be 2D, 3D, or 4D array")

        for X_matrix in X_Tensor:
            X_df = self.__array2Dataframe(X_matrix)
            dataframes.append(X_df)
            
        return dataframes
    

    def __array2Dataframe(self, x):
        x_df = pd.DataFrame(x)
        x_df = x_df.reset_index()
        x_df = x_df.rename(columns={"index": "channel"})
        x_df["channel"] = pd.to_datetime(x_df["channel"], unit="s")
        x_df = x_df.set_index("channel")
        x_df = self.__normalize(x_df)
        return x_df

    def __normalize(self, X):
        mean = X.values.mean()
        std = X.values.std()
        X = (X - mean) / std
        return X

    def __init_adjacent_matrix(self, X):
        torch.cuda.manual_seed(10)
        random.seed(10)
        np.random.seed(10)
        torch.manual_seed(10)
        init = torch.zeros([X.shape[X.ndim - 1], X.shape[X.ndim - 1]])
        init = xavier_uniform_(init).abs()
        init = init.fill_diagonal_(0.0)
        adjacentMatrix = init.to(self.device).requires_grad_(True)
        return adjacentMatrix

    def __sklearn_tags__(self):
        return SimpleNamespace(requires_fit=False)

    # region Data class for dataloader
    class Data(Dataset):
        def __init__(self, df, window_size=12, stride_size=1):
            super(TRCVAEcore.Data, self).__init__()
            self.df = df
            self.window_size = window_size
            self.stride_size = stride_size

            self.data, self.idx, self.time = self.preprocess(df)

        def preprocess(self, df):
            start_idx = np.arange(0, len(df) - self.window_size + 1, self.stride_size)
            end_idx = start_idx + self.window_size

            delat_time = df.index[end_idx - 1] - df.index[start_idx]
            idx_mask = delat_time == pd.Timedelta(self.window_size - 1, unit="s")

            return df.values, start_idx[idx_mask], df.index[start_idx[idx_mask]]

        def __len__(self):

            length = len(self.idx)

            return length

        def __getitem__(self, index):
            #  N X K X L X D
            start = self.idx[index]
            end = start + self.window_size
            data = self.data[start:end].reshape([self.window_size, -1, 1])

            return torch.FloatTensor(data).transpose(0, 1)


# endregion
