#include <pybind11/pybind11.h>
namespace py = pybind11;

#include "bindings/state_space.h"
#include "bindings/base_state_space.h"
#include "bindings/so2_state_space.h"
#include "bindings/so3_state_space.h"
#include "bindings/se2_state_space.h"
#include "bindings/se3_state_space.h"
#include "bindings/time_state_space.h"
#include "bindings/discrete_state_space.h"
#include "bindings/space_time_state_space.h"
#include "bindings/extra_state_space.h"

PYBIND11_MODULE(_core, m) {
    m.doc() = "pyompl - Python bindings for OMPL 2.0.0";
    bind_state_space(m);
    bind_base_state_space(m);
    bind_so2_state_space(m);
    bind_so3_state_space(m);
    bind_se2_state_space(m);
    bind_se3_state_space(m);
    bind_time_state_space(m);
    bind_discrete_state_space(m);
    bind_space_time_state_space(m);
    bind_extra_state_spaces(m);
}
