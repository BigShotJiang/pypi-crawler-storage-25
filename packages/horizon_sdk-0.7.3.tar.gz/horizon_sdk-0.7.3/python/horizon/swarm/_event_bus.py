"""WebSocket pub/sub event bus for the swarm system."""

from __future__ import annotations

import asyncio
import collections
import json
import logging
import time
from typing import Any

try:
    import websockets
    # websockets v13+ uses websockets.asyncio.server
    # websockets v12 and earlier use websockets.serve directly
    try:
        from websockets.asyncio.server import serve as ws_serve
    except (ImportError, AttributeError):
        ws_serve = websockets.serve  # type: ignore[assignment]
except ImportError:
    websockets = None  # type: ignore[assignment]
    ws_serve = None  # type: ignore[assignment]

from ._types import SwarmEvent, SwarmEventType

logger = logging.getLogger("horizon.swarm.event_bus")

CHANNELS = ("agents", "hive", "risk", "knowledge", "system", "ui")
RING_BUFFER_SIZE = 1000


class EventBus:
    """WebSocket pub/sub server for swarm events.

    Each connected client subscribes to one or more channels.
    Events are broadcast to all subscribers of the target channel.
    A ring buffer of recent events per channel supports late-joining clients.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 8765) -> None:
        self._host = host
        self._port = port
        self._loop: asyncio.AbstractEventLoop | None = None
        self._server: Any = None
        # channel -> set of websocket connections
        self._subscribers: dict[str, set[Any]] = {ch: set() for ch in CHANNELS}
        # channel -> ring buffer of recent events
        self._history: dict[str, collections.deque[dict[str, Any]]] = {
            ch: collections.deque(maxlen=RING_BUFFER_SIZE) for ch in CHANNELS
        }
        # all connected clients
        self._clients: set[Any] = set()
        self._running = False

    async def start(self) -> None:
        """Start the WebSocket server."""
        if websockets is None:
            raise ImportError("Install websockets: pip install websockets")
        self._loop = asyncio.get_running_loop()
        server = ws_serve(self._handle_client, self._host, self._port)
        # websockets v12 returns a coroutine from serve(); v13+ may differ
        if asyncio.iscoroutine(server):
            self._server = await server
        else:
            self._server = await server.__aenter__()
        self._running = True
        # Get the actual port if 0 was passed (OS-assigned)
        if hasattr(self._server, "sockets") and self._server.sockets:
            addr = self._server.sockets[0].getsockname()
            self._port = addr[1]
        logger.info("Event bus listening on ws://%s:%d", self._host, self._port)

    async def stop(self) -> None:
        """Shut down the WebSocket server."""
        self._running = False
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        # Close all client connections
        for ws in list(self._clients):
            try:
                await ws.close()
            except Exception:
                pass
        self._clients.clear()
        for subs in self._subscribers.values():
            subs.clear()
        logger.info("Event bus stopped")

    async def publish(self, channel: str, event: SwarmEvent) -> None:
        """Publish an event to a channel (async, call from event loop)."""
        if channel not in self._subscribers:
            logger.warning("Unknown channel: %s", channel)
            return

        payload = json.dumps({"channel": channel, "event": event.to_dict()})
        self._history[channel].append(event.to_dict())

        dead: list[Any] = []
        for ws in self._subscribers[channel]:
            try:
                await ws.send(payload)
            except Exception:
                dead.append(ws)

        for ws in dead:
            self._remove_client(ws)

    def publish_sync(self, channel: str, event: SwarmEvent) -> None:
        """Thread-safe publish from non-async context (e.g. agent threads)."""
        if self._loop is None or not self._running:
            return
        asyncio.run_coroutine_threadsafe(self.publish(channel, event), self._loop)

    def get_history(self, channel: str, limit: int = 100) -> list[dict[str, Any]]:
        """Get recent events from a channel's ring buffer."""
        buf = self._history.get(channel, collections.deque())
        return list(buf)[-limit:]

    async def _handle_client(self, ws: Any, path: str = "/") -> None:
        """Handle a new WebSocket client connection."""
        self._clients.add(ws)
        # Default: subscribe to all channels
        for ch in CHANNELS:
            self._subscribers[ch].add(ws)
        logger.info("Client connected (%d total)", len(self._clients))

        try:
            async for raw in ws:
                await self._handle_message(ws, raw)
        except Exception:
            pass
        finally:
            self._remove_client(ws)
            logger.info("Client disconnected (%d remaining)", len(self._clients))

    async def _handle_message(self, ws: Any, raw: str) -> None:
        """Handle incoming messages from clients.

        Supported messages:
        - {"subscribe": ["channel1", "channel2"]}
        - {"unsubscribe": ["channel1"]}
        - {"command": "...", ...}  (forwarded to hive channel)
        - {"get_history": "channel", "limit": 50}
        """
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            return

        if "subscribe" in msg:
            for ch in msg["subscribe"]:
                if ch in self._subscribers:
                    self._subscribers[ch].add(ws)

        elif "unsubscribe" in msg:
            for ch in msg["unsubscribe"]:
                if ch in self._subscribers:
                    self._subscribers[ch].discard(ws)

        elif "get_history" in msg:
            ch = msg["get_history"]
            limit = msg.get("limit", 100)
            history = self.get_history(ch, limit)
            await ws.send(json.dumps({"history": ch, "events": history}))

        elif "command" in msg:
            # Forward user commands to hive channel
            event = SwarmEvent(
                type=SwarmEventType.HIVE_DIRECTIVE,
                source="ui",
                data={"command": msg["command"], **{k: v for k, v in msg.items() if k != "command"}},
                timestamp=time.time(),
            )
            await self.publish("hive", event)

    def _remove_client(self, ws: Any) -> None:
        """Clean up a disconnected client."""
        self._clients.discard(ws)
        for subs in self._subscribers.values():
            subs.discard(ws)
