"""Horizon Swarm — Autonomous quant agent system.

Uses OpenRouter (any LLM) to orchestrate agent workflows through
research -> analysis -> backtest -> robustness -> execution -> monitoring.

Usage:
    from horizon.swarm import SwarmConfig, run_swarm

    config = SwarmConfig(
        api_key="sk-or-...",  # OpenRouter API key
        hive_model="anthropic/claude-sonnet-4-6",
        agent_model="anthropic/claude-sonnet-4-6",
        max_agents=5,
        max_capital_usd=10_000,
    )
    run_swarm(config)
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from ._types import (
    AgentPhase,
    AgentState,
    AgentStatus,
    CircuitBreakerState,
    Proposal,
    ProposalVerdict,
    SwarmConfig,
    SwarmEvent,
    SwarmEventType,
)
from ._event_bus import EventBus
from ._engine_pool import EnginePool
from ._circuit_breaker import CircuitBreaker
from ._llm import LLMClient, LLMResponse, ToolCall
from ._hive import Hive

logger = logging.getLogger("horizon.swarm")

__all__ = [
    "AgentPhase",
    "AgentState",
    "AgentStatus",
    "CircuitBreakerState",
    "EventBus",
    "EnginePool",
    "CircuitBreaker",
    "Hive",
    "LLMClient",
    "LLMResponse",
    "Proposal",
    "ProposalVerdict",
    "SwarmConfig",
    "SwarmEvent",
    "SwarmEventType",
    "ToolCall",
    "start_swarm",
    "run_swarm",
]


async def start_swarm(config: SwarmConfig) -> Hive:
    """Start the full swarm system.

    Creates and starts:
    1. Event bus (WebSocket server)
    2. Engine pool
    3. Knowledge graph (shared brain)
    4. Circuit breaker (non-LLM watchdog)
    5. Hive orchestrator (Opus)

    Returns the Hive instance for programmatic control.
    """
    # Optional knowledge graph
    kg = None
    try:
        from horizon.fund._knowledge_graph import KnowledgeGraph
        kg = KnowledgeGraph(db_path=config.db_path.replace(".db", "_kg.db"))
        logger.info("Knowledge graph initialized")
    except Exception as e:
        logger.warning("Knowledge graph unavailable: %s", e)

    # 1. Event bus
    event_bus = EventBus(host=config.ws_host, port=config.ws_port)
    await event_bus.start()

    # 2. Engine pool
    engine_pool = EnginePool(config)

    # 3. Circuit breaker
    circuit_breaker = CircuitBreaker(
        config=config,
        engine_pool=engine_pool,
        event_bus=event_bus,
    )
    circuit_breaker.start()

    # 4. Hive
    hive = Hive(
        config=config,
        event_bus=event_bus,
        engine_pool=engine_pool,
        knowledge_graph=kg,
    )

    # Wire circuit breaker to hive agents
    circuit_breaker.set_agents(hive._agents)

    await hive.start()

    # Store references for cleanup
    hive._event_bus = event_bus
    hive._circuit_breaker = circuit_breaker  # type: ignore[attr-defined]

    logger.info(
        "Swarm started: ws://%s:%d | max_agents=%d | max_capital=$%,.0f",
        config.ws_host, config.ws_port, config.max_agents, config.max_capital_usd,
    )
    return hive


def run_swarm(config: SwarmConfig) -> None:
    """Blocking entry point — starts the swarm and runs until interrupted."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    async def _main() -> None:
        hive = await start_swarm(config)
        try:
            # Run forever (or until Ctrl+C)
            while True:
                await asyncio.sleep(1)
        except (KeyboardInterrupt, asyncio.CancelledError):
            logger.info("Shutting down swarm...")
        finally:
            # Cleanup
            cb = getattr(hive, "_circuit_breaker", None)
            if cb is not None:
                cb.stop()
            await hive.stop()
            if hive._event_bus is not None:
                await hive._event_bus.stop()

    asyncio.run(_main())
