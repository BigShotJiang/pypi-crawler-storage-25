"""Hive orchestrator — LLM-powered swarm intelligence.

The Hive runs a periodic oversight loop where it reviews the swarm state,
manages agent lifecycle, reviews proposals, and allocates capital.

Uses the Horizon LLMClient, which works with any OpenAI-compatible provider
(OpenRouter, Azure, local models, etc.).
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import deque
from typing import Any

from ._types import (
    AgentStatus,
    Proposal,
    ProposalVerdict,
    SwarmConfig,
    SwarmEvent,
    SwarmEventType,
)
from ._event_bus import EventBus
from ._engine_pool import EnginePool
from ._agent import SwarmAgent
from ._llm import LLMClient
from ._mcp_tools import HiveToolServer
from ._prompt import build_hive_context, get_hive_system_prompt

logger = logging.getLogger("horizon.swarm.hive")


class Hive:
    """Central orchestrator for the quant agent swarm.

    Uses an LLM to review swarm state and make strategic decisions:
    spawn/kill agents, review proposals, allocate capital.
    """

    def __init__(
        self,
        config: SwarmConfig,
        event_bus: EventBus,
        engine_pool: EnginePool,
        knowledge_graph: Any = None,
    ) -> None:
        self._config = config
        self._event_bus = event_bus
        self._engine_pool = engine_pool
        self._kg = knowledge_graph

        # Agent registry
        self._agents: dict[str, SwarmAgent] = {}
        self._agent_counter = 0

        # Proposal queue (agents push, Hive reads)
        self._pending_proposals: list[Proposal] = []
        self._resolved_proposals: deque[Proposal] = deque(maxlen=200)

        # Recent events for context (fed from event bus)
        self._recent_events: deque[dict[str, Any]] = deque(maxlen=200)

        # LLM client
        self._llm: LLMClient | None = None
        self._tool_server: HiveToolServer | None = None

        # Oversight loop task
        self._task: asyncio.Task | None = None
        self._running = False

        # Observability
        self._cycle_count = 0

    @property
    def llm_cost_usd(self) -> float:
        """Cumulative LLM cost for Hive oversight calls."""
        return self._llm.total_cost_usd if self._llm else 0.0

    async def start(self) -> None:
        """Start the Hive oversight loop."""
        self._llm = LLMClient(
            api_key=self._config.api_key,
            model=self._config.hive_model,
            api_base=self._config.api_base,
        )
        self._tool_server = HiveToolServer(self)
        self._running = True

        self._event_bus.publish_sync("system", SwarmEvent(
            type=SwarmEventType.SYSTEM_STATUS,
            source="hive",
            data={"status": "started", "model": self._config.hive_model},
            timestamp=time.time(),
        ))

        self._task = asyncio.create_task(self._oversight_loop())
        logger.info(
            "Hive started (model=%s, oversight every %.0fs)",
            self._config.hive_model, self._config.hive_oversight_interval_s,
        )

    async def stop(self) -> None:
        """Stop the Hive and all agents."""
        self._running = False
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

        # Stop all agents and release their engines
        for agent in list(self._agents.values()):
            await agent.stop()
        self._agents.clear()

        self._event_bus.publish_sync("system", SwarmEvent(
            type=SwarmEventType.SYSTEM_STATUS,
            source="hive",
            data={"status": "stopped", "cycles": self._cycle_count, "total_cost": self.llm_cost_usd},
            timestamp=time.time(),
        ))
        logger.info("Hive stopped (cycles=%d, cost=$%.4f)", self._cycle_count, self.llm_cost_usd)

    # ----------------------------------------------------------------------- #
    # Agent lifecycle (called by Hive tool server)
    # ----------------------------------------------------------------------- #

    async def spawn_agent(self, mission: str = "") -> str:
        """Spawn a new swarm agent."""
        if len(self._agents) >= self._config.max_agents:
            raise ValueError(f"Max agents ({self._config.max_agents}) reached")

        self._agent_counter += 1
        agent_id = f"agent_{self._agent_counter:03d}"

        agent = SwarmAgent(
            agent_id=agent_id,
            config=self._config,
            engine_pool=self._engine_pool,
            event_bus=self._event_bus,
            knowledge_graph=self._kg,
            mission=mission or None,
        )
        self._agents[agent_id] = agent
        await agent.start()

        self._event_bus.publish_sync("hive", SwarmEvent(
            type=SwarmEventType.HIVE_AGENT_SPAWNED,
            source="hive",
            data={"agent_id": agent_id, "mission": mission},
            timestamp=time.time(),
        ))
        logger.info("Spawned agent %s (mission=%s)", agent_id, mission or "free-roaming")
        return agent_id

    async def kill_agent(self, agent_id: str, reason: str) -> None:
        """Kill a specific agent."""
        agent = self._agents.pop(agent_id, None)
        if agent is None:
            raise ValueError(f"Agent {agent_id} not found")

        agent.state.status = AgentStatus.KILLED
        await agent.stop()
        # Engine is released inside agent.stop() via engine_pool.release()
        logger.info("Killed agent %s: %s", agent_id, reason)

    def redirect_agent(self, agent_id: str, directive: str) -> None:
        """Send a directive to an agent."""
        agent = self._agents.get(agent_id)
        if agent is None:
            raise ValueError(f"Agent {agent_id} not found")
        agent.inject_directive(directive)
        self._event_bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.HIVE_DIRECTIVE,
            source="hive",
            data={"agent_id": agent_id, "directive": directive},
            timestamp=time.time(),
        ))

    def allocate_capital(self, agent_id: str, amount: float) -> None:
        """Set capital allocation for an agent."""
        agent = self._agents.get(agent_id)
        if agent is None:
            raise ValueError(f"Agent {agent_id} not found")

        # Validate total allocation
        total_allocated = sum(a.state.capital_allocated for a in self._agents.values())
        new_total = total_allocated - agent.state.capital_allocated + amount
        if new_total > self._config.max_capital_usd:
            raise ValueError(
                f"Would exceed max capital: ${new_total:,.2f} > ${self._config.max_capital_usd:,.2f}"
            )

        agent.state.capital_allocated = amount
        self._engine_pool.update_risk_limits(agent_id, amount)

        self._event_bus.publish_sync("hive", SwarmEvent(
            type=SwarmEventType.HIVE_CAPITAL_ALLOCATED,
            source="hive",
            data={"agent_id": agent_id, "amount": amount},
            timestamp=time.time(),
        ))

    def review_proposal(
        self, proposal_id: str, verdict: str, reasoning: str
    ) -> dict[str, Any]:
        """Review a pending proposal."""
        proposal = None
        for p in self._pending_proposals:
            if p.proposal_id == proposal_id:
                proposal = p
                break
        if proposal is None:
            return {"error": f"Proposal {proposal_id} not found"}

        # Validate anti-overfitting gates (enforced in code, not prompt)
        proof = proposal.anti_overfitting_proof
        required_gates = [
            "deflated_sharpe", "walk_forward", "cpcv_pbo",
            "bootstrap_robustness", "structural_validation",
        ]
        missing_gates = [g for g in required_gates if g not in proof]
        failed_gates = [g for g in required_gates if g in proof and not proof[g].get("passed", False)]

        if missing_gates and verdict == "approved":
            return {
                "error": f"Cannot approve: missing anti-overfitting gates: {missing_gates}",
                "missing_gates": missing_gates,
            }
        if failed_gates and verdict == "approved":
            return {
                "error": f"Cannot approve: failed anti-overfitting gates: {failed_gates}",
                "failed_gates": failed_gates,
            }

        verdict_enum = ProposalVerdict(verdict)
        proposal.verdict = verdict_enum
        proposal.verdict_reasoning = reasoning

        self._pending_proposals.remove(proposal)
        self._resolved_proposals.append(proposal)

        # Notify the agent
        agent = self._agents.get(proposal.agent_id)
        if agent is not None:
            agent.inject_directive(
                f"Proposal {proposal_id} {verdict}: {reasoning}"
            )

        self._event_bus.publish_sync("hive", SwarmEvent(
            type=SwarmEventType.PROPOSAL_VERDICT,
            source="hive",
            data={
                "proposal_id": proposal_id,
                "agent_id": proposal.agent_id,
                "verdict": verdict,
                "reasoning": reasoning,
            },
            timestamp=time.time(),
        ))

        return {
            "proposal_id": proposal_id,
            "verdict": verdict,
            "reasoning": reasoning,
        }

    def broadcast_insight(self, message: str) -> None:
        """Broadcast an insight to all agents."""
        for agent in self._agents.values():
            agent.inject_directive(f"[Hive Insight] {message}")
        self._event_bus.publish_sync("knowledge", SwarmEvent(
            type=SwarmEventType.KNOWLEDGE_SHARED,
            source="hive",
            data={"message": message},
            timestamp=time.time(),
        ))

    def record_event(self, event: dict[str, Any]) -> None:
        """Record an event for Hive context (called by event bus listener)."""
        self._recent_events.append(event)

    # ----------------------------------------------------------------------- #
    # Status queries (called by Hive tool server)
    # ----------------------------------------------------------------------- #

    def get_swarm_status(self) -> dict[str, Any]:
        """Get full swarm status."""
        agents = [a.state.to_dict() for a in self._agents.values()]
        total_pnl = sum(a.state.pnl for a in self._agents.values())
        total_capital = sum(a.state.capital_allocated for a in self._agents.values())
        total_agent_cost = sum(a.state.llm_cost_usd for a in self._agents.values())

        return {
            "n_agents": len(self._agents),
            "agents": agents,
            "total_pnl": round(total_pnl, 4),
            "total_capital_allocated": round(total_capital, 2),
            "total_llm_cost": round(total_agent_cost + self.llm_cost_usd, 4),
            "hive_llm_cost": round(self.llm_cost_usd, 4),
            "pending_proposals": len(self._pending_proposals),
            "max_agents": self._config.max_agents,
            "max_capital": self._config.max_capital_usd,
            "hive_cycles": self._cycle_count,
        }

    def get_agent_details(self, agent_id: str) -> dict[str, Any]:
        """Get detailed info on a specific agent."""
        agent = self._agents.get(agent_id)
        if agent is None:
            return {"error": f"Agent {agent_id} not found"}

        state = agent.state.to_dict()
        state["proposals"] = [
            {
                "proposal_id": p.proposal_id,
                "market_id": p.market_id,
                "verdict": p.verdict.value if p.verdict else None,
            }
            for p in agent.proposals
        ]
        return state

    def get_portfolio_risk(self) -> dict[str, Any]:
        """Get portfolio-level risk metrics."""
        total_pnl = self._engine_pool.aggregate_pnl()
        positions = self._engine_pool.aggregate_positions()
        total_capital = sum(a.state.capital_allocated for a in self._agents.values())

        # Market concentration
        market_exposure: dict[str, float] = {}
        for pos in positions:
            mid = pos["market_id"]
            market_exposure[mid] = market_exposure.get(mid, 0.0) + abs(pos.get("size", 0.0))

        max_concentration = 0.0
        if total_capital > 0 and market_exposure:
            max_concentration = max(market_exposure.values()) / total_capital

        # Drawdown
        drawdown_pct = abs(min(total_pnl, 0.0)) / total_capital if total_capital > 0 else 0.0

        return {
            "total_pnl": round(total_pnl, 4),
            "total_capital": round(total_capital, 2),
            "n_positions": len(positions),
            "drawdown_pct": round(drawdown_pct, 4),
            "max_market_concentration": round(max_concentration, 4),
            "n_unique_markets": len(market_exposure),
            "positions": positions[:20],
        }

    # ----------------------------------------------------------------------- #
    # Oversight loop
    # ----------------------------------------------------------------------- #

    async def _oversight_loop(self) -> None:
        """Periodic oversight: review swarm, make decisions via LLM."""
        # Brief delay so agents have time to start before first cycle
        await asyncio.sleep(min(5.0, self._config.hive_oversight_interval_s))

        while self._running:
            try:
                await self._run_oversight_cycle()
            except Exception as e:
                logger.error("Hive oversight error: %s", e, exc_info=True)
            await asyncio.sleep(self._config.hive_oversight_interval_s)

    async def _run_oversight_cycle(self) -> None:
        """One Hive oversight cycle with tool use."""
        if self._llm is None or self._tool_server is None:
            return

        self._cycle_count += 1

        # Collect pending proposals from all agents
        for agent in self._agents.values():
            for proposal in agent.proposals:
                if not any(p.proposal_id == proposal.proposal_id for p in self._pending_proposals):
                    self._pending_proposals.append(proposal)

        # Build context
        agents_data = [a.state.to_dict() for a in self._agents.values()]
        proposals_data = [
            {
                "proposal_id": p.proposal_id,
                "agent_id": p.agent_id,
                "market_id": p.market_id,
                "side": p.side,
                "edge_estimate": p.edge_estimate,
                "requested_capital": p.requested_capital,
                "anti_overfitting_proof": {
                    gate: {"passed": info.get("passed", False)}
                    for gate, info in p.anti_overfitting_proof.items()
                },
            }
            for p in self._pending_proposals
        ]
        portfolio_risk = self.get_portfolio_risk()
        recent_events = list(self._recent_events)[-30:]

        context = build_hive_context(
            agents=agents_data,
            pending_proposals=proposals_data,
            portfolio_risk=portfolio_risk,
            recent_events=recent_events,
        )

        system_prompt = get_hive_system_prompt(
            n_agents=len(self._agents),
            total_capital=sum(a.state.capital_allocated for a in self._agents.values()),
            max_capital=self._config.max_capital_usd,
            max_agents=self._config.max_agents,
        )

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context},
        ]
        tools = self._tool_server.openai_tool_definitions

        # Agentic loop
        turns = 0
        max_turns = 10

        while turns < max_turns:
            turns += 1
            resp = await self._llm.complete(messages, tools)
            if resp is None:
                break

            # Append assistant message to conversation
            messages.append(resp.to_message())

            if not resp.tool_calls:
                break

            # Execute tool calls
            for tc in resp.tool_calls:
                try:
                    args = json.loads(tc.arguments)
                except json.JSONDecodeError:
                    args = {}

                result = await self._tool_server.call_tool(tc.name, args)
                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": json.dumps(result, default=str),
                })

                # Record tool action as event for future context
                self._recent_events.append({
                    "type": "hive_action",
                    "source": "hive",
                    "data": {"tool": tc.name, "result_keys": list(result.keys())},
                })
                logger.info(
                    "Hive tool: %s -> %s",
                    tc.name, json.dumps(result, default=str)[:200],
                )

            if resp.finish_reason == "stop":
                break

        self._event_bus.publish_sync("system", SwarmEvent(
            type=SwarmEventType.METRICS_UPDATE,
            source="hive",
            data={
                "cycle": self._cycle_count,
                "oversight_turns": turns,
                "n_agents": len(self._agents),
                "hive_cost_usd": round(self.llm_cost_usd, 4),
            },
            timestamp=time.time(),
        ))
