"""Thread-safe Engine instance pool for swarm agents."""

from __future__ import annotations

import logging
import threading
from typing import Any

from horizon._horizon import Engine, RiskConfig

from ._types import SwarmConfig

logger = logging.getLogger("horizon.swarm.engine_pool")


class EnginePool:
    """Manages a pool of Engine instances, one per swarm agent.

    Each agent gets its own Engine with per-agent risk limits derived
    from its capital allocation. Thread-safe via a global lock.
    """

    def __init__(self, config: SwarmConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        # agent_id -> Engine
        self._engines: dict[str, Engine] = {}

    def acquire(self, agent_id: str, capital: float = 0.0) -> Engine:
        """Create and return an Engine for a specific agent.

        If the agent already has an engine, returns the existing one.
        """
        with self._lock:
            if agent_id in self._engines:
                return self._engines[agent_id]

            risk = RiskConfig(
                max_position_per_market=max(capital * 0.5, 100.0),
                max_portfolio_notional=max(capital, 100.0),
                max_daily_drawdown_pct=self._config.max_drawdown_pct * 100,
            )

            engine = Engine(
                risk_config=risk,
                exchange_type=self._config.exchange_backend,
                db_path=f"{self._config.db_path}.{agent_id}",
            )
            self._engines[agent_id] = engine
            logger.info("Engine acquired for agent %s (capital=%.2f)", agent_id, capital)
            return engine

    def release(self, agent_id: str) -> None:
        """Release an engine for a given agent."""
        with self._lock:
            engine = self._engines.pop(agent_id, None)
            if engine is not None:
                try:
                    engine.cancel_all()
                except Exception:
                    pass
                logger.info("Engine released for agent %s", agent_id)

    def get_engine(self, agent_id: str) -> Engine | None:
        """Get an agent's engine (returns None if not acquired)."""
        with self._lock:
            return self._engines.get(agent_id)

    def get_all_engines(self) -> dict[str, Engine]:
        """Get a snapshot of all agent engines."""
        with self._lock:
            return dict(self._engines)

    def update_risk_limits(self, agent_id: str, capital: float) -> None:
        """Update an agent's engine risk limits based on new capital allocation.

        RiskConfig is immutable after Engine construction, so we recreate the
        engine with updated limits. Open orders are canceled first.
        """
        with self._lock:
            old_engine = self._engines.get(agent_id)
            if old_engine is None:
                return

            # Cancel all orders on the old engine before replacing
            try:
                old_engine.cancel_all()
            except Exception:
                pass

            risk = RiskConfig(
                max_position_per_market=max(capital * 0.5, 100.0),
                max_portfolio_notional=max(capital, 100.0),
                max_daily_drawdown_pct=self._config.max_drawdown_pct * 100,
            )

            new_engine = Engine(
                risk_config=risk,
                exchange_type=self._config.exchange_backend,
                db_path=f"{self._config.db_path}.{agent_id}",
            )
            self._engines[agent_id] = new_engine
            logger.info(
                "Engine recreated for agent %s with updated capital=%.2f "
                "(max_position=%.2f, max_notional=%.2f)",
                agent_id, capital,
                max(capital * 0.5, 100.0), max(capital, 100.0),
            )

    def shutdown(self) -> None:
        """Release all engines and clean up."""
        with self._lock:
            for agent_id, engine in self._engines.items():
                try:
                    engine.cancel_all()
                except Exception:
                    pass
                logger.info("Engine shut down for agent %s", agent_id)
            self._engines.clear()

    @property
    def active_count(self) -> int:
        with self._lock:
            return len(self._engines)

    def aggregate_pnl(self) -> float:
        """Sum realized P&L across all engines."""
        total = 0.0
        with self._lock:
            for engine in self._engines.values():
                try:
                    status = engine.status()
                    total += status.total_realized_pnl
                except Exception:
                    pass
        return total

    def aggregate_positions(self) -> list[dict[str, Any]]:
        """Get all positions across all engines."""
        all_pos: list[dict[str, Any]] = []
        with self._lock:
            for agent_id, engine in self._engines.items():
                try:
                    for pos in engine.positions():
                        all_pos.append({
                            "agent_id": agent_id,
                            "market_id": pos.market_id,
                            "size": pos.size,
                            "side": str(pos.side),
                            "avg_price": pos.avg_price,
                            "unrealized_pnl": pos.unrealized_pnl,
                        })
                except Exception:
                    pass
        return all_pos

    def cancel_all_orders(self) -> int:
        """Emergency: cancel all orders across all engines."""
        total = 0
        with self._lock:
            for agent_id, engine in self._engines.items():
                try:
                    n = engine.cancel_all()
                    total += n
                    logger.warning("Canceled %d orders for agent %s", n, agent_id)
                except Exception as e:
                    logger.error("Failed to cancel orders for %s: %s", agent_id, e)
        return total
