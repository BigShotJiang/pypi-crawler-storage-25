"""Entry point: python -m horizon.swarm"""

from __future__ import annotations

import os
import sys

from ._types import SwarmConfig


def main() -> None:
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key:
        print("Error: OPENROUTER_API_KEY environment variable required", file=sys.stderr)
        print("  Get one at https://openrouter.ai/keys", file=sys.stderr)
        sys.exit(1)

    config = SwarmConfig(
        api_key=api_key,
        api_base=os.environ.get("SWARM_API_BASE", "https://openrouter.ai/api/v1"),
        max_agents=int(os.environ.get("SWARM_MAX_AGENTS", "10")),
        max_capital_usd=float(os.environ.get("SWARM_MAX_CAPITAL", "10000")),
        max_drawdown_pct=float(os.environ.get("SWARM_MAX_DRAWDOWN", "0.10")),
        max_daily_loss_usd=float(os.environ.get("SWARM_MAX_DAILY_LOSS", "500")),
        ws_host=os.environ.get("SWARM_WS_HOST", "127.0.0.1"),
        ws_port=int(os.environ.get("SWARM_WS_PORT", "8765")),
        exchange_backend=os.environ.get("SWARM_EXCHANGE", "paper"),
        hive_model=os.environ.get("SWARM_HIVE_MODEL", "anthropic/claude-sonnet-4.6"),
        agent_model=os.environ.get("SWARM_AGENT_MODEL", "openai/gpt-5.4-mini"),
        db_path=os.environ.get("SWARM_DB_PATH", "swarm.db"),
    )

    from . import run_swarm
    run_swarm(config)


if __name__ == "__main__":
    main()
