"""SwarmAgent — Autonomous quant agent powered by any LLM.

Each agent runs a recurring query loop through the full quant pipeline:
research -> analyze -> backtest -> robustness -> propose -> execute -> monitor.

Uses the Horizon LLMClient, which works with any OpenAI-compatible provider
(OpenRouter, Azure, local models, etc.).
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import deque
from typing import Any

from ._types import (
    AgentPhase,
    AgentState,
    AgentStatus,
    SwarmConfig,
    SwarmEvent,
    SwarmEventType,
)
from ._event_bus import EventBus
from ._engine_pool import EnginePool
from ._llm import LLMClient
from ._mcp_tools import AgentToolServer
from ._prompt import build_agent_context, get_agent_system_prompt

logger = logging.getLogger("horizon.swarm.agent")

# Message history limits to prevent context overflow
_MAX_MESSAGES_PER_CYCLE = 120  # ~120 messages before truncation
_TRUNCATE_TO = 40  # keep system + user + last N messages

# Phase sequence — agents progress through these in order
_PHASE_SEQUENCE = [
    AgentPhase.RESEARCHING,
    AgentPhase.ANALYZING,
    AgentPhase.BACKTESTING,
    AgentPhase.ROBUSTNESS,
    AgentPhase.PROPOSING,
    AgentPhase.EXECUTING,
    AgentPhase.MONITORING,
    AgentPhase.EVOLVING,
    AgentPhase.RETIRING,
]

# Per-phase turn budgets — generous limits, nudge at 80%, auto-advance at 100%
_PHASE_TURN_BUDGET: dict[AgentPhase, int] = {
    AgentPhase.IDLE: 3,
    AgentPhase.RESEARCHING: 30,
    AgentPhase.ANALYZING: 30,
    AgentPhase.BACKTESTING: 25,
    AgentPhase.ROBUSTNESS: 25,
    AgentPhase.PROPOSING: 15,
    AgentPhase.EXECUTING: 25,
    AgentPhase.MONITORING: 100,
    AgentPhase.EVOLVING: 30,
    AgentPhase.RETIRING: 15,
}

# Phase time limits in seconds — generous wall-clock limits
_PHASE_TIME_LIMIT: dict[AgentPhase, float] = {
    AgentPhase.IDLE: 30.0,
    AgentPhase.RESEARCHING: 300.0,   # 5 min
    AgentPhase.ANALYZING: 300.0,
    AgentPhase.BACKTESTING: 300.0,
    AgentPhase.ROBUSTNESS: 300.0,
    AgentPhase.PROPOSING: 180.0,     # 3 min
    AgentPhase.EXECUTING: 300.0,
    AgentPhase.MONITORING: 1800.0,   # 30 min
    AgentPhase.EVOLVING: 300.0,
    AgentPhase.RETIRING: 120.0,      # 2 min
}


def _next_phase(current: AgentPhase, has_trades: bool = True) -> AgentPhase | None:
    """Get the next phase in the sequence.

    If the agent reaches RETIRING with no trades, restart from RESEARCHING
    instead of terminating — the agent gets another chance.
    """
    if current == AgentPhase.RETIRING and not has_trades:
        return AgentPhase.RESEARCHING

    try:
        idx = _PHASE_SEQUENCE.index(current)
        if idx + 1 < len(_PHASE_SEQUENCE):
            return _PHASE_SEQUENCE[idx + 1]
    except ValueError:
        pass
    return None


class SwarmAgent:
    """A single autonomous quant agent.

    Runs a recurring LLM query cycle. Each cycle:
    1. Build context (phase, portfolio, directives, knowledge)
    2. Call the LLM with tools available
    3. Process tool calls in a loop until the LLM stops or hits max_turns
    4. Publish state update to the event bus
    5. Sleep briefly, then start next cycle
    """

    def __init__(
        self,
        agent_id: str,
        config: SwarmConfig,
        engine_pool: EnginePool,
        event_bus: EventBus,
        knowledge_graph: Any = None,
        mission: str | None = None,
    ) -> None:
        self.agent_id = agent_id
        self._config = config
        self._engine_pool = engine_pool
        self._event_bus = event_bus
        self._kg = knowledge_graph

        self.state = AgentState(
            agent_id=agent_id,
            phase=AgentPhase.IDLE,
            status=AgentStatus.STOPPED,
            mission=mission or None,
        )

        # Directive queue: Hive pushes directives here
        self._directive_queue: list[str] = []
        # Proposal queue: agent pushes proposals here, Hive reads them
        self._proposal_queue: deque[Any] = deque(maxlen=50)
        # Recent events for context building
        self._recent_events: deque[dict[str, Any]] = deque(maxlen=100)

        self._task: asyncio.Task | None = None
        self._paused = False
        self._start_time = 0.0

        # Tool server (created when engine is acquired)
        self._tool_server: AgentToolServer | None = None
        # LLM client
        self._llm: LLMClient | None = None

        # Per-phase tracking
        self._phase_turns = 0
        self._phase_entered_at = 0.0
        self._nudge_sent = False
        self._consecutive_llm_failures = 0
        self._restart_count = 0  # how many times we've restarted from RETIRING

    async def start(self) -> None:
        """Start the agent's main loop."""
        self._llm = LLMClient(
            api_key=self._config.api_key,
            model=self._config.agent_model,
            api_base=self._config.api_base,
        )
        self._start_time = time.time()

        # Acquire engine from the pool
        engine = self._engine_pool.acquire(self.agent_id, self.state.capital_allocated)

        # Create tool server bound to this agent's engine
        self._tool_server = AgentToolServer(
            agent_id=self.agent_id,
            engine=engine,
            event_bus=self._event_bus,
            knowledge_graph=self._kg,
            proposal_queue=self._proposal_queue,
            directive_queue=self._directive_queue,
        )

        self.state.status = AgentStatus.RUNNING
        self.state.phase = AgentPhase.RESEARCHING

        # CRITICAL: sync tool server phase with agent state
        self._tool_server._phase = AgentPhase.RESEARCHING

        # Initialize phase tracking
        self._phase_turns = 0
        self._phase_entered_at = time.time()
        self._nudge_sent = False

        self._event_bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.AGENT_SPAWNED,
            source=self.agent_id,
            data={"mission": self.state.mission, "phase": self.state.phase.value},
            timestamp=time.time(),
        ))

        self._task = asyncio.create_task(self._run_loop())
        logger.info("Agent %s started (mission=%s, model=%s)", self.agent_id, self.state.mission, self._config.agent_model)

    async def stop(self) -> None:
        """Stop the agent gracefully."""
        self.state.status = AgentStatus.STOPPED
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

        # Release engine back to pool
        self._engine_pool.release(self.agent_id)

        self._event_bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.AGENT_STOPPED,
            source=self.agent_id,
            data={"reason": "stopped", "final_pnl": self.state.pnl, "total_cost": self.state.llm_cost_usd},
            timestamp=time.time(),
        ))
        logger.info("Agent %s stopped (pnl=%.4f, cost=$%.4f)", self.agent_id, self.state.pnl, self.state.llm_cost_usd)

    def pause(self) -> None:
        self._paused = True
        self.state.status = AgentStatus.PAUSED

    def resume(self) -> None:
        self._paused = False
        self.state.status = AgentStatus.RUNNING

    def inject_directive(self, directive: str) -> None:
        """Inject a directive from the Hive."""
        self._directive_queue.append(directive)

    @property
    def proposals(self) -> list[Any]:
        """Get pending proposals (read by Hive)."""
        return list(self._proposal_queue)

    def _transition_phase(self, new_phase: AgentPhase, reason: str) -> None:
        """Internal phase transition with tracking reset."""
        old_phase = self.state.phase
        self.state.phase = new_phase
        if self._tool_server is not None:
            self._tool_server._phase = new_phase
        self._phase_turns = 0
        self._phase_entered_at = time.time()
        self._nudge_sent = False

        self._event_bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.AGENT_PHASE_CHANGED,
            source=self.agent_id,
            data={
                "old_phase": old_phase.value,
                "new_phase": new_phase.value,
                "reason": reason,
            },
            timestamp=time.time(),
        ))
        logger.info("Agent %s phase: %s -> %s (%s)", self.agent_id, old_phase.value, new_phase.value, reason)

    def _check_phase_budget(self) -> str | None:
        """Check if the current phase has exceeded its turn/time budget.

        Returns a nudge message if near budget, or auto-transitions if over.
        Returns None if within budget.
        """
        phase = self.state.phase
        budget = _PHASE_TURN_BUDGET.get(phase, 30)
        time_limit = _PHASE_TIME_LIMIT.get(phase, 300.0)
        elapsed = time.time() - self._phase_entered_at

        # Over budget: force transition
        if self._phase_turns >= budget or elapsed >= time_limit:
            has_trades = self.state.trades > 0
            next_ph = _next_phase(phase, has_trades=has_trades)
            if next_ph is not None:
                # If restarting from RETIRING, limit restart attempts
                if phase == AgentPhase.RETIRING and next_ph == AgentPhase.RESEARCHING:
                    self._restart_count += 1
                    if self._restart_count >= 3:
                        # Stop after 3 restarts — agent can't find opportunities
                        return None
                reason = (
                    f"auto-advanced: {'turn budget' if self._phase_turns >= budget else 'time limit'} "
                    f"({self._phase_turns}/{budget} turns, {elapsed:.0f}s)"
                )
                self._transition_phase(next_ph, reason)
                return f"[SYSTEM] Auto-advanced to {next_ph.value}. Focus on this phase now."
            return None

        # Near budget (80%): send nudge
        near_turn = self._phase_turns >= int(budget * 0.8)
        near_time = elapsed >= time_limit * 0.8
        if (near_turn or near_time) and not self._nudge_sent:
            self._nudge_sent = True
            remaining_turns = budget - self._phase_turns
            remaining_time = max(0, time_limit - elapsed)
            return (
                f"[SYSTEM] {remaining_turns} turns and {remaining_time:.0f}s remaining in {phase.value}. "
                f"Wrap up and call transition_phase to advance."
            )

        return None

    async def _run_loop(self) -> None:
        """Main loop: cycle until stopped."""
        while self.state.status == AgentStatus.RUNNING:
            if self._paused:
                await asyncio.sleep(1)
                continue
            try:
                await self._run_cycle()
            except Exception as e:
                logger.error("Agent %s cycle error: %s", self.agent_id, e, exc_info=True)
                self.state.status = AgentStatus.ERROR
                self._event_bus.publish_sync("agents", SwarmEvent(
                    type=SwarmEventType.AGENT_ERROR,
                    source=self.agent_id,
                    data={"error": str(e)},
                    timestamp=time.time(),
                ))
                # Exponential backoff on repeated errors
                await asyncio.sleep(5)
                self.state.status = AgentStatus.RUNNING
            # Brief pause between cycles
            await asyncio.sleep(2)

    async def _run_cycle(self) -> None:
        """One agent thinking cycle with tool use."""
        if self._llm is None or self._tool_server is None:
            return

        self.state.uptime_s = time.time() - self._start_time

        # Check phase budget BEFORE building context
        budget_msg = self._check_phase_budget()

        # Build context
        context = build_agent_context(
            state=self.state,
            recent_events=list(self._recent_events),
            directives=list(self._directive_queue),
            knowledge_highlights=self._get_knowledge_highlights(),
            portfolio_summary=self._get_portfolio_summary(),
            phase_turns=self._phase_turns,
            phase_budget=_PHASE_TURN_BUDGET.get(self.state.phase, 30),
            phase_elapsed_s=time.time() - self._phase_entered_at,
        )

        system_prompt = get_agent_system_prompt(self.state)
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context},
        ]

        # Inject budget nudge/auto-advance message
        if budget_msg is not None:
            messages.append({"role": "user", "content": budget_msg})

        tools = self._tool_server.openai_tool_definitions

        # Agentic loop: call LLM, process tool calls, repeat until done
        turns = 0
        max_turns = self._config.max_turns_per_cycle
        prev_phase = self.state.phase

        while turns < max_turns:
            turns += 1
            self.state.turns += 1

            # Truncate message history if too long
            if len(messages) > _MAX_MESSAGES_PER_CYCLE:
                messages = messages[:2] + messages[-_TRUNCATE_TO:]

            # Stream LLM response, publishing deltas in real-time
            turn_num = turns  # capture for closure

            def _on_delta(delta: str, _tn: int = turn_num) -> None:
                self._event_bus.publish_sync("agents", SwarmEvent(
                    type=SwarmEventType.LLM_DELTA,
                    source=self.agent_id,
                    data={
                        "turn": _tn,
                        "delta": delta,
                        "phase": self.state.phase.value,
                    },
                    timestamp=time.time(),
                ))

            resp = await self._llm.stream(messages, tools, on_delta=_on_delta)

            # Handle LLM failure — don't count against phase budget
            if resp is None:
                self._consecutive_llm_failures += 1
                self.state.turns -= 1  # don't count failed turns
                # Publish error event so TUI shows something
                self._event_bus.publish_sync("agents", SwarmEvent(
                    type=SwarmEventType.LLM_TURN,
                    source=self.agent_id,
                    data={
                        "turn": turns,
                        "content": f"[LLM call failed — attempt {self._consecutive_llm_failures}, retrying...]",
                        "tool_calls": [],
                        "tool_args": [],
                        "phase": self.state.phase.value,
                        "error": True,
                    },
                    timestamp=time.time(),
                ))
                if self._consecutive_llm_failures >= 5:
                    logger.error("Agent %s: %d consecutive LLM failures, pausing", self.agent_id, self._consecutive_llm_failures)
                    self._event_bus.publish_sync("agents", SwarmEvent(
                        type=SwarmEventType.AGENT_ERROR,
                        source=self.agent_id,
                        data={"error": f"{self._consecutive_llm_failures} consecutive LLM failures"},
                        timestamp=time.time(),
                    ))
                    await asyncio.sleep(10)
                    self._consecutive_llm_failures = 0
                break

            # LLM succeeded — reset failure counter
            self._consecutive_llm_failures = 0
            self._phase_turns += 1

            # Sync cost from LLM client
            self.state.llm_cost_usd = self._llm.total_cost_usd

            # Append assistant message to conversation
            messages.append(resp.to_message())

            # Build tool call detail for the TUI
            tool_names = [tc.name for tc in resp.tool_calls]
            tool_args = []
            for tc in resp.tool_calls:
                try:
                    parsed = json.loads(tc.arguments)
                    # Abbreviate args: keep keys + short values
                    brief = {k: (str(v)[:60] if isinstance(v, str) else v) for k, v in parsed.items()
                             if not isinstance(v, (list, dict)) or len(str(v)) < 80}
                    tool_args.append(f"{tc.name}({json.dumps(brief, default=str)[:200]})")
                except Exception:
                    tool_args.append(f"{tc.name}({tc.arguments[:100]})")

            # Publish LLM turn summary to event bus — full content for TUI
            self._event_bus.publish_sync("agents", SwarmEvent(
                type=SwarmEventType.LLM_TURN,
                source=self.agent_id,
                data={
                    "turn": turns,
                    "content": (resp.content or "")[:2000],
                    "tool_calls": tool_names,
                    "tool_args": tool_args,
                    "phase": self.state.phase.value,
                },
                timestamp=time.time(),
            ))

            # No tool calls — LLM decided to stop
            if not resp.tool_calls:
                if resp.content:
                    self.state.last_action = resp.content[:200]
                break

            # Execute tool calls
            for tc in resp.tool_calls:
                try:
                    args = json.loads(tc.arguments)
                except json.JSONDecodeError:
                    args = {}

                result = await self._tool_server.call_tool(tc.name, args)
                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": json.dumps(result, default=str),
                })
                self.state.last_action = f"{tc.name}({tc.arguments[:100]})"

                # Detect phase change from tool server (transition_phase was called)
                if self._tool_server._phase != prev_phase:
                    new_phase = self._tool_server._phase
                    self.state.phase = new_phase
                    self._phase_turns = 0
                    self._phase_entered_at = time.time()
                    self._nudge_sent = False
                    prev_phase = new_phase
                    logger.info("Agent %s transitioned to %s via tool call", self.agent_id, new_phase.value)

            # Check phase budget mid-cycle
            mid_budget = self._check_phase_budget()
            if mid_budget is not None:
                messages.append({"role": "user", "content": mid_budget})

            # Check stop reason
            if resp.finish_reason == "stop":
                break

        # Final phase sync
        self.state.phase = self._tool_server._phase

        # Update state from engine
        self._update_state_from_engine()

        # Publish heartbeat with current state
        self._event_bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.HEARTBEAT,
            source=self.agent_id,
            data={
                "phase": self.state.phase.value,
                "pnl": self.state.pnl,
                "trades": self.state.trades,
                "turns": self.state.turns,
                "llm_cost_usd": self.state.llm_cost_usd,
                "last_action": self.state.last_action,
                "capital": self.state.capital_allocated,
                "markets": self.state.markets,
                "phase_turns": self._phase_turns,
            },
            timestamp=time.time(),
        ))

    def _update_state_from_engine(self) -> None:
        """Sync agent state from its engine."""
        engine = self._engine_pool.get_engine(self.agent_id)
        if engine is None:
            return
        try:
            status = engine.status()
            self.state.pnl = status.total_realized_pnl
            self.state.trades = len(engine.recent_fills())
            positions = engine.positions()
            self.state.markets = list({p.market_id for p in positions})
        except Exception:
            pass

    def _get_knowledge_highlights(self) -> list[dict[str, Any]]:
        """Get recent knowledge graph facts for context."""
        if self._kg is None:
            return []
        try:
            entities = self._kg.find_entities(limit=10)
            highlights = []
            for e in entities[:5]:
                facts = self._kg.get_facts(e["entity_id"], limit=3)
                for f in facts:
                    highlights.append({
                        "entity": e.get("name", e["entity_id"]),
                        "content": f.get("content", ""),
                        "confidence": f.get("confidence", 0),
                    })
            return highlights
        except Exception:
            return []

    def _get_portfolio_summary(self) -> dict[str, Any]:
        """Get the agent's portfolio summary."""
        engine = self._engine_pool.get_engine(self.agent_id)
        if engine is None:
            return {}
        try:
            status = engine.status()
            positions = engine.positions()
            return {
                "total_pnl": status.total_realized_pnl,
                "n_positions": len(positions),
                "open_orders": status.open_orders,
            }
        except Exception:
            return {}
