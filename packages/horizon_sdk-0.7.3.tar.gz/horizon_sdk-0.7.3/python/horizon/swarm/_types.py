"""Swarm quant agent system — all data structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class AgentPhase(str, Enum):
    IDLE = "idle"
    RESEARCHING = "researching"
    ANALYZING = "analyzing"
    BACKTESTING = "backtesting"
    ROBUSTNESS = "robustness"
    PROPOSING = "proposing"
    EXECUTING = "executing"
    MONITORING = "monitoring"
    EVOLVING = "evolving"
    RETIRING = "retiring"


class AgentStatus(str, Enum):
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"
    KILLED = "killed"


class ProposalVerdict(str, Enum):
    APPROVED = "approved"
    REJECTED = "rejected"
    REVISE = "revise"
    DEFERRED = "deferred"


class SwarmEventType(str, Enum):
    # Agent lifecycle
    AGENT_SPAWNED = "agent_spawned"
    AGENT_PHASE_CHANGED = "agent_phase_changed"
    AGENT_STOPPED = "agent_stopped"
    AGENT_ERROR = "agent_error"
    # Proposals
    PROPOSAL_SUBMITTED = "proposal_submitted"
    PROPOSAL_VERDICT = "proposal_verdict"
    # Trading
    ORDER_SUBMITTED = "order_submitted"
    FILL_RECEIVED = "fill_received"
    POSITION_OPENED = "position_opened"
    POSITION_CLOSED = "position_closed"
    # Risk
    CIRCUIT_BREAKER_TRIGGERED = "circuit_breaker_triggered"
    DRAWDOWN_ALERT = "drawdown_alert"
    RISK_LIMIT_HIT = "risk_limit_hit"
    # Hive
    HIVE_DIRECTIVE = "hive_directive"
    HIVE_CAPITAL_ALLOCATED = "hive_capital_allocated"
    HIVE_AGENT_SPAWNED = "hive_agent_spawned"
    # Knowledge
    KNOWLEDGE_SHARED = "knowledge_shared"
    INSIGHT_DISCOVERED = "insight_discovered"
    # LLM reasoning
    LLM_TURN = "llm_turn"
    LLM_DELTA = "llm_delta"
    # System
    HEARTBEAT = "heartbeat"
    METRICS_UPDATE = "metrics_update"
    SYSTEM_STATUS = "system_status"


@dataclass
class SwarmConfig:
    """Top-level configuration for the swarm system."""

    api_key: str  # OpenRouter API key (or any OpenAI-compatible provider)
    api_base: str = "https://openrouter.ai/api/v1"
    hive_model: str = "anthropic/claude-sonnet-4.6"
    agent_model: str = "openai/gpt-5.4-mini"
    max_agents: int = 20
    max_capital_usd: float = 10_000.0
    max_drawdown_pct: float = 0.10
    max_daily_loss_usd: float = 500.0
    ws_host: str = "127.0.0.1"
    ws_port: int = 8765
    circuit_breaker_interval_s: float = 2.0
    hive_oversight_interval_s: float = 30.0
    max_turns_per_cycle: int = 50
    exchange_backend: str = "paper"
    db_path: str = "swarm.db"


@dataclass
class Proposal:
    """Strategy proposal from an agent to the Hive for review."""

    proposal_id: str
    agent_id: str
    hypothesis: str
    market_id: str
    side: str
    edge_estimate: float
    kelly_fraction: float
    requested_capital: float
    backtest_results: dict[str, Any]
    robustness_results: dict[str, Any]
    reasoning: str
    anti_overfitting_proof: dict[str, Any]
    timestamp: float
    verdict: ProposalVerdict | None = None
    verdict_reasoning: str | None = None


@dataclass
class SwarmEvent:
    """Event flowing through the WebSocket event bus."""

    type: SwarmEventType
    source: str  # agent_id or "hive" or "circuit_breaker"
    data: dict[str, Any]
    timestamp: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.type.value,
            "source": self.source,
            "data": self.data,
            "timestamp": self.timestamp,
        }


@dataclass
class AgentState:
    """Mutable state for a single swarm agent."""

    agent_id: str
    phase: AgentPhase = AgentPhase.IDLE
    status: AgentStatus = AgentStatus.STOPPED
    mission: str | None = None
    markets: list[str] = field(default_factory=list)
    capital_allocated: float = 0.0
    pnl: float = 0.0
    trades: int = 0
    uptime_s: float = 0.0
    llm_cost_usd: float = 0.0
    last_action: str = ""
    turns: int = 0
    phase_turns: int = 0
    phase_started_at: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "phase": self.phase.value,
            "status": self.status.value,
            "mission": self.mission,
            "markets": self.markets,
            "capital_allocated": self.capital_allocated,
            "pnl": round(self.pnl, 4),
            "trades": self.trades,
            "uptime_s": round(self.uptime_s, 1),
            "llm_cost_usd": round(self.llm_cost_usd, 4),
            "last_action": self.last_action,
            "turns": self.turns,
            "phase_turns": self.phase_turns,
        }


@dataclass
class CircuitBreakerState:
    """State snapshot from the circuit breaker watchdog."""

    active: bool = False
    reason: str | None = None
    portfolio_drawdown_pct: float = 0.0
    daily_pnl_usd: float = 0.0
    triggered_at: float | None = None
    checks_run: int = 0
