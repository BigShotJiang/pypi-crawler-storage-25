"""Non-LLM circuit breaker watchdog for the swarm.

Runs as a daemon thread, checking portfolio-wide risk limits every N seconds.
No LLM is involved — pure math. Cannot be overridden by any LLM decision.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

from ._types import (
    CircuitBreakerState,
    SwarmConfig,
    SwarmEvent,
    SwarmEventType,
)
from ._event_bus import EventBus
from ._engine_pool import EnginePool

logger = logging.getLogger("horizon.swarm.circuit_breaker")


class CircuitBreaker:
    """Non-LLM portfolio-wide risk watchdog.

    4-layer risk architecture:
    1. Agent-level: Engine per-agent risk limits
    2. Rust engine: 8-point risk pipeline (compiled, non-bypassable)
    3. Circuit breaker (this): Portfolio-wide hard limits
    4. Hive oversight: Strategic risk (LLM, but cannot override layers 1-3)
    """

    def __init__(
        self,
        config: SwarmConfig,
        engine_pool: EnginePool,
        event_bus: EventBus,
    ) -> None:
        self._config = config
        self._engine_pool = engine_pool
        self._event_bus = event_bus

        self.state = CircuitBreakerState()

        # Agent references (set by Hive after construction)
        self._agents: dict[str, Any] = {}
        # Last heartbeat timestamp per agent
        self._last_heartbeat: dict[str, float] = {}
        # Daily P&L tracking
        self._daily_pnl_start: float = 0.0
        self._day_start_time: float = time.time()

        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    def set_agents(self, agents: dict[str, Any]) -> None:
        """Update agent references (called by Hive)."""
        self._agents = agents

    def record_heartbeat(self, agent_id: str) -> None:
        """Record a heartbeat from an agent."""
        self._last_heartbeat[agent_id] = time.time()

    def start(self) -> None:
        """Start the watchdog thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._watchdog_loop,
            name="circuit-breaker",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "Circuit breaker started (interval=%.1fs, max_dd=%.1f%%, max_daily_loss=$%.0f)",
            self._config.circuit_breaker_interval_s,
            self._config.max_drawdown_pct * 100,
            self._config.max_daily_loss_usd,
        )

    def stop(self) -> None:
        """Stop the watchdog thread."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None
        logger.info("Circuit breaker stopped")

    def _watchdog_loop(self) -> None:
        """Main watchdog loop — runs every circuit_breaker_interval_s."""
        while not self._stop_event.is_set():
            try:
                self._check()
            except Exception as e:
                logger.error("Circuit breaker check error: %s", e)
            self._stop_event.wait(self._config.circuit_breaker_interval_s)

    def _check(self) -> None:
        """Run all circuit breaker checks."""
        self.state.checks_run += 1

        # Reset daily tracking at day boundary
        now = time.time()
        if now - self._day_start_time > 86400:
            self._daily_pnl_start = self._engine_pool.aggregate_pnl()
            self._day_start_time = now

        total_pnl = self._engine_pool.aggregate_pnl()
        daily_pnl = total_pnl - self._daily_pnl_start
        total_capital = sum(
            a.state.capital_allocated
            for a in self._agents.values()
            if hasattr(a, "state")
        )

        # Check 1: Portfolio drawdown
        if total_capital > 0:
            drawdown_pct = abs(min(total_pnl, 0.0)) / total_capital
            self.state.portfolio_drawdown_pct = drawdown_pct
            if drawdown_pct >= self._config.max_drawdown_pct:
                self._trigger(
                    f"Portfolio drawdown {drawdown_pct:.1%} >= limit {self._config.max_drawdown_pct:.1%}"
                )
                return

        # Check 2: Daily P&L limit
        self.state.daily_pnl_usd = daily_pnl
        if daily_pnl <= -self._config.max_daily_loss_usd:
            self._trigger(
                f"Daily loss ${abs(daily_pnl):,.2f} >= limit ${self._config.max_daily_loss_usd:,.2f}"
            )
            return

        # Check 3: Per-agent capital breach
        for agent_id, agent in self._agents.items():
            if not hasattr(agent, "state"):
                continue
            engine = self._engine_pool.get_engine(agent_id)
            if engine is None:
                continue
            try:
                positions = engine.positions()
                notional = sum(abs(p.size * p.avg_price) for p in positions)
                if notional > agent.state.capital_allocated * 1.5 and agent.state.capital_allocated > 0:
                    logger.warning(
                        "Agent %s notional $%.2f > 1.5x capital $%.2f — pausing",
                        agent_id, notional, agent.state.capital_allocated,
                    )
                    agent.pause()
                    self._event_bus.publish_sync("risk", SwarmEvent(
                        type=SwarmEventType.RISK_LIMIT_HIT,
                        source="circuit_breaker",
                        data={
                            "agent_id": agent_id,
                            "notional": notional,
                            "capital": agent.state.capital_allocated,
                        },
                        timestamp=time.time(),
                    ))
            except Exception:
                pass

        # Check 4: Agent heartbeat (stuck detection)
        for agent_id, agent in self._agents.items():
            if not hasattr(agent, "state"):
                continue
            if agent.state.status.value not in ("running",):
                continue
            last_hb = self._last_heartbeat.get(agent_id, now)
            if now - last_hb > 300:  # 5 minutes with no heartbeat
                logger.warning("Agent %s appears stuck (no heartbeat for 5min)", agent_id)
                self._event_bus.publish_sync("risk", SwarmEvent(
                    type=SwarmEventType.AGENT_ERROR,
                    source="circuit_breaker",
                    data={"agent_id": agent_id, "reason": "stuck_no_heartbeat"},
                    timestamp=time.time(),
                ))

    def _trigger(self, reason: str) -> None:
        """Emergency stop: cancel all orders, pause all agents."""
        if self.state.active:
            return  # Already triggered

        logger.critical("CIRCUIT BREAKER TRIGGERED: %s", reason)
        self.state.active = True
        self.state.reason = reason
        self.state.triggered_at = time.time()

        # Cancel all orders across all engines
        cancelled = self._engine_pool.cancel_all_orders()
        logger.critical("Emergency cancelled %d orders", cancelled)

        # Pause all agents
        for agent_id, agent in self._agents.items():
            if hasattr(agent, "pause"):
                agent.pause()
                logger.critical("Paused agent %s", agent_id)

        self._event_bus.publish_sync("risk", SwarmEvent(
            type=SwarmEventType.CIRCUIT_BREAKER_TRIGGERED,
            source="circuit_breaker",
            data={
                "reason": reason,
                "orders_cancelled": cancelled,
                "agents_paused": len(self._agents),
            },
            timestamp=time.time(),
        ))

    def reset(self) -> None:
        """Manually reset the circuit breaker (requires human intervention)."""
        self.state.active = False
        self.state.reason = None
        self.state.triggered_at = None
        logger.info("Circuit breaker manually reset")
