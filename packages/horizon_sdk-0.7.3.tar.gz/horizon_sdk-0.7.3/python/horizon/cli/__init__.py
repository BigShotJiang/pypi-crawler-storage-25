"""Horizon CLI - prediction market trading SDK.

Usage:
    horizon [--json] COMMAND [ARGS]
    uvx horizon-sdk COMMAND [ARGS]
"""

from __future__ import annotations

import click


@click.group()
@click.option("--json", "json_mode", is_flag=True, help="Output as JSON (pipeable)")
@click.version_option(package_name="horizon-sdk")
@click.pass_context
def cli(ctx, json_mode: bool):
    """Horizon - prediction market trading SDK.

    \b
    Trade prediction markets from the command line.
    Discover markets, submit orders, analyze wallets, and manage funds.

    \b
    Quick start:
      horizon discover "election"
      horizon top-markets --limit 5
      horizon kelly --prob 0.65 --price 0.50 --bankroll 1000
      horizon wallet value 0x1234...abcd

    \b
    Run a strategy:
      horizon run my_strategy.py --mode paper --dashboard

    \b
    All commands support --json for pipeable output:
      horizon discover "bitcoin" --json | jq '.[0].slug'
    """
    ctx.ensure_object(dict)
    ctx.obj["json"] = json_mode


def _register():
    """Register all commands and groups."""
    from horizon.cli.run import run
    from horizon.cli.engine import (
        status, submit, cancel, cancel_all, kill_switch,
        positions, orders, fills, cancel_market,
        stop_loss, take_profit, contingent_orders, arb,
        copy_trades, stealth_estimate, stealth_execute,
        portfolio_metrics, portfolio_weights,
        runtime_params, set_params,
    )
    from horizon.cli.discovery import discover, events, top_markets, market
    from horizon.cli.feeds import feed
    from horizon.cli.wallet import wallet
    from horizon.cli.analytics import kelly, parity, simulate
    from horizon.cli.fund import fund
    from horizon.cli.account import setup, login, key_status
    from horizon.cli.db import db
    from horizon.cli.intelligence import intel
    from horizon.cli.hedge import hedge
    from horizon.cli.quant import quant
    from horizon.cli.providers import providers
    from horizon.cli.equity import equity
    from horizon.cli.hive import hive

    # Strategy
    cli.add_command(run)

    # Engine
    cli.add_command(status)
    cli.add_command(submit)
    cli.add_command(cancel)
    cli.add_command(cancel_all)
    cli.add_command(cancel_market)
    cli.add_command(kill_switch)
    cli.add_command(positions)
    cli.add_command(orders)
    cli.add_command(fills)
    cli.add_command(stop_loss)
    cli.add_command(take_profit)
    cli.add_command(contingent_orders)
    cli.add_command(arb)
    cli.add_command(copy_trades)
    cli.add_command(stealth_estimate)
    cli.add_command(stealth_execute)
    cli.add_command(portfolio_metrics)
    cli.add_command(portfolio_weights)
    cli.add_command(runtime_params)
    cli.add_command(set_params)

    # Discovery
    cli.add_command(discover)
    cli.add_command(events)
    cli.add_command(top_markets)
    cli.add_command(market)

    # Analytics
    cli.add_command(kelly)
    cli.add_command(parity)
    cli.add_command(simulate)

    # Account
    cli.add_command(setup)
    cli.add_command(login)
    cli.add_command(key_status)

    # Groups
    cli.add_command(feed)
    cli.add_command(wallet)
    cli.add_command(fund)
    cli.add_command(db)
    cli.add_command(intel)
    cli.add_command(hedge)
    cli.add_command(quant)
    cli.add_command(providers)
    cli.add_command(equity)
    cli.add_command(hive)


_register()
