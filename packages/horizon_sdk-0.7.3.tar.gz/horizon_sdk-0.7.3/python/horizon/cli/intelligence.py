"""Intelligence commands: oracle, whale, LLM, sniper, sentinel, resolution."""

from __future__ import annotations

import click


@click.group()
def intel():
    """Market intelligence and signal scanning."""
    pass


@intel.command()
@click.pass_context
def sentinel(ctx):
    """Generate a sentinel risk report."""
    from horizon.tools import get_sentinel_report
    from horizon.cli._fmt import output

    output(get_sentinel_report(), json_mode=ctx.obj.get("json", False))


@intel.command("oracle-forecast")
@click.argument("market_id")
@click.pass_context
def oracle_forecast(ctx, market_id):
    """Get oracle probability forecast for a market."""
    from horizon.tools import oracle_forecast_market
    from horizon.cli._fmt import output

    output(oracle_forecast_market(market_id=market_id), json_mode=ctx.obj.get("json", False))


@intel.command("oracle-scan")
@click.option("--exchange", default="polymarket", help="Exchange to scan")
@click.option("--limit", default=10, type=int, help="Number of markets")
@click.pass_context
def oracle_scan(ctx, exchange, limit):
    """Scan for oracle edge opportunities."""
    from horizon.tools import oracle_scan_edges
    from horizon.cli._fmt import output

    output(oracle_scan_edges(exchange=exchange, limit=limit), json_mode=ctx.obj.get("json", False))


@intel.command("whale-scan")
@click.option("--exchange", default="polymarket", help="Exchange to scan")
@click.option("--limit", default=10, type=int, help="Number of results")
@click.pass_context
def whale_scan(ctx, exchange, limit):
    """Scan for whale galaxy signals."""
    from horizon.tools import whale_galaxy_scan
    from horizon.cli._fmt import output

    output(whale_galaxy_scan(exchange=exchange, limit=limit), json_mode=ctx.obj.get("json", False))


@intel.command("llm-forecast")
@click.argument("market_id")
@click.pass_context
def llm_forecast(ctx, market_id):
    """Get LLM probability forecast for a market."""
    from horizon.tools import llm_forecast_market
    from horizon.cli._fmt import output

    output(llm_forecast_market(market_id=market_id), json_mode=ctx.obj.get("json", False))


@intel.command("llm-scan")
@click.option("--exchange", default="polymarket", help="Exchange to scan")
@click.option("--limit", default=10, type=int, help="Number of markets")
@click.pass_context
def llm_scan(ctx, exchange, limit):
    """Scan markets with LLM for edge."""
    from horizon.tools import llm_scan_markets
    from horizon.cli._fmt import output

    output(llm_scan_markets(exchange=exchange, limit=limit), json_mode=ctx.obj.get("json", False))


@intel.command("resolution")
@click.argument("market_id")
@click.pass_context
def resolution(ctx, market_id):
    """Analyze market resolution likelihood."""
    from horizon.tools import analyze_resolution_tool
    from horizon.cli._fmt import output

    output(analyze_resolution_tool(market_id=market_id), json_mode=ctx.obj.get("json", False))


@intel.command("sniper")
@click.option("--exchange", default="polymarket", help="Exchange to scan")
@click.option("--limit", default=10, type=int, help="Number of results")
@click.pass_context
def sniper(ctx, exchange, limit):
    """Scan for sniper entry opportunities."""
    from horizon.tools import sniper_scan_tool
    from horizon.cli._fmt import output

    output(sniper_scan_tool(exchange=exchange, limit=limit), json_mode=ctx.obj.get("json", False))


@intel.command("bot-scan")
@click.argument("market_id")
@click.pass_context
def bot_scan(ctx, market_id):
    """Detect bot activity in a market."""
    from horizon.tools import market_bot_scan
    from horizon.cli._fmt import output

    output(market_bot_scan(market_id=market_id), json_mode=ctx.obj.get("json", False))
