"""Hive swarm intelligence commands."""

from __future__ import annotations

import os
from typing import Any

import click


# ---------------------------------------------------------------------------
# Hive accessor
# ---------------------------------------------------------------------------

_hive_instance: Any = None


def _get_hive():
    """Return a HiveController (local) or HiveClient (remote).

    Resolution order:
    1. Module-level singleton (set by ``set_hive()``)
    2. HIVE_URL env var -> HiveClient with optional HIVE_TOKEN
    3. Lazy-init a local HiveController with default config
    """
    global _hive_instance
    if _hive_instance is not None:
        return _hive_instance

    url = os.environ.get("HIVE_URL")
    if url:
        from horizon.hive import HiveClient
        token = os.environ.get("HIVE_TOKEN", "")
        client = HiveClient(url, token=token)
        if not client.connect():
            raise click.ClickException(f"Failed to connect to Hive at {url}")
        _hive_instance = client
        return client

    # Local controller
    from horizon.hive import HiveController, HiveConfig
    ctrl = HiveController(HiveConfig())
    _hive_instance = ctrl
    return ctrl


def set_hive(instance: Any) -> None:
    """Inject a HiveController or HiveClient for CLI use."""
    global _hive_instance
    _hive_instance = instance


def _is_remote(h: Any) -> bool:
    """True when ``h`` is a HiveClient (remote connection)."""
    return type(h).__name__ == "HiveClient"


# ---------------------------------------------------------------------------
# Click group
# ---------------------------------------------------------------------------

@click.group()
def hive():
    """Hive swarm intelligence commands."""
    pass


# ---------------------------------------------------------------------------
# 1. status
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def status(ctx):
    """Show Hive status: agents, mode, capital, criticality."""
    from horizon.cli._fmt import output

    h = _get_hive()
    output(h.status(), json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 2. agents
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def agents(ctx):
    """List all agents with fitness rankings."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.agents()
    else:
        data = h.coordinator.agent_ranking()

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 3. agent <agent_id>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("agent_id")
@click.pass_context
def agent(ctx, agent_id):
    """Show detailed info for a specific agent."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.agent(agent_id)
    else:
        a = h.coordinator.get_agent(agent_id)
        if a is None:
            raise click.ClickException(f"Agent not found: {agent_id}")
        data = a.to_dict()

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 4. spawn <template> <markets>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("template")
@click.argument("markets", nargs=-1, required=True)
@click.option("--capital", default=0.0, type=float, help="Initial capital allocation")
@click.option("--mutate", is_flag=True, help="Apply random mutation to template genome")
@click.pass_context
def spawn(ctx, template, markets, capital, mutate):
    """Spawn a new agent from a strategy template.

    \b
    Example:
      horizon hive spawn momentum BTC-USD ETH-USD --capital 5000
      horizon hive spawn mean_reversion BTC-USD --mutate
    """
    from horizon.cli._fmt import output

    h = _get_hive()
    market_list = list(markets)

    if _is_remote(h):
        data = h.spawn(template=template, markets=market_list, capital=capital)
    else:
        if mutate:
            from horizon.hive._types import StrategyArchetype, StrategyGenome, SpawnSource
            try:
                archetype = StrategyArchetype(template)
            except ValueError:
                raise click.ClickException(
                    f"Unknown template: {template}. "
                    f"Use 'horizon hive templates' to list available templates."
                )
            genome = StrategyGenome(
                source=SpawnSource.EVOLUTION,
                archetype=archetype,
                target_markets=market_list,
            )
            agent = h.spawn_agent(
                template=template, markets=market_list,
                capital=capital, genome=genome,
            )
        else:
            agent = h.spawn_agent(
                template=template, markets=market_list, capital=capital,
            )

        if agent is None:
            data = {"error": "Failed to spawn agent (at capacity or awaiting approval)"}
        else:
            data = agent.to_dict()

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 5. kill <agent_id>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("agent_id")
@click.option("--reason", default="", help="Reason for termination")
@click.pass_context
def kill(ctx, agent_id, reason):
    """Terminate an agent."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.kill(agent_id, reason=reason)
    else:
        ok = h.coordinator.kill_agent(agent_id, reason or "cli_kill")
        data = {"agent_id": agent_id, "killed": ok}
        if not ok:
            data["error"] = f"Agent not found: {agent_id}"

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 6. pause <agent_id>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("agent_id")
@click.pass_context
def pause(ctx, agent_id):
    """Pause an agent (keeps state)."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.pause(agent_id)
    else:
        ok = h.coordinator.pause_agent(agent_id, "cli_pause")
        data = {"agent_id": agent_id, "paused": ok}
        if not ok:
            data["error"] = f"Agent not found: {agent_id}"

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 7. resume <agent_id>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("agent_id")
@click.pass_context
def resume(ctx, agent_id):
    """Resume a paused agent."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.resume(agent_id)
    else:
        ok = h.coordinator.resume_agent(agent_id)
        data = {"agent_id": agent_id, "resumed": ok}
        if not ok:
            data["error"] = f"Agent not found or not paused: {agent_id}"

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 8. scale <agent_id> <capital>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("agent_id")
@click.argument("capital", type=float)
@click.pass_context
def scale(ctx, agent_id, capital):
    """Scale an agent's capital allocation.

    Example: horizon hive scale hv-a1b2c3d4 10000
    """
    from horizon.cli._fmt import output

    if capital < 0:
        raise click.ClickException("Capital must be non-negative")

    h = _get_hive()
    if _is_remote(h):
        data = h.scale(agent_id, capital)
    else:
        ok = h.coordinator.scale_agent(agent_id, capital)
        data = {"agent_id": agent_id, "capital": capital, "scaled": ok}
        if not ok:
            data["error"] = f"Agent not found: {agent_id}"

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 9. mode [mode_value]
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("mode_value", required=False, default=None)
@click.pass_context
def mode(ctx, mode_value):
    """Get or set the Hive autonomy mode.

    \b
    Modes: observe, suggest, supervised, autonomous, skynet

    \b
    Example:
      horizon hive mode              # show current mode
      horizon hive mode supervised   # set mode to supervised
    """
    from horizon.cli._fmt import output

    h = _get_hive()

    if mode_value is None:
        # GET mode
        if _is_remote(h):
            data = {"mode": h.mode()}
        else:
            data = h.autonomy.status()
    else:
        # SET mode
        valid_modes = ("observe", "suggest", "supervised", "autonomous", "skynet")
        if mode_value not in valid_modes:
            raise click.ClickException(
                f"Invalid mode: {mode_value}. Must be one of: {', '.join(valid_modes)}"
            )

        if _is_remote(h):
            data = h.set_mode(mode_value)
        else:
            from horizon.hive._types import AutonomyMode
            h.autonomy.set_mode(AutonomyMode(mode_value))
            data = {"mode": mode_value, "set": True}

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 10. pending
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def pending(ctx):
    """Show pending approval decisions."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.pending_approvals()
    else:
        decisions = h.autonomy.pending()
        data = [d.to_dict() for d in decisions]

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 11. approve <decision_id>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("decision_id")
@click.pass_context
def approve(ctx, decision_id):
    """Approve a pending decision."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.approve(decision_id)
    else:
        decision = h.autonomy.approve(decision_id)
        if decision is None:
            data = {"error": f"Decision not found: {decision_id}"}
        else:
            data = decision.to_dict()
            data["approved"] = True

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 12. reject <decision_id>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("decision_id")
@click.option("--reason", default="", help="Reason for rejection")
@click.pass_context
def reject(ctx, decision_id, reason):
    """Reject a pending decision."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.reject(decision_id, reason=reason)
    else:
        decision = h.autonomy.reject(decision_id, reason=reason)
        if decision is None:
            data = {"error": f"Decision not found: {decision_id}"}
        else:
            data = decision.to_dict()
            data["rejected"] = True

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 13. evolve
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def evolve(ctx):
    """Run one evolution cycle."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.evolve()
    else:
        data = h.run_evolution_cycle()

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 14. dream
# ---------------------------------------------------------------------------

@hive.command()
@click.option("--generations", default=None, type=int,
              help="Number of dream generations (default: config value)")
@click.pass_context
def dream(ctx, generations):
    """Start a dream state — accelerated offline evolution.

    \b
    Example:
      horizon hive dream
      horizon hive dream --generations 50000
    """
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.dream(generations=generations)
    else:
        report = h.dream.dream(generations=generations)
        data = report.to_dict() if hasattr(report, "to_dict") else {"status": "complete"}

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 15. pheromone [market_id]
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("market_id", required=False, default=None)
@click.pass_context
def pheromone(ctx, market_id):
    """Show the pheromone field (all markets or a specific market).

    \b
    Example:
      horizon hive pheromone                  # all markets
      horizon hive pheromone BTC-USD          # single market
    """
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.pheromone(market_id=market_id or "")
    else:
        if market_id:
            mp = h.pheromone.sense(market_id)
            data = {"market_id": market_id, **mp.as_dict()}
        else:
            data = h.pheromone.snapshot()

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 16. reputation
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def reputation(ctx):
    """Show agent reputation rankings."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "reputation")
    else:
        rankings = h.reputation.ranking()
        data = [
            {"agent_id": aid, "reputation": round(score, 4),
             "confidence": round(conf, 4)}
            for aid, score, conf in rankings
        ]

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 17. consensus
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def consensus(ctx):
    """Show internal prediction markets."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "consensus")
    else:
        markets = h.consensus.active_markets()
        data = [
            {
                "market_id": m.market_id,
                "question": m.question,
                "consensus_probability": round(m.consensus_probability, 4),
                "views_count": len(m.views),
                "resolved": m.resolved,
            }
            for m in markets
        ]

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 18. incidents
# ---------------------------------------------------------------------------

@hive.command()
@click.option("--limit", default=50, type=int, help="Number of incidents to show")
@click.pass_context
def incidents(ctx, limit):
    """Show incident history."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "incidents", {"limit": limit})
    else:
        active = h.kill_chain.active_incidents()
        history = h.kill_chain.incident_history(limit=limit)
        all_incidents = active + history
        data = [
            {
                "incident_id": i.incident_id,
                "severity": f"SEV{i.severity.value}",
                "trigger": i.trigger,
                "state": i.state,
                "affected_agents": len(i.affected_agents),
                "pnl_impact": round(i.pnl_impact, 4),
                "created_at": i.created_at,
            }
            for i in all_incidents[:limit]
        ]

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 19. kill-switch
# ---------------------------------------------------------------------------

@hive.command("kill-switch")
@click.confirmation_option(prompt="This will halt ALL agents. Are you sure?")
@click.pass_context
def kill_switch(ctx):
    """Emergency halt all agents."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h.kill_switch()
    else:
        h.kill_switch()
        data = {"kill_switch": "activated", "agents_paused": "all"}

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 20. criticality
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def criticality(ctx):
    """Show the criticality report (15-indicator assessment)."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "criticality")
    else:
        report = h.last_criticality
        if report is None:
            data = {"warning_count": 0, "is_critical": False, "message": "No assessment yet"}
        else:
            data = {
                "warning_count": report.warning_count(),
                "is_critical": report.is_critical(),
                "correlation_convergence": round(report.correlation_convergence, 4),
                "contagion_score": round(report.contagion_score, 4),
                "regime_shift_detected": report.regime_shift_detected,
                "hurst_exponent": round(report.hurst_exponent, 4),
                "vol_signature_noise": round(report.vol_signature_noise, 4),
                "two_scale_vol_ratio": round(report.two_scale_vol_ratio, 4),
                "market_entropy": round(report.market_entropy, 4),
                "transfer_entropy_surge": round(report.transfer_entropy_surge, 4),
                "vpin_aggregate": round(report.vpin_aggregate, 4),
                "liquidity_score": round(report.liquidity_score, 4),
                "spread_widening": round(report.spread_widening, 4),
                "amihud_ratio": round(report.amihud_ratio, 4),
                "bocpd_probability": round(report.bocpd_probability, 4),
                "cusum_trigger_count": report.cusum_trigger_count,
                "vine_tail_risk": round(report.vine_tail_risk, 4),
                "timestamp": report.timestamp,
            }

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 21. imprint
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def imprint(ctx):
    """Show imprint system status (user behavior learning)."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "imprint")
    else:
        data = h.imprint.status()

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 22. impact
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def impact(ctx):
    """Show self-impact model status."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "impact")
    else:
        data = h.impact.status()

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 23. templates
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def templates(ctx):
    """List available strategy templates."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "templates")
    else:
        names = h.factory.available_templates()
        data = [
            {"template": name, **h.factory.template_config(name)}
            for name in names
        ]

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 24. connect <host:port>
# ---------------------------------------------------------------------------

@hive.command()
@click.argument("host_port")
@click.option("--token", default="", help="Authentication token")
@click.pass_context
def connect(ctx, host_port, token):
    """Connect to a remote Hive server.

    \b
    Example:
      horizon hive connect ws://hive-server:8780 --token secret
      horizon hive connect localhost:8780
    """
    from horizon.cli._fmt import output

    url = host_port
    if not url.startswith("ws://") and not url.startswith("wss://"):
        url = f"ws://{url}"

    from horizon.hive import HiveClient
    client = HiveClient(url, token=token)
    ok = client.connect()

    if ok:
        set_hive(client)
        data = {"connected": True, "url": url, "status": client.status()}
    else:
        data = {"error": f"Failed to connect to {url}"}

    output(data, json_mode=ctx.obj.get("json", False))


# ---------------------------------------------------------------------------
# 25. server
# ---------------------------------------------------------------------------

@hive.command()
@click.pass_context
def server(ctx):
    """Show Hive server status."""
    from horizon.cli._fmt import output

    h = _get_hive()
    if _is_remote(h):
        data = h._request("query", "server")
    else:
        data = h.server.status()

    output(data, json_mode=ctx.obj.get("json", False))
