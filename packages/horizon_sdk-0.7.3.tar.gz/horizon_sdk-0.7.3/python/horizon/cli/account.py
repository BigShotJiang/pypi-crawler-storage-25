"""Account management commands: setup, login, key-status."""

from __future__ import annotations

import click


@click.command()
@click.argument("email")
@click.option("--password", default="", help="Account password (or set HORIZON_PASSWORD)")
@click.option("--name", default="", help="Display name")
@click.pass_context
def setup(ctx, email, password, name):
    """Create a Horizon account and generate an SDK key.

    Example: horizon setup user@example.com --name "My Bot"
    """
    from horizon.tools import horizon_setup
    from horizon.cli._fmt import output

    result = horizon_setup(email=email, password=password, name=name)
    output(result, json_mode=ctx.obj.get("json", False))


@click.command()
@click.argument("email")
@click.option("--password", default="", help="Account password (or set HORIZON_PASSWORD)")
@click.pass_context
def login(ctx, email, password):
    """Login to Horizon and generate a new SDK key.

    Example: horizon login user@example.com
    """
    from horizon.tools import horizon_login
    from horizon.cli._fmt import output

    result = horizon_login(email=email, password=password)
    output(result, json_mode=ctx.obj.get("json", False))


@click.command("key-status")
@click.pass_context
def key_status(ctx):
    """Check API key configuration status."""
    from horizon.tools import horizon_key_status
    from horizon.cli._fmt import output

    output(horizon_key_status(), json_mode=ctx.obj.get("json", False))
