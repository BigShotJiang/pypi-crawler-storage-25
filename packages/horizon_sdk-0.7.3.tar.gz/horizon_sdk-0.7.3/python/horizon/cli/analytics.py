"""Analytics commands: kelly, parity, simulate."""

from __future__ import annotations

import click


@click.command()
@click.option("--prob", required=True, type=float, help="True probability estimate (0-1)")
@click.option("--price", required=True, type=float, help="Current market price (0-1)")
@click.option("--bankroll", default=1000.0, type=float, help="Available capital in USD")
@click.option("--fraction", default=0.25, type=float, help="Kelly fraction (0.25 = quarter Kelly)")
@click.option("--max-size", default=100.0, type=float, help="Maximum position size")
@click.pass_context
def kelly(ctx, prob, price, bankroll, fraction, max_size):
    """Compute Kelly-optimal position size.

    \b
    Examples:
      horizon kelly --prob 0.65 --price 0.50 --bankroll 1000
      horizon kelly --prob 0.7 --price 0.55 --bankroll 5000 --fraction 0.5
    """
    from horizon.tools import kelly_sizing
    from horizon.cli._fmt import output

    result = kelly_sizing(
        prob=prob,
        price=price,
        bankroll=bankroll,
        fraction=fraction,
        max_size=max_size,
    )
    output(result, json_mode=ctx.obj.get("json", False))


@click.command()
@click.argument("market_id")
@click.option("--feed", "feed_name", default=None, help="Feed name to check against")
@click.pass_context
def parity(ctx, market_id, feed_name):
    """Check YES/NO price parity for a market.

    Verifies that YES + NO prices sum to ~1.0 (no arbitrage).

    Example: horizon parity "will-btc-hit-100k"
    """
    from horizon.tools import check_parity
    from horizon.cli._fmt import output

    output(check_parity(market_id=market_id, feed_name=feed_name), json_mode=ctx.obj.get("json", False))


@click.command()
@click.option("--scenarios", default=10000, type=int, help="Number of Monte Carlo scenarios")
@click.option("--seed", default=None, type=int, help="Random seed for reproducibility")
@click.pass_context
def simulate(ctx, scenarios, seed):
    """Run Monte Carlo simulation on current positions.

    Example: horizon simulate --scenarios 50000
    """
    from horizon.tools import simulate_portfolio
    from horizon.cli._fmt import output

    result = simulate_portfolio(scenarios=scenarios, seed=seed)
    output(result, json_mode=ctx.obj.get("json", False))
