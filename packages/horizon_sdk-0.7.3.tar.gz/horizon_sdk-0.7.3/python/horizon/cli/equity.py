"""Equity and options commands."""

from __future__ import annotations

import click


@click.group()
def equity():
    """Equity and options tools: quotes, options chains, Greeks, screener.
    Convenience wrappers — for full provider API access, use `horizon providers uw`."""
    pass


@equity.command("quote")
@click.argument("symbol")
@click.pass_context
def quote(ctx, symbol):
    """Get a stock quote.

    \b
    Examples:
      horizon equity quote AAPL
      horizon equity quote TSLA --json
    """
    from horizon.cli._fmt import output

    try:
        from horizon.provider_tools import uw_stock_info
        result = uw_stock_info(symbol.upper())
    except Exception as e:
        result = {"error": str(e)}
    output(result, json_mode=ctx.obj.get("json", False))


@equity.command("search")
@click.argument("query")
@click.option("--limit", default=10, help="Number of results")
@click.pass_context
def search(ctx, query, limit):
    """Search for stocks by name or symbol.

    \b
    Examples:
      horizon equity search "apple"
      horizon equity search "tech" --limit 5
    """
    from horizon.cli._fmt import output

    try:
        from horizon.provider_tools import uw_screener_stocks
        result = uw_screener_stocks()
        # Filter by query if we got a list
        if isinstance(result, list):
            q = query.lower()
            result = [r for r in result if q in str(r).lower()][:limit]
    except Exception as e:
        result = {"error": str(e)}
    output(result, json_mode=ctx.obj.get("json", False))


@equity.command("options-chain")
@click.argument("symbol")
@click.option("--expiry", default=None, help="Expiration date (YYYY-MM-DD)")
@click.pass_context
def options_chain(ctx, symbol, expiry):
    """Get options chain for a symbol.

    \b
    Examples:
      horizon equity options-chain AAPL
      horizon equity options-chain SPY --expiry 2026-04-17
    """
    from horizon.cli._fmt import output

    try:
        from horizon.provider_tools import uw_option_chains
        result = uw_option_chains(symbol.upper())
        if expiry and isinstance(result, list):
            result = [r for r in result if expiry in str(r.get("expiration", ""))]
    except Exception as e:
        result = {"error": str(e)}
    output(result, json_mode=ctx.obj.get("json", False))


@equity.command("greeks")
@click.argument("symbol")
@click.pass_context
def greeks(ctx, symbol):
    """Get Greek exposure for a symbol.

    \b
    Examples:
      horizon equity greeks AAPL
      horizon equity greeks SPY
    """
    from horizon.cli._fmt import output

    try:
        from horizon.provider_tools import uw_greek_exposure
        result = uw_greek_exposure(symbol.upper())
    except Exception as e:
        result = {"error": str(e)}
    output(result, json_mode=ctx.obj.get("json", False))


@equity.command("iv-surface")
@click.argument("symbol")
@click.pass_context
def iv_surface(ctx, symbol):
    """Get implied volatility term structure.

    \b
    Examples:
      horizon equity iv-surface AAPL
      horizon equity iv-surface TSLA
    """
    from horizon.cli._fmt import output

    try:
        from horizon.provider_tools import uw_vol_term_structure
        result = uw_vol_term_structure(symbol.upper())
    except Exception as e:
        result = {"error": str(e)}
    output(result, json_mode=ctx.obj.get("json", False))


@equity.command("screener")
@click.option("--sector", default=None, help="Filter by sector")
@click.option("--limit", default=20, help="Number of results")
@click.pass_context
def screener(ctx, sector, limit):
    """Screen stocks by criteria.

    \b
    Examples:
      horizon equity screener
      horizon equity screener --sector tech --limit 10
    """
    from horizon.cli._fmt import output

    try:
        from horizon.provider_tools import uw_screener_stocks
        result = uw_screener_stocks()
        if isinstance(result, list):
            if sector:
                s = sector.lower()
                result = [r for r in result if s in str(r.get("sector", "")).lower()]
            result = result[:limit]
    except Exception as e:
        result = {"error": str(e)}
    output(result, json_mode=ctx.obj.get("json", False))
