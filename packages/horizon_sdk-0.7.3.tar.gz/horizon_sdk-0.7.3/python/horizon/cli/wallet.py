"""Wallet analytics commands."""

from __future__ import annotations

import click


@click.group()
def wallet():
    """Wallet analytics and flow analysis."""
    pass


@wallet.command()
@click.argument("address")
@click.option("--limit", default=50, help="Number of trades")
@click.option("--condition-id", default=None, help="Filter by condition ID")
@click.pass_context
def trades(ctx, address, limit, condition_id):
    """Show trade history for a Polymarket wallet.

    Example: horizon wallet trades 0x1234...abcd --limit 20
    """
    from horizon.tools import wallet_trades
    from horizon.cli._fmt import output

    result = wallet_trades(address=address, limit=limit, condition_id=condition_id)
    output(result, json_mode=ctx.obj.get("json", False))


@wallet.command()
@click.argument("address")
@click.pass_context
def positions(ctx, address):
    """Show open positions for a Polymarket wallet.

    Example: horizon wallet positions 0x1234...abcd
    """
    from horizon.tools import wallet_positions
    from horizon.cli._fmt import output

    output(wallet_positions(address=address), json_mode=ctx.obj.get("json", False))


@wallet.command()
@click.argument("address")
@click.pass_context
def value(ctx, address):
    """Show total USD value of a wallet's positions.

    Example: horizon wallet value 0x1234...abcd
    """
    from horizon.tools import wallet_value
    from horizon.cli._fmt import output

    output(wallet_value(address=address), json_mode=ctx.obj.get("json", False))


@wallet.command()
@click.argument("address")
@click.pass_context
def profile(ctx, address):
    """Show public profile for a Polymarket wallet.

    Example: horizon wallet profile 0x1234...abcd
    """
    from horizon.tools import wallet_profile
    from horizon.cli._fmt import output

    output(wallet_profile(address=address), json_mode=ctx.obj.get("json", False))


@wallet.command("top-holders")
@click.argument("condition_id")
@click.option("--limit", default=20, help="Number of holders")
@click.pass_context
def top_holders(ctx, condition_id, limit):
    """Show largest position holders in a market.

    Example: horizon wallet top-holders 0xabc123... --limit 10
    """
    from horizon.tools import market_top_holders
    from horizon.cli._fmt import output

    output(market_top_holders(condition_id=condition_id, limit=limit), json_mode=ctx.obj.get("json", False))


@wallet.command()
@click.argument("condition_id")
@click.option("--window", default=24, type=int, help="Time window in hours")
@click.option("--min-size", default=100.0, type=float, help="Minimum trade size")
@click.pass_context
def flow(ctx, condition_id, window, min_size):
    """Analyze buy/sell flow for a market.

    Example: horizon wallet flow 0xabc123... --window 12 --min-size 500
    """
    from horizon.tools import market_flow
    from horizon.cli._fmt import output

    result = market_flow(condition_id=condition_id, window_hours=window, min_size=min_size)
    output(result, json_mode=ctx.obj.get("json", False))


@wallet.command("market-trades")
@click.argument("condition_id")
@click.option("--limit", default=50, help="Number of trades")
@click.pass_context
def market_trades(ctx, condition_id, limit):
    """Show recent trades for a market.

    Example: horizon wallet market-trades 0xabc123... --limit 20
    """
    from horizon.tools import market_trades as _market_trades
    from horizon.cli._fmt import output

    result = _market_trades(condition_id=condition_id, limit=limit)
    output(result, json_mode=ctx.obj.get("json", False))


@wallet.command()
@click.argument("address")
@click.option("--limit", default=500, help="Number of trades to analyze")
@click.pass_context
def score(ctx, address, limit):
    """Score a wallet's trading performance.

    Example: horizon wallet score 0x1234...abcd
    """
    from horizon.tools import wallet_score
    from horizon.cli._fmt import output

    output(wallet_score(address=address, limit=limit), json_mode=ctx.obj.get("json", False))


@wallet.command("analysis")
@click.argument("address")
@click.option("--limit", default=500, help="Number of trades to analyze")
@click.pass_context
def analysis(ctx, address, limit):
    """Deep analysis of a wallet's trading behavior."""
    from horizon.tools import wallet_analysis
    from horizon.cli._fmt import output

    output(wallet_analysis(address=address, trade_limit=limit), json_mode=ctx.obj.get("json", False))


@wallet.command("profiler")
@click.argument("address")
@click.option("--limit", default=500, help="Number of trades to analyze")
@click.pass_context
def profiler(ctx, address, limit):
    """Generate a full trader profile for a wallet."""
    from horizon.tools import wallet_profiler
    from horizon.cli._fmt import output

    output(wallet_profiler(address=address, trade_limit=limit), json_mode=ctx.obj.get("json", False))


@wallet.command("consensus")
@click.option("--addresses", required=True, multiple=True, help="Wallet addresses (repeat for multiple)")
@click.pass_context
def consensus(ctx, addresses):
    """Compute consensus signal from multiple wallets."""
    from horizon.tools import wallet_consensus_tool
    from horizon.cli._fmt import output

    output(wallet_consensus_tool(addresses=list(addresses)), json_mode=ctx.obj.get("json", False))


@wallet.command("signals")
@click.argument("address")
@click.pass_context
def signals(ctx, address):
    """Scan for trading signals from a wallet."""
    from horizon.tools import scan_wallet_signals_tool
    from horizon.cli._fmt import output

    output(scan_wallet_signals_tool(address=address), json_mode=ctx.obj.get("json", False))


@wallet.command("track")
@click.argument("address")
@click.pass_context
def track(ctx, address):
    """Start tracking a wallet for signals."""
    from horizon.tools import track_wallet_tool
    from horizon.cli._fmt import output

    output(track_wallet_tool(address=address), json_mode=ctx.obj.get("json", False))
