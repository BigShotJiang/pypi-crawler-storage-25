"""Hedging commands."""

from __future__ import annotations

import json

import click


@click.group()
def hedge():
    """Hedging analysis commands."""
    pass


@hedge.command()
@click.option("--spot-prices", required=True, help="JSON array of spot prices")
@click.option("--hedge-prices", required=True, help="JSON array of hedge prices")
@click.pass_context
def analysis(ctx, spot_prices, hedge_prices):
    """Compute hedge ratio, effectiveness, and basis risk.

    Example: horizon hedge analysis --spot-prices '[100,101,99]' --hedge-prices '[50,51,49]'
    """
    from horizon.tools import hedge_analysis
    from horizon.cli._fmt import output

    output(hedge_analysis(spot_prices=json.loads(spot_prices), hedge_prices=json.loads(hedge_prices)), json_mode=ctx.obj.get("json", False))


@hedge.command()
@click.option("--spot-prices", required=True, help="JSON array of spot prices")
@click.option("--hedge-prices", required=True, help="JSON array of hedge prices")
@click.option("--scenarios", default="[-0.1,-0.05,0,0.05,0.1]", help="JSON array of spot moves")
@click.pass_context
def scenario(ctx, spot_prices, hedge_prices, scenarios):
    """Run hedge scenario analysis under various spot moves."""
    from horizon.tools import hedge_scenario_analysis
    from horizon.cli._fmt import output

    output(hedge_scenario_analysis(spot_prices=json.loads(spot_prices), hedge_prices=json.loads(hedge_prices), scenarios=json.loads(scenarios)), json_mode=ctx.obj.get("json", False))


@hedge.command("multi-ticker")
@click.option("--returns-matrix", required=True, help="JSON 2D array of returns")
@click.option("--target-returns", required=True, help="JSON array of target returns")
@click.pass_context
def multi_ticker(ctx, returns_matrix, target_returns):
    """Compute optimal multi-ticker hedge weights."""
    from horizon.tools import multi_ticker_hedge_analysis
    from horizon.cli._fmt import output

    output(multi_ticker_hedge_analysis(returns_matrix=json.loads(returns_matrix), target_returns=json.loads(target_returns)), json_mode=ctx.obj.get("json", False))


@hedge.command("cost")
@click.pass_context
def cost(ctx):
    """Show hedge trading cost summary."""
    from horizon.tools import hedge_cost_summary
    from horizon.cli._fmt import output

    output(hedge_cost_summary(), json_mode=ctx.obj.get("json", False))
