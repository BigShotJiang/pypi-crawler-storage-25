"""Discovery commands: discover, events, top-markets, market."""

from __future__ import annotations

import click


@click.command()
@click.argument("query", default="")
@click.option("--exchange", default="polymarket", help="Exchange to search (polymarket, kalshi, alpaca, ibkr)")
@click.option("--limit", default=10, help="Number of results")
@click.option("--type", "market_type", default="all", type=click.Choice(["all", "binary", "multi"]), help="Market type filter")
@click.option("--category", default="", help="Category filter (e.g. crypto, politics)")
@click.pass_context
def discover(ctx, query, exchange, limit, market_type, category):
    """Search for prediction markets.

    Examples:

    \b
      horizon discover "election"
      horizon discover "bitcoin" --exchange kalshi --limit 5
      horizon discover --type binary --category crypto
    """
    from horizon.tools import discover as _discover
    from horizon.cli._fmt import output

    result = _discover(
        query=query,
        exchange=exchange,
        limit=limit,
        market_type=market_type,
        category=category,
    )
    output(result, json_mode=ctx.obj.get("json", False))


@click.command()
@click.argument("query", default="")
@click.option("--limit", default=10, help="Number of events")
@click.pass_context
def events(ctx, query, limit):
    """Search for multi-outcome events.

    Examples:

    \b
      horizon events "election"
      horizon events "super bowl" --limit 5
    """
    from horizon.tools import discover_event
    from horizon.cli._fmt import output

    result = discover_event(query=query, limit=limit)
    output(result, json_mode=ctx.obj.get("json", False))


@click.command("top-markets")
@click.option("--exchange", default="polymarket", help="Exchange (polymarket, kalshi, alpaca, ibkr)")
@click.option("--limit", default=10, help="Number of markets")
@click.option("--category", default="", help="Category filter")
@click.pass_context
def top_markets(ctx, exchange, limit, category):
    """Show highest-volume active markets.

    Examples:

    \b
      horizon top-markets
      horizon top-markets --exchange kalshi --limit 10
    """
    from horizon.tools import get_top_markets
    from horizon.cli._fmt import output

    result = get_top_markets(exchange=exchange, limit=limit, category=category)
    output(result, json_mode=ctx.obj.get("json", False))


@click.command()
@click.argument("slug")
@click.option("--exchange", default="polymarket", help="Exchange (polymarket, kalshi, alpaca, ibkr)")
@click.pass_context
def market(ctx, slug, exchange):
    """Show details for a specific market.

    Examples:

    \b
      horizon market "will-trump-win-2024"
      horizon market "KXBTC-25MAR14" --exchange kalshi
    """
    from horizon.tools import market_detail
    from horizon.cli._fmt import output

    result = market_detail(slug_or_id=slug, exchange=exchange)
    output(result, json_mode=ctx.obj.get("json", False))
