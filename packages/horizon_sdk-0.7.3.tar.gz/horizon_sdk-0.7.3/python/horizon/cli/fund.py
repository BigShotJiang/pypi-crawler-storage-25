"""Fund management commands."""

from __future__ import annotations

import click


@click.group()
def fund():
    """Autonomous fund management commands."""
    pass


@fund.command()
@click.pass_context
def status(ctx):
    """Show fund status: NAV, drawdown, active strategies."""
    from horizon.tools import fund_status
    from horizon.cli._fmt import output

    output(fund_status(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.pass_context
def report(ctx):
    """Generate a comprehensive fund report."""
    from horizon.tools import fund_report
    from horizon.cli._fmt import output

    output(fund_report(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.option("--name", required=True, help="Strategy name")
@click.option("--markets", required=True, multiple=True, help="Market IDs (repeat for multiple)")
@click.option("--mode", default="paper", help="Trading mode: paper or live")
@click.option("--file", "strategy_file", default=None, type=click.Path(), help="Path to a .py strategy file to load pipeline from")
@click.pass_context
def deploy(ctx, name, markets, mode, strategy_file):
    """Deploy a strategy to the fund.

    \b
    Example:
      horizon fund deploy --name my-mm --markets will-btc-hit-100k --mode paper
      horizon fund deploy --name arb --markets market-a --markets market-b
      horizon fund deploy --name my-strat --markets some-market --file ./my_strategy.py
    """
    from horizon.cli._fmt import output

    pipeline = []
    if strategy_file is not None:
        pipeline = _load_strategy_file(strategy_file)

    from horizon.tools import fund_deploy_strategy

    result = fund_deploy_strategy(
        name=name,
        markets=list(markets),
        mode=mode,
        pipeline=pipeline,
    )
    output(result, json_mode=ctx.obj.get("json", False))


# Maximum strategy file size: 1 MB
_MAX_STRATEGY_FILE_SIZE = 1_048_576


def _load_strategy_file(path: str) -> list:
    """Safely load a strategy file and extract its pipeline.

    Validates the file path, size, and extension, then executes it in a
    restricted namespace that prevents access to dangerous builtins.
    """
    import os

    # Validate file extension
    if not path.endswith(".py"):
        raise click.ClickException(f"Strategy file must be a .py file, got: {path}")

    # Resolve to absolute path and validate existence
    abs_path = os.path.abspath(path)
    if not os.path.isfile(abs_path):
        raise click.ClickException(f"Strategy file not found: {abs_path}")

    # Validate file size
    file_size = os.path.getsize(abs_path)
    if file_size > _MAX_STRATEGY_FILE_SIZE:
        raise click.ClickException(
            f"Strategy file too large: {file_size:,} bytes "
            f"(max {_MAX_STRATEGY_FILE_SIZE:,} bytes)"
        )
    if file_size == 0:
        raise click.ClickException("Strategy file is empty")

    # Read file contents
    source = open(abs_path, "r", encoding="utf-8").read()

    # Restricted builtins: remove dangerous functions that allow arbitrary
    # system access, code execution, or file manipulation beyond what the
    # strategy needs.
    import builtins
    safe_builtins = {k: getattr(builtins, k) for k in dir(builtins) if not k.startswith("_")}
    # Remove dangerous builtins
    for dangerous in (
        "eval", "exec", "compile", "execfile",
        "globals", "locals", "vars",
        "breakpoint", "exit", "quit",
        "open", "input",
        "__import__",
    ):
        safe_builtins.pop(dangerous, None)

    # Allow controlled imports via a whitelist
    _ALLOWED_MODULES = frozenset({
        "horizon", "horizon.strategy", "horizon.context", "horizon.feeds",
        "horizon.exchanges", "horizon.risk", "horizon._horizon",
        "math", "statistics", "collections", "functools", "itertools",
        "dataclasses", "typing", "enum", "decimal", "fractions",
        "datetime", "time", "json", "logging", "copy", "operator",
        "numpy", "pandas", "scipy",
    })

    def _restricted_import(name, *args, **kwargs):
        # Allow sub-imports of whitelisted top-level packages
        top = name.split(".")[0]
        if name in _ALLOWED_MODULES or top in {m.split(".")[0] for m in _ALLOWED_MODULES}:
            return __builtins__["__import__"](name, *args, **kwargs) if isinstance(__builtins__, dict) else __import__(name, *args, **kwargs)
        raise ImportError(f"Import of '{name}' is not allowed in strategy files")

    safe_builtins["__import__"] = _restricted_import

    restricted_globals = {"__builtins__": safe_builtins, "__file__": abs_path, "__name__": "__strategy__"}

    try:
        compiled = compile(source, abs_path, "exec")
        exec(compiled, restricted_globals)  # noqa: S102
    except ImportError as e:
        raise click.ClickException(f"Strategy file import error: {e}")
    except SyntaxError as e:
        raise click.ClickException(f"Strategy file syntax error: {e}")
    except Exception as e:
        raise click.ClickException(f"Strategy file execution error: {type(e).__name__}: {e}")

    # Extract pipeline from the executed namespace
    pipeline = restricted_globals.get("pipeline", restricted_globals.get("PIPELINE", []))
    if not isinstance(pipeline, list):
        raise click.ClickException(
            "Strategy file must define a 'pipeline' list of callable functions"
        )
    return pipeline


@fund.command()
@click.argument("name")
@click.pass_context
def stop(ctx, name):
    """Stop a running strategy."""
    from horizon.tools import fund_stop_strategy
    from horizon.cli._fmt import output

    output(fund_stop_strategy(name), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.argument("name")
@click.pass_context
def pause(ctx, name):
    """Pause a running strategy (keeps state)."""
    from horizon.tools import fund_pause_strategy
    from horizon.cli._fmt import output

    output(fund_pause_strategy(name), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.argument("name")
@click.pass_context
def resume(ctx, name):
    """Resume a paused strategy."""
    from horizon.tools import fund_resume_strategy
    from horizon.cli._fmt import output

    output(fund_resume_strategy(name), json_mode=ctx.obj.get("json", False))


@fund.command("list")
@click.pass_context
def list_strategies(ctx):
    """List all fund strategies with status."""
    from horizon.tools import fund_list_strategies
    from horizon.cli._fmt import output

    output(fund_list_strategies(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.argument("name")
@click.option("--capital", required=True, type=float, help="New capital allocation")
@click.pass_context
def scale(ctx, name, capital):
    """Scale a strategy's capital allocation.

    Example: horizon fund scale my-mm --capital 10000
    """
    from horizon.tools import fund_scale_strategy
    from horizon.cli._fmt import output

    output(fund_scale_strategy(name=name, new_capital=capital), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.option("--limit", default=50, help="Number of NAV records")
@click.pass_context
def nav(ctx, limit):
    """Show NAV history."""
    from horizon.tools import fund_nav_history
    from horizon.cli._fmt import output

    output(fund_nav_history(limit=limit), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.pass_context
def risk(ctx):
    """Show fund risk dashboard."""
    from horizon.tools import fund_risk_dashboard
    from horizon.cli._fmt import output

    output(fund_risk_dashboard(), json_mode=ctx.obj.get("json", False))


@fund.command("stress-test")
@click.pass_context
def stress_test(ctx):
    """Run fund stress test."""
    from horizon.tools import fund_stress_test
    from horizon.cli._fmt import output

    output(fund_stress_test(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.pass_context
def pnl(ctx):
    """Show PnL attribution breakdown."""
    from horizon.tools import fund_pnl_attribution
    from horizon.cli._fmt import output

    output(fund_pnl_attribution(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.pass_context
def explain(ctx):
    """Explain fund state in plain language."""
    from horizon.tools import fund_explain
    from horizon.cli._fmt import output

    output(fund_explain(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.pass_context
def regime(ctx):
    """Show current market regime classification."""
    from horizon.tools import fund_regime
    from horizon.cli._fmt import output

    output(fund_regime(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.option("--limit", default=20, help="Number of alerts")
@click.pass_context
def alerts(ctx, limit):
    """Show recent fund alerts."""
    from horizon.tools import fund_alerts
    from horizon.cli._fmt import output

    output(fund_alerts(limit=limit), json_mode=ctx.obj.get("json", False))


@fund.command("explain-strategy")
@click.argument("name")
@click.pass_context
def explain_strategy(ctx, name):
    """Explain a specific strategy's state."""
    from horizon.tools import fund_explain_strategy
    from horizon.cli._fmt import output

    output(fund_explain_strategy(name=name), json_mode=ctx.obj.get("json", False))


@fund.command("explain-risk")
@click.pass_context
def explain_risk(ctx):
    """Explain fund risk state."""
    from horizon.tools import fund_explain_risk
    from horizon.cli._fmt import output

    output(fund_explain_risk(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.option("--limit", default=20, help="Number of hypotheses")
@click.pass_context
def hypotheses(ctx, limit):
    """Show fund hypotheses and their status."""
    from horizon.tools import fund_hypotheses
    from horizon.cli._fmt import output

    output(fund_hypotheses(limit=limit), json_mode=ctx.obj.get("json", False))


@fund.command("alpha-model")
@click.pass_context
def alpha_model(ctx):
    """Show alpha model state and factor weights."""
    from horizon.tools import fund_alpha_model
    from horizon.cli._fmt import output

    output(fund_alpha_model(), json_mode=ctx.obj.get("json", False))


@fund.command()
@click.option("--limit", default=20, help="Number of decisions")
@click.pass_context
def decisions(ctx, limit):
    """Show recent fund decisions."""
    from horizon.tools import fund_decisions
    from horizon.cli._fmt import output

    output(fund_decisions(limit=limit), json_mode=ctx.obj.get("json", False))


@fund.command("decay-report")
@click.pass_context
def decay_report(ctx):
    """Show alpha decay report."""
    from horizon.tools import fund_decay_report
    from horizon.cli._fmt import output

    output(fund_decay_report(), json_mode=ctx.obj.get("json", False))


@fund.command("ledger")
@click.option("--limit", default=50, help="Number of entries")
@click.pass_context
def ledger(ctx, limit):
    """Show fund ledger entries."""
    from horizon.tools import fund_ledger_entries
    from horizon.cli._fmt import output

    output(fund_ledger_entries(limit=limit), json_mode=ctx.obj.get("json", False))


@fund.command("promotion-status")
@click.pass_context
def promotion_status(ctx):
    """Show strategy promotion pipeline status."""
    from horizon.tools import fund_promotion_status
    from horizon.cli._fmt import output

    output(fund_promotion_status(), json_mode=ctx.obj.get("json", False))


@fund.command("snapshot")
@click.pass_context
def snapshot(ctx):
    """Full fund snapshot (all metrics in one call)."""
    from horizon.tools import fund_full_snapshot
    from horizon.cli._fmt import output

    output(fund_full_snapshot(), json_mode=ctx.obj.get("json", False))


@fund.command("correlation")
@click.pass_context
def correlation(ctx):
    """Show inter-strategy correlation matrix."""
    from horizon.tools import fund_correlation_matrix
    from horizon.cli._fmt import output

    output(fund_correlation_matrix(), json_mode=ctx.obj.get("json", False))


@fund.command("execution-report")
@click.pass_context
def execution_report(ctx):
    """Show execution quality report."""
    from horizon.tools import fund_execution_report
    from horizon.cli._fmt import output

    output(fund_execution_report(), json_mode=ctx.obj.get("json", False))


@fund.command("memory-query")
@click.option("--category", default=None, help="Filter by category")
@click.option("--key", "key_contains", default=None, help="Filter by key substring")
@click.option("--limit", default=20, help="Number of entries")
@click.pass_context
def memory_query(ctx, category, key_contains, limit):
    """Query fund memory system."""
    from horizon.tools import fund_memory_query
    from horizon.cli._fmt import output

    output(fund_memory_query(category=category, key_contains=key_contains, limit=limit), json_mode=ctx.obj.get("json", False))


@fund.command("memory-record")
@click.option("--category", required=True, help="Memory category")
@click.option("--key", required=True, help="Memory key")
@click.option("--value", required=True, help="Memory value")
@click.option("--confidence", default=0.5, type=float, help="Confidence score (0-1)")
@click.pass_context
def memory_record(ctx, category, key, value, confidence):
    """Record a memory entry in the fund."""
    from horizon.tools import fund_memory_record
    from horizon.cli._fmt import output

    output(fund_memory_record(category=category, key=key, value=value, confidence=confidence), json_mode=ctx.obj.get("json", False))
