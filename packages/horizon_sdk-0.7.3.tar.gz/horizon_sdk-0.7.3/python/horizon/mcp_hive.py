"""Horizon Hive MCP Server — autonomous swarm intelligence tools.

A separate MCP server for Hive swarm management. Exposes agent lifecycle,
evolution, pheromone sensing, autonomy control, and kill chain tools.

Run: python -m horizon.mcp_hive

Configuration example (Claude Desktop / claude_desktop_config.json):

    {
        "mcpServers": {
            "horizon-hive": {
                "command": "python",
                "args": ["-m", "horizon.mcp_hive"],
                "env": {
                    "HORIZON_HIVE_CAPITAL": "100000",
                    "HORIZON_HIVE_DB": "hive.db"
                }
            }
        }
    }

Security:
- HORIZON_SDK_KEY or HORIZON_API_KEY: validated at startup.
- HORIZON_MCP_AUTH: set to ``"false"`` to disable startup auth.
"""

from __future__ import annotations

import os
import logging
import time

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger(__name__)

_sdk_key = os.environ.get("HORIZON_SDK_KEY") or os.environ.get("HORIZON_API_KEY")
_auth_enabled = os.environ.get("HORIZON_MCP_AUTH", "true").lower() != "false"


def _validate_startup_auth() -> None:
    if not _auth_enabled:
        logger.info("Hive MCP server: auth disabled via HORIZON_MCP_AUTH=false")
        return
    if not _sdk_key:
        raise RuntimeError(
            "HORIZON_SDK_KEY (or HORIZON_API_KEY) required for Hive MCP server. "
            "Set HORIZON_MCP_AUTH=false to disable authentication."
        )
    try:
        from horizon.auth import validate_sdk_key
        tier = validate_sdk_key(_sdk_key)
        logger.info("Hive MCP server authenticated: tier=%s", tier)
    except Exception as e:
        raise RuntimeError(f"Invalid SDK key: {e}")


mcp = FastMCP(
    "horizon-hive",
    instructions=(
        "Horizon Hive — autonomous swarm intelligence system. "
        "Manage a fleet of trading agents that evolve, compete, and cooperate. "
        "Use these tools to spawn/kill agents, monitor pheromone signals, "
        "control autonomy level, run evolution cycles, and manage incidents. "
        "The Hive supports progressive autonomy: OBSERVE → SUGGEST → "
        "SUPERVISED → AUTONOMOUS → SKYNET. Start in OBSERVE mode. "
        "Never pass API keys or passwords as tool parameters."
    ),
)

# ---------------------------------------------------------------------------
# Hive singleton
# ---------------------------------------------------------------------------

_hive = None


def _get_hive():
    """Get or create the Hive singleton."""
    global _hive
    if _hive is not None:
        return _hive
    from horizon.hive import HiveController
    from horizon.hive._types import HiveConfig
    capital = float(os.environ.get("HORIZON_HIVE_CAPITAL", "100000"))
    db_path = os.environ.get("HORIZON_HIVE_DB", "hive.db")
    max_agents = int(os.environ.get("HORIZON_HIVE_MAX_AGENTS", "50"))
    _hive = HiveController(HiveConfig(
        total_capital=capital,
        db_path=db_path,
        max_agents=max_agents,
    ))
    return _hive


# ---------------------------------------------------------------------------
# Status & overview
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_status() -> dict:
    """Get full Hive status: agents, capital, mode, criticality, evolution generation."""
    return _get_hive().status()


@mcp.tool()
def hive_agents() -> list[dict]:
    """List all agents ranked by fitness. Shows ID, lifecycle, sharpe, PnL, capital, markets."""
    return _get_hive().coordinator.agent_ranking()


@mcp.tool()
def hive_agent(agent_id: str) -> dict:
    """Get detailed info for a specific agent by ID."""
    agent = _get_hive().coordinator.get_agent(agent_id)
    if agent is None:
        return {"error": f"Agent {agent_id} not found"}
    return agent.to_dict()


# ---------------------------------------------------------------------------
# Agent lifecycle
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_spawn(template: str, markets: list[str], capital: float = 0.0) -> dict:
    """Spawn a new agent from a strategy template.

    Templates: momentum, mean_reversion, market_maker, arbitrage,
    volatility, event_driven, macro, copy, liquidation.
    """
    agent = _get_hive().spawn_agent(
        template=template, markets=markets, capital=capital,
    )
    if agent is None:
        return {"error": "Spawn failed — fleet at capacity or invalid template"}
    return agent.to_dict()


@mcp.tool()
def hive_kill(agent_id: str, reason: str = "mcp_command") -> dict:
    """Kill (terminate) an agent. Removes from fleet and archives genome."""
    ok = _get_hive().coordinator.kill_agent(agent_id, reason)
    return {"killed": ok, "agent_id": agent_id}


@mcp.tool()
def hive_pause(agent_id: str) -> dict:
    """Pause an agent. Keeps state but stops trading."""
    ok = _get_hive().coordinator.pause_agent(agent_id, "mcp_command")
    return {"paused": ok, "agent_id": agent_id}


@mcp.tool()
def hive_resume(agent_id: str) -> dict:
    """Resume a paused agent."""
    ok = _get_hive().coordinator.resume_agent(agent_id)
    return {"resumed": ok, "agent_id": agent_id}


@mcp.tool()
def hive_scale(agent_id: str, capital: float) -> dict:
    """Adjust an agent's capital allocation."""
    ok = _get_hive().coordinator.scale_agent(agent_id, capital)
    return {"scaled": ok, "agent_id": agent_id, "capital": capital}


# ---------------------------------------------------------------------------
# Autonomy
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_mode(mode: str = "") -> dict:
    """Get or set the autonomy mode.

    Modes: observe, suggest, supervised, autonomous, skynet.
    Call with no mode to get current mode.
    """
    hive = _get_hive()
    if not mode:
        return {"mode": hive.autonomy.mode.value}
    from horizon.hive._types import AutonomyMode
    try:
        new_mode = AutonomyMode(mode)
        hive.autonomy.set_mode(new_mode)
        return {"mode": new_mode.value}
    except ValueError:
        return {"error": f"Invalid mode: {mode}. Valid: observe, suggest, supervised, autonomous, skynet"}


@mcp.tool()
def hive_pending() -> list[dict]:
    """List pending decisions awaiting approval."""
    hive = _get_hive()
    if hive.autonomy is None:
        return []
    return [d.to_dict() for d in hive.autonomy.pending()]


@mcp.tool()
def hive_approve(decision_id: str) -> dict:
    """Approve a pending autonomy decision."""
    hive = _get_hive()
    if hive.autonomy is None:
        return {"error": "Autonomy controller not available"}
    d = hive.autonomy.approve(decision_id)
    return {"approved": d is not None}


@mcp.tool()
def hive_reject(decision_id: str, reason: str = "") -> dict:
    """Reject a pending autonomy decision."""
    hive = _get_hive()
    if hive.autonomy is None:
        return {"error": "Autonomy controller not available"}
    d = hive.autonomy.reject(decision_id, reason)
    return {"rejected": d is not None}


# ---------------------------------------------------------------------------
# Pheromone field
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_pheromone(market_id: str = "") -> dict:
    """Sense the pheromone field. Pass market_id for a specific market, or empty for snapshot."""
    hive = _get_hive()
    if market_id:
        reading = hive.pheromone.sense(market_id)
        return reading.as_dict()
    return hive.pheromone.snapshot()


# ---------------------------------------------------------------------------
# Evolution & dream
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_evolve() -> dict:
    """Run one evolution cycle (N generations). Returns stats."""
    return _get_hive().run_evolution_cycle()


@mcp.tool()
def hive_dream(generations: int = 0) -> dict:
    """Start dream state: accelerated offline evolution.

    Uses 10,000 generations by default. Runs in background thread.
    """
    hive = _get_hive()
    if hive.dream is None:
        return {"error": "Dream state not available"}
    gens = generations if generations > 0 else None
    hive.dream.dream_async(generations=gens)
    return {"dreaming": True, "generations": gens or hive._config.dream_generations}


# ---------------------------------------------------------------------------
# Intelligence
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_reputation() -> list[dict]:
    """Get agent reputation rankings (Bayesian trust scores)."""
    return _get_hive().reputation.ranking()


@mcp.tool()
def hive_consensus() -> dict:
    """Show active internal prediction markets."""
    hive = _get_hive()
    markets = hive.consensus.active_markets()
    return {"markets": [
        {"id": m.market_id, "question": m.question,
         "consensus": m.consensus_probability}
        for m in markets
    ]}


@mcp.tool()
def hive_criticality() -> dict:
    """Compute criticality report: 15 indicators across 5 categories."""
    hive = _get_hive()
    report = hive.criticality.compute_report({})
    return {
        "warnings": report.warning_count(),
        "indicators": report.to_dict(),
    }


@mcp.tool()
def hive_imprint() -> dict:
    """Show imprint (behavioral cloning) system status."""
    return _get_hive().imprint.status()


@mcp.tool()
def hive_impact(market_id: str, size: float) -> dict:
    """Predict self-impact cost for a proposed order."""
    cost = _get_hive().impact.predict_impact(market_id, size)
    return {"market_id": market_id, "size": size, "impact_cost": cost}


# ---------------------------------------------------------------------------
# Incidents & safety
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_incidents() -> dict:
    """Show active and recent incidents."""
    return _get_hive().kill_chain.status()


@mcp.tool()
def hive_kill_switch() -> dict:
    """EMERGENCY: Halt all agents immediately. Triggers SEV1 incident."""
    _get_hive().kill_switch()
    return {"halted": True}


# ---------------------------------------------------------------------------
# Templates & info
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_templates() -> list[str]:
    """List available strategy templates for spawning."""
    return _get_hive().factory.available_templates()


@mcp.tool()
def hive_template_config(template: str) -> dict:
    """Get the configuration for a specific strategy template."""
    return _get_hive().factory.template_config(template)


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------

@mcp.tool()
def hive_server_status() -> dict:
    """Show WebSocket server status (port, clients, auth)."""
    return _get_hive().server.status()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    _validate_startup_auth()
    mcp.run()
