"""Run the Horizon MCP server: python -m horizon.mcp

Security: SDK key (HORIZON_SDK_KEY or HORIZON_API_KEY) is validated
at startup. Set HORIZON_MCP_AUTH=false to disable authentication.
When running over stdio (default), the transport is inherently local
but the SDK key is still validated to ensure authorization.
"""

import sys

from horizon.mcp_server import mcp, _validate_startup_auth

transport = "stdio"
if "--http" in sys.argv:
    transport = "streamable-http"

_validate_startup_auth()
mcp.run(transport=transport)
