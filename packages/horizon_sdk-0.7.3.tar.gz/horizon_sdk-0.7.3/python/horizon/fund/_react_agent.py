"""ReACT Research Agent for fund oversight and market analysis.

Implements a deterministic ReACT (Reason + Act) loop that queries positions,
markets, feeds, risk metrics, and the knowledge graph to produce structured
analysis reports.  No external LLM dependency -- all reasoning is rule-based
with configurable thresholds.

All public methods return plain dicts suitable for JSON serialisation.
"""

from __future__ import annotations

import logging
import math
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger("horizon.fund.react_agent")

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Finding:
    """A single research finding."""

    category: str  # risk, opportunity, anomaly, recommendation, insight
    severity: str  # critical, high, medium, low, info
    title: str
    detail: str
    evidence: dict
    timestamp: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ResearchReport:
    """Structured research report."""

    query: str
    findings: list[Finding]
    data_sources: list[str]
    reasoning_trace: list[dict]
    timestamp: float = field(default_factory=time.time)
    duration_secs: float = 0.0

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "findings": [
                {
                    "category": f.category,
                    "severity": f.severity,
                    "title": f.title,
                    "detail": f.detail,
                    "evidence": f.evidence,
                    "timestamp": f.timestamp,
                }
                for f in self.findings
            ],
            "data_sources": self.data_sources,
            "reasoning_trace": self.reasoning_trace,
            "timestamp": self.timestamp,
            "duration_secs": round(self.duration_secs, 3),
            "summary": self._summary(),
        }

    def _summary(self) -> dict:
        by_severity: dict[str, int] = {}
        for f in self.findings:
            by_severity[f.severity] = by_severity.get(f.severity, 0) + 1
        return {
            "total_findings": len(self.findings),
            "by_severity": by_severity,
            "by_category": {
                cat: sum(1 for f in self.findings if f.category == cat)
                for cat in {f.category for f in self.findings}
            },
        }


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class ResearchAgent:
    """ReACT-style research agent for fund oversight and market analysis.

    The agent executes a four-phase loop:

    1. **Observe** -- gather data from registered query tools.
    2. **Think**   -- apply rule-based heuristics to analyse observations.
    3. **Act**     -- generate findings with severity and evidence.
    4. **Conclude** -- deduplicate, sort, and wrap into a ``ResearchReport``.

    The agent is fully deterministic (no LLM calls) and thread-safe for
    read-only operations (it never mutates the fund).  All methods return
    plain dicts for JSON serialisation.
    """

    FINDING_CATEGORIES = {"risk", "opportunity", "anomaly", "recommendation", "insight"}
    SEVERITY_LEVELS = {"critical", "high", "medium", "low", "info"}
    MAX_REASONING_STEPS = 20  # prevent infinite loops

    # Configurable thresholds ------------------------------------------------

    DD_CRITICAL = 0.15
    DD_HIGH = 0.08
    DD_MEDIUM = 0.03

    DD_STRAT_CRITICAL = 0.20
    DD_STRAT_HIGH = 0.10

    VAR_CRITICAL = 0.90
    VAR_HIGH = 0.70

    SLIPPAGE_HIGH = 0.02
    FILL_RATE_LOW = 0.50

    EDGE_DECAY_SEVERE = 0.30
    EDGE_DECAY_MODERATE = 0.50

    FEED_STALE_SECS = 300.0  # 5 min

    STRAT_NAV_LOW = 950.0
    STRAT_DD_MIN = 0.05

    HYPOTHESIS_CONFIDENCE_MIN = 0.60

    def __init__(self, fund: Any = None, knowledge_graph: Any = None) -> None:
        """
        Args:
            fund: FundManager instance (optional -- agent works with
                  whatever is available).
            knowledge_graph: KnowledgeGraph instance (optional).
        """
        self._fund = fund
        self._kg = knowledge_graph
        self._tools: dict[str, Callable[[dict], dict]] = self._register_tools()

    # ------------------------------------------------------------------
    # Tool registration
    # ------------------------------------------------------------------

    def _register_tools(self) -> dict[str, Callable[[dict], dict]]:
        """Register available query tools based on what's connected."""
        tools: dict[str, Callable[[dict], dict]] = {
            "positions": self._tool_positions,
            "markets": self._tool_markets,
            "risk": self._tool_risk,
            "performance": self._tool_performance,
            "feeds": self._tool_feeds,
            "strategies": self._tool_strategies,
            "correlations": self._tool_correlations,
            "regime": self._tool_regime,
            "hypotheses": self._tool_hypotheses,
            "graph_context": self._tool_graph_context,
            "graph_opportunities": self._tool_graph_opportunities,
            "graph_correlations": self._tool_graph_correlations,
            "alpha_decay": self._tool_alpha_decay,
            "execution_quality": self._tool_execution_quality,
            "stress_test": self._tool_stress_test,
        }
        return tools

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def investigate(self, query: str) -> dict:
        """Run a full investigation on a query.  Returns ``ResearchReport``
        serialised as a dict.

        Example queries::

            "Why is strategy X underperforming?"
            "Should we enter election markets?"
            "What are the current risk exposures?"
            "Find cross-market opportunities"
            "Full fund health check"
        """
        start = time.time()
        trace: list[dict] = []
        findings: list[Finding] = []
        sources: list[str] = []

        # Step 1: Parse query intent
        intent = self._parse_intent(query)
        trace.append({"step": "parse_intent", "intent": intent})

        # Step 2: Plan which tools to use
        plan = self._plan_tools(intent)
        trace.append({"step": "plan", "tools": plan})

        # Step 3: Execute tool queries (observe)
        observations: dict[str, dict] = {}
        for tool_name in plan:
            if tool_name in self._tools:
                try:
                    result = self._tools[tool_name](intent)
                    observations[tool_name] = result
                    sources.append(tool_name)
                    trace.append({"step": "observe", "tool": tool_name, "status": "ok"})
                except Exception as exc:
                    logger.debug("Tool %s failed: %s", tool_name, exc)
                    trace.append({"step": "observe", "tool": tool_name, "status": "error", "error": str(exc)})

        # Step 4: Analyse observations (think + act)
        step_count = 0
        for analyzer in self._get_analyzers(intent):
            if step_count >= self.MAX_REASONING_STEPS:
                trace.append({"step": "limit", "message": "max reasoning steps reached"})
                break
            try:
                new_findings = analyzer(intent, observations)
                findings.extend(new_findings)
                trace.append({
                    "step": "analyze",
                    "analyzer": analyzer.__name__,
                    "findings": len(new_findings),
                })
            except Exception as exc:
                logger.debug("Analyzer %s failed: %s", analyzer.__name__, exc)
                trace.append({
                    "step": "analyze",
                    "analyzer": analyzer.__name__,
                    "error": str(exc),
                })
            step_count += 1

        # Step 5: Deduplicate and sort findings
        findings = self._deduplicate(findings)
        findings.sort(key=lambda f: self._severity_rank(f.severity))

        duration = time.time() - start
        report = ResearchReport(
            query=query,
            findings=findings,
            data_sources=sources,
            reasoning_trace=trace,
            timestamp=start,
            duration_secs=duration,
        )
        return report.to_dict()

    def health_check(self) -> dict:
        """Quick fund health check."""
        return self.investigate("Full fund health check")

    def explain_underperformance(self, strategy_name: str) -> dict:
        """Investigate why a strategy is underperforming."""
        return self.investigate(f"Why is strategy {strategy_name} underperforming?")

    def market_research(self, topic: str) -> dict:
        """Research market opportunities around a topic."""
        return self.investigate(f"Find market opportunities for {topic}")

    def risk_assessment(self) -> dict:
        """Comprehensive risk assessment."""
        return self.investigate("Comprehensive risk assessment of all exposures")

    # ------------------------------------------------------------------
    # Intent parsing
    # ------------------------------------------------------------------

    def _parse_intent(self, query: str) -> dict:
        """Parse query into structured intent."""
        q = query.lower()
        intent: dict[str, Any] = {
            "raw_query": query,
            "focus": "general",
            "strategy_name": None,
            "market_id": None,
            "topics": [],
        }

        # Detect focus areas (order matters -- first match wins)
        _focus_map: list[tuple[list[str], str, list[str]]] = [
            (["risk", "exposure", "drawdown", "var", "stress"], "risk", ["risk", "exposure"]),
            (["underperform", "losing", "decline", "why is"], "diagnosis", ["performance", "risk", "execution"]),
            (["opportunity", "enter", "should we", "market research"], "opportunity", ["markets", "correlations", "edge"]),
            (["health", "status", "overview", "full"], "health", ["performance", "risk", "strategies", "feeds"]),
            (["correlation", "cross-market", "cluster"], "correlations", ["correlations", "markets"]),
            (["alpha", "edge", "decay", "signal"], "alpha", ["alpha_decay", "performance", "hypotheses"]),
        ]
        for keywords, focus, topics in _focus_map:
            if any(w in q for w in keywords):
                intent["focus"] = focus
                intent["topics"] = list(topics)
                break

        # Extract strategy name if mentioned (pattern: "strategy X")
        strat_match = re.search(r"strategy\s+(\w+)", q)
        if strat_match:
            intent["strategy_name"] = strat_match.group(1)

        return intent

    # ------------------------------------------------------------------
    # Planning
    # ------------------------------------------------------------------

    _TOOL_MAP: dict[str, list[str]] = {
        "risk": ["positions", "risk", "correlations", "regime", "stress_test"],
        "diagnosis": [
            "positions", "performance", "risk", "execution_quality",
            "alpha_decay", "feeds", "strategies",
        ],
        "opportunity": [
            "markets", "graph_opportunities", "graph_correlations",
            "hypotheses", "regime",
        ],
        "health": [
            "positions", "performance", "risk", "strategies", "feeds",
            "correlations", "regime",
        ],
        "correlations": ["correlations", "graph_correlations", "positions", "markets"],
        "alpha": ["alpha_decay", "hypotheses", "performance", "strategies"],
        "general": ["positions", "performance", "risk", "strategies"],
    }

    def _plan_tools(self, intent: dict) -> list[str]:
        """Decide which tools to query based on intent."""
        focus = intent.get("focus", "general")
        plan = list(self._TOOL_MAP.get(focus, self._TOOL_MAP["general"]))

        # Always include graph tools if knowledge graph is available
        if self._kg is not None and "graph_context" not in plan:
            plan.append("graph_context")

        return plan

    # ------------------------------------------------------------------
    # Analyzer dispatch
    # ------------------------------------------------------------------

    def _get_analyzers(self, intent: dict) -> list[Callable[[dict, dict], list[Finding]]]:
        """Get analyzer functions based on intent."""
        focus = intent.get("focus", "general")

        _analyzer_map: dict[str, list[Callable[[dict, dict], list[Finding]]]] = {
            "risk": [
                self._analyze_risk_exposure,
                self._analyze_drawdown,
                self._analyze_concentration,
                self._analyze_regime_risk,
            ],
            "diagnosis": [
                self._analyze_strategy_performance,
                self._analyze_execution,
                self._analyze_alpha_health,
                self._analyze_feed_health,
                self._analyze_risk_exposure,
            ],
            "opportunity": [
                self._analyze_market_opportunities,
                self._analyze_edge_signals,
                self._analyze_correlation_opportunities,
            ],
            "health": [
                self._analyze_fund_overview,
                self._analyze_strategy_performance,
                self._analyze_risk_exposure,
                self._analyze_feed_health,
                self._analyze_regime_risk,
            ],
            "correlations": [
                self._analyze_concentration,
                self._analyze_correlation_opportunities,
            ],
            "alpha": [
                self._analyze_alpha_health,
                self._analyze_edge_signals,
                self._analyze_strategy_performance,
            ],
            "general": [
                self._analyze_fund_overview,
                self._analyze_risk_exposure,
            ],
        }
        return _analyzer_map.get(focus, _analyzer_map["general"])

    # ------------------------------------------------------------------
    # Tools (data gathering)
    # ------------------------------------------------------------------

    def _tool_positions(self, intent: dict) -> dict:
        """Query current positions from all strategy engines."""
        if not self._fund:
            return {"available": False}
        try:
            strategies: dict[str, list[dict]] = {}
            for name, state in self._fund._controller._strategies.items():
                engine = state.get("engine")
                if engine:
                    positions = engine.positions()
                    strategies[name] = [
                        {
                            "market_id": p.market_id,
                            "size": p.size,
                            "avg_price": p.avg_price,
                            "unrealized_pnl": p.unrealized_pnl,
                            "realized_pnl": p.realized_pnl,
                            "side": str(p.side),
                        }
                        for p in positions
                    ]
            return {"strategies": strategies, "available": True}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_markets(self, intent: dict) -> dict:
        """Query known markets from the universe."""
        if not self._fund:
            return {"available": False}
        try:
            universe = getattr(self._fund, "_universe", None)
            if universe:
                candidates = universe.candidates()
                return {
                    "available": True,
                    "count": len(candidates),
                    "markets": candidates[:50],
                }
            return {"available": True, "count": 0, "markets": []}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_risk(self, intent: dict) -> dict:
        """Query fund-level risk metrics (NAV, drawdown, kill switch, VaR)."""
        if not self._fund:
            return {"available": False}
        try:
            result: dict[str, Any] = {"available": True}

            nav = self._fund._nav
            result["nav"] = round(nav.fund_nav(), 4)
            result["drawdown"] = round(nav.fund_drawdown(), 6)
            result["high_water_mark"] = round(nav.fund_high_water_mark(), 4)

            risk_mon = self._fund._risk_monitor
            result["kill_switch_active"] = risk_mon.is_active()

            var_mgr = getattr(self._fund, "_var_budget", None)
            if var_mgr:
                result["var_usage"] = var_mgr.portfolio_usage()

            return result
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_performance(self, intent: dict) -> dict:
        """Query per-strategy NAV, drawdown, and attribution."""
        if not self._fund:
            return {"available": False}
        try:
            result: dict[str, Any] = {"available": True, "strategies": {}}
            for name, state in self._fund._controller._strategies.items():
                nav = self._fund._nav.strategy_nav(name)
                dd = self._fund._nav.strategy_drawdown(name)
                result["strategies"][name] = {
                    "nav": round(nav, 4),
                    "drawdown": round(dd, 6),
                    "status": state.get("status", "unknown"),
                }

            attr = getattr(self._fund, "_perf_attribution", None)
            if attr:
                try:
                    result["attribution"] = attr.compute()
                except Exception:
                    pass

            return result
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_feeds(self, intent: dict) -> dict:
        """Query feed health (price, staleness)."""
        if not self._fund:
            return {"available": False}
        try:
            result: dict[str, Any] = {"available": True, "feeds": {}}
            for name, state in self._fund._controller._strategies.items():
                engine = state.get("engine")
                if engine:
                    snapshots = engine.feed_snapshots()
                    for fname, snap in snapshots.items():
                        age = time.time() - snap.timestamp if snap.timestamp > 0 else math.inf
                        result["feeds"][fname] = {
                            "price": snap.price,
                            "bid": snap.bid,
                            "ask": snap.ask,
                            "age_secs": round(age, 1),
                            "stale": age > self.FEED_STALE_SECS,
                        }
            return result
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_strategies(self, intent: dict) -> dict:
        """Query strategy states (status, capital, markets)."""
        if not self._fund:
            return {"available": False}
        try:
            result: dict[str, Any] = {"available": True, "strategies": {}}
            for name, state in self._fund._controller._strategies.items():
                result["strategies"][name] = {
                    "status": state.get("status", "unknown"),
                    "capital": state.get("capital", 0),
                    "market_ids": state.get("market_ids", []),
                }
            return result
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_correlations(self, intent: dict) -> dict:
        """Query cross-strategy correlations."""
        if not self._fund:
            return {"available": False}
        try:
            corr = getattr(self._fund, "_correlation", None)
            if not corr:
                return {"available": False}
            matrix = corr.correlation_matrix()
            alerts = corr.recent_alerts()
            return {
                "available": True,
                "matrix": matrix,
                "alerts": alerts,
                "alert_count": len(alerts),
            }
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_regime(self, intent: dict) -> dict:
        """Query current market regime."""
        if not self._fund:
            return {"available": False}
        try:
            regime = getattr(self._fund, "_regime_detector", None)
            if not regime:
                return {"available": False}
            snap = regime.current_regime()
            if snap is None:
                return {"available": True, "regime": "unknown", "snapshot": {}}
            return {
                "available": True,
                "regime": snap.regime,
                "snapshot": {
                    "regime": snap.regime,
                    "confidence": snap.confidence,
                    "volatility": snap.volatility,
                    "trend_strength": snap.trend_strength,
                    "mean_reversion_score": snap.mean_reversion_score,
                    "timestamp": snap.timestamp,
                },
            }
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_hypotheses(self, intent: dict) -> dict:
        """Query active hypotheses."""
        if not self._fund:
            return {"available": False}
        try:
            hyp = getattr(self._fund, "_hypothesis_mgr", None)
            if not hyp:
                return {"available": False}
            active = hyp.active_hypotheses()
            return {
                "available": True,
                "count": len(active),
                "hypotheses": active[:20],
            }
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_graph_context(self, intent: dict) -> dict:
        """Query knowledge graph for context (market-specific or global)."""
        if not self._kg:
            return {"available": False}
        try:
            market_id = intent.get("market_id")
            if market_id:
                return {"available": True, "context": self._kg.market_context(market_id)}
            return {"available": True, "stats": self._kg.stats()}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_graph_opportunities(self, intent: dict) -> dict:
        """Query knowledge graph for opportunities."""
        if not self._kg:
            return {"available": False}
        try:
            opps = self._kg.surface_opportunities(min_confidence=0.6, lookback_hours=24.0)
            return {"available": True, "opportunities": opps[:20]}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_graph_correlations(self, intent: dict) -> dict:
        """Query knowledge graph for cross-market correlations."""
        if not self._kg:
            return {"available": False}
        try:
            clusters = self._kg.detect_cross_correlations(min_weight=0.3)
            return {"available": True, "clusters": clusters[:10]}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_alpha_decay(self, intent: dict) -> dict:
        """Query alpha decay status for each strategy."""
        if not self._fund:
            return {"available": False}
        try:
            decay = getattr(self._fund, "_alpha_decay", None)
            if not decay:
                return {"available": False}
            status: dict[str, Any] = {}
            for name in self._fund._controller._strategies:
                try:
                    profile = decay.fit_decay(name)
                    if profile:
                        status[name] = {
                            "initial_edge": profile.initial_edge,
                            "current_edge": profile.current_edge,
                            "half_life_days": profile.half_life_days,
                            "predicted_zero_crossing": profile.predicted_zero_crossing,
                            "edge_type": profile.edge_type,
                            "r_squared": profile.r_squared,
                        }
                except Exception:
                    pass
            return {"available": True, "strategies": status}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_execution_quality(self, intent: dict) -> dict:
        """Query execution quality metrics for each strategy."""
        if not self._fund:
            return {"available": False}
        try:
            eq = getattr(self._fund, "_exec_quality", None)
            if not eq:
                return {"available": False}
            metrics: dict[str, Any] = {}
            for name in self._fund._controller._strategies:
                try:
                    m = eq.strategy_metrics(name)
                    if m:
                        metrics[name] = m
                except Exception:
                    pass
            return {"available": True, "strategies": metrics}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    def _tool_stress_test(self, intent: dict) -> dict:
        """Run quick stress test scenarios."""
        if not self._fund:
            return {"available": False}
        try:
            stress = getattr(self._fund, "_stress_tester", None)
            if not stress:
                return {"available": False}
            # Gather arguments required by FundStressTester.run()
            engines: dict[str, Any] = {}
            strategy_capitals: dict[str, float] = {}
            for name, state in self._fund._controller._strategies.items():
                eng = state.get("engine")
                if eng:
                    engines[name] = eng
                strategy_capitals[name] = state.get("capital", 0)
            latest = self._fund._nav.latest()
            current_nav = latest.total_nav if latest else self._fund._config.total_capital
            hwm = self._fund._nav.high_water_mark
            result = stress.run(engines, strategy_capitals, current_nav, hwm)
            return {"available": True, "scenarios": result.summary()}
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    # ------------------------------------------------------------------
    # Analyzers (reasoning)
    # ------------------------------------------------------------------

    def _analyze_fund_overview(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse overall fund health."""
        findings: list[Finding] = []

        perf = obs.get("performance", {})
        risk = obs.get("risk", {})

        if not perf.get("available") or not risk.get("available"):
            return findings

        nav = risk.get("nav", 0)
        dd = risk.get("drawdown", 0)
        kill = risk.get("kill_switch_active", False)

        if kill:
            findings.append(Finding(
                category="risk",
                severity="critical",
                title="Kill switch is active",
                detail="Fund kill switch has been triggered. All trading halted.",
                evidence={"kill_switch": True, "drawdown": dd},
            ))

        if dd > self.DD_CRITICAL:
            findings.append(Finding(
                category="risk",
                severity="critical",
                title=f"Severe drawdown: {dd:.1%}",
                detail=f"Drawdown exceeds {self.DD_CRITICAL:.0%}. Consider reducing exposure.",
                evidence={"drawdown": dd, "nav": nav},
            ))
        elif dd > self.DD_HIGH:
            findings.append(Finding(
                category="risk",
                severity="high",
                title=f"Elevated drawdown: {dd:.1%}",
                detail=f"Drawdown exceeds {self.DD_HIGH:.0%}. Monitor closely.",
                evidence={"drawdown": dd, "nav": nav},
            ))
        elif dd > self.DD_MEDIUM:
            findings.append(Finding(
                category="risk",
                severity="medium",
                title=f"Moderate drawdown: {dd:.1%}",
                detail="Drawdown within normal range but worth monitoring.",
                evidence={"drawdown": dd, "nav": nav},
            ))

        # Strategy count
        strats = perf.get("strategies", {})
        active = sum(1 for s in strats.values() if s.get("status") == "running")
        total = len(strats)

        if total > 0 and active == 0:
            findings.append(Finding(
                category="anomaly",
                severity="high",
                title="No active strategies",
                detail=f"All {total} strategies are inactive.",
                evidence={"total": total, "active": active},
            ))
        elif total > 0:
            findings.append(Finding(
                category="insight",
                severity="info",
                title=f"Fund overview: {active}/{total} strategies active",
                detail=f"NAV: {nav:.2f}, Drawdown: {dd:.2%}",
                evidence={"nav": nav, "drawdown": dd, "active": active, "total": total},
            ))

        return findings

    def _analyze_risk_exposure(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse VaR budget usage."""
        findings: list[Finding] = []
        risk = obs.get("risk", {})
        if not risk.get("available"):
            return findings

        var_usage = risk.get("var_usage", {})
        if isinstance(var_usage, dict):
            total_usage = var_usage.get("total_usage", 0)
            if total_usage > self.VAR_CRITICAL:
                findings.append(Finding(
                    category="risk",
                    severity="critical",
                    title=f"VaR budget nearly exhausted: {total_usage:.0%}",
                    detail=f"Portfolio VaR usage exceeds {self.VAR_CRITICAL:.0%}. Reduce positions or widen limits.",
                    evidence=var_usage,
                ))
            elif total_usage > self.VAR_HIGH:
                findings.append(Finding(
                    category="risk",
                    severity="high",
                    title=f"VaR budget elevated: {total_usage:.0%}",
                    detail=f"Portfolio VaR usage exceeds {self.VAR_HIGH:.0%}.",
                    evidence=var_usage,
                ))

        return findings

    def _analyze_drawdown(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse per-strategy drawdown patterns."""
        findings: list[Finding] = []
        perf = obs.get("performance", {})
        if not perf.get("available"):
            return findings

        for name, metrics in perf.get("strategies", {}).items():
            dd = metrics.get("drawdown", 0)
            if dd > self.DD_STRAT_CRITICAL:
                findings.append(Finding(
                    category="risk",
                    severity="critical",
                    title=f"Strategy {name}: severe drawdown {dd:.1%}",
                    detail=f"Strategy drawdown exceeds {self.DD_STRAT_CRITICAL:.0%}. Consider stopping.",
                    evidence={"strategy": name, "drawdown": dd, "nav": metrics.get("nav", 0)},
                ))
            elif dd > self.DD_STRAT_HIGH:
                findings.append(Finding(
                    category="risk",
                    severity="high",
                    title=f"Strategy {name}: elevated drawdown {dd:.1%}",
                    detail=f"Strategy drawdown exceeds {self.DD_STRAT_HIGH:.0%}.",
                    evidence={"strategy": name, "drawdown": dd},
                ))

        return findings

    def _analyze_concentration(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse portfolio concentration via correlation alerts."""
        findings: list[Finding] = []
        corr = obs.get("correlations", {})
        if not corr.get("available"):
            return findings

        alerts = corr.get("alerts", [])
        if len(alerts) > 0:
            findings.append(Finding(
                category="risk",
                severity="high",
                title=f"Correlation alerts: {len(alerts)} active",
                detail="High cross-strategy correlations detected. Portfolio may be concentrated.",
                evidence={"alert_count": len(alerts), "alerts": alerts[:5]},
            ))

        return findings

    def _analyze_regime_risk(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse regime-specific risks."""
        findings: list[Finding] = []
        regime = obs.get("regime", {})
        if not regime.get("available"):
            return findings

        current = regime.get("regime", "unknown")
        snapshot = regime.get("snapshot", {})

        if current == "crisis":
            findings.append(Finding(
                category="risk",
                severity="critical",
                title="Crisis regime detected",
                detail="Market regime classified as crisis. Defensive positioning recommended.",
                evidence={"regime": current, "snapshot": snapshot},
            ))
        elif current == "stressed":
            findings.append(Finding(
                category="risk",
                severity="high",
                title="Stressed regime detected",
                detail="Market showing stress signals. Monitor positions closely.",
                evidence={"regime": current, "snapshot": snapshot},
            ))

        findings.append(Finding(
            category="insight",
            severity="info",
            title=f"Current regime: {current}",
            detail=f"Confidence: {snapshot.get('confidence', 0):.2f}, Volatility: {snapshot.get('volatility', 0):.4f}",
            evidence={"regime": current, "snapshot": snapshot},
        ))

        return findings

    def _analyze_strategy_performance(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse individual strategy performance."""
        findings: list[Finding] = []
        perf = obs.get("performance", {})
        if not perf.get("available"):
            return findings

        target = intent.get("strategy_name")
        strats = perf.get("strategies", {})

        for name, metrics in strats.items():
            if target and name != target:
                continue

            nav = metrics.get("nav", 0)
            dd = metrics.get("drawdown", 0)
            status = metrics.get("status", "unknown")

            if status == "paused":
                findings.append(Finding(
                    category="anomaly",
                    severity="medium",
                    title=f"Strategy {name} is paused",
                    detail="Strategy has been paused. Check if intentional.",
                    evidence={"strategy": name, "status": status},
                ))

            if status == "running" and nav < self.STRAT_NAV_LOW and dd > self.STRAT_DD_MIN:
                findings.append(Finding(
                    category="risk",
                    severity="high",
                    title=f"Strategy {name} losing capital",
                    detail=f"NAV {nav:.2f} with {dd:.1%} drawdown.",
                    evidence={"strategy": name, "nav": nav, "drawdown": dd},
                ))

        return findings

    def _analyze_execution(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse execution quality issues (slippage, fill rate)."""
        findings: list[Finding] = []
        eq = obs.get("execution_quality", {})
        if not eq.get("available"):
            return findings

        for name, metrics in eq.get("strategies", {}).items():
            if not isinstance(metrics, dict):
                continue
            slippage = metrics.get("avg_slippage", 0)
            if slippage > self.SLIPPAGE_HIGH:
                findings.append(Finding(
                    category="anomaly",
                    severity="high",
                    title=f"High slippage on {name}: {slippage:.1%}",
                    detail=f"Average slippage exceeds {self.SLIPPAGE_HIGH:.0%}. Check market liquidity and order sizing.",
                    evidence={"strategy": name, "metrics": metrics},
                ))
            fill_rate = metrics.get("fill_rate", 1.0)
            if fill_rate < self.FILL_RATE_LOW:
                findings.append(Finding(
                    category="anomaly",
                    severity="medium",
                    title=f"Low fill rate on {name}: {fill_rate:.0%}",
                    detail=f"Less than {self.FILL_RATE_LOW:.0%} of orders filling. Consider adjusting pricing.",
                    evidence={"strategy": name, "fill_rate": fill_rate},
                ))

        return findings

    def _analyze_alpha_health(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse alpha/edge decay across strategies."""
        findings: list[Finding] = []
        decay = obs.get("alpha_decay", {})
        if not decay.get("available"):
            return findings

        for name, d in decay.get("strategies", {}).items():
            if not isinstance(d, dict):
                continue
            decay_rate = d.get("decay_rate", 0)
            current_edge = d.get("current_edge", 0)
            initial_edge = d.get("initial_edge", 0)

            if initial_edge > 0:
                ratio = current_edge / initial_edge
                if ratio < self.EDGE_DECAY_SEVERE:
                    findings.append(Finding(
                        category="risk",
                        severity="high",
                        title=f"Edge severely decayed on {name}",
                        detail=(
                            f"Current edge {current_edge:.3f} is "
                            f"<{self.EDGE_DECAY_SEVERE:.0%} of initial {initial_edge:.3f}."
                        ),
                        evidence={
                            "strategy": name,
                            "current_edge": current_edge,
                            "initial_edge": initial_edge,
                            "decay_rate": decay_rate,
                        },
                    ))
                elif ratio < self.EDGE_DECAY_MODERATE:
                    findings.append(Finding(
                        category="risk",
                        severity="medium",
                        title=f"Edge decaying on {name}",
                        detail=f"Current edge at {ratio:.0%} of initial.",
                        evidence={"strategy": name, "decay_rate": decay_rate},
                    ))

        return findings

    def _analyze_feed_health(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse feed health (staleness)."""
        findings: list[Finding] = []
        feeds = obs.get("feeds", {})
        if not feeds.get("available"):
            return findings

        stale_count = 0
        feed_data = feeds.get("feeds", {})
        for fname, fdata in feed_data.items():
            if fdata.get("stale", False):
                stale_count += 1
                findings.append(Finding(
                    category="anomaly",
                    severity="high",
                    title=f"Stale feed: {fname}",
                    detail=f"Feed data is {fdata.get('age_secs', 0):.0f}s old (>{self.FEED_STALE_SECS:.0f}s).",
                    evidence={"feed": fname, "age_secs": fdata.get("age_secs", 0)},
                ))

        total = len(feed_data)
        if total > 0 and stale_count == 0:
            findings.append(Finding(
                category="insight",
                severity="info",
                title=f"All {total} feeds healthy",
                detail="No stale feeds detected.",
                evidence={"total_feeds": total},
            ))

        return findings

    def _analyze_market_opportunities(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse market opportunities from graph and hypotheses."""
        findings: list[Finding] = []

        graph_opps = obs.get("graph_opportunities", {})
        if graph_opps.get("available"):
            opps = graph_opps.get("opportunities", [])
            for opp in opps[:5]:
                if isinstance(opp, dict):
                    findings.append(Finding(
                        category="opportunity",
                        severity="medium",
                        title=f"Opportunity: {str(opp.get('content', 'unknown'))[:60]}",
                        detail=(
                            f"Confidence: {opp.get('confidence', 0):.0%}. "
                            f"Source: {opp.get('source', 'unknown')}."
                        ),
                        evidence=opp,
                    ))

        hyp = obs.get("hypotheses", {})
        if hyp.get("available"):
            for h in hyp.get("hypotheses", [])[:5]:
                if isinstance(h, dict) and h.get("confidence", 0) > self.HYPOTHESIS_CONFIDENCE_MIN:
                    findings.append(Finding(
                        category="opportunity",
                        severity="medium",
                        title=f"Active hypothesis: {str(h.get('statement', ''))[:60]}",
                        detail=(
                            f"Confidence: {h.get('confidence', 0):.0%}, "
                            f"Edge: {h.get('edge_estimate', 0):.3f}"
                        ),
                        evidence=h,
                    ))

        return findings

    def _analyze_edge_signals(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse edge signals from hypotheses and alpha model."""
        findings: list[Finding] = []
        hyp = obs.get("hypotheses", {})
        if not hyp.get("available"):
            return findings

        active = hyp.get("hypotheses", [])
        validated = [h for h in active if isinstance(h, dict) and h.get("state") == "VALIDATED"]
        decaying = [h for h in active if isinstance(h, dict) and h.get("state") == "DECAYING"]

        if validated:
            findings.append(Finding(
                category="insight",
                severity="info",
                title=f"{len(validated)} validated hypotheses ready",
                detail="These hypotheses have passed backtesting and are ready for deployment.",
                evidence={
                    "count": len(validated),
                    "hypotheses": [h.get("statement", "") for h in validated[:5]],
                },
            ))

        if decaying:
            findings.append(Finding(
                category="risk",
                severity="medium",
                title=f"{len(decaying)} hypotheses showing edge decay",
                detail="Monitor these for potential retirement.",
                evidence={
                    "count": len(decaying),
                    "hypotheses": [h.get("statement", "") for h in decaying[:5]],
                },
            ))

        return findings

    def _analyze_correlation_opportunities(self, intent: dict, obs: dict) -> list[Finding]:
        """Analyse cross-market correlations for hedging / arbitrage."""
        findings: list[Finding] = []

        graph_corr = obs.get("graph_correlations", {})
        if graph_corr.get("available"):
            clusters = graph_corr.get("clusters", [])
            for cluster in clusters[:3]:
                if isinstance(cluster, dict):
                    market_count = len(cluster.get("markets", []))
                    findings.append(Finding(
                        category="opportunity",
                        severity="medium",
                        title=f"Correlated market cluster ({market_count} markets)",
                        detail="Cross-market correlation detected. Potential for hedging or arbitrage.",
                        evidence=cluster,
                    ))

        return findings

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _deduplicate(findings: list[Finding]) -> list[Finding]:
        """Remove duplicate findings by title."""
        seen: set[str] = set()
        unique: list[Finding] = []
        for f in findings:
            if f.title not in seen:
                seen.add(f.title)
                unique.append(f)
        return unique

    @staticmethod
    def _severity_rank(severity: str) -> int:
        """Lower rank = higher severity."""
        ranks = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        return ranks.get(severity, 5)
