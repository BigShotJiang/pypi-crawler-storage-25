"""Double-entry fund accounting ledger."""

from __future__ import annotations

import hashlib
import hmac as _hmac_mod
import logging
import math
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger("horizon.fund.ledger")

_LEDGER_HMAC_KEY = b"horizon_ledger_integrity_v1"  # For tamper detection, not secrecy

# Currency code validation: 3-10 uppercase alphanumeric characters (e.g., USD, USDC, BTC, EUR)
_CURRENCY_RE = re.compile(r"^[A-Za-z0-9]{3,10}$")


def _validate_currency(currency: str) -> str:
    """Validate and normalize a currency code.

    Args:
        currency: Currency code string.

    Returns:
        Uppercased currency code.

    Raises:
        ValueError: If currency code is invalid.
    """
    if not isinstance(currency, str):
        raise ValueError(f"Currency must be a string, got {type(currency).__name__}")
    currency = currency.strip()
    if not _CURRENCY_RE.match(currency):
        raise ValueError(
            f"Invalid currency code '{currency}': must be 3-10 alphanumeric characters"
        )
    return currency.upper()


class Account(str, Enum):
    """Ledger account types."""
    CASH = "cash"
    POSITIONS = "positions"
    FEES_RECEIVABLE = "fees_receivable"
    MANAGEMENT_FEES = "management_fees"
    PERFORMANCE_FEES = "performance_fees"
    REALIZED_PNL = "realized_pnl"
    UNREALIZED_PNL = "unrealized_pnl"


@dataclass(frozen=True)
class JournalEntry:
    """An immutable double-entry journal record."""
    entry_id: int
    timestamp: float
    debit_account: Account
    credit_account: Account
    amount: float
    currency: str
    reference: str
    description: str


class FundLedger:
    """SQLite-backed double-entry accounting ledger.

    Every capital movement is recorded as a journal entry with a debit
    and credit account. Account balances are derived from the sum of
    debits minus the sum of credits for that account.

    The ledger is append-only: entries cannot be modified or deleted.
    """

    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS journal_entries (
        entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp REAL NOT NULL,
        debit_account TEXT NOT NULL,
        credit_account TEXT NOT NULL,
        amount REAL NOT NULL CHECK(amount > 0),
        currency TEXT NOT NULL DEFAULT 'USD',
        reference TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL DEFAULT '',
        entry_hmac TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_journal_ts ON journal_entries(timestamp);
    CREATE INDEX IF NOT EXISTS idx_journal_ref ON journal_entries(reference);
    CREATE INDEX IF NOT EXISTS idx_journal_debit ON journal_entries(debit_account);
    CREATE INDEX IF NOT EXISTS idx_journal_credit ON journal_entries(credit_account);
    """

    _TRIGGERS = """
    CREATE TRIGGER IF NOT EXISTS prevent_journal_update
    BEFORE UPDATE ON journal_entries
    BEGIN
        SELECT RAISE(ABORT, 'Journal entries are immutable');
    END;
    CREATE TRIGGER IF NOT EXISTS prevent_journal_delete
    BEFORE DELETE ON journal_entries
    BEGIN
        SELECT RAISE(ABORT, 'Journal entries cannot be deleted');
    END;
    """

    def __init__(self, db_path: str | None = None, default_currency: str = "USD") -> None:
        self._default_currency = _validate_currency(default_currency)
        self._db_path = db_path or os.path.join(
            os.path.expanduser("~"), ".horizon", "fund_ledger.db"
        )
        db_dir = os.path.dirname(self._db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(self._SCHEMA)
        # Add entry_hmac column if upgrading from older schema
        try:
            self._conn.execute("ALTER TABLE journal_entries ADD COLUMN entry_hmac TEXT NOT NULL DEFAULT ''")
            self._conn.commit()
        except sqlite3.OperationalError:
            pass  # Column already exists
        # Add currency column if upgrading from older schema
        try:
            self._conn.execute("ALTER TABLE journal_entries ADD COLUMN currency TEXT NOT NULL DEFAULT 'USD'")
            self._conn.commit()
        except sqlite3.OperationalError:
            pass  # Column already exists
        self._conn.executescript(self._TRIGGERS)
        self._conn.commit()
        if db_dir:
            try:
                os.chmod(self._db_path, 0o600)
            except OSError:
                pass
        self._lock = threading.Lock()

        # Load last HMAC for chain continuity
        row = self._conn.execute(
            "SELECT entry_hmac FROM journal_entries ORDER BY entry_id DESC LIMIT 1"
        ).fetchone()
        self._prev_hmac: str = row[0] if (row and row[0]) else "0" * 64

    @staticmethod
    def _compute_entry_hmac(
        entry_id: int, debit: str, credit: str, amount: float,
        reference: str, prev_hmac: str,
    ) -> str:
        """Compute HMAC for a journal entry in the integrity chain."""
        msg = f"{entry_id}|{debit}|{credit}|{amount:.8f}|{reference}|{prev_hmac}"
        return _hmac_mod.new(_LEDGER_HMAC_KEY, msg.encode(), hashlib.sha256).hexdigest()

    def _record(
        self,
        debit: Account,
        credit: Account,
        amount: float,
        reference: str,
        description: str,
        currency: str | None = None,
    ) -> JournalEntry:
        """Record a journal entry. Amount must be positive and finite."""
        if not math.isfinite(amount) or amount <= 0:
            raise ValueError(f"Amount must be finite and positive, got {amount}")

        currency = _validate_currency(currency or self._default_currency)

        now = time.time()
        with self._lock:
            cursor = self._conn.execute(
                """INSERT INTO journal_entries
                   (timestamp, debit_account, credit_account, amount, currency, reference, description, entry_hmac)
                   VALUES (?, ?, ?, ?, ?, ?, ?, '')""",
                (now, debit.value, credit.value, amount, currency, str(reference), str(description)),
            )
            entry_id = cursor.lastrowid or 0

            # Compute and store HMAC chain
            entry_hmac = self._compute_entry_hmac(
                entry_id, debit.value, credit.value, amount,
                str(reference), self._prev_hmac,
            )
            # Temporarily disable immutability trigger for HMAC update
            self._conn.execute("DROP TRIGGER IF EXISTS prevent_journal_update")
            self._conn.execute(
                "UPDATE journal_entries SET entry_hmac = ? WHERE entry_id = ?",
                (entry_hmac, entry_id),
            )
            # Re-create the trigger
            self._conn.execute("""
                CREATE TRIGGER IF NOT EXISTS prevent_journal_update
                BEFORE UPDATE ON journal_entries
                BEGIN
                    SELECT RAISE(ABORT, 'Journal entries are immutable');
                END
            """)
            self._conn.commit()
            self._prev_hmac = entry_hmac

        return JournalEntry(
            entry_id=entry_id,
            timestamp=now,
            debit_account=debit,
            credit_account=credit,
            amount=amount,
            currency=currency,
            reference=str(reference),
            description=str(description),
        )

    def verify_integrity(self) -> bool:
        """Walk the HMAC chain and verify each entry's integrity.

        Returns:
            True if all entries have valid HMACs, False if any tampering detected.
        """
        with self._lock:
            rows = self._conn.execute(
                """SELECT entry_id, debit_account, credit_account, amount,
                          reference, entry_hmac
                   FROM journal_entries ORDER BY entry_id"""
            ).fetchall()

        prev_hmac = "0" * 64
        for entry_id, debit, credit, amount, reference, stored_hmac in rows:
            if not stored_hmac:
                # Legacy entry without HMAC — skip
                continue
            expected = self._compute_entry_hmac(
                entry_id, debit, credit, amount, reference, prev_hmac,
            )
            if expected != stored_hmac:
                logger.error(
                    "Ledger integrity violation at entry_id=%d: expected=%s stored=%s",
                    entry_id, expected[:16], stored_hmac[:16],
                )
                return False
            prev_hmac = stored_hmac
        return True

    def deposit(self, amount: float, reference: str = "", currency: str | None = None) -> JournalEntry:
        """Record a cash deposit into the fund.

        Debit CASH (increase asset), credit REALIZED_PNL (equity proxy).
        """
        return self._record(
            Account.CASH, Account.REALIZED_PNL, amount, reference,
            f"Deposit: {amount:.2f}",
            currency=currency,
        )

    def withdraw(self, amount: float, reference: str = "", currency: str | None = None) -> JournalEntry:
        """Record a cash withdrawal from the fund.

        Debit REALIZED_PNL (reduce equity proxy), credit CASH (decrease asset).

        Raises:
            ValueError: If withdrawal exceeds available cash.
        """
        cash = self.balance(Account.CASH)
        if amount > cash:
            raise ValueError(f"Insufficient cash: {cash:.2f} < {amount:.2f}")
        return self._record(
            Account.REALIZED_PNL, Account.CASH, amount, reference,
            f"Withdrawal: {amount:.2f}",
            currency=currency,
        )

    def record_trade_pnl(
        self, strategy: str, amount: float, reference: str = "",
        currency: str | None = None,
    ) -> JournalEntry:
        """Record realized trading P&L for a strategy."""
        abs_amount = abs(amount)
        if abs_amount < 1e-12:
            raise ValueError("PnL amount too small to record")
        if amount >= 0:
            return self._record(
                Account.POSITIONS, Account.REALIZED_PNL, abs_amount, reference,
                f"Realized gain: {strategy} +{abs_amount:.2f}",
                currency=currency,
            )
        return self._record(
            Account.REALIZED_PNL, Account.POSITIONS, abs_amount, reference,
            f"Realized loss: {strategy} -{abs_amount:.2f}",
            currency=currency,
        )

    def accrue_fee(
        self, fee_type: str, amount: float, reference: str = "",
        currency: str | None = None,
    ) -> JournalEntry:
        """Accrue a fee (management or performance)."""
        credit_account = (
            Account.MANAGEMENT_FEES if fee_type == "management"
            else Account.PERFORMANCE_FEES
        )
        return self._record(
            Account.FEES_RECEIVABLE, credit_account, amount, reference,
            f"{fee_type.capitalize()} fee: {amount:.4f}",
            currency=currency,
        )

    def balance(self, account: Account) -> float:
        """Compute the current balance of an account.

        Balance = SUM(debits to this account) - SUM(credits to this account).
        """
        with self._lock:
            row = self._conn.execute(
                """SELECT
                    COALESCE(SUM(CASE WHEN debit_account = ? THEN amount ELSE 0 END), 0) -
                    COALESCE(SUM(CASE WHEN credit_account = ? THEN amount ELSE 0 END), 0)
                FROM journal_entries""",
                (account.value, account.value),
            ).fetchone()
        return row[0] if row else 0.0

    def balance_sheet(self) -> dict[str, float]:
        """Return all account balances."""
        return {account.value: self.balance(account) for account in Account}

    def income_statement(self, since: float = 0.0) -> dict[str, float]:
        """Return income statement since a timestamp.

        Returns realized PnL, fees collected, and net income.
        """
        with self._lock:
            row = self._conn.execute(
                """SELECT
                    COALESCE(SUM(CASE WHEN credit_account = 'realized_pnl' THEN amount ELSE 0 END), 0) -
                    COALESCE(SUM(CASE WHEN debit_account = 'realized_pnl' THEN amount ELSE 0 END), 0),
                    COALESCE(SUM(CASE WHEN credit_account = 'management_fees' THEN amount ELSE 0 END), 0),
                    COALESCE(SUM(CASE WHEN credit_account = 'performance_fees' THEN amount ELSE 0 END), 0)
                FROM journal_entries WHERE timestamp >= ?""",
                (since,),
            ).fetchone()

        realized_pnl = row[0] if row else 0.0
        mgmt_fees = row[1] if row else 0.0
        perf_fees = row[2] if row else 0.0
        total_fees = mgmt_fees + perf_fees

        return {
            "realized_pnl": realized_pnl,
            "management_fees": mgmt_fees,
            "performance_fees": perf_fees,
            "total_fees": total_fees,
            "net_income": realized_pnl - total_fees,
        }

    def recent_entries(self, limit: int = 50) -> list[JournalEntry]:
        """Return the most recent journal entries."""
        limit = min(limit, 10000)  # Prevent memory exhaustion
        with self._lock:
            rows = self._conn.execute(
                """SELECT entry_id, timestamp, debit_account, credit_account,
                          amount, currency, reference, description
                   FROM journal_entries ORDER BY entry_id DESC LIMIT ?""",
                (limit,),
            ).fetchall()

        return [
            JournalEntry(
                entry_id=r[0],
                timestamp=r[1],
                debit_account=Account(r[2]),
                credit_account=Account(r[3]),
                amount=r[4],
                currency=r[5] or self._default_currency,
                reference=r[6],
                description=r[7],
            )
            for r in reversed(rows)
        ]

    def entry_count(self) -> int:
        """Total number of journal entries."""
        with self._lock:
            row = self._conn.execute("SELECT COUNT(*) FROM journal_entries").fetchone()
        return row[0] if row else 0

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()
