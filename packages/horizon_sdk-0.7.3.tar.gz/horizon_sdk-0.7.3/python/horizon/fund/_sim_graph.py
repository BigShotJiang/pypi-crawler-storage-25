"""Simulation-to-Graph Memory Loop.

Bridges the backtester, live strategies, and knowledge graph by writing
structured events as graph facts with causal metadata. This gives both
backtest and live strategies persistent causal memory.

Key responsibilities:
- Record backtest outcomes as graph facts with causal metadata
- Record live strategy events (fills, settlements, regime changes) as graph facts
- Build entity relationships from observed market behavior
- Query historical context from graph for current decisions
"""

from __future__ import annotations

import logging
import time

logger = logging.getLogger("horizon.fund.sim_graph")


class SimGraphBridge:
    """Bridges simulation/live events to the knowledge graph for persistent causal memory.

    All public methods return plain dicts for JSON serialization and use
    safe-fail try/except to avoid disrupting callers on graph errors.

    Graph growth is bounded by ``max_entities`` and ``max_relationships``.
    When either limit is exceeded, the oldest entries (by creation/update
    timestamp) are pruned to bring the count back to 90% of the limit.
    """

    def __init__(
        self,
        knowledge_graph,
        max_entities: int = 50_000,
        max_relationships: int = 200_000,
        max_facts: int = 500_000,
    ) -> None:
        """
        Args:
            knowledge_graph: KnowledgeGraph instance (from _knowledge_graph.py).
            max_entities: Maximum number of entity nodes before pruning.
            max_relationships: Maximum number of relationship edges before pruning.
            max_facts: Maximum number of facts before pruning.
        """
        self._kg = knowledge_graph
        self._max_entities = max_entities
        self._max_relationships = max_relationships
        self._max_facts = max_facts
        self._ops_since_prune = 0
        self._prune_check_interval = 100  # check every N write operations

    # ------------------------------------------------------------------
    # Backtest Event Recording
    # ------------------------------------------------------------------

    def record_backtest_result(
        self,
        strategy_name: str,
        market_id: str,
        backtest_result: dict,
    ) -> dict:
        """Record a backtest outcome in the graph.

        Creates/updates market entity, records outcome fact with causal
        metadata. If Sharpe >= 1.0 an additional ``edge_detected`` fact is
        recorded.

        Returns:
            Summary dict with status, market_id, strategy, fact_id, confidence.
        """
        try:
            self._ensure_market_entity(market_id)

            total_pnl = backtest_result.get("total_pnl", 0.0)
            sharpe = backtest_result.get("sharpe", 0.0)
            max_dd = backtest_result.get("max_drawdown", 0.0)
            n_trades = backtest_result.get("n_trades", 0)
            win_rate = backtest_result.get("win_rate", 0.0)

            # More trades => higher confidence (clamped to [0.1, 0.95])
            confidence = min(0.95, max(0.1, 0.3 + 0.4 * min(1.0, n_trades / 50)))

            fact = self._kg.record_fact(
                entity_id=market_id,
                fact_type="outcome",
                content=(
                    f"Backtest '{strategy_name}': PnL={total_pnl:.2f}, "
                    f"Sharpe={sharpe:.2f}, MaxDD={max_dd:.2%}, Trades={n_trades}"
                ),
                confidence=confidence,
                source="backtest",
                metadata={
                    "strategy_name": strategy_name,
                    "total_pnl": total_pnl,
                    "sharpe": sharpe,
                    "max_drawdown": max_dd,
                    "n_trades": n_trades,
                    "win_rate": win_rate,
                    "causal_context": self._build_causal_context(backtest_result),
                },
            )

            # Record edge signal for strong backtests
            if sharpe >= 1.0:
                try:
                    self._kg.record_fact(
                        entity_id=market_id,
                        fact_type="edge_detected",
                        content=f"Strategy '{strategy_name}' shows edge: Sharpe={sharpe:.2f}",
                        confidence=min(0.9, confidence),
                        source="backtest",
                        metadata={
                            "strategy_name": strategy_name,
                            "sharpe": sharpe,
                            "edge_type": "backtest_validated",
                        },
                    )
                except Exception:
                    logger.debug("Failed to record edge fact for %s", market_id)

            self._maybe_prune()
            return {
                "status": "recorded",
                "market_id": market_id,
                "strategy": strategy_name,
                "fact_id": fact.get("fact_id"),
                "confidence": confidence,
            }
        except Exception:
            logger.exception(
                "Failed to record backtest result for %s on %s",
                strategy_name,
                market_id,
            )
            return {"status": "error", "market_id": market_id, "strategy": strategy_name}

    def record_backtest_failure(
        self,
        strategy_name: str,
        market_id: str,
        reason: str,
        details: dict | None = None,
    ) -> dict:
        """Record a backtest failure in the graph.

        Returns:
            Summary dict with status, market_id, fact_id.
        """
        try:
            self._ensure_market_entity(market_id)

            fact = self._kg.record_fact(
                entity_id=market_id,
                fact_type="outcome",
                content=f"Backtest '{strategy_name}' failed: {reason}",
                confidence=0.8,
                source="backtest",
                metadata={
                    "strategy_name": strategy_name,
                    "outcome": "failure",
                    "reason": reason,
                    "details": details or {},
                },
            )

            self._maybe_prune()
            return {
                "status": "recorded",
                "market_id": market_id,
                "fact_id": fact.get("fact_id"),
            }
        except Exception:
            logger.exception(
                "Failed to record backtest failure for %s on %s",
                strategy_name,
                market_id,
            )
            return {"status": "error", "market_id": market_id}

    # ------------------------------------------------------------------
    # Live Strategy Event Recording
    # ------------------------------------------------------------------

    def record_fill(
        self,
        strategy_name: str,
        market_id: str,
        side: str,
        price: float,
        size: float,
        order_id: str = "",
    ) -> dict:
        """Record a fill event in the graph.

        Fills are recorded with confidence=1.0 (they are certain).

        Returns:
            Summary dict with status, fact_id.
        """
        try:
            self._ensure_market_entity(market_id)

            fact = self._kg.record_fact(
                entity_id=market_id,
                fact_type="observation",
                content=f"Fill: {side} {size:.4f}@{price:.4f} ({strategy_name})",
                confidence=1.0,
                source="live",
                metadata={
                    "event_type": "fill",
                    "strategy_name": strategy_name,
                    "side": side,
                    "price": price,
                    "size": size,
                    "order_id": order_id,
                },
            )

            self._maybe_prune()
            return {"status": "recorded", "fact_id": fact.get("fact_id")}
        except Exception:
            logger.debug("Failed to record fill for %s on %s", strategy_name, market_id)
            return {"status": "error", "market_id": market_id}

    def record_settlement(
        self,
        market_id: str,
        outcome: str,
        settlement_price: float,
        strategies_affected: list[str] | None = None,
    ) -> dict:
        """Record a market settlement in the graph.

        Also expires active ``correlated_with`` and ``hedges`` relationships
        for the settled market since they are no longer actionable.

        Returns:
            Summary dict with status, fact_id.
        """
        try:
            self._ensure_market_entity(market_id)

            fact = self._kg.record_fact(
                entity_id=market_id,
                fact_type="settlement",
                content=f"Market settled: {outcome} at {settlement_price:.4f}",
                confidence=1.0,
                source="live",
                metadata={
                    "outcome": outcome,
                    "settlement_price": settlement_price,
                    "strategies_affected": strategies_affected or [],
                },
            )

            # Expire active relationships for settled market
            try:
                rels = self._kg.get_relationships(market_id, active_only=True)
                for rel in rels:
                    if rel.get("rel_type") in ("correlated_with", "hedges"):
                        self._kg.expire_relationship(rel["rel_id"])
            except Exception:
                logger.debug("Failed to expire relationships for settled market %s", market_id)

            self._maybe_prune()
            return {"status": "recorded", "fact_id": fact.get("fact_id")}
        except Exception:
            logger.exception("Failed to record settlement for %s", market_id)
            return {"status": "error", "market_id": market_id}

    def record_regime_change(
        self,
        from_regime: str,
        to_regime: str,
        affected_markets: list[str] | None = None,
    ) -> dict:
        """Record a regime change across affected markets.

        Returns:
            Summary dict with status, regime_transition, per-market results.
        """
        results: list[dict] = []
        for market_id in affected_markets or []:
            try:
                self._ensure_market_entity(market_id)
                fact = self._kg.record_fact(
                    entity_id=market_id,
                    fact_type="regime_change",
                    content=f"Regime transition: {from_regime} -> {to_regime}",
                    confidence=0.8,
                    source="live",
                    metadata={
                        "from_regime": from_regime,
                        "to_regime": to_regime,
                    },
                )
                results.append({"market_id": market_id, "fact_id": fact.get("fact_id")})
            except Exception as exc:
                logger.debug("Failed to record regime change for %s: %s", market_id, exc)
                results.append({"market_id": market_id, "error": str(exc)})

        if results:
            self._maybe_prune()
        return {
            "status": "recorded",
            "regime_transition": f"{from_regime}->{to_regime}",
            "markets": results,
        }

    def record_edge_decay(
        self,
        strategy_name: str,
        market_id: str,
        initial_edge: float,
        current_edge: float,
        decay_rate: float,
    ) -> dict:
        """Record edge decay observation.

        Classifies severity as ``severe`` (<30% remaining), ``moderate``
        (<50%), or ``mild``.

        Returns:
            Summary dict with status, fact_id, severity.
        """
        try:
            self._ensure_market_entity(market_id)

            ratio = current_edge / initial_edge if initial_edge > 0 else 0.0
            if ratio < 0.3:
                severity = "severe"
            elif ratio < 0.5:
                severity = "moderate"
            else:
                severity = "mild"

            fact = self._kg.record_fact(
                entity_id=market_id,
                fact_type="edge_detected",
                content=(
                    f"Edge decay ({severity}): {strategy_name} edge "
                    f"{initial_edge:.3f}->{current_edge:.3f}"
                ),
                confidence=0.7,
                source="live",
                metadata={
                    "strategy_name": strategy_name,
                    "initial_edge": initial_edge,
                    "current_edge": current_edge,
                    "decay_rate": decay_rate,
                    "ratio": ratio,
                    "severity": severity,
                },
            )

            self._maybe_prune()
            return {
                "status": "recorded",
                "fact_id": fact.get("fact_id"),
                "severity": severity,
            }
        except Exception:
            logger.debug(
                "Failed to record edge decay for %s on %s", strategy_name, market_id
            )
            return {"status": "error", "market_id": market_id, "severity": "unknown"}

    def record_price_move(
        self,
        market_id: str,
        price: float,
        change_pct: float,
        volume: float = 0.0,
    ) -> dict:
        """Record a significant price move.

        Price move facts expire after 24 hours since they are short-lived
        signals.

        Returns:
            Summary dict with status, fact_id.
        """
        try:
            self._ensure_market_entity(market_id)

            direction = "up" if change_pct > 0 else "down"
            abs_change = abs(change_pct)
            if abs_change > 0.1:
                magnitude = "large"
            elif abs_change > 0.05:
                magnitude = "moderate"
            else:
                magnitude = "small"

            fact = self._kg.record_fact(
                entity_id=market_id,
                fact_type="price_move",
                content=f"Price {direction} {abs_change:.1%} to {price:.4f} ({magnitude})",
                confidence=1.0,
                source="live",
                metadata={
                    "price": price,
                    "change_pct": change_pct,
                    "volume": volume,
                    "direction": direction,
                    "magnitude": magnitude,
                },
                expires_at=time.time() + 86400,  # 24h expiry
            )

            self._maybe_prune()
            return {"status": "recorded", "fact_id": fact.get("fact_id")}
        except Exception:
            logger.debug("Failed to record price move for %s", market_id)
            return {"status": "error", "market_id": market_id}

    # ------------------------------------------------------------------
    # Relationship Building
    # ------------------------------------------------------------------

    def link_correlated_markets(
        self,
        market_a: str,
        market_b: str,
        correlation: float,
        source: str = "backtest",
    ) -> dict:
        """Create or update a correlation relationship between markets.

        Expires any existing ``correlated_with`` relationship between the
        same pair before creating a new one.

        Returns:
            Summary dict with status, rel_id, weight.
        """
        try:
            self._ensure_market_entity(market_a)
            self._ensure_market_entity(market_b)

            # Expire existing correlations between these two
            try:
                existing = self._kg.get_relationships(
                    market_a, direction="outgoing", rel_type="correlated_with"
                )
                for rel in existing:
                    if rel.get("target_id") == market_b:
                        self._kg.expire_relationship(rel["rel_id"])
            except Exception:
                logger.debug(
                    "Failed to expire old correlation %s->%s", market_a, market_b
                )

            rel = self._kg.add_relationship(
                source_id=market_a,
                target_id=market_b,
                rel_type="correlated_with",
                weight=abs(correlation),
                properties={"correlation": correlation, "source": source},
            )

            self._maybe_prune()
            return {
                "status": "linked",
                "rel_id": rel.get("rel_id"),
                "weight": abs(correlation),
            }
        except Exception:
            logger.debug("Failed to link correlated markets %s<->%s", market_a, market_b)
            return {"status": "error", "market_a": market_a, "market_b": market_b}

    def link_market_to_event(
        self,
        market_id: str,
        event_id: str,
        event_name: str = "",
    ) -> dict:
        """Link a market to an event entity.

        Creates the event entity if it does not already exist.

        Returns:
            Summary dict with status, rel_id.
        """
        try:
            self._ensure_market_entity(market_id)

            if not self._kg.get_entity(event_id):
                self._kg.add_entity(event_id, "event", event_name or event_id)

            rel = self._kg.add_relationship(
                source_id=market_id,
                target_id=event_id,
                rel_type="part_of",
            )

            self._maybe_prune()
            return {"status": "linked", "rel_id": rel.get("rel_id")}
        except Exception:
            logger.debug("Failed to link market %s to event %s", market_id, event_id)
            return {"status": "error", "market_id": market_id, "event_id": event_id}

    def link_hedge_pair(
        self,
        market_a: str,
        market_b: str,
        hedge_ratio: float = 1.0,
    ) -> dict:
        """Mark two markets as a hedging pair.

        Returns:
            Summary dict with status, rel_id.
        """
        try:
            self._ensure_market_entity(market_a)
            self._ensure_market_entity(market_b)

            rel = self._kg.add_relationship(
                source_id=market_a,
                target_id=market_b,
                rel_type="hedges",
                weight=hedge_ratio,
                properties={"hedge_ratio": hedge_ratio},
            )

            self._maybe_prune()
            return {"status": "linked", "rel_id": rel.get("rel_id")}
        except Exception:
            logger.debug("Failed to link hedge pair %s<->%s", market_a, market_b)
            return {"status": "error", "market_a": market_a, "market_b": market_b}

    # ------------------------------------------------------------------
    # Context Queries
    # ------------------------------------------------------------------

    def strategy_history_for_market(
        self,
        market_id: str,
        strategy_name: str | None = None,
    ) -> list[dict]:
        """Get historical strategy outcomes for a market from the graph.

        Args:
            market_id: Target market.
            strategy_name: If provided, filter to this strategy only.

        Returns:
            List of fact dicts (outcome facts from backtest source).
        """
        try:
            facts = self._kg.get_facts(
                entity_id=market_id,
                fact_type="outcome",
                source="backtest",
                limit=50,
            )

            if strategy_name:
                facts = [
                    f
                    for f in facts
                    if f.get("metadata", {}).get("strategy_name") == strategy_name
                ]

            return facts
        except Exception:
            logger.debug("Failed to get strategy history for %s", market_id)
            return []

    def market_causal_history(
        self,
        market_id: str,
        lookback_hours: float = 168.0,
    ) -> dict:
        """Build causal history for a market: facts, neighbors, context.

        Default lookback is 7 days (168 hours).

        Returns:
            Dict with market_id, facts, neighbors, context, lookback_hours.
        """
        try:
            since = time.time() - lookback_hours * 3600

            facts = self._kg.get_facts(entity_id=market_id, since=since, limit=100)
            neighbors = self._kg.neighbors(market_id, depth=2)
            context = self._kg.market_context(market_id)

            return {
                "market_id": market_id,
                "facts": facts,
                "neighbors": neighbors,
                "context": context,
                "lookback_hours": lookback_hours,
            }
        except Exception:
            logger.debug("Failed to build causal history for %s", market_id)
            return {
                "market_id": market_id,
                "facts": [],
                "neighbors": {},
                "context": {},
                "lookback_hours": lookback_hours,
            }

    def similar_market_outcomes(self, market_id: str) -> list[dict]:
        """Find outcomes from correlated/similar markets.

        Looks up correlated markets and retrieves their outcome facts,
        annotating each with correlation weight and source market.

        Returns:
            List of fact dicts sorted by confidence (up to 30).
        """
        try:
            correlated = self._kg.correlated_markets(market_id, min_weight=0.3)

            outcomes: list[dict] = []
            for corr in correlated[:10]:
                corr_entity = corr.get("entity", {})
                corr_market_id = corr_entity.get("entity_id", "")
                if not corr_market_id:
                    continue

                try:
                    facts = self._kg.get_facts(
                        entity_id=corr_market_id,
                        fact_type="outcome",
                        limit=10,
                    )
                    for fact in facts:
                        fact["correlation_weight"] = corr.get("weight", 0.0)
                        fact["correlated_market"] = corr_market_id
                        outcomes.append(fact)
                except Exception:
                    logger.debug(
                        "Failed to get outcomes for correlated market %s",
                        corr_market_id,
                    )

            outcomes.sort(key=lambda x: x.get("confidence", 0.0), reverse=True)
            return outcomes[:30]
        except Exception:
            logger.debug("Failed to find similar market outcomes for %s", market_id)
            return []

    def edge_history(self, market_id: str) -> list[dict]:
        """Get edge detection history for a market.

        Returns:
            List of ``edge_detected`` fact dicts (up to 50).
        """
        try:
            return self._kg.get_facts(
                entity_id=market_id,
                fact_type="edge_detected",
                limit=50,
            )
        except Exception:
            logger.debug("Failed to get edge history for %s", market_id)
            return []

    # ------------------------------------------------------------------
    # Batch Operations
    # ------------------------------------------------------------------

    def sync_discovery_to_graph(self, markets: list) -> dict:
        """Sync discovered markets into the knowledge graph.

        Accepts Market objects (with ``.id``, ``.question``/``.name``,
        ``.exchange``) or plain dicts with ``id``, ``name``, ``exchange``
        keys. Each market is also linked to an exchange entity.

        Returns:
            Summary dict with added, updated, errors, total counts.
        """
        added = 0
        updated = 0
        errors = 0

        for market in markets:
            try:
                # Extract fields from Market objects or dicts
                if hasattr(market, "id"):
                    mid = market.id
                    name = (
                        getattr(market, "question", "")
                        or getattr(market, "name", mid)
                    )
                    exchange = getattr(market, "exchange", "")
                    props = {
                        "exchange": exchange,
                        "condition_id": getattr(market, "condition_id", ""),
                        "active": getattr(market, "active", True),
                    }
                elif isinstance(market, dict):
                    mid = market.get("id", "")
                    name = market.get("name", mid)
                    exchange = market.get("exchange", "")
                    props = {
                        "exchange": exchange,
                        "condition_id": market.get("condition_id", ""),
                        "active": market.get("active", True),
                    }
                else:
                    continue

                if not mid:
                    continue

                existing = self._kg.get_entity(mid)
                self._kg.add_entity(mid, "market", name[:500], properties=props)

                if existing:
                    updated += 1
                else:
                    added += 1

                # Link to exchange entity
                if exchange:
                    ex_id = f"exchange:{exchange}"
                    try:
                        if not self._kg.get_entity(ex_id):
                            self._kg.add_entity(ex_id, "exchange", exchange)
                        self._kg.add_relationship(mid, ex_id, "part_of")
                    except Exception:
                        # Duplicate relationship is fine — swallow IntegrityError
                        pass

            except Exception as exc:
                errors += 1
                logger.debug("Failed to sync market to graph: %s", exc)

        if added > 0 or updated > 0:
            self._maybe_prune()
        return {
            "added": added,
            "updated": updated,
            "errors": errors,
            "total": len(markets),
        }

    def prune_stale_facts(self, max_age_days: float = 30.0) -> dict:
        """Prune old facts from the graph.

        Returns:
            Summary dict with removed count and max_age_days.
        """
        try:
            removed = self._kg.prune(max_age_days=max_age_days, min_confidence=0.1)
            return {"removed": removed, "max_age_days": max_age_days}
        except Exception:
            logger.exception("Failed to prune stale facts")
            return {"removed": 0, "max_age_days": max_age_days}

    # ------------------------------------------------------------------
    # Internal Helpers
    # ------------------------------------------------------------------

    def _ensure_market_entity(self, market_id: str) -> None:
        """Ensure a market entity exists in the graph (create if missing)."""
        if not self._kg.get_entity(market_id):
            self._kg.add_entity(market_id, "market", market_id)
            self._maybe_prune()

    def _maybe_prune(self) -> None:
        """Periodically check graph size and prune if limits are exceeded."""
        self._ops_since_prune += 1
        if self._ops_since_prune < self._prune_check_interval:
            return
        self._ops_since_prune = 0
        try:
            self._enforce_limits()
        except Exception:
            logger.debug("Error during graph size enforcement")

    def _enforce_limits(self) -> None:
        """Prune oldest entities, relationships, and facts when limits are exceeded.

        Deletes the oldest entries (by timestamp) to bring counts down to 90%
        of the configured maximums.
        """
        try:
            stats = self._kg.stats()
        except Exception:
            return

        total_entities = stats.get("total_entities", 0)
        total_rels = stats.get("total_relationships", 0)
        total_facts = stats.get("total_facts", 0)

        conn = getattr(self._kg, "_conn", None)
        lock = getattr(self._kg, "_lock", None)
        if conn is None or lock is None:
            return

        pruned = 0

        # Prune excess facts (oldest by timestamp)
        if total_facts > self._max_facts:
            target = int(self._max_facts * 0.9)
            excess = total_facts - target
            try:
                with lock:
                    conn.execute(
                        "DELETE FROM facts WHERE fact_id IN ("
                        "  SELECT fact_id FROM facts ORDER BY timestamp ASC LIMIT ?"
                        ")",
                        (excess,),
                    )
                    conn.commit()
                pruned += excess
            except Exception:
                logger.debug("Failed to prune excess facts")

        # Prune excess relationships (oldest by created_at)
        if total_rels > self._max_relationships:
            target = int(self._max_relationships * 0.9)
            excess = total_rels - target
            try:
                with lock:
                    conn.execute(
                        "DELETE FROM relationships WHERE rel_id IN ("
                        "  SELECT rel_id FROM relationships ORDER BY created_at ASC LIMIT ?"
                        ")",
                        (excess,),
                    )
                    conn.commit()
                pruned += excess
            except Exception:
                logger.debug("Failed to prune excess relationships")

        # Prune excess entities (oldest by updated_at, excluding those with active relationships/facts)
        if total_entities > self._max_entities:
            target = int(self._max_entities * 0.9)
            excess = total_entities - target
            try:
                with lock:
                    conn.execute(
                        "DELETE FROM entities WHERE entity_id IN ("
                        "  SELECT entity_id FROM entities"
                        "  WHERE entity_id NOT IN (SELECT DISTINCT entity_id FROM facts)"
                        "    AND entity_id NOT IN (SELECT DISTINCT source_id FROM relationships)"
                        "    AND entity_id NOT IN (SELECT DISTINCT target_id FROM relationships)"
                        "  ORDER BY updated_at ASC LIMIT ?"
                        ")",
                        (excess,),
                    )
                    conn.commit()
                    # If we still need to prune more, remove oldest regardless
                    remaining = conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
                    if remaining > self._max_entities:
                        still_excess = remaining - target
                        conn.execute(
                            "DELETE FROM facts WHERE entity_id IN ("
                            "  SELECT entity_id FROM entities ORDER BY updated_at ASC LIMIT ?"
                            ")",
                            (still_excess,),
                        )
                        conn.execute(
                            "DELETE FROM relationships WHERE source_id IN ("
                            "  SELECT entity_id FROM entities ORDER BY updated_at ASC LIMIT ?"
                            ") OR target_id IN ("
                            "  SELECT entity_id FROM entities ORDER BY updated_at ASC LIMIT ?"
                            ")",
                            (still_excess, still_excess),
                        )
                        conn.execute(
                            "DELETE FROM entities WHERE entity_id IN ("
                            "  SELECT entity_id FROM entities ORDER BY updated_at ASC LIMIT ?"
                            ")",
                            (still_excess,),
                        )
                        conn.commit()
                        pruned += still_excess
                pruned += excess
            except Exception:
                logger.debug("Failed to prune excess entities")

        if pruned > 0:
            logger.info(
                "Graph pruned: ~%d entries removed (limits: entities=%d, rels=%d, facts=%d)",
                pruned, self._max_entities, self._max_relationships, self._max_facts,
            )

    @staticmethod
    def _build_causal_context(backtest_result: dict) -> dict:
        """Extract causal context from a backtest result dict.

        Pulls out market conditions, strategy parameters, key events, and
        regime information when present.
        """
        ctx: dict = {}

        if "market_conditions" in backtest_result:
            ctx["market_conditions"] = backtest_result["market_conditions"]

        if "parameters" in backtest_result:
            ctx["parameters"] = backtest_result["parameters"]

        if "events" in backtest_result:
            ctx["events"] = backtest_result["events"][:10]

        if "regime" in backtest_result:
            ctx["regime"] = backtest_result["regime"]

        return ctx
