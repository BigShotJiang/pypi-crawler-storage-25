"""Third-party data providers for Horizon SDK.

Wraps external APIs (Unusual Whales, Massive/Polygon) so users can
query options flow, dark pool data, market snapshots, and more
through a single Horizon interface — CLI, MCP, or Python.
"""

from horizon.providers.unusual_whales import UnusualWhalesProvider
from horizon.providers.massive import MassiveProvider

__all__ = ["UnusualWhalesProvider", "MassiveProvider"]
