"""Metamorphic Execution — Invisible orders that can't be fingerprinted.

Every execution looks different. Randomized sizes, Poisson timing,
varying aggressiveness, venue rotation. Pattern recognition by
adversarial HFT becomes statistically impossible.
"""

from __future__ import annotations

import math
import random
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class ExecutionSlice:
    """A single child order in a metamorphic execution plan."""
    slice_id: int
    size: float
    delay_seconds: float
    aggression: float        # 0 = passive limit, 1 = aggressive market
    venue: str | None = None # Exchange to route to
    is_decoy: bool = False   # Noise order (small, canceled quickly)
    price_offset: float = 0.0  # Offset from mid for limit orders


@dataclass
class ExecutionPlan:
    """A complete metamorphic execution plan."""
    plan_id: str
    market_id: str
    side: str
    total_size: float
    urgency: float
    slices: list[ExecutionSlice] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)

    @property
    def n_slices(self) -> int:
        return len([s for s in self.slices if not s.is_decoy])


class MetamorphicExecutor:
    """Every execution is unique. No two runs produce the same pattern.

    Randomization layers:
    1. Order sizes: ±jitter% uniform noise around base slice
    2. Timing: Poisson-distributed intervals (exponential inter-arrival)
    3. Aggressiveness: Beta-distributed (skewed toward passive by default)
    4. Venue rotation: Never same venue sequence twice
    5. Decoy orders: Occasional small orders on noise markets
    """

    def __init__(self, size_jitter: float = 0.15,
                 aggression_skew: tuple[float, float] = (2.0, 5.0),
                 enabled: bool = True):
        self._lock = threading.Lock()
        self._size_jitter = size_jitter
        self._aggression_alpha = aggression_skew[0]
        self._aggression_beta = aggression_skew[1]
        self._enabled = enabled
        self._rng = random.Random()

        # Available venues (populated by caller)
        self._venues: list[str] = []

        # Entropy tracking
        self._plan_history: deque[dict[str, Any]] = deque(maxlen=100)
        self._behavioral_entropy: float = 1.0

        # Stats
        self._plans_created = 0
        self._decoys_generated = 0

    def set_venues(self, venues: list[str]) -> None:
        """Set available execution venues."""
        with self._lock:
            self._venues = list(venues)

    # -----------------------------------------------------------------------
    # Plan Generation
    # -----------------------------------------------------------------------

    def create_plan(self, market_id: str, side: str,
                    total_size: float, urgency: float = 0.5,
                    n_slices: int = 0, add_decoys: bool = False,
                    venues: list[str] | None = None) -> ExecutionPlan:
        """Generate a metamorphic execution plan.

        Args:
            market_id: Target market
            side: "buy" or "sell"
            total_size: Total quantity to execute
            urgency: 0 (patient) to 1 (immediate). Affects timing and aggression.
            n_slices: Number of child orders. 0 = auto-select based on size.
            add_decoys: Whether to add noise orders.
            venues: Available venues. Uses self._venues if None.

        Returns:
            ExecutionPlan with randomized slices.
        """
        if not self._enabled:
            # Pass-through: single slice, no randomization
            plan = ExecutionPlan(
                plan_id=f"mp-{self._plans_created}",
                market_id=market_id, side=side,
                total_size=total_size, urgency=urgency,
            )
            plan.slices.append(ExecutionSlice(
                slice_id=0, size=total_size,
                delay_seconds=0.0, aggression=urgency,
            ))
            return plan

        available_venues = venues or self._venues or ["default"]

        # Auto-select slice count based on size
        if n_slices <= 0:
            if total_size < 10:
                n_slices = 1
            elif total_size < 100:
                n_slices = max(2, int(total_size / 20))
            elif total_size < 1000:
                n_slices = max(3, int(total_size / 100))
            else:
                n_slices = max(5, min(20, int(total_size / 500)))

        # 1. Randomize sizes: ±jitter% around base
        base_size = total_size / n_slices
        raw_sizes = [
            base_size * self._rng.uniform(1 - self._size_jitter,
                                          1 + self._size_jitter)
            for _ in range(n_slices)
        ]
        # Normalize to hit exact total
        s = sum(raw_sizes)
        sizes = [sz * total_size / s for sz in raw_sizes]

        # 2. Randomize timing: Poisson intervals
        lambda_rate = max(0.1, urgency * 10)
        delays = [0.0]  # First slice immediate
        for _ in range(n_slices - 1):
            delays.append(self._rng.expovariate(lambda_rate))

        # 3. Randomize aggressiveness: Beta distribution
        aggressions = [
            self._rng.betavariate(self._aggression_alpha, self._aggression_beta)
            for _ in range(n_slices)
        ]
        # Urgency floor: minimum aggression scales with urgency
        aggressions = [max(a, urgency * 0.3) for a in aggressions]

        # 4. Venue rotation: shuffle, never repeat consecutive
        venue_sequence = []
        for i in range(n_slices):
            candidates = [v for v in available_venues
                          if not venue_sequence or v != venue_sequence[-1]]
            if not candidates:
                candidates = available_venues
            venue_sequence.append(self._rng.choice(candidates))

        # 5. Price offsets for limit orders (passive slices)
        offsets = []
        for agg in aggressions:
            if agg > 0.7:
                offsets.append(0.0)  # Market order — no offset
            else:
                offsets.append(self._rng.uniform(0.001, 0.01) * (1 - agg))

        # Build slices
        slices = []
        for i in range(n_slices):
            slices.append(ExecutionSlice(
                slice_id=i,
                size=sizes[i],
                delay_seconds=delays[i],
                aggression=aggressions[i],
                venue=venue_sequence[i],
                is_decoy=False,
                price_offset=offsets[i],
            ))

        # 6. Add decoy orders (optional)
        if add_decoys and n_slices >= 3:
            n_decoys = self._rng.randint(1, max(1, n_slices // 3))
            for d in range(n_decoys):
                slices.append(ExecutionSlice(
                    slice_id=n_slices + d,
                    size=base_size * self._rng.uniform(0.01, 0.05),
                    delay_seconds=self._rng.expovariate(lambda_rate * 2),
                    aggression=self._rng.uniform(0.0, 0.3),
                    venue=self._rng.choice(available_venues),
                    is_decoy=True,
                    price_offset=self._rng.uniform(0.005, 0.02),
                ))
            with self._lock:
                self._decoys_generated += n_decoys

        with self._lock:
            self._plans_created += 1

        plan = ExecutionPlan(
            plan_id=f"mp-{self._plans_created}",
            market_id=market_id, side=side,
            total_size=total_size, urgency=urgency,
            slices=slices,
        )

        # Record for entropy tracking
        self._record_plan_fingerprint(plan)

        return plan

    # -----------------------------------------------------------------------
    # Entropy Management
    # -----------------------------------------------------------------------

    def _record_plan_fingerprint(self, plan: ExecutionPlan) -> None:
        """Record plan statistics for behavioral entropy computation."""
        real_slices = [s for s in plan.slices if not s.is_decoy]
        if not real_slices:
            return

        fingerprint = {
            "n_slices": len(real_slices),
            "avg_size": sum(s.size for s in real_slices) / len(real_slices),
            "avg_delay": sum(s.delay_seconds for s in real_slices) / len(real_slices),
            "avg_aggression": sum(s.aggression for s in real_slices) / len(real_slices),
            "venues_used": len(set(s.venue for s in real_slices if s.venue)),
            "has_decoys": any(s.is_decoy for s in plan.slices),
        }
        with self._lock:
            self._plan_history.append(fingerprint)

    def behavioral_entropy(self) -> float:
        """Compute behavioral entropy: how predictable are our executions?

        Low entropy = predictable = exploitable.
        Target: high enough to be undetectable, low enough to be profitable.
        """
        with self._lock:
            history = list(self._plan_history)

        if len(history) < 5:
            return 1.0  # Unknown = assume high entropy

        # Compute entropy over slice count distribution
        n_slices_counts: dict[int, int] = {}
        for fp in history:
            n = fp["n_slices"]
            n_slices_counts[n] = n_slices_counts.get(n, 0) + 1

        total = sum(n_slices_counts.values())
        entropy = 0.0
        for count in n_slices_counts.values():
            p = count / total
            if p > 0:
                entropy -= p * math.log(p)

        # Normalize to [0, 1]
        max_entropy = math.log(max(len(n_slices_counts), 1))
        if max_entropy > 0:
            entropy /= max_entropy

        self._behavioral_entropy = entropy
        return entropy

    def increase_randomization(self) -> None:
        """Increase randomization when adversarial detection is suspected."""
        with self._lock:
            self._size_jitter = min(0.30, self._size_jitter * 1.5)
            self._aggression_beta = min(10.0, self._aggression_beta * 1.2)

    def decrease_randomization(self) -> None:
        """Decrease randomization when execution quality suffers."""
        with self._lock:
            self._size_jitter = max(0.05, self._size_jitter * 0.8)
            self._aggression_beta = max(2.0, self._aggression_beta * 0.9)

    # -----------------------------------------------------------------------
    # Status
    # -----------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Current metamorphic executor status."""
        return {
            "enabled": self._enabled,
            "size_jitter": round(self._size_jitter, 4),
            "aggression_skew": (self._aggression_alpha, self._aggression_beta),
            "venues": list(self._venues),
            "plans_created": self._plans_created,
            "decoys_generated": self._decoys_generated,
            "behavioral_entropy": round(self.behavioral_entropy(), 4),
        }
