"""Quality-diversity archive for the Hive evolutionary engine.

MAP-Elites maintains a grid of behaviorally distinct strategy archetypes.
Each cell in the grid holds the single best-performing ``StrategyGenome``
discovered so far for that behavioral niche.  When a regime change occurs,
the Hive can instantly pull pre-adapted strategies from relevant cells
rather than evolving from scratch.

Grid dimensions:

    5 (holding_period) x 5 (directional_bias) x 3 (volatility_pref) x 4 (asset_focus) = 300 cells

Thread-safe: every public method acquires a single lock so the archive can
be read from dashboard / API threads while the evolution loop mutates it.
"""

from __future__ import annotations

import logging
import random
import threading
from typing import Any

from horizon.hive._types import StrategyGenome

logger = logging.getLogger("horizon.hive.map_elites")

# Grid extents.
_HP_BINS = 5   # holding_period
_DB_BINS = 5   # directional_bias
_VP_BINS = 3   # volatility_pref
_AF_BINS = 4   # asset_focus
_TOTAL_CELLS = _HP_BINS * _DB_BINS * _VP_BINS * _AF_BINS  # 300


class MAPElitesArchive:
    """Quality-diversity archive of strategy archetypes.

    Grid: 5 (holding_period) x 5 (directional_bias) x 3 (volatility_pref) x 4 (asset_focus) = 300 cells.
    Each cell holds the BEST StrategyGenome found for that behavioral niche.

    When regime changes, the Hive can instantly activate strategies from
    relevant cells -- no evolution from scratch needed.
    """

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # cell (hp, db, vp, af) -> StrategyGenome
        self._grid: dict[tuple[int, int, int, int], StrategyGenome] = {}

    # ------------------------------------------------------------------ #
    # Core operations
    # ------------------------------------------------------------------ #

    def add(self, genome: StrategyGenome) -> bool:
        """Insert *genome* into its behavioral cell if it is the best so far.

        Uses ``genome.behavior_cell()`` for discretization.  Returns ``True``
        if the genome was placed (either the cell was empty or the incoming
        genome has strictly higher fitness than the incumbent).
        """
        cell = genome.behavior_cell()
        # Validate cell coordinates are in-range.
        hp, db, vp, af = cell
        if not (0 <= hp < _HP_BINS and 0 <= db < _DB_BINS
                and 0 <= vp < _VP_BINS and 0 <= af < _AF_BINS):
            logger.warning(
                "Genome %s produced out-of-range cell %s; clamping",
                genome.genome_id, cell,
            )
            cell = (
                max(0, min(_HP_BINS - 1, hp)),
                max(0, min(_DB_BINS - 1, db)),
                max(0, min(_VP_BINS - 1, vp)),
                max(0, min(_AF_BINS - 1, af)),
            )

        with self._lock:
            incumbent = self._grid.get(cell)
            if incumbent is None or genome.fitness > incumbent.fitness:
                self._grid[cell] = genome
                return True
            return False

    def get(self, cell: tuple[int, int, int, int]) -> StrategyGenome | None:
        """Return the genome occupying *cell*, or ``None`` if empty."""
        with self._lock:
            return self._grid.get(cell)

    # ------------------------------------------------------------------ #
    # Regime / asset queries
    # ------------------------------------------------------------------ #

    def get_best_for_regime(self, regime: str) -> list[StrategyGenome]:
        """Return genomes suited to the given regime.

        Regime mapping to grid dimensions:

        - ``"trending"``      -- directional_bias bins 3-4 (positive trend followers)
        - ``"mean_reverting"`` -- directional_bias bins 0-1 (mean reversion)
        - ``"volatile"``      -- volatility_pref bin 2 (crisis / high-vol)
        - ``"quiet"``         -- volatility_pref bin 0 (low-vol)

        Returns genomes sorted by fitness descending.
        """
        results: list[StrategyGenome] = []

        with self._lock:
            for (hp, db, vp, af), genome in self._grid.items():
                match = False
                if regime == "trending" and db >= 3:
                    match = True
                elif regime == "mean_reverting" and db <= 1:
                    match = True
                elif regime == "volatile" and vp == 2:
                    match = True
                elif regime == "quiet" and vp == 0:
                    match = True
                if match:
                    results.append(genome)

        results.sort(key=lambda g: g.fitness, reverse=True)
        return results

    def get_best_for_asset(self, asset_class: str) -> list[StrategyGenome]:
        """Return genomes filtered by asset_focus dimension.

        Asset-focus bins: 0=pm, 1=crypto, 2=equity, 3=cross.

        Returns genomes sorted by fitness descending.
        """
        af_target = {"pm": 0, "crypto": 1, "equity": 2, "cross": 3}.get(
            asset_class, -1,
        )
        if af_target < 0:
            return []

        results: list[StrategyGenome] = []
        with self._lock:
            for (hp, db, vp, af), genome in self._grid.items():
                if af == af_target:
                    results.append(genome)

        results.sort(key=lambda g: g.fitness, reverse=True)
        return results

    # ------------------------------------------------------------------ #
    # Aggregate queries
    # ------------------------------------------------------------------ #

    def get_all(self) -> list[StrategyGenome]:
        """Return every genome currently in the archive (unordered)."""
        with self._lock:
            return list(self._grid.values())

    def coverage(self) -> float:
        """Fraction of the 300-cell grid that is occupied."""
        with self._lock:
            n = len(self._grid)
        return n / _TOTAL_CELLS

    def cells_filled(self) -> int:
        """Number of occupied cells in the grid."""
        with self._lock:
            return len(self._grid)

    def best_n(self, n: int = 10) -> list[StrategyGenome]:
        """Return the top *n* genomes by fitness across the entire archive."""
        with self._lock:
            all_genomes = list(self._grid.values())
        all_genomes.sort(key=lambda g: g.fitness, reverse=True)
        return all_genomes[:n]

    def random_genome(self) -> StrategyGenome | None:
        """Return a uniformly random genome from the archive.

        Useful for seeding evolutionary operators.  Returns ``None`` if the
        archive is empty.
        """
        with self._lock:
            if not self._grid:
                return None
            return random.choice(list(self._grid.values()))

    # ------------------------------------------------------------------ #
    # Serialization
    # ------------------------------------------------------------------ #

    def snapshot(self) -> dict:
        """Return a JSON-serializable snapshot of the archive.

        Format::

            {
                "cells": {
                    "(hp,db,vp,af)": {<genome_dict>},
                    ...
                },
                "total_cells": 300,
                "cells_filled": <int>,
                "coverage": <float>,
            }
        """
        with self._lock:
            cells: dict[str, dict[str, Any]] = {}
            for cell, genome in self._grid.items():
                key = f"{cell[0]},{cell[1]},{cell[2]},{cell[3]}"
                cells[key] = {
                    "genome_id": genome.genome_id,
                    "source": genome.source.value,
                    "archetype": genome.archetype.value if genome.archetype else None,
                    "generation": genome.generation,
                    "lineage": list(genome.lineage),
                    "gp_tree": genome.gp_tree,
                    "hyperparams": dict(genome.hyperparams),
                    "holding_period": genome.holding_period,
                    "directional_bias": genome.directional_bias,
                    "volatility_pref": genome.volatility_pref,
                    "asset_focus": genome.asset_focus,
                    "fitness": genome.fitness,
                    "sharpe": genome.sharpe,
                    "max_drawdown": genome.max_drawdown,
                    "num_trades": genome.num_trades,
                    "complexity": genome.complexity,
                    "target_markets": list(genome.target_markets),
                    "target_exchanges": list(genome.target_exchanges),
                    "pipeline_config": dict(genome.pipeline_config),
                }
            filled = len(self._grid)

        return {
            "cells": cells,
            "total_cells": _TOTAL_CELLS,
            "cells_filled": filled,
            "coverage": filled / _TOTAL_CELLS,
        }

    def restore(self, data: dict) -> None:
        """Restore the archive from a previous :meth:`snapshot`.

        Existing data is replaced wholesale.  Unknown keys or malformed
        entries are silently skipped for forward compatibility.
        """
        cells_raw = data.get("cells")
        if not isinstance(cells_raw, dict):
            return

        from horizon.hive._types import SpawnSource, StrategyArchetype

        new_grid: dict[tuple[int, int, int, int], StrategyGenome] = {}

        for key_str, gdata in cells_raw.items():
            if not isinstance(gdata, dict):
                continue
            try:
                parts = [int(x) for x in key_str.split(",")]
                if len(parts) != 4:
                    continue
                cell = (parts[0], parts[1], parts[2], parts[3])
            except (ValueError, AttributeError):
                continue

            # Validate cell bounds.
            hp, db, vp, af = cell
            if not (0 <= hp < _HP_BINS and 0 <= db < _DB_BINS
                    and 0 <= vp < _VP_BINS and 0 <= af < _AF_BINS):
                continue

            try:
                archetype_raw = gdata.get("archetype")
                archetype = (
                    StrategyArchetype(archetype_raw) if archetype_raw else None
                )
                source_raw = gdata.get("source", "template")
                source = SpawnSource(source_raw)
            except ValueError:
                archetype = None
                source = SpawnSource.TEMPLATE

            genome = StrategyGenome(
                genome_id=gdata.get("genome_id", ""),
                source=source,
                archetype=archetype,
                generation=gdata.get("generation", 0),
                lineage=list(gdata.get("lineage", [])),
                gp_tree=gdata.get("gp_tree"),
                hyperparams=dict(gdata.get("hyperparams", {})),
                holding_period=float(gdata.get("holding_period", 0.0)),
                directional_bias=float(gdata.get("directional_bias", 0.0)),
                volatility_pref=float(gdata.get("volatility_pref", 0.5)),
                asset_focus=gdata.get("asset_focus", "cross"),
                fitness=float(gdata.get("fitness", 0.0)),
                sharpe=float(gdata.get("sharpe", 0.0)),
                max_drawdown=float(gdata.get("max_drawdown", 0.0)),
                num_trades=int(gdata.get("num_trades", 0)),
                complexity=int(gdata.get("complexity", 0)),
                target_markets=list(gdata.get("target_markets", [])),
                target_exchanges=list(gdata.get("target_exchanges", [])),
                pipeline_config=dict(gdata.get("pipeline_config", {})),
            )
            new_grid[cell] = genome

        with self._lock:
            self._grid = new_grid

        logger.info(
            "MAP-Elites archive restored: %d/%d cells filled (%.1f%% coverage)",
            len(new_grid), _TOTAL_CELLS, len(new_grid) / _TOTAL_CELLS * 100,
        )
