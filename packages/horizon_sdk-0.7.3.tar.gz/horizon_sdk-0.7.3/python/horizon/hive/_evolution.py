"""Darwinian strategy genesis wrapping Rust evolution.rs.

Island-model NSGA-II multi-objective evolution of trading strategy genomes.
The Rust core (``src/evolution.rs``) implements all computationally heavy
operators — selection, crossover, mutation, Pareto sorting, crowding
distance, island migration, convergence detection, and adaptive sigma.
This module orchestrates the evolutionary loop and maps float-vector
genomes to/from :class:`StrategyGenome` objects.

Thread-safe: all mutable state guarded by a single lock so concurrent
readers (dashboard, API) never see torn state.
"""

from __future__ import annotations

import copy
import logging
import math
import random
import threading
import time
import uuid
from typing import Callable, TYPE_CHECKING

from horizon.hive._types import HiveConfig, SpawnSource, StrategyGenome

if TYPE_CHECKING:
    from horizon.hive._db import HiveDB

logger = logging.getLogger("horizon.hive.evolution")

# ---------------------------------------------------------------------------
# Rust FFI — graceful fallback to pure-Python if unavailable
# ---------------------------------------------------------------------------

_RUST_AVAILABLE = False

try:
    import horizon as _hz

    # Probe for the key function to confirm the evolution module is present.
    _init_population = getattr(_hz, "init_population", None)
    _tournament_select = getattr(_hz, "tournament_select", None)
    _roulette_select = getattr(_hz, "roulette_select", None)
    _rank_select = getattr(_hz, "rank_select", None)
    _ucb1_select = getattr(_hz, "ucb1_select", None)
    _epsilon_greedy_select = getattr(_hz, "epsilon_greedy_select", None)
    _gaussian_mutate = getattr(_hz, "gaussian_mutate", None)
    _uniform_crossover = getattr(_hz, "uniform_crossover", None)
    _non_dominated_sort = getattr(_hz, "non_dominated_sort", None)
    _crowding_distance_assign = getattr(_hz, "crowding_distance_assign", None)
    _nsga2_select = getattr(_hz, "nsga2_select", None)
    _pareto_front = getattr(_hz, "pareto_front", None)
    _island_migrate = getattr(_hz, "island_migrate", None)
    _check_convergence = getattr(_hz, "check_convergence", None)
    _adapt_mutation_sigma = getattr(_hz, "adapt_mutation_sigma", None)
    _population_diversity = getattr(_hz, "population_diversity", None)
    _compute_generation_stats = getattr(_hz, "compute_generation_stats", None)

    # IslandConfig class for island_migrate
    _IslandConfig = getattr(_hz, "IslandConfig", None)
    _MigrationTopology = getattr(_hz, "MigrationTopology", None)

    if _init_population is not None and _nsga2_select is not None:
        _RUST_AVAILABLE = True
        logger.debug("Rust evolution backend available")
    else:
        logger.info("Rust evolution module incomplete — using pure-Python fallback")
except Exception:  # pragma: no cover
    logger.info("Rust evolution module not importable — using pure-Python fallback")

# ---------------------------------------------------------------------------
# Parameter encoding
# ---------------------------------------------------------------------------

PARAM_BOUNDS: list[tuple[str, float, float]] = [
    ("signal_threshold", 0.01, 2.0),
    ("position_size_mult", 0.1, 3.0),
    ("stop_loss_pct", 0.01, 0.20),
    ("take_profit_pct", 0.02, 0.50),
    ("rebalance_interval", 60.0, 86400.0),
    ("max_position_pct", 0.01, 0.30),
    ("spread_mult", 0.5, 5.0),
    ("decay_halflife", 300.0, 86400.0),
    ("regime_sensitivity", 0.0, 2.0),
    ("crowding_threshold", 0.3, 0.9),
]

# Pre-compute bound vectors once (used by Rust calls).
_PARAM_NAMES: list[str] = [b[0] for b in PARAM_BOUNDS]
_BOUNDS_MIN: list[float] = [b[1] for b in PARAM_BOUNDS]
_BOUNDS_MAX: list[float] = [b[2] for b in PARAM_BOUNDS]
_IS_DISCRETE: list[bool] = [False] * len(PARAM_BOUNDS)
_DIM = len(PARAM_BOUNDS)


# ---------------------------------------------------------------------------
# EvolutionEngine
# ---------------------------------------------------------------------------


class EvolutionEngine:
    """Darwinian strategy genesis wrapping Rust evolution.rs.

    Manages populations of StrategyGenome across island-model parallel
    evolution. Uses NSGA-II multi-objective optimization (Sharpe, drawdown,
    diversity). Self-adaptive mutation via Rust adapt_mutation_sigma().
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(
        self,
        config: HiveConfig,
        db: HiveDB | None = None,
    ) -> None:
        self._config = config
        self._db = db
        self._lock = threading.Lock()

        # Evolution state
        self.generation: int = 0
        self.sigma: float = 0.1
        self.best_fitness_history: list[float] = []

        # Convergence tracking
        self._gens_without_improvement: int = 0
        self._prev_best_fitness: float = float("-inf")

        # Adaptive mutation counters (reset each generation)
        self._mutation_success_count: int = 0
        self._mutation_total_count: int = 0

        # Genome registry: genome_id -> StrategyGenome
        self.genome_registry: dict[str, StrategyGenome] = {}

        # Per-genome fitness cache: genome_id -> fitness
        self._fitness_cache: dict[str, float] = {}

        # Islands: list of populations, each population is list of float vectors
        n_islands = max(1, config.island_count)
        pop_per_island = max(2, config.population_size // n_islands)

        self.islands: list[list[list[float]]] = []
        self._island_fitnesses: list[list[float]] = []

        seed_base = int(time.monotonic() * 1000) % (2**63)

        for i in range(n_islands):
            seed = (seed_base + i * 7919) % (2**63)
            pop = self._init_island_population(pop_per_island, seed)
            self.islands.append(pop)
            self._island_fitnesses.append([0.0] * len(pop))

        # Register initial genomes
        for island_pop in self.islands:
            for vec in island_pop:
                genome = self._decode_genome(vec)
                genome.source = SpawnSource.Evolution
                self.genome_registry[genome.genome_id] = genome

        logger.info(
            "EvolutionEngine initialized: %d islands x ~%d genomes, sigma=%.4f",
            n_islands,
            pop_per_island,
            self.sigma,
        )

    # ------------------------------------------------------------------
    # Population initialisation
    # ------------------------------------------------------------------

    def _init_island_population(
        self, pop_size: int, seed: int,
    ) -> list[list[float]]:
        """Initialize a random population within PARAM_BOUNDS."""
        if _RUST_AVAILABLE and _init_population is not None:
            try:
                return _init_population(
                    _BOUNDS_MIN, _BOUNDS_MAX, _IS_DISCRETE,
                    pop_size, seed,
                )
            except Exception:
                logger.debug("Rust init_population failed, using fallback")

        # Pure-Python fallback
        rng = random.Random(seed)
        population: list[list[float]] = []
        for _ in range(pop_size):
            genome: list[float] = []
            for lo, hi in zip(_BOUNDS_MIN, _BOUNDS_MAX):
                genome.append(rng.uniform(lo, hi))
            population.append(genome)
        return population

    # ------------------------------------------------------------------
    # Genome encoding / decoding
    # ------------------------------------------------------------------

    def _encode_genome(self, genome: StrategyGenome) -> list[float]:
        """Encode a StrategyGenome's hyperparams to a float vector.

        Parameters not present in ``genome.hyperparams`` use the midpoint
        of their respective bounds as a default.
        """
        vector: list[float] = []
        for name, lo, hi in PARAM_BOUNDS:
            val = genome.hyperparams.get(name, (lo + hi) / 2.0)
            # Clamp to bounds for safety.
            val = max(lo, min(hi, float(val)))
            vector.append(val)
        return vector

    def _decode_genome(
        self,
        vector: list[float],
        template: StrategyGenome | None = None,
    ) -> StrategyGenome:
        """Decode a float vector back to a StrategyGenome.

        Parameters
        ----------
        vector:
            Float vector of length ``len(PARAM_BOUNDS)``.
        template:
            Optional template genome to inherit non-evolved fields from
            (archetype, target_markets, pipeline_config, etc.).
            A deep copy is made — the template is never mutated.
        """
        if template is not None:
            genome = copy.deepcopy(template)
            genome.genome_id = uuid.uuid4().hex[:12]
        else:
            genome = StrategyGenome()

        genome.source = SpawnSource.Evolution
        genome.generation = self.generation

        for i, (name, lo, hi) in enumerate(PARAM_BOUNDS):
            if i < len(vector):
                val = max(lo, min(hi, vector[i]))
            else:
                val = (lo + hi) / 2.0
            genome.hyperparams[name] = val

        return genome

    # ------------------------------------------------------------------
    # Fitness evaluation
    # ------------------------------------------------------------------

    def evaluate_fitness(
        self,
        genome: StrategyGenome,
        backtest_sharpe: float,
        backtest_dd: float,
        num_trades: int,
        regime_sharpes: dict[str, float] | None = None,
    ) -> float:
        """Compute multi-objective fitness for a genome.

        Fitness combines:
        - Sharpe ratio (primary signal, weight 1.0)
        - Drawdown penalty for DD > 15% (weight 5.0)
        - Activity bonus for trade count (weight 0.2, capped at 200)
        - Parsimony pressure on complexity (weight 0.1)
        - Regime robustness from cross-regime Sharpe consistency (weight 0.3)

        Parameters
        ----------
        genome:
            The strategy genome being evaluated.
        backtest_sharpe:
            Sharpe ratio from backtest.
        backtest_dd:
            Maximum drawdown from backtest (0.0-1.0).
        num_trades:
            Number of trades executed in backtest.
        regime_sharpes:
            Optional dict of regime_name -> sharpe for robustness check.

        Returns
        -------
        float
            Composite fitness score. Higher is better.
        """
        # Sanitize inputs
        sharpe = backtest_sharpe if math.isfinite(backtest_sharpe) else 0.0
        dd = backtest_dd if math.isfinite(backtest_dd) else 1.0
        dd = max(0.0, min(1.0, dd))
        trades = max(0, num_trades)

        # Complexity: number of non-default hyperparams as a rough proxy.
        complexity = genome.complexity if genome.complexity > 0 else len(genome.hyperparams)

        # Regime consistency: std of sharpes across regimes (lower is better).
        regime_consistency = 0.0
        if regime_sharpes and len(regime_sharpes) >= 2:
            values = [v for v in regime_sharpes.values() if math.isfinite(v)]
            if len(values) >= 2:
                mean_s = sum(values) / len(values)
                var_s = sum((v - mean_s) ** 2 for v in values) / len(values)
                std_s = math.sqrt(var_s)
                # Consistency = 1 when std is 0, decays towards 0 as std grows.
                regime_consistency = max(0.0, 1.0 - std_s)

        fitness = (
            sharpe * 1.0
            - max(0.0, dd - 0.15) * 5.0        # Drawdown penalty > 15%
            + min(trades, 200) / 200.0 * 0.2    # Activity bonus
            - complexity / 100.0 * 0.1           # Parsimony pressure
            + regime_consistency * 0.3           # Regime robustness
        )

        # Guard against NaN/Inf in final result.
        if not math.isfinite(fitness):
            fitness = -10.0

        # Update genome fields.
        genome.fitness = fitness
        genome.sharpe = sharpe
        genome.max_drawdown = dd
        genome.num_trades = trades
        genome.complexity = complexity

        # Cache
        self._fitness_cache[genome.genome_id] = fitness

        return fitness

    # ------------------------------------------------------------------
    # Selection helpers
    # ------------------------------------------------------------------

    def _select_parents(
        self,
        fitnesses: list[float],
        count: int,
        seed: int,
    ) -> list[int]:
        """Select parent indices using tournament selection.

        Tries Rust tournament_select first, falls back to pure Python.
        """
        k = self._config.gp_tournament_size
        if _RUST_AVAILABLE and _tournament_select is not None:
            try:
                return [int(i) for i in _tournament_select(fitnesses, k, count, seed)]
            except Exception:
                pass
        return self._fallback_tournament_select(fitnesses, k, count, seed)

    # ------------------------------------------------------------------
    # Genetic operators
    # ------------------------------------------------------------------

    def _crossover(
        self, p1: list[float], p2: list[float], seed: int,
    ) -> list[float]:
        """Uniform crossover of two parent vectors.

        Tries Rust uniform_crossover, falls back to pure Python.
        """
        if _RUST_AVAILABLE and _uniform_crossover is not None:
            try:
                return list(_uniform_crossover(
                    p1, p2, self._config.gp_crossover_rate, seed,
                ))
            except Exception:
                pass
        return self._fallback_uniform_crossover(p1, p2, seed)

    def _mutate(
        self, genome_vec: list[float], seed: int,
    ) -> list[float]:
        """Gaussian mutation with adaptive sigma.

        Tries Rust gaussian_mutate, falls back to pure Python.
        """
        if _RUST_AVAILABLE and _gaussian_mutate is not None:
            try:
                return list(_gaussian_mutate(
                    genome_vec,
                    _BOUNDS_MIN,
                    _BOUNDS_MAX,
                    _IS_DISCRETE,
                    self.sigma,
                    self._config.gp_mutation_rate,
                    seed,
                ))
            except Exception:
                pass
        return self._fallback_gaussian_mutate(
            genome_vec, self.sigma, list(zip(_BOUNDS_MIN, _BOUNDS_MAX)), seed,
        )

    # ------------------------------------------------------------------
    # NSGA-II multi-objective selection
    # ------------------------------------------------------------------

    def _nsga2_select_survivors(
        self,
        population: list[list[float]],
        fitnesses: list[float],
        n_select: int,
    ) -> tuple[list[list[float]], list[float]]:
        """Select survivors using NSGA-II when Rust is available,
        otherwise fall back to simple truncation selection.

        Multi-objective: maximize Sharpe, minimize drawdown, maximize diversity.
        """
        if _RUST_AVAILABLE and _nsga2_select is not None and len(population) > 0:
            # Build multi-objective matrix: [sharpe, -drawdown, activity_bonus]
            # For NSGA-II all objectives are maximized, so negate drawdown.
            objectives: list[list[float]] = []
            for i, vec in enumerate(population):
                gid = self._vec_to_genome_id(vec)
                genome = self.genome_registry.get(gid)
                if genome is not None:
                    obj = [
                        genome.sharpe,
                        -genome.max_drawdown,
                        min(genome.num_trades, 200) / 200.0,
                    ]
                else:
                    # Fall back to scalar fitness as all 3 objectives.
                    f = fitnesses[i] if i < len(fitnesses) else 0.0
                    obj = [f, 0.0, 0.0]
                objectives.append(obj)

            try:
                result = _nsga2_select(objectives, n_select)
                selected_idx = [int(i) for i in result.selected_indices]
                new_pop = [population[i] for i in selected_idx if i < len(population)]
                new_fit = [fitnesses[i] for i in selected_idx if i < len(fitnesses)]
                if len(new_pop) >= n_select:
                    return new_pop[:n_select], new_fit[:n_select]
            except Exception:
                logger.debug("Rust nsga2_select failed, using truncation fallback")

        # Truncation fallback: sort by fitness descending, keep top n_select.
        paired = sorted(
            zip(fitnesses, population),
            key=lambda x: x[0],
            reverse=True,
        )
        new_fit = [p[0] for p in paired[:n_select]]
        new_pop = [p[1] for p in paired[:n_select]]
        return new_pop, new_fit

    def _vec_to_genome_id(self, vec: list[float]) -> str | None:
        """Find genome_id for a given float vector (approximate match)."""
        # Linear scan is acceptable for population sizes <= ~200.
        for gid, genome in self.genome_registry.items():
            encoded = self._encode_genome(genome)
            if len(encoded) == len(vec) and all(
                abs(a - b) < 1e-12 for a, b in zip(encoded, vec)
            ):
                return gid
        return None

    # ------------------------------------------------------------------
    # Run one generation
    # ------------------------------------------------------------------

    def run_generation(
        self,
        fitness_fn: Callable[[StrategyGenome], float],
    ) -> dict:
        """Execute one evolutionary generation across all islands.

        For each island:
        1. Evaluate fitness for every genome.
        2. Select parents via tournament selection.
        3. Crossover parents to produce offspring.
        4. Mutate offspring.
        5. Evaluate offspring fitness.
        6. Select survivors via NSGA-II (or truncation fallback).
        7. Adapt mutation sigma via Rechenberg 1/5 rule.
        8. Check convergence.

        Parameters
        ----------
        fitness_fn:
            Callable that takes a StrategyGenome and returns a scalar
            fitness value. Typically wraps a backtest call.

        Returns
        -------
        dict
            Generation statistics including generation number, best/mean
            fitness, sigma, diversity, convergence state.
        """
        with self._lock:
            gen_start = time.monotonic()
            self.generation += 1
            seed_base = (int(gen_start * 1000) + self.generation) % (2**63)

            # Reset per-generation mutation counters.
            self._mutation_success_count = 0
            self._mutation_total_count = 0

            all_fitnesses: list[float] = []
            total_offspring = 0

            for island_idx, island_pop in enumerate(self.islands):
                n_pop = len(island_pop)
                if n_pop < 2:
                    continue

                island_seed = (seed_base + island_idx * 6271) % (2**63)

                # --- 1. Evaluate current population ---
                fitnesses: list[float] = []
                for vec in island_pop:
                    genome = self._find_or_create_genome(vec)
                    try:
                        f = fitness_fn(genome)
                    except Exception:
                        f = -10.0
                        logger.debug(
                            "Fitness evaluation failed for %s", genome.genome_id,
                        )
                    if not math.isfinite(f):
                        f = -10.0
                    genome.fitness = f
                    self._fitness_cache[genome.genome_id] = f
                    fitnesses.append(f)

                # --- 2. Select parents ---
                n_offspring = max(2, n_pop)
                parent_indices = self._select_parents(
                    fitnesses, n_offspring * 2, island_seed,
                )

                # --- 3 & 4. Crossover + Mutation ---
                offspring: list[list[float]] = []
                offspring_fitnesses: list[float] = []

                for j in range(0, len(parent_indices) - 1, 2):
                    p1_idx = parent_indices[j] % n_pop
                    p2_idx = parent_indices[j + 1] % n_pop
                    p1 = island_pop[p1_idx]
                    p2 = island_pop[p2_idx]

                    cx_seed = (island_seed + j * 31) % (2**63)
                    child_vec = self._crossover(p1, p2, cx_seed)

                    mut_seed = (island_seed + j * 37 + 17) % (2**63)
                    child_vec = self._mutate(child_vec, mut_seed)

                    # --- 5. Evaluate offspring ---
                    child_genome = self._decode_genome(child_vec)
                    child_genome.lineage = self._build_lineage(
                        island_pop, p1_idx, p2_idx,
                    )
                    self.genome_registry[child_genome.genome_id] = child_genome

                    self._mutation_total_count += 1
                    try:
                        child_f = fitness_fn(child_genome)
                    except Exception:
                        child_f = -10.0
                    if not math.isfinite(child_f):
                        child_f = -10.0

                    child_genome.fitness = child_f
                    self._fitness_cache[child_genome.genome_id] = child_f

                    # Track mutation success (offspring better than worse parent).
                    parent_min_f = min(fitnesses[p1_idx], fitnesses[p2_idx])
                    if child_f > parent_min_f:
                        self._mutation_success_count += 1

                    offspring.append(child_vec)
                    offspring_fitnesses.append(child_f)
                    total_offspring += 1

                # --- 6. Combine + Select survivors ---
                combined_pop = island_pop + offspring
                combined_fit = fitnesses + offspring_fitnesses

                survivors, survivor_fit = self._nsga2_select_survivors(
                    combined_pop, combined_fit, n_pop,
                )

                self.islands[island_idx] = survivors
                self._island_fitnesses[island_idx] = survivor_fit
                all_fitnesses.extend(survivor_fit)

            # --- 7. Adapt mutation sigma ---
            self._adapt_sigma()

            # --- 8. Convergence check ---
            best_f = max(all_fitnesses) if all_fitnesses else 0.0
            mean_f = (
                sum(all_fitnesses) / len(all_fitnesses)
                if all_fitnesses
                else 0.0
            )
            self.best_fitness_history.append(best_f)

            diversity = self._compute_diversity()
            convergence = self._check_convergence(best_f, diversity)

            # Update tracking.
            if best_f > self._prev_best_fitness + 1e-4:
                self._gens_without_improvement = 0
                self._prev_best_fitness = best_f
            else:
                self._gens_without_improvement += 1

            # Prune stale genome registry entries (keep last 5x population).
            self._prune_registry()

            elapsed = time.monotonic() - gen_start

            stats = {
                "generation": self.generation,
                "best_fitness": round(best_f, 6),
                "mean_fitness": round(mean_f, 6),
                "sigma": round(self.sigma, 6),
                "diversity": round(diversity, 6),
                "offspring_count": total_offspring,
                "converged": convergence.get("converged", False),
                "convergence_reason": convergence.get("reason", ""),
                "gens_without_improvement": self._gens_without_improvement,
                "elapsed_s": round(elapsed, 4),
            }

            # Compute detailed generation stats via Rust if available.
            if _RUST_AVAILABLE and _compute_generation_stats is not None and all_fitnesses:
                try:
                    gs = _compute_generation_stats(self.generation, all_fitnesses)
                    stats["median_fitness"] = round(gs.median_fitness, 6)
                    stats["worst_fitness"] = round(gs.worst_fitness, 6)
                    stats["std_fitness"] = round(gs.std_fitness, 6)
                except Exception:
                    pass

            logger.info(
                "Generation %d: best=%.4f mean=%.4f sigma=%.4f div=%.4f (%.2fs)",
                self.generation, best_f, mean_f, self.sigma, diversity, elapsed,
            )

            return stats

    # ------------------------------------------------------------------
    # Island migration
    # ------------------------------------------------------------------

    def migrate(self) -> None:
        """Migrate top genomes between islands (ring topology).

        Top fraction of each island (per ``config.migration_fraction``)
        are copied to the next island. Uses Rust ``island_migrate`` when
        available.
        """
        with self._lock:
            n = len(self.islands)
            if n < 2:
                return

            migration_count = max(
                1,
                int(
                    len(self.islands[0])
                    * self._config.migration_fraction
                ),
            )

            if (
                _RUST_AVAILABLE
                and _island_migrate is not None
                and _IslandConfig is not None
                and _MigrationTopology is not None
            ):
                try:
                    ic = _IslandConfig(
                        n_islands=n,
                        migration_interval=self._config.migration_interval,
                        migration_count=migration_count,
                        topology=_MigrationTopology.Ring,
                    )
                    self.islands = _island_migrate(
                        self.islands,
                        self._island_fitnesses,
                        ic,
                    )
                    # Trim excess from migration to maintain population size.
                    target_size = max(
                        2, self._config.population_size // n,
                    )
                    for i in range(n):
                        if len(self.islands[i]) > target_size:
                            # Keep the first target_size (originals + migrants
                            # replacing worst). Simple truncation.
                            fit = self._island_fitnesses[i]
                            if len(fit) < len(self.islands[i]):
                                fit.extend(
                                    [0.0] * (len(self.islands[i]) - len(fit))
                                )
                            paired = sorted(
                                zip(fit, self.islands[i]),
                                key=lambda x: x[0],
                                reverse=True,
                            )
                            self.islands[i] = [p[1] for p in paired[:target_size]]
                            self._island_fitnesses[i] = [
                                p[0] for p in paired[:target_size]
                            ]
                    logger.debug(
                        "Island migration complete (Rust): %d migrants/island",
                        migration_count,
                    )
                    return
                except Exception:
                    logger.debug("Rust island_migrate failed, using fallback")

            # Pure-Python ring migration fallback.
            for i in range(n):
                island = self.islands[i]
                fit = self._island_fitnesses[i]
                if len(island) < 2:
                    continue

                # Get top-K genomes from this island.
                ranked = sorted(
                    range(len(island)),
                    key=lambda idx: fit[idx] if idx < len(fit) else 0.0,
                    reverse=True,
                )
                k = min(migration_count, len(island))
                migrants = [list(island[ranked[j]]) for j in range(k)]

                target = (i + 1) % n
                self.islands[target].extend(migrants)
                # Extend fitness list with placeholder — migrants will be
                # re-evaluated next generation.
                self._island_fitnesses[target].extend(
                    [fit[ranked[j]] for j in range(k)]
                )

            # Trim excess.
            target_size = max(2, self._config.population_size // n)
            for i in range(n):
                if len(self.islands[i]) > target_size:
                    paired = sorted(
                        zip(self._island_fitnesses[i], self.islands[i]),
                        key=lambda x: x[0],
                        reverse=True,
                    )
                    self.islands[i] = [p[1] for p in paired[:target_size]]
                    self._island_fitnesses[i] = [
                        p[0] for p in paired[:target_size]
                    ]

            logger.debug(
                "Island migration complete (Python): %d migrants/island",
                migration_count,
            )

    # ------------------------------------------------------------------
    # Top-N / Diverse-N queries
    # ------------------------------------------------------------------

    def get_best(self, n: int = 10) -> list[StrategyGenome]:
        """Return the top *n* genomes by fitness across all islands."""
        with self._lock:
            all_genomes: list[tuple[float, StrategyGenome]] = []
            for island_pop, island_fit in zip(
                self.islands, self._island_fitnesses,
            ):
                for i, vec in enumerate(island_pop):
                    genome = self._find_or_create_genome(vec)
                    f = island_fit[i] if i < len(island_fit) else genome.fitness
                    all_genomes.append((f, genome))

            all_genomes.sort(key=lambda x: x[0], reverse=True)
            return [g for _, g in all_genomes[:n]]

    def get_diverse(self, n: int = 10) -> list[StrategyGenome]:
        """Return *n* most diverse genomes using crowding distance.

        Uses Rust crowding_distance_assign when available, otherwise falls
        back to maximum-spread heuristic over the parameter space.
        """
        with self._lock:
            # Collect all genomes across islands.
            all_vecs: list[list[float]] = []
            all_genomes: list[StrategyGenome] = []
            for island_pop in self.islands:
                for vec in island_pop:
                    genome = self._find_or_create_genome(vec)
                    all_vecs.append(vec)
                    all_genomes.append(genome)

            if len(all_genomes) <= n:
                return list(all_genomes)

            # Try Rust crowding distance.
            if (
                _RUST_AVAILABLE
                and _crowding_distance_assign is not None
            ):
                try:
                    # Build objectives matrix for crowding distance.
                    objectives = [
                        [g.sharpe, -g.max_drawdown, float(g.num_trades)]
                        for g in all_genomes
                    ]
                    front_indices = list(range(len(all_genomes)))
                    front_u32 = [i for i in front_indices]
                    distances = _crowding_distance_assign(objectives, front_u32)

                    ranked = sorted(
                        range(len(all_genomes)),
                        key=lambda i: distances[i] if i < len(distances) else 0.0,
                        reverse=True,
                    )
                    return [all_genomes[i] for i in ranked[:n]]
                except Exception:
                    pass

            # Fallback: farthest-point sampling in param space.
            return self._farthest_point_sample(all_vecs, all_genomes, n)

    # ------------------------------------------------------------------
    # Injection
    # ------------------------------------------------------------------

    def inject(self, genome: StrategyGenome, island: int = 0) -> None:
        """Inject a genome into an island (seeding from templates/clones).

        The genome's hyperparams are encoded and appended to the target
        island. If the island index is out of range, it wraps around.
        """
        with self._lock:
            if not self.islands:
                return
            idx = island % len(self.islands)
            vec = self._encode_genome(genome)
            self.islands[idx].append(vec)
            self._island_fitnesses[idx].append(genome.fitness)
            self.genome_registry[genome.genome_id] = genome
            logger.debug(
                "Injected genome %s into island %d",
                genome.genome_id,
                idx,
            )

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict:
        """Return current evolution engine statistics."""
        with self._lock:
            all_fit: list[float] = []
            total_pop = 0
            for island_fit in self._island_fitnesses:
                all_fit.extend(island_fit)
                total_pop += len(island_fit)

            best_f = max(all_fit) if all_fit else 0.0
            mean_f = (sum(all_fit) / len(all_fit)) if all_fit else 0.0
            diversity = self._compute_diversity()
            convergence = self._check_convergence(best_f, diversity)

            return {
                "generation": self.generation,
                "sigma": round(self.sigma, 6),
                "diversity": round(diversity, 6),
                "best_fitness": round(best_f, 6),
                "mean_fitness": round(mean_f, 6),
                "total_population": total_pop,
                "n_islands": len(self.islands),
                "converged": convergence.get("converged", False),
                "convergence_reason": convergence.get("reason", ""),
                "gens_without_improvement": self._gens_without_improvement,
                "genome_registry_size": len(self.genome_registry),
                "best_fitness_history_len": len(self.best_fitness_history),
            }

    # ------------------------------------------------------------------
    # Pure-Python fallbacks
    # ------------------------------------------------------------------

    @staticmethod
    def _fallback_tournament_select(
        fitnesses: list[float],
        k: int,
        n: int,
        seed: int,
    ) -> list[int]:
        """Pure-Python tournament selection fallback.

        Parameters
        ----------
        fitnesses:
            Fitness values for the population.
        k:
            Tournament size.
        n:
            Number of parents to select.
        seed:
            RNG seed.
        """
        rng = random.Random(seed)
        pop_size = len(fitnesses)
        if pop_size == 0:
            return []
        k = min(k, pop_size)
        selected: list[int] = []
        for _ in range(n):
            candidates = rng.sample(range(pop_size), k)
            winner = max(candidates, key=lambda i: fitnesses[i])
            selected.append(winner)
        return selected

    @staticmethod
    def _fallback_gaussian_mutate(
        genome: list[float],
        sigma: float,
        bounds: list[tuple[float, float]],
        seed: int,
    ) -> list[float]:
        """Pure-Python Gaussian mutation fallback.

        Each gene is mutated with probability proportional to sigma.
        Noise is scaled by the parameter range.
        """
        rng = random.Random(seed)
        result = list(genome)
        mutation_rate = 0.2  # Per-gene probability
        for i in range(len(result)):
            if i < len(bounds) and rng.random() < mutation_rate:
                lo, hi = bounds[i]
                param_range = hi - lo
                noise = rng.gauss(0.0, sigma * param_range)
                result[i] = max(lo, min(hi, result[i] + noise))
        return result

    @staticmethod
    def _fallback_uniform_crossover(
        p1: list[float],
        p2: list[float],
        seed: int,
    ) -> list[float]:
        """Pure-Python uniform crossover fallback."""
        rng = random.Random(seed)
        n = min(len(p1), len(p2))
        child: list[float] = []
        for i in range(n):
            child.append(p2[i] if rng.random() < 0.5 else p1[i])
        return child

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_or_create_genome(self, vec: list[float]) -> StrategyGenome:
        """Find a genome matching this vector or create a new one.

        Performs an exact match first (fast path via registry), then
        falls back to creating a new decoded genome.
        """
        gid = self._vec_to_genome_id(vec)
        if gid is not None:
            return self.genome_registry[gid]
        genome = self._decode_genome(vec)
        self.genome_registry[genome.genome_id] = genome
        return genome

    def _build_lineage(
        self,
        island_pop: list[list[float]],
        p1_idx: int,
        p2_idx: int,
    ) -> list[str]:
        """Build lineage list from two parent indices."""
        lineage: list[str] = []
        for idx in (p1_idx, p2_idx):
            if idx < len(island_pop):
                gid = self._vec_to_genome_id(island_pop[idx])
                if gid is not None:
                    lineage.append(gid)
        return lineage

    def _adapt_sigma(self) -> None:
        """Adapt mutation sigma using Rechenberg's 1/5 success rule."""
        if self._mutation_total_count == 0:
            return

        if _RUST_AVAILABLE and _adapt_mutation_sigma is not None:
            try:
                state = _adapt_mutation_sigma(
                    self.sigma,
                    self._mutation_success_count,
                    self._mutation_total_count,
                )
                self.sigma = state.sigma
                return
            except Exception:
                pass

        # Pure-Python fallback.
        success_rate = self._mutation_success_count / self._mutation_total_count
        target = 0.2  # Rechenberg's 1/5 rule
        factor = 1.5
        if success_rate > target:
            self.sigma = min(2.0, self.sigma * factor)
        elif success_rate < target:
            self.sigma = max(0.001, self.sigma / factor)

    def _compute_diversity(self) -> float:
        """Compute population diversity across all islands."""
        all_pop: list[list[float]] = []
        for island_pop in self.islands:
            all_pop.extend(island_pop)

        if len(all_pop) < 2:
            return 0.0

        if _RUST_AVAILABLE and _population_diversity is not None:
            try:
                return _population_diversity(all_pop)
            except Exception:
                pass

        # Pure-Python fallback: mean pairwise L2 distance (sampled for speed).
        n = len(all_pop)
        dim = len(all_pop[0]) if all_pop else 1
        max_pairs = 500
        rng = random.Random(42)
        total_dist = 0.0
        count = 0
        for _ in range(min(max_pairs, n * (n - 1) // 2)):
            i = rng.randrange(n)
            j = rng.randrange(n)
            if i == j:
                continue
            dist = math.sqrt(
                sum(
                    (all_pop[i][k] - all_pop[j][k]) ** 2
                    for k in range(min(dim, len(all_pop[i]), len(all_pop[j])))
                )
            ) / dim
            total_dist += dist
            count += 1

        return total_dist / count if count > 0 else 0.0

    def _check_convergence(
        self, best_fitness: float, diversity: float,
    ) -> dict:
        """Check convergence via Rust or pure-Python fallback."""
        if _RUST_AVAILABLE and _check_convergence is not None:
            try:
                state = _check_convergence(
                    best_fitness,
                    diversity,
                    self._prev_best_fitness,
                    self._gens_without_improvement,
                    patience=20,
                    min_improvement=1e-4,
                    diversity_threshold=0.01,
                )
                return {
                    "converged": state.converged,
                    "reason": state.reason,
                    "gens_without_improvement": int(
                        state.generations_without_improvement
                    ),
                    "best_fitness": state.best_fitness,
                }
            except Exception:
                pass

        # Pure-Python fallback.
        converged = False
        reason = ""
        if self._gens_without_improvement >= 20:
            converged = True
            reason = (
                f"No improvement for {self._gens_without_improvement} "
                f"generations (patience=20)"
            )
        elif 0.0 <= diversity < 0.01:
            converged = True
            reason = f"Diversity collapsed to {diversity:.6f} (threshold=0.01)"

        return {
            "converged": converged,
            "reason": reason,
            "gens_without_improvement": self._gens_without_improvement,
            "best_fitness": best_fitness,
        }

    def _farthest_point_sample(
        self,
        all_vecs: list[list[float]],
        all_genomes: list[StrategyGenome],
        n: int,
    ) -> list[StrategyGenome]:
        """Select *n* diverse genomes via farthest-point sampling.

        Greedy algorithm: start with the best genome, then iteratively
        pick the genome farthest from all already-selected genomes.
        """
        if not all_genomes:
            return []

        # Start with highest-fitness genome.
        best_idx = max(
            range(len(all_genomes)),
            key=lambda i: all_genomes[i].fitness,
        )
        selected_indices = [best_idx]
        remaining = set(range(len(all_genomes))) - {best_idx}

        while len(selected_indices) < n and remaining:
            best_dist = -1.0
            best_candidate = -1
            for cand in remaining:
                min_dist = float("inf")
                for sel_idx in selected_indices:
                    d = self._l2_distance(all_vecs[cand], all_vecs[sel_idx])
                    if d < min_dist:
                        min_dist = d
                if min_dist > best_dist:
                    best_dist = min_dist
                    best_candidate = cand
            if best_candidate < 0:
                break
            selected_indices.append(best_candidate)
            remaining.discard(best_candidate)

        return [all_genomes[i] for i in selected_indices]

    @staticmethod
    def _l2_distance(a: list[float], b: list[float]) -> float:
        """L2 distance between two vectors."""
        n = min(len(a), len(b))
        return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(n)))

    def _prune_registry(self) -> None:
        """Remove old genome entries to bound memory.

        Keeps at most 5x the total population size. Evicts lowest-fitness
        genomes not currently in any island.
        """
        max_size = max(100, self._config.population_size * 5)
        if len(self.genome_registry) <= max_size:
            return

        # Collect genome IDs currently in islands.
        active_ids: set[str] = set()
        for island_pop in self.islands:
            for vec in island_pop:
                gid = self._vec_to_genome_id(vec)
                if gid is not None:
                    active_ids.add(gid)

        # Evict lowest-fitness non-active genomes.
        candidates = [
            (gid, g.fitness)
            for gid, g in self.genome_registry.items()
            if gid not in active_ids
        ]
        candidates.sort(key=lambda x: x[1])

        n_to_remove = len(self.genome_registry) - max_size
        for gid, _ in candidates[:n_to_remove]:
            del self.genome_registry[gid]
            self._fitness_cache.pop(gid, None)
