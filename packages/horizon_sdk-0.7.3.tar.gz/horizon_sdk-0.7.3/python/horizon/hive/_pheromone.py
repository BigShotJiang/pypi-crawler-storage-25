"""Stigmergic coordination substrate for the Hive swarm.

Pheromone fields are the primary indirect communication mechanism between
agents.  Instead of point-to-point messaging, agents *deposit* chemical-like
signals on markets they operate in.  Other agents *sense* those signals and
adapt their behaviour accordingly.

Nine channels encode different market semantics (bullish/bearish sentiment,
crowding pressure, opportunity, toxicity, etc.).  Signals evaporate
exponentially, diffuse to correlated markets, and saturate at per-channel
ceilings so no single agent can dominate the field.

Thread-safe: every public method acquires a single reentrant lock so the
field can be read from dashboard / API threads while the tick loop mutates it.
"""

from __future__ import annotations

import math
import threading
from dataclasses import dataclass, fields

from horizon.hive._types import (
    CHANNEL_DEFAULTS,
    ChannelConfig,
    HiveConfig,
    MarketPheromones,
    PheromoneChannel,
)


class PheromoneField:
    """Stigmergic coordination substrate for the swarm.

    9 channels per market.  Agents deposit pheromone proportional to their
    fitness (proven agents have stronger signals).  Pheromone evaporates
    exponentially.  Diffusion uses cross-impact weights from KnowledgeGraph
    relationships.
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, config: HiveConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        # Primary data store: market_id -> per-market pheromones.
        self._field: dict[str, MarketPheromones] = {}
        # Channel configs (immutable after init).
        self._channel_cfg: dict[PheromoneChannel, ChannelConfig] = dict(
            CHANNEL_DEFAULTS
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_market(self, market_id: str) -> MarketPheromones:
        """Return (or lazily create) pheromones for *market_id*.

        Caller must hold ``_lock``.
        """
        mp = self._field.get(market_id)
        if mp is None:
            mp = MarketPheromones()
            self._field[market_id] = mp
        return mp

    @staticmethod
    def _clamp(value: float, lo: float, hi: float) -> float:
        if value < lo:
            return lo
        if value > hi:
            return hi
        return value

    # ------------------------------------------------------------------
    # Deposit
    # ------------------------------------------------------------------

    def deposit(
        self,
        market_id: str,
        channel: PheromoneChannel,
        amount: float,
        agent_fitness: float,
        avg_fitness: float = 1.0,
    ) -> None:
        """Deposit pheromone on *channel* for *market_id*.

        The effective deposit is::

            effective = amount * cfg.deposit_weight * (agent_fitness / avg_fitness)

        Fitter agents leave stronger trails.  The result is clamped to
        ``[0, cfg.saturation]``.

        Parameters
        ----------
        market_id:
            Target market.
        channel:
            Which of the 9 channels to deposit on.
        amount:
            Raw deposit amount (non-negative).
        agent_fitness:
            Depositing agent's current fitness score.
        avg_fitness:
            Swarm-wide average fitness (avoids division-by-zero; defaults to 1).
        """
        if amount <= 0.0:
            return
        cfg = self._channel_cfg[channel]
        # Guard against degenerate avg_fitness.
        safe_avg = max(avg_fitness, 1e-12)
        fitness_weight = max(agent_fitness / safe_avg, 0.0)
        effective = amount * cfg.deposit_weight * fitness_weight

        with self._lock:
            mp = self._ensure_market(market_id)
            current = mp.get(channel)
            new_val = self._clamp(current + effective, 0.0, cfg.saturation)
            mp.set(channel, new_val)

    # ------------------------------------------------------------------
    # Evaporation
    # ------------------------------------------------------------------

    def evaporate(self, dt: float) -> None:
        """Apply exponential decay to every channel on every market.

        ``value_new = value * exp(-rate * dt)``

        Parameters
        ----------
        dt:
            Elapsed time in seconds since last evaporation step.
        """
        if dt <= 0.0:
            return

        # Pre-compute per-channel decay factors once.
        decay_factors: dict[PheromoneChannel, float] = {}
        for ch, cfg in self._channel_cfg.items():
            decay_factors[ch] = math.exp(-cfg.evaporation_rate * dt)

        with self._lock:
            for mp in self._field.values():
                for ch, factor in decay_factors.items():
                    current = mp.get(ch)
                    if current > 0.0:
                        new_val = current * factor
                        # Snap negligible values to zero to avoid float dust.
                        mp.set(ch, new_val if new_val > 1e-12 else 0.0)

    # ------------------------------------------------------------------
    # Diffusion
    # ------------------------------------------------------------------

    def diffuse(
        self,
        neighbors: dict[str, list[tuple[str, float]]],
    ) -> None:
        """Spread pheromone to related markets.

        For each market with known neighbors, channels whose
        ``diffusion_radius > 0`` contribute a fraction of their value to
        each neighbor::

            contribution = value * 0.3 * relationship_weight

        Diffusion is additive and clamped to saturation.

        Parameters
        ----------
        neighbors:
            ``{market_id: [(neighbor_id, weight), ...]}`` where *weight*
            is a relationship strength in ``[0, 1]``.
        """
        if not neighbors:
            return

        diffusion_base = 0.3

        # Identify channels that actually diffuse.
        diffusing_channels: list[PheromoneChannel] = [
            ch
            for ch, cfg in self._channel_cfg.items()
            if cfg.diffusion_radius > 0
        ]
        if not diffusing_channels:
            return

        with self._lock:
            # Collect contributions in a separate buffer so reads are
            # consistent (no order-dependent contamination within one step).
            contributions: dict[str, dict[PheromoneChannel, float]] = {}

            for src_id, nbrs in neighbors.items():
                src = self._field.get(src_id)
                if src is None:
                    continue
                for ch in diffusing_channels:
                    val = src.get(ch)
                    if val <= 0.0:
                        continue
                    for nbr_id, weight in nbrs:
                        amount = val * diffusion_base * weight
                        if amount <= 0.0:
                            continue
                        if nbr_id not in contributions:
                            contributions[nbr_id] = {}
                        bucket = contributions[nbr_id]
                        bucket[ch] = bucket.get(ch, 0.0) + amount

            # Apply contributions.
            for mkt_id, ch_amounts in contributions.items():
                mp = self._ensure_market(mkt_id)
                for ch, added in ch_amounts.items():
                    cfg = self._channel_cfg[ch]
                    current = mp.get(ch)
                    mp.set(ch, self._clamp(current + added, 0.0, cfg.saturation))

    # ------------------------------------------------------------------
    # Crowding
    # ------------------------------------------------------------------

    def update_crowding(
        self,
        agent_markets: dict[str, list[str]],
        max_per_market: int,
    ) -> None:
        """Auto-compute crowding pheromone from active agent assignments.

        Crowding is set (not deposited additively) to::

            crowding = (n_agents / max_per_market) * saturation

        clamped to ``[0, saturation]``.

        Parameters
        ----------
        agent_markets:
            ``{agent_id: [market_id, ...]}`` for every active agent.
        max_per_market:
            Maximum desired agents per market.
        """
        if max_per_market <= 0:
            return

        # Count agents per market.
        counts: dict[str, int] = {}
        for markets in agent_markets.values():
            for mkt_id in markets:
                counts[mkt_id] = counts.get(mkt_id, 0) + 1

        cfg = self._channel_cfg[PheromoneChannel.CROWDING]

        with self._lock:
            # Reset crowding for all tracked markets first (agents may have
            # departed since the last tick).
            for mp in self._field.values():
                mp.set(PheromoneChannel.CROWDING, 0.0)
            # Set crowding for active markets.
            for mkt_id, n in counts.items():
                mp = self._ensure_market(mkt_id)
                ratio = n / max_per_market
                mp.set(
                    PheromoneChannel.CROWDING,
                    self._clamp(ratio * cfg.saturation, 0.0, cfg.saturation),
                )

    # ------------------------------------------------------------------
    # Sense
    # ------------------------------------------------------------------

    def sense(self, market_id: str) -> MarketPheromones:
        """Read all 9 channels for *market_id*.

        Returns a *copy* so the caller can inspect values without holding
        the lock.  If the market has no recorded pheromones, a zero-valued
        ``MarketPheromones`` is returned (the market is **not** registered
        in the field).
        """
        with self._lock:
            mp = self._field.get(market_id)
            if mp is None:
                return MarketPheromones()
            # Shallow copy via dataclass field iteration.
            copy = MarketPheromones()
            for ch in PheromoneChannel:
                copy.set(ch, mp.get(ch))
            return copy

    # ------------------------------------------------------------------
    # Tick (full pheromone cycle)
    # ------------------------------------------------------------------

    def tick(
        self,
        dt: float,
        neighbors: dict[str, list[tuple[str, float]]],
        agent_markets: dict[str, list[str]],
        max_per_market: int,
    ) -> None:
        """One complete pheromone update cycle.

        Order: evaporate -> diffuse -> update_crowding.

        Parameters
        ----------
        dt:
            Elapsed seconds since last tick.
        neighbors:
            Cross-market relationship graph.
        agent_markets:
            Agent-to-market assignments.
        max_per_market:
            Crowding normalisation denominator.
        """
        self.evaporate(dt)
        self.diffuse(neighbors)
        self.update_crowding(agent_markets, max_per_market)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def snapshot(self) -> dict[str, dict[str, float]]:
        """Serialise the entire pheromone field.

        Returns ``{market_id: {channel_name: value, ...}, ...}``.
        """
        with self._lock:
            return {
                mkt_id: mp.as_dict()
                for mkt_id, mp in self._field.items()
            }

    def restore(self, data: dict[str, dict[str, float]]) -> None:
        """Restore the field from a previous :meth:`snapshot`.

        Existing data is replaced wholesale.
        """
        with self._lock:
            self._field.clear()
            for mkt_id, ch_dict in data.items():
                mp = MarketPheromones()
                for ch_name, value in ch_dict.items():
                    try:
                        ch = PheromoneChannel(ch_name)
                    except ValueError:
                        continue  # Ignore unknown channels (forward compat).
                    cfg = self._channel_cfg[ch]
                    mp.set(ch, self._clamp(value, 0.0, cfg.saturation))
                self._field[mkt_id] = mp

    # ------------------------------------------------------------------
    # Aggregate queries
    # ------------------------------------------------------------------

    def aggregate_opportunity(self) -> float:
        """Average opportunity pheromone across all tracked markets."""
        with self._lock:
            if not self._field:
                return 0.0
            total = sum(
                mp.get(PheromoneChannel.OPPORTUNITY)
                for mp in self._field.values()
            )
            return total / len(self._field)

    def aggregate_toxicity(self) -> float:
        """Average toxicity pheromone across all tracked markets."""
        with self._lock:
            if not self._field:
                return 0.0
            total = sum(
                mp.get(PheromoneChannel.TOXICITY)
                for mp in self._field.values()
            )
            return total / len(self._field)

    def crowded_markets(self, threshold: float = 0.6) -> list[str]:
        """Return market IDs where crowding exceeds *threshold* fraction of saturation."""
        cfg = self._channel_cfg[PheromoneChannel.CROWDING]
        cutoff = threshold * cfg.saturation
        with self._lock:
            return [
                mkt_id
                for mkt_id, mp in self._field.items()
                if mp.get(PheromoneChannel.CROWDING) > cutoff
            ]

    def opportunity_markets(self, threshold: float = 0.5) -> list[str]:
        """Return market IDs where opportunity exceeds *threshold* fraction of saturation."""
        cfg = self._channel_cfg[PheromoneChannel.OPPORTUNITY]
        cutoff = threshold * cfg.saturation
        with self._lock:
            return [
                mkt_id
                for mkt_id, mp in self._field.items()
                if mp.get(PheromoneChannel.OPPORTUNITY) > cutoff
            ]

    # ------------------------------------------------------------------
    # Reset
    # ------------------------------------------------------------------

    def clear(self) -> None:
        """Reset the entire pheromone field to empty."""
        with self._lock:
            self._field.clear()
