"""Hive Server — WebSocket + REST API for remote Hive connections.

The Hive runs as a service on our servers. Users connect via WebSocket
for real-time events and REST for commands. Simple, proprietary, fast.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import threading
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from horizon.hive import HiveController

logger = logging.getLogger("horizon.hive.server")


class HiveServer:
    """WebSocket server for remote Hive control.

    Protocol:
    - Client connects with auth token
    - Receives real-time events (agent lifecycle, trades, regime, etc.)
    - Sends commands (spawn, kill, scale, mode, etc.)
    - Request-response for status queries

    Message format:
    {
        "type": "command" | "query" | "event" | "response",
        "action": "spawn" | "kill" | "status" | ...,
        "data": {...},
        "request_id": "optional-for-req-res",
        "token": "auth-token"
    }
    """

    def __init__(self, host: str = "0.0.0.0", port: int = 8780,
                 auth_token: str | None = None):
        self._host = host
        self._port = port
        self._auth_token = auth_token
        self._controller: HiveController | None = None
        self._clients: set[Any] = set()
        self._lock = threading.Lock()
        self._running = False
        self._server_task: asyncio.Task | None = None

    def bind(self, controller: "HiveController") -> None:
        """Bind to a HiveController for command dispatch."""
        self._controller = controller

    # -----------------------------------------------------------------------
    # Server Lifecycle
    # -----------------------------------------------------------------------

    async def start(self) -> None:
        """Start the WebSocket server."""
        try:
            import websockets
            import websockets.server
        except ImportError:
            logger.warning("websockets not installed — server disabled. "
                           "pip install websockets")
            return

        self._running = True

        async def handler(websocket: Any) -> None:
            await self._handle_client(websocket)

        try:
            server = await websockets.serve(  # type: ignore
                handler, self._host, self._port,
            )
            logger.info("Hive server listening on ws://%s:%d", self._host, self._port)
            await server.wait_closed()
        except Exception as e:
            logger.error("Hive server error: %s", e)
        finally:
            self._running = False

    async def stop(self) -> None:
        """Stop the server."""
        self._running = False
        # Close all client connections
        with self._lock:
            clients = list(self._clients)
        for ws in clients:
            try:
                await ws.close()
            except Exception:
                pass

    # -----------------------------------------------------------------------
    # Client Handling
    # -----------------------------------------------------------------------

    async def _handle_client(self, websocket: Any) -> None:
        """Handle a single client connection."""
        # Auth check on first message
        authed = self._auth_token is None  # No token = open

        with self._lock:
            self._clients.add(websocket)

        try:
            async for raw in websocket:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    await websocket.send(json.dumps({
                        "type": "error", "data": {"message": "invalid JSON"},
                    }))
                    continue

                # Auth
                if not authed:
                    token = msg.get("token", "")
                    if token == self._auth_token:
                        authed = True
                        await websocket.send(json.dumps({
                            "type": "response", "action": "auth",
                            "data": {"authenticated": True},
                        }))
                        continue
                    else:
                        await websocket.send(json.dumps({
                            "type": "error", "data": {"message": "unauthorized"},
                        }))
                        continue

                # Dispatch
                response = await self._dispatch(msg)
                await websocket.send(json.dumps(response))

        except Exception as e:
            logger.debug("Client disconnected: %s", e)
        finally:
            with self._lock:
                self._clients.discard(websocket)

    async def _dispatch(self, msg: dict[str, Any]) -> dict[str, Any]:
        """Dispatch a client message to the appropriate handler."""
        msg_type = msg.get("type", "")
        action = msg.get("action", "")
        data = msg.get("data", {})
        request_id = msg.get("request_id", "")

        if self._controller is None:
            return {"type": "error", "data": {"message": "controller not bound"},
                    "request_id": request_id}

        try:
            if msg_type == "query":
                result = self._handle_query(action, data)
            elif msg_type == "command":
                result = self._handle_command(action, data)
            else:
                result = {"error": f"unknown message type: {msg_type}"}
        except Exception as e:
            logger.error("Dispatch error: %s", e)
            result = {"error": str(e)}

        return {"type": "response", "action": action,
                "data": result, "request_id": request_id}

    def _handle_query(self, action: str, data: dict) -> dict[str, Any]:
        """Handle status/query requests."""
        ctrl = self._controller
        if ctrl is None:
            return {"error": "not initialized"}

        if action == "status":
            return ctrl.status()
        elif action == "agents":
            return {"agents": ctrl.coordinator.agent_ranking()}
        elif action == "agent":
            agent_id = data.get("agent_id", "")
            agent = ctrl.coordinator.get_agent(agent_id)
            return agent.to_dict() if agent else {"error": "not found"}
        elif action == "pheromone":
            market_id = data.get("market_id")
            if market_id and ctrl.pheromone:
                return ctrl.pheromone.sense(market_id).as_dict()
            elif ctrl.pheromone:
                return ctrl.pheromone.snapshot()
            return {}
        elif action == "mode":
            return {"mode": ctrl.autonomy.mode.value if ctrl.autonomy else "unknown"}
        elif action == "pending":
            if ctrl.autonomy:
                return {"pending": [d.to_dict() for d in ctrl.autonomy.pending()]}
            return {"pending": []}
        elif action == "criticality":
            return {"warnings": ctrl.last_criticality.warning_count()
                    if ctrl.last_criticality else 0}
        elif action == "evolution":
            if ctrl.evolution:
                return ctrl.evolution.stats()
            return {}
        elif action == "imprint":
            if ctrl.imprint:
                return ctrl.imprint.status()
            return {}
        elif action == "reputation":
            if ctrl.reputation:
                return {"ranking": ctrl.reputation.ranking()}
            return {}
        elif action == "consensus":
            if ctrl.consensus:
                return {"active_markets": [
                    {"id": m.market_id, "question": m.question,
                     "consensus": m.consensus_probability}
                    for m in ctrl.consensus.active_markets()
                ]}
            return {}
        elif action == "incidents":
            if ctrl.kill_chain:
                return ctrl.kill_chain.status()
            return {}
        elif action == "dream":
            if ctrl.dream:
                return ctrl.dream.status()
            return {}
        else:
            return {"error": f"unknown query: {action}"}

    def _handle_command(self, action: str, data: dict) -> dict[str, Any]:
        """Handle mutation/command requests."""
        ctrl = self._controller
        if ctrl is None:
            return {"error": "not initialized"}

        if action == "spawn":
            template = data.get("template", "momentum")
            markets = data.get("markets", [])
            capital = data.get("capital", 0.0)
            agent = ctrl.spawn_agent(template=template, markets=markets,
                                     capital=capital)
            return agent.to_dict() if agent else {"error": "spawn failed"}

        elif action == "kill":
            agent_id = data.get("agent_id", "")
            reason = data.get("reason", "user_command")
            ok = ctrl.coordinator.kill_agent(agent_id, reason)
            return {"killed": ok, "agent_id": agent_id}

        elif action == "pause":
            agent_id = data.get("agent_id", "")
            ok = ctrl.coordinator.pause_agent(agent_id, "user_command")
            return {"paused": ok}

        elif action == "resume":
            agent_id = data.get("agent_id", "")
            ok = ctrl.coordinator.resume_agent(agent_id)
            return {"resumed": ok}

        elif action == "scale":
            agent_id = data.get("agent_id", "")
            capital = data.get("capital", 0.0)
            ok = ctrl.coordinator.scale_agent(agent_id, capital)
            return {"scaled": ok}

        elif action == "set_mode":
            mode_str = data.get("mode", "observe")
            try:
                from horizon.hive._types import AutonomyMode
                mode = AutonomyMode(mode_str)
                if ctrl.autonomy:
                    ctrl.autonomy.set_mode(mode)
                return {"mode": mode.value}
            except ValueError:
                return {"error": f"invalid mode: {mode_str}"}

        elif action == "approve":
            decision_id = data.get("decision_id", "")
            if ctrl.autonomy:
                d = ctrl.autonomy.approve(decision_id)
                return {"approved": d is not None}
            return {"error": "autonomy controller not available"}

        elif action == "reject":
            decision_id = data.get("decision_id", "")
            reason = data.get("reason", "")
            if ctrl.autonomy:
                d = ctrl.autonomy.reject(decision_id, reason)
                return {"rejected": d is not None}
            return {"error": "autonomy controller not available"}

        elif action == "kill_switch":
            ctrl.kill_switch()
            return {"halted": True}

        elif action == "dream":
            if ctrl.dream:
                gens = data.get("generations", None)
                ctrl.dream.dream_async(generations=gens)
                return {"dreaming": True}
            return {"error": "dream state not available"}

        elif action == "evolve":
            if ctrl.evolution:
                stats = ctrl.run_evolution_cycle()
                return stats
            return {"error": "evolution engine not available"}

        else:
            return {"error": f"unknown command: {action}"}

    # -----------------------------------------------------------------------
    # Event Broadcasting
    # -----------------------------------------------------------------------

    async def broadcast(self, event_type: str, data: dict[str, Any]) -> None:
        """Broadcast an event to all connected clients."""
        msg = json.dumps({
            "type": "event",
            "event": event_type,
            "data": data,
            "timestamp": time.time(),
        })
        with self._lock:
            clients = list(self._clients)
        for ws in clients:
            try:
                await ws.send(msg)
            except Exception:
                with self._lock:
                    self._clients.discard(ws)

    def broadcast_sync(self, event_type: str, data: dict[str, Any]) -> None:
        """Broadcast from a synchronous context."""
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.broadcast(event_type, data))
        except RuntimeError:
            pass  # No event loop — skip

    # -----------------------------------------------------------------------
    # Status
    # -----------------------------------------------------------------------

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def client_count(self) -> int:
        return len(self._clients)

    def status(self) -> dict[str, Any]:
        return {
            "running": self._running,
            "host": self._host,
            "port": self._port,
            "clients": self.client_count,
            "auth_required": self._auth_token is not None,
        }
