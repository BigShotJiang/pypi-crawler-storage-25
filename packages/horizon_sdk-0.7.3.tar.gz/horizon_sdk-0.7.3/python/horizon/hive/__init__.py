"""The Hive — Autonomous Swarm Intelligence for Horizon SDK.

Proprietary server-side system. Users connect via WebSocket.
Transforms independent trading strategies into a self-organizing
complex adaptive system that evolves, learns, and self-improves.

Usage (server-side):
    from horizon.hive import HiveController, HiveConfig

    config = HiveConfig(
        total_capital=100_000,
        max_agents=50,
        host="0.0.0.0",
        port=8780,
        auth_token="your-secret-token",
    )
    hive = HiveController(config)
    hive.start()     # Non-blocking: starts server + oversight loop
    hive.run()       # Blocking: runs until interrupted

Usage (client-side — connect to remote Hive):
    from horizon.hive import HiveClient

    client = HiveClient("ws://hive-server:8780", token="your-secret-token")
    client.connect()
    print(client.status())
    client.spawn(template="momentum", markets=["BTC-USD"])
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import Any

# Rust-compiled types (proprietary, opaque binary — IP protected)
from horizon._horizon import (
    AutonomyMode, AgentLifecycle, SpawnSource, PheromoneChannel,
    Severity, StrategyArchetype, DecisionType, HiveEventType,
    ChannelConfig, MarketPheromones, StrategyGenome, HiveAgent,
    CriticalityReport, ConsensusView, InternalMarket, ImprintAction,
    Incident, SwarmStatus, ExecutionSlice, ExecutionPlan,
    CausalEdge, CausalGraph,
)
# Rust-compiled subsystem engines (proprietary algorithms)
from horizon._horizon import (
    PheromoneField, ReputationSystem, ConsensusEngine,
    CriticalityMonitor, SelfImpactModel, ImprintSystem,
    CausalEngine, MAPElitesArchive, MetamorphicExecutor,
    AutonomyController, KillChain, AgentFactory, SwarmCoordinator,
)
# Python-only types
from horizon.hive._types import HiveConfig, HiveDecision, DecayForecast
# Python-only subsystems (DB, server, evolution wrappers)
from horizon.hive._db import HiveDB
from horizon.hive._evolution import EvolutionEngine
from horizon.hive._pbt import PopulationBasedTrainer
from horizon.hive._dream import DreamState
from horizon.hive._server import HiveServer

logger = logging.getLogger("horizon.hive")

__all__ = [
    # Core
    "HiveController",
    "HiveConfig",
    "HiveClient",
    # Types
    "AutonomyMode", "AgentLifecycle", "CriticalityReport", "DecisionType",
    "HiveAgent", "HiveDecision", "HiveEventType", "ImprintAction",
    "Incident", "InternalMarket", "MarketPheromones", "PheromoneChannel",
    "Severity", "SpawnSource", "StrategyArchetype", "StrategyGenome",
    "SwarmStatus",
    # Modules
    "HiveDB", "PheromoneField", "ReputationSystem", "AutonomyController",
    "EvolutionEngine", "MAPElitesArchive", "PopulationBasedTrainer",
    "ConsensusEngine", "CriticalityMonitor", "ImprintSystem",
    "SelfImpactModel", "MetamorphicExecutor", "CausalEngine",
    "DreamState", "KillChain", "AgentFactory", "SwarmCoordinator",
    "HiveServer",
]


class HiveController:
    """The Hive — Central intelligence orchestrating everything.

    Wires together all 17 subsystems:
    - SwarmCoordinator: fleet management + selection pressure
    - PheromoneField: stigmergic coordination (9 channels)
    - EvolutionEngine: Darwinian strategy genesis (wraps Rust NSGA-II)
    - MAPElitesArchive: quality-diversity (300-cell behavioral grid)
    - PopulationBasedTrainer: live hyperparameter evolution
    - ConsensusEngine: 4-layer collective intelligence
    - CriticalityMonitor: 15-indicator market criticality
    - ImprintSystem: user behavior learning (BC + IRL + DAgger)
    - ReputationSystem: Bayesian agent trust tracking
    - SelfImpactModel: calibrated impact + internal crossing
    - MetamorphicExecutor: anti-fingerprint execution
    - CausalEngine: Granger/TE/lead-lag causal discovery
    - DreamState: accelerated offline evolution
    - KillChain: automated incident response
    - AutonomyController: 5-mode progressive autonomy
    - AgentFactory: 6-source agent creation
    - HiveServer: WebSocket API for remote connections
    """

    def __init__(self, config: HiveConfig | None = None):
        self._config = config or HiveConfig()
        self._lock = threading.Lock()
        self._running = False
        self._oversight_thread: threading.Thread | None = None

        # --- Initialize all subsystems ---
        # Python-only: DB, server, evolution wrappers
        self.db = HiveDB(db_path=self._config.db_path)
        self.evolution = EvolutionEngine(self._config, db=self.db)
        self.pbt = PopulationBasedTrainer(self._config)

        # Rust-compiled subsystems (proprietary algorithms, opaque binary)
        self.pheromone = PheromoneField()
        self.reputation = ReputationSystem()
        self.autonomy = AutonomyController(initial_mode=self._config.initial_mode)
        self.archive = MAPElitesArchive()
        self.consensus = ConsensusEngine()
        self.criticality = CriticalityMonitor()
        self.imprint = ImprintSystem()
        self.impact = SelfImpactModel(
            impact_gate_margin=self._config.impact_gate_margin,
            internal_crossing=self._config.internal_crossing_enabled,
        )
        self.metamorphic = MetamorphicExecutor()
        self.causal = CausalEngine()
        self.kill_chain = KillChain()
        self.factory = AgentFactory()
        self.coordinator = SwarmCoordinator(
            total_capital=self._config.total_capital,
        )

        # Python-only: Dream state, WebSocket server
        self.dream = DreamState(
            self._config, evolution=self.evolution,
            archive=self.archive, db=self.db,
        )
        self.server = HiveServer(
            host=self._config.host,
            port=self._config.port,
            auth_token=self._config.auth_token,
        )
        self.server.bind(self)

        # Wire kill chain callbacks to coordinator operations
        self._wire_kill_chain()

        # State
        self.last_criticality: CriticalityReport | None = None
        self._generation = 0
        self._last_pbt_time = 0.0
        self._last_criticality_time = 0.0
        self._last_imprint_train = 0.0

        logger.info("Hive initialized: %d max agents, $%,.0f capital, mode=%s",
                     self._config.max_agents, self._config.total_capital,
                     str(self._config.initial_mode))

    @property
    def _autonomy_mode(self) -> str:
        """Get current autonomy mode string from Rust controller."""
        return self.autonomy.status().get("mode", "observe")

    def _wire_kill_chain(self) -> None:
        """Connect kill chain phases to actual coordinator operations."""
        def _contain(incident):
            for aid in incident.affected_agents:
                self.coordinator.pause_agent(aid, f"incident:{incident.incident_id}")

        def _preserve(incident):
            return {
                "swarm": self.coordinator.swarm_status().__dict__,
                "pheromone": self.pheromone.snapshot() if self.pheromone else {},
                "agents": {a.agent_id: a.to_dict() for a in self.coordinator.all_agents()},
            }

        def _diagnose(incident):
            # Basic automated diagnosis based on trigger
            trigger = incident.trigger.lower()
            if "drawdown" in trigger:
                return "excessive_drawdown"
            elif "kill_switch" in trigger:
                return "manual_halt"
            elif "correlation" in trigger:
                return "correlation_spike"
            return f"trigger:{incident.trigger}"

        def _remediate(incident):
            for aid in incident.affected_agents:
                agent = self.coordinator.get_agent(aid)
                if agent and agent.genome:
                    self.kill_chain.blacklist_genome(agent.genome.genome_id)
                self.coordinator.kill_agent(aid, f"remediated:{incident.incident_id}")

        def _learn(incident):
            # Record failure for future evolutionary fitness penalty
            if self.evolution and hasattr(self.evolution, 'record_failure'):
                self.evolution.record_failure(incident.trigger)
            logger.info("Kill chain learn: incident %s recorded", incident.incident_id)

        self.kill_chain.on_contain(_contain)
        self.kill_chain.on_preserve(_preserve)
        self.kill_chain.on_diagnose(_diagnose)
        self.kill_chain.on_remediate(_remediate)
        self.kill_chain.on_learn(_learn)

    # -----------------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------------

    def start(self) -> None:
        """Start the Hive (non-blocking). Starts oversight loop + server."""
        self._running = True

        # Start oversight loop in background thread
        self._oversight_thread = threading.Thread(
            target=self._oversight_loop,
            daemon=True,
            name="hive-oversight",
        )
        self._oversight_thread.start()

        logger.info("Hive started. Oversight loop running.")

    def run(self) -> None:
        """Run the Hive (blocking). Starts server + oversight loop."""
        self.start()

        # Run WebSocket server in main thread's event loop
        try:
            asyncio.run(self.server.start())
        except KeyboardInterrupt:
            logger.info("Hive shutting down...")
        finally:
            self.stop()

    def stop(self) -> None:
        """Stop the Hive."""
        self._running = False
        if self._oversight_thread is not None:
            self._oversight_thread.join(timeout=5.0)
        self.db.close()
        logger.info("Hive stopped.")

    # -----------------------------------------------------------------------
    # Oversight Loop
    # -----------------------------------------------------------------------

    def _oversight_loop(self) -> None:
        """Main oversight loop — runs in background thread.

        Cycle:
        1. Coordinator tick (metrics, pheromone, selection, promotion, rebalance)
        2. Criticality check (periodic)
        3. PBT evolution (periodic)
        4. Imprint training (periodic)
        5. Autonomy graduation check
        6. Consensus market expiration
        """
        while self._running:
            try:
                cycle_start = time.monotonic()

                # 1. Coordinator tick
                tick_result = self.coordinator.tick()

                # 2. Criticality check
                now = time.time()
                if now - self._last_criticality_time >= self._config.criticality_check_interval:
                    self._check_criticality()
                    self._last_criticality_time = now

                # 3. PBT evolution
                if self.pbt.should_run(self._last_pbt_time):
                    agents = self.coordinator.active_agents()
                    if len(agents) >= 3:
                        mutations = self.pbt.evaluate_and_evolve(agents)
                        for m in mutations:
                            logger.debug("PBT mutated %s", m.get("agent_id"))
                        self._last_pbt_time = now

                # 4. Imprint training
                if (self._config.imprint_enabled and
                        self.imprint.status().get("actions_observed", 0) >= self._config.imprint_min_actions):
                    self.imprint.train()

                # 5. Autonomy graduation check (daily)
                swarm_st = self.coordinator.swarm_status()
                imprint_obs = self.imprint.status().get("actions_observed", 0)
                graduation = self.autonomy.evaluate_graduation(
                    imprint_obs, swarm_st.aggregate_sharpe, 0.0, 0, 0,
                )
                if graduation is not None:
                    self.autonomy.set_mode(graduation)

                # 6. Consensus market expiration
                self.consensus.expire_markets()

                # 7. Self-impact flush
                self.impact.flush_stale()

                # Sleep until next cycle
                elapsed = time.monotonic() - cycle_start
                sleep_time = max(0.1, self._config.pheromone_tick_interval - elapsed)
                time.sleep(sleep_time)

            except Exception as e:
                logger.error("Oversight loop error: %s", e, exc_info=True)
                time.sleep(1.0)

    def _check_criticality(self) -> None:
        """Run criticality assessment and respond."""
        # Gather available data
        price_series: dict[str, list[float]] = {}
        for agent in self.coordinator.active_agents():
            for market_id in agent.markets:
                if market_id not in price_series:
                    price_series[market_id] = []

        volume_series: dict[str, list[float]] = {}
        feed_spreads: dict[str, float] = {}
        report = self.criticality.compute_report(price_series, volume_series, feed_spreads)
        self.last_criticality = report

        if report.warning_count() >= 5:
            logger.warning("CRITICALITY WARNING: %d/15 indicators triggered",
                           report.warning_count())

            # Deploy avalanche reserves if drawdown threshold reached
            status = self.coordinator.swarm_status()
            deploy = self.criticality.avalanche_check(status.aggregate_drawdown)
            if deploy > 0:
                self.coordinator.deploy_reserves(deploy)

    # -----------------------------------------------------------------------
    # Agent Operations
    # -----------------------------------------------------------------------

    def spawn_agent(self, template: str = "momentum",
                    markets: list[str] | None = None,
                    capital: float = 0.0,
                    genome: StrategyGenome | None = None) -> HiveAgent | None:
        """Spawn a new agent. Returns the agent or None if at capacity."""
        if not self.coordinator.can_spawn:
            logger.warning("Cannot spawn: at max agents (%d)", self._config.max_agents)
            return None

        # Check autonomy permission
        allowed, reason = self.autonomy.check_permission(DecisionType.SpawnAgent, 0.0)
        if not allowed and self._autonomy_mode not in ("observe", "suggest"):
            # In SUPERVISED mode, queue for approval
            decision = HiveDecision(
                decision_type=DecisionType.SpawnAgent,
                action_taken=f"Spawn {template} agent for {markets}",
                reasoning=reason,
                autonomy_mode=self._autonomy_mode,
            )
            self.autonomy.request_approval(decision)
            return None

        markets = markets or []
        if genome is not None:
            agent = self.factory.spawn_from_evolution(genome, markets)
        else:
            agent = self.factory.spawn_from_template(template, markets, capital)

        self.coordinator.add_agent(agent)

        # Record decision
        decision = HiveDecision(
            decision_type=DecisionType.SpawnAgent,
            action_taken=f"Spawned {agent.agent_id} ({template})",
            reasoning=f"markets={markets}, capital={capital}",
            confidence=1.0,
            autonomy_mode=self._autonomy_mode,
        )
        self.db.record_decision(decision)

        return agent

    # -----------------------------------------------------------------------
    # Evolution
    # -----------------------------------------------------------------------

    def run_evolution_cycle(self, generations: int | None = None) -> dict[str, Any]:
        """Run one cycle of the evolutionary engine."""
        gens = generations or self._config.generations_per_cycle
        stats: dict[str, Any] = {}

        for _ in range(gens):
            gen_stats = self.evolution.run_generation(
                lambda g: g.fitness
            )
            stats = gen_stats
            self._generation += 1

            # Update archive
            for genome in self.evolution.get_best(n=5):
                self.archive.add(genome)

        # Migrate between islands
        if self._generation % self._config.migration_interval == 0:
            self.evolution.migrate()

        stats["archive_coverage"] = self.archive.coverage()
        stats["generation"] = self._generation
        return stats

    # -----------------------------------------------------------------------
    # Kill Switch
    # -----------------------------------------------------------------------

    def kill_switch(self) -> None:
        """Emergency halt. Pause all agents, cancel all orders."""
        logger.critical("KILL SWITCH ACTIVATED")
        for agent in self.coordinator.all_agents():
            self.coordinator.pause_agent(agent.agent_id, "kill_switch")

        # Record
        decision = HiveDecision(
            decision_type=DecisionType.RiskOff,
            action_taken="KILL SWITCH — all agents paused",
            reasoning="Manual kill switch activation",
            confidence=1.0,
            autonomy_mode=self._autonomy_mode,
        )
        self.db.record_decision(decision)

        # Trigger kill chain
        self.kill_chain.trigger(
            Severity.Sev1Critical,
            "kill_switch_manual",
            [a.agent_id for a in self.coordinator.all_agents()],
            0.0,
        )

    # -----------------------------------------------------------------------
    # Imprint (User Behavior Learning)
    # -----------------------------------------------------------------------

    def observe_user_action(self, action: ImprintAction) -> None:
        """Record a user action for behavioral modeling."""
        if self._config.imprint_enabled:
            self.imprint.observe(action)

    # -----------------------------------------------------------------------
    # Status
    # -----------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Comprehensive Hive status."""
        swarm = self.coordinator.swarm_status()
        swarm_dict = {
            "total_agents": swarm.total_agents,
            "active_agents": swarm.active_agents,
            "paper_agents": swarm.paper_agents,
            "shadow_agents": swarm.shadow_agents,
            "live_agents": swarm.live_agents,
            "total_capital": round(swarm.total_capital, 2),
            "allocated_capital": round(swarm.allocated_capital, 2),
            "reserve_capital": round(swarm.reserve_capital, 2),
            "total_pnl": round(swarm.total_pnl, 4),
            "aggregate_sharpe": round(swarm.aggregate_sharpe, 4),
            "aggregate_drawdown": round(swarm.aggregate_drawdown, 4),
        }
        return {
            "swarm": swarm_dict,
            "autonomy": self.autonomy.status(),
            "evolution": self.evolution.stats(),
            "archive_coverage": round(self.archive.coverage(), 4),
            "archive_cells": self.archive.cells_filled(),
            "criticality_warnings": (self.last_criticality.warning_count()
                                     if self.last_criticality else 0),
            "imprint": self.imprint.status(),
            "impact": self.impact.status(),
            "metamorphic_entropy": round(self.metamorphic.behavioral_entropy(), 4),
            "causal": self.causal.status(),
            "consensus_markets": len(self.consensus.active_markets()),
            "incidents_active": len(self.kill_chain.active_incidents()),
            "dream": self.dream.status(),
            "server": self.server.status(),
            "generation": self._generation,
            "running": self._running,
        }


# ---------------------------------------------------------------------------
# Client for Remote Connection
# ---------------------------------------------------------------------------

class HiveClient:
    """Client for connecting to a remote Hive server.

    Usage:
        client = HiveClient("ws://hive-server:8780", token="secret")
        client.connect()
        print(client.status())
        client.spawn(template="momentum", markets=["BTC-USD"])
    """

    def __init__(self, url: str, token: str = ""):
        self._url = url
        self._token = token
        self._ws: Any = None
        self._connected = False
        self._request_counter = 0

    def connect(self) -> bool:
        """Connect to the Hive server."""
        try:
            import websockets.sync.client as wsc
            self._ws = wsc.connect(self._url)
            # Authenticate
            self._ws.send(json.dumps({"token": self._token}))
            resp = json.loads(self._ws.recv())
            self._connected = resp.get("data", {}).get("authenticated", False)
            return self._connected
        except ImportError:
            raise ImportError("pip install websockets")
        except Exception as e:
            logger.error("Connection failed: %s", e)
            return False

    def disconnect(self) -> None:
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
            self._connected = False

    def _request(self, msg_type: str, action: str,
                 data: dict | None = None) -> dict[str, Any]:
        """Send a request and wait for response."""
        if not self._connected or not self._ws:
            return {"error": "not connected"}

        self._request_counter += 1
        rid = str(self._request_counter)
        msg = {
            "type": msg_type, "action": action,
            "data": data or {}, "request_id": rid,
        }
        self._ws.send(json.dumps(msg))
        resp = json.loads(self._ws.recv())
        return resp.get("data", {})

    # --- Queries ---

    def status(self) -> dict:
        return self._request("query", "status")

    def agents(self) -> list[dict]:
        return self._request("query", "agents").get("agents", [])

    def agent(self, agent_id: str) -> dict:
        return self._request("query", "agent", {"agent_id": agent_id})

    def pheromone(self, market_id: str = "") -> dict:
        return self._request("query", "pheromone", {"market_id": market_id})

    def mode(self) -> str:
        return self._request("query", "mode").get("mode", "unknown")

    def pending_approvals(self) -> list[dict]:
        return self._request("query", "pending").get("pending", [])

    # --- Commands ---

    def spawn(self, template: str = "momentum",
              markets: list[str] | None = None,
              capital: float = 0.0) -> dict:
        return self._request("command", "spawn", {
            "template": template, "markets": markets or [], "capital": capital,
        })

    def kill(self, agent_id: str, reason: str = "") -> dict:
        return self._request("command", "kill", {
            "agent_id": agent_id, "reason": reason,
        })

    def pause(self, agent_id: str) -> dict:
        return self._request("command", "pause", {"agent_id": agent_id})

    def resume(self, agent_id: str) -> dict:
        return self._request("command", "resume", {"agent_id": agent_id})

    def scale(self, agent_id: str, capital: float) -> dict:
        return self._request("command", "scale", {
            "agent_id": agent_id, "capital": capital,
        })

    def set_mode(self, mode: str) -> dict:
        return self._request("command", "set_mode", {"mode": mode})

    def approve(self, decision_id: str) -> dict:
        return self._request("command", "approve", {"decision_id": decision_id})

    def reject(self, decision_id: str, reason: str = "") -> dict:
        return self._request("command", "reject", {
            "decision_id": decision_id, "reason": reason,
        })

    def kill_switch(self) -> dict:
        return self._request("command", "kill_switch")

    def dream(self, generations: int | None = None) -> dict:
        return self._request("command", "dream", {"generations": generations})

    def evolve(self) -> dict:
        return self._request("command", "evolve")


# Required for HiveClient JSON import
import json
