"""Progressive autonomy controller for the Hive.

Trust is earned through demonstrated competence. The Hive starts in OBSERVE
mode and graduates through SUGGEST, SUPERVISED, AUTONOMOUS, and finally SKYNET.
Every mode transition requires explicit user approval — the controller only
*proposes* graduations, never forces them.

Thread-safe: all mutable state is behind a single reentrant lock.
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any

from horizon.hive._types import (
    AutonomyMode,
    DecisionType,
    HiveConfig,
    HiveDecision,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Ring-buffer trackers
# ---------------------------------------------------------------------------

_TRACKER_MAXLEN = 1000


@dataclass
class _SuggestionRecord:
    suggestion_id: str
    accepted: bool | None  # None = pending
    timestamp: float


class _SuggestionTracker:
    """Ring buffer tracking suggestion acceptance rates."""

    __slots__ = ("_buf", "_index")

    def __init__(self) -> None:
        self._buf: deque[_SuggestionRecord] = deque(maxlen=_TRACKER_MAXLEN)
        # Fast lookup by suggestion_id -> record (weak ref not needed, deque evicts)
        self._index: dict[str, _SuggestionRecord] = {}

    def record(self, suggestion_id: str) -> None:
        """Record that a suggestion was made (outcome pending)."""
        rec = _SuggestionRecord(
            suggestion_id=suggestion_id,
            accepted=None,
            timestamp=time.time(),
        )
        # If deque is at capacity, the leftmost record is about to be evicted.
        if len(self._buf) == _TRACKER_MAXLEN:
            evicted = self._buf[0]
            self._index.pop(evicted.suggestion_id, None)
        self._buf.append(rec)
        self._index[suggestion_id] = rec

    def accept(self, suggestion_id: str) -> None:
        rec = self._index.get(suggestion_id)
        if rec is not None:
            rec.accepted = True

    def reject(self, suggestion_id: str) -> None:
        rec = self._index.get(suggestion_id)
        if rec is not None:
            rec.accepted = False

    def acceptance_rate(self, days: int = 14) -> float:
        """Return acceptance rate over the last *days* days.

        Only counts records that have been resolved (accepted is not None).
        Returns 0.0 if no resolved records exist in the window.
        """
        cutoff = time.time() - days * 86400.0
        accepted = 0
        total = 0
        for rec in self._buf:
            if rec.timestamp < cutoff:
                continue
            if rec.accepted is None:
                continue
            total += 1
            if rec.accepted:
                accepted += 1
        if total == 0:
            return 0.0
        return accepted / total

    @property
    def total_recorded(self) -> int:
        return len(self._buf)

    @property
    def resolved_count(self) -> int:
        return sum(1 for r in self._buf if r.accepted is not None)


@dataclass
class _ApprovalRecord:
    decision_id: str
    approved: bool
    timestamp: float


class _ApprovalTracker:
    """Ring buffer tracking decision approval rates."""

    __slots__ = ("_buf",)

    def __init__(self) -> None:
        self._buf: deque[_ApprovalRecord] = deque(maxlen=_TRACKER_MAXLEN)

    def record(self, decision_id: str, approved: bool) -> None:
        self._buf.append(_ApprovalRecord(
            decision_id=decision_id,
            approved=approved,
            timestamp=time.time(),
        ))

    def approval_rate(self, days: int = 28) -> float:
        """Return approval rate over the last *days* days.

        Returns 0.0 if no records exist in the window.
        """
        cutoff = time.time() - days * 86400.0
        approved = 0
        total = 0
        for rec in self._buf:
            if rec.timestamp < cutoff:
                continue
            total += 1
            if rec.approved:
                approved += 1
        if total == 0:
            return 0.0
        return approved / total

    @property
    def total_recorded(self) -> int:
        return len(self._buf)


# ---------------------------------------------------------------------------
# Default permission sets per mode
# ---------------------------------------------------------------------------

_DEFAULT_AUTO_APPROVE: frozenset[DecisionType] = frozenset({
    DecisionType.MUTATE_AGENT,      # PBT parameter tuning
    DecisionType.PAUSE_AGENT,
    DecisionType.RESUME_AGENT,
})

_DEFAULT_REQUIRE_APPROVAL: frozenset[DecisionType] = frozenset({
    DecisionType.SPAWN_AGENT,
    DecisionType.KILL_AGENT,
    DecisionType.RISK_OFF,
    DecisionType.GRADUATION,
})


# ---------------------------------------------------------------------------
# AutonomyController
# ---------------------------------------------------------------------------

class AutonomyController:
    """Progressive autonomy: OBSERVE -> SUGGEST -> SUPERVISED -> AUTONOMOUS -> SKYNET.

    Trust is earned through demonstrated competence. Each mode has explicit
    graduation criteria. Mode transitions always require user approval.
    """

    def __init__(
        self,
        config: HiveConfig,
        db: Any | None = None,
    ) -> None:
        self._lock = threading.Lock()
        self._config = config
        self._db = db

        # Current mode
        self.mode: AutonomyMode = config.initial_mode
        self.mode_entered_at: float = time.time()

        # Trackers
        self.suggestion_tracker = _SuggestionTracker()
        self.approval_tracker = _ApprovalTracker()

        # Pending decisions awaiting user OK
        self.pending_approvals: dict[str, HiveDecision] = {}

        # Permission sets (mutable — user can customize)
        self.auto_approve_types: set[DecisionType] = set(_DEFAULT_AUTO_APPROVE)
        self.require_approval_types: set[DecisionType] = set(_DEFAULT_REQUIRE_APPROVAL)

        logger.info(
            "AutonomyController initialized — mode=%s",
            self.mode.value,
        )

    # ------------------------------------------------------------------
    # Permission checking
    # ------------------------------------------------------------------

    def check_permission(
        self,
        decision_type: DecisionType,
        capital_pct: float = 0.0,
    ) -> tuple[bool, str]:
        """Check whether *decision_type* is allowed under the current mode.

        Returns ``(allowed, reason)``.  ``reason`` is empty when allowed.
        """
        with self._lock:
            return self._check_permission_locked(decision_type, capital_pct)

    def _check_permission_locked(
        self,
        decision_type: DecisionType,
        capital_pct: float,
    ) -> tuple[bool, str]:
        mode = self.mode

        # ----- OBSERVE: nothing allowed ---------------------------------
        if mode == AutonomyMode.OBSERVE:
            return False, "observe mode — no actions permitted"

        # ----- SUGGEST: generate suggestions only, never execute --------
        if mode == AutonomyMode.SUGGEST:
            return False, "suggest-only mode — execution not permitted"

        # ----- SUPERVISED: act with approval for non-routine ------------
        if mode == AutonomyMode.SUPERVISED:
            # Always require approval for these types
            if decision_type in self.require_approval_types:
                return False, (
                    f"supervised mode — {decision_type.value} requires approval"
                )
            # Capital allocation above 10% requires approval
            if (
                decision_type == DecisionType.ALLOCATE_CAPITAL
                and capital_pct > 0.10
            ):
                return False, (
                    f"supervised mode — capital allocation of "
                    f"{capital_pct:.1%} exceeds 10% threshold, requires approval"
                )
            # Auto-approved routine actions
            if decision_type in self.auto_approve_types:
                return True, ""
            # Everything else in supervised: requires approval
            return False, (
                f"supervised mode — {decision_type.value} requires approval"
            )

        # ----- AUTONOMOUS: always allowed within guardrails -------------
        if mode == AutonomyMode.AUTONOMOUS:
            return True, ""

        # ----- SKYNET: always allowed, can modify guardrails ------------
        if mode == AutonomyMode.SKYNET:
            return True, ""

        # Unreachable, but defensive
        return False, f"unknown mode {mode.value}"  # pragma: no cover

    # ------------------------------------------------------------------
    # Approval queue
    # ------------------------------------------------------------------

    def request_approval(self, decision: HiveDecision) -> str:
        """Queue *decision* for user approval. Returns the decision_id."""
        with self._lock:
            decision.user_approved = None  # explicitly pending
            self.pending_approvals[decision.decision_id] = decision
            logger.info(
                "Approval requested — id=%s type=%s action=%s",
                decision.decision_id,
                decision.decision_type.value,
                decision.action_taken,
            )
            return decision.decision_id

    def approve(self, decision_id: str) -> HiveDecision | None:
        """Approve a pending decision. Returns the decision or None."""
        with self._lock:
            decision = self.pending_approvals.pop(decision_id, None)
            if decision is None:
                logger.warning("approve() — decision_id %s not found", decision_id)
                return None
            decision.user_approved = True
            self.approval_tracker.record(decision_id, approved=True)

            # Handle graduation approval
            if decision.decision_type == DecisionType.GRADUATION:
                target_str = decision.action_taken  # e.g. "graduate_to:supervised"
                target_mode = self._parse_graduation_target(target_str)
                if target_mode is not None:
                    self._set_mode_locked(target_mode)
                    logger.info(
                        "Graduation approved — now in %s mode",
                        target_mode.value,
                    )

            logger.info("Decision approved — id=%s", decision_id)
            return decision

    def reject(self, decision_id: str, reason: str = "") -> HiveDecision | None:
        """Reject a pending decision. Returns the decision or None."""
        with self._lock:
            decision = self.pending_approvals.pop(decision_id, None)
            if decision is None:
                logger.warning("reject() — decision_id %s not found", decision_id)
                return None
            decision.user_approved = False
            if reason:
                decision.outcome = f"rejected: {reason}"
            else:
                decision.outcome = "rejected"
            self.approval_tracker.record(decision_id, approved=False)
            logger.info("Decision rejected — id=%s reason=%s", decision_id, reason)
            return decision

    def pending(self) -> list[HiveDecision]:
        """Return all pending decisions, ordered by timestamp."""
        with self._lock:
            return sorted(
                self.pending_approvals.values(),
                key=lambda d: d.timestamp,
            )

    def expire_stale(self, timeout_seconds: float = 3600.0) -> list[HiveDecision]:
        """Expire pending decisions older than *timeout_seconds*.

        Returns the list of expired decisions.
        """
        now = time.time()
        expired: list[HiveDecision] = []
        with self._lock:
            stale_ids = [
                did
                for did, d in self.pending_approvals.items()
                if (now - d.timestamp) > timeout_seconds
            ]
            for did in stale_ids:
                decision = self.pending_approvals.pop(did)
                decision.user_approved = False
                decision.outcome = "expired"
                expired.append(decision)
                logger.info(
                    "Decision expired — id=%s age=%.0fs",
                    did,
                    now - decision.timestamp,
                )
        return expired

    # ------------------------------------------------------------------
    # Graduation evaluation
    # ------------------------------------------------------------------

    def evaluate_graduation(
        self,
        performance_sharpe: float = 0.0,
        months_profitable: int = 0,
        critical_failures_90d: int = 0,
        user_sharpe: float = 0.0,
    ) -> tuple[AutonomyMode | None, str]:
        """Evaluate whether the Hive has earned the next autonomy level.

        Returns ``(target_mode, evidence)`` if graduation criteria are met,
        or ``(None, "")`` if not.

        Graduation criteria
        -------------------
        OBSERVE -> SUGGEST:
            Minimum imprint actions observed AND model trained.
            (Proxied by: suggestion_tracker has >= imprint_min_actions records.)
        SUGGEST -> SUPERVISED:
            >= 80% suggestion acceptance rate over the last 14 days.
        SUPERVISED -> AUTONOMOUS:
            >= 95% approval rate over the last 28 days AND positive
            risk-adjusted return (performance_sharpe > 0).
        AUTONOMOUS -> SKYNET:
            >= 6 months profitable AND 0 critical failures in the last 90
            days AND Hive Sharpe exceeds user's Sharpe.
        """
        with self._lock:
            mode = self.mode

            if mode == AutonomyMode.OBSERVE:
                min_actions = self._config.imprint_min_actions
                recorded = self.suggestion_tracker.total_recorded
                if recorded >= min_actions:
                    evidence = (
                        f"Observed {recorded} actions "
                        f"(threshold: {min_actions}). "
                        f"Imprint model ready."
                    )
                    return AutonomyMode.SUGGEST, evidence
                return None, ""

            if mode == AutonomyMode.SUGGEST:
                rate = self.suggestion_tracker.acceptance_rate(days=14)
                resolved = self.suggestion_tracker.resolved_count
                # Need at least some resolved suggestions to be meaningful
                if resolved < 10:
                    return None, ""
                if rate >= 0.80:
                    evidence = (
                        f"Suggestion acceptance rate: {rate:.1%} "
                        f"over 14 days ({resolved} resolved). "
                        f"Threshold: 80%."
                    )
                    return AutonomyMode.SUPERVISED, evidence
                return None, ""

            if mode == AutonomyMode.SUPERVISED:
                rate = self.approval_tracker.approval_rate(days=28)
                total = self.approval_tracker.total_recorded
                if total < 10:
                    return None, ""
                if rate >= 0.95 and performance_sharpe > 0.0:
                    evidence = (
                        f"Approval rate: {rate:.1%} over 28 days "
                        f"({total} decisions). "
                        f"Sharpe: {performance_sharpe:.2f}. "
                        f"Threshold: 95% approval + positive risk-adjusted return."
                    )
                    return AutonomyMode.AUTONOMOUS, evidence
                return None, ""

            if mode == AutonomyMode.AUTONOMOUS:
                if (
                    months_profitable >= 6
                    and critical_failures_90d == 0
                    and performance_sharpe > user_sharpe
                ):
                    evidence = (
                        f"Profitable for {months_profitable} months "
                        f"(threshold: 6). "
                        f"Critical failures in 90d: {critical_failures_90d}. "
                        f"Hive Sharpe: {performance_sharpe:.2f} vs "
                        f"user Sharpe: {user_sharpe:.2f}."
                    )
                    return AutonomyMode.SKYNET, evidence
                return None, ""

            # Already at SKYNET — no further graduation
            return None, ""

    def propose_graduation(self, target: AutonomyMode, evidence: str) -> str:
        """Create a pending approval for a mode transition.

        Returns the decision_id of the graduation proposal.
        """
        decision = HiveDecision(
            decision_type=DecisionType.GRADUATION,
            action_taken=f"graduate_to:{target.value}",
            reasoning=evidence,
            confidence=1.0,
            autonomy_mode=self.mode,
        )
        return self.request_approval(decision)

    # ------------------------------------------------------------------
    # Mode management
    # ------------------------------------------------------------------

    def set_mode(self, mode: AutonomyMode) -> None:
        """Set mode directly (user override or approved graduation)."""
        with self._lock:
            self._set_mode_locked(mode)

    def _set_mode_locked(self, mode: AutonomyMode) -> None:
        old = self.mode
        self.mode = mode
        self.mode_entered_at = time.time()
        logger.info("Autonomy mode changed: %s -> %s", old.value, mode.value)

    # ------------------------------------------------------------------
    # Suggestion recording
    # ------------------------------------------------------------------

    def record_suggestion(self, suggestion_id: str) -> None:
        """Record that a suggestion was made."""
        with self._lock:
            self.suggestion_tracker.record(suggestion_id)

    def record_suggestion_accepted(self, suggestion_id: str) -> None:
        """Record that the user accepted a suggestion."""
        with self._lock:
            self.suggestion_tracker.accept(suggestion_id)

    def record_suggestion_rejected(self, suggestion_id: str) -> None:
        """Record that the user rejected a suggestion."""
        with self._lock:
            self.suggestion_tracker.reject(suggestion_id)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Return current autonomy status as a serializable dict."""
        with self._lock:
            now = time.time()
            return {
                "mode": self.mode.value,
                "mode_entered_at": self.mode_entered_at,
                "time_in_mode_seconds": round(now - self.mode_entered_at, 1),
                "pending_count": len(self.pending_approvals),
                "suggestion_acceptance_rate_14d": round(
                    self.suggestion_tracker.acceptance_rate(days=14), 4,
                ),
                "suggestion_total": self.suggestion_tracker.total_recorded,
                "suggestion_resolved": self.suggestion_tracker.resolved_count,
                "approval_rate_28d": round(
                    self.approval_tracker.approval_rate(days=28), 4,
                ),
                "approval_total": self.approval_tracker.total_recorded,
                "auto_approve_types": sorted(
                    dt.value for dt in self.auto_approve_types
                ),
                "require_approval_types": sorted(
                    dt.value for dt in self.require_approval_types
                ),
            }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_graduation_target(action_taken: str) -> AutonomyMode | None:
        """Parse target mode from ``'graduate_to:<mode>'`` string."""
        prefix = "graduate_to:"
        if not action_taken.startswith(prefix):
            return None
        mode_str = action_taken[len(prefix):]
        try:
            return AutonomyMode(mode_str)
        except ValueError:
            logger.error(
                "Invalid graduation target: %s", mode_str,
            )
            return None

    def __repr__(self) -> str:
        return (
            f"AutonomyController(mode={self.mode.value!r}, "
            f"pending={len(self.pending_approvals)})"
        )
