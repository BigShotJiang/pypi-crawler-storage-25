"""Collective intelligence engine for the Hive swarm.

Four layered aggregation mechanisms transform individual agent signals
into collective beliefs.  Each layer serves a different decision cadence:

1. **IC-Weighted Ensemble** — routine allocation, every tick.
2. **Internal Prediction Market** — binary questions with capital at stake.
3. **Mixture of Experts Gating** — regime-conditional agent routing.
4. **Dempster-Shafer Belief Aggregation** — high-stakes strategic decisions
   that must account for partial ignorance.

Thread-safe.  No external dependencies (pure Python math).
"""

from __future__ import annotations

import logging
import math
import threading
import time
import uuid
from typing import TYPE_CHECKING

from horizon.hive._types import ConsensusView, HiveConfig, InternalMarket

if TYPE_CHECKING:
    from horizon.hive._db import HiveDB

logger = logging.getLogger("horizon.hive.consensus")

# Maximum number of in-memory markets to prevent unbounded growth.
_MAX_MARKETS = 10_000

# Contradiction pairs for Dempster-Shafer combination.
_DS_CONTRADICTIONS: frozenset[frozenset[str]] = frozenset(
    {
        frozenset({"bullish", "bearish"}),
    }
)


class ConsensusEngine:
    """4-layer collective intelligence:

    1. IC-Weighted Signal Ensemble (routine allocation)
    2. Internal Prediction Market (binary questions)
    3. Mixture of Experts Gating (agent routing)
    4. Dempster-Shafer Belief Aggregation (high-stakes strategic)
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, config: HiveConfig, db: HiveDB | None = None) -> None:
        self._config = config
        self._db = db
        self._lock = threading.Lock()
        # market_id -> InternalMarket
        self._markets: dict[str, InternalMarket] = {}
        # agent_id -> cumulative fitness delta from resolved markets
        self._fitness_ledger: dict[str, float] = {}

    # ==================================================================
    # Layer 1: IC-Weighted Signal Ensemble
    # ==================================================================

    def ic_weighted_combine(
        self,
        signals: dict[str, float],
        ics: dict[str, float],
    ) -> float:
        """Combine agent signals weighted by Information Coefficient.

        Result = sum(IC_i * Signal_i) / sum(|IC_i|)

        Args:
            signals: ``{agent_id: signal_value}`` where signal is a
                real-valued directional view (positive = bullish).
            ics: ``{agent_id: information_coefficient}`` where IC is the
                historical rank correlation between forecasts and outcomes.
                Can be negative (contrarian indicator).

        Returns:
            Weighted consensus signal.  Returns 0.0 when no valid
            agent signals are available.
        """
        numerator = 0.0
        denominator = 0.0
        for agent_id, signal in signals.items():
            if not math.isfinite(signal):
                continue
            ic = ics.get(agent_id, 0.0)
            if not math.isfinite(ic):
                continue
            numerator += ic * signal
            denominator += abs(ic)
        if denominator < 1e-15:
            return 0.0
        return numerator / denominator

    # ==================================================================
    # Layer 2: Internal Prediction Market
    # ==================================================================

    def create_market(self, question: str, deadline: float) -> str:
        """Create an internal prediction market for a binary question.

        Args:
            question: Human-readable question (e.g. "BTC > 100k by EOD?").
            deadline: Unix timestamp after which the market expires.

        Returns:
            Unique market_id.

        Raises:
            ValueError: If the deadline is in the past.
        """
        now = time.time()
        if deadline <= now:
            raise ValueError(
                f"Deadline {deadline:.0f} is in the past (now={now:.0f})"
            )

        market = InternalMarket(
            market_id=uuid.uuid4().hex[:12],
            question=question,
            deadline=deadline,
            created_at=now,
        )

        with self._lock:
            # Evict oldest resolved markets if approaching cap.
            if len(self._markets) >= _MAX_MARKETS:
                self._evict_oldest_resolved_locked()
            self._markets[market.market_id] = market

        if self._db is not None:
            try:
                self._db.save_internal_market(market)
            except Exception:
                logger.warning(
                    "Failed to persist market %s", market.market_id, exc_info=True,
                )

        logger.info(
            "Created internal market %s: %s (deadline %.0f)",
            market.market_id,
            question,
            deadline,
        )
        return market.market_id

    def submit_view(
        self,
        market_id: str,
        agent_id: str,
        probability: float,
        confidence: float,
        capital_weight: float,
    ) -> None:
        """Agent submits a probability view on an internal market.

        Stake = (prob - 0.5) * confidence * capital_weight.
        Positive stake = believes Yes; negative = believes No.

        Args:
            market_id: Target internal market.
            agent_id: Submitting agent.
            probability: Agent's assessed probability of Yes in [0, 1].
            confidence: Conviction level in [0, 1].
            capital_weight: Reputation-proportional capital share (>= 0).

        Raises:
            KeyError: If *market_id* does not exist.
            ValueError: If the market is already resolved or inputs are
                out of range.
        """
        probability = max(0.0, min(1.0, probability))
        confidence = max(0.0, min(1.0, confidence))
        capital_weight = max(0.0, capital_weight)

        stake = (probability - 0.5) * confidence * capital_weight

        view = ConsensusView(
            agent_id=agent_id,
            probability=probability,
            confidence=confidence,
            stake=stake,
        )

        with self._lock:
            market = self._markets.get(market_id)
            if market is None:
                raise KeyError(f"Unknown market: {market_id}")
            if market.resolved:
                raise ValueError(f"Market {market_id} is already resolved")
            market.views[agent_id] = view

        if self._db is not None:
            try:
                self._db.save_internal_market(market)
            except Exception:
                logger.warning(
                    "Failed to persist view for market %s", market_id, exc_info=True,
                )

    def resolve_market(
        self,
        market_id: str,
        outcome: bool,
    ) -> dict[str, float]:
        """Resolve an internal market and compute fitness deltas.

        Correct predictions: ``+|stake| * 0.1``.
        Wrong predictions: ``-|stake| * 0.15`` (asymmetric to penalise
        overconfident wrong calls harder).

        Args:
            market_id: Market to resolve.
            outcome: True if the question resolved Yes, False otherwise.

        Returns:
            ``{agent_id: fitness_delta}`` for every agent that participated.

        Raises:
            KeyError: If *market_id* does not exist.
            ValueError: If already resolved.
        """
        with self._lock:
            market = self._markets.get(market_id)
            if market is None:
                raise KeyError(f"Unknown market: {market_id}")
            if market.resolved:
                raise ValueError(f"Market {market_id} is already resolved")

            market.resolved = True
            market.outcome = outcome

            deltas: dict[str, float] = {}
            for agent_id, view in market.views.items():
                # A positive stake means the agent bet Yes.
                agent_bet_yes = view.stake >= 0.0
                correct = agent_bet_yes == outcome
                abs_stake = abs(view.stake)
                if correct:
                    delta = abs_stake * 0.1
                else:
                    delta = -(abs_stake * 0.15)
                deltas[agent_id] = delta
                self._fitness_ledger[agent_id] = (
                    self._fitness_ledger.get(agent_id, 0.0) + delta
                )

        # Persist resolved state.
        if self._db is not None:
            try:
                self._db.save_internal_market(market)
            except Exception:
                logger.warning(
                    "Failed to persist resolved market %s", market_id, exc_info=True,
                )

        logger.info(
            "Resolved market %s: outcome=%s, participants=%d",
            market_id,
            outcome,
            len(deltas),
        )
        return deltas

    def consensus_probability(self, market_id: str) -> float:
        """Current capital-weighted consensus probability for a market.

        Uses the ``InternalMarket.consensus_probability`` property which
        computes Yes-stake / (Yes-stake + No-stake).

        Args:
            market_id: Target internal market.

        Returns:
            Probability in [0, 1].  Returns 0.5 if the market has no
            views or does not exist.
        """
        with self._lock:
            market = self._markets.get(market_id)
            if market is None:
                return 0.5
            return market.consensus_probability

    def active_markets(self) -> list[InternalMarket]:
        """Return all unresolved internal markets.

        Returns a shallow copy of each market so callers cannot mutate
        engine state.
        """
        with self._lock:
            return [
                self._copy_market(m)
                for m in self._markets.values()
                if not m.resolved
            ]

    def get_market(self, market_id: str) -> InternalMarket | None:
        """Retrieve a single market by ID, or None if not found.

        Returns a copy.
        """
        with self._lock:
            m = self._markets.get(market_id)
            if m is None:
                return None
            return self._copy_market(m)

    def expire_markets(self) -> None:
        """Auto-resolve markets that have passed their deadline.

        Expired markets resolve as ``outcome=False`` (conservative default:
        the predicted event did not happen).  Fitness deltas are applied
        as in :meth:`resolve_market`.
        """
        now = time.time()
        to_expire: list[str] = []

        with self._lock:
            for mid, m in self._markets.items():
                if not m.resolved and m.deadline <= now:
                    to_expire.append(mid)

        for mid in to_expire:
            try:
                self.resolve_market(mid, outcome=False)
                logger.info("Auto-expired market %s (deadline passed)", mid)
            except (KeyError, ValueError):
                # Race: resolved between check and resolve call.
                pass

    def fitness_delta(self, agent_id: str) -> float:
        """Cumulative prediction-market fitness delta for *agent_id*."""
        with self._lock:
            return self._fitness_ledger.get(agent_id, 0.0)

    # ==================================================================
    # Layer 3: Mixture of Experts Gating
    # ==================================================================

    def compute_expert_weights(
        self,
        regime_probs: list[float],
        avg_volatility: float,
        avg_correlation: float,
        opportunity_score: float,
        agent_recent_returns: dict[str, list[float]],
    ) -> dict[str, float]:
        """Compute optimal capital weight per agent for current conditions.

        Uses softmax over regime-conditional historical returns.  For each
        agent, the weight is::

            exp(context_score_i) / Z

        where ``context_score_i`` is a weighted combination of the agent's
        recent performance conditional on the dominant regime, modulated
        by volatility, correlation, and opportunity signals.

        Args:
            regime_probs: Probability distribution over regimes (e.g.
                ``[p_low_vol, p_normal, p_crisis]``).  Must sum to ~1.
            avg_volatility: Current average volatility across the book
                (used for temperature scaling).
            avg_correlation: Average pairwise correlation across positions
                (high correlation => concentrate on fewer experts).
            opportunity_score: Aggregate opportunity pheromone (higher =>
                more aggressive allocation).
            agent_recent_returns: ``{agent_id: [recent_returns...]}``
                where each list contains the agent's last N cycle returns.

        Returns:
            ``{agent_id: weight}`` where weights sum to 1.0.
            Empty dict if no agents have return data.
        """
        if not agent_recent_returns:
            return {}

        n_regimes = max(len(regime_probs), 1)

        # Softmax temperature: higher volatility => softer (more uniform)
        # allocation; lower vol => sharper differentiation.
        temperature = max(0.1, 0.5 + avg_volatility * 2.0)

        # Correlation penalty: when correlation is high, concentrate on
        # fewer experts (increase temperature less).
        correlation_factor = 1.0 + max(0.0, avg_correlation) * 0.5

        # Opportunity bonus: more opportunity => boost aggressive agents.
        opportunity_bonus = max(0.0, min(1.0, opportunity_score)) * 0.2

        scores: dict[str, float] = {}
        for agent_id, returns in agent_recent_returns.items():
            if not returns:
                scores[agent_id] = 0.0
                continue

            # Compute regime-conditional expected return.  We split
            # the return history into segments proportional to regime
            # probabilities and compute a weighted sum.
            n_returns = len(returns)
            weighted_return = 0.0
            offset = 0
            for r_idx in range(n_regimes):
                rp = regime_probs[r_idx] if r_idx < len(regime_probs) else 0.0
                # How many returns belong to this regime segment.
                segment_len = max(1, int(round(n_returns * max(rp, 1e-6))))
                segment_end = min(offset + segment_len, n_returns)
                if segment_end <= offset:
                    offset = segment_end
                    continue
                segment = returns[offset:segment_end]
                seg_mean = sum(segment) / len(segment)
                weighted_return += rp * seg_mean
                offset = segment_end

            # If the agent has fewer returns than regimes, handle residual.
            if offset < n_returns:
                residual = returns[offset:]
                residual_mean = sum(residual) / len(residual)
                weighted_return += residual_mean * 0.1

            # Apply opportunity bonus to agents with positive returns.
            if weighted_return > 0.0:
                weighted_return *= 1.0 + opportunity_bonus

            # Penalise volatility of returns (risk-adjusted score).
            if n_returns >= 2:
                ret_mean = sum(returns) / n_returns
                var = sum((r - ret_mean) ** 2 for r in returns) / n_returns
                ret_std = math.sqrt(var)
                # Sharpe-like adjustment: penalise high variance.
                if ret_std > 1e-12:
                    weighted_return /= (1.0 + ret_std * correlation_factor)

            scores[agent_id] = weighted_return

        # Softmax with temperature.
        return self._softmax(scores, temperature)

    # ==================================================================
    # Layer 4: Dempster-Shafer Belief Aggregation
    # ==================================================================

    def dempster_shafer_combine(
        self,
        beliefs: list[dict[str, float]],
    ) -> dict[str, float]:
        """Combine evidence from multiple agents using Dempster-Shafer theory.

        Each belief is a mass function mapping focal elements to masses.
        The special key ``"uncertain"`` represents the universal set
        (total ignorance).  All other keys are singletons.

        Known contradiction pairs:

        - ``bullish`` vs ``bearish``

        The algorithm iteratively combines mass functions pairwise via
        Dempster's rule of combination:

        1. For each pair of focal elements from the two sources, compute
           the product of their masses.
        2. Assign the product to the *intersection* of the pair.
        3. Products assigned to the empty set (contradictions) accumulate
           as *conflict* (K).
        4. Normalise surviving masses by ``1 / (1 - K)``.

        Args:
            beliefs: List of mass functions, one per agent.  Each dict
                maps hypothesis labels to non-negative masses that should
                sum to 1.0.  Example::

                    {"bullish": 0.4, "bearish": 0.1, "uncertain": 0.5}

        Returns:
            Combined mass function ``{hypothesis: mass}``.
            Returns ``{"uncertain": 1.0}`` for empty input or when
            conflict is total (K >= 1.0).
        """
        if not beliefs:
            return {"uncertain": 1.0}

        # Normalise each input so masses sum to 1.
        normalised: list[dict[str, float]] = []
        for raw in beliefs:
            total = sum(max(0.0, v) for v in raw.values())
            if total < 1e-15:
                continue
            normalised.append({k: max(0.0, v) / total for k, v in raw.items()})

        if not normalised:
            return {"uncertain": 1.0}

        # Iterative pairwise combination.
        combined = normalised[0]
        for i in range(1, len(normalised)):
            combined = self._ds_combine_pair(combined, normalised[i])
            if combined is None:
                # Total conflict — return vacuous belief.
                return {"uncertain": 1.0}

        # Remove negligible masses and re-normalise.
        result: dict[str, float] = {}
        for k, v in combined.items():
            if v > 1e-12:
                result[k] = v
        total = sum(result.values())
        if total < 1e-15:
            return {"uncertain": 1.0}
        return {k: v / total for k, v in result.items()}

    # ==================================================================
    # Private helpers
    # ==================================================================

    @staticmethod
    def _ds_combine_pair(
        m1: dict[str, float],
        m2: dict[str, float],
    ) -> dict[str, float] | None:
        """Combine two mass functions via Dempster's rule.

        Returns None if conflict K >= 1.0 (total disagreement).
        """
        combined: dict[str, float] = {}
        conflict = 0.0

        for h1, mass1 in m1.items():
            if mass1 <= 0.0:
                continue
            for h2, mass2 in m2.items():
                if mass2 <= 0.0:
                    continue
                product = mass1 * mass2

                # Compute intersection of focal elements.
                intersection = _ds_intersect(h1, h2)
                if intersection is None:
                    # Empty set — this is conflict.
                    conflict += product
                else:
                    combined[intersection] = combined.get(intersection, 0.0) + product

        normaliser = 1.0 - conflict
        if normaliser < 1e-15:
            return None  # Total conflict.

        return {k: v / normaliser for k, v in combined.items()}

    @staticmethod
    def _softmax(scores: dict[str, float], temperature: float) -> dict[str, float]:
        """Numerically stable softmax over a dict of scores.

        Returns ``{key: weight}`` with weights summing to 1.0.
        """
        if not scores:
            return {}

        # Subtract max for numerical stability.
        max_score = max(scores.values())
        exp_scores: dict[str, float] = {}
        total = 0.0
        for k, s in scores.items():
            e = math.exp((s - max_score) / max(temperature, 1e-12))
            exp_scores[k] = e
            total += e

        if total < 1e-15:
            # Degenerate — return uniform.
            n = len(scores)
            return {k: 1.0 / n for k in scores}

        return {k: v / total for k, v in exp_scores.items()}

    @staticmethod
    def _copy_market(m: InternalMarket) -> InternalMarket:
        """Create a shallow copy of an InternalMarket.

        Views dict is copied so mutations to the returned object do not
        affect the engine's internal state.
        """
        return InternalMarket(
            market_id=m.market_id,
            question=m.question,
            deadline=m.deadline,
            views=dict(m.views),
            resolved=m.resolved,
            outcome=m.outcome,
            created_at=m.created_at,
        )

    def _evict_oldest_resolved_locked(self) -> None:
        """Remove the oldest resolved markets to stay under the cap.

        Caller must hold ``_lock``.  Removes up to 10 % of resolved
        markets per eviction pass.
        """
        resolved = [
            (mid, m.created_at)
            for mid, m in self._markets.items()
            if m.resolved
        ]
        if not resolved:
            return
        resolved.sort(key=lambda x: x[1])
        to_remove = max(1, len(resolved) // 10)
        for mid, _ in resolved[:to_remove]:
            del self._markets[mid]


# ======================================================================
# Module-level helpers
# ======================================================================


def _ds_intersect(h1: str, h2: str) -> str | None:
    """Compute the intersection of two Dempster-Shafer focal elements.

    Rules:
    - ``uncertain`` is the universal set: intersects with anything to
      yield the other element.
    - Two identical singletons yield that singleton.
    - Two different singletons that form a known contradiction pair
      yield None (empty set).
    - Two different singletons that are not known contradictions yield
      the first element (conservative: assumes compatible sub-hypotheses).

    Returns:
        The intersection hypothesis label, or None for the empty set.
    """
    # Universal set absorbs everything.
    if h1 == "uncertain":
        return h2
    if h2 == "uncertain":
        return h1

    # Same hypothesis.
    if h1 == h2:
        return h1

    # Check if the pair is a known contradiction.
    pair = frozenset({h1, h2})
    if pair in _DS_CONTRADICTIONS:
        return None

    # Non-contradictory distinct hypotheses: treat as compatible.
    # Return the more specific one (arbitrary but deterministic).
    return min(h1, h2)
