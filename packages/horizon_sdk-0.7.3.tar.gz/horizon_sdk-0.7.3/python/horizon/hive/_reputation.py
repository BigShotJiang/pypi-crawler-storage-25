"""Bayesian agent reputation tracking for the Hive swarm."""

from __future__ import annotations

import logging
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from horizon.hive._db import HiveDB

logger = logging.getLogger("horizon.hive.reputation")

# ---------------------------------------------------------------------------
# Internal dataclass
# ---------------------------------------------------------------------------

_HISTORY_MAXLEN = 200
_FINGERPRINT_EMA_ALPHA = 0.1


@dataclass
class _AgentReputation:
    """Mutable reputation state for a single agent."""

    alpha: float = 1.0  # Beta-distribution parameter (successes + prior)
    beta: float = 1.0   # Beta-distribution parameter (failures + prior)
    score: float = 0.5
    confidence: float = 0.0
    history: deque = field(default_factory=lambda: deque(maxlen=_HISTORY_MAXLEN))
    style_fingerprint: dict[str, float] = field(default_factory=dict)
    # Running variance for each fingerprint stat (Welford-style).
    # Stores (count, mean, M2) per stat key for drift detection.
    _fingerprint_var: dict[str, tuple[int, float, float]] = field(
        default_factory=dict,
    )


# ---------------------------------------------------------------------------
# ReputationSystem
# ---------------------------------------------------------------------------


class ReputationSystem:
    """Bayesian reputation tracking for swarm agents.

    Every agent has a reputation score [0, 1] and confidence [0, 1].
    Score starts at 0.5 (neutral). Updated via Bayesian posterior after
    each trading cycle outcome. Reputation decays toward 0.5 without evidence.

    High reputation = more capital, stronger pheromone, priority API allocation.
    Low reputation = throttled capital, weakened pheromone, termination candidate.
    """

    # --------------------------------------------------------------------- #
    # Init
    # --------------------------------------------------------------------- #

    def __init__(self, db: HiveDB | None = None) -> None:
        self._agents: dict[str, _AgentReputation] = {}
        self._db = db
        self._lock = threading.Lock()

    # --------------------------------------------------------------------- #
    # Core update
    # --------------------------------------------------------------------- #

    def update(
        self,
        agent_id: str,
        outcome: float,
        timestamp: float | None = None,
    ) -> None:
        """Bayesian posterior update from a trading cycle outcome.

        Args:
            agent_id: Unique agent identifier.
            outcome: Normalized trading result in [-1, +1].  Clamped if
                outside that range.
            timestamp: Epoch seconds.  Defaults to ``time.time()``.
        """
        ts = timestamp if timestamp is not None else time.time()
        outcome = max(-1.0, min(1.0, outcome))

        with self._lock:
            rep = self._ensure(agent_id)

            # Beta-distribution update: positive outcomes add to alpha,
            # negative outcomes add to beta.
            rep.alpha += max(0.0, outcome)
            rep.beta += max(0.0, -outcome)

            total = rep.alpha + rep.beta
            rep.score = rep.alpha / total
            rep.confidence = 1.0 - 1.0 / math.sqrt(total)
            rep.history.append((ts, outcome))

        # Persist outside the hot lock path (DB may do I/O).
        if self._db is not None:
            try:
                self._db.record_reputation(agent_id, rep.score, rep.confidence, ts)
            except Exception:
                logger.warning(
                    "Failed to persist reputation for %s", agent_id, exc_info=True,
                )

    # --------------------------------------------------------------------- #
    # Query
    # --------------------------------------------------------------------- #

    def get(self, agent_id: str) -> tuple[float, float]:
        """Return ``(score, confidence)`` for *agent_id*.

        Returns ``(0.5, 0.0)`` for unknown agents.
        """
        with self._lock:
            rep = self._agents.get(agent_id)
            if rep is None:
                return (0.5, 0.0)
            return (rep.score, rep.confidence)

    # --------------------------------------------------------------------- #
    # Decay
    # --------------------------------------------------------------------- #

    def decay(self, dt_seconds: float, halflife: float = 86400.0) -> None:
        """Decay all scores toward 0.5 (neutral) over elapsed time.

        Uses exponential decay:
        ``score = 0.5 + (score - 0.5) * exp(-0.693 * dt / halflife)``

        Args:
            dt_seconds: Wall-clock seconds since last decay call.
            halflife: Seconds for the deviation from 0.5 to halve.
                Defaults to 86 400 (one day).
        """
        if dt_seconds <= 0.0 or halflife <= 0.0:
            return
        factor = math.exp(-0.693147180559945 * dt_seconds / halflife)
        with self._lock:
            for rep in self._agents.values():
                rep.score = 0.5 + (rep.score - 0.5) * factor
                # Re-derive alpha/beta from decayed score while preserving
                # total evidence mass so that confidence stays consistent.
                total = rep.alpha + rep.beta
                rep.alpha = rep.score * total
                rep.beta = (1.0 - rep.score) * total

    # --------------------------------------------------------------------- #
    # Capital & pheromone weights
    # --------------------------------------------------------------------- #

    def capital_weight(self, agent_id: str) -> float:
        """Reputation-proportional capital allocation weight.

        Returns ``max(0.1, score ** 1.5)`` so that low-reputation agents
        still receive at least 10 % of base capital.
        """
        with self._lock:
            rep = self._agents.get(agent_id)
            score = rep.score if rep is not None else 0.5
        return max(0.1, score ** 1.5)

    def pheromone_weight(self, agent_id: str) -> float:
        """Reputation-proportional pheromone influence.

        Returns ``score / 0.5`` (1.0 at neutral, 2.0 at perfect, 0.0 at
        zero reputation).
        """
        with self._lock:
            rep = self._agents.get(agent_id)
            score = rep.score if rep is not None else 0.5
        return score / 0.5

    # --------------------------------------------------------------------- #
    # Style drift detection
    # --------------------------------------------------------------------- #

    def detect_style_drift(
        self,
        agent_id: str,
        current_stats: dict[str, float],
        threshold: float = 2.0,
    ) -> bool:
        """Detect whether an agent's trading style has materially changed.

        Compares *current_stats* (expected keys: ``return_mean``,
        ``return_std``, ``trade_frequency``, ``position_size_avg``) against
        the historical rolling fingerprint.  Returns ``True`` if any stat
        deviates by more than *threshold* standard deviations from the
        historical mean.

        If the agent has no fingerprint yet, returns ``False`` (no basis
        for comparison).
        """
        with self._lock:
            rep = self._agents.get(agent_id)
            if rep is None or not rep._fingerprint_var:
                return False

            for key, value in current_stats.items():
                var_entry = rep._fingerprint_var.get(key)
                if var_entry is None:
                    continue
                count, mean, m2 = var_entry
                if count < 2:
                    continue
                std = math.sqrt(m2 / count)
                if std < 1e-12:
                    continue
                if abs(value - mean) > threshold * std:
                    return True
        return False

    def update_fingerprint(
        self,
        agent_id: str,
        stats: dict[str, float],
    ) -> None:
        """Update rolling style fingerprint using EMA (alpha=0.1).

        Also updates a Welford online variance tracker per stat key so
        that :meth:`detect_style_drift` can compute z-scores.
        """
        alpha = _FINGERPRINT_EMA_ALPHA
        with self._lock:
            rep = self._ensure(agent_id)
            for key, value in stats.items():
                if not math.isfinite(value):
                    continue
                prev = rep.style_fingerprint.get(key)
                if prev is None:
                    rep.style_fingerprint[key] = value
                else:
                    rep.style_fingerprint[key] = alpha * value + (1.0 - alpha) * prev

                # Welford online variance update
                entry = rep._fingerprint_var.get(key)
                if entry is None:
                    rep._fingerprint_var[key] = (1, value, 0.0)
                else:
                    count, mean, m2 = entry
                    count += 1
                    delta = value - mean
                    mean += delta / count
                    delta2 = value - mean
                    m2 += delta * delta2
                    rep._fingerprint_var[key] = (count, mean, m2)

    # --------------------------------------------------------------------- #
    # Rankings
    # --------------------------------------------------------------------- #

    def ranking(self) -> list[tuple[str, float, float]]:
        """All agents sorted by reputation score descending.

        Returns:
            List of ``(agent_id, score, confidence)`` tuples.
        """
        with self._lock:
            items = [
                (aid, rep.score, rep.confidence)
                for aid, rep in self._agents.items()
            ]
        items.sort(key=lambda t: t[1], reverse=True)
        return items

    def bottom_agents(self, fraction: float = 0.2) -> list[str]:
        """Return the bottom *fraction* of agents by reputation.

        These are termination / PBT-exploitation candidates.
        """
        ranked = self.ranking()
        if not ranked:
            return []
        n = max(1, int(math.ceil(len(ranked) * max(0.0, min(1.0, fraction)))))
        return [aid for aid, _, _ in ranked[-n:]]

    def top_agents(self, fraction: float = 0.2) -> list[str]:
        """Return the top *fraction* of agents by reputation."""
        ranked = self.ranking()
        if not ranked:
            return []
        n = max(1, int(math.ceil(len(ranked) * max(0.0, min(1.0, fraction)))))
        return [aid for aid, _, _ in ranked[:n]]

    # --------------------------------------------------------------------- #
    # Internals
    # --------------------------------------------------------------------- #

    def _ensure(self, agent_id: str) -> _AgentReputation:
        """Return or create the reputation entry.  Caller must hold ``_lock``."""
        rep = self._agents.get(agent_id)
        if rep is None:
            rep = _AgentReputation()
            self._agents[agent_id] = rep
        return rep
