"""The Imprint System — User behavior learning via observation + behavioral cloning.

Observes how the user interacts with Horizon (CLI commands, parameter changes,
manual overrides, market choices) and builds a behavioral model. Over time,
the Hive learns to anticipate and replicate the user's trading style.

Pipeline: OBSERVATION → BEHAVIORAL CLONING → INVERSE RL → DAgger REFINEMENT
"""

from __future__ import annotations

import json
import math
import random
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

from horizon.hive._types import HiveConfig, ImprintAction

if TYPE_CHECKING:
    from horizon.hive._db import HiveDB


# ---------------------------------------------------------------------------
# Action Types the system can predict
# ---------------------------------------------------------------------------

ACTION_TYPES = [
    "submit_order", "cancel_order", "deploy_strategy", "set_params",
    "kill_switch", "pause_strategy", "resume_strategy", "scale_strategy",
    "do_nothing",
]

# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------

FEATURE_NAMES = [
    "portfolio_heat", "directional_bias", "pnl_momentum",
    "regime_trending", "regime_mean_reverting", "regime_volatile",
    "hour_sin", "hour_cos", "day_sin", "day_cos",
    "opportunity_score", "toxicity_score", "volatility_level",
    "drawdown_current", "num_positions", "cash_ratio",
]

NUM_FEATURES = len(FEATURE_NAMES)
NUM_ACTIONS = len(ACTION_TYPES)


def _extract_features(action: ImprintAction) -> list[float]:
    """Extract normalized feature vector from an ImprintAction context."""
    ps = action.pheromone_state
    positions = action.positions
    hour = action.time_of_day  # 0-1
    day = action.day_of_week   # 0-6

    total_notional = sum(abs(p.get("notional", 0)) for p in positions)
    net_direction = sum(p.get("notional", 0) for p in positions)
    cap = max(total_notional, 1.0)

    return [
        min(1.0, total_notional / max(cap, 1.0)),           # portfolio_heat
        max(-1.0, min(1.0, net_direction / max(cap, 1.0))), # directional_bias
        max(-1.0, min(1.0, action.pnl / max(cap * 0.1, 1.0))),  # pnl_momentum
        float(action.regime == "trending"),                   # regime flags
        float(action.regime == "mean_reverting"),
        float(action.regime == "volatile"),
        math.sin(2 * math.pi * hour),                        # time encoding
        math.cos(2 * math.pi * hour),
        math.sin(2 * math.pi * day / 7),
        math.cos(2 * math.pi * day / 7),
        ps.get("opportunity", 0.0) / 100.0,                  # pheromone
        ps.get("toxicity", 0.0) / 50.0,
        min(1.0, action.volatility),                          # volatility
        0.0,                                                  # drawdown (filled if available)
        min(1.0, len(positions) / 20.0),                      # num_positions
        1.0 - min(1.0, total_notional / max(cap, 1.0)),      # cash_ratio
    ]


def _action_index(action_type: str) -> int:
    try:
        return ACTION_TYPES.index(action_type)
    except ValueError:
        return ACTION_TYPES.index("do_nothing")


# ---------------------------------------------------------------------------
# Lightweight MLP (no PyTorch — pure Python + math)
# ---------------------------------------------------------------------------

@dataclass
class _Layer:
    """Single dense layer: y = activation(W @ x + b)."""
    weights: list[list[float]]   # [out_dim][in_dim]
    biases: list[float]          # [out_dim]

    def forward(self, x: list[float]) -> list[float]:
        out = []
        for j in range(len(self.biases)):
            s = self.biases[j]
            for i in range(len(x)):
                s += self.weights[j][i] * x[i]
            out.append(s)
        return out


def _relu(x: list[float]) -> list[float]:
    return [max(0.0, v) for v in x]


def _softmax(x: list[float]) -> list[float]:
    mx = max(x)
    exps = [math.exp(v - mx) for v in x]
    s = sum(exps)
    return [e / s for e in exps]


def _init_layer(in_dim: int, out_dim: int, rng: random.Random) -> _Layer:
    """Xavier initialization."""
    scale = math.sqrt(2.0 / (in_dim + out_dim))
    w = [[rng.gauss(0, scale) for _ in range(in_dim)] for _ in range(out_dim)]
    b = [0.0] * out_dim
    return _Layer(w, b)


class _MLP:
    """3-layer MLP: 16 → 64 → 32 → 9 (action distribution)."""

    def __init__(self, seed: int = 42):
        rng = random.Random(seed)
        self.l1 = _init_layer(NUM_FEATURES, 64, rng)
        self.l2 = _init_layer(64, 32, rng)
        self.l3 = _init_layer(32, NUM_ACTIONS, rng)
        self._trained = False

    def predict(self, features: list[float]) -> list[float]:
        """Forward pass → softmax action probabilities."""
        h1 = _relu(self.l1.forward(features))
        h2 = _relu(self.l2.forward(h1))
        logits = self.l3.forward(h2)
        return _softmax(logits)

    def predict_action(self, features: list[float]) -> tuple[str, float]:
        """Return (action_type, confidence)."""
        probs = self.predict(features)
        idx = max(range(len(probs)), key=lambda i: probs[i])
        return ACTION_TYPES[idx], probs[idx]

    def train(self, features_batch: list[list[float]],
              labels_batch: list[int], epochs: int = 50,
              lr: float = 0.01) -> dict[str, float]:
        """Mini-batch SGD training with cross-entropy loss."""
        if not features_batch:
            return {"loss": 0.0, "accuracy": 0.0}

        n = len(features_batch)
        best_loss = float("inf")
        final_acc = 0.0

        for epoch in range(epochs):
            total_loss = 0.0
            correct = 0
            indices = list(range(n))
            random.shuffle(indices)

            for idx in indices:
                x = features_batch[idx]
                target = labels_batch[idx]

                # Forward
                h1_pre = self.l1.forward(x)
                h1 = _relu(h1_pre)
                h2_pre = self.l2.forward(h1)
                h2 = _relu(h2_pre)
                logits = self.l3.forward(h2)
                probs = _softmax(logits)

                # Loss
                p = max(probs[target], 1e-10)
                total_loss += -math.log(p)
                if max(range(len(probs)), key=lambda i: probs[i]) == target:
                    correct += 1

                # Backward (simplified gradient descent)
                # Gradient of cross-entropy + softmax = probs - one_hot
                d_logits = list(probs)
                d_logits[target] -= 1.0

                # Layer 3 gradients
                for j in range(NUM_ACTIONS):
                    self.l3.biases[j] -= lr * d_logits[j]
                    for i in range(32):
                        self.l3.weights[j][i] -= lr * d_logits[j] * h2[i]

                # Backprop to h2
                d_h2 = [0.0] * 32
                for i in range(32):
                    for j in range(NUM_ACTIONS):
                        d_h2[i] += self.l3.weights[j][i] * d_logits[j]
                    if h2_pre[i] <= 0:
                        d_h2[i] = 0.0  # ReLU derivative

                # Layer 2 gradients
                for j in range(32):
                    self.l2.biases[j] -= lr * d_h2[j]
                    for i in range(64):
                        self.l2.weights[j][i] -= lr * d_h2[j] * h1[i]

                # Backprop to h1
                d_h1 = [0.0] * 64
                for i in range(64):
                    for j in range(32):
                        d_h1[i] += self.l2.weights[j][i] * d_h2[j]
                    if h1_pre[i] <= 0:
                        d_h1[i] = 0.0

                # Layer 1 gradients
                for j in range(64):
                    self.l1.biases[j] -= lr * d_h1[j]
                    for i in range(NUM_FEATURES):
                        self.l1.weights[j][i] -= lr * d_h1[j] * x[i]

            avg_loss = total_loss / n
            final_acc = correct / n
            if avg_loss < best_loss:
                best_loss = avg_loss

        self._trained = True
        return {"loss": best_loss, "accuracy": final_acc, "epochs": epochs, "samples": n}

    def serialize(self) -> dict:
        """Serialize model weights."""
        return {
            "l1_w": self.l1.weights, "l1_b": self.l1.biases,
            "l2_w": self.l2.weights, "l2_b": self.l2.biases,
            "l3_w": self.l3.weights, "l3_b": self.l3.biases,
            "trained": self._trained,
        }

    def deserialize(self, data: dict) -> None:
        """Restore model weights."""
        self.l1.weights = data["l1_w"]
        self.l1.biases = data["l1_b"]
        self.l2.weights = data["l2_w"]
        self.l2.biases = data["l2_b"]
        self.l3.weights = data["l3_w"]
        self.l3.biases = data["l3_b"]
        self._trained = data.get("trained", False)


# ---------------------------------------------------------------------------
# Reward Model (Inverse RL — simplified MaxEnt IRL)
# ---------------------------------------------------------------------------

class _RewardModel:
    """Learns the user's implicit reward function from demonstrated actions.

    Uses maximum entropy IRL: the user's policy is optimal with respect
    to some unknown reward R(s, a). We recover R by finding weights that
    make the demonstrated feature expectations match the learned policy's
    feature expectations.

    Simplified: linear reward R(s) = w · features(s). Learn w from
    matching feature expectations.
    """

    def __init__(self):
        self.weights: list[float] = [0.0] * NUM_FEATURES
        self._trained = False

    def train(self, features_batch: list[list[float]],
              epochs: int = 100, lr: float = 0.001) -> dict[str, float]:
        """Simplified MaxEnt IRL: match feature expectations."""
        if not features_batch:
            return {"converged": False}

        n = len(features_batch)
        # Expert feature expectations
        expert_fe = [0.0] * NUM_FEATURES
        for feats in features_batch:
            for i in range(NUM_FEATURES):
                expert_fe[i] += feats[i] / n

        # Gradient ascent on log-likelihood
        for epoch in range(epochs):
            # Current policy feature expectations (uniform baseline)
            policy_fe = [0.5] * NUM_FEATURES

            # Gradient = expert_fe - policy_fe
            for i in range(NUM_FEATURES):
                self.weights[i] += lr * (expert_fe[i] - policy_fe[i])

        self._trained = True
        return {"converged": True, "epochs": epochs}

    def reward(self, features: list[float]) -> float:
        """Evaluate reward for a state."""
        return sum(w * f for w, f in zip(self.weights, features))

    def serialize(self) -> dict:
        return {"weights": list(self.weights), "trained": self._trained}

    def deserialize(self, data: dict) -> None:
        self.weights = data["weights"]
        self._trained = data.get("trained", False)


# ---------------------------------------------------------------------------
# Imprint System
# ---------------------------------------------------------------------------

class ImprintSystem:
    """User behavior learning system.

    Phase 1 (OBSERVE): Collect actions. No predictions.
    Phase 2 (SUGGEST): Train behavioral cloning MLP. Predict user actions.
    Phase 3 (SUPERVISED): Train IRL reward model. Extrapolate to novel situations.
    Phase 4+ (AUTONOMOUS): DAgger refinement from user corrections.
    """

    def __init__(self, config: HiveConfig, db: "HiveDB | None" = None):
        self._config = config
        self._db = db
        self._lock = threading.Lock()

        # Observation buffer
        self._actions: deque[ImprintAction] = deque(maxlen=10_000)
        self._actions_count = 0

        # Models
        self._bc_model = _MLP(seed=42)
        self._reward_model = _RewardModel()

        # Training state
        self._last_train_time = 0.0
        self._train_results: dict[str, Any] = {}

        # DAgger corrections
        self._corrections: deque[tuple[list[float], int]] = deque(maxlen=5000)

        # User stats for style profiling
        self._user_sharpe: float = 0.0
        self._action_type_counts: dict[str, int] = {}

    # -----------------------------------------------------------------------
    # Observation
    # -----------------------------------------------------------------------

    def observe(self, action: ImprintAction) -> None:
        """Record a user action with full market context."""
        with self._lock:
            self._actions.append(action)
            self._actions_count += 1
            self._action_type_counts[action.action_type] = (
                self._action_type_counts.get(action.action_type, 0) + 1
            )
        if self._db is not None:
            try:
                self._db.record_imprint_action(action)
            except Exception:
                pass

    @property
    def actions_observed(self) -> int:
        return self._actions_count

    @property
    def model_trained(self) -> bool:
        return self._bc_model._trained

    # -----------------------------------------------------------------------
    # Training
    # -----------------------------------------------------------------------

    def train(self, force: bool = False) -> dict[str, Any]:
        """Train both behavioral cloning and reward models."""
        now = time.time()
        interval = self._config.imprint_train_interval_hours * 3600
        if not force and (now - self._last_train_time) < interval:
            return {"skipped": True, "reason": "too_soon"}

        with self._lock:
            actions = list(self._actions)

        if len(actions) < max(20, self._config.imprint_min_actions // 5):
            return {"skipped": True, "reason": "insufficient_data",
                    "count": len(actions), "min": self._config.imprint_min_actions}

        # Prepare training data
        features_batch: list[list[float]] = []
        labels_batch: list[int] = []

        for a in actions:
            feats = _extract_features(a)
            label = _action_index(a.action_type)
            features_batch.append(feats)
            labels_batch.append(label)

        # Add DAgger corrections
        with self._lock:
            corrections = list(self._corrections)
        for feats, label in corrections:
            features_batch.append(feats)
            labels_batch.append(label)

        # Train behavioral cloning
        bc_results = self._bc_model.train(features_batch, labels_batch,
                                          epochs=50, lr=0.005)

        # Train reward model on expert demonstrations only
        expert_features = [_extract_features(a) for a in actions]
        irl_results = self._reward_model.train(expert_features,
                                               epochs=100, lr=0.001)

        self._last_train_time = now
        self._train_results = {
            "behavioral_cloning": bc_results,
            "inverse_rl": irl_results,
            "total_samples": len(features_batch),
            "corrections_used": len(corrections),
            "timestamp": now,
        }
        return self._train_results

    # -----------------------------------------------------------------------
    # Prediction
    # -----------------------------------------------------------------------

    def predict_action(self, context: ImprintAction) -> tuple[str, float]:
        """Predict what the user would do in this context.

        Returns (action_type, confidence).
        """
        if not self._bc_model._trained:
            return ("do_nothing", 0.0)
        features = _extract_features(context)
        return self._bc_model.predict_action(features)

    def evaluate_reward(self, context: ImprintAction) -> float:
        """Evaluate the user's implicit reward for a state."""
        if not self._reward_model._trained:
            return 0.0
        features = _extract_features(context)
        return self._reward_model.reward(features)

    def suggest(self, context: ImprintAction) -> dict[str, Any] | None:
        """Generate a suggestion based on the behavioral model.

        Returns dict with action_type, confidence, reasoning.
        Returns None if model not trained or confidence too low.
        """
        action, confidence = self.predict_action(context)
        if confidence < 0.3 or action == "do_nothing":
            return None

        reward = self.evaluate_reward(context)
        return {
            "action_type": action,
            "confidence": round(confidence, 4),
            "reward_score": round(reward, 4),
            "reasoning": f"Behavioral model predicts '{action}' with {confidence:.1%} "
                         f"confidence (reward={reward:.3f})",
        }

    # -----------------------------------------------------------------------
    # DAgger (Dataset Aggregation) Refinement
    # -----------------------------------------------------------------------

    def record_correction(self, context: ImprintAction,
                          correct_action: str) -> None:
        """Record a user correction for DAgger refinement.

        When the system suggests an action but the user does something
        different, record the correction to reduce distributional shift.
        """
        features = _extract_features(context)
        label = _action_index(correct_action)
        with self._lock:
            self._corrections.append((features, label))

    # -----------------------------------------------------------------------
    # User Profile
    # -----------------------------------------------------------------------

    def user_profile(self) -> dict[str, Any]:
        """Summarize what the model has learned about the user."""
        total = max(1, sum(self._action_type_counts.values()))
        action_dist = {
            k: round(v / total, 3)
            for k, v in sorted(self._action_type_counts.items(),
                               key=lambda x: -x[1])
        }

        # Infer preferences from reward model weights
        preferences = {}
        if self._reward_model._trained:
            for name, w in zip(FEATURE_NAMES, self._reward_model.weights):
                if abs(w) > 0.1:
                    preferences[name] = round(w, 4)

        return {
            "actions_observed": self._actions_count,
            "model_trained": self._bc_model._trained,
            "action_distribution": action_dist,
            "inferred_preferences": preferences,
            "user_sharpe": self._user_sharpe,
            "train_results": self._train_results,
        }

    def set_user_sharpe(self, sharpe: float) -> None:
        """Update the user's historical Sharpe for comparison."""
        self._user_sharpe = sharpe

    # -----------------------------------------------------------------------
    # Serialization
    # -----------------------------------------------------------------------

    def serialize(self) -> dict:
        """Serialize the full imprint state."""
        return {
            "bc_model": self._bc_model.serialize(),
            "reward_model": self._reward_model.serialize(),
            "actions_count": self._actions_count,
            "action_type_counts": dict(self._action_type_counts),
            "user_sharpe": self._user_sharpe,
            "train_results": self._train_results,
        }

    def deserialize(self, data: dict) -> None:
        """Restore imprint state."""
        if "bc_model" in data:
            self._bc_model.deserialize(data["bc_model"])
        if "reward_model" in data:
            self._reward_model.deserialize(data["reward_model"])
        self._actions_count = data.get("actions_count", 0)
        self._action_type_counts = data.get("action_type_counts", {})
        self._user_sharpe = data.get("user_sharpe", 0.0)
        self._train_results = data.get("train_results", {})

    # -----------------------------------------------------------------------
    # Status
    # -----------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Current imprint system status."""
        return {
            "enabled": self._config.imprint_enabled,
            "actions_observed": self._actions_count,
            "min_actions": self._config.imprint_min_actions,
            "model_trained": self._bc_model._trained,
            "reward_model_trained": self._reward_model._trained,
            "corrections_queued": len(self._corrections),
            "last_train": self._last_train_time,
            "ready_for_suggest": (self._bc_model._trained and
                                  self._actions_count >= self._config.imprint_min_actions),
        }
