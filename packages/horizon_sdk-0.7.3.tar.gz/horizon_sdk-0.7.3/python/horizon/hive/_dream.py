"""Dream State — Accelerated offline evolution during market closures.

When markets are closed, the Hive runs accelerated evolution at 100x speed
using historical data. It comes back from weekends STRONGER.
10,000 generations overnight while humans sleep.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, TYPE_CHECKING

from horizon.hive._types import HiveConfig, StrategyGenome, SpawnSource

if TYPE_CHECKING:
    from horizon.hive._evolution import EvolutionEngine
    from horizon.hive._map_elites import MAPElitesArchive
    from horizon.hive._db import HiveDB

logger = logging.getLogger("horizon.hive.dream")


@dataclass
class DreamReport:
    """Results from a dream cycle."""
    generations_run: int = 0
    best_fitness: float = 0.0
    mean_fitness: float = 0.0
    new_species_found: int = 0
    cells_illuminated: int = 0
    archive_coverage: float = 0.0
    duration_seconds: float = 0.0
    adversarial_tests_passed: int = 0
    adversarial_tests_failed: int = 0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "generations_run": self.generations_run,
            "best_fitness": round(self.best_fitness, 4),
            "mean_fitness": round(self.mean_fitness, 4),
            "new_species_found": self.new_species_found,
            "cells_illuminated": self.cells_illuminated,
            "archive_coverage": round(self.archive_coverage, 4),
            "duration_seconds": round(self.duration_seconds, 2),
            "adversarial_passed": self.adversarial_tests_passed,
            "adversarial_failed": self.adversarial_tests_failed,
        }


class DreamState:
    """Accelerated evolution during market closures.

    The Hive doesn't sleep. It dreams:
    1. Generate synthetic market scenarios from historical data
    2. Run evolutionary engine at maximum speed (no real-time constraint)
    3. Test evolved strategies against adversarial simulations
    4. Update MAP-Elites archive with new discoveries
    5. Pre-compute optimal agent roster for anticipated next regime
    """

    def __init__(self, config: HiveConfig,
                 evolution: "EvolutionEngine | None" = None,
                 archive: "MAPElitesArchive | None" = None,
                 db: "HiveDB | None" = None):
        self._config = config
        self._evolution = evolution
        self._archive = archive
        self._db = db
        self._lock = threading.Lock()

        # State
        self._dreaming = False
        self._dream_thread: threading.Thread | None = None
        self._last_report: DreamReport | None = None
        self._total_dreams = 0

        # Callbacks
        self._fitness_fn: Callable[[StrategyGenome], float] | None = None
        self._adversarial_fn: Callable[[StrategyGenome], bool] | None = None

    def set_fitness_fn(self, fn: Callable[[StrategyGenome], float]) -> None:
        """Set the fitness evaluation function for dream evolution."""
        self._fitness_fn = fn

    def set_adversarial_fn(self, fn: Callable[[StrategyGenome], bool]) -> None:
        """Set adversarial test function. Returns True if strategy survives."""
        self._adversarial_fn = fn

    # -----------------------------------------------------------------------
    # Dream Execution
    # -----------------------------------------------------------------------

    def dream(self, generations: int | None = None,
              max_duration_seconds: float = 0) -> DreamReport:
        """Run a dream cycle synchronously.

        Args:
            generations: Number of generations. Default: config.dream_generations.
            max_duration_seconds: Hard time limit. 0 = no limit.
        """
        if self._evolution is None:
            logger.warning("Dream state: no evolution engine available")
            return DreamReport()

        gens = generations or self._config.dream_generations
        start = time.monotonic()
        report = DreamReport()

        with self._lock:
            self._dreaming = True

        try:
            for gen in range(gens):
                # Time limit check
                if max_duration_seconds > 0:
                    elapsed = time.monotonic() - start
                    if elapsed >= max_duration_seconds:
                        logger.info("Dream: time limit reached at generation %d", gen)
                        break

                # Run one generation
                if self._fitness_fn is not None:
                    stats = self._evolution.run_generation(self._fitness_fn)
                else:
                    # Use evolution engine's internal evaluation
                    stats = self._evolution.run_generation(
                        lambda g: g.fitness
                    )

                report.generations_run = gen + 1
                report.best_fitness = max(report.best_fitness,
                                          stats.get("best_fitness", 0.0))
                report.mean_fitness = stats.get("mean_fitness", 0.0)

                # Migrate between islands periodically
                if gen > 0 and gen % self._config.migration_interval == 0:
                    self._evolution.migrate()

                # Update MAP-Elites archive with best genomes
                if self._archive is not None and gen % 10 == 0:
                    best = self._evolution.get_best(n=5)
                    for genome in best:
                        added = self._archive.add(genome)
                        if added:
                            report.new_species_found += 1

                # Adversarial testing every 100 generations
                if self._adversarial_fn is not None and gen % 100 == 0:
                    best = self._evolution.get_best(n=3)
                    for genome in best:
                        if self._adversarial_fn(genome):
                            report.adversarial_tests_passed += 1
                        else:
                            report.adversarial_tests_failed += 1

            # Final archive update
            if self._archive is not None:
                report.cells_illuminated = self._archive.cells_filled()
                report.archive_coverage = self._archive.coverage()

        finally:
            report.duration_seconds = time.monotonic() - start
            with self._lock:
                self._dreaming = False
                self._last_report = report
                self._total_dreams += 1

            # Persist stats
            if self._db is not None:
                try:
                    self._db.record_evolution_stats(
                        generation=self._evolution.generation,
                        stats=report.to_dict(),
                    )
                except Exception:
                    pass

            logger.info(
                "Dream complete: %d generations in %.1fs, best_fitness=%.4f, "
                "new_species=%d, coverage=%.1f%%",
                report.generations_run, report.duration_seconds,
                report.best_fitness, report.new_species_found,
                report.archive_coverage * 100,
            )

        return report

    def dream_async(self, generations: int | None = None,
                    max_duration_seconds: float = 0) -> None:
        """Start a dream cycle in a background thread."""
        if self._dreaming:
            logger.warning("Dream already in progress")
            return

        self._dream_thread = threading.Thread(
            target=self.dream,
            args=(generations, max_duration_seconds),
            daemon=True,
            name="hive-dream",
        )
        self._dream_thread.start()

    def stop_dream(self) -> None:
        """Signal the dream to stop (sets dreaming=False)."""
        with self._lock:
            self._dreaming = False

    # -----------------------------------------------------------------------
    # Pre-Position for Market Open
    # -----------------------------------------------------------------------

    def pre_position_roster(self, predicted_regime: str) -> list[StrategyGenome]:
        """Select optimal agent roster for predicted next regime.

        Uses MAP-Elites archive to pick pre-evolved strategies matching
        the predicted regime.
        """
        if self._archive is None:
            return []

        candidates = self._archive.get_best_for_regime(predicted_regime)

        # Sort by fitness, take top N (limited by config.max_agents)
        candidates.sort(key=lambda g: g.fitness, reverse=True)
        max_agents = self._config.max_agents
        return candidates[:max_agents]

    # -----------------------------------------------------------------------
    # Status
    # -----------------------------------------------------------------------

    @property
    def is_dreaming(self) -> bool:
        return self._dreaming

    def status(self) -> dict[str, Any]:
        """Current dream state status."""
        return {
            "enabled": self._config.dream_enabled,
            "dreaming": self._dreaming,
            "total_dreams": self._total_dreams,
            "last_report": self._last_report.to_dict() if self._last_report else None,
            "has_evolution_engine": self._evolution is not None,
            "has_archive": self._archive is not None,
            "has_fitness_fn": self._fitness_fn is not None,
            "has_adversarial_fn": self._adversarial_fn is not None,
        }
