"""Hive SQLite persistence layer.

Thread-safe, WAL-mode database for all Hive subsystems:
decisions, genomes, pheromones, imprint actions, internal markets,
incidents, reputation, and evolution statistics.
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
import uuid

from horizon.hive._types import (
    HiveDecision,
    ImprintAction,
    Incident,
    InternalMarket,
    StrategyGenome,
)

logger = logging.getLogger("horizon.hive.db")


class HiveDB:
    """SQLite persistence for the Hive swarm.

    All writes are serialized through a threading.Lock.
    The database runs in WAL mode for concurrent read access.
    Every query uses parameterized statements — no string interpolation.
    """

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    _SCHEMA = """\
    CREATE TABLE IF NOT EXISTS hive_decisions (
        decision_id    TEXT PRIMARY KEY,
        timestamp      REAL NOT NULL,
        decision_type  TEXT NOT NULL,
        action_taken   TEXT NOT NULL DEFAULT '',
        reasoning      TEXT NOT NULL DEFAULT '',
        confidence     REAL NOT NULL DEFAULT 0.0,
        regime         TEXT NOT NULL DEFAULT '',
        pheromone_snapshot  TEXT NOT NULL DEFAULT '{}',
        knowledge_context   TEXT NOT NULL DEFAULT '[]',
        criticality_state   TEXT NOT NULL DEFAULT '{}',
        autonomy_mode       TEXT NOT NULL DEFAULT 'observe',
        user_approved       INTEGER,
        outcome             TEXT,
        outcome_timestamp   REAL,
        was_correct         INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_decision_ts   ON hive_decisions(timestamp);
    CREATE INDEX IF NOT EXISTS idx_decision_type ON hive_decisions(decision_type);

    CREATE TABLE IF NOT EXISTS agent_genomes (
        genome_id        TEXT PRIMARY KEY,
        source           TEXT NOT NULL DEFAULT 'template',
        archetype        TEXT,
        generation       INTEGER NOT NULL DEFAULT 0,
        lineage          TEXT NOT NULL DEFAULT '[]',
        gp_tree          TEXT,
        hyperparams      TEXT NOT NULL DEFAULT '{}',
        fitness          REAL NOT NULL DEFAULT 0.0,
        sharpe           REAL NOT NULL DEFAULT 0.0,
        max_drawdown     REAL NOT NULL DEFAULT 0.0,
        holding_period   REAL NOT NULL DEFAULT 0.0,
        directional_bias REAL NOT NULL DEFAULT 0.0,
        volatility_pref  REAL NOT NULL DEFAULT 0.5,
        asset_focus      TEXT NOT NULL DEFAULT 'cross',
        target_markets   TEXT NOT NULL DEFAULT '[]',
        archived_at      REAL NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_genome_source  ON agent_genomes(source);
    CREATE INDEX IF NOT EXISTS idx_genome_fitness ON agent_genomes(fitness);

    CREATE TABLE IF NOT EXISTS pheromone_snapshots (
        snapshot_id TEXT PRIMARY KEY,
        timestamp   REAL NOT NULL,
        field_data  TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_phero_ts ON pheromone_snapshots(timestamp);

    CREATE TABLE IF NOT EXISTS imprint_actions (
        action_id     INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp     REAL NOT NULL,
        action_type   TEXT NOT NULL,
        action_params TEXT NOT NULL DEFAULT '{}',
        context       TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_imprint_ts ON imprint_actions(timestamp);

    CREATE TABLE IF NOT EXISTS internal_markets (
        market_id   TEXT PRIMARY KEY,
        question    TEXT NOT NULL DEFAULT '',
        deadline    REAL NOT NULL DEFAULT 0.0,
        views       TEXT NOT NULL DEFAULT '{}',
        resolved    INTEGER NOT NULL DEFAULT 0,
        outcome     INTEGER,
        created_at  REAL NOT NULL,
        resolved_at REAL
    );

    CREATE TABLE IF NOT EXISTS incidents (
        incident_id     TEXT PRIMARY KEY,
        severity        INTEGER NOT NULL DEFAULT 4,
        trigger         TEXT NOT NULL DEFAULT '',
        affected_agents TEXT NOT NULL DEFAULT '[]',
        state           TEXT NOT NULL DEFAULT 'detected',
        timeline        TEXT NOT NULL DEFAULT '[]',
        root_cause      TEXT,
        pnl_impact      REAL NOT NULL DEFAULT 0.0,
        created_at      REAL NOT NULL,
        resolved_at     REAL
    );
    CREATE INDEX IF NOT EXISTS idx_incident_severity ON incidents(severity);
    CREATE INDEX IF NOT EXISTS idx_incident_state    ON incidents(state);

    CREATE TABLE IF NOT EXISTS reputation_history (
        agent_id   TEXT NOT NULL,
        timestamp  REAL NOT NULL,
        score      REAL NOT NULL,
        confidence REAL NOT NULL DEFAULT 0.0,
        outcome    REAL NOT NULL DEFAULT 0.0
    );
    CREATE INDEX IF NOT EXISTS idx_rep_agent ON reputation_history(agent_id);
    CREATE INDEX IF NOT EXISTS idx_rep_ts    ON reputation_history(timestamp);

    CREATE TABLE IF NOT EXISTS evolution_stats (
        generation   INTEGER PRIMARY KEY,
        timestamp    REAL NOT NULL,
        best_fitness REAL NOT NULL DEFAULT 0.0,
        mean_fitness REAL NOT NULL DEFAULT 0.0,
        diversity    REAL NOT NULL DEFAULT 0.0,
        cells_filled INTEGER NOT NULL DEFAULT 0,
        stats        TEXT NOT NULL DEFAULT '{}'
    );
    """

    # ------------------------------------------------------------------
    # Init / teardown
    # ------------------------------------------------------------------

    def __init__(self, db_path: str = "hive.db") -> None:
        self._db_path = db_path
        db_dir = os.path.dirname(os.path.abspath(db_path))
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)

        self._lock = threading.Lock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript(self._SCHEMA)
        self._conn.commit()
        logger.debug("HiveDB initialized at %s", db_path)

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()
        logger.debug("HiveDB closed")

    # ------------------------------------------------------------------
    # Decisions
    # ------------------------------------------------------------------

    def record_decision(self, decision: HiveDecision) -> None:
        """Persist an auditable Hive decision."""
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO hive_decisions
                   (decision_id, timestamp, decision_type, action_taken,
                    reasoning, confidence, regime, pheromone_snapshot,
                    knowledge_context, criticality_state, autonomy_mode,
                    user_approved, outcome, outcome_timestamp, was_correct)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    decision.decision_id,
                    decision.timestamp,
                    decision.decision_type.value
                    if hasattr(decision.decision_type, "value")
                    else str(decision.decision_type),
                    decision.action_taken,
                    decision.reasoning,
                    decision.confidence,
                    decision.regime,
                    json.dumps(decision.pheromone_snapshot),
                    json.dumps(decision.knowledge_context),
                    json.dumps(decision.criticality_state),
                    decision.autonomy_mode.value
                    if hasattr(decision.autonomy_mode, "value")
                    else str(decision.autonomy_mode),
                    _bool_to_int(decision.user_approved),
                    decision.outcome,
                    decision.outcome_timestamp,
                    _bool_to_int(decision.was_correct),
                ),
            )
            self._conn.commit()

    def query_decisions(
        self,
        decision_type: str | None = None,
        since: float | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """Query decision records with optional filters.

        Args:
            decision_type: Filter by decision type value (e.g. "spawn_agent").
            since: Only return decisions after this Unix timestamp.
            limit: Maximum number of results (capped at 10 000).

        Returns:
            List of decision dicts, most recent first.
        """
        limit = max(1, min(limit, 10_000))
        clauses: list[str] = []
        params: list[object] = []
        if decision_type is not None:
            clauses.append("decision_type = ?")
            params.append(str(decision_type))
        if since is not None:
            clauses.append("timestamp >= ?")
            params.append(float(since))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT * FROM hive_decisions {where} ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [_decision_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Genomes
    # ------------------------------------------------------------------

    def archive_genome(self, genome: StrategyGenome) -> None:
        """Archive a strategy genome snapshot."""
        now = time.time()
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO agent_genomes
                   (genome_id, source, archetype, generation, lineage,
                    gp_tree, hyperparams, fitness, sharpe, max_drawdown,
                    holding_period, directional_bias, volatility_pref,
                    asset_focus, target_markets, archived_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    genome.genome_id,
                    genome.source.value
                    if hasattr(genome.source, "value")
                    else str(genome.source),
                    genome.archetype.value
                    if genome.archetype and hasattr(genome.archetype, "value")
                    else (str(genome.archetype) if genome.archetype else None),
                    genome.generation,
                    json.dumps(genome.lineage),
                    json.dumps(genome.gp_tree) if genome.gp_tree else None,
                    json.dumps(genome.hyperparams),
                    genome.fitness,
                    genome.sharpe,
                    genome.max_drawdown,
                    genome.holding_period,
                    genome.directional_bias,
                    genome.volatility_pref,
                    genome.asset_focus,
                    json.dumps(genome.target_markets),
                    now,
                ),
            )
            self._conn.commit()

    def load_genome(self, genome_id: str) -> dict | None:
        """Load a single genome by ID, or None if not found."""
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM agent_genomes WHERE genome_id = ?",
                (str(genome_id),),
            ).fetchone()
        if row is None:
            return None
        return _genome_row_to_dict(row)

    def load_genomes(
        self,
        source: str | None = None,
        min_fitness: float | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """Load archived genomes with optional filters.

        Args:
            source: Filter by spawn source value (e.g. "evolution").
            min_fitness: Minimum fitness threshold.
            limit: Maximum results (capped at 10 000).

        Returns:
            List of genome dicts, highest fitness first.
        """
        limit = max(1, min(limit, 10_000))
        clauses: list[str] = []
        params: list[object] = []
        if source is not None:
            clauses.append("source = ?")
            params.append(str(source))
        if min_fitness is not None:
            clauses.append("fitness >= ?")
            params.append(float(min_fitness))
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        sql = f"SELECT * FROM agent_genomes {where} ORDER BY fitness DESC LIMIT ?"
        params.append(limit)

        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [_genome_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Pheromone snapshots
    # ------------------------------------------------------------------

    def snapshot_pheromones(self, field_data: dict) -> None:
        """Persist a pheromone field snapshot for replay."""
        snapshot_id = uuid.uuid4().hex[:16]
        now = time.time()
        with self._lock:
            self._conn.execute(
                "INSERT INTO pheromone_snapshots (snapshot_id, timestamp, field_data) VALUES (?,?,?)",
                (snapshot_id, now, json.dumps(field_data)),
            )
            self._conn.commit()

    def load_pheromone_snapshot(self, before: float | None = None) -> dict | None:
        """Load the most recent pheromone snapshot, optionally before a timestamp.

        Returns:
            Dict with snapshot_id, timestamp, and field_data, or None.
        """
        if before is not None:
            sql = "SELECT * FROM pheromone_snapshots WHERE timestamp <= ? ORDER BY timestamp DESC LIMIT 1"
            params: tuple = (float(before),)
        else:
            sql = "SELECT * FROM pheromone_snapshots ORDER BY timestamp DESC LIMIT 1"
            params = ()

        with self._lock:
            row = self._conn.execute(sql, params).fetchone()
        if row is None:
            return None
        return {
            "snapshot_id": row[0],
            "timestamp": row[1],
            "field_data": json.loads(row[2]),
        }

    # ------------------------------------------------------------------
    # Imprint actions
    # ------------------------------------------------------------------

    def record_imprint_action(self, action: ImprintAction) -> None:
        """Record a user action for behavioral modeling."""
        context = {
            "feed_snapshots": action.feed_snapshots,
            "positions": action.positions,
            "pnl": action.pnl,
            "regime": action.regime,
            "pheromone_state": action.pheromone_state,
            "volatility": action.volatility,
            "time_of_day": action.time_of_day,
            "day_of_week": action.day_of_week,
        }
        with self._lock:
            self._conn.execute(
                """INSERT INTO imprint_actions
                   (timestamp, action_type, action_params, context)
                   VALUES (?,?,?,?)""",
                (
                    action.timestamp,
                    action.action_type,
                    json.dumps(action.action_params),
                    json.dumps(context),
                ),
            )
            self._conn.commit()

    def load_imprint_actions(
        self, since: float | None = None, limit: int = 1000
    ) -> list[dict]:
        """Load imprint actions, optionally filtered by time.

        Args:
            since: Only return actions after this Unix timestamp.
            limit: Maximum results (capped at 50 000).

        Returns:
            List of action dicts, most recent first.
        """
        limit = max(1, min(limit, 50_000))
        if since is not None:
            sql = "SELECT * FROM imprint_actions WHERE timestamp >= ? ORDER BY timestamp DESC LIMIT ?"
            params: tuple = (float(since), limit)
        else:
            sql = "SELECT * FROM imprint_actions ORDER BY timestamp DESC LIMIT ?"
            params = (limit,)

        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [
            {
                "action_id": r[0],
                "timestamp": r[1],
                "action_type": r[2],
                "action_params": json.loads(r[3]),
                "context": json.loads(r[4]),
            }
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Internal markets
    # ------------------------------------------------------------------

    def save_internal_market(self, market: InternalMarket) -> None:
        """Persist an internal prediction market."""
        views_dict = {}
        for agent_id, view in market.views.items():
            views_dict[agent_id] = {
                "agent_id": view.agent_id,
                "probability": view.probability,
                "confidence": view.confidence,
                "stake": view.stake,
            }

        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO internal_markets
                   (market_id, question, deadline, views, resolved,
                    outcome, created_at, resolved_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (
                    market.market_id,
                    market.question,
                    market.deadline,
                    json.dumps(views_dict),
                    1 if market.resolved else 0,
                    _bool_to_int(market.outcome),
                    market.created_at,
                    None,  # resolved_at set via update
                ),
            )
            self._conn.commit()

    def load_internal_market(self, market_id: str) -> dict | None:
        """Load an internal market by ID, or None if not found."""
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM internal_markets WHERE market_id = ?",
                (str(market_id),),
            ).fetchone()
        if row is None:
            return None
        return {
            "market_id": row[0],
            "question": row[1],
            "deadline": row[2],
            "views": json.loads(row[3]),
            "resolved": bool(row[4]),
            "outcome": _int_to_bool(row[5]),
            "created_at": row[6],
            "resolved_at": row[7],
        }

    # ------------------------------------------------------------------
    # Incidents
    # ------------------------------------------------------------------

    def record_incident(self, incident: Incident) -> None:
        """Record a kill-chain incident."""
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO incidents
                   (incident_id, severity, trigger, affected_agents,
                    state, timeline, root_cause, pnl_impact,
                    created_at, resolved_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    incident.incident_id,
                    int(incident.severity),
                    incident.trigger,
                    json.dumps(incident.affected_agents),
                    incident.state,
                    json.dumps(incident.timeline),
                    incident.root_cause,
                    incident.pnl_impact,
                    incident.created_at,
                    incident.resolved_at,
                ),
            )
            self._conn.commit()

    def update_incident(self, incident_id: str, **kwargs: object) -> None:
        """Update mutable fields on an incident.

        Allowed fields: state, root_cause, pnl_impact, resolved_at,
        timeline, affected_agents.

        Raises:
            ValueError: If an unknown field is passed.
        """
        _ALLOWED = {
            "state": str,
            "root_cause": str,
            "pnl_impact": float,
            "resolved_at": float,
            "timeline": list,
            "affected_agents": list,
        }
        sets: list[str] = []
        params: list[object] = []
        for key, value in kwargs.items():
            if key not in _ALLOWED:
                raise ValueError(
                    f"Cannot update field '{key}' on incident. "
                    f"Allowed: {sorted(_ALLOWED)}"
                )
            if isinstance(value, (list, dict)):
                params.append(json.dumps(value))
            else:
                params.append(value)
            sets.append(f"{key} = ?")

        if not sets:
            return

        params.append(str(incident_id))
        sql = f"UPDATE incidents SET {', '.join(sets)} WHERE incident_id = ?"

        with self._lock:
            self._conn.execute(sql, params)
            self._conn.commit()

    # ------------------------------------------------------------------
    # Reputation
    # ------------------------------------------------------------------

    def record_reputation(
        self,
        agent_id: str,
        score: float,
        confidence: float,
        outcome: float,
    ) -> None:
        """Append a reputation data point for an agent."""
        now = time.time()
        with self._lock:
            self._conn.execute(
                """INSERT INTO reputation_history
                   (agent_id, timestamp, score, confidence, outcome)
                   VALUES (?,?,?,?,?)""",
                (str(agent_id), now, float(score), float(confidence), float(outcome)),
            )
            self._conn.commit()

    def load_reputation_history(
        self, agent_id: str, limit: int = 100
    ) -> list[dict]:
        """Load reputation history for an agent, most recent first.

        Args:
            agent_id: The agent identifier.
            limit: Maximum results (capped at 10 000).

        Returns:
            List of reputation snapshot dicts.
        """
        limit = max(1, min(limit, 10_000))
        with self._lock:
            rows = self._conn.execute(
                """SELECT agent_id, timestamp, score, confidence, outcome
                   FROM reputation_history
                   WHERE agent_id = ?
                   ORDER BY timestamp DESC LIMIT ?""",
                (str(agent_id), limit),
            ).fetchall()
        return [
            {
                "agent_id": r[0],
                "timestamp": r[1],
                "score": r[2],
                "confidence": r[3],
                "outcome": r[4],
            }
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Evolution stats
    # ------------------------------------------------------------------

    def record_evolution_stats(self, generation: int, stats: dict) -> None:
        """Record statistics for a completed evolutionary generation.

        The *stats* dict should contain at least best_fitness,
        mean_fitness, diversity, and cells_filled.  Any extra keys
        are preserved in the `stats` JSON column.
        """
        now = time.time()
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO evolution_stats
                   (generation, timestamp, best_fitness, mean_fitness,
                    diversity, cells_filled, stats)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    int(generation),
                    now,
                    float(stats.get("best_fitness", 0.0)),
                    float(stats.get("mean_fitness", 0.0)),
                    float(stats.get("diversity", 0.0)),
                    int(stats.get("cells_filled", 0)),
                    json.dumps(stats),
                ),
            )
            self._conn.commit()

    def load_evolution_stats(self, limit: int = 100) -> list[dict]:
        """Load evolution statistics, most recent generation first.

        Args:
            limit: Maximum results (capped at 10 000).

        Returns:
            List of per-generation stats dicts.
        """
        limit = max(1, min(limit, 10_000))
        with self._lock:
            rows = self._conn.execute(
                """SELECT generation, timestamp, best_fitness, mean_fitness,
                          diversity, cells_filled, stats
                   FROM evolution_stats
                   ORDER BY generation DESC LIMIT ?""",
                (limit,),
            ).fetchall()
        return [
            {
                "generation": r[0],
                "timestamp": r[1],
                "best_fitness": r[2],
                "mean_fitness": r[3],
                "diversity": r[4],
                "cells_filled": r[5],
                "stats": json.loads(r[6]),
            }
            for r in rows
        ]


# ======================================================================
# Private helpers
# ======================================================================


def _bool_to_int(val: bool | None) -> int | None:
    """Convert Python bool/None to SQLite INTEGER (1/0/NULL)."""
    if val is None:
        return None
    return 1 if val else 0


def _int_to_bool(val: int | None) -> bool | None:
    """Convert SQLite INTEGER (1/0/NULL) to Python bool/None."""
    if val is None:
        return None
    return bool(val)


def _decision_row_to_dict(row: tuple) -> dict:
    """Map a hive_decisions row tuple to a dict."""
    return {
        "decision_id": row[0],
        "timestamp": row[1],
        "decision_type": row[2],
        "action_taken": row[3],
        "reasoning": row[4],
        "confidence": row[5],
        "regime": row[6],
        "pheromone_snapshot": json.loads(row[7]) if row[7] else {},
        "knowledge_context": json.loads(row[8]) if row[8] else [],
        "criticality_state": json.loads(row[9]) if row[9] else {},
        "autonomy_mode": row[10],
        "user_approved": _int_to_bool(row[11]),
        "outcome": row[12],
        "outcome_timestamp": row[13],
        "was_correct": _int_to_bool(row[14]),
    }


def _genome_row_to_dict(row: tuple) -> dict:
    """Map an agent_genomes row tuple to a dict."""
    return {
        "genome_id": row[0],
        "source": row[1],
        "archetype": row[2],
        "generation": row[3],
        "lineage": json.loads(row[4]) if row[4] else [],
        "gp_tree": json.loads(row[5]) if row[5] else None,
        "hyperparams": json.loads(row[6]) if row[6] else {},
        "fitness": row[7],
        "sharpe": row[8],
        "max_drawdown": row[9],
        "holding_period": row[10],
        "directional_bias": row[11],
        "volatility_pref": row[12],
        "asset_focus": row[13],
        "target_markets": json.loads(row[14]) if row[14] else [],
        "archived_at": row[15],
    }
