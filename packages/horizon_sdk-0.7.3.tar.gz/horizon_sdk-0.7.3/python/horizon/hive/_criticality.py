"""15-indicator criticality monitoring with avalanche reserves.

Detects when markets approach critical phase transitions by tracking
correlation convergence, volatility regime shifts, information flow
anomalies, microstructure deterioration, and changepoint signals.
When multiple indicators trigger simultaneously, the Hive enters
defensive mode and can deploy avalanche reserves.

Computation is delegated to Rust (via PyO3) where available, with
pure-Python fallbacks for every indicator so the module works in
any environment.

Thread-safe: all mutable state is behind a single lock.
"""

from __future__ import annotations

import logging
import math
import threading
import time
from collections import deque
from typing import Sequence

from horizon.hive._types import CriticalityReport, HiveConfig

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Rust accelerated helpers — fall back to pure Python
# ---------------------------------------------------------------------------

_rust_hurst = None
_rust_entropy = None
_rust_transfer_entropy = None
_rust_ewma_vol = None

try:
    from horizon import hurst_exponent as _rust_hurst  # type: ignore[import]
except (ImportError, AttributeError):
    pass

try:
    from horizon import shannon_entropy as _rust_entropy  # type: ignore[import]
except (ImportError, AttributeError):
    pass

try:
    from horizon import transfer_entropy as _rust_transfer_entropy  # type: ignore[import]
except (ImportError, AttributeError):
    pass

try:
    from horizon import ewma_vol as _rust_ewma_vol  # type: ignore[import]
except (ImportError, AttributeError):
    pass


# ---------------------------------------------------------------------------
# Pure-Python fallbacks
# ---------------------------------------------------------------------------

_LOG2 = math.log(2.0)
_MIN_SERIES = 20  # Minimum observations for meaningful estimation


def _py_hurst_exponent(prices: Sequence[float]) -> float:
    """Rescaled-range (R/S) Hurst exponent estimate.

    Returns 0.5 (random walk) for degenerate inputs.
    """
    n = len(prices)
    if n < _MIN_SERIES:
        return 0.5

    # Convert to log-returns
    returns: list[float] = []
    for i in range(1, n):
        if prices[i - 1] <= 0.0 or prices[i] <= 0.0:
            continue
        returns.append(math.log(prices[i] / prices[i - 1]))

    m = len(returns)
    if m < _MIN_SERIES:
        return 0.5

    # Compute R/S at multiple sub-series lengths
    rs_log: list[tuple[float, float]] = []
    for chunk_size in (m // 8, m // 4, m // 2, m):
        if chunk_size < 10:
            continue
        n_chunks = m // chunk_size
        if n_chunks < 1:
            continue

        rs_values: list[float] = []
        for c in range(n_chunks):
            start = c * chunk_size
            chunk = returns[start : start + chunk_size]
            mean_r = sum(chunk) / len(chunk)
            deviations = [r - mean_r for r in chunk]
            cumulative = []
            s = 0.0
            for d in deviations:
                s += d
                cumulative.append(s)
            range_val = max(cumulative) - min(cumulative)
            std_val = math.sqrt(
                sum((r - mean_r) ** 2 for r in chunk) / len(chunk)
            )
            if std_val > 1e-15:
                rs_values.append(range_val / std_val)

        if rs_values:
            avg_rs = sum(rs_values) / len(rs_values)
            if avg_rs > 0.0:
                rs_log.append((math.log(chunk_size), math.log(avg_rs)))

    if len(rs_log) < 2:
        return 0.5

    # OLS regression: log(R/S) = H * log(n) + c
    n_pts = len(rs_log)
    sum_x = sum(p[0] for p in rs_log)
    sum_y = sum(p[1] for p in rs_log)
    sum_xy = sum(p[0] * p[1] for p in rs_log)
    sum_x2 = sum(p[0] ** 2 for p in rs_log)

    denom = n_pts * sum_x2 - sum_x ** 2
    if abs(denom) < 1e-15:
        return 0.5

    hurst = (n_pts * sum_xy - sum_x * sum_y) / denom
    return max(0.0, min(1.0, hurst))


def _py_shannon_entropy(probs: Sequence[float]) -> float:
    """Shannon entropy in bits.

    Expects a probability distribution (non-negative, sums ~1).
    Ignores zero or negative entries.
    """
    total = 0.0
    for p in probs:
        if p > 0.0:
            total -= p * math.log2(p)
    return total


def _py_transfer_entropy(
    source: Sequence[float],
    target: Sequence[float],
    lag: int = 1,
    bins: int = 5,
) -> float:
    """Simplified transfer entropy estimate via binned histograms.

    Returns 0.0 for degenerate inputs.
    """
    n = min(len(source), len(target))
    if n < lag + _MIN_SERIES:
        return 0.0

    def _bin_series(series: Sequence[float], num_bins: int) -> list[int]:
        """Discretize a series into integer bin labels."""
        valid = [v for v in series if math.isfinite(v)]
        if not valid:
            return [0] * len(series)
        lo, hi = min(valid), max(valid)
        spread = hi - lo
        if spread < 1e-15:
            return [0] * len(series)
        result = []
        for v in series:
            if not math.isfinite(v):
                result.append(0)
            else:
                b = int((v - lo) / spread * (num_bins - 1))
                result.append(max(0, min(num_bins - 1, b)))
        return result

    s_binned = _bin_series(source[:n], bins)
    t_binned = _bin_series(target[:n], bins)

    # Count joint and marginal frequencies
    # TE = sum p(t_future, t_past, s_past) * log2(p(t_future|t_past,s_past) / p(t_future|t_past))
    joint_3: dict[tuple[int, int, int], int] = {}
    joint_2_ts: dict[tuple[int, int], int] = {}
    joint_2_tt: dict[tuple[int, int], int] = {}
    marginal_t: dict[int, int] = {}

    count = 0
    for i in range(lag, n):
        t_future = t_binned[i]
        t_past = t_binned[i - lag]
        s_past = s_binned[i - lag]

        key3 = (t_future, t_past, s_past)
        joint_3[key3] = joint_3.get(key3, 0) + 1

        key_ts = (t_past, s_past)
        joint_2_ts[key_ts] = joint_2_ts.get(key_ts, 0) + 1

        key_tt = (t_future, t_past)
        joint_2_tt[key_tt] = joint_2_tt.get(key_tt, 0) + 1

        marginal_t[t_past] = marginal_t.get(t_past, 0) + 1

        count += 1

    if count == 0:
        return 0.0

    te = 0.0
    inv_count = 1.0 / count
    for (tf, tp, sp), n3 in joint_3.items():
        p_joint = n3 * inv_count
        p_ts = joint_2_ts.get((tp, sp), 0) * inv_count
        p_tt = joint_2_tt.get((tf, tp), 0) * inv_count
        p_t = marginal_t.get(tp, 0) * inv_count

        if p_ts > 0.0 and p_tt > 0.0 and p_t > 0.0:
            # p(tf|tp,sp) = p(tf,tp,sp) / p(tp,sp)
            # p(tf|tp)    = p(tf,tp) / p(tp)
            cond_full = p_joint / p_ts
            cond_reduced = p_tt / p_t
            if cond_full > 0.0 and cond_reduced > 0.0:
                te += p_joint * math.log2(cond_full / cond_reduced)

    return max(0.0, te)


def _py_ewma_vol(returns: Sequence[float], lam: float = 0.94) -> float:
    """Exponentially weighted moving average volatility.

    Returns annualized volatility (assuming 252 trading days).
    Returns 0.0 for empty input.
    """
    if not returns:
        return 0.0
    var = 0.0
    for r in returns:
        if not math.isfinite(r):
            continue
        var = lam * var + (1.0 - lam) * r * r
    return math.sqrt(var * 252.0)


# ---------------------------------------------------------------------------
# Dispatch helpers (Rust-first, Python fallback)
# ---------------------------------------------------------------------------

def _hurst(prices: Sequence[float]) -> float:
    if _rust_hurst is not None:
        try:
            return float(_rust_hurst(list(prices)))
        except Exception:
            pass
    return _py_hurst_exponent(prices)


def _entropy(probs: Sequence[float]) -> float:
    if _rust_entropy is not None:
        try:
            return float(_rust_entropy(list(probs)))
        except Exception:
            pass
    return _py_shannon_entropy(probs)


def _transfer_ent(
    source: Sequence[float],
    target: Sequence[float],
    lag: int = 1,
    bins: int = 5,
) -> float:
    if _rust_transfer_entropy is not None:
        try:
            return float(
                _rust_transfer_entropy(list(source), list(target), lag, bins)
            )
        except Exception:
            pass
    return _py_transfer_entropy(source, target, lag, bins)


def _ewma(returns: Sequence[float], lam: float = 0.94) -> float:
    if _rust_ewma_vol is not None:
        try:
            return float(_rust_ewma_vol(list(returns), lam))
        except Exception:
            pass
    return _py_ewma_vol(returns, lam)


# ---------------------------------------------------------------------------
# Linear algebra helpers (pure Python — no numpy dependency)
# ---------------------------------------------------------------------------

def _correlation_matrix(
    returns_matrix: list[list[float]],
) -> list[list[float]] | None:
    """Compute correlation matrix from a returns matrix (assets x observations).

    Returns None if the matrix is degenerate.
    """
    n_assets = len(returns_matrix)
    if n_assets < 2:
        return None

    # Validate lengths
    min_len = min(len(row) for row in returns_matrix)
    if min_len < 2:
        return None

    # Truncate to common length
    m = min_len

    # Means and stddevs
    means: list[float] = []
    stds: list[float] = []
    for row in returns_matrix:
        obs = row[:m]
        mu = sum(obs) / m
        means.append(mu)
        var = sum((x - mu) ** 2 for x in obs) / m
        stds.append(math.sqrt(var) if var > 0.0 else 0.0)

    # Correlation matrix
    corr: list[list[float]] = [[0.0] * n_assets for _ in range(n_assets)]
    for i in range(n_assets):
        corr[i][i] = 1.0
        if stds[i] < 1e-15:
            continue
        for j in range(i + 1, n_assets):
            if stds[j] < 1e-15:
                continue
            cov = sum(
                (returns_matrix[i][k] - means[i])
                * (returns_matrix[j][k] - means[j])
                for k in range(m)
            ) / m
            rho = cov / (stds[i] * stds[j])
            rho = max(-1.0, min(1.0, rho))
            corr[i][j] = rho
            corr[j][i] = rho

    return corr


def _avg_pairwise_correlation(corr: list[list[float]]) -> float:
    """Average off-diagonal absolute correlation."""
    n = len(corr)
    if n < 2:
        return 0.0
    total = 0.0
    count = 0
    for i in range(n):
        for j in range(i + 1, n):
            total += abs(corr[i][j])
            count += 1
    return total / count if count > 0 else 0.0


def _max_eigenvalue_ratio(corr: list[list[float]], iterations: int = 100) -> float:
    """Estimate largest eigenvalue / trace via power iteration.

    Returns the ratio of the largest eigenvalue to the sum of all
    eigenvalues (trace of correlation matrix = number of assets).
    """
    n = len(corr)
    if n < 2:
        return 0.0

    trace = float(n)  # Diagonal of correlation matrix is all 1s

    # Power iteration for dominant eigenvalue
    v = [1.0 / math.sqrt(n)] * n
    eigenvalue = 0.0

    for _ in range(iterations):
        # Matrix-vector multiply
        w = [0.0] * n
        for i in range(n):
            s = 0.0
            for j in range(n):
                s += corr[i][j] * v[j]
            w[i] = s

        # Compute norm
        norm = math.sqrt(sum(x * x for x in w))
        if norm < 1e-15:
            return 0.0

        eigenvalue = norm
        v = [x / norm for x in w]

    if trace < 1e-15:
        return 0.0

    return eigenvalue / trace


# ---------------------------------------------------------------------------
# Spread history config
# ---------------------------------------------------------------------------

_SPREAD_HISTORY_MAXLEN = 120  # ~2 hours at 1-minute checks


# ---------------------------------------------------------------------------
# CriticalityMonitor
# ---------------------------------------------------------------------------

class CriticalityMonitor:
    """Detects when markets approach critical states.

    15 indicators across 5 categories: correlation, volatility,
    information flow, microstructure, changepoint. When multiple
    indicators trigger simultaneously, the Hive enters defensive mode.

    Thread-safe. All Rust functions have pure-Python fallbacks.
    """

    __slots__ = (
        "_config",
        "_lock",
        "_prev_report",
        "_spread_history",
        "_prev_avg_correlation",
        "_avalanche_reserve",
    )

    def __init__(self, config: HiveConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._prev_report: CriticalityReport | None = None
        self._spread_history: deque[float] = deque(maxlen=_SPREAD_HISTORY_MAXLEN)
        self._prev_avg_correlation: float | None = None
        # Reserve capital for avalanche deployment
        self._avalanche_reserve: float = (
            config.total_capital * config.avalanche_reserve_pct
        )

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def compute_report(
        self,
        price_series: dict[str, list[float]],
        volume_series: dict[str, list[float]] | None = None,
        returns_matrix: list[list[float]] | None = None,
        feed_spreads: dict[str, float] | None = None,
        *,
        vpin_aggregate: float = 0.0,
        bocpd_probability: float = 0.0,
        vine_tail_risk: float = 0.0,
    ) -> CriticalityReport:
        """Compute all 15 criticality indicators.

        Parameters
        ----------
        price_series:
            ``{market_id: [price, ...]}`` — recent price history per market.
        volume_series:
            ``{market_id: [volume, ...]}`` — matching volume history. Optional.
        returns_matrix:
            ``[[r1_t0, r1_t1, ...], [r2_t0, ...], ...]`` — returns per asset
            (assets x observations). Used for correlation indicators. Optional.
        feed_spreads:
            ``{market_id: spread}`` — current bid-ask spreads. Optional.
        vpin_aggregate:
            Pre-computed VPIN aggregate (from execution intelligence). Default 0.
        bocpd_probability:
            Pre-computed BOCPD changepoint probability. Default 0.
        vine_tail_risk:
            Pre-computed vine copula tail risk. Default 0.
        """
        with self._lock:
            return self._compute_locked(
                price_series=price_series,
                volume_series=volume_series or {},
                returns_matrix=returns_matrix,
                feed_spreads=feed_spreads or {},
                vpin_aggregate=vpin_aggregate,
                bocpd_probability=bocpd_probability,
                vine_tail_risk=vine_tail_risk,
            )

    def _compute_locked(
        self,
        price_series: dict[str, list[float]],
        volume_series: dict[str, list[float]],
        returns_matrix: list[list[float]] | None,
        feed_spreads: dict[str, float],
        vpin_aggregate: float,
        bocpd_probability: float,
        vine_tail_risk: float,
    ) -> CriticalityReport:
        report = CriticalityReport()

        # ---- Category 1: Correlation (3 indicators) ---------------------

        corr_matrix: list[list[float]] | None = None
        if returns_matrix is not None and len(returns_matrix) >= 2:
            corr_matrix = _correlation_matrix(returns_matrix)

        if corr_matrix is not None:
            report.correlation_convergence = _avg_pairwise_correlation(corr_matrix)
            report.contagion_score = _max_eigenvalue_ratio(corr_matrix)
        else:
            report.correlation_convergence = 0.0
            report.contagion_score = 0.0

        # Regime shift: large change in average pairwise correlation
        if self._prev_avg_correlation is not None:
            delta = abs(
                report.correlation_convergence - self._prev_avg_correlation
            )
            report.regime_shift_detected = delta > 0.3
        else:
            report.regime_shift_detected = False
        self._prev_avg_correlation = report.correlation_convergence

        # ---- Category 2: Volatility (3 indicators) ----------------------

        # 2a. Hurst exponent — average across all price series
        hurst_values: list[float] = []
        for prices in price_series.values():
            if len(prices) >= _MIN_SERIES:
                hurst_values.append(_hurst(prices))
        report.hurst_exponent = (
            sum(hurst_values) / len(hurst_values)
            if hurst_values
            else 0.5
        )

        # 2b. Volatility signature noise — std of realized vol at different
        #     sampling frequencies (1, 2, 5, 10, 20 tick intervals)
        vol_readings = self._vol_signature(price_series)
        if len(vol_readings) >= 2:
            mean_v = sum(vol_readings) / len(vol_readings)
            report.vol_signature_noise = math.sqrt(
                sum((v - mean_v) ** 2 for v in vol_readings) / len(vol_readings)
            )
        else:
            report.vol_signature_noise = 0.0

        # 2c. Two-scale vol ratio — high-freq / low-freq realized vol
        report.two_scale_vol_ratio = self._two_scale_ratio(price_series)

        # ---- Category 3: Information flow (3 indicators) ----------------

        # 3a. Market entropy — average Shannon entropy of return bins
        report.market_entropy = self._market_entropy(price_series)

        # 3b. Transfer entropy surge — max TE across top-5 market pairs
        report.transfer_entropy_surge = self._transfer_entropy_surge(price_series)

        # 3c. VPIN — accept as parameter
        report.vpin_aggregate = max(0.0, min(1.0, vpin_aggregate))

        # ---- Category 4: Microstructure (3 indicators) ------------------

        # 4a. Liquidity score — 1.0 - avg(spread / mid)
        report.liquidity_score = self._liquidity_score(price_series, feed_spreads)

        # 4b. Spread widening — rate of change of average spread
        avg_spread = self._avg_spread(feed_spreads)
        self._spread_history.append(avg_spread)
        report.spread_widening = self._spread_widening_rate()

        # 4c. Amihud illiquidity ratio
        report.amihud_ratio = self._amihud_ratio(price_series, volume_series)

        # ---- Category 5: Changepoint (2 indicators) --------------------

        # 5a. BOCPD — accept as parameter
        report.bocpd_probability = max(0.0, min(1.0, bocpd_probability))

        # 5b. CUSUM trigger count
        report.cusum_trigger_count = self._cusum_triggers(price_series)

        # ---- Category 6: Copula tail (1 indicator) ---------------------

        report.vine_tail_risk = max(0.0, min(1.0, vine_tail_risk))

        # ---- Bookkeeping -----------------------------------------------
        report.timestamp = time.time()
        self._prev_report = report
        return report

    # ------------------------------------------------------------------
    # Aggregate queries
    # ------------------------------------------------------------------

    def is_approaching_criticality(
        self,
        report: CriticalityReport | None = None,
        threshold: int = 5,
    ) -> bool:
        """True if the warning count meets or exceeds *threshold*.

        Uses the most recent report if *report* is not provided.
        """
        with self._lock:
            r = report if report is not None else self._prev_report
            if r is None:
                return False
            return r.warning_count() >= threshold

    def avalanche_check(self, market_drawdown: float) -> float:
        """Determine capital to deploy from avalanche reserves.

        If *market_drawdown* (fractional, e.g. 0.35 for 35%) exceeds the
        deploy threshold from config, returns a portion of the reserve to
        deploy. Otherwise returns 0.

        The deployed amount is subtracted from the internal reserve so
        double-deployment cannot occur.

        Parameters
        ----------
        market_drawdown:
            Current drawdown as a positive fraction (0.0 to 1.0).

        Returns
        -------
        Capital amount to deploy (0 if below threshold).
        """
        with self._lock:
            if market_drawdown < self._config.avalanche_deploy_threshold:
                return 0.0

            if self._avalanche_reserve <= 0.0:
                logger.warning(
                    "Avalanche reserve exhausted — cannot deploy"
                )
                return 0.0

            # Deploy a fraction proportional to how far past the threshold
            # we are, capped at the remaining reserve.
            overshoot = (
                market_drawdown - self._config.avalanche_deploy_threshold
            )
            # deploy_fraction: scale between 0.25 (at threshold) and 1.0
            # (at 2x threshold overshoot)
            deploy_fraction = min(
                1.0,
                0.25 + 0.75 * (overshoot / max(self._config.avalanche_deploy_threshold, 1e-9)),
            )
            deploy = min(
                self._avalanche_reserve * deploy_fraction,
                self._avalanche_reserve,
            )
            self._avalanche_reserve -= deploy

            logger.info(
                "Avalanche deploy: $%.2f (drawdown=%.1f%%, reserve_remaining=$%.2f)",
                deploy,
                market_drawdown * 100.0,
                self._avalanche_reserve,
            )
            return deploy

    @property
    def reserve_remaining(self) -> float:
        """Current avalanche reserve balance."""
        with self._lock:
            return self._avalanche_reserve

    def replenish_reserve(self, amount: float) -> None:
        """Add capital back to the avalanche reserve (e.g. after recovery).

        Capped at the configured maximum reserve.
        """
        if amount <= 0.0:
            return
        max_reserve = self._config.total_capital * self._config.avalanche_reserve_pct
        with self._lock:
            self._avalanche_reserve = min(
                self._avalanche_reserve + amount,
                max_reserve,
            )

    @property
    def prev_report(self) -> CriticalityReport | None:
        """Most recent criticality report (read-only snapshot)."""
        with self._lock:
            return self._prev_report

    # ------------------------------------------------------------------
    # Indicator implementations
    # ------------------------------------------------------------------

    @staticmethod
    def _vol_signature(
        price_series: dict[str, list[float]],
    ) -> list[float]:
        """Compute realized vol at multiple sampling frequencies.

        Returns a list of average volatilities (one per frequency).
        """
        frequencies = [1, 2, 5, 10, 20]
        results: list[float] = []

        for freq in frequencies:
            vols: list[float] = []
            for prices in price_series.values():
                n = len(prices)
                if n < freq * 2 + 1:
                    continue
                # Sub-sampled log-returns
                returns: list[float] = []
                for i in range(freq, n, freq):
                    if prices[i - freq] > 0.0 and prices[i] > 0.0:
                        returns.append(math.log(prices[i] / prices[i - freq]))
                if len(returns) < 2:
                    continue
                mean_r = sum(returns) / len(returns)
                var = sum((r - mean_r) ** 2 for r in returns) / len(returns)
                vols.append(math.sqrt(var))

            if vols:
                results.append(sum(vols) / len(vols))

        return results

    @staticmethod
    def _two_scale_ratio(
        price_series: dict[str, list[float]],
    ) -> float:
        """Ratio of high-frequency to low-frequency realized volatility.

        High-freq: 1-tick returns.  Low-freq: 20-tick returns.
        A ratio >> 1 indicates microstructure noise; < 1 indicates smoothing.
        """
        hf_vols: list[float] = []
        lf_vols: list[float] = []

        for prices in price_series.values():
            n = len(prices)

            # High-freq vol (1-tick)
            if n >= 20:
                hf_returns = []
                for i in range(1, n):
                    if prices[i - 1] > 0.0 and prices[i] > 0.0:
                        hf_returns.append(math.log(prices[i] / prices[i - 1]))
                if len(hf_returns) >= 2:
                    mu = sum(hf_returns) / len(hf_returns)
                    var = sum((r - mu) ** 2 for r in hf_returns) / len(hf_returns)
                    hf_vols.append(math.sqrt(var))

            # Low-freq vol (20-tick)
            if n >= 41:
                lf_returns = []
                for i in range(20, n, 20):
                    if prices[i - 20] > 0.0 and prices[i] > 0.0:
                        lf_returns.append(math.log(prices[i] / prices[i - 20]))
                if len(lf_returns) >= 2:
                    mu = sum(lf_returns) / len(lf_returns)
                    var = sum((r - mu) ** 2 for r in lf_returns) / len(lf_returns)
                    lf_vols.append(math.sqrt(var))

        if not hf_vols or not lf_vols:
            return 1.0

        avg_hf = sum(hf_vols) / len(hf_vols)
        avg_lf = sum(lf_vols) / len(lf_vols)

        if avg_lf < 1e-15:
            return 1.0

        return avg_hf / avg_lf

    @staticmethod
    def _market_entropy(
        price_series: dict[str, list[float]],
    ) -> float:
        """Average Shannon entropy of binned price returns.

        Higher entropy = more uniform (random) distribution of returns.
        Lower entropy = more concentrated/predictable distribution.
        Returns 1.0 (maximum entropy for uniform distribution) when no
        data is available.
        """
        n_bins = 10
        entropies: list[float] = []

        for prices in price_series.values():
            n = len(prices)
            if n < _MIN_SERIES:
                continue

            # Log-returns
            returns: list[float] = []
            for i in range(1, n):
                if prices[i - 1] > 0.0 and prices[i] > 0.0:
                    returns.append(math.log(prices[i] / prices[i - 1]))

            if len(returns) < _MIN_SERIES:
                continue

            # Bin returns
            lo = min(returns)
            hi = max(returns)
            spread = hi - lo
            if spread < 1e-15:
                # All returns identical — zero entropy
                entropies.append(0.0)
                continue

            counts = [0] * n_bins
            for r in returns:
                b = int((r - lo) / spread * (n_bins - 1))
                b = max(0, min(n_bins - 1, b))
                counts[b] += 1

            total = sum(counts)
            if total == 0:
                continue

            probs = [c / total for c in counts if c > 0]
            ent = _entropy(probs)
            # Normalize to [0, 1] by dividing by max possible entropy
            max_ent = math.log2(n_bins) if n_bins > 1 else 1.0
            entropies.append(ent / max_ent if max_ent > 0.0 else 0.0)

        if not entropies:
            return 1.0

        return sum(entropies) / len(entropies)

    @staticmethod
    def _transfer_entropy_surge(
        price_series: dict[str, list[float]],
    ) -> float:
        """Max transfer entropy across the top-5 most active market pairs.

        Returns 0.0 if fewer than 2 markets or insufficient data.
        """
        # Sort markets by series length (most data first)
        markets = sorted(
            price_series.items(),
            key=lambda kv: len(kv[1]),
            reverse=True,
        )[:10]  # Consider top-10 most data-rich markets

        if len(markets) < 2:
            return 0.0

        # Convert to returns for TE computation
        market_returns: list[tuple[str, list[float]]] = []
        for mkt_id, prices in markets:
            n = len(prices)
            if n < _MIN_SERIES:
                continue
            returns: list[float] = []
            for i in range(1, n):
                if prices[i - 1] > 0.0 and prices[i] > 0.0:
                    returns.append(math.log(prices[i] / prices[i - 1]))
                else:
                    returns.append(0.0)
            if len(returns) >= _MIN_SERIES:
                market_returns.append((mkt_id, returns))

        if len(market_returns) < 2:
            return 0.0

        # Compute TE for top-5 pairs (by combined series length)
        te_values: list[float] = []
        pairs_checked = 0
        max_pairs = 5

        for i in range(len(market_returns)):
            if pairs_checked >= max_pairs:
                break
            for j in range(i + 1, len(market_returns)):
                if pairs_checked >= max_pairs:
                    break
                _, src = market_returns[i]
                _, tgt = market_returns[j]
                te_fwd = _transfer_ent(src, tgt, lag=1, bins=5)
                te_rev = _transfer_ent(tgt, src, lag=1, bins=5)
                te_values.append(max(te_fwd, te_rev))
                pairs_checked += 1

        return max(te_values) if te_values else 0.0

    @staticmethod
    def _liquidity_score(
        price_series: dict[str, list[float]],
        feed_spreads: dict[str, float],
    ) -> float:
        """Liquidity score: 1.0 - avg(spread / mid_price).

        Returns 1.0 (fully liquid) when no spread data is available.
        """
        if not feed_spreads:
            return 1.0

        ratios: list[float] = []
        for mkt_id, spread in feed_spreads.items():
            if spread < 0.0 or not math.isfinite(spread):
                continue
            # Use latest price as mid approximation
            prices = price_series.get(mkt_id)
            if prices and len(prices) > 0:
                mid = prices[-1]
                if mid > 1e-15:
                    ratios.append(spread / mid)

        if not ratios:
            return 1.0

        avg_ratio = sum(ratios) / len(ratios)
        return max(0.0, min(1.0, 1.0 - avg_ratio))

    def _spread_widening_rate(self) -> float:
        """Rate of change of average spread from history.

        Positive = spreads are widening (deteriorating liquidity).
        Returns 0.0 with insufficient history.
        """
        if len(self._spread_history) < 2:
            return 0.0

        # Compare recent half vs older half
        history = list(self._spread_history)
        mid = len(history) // 2
        if mid == 0:
            return 0.0

        old_avg = sum(history[:mid]) / mid
        new_avg = sum(history[mid:]) / (len(history) - mid)

        if old_avg < 1e-15:
            return 0.0 if new_avg < 1e-15 else 1.0

        # Fractional change
        return (new_avg - old_avg) / old_avg

    @staticmethod
    def _avg_spread(feed_spreads: dict[str, float]) -> float:
        """Average spread across all markets."""
        if not feed_spreads:
            return 0.0
        valid = [s for s in feed_spreads.values() if math.isfinite(s) and s >= 0.0]
        if not valid:
            return 0.0
        return sum(valid) / len(valid)

    @staticmethod
    def _amihud_ratio(
        price_series: dict[str, list[float]],
        volume_series: dict[str, list[float]],
    ) -> float:
        """Average Amihud illiquidity ratio: avg(|return| / volume).

        Higher values = less liquid. Returns 0.0 when volume data is missing.
        """
        if not volume_series:
            return 0.0

        ratios: list[float] = []
        for mkt_id, prices in price_series.items():
            volumes = volume_series.get(mkt_id)
            if volumes is None:
                continue

            n = min(len(prices), len(volumes))
            if n < 2:
                continue

            mkt_ratios: list[float] = []
            for i in range(1, n):
                if prices[i - 1] <= 0.0 or prices[i] <= 0.0:
                    continue
                vol = volumes[i]
                if not math.isfinite(vol) or vol <= 0.0:
                    continue
                ret = abs(math.log(prices[i] / prices[i - 1]))
                mkt_ratios.append(ret / vol)

            if mkt_ratios:
                ratios.append(sum(mkt_ratios) / len(mkt_ratios))

        if not ratios:
            return 0.0

        return sum(ratios) / len(ratios)

    @staticmethod
    def _cusum_triggers(
        price_series: dict[str, list[float]],
    ) -> int:
        """Count returns exceeding 2*std across all markets (CUSUM-style).

        Each exceedance is one trigger. Sums across all markets.
        """
        total_triggers = 0

        for prices in price_series.values():
            n = len(prices)
            if n < _MIN_SERIES:
                continue

            returns: list[float] = []
            for i in range(1, n):
                if prices[i - 1] > 0.0 and prices[i] > 0.0:
                    returns.append(math.log(prices[i] / prices[i - 1]))

            if len(returns) < _MIN_SERIES:
                continue

            mu = sum(returns) / len(returns)
            var = sum((r - mu) ** 2 for r in returns) / len(returns)
            std = math.sqrt(var) if var > 0.0 else 0.0

            if std < 1e-15:
                continue

            threshold = 2.0 * std
            for r in returns:
                if abs(r - mu) > threshold:
                    total_triggers += 1

        return total_triggers

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        with self._lock:
            warnings = (
                self._prev_report.warning_count()
                if self._prev_report is not None
                else 0
            )
            return (
                f"CriticalityMonitor("
                f"warnings={warnings}, "
                f"reserve=${self._avalanche_reserve:,.2f})"
            )
