"""Population-Based Training for live agent hyperparameter evolution.

PBT runs periodically (default every 24 h) and applies two operators:

1. **Exploit** -- The bottom ``exploit_fraction`` of agents (by fitness)
   copy hyperparameters from a randomly chosen agent in the top
   ``exploit_fraction``.
2. **Explore** -- Each exploited agent then perturbs its newly copied
   hyperparameters by a multiplicative factor drawn uniformly from
   ``[1 - magnitude, 1 + magnitude]``, clamped to the parameter's
   defined range.

This discovers hyperparameter *schedules*, not just optimal fixed values,
because the population is always live and the landscape shifts with regime
changes.

Thread-safe: every public method acquires a single lock so PBT can run
concurrently with dashboard reads and agent lifecycle management.
"""

from __future__ import annotations

import logging
import random
import threading
import time
from typing import Any

from horizon.hive._types import HiveAgent, HiveConfig

logger = logging.getLogger("horizon.hive.pbt")

# ---------------------------------------------------------------------------
# Tunable parameter definitions: name -> (min, max)
# ---------------------------------------------------------------------------

TUNABLE_PARAMS: dict[str, tuple[float, float]] = {
    "signal_threshold": (0.01, 2.0),
    "position_size_mult": (0.1, 3.0),
    "stop_loss_pct": (0.01, 0.20),
    "take_profit_pct": (0.02, 0.50),
    "rebalance_interval": (60.0, 86400.0),
    "max_position_pct": (0.01, 0.30),
    "spread_mult": (0.5, 5.0),
    "decay_halflife": (300.0, 86400.0),
    "regime_sensitivity": (0.0, 2.0),
    "crowding_threshold": (0.3, 0.9),
}


class PopulationBasedTrainer:
    """Evolves hyperparameters of live agents.

    Bottom 20% copy hyperparams from top 20% (exploit),
    then perturb them (explore). This discovers hyperparameter
    schedules, not just optimal fixed values.
    """

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #

    def __init__(self, config: HiveConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        # Cache exploit/explore parameters from config for hot-path reads.
        self._exploit_fraction = max(0.0, min(1.0, config.pbt_exploit_fraction))
        self._explore_magnitude = max(0.0, min(1.0, config.pbt_explore_magnitude))
        self._interval_seconds = max(60.0, config.pbt_interval_hours * 3600.0)

    # ------------------------------------------------------------------ #
    # Scheduling
    # ------------------------------------------------------------------ #

    def should_run(self, last_run: float) -> bool:
        """Return ``True`` if ``pbt_interval_hours`` has elapsed since *last_run*.

        Parameters
        ----------
        last_run:
            Monotonic timestamp (``time.monotonic()``) of the last PBT cycle.
            Pass ``0.0`` to force an immediate run.
        """
        return (time.monotonic() - last_run) >= self._interval_seconds

    # ------------------------------------------------------------------ #
    # Core evolution step
    # ------------------------------------------------------------------ #

    def evaluate_and_evolve(
        self,
        agents: list[HiveAgent],
    ) -> list[dict[str, Any]]:
        """Run one PBT cycle: exploit then explore.

        1. Sort agents by ``fitness`` descending.
        2. Bottom ``exploit_fraction`` copies hyperparams from a random
           agent in the top ``exploit_fraction``.
        3. Each exploited agent then perturbs every tunable parameter by
           a multiplicative factor in ``[1 - magnitude, 1 + magnitude]``,
           clamped to the parameter's defined range.

        Parameters
        ----------
        agents:
            All active ``HiveAgent`` instances.  Must have at least 2
            agents for exploitation to occur.

        Returns
        -------
        list[dict]
            One mutation record per mutated agent::

                {
                    "agent_id": str,
                    "old_params": dict[str, float],
                    "new_params": dict[str, float],
                    "parent_id": str,
                }
        """
        if len(agents) < 2:
            return []

        with self._lock:
            exploit_frac = self._exploit_fraction
            explore_mag = self._explore_magnitude

        # Sort by fitness descending (stable sort preserves insertion order
        # for equal-fitness agents).
        ranked = sorted(agents, key=lambda a: a.fitness, reverse=True)
        n = len(ranked)

        n_exploit = max(1, int(n * exploit_frac))
        top_agents = ranked[:n_exploit]
        bottom_agents = ranked[-n_exploit:]

        # Guard: if top and bottom overlap entirely (tiny population),
        # skip to avoid self-copy.
        top_ids = {a.agent_id for a in top_agents}
        bottom_candidates = [a for a in bottom_agents if a.agent_id not in top_ids]
        if not bottom_candidates:
            return []

        mutations: list[dict[str, Any]] = []

        for agent in bottom_candidates:
            # --- Exploit: copy from a random top performer ---
            parent = random.choice(top_agents)
            old_params = dict(agent.hyperparams)

            # Start with parent's hyperparams.
            new_params: dict[str, float] = dict(parent.hyperparams)

            # --- Explore: perturb each tunable parameter ---
            for param_name, (lo, hi) in TUNABLE_PARAMS.items():
                # Use parent's value if present, otherwise use agent's
                # current value, otherwise use midpoint of range.
                base_value = new_params.get(
                    param_name,
                    agent.hyperparams.get(param_name, (lo + hi) / 2.0),
                )
                # Multiplicative perturbation.
                factor = random.uniform(1.0 - explore_mag, 1.0 + explore_mag)
                perturbed = base_value * factor
                # Clamp to valid range.
                new_params[param_name] = max(lo, min(hi, perturbed))

            # Apply to agent.
            agent.hyperparams = new_params

            mutations.append({
                "agent_id": agent.agent_id,
                "old_params": old_params,
                "new_params": dict(new_params),
                "parent_id": parent.agent_id,
            })

        if mutations:
            logger.info(
                "PBT cycle: %d/%d agents mutated (exploit_frac=%.2f, explore_mag=%.2f)",
                len(mutations), n, exploit_frac, explore_mag,
            )

        return mutations
