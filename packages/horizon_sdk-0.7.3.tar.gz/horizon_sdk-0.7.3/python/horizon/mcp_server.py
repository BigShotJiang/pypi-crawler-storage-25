"""Horizon SDK MCP Server.

Exposes the Horizon trading engine as MCP tools for Claude Code,
Cursor, Claude Desktop, and other MCP-compatible clients.

Run: python -m horizon.mcp

Security:
- HORIZON_API_KEY or HORIZON_SDK_KEY: authenticates the engine against the
  Horizon backend. Validated at startup when auth is enabled.
- HORIZON_MCP_AUTH: set to ``"false"`` to disable startup SDK key validation.
  Auth is enabled by default.
- stdio transport (the default) is inherently local but still validates
  the SDK key at startup to ensure only authorized users run the server.

Architecture note: Tools are consolidated into ~25 tools (from 241) using
action-dispatch compound tools. This reduces context consumption when an LLM
loads the tool list, while preserving all capabilities. Individual tools are
kept for the most frequently used trading operations.
"""

from __future__ import annotations

import json
import os
import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from horizon import tools
from horizon import provider_tools

logger = logging.getLogger(__name__)

_sdk_key = os.environ.get("HORIZON_SDK_KEY") or os.environ.get("HORIZON_API_KEY")
_auth_enabled = os.environ.get("HORIZON_MCP_AUTH", "true").lower() != "false"

if _sdk_key:
    logger.info("MCP server: SDK key set, engine will authenticate")
else:
    logger.info("MCP server: no SDK key set, running in unauthenticated mode")


def _validate_startup_auth() -> None:
    """Validate the SDK key at server startup.

    When auth is enabled (default), the server refuses to start without
    a valid SDK key. This ensures only authorized users can run MCP servers.
    """
    if not _auth_enabled:
        logger.info("MCP server: auth disabled via HORIZON_MCP_AUTH=false")
        return
    if not _sdk_key:
        raise RuntimeError(
            "HORIZON_SDK_KEY (or HORIZON_API_KEY) required for MCP server. "
            "Set HORIZON_MCP_AUTH=false to disable authentication."
        )
    try:
        from horizon.auth import validate_sdk_key
        tier = validate_sdk_key(_sdk_key)
        logger.info("MCP server authenticated: tier=%s", tier)
    except Exception as e:
        raise RuntimeError(f"Invalid SDK key: {e}")

mcp = FastMCP(
    "horizon-sdk",
    instructions=(
        "Horizon SDK - prediction market trading engine. "
        "Core tools (engine_status, submit_order, etc.) are individual tools. "
        "Advanced capabilities are grouped into compound tools that take an 'action' "
        "parameter and a 'params' JSON string. Each compound tool's description lists "
        "available actions and their parameters. "
        "Never pass API keys, private keys, or passwords as tool parameters - "
        "always use environment variables instead. "
        "Some actions require a Pro or Ultra plan (marked [PRO]/[ULTRA]). "
        "Check plan with cloud(action='account')."
    ),
)


# ---------------------------------------------------------------------------
# Dispatch helper
# ---------------------------------------------------------------------------

_MAX_INPUT_LEN = 10_000  # max chars for action + params to prevent abuse


def _dispatch(table: dict[str, Any], action: str, params_str: str) -> Any:
    """Route a compound tool call to the right function."""
    if len(action) + len(params_str) > _MAX_INPUT_LEN:
        return {"error": f"Input too large ({len(action) + len(params_str)} chars). Maximum is {_MAX_INPUT_LEN}."}
    fn = table.get(action)
    if fn is None:
        return {"error": f"Unknown action '{action}'. Available: {', '.join(sorted(table))}"}
    try:
        kwargs = json.loads(params_str) if params_str and params_str != "{}" else {}
    except json.JSONDecodeError as e:
        return {"error": f"Invalid params JSON: {e}"}
    try:
        return fn(**kwargs)
    except TypeError as e:
        return {"error": f"Invalid params for '{action}': {e}"}
    except Exception as e:
        return {"error": str(e)}


# ===========================================================================
# Individual Tools (14) — most-used trading operations
# ===========================================================================

@mcp.tool()
def engine_status() -> dict:
    """Get trading engine status: PnL, open orders, positions, kill switch state, uptime."""
    return tools.engine_status()


@mcp.tool()
def submit_order(
    market_id: str, side: str, price: float, size: float, market_side: str = "yes",
) -> dict:
    """Submit a limit order. side: 'buy' or 'sell'. market_side: 'yes', 'no', or 'long'. price in market currency (0-1 for prediction markets, dollar price for equities/crypto). Returns order ID."""
    return tools.submit_order(market_id, side, price, size, market_side)


@mcp.tool()
def cancel_order(order_id: str) -> dict:
    """Cancel a single order by its ID."""
    return tools.cancel_order(order_id)


@mcp.tool()
def cancel_all_orders() -> dict:
    """Cancel ALL open orders across all exchanges. Use with caution."""
    return tools.cancel_all_orders()


@mcp.tool()
def list_positions() -> list[dict]:
    """List all open positions with size, entry price, PnL, and exchange."""
    return tools.list_positions()


@mcp.tool()
def list_open_orders(market_id: str | None = None) -> list[dict]:
    """List open orders. Optionally filter by market_id."""
    return tools.list_open_orders(market_id)


@mcp.tool()
def list_recent_fills(limit: int = 20) -> list[dict]:
    """List recent trade fills. Default last 20."""
    return tools.list_recent_fills(limit)


@mcp.tool()
def discover_markets(
    exchange: str = "polymarket",
    query: str = "",
    limit: int = 10,
    market_type: str = "all",
    category: str = "",
) -> list[dict]:
    """Search for markets. exchange: "polymarket", "kalshi", "limitless", "alpaca", "ibkr". market_type: 'all', 'binary', or 'multi'. category: tag filter."""
    return tools.discover(exchange, query, limit, market_type, category)


@mcp.tool()
def get_market_detail(slug_or_id: str, exchange: str = "polymarket") -> dict:
    """Get full detail for a single market: metadata, prices, history, orderbook, trades, holders."""
    return tools.market_detail(slug_or_id, exchange)


@mcp.tool()
def top_markets(exchange: str = "polymarket", limit: int = 10, category: str = "") -> list[dict]:
    """Get the highest-volume active markets. Exchange: 'polymarket' or 'kalshi'."""
    return tools.get_top_markets(exchange, limit, category)


@mcp.tool()
def kelly_sizing(
    prob: float,
    price: float,
    bankroll: float = 1000.0,
    fraction: float = 0.25,
    max_size: float = 100.0,
) -> dict:
    """Compute Kelly-optimal position size. prob: estimated probability (0-1). price: market price (0-1)."""
    return tools.kelly_sizing(prob, price, bankroll, fraction, max_size)


@mcp.tool()
def get_feed_snapshot(name: str) -> dict:
    """Get the latest price/bid/ask snapshot for a named feed."""
    return tools.get_feed_snapshot(name)


@mcp.tool()
def activate_kill_switch(reason: str) -> dict:
    """EMERGENCY STOP. Activates the kill switch and cancels all orders."""
    return tools.activate_kill_switch(reason)


@mcp.tool()
def portfolio_metrics() -> dict:
    """Get portfolio metrics: total value, PnL, exposure, diversification, concentration."""
    return tools.get_portfolio_metrics()


# ===========================================================================
# Resources
# ===========================================================================

@mcp.resource("horizon://status")
def resource_status() -> str:
    """Current engine status as JSON context."""
    return json.dumps(tools.engine_status(), indent=2)


@mcp.resource("horizon://positions")
def resource_positions() -> str:
    """Current positions as JSON context."""
    return json.dumps(tools.list_positions(), indent=2)


# ===========================================================================
# Compound Tool: feed
# ===========================================================================

@mcp.tool()
def feed(action: str, params: str = "{}") -> dict | list:
    """Feed and data management. Actions:

    - list_feeds() — list all active feeds with prices
    - start(name, feed_type, config_json?, symbol?, url?, interval?) — start a live feed. feed_type: binance_ws, polymarket_book, kalshi_book, rest, predictit, manifold, espn, nws, rest_json_path, chainlink, alpaca
    - metrics(name) — connection metrics for a feed
    - all_metrics() — metrics for all feeds
    - health(stale_threshold?) — check staleness of all feeds
    - parity(market_id, feed_name?) [PREDICTION MARKET] — check YES/NO price parity
    - discover_events(query?, limit?, min_volume?) [PREDICTION MARKET] — discover multi-outcome events on Polymarket
    """
    return _dispatch({
        "list_feeds": lambda **kw: tools.list_all_feeds(),
        "start": lambda **kw: tools.start_feed(
            kw["name"], kw["feed_type"], kw.get("config_json"),
            kw.get("symbol"), kw.get("url"), kw.get("interval", 5.0),
        ),
        "metrics": lambda **kw: tools.feed_metrics(kw["name"]),
        "all_metrics": lambda **kw: tools.all_feed_metrics(),
        "health": lambda **kw: tools.check_feed_health(kw.get("stale_threshold", 30.0)),
        "parity": lambda **kw: tools.check_parity(kw["market_id"], kw.get("feed_name")),
        "discover_events": lambda **kw: tools.discover_event(
            kw.get("query", ""), kw.get("limit", 10), kw.get("min_volume", 0.0),
        ),
    }, action, params)


# ===========================================================================
# Compound Tool: order_management
# ===========================================================================

@mcp.tool()
def order_management(action: str, params: str = "{}") -> dict | list:
    """Advanced order management. Actions:

    - cancel_market(market_id) — cancel all orders for a market
    - add_stop_loss(market_id, side, order_side, size, trigger) — add stop-loss. side: yes/no/long. order_side: buy/sell
    - add_take_profit(market_id, side, order_side, size, trigger) — add take-profit. side: yes/no/long
    - list_contingent() — list pending stop-loss and take-profit orders
    - deactivate_kill_switch() — resume normal trading after kill switch
    """
    return _dispatch({
        "cancel_market": lambda **kw: tools.cancel_market_orders(kw["market_id"]),
        "add_stop_loss": lambda **kw: tools.add_stop_loss(
            kw["market_id"], kw["side"], kw["order_side"], kw["size"], kw["trigger"],
        ),
        "add_take_profit": lambda **kw: tools.add_take_profit(
            kw["market_id"], kw["side"], kw["order_side"], kw["size"], kw["trigger"],
        ),
        "list_contingent": lambda **kw: tools.list_contingent_orders(),
        "deactivate_kill_switch": lambda **kw: tools.deactivate_kill_switch(),
    }, action, params)


# ===========================================================================
# Compound Tool: wallet
# ===========================================================================

@mcp.tool()
def wallet(action: str, params: str = "{}") -> dict | list:
    """Polymarket wallet analytics (public, no auth). Actions:

    - trades(address, limit?, condition_id?) — trade history for a wallet
    - market_trades(condition_id, limit?, side?, min_size?) — recent trades for a market
    - positions(address, limit?, sort_by?) — open positions. sort_by: TOKENS/CURRENT/INITIAL/CASHPNL/PERCENTPNL/PRICE/AVGPRICE
    - value(address) — total USD value
    - profile(address) — public profile (name, bio, X handle)
    - top_holders(condition_id, limit?) — top token holders
    - market_flow(condition_id, trade_limit?, top_n?) — buy/sell volume, net flow, top traders
    - profile_wallet(address, trade_limit?) — [PRO] deep behavioral profile
    - track(wallet, market_id?, limit?) — [ULTRA] directional signals for a wallet
    - consensus(market_id, min_quality?) — [ULTRA] multi-wallet consensus signal
    - scan_signals(wallet, limit?) — [ULTRA] scan all positions for signals
    """
    return _dispatch({
        "trades": lambda **kw: tools.wallet_trades(kw["address"], kw.get("limit", 50), kw.get("condition_id")),
        "market_trades": lambda **kw: tools.market_trades(
            kw["condition_id"], kw.get("limit", 50), kw.get("side"), kw.get("min_size", 0.0),
        ),
        "positions": lambda **kw: tools.wallet_positions(kw["address"], kw.get("limit", 50), kw.get("sort_by", "CURRENT")),
        "value": lambda **kw: tools.wallet_value(kw["address"]),
        "profile": lambda **kw: tools.wallet_profile(kw["address"]),
        "top_holders": lambda **kw: tools.market_top_holders(kw["condition_id"], kw.get("limit", 20)),
        "market_flow": lambda **kw: tools.market_flow(kw["condition_id"], kw.get("trade_limit", 500), kw.get("top_n", 10)),
        "profile_wallet": lambda **kw: tools.wallet_profiler(kw["address"], kw.get("trade_limit", 500)),
        "track": lambda **kw: tools.track_wallet_tool(kw["wallet"], kw.get("market_id", ""), kw.get("limit", 500)),
        "consensus": lambda **kw: tools.wallet_consensus_tool(kw["market_id"], kw.get("min_quality", 0.1)),
        "scan_signals": lambda **kw: tools.scan_wallet_signals_tool(kw["wallet"], kw.get("limit", 500)),
    }, action, params)


# ===========================================================================
# Compound Tool: scanning
# ===========================================================================

@mcp.tool()
def scanning(action: str, params: str = "{}") -> dict | list:
    """Market scanning, signals, and execution. Actions:

    - sentinel_report() — [ULTRA] portfolio risk report (regime, VaR, drawdown, hedge suggestions)
    - oracle_forecast(market_id, market_title?, market_price?, exchange?) — [ULTRA] 6-signal ensemble forecast
    - oracle_edges(min_edge_bps?, max_markets?, exchange?) — [ULTRA] scan for edge opportunities
    - whale_galaxy(top_n?, max_markets?) — [ULTRA] scan for whale wallets and clusters
    - llm_forecast(market_id, market_title?, market_price?, provider?, model?) — LLM + news forecast
    - llm_scan(min_edge_bps?, max_markets?, provider?, model?, exchange?) — scan for LLM-detected edges
    - analyze_resolution(market_id, market_title?, provider?, model?, exchange?) — analyze resolution risks
    - sniper_scan(provider?, max_markets?, model?, exchange?) — scan for markets about to resolve
    - execute_arbitrage(market_id, buy_exchange, sell_exchange, buy_price, sell_price, size) — cross-exchange arb
    - stealth_estimate(market_id, size, feed_name?) — [ULTRA] estimate market impact
    - stealth_execute(market_id, side, order_side, size, price, strategy?) — [ULTRA] stealth execution (twap/iceberg/sniper). side: yes/no/long
    """
    return _dispatch({
        "sentinel_report": lambda **kw: tools.get_sentinel_report(),
        "oracle_forecast": lambda **kw: tools.oracle_forecast_market(
            kw["market_id"], kw.get("market_title", ""), kw.get("market_price", 0.0),
            exchange=kw.get("exchange", "polymarket"),
        ),
        "oracle_edges": lambda **kw: tools.oracle_scan_edges(
            kw.get("min_edge_bps", 200.0), kw.get("max_markets", 30),
            exchange=kw.get("exchange", "polymarket"),
        ),
        "whale_galaxy": lambda **kw: tools.whale_galaxy_scan(kw.get("top_n", 20), kw.get("max_markets", 50)),
        "llm_forecast": lambda **kw: tools.llm_forecast_market(
            kw["market_id"], kw.get("market_title", ""), kw.get("market_price", 0.5),
            kw.get("provider", "anthropic"), kw.get("model", ""),
        ),
        "llm_scan": lambda **kw: tools.llm_scan_markets(
            kw.get("min_edge_bps", 200.0), kw.get("max_markets", 20),
            kw.get("provider", "anthropic"), kw.get("model", ""),
            exchange=kw.get("exchange", "polymarket"),
        ),
        "analyze_resolution": lambda **kw: tools.analyze_resolution_tool(
            kw["market_id"], kw.get("market_title", ""), kw.get("provider", "anthropic"),
            kw.get("model", ""), exchange=kw.get("exchange", "polymarket"),
        ),
        "sniper_scan": lambda **kw: tools.sniper_scan_tool(
            kw.get("provider", "anthropic"), kw.get("max_markets", 10),
            kw.get("model", ""), exchange=kw.get("exchange", "polymarket"),
        ),
        "execute_arbitrage": lambda **kw: tools.execute_arb(
            kw["market_id"], kw["buy_exchange"], kw["sell_exchange"],
            kw["buy_price"], kw["sell_price"], kw["size"],
        ),
        "stealth_estimate": lambda **kw: tools.stealth_estimate_impact(
            kw["market_id"], kw["size"], kw.get("feed_name"),
        ),
        "stealth_execute": lambda **kw: tools.stealth_execute_order(
            kw["market_id"], kw["side"], kw["order_side"], kw["size"],
            kw["price"], kw.get("strategy", "auto"),
        ),
    }, action, params)


# ===========================================================================
# Compound Tool: analytics
# ===========================================================================

@mcp.tool()
def analytics(action: str, params: str = "{}") -> dict | list:
    """Quantitative analytics toolkit. Pass action and params as JSON string.

    Statistics:
    - shannon_entropy(p) — binary Shannon entropy
    - kl_divergence(p, q) — KL divergence between distributions
    - hurst_exponent(prices) — trend/mean-reversion detection (>0.5 trending, <0.5 mean-reverting)
    - variance_ratio_test(returns, period?) — market efficiency test
    - cornish_fisher_var(returns, confidence?) — skew/kurtosis-adjusted VaR and CVaR
    - deflated_sharpe(sharpe, n_obs, n_trials, skew?, kurt?) — statistical significance of Sharpe
    - hawkes_intensity(event_times, mu?, alpha?, beta?) — self-exciting process for trade arrivals
    - correlation_matrix(returns) — Ledoit-Wolf shrinkage covariance

    Signals [PRO]:
    - signal_diagnostics(predictions, outcomes) — IC, half-life, Hurst
    - market_efficiency_test(prices) — variance ratio + Hurst + efficiency flag

    Portfolio:
    - portfolio_weights(method?) — optimal weights (equal/kelly/risk_parity/min_variance)
    - simulate_portfolio(scenarios?, seed?) — [PRO] Monte Carlo VaR/CVaR
    - stress_test(n_simulations?, seed?) — [PRO] adverse scenario stress test
    - generate_tearsheet(equity_curve?, timestamps?, trades?, initial_capital?) — [PRO] performance tearsheet
    - bayesian_optimize(param_space, n_iterations?, n_initial?, seed?) — [PRO] GP-based param optimization
    - update_params(params) — hot-reload runtime parameters
    - get_params() — get current runtime parameters

    AFML (Lopez de Prado):
    - tick_bars(timestamps, prices, volumes, bar_size) — fixed-tick bars
    - volume_bars(timestamps, prices, volumes, bar_size) — fixed-volume bars
    - dollar_bars(timestamps, prices, volumes, bar_size) — fixed-dollar bars
    - cusum_filter(prices, threshold) — structural break detection
    - triple_barrier_labels(prices, timestamps, events, pt_sl?, min_ret?, max_holding?, vol_span?)
    - frac_diff(series, d, threshold?) — fractional differentiation
    - min_frac_diff(series, p_threshold?, max_d?, n_steps?) — minimum d for stationarity
    - hrp_weights(covariance) — Hierarchical Risk Parity weights
    - denoise_covariance(covariance, n_observations) — Marcenko-Pastur denoising

    Microstructure:
    - invariance_analysis(dollar_volume, volatility, n_trades, avg_trade_size)
    - signal_selection(x, y, alpha?, l1_ratio?) — elastic net for signal selection
    - duration_analysis(durations, omega?, alpha?, beta?) — ACD model
    - volatility_signature(prices, max_freq?, n_points?) — optimal sampling frequency
    - two_scale_realized_vol(prices) — noise-robust realized volatility
    - cross_impact(returns_matrix, volumes_matrix) — cross-asset impact matrix

    State Estimation:
    - kalman_filter_state(observations, state_dim?, obs_dim?)
    - particle_filter_state(observations, n_particles?, process_noise?, measurement_noise?)
    - bocpd_detect(observations, hazard_rate?, threshold?) — Bayesian change point detection

    Causality:
    - lead_lag_analysis(series_a, series_b, max_lag?)
    - granger_test(x, y, max_lag?)
    - market_graph_analysis(corr_matrix, names, threshold?)

    Execution:
    - gp_optimal_execution(current_pos, target_pos, alpha_decay, temp_impact, perm_impact, risk_aversion, n_steps, dt)
    - ac_optimal_liquidation(total_shares, n_steps, volatility, perm_impact, temp_impact, risk_aversion)
    - queue_fill_probability(queue_size, position, arrival_rate, cancel_rate, time_horizon)

    Copula:
    - fit_copula(u, v, family?) — gaussian/student_t/clayton/gumbel/frank
    - best_copula(u, v) — best family by AIC
    - vine_copula_fit(data, vine_type?) — [ULTRA] vine copula
    - vine_tail_risk(data, vine_type?, threshold?, n_sim?) — [ULTRA] joint tail risk

    Portfolio Optimization:
    - cross_impact_matrix(returns_matrix, volume_matrix, names) — [ULTRA]
    - entropy_pooling(prior_probs, scenarios, views) — [ULTRA] Meucci entropy pooling
    - robust_portfolio(expected_returns, covariance, return_uncertainty, uncertainty_budget?) — [ULTRA]
    - optimal_exit(s0, mu, sigma, dt, n_steps, n_paths, strike) — Longstaff-Schwartz
    - hjb_optimal_quotes(max_inventory?, n_time_steps?, gamma?, sigma?, kappa?, alpha?, terminal_time?, current_inventory?, time_fraction?) — [ULTRA] Avellaneda-Stoikov

    Hedging:
    - hedge_analysis(spot_prices, hedge_prices, window?, position_size?)
    - hedge_scenario_analysis(spot_position, spot_price, hedge_position, hedge_price, spot_moves?, correlation?, hedge_vol?, spot_vol?)
    - multi_ticker_hedge(spot_returns, hedge_returns_matrix, tickers)
    - hedge_cost_summary() — hedge costs from running engine

    Pricing:
    - prediction_greeks(price, size, is_yes?, t_hours?, vol?) [PREDICTION MARKET] — binary market Greeks
    - logit_greeks(price, size, is_yes?) [PREDICTION MARKET] — logit-space Greeks
    - logit_reservation_price(mid, inventory, gamma, belief_vol, t?) [PREDICTION MARKET]
    - logit_optimal_spread(belief_vol, inventory, gamma, kappa, t?) [PREDICTION MARKET]
    - logit_pnl_decompose(entry_price, exit_price, size, is_yes?) [PREDICTION MARKET]
    - toxicity_adjusted_spread(base_spread, vpin, ofi, vpin_weight?, ofi_weight?)
    - binary_option_price(model, strike, time_to_expiry, s0?, r?) — heston/merton/vg
    - binary_price_heston(price, strike, t, vol, kappa?, theta?, xi?, rho?)
    - implied_vol_from_binary(binary_price, spot, strike, t)
    - build_options_chain(mid_price, n_strikes?, vol?, t_days?)
    - compute_vol_surface(prices, strikes, expirations)

    Bootstrap:
    - bootstrap_sharpe(returns, n_bootstrap?)
    - bootstrap_mean(data, n_bootstrap?)
    - bootstrap_var(returns, n_bootstrap?, confidence?)
    - bootstrap_edge(probs, prices, n_bootstrap?)
    - bootstrap_hypothesis_test(sample_a, sample_b, n_bootstrap?)

    Risk/Regime:
    - risk_neutral_density(prices, strikes)
    - implied_probability_between(prices, strikes, lower, upper)
    - cross_asset_edge(prices_a, strikes_a, prices_b, strikes_b)
    - yield_adjusted_kelly(prob, price, rfr, duration_days, fraction?)
    - correlation_regime(returns_a, returns_b, window?)
    - contagion_score(returns_matrix, window?)
    - beta_decompose(strategy_returns, benchmark_returns)
    - compute_index_level(prices, weights, base?)
    - index_tracking_error(index_levels, benchmark_levels)

    Other:
    - best_venue(bids, asks, venues)
    - vulnerability_score(returns)
    - evolution_optimize(param_names, param_mins, param_maxs, population_size?, generations?)
    - evaluate_trigger(condition, threshold, current_value) — condition: above/below/crosses
    - validate_multi_leg(market_ids, sides, prices, sizes)
    """
    return _dispatch(_ANALYTICS_TABLE, action, params)


_ANALYTICS_TABLE: dict[str, Any] = {
    # Statistics
    "shannon_entropy": tools.compute_shannon_entropy,
    "kl_divergence": tools.compute_kl_divergence,
    "hurst_exponent": tools.compute_hurst_exponent,
    "variance_ratio_test": tools.compute_variance_ratio,
    "cornish_fisher_var": tools.compute_cornish_fisher_var,
    "deflated_sharpe": tools.compute_deflated_sharpe,
    "hawkes_intensity": tools.compute_hawkes_intensity,
    "correlation_matrix": tools.compute_correlation_matrix,
    # Signals
    "signal_diagnostics": tools.run_signal_diagnostics,
    "market_efficiency_test": tools.run_market_efficiency,
    # Portfolio
    "portfolio_weights": tools.get_portfolio_weights,
    "simulate_portfolio": tools.simulate_portfolio,
    "stress_test": tools.run_stress_test,
    "generate_tearsheet": tools.generate_tearsheet_report,
    "bayesian_optimize": tools.run_bayesian_optimize,
    "update_params": tools.update_runtime_params,
    "get_params": lambda **kw: tools.get_runtime_params(),
    # AFML
    "tick_bars": tools.compute_tick_bars,
    "volume_bars": tools.compute_volume_bars,
    "dollar_bars": tools.compute_dollar_bars,
    "cusum_filter": tools.compute_cusum_filter,
    "triple_barrier_labels": tools.compute_triple_barrier,
    "frac_diff": tools.compute_frac_diff,
    "min_frac_diff": tools.compute_min_frac_diff,
    "hrp_weights": tools.compute_hrp_weights,
    "denoise_covariance": tools.compute_denoise_covariance,
    # Microstructure
    "invariance_analysis": tools.invariance_analysis_tool,
    "signal_selection": tools.signal_selection_tool,
    "duration_analysis": tools.duration_analysis_tool,
    "volatility_signature": tools.volatility_signature_tool,
    "two_scale_realized_vol": tools.two_scale_vol_tool,
    "cross_impact": tools.cross_impact_tool,
    # State Estimation
    "kalman_filter_state": tools.kalman_filter_state_tool,
    "particle_filter_state": tools.particle_filter_state_tool,
    "bocpd_detect": tools.bocpd_detect_tool,
    # Causality
    "lead_lag_analysis": tools.lead_lag_analysis_tool,
    "granger_test": tools.granger_test_tool,
    "market_graph_analysis": tools.market_graph_analysis_tool,
    # Execution
    "gp_optimal_execution": tools.gp_optimal_execution_tool,
    "ac_optimal_liquidation": tools.ac_optimal_liquidation_tool,
    "queue_fill_probability": tools.queue_fill_probability_tool,
    # Copula
    "fit_copula": tools.fit_copula_tool,
    "best_copula": tools.best_copula_tool,
    "vine_copula_fit": tools.vine_copula_fit_tool,
    "vine_tail_risk": tools.vine_tail_risk_tool,
    # Portfolio Optimization
    "cross_impact_matrix": tools.cross_impact_matrix_tool,
    "entropy_pooling": tools.entropy_pooling_tool,
    "robust_portfolio": tools.robust_portfolio_tool,
    "optimal_exit": tools.optimal_exit_tool,
    "hjb_optimal_quotes": tools.hjb_optimal_quotes_tool,
    # Hedging
    "hedge_analysis": tools.hedge_analysis,
    "hedge_scenario_analysis": tools.hedge_scenario_analysis,
    "multi_ticker_hedge": tools.multi_ticker_hedge_analysis,
    "hedge_cost_summary": lambda **kw: tools.hedge_cost_summary(),
    # Pricing
    "prediction_greeks": tools.compute_prediction_greeks,
    "logit_greeks": tools.logit_greeks_tool,
    "logit_reservation_price": tools.logit_reservation_price_tool,
    "logit_optimal_spread": tools.logit_optimal_spread_tool,
    "logit_pnl_decompose": tools.logit_pnl_decompose_tool,
    "toxicity_adjusted_spread": tools.toxicity_adjusted_spread_tool,
    "binary_option_price": tools.binary_option_price_tool,
    "binary_price_heston": tools.binary_price_heston_tool,
    "implied_vol_from_binary": tools.implied_vol_tool,
    "build_options_chain": tools.build_options_chain_tool,
    "compute_vol_surface": tools.vol_surface_tool,
    # Bootstrap
    "bootstrap_sharpe": tools.bootstrap_sharpe_tool,
    "bootstrap_mean": tools.bootstrap_mean_tool,
    "bootstrap_var": tools.bootstrap_var_tool,
    "bootstrap_edge": tools.bootstrap_edge_tool,
    "bootstrap_hypothesis_test": tools.bootstrap_hypothesis_tool,
    # Risk/Regime
    "risk_neutral_density": tools.risk_neutral_density_tool,
    "implied_probability_between": tools.implied_probability_tool,
    "cross_asset_edge": tools.cross_asset_edge_tool,
    "yield_adjusted_kelly": tools.yield_adjusted_kelly_tool,
    "correlation_regime": tools.correlation_regime_tool,
    "contagion_score": tools.contagion_score_tool,
    "beta_decompose": tools.beta_decompose_tool,
    "compute_index_level": tools.compute_index_level_tool,
    "index_tracking_error": tools.index_tracking_error_tool,
    # Other
    "best_venue": tools.best_venue_tool,
    "vulnerability_score": tools.vulnerability_score_tool,
    "evolution_optimize": tools.evolution_optimize_tool,
    "evaluate_trigger": tools.evaluate_trigger_tool,
    "validate_multi_leg": tools.validate_legs_tool,
}


# ===========================================================================
# Compound Tool: unusual_whales
# ===========================================================================

@mcp.tool()
def unusual_whales(action: str, params: str = "{}") -> dict | list:
    """Unusual Whales market intelligence. Actions:

    Flow:
    - options_flow(ticker?, min_premium?, is_sweep?, is_call?, is_put?, is_otm?, min_dte?, max_dte?, limit?) — unusual options alerts
    - stock_flow(ticker, side?, min_premium?) — options flow for a ticker
    - dark_pool(ticker?, date?, min_size?, limit?) — dark pool trades
    - market_tide(date?, otm_only?) — net premium flow sentiment
    - spike() — SPIKE volatility indicator

    Congress/Insider:
    - congress_trades(ticker?, date?, limit?) — Congress member trades
    - congress_trader(name) — trades for a specific Congress member
    - insider_trades(ticker?, min_value?, is_officer?, is_director?, is_ten_percent_owner?, start_date?, end_date?, limit?)

    Stock Data:
    - stock_info(ticker) — price, market cap, sector
    - stock_state(ticker) — current state
    - earnings(ticker) — earnings history
    - earnings_schedule(time?) — upcoming earnings (premarket/afterhours)
    - seasonality(ticker) — monthly seasonality

    Options Analytics:
    - greek_exposure(ticker) — aggregate GEX/DEX
    - greek_exposure_by_strike(ticker)
    - greek_exposure_by_expiry(ticker)
    - iv_rank(ticker) — IV rank percentile
    - vol_term_structure(ticker) — IV across expirations
    - max_pain(ticker)
    - option_chains(ticker) — full chains

    Short Interest:
    - short_interest(ticker) — short interest and float
    - short_volume(ticker) — short volume history
    - ftd(ticker) — failures to deliver

    Screeners:
    - screener_stocks() — multi-criteria stock screen
    - screener_options(limit?, min_premium?, is_otm?, min_volume_oi_ratio?)

    ETF:
    - etf_holdings(ticker) — ETF holdings breakdown
    - etf_flow(ticker) — inflow/outflow

    Institutions:
    - institutions() — list tracked institutions
    - institution_holdings(name) — holdings for institution
    - institution_ownership(ticker) — institutional ownership

    Calendars:
    - economic_calendar() — upcoming economic events
    - fda_calendar() — FDA calendar events

    Other:
    - news() — financial headlines
    - prediction_whales() — prediction market whales
    - prediction_unusual() — unusual prediction activity
    - crypto_whales() — crypto whale transactions
    """
    return _dispatch(_UW_TABLE, action, params)


def _uw_dark_pool(**kw):
    ticker = kw.get("ticker")
    if ticker:
        return provider_tools.uw_dark_pool(ticker, date=kw.get("date"), min_size=kw.get("min_size"), limit=kw.get("limit", 50))
    return provider_tools.uw_dark_pool_recent()


_UW_TABLE: dict[str, Any] = {
    "options_flow": lambda **kw: provider_tools.uw_options_flow(
        ticker=kw.get("ticker"), min_premium=kw.get("min_premium"), is_sweep=kw.get("is_sweep"),
        is_call=kw.get("is_call"), is_put=kw.get("is_put"), is_otm=kw.get("is_otm"),
        min_dte=kw.get("min_dte"), max_dte=kw.get("max_dte"), limit=kw.get("limit", 50),
    ),
    "stock_flow": lambda **kw: provider_tools.uw_stock_flow(kw["ticker"], side=kw.get("side"), min_premium=kw.get("min_premium")),
    "dark_pool": _uw_dark_pool,
    "market_tide": lambda **kw: provider_tools.uw_market_tide(date=kw.get("date"), otm_only=kw.get("otm_only")),
    "spike": lambda **kw: provider_tools.uw_spike(),
    "congress_trades": lambda **kw: provider_tools.uw_congress_trades(limit=kw.get("limit", 50), ticker=kw.get("ticker"), date=kw.get("date")),
    "congress_trader": lambda **kw: provider_tools.uw_congress_trader(kw["name"]),
    "insider_trades": lambda **kw: provider_tools.uw_insider_trades(
        ticker=kw.get("ticker"), min_value=kw.get("min_value"), is_officer=kw.get("is_officer"),
        is_director=kw.get("is_director"), is_ten_percent_owner=kw.get("is_ten_percent_owner"),
        start_date=kw.get("start_date"), end_date=kw.get("end_date"), limit=kw.get("limit", 50),
    ),
    "stock_info": lambda **kw: provider_tools.uw_stock_info(kw["ticker"]),
    "stock_state": lambda **kw: provider_tools.uw_stock_state(kw["ticker"]),
    "earnings": lambda **kw: provider_tools.uw_earnings(kw["ticker"]),
    "earnings_schedule": lambda **kw: provider_tools.uw_earnings_schedule(kw.get("time", "premarket")),
    "seasonality": lambda **kw: provider_tools.uw_seasonality(kw["ticker"]),
    "greek_exposure": lambda **kw: provider_tools.uw_greek_exposure(kw["ticker"]),
    "greek_exposure_by_strike": lambda **kw: provider_tools.uw_greek_exposure_by_strike(kw["ticker"]),
    "greek_exposure_by_expiry": lambda **kw: provider_tools.uw_greek_exposure_by_expiry(kw["ticker"]),
    "iv_rank": lambda **kw: provider_tools.uw_iv_rank(kw["ticker"]),
    "vol_term_structure": lambda **kw: provider_tools.uw_vol_term_structure(kw["ticker"]),
    "max_pain": lambda **kw: provider_tools.uw_max_pain(kw["ticker"]),
    "option_chains": lambda **kw: provider_tools.uw_option_chains(kw["ticker"]),
    "short_interest": lambda **kw: provider_tools.uw_short_interest(kw["ticker"]),
    "short_volume": lambda **kw: provider_tools.uw_short_volume(kw["ticker"]),
    "ftd": lambda **kw: provider_tools.uw_ftd(kw["ticker"]),
    "screener_stocks": lambda **kw: provider_tools.uw_screener_stocks(),
    "screener_options": lambda **kw: provider_tools.uw_screener_options(
        limit=kw.get("limit", 50), min_premium=kw.get("min_premium"),
        is_otm=kw.get("is_otm"), min_volume_oi_ratio=kw.get("min_volume_oi_ratio"),
    ),
    "etf_holdings": lambda **kw: provider_tools.uw_etf_holdings(kw["ticker"]),
    "etf_flow": lambda **kw: provider_tools.uw_etf_flow(kw["ticker"]),
    "institutions": lambda **kw: provider_tools.uw_institutions(),
    "institution_holdings": lambda **kw: provider_tools.uw_institution_holdings(kw["name"]),
    "institution_ownership": lambda **kw: provider_tools.uw_institution_ownership(kw["ticker"]),
    "economic_calendar": lambda **kw: provider_tools.uw_economic_calendar(),
    "fda_calendar": lambda **kw: provider_tools.uw_fda_calendar(),
    "news": lambda **kw: provider_tools.uw_news(),
    "prediction_whales": lambda **kw: provider_tools.uw_prediction_whales(),
    "prediction_unusual": lambda **kw: provider_tools.uw_prediction_unusual(),
    "crypto_whales": lambda **kw: provider_tools.uw_crypto_whales(),
}


# ===========================================================================
# Compound Tool: market_data
# ===========================================================================

@mcp.tool()
def market_data(action: str, params: str = "{}") -> dict | list:
    """Market data from Massive (Polygon.io). Actions:

    Price Data:
    - aggregates(ticker, from_date, to_date, multiplier?, timespan?, limit?) — OHLCV bars. timespan: second/minute/hour/day/week/month
    - snapshot(ticker) — real-time snapshot
    - last_trade(ticker) — most recent trade
    - last_quote(ticker) — most recent NBBO quote
    - previous_close(ticker) — previous day OHLCV
    - grouped_daily(date, adjusted?) — entire market OHLCV for a date

    Movers:
    - gainers_losers(direction?) — top gainers or losers
    - crypto_gainers_losers(direction?)

    Reference:
    - ticker_details(ticker) — name, market cap, sector
    - search_tickers(query?, market?, limit?) — search tickers (stocks/crypto/fx/otc)
    - market_status() — open/closed/early hours
    - market_holidays() — upcoming holidays

    Technical Indicators:
    - sma(ticker, timespan?, window?, limit?)
    - ema(ticker, timespan?, window?, limit?)
    - rsi(ticker, timespan?, window?, limit?)
    - macd(ticker, timespan?, limit?)

    Options:
    - options_chain(underlying, contract_type?, expiration_date?, expiration_date_gte?, strike_price_gte?, strike_price_lte?, limit?)
    - options_contracts(underlying_ticker?, contract_type?, expiration_date?, strike_price?, limit?)

    Other:
    - news(ticker?, limit?) — market news
    - dividends(ticker, limit?)
    - splits(ticker, limit?)
    - crypto_snapshot(ticker) — e.g. X:BTCUSD
    - forex_conversion(from_currency, to_currency)
    - forex_snapshot(ticker) — e.g. C:EURUSD
    """
    return _dispatch(_MASSIVE_TABLE, action, params)


_MASSIVE_TABLE: dict[str, Any] = {
    "aggregates": lambda **kw: provider_tools.massive_aggregates(
        kw["ticker"], kw.get("multiplier", 1), kw.get("timespan", "day"),
        kw["from_date"], kw["to_date"], limit=kw.get("limit", 5000),
    ),
    "snapshot": lambda **kw: provider_tools.massive_snapshot(kw["ticker"]),
    "last_trade": lambda **kw: provider_tools.massive_last_trade(kw["ticker"]),
    "last_quote": lambda **kw: provider_tools.massive_last_quote(kw["ticker"]),
    "previous_close": lambda **kw: provider_tools.massive_previous_close(kw["ticker"]),
    "grouped_daily": lambda **kw: provider_tools.massive_grouped_daily(kw["date"], adjusted=kw.get("adjusted", True)),
    "gainers_losers": lambda **kw: provider_tools.massive_gainers_losers(kw.get("direction", "gainers")),
    "crypto_gainers_losers": lambda **kw: provider_tools.massive_crypto_gainers_losers(kw.get("direction", "gainers")),
    "ticker_details": lambda **kw: provider_tools.massive_ticker_details(kw["ticker"]),
    "search_tickers": lambda **kw: provider_tools.massive_search_tickers(kw.get("query", ""), market=kw.get("market"), limit=kw.get("limit", 20)),
    "market_status": lambda **kw: provider_tools.massive_market_status(),
    "market_holidays": lambda **kw: provider_tools.massive_market_holidays(),
    "sma": lambda **kw: provider_tools.massive_sma(kw["ticker"], timespan=kw.get("timespan", "day"), window=kw.get("window", 50), limit=kw.get("limit", 50)),
    "ema": lambda **kw: provider_tools.massive_ema(kw["ticker"], timespan=kw.get("timespan", "day"), window=kw.get("window", 50), limit=kw.get("limit", 50)),
    "rsi": lambda **kw: provider_tools.massive_rsi(kw["ticker"], timespan=kw.get("timespan", "day"), window=kw.get("window", 14), limit=kw.get("limit", 50)),
    "macd": lambda **kw: provider_tools.massive_macd(kw["ticker"], timespan=kw.get("timespan", "day"), limit=kw.get("limit", 50)),
    "options_chain": lambda **kw: provider_tools.massive_options_chain(
        kw["underlying"], contract_type=kw.get("contract_type"), expiration_date=kw.get("expiration_date"),
        expiration_date_gte=kw.get("expiration_date_gte"),
        strike_price_gte=kw.get("strike_price_gte"), strike_price_lte=kw.get("strike_price_lte"),
        limit=kw.get("limit", 250),
    ),
    "options_contracts": lambda **kw: provider_tools.massive_options_contracts(
        underlying_ticker=kw.get("underlying_ticker"), contract_type=kw.get("contract_type"),
        expiration_date=kw.get("expiration_date"), strike_price=kw.get("strike_price"),
        limit=kw.get("limit", 100),
    ),
    "news": lambda **kw: provider_tools.massive_news(ticker=kw.get("ticker"), limit=kw.get("limit", 20)),
    "dividends": lambda **kw: provider_tools.massive_dividends(kw["ticker"], limit=kw.get("limit", 20)),
    "splits": lambda **kw: provider_tools.massive_splits(kw["ticker"], limit=kw.get("limit", 20)),
    "crypto_snapshot": lambda **kw: provider_tools.massive_crypto_snapshot(kw["ticker"]),
    "forex_conversion": lambda **kw: provider_tools.massive_forex_conversion(kw["from_currency"], kw["to_currency"]),
    "forex_snapshot": lambda **kw: provider_tools.massive_forex_snapshot(kw["ticker"]),
}


# ===========================================================================
# Compound Tool: cloud
# ===========================================================================

def _get_cloud():
    """Create a HorizonCloud client using HORIZON_API_KEY env var."""
    from horizon.cloud import HorizonCloud
    return HorizonCloud()


@mcp.tool()
def cloud(action: str, params: str = "{}") -> dict:
    """Horizon Cloud deployment and management. All actions use HORIZON_API_KEY env var. Actions:

    - list_strategies() — list deployed strategies (id, name, status)
    - get_strategy(strategy_id) — detailed strategy info
    - create_strategy(name, code, description?) — create from Python code (must use hz.run())
    - validate(strategy_id) — static + sandbox validation (required before deploy)
    - list_credentials() — list saved exchange credentials (metadata only)
    - save_credentials(label?, exchange?) — save exchange credentials from env var (POLYMARKET_PRIVATE_KEY or KALSHI_API_KEY)
    - deploy(strategy_id, credential_id, mode?, markets?) — deploy strategy. mode: paper/live. markets: comma-separated slugs
    - stop(strategy_id) — stop all deployments
    - status(strategy_id) — deployment status (pending/running/stopped/error)
    - metrics(strategy_id, limit?) — performance metrics (PnL, Sharpe, drawdown)
    - logs(strategy_id, limit?, level?) — deployment logs. level: info/error/warning
    - account() — plan info, usage counts
    """
    try:
        kwargs = json.loads(params) if params and params != "{}" else {}
    except json.JSONDecodeError as e:
        return {"error": f"Invalid params JSON: {e}"}

    try:
        if action == "list_strategies":
            return {"strategies": _get_cloud().list_strategies()}
        elif action == "get_strategy":
            return _get_cloud().get_strategy(kwargs["strategy_id"])
        elif action == "create_strategy":
            return _get_cloud().create_strategy(
                name=kwargs["name"], code=kwargs["code"], description=kwargs.get("description", ""),
            )
        elif action == "validate":
            return _get_cloud().validate(kwargs["strategy_id"])
        elif action == "list_credentials":
            return {"credentials": _get_cloud().list_credentials()}
        elif action == "save_credentials":
            exchange = kwargs.get("exchange", "polymarket")
            private_key = os.environ.get("POLYMARKET_PRIVATE_KEY", "")
            if exchange == "kalshi":
                private_key = os.environ.get("KALSHI_API_KEY", private_key)
            if not private_key:
                env_var = "POLYMARKET_PRIVATE_KEY" if exchange == "polymarket" else "KALSHI_API_KEY"
                return {"error": f"Set {env_var} env var before calling this action."}
            return _get_cloud().save_credentials(
                private_key=private_key, label=kwargs.get("label", "Default"), exchange=exchange,
            )
        elif action == "deploy":
            cloud_client = _get_cloud()
            markets_str = kwargs.get("markets", "")
            market_list = [m.strip() for m in markets_str.split(",") if m.strip()] if markets_str else None
            return cloud_client.deploy(
                kwargs["strategy_id"], credential_id=kwargs["credential_id"],
                mode=kwargs.get("mode", "paper"), markets=market_list,
            )
        elif action == "stop":
            return _get_cloud().stop(kwargs["strategy_id"])
        elif action == "status":
            return _get_cloud().status(kwargs["strategy_id"])
        elif action == "metrics":
            return _get_cloud().metrics(kwargs["strategy_id"], limit=kwargs.get("limit", 50))
        elif action == "logs":
            level = kwargs.get("level", "")
            return {"logs": _get_cloud().logs(kwargs["strategy_id"], limit=kwargs.get("limit", 100), level=level or None)}
        elif action == "account":
            return _get_cloud().account()
        else:
            return {"error": f"Unknown action '{action}'. Available: list_strategies, get_strategy, create_strategy, validate, list_credentials, save_credentials, deploy, stop, status, metrics, logs, account"}
    except Exception as e:
        return {"error": str(e)}


# ===========================================================================
# Compound Tool: marketplace
# ===========================================================================

def _get_marketplace():
    from horizon.marketplace import Marketplace
    return Marketplace()


@mcp.tool()
def marketplace(action: str, params: str = "{}") -> dict:
    """Horizon strategy marketplace. Actions:

    Browse:
    - browse(query?, mode?, exchange?, sort_by?, limit?) — search listings. mode: signal/package. sort_by: sharpe/pnl/subscribers/price/newest
    - get_listing(listing_id) — full listing details
    - leaderboard(timeframe?, limit?) — top strategies. timeframe: 7d/30d/90d/all

    Publish:
    - publish(strategy_id, mode?, price?, description?, tags?, exchange?, max_sales?) — publish to marketplace. mode: signal (copy trading) or package (code sale). 90/10 revenue split
    - my_listings() — your published listings
    - listing_earnings(listing_id) — earnings breakdown

    Subscribe (signal mode):
    - subscribe(listing_id, size_scale?, max_position?) — subscribe to signals
    - unsubscribe(subscription_id)
    - my_subscriptions() — list subscriptions
    - signals(subscription_id, limit?) — recent signals

    Purchase (package mode):
    - purchase(listing_id) — buy listing (returns checkout_url)
    - my_purchases() — list purchases

    Payments:
    - connect_payments() — start Stripe Connect onboarding
    - payment_status() — check Stripe Connect status

    Verification:
    - verify_performance(listing_id) — request Verified Performance badge
    - listing_badges(listing_id) — badge details
    - verify_trader(exchange, wallet_address?, credential_id?) — start Verified Trader verification
    - verification_status() — check verification progress
    """
    try:
        kwargs = json.loads(params) if params and params != "{}" else {}
    except json.JSONDecodeError as e:
        return {"error": f"Invalid params JSON: {e}"}

    try:
        mp = _get_marketplace()

        if action == "browse":
            listings = mp.browse(
                query=kwargs.get("query", ""), mode=kwargs.get("mode") or None,
                exchange=kwargs.get("exchange") or None, sort_by=kwargs.get("sort_by", "sharpe"),
                limit=kwargs.get("limit", 20),
            )
            return {"listings": [
                {"id": l.id, "name": l.name, "mode": l.mode, "price": l.price,
                 "author": l.author_name, "sharpe": l.sharpe_ratio,
                 "total_pnl": l.total_pnl, "win_rate": l.win_rate,
                 "subscribers": l.total_subscribers, "exchange": l.exchange,
                 "tags": l.tags, "status": l.status, "description": l.description[:200]}
                for l in listings
            ]}
        elif action == "get_listing":
            l = mp.get_listing(kwargs["listing_id"])
            return {
                "id": l.id, "name": l.name, "mode": l.mode, "price": l.price,
                "currency": l.currency, "author": l.author_name,
                "description": l.description, "tags": l.tags,
                "exchange": l.exchange, "markets": l.markets,
                "max_sales": l.max_sales, "status": l.status,
                "sharpe": l.sharpe_ratio, "total_pnl": l.total_pnl,
                "max_drawdown": l.max_drawdown, "win_rate": l.win_rate,
                "subscribers": l.total_subscribers, "avg_monthly_return": l.avg_monthly_return,
                "live_since": l.live_since, "created_at": l.created_at,
            }
        elif action == "leaderboard":
            listings = mp.leaderboard(timeframe=kwargs.get("timeframe", "30d"), limit=kwargs.get("limit", 20))
            return {"leaderboard": [
                {"id": l.id, "name": l.name, "author": l.author_name,
                 "sharpe": l.sharpe_ratio, "total_pnl": l.total_pnl,
                 "win_rate": l.win_rate, "subscribers": l.total_subscribers,
                 "price": l.price, "mode": l.mode}
                for l in listings
            ]}
        elif action == "publish":
            tags_str = kwargs.get("tags", "")
            tag_list = [t.strip() for t in tags_str.split(",") if t.strip()] if tags_str else None
            max_sales = kwargs.get("max_sales", 0)
            listing = mp.publish(
                kwargs["strategy_id"], mode=kwargs.get("mode", "signal"),
                price=kwargs.get("price", 0.0), description=kwargs.get("description", ""),
                tags=tag_list, exchange=kwargs.get("exchange", ""),
                max_sales=max_sales if max_sales > 0 else None,
            )
            return {"id": listing.id, "name": listing.name, "mode": listing.mode, "price": listing.price, "status": listing.status}
        elif action == "my_listings":
            listings = mp.my_listings()
            return {"listings": [
                {"id": l.id, "name": l.name, "mode": l.mode, "price": l.price,
                 "status": l.status, "subscribers": l.total_subscribers,
                 "total_pnl": l.total_pnl, "sharpe": l.sharpe_ratio}
                for l in listings
            ]}
        elif action == "listing_earnings":
            e = mp.listing_earnings(kwargs["listing_id"])
            return {
                "listing_id": e.listing_id, "total_revenue": e.total_revenue,
                "author_share": e.author_share, "platform_fee": e.platform_fee,
                "total_subscribers": e.total_subscribers, "total_purchases": e.total_purchases,
                "currency": e.currency,
            }
        elif action == "subscribe":
            sub = mp.subscribe(kwargs["listing_id"], size_scale=kwargs.get("size_scale", 1.0), max_position=kwargs.get("max_position", 1000.0))
            return {"id": sub.id, "listing_name": sub.listing_name, "status": sub.status, "size_scale": sub.size_scale, "max_position": sub.max_position}
        elif action == "unsubscribe":
            return mp.unsubscribe(kwargs["subscription_id"])
        elif action == "my_subscriptions":
            subs = mp.my_subscriptions()
            return {"subscriptions": [
                {"id": s.id, "listing_name": s.listing_name, "status": s.status,
                 "size_scale": s.size_scale, "total_signals": s.total_signals, "total_pnl": s.total_pnl}
                for s in subs
            ]}
        elif action == "signals":
            signals = mp.signals(kwargs["subscription_id"], limit=kwargs.get("limit", 50))
            return {"signals": [
                {"id": s.id, "market_id": s.market_id, "side": s.side,
                 "order_side": s.order_side, "price": s.price,
                 "size": s.size, "timestamp": s.timestamp}
                for s in signals
            ]}
        elif action == "purchase":
            p = mp.purchase(kwargs["listing_id"])
            return {"id": p.id, "listing_name": p.listing_name, "status": p.status, "checkout_url": p.checkout_url, "license_key": p.license_key}
        elif action == "my_purchases":
            purchases = mp.my_purchases()
            return {"purchases": [
                {"id": p.id, "listing_name": p.listing_name, "status": p.status,
                 "purchased_at": p.purchased_at, "expires_at": p.expires_at}
                for p in purchases
            ]}
        elif action == "connect_payments":
            return mp.connect_payments()
        elif action == "payment_status":
            return mp.payment_status()
        elif action == "verify_performance":
            vp = mp.verify_performance(kwargs["listing_id"])
            return {
                "verified": vp.verified, "verified_at": vp.verified_at,
                "sharpe": vp.sharpe, "total_pnl": vp.total_pnl,
                "win_rate": vp.win_rate, "max_drawdown": vp.max_drawdown,
                "total_trades": vp.total_trades, "measurement_period_days": vp.measurement_period_days,
            }
        elif action == "listing_badges":
            return mp.listing_badges(kwargs["listing_id"])
        elif action == "verify_trader":
            vr = mp.verify_trader(
                kwargs["exchange"],
                wallet_address=kwargs.get("wallet_address") or None,
                credential_id=kwargs.get("credential_id") or None,
            )
            return {"id": vr.id, "type": vr.type, "exchange": vr.exchange, "status": vr.status, "created_at": vr.created_at}
        elif action == "verification_status":
            requests = mp.verification_status()
            return {"requests": [
                {"id": r.id, "type": r.type, "exchange": r.exchange, "status": r.status,
                 "error_message": r.error_message, "created_at": r.created_at, "completed_at": r.completed_at}
                for r in requests
            ]}
        else:
            return {"error": f"Unknown action '{action}'. Available: browse, get_listing, leaderboard, publish, my_listings, listing_earnings, subscribe, unsubscribe, my_subscriptions, signals, purchase, my_purchases, connect_payments, payment_status, verify_performance, listing_badges, verify_trader, verification_status"}
    except Exception as e:
        return {"error": str(e)}


# ===========================================================================
# Compound Tool: fund
# ===========================================================================

@mcp.tool()
def fund(action: str, params: str = "{}") -> dict:
    """Multi-strategy fund management (requires HORIZON_FUND_MODE=1). Actions:

    Status:
    - status() — NAV, drawdown, strategy count, kill switch
    - report() — full fund report
    - risk_dashboard() — VaR budget, correlations, execution quality
    - stress_test() — fund-level stress scenarios

    Strategies:
    - deploy_strategy(name, markets, mode?) — deploy to fund. mode: paper/live
    - stop_strategy(name)
    - pause_strategy(name)
    - resume_strategy(name)
    - list_strategies() — all strategies with state, capital, markets
    - scale_strategy(name, new_capital) — adjust capital allocation

    Analytics:
    - nav_history(limit?) — NAV time series
    - pnl_attribution() — per-strategy P&L breakdown
    - correlation_matrix() — cross-strategy correlations
    - execution_report() — fill rates, slippage, adverse selection

    Memory:
    - memory_query(category?, key_contains?, limit?) — query persistent memory. categories: strategy_outcome, market_pattern, regime_mapping, edge_decay, failure_reason
    - memory_record(category, key, value, confidence?) — record an observation
    """
    return _dispatch({
        "status": lambda **kw: tools.fund_status(),
        "report": lambda **kw: tools.fund_report(),
        "risk_dashboard": lambda **kw: tools.fund_risk_dashboard(),
        "stress_test": lambda **kw: tools.fund_stress_test(),
        "deploy_strategy": lambda **kw: tools.fund_deploy_strategy(kw["name"], kw["markets"], kw.get("mode", "paper")),
        "stop_strategy": lambda **kw: tools.fund_stop_strategy(kw["name"]),
        "pause_strategy": lambda **kw: tools.fund_pause_strategy(kw["name"]),
        "resume_strategy": lambda **kw: tools.fund_resume_strategy(kw["name"]),
        "list_strategies": lambda **kw: tools.fund_list_strategies(),
        "scale_strategy": lambda **kw: tools.fund_scale_strategy(kw["name"], kw["new_capital"]),
        "nav_history": lambda **kw: tools.fund_nav_history(kw.get("limit", 50)),
        "pnl_attribution": lambda **kw: tools.fund_pnl_attribution(),
        "correlation_matrix": lambda **kw: tools.fund_correlation_matrix(),
        "execution_report": lambda **kw: tools.fund_execution_report(),
        "memory_query": lambda **kw: tools.fund_memory_query(kw.get("category"), kw.get("key_contains"), kw.get("limit", 20)),
        "memory_record": lambda **kw: tools.fund_memory_record(kw["category"], kw["key"], kw["value"], kw.get("confidence", 0.5)),
    }, action, params)


# ===========================================================================
# Compound Tool: account
# ===========================================================================

@mcp.tool()
def account(action: str, params: str = "{}") -> dict:
    """Horizon account and credentials. Actions:

    - setup(email, name?) — create account + generate SDK key. Set HORIZON_PASSWORD env var first
    - login(email) — login + generate new SDK key. Set HORIZON_PASSWORD env var first
    - key_status() — check if SDK credentials are configured
    """
    return _dispatch({
        "setup": lambda **kw: tools.horizon_setup(kw["email"], "", kw.get("name", "")),
        "login": lambda **kw: tools.horizon_login(kw["email"], ""),
        "key_status": lambda **kw: tools.horizon_key_status(),
    }, action, params)


# ===========================================================================
# Compound Tool: equity
# ===========================================================================

@mcp.tool()
def equity(action: str, params: str = "{}") -> dict | list:
    """Equity and options tools.

    Actions:
    - quote(symbol) — stock quote via Unusual Whales
    - search(query) — screen stocks
    - options_chain(symbol) — options chain
    - greeks(symbol) — Greek exposure
    - iv_surface(symbol) — IV term structure
    - screener() — stock screener
    """
    import json as _json
    p = _json.loads(params) if isinstance(params, str) else params
    try:
        from horizon import provider_tools as pt
        if action == "quote":
            return pt.uw_stock_info(p["symbol"].upper())
        elif action == "search":
            result = pt.uw_screener_stocks()
            if isinstance(result, list) and "query" in p:
                q = p["query"].lower()
                result = [r for r in result if q in str(r).lower()][:p.get("limit", 20)]
            return result
        elif action == "options_chain":
            return pt.uw_option_chains(p["symbol"].upper())
        elif action == "greeks":
            return pt.uw_greek_exposure(p["symbol"].upper())
        elif action == "iv_surface":
            return pt.uw_vol_term_structure(p["symbol"].upper())
        elif action == "screener":
            return pt.uw_screener_stocks()
        else:
            return {"error": f"Unknown equity action: {action}"}
    except KeyError as e:
        return {"error": f"Missing required parameter: {e}"}
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(transport: str = "stdio") -> None:
    """Run the MCP server.

    Validates the SDK key at startup. For HTTP transport, a valid SDK key
    is required (no separate MCP token needed).
    """
    _validate_startup_auth()
    mcp.run(transport=transport)
