# horizon-sdk

Prediction market trading SDK. Discover markets, trade, analyze wallets, and manage funds from the CLI.

## Quick Start

```bash
# Run without installing (requires uv or pipx)
bunx horizon-sdk discover "election"
npx horizon-sdk top-markets --json

# Or install permanently
uv tool install horizon-sdk   # Python package with Rust core
horizon discover "bitcoin"
```

## Requirements

This is a thin npm wrapper that delegates to the Python `horizon-sdk` package. You need one of:

- **[uv](https://docs.astral.sh/uv/)** (recommended) - `uvx` runs it without install
- **pip** - `pip install horizon-sdk`
- **pipx** - `pipx install horizon-sdk`

## Commands

```bash
horizon discover "election"                    # Search markets
horizon top-markets --limit 5                  # Trending markets
horizon kelly --prob 0.65 --price 0.50         # Position sizing
horizon wallet value 0x1234...                 # Wallet analytics
horizon submit --market-id X --side buy        # Place orders
horizon fund status                            # Fund management
horizon --json discover "bitcoin" | jq .       # JSON output
```

54 commands across discovery, trading, wallet analytics, feeds, fund management, and more.

## Links

- [Documentation](https://docs.mathematicalcompany.com)
- [GitHub](https://github.com/Jesusmanuelrg/horizon_sdk)
- [PyPI](https://pypi.org/project/horizon-sdk/)
