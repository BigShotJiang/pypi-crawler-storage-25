"""Tests for the Horizon Swarm system."""

from __future__ import annotations

import asyncio
import json
import time
import threading
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from horizon.swarm._types import (
    AgentPhase,
    AgentState,
    AgentStatus,
    CircuitBreakerState,
    Proposal,
    ProposalVerdict,
    SwarmConfig,
    SwarmEvent,
    SwarmEventType,
)
from horizon.swarm._event_bus import EventBus
from horizon.swarm._engine_pool import EnginePool
from horizon.swarm._circuit_breaker import CircuitBreaker
from horizon.swarm._mcp_tools import (
    AgentToolServer,
    HiveToolServer,
    _build_tool_schema,
    _sharpe,
    _norm_cdf,
    _norm_ppf,
)


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture
def config():
    return SwarmConfig(
        api_key="test-key",
        max_agents=5,
        max_capital_usd=10_000,
        max_drawdown_pct=0.10,
        max_daily_loss_usd=500,
        ws_host="127.0.0.1",
        ws_port=0,  # OS-assigned port for tests
        exchange_backend="paper",
    )


@pytest.fixture
def engine_pool(config):
    pool = EnginePool(config)
    yield pool
    pool.shutdown()


# --------------------------------------------------------------------------- #
# Types tests
# --------------------------------------------------------------------------- #

class TestTypes:
    def test_agent_phase_values(self):
        assert AgentPhase.RESEARCHING.value == "researching"
        assert AgentPhase.ROBUSTNESS.value == "robustness"
        assert AgentPhase.EXECUTING.value == "executing"

    def test_agent_status_values(self):
        assert AgentStatus.RUNNING.value == "running"
        assert AgentStatus.KILLED.value == "killed"

    def test_proposal_verdict_values(self):
        assert ProposalVerdict.APPROVED.value == "approved"
        assert ProposalVerdict.REJECTED.value == "rejected"

    def test_swarm_event_to_dict(self):
        event = SwarmEvent(
            type=SwarmEventType.AGENT_SPAWNED,
            source="agent_001",
            data={"mission": "test"},
            timestamp=1000.0,
        )
        d = event.to_dict()
        assert d["type"] == "agent_spawned"
        assert d["source"] == "agent_001"
        assert d["data"] == {"mission": "test"}
        assert d["timestamp"] == 1000.0

    def test_agent_state_to_dict(self):
        state = AgentState(
            agent_id="agent_001",
            phase=AgentPhase.ANALYZING,
            status=AgentStatus.RUNNING,
            mission="Find alpha",
            capital_allocated=1000.0,
            pnl=42.5,
            trades=7,
        )
        d = state.to_dict()
        assert d["agent_id"] == "agent_001"
        assert d["phase"] == "analyzing"
        assert d["status"] == "running"
        assert d["pnl"] == 42.5
        assert d["trades"] == 7

    def test_swarm_config_defaults(self):
        config = SwarmConfig(api_key="key")
        assert config.max_agents == 20
        assert config.max_capital_usd == 10_000.0
        assert config.max_drawdown_pct == 0.10
        assert config.hive_model == "anthropic/claude-sonnet-4.6"
        assert config.agent_model == "openai/gpt-5.4-mini"
        assert config.api_base == "https://openrouter.ai/api/v1"

    def test_circuit_breaker_state_defaults(self):
        state = CircuitBreakerState()
        assert state.active is False
        assert state.reason is None
        assert state.portfolio_drawdown_pct == 0.0

    def test_proposal_creation(self):
        p = Proposal(
            proposal_id="prop_1",
            agent_id="agent_001",
            hypothesis="Markets underestimate rain",
            market_id="rain-2026",
            side="yes",
            edge_estimate=0.05,
            kelly_fraction=0.1,
            requested_capital=500,
            backtest_results={"sharpe": 1.5},
            robustness_results={"all_passed": True},
            reasoning="Weather models say so",
            anti_overfitting_proof={},
            timestamp=time.time(),
        )
        assert p.verdict is None
        assert p.verdict_reasoning is None

    def test_swarm_event_type_completeness(self):
        """All event types should be string enums."""
        for evt in SwarmEventType:
            assert isinstance(evt.value, str)
        assert len(SwarmEventType) >= 20


# --------------------------------------------------------------------------- #
# Engine Pool tests
# --------------------------------------------------------------------------- #

class TestEnginePool:
    def test_acquire_engine(self, engine_pool):
        engine = engine_pool.acquire("agent_001", capital=1000.0)
        assert engine is not None
        assert engine_pool.active_count == 1

    def test_acquire_same_engine_twice(self, engine_pool):
        e1 = engine_pool.acquire("agent_001", capital=1000.0)
        e2 = engine_pool.acquire("agent_001", capital=2000.0)
        assert e1 is e2  # Same engine returned

    def test_release_engine(self, engine_pool):
        engine_pool.acquire("agent_001", capital=1000.0)
        assert engine_pool.active_count == 1
        engine_pool.release("agent_001")
        assert engine_pool.active_count == 0

    def test_release_nonexistent(self, engine_pool):
        engine_pool.release("nonexistent")  # Should not raise

    def test_get_engine(self, engine_pool):
        assert engine_pool.get_engine("agent_001") is None
        engine_pool.acquire("agent_001", capital=1000.0)
        assert engine_pool.get_engine("agent_001") is not None

    def test_multiple_engines(self, engine_pool):
        engine_pool.acquire("agent_001", capital=1000.0)
        engine_pool.acquire("agent_002", capital=2000.0)
        engine_pool.acquire("agent_003", capital=3000.0)
        assert engine_pool.active_count == 3
        engines = engine_pool.get_all_engines()
        assert len(engines) == 3

    def test_shutdown(self, engine_pool):
        engine_pool.acquire("agent_001", capital=1000.0)
        engine_pool.acquire("agent_002", capital=2000.0)
        engine_pool.shutdown()
        assert engine_pool.active_count == 0

    def test_aggregate_pnl(self, engine_pool):
        engine_pool.acquire("agent_001", capital=1000.0)
        # Fresh engines have 0 PnL
        assert engine_pool.aggregate_pnl() == 0.0

    def test_aggregate_positions(self, engine_pool):
        engine_pool.acquire("agent_001", capital=1000.0)
        positions = engine_pool.aggregate_positions()
        assert isinstance(positions, list)

    def test_cancel_all_orders(self, engine_pool):
        engine_pool.acquire("agent_001", capital=1000.0)
        total = engine_pool.cancel_all_orders()
        assert total == 0  # No orders to cancel

    def test_thread_safety(self, engine_pool):
        """Concurrent acquire/release should not crash."""
        errors = []

        def worker(i):
            try:
                agent_id = f"agent_{i:03d}"
                engine_pool.acquire(agent_id, capital=100.0)
                engine_pool.get_engine(agent_id)
                engine_pool.release(agent_id)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0


# --------------------------------------------------------------------------- #
# Event Bus tests
# --------------------------------------------------------------------------- #

class TestEventBus:
    @pytest.mark.asyncio
    async def test_start_stop(self):
        pytest.importorskip("websockets")
        bus = EventBus(host="127.0.0.1", port=0)
        await bus.start()
        assert bus._running is True
        await bus.stop()
        assert bus._running is False

    def test_get_history_empty(self):
        bus = EventBus()
        assert bus.get_history("agents") == []

    def test_publish_sync_without_running(self):
        bus = EventBus()
        # Should not raise
        bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.HEARTBEAT,
            source="test",
            data={},
            timestamp=time.time(),
        ))


# --------------------------------------------------------------------------- #
# MCP Tools tests
# --------------------------------------------------------------------------- #

class TestMCPTools:
    def test_build_tool_schema(self):
        def example_fn(name: str, count: int = 5, active: bool = True) -> dict:
            pass
        schema = _build_tool_schema(example_fn)
        assert schema["type"] == "object"
        assert "name" in schema["properties"]
        assert "count" in schema["properties"]
        assert "active" in schema["properties"]
        assert "name" in schema["required"]
        assert "count" not in schema["required"]

    def test_sharpe_calculation(self):
        # Positive returns should give positive Sharpe
        returns = [0.01, 0.02, 0.01, 0.03, 0.01, 0.02, 0.01, 0.02, 0.01, 0.03]
        sr = _sharpe(returns)
        assert sr > 0

    def test_sharpe_negative(self):
        returns = [-0.01, -0.02, -0.01, -0.03, -0.01]
        sr = _sharpe(returns)
        assert sr < 0

    def test_sharpe_empty(self):
        assert _sharpe([]) == 0.0
        assert _sharpe([0.01]) == 0.0

    def test_norm_cdf(self):
        assert abs(_norm_cdf(0.0) - 0.5) < 0.01
        assert _norm_cdf(3.0) > 0.99
        assert _norm_cdf(-3.0) < 0.01

    def test_norm_ppf(self):
        assert abs(_norm_ppf(0.5)) < 0.01
        assert _norm_ppf(0.975) > 1.5
        assert _norm_ppf(0.025) < -1.5

    def test_agent_tool_server_creation(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        defs = server.tool_definitions
        assert len(defs) > 0
        # Check swarm-specific tools exist
        tool_names = {d["name"] for d in defs}
        assert "transition_phase" in tool_names
        assert "submit_proposal" in tool_names
        assert "share_insight" in tool_names
        assert "run_deflated_sharpe" in tool_names
        assert "run_walk_forward" in tool_names
        assert "run_cpcv_pbo" in tool_names
        assert "run_bootstrap_robustness" in tool_names
        assert "run_structural_validation" in tool_names

    @pytest.mark.asyncio
    async def test_transition_phase(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        result = await server.call_tool("transition_phase", {
            "new_phase": "analyzing",
            "reason": "done researching",
        })
        assert result["status"] == "ok"
        assert result["new_phase"] == "analyzing"
        assert server._phase == AgentPhase.ANALYZING

    @pytest.mark.asyncio
    async def test_deflated_sharpe_gate(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        result = await server.call_tool("run_deflated_sharpe", {
            "observed_sharpe": 3.0,
            "n_strategies_tested": 5,
            "n_observations": 500,
        })
        assert result["gate"] == "deflated_sharpe"
        assert "passed" in result
        assert "p_value" in result

    @pytest.mark.asyncio
    async def test_walk_forward_gate(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        returns = [0.01 * (1 if i % 3 != 0 else -1) for i in range(200)]
        result = await server.call_tool("run_walk_forward", {
            "returns": returns,
            "n_splits": 5,
        })
        assert result["gate"] == "walk_forward"
        assert "avg_oos_sharpe" in result

    @pytest.mark.asyncio
    async def test_cpcv_pbo_gate(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        returns = [0.005 + 0.001 * (i % 7) for i in range(120)]
        result = await server.call_tool("run_cpcv_pbo", {
            "returns": returns,
            "n_groups": 6,
        })
        assert result["gate"] == "cpcv_pbo"
        assert "pbo" in result

    @pytest.mark.asyncio
    async def test_bootstrap_robustness_gate(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        returns = [0.01, 0.02, -0.005, 0.015, 0.01, -0.003, 0.02, 0.01,
                   0.005, 0.015, 0.02, -0.01, 0.01, 0.025, -0.005, 0.01,
                   0.02, 0.01, -0.005, 0.015, 0.01, -0.003, 0.02, 0.01]
        result = await server.call_tool("run_bootstrap_robustness", {
            "returns": returns,
            "n_samples": 100,
        })
        assert result["gate"] == "bootstrap_robustness"
        assert "p_sharpe_positive" in result
        assert "mc_profitable_pct" in result

    @pytest.mark.asyncio
    async def test_structural_validation_gate(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        result = await server.call_tool("run_structural_validation", {
            "hypothesis": "Fed rate markets systematically underestimate tail risk due to anchoring bias",
            "regime_results": {
                "low_vol": {"sharpe": 1.2},
                "high_vol": {"sharpe": 0.8},
            },
        })
        assert result["gate"] == "structural_validation"
        assert result["passed"] is True
        assert result["multi_regime"] is True
        assert result["n_regimes"] == 2

    @pytest.mark.asyncio
    async def test_structural_validation_fails_short_hypothesis(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        result = await server.call_tool("run_structural_validation", {
            "hypothesis": "buy low sell high",
            "regime_results": {"bull": {"sharpe": 2.0}},
        })
        assert result["passed"] is False  # Short hypothesis + only 1 regime

    @pytest.mark.asyncio
    async def test_submit_proposal(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        queue = []
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=queue,
            directive_queue=[],
        )
        result = await server.call_tool("submit_proposal", {
            "hypothesis": "Test hypothesis with enough detail here",
            "market_id": "test-market",
            "side": "yes",
            "edge_estimate": 0.05,
            "kelly_fraction": 0.1,
            "requested_capital": 500,
            "backtest_results": {"sharpe": 1.5},
            "robustness_results": {},
            "reasoning": "Test reasoning",
            "anti_overfitting_proof": {},
        })
        assert result["status"] == "submitted"
        assert len(queue) == 1

    @pytest.mark.asyncio
    async def test_get_hive_directives(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        directives = ["Focus on Kalshi", "Reduce exposure"]
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=directives,
        )
        result = await server.call_tool("get_hive_directives", {})
        assert len(result["directives"]) == 2
        assert len(directives) == 0  # Drained

    @pytest.mark.asyncio
    async def test_unknown_tool(self, engine_pool, config):
        engine = engine_pool.acquire("agent_test", capital=1000.0)
        bus = EventBus()
        server = AgentToolServer(
            agent_id="agent_test",
            engine=engine,
            event_bus=bus,
            knowledge_graph=None,
            proposal_queue=[],
            directive_queue=[],
        )
        result = await server.call_tool("nonexistent_tool", {})
        assert "error" in result


# --------------------------------------------------------------------------- #
# Circuit Breaker tests
# --------------------------------------------------------------------------- #

class TestCircuitBreaker:
    def test_creation(self, config, engine_pool):
        cb = CircuitBreaker(config=config, engine_pool=engine_pool, event_bus=EventBus())
        assert cb.state.active is False
        assert cb.state.checks_run == 0

    def test_start_stop(self, config, engine_pool):
        cb = CircuitBreaker(config=config, engine_pool=engine_pool, event_bus=EventBus())
        cb.start()
        assert cb._thread is not None
        assert cb._thread.is_alive()
        cb.stop()

    def test_trigger(self, config, engine_pool):
        bus = EventBus()
        cb = CircuitBreaker(config=config, engine_pool=engine_pool, event_bus=bus)
        cb._trigger("Test breach")
        assert cb.state.active is True
        assert cb.state.reason == "Test breach"
        assert cb.state.triggered_at is not None

    def test_trigger_idempotent(self, config, engine_pool):
        bus = EventBus()
        cb = CircuitBreaker(config=config, engine_pool=engine_pool, event_bus=bus)
        cb._trigger("First")
        cb._trigger("Second")  # Should be ignored
        assert cb.state.reason == "First"

    def test_reset(self, config, engine_pool):
        bus = EventBus()
        cb = CircuitBreaker(config=config, engine_pool=engine_pool, event_bus=bus)
        cb._trigger("Test")
        assert cb.state.active is True
        cb.reset()
        assert cb.state.active is False
        assert cb.state.reason is None

    def test_heartbeat_recording(self, config, engine_pool):
        bus = EventBus()
        cb = CircuitBreaker(config=config, engine_pool=engine_pool, event_bus=bus)
        cb.record_heartbeat("agent_001")
        assert "agent_001" in cb._last_heartbeat

    def test_check_with_no_agents(self, config, engine_pool):
        bus = EventBus()
        cb = CircuitBreaker(config=config, engine_pool=engine_pool, event_bus=bus)
        cb._check()  # Should not crash
        assert cb.state.checks_run == 1


# --------------------------------------------------------------------------- #
# Prompt tests
# --------------------------------------------------------------------------- #

class TestPrompts:
    def test_agent_system_prompt(self):
        from horizon.swarm._prompt import get_agent_system_prompt
        state = AgentState(
            agent_id="agent_001",
            phase=AgentPhase.RESEARCHING,
            status=AgentStatus.RUNNING,
            mission="Find alpha in weather markets",
            capital_allocated=1000.0,
        )
        prompt = get_agent_system_prompt(state)
        assert "agent_001" in prompt
        assert "RESEARCHING" in prompt.upper() or "researching" in prompt
        assert "Find alpha in weather markets" in prompt
        assert "$1,000.00" in prompt
        assert "transition_phase" in prompt
        assert "anti-overfitting" in prompt.lower()

    def test_hive_system_prompt(self):
        from horizon.swarm._prompt import get_hive_system_prompt
        prompt = get_hive_system_prompt(
            n_agents=3,
            total_capital=5000.0,
            max_capital=10000.0,
            max_agents=20,
        )
        assert "3" in prompt
        assert "$5,000" in prompt
        assert "spawn" in prompt.lower()
        assert "kill" in prompt.lower()
        assert "anti-overfitting" in prompt.lower()

    def test_agent_context(self):
        from horizon.swarm._prompt import build_agent_context
        state = AgentState(
            agent_id="agent_001",
            phase=AgentPhase.ANALYZING,
            status=AgentStatus.RUNNING,
            capital_allocated=1000.0,
            pnl=50.0,
            trades=5,
        )
        ctx = build_agent_context(
            state=state,
            recent_events=[],
            directives=["Focus on Kalshi"],
            knowledge_highlights=[{"entity": "rain", "content": "likely to rain"}],
            portfolio_summary={"total_pnl": 50.0, "n_positions": 2},
        )
        assert "agent_001" in ctx
        assert "Focus on Kalshi" in ctx
        assert "rain" in ctx

    def test_hive_context(self):
        from horizon.swarm._prompt import build_hive_context
        ctx = build_hive_context(
            agents=[{"agent_id": "agent_001", "phase": "analyzing", "status": "running", "pnl": 50, "trades": 3, "mission": "test"}],
            pending_proposals=[],
            portfolio_risk={"drawdown_pct": 0.02, "total_pnl": 50, "n_positions": 1},
            recent_events=[],
        )
        assert "agent_001" in ctx
        assert "analyzing" in ctx


# --------------------------------------------------------------------------- #
# Hive tests
# --------------------------------------------------------------------------- #

class TestHive:
    def test_hive_tool_server_definitions(self):
        hive_mock = MagicMock()
        server = HiveToolServer(hive_mock)
        defs = server.tool_definitions
        tool_names = {d["name"] for d in defs}
        assert "spawn_agent" in tool_names
        assert "kill_agent" in tool_names
        assert "redirect_agent" in tool_names
        assert "allocate_capital" in tool_names
        assert "review_proposal" in tool_names
        assert "get_swarm_status" in tool_names
        assert "get_portfolio_risk" in tool_names

    @pytest.mark.asyncio
    async def test_hive_tool_server_spawn(self):
        hive_mock = MagicMock()
        hive_mock.spawn_agent = AsyncMock(return_value="agent_001")
        server = HiveToolServer(hive_mock)
        result = await server.call_tool("spawn_agent", {"mission": "test"})
        assert result["agent_id"] == "agent_001"
        assert result["status"] == "spawned"

    @pytest.mark.asyncio
    async def test_hive_tool_server_unknown(self):
        hive_mock = MagicMock()
        server = HiveToolServer(hive_mock)
        result = await server.call_tool("nonexistent", {})
        assert "error" in result


# --------------------------------------------------------------------------- #
# Integration tests
# --------------------------------------------------------------------------- #

class TestHiveProposalReview:
    def test_review_rejects_without_gates(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        proposal = Proposal(
            proposal_id="prop_1",
            agent_id="agent_001",
            hypothesis="Test",
            market_id="market-1",
            side="yes",
            edge_estimate=0.05,
            kelly_fraction=0.1,
            requested_capital=500,
            backtest_results={},
            robustness_results={},
            reasoning="Test",
            anti_overfitting_proof={},  # No gates!
            timestamp=time.time(),
        )
        hive._pending_proposals.append(proposal)

        result = hive.review_proposal("prop_1", "approved", "Looks good")
        assert "error" in result
        assert "missing" in result["error"].lower()

    def test_review_rejects_failed_gates(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        proposal = Proposal(
            proposal_id="prop_2",
            agent_id="agent_001",
            hypothesis="Test",
            market_id="market-1",
            side="yes",
            edge_estimate=0.05,
            kelly_fraction=0.1,
            requested_capital=500,
            backtest_results={},
            robustness_results={},
            reasoning="Test",
            anti_overfitting_proof={
                "deflated_sharpe": {"passed": True},
                "walk_forward": {"passed": True},
                "cpcv_pbo": {"passed": False},  # Failed!
                "bootstrap_robustness": {"passed": True},
                "structural_validation": {"passed": True},
            },
            timestamp=time.time(),
        )
        hive._pending_proposals.append(proposal)

        result = hive.review_proposal("prop_2", "approved", "Looks good")
        assert "error" in result
        assert "failed" in result["error"].lower()

    def test_review_approves_all_gates_passed(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        # Create a mock agent to receive the directive
        mock_agent = MagicMock()
        hive._agents["agent_001"] = mock_agent

        proposal = Proposal(
            proposal_id="prop_3",
            agent_id="agent_001",
            hypothesis="Test",
            market_id="market-1",
            side="yes",
            edge_estimate=0.05,
            kelly_fraction=0.1,
            requested_capital=500,
            backtest_results={},
            robustness_results={},
            reasoning="Test",
            anti_overfitting_proof={
                "deflated_sharpe": {"passed": True},
                "walk_forward": {"passed": True},
                "cpcv_pbo": {"passed": True},
                "bootstrap_robustness": {"passed": True},
                "structural_validation": {"passed": True},
            },
            timestamp=time.time(),
        )
        hive._pending_proposals.append(proposal)

        result = hive.review_proposal("prop_3", "approved", "All gates passed")
        assert result["verdict"] == "approved"
        assert len(hive._pending_proposals) == 0
        mock_agent.inject_directive.assert_called_once()

    def test_review_can_reject_with_failed_gates(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        mock_agent = MagicMock()
        hive._agents["agent_001"] = mock_agent

        proposal = Proposal(
            proposal_id="prop_4",
            agent_id="agent_001",
            hypothesis="Bad strategy",
            market_id="market-1",
            side="yes",
            edge_estimate=0.01,
            kelly_fraction=0.01,
            requested_capital=100,
            backtest_results={},
            robustness_results={},
            reasoning="Weak",
            anti_overfitting_proof={
                "deflated_sharpe": {"passed": False},
            },
            timestamp=time.time(),
        )
        hive._pending_proposals.append(proposal)

        # Rejection doesn't require all gates
        result = hive.review_proposal("prop_4", "rejected", "Weak edge")
        assert result["verdict"] == "rejected"

    def test_capital_allocation(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        mock_agent = MagicMock()
        mock_agent.state = AgentState(agent_id="agent_001")
        hive._agents["agent_001"] = mock_agent

        hive.allocate_capital("agent_001", 5000.0)
        assert mock_agent.state.capital_allocated == 5000.0

    def test_capital_allocation_exceeds_max(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        mock_agent = MagicMock()
        mock_agent.state = AgentState(agent_id="agent_001")
        hive._agents["agent_001"] = mock_agent

        with pytest.raises(ValueError, match="exceed max capital"):
            hive.allocate_capital("agent_001", 999_999.0)

    def test_get_swarm_status(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        status = hive.get_swarm_status()
        assert status["n_agents"] == 0
        assert status["total_pnl"] == 0
        assert status["max_agents"] == 5

    def test_get_portfolio_risk(self, config, engine_pool):
        from horizon.swarm._hive import Hive
        hive = Hive(config=config, event_bus=EventBus(), engine_pool=engine_pool)

        risk = hive.get_portfolio_risk()
        assert "total_pnl" in risk
        assert "drawdown_pct" in risk
        assert "n_positions" in risk


# --------------------------------------------------------------------------- #
# Module API tests
# --------------------------------------------------------------------------- #

class TestModuleAPI:
    def test_imports(self):
        from horizon.swarm import (
            SwarmConfig,
            Hive,
            EventBus,
            EnginePool,
            CircuitBreaker,
            AgentPhase,
            AgentStatus,
            SwarmEventType,
            start_swarm,
            run_swarm,
        )
        assert SwarmConfig is not None
        assert Hive is not None
        assert start_swarm is not None
        assert run_swarm is not None
