"""Tests for Robinhood exchange integration."""

import os
import pytest

import horizon as hz


# ---------------------------------------------------------------------------
# 1. Robinhood Dataclass Configuration
# ---------------------------------------------------------------------------


class TestRobinhoodConfig:
    def test_defaults(self):
        exch = hz.Robinhood(api_key="test-key-123")
        assert exch.api_url == "https://trading.robinhood.com/api/v1"
        assert exch.api_key == "test-key-123"

    def test_custom_url(self):
        exch = hz.Robinhood(api_key="test-key", api_url="https://custom.robinhood.com")
        assert exch.api_url == "https://custom.robinhood.com"

    def test_env_var_resolution(self, monkeypatch):
        monkeypatch.setenv("ROBINHOOD_API_KEY", "env-rh-key-456")
        exch = hz.Robinhood()
        assert exch.api_key == "env-rh-key-456"

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("ROBINHOOD_API_KEY", "env-key")
        exch = hz.Robinhood(api_key="explicit-key")
        assert exch.api_key == "explicit-key"

    def test_no_env_no_explicit(self, monkeypatch):
        monkeypatch.delenv("ROBINHOOD_API_KEY", raising=False)
        exch = hz.Robinhood()
        assert exch.api_key is None

    def test_api_key_not_in_repr(self):
        exch = hz.Robinhood(api_key="SUPERSECRETKEY")
        assert "SUPERSECRETKEY" not in repr(exch)


# ---------------------------------------------------------------------------
# 2. Engine Creation
# ---------------------------------------------------------------------------


class TestRobinhoodEngine:
    """Test engine creation with robinhood exchange type."""

    def test_engine_creation_with_key(self):
        """Engine should succeed with an api_key for robinhood."""
        try:
            engine = hz.Engine(
                exchange_type="robinhood",
                exchange_key="test-robinhood-key",
            )
            assert "robinhood" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_add_secondary_exchange(self):
        """Adding robinhood as secondary exchange should work."""
        try:
            engine = hz.Engine()  # paper primary
            engine.add_exchange(
                exchange_type="robinhood",
                exchange_key="test-robinhood-key",
            )
            assert "robinhood" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_duplicate_exchange_rejected(self):
        """Adding robinhood twice should fail."""
        try:
            engine = hz.Engine()
            engine.add_exchange(
                exchange_type="robinhood",
                exchange_key="test-robinhood-key",
            )
            with pytest.raises(Exception, match="already registered"):
                engine.add_exchange(
                    exchange_type="robinhood",
                    exchange_key="test-robinhood-key",
                )
        except PermissionError:
            pytest.skip("API key tier required")


# ---------------------------------------------------------------------------
# 3. Import Verification
# ---------------------------------------------------------------------------


class TestRobinhoodImport:
    def test_importable_from_horizon(self):
        """hz.Robinhood should be importable."""
        assert hasattr(hz, "Robinhood")

    def test_in_all(self):
        """Robinhood should be in __all__."""
        assert "Robinhood" in hz.__all__

    def test_from_exchanges_module(self):
        """Should be importable from exchanges module directly."""
        from horizon.exchanges import Robinhood
        assert Robinhood is hz.Robinhood
