"""Tests for Limitless exchange integration."""

import os
import pytest

import horizon as hz


# ---------------------------------------------------------------------------
# 1. Limitless Dataclass Configuration
# ---------------------------------------------------------------------------


class TestLimitlessConfig:
    def test_defaults(self):
        exch = hz.Limitless(api_key="lmt-key-123", private_key="0xdeadbeef")
        assert exch.api_url == "https://api.limitless.exchange"
        assert exch.api_key == "lmt-key-123"
        assert exch.private_key == "0xdeadbeef"
        assert exch.owner_id is None

    def test_owner_id(self):
        exch = hz.Limitless(
            api_key="key",
            private_key="0xabc",
            owner_id="owner-xyz",
        )
        assert exch.owner_id == "owner-xyz"

    def test_custom_url(self):
        exch = hz.Limitless(
            api_key="key",
            api_url="https://custom.limitless.exchange",
        )
        assert exch.api_url == "https://custom.limitless.exchange"

    def test_env_var_resolution(self, monkeypatch):
        monkeypatch.setenv("LIMITLESS_API_KEY", "env-lmt-key")
        monkeypatch.setenv("LIMITLESS_PRIVATE_KEY", "0xenvprivkey")
        monkeypatch.setenv("LIMITLESS_OWNER_ID", "env-owner-id")
        exch = hz.Limitless()
        assert exch.api_key == "env-lmt-key"
        assert exch.private_key == "0xenvprivkey"
        assert exch.owner_id == "env-owner-id"

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("LIMITLESS_API_KEY", "env-key")
        monkeypatch.setenv("LIMITLESS_PRIVATE_KEY", "0xenvkey")
        exch = hz.Limitless(api_key="explicit-key", private_key="0xexplicit")
        assert exch.api_key == "explicit-key"
        assert exch.private_key == "0xexplicit"

    def test_no_env_no_explicit(self, monkeypatch):
        monkeypatch.delenv("LIMITLESS_API_KEY", raising=False)
        monkeypatch.delenv("LIMITLESS_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("LIMITLESS_OWNER_ID", raising=False)
        exch = hz.Limitless()
        assert exch.api_key is None
        assert exch.private_key is None
        assert exch.owner_id is None

    def test_secrets_not_in_repr(self):
        exch = hz.Limitless(api_key="SECRETAPIKEY", private_key="0xSECRETPRIVATEKEY")
        r = repr(exch)
        assert "SECRETAPIKEY" not in r
        assert "SECRETPRIVATEKEY" not in r


# ---------------------------------------------------------------------------
# 2. Engine Creation
# ---------------------------------------------------------------------------


class TestLimitlessEngine:
    """Test engine creation with limitless exchange type."""

    def test_engine_creation_with_key(self):
        """Engine should succeed with api_key for limitless."""
        try:
            engine = hz.Engine(
                exchange_type="limitless",
                exchange_key="test-limitless-key",
            )
            assert "limitless" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_add_secondary_exchange(self):
        """Adding limitless as secondary exchange should work."""
        try:
            engine = hz.Engine()  # paper primary
            engine.add_exchange(
                exchange_type="limitless",
                exchange_key="test-limitless-key",
            )
            assert "limitless" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_duplicate_exchange_rejected(self):
        """Adding limitless twice should fail."""
        try:
            engine = hz.Engine()
            engine.add_exchange(
                exchange_type="limitless",
                exchange_key="test-limitless-key",
            )
            with pytest.raises(Exception, match="already registered"):
                engine.add_exchange(
                    exchange_type="limitless",
                    exchange_key="test-limitless-key",
                )
        except PermissionError:
            pytest.skip("API key tier required")


# ---------------------------------------------------------------------------
# 3. Import Verification
# ---------------------------------------------------------------------------


class TestLimitlessImport:
    def test_importable_from_horizon(self):
        """hz.Limitless should be importable."""
        assert hasattr(hz, "Limitless")

    def test_in_all(self):
        """Limitless should be in __all__."""
        assert "Limitless" in hz.__all__

    def test_from_exchanges_module(self):
        """Should be importable from exchanges module directly."""
        from horizon.exchanges import Limitless
        assert Limitless is hz.Limitless
