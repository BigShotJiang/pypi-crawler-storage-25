"""Tests for Hyperliquid exchange integration."""

import os
import pytest

import horizon as hz


# ---------------------------------------------------------------------------
# 1. Hyperliquid Dataclass Configuration
# ---------------------------------------------------------------------------


class TestHyperliquidConfig:
    def test_defaults(self):
        exch = hz.Hyperliquid(private_key="0xdeadbeef" * 4)
        assert exch.testnet is False
        assert exch.api_url == "https://api.hyperliquid.xyz"
        assert exch.vault_address is None

    def test_testnet_url(self):
        exch = hz.Hyperliquid(private_key="0xdeadbeef" * 4, testnet=True)
        assert exch.testnet is True
        assert exch.api_url == "https://api.hyperliquid-testnet.xyz"

    def test_custom_url(self):
        exch = hz.Hyperliquid(
            private_key="0xdeadbeef" * 4,
            api_url="https://custom.api.xyz",
        )
        assert exch.api_url == "https://custom.api.xyz"

    def test_vault_address(self):
        exch = hz.Hyperliquid(
            private_key="0xdeadbeef" * 4,
            vault_address="0x" + "ab" * 20,
        )
        assert exch.vault_address == "0x" + "ab" * 20

    def test_env_var_resolution(self, monkeypatch):
        monkeypatch.setenv("HYPERLIQUID_PRIVATE_KEY", "0x" + "aa" * 32)
        exch = hz.Hyperliquid()
        assert exch.private_key == "0x" + "aa" * 32

    def test_env_var_vault(self, monkeypatch):
        monkeypatch.setenv("HYPERLIQUID_PRIVATE_KEY", "0x" + "aa" * 32)
        monkeypatch.setenv("HYPERLIQUID_VAULT_ADDRESS", "0x" + "bb" * 20)
        exch = hz.Hyperliquid()
        assert exch.vault_address == "0x" + "bb" * 20

    def test_private_key_not_in_repr(self):
        exch = hz.Hyperliquid(private_key="0xSECRET" + "aa" * 28)
        assert "SECRET" not in repr(exch)


# ---------------------------------------------------------------------------
# 2. Engine Creation
# ---------------------------------------------------------------------------


class TestHyperliquidEngine:
    """Test engine creation with hyperliquid exchange type."""

    def test_engine_creation_requires_key(self):
        """Engine should fail without private_key for hyperliquid."""
        with pytest.raises(Exception):
            hz.Engine(exchange_type="hyperliquid")

    def test_engine_creation_invalid_key(self):
        """Engine should fail with invalid private key."""
        with pytest.raises(Exception):
            hz.Engine(
                exchange_type="hyperliquid",
                private_key="not-a-valid-hex-key",
            )

    def test_engine_creation_with_valid_key(self):
        """Engine should succeed with a valid 32-byte hex private key."""
        try:
            engine = hz.Engine(
                exchange_type="hyperliquid",
                private_key="0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
            )
            assert "hyperliquid" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_engine_creation_testnet(self):
        """Testnet URL should trigger testnet mode."""
        try:
            engine = hz.Engine(
                exchange_type="hyperliquid",
                private_key="0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
                api_url="https://api.hyperliquid-testnet.xyz",
            )
            assert "hyperliquid" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_add_secondary_exchange(self):
        """Adding hyperliquid as secondary exchange should work."""
        try:
            engine = hz.Engine()  # paper primary
            engine.add_exchange(
                exchange_type="hyperliquid",
                private_key="0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
            )
            assert "hyperliquid" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_duplicate_exchange_rejected(self):
        """Adding hyperliquid twice should fail."""
        try:
            engine = hz.Engine()
            engine.add_exchange(
                exchange_type="hyperliquid",
                private_key="0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
            )
            with pytest.raises(Exception, match="already registered"):
                engine.add_exchange(
                    exchange_type="hyperliquid",
                    private_key="0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
                )
        except PermissionError:
            pytest.skip("API key tier required")


# ---------------------------------------------------------------------------
# 3. Live Mode Validation
# ---------------------------------------------------------------------------


class TestHyperliquidValidation:
    def test_live_mode_requires_private_key(self):
        """Live mode should reject Hyperliquid without private_key."""
        exch = hz.Hyperliquid()
        # Manually clear any env-resolved key
        exch.private_key = None
        # The validation happens in hz.run() which we can't fully invoke without
        # a pipeline, but we can verify the dataclass state
        assert exch.private_key is None


# ---------------------------------------------------------------------------
# 4. Import Verification
# ---------------------------------------------------------------------------


class TestHyperliquidImport:
    def test_importable_from_horizon(self):
        """hz.Hyperliquid should be importable."""
        assert hasattr(hz, "Hyperliquid")

    def test_in_all(self):
        """Hyperliquid should be in __all__."""
        assert "Hyperliquid" in hz.__all__

    def test_from_exchanges_module(self):
        """Should be importable from exchanges module directly."""
        from horizon.exchanges import Hyperliquid
        assert Hyperliquid is hz.Hyperliquid
