"""Tests for Interactive Brokers exchange integration."""

import os
import pytest

import horizon as hz


# ---------------------------------------------------------------------------
# 1. InteractiveBrokers Dataclass Configuration
# ---------------------------------------------------------------------------


class TestIBKRConfig:
    def test_defaults(self):
        exch = hz.InteractiveBrokers(access_token="tok-123", account_id="U12345")
        assert exch.paper is True
        assert exch.api_url == "https://paper-api.ibkr.com/v1/api"
        assert exch.access_token == "tok-123"
        assert exch.account_id == "U12345"

    def test_paper_mode_default_url(self):
        exch = hz.InteractiveBrokers(access_token="tok", paper=True)
        assert exch.api_url == "https://paper-api.ibkr.com/v1/api"

    def test_live_mode_url(self):
        exch = hz.InteractiveBrokers(access_token="tok", paper=False)
        assert exch.paper is False
        assert exch.api_url == "https://api.ibkr.com/v1/api"

    def test_custom_url(self):
        exch = hz.InteractiveBrokers(
            access_token="tok",
            api_url="https://custom.ibkr.com/v1/api",
        )
        assert exch.api_url == "https://custom.ibkr.com/v1/api"

    def test_env_var_resolution(self, monkeypatch):
        monkeypatch.setenv("IBKR_ACCESS_TOKEN", "env-token-abc")
        monkeypatch.setenv("IBKR_ACCOUNT_ID", "U99999")
        exch = hz.InteractiveBrokers()
        assert exch.access_token == "env-token-abc"
        assert exch.account_id == "U99999"

    def test_explicit_overrides_env(self, monkeypatch):
        monkeypatch.setenv("IBKR_ACCESS_TOKEN", "env-token")
        monkeypatch.setenv("IBKR_ACCOUNT_ID", "U00000")
        exch = hz.InteractiveBrokers(access_token="explicit-tok", account_id="U11111")
        assert exch.access_token == "explicit-tok"
        assert exch.account_id == "U11111"

    def test_no_env_no_explicit(self, monkeypatch):
        monkeypatch.delenv("IBKR_ACCESS_TOKEN", raising=False)
        monkeypatch.delenv("IBKR_ACCOUNT_ID", raising=False)
        exch = hz.InteractiveBrokers()
        assert exch.access_token is None
        assert exch.account_id is None

    def test_access_token_not_in_repr(self):
        exch = hz.InteractiveBrokers(access_token="SUPERSECRETTOKEN")
        assert "SUPERSECRETTOKEN" not in repr(exch)


# ---------------------------------------------------------------------------
# 2. Engine Creation
# ---------------------------------------------------------------------------


class TestIBKREngine:
    """Test engine creation with ibkr exchange type."""

    def test_engine_creation_with_key(self):
        """Engine should succeed with access_token for ibkr."""
        try:
            engine = hz.Engine(
                exchange_type="ibkr",
                exchange_key="test-ibkr-token",
                exchange_secret="U12345",
            )
            assert "ibkr" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_add_secondary_exchange(self):
        """Adding ibkr as secondary exchange should work."""
        try:
            engine = hz.Engine()  # paper primary
            engine.add_exchange(
                exchange_type="ibkr",
                exchange_key="test-ibkr-token",
                exchange_secret="U12345",
            )
            assert "ibkr" in engine.exchange_names()
        except PermissionError:
            pytest.skip("API key tier required")

    def test_duplicate_exchange_rejected(self):
        """Adding ibkr twice should fail."""
        try:
            engine = hz.Engine()
            engine.add_exchange(
                exchange_type="ibkr",
                exchange_key="test-ibkr-token",
                exchange_secret="U12345",
            )
            with pytest.raises(Exception, match="already registered"):
                engine.add_exchange(
                    exchange_type="ibkr",
                    exchange_key="test-ibkr-token",
                    exchange_secret="U12345",
                )
        except PermissionError:
            pytest.skip("API key tier required")


# ---------------------------------------------------------------------------
# 3. Import Verification
# ---------------------------------------------------------------------------


class TestIBKRImport:
    def test_importable_from_horizon(self):
        """hz.InteractiveBrokers should be importable."""
        assert hasattr(hz, "InteractiveBrokers")

    def test_in_all(self):
        """InteractiveBrokers should be in __all__."""
        assert "InteractiveBrokers" in hz.__all__

    def test_from_exchanges_module(self):
        """Should be importable from exchanges module directly."""
        from horizon.exchanges import InteractiveBrokers
        assert InteractiveBrokers is hz.InteractiveBrokers
