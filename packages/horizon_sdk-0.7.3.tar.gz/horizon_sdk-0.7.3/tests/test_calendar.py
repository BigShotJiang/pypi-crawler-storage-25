"""Tests for calendar/event integration.

Tests cover:
- Bundled FOMC_DATES and CPI_DATES lists
- bundled_events_json() serialization
- CalendarFeed dataclass creation and default events_json population
- Python pipeline functions (time_decay, event_countdown, pre_event_strategy)
"""

import json
import pytest


# ---------------------------------------------------------------------------
# 1. Calendar event data
# ---------------------------------------------------------------------------


class TestCalendarEvents:
    def test_fomc_dates_exist(self):
        from horizon.calendar_events import FOMC_DATES

        assert isinstance(FOMC_DATES, list)
        assert len(FOMC_DATES) > 0
        # Should contain valid date strings
        for d in FOMC_DATES:
            assert len(d) == 10  # "YYYY-MM-DD"
            assert d[4] == "-" and d[7] == "-"

    def test_cpi_dates_exist(self):
        from horizon.calendar_events import CPI_DATES

        assert isinstance(CPI_DATES, list)
        assert len(CPI_DATES) > 0
        for d in CPI_DATES:
            assert len(d) == 10

    def test_fomc_dates_has_2025_and_2026(self):
        from horizon.calendar_events import FOMC_DATES

        has_2025 = any(d.startswith("2025") for d in FOMC_DATES)
        has_2026 = any(d.startswith("2026") for d in FOMC_DATES)
        assert has_2025
        assert has_2026

    def test_bundled_events_json(self):
        from horizon.calendar_events import bundled_events_json

        result = bundled_events_json()
        assert isinstance(result, str)
        events = json.loads(result)
        assert isinstance(events, list)
        assert len(events) > 0
        # Each event should have name, timestamp, type
        for e in events:
            assert "name" in e
            assert "timestamp" in e
            assert "type" in e
            assert isinstance(e["timestamp"], (int, float))

    def test_bundled_events_json_types(self):
        from horizon.calendar_events import bundled_events_json

        events = json.loads(bundled_events_json())
        types = {e["type"] for e in events}
        assert "fomc" in types
        assert "cpi" in types


# ---------------------------------------------------------------------------
# 2. CalendarFeed dataclass
# ---------------------------------------------------------------------------


class TestCalendarFeed:
    def test_dataclass_creation(self):
        from horizon.feeds import CalendarFeed

        feed = CalendarFeed()
        assert feed._type == "calendar"
        assert feed.interval == 300.0

    def test_default_events_json_populated(self):
        from horizon.feeds import CalendarFeed

        feed = CalendarFeed()
        # __post_init__ should populate events_json with bundled data
        assert len(feed.events_json) > 0
        events = json.loads(feed.events_json)
        assert len(events) > 0

    def test_custom_events_json(self):
        from horizon.feeds import CalendarFeed

        custom = json.dumps([{"name": "Test", "timestamp": 1700000000, "type": "test"}])
        feed = CalendarFeed(events_json=custom)
        assert feed.events_json == custom

    def test_custom_api_url(self):
        from horizon.feeds import CalendarFeed

        feed = CalendarFeed(api_url="https://example.com/events")
        assert feed.api_url == "https://example.com/events"


# ---------------------------------------------------------------------------
# 3. Pipeline functions (Ultra tier)
# ---------------------------------------------------------------------------


class TestTimePipeline:
    def test_time_decay(self):
        try:
            from horizon.calendar_events import time_decay
        except PermissionError:
            pytest.skip("Ultra tier required")

        fn = time_decay(max_days=30.0, decay_type="linear")
        assert callable(fn)
        assert fn.__name__ == "time_decay"

    def test_time_decay_exponential(self):
        try:
            from horizon.calendar_events import time_decay
        except PermissionError:
            pytest.skip("Ultra tier required")

        fn = time_decay(decay_type="exponential")
        assert callable(fn)

    def test_event_countdown(self):
        try:
            from horizon.calendar_events import event_countdown
        except PermissionError:
            pytest.skip("Ultra tier required")

        fn = event_countdown()
        assert callable(fn)
        assert fn.__name__ == "event_countdown"

    def test_pre_event_strategy(self):
        try:
            from horizon.calendar_events import pre_event_strategy
        except PermissionError:
            pytest.skip("Ultra tier required")

        fn = pre_event_strategy(reduce_hours=24.0, reduce_factor=0.5)
        assert callable(fn)
        assert fn.__name__ == "pre_event_strategy"
