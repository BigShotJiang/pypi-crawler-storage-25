"""Tests for intelligence modules: KnowledgeGraph, ResearchAgent, SimGraphBridge."""

from __future__ import annotations

import time

import pytest

from horizon.fund._knowledge_graph import (
    ENTITY_TYPES,
    FACT_TYPES,
    REL_TYPES,
    KnowledgeGraph,
)
from horizon.fund._react_agent import Finding, ResearchAgent, ResearchReport
from horizon.fund._sim_graph import SimGraphBridge


# -----------------------------------------------------------------------
# Fixtures
# -----------------------------------------------------------------------

@pytest.fixture
def kg(tmp_path):
    db = KnowledgeGraph(db_path=str(tmp_path / "test_kg.db"))
    yield db
    db.close()


@pytest.fixture
def bridge(kg):
    return SimGraphBridge(kg)


@pytest.fixture
def agent_no_fund():
    return ResearchAgent()


@pytest.fixture
def agent_with_graph(kg):
    return ResearchAgent(knowledge_graph=kg)


# -----------------------------------------------------------------------
# Helper
# -----------------------------------------------------------------------

def _add_two_markets(kg: KnowledgeGraph, a: str = "m1", b: str = "m2"):
    """Add two market entities and return their ids."""
    kg.add_entity(a, "market", f"Market {a}")
    kg.add_entity(b, "market", f"Market {b}")
    return a, b


# =======================================================================
# KnowledgeGraph
# =======================================================================


class TestKnowledgeGraph:

    # -- lifecycle -------------------------------------------------------

    def test_create_and_close(self, tmp_path):
        db = KnowledgeGraph(db_path=str(tmp_path / "kg.db"))
        stats = db.stats()
        assert stats["total_entities"] == 0
        db.close()

    # -- entity CRUD -----------------------------------------------------

    def test_add_entity(self, kg):
        e = kg.add_entity("e1", "market", "Test Market")
        assert e["entity_id"] == "e1"
        assert e["entity_type"] == "market"
        assert e["name"] == "Test Market"
        assert e["properties"] == {}
        assert isinstance(e["created_at"], float)

    def test_add_entity_duplicate_updates(self, kg):
        kg.add_entity("e1", "market", "v1")
        kg.add_entity("e1", "market", "v2", properties={"foo": 1})
        e = kg.get_entity("e1")
        assert e is not None
        assert e["name"] == "v2"
        assert e["properties"]["foo"] == 1

    def test_add_entity_invalid_type(self, kg):
        with pytest.raises(ValueError, match="Invalid entity_type"):
            kg.add_entity("bad", "invalid_type", "Bad")

    def test_get_entity(self, kg):
        kg.add_entity("x", "asset", "BTC")
        e = kg.get_entity("x")
        assert e is not None
        assert e["entity_type"] == "asset"

    def test_get_entity_missing(self, kg):
        assert kg.get_entity("nonexistent") is None

    def test_find_entities_by_type(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_entity("e1", "event", "E1")
        results = kg.find_entities(entity_type="market")
        assert len(results) == 2
        assert all(r["entity_type"] == "market" for r in results)

    def test_find_entities_by_name_pattern(self, kg):
        kg.add_entity("a1", "market", "Bitcoin price above 50k")
        kg.add_entity("a2", "market", "Ethereum price above 3k")
        kg.add_entity("a3", "event", "Election 2024")
        results = kg.find_entities(name_pattern="price above")
        assert len(results) == 2

    def test_remove_entity_cascades(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_relationship("m1", "m2", "correlated_with")
        kg.record_fact("m1", "observation", "test fact")

        assert kg.remove_entity("m1") is True

        assert kg.get_entity("m1") is None
        assert kg.get_facts(entity_id="m1") == []
        rels = kg.get_relationships("m1", active_only=False)
        assert len(rels) == 0

    def test_remove_entity_missing_returns_false(self, kg):
        assert kg.remove_entity("ghost") is False

    # -- relationships ---------------------------------------------------

    def test_add_relationship(self, kg):
        a, b = _add_two_markets(kg)
        rel = kg.add_relationship(a, b, "correlated_with", weight=0.8)
        assert rel["source_id"] == a
        assert rel["target_id"] == b
        assert rel["rel_type"] == "correlated_with"
        assert rel["weight"] == 0.8

    def test_add_relationship_validates_entities(self, kg):
        kg.add_entity("m1", "market", "M1")
        with pytest.raises(ValueError, match="does not exist"):
            kg.add_relationship("m1", "phantom", "correlated_with")
        with pytest.raises(ValueError, match="does not exist"):
            kg.add_relationship("phantom", "m1", "correlated_with")

    def test_add_relationship_validates_rel_type(self, kg):
        a, b = _add_two_markets(kg)
        with pytest.raises(ValueError, match="Invalid rel_type"):
            kg.add_relationship(a, b, "friends_with")

    def test_get_relationships_outgoing(self, kg):
        a, b = _add_two_markets(kg)
        kg.add_relationship(a, b, "correlated_with")
        rels = kg.get_relationships(a, direction="outgoing")
        assert len(rels) == 1
        assert rels[0]["target_id"] == b

    def test_get_relationships_incoming(self, kg):
        a, b = _add_two_markets(kg)
        kg.add_relationship(a, b, "correlated_with")
        rels = kg.get_relationships(b, direction="incoming")
        assert len(rels) == 1
        assert rels[0]["source_id"] == a

    def test_get_relationships_both(self, kg):
        a, b = _add_two_markets(kg)
        kg.add_entity("m3", "market", "Market m3")
        kg.add_relationship(a, b, "correlated_with")
        kg.add_relationship("m3", a, "related_to")
        rels = kg.get_relationships(a, direction="both")
        assert len(rels) == 2

    def test_expire_relationship(self, kg):
        a, b = _add_two_markets(kg)
        rel = kg.add_relationship(a, b, "correlated_with")
        rel_id = rel["rel_id"]

        assert kg.expire_relationship(rel_id) is True

        # After expiry, active_only=True should exclude it
        rels = kg.get_relationships(a, active_only=True)
        assert len(rels) == 0

        # But it still exists when not filtering active only
        rels_all = kg.get_relationships(a, active_only=False)
        assert len(rels_all) == 1

    def test_expire_relationship_nonexistent(self, kg):
        assert kg.expire_relationship(99999) is False

    # -- facts -----------------------------------------------------------

    def test_record_fact(self, kg):
        kg.add_entity("m1", "market", "M1")
        f = kg.record_fact("m1", "observation", "Price went up", confidence=0.9, source="test")
        assert f["entity_id"] == "m1"
        assert f["fact_type"] == "observation"
        assert f["confidence"] == 0.9
        assert f["source"] == "test"
        assert f["fact_id"] > 0

    def test_record_fact_validates_entity(self, kg):
        with pytest.raises(ValueError, match="does not exist"):
            kg.record_fact("ghost", "observation", "nope")

    def test_record_fact_validates_type(self, kg):
        kg.add_entity("m1", "market", "M1")
        with pytest.raises(ValueError, match="Invalid fact_type"):
            kg.record_fact("m1", "gossip", "not a valid type")

    def test_record_fact_clamps_confidence(self, kg):
        kg.add_entity("m1", "market", "M1")
        f_high = kg.record_fact("m1", "observation", "high", confidence=5.0)
        assert f_high["confidence"] == 1.0
        f_low = kg.record_fact("m1", "observation", "low", confidence=-2.0)
        assert f_low["confidence"] == 0.0

    def test_get_facts_filters(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.record_fact("m1", "observation", "obs1", confidence=0.3, source="a")
        kg.record_fact("m1", "signal", "sig1", confidence=0.9, source="b")
        kg.record_fact("m1", "observation", "obs2", confidence=0.8, source="a")

        # Filter by type
        obs = kg.get_facts(entity_id="m1", fact_type="observation")
        assert len(obs) == 2

        # Filter by source
        src_b = kg.get_facts(entity_id="m1", source="b")
        assert len(src_b) == 1

        # Filter by min confidence
        high = kg.get_facts(entity_id="m1", min_confidence=0.7)
        assert len(high) == 2

    # -- graph queries ---------------------------------------------------

    def test_neighbors_depth_1(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_entity("m3", "market", "M3")
        kg.add_relationship("m1", "m2", "correlated_with")
        kg.add_relationship("m2", "m3", "correlated_with")

        neighbors = kg.neighbors("m1", depth=1)
        assert "m1" in neighbors
        assert "m2" in neighbors
        assert "m3" not in neighbors
        assert neighbors["m1"]["depth"] == 0
        assert neighbors["m2"]["depth"] == 1

    def test_neighbors_depth_2(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_entity("m3", "market", "M3")
        kg.add_relationship("m1", "m2", "correlated_with")
        kg.add_relationship("m2", "m3", "correlated_with")

        neighbors = kg.neighbors("m1", depth=2)
        assert "m1" in neighbors
        assert "m2" in neighbors
        assert "m3" in neighbors
        assert neighbors["m3"]["depth"] == 2

    def test_find_path_exists(self, kg):
        kg.add_entity("a", "market", "A")
        kg.add_entity("b", "market", "B")
        kg.add_entity("c", "market", "C")
        kg.add_relationship("a", "b", "correlated_with")
        kg.add_relationship("b", "c", "correlated_with")

        path = kg.find_path("a", "c")
        assert path is not None
        assert len(path) == 2
        assert path[0]["source_id"] == "a"
        assert path[0]["target_id"] == "b"

    def test_find_path_same_node(self, kg):
        kg.add_entity("a", "market", "A")
        path = kg.find_path("a", "a")
        assert path == []

    def test_find_path_no_path(self, kg):
        kg.add_entity("a", "market", "A")
        kg.add_entity("z", "market", "Z")
        path = kg.find_path("a", "z")
        assert path is None

    # -- intelligence queries -------------------------------------------

    def test_correlated_markets(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_entity("m3", "market", "M3")
        kg.add_relationship("m1", "m2", "correlated_with", weight=0.9)
        kg.add_relationship("m1", "m3", "correlated_with", weight=0.4)

        corr = kg.correlated_markets("m1", min_weight=0.5)
        assert len(corr) == 1
        assert corr[0]["entity"]["entity_id"] == "m2"
        assert corr[0]["weight"] == 0.9

    def test_event_opportunities(self, kg):
        kg.add_entity("evt1", "event", "Election 2024")
        kg.add_entity("m1", "market", "Candidate A wins?")
        kg.add_entity("m2", "market", "Candidate B wins?")
        kg.add_entity("org1", "organization", "PolyCorp")
        kg.add_relationship("m1", "evt1", "part_of")
        kg.add_relationship("m2", "evt1", "related_to")
        kg.add_relationship("org1", "evt1", "related_to")  # non-market, should be excluded

        opps = kg.event_opportunities("evt1")
        assert len(opps) == 2
        ids = {o["entity"]["entity_id"] for o in opps}
        assert ids == {"m1", "m2"}

    def test_market_context(self, kg):
        kg.add_entity("m1", "market", "Test Market")
        kg.record_fact("m1", "observation", "some data", confidence=0.8)
        ctx = kg.market_context("m1")
        assert ctx["entity"]["entity_id"] == "m1"
        assert ctx["fact_count"] == 1
        assert ctx["neighbor_count"] == 0

    def test_market_context_missing(self, kg):
        ctx = kg.market_context("ghost")
        assert "error" in ctx

    def test_detect_cross_correlations(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_entity("m3", "market", "M3")
        kg.add_entity("m4", "market", "M4")
        # Cluster 1: m1-m2-m3
        kg.add_relationship("m1", "m2", "correlated_with", weight=0.8)
        kg.add_relationship("m2", "m3", "correlated_with", weight=0.7)
        # m4 isolated — no cluster

        clusters = kg.detect_cross_correlations(min_weight=0.3)
        assert len(clusters) == 1
        assert clusters[0]["size"] == 3
        assert set(clusters[0]["entity_ids"]) == {"m1", "m2", "m3"}

    def test_surface_opportunities(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.record_fact("m1", "edge_detected", "Good edge", confidence=0.85)
        kg.record_fact("m1", "observation", "Low conf", confidence=0.2)

        opps = kg.surface_opportunities(min_confidence=0.6, lookback_hours=1.0)
        assert len(opps) == 1
        assert opps[0]["fact"]["confidence"] == 0.85

    def test_surface_opportunities_with_fact_types_filter(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.record_fact("m1", "edge_detected", "edge", confidence=0.9)
        kg.record_fact("m1", "signal", "sig", confidence=0.9)

        opps = kg.surface_opportunities(
            fact_types=["edge_detected"], min_confidence=0.6, lookback_hours=1.0
        )
        assert len(opps) == 1
        assert opps[0]["fact"]["fact_type"] == "edge_detected"

    # -- maintenance -----------------------------------------------------

    def test_prune_removes_expired(self, kg):
        kg.add_entity("m1", "market", "M1")
        # Record a fact that already expired
        now = time.time()
        kg.record_fact("m1", "observation", "old", confidence=0.5, expires_at=now - 10)
        # Record a current fact
        kg.record_fact("m1", "observation", "fresh", confidence=0.5)

        removed = kg.prune(max_age_days=90)
        assert removed >= 1

        facts = kg.get_facts(entity_id="m1", active_only=False)
        # The fresh fact should remain
        assert len(facts) >= 1

    def test_stats(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_entity("e1", "event", "E1")
        kg.add_relationship("m1", "m2", "correlated_with")
        kg.record_fact("m1", "observation", "obs")

        stats = kg.stats()
        assert stats["total_entities"] == 3
        assert stats["total_relationships"] == 1
        assert stats["total_facts"] == 1
        assert stats["entities_by_type"]["market"] == 2
        assert stats["entities_by_type"]["event"] == 1

    def test_export_subgraph(self, kg):
        kg.add_entity("m1", "market", "M1")
        kg.add_entity("m2", "market", "M2")
        kg.add_entity("m3", "market", "M3")
        kg.add_relationship("m1", "m2", "correlated_with")
        kg.add_relationship("m1", "m3", "correlated_with")
        kg.record_fact("m1", "observation", "data1")
        kg.record_fact("m2", "observation", "data2")

        sub = kg.export_subgraph(["m1", "m2"])
        assert len(sub["entities"]) == 2
        # Only m1->m2 relationship is within the subgraph
        assert len(sub["relationships"]) == 1
        assert sub["relationships"][0]["source_id"] == "m1"
        assert sub["relationships"][0]["target_id"] == "m2"
        # Facts for m1 and m2
        assert len(sub["facts"]) == 2

    def test_export_subgraph_empty(self, kg):
        sub = kg.export_subgraph([])
        assert sub == {"entities": [], "relationships": [], "facts": []}

    def test_hmac_integrity(self, kg):
        kg.add_entity("secure1", "market", "Secure Market")
        e = kg.get_entity("secure1")
        assert e is not None

        # Tamper with the hmac by direct SQL
        kg._conn.execute(
            "UPDATE entities SET hmac = 'tampered' WHERE entity_id = 'secure1'"
        )
        kg._conn.commit()

        # get_entity should still return the entity but log a warning
        e2 = kg.get_entity("secure1")
        assert e2 is not None
        assert e2["entity_id"] == "secure1"


# =======================================================================
# ResearchAgent
# =======================================================================


class TestResearchAgent:

    def test_create_agent_no_fund(self, agent_no_fund):
        assert agent_no_fund._fund is None
        assert agent_no_fund._kg is None
        assert len(agent_no_fund._tools) > 0

    def test_create_agent_with_graph(self, agent_with_graph, kg):
        assert agent_with_graph._kg is kg
        assert "graph_context" in agent_with_graph._tools

    def test_investigate_general(self, agent_no_fund):
        result = agent_no_fund.investigate("What is the current fund status?")
        assert "query" in result
        assert "findings" in result
        assert "data_sources" in result
        assert "reasoning_trace" in result
        assert "timestamp" in result
        assert "duration_secs" in result
        assert "summary" in result

    def test_investigate_risk(self, agent_no_fund):
        result = agent_no_fund.investigate("What are our current risk exposures?")
        trace = result["reasoning_trace"]
        intents = [t for t in trace if t.get("step") == "parse_intent"]
        assert len(intents) == 1
        assert intents[0]["intent"]["focus"] == "risk"

    def test_investigate_opportunity(self, agent_no_fund):
        result = agent_no_fund.investigate("Should we enter election markets?")
        trace = result["reasoning_trace"]
        intents = [t for t in trace if t.get("step") == "parse_intent"]
        assert intents[0]["intent"]["focus"] == "opportunity"

    def test_health_check(self, agent_no_fund):
        result = agent_no_fund.health_check()
        assert result["query"] == "Full fund health check"
        trace = result["reasoning_trace"]
        intents = [t for t in trace if t.get("step") == "parse_intent"]
        assert intents[0]["intent"]["focus"] == "health"

    def test_explain_underperformance(self, agent_no_fund):
        result = agent_no_fund.explain_underperformance("alpha_mm")
        assert "alpha_mm" in result["query"]
        trace = result["reasoning_trace"]
        intents = [t for t in trace if t.get("step") == "parse_intent"]
        assert intents[0]["intent"]["focus"] == "diagnosis"
        assert intents[0]["intent"]["strategy_name"] == "alpha_mm"

    def test_market_research(self, agent_no_fund):
        result = agent_no_fund.market_research("elections")
        assert "elections" in result["query"]

    def test_risk_assessment(self, agent_no_fund):
        result = agent_no_fund.risk_assessment()
        assert "risk" in result["query"].lower()

    def test_parse_intent_risk(self, agent_no_fund):
        intent = agent_no_fund._parse_intent("What is the drawdown risk?")
        assert intent["focus"] == "risk"

    def test_parse_intent_diagnosis(self, agent_no_fund):
        intent = agent_no_fund._parse_intent("Why is strategy foo underperforming?")
        assert intent["focus"] == "diagnosis"
        assert intent["strategy_name"] == "foo"

    def test_parse_intent_opportunity(self, agent_no_fund):
        intent = agent_no_fund._parse_intent("Should we enter crypto markets?")
        assert intent["focus"] == "opportunity"

    def test_plan_tools_maps_correctly(self, agent_no_fund):
        risk_intent = {"focus": "risk"}
        plan = agent_no_fund._plan_tools(risk_intent)
        assert "risk" in plan
        assert "positions" in plan

        opp_intent = {"focus": "opportunity"}
        plan = agent_no_fund._plan_tools(opp_intent)
        assert "markets" in plan
        assert "graph_opportunities" in plan

    def test_plan_tools_adds_graph_context_when_kg_present(self, agent_with_graph):
        intent = {"focus": "risk"}
        plan = agent_with_graph._plan_tools(intent)
        assert "graph_context" in plan

    def test_report_to_dict_format(self):
        f = Finding(
            category="risk",
            severity="high",
            title="Test",
            detail="Detail",
            evidence={"k": "v"},
            timestamp=1000.0,
        )
        report = ResearchReport(
            query="test query",
            findings=[f],
            data_sources=["positions"],
            reasoning_trace=[{"step": "parse_intent"}],
            timestamp=1000.0,
            duration_secs=0.5,
        )
        d = report.to_dict()
        assert d["query"] == "test query"
        assert len(d["findings"]) == 1
        assert d["findings"][0]["category"] == "risk"
        assert d["findings"][0]["severity"] == "high"
        assert d["duration_secs"] == 0.5
        assert "summary" in d
        assert d["summary"]["total_findings"] == 1
        assert d["summary"]["by_severity"]["high"] == 1

    def test_finding_severity_ranking(self):
        assert ResearchAgent._severity_rank("critical") < ResearchAgent._severity_rank("high")
        assert ResearchAgent._severity_rank("high") < ResearchAgent._severity_rank("medium")
        assert ResearchAgent._severity_rank("medium") < ResearchAgent._severity_rank("low")
        assert ResearchAgent._severity_rank("low") < ResearchAgent._severity_rank("info")
        assert ResearchAgent._severity_rank("unknown") > ResearchAgent._severity_rank("info")

    def test_max_reasoning_steps_cap(self, agent_no_fund):
        assert agent_no_fund.MAX_REASONING_STEPS == 20

        # Run a health check that uses all analyzers — should not exceed cap
        result = agent_no_fund.health_check()
        analyze_steps = [
            t for t in result["reasoning_trace"] if t.get("step") == "analyze"
        ]
        assert len(analyze_steps) <= agent_no_fund.MAX_REASONING_STEPS

    def test_deduplicate_findings(self):
        f1 = Finding("risk", "high", "Same Title", "d1", {})
        f2 = Finding("risk", "medium", "Same Title", "d2", {})
        f3 = Finding("risk", "low", "Different", "d3", {})
        deduped = ResearchAgent._deduplicate([f1, f2, f3])
        assert len(deduped) == 2
        titles = {f.title for f in deduped}
        assert titles == {"Same Title", "Different"}

    def test_investigate_with_graph_context(self, agent_with_graph, kg):
        kg.add_entity("m1", "market", "Test Market")
        kg.record_fact("m1", "edge_detected", "Good edge", confidence=0.9)
        result = agent_with_graph.investigate("Show me the full overview")
        assert "graph_context" in result["data_sources"]


# =======================================================================
# SimGraphBridge
# =======================================================================


class TestSimGraphBridge:

    def test_create_bridge(self, bridge, kg):
        assert bridge._kg is kg

    def test_record_backtest_result(self, bridge, kg):
        result = bridge.record_backtest_result(
            strategy_name="mm_v1",
            market_id="market_1",
            backtest_result={
                "total_pnl": 500.0,
                "sharpe": 0.8,
                "max_drawdown": 0.05,
                "n_trades": 30,
                "win_rate": 0.6,
            },
        )
        assert result["status"] == "recorded"
        assert result["market_id"] == "market_1"
        assert result["strategy"] == "mm_v1"
        assert result["fact_id"] is not None
        assert 0.1 <= result["confidence"] <= 0.95

        # Entity should have been created
        entity = kg.get_entity("market_1")
        assert entity is not None
        assert entity["entity_type"] == "market"

    def test_record_backtest_result_with_edge(self, bridge, kg):
        """When Sharpe >= 1.0, an additional edge_detected fact is recorded."""
        bridge.record_backtest_result(
            strategy_name="strong_strat",
            market_id="mkt_edge",
            backtest_result={
                "total_pnl": 1000.0,
                "sharpe": 1.5,
                "max_drawdown": 0.03,
                "n_trades": 60,
                "win_rate": 0.7,
            },
        )
        facts = kg.get_facts(entity_id="mkt_edge", fact_type="edge_detected")
        assert len(facts) >= 1
        assert "edge" in facts[0]["content"].lower() or "edge" in facts[0]["content"]

    def test_record_backtest_result_confidence_scales_with_trades(self, bridge):
        # Few trades => low confidence
        r_low = bridge.record_backtest_result(
            "s", "m_low", {"total_pnl": 10, "sharpe": 0.5, "max_drawdown": 0.1, "n_trades": 5, "win_rate": 0.5}
        )
        # Many trades => high confidence
        r_high = bridge.record_backtest_result(
            "s", "m_high", {"total_pnl": 10, "sharpe": 0.5, "max_drawdown": 0.1, "n_trades": 100, "win_rate": 0.5}
        )
        assert r_low["confidence"] < r_high["confidence"]

    def test_record_backtest_failure(self, bridge, kg):
        result = bridge.record_backtest_failure(
            strategy_name="bad_strat",
            market_id="mkt_fail",
            reason="Insufficient data",
            details={"rows": 5},
        )
        assert result["status"] == "recorded"
        assert result["fact_id"] is not None

        facts = kg.get_facts(entity_id="mkt_fail", fact_type="outcome")
        assert len(facts) == 1
        assert "failed" in facts[0]["content"]

    def test_record_fill(self, bridge, kg):
        result = bridge.record_fill(
            strategy_name="mm_v1",
            market_id="mkt_fill",
            side="buy",
            price=0.55,
            size=100.0,
            order_id="p1",
        )
        assert result["status"] == "recorded"
        assert result["fact_id"] is not None

        facts = kg.get_facts(entity_id="mkt_fill", fact_type="observation")
        assert len(facts) == 1
        assert facts[0]["confidence"] == 1.0
        meta = facts[0]["metadata"]
        assert meta["side"] == "buy"
        assert meta["price"] == 0.55

    def test_record_settlement_expires_relationships(self, bridge, kg):
        # Create market and a correlation relationship
        kg.add_entity("mkt_settle", "market", "Settled Market")
        kg.add_entity("mkt_other", "market", "Other Market")
        kg.add_relationship("mkt_settle", "mkt_other", "correlated_with")
        kg.add_relationship("mkt_settle", "mkt_other", "hedges", valid_from=time.time() + 0.001)

        result = bridge.record_settlement(
            market_id="mkt_settle",
            outcome="yes",
            settlement_price=1.0,
            strategies_affected=["mm_v1"],
        )
        assert result["status"] == "recorded"

        # Active relationships should be expired
        active_rels = kg.get_relationships("mkt_settle", active_only=True)
        corr_hedge = [r for r in active_rels if r["rel_type"] in ("correlated_with", "hedges")]
        assert len(corr_hedge) == 0

    def test_record_regime_change(self, bridge, kg):
        result = bridge.record_regime_change(
            from_regime="normal",
            to_regime="stressed",
            affected_markets=["m_a", "m_b"],
        )
        assert result["status"] == "recorded"
        assert result["regime_transition"] == "normal->stressed"
        assert len(result["markets"]) == 2

        facts_a = kg.get_facts(entity_id="m_a", fact_type="regime_change")
        assert len(facts_a) == 1
        assert "normal -> stressed" in facts_a[0]["content"]

    def test_record_regime_change_no_markets(self, bridge):
        result = bridge.record_regime_change("bull", "bear", affected_markets=[])
        assert result["status"] == "recorded"
        assert result["markets"] == []

    def test_record_edge_decay_severity(self, bridge, kg):
        # Severe: ratio < 0.3
        r_severe = bridge.record_edge_decay("s1", "m_sev", 1.0, 0.2, 0.05)
        assert r_severe["severity"] == "severe"

        # Moderate: ratio < 0.5
        r_mod = bridge.record_edge_decay("s1", "m_mod", 1.0, 0.4, 0.03)
        assert r_mod["severity"] == "moderate"

        # Mild: ratio >= 0.5
        r_mild = bridge.record_edge_decay("s1", "m_mild", 1.0, 0.8, 0.01)
        assert r_mild["severity"] == "mild"

    def test_record_price_move_expiry(self, bridge, kg):
        result = bridge.record_price_move("mkt_pm", 0.65, 0.15, volume=1000)
        assert result["status"] == "recorded"

        facts = kg.get_facts(entity_id="mkt_pm", fact_type="price_move")
        assert len(facts) == 1
        assert facts[0]["expires_at"] is not None
        # Expires roughly 24h from now
        assert facts[0]["expires_at"] > time.time()
        assert facts[0]["expires_at"] < time.time() + 86400 + 60

    def test_link_correlated_markets(self, bridge, kg):
        result = bridge.link_correlated_markets("mkt_a", "mkt_b", 0.85)
        assert result["status"] == "linked"
        assert result["weight"] == 0.85

        rels = kg.get_relationships("mkt_a", direction="outgoing", rel_type="correlated_with")
        assert len(rels) == 1

    def test_link_correlated_markets_expires_old(self, bridge, kg):
        bridge.link_correlated_markets("mkt_x", "mkt_y", 0.7)
        bridge.link_correlated_markets("mkt_x", "mkt_y", 0.9)

        rels = kg.get_relationships("mkt_x", direction="outgoing", rel_type="correlated_with", active_only=True)
        # Only the latest should be active
        assert len(rels) == 1
        assert rels[0]["weight"] == 0.9

    def test_link_market_to_event(self, bridge, kg):
        result = bridge.link_market_to_event("mkt_e", "evt_1", "Election")
        assert result["status"] == "linked"

        event = kg.get_entity("evt_1")
        assert event is not None
        assert event["entity_type"] == "event"
        assert event["name"] == "Election"

    def test_link_hedge_pair(self, bridge, kg):
        result = bridge.link_hedge_pair("mkt_h1", "mkt_h2", hedge_ratio=0.5)
        assert result["status"] == "linked"

        rels = kg.get_relationships("mkt_h1", direction="outgoing", rel_type="hedges")
        assert len(rels) == 1
        assert rels[0]["weight"] == 0.5

    def test_strategy_history_for_market(self, bridge, kg):
        kg.add_entity("mkt_hist", "market", "History Market")
        kg.record_fact("mkt_hist", "outcome", "Backtest s1", confidence=0.7,
                       source="backtest", metadata={"strategy_name": "s1"})
        kg.record_fact("mkt_hist", "outcome", "Backtest s2", confidence=0.8,
                       source="backtest", metadata={"strategy_name": "s2"})
        kg.record_fact("mkt_hist", "observation", "Fill event", confidence=1.0,
                       source="live")

        # All backtest outcomes
        all_hist = bridge.strategy_history_for_market("mkt_hist")
        assert len(all_hist) == 2

        # Filtered to s1
        s1_hist = bridge.strategy_history_for_market("mkt_hist", strategy_name="s1")
        assert len(s1_hist) == 1
        assert s1_hist[0]["metadata"]["strategy_name"] == "s1"

    def test_market_causal_history(self, bridge, kg):
        kg.add_entity("mkt_ch", "market", "Causal Market")
        kg.record_fact("mkt_ch", "observation", "recent", confidence=0.9)

        result = bridge.market_causal_history("mkt_ch", lookback_hours=1.0)
        assert result["market_id"] == "mkt_ch"
        assert len(result["facts"]) >= 1
        assert "neighbors" in result
        assert "context" in result

    def test_market_causal_history_missing_market(self, bridge):
        result = bridge.market_causal_history("nonexistent")
        assert result["market_id"] == "nonexistent"
        assert result["facts"] == [] or isinstance(result["facts"], list)

    def test_similar_market_outcomes(self, bridge, kg):
        # Set up correlated markets with outcomes
        kg.add_entity("mkt_main", "market", "Main")
        kg.add_entity("mkt_corr", "market", "Correlated")
        kg.add_relationship("mkt_main", "mkt_corr", "correlated_with", weight=0.8)
        kg.record_fact("mkt_corr", "outcome", "Good backtest",
                       confidence=0.9, source="backtest",
                       metadata={"strategy_name": "s1"})

        outcomes = bridge.similar_market_outcomes("mkt_main")
        assert len(outcomes) >= 1
        assert outcomes[0].get("correlation_weight") == 0.8
        assert outcomes[0].get("correlated_market") == "mkt_corr"

    def test_similar_market_outcomes_none(self, bridge, kg):
        kg.add_entity("lonely", "market", "Lonely")
        outcomes = bridge.similar_market_outcomes("lonely")
        assert outcomes == []

    def test_sync_discovery_to_graph(self, bridge, kg):
        # Test with dict-based markets
        markets = [
            {"id": "d1", "name": "Dict Market 1", "exchange": "polymarket"},
            {"id": "d2", "name": "Dict Market 2", "exchange": "kalshi"},
        ]
        result = bridge.sync_discovery_to_graph(markets)
        assert result["added"] == 2
        assert result["errors"] == 0
        assert result["total"] == 2

        # Verify entities created
        e1 = kg.get_entity("d1")
        assert e1 is not None
        assert e1["name"] == "Dict Market 1"

        # Exchange entity should exist
        ex = kg.get_entity("exchange:polymarket")
        assert ex is not None
        assert ex["entity_type"] == "exchange"

    def test_sync_discovery_to_graph_updates_existing(self, bridge, kg):
        kg.add_entity("existing", "market", "Old Name")
        markets = [{"id": "existing", "name": "New Name", "exchange": "kalshi"}]
        result = bridge.sync_discovery_to_graph(markets)
        assert result["updated"] == 1
        assert result["added"] == 0

        e = kg.get_entity("existing")
        assert e["name"] == "New Name"

    def test_sync_discovery_to_graph_with_objects(self, bridge, kg):
        # Simulate Market-like objects with attributes
        import types
        m = types.SimpleNamespace(
            id="obj_1", question="Will X happen?", name="Fallback name",
            exchange="polymarket", condition_id="cid", active=True,
        )
        result = bridge.sync_discovery_to_graph([m])
        assert result["added"] == 1
        e = kg.get_entity("obj_1")
        assert e is not None
        assert e["name"] == "Will X happen?"

    def test_prune_stale_facts(self, bridge, kg):
        kg.add_entity("mkt_pr", "market", "Prune Market")
        # Record a fact with past expiry
        kg.record_fact("mkt_pr", "observation", "old", confidence=0.5,
                       expires_at=time.time() - 100)

        result = bridge.prune_stale_facts(max_age_days=30)
        assert result["removed"] >= 1
        assert result["max_age_days"] == 30

    def test_edge_history(self, bridge, kg):
        kg.add_entity("mkt_eh", "market", "Edge History")
        kg.record_fact("mkt_eh", "edge_detected", "Edge found", confidence=0.8,
                       source="backtest")
        kg.record_fact("mkt_eh", "observation", "Not an edge", confidence=0.5)

        history = bridge.edge_history("mkt_eh")
        assert len(history) == 1
        assert history[0]["fact_type"] == "edge_detected"
