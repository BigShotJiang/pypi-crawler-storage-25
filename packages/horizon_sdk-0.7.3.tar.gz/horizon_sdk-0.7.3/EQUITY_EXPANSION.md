# Equity & Options Expansion — Tracking

Status as of 2026-03-19. All items verified against `cargo check --tests` + `pytest tests/` (4682 passed).

---

## Phase 1: Rust Core Type Generalization — COMPLETE

| Item | File | Status |
|------|------|--------|
| `Side::Long` variant | `src/types.rs` | Done |
| `AssetClass` enum (PredictionMarket, Equity, Option, Crypto, Future) | `src/types.rs` | Done |
| `OptionType` enum (Call, Put) | `src/types.rs` | Done |
| Market struct: `asset_class`, `underlying`, `strike_price`, `option_type`, `multiplier` | `src/types.rs` | Done |
| `token_id()` handles `Side::Long` → `None` | `src/types.rs` | Done |
| PositionTracker: 5 methods updated for `Side::Long` lookups | `src/positions.rs` | Done |
| PositionTracker: 6 new `Side::Long` tests | `src/positions.rs` | Done |
| DB serialization: `Side::Long` ↔ `"long"` | `src/db.rs` | Done |
| PyO3 module: `AssetClass`, `OptionType` registered | `src/lib.rs` | Done |
| Alpaca: `Side::Yes` → `Side::Long` in fills/positions | `src/exchanges/alpaca.rs` | Done |
| IBKR: `Side::Yes` → `Side::Long` in fills/positions | `src/exchanges/ibkr.rs` | Done |
| Coinbase: `Side::Yes` → `Side::Long` in fills/positions | `src/exchanges/coinbase.rs` | Done |
| Robinhood: `Side::Yes` → `Side::Long` in fills/positions | `src/exchanges/robinhood.rs` | Done |
| Kalshi: `Side::Long` arm in `kalshi_side()` and submit dispatch | `src/exchanges/kalshi.rs` | Done |
| Paper exchange: `Side::Long` passes through (no changes needed) | `src/exchanges/paper.rs` | Done |

## Phase 2: Python SDK Updates — COMPLETE

| Item | File | Status |
|------|------|--------|
| `InventorySnapshot.net()` handles `Side.Long` | `python/horizon/context.py` | Done |
| Price validation: removed 0-1 hardcode, now `price > 0` | `python/horizon/tools.py` | Done |
| `market_side` accepts `"long"` → `Side.Long` | `python/horizon/tools.py` | Done |
| Serialization helpers: `Side.Long` → `"long"` | `python/horizon/tools.py` | Done |
| `_contingent_to_dict`: `Side.Long` serialization | `python/horizon/tools.py` | Done |
| Mark price: `_is_prediction_market()` detection | `python/horizon/strategy.py` | Done |
| Mark price: equities use `Side.Long`, skip `Side.No` complement | `python/horizon/strategy.py` | Done |
| Token ID: skip lookup for non-prediction markets | `python/horizon/strategy.py` | Done |
| Discovery: `_discover_alpaca()` backend | `python/horizon/discovery.py` | Done |
| Discovery: `_discover_ibkr()` backend (SSL-safe) | `python/horizon/discovery.py` | Done |
| Discovery: dispatch for `exchange="alpaca"/"ibkr"` | `python/horizon/discovery.py` | Done |
| `Risk.equity()` classmethod with equity defaults | `python/horizon/risk.py` | Done |
| `price_min`/`price_max` passthrough in Risk builder | `python/horizon/risk.py` | Done |
| Exports: `AssetClass`, `OptionType` in `__init__.py` | `python/horizon/__init__.py` | Done |

## Phase 3: CLI & MCP — COMPLETE

| Item | File | Status |
|------|------|--------|
| `equity` CLI group (quote, search, options-chain, greeks, iv-surface, screener) | `python/horizon/cli/equity.py` | Done |
| CLI group registered | `python/horizon/cli/__init__.py` | Done |
| `--market-side` expanded to `["yes", "no", "long"]` | `python/horizon/cli/engine.py` | Done |
| `--exchange` help includes `alpaca`, `ibkr` | `python/horizon/cli/discovery.py` | Done |
| MCP `submit_order`: price not limited to 0-1 | `python/horizon/mcp_server.py` | Done |
| MCP `discover_markets`: supports `alpaca`/`ibkr` | `python/horizon/mcp_server.py` | Done |
| MCP `equity` compound tool (6 actions) | `python/horizon/mcp_server.py` | Done |

## Phase 4: Documentation — COMPLETE

| Item | File | Status |
|------|------|--------|
| Tabbed nav: Prediction Markets / Equities & Options | `docs/mint.json` | Done |
| Equity trading guide | `docs/equities.mdx` | Done |
| Options trading guide | `docs/options-trading.mdx` | Done |
| Updated ~20 existing doc pages for multi-asset | Various `docs/` | Done |

## Quality Fixes (post-implementation audit)

| Fix | File | Issue |
|-----|------|-------|
| `_contingent_to_dict` Side.Long mapping | `python/horizon/tools.py` | Was mapping Long → "no" |
| IBKR discovery SSL verification | `python/horizon/discovery.py` | `verify=False` only for localhost, env var override |
| 6 Side::Long position tracker tests | `src/positions.rs` | No test coverage for Long variant |

## Verification

```
cargo check --tests     → PASS (22 pre-existing warnings, 0 errors)
maturin develop         → horizon-sdk 0.6.1 installed
pytest tests/           → 4682 passed, 4 skipped, 8 warnings (80.92s)
```

---

## Remaining Work

### High Priority
- [ ] `Side::Short` variant — needed for short selling equities and put positions
- [ ] Options position sizing — Kelly with Greeks (delta-adjusted notional)
- [ ] Options PnL tracking — multiplier-aware (100x for standard equity options)
- [ ] Market struct: `expiry` field for options/futures expiration dates
- [ ] Rust-native equity discovery (move Alpaca/IBKR asset search from Python to Rust)

### Medium Priority
- [ ] Options strategy construction (spreads, straddles, iron condors) at the type level
- [ ] Margin requirement calculation (Reg-T, portfolio margin)
- [ ] Dividend adjustment for equity positions
- [ ] Corporate action handling (splits, mergers)
- [ ] Multi-leg order support in Engine

### Lower Priority
- [ ] Futures support (`Side::Long`/`Side::Short`, margin, roll logic)
- [ ] Private equity / illiquid asset modeling
- [ ] Tax lot tracking (FIFO/LIFO) for equity positions
- [ ] Benchmark tracking (SPY, QQQ) in fund analytics
- [ ] Options implied volatility surface caching in Rust
