# The Hive: Complete Tutorial

This tutorial walks through setting up and operating the Hive, a self-evolving autonomous trading swarm built on the Horizon SDK. The Hive coordinates up to 50 independent trading agents across prediction markets, equities, options, and crypto through 13 compiled Rust subsystems.

## Prerequisites

```bash
# Build and install the SDK
maturin develop --features skip-auth

# Verify the Hive subsystems are available
python -c "from horizon.hive import HiveController, HiveConfig; print('OK')"
```

## 1. Creating a Hive

```python
from horizon.hive import HiveController, HiveConfig
from horizon._horizon import AutonomyMode, PheromoneChannel, Severity

config = HiveConfig(
    total_capital=100_000,        # Total AUM across all agents
    max_agents=50,                # Maximum concurrent agents
    initial_mode=AutonomyMode.Observe,  # Start in watch-only mode
    host="0.0.0.0",
    port=8780,
    auth_token="your-secret-token",
)

hive = HiveController(config)
```

### Key Configuration Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `total_capital` | 100,000 | Total capital across all agents |
| `max_agents` | 50 | Maximum fleet size |
| `initial_mode` | Observe | Starting autonomy mode |
| `max_capital_per_agent_pct` | 0.15 | No single agent gets more than 15% |
| `max_drawdown_pct` | 0.20 | Portfolio-wide drawdown limit |
| `fitness_gamma` | 1.5 | Selection pressure (higher = more aggressive) |
| `min_sharpe_paper` | 1.0 | Sharpe required to graduate from paper |
| `min_sharpe_shadow` | 1.2 | Sharpe required to graduate from shadow |
| `avalanche_reserve_pct` | 0.15 | Capital held back for crises |
| `dream_enabled` | True | Offline accelerated evolution between sessions |
| `pheromone_tick_interval` | 1.0 | Seconds between pheromone decay ticks |
| `criticality_check_interval` | 60.0 | Seconds between systemic risk checks |

## 2. Spawning Agents

Agents are created from 9 archetype templates, each with pre-tuned hyperparameters:

```python
# Spawn from templates
a1 = hive.spawn_agent("momentum", markets=["BTC-YES"], capital=5000.0)
a2 = hive.spawn_agent("mean_reversion", markets=["ETH-YES"], capital=3000.0)
a3 = hive.spawn_agent("arbitrage", markets=["BTC-YES", "ETH-YES"], capital=8000.0)
a4 = hive.spawn_agent("event_driven", markets=["FED-RATE-YES"], capital=4000.0)
a5 = hive.spawn_agent("market_maker", markets=["BTC-YES"], capital=6000.0)

print(f"Agent {a1.agent_id}: archetype={a1.genome.archetype}, capital={a1.capital}")
```

### Available Templates

| Template | Strategy Style |
|----------|---------------|
| `momentum` | Trend following, breakout detection |
| `mean_reversion` | Statistical reversion to fair value |
| `market_maker` | Two-sided quoting, inventory management |
| `arbitrage` | Cross-venue price discrepancies |
| `volatility` | Vol surface, straddles, calendar spreads |
| `event_driven` | News, earnings, resolution catalysts |
| `macro` | Rate expectations, yield curve, inflation |
| `copy` | Behavioral cloning of operator style |
| `liquidation` | Forced liquidation flow detection |

List all templates programmatically:

```python
print(hive.factory.available_templates())
# ['arbitrage', 'copy', 'event_driven', 'liquidation', 'macro',
#  'market_maker', 'mean_reversion', 'momentum', 'volatility']
```

## 3. The Coordinator: Fleet Management

The SwarmCoordinator manages the agent lifecycle: fitness scoring, selection pressure, promotion, culling, and capital rebalancing.

```python
# Run one coordinator tick
result = hive.coordinator.tick()
print(result)
# {'tick': 1, 'total_agents': 5, 'fitness_updated': 5,
#  'promoted': 5, 'culled': 0, 'scaled': 0, 'rebalanced': False}
```

Each tick:
1. Updates fitness scores for all agents (composite of Sharpe, drawdown, profit factor, diversity)
2. Culls agents past `age_cull_days` (default 30) that haven't earned promotion
3. Promotes agents that meet Sharpe thresholds: Paper (1.0) to Shadow (1.2) to Live
4. Rebalances capital using fitness-weighted power-law allocation

### Agent Lifecycle

```
Spawned -> Paper -> Shadow -> Live -> (Thriving | Culled | Blacklisted)
```

```python
# View all agents
agents = hive.coordinator.all_agents()
for a in agents:
    print(f"  {a.agent_id}: lifecycle={a.lifecycle}, sharpe={a.sharpe:.2f}, capital={a.capital}")

# Agent ranking by fitness
ranking = hive.coordinator.agent_ranking()

# Kill an underperformer
hive.coordinator.kill_agent(a3.agent_id, "negative sharpe for 7 days")

# Scale capital
hive.coordinator.scale_agent(a1.agent_id, 10000.0)

# Pause / resume
hive.coordinator.pause_agent(a2.agent_id)
hive.coordinator.resume_agent(a2.agent_id)
```

## 4. Pheromone Field: Emergent Coordination

Agents coordinate without direct communication by depositing pheromone signals into a shared 9-channel field. Signals decay over time and diffuse to related markets.

```python
# Agent deposits a bullish signal on BTC, weighted by fitness
hive.pheromone.deposit("BTC-YES", PheromoneChannel.Bullish, 0.8, 1.5)

# Another agent senses the field before trading
readings = hive.pheromone.sense("BTC-YES")
print(f"Bullish:    {readings.bullish:.2f}")
print(f"Bearish:    {readings.bearish:.2f}")
print(f"Crowding:   {readings.crowding:.2f}")
print(f"Opportunity:{readings.opportunity:.2f}")
print(f"Toxicity:   {readings.toxicity:.2f}")
print(f"Liquidity:  {readings.liquidity:.2f}")

# Tick causes decay + diffusion
hive.pheromone.tick(1.0, neighbors={}, agent_markets={}, max_per_market=5)

# View all markets with pheromone activity
snapshot = hive.pheromone.snapshot()
```

### 9 Channels

| Channel | What It Signals |
|---------|-----------------|
| `Bullish` / `Bearish` | Directional conviction from agents actively trading |
| `Volatility` | Agents detecting unusual price movement |
| `Crowding` | How many agents are on the same market (auto-computed) |
| `Opportunity` | Untapped edge detected but not yet exploited |
| `Toxicity` | Adverse selection or market manipulation detected |
| `Liquidity` | Available depth for execution |
| `RegimeTrend` / `RegimeMR` | Current market regime classification |

The crowding channel is the key self-organizing mechanism. When too many agents pile into the same market, crowding rises automatically, pushing agents toward less crowded opportunities. No allocation logic required.

## 5. Evolution: Breeding New Strategies

The EvolutionEngine uses NSGA-II multi-objective optimization across 5 island populations.

```python
# Run an evolution cycle
result = hive.run_evolution_cycle(generations=10)
print(f"Generation: {result['generation']}")
print(f"Best fitness: {result['best_fitness']:.4f}")
print(f"Archive coverage: {result['archive_coverage']:.2%}")
print(f"Converged: {result['converged']}")
```

### MAP-Elites: Forced Diversity

The 300-cell quality-diversity archive prevents evolutionary convergence. Every strategy genome maps to a cell based on 4 behavioral dimensions:

| Dimension | Bins | Values |
|-----------|------|--------|
| Holding period | 5 | Ultra-short to long-term |
| Directional bias | 5 | Strong short to strong long |
| Volatility preference | 3 | Low, medium, high |
| Asset focus | 4 | Equities, crypto, prediction markets, cross-asset |

```python
# Archive status
print(f"Cells filled: {hive.archive.cells_filled()}/300")
print(f"Coverage: {hive.archive.coverage():.2%}")

# Get best strategy for a specific regime
best_trending = hive.archive.get_best_for_regime("trending")
best_mean_rev = hive.archive.get_best_for_regime("mean_reverting")
```

### Dream State: Offline Evolution

When markets close, the Hive can run accelerated evolution against synthetic scenarios:

```python
# Run 10,000 generations offline (config.dream_enabled must be True)
dream_report = hive.dream.run(generations=10_000)
print(f"Dream complete: {dream_report}")
```

## 6. Consensus Engine: Collective Intelligence

Four layers of collective decision-making:

1. **IC-weighted signal combination** for routine allocation
2. **Internal prediction markets** where agents bet on outcomes
3. **Mixture of Experts gating** for regime-conditional routing
4. **Dempster-Shafer belief aggregation** for conflicting views

```python
# Create an internal prediction market
market_id = hive.consensus.create_market("BTC > 100k by EOY?", deadline=1.8e9)

# Agents submit views (probability, confidence, capital weight)
hive.consensus.submit_view(market_id, a1.agent_id, 0.75, 0.9, 1.0)
hive.consensus.submit_view(market_id, a2.agent_id, 0.45, 0.7, 1.0)
hive.consensus.submit_view(market_id, a3.agent_id, 0.60, 0.8, 1.0)

# Get consensus
prob = hive.consensus.consensus_probability(market_id)
print(f"Consensus probability: {prob:.2f}")

# List active markets
markets = hive.consensus.active_markets()

# Resolve when outcome is known
hive.consensus.resolve_market(market_id, True)
```

## 7. Reputation System: Bayesian Trust

Each agent has a Bayesian Beta-distribution trust score that weights its influence on capital allocation and pheromone deposits.

```python
# Update after an agent's trade resolves
hive.reputation.update(a1.agent_id, success=True, sharpe=1.8)
hive.reputation.update(a1.agent_id, success=True, sharpe=1.5)
hive.reputation.update(a1.agent_id, success=False, sharpe=-0.3)

# Get score
score, confidence = hive.reputation.get(a1.agent_id)
print(f"Score: {score:.3f}, Confidence: {confidence:.3f}")

# Full ranking
ranking = hive.reputation.ranking()
for agent_id, rep_score, rep_conf in ranking:
    print(f"  {agent_id}: {rep_score:.3f} (conf={rep_conf:.3f})")
```

## 8. Criticality Monitor: Systemic Risk

15 indicators computed every 60 seconds from price series, volume, and feed spreads:

```python
# Run a criticality check
report = hive.criticality.compute_report(
    price_series={"BTC": prices, "ETH": eth_prices},
    volume_series={"BTC": volumes, "ETH": eth_volumes},
    feed_spreads={"BTC": 0.01, "ETH": 0.02},
    vpin_aggregate=0.3,
    bocpd_probability=0.1,
    vine_tail_risk=0.05,
)

print(f"Hurst exponent: {report.hurst_exponent:.3f}")
print(f"Correlation convergence: {report.correlation_convergence:.3f}")
print(f"Contagion score: {report.contagion_score:.3f}")
print(f"Market entropy: {report.market_entropy:.3f}")
print(f"VPIN: {report.vpin_aggregate:.3f}")
print(f"Liquidity: {report.liquidity_score:.3f}")
print(f"Is critical: {report.is_critical}")
print(f"Warning count: {report.warning_count()}")
```

When criticality exceeds the threshold (default 0.30), the Hive deploys the avalanche reserve (15% of capital held back for crises).

## 9. Causal Engine: Beyond Correlation

Granger causality, transfer entropy, and lead-lag detection across all tracked markets:

```python
# Feed price observations
for price in btc_prices:
    hive.causal.update_price("BTC", price)
for price in eth_prices:
    hive.causal.update_price("ETH", price)

# Build causal graph
graph = hive.causal.build_causal_graph()
for edge in graph.edges:
    print(f"  {edge.source} -> {edge.target}: "
          f"granger_p={edge.granger_pvalue:.4f}, lag={edge.lag}")

# Detect causal breaks (regime shifts)
breaks = hive.causal.detect_causal_break()
```

## 10. Self-Impact Model: Trading Your Own Wake

The Hive knows its orders move prices and gates any order where predicted impact exceeds half the estimated alpha.

```python
# Record fills to calibrate the model
hive.impact.record_fill("BTC-YES", size=100.0, expected_price=0.65, actual_price=0.652)

# Calibrate from accumulated fills
hive.impact.calibrate()

# Predict impact before placing an order
impact = hive.impact.predict_impact("BTC-YES", size=500.0)
print(f"Predicted impact: {impact:.4%}")

# Gate check: is the order worth it given the alpha estimate?
allowed = hive.impact.gate_order("BTC-YES", size=500.0, alpha_estimate=0.03)
print(f"Order allowed: {allowed}")

# Internal crossing: net opposing agent orders
crossed = hive.impact.submit_for_crossing("BTC-YES", "buy", 200.0)
print(f"Crossed internally: {crossed:.1f} units")
```

## 11. Metamorphic Executor: Anti-Fingerprint Orders

Every order gets shattered into randomized child orders so no two execution runs look the same.

```python
# Set available venues
hive.metamorphic.set_venues(["polymarket", "kalshi", "coinbase"])

# Create an execution plan
plan = hive.metamorphic.create_plan("BTC-YES", "buy", total_size=1000.0, urgency=0.5)

print(f"Plan: {plan.plan_id}, {len(plan.slices)} slices")
for sl in plan.slices:
    print(f"  size={sl.size:.1f}, venue={sl.venue}, "
          f"delay={sl.delay_seconds:.2f}s, aggression={sl.aggression:.2f}, "
          f"decoy={sl.is_decoy}")

# Increase randomization (e.g., after detecting front-running)
hive.metamorphic.increase_randomization()

# Check behavioral entropy
entropy = hive.metamorphic.behavioral_entropy()
print(f"Entropy: {entropy:.2f}")  # 1.0 = fully random
```

## 12. Imprint System: Learning Your Style

The Hive observes your trading actions and learns to replicate your decision-making.

```python
import time
from horizon._horizon import ImprintAction

# Record operator actions
action = ImprintAction(
    timestamp=time.time(),
    action_type="submit_order",
    action_params={"market": "BTC-YES", "side": "buy", "size": "100"},
    feed_snapshots={"BTC-YES": 0.65},
    pnl=500.0,
    regime="trending",
    volatility=0.02,
    time_of_day=14.5,
    day_of_week=2,
)
hive.imprint.observe(action)

# After 100+ observations, train the model
hive.imprint.train(epochs=50)

# Get a suggestion for the current state
suggestion = hive.imprint.suggest(feed_snapshots={"BTC-YES": 0.70}, regime="trending")
print(f"Imprint suggests: {suggestion}")

# Status
print(hive.imprint.status())
# {'actions_observed': 1, 'model_trained': False, 'min_actions': 100, ...}
```

## 13. Kill Chain: Automated Incident Response

Six phases execute in sequence. Once triggered, all phases run. The Hive cannot suppress an incident.

```python
# Trigger manually (or automatically via CriticalityMonitor)
hive.kill_chain.trigger(
    Severity.Sev1Critical,
    "portfolio_drawdown_15pct",
    ["agent-001", "agent-002"],
    pnl_impact=-15000.0,
)

# Register response handlers (called at each phase)
hive.kill_chain.on_contain(lambda incident: print(f"Containing: {incident}"))
hive.kill_chain.on_preserve(lambda incident: print(f"Preserving state"))
hive.kill_chain.on_diagnose(lambda incident: print(f"Diagnosing root cause"))
hive.kill_chain.on_remediate(lambda incident: print(f"Remediating"))
hive.kill_chain.on_learn(lambda incident: print(f"Recording for evolution"))

# Blacklist a genome permanently
hive.kill_chain.blacklist_genome("bad-genome-id")
is_banned = hive.kill_chain.is_blacklisted("bad-genome-id")

# View incident history
incidents = hive.kill_chain.incident_history()
print(hive.kill_chain.status())
```

| Phase | Action |
|-------|--------|
| Detect | Identify incident type and severity |
| Contain | Pause affected agents, halt new orders |
| Preserve | Snapshot full state for post-mortem |
| Diagnose | Identify root cause (which agent, which strategy) |
| Remediate | Kill responsible agents, blacklist their genomes |
| Learn | Record the incident for evolutionary pressure |

## 14. Autonomy Controller: Earning Trust

The Hive starts in Observe mode and earns autonomy through demonstrated performance.

| Mode | Behavior | Graduation Criteria |
|------|----------|---------------------|
| **Observe** | Watch only, no actions | 100+ imprint observations |
| **Suggest** | Suggest actions, human reviews | 70%+ acceptance rate over 14 days |
| **Supervised** | Auto-approve routine, ask for major decisions | 80%+ approval rate over 28 days |
| **Autonomous** | Independent within guardrails | 6+ months profitable, Sharpe > user Sharpe, 0 critical incidents in 90 days |
| **Skynet** | Full autonomy with self-modifying guardrails | Manual promotion only |

```python
# Check current mode
print(hive.autonomy.status())
# {'mode': 'observe', 'acceptance_rate_14d': 0.0, ...}

# Check if a decision is allowed in the current mode
allowed = hive.autonomy.check_permission(DecisionType.SpawnAgent)

# In Suggest mode: record suggestion outcomes
hive.autonomy.record_suggestion_accepted()
hive.autonomy.record_suggestion_rejected()

# In Supervised mode: approve/reject decisions
pending = hive.autonomy.pending()
hive.autonomy.approve(pending[0])
# or
hive.autonomy.reject(pending[0])

# Check if ready for graduation
hive.autonomy.evaluate_graduation()

# Force mode change (bypasses graduation criteria)
hive.autonomy.set_mode(AutonomyMode.Supervised)
```

## 15. Running the Hive

### Non-blocking Start

```python
hive.start()  # Starts oversight loop + WebSocket server in background threads
# ... do other work ...
hive.stop()   # Clean shutdown
```

### Blocking Run

```python
hive.run()  # Runs the WebSocket server in the main thread (blocks until Ctrl+C)
```

### Full Status

```python
status = hive.status()
print(f"Agents:      {status['swarm']['total_agents']}")
print(f"Autonomy:    {status['autonomy']['mode']}")
print(f"Generation:  {status['generation']}")
print(f"Archive:     {status['archive_cells']}/300 cells")
print(f"Incidents:   {status['incidents_active']}")
print(f"Running:     {status['running']}")
```

### Emergency Stop

```python
hive.kill_switch()  # Pauses all agents, cancels all orders, only human can restart
```

## 16. Remote Connection

Connect to a running Hive from anywhere:

```python
from horizon.hive import HiveClient

client = HiveClient("ws://hive-server:8780", token="your-secret-token")
client.connect()

# All operations available remotely
print(client.status())
client.spawn(template="momentum", markets=["BTC-YES"])
client.kill(agent_id="hv-abc123")
client.set_mode("supervised")
```

## 17. CLI Commands

25 commands under `horizon hive`:

```bash
# Status
horizon hive status
horizon hive agents
horizon hive agent <agent-id>

# Lifecycle
horizon hive spawn momentum --markets BTC-YES --capital 5000
horizon hive kill <agent-id> --reason "negative sharpe"
horizon hive pause <agent-id>
horizon hive resume <agent-id>
horizon hive scale <agent-id> 10000

# Autonomy
horizon hive mode
horizon hive pending
horizon hive approve <decision-id>
horizon hive reject <decision-id>

# Intelligence
horizon hive evolve --generations 100
horizon hive dream --generations 10000
horizon hive pheromone BTC-YES
horizon hive reputation
horizon hive consensus
horizon hive criticality
horizon hive incidents

# Emergency
horizon hive kill-switch

# Remote
horizon hive connect ws://server:8780 --token secret
horizon hive server
```

## 18. MCP Server

Expose the Hive to LLMs via MCP (Model Context Protocol):

```bash
python -m horizon.mcp_hive
# or with auth
HIVE_MCP_TOKEN=secret python -m horizon.mcp_hive
```

25+ tools available: `hive_status`, `hive_spawn`, `hive_kill`, `hive_evolve`, `hive_dream`, `hive_pheromone`, `hive_consensus`, `hive_criticality`, and more.

## Complete Example

```python
from horizon.hive import HiveController, HiveConfig
from horizon._horizon import AutonomyMode, PheromoneChannel, Severity

# 1. Configure
config = HiveConfig(
    total_capital=100_000,
    max_agents=30,
    initial_mode=AutonomyMode.Observe,
    fitness_gamma=1.5,
    min_sharpe_paper=1.0,
    min_sharpe_shadow=1.2,
    avalanche_reserve_pct=0.15,
    dream_enabled=True,
)

# 2. Create
hive = HiveController(config)

# 3. Spawn a diverse fleet
for template in ["momentum", "mean_reversion", "arbitrage", "event_driven", "macro"]:
    hive.spawn_agent(template, markets=["BTC-YES", "ETH-YES"], capital=10_000.0)

# 4. Run coordinator tick
tick = hive.coordinator.tick()
print(f"Fleet: {tick['total_agents']} agents, {tick['promoted']} promoted")

# 5. Run evolution to breed new strategies
evo = hive.run_evolution_cycle(generations=50)
print(f"Evolution gen={evo['generation']}, archive={evo['archive_coverage']:.2%}")

# 6. Check pheromone field
hive.pheromone.deposit("BTC-YES", PheromoneChannel.Bullish, 0.9, 1.5)
readings = hive.pheromone.sense("BTC-YES")
print(f"BTC-YES pheromone: bullish={readings.bullish:.2f}, crowding={readings.crowding:.2f}")

# 7. Create consensus market
mid = hive.consensus.create_market("BTC > 100k by 2027?", deadline=1.8e9)
for agent in hive.coordinator.all_agents()[:3]:
    hive.consensus.submit_view(mid, agent.agent_id, 0.65, 0.8, 1.0)
print(f"Consensus: {hive.consensus.consensus_probability(mid):.2f}")

# 8. Full status
status = hive.status()
print(f"\nHive Status:")
print(f"  Agents:    {status['swarm']['total_agents']}")
print(f"  Autonomy:  {status['autonomy']['mode']}")
print(f"  Archive:   {status['archive_cells']}/300 cells")
print(f"  Generation:{status['generation']}")

# 9. Start the server (blocking)
# hive.run()
```

## Architecture Summary

The Hive is built from 13 compiled Rust subsystems (opaque binary, IP protected) with a thin Python orchestration layer:

| Layer | Subsystems |
|-------|-----------|
| **Coordination** | SwarmCoordinator, PheromoneField, ConsensusEngine |
| **Evolution** | AgentFactory, EvolutionEngine, MAPElitesArchive |
| **Intelligence** | CriticalityMonitor, CausalEngine, SelfImpactModel, ImprintSystem |
| **Safety** | AutonomyController, KillChain, MetamorphicExecutor, ReputationSystem |

All subsystems communicate via direct PyO3 function calls (no IPC, no serialization overhead). The Python layer handles configuration, persistence (SQLite), WebSocket server, and the oversight loop.
