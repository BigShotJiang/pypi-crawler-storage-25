//! AgentFactory — agent creation from 6 sources with 9 template configs.
//!
//! Templates map archetype names to hyperparameter dictionaries.  Agents can be
//! spawned from templates, cloned (with optional mutation), created by users,
//! or evolved from a StrategyGenome.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use super::types::{
    AgentLifecycle, HiveAgent, SpawnSource, StrategyArchetype, StrategyGenome,
};

// ---------------------------------------------------------------------------
// Deterministic PRNG (same LCG as evolution.rs)
// ---------------------------------------------------------------------------

struct Rng {
    state: u64,
}

impl Rng {
    fn new(seed: u64) -> Self {
        Self {
            state: seed.wrapping_add(1),
        }
    }

    fn next_u64(&mut self) -> u64 {
        self.state = self
            .state
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        self.state
    }

    fn next_f64(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 / (1u64 << 53) as f64
    }
}

// ---------------------------------------------------------------------------
// Template configs (9 archetypes)
// ---------------------------------------------------------------------------

fn template_configs() -> HashMap<String, HashMap<String, f64>> {
    let mut templates: HashMap<String, HashMap<String, f64>> = HashMap::new();

    // momentum
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.5);
        hp.insert("position_size_mult".into(), 1.0);
        hp.insert("stop_loss_pct".into(), 0.05);
        hp.insert("take_profit_pct".into(), 0.15);
        hp.insert("rebalance_interval".into(), 3600.0);
        hp.insert("max_position_pct".into(), 0.10);
        templates.insert("momentum".into(), hp);
    }

    // mean_reversion
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 1.5);
        hp.insert("position_size_mult".into(), 0.8);
        hp.insert("stop_loss_pct".into(), 0.03);
        hp.insert("take_profit_pct".into(), 0.08);
        templates.insert("mean_reversion".into(), hp);
    }

    // market_maker
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.1);
        hp.insert("position_size_mult".into(), 1.5);
        hp.insert("stop_loss_pct".into(), 0.02);
        hp.insert("take_profit_pct".into(), 0.04);
        hp.insert("spread_mult".into(), 2.0);
        templates.insert("market_maker".into(), hp);
    }

    // arbitrage
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.01);
        hp.insert("position_size_mult".into(), 2.0);
        hp.insert("stop_loss_pct".into(), 0.01);
        templates.insert("arbitrage".into(), hp);
    }

    // volatility
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.3);
        hp.insert("position_size_mult".into(), 0.7);
        hp.insert("stop_loss_pct".into(), 0.08);
        templates.insert("volatility".into(), hp);
    }

    // event_driven
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.7);
        hp.insert("position_size_mult".into(), 1.2);
        hp.insert("stop_loss_pct".into(), 0.04);
        templates.insert("event_driven".into(), hp);
    }

    // macro
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.4);
        hp.insert("position_size_mult".into(), 0.6);
        hp.insert("stop_loss_pct".into(), 0.10);
        templates.insert("macro".into(), hp);
    }

    // copy
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.0);
        hp.insert("position_size_mult".into(), 0.5);
        hp.insert("stop_loss_pct".into(), 0.05);
        templates.insert("copy".into(), hp);
    }

    // liquidation
    {
        let mut hp = HashMap::new();
        hp.insert("signal_threshold".into(), 0.0);
        hp.insert("position_size_mult".into(), 1.0);
        hp.insert("stop_loss_pct".into(), 0.0);
        templates.insert("liquidation".into(), hp);
    }

    templates
}

fn archetype_from_name(name: &str) -> Option<StrategyArchetype> {
    match name {
        "momentum" => Some(StrategyArchetype::Momentum),
        "mean_reversion" => Some(StrategyArchetype::MeanReversion),
        "market_maker" => Some(StrategyArchetype::MarketMaker),
        "arbitrage" => Some(StrategyArchetype::Arbitrage),
        "volatility" => Some(StrategyArchetype::Volatility),
        "event_driven" => Some(StrategyArchetype::EventDriven),
        "macro" => Some(StrategyArchetype::Macro),
        "copy" => Some(StrategyArchetype::Copy),
        "liquidation" => Some(StrategyArchetype::Liquidation),
        _ => None,
    }
}

// ---------------------------------------------------------------------------
// AgentFactory
// ---------------------------------------------------------------------------

/// Agent spawning from 6 sources (template, clone, user, evolution,
/// imprint, opportunistic) with 9 built-in archetype templates.
#[pyclass]
pub struct AgentFactory {
    spawned: AtomicUsize,
    rng_state: std::sync::Mutex<Rng>,
}

#[pymethods]
impl AgentFactory {
    #[new]
    fn new() -> Self {
        let seed = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;
        Self {
            spawned: AtomicUsize::new(0),
            rng_state: std::sync::Mutex::new(Rng::new(seed)),
        }
    }

    /// Spawn an agent from one of the 9 archetype templates.
    fn spawn_from_template(
        &self,
        archetype: &str,
        markets: Vec<String>,
        capital: f64,
    ) -> PyResult<HiveAgent> {
        let templates = template_configs();
        let hp = templates.get(archetype).ok_or_else(|| {
            pyo3::exceptions::PyValueError::new_err(format!(
                "unknown archetype '{}'; available: {:?}",
                archetype,
                templates.keys().collect::<Vec<_>>()
            ))
        })?;

        let arch = archetype_from_name(archetype);

        let genome = StrategyGenome {
            genome_id: super::types::gen_id("", 12),
            source: SpawnSource::Template,
            archetype: arch,
            generation: 0,
            lineage: vec![],
            hyperparams: hp.clone(),
            holding_period: 0.0,
            directional_bias: 0.0,
            volatility_pref: 0.5,
            asset_focus: "cross".into(),
            fitness: 0.0,
            sharpe: 0.0,
            max_drawdown: 0.0,
            num_trades: 0,
            complexity: 0,
            target_markets: markets.clone(),
            target_exchanges: vec![],
            pipeline_config: HashMap::new(),
        };

        let mut agent = HiveAgent::create(genome, AgentLifecycle::Spawned);
        agent.capital = capital;
        agent.markets = markets;
        agent.hyperparams = hp.clone();

        self.spawned.fetch_add(1, Ordering::Relaxed);
        Ok(agent)
    }

    /// Clone an agent, optionally mutating hyperparameters.
    ///
    /// When `mutate` is true, each hyperparameter is perturbed by
    /// `value * uniform(1 - magnitude, 1 + magnitude)`.
    fn spawn_from_clone(
        &self,
        parent: &HiveAgent,
        mutate: bool,
        mutation_magnitude: f64,
    ) -> HiveAgent {
        let mut genome = parent.genome.clone();
        genome.genome_id = super::types::gen_id("", 12);
        genome.source = SpawnSource::Clone;
        genome.lineage.push(parent.genome.genome_id.clone());

        let mut hp = parent.hyperparams.clone();

        if mutate {
            let mut rng = self.rng_state.lock().unwrap();
            let mag = mutation_magnitude.abs();
            for val in hp.values_mut() {
                // uniform in [1 - mag, 1 + mag]
                let factor = 1.0 - mag + 2.0 * mag * rng.next_f64();
                *val *= factor;
            }
        }

        genome.hyperparams = hp.clone();

        let mut agent = HiveAgent::create(genome, AgentLifecycle::Spawned);
        agent.capital = parent.capital;
        agent.markets = parent.markets.clone();
        agent.hyperparams = hp;

        self.spawned.fetch_add(1, Ordering::Relaxed);
        agent
    }

    /// Spawn a user-created agent (blank slate).
    fn spawn_from_user(&self, markets: Vec<String>, capital: f64) -> HiveAgent {
        let genome = StrategyGenome {
            genome_id: super::types::gen_id("", 12),
            source: SpawnSource::User,
            archetype: None,
            generation: 0,
            lineage: vec![],
            hyperparams: HashMap::new(),
            holding_period: 0.0,
            directional_bias: 0.0,
            volatility_pref: 0.5,
            asset_focus: "cross".into(),
            fitness: 0.0,
            sharpe: 0.0,
            max_drawdown: 0.0,
            num_trades: 0,
            complexity: 0,
            target_markets: markets.clone(),
            target_exchanges: vec![],
            pipeline_config: HashMap::new(),
        };

        let mut agent = HiveAgent::create(genome, AgentLifecycle::Spawned);
        agent.capital = capital;
        agent.markets = markets;

        self.spawned.fetch_add(1, Ordering::Relaxed);
        agent
    }

    /// Spawn from an evolved StrategyGenome (from the evolutionary engine).
    fn spawn_from_evolution(
        &self,
        genome: StrategyGenome,
        markets: Vec<String>,
    ) -> HiveAgent {
        let hp = genome.hyperparams.clone();
        let capital = 0.0; // Capital will be allocated by the coordinator.

        let mut agent = HiveAgent::create(genome, AgentLifecycle::Spawned);
        agent.capital = capital;
        agent.markets = markets;
        agent.hyperparams = hp;

        self.spawned.fetch_add(1, Ordering::Relaxed);
        agent
    }

    /// List available archetype template names.
    fn available_templates(&self) -> Vec<String> {
        let mut names: Vec<String> = template_configs().keys().cloned().collect();
        names.sort();
        names
    }

    /// Get the hyperparameter dictionary for a given archetype template.
    fn template_config(&self, archetype: &str) -> HashMap<String, f64> {
        template_configs()
            .get(archetype)
            .cloned()
            .unwrap_or_default()
    }

    /// Total number of agents spawned by this factory.
    fn agents_spawned(&self) -> usize {
        self.spawned.load(Ordering::Relaxed)
    }
}
