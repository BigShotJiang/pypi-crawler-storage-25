//! SelfImpactModel — Market impact estimation and internal crossing.
//!
//! Estimates execution cost via the Almgren-Chriss-style model:
//!     IS = alpha + beta * sqrt(V / ADV) + gamma * sigma * T
//!
//! Also provides internal order crossing (dark pool-style netting) to
//! reduce market impact when agents trade opposite sides of the same market.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

fn now_secs() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs_f64()
}

// ---------------------------------------------------------------------------
// Internal types
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct FillRecord {
    sqrt_participation: f64, // sqrt(V / ADV)
    sigma_t: f64,            // sigma * T (vol * time proxy, use 1.0)
    impact: f64,             // (actual - expected) / expected or absolute slippage
}

#[derive(Debug, Clone)]
struct PendingOrder {
    market_id: String,
    side: String, // "buy" or "sell"
    size: f64,
    timestamp: f64,
}

struct Inner {
    // Almgren-Chriss coefficients
    alpha: f64,
    beta: f64,
    gamma: f64,

    // Per-market calibration data
    adv_map: HashMap<String, f64>,
    vol_map: HashMap<String, f64>,

    // Fill history for calibration
    fill_records: Vec<FillRecord>,

    // Internal crossing pool
    crossing_enabled: bool,
    pending_orders: Vec<PendingOrder>,

    // Impact gate
    impact_gate_margin: f64,

    // Stats
    total_fills: u64,
    total_crossed: f64,
    calibration_count: u32,
}

// ---------------------------------------------------------------------------
// SelfImpactModel
// ---------------------------------------------------------------------------

#[pyclass]
pub struct SelfImpactModel {
    inner: Mutex<Inner>,
}

#[pymethods]
impl SelfImpactModel {
    #[new]
    #[pyo3(signature = (impact_gate_margin=0.5, internal_crossing=true))]
    fn new(impact_gate_margin: f64, internal_crossing: bool) -> Self {
        Self {
            inner: Mutex::new(Inner {
                alpha: 0.0001,  // default baseline cost
                beta: 0.1,     // participation coefficient
                gamma: 0.01,   // volatility coefficient
                adv_map: HashMap::new(),
                vol_map: HashMap::new(),
                fill_records: Vec::new(),
                crossing_enabled: internal_crossing,
                pending_orders: Vec::new(),
                impact_gate_margin,
                total_fills: 0,
                total_crossed: 0.0,
                calibration_count: 0,
            }),
        }
    }

    /// Record a fill observation for calibration.
    #[pyo3(signature = (market_id, size, expected_price, actual_price, adv, volatility))]
    fn record_fill(
        &self,
        market_id: String,
        size: f64,
        expected_price: f64,
        actual_price: f64,
        adv: f64,
        volatility: f64,
    ) {
        let mut state = self.inner.lock().unwrap();

        // Update per-market maps
        state.adv_map.insert(market_id.clone(), adv);
        state.vol_map.insert(market_id, volatility);

        // Compute slippage as fraction
        let impact = if expected_price.abs() > 1e-15 {
            (actual_price - expected_price).abs() / expected_price.abs()
        } else {
            0.0
        };

        let sqrt_participation = if adv > 1e-15 {
            (size / adv).sqrt()
        } else {
            0.0
        };

        // Use volatility directly as sigma*T proxy (T=1)
        let sigma_t = volatility;

        state.fill_records.push(FillRecord {
            sqrt_participation,
            sigma_t,
            impact,
        });

        state.total_fills += 1;

        // Cap history at 10000
        let rlen = state.fill_records.len();
        if rlen > 10_000 {
            state.fill_records.drain(..rlen - 10_000);
        }
    }

    /// Calibrate the impact model: IS = alpha + beta*sqrt(V/ADV) + gamma*sigma*T
    /// Uses Cramer's rule for the 3x3 OLS normal equations.
    fn calibrate(&self) {
        let mut state = self.inner.lock().unwrap();
        let n = state.fill_records.len();
        if n < 4 {
            return; // Need at least 4 observations for 3 parameters
        }

        // Build normal equations: A^T A x = A^T b
        // Columns: [1, sqrt_participation, sigma_t] -> [alpha, beta, gamma]
        let mut ata = [[0.0f64; 3]; 3];
        let mut atb = [0.0f64; 3];

        for rec in &state.fill_records {
            let row = [1.0, rec.sqrt_participation, rec.sigma_t];
            let y = rec.impact;
            for i in 0..3 {
                atb[i] += row[i] * y;
                for j in 0..3 {
                    ata[i][j] += row[i] * row[j];
                }
            }
        }

        // Cramer's rule for 3x3
        let det3 = |m: [[f64; 3]; 3]| -> f64 {
            m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
        };

        let det_a = det3(ata);
        if det_a.abs() < 1e-30 {
            return; // Singular matrix, skip calibration
        }

        // Replace column i with atb to get determinant for x_i
        let solve_col = |col: usize| -> f64 {
            let mut m = ata;
            for row in 0..3 {
                m[row][col] = atb[row];
            }
            det3(m) / det_a
        };

        let new_alpha = solve_col(0);
        let new_beta = solve_col(1);
        let new_gamma = solve_col(2);

        // Only accept if finite and reasonable
        if new_alpha.is_finite() && new_beta.is_finite() && new_gamma.is_finite() {
            state.alpha = new_alpha;
            state.beta = new_beta.max(0.0); // beta should be non-negative
            state.gamma = new_gamma.max(0.0); // gamma should be non-negative
        }

        state.calibration_count += 1;
    }

    /// Predict market impact (cost fraction) for a given order.
    #[pyo3(signature = (market_id, size))]
    fn predict_impact(&self, market_id: String, size: f64) -> f64 {
        let state = self.inner.lock().unwrap();
        let adv = state.adv_map.get(&market_id).copied().unwrap_or(1e6);
        let vol = state.vol_map.get(&market_id).copied().unwrap_or(0.01);

        let sqrt_participation = if adv > 1e-15 {
            (size / adv).sqrt()
        } else {
            0.0
        };

        let impact = state.alpha + state.beta * sqrt_participation + state.gamma * vol;
        impact.max(0.0)
    }

    /// Gate an order: reject if predicted impact > margin * alpha_estimate.
    /// Returns true if the order should proceed, false if rejected.
    #[pyo3(signature = (market_id, size, alpha_estimate))]
    fn gate_order(&self, market_id: String, size: f64, alpha_estimate: f64) -> bool {
        let state = self.inner.lock().unwrap();
        let adv = state.adv_map.get(&market_id).copied().unwrap_or(1e6);
        let vol = state.vol_map.get(&market_id).copied().unwrap_or(0.01);

        let sqrt_participation = if adv > 1e-15 {
            (size / adv).sqrt()
        } else {
            0.0
        };

        let impact = state.alpha + state.beta * sqrt_participation + state.gamma * vol;
        let threshold = state.impact_gate_margin * alpha_estimate.abs();

        impact <= threshold
    }

    /// Submit an order for internal crossing. Returns the amount that was
    /// crossed (netted) internally. The remainder should go to market.
    #[pyo3(signature = (market_id, side, size))]
    fn submit_for_crossing(&self, market_id: String, side: &str, size: f64) -> f64 {
        let mut state = self.inner.lock().unwrap();
        if !state.crossing_enabled || size <= 0.0 {
            return 0.0;
        }

        let opposite = match side {
            "buy" => "sell",
            "sell" => "buy",
            _ => return 0.0,
        };

        let mut remaining = size;
        let mut crossed = 0.0;
        let now = now_secs();

        // Match against opposite-side pending orders for the same market
        let mut i = 0;
        while i < state.pending_orders.len() && remaining > 1e-15 {
            let po = &state.pending_orders[i];
            if po.market_id == market_id && po.side == opposite {
                let match_size = remaining.min(po.size);
                crossed += match_size;
                remaining -= match_size;

                let new_size = po.size - match_size;
                if new_size < 1e-15 {
                    state.pending_orders.remove(i);
                } else {
                    state.pending_orders[i].size = new_size;
                    i += 1;
                }
            } else {
                i += 1;
            }
        }

        // If there's remainder, add to pending pool
        if remaining > 1e-15 {
            state.pending_orders.push(PendingOrder {
                market_id,
                side: side.to_string(),
                size: remaining,
                timestamp: now,
            });
        }

        state.total_crossed += crossed;
        crossed
    }

    /// Remove stale pending orders older than max_age_seconds.
    #[pyo3(signature = (max_age_seconds=300.0))]
    fn flush_stale(&self, max_age_seconds: f64) {
        let mut state = self.inner.lock().unwrap();
        let cutoff = now_secs() - max_age_seconds;
        state.pending_orders.retain(|po| po.timestamp >= cutoff);
    }

    /// Return model status: coefficients, fill count, crossing stats.
    fn status(&self) -> HashMap<String, f64> {
        let state = self.inner.lock().unwrap();
        let mut m = HashMap::new();
        m.insert("alpha".into(), state.alpha);
        m.insert("beta".into(), state.beta);
        m.insert("gamma".into(), state.gamma);
        m.insert("total_fills".into(), state.total_fills as f64);
        m.insert("fill_records".into(), state.fill_records.len() as f64);
        m.insert("calibration_count".into(), state.calibration_count as f64);
        m.insert("total_crossed".into(), state.total_crossed);
        m.insert("pending_orders".into(), state.pending_orders.len() as f64);
        m.insert("crossing_enabled".into(), if state.crossing_enabled { 1.0 } else { 0.0 });
        m.insert("impact_gate_margin".into(), state.impact_gate_margin);
        m
    }
}
