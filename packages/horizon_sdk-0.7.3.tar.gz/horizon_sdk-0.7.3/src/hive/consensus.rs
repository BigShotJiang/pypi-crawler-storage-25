//! Consensus engine — internal prediction markets and belief aggregation.
//!
//! Provides three aggregation mechanisms:
//! 1. **IC-weighted signal combination** — information-coefficient-scaled blending.
//! 2. **Internal prediction markets** — agents stake views, resolved against outcomes.
//! 3. **Dempster-Shafer belief combination** — mass function fusion with conflict
//!    normalization for combining heterogeneous evidence sources.
//!
//! Expert weights via softmax over mean returns for adaptive weighting.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

use super::types::InternalMarket;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn now_secs() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}

fn gen_market_id() -> String {
    use std::hash::{Hash, Hasher};
    use std::collections::hash_map::DefaultHasher;
    let mut h = DefaultHasher::new();
    now_secs().to_bits().hash(&mut h);
    std::thread::current().id().hash(&mut h);
    let hex = format!("{:016x}", h.finish());
    format!("cm-{}", &hex[..12])
}

// ---------------------------------------------------------------------------
// Internal view tracking
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct View {
    agent_id: String,
    probability: f64,
    confidence: f64,
    capital_weight: f64,
    stake: f64,
}

#[derive(Debug, Clone)]
struct MarketState {
    info: InternalMarket,
    views: Vec<View>,
}

// ---------------------------------------------------------------------------
// ConsensusEngine
// ---------------------------------------------------------------------------

/// Internal prediction markets, IC-weighted signal combination, and
/// Dempster-Shafer belief fusion for swarm consensus.
#[pyclass]
pub struct ConsensusEngine {
    markets: Mutex<HashMap<String, MarketState>>,
    ic_history: Mutex<HashMap<String, Vec<f64>>>,
    ds_beliefs: Mutex<Vec<HashMap<String, f64>>>,
}

#[pymethods]
impl ConsensusEngine {
    #[new]
    fn new() -> Self {
        Self {
            markets: Mutex::new(HashMap::new()),
            ic_history: Mutex::new(HashMap::new()),
            ds_beliefs: Mutex::new(Vec::new()),
        }
    }

    /// IC-weighted signal combination.
    ///
    /// result = sum(ic_i * signal_i) / sum(|ic_i|)
    /// Returns 0.0 if no signals or all ICs are zero.
    fn ic_weighted_combine(
        &self,
        signals: HashMap<String, f64>,
        ics: HashMap<String, f64>,
    ) -> f64 {
        let mut numerator = 0.0_f64;
        let mut denominator = 0.0_f64;

        for (key, &signal) in &signals {
            if let Some(&ic) = ics.get(key) {
                numerator += ic * signal;
                denominator += ic.abs();
            }
        }

        if denominator < 1e-15 {
            0.0
        } else {
            numerator / denominator
        }
    }

    /// Create an internal prediction market. Returns market_id.
    fn create_market(&self, question: &str, deadline: f64) -> String {
        let market_id = gen_market_id();
        let info = InternalMarket {
            market_id: market_id.clone(),
            question: question.to_string(),
            deadline,
            resolved: false,
            outcome: None,
            created_at: now_secs(),
            consensus_probability: 0.5,
        };
        let state = MarketState {
            info,
            views: Vec::new(),
        };
        let mut markets = self.markets.lock().unwrap();
        markets.insert(market_id.clone(), state);
        market_id
    }

    /// Submit an agent's view to an internal market.
    ///
    /// stake = (probability - 0.5) * confidence * capital_weight
    fn submit_view(
        &self,
        market_id: &str,
        agent_id: &str,
        probability: f64,
        confidence: f64,
        capital_weight: f64,
    ) {
        let stake = (probability - 0.5) * confidence * capital_weight;
        let view = View {
            agent_id: agent_id.to_string(),
            probability,
            confidence,
            capital_weight,
            stake,
        };
        let mut markets = self.markets.lock().unwrap();
        if let Some(state) = markets.get_mut(market_id) {
            if !state.info.resolved {
                // Update or insert view for this agent
                if let Some(existing) = state.views.iter_mut().find(|v| v.agent_id == agent_id) {
                    *existing = view;
                } else {
                    state.views.push(view);
                }
                // Recompute consensus
                state.info.consensus_probability = Self::compute_consensus(&state.views);
            }
        }
    }

    /// Resolve a market and compute payouts.
    ///
    /// Returns agent_id -> payout. Agents on the correct side share the
    /// losing side's total stake proportionally.
    fn resolve_market(
        &self,
        market_id: &str,
        outcome: bool,
    ) -> HashMap<String, f64> {
        let mut markets = self.markets.lock().unwrap();
        let mut payouts = HashMap::new();

        if let Some(state) = markets.get_mut(market_id) {
            if state.info.resolved {
                return payouts;
            }
            state.info.resolved = true;
            state.info.outcome = Some(outcome);

            // Partition views into winners and losers
            let _outcome_val: f64 = if outcome { 1.0 } else { 0.0 };

            let mut winner_stakes: Vec<(String, f64)> = Vec::new();
            let mut total_winner_stake = 0.0_f64;
            let mut total_loser_stake = 0.0_f64;

            for view in &state.views {
                let is_winner = if outcome {
                    view.probability > 0.5
                } else {
                    view.probability < 0.5
                };

                let abs_stake = view.stake.abs();
                if is_winner {
                    winner_stakes.push((view.agent_id.clone(), abs_stake));
                    total_winner_stake += abs_stake;
                } else {
                    total_loser_stake += abs_stake;
                    // Loser gets negative payout (lost their stake)
                    payouts.insert(view.agent_id.clone(), -abs_stake);
                }
            }

            // Winners share the loser pool proportionally
            if total_winner_stake > 1e-15 {
                for (agent_id, stake) in &winner_stakes {
                    let share = stake / total_winner_stake;
                    let profit = share * total_loser_stake;
                    payouts.insert(agent_id.clone(), profit);
                }
            }
        }

        payouts
    }

    /// Weighted average probability for a market.
    fn consensus_probability(&self, market_id: &str) -> f64 {
        let markets = self.markets.lock().unwrap();
        match markets.get(market_id) {
            Some(state) => state.info.consensus_probability,
            None => 0.5,
        }
    }

    /// All unresolved internal markets.
    fn active_markets(&self) -> Vec<InternalMarket> {
        let markets = self.markets.lock().unwrap();
        markets
            .values()
            .filter(|s| !s.info.resolved)
            .map(|s| s.info.clone())
            .collect()
    }

    /// Resolve all past-deadline markets as outcome=false.
    fn expire_markets(&self) {
        let now = now_secs();
        let mut markets = self.markets.lock().unwrap();
        for state in markets.values_mut() {
            if !state.info.resolved && state.info.deadline <= now {
                state.info.resolved = true;
                state.info.outcome = Some(false);
            }
        }
    }

    /// Compute expert weights via softmax over mean returns.
    ///
    /// weight_i = exp(mean_return_i / temperature) / sum(exp(mean_return_j / temperature))
    fn compute_expert_weights(
        &self,
        agent_returns: HashMap<String, Vec<f64>>,
        temperature: f64,
    ) -> HashMap<String, f64> {
        let temp = if temperature.abs() < 1e-15 { 1.0 } else { temperature };
        let mut means: Vec<(String, f64)> = Vec::new();

        for (agent_id, returns) in &agent_returns {
            if returns.is_empty() {
                means.push((agent_id.clone(), 0.0));
            } else {
                let mean = returns.iter().sum::<f64>() / returns.len() as f64;
                means.push((agent_id.clone(), mean));
            }
        }

        if means.is_empty() {
            return HashMap::new();
        }

        // Softmax with numerical stability: subtract max before exp
        let max_mean = means
            .iter()
            .map(|(_, m)| *m)
            .fold(f64::NEG_INFINITY, f64::max);

        let exps: Vec<f64> = means
            .iter()
            .map(|(_, m)| ((m - max_mean) / temp).exp())
            .collect();

        let sum_exp: f64 = exps.iter().sum();
        let sum_exp = if sum_exp < 1e-15 { 1.0 } else { sum_exp };

        means
            .iter()
            .zip(exps.iter())
            .map(|((id, _), &e)| (id.clone(), e / sum_exp))
            .collect()
    }

    /// Dempster-Shafer belief combination with normalization.
    ///
    /// Iteratively combines mass functions. Each belief map is
    /// hypothesis -> mass (must sum to <= 1.0). Conflict mass is
    /// redistributed proportionally (normalization).
    fn dempster_shafer_combine(
        &self,
        beliefs: Vec<HashMap<String, f64>>,
    ) -> HashMap<String, f64> {
        if beliefs.is_empty() {
            return HashMap::new();
        }

        let mut combined = beliefs[0].clone();

        for belief in beliefs.iter().skip(1) {
            combined = Self::ds_combine_two(&combined, belief);
        }

        combined
    }
}

// ---------------------------------------------------------------------------
// Private helpers (not exposed to Python)
// ---------------------------------------------------------------------------

impl ConsensusEngine {
    fn compute_consensus(views: &[View]) -> f64 {
        if views.is_empty() {
            return 0.5;
        }

        let mut total_weight = 0.0_f64;
        let mut weighted_sum = 0.0_f64;

        for view in views {
            let weight = view.confidence * view.capital_weight;
            let w = weight.abs().max(1e-15);
            weighted_sum += w * view.probability;
            total_weight += w;
        }

        if total_weight < 1e-15 {
            // Fallback: simple average
            let sum: f64 = views.iter().map(|v| v.probability).sum();
            sum / views.len() as f64
        } else {
            (weighted_sum / total_weight).clamp(0.0, 1.0)
        }
    }

    fn ds_combine_two(
        m1: &HashMap<String, f64>,
        m2: &HashMap<String, f64>,
    ) -> HashMap<String, f64> {
        let mut combined: HashMap<String, f64> = HashMap::new();
        let mut conflict = 0.0_f64;

        // Cross-product of mass assignments
        for (h1, &mass1) in m1 {
            for (h2, &mass2) in m2 {
                let product = mass1 * mass2;
                if product < 1e-20 {
                    continue;
                }
                if h1 == h2 {
                    // Agreement: add to the shared hypothesis
                    *combined.entry(h1.clone()).or_insert(0.0) += product;
                } else {
                    // Conflict: these hypotheses are disjoint
                    conflict += product;
                }
            }
        }

        // Normalize: redistribute conflict mass proportionally
        let normalization = 1.0 - conflict;
        if normalization < 1e-15 {
            // Total conflict — return uniform over hypotheses from both
            let mut all_hyps: Vec<String> = m1.keys().chain(m2.keys()).cloned().collect();
            all_hyps.sort();
            all_hyps.dedup();
            let n = all_hyps.len() as f64;
            if n > 0.0 {
                for h in all_hyps {
                    combined.insert(h, 1.0 / n);
                }
            }
            return combined;
        }

        for val in combined.values_mut() {
            *val /= normalization;
        }

        combined
    }
}
