//! Pheromone field — stigmergic coordination layer.
//!
//! Markets are annotated with 9-channel pheromone signals that agents deposit,
//! sense, and respond to. Channels evaporate over time, diffuse to neighbors,
//! and track crowding to prevent herding.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;

use super::types::{ChannelConfig, MarketPheromones, PheromoneChannel, CHANNEL_DEFAULTS};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const NUM_CHANNELS: usize = 9;

fn mp_to_dict(mp: &MarketPheromones) -> HashMap<String, f64> {
    let mut m = HashMap::new();
    m.insert("bullish".into(), mp.bullish);
    m.insert("bearish".into(), mp.bearish);
    m.insert("volatility".into(), mp.volatility);
    m.insert("crowding".into(), mp.crowding);
    m.insert("opportunity".into(), mp.opportunity);
    m.insert("toxicity".into(), mp.toxicity);
    m.insert("liquidity".into(), mp.liquidity);
    m.insert("regime_trend".into(), mp.regime_trend);
    m.insert("regime_mr".into(), mp.regime_mr);
    m
}

fn channel_configs() -> Vec<ChannelConfig> {
    CHANNEL_DEFAULTS
        .iter()
        .map(|&(er, dr, sat, dw)| ChannelConfig {
            evaporation_rate: er,
            diffusion_radius: dr,
            saturation: sat,
            deposit_weight: dw,
        })
        .collect()
}

fn channel_idx(ch: PheromoneChannel) -> usize {
    match ch {
        PheromoneChannel::Bullish => 0,
        PheromoneChannel::Bearish => 1,
        PheromoneChannel::Volatility => 2,
        PheromoneChannel::Crowding => 3,
        PheromoneChannel::Opportunity => 4,
        PheromoneChannel::Toxicity => 5,
        PheromoneChannel::Liquidity => 6,
        PheromoneChannel::RegimeTrend => 7,
        PheromoneChannel::RegimeMR => 8,
    }
}

// ---------------------------------------------------------------------------
// PheromoneField
// ---------------------------------------------------------------------------

/// Stigmergic pheromone field over market space.
///
/// Each market carries 9 pheromone channels (bullish, bearish, volatility,
/// crowding, opportunity, toxicity, liquidity, regime_trend, regime_mr).
/// Agents deposit signals scaled by fitness; signals evaporate, diffuse to
/// neighbors, and saturate to prevent runaway accumulation.
#[pyclass]
pub struct PheromoneField {
    field: Mutex<HashMap<String, MarketPheromones>>,
    configs: Vec<ChannelConfig>,
}

#[pymethods]
impl PheromoneField {
    #[new]
    fn new() -> Self {
        Self {
            field: Mutex::new(HashMap::new()),
            configs: channel_configs(),
        }
    }

    /// Deposit pheromone on a market channel, scaled by agent fitness.
    ///
    /// effective = amount * cfg.deposit_weight * (agent_fitness / avg_fitness)
    /// Result is clamped to [0, saturation].
    #[pyo3(signature = (market_id, channel, amount, agent_fitness, avg_fitness = 1.0))]
    fn deposit(
        &self,
        market_id: &str,
        channel: PheromoneChannel,
        amount: f64,
        agent_fitness: f64,
        avg_fitness: f64,
    ) {
        let idx = channel_idx(channel);
        let cfg = &self.configs[idx];
        let avg = if avg_fitness.abs() < 1e-15 { 1.0 } else { avg_fitness };
        let effective = amount * cfg.deposit_weight * (agent_fitness / avg);
        let mut field = self.field.lock().unwrap();
        let mp = field.entry(market_id.to_string()).or_insert_with(MarketPheromones::default);
        let val = mp.get_mut(idx);
        *val = (*val + effective).clamp(0.0, cfg.saturation);
    }

    /// Evaporate all channels: value *= exp(-rate * dt). Snap to 0 if < 1e-10.
    fn evaporate(&self, dt: f64) {
        let mut field = self.field.lock().unwrap();
        for mp in field.values_mut() {
            for i in 0..NUM_CHANNELS {
                let rate = self.configs[i].evaporation_rate;
                let val = mp.get_mut(i);
                *val *= (-rate * dt).exp();
                if *val < 1e-10 {
                    *val = 0.0;
                }
            }
        }
    }

    /// Diffuse pheromone to neighbor markets weighted by relationship strength.
    ///
    /// `neighbors` maps market_id -> Vec<(neighbor_id, weight)>.
    /// For each channel with diffusion_radius > 0, a fraction of the source
    /// value flows to each neighbor proportional to weight.
    fn diffuse(&self, neighbors: HashMap<String, Vec<(String, f64)>>) {
        let mut field = self.field.lock().unwrap();

        // Collect deltas first to avoid aliasing issues.
        let mut deltas: HashMap<String, [f64; NUM_CHANNELS]> = HashMap::new();

        for (market_id, nbrs) in &neighbors {
            if let Some(mp) = field.get(market_id) {
                for i in 0..NUM_CHANNELS {
                    let cfg = &self.configs[i];
                    if cfg.diffusion_radius <= 0 {
                        continue;
                    }
                    let src_val = mp.get_idx(i);
                    if src_val < 1e-15 {
                        continue;
                    }
                    // Diffusion fraction: spread proportional to radius / 10
                    let frac = (cfg.diffusion_radius as f64 * 0.1).min(0.5);
                    let total_w: f64 = nbrs.iter().map(|(_, w)| w.abs()).sum();
                    if total_w < 1e-15 {
                        continue;
                    }
                    let out = src_val * frac;
                    // Subtract from source
                    deltas.entry(market_id.clone()).or_insert([0.0; NUM_CHANNELS])[i] -= out;
                    // Add to neighbors
                    for (nbr_id, w) in nbrs {
                        let share = out * (w.abs() / total_w);
                        deltas.entry(nbr_id.clone()).or_insert([0.0; NUM_CHANNELS])[i] += share;
                    }
                }
            }
        }

        // Apply deltas, clamped to [0, saturation].
        for (market_id, delta) in &deltas {
            let mp = field.entry(market_id.clone()).or_insert_with(MarketPheromones::default);
            for i in 0..NUM_CHANNELS {
                if delta[i].abs() < 1e-15 {
                    continue;
                }
                let val = mp.get_mut(i);
                *val = (*val + delta[i]).clamp(0.0, self.configs[i].saturation);
            }
        }
    }

    /// Update crowding channel based on agent density per market.
    ///
    /// `agent_markets` maps agent_id -> Vec<market_id>.
    /// crowding = (n_agents / max_per_market) * saturation, clamped.
    fn update_crowding(
        &self,
        agent_markets: HashMap<String, Vec<String>>,
        max_per_market: usize,
    ) {
        // Count agents per market.
        let mut counts: HashMap<String, usize> = HashMap::new();
        for markets in agent_markets.values() {
            for m in markets {
                *counts.entry(m.clone()).or_insert(0) += 1;
            }
        }

        let crowding_idx = channel_idx(PheromoneChannel::Crowding);
        let sat = self.configs[crowding_idx].saturation;
        let max = if max_per_market == 0 { 1 } else { max_per_market };

        let mut field = self.field.lock().unwrap();
        // Reset crowding for all existing markets, then set from counts.
        for mp in field.values_mut() {
            *mp.get_mut(crowding_idx) = 0.0;
        }
        for (market_id, count) in &counts {
            let mp = field.entry(market_id.clone()).or_insert_with(MarketPheromones::default);
            let val = (*count as f64 / max as f64) * sat;
            *mp.get_mut(crowding_idx) = val.min(sat);
        }
    }

    /// Sense pheromone readings for a single market. Returns zeros if unknown.
    fn sense(&self, market_id: &str) -> MarketPheromones {
        let field = self.field.lock().unwrap();
        field.get(market_id).cloned().unwrap_or_default()
    }

    /// Single tick: evaporate + diffuse + update_crowding.
    #[pyo3(signature = (dt, neighbors, agent_markets, max_per_market))]
    fn tick(
        &self,
        dt: f64,
        neighbors: HashMap<String, Vec<(String, f64)>>,
        agent_markets: HashMap<String, Vec<String>>,
        max_per_market: usize,
    ) {
        self.evaporate(dt);
        self.diffuse(neighbors);
        self.update_crowding(agent_markets, max_per_market);
    }

    /// Serialize entire field to nested dict: market_id -> channel_name -> value.
    fn snapshot(&self) -> HashMap<String, HashMap<String, f64>> {
        let field = self.field.lock().unwrap();
        field
            .iter()
            .map(|(k, v)| (k.clone(), mp_to_dict(v)))
            .collect()
    }

    /// Reset all pheromone data.
    fn clear(&self) {
        let mut field = self.field.lock().unwrap();
        field.clear();
    }

    /// Mean opportunity pheromone across all markets.
    fn aggregate_opportunity(&self) -> f64 {
        let field = self.field.lock().unwrap();
        if field.is_empty() {
            return 0.0;
        }
        let opp_idx = channel_idx(PheromoneChannel::Opportunity);
        let sum: f64 = field.values().map(|mp| mp.get_idx(opp_idx)).sum();
        sum / field.len() as f64
    }

    /// Mean toxicity pheromone across all markets.
    fn aggregate_toxicity(&self) -> f64 {
        let field = self.field.lock().unwrap();
        if field.is_empty() {
            return 0.0;
        }
        let tox_idx = channel_idx(PheromoneChannel::Toxicity);
        let sum: f64 = field.values().map(|mp| mp.get_idx(tox_idx)).sum();
        sum / field.len() as f64
    }

    /// Markets where crowding exceeds threshold * saturation.
    fn crowded_markets(&self, threshold: f64) -> Vec<String> {
        let field = self.field.lock().unwrap();
        let crowding_idx = channel_idx(PheromoneChannel::Crowding);
        let sat = self.configs[crowding_idx].saturation;
        let cutoff = threshold * sat;
        field
            .iter()
            .filter(|(_, mp)| mp.get_idx(crowding_idx) > cutoff)
            .map(|(k, _)| k.clone())
            .collect()
    }

    /// Markets where opportunity exceeds threshold * saturation.
    fn opportunity_markets(&self, threshold: f64) -> Vec<String> {
        let field = self.field.lock().unwrap();
        let opp_idx = channel_idx(PheromoneChannel::Opportunity);
        let sat = self.configs[opp_idx].saturation;
        let cutoff = threshold * sat;
        field
            .iter()
            .filter(|(_, mp)| mp.get_idx(opp_idx) > cutoff)
            .map(|(k, _)| k.clone())
            .collect()
    }
}
