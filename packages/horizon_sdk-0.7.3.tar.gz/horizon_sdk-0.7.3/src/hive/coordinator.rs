//! SwarmCoordinator — fleet management, selection pressure, capital allocation.
//!
//! Owns the live agent roster, nursery (newly spawned agents waiting for
//! promotion), graveyard (terminated genomes), and capital budgets.
//! The `tick()` method drives the swarm lifecycle: collect metrics, cull
//! underperformers, promote graduates, enforce risk budgets, and rebalance
//! capital via fitness-weighted power allocation.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

use super::types::{
    AgentLifecycle, AutonomyMode, HiveAgent, StrategyGenome, SwarmStatus,
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn now_secs() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}

fn finite_or_zero(v: f64) -> f64 {
    if v.is_finite() { v } else { 0.0 }
}

// ---------------------------------------------------------------------------
// Inner state
// ---------------------------------------------------------------------------

struct Inner {
    agents: HashMap<String, HiveAgent>,
    graveyard: Vec<StrategyGenome>,
    nursery: Vec<String>, // agent_ids in nursery
    tick_count: u64,

    // Config
    max_agents: usize,
    total_capital: f64,
    max_capital_per_agent_pct: f64,
    max_drawdown_pct: f64,
    fitness_gamma: f64,
    age_cull_days: u32,
    min_sharpe_paper: f64,
    min_sharpe_shadow: f64,
    avalanche_reserve_pct: f64,
}

impl Inner {
    /// Allocatable capital after reserves.
    fn allocatable_capital(&self) -> f64 {
        self.total_capital * (1.0 - self.avalanche_reserve_pct)
    }

    /// Reserve capital.
    fn reserve_capital(&self) -> f64 {
        self.total_capital * self.avalanche_reserve_pct
    }

    /// Sum of capital across all agents.
    fn allocated_capital(&self) -> f64 {
        self.agents.values().map(|a| a.capital).sum()
    }

    /// Compute fitness score for an agent.
    fn compute_fitness(agent: &HiveAgent) -> f64 {
        let sharpe = finite_or_zero(agent.sharpe);
        let dd_penalty = if agent.max_drawdown > 0.0 {
            agent.max_drawdown * 2.0
        } else {
            0.0
        };
        let trade_bonus = (agent.num_trades as f64).min(100.0) * 0.001;
        finite_or_zero(sharpe - dd_penalty + trade_bonus)
    }
}

// ---------------------------------------------------------------------------
// SwarmCoordinator
// ---------------------------------------------------------------------------

/// Fleet management: lifecycle promotion, selection pressure, capital allocation.
///
/// The `tick()` method is the main loop driver:
/// 1. Collect metrics (compute fitness for all agents)
/// 2. Selection pressure (cull underperformers)
/// 3. Process nursery (promote agents through Paper -> Shadow -> Live)
/// 4. Enforce risk budget (scale down if over-allocated)
/// 5. Rebalance capital (every 60 ticks, fitness-weighted power allocation)
#[pyclass]
pub struct SwarmCoordinator {
    inner: Mutex<Inner>,
}

#[pymethods]
impl SwarmCoordinator {
    #[new]
    #[pyo3(signature = (
        max_agents = 50,
        total_capital = 100_000.0,
        max_capital_per_agent_pct = 0.15,
        max_drawdown_pct = 0.20,
        fitness_gamma = 1.5,
        age_cull_days = 30,
        min_sharpe_paper = 1.0,
        min_sharpe_shadow = 1.2,
        avalanche_reserve_pct = 0.15,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        max_agents: usize,
        total_capital: f64,
        max_capital_per_agent_pct: f64,
        max_drawdown_pct: f64,
        fitness_gamma: f64,
        age_cull_days: u32,
        min_sharpe_paper: f64,
        min_sharpe_shadow: f64,
        avalanche_reserve_pct: f64,
    ) -> Self {
        Self {
            inner: Mutex::new(Inner {
                agents: HashMap::new(),
                graveyard: Vec::new(),
                nursery: Vec::new(),
                tick_count: 0,
                max_agents,
                total_capital,
                max_capital_per_agent_pct,
                max_drawdown_pct,
                fitness_gamma,
                age_cull_days,
                min_sharpe_paper,
                min_sharpe_shadow,
                avalanche_reserve_pct,
            }),
        }
    }

    /// Add an agent to the swarm.
    fn add_agent(&self, agent: &HiveAgent) {
        let mut inner = self.inner.lock().unwrap();
        let id = agent.agent_id.clone();
        inner.agents.insert(id.clone(), agent.clone());
        if agent.lifecycle == AgentLifecycle::Spawned {
            inner.nursery.push(id);
        }
    }

    /// Remove an agent and archive its genome. Returns the agent if found.
    fn remove_agent(&self, agent_id: &str, _reason: &str) -> Option<HiveAgent> {
        let mut inner = self.inner.lock().unwrap();
        if let Some(mut agent) = inner.agents.remove(agent_id) {
            inner.nursery.retain(|id| id != agent_id);
            agent.lifecycle = AgentLifecycle::Terminated;
            inner.graveyard.push(agent.genome.clone());
            Some(agent)
        } else {
            None
        }
    }

    /// Get a clone of an agent by ID.
    fn get_agent(&self, agent_id: &str) -> Option<HiveAgent> {
        let inner = self.inner.lock().unwrap();
        inner.agents.get(agent_id).cloned()
    }

    /// All agents (active + inactive).
    fn all_agents(&self) -> Vec<HiveAgent> {
        let inner = self.inner.lock().unwrap();
        inner.agents.values().cloned().collect()
    }

    /// Active agents: Paper, Shadow, or Live lifecycle.
    fn active_agents(&self) -> Vec<HiveAgent> {
        let inner = self.inner.lock().unwrap();
        inner
            .agents
            .values()
            .filter(|a| {
                matches!(
                    a.lifecycle,
                    AgentLifecycle::Paper | AgentLifecycle::Shadow | AgentLifecycle::Live
                )
            })
            .cloned()
            .collect()
    }

    /// Main tick loop.
    ///
    /// Returns a status dict with counts of actions taken.
    fn tick(&self) -> HashMap<String, PyObject> {
        let mut inner = self.inner.lock().unwrap();
        inner.tick_count += 1;
        let tick_num = inner.tick_count;

        let mut fitness_updated = 0usize;
        let mut culled = 0usize;
        let mut promoted = 0usize;
        let mut scaled = 0usize;

        // -- Phase 1: Collect metrics (compute fitness for all agents) --
        let agent_ids: Vec<String> = inner.agents.keys().cloned().collect();
        for id in &agent_ids {
            if let Some(agent) = inner.agents.get_mut(id) {
                agent.fitness = Inner::compute_fitness(agent);
                fitness_updated += 1;
            }
        }

        // -- Phase 2: Selection pressure --
        let now = now_secs();
        let max_dd = inner.max_drawdown_pct;
        let age_cull = inner.age_cull_days;
        let min_sharpe_paper = inner.min_sharpe_paper;

        let to_kill: Vec<String> = inner
            .agents
            .iter()
            .filter(|(_, a)| {
                // Kill if drawdown exceeds max.
                if a.max_drawdown > max_dd {
                    return true;
                }
                // Kill if old AND underperforming (only for Paper+).
                let age_days = (now - a.birth_time) / 86400.0;
                if age_days > age_cull as f64
                    && a.sharpe < min_sharpe_paper
                    && matches!(
                        a.lifecycle,
                        AgentLifecycle::Paper | AgentLifecycle::Shadow | AgentLifecycle::Live
                    )
                {
                    return true;
                }
                false
            })
            .map(|(id, _)| id.clone())
            .collect();

        for id in &to_kill {
            if let Some(mut agent) = inner.agents.remove(id) {
                agent.lifecycle = AgentLifecycle::Terminated;
                inner.graveyard.push(agent.genome.clone());
                inner.nursery.retain(|nid| nid != id);
                culled += 1;
            }
        }

        // -- Phase 3: Process nursery (promote through lifecycle stages) --
        let min_paper = inner.min_sharpe_paper;
        let min_shadow = inner.min_sharpe_shadow;

        // Collect nursery IDs and handle them (nursery may contain agents at any early stage).
        // Also process all agents that might be eligible for promotion.
        let all_ids: Vec<String> = inner.agents.keys().cloned().collect();
        for id in &all_ids {
            if let Some(agent) = inner.agents.get_mut(id) {
                let age_days = (now - agent.birth_time) / 86400.0;
                match agent.lifecycle {
                    AgentLifecycle::Spawned => {
                        // SPAWNED -> PAPER immediately.
                        agent.lifecycle = AgentLifecycle::Paper;
                        promoted += 1;
                    }
                    AgentLifecycle::Paper => {
                        // PAPER -> SHADOW: 14 days, >= 50 trades, sharpe >= min_paper.
                        if age_days >= 14.0
                            && agent.num_trades >= 50
                            && agent.sharpe >= min_paper
                        {
                            agent.lifecycle = AgentLifecycle::Shadow;
                            let mut entry = HashMap::new();
                            entry.insert("from".into(), "paper".into());
                            entry.insert("to".into(), "shadow".into());
                            entry.insert("at".into(), format!("{:.0}", now));
                            agent.promotion_history.push(entry);
                            promoted += 1;
                        }
                    }
                    AgentLifecycle::Shadow => {
                        // SHADOW -> LIVE: 21 days total age, sharpe >= min_shadow.
                        if age_days >= 21.0 && agent.sharpe >= min_shadow {
                            agent.lifecycle = AgentLifecycle::Live;
                            let mut entry = HashMap::new();
                            entry.insert("from".into(), "shadow".into());
                            entry.insert("to".into(), "live".into());
                            entry.insert("at".into(), format!("{:.0}", now));
                            agent.promotion_history.push(entry);
                            promoted += 1;
                        }
                    }
                    _ => {}
                }
            }
        }

        // Remove promoted agents from nursery.
        // Collect IDs to keep first to avoid borrow conflict on Inner fields.
        let nursery_keep: Vec<String> = inner
            .nursery
            .iter()
            .filter(|id| {
                inner
                    .agents
                    .get(id.as_str())
                    .map_or(false, |a| a.lifecycle == AgentLifecycle::Spawned)
            })
            .cloned()
            .collect();
        inner.nursery = nursery_keep;

        // -- Phase 4: Enforce risk budget --
        let allocatable = inner.allocatable_capital();
        let total_notional: f64 = inner.agents.values().map(|a| a.capital).sum();
        if total_notional > allocatable && total_notional > 0.0 {
            let scale_factor = allocatable / total_notional;
            for agent in inner.agents.values_mut() {
                agent.capital *= scale_factor;
                scaled += 1;
            }
        }

        // -- Phase 5: Rebalance (every 60 ticks) --
        let rebalanced = if tick_num % 60 == 0 {
            let gamma = inner.fitness_gamma;
            let max_per = inner.max_capital_per_agent_pct;
            let max_cap = allocatable * max_per;

            // Compute fitness^gamma for active agents, using max(fitness, 0.01) to avoid zero.
            let active_ids: Vec<String> = inner
                .agents
                .iter()
                .filter(|(_, a)| {
                    matches!(
                        a.lifecycle,
                        AgentLifecycle::Paper | AgentLifecycle::Shadow | AgentLifecycle::Live
                    )
                })
                .map(|(id, _)| id.clone())
                .collect();

            if !active_ids.is_empty() {
                let weights: Vec<(String, f64)> = active_ids
                    .iter()
                    .map(|id| {
                        let f = inner.agents[id].fitness.max(0.01);
                        (id.clone(), f.powf(gamma))
                    })
                    .collect();
                let total_weight: f64 = weights.iter().map(|(_, w)| w).sum();

                if total_weight > 0.0 {
                    for (id, w) in &weights {
                        let share = allocatable * (w / total_weight);
                        let capped = share.min(max_cap);
                        if let Some(agent) = inner.agents.get_mut(id) {
                            agent.capital = finite_or_zero(capped);
                        }
                    }
                }
            }
            true
        } else {
            false
        };

        // Build return dict.
        Python::with_gil(|py| {
            let mut m = HashMap::new();
            m.insert(
                "tick".into(),
                tick_num.to_object(py),
            );
            m.insert(
                "fitness_updated".into(),
                fitness_updated.to_object(py),
            );
            m.insert(
                "culled".into(),
                culled.to_object(py),
            );
            m.insert(
                "promoted".into(),
                promoted.to_object(py),
            );
            m.insert(
                "scaled".into(),
                scaled.to_object(py),
            );
            m.insert(
                "rebalanced".into(),
                rebalanced.to_object(py),
            );
            m.insert(
                "total_agents".into(),
                inner.agents.len().to_object(py),
            );
            m
        })
    }

    /// Kill an agent by ID with a reason. Returns true if found.
    fn kill_agent(&self, agent_id: &str, _reason: &str) -> bool {
        let mut inner = self.inner.lock().unwrap();
        if let Some(mut agent) = inner.agents.remove(agent_id) {
            agent.lifecycle = AgentLifecycle::Terminated;
            inner.graveyard.push(agent.genome.clone());
            inner.nursery.retain(|id| id != agent_id);
            true
        } else {
            false
        }
    }

    /// Pause an agent. Returns true if found and successfully paused.
    fn pause_agent(&self, agent_id: &str, _reason: &str) -> bool {
        let mut inner = self.inner.lock().unwrap();
        if let Some(agent) = inner.agents.get_mut(agent_id) {
            if !matches!(agent.lifecycle, AgentLifecycle::Terminated | AgentLifecycle::Paused) {
                agent.lifecycle = AgentLifecycle::Paused;
                return true;
            }
        }
        false
    }

    /// Resume a paused agent back to Paper. Returns true if found and resumed.
    fn resume_agent(&self, agent_id: &str) -> bool {
        let mut inner = self.inner.lock().unwrap();
        if let Some(agent) = inner.agents.get_mut(agent_id) {
            if agent.lifecycle == AgentLifecycle::Paused {
                agent.lifecycle = AgentLifecycle::Paper;
                return true;
            }
        }
        false
    }

    /// Scale an agent's capital. Returns true if found.
    fn scale_agent(&self, agent_id: &str, new_capital: f64) -> bool {
        let mut inner = self.inner.lock().unwrap();
        if let Some(agent) = inner.agents.get_mut(agent_id) {
            agent.capital = new_capital.max(0.0);
            true
        } else {
            false
        }
    }

    /// Deploy capital from reserves. Returns the amount actually deployed
    /// (capped to available reserves).
    fn deploy_reserves(&self, amount: f64) -> f64 {
        let inner = self.inner.lock().unwrap();
        let reserve = inner.reserve_capital();
        let allocated = inner.allocated_capital();
        let available = (inner.total_capital - allocated).min(reserve);
        let deploy = amount.min(available).max(0.0);
        // The deployed amount will be allocated by subsequent rebalance or
        // manual scale_agent calls; we increase total_capital conceptually.
        // In practice this is a no-op on total_capital; we just return how
        // much headroom exists.
        drop(inner); // explicitly release lock before returning
        deploy
    }

    /// Build a SwarmStatus snapshot.
    fn swarm_status(&self) -> SwarmStatus {
        let inner = self.inner.lock().unwrap();

        let mut paper = 0usize;
        let mut shadow = 0usize;
        let mut live = 0usize;
        let mut total_pnl = 0.0f64;
        let mut sharpe_sum = 0.0f64;
        let mut max_dd = 0.0f64;
        let mut active = 0usize;

        for agent in inner.agents.values() {
            match agent.lifecycle {
                AgentLifecycle::Paper => {
                    paper += 1;
                    active += 1;
                }
                AgentLifecycle::Shadow => {
                    shadow += 1;
                    active += 1;
                }
                AgentLifecycle::Live => {
                    live += 1;
                    active += 1;
                }
                _ => {}
            }
            total_pnl += agent.pnl;
            sharpe_sum += agent.sharpe;
            if agent.max_drawdown > max_dd {
                max_dd = agent.max_drawdown;
            }
        }

        let n = inner.agents.len();
        let agg_sharpe = if n > 0 {
            finite_or_zero(sharpe_sum / n as f64)
        } else {
            0.0
        };

        SwarmStatus {
            total_agents: n,
            active_agents: active,
            paper_agents: paper,
            shadow_agents: shadow,
            live_agents: live,
            total_capital: inner.total_capital,
            allocated_capital: inner.allocated_capital(),
            reserve_capital: inner.reserve_capital(),
            total_pnl: finite_or_zero(total_pnl),
            aggregate_sharpe: agg_sharpe,
            aggregate_drawdown: max_dd,
            autonomy_mode: AutonomyMode::Observe, // set by orchestrator
        }
    }

    /// Agents sorted by fitness descending, each as a dict.
    fn agent_ranking(&self) -> Vec<HashMap<String, PyObject>> {
        let inner = self.inner.lock().unwrap();
        let mut agents: Vec<&HiveAgent> = inner.agents.values().collect();
        agents.sort_by(|a, b| {
            b.fitness
                .partial_cmp(&a.fitness)
                .unwrap_or(std::cmp::Ordering::Equal)
        });

        agents.iter().map(|a| a.to_dict_py()).collect()
    }

    /// Whether new agents can be spawned (under max_agents limit).
    #[getter]
    fn can_spawn(&self) -> bool {
        let inner = self.inner.lock().unwrap();
        inner.agents.len() < inner.max_agents
    }

    /// Current number of agents.
    #[getter]
    fn agent_count(&self) -> usize {
        let inner = self.inner.lock().unwrap();
        inner.agents.len()
    }
}
