//! AutonomyController — 5-mode progressive autonomy state machine.
//!
//! Modes: Observe -> Suggest -> Supervised -> Autonomous -> Skynet.
//! Each mode unlocks more decision-making authority.  Graduation between
//! modes is earned by demonstrating consistent, profitable behaviour.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::collections::HashSet;
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

use super::types::{AutonomyMode, DecisionType, HiveDecision};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn now_secs() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}

// ---------------------------------------------------------------------------
// Internal records
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct SuggestionRecord {
    id: String,
    accepted: Option<bool>,
    timestamp: f64,
}

#[derive(Debug, Clone)]
#[allow(dead_code)]
struct ApprovalRecord {
    id: String,
    approved: bool,
    timestamp: f64,
}

#[derive(Debug)]
struct Inner {
    mode: AutonomyMode,
    mode_entered_at: f64,
    suggestions: Vec<SuggestionRecord>,
    approvals: Vec<ApprovalRecord>,
    pending: HashMap<String, HiveDecision>,
    auto_approve: HashSet<DecisionType>,
    require_approval: HashSet<DecisionType>,
}

impl Inner {
    fn new(initial_mode: AutonomyMode) -> Self {
        // Routine types that Supervised mode can auto-approve.
        let auto_approve: HashSet<DecisionType> = [
            DecisionType::PauseAgent,
            DecisionType::ResumeAgent,
            DecisionType::ScaleAgent,
        ]
        .iter()
        .copied()
        .collect();

        // Major types that always require approval in Supervised mode.
        let require_approval: HashSet<DecisionType> = [
            DecisionType::SpawnAgent,
            DecisionType::KillAgent,
            DecisionType::PromoteAgent,
            DecisionType::MutateAgent,
            DecisionType::AllocateCapital,
            DecisionType::RegimePosture,
            DecisionType::EvolveGeneration,
            DecisionType::DreamCycle,
            DecisionType::RiskOff,
            DecisionType::RiskOn,
            DecisionType::Graduation,
            DecisionType::InternalCross,
        ]
        .iter()
        .copied()
        .collect();

        Self {
            mode: initial_mode,
            mode_entered_at: now_secs(),
            suggestions: Vec::new(),
            approvals: Vec::new(),
            pending: HashMap::new(),
            auto_approve,
            require_approval,
        }
    }

    /// Acceptance rate over the last `window` seconds for resolved suggestions.
    fn acceptance_rate(&self, window: f64) -> (f64, usize) {
        let cutoff = now_secs() - window;
        let resolved: Vec<&SuggestionRecord> = self
            .suggestions
            .iter()
            .filter(|s| s.timestamp >= cutoff && s.accepted.is_some())
            .collect();
        let total = resolved.len();
        if total == 0 {
            return (0.0, 0);
        }
        let accepted = resolved.iter().filter(|s| s.accepted == Some(true)).count();
        (accepted as f64 / total as f64, total)
    }

    /// Approval rate over the last `window` seconds for recorded approvals.
    fn approval_rate(&self, window: f64) -> (f64, usize) {
        let cutoff = now_secs() - window;
        let relevant: Vec<&ApprovalRecord> = self
            .approvals
            .iter()
            .filter(|a| a.timestamp >= cutoff)
            .collect();
        let total = relevant.len();
        if total == 0 {
            return (0.0, 0);
        }
        let approved = relevant.iter().filter(|a| a.approved).count();
        (approved as f64 / total as f64, total)
    }
}

// ---------------------------------------------------------------------------
// AutonomyController
// ---------------------------------------------------------------------------

/// Five-mode progressive autonomy state machine.
///
/// Observe -> Suggest -> Supervised -> Autonomous -> Skynet.
/// Each transition is earned by meeting objective graduation criteria
/// (acceptance rate, Sharpe ratio, profitable months, etc.).
#[pyclass]
pub struct AutonomyController {
    inner: Mutex<Inner>,
}

#[pymethods]
impl AutonomyController {
    #[new]
    fn new(initial_mode: AutonomyMode) -> Self {
        Self {
            inner: Mutex::new(Inner::new(initial_mode)),
        }
    }

    /// Check whether the current mode allows a decision of the given type
    /// that may affect `capital_pct` of total capital.
    ///
    /// Returns `(allowed, reason)`.
    fn check_permission(&self, decision_type: DecisionType, capital_pct: f64) -> (bool, String) {
        let inner = self.inner.lock().unwrap();
        match inner.mode {
            AutonomyMode::Observe => {
                (false, "Observe mode: all actions denied".into())
            }
            AutonomyMode::Suggest => {
                (false, "Suggest mode: suggestions only, no execution".into())
            }
            AutonomyMode::Supervised => {
                // Block large allocations.
                if capital_pct > 0.10 {
                    return (
                        false,
                        format!(
                            "Supervised mode: capital_pct {:.1}% exceeds 10% limit",
                            capital_pct * 100.0
                        ),
                    );
                }
                // Auto-approve routine types.
                if inner.auto_approve.contains(&decision_type) {
                    return (true, "Supervised mode: routine type auto-approved".into());
                }
                // Require approval for major types.
                if inner.require_approval.contains(&decision_type) {
                    return (
                        false,
                        format!(
                            "Supervised mode: {:?} requires human approval",
                            decision_type
                        ),
                    );
                }
                // Default: require approval for unknown types.
                (false, "Supervised mode: unknown type requires approval".into())
            }
            AutonomyMode::Autonomous => {
                (true, "Autonomous mode: allowed".into())
            }
            AutonomyMode::Skynet => {
                (true, "Skynet mode: full autonomy".into())
            }
        }
    }

    /// Store a decision in the pending queue for human review.
    /// Returns the decision_id.
    fn request_approval(&self, decision: HiveDecision) -> String {
        let mut inner = self.inner.lock().unwrap();
        let id = decision.decision_id.clone();
        inner.pending.insert(id.clone(), decision);
        id
    }

    /// Approve a pending decision, returning it if found.
    fn approve(&self, decision_id: &str) -> Option<HiveDecision> {
        let mut inner = self.inner.lock().unwrap();
        if let Some(mut decision) = inner.pending.remove(decision_id) {
            decision.user_approved = Some(true);
            inner.approvals.push(ApprovalRecord {
                id: decision_id.to_string(),
                approved: true,
                timestamp: now_secs(),
            });
            Some(decision)
        } else {
            None
        }
    }

    /// Reject a pending decision, returning it if found.
    fn reject(&self, decision_id: &str, reason: &str) -> Option<HiveDecision> {
        let mut inner = self.inner.lock().unwrap();
        if let Some(mut decision) = inner.pending.remove(decision_id) {
            decision.user_approved = Some(false);
            decision.outcome = Some(format!("rejected: {}", reason));
            inner.approvals.push(ApprovalRecord {
                id: decision_id.to_string(),
                approved: false,
                timestamp: now_secs(),
            });
            Some(decision)
        } else {
            None
        }
    }

    /// All currently pending decisions.
    fn pending(&self) -> Vec<HiveDecision> {
        let inner = self.inner.lock().unwrap();
        inner.pending.values().cloned().collect()
    }

    /// Remove pending decisions older than `max_age_seconds`.
    /// Returns the number removed.
    fn expire_stale(&self, max_age_seconds: f64) -> usize {
        let mut inner = self.inner.lock().unwrap();
        let cutoff = now_secs() - max_age_seconds;
        let stale: Vec<String> = inner
            .pending
            .iter()
            .filter(|(_, d)| d.timestamp < cutoff)
            .map(|(id, _)| id.clone())
            .collect();
        let count = stale.len();
        for id in stale {
            inner.pending.remove(&id);
        }
        count
    }

    /// Evaluate whether graduation to the next autonomy mode is warranted.
    ///
    /// Returns `Some(next_mode)` if criteria are met, `None` otherwise.
    #[pyo3(signature = (imprint_actions, hive_sharpe, user_sharpe, critical_count_90d, months_profitable))]
    fn evaluate_graduation(
        &self,
        imprint_actions: usize,
        hive_sharpe: f64,
        user_sharpe: f64,
        critical_count_90d: usize,
        months_profitable: usize,
    ) -> Option<AutonomyMode> {
        let inner = self.inner.lock().unwrap();
        match inner.mode {
            AutonomyMode::Observe => {
                // Observe -> Suggest: enough imprint data collected.
                let min_actions = 100;
                if imprint_actions >= min_actions {
                    Some(AutonomyMode::Suggest)
                } else {
                    None
                }
            }
            AutonomyMode::Suggest => {
                // Suggest -> Supervised: high acceptance rate over 14 days.
                let (rate, resolved) = inner.acceptance_rate(14.0 * 86400.0);
                if resolved >= 10 && rate >= 0.8 {
                    Some(AutonomyMode::Supervised)
                } else {
                    None
                }
            }
            AutonomyMode::Supervised => {
                // Supervised -> Autonomous: high approval rate over 28 days, positive Sharpe.
                let (rate, total) = inner.approval_rate(28.0 * 86400.0);
                if total >= 10 && rate >= 0.95 && hive_sharpe > 0.0 {
                    Some(AutonomyMode::Autonomous)
                } else {
                    None
                }
            }
            AutonomyMode::Autonomous => {
                // Autonomous -> Skynet: sustained profitability, no critical incidents,
                // hive outperforms user.
                if months_profitable >= 6
                    && critical_count_90d == 0
                    && hive_sharpe > user_sharpe
                {
                    Some(AutonomyMode::Skynet)
                } else {
                    None
                }
            }
            AutonomyMode::Skynet => {
                // Terminal mode — no further graduation.
                None
            }
        }
    }

    /// Set the autonomy mode (with timestamp update).
    fn set_mode(&self, mode: AutonomyMode) {
        let mut inner = self.inner.lock().unwrap();
        inner.mode = mode;
        inner.mode_entered_at = now_secs();
    }

    /// Record that a suggestion was generated.
    fn record_suggestion(&self, suggestion_id: &str) {
        let mut inner = self.inner.lock().unwrap();
        inner.suggestions.push(SuggestionRecord {
            id: suggestion_id.to_string(),
            accepted: None,
            timestamp: now_secs(),
        });
    }

    /// Record that a suggestion was accepted by the user.
    fn record_suggestion_accepted(&self, suggestion_id: &str) {
        let mut inner = self.inner.lock().unwrap();
        if let Some(rec) = inner
            .suggestions
            .iter_mut()
            .rev()
            .find(|s| s.id == suggestion_id)
        {
            rec.accepted = Some(true);
        }
    }

    /// Record that a suggestion was rejected by the user.
    fn record_suggestion_rejected(&self, suggestion_id: &str) {
        let mut inner = self.inner.lock().unwrap();
        if let Some(rec) = inner
            .suggestions
            .iter_mut()
            .rev()
            .find(|s| s.id == suggestion_id)
        {
            rec.accepted = Some(false);
        }
    }

    /// Status snapshot.
    fn status(&self) -> HashMap<String, PyObject> {
        let inner = self.inner.lock().unwrap();
        let now = now_secs();
        let time_in_mode = now - inner.mode_entered_at;
        let (accept_rate_14d, resolved_14d) = inner.acceptance_rate(14.0 * 86400.0);
        let (approval_rate_28d, decisions_28d) = inner.approval_rate(28.0 * 86400.0);

        Python::with_gil(|py| {
            let mut m = HashMap::new();
            m.insert(
                "mode".into(),
                inner.mode.as_str().to_object(py),
            );
            m.insert(
                "time_in_mode".into(),
                time_in_mode.to_object(py),
            );
            m.insert(
                "pending_count".into(),
                inner.pending.len().to_object(py),
            );
            m.insert(
                "total_suggestions".into(),
                inner.suggestions.len().to_object(py),
            );
            m.insert(
                "total_approvals".into(),
                inner.approvals.len().to_object(py),
            );
            m.insert(
                "acceptance_rate_14d".into(),
                accept_rate_14d.to_object(py),
            );
            m.insert(
                "resolved_14d".into(),
                resolved_14d.to_object(py),
            );
            m.insert(
                "approval_rate_28d".into(),
                approval_rate_28d.to_object(py),
            );
            m.insert(
                "decisions_28d".into(),
                decisions_28d.to_object(py),
            );
            m
        })
    }
}
