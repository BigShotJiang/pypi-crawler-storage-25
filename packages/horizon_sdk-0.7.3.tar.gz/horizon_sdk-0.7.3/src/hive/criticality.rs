//! CriticalityMonitor — 15-indicator systemic risk monitoring.
//!
//! Computes correlation convergence, contagion score, regime shifts,
//! Hurst exponent, microstructure noise, entropy, transfer entropy,
//! VPIN, liquidity, Amihud, BOCPD, CUSUM, and vine copula tail risk.
//! Also manages an avalanche reserve for crash-responsive capital deployment.

use pyo3::prelude::*;
use std::collections::{HashMap, VecDeque};
use std::sync::Mutex;

use super::types::CriticalityReport;

// ---------------------------------------------------------------------------
// Internal state
// ---------------------------------------------------------------------------

struct Inner {
    prev_report: Option<CriticalityReport>,
    prev_avg_corr: f64,
    spread_history: VecDeque<f64>, // capped at 120
    reserve_capital: f64,
    avalanche_reserve_pct: f64,
    avalanche_deploy_threshold: f64,
    total_capital: f64,
}

// ---------------------------------------------------------------------------
// CriticalityMonitor
// ---------------------------------------------------------------------------

#[pyclass]
pub struct CriticalityMonitor {
    inner: Mutex<Inner>,
}

// ---------------------------------------------------------------------------
// Helper maths (pure Rust, no external crates)
// ---------------------------------------------------------------------------

/// Log-returns from a price series.
fn log_returns(prices: &[f64]) -> Vec<f64> {
    if prices.len() < 2 {
        return vec![];
    }
    prices.windows(2)
        .map(|w| {
            let r = (w[1] / w[0]).ln();
            if r.is_finite() { r } else { 0.0 }
        })
        .collect()
}

/// Mean of a slice.
fn mean(v: &[f64]) -> f64 {
    if v.is_empty() { return 0.0; }
    v.iter().sum::<f64>() / v.len() as f64
}

/// Standard deviation (population).
fn std_dev(v: &[f64]) -> f64 {
    if v.len() < 2 { return 0.0; }
    let m = mean(v);
    let var = v.iter().map(|x| (x - m).powi(2)).sum::<f64>() / v.len() as f64;
    var.sqrt()
}

/// Pearson correlation between two equal-length slices.
fn pearson_corr(a: &[f64], b: &[f64]) -> f64 {
    let n = a.len().min(b.len());
    if n < 2 { return 0.0; }
    let ma = mean(&a[..n]);
    let mb = mean(&b[..n]);
    let mut cov = 0.0;
    let mut va = 0.0;
    let mut vb = 0.0;
    for i in 0..n {
        let da = a[i] - ma;
        let db = b[i] - mb;
        cov += da * db;
        va += da * da;
        vb += db * db;
    }
    let denom = (va * vb).sqrt();
    if denom < 1e-15 { 0.0 } else { (cov / denom).clamp(-1.0, 1.0) }
}

/// Average pairwise correlation across a collection of return series.
fn avg_pairwise_correlation(return_series: &[Vec<f64>]) -> f64 {
    let n = return_series.len();
    if n < 2 { return 0.0; }
    let mut total = 0.0;
    let mut count = 0usize;
    for i in 0..n {
        for j in (i + 1)..n {
            total += pearson_corr(&return_series[i], &return_series[j]).abs();
            count += 1;
        }
    }
    if count == 0 { 0.0 } else { total / count as f64 }
}

/// Contagion score: max eigenvalue ratio via power iteration on the
/// correlation matrix.
fn contagion_score(return_series: &[Vec<f64>]) -> f64 {
    let n = return_series.len();
    if n < 2 { return 0.0; }

    // Build correlation matrix
    let mut corr = vec![vec![0.0f64; n]; n];
    for i in 0..n {
        corr[i][i] = 1.0;
        for j in (i + 1)..n {
            let c = pearson_corr(&return_series[i], &return_series[j]);
            corr[i][j] = c;
            corr[j][i] = c;
        }
    }

    // Power iteration for largest eigenvalue
    let mut v = vec![1.0 / (n as f64).sqrt(); n];
    for _ in 0..100 {
        let mut w = vec![0.0; n];
        for i in 0..n {
            for j in 0..n {
                w[i] += corr[i][j] * v[j];
            }
        }
        let norm = w.iter().map(|x| x * x).sum::<f64>().sqrt();
        if norm < 1e-15 { break; }
        for x in &mut w { *x /= norm; }
        v = w;
    }

    // Rayleigh quotient -> eigenvalue
    let mut num = 0.0;
    for i in 0..n {
        let mut row_sum = 0.0;
        for j in 0..n {
            row_sum += corr[i][j] * v[j];
        }
        num += v[i] * row_sum;
    }
    let denom = v.iter().map(|x| x * x).sum::<f64>();
    let lambda_max = if denom > 1e-15 { num / denom } else { 1.0 };

    // Marchenko-Pastur upper bound for null: (1 + 1/sqrt(T/N))^2 ~ n for equal length
    // Simple ratio: lambda_max / n — ranges 1/n to 1, normalize
    let ratio = lambda_max / n as f64;
    ratio.clamp(0.0, 1.0)
}

/// Hurst exponent via rescaled range (R/S) method.
fn hurst_exponent(returns: &[f64]) -> f64 {
    let n = returns.len();
    if n < 20 { return 0.5; }

    let mut log_ns = Vec::new();
    let mut log_rs = Vec::new();

    // Sub-series sizes
    let sizes: Vec<usize> = vec![10, 20, 40, 80, 160, 320]
        .into_iter()
        .filter(|&s| s <= n)
        .collect();

    if sizes.len() < 2 { return 0.5; }

    for &sz in &sizes {
        let num_chunks = n / sz;
        if num_chunks == 0 { continue; }
        let mut rs_vals = Vec::new();
        for c in 0..num_chunks {
            let chunk = &returns[c * sz..(c + 1) * sz];
            let m = mean(chunk);
            let s = std_dev(chunk);
            if s < 1e-15 { continue; }
            // Cumulative deviations
            let mut cum = 0.0;
            let mut max_cum = f64::NEG_INFINITY;
            let mut min_cum = f64::INFINITY;
            for &x in chunk {
                cum += x - m;
                if cum > max_cum { max_cum = cum; }
                if cum < min_cum { min_cum = cum; }
            }
            let r = max_cum - min_cum;
            rs_vals.push(r / s);
        }
        if rs_vals.is_empty() { continue; }
        let avg_rs = mean(&rs_vals);
        if avg_rs > 0.0 {
            log_ns.push((sz as f64).ln());
            log_rs.push(avg_rs.ln());
        }
    }

    if log_ns.len() < 2 { return 0.5; }

    // OLS slope in log-log space
    let mx = mean(&log_ns);
    let my = mean(&log_rs);
    let mut num = 0.0;
    let mut den = 0.0;
    for i in 0..log_ns.len() {
        let dx = log_ns[i] - mx;
        num += dx * (log_rs[i] - my);
        den += dx * dx;
    }
    if den.abs() < 1e-15 { return 0.5; }
    let h = num / den;
    h.clamp(0.0, 1.0)
}

/// Realized volatility at a given sub-sampling frequency.
fn realized_vol_at_freq(returns: &[f64], freq: usize) -> f64 {
    if returns.len() < freq || freq == 0 { return 0.0; }
    let sub: Vec<f64> = returns.iter().step_by(freq).copied().collect();
    let v = sub.iter().map(|r| r * r).sum::<f64>() / sub.len() as f64;
    v.sqrt()
}

/// Vol signature noise: std of realized vol at 5 frequencies.
fn vol_signature_noise(returns: &[f64]) -> f64 {
    let freqs = [1, 2, 5, 10, 20];
    let vols: Vec<f64> = freqs.iter()
        .map(|&f| realized_vol_at_freq(returns, f))
        .collect();
    std_dev(&vols)
}

/// Two-scale vol ratio: 1-tick vs 20-tick.
fn two_scale_vol_ratio(returns: &[f64]) -> f64 {
    let v1 = realized_vol_at_freq(returns, 1);
    let v20 = realized_vol_at_freq(returns, 20);
    if v20 < 1e-15 { return 1.0; }
    v1 / v20
}

/// Shannon entropy of binned returns.
fn market_entropy(returns: &[f64]) -> f64 {
    if returns.is_empty() { return 1.0; }
    let n_bins = 20usize;
    let min_r = returns.iter().copied().fold(f64::INFINITY, f64::min);
    let max_r = returns.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let range = max_r - min_r;
    if range < 1e-15 { return 0.0; }
    let mut bins = vec![0usize; n_bins];
    for &r in returns {
        let idx = ((r - min_r) / range * (n_bins as f64 - 1.0)).round() as usize;
        bins[idx.min(n_bins - 1)] += 1;
    }
    let total = returns.len() as f64;
    let max_entropy = (n_bins as f64).ln();
    if max_entropy < 1e-15 { return 1.0; }
    let mut entropy = 0.0;
    for &count in &bins {
        if count > 0 {
            let p = count as f64 / total;
            entropy -= p * p.ln();
        }
    }
    // Normalize to [0, 1]
    (entropy / max_entropy).clamp(0.0, 1.0)
}

/// Transfer entropy from series a to series b (lag 1, simple binning).
fn transfer_entropy(a: &[f64], b: &[f64]) -> f64 {
    let n = a.len().min(b.len());
    if n < 10 { return 0.0; }

    // Discretize into 3 bins each: down, flat, up
    let discretize = |v: &[f64]| -> Vec<u8> {
        let s = std_dev(v);
        let threshold = s * 0.5;
        v.iter().map(|&x| {
            if x < -threshold { 0 }
            else if x > threshold { 2 }
            else { 1 }
        }).collect()
    };

    let da = discretize(&a[..n]);
    let db = discretize(&b[..n]);

    // Count joint and marginal frequencies
    // P(b_t | b_{t-1}, a_{t-1}) vs P(b_t | b_{t-1})
    // Using 3x3x3 and 3x3 counting
    let mut joint = [[[0u32; 3]; 3]; 3]; // [b_{t-1}][a_{t-1}][b_t]
    let mut marg = [[0u32; 3]; 3];       // [b_{t-1}][b_t]

    for t in 1..n {
        let bt = db[t] as usize;
        let bt1 = db[t - 1] as usize;
        let at1 = da[t - 1] as usize;
        joint[bt1][at1][bt] += 1;
        marg[bt1][bt] += 1;
    }

    let total = (n - 1) as f64;
    let mut te = 0.0;
    for bt1 in 0..3 {
        let marg_bt1: u32 = marg[bt1].iter().sum();
        if marg_bt1 == 0 { continue; }
        for at1 in 0..3 {
            let joint_bt1_at1: u32 = joint[bt1][at1].iter().sum();
            if joint_bt1_at1 == 0 { continue; }
            for bt in 0..3 {
                let j = joint[bt1][at1][bt] as f64;
                if j < 1.0 { continue; }
                let p_bt_given_bt1_at1 = j / joint_bt1_at1 as f64;
                let p_bt_given_bt1 = marg[bt1][bt] as f64 / marg_bt1 as f64;
                if p_bt_given_bt1 < 1e-15 { continue; }
                let weight = j / total;
                te += weight * (p_bt_given_bt1_at1 / p_bt_given_bt1).ln();
            }
        }
    }
    te.max(0.0)
}

/// Max cross-transfer-entropy across all pairs.
fn max_transfer_entropy(return_series: &[Vec<f64>]) -> f64 {
    let n = return_series.len();
    if n < 2 { return 0.0; }
    let mut max_te = 0.0;
    for i in 0..n {
        for j in 0..n {
            if i == j { continue; }
            let te = transfer_entropy(&return_series[i], &return_series[j]);
            if te > max_te { max_te = te; }
        }
    }
    max_te
}

/// Liquidity score: 1 - avg(spread / mid).
fn liquidity_score(feed_spreads: &HashMap<String, f64>) -> f64 {
    if feed_spreads.is_empty() { return 1.0; }
    let avg_spread: f64 = feed_spreads.values().sum::<f64>() / feed_spreads.len() as f64;
    (1.0 - avg_spread).clamp(0.0, 1.0)
}

/// Amihud illiquidity ratio: avg(|return| / volume).
fn amihud_ratio(return_series: &[Vec<f64>], volume_series: &[Vec<f64>]) -> f64 {
    let n = return_series.len().min(volume_series.len());
    if n == 0 { return 0.0; }
    let mut total = 0.0;
    let mut count = 0usize;
    for i in 0..n {
        let rets = &return_series[i];
        let vols = &volume_series[i];
        let m = rets.len().min(vols.len());
        for j in 0..m {
            if vols[j] > 1e-15 {
                total += rets[j].abs() / vols[j];
                count += 1;
            }
        }
    }
    if count == 0 { 0.0 } else { total / count as f64 }
}

/// CUSUM trigger count: how many returns exceed 2 * std.
fn cusum_trigger_count(returns: &[f64]) -> u32 {
    if returns.len() < 2 { return 0; }
    let s = std_dev(returns);
    let threshold = 2.0 * s;
    returns.iter().filter(|&&r| r.abs() > threshold).count() as u32
}

/// Spread-widening rate of change from history.
fn spread_widening(spread_history: &VecDeque<f64>) -> f64 {
    if spread_history.len() < 2 { return 0.0; }
    let n = spread_history.len();
    // Simple linear regression slope
    let mut sum_x = 0.0;
    let mut sum_y = 0.0;
    let mut sum_xy = 0.0;
    let mut sum_xx = 0.0;
    for (i, &s) in spread_history.iter().enumerate() {
        let x = i as f64;
        sum_x += x;
        sum_y += s;
        sum_xy += x * s;
        sum_xx += x * x;
    }
    let nf = n as f64;
    let denom = nf * sum_xx - sum_x * sum_x;
    if denom.abs() < 1e-15 { return 0.0; }
    let slope = (nf * sum_xy - sum_x * sum_y) / denom;
    slope.max(0.0) // only positive widening matters
}

// ---------------------------------------------------------------------------
// PyO3 implementation
// ---------------------------------------------------------------------------

#[pymethods]
impl CriticalityMonitor {
    #[new]
    #[pyo3(signature = (avalanche_reserve_pct=0.15, avalanche_deploy_threshold=0.30, total_capital=100_000.0))]
    fn new(avalanche_reserve_pct: f64, avalanche_deploy_threshold: f64, total_capital: f64) -> Self {
        let reserve = total_capital * avalanche_reserve_pct;
        Self {
            inner: Mutex::new(Inner {
                prev_report: None,
                prev_avg_corr: 0.0,
                spread_history: VecDeque::with_capacity(120),
                reserve_capital: reserve,
                avalanche_reserve_pct,
                avalanche_deploy_threshold,
                total_capital,
            }),
        }
    }

    /// Compute a full 15-indicator criticality report.
    #[pyo3(signature = (price_series, volume_series, feed_spreads, vpin_aggregate=0.0,
                        bocpd_probability=0.0, vine_tail_risk=0.0))]
    #[allow(clippy::too_many_arguments)]
    fn compute_report(
        &self,
        price_series: HashMap<String, Vec<f64>>,
        volume_series: HashMap<String, Vec<f64>>,
        feed_spreads: HashMap<String, f64>,
        vpin_aggregate: f64,
        bocpd_probability: f64,
        vine_tail_risk: f64,
    ) -> CriticalityReport {
        let mut state = self.inner.lock().unwrap();

        // Build return series from price series
        let mut all_returns: Vec<Vec<f64>> = Vec::new();
        let mut price_keys: Vec<String> = price_series.keys().cloned().collect();
        price_keys.sort(); // deterministic order
        for key in &price_keys {
            let rets = log_returns(&price_series[key]);
            if !rets.is_empty() {
                all_returns.push(rets);
            }
        }

        // Build volume return series (aligned with return series)
        let mut vol_series_aligned: Vec<Vec<f64>> = Vec::new();
        for key in &price_keys {
            if let Some(vols) = volume_series.get(key) {
                // Volume series should be same length as prices; we take as-is for Amihud
                vol_series_aligned.push(vols.clone());
            }
        }

        // Flatten all returns for single-series indicators
        let flat_returns: Vec<f64> = all_returns.iter().flat_map(|r| r.iter().copied()).collect();

        // 1. Correlation convergence
        let corr_conv = avg_pairwise_correlation(&all_returns);

        // 2. Contagion score
        let contagion = contagion_score(&all_returns);

        // 3. Regime shift detected
        let regime_shift = (corr_conv - state.prev_avg_corr).abs() > 0.3;
        state.prev_avg_corr = corr_conv;

        // 4. Hurst exponent
        let hurst = hurst_exponent(&flat_returns);

        // 5. Vol signature noise
        let vol_noise = vol_signature_noise(&flat_returns);

        // 6. Two-scale vol ratio
        let ts_ratio = two_scale_vol_ratio(&flat_returns);

        // 7. Market entropy
        let entropy = market_entropy(&flat_returns);

        // 8. Transfer entropy surge
        let te_surge = max_transfer_entropy(&all_returns);

        // 9. VPIN aggregate (passed in)
        // 10. Liquidity score
        let liq = liquidity_score(&feed_spreads);

        // 11. Spread widening — update history
        let avg_spread = if feed_spreads.is_empty() {
            0.0
        } else {
            feed_spreads.values().sum::<f64>() / feed_spreads.len() as f64
        };
        if state.spread_history.len() >= 120 {
            state.spread_history.pop_front();
        }
        state.spread_history.push_back(avg_spread);
        let sw = spread_widening(&state.spread_history);

        // 12. Amihud ratio — need aligned return/volume series
        let amihud = amihud_ratio(&all_returns, &vol_series_aligned);

        // 13. BOCPD probability (passed in)
        // 14. CUSUM trigger count
        let cusum = cusum_trigger_count(&flat_returns);

        // 15. Vine tail risk (passed in)

        let report = CriticalityReport {
            correlation_convergence: corr_conv,
            contagion_score: contagion,
            regime_shift_detected: regime_shift,
            hurst_exponent: hurst,
            vol_signature_noise: vol_noise,
            two_scale_vol_ratio: ts_ratio,
            market_entropy: entropy,
            transfer_entropy_surge: te_surge,
            vpin_aggregate,
            liquidity_score: liq,
            spread_widening: sw,
            amihud_ratio: amihud,
            bocpd_probability,
            cusum_trigger_count: cusum,
            vine_tail_risk,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs_f64(),
        };

        state.prev_report = Some(report.clone());
        report
    }

    /// Check if avalanche reserve should be deployed.
    /// Returns the amount to deploy (0.0 if below threshold).
    fn avalanche_check(&self, market_drawdown: f64) -> f64 {
        let mut state = self.inner.lock().unwrap();
        if market_drawdown.abs() > state.avalanche_deploy_threshold && state.reserve_capital > 0.0 {
            // Deploy proportional to severity: (drawdown / threshold - 1) clamped to [0, 1]
            let severity = (market_drawdown.abs() / state.avalanche_deploy_threshold - 1.0)
                .clamp(0.0, 1.0);
            let deploy = state.reserve_capital * severity;
            let deploy = deploy.min(state.reserve_capital);
            state.reserve_capital -= deploy;
            deploy
        } else {
            0.0
        }
    }

    /// Replenish the avalanche reserve by the given amount.
    fn replenish_reserve(&self, amount: f64) {
        let mut state = self.inner.lock().unwrap();
        let max_reserve = state.total_capital * state.avalanche_reserve_pct;
        state.reserve_capital = (state.reserve_capital + amount).min(max_reserve);
    }

    /// Return the current avalanche reserve remaining.
    fn reserve_remaining(&self) -> f64 {
        self.inner.lock().unwrap().reserve_capital
    }
}
