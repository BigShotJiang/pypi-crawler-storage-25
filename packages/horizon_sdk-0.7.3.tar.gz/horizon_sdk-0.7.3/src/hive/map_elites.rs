//! MAP-Elites quality-diversity archive.
//!
//! Maintains a 300-cell grid (5 x 5 x 3 x 4) indexed by behavioral
//! descriptors: holding period, directional bias, volatility preference,
//! and asset focus. Each cell holds the highest-fitness StrategyGenome
//! that falls into that behavioral niche, ensuring the swarm always has
//! diverse strategy templates to draw from.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;

use super::types::StrategyGenome;

// ---------------------------------------------------------------------------
// Grid constants
// ---------------------------------------------------------------------------

const HP_BINS: u8 = 5;
const DB_BINS: u8 = 5;
const VP_BINS: u8 = 3;
const AF_BINS: u8 = 4;
const TOTAL_CELLS: usize =
    HP_BINS as usize * DB_BINS as usize * VP_BINS as usize * AF_BINS as usize; // 300

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Compute the MAP-Elites behavior cell for a genome.
/// Mirrors StrategyGenome::behavior_cell() which is a pymethods fn (private to Rust).
fn compute_behavior_cell(genome: &StrategyGenome) -> (u8, u8, u8, u8) {
    let hp = (genome.holding_period / (7.0 * 24.0 * 3600.0) * 5.0).min(4.0).max(0.0) as u8;
    let db = ((genome.directional_bias + 1.0) / 2.0 * 5.0).min(4.0).max(0.0) as u8;
    let vp = (genome.volatility_pref * 3.0).min(2.0).max(0.0) as u8;
    let af: u8 = match genome.asset_focus.as_str() {
        "pm" => 0, "crypto" => 1, "equity" => 2, _ => 3,
    };
    (hp, db, vp, af)
}

fn spawn_source_str(s: &super::types::SpawnSource) -> &'static str {
    match s {
        super::types::SpawnSource::Evolution => "evolution",
        super::types::SpawnSource::Template => "template",
        super::types::SpawnSource::Clone => "clone",
        super::types::SpawnSource::User => "user",
        super::types::SpawnSource::Imprint => "imprint",
        super::types::SpawnSource::Opportunistic => "opportunistic",
    }
}

fn archetype_str(a: &super::types::StrategyArchetype) -> &'static str {
    match a {
        super::types::StrategyArchetype::Momentum => "momentum",
        super::types::StrategyArchetype::MeanReversion => "mean_reversion",
        super::types::StrategyArchetype::MarketMaker => "market_maker",
        super::types::StrategyArchetype::Arbitrage => "arbitrage",
        super::types::StrategyArchetype::Volatility => "volatility",
        super::types::StrategyArchetype::EventDriven => "event_driven",
        super::types::StrategyArchetype::Macro => "macro",
        super::types::StrategyArchetype::Copy => "copy",
        super::types::StrategyArchetype::Liquidation => "liquidation",
    }
}

// ---------------------------------------------------------------------------
// MAPElitesArchive
// ---------------------------------------------------------------------------

/// Quality-diversity archive using a 300-cell MAP-Elites grid.
///
/// Grid dimensions:
/// - holding_period: 5 bins (sub-hour to weekly)
/// - directional_bias: 5 bins (strong short to strong long)
/// - volatility_pref: 3 bins (low, medium, high)
/// - asset_focus: 4 bins (pm=0, crypto=1, equity=2, cross=3)
///
/// Each cell stores at most one genome — the highest-fitness individual
/// that maps to that behavioral niche.
#[pyclass]
pub struct MAPElitesArchive {
    archive: Mutex<HashMap<(u8, u8, u8, u8), StrategyGenome>>,
}

#[pymethods]
impl MAPElitesArchive {
    #[new]
    fn new() -> Self {
        Self {
            archive: Mutex::new(HashMap::new()),
        }
    }

    /// Insert a genome into the archive if the cell is empty or if the
    /// genome's fitness exceeds the existing occupant. Returns true if inserted.
    fn add(&self, genome: &StrategyGenome) -> bool {
        let cell = compute_behavior_cell(genome);

        // Validate cell bounds
        if cell.0 >= HP_BINS || cell.1 >= DB_BINS || cell.2 >= VP_BINS || cell.3 >= AF_BINS {
            return false;
        }

        let mut archive = self.archive.lock().unwrap();
        match archive.get(&cell) {
            Some(existing) if existing.fitness >= genome.fitness => false,
            _ => {
                archive.insert(cell, genome.clone());
                true
            }
        }
    }

    /// Retrieve the genome occupying a specific cell, if any.
    fn get(&self, hp: u8, db: u8, vp: u8, af: u8) -> Option<StrategyGenome> {
        let archive = self.archive.lock().unwrap();
        archive.get(&(hp, db, vp, af)).cloned()
    }

    /// Get the highest-fitness genome suitable for a given regime.
    ///
    /// - "trending": directional bias bins 3-4 (strong directional)
    /// - "mean_reverting": directional bias bins 0-1 (counter-trend / neutral)
    /// - "volatile": volatility preference bin 2 (high vol)
    /// - "quiet": volatility preference bin 0 (low vol)
    fn get_best_for_regime(&self, regime: &str) -> Option<StrategyGenome> {
        let archive = self.archive.lock().unwrap();

        let filter_fn: Box<dyn Fn(&(u8, u8, u8, u8)) -> bool> = match regime {
            "trending" => Box::new(|cell: &(u8, u8, u8, u8)| cell.1 >= 3),
            "mean_reverting" => Box::new(|cell: &(u8, u8, u8, u8)| cell.1 <= 1),
            "volatile" => Box::new(|cell: &(u8, u8, u8, u8)| cell.2 == 2),
            "quiet" => Box::new(|cell: &(u8, u8, u8, u8)| cell.2 == 0),
            _ => return None,
        };

        archive
            .iter()
            .filter(|(cell, _)| filter_fn(cell))
            .max_by(|a, b| a.1.fitness.partial_cmp(&b.1.fitness).unwrap_or(std::cmp::Ordering::Equal))
            .map(|(_, g)| g.clone())
    }

    /// Get the highest-fitness genome for a given asset class.
    ///
    /// "pm" -> 0, "crypto" -> 1, "equity" -> 2, "cross" -> 3
    fn get_best_for_asset(&self, asset_class: &str) -> Option<StrategyGenome> {
        let af_bin: u8 = match asset_class {
            "pm" => 0,
            "crypto" => 1,
            "equity" => 2,
            "cross" => 3,
            _ => return None,
        };

        let archive = self.archive.lock().unwrap();
        archive
            .iter()
            .filter(|(cell, _)| cell.3 == af_bin)
            .max_by(|a, b| a.1.fitness.partial_cmp(&b.1.fitness).unwrap_or(std::cmp::Ordering::Equal))
            .map(|(_, g)| g.clone())
    }

    /// Return all genomes currently in the archive.
    fn get_all(&self) -> Vec<StrategyGenome> {
        let archive = self.archive.lock().unwrap();
        archive.values().cloned().collect()
    }

    /// Return the top N genomes by fitness, descending.
    fn best_n(&self, n: usize) -> Vec<StrategyGenome> {
        let archive = self.archive.lock().unwrap();
        let mut genomes: Vec<StrategyGenome> = archive.values().cloned().collect();
        genomes.sort_by(|a, b| b.fitness.partial_cmp(&a.fitness).unwrap_or(std::cmp::Ordering::Equal));
        genomes.truncate(n);
        genomes
    }

    /// Fraction of cells occupied: cells_filled / 300.
    fn coverage(&self) -> f64 {
        let archive = self.archive.lock().unwrap();
        archive.len() as f64 / TOTAL_CELLS as f64
    }

    /// Number of occupied cells.
    fn cells_filled(&self) -> usize {
        let archive = self.archive.lock().unwrap();
        archive.len()
    }

    /// Serialize the archive to a nested dict for persistence.
    ///
    /// Keys are "hp_db_vp_af" cell coordinates, values are genome attributes.
    fn snapshot(&self) -> HashMap<String, HashMap<String, PyObject>> {
        Python::with_gil(|py| {
            let archive = self.archive.lock().unwrap();
            let mut result = HashMap::new();

            for ((hp, db, vp, af), genome) in archive.iter() {
                let key = format!("{}_{}_{}_{}", hp, db, vp, af);
                let mut entry = HashMap::new();

                entry.insert(
                    "genome_id".into(),
                    genome.genome_id.clone().to_object(py),
                );
                entry.insert(
                    "fitness".into(),
                    genome.fitness.to_object(py),
                );
                entry.insert(
                    "sharpe".into(),
                    genome.sharpe.to_object(py),
                );
                entry.insert(
                    "max_drawdown".into(),
                    genome.max_drawdown.to_object(py),
                );
                entry.insert(
                    "holding_period".into(),
                    genome.holding_period.to_object(py),
                );
                entry.insert(
                    "directional_bias".into(),
                    genome.directional_bias.to_object(py),
                );
                entry.insert(
                    "volatility_pref".into(),
                    genome.volatility_pref.to_object(py),
                );
                entry.insert(
                    "asset_focus".into(),
                    genome.asset_focus.clone().to_object(py),
                );
                entry.insert(
                    "generation".into(),
                    genome.generation.to_object(py),
                );
                entry.insert(
                    "num_trades".into(),
                    genome.num_trades.to_object(py),
                );
                entry.insert(
                    "complexity".into(),
                    genome.complexity.to_object(py),
                );

                if let Some(arch) = &genome.archetype {
                    entry.insert(
                        "archetype".into(),
                        archetype_str(arch).to_object(py),
                    );
                }
                entry.insert(
                    "source".into(),
                    spawn_source_str(&genome.source).to_object(py),
                );

                result.insert(key, entry);
            }

            result
        })
    }

    /// Restore archive from a serialized dict (e.g., loaded from disk).
    ///
    /// Expects keys like "hp_db_vp_af" and values mapping field names to f64.
    /// Reconstructs minimal StrategyGenome objects with the restored fitness
    /// and behavioral descriptors.
    fn restore(&self, data: HashMap<String, HashMap<String, f64>>) {
        let mut archive = self.archive.lock().unwrap();
        archive.clear();

        for (key, fields) in &data {
            let parts: Vec<&str> = key.split('_').collect();
            if parts.len() != 4 {
                continue;
            }
            let hp: u8 = match parts[0].parse() {
                Ok(v) => v,
                Err(_) => continue,
            };
            let db: u8 = match parts[1].parse() {
                Ok(v) => v,
                Err(_) => continue,
            };
            let vp: u8 = match parts[2].parse() {
                Ok(v) => v,
                Err(_) => continue,
            };
            let af: u8 = match parts[3].parse() {
                Ok(v) => v,
                Err(_) => continue,
            };

            if hp >= HP_BINS || db >= DB_BINS || vp >= VP_BINS || af >= AF_BINS {
                continue;
            }

            // Reconstruct genome with behavioral descriptors that map to this cell
            let asset_focus = match af {
                0 => "pm",
                1 => "crypto",
                2 => "equity",
                _ => "cross",
            }
            .to_string();

            let holding_period = fields.get("holding_period").copied().unwrap_or(
                hp as f64 / 5.0 * 7.0 * 24.0 * 3600.0,
            );
            let directional_bias = fields.get("directional_bias").copied().unwrap_or(
                db as f64 / 5.0 * 2.0 - 1.0,
            );
            let volatility_pref = fields.get("volatility_pref").copied().unwrap_or(
                vp as f64 / 3.0,
            );
            let fitness = fields.get("fitness").copied().unwrap_or(0.0);
            let sharpe = fields.get("sharpe").copied().unwrap_or(0.0);
            let max_drawdown = fields.get("max_drawdown").copied().unwrap_or(0.0);
            let generation = fields.get("generation").copied().unwrap_or(0.0) as u32;
            let num_trades = fields.get("num_trades").copied().unwrap_or(0.0) as u32;
            let complexity = fields.get("complexity").copied().unwrap_or(0.0) as u32;

            let mut genome = StrategyGenome {
                genome_id: format!("restored_{}_{}_{}_{}",hp, db, vp, af),
                source: super::types::SpawnSource::Template,
                archetype: None,
                generation,
                lineage: vec![],
                hyperparams: HashMap::new(),
                holding_period,
                directional_bias,
                volatility_pref,
                asset_focus,
                fitness,
                sharpe,
                max_drawdown,
                num_trades,
                complexity,
                target_markets: vec![],
                target_exchanges: vec![],
                pipeline_config: HashMap::new(),
            };

            // Verify the genome maps back to the correct cell
            let actual_cell = compute_behavior_cell(&genome);
            if actual_cell != (hp, db, vp, af) {
                // Adjust so it lands in the right cell via direct field tweaking
                genome.holding_period = (hp as f64 + 0.5) / 5.0 * 7.0 * 24.0 * 3600.0;
                genome.directional_bias = (db as f64 + 0.5) / 5.0 * 2.0 - 1.0;
                genome.volatility_pref = (vp as f64 + 0.5) / 3.0;
            }

            archive.insert((hp, db, vp, af), genome);
        }
    }

    /// Clear all genomes from the archive.
    fn clear(&self) {
        let mut archive = self.archive.lock().unwrap();
        archive.clear();
    }
}
