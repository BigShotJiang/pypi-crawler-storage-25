//! Hive core types — enums, structs, configs.
//!
//! All types are #[pyclass] for Python interop via PyO3.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

fn now_secs() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs_f64()
}

pub fn gen_id(prefix: &str, len: usize) -> String {
    use std::hash::{Hash, Hasher};
    use std::collections::hash_map::DefaultHasher;
    let mut h = DefaultHasher::new();
    now_secs().to_bits().hash(&mut h);
    std::thread::current().id().hash(&mut h);
    let hex = format!("{:016x}", h.finish());
    format!("{}{}", prefix, &hex[..len.min(16)])
}

// ---------------------------------------------------------------------------
// Enums
// ---------------------------------------------------------------------------

/// Progressive autonomy levels.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AutonomyMode {
    Observe = 0,
    Suggest = 1,
    Supervised = 2,
    Autonomous = 3,
    Skynet = 4,
}

#[pymethods]
impl AutonomyMode {
    fn __repr__(&self) -> &'static str {
        match self {
            Self::Observe => "AutonomyMode.Observe",
            Self::Suggest => "AutonomyMode.Suggest",
            Self::Supervised => "AutonomyMode.Supervised",
            Self::Autonomous => "AutonomyMode.Autonomous",
            Self::Skynet => "AutonomyMode.Skynet",
        }
    }
    fn __str__(&self) -> &'static str {
        match self {
            Self::Observe => "observe",
            Self::Suggest => "suggest",
            Self::Supervised => "supervised",
            Self::Autonomous => "autonomous",
            Self::Skynet => "skynet",
        }
    }
    #[getter]
    fn value(&self) -> &'static str {
        self.__str__()
    }
}

/// Agent lifecycle states.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AgentLifecycle {
    Spawned = 0,
    Initializing = 1,
    Paper = 2,
    Shadow = 3,
    Live = 4,
    Paused = 5,
    Dying = 6,
    Mutating = 7,
    Terminated = 8,
}

#[pymethods]
impl AgentLifecycle {
    fn __repr__(&self) -> String { format!("AgentLifecycle.{:?}", self) }
    fn __str__(&self) -> &'static str {
        match self {
            Self::Spawned => "spawned", Self::Initializing => "initializing",
            Self::Paper => "paper", Self::Shadow => "shadow", Self::Live => "live",
            Self::Paused => "paused", Self::Dying => "dying",
            Self::Mutating => "mutating", Self::Terminated => "terminated",
        }
    }
    #[getter]
    fn value(&self) -> &'static str { self.__str__() }
}

/// How an agent was created.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SpawnSource {
    Evolution = 0,
    Template = 1,
    Clone = 2,
    User = 3,
    Imprint = 4,
    Opportunistic = 5,
}

#[pymethods]
impl SpawnSource {
    fn __repr__(&self) -> String { format!("SpawnSource.{:?}", self) }
    fn __str__(&self) -> &'static str {
        match self {
            Self::Evolution => "evolution", Self::Template => "template",
            Self::Clone => "clone", Self::User => "user",
            Self::Imprint => "imprint", Self::Opportunistic => "opportunistic",
        }
    }
    #[getter]
    fn value(&self) -> &'static str { self.__str__() }
}

/// Nine pheromone channels for stigmergic coordination.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PheromoneChannel {
    Bullish = 0,
    Bearish = 1,
    Volatility = 2,
    Crowding = 3,
    Opportunity = 4,
    Toxicity = 5,
    Liquidity = 6,
    RegimeTrend = 7,
    RegimeMR = 8,
}

#[pymethods]
impl PheromoneChannel {
    fn __repr__(&self) -> String { format!("PheromoneChannel.{:?}", self) }
    fn __str__(&self) -> &'static str {
        match self {
            Self::Bullish => "bullish", Self::Bearish => "bearish",
            Self::Volatility => "volatility", Self::Crowding => "crowding",
            Self::Opportunity => "opportunity", Self::Toxicity => "toxicity",
            Self::Liquidity => "liquidity", Self::RegimeTrend => "regime_trend",
            Self::RegimeMR => "regime_mr",
        }
    }
    #[getter]
    fn value(&self) -> &'static str { self.__str__() }
}

/// Incident severity levels.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum Severity {
    Sev1Critical = 1,
    Sev2High = 2,
    Sev3Medium = 3,
    Sev4Low = 4,
}

#[pymethods]
impl Severity {
    fn __repr__(&self) -> String { format!("Severity.{:?}", self) }
    #[getter]
    fn value(&self) -> u8 {
        match self {
            Self::Sev1Critical => 1, Self::Sev2High => 2,
            Self::Sev3Medium => 3, Self::Sev4Low => 4,
        }
    }
}

/// Strategy archetype templates.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StrategyArchetype {
    Momentum = 0,
    MeanReversion = 1,
    MarketMaker = 2,
    Arbitrage = 3,
    Volatility = 4,
    EventDriven = 5,
    Macro = 6,
    Copy = 7,
    Liquidation = 8,
}

#[pymethods]
impl StrategyArchetype {
    fn __repr__(&self) -> String { format!("StrategyArchetype.{:?}", self) }
    fn __str__(&self) -> &'static str {
        match self {
            Self::Momentum => "momentum", Self::MeanReversion => "mean_reversion",
            Self::MarketMaker => "market_maker", Self::Arbitrage => "arbitrage",
            Self::Volatility => "volatility", Self::EventDriven => "event_driven",
            Self::Macro => "macro", Self::Copy => "copy", Self::Liquidation => "liquidation",
        }
    }
    #[getter]
    fn value(&self) -> &'static str { self.__str__() }
}

/// Decision types for audit.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum DecisionType {
    SpawnAgent = 0,
    KillAgent = 1,
    PauseAgent = 2,
    ResumeAgent = 3,
    ScaleAgent = 4,
    PromoteAgent = 5,
    MutateAgent = 6,
    AllocateCapital = 7,
    RegimePosture = 8,
    EvolveGeneration = 9,
    DreamCycle = 10,
    RiskOff = 11,
    RiskOn = 12,
    Graduation = 13,
    InternalCross = 14,
}

#[pymethods]
impl DecisionType {
    fn __repr__(&self) -> String { format!("DecisionType.{:?}", self) }
    fn __str__(&self) -> &'static str {
        match self {
            Self::SpawnAgent => "spawn_agent", Self::KillAgent => "kill_agent",
            Self::PauseAgent => "pause_agent", Self::ResumeAgent => "resume_agent",
            Self::ScaleAgent => "scale_agent", Self::PromoteAgent => "promote_agent",
            Self::MutateAgent => "mutate_agent", Self::AllocateCapital => "allocate_capital",
            Self::RegimePosture => "regime_posture", Self::EvolveGeneration => "evolve_generation",
            Self::DreamCycle => "dream_cycle", Self::RiskOff => "risk_off",
            Self::RiskOn => "risk_on", Self::Graduation => "graduation",
            Self::InternalCross => "internal_cross",
        }
    }
    #[getter]
    fn value(&self) -> &'static str { self.__str__() }
}

/// Hive event types.
#[pyclass(eq, eq_int, frozen, hash)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum HiveEventType {
    AgentSpawned = 0, AgentTerminated = 1, AgentPromoted = 2,
    AgentPaused = 3, AgentMutated = 4, AgentScaled = 5,
    TradeSubmitted = 10, TradeFilled = 11, TradeCanceled = 12, InternalCross = 13,
    RegimeChanged = 20, RegimeApproaching = 21,
    DrawdownBreach = 30, KillSwitch = 31, VvarExceeded = 32,
    CriticalityWarning = 33, AvalancheDeploy = 34,
    FactAdded = 40, OpportunitySurfaced = 41, CausalBreak = 42,
    CrowdingAlert = 50, OpportunityDetected = 51,
    GenerationComplete = 60, NewSpecies = 61, DreamComplete = 62,
    Suggestion = 70, ModelUpdated = 71, GraduationProposed = 72,
    MarketResolved = 80, ViewShift = 81,
    ModeChanged = 90, GraduationApproved = 91,
    IncidentDetected = 100, IncidentContained = 101, IncidentResolved = 102,
}

#[pymethods]
impl HiveEventType {
    fn __repr__(&self) -> String { format!("HiveEventType.{:?}", self) }
}

// ---------------------------------------------------------------------------
// Config structs
// ---------------------------------------------------------------------------

/// Configuration for a single pheromone channel.
#[pyclass(frozen, get_all)]
#[derive(Debug, Clone)]
pub struct ChannelConfig {
    pub evaporation_rate: f64,
    pub diffusion_radius: i32,
    pub saturation: f64,
    pub deposit_weight: f64,
}

#[pymethods]
impl ChannelConfig {
    #[new]
    #[pyo3(signature = (evaporation_rate, diffusion_radius, saturation, deposit_weight))]
    fn new(evaporation_rate: f64, diffusion_radius: i32, saturation: f64, deposit_weight: f64) -> Self {
        Self { evaporation_rate, diffusion_radius, saturation, deposit_weight }
    }
}

/// Default channel configs (indexed by PheromoneChannel discriminant).
pub const CHANNEL_DEFAULTS: [(f64, i32, f64, f64); 9] = [
    (0.01,  2, 100.0, 1.0),  // Bullish
    (0.01,  2, 100.0, 1.0),  // Bearish
    (0.005, 3, 50.0,  1.0),  // Volatility
    (0.001, 0, 50.0,  1.0),  // Crowding
    (0.02,  1, 100.0, 1.0),  // Opportunity
    (0.008, 1, 50.0,  1.5),  // Toxicity
    (0.003, 0, 100.0, 1.0),  // Liquidity
    (0.002, 3, 10.0,  1.0),  // RegimeTrend
    (0.002, 3, 10.0,  1.0),  // RegimeMR
];

/// Pheromone readings for a single market.
#[pyclass(get_all, set_all)]
#[derive(Debug, Clone, Default)]
pub struct MarketPheromones {
    pub bullish: f64,
    pub bearish: f64,
    pub volatility: f64,
    pub crowding: f64,
    pub opportunity: f64,
    pub toxicity: f64,
    pub liquidity: f64,
    pub regime_trend: f64,
    pub regime_mr: f64,
}

#[pymethods]
impl MarketPheromones {
    #[new]
    #[pyo3(signature = (
        bullish=0.0, bearish=0.0, volatility=0.0, crowding=0.0,
        opportunity=0.0, toxicity=0.0, liquidity=0.0,
        regime_trend=0.0, regime_mr=0.0
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(bullish: f64, bearish: f64, volatility: f64, crowding: f64,
           opportunity: f64, toxicity: f64, liquidity: f64,
           regime_trend: f64, regime_mr: f64) -> Self {
        Self { bullish, bearish, volatility, crowding, opportunity, toxicity, liquidity, regime_trend, regime_mr }
    }

    fn as_dict(&self) -> HashMap<String, f64> {
        let mut m = HashMap::new();
        m.insert("bullish".into(), self.bullish);
        m.insert("bearish".into(), self.bearish);
        m.insert("volatility".into(), self.volatility);
        m.insert("crowding".into(), self.crowding);
        m.insert("opportunity".into(), self.opportunity);
        m.insert("toxicity".into(), self.toxicity);
        m.insert("liquidity".into(), self.liquidity);
        m.insert("regime_trend".into(), self.regime_trend);
        m.insert("regime_mr".into(), self.regime_mr);
        m
    }

    fn get_channel(&self, channel: PheromoneChannel) -> f64 {
        match channel {
            PheromoneChannel::Bullish => self.bullish,
            PheromoneChannel::Bearish => self.bearish,
            PheromoneChannel::Volatility => self.volatility,
            PheromoneChannel::Crowding => self.crowding,
            PheromoneChannel::Opportunity => self.opportunity,
            PheromoneChannel::Toxicity => self.toxicity,
            PheromoneChannel::Liquidity => self.liquidity,
            PheromoneChannel::RegimeTrend => self.regime_trend,
            PheromoneChannel::RegimeMR => self.regime_mr,
        }
    }
}

impl MarketPheromones {
    pub fn get_mut(&mut self, idx: usize) -> &mut f64 {
        match idx {
            0 => &mut self.bullish, 1 => &mut self.bearish,
            2 => &mut self.volatility, 3 => &mut self.crowding,
            4 => &mut self.opportunity, 5 => &mut self.toxicity,
            6 => &mut self.liquidity, 7 => &mut self.regime_trend,
            8 => &mut self.regime_mr,
            _ => unreachable!(),
        }
    }
    pub fn get_idx(&self, idx: usize) -> f64 {
        match idx {
            0 => self.bullish, 1 => self.bearish,
            2 => self.volatility, 3 => self.crowding,
            4 => self.opportunity, 5 => self.toxicity,
            6 => self.liquidity, 7 => self.regime_trend,
            8 => self.regime_mr,
            _ => 0.0,
        }
    }
}

// ---------------------------------------------------------------------------
// HiveConfig
// ---------------------------------------------------------------------------

#[pyclass(get_all, set_all)]
#[derive(Debug, Clone)]
pub struct HiveConfig {
    pub host: String,
    pub port: u16,
    pub auth_token: Option<String>,
    pub max_agents: usize,
    pub total_capital: f64,
    pub max_capital_per_agent_pct: f64,
    pub max_drawdown_pct: f64,
    pub population_size: usize,
    pub generations_per_cycle: usize,
    pub island_count: usize,
    pub migration_interval: usize,
    pub migration_fraction: f64,
    pub gp_max_depth: usize,
    pub gp_tournament_size: usize,
    pub gp_crossover_rate: f64,
    pub gp_mutation_rate: f64,
    pub pheromone_tick_interval: f64,
    pub initial_mode: AutonomyMode,
    pub graduation_cooldown_days: u32,
    pub imprint_enabled: bool,
    pub imprint_min_actions: usize,
    pub imprint_train_interval_hours: f64,
    pub fitness_gamma: f64,
    pub diversity_tax_threshold: f64,
    pub age_cull_days: u32,
    pub min_sharpe_paper: f64,
    pub min_sharpe_shadow: f64,
    pub criticality_check_interval: f64,
    pub avalanche_reserve_pct: f64,
    pub avalanche_deploy_threshold: f64,
    pub pbt_interval_hours: f64,
    pub pbt_exploit_fraction: f64,
    pub pbt_explore_magnitude: f64,
    pub dream_enabled: bool,
    pub dream_generations: usize,
    pub consensus_prediction_market_enabled: bool,
    pub impact_gate_margin: f64,
    pub internal_crossing_enabled: bool,
    pub metamorphic_enabled: bool,
    pub metamorphic_size_jitter: f64,
    pub metamorphic_aggression_alpha: f64,
    pub metamorphic_aggression_beta: f64,
    pub db_path: String,
}

#[pymethods]
impl HiveConfig {
    #[new]
    #[pyo3(signature = (
        host="0.0.0.0".to_string(), port=8780, auth_token=None,
        max_agents=50, total_capital=100_000.0,
        max_capital_per_agent_pct=0.15, max_drawdown_pct=0.20,
        population_size=100, generations_per_cycle=10,
        island_count=5, migration_interval=50, migration_fraction=0.05,
        gp_max_depth=8, gp_tournament_size=5,
        gp_crossover_rate=0.7, gp_mutation_rate=0.2,
        pheromone_tick_interval=1.0,
        initial_mode=AutonomyMode::Observe,
        graduation_cooldown_days=7,
        imprint_enabled=true, imprint_min_actions=100,
        imprint_train_interval_hours=24.0,
        fitness_gamma=1.5, diversity_tax_threshold=0.7,
        age_cull_days=30, min_sharpe_paper=1.0, min_sharpe_shadow=1.2,
        criticality_check_interval=60.0,
        avalanche_reserve_pct=0.15, avalanche_deploy_threshold=0.30,
        pbt_interval_hours=24.0, pbt_exploit_fraction=0.2, pbt_explore_magnitude=0.2,
        dream_enabled=true, dream_generations=10_000,
        consensus_prediction_market_enabled=true,
        impact_gate_margin=0.5, internal_crossing_enabled=true,
        metamorphic_enabled=true, metamorphic_size_jitter=0.15,
        metamorphic_aggression_alpha=2.0, metamorphic_aggression_beta=5.0,
        db_path="hive.db".to_string(),
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        host: String, port: u16, auth_token: Option<String>,
        max_agents: usize, total_capital: f64,
        max_capital_per_agent_pct: f64, max_drawdown_pct: f64,
        population_size: usize, generations_per_cycle: usize,
        island_count: usize, migration_interval: usize, migration_fraction: f64,
        gp_max_depth: usize, gp_tournament_size: usize,
        gp_crossover_rate: f64, gp_mutation_rate: f64,
        pheromone_tick_interval: f64,
        initial_mode: AutonomyMode,
        graduation_cooldown_days: u32,
        imprint_enabled: bool, imprint_min_actions: usize,
        imprint_train_interval_hours: f64,
        fitness_gamma: f64, diversity_tax_threshold: f64,
        age_cull_days: u32, min_sharpe_paper: f64, min_sharpe_shadow: f64,
        criticality_check_interval: f64,
        avalanche_reserve_pct: f64, avalanche_deploy_threshold: f64,
        pbt_interval_hours: f64, pbt_exploit_fraction: f64, pbt_explore_magnitude: f64,
        dream_enabled: bool, dream_generations: usize,
        consensus_prediction_market_enabled: bool,
        impact_gate_margin: f64, internal_crossing_enabled: bool,
        metamorphic_enabled: bool, metamorphic_size_jitter: f64,
        metamorphic_aggression_alpha: f64, metamorphic_aggression_beta: f64,
        db_path: String,
    ) -> Self {
        Self {
            host, port, auth_token, max_agents, total_capital,
            max_capital_per_agent_pct, max_drawdown_pct,
            population_size, generations_per_cycle,
            island_count, migration_interval, migration_fraction,
            gp_max_depth, gp_tournament_size, gp_crossover_rate, gp_mutation_rate,
            pheromone_tick_interval, initial_mode, graduation_cooldown_days,
            imprint_enabled, imprint_min_actions, imprint_train_interval_hours,
            fitness_gamma, diversity_tax_threshold,
            age_cull_days, min_sharpe_paper, min_sharpe_shadow,
            criticality_check_interval, avalanche_reserve_pct, avalanche_deploy_threshold,
            pbt_interval_hours, pbt_exploit_fraction, pbt_explore_magnitude,
            dream_enabled, dream_generations,
            consensus_prediction_market_enabled,
            impact_gate_margin, internal_crossing_enabled,
            metamorphic_enabled, metamorphic_size_jitter,
            metamorphic_aggression_alpha, metamorphic_aggression_beta,
            db_path,
        }
    }
}

// ---------------------------------------------------------------------------
// StrategyGenome
// ---------------------------------------------------------------------------

#[pyclass(get_all, set_all)]
#[derive(Debug, Clone)]
pub struct StrategyGenome {
    pub genome_id: String,
    pub source: SpawnSource,
    pub archetype: Option<StrategyArchetype>,
    pub generation: u32,
    pub lineage: Vec<String>,
    pub hyperparams: HashMap<String, f64>,
    pub holding_period: f64,
    pub directional_bias: f64,
    pub volatility_pref: f64,
    pub asset_focus: String,
    pub fitness: f64,
    pub sharpe: f64,
    pub max_drawdown: f64,
    pub num_trades: u32,
    pub complexity: u32,
    pub target_markets: Vec<String>,
    pub target_exchanges: Vec<String>,
    pub pipeline_config: HashMap<String, String>,
}

#[pymethods]
impl StrategyGenome {
    #[new]
    #[pyo3(signature = (
        source=SpawnSource::Template, archetype=None, generation=0,
        hyperparams=HashMap::new(), holding_period=0.0, directional_bias=0.0,
        volatility_pref=0.5, asset_focus="cross".to_string(),
        target_markets=vec![], pipeline_config=HashMap::new(),
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        source: SpawnSource, archetype: Option<StrategyArchetype>, generation: u32,
        hyperparams: HashMap<String, f64>, holding_period: f64, directional_bias: f64,
        volatility_pref: f64, asset_focus: String,
        target_markets: Vec<String>, pipeline_config: HashMap<String, String>,
    ) -> Self {
        Self {
            genome_id: gen_id("", 12),
            source, archetype, generation, lineage: vec![],
            hyperparams, holding_period, directional_bias, volatility_pref, asset_focus,
            fitness: 0.0, sharpe: 0.0, max_drawdown: 0.0, num_trades: 0, complexity: 0,
            target_markets, target_exchanges: vec![], pipeline_config,
        }
    }

    /// Discretize behavioral descriptor for MAP-Elites grid.
    fn behavior_cell(&self) -> (u8, u8, u8, u8) {
        let hp = (self.holding_period / (7.0 * 24.0 * 3600.0) * 5.0).min(4.0).max(0.0) as u8;
        let db = ((self.directional_bias + 1.0) / 2.0 * 5.0).min(4.0).max(0.0) as u8;
        let vp = (self.volatility_pref * 3.0).min(2.0).max(0.0) as u8;
        let af: u8 = match self.asset_focus.as_str() {
            "pm" => 0, "crypto" => 1, "equity" => 2, _ => 3,
        };
        (hp, db, vp, af)
    }
}

// ---------------------------------------------------------------------------
// HiveAgent
// ---------------------------------------------------------------------------

#[pyclass(get_all, set_all)]
#[derive(Debug, Clone)]
pub struct HiveAgent {
    pub agent_id: String,
    pub genome: StrategyGenome,
    pub lifecycle: AgentLifecycle,
    pub birth_time: f64,
    pub promotion_history: Vec<HashMap<String, String>>,
    pub capital: f64,
    pub markets: Vec<String>,
    pub sharpe: f64,
    pub pnl: f64,
    pub max_drawdown: f64,
    pub alpha: f64,
    pub fitness: f64,
    pub num_trades: u32,
    pub reputation: f64,
    pub reputation_confidence: f64,
    pub hyperparams: HashMap<String, f64>,
}

#[pymethods]
impl HiveAgent {
    #[new]
    #[pyo3(signature = (genome=StrategyGenome::new(
        SpawnSource::Template, None, 0, HashMap::new(), 0.0, 0.0,
        0.5, "cross".to_string(), vec![], HashMap::new(),
    ), lifecycle=AgentLifecycle::Spawned))]
    fn new(genome: StrategyGenome, lifecycle: AgentLifecycle) -> Self {
        Self {
            agent_id: gen_id("hv-", 8),
            genome, lifecycle,
            birth_time: now_secs(),
            promotion_history: vec![],
            capital: 0.0, markets: vec![],
            sharpe: 0.0, pnl: 0.0, max_drawdown: 0.0,
            alpha: 0.0, fitness: 0.0, num_trades: 0,
            reputation: 0.5, reputation_confidence: 0.0,
            hyperparams: HashMap::new(),
        }
    }

    fn age_seconds(&self) -> f64 { now_secs() - self.birth_time }
    fn age_days(&self) -> f64 { self.age_seconds() / 86400.0 }

    fn to_dict(&self) -> HashMap<String, PyObject> {
        Python::with_gil(|py| {
            let mut m = HashMap::new();
            m.insert("agent_id".into(), self.agent_id.clone().to_object(py));
            m.insert("genome_id".into(), self.genome.genome_id.clone().to_object(py));
            m.insert("lifecycle".into(), self.lifecycle.__str__().to_object(py));
            m.insert("capital".into(), self.capital.to_object(py));
            m.insert("markets".into(), self.markets.clone().to_object(py));
            m.insert("sharpe".into(), self.sharpe.to_object(py));
            m.insert("pnl".into(), self.pnl.to_object(py));
            m.insert("max_drawdown".into(), self.max_drawdown.to_object(py));
            m.insert("fitness".into(), self.fitness.to_object(py));
            m.insert("reputation".into(), self.reputation.to_object(py));
            m.insert("num_trades".into(), self.num_trades.to_object(py));
            m.insert("age_days".into(), self.age_days().to_object(py));
            m.insert("generation".into(), self.genome.generation.to_object(py));
            if let Some(arch) = &self.genome.archetype {
                m.insert("archetype".into(), arch.__str__().to_object(py));
            }
            m.insert("source".into(), self.genome.source.__str__().to_object(py));
            m
        })
    }
}

// ---------------------------------------------------------------------------
// CriticalityReport
// ---------------------------------------------------------------------------

#[pyclass(get_all)]
#[derive(Debug, Clone, Default)]
pub struct CriticalityReport {
    pub correlation_convergence: f64,
    pub contagion_score: f64,
    pub regime_shift_detected: bool,
    pub hurst_exponent: f64,
    pub vol_signature_noise: f64,
    pub two_scale_vol_ratio: f64,
    pub market_entropy: f64,
    pub transfer_entropy_surge: f64,
    pub vpin_aggregate: f64,
    pub liquidity_score: f64,
    pub spread_widening: f64,
    pub amihud_ratio: f64,
    pub bocpd_probability: f64,
    pub cusum_trigger_count: u32,
    pub vine_tail_risk: f64,
    pub timestamp: f64,
}

#[pymethods]
impl CriticalityReport {
    #[new]
    fn new() -> Self {
        Self { hurst_exponent: 0.5, market_entropy: 1.0, liquidity_score: 1.0,
               two_scale_vol_ratio: 1.0, timestamp: now_secs(), ..Default::default() }
    }

    fn warning_count(&self) -> u32 {
        let mut c = 0u32;
        if self.correlation_convergence > 0.7 { c += 1; }
        if self.contagion_score > 0.7 { c += 1; }
        if self.regime_shift_detected { c += 1; }
        if self.hurst_exponent > 0.7 { c += 1; }
        if self.vol_signature_noise > 0.5 { c += 1; }
        if self.two_scale_vol_ratio > 2.0 { c += 1; }
        if self.market_entropy < 0.3 { c += 1; }
        if self.transfer_entropy_surge > 0.7 { c += 1; }
        if self.vpin_aggregate > 0.7 { c += 1; }
        if self.liquidity_score < 0.3 { c += 1; }
        if self.spread_widening > 0.5 { c += 1; }
        if self.amihud_ratio > 0.7 { c += 1; }
        if self.bocpd_probability > 0.7 { c += 1; }
        if self.cusum_trigger_count > 5 { c += 1; }
        if self.vine_tail_risk > 0.1 { c += 1; }
        c
    }

    fn is_critical(&self, threshold: u32) -> bool { self.warning_count() >= threshold }

    fn to_dict(&self) -> HashMap<String, f64> {
        let mut m = HashMap::new();
        m.insert("correlation_convergence".into(), self.correlation_convergence);
        m.insert("contagion_score".into(), self.contagion_score);
        m.insert("regime_shift_detected".into(), if self.regime_shift_detected { 1.0 } else { 0.0 });
        m.insert("hurst_exponent".into(), self.hurst_exponent);
        m.insert("vol_signature_noise".into(), self.vol_signature_noise);
        m.insert("two_scale_vol_ratio".into(), self.two_scale_vol_ratio);
        m.insert("market_entropy".into(), self.market_entropy);
        m.insert("transfer_entropy_surge".into(), self.transfer_entropy_surge);
        m.insert("vpin_aggregate".into(), self.vpin_aggregate);
        m.insert("liquidity_score".into(), self.liquidity_score);
        m.insert("spread_widening".into(), self.spread_widening);
        m.insert("amihud_ratio".into(), self.amihud_ratio);
        m.insert("bocpd_probability".into(), self.bocpd_probability);
        m.insert("cusum_trigger_count".into(), self.cusum_trigger_count as f64);
        m.insert("vine_tail_risk".into(), self.vine_tail_risk);
        m
    }
}

// ---------------------------------------------------------------------------
// Remaining types (decision, consensus, imprint, incident, etc.)
// ---------------------------------------------------------------------------

#[pyclass(get_all, set_all)]
#[derive(Debug, Clone)]
pub struct HiveDecision {
    pub decision_id: String,
    pub timestamp: f64,
    pub decision_type: DecisionType,
    pub action_taken: String,
    pub reasoning: String,
    pub confidence: f64,
    pub regime: String,
    pub autonomy_mode: AutonomyMode,
    pub user_approved: Option<bool>,
    pub outcome: Option<String>,
    pub was_correct: Option<bool>,
}

#[pymethods]
impl HiveDecision {
    #[new]
    #[pyo3(signature = (decision_type=DecisionType::SpawnAgent, action_taken="".to_string(),
        reasoning="".to_string(), confidence=0.0, autonomy_mode=AutonomyMode::Observe))]
    fn new(decision_type: DecisionType, action_taken: String, reasoning: String,
           confidence: f64, autonomy_mode: AutonomyMode) -> Self {
        Self {
            decision_id: gen_id("", 16), timestamp: now_secs(),
            decision_type, action_taken, reasoning, confidence,
            regime: String::new(), autonomy_mode,
            user_approved: None, outcome: None, was_correct: None,
        }
    }

    fn to_dict(&self) -> HashMap<String, PyObject> {
        Python::with_gil(|py| {
            let mut m = HashMap::new();
            m.insert("decision_id".into(), self.decision_id.clone().to_object(py));
            m.insert("timestamp".into(), self.timestamp.to_object(py));
            m.insert("decision_type".into(), self.decision_type.__str__().to_object(py));
            m.insert("action_taken".into(), self.action_taken.clone().to_object(py));
            m.insert("reasoning".into(), self.reasoning.clone().to_object(py));
            m.insert("confidence".into(), self.confidence.to_object(py));
            m.insert("autonomy_mode".into(), self.autonomy_mode.__str__().to_object(py));
            m
        })
    }
}

#[pyclass(frozen, get_all)]
#[derive(Debug, Clone)]
pub struct ConsensusView {
    pub agent_id: String,
    pub probability: f64,
    pub confidence: f64,
    pub stake: f64,
}

#[pymethods]
impl ConsensusView {
    #[new]
    fn new(agent_id: String, probability: f64, confidence: f64, stake: f64) -> Self {
        Self { agent_id, probability, confidence, stake }
    }
}

#[pyclass(get_all, set_all)]
#[derive(Debug, Clone)]
pub struct InternalMarket {
    pub market_id: String,
    pub question: String,
    pub deadline: f64,
    pub resolved: bool,
    pub outcome: Option<bool>,
    pub created_at: f64,
    pub consensus_probability: f64,
}

#[pymethods]
impl InternalMarket {
    #[new]
    fn new(question: String, deadline: f64) -> Self {
        Self {
            market_id: gen_id("", 12), question, deadline,
            resolved: false, outcome: None, created_at: now_secs(),
            consensus_probability: 0.5,
        }
    }
}

#[pyclass(get_all)]
#[derive(Debug, Clone)]
pub struct ImprintAction {
    pub timestamp: f64,
    pub action_type: String,
    pub action_params: HashMap<String, String>,
    pub feed_snapshots: HashMap<String, f64>,
    pub pnl: f64,
    pub regime: String,
    pub volatility: f64,
    pub time_of_day: f64,
    pub day_of_week: u8,
}

#[pymethods]
impl ImprintAction {
    #[new]
    #[pyo3(signature = (timestamp, action_type, action_params=HashMap::new(),
        feed_snapshots=HashMap::new(), pnl=0.0, regime="".to_string(),
        volatility=0.0, time_of_day=0.0, day_of_week=0))]
    #[allow(clippy::too_many_arguments)]
    fn new(timestamp: f64, action_type: String, action_params: HashMap<String, String>,
           feed_snapshots: HashMap<String, f64>, pnl: f64, regime: String,
           volatility: f64, time_of_day: f64, day_of_week: u8) -> Self {
        Self { timestamp, action_type, action_params, feed_snapshots, pnl, regime, volatility, time_of_day, day_of_week }
    }
}

#[pyclass(get_all, set_all)]
#[derive(Debug, Clone)]
pub struct Incident {
    pub incident_id: String,
    pub severity: Severity,
    pub trigger: String,
    pub affected_agents: Vec<String>,
    pub state: String,
    pub root_cause: Option<String>,
    pub pnl_impact: f64,
    pub created_at: f64,
    pub resolved_at: Option<f64>,
}

#[pymethods]
impl Incident {
    #[new]
    #[pyo3(signature = (severity=Severity::Sev4Low, trigger="".to_string(),
        affected_agents=vec![], pnl_impact=0.0))]
    fn new(severity: Severity, trigger: String, affected_agents: Vec<String>, pnl_impact: f64) -> Self {
        Self {
            incident_id: gen_id("", 12), severity, trigger, affected_agents,
            state: "detected".into(), root_cause: None, pnl_impact,
            created_at: now_secs(), resolved_at: None,
        }
    }
}

#[pyclass(frozen, get_all)]
#[derive(Debug, Clone)]
pub struct SwarmStatus {
    pub total_agents: usize,
    pub active_agents: usize,
    pub paper_agents: usize,
    pub shadow_agents: usize,
    pub live_agents: usize,
    pub total_capital: f64,
    pub allocated_capital: f64,
    pub reserve_capital: f64,
    pub total_pnl: f64,
    pub aggregate_sharpe: f64,
    pub aggregate_drawdown: f64,
    pub autonomy_mode: AutonomyMode,
}

#[pymethods]
impl SwarmStatus {
    #[new]
    fn new() -> Self {
        Self {
            total_agents: 0, active_agents: 0, paper_agents: 0,
            shadow_agents: 0, live_agents: 0, total_capital: 0.0,
            allocated_capital: 0.0, reserve_capital: 0.0,
            total_pnl: 0.0, aggregate_sharpe: 0.0, aggregate_drawdown: 0.0,
            autonomy_mode: AutonomyMode::Observe,
        }
    }
}

// ---------------------------------------------------------------------------
// Execution types (for metamorphic)
// ---------------------------------------------------------------------------

#[pyclass(frozen, get_all)]
#[derive(Debug, Clone)]
pub struct ExecutionSlice {
    pub slice_id: String,
    pub size: f64,
    pub delay_seconds: f64,
    pub aggression: f64,
    pub venue: String,
    pub price_offset: f64,
    pub is_decoy: bool,
}

#[pymethods]
impl ExecutionSlice {
    #[new]
    fn new(size: f64, delay_seconds: f64, aggression: f64, venue: String,
           price_offset: f64, is_decoy: bool) -> Self {
        Self { slice_id: gen_id("sl-", 8), size, delay_seconds, aggression, venue, price_offset, is_decoy }
    }
}

#[pyclass(frozen, get_all)]
#[derive(Debug, Clone)]
pub struct ExecutionPlan {
    pub plan_id: String,
    pub market_id: String,
    pub side: String,
    pub total_size: f64,
    pub urgency: f64,
    pub slices: Vec<ExecutionSlice>,
}

#[pymethods]
impl ExecutionPlan {
    #[new]
    fn new(market_id: String, side: String, total_size: f64, urgency: f64,
           slices: Vec<ExecutionSlice>) -> Self {
        Self { plan_id: gen_id("ep-", 8), market_id, side, total_size, urgency, slices }
    }
    #[getter]
    fn n_slices(&self) -> usize {
        self.slices.iter().filter(|s| !s.is_decoy).count()
    }
}

// ---------------------------------------------------------------------------
// Causal types
// ---------------------------------------------------------------------------

#[pyclass(frozen, get_all)]
#[derive(Debug, Clone)]
pub struct CausalEdge {
    pub source: String,
    pub target: String,
    pub granger_pvalue: f64,
    pub transfer_entropy: f64,
    pub lag: i32,
    pub weight: f64,
}

#[pymethods]
impl CausalEdge {
    #[new]
    fn new(source: String, target: String, granger_pvalue: f64,
           transfer_entropy: f64, lag: i32, weight: f64) -> Self {
        Self { source, target, granger_pvalue, transfer_entropy, lag, weight }
    }
}

#[pyclass(frozen, get_all)]
#[derive(Debug, Clone)]
pub struct CausalGraph {
    pub edges: Vec<CausalEdge>,
    pub markets: Vec<String>,
    pub built_at: f64,
}

#[pymethods]
impl CausalGraph {
    #[new]
    fn new(edges: Vec<CausalEdge>, markets: Vec<String>) -> Self {
        Self { edges, markets, built_at: now_secs() }
    }
}

// ---------------------------------------------------------------------------
// Public Rust-accessible helpers (for use by sibling modules)
// ---------------------------------------------------------------------------

impl AutonomyMode {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Observe => "observe",
            Self::Suggest => "suggest",
            Self::Supervised => "supervised",
            Self::Autonomous => "autonomous",
            Self::Skynet => "skynet",
        }
    }
}

impl AgentLifecycle {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Spawned => "spawned", Self::Initializing => "initializing",
            Self::Paper => "paper", Self::Shadow => "shadow", Self::Live => "live",
            Self::Paused => "paused", Self::Dying => "dying",
            Self::Mutating => "mutating", Self::Terminated => "terminated",
        }
    }
}

impl StrategyArchetype {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Momentum => "momentum", Self::MeanReversion => "mean_reversion",
            Self::MarketMaker => "market_maker", Self::Arbitrage => "arbitrage",
            Self::Volatility => "volatility", Self::EventDriven => "event_driven",
            Self::Macro => "macro", Self::Copy => "copy", Self::Liquidation => "liquidation",
        }
    }
}

impl SpawnSource {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Evolution => "evolution", Self::Template => "template",
            Self::Clone => "clone", Self::User => "user",
            Self::Imprint => "imprint", Self::Opportunistic => "opportunistic",
        }
    }
}

impl Incident {
    pub fn create(severity: Severity, trigger: String, affected_agents: Vec<String>, pnl_impact: f64) -> Self {
        Self {
            incident_id: gen_id("", 12), severity, trigger, affected_agents,
            state: "detected".into(), root_cause: None, pnl_impact,
            created_at: now_secs(), resolved_at: None,
        }
    }
}

impl HiveAgent {
    pub fn create(genome: StrategyGenome, lifecycle: AgentLifecycle) -> Self {
        Self {
            agent_id: gen_id("hv-", 8),
            genome, lifecycle,
            birth_time: now_secs(),
            promotion_history: vec![],
            capital: 0.0, markets: vec![],
            sharpe: 0.0, pnl: 0.0, max_drawdown: 0.0,
            alpha: 0.0, fitness: 0.0, num_trades: 0,
            reputation: 0.5, reputation_confidence: 0.0,
            hyperparams: HashMap::new(),
        }
    }

    pub fn to_dict_py(&self) -> HashMap<String, PyObject> {
        Python::with_gil(|py| {
            let mut m = HashMap::new();
            m.insert("agent_id".into(), self.agent_id.clone().to_object(py));
            m.insert("genome_id".into(), self.genome.genome_id.clone().to_object(py));
            m.insert("lifecycle".into(), self.lifecycle.as_str().to_object(py));
            m.insert("capital".into(), self.capital.to_object(py));
            m.insert("markets".into(), self.markets.clone().to_object(py));
            m.insert("sharpe".into(), self.sharpe.to_object(py));
            m.insert("pnl".into(), self.pnl.to_object(py));
            m.insert("max_drawdown".into(), self.max_drawdown.to_object(py));
            m.insert("fitness".into(), self.fitness.to_object(py));
            m.insert("reputation".into(), self.reputation.to_object(py));
            m.insert("num_trades".into(), self.num_trades.to_object(py));
            m.insert("age_days".into(), ((now_secs() - self.birth_time) / 86400.0).to_object(py));
            m.insert("generation".into(), self.genome.generation.to_object(py));
            if let Some(ref arch) = self.genome.archetype {
                m.insert("archetype".into(), arch.as_str().to_object(py));
            }
            m.insert("source".into(), self.genome.source.as_str().to_object(py));
            m
        })
    }
}
