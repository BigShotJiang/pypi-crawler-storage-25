//! Metamorphic execution — anti-fingerprint order slicing.
//!
//! Randomizes order sizes, timing, aggression, venue selection, and price
//! offsets to prevent adversarial detection of the swarm's execution patterns.
//! Uses 6 randomization layers: size jitter, exponential timing, beta-distributed
//! aggression, round-robin venue cycling, Gaussian price offsets, and decoy orders.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;

use super::types::{ExecutionPlan, ExecutionSlice};

// ---------------------------------------------------------------------------
// PRNG (deterministic LCG — same as evolution.rs)
// ---------------------------------------------------------------------------

struct Rng {
    state: u64,
}

impl Rng {
    fn new(seed: u64) -> Self {
        Self {
            state: seed.wrapping_add(1),
        }
    }

    fn next_u64(&mut self) -> u64 {
        self.state = self
            .state
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        self.state
    }

    fn next_f64(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 / (1u64 << 53) as f64
    }

    fn next_gaussian(&mut self) -> f64 {
        let u1 = self.next_f64().max(1e-15);
        let u2 = self.next_f64();
        (-2.0 * u1.ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos()
    }

    /// Exponential distribution: -ln(U) / lambda
    fn next_exponential(&mut self, lambda: f64) -> f64 {
        let u = self.next_f64().max(1e-15);
        -u.ln() / lambda.max(1e-15)
    }

    /// Gamma distribution via Marsaglia & Tsang's method.
    ///
    /// For shape >= 1, uses the standard rejection method.
    /// For shape < 1, uses the Gamma(shape+1) * U^(1/shape) trick.
    fn next_gamma(&mut self, shape: f64) -> f64 {
        if shape < 1e-15 {
            return 0.0;
        }

        if shape < 1.0 {
            // Use Gamma(1 + shape) * U^(1/shape)
            let g = self.next_gamma(shape + 1.0);
            let u = self.next_f64().max(1e-15);
            return g * u.powf(1.0 / shape);
        }

        // Marsaglia & Tsang's method for shape >= 1
        let d = shape - 1.0 / 3.0;
        let c = 1.0 / (9.0 * d).sqrt();

        loop {
            let x = self.next_gaussian();
            let v_base = 1.0 + c * x;
            if v_base <= 0.0 {
                continue;
            }
            let v = v_base * v_base * v_base;
            let u = self.next_f64().max(1e-15);

            // Check acceptance
            let x2 = x * x;
            if u < 1.0 - 0.0331 * x2 * x2 {
                return d * v;
            }
            if u.ln() < 0.5 * x2 + d * (1.0 - v + v.ln()) {
                return d * v;
            }
        }
    }

    /// Beta distribution: X / (X + Y) where X ~ Gamma(alpha), Y ~ Gamma(beta).
    fn next_beta(&mut self, alpha: f64, beta: f64) -> f64 {
        let x = self.next_gamma(alpha);
        let y = self.next_gamma(beta);
        let sum = x + y;
        if sum < 1e-15 {
            return 0.5;
        }
        (x / sum).clamp(0.0, 1.0)
    }

    /// Uniform in [lo, hi].
    fn next_uniform(&mut self, lo: f64, hi: f64) -> f64 {
        lo + self.next_f64() * (hi - lo)
    }

    /// Random integer in [0, n).
    fn next_usize(&mut self, n: usize) -> usize {
        if n == 0 {
            return 0;
        }
        (self.next_u64() % n as u64) as usize
    }
}

// ---------------------------------------------------------------------------
// Inner state
// ---------------------------------------------------------------------------

struct Inner {
    size_jitter: f64,
    aggression_alpha: f64,
    aggression_beta: f64,
    enabled: bool,
    venues: Vec<String>,
    entropy_history: Vec<f64>,
    plans_created: u64,
    rng: Rng,
}

// ---------------------------------------------------------------------------
// MetamorphicExecutor
// ---------------------------------------------------------------------------

/// Anti-fingerprint execution engine with 6 randomization layers.
///
/// Generates ExecutionPlans that slice a parent order into multiple child
/// orders with randomized size, timing, aggression, venue, and price offsets.
/// Optional decoy orders add noise to the execution footprint.
#[pyclass]
pub struct MetamorphicExecutor {
    inner: Mutex<Inner>,
}

fn now_secs() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}

fn gen_id(prefix: &str, len: usize) -> String {
    use std::hash::{Hash, Hasher};
    use std::collections::hash_map::DefaultHasher;
    let mut h = DefaultHasher::new();
    now_secs().to_bits().hash(&mut h);
    std::thread::current().id().hash(&mut h);
    let hex = format!("{:016x}", h.finish());
    format!("{}{}", prefix, &hex[..len.min(16)])
}

#[pymethods]
impl MetamorphicExecutor {
    #[new]
    #[pyo3(signature = (size_jitter=0.15, aggression_alpha=2.0, aggression_beta=5.0, enabled=true))]
    fn new(size_jitter: f64, aggression_alpha: f64, aggression_beta: f64, enabled: bool) -> Self {
        // Seed from current time for non-determinism across instances
        let seed = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;

        Self {
            inner: Mutex::new(Inner {
                size_jitter: size_jitter.clamp(0.0, 1.0),
                aggression_alpha: aggression_alpha.max(0.01),
                aggression_beta: aggression_beta.max(0.01),
                enabled,
                venues: vec!["default".to_string()],
                entropy_history: Vec::new(),
                plans_created: 0,
                rng: Rng::new(seed),
            }),
        }
    }

    /// Generate a metamorphic execution plan.
    ///
    /// Slices `total_size` into `n_slices` child orders, each with randomized
    /// size (uniform jitter), timing (exponential), aggression (beta),
    /// venue (round-robin), and price offset (Gaussian). Optionally adds
    /// 1-3 small decoy orders.
    #[pyo3(signature = (market_id, side, total_size, urgency=1.0, n_slices=0,
                        add_decoys=false, venues=None))]
    #[allow(clippy::too_many_arguments)]
    fn create_plan(
        &self,
        market_id: &str,
        side: &str,
        total_size: f64,
        urgency: f64,
        n_slices: usize,
        add_decoys: bool,
        venues: Option<Vec<String>>,
    ) -> ExecutionPlan {
        let mut inner = self.inner.lock().unwrap();

        // Use provided venues or fall back to stored
        let venue_list: Vec<String> = venues.unwrap_or_else(|| inner.venues.clone());
        let venue_count = venue_list.len().max(1);

        // Auto-select n_slices if 0
        let n = if n_slices == 0 {
            ((total_size / 100.0).ceil() as usize).clamp(2, 20)
        } else {
            n_slices.clamp(1, 100)
        };

        let base_size = total_size / n as f64;
        let urgency_clamped = urgency.max(0.01);

        let mut slices = Vec::with_capacity(n + 3); // +3 for possible decoys

        if inner.enabled {
            // Copy parameters to avoid borrow conflicts with inner.rng
            let jitter_range = inner.size_jitter;
            let agg_alpha = inner.aggression_alpha;
            let agg_beta = inner.aggression_beta;

            // --- Randomized slicing ---
            let mut raw_sizes = Vec::with_capacity(n);
            for _ in 0..n {
                let jitter = inner.rng.next_uniform(
                    1.0 - jitter_range,
                    1.0 + jitter_range,
                );
                raw_sizes.push(base_size * jitter);
            }

            // Normalize sizes to sum to total_size
            let raw_sum: f64 = raw_sizes.iter().sum();
            if raw_sum > 1e-15 {
                for s in &mut raw_sizes {
                    *s = *s / raw_sum * total_size;
                }
            }

            for (i, &size) in raw_sizes.iter().enumerate() {
                let delay = inner.rng.next_exponential(urgency_clamped);
                let aggression = inner.rng.next_beta(agg_alpha, agg_beta);
                let venue = venue_list[i % venue_count].clone();
                let price_offset = inner.rng.next_gaussian() * 0.001;

                slices.push(ExecutionSlice {
                    slice_id: gen_id("sl-", 8),
                    size,
                    delay_seconds: delay,
                    aggression,
                    venue,
                    price_offset,
                    is_decoy: false,
                });
            }

            // Add decoy orders
            if add_decoys {
                let n_decoys = (inner.rng.next_usize(3) + 1).min(3); // 1-3 decoys
                for _ in 0..n_decoys {
                    let decoy_size = total_size * inner.rng.next_uniform(0.01, 0.05);
                    let delay = inner.rng.next_exponential(urgency_clamped * 0.5);
                    let aggression = inner.rng.next_beta(agg_alpha, agg_beta);
                    let venue_idx = inner.rng.next_usize(venue_count);
                    let venue = venue_list[venue_idx].clone();
                    let price_offset = inner.rng.next_gaussian() * 0.002;

                    slices.push(ExecutionSlice {
                        slice_id: gen_id("sl-", 8),
                        size: decoy_size,
                        delay_seconds: delay,
                        aggression,
                        venue,
                        price_offset,
                        is_decoy: true,
                    });
                }
            }
        } else {
            // Disabled: uniform slicing, no randomization
            for i in 0..n {
                slices.push(ExecutionSlice {
                    slice_id: gen_id("sl-", 8),
                    size: total_size / n as f64,
                    delay_seconds: 0.0,
                    aggression: 0.5,
                    venue: venue_list[i % venue_count].clone(),
                    price_offset: 0.0,
                    is_decoy: false,
                });
            }
        }

        // Track entropy of this plan
        let entropy = self.compute_plan_entropy(&slices);
        inner.entropy_history.push(entropy);
        if inner.entropy_history.len() > 1000 {
            inner.entropy_history.remove(0);
        }
        inner.plans_created += 1;

        ExecutionPlan {
            plan_id: gen_id("ep-", 8),
            market_id: market_id.to_string(),
            side: side.to_string(),
            total_size,
            urgency,
            slices,
        }
    }

    /// Shannon entropy of recent execution patterns.
    ///
    /// Bins the entropy_history values and computes H = -sum(p * log2(p)).
    /// Higher entropy means more unpredictable execution.
    fn behavioral_entropy(&self) -> f64 {
        let inner = self.inner.lock().unwrap();
        if inner.entropy_history.len() < 2 {
            return 0.0;
        }
        self.compute_shannon_entropy(&inner.entropy_history)
    }

    /// Multiply the size jitter by a factor (increase randomization).
    fn increase_randomization(&self, factor: f64) {
        let mut inner = self.inner.lock().unwrap();
        inner.size_jitter = (inner.size_jitter * factor.abs()).clamp(0.0, 1.0);
    }

    /// Divide the size jitter by a factor (decrease randomization).
    fn decrease_randomization(&self, factor: f64) {
        let mut inner = self.inner.lock().unwrap();
        let divisor = factor.abs().max(1e-15);
        inner.size_jitter = (inner.size_jitter / divisor).clamp(0.0, 1.0);
    }

    /// Set the venue list for round-robin assignment.
    fn set_venues(&self, venues: Vec<String>) {
        let mut inner = self.inner.lock().unwrap();
        if !venues.is_empty() {
            inner.venues = venues;
        }
    }

    /// Return executor status as a dict of numeric metrics.
    fn status(&self) -> HashMap<String, f64> {
        let inner = self.inner.lock().unwrap();
        let mut m = HashMap::new();
        m.insert("size_jitter".into(), inner.size_jitter);
        m.insert("aggression_alpha".into(), inner.aggression_alpha);
        m.insert("aggression_beta".into(), inner.aggression_beta);
        m.insert("enabled".into(), if inner.enabled { 1.0 } else { 0.0 });
        m.insert("venues_count".into(), inner.venues.len() as f64);
        m.insert("plans_created".into(), inner.plans_created as f64);
        m.insert(
            "entropy".into(),
            if inner.entropy_history.len() < 2 {
                0.0
            } else {
                self.compute_shannon_entropy(&inner.entropy_history)
            },
        );
        m.insert(
            "entropy_history_len".into(),
            inner.entropy_history.len() as f64,
        );
        m
    }
}

// ---------------------------------------------------------------------------
// Internal helpers (not exposed to Python)
// ---------------------------------------------------------------------------

impl MetamorphicExecutor {
    /// Compute a scalar entropy measure for a single plan based on size variance.
    fn compute_plan_entropy(&self, slices: &[ExecutionSlice]) -> f64 {
        let real_slices: Vec<&ExecutionSlice> =
            slices.iter().filter(|s| !s.is_decoy).collect();
        if real_slices.len() < 2 {
            return 0.0;
        }

        let total: f64 = real_slices.iter().map(|s| s.size).sum();
        if total < 1e-15 {
            return 0.0;
        }

        // Shannon entropy of the size distribution
        let mut entropy = 0.0;
        for s in &real_slices {
            let p = s.size / total;
            if p > 1e-15 {
                entropy -= p * p.log2();
            }
        }
        entropy
    }

    /// Shannon entropy of a series of continuous values (binned into 10 buckets).
    fn compute_shannon_entropy(&self, values: &[f64]) -> f64 {
        if values.is_empty() {
            return 0.0;
        }

        let n_bins = 10usize;
        let min_val = values.iter().copied().fold(f64::INFINITY, f64::min);
        let max_val = values.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let range = max_val - min_val;

        if range < 1e-15 {
            return 0.0;
        }

        let mut bins = vec![0usize; n_bins];
        for &v in values {
            let idx = ((v - min_val) / range * (n_bins as f64 - 1.0)).round() as usize;
            bins[idx.min(n_bins - 1)] += 1;
        }

        let total = values.len() as f64;
        let mut entropy = 0.0;
        for &count in &bins {
            if count > 0 {
                let p = count as f64 / total;
                entropy -= p * p.log2();
            }
        }
        entropy
    }
}
