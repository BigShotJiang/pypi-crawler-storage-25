//! Hive — Autonomous swarm intelligence system.
//!
//! Compiled Rust core for IP protection and performance.
//! All proprietary algorithms (pheromone fields, evolutionary engines,
//! behavioral cloning, causal discovery, etc.) live here as opaque binaries.
//! Python layer is thin wrappers only.

pub mod types;
pub mod pheromone;
pub mod reputation;
pub mod consensus;
pub mod criticality;
pub mod impact;
pub mod imprint;
pub mod causal;
pub mod map_elites;
pub mod metamorphic;
pub mod autonomy;
pub mod kill_chain;
pub mod factory;
pub mod coordinator;

use pyo3::prelude::*;

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // --- Enums ---
    m.add_class::<types::AutonomyMode>()?;
    m.add_class::<types::AgentLifecycle>()?;
    m.add_class::<types::SpawnSource>()?;
    m.add_class::<types::PheromoneChannel>()?;
    m.add_class::<types::Severity>()?;
    m.add_class::<types::StrategyArchetype>()?;
    m.add_class::<types::DecisionType>()?;
    m.add_class::<types::HiveEventType>()?;

    // --- Data types ---
    m.add_class::<types::ChannelConfig>()?;
    m.add_class::<types::MarketPheromones>()?;
    m.add_class::<types::HiveConfig>()?;
    m.add_class::<types::StrategyGenome>()?;
    m.add_class::<types::HiveAgent>()?;
    m.add_class::<types::CriticalityReport>()?;
    m.add_class::<types::HiveDecision>()?;
    m.add_class::<types::ConsensusView>()?;
    m.add_class::<types::InternalMarket>()?;
    m.add_class::<types::ImprintAction>()?;
    m.add_class::<types::Incident>()?;
    m.add_class::<types::SwarmStatus>()?;
    m.add_class::<types::ExecutionSlice>()?;
    m.add_class::<types::ExecutionPlan>()?;
    m.add_class::<types::CausalEdge>()?;
    m.add_class::<types::CausalGraph>()?;

    // --- Subsystem classes ---
    m.add_class::<pheromone::PheromoneField>()?;
    m.add_class::<reputation::ReputationSystem>()?;
    m.add_class::<consensus::ConsensusEngine>()?;
    m.add_class::<criticality::CriticalityMonitor>()?;
    m.add_class::<impact::SelfImpactModel>()?;
    m.add_class::<imprint::ImprintSystem>()?;
    m.add_class::<causal::CausalEngine>()?;
    m.add_class::<map_elites::MAPElitesArchive>()?;
    m.add_class::<metamorphic::MetamorphicExecutor>()?;
    m.add_class::<autonomy::AutonomyController>()?;
    m.add_class::<kill_chain::KillChain>()?;
    m.add_class::<factory::AgentFactory>()?;
    m.add_class::<coordinator::SwarmCoordinator>()?;

    Ok(())
}
