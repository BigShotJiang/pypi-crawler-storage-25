//! KillChain — 6-phase automated incident response.
//!
//! Phases: Detect -> Contain -> Preserve -> Diagnose -> Remediate -> Learn.
//! SEV1/SEV2 incidents trigger full remediation; SEV3/SEV4 are contained and
//! logged but not auto-remediated.  Python callbacks are invoked at each phase.

use pyo3::prelude::*;
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

use super::types::{Incident, Severity};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn now_secs() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs_f64()
}

const HISTORY_CAP: usize = 500;

// ---------------------------------------------------------------------------
// Inner state
// ---------------------------------------------------------------------------

#[derive(Debug)]
struct Callbacks {
    on_contain: Option<PyObject>,
    on_preserve: Option<PyObject>,
    on_diagnose: Option<PyObject>,
    on_remediate: Option<PyObject>,
    on_learn: Option<PyObject>,
}

impl Callbacks {
    fn new() -> Self {
        Self {
            on_contain: None,
            on_preserve: None,
            on_diagnose: None,
            on_remediate: None,
            on_learn: None,
        }
    }
}

struct Inner {
    active: HashMap<String, Incident>,
    history: VecDeque<Incident>,
    blacklisted_genomes: HashSet<String>,
    callbacks: Callbacks,
}

impl Inner {
    fn new() -> Self {
        Self {
            active: HashMap::new(),
            history: VecDeque::new(),
            blacklisted_genomes: HashSet::new(),
            callbacks: Callbacks::new(),
        }
    }

    fn archive(&mut self, incident: Incident) {
        if self.history.len() >= HISTORY_CAP {
            self.history.pop_front();
        }
        self.history.push_back(incident);
    }
}

// ---------------------------------------------------------------------------
// KillChain
// ---------------------------------------------------------------------------

/// Six-phase automated incident response pipeline.
///
/// Detect -> Contain -> Preserve -> Diagnose -> Remediate -> Learn.
/// Python callbacks are invoked at each phase to allow orchestration-layer
/// actions (pause agents, snapshot state, notify, etc.).
#[pyclass]
pub struct KillChain {
    inner: Mutex<Inner>,
}

/// Call a Python callback with the incident, swallowing any Python errors.
fn call_callback(cb: &Option<PyObject>, incident: &Incident) {
    if let Some(ref callback) = cb {
        Python::with_gil(|py| {
            if let Err(e) = callback.call1(py, (incident.clone(),)) {
                tracing::warn!("KillChain callback error: {}", e);
            }
        });
    }
}

#[pymethods]
impl KillChain {
    #[new]
    fn new() -> Self {
        Self {
            inner: Mutex::new(Inner::new()),
        }
    }

    /// Register a callback for the Contain phase.
    fn on_contain(&self, callback: PyObject) {
        let mut inner = self.inner.lock().unwrap();
        inner.callbacks.on_contain = Some(callback);
    }

    /// Register a callback for the Preserve phase.
    fn on_preserve(&self, callback: PyObject) {
        let mut inner = self.inner.lock().unwrap();
        inner.callbacks.on_preserve = Some(callback);
    }

    /// Register a callback for the Diagnose phase.
    fn on_diagnose(&self, callback: PyObject) {
        let mut inner = self.inner.lock().unwrap();
        inner.callbacks.on_diagnose = Some(callback);
    }

    /// Register a callback for the Remediate phase.
    fn on_remediate(&self, callback: PyObject) {
        let mut inner = self.inner.lock().unwrap();
        inner.callbacks.on_remediate = Some(callback);
    }

    /// Register a callback for the Learn phase.
    fn on_learn(&self, callback: PyObject) {
        let mut inner = self.inner.lock().unwrap();
        inner.callbacks.on_learn = Some(callback);
    }

    /// Trigger the 6-phase kill chain for a new incident.
    ///
    /// 1. **Detect**: create incident record
    /// 2. **Contain**: invoke on_contain callback
    /// 3. **Preserve**: invoke on_preserve callback
    /// 4. **Diagnose**: invoke on_diagnose callback
    /// 5. **Remediate** (SEV1/SEV2 only): invoke on_remediate callback
    /// 6. **Learn**: invoke on_learn callback, resolve incident
    fn trigger(
        &self,
        severity: Severity,
        trigger: &str,
        affected_agents: Vec<String>,
        pnl_impact: f64,
    ) -> Incident {
        // Phase 1: Detect — create the incident.
        let mut incident = Incident::create(severity, trigger.to_string(), affected_agents, pnl_impact);
        incident.state = "detected".into();

        // We need to extract callbacks while holding the lock, then release
        // the lock before calling Python (to avoid deadlock if callbacks
        // re-enter).  PyObject requires GIL for cloning in PyO3 0.22.
        let (cb_contain, cb_preserve, cb_diagnose, cb_remediate, cb_learn) =
            Python::with_gil(|py| {
                let inner = self.inner.lock().unwrap();
                (
                    inner.callbacks.on_contain.as_ref().map(|c| c.clone_ref(py)),
                    inner.callbacks.on_preserve.as_ref().map(|c| c.clone_ref(py)),
                    inner.callbacks.on_diagnose.as_ref().map(|c| c.clone_ref(py)),
                    inner.callbacks.on_remediate.as_ref().map(|c| c.clone_ref(py)),
                    inner.callbacks.on_learn.as_ref().map(|c| c.clone_ref(py)),
                )
            });

        // Phase 2: Contain.
        incident.state = "contained".into();
        call_callback(&cb_contain, &incident);

        // Phase 3: Preserve.
        incident.state = "preserved".into();
        call_callback(&cb_preserve, &incident);

        // Phase 4: Diagnose.
        incident.state = "diagnosed".into();
        call_callback(&cb_diagnose, &incident);

        // Phase 5: Remediate (SEV1/SEV2 only).
        let is_severe = matches!(severity, Severity::Sev1Critical | Severity::Sev2High);
        if is_severe {
            incident.state = "remediated".into();
            call_callback(&cb_remediate, &incident);
        }

        // Phase 6: Learn.
        incident.state = "resolved".into();
        incident.resolved_at = Some(now_secs());
        call_callback(&cb_learn, &incident);

        // Store in active (briefly) then archive to history.
        let mut inner = self.inner.lock().unwrap();
        inner.archive(incident.clone());

        incident
    }

    /// Add a genome to the blacklist (will not be spawned again).
    fn blacklist_genome(&self, genome_id: &str) {
        let mut inner = self.inner.lock().unwrap();
        inner.blacklisted_genomes.insert(genome_id.to_string());
    }

    /// Check if a genome is blacklisted.
    fn is_blacklisted(&self, genome_id: &str) -> bool {
        let inner = self.inner.lock().unwrap();
        inner.blacklisted_genomes.contains(genome_id)
    }

    /// All currently active (unresolved) incidents.
    fn active_incidents(&self) -> Vec<Incident> {
        let inner = self.inner.lock().unwrap();
        inner.active.values().cloned().collect()
    }

    /// Recent incident history (most recent first), limited to `limit` entries.
    fn incident_history(&self, limit: usize) -> Vec<Incident> {
        let inner = self.inner.lock().unwrap();
        inner
            .history
            .iter()
            .rev()
            .take(limit)
            .cloned()
            .collect()
    }

    /// Count of SEV1/SEV2 incidents in the last `days` days.
    fn critical_count(&self, days: u32) -> usize {
        let cutoff = now_secs() - (days as f64 * 86400.0);
        let inner = self.inner.lock().unwrap();
        inner
            .history
            .iter()
            .filter(|i| {
                i.created_at >= cutoff
                    && matches!(i.severity, Severity::Sev1Critical | Severity::Sev2High)
            })
            .count()
    }

    /// Status snapshot.
    fn status(&self) -> HashMap<String, PyObject> {
        let inner = self.inner.lock().unwrap();

        let active_count = inner.active.len();
        let resolved_count = inner.history.len();
        let blacklisted_count = inner.blacklisted_genomes.len();
        let callbacks_registered = [
            inner.callbacks.on_contain.is_some(),
            inner.callbacks.on_preserve.is_some(),
            inner.callbacks.on_diagnose.is_some(),
            inner.callbacks.on_remediate.is_some(),
            inner.callbacks.on_learn.is_some(),
        ]
        .iter()
        .filter(|&&b| b)
        .count();

        Python::with_gil(|py| {
            let mut m = HashMap::new();
            m.insert(
                "active_count".into(),
                active_count.to_object(py),
            );
            m.insert(
                "resolved_count".into(),
                resolved_count.to_object(py),
            );
            m.insert(
                "blacklisted_count".into(),
                blacklisted_count.to_object(py),
            );
            m.insert(
                "callbacks_registered".into(),
                callbacks_registered.to_object(py),
            );
            m
        })
    }
}
