//! ImprintSystem — Behavioral cloning MLP + MaxEnt IRL.
//!
//! Learns operator behavior from recorded actions using a 3-layer MLP
//! (16 -> 64 -> 32 -> 9 actions). Provides DAgger-style correction
//! ingestion and prediction-with-confidence for the autonomy controller.
//!
//! PRNG uses LCG from evolution.rs pattern for deterministic weight init.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;

use super::types::ImprintAction;

// ---------------------------------------------------------------------------
// PRNG (deterministic LCG, same as evolution.rs)
// ---------------------------------------------------------------------------

struct Rng {
    state: u64,
}

impl Rng {
    fn new(seed: u64) -> Self {
        Self { state: seed.wrapping_add(1) }
    }

    fn next_u64(&mut self) -> u64 {
        self.state = self.state
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        self.state
    }

    fn next_f64(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 / (1u64 << 53) as f64
    }

    fn next_gaussian(&mut self) -> f64 {
        let u1 = self.next_f64().max(1e-15);
        let u2 = self.next_f64();
        (-2.0 * u1.ln()).sqrt() * (2.0 * std::f64::consts::PI * u2).cos()
    }
}

// ---------------------------------------------------------------------------
// Action constants
// ---------------------------------------------------------------------------

const NUM_ACTIONS: usize = 9;

const ACTION_NAMES: [&str; NUM_ACTIONS] = [
    "spawn", "kill", "pause", "resume", "scale",
    "approve", "reject", "evolve", "observe",
];

fn action_index(name: &str) -> Option<usize> {
    ACTION_NAMES.iter().position(|&a| a == name)
}

// ---------------------------------------------------------------------------
// Feature extraction (16 features from ImprintAction)
// ---------------------------------------------------------------------------

const NUM_FEATURES: usize = 16;

fn extract_features(action: &ImprintAction) -> [f64; NUM_FEATURES] {
    let mut f = [0.0f64; NUM_FEATURES];

    // Regime one-hot (3): trending=0, mean_reverting=1, other=2
    match action.regime.as_str() {
        "trending" | "trend" => f[0] = 1.0,
        "mean_reverting" | "mean_reversion" | "mr" => f[1] = 1.0,
        _ => f[2] = 1.0,
    }

    // Volatility (1)
    f[3] = action.volatility;

    // PnL (1)
    f[4] = action.pnl;

    // Time of day normalized to [0, 1] (1)
    f[5] = (action.time_of_day / 86400.0).clamp(0.0, 1.0);

    // Day of week one-hot (7)
    let dow = (action.day_of_week as usize).min(6);
    f[6 + dow] = 1.0;

    // Number of positions indicator (1): >0 if feed_snapshots has entries
    f[13] = if action.feed_snapshots.is_empty() { 0.0 } else { 1.0 };

    // Position PnL (1): use pnl again as proxy (direct from action)
    f[14] = action.pnl;

    // Has feed data indicator (1)
    f[15] = if action.feed_snapshots.is_empty() { 0.0 } else { 1.0 };

    f
}

// ---------------------------------------------------------------------------
// MLP layer
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct Layer {
    weights: Vec<Vec<f64>>, // [out_dim][in_dim]
    biases: Vec<f64>,       // [out_dim]
}

impl Layer {
    /// Xavier/He initialization using LCG PRNG.
    fn new(in_dim: usize, out_dim: usize, rng: &mut Rng, he: bool) -> Self {
        let std_dev = if he {
            // He init: sqrt(2 / fan_in)
            (2.0 / in_dim as f64).sqrt()
        } else {
            // Xavier init: sqrt(2 / (fan_in + fan_out))
            (2.0 / (in_dim + out_dim) as f64).sqrt()
        };

        let weights = (0..out_dim)
            .map(|_| {
                (0..in_dim)
                    .map(|_| rng.next_gaussian() * std_dev)
                    .collect()
            })
            .collect();

        let biases = vec![0.0; out_dim];

        Layer { weights, biases }
    }

    /// Forward: y = W * x + b
    fn forward(&self, input: &[f64]) -> Vec<f64> {
        self.weights
            .iter()
            .zip(self.biases.iter())
            .map(|(w_row, &b)| {
                let dot: f64 = w_row.iter().zip(input.iter()).map(|(w, x)| w * x).sum();
                dot + b
            })
            .collect()
    }
}

// ---------------------------------------------------------------------------
// MLP
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct MLP {
    l1: Layer, // 16 -> 64
    l2: Layer, // 64 -> 32
    l3: Layer, // 32 -> NUM_ACTIONS
    trained: bool,
}

impl MLP {
    fn new(rng: &mut Rng) -> Self {
        // He init for ReLU hidden layers, Xavier for output
        let l1 = Layer::new(NUM_FEATURES, 64, rng, true);
        let l2 = Layer::new(64, 32, rng, true);
        let l3 = Layer::new(32, NUM_ACTIONS, rng, false);
        MLP { l1, l2, l3, trained: false }
    }

    /// Forward pass: relu -> relu -> softmax.
    fn forward(&self, input: &[f64; NUM_FEATURES]) -> Vec<f64> {
        let h1 = relu_vec(&self.l1.forward(input));
        let h2 = relu_vec(&self.l2.forward(&h1));
        let logits = self.l3.forward(&h2);
        softmax(&logits)
    }

    /// Full forward pass returning intermediates for backprop.
    fn forward_full(&self, input: &[f64; NUM_FEATURES]) -> (Vec<f64>, Vec<f64>, Vec<f64>, Vec<f64>) {
        let z1 = self.l1.forward(input);
        let h1 = relu_vec(&z1);
        let z2 = self.l2.forward(&h1);
        let h2 = relu_vec(&z2);
        let logits = self.l3.forward(&h2);
        let probs = softmax(&logits);
        (h1, h2, logits, probs)
    }

    /// Train one step with cross-entropy loss + SGD.
    /// Returns the loss for this sample.
    fn train_step(&mut self, input: &[f64; NUM_FEATURES], target: usize, lr: f64) -> f64 {
        let (h1, h2, _logits, probs) = self.forward_full(input);

        // Cross-entropy loss
        let loss = -(probs[target].max(1e-15)).ln();

        // Gradient of cross-entropy + softmax: d_logits[i] = probs[i] - target[i]
        let mut d_logits = probs.clone();
        d_logits[target] -= 1.0;

        // Backprop through L3: d_logits -> dW3, db3, dh2
        let mut dw3 = vec![vec![0.0; 32]; NUM_ACTIONS];
        let mut db3 = vec![0.0; NUM_ACTIONS];
        let mut dh2 = vec![0.0; 32];

        for i in 0..NUM_ACTIONS {
            db3[i] = d_logits[i];
            for j in 0..32 {
                dw3[i][j] = d_logits[i] * h2[j];
                dh2[j] += self.l3.weights[i][j] * d_logits[i];
            }
        }

        // ReLU gradient for h2
        let z2 = self.l2.forward(&h1);
        let dz2: Vec<f64> = dh2.iter().zip(z2.iter()).map(|(&d, &z)| if z > 0.0 { d } else { 0.0 }).collect();

        // Backprop through L2
        let mut dw2 = vec![vec![0.0; 64]; 32];
        let mut db2 = vec![0.0; 32];
        let mut dh1 = vec![0.0; 64];

        for i in 0..32 {
            db2[i] = dz2[i];
            for j in 0..64 {
                dw2[i][j] = dz2[i] * h1[j];
                dh1[j] += self.l2.weights[i][j] * dz2[i];
            }
        }

        // ReLU gradient for h1
        let z1 = self.l1.forward(input);
        let dz1: Vec<f64> = dh1.iter().zip(z1.iter()).map(|(&d, &z)| if z > 0.0 { d } else { 0.0 }).collect();

        // Backprop through L1
        let mut dw1 = vec![vec![0.0; NUM_FEATURES]; 64];
        let mut db1 = vec![0.0; 64];

        for i in 0..64 {
            db1[i] = dz1[i];
            for j in 0..NUM_FEATURES {
                dw1[i][j] = dz1[i] * input[j];
            }
        }

        // SGD update
        for i in 0..NUM_ACTIONS {
            self.l3.biases[i] -= lr * db3[i];
            for j in 0..32 {
                self.l3.weights[i][j] -= lr * dw3[i][j];
            }
        }
        for i in 0..32 {
            self.l2.biases[i] -= lr * db2[i];
            for j in 0..64 {
                self.l2.weights[i][j] -= lr * dw2[i][j];
            }
        }
        for i in 0..64 {
            self.l1.biases[i] -= lr * db1[i];
            for j in 0..NUM_FEATURES {
                self.l1.weights[i][j] -= lr * dw1[i][j];
            }
        }

        loss
    }
}

fn relu_vec(v: &[f64]) -> Vec<f64> {
    v.iter().map(|&x| x.max(0.0)).collect()
}

fn softmax(logits: &[f64]) -> Vec<f64> {
    let max_l = logits.iter().copied().fold(f64::NEG_INFINITY, f64::max);
    let exps: Vec<f64> = logits.iter().map(|&l| (l - max_l).exp()).collect();
    let sum: f64 = exps.iter().sum();
    if sum < 1e-30 {
        vec![1.0 / logits.len() as f64; logits.len()]
    } else {
        exps.iter().map(|&e| e / sum).collect()
    }
}

// ---------------------------------------------------------------------------
// Correction record (for DAgger)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct CorrectionRecord {
    features: [f64; NUM_FEATURES],
    correct_action: usize,
}

// ---------------------------------------------------------------------------
// Inner state
// ---------------------------------------------------------------------------

struct Inner {
    enabled: bool,
    min_actions: usize,
    mlp: MLP,
    action_buffer: Vec<(ImprintAction, usize)>, // (action, action_index)
    correction_buffer: Vec<CorrectionRecord>,
    total_observed: u64,
    total_trained: u64,
    train_epochs: u32,
    rng: Rng,
}

// ---------------------------------------------------------------------------
// ImprintSystem
// ---------------------------------------------------------------------------

#[pyclass]
pub struct ImprintSystem {
    inner: Mutex<Inner>,
}

#[pymethods]
impl ImprintSystem {
    #[new]
    #[pyo3(signature = (enabled=true, min_actions=100))]
    fn new(enabled: bool, min_actions: usize) -> Self {
        let seed = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;
        let mut rng = Rng::new(seed);
        let mlp = MLP::new(&mut rng);

        Self {
            inner: Mutex::new(Inner {
                enabled,
                min_actions,
                mlp,
                action_buffer: Vec::new(),
                correction_buffer: Vec::new(),
                total_observed: 0,
                total_trained: 0,
                train_epochs: 0,
                rng,
            }),
        }
    }

    /// Record an operator action for training.
    fn observe(&self, action: &ImprintAction) {
        let mut state = self.inner.lock().unwrap();
        if !state.enabled { return; }

        if let Some(idx) = action_index(&action.action_type) {
            state.action_buffer.push((action.clone(), idx));
            state.total_observed += 1;

            // Cap buffer at 50_000
            let blen = state.action_buffer.len();
            if blen > 50_000 {
                state.action_buffer.drain(..blen - 50_000);
            }
        }
    }

    /// Train the MLP on recorded actions. Returns training stats.
    /// If force=false, requires at least min_actions observations.
    #[pyo3(signature = (force=false))]
    fn train(&self, force: bool) -> HashMap<String, f64> {
        let mut state = self.inner.lock().unwrap();
        let mut stats = HashMap::new();

        let n = state.action_buffer.len() + state.correction_buffer.len();
        stats.insert("total_samples".into(), n as f64);

        if !state.enabled {
            stats.insert("trained".into(), 0.0);
            stats.insert("reason".into(), -1.0); // disabled
            return stats;
        }

        if !force && state.action_buffer.len() < state.min_actions {
            stats.insert("trained".into(), 0.0);
            stats.insert("reason".into(), -2.0); // insufficient data
            return stats;
        }

        if state.action_buffer.is_empty() && state.correction_buffer.is_empty() {
            stats.insert("trained".into(), 0.0);
            stats.insert("reason".into(), -3.0); // no data
            return stats;
        }

        // Build training set: features + targets
        let mut training_data: Vec<([f64; NUM_FEATURES], usize)> = Vec::new();

        for (action, idx) in &state.action_buffer {
            training_data.push((extract_features(action), *idx));
        }

        // Corrections are weighted 3x (DAgger importance)
        for correction in &state.correction_buffer {
            for _ in 0..3 {
                training_data.push((correction.features, correction.correct_action));
            }
        }

        let n_samples = training_data.len();
        let lr = 0.001;
        let epochs = 10u32;
        let mut total_loss = 0.0;
        let mut final_epoch_loss = 0.0;

        for epoch in 0..epochs {
            // Shuffle using LCG
            for i in (1..training_data.len()).rev() {
                let j = (state.rng.next_u64() as usize) % (i + 1);
                training_data.swap(i, j);
            }

            let mut epoch_loss = 0.0;
            for (features, target) in &training_data {
                let loss = state.mlp.train_step(features, *target, lr);
                epoch_loss += loss;
            }
            epoch_loss /= n_samples as f64;
            total_loss += epoch_loss;

            if epoch == epochs - 1 {
                final_epoch_loss = epoch_loss;
            }
        }

        state.mlp.trained = true;
        state.total_trained += n_samples as u64;
        state.train_epochs += epochs;

        stats.insert("trained".into(), 1.0);
        stats.insert("epochs".into(), epochs as f64);
        stats.insert("samples".into(), n_samples as f64);
        stats.insert("avg_loss".into(), total_loss / epochs as f64);
        stats.insert("final_loss".into(), final_epoch_loss);
        stats.insert("total_trained".into(), state.total_trained as f64);
        stats.insert("train_epochs".into(), state.train_epochs as f64);
        stats
    }

    /// Predict the most likely action given the current context.
    /// Returns (action_name, confidence).
    fn predict_action(&self, action: &ImprintAction) -> (String, f64) {
        let state = self.inner.lock().unwrap();
        if !state.enabled || !state.mlp.trained {
            return ("observe".to_string(), 0.0);
        }

        let features = extract_features(action);
        let probs = state.mlp.forward(&features);

        let (best_idx, best_prob) = probs
            .iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal))
            .unwrap_or((NUM_ACTIONS - 1, &0.0));

        (ACTION_NAMES[best_idx].to_string(), *best_prob)
    }

    /// Suggest an action if model confidence exceeds 0.7.
    /// Returns None if confidence is too low or model is untrained.
    fn suggest(&self, action: &ImprintAction) -> Option<HashMap<String, String>> {
        let state = self.inner.lock().unwrap();
        if !state.enabled || !state.mlp.trained {
            return None;
        }

        let features = extract_features(action);
        let probs = state.mlp.forward(&features);

        let (best_idx, best_prob) = probs
            .iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal))
            .unwrap_or((NUM_ACTIONS - 1, &0.0));

        if *best_prob < 0.7 {
            return None;
        }

        let mut suggestion = HashMap::new();
        suggestion.insert("action".into(), ACTION_NAMES[best_idx].to_string());
        suggestion.insert("confidence".into(), format!("{:.4}", best_prob));
        suggestion.insert("regime".into(), action.regime.clone());

        // Include top-3 actions with probabilities
        let mut indexed: Vec<(usize, f64)> = probs.iter().enumerate().map(|(i, &p)| (i, p)).collect();
        indexed.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        for (rank, &(idx, prob)) in indexed.iter().take(3).enumerate() {
            suggestion.insert(
                format!("alt_{}", rank + 1),
                format!("{}:{:.4}", ACTION_NAMES[idx], prob),
            );
        }

        Some(suggestion)
    }

    /// Record a DAgger-style correction: what the operator *should* have done.
    fn record_correction(&self, action: &ImprintAction, correct_action: &str) {
        let mut state = self.inner.lock().unwrap();
        if !state.enabled { return; }

        if let Some(idx) = action_index(correct_action) {
            let features = extract_features(action);
            state.correction_buffer.push(CorrectionRecord {
                features,
                correct_action: idx,
            });

            // Cap corrections at 10_000
            let clen = state.correction_buffer.len();
            if clen > 10_000 {
                state.correction_buffer.drain(..clen - 10_000);
            }
        }
    }

    /// Return system status.
    fn status(&self) -> HashMap<String, PyObject> {
        let state = self.inner.lock().unwrap();
        Python::with_gil(|py| {
            let mut m = HashMap::new();
            m.insert(
                "enabled".into(),
                state.enabled.to_object(py),
            );
            m.insert(
                "actions_observed".into(),
                state.total_observed.to_object(py),
            );
            m.insert(
                "action_buffer_size".into(),
                state.action_buffer.len().to_object(py),
            );
            m.insert(
                "correction_buffer_size".into(),
                state.correction_buffer.len().to_object(py),
            );
            m.insert(
                "model_trained".into(),
                state.mlp.trained.to_object(py),
            );
            m.insert(
                "total_trained".into(),
                state.total_trained.to_object(py),
            );
            m.insert(
                "train_epochs".into(),
                state.train_epochs.to_object(py),
            );
            m.insert(
                "min_actions".into(),
                state.min_actions.to_object(py),
            );

            // Action distribution in buffer
            let mut dist = vec![0u64; NUM_ACTIONS];
            for (_, idx) in &state.action_buffer {
                dist[*idx] += 1;
            }
            let dist_map: HashMap<String, u64> = ACTION_NAMES
                .iter()
                .enumerate()
                .map(|(i, &name)| (name.to_string(), dist[i]))
                .collect();
            m.insert(
                "action_distribution".into(),
                dist_map.to_object(py),
            );

            m
        })
    }
}

