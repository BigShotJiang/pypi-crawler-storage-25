//! Causal discovery engine — Granger causality, transfer entropy, lead-lag.
//!
//! Discovers directed causal relationships between markets from return series.
//! Used by the Hive coordinator to route pheromone diffusion, detect regime
//! breaks, and surface lead-lag alpha opportunities.

use pyo3::prelude::*;
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::Mutex;

use super::types::{CausalEdge, CausalGraph};

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const MAX_PRICE_BUF: usize = 500;
const MAX_RETURN_BUF: usize = 499; // MAX_PRICE_BUF - 1
const DEFAULT_LAG_ORDER: usize = 5;
const CROSS_CORR_MAX_LAG: i32 = 20;
const TE_NUM_BINS: usize = 3;

// ---------------------------------------------------------------------------
// Inner state
// ---------------------------------------------------------------------------

struct Inner {
    price_buffers: HashMap<String, VecDeque<f64>>,
    return_buffers: HashMap<String, VecDeque<f64>>,
    graph: Option<CausalGraph>,
    prev_graph: Option<CausalGraph>,
}

impl Inner {
    fn new() -> Self {
        Self {
            price_buffers: HashMap::new(),
            return_buffers: HashMap::new(),
            graph: None,
            prev_graph: None,
        }
    }
}

// ---------------------------------------------------------------------------
// Linear algebra helpers (no external deps)
// ---------------------------------------------------------------------------

/// Solve normal equations: beta = (X'X)^{-1} X'y via Cholesky-like approach.
/// X is (n x p), y is (n x 1). Returns (p x 1) coefficients and RSS.
fn ols_rss(x: &[Vec<f64>], y: &[f64]) -> (Vec<f64>, f64) {
    let n = y.len();
    if n == 0 || x.is_empty() || x[0].is_empty() {
        return (vec![], 0.0);
    }
    let p = x[0].len();

    // Build X'X (p x p) and X'y (p x 1)
    let mut xtx = vec![vec![0.0f64; p]; p];
    let mut xty = vec![0.0f64; p];

    for i in 0..n {
        for j in 0..p {
            xty[j] += x[i][j] * y[i];
            for k in j..p {
                let v = x[i][j] * x[i][k];
                xtx[j][k] += v;
                if j != k {
                    xtx[k][j] += v;
                }
            }
        }
    }

    // Add small ridge for numerical stability
    for j in 0..p {
        xtx[j][j] += 1e-10;
    }

    // Solve via Gaussian elimination with partial pivoting
    let mut aug = vec![vec![0.0f64; p + 1]; p];
    for i in 0..p {
        for j in 0..p {
            aug[i][j] = xtx[i][j];
        }
        aug[i][p] = xty[i];
    }

    for col in 0..p {
        // Partial pivot
        let mut max_row = col;
        let mut max_val = aug[col][col].abs();
        for row in (col + 1)..p {
            if aug[row][col].abs() > max_val {
                max_val = aug[row][col].abs();
                max_row = row;
            }
        }
        if max_val < 1e-15 {
            // Singular — return zeros
            return (vec![0.0; p], y.iter().map(|v| v * v).sum());
        }
        if max_row != col {
            aug.swap(col, max_row);
        }
        let pivot = aug[col][col];
        for j in col..=p {
            aug[col][j] /= pivot;
        }
        for row in 0..p {
            if row == col {
                continue;
            }
            let factor = aug[row][col];
            for j in col..=p {
                aug[row][j] -= factor * aug[col][j];
            }
        }
    }

    let beta: Vec<f64> = (0..p).map(|i| aug[i][p]).collect();

    // Compute RSS
    let mut rss = 0.0;
    for i in 0..n {
        let mut pred = 0.0;
        for j in 0..p {
            pred += x[i][j] * beta[j];
        }
        let e = y[i] - pred;
        rss += e * e;
    }

    (beta, rss)
}

/// Granger causality F-test.
///
/// Tests whether X Granger-causes Y at the given lag order.
/// Returns (F-statistic, approximate p-value).
///
/// Restricted model: Y_t = a0 + sum(a_i * Y_{t-i})
/// Unrestricted model: Y_t = a0 + sum(a_i * Y_{t-i}) + sum(b_j * X_{t-j})
fn granger_f_test(
    x_returns: &[f64],
    y_returns: &[f64],
    lag_order: usize,
) -> (f64, f64) {
    let n = x_returns.len().min(y_returns.len());
    if n <= 2 * lag_order + 2 {
        return (0.0, 1.0);
    }

    let effective_n = n - lag_order;
    let y_target: Vec<f64> = y_returns[lag_order..n].to_vec();

    // Restricted model: intercept + Y lags
    let p_r = 1 + lag_order;
    let mut x_restricted = Vec::with_capacity(effective_n);
    for t in lag_order..n {
        let mut row = Vec::with_capacity(p_r);
        row.push(1.0); // intercept
        for l in 1..=lag_order {
            row.push(y_returns[t - l]);
        }
        x_restricted.push(row);
    }

    // Unrestricted model: intercept + Y lags + X lags
    let p_u = 1 + 2 * lag_order;
    let mut x_unrestricted = Vec::with_capacity(effective_n);
    for t in lag_order..n {
        let mut row = Vec::with_capacity(p_u);
        row.push(1.0); // intercept
        for l in 1..=lag_order {
            row.push(y_returns[t - l]);
        }
        for l in 1..=lag_order {
            row.push(x_returns[t - l]);
        }
        x_unrestricted.push(row);
    }

    let (_, rss_r) = ols_rss(&x_restricted, &y_target);
    let (_, rss_u) = ols_rss(&x_unrestricted, &y_target);

    if rss_u < 1e-15 {
        return (f64::INFINITY, 0.0);
    }

    let q = lag_order as f64; // number of restrictions
    let df2 = effective_n as f64 - p_u as f64;
    if df2 <= 0.0 {
        return (0.0, 1.0);
    }

    let f_stat = ((rss_r - rss_u) / q) / (rss_u / df2);
    if !f_stat.is_finite() || f_stat < 0.0 {
        return (0.0, 1.0);
    }

    // Approximate p-value using F-distribution CDF approximation.
    // Use the regularized incomplete beta function approximation.
    let p_value = f_distribution_sf(f_stat, q, df2);

    (f_stat, p_value)
}

/// Survival function (1 - CDF) of the F-distribution.
/// Uses transformation to Beta distribution: if F ~ F(d1,d2),
/// then X = d1*F / (d1*F + d2) ~ Beta(d1/2, d2/2).
fn f_distribution_sf(f: f64, d1: f64, d2: f64) -> f64 {
    if f <= 0.0 {
        return 1.0;
    }
    let x = d1 * f / (d1 * f + d2);
    // P(F > f) = 1 - I_x(d1/2, d2/2)
    let cdf = regularized_incomplete_beta(x, d1 / 2.0, d2 / 2.0);
    (1.0 - cdf).clamp(0.0, 1.0)
}

/// Regularized incomplete beta function I_x(a, b) via continued fraction.
/// Uses Lentz's method for the continued fraction expansion.
fn regularized_incomplete_beta(x: f64, a: f64, b: f64) -> f64 {
    if x <= 0.0 {
        return 0.0;
    }
    if x >= 1.0 {
        return 1.0;
    }

    // Use symmetry relation if x > (a+1)/(a+b+2)
    let threshold = (a + 1.0) / (a + b + 2.0);
    if x > threshold {
        return 1.0 - regularized_incomplete_beta(1.0 - x, b, a);
    }

    // Front factor: x^a * (1-x)^b / (a * B(a,b))
    let ln_front = a * x.ln() + b * (1.0 - x).ln() - ln_beta(a, b) - a.ln();
    let front = ln_front.exp();

    // Continued fraction (Lentz's method)
    let mut f_val = 1.0;
    let mut c = 1.0;
    let mut d = 1.0 - (a + b) * x / (a + 1.0);
    if d.abs() < 1e-30 {
        d = 1e-30;
    }
    d = 1.0 / d;
    f_val = d;

    for m in 1..200 {
        let mf = m as f64;

        // Even step: d_{2m}
        let num_even = mf * (b - mf) * x / ((a + 2.0 * mf - 1.0) * (a + 2.0 * mf));
        d = 1.0 + num_even * d;
        if d.abs() < 1e-30 {
            d = 1e-30;
        }
        c = 1.0 + num_even / c;
        if c.abs() < 1e-30 {
            c = 1e-30;
        }
        d = 1.0 / d;
        f_val *= d * c;

        // Odd step: d_{2m+1}
        let num_odd = -((a + mf) * (a + b + mf) * x)
            / ((a + 2.0 * mf) * (a + 2.0 * mf + 1.0));
        d = 1.0 + num_odd * d;
        if d.abs() < 1e-30 {
            d = 1e-30;
        }
        c = 1.0 + num_odd / c;
        if c.abs() < 1e-30 {
            c = 1e-30;
        }
        d = 1.0 / d;
        let delta = d * c;
        f_val *= delta;

        if (delta - 1.0).abs() < 1e-10 {
            break;
        }
    }

    (front * f_val).clamp(0.0, 1.0)
}

/// Log of the Beta function: ln(B(a,b)) = lnGamma(a) + lnGamma(b) - lnGamma(a+b)
fn ln_beta(a: f64, b: f64) -> f64 {
    ln_gamma(a) + ln_gamma(b) - ln_gamma(a + b)
}

/// Stirling's approximation for ln(Gamma(x)) — Lanczos approximation.
fn ln_gamma(x: f64) -> f64 {
    // Lanczos coefficients (g=7)
    const COEFF: [f64; 9] = [
        0.99999999999980993,
        676.5203681218851,
        -1259.1392167224028,
        771.32342877765313,
        -176.61502916214059,
        12.507343278686905,
        -0.13857109526572012,
        9.9843695780195716e-6,
        1.5056327351493116e-7,
    ];

    if x < 0.5 {
        // Reflection formula
        let pi = std::f64::consts::PI;
        return pi.ln() - (pi * x).sin().abs().ln() - ln_gamma(1.0 - x);
    }

    let x = x - 1.0;
    let mut sum = COEFF[0];
    for (i, &c) in COEFF[1..].iter().enumerate() {
        sum += c / (x + i as f64 + 1.0);
    }

    let t = x + 7.5;
    0.5 * (2.0 * std::f64::consts::PI).ln() + (x + 0.5) * t.ln() - t + sum.ln()
}

/// Transfer entropy TE(X -> Y) using binned estimation.
///
/// TE(X->Y) = H(Y_future | Y_past) - H(Y_future | Y_past, X_past)
/// Computed via joint and marginal histograms.
fn transfer_entropy(x_returns: &[f64], y_returns: &[f64], lag: usize) -> f64 {
    let n = x_returns.len().min(y_returns.len());
    if n <= lag + 1 {
        return 0.0;
    }

    // Bin returns into TE_NUM_BINS categories based on quantiles
    let x_bins = bin_series(x_returns, TE_NUM_BINS);
    let y_bins = bin_series(y_returns, TE_NUM_BINS);

    let effective_n = n - lag;
    let nb = TE_NUM_BINS;

    // Count joint: (y_future, y_past, x_past) and marginals
    // y_future in {0..nb-1}, y_past in {0..nb-1}, x_past in {0..nb-1}
    let mut count_fyp_xp = vec![vec![vec![0usize; nb]; nb]; nb]; // [y_f][y_p][x_p]
    let mut count_yp_xp = vec![vec![0usize; nb]; nb]; // [y_p][x_p]
    let mut count_fyp = vec![vec![0usize; nb]; nb]; // [y_f][y_p]
    let mut count_yp = vec![0usize; nb]; // [y_p]

    for t in lag..n {
        let y_f = y_bins[t];
        let y_p = y_bins[t - 1]; // use lag-1 as past
        let x_p = x_bins[t - 1];
        if y_f >= nb || y_p >= nb || x_p >= nb {
            continue;
        }
        count_fyp_xp[y_f][y_p][x_p] += 1;
        count_yp_xp[y_p][x_p] += 1;
        count_fyp[y_f][y_p] += 1;
        count_yp[y_p] += 1;
    }

    let total = effective_n as f64;
    if total < 1.0 {
        return 0.0;
    }

    // TE = sum over (y_f, y_p, x_p) of p(y_f, y_p, x_p) * log2(
    //   p(y_f | y_p, x_p) / p(y_f | y_p) )
    let mut te = 0.0;
    for y_f in 0..nb {
        for y_p in 0..nb {
            for x_p in 0..nb {
                let n_fyp_xp = count_fyp_xp[y_f][y_p][x_p];
                if n_fyp_xp == 0 {
                    continue;
                }
                let n_yp_xp = count_yp_xp[y_p][x_p];
                let n_fyp = count_fyp[y_f][y_p];
                let n_yp = count_yp[y_p];

                if n_yp_xp == 0 || n_fyp == 0 || n_yp == 0 {
                    continue;
                }

                let p_joint = n_fyp_xp as f64 / total;
                // p(y_f | y_p, x_p) = n(y_f, y_p, x_p) / n(y_p, x_p)
                let p_cond_full = n_fyp_xp as f64 / n_yp_xp as f64;
                // p(y_f | y_p) = n(y_f, y_p) / n(y_p)
                let p_cond_reduced = n_fyp as f64 / n_yp as f64;

                if p_cond_full > 0.0 && p_cond_reduced > 0.0 {
                    te += p_joint * (p_cond_full / p_cond_reduced).ln();
                }
            }
        }
    }

    te.max(0.0)
}

/// Bin a series into `n_bins` categories using equally-spaced quantile thresholds.
fn bin_series(data: &[f64], n_bins: usize) -> Vec<usize> {
    if data.is_empty() || n_bins == 0 {
        return vec![];
    }

    let mut sorted = data.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

    // Compute quantile thresholds
    let mut thresholds = Vec::with_capacity(n_bins - 1);
    for i in 1..n_bins {
        let q = i as f64 / n_bins as f64;
        let idx = ((sorted.len() as f64 - 1.0) * q).round() as usize;
        thresholds.push(sorted[idx.min(sorted.len() - 1)]);
    }

    data.iter()
        .map(|&v| {
            let mut bin = 0;
            for &t in &thresholds {
                if v > t {
                    bin += 1;
                } else {
                    break;
                }
            }
            bin.min(n_bins - 1)
        })
        .collect()
}

/// Cross-correlation between two series at multiple lags.
/// Returns (best_lag, best_correlation) where positive lag means X leads Y.
fn lead_lag_analysis(x_returns: &[f64], y_returns: &[f64]) -> (i32, f64) {
    let n = x_returns.len().min(y_returns.len());
    if n < 3 {
        return (0, 0.0);
    }

    let mean_x: f64 = x_returns[..n].iter().sum::<f64>() / n as f64;
    let mean_y: f64 = y_returns[..n].iter().sum::<f64>() / n as f64;

    let var_x: f64 = x_returns[..n].iter().map(|v| (v - mean_x).powi(2)).sum::<f64>();
    let var_y: f64 = y_returns[..n].iter().map(|v| (v - mean_y).powi(2)).sum::<f64>();
    let denom = (var_x * var_y).sqrt();
    if denom < 1e-15 {
        return (0, 0.0);
    }

    let max_lag = CROSS_CORR_MAX_LAG.min(n as i32 / 3);
    let mut best_lag = 0i32;
    let mut best_corr = 0.0f64;

    for lag in -max_lag..=max_lag {
        let mut cross = 0.0;
        let mut count = 0;

        for t in 0..n {
            let s = t as i32 + lag;
            if s >= 0 && (s as usize) < n {
                cross += (x_returns[s as usize] - mean_x) * (y_returns[t] - mean_y);
                count += 1;
            }
        }

        if count > 0 {
            let corr = cross / denom;
            if corr.abs() > best_corr.abs() {
                best_corr = corr;
                best_lag = lag;
            }
        }
    }

    (best_lag, best_corr)
}

// ---------------------------------------------------------------------------
// CausalEngine
// ---------------------------------------------------------------------------

/// Causal discovery engine for market return series.
///
/// Maintains rolling price/return buffers for each market and builds directed
/// causal graphs via Granger causality F-tests, transfer entropy, and
/// cross-correlation lead-lag analysis.
#[pyclass]
pub struct CausalEngine {
    inner: Mutex<Inner>,
}

#[pymethods]
impl CausalEngine {
    #[new]
    fn new() -> Self {
        Self {
            inner: Mutex::new(Inner::new()),
        }
    }

    /// Append a price observation for a market. Computes log-return from
    /// the previous observation and appends to the return buffer.
    fn update_price(&self, market_id: &str, price: f64) {
        if !price.is_finite() || price <= 0.0 {
            return;
        }
        let mut inner = self.inner.lock().unwrap();
        let key = market_id.to_string();

        // Get previous price (if any) before mutating
        let prev_price = inner
            .price_buffers
            .get(&key)
            .and_then(|buf| buf.back().copied());

        // Compute and store return
        if let Some(prev) = prev_price {
            if prev > 0.0 {
                let ret = (price / prev).ln();
                if ret.is_finite() {
                    let returns = inner
                        .return_buffers
                        .entry(key.clone())
                        .or_insert_with(VecDeque::new);
                    returns.push_back(ret);
                    if returns.len() > MAX_RETURN_BUF {
                        returns.pop_front();
                    }
                }
            }
        }

        // Append price
        let prices = inner
            .price_buffers
            .entry(key)
            .or_insert_with(VecDeque::new);
        prices.push_back(price);
        if prices.len() > MAX_PRICE_BUF {
            prices.pop_front();
        }
    }

    /// Build a causal graph from return buffers.
    ///
    /// For each directed pair (X, Y), runs a Granger causality F-test,
    /// computes transfer entropy, and finds the optimal lead-lag. An edge
    /// is added if either the Granger p-value < threshold OR the transfer
    /// entropy > te_threshold.
    #[pyo3(signature = (markets=None, granger_pvalue_threshold=0.05,
                        te_threshold=0.01, min_observations=30))]
    fn build_causal_graph(
        &self,
        markets: Option<Vec<String>>,
        granger_pvalue_threshold: f64,
        te_threshold: f64,
        min_observations: usize,
    ) -> CausalGraph {
        let mut inner = self.inner.lock().unwrap();

        // Determine market set
        let market_list: Vec<String> = match markets {
            Some(m) => m,
            None => inner.return_buffers.keys().cloned().collect(),
        };

        let mut edges = Vec::new();

        for i in 0..market_list.len() {
            for j in 0..market_list.len() {
                if i == j {
                    continue;
                }
                let src = &market_list[i];
                let tgt = &market_list[j];

                let src_returns = match inner.return_buffers.get(src) {
                    Some(buf) if buf.len() >= min_observations => buf,
                    _ => continue,
                };
                let tgt_returns = match inner.return_buffers.get(tgt) {
                    Some(buf) if buf.len() >= min_observations => buf,
                    _ => continue,
                };

                let x_vec: Vec<f64> = src_returns.iter().copied().collect();
                let y_vec: Vec<f64> = tgt_returns.iter().copied().collect();

                // Granger test
                let (f_stat, p_value) = granger_f_test(&x_vec, &y_vec, DEFAULT_LAG_ORDER);

                // Transfer entropy
                let te = transfer_entropy(&x_vec, &y_vec, DEFAULT_LAG_ORDER);

                // Lead-lag
                let (lag, _corr) = lead_lag_analysis(&x_vec, &y_vec);

                // Accept edge if either test passes
                if p_value < granger_pvalue_threshold || te > te_threshold {
                    let weight = if p_value < granger_pvalue_threshold {
                        f_stat.min(100.0) / 100.0 // normalize F-stat to [0,1]
                    } else {
                        te.min(1.0)
                    };

                    edges.push(CausalEdge {
                        source: src.clone(),
                        target: tgt.clone(),
                        granger_pvalue: p_value,
                        transfer_entropy: te,
                        lag,
                        weight,
                    });
                }
            }
        }

        let graph = CausalGraph {
            edges,
            markets: market_list,
            built_at: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs_f64(),
        };

        // Rotate graphs
        inner.prev_graph = inner.graph.take();
        inner.graph = Some(graph.clone());

        graph
    }

    /// Detect a structural break in the causal graph.
    ///
    /// Compares the edge set of the current graph vs the previous graph
    /// using Jaccard similarity. Returns true if similarity < threshold
    /// (i.e., the graph has changed significantly).
    #[pyo3(signature = (jaccard_threshold=0.5))]
    fn detect_causal_break(&self, jaccard_threshold: f64) -> bool {
        let inner = self.inner.lock().unwrap();

        let (curr, prev) = match (&inner.graph, &inner.prev_graph) {
            (Some(c), Some(p)) => (c, p),
            _ => return false,
        };

        let curr_edges: HashSet<(String, String)> = curr
            .edges
            .iter()
            .map(|e| (e.source.clone(), e.target.clone()))
            .collect();

        let prev_edges: HashSet<(String, String)> = prev
            .edges
            .iter()
            .map(|e| (e.source.clone(), e.target.clone()))
            .collect();

        let intersection = curr_edges.intersection(&prev_edges).count();
        let union = curr_edges.union(&prev_edges).count();

        if union == 0 {
            return false;
        }

        let jaccard = intersection as f64 / union as f64;
        jaccard < jaccard_threshold
    }

    /// Return the list of markets that Granger-cause the given market.
    fn causal_parents(&self, market_id: &str) -> Vec<String> {
        let inner = self.inner.lock().unwrap();
        match &inner.graph {
            Some(g) => g
                .edges
                .iter()
                .filter(|e| e.target == market_id)
                .map(|e| e.source.clone())
                .collect(),
            None => vec![],
        }
    }

    /// Return the full information flow map: source -> [(target, weight)].
    fn information_flow_map(&self) -> HashMap<String, Vec<(String, f64)>> {
        let inner = self.inner.lock().unwrap();
        let mut map: HashMap<String, Vec<(String, f64)>> = HashMap::new();

        if let Some(g) = &inner.graph {
            for edge in &g.edges {
                map.entry(edge.source.clone())
                    .or_default()
                    .push((edge.target.clone(), edge.weight));
            }
        }

        map
    }

    /// Return engine status as a dict.
    fn status(&self) -> HashMap<String, PyObject> {
        Python::with_gil(|py| {
            let inner = self.inner.lock().unwrap();
            let mut m = HashMap::new();

            m.insert(
                "markets_tracked".into(),
                inner.return_buffers.len().to_object(py),
            );

            let min_obs: usize = inner
                .return_buffers
                .values()
                .map(|v| v.len())
                .min()
                .unwrap_or(0);
            m.insert(
                "min_observations".into(),
                min_obs.to_object(py),
            );

            let max_obs: usize = inner
                .return_buffers
                .values()
                .map(|v| v.len())
                .max()
                .unwrap_or(0);
            m.insert(
                "max_observations".into(),
                max_obs.to_object(py),
            );

            let has_graph = inner.graph.is_some();
            m.insert(
                "has_graph".into(),
                has_graph.to_object(py),
            );

            let edge_count = inner
                .graph
                .as_ref()
                .map(|g| g.edges.len())
                .unwrap_or(0);
            m.insert(
                "edge_count".into(),
                edge_count.to_object(py),
            );

            let has_prev = inner.prev_graph.is_some();
            m.insert(
                "has_prev_graph".into(),
                has_prev.to_object(py),
            );

            m
        })
    }
}
