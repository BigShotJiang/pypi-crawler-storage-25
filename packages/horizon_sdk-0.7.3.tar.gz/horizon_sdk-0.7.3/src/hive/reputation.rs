//! Reputation system — Bayesian trust scoring for swarm agents.
//!
//! Each agent maintains a Beta(alpha, beta) posterior tracking success/failure.
//! Reputation score = alpha / (alpha + beta) (posterior mean).
//! Confidence = 1 - 2 / sqrt(alpha + beta + 2) (shrinks with more observations).
//!
//! Behavioral fingerprinting tracks EMA of strategy statistics with Welford
//! online variance, enabling style-drift detection.

use pyo3::prelude::*;
use std::collections::HashMap;
use std::sync::Mutex;

// ---------------------------------------------------------------------------
// Internal per-agent state
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct AgentReputation {
    alpha: f64,
    beta: f64,
    score: f64,
    confidence: f64,
    fingerprint: HashMap<String, f64>,
    /// Welford online: (count, mean, M2)
    fingerprint_var: HashMap<String, (u64, f64, f64)>,
}

impl AgentReputation {
    fn new() -> Self {
        let mut rep = Self {
            alpha: 1.0,
            beta: 1.0,
            score: 0.5,
            confidence: 0.0,
            fingerprint: HashMap::new(),
            fingerprint_var: HashMap::new(),
        };
        rep.recompute();
        rep
    }

    fn recompute(&mut self) {
        let total = self.alpha + self.beta;
        self.score = if total > 0.0 { self.alpha / total } else { 0.5 };
        // confidence: 1 - 2/sqrt(alpha + beta + 2), clamped to [0, 1]
        self.confidence = (1.0 - 2.0 / (self.alpha + self.beta + 2.0).sqrt()).max(0.0);
    }
}

// ---------------------------------------------------------------------------
// ReputationSystem
// ---------------------------------------------------------------------------

/// Bayesian reputation tracker for swarm agents.
///
/// Maintains Beta posterior per agent, computes capital and pheromone weights,
/// and detects style drift via fingerprint statistics.
#[pyclass]
pub struct ReputationSystem {
    agents: Mutex<HashMap<String, AgentReputation>>,
}

#[pymethods]
impl ReputationSystem {
    #[new]
    fn new() -> Self {
        Self {
            agents: Mutex::new(HashMap::new()),
        }
    }

    /// Record a success or failure for an agent.
    ///
    /// Increment is `magnitude.abs().min(1.0)`.
    fn update(&self, agent_id: &str, success: bool, magnitude: f64) {
        let inc = magnitude.abs().min(1.0);
        let mut agents = self.agents.lock().unwrap();
        let rep = agents
            .entry(agent_id.to_string())
            .or_insert_with(AgentReputation::new);
        if success {
            rep.alpha += inc;
        } else {
            rep.beta += inc;
        }
        rep.recompute();
    }

    /// Get (score, confidence) for an agent. Returns (0.5, 0.0) if unknown.
    fn get(&self, agent_id: &str) -> (f64, f64) {
        let agents = self.agents.lock().unwrap();
        match agents.get(agent_id) {
            Some(rep) => (rep.score, rep.confidence),
            None => (0.5, 0.0),
        }
    }

    /// Exponential decay toward 0.5 for all agents.
    ///
    /// decay_factor = exp(-ln(2) * dt_seconds / halflife)
    /// alpha' = 1 + (alpha - 1) * decay_factor
    /// beta'  = 1 + (beta  - 1) * decay_factor
    fn decay(&self, dt_seconds: f64, halflife: f64) {
        if halflife <= 0.0 || dt_seconds <= 0.0 {
            return;
        }
        let factor = (-f64::ln(2.0) * dt_seconds / halflife).exp();
        let mut agents = self.agents.lock().unwrap();
        for rep in agents.values_mut() {
            rep.alpha = 1.0 + (rep.alpha - 1.0) * factor;
            rep.beta = 1.0 + (rep.beta - 1.0) * factor;
            rep.recompute();
        }
    }

    /// Capital allocation weight: score^2 clamped to [0.1, 2.0].
    fn capital_weight(&self, agent_id: &str) -> f64 {
        let agents = self.agents.lock().unwrap();
        let score = agents
            .get(agent_id)
            .map(|r| r.score)
            .unwrap_or(0.5);
        (score * score).clamp(0.1, 2.0)
    }

    /// Pheromone deposit weight: score * (1 + confidence) clamped to [0.5, 2.0].
    fn pheromone_weight(&self, agent_id: &str) -> f64 {
        let agents = self.agents.lock().unwrap();
        match agents.get(agent_id) {
            Some(rep) => (rep.score * (1.0 + rep.confidence)).clamp(0.5, 2.0),
            None => 1.0,
        }
    }

    /// Detect if agent's current stats deviate from fingerprint by > threshold * std.
    ///
    /// Returns true if ANY stat deviates beyond the threshold.
    fn detect_style_drift(
        &self,
        agent_id: &str,
        current_stats: HashMap<String, f64>,
        threshold: f64,
    ) -> bool {
        let agents = self.agents.lock().unwrap();
        let rep = match agents.get(agent_id) {
            Some(r) => r,
            None => return false,
        };

        for (key, &current) in &current_stats {
            // Need both fingerprint mean and variance data
            let fp_mean = match rep.fingerprint.get(key) {
                Some(&v) => v,
                None => continue,
            };
            let var_data = match rep.fingerprint_var.get(key) {
                Some(v) => v,
                None => continue,
            };
            let (count, _mean, m2) = *var_data;
            if count < 2 {
                continue;
            }
            let variance = m2 / count as f64;
            let std_dev = variance.sqrt();
            if std_dev < 1e-15 {
                continue;
            }
            let deviation = (current - fp_mean).abs();
            if deviation > threshold * std_dev {
                return true;
            }
        }
        false
    }

    /// Update behavioral fingerprint using EMA (alpha=0.1) and Welford online variance.
    fn update_fingerprint(&self, agent_id: &str, stats: HashMap<String, f64>) {
        const EMA_ALPHA: f64 = 0.1;

        let mut agents = self.agents.lock().unwrap();
        let rep = agents
            .entry(agent_id.to_string())
            .or_insert_with(AgentReputation::new);

        for (key, &value) in &stats {
            // EMA update for fingerprint
            let fp = rep.fingerprint.entry(key.clone()).or_insert(value);
            *fp = EMA_ALPHA * value + (1.0 - EMA_ALPHA) * *fp;

            // Welford online variance update
            let entry = rep.fingerprint_var.entry(key.clone()).or_insert((0, 0.0, 0.0));
            let (count, mean, m2) = entry;
            *count += 1;
            let delta = value - *mean;
            *mean += delta / *count as f64;
            let delta2 = value - *mean;
            *m2 += delta * delta2;
        }
    }

    /// All agents sorted by score descending: Vec<(agent_id, score, confidence)>.
    fn ranking(&self) -> Vec<(String, f64, f64)> {
        let agents = self.agents.lock().unwrap();
        let mut v: Vec<(String, f64, f64)> = agents
            .iter()
            .map(|(id, rep)| (id.clone(), rep.score, rep.confidence))
            .collect();
        v.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        v
    }

    /// Top fraction of agents by score.
    fn top_agents(&self, fraction: f64) -> Vec<String> {
        let ranking = self.ranking();
        let n = ((ranking.len() as f64 * fraction.clamp(0.0, 1.0)).ceil() as usize).max(0);
        ranking.into_iter().take(n).map(|(id, _, _)| id).collect()
    }

    /// Bottom fraction of agents by score.
    fn bottom_agents(&self, fraction: f64) -> Vec<String> {
        let mut ranking = self.ranking();
        let n = ((ranking.len() as f64 * fraction.clamp(0.0, 1.0)).ceil() as usize).max(0);
        ranking.reverse();
        ranking.into_iter().take(n).map(|(id, _, _)| id).collect()
    }
}
