use std::sync::Mutex;
use std::time::Instant;

/// Token bucket rate limiter with sliding window semantics.
///
/// Refills tokens continuously based on elapsed time (monotonic clock),
/// preventing wall-clock boundary exploits. The bucket starts with tokens
/// equal to one second's worth of the sustained rate (not the full burst
/// capacity), so cold-start bursts are bounded. Over time, unused capacity
/// accumulates up to `burst_capacity`.
pub struct TokenBucket {
    sustained_rate: u32,
    burst_capacity: u32,
    inner: Mutex<TokenBucketInner>,
}

struct TokenBucketInner {
    tokens: f64,
    last_refill: Instant,
}

impl TokenBucket {
    pub fn new(sustained_per_min: u32, burst: u32) -> Self {
        // Start with full burst capacity. The monotonic clock (Instant)
        // prevents wall-clock boundary exploits. The burst capacity represents
        // the user's configured maximum acceptable initial burst.
        let initial_tokens = burst as f64;
        Self {
            sustained_rate: sustained_per_min,
            burst_capacity: burst,
            inner: Mutex::new(TokenBucketInner {
                tokens: initial_tokens,
                last_refill: Instant::now(),
            }),
        }
    }

    /// Try to acquire one token. Returns true if successful.
    ///
    /// Uses monotonic `Instant` for elapsed time, so there is no wall-clock
    /// boundary where a burst at second N.999 + second (N+1).000 could
    /// double the effective rate (a problem with per-second counters).
    pub fn try_acquire(&self) -> bool {
        let mut inner = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        let now = Instant::now();
        let elapsed = now.duration_since(inner.last_refill).as_secs_f64();
        let refill = elapsed * (self.sustained_rate as f64 / 60.0);
        inner.tokens = (inner.tokens + refill).min(self.burst_capacity as f64);
        inner.last_refill = now;

        if inner.tokens >= 1.0 {
            inner.tokens -= 1.0;
            true
        } else {
            false
        }
    }

    /// Current number of available tokens.
    pub fn available(&self) -> f64 {
        let inner = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        inner.tokens
    }

    /// Sustained rate (tokens per minute).
    pub fn sustained_rate(&self) -> u32 {
        self.sustained_rate
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn token_bucket_initial_burst() {
        // sustained=60/min, burst=100
        // Initial tokens = burst capacity = 100
        let bucket = TokenBucket::new(60, 100);
        for _ in 0..100 {
            assert!(bucket.try_acquire());
        }
        assert!(!bucket.try_acquire()); // 101st fails (burst exhausted)
    }

    #[test]
    fn token_bucket_burst_cap() {
        let bucket = TokenBucket::new(600, 5);
        // Initial tokens = burst = 5 (capped by burst_capacity)
        for _ in 0..5 {
            assert!(bucket.try_acquire());
        }
        // 6th should fail (burst exhausted)
        assert!(!bucket.try_acquire());
    }

    #[test]
    fn token_bucket_refills_over_time() {
        let bucket = TokenBucket::new(6000, 10);
        // Initial tokens = burst = 10
        // Drain all initial tokens
        for _ in 0..10 {
            assert!(bucket.try_acquire());
        }
        assert!(!bucket.try_acquire());

        // After waiting, tokens should refill
        // (Can't easily test timing in unit tests without mocking Instant)
    }
}
