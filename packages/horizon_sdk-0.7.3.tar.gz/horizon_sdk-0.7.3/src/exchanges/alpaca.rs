//! Alpaca Markets REST exchange client.
//!
//! Implements the Exchange trait for Alpaca's Trading API.
//! Supports both paper and live trading via header-based auth.
//! Includes fill polling and order management.

use crate::error::HorizonError;
use crate::exchanges::fill_dedup::FillDedup;
use crate::exchanges::order_tracker::OrderTracker;
use crate::exchanges::Exchange;
use crate::types::{Fill, OrderRequest, OrderSide, OrderType, Position, Side, TimeInForce};
use std::sync::{Arc, Mutex};
use tracing::{debug, error, info, warn};
use zeroize::Zeroizing;

const LIVE_API_URL: &str = "https://api.alpaca.markets";
const PAPER_API_URL: &str = "https://paper-api.alpaca.markets";

/// Validate that a URL path parameter contains only safe characters.
fn validate_url_param(param: &str, name: &str) -> Result<(), HorizonError> {
    if param.is_empty() {
        return Err(HorizonError::Exchange(format!(
            "alpaca: {} is empty",
            name
        )));
    }
    if !param
        .bytes()
        .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
    {
        return Err(HorizonError::Exchange(format!(
            "alpaca: invalid characters in {}",
            name
        )));
    }
    Ok(())
}

/// URL-encode a query parameter value to prevent injection.
/// Only allows alphanumeric, '-', '_', '.', '~' through unencoded (RFC 3986 unreserved).
/// Everything else is percent-encoded.
fn url_encode_query_value(value: &str) -> String {
    let mut encoded = String::with_capacity(value.len());
    for byte in value.bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                encoded.push(byte as char);
            }
            _ => {
                encoded.push_str(&format!("%{:02X}", byte));
            }
        }
    }
    encoded
}

/// Parse an ISO 8601 timestamp string to Unix seconds.
/// Handles formats like "2024-01-15T12:00:00Z" and "2024-01-15T12:00:00.123Z".
/// Also handles timezone offsets like "+00:00" by stripping them (assumes UTC).
fn parse_iso_timestamp(s: &str) -> f64 {
    // Try numeric first
    if let Ok(v) = s.parse::<f64>() {
        return v;
    }
    // Strip trailing timezone offset (+HH:MM or -HH:MM) for simplicity (treat as UTC)
    let s = s.trim();
    let s = if s.ends_with('Z') {
        &s[..s.len() - 1]
    } else if s.len() > 6 {
        // Check for +HH:MM or -HH:MM suffix
        let tail = &s[s.len() - 6..];
        if (tail.starts_with('+') || tail.starts_with('-'))
            && tail.as_bytes()[3] == b':'
        {
            &s[..s.len() - 6]
        } else {
            s
        }
    } else {
        s
    };

    let (date_part, time_part) = match s.split_once('T') {
        Some(parts) => parts,
        None => return 0.0,
    };
    let mut date_iter = date_part.split('-');
    let year: i64 = match date_iter.next().and_then(|v| v.parse().ok()) {
        Some(v) => v,
        None => return 0.0,
    };
    let month: i64 = match date_iter.next().and_then(|v| v.parse().ok()) {
        Some(v) => v,
        None => return 0.0,
    };
    let day: i64 = match date_iter.next().and_then(|v| v.parse().ok()) {
        Some(v) => v,
        None => return 0.0,
    };

    let (time_whole, frac) = if let Some((w, f)) = time_part.split_once('.') {
        let frac_secs: f64 = format!("0.{}", f).parse().unwrap_or(0.0);
        (w, frac_secs)
    } else {
        (time_part, 0.0)
    };

    let mut time_iter = time_whole.split(':');
    let hour: i64 = time_iter.next().and_then(|v| v.parse().ok()).unwrap_or(0);
    let min: i64 = time_iter.next().and_then(|v| v.parse().ok()).unwrap_or(0);
    let sec: i64 = time_iter.next().and_then(|v| v.parse().ok()).unwrap_or(0);

    if month < 1 || month > 12 || day < 1 || day > 31 {
        return 0.0;
    }
    if hour > 23 || min > 59 || sec > 59 {
        return 0.0;
    }

    let is_leap = |y: i64| (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
    let mut days: i64 = 0;
    for y in 1970..year {
        days += if is_leap(y) { 366 } else { 365 };
    }
    let month_days = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for m in 1..month {
        days += month_days[m as usize];
        if m == 2 && is_leap(year) {
            days += 1;
        }
    }
    days += day - 1;

    let total_secs = days * 86400 + hour * 3600 + min * 60 + sec;
    total_secs as f64 + frac
}

pub struct AlpacaExchange {
    api_url: String,
    api_key: Zeroizing<String>,
    api_secret: Zeroizing<String>,
    client: reqwest::Client,
    runtime: Arc<tokio::runtime::Runtime>,
    fills: Mutex<Vec<Fill>>,
    next_fill_id: Mutex<u64>,
    last_fill_cursor: Mutex<Option<String>>,
    /// Tracks open order IDs per market (shared OrderTracker).
    open_orders: Mutex<OrderTracker>,
    /// Deduplicates fill IDs with FIFO eviction (shared FillDedup).
    fill_dedup: Mutex<FillDedup>,
    is_paper: bool,
}

impl AlpacaExchange {
    pub fn new(
        api_key: String,
        api_secret: String,
        api_url: Option<String>,
        is_paper: bool,
        runtime: Arc<tokio::runtime::Runtime>,
    ) -> Self {
        let default_url = if is_paper {
            PAPER_API_URL.to_string()
        } else {
            LIVE_API_URL.to_string()
        };
        Self {
            api_url: api_url.unwrap_or(default_url),
            api_key: Zeroizing::new(api_key),
            api_secret: Zeroizing::new(api_secret),
            client: reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(10))
                .connect_timeout(std::time::Duration::from_secs(5))
                .build()
                .unwrap_or_else(|_| reqwest::Client::new()),
            runtime,
            fills: Mutex::new(Vec::new()),
            next_fill_id: Mutex::new(1),
            last_fill_cursor: Mutex::new(None),
            open_orders: Mutex::new(OrderTracker::new("alpaca")),
            fill_dedup: Mutex::new(FillDedup::new()),
            is_paper,
        }
    }

    /// Add Alpaca auth headers to a request builder.
    fn auth_headers(
        &self,
        builder: reqwest::RequestBuilder,
    ) -> reqwest::RequestBuilder {
        builder
            .header("APCA-API-KEY-ID", &**self.api_key)
            .header("APCA-API-SECRET-KEY", &**self.api_secret)
    }

    /// Submit order to Alpaca with retry on 429.
    async fn submit_order_async(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let url = format!("{}/v2/orders", self.api_url);

        if req.size <= 0.0 || !req.size.is_finite() {
            return Err(HorizonError::Exchange(format!(
                "invalid size for Alpaca: {}",
                req.size
            )));
        }

        // Market orders don't need a valid price; limit orders do
        let is_market = matches!(req.order_type, OrderType::Market);
        if !is_market && (req.price <= 0.0 || !req.price.is_finite()) {
            return Err(HorizonError::Exchange(format!(
                "invalid price for Alpaca limit order: {}",
                req.price
            )));
        }

        let side_str = match req.order_side {
            OrderSide::Buy => "buy",
            OrderSide::Sell => "sell",
        };

        let order_type_str = match req.order_type {
            OrderType::Market => "market",
            OrderType::Limit => "limit",
        };

        let tif_str = match req.time_in_force {
            TimeInForce::GTC => "gtc",
            TimeInForce::GTD => "gtc", // Alpaca doesn't support GTD; fall back to GTC
            TimeInForce::FOK => "fok",
            TimeInForce::FAK => "ioc", // Fill-and-Kill = Immediate-or-Cancel
        };

        let mut body = serde_json::json!({
            "symbol": req.market_id,
            "qty": format!("{}", req.size),
            "side": side_str,
            "type": order_type_str,
            "time_in_force": tif_str,
        });

        // Only include limit_price for limit orders
        if !is_market {
            if let Some(obj) = body.as_object_mut() {
                obj.insert(
                    "limit_price".to_string(),
                    serde_json::Value::String(format!("{:.2}", req.price)),
                );
            }
        }

        debug!(
            symbol = %req.market_id,
            side = side_str,
            price = req.price,
            size = req.size,
            "alpaca: submitting order"
        );

        let mut backoff_ms: u64 = 1000;

        for attempt in 0..5u32 {
            let builder = self.client.post(&url).json(&body);
            let resp = self
                .auth_headers(builder)
                .send()
                .await
                .map_err(|e| HorizonError::Exchange(format!("alpaca order failed for {}: {}", req.market_id, e)))?;

            let status_code = resp.status().as_u16();

            if status_code == 429 && attempt < 4 {
                warn!(
                    attempt = attempt + 1,
                    backoff_ms = backoff_ms,
                    "alpaca: rate limited (429), retrying"
                );
                tokio::time::sleep(tokio::time::Duration::from_millis(backoff_ms)).await;
                backoff_ms = (backoff_ms * 2).min(30_000);
                continue;
            }

            if status_code == 403 {
                let body_text = resp.text().await.unwrap_or_default();
                return Err(HorizonError::Exchange(format!(
                    "alpaca: forbidden (403) — check API key permissions: {}",
                    body_text
                )));
            }

            if !resp.status().is_success() {
                let status = resp.status();
                let body_text = resp.text().await.unwrap_or_default();
                error!(status = %status, body = %body_text, "alpaca: order rejected");
                return Err(HorizonError::Exchange(format!(
                    "alpaca order rejected ({}): {}",
                    status, body_text
                )));
            }

            let json: serde_json::Value = resp
                .json()
                .await
                .map_err(|e| HorizonError::Exchange(format!("alpaca parse error: {}", e)))?;

            let order_id = json
                .get("id")
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .map(|s| s.to_string())
                .ok_or_else(|| {
                    HorizonError::Exchange(format!(
                        "alpaca: response missing order id: {}",
                        json
                    ))
                })?;

            info!(order_id = %order_id, "alpaca: order accepted");
            return Ok(order_id);
        }

        Err(HorizonError::Exchange(format!(
            "alpaca: retry attempts exhausted for {}",
            req.market_id
        )))
    }

    /// Cancel order on Alpaca.
    async fn cancel_order_async(&self, order_id: &str) -> Result<(), HorizonError> {
        validate_url_param(order_id, "order_id")?;
        let url = format!("{}/v2/orders/{}", self.api_url, order_id);

        let builder = self.client.delete(&url);
        let resp = self
            .auth_headers(builder)
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("alpaca cancel failed for order {}: {}", order_id, e)))?;

        if resp.status().as_u16() == 404 {
            // Order already filled or canceled
            debug!(order_id = %order_id, "alpaca: order not found (may be filled)");
            return Ok(());
        }

        if !resp.status().is_success() && resp.status().as_u16() != 204 {
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            return Err(HorizonError::Exchange(format!(
                "alpaca cancel failed ({}): {}",
                status, body
            )));
        }

        debug!(order_id = %order_id, "alpaca: order canceled");
        Ok(())
    }

    /// Cancel all orders on Alpaca.
    async fn cancel_all_async(&self) -> Result<usize, HorizonError> {
        let url = format!("{}/v2/orders", self.api_url);

        let builder = self.client.delete(&url);
        let resp = self
            .auth_headers(builder)
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("alpaca cancel-all failed: {}", e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            return Err(HorizonError::Exchange(format!(
                "alpaca cancel-all failed ({}): {}",
                status, body
            )));
        }

        // Alpaca returns an array of canceled orders (207) or empty on success
        let json: serde_json::Value = resp.json().await.unwrap_or_else(|e| {
            warn!(error = %e, "alpaca: cancel-all response parse failed");
            serde_json::Value::Null
        });
        let count = json.as_array().map(|a| a.len()).unwrap_or(0);

        info!(count = count, "alpaca: canceled all orders");
        Ok(count)
    }

    /// Poll for filled orders from Alpaca.
    async fn poll_fills_async(&self) -> Result<Vec<Fill>, HorizonError> {
        let mut url = format!("{}/v2/orders?status=filled&limit=100&direction=desc", self.api_url);

        // Add after cursor for incremental polling (URL-encoded to prevent injection)
        if let Ok(cursor) = self.last_fill_cursor.lock() {
            if let Some(ref c) = *cursor {
                let encoded = url_encode_query_value(c);
                url = format!("{}&after={}", url, encoded);
            }
        }

        let builder = self.client.get(&url);
        let resp = self
            .auth_headers(builder)
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("alpaca: fill poll failed: {}", e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            debug!(status = %status, "alpaca: fill poll returned non-200");
            return Ok(Vec::new());
        }

        let json: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("alpaca: fill parse error: {}", e))
        })?;

        let mut new_fills = Vec::new();

        if let Some(orders_arr) = json.as_array() {
            let mut next_id = self.next_fill_id.lock().unwrap_or_else(|e| e.into_inner());

            for order_json in orders_arr {
                let order_id = order_json
                    .get("id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let symbol = order_json
                    .get("symbol")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let filled_qty = order_json
                    .get("filled_qty")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()).or_else(|| v.as_f64()))
                    .unwrap_or(0.0);

                let filled_avg_price = order_json
                    .get("filled_avg_price")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()).or_else(|| v.as_f64()))
                    .unwrap_or(0.0);

                let side_str = order_json
                    .get("side")
                    .and_then(|v| v.as_str())
                    .unwrap_or("buy");

                let order_side = if side_str.eq_ignore_ascii_case("buy") {
                    OrderSide::Buy
                } else {
                    OrderSide::Sell
                };

                let ts = order_json
                    .get("filled_at")
                    .or_else(|| order_json.get("updated_at"))
                    .and_then(|v| v.as_str())
                    .map(parse_iso_timestamp)
                    .unwrap_or(0.0);

                if filled_qty <= 0.0 {
                    continue;
                }

                let fill_id = if order_id.is_empty() {
                    let id = format!("alpaca_fill_{}", *next_id);
                    *next_id += 1;
                    id
                } else {
                    order_id.clone()
                };

                // Dedup via shared FillDedup
                {
                    let mut dedup = self.fill_dedup.lock().unwrap_or_else(|e| e.into_inner());
                    if !dedup.check_and_insert(&fill_id) {
                        continue;
                    }
                }

                // Update cursor to latest order ID
                if let Ok(mut cursor) = self.last_fill_cursor.lock() {
                    *cursor = Some(order_id.clone());
                }

                new_fills.push(Fill {
                    fill_id,
                    order_id,
                    market_id: symbol,
                    side: Side::Long, // Long side for non-prediction instruments
                    order_side,
                    price: filled_avg_price,
                    size: filled_qty,
                    fee: 0.0, // Alpaca is commission-free for stocks
                    timestamp: ts,
                    token_id: None,
                    exchange: "alpaca".to_string(),
                    is_maker: false,
                    multiplier: 1.0,
                });
            }
        }

        if !new_fills.is_empty() {
            info!(count = new_fills.len(), "alpaca: polled new fills");
        }

        Ok(new_fills)
    }

    /// Fetch positions from Alpaca for reconciliation.
    async fn fetch_positions_async(&self) -> Result<Vec<Position>, HorizonError> {
        let url = format!("{}/v2/positions", self.api_url);

        let builder = self.client.get(&url);
        let resp = self
            .auth_headers(builder)
            .send()
            .await
            .map_err(|e| {
                HorizonError::Exchange(format!("alpaca: position fetch failed: {}", e))
            })?;

        if !resp.status().is_success() {
            let status = resp.status();
            debug!(status = %status, "alpaca: position fetch returned non-200");
            return Ok(Vec::new());
        }

        let json: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("alpaca: position parse error: {}", e))
        })?;

        let mut positions = Vec::new();

        if let Some(arr) = json.as_array() {
            for p in arr {
                let symbol = p
                    .get("symbol")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                let qty = p
                    .get("qty")
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);
                let avg_entry = p
                    .get("avg_entry_price")
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);
                let unrealized_pl = p
                    .get("unrealized_pl")
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);

                if qty.abs() > 0.0 {
                    positions.push(Position {
                        market_id: symbol,
                        side: Side::Long, // Long side for non-prediction instruments
                        size: qty,
                        avg_entry_price: avg_entry,
                        realized_pnl: 0.0,
                        unrealized_pnl: unrealized_pl,
                        token_id: None,
                        exchange: "alpaca".to_string(),
                        multiplier: 1.0,
                    });
                }
            }
        }

        if !positions.is_empty() {
            info!(
                count = positions.len(),
                "alpaca: fetched positions for reconciliation"
            );
        }

        Ok(positions)
    }
}

impl Exchange for AlpacaExchange {
    fn submit_order(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let req_clone = req.clone();
        let order_id = self
            .runtime
            .block_on(self.submit_order_async(&req_clone))?;

        // Track order_id per market via shared OrderTracker
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.insert(&req.market_id, &order_id);
        }

        Ok(order_id)
    }

    fn cancel_order(&self, order_id: &str) -> Result<(), HorizonError> {
        let id = order_id.to_string();
        self.runtime.block_on(self.cancel_order_async(&id))?;

        // Remove from open_orders tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove(order_id);
        }

        Ok(())
    }

    fn cancel_all(&self) -> Result<usize, HorizonError> {
        let count = self.runtime.block_on(self.cancel_all_async())?;

        // Clear all tracked orders
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.clear();
        }

        Ok(count)
    }

    fn cancel_for_market(&self, market_id: &str) -> Result<usize, HorizonError> {
        let order_ids: Vec<String> = {
            let tracker = self.open_orders.lock().unwrap_or_else(|e| e.into_inner());
            tracker.get_market_orders(market_id)
        };

        if order_ids.is_empty() {
            return Ok(0);
        }

        let mut successfully_canceled = Vec::new();
        for oid in &order_ids {
            match self.runtime.block_on(self.cancel_order_async(oid)) {
                Ok(()) => successfully_canceled.push(oid.clone()),
                Err(e) => {
                    debug!(
                        order_id = %oid,
                        error = %e,
                        "alpaca: cancel_for_market: order cancel failed (may already be filled)"
                    );
                }
            }
        }

        // Only remove successfully canceled IDs from tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove_from_market(market_id, &successfully_canceled);
        }

        let canceled = successfully_canceled.len();
        info!(
            market_id = %market_id,
            canceled = canceled,
            total = order_ids.len(),
            "alpaca: canceled orders for market"
        );
        Ok(canceled)
    }

    fn drain_fills(&self) -> Vec<Fill> {
        // Poll for new fills from the API
        match self.runtime.block_on(self.poll_fills_async()) {
            Ok(new_fills) => {
                if !new_fills.is_empty() {
                    // Remove filled order IDs from open_orders tracking
                    if let Ok(mut tracker) = self.open_orders.lock() {
                        let filled_ids: Vec<&str> =
                            new_fills.iter().map(|f| f.order_id.as_str()).collect();
                        tracker.remove_filled(&filled_ids);
                    }

                    if let Ok(mut fills) = self.fills.lock() {
                        fills.extend(new_fills);
                    }
                }
            }
            Err(e) => {
                warn!(error = %e, "alpaca: fill polling error");
            }
        }

        match self.fills.lock() {
            Ok(mut fills) => std::mem::take(&mut *fills),
            Err(_) => {
                error!("alpaca: fills lock poisoned");
                Vec::new()
            }
        }
    }

    fn name(&self) -> &str {
        "alpaca"
    }

    fn fetch_positions(&self) -> Result<Vec<Position>, HorizonError> {
        self.runtime.block_on(self.fetch_positions_async())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_validate_url_param_valid() {
        assert!(validate_url_param("abc-123_def", "test").is_ok());
    }

    #[test]
    fn test_validate_url_param_empty() {
        assert!(validate_url_param("", "test").is_err());
    }

    #[test]
    fn test_validate_url_param_special_chars() {
        assert!(validate_url_param("abc/../etc", "test").is_err());
        assert!(validate_url_param("abc def", "test").is_err());
    }

    #[test]
    fn test_url_encode_query_value_safe_chars() {
        assert_eq!(url_encode_query_value("abc-123_def.txt~v2"), "abc-123_def.txt~v2");
    }

    #[test]
    fn test_url_encode_query_value_special_chars() {
        assert_eq!(url_encode_query_value("a&b=c"), "a%26b%3Dc");
        assert_eq!(url_encode_query_value("foo bar"), "foo%20bar");
    }

    #[test]
    fn test_url_encode_query_value_injection_attempt() {
        // Attempt to inject extra query params
        assert_eq!(
            url_encode_query_value("val&admin=true"),
            "val%26admin%3Dtrue"
        );
        // Attempt to break out of query string
        assert_eq!(
            url_encode_query_value("val#fragment"),
            "val%23fragment"
        );
    }

    #[test]
    fn test_url_encode_query_value_empty() {
        assert_eq!(url_encode_query_value(""), "");
    }
}
