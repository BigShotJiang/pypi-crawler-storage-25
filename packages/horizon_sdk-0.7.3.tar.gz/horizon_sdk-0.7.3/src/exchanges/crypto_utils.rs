//! Shared cryptographic helpers for EVM-based exchange clients.
//!
//! These utilities are used by exchanges that require EIP-712 signing
//! (Polymarket, Limitless, Hyperliquid) to avoid code duplication.

use crate::error::HorizonError;
use k256::ecdsa::{RecoveryId, Signature, SigningKey, VerifyingKey};
use sha3::{Digest, Keccak256};

/// keccak256 hash.
pub fn keccak256(data: &[u8]) -> [u8; 32] {
    let mut hasher = Keccak256::new();
    hasher.update(data);
    let result = hasher.finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(&result);
    out
}

/// Encode a u256 value from u64 into a 32-byte big-endian word.
pub fn u64_to_u256(v: u64) -> [u8; 32] {
    let mut buf = [0u8; 32];
    buf[24..32].copy_from_slice(&v.to_be_bytes());
    buf
}

/// Encode a u256 value from u128 into a 32-byte big-endian word.
pub fn u128_to_u256(v: u128) -> [u8; 32] {
    let mut buf = [0u8; 32];
    buf[16..32].copy_from_slice(&v.to_be_bytes());
    buf
}

/// Parse a decimal string (potentially very large) into a 32-byte u256.
/// Used for token IDs which are large uint256 values.
pub fn decimal_str_to_u256(s: &str) -> Result<[u8; 32], HorizonError> {
    // Parse as u128 if it fits, otherwise do big-number arithmetic
    if let Ok(v) = s.parse::<u128>() {
        return Ok(u128_to_u256(v));
    }

    // For values > u128::MAX, do manual base-10 -> base-256 conversion
    let mut result = [0u8; 32];
    for ch in s.bytes() {
        if !ch.is_ascii_digit() {
            return Err(HorizonError::Validation(format!(
                "Token ID contains non-digit character: {}",
                ch as char
            )));
        }
        let digit = (ch - b'0') as u16;
        // result = result * 10 + digit
        let mut carry = digit;
        for byte in result.iter_mut().rev() {
            let v = (*byte as u16) * 10 + carry;
            *byte = (v & 0xff) as u8;
            carry = v >> 8;
        }
    }
    Ok(result)
}

/// Pad an address (20 bytes) to 32 bytes (left-padded with zeros).
pub fn address_to_u256(addr: &[u8; 20]) -> [u8; 32] {
    let mut buf = [0u8; 32];
    buf[12..32].copy_from_slice(addr);
    buf
}

/// Derive an Ethereum address from a secp256k1 signing key.
pub fn derive_address(key: &SigningKey) -> [u8; 20] {
    let verifying_key = VerifyingKey::from(key);
    let pubkey_bytes = verifying_key.to_encoded_point(false);
    // Uncompressed public key: 0x04 || x(32) || y(32)
    // Address = keccak256(x || y)[12..32]
    let hash = keccak256(&pubkey_bytes.as_bytes()[1..]);
    let mut addr = [0u8; 20];
    addr.copy_from_slice(&hash[12..32]);
    addr
}

/// Parse a private key from hex string (with or without "0x" prefix).
pub fn parse_private_key(hex_str: &str) -> Result<SigningKey, HorizonError> {
    let clean = hex_str.strip_prefix("0x").unwrap_or(hex_str);
    let bytes = hex::decode(clean).map_err(|e| {
        HorizonError::Exchange(format!("invalid private key hex: {}", e))
    })?;
    SigningKey::from_bytes((&bytes[..]).into()).map_err(|e| {
        HorizonError::Exchange(format!("invalid private key: {}", e))
    })
}

/// Sign a 32-byte digest with recoverable ECDSA (returns 65-byte r||s||v signature).
pub fn sign_digest(key: &SigningKey, digest: &[u8; 32]) -> Result<Vec<u8>, HorizonError> {
    let (signature, recovery_id): (Signature, RecoveryId) = key
        .sign_prehash_recoverable(digest)
        .map_err(|e| HorizonError::Exchange(format!("ECDSA sign failed: {}", e)))?;

    let mut sig_bytes = Vec::with_capacity(65);
    sig_bytes.extend_from_slice(&signature.to_bytes());
    sig_bytes.push(recovery_id.to_byte() + 27);
    Ok(sig_bytes)
}

/// Compute an EIP-712 domain separator with the given parameters.
///
///   hashStruct(EIP712Domain) = keccak256(
///     keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"),
///     keccak256(name), keccak256(version), chainId, verifyingContract
///   )
pub fn eip712_domain_separator(
    name: &str,
    version: &str,
    chain_id: u64,
    contract_addr: &[u8; 20],
) -> [u8; 32] {
    let type_hash = keccak256(
        b"EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)",
    );
    let name_hash = keccak256(name.as_bytes());
    let version_hash = keccak256(version.as_bytes());
    let chain_id_bytes = u64_to_u256(chain_id);
    let contract = address_to_u256(contract_addr);

    let mut buf = Vec::with_capacity(5 * 32);
    buf.extend_from_slice(&type_hash);
    buf.extend_from_slice(&name_hash);
    buf.extend_from_slice(&version_hash);
    buf.extend_from_slice(&chain_id_bytes);
    buf.extend_from_slice(&contract);

    keccak256(&buf)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_keccak256_deterministic() {
        let h1 = keccak256(b"hello");
        let h2 = keccak256(b"hello");
        assert_eq!(h1, h2);
        assert_ne!(h1, keccak256(b"world"));
    }

    #[test]
    fn test_u64_to_u256() {
        let result = u64_to_u256(1);
        assert_eq!(result[31], 1);
        assert!(result[..24].iter().all(|&b| b == 0));
    }

    #[test]
    fn test_u128_to_u256() {
        let result = u128_to_u256(1);
        assert_eq!(result[31], 1);
        assert!(result[..16].iter().all(|&b| b == 0));
    }

    #[test]
    fn test_decimal_str_to_u256_small() {
        let result = decimal_str_to_u256("12345").unwrap();
        let expected = u128_to_u256(12345);
        assert_eq!(result, expected);
    }

    #[test]
    fn test_decimal_str_to_u256_invalid() {
        assert!(decimal_str_to_u256("abc").is_err());
    }

    #[test]
    fn test_address_to_u256_padding() {
        let addr = [0xffu8; 20];
        let result = address_to_u256(&addr);
        assert!(result[..12].iter().all(|&b| b == 0));
        assert!(result[12..].iter().all(|&b| b == 0xff));
    }

    #[test]
    fn test_parse_private_key_with_prefix() {
        let hex_key = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80";
        assert!(parse_private_key(hex_key).is_ok());
    }

    #[test]
    fn test_parse_private_key_without_prefix() {
        let hex_key = "ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80";
        assert!(parse_private_key(hex_key).is_ok());
    }

    #[test]
    fn test_parse_private_key_invalid() {
        assert!(parse_private_key("not-hex").is_err());
        assert!(parse_private_key("0x1234").is_err());
    }

    #[test]
    fn test_derive_address_hardhat() {
        let key = parse_private_key(
            "ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
        )
        .unwrap();
        let addr = derive_address(&key);
        let addr_hex = hex::encode(addr);
        assert_eq!(addr_hex, "f39fd6e51aad88f6f4ce6ab8827279cfffb92266");
    }

    #[test]
    fn test_domain_separator_deterministic() {
        let addr = [0u8; 20];
        let ds1 = eip712_domain_separator("Test", "1", 1, &addr);
        let ds2 = eip712_domain_separator("Test", "1", 1, &addr);
        assert_eq!(ds1, ds2);
    }

    #[test]
    fn test_domain_separator_different_params() {
        let addr = [0u8; 20];
        let ds1 = eip712_domain_separator("Test", "1", 1, &addr);
        let ds2 = eip712_domain_separator("Test", "2", 1, &addr);
        assert_ne!(ds1, ds2);
    }
}
