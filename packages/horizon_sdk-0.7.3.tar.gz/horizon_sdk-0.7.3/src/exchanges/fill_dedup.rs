//! Shared fill deduplication for exchange clients.
//!
//! Encapsulates the `seen_fill_ids: HashSet<String>` + `seen_fill_order: VecDeque<String>`
//! pattern with FIFO eviction at a configurable cap, duplicated across Polymarket,
//! Kalshi, Limitless, and Hyperliquid.

use std::collections::{HashSet, VecDeque};

/// Default maximum number of fill IDs to track before FIFO eviction.
const DEFAULT_CAP: usize = 10_000;

/// Deduplicates fill IDs with bounded memory using FIFO eviction.
///
/// Tracks seen fill IDs in a HashSet for O(1) lookup, with a VecDeque
/// maintaining insertion order for oldest-first eviction when the cap
/// is exceeded.
pub struct FillDedup {
    seen: HashSet<String>,
    order: VecDeque<String>,
    cap: usize,
}

impl FillDedup {
    /// Create a new FillDedup with the default cap (10,000).
    pub fn new() -> Self {
        Self {
            seen: HashSet::new(),
            order: VecDeque::new(),
            cap: DEFAULT_CAP,
        }
    }

    /// Check if a fill ID is new (not seen before). If new, records it
    /// and returns `true`. If already seen, returns `false`.
    ///
    /// Automatically evicts the oldest entries when the cap is exceeded.
    pub fn check_and_insert(&mut self, fill_id: &str) -> bool {
        if self.seen.contains(fill_id) {
            return false;
        }
        self.seen.insert(fill_id.to_string());
        self.order.push_back(fill_id.to_string());
        // FIFO eviction: remove oldest when over cap
        while self.seen.len() > self.cap {
            if let Some(oldest) = self.order.pop_front() {
                self.seen.remove(&oldest);
            } else {
                break;
            }
        }
        true
    }
}

impl Default for FillDedup {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_new_fill_returns_true() {
        let mut dedup = FillDedup::new();
        assert!(dedup.check_and_insert("fill_1"));
    }

    #[test]
    fn test_duplicate_fill_returns_false() {
        let mut dedup = FillDedup::new();
        assert!(dedup.check_and_insert("fill_1"));
        assert!(!dedup.check_and_insert("fill_1"));
    }

    #[test]
    fn test_different_fills_both_new() {
        let mut dedup = FillDedup::new();
        assert!(dedup.check_and_insert("fill_1"));
        assert!(dedup.check_and_insert("fill_2"));
    }

    #[test]
    fn test_eviction_at_cap() {
        let mut dedup = FillDedup {
            seen: HashSet::new(),
            order: VecDeque::new(),
            cap: 3,
        };

        assert!(dedup.check_and_insert("fill_1"));
        assert!(dedup.check_and_insert("fill_2"));
        assert!(dedup.check_and_insert("fill_3"));
        // At cap, inserting a 4th should evict fill_1
        assert!(dedup.check_and_insert("fill_4"));
        // fill_1 should have been evicted, so it's "new" again
        assert!(dedup.check_and_insert("fill_1"));
        // fill_2 should still be present (it was 2nd oldest, but fill_1 was evicted)
        // Actually after inserting fill_4, fill_1 was evicted (cap=3, have 4 -> evict 1)
        // After inserting fill_1 again, fill_2 was evicted (cap=3, have 4 -> evict 1)
        assert!(dedup.check_and_insert("fill_2"));
    }
}
