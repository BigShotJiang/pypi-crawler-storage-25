# Autonomous Quant Agent Swarm — Design Document

## Vision

A swarm of LLM-powered autonomous agents, each a self-contained workflow capable of discovering markets, finding alpha, deploying capital, monitoring positions, evolving strategies, and retiring when edges decay. The Hive — a powerful LLM — orchestrates dozens of these workflows in parallel, approving proposals, allocating capital, resolving conflicts, and ensuring the collective intelligence of the swarm grows over time.

No rule-based logic. No hardcoded decision trees. Every decision — from "should I research this market?" to "should I retire this strategy?" — is made by an LLM with full tool access to the Horizon SDK's 230+ mathematical, analytical, and execution operations.

**Critical design principle:** LLMs reason and orchestrate. Math enforces. The LLM decides *what* to analyze and *how* to interpret results, but every risk check, every statistical test, every backtest metric is computed by deterministic Rust/Python functions. The LLM cannot hallucinate a Sharpe ratio — it must call `deflated_sharpe()` and read the result. The LLM cannot override a risk limit — the Rust engine rejects the order before it reaches the exchange.

---

## 1. Core Paradigm: Workflows, Not Roles

```
┌──────────────────────────────────────────┐
│                 THE HIVE                  │
│          (Powerful LLM — Opus)            │
│   Approves, allocates, resolves, learns  │
└─────────┬──────────┬──────────┬──────────┘
          │          │          │
    ┌─────▼────┐ ┌───▼──────┐ ┌▼─────────┐
    │  Agent 1 │ │ Agent 2  │ │ Agent N   │
    │ Workflow  │ │ Workflow │ │ Workflow  │    ... dozens
    │  Box      │ │  Box     │ │  Box      │
    └──────────┘ └──────────┘ └───────────┘
```

Each **Agent** is a complete, autonomous workflow — a "box" — powered by its own LLM instance. It can move fluidly through any phase. It is not a specialist. It is a quant trader in a box — it can research, analyze, backtest, execute, monitor, evolve, and retire strategies entirely on its own. It escalates to the Hive only for capital deployment approval and conflict resolution.

```
┌──────────────────────────────────────────────────────────────┐
│                      AGENT WORKFLOW BOX                       │
│                                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐   │
│  │ Research  │→│ Analysis │→│ Backtest │→│  Robustness  │   │
│  └──────────┘ └──────────┘ └──────────┘ └──────┬───────┘   │
│                                                  ↓           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐   │
│  │  Post-   │←│ Retire/  │←│ Monitor  │←│  Execution   │   │
│  │  Mortem  │ │  Evolve  │ │ & Track  │ │              │   │
│  └──────────┘ └──────────┘ └──────────┘ └──────────────┘   │
│       │                          ↑                           │
│       └──────────────────────────┘ (loop back to research)   │
│                                                              │
│  LLM Brain: full reasoning about what to do next             │
│  Tools: 230+ SDK operations (math, analytics, execution)     │
│  Memory: shared knowledge graph (reads + writes)             │
│  Comms: WebSocket bus (real-time events from all agents)     │
└──────────────────────────────────────────────────────────────┘
```

---

## 2. The Hive (Orchestrator LLM)

The Hive is a single, powerful LLM (Claude Opus-class) that runs continuously. It is the swarm's brain. It does not compute anything — it reads computations from agents and reasons about them in context.

**What the Hive does:**
- Reviews agent proposals (with full reasoning chain, quantitative evidence, and overfitting proofs)
- Approves or rejects capital deployment — the Hive is a justification system
- Allocates capital across the swarm
- Resolves conflicts (two agents targeting the same market)
- Issues strategic directives (regime shifts, sector limits)
- Spawns and kills agents based on swarm needs
- Synthesizes learnings from all agents into collective intelligence

**The Hive as Justification System:**

Agents cannot deploy capital on their own. They must present their case to the Hive with:
1. The hypothesis and reasoning chain (why they believe an edge exists)
2. Quantitative evidence (alpha estimate, backtest metrics, statistical tests)
3. Anti-overfitting proof (all five gates passed — see Section 5)
4. Risk assessment (portfolio impact, correlation, regime sensitivity)
5. What could go wrong and how they'll handle it

The Hive reads all of this — not as raw numbers, but as a structured argument — and makes a judgment call with full context of the portfolio, other agents' positions, the current regime, and historical outcomes of similar strategies from the knowledge graph.

```
Hive receives proposal from Agent-7:

  Hypothesis: "Fed funds futures lead the Polymarket 'rate cut' market
               by 2 days. Current divergence = 7 cents. Edge is structural
               — market participants are slower to price macro data."

  Evidence:
    granger_test: p=0.008 (fed futures → polymarket, lag=2)
    lead_lag_network: fed_futures leads polymarket (corr=0.82 at lag 2)
    alpha_model: composite=+0.28, confidence=0.72
    kelly_sizing: optimal fraction=0.12, half-kelly=$6,000
    backtest: Sharpe=1.6, max DD=7%, 150 trades, profit_factor=1.8
    walk_forward: 68% OOS consistency across 5 folds
    cpcv: PBO=0.18 (not overfit), OOS Sharpe median=1.2
    deflated_sharpe: p=0.02 after 15-trial correction
    bootstrap_edge: 95% CI [0.03, 0.11] — lower bound > 0
    robustness: permutation p=0.01, outcome_rand p=0.02, path_sim OK
    regime_sensitivity: calm=1.8 Sharpe, volatile=0.9, crisis=0.3

  Risk:
    correlation_with_portfolio: 0.15
    max_loss: -$600 (stress test)
    var_impact: +2% to portfolio VaR

  Acknowledged risks:
    "Edge weakens in volatile regime (0.9 Sharpe). Will auto-reduce
     size 50% if regime shifts. Stop-loss at 10% drawdown."

Hive reasons:
  "Strong evidence. Granger causality is statistically significant.
   PBO is 0.18 — well below 0.5 threshold. Walk-forward holds up.
   Bootstrap CI lower bound is 3 cents — edge is real.

   But: we already have 3 macro strategies. Adding this makes 4.
   Correlation 0.15 looks low, but in crisis regime (their own data
   shows Sharpe 0.3) all macro markets correlate. Let me check the
   knowledge graph for similar past strategies...

   [reads: 'Rate market strategies avg lifetime 40d, avg Sharpe 1.1.
    Last one retired 12d ago — edge decayed as FOMC approached.']

   This aligns — FOMC is in 50 days, so there's a window. But I'll
   limit capital to prevent over-concentration in macro.

   APPROVED: $4,000 (reduced from $6,000). Conditions:
   - Mandatory review at day 30 (historical lifetime ~40d)
   - Auto-scale down 50% if crypto_macro allocation exceeds 30%
   - Must pass through paper (14d) and shadow (7d) before live"
```

---

## 3. The Full Pipeline: Every Step Inside the Box

This is the complete workflow an agent follows from market discovery to post-mortem. The LLM orchestrates every step, but each computation is performed by the SDK's mathematical tools.

### Phase 1: Research — Finding Opportunities

The agent scans for markets worth investigating. This is not random browsing — the LLM reasons about where to look based on knowledge graph intelligence, current events, and gaps in the swarm's coverage.

```
Step 1.1: Strategic Focus
  LLM reasons: "What should I look for?"
  Inputs: Hive directives, knowledge graph gaps, calendar events
  Example: "Hive wants Kalshi diversification. Economic calendar shows
            CPI release in 3 days. I'll look for inflation-related markets."

Step 1.2: Market Discovery
  Tools:
    discover_markets(exchange, query, limit, category, sort_by)
    discover_events(exchange, query, limit)
    top_markets(exchange, limit, category)
    economic_calendar()    — upcoming macro events
    news()                 — breaking headlines
  Output: List of candidate markets with basic metadata

Step 1.3: Smart Money Analysis
  For each promising candidate:
  Tools:
    wallet_flow(condition_id)           — net buy/sell pressure
    wallet_top_holders(condition_id)    — who holds the most
    whale_galaxy(max_markets)           — whale clusters
    wallet_profile(address)             — behavioral profile of top wallets
    unusual_whales_dark_pool(ticker)    — dark pool activity
    unusual_whales_congress(ticker)     — congressional trading
    unusual_whales_insider(ticker)      — insider transactions
    unusual_whales_options_flow(ticker) — smart options flow
  Output: Smart money thesis (who's positioned, which direction, conviction)

Step 1.4: Cross-Reference with Knowledge Graph
  Tools:
    query_knowledge(market_id)          — has anyone analyzed this before?
    query_knowledge(entity_type="market", related_to=...)
  Output: Prior analysis, past strategy outcomes, known correlations

Step 1.5: Market Microstructure Check
  Tools:
    get_market_detail(slug)             — full orderbook, trades, metadata
    feed_start(name, type, config)      — start real-time feed
    feed_snapshot(name)                 — current bid/ask/spread
    shannon_entropy(implied_prob)       — market uncertainty
  Output: Liquidity assessment, spread, depth, activity level

  LLM reasons about all of this:
  "This CPI market has $1.5M daily volume, 2-cent spread, high entropy
   (uncertain outcome). Congress bought inflation hedges last week.
   Dark pool shows institutional interest. Knowledge graph says no other
   agent is covering this. Worth deep analysis."
```

### Phase 2: Analysis — Finding the Edge

The agent transitions from "is this interesting?" to "is there a quantifiable, tradeable edge?" Every claim must be backed by a mathematical computation.

```
Step 2.1: Data Preparation (AFML)
  Tools:
    market_data_aggregates(ticker, from, to)  — historical OHLCV
    tick_bars(trades, bar_size)                — information-driven bars
    volume_bars(trades, target_volume)         — volume-normalized bars
    dollar_bars(trades, target_dollar)         — dollar-normalized bars
    frac_diff(series, d, threshold)            — stationarity without losing memory
    min_frac_diff(series, p_threshold)         — minimum d for stationarity
  Output: Clean, stationary, information-sampled data

  Why: Raw time bars oversample quiet periods and undersample volatile ones.
  AFML bars (tick/volume/dollar) give better statistical properties.
  Fractional differentiation preserves memory while achieving stationarity —
  critical for ML-based alpha models.

Step 2.2: Alpha Factor Analysis
  Tools:
    alpha_model_estimate(market_id, price, volume, ...)   — 7-factor model
      Factor 1: Liquidity (volume ratio vs median)
      Factor 2: Momentum (recent price change)
      Factor 3: Mean reversion (distance from 0.5)
      Factor 4: Event proximity (1/(1+days_to_expiry))
      Factor 5: Spread (current vs historical)
      Factor 6: Cross-market (price divergence across exchanges)
      Factor 7: Entropy (Shannon entropy of implied probability)

    signal_diagnostics(predictions, outcomes)   — IC, hit rate, half-life
    information_coefficient(predictions, outcomes)
    signal_half_life(signal)
  Output: Per-factor IC, composite alpha, confidence

Step 2.3: Causal Discovery (Not Just Correlation)
  Tools:
    granger_test(x, y, max_lag)                — does X predict Y?
    lead_lag_analysis(series_a, series_b)       — who leads whom?
    lead_lag_network(all_series, names)          — multi-asset lead-lag graph
    cross_correlation_lags(x, y, max_lag)       — lag structure
    market_graph_analysis(corr_matrix, names)    — network centrality
  Output: Causal links (not just correlations), lead-lag relationships

  Critical: Correlation is not causation. The agent must find causal links.
  "BTC spot Granger-causes this prediction market (p=0.008, lag=2 days)"
  is much stronger than "BTC spot is correlated with this market (r=0.8)."

Step 2.4: Tail Dependency and Hidden Correlations
  Tools:
    copula_fit(u, v, family)                   — joint distribution modeling
    best_copula(u, v)                          — best family by AIC
    vine_copula_fit(data)                      — multivariate dependency
    vine_tail_risk(data, threshold)            — joint tail probability
    correlation_regime(returns_a, returns_b)    — time-varying correlation
    contagion_score(returns_matrix)             — systemic risk
    cross_impact_matrix(returns, volumes)       — cross-asset impact
    entropy_pooling(scenarios, views)           — Bayesian view combination
  Output: Hidden dependency structure, tail risks, regime-conditional relationships

  Why: Linear correlation misses everything important:
  - Two assets uncorrelated in normal times but 0.95 correlated in crisis
  - Tail dependencies (both crash together even if daily returns are uncorrelated)
  - Non-linear relationships (Clayton copula captures lower-tail clustering)

  The LLM reasons about these:
  "Copula analysis shows Clayton (lower tail) fits best. Tail dependence = 0.4.
   This means in a market crash, these two markets move together 40% of the time
   even though daily correlation is only 0.3. I need to factor this into position
   sizing — my portfolio is more exposed to crash risk than it looks."

Step 2.5: Regime Context
  Tools:
    regime_detect()                            — HMM 3-state classification
    bocpd_detect(observations, hazard_rate)    — change point detection
    cusum_filter(prices, threshold)            — structural break detection
    kalman_filter_state(observations)          — latent state estimation
    hurst_exponent(returns)                    — trend vs mean-reversion
    variance_ratio_test(returns, period)       — market efficiency
    market_efficiency_test(prices)             — combined efficiency score
  Output: Current regime, recent structural breaks, market character

  Why: A strategy that works in calm markets can blow up in volatile ones.
  The agent must know what regime it's in and how the edge behaves per regime.

Step 2.6: Cross-Market Pattern Discovery
  Tools:
    correlation_matrix(returns_matrix)          — Ledoit-Wolf shrinkage
    detect_regime_shift(hist, recent, threshold) — correlation breakdowns
    find_decorrelated(correlations, threshold)   — diversification opportunities
    contagion_alert(feeds, threshold)            — contagion monitoring
    cross_asset_edge(prices_a, strikes_a, prices_b, strikes_b) — risk-neutral edge
    beta_decompose(strategy, benchmark)          — factor exposure
  Output: Non-obvious relationships, clustering, contagion risk

  This is where the agent finds things humans miss:
  "The weather market in Florida and the orange juice futures are 0.7
   correlated with a 3-day lag. A hurricane warning causes OJ futures
   to spike, and 3 days later the Kalshi 'hurricane category 4+' market
   reprices. I can use OJ futures as a leading indicator."

Step 2.7: Edge Quantification
  Tools:
    kelly_sizing(prob, price, bankroll, fraction, max_size) — optimal size
    cornish_fisher_var(returns, confidence)                  — tail-adjusted VaR
    prediction_greeks(price, size, is_yes, t_hours, vol)     — binary market Greeks
    logit_reservation_price(mid, inventory, gamma, belief_vol) — fair value
    hjb_optimal_quotes(inventory, gamma, sigma, kappa)       — optimal spread
  Output: Exact edge in dollars, optimal position size, optimal spread

  The LLM synthesizes: "My edge is 3.2 cents on the YES side. Kelly says
  optimal position is $8,000 at half-Kelly. Avellaneda-Stoikov optimal spread
  is 1.8 cents given current inventory and volatility."
```

### Phase 3: Backtest — Proving the Edge Exists

Not a single backtest run. A multi-step process that simulates the strategy under realistic conditions.

```
Step 3.1: In-Sample Backtest
  Tools:
    backtest(pipeline, markets, data, fees, slippage)
  Metrics computed automatically (Rust):
    sharpe_ratio, sortino_ratio, calmar_ratio
    max_drawdown, max_drawdown_pct, max_drawdown_duration
    win_rate, profit_factor, expectancy
    avg_win, avg_loss, largest_win, largest_loss
    brier_score, edge_capture, adverse_selection
  Output: Full BacktestResult with Metrics object

Step 3.2: Transaction Cost Modeling
  The backtest includes realistic costs:
    - Exchange fees (maker/taker)
    - Spread crossing cost
    - Market impact (via kyle_obizhaeva_impact or stealth_estimate)
    - Slippage estimation
  Tools:
    invariance_analysis(dollar_volume, vol, n_trades, avg_size) — impact model
    stealth_estimate(market_id, size)                            — predicted impact
    queue_fill_probability(queue_size, position, arrival, cancel) — fill modeling
  Output: Cost-adjusted returns (the REAL returns, not idealized)

Step 3.3: Calibration Check
  Tools:
    backtest_result.calibration(n_bins=10)
  Output: Predicted probabilities vs actual outcomes curve

  If the strategy says "70% chance of YES" and it's right 70% of the time,
  it's well-calibrated. If it says 70% and is right 50%, it's delusional.
  The LLM checks: "Calibration curve is tight — max deviation 5%. Good."
```

### Phase 4: Robustness — The Five Anti-Overfitting Gates

This is the most critical phase. **A strategy that looks good in backtest but is overfit will lose real money.** The agent must pass ALL FIVE GATES before it can propose deployment. No exceptions. The Hive will reject any proposal missing a gate.

```
┌────────────────────────────────────────────────────────────┐
│              THE FIVE ANTI-OVERFITTING GATES                │
│                                                             │
│  Gate 1: Statistical Significance                           │
│  Gate 2: Out-of-Sample Validation                           │
│  Gate 3: Combinatorial Purged Cross-Validation (PBO)        │
│  Gate 4: Stochastic Robustness                              │
│  Gate 5: Structural Validation                              │
│                                                             │
│  ALL FIVE must pass. One failure = no deployment.            │
│  Every gate is computed by SDK math. LLM cannot fake them.  │
└────────────────────────────────────────────────────────────┘
```

#### Gate 1: Statistical Significance

The backtest Sharpe might look good, but is it statistically distinguishable from luck?

```
Tools:
  deflated_sharpe(
    sharpe=1.6,          # observed Sharpe
    n_obs=150,           # number of trades
    n_trials=15,         # total hypotheses the agent has tested
    skew=-0.3,           # return distribution skew
    kurt=4.2             # return distribution kurtosis
  ) → p_value

  benjamini_hochberg(
    p_values=[...],      # p-values from ALL hypotheses (this agent + others)
    alpha=0.05           # false discovery rate
  ) → [survives: bool]

Pass criteria:
  - deflated_sharpe p-value < 0.05
  - Survives Benjamini-Hochberg correction across ALL active hypotheses
  - n_obs >= 50 (minimum trades for statistical power)

Why deflated Sharpe:
  Standard Sharpe doesn't account for:
  - How many strategies you tested before finding this one (selection bias)
  - Non-normal returns (skew and kurtosis inflate apparent Sharpe)
  - Small sample size (150 trades is not 10,000)
  Deflated Sharpe adjusts for ALL of these. A 1.6 Sharpe with 15 trials
  might have a p-value of 0.15 — not significant. The LLM cannot argue
  around this — the math is definitive.

Why Benjamini-Hochberg:
  If the swarm has 20 agents each testing 10 hypotheses, that's 200 tests.
  By chance, 10 will have p < 0.05. BH controls the false discovery rate
  across the entire swarm, not just one agent's tests.
```

#### Gate 2: Out-of-Sample Validation (Walk-Forward)

The strategy must work on data it has never seen.

```
Tools:
  walk_forward(
    data=price_data,
    pipeline_factory=strategy_factory,
    param_grid=param_space,
    n_splits=5,           # 5 train/test windows
    train_ratio=0.7,      # 70% train, 30% test
    expanding=True,       # anchored walk-forward
    objective="sharpe_ratio",
    purge_gap=0.05        # 5% embargo between train/test (prevent leakage)
  ) → WalkForwardResult

Pass criteria:
  - OOS consistency >= 60% (at least 3 of 5 windows profitable)
  - OOS Sharpe median > 0.5 (not just lucky in one window)
  - No single window with catastrophic loss (max DD < 2× in-sample)
  - OOS/IS Sharpe ratio > 0.5 (edge doesn't collapse out of sample)

Why purge gap:
  Without it, the test set can be contaminated by serial correlation
  with the training set. A 5% gap ensures clean separation.

Why expanding (not rolling):
  Expanding windows simulate what a live strategy would experience —
  you train on all available history, not just a fixed window.
  This is more realistic and conservative.
```

#### Gate 3: Combinatorial Purged Cross-Validation with PBO

The gold standard for overfitting detection. Tests every possible train/test split.

```
Tools:
  cpcv(
    data=price_data,
    pipeline_factory=strategy_factory,
    param_grid=param_space,
    n_groups=8,            # 8 segments → C(8,4)=70 combinations
    purge_gap=0.05,        # embargo between segments
    max_combinations=500   # cap for computational budget
  ) → CPCVResult
    .pbo                   # Probability of Backtest Overfitting [0,1]
    .oos_sharpes           # OOS Sharpe for every combination
    .is_overfit            # True if PBO > 0.5
    .n_combinations        # How many splits were tested

Pass criteria:
  - PBO < 0.40 (probability of overfitting < 40%)
  - Median OOS Sharpe > 0 (more than half of combinations are profitable)
  - PBO is NOT something the LLM estimates — it's computed from the
    empirical distribution of IS vs OOS performance across all splits

Why this matters:
  PBO answers the question: "If I picked the best parameters in-sample,
  what is the probability that they would perform worse than the median
  out of sample?" If PBO > 0.5, the strategy is more likely overfit
  than not — regardless of how good the backtest looks.

  This is the most powerful anti-overfitting test that exists. Most
  quant funds don't even use it. The fact that it's built into the SDK
  means agents can run it on every hypothesis automatically.
```

#### Gate 4: Stochastic Robustness

Does the strategy survive random variations of reality?

```
Tools:
  # Test 1: Bootstrap confidence interval for edge
  bootstrap_edge(
    predictions=model_predictions,
    outcomes=actual_outcomes,
    n_resamples=1000,
    confidence=0.95,
    seed=42
  ) → BootstrapResult
    .ci_lower, .ci_upper   # 95% confidence interval for edge
    .std_error, .bias      # estimation quality

  # Test 2: Monte Carlo portfolio simulation
  simulate_portfolio(
    scenarios=500,
    seed=42
  ) → SimulationResult
    .var_95, .cvar_95, .max_loss
    .win_probability, .probability_of_ruin

  # Test 3: Stress testing (4 adversarial scenarios)
  stress_test(
    n_simulations=200,
    seed=42
  ) → StressTestResult
    Scenario 1: Correlation spike (all correlations → 0.95)
    Scenario 2: All markets resolve NO (worst case for long positions)
    Scenario 3: Liquidity shock (volume drops 90%)
    Scenario 4: Tail risk (correlations → 0.99, extreme moves)

  # Test 4: Permutation test (is the edge real or random?)
  permutation_test(backtest_result, n_permutations=1000)
    → p_value (probability of getting this PnL by chance)

  # Test 5: Outcome randomization (does direction matter?)
  outcome_randomization_test(backtest_result, n_simulations=1000)
    → p_value (probability with random outcomes)

  # Test 6: Path simulation (is the path stable?)
  path_simulation(backtest_result, n_simulations=1000)
    → drawdown percentiles, consecutive loss distribution

  # Test 7: Jackknife stability
  jackknife_sharpe(returns) → bias-corrected Sharpe estimate
  jackknife_max_drawdown(returns) → bias-corrected max DD

Pass criteria:
  - Bootstrap edge CI lower bound > 0 (edge exists with 95% confidence)
  - Monte Carlo probability of ruin < 5%
  - All 4 stress scenarios: max loss < 20% of allocated capital
  - Permutation test p < 0.05 (edge is not random)
  - Outcome randomization p < 0.05 (direction matters)
  - Path simulation: 95th percentile max DD < 2× backtest max DD
  - Jackknife Sharpe within 20% of raw Sharpe (stable estimate)
```

#### Gate 5: Structural Validation

The edge must have a plausible causal mechanism and survive across regimes. This is where the LLM's reasoning adds value on top of the math.

```
Sub-gate 5a: Causal mechanism exists
  The LLM must articulate WHY the edge exists, backed by causal tests:
  - granger_test confirms directional causality (not just correlation)
  - lead_lag_analysis shows a stable lead-lag relationship
  - The mechanism is economically plausible (not just a statistical artifact)

  Example of GOOD causal reasoning:
  "Fed funds futures lead this prediction market by 2 days because
   institutional traders reprice futures first (faster, more liquid)
   and retail prediction market participants follow with a lag.
   Granger test p=0.008 confirms this causal direction."

  Example of BAD reasoning (would be rejected):
  "The backtest shows Sharpe 2.0, so there must be an edge."
  (This is circular. The Hive would reject immediately.)

Sub-gate 5b: Regime robustness
  Tools:
    regime_detect() — current regime classification
    correlation_regime(returns_a, returns_b) — time-varying correlation

  The strategy must show Sharpe > 0 in at least 2 of 3 regimes:
    calm:     target Sharpe > 0.5
    volatile: target Sharpe > 0 (breakeven is acceptable)
    crisis:   allowed to be negative, but max DD must be contained

  If the strategy only works in one regime, it's fragile. The agent
  must demonstrate it knows which regimes are dangerous and has a plan.

Sub-gate 5c: Not a duplicate of existing strategies
  Tools:
    correlation_matrix() across all active strategy returns
    beta_decompose(new_strategy, existing_portfolio)

  If correlation with any existing strategy > 0.7, the new strategy
  is likely the same edge repackaged. The Hive will reject it unless
  the agent can demonstrate it captures genuinely different alpha
  (e.g., incremental Sharpe improvement to portfolio).

Sub-gate 5d: Parameter sensitivity
  Tools:
    bayesian_optimize() or evolution_optimize() — search param space

  The strategy must work across a range of parameters, not just one
  specific setting. If changing spread from 2% to 2.5% kills the
  edge, the strategy is fragile and likely overfit to that parameter.

  Test: perturb each parameter ±20%. Strategy must remain Sharpe > 0.5
  for all perturbations.
```

### Phase 5: Execution — Deploying and Trading

After all five gates pass, the agent submits a proposal to the Hive. If approved, it begins execution through the promotion pipeline: paper → shadow → live.

```
Step 5.1: Paper Trading (14 days minimum)
  The agent runs hz.run() with the paper exchange. No real capital.
  Purpose: Validate that the strategy works in real-time (not just backtest)

  Each execution cycle (0.5-2 seconds):
  Tools:
    get_feed_snapshot(feed_name)          — current price/bid/ask
    engine_status()                       — positions, P&L, orders
    submit_order(market, side, price, size)
    cancel_order(order_id)
    cancel_market(market_id)
    add_stop_loss(market, side, trigger)
    add_take_profit(market, side, trigger)
    hjb_optimal_quotes(inventory, ...)     — Avellaneda-Stoikov optimal quotes
    logit_reservation_price(mid, inventory, gamma, belief_vol)

  The LLM decides EVERY order. Not a fixed algorithm.
  It reads the orderbook, checks VPIN toxicity, considers inventory,
  reasons about the current situation, and decides what to quote.

Step 5.2: Shadow Trading (7 days minimum)
  Same as paper, but with LIVE feeds and LIVE orderbook data.
  No real execution — simulated fills at market prices.
  Purpose: Validate that paper performance tracks live reality.

  Shadow validation:
  - Tracking error between paper fills and live prices < 3%
  - Fill rate realistic (not assuming instant fills at mid)
  - Spread crossing cost matches real orderbook depth

Step 5.3: Live Trading
  Real orders on real exchanges. The agent has full execution tools:

  Standard execution:
    submit_order, cancel_order, cancel_market
    add_stop_loss, add_take_profit

  Advanced execution (when the LLM decides it's warranted):
    stealth_execute(market, side, size, strategy="twap")     — time-weighted avg
    stealth_execute(market, side, size, strategy="iceberg")  — hidden size
    stealth_execute(market, side, size, strategy="sniper")   — aggressive fill
    gp_optimal_execution(pos, target, decay, impact, ...)    — Gatheral-Schied
    ac_optimal_liquidation(shares, steps, vol, impact, ...)  — Almgren-Chriss

  Execution quality monitoring:
    stealth_estimate(market, size)                            — predicted impact
    invariance_analysis(dollar_vol, vol, n_trades, avg_size)  — market quality
    queue_fill_probability(queue, position, arrival, cancel)  — fill probability

  The LLM reasons about execution:
  "I need to buy 500 contracts. Orderbook depth is only 200 at the best bid.
   If I place 500 at once, I'll move the market ~2 cents. Let me use TWAP
   over 60 seconds to reduce impact. stealth_estimate says impact drops
   from 2 cents to 0.5 cents with TWAP."
```

### Phase 6: Monitoring and Tracking

The agent doesn't just execute and forget. It continuously monitors every aspect of its running strategy.

```
Step 6.1: P&L and Performance Tracking
  Tools:
    engine_status()                — real-time P&L, drawdown
    portfolio_metrics()            — portfolio-level metrics
    list_positions()               — current exposure
    list_recent_fills()            — execution quality
    list_open_orders()             — order state

Step 6.2: Alpha Decay Detection
  Tools:
    bootstrap_edge(recent_preds, recent_outcomes) — is edge still there?
    signal_diagnostics(predictions, outcomes)       — IC decay
    signal_half_life(signal_values)                 — how fast is it decaying?
    market_efficiency_test(recent_prices)            — is the market learning?
    vulnerability_score(returns)                     — portfolio fragility

  The agent tracks:
  - Rolling 30-day Sharpe (vs backtest baseline)
  - IC trend (increasing, stable, or declining)
  - Signal half-life (if shrinking, edge is disappearing)
  - Market efficiency score (if increasing, others found the edge too)

Step 6.3: Regime Monitoring
  Tools:
    regime_detect()                                 — current regime
    bocpd_detect(observations)                      — change point detection
    cusum_filter(prices, threshold)                 — structural breaks
    correlation_regime(strategy_returns, market)     — correlation shifts
    contagion_score(returns_matrix)                  — systemic risk

  The agent watches for:
  - Regime transitions (calm → volatile → crisis)
  - Structural breaks in the price process
  - Correlation regime shifts (stable relationships breaking down)
  - Contagion events (one market crashing affects others)

Step 6.4: External Signal Monitoring
  Tools:
    unusual_whales_news()                           — breaking news
    unusual_whales_options_flow(ticker)              — smart money flow
    wallet_flow(condition_id)                        — whale activity
    whale_galaxy()                                   — whale cluster changes
    economic_calendar()                              — upcoming events

  The agent reacts to external events:
  "Breaking news: SEC announces crypto regulation hearing. My BTC strategy
   might be affected. Let me check whale reaction... Whales are selling.
   I'll widen spreads and reduce size while I analyze the implications."

Step 6.5: Cross-Agent Signal Processing
  Via WebSocket bus, the agent receives signals from other agents:
  - MarketSignal: whale activity, regime changes, anomalies
  - RiskAlert: portfolio-level warnings from the Hive
  - KnowledgeUpdate: new facts about related markets
  - HiveDirective: regime changes, sector limits, strategic shifts

  The agent processes these in context:
  "Agent-3 detected correlation breakdown between ETH and BTC prediction
   markets. My strategy uses BTC-ETH correlation for hedging. Let me
   re-estimate the hedge ratio with the Kalman filter..."

  [calls kalman_hedge_ratio(btc_feed, eth_feed)]
  [updates hedge parameters in real-time]

Step 6.6: Execution Quality Analysis
  Tools:
    toxic_flow(feed, bucket_volume, n_buckets, threshold) — VPIN toxicity
    microstructure(feed, lookback)                         — OFI, Kyle's lambda
    hawkes_intensity(feed, mu, alpha, beta)                — order clustering

  The agent detects:
  - Toxic order flow (informed traders picking off stale quotes)
  - Adverse selection (consistently filled on the wrong side)
  - Order clustering (unusual burst of activity → potential manipulation)

  Response: "VPIN spiked to 0.85. Toxic flow detected. Widening spread
  from 2c to 4c and reducing size by 50% until toxicity subsides."
```

### Phase 7: Evolution — Adapting to Change

When the agent detects degradation, it doesn't just retire — it first tries to evolve.

```
Step 7.1: Diagnose the Problem
  The LLM reasons about WHY performance is declining:
  - Alpha decay? (edge is shrinking because others found it)
  - Regime shift? (strategy doesn't work in new regime)
  - Parameter drift? (optimal parameters changed with market conditions)
  - Structural break? (the causal mechanism broke)
  - Execution degradation? (fills getting worse, more adverse selection)

Step 7.2: Attempt Evolution
  Depending on diagnosis:

  If parameter drift:
    Tools:
      bayesian_optimize(param_bounds, n_trials=50)     — GP-based tuning
      evolution_optimize(param_names, mins, maxs)       — evolutionary search
      update_params(new_params)                         — hot-swap parameters
    The agent re-optimizes parameters on recent data.
    Must re-pass Gates 1-4 on the new parameters before deploying.

  If regime shift:
    Tools:
      regime_detect()                                   — confirm regime
      correlation_regime()                              — how correlations changed
    Adjust position sizing and spreads for new regime.
    If strategy Sharpe < 0.3 in new regime → proceed to retirement.

  If alpha decay:
    Re-run alpha model with fresh data.
    If new edge found → form new hypothesis, re-validate through all 5 gates.
    If no edge → proceed to retirement.

  If structural break:
    Re-run causal tests (Granger, lead-lag).
    If causal link broken → retire immediately (the thesis is dead).
    If causal link holds → the break was temporary, re-enter cautiously.

Step 7.3: Evolution Proposal to Hive
  If the agent wants to significantly change its strategy, it submits
  a new proposal to the Hive:
  "My fed rate strategy's original thesis (futures lead prediction market
   by 2 days) has weakened. Granger p-value increased from 0.008 to 0.04.
   However, I found a new signal: Treasury bid-to-cover ratio leads the
   market by 1 day (Granger p=0.01). I've re-backtested with this signal.
   New metrics: Sharpe 1.3, PBO 0.22. Requesting continuation with
   updated parameters."
```

### Phase 8: Retirement and Post-Mortem

When the edge is truly gone, the agent performs a rigorous shutdown and post-mortem analysis that becomes permanent knowledge for the swarm.

```
Step 8.1: Graceful Position Closure
  Tools:
    ac_optimal_liquidation(shares, steps, vol, impact, risk_aversion)
    cancel_all_orders()
    list_positions() — verify all positions closed
    engine_status()  — verify clean state
  The agent doesn't dump positions — it uses Almgren-Chriss optimal
  liquidation to minimize market impact on the way out.

Step 8.2: Final Performance Attribution
  Tools:
    beta_decompose(strategy_returns, benchmark)  — alpha/beta separation
    generate_tearsheet(equity_curve, trades)      — full performance report

  Decompose total P&L into:
  - Alpha (pure strategy edge, net of fees and impact)
  - Beta (market exposure, what you'd have gotten from passive)
  - Cost drag (fees, spread, slippage, market impact)
  - Luck (deviation from expected based on confidence intervals)

Step 8.3: Post-Mortem Analysis
  The LLM writes a structured post-mortem covering:

  1. SUMMARY
     "Fed rate market-making strategy. Ran 50 days. Total P&L: +$1,200
      (18% return on $6,000 capital). Sharpe 1.3 (lifetime)."

  2. WHAT WORKED
     - Treasury yield lead-lag signal (Granger p=0.008)
     - Avellaneda-Stoikov spread optimization (reduced adverse selection 30%)
     - VPIN toxicity detection (avoided 3 toxic flow events)
     - Regime-conditional sizing (50% reduction in volatile periods)

  3. WHAT DIDN'T WORK
     - Cross-market correlation with Kalshi KXRATE was unstable
     - Momentum factor had negative IC in last 10 days (market reversed)
     - Hedge with ETH market was ineffective (correlation broke down)

  4. WHY THE EDGE DECAYED
     "Market efficiency improved from 0.6 to 0.92 over 50 days.
      Variance ratio test shows the market became a random walk.
      Hypothesis: other participants (likely MM bots) discovered
      the same lead-lag signal and arbitraged it away."

  5. KEY METRICS AT RETIREMENT
     Alpha decay half-life: 35 days
     Edge type: temporary (as predicted by initial analysis)
     Final IC: 0.02 (down from 0.15 at deployment)
     Final Sharpe (last 10d): 0.4 (down from 1.6 at deployment)

  6. LESSONS FOR THE SWARM
     - Rate-related markets have ~35-50 day edge windows
     - Enter within 7 days of hypothesis formation (edge decays fast)
     - Market efficiency > 0.85 is the exit signal (don't wait for 0.95)
     - Lead-lag signals in macro markets are temporary — others find them
     - OJ futures → hurricane markets lead-lag is still unexploited (tip for other agents)

Step 8.4: Knowledge Graph Enrichment
  Tools:
    publish_knowledge(entity_type="market", facts=[...])
    publish_knowledge(entity_type="strategy_outcome", facts=[...])

  Written to knowledge graph:
  - Market entity: updated with final outcome data
  - Strategy outcome: full metrics, edge type, decay profile
  - Causal relationships: confirmed or invalidated
  - Lessons learned: searchable by future agents
  - Tips: specific leads for other agents to investigate

Step 8.5: Capital Release and Restart
  Capital returns to pool. The Hive is notified.
  The agent loops back to Phase 1: Research.
  It carries the knowledge of what it learned — both in its own context
  and in the knowledge graph for all agents to access.
```

---

## 4. Mathematically Enforced Risk

### Design Principle: LLMs Reason, Math Enforces

The fundamental risk architecture separates **judgment** (LLM) from **enforcement** (Rust/Python math). An LLM can hallucinate, be overly optimistic, or talk itself into excessive risk. The mathematical enforcement layer makes this irrelevant.

```
LLM decides: "I want to buy 1000 contracts at 0.95"

Rust risk pipeline evaluates (in microseconds, no LLM involved):
  ✗ Check 1 (kill switch): PASS
  ✗ Check 2 (price bounds): PASS (0 < 0.95 < 1.0)
  ✗ Check 3 (size bounds): FAIL — max_size=500
  → ORDER REJECTED

The LLM cannot argue. It cannot override. It cannot "reason" its way
past the risk check. The Rust engine simply rejects the order and
returns a RiskRejection. The LLM sees: "Order rejected: size 1000
exceeds limit 500" and must adjust.
```

### Layer 0: Rust Engine (Per-Order, Microseconds)

Every single order — no exceptions — passes through 8 checks in Rust:

```
1. Kill Switch     — Is the kill switch active? → REJECT ALL
2. Price Bounds    — 0 < price < 1 for prediction markets → REJECT
3. Size Bounds     — size > 0 and size <= max_order_size → REJECT
4. Position Limit  — projected_position <= max_position → REJECT
5. Notional Limit  — projected_notional <= max_notional → REJECT
6. Drawdown Limit  — daily_drawdown <= max_drawdown_pct → REJECT
7. Duplicate Check — same (market, side, price, size) within 1s → REJECT
8. Rate Limit      — orders_this_second <= max_rate → REJECT

These checks run in Rust (not Python, not LLM-mediated).
They are the ground truth. No amount of LLM reasoning changes them.
```

### Layer 1: Agent Self-Risk (Per-Strategy, Seconds)

The agent LLM monitors its own strategy using mathematical tools:

```
Computed by SDK (not estimated by LLM):
  cornish_fisher_var(returns)     → actual VaR accounting for skew/kurtosis
  toxic_flow(feed, threshold)     → actual VPIN measurement
  regime_detect()                 → actual HMM state
  signal_half_life(signal)        → actual decay rate
  bootstrap_edge(preds, outcomes) → actual confidence interval

The LLM reads these numbers and decides how to react:
  "VaR increased 3x → reduce position size"
  "VPIN at 0.85 → widen spreads"
  "Signal half-life dropped to 5 days → prepare for retirement"

The LLM can always activate its own kill switch (self-protection):
  activate_kill_switch(reason="VPIN spike — protecting capital")
```

### Layer 2: Hive Portfolio Risk (Global, Minutes)

The Hive monitors the aggregate portfolio using the same mathematical tools:

```
The Hive computes (via tool calls, not estimation):
  portfolio VaR across all strategies
  cross-strategy correlation matrix
  total drawdown from peak NAV
  sector concentration percentages
  regime-conditional risk metrics

The Hive can issue directives:
  "All agents: reduce exposure 40% — volatile regime detected"
  "Agent-7: your strategy's correlation with Agent-2 spiked to 0.8.
   One of you should close. Agent-2 has higher Sharpe — Agent-7, retire."
  "Global kill switch — drawdown approaching hard limit"
```

### Layer 3: Hard Circuit Breakers (Automatic, Non-LLM)

A separate watchdog thread runs independently of all LLMs:

```
Watchdog runs every 5 seconds:
  total_drawdown = (peak_nav - current_nav) / peak_nav
  if total_drawdown > hard_max_drawdown_pct:
      activate_global_kill_switch()
      halt_all_agents()
      alert_human()
      # NO LLM CAN OVERRIDE THIS

  for each strategy:
      if strategy_drawdown > hard_max_strategy_drawdown_pct:
          pause_strategy()
          # Agent can request resume, but watchdog checks again

  if daily_loss > hard_max_daily_loss:
      activate_global_kill_switch()
      # Hard dollar stop, no exceptions
```

### Why Four Layers

| Layer | Who Controls | Speed | Overridable? |
|---|---|---|---|
| 0: Rust Engine | Nobody (hardcoded) | Microseconds | Never |
| 1: Agent Self-Risk | Agent LLM | Seconds | Agent can self-adjust |
| 2: Hive Portfolio Risk | Hive LLM | Minutes | Hive can override agents |
| 3: Circuit Breaker | Nobody (watchdog) | Seconds | Only human can restart |

An LLM that hallucinates "this can't lose" will be stopped by Layer 0.
An agent that ignores risk will be stopped by the Hive (Layer 2).
A Hive that gets too aggressive will be stopped by the circuit breaker (Layer 3).
A circuit breaker event requires a human to evaluate and restart (no automation).

---

## 5. Deep Pattern Discovery

### Finding What's Not Obvious

The most valuable edges are the ones nobody else sees. The agent has tools specifically designed to uncover hidden relationships, non-linear dependencies, and structural patterns that linear correlation completely misses.

### 5.1 Multi-Step Correlation Analysis

```
Step 1: Linear correlation (baseline)
  correlation_matrix(returns) → Ledoit-Wolf shrinkage covariance
  This finds the obvious relationships: BTC and ETH are correlated.

Step 2: Time-varying correlation
  correlation_regime(returns_a, returns_b, window=50)
  → Shows HOW the relationship changes over time.
  "BTC-ETH correlation was 0.9 in January, dropped to 0.6 in February"
  This reveals unstable relationships — dangerous for hedging.

Step 3: Lead-lag structure
  lead_lag_network(all_series, names, max_lag=10)
  cross_correlation_lags(x, y, max_lag=10)
  → Shows WHO leads and WHO follows, and by how much.
  "Fed futures lead the rate prediction market by 2 days"
  This is tradeable — the leader tells you what the follower will do.

Step 4: Causal direction
  granger_test(x, y, max_lag=5) → Does X actually CAUSE Y?
  → "p=0.008 — yes, futures Granger-cause the prediction market"
  NOT the same as correlation. Granger causality is directional and
  controls for the possibility that both are driven by a third factor.

Step 5: Non-linear dependency (copulas)
  best_copula(u, v) → tests Gaussian, Clayton, Frank, Gumbel
  → "Clayton copula fits best (AIC=-120 vs Gaussian AIC=-80)"
  Clayton captures lower-tail dependence: in crashes, these assets
  move together much more than in normal times. Gaussian correlation
  completely misses this.

Step 6: Multivariate structure (vine copulas)
  vine_copula_fit(data, vine_type="c-vine")
  vine_tail_risk(data, threshold=0.05, n_sim=10000)
  → Joint tail probability across 5+ assets simultaneously.
  "The probability that all 4 crypto markets crash together: 12%"
  (much higher than the 2% you'd estimate from linear correlation)

Step 7: Network structure
  market_graph_analysis(corr_matrix, names, threshold=0.5)
  → Graph centrality, communities, contagion paths.
  "BTC is the most central node. If BTC drops, the contagion
   path goes BTC → ETH → SOL → all DeFi prediction markets"

Step 8: Regime-conditional relationships
  contagion_score(returns_matrix, window=30)
  detect_regime_shift(hist_correlations, recent_correlations)
  → "Correlation regime shifted: crypto markets that were independent
     in calm regime (corr=0.3) are now highly correlated (corr=0.85)
     in volatile regime. Diversification benefit has evaporated."
```

### 5.2 Cross-Domain Pattern Discovery

The agent has access to data from multiple domains. The most interesting patterns are cross-domain:

```
Example 1: Weather → Prediction Markets
  Data sources: NWS feed, Kalshi weather markets, FRED agricultural data
  Analysis:
    lead_lag_analysis(hurricane_probability, oj_futures)
    granger_test(nws_alerts, kalshi_hurricane_market)
    copula_fit(hurricane_prob, insurance_stock_returns)
  Finding: "NWS hurricane probability updates lead Kalshi markets by 6 hours"

Example 2: Congressional Trading → Stock Predictions
  Data sources: unusual_whales_congress(), Polymarket stock prediction markets
  Analysis:
    lead_lag_analysis(congress_buys, stock_market_price)
    granger_test(insider_trades, prediction_market_probability)
  Finding: "Congressional trades in pharma stocks lead FDA approval markets
            by 2-5 days (Granger p=0.02)"

Example 3: Dark Pool Activity → Crypto Prediction Markets
  Data sources: unusual_whales_dark_pool(), whale_galaxy(), Polymarket
  Analysis:
    hawkes_intensity(dark_pool_events) → clustering in time
    cross_impact_matrix(crypto_returns, dark_pool_volumes)
    correlation_regime(dark_pool_flow, prediction_market_returns)
  Finding: "Dark pool BTC accumulation clusters (Hawkes branching ratio 0.7)
            predict BTC prediction market repricing 12-24 hours later"

Example 4: Macro Events → Multi-Market Cascade
  Data sources: economic_calendar(), treasury_feed(), multiple markets
  Analysis:
    bocpd_detect(market_prices)  — change point at CPI release
    contagion_score() — how the shock propagates
    lead_lag_network() — propagation order
  Finding: "CPI surprise causes: Treasury yields move (0 min) →
            Fed rate market reprices (5 min) → BTC prediction moves (30 min)
            → ALT crypto predictions move (2 hours). Trading the cascade
            at each stage captures progressively more mispricing."
```

### 5.3 Structural Break Detection

Markets change. Relationships break. The agent must detect this before it causes losses.

```
Tools:
  bocpd_detect(observations, hazard_rate=250)
    → Bayesian change point: "probability of structural break: 0.87"
    Adams & MacKay (2007) method. Detects changes in mean and variance
    of the generating process.

  cusum_filter(prices, threshold)
    → CUSUM: flags exact timestamps of structural breaks.
    Works on both trends and variance changes.

  kalman_filter_state(observations)
    → Tracks the LATENT state behind noisy observations.
    "The true fair value is drifting even though prices look random"

  particle_filter_state(observations, n_particles=1000)
    → Non-linear, non-Gaussian state estimation.
    For when Kalman assumptions don't hold (prediction markets are
    bounded [0,1], so Gaussian assumptions are wrong near boundaries).

  hawkes_intensity(event_times)
    → Self-exciting process: "Events are clustering — the arrival rate
       of trades is accelerating, suggesting a cascade or panic"

Combined usage:
  "BOCPD says 87% probability of a change point 2 hours ago.
   CUSUM flagged a structural break at the same timestamp.
   Kalman filter shows the latent state jumped from 0.55 to 0.62.
   Hawkes intensity shows trade clustering (branching ratio 0.8).

   Diagnosis: an informed trader entered the market with size.
   The break is real, not noise. My fair value estimate is stale.
   Adjusting immediately."
```

### 5.4 Pattern Sharing Across Agents

When one agent discovers a non-obvious pattern, ALL agents benefit:

```
Agent-3 discovers:
  "Clayton copula between BTC prediction markets and Coinbase funding rate.
   Lower tail dependence = 0.45. When funding rate crashes, BTC prediction
   markets overreact — 3-cent mispricing appears within 30 minutes."

Agent-3 publishes:
  → WebSocket: MarketSignal (for immediate use by active traders)
  → Knowledge Graph: fact (for long-term memory)
    entity: btc_funding_rate_relationship
    fact_type: correlation
    confidence: 0.85
    content: {
      type: "copula_dependency",
      family: "clayton",
      tail_dependence: 0.45,
      mechanism: "funding rate crash → prediction market overreaction",
      tradeable_window: "30 minutes",
      edge_size: "~3 cents"
    }

Agent-7 (already trading BTC markets) receives the WebSocket signal:
  "Interesting — I should add funding rate monitoring to my strategy.
   If I detect a funding rate crash (via Binance feed), I can prepare
   to buy the dip on the prediction market before others react."

Agent-14 (researching new opportunities) reads the knowledge graph:
  "There's a documented copula dependency between funding rates and
   prediction markets. Let me investigate if similar relationships
   exist for ETH, SOL, and other crypto prediction markets."
```

---

## 6. Communication: WebSocket Event Bus

Agents and the Hive communicate over a real-time WebSocket bus. This enables the reactive behavior described throughout this document.

```
┌─────────────────────────────────────────────────┐
│              WebSocket Event Bus                 │
│                                                  │
│  Channels:                                       │
│  ├── hive/commands      (Hive → Agents)         │
│  ├── hive/approvals     (Hive → specific Agent) │
│  ├── agents/proposals   (Agents → Hive)         │
│  ├── agents/status      (Agents → All)          │
│  ├── market/signals     (Any → All)             │
│  ├── market/fills       (Agents → All)          │
│  ├── risk/alerts        (Any → All)             │
│  └── knowledge/updates  (Any → All)             │
└─────────────────────────────────────────────────┘
```

**Event Types:**

```python
# Hive → Agents
HiveCommand:     spawn | kill | pause | resume | adjust_risk
HiveApproval:    approved | rejected | modified (with conditions)
HiveDirective:   strategic shift, regime change, sector limits

# Agents → Hive
AgentProposal:   deploy | scale | retire | evolve (with full evidence)
AgentEscalation: severity + situation + options

# Agents → All (broadcast)
AgentStatus:     phase, markets, pnl, positions, reasoning summary
MarketSignal:    signal_type, value, confidence, evidence
FillEvent:       market, side, price, size, pnl impact
KnowledgeUpdate: entity, fact_type, content, confidence

# System
RiskAlert:       source, severity, message, action_taken
```

**WebSocket is complementary to Knowledge Graph:**
- WebSocket = real-time events (ephemeral, reactive, "what's happening NOW")
- Knowledge Graph = persistent memory (durable, queryable, "what do we KNOW")

An agent publishes a MarketSignal on WebSocket for immediate reaction by active traders, AND records a fact in the knowledge graph for future reference by any agent.

---

## 7. Capital Management

### 7.1 Capital Pool

```
Total Capital: $100,000
├── Reserve Buffer: 20% ($20,000) — never deployed, safety net
├── Paper Allocation: 10% ($10,000) — testing new strategies
├── Shadow Allocation: 10% ($10,000) — validation phase
└── Live Allocation: 60% ($60,000) — active trading
    ├── Strategy A: $15,000 (Kelly-optimal, capped at 20%)
    ├── Strategy B: $10,000
    └── Undeployed: $35,000 (available for new strategies)
```

### 7.2 Allocation Rules (Computed, Not Estimated)

```
Every allocation is computed by mathematical tools:

kelly_sizing(prob, price, bankroll, fraction=0.25, max_size)
  → Optimal position size given edge and confidence
  → Half-Kelly (fraction=0.25 is quarter-Kelly) for safety

portfolio_weights(method="kelly")
  → Portfolio-level Kelly with correlation adjustment
  → Ledoit-Wolf covariance → not just pairwise Kelly

simulate_portfolio(scenarios=500)
  → Monte Carlo validation of proposed allocation
  → probability_of_ruin must be < 5%

stress_test(scenarios=["correlation_spike", "tail_risk"])
  → Worst-case loss at proposed allocation must be < 20% of capital

The LLM reads these results and proposes allocations to the Hive.
The Hive validates with its own tool calls. Neither can hallucinate
the optimal allocation — it's computed by the SDK.
```

---

## 8. Process Architecture

```
┌──────────────────────────────────────────────────────┐
│                    SWARM PROCESS                      │
│                                                       │
│  ┌───────────────────────────────────────────────┐   │
│  │              WebSocket Server                  │   │
│  │         (asyncio, event routing)               │   │
│  └───────────────────────────────────────────────┘   │
│                                                       │
│  ┌───────────────────────────────────────────────┐   │
│  │              Hive Thread                       │   │
│  │    LLM loop: context → reason → act → sleep   │   │
│  └───────────────────────────────────────────────┘   │
│                                                       │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐            │
│  │ Agent-1  │ │ Agent-2  │ │ Agent-N  │  ...       │
│  │ Thread   │ │ Thread   │ │ Thread   │            │
│  └──────────┘ └──────────┘ └──────────┘            │
│                                                       │
│  ┌───────────────────────────────────────────────┐   │
│  │            Shared Resources                    │   │
│  │  FeedManager │ KnowledgeGraph │ Engine Pool    │   │
│  └───────────────────────────────────────────────┘   │
│                                                       │
│  ┌───────────────────────────────────────────────┐   │
│  │         Circuit Breaker (watchdog)             │   │
│  │    Non-LLM, monitors NAV, auto-kills          │   │
│  └───────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────┘
```

### LLM API Architecture

```
Hive:    Claude Opus — highest reasoning capability
Agents:  Claude Sonnet — fast, cost-efficient, strong tool use

Tool execution is LOCAL (in-process):
  LLM says: call deflated_sharpe(1.6, 150, 15, -0.3, 4.2)
  Agent thread intercepts → calls Python/Rust function directly
  Rust computes in microseconds → result returned to LLM context
  LLM continues reasoning with the verified mathematical result
```

### Resource Sharing

```
Shared (one instance, many consumers):
├── FeedManager     — one WebSocket per data source, shared by all agents
├── Knowledge Graph — SQLite WAL (concurrent readers, serialized writers)
├── WebSocket Bus   — single server, all agents connected
├── Engine Pool     — pre-allocated engines per exchange
└── API Clients     — pooled HTTP connections per exchange

Per-Agent:
├── LLM Context     — each agent has its own conversation with Claude
├── Reasoning State  — current plan, phase, working memory
└── Tool Call Budget — rate-limited to prevent API abuse
```

---

## 9. Configuration

```python
from horizon.swarm import SwarmConfig, Swarm

config = SwarmConfig(
    # LLM
    hive_model="claude-opus-4-6",
    agent_model="claude-sonnet-4-6",

    # Capital
    total_capital=100_000,
    reserve_pct=0.20,
    max_concentration=0.20,
    min_allocation=1_000,

    # Agent limits
    max_agents=20,
    initial_agents=4,

    # Exchanges
    exchanges=["polymarket", "kalshi"],
    mode="paper",  # "paper" or "live"

    # Hard circuit breakers (NOT controlled by LLM)
    hard_max_drawdown_pct=10.0,
    hard_max_strategy_drawdown_pct=20.0,
    hard_max_daily_loss=5_000,

    # Anti-overfitting thresholds (applied to all agents)
    min_deflated_sharpe_p=0.05,
    max_pbo=0.40,
    min_walk_forward_consistency=0.60,
    min_bootstrap_edge_lower=0.0,
    min_backtest_trades=50,

    # Promotion pipeline
    paper_days=14,
    shadow_days=7,
    min_sharpe_for_live=1.0,

    # Communication
    ws_port=8765,

    # Knowledge
    knowledge_graph_path="~/.horizon/swarm/knowledge.db",

    # Observability
    log_level="INFO",
    dashboard=True,
)

swarm = Swarm(config)
swarm.start()
# Fully autonomous from here.
# Hive spawns agents → agents discover → analyze → backtest →
# pass 5 gates → propose to Hive → paper → shadow → live →
# monitor → evolve → retire → post-mortem → repeat
```

---

## 10. Observability

### Swarm TUI Dashboard

```
┌─ HORIZON SWARM ──────────────────────────────────────────────────────┐
│ NAV: $103,450  DD: -1.2%  Regime: Volatile  Capital: 72% deployed   │
│ Agents: 12 active  |  Hive: reasoning  |  LLM cost today: $127      │
├─ AGENTS ─────────────────────────────────────────────────────────────┤
│ ID │ Phase      │ Market              │ P&L     │ Sharpe │ Age      │
│  2 │ EXECUTE    │ ETH>$5k June        │ +$890   │ 1.3    │ 30d      │
│  5 │ EXECUTE    │ BTC corr arb        │ +$1,200 │ 2.1    │ 15d      │
│  7 │ EXECUTE    │ Fed rate Sept       │ +$340   │ 1.5    │ 8d       │
│  8 │ ANALYZE    │ Kalshi CPI market   │ --      │ --     │ 2d       │
│ 10 │ PAPER      │ NBA finals          │ -$30    │ 0.8    │ 3d       │
│ 14 │ RESEARCH   │ Kalshi events       │ --      │ --     │ 1d       │
├─ HIVE DECISIONS ─────────────────────────────────────────────────────┤
│ 14:28 APPROVED  Agent-9 (BTC hedge, $3K, conditions: regime review) │
│ 14:15 REJECTED  Agent-4 (Election MM: PBO=0.55 — overfit)          │
│ 14:02 SPAWNED   Agent-14 (directive: Kalshi diversification)        │
├─ RISK ───────────────────────────────────────────────────────────────┤
│ Portfolio VaR(95%): $2,100  |  Max sector: crypto 38%/40%           │
│ Circuit breaker: 8.8% DD / 10% limit  |  Watchdog: OK              │
├─ SIGNALS ────────────────────────────────────────────────────────────┤
│ 14:32 [Agent-3]  Whale 0xabc sold $200K ETH YES (copula tail=0.4) │
│ 14:30 [Agent-5]  BTC-ETH corr dropped 0.92→0.72 (regime shift)    │
│ 14:29 [System]   BOCPD: 87% change point probability (BTC market)  │
└──────────────────────────────────────────────────────────────────────┘
```

### Agent Reasoning Trace

```
$ hz swarm agent-log 7 --last 1

[Agent-7] 14:32:01 Phase: MONITORING
Context: Fed rate market | Position: 200 YES @ 0.62 | P&L: +$340

Received: HiveDirective "reduce exposure 40% — volatile regime"
Received: Agent-3 signal "whale dump ETH market"

Thinking:
  "Hive wants 40% reduction. My current position is 200 contracts.
   Target: 120 contracts. Need to sell 80.

   The whale dump is ETH, not my market. Let me check correlation...
   [correlation_regime(my_returns, eth_returns) → 0.45]
   Moderate correlation. Not directly dangerous but worth monitoring.

   Best execution for selling 80:
   [stealth_estimate('fed_rate', 80) → impact: 0.3 cents]
   [feed_snapshot('poly_fed_rate') → bid: 0.64]

   0.3 cents impact is acceptable. Placing sell order at 0.64."

Actions:
  submit_order("fed_rate", "yes", "sell", 0.64, 80)
  → Filled at 0.64 (maker)
  publish_signal(AgentStatus: "reduced per Hive directive, 120 remaining")
```

---

## 11. The Hive as Active Commander

The Hive is not a passive approval gate. It is the brain of the swarm — it actively manages, directs, spawns, evaluates, and reshapes the agent population based on what it sees across the entire system.

### 11.1 The Hive's Continuous Reasoning Loop

```
┌────────────────────────────────────────────────────────────────┐
│                    HIVE REASONING LOOP                          │
│                                                                 │
│  every 60 seconds:                                              │
│                                                                 │
│  1. OBSERVE — gather full swarm state                          │
│     - All agent statuses (phase, market, P&L, age, health)     │
│     - Portfolio snapshot (NAV, drawdown, VaR, sector exposure)  │
│     - Pending proposals from agents                             │
│     - Risk alerts from watchdog                                 │
│     - Knowledge graph: recent discoveries, failed hypotheses    │
│     - WebSocket event stream: signals, fills, escalations       │
│     - Resource usage: LLM cost, API rate limits, memory         │
│                                                                 │
│  2. ASSESS — reason about the swarm's performance              │
│     - Is the swarm finding enough opportunities?                │
│     - Are agents productive or spinning wheels?                 │
│     - Is the portfolio well-diversified or concentrated?        │
│     - Are we in the right regime for our current strategies?    │
│     - Which sectors/exchanges are underexplored?                │
│     - Which agents have the best track records?                 │
│     - Are we burning too much on LLM costs vs returns?         │
│                                                                 │
│  3. DECIDE — take strategic actions                            │
│     - Review pending proposals (approve/reject/modify)          │
│     - Spawn new agents (free-roaming or directed)               │
│     - Kill underperforming or stuck agents                      │
│     - Issue directives (regime shifts, sector rebalancing)      │
│     - Adjust risk parameters                                    │
│     - Reallocate capital across strategies                      │
│                                                                 │
│  4. REFLECT — learn from the cycle                             │
│     - Was my last directive effective?                           │
│     - Did agents I spawned yesterday find anything?             │
│     - Are my approval criteria too strict or too loose?         │
│     - Update my mental model of the opportunity landscape       │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

### 11.2 Hive Context Assembly

Every cycle, the Hive receives a structured snapshot of the entire swarm. This is NOT a summary — it's the raw data the Hive needs to reason about.

```python
HiveContext:
  # Portfolio State (from mathematical tools — not agent-reported)
  portfolio:
    nav: 103_450
    peak_nav: 105_200
    drawdown_pct: 1.66
    daily_pnl: +320
    total_realized: +8_200
    total_unrealized: -450
    capital_deployed: 72_000  (72%)
    capital_available: 8_000  (after reserve)
    var_95: 2_100
    regime: "volatile"
    sector_exposure: {crypto: 38%, macro: 22%, sports: 12%, unallocated: 28%}

  # Every Agent (live state)
  agents: [
    {id: 1,  phase: "research",  market: null,           pnl: 0,      age: "6h",
     score: 0.72, directive: "free-roaming",
     last_action: "scanning Polymarket crypto", last_action_age: "2m"},

    {id: 2,  phase: "executing", market: "ETH>$5k",      pnl: +890,   age: "30d",
     score: 0.91, directive: null,
     sharpe: 1.3, alpha_decay: "stable", regime_sensitivity: "moderate"},

    {id: 5,  phase: "executing", market: "BTC corr arb",  pnl: +1200,  age: "15d",
     score: 0.95, directive: null,
     sharpe: 2.1, alpha_decay: "stable", regime_sensitivity: "low"},

    {id: 8,  phase: "analyze",   market: "CPI prediction", pnl: 0,     age: "2d",
     score: 0.60, directive: "explore Kalshi macro",
     progress: "running backtest, 3 hypotheses tested, 0 validated"},

    {id: 14, phase: "research",  market: null,            pnl: 0,      age: "1d",
     score: 0.45, directive: "explore Kalshi events",
     progress: "scanned 40 markets, found 3 candidates, analyzing first"},
  ]

  # Pending Proposals
  proposals: [
    {agent: 9, type: "deploy_live", market: "BTC hedge", capital: 3000,
     evidence: {sharpe: 1.4, pbo: 0.18, walk_forward: 0.72, ...}},
  ]

  # Recent Events (last hour)
  events: [
    {time: "14:32", agent: 3, type: "signal", msg: "whale dump ETH"},
    {time: "14:28", agent: 2, type: "fill", msg: "sold 200 YES @ 0.67"},
    {time: "14:15", system: true, type: "risk", msg: "crypto at 38%/40%"},
  ]

  # Knowledge Graph Summary
  knowledge:
    markets_in_graph: 340
    active_hypotheses: 12
    validated_awaiting_deploy: 2
    recently_retired_strategies: [{market: "SOL momentum", sharpe: 0.6, lesson: "..."}]
    unexplored_sectors: ["Kalshi weather", "Limitless DeFi"]
    tips_from_retired_agents: ["OJ-hurricane lead-lag unexploited"]

  # Resource Budget
  resources:
    llm_cost_today: 127.00
    llm_budget_daily: 500.00
    api_rate_remaining: {polymarket: 85%, kalshi: 92%, polygon: 70%}
    memory_usage: 4.2 GB / 16 GB
    active_feeds: 18 / 50 max
    active_engines: 8 / 20 max
```

### 11.3 Two Agent Spawning Modes

The Hive can spawn agents in two fundamentally different modes:

#### Mode 1: Free-Roaming Agents

A free-roaming agent has no specific target. It explores wherever its reasoning leads it. The Hive spawns these when it wants broad coverage or serendipitous discovery.

```
Hive reasoning:
  "We have 8 active strategies, all in crypto and macro. We're missing
   sports, weather, and political markets entirely. I'll spawn 2 free-
   roaming agents to explore broadly. They might find opportunities
   I haven't thought of."

HiveCommand: spawn Agent-15
  mode: "free_roaming"
  directive: null  # No specific target — explore freely
  constraints:
    exchanges: ["polymarket", "kalshi"]  # Full access
    budget: $0 (research only, no capital until approved)
    ttl: 24h  # Auto-terminate if nothing found in 24 hours
    report_interval: 2h  # Check in with Hive every 2 hours

Agent-15 (free-roaming) reasoning:
  "I have no directive — I'll explore where I see opportunity.
   Let me start with the knowledge graph to see what's unexplored...

   [query_knowledge: unexplored sectors]
   Weather and sports are untouched. Let me scan both.

   [discover_markets(exchange='kalshi', category='weather')]
   → 15 active weather markets. Hurricane season starting.

   [discover_markets(exchange='polymarket', category='sports')]
   → 30 active sports markets. NBA playoffs.

   Interesting — I'll dig into hurricane markets first because
   they have a structural data advantage (NWS forecasts are public
   but prediction markets react slowly to updates)..."

   [This agent may eventually find an edge, backtest it, pass 5 gates,
    and propose deployment to the Hive — all on its own initiative]
```

#### Mode 2: Directed Agents

A directed agent has a specific mission from the Hive. The Hive spawns these when it sees a concrete opportunity or gap that needs focused attention.

```
Hive reasoning:
  "Agent-7's post-mortem mentioned that OJ futures lead hurricane
   prediction markets on Kalshi. No agent has investigated this yet.
   This is a specific, testable hypothesis. I'll spawn a directed
   agent to validate it."

HiveCommand: spawn Agent-16
  mode: "directed"
  directive:
    objective: "Investigate OJ futures → Kalshi hurricane market lead-lag"
    hypothesis: "OJ futures lead hurricane prediction markets by 3 days"
    data_sources: ["FRED agricultural data", "Kalshi weather markets",
                   "Polymarket weather", "NWS hurricane feed"]
    specific_tools: ["granger_test", "lead_lag_analysis", "copula_fit"]
    urgency: "high"  # Hurricane season is approaching
    ttl: 48h  # This is a focused mission, not open-ended
    success_criteria: "Granger p < 0.05, backtest Sharpe > 1.0"
    on_success: "Submit deployment proposal immediately"
    on_failure: "Record negative result in knowledge graph and terminate"

Agent-16 (directed) reasoning:
  "I have a clear mission: validate OJ → hurricane lead-lag.
   Let me go directly to the analysis..."

   [calls market_data_aggregates('OJ', from='2024-01-01', to=now)]
   [calls discover_markets(exchange='kalshi', category='weather')]
   [calls granger_test(oj_returns, hurricane_market_prices, max_lag=5)]

   "Granger test: p=0.015 at lag 3. Significant! OJ futures do lead
    hurricane markets by 3 days. Now let me quantify the edge..."

   [proceeds through full pipeline: analysis → backtest → 5 gates]
```

#### When to Use Which Mode

```
Hive decides:

  FREE-ROAMING when:
  - Portfolio is concentrated in few sectors → need diversification scouting
  - No specific leads → cast a wide net
  - Market conditions changed → need to discover new opportunity landscape
  - Agent population is low → more explorers = more coverage
  - After major event (election, FOMC, etc.) → new markets may have appeared

  DIRECTED when:
  - Knowledge graph contains a specific untested tip
  - Retired agent left a lead ("OJ → hurricane not yet exploited")
  - Hive detects a macro event that should create opportunity
  - Cross-agent signal suggests a specific opportunity
  - Urgent: time-sensitive event approaching (CPI release in 2 hours)
  - A running strategy needs a hedge → spawn agent to find the best hedge
```

### 11.4 Dynamic Agent Population Management

The Hive continuously adjusts the agent population:

```
Hive reasoning (every cycle):

  "Let me assess my agent population...

   Research agents: 3 (Agent-1 free-roaming, Agent-14 directed-Kalshi,
                       Agent-15 free-roaming)
   Analysis agents: 1 (Agent-8 analyzing CPI market)
   Executing agents: 4 (Agent-2, 5, 7, 10)
   Monitoring agents: 0 (each executing agent monitors itself)

   Problems I see:
   1. Agent-14 has been researching Kalshi for 24 hours but only found
      3 candidates and analyzed 0. Score: 0.45. Underperforming.
      → Send a nudge: 'Agent-14, you've been researching for 24h with
        no validated hypotheses. Speed up or shift focus.'
      → If no improvement in 6h, terminate and spawn a replacement
        with a different approach.

   2. We have 3 research agents but only 1 analyst. The knowledge graph
      shows 8 unanalyzed candidates. Bottleneck.
      → Spawn Agent-17 in directed mode: 'Analyze the top 4 unanalyzed
        candidates from the knowledge graph by priority score.'

   3. Agent-10 (NBA paper trading) has Sharpe 0.8 after 3 days.
      That's below the 1.0 threshold for promotion. But it's only 3 days.
      → No action. Check again at day 7. If still below 1.0, retire.

   4. Agent-5 (BTC corr arb, Sharpe 2.1) is our best performer.
      It's been running 15 days with stable alpha.
      → Proposal: scale up Agent-5's capital from $10K to $15K.
        Run correlation and VaR checks first.

   5. Capital utilization is 72%. We have $8K available.
      2 validated hypotheses are waiting for deployment.
      → Review the proposals and approve the best one.

   6. The swarm is 70% crypto. I need to diversify.
      → Agent-15 (free-roaming) hasn't checked political markets.
        Send directive: 'Also explore Polymarket political markets —
        election primaries are heating up.'

   Actions this cycle:
   - Nudge Agent-14
   - Spawn Agent-17 (directed: analyze backlog)
   - Propose scaling Agent-5 to $15K
   - Review Agent-9's deployment proposal
   - Redirect Agent-15 to include political markets"
```

### 11.5 Agent Lifecycle Decisions

The Hive makes four types of lifecycle decisions:

```
┌────────────────────────────────────────────────────────────┐
│ SPAWN      "The swarm needs more X" or "I see opportunity" │
│            → Free-roaming (broad search)                   │
│            → Directed (specific mission)                   │
│            → Replacement (underperformer terminated)       │
├────────────────────────────────────────────────────────────┤
│ REDIRECT   "Agent is capable but looking in wrong place"   │
│            → Send HiveDirective with new focus area        │
│            → Agent keeps its context but shifts attention   │
├────────────────────────────────────────────────────────────┤
│ TERMINATE  "Agent is not productive or no longer needed"   │
│            → Underperforming (low score for extended time)  │
│            → Mission complete (directed agent finished)     │
│            → Resource pressure (need to free capacity)      │
│            → Conflict (two agents on same market)          │
├────────────────────────────────────────────────────────────┤
│ PROMOTE    "Agent proved itself, give it more resources"   │
│            → Scale capital (strategy performing well)       │
│            → Upgrade priority (high-value discovery)        │
│            → Extend TTL (free-roaming found a lead)        │
└────────────────────────────────────────────────────────────┘
```

---

## 12. Performance Tracking: How the Hive Evaluates Agents

### 12.1 The Agent Scorecard

Every agent has a continuously computed score that the Hive uses to evaluate productivity. The score is NOT based on LLM self-reporting — it's computed from observable actions and outcomes.

```
AgentScorecard:
  agent_id: 7
  age: "8d"
  current_phase: "executing"
  score: 0.88 / 1.00

  # Discovery Metrics (for research/analysis phases)
  markets_scanned: 45
  candidates_surfaced: 8
  hypotheses_formed: 4
  hypotheses_validated: 2
  hypotheses_invalidated: 2
  discovery_rate: 0.18 (validated/scanned)
  time_to_first_hypothesis: "6 hours"

  # Execution Metrics (for trading phases)
  strategies_deployed: 1
  live_sharpe: 1.5
  total_pnl: +$340
  max_drawdown: 5%
  win_rate: 0.60
  edge_capture: 0.72  # actual edge / theoretical edge
  adverse_selection_pct: 0.05
  cost_efficiency: 0.91  # (gross_pnl - costs) / gross_pnl

  # Quality Metrics (across all phases)
  proposal_acceptance_rate: 0.67 (2/3 proposals approved by Hive)
  gates_pass_rate: 0.50 (2/4 hypotheses passed all 5 gates)
  knowledge_contributions: 12 facts written to graph
  signals_published: 8 (3 acted on by other agents)
  false_signal_rate: 0.00 (no signals contradicted by outcomes)
  mean_time_in_research: "6h"
  mean_time_to_deployment: "18d" (research → live)

  # Cost Metrics
  llm_cost_total: $42
  llm_cost_per_pnl_dollar: $0.12  # $42 cost / $340 P&L
  api_calls_total: 1,200
  tool_calls_total: 3,400

  # Reliability Metrics
  crashes: 0
  recoveries: 0
  missed_cycles: 3 (out of 48,000)
  uptime: 99.99%
```

### 12.2 How the Hive Uses Scores

```
Hive reasoning about Agent-14 (score: 0.45):

  "Agent-14 has been running for 24 hours with a score of 0.45.
   Let me break it down:
   - Scanned 40 markets (good volume)
   - Surfaced 3 candidates (low yield — only 7.5%)
   - 0 hypotheses formed (nothing passed initial analysis)
   - LLM cost: $18 with no return

   Compare to Agent-1 (score: 0.72) at the same age:
   - Scanned 35 markets, surfaced 5 candidates, formed 2 hypotheses
   - LLM cost: $15

   Agent-14 is less efficient. Possible reasons:
   1. It's exploring Kalshi, which has fewer markets (harder problem)
   2. Its analysis criteria may be too strict
   3. It might be stuck in a loop (re-analyzing the same markets)

   Let me check its reasoning trace...
   [reads agent-14 log: last 5 cycles]

   It's re-analyzing the same 3 candidates repeatedly with different
   parameters. It's stuck. I'll redirect it:

   HiveDirective to Agent-14:
   'You've been re-analyzing the same 3 Kalshi candidates for 8 hours.
    Move on. If none of them pass initial alpha screening, they don't
    have an edge. Shift to Kalshi economic indicator markets (KXCPI,
    KXGDP, KXJOBS) — these have higher volume and more macro data
    available for lead-lag analysis.'"

Hive reasoning about Agent-5 (score: 0.95):

  "Agent-5 is our best performer. BTC correlation arb, Sharpe 2.1,
   $1,200 P&L in 15 days, zero crashes, low adverse selection.
   Score 0.95.

   This agent understands cross-exchange arb well. Its knowledge graph
   contributions have been high-quality (8 facts, 3 acted on by others).

   I should:
   1. Scale its capital from $10K to $15K (proposal pending my own review)
   2. Ask it to document its correlation monitoring approach so other
      agents can learn from it
   3. Consider spawning a directed agent to test similar arb strategies
      on ETH and SOL markets"
```

### 12.3 Agent Performance Tiers

The Hive categorizes agents into tiers for resource allocation:

```
TIER 1 — Star Performers (score > 0.85)
  - Highest capital allocation priority
  - Longest TTL (no auto-terminate)
  - Can request scaling without full re-proposal
  - Their knowledge contributions get highest confidence weight

TIER 2 — Solid Performers (score 0.60-0.85)
  - Normal capital allocation
  - Standard TTL
  - Full proposal process for changes
  - Default treatment

TIER 3 — Underperformers (score 0.40-0.60)
  - Receive Hive redirect or nudge
  - Reduced TTL (auto-terminate if no improvement in 12h)
  - Cannot request scaling
  - Hive considers whether to replace

TIER 4 — Failing (score < 0.40)
  - Immediate review by Hive
  - Likely terminated unless there's a clear reason (hard problem, new exchange)
  - Capital reallocated to higher-performing agents
  - Post-mortem required: why did this agent fail?
```

### 12.4 Hive Self-Assessment

The Hive also tracks its own performance:

```
HiveMetrics:
  proposals_reviewed: 45
  approval_rate: 0.55 (25 approved, 20 rejected)
  approved_strategies_profitable: 0.80 (20/25 strategies positive P&L)
  rejected_strategies_that_would_have_worked: unknown (but tracked via
    paper-simulation of rejected proposals for calibration)
  agents_spawned: 20
  agents_terminated: 6
  mean_agent_lifetime: "12d"
  portfolio_sharpe: 1.4
  portfolio_max_drawdown: 3.2%
  total_pnl: +$8,200
  llm_cost_total: $1,200
  roi_on_llm_cost: 6.8x ($8,200 / $1,200)

Hive self-reflection:
  "My approval rate is 55% — am I being too strict? Let me check:
   of the 20 rejected proposals, 3 were later re-submitted with
   stronger evidence and approved. The other 17 were genuinely weak
   (PBO too high, insufficient trades, or duplicate of existing strategy).

   My approved strategies have 80% profitability rate — that's good.
   The 5 unprofitable ones all suffered from regime shifts that were
   hard to predict.

   Agents I spawned: 20 total, 6 terminated. That's a 70% survival rate.
   The 6 terminated were mostly free-roaming agents that didn't find
   opportunities (expected — exploration has a lower hit rate than
   directed missions). My directed agents have a 90% success rate
   in finding something worth analyzing.

   Conclusion: I should spawn more directed agents when I have specific
   leads, and fewer free-roaming agents. But I still need some free-
   roaming for serendipitous discovery."
```

---

## 13. Reliability Engineering

### 13.1 Design Principle: The System Never Loses State

Every piece of state that matters is persisted to durable storage. If the entire process crashes and restarts, the swarm can recover to a consistent state.

```
What is persisted (and where):

Knowledge Graph (SQLite WAL):
  ├── All market entities and relationships
  ├── All facts (signals, outcomes, correlations, edge estimates)
  ├── All hypotheses (state, evidence, confidence)
  ├── Agent assignments and market allocations
  ├── Strategy outcomes and post-mortems
  └── Hive decisions (approvals, rejections, directives)

Engine State (per-engine SQLite):
  ├── Open orders
  ├── Active positions
  ├── Fill history
  ├── P&L tracking
  └── Risk state (daily baseline, kill switch)

Swarm State (swarm.db SQLite):
  ├── Agent registry (id, mode, directive, phase, spawned_at)
  ├── Capital allocation table
  ├── Hive decision log
  ├── Agent scorecard snapshots
  └── Circuit breaker state (peak NAV, current DD)

NAV History (append-only JSONL):
  ├── Timestamped NAV snapshots
  ├── Per-strategy P&L
  └── Portfolio composition
```

### 13.2 Crash Recovery Protocol

```
On startup, the Swarm checks for prior state:

Step 1: Load swarm state from swarm.db
  → Reconstruct agent registry
  → Reconstruct capital allocations
  → Reconstruct Hive decision history

Step 2: Load engine states
  → For each previously active strategy:
     - Restore positions from engine SQLite
     - Restore open orders
     - Reconcile with exchange (poll current positions/orders via API)
     - If mismatch: log warning, trust exchange state (source of truth)

Step 3: Load knowledge graph
  → All market intelligence, hypotheses, outcomes intact
  → Verify HMAC integrity checks on all records

Step 4: Assess situation
  Hive receives recovery context:
  "Swarm restarted after crash. Prior state:
   - 4 strategies were live (positions restored from exchange)
   - 3 agents were researching (progress lost — restart research)
   - 1 agent was mid-backtest (restart from beginning)
   - NAV at crash: $103,450
   - Current NAV (from exchange positions): $103,200 (-$250 since crash)
   - All feeds were disconnected (reconnecting now)"

Step 5: Hive decides recovery strategy
  "Positions are intact — exchanges held them. NAV slip is small ($250).
   I'll restart the 4 trading agents with their strategy configs from
   the database. Research agents lose their in-flight work but the
   knowledge graph has everything they already committed. Restarting
   them from scratch is fine — they'll check the graph first anyway."

Step 6: Rebuild agent population
  → Spawn trading agents for active strategies
  → Spawn research agents at previous count
  → Resume normal Hive reasoning loop
```

### 13.3 Agent-Level Fault Tolerance

Individual agents can crash without affecting the swarm:

```
Agent crash scenarios and recovery:

1. LLM API timeout / error
   → Agent catches exception
   → Retries with exponential backoff (1s, 2s, 4s, max 30s)
   → After 5 consecutive failures: agent enters RECOVERING state
   → Hive is notified: "Agent-7 LLM connection issues"
   → If executing: open orders remain (exchange holds them)
   → If not recovered in 5 minutes: Hive terminates and respawns

2. Tool call fails (SDK function error)
   → Agent catches exception, logs error with full traceback
   → LLM receives error message and reasons about it:
     "submit_order failed: 'market not found'. The market may have
      settled. Let me check... [calls get_market_detail] ...
      Yes, market resolved. I need to retire this strategy."
   → The LLM handles errors as part of its reasoning — not a crash

3. Agent thread dies (unhandled exception)
   → Swarm Manager detects missing heartbeat within 30 seconds
   → If agent was executing:
     - Engine kill switch activated for that agent's markets
     - All orders canceled
     - Positions preserved (will be handled on respawn)
   → Hive notified: "Agent-7 died unexpectedly"
   → Hive decides: respawn with same config, or investigate first

4. WebSocket disconnection
   → Agent reconnects with exponential backoff
   → Missed events are NOT replayed (WebSocket is ephemeral)
   → Agent reads knowledge graph on reconnect to catch up
   → If disconnected > 60 seconds while executing:
     Agent pauses trading until reconnected (can't receive Hive commands)
```

### 13.4 Heartbeat and Health Monitoring

```
Every agent sends a heartbeat every 10 seconds:

Heartbeat:
  agent_id: 7
  timestamp: 1711000000
  phase: "executing"
  health: "OK"      # OK | DEGRADED | RECOVERING | STALE
  llm_responsive: true
  last_tool_call: "2s ago"
  last_ws_event_received: "1s ago"
  memory_usage_mb: 120
  open_positions: 1
  open_orders: 2

Swarm Manager monitors:
  for each agent:
    if no heartbeat in 30 seconds:
      mark as STALE
      notify Hive: "Agent-{id} heartbeat missing"
    if no heartbeat in 60 seconds:
      mark as DEAD
      trigger crash recovery for that agent

Hive monitors degraded agents:
  "Agent-8 has been in DEGRADED state for 10 minutes (LLM timeouts).
   It's not executing trades, just researching, so no risk.
   I'll give it 10 more minutes. If still degraded, terminate and
   spawn a replacement."
```

### 13.5 Graceful Shutdown

```
SIGTERM received:

1. Swarm Manager sets global SHUTTING_DOWN flag
2. Hive receives shutdown signal
   → Issues directive to all agents: "Graceful shutdown initiated"

3. Executing agents:
   → Cancel all open orders (cancel_all_orders per engine)
   → Close positions if configured (optional — may want to keep them)
   → Persist final state to engine SQLite
   → Write post-mortem for interrupted strategies

4. Research/analysis agents:
   → Commit any findings to knowledge graph
   → Persist current progress

5. Hive:
   → Write final swarm state to swarm.db
   → Record shutdown reason and timestamp

6. All agents terminated
7. Feeds shut down
8. WebSocket server closed
9. Process exits cleanly

Total shutdown time budget: 60 seconds
After 60 seconds: force-kill remaining threads
```

---

## 14. Scalability

### 14.1 Resource Budget Model

Every agent consumes resources. The Hive manages a total budget:

```
Resource Budget:
  ┌──────────────────────────────────────────────────────┐
  │ Resource          │ Limit    │ Current │ Per Agent   │
  ├──────────────────────────────────────────────────────┤
  │ LLM cost/hour     │ $50/hr   │ $34/hr  │ ~$2-3/hr   │
  │ Memory            │ 16 GB    │ 4.2 GB  │ ~200 MB    │
  │ Concurrent feeds  │ 50       │ 18      │ shared     │
  │ Engine instances   │ 20       │ 8       │ 1 per exec │
  │ API calls/min     │ varies   │ varies  │ rate-limit │
  │ SQLite writers     │ 1 (WAL) │ 1       │ serialized │
  │ WebSocket conns    │ 100      │ 14      │ 1 per agent│
  │ Thread count       │ 50       │ 16      │ 1 per agent│
  └──────────────────────────────────────────────────────┘
```

### 14.2 LLM Cost Management

The dominant cost is LLM API calls. The Hive actively manages this:

```
Cost tiers by agent activity:

  Executing agent (high-frequency):
    ~120 reasoning cycles/hour × $0.02/cycle = $2.40/hour
    But: execution cycles are SHORT (1-2 tool calls each)
    Optimization: batch context (include last 5 cycles' data in one call)

  Researching agent:
    ~30 cycles/hour × $0.03/cycle = $0.90/hour
    Research cycles are LONGER (5-10 tool calls each)

  Analyzing agent (backtesting):
    ~20 cycles/hour × $0.05/cycle = $1.00/hour
    Analysis cycles are LONGEST (many tool calls for backtesting)

  Hive:
    ~60 cycles/hour × $0.10/cycle = $6.00/hour
    Hive processes more context (all agents + portfolio)

  Total for 12 agents + Hive:
    ~$25-35/hour = ~$600-840/day

Cost controls:
  1. Daily budget cap ($500 default) — Hive stops spawning agents at 80%
  2. Per-agent budget — terminate agents that burn cost without results
  3. Adaptive cycle frequency — slow down research agents when budget tight
  4. Cache LLM context — don't re-send unchanged portfolio state
  5. Hive metric: ROI on LLM cost — portfolio P&L / total LLM spend
     Target: >3x (every $1 in LLM cost should generate $3+ in P&L)
```

### 14.3 Dynamic Scaling

```
The Hive scales the agent population based on opportunity density:

Low opportunity (bear market, few mispriced markets):
  → Reduce to 2-4 agents (mostly research, no new deployments)
  → Lower LLM cost, preserve capital
  → Hive reasoning: "Market efficiency is high across all sectors.
    No validated hypotheses in 3 days. Scaling down to 3 agents
    (2 research, 1 monitoring existing positions)."

Normal (typical market conditions):
  → 8-12 agents (mix of research, analysis, execution)
  → Standard LLM budget
  → Hive reasoning: "Steady discovery rate of 2-3 hypotheses/day.
    4 strategies executing profitably. Good balance."

High opportunity (major event, regime change, new markets):
  → Scale to 15-20 agents (many directed agents on specific opportunities)
  → Higher LLM budget (opportunity justifies the cost)
  → Hive reasoning: "Election week — 50 new prediction markets appeared.
    Multiple regime changes detected. Spawning 5 directed agents for
    the highest-volume new markets. Budget increase authorized."

Scaling decisions (Hive, every cycle):
  opportunity_density = validated_hypotheses_per_day / active_agents
  if opportunity_density > 0.5 and budget_remaining > 30%:
    spawn_agent()  # More opportunities than agents can handle
  if opportunity_density < 0.1 and agent_count > min_agents:
    terminate_lowest_score_agent()  # Not enough opportunity to justify cost
```

### 14.4 Feed and Engine Sharing

Feeds and engines are the most expensive shared resources (WebSocket connections, API connections, memory):

```
Feed Sharing:
  When Agent-7 needs Binance BTC price:
    1. Check FeedRegistry: "binance_btcusdt" already running (started by Agent-2)
    2. Register as consumer: binance_btcusdt.consumers += [agent-7]
    3. Read from shared FeedManager snapshot (lock-free DashMap)
    4. When Agent-7 stops needing it: unregister
    5. Feed shuts down only when last consumer leaves

  Benefits:
    - 1 WebSocket connection serves 10 agents (vs 10 connections)
    - Feed reconnect logic shared (one reconnect, all agents benefit)
    - Memory: one snapshot, not 10 copies

Engine Pooling:
  Pre-allocated engines per exchange × mode:
    paper_polymarket_engine_1, paper_polymarket_engine_2, ...
    live_polymarket_engine_1, ...
    paper_kalshi_engine_1, ...

  When Agent-7 needs a paper Polymarket engine:
    1. Request from pool: engine = pool.acquire("paper", "polymarket")
    2. Engine comes pre-configured with risk limits
    3. Agent uses it for its strategy lifecycle
    4. On termination: pool.release(engine) — engine state reset

  Benefits:
    - No startup cost per agent (engines pre-warmed)
    - Bounded total engine count (pool size = max engines)
    - Clean state on reuse (positions cleared, orders canceled)
```

### 14.5 Horizontal Scaling (Future)

The current design is single-process (threads). For scaling beyond ~20 agents:

```
Phase 1 (current): Single process, threads
  Max: ~20 agents on one machine
  Bottleneck: LLM API concurrency, SQLite write serialization

Phase 2 (future): Multi-process with shared state
  - Each agent as a subprocess
  - PostgreSQL instead of SQLite (concurrent writers)
  - Redis for WebSocket pub/sub (vs in-process bus)
  - Max: ~100 agents across multiple machines

Phase 3 (far future): Distributed swarm
  - Multiple Hives (hierarchical: regional Hives + global Hive)
  - Agents on different machines/regions
  - Low-latency exchange proximity
  - Max: unlimited
```

---

## 15. Putting It All Together: A Day in the Life

```
06:00 — Swarm starts. Hive spawns 4 agents.
  Agent-1: free-roaming (Polymarket)
  Agent-2: free-roaming (Kalshi)
  Agent-3: directed ("Check if overnight crypto moves created prediction mispricings")
  Agent-4: directed ("Scan economic calendar — CPI release at 08:30")

06:15 — Agent-3 finds BTC prediction market 3 cents wide after overnight rally.
  Runs alpha model → composite alpha 0.04, confidence 0.7
  Starts backtest.

06:45 — Agent-4 researches CPI market.
  Finds lead-lag: Treasury yields → CPI prediction market (Granger p=0.01)
  Starts building hypothesis.

07:00 — Agent-3's backtest completes. Sharpe 1.5.
  Runs 5 gates: deflated Sharpe p=0.03 ✓, walk-forward 72% ✓,
  PBO=0.22 ✓, bootstrap CI [0.02, 0.08] ✓, causal mechanism confirmed ✓
  Submits proposal to Hive.

07:05 — Hive reviews Agent-3's proposal.
  "Strong evidence. Low correlation with portfolio (we have no crypto
   strategies running). Approved for paper at $5,000."
  Agent-3 begins paper trading.

08:00 — Agent-1 (free-roaming) finds 5 weather markets on Kalshi.
  Publishes to knowledge graph. No immediate edge but good for future.

08:30 — CPI release. Agent-4 detects BOCPD change point.
  Treasury yields spike → Agent-4's lead-lag model triggers.
  "CPI came in hot. My model predicts the fed rate prediction market
   will reprice in ~5 minutes. Edge: 5 cents YES side."
  Runs backtest rapidly. Sharpe 1.8. Submits proposal.

08:35 — Hive reviews. "Time-sensitive. CPI-driven edge decays in hours.
  Backtest looks good but only 80 trades (marginal n). PBO=0.28.
  I'll approve for paper only — if it works for 2 days, fast-track
  to shadow."

09:00 — Hive spawns Agent-5 (directed): "Investigate cross-market cascade
  from CPI surprise. Treasury → Fed rate → BTC → ALT crypto.
  Which markets in the cascade haven't repriced yet?"

09:30 — Agent-5 finds: ALT crypto prediction markets haven't repriced yet.
  "SOL and AVAX prediction markets are lagged by ~2 hours from BTC.
   Granger test confirms BTC leads SOL prediction market (p=0.02, lag=4h)."
  Starts analysis.

12:00 — Agent-3 (BTC paper trading) reports: Sharpe 2.1 after 6 hours.
  Hive reviews: "Unusually high Sharpe for 6 hours — could be luck.
  Continue paper. Too early for any promotion."

14:00 — Agent-1 (free-roaming) discovers an NBA playoff market with
  high spread and an ESPN feed advantage.
  "ESPN scoreboard updates faster than Polymarket prices by ~30 seconds
   during live games. This is a pure information advantage."
  Submits analysis.

15:00 — Hive assesses swarm:
  "5 agents running. Agent-4 (CPI) P&L: +$200 paper. Agent-3 (BTC)
   P&L: +$150 paper. Agent-5 still analyzing. Agent-1 found NBA lead.
   Agent-2 (Kalshi free-roaming) score 0.40 — hasn't found anything.

   Actions:
   - Redirect Agent-2: 'Focus on Kalshi election markets specifically'
   - Spawn Agent-6: directed to validate Agent-1's NBA/ESPN thesis
   - Agent-5 should have results by now — check in"

18:00 — Agent-5 validated SOL lead-lag. Submitted proposal.
  Hive approves paper trading.

20:00 — NBA game tonight. Agent-6 is ready with ESPN feed integration.
  Has validated the 30-second information advantage.
  Sharpe in backtest: 3.2 (but very few trades — sports events are sparse).
  Hive: "Edge is real but sample size is tiny. Paper only. Let's see
  how it performs over 10 games before considering live."

23:00 — End of day. Hive summarizes:
  "NAV flat (all paper today). 6 agents active. 3 strategies paper trading.
   2 new hypotheses validated. 1 agent underperforming (redirected).
   LLM cost today: $180. No revenue yet (all paper).

   Tomorrow: continue paper trading all 3. If Agent-3 (BTC) and Agent-4
   (CPI) maintain performance, consider shadow promotion at day 3
   (accelerated — CPI thesis is time-sensitive and will decay)."
```

---

## 16. Implementation Plan

### Phase 1: Agent Runtime + Hive Foundation

The core loop: one agent can start, reason, call tools, and communicate with the Hive.

```
python/horizon/swarm/
├── __init__.py           # Swarm entry point, SwarmManager
├── _config.py            # SwarmConfig dataclass
├── _agent.py             # Agent runtime (thread, LLM loop, tool dispatch, heartbeat)
├── _hive.py              # Hive runtime (LLM loop, proposal review, agent lifecycle)
├── _bus.py               # WebSocket event bus (asyncio server + typed events)
├── _tools.py             # Tool registry (maps LLM function calls → SDK operations)
├── _context.py           # Context assembly (agent context + hive context)
├── _circuit_breaker.py   # Non-LLM watchdog (NAV monitor, hard kill switches)
└── _state.py             # Swarm state persistence (swarm.db SQLite)
```

Deliverables:
- Agent lifecycle state machine (SPAWNED → RUNNING → PAUSED → STOPPED)
- Agent LLM loop with tool dispatch (230+ tools)
- Hive LLM loop with proposal review and agent spawn/kill
- WebSocket event bus with typed channels
- Heartbeat monitoring + stale agent detection
- Circuit breaker (non-LLM) running independently
- State persistence: agent registry, capital allocations, decisions

Exit criteria: One agent discovers a market, analyzes it, backtests it,
passes 5 gates, submits proposal, Hive approves, agent starts paper trading.

### Phase 2: Multi-Agent + Knowledge Sharing + Scoring

Multiple agents run in parallel, share resources, and the Hive tracks performance.

```
├── _feed_registry.py     # Shared feed management (consumers, auto-cleanup)
├── _engine_pool.py       # Pre-allocated engine instances per exchange
├── _knowledge.py         # Knowledge graph read/write helpers for agents
├── _scorecard.py         # Agent scorecard computation (metrics, tiers)
├── _cost_tracker.py      # LLM cost tracking + budget enforcement
└── _dashboard.py         # Swarm TUI dashboard (Textual)
```

Deliverables:
- 4+ agents running simultaneously with shared feeds
- Knowledge graph anti-duplication (check before research)
- WebSocket broadcast: signals from one agent reach all others
- Agent scorecard: automated performance scoring
- Hive uses scores for spawn/kill/redirect decisions
- Feed and engine sharing (one feed, many consumers)
- LLM cost tracking with daily budget cap
- TUI dashboard with agent states, P&L, risk, events

Exit criteria: 4 agents discover independently, share findings via knowledge
graph and WebSocket, Hive tracks scores and terminates underperformers.

### Phase 3: Full Pipeline + Anti-Overfitting + Spawning Modes

The complete agent workflow, anti-overfitting gates, and Hive active command.

```
├── _gates.py             # Five anti-overfitting gates (automated validation)
├── _postmortem.py        # Structured post-mortem generation
├── _promotion.py         # Paper → shadow → live pipeline
└── _spawner.py           # Free-roaming vs directed agent spawning
```

Deliverables:
- Full 8-phase pipeline operational (research → post-mortem)
- Five anti-overfitting gates enforced on every deployment proposal
- Paper → shadow → live promotion (Hive-approved transitions)
- Post-mortem + knowledge transfer on strategy retirement
- Free-roaming agent mode (broad exploration)
- Directed agent mode (specific mission from Hive)
- Hive active command: spawn, redirect, terminate, promote
- Dynamic agent population management (scale up/down)

Exit criteria: Complete autonomous loop — Hive spawns agent, agent discovers
and deploys strategy through paper/shadow/live, monitors, evolves, retires
with post-mortem, knowledge feeds next agent's research.

### Phase 4: Reliability + Hardening

Production-grade fault tolerance.

```
├── _recovery.py          # Crash recovery protocol
└── _rate_limiter.py      # API rate limiting (LLM + exchange)
```

Deliverables:
- Graceful shutdown (SIGTERM → cancel orders → persist → exit)
- Crash recovery (rebuild agent population from persisted state)
- Exchange reconciliation (trust exchange positions after crash)
- Per-agent fault tolerance (LLM timeout retry, tool error handling)
- Rate limiting: LLM API, exchange API, tool call budgets
- Adversarial testing: what if the LLM reasons badly?
- Multi-agent integration tests (10+ agents, regime changes, crashes)
- Stress tests (max agents, max feeds, exchange outages)

Exit criteria: Swarm survives kill -9, restarts cleanly, reconciles
with exchanges, resumes trading with no lost state.
