#!/usr/bin/env bun
/**
 * Horizon Swarm TUI (OpenTUI)
 *
 * Usage:
 *   bun run swarm-ui/src/index.tsx
 *   bun run swarm-ui/src/index.tsx --url ws://127.0.0.1:8765
 *
 * Commands inside the TUI:
 *   /start        — launch the Python backend in the background
 *   /stop         — stop the Python backend
 *   spawn [mission] — tell the hive to spawn an agent
 *   kill <id>     — kill an agent
 *   pause / resume / status / kg / stop
 */

import { render } from "@opentui/solid";
import { resolve } from "path";
import { App } from "./App.js";

let wsUrl = "ws://127.0.0.1:8765";

const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  if ((args[i] === "--url" || args[i] === "--ws-url") && args[i + 1]) {
    wsUrl = args[i + 1]!;
    i++;
  }
}

// Set project root so BackendManager can find `python -m horizon.swarm`
if (!process.env.HORIZON_ROOT) {
  process.env.HORIZON_ROOT = resolve(import.meta.dir, "../..");
}

await render(() => <App wsUrl={wsUrl} />);
