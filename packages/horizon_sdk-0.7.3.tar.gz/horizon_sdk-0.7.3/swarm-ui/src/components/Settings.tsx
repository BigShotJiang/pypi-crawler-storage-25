import { createSignal, For } from "solid-js";
import { useKeyboard } from "@opentui/solid";
import { TX, C, I, BG } from "../theme.js";

interface Setting { key: string; env: string; label: string; value: string; masked?: boolean; }

function getSettings(): Setting[] {
  const e = process.env;
  return [
    { key: "api_key", env: "OPENROUTER_API_KEY", label: "API Key", value: e.OPENROUTER_API_KEY ?? "", masked: true },
    { key: "hive_model", env: "SWARM_HIVE_MODEL", label: "Hive Model", value: e.SWARM_HIVE_MODEL ?? "claude-sonnet-4.6" },
    { key: "agent_model", env: "SWARM_AGENT_MODEL", label: "Agent Model", value: e.SWARM_AGENT_MODEL ?? "gpt-5.4-mini" },
    { key: "max_agents", env: "SWARM_MAX_AGENTS", label: "Max Agents", value: e.SWARM_MAX_AGENTS ?? "10" },
    { key: "max_capital", env: "SWARM_MAX_CAPITAL", label: "Capital", value: e.SWARM_MAX_CAPITAL ?? "$10,000" },
    { key: "max_drawdown", env: "SWARM_MAX_DRAWDOWN", label: "Drawdown", value: e.SWARM_MAX_DRAWDOWN ?? "10%" },
    { key: "exchange", env: "SWARM_EXCHANGE", label: "Exchange", value: e.SWARM_EXCHANGE ?? "paper" },
  ];
}

function mask(s: string): string {
  if (s.length <= 8) return "*".repeat(s.length);
  return s.slice(0, 4) + "*".repeat(Math.min(s.length - 8, 16)) + s.slice(-4);
}

interface Props { cols: number; onClose: () => void; }

export function Settings(props: Props) {
  const [settings, setSettings] = createSignal<Setting[]>(getSettings());
  const [cur, setCur] = createSignal(0);
  const [editing, setEditing] = createSignal(false);
  const [buf, setBuf] = createSignal("");
  const [saved, setSaved] = createSignal("");

  useKeyboard((k) => {
    if (k.name === "escape") {
      if (editing()) setEditing(false);
      else props.onClose();
      return;
    }
    if (editing()) {
      if (k.name === "return") {
        const s = settings()[cur()]!;
        process.env[s.env] = buf();
        setSettings((p) => p.map((item, i) => i === cur() ? { ...item, value: buf() } : item));
        setEditing(false);
        setSaved(`${I.check} saved`);
        return;
      }
      if (k.name === "backspace" || k.name === "delete") { setBuf((b) => b.slice(0, -1)); return; }
      if (k.name.length === 1 && !k.ctrl && !k.meta) setBuf((b) => b + k.name);
      return;
    }
    if (k.name === "down") setCur((c) => Math.min(c + 1, settings().length - 1));
    if (k.name === "up") setCur((c) => Math.max(c - 1, 0));
    if (k.name === "return") { setEditing(true); setBuf(settings()[cur()]!.value); setSaved(""); }
  });

  return (
    <box flexDirection="column" flexGrow={1}>
      {/* header */}
      <box width="100%" height={1} flexDirection="row" justifyContent="space-between">
        <text fg={C.primary}><b>settings</b></text>
        <text fg={TX.dim}>esc {"\u00D7"} {saved()}</text>
      </box>

      <box height={1} />

      {/* settings rows */}
      <For each={settings()}>{(s, i) => {
        const sel = () => i() === cur();
        const val = () => s.masked && !editing() ? mask(s.value) : s.value;
        return (
          <box width="100%" height={1} flexDirection="row" backgroundColor={sel() ? BG.selection : undefined}>
            <text fg={sel() ? C.primary : TX.dim}>{sel() ? I.ptr : " "} </text>
            <text fg={TX.muted}>{s.label.padEnd(16)}</text>
            {sel() && editing()
              ? <text fg={TX.primary}>{buf()}<text fg={TX.dim}>_</text></text>
              : <text fg={sel() ? TX.primary : TX.muted}>{val() || "not set"}</text>
            }
          </box>
        );
      }}</For>

      <box marginTop={1}>
        <text fg={TX.dim}>{"\u2191\u2193"} navigate {I.dot} enter edit {I.dot} esc close</text>
      </box>
    </box>
  );
}
