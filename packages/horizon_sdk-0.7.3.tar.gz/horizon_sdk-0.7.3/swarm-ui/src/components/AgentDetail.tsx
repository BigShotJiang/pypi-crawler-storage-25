import { createSignal, For, Show } from "solid-js";
import { useKeyboard } from "@opentui/solid";
import type { SwarmState, LLMTurn } from "../state/store.js";
import { BG, TX, C, PHASE_CLR, I } from "../theme.js";
import { useSpinner, ts, pad, trunc, spark } from "./hooks.js";

const PHASES = ["res", "ana", "bkt", "rob", "prp", "exe", "mon", "evo", "ret"];
const PHASE_FULL = ["researching", "analyzing", "backtesting", "robustness", "proposing", "executing", "monitoring", "evolving", "retiring"];

interface Props { state: SwarmState; agentId: string; onBack: () => void; cols: number; }

/** Split long text into lines that fit within cols */
function wrapLines(text: string, cols: number): string[] {
  if (!text) return [];
  const raw = text.split("\n");
  const out: string[] = [];
  for (const line of raw) {
    if (line.length <= cols) {
      out.push(line);
    } else {
      // Word-wrap
      let remaining = line;
      while (remaining.length > cols) {
        let cut = remaining.lastIndexOf(" ", cols);
        if (cut <= 0) cut = cols;
        out.push(remaining.slice(0, cut));
        remaining = remaining.slice(cut).trimStart();
      }
      if (remaining) out.push(remaining);
    }
  }
  return out;
}

export function AgentDetail(props: Props) {
  const spinner = useSpinner();
  const ag = () => props.state.agents.get(props.agentId);
  const [panel, setPanel] = createSignal<"llm" | "ops">("llm");

  useKeyboard((k) => {
    if (k.name === "tab") setPanel((p) => p === "llm" ? "ops" : "llm");
  });

  return (
    <Show when={ag()} fallback={<text fg={C.error}>not found</text>}>
      {(a) => {
        const alive = () => a().status === "running";
        const pClr = () => a().pnl >= 0 ? C.success : C.error;
        const phClr = () => PHASE_CLR[a().phase] ?? TX.muted;
        const icon = () => alive() ? spinner() : a().status === "error" ? I.cross : I.stopped;
        const chart = () => spark(a().pnlHistory, 20);
        const idx = () => PHASE_FULL.indexOf(a().phase);
        const fmtCap = () => {
          const c = a().capital;
          return c >= 1000 ? `$${(c / 1000).toFixed(1)}k` : `$${c.toFixed(0)}`;
        };
        const contentCols = () => Math.max(20, props.cols - 8);

        return (
          <box flexDirection="column" flexGrow={1} width="100%">
            {/* ── header: all metrics on ONE LINE ── */}
            <box width="100%" height={1} flexDirection="row">
              <text fg={phClr()}><b>{icon()} {a().id}</b></text>
              <text fg={phClr()}>{"   "}{a().phase}</text>
              <text fg={pClr()}>{"   "}{a().pnl >= 0 ? "+" : ""}${a().pnl.toFixed(2)}</text>
              <text fg={TX.muted}>{"   "}{fmtCap()}</text>
              <text fg={TX.muted}>{"   "}{a().trades}t</text>
              <text fg={TX.muted}>{"   "}${a().cost.toFixed(3)}</text>
              <text fg={TX.muted}>{"   "}{a().turns} turns</text>
              <text fg={pClr()}>{"   "}{chart()}</text>
            </box>

            {/* ── phase pipeline: abbreviated dots ── */}
            <box width="100%" height={1} flexDirection="row">
              <For each={PHASES}>{(p, i) => {
                const done = () => i() < idx();
                const active = () => i() === idx();
                const clr = () => active() ? C.primary : done() ? C.success : TX.dim;
                return <text fg={clr()}>{active() ? I.alive : done() ? I.alive : I.idle}{p}{"  "}</text>;
              }}</For>
            </box>

            <box height={1} width="100%" />

            {/* ── panel switcher ── */}
            <box width="100%" height={1} flexDirection="row" justifyContent="space-between">
              <box flexDirection="row">
                <text fg={panel() === "llm" ? C.primary : TX.dim}>{panel() === "llm" ? <b>reasoning</b> : "reasoning"}</text>
                <text>{"                    "}</text>
                <text fg={panel() === "ops" ? C.primary : TX.dim}>{panel() === "ops" ? <b>operations</b> : "operations"}</text>
              </box>
              <text fg={TX.dim}>tab to switch {I.dot} esc back</text>
            </box>

            <box height={1} width="100%" />

            {/* ── reasoning panel ── */}
            <Show when={panel() === "llm"}>
              <box flexDirection="column" flexGrow={1} width="100%">
                <scrollbox flexGrow={1} width="100%" stickyScroll={true} stickyStart="bottom">
                  <Show when={a().reasoning.length > 0} fallback={
                    <box flexDirection="column" width="100%">
                      <text fg={TX.dim}>{spinner()} waiting for llm response{I.ellip}</text>
                      {/* Show activity log as fallback when no reasoning yet */}
                      <Show when={a().log.length > 1}>
                        <box height={1} />
                        <text fg={TX.muted}>activity while waiting:</text>
                        <For each={a().log.filter(e => e.type !== "heartbeat" && e.type !== "llm_delta").slice(-10)}>{(ev) => {
                          const d = ev.data as Record<string, any>;
                          let desc = ev.type.replace(/_/g, " ");
                          if (ev.type === "agent_phase_changed") desc = `phase ${I.ptr} ${d.new_phase ?? "?"}`;
                          else if (ev.type === "agent_spawned") desc = `spawned (${d.mission ?? "free-roaming"})`;
                          else if (ev.type === "agent_error") desc = `error: ${d.error ?? "?"}`;
                          return (
                            <box width="100%" height={1} flexDirection="row">
                              <text fg={TX.dim}>{ts(ev.timestamp).slice(0, 5)}</text>
                              <text fg={TX.muted}>{"  "}{desc}</text>
                            </box>
                          );
                        }}</For>
                      </Show>
                    </box>
                  }>
                    <For each={a().reasoning.slice(-50)}>{(turn) => (
                      <box flexDirection="column" width="100%">
                        {/* turn header: timestamp + turn number + phase */}
                        <box width="100%" height={1} flexDirection="row">
                          <text fg={TX.dim}>{ts(turn.ts).slice(0, 5)}</text>
                          <text fg={turn.error ? C.error : C.primary}>{"  "}t{turn.turn}</text>
                          <text fg={TX.dim}>{"  "}{turn.phase}</text>
                        </box>

                        {/* tool calls with arguments */}
                        <Show when={turn.toolArgs.length > 0}>
                          <For each={turn.toolArgs}>{(ta) => (
                            <box width="100%" height={1} flexDirection="row">
                              <text fg={C.info}>{"    "}{trunc(ta, contentCols())}</text>
                            </box>
                          )}</For>
                        </Show>
                        <Show when={turn.toolArgs.length === 0 && turn.toolCalls.length > 0}>
                          <box width="100%" height={1} flexDirection="row">
                            <text fg={C.info}>{"    "}{turn.toolCalls.join(", ")}</text>
                          </box>
                        </Show>

                        {/* multi-line content */}
                        <Show when={turn.content}>
                          <For each={wrapLines(turn.content, contentCols())}>{(line) => (
                            <box width="100%" height={1} flexDirection="row">
                              <text fg={turn.error ? C.error : TX.primary}>{"    "}{line}</text>
                            </box>
                          )}</For>
                        </Show>

                        {/* blank line between turns */}
                        <box width="100%" height={1} />
                      </box>
                    )}</For>
                  </Show>
                </scrollbox>

                {/* streaming buffer at bottom */}
                <Show when={a().streamBuf}>
                  <box width="100%" flexDirection="column">
                    <For each={wrapLines(a().streamBuf, contentCols()).slice(-3)}>{(line) => (
                      <box width="100%" height={1} flexDirection="row">
                        <text fg={C.info}>{I.ptr} {line}</text>
                      </box>
                    )}</For>
                  </box>
                </Show>
              </box>
            </Show>

            {/* ── operations panel ── */}
            <Show when={panel() === "ops"}>
              <box flexDirection="row" flexGrow={1} width="100%">
                {/* event log */}
                <box flexDirection="column" width={Math.floor(props.cols * 0.55)} flexShrink={0}>
                  <box width="100%" height={1}><text fg={TX.muted}><b>log</b></text></box>
                  <For each={a().log.filter((e) => e.type !== "llm_turn" && e.type !== "llm_delta" && e.type !== "heartbeat").slice(-14)}>{(ev) => {
                    const d = ev.data as Record<string, any>;
                    let lbl = ev.type.replace(/_/g, " ").slice(0, 8).toUpperCase();
                    let clr = TX.dim;
                    let detail = "";
                    if (ev.type === "agent_phase_changed") { lbl = "PHASE"; clr = C.info; detail = `${I.ptr} ${d.new_phase ?? ""}`; }
                    else if (ev.type === "order_submitted") { lbl = "ORDER"; clr = C.success; detail = `${d.side ?? ""} ${d.market_id ?? ""}`; }
                    else if (ev.type === "proposal_submitted") { lbl = "PROPOSE"; clr = C.accent; detail = d.market_id ?? ""; }
                    else if (ev.type === "agent_error") { lbl = "ERROR"; clr = C.error; detail = (d.error as string)?.slice(0, 20) ?? ""; }
                    else if (ev.type === "agent_spawned") { lbl = "SPAWN"; clr = C.primary; detail = (d.mission as string)?.slice(0, 20) ?? ""; }
                    else if (ev.type === "knowledge_shared") { lbl = "KG"; clr = C.accent; detail = (d.entity as string)?.slice(0, 20) ?? ""; }
                    return (
                      <box width="100%" height={1} flexDirection="row">
                        <text fg={TX.dim}>{ts(ev.timestamp).slice(0, 5)} </text>
                        <text fg={clr}>{pad(lbl, 8)}</text>
                        <text fg={TX.muted}> {detail}</text>
                      </box>
                    );
                  }}</For>
                </box>

                {/* proposals */}
                <box flexDirection="column" flexGrow={1}>
                  <box width="100%" height={1}><text fg={TX.muted}><b>proposals</b></text></box>
                  <Show when={props.state.proposals.filter((p) => p.agentId === props.agentId).length > 0} fallback={<text fg={TX.dim}>none</text>}>
                    <For each={props.state.proposals.filter((p) => p.agentId === props.agentId).slice(-5)}>{(p) => (
                      <box width="100%" height={1} flexDirection="row">
                        <text fg={p.verdict === "approved" ? C.success : p.verdict === "rejected" ? C.error : TX.dim}>
                          {p.verdict === "approved" ? I.check : p.verdict === "rejected" ? I.cross : I.dot}
                        </text>
                        <text fg={TX.muted}> {trunc(p.market, 14)} {p.side}</text>
                      </box>
                    )}</For>
                  </Show>
                </box>
              </box>
            </Show>
          </box>
        );
      }}
    </Show>
  );
}
