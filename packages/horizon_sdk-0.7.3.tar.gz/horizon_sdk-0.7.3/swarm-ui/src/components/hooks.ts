/**
 * Shared utilities and reactive primitives for OpenTUI/Solid.
 */
import { createSignal, onCleanup } from "solid-js";
import { BLOCKS, BAR_FULL, BAR_EMPTY } from "../theme.js";

/* braille spinner */
const BRAILLE = ["\u280B", "\u2819", "\u2839", "\u2838", "\u283C", "\u2834", "\u2826", "\u2827", "\u2807", "\u280F"];

export function useSpinner(): () => string {
  const [i, setI] = createSignal(0);
  const t = setInterval(() => setI((n) => (n + 1) % BRAILLE.length), 80);
  onCleanup(() => clearInterval(t));
  return () => BRAILLE[i()]!;
}

/* clock */
export function useClock(): () => string {
  const [t, setT] = createSignal(fmt(Date.now()));
  const id = setInterval(() => setT(fmt(Date.now())), 1000);
  onCleanup(() => clearInterval(id));
  return t;
}

function fmt(ms: number): string {
  return new Date(ms).toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

/* utils */
export function ts(epoch: number): string {
  return new Date(epoch * 1000).toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function pad(s: string, n: number): string {
  return s.length >= n ? s.slice(0, n) : s + " ".repeat(n - s.length);
}

export function trunc(s: string, n: number): string {
  return s.length <= n ? s : s.slice(0, n - 1) + "\u2026";
}

/* sparkline */
export function spark(values: number[], width: number): string {
  if (values.length === 0) return " ".repeat(width);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const out: string[] = [];
  for (let i = 0; i < width; i++) {
    const idx = Math.floor((i / width) * values.length);
    const norm = (values[idx]! - min) / range;
    out.push(BLOCKS[Math.min(Math.floor(norm * BLOCKS.length), BLOCKS.length - 1)]!);
  }
  return out.join("");
}

/* bar gauge */
export function bar(ratio: number, width: number): string {
  const c = Math.max(0, Math.min(1, ratio));
  const f = Math.round(c * width);
  return BAR_FULL.repeat(f) + BAR_EMPTY.repeat(width - f);
}

/* relative time */
export function ago(epoch: number): string {
  const d = Date.now() / 1000 - epoch;
  if (d < 60) return `${Math.floor(d)}s`;
  if (d < 3600) return `${Math.floor(d / 60)}m`;
  return `${Math.floor(d / 3600)}h${Math.floor((d % 3600) / 60)}m`;
}
