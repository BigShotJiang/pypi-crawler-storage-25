import { For, Show } from "solid-js";
import type { SwarmState } from "../state/store.js";
import type { SwarmEvent } from "../ws/client.js";
import { TX, C, PHASE_CLR, I } from "../theme.js";
import { useSpinner, ts, pad, trunc, spark } from "./hooks.js";

function fmtEvt(ev: SwarmEvent): { lbl: string; clr: string; det: string } {
  const d = ev.data as Record<string, any>;
  switch (ev.type) {
    case "proposal_verdict": return { lbl: (d.verdict as string)?.toUpperCase() ?? "?", clr: d.verdict === "approved" ? C.success : C.error, det: d.agent_id ?? "" };
    case "hive_agent_spawned": return { lbl: "SPAWN", clr: C.primary, det: (d.mission as string)?.slice(0, 18) || "free" };
    case "hive_capital_allocated": return { lbl: "CAP", clr: C.primary, det: `${d.agent_id ?? ""} $${d.amount ?? 0}` };
    case "hive_directive": return { lbl: "DIR", clr: C.warning, det: (d.directive as string)?.slice(0, 18) ?? "" };
    case "agent_phase_changed": return { lbl: "PHASE", clr: C.info, det: `${ev.source.slice(6)} ${I.ptr} ${d.new_phase ?? ""}` };
    case "order_submitted": return { lbl: "ORDER", clr: C.success, det: `${d.side ?? ""} ${d.market_id ?? ""}` };
    case "knowledge_shared": return { lbl: "KG", clr: C.accent, det: (d.entity as string)?.slice(0, 18) ?? "" };
    case "agent_error": return { lbl: "ERR", clr: C.error, det: ev.source.slice(6) };
    default: return { lbl: ev.type.replace(/_/g, " ").slice(0, 7).toUpperCase(), clr: TX.dim, det: "" };
  }
}

export function Dashboard(props: { state: SwarmState; cols: number }) {
  const spinner = useSpinner();
  const agents = () => Array.from(props.state.agents.values());
  const running = () => agents().filter((a) => a.status === "running").length;
  const pnlClr = () => props.state.totalPnl >= 0 ? C.success : C.error;
  const chart = () => spark(props.state.pnlHistory, Math.min(20, Math.floor(props.cols * 0.15)));

  const fmtCap = () => {
    const c = props.state.totalCapital;
    return c >= 1000 ? `$${(c / 1000).toFixed(1)}k` : `$${c.toFixed(0)}`;
  };

  const hiveLog = () => props.state.hiveLog.slice(-8);
  const events = () => props.state.events
    .filter((e) => e.type !== "heartbeat" && e.type !== "metrics_update" && e.type !== "system_status" && e.type !== "llm_turn" && e.type !== "llm_delta")
    .slice(-8);
  const half = () => Math.floor(props.cols / 2);

  return (
    <box flexDirection="column" flexGrow={1} width="100%">
      {/* ── hive summary line ── */}
      <box width="100%" height={1} flexDirection="row" justifyContent="space-between">
        <box flexDirection="row">
          <text fg={C.primary}><b>{spinner()} hive</b></text>
        </box>
        <box flexDirection="row">
          <text fg={TX.muted}>{running()}/{props.state.agents.size} agents</text>
          <text fg={TX.muted}>{"  "}{I.dot}{"  "}{fmtCap()}</text>
          <text fg={pnlClr()}>{"  "}{I.dot}{"  "}{props.state.totalPnl >= 0 ? "+" : ""}{props.state.totalPnl.toFixed(2)}</text>
        </box>
      </box>

      <box height={1} width="100%" />

      {/* ── agent rows ── */}
      <Show when={agents().length > 0} fallback={
        <box width="100%" height={1}><text fg={TX.dim}>{spinner()} waiting for agents{I.ellip}</text></box>
      }>
        <For each={agents()}>{(a) => {
          const alive = () => a.status === "running";
          const pClr = () => a.pnl >= 0 ? C.success : C.error;
          const phClr = () => PHASE_CLR[a.phase] ?? TX.dim;
          const icon = () => alive() ? spinner() : a.status === "error" ? I.cross : I.stopped;
          const fmtAgentCap = () => {
            const c = a.capital;
            return c >= 1000 ? `$${(c / 1000).toFixed(1)}k` : `$${c.toFixed(0)}`;
          };
          return (
            <box width="100%" height={1} flexDirection="row">
              <text fg={alive() ? TX.primary : TX.dim}>{pad(a.id.slice(6), 5)}</text>
              <text fg={phClr()}>{"  "}{pad(a.phase, 13)}</text>
              <text fg={pClr()}>{"  "}{pad(`${a.pnl >= 0 ? "+" : ""}${a.pnl.toFixed(2)}`, 9)}</text>
              <text fg={TX.muted}>{"  "}{pad(fmtAgentCap(), 6)}</text>
              <text fg={TX.muted}>{"  "}{pad(`${a.trades}t`, 4)}</text>
              <text fg={TX.muted}>{"  "}{trunc(a.mission || "free-roaming", Math.max(10, props.cols - 50))}</text>
            </box>
          );
        }}</For>
      </Show>

      <box height={1} width="100%" />

      {/* ── two-column feeds ── */}
      <box flexDirection="row" flexGrow={1} width="100%">
        {/* hive decisions */}
        <box flexDirection="column" width={half()} flexShrink={0}>
          <box width="100%" height={1} flexDirection="row">
            <text fg={TX.muted}><b>hive</b></text>
          </box>
          <Show when={hiveLog().length > 0} fallback={<text fg={TX.dim}>  {I.dash}</text>}>
            <For each={hiveLog()}>{(ev) => {
              const { lbl, clr, det } = fmtEvt(ev);
              return (
                <box width="100%" height={1} flexDirection="row">
                  <text fg={TX.dim}>{ts(ev.timestamp).slice(0, 5)} </text>
                  <text fg={clr}>{pad(lbl, 7)}</text>
                  <text fg={TX.muted}> {det.slice(0, 22)}</text>
                </box>
              );
            }}</For>
          </Show>
        </box>

        {/* activity stream */}
        <box flexDirection="column" flexGrow={1}>
          <box width="100%" height={1} flexDirection="row">
            <text fg={TX.muted}><b>activity</b></text>
          </box>
          <Show when={events().length > 0} fallback={<text fg={TX.dim}>  {I.dash}</text>}>
            <For each={events()}>{(ev) => {
              const { lbl, clr, det } = fmtEvt(ev);
              return (
                <box width="100%" height={1} flexDirection="row">
                  <text fg={TX.dim}>{ts(ev.timestamp).slice(0, 5)} </text>
                  <text fg={clr}>{pad(lbl, 7)}</text>
                  <text fg={TX.muted}> {det.slice(0, 22)}</text>
                </box>
              );
            }}</For>
          </Show>
        </box>
      </box>
    </box>
  );
}
