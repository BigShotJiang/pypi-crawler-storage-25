import { createSignal, For } from "solid-js";
import { useKeyboard } from "@opentui/solid";
import { TX, C, I } from "../theme.js";

const PAGES = [
  { title: "Overview", lines: [
    "Autonomous quant trading swarm.",
    "Hive (LLM) orchestrates agents through:",
    "research > analyze > backtest > robustness > propose > execute > monitor",
    "",
    "Paper exchange by default. No real money.",
  ]},
  { title: "Commands", lines: [
    "/start              Launch backend",
    "/stop               Stop backend",
    "/settings           Open settings overlay",
    "spawn [mission]     Create agent",
    "kill <id>           Terminate agent",
    "pause / resume      Control agents",
    "1-3                 Switch tabs",
    "tab                 Switch panels (detail)",
  ]},
  { title: "Risk", lines: [
    "Layer 1  Agent caps         Per-agent limits",
    "Layer 2  Rust engine        8-point pipeline",
    "Layer 3  Circuit breaker    Non-LLM watchdog",
    "Layer 4  Hive oversight     Strategic review",
    "",
    "Defaults: 10% drawdown, $500 daily, $10k cap",
  ]},
];

export function Tutorial(props: { cols: number }) {
  const [pg, setPg] = createSignal(0);
  useKeyboard((k) => {
    if (k.name === "down" || k.name === "right") setPg((p) => Math.min(p + 1, PAGES.length - 1));
    if (k.name === "up" || k.name === "left") setPg((p) => Math.max(p - 1, 0));
  });
  const p = () => PAGES[pg()]!;
  return (
    <box flexDirection="column" flexGrow={1} width="100%">
      <box width="100%" height={1} flexDirection="row" justifyContent="space-between">
        <text fg={C.primary}><b>{p().title}</b></text>
        <text fg={TX.dim}>{pg() + 1}/{PAGES.length}</text>
      </box>
      <box height={1} />
      <For each={p().lines}>{(l) => <text fg={l ? TX.muted : TX.dim}>{l || " "}</text>}</For>
      <box marginTop={1}><text fg={TX.dim}>{"\u2190\u2192"} pages</text></box>
    </box>
  );
}
