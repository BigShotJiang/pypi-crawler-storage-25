import { createSignal } from "solid-js";
import { useKeyboard } from "@opentui/solid";
import type { SwarmWSClient } from "../ws/client.js";
import type { TabId } from "../state/store.js";
import { BG, TX, C, I } from "../theme.js";

const TABS: Record<string, TabId> = { "1": "dashboard", "2": "agents", "3": "tutorial" };

interface Props {
  client: SwarmWSClient | null;
  tab: TabId;
  onTab: (tab: TabId) => void;
  onCmd: (cmd: string) => string | null;
  msg: string;
  cols: number;
}

export function CommandBar(props: Props) {
  const [input, setInput] = createSignal("");
  const [fb, setFb] = createSignal("");

  useKeyboard((k) => {
    if (input() === "" && k.name.length === 1 && k.name in TABS) { props.onTab(TABS[k.name]!); return; }
    if (k.name === "escape") { if (input()) { setInput(""); setFb(""); } else if (props.tab === "agent-detail") props.onTab("agents"); return; }
    if ((k.name === "backspace" || k.name === "delete") && input() === "" && props.tab === "agent-detail") { props.onTab("agents"); return; }
    if (k.name === "return") {
      const cmd = input().trim(); if (!cmd) return;
      const r = props.onCmd(cmd);
      if (r !== null) { setFb(r); setInput(""); return; }
      if (props.client) { props.client.sendCommand(cmd); setFb(cmd); } else setFb("not connected");
      setInput(""); return;
    }
    if (k.name === "backspace" || k.name === "delete") { setInput((p) => p.slice(0, -1)); return; }
    if (k.name.length === 1 && !k.ctrl && !k.meta) setInput((p) => p + k.name);
  });

  return (
    <box flexDirection="column" width="100%" height={3} backgroundColor={BG.darker} flexShrink={0}>
      {/* input line */}
      <box width="100%" height={1} flexDirection="row" paddingLeft={2} paddingRight={2}>
        <text fg={TX.muted}>{"> "}</text>
        <text fg={TX.primary}>{input() || ""}</text>
        <text fg={TX.dim}>{"_"}</text>
      </box>
      {/* placeholder / feedback */}
      <box width="100%" height={1} flexDirection="row" paddingLeft={4} paddingRight={2}>
        <text fg={TX.dim}>{fb() || (input() === "" ? "type a command... (/ for help)" : "")}</text>
      </box>
      {/* spacer line */}
      <box width="100%" height={1} />
    </box>
  );
}
