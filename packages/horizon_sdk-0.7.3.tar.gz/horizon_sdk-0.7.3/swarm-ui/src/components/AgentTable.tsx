import { createSignal, For, Show } from "solid-js";
import { useKeyboard } from "@opentui/solid";
import type { SwarmState } from "../state/store.js";
import { BG, TX, C, PHASE_CLR, I } from "../theme.js";
import { useSpinner, pad, spark, trunc } from "./hooks.js";

interface Props { state: SwarmState; onSelect: (id: string) => void; cols: number; }

export function AgentTable(props: Props) {
  const spinner = useSpinner();
  const agents = () => Array.from(props.state.agents.values());
  const [cur, setCur] = createSignal(0);

  useKeyboard((k) => {
    if (k.name === "down") setCur((c) => Math.min(c + 1, agents().length - 1));
    if (k.name === "up") setCur((c) => Math.max(c - 1, 0));
    if (k.name === "return") { const a = agents()[cur()]; if (a) props.onSelect(a.id); }
  });

  return (
    <box flexDirection="column" flexGrow={1} width="100%">
      {/* column headers */}
      <box width="100%" height={1} flexDirection="row">
        <text fg={TX.dim}>
          {"  "}{pad("id", 14)}{pad("phase", 13)}{pad("pnl", 10)}{pad("chart", 12)}{pad("trd", 5)}{pad("cap", 7)}mission
        </text>
      </box>

      <Show when={agents().length > 0} fallback={
        <box width="100%" height={1}><text fg={TX.dim}>{spinner()} waiting{I.ellip}</text></box>
      }>
        <For each={agents()}>{(a, i) => {
          const sel = () => i() === cur();
          const alive = () => a.status === "running";
          const pClr = () => a.pnl >= 0 ? C.success : C.error;
          const phClr = () => PHASE_CLR[a.phase] ?? TX.dim;
          const icon = () => alive() ? spinner() : a.status === "error" ? I.cross : I.stopped;
          const pnl = () => `${a.pnl >= 0 ? "+" : ""}${a.pnl.toFixed(2)}`;
          const fmtCap = () => {
            const c = a.capital;
            return c >= 1000 ? `$${(c / 1000).toFixed(1)}k` : `$${c.toFixed(0)}`;
          };
          return (
            <box width="100%" height={1} flexDirection="row" backgroundColor={sel() ? BG.selection : undefined}>
              <text fg={sel() ? C.primary : TX.dim}>{sel() ? I.ptr : " "} </text>
              <text fg={alive() ? TX.primary : TX.dim}>{icon()} {pad(a.id, 12)}</text>
              <text fg={phClr()}>{pad(a.phase, 13)}</text>
              <text fg={pClr()}>{pad(pnl(), 10)}</text>
              <text fg={pClr()}>{pad(spark(a.pnlHistory, 10), 12)}</text>
              <text fg={TX.muted}>{pad(`${a.trades}`, 5)}</text>
              <text fg={TX.muted}>{pad(fmtCap(), 7)}</text>
              <text fg={TX.muted}>{trunc(a.mission || "free", Math.max(10, props.cols - 70))}</text>
            </box>
          );
        }}</For>
      </Show>

      <box width="100%" height={1} marginTop={1}>
        <text fg={TX.dim}>enter inspect {I.dot} {"\u2191\u2193"} navigate</text>
      </box>
    </box>
  );
}
