import { createSignal, Show, onMount, onCleanup } from "solid-js";
import { useTerminalDimensions } from "@opentui/solid";
import { SwarmWSClient } from "./ws/client.js";
import { initial, reduce, type SwarmState, type TabId } from "./state/store.js";
import { Dashboard } from "./components/Dashboard.js";
import { AgentTable } from "./components/AgentTable.js";
import { AgentDetail } from "./components/AgentDetail.js";
import { Settings } from "./components/Settings.js";
import { Tutorial } from "./components/Tutorial.js";
import { CommandBar } from "./components/CommandBar.js";
import { useClock } from "./components/hooks.js";
import { BackendManager, type BackendStatus } from "./backend.js";
import { FileLogger } from "./logger.js";
import { BG, TX, C, I } from "./theme.js";
import { useSpinner, spark } from "./components/hooks.js";

export function App(props: { wsUrl: string }) {
  const [state, setState] = createSignal<SwarmState>(initial());
  const [bkStatus, setBkStatus] = createSignal<BackendStatus>("stopped");
  const [bkMsg, setBkMsg] = createSignal("");
  const [showSettings, setShowSettings] = createSignal(false);

  let client: SwarmWSClient | null = null;
  const backend = new BackendManager();
  const logger = new FileLogger();

  const dims = useTerminalDimensions();
  const w = () => dims().width ?? 80;
  const h = () => dims().height ?? 24;
  const clock = useClock();
  const spinner = useSpinner();

  onMount(() => {
    const onSt = (s: BackendStatus) => { setBkStatus(s); logger.logStatus(`backend ${s}`); };
    const onLog = (l: string) => logger.logBackend(l);
    backend.on("status", onSt); backend.on("log", onLog);
    onCleanup(() => { backend.off("status", onSt); backend.off("log", onLog); });
  });

  onMount(() => {
    client = new SwarmWSClient(
      props.wsUrl,
      (ch, ev) => { logger.logEvent(ch, ev); setState((p) => reduce(p, ch, ev)); },
      (c) => { logger.logStatus(`ws ${c ? "up" : "down"}`); setState((p) => ({ ...p, connected: c })); },
    );
    client.connect();
    onCleanup(() => client?.disconnect());
  });

  const setTab = (tab: TabId) => setState((p) => ({
    ...p, tab, selectedAgent: tab !== "agent-detail" ? null : p.selectedAgent,
  }));
  const selectAgent = (id: string) => setState((p) => ({ ...p, tab: "agent-detail" as TabId, selectedAgent: id }));

  const runCmd = (cmd: string): string | null => {
    logger.logCommand(cmd);
    if (cmd === "/start") { logger.startRun(); const m = backend.start(); setBkMsg(m); return m; }
    if (cmd === "/stop") { logger.endRun(); const m = backend.stop(); setBkMsg(m); return m; }
    if (cmd === "/settings" || cmd === "settings") { setShowSettings((v) => !v); return "settings"; }
    if (cmd === "tutorial") { setTab("tutorial"); return "tutorial"; }
    return null;
  };

  const s = () => state();
  const pnlClr = () => s().totalPnl >= 0 ? C.success : C.error;
  const bkClr = () => bkStatus() === "running" ? C.success : bkStatus() === "starting" ? C.warning : bkStatus() === "error" ? C.error : TX.dim;
  const wsClr = () => s().connected ? C.success : TX.dim;
  const chart = () => spark(s().pnlHistory, Math.min(8, Math.floor(w() * 0.08)));
  const fmtCap = () => {
    const c = s().totalCapital;
    return c >= 1000 ? `$${(c / 1000).toFixed(1)}k` : `$${c.toFixed(0)}`;
  };

  return (
    <box flexDirection="column" width="100%" height="100%" backgroundColor={BG.base}>
      {/* ── tab bar · 1 line · top ── */}
      <box width="100%" height={1} backgroundColor={BG.darker} paddingLeft={1} paddingRight={2} flexDirection="row" flexShrink={0}>
        <box flexDirection="row" flexGrow={1}>
          <text fg={s().tab === "dashboard" ? C.primary : TX.muted}>
            {s().tab === "dashboard" ? <b>{spinner()} 1 swarm</b> : "  1 swarm"}
          </text>
          <text>{"    "}</text>
          <text fg={s().tab === "agents" || s().tab === "agent-detail" ? C.primary : TX.muted}>
            {s().tab === "agents" || s().tab === "agent-detail" ? <b>2 agents</b> : "2 agents"}
          </text>
          <text>{"    "}</text>
          <text fg={s().tab === "tutorial" ? C.primary : TX.muted}>
            {s().tab === "tutorial" ? <b>3 help</b> : "3 help"}
          </text>
        </box>
        <text fg={TX.muted}>/settings</text>
      </box>

      {/* ── main content · flex grow · padded ── */}
      <box flexDirection="column" flexGrow={1} width="100%" paddingLeft={3} paddingRight={3} paddingTop={1}>
        <Show when={s().tab === "dashboard"}><Dashboard state={s()} cols={w() - 6} /></Show>
        <Show when={s().tab === "agents"}><AgentTable state={s()} onSelect={selectAgent} cols={w() - 6} /></Show>
        <Show when={s().tab === "agent-detail" && s().selectedAgent}>
          <AgentDetail state={s()} agentId={s().selectedAgent!} onBack={() => setTab("agents")} cols={w() - 6} />
        </Show>
        <Show when={s().tab === "tutorial"}><Tutorial cols={w() - 6} /></Show>
      </box>

      {/* ── settings floating overlay ── */}
      <Show when={showSettings()}>
        <box
          position="absolute"
          left={Math.max(0, Math.floor(w() / 2) - 20)}
          top={Math.max(0, Math.floor(h() / 4))}
          width={Math.min(40, w() - 4)}
          height={Math.min(14, h() - 4)}
          backgroundColor={BG.secondary}
          borderStyle="rounded"
          border={true}
          borderColor={C.primary}
          flexDirection="column"
          paddingLeft={2}
          paddingRight={2}
          paddingTop={1}
        >
          <Settings cols={Math.min(34, w() - 10)} onClose={() => setShowSettings(false)} />
        </box>
      </Show>

      {/* ── input bar · 3 lines · bottom ── */}
      <CommandBar client={client} tab={s().tab} onTab={setTab} onCmd={runCmd} msg={bkMsg()} cols={w()} />

      {/* ── status bar · 1 line · very bottom ── */}
      <box width="100%" height={1} backgroundColor={BG.darker} paddingLeft={2} paddingRight={2} flexDirection="row" justifyContent="space-between" flexShrink={0}>
        <box flexDirection="row">
          <text fg={C.primary}><b>hive</b></text>
          <text fg={TX.muted}> {spinner()} {s().agents.size > 0 ? `${Array.from(s().agents.values()).filter(a => a.status === "running").length}/${s().agents.size}` : "0/0"}</text>
          <text fg={TX.muted}>{"    "}{fmtCap()}</text>
          <text fg={pnlClr()}>{"    "}{s().totalPnl >= 0 ? "+" : ""}{s().totalPnl.toFixed(2)} {chart()}</text>
          <Show when={s().cbActive}><text fg={C.error}>{"    "}<b>CB</b></text></Show>
        </box>
        <box flexDirection="row">
          <text fg={bkClr()}>{bkStatus() === "running" ? I.alive : I.idle} {bkStatus()}</text>
          <text fg={wsClr()}>{"    "}{s().connected ? I.alive : I.idle} ws</text>
          <text fg={TX.muted}>{"    "}{clock()}</text>
        </box>
      </box>
    </box>
  );
}
