/**
 * Backend process manager — spawns/kills `python -m horizon.swarm` as a child process.
 */

import { spawn, type ChildProcess } from "child_process";
import { EventEmitter } from "events";

export type BackendStatus = "stopped" | "starting" | "running" | "error";

export class BackendManager extends EventEmitter {
  private proc: ChildProcess | null = null;
  private _status: BackendStatus = "stopped";
  private _lastLog: string[] = [];
  private readonly maxLog = 50;

  get status(): BackendStatus {
    return this._status;
  }

  get logs(): readonly string[] {
    return this._lastLog;
  }

  start(): string {
    if (this.proc) return "already running";

    if (!process.env.OPENROUTER_API_KEY) {
      return "OPENROUTER_API_KEY not set";
    }

    this._setStatus("starting");
    this._lastLog = [];

    this.proc = spawn("python", ["-m", "horizon.swarm"], {
      stdio: ["ignore", "pipe", "pipe"],
      env: { ...process.env },
      cwd: process.env.HORIZON_ROOT || undefined,
    });

    this.proc.stdout?.on("data", (chunk: Buffer) => {
      const line = chunk.toString().trim();
      if (line) {
        this._pushLog(line);
        // Detect when the event bus is up
        if (line.includes("event bus") || line.includes("listening") || line.includes("started")) {
          this._setStatus("running");
        }
      }
    });

    this.proc.stderr?.on("data", (chunk: Buffer) => {
      const line = chunk.toString().trim();
      if (line) this._pushLog(`[err] ${line}`);
    });

    this.proc.on("error", (err) => {
      this._pushLog(`[fatal] ${err.message}`);
      this._setStatus("error");
      this.proc = null;
    });

    this.proc.on("exit", (code) => {
      this._pushLog(`[exit] code=${code}`);
      this._setStatus("stopped");
      this.proc = null;
    });

    // If still "starting" after 3s, assume running (some backends don't print a banner)
    setTimeout(() => {
      if (this._status === "starting") this._setStatus("running");
    }, 3000);

    return "starting backend...";
  }

  stop(): string {
    if (!this.proc) return "not running";

    this.proc.kill("SIGTERM");
    // Force kill after 5s if still alive
    const p = this.proc;
    setTimeout(() => {
      try { p.kill("SIGKILL"); } catch { /* already dead */ }
    }, 5000);

    return "stopping backend...";
  }

  private _setStatus(s: BackendStatus): void {
    this._status = s;
    this.emit("status", s);
  }

  private _pushLog(line: string): void {
    this._lastLog.push(line);
    if (this._lastLog.length > this.maxLog) this._lastLog.shift();
    this.emit("log", line);
  }
}
