/**
 * Minimal dark theme — blue accent, depth via background stepping only.
 * No borders, no boxes. Steve Jobs approved.
 */

// ── Backgrounds ──
export const BG = {
  base:      "#212121",   // Main content area
  darker:    "#1a1a1a",   // Bars (tab, input, status)
  secondary: "#252525",   // Panels, overlays
  selection: "#303030",   // Selected/hover states
};

// ── Text ──
export const TX = {
  primary: "#e0e0e0",
  muted:   "#6a6a6a",
  dim:     "#333333",
};

// ── Colors ──
export const C = {
  primary:   "#5c9cf5",  // blue — accent, active tabs, links
  accent:    "#9d7cd8",  // purple — proposals, strategy
  success:   "#7fd88f",  // green — positive PnL, fills
  error:     "#e06c75",  // red — negative PnL, errors
  warning:   "#f5a742",  // orange — warnings, directives
  info:      "#56b6c2",  // teal — phase transitions, LLM
};

// ── Phase colors ──
export const PHASE_CLR: Record<string, string> = {
  idle:        TX.dim,
  researching: C.info,
  analyzing:   C.primary,
  backtesting: C.accent,
  robustness:  C.warning,
  proposing:   C.warning,
  executing:   C.success,
  monitoring:  "#4fd6be",
  evolving:    C.warning,
  retiring:    C.error,
};

// ── Icons ──
export const I = {
  alive:   "\u25CF",
  idle:    "\u25CB",
  stopped: "\u25A0",
  check:   "\u2713",
  cross:   "\u2717",
  ptr:     "\u25B8",
  dot:     "\u00B7",
  pipe:    "\u2502",
  heavy:   "\u2503",
  dash:    "\u2500",
  ellip:   "\u2026",
};

export const BLOCKS = ["\u2581", "\u2582", "\u2583", "\u2584", "\u2585", "\u2586", "\u2587", "\u2588"];
export const BAR_FULL = "\u2588";
export const BAR_EMPTY = "\u2591";
