/**
 * WebSocket client — connects to the Horizon Swarm event bus.
 * Auto-reconnects with exponential backoff.
 */

import WebSocket from "ws";

export interface SwarmEvent {
  type: string;
  source: string;
  data: Record<string, unknown>;
  timestamp: number;
}

type MessageHandler = (channel: string, event: SwarmEvent) => void;
type StatusHandler = (connected: boolean) => void;

export class SwarmWSClient {
  private url: string;
  private ws: WebSocket | null = null;
  private onMessage: MessageHandler;
  private onStatus: StatusHandler;
  private baseReconnectMs: number;
  private attempt = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private shouldConnect = false;

  constructor(
    url: string,
    onMessage: MessageHandler,
    onStatus: StatusHandler,
    reconnectMs = 1500,
  ) {
    this.url = url;
    this.onMessage = onMessage;
    this.onStatus = onStatus;
    this.baseReconnectMs = reconnectMs;
  }

  connect(): void {
    this.shouldConnect = true;
    this.attempt = 0;
    this._connect();
  }

  disconnect(): void {
    this.shouldConnect = false;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  send(data: Record<string, unknown>): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  sendCommand(command: string, args = ""): void {
    this.send({ command, args });
  }

  private _connect(): void {
    try {
      this.ws = new WebSocket(this.url);

      this.ws.on("open", () => {
        this.attempt = 0;
        this.onStatus(true);
        // Request recent history
        for (const ch of ["agents", "hive", "risk", "system"]) {
          this.send({ get_history: ch, limit: 50 });
        }
      });

      this.ws.on("message", (raw: WebSocket.Data) => {
        try {
          const msg = JSON.parse(raw.toString());
          if ("channel" in msg && "event" in msg) {
            this.onMessage(msg.channel, msg.event);
          } else if ("history" in msg && "events" in msg) {
            for (const ev of msg.events) {
              this.onMessage(msg.history, ev);
            }
          }
        } catch {
          /* ignore */
        }
      });

      this.ws.on("close", () => {
        this.onStatus(false);
        this._scheduleReconnect();
      });

      this.ws.on("error", () => {
        this.onStatus(false);
        this.ws?.close();
      });
    } catch {
      this._scheduleReconnect();
    }
  }

  private _scheduleReconnect(): void {
    if (!this.shouldConnect || this.reconnectTimer) return;
    const delay = Math.min(this.baseReconnectMs * 2 ** this.attempt, 15_000);
    this.attempt++;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (this.shouldConnect) this._connect();
    }, delay);
  }
}
