/**
 * File logger — writes swarm data to swarm-ui/data/runs/<run-id>/
 *
 * Structure:
 *   data/
 *     runs/
 *       run-2026-03-18-14-30-00/
 *         events.jsonl      — all WS events, one JSON per line
 *         backend.log       — Python backend stdout/stderr
 *         commands.log      — user commands
 *         status.log        — connection/backend status changes
 *         summary.json      — run metadata (start time, end time, config)
 *
 * A new run folder is created each time /start is called.
 * Pre-start events (WS connection, etc.) go to a "pre" buffer
 * and get flushed into the run folder when it's created.
 */

import { mkdirSync, appendFileSync, writeFileSync } from "fs";
import { resolve } from "path";
import type { SwarmEvent } from "./ws/client.js";

const DATA_DIR = resolve(import.meta.dir, "../data/runs");

function stamp(): string {
  return new Date().toISOString();
}

function runTag(): string {
  return new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-");
}

export class FileLogger {
  private runDir: string | null = null;
  private preBuffer: string[] = [];
  private startTime: string | null = null;

  /** Call this when /start is issued to create a new run folder */
  startRun(): string {
    try {
      mkdirSync(DATA_DIR, { recursive: true });
    } catch { /* exists */ }

    const tag = runTag();
    this.runDir = resolve(DATA_DIR, `run-${tag}`);
    mkdirSync(this.runDir, { recursive: true });
    this.startTime = stamp();

    // Write summary header
    writeFileSync(resolve(this.runDir, "summary.json"), JSON.stringify({
      started: this.startTime,
      ended: null,
      tag,
    }, null, 2));

    // Flush pre-buffer into status.log
    if (this.preBuffer.length > 0) {
      const statusPath = resolve(this.runDir, "status.log");
      for (const line of this.preBuffer) {
        appendFileSync(statusPath, line);
      }
      this.preBuffer = [];
    }

    return this.runDir;
  }

  /** Call this when /stop is issued */
  endRun(): void {
    if (!this.runDir) return;
    try {
      const summaryPath = resolve(this.runDir, "summary.json");
      writeFileSync(summaryPath, JSON.stringify({
        started: this.startTime,
        ended: stamp(),
      }, null, 2));
    } catch { /* best effort */ }
  }

  logEvent(channel: string, ev: SwarmEvent): void {
    if (!this.runDir) return;
    const line = JSON.stringify({ ts: stamp(), channel, ...ev }) + "\n";
    this._append("events.jsonl", line);
  }

  logBackend(line: string): void {
    if (!this.runDir) return;
    this._append("backend.log", `[${stamp()}] ${line}\n`);
  }

  logCommand(cmd: string): void {
    if (!this.runDir) return;
    this._append("commands.log", `[${stamp()}] ${cmd}\n`);
  }

  logStatus(msg: string): void {
    const line = `[${stamp()}] ${msg}\n`;
    if (!this.runDir) {
      this.preBuffer.push(line);
      return;
    }
    this._append("status.log", line);
  }

  get currentRunDir(): string | null {
    return this.runDir;
  }

  private _append(file: string, text: string): void {
    if (!this.runDir) return;
    try {
      appendFileSync(resolve(this.runDir, file), text);
    } catch { /* best effort */ }
  }
}
