/**
 * Central reactive store. Pure functions, no side effects.
 */

import type { SwarmEvent } from "../ws/client.js";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export interface LLMTurn {
  turn: number;
  content: string;
  toolCalls: string[];
  /** Tool calls with abbreviated arguments, e.g. "discover({event_type: 'politics'})" */
  toolArgs: string[];
  phase: string;
  ts: number;
  /** True if this was an LLM error, not a real turn */
  error?: boolean;
}

export interface AgentInfo {
  id: string;
  phase: string;
  status: string;
  mission: string | null;
  pnl: number;
  trades: number;
  capital: number;
  cost: number;
  lastAction: string;
  turns: number;
  updatedAt: number;
  /** Per-agent event log for detail view */
  log: SwarmEvent[];
  /** PnL sample history for sparkline */
  pnlHistory: number[];
  /** Hive's last verdict for this agent */
  hiveVerdict: string | null;
  /** LLM reasoning turns */
  reasoning: LLMTurn[];
  /** Streaming text buffer (current turn) */
  streamBuf: string;
}

export interface ProposalInfo {
  id: string;
  agentId: string;
  market: string;
  side: string;
  edge: number;
  capital: number;
  verdict: string | null;
  ts: number;
}

export type TabId = "dashboard" | "agents" | "agent-detail" | "settings" | "tutorial";

export interface SwarmState {
  connected: boolean;
  agents: Map<string, AgentInfo>;
  totalPnl: number;
  totalCapital: number;
  totalCost: number;
  cbActive: boolean;
  cbReason: string | null;
  drawdown: number;
  positions: number;
  events: SwarmEvent[];
  hiveLog: SwarmEvent[];
  proposals: ProposalInfo[];
  tab: TabId;
  selectedAgent: string | null;
  /** Global PnL history for dashboard sparkline */
  pnlHistory: number[];
}

export function initial(): SwarmState {
  return {
    connected: false,
    agents: new Map(),
    totalPnl: 0,
    totalCapital: 0,
    totalCost: 0,
    cbActive: false,
    cbReason: null,
    drawdown: 0,
    positions: 0,
    events: [],
    hiveLog: [],
    proposals: [],
    tab: "dashboard",
    selectedAgent: null,
    pnlHistory: [],
  };
}

/* ------------------------------------------------------------------ */
/* Reducer                                                             */
/* ------------------------------------------------------------------ */

const MAX_EVENTS = 300;
const MAX_HIVE = 80;
const MAX_AGENT_LOG = 100;
const MAX_PNL_HISTORY = 60;
const MAX_REASONING = 200;

function pushAgentLog(agent: AgentInfo, ev: SwarmEvent): SwarmEvent[] {
  const log = [...agent.log.slice(-(MAX_AGENT_LOG - 1)), ev];
  return log;
}

export function reduce(
  s: SwarmState,
  ch: string,
  ev: SwarmEvent,
): SwarmState {
  const events = [...s.events.slice(-(MAX_EVENTS - 1)), ev];
  const d = ev.data as Record<string, any>;

  const next: SwarmState = { ...s, events };

  switch (ev.type) {
    /* ---- agent lifecycle ---- */
    case "agent_spawned": {
      const a: AgentInfo = {
        id: ev.source,
        phase: "idle",
        status: "running",
        mission: (d.mission as string) || null,
        pnl: 0,
        trades: 0,
        capital: 0,
        cost: 0,
        lastAction: "spawned",
        turns: 0,
        updatedAt: ev.timestamp,
        log: [ev],
        pnlHistory: [0],
        hiveVerdict: null,
        reasoning: [],
        streamBuf: "",
      };
      next.agents = new Map(s.agents);
      next.agents.set(ev.source, a);
      break;
    }
    case "agent_phase_changed": {
      const ag = s.agents.get(ev.source);
      if (ag) {
        next.agents = new Map(s.agents);
        next.agents.set(ev.source, {
          ...ag,
          phase: (d.new_phase as string) ?? ag.phase,
          updatedAt: ev.timestamp,
          log: pushAgentLog(ag, ev),
        });
      }
      break;
    }
    case "agent_stopped": {
      const ag = s.agents.get(ev.source);
      if (ag) {
        next.agents = new Map(s.agents);
        next.agents.set(ev.source, {
          ...ag,
          status: "stopped",
          updatedAt: ev.timestamp,
          log: pushAgentLog(ag, ev),
        });
      }
      break;
    }
    case "agent_error": {
      const ag = s.agents.get(ev.source);
      if (ag) {
        next.agents = new Map(s.agents);
        next.agents.set(ev.source, {
          ...ag,
          status: "error",
          updatedAt: ev.timestamp,
          log: pushAgentLog(ag, ev),
        });
      }
      break;
    }
    case "heartbeat": {
      const ag = s.agents.get(ev.source);
      if (ag) {
        next.agents = new Map(s.agents);
        const pnl = (d.pnl as number) ?? ag.pnl;
        const pnlHistory = [...ag.pnlHistory.slice(-(MAX_PNL_HISTORY - 1)), pnl];
        next.agents.set(ev.source, {
          ...ag,
          phase: (d.phase as string) ?? ag.phase,
          pnl,
          trades: (d.trades as number) ?? ag.trades,
          cost: (d.llm_cost_usd as number) ?? ag.cost,
          turns: (d.turns as number) ?? ag.turns,
          lastAction: (d.last_action as string) ?? ag.lastAction,
          capital: (d.capital as number) ?? ag.capital,
          updatedAt: ev.timestamp,
          pnlHistory,
        });
      }
      break;
    }

    /* ---- LLM reasoning ---- */
    case "llm_turn": {
      const ag = s.agents.get(ev.source);
      if (ag) {
        next.agents = new Map(s.agents);
        const turn: LLMTurn = {
          turn: (d.turn as number) ?? 0,
          content: (d.content as string) ?? "",
          toolCalls: (d.tool_calls as string[]) ?? [],
          toolArgs: (d.tool_args as string[]) ?? [],
          phase: (d.phase as string) ?? ag.phase,
          ts: ev.timestamp,
          error: (d.error as boolean) ?? false,
        };
        next.agents.set(ev.source, {
          ...ag,
          reasoning: [...ag.reasoning.slice(-(MAX_REASONING - 1)), turn],
          streamBuf: "",
          log: pushAgentLog(ag, ev),
          updatedAt: ev.timestamp,
        });
      }
      break;
    }
    case "llm_delta": {
      const ag = s.agents.get(ev.source);
      if (ag) {
        next.agents = new Map(s.agents);
        next.agents.set(ev.source, {
          ...ag,
          streamBuf: ag.streamBuf + ((d.delta as string) ?? ""),
          updatedAt: ev.timestamp,
        });
      }
      break;
    }

    /* ---- trading events — route to agent log ---- */
    case "order_submitted":
    case "fill_received":
    case "position_opened":
    case "position_closed":
    case "knowledge_shared":
    case "insight_discovered": {
      const ag = s.agents.get(ev.source);
      if (ag) {
        next.agents = new Map(s.agents);
        next.agents.set(ev.source, {
          ...ag,
          log: pushAgentLog(ag, ev),
          updatedAt: ev.timestamp,
        });
      }
      break;
    }

    /* ---- hive ---- */
    case "hive_directive":
    case "hive_agent_spawned":
    case "hive_capital_allocated":
    case "proposal_verdict":
    case "proposal_submitted":
      next.hiveLog = [...s.hiveLog.slice(-(MAX_HIVE - 1)), ev];
      if (ev.type === "hive_capital_allocated") {
        const ag = s.agents.get(d.agent_id as string);
        if (ag) {
          next.agents = new Map(s.agents);
          next.agents.set(d.agent_id as string, {
            ...ag,
            capital: (d.amount as number) ?? ag.capital,
            log: pushAgentLog(ag, ev),
          });
        }
      }
      if (ev.type === "proposal_submitted") {
        next.proposals = [
          ...s.proposals,
          {
            id: d.proposal_id as string,
            agentId: ev.source,
            market: d.market_id as string,
            side: d.side as string,
            edge: (d.edge_estimate as number) ?? 0,
            capital: (d.requested_capital as number) ?? 0,
            verdict: null,
            ts: ev.timestamp,
          },
        ];
        const ag = s.agents.get(ev.source);
        if (ag) {
          next.agents = new Map(s.agents);
          next.agents.set(ev.source, {
            ...ag,
            log: pushAgentLog(ag, ev),
          });
        }
      }
      if (ev.type === "proposal_verdict") {
        next.proposals = s.proposals.map((p) =>
          p.id === d.proposal_id ? { ...p, verdict: d.verdict as string } : p,
        );
        // Update agent's hive verdict
        const agentId = d.agent_id as string;
        const ag = s.agents.get(agentId);
        if (ag) {
          next.agents = new Map(s.agents);
          next.agents.set(agentId, {
            ...ag,
            hiveVerdict: (d.verdict as string) ?? null,
            log: pushAgentLog(ag, ev),
          });
        }
      }
      break;

    /* ---- risk ---- */
    case "circuit_breaker_triggered":
      next.cbActive = true;
      next.cbReason = (d.reason as string) ?? "unknown";
      break;
    case "risk_limit_hit":
    case "drawdown_alert":
      if (d.drawdown_pct !== undefined) next.drawdown = d.drawdown_pct as number;
      break;

    /* ---- metrics ---- */
    case "metrics_update":
      if (d.n_positions !== undefined) next.positions = d.n_positions as number;
      break;
  }

  // Recompute aggregates
  let pnl = 0,
    cap = 0,
    cost = 0;
  for (const a of next.agents.values()) {
    pnl += a.pnl;
    cap += a.capital;
    cost += a.cost;
  }
  next.totalPnl = pnl;
  next.totalCapital = cap;
  next.totalCost = cost;

  // Append to global PnL history on metrics/heartbeat
  if (ev.type === "heartbeat" || ev.type === "metrics_update") {
    next.pnlHistory = [...s.pnlHistory.slice(-(MAX_PNL_HISTORY - 1)), pnl];
  }

  return next;
}
