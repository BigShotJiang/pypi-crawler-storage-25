"""Paper market maker on REAL Polymarket markets.

Uses live orderbook data from Polymarket WebSocket. The paper exchange
matches your orders against real mid prices — so fills are realistic,
but no real money is at risk.

How paper fills work:
  Each cycle, the engine ticks with the real bid AND ask from the feed.
  - Your buy orders fill when feed_bid <= your_buy_price
  - Your sell orders fill when feed_ask >= your_sell_price
  So if you quote inside the real spread, you fill on every tick.

Requires:
    export HORIZON_API_KEY="hz_..."

Usage:
    python examples/paper_mm.py
"""

import requests
import horizon as hz
from horizon.context import FeedData


# ── Discover competitive markets with mid-range prices ──────────────

def find_tradeable_markets(n: int = 3) -> list[str]:
    """Fetch active Polymarket markets and pick ones with prices
    between 0.15 and 0.85, sorted by 24h volume."""
    resp = requests.get(
        "https://gamma-api.polymarket.com/markets",
        params={"closed": "false", "limit": 200},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()

    candidates = []
    for m in data:
        if not m.get("active") or m.get("closed"):
            continue
        if not m.get("acceptingOrders"):
            continue
        bid = float(m.get("bestBid", 0) or 0)
        ask = float(m.get("bestAsk", 0) or 0)
        if bid <= 0 or ask <= 0:
            continue
        mid = (bid + ask) / 2
        if not (0.15 <= mid <= 0.85):
            continue
        liq = float(m.get("liquidityNum", 0) or 0)
        if liq < 500:
            continue
        vol24 = float(m.get("volume24hr", 0) or 0)
        candidates.append((m["slug"], mid, vol24, liq))

    candidates.sort(key=lambda x: x[2], reverse=True)

    for slug, mid, vol, liq in candidates[:n]:
        print(f"  {slug[:55]:55s}  mid={mid:.2f}  vol24h={vol:,.0f}  liq={liq:,.0f}")

    return [c[0] for c in candidates[:n]]


print("Discovering tradeable Polymarket markets...")
slugs = find_tradeable_markets(3)

if not slugs:
    raise SystemExit("No suitable markets found.")

print()


# ── Fair value: read real orderbook mid ─────────────────────────────

def fair_value(ctx: hz.Context) -> float:
    """Use the live Polymarket orderbook mid as fair value."""
    book = ctx.feeds.get(ctx.market_id, FeedData())

    if book.bid > 0 and book.ask > 0:
        return (book.bid + book.ask) / 2.0

    if book.price > 0:
        return book.price

    return 0.0


# ── Quoter: crosses the real spread to fill on every tick ───────────

def quoter(ctx: hz.Context, fair: float) -> list[hz.Quote]:
    """Quote inside the real spread so the paper exchange fills us.

    The paper engine ticks with both the real bid and real ask:
      - buy fills when real_bid <= our_buy_price
      - sell fills when real_ask >= our_sell_price

    By quoting a 1-mill spread around fair, both sides cross on
    every tick where the real spread is > 1 mill.
    """
    if fair <= 0.02 or fair >= 0.98:
        return []

    # Lean away from inventory to manage risk
    inv = ctx.inventory.net_for_market(ctx.market_id)
    skew = inv * 0.003

    # Tight 1-mill spread: crosses the real spread → fills every tick
    # Widen with inventory to slow down accumulation
    spread = 0.001 + abs(inv) * 0.0005
    spread = min(spread, 0.02)

    return hz.quotes(fair - skew, spread=spread, size=5)


# ── Wire feeds: one PolymarketBook per market ───────────────────────

feeds = {slug: hz.PolymarketBook(slug) for slug in slugs}


# ── Run ─────────────────────────────────────────────────────────────

hz.run(
    name="paper_mm_real",
    markets=slugs,
    feeds=feeds,
    pipeline=[fair_value, quoter],
    risk=hz.Risk(
        max_position=200,
        max_notional=5000,
        max_drawdown_pct=20,
        max_order_size=50,
        rate_limit=100,
        rate_burst=500,
    ),
    interval=0.5,
    mode="paper",
    dashboard=True,
)
