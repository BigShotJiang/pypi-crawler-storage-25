"""Core unit tests for Kontrol Freek."""
import json, os, tempfile
import pytest
from kontrol_freek_mcp.db import DecisionDB
from kontrol_freek_mcp.policy import PolicyEngine, RiskLevel
from kontrol_freek_mcp.audit import AuditTrail
from kontrol_freek_mcp.similarity import SemanticMatcher

@pytest.fixture
def tmp_db():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db = DecisionDB(f.name)
        yield db
        db.close(); os.unlink(f.name)

class TestDecisionDB:
    def test_log_and_search(self, tmp_db):
        did = tmp_db.log_decision(text="Use PostgreSQL", category="architecture", risk_level="medium", status="confirmed", rationale="Better JSON support")
        assert did > 0
        r = tmp_db.search_decisions(keyword="PostgreSQL")
        assert len(r) == 1 and r[0]["text"] == "Use PostgreSQL"

    def test_stats(self, tmp_db):
        tmp_db.log_decision(text="A", status="confirmed")
        tmp_db.log_decision(text="B", status="human_approved")
        s = tmp_db.get_stats()
        assert s["total_decisions"] == 2 and s["by_status"]["confirmed"] == 1

    def test_update_status(self, tmp_db):
        did = tmp_db.log_decision(text="Test", status="pending")
        tmp_db.update_status(did, "confirmed", "OK")
        assert tmp_db.search_decisions(keyword="Test")[0]["status"] == "confirmed"

class TestPolicyEngine:
    def test_critical_blocks(self, tmp_db):
        assert PolicyEngine(tmp_db).evaluate("X", RiskLevel.CRITICAL, "general", [], []).action == "block"

    def test_contradiction_blocks(self, tmp_db):
        assert PolicyEngine(tmp_db).evaluate("Y", RiskLevel.LOW, "general", [], [{"text": "X", "reason": "Conflict"}]).action == "block"

    def test_security_reviews(self, tmp_db):
        assert PolicyEngine(tmp_db).evaluate("API key", RiskLevel.LOW, "security", [], []).action == "review"

    def test_similar_auto_approves(self, tmp_db):
        similar = [{"score": 0.9, "status": "confirmed", "created_at": "2026-04-07T10:00:00+00:00", "text": "Same"}]
        assert PolicyEngine(tmp_db, similarity_threshold=0.7).evaluate("Same", RiskLevel.LOW, "general", similar, []).action == "auto_approve"

class TestAuditTrail:
    def test_append_and_verify(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False, mode="w") as f: path = f.name
        try:
            t = AuditTrail(path, "secret")
            t.append("test", "hello", "d", 1); t.append("test2", "world", "d", 2)
            valid, count = t.verify_chain()
            assert valid and count == 2
        finally: os.unlink(path)

    def test_tamper_detection(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False, mode="w") as f: path = f.name
        try:
            t = AuditTrail(path, "secret"); t.append("a", "b"); t.append("c", "d")
            lines = open(path).readlines()
            e = json.loads(lines[0]); e["text"] = "TAMPERED"; lines[0] = json.dumps(e) + "\n"
            with open(path, "w") as f: f.writelines(lines)
            assert AuditTrail(path, "secret").verify_chain()[0] is False
        finally: os.unlink(path)

class TestSemanticMatcher:
    def test_find_similar(self, tmp_db):
        tmp_db.log_decision(text="Use PostgreSQL database", status="confirmed")
        tmp_db.log_decision(text="Add Redis cache", status="confirmed")
        r = SemanticMatcher(tmp_db).find_similar("Postgres database selected")
        assert len(r) >= 1 and r[0]["text"] == "Use PostgreSQL database"

    def test_find_contradictions(self, tmp_db):
        tmp_db.log_decision(text="Use SQLite", status="human_rejected")
        m = SemanticMatcher(tmp_db)
        s = m.find_similar("Use SQLite")
        assert len(m.find_contradictions("Use SQLite", s)) >= 1
