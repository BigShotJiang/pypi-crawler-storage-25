"""
Kontrol Freek MCP Server
=========================
An MCP server that catches AI assumptions, verifies them against a project
decision log, detects contradictions, scores risk, and gates human approval.

Combines best features of: clarify-mcp, CONTINUITY, mcp-human-loop,
VantaGate/Aegis, HumanLayer, interactive-mcp — then goes further with
semantic similarity, contradiction detection, adaptive policy engine,
time-based decision decay, and cryptographic audit trails.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastmcp import FastMCP, Context

from .db import DecisionDB
from .policy import PolicyEngine, RiskLevel
from .notifier import NotificationRouter
from .similarity import SemanticMatcher
from .audit import AuditTrail

LOG = logging.getLogger("kontrol-freek")

# --- Global config from env ---
HMAC_SECRET = os.getenv("KF_HMAC_SECRET", "change-me-in-production")
if HMAC_SECRET == "change-me-in-production":
    import warnings
    warnings.warn(
        "KF_HMAC_SECRET is set to the default value. "
        "Set a strong secret via the KF_HMAC_SECRET environment variable before using in production.",
        stacklevel=1,
    )
SIMILARITY_THRESHOLD = float(os.getenv("KF_SIMILARITY_THRESHOLD", "0.78"))
if not 0.0 < SIMILARITY_THRESHOLD < 1.0:
    import warnings
    warnings.warn(f"KF_SIMILARITY_THRESHOLD={SIMILARITY_THRESHOLD} is out of range (0, 1). Resetting to 0.78.", stacklevel=1)
    SIMILARITY_THRESHOLD = 0.78
DECISION_DECAY_DAYS = int(os.getenv("KF_DECAY_DAYS", "90"))
TELEGRAM_BOT_TOKEN = os.getenv("KF_TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("KF_TELEGRAM_CHAT_ID", "")
SLACK_WEBHOOK_URL = os.getenv("KF_SLACK_WEBHOOK", "")
WEB_PORT = int(os.getenv("KF_WEB_PORT", "9111"))

# Base directory for all project data
KF_HOME = Path.home() / ".kontrol-freek"
KF_PROJECTS_DIR = KF_HOME / "projects"


def _load_project_config(project_root: str) -> dict:
    """Load .kontrol-freek.json from the project root if it exists."""
    cfg_path = Path(project_root) / ".kontrol-freek.json"
    if cfg_path.exists():
        try:
            return json.loads(cfg_path.read_text())
        except Exception as e:
            LOG.warning("Failed to load project config %s: %s", cfg_path, e)
    return {}


def _project_slug(project_root: str) -> str:
    """Return a filesystem-safe slug for a project root path."""
    resolved = str(Path(project_root).resolve())
    slug = re.sub(r"[^a-zA-Z0-9_-]", "_", resolved).strip("_")
    return slug[:80]


def _project_data_dir(project_root: str) -> Path:
    """Return the per-project data directory under ~/.kontrol-freek/projects/."""
    cfg = _load_project_config(project_root)
    if cfg.get("project_name"):
        name = re.sub(r"[^a-zA-Z0-9_-]", "_", cfg["project_name"])[:60]
    else:
        name = _project_slug(project_root)
    d = KF_PROJECTS_DIR / name
    d.mkdir(parents=True, exist_ok=True)
    return d


# --- Per-project caches ---
_db_cache: dict[str, DecisionDB] = {}
_policy_cache: dict[str, PolicyEngine] = {}
_matcher_cache: dict[str, SemanticMatcher] = {}
_audit_cache: dict[str, AuditTrail] = {}
_notifier_cache: dict[str, NotificationRouter] = {}


def _get_db(project_root: str) -> DecisionDB:
    key = str(Path(project_root).resolve())
    if key not in _db_cache:
        data_dir = _project_data_dir(project_root)
        _db_cache[key] = DecisionDB(str(data_dir / "decisions.db"))
    return _db_cache[key]


def _get_policy(project_root: str) -> PolicyEngine:
    key = str(Path(project_root).resolve())
    if key not in _policy_cache:
        _policy_cache[key] = PolicyEngine(_get_db(project_root), similarity_threshold=SIMILARITY_THRESHOLD, decay_days=DECISION_DECAY_DAYS)
    return _policy_cache[key]


def _get_matcher(project_root: str) -> SemanticMatcher:
    key = str(Path(project_root).resolve())
    if key not in _matcher_cache:
        _matcher_cache[key] = SemanticMatcher(_get_db(project_root))
    return _matcher_cache[key]


def _get_audit(project_root: str) -> AuditTrail:
    key = str(Path(project_root).resolve())
    if key not in _audit_cache:
        data_dir = _project_data_dir(project_root)
        _audit_cache[key] = AuditTrail(str(data_dir / "audit.jsonl"), HMAC_SECRET)
    return _audit_cache[key]


def _get_notifier(project_root: str) -> NotificationRouter:
    key = str(Path(project_root).resolve())
    cfg_path = Path(project_root) / ".kontrol-freek.json"
    cfg_mtime = cfg_path.stat().st_mtime if cfg_path.exists() else 0
    cached = _notifier_cache.get(key)
    if cached and getattr(cached, "_cfg_mtime", None) == cfg_mtime:
        return cached
    cfg = _load_project_config(project_root)
    token = cfg.get("telegram_token") or TELEGRAM_BOT_TOKEN
    chat_id = cfg.get("telegram_chat_id") or TELEGRAM_CHAT_ID
    slack = cfg.get("slack_webhook") or SLACK_WEBHOOK_URL
    project_name = cfg.get("project_name") or Path(project_root).resolve().name
    notifier = NotificationRouter(telegram_token=token, telegram_chat_id=chat_id, slack_webhook=slack, web_port=WEB_PORT, project_name=project_name)
    notifier._cfg_mtime = cfg_mtime
    _notifier_cache[key] = notifier
    return notifier


def _invalidate_notifier(project_root: str):
    key = str(Path(project_root).resolve())
    _notifier_cache.pop(key, None)


def _sign(data: str) -> str:
    return hmac.new(HMAC_SECRET.encode(), data.encode(), hashlib.sha256).hexdigest()


mcp = FastMCP(
    "kontrol-freek",
    instructions=(
        "AI assumption firewall — pause at decision points, compare with "
        "past decisions, detect contradictions, gate human approval. "
        "Always pass project_root=<current working directory> to every tool call."
    ),
)


# =========================================================================
# TOOLS
# =========================================================================

@mcp.tool()
async def check_assumption(
    assumption: str,
    project_root: str = ".",
    context: str = "",
    risk_level: str = "medium",
    category: str = "general",
    alternatives: list[str] | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """
    Verify an assumption against past decisions. Checks for contradictions,
    scores risk, and requests human approval when needed.

    ALWAYS pass project_root as the current working directory so decisions
    are stored per-project and not mixed across projects.

    The AI MUST call this at every decision point:
    - When guessing instead of using confirmed info
    - When choosing between multiple valid options
    - When the choice might contradict a previous decision
    - Before any hard-to-reverse step
    """
    _VALID_RISK_LEVELS = {"low", "medium", "high", "critical"}
    if risk_level not in _VALID_RISK_LEVELS:
        LOG.warning("Invalid risk_level '%s', defaulting to 'medium'", risk_level)
        risk_level = "medium"

    db = _get_db(project_root)
    policy = _get_policy(project_root)
    matcher = _get_matcher(project_root)
    audit = _get_audit(project_root)
    notifier = _get_notifier(project_root)
    alts = alternatives or []
    risk = RiskLevel.from_str(risk_level)
    ts = datetime.now(timezone.utc).isoformat()

    similar = matcher.find_similar(assumption, top_k=5)
    contradictions = matcher.find_contradictions(assumption, similar)
    verdict = policy.evaluate(assumption=assumption, risk=risk, category=category, similar_decisions=similar, contradictions=contradictions)

    result: dict[str, Any] = {
        "assumption": assumption, "risk_level": risk.value, "category": category, "timestamp": ts,
        "project": Path(project_root).resolve().name,
        "similar_past_decisions": [{"decision": s["text"], "similarity": round(s["score"], 3), "status": s["status"]} for s in similar[:3]],
        "contradictions_found": [{"decision": c["text"], "reason": c["reason"]} for c in contradictions],
        "policy_verdict": verdict.action,
    }

    if verdict.action == "auto_approve":
        did = db.log_decision(text=assumption, category=category, risk_level=risk.value, status="auto_approved", rationale=verdict.reason, context=context, alternatives=json.dumps(alts), signature=_sign(assumption))
        result.update(status="auto_approved", reason=verdict.reason, decision_id=did)
        audit.append("auto_approve", assumption, verdict.reason, did)
    elif verdict.action == "block":
        result.update(status="blocked", reason=verdict.reason, action_required="This assumption contradicts past decisions or carries critical risk. Do NOT proceed without human approval.")
        audit.append("block", assumption, verdict.reason, None)
        hr = await _request_human_approval(ctx=ctx, notifier=notifier, title="⛔ Assumption Blocked", assumption=assumption, context=context, reason=verdict.reason, contradictions=contradictions, risk=risk)
        result.update(**_process_human_response(db, audit, hr, assumption, category, risk, context, alts))
    else:
        hr = await _request_human_approval(ctx=ctx, notifier=notifier, title="🔍 Assumption Review", assumption=assumption, context=context, reason=verdict.reason, contradictions=contradictions, risk=risk)
        result.update(**_process_human_response(db, audit, hr, assumption, category, risk, context, alts))

    return result


def _process_human_response(db, audit, hr, assumption, category, risk, context, alts) -> dict[str, Any]:
    if hr.get("approved"):
        did = db.log_decision(text=assumption, category=category, risk_level=risk.value, status="human_approved", rationale=hr.get("comment", ""), context=context, alternatives=json.dumps(alts), signature=_sign(assumption))
        audit.append("human_approve", assumption, hr.get("comment", ""), did)
        return {"status": "human_approved", "human_comment": hr.get("comment", ""), "decision_id": did}
    else:
        audit.append("human_reject", assumption, hr.get("comment", ""), None)
        return {"status": "human_rejected", "human_comment": hr.get("comment", "")}


@mcp.tool()
async def confirm_decision(
    decision: str,
    rationale: str,
    project_root: str = ".",
    alternatives_considered: list[str] | None = None,
    category: str = "general",
    is_irreversible: bool = False,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Record a finalized decision. Irreversible decisions always require human approval.
    Always pass project_root as the current working directory."""
    db = _get_db(project_root)
    audit = _get_audit(project_root)
    notifier = _get_notifier(project_root)
    alts = alternatives_considered or []
    if is_irreversible:
        hr = await _request_human_approval(ctx=ctx, notifier=notifier, title="⚠️ Irreversible Decision", assumption=decision, context=rationale, reason="This decision is marked as irreversible.", contradictions=[], risk=RiskLevel.CRITICAL)
        if not hr.get("approved"):
            audit.append("human_reject_irreversible", decision, hr.get("comment", ""), None)
            return {"status": "rejected", "decision": decision, "human_comment": hr.get("comment", "")}
    did = db.log_decision(text=decision, category=category, risk_level="critical" if is_irreversible else "low", status="confirmed", rationale=rationale, context="", alternatives=json.dumps(alts), signature=_sign(decision))
    audit.append("confirm", decision, rationale, did)
    return {"status": "confirmed", "decision_id": did, "decision": decision, "rationale": rationale}


@mcp.tool()
async def ask_human(
    question: str,
    project_root: str = ".",
    options: list[str] | None = None,
    urgency: str = "normal",
    context: str = "",
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Ask the human a direct question and wait for their response. Call this whenever uncertain.
    Always pass project_root as the current working directory."""
    notifier = _get_notifier(project_root)
    audit = _get_audit(project_root)
    response = await _ask_human_question(ctx=ctx, notifier=notifier, question=question, options=options or [], urgency=urgency, context=context)
    audit.append("ask_human", question, response.get("answer", ""), None)
    return {"question": question, "answer": response.get("answer", ""), "answered_via": response.get("channel", "unknown"), "timestamp": datetime.now(timezone.utc).isoformat()}


@mcp.tool()
async def query_decisions(
    project_root: str = ".",
    keyword: str = "",
    category: str = "",
    status: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """Search past decisions for context and consistency.
    Always pass project_root as the current working directory."""
    return {
        "query": {"keyword": keyword, "category": category, "status": status},
        "project": Path(project_root).resolve().name,
        "count": 0,
        "decisions": _get_db(project_root).search_decisions(keyword=keyword, category=category, status=status, limit=limit),
    }


@mcp.tool()
async def revoke_decision(
    decision_id: int,
    reason: str,
    project_root: str = ".",
) -> dict[str, Any]:
    """Revoke or supersede a previously approved decision.

    Use this when a past decision was wrong, circumstances changed, or it
    conflicts with new requirements. The decision is marked 'revoked' in the
    log so future similarity checks ignore it.

    Always pass project_root as the current working directory."""
    db = _get_db(project_root)
    audit = _get_audit(project_root)
    matches = db.search_decisions(limit=1000)
    target = next((d for d in matches if d["id"] == decision_id), None)
    if target is None:
        return {"status": "error", "reason": f"Decision {decision_id} not found in project '{Path(project_root).resolve().name}'"}
    db.update_status(decision_id, "revoked", rationale=reason)
    audit.append("revoke", target["text"], reason, decision_id)
    return {
        "status": "revoked",
        "decision_id": decision_id,
        "original_text": target["text"],
        "reason": reason,
    }


@mcp.tool()
async def get_firewall_stats(project_root: str = ".") -> dict[str, Any]:
    """Return firewall statistics for the current project.
    Always pass project_root as the current working directory."""
    stats = _get_db(project_root).get_stats()
    stats["project"] = Path(project_root).resolve().name
    stats["data_dir"] = str(_project_data_dir(project_root))
    return stats


@mcp.tool()
async def setup_project(project_root: str = ".", ctx: Context | None = None) -> dict[str, Any]:
    """
    Initialize Kontrol Freek for the current project.

    Checks if .kontrol-freek.json exists in the project root. If not,
    analyzes project files to infer a configuration, then asks the human
    for confirmation before writing the file.

    Always pass project_root as the current working directory.
    Call this at the start of every session in a new project.
    """
    root = Path(project_root)
    cfg_path = root / ".kontrol-freek.json"

    if cfg_path.exists():
        try:
            existing = json.loads(cfg_path.read_text())
            return {
                "status": "already_configured",
                "project_name": existing.get("project_name", ""),
                "config_path": str(cfg_path),
                "data_dir": str(_project_data_dir(project_root)),
            }
        except Exception as e:
            LOG.warning("Corrupted .kontrol-freek.json at %s: %s — re-running setup", cfg_path, e)

    # --- Detect project name from common files ---
    detected_name = root.resolve().name  # fallback: directory name

    pkg_json = root / "package.json"
    pyproject = root / "pyproject.toml"
    readme = root / "README.md"

    if pkg_json.exists():
        try:
            detected_name = json.loads(pkg_json.read_text()).get("name", detected_name)
        except Exception as e:
            LOG.warning("Failed to read project name from package.json: %s", e)
    elif pyproject.exists():
        try:
            for line in pyproject.read_text().splitlines():
                line = line.strip()
                if line.startswith("name") and "=" in line:
                    detected_name = line.split("=", 1)[1].strip().strip('"').strip("'")
                    break
        except Exception as e:
            LOG.warning("Failed to read project name from pyproject.toml: %s", e)
    elif readme.exists():
        try:
            for line in readme.read_text().splitlines():
                if line.startswith("# "):
                    detected_name = line[2:].strip()
                    break
        except Exception as e:
            LOG.warning("Failed to read project name from README.md: %s", e)

    proposed: dict[str, Any] = {
        "project_name": detected_name,
        "telegram_token": "",
        "telegram_chat_id": "",
        "slack_webhook": "",
    }

    data_dir = KF_PROJECTS_DIR / re.sub(r"[^a-zA-Z0-9_-]", "_", detected_name)[:60]

    elicit_msg = (
        f"**Kontrol Freek — Project Setup**\n\n"
        f"No `.kontrol-freek.json` found for this project.\n"
        f"Config will be saved to `{cfg_path}`, data stored under `{data_dir}`:\n\n"
        f"```json\n{json.dumps(proposed, indent=2, ensure_ascii=False)}\n```\n\n"
        f"Would you like to enter Telegram or Slack credentials now? "
        f"(Leave blank to configure later by editing the file manually.)"
    )

    schema = {
        "type": "object",
        "properties": {
            "project_name": {"type": "string", "title": "Project name", "default": detected_name},
            "telegram_token": {"type": "string", "title": "Telegram Bot Token (optional)", "default": ""},
            "telegram_chat_id": {"type": "string", "title": "Telegram Chat ID (optional)", "default": ""},
            "confirm_save": {"type": "boolean", "title": "Save config file", "default": True},
        },
        "required": ["confirm_save"],
    }

    answered: dict[str, Any] | None = None
    if ctx is not None:
        try:
            result = await asyncio.wait_for(ctx.elicit(message=elicit_msg, schema=schema), timeout=10.0)
            if result is not None:
                answered = result.data if hasattr(result, "data") else result
        except Exception as e:
            LOG.warning("Elicitation failed (%s), using proposed defaults", e)

    if answered is None:
        # Elicitation unavailable (stdio MCP context) — use defaults and proceed.
        # input() would block forever in a non-interactive MCP server process.
        LOG.info("Elicitation unavailable; proceeding with default config for %s", detected_name)
        answered = {"confirm_save": True, "project_name": detected_name}

    if not answered.get("confirm_save", False):
        return {"status": "cancelled", "reason": "User declined"}

    if answered.get("project_name"):
        proposed["project_name"] = answered["project_name"]
    if answered.get("telegram_token"):
        proposed["telegram_token"] = answered["telegram_token"]
    if answered.get("telegram_chat_id"):
        proposed["telegram_chat_id"] = answered["telegram_chat_id"]

    cfg_path.write_text(json.dumps(proposed, indent=2, ensure_ascii=False))
    LOG.info("Project config saved: %s", cfg_path)

    # Invalidate notifier cache so it picks up new credentials
    _invalidate_notifier(project_root)

    actual_data_dir = _project_data_dir(project_root)

    return {
        "status": "configured",
        "config_path": str(cfg_path),
        "project_name": proposed["project_name"],
        "data_dir": str(actual_data_dir),
        "telegram_enabled": bool(proposed.get("telegram_token") and proposed.get("telegram_chat_id")),
    }


@mcp.tool()
async def healthcheck(project_root: str = ".") -> dict[str, Any]:
    """Full health check — DB, audit chain, channels.
    Always pass project_root as the current working directory."""
    r: dict[str, Any] = {
        "status": "ok",
        "project": Path(project_root).resolve().name,
        "data_dir": str(_project_data_dir(project_root)),
        "checks": {},
    }
    try:
        r["checks"]["db"] = {"ok": True, "total_decisions": _get_db(project_root).get_stats()["total_decisions"]}
    except Exception as e:
        r["checks"]["db"] = {"ok": False, "error": str(e)}; r["status"] = "degraded"
    try:
        valid, count = _get_audit(project_root).verify_chain()
        r["checks"]["audit"] = {"ok": valid, "entries": count}
        if not valid: r["status"] = "degraded"
    except Exception as e:
        r["checks"]["audit"] = {"ok": False, "error": str(e)}
    r["checks"]["channels"] = _get_notifier(project_root)._channels
    return r


# =========================================================================
# RESOURCES + PROMPT
# =========================================================================

@mcp.resource("kontrol-freek://project-context")
async def get_project_context() -> str:
    """Read project context files."""
    parts = []
    root = Path(".")
    for f in ["README.md", "decisions.json", ".decisions.json"]:
        p = root / f
        if p.exists(): parts.append(f"=== {f} ===\n{p.read_text(errors='replace')[:5000]}")
    return "\n\n".join(parts) or "No project context files found."


@mcp.resource("kontrol-freek://stats")
async def stats_resource() -> str:
    return json.dumps(_get_db(".").get_stats(), indent=2)


@mcp.prompt()
async def assumption_discipline_prompt() -> str:
    """System prompt that enforces assumption discipline."""
    return """## KONTROL FREEK — MANDATORY RULES

You are connected to the Kontrol Freek assumption firewall.

### CORE RULE: Never assume — always verify.

IMPORTANT: Every tool call MUST include project_root=<current working directory>.
This ensures decisions are stored per-project and never mixed across projects.

At EVERY decision point:
1. Separate known facts from unknowns
2. State assumptions: ASSUMPTION: [text] | CONFIDENCE: [high/medium/low]
3. Call check_assumption(assumption=..., project_root=<cwd>) for medium/low confidence items
4. Call confirm_decision(project_root=<cwd>) before irreversible actions
5. Call ask_human(project_root=<cwd>) when uncertain

WHEN TO CALL check_assumption(): guessing, choosing between options,
assuming preferences, technical assumptions, potential contradictions.

WHEN TO CALL confirm_decision(): file deletion, overwrites, deploys,
architecture decisions, third-party integrations.

WHEN TO CALL ask_human(): missing context, personal preferences,
equally valid options.

WHEN TO CALL query_decisions(): new task start, before decisions, user asks.

SKIPPING THESE RULES IS FORBIDDEN. Asking beats assuming. Always."""


# =========================================================================
# INTERNAL HELPERS
# =========================================================================

async def _request_human_approval(*, ctx, notifier, title, assumption, context, reason, contradictions, risk) -> dict[str, Any]:
    parts = [f"**{title}**", f"**Assumption:** {assumption}"]
    if context: parts.append(f"**Context:** {context}")
    parts += [f"**Risk:** {risk.value}", f"**Reason:** {reason}"]
    if contradictions:
        parts.append("**Contradictions:**\n" + "\n".join(f"  - {c['reason']}" for c in contradictions))
    msg = "\n".join(parts)

    if ctx is not None:
        try:
            result = await asyncio.wait_for(
                ctx.elicit(message=msg, schema={"type": "object", "properties": {"approved": {"type": "boolean", "title": "Approve"}, "comment": {"type": "string", "title": "Comment", "default": ""}}, "required": ["approved"]}),
                timeout=60.0,
            )
            if result is not None:
                d = result.data if hasattr(result, "data") else result
                if isinstance(d, dict): return {"approved": d.get("approved", False), "comment": d.get("comment", ""), "channel": "elicitation"}
        except Exception as e:
            LOG.warning("Elicitation failed (%s)", e)

    # Only use notifier (which may call input()) when remote channels are configured.
    # Never block on terminal input inside an MCP stdio process — stdin is owned by the protocol.
    remote_channels = [ch for ch in notifier._channels if ch not in ("terminal", "web")]
    if remote_channels:
        return await notifier.request_approval(msg)

    # No interactive channel available — auto-approve low/medium risk, reject critical.
    if risk.value in ("critical", "high"):
        return {"approved": False, "comment": "No interactive approval channel configured (Telegram/Slack). Configure KF_TELEGRAM_TOKEN or KF_SLACK_WEBHOOK to gate high-risk decisions.", "channel": "unavailable"}
    return {"approved": True, "comment": "Auto-approved: no interactive channel configured for this risk level.", "channel": "auto"}


async def _ask_human_question(*, ctx, notifier, question, options, urgency, context) -> dict[str, Any]:
    full_q = question
    if context: full_q += f"\n\nContext: {context}"
    if options: full_q += "\n\nOptions:\n" + "\n".join(f"  {i+1}. {o}" for i, o in enumerate(options))

    if ctx is not None:
        try:
            result = await asyncio.wait_for(
                ctx.elicit(message=full_q, schema={"type": "object", "properties": {"answer": {"type": "string", "title": "Answer"}}, "required": ["answer"]}),
                timeout=60.0,
            )
            if result is not None:
                d = result.data if hasattr(result, "data") else result
                if isinstance(d, dict): return {"answer": d.get("answer", ""), "channel": "elicitation"}
        except Exception as e:
            LOG.warning("Elicitation failed (%s)", e)

    remote_channels = [ch for ch in notifier._channels if ch not in ("terminal", "web")]
    if remote_channels:
        return await notifier.ask_question(full_q)

    return {"answer": "", "channel": "unavailable", "note": "No interactive channel configured. Configure KF_TELEGRAM_TOKEN or KF_SLACK_WEBHOOK."}


def main():
    import argparse
    p = argparse.ArgumentParser(description="Kontrol Freek MCP Server")
    p.add_argument("--transport", default="stdio", choices=["stdio", "streamable-http", "sse"])
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=8765)
    a = p.parse_args()
    mcp.run(transport="stdio") if a.transport == "stdio" else mcp.run(transport=a.transport, host=a.host, port=a.port)

if __name__ == "__main__":
    main()
