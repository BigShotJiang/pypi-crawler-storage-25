"""Tests for MCP configuration generation."""

import json
from io import StringIO
from pathlib import Path

import pytest
from pydantic import ValidationError
from rich.console import Console

from atk import exit_codes
from atk.cli import app
from atk.mcp import (
    McpConfig,
    StdioMcpConfig,
    format_mcp_plaintext,
    generate_mcp_config,
    substitute_plugin_dir,
)
from atk.mcp_agents import (
    build_auggie_mcp_config,
    build_claude_mcp_config,
    build_codex_mcp_config,
    build_gemini_mcp_config,
    build_opencode_mcp_config,
)
from atk.mcp_configure import (
    run_auggie_mcp_remove,
    run_claude_mcp_remove,
    run_opencode_mcp_add,
)
from atk.plugin_schema import PLUGIN_SCHEMA_VERSION, EnvVarConfig, McpPluginConfig, PluginSchema


class TestSubstitutePluginDir:
    """Tests for ATK_PLUGIN_DIR substitution."""

    @pytest.fixture(autouse=True)
    def setup_method(self, tmp_path: Path) -> None:
        """Set up plugin directory for each test."""
        self.plugin_dir = tmp_path / "plugins" / "test-plugin"

    def test_substitute_dollar_syntax(self) -> None:
        """Verify $ATK_PLUGIN_DIR is substituted with absolute path."""
        # Given
        command = "$ATK_PLUGIN_DIR/mcp-server.sh"

        # When
        result = substitute_plugin_dir(command, self.plugin_dir)

        # Then
        expected = f"{self.plugin_dir.resolve()}/mcp-server.sh"
        assert result == expected

    def test_substitute_braces_syntax(self) -> None:
        """Verify ${ATK_PLUGIN_DIR} is substituted with absolute path."""
        # Given
        command = "${ATK_PLUGIN_DIR}/mcp-server.sh"

        # When
        result = substitute_plugin_dir(command, self.plugin_dir)

        # Then
        expected = f"{self.plugin_dir.resolve()}/mcp-server.sh"
        assert result == expected

    def test_substitute_multiple_occurrences(self) -> None:
        """Verify multiple occurrences of $ATK_PLUGIN_DIR are all substituted."""
        # Given
        value = "$ATK_PLUGIN_DIR/bin:$ATK_PLUGIN_DIR/lib"

        # When
        result = substitute_plugin_dir(value, self.plugin_dir)

        # Then
        plugin_dir_str = str(self.plugin_dir.resolve())
        expected = f"{plugin_dir_str}/bin:{plugin_dir_str}/lib"
        assert result == expected

    def test_substitute_mixed_syntax(self) -> None:
        """Verify both $VAR and ${VAR} syntax work in same string."""
        # Given
        value = "$ATK_PLUGIN_DIR/bin:${ATK_PLUGIN_DIR}/lib"

        # When
        result = substitute_plugin_dir(value, self.plugin_dir)

        # Then
        plugin_dir_str = str(self.plugin_dir.resolve())
        expected = f"{plugin_dir_str}/bin:{plugin_dir_str}/lib"
        assert result == expected

    def test_no_substitution_when_variable_not_present(self) -> None:
        """Verify strings without $ATK_PLUGIN_DIR are unchanged."""
        # Given
        command = "/usr/bin/python"

        # When
        result = substitute_plugin_dir(command, self.plugin_dir)

        # Then
        assert result == command

    def test_substitute_in_arg_with_path(self) -> None:
        """Verify substitution works in arguments like --config=$ATK_PLUGIN_DIR/config.json."""
        # Given
        arg = "--config=$ATK_PLUGIN_DIR/config.json"

        # When
        result = substitute_plugin_dir(arg, self.plugin_dir)

        # Then
        expected = f"--config={self.plugin_dir.resolve()}/config.json"
        assert result == expected


class TestGenerateMcpConfigWithSubstitution:
    """Tests for generate_mcp_config with ATK_PLUGIN_DIR substitution."""
    @pytest.fixture(autouse=True)
    def setup_method(self, tmp_path: Path) -> None:
        """Set up plugin directory for each test."""
        self.plugin_dir = tmp_path / "plugins" / "test-plugin"

    def test_substitutes_command(self) -> None:
        """Verify command field is substituted."""
        # Given
        command = "$ATK_PLUGIN_DIR/mcp-server.sh"

        plugin = PluginSchema(
            schema_version="2026-01-23",
            name="TestPlugin",
            description="Test plugin",
            mcp=McpPluginConfig(transport="stdio", command=command),
        )

        # When
        result = generate_mcp_config(plugin, self.plugin_dir, "test-plugin")

        # Then
        expected_command = f"{self.plugin_dir.resolve()}/mcp-server.sh"
        assert isinstance(result, StdioMcpConfig)
        assert result.command == expected_command

    def test_substitutes_args(self) -> None:
        """Verify args are substituted."""
        # Given
        command = "python"
        args = ["--config", "$ATK_PLUGIN_DIR/config.json", "--data-dir", "${ATK_PLUGIN_DIR}/data"]

        plugin = PluginSchema(
            schema_version="2026-01-23",
            name="TestPlugin",
            description="Test plugin",
            mcp=McpPluginConfig(transport="stdio", command=command, args=args),
        )

        # When
        result = generate_mcp_config(plugin, self.plugin_dir, "test-plugin")

        # Then
        plugin_dir_str = str(self.plugin_dir.resolve())
        expected_args = [
            "--config",
            f"{plugin_dir_str}/config.json",
            "--data-dir",
            f"{plugin_dir_str}/data",
        ]
        assert isinstance(result, StdioMcpConfig)
        assert result.args == expected_args


# ---------------------------------------------------------------------------
# Helpers — module-level factory functions (not fixtures)
# ---------------------------------------------------------------------------

def _make_stdio_plugin(
    *,
    name: str = "TestPlugin",
    command: str = "uv",
    args: list[str] | None = None,
    mcp_env: list[str] | None = None,
    env_vars: list[EnvVarConfig] | None = None,
) -> PluginSchema:
    """Build a PluginSchema with a stdio MCP config."""
    return PluginSchema(
        schema_version=PLUGIN_SCHEMA_VERSION,
        name=name,
        description="Test plugin",
        mcp=McpPluginConfig(transport="stdio", command=command, args=args, env=mcp_env),
        env_vars=env_vars or [],
    )


def _make_sse_plugin(
    *,
    name: str = "TestPlugin",
    endpoint: str = "http://localhost:8080/mcp",
    mcp_env: list[str] | None = None,
    env_vars: list[EnvVarConfig] | None = None,
) -> PluginSchema:
    """Build a PluginSchema with an SSE MCP config."""
    return PluginSchema(
        schema_version=PLUGIN_SCHEMA_VERSION,
        name=name,
        description="Test plugin",
        mcp=McpPluginConfig(transport="sse", endpoint=endpoint, env=mcp_env),
        env_vars=env_vars or [],
    )


def _write_env_file(plugin_dir: Path, values: dict[str, str]) -> None:
    """Write a .env file into the plugin directory."""
    plugin_dir.mkdir(parents=True, exist_ok=True)
    (plugin_dir / ".env").write_text(
        "\n".join(f"{k}={v}" for k, v in values.items()) + "\n"
    )


def _render_plaintext(result: McpConfig) -> str:
    """Render format_mcp_plaintext() output as plain text (markup stripped)."""
    sio = StringIO()
    console = Console(file=sio, no_color=True, highlight=False, markup=True, width=1000)
    console.print(format_mcp_plaintext(result))
    return sio.getvalue()


# ---------------------------------------------------------------------------
# Data layer — env var default resolution (generate_mcp_config)
# ---------------------------------------------------------------------------

def test_generate_mcp_config_uses_env_var_default_when_not_in_dotenv(tmp_path: Path) -> None:
    """When a var is missing from .env but has a default in env_vars, use the default."""
    # Given
    var_name = "MODEL_PATH"
    default_value = "/opt/models/kokoro"
    plugin = _make_stdio_plugin(
        mcp_env=[var_name],
        env_vars=[EnvVarConfig(name=var_name, default=default_value)],
    )
    plugin_dir = tmp_path / "test-plugin"
    plugin_dir.mkdir()
    # No .env file written — var is absent

    # When
    result = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # Then
    assert result.env[var_name] == default_value
    assert var_name not in result.missing_vars


def test_generate_mcp_config_dotenv_value_takes_precedence_over_default(tmp_path: Path) -> None:
    """A value present in .env overrides the declared default in env_vars."""
    # Given
    var_name = "MODEL_PATH"
    default_value = "/opt/models/default"
    dotenv_value = "/home/user/custom-model"
    plugin = _make_stdio_plugin(
        mcp_env=[var_name],
        env_vars=[EnvVarConfig(name=var_name, default=default_value)],
    )
    plugin_dir = tmp_path / "test-plugin"
    _write_env_file(plugin_dir, {var_name: dotenv_value})

    # When
    result = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # Then
    assert result.env[var_name] == dotenv_value
    assert var_name not in result.missing_vars


def test_generate_mcp_config_marks_not_set_when_required_var_has_no_value(tmp_path: Path) -> None:
    """A required var with no .env value and no default is marked NOT_SET in env and tracked in missing_vars."""
    # Given
    var_name = "API_KEY"
    plugin = _make_stdio_plugin(
        mcp_env=[var_name],
        env_vars=[EnvVarConfig(name=var_name, required=True)],  # required, no default
    )
    plugin_dir = tmp_path / "test-plugin"
    plugin_dir.mkdir()

    # When
    result = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # Then
    assert result.env[var_name] == "<NOT_SET>"
    assert var_name in result.missing_vars
    assert var_name not in result.optional_unset_vars


def test_generate_mcp_config_omits_optional_unset_var_from_env(tmp_path: Path) -> None:
    """An optional var with no .env value and no default is omitted from env and tracked in optional_unset_vars."""
    # Given
    var_name = "GITHUB_HOST"
    plugin = _make_stdio_plugin(
        mcp_env=[var_name],
        env_vars=[EnvVarConfig(name=var_name, required=False)],  # optional, no default
    )
    plugin_dir = tmp_path / "test-plugin"
    plugin_dir.mkdir()

    # When
    result = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # Then — optional unset var must not pollute env or appear as NOT_SET
    assert var_name not in result.env
    assert var_name not in result.missing_vars
    assert var_name in result.optional_unset_vars


def test_format_mcp_plaintext_shows_optional_unset_vars_as_note(tmp_path: Path) -> None:
    """Optional unset vars appear as a dim 'not set (optional, omitted)' note in plaintext; NOT_SET is never shown."""
    # Given
    set_var_name = "GITHUB_TOKEN"
    set_var_value = "ghp_secret"
    optional_var_name = "GITHUB_HOST"
    plugin = _make_stdio_plugin(
        command="npx",
        mcp_env=[set_var_name, optional_var_name],
        env_vars=[
            EnvVarConfig(name=set_var_name, required=True),
            EnvVarConfig(name=optional_var_name, required=False),
        ],
    )
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {set_var_name: set_var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # When
    rendered = _render_plaintext(mcp_config)

    # Then
    assert f"{set_var_name}={set_var_value}" in rendered
    assert "not set (optional, omitted)" in rendered
    assert optional_var_name in rendered
    assert "<NOT_SET>" not in rendered



# ---------------------------------------------------------------------------
# Env var substitution in command and args
# ---------------------------------------------------------------------------

def test_generate_mcp_config_substitutes_env_var_in_args(tmp_path: Path) -> None:
    """$VAR references in args are replaced with the resolved env var value.

    Regression: OpenMemory uses args=['-y', 'mcp-remote', '$OPENMEMORY_URL/mcp'].
    Claude Code spawns servers via execve (no shell), so $VAR in args is never
    expanded at runtime. ATK must substitute the resolved value before handing
    the config to any agent CLI.
    """
    # Given
    var_name = "OPENMEMORY_URL"
    var_value = "http://localhost:8787"
    plugin = _make_stdio_plugin(
        command="npx",
        args=["-y", "mcp-remote", f"${var_name}/mcp"],
        mcp_env=[var_name],
        env_vars=[EnvVarConfig(name=var_name, default=var_value)],
    )
    plugin_dir = tmp_path / "test-plugin"
    plugin_dir.mkdir()

    # When
    result = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # Then — $OPENMEMORY_URL/mcp must be replaced with the resolved URL
    assert isinstance(result, StdioMcpConfig)
    expected_args = ["-y", "mcp-remote", f"{var_value}/mcp"]
    assert result.args == expected_args


def test_generate_mcp_config_substitutes_braces_env_var_in_args(tmp_path: Path) -> None:
    """${VAR} brace syntax in args is also substituted."""
    # Given
    var_name = "BASE_URL"
    var_value = "http://localhost:9000"
    plugin = _make_stdio_plugin(
        command="npx",
        args=["--url", f"${{{var_name}}}/endpoint"],
        mcp_env=[var_name],
        env_vars=[EnvVarConfig(name=var_name, default=var_value)],
    )
    plugin_dir = tmp_path / "test-plugin"
    plugin_dir.mkdir()

    # When
    result = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # Then
    assert isinstance(result, StdioMcpConfig)
    expected_args = ["--url", f"{var_value}/endpoint"]
    assert result.args == expected_args


def test_generate_mcp_config_leaves_required_unset_var_unexpanded_in_args(tmp_path: Path) -> None:
    """If a $VAR reference in args maps to a required NOT_SET var, leave it unchanged."""
    # Given
    var_name = "MISSING_URL"
    plugin = _make_stdio_plugin(
        command="npx",
        args=["--url", f"${var_name}/mcp"],
        mcp_env=[var_name],
        env_vars=[EnvVarConfig(name=var_name, required=True)],  # required, no default
    )
    plugin_dir = tmp_path / "test-plugin"
    plugin_dir.mkdir()

    # When
    result = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # Then — unresolvable required var stays as the literal $VAR string in args
    assert isinstance(result, StdioMcpConfig)
    assert result.args == ["--url", f"${var_name}/mcp"]
    assert var_name in result.missing_vars
    assert var_name not in result.optional_unset_vars


# ---------------------------------------------------------------------------
# Formatter adapter layer — format_mcp_plaintext
# ---------------------------------------------------------------------------

def test_format_mcp_plaintext_stdio(tmp_path: Path) -> None:
    """stdio plugin: exact rendered output with Name, Command, and Environment Variables."""
    # Given
    command = "uv"
    args = ["run", "--directory", str(tmp_path / "plugin"), "server.py"]
    var_name = "API_KEY"
    var_value = "my-secret"
    plugin = _make_stdio_plugin(command=command, args=args, mcp_env=[var_name])
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {var_name: var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # When
    rendered = _render_plaintext(mcp_config)

    # Then
    expected = (
        f"Name:    {plugin.name}\n"
        f"Command:  {command} {' '.join(args)}\n"
        f"\n"
        f"Environment Variables:\n"
        f"  {var_name}={var_value}\n"
    )
    assert rendered == expected


def test_format_mcp_plaintext_sse(tmp_path: Path) -> None:
    """SSE plugin: exact rendered output with Name and URL; no Environment Variables section."""
    # Given
    endpoint = "http://localhost:8080/mcp"
    plugin = _make_sse_plugin(endpoint=endpoint)  # no env vars
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, "test-plugin")

    # When
    rendered = _render_plaintext(mcp_config)

    # Then
    expected = (
        f"Name:    {plugin.name}\n"
        f"URL:     {endpoint}\n"
    )
    assert rendered == expected


# ---------------------------------------------------------------------------
# CLI E2E tests
# ---------------------------------------------------------------------------

def test_mcp_command_default_outputs_plaintext(create_plugin, cli_runner) -> None:
    """Default output (no --json) is plaintext with Name and Command sections."""
    # Given
    plugin_name = "TestPlugin"
    command = "uv"
    args = ["run", "server.py"]
    plugin = _make_stdio_plugin(name=plugin_name, command=command, args=args)
    create_plugin(plugin=plugin, directory="test-plugin")

    # When
    result = cli_runner.invoke(app, ["mcp", "test-plugin"])

    # Then
    assert result.exit_code == exit_codes.SUCCESS
    assert "Name:" in result.output
    assert plugin_name in result.output
    assert "Command:" in result.output
    assert f"{command} {' '.join(args)}" in result.output



# ---------------------------------------------------------------------------
# build_claude_mcp_config — unit tests (pure, no subprocess)
# ---------------------------------------------------------------------------

def test_build_claude_mcp_config_stdio_minimal(tmp_path: Path) -> None:
    """Minimal stdio plugin: argv has correct shape with name and command."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    plugin = _make_stdio_plugin(name=plugin_name, command=command)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then
    assert result.argv == ["claude", "mcp", "add", "--scope", "user", "--", plugin_name, command]


def test_build_claude_mcp_config_stdio_with_args(tmp_path: Path) -> None:
    """Stdio plugin with args: all args appended positionally after command."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    plugin_args = ["run", "--directory", "/some/path", "server.py"]
    plugin = _make_stdio_plugin(name=plugin_name, command=command, args=plugin_args)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then
    assert result.argv == [
        "claude", "mcp", "add", "--scope", "user", "--",
        plugin_name, command, *plugin_args,
    ]


def test_build_claude_mcp_config_double_dash_terminates_option_parsing(tmp_path: Path) -> None:
    """-- must appear before server name so claude does not eat server args as its own options.

    Regression: `uv run --directory /path` caused `error: unknown option '--directory'`
    because claude's parser was still active when it hit --directory.
    """
    # Given
    plugin_name = "parley"
    command = "uv"
    plugin_args = ["run", "--directory", "/some/path", "parley-mcp", "run"]
    plugin = _make_stdio_plugin(name=plugin_name, command=command, args=plugin_args)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then — "--" must appear before the server name
    double_dash_idx = result.argv.index("--")
    name_idx = result.argv.index(plugin_name)
    assert double_dash_idx < name_idx
    # and --directory must survive intact in the argv
    assert "--directory" in result.argv



def test_build_claude_mcp_config_stdio_with_env_vars(tmp_path: Path) -> None:
    """Set env vars each become a separate -e KEY=VAL flag."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    var_name = "API_KEY"
    var_value = "secret-123"
    plugin = _make_stdio_plugin(name=plugin_name, command=command, mcp_env=[var_name])
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {var_name: var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then
    assert result.argv == [
        "claude", "mcp", "add", "--scope", "user",
        "-e", f"{var_name}={var_value}",
        "--", plugin_name, command,
    ]


def test_build_claude_mcp_config_stdio_multiple_env_vars(tmp_path: Path) -> None:
    """Multiple env vars produce multiple consecutive -e KEY=VAL flags."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    var1_name, var1_value = "API_KEY", "secret-123"
    var2_name, var2_value = "MODEL", "gpt-4"
    plugin = _make_stdio_plugin(
        name=plugin_name, command=command, mcp_env=[var1_name, var2_name]
    )
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {var1_name: var1_value, var2_name: var2_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then
    assert result.argv == [
        "claude", "mcp", "add", "--scope", "user",
        "-e", f"{var1_name}={var1_value}",
        "-e", f"{var2_name}={var2_value}",
        "--", plugin_name, command,
    ]


def test_build_claude_mcp_config_stdio_skips_not_set_env_vars(tmp_path: Path) -> None:
    """Env vars with <NOT_SET> value are omitted from the argv entirely."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    set_var_name, set_var_value = "MODEL", "gpt-4"
    missing_var_name = "API_KEY"
    plugin = _make_stdio_plugin(
        name=plugin_name, command=command,
        mcp_env=[set_var_name, missing_var_name],
        env_vars=[EnvVarConfig(name=missing_var_name)],
    )
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {set_var_name: set_var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then — missing var must not appear anywhere in the argv
    assert missing_var_name not in " ".join(result.argv)
    assert result.argv == [
        "claude", "mcp", "add", "--scope", "user",
        "-e", f"{set_var_name}={set_var_value}",
        "--", plugin_name, command,
    ]


def test_build_claude_mcp_config_sse(tmp_path: Path) -> None:
    """SSE plugin: --transport sse inserted and URL placed as positional."""
    # Given
    plugin_name = "my-plugin"
    endpoint = "http://localhost:8080/mcp"
    plugin = _make_sse_plugin(name=plugin_name, endpoint=endpoint)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then
    assert result.argv == [
        "claude", "mcp", "add", "--transport", "sse", "--scope", "user",
        "--", plugin_name, endpoint,
    ]


def test_build_claude_mcp_config_scope_defaults_to_user(tmp_path: Path) -> None:
    """Default scope is 'user' — --scope user always present when no scope given."""
    # Given
    plugin_name = "my-plugin"
    plugin = _make_stdio_plugin(name=plugin_name)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config)

    # Then
    scope_index = result.argv.index("--scope")
    assert result.argv[scope_index + 1] == "user"


def test_build_claude_mcp_config_custom_scope(tmp_path: Path) -> None:
    """Passing scope='local' produces --scope local in the argv."""
    # Given
    plugin_name = "my-plugin"
    custom_scope = "local"
    plugin = _make_stdio_plugin(name=plugin_name)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_claude_mcp_config(mcp_config, scope=custom_scope)

    # Then
    scope_index = result.argv.index("--scope")
    assert result.argv[scope_index + 1] == custom_scope


# ---------------------------------------------------------------------------
# generate_mcp_config — fail-fast for missing transport-required fields
# ---------------------------------------------------------------------------

def test_generate_mcp_config_stdio_raises_when_command_missing() -> None:
    """stdio transport with no command is caught at schema construction — raises ValidationError."""
    # When / Then — validation now happens at McpPluginConfig construction, not generate_mcp_config
    with pytest.raises(ValidationError, match="'command' is required when transport is 'stdio'"):
        McpPluginConfig(transport="stdio")  # no command


def test_generate_mcp_config_sse_raises_when_endpoint_missing() -> None:
    """sse transport with no endpoint is caught at schema construction — raises ValidationError."""
    # When / Then — validation now happens at McpPluginConfig construction, not generate_mcp_config
    with pytest.raises(ValidationError, match="'endpoint' is required when transport is 'sse'"):
        McpPluginConfig(transport="sse")  # no endpoint




# ---------------------------------------------------------------------------
# build_codex_mcp_config — unit tests
# ---------------------------------------------------------------------------


def test_build_codex_mcp_config_stdio_minimal(tmp_path: Path) -> None:
    """Minimal stdio: argv is codex mcp add <name> -- <cmd>."""
    plugin_name = "my-plugin"
    command = "uv"
    plugin = _make_stdio_plugin(name=plugin_name, command=command)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_codex_mcp_config(mcp_config)

    assert result.argv == ["codex", "mcp", "add", plugin_name, "--", command]


def test_build_codex_mcp_config_stdio_with_args(tmp_path: Path) -> None:
    """Stdio plugin with args: all args appended after -- <command>."""
    plugin_name = "my-plugin"
    command = "uv"
    plugin_args = ["run", "--directory", "/some/path", "server.py"]
    plugin = _make_stdio_plugin(name=plugin_name, command=command, args=plugin_args)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_codex_mcp_config(mcp_config)

    assert result.argv == [
        "codex", "mcp", "add", plugin_name, "--", command, *plugin_args,
    ]


def test_build_codex_mcp_config_stdio_with_env_vars(tmp_path: Path) -> None:
    """Set env vars become --env KEY=VAL flags placed before the server name."""
    plugin_name = "my-plugin"
    var_name, var_value = "API_KEY", "secret-123"
    plugin = _make_stdio_plugin(name=plugin_name, command="uv", mcp_env=[var_name])
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {var_name: var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_codex_mcp_config(mcp_config)

    assert result.argv == [
        "codex", "mcp", "add", "--env", f"{var_name}={var_value}", plugin_name, "--", "uv",
    ]


def test_build_codex_mcp_config_stdio_skips_not_set_env_vars(tmp_path: Path) -> None:
    """Unresolved env vars are omitted from the Codex argv entirely."""
    plugin_name = "my-plugin"
    set_name, set_value = "MODEL", "gpt-4"
    missing_name = "API_KEY"
    plugin = _make_stdio_plugin(
        name=plugin_name, command="uv",
        mcp_env=[set_name, missing_name],
        env_vars=[EnvVarConfig(name=missing_name)],
    )
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {set_name: set_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_codex_mcp_config(mcp_config)

    assert missing_name not in " ".join(result.argv)
    assert result.argv == [
        "codex", "mcp", "add", "--env", f"{set_name}={set_value}", plugin_name, "--", "uv",
    ]


def test_build_codex_mcp_config_sse(tmp_path: Path) -> None:
    """SSE plugin: --url <url> instead of -- <cmd>."""
    plugin_name = "my-plugin"
    endpoint = "http://localhost:8080/mcp"
    plugin = _make_sse_plugin(name=plugin_name, endpoint=endpoint)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_codex_mcp_config(mcp_config)

    assert result.argv == ["codex", "mcp", "add", plugin_name, "--url", endpoint]


# ---------------------------------------------------------------------------
# build_auggie_mcp_config — unit tests
# ---------------------------------------------------------------------------


def test_build_auggie_mcp_config_stdio_minimal(tmp_path: Path) -> None:
    """Minimal stdio: argv is auggie mcp add-json <name> '<json>'."""
    plugin_name = "my-plugin"
    command = "uv"
    plugin = _make_stdio_plugin(name=plugin_name, command=command)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_auggie_mcp_config(mcp_config)

    assert result.argv[0:4] == ["auggie", "mcp", "add-json", plugin_name]
    payload = json.loads(result.argv[4])
    assert payload["command"] == command
    assert payload["args"] == []
    assert payload["env"] == {}


def test_build_auggie_mcp_config_stdio_args_is_json_array(tmp_path: Path) -> None:
    """Args in the JSON payload must be an array, never a string."""
    plugin_name = "my-plugin"
    plugin_args = ["run", "server.py"]
    plugin = _make_stdio_plugin(name=plugin_name, command="uv", args=plugin_args)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_auggie_mcp_config(mcp_config)

    payload = json.loads(result.argv[4])
    assert isinstance(payload["args"], list)
    assert payload["args"] == plugin_args


def test_build_auggie_mcp_config_stdio_includes_resolved_env_vars(tmp_path: Path) -> None:
    """Resolved env vars appear in the JSON env dict."""
    plugin_name = "my-plugin"
    var_name, var_value = "API_KEY", "secret-123"
    plugin = _make_stdio_plugin(name=plugin_name, command="uv", mcp_env=[var_name])
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {var_name: var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_auggie_mcp_config(mcp_config)

    payload = json.loads(result.argv[4])
    assert payload["env"] == {var_name: var_value}


def test_build_auggie_mcp_config_stdio_omits_not_set_env_vars(tmp_path: Path) -> None:
    """Unresolved env vars must not appear in the JSON payload."""
    plugin_name = "my-plugin"
    missing_name = "API_KEY"
    plugin = _make_stdio_plugin(
        name=plugin_name, command="uv",
        mcp_env=[missing_name],
        env_vars=[EnvVarConfig(name=missing_name)],
    )
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_auggie_mcp_config(mcp_config)

    payload = json.loads(result.argv[4])
    assert missing_name not in payload["env"]


def test_build_auggie_mcp_config_json_is_single_line(tmp_path: Path) -> None:
    """The JSON string must be compact (no newlines) — auggie rejects multi-line."""
    plugin = _make_stdio_plugin(command="uv")
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, "my-plugin")

    result = build_auggie_mcp_config(mcp_config)

    assert "\n" not in result.argv[4]


def test_build_auggie_mcp_config_sse(tmp_path: Path) -> None:
    """SSE plugin: payload is {type: sse, url: ...}."""
    plugin_name = "my-plugin"
    endpoint = "http://localhost:8080/mcp"
    plugin = _make_sse_plugin(name=plugin_name, endpoint=endpoint)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_auggie_mcp_config(mcp_config)

    assert result.argv[0:4] == ["auggie", "mcp", "add-json", plugin_name]
    payload = json.loads(result.argv[4])
    assert payload == {"type": "sse", "url": endpoint}


# ---------------------------------------------------------------------------
# build_opencode_mcp_config — unit tests
# ---------------------------------------------------------------------------


def test_build_opencode_mcp_config_stdio_minimal(tmp_path: Path) -> None:
    """Minimal stdio: entry has type=local, command array, empty environment."""
    plugin_name = "my-plugin"
    command = "uv"
    plugin = _make_stdio_plugin(name=plugin_name, command=command)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)
    cwd = tmp_path / "project"
    cwd.mkdir()

    result = build_opencode_mcp_config(mcp_config, cwd)

    assert result.entry_key == plugin_name
    assert result.entry_value["type"] == "local"
    assert result.entry_value["command"] == [command]
    assert result.entry_value["environment"] == {}
    assert result.entry_value["enabled"] is True
    assert result.file_path == cwd / "opencode.jsonc"


def test_build_opencode_mcp_config_stdio_command_includes_args(tmp_path: Path) -> None:
    """Command array includes executable + all args as one flat list."""
    plugin_name = "my-plugin"
    command = "uv"
    plugin_args = ["run", "server.py"]
    plugin = _make_stdio_plugin(name=plugin_name, command=command, args=plugin_args)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_opencode_mcp_config(mcp_config, tmp_path)

    assert result.entry_value["command"] == [command, *plugin_args]


def test_build_opencode_mcp_config_stdio_includes_resolved_env_vars(tmp_path: Path) -> None:
    """Resolved env vars appear under the 'environment' key (not 'env')."""
    plugin_name = "my-plugin"
    var_name, var_value = "API_KEY", "secret-123"
    plugin = _make_stdio_plugin(name=plugin_name, command="uv", mcp_env=[var_name])
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {var_name: var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_opencode_mcp_config(mcp_config, tmp_path)

    assert result.entry_value["environment"] == {var_name: var_value}
    assert "env" not in result.entry_value


def test_build_opencode_mcp_config_stdio_omits_not_set_env_vars(tmp_path: Path) -> None:
    """Unresolved env vars must not appear in the environment dict."""
    plugin_name = "my-plugin"
    missing_name = "API_KEY"
    plugin = _make_stdio_plugin(
        name=plugin_name, command="uv",
        mcp_env=[missing_name],
        env_vars=[EnvVarConfig(name=missing_name)],
    )
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_opencode_mcp_config(mcp_config, tmp_path)

    assert missing_name not in result.entry_value["environment"]


def test_build_opencode_mcp_config_sse(tmp_path: Path) -> None:
    """SSE plugin: entry has type=remote and url."""
    plugin_name = "my-plugin"
    endpoint = "http://localhost:8080/mcp"
    plugin = _make_sse_plugin(name=plugin_name, endpoint=endpoint)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    result = build_opencode_mcp_config(mcp_config, tmp_path)

    assert result.entry_value == {"type": "remote", "url": endpoint, "enabled": True}


def test_build_opencode_mcp_config_default_path_is_global_config(tmp_path: Path) -> None:
    """REGRESSION: When no config_dir is given, file_path must be the global OpenCode config.

    The global config lives at ~/.config/opencode/opencode.jsonc.
    Previously, ATK wrote to Path.cwd()/'opencode.jsonc' (wherever atk was run),
    which OpenCode never read — because OpenCode's global config is in ~/.config/opencode/.
    """
    plugin = _make_stdio_plugin(command="uv")
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, "my-plugin")

    result = build_opencode_mcp_config(mcp_config)

    expected = Path.home() / ".config" / "opencode" / "opencode.jsonc"
    assert result.file_path == expected, (
        f"Expected global config path {expected}, got {result.file_path}. "
        "OpenCode only reads its global config from ~/.config/opencode/, "
        "not from the current working directory."
    )


def test_run_opencode_mcp_add_creates_parent_dirs(tmp_path: Path) -> None:
    """run_opencode_mcp_add must create parent directories that do not yet exist.

    The global config dir (~/.config/opencode/) may not exist on a fresh install.
    """
    plugin = _make_stdio_plugin(command="uv")
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, "my-plugin")
    # Simulate a config dir that doesn't exist yet
    nested_config_dir = tmp_path / "nonexistent" / "deeply" / "nested"
    oc_config = build_opencode_mcp_config(mcp_config, nested_config_dir)
    assert not nested_config_dir.exists()

    run_opencode_mcp_add(oc_config)

    assert oc_config.file_path.exists()


# ---------------------------------------------------------------------------
# run_opencode_mcp_add — unit tests (file I/O, no subprocess)
# ---------------------------------------------------------------------------


def test_run_opencode_mcp_add_creates_file_when_missing(tmp_path: Path) -> None:
    """Creates opencode.jsonc with the mcp entry when the file does not exist."""
    plugin_name = "my-plugin"
    command = "uv"
    plugin = _make_stdio_plugin(name=plugin_name, command=command)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)
    cwd = tmp_path / "project"
    cwd.mkdir()
    oc_config = build_opencode_mcp_config(mcp_config, cwd)

    return_code = run_opencode_mcp_add(oc_config)

    assert return_code == 0
    assert oc_config.file_path.exists()
    data = json.loads(oc_config.file_path.read_text())
    assert data["mcp"][plugin_name]["type"] == "local"
    assert data["mcp"][plugin_name]["command"] == [command]


def test_run_opencode_mcp_add_merges_into_existing_file(tmp_path: Path) -> None:
    """Merges the new entry into an existing opencode.jsonc without overwriting other keys."""
    plugin_name = "my-plugin"
    existing_plugin_name = "existing-plugin"
    plugin = _make_stdio_plugin(name=plugin_name, command="uv")
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)
    cwd = tmp_path / "project"
    cwd.mkdir()

    existing_data = {
        "mcp": {existing_plugin_name: {"type": "local", "command": ["echo"], "enabled": True}},
        "other_key": "preserved",
    }
    (cwd / "opencode.jsonc").write_text(json.dumps(existing_data))

    oc_config = build_opencode_mcp_config(mcp_config, cwd)
    run_opencode_mcp_add(oc_config)

    data = json.loads(oc_config.file_path.read_text())
    assert existing_plugin_name in data["mcp"]
    assert plugin_name in data["mcp"]
    assert data["other_key"] == "preserved"


def test_run_opencode_mcp_add_overwrites_existing_entry(tmp_path: Path) -> None:
    """Re-running for the same plugin replaces the existing entry."""
    plugin_name = "my-plugin"
    command_v2 = "python"
    plugin = _make_stdio_plugin(name=plugin_name, command=command_v2)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)
    cwd = tmp_path / "project"
    cwd.mkdir()

    old_data = {"mcp": {plugin_name: {"type": "local", "command": ["uv"], "enabled": True}}}
    (cwd / "opencode.jsonc").write_text(json.dumps(old_data))

    oc_config = build_opencode_mcp_config(mcp_config, cwd)
    run_opencode_mcp_add(oc_config)

    data = json.loads(oc_config.file_path.read_text())
    assert data["mcp"][plugin_name]["command"] == [command_v2]


def test_run_opencode_mcp_add_raises_on_invalid_json(tmp_path: Path) -> None:
    """Raises ValueError if the existing file cannot be parsed as JSON."""
    plugin = _make_stdio_plugin(command="uv")
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, "my-plugin")
    cwd = tmp_path / "project"
    cwd.mkdir()
    (cwd / "opencode.jsonc").write_text("{ invalid json // comment\n")

    oc_config = build_opencode_mcp_config(mcp_config, cwd)

    with pytest.raises(ValueError, match="Cannot parse"):
        run_opencode_mcp_add(oc_config)



# ---------------------------------------------------------------------------
# run_claude_mcp_remove / run_auggie_mcp_remove — unit tests
# ---------------------------------------------------------------------------


def test_run_claude_mcp_remove_calls_correct_argv(monkeypatch) -> None:
    """run_claude_mcp_remove invokes 'claude mcp remove --scope user <name>'."""
    # Given
    plugin_name = "my-plugin"
    captured_args: list[list[str]] = []

    class FakeResult:
        returncode = 0

    def fake_run(argv, **_kwargs):
        captured_args.append(list(argv))
        return FakeResult()

    monkeypatch.setattr("atk.mcp_configure.subprocess.run", fake_run)

    # When
    code = run_claude_mcp_remove(plugin_name)

    # Then
    assert code == 0
    assert captured_args == [["claude", "mcp", "remove", "--scope", "user", plugin_name]]


def test_run_auggie_mcp_remove_calls_correct_argv(monkeypatch) -> None:
    """run_auggie_mcp_remove invokes 'auggie mcp remove <name>'."""
    # Given
    plugin_name = "my-plugin"
    captured_args: list[list[str]] = []

    class FakeResult:
        returncode = 0

    def fake_run(argv, **_kwargs):
        captured_args.append(list(argv))
        return FakeResult()

    monkeypatch.setattr("atk.mcp_configure.subprocess.run", fake_run)

    # When
    code = run_auggie_mcp_remove(plugin_name)

    # Then
    assert code == 0
    assert captured_args == [["auggie", "mcp", "remove", plugin_name]]


# ---------------------------------------------------------------------------
# build_gemini_mcp_config — unit tests
# ---------------------------------------------------------------------------

def test_build_gemini_mcp_config_stdio_minimal(tmp_path: Path) -> None:
    """Minimal stdio: argv has correct shape with name and command."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    plugin = _make_stdio_plugin(name=plugin_name, command=command)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_gemini_mcp_config(mcp_config)

    # Then
    assert result.argv == ["gemini", "mcp", "add", "--scope", "user", plugin_name, command]


def test_build_gemini_mcp_config_stdio_with_args(tmp_path: Path) -> None:
    """Stdio plugin with args: all args appended positionally after command."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    plugin_args = ["run", "--directory", "/some/path", "server.py"]
    plugin = _make_stdio_plugin(name=plugin_name, command=command, args=plugin_args)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_gemini_mcp_config(mcp_config)

    # Then
    assert result.argv == [
        "gemini", "mcp", "add", "--scope", "user",
        plugin_name, command, *plugin_args,
    ]


def test_build_gemini_mcp_config_stdio_with_env_vars(tmp_path: Path) -> None:
    """Set env vars each become a separate -e KEY=VAL flag."""
    # Given
    plugin_name = "my-plugin"
    command = "uv"
    var_name = "API_KEY"
    var_value = "secret-123"
    plugin = _make_stdio_plugin(name=plugin_name, command=command, mcp_env=[var_name])
    plugin_dir = tmp_path / "plugin"
    _write_env_file(plugin_dir, {var_name: var_value})
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_gemini_mcp_config(mcp_config)

    # Then
    assert result.argv == [
        "gemini", "mcp", "add", "--scope", "user",
        "-e", f"{var_name}={var_value}",
        plugin_name, command,
    ]


def test_build_gemini_mcp_config_sse(tmp_path: Path) -> None:
    """SSE plugin: --transport sse inserted and URL placed as positional."""
    # Given
    plugin_name = "my-plugin"
    endpoint = "http://localhost:8080/mcp"
    plugin = _make_sse_plugin(name=plugin_name, endpoint=endpoint)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_gemini_mcp_config(mcp_config)

    # Then
    assert result.argv == [
        "gemini", "mcp", "add", "--transport", "sse", "--scope", "user",
        plugin_name, endpoint,
    ]


def test_build_gemini_mcp_config_scope_defaults_to_user(tmp_path: Path) -> None:
    """Default scope is 'project' — --scope project always present when no scope given."""
    # Given
    plugin_name = "my-plugin"
    plugin = _make_stdio_plugin(name=plugin_name)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_gemini_mcp_config(mcp_config)

    # Then
    scope_index = result.argv.index("--scope")
    assert result.argv[scope_index + 1] == "user"


def test_build_gemini_mcp_config_custom_scope(tmp_path: Path) -> None:
    """Passing scope='user' produces --scope user in the argv."""
    # Given
    plugin_name = "my-plugin"
    custom_scope = "user"
    plugin = _make_stdio_plugin(name=plugin_name)
    plugin_dir = tmp_path / "plugin"
    plugin_dir.mkdir()
    mcp_config = generate_mcp_config(plugin, plugin_dir, plugin_name)

    # When
    result = build_gemini_mcp_config(mcp_config, scope=custom_scope)

    # Then
    scope_index = result.argv.index("--scope")
    assert result.argv[scope_index + 1] == custom_scope


