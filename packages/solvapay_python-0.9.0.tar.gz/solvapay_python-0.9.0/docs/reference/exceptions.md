# Exceptions Reference

::: solvapay.exceptions
