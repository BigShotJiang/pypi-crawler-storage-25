# hojo-asr

HOJO ASR inference library

The bundled WeNet-derived code lives under `hojo_asr.wenet` (not the top-level
`wenet` package) to avoid import conflicts with the official WeNet project.

## Installation

```bash
pip install hojo-asr
```

Install from source for development:

```bash
cd inference/hojo_asr
pip install -e .
```

## Quick start

```python
from hojo_asr import HOJO_ASR

model = HOJO_ASR.load_model("/path/to/model_folder", device="cuda:0")
results = model.run_infer(["/path/to/audio.wav"], batch_size=1)

for item in results:
    print(item["key"], item["text"])
```

The model folder should contain:

- `merged_full_model.safetensors`
- `config.yaml`
- Subdirectories referenced in `config.yaml`

## Publish to PyPI

```bash
cd inference/hojo_asr
python -m pip install build twine
python -m build
twine upload dist/*
```

## Third-party notices

This package includes a trimmed subset of [WeNet](https://github.com/wenet-e2e/wenet)
(Apache License 2.0). Some modules are also derived from
[ESPnet](https://github.com/espnet/espnet) (Apache License 2.0).

See [NOTICE](NOTICE) for attribution and a summary of modifications to the
bundled code under `hojo_asr.wenet`. This package is **not** the official
WeNet distribution and does not install a top-level `wenet` module.

## License

Copyright 2026 HojoAI.

Licensed under the Apache License, Version 2.0. See [LICENSE](LICENSE) and
[NOTICE](NOTICE) for details.
