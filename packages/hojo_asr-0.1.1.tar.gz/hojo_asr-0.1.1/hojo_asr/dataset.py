#
# Copyright 2026 HojoAI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""Inference datapipes: wav path lists or scp (utterance_id<TAB>path)."""

import io
import os
import soundfile as sf
import numpy as np
from functools import partial
from typing import List, Optional, Tuple, Union

import torch
import torchaudio
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import IterDataPipe
from transformers import WhisperFeatureExtractor


def padding_for_batch(samples: List[dict]) -> dict:
    """Sort a micro-batch by frame length (descending), pad feats, for `prepare_sample`.

    Args:
        samples: List of dicts with ``key`` and ``feat``; ``feat`` has shape (T, F).

    Returns:
        Batch dict with ``id``, ``spectrogram``, ``spectrogram_lens``, and
        ``original_index`` (position ``j`` in the sorted batch maps to input
        sample ``original_index[j]``).
    """
    assert isinstance(samples, list)
    feat_lengths = torch.tensor(
        [x["feat"].size(0) for x in samples], dtype=torch.int32
    )
    order = torch.argsort(feat_lengths, descending=True)
    lengths = torch.tensor(
        [samples[i]["feat"].size(0) for i in order], dtype=torch.int64
    )
    feats_sorted = [samples[i]["feat"] for i in order]
    keys_sorted = [samples[i]["key"] for i in order]
    original_index = order.tolist()
    padded = pad_sequence(feats_sorted, batch_first=True, padding_value=0)
    return {
        "id": keys_sorted,
        "spectrogram": padded,
        "spectrogram_lens": lengths,
        "original_index": original_index,
    }


def _load_wav_path_to_sample(
    wav_path: str,
    utterance_id: str,
    feat_extractor: WhisperFeatureExtractor,
    sample_rate: int,
    max_audio_len: int,
    min_audio_len: int,
) -> Optional[dict]:
    """Load one wav, extract Whisper features; drop if length not in [min, max] (frame scale)."""
    with open(wav_path, "rb") as f:
        wav_bytes = f.read()
    with io.BytesIO(wav_bytes) as buf:
        waveform, sr = torchaudio.load(buf)
    if waveform.size(0) != 1:
        waveform = waveform[0:1, :]
    num_frames = waveform.size(1) / sr * 100
    if num_frames < min_audio_len or num_frames > max_audio_len:
        return None
    if sr != sample_rate:
        waveform = torchaudio.transforms.Resample(
            orig_freq=sr, new_freq=sample_rate
        )(waveform)
        sr = sample_rate
    waveform = waveform.squeeze(0)
    feats = feat_extractor(
        waveform.numpy(),
        sampling_rate=sr,
        return_tensors="pt",
        padding=False,
    ).input_features
    feat = feats.squeeze(0).transpose(0, 1)
    return {"key": utterance_id, "feat": feat, "audio_path": wav_bytes}


def _load_wav_bytes_to_sample(
    wav_bytes: bytes,
    utterance_id: str,
    feat_extractor: WhisperFeatureExtractor,
    sample_rate: int,
    max_audio_len: int,
    min_audio_len: int,
) -> Optional[dict]:
    """Load audio FROM BYTES, extract Whisper features; drop if length not in [min, max]."""
    with io.BytesIO(wav_bytes) as buf:
        waveform, sr = torchaudio.load(buf)

    if waveform.size(0) != 1:
        waveform = waveform[0:1, :]
    num_frames = waveform.size(1) / sr * 100
    #if num_frames < min_audio_len or num_frames > max_audio_len:
    #    return None

    if sr != sample_rate:
        waveform = torchaudio.transforms.Resample(
            orig_freq=sr, new_freq=sample_rate
        )(waveform)

    waveform = waveform.squeeze(0)
    feats = feat_extractor(
        waveform.numpy(),
        sampling_rate=sample_rate,
        return_tensors="pt",
        padding=False,
    ).input_features
    feat = feats.squeeze(0).transpose(0, 1)
    return {"key": utterance_id, "feat": feat, "audio_path": wav_bytes}


def _first_meaningful_scp_line(scp_path: str) -> Optional[str]:
    """Return the first non-empty, non-comment line in an scp file; None if empty."""
    with open(scp_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            s = line.strip()
            if s and not s.startswith("#"):
                return s
    return None


def _is_tab_separated_id_path(line: str) -> bool:
    """True if the line looks like ``utterance_id<TAB>wav_path``."""
    if "\t" not in line:
        return False
    utt_id, path = line.split("\t", 1)
    return bool(utt_id.strip()) and bool(path.strip())


# Treat these extensions as audio files; do not sniff them as scp by first line alone.
_AUDIO_EXTENSIONS_EXCLUDED_FROM_SCP_SNIFF = (
    ".wav"
)


def is_scp_input(path: str) -> bool:
    """True if path is an existing scp list file (.scp suffix or first line id\\tpath)."""
    if not isinstance(path, str) or not os.path.isfile(path):
        return False
    lower = path.lower()
    if lower.endswith(".scp"):
        return True
    if lower.endswith(_AUDIO_EXTENSIONS_EXCLUDED_FROM_SCP_SNIFF):
        return False
    first = _first_meaningful_scp_line(path)
    return first is not None and _is_tab_separated_id_path(first)


def resolve_infer_audio_input(
    audio_input: Union[str, List[str]],
) -> Tuple[Union[str, List[str]], str]:
    """Resolve inference input: returns (wav path(s) or single scp path, ``'wav'`` | ``'scp'``)."""
    if isinstance(audio_input, str):
        if is_scp_input(audio_input):
            return audio_input, "scp"
        return audio_input, "wav"
    if isinstance(audio_input, (list, tuple)):
        if len(audio_input) > 0 and isinstance(audio_input[0], bytes):
            return audio_input, "bytes" 
        elif len(audio_input) > 0 and isinstance(audio_input[0], np.ndarray):
            return list(audio_input), "numpy"
        return list(audio_input), "wav"
    raise TypeError(
        "audio_input must be str (single wav or scp) or a list of wav paths"
    )


class WavListDatasetSource(IterDataPipe):
    """Iterate wav file paths in order; ``key`` is the basename without extension."""

    def __init__(
        self,
        audio_paths: Union[str, List[str]],
        feat_extractor: WhisperFeatureExtractor,
        sample_rate: int = 16000,
        max_audio_len: int = 30000,
        min_audio_len: int = 0,
    ) -> None:
        super().__init__()
        self.feat_extractor = feat_extractor
        self.audio_paths = (
            [audio_paths] if isinstance(audio_paths, str) else list(audio_paths)
        )
        self.sample_rate = sample_rate
        self.max_audio_len = max_audio_len
        self.min_audio_len = min_audio_len

    def __iter__(self):
        for path in self.audio_paths:
            utt_id = os.path.splitext(os.path.basename(path))[0]
            sample = _load_wav_path_to_sample(
                path,
                utt_id,
                self.feat_extractor,
                self.sample_rate,
                self.max_audio_len,
                self.min_audio_len,
            )
            if sample is not None:
                yield sample

    #def __len__(self) -> int:
    #    return len(self.audio_paths)


class ScpListDatasetSource(IterDataPipe):
    """Scp file: each line ``wav_id<TAB>wav_path``; ``key`` is wav_id."""

    def __init__(
        self,
        scp_path: str,
        feat_extractor: WhisperFeatureExtractor,
        sample_rate: int = 16000,
        max_audio_len: int = 30000,
        min_audio_len: int = 0,
    ) -> None:
        super().__init__()
        self.feat_extractor = feat_extractor
        self.sample_rate = sample_rate
        self.max_audio_len = max_audio_len
        self.min_audio_len = min_audio_len
        self.records: List[Tuple[str, str]] = []
        with open(scp_path, "r", encoding="utf-8", errors="replace") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "\t" not in line:
                    continue
                utt_id, wav_path = line.split("\t", 1)
                utt_id, wav_path = utt_id.strip(), wav_path.strip()
                if utt_id and wav_path:
                    self.records.append((utt_id, wav_path))

    def __iter__(self):
        for utt_id, wav_path in self.records:
            sample = _load_wav_path_to_sample(
                wav_path,
                utt_id,
                self.feat_extractor,
                self.sample_rate,
                self.max_audio_len,
                self.min_audio_len,
            )
            if sample is not None:
                yield sample


class AudioBytesDatasetSource(IterDataPipe):
    """Input: LIST OF AUDIO BYTES. No files needed."""
    def __init__(
        self,
        audio_bytes_list: List[bytes],
        feat_extractor: WhisperFeatureExtractor,
        sample_rate: int = 16000,
        max_audio_len: int = 30000,
        min_audio_len: int = 0,
    ) -> None:
        super().__init__()
        self.feat_extractor = feat_extractor
        self.bytes_list = audio_bytes_list
        self.sample_rate = sample_rate
        self.max_audio_len = max_audio_len
        self.min_audio_len = min_audio_len

    def __iter__(self):
        for idx, wav_bytes in enumerate(self.bytes_list):
            utt_id = f"sample_{idx}"
            sample = _load_wav_bytes_to_sample(
                wav_bytes,
                utt_id,
                self.feat_extractor,
                self.sample_rate,
                self.max_audio_len,
                self.min_audio_len,
            )
            #if sample is not None:
            yield sample

def numpy_list_to_bytes_list(numpy_list: list[np.ndarray], sr: int = 16000) -> list[bytes]:
    bytes_list = []
    for audio_np in numpy_list:
        buf = io.BytesIO()
        sf.write(buf, audio_np, sr, format='WAV', subtype='PCM_16')
        audio_bytes = buf.getvalue()
        bytes_list.append(audio_bytes)
        buf.close()
    return bytes_list


def infer_datapipe(
    audio_input: Union[str, List[str], List[np.ndarray]],
    feat_extractor: WhisperFeatureExtractor,
    batch_size: int = 1,
    num_workers: int = 0,
) -> Tuple[IterDataPipe, str]:
    """Pick ``WavListDatasetSource`` or ``ScpListDatasetSource`` from input, then batch.

    Returns (batched pipe, ``'wav'`` | ``'scp'``).
    """
    del num_workers
    paths_or_scp, kind = resolve_infer_audio_input(audio_input)
    if kind == "scp":
        src = ScpListDatasetSource(paths_or_scp, feat_extractor)
    elif kind == "bytes":
        src = AudioBytesDatasetSource(paths_or_scp, feat_extractor)
    elif kind == "numpy":
        bytes_list = numpy_list_to_bytes_list(paths_or_scp, sr=16000)
        src = AudioBytesDatasetSource(bytes_list, feat_extractor)
    else:
        src = WavListDatasetSource(paths_or_scp, feat_extractor)
    
    wrapper = partial(padding_for_batch)
    return src.batch(batch_size, wrapper_class=wrapper, drop_last=False), kind
