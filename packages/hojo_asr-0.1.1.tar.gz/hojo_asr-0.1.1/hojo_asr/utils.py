#
# Copyright 2026 HojoAI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import logging
import time

import torch
from torch.utils.data import DataLoader, DistributedSampler
from torch.nn.utils.rnn import pad_sequence
import soundfile as sf
import numpy as np

import torch.multiprocessing as mp
mp.set_start_method("spawn", force=True)


def now():
    from datetime import datetime
    return datetime.now().strftime("%Y%m%d%H%M")


def apply_to_sample(f, sample):
    if len(sample) == 0:
        return {}

    def _apply(x):
        if torch.is_tensor(x):
            return f(x)
        elif isinstance(x, dict):
            return {key: _apply(value) for key, value in x.items()}
        elif isinstance(x, list):
            return [_apply(x) for x in x]
        else:
            return x

    return _apply(sample)


def move_to_device(sample, device):
    def _move_to_device(tensor):
        return tensor.to(device)

    return apply_to_sample(_move_to_device, sample)


def move_to_cuda(sample):
    def _move_to_cuda(tensor):
        return tensor.cuda()

    return apply_to_sample(_move_to_cuda, sample)


def prepare_sample(samples, cuda_enabled=True, device=None):
    if cuda_enabled:
        if device is not None:
            samples = move_to_device(samples, device)
        else:
            samples = move_to_cuda(samples)

    return samples

def apply_to_sample_cudaid(f, sample, cudaid):
    if len(sample) == 0:
        return {}

    def _apply(x, cudaid):
        if torch.is_tensor(x):
            return f(x, cudaid)
        elif isinstance(x, dict):
            return {key: _apply(value, cudaid) for key, value in x.items()}
        elif isinstance(x, list):
            return [_apply(x, cudaid) for x in x]
        else:
            return x

    return _apply(sample, cudaid)


def move_to_cudaid(sample, cudaid):
    def _move_to_cudaid(tensor, cudaid):
        return tensor.cuda(cudaid)

    return apply_to_sample_cudaid(_move_to_cudaid, sample, cudaid)


def prepare_sample_cudaid(samples, cudaid, cuda_enabled=True):
    if cuda_enabled:
        samples = move_to_cudaid(samples, cudaid)

    # TODO fp16 support

    return samples

