"""WeNet-derived inference components for HOJO ASR (Conformer encoder).

This subpackage contains modified code from the WeNet project
(https://github.com/wenet-e2e/wenet), licensed under the Apache License 2.0.
It is vendored as `hojo_asr.wenet` to avoid conflicting with any separately
installed top-level `wenet` package. See NOTICE in the package root for details.
"""
