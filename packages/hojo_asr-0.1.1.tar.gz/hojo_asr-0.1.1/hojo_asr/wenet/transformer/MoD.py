# inspired by  https://github.com/kyegomez/Mixture-of-Depths
import torch
import torch.nn as nn
from torch.nn.utils.rnn import pad_sequence
from typing import Optional, Tuple, Any
import logging

from hojo_asr.wenet.utils.mask import make_pad_mask
# from https://github.com/astramind-ai/Mixture-of-depths/blob/main/MoD/MoD.py#L11
class TokenRouter(nn.Module):
    def __init__(self, embed_dim):
        super().__init__()
        self.weight_predictor = nn.Linear(embed_dim, 1)

    def forward(self, x):
        weights = self.weight_predictor(x).squeeze(
            -1
        )  # [batch_size, seq_len]
        return weights


class MoD(nn.Module):
    def __init__(self, capacity, block):
        super().__init__()
        self.router = TokenRouter(block.hidden_size)
        self.block = block
        self.capacity = capacity
        self.training_step = 0
        logging.info("capacity: {}".format(self.capacity))

    def forward(self,
                x: torch.Tensor,
                attention_mask: torch.Tensor,
                position_ids: torch.Tensor,
                past_key_value: Optional[Tuple[torch.Tensor, torch.Tensor]],
                output_attentions: bool = False,
                use_cache: bool = False,
                cache_position: Optional[torch.Tensor] = None,
                **kwargs: Any
               ) -> Tuple[torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]]:
        b, s, d = x.shape
        lengths = attention_mask.squeeze(1).sum(dim=-1)
        weights = self.router(x) #(b, s)
        if self.router.training:
            self.training_step += 1 if self.training_step < 1000 else 999
            self.capacity = self.capacity + ((1 - self.capacity) * (1. / self.training_step))

        k = int(self.capacity * s)
        top_k_values, _ = torch.topk(weights, k, dim=1, sorted=True)
        threshold = top_k_values[:, -1]
        selected_mask = weights > threshold.unsqueeze(-1) #(b, s)
        selected_length = selected_mask.sum(dim=-1)
        '''
        if not self.router.training:
            logging.info("speech length: {}, speech_length after selected: {}".format(lengths, selected_length))
        '''
        cache = None
        return_mask = attention_mask #(b, 1, s)
        processed_tokens = torch.zeros_like(x)
        selected_tokens_list = []
        masks_list = []
        device = weights.device
        for i in range(b):
            current_selected_mask = selected_mask[i] #(k)
            selected_tokens = x[i][current_selected_mask] #(k, d)
            selected_tokens_list.append(selected_tokens)
            current_causal_mask = attention_mask[i, 0]#(s)
            current_causal_mask = current_causal_mask[current_selected_mask]
            masks_list.append(current_causal_mask)
        padded_selected_tokens = pad_sequence(selected_tokens_list, batch_first=True, padding_value=0) #(b, K, d)

        lengths_after_selected = selected_mask.sum(dim=-1)
        K = padded_selected_tokens.size(1)
        masks = pad_sequence(masks_list, batch_first=True, padding_value=False).unsqueeze(1)
        encoder_out, _, _, _ = self.block(padded_selected_tokens, masks, position_ids)# (b, K, d)
        for i in range(b):
            new_weight = torch.zeros_like(encoder_out[i])
            if encoder_out[i].shape[0] != weights[i][selected_mask[i]].shape[0]:
                logging.info("encoder_out[i].shape: {}, weights[i][selected_mask[i]].shape: {}".format(encoder_out[i].shape, weights[i][selected_mask[i]].shape))
                t = encoder_out[i].shape[0] - weights[i][selected_mask[i]].shape[0]
                padding_tensor = torch.zeros(t, device=device)
                new_weight = torch.cat((weights[i][selected_mask[i]], padding_tensor)).unsqueeze(-1)
                logging.info("new_weight.shape: {}".format(new_weight.shape))
            else:
                new_weight = weights[i][selected_mask[i]].unsqueeze(-1)
            encoder_out[i] *=  new_weight
            actual_t = lengths_after_selected[i].item()
            processed_tokens[i][selected_mask[i]] = encoder_out[i][0:actual_t]
        output = processed_tokens + (x * (~selected_mask).unsqueeze(-1).to(x.dtype))
        return (output, attention_mask, _, _)

    def forward_deprecated(self,
    # def forward(self,
                x: torch.Tensor,
                attention_mask: torch.Tensor,
                position_ids: torch.Tensor,
                past_key_value: Optional[Tuple[torch.Tensor, torch.Tensor]],
                output_attentions: bool = False,
                use_cache: bool = False,
                cache_position: Optional[torch.Tensor] = None,
                **kwargs: Any
                ) -> Tuple[torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]]:
        b, s, d = x.shape
        lengths = attention_mask.squeeze(1).sum(dim=-1)
        # logging.info("lengths: {}".format(lengths))
        weights = self.router(x)
        if self.router.training:
            self.training_step += 1 if self.training_step < 1000 else 999
            self.capacity = self.capacity + ((1 - self.capacity) * (1. / self.training_step))

        k = int(self.capacity * s)
        # logging.info("k: {}, capacity: {}".format(k, self.capacity))
        top_k_values, _ = torch.topk(weights, k, dim=1, sorted=True)
        # logging.info("top_k_values.shape: {}".format(top_k_values.shape))
        threshold = top_k_values[:, -1]
        selected_mask = weights > threshold.unsqueeze(-1) #(b, s)
        cache = None
        return_mask = attention_mask #(b, 1, s)

        processed_tokens = torch.zeros_like(x)
        for i in range(b):
            current_selected_mask = selected_mask[i] #(k)
            selected_tokens = x[i][current_selected_mask] #(k, d)
            selected_position_ids = position_ids[0][current_selected_mask].unsqueeze(0)
            #selected_position_ids = position_ids[i][current_selected_mask].unsqueeze(0)
            #logging.info("position_ids.shape: {}".format(position_ids.shape))
            if attention_mask is not None:
                current_causal_mask = attention_mask[i, 0]#(s)
                # logging.info("x.shape: {}, current_selected_mask.shape: {}, attention_mask.shape: {}, selected_mask.shape: {}, current_causal_mask.shape: {}".format(x.shape, current_selected_mask.shape, attention_mask.shape, selected_mask.shape, current_causal_mask.shape))
                # logging.info("current_causal_mask: {}, current_selected_mask: {}".format(current_causal_mask, current_selected_mask))
                current_causal_mask = current_causal_mask[current_selected_mask].unsqueeze(0).unsqueeze(0) #first if for the one second is for the bs
                # logging.info("current_causal_mask: {}".format(current_causal_mask))
                #current_causal_mask = current_causal_mask[current_selected_mask][:, current_selected_mask].unsqueeze(0).unsqueeze(0) #first if for the one second is for the bs
            else:
                current_causal_mask = None

            if selected_tokens.size(0) > 0:
                # Dynamic cache management
                if cache_position is not None:
                    selected_cache_position = cache_position[selected_mask[i]]
                    block_output = self.block(
                        selected_tokens.unsqueeze(0),
                        attention_mask=current_causal_mask,
                        position_ids=selected_position_ids,
                        past_key_value=past_key_value,
                        output_attentions=output_attentions,
                        use_cache=use_cache,
                        cache_position=selected_cache_position,
                        **kwargs
                    )
                    if len(block_output) == 2:
                        processed_tokens[i][selected_mask[i]], cache = block_output
                    else:
                        processed_tokens[i][selected_mask[i]] = block_output[0]
                    processed_tokens[i][selected_mask[i]] = processed_tokens[i][selected_mask[i]] * weights[i][selected_mask[i]].unsqueeze(-1)
                else:
                    # logging.info("x.shape: {}, sele_tokens.shape: {}, current_causal_mask.shape: {}, selec_pos_ids.shape: {}".format(x.shape, selected_tokens.shape, current_causal_mask.shape, selected_position_ids.shape))
                    encoder_out, _, _, _ = self.block(
                        selected_tokens.unsqueeze(0),
                        mask=current_causal_mask,
                        pos_emb=selected_position_ids,
                    )
                    
                    processed_tokens[i][selected_mask[i]] = encoder_out
                    processed_tokens[i][selected_mask[i]] *= weights[i][selected_mask[i]].unsqueeze(-1)
                    """
                    processed_tokens[i][selected_mask[i]] = self.block(
                        selected_tokens.unsqueeze(0),
                        mask=current_causal_mask,
                        pos_emb=selected_position_ids,
                    )[0] * weights[i][selected_mask[i]].unsqueeze(-1)"""


        output = processed_tokens + (x * (~selected_mask).unsqueeze(-1).to(x.dtype))
        return (output, cache) if cache is not None else (output, attention_mask, _, _)
