"""VoxKitchen quality operators."""
