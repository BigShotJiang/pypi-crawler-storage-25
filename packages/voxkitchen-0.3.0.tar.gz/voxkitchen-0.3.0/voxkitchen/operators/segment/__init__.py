"""VoxKitchen segmentation operators."""
