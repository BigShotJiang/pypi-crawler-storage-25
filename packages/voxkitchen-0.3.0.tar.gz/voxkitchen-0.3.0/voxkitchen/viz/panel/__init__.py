"""Gradio interactive panel."""
