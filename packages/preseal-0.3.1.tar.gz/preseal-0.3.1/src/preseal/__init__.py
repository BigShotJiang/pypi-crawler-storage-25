"""Preseal — Pre-deployment security testing for AI agents."""

__version__ = "0.3.1"
