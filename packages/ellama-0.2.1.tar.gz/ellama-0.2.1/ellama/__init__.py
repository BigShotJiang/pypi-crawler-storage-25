"""Embeddings using Ollama + FAISS + Langchain.

config env var defaults:
- OLLAMA_BASE_URL=http://localhost:11434
- OLLAMA_MODEL=all-minilm (see <https://ollama.com/search?c=embedding>)
- CACHE_ROOT=.cache
"""
import functools
import logging
import os
import pickle
from contextlib import contextmanager
from pathlib import Path, PurePath
from shutil import rmtree

from tqdm import tqdm

os.environ['LIBGL_DEBUG'] = "quiet" # suppres FAISS libGL missing drirc file warnings

from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_community.vectorstores import FAISS
from langchain_community.vectorstores.faiss import dependable_faiss_import
from langchain_core.documents import Document
from langchain_ollama import OllamaEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

__all__ = ['EllamaDB']
log = logging.getLogger(__name__)
faiss = dependable_faiss_import()
BASE_URL = os.getenv('OLLAMA_BASE_URL', "http://localhost:11434")
MODEL = os.getenv('OLLAMA_MODEL', 'all-minilm')
CACHE_ROOT = Path(os.getenv('CACHE_ROOT', ".cache"))


@contextmanager
def log_level(logger_name: str, level: int | str):
    logger = logging.getLogger(logger_name)
    old = logger.level
    logger.setLevel(level)
    try:
        yield
    finally:
        logger.setLevel(old)


def mean(vectors: list[list[float]]) -> list[float]:
    """`numpy.mean(vectors, axis=0).tolist()`"""
    N, D = len(vectors), len(vectors[0])
    return [sum(v[i] for v in vectors) / N for i in range(D)]


class EllamaEmbeddings(OllamaEmbeddings):
    def __init__(self, *args, chars_per_token: float = 4, **kwargs):
        super().__init__(*args, **kwargs)
        self._chars_per_token = chars_per_token
        with tqdm(desc=f"pulling {self.model}") as t:
            for i in self._client.pull(self.model, stream=True):
                t.total = i.total
                if i.completed:
                    t.update(i.completed - t.n)
        info = self._client.show(self.model).modelinfo
        self._ndim = next(v for k, v in info.items() if k.endswith('embedding_length'))
        self.num_ctx = next(v for k, v in info.items() if k.endswith('context_length'))

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [
            mean([
                super().embed_documents([chunk])[0] for chunk in RecursiveCharacterTextSplitter(
                    chunk_size=int(self.num_ctx *
                                   self._chars_per_token)).split_text(text)]) if len(text) > self.num_ctx *
            self._chars_per_token else super().embed_documents([text])[0] for text in texts]


@functools.cache
def get_embedder(model, base_url, **kwargs):
    return EllamaEmbeddings(model=model, base_url=base_url, **kwargs)


class EllamaDB(FAISS):
    def __init__(self, name: str, model: str = MODEL, base_url: str = BASE_URL, cache_root: PurePath = CACHE_ROOT,
                 **ollama_kwargs):
        self.db_path = db_path = Path(cache_root) / name
        embedder = get_embedder(model, base_url, **ollama_kwargs)
        if (db_path / "index.faiss").exists():
            # super().load_local(db_path, embedder, allow_dangerous_deserialization=True)
            index = faiss.read_index(str(db_path / "index.faiss"))
            with (db_path / "index.pkl").open("rb") as f:
                docstore, index_to_docstore_id = pickle.load(f)
            super().__init__(embedder, index, docstore, index_to_docstore_id)
        else:
            rmtree(db_path, ignore_errors=True)
            super().__init__(embedder, faiss.IndexFlatL2(embedder._ndim), InMemoryDocstore(), {})

    def save_local(self):
        super().save_local(str(self.db_path))

    def add_documents(self, docs: list[Document], save_local=True):
        with log_level('httpx', logging.WARNING):
            for doc in tqdm(docs, desc=f"{self.db_path.name}:indexing", unit="doc"):
                if (old := self.get_by_ids([doc.id])) != [doc]:
                    if old:
                        log.debug("updating:%r", doc.id)
                        self.delete([doc.id])
                    log.debug("adding:%r", doc.id)
                    super().add_documents([doc])
        if save_local:
            self.save_local()

    def similarity_search_with_relevance_scores(self, query: str, k: int = 4, **kwargs) -> list[Document]:
        """k: max documents returned by vector search"""
        from warnings import catch_warnings, filterwarnings
        with catch_warnings():
            filterwarnings(action="ignore", message="Relevance scores must be between 0 and 1", category=UserWarning)
            with log_level('httpx', logging.WARNING):
                scores = super().similarity_search_with_relevance_scores(query, k=k, **kwargs)
        # log.debug("similarity_search_with_relevance_scores:%r", {doc.metadata['title']: score for doc, score in scores})
        return [doc for doc, score in scores if score > 0]

    def similarity_search_with_relevance_scores_by_id(self, id: str, **kwargs) -> list[tuple[Document, float]]:
        index_id = next(i for i, j in self.index_to_docstore_id.items() if j == id)
        ntotal, d = self.index.ntotal, self.index.d
        embedding = faiss.rev_swig_ptr(self.index.get_xb(), ntotal * d).reshape(ntotal, d)[index_id]
        relevance_score_fn = self._select_relevance_score_fn()
        k = len(self.index_to_docstore_id)
        return [(doc, relevance_score_fn(score))
                for doc, score in self.similarity_search_with_score_by_vector(embedding, k=k, fetch_k=k, **kwargs)]

    def get_docs(self, filter: dict[str]) -> list[Document]:
        filter_func = self._create_filter_func(filter)
        return [doc for doc in self.get_by_ids(self.index_to_docstore_id.values()) if filter_func(doc.metadata)]
