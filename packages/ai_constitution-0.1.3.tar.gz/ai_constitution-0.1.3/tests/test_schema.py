"""Tests for the org-config schema (RAJ-58)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from ai_constitution.schema import (
    KNOWN_MINISTERS,
    MANDATORY_SHERPAS,
    OrgConfig,
    json_schema,
    load_org_config,
)


# ────────────────────────────────────────────────────────────
# Defaults — empty {} should give a coherent default org.
# ────────────────────────────────────────────────────────────


def test_empty_config_uses_defaults() -> None:
    cfg = OrgConfig.model_validate({})
    assert cfg.org.name == "Your Org"
    assert cfg.org.timezone == "UTC"
    assert cfg.org.pm.title == "Prime Minister"
    assert cfg.org.agent.name == "Secretary"
    assert cfg.org.agent.persona.tone == "Sharp, composed, efficient"
    assert set(cfg.org.ministries.enabled) == set(KNOWN_MINISTERS)
    assert set(cfg.org.sherpas.enabled) >= set(MANDATORY_SHERPAS)
    assert cfg.org.protocols.enabled == ["00", "12"]


def test_partial_override_only_touches_named_fields() -> None:
    cfg = OrgConfig.model_validate({"org": {"name": "Acme", "agent": {"name": "Friday"}}})
    assert cfg.org.name == "Acme"
    assert cfg.org.agent.name == "Friday"
    # Untouched defaults stay intact.
    assert cfg.org.agent.title == "Principal Secretary"
    assert cfg.org.timezone == "UTC"


# ────────────────────────────────────────────────────────────
# Strictness — typos surface as errors.
# ────────────────────────────────────────────────────────────


def test_unknown_field_at_root_rejected() -> None:
    with pytest.raises(ValidationError) as exc:
        OrgConfig.model_validate({"org": {"naem": "Acme"}})  # typo
    assert "naem" in str(exc.value)


def test_unknown_minister_rejected() -> None:
    with pytest.raises(ValidationError) as exc:
        OrgConfig.model_validate({"org": {"ministries": {"enabled": ["legal"]}}})
    assert "legal" in str(exc.value)


def test_unknown_sherpa_rejected() -> None:
    with pytest.raises(ValidationError) as exc:
        OrgConfig.model_validate({"org": {"sherpas": {"enabled": ["typo"]}}})
    assert "typo" in str(exc.value)


def test_unknown_protocol_rejected() -> None:
    with pytest.raises(ValidationError) as exc:
        OrgConfig.model_validate({"org": {"protocols": {"enabled": ["99"]}}})
    assert "99" in str(exc.value)


def test_mandatory_sherpas_always_present_even_when_omitted() -> None:
    # User explicitly enables only `scrum`; mandatories still get added.
    cfg = OrgConfig.model_validate({"org": {"sherpas": {"enabled": ["scrum"]}}})
    for m in MANDATORY_SHERPAS:
        assert m in cfg.org.sherpas.enabled
    assert "scrum" in cfg.org.sherpas.enabled


# ────────────────────────────────────────────────────────────
# Slug rule.
# ────────────────────────────────────────────────────────────


@pytest.mark.parametrize("good", ["acme", "raj-sadan", "x", "a1-b2-c3"])
def test_slug_accepted(good: str) -> None:
    cfg = OrgConfig.model_validate({"org": {"slug": good}})
    assert cfg.org.slug == good


@pytest.mark.parametrize("bad", ["Acme", "raj_sadan", "-leading", "trailing-", "has space"])
def test_slug_rejected(bad: str) -> None:
    with pytest.raises(ValidationError):
        OrgConfig.model_validate({"org": {"slug": bad}})


# ────────────────────────────────────────────────────────────
# JSON Schema export shape.
# ────────────────────────────────────────────────────────────


def test_json_schema_has_org_root() -> None:
    s = json_schema()
    assert "$defs" in s or "definitions" in s or "properties" in s
    assert "org" in s["properties"]


# ────────────────────────────────────────────────────────────
# Loader integration — round-trip a tiny TOML.
# ────────────────────────────────────────────────────────────


def test_load_org_config_round_trip(tmp_path: Path) -> None:
    cfg_text = """
[org]
name = "Acme"
slug = "acme"
timezone = "Europe/Madrid"

[org.pm]
name = "Vishal"
title = "Founder"

[org.agent]
name = "Friday"
emoji = "🤖"

[org.ministries]
enabled = ["planning", "review"]

[org.protocols]
enabled = ["00", "12", "11"]
"""
    p = tmp_path / "org-config.toml"
    p.write_text(cfg_text, encoding="utf-8")

    cfg = load_org_config(str(p))
    assert cfg.org.name == "Acme"
    assert cfg.org.slug == "acme"
    assert cfg.org.timezone == "Europe/Madrid"
    assert cfg.org.pm.title == "Founder"
    assert cfg.org.agent.name == "Friday"
    assert cfg.org.ministries.enabled == ["planning", "review"]
    assert "11" in cfg.org.protocols.enabled
    # Mandatory sherpas auto-added.
    for m in MANDATORY_SHERPAS:
        assert m in cfg.org.sherpas.enabled
