"""Smoke tests for the bundled templates (RAJ-51..55).

Verifies:
* Every shipped .j2 file parses as valid Jinja2 syntax (no template errors).
* Rendering against just defaults.toml succeeds for the whole bundle.
* Rendering against a raj-sadan-shaped org-config succeeds and produces
  files containing the expected substituted strings.
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from ai_constitution.render import (
    BUILTIN_DEFAULTS_PATH,
    BUILTIN_SKILLS_DIR,
    BUILTIN_TEMPLATES_DIR,
    Constitution,
)


_RAJ_SADAN_CONFIG = textwrap.dedent(
    """
    [org]
    name     = "Raj Sadan"
    slug     = "raj-sadan"
    timezone = "Asia/Kolkata"

    [org.pm]
    name     = "Vishal"
    title    = "Prime Minister"
    pronouns = "he/him"

    [org.agent]
    name       = "Mr. V"
    title      = "Principal Secretary"
    emoji      = "🏛️"

    [org.agent.persona]
    tone     = "Sharp, composed, efficient"
    keywords = ["architect", "orchestrator"]

    [org.protocols]
    enabled = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
    """,
).strip()


# Skip the whole module if templates haven't been generated yet (clean clone
# without running tools/convert_from_raj_sadan.py first).
pytestmark = pytest.mark.skipif(
    not (BUILTIN_TEMPLATES_DIR / "CONSTITUTION.toml.j2").exists(),
    reason="templates not generated — run tools/convert_from_raj_sadan.py first",
)


def test_templates_present() -> None:
    """All 24 expected output paths exist."""
    expected = [
        "CONSTITUTION.toml.j2",
        "AGENT.toml.j2",
        "IDENTITY.toml.j2",
        "PRINCIPAL.toml.j2",
        "CLAUDE.md.j2",
        "boot-prompt.md.j2",
    ]
    for name in expected:
        assert (BUILTIN_TEMPLATES_DIR / name).is_file(), f"missing template: {name}"

    for i in range(13):
        path = BUILTIN_TEMPLATES_DIR / "protocols" / f"PROTOCOL-{i:02d}.toml.j2"
        assert path.is_file(), f"missing protocol template: {path}"

    for cmd in ["amend", "boot", "checkpoint", "delegate", "reboot"]:
        path = BUILTIN_SKILLS_DIR / cmd / "SKILL.md.j2"
        assert path.is_file(), f"missing skill template: {path}"


def test_render_with_defaults_only(tmp_path: Path) -> None:
    """Whole bundle must render against just defaults.toml without errors."""
    c = Constitution.load()
    rendered = c.render(tmp_path / "out")
    assert len(rendered) >= 24
    by_path = {f.relative_path for f in rendered}
    assert "CONSTITUTION.toml" in by_path
    assert "PRINCIPAL.toml" in by_path
    assert "skills/amend/SKILL.md" in by_path
    assert "protocols/PROTOCOL-00.toml" in by_path


def test_render_with_raj_sadan_config_substitutes(tmp_path: Path) -> None:
    """raj-sadan config produces files containing 'Mr. V', 'Raj Sadan', 'Vishal'."""
    cfg_path = tmp_path / "org-config.toml"
    cfg_path.write_text(_RAJ_SADAN_CONFIG, encoding="utf-8")

    c = Constitution.load(org_config_path=cfg_path)
    rendered = {f.relative_path: f.content for f in c.render(tmp_path / "out")}

    constitution = rendered["CONSTITUTION.toml"]
    assert "Raj Sadan" in constitution
    assert "Mr. V" in constitution
    assert "Vishal" in constitution
    assert "Principal Secretary" in constitution
    # No raw template syntax left behind.
    assert "{{" not in constitution
    assert "}}" not in constitution


def test_no_template_renders_to_empty_file() -> None:
    """Defensive: every rendered file has at least some content."""
    c = Constitution.load()
    rendered = c.render_all()
    for f in rendered:
        assert f.content.strip(), f"empty render: {f.relative_path}"
