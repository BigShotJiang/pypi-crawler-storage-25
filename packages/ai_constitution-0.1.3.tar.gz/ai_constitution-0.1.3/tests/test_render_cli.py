"""Tests for the `render` CLI command (RAJ-59)."""

from __future__ import annotations

import subprocess
import sys
import textwrap
from pathlib import Path


def _run(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "ai_constitution", *args],
        capture_output=True,
        text=True,
    )


def _make_repo(tmp_path: Path) -> tuple[Path, Path]:
    """Build a minimal templates/ + defaults.toml outside the package."""
    templates = tmp_path / "templates"
    templates.mkdir()
    (templates / "IDENTITY.toml.j2").write_text(
        '[identity]\nname = "{{ org.agent.name }}"\n',
        encoding="utf-8",
    )

    defaults = tmp_path / "defaults.toml"
    defaults.write_text(
        textwrap.dedent(
            """
            [org]
            name = "Your Org"
            timezone = "UTC"

            [org.agent]
            name = "Secretary"
            """,
        ).strip(),
        encoding="utf-8",
    )
    return templates, defaults


def test_render_writes_files(tmp_path: Path) -> None:
    templates, defaults = _make_repo(tmp_path)
    out_dir = tmp_path / "out"

    result = _run(
        "render",
        "--templates",
        str(templates),
        "--defaults",
        str(defaults),
        "--output",
        str(out_dir),
    )
    assert result.returncode == 0, result.stderr
    assert "rendered" in result.stdout
    rendered_id = (out_dir / "IDENTITY.toml").read_text(encoding="utf-8")
    assert 'name = "Secretary"' in rendered_id


def test_render_diff_no_changes(tmp_path: Path) -> None:
    templates, defaults = _make_repo(tmp_path)
    out_dir = tmp_path / "out"

    # First write.
    _run(
        "render",
        "--templates",
        str(templates),
        "--defaults",
        str(defaults),
        "--output",
        str(out_dir),
    )
    # Then diff — should report no changes.
    result = _run(
        "render",
        "--templates",
        str(templates),
        "--defaults",
        str(defaults),
        "--output",
        str(out_dir),
        "--diff",
    )
    assert result.returncode == 0, result.stderr
    assert "no changes" in result.stdout


def test_render_with_config_override(tmp_path: Path) -> None:
    templates, defaults = _make_repo(tmp_path)
    cfg = tmp_path / "org-config.toml"
    cfg.write_text(
        '[org.agent]\nname = "Friday"\n',
        encoding="utf-8",
    )
    out_dir = tmp_path / "out"

    result = _run(
        "render",
        "--templates",
        str(templates),
        "--defaults",
        str(defaults),
        "--config",
        str(cfg),
        "--output",
        str(out_dir),
    )
    assert result.returncode == 0, result.stderr
    assert 'name = "Friday"' in (out_dir / "IDENTITY.toml").read_text(encoding="utf-8")


def test_render_missing_templates_dir_exits_2(tmp_path: Path) -> None:
    _, defaults = _make_repo(tmp_path)
    result = _run(
        "render",
        "--templates",
        str(tmp_path / "nope"),
        "--defaults",
        str(defaults),
        "--output",
        str(tmp_path / "out"),
    )
    assert result.returncode == 2
    assert "templates_dir" in result.stderr


def test_render_invalid_config_exits_1(tmp_path: Path) -> None:
    templates, defaults = _make_repo(tmp_path)
    cfg = tmp_path / "org-config.toml"
    cfg.write_text(
        "[org]\nbogus = 'value'\n",
        encoding="utf-8",
    )
    result = _run(
        "render",
        "--templates",
        str(templates),
        "--defaults",
        str(defaults),
        "--config",
        str(cfg),
        "--output",
        str(tmp_path / "out"),
    )
    assert result.returncode == 1
    assert "bogus" in result.stderr
