"""Smoke tests proving the v0.0.1 scaffold is importable and the CLI runs.

These tests stay green throughout M2 as the package fills out.
"""

from __future__ import annotations

import subprocess
import sys


def test_package_imports() -> None:
    import ai_constitution

    assert ai_constitution.__version__ == "0.1.2"


def test_cli_version() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "ai_constitution", "--version"],
        capture_output=True,
        text=True,
        check=True,
    )
    assert "0.1.2" in result.stdout


def test_cli_help() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "ai_constitution", "--help"],
        capture_output=True,
        text=True,
        check=True,
    )
    assert "ai-constitution" in result.stdout
    assert "render" in result.stdout
    assert "validate" in result.stdout
