"""Tests for defaults.toml — the framework-level baseline (RAJ-56).

The contract: rendering against defaults.toml alone (no overrides) must produce
a coherent "Your Org" agent stack. Loading defaults.toml must agree with the
Pydantic-default OrgConfig.
"""

from __future__ import annotations

from pathlib import Path

from ai_constitution.schema import (
    KNOWN_MINISTERS,
    MANDATORY_SHERPAS,
    OrgConfig,
    load_org_config,
)

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULTS_PATH = REPO_ROOT / "defaults.toml"


def test_defaults_file_exists() -> None:
    assert DEFAULTS_PATH.is_file(), f"missing defaults.toml at {DEFAULTS_PATH}"


def test_defaults_validates_against_schema() -> None:
    """defaults.toml must parse and validate cleanly."""
    cfg = load_org_config(str(DEFAULTS_PATH))
    assert isinstance(cfg, OrgConfig)


def test_defaults_match_pydantic_defaults() -> None:
    """Loading defaults.toml should give the same shape as OrgConfig()."""
    from_file = load_org_config(str(DEFAULTS_PATH)).model_dump(mode="json")
    from_pydantic = OrgConfig().model_dump(mode="json")
    # Service ports differ: schema models them as None; TOML uses 0 to signal
    # "not configured" (TOML has no native null). Normalize both for comparison.
    for svc in ("cron", "whatsapp", "dashboard", "knowledge"):
        if from_file["org"]["services"][svc].get("port") == 0:
            from_file["org"]["services"][svc]["port"] = None
        if from_file["org"]["services"][svc].get("host") == "":
            from_file["org"]["services"][svc]["host"] = None
    assert from_file == from_pydantic, (
        "defaults.toml drifted from Pydantic defaults — pick one as source of "
        "truth and update the other."
    )


def test_defaults_have_every_registry_section() -> None:
    """Every section in the RAJ-50 registry has an entry."""
    cfg = load_org_config(str(DEFAULTS_PATH))
    assert cfg.org.name == "Your Org"
    assert cfg.org.timezone == "UTC"
    assert cfg.org.pm.title == "Prime Minister"
    assert cfg.org.agent.name == "Secretary"
    assert cfg.org.agent.emoji == "🏛️"
    assert cfg.org.agent.persona.tone == "Sharp, composed, efficient"
    assert set(cfg.org.ministries.enabled) == set(KNOWN_MINISTERS)
    assert set(cfg.org.sherpas.enabled) >= set(MANDATORY_SHERPAS)
    assert cfg.org.protocols.enabled == ["00", "12"]
    assert cfg.org.llm.local.host == "http://localhost:11434"
