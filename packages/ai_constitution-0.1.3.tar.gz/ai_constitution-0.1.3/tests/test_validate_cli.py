"""Tests for the `validate` and `schema` CLI commands (RAJ-58)."""

from __future__ import annotations

import json
import subprocess
import sys
import textwrap
from pathlib import Path


def _run(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "ai_constitution", *args],
        capture_output=True,
        text=True,
        cwd=cwd,
    )


def test_validate_passes_on_valid_config(tmp_path: Path) -> None:
    cfg = tmp_path / "org-config.toml"
    cfg.write_text(
        textwrap.dedent(
            """
            [org]
            name = "Acme"

            [org.pm]
            name = "Test User"

            [org.agent]
            name = "Friday"
            """,
        ).strip(),
        encoding="utf-8",
    )
    result = _run("validate", "--config", str(cfg))
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_validate_fails_on_unknown_field(tmp_path: Path) -> None:
    cfg = tmp_path / "org-config.toml"
    cfg.write_text(
        textwrap.dedent(
            """
            [org]
            naem = "Acme"  # typo
            """,
        ).strip(),
        encoding="utf-8",
    )
    result = _run("validate", "--config", str(cfg))
    assert result.returncode == 1
    assert "naem" in result.stderr


def test_validate_missing_file_exits_2() -> None:
    result = _run("validate", "--config", "/nonexistent/path.toml")
    assert result.returncode == 2
    assert "not found" in result.stderr


def test_validate_show_dumps_config(tmp_path: Path) -> None:
    cfg = tmp_path / "org-config.toml"
    cfg.write_text('[org]\nname = "Acme"\n', encoding="utf-8")
    result = _run("validate", "--config", str(cfg), "--show")
    assert result.returncode == 0, result.stderr
    # The --show output is JSON appended after the "ok" line.
    body = result.stdout.split("\n", 1)[1]
    parsed = json.loads(body)
    assert parsed["org"]["name"] == "Acme"


def test_schema_command_emits_json_with_org() -> None:
    result = _run("schema")
    assert result.returncode == 0, result.stderr
    parsed = json.loads(result.stdout)
    assert "org" in parsed["properties"]
