"""Tests for the Constitution render API (RAJ-59)."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from ai_constitution.render import Constitution, _derive_slug


# ──────────────────────────────────────────────────────────
# Fixture helpers — write a minimal templates dir + defaults.
# ──────────────────────────────────────────────────────────


def _write_template(dir_: Path, rel: str, body: str) -> None:
    p = dir_ / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(textwrap.dedent(body), encoding="utf-8")


@pytest.fixture
def fake_repo(tmp_path: Path) -> dict[str, Path]:
    """Minimal templates_dir + defaults.toml for isolated tests."""
    templates = tmp_path / "templates"
    templates.mkdir()
    skills = tmp_path / "skills"
    skills.mkdir()

    _write_template(
        templates,
        "IDENTITY.toml.j2",
        """\
        [identity]
        name = "{{ org.agent.name }}"
        title = "{{ org.agent.title }}"
        emoji = "{{ org.agent.emoji }}"
        """,
    )
    _write_template(
        templates,
        "PRINCIPAL.toml.j2",
        """\
        [principal]
        name = "{{ org.pm.name }}"
        title = "{{ org.pm.title }}"
        org = "{{ org.name }}"
        slug = "{{ org.slug }}"
        """,
    )
    _write_template(
        templates,
        "protocols/PROTOCOL-00.toml.j2",
        """\
        [protocol]
        id = "00"
        agent = "{{ org.agent.name }}"
        """,
    )
    _write_template(
        templates,
        "DATA.toml",
        """\
        [data]
        verbatim = true
        """,
    )
    _write_template(
        skills,
        "boot/SKILL.md.j2",
        """\
        # /boot — for {{ org.agent.name }} of {{ org.name }}
        """,
    )

    defaults = tmp_path / "defaults.toml"
    defaults.write_text(
        textwrap.dedent(
            """
            [org]
            name = "Your Org"
            slug = ""
            timezone = "UTC"

            [org.pm]
            name = ""
            title = "Prime Minister"

            [org.agent]
            name = "Secretary"
            title = "Principal Secretary"
            emoji = "🏛️"
            """,
        ).strip(),
        encoding="utf-8",
    )

    return {"templates": templates, "skills": skills, "defaults": defaults}


# ──────────────────────────────────────────────────────────
# Slug derivation.
# ──────────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "name, slug",
    [
        ("Acme", "acme"),
        ("Raj Sadan", "raj-sadan"),
        ("FOO BAR INC.", "foo-bar-inc"),
        ("My_Cool/Org", "my-cool-org"),
    ],
)
def test_slug_derivation(name: str, slug: str) -> None:
    assert _derive_slug(name) == slug


# ──────────────────────────────────────────────────────────
# Defaults-only render.
# ──────────────────────────────────────────────────────────


def test_render_defaults_only(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    out = tmp_path / "out"
    rendered = c.render(out)
    by_path = {f.relative_path: f.content for f in rendered}

    assert "IDENTITY.toml" in by_path
    assert "PRINCIPAL.toml" in by_path
    assert "protocols/PROTOCOL-00.toml" in by_path
    assert "DATA.toml" in by_path
    assert "skills/boot/SKILL.md" in by_path

    # Default agent name is "Secretary".
    assert 'name = "Secretary"' in by_path["IDENTITY.toml"]
    # Slug is auto-derived from org.name even when it's empty in defaults.
    assert 'slug = "your-org"' in by_path["PRINCIPAL.toml"]
    # Verbatim file (non-.j2) preserved as-is.
    assert "verbatim = true" in by_path["DATA.toml"]
    # Skills path mirrored under skills/.
    assert "Secretary of Your Org" in by_path["skills/boot/SKILL.md"]


# ──────────────────────────────────────────────────────────
# Override config.
# ──────────────────────────────────────────────────────────


def test_render_with_overrides(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    cfg_path = tmp_path / "org-config.toml"
    cfg_path.write_text(
        textwrap.dedent(
            """
            [org]
            name = "Acme"

            [org.pm]
            name = "Vishal"
            title = "Founder"

            [org.agent]
            name = "Friday"
            emoji = "🤖"
            """,
        ).strip(),
        encoding="utf-8",
    )
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
        org_config_path=cfg_path,
    )
    out = tmp_path / "out"
    rendered = {f.relative_path: f.content for f in c.render(out)}

    assert 'name = "Friday"' in rendered["IDENTITY.toml"]
    assert 'emoji = "🤖"' in rendered["IDENTITY.toml"]
    # Untouched defaults still apply.
    assert 'title = "Principal Secretary"' in rendered["IDENTITY.toml"]
    # Override of pm
    assert 'name = "Vishal"' in rendered["PRINCIPAL.toml"]
    assert 'title = "Founder"' in rendered["PRINCIPAL.toml"]
    assert 'org = "Acme"' in rendered["PRINCIPAL.toml"]
    assert 'slug = "acme"' in rendered["PRINCIPAL.toml"]


# ──────────────────────────────────────────────────────────
# Render is lossless / idempotent.
# ──────────────────────────────────────────────────────────


def test_render_idempotent(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    out = tmp_path / "out"
    first = {f.relative_path: f.content for f in c.render(out)}
    second = {f.relative_path: f.content for f in c.render(out)}
    assert first == second


# ──────────────────────────────────────────────────────────
# render_one
# ──────────────────────────────────────────────────────────


def test_render_one_returns_string(fake_repo: dict[str, Path]) -> None:
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    text = c.render_one("IDENTITY.toml")
    assert 'name = "Secretary"' in text
    assert isinstance(text, str)


def test_render_one_unknown_raises(fake_repo: dict[str, Path]) -> None:
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    with pytest.raises(FileNotFoundError):
        c.render_one("NOPE.toml")


# ──────────────────────────────────────────────────────────
# StrictUndefined catches typos in templates.
# ──────────────────────────────────────────────────────────


def test_undefined_variable_in_template_raises(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    bad = fake_repo["templates"] / "BAD.toml.j2"
    bad.write_text("name = '{{ org.does_not_exist }}'\n", encoding="utf-8")
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    from jinja2 import UndefinedError

    with pytest.raises(UndefinedError):
        c.render_one("BAD.toml")


# ──────────────────────────────────────────────────────────
# Diff mode.
# ──────────────────────────────────────────────────────────


def test_diff_unchanged_after_render(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    out = tmp_path / "out"
    c.render(out)
    diffs = c.render_diff(out)
    assert all(d.status == "unchanged" for d in diffs)


def test_diff_modified(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    out = tmp_path / "out"
    c.render(out)
    # Tamper.
    (out / "IDENTITY.toml").write_text("tampered\n", encoding="utf-8")
    diffs = {d.relative_path: d for d in c.render_diff(out)}
    assert diffs["IDENTITY.toml"].status == "modified"
    assert "tampered" in diffs["IDENTITY.toml"].diff
    assert diffs["PRINCIPAL.toml"].status == "unchanged"


def test_diff_new_files(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    c = Constitution.load(
        templates_dir=fake_repo["templates"],
        skills_dir=fake_repo["skills"],
        defaults_path=fake_repo["defaults"],
    )
    diffs = c.render_diff(tmp_path / "nonexistent")
    assert all(d.status == "new" for d in diffs)


# ──────────────────────────────────────────────────────────
# Missing inputs are clear errors.
# ──────────────────────────────────────────────────────────


def test_missing_templates_dir_errors(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="templates_dir"):
        Constitution.load(
            templates_dir=tmp_path / "nope",
            defaults_path=tmp_path / "defaults.toml",
        )


def test_missing_defaults_errors(fake_repo: dict[str, Path], tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="defaults_path"):
        Constitution.load(
            templates_dir=fake_repo["templates"],
            defaults_path=tmp_path / "nope.toml",
        )
