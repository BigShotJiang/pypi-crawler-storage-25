"""ai-constitution — constitutional governance framework for AI agents.

The full Constitution.load + render API is populated in RAJ-59 (M2).
This file currently exposes only the package version so a fresh install
remains importable.
"""

__version__ = "0.1.2"
