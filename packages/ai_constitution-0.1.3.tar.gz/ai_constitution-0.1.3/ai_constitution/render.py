"""The Constitution render API — load templates + config, write or diff a bundle.

This is the consumer-facing surface (RAJ-59). The onboarding sherpa (M3, RAJ-61)
calls these methods after collecting answers; raj-sadan (M6, RAJ-79) calls them
during the round-trip diff.

Contract:
* Rendering is **lossless** — same inputs always produce the same bytes.
* The renderer accepts arbitrary template trees — it walks `templates_dir`
  and renders every `*.j2` file it finds, mirroring the directory layout
  into the output. Non-`.j2` files (e.g. fixtures, data) are copied verbatim.
* The output filename strips the `.j2` suffix.
* Rendering is **one-shot** — produced files are plain TOML/MD; no template
  engine ships into the consumer at runtime (per RAJ-50 decision).
"""

from __future__ import annotations

import difflib
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape

from .schema import OrgConfig, load_org_config

# ──────────────────────────────────────────────────────────
# Paths to the built-in templates + defaults shipped in the package.
# ──────────────────────────────────────────────────────────

_PACKAGE_ROOT = Path(__file__).resolve().parent
_REPO_ROOT = _PACKAGE_ROOT.parent
BUILTIN_TEMPLATES_DIR = _REPO_ROOT / "templates"
BUILTIN_DEFAULTS_PATH = _REPO_ROOT / "defaults.toml"
BUILTIN_SKILLS_DIR = _REPO_ROOT / "skills"


# ──────────────────────────────────────────────────────────
# Helpers — TOML merge + slug derivation.
# ──────────────────────────────────────────────────────────


def _deep_merge(base: dict[str, Any], over: dict[str, Any]) -> dict[str, Any]:
    """Deep-merge `over` onto `base`. Lists and scalars from `over` replace base."""
    out = dict(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _load_toml(path: Path) -> dict[str, Any]:
    try:
        import tomllib  # py >= 3.11
    except ModuleNotFoundError:  # pragma: no cover
        import tomli as tomllib  # type: ignore[no-redef]
    with open(path, "rb") as f:
        return tomllib.load(f)


def _derive_slug(name: str) -> str:
    """Derive a kebab-case slug from a human-readable name."""
    import re

    s = name.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = s.strip("-")
    return s[:64]


# ──────────────────────────────────────────────────────────
# RenderResult — what render() / render_diff() return.
# ──────────────────────────────────────────────────────────


@dataclass
class RenderedFile:
    """Represents one file in the rendered bundle."""

    relative_path: str  # path relative to output_dir, e.g. "CONSTITUTION.toml"
    content: str
    source: Path  # absolute path to the source template (or copied file)


@dataclass
class FileDiff:
    """One file's status in a diff against an existing output directory."""

    relative_path: str
    status: str  # "unchanged" | "modified" | "new"
    diff: str = ""  # unified diff if modified, empty otherwise


# ──────────────────────────────────────────────────────────
# Constitution — the main entry.
# ──────────────────────────────────────────────────────────


class Constitution:
    """Load templates + config and render the org bundle.

    Usage:
        c = Constitution.load(org_config_path="my-org.toml")
        c.render(output_dir="./my-org/")           # writes the bundle
        text = c.render_one("CONSTITUTION.toml")   # returns one file as string
        diffs = c.render_diff("./my-org/")         # show what would change

    The optional `org_config_path` may be omitted — in that case only defaults
    are used (useful for "what does a fresh install look like" demos).
    """

    def __init__(
        self,
        *,
        templates_dir: Path,
        skills_dir: Path | None,
        config: OrgConfig,
    ) -> None:
        self._templates_dir = templates_dir
        self._skills_dir = skills_dir
        self._config = config
        self._context = self._build_context(config)
        self._env = Environment(
            loader=FileSystemLoader([str(templates_dir)] + ([str(skills_dir)] if skills_dir else [])),
            autoescape=select_autoescape(default=False),
            undefined=StrictUndefined,  # surface typos in template variables
            keep_trailing_newline=True,
            variable_start_string="{{",
            variable_end_string="}}",
        )

    # ── Construction ──────────────────────────────────────

    @classmethod
    def load(
        cls,
        *,
        templates_dir: Path | str | None = None,
        defaults_path: Path | str | None = None,
        skills_dir: Path | str | None = None,
        org_config_path: Path | str | None = None,
    ) -> "Constitution":
        """Load templates + merged config from disk.

        Defaults all come from the package's bundled paths. Pass overrides
        for tests or alternate framework versions.
        """
        templates_dir = Path(templates_dir or BUILTIN_TEMPLATES_DIR).resolve()
        defaults_path = Path(defaults_path or BUILTIN_DEFAULTS_PATH).resolve()
        if skills_dir is None and BUILTIN_SKILLS_DIR.exists():
            skills_dir = BUILTIN_SKILLS_DIR
        skills_dir_resolved = Path(skills_dir).resolve() if skills_dir else None

        if not templates_dir.is_dir():
            raise FileNotFoundError(f"templates_dir not found: {templates_dir}")
        if not defaults_path.is_file():
            raise FileNotFoundError(f"defaults_path not found: {defaults_path}")

        defaults = _load_toml(defaults_path)
        if org_config_path is not None:
            overrides = _load_toml(Path(org_config_path).resolve())
            merged = _deep_merge(defaults, overrides)
        else:
            merged = defaults

        config = OrgConfig.model_validate(merged)
        return cls(
            templates_dir=templates_dir,
            skills_dir=skills_dir_resolved,
            config=config,
        )

    # ── Public API ────────────────────────────────────────

    @property
    def config(self) -> OrgConfig:
        return self._config

    def list_templates(self) -> list[str]:
        """Return the relative paths of every template + asset that would render."""
        return [r for r, _ in self._iter_template_files()]

    def render_all(self) -> list[RenderedFile]:
        """Render every template into RenderedFile objects (in-memory, no IO)."""
        out: list[RenderedFile] = []
        for rel, src in self._iter_template_files():
            content = self._render_one_path(src, rel)
            out_rel = rel[:-3] if rel.endswith(".j2") else rel
            out.append(RenderedFile(relative_path=out_rel, content=content, source=src))
        return out

    def render_one(self, output_relative_path: str) -> str:
        """Render a single output file, identified by its post-strip filename.

        Example: render_one("CONSTITUTION.toml") looks for templates/CONSTITUTION.toml.j2
        first, then templates/CONSTITUTION.toml as a non-templated copy.
        """
        for rel, src in self._iter_template_files():
            stripped = rel[:-3] if rel.endswith(".j2") else rel
            if stripped == output_relative_path:
                return self._render_one_path(src, rel)
        raise FileNotFoundError(
            f"no template found rendering to {output_relative_path!r} "
            f"under {self._templates_dir}",
        )

    def render(self, output_dir: Path | str) -> list[RenderedFile]:
        """Render every template and write to `output_dir`. Returns the list of files."""
        out_dir = Path(output_dir).resolve()
        out_dir.mkdir(parents=True, exist_ok=True)
        rendered = self.render_all()
        for f in rendered:
            target = out_dir / f.relative_path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(f.content, encoding="utf-8", newline="\n")
        return rendered

    def render_diff(self, output_dir: Path | str) -> list[FileDiff]:
        """Compare rendered output against the existing files in output_dir.

        Returns one FileDiff per rendered file. status is one of:
        * "unchanged" — file exists and matches
        * "modified" — file exists but differs (diff field has unified diff)
        * "new" — file does not exist yet
        """
        out_dir = Path(output_dir).resolve()
        rendered = self.render_all()
        diffs: list[FileDiff] = []
        for f in rendered:
            target = out_dir / f.relative_path
            if not target.exists():
                diffs.append(FileDiff(relative_path=f.relative_path, status="new"))
                continue
            # Tolerate stray Windows-1252 bytes in the existing file (an editor
            # wart we've seen on real consumer files). Diff is for human review,
            # not byte-exactness — the lift script's read_source already does
            # this fallback on the source side.
            try:
                existing = target.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                existing = target.read_bytes().decode("cp1252")
            if existing == f.content:
                diffs.append(FileDiff(relative_path=f.relative_path, status="unchanged"))
                continue
            udiff = "".join(
                difflib.unified_diff(
                    existing.splitlines(keepends=True),
                    f.content.splitlines(keepends=True),
                    fromfile=f"existing/{f.relative_path}",
                    tofile=f"rendered/{f.relative_path}",
                ),
            )
            diffs.append(FileDiff(relative_path=f.relative_path, status="modified", diff=udiff))
        return diffs

    # ── Internals ─────────────────────────────────────────

    def _build_context(self, config: OrgConfig) -> dict[str, Any]:
        """Convert the validated OrgConfig into the dict jinja2 sees."""
        ctx = config.model_dump(mode="json")
        # Auto-derive slug if empty so templates can rely on `org.slug`.
        if not ctx["org"].get("slug"):
            ctx["org"]["slug"] = _derive_slug(ctx["org"].get("name", "your-org"))
        return ctx

    def _iter_template_files(self) -> list[tuple[str, Path]]:
        """Walk templates_dir + skills_dir, yielding (relative_path, abs_source_path).

        Skip dotfiles and the `.gitkeep` placeholders.
        """
        out: list[tuple[str, Path]] = []
        for root_dir in [self._templates_dir, self._skills_dir]:
            if root_dir is None or not root_dir.is_dir():
                continue
            prefix = "" if root_dir == self._templates_dir else "skills/"
            for p in sorted(root_dir.rglob("*")):
                if not p.is_file():
                    continue
                rel_path = p.relative_to(root_dir)
                if rel_path.name.startswith("."):
                    continue
                rel_str = (prefix + str(rel_path)).replace("\\", "/")
                out.append((rel_str, p))
        return out

    def _render_one_path(self, src: Path, rel: str) -> str:
        """Render a single source path. Non-.j2 files are returned verbatim."""
        if not rel.endswith(".j2"):
            # Copy verbatim (preserve text encoding; binary files are out of scope).
            return src.read_text(encoding="utf-8")
        # Use Environment.get_template which goes through the FileSystemLoader.
        # rel includes the "skills/" prefix when applicable; the loader has
        # both roots so the lookup name strips the prefix.
        lookup = rel[len("skills/"):] if rel.startswith("skills/") else rel
        template = self._env.get_template(lookup)
        return template.render(**self._context)
