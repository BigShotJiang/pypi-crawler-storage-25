"""Pydantic schema for `org-config.toml` — the consumer's per-org overrides.

The variable registry was decided in raj-sadan's audit/PARAMETERIZATION.md
(RAJ-50). Required-ness is enforced by the onboarding sherpa (RAJ-62), NOT
here — every field has a default so a fresh install can render against
just defaults.toml.

What this schema provides:
* Type validation (string, int, list[str], etc.) at config load time.
* Structural validation (e.g. `org.ministries.enabled` is a list of known
  minister names).
* JSON Schema export for editor auto-completion.

What this schema deliberately does NOT do:
* Refuse to load when `org.name` is "Your Org" — that's a soft, judgment
  call the onboarding sherpa makes interactively, not a hard contract.
"""

from __future__ import annotations

import re
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ────────────────────────────────────────────────────────────
# Known names — single source of truth for ministry / sherpa /
# protocol enums so a typo in `enabled` lists fails fast.
# ────────────────────────────────────────────────────────────

KNOWN_MINISTERS = (
    "planning",
    "design",
    "external_affairs",
    "resources",
    "review",
)

KNOWN_SHERPAS = (
    "boot",
    "exit",
    "onboarding",
    "scrum",
    "design",
    "nextcloud",
    "crawler",
)

# Onboarding, boot, exit are mandatory — they always appear in
# `org.sherpas.enabled` regardless of what the user says.
MANDATORY_SHERPAS = ("boot", "exit", "onboarding")

KNOWN_PROTOCOLS = tuple(f"{i:02d}" for i in range(13))  # "00".."12"

# Slug rule: lowercase, kebab-case, alphanumeric + hyphen, 1-64 chars.
_SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$")


class StrictModel(BaseModel):
    """Base — every model rejects unknown keys so typos surface immediately."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


# ────────────────────────────────────────────────────────────
# org.pm.*
# ────────────────────────────────────────────────────────────


class OrgPM(StrictModel):
    name: str = ""
    title: str = "Prime Minister"
    pronouns: str = "they/them"
    email: str = ""


# ────────────────────────────────────────────────────────────
# org.agent.*
# ────────────────────────────────────────────────────────────


class AgentPersona(StrictModel):
    tone: str = "Sharp, composed, efficient"
    keywords: list[str] = Field(default_factory=lambda: ["architect", "orchestrator"])


class OrgAgent(StrictModel):
    name: str = "Secretary"
    title: str = "Principal Secretary"
    emoji: str = "🏛️"
    persona: AgentPersona = Field(default_factory=AgentPersona)
    reports_to: str = "Prime Minister"


# ────────────────────────────────────────────────────────────
# org.ministries.* / org.sherpas.* / org.protocols.*
# ────────────────────────────────────────────────────────────


class MinisterOverride(StrictModel):
    """Per-ministry override of the registry-default domain description."""

    domain: str | None = None


class OrgMinistries(StrictModel):
    enabled: list[str] = Field(
        default_factory=lambda: list(KNOWN_MINISTERS),
        description="Subset of the ai-ministers registry to wire into this org.",
    )
    overrides: dict[str, MinisterOverride] = Field(default_factory=dict)

    @field_validator("enabled")
    @classmethod
    def _check_known(cls, v: list[str]) -> list[str]:
        unknown = [m for m in v if m not in KNOWN_MINISTERS]
        if unknown:
            raise ValueError(
                f"unknown ministers in org.ministries.enabled: {unknown}. "
                f"Known: {list(KNOWN_MINISTERS)}",
            )
        return v


class OrgSherpas(StrictModel):
    enabled: list[str] = Field(
        default_factory=lambda: list(MANDATORY_SHERPAS),
        description="Sherpas to enable. boot, exit, onboarding are always added.",
    )

    @field_validator("enabled")
    @classmethod
    def _check_known_and_mandatory(cls, v: list[str]) -> list[str]:
        unknown = [s for s in v if s not in KNOWN_SHERPAS]
        if unknown:
            raise ValueError(
                f"unknown sherpas in org.sherpas.enabled: {unknown}. "
                f"Known: {list(KNOWN_SHERPAS)}",
            )
        out = list(v)
        for m in MANDATORY_SHERPAS:
            if m not in out:
                out.append(m)
        return out


class OrgProtocols(StrictModel):
    enabled: list[str] = Field(
        default_factory=lambda: ["00", "12"],
        description='Minimum viable set: PROTOCOL-00 (delegation) + PROTOCOL-12 (cognitive continuity).',
    )

    @field_validator("enabled")
    @classmethod
    def _check_known(cls, v: list[str]) -> list[str]:
        unknown = [p for p in v if p not in KNOWN_PROTOCOLS]
        if unknown:
            raise ValueError(
                f"unknown protocols in org.protocols.enabled: {unknown}. "
                f"Known: {list(KNOWN_PROTOCOLS)}",
            )
        return v


# ────────────────────────────────────────────────────────────
# org.llm.*
# ────────────────────────────────────────────────────────────


class LLMLocal(StrictModel):
    host: str = "http://localhost:11434"
    fleet: dict[str, str] = Field(
        default_factory=dict,
        description="Map of role-name to ollama model identifier.",
    )


class LLMCloud(StrictModel):
    provider: str = ""  # "anthropic" / "openai" / ""
    api_key: str = ""  # Stored encrypted in practice; this schema accepts the slot.


class OrgLLM(StrictModel):
    local: LLMLocal = Field(default_factory=LLMLocal)
    cloud: LLMCloud = Field(default_factory=LLMCloud)


# ────────────────────────────────────────────────────────────
# org.services.* — optional gateway endpoints
# ────────────────────────────────────────────────────────────


class ServiceEndpoint(StrictModel):
    host: str | None = None
    port: int | None = None


class OrgServices(StrictModel):
    """Open dict — orgs can register arbitrary services beyond the canonical set."""

    model_config = ConfigDict(extra="allow", str_strip_whitespace=True)

    cron: ServiceEndpoint = Field(default_factory=ServiceEndpoint)
    whatsapp: ServiceEndpoint = Field(default_factory=ServiceEndpoint)
    dashboard: ServiceEndpoint = Field(default_factory=ServiceEndpoint)
    knowledge: ServiceEndpoint = Field(default_factory=ServiceEndpoint)


# ────────────────────────────────────────────────────────────
# org.* (root)
# ────────────────────────────────────────────────────────────


class Org(StrictModel):
    name: str = "Your Org"
    slug: str = ""
    tagline: str = ""
    timezone: str = "UTC"

    pm: OrgPM = Field(default_factory=OrgPM)
    agent: OrgAgent = Field(default_factory=OrgAgent)
    ministries: OrgMinistries = Field(default_factory=OrgMinistries)
    sherpas: OrgSherpas = Field(default_factory=OrgSherpas)
    protocols: OrgProtocols = Field(default_factory=OrgProtocols)
    llm: OrgLLM = Field(default_factory=OrgLLM)
    services: OrgServices = Field(default_factory=OrgServices)

    @field_validator("slug")
    @classmethod
    def _slug_format(cls, v: str) -> str:
        if v == "":
            return v  # empty is fine — onboarding derives from name
        if not _SLUG_RE.match(v):
            raise ValueError(
                f"org.slug {v!r} must be lowercase kebab-case, "
                "alphanumeric + hyphen, 1-64 chars, no leading/trailing hyphen.",
            )
        return v


class OrgConfig(StrictModel):
    """Top-level container — `org-config.toml` parses straight into this."""

    org: Org = Field(default_factory=Org)


# ────────────────────────────────────────────────────────────
# JSON Schema export
# ────────────────────────────────────────────────────────────


def json_schema() -> dict:
    """Return the OpenAPI-compatible JSON Schema for `org-config.toml`."""
    return OrgConfig.model_json_schema()


# ────────────────────────────────────────────────────────────
# Loader (used by validator CLI + render library — RAJ-59)
# ────────────────────────────────────────────────────────────


def load_org_config(path: str) -> OrgConfig:
    """Parse a TOML file at `path` into an OrgConfig.

    Raises pydantic.ValidationError with field-level details on schema violations.
    """
    try:
        import tomllib  # py >= 3.11
    except ModuleNotFoundError:  # pragma: no cover - 3.10 fallback
        import tomli as tomllib  # type: ignore[no-redef]

    with open(path, "rb") as f:
        data = tomllib.load(f)
    return OrgConfig.model_validate(data)
