"""CLI entry — dispatches to render / validate / schema / version subcommands."""

from __future__ import annotations

import argparse
import json
import sys

from . import __version__


def _cmd_validate(args: argparse.Namespace) -> int:
    from pydantic import ValidationError

    from .schema import load_org_config

    try:
        cfg = load_org_config(args.config)
    except FileNotFoundError:
        print(f"error: config file not found: {args.config}", file=sys.stderr)
        return 2
    except ValidationError as exc:
        print(f"error: {args.config} failed schema validation:", file=sys.stderr)
        for err in exc.errors():
            loc = ".".join(str(p) for p in err["loc"])
            print(f"  • {loc or '<root>'}: {err['msg']}", file=sys.stderr)
        return 1

    print(f"ok: {args.config} validates")
    if args.show:
        print(json.dumps(cfg.model_dump(mode="json"), indent=2))
    return 0


def _cmd_schema(_args: argparse.Namespace) -> int:
    from .schema import json_schema

    print(json.dumps(json_schema(), indent=2))
    return 0


def _cmd_render(args: argparse.Namespace) -> int:
    from pydantic import ValidationError

    from .render import Constitution

    try:
        c = Constitution.load(
            templates_dir=args.templates,
            defaults_path=args.defaults,
            skills_dir=args.skills,
            org_config_path=args.config,
        )
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except ValidationError as exc:
        print("error: org-config failed schema validation:", file=sys.stderr)
        for err in exc.errors():
            loc = ".".join(str(p) for p in err["loc"])
            print(f"  • {loc or '<root>'}: {err['msg']}", file=sys.stderr)
        return 1

    if args.diff:
        diffs = c.render_diff(args.output)
        any_changes = False
        for d in diffs:
            if d.status == "unchanged":
                continue
            any_changes = True
            print(f"[{d.status}] {d.relative_path}")
            if d.diff:
                print(d.diff)
        if not any_changes:
            print("no changes — rendered output matches existing tree")
        return 0

    rendered = c.render(args.output)
    print(f"rendered {len(rendered)} files to {args.output}")
    return 0


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ai-constitution",
        description="Render constitutional templates for an organization.",
    )
    p.add_argument("-V", "--version", action="version", version=f"ai-constitution {__version__}")
    sub = p.add_subparsers(dest="cmd", metavar="COMMAND")

    pv = sub.add_parser("validate", help="validate an org-config.toml against the schema")
    pv.add_argument("--config", required=True, help="path to org-config.toml")
    pv.add_argument("--show", action="store_true", help="print the parsed config as JSON")
    pv.set_defaults(func=_cmd_validate)

    ps = sub.add_parser("schema", help="print the JSON Schema for org-config.toml")
    ps.set_defaults(func=_cmd_schema)

    pr = sub.add_parser("render", help="render templates into an org bundle")
    pr.add_argument("--config", required=False, help="path to org-config.toml (defaults only if omitted)")
    pr.add_argument("--output", required=True, help="output directory")
    pr.add_argument("--templates", required=False, help="override the templates directory")
    pr.add_argument("--defaults", required=False, help="override the defaults.toml path")
    pr.add_argument("--skills", required=False, help="override the skills directory")
    pr.add_argument("--diff", action="store_true", help="show what would change without writing")
    pr.set_defaults(func=_cmd_render)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "cmd", None):
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
