from __future__ import annotations

from typing import Callable, Awaitable

from .client import capture_exception

try:
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
except Exception:  # pragma: no cover
    BaseHTTPMiddleware = object  # type: ignore
    Request = object  # type: ignore


class VybesecMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable]):  # type: ignore[override]
        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            body_text = None
            try:
                body = await request.body()  # type: ignore[attr-defined]
                body_text = body.decode("utf-8") if body else None
            except Exception:
                body_text = None
            capture_exception(
                exc,
                route=getattr(request, "url", None).path if getattr(request, "url", None) else None,
                method=getattr(request, "method", None),
                status_code=500,
                request_body=body_text,
            )
            raise
