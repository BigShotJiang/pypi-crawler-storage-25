from __future__ import annotations

import time
import uuid
import traceback
from dataclasses import dataclass
from typing import Optional, Dict, Any

import requests

SCRUB_PATTERNS = [
    (r"sk-[a-zA-Z0-9]{20,}", "[api-key]"),
    (r"pk_live_[a-zA-Z0-9]{20,}", "[stripe-key]"),
    (r"whsec_[a-zA-Z0-9]{20,}", "[webhook-secret]"),
    (r"Bearer\s+[a-zA-Z0-9\-_.]{20,}", "Bearer [token]"),
    (r"eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}", "[jwt]"),
    (r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b", "[email]"),
    (r"\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b", "[card]"),
    (r"\b\d{3}-\d{2}-\d{4}\b", "[ssn]"),
    (r'"password"\s*:\s*"[^"]+"', '"password":"[redacted]"'),
    (r'"secret"\s*:\s*"[^"]+"', '"secret":"[redacted]"'),
    (r'"token"\s*:\s*"[^"]+"', '"token":"[redacted]"'),
]


def scrub_sensitive_data(value: str) -> str:
    if not value:
        return value
    output = value
    for pattern, replacement in SCRUB_PATTERNS:
        output = __import__("re").sub(pattern, replacement, output)
    return output


@dataclass
class VybesecConfig:
    key: str
    platform: str = "other"
    environment: str = "production"
    release: str = ""
    ingest_url: str = "https://ingest.vybesec.com"
    debug: bool = False


_CONFIG: Optional[VybesecConfig] = None


def init(
    *,
    key: str,
    platform: str = "other",
    environment: str = "production",
    release: str = "",
    ingest_url: str = "https://ingest.vybesec.com",
    debug: bool = False,
) -> None:
    global _CONFIG
    _CONFIG = VybesecConfig(
        key=key,
        platform=platform,
        environment=environment,
        release=release,
        ingest_url=ingest_url,
        debug=debug,
    )


def capture_exception(
    exc: Exception,
    *,
    route: Optional[str] = None,
    method: Optional[str] = None,
    status_code: Optional[int] = None,
    request_body: Optional[str] = None,
    tags: Optional[Dict[str, str]] = None,
) -> None:
    if _CONFIG is None:
        print("[Vybesec] capture_exception called before init()")
        return

    message = scrub_sensitive_data(str(exc))
    stack = scrub_sensitive_data("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
    body = scrub_sensitive_data(request_body).strip()[:500] if request_body else None

    payload: Dict[str, Any] = {
        "type": "error",
        "message": message,
        "stackTrace": stack,
        "errorType": exc.__class__.__name__,
        "source": "server",
        "serverRuntime": "python",
        "serverPlatform": "python",
        "serverRoute": route,
        "serverMethod": method,
        "serverStatusCode": status_code,
        "requestBody": body,
        "platform": _CONFIG.platform,
        "environment": _CONFIG.environment,
        "release": _CONFIG.release,
        "sdkVersion": "0.1.0",
        "timestamp": int(time.time() * 1000),
        "tags": tags or {},
        "sessionId": uuid.uuid4().hex[:16],
    }

    url = f"{_CONFIG.ingest_url}/v1/server-events/{_CONFIG.key}"
    try:
        requests.post(url, json=[payload], timeout=2)
    except Exception as err:
        if _CONFIG.debug:
            print("[Vybesec] Send failed:", err)
