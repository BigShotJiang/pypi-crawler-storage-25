# vybesec

Server-side error monitoring for Python backends (FastAPI/Flask/Django).

## Install

```bash
pip install vybesec
```

## Init

```python
from vybesec import init, capture_exception

init(
    key="pk_live_YOUR_KEY",
    platform="other",
    environment="production",
)
```

## Manual capture

```python
try:
    raise ValueError("boom")
except Exception as exc:
    capture_exception(exc, route="/api/checkout", method="POST", status_code=500)
```

## FastAPI middleware

```python
from fastapi import FastAPI
from vybesec.middleware import VybesecMiddleware

app = FastAPI()
app.add_middleware(VybesecMiddleware)
```
