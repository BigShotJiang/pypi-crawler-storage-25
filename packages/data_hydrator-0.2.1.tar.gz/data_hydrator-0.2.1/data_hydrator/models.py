from __future__ import annotations
from enum import Enum
from typing import Any
from pydantic import BaseModel, Field

from component_mapper.models import MappedComponent, PropDefinition
from segment_classifier.models import ClassifiedSegment, ComponentType


# ─── Page-segmenter domain models (owned here, not by page-segmenter pkg) ────

class SegmentRecord(BaseModel):
    id: str
    html: str
    dom_position: str = ""
    type: str = ""
    confidence: float = 1.0
    children: list["SegmentRecord"] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}


SegmentRecord.model_rebuild()


class SegmentedPage(BaseModel):
    url: str
    html: str
    scraped_at: str = ""
    title: str = ""
    segments: list[SegmentRecord] = Field(default_factory=list)

    _segment_index: dict[str, SegmentRecord] = {}

    def build_index(self) -> None:
        index: dict[str, SegmentRecord] = {}

        def _walk(segs: list[SegmentRecord]) -> None:
            for seg in segs:
                index[seg.id] = seg
                if seg.children:
                    _walk(seg.children)

        _walk(self.segments)
        object.__setattr__(self, "_segment_index", index)

    def get_segment(self, segment_id: str) -> SegmentRecord | None:
        return self._segment_index.get(segment_id)


# ─── Enums ────────────────────────────────────────────────────────────────────

class ExtractionTrack(str, Enum):
    KNOWN   = "known"
    CONTENT = "content"
    UNKNOWN = "unknown"


class CollectionFormat(str, Enum):
    JSON     = "json"
    MARKDOWN = "markdown"


class EntryStatus(str, Enum):
    COMPLETE = "complete"
    DRAFT    = "draft"
    FAILED   = "failed"


class ImageUploadStatus(str, Enum):
    UPLOADED = "uploaded"
    CACHED   = "cached"
    FAILED   = "failed"
    SKIPPED  = "skipped"


# ─── Extraction Schema ────────────────────────────────────────────────────────

class FieldSelector(BaseModel):
    field_name: str
    css_selector: str
    attribute: str | None = None
    content_type: str = "text"
    required: bool = False
    multiple: bool = False


class ExtractionSchema(BaseModel):
    site_id: str
    component_type: str
    track: ExtractionTrack
    field_selectors: list[FieldSelector] = Field(default_factory=list)
    content_selector: str = ""
    exclude_selectors: list[str] = Field(default_factory=list)
    generated_from_segment_ids: list[str] = Field(default_factory=list)
    generation_confidence: float = 1.0
    llm_model_used: str = ""
    notes: str = ""


# ─── Extraction Results ───────────────────────────────────────────────────────

class ExtractedField(BaseModel):
    field_name: str
    raw_value: Any
    processed_value: Any
    content_type: str
    extraction_success: bool
    warning: str = ""


class ImageUploadResult(BaseModel):
    original_url: str
    cdn_url: str = ""
    r2_key: str = ""
    status: ImageUploadStatus
    file_size_bytes: int = 0
    content_type: str = ""


class SegmentExtractionResult(BaseModel):
    segment_id: str
    page_url: str
    component_type: str
    track: ExtractionTrack
    extracted_fields: list[ExtractedField]
    image_results: list[ImageUploadResult] = Field(default_factory=list)
    missing_required_fields: list[str] = Field(default_factory=list)
    status: EntryStatus
    warnings: list[str] = Field(default_factory=list)
    generated_schema: ExtractionSchema | None = None


# ─── Collection ───────────────────────────────────────────────────────────────

class CollectionEntry(BaseModel):
    slug: str
    collection_name: str
    format: CollectionFormat
    data: dict[str, Any]
    draft: bool = False
    title: str = ""
    body_markdown: str = ""
    source_segment_id: str = ""
    source_page_url: str = ""
    generated_url: str = ""
    original_url: str = ""


class PageSections(BaseModel):
    page_slug: str
    page_url: str
    page_title: str
    sections: list[dict[str, Any]] = Field(default_factory=list)


# ─── URL & Redirect ───────────────────────────────────────────────────────────

class CategoryMap(BaseModel):
    component_type: str
    prefix_to_category: dict[str, str] = Field(default_factory=dict)
    base_path: str = ""


class RedirectEntry(BaseModel):
    original_url: str
    new_url: str
    status_code: int = 301
    component_type: str = ""
    slug: str = ""


class RedirectMap(BaseModel):
    site_url: str
    generated_at: str
    total: int
    entries: list[RedirectEntry]


# ─── Phase Cache ──────────────────────────────────────────────────────────────

class MappedPageOutput(BaseModel):
    """Written to mapped/{page_slug}.json."""
    page_slug: str
    page_url: str
    mapped_components: list[dict]   # MappedComponent.model_dump() each


# ─── Staging & Manifest ───────────────────────────────────────────────────────

class BackupRecord(BaseModel):
    original_path: str
    backup_path: str
    created_at: str


class WrittenFile(BaseModel):
    file_path: str
    collection: str
    slug: str
    format: CollectionFormat
    status: EntryStatus
    draft: bool
    segment_id: str
    page_url: str
    generated_url: str = ""
    backup: BackupRecord | None = None
    warnings: list[str] = Field(default_factory=list)


class HydrationManifest(BaseModel):
    run_id: str
    site_id: str
    generated_at: str
    classified_dir: str
    staging_dir: str
    total_segments: int
    total_written: int
    total_draft: int
    total_failed: int
    total_images_uploaded: int
    total_images_cached: int
    total_images_failed: int
    track_breakdown: dict[ExtractionTrack, int]
    collections: dict[str, int]
    schemas_generated: int
    schema_cache_hits: int
    llm_calls_schema_gen: int
    llm_calls_unknown: int
    files: list[WrittenFile]
    backups: list[BackupRecord]
    warnings: list[str] = Field(default_factory=list)
    image_cache_hit_rate: float


class HydrationResult(BaseModel):
    manifest: HydrationManifest
    written_files: list[WrittenFile]
    redirect_map: RedirectMap
    failed_segments: list[str]
    staging_root: str
    manifest_path: str
    redirects_json_path: str
    redirects_csv_path: str


# ─── Re-exports ───────────────────────────────────────────────────────────────

__all__ = [
    "SegmentRecord", "SegmentedPage",
    "MappedComponent", "PropDefinition",
    "ClassifiedSegment", "ComponentType",

    "ExtractionTrack", "CollectionFormat", "EntryStatus", "ImageUploadStatus",
    "FieldSelector", "ExtractionSchema",
    "ExtractedField", "ImageUploadResult", "SegmentExtractionResult",
    "CollectionEntry", "PageSections",
    "CategoryMap", "RedirectEntry", "RedirectMap",
    "MappedPageOutput",
    "BackupRecord", "WrittenFile", "HydrationManifest", "HydrationResult",
]
