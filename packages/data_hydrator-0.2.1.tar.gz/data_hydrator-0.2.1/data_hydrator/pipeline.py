from __future__ import annotations

import logging
from typing import TypeVar

from data_hydrator.config import HydrationSettings
from data_hydrator.llm import LLMClient
from data_hydrator.models import HydrationResult
from data_hydrator.io.page_loader import PageLoader
from data_hydrator.io.phase_cache import PhaseCache
from data_hydrator.io.staging_writer import StagingWriter
from data_hydrator.schema.schema_cache import SchemaCache
from data_hydrator.schema.schema_generator import SchemaGenerator
from data_hydrator.extraction.unknown_extractor import UnknownExtractor
from data_hydrator.media.r2_client import R2Client
from data_hydrator.media.url_cache import ImageURLCache
from data_hydrator.media.image_processor import ImageProcessor
from data_hydrator.urls.url_generator import URLGenerator
from data_hydrator.phases.phase2_segmentation import Phase2Segmentation
from data_hydrator.phases.phase3_classification import Phase3Classification
from data_hydrator.phases.phase4_mapping import Phase4Mapping
from data_hydrator.phases.phase5_hydration import Phase5Hydration

logger = logging.getLogger(__name__)

T = TypeVar("T")


def _successes(d: dict[str, T | Exception]) -> dict[str, T]:
    return {k: v for k, v in d.items() if not isinstance(v, Exception)}


def _log_failures(phase: int, d: dict) -> list[str]:
    msgs = []
    for slug, v in d.items():
        if isinstance(v, Exception):
            msg = f"Phase {phase} failed for {slug}: {v}"
            logger.warning(msg)
            msgs.append(msg)
    return msgs


class HydrationPipeline:

    def __init__(self, settings: HydrationSettings):
        self._settings = settings
        self._loader:       PageLoader | None      = None
        self._cache:        PhaseCache | None      = None
        self._schema_cache: SchemaCache | None     = None
        self._url_cache:    ImageURLCache | None   = None
        self._r2:           R2Client | None        = None
        self._phase2:       Phase2Segmentation | None  = None
        self._phase3:       Phase3Classification | None = None
        self._phase4:       Phase4Mapping | None   = None
        self._phase5:       Phase5Hydration | None = None

    async def initialize(self) -> None:
        s = self._settings

        self._loader = PageLoader(s)
        self._cache  = PhaseCache(s.dirs)

        self._schema_cache = SchemaCache(s.schema_gen.schema_cache_path)
        await self._schema_cache.load_all(s.site_id)

        self._url_cache = ImageURLCache(s.r2.url_cache_path)
        await self._url_cache.load()

        self._r2 = R2Client(s.r2)
        await self._r2.__aenter__()

        llm             = LLMClient(s.schema_gen)
        image_processor = ImageProcessor(self._r2, self._url_cache, s.r2)
        schema_gen      = SchemaGenerator(s.schema_gen, s.site_id, llm)
        unknown_ext     = UnknownExtractor(s.schema_gen, self._schema_cache, s.site_id, llm)
        url_gen         = URLGenerator(s.url_gen)
        writer          = StagingWriter(s.dirs.staging_dir, s.staging)

        self._phase2 = Phase2Segmentation(s, self._cache, self._loader)
        self._phase3 = Phase3Classification(s, self._cache)
        self._phase4 = Phase4Mapping(s, self._cache)
        self._phase5 = Phase5Hydration(
            settings=s,
            schema_cache=self._schema_cache,
            schema_generator=schema_gen,
            unknown_extractor=unknown_ext,
            image_processor=image_processor,
            url_generator=url_gen,
            staging_writer=writer,
        )

        logger.info("HydrationPipeline initialized for site_id=%s", s.site_id)

    async def run(self) -> HydrationResult:
        # Step 0: Discover pages
        page_slugs = self._loader.discover_slugs()
        if not page_slugs:
            raise ValueError(
                f"No pages found in scrape_dir={self._settings.dirs.scrape_dir}"
            )
        logger.info("Discovered %d pages", len(page_slugs))

        all_warnings: list[str] = []

        # Step 1: Phase 2 — Segmentation
        segmented = await self._phase2.run(page_slugs)
        all_warnings.extend(_log_failures(2, segmented))
        segmented_ok = _successes(segmented)
        logger.info("Phase 2 complete: %d/%d pages OK", len(segmented_ok), len(page_slugs))

        # Step 2: Phase 3 — Classification
        classified = await self._phase3.run(segmented_ok)
        all_warnings.extend(_log_failures(3, classified))
        classified_ok = _successes(classified)
        logger.info("Phase 3 complete: %d/%d pages OK", len(classified_ok), len(segmented_ok))

        # Step 3: Phase 4 — Mapping
        mapped_by_page = await self._phase4.run(classified_ok)
        all_warnings.extend(_log_failures(4, mapped_by_page))
        mapped_ok = _successes(mapped_by_page)
        logger.info("Phase 4 complete: %d/%d pages OK", len(mapped_ok), len(classified_ok))

        # Step 4: Phase 5 — Hydration
        result = await self._phase5.run(mapped_ok, classified_ok)

        # Step 5: Aggregate phase failures into manifest warnings
        for w in all_warnings:
            result.manifest.warnings.append(w)

        # Step 6: Persist caches
        await self._url_cache.persist()

        return result

    async def shutdown(self) -> None:
        if self._r2:
            await self._r2.__aexit__(None, None, None)
        if self._url_cache:
            await self._url_cache.persist()
        logger.info("HydrationPipeline shut down")
