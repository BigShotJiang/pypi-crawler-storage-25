import asyncio
import json
import logging
from pathlib import Path
from data_hydrator.models import ExtractionSchema

logger = logging.getLogger(__name__)


class SchemaCache:

    def __init__(self, cache_path: str):
        self._base = Path(cache_path)
        self._store: dict[str, ExtractionSchema] = {}
        self._lock = asyncio.Lock()
        self._hit_count = 0
        self._miss_count = 0

    async def load_all(self, site_id: str) -> dict[str, ExtractionSchema]:
        site_dir = self._base / site_id
        if not site_dir.exists():
            return {}

        loaded: dict[str, ExtractionSchema] = {}
        for path in site_dir.glob("*.json"):
            try:
                text = path.read_text(encoding="utf-8")
                data = json.loads(text)
                schema = ExtractionSchema.model_validate(data)
                loaded[schema.component_type] = schema
            except Exception as exc:
                logger.warning("Failed to load schema from %s: %s", path, exc)

        async with self._lock:
            self._store.update(loaded)
            self._hit_count += len(loaded)

        return loaded

    async def save(self, schema: ExtractionSchema) -> None:
        path = self._base / schema.site_id / self._type_to_filename(schema.component_type)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                schema.model_dump_json(indent=2),
                encoding="utf-8",
            )
        except Exception as exc:
            logger.error("Failed to save schema for %s: %s", schema.component_type, exc)

    async def save_many(self, schemas: dict[str, ExtractionSchema]) -> None:
        await asyncio.gather(*(self.save(s) for s in schemas.values()))

    def get(self, component_type: str) -> ExtractionSchema | None:
        return self._store.get(component_type)

    def set(self, schema: ExtractionSchema) -> None:
        self._store[schema.component_type] = schema

    def record_miss(self) -> None:
        self._miss_count += 1

    def _type_to_filename(self, component_type: str) -> str:
        return component_type.replace(".", "_").replace("/", "_") + ".json"

    @property
    def hit_count(self) -> int:
        return self._hit_count

    @property
    def miss_count(self) -> int:
        return self._miss_count
