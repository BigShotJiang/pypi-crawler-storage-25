import json
import logging
from data_hydrator.models import ExtractionSchema, ExtractionTrack, FieldSelector
from data_hydrator.config import SchemaGenConfig
from data_hydrator.llm import LLMClient
from data_hydrator.schema.representative_picker import ComponentPair

logger = logging.getLogger(__name__)

_CONTENT_PREFIXES = ("content.", "collection.blog", "collection.news")

SYSTEM_PROMPT = """\
You are an expert HTML data extraction specialist.
Given representative HTML segments for multiple UI component types,
generate CSS extraction schemas for each type.

For each component type you receive:
- 1-3 example HTML segments (real scraped HTML)
- A prop_schema hint listing expected fields (may be incomplete or wrong)

Your job:
- Identify the best CSS selector for each meaningful data field
- For content types (blog, news, docs, articles): identify the main
  content container selector and selectors for noise elements to exclude
- Use the prop_schema as a HINT only — override if the HTML suggests
  better field names or selectors
- Prefer specific selectors (class-based) over generic ones (tag-only)
- If a field appears in some examples but not others, mark required: false

Output ONLY a valid JSON array. No markdown. No explanation.
One object per component type.\
"""


class SchemaGenerator:

    def __init__(self, settings: SchemaGenConfig, site_id: str, llm: LLMClient):
        self.settings = settings
        self.site_id = site_id
        self._llm = llm

    async def generate(
        self,
        representatives: dict[str, list[ComponentPair]],
    ) -> dict[str, ExtractionSchema]:
        if not representatives:
            return {}

        prompt = self._build_prompt(representatives)
        try:
            response = await self._llm.acompletion(
                model=self.settings.model,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
            )
            text = response.choices[0].message.content or ""
        except Exception as exc:
            logger.error("Schema generation LLM call failed: %s", exc)
            return {}

        return self._parse_response(text, self.site_id)

    def _build_prompt(
        self,
        representatives: dict[str, list[ComponentPair]],
    ) -> str:
        n = len(representatives)
        items = []
        for ctype, pairs in representatives.items():
            track = self._determine_track(ctype).value
            prop_hint = []
            if pairs:
                m0, _ = pairs[0]
                for pd in m0.prop_schema:
                    prop_hint.append({
                        "name": pd.name,
                        "type": pd.type,
                        "required": pd.required,
                    })
            segs = [
                {"segment_id": m.segment_id, "html": seg.html[:4000]}
                for m, seg in pairs
            ]
            items.append({
                "component_type": ctype,
                "track": track,
                "prop_schema_hint": prop_hint,
                "representative_segments": segs,
            })

        payload = json.dumps(items, indent=2, ensure_ascii=False)
        return (
            f"Analyze these {n} component types and generate extraction schemas.\n"
            f"Site: {self.site_id}\n\n"
            f"{payload}"
        )

    def _parse_response(
        self,
        response_text: str,
        site_id: str,
    ) -> dict[str, ExtractionSchema]:
        text = response_text.strip()
        if text.startswith("```"):
            lines = text.splitlines()
            text = "\n".join(l for l in lines if not l.startswith("```")).strip()

        try:
            raw_list = json.loads(text)
        except json.JSONDecodeError as exc:
            logger.error("Failed to parse schema generator response: %s", exc)
            return {}

        if not isinstance(raw_list, list):
            logger.error("Schema generator response is not a JSON array")
            return {}

        result: dict[str, ExtractionSchema] = {}
        for item in raw_list:
            try:
                ctype = item.get("component_type", "")
                if not ctype:
                    continue
                seg_ids = [
                    s.get("segment_id", "")
                    for s in item.get("representative_segments", [])
                    if s.get("segment_id")
                ]
                field_selectors = [
                    FieldSelector(**fs)
                    for fs in item.get("field_selectors", [])
                ]
                schema = ExtractionSchema(
                    site_id=site_id,
                    component_type=ctype,
                    track=ExtractionTrack(
                        item.get("track", self._determine_track(ctype).value)
                    ),
                    field_selectors=field_selectors,
                    content_selector=item.get("content_selector", ""),
                    exclude_selectors=item.get("exclude_selectors", []),
                    generation_confidence=float(item.get("generation_confidence", 1.0)),
                    llm_model_used=self.settings.model,
                    notes=item.get("notes", ""),
                    generated_from_segment_ids=seg_ids,
                )
                result[ctype] = schema
            except Exception as exc:
                logger.error("Failed to parse schema for type %s: %s", item.get("component_type"), exc)

        return result

    def _determine_track(self, component_type: str) -> ExtractionTrack:
        if any(component_type.startswith(p) for p in _CONTENT_PREFIXES):
            return ExtractionTrack.CONTENT
        return ExtractionTrack.KNOWN
