from bs4 import BeautifulSoup
from component_mapper.models import MappedComponent
from data_hydrator.models import SegmentRecord

# Pair type used throughout schema generation
ComponentPair = tuple[MappedComponent, SegmentRecord]


def pick_representatives(
    pairs: list[ComponentPair],
    n: int = 3,
) -> dict[str, list[ComponentPair]]:
    """
    Returns dict[component_type_str, list[ComponentPair]] of the n most
    complete, deduplicated representatives per type, highest-score first.

    Scoring: (child_element_count * 0.6) + (text_density_ratio * 0.4)
    Dedup by MappedComponent.fingerprint_hash before taking top N.
    """
    by_type: dict[str, list[ComponentPair]] = {}
    for pair in pairs:
        m, _ = pair
        by_type.setdefault(m.component_type, []).append(pair)

    result: dict[str, list[ComponentPair]] = {}
    for ctype, type_pairs in by_type.items():
        scored: list[tuple[float, ComponentPair]] = []
        for pair in type_pairs:
            m, seg = pair
            child_count, text_density = _score_segment(seg.html)
            score = _composite_score(child_count, text_density)
            scored.append((score, pair))

        scored.sort(key=lambda x: x[0], reverse=True)

        # Deduplicate by fingerprint_hash (keep highest-scoring per hash)
        seen_hashes: set[str] = set()
        deduped: list[ComponentPair] = []
        for _score, pair in scored:
            m, _ = pair
            fh = m.fingerprint_hash or ""
            if fh and fh in seen_hashes:
                continue
            if fh:
                seen_hashes.add(fh)
            deduped.append(pair)

        result[ctype] = deduped[:n]

    return result


def _score_segment(html: str) -> tuple[int, float]:
    """Returns (child_element_count, text_density_ratio). Never raises."""
    try:
        soup = BeautifulSoup(html, "lxml")
        child_count = len(soup.find_all())
        text_len = len(soup.get_text(strip=True))
        html_len = max(len(html), 1)
        text_density = min(text_len / html_len, 1.0)
        return child_count, text_density
    except Exception:
        return 0, 0.0


def _composite_score(child_count: int, text_density: float) -> float:
    return (child_count * 0.6) + (text_density * 0.4)
