import logging
import re
from urllib.parse import urljoin
from bs4 import BeautifulSoup
import markdownify
from data_hydrator.models import ExtractionSchema, ExtractedField
from data_hydrator.config import ContentExtractionConfig
from data_hydrator.extraction.field_extractor import extract_fields

logger = logging.getLogger(__name__)


def extract_content(
    segment_html: str,
    schema: ExtractionSchema,
    page_url: str,
    settings: ContentExtractionConfig,
) -> tuple[list[ExtractedField], str, list[str]]:
    """Returns (metadata_fields, body_markdown, missing_required_fields). Never raises."""
    try:
        # Step 1: Extract metadata fields using field selectors
        metadata_fields, missing_required = extract_fields(segment_html, schema, page_url)

        # Step 2: Parse for content extraction
        soup = BeautifulSoup(segment_html, "lxml")

        # Step 3: Find content container
        if schema.content_selector:
            container = soup.select_one(schema.content_selector)
            if container is None:
                logger.warning(
                    "content_selector '%s' found nothing; using full segment",
                    schema.content_selector,
                )
                container = soup
        else:
            container = soup

        # Step 4: Remove noise elements
        _remove_noise(container, schema.exclude_selectors)

        # Step 5: Remove always-strip tags
        for tag_name in settings.always_strip_tags:
            for el in container.find_all(tag_name):
                el.decompose()

        # Step 6: Convert to Markdown
        content_html = str(container)
        md = markdownify.markdownify(
            content_html,
            strip=settings.always_strip_tags,
            convert=settings.allowed_tags,
            heading_style="ATX",
        )

        # Post-process
        md = re.sub(r"\n{3,}", "\n\n", md)
        md = md.strip()
        md = _resolve_relative_urls(md, page_url)

        return metadata_fields, md, missing_required

    except Exception as exc:
        logger.error("Content extraction failed: %s", exc)
        return [], "", []


def _remove_noise(soup: BeautifulSoup, exclude_selectors: list[str]) -> None:
    for selector in exclude_selectors:
        try:
            for el in soup.select(selector):
                el.decompose()
        except Exception as exc:
            logger.warning("Exclude selector '%s' failed: %s", selector, exc)


def _resolve_relative_urls(markdown: str, base_url: str) -> str:
    if not base_url:
        return markdown

    def replace_image(m: re.Match) -> str:
        alt, url = m.group(1), m.group(2)
        resolved = urljoin(base_url, url)
        return f"![{alt}]({resolved})"

    def replace_link(m: re.Match) -> str:
        text, url = m.group(1), m.group(2)
        resolved = urljoin(base_url, url)
        return f"[{text}]({resolved})"

    # Images first (more specific pattern)
    markdown = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", replace_image, markdown)
    # Then links
    markdown = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", replace_link, markdown)
    return markdown
