import asyncio
import json
import logging
from data_hydrator.models import (
    ExtractionSchema, SegmentExtractionResult, ExtractionTrack,
    ExtractedField, EntryStatus, FieldSelector,
)
from data_hydrator.schema.schema_cache import SchemaCache
from data_hydrator.config import SchemaGenConfig
from data_hydrator.llm import LLMClient
from component_mapper.models import MappedComponent

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """\
You are an expert HTML content extractor.
Given an HTML segment of unknown type, do two things:
1. Infer what kind of UI component this is and what fields it contains
2. Extract those fields from the HTML

Output ONLY a valid JSON array. No markdown. No explanation.
One object per input segment.\
"""


class UnknownExtractor:

    def __init__(
        self,
        settings: SchemaGenConfig,
        schema_cache: SchemaCache,
        site_id: str,
        llm: LLMClient,
    ):
        self.settings = settings
        self.schema_cache = schema_cache
        self.site_id = site_id
        self._llm = llm
        self._semaphore = asyncio.Semaphore(settings.max_concurrent_unknown_batches)

    async def extract_batch(
        self,
        segments: list[tuple[MappedComponent, str]],
    ) -> list[SegmentExtractionResult]:
        if not segments:
            return []

        # Split into batches
        batch_size = self.settings.unknown_batch_size
        batches = [
            segments[i:i + batch_size]
            for i in range(0, len(segments), batch_size)
        ]

        all_results: list[SegmentExtractionResult] = []
        results = await asyncio.gather(
            *[self._process_batch(batch) for batch in batches],
            return_exceptions=True,
        )
        for r in results:
            if isinstance(r, Exception):
                logger.error("Unknown extractor batch failed: %s", r)
            else:
                all_results.extend(r)

        return all_results

    async def _process_batch(
        self,
        batch: list[tuple[MappedComponent, str]],
    ) -> list[SegmentExtractionResult]:
        async with self._semaphore:
            items = [
                {
                    "segment_id": m.segment_id,
                    "component_type_hint": "unknown",
                    "site_id": self.site_id,
                    "html": html[:3000],
                }
                for m, html in batch
            ]

            prompt = self._build_batch_prompt(items)
            try:
                response = await self._llm.acompletion(
                    model=self.settings.unknown_model,
                    messages=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": prompt},
                    ],
                )
                text = response.choices[0].message.content or ""
            except Exception as exc:
                logger.error("Unknown extractor LLM call failed: %s", exc)
                return [self._failed_result(m, html) for m, html in batch]

            return self._parse_batch_response(text, batch)

    def _build_batch_prompt(self, items: list[dict]) -> str:
        return json.dumps(items, indent=2, ensure_ascii=False)

    def _parse_batch_response(
        self,
        response: str,
        batch: list[tuple[MappedComponent, str]],
    ) -> list[SegmentExtractionResult]:
        text = response.strip()
        if text.startswith("```"):
            lines = text.splitlines()
            text = "\n".join(l for l in lines if not l.startswith("```")).strip()

        batch_map = {m.segment_id: (m, html) for m, html in batch}
        results: list[SegmentExtractionResult] = []

        try:
            parsed = json.loads(text)
            if not isinstance(parsed, list):
                parsed = [parsed]
        except json.JSONDecodeError as exc:
            logger.error("Failed to parse unknown extractor response: %s", exc)
            return [self._failed_result(m, html) for m, html in batch]

        handled_ids: set[str] = set()
        for item in parsed:
            seg_id = item.get("segment_id", "")
            if seg_id not in batch_map:
                continue

            mapped, html = batch_map[seg_id]
            handled_ids.add(seg_id)

            try:
                result = self._build_result(item, mapped)
                results.append(result)
            except Exception as exc:
                logger.error("Failed to build result for segment %s: %s", seg_id, exc)
                results.append(self._failed_result(mapped, html))

        # Any segment not in response → failed
        for seg_id, (m, html) in batch_map.items():
            if seg_id not in handled_ids:
                results.append(self._failed_result(m, html))

        return results

    def _build_result(
        self,
        item: dict,
        mapped: MappedComponent,
    ) -> SegmentExtractionResult:
        inferred_type = item.get("inferred_type", "unknown")
        schema_data = item.get("schema", {})
        extracted_data = item.get("extracted_data", {})
        confidence = float(item.get("confidence", 0.5))

        # Build ExtractionSchema from inferred data
        field_selectors = [
            FieldSelector(**fs)
            for fs in schema_data.get("field_selectors", [])
        ]
        schema = ExtractionSchema(
            site_id=self.site_id,
            component_type=inferred_type,
            track=ExtractionTrack.UNKNOWN,
            field_selectors=field_selectors,
            content_selector=schema_data.get("content_selector", ""),
            exclude_selectors=schema_data.get("exclude_selectors", []),
            generation_confidence=confidence,
            llm_model_used=self.settings.unknown_model,
            generated_from_segment_ids=[mapped.segment_id],
        )

        # Write back to cache so future same-type segments use Track A
        self.schema_cache.set(schema)
        asyncio.create_task(self.schema_cache.save(schema))

        # Build extracted fields
        extracted_fields: list[ExtractedField] = []
        for field_name, value in extracted_data.items():
            extracted_fields.append(ExtractedField(
                field_name=field_name,
                raw_value=value,
                processed_value=value,
                content_type="text",
                extraction_success=value is not None,
            ))

        return SegmentExtractionResult(
            segment_id=mapped.segment_id,
            page_url=mapped.page_url,
            component_type=inferred_type,
            track=ExtractionTrack.UNKNOWN,
            extracted_fields=extracted_fields,
            missing_required_fields=[],
            status=EntryStatus.COMPLETE if extracted_fields else EntryStatus.DRAFT,
            generated_schema=schema,
        )

    def _failed_result(
        self,
        mapped: MappedComponent,
        html: str,
    ) -> SegmentExtractionResult:
        return SegmentExtractionResult(
            segment_id=mapped.segment_id,
            page_url=mapped.page_url,
            component_type=mapped.component_type,
            track=ExtractionTrack.UNKNOWN,
            extracted_fields=[],
            missing_required_fields=[],
            status=EntryStatus.FAILED,
            warnings=["LLM extraction failed"],
        )
