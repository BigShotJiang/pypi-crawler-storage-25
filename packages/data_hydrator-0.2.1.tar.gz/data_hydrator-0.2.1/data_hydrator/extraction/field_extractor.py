import logging
import re
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from data_hydrator.models import ExtractionSchema, ExtractedField, FieldSelector

logger = logging.getLogger(__name__)


def extract_fields(
    segment_html: str,
    schema: ExtractionSchema,
    page_url: str,
) -> tuple[list[ExtractedField], list[str]]:
    """Returns (fields, missing_required_field_names). Never raises."""
    try:
        soup = BeautifulSoup(segment_html, "lxml")
    except Exception as exc:
        logger.error("Failed to parse segment HTML: %s", exc)
        missing = [fs.field_name for fs in schema.field_selectors if fs.required]
        return [], missing

    fields: list[ExtractedField] = []
    missing_required: list[str] = []

    for selector in schema.field_selectors:
        field = _extract_one(soup, selector, page_url)
        fields.append(field)
        if not field.extraction_success and selector.required:
            missing_required.append(selector.field_name)

    return fields, missing_required


def _extract_one(
    soup: BeautifulSoup,
    selector: FieldSelector,
    page_url: str,
) -> ExtractedField:
    css, attr_override = _parse_selector_attr(selector.css_selector)
    attribute = selector.attribute or attr_override

    try:
        if selector.content_type == "list" or selector.multiple:
            elements = soup.select(css)
            if not elements:
                return ExtractedField(
                    field_name=selector.field_name,
                    raw_value=None,
                    processed_value=[],
                    content_type=selector.content_type,
                    extraction_success=False,
                    warning=f"No elements matched selector '{css}'",
                )
            values = [el.get_text(strip=True) for el in elements]
            return ExtractedField(
                field_name=selector.field_name,
                raw_value=values,
                processed_value=values,
                content_type=selector.content_type,
                extraction_success=True,
            )

        element = soup.select_one(css)

        if selector.content_type == "boolean":
            val = element is not None
            return ExtractedField(
                field_name=selector.field_name,
                raw_value=val,
                processed_value=val,
                content_type="boolean",
                extraction_success=True,
            )

        if element is None:
            return ExtractedField(
                field_name=selector.field_name,
                raw_value=None,
                processed_value=None,
                content_type=selector.content_type,
                extraction_success=False,
                warning=f"No element matched selector '{css}'",
            )

        if selector.content_type == "text":
            text = element.get_text(strip=True)
            return ExtractedField(
                field_name=selector.field_name,
                raw_value=text,
                processed_value=text,
                content_type="text",
                extraction_success=bool(text),
                warning="" if text else f"Empty text at selector '{css}'",
            )

        if selector.content_type == "image_url":
            src = _get_image_src(element, attribute)
            if src:
                src = urljoin(page_url, src)
            return ExtractedField(
                field_name=selector.field_name,
                raw_value=src,
                processed_value=src,
                content_type="image_url",
                extraction_success=bool(src),
                warning="" if src else f"Could not extract image URL at '{css}'",
            )

        if selector.content_type == "url":
            attr = attribute or "href"
            href = element.get(attr, "")
            if href:
                href = urljoin(page_url, href)
            return ExtractedField(
                field_name=selector.field_name,
                raw_value=href,
                processed_value=href,
                content_type="url",
                extraction_success=bool(href),
                warning="" if href else f"No href at selector '{css}'",
            )

        # Fallback: treat as text
        text = element.get_text(strip=True)
        return ExtractedField(
            field_name=selector.field_name,
            raw_value=text,
            processed_value=text,
            content_type=selector.content_type,
            extraction_success=bool(text),
        )

    except Exception as exc:
        logger.warning("Field extraction failed for %s: %s", selector.field_name, exc)
        return ExtractedField(
            field_name=selector.field_name,
            raw_value=None,
            processed_value=None,
            content_type=selector.content_type,
            extraction_success=False,
            warning=str(exc),
        )


def _get_image_src(element, attribute: str | None) -> str:
    """Try multiple src attributes for lazy-loaded images."""
    candidates = [attribute] if attribute else []
    candidates += ["src", "data-src", "data-lazy-src"]
    for attr in candidates:
        if attr and element.get(attr):
            return element[attr]

    # Try background-image from style
    style = element.get("style", "")
    if "background-image" in style:
        match = re.search(r"url\(['\"]?([^'\")\s]+)['\"]?\)", style)
        if match:
            return match.group(1)
    return ""


def _parse_selector_attr(segment_field: str) -> tuple[str, str | None]:
    """Split 'img[src]' → ('img', 'src'), 'h2.name' → ('h2.name', None)."""
    match = re.match(r"^(.*?)\[([^\]]+)\]$", segment_field)
    if match:
        return match.group(1), match.group(2)
    return segment_field, None
