import asyncio
import logging
import mimetypes
import aiohttp
from data_hydrator.models import ImageUploadResult, ImageUploadStatus
from data_hydrator.media.r2_client import R2Client
from data_hydrator.media.url_cache import ImageURLCache
from data_hydrator.config import R2Config

logger = logging.getLogger(__name__)


class ImageProcessor:

    def __init__(
        self,
        r2: R2Client,
        url_cache: ImageURLCache,
        config: R2Config,
    ):
        self._r2 = r2
        self._cache = url_cache
        self._config = config
        self._download_semaphore = asyncio.Semaphore(config.max_concurrent_downloads)

    async def process_images(
        self,
        image_urls: list[str],
        collection: str,
        page_url: str,
    ) -> list[ImageUploadResult]:
        if not image_urls:
            return []
        tasks = [
            self._process_one(url, collection, page_url)
            for url in image_urls
            if url
        ]
        return list(await asyncio.gather(*tasks))

    async def _process_one(
        self,
        original_url: str,
        collection: str,
        page_url: str,
    ) -> ImageUploadResult:
        if not self._r2.configured:
            return ImageUploadResult(
                original_url=original_url,
                status=ImageUploadStatus.SKIPPED,
            )

        # Check cache first
        cached = self._cache.get(original_url)
        if cached:
            return ImageUploadResult(
                original_url=original_url,
                cdn_url=cached,
                status=ImageUploadStatus.CACHED,
            )

        # Download
        try:
            data, content_type = await self._download(original_url)
        except Exception as exc:
            logger.warning("Failed to download image %s: %s", original_url, exc)
            return ImageUploadResult(
                original_url=original_url,
                status=ImageUploadStatus.FAILED,
            )

        # Upload
        try:
            key = self._r2.build_key(original_url, collection)
            cdn_url = await self._r2.upload(key, data, content_type)
            self._cache.set(original_url, cdn_url)
            return ImageUploadResult(
                original_url=original_url,
                cdn_url=cdn_url,
                r2_key=key,
                status=ImageUploadStatus.UPLOADED,
                file_size_bytes=len(data),
                content_type=content_type,
            )
        except Exception as exc:
            logger.warning("Failed to upload image %s: %s", original_url, exc)
            return ImageUploadResult(
                original_url=original_url,
                status=ImageUploadStatus.FAILED,
            )

    async def _download(self, url: str) -> tuple[bytes, str]:
        async with self._download_semaphore:
            timeout = aiohttp.ClientTimeout(total=self._config.download_timeout_seconds)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as resp:
                    resp.raise_for_status()
                    content_type = resp.headers.get("Content-Type", "").split(";")[0].strip()
                    if not content_type:
                        content_type = mimetypes.guess_type(url)[0] or "image/jpeg"
                    data = await resp.read()
                    return data, content_type
