import asyncio
import hashlib
import logging
import mimetypes
from pathlib import PurePosixPath
from data_hydrator.config import R2Config

logger = logging.getLogger(__name__)


class R2Client:
    """Async Cloudflare R2 client using aiobotocore."""

    def __init__(self, config: R2Config):
        self._config = config
        self._session = None
        self._client = None
        self._upload_semaphore = asyncio.Semaphore(config.max_concurrent_uploads)

    async def __aenter__(self) -> "R2Client":
        if not self._config.bucket_name:
            logger.info("R2 not configured — uploads will be skipped")
            return self
        try:
            import aiobotocore.session
            self._session = aiobotocore.session.get_session()
            self._client = await self._session.create_client(
                "s3",
                endpoint_url=self._config.endpoint_url,
                aws_access_key_id=self._config.access_key_id,
                aws_secret_access_key=self._config.secret_access_key,
            ).__aenter__()
        except Exception as exc:
            logger.error("Failed to initialize R2 client: %s", exc)
        return self

    async def __aexit__(self, *args) -> None:
        if self._client:
            try:
                await self._client.__aexit__(*args)
            except Exception:
                pass
        self._client = None
        self._session = None

    async def upload(self, key: str, data: bytes, content_type: str = "") -> str:
        """Upload bytes to R2. Returns public CDN URL."""
        if not self._client:
            raise RuntimeError("R2 client not initialized or not configured")

        async with self._upload_semaphore:
            await self._client.put_object(
                Bucket=self._config.bucket_name,
                Key=key,
                Body=data,
                ContentType=content_type or "application/octet-stream",
            )

        base = self._config.public_base_url.rstrip("/")
        return f"{base}/{key}"

    def build_key(self, original_url: str, collection: str) -> str:
        url_hash = hashlib.md5(original_url.encode()).hexdigest()[:12]
        suffix = PurePosixPath(original_url.split("?")[0]).suffix or ".jpg"
        prefix = self._config.key_prefix.strip("/")
        return f"{prefix}/{collection}/{url_hash}{suffix}"

    @property
    def configured(self) -> bool:
        return bool(self._config.bucket_name)
