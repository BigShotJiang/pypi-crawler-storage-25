import asyncio
import hashlib
import json
import logging
import aiofiles
from pathlib import Path

logger = logging.getLogger(__name__)


class ImageURLCache:
    """Hash-based image URL deduplication cache backed by a JSON file on disk."""

    def __init__(self, cache_path: str):
        self._path = Path(cache_path)
        self._store: dict[str, str] = {}  # original_url_hash → cdn_url
        self._lock = asyncio.Lock()
        self._hit_count = 0

    async def load(self) -> None:
        if not self._path.exists():
            return
        try:
            async with aiofiles.open(self._path, encoding="utf-8") as f:
                data = json.loads(await f.read())
            async with self._lock:
                self._store = data
            logger.debug("Loaded %d image URL cache entries", len(self._store))
        except Exception as exc:
            logger.warning("Failed to load image URL cache: %s", exc)

    async def persist(self) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            async with aiofiles.open(self._path, "w", encoding="utf-8") as f:
                await f.write(json.dumps(self._store, indent=2))
        except Exception as exc:
            logger.warning("Failed to persist image URL cache: %s", exc)

    def get(self, original_url: str) -> str | None:
        key = self._hash(original_url)
        cdn = self._store.get(key)
        if cdn:
            self._hit_count += 1
        return cdn

    def set(self, original_url: str, cdn_url: str) -> None:
        key = self._hash(original_url)
        self._store[key] = cdn_url

    @property
    def hit_count(self) -> int:
        return self._hit_count

    @staticmethod
    def _hash(url: str) -> str:
        return hashlib.sha256(url.encode()).hexdigest()
