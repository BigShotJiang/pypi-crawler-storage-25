"""Central LiteLLM client — loads litellm_config.yaml and routes all AI calls."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import litellm
import yaml
from litellm import Router

from data_hydrator.config import SchemaGenConfig

logger = logging.getLogger(__name__)


class LLMClient:
    """Wraps a LiteLLM Router loaded from litellm_config.yaml.

    Falls back to bare litellm.acompletion() when the config file is absent,
    so local dev without the file still works.
    """

    def __init__(self, config: SchemaGenConfig) -> None:
        self._config = config
        self._router: Router | None = None
        self._init_router()

    def _init_router(self) -> None:
        path = Path(self._config.litellm_config_path)
        if not path.exists():
            logger.warning(
                "litellm_config.yaml not found at %s — falling back to direct litellm calls",
                path,
            )
            litellm.drop_params = self._config.drop_params
            return

        with open(path, encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh)

        ls: dict[str, Any] = cfg.get("litellm_settings", {})
        litellm.drop_params = ls.get("drop_params", self._config.drop_params)

        model_list: list[dict] = cfg.get("model_list", [])
        if not model_list:
            logger.warning("litellm_config.yaml has no model_list — falling back to direct calls")
            return

        self._router = Router(
            model_list=model_list,
            num_retries=ls.get("num_retries", self._config.max_retries),
            timeout=ls.get("request_timeout", self._config.timeout_seconds),
        )
        logger.info(
            "LiteLLM Router initialised with %d model(s) from %s",
            len(model_list),
            path,
        )

    async def acompletion(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float = 0,
        **kwargs: Any,
    ) -> Any:
        if self._router is not None:
            return await self._router.acompletion(
                model=model,
                messages=messages,
                temperature=temperature,
                **kwargs,
            )
        return await litellm.acompletion(
            model=model,
            messages=messages,
            temperature=temperature,
            timeout=self._config.timeout_seconds,
            num_retries=self._config.max_retries,
            **kwargs,
        )
