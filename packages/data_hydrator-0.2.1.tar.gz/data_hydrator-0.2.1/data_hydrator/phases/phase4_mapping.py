import asyncio
import logging
from bs4 import BeautifulSoup
from data_hydrator.models import SegmentedPage, SegmentRecord
from segment_classifier.models import ClassifiedSegment, ComponentType, ClassificationStage
from component_mapper import MapperPipeline
from component_mapper.models import MappedComponent

try:
    from component_mapper.config import MapperSettings as _MapperSettings
    _HAS_MAPPER_SETTINGS = True
except ImportError:
    _HAS_MAPPER_SETTINGS = False

from data_hydrator.config import HydrationSettings
from data_hydrator.io.phase_cache import PhaseCache
from data_hydrator.models import MappedPageOutput

logger = logging.getLogger(__name__)


class Phase4Mapping:

    def __init__(self, settings: HydrationSettings, cache: PhaseCache):
        self.settings = settings
        self.cache = cache
        self._mapper = self._build_mapper()

    @staticmethod
    def _build_mapper() -> MapperPipeline:
        if _HAS_MAPPER_SETTINGS:
            try:
                return MapperPipeline(_MapperSettings())
            except Exception:
                pass
        # Try with no args first, then with a bare default settings object
        try:
            return MapperPipeline()
        except TypeError:
            # Real package requires positional settings — try common patterns
            for attr in ("MapperSettings", "Settings"):
                try:
                    import component_mapper.config as _cfg
                    cls = getattr(_cfg, attr, None)
                    if cls is not None:
                        return MapperPipeline(cls())
                except Exception:
                    pass
            raise

    async def run(
        self,
        classified: dict[str, SegmentedPage],
    ) -> dict[str, list[MappedComponent] | Exception]:
        # Resume: separate cached vs uncached
        cached_results: dict[str, list[MappedComponent]] = {}
        uncached: dict[str, SegmentedPage] = {}

        for slug, page in classified.items():
            if (
                self.settings.resume.skip_mapping_if_cached
                and await self.cache.exists(4, slug)
            ):
                try:
                    output = await self.cache.read_mapped(slug)
                    cached_results[slug] = [
                        MappedComponent(**d) for d in output.mapped_components
                    ]
                except Exception as exc:
                    logger.warning("Failed to read mapped cache for %s: %s", slug, exc)
                    uncached[slug] = page
            else:
                uncached[slug] = page

        logger.info(
            "Phase 4: %d from cache, %d to map",
            len(cached_results), len(uncached),
        )

        if not uncached:
            return cached_results

        # Build ClassifiedSegment list from all uncached pages (flat, all depths)
        classified_segs: list[ClassifiedSegment] = []
        slug_for_seg: dict[str, str] = {}

        for slug, page in uncached.items():
            self._collect_segments(page, slug, classified_segs, slug_for_seg)

        # Run mapper in one batch
        try:
            mapped_list = await self._mapper.run(classified_segs)
        except Exception as exc:
            logger.error("MapperPipeline failed: %s", exc)
            mapped_list = []

        # Group MappedComponents by page_slug
        by_slug: dict[str, list[MappedComponent]] = {slug: [] for slug in uncached}
        for m in mapped_list:
            if m.page_slug in by_slug:
                by_slug[m.page_slug].append(m)

        # Write + collect
        new_results: dict[str, list[MappedComponent] | Exception] = {}
        for slug, components in by_slug.items():
            try:
                page = uncached[slug]
                output = MappedPageOutput(
                    page_slug=slug,
                    page_url=page.url,
                    mapped_components=[c.model_dump() for c in components],
                )
                await self.cache.write_mapped(slug, output)
                new_results[slug] = components
            except Exception as exc:
                logger.error("Failed to write mapped page %s: %s", slug, exc)
                new_results[slug] = exc

        return {**cached_results, **new_results}

    def _collect_segments(
        self,
        page: SegmentedPage,
        page_slug: str,
        out: list[ClassifiedSegment],
        slug_map: dict[str, str],
    ) -> None:
        def _walk(segs: list[SegmentRecord]) -> None:
            for seg in segs:
                out.append(self._to_classified_segment(seg, page, page_slug))
                slug_map[seg.id] = page_slug
                if seg.children:
                    _walk(seg.children)

        _walk(page.segments)

    def _to_classified_segment(
        self,
        seg: SegmentRecord,
        page: SegmentedPage,
        page_slug: str,
    ) -> ClassifiedSegment:
        try:
            text = BeautifulSoup(seg.html, "lxml").get_text(strip=True)
        except Exception:
            text = ""

        try:
            ctype = ComponentType(seg.type) if seg.type else ComponentType.UNKNOWN
        except ValueError:
            ctype = ComponentType.UNKNOWN

        return ClassifiedSegment(
            segment_id=seg.id,
            page_url=page.url,
            page_slug=page_slug,
            raw_html=seg.html,
            text_content=text,
            component_type=ctype,
            classification_stage=ClassificationStage.L1_EXACT_CACHE,
            fingerprint_hash=seg.id,
            dom_position=seg.dom_position,
            confidence=seg.confidence,
        )
