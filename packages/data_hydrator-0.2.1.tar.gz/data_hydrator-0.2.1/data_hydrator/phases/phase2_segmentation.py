import asyncio
import logging
import uuid
from bs4 import BeautifulSoup, Tag

from page_segmenter import find_segments_from_html
from data_hydrator.config import HydrationSettings
from data_hydrator.io.phase_cache import PhaseCache
from data_hydrator.io.page_loader import PageLoader
from data_hydrator.models import SegmentRecord, SegmentedPage

logger = logging.getLogger(__name__)


class Phase2Segmentation:

    def __init__(
        self,
        settings: HydrationSettings,
        cache: PhaseCache,
        loader: PageLoader,
    ):
        self.settings = settings
        self.cache = cache
        self._loader = loader
        self._sem = asyncio.Semaphore(settings.segmenter.max_concurrent_pages)
        self._cached_count = 0
        self._segmented_count = 0

    async def run(
        self,
        page_slugs: list[str],
    ) -> dict[str, SegmentedPage | Exception]:
        results = await asyncio.gather(
            *[self._process_one(slug) for slug in page_slugs],
            return_exceptions=True,
        )
        output = {slug: result for slug, result in zip(page_slugs, results)}
        logger.info(
            "Phase 2: %d from cache, %d newly segmented, %d failed",
            self._cached_count,
            self._segmented_count,
            sum(1 for v in output.values() if isinstance(v, Exception)),
        )
        return output

    async def _process_one(self, page_slug: str) -> SegmentedPage:
        if (
            self.settings.resume.skip_segmentation_if_cached
            and await self.cache.exists(2, page_slug)
        ):
            self._cached_count += 1
            return await self.cache.read_segmented(page_slug)

        async with self._sem:
            raw = await self._loader.load_raw(page_slug)
            html: str = raw["html"]
            page_url: str = raw.get("url", "")

            loop = asyncio.get_event_loop()
            seg_dicts = await loop.run_in_executor(
                None, find_segments_from_html, html, page_url, "unknown"
            )

        soup = BeautifulSoup(html, "lxml")
        segments = [self._dict_to_record(d, soup) for d in seg_dicts]

        page = SegmentedPage(
            url=page_url,
            html=html,
            scraped_at=raw.get("scraped_at", ""),
            title=raw.get("title", ""),
            segments=segments,
        )
        page.build_index()
        await self.cache.write_segmented(page_slug, page)
        self._segmented_count += 1
        return page

    def _dict_to_record(self, d: dict, soup: BeautifulSoup) -> SegmentRecord:
        selector = d.get("selector", "")
        html_snippet = self._extract_html(soup, selector)
        children = [self._dict_to_record(c, soup) for c in d.get("children", [])]
        # identityScore from real page-segmenter is 0-100; normalise to 0-1
        raw_score = d.get("identityScore", 0)
        confidence = min(1.0, max(0.0, raw_score / 100.0))
        return SegmentRecord(
            id=str(uuid.uuid4()),
            html=html_snippet,
            dom_position=selector,
            type=d.get("role", ""),
            confidence=confidence,
            children=children,
        )

    def _extract_html(self, soup: BeautifulSoup, selector: str) -> str:
        if not selector:
            return ""
        try:
            el = soup.select_one(selector)
            return str(el) if el else ""
        except Exception:
            return ""
