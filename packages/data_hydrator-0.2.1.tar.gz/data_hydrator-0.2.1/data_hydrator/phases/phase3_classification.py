import asyncio
import logging
from urllib.parse import urlparse
from bs4 import BeautifulSoup
from data_hydrator.models import SegmentedPage, SegmentRecord
from segment_classifier import ClassifierPipeline
from segment_classifier.config import ClassifierSettings
from segment_classifier.models import InputSegment, SegmentPosition

try:
    from segment_classifier.config import CacheConfig, LiteLLMConfig
    _HAS_NESTED_CONFIG = True
except ImportError:
    _HAS_NESTED_CONFIG = False

from data_hydrator.config import HydrationSettings
from data_hydrator.io.phase_cache import PhaseCache

logger = logging.getLogger(__name__)


class Phase3Classification:

    def __init__(self, settings: HydrationSettings, cache: PhaseCache):
        self.settings = settings
        self.cache = cache
        cfg = settings.classifier
        self._classifier = ClassifierPipeline(self._build_settings(cfg))

    @staticmethod
    def _build_settings(cfg) -> ClassifierSettings:
        if _HAS_NESTED_CONFIG:
            return ClassifierSettings(
                rule_based_confidence_threshold=cfg.rule_based_confidence_threshold,
                cache=CacheConfig(
                    l1_cache_path=cfg.l1_cache_path,
                    l2_cache_path=cfg.l2_cache_path,
                ),
                litellm=LiteLLMConfig(
                    batch_size=cfg.litellm_batch_size,
                    max_concurrent_batches=cfg.max_concurrent_batches,
                ),
            )
        # Real package: try flat kwargs, fall back to defaults
        try:
            return ClassifierSettings(
                rule_based_confidence_threshold=cfg.rule_based_confidence_threshold,
            )
        except TypeError:
            return ClassifierSettings()

    async def run(
        self,
        segmented: dict[str, SegmentedPage],
    ) -> dict[str, SegmentedPage | Exception]:
        # Resume: separate cached vs uncached pages
        cached_results: dict[str, SegmentedPage] = {}
        uncached: dict[str, SegmentedPage] = {}

        for slug, page in segmented.items():
            if (
                self.settings.resume.skip_classification_if_cached
                and await self.cache.exists(3, slug)
            ):
                try:
                    cached_results[slug] = await self.cache.read_classified(slug)
                except Exception as exc:
                    logger.warning("Failed to read classified cache for %s: %s", slug, exc)
                    uncached[slug] = page
            else:
                uncached[slug] = page

        logger.info(
            "Phase 3: %d from cache, %d to classify",
            len(cached_results), len(uncached),
        )

        if not uncached:
            return cached_results

        # Build InputSegment list for all uncached pages (flat, all depths)
        input_segments: list[InputSegment] = []
        slug_for_seg: dict[str, str] = {}  # segment_id → page_slug

        for slug, page in uncached.items():
            self._collect_segments(page, slug, input_segments, slug_for_seg)

        # Run classifier in one batch
        try:
            classified = await self._classifier.run(input_segments)
        except Exception as exc:
            logger.error("ClassifierPipeline failed: %s", exc)
            classified = []

        # Map component_type back onto SegmentRecord.type
        for cs in classified:
            page_slug = slug_for_seg.get(cs.segment_id)
            if page_slug is None:
                continue
            page = uncached.get(page_slug)
            if page is None:
                continue
            seg = page.get_segment(cs.segment_id)
            if seg is not None:
                seg.type = cs.component_type.value

        # Write + collect results
        new_results: dict[str, SegmentedPage | Exception] = {}
        for slug, page in uncached.items():
            try:
                await self.cache.write_classified(slug, page)
                new_results[slug] = page
            except Exception as exc:
                logger.error("Failed to write classified page %s: %s", slug, exc)
                new_results[slug] = exc

        return {**cached_results, **new_results}

    def _collect_segments(
        self,
        page: SegmentedPage,
        page_slug: str,
        out: list[InputSegment],
        slug_map: dict[str, str],
    ) -> None:
        def _walk(segs: list[SegmentRecord]) -> None:
            for seg in segs:
                out.append(self._to_input_segment(seg, page, page_slug))
                slug_map[seg.id] = page_slug
                if seg.children:
                    _walk(seg.children)

        _walk(page.segments)

    def _to_input_segment(
        self,
        seg: SegmentRecord,
        page: SegmentedPage,
        page_slug: str,
    ) -> InputSegment:
        try:
            text = BeautifulSoup(seg.html, "lxml").get_text(strip=True)
        except Exception:
            text = ""
        try:
            path_parts = urlparse(page.url).path.strip("/").split("/")
        except Exception:
            path_parts = []

        return InputSegment(
            segment_id=seg.id,
            page_url=page.url,
            page_slug=page_slug,
            raw_html=seg.html,
            text_content=text,
            dom_position=seg.dom_position,
            position_hint=self._infer_position_hint(seg.dom_position),
            sibling_count=0,
            url_path_segments=path_parts,
        )

    def _infer_position_hint(self, dom_position: str) -> SegmentPosition:
        dp = dom_position.lower()
        if "header" in dp:
            return SegmentPosition.TOP
        if "footer" in dp:
            return SegmentPosition.BOTTOM
        if ":nth-child(1)" in dp and dp.count(">") <= 1:
            return SegmentPosition.TOP
        return SegmentPosition.MIDDLE
