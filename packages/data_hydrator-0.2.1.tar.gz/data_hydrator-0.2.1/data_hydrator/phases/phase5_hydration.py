from __future__ import annotations

import asyncio
import logging
import uuid
from collections import defaultdict
from datetime import datetime, timezone

from data_hydrator.models import SegmentedPage, SegmentRecord
from component_mapper.models import MappedComponent
from segment_classifier.models import ComponentType

from data_hydrator.config import HydrationSettings
from data_hydrator.models import (
    CategoryMap, CollectionEntry, EntryStatus,
    ExtractionTrack, HydrationResult, ImageUploadResult,
    RedirectEntry, RedirectMap, SegmentExtractionResult,
)
from data_hydrator.schema.representative_picker import pick_representatives, ComponentPair
from data_hydrator.schema.schema_generator import SchemaGenerator
from data_hydrator.schema.schema_cache import SchemaCache
from data_hydrator.extraction.field_extractor import extract_fields
from data_hydrator.extraction.content_extractor import extract_content
from data_hydrator.extraction.unknown_extractor import UnknownExtractor
from data_hydrator.urls.category_inferrer import infer_categories
from data_hydrator.urls.url_generator import URLGenerator
from data_hydrator.urls.redirect_builder import write_redirects
from data_hydrator.media.image_processor import ImageProcessor
from data_hydrator.collection.entry_builder import build_entry
from data_hydrator.manifest.manifest_builder import build_manifest
from data_hydrator.io.staging_writer import StagingWriter

logger = logging.getLogger(__name__)

_UNKNOWN_VALUE = ComponentType.UNKNOWN.value


class Phase5Hydration:

    def __init__(
        self,
        settings: HydrationSettings,
        schema_cache: SchemaCache,
        schema_generator: SchemaGenerator,
        unknown_extractor: UnknownExtractor,
        image_processor: ImageProcessor,
        url_generator: URLGenerator,
        staging_writer: StagingWriter,
    ):
        self._s = settings
        self._schema_cache = schema_cache
        self._schema_gen = schema_generator
        self._unknown_extractor = unknown_extractor
        self._image_processor = image_processor
        self._url_gen = url_generator
        self._writer = staging_writer

    async def run(
        self,
        mapped_by_page: dict[str, list[MappedComponent]],
        classified_pages: dict[str, SegmentedPage],
    ) -> HydrationResult:
        s = self._s
        run_id = str(uuid.uuid4())

        # ── Flatten all (mapped, seg) pairs ──────────────────────────────────
        all_pairs: list[ComponentPair] = []
        failed_segments: list[str] = []

        for page_slug, components in mapped_by_page.items():
            page = classified_pages.get(page_slug)
            if page is None:
                for m in components:
                    failed_segments.append(m.segment_id)
                continue
            for m in components:
                seg = page.get_segment(m.segment_id)
                if seg is None:
                    logger.warning("Segment %s not found in classified page %s", m.segment_id, page_slug)
                    failed_segments.append(m.segment_id)
                    continue
                all_pairs.append((m, seg))

        # ── Separate tracks ───────────────────────────────────────────────────
        known_pairs:   list[ComponentPair] = []
        content_pairs: list[ComponentPair] = []
        unknown_pairs: list[ComponentPair] = []

        for pair in all_pairs:
            m, _ = pair
            if m.component_type == _UNKNOWN_VALUE:
                unknown_pairs.append(pair)
            elif self._is_content_type(m.component_type):
                content_pairs.append(pair)
            else:
                known_pairs.append(pair)

        logger.info(
            "Phase 5 — known: %d, content: %d, unknown: %d",
            len(known_pairs), len(content_pairs), len(unknown_pairs),
        )

        # ── Schema generation ─────────────────────────────────────────────────
        all_kc_pairs = known_pairs + content_pairs
        unique_types = list({m.component_type for m, _ in all_kc_pairs})

        cached_schemas: dict = {}
        uncached_types: list[str] = []
        for ctype in unique_types:
            existing = self._schema_cache.get(ctype)
            if existing:
                cached_schemas[ctype] = existing
            else:
                uncached_types.append(ctype)
                self._schema_cache.record_miss()

        llm_calls_schema_gen = 0
        schemas_generated = 0
        if uncached_types:
            uncached_pairs = [p for p in all_kc_pairs if p[0].component_type in uncached_types]
            reps = pick_representatives(uncached_pairs, n=s.schema_gen.representatives_per_type)
            new_schemas = await self._schema_gen.generate(reps)
            await self._schema_cache.save_many(new_schemas)
            for schema in new_schemas.values():
                self._schema_cache.set(schema)
            cached_schemas.update(new_schemas)
            schemas_generated = len(new_schemas)
            llm_calls_schema_gen = 1 if new_schemas else 0

        schema_cache_hits = self._schema_cache.hit_count

        # ── Category inference ────────────────────────────────────────────────
        type_urls: dict[str, list[str]] = defaultdict(list)
        for m, _ in all_kc_pairs:
            type_urls[m.component_type].append(m.page_url)

        category_maps: dict[str, CategoryMap] = {
            ctype: infer_categories(urls, ctype, s.url_gen)
            for ctype, urls in type_urls.items()
        }

        # ── Process known + content (concurrent) ─────────────────────────────
        semaphore = asyncio.Semaphore(s.max_concurrent_segments)
        all_entries:            list[CollectionEntry]        = []
        all_extraction_results: list[SegmentExtractionResult] = []
        all_image_results:      list[ImageUploadResult]       = []
        redirect_entries:       list[RedirectEntry]           = []

        async def process_known_content(pair: ComponentPair) -> None:
            m, seg = pair
            async with semaphore:
                schema = cached_schemas.get(m.component_type)
                if schema is None:
                    logger.warning("No schema for %s, skipping %s", m.component_type, m.segment_id)
                    failed_segments.append(m.segment_id)
                    return

                track = (
                    ExtractionTrack.CONTENT
                    if self._is_content_type(m.component_type)
                    else ExtractionTrack.KNOWN
                )

                page = classified_pages.get(m.page_slug)
                page_title = page.title if page else ""
                page_url = m.page_url

                if track == ExtractionTrack.CONTENT:
                    fields, body_md, missing = extract_content(
                        seg.html, schema, page_url, s.content
                    )
                else:
                    fields, missing = extract_fields(seg.html, schema, page_url)
                    body_md = ""

                image_urls = [
                    f.processed_value
                    for f in fields
                    if f.content_type == "image_url" and f.extraction_success and f.processed_value
                ]
                collection_name = self._get_collection_name(m.component_type)
                img_results = await self._image_processor.process_images(
                    image_urls, collection_name, page_url
                )
                all_image_results.extend(img_results)

                status = EntryStatus.DRAFT if missing else EntryStatus.COMPLETE
                extraction_result = SegmentExtractionResult(
                    segment_id=m.segment_id,
                    page_url=page_url,
                    component_type=m.component_type,
                    track=track,
                    extracted_fields=fields,
                    image_results=img_results,
                    missing_required_fields=missing,
                    status=status,
                )
                all_extraction_results.append(extraction_result)

                cat_map = category_maps.get(m.component_type, CategoryMap(
                    component_type=m.component_type,
                    base_path=s.url_gen.type_base_paths.get(
                        m.component_type, f"/{m.component_type.split('.')[-1]}"
                    ),
                ))
                title = next(
                    (f.processed_value for f in fields
                     if f.field_name in ("title", "name", "heading") and f.extraction_success),
                    None,
                ) or page_title or ""

                generated_url = self._url_gen.generate(
                    str(title), m.component_type, m.page_url, cat_map
                )
                slug = generated_url.rstrip("/").split("/")[-1]

                entry = build_entry(
                    extraction_result=extraction_result,
                    image_results=img_results,
                    slug=slug,
                    collection_name=collection_name,
                    generated_url=generated_url,
                    original_url=m.page_url,
                    page_title=page_title,
                    settings=s,
                )
                if track == ExtractionTrack.CONTENT and body_md:
                    entry = entry.model_copy(update={"body_markdown": body_md})

                all_entries.append(entry)
                redirect_entries.append(RedirectEntry(
                    original_url=m.page_url,
                    new_url=generated_url,
                    component_type=m.component_type,
                    slug=slug,
                ))

        await asyncio.gather(*(process_known_content(p) for p in all_kc_pairs))

        # ── Process unknown (LLM batch) ───────────────────────────────────────
        unknown_items = [(m, seg.html) for m, seg in unknown_pairs]
        unknown_results = await self._unknown_extractor.extract_batch(unknown_items)
        llm_calls_unknown = len(unknown_items)

        m_by_id = {m.segment_id: m for m, _ in unknown_pairs}
        for result in unknown_results:
            all_extraction_results.append(result)
            if result.status == EntryStatus.FAILED:
                failed_segments.append(result.segment_id)
                continue

            m = m_by_id.get(result.segment_id)
            if m is None:
                continue

            collection_name = self._get_collection_name(result.component_type)
            title = next(
                (f.processed_value for f in result.extracted_fields
                 if f.field_name in ("title", "name") and f.extraction_success),
                None,
            ) or ""

            page = classified_pages.get(m.page_slug)
            cat_map = CategoryMap(
                component_type=result.component_type,
                base_path=s.url_gen.type_base_paths.get(
                    result.component_type, f"/{result.component_type.split('.')[-1]}"
                ),
            )
            generated_url = self._url_gen.generate(
                str(title), result.component_type, m.page_url, cat_map
            )
            slug = generated_url.rstrip("/").split("/")[-1]

            entry = build_entry(
                extraction_result=result,
                image_results=[],
                slug=slug,
                collection_name=collection_name,
                generated_url=generated_url,
                original_url=m.page_url,
                page_title=page.title if page else "",
                settings=s,
            )
            all_entries.append(entry)
            redirect_entries.append(RedirectEntry(
                original_url=m.page_url,
                new_url=generated_url,
                component_type=result.component_type,
                slug=slug,
            ))

        # ── Write entries ─────────────────────────────────────────────────────
        written_files = await self._writer.write_many(all_entries)

        # ── Write redirects ───────────────────────────────────────────────────
        json_path, csv_path = await write_redirects(
            redirect_entries, s.site_id, s.dirs.staging_dir, s.staging
        )

        # ── Build + write manifest ────────────────────────────────────────────
        manifest = build_manifest(
            run_id=run_id,
            site_id=s.site_id,
            classified_dir=s.dirs.classified_dir,
            staging_dir=s.dirs.staging_dir,
            written_files=written_files,
            all_extraction_results=all_extraction_results,
            all_image_results=all_image_results,
            schemas_generated=schemas_generated,
            schema_cache_hits=schema_cache_hits,
            llm_calls_schema_gen=llm_calls_schema_gen,
            llm_calls_unknown=llm_calls_unknown,
            warnings=[],
        )
        manifest_path = await self._writer.write_manifest(manifest)

        redirect_map = RedirectMap(
            site_url=s.site_id,
            generated_at=datetime.now(timezone.utc).isoformat(),
            total=len(redirect_entries),
            entries=redirect_entries,
        )

        return HydrationResult(
            manifest=manifest,
            written_files=written_files,
            redirect_map=redirect_map,
            failed_segments=failed_segments,
            staging_root=s.dirs.staging_dir,
            manifest_path=manifest_path,
            redirects_json_path=json_path,
            redirects_csv_path=csv_path,
        )

    def _is_content_type(self, component_type: str) -> bool:
        return any(
            component_type.startswith(p)
            for p in self._s.content_type_prefixes
        )

    def _get_collection_name(self, component_type: str) -> str:
        for prefix, base_path in self._s.url_gen.type_base_paths.items():
            if component_type == prefix or component_type.startswith(
                prefix.rstrip(".")
            ):
                return base_path.strip("/")
        return "misc"
