import asyncio
import logging
import aiofiles
from datetime import datetime, timezone
from pathlib import Path
from data_hydrator.models import (
    CollectionEntry, CollectionFormat, EntryStatus,
    WrittenFile, BackupRecord, HydrationManifest,
)
from data_hydrator.config import StagingConfig
from data_hydrator.collection.serializer import serialize

logger = logging.getLogger(__name__)


class StagingWriter:

    def __init__(self, staging_dir: str, config: StagingConfig):
        self._root = Path(staging_dir)
        self._config = config

    def _entry_path(self, entry: CollectionEntry) -> Path:
        ext = ".md" if entry.format == CollectionFormat.MARKDOWN else ".json"
        return (
            self._root
            / self._config.astro_content_prefix
            / entry.collection_name
            / f"{entry.slug}{ext}"
        )

    async def write(self, entry: CollectionEntry) -> WrittenFile:
        path = self._entry_path(entry)
        backup: BackupRecord | None = None

        try:
            path.parent.mkdir(parents=True, exist_ok=True)

            if path.exists() and self._config.create_backup_on_overwrite:
                backup = await self._backup(path)

            content = serialize(entry)
            async with aiofiles.open(path, "w", encoding="utf-8") as f:
                await f.write(content)

            rel_path = str(path.relative_to(self._root))
            status = EntryStatus.DRAFT if entry.draft else EntryStatus.COMPLETE
            return WrittenFile(
                file_path=rel_path,
                collection=entry.collection_name,
                slug=entry.slug,
                format=entry.format,
                status=status,
                draft=entry.draft,
                segment_id=entry.source_segment_id,
                page_url=entry.source_page_url,
                generated_url=entry.generated_url,
                backup=backup,
            )
        except Exception as exc:
            logger.error("Failed to write entry %s: %s", entry.slug, exc)
            rel_path = str(path.relative_to(self._root)) if path else entry.slug
            return WrittenFile(
                file_path=rel_path,
                collection=entry.collection_name,
                slug=entry.slug,
                format=entry.format,
                status=EntryStatus.FAILED,
                draft=entry.draft,
                segment_id=entry.source_segment_id,
                page_url=entry.source_page_url,
                generated_url=entry.generated_url,
                backup=backup,
                warnings=[str(exc)],
            )

    async def write_many(self, entries: list[CollectionEntry]) -> list[WrittenFile]:
        return list(await asyncio.gather(*(self.write(e) for e in entries)))

    async def write_manifest(self, manifest: HydrationManifest) -> str:
        path = self._root / self._config.manifest_filename
        path.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(path, "w", encoding="utf-8") as f:
            await f.write(manifest.model_dump_json(indent=2))
        logger.info("Manifest written to %s", path)
        return str(path)

    async def _backup(self, path: Path) -> BackupRecord:
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        backup_path = path.with_suffix(f".{ts}.bak{path.suffix}")
        async with aiofiles.open(path, "rb") as src:
            data = await src.read()
        async with aiofiles.open(backup_path, "wb") as dst:
            await dst.write(data)
        return BackupRecord(
            original_path=str(path),
            backup_path=str(backup_path),
            created_at=datetime.now(timezone.utc).isoformat(),
        )
