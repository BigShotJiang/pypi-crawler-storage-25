import asyncio
import json
import logging
import aiofiles
from pathlib import Path
from data_hydrator.models import SegmentedPage
from data_hydrator.models import MappedPageOutput
from data_hydrator.config import PipelineDirsConfig

logger = logging.getLogger(__name__)


class PhaseCache:

    def __init__(self, config: PipelineDirsConfig):
        self._dirs = config
        self._sem = asyncio.Semaphore(20)

    def _path(self, phase: int, page_slug: str) -> Path:
        phase_dir = {
            2: self._dirs.segmented_dir,
            3: self._dirs.classified_dir,
            4: self._dirs.mapped_dir,
        }[phase]
        return Path(phase_dir) / f"{page_slug}.json"

    async def exists(self, phase: int, page_slug: str) -> bool:
        return self._path(phase, page_slug).exists()

    # ── Phase 2: SegmentedPage ───────────────────────────────────────────────

    async def read_segmented(self, page_slug: str) -> SegmentedPage:
        return await self._read_segmented_page(2, page_slug)

    async def write_segmented(self, page_slug: str, page: SegmentedPage) -> None:
        await self._write_json(2, page_slug, page.model_dump())

    # ── Phase 3: SegmentedPage (type populated) ──────────────────────────────

    async def read_classified(self, page_slug: str) -> SegmentedPage:
        return await self._read_segmented_page(3, page_slug)

    async def write_classified(self, page_slug: str, page: SegmentedPage) -> None:
        await self._write_json(3, page_slug, page.model_dump())

    # ── Phase 4: MappedPageOutput ────────────────────────────────────────────

    async def read_mapped(self, page_slug: str) -> MappedPageOutput:
        path = self._path(4, page_slug)
        async with aiofiles.open(path, encoding="utf-8") as f:
            data = json.loads(await f.read())
        return MappedPageOutput.model_validate(data)

    async def write_mapped(self, page_slug: str, output: MappedPageOutput) -> None:
        await self._write_json(4, page_slug, output.model_dump())

    # ── Bulk loaders ─────────────────────────────────────────────────────────

    async def read_many_segmented(
        self, slugs: list[str]
    ) -> dict[str, SegmentedPage | Exception]:
        return await self._read_many(slugs, self.read_segmented)

    async def read_many_classified(
        self, slugs: list[str]
    ) -> dict[str, SegmentedPage | Exception]:
        return await self._read_many(slugs, self.read_classified)

    async def read_many_mapped(
        self, slugs: list[str]
    ) -> dict[str, MappedPageOutput | Exception]:
        return await self._read_many(slugs, self.read_mapped)

    # ── Helpers ──────────────────────────────────────────────────────────────

    async def _read_segmented_page(self, phase: int, page_slug: str) -> SegmentedPage:
        path = self._path(phase, page_slug)
        async with aiofiles.open(path, encoding="utf-8") as f:
            data = json.loads(await f.read())
        page = SegmentedPage.model_validate(data)
        page.build_index()
        return page

    async def _write_json(self, phase: int, page_slug: str, data: dict) -> None:
        path = self._path(phase, page_slug)
        path.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(path, "w", encoding="utf-8") as f:
            await f.write(json.dumps(data, indent=2, default=str))

    async def _read_many(self, slugs: list[str], reader) -> dict:
        async def _safe(slug: str):
            async with self._sem:
                try:
                    return slug, await reader(slug)
                except Exception as exc:
                    logger.warning("Cache read failed for %s: %s", slug, exc)
                    return slug, exc

        pairs = await asyncio.gather(*(_safe(s) for s in slugs))
        return dict(pairs)
