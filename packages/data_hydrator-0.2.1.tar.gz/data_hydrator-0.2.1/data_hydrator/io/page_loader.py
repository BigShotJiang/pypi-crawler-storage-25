import asyncio
import json
import logging
import aiofiles
from pathlib import Path
from data_hydrator.config import HydrationSettings

logger = logging.getLogger(__name__)


class PageNotFoundError(Exception):
    pass


class PageParseError(Exception):
    pass


class PageLoader:
    """
    Loads raw scraped page JSON files from scrape_output/.
    Returns plain dict — NOT a Pydantic model.
    """

    def __init__(self, settings: HydrationSettings):
        self._scrape_dir = Path(settings.dirs.scrape_dir)
        self._sem = asyncio.Semaphore(20)
        self._cache: dict[str, dict] = {}

    async def load_raw(self, page_slug: str) -> dict:
        if page_slug in self._cache:
            return self._cache[page_slug]

        path = self._scrape_dir / f"{page_slug}.json"
        if not path.exists():
            raise PageNotFoundError(f"Page file not found: {path}")

        try:
            async with aiofiles.open(path, encoding="utf-8") as f:
                text = await f.read()
            data = json.loads(text)
        except PageNotFoundError:
            raise
        except Exception as exc:
            raise PageParseError(f"Failed to parse {page_slug}: {exc}") from exc

        if "html" not in data:
            raise PageParseError(f"Page {page_slug} missing 'html' key")

        self._cache[page_slug] = data
        logger.debug("Loaded raw page %s", page_slug)
        return data

    async def load_many_raw(
        self,
        page_slugs: list[str],
    ) -> dict[str, dict | Exception]:
        unique = list(dict.fromkeys(page_slugs))

        async def _safe(slug: str) -> tuple[str, dict | Exception]:
            async with self._sem:
                try:
                    return slug, await self.load_raw(slug)
                except Exception as exc:
                    logger.warning("Failed to load page %s: %s", slug, exc)
                    return slug, exc

        pairs = await asyncio.gather(*(_safe(s) for s in unique))
        return dict(pairs)

    def discover_slugs(self) -> list[str]:
        if not self._scrape_dir.exists():
            return []
        return sorted(p.stem for p in self._scrape_dir.glob("*.json"))
