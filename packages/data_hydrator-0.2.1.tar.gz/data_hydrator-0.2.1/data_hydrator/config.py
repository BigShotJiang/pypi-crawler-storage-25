from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict


class PipelineDirsConfig(BaseModel):
    scrape_dir:     str = "./scrape_output"
    segmented_dir:  str = "./segmented"
    classified_dir: str = "./classified"
    mapped_dir:     str = "./mapped"
    staging_dir:    str = "./staging"


class ResumeConfig(BaseModel):
    skip_segmentation_if_cached:   bool = True
    skip_classification_if_cached: bool = True
    skip_mapping_if_cached:        bool = True


class SegmenterConfig(BaseModel):
    use_llm: bool = True
    llm_model: str = "anthropic/claude-haiku-4-5"
    llm_confidence_threshold: float = 0.7
    max_concurrent_pages: int = 10


class ClassifierConfig(BaseModel):
    rule_based_confidence_threshold: float = 0.90
    l1_cache_path: str = ".cache/l1_fingerprints.json"
    l2_cache_path: str = ".cache/l2_clusters.json"
    litellm_batch_size: int = 20
    max_concurrent_batches: int = 5


class MapperConfig(BaseModel):
    mcp_transport: str = "stdio"
    signature_index_cache_path: str = ".cache/signature_index.json"
    custom_registry_path: str = ".cache/custom_registry.json"
    litellm_batch_size: int = 15


class SchemaGenConfig(BaseModel):
    # Aliases defined in litellm_config.yaml model_list
    model: str = "schema-gen"
    unknown_model: str = "unknown-extraction"
    litellm_config_path: str = "litellm_config.yaml"
    representatives_per_type: int = 3
    unknown_batch_size: int = 20
    max_concurrent_unknown_batches: int = 5
    # Fallback values used when litellm_config.yaml is absent
    timeout_seconds: int = 60
    max_retries: int = 3
    drop_params: bool = True
    schema_cache_path: str = ".cache/extraction_schemas"


class ContentExtractionConfig(BaseModel):
    markdown_library: str = "markdownify"
    allowed_tags: list[str] = [
        "p", "strong", "em", "b", "i",
        "ul", "ol", "li", "h1", "h2", "h3", "h4", "h5",
        "a", "blockquote", "code", "pre",
        "table", "thead", "tbody", "tr", "th", "td", "img",
    ]
    always_strip_tags: list[str] = [
        "script", "style", "iframe", "noscript",
        "nav", "header", "footer", "aside",
    ]


class URLGenConfig(BaseModel):
    type_base_paths: dict[str, str] = {
        "collection.product_card": "/products",
        "collection.product_list": "/products",
        "collection.blog_card":    "/blog",
        "collection.blog_list":    "/blog",
        "collection.news_item":    "/news",
        "content.article":         "/articles",
    }
    category_detection_depth: int = 3
    category_min_occurrence: int = 2
    max_slug_length: int = 80


class StagingConfig(BaseModel):
    astro_content_prefix: str = "src/content"
    astro_pages_prefix: str = "src/pages/_data"
    create_backup_on_overwrite: bool = True
    manifest_filename: str = "hydration_manifest.json"
    redirects_json_filename: str = "redirects.json"
    redirects_csv_filename: str = "redirects.csv"


class R2Config(BaseModel):
    bucket_name: str = ""
    endpoint_url: str = ""
    access_key_id: str = ""
    secret_access_key: str = ""
    public_base_url: str = ""
    key_prefix: str = "images"
    max_concurrent_uploads: int = 10
    max_concurrent_downloads: int = 20
    download_timeout_seconds: int = 30
    upload_timeout_seconds: int = 60
    url_cache_path: str = ".cache/image_url_cache.json"


class HydrationSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="HYDRATOR_")

    site_id: str = ""

    dirs:       PipelineDirsConfig      = PipelineDirsConfig()
    resume:     ResumeConfig            = ResumeConfig()
    segmenter:  SegmenterConfig         = SegmenterConfig()
    classifier: ClassifierConfig        = ClassifierConfig()
    mapper:     MapperConfig            = MapperConfig()
    schema_gen: SchemaGenConfig         = SchemaGenConfig()
    content:    ContentExtractionConfig = ContentExtractionConfig()
    url_gen:    URLGenConfig            = URLGenConfig()
    staging:    StagingConfig           = StagingConfig()
    r2:         R2Config                = R2Config()

    content_type_prefixes: list[str] = [
        "content.", "collection.blog", "collection.news",
    ]
    max_concurrent_segments: int = 50
