import re
from collections import defaultdict
from urllib.parse import urlparse
from data_hydrator.models import CategoryMap
from data_hydrator.config import URLGenConfig


class URLGenerator:

    def __init__(self, config: URLGenConfig):
        self.config = config
        self._used_slugs: dict[str, set[str]] = defaultdict(set)

    def generate(
        self,
        title: str,
        component_type: str,
        original_url: str,
        category_map: CategoryMap,
    ) -> str:
        base_path = category_map.base_path or self.config.type_base_paths.get(
            component_type,
            f"/{component_type.split('.')[-1]}",
        )
        base_path = base_path.rstrip("/")
        collection = base_path.lstrip("/")

        slug = self._make_unique(self._slugify(title), collection)
        category = self._get_category(original_url, category_map)

        if category:
            return f"{base_path}/{category}/{slug}"
        return f"{base_path}/{slug}"

    def generate_listing_urls(
        self,
        component_type: str,
        category_map: CategoryMap,
    ) -> list[str]:
        base_path = category_map.base_path or self.config.type_base_paths.get(
            component_type,
            f"/{component_type.split('.')[-1]}",
        )
        base_path = base_path.rstrip("/")
        listing_urls = [f"{base_path}/"]

        for prefix, category in category_map.prefix_to_category.items():
            listing_urls.append(f"{base_path}/{category}/")

        return listing_urls

    def _slugify(self, text: str) -> str:
        if not text:
            return "untitled"
        text = text.lower()
        text = re.sub(r"[^a-z0-9]+", "-", text)
        text = text.strip("-")
        return text[: self.config.max_slug_length] or "untitled"

    def _get_category(self, original_url: str, category_map: CategoryMap) -> str | None:
        if not category_map.prefix_to_category:
            return None
        try:
            path = urlparse(original_url).path
        except Exception:
            return None

        for prefix, category in category_map.prefix_to_category.items():
            if path.startswith(prefix.rstrip("/")) or path.startswith(prefix):
                return category
        return None

    def _make_unique(self, slug: str, collection: str) -> str:
        if slug not in self._used_slugs[collection]:
            self._used_slugs[collection].add(slug)
            return slug
        counter = 2
        while True:
            candidate = f"{slug}-{counter}"
            if candidate not in self._used_slugs[collection]:
                self._used_slugs[collection].add(candidate)
                return candidate
            counter += 1
