import csv
import io
import json
import logging
import aiofiles
from datetime import datetime, timezone
from pathlib import Path
from data_hydrator.models import RedirectEntry, RedirectMap
from data_hydrator.config import StagingConfig

logger = logging.getLogger(__name__)


async def write_redirects(
    entries: list[RedirectEntry],
    site_id: str,
    staging_root: str,
    config: StagingConfig,
) -> tuple[str, str]:
    """Returns (json_path, csv_path)."""
    root = Path(staging_root)
    root.mkdir(parents=True, exist_ok=True)

    json_path = root / config.redirects_json_filename
    csv_path = root / config.redirects_csv_filename

    redirect_map = RedirectMap(
        site_url=site_id,
        generated_at=datetime.now(timezone.utc).isoformat(),
        total=len(entries),
        entries=entries,
    )

    json_content = json.dumps(
        redirect_map.model_dump(),
        indent=2,
        ensure_ascii=False,
        default=str,
    )
    csv_content = _build_csv_content(entries)

    async with aiofiles.open(json_path, "w", encoding="utf-8") as f:
        await f.write(json_content)

    async with aiofiles.open(csv_path, "w", encoding="utf-8", newline="") as f:
        await f.write(csv_content)

    logger.info("Wrote redirects: %s, %s", json_path, csv_path)
    return str(json_path), str(csv_path)


def _build_csv_content(entries: list[RedirectEntry]) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["source_url", "target_url", "status_code", "preserve_query_string"])
    for entry in entries:
        if not entry.original_url:
            continue
        writer.writerow([
            entry.original_url,
            entry.new_url,
            entry.status_code,
            "false",
        ])
    return output.getvalue()
