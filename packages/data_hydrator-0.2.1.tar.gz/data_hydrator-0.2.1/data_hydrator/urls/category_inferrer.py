from collections import Counter
from urllib.parse import urlparse
from data_hydrator.models import CategoryMap
from data_hydrator.config import URLGenConfig


def infer_categories(
    urls: list[str],
    component_type: str,
    config: URLGenConfig,
) -> CategoryMap:
    """Pure function. Infers category structure from URL patterns."""
    base_path = config.type_base_paths.get(component_type, f"/{component_type.split('.')[-1]}")

    if not urls:
        return CategoryMap(component_type=component_type, base_path=base_path)

    all_segments = [_extract_path_segments(url) for url in urls]
    all_segments = [s for s in all_segments if s]

    if not all_segments:
        return CategoryMap(component_type=component_type, base_path=base_path)

    common = _find_common_prefix(all_segments)
    depth = config.category_detection_depth
    category_depth = len(common)

    # Look at the segment right after the common prefix
    candidate_counter: Counter = Counter()
    url_to_candidate: dict[str, str] = {}

    for url, segs in zip(urls, all_segments):
        if len(segs) > category_depth:
            candidate = segs[category_depth]
            candidate_counter[candidate] += 1
            url_to_candidate[url] = candidate

    prefix_to_category: dict[str, str] = {}
    for candidate, count in candidate_counter.items():
        if count >= config.category_min_occurrence:
            # Build the URL prefix for this category
            prefix_parts = common + [candidate]
            prefix = "/" + "/".join(prefix_parts) + "/"
            prefix_to_category[prefix] = candidate

    return CategoryMap(
        component_type=component_type,
        prefix_to_category=prefix_to_category,
        base_path=base_path,
    )


def _extract_path_segments(url: str) -> list[str]:
    try:
        parsed = urlparse(url)
        path = parsed.path.strip("/")
        return [s for s in path.split("/") if s]
    except Exception:
        return []


def _find_common_prefix(paths: list[list[str]]) -> list[str]:
    if not paths:
        return []
    reference = paths[0]
    common: list[str] = []
    for i, segment in enumerate(reference):
        if all(len(p) > i and p[i] == segment for p in paths):
            common.append(segment)
        else:
            break
    return common
