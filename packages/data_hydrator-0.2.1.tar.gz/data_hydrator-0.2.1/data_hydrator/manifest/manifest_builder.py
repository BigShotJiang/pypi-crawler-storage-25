from collections import defaultdict
from datetime import datetime, timezone
from data_hydrator.models import (
    HydrationManifest, WrittenFile, BackupRecord,
    ExtractionTrack, EntryStatus, ImageUploadStatus,
    SegmentExtractionResult, ImageUploadResult,
)


def build_manifest(
    run_id: str,
    site_id: str,
    classified_dir: str,
    staging_dir: str,
    written_files: list[WrittenFile],
    all_extraction_results: list[SegmentExtractionResult],
    all_image_results: list[ImageUploadResult],
    schemas_generated: int,
    schema_cache_hits: int,
    llm_calls_schema_gen: int,
    llm_calls_unknown: int,
    warnings: list[str],
) -> HydrationManifest:
    total_written = sum(1 for f in written_files if f.status != EntryStatus.FAILED)
    total_draft   = sum(1 for f in written_files if f.draft)
    total_failed  = sum(1 for f in written_files if f.status == EntryStatus.FAILED)

    total_uploaded    = sum(1 for r in all_image_results if r.status == ImageUploadStatus.UPLOADED)
    total_cached      = sum(1 for r in all_image_results if r.status == ImageUploadStatus.CACHED)
    total_img_failed  = sum(1 for r in all_image_results if r.status == ImageUploadStatus.FAILED)
    total_img_total   = len(all_image_results)
    hit_rate          = (total_cached / total_img_total) if total_img_total > 0 else 0.0

    track_breakdown: dict[ExtractionTrack, int] = defaultdict(int)
    for result in all_extraction_results:
        track_breakdown[result.track] += 1

    collections: dict[str, int] = defaultdict(int)
    for f in written_files:
        collections[f.collection] += 1

    backups = [f.backup for f in written_files if f.backup is not None]

    return HydrationManifest(
        run_id=run_id,
        site_id=site_id,
        generated_at=datetime.now(timezone.utc).isoformat(),
        classified_dir=classified_dir,
        staging_dir=staging_dir,
        total_segments=len(all_extraction_results),
        total_written=total_written,
        total_draft=total_draft,
        total_failed=total_failed,
        total_images_uploaded=total_uploaded,
        total_images_cached=total_cached,
        total_images_failed=total_img_failed,
        track_breakdown=dict(track_breakdown),
        collections=dict(collections),
        schemas_generated=schemas_generated,
        schema_cache_hits=schema_cache_hits,
        llm_calls_schema_gen=llm_calls_schema_gen,
        llm_calls_unknown=llm_calls_unknown,
        files=written_files,
        backups=backups,
        warnings=warnings,
        image_cache_hit_rate=hit_rate,
    )
