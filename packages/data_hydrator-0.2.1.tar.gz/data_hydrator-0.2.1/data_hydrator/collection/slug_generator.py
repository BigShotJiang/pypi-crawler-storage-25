import re
from collections import defaultdict


class SlugGenerator:

    def __init__(self, max_length: int = 80):
        self._max_length = max_length
        self._used: dict[str, set[str]] = defaultdict(set)

    def generate(self, title: str, collection: str) -> str:
        base = self._slugify(title)
        return self._make_unique(base, collection)

    def _slugify(self, text: str) -> str:
        if not text:
            return "untitled"
        text = text.lower()
        text = re.sub(r"[^a-z0-9]+", "-", text)
        text = text.strip("-")
        return text[: self._max_length] or "untitled"

    def _make_unique(self, slug: str, collection: str) -> str:
        if slug not in self._used[collection]:
            self._used[collection].add(slug)
            return slug
        counter = 2
        while True:
            candidate = f"{slug}-{counter}"
            if candidate not in self._used[collection]:
                self._used[collection].add(candidate)
                return candidate
            counter += 1
