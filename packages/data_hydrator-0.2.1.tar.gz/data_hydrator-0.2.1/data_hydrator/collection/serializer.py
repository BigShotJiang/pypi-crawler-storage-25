import json
import re
import yaml
from data_hydrator.models import CollectionEntry, CollectionFormat


def serialize(entry: CollectionEntry) -> str:
    if entry.format == CollectionFormat.MARKDOWN:
        return _serialize_markdown(entry)
    return _serialize_json(entry)


def _serialize_json(entry: CollectionEntry) -> str:
    payload: dict = {}
    payload["draft"] = entry.draft
    payload["title"] = entry.title
    payload["generatedUrl"] = entry.generated_url
    for k, v in entry.data.items():
        payload[_snake_to_camel(k)] = v
    return json.dumps(payload, indent=2, ensure_ascii=False)


def _serialize_markdown(entry: CollectionEntry) -> str:
    frontmatter: dict = {}
    frontmatter["draft"] = entry.draft
    frontmatter["title"] = entry.title
    frontmatter["generatedUrl"] = entry.generated_url
    for k, v in entry.data.items():
        frontmatter[_snake_to_camel(k)] = v

    yaml_block = _to_yaml_frontmatter(frontmatter)
    body = entry.body_markdown or ""
    return f"---\n{yaml_block}---\n\n{body}\n"


def _to_yaml_frontmatter(data: dict) -> str:
    return yaml.dump(data, default_flow_style=False, allow_unicode=True)


def _snake_to_camel(s: str) -> str:
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])
