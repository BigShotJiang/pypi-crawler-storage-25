from data_hydrator.models import (
    CollectionEntry, CollectionFormat, EntryStatus,
    SegmentExtractionResult, ImageUploadResult, ExtractionTrack,
    ImageUploadStatus,
)
from data_hydrator.config import HydrationSettings


def build_entry(
    extraction_result: SegmentExtractionResult,
    image_results: list[ImageUploadResult],
    slug: str,
    collection_name: str,
    generated_url: str,
    original_url: str,
    page_title: str,
    settings: HydrationSettings,
) -> CollectionEntry:
    # Build CDN URL lookup: original → cdn
    cdn_map: dict[str, str] = {
        r.original_url: r.cdn_url
        for r in image_results
        if r.status in (ImageUploadStatus.UPLOADED, ImageUploadStatus.CACHED)
        and r.cdn_url
    }

    # Build data dict from successful extractions
    data: dict = {}
    body_markdown = ""
    warnings: list[str] = []

    for field in extraction_result.extracted_fields:
        if not field.extraction_success:
            continue
        value = field.processed_value

        # Rewrite image URLs to CDN
        if field.content_type == "image_url" and isinstance(value, str):
            value = cdn_map.get(value, value)
            if value not in cdn_map and field.processed_value and field.processed_value not in cdn_map:
                if field.processed_value:
                    warnings.append(f"Image upload failed for {field.field_name}; keeping original URL")

        data[field.field_name] = value

    # For markdown entries: pop body field from data into body_markdown
    fmt = _resolve_format(extraction_result.component_type, settings)
    if fmt == CollectionFormat.MARKDOWN:
        for body_field in ("body", "content", "description"):
            if body_field in data:
                candidate = data[body_field]
                if isinstance(candidate, str) and len(candidate) > 50:
                    body_markdown = candidate
                    del data[body_field]
                    break
        # Also grab from Track B markdown
        if not body_markdown:
            for field in extraction_result.extracted_fields:
                if field.content_type == "markdown" and field.extraction_success:
                    body_markdown = str(field.processed_value or "")
                    data.pop(field.field_name, None)
                    break

    # Title resolution
    title = (
        data.get("title")
        or data.get("name")
        or data.get("heading")
        or page_title
        or _slug_to_title(slug)
    )

    draft = len(extraction_result.missing_required_fields) > 0

    return CollectionEntry(
        slug=slug,
        collection_name=collection_name,
        format=fmt,
        data=data,
        draft=draft,
        title=str(title),
        body_markdown=body_markdown,
        source_segment_id=extraction_result.segment_id,
        source_page_url=extraction_result.page_url,
        generated_url=generated_url,
        original_url=original_url,
    )


def _resolve_format(component_type: str, settings: HydrationSettings) -> CollectionFormat:
    content_prefixes = ("content.", "collection.blog", "collection.news")
    if any(component_type.startswith(p) for p in content_prefixes):
        return CollectionFormat.MARKDOWN
    return CollectionFormat.JSON


def _slug_to_title(slug: str) -> str:
    return slug.replace("-", " ").title()
