"""
resume_run.py — demonstrates the resume / incremental-update behaviour.

First run:  processes all pages in scrape_output/ through all phases.
Second run: phases 2–4 load from disk cache; only Phase 5 re-runs.

Add new *.json files to scrape_output/ between runs and only those pages
will be re-segmented, re-classified, and re-mapped; the rest come from cache.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python examples/resume_run.py          # first run
    # ... add new pages to scrape_output/
    python examples/resume_run.py          # second run — phases 2-4 mostly cached
"""

import asyncio
import logging

from data_hydrator import HydrationPipeline, HydrationSettings
from data_hydrator.config import ResumeConfig

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")


async def main() -> None:
    settings = HydrationSettings(
        site_id="blog.example.com",
        resume=ResumeConfig(
            skip_segmentation_if_cached=True,
            skip_classification_if_cached=True,
            skip_mapping_if_cached=True,
        ),
    )

    pipeline = HydrationPipeline(settings)
    await pipeline.initialize()
    try:
        result = await pipeline.run()
    finally:
        await pipeline.shutdown()

    m = result.manifest
    print(f"Schema cache hits : {m.schema_cache_hits}  generated: {m.schemas_generated}")
    print(f"Total segments    : {m.total_segments}")
    print(f"Written           : {m.total_written}  draft: {m.total_draft}")
    if m.warnings:
        print(f"Warnings ({len(m.warnings)}):")
        for w in m.warnings:
            print(f"  • {w}")


if __name__ == "__main__":
    asyncio.run(main())
