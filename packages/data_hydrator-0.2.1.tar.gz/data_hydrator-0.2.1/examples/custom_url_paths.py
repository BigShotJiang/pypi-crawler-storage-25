"""
custom_url_paths.py — override the default type→base-path mapping and set
custom extraction schema generation settings.

Useful when a site uses non-standard collection names or URL structures.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python examples/custom_url_paths.py
"""

import asyncio
import logging

from data_hydrator import HydrationPipeline, HydrationSettings
from data_hydrator.config import URLGenConfig, SchemaGenConfig, PipelineDirsConfig

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")


async def main() -> None:
    settings = HydrationSettings(
        site_id="store.example.com",
        dirs=PipelineDirsConfig(
            scrape_dir="./scrape_output",
            staging_dir="./staging",
        ),
        url_gen=URLGenConfig(
            type_base_paths={
                "collection.product_card": "/shop/items",
                "collection.product_list": "/shop/items",
                "collection.blog_card":    "/insights",
                "content.article":         "/insights",
                "collection.news_item":    "/press",
            },
            category_detection_depth=2,
            category_min_occurrence=3,
            max_slug_length=60,
        ),
        schema_gen=SchemaGenConfig(
            model="anthropic/claude-sonnet-4-5",
            unknown_model="anthropic/claude-haiku-4-5",
            representatives_per_type=2,
            unknown_batch_size=10,
            timeout_seconds=90,
        ),
    )

    pipeline = HydrationPipeline(settings)
    await pipeline.initialize()
    try:
        result = await pipeline.run()
    finally:
        await pipeline.shutdown()

    print(f"Written: {result.manifest.total_written}")
    for collection, count in sorted(result.manifest.collections.items()):
        print(f"  {collection}: {count}")


if __name__ == "__main__":
    asyncio.run(main())
