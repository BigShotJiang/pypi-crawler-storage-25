"""
inspect_manifest.py — load and pretty-print a hydration manifest from a
previous run without re-running the pipeline.

Usage:
    python examples/inspect_manifest.py [path/to/hydration_manifest.json]

Defaults to ./staging/hydration_manifest.json if no path is given.
"""

import json
import sys
from pathlib import Path


def main() -> None:
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("./staging/hydration_manifest.json")

    if not path.exists():
        print(f"Manifest not found: {path}")
        sys.exit(1)

    data = json.loads(path.read_text())

    print(f"Run ID   : {data['run_id']}")
    print(f"Site     : {data['site_id']}")
    print(f"At       : {data['generated_at']}")
    print()
    print(f"Segments : {data['total_segments']}")
    print(f"Written  : {data['total_written']}  Draft: {data['total_draft']}  Failed: {data['total_failed']}")
    print()
    print("Track breakdown:")
    for track, count in data.get("track_breakdown", {}).items():
        print(f"  {track:<10} {count}")
    print()
    print("Collections:")
    for name, count in sorted(data.get("collections", {}).items()):
        print(f"  {name:<30} {count} entries")
    print()
    print(f"Schema LLM calls : {data['llm_calls_schema_gen']} (batch)")
    print(f"Unknown LLM calls: {data['llm_calls_unknown']}")
    print(f"Schema cache hits: {data['schema_cache_hits']}  generated: {data['schemas_generated']}")
    print()
    print(f"Images uploaded  : {data['total_images_uploaded']}")
    print(f"Images cached    : {data['total_images_cached']}  (hit rate {data['image_cache_hit_rate']:.1%})")
    print(f"Images failed    : {data['total_images_failed']}")

    if data.get("warnings"):
        print(f"\nWarnings ({len(data['warnings'])}):")
        for w in data["warnings"]:
            print(f"  ! {w}")


if __name__ == "__main__":
    main()
