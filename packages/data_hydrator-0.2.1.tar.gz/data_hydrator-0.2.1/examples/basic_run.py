"""
basic_run.py — minimal end-to-end pipeline run.

Discovers every *.json file in ./scrape_output/, runs all four phases,
and writes Astro Content Collection files to ./staging/.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python examples/basic_run.py
"""

import asyncio
import logging

from data_hydrator import HydrationPipeline, HydrationSettings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
)


async def main() -> None:
    settings = HydrationSettings(site_id="example.com")

    pipeline = HydrationPipeline(settings)
    await pipeline.initialize()

    try:
        result = await pipeline.run()
    finally:
        await pipeline.shutdown()

    m = result.manifest
    print(f"\nRun ID : {m.run_id}")
    print(f"Written: {m.total_written}  Draft: {m.total_draft}  Failed: {m.total_failed}")
    print(f"Schema LLM calls : {m.llm_calls_schema_gen} (batch)")
    print(f"Unknown LLM calls: {m.llm_calls_unknown}")
    print(f"Images uploaded  : {m.total_images_uploaded}  cached: {m.total_images_cached}")
    print(f"Manifest : {result.manifest_path}")
    print(f"Redirects: {result.redirects_json_path}")
    print(f"          {result.redirects_csv_path}")


if __name__ == "__main__":
    asyncio.run(main())
