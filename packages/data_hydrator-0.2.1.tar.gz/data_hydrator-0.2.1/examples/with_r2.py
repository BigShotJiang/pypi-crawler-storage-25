"""
with_r2.py — pipeline run with Cloudflare R2 image upload enabled.

Images found in extracted HTML are downloaded and uploaded to R2.
Their URLs are rewritten to the CDN base URL in all output files.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    export HYDRATOR_R2__BUCKET_NAME=my-bucket
    export HYDRATOR_R2__ENDPOINT_URL=https://abc123.r2.cloudflarestorage.com
    export HYDRATOR_R2__ACCESS_KEY_ID=...
    export HYDRATOR_R2__SECRET_ACCESS_KEY=...
    export HYDRATOR_R2__PUBLIC_BASE_URL=https://cdn.example.com

    python examples/with_r2.py
"""

import asyncio
import logging

from data_hydrator import HydrationPipeline, HydrationSettings
from data_hydrator.config import R2Config, PipelineDirsConfig

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")


async def main() -> None:
    settings = HydrationSettings(
        site_id="shop.example.com",
        dirs=PipelineDirsConfig(
            scrape_dir="./scrape_output",
            segmented_dir="./segmented",
            classified_dir="./classified",
            mapped_dir="./mapped",
            staging_dir="./staging",
        ),
        r2=R2Config(
            bucket_name="my-assets-bucket",
            endpoint_url="https://abc123.r2.cloudflarestorage.com",
            access_key_id="YOUR_KEY_ID",
            secret_access_key="YOUR_SECRET",
            public_base_url="https://cdn.example.com",
            key_prefix="images/shop",
            max_concurrent_uploads=10,
            max_concurrent_downloads=20,
        ),
    )

    pipeline = HydrationPipeline(settings)
    await pipeline.initialize()
    try:
        result = await pipeline.run()
    finally:
        await pipeline.shutdown()

    m = result.manifest
    print(f"Images uploaded : {m.total_images_uploaded}")
    print(f"Images cached   : {m.total_images_cached}  (hit rate {m.image_cache_hit_rate:.1%})")
    print(f"Images failed   : {m.total_images_failed}")
    print(f"Staging root    : {result.staging_root}")


if __name__ == "__main__":
    asyncio.run(main())
