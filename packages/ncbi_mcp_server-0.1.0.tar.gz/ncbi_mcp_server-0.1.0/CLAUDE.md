# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

An MCP (Model Context Protocol) server that exposes NCBI (National Center for Biotechnology Information) database data to AI assistants. Uses Anthropic's MCP SDK with stdio transport (stdin/stdout JSON-RPC), making it embeddable in Claude Desktop, Claude Code, or any MCP-compatible client.

## Commands

All commands use `uv` as the package manager.

```bash
# Install dependencies
uv sync

# Run the server
uv run ncbi-mcp-server
# or
uv run python -m ncbi_mcp_server

# Smoke test (pipes MCP JSON-RPC messages to the server, 5s timeout)
make test

# Build and publish to PyPI (requires PYPI_TOKEN in .env)
make publish
```

## Architecture

**`src/ncbi_mcp_server/server.py`** — core MCP server. Creates an `mcp.server.Server` instance and runs it over stdio with `asyncio`. Add new NCBI tools here by:
1. Registering them in the `@server.list_tools()` handler (return `Tool` objects)
2. Handling them in the `@server.call_tool()` handler

**`src/ncbi_mcp_server/lambda.py`** — standalone AWS Lambda handler for downloading GEO (Gene Expression Omnibus) SOFT files from NCBI. Not yet wired into the MCP server. Requires `BUCKET_NAME` env var. The S3 upload/decompression logic is incomplete.

## Key Details

- Python 3.11+, built with `hatchling`, managed with `uv`
- Single runtime dependency: `mcp>=1.0.0`
- No tools are implemented yet — `list_tools()` returns an empty list
- The intended direction is NCBI GEO dataset extraction (see `lambda.py` for the pattern)
- Copy `.env.example` to `.env` and set `PYPI_TOKEN` before publishing
