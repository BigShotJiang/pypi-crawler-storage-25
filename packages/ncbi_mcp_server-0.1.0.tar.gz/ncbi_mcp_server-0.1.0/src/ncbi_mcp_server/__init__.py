"""MCP server for extracting data from NCBI databases."""

from ncbi_mcp_server.server import main

__all__ = ["main"]
