"""
MCP server for extracting data from NCBI databases.

Tools:
  get_geo_soft — download and read a GEO SOFT file from a GEO URL.

Usage:
  ncbi-mcp-server              # run directly if installed
  python -m ncbi_mcp_server    # run as module
"""

import gzip
import os
import re
import urllib.request
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

server = Server("ncbi-mcp-server")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_prefix(url: str) -> str:
    match = re.search(r"/(GSE\d+)/", url)
    if not match:
        raise ValueError("Could not extract GEO prefix from URL")
    return match.group(1)


def _build_download_url(base_url: str, prefix: str) -> str:
    normalized = base_url.rstrip("/") + "/"
    return normalized + f"{prefix}_family.soft.gz"


def _get_soft_file(url: str) -> Path:
    """Return path to decompressed .soft file, downloading if needed."""
    prefix = _extract_prefix(url)
    dest_dir = Path("/tmp") / prefix
    dest_dir.mkdir(parents=True, exist_ok=True)

    # Find existing .soft file
    soft_files = list(dest_dir.glob("*.soft"))
    if soft_files:
        return soft_files[0]

    # Download and decompress
    download_url = _build_download_url(url, prefix)
    gz_path = dest_dir / f"{prefix}_family.soft.gz"
    soft_path = dest_dir / f"{prefix}_family.soft"

    with urllib.request.urlopen(download_url) as response:
        gz_path.write_bytes(response.read())

    with gzip.open(gz_path, "rb") as gz_in, open(soft_path, "wb") as out:
        out.write(gz_in.read())

    gz_path.unlink()
    return soft_path


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="get_geo_soft",
            description=(
                "Download a GEO SOFT file from an NCBI GEO URL and return the first 500 lines. "
                "The file is cached in /tmp/<prefix> so subsequent calls are instant."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "URL to the GEO SOFT directory, e.g. https://ftp.ncbi.nlm.nih.gov/geo/series/GSE66nnn/GSE66597/soft/",
                    },
                    "rows": {
                        "type": "integer",
                        "description": "Number of lines to return (default 500).",
                        "default": 500,
                    },
                },
                "required": ["url"],
            },
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list:
    if name != "get_geo_soft":
        raise ValueError(f"Unknown tool: {name}")

    url = arguments.get("url")
    if not url:
        raise ValueError("'url' is required")

    rows = int(arguments.get("rows", 500))

    soft_path = _get_soft_file(url)

    lines = []
    with open(soft_path, encoding="utf-8", errors="replace") as f:
        for i, line in enumerate(f):
            if i >= rows:
                break
            lines.append(line.rstrip("\n"))

    return [TextContent(type="text", text="\n".join(lines))]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    import asyncio

    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(_run())
