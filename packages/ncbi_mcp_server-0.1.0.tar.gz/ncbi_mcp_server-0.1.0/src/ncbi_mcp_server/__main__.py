"""Allow running as: python -m ncbi_mcp_server"""

from ncbi_mcp_server.server import main

main()
