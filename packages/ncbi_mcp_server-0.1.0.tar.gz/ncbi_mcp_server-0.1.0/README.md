# ncbi-mcp-server

MCP server for extracting data from NCBI databases.
