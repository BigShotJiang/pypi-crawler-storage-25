from setuptools import setup, find_packages

setup(
    name="agentomy",
    version="0.1.0a1",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.9",
    author="Agentomy Contributors",
    author_email="governance@agentomy.com",
    description="Governed agent framework for Python. Add governance to any AI agent.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    license="MIT",
    url="https://github.com/Galaleio/Agentomy",
    project_urls={
        "Homepage": "https://agentomy.com",
        "Documentation": "https://agentomy.com/docs",
        "GovernanceBench": "https://agentomy.com/governancebench",
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries",
    ],
)
