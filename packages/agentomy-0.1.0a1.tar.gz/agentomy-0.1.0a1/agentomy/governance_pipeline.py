"""GovernancePipeline -- wrap any Python function with governance in one line."""

from .client import AgentomyClient
from .capsules.permission_router import PermissionRouter
from .capsules.audit_logger import AuditLogger
from .capsules.halt_protocol import HaltProtocol


class GovernancePipeline:
    """The magic wrapper. One line governs anything."""

    def __init__(self, endpoint: str = "http://localhost:3000",
                 token: str = "demo", agent_id: str = "default-agent"):
        self.client = AgentomyClient(endpoint, token, agent_id)
        self.router = PermissionRouter(self.client)
        self.logger = AuditLogger(self.client)
        self.halt = HaltProtocol(self.client)

    def govern(self, agent_func, *args, **kwargs):
        """Wrap any Python function with governance.

        Usage:
            pipeline = GovernancePipeline(endpoint="...", token="...", agent_id="my-agent")
            result = pipeline.govern(my_agent_function, input_data)
        """
        check = self.router.check(action="execute")
        if not check.get("authorized"):
            raise PermissionError(
                check.get("reason", "Action blocked by PermissionRouter")
            )
        self.logger.log(action="execution_started")
        result = agent_func(*args, **kwargs)
        self.logger.log(action="execution_completed")
        return result

    def halt_agent(self, reason: str = "operator_command"):
        """Emergency halt."""
        return self.halt.execute(reason=reason)
