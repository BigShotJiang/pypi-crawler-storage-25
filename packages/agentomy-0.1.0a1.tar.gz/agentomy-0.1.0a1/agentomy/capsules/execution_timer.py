"""Agentomy ExecutionTimer capsule."""

from datetime import datetime, timezone


class ExecutionTimer:
    """ExecutionTimer -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def execute(self, action: str, **kwargs):
        return self.client.post("/pipeline/execute", {**kwargs})

