"""Agentomy TeamCoordinator capsule."""



class TeamCoordinator:
    """TeamCoordinator -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def topology(self, agent_id=None):
        path = f"/agent/topology/{agent_id or self.client.agent_id}"

