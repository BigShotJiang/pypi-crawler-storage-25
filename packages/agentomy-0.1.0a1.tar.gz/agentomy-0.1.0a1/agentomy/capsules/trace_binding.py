"""Agentomy TraceBinding capsule."""



class TraceBinding:
    """TraceBinding -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def verify(self, agent_id=None):
        return self.client.get("/audit/anchors")

