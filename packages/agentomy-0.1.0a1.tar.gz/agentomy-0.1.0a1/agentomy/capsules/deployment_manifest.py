"""Agentomy DeploymentManifest capsule."""



class DeploymentManifest:
    """DeploymentManifest -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def snapshot(self, agent_id=None):
        return self.client.get("/governance/summary")

