"""Agentomy AuditLogger capsule."""

from datetime import datetime, timezone


class AuditLogger:
    """AuditLogger -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def log(self, action: str, **kwargs):
        return self.client.post("/claw/log", {**kwargs})

