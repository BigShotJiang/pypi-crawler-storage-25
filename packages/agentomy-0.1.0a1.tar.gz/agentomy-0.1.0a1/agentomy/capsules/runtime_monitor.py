"""Agentomy RuntimeMonitor capsule."""



class RuntimeMonitor:
    """RuntimeMonitor -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def status(self, agent_id=None):
        return self.client.get("/monitor/status")

