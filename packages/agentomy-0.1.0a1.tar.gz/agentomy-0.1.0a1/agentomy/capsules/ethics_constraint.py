"""Agentomy EthicsConstraint capsule."""

from datetime import datetime, timezone


class EthicsConstraint:
    """EthicsConstraint -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def evaluate(self, action: str, **kwargs):
        return self.client.post("/pipeline/execute", {**kwargs})

