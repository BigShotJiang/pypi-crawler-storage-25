"""Agentomy AgentSandbox capsule."""

from datetime import datetime, timezone


class AgentSandbox:
    """AgentSandbox -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def deploy(self, persona: str, **kwargs):
        return self.client.post("/agents/deploy", {**kwargs})

