"""Agentomy HaltProtocol capsule."""

from datetime import datetime, timezone


class HaltProtocol:
    """HaltProtocol -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def execute(self, reason: str, **kwargs):
        return self.client.post("/claw/halt", {**kwargs})

