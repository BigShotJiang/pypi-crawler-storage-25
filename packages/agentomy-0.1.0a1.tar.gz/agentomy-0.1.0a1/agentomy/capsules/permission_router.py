"""Agentomy PermissionRouter capsule."""

from datetime import datetime, timezone


class PermissionRouter:
    """PermissionRouter -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def check(self, action: str, **kwargs):
        return self.client.post("/claw/authorize", {**kwargs})

