"""Agentomy DecisionLog capsule."""

from datetime import datetime, timezone


class DecisionLog:
    """DecisionLog -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def record(self, action: str, decision: str, **kwargs):
        return self.client.post("/claw/log", {**kwargs})

