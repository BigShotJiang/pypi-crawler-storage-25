"""Agentomy TrustScorer capsule."""



class TrustScorer:
    """TrustScorer -- governance capsule wrapper."""

    def __init__(self, client):
        self.client = client

    def score(self, agent_id=None):
        path = f"/monitor/agent/{agent_id or self.client.agent_id}"

