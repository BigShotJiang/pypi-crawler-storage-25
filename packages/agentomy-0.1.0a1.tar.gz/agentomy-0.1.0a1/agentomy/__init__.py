"""Agentomy -- Governed agent framework for Python."""

from .client import AgentomyClient
from .governance_pipeline import GovernancePipeline
from .capsules.permission_router import PermissionRouter
from .capsules.audit_logger import AuditLogger
from .capsules.halt_protocol import HaltProtocol
from .capsules.execution_timer import ExecutionTimer
from .capsules.agent_sandbox import AgentSandbox
from .capsules.decision_log import DecisionLog
from .capsules.trace_binding import TraceBinding
from .capsules.team_coordinator import TeamCoordinator
from .capsules.ethics_constraint import EthicsConstraint
from .capsules.trust_scorer import TrustScorer
from .capsules.runtime_monitor import RuntimeMonitor
from .capsules.deployment_manifest import DeploymentManifest

__version__ = "0.1.0a1"
__all__ = [
    "AgentomyClient", "GovernancePipeline",
    "PermissionRouter", "AuditLogger", "HaltProtocol",
    "ExecutionTimer", "AgentSandbox", "DecisionLog",
    "TraceBinding", "TeamCoordinator", "EthicsConstraint",
    "TrustScorer", "RuntimeMonitor", "DeploymentManifest",
]
