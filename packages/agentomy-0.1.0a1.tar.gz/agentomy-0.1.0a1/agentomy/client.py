"""Agentomy Python SDK -- base client for governance API communication."""

import requests


class AgentomyClient:
    """Base HTTP client for Agentomy governance server."""

    def __init__(self, endpoint: str = "http://localhost:3000",
                 token: str = "demo", agent_id: str = "default-agent"):
        self.endpoint = endpoint.rstrip("/")
        self.token = token
        self.agent_id = agent_id
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        })

    def post(self, path: str, payload: dict) -> dict:
        url = f"{self.endpoint}/api{path}"
        response = self.session.post(url, json=payload)
        response.raise_for_status()
        return response.json()

    def get(self, path: str) -> dict:
        url = f"{self.endpoint}/api{path}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
