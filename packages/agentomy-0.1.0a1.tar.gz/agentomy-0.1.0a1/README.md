# Agentomy -- Python SDK

Governed agent framework for Python. Add governance to any AI agent.

## Install

```bash
pip install agentomy
```

## Quick Start (4 lines)

```python
from agentomy import GovernancePipeline

pipeline = GovernancePipeline(
    endpoint="YOUR_AGENTOMY_ENDPOINT",
    token="YOUR_TOKEN",
    agent_id="my-python-agent"
)

result = pipeline.govern(my_agent_function, input_data)
```

## 12 Governance Capsules

- PermissionRouter -- access control
- AuditLogger -- tamper-evident audit trail
- HaltProtocol -- emergency halt
- ExecutionTimer -- runtime boundaries
- AgentSandbox -- containment
- DecisionLog -- decision transparency
- TraceBinding -- output traceability
- TeamCoordinator -- multi-agent orchestration
- EthicsConstraint -- ethics enforcement
- TrustScorer -- behavioral trust
- RuntimeMonitor -- observability
- DeploymentManifest -- governance transparency

## Status

Alpha release. MIT licensed. Production requires Agentomy governance server.

## Links

- Website: https://agentomy.com
- GovernanceBench: https://agentomy.com/governancebench
- npm (TypeScript): https://npmjs.com/package/agentomy-agent
