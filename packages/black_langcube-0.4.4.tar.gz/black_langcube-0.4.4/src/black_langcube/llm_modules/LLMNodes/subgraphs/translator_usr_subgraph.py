"""
TranslatorUsrNode is a subclass of LLMNode designed to handle translation tasks using a language model.
It utilizes a prompt template and output parser to generate translations based on user input and a specified target language.
Attributes:
    state (dict): The current state containing translation input and target language.
    config (dict): Configuration parameters for the node.
Methods:
    __init__(state, config):
        Initializes the TranslatorUsrNode with the given state and configuration.
    generate_messages():
        Constructs and returns a list of messages for the translation prompt, including a system message
        formatted with the target language and a human message containing the input text to be translated.
    execute(extra_input=None):
        Executes the translation process by updating the state with new input, running the language model chain,
        and returning the translation output, token usage, and target language.
"""

import logging
from black_langcube.llm_modules.LLMNodes.LLMNode import LLMNode
from black_langcube.prompts.prompts import translator_usr

logger = logging.getLogger(__name__)


class TranslatorUsrNode(LLMNode):
    def __init__(self, state, config, llm=None):
        super().__init__(state, config, llm=llm)

    def generate_messages(self):
        """
        Generate messages for translation.
        """
        messages = [
            (
                "system",
                translator_usr["system"].format(
                    language=self.state.get("language", "English")
                ),
            ),
            ("human", self.state.get("translation_input", "")),
        ]
        return messages

    async def execute(self, extra_input=None):
        self.logger.debug("----- Executing TranslatorUsrNode -----")
        self.state["translation_input"] = extra_input.get("translation_input")
        self.state["language"] = extra_input.get("language")
        result, tokens = await self.run_chain(extra_input=extra_input)

        self.logger.debug("----- TranslatorUsrNode execution completed -----")

        return {
            "translation_output": result,
            "translation_tokens": tokens,
            "language": self.state.get("language"),
        }
