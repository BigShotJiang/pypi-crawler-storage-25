"""
LLMNode is a base class for nodes that interact with language models in a chain-of-thought or prompt-composition workflow.
Attributes:
    state (Any): The current state or context for the node.
    config (Any): Configuration parameters for the node.
    llm (BaseChatModel): The language model instance injected at construction time.
    logger (logging.Logger): Logger instance for the node.
Methods:
    __init__(state, config, llm=None):
        Initializes the LLMNode with the given state, configuration, and optional LLM instance.
        When ``llm`` is ``None``, the default LLM is created via ``default_llm()``.
    generate_messages():
        Abstract method to return a list of messages for prompt composition.
        Must be implemented by subclasses.
    get_llm():
        Returns the LLM instance stored at construction time.
    get_parser():
        Returns the output parser for the language model's response. Can be overridden if needed.
    run_chain(extra_input=None):
        Prepares and executes the chain using the generated messages, language model, and parser.
        Returns the result and token usage.
    execute(extra_input=None):
        Executes the chain and returns the result and token usage.
"""

import logging
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from black_langcube.llm_modules.llm_model import default_llm
from black_langcube.llm_modules.robust_invoke_async import robust_invoke_async


class LLMNode:
    def __init__(self, state, config, llm=None):
        self.state = state
        self.config = config
        self.llm = llm if llm is not None else default_llm()
        self.logger = logging.getLogger(__name__)

    def generate_messages(self):
        """Return a list of messages for prompt composition.
        Must be implemented by subclasses."""
        raise NotImplementedError

    def get_llm(self):
        """Return the LLM instance stored at construction time."""
        return self.llm

    def get_parser(self):
        """Return the output parser. Subclasses can override if needed."""
        return StrOutputParser()

    async def run_chain(self, extra_input=None):
        """Prepare the chain with messages, LLM, and parser."""
        messages = self.generate_messages()
        prompt = ChatPromptTemplate.from_messages(messages)
        chain = prompt | self.get_llm() | self.get_parser()
        result, tokens = await robust_invoke_async(chain, extra_input)
        return result, tokens

    async def execute(self, extra_input=None):
        result, tokens = await self.run_chain(extra_input)
        return result, tokens
