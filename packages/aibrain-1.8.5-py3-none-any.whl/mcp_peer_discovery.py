#!/usr/bin/env python3
"""
AIBrain Peer Discovery MCP Server — Agent-agnostic multi-agent coordination.

Provides peer discovery and messaging for any agent runtime (Claude, Cursor,
Copilot, custom agents, etc.) via MCP tools backed by a lightweight HTTP broker.

Broker runs embedded on localhost:7800 (configurable via PEER_BROKER_PORT).
Set PEER_BROKER_URL to point at a remote broker instead of starting a local one.

Usage:
    python mcp_peer_discovery.py                          # stdio MCP + local broker
    PEER_BROKER_URL=http://host:7800 python mcp_peer_discovery.py  # remote broker

MCP config (.mcp.json):
    {
        "mcpServers": {
            "aibrain-peers": {
                "command": "python",
                "args": ["C:/Users/.../aibrain/mcp_peer_discovery.py"]
            }
        }
    }
"""

import argparse
import base64
import hashlib
import json
import os
import platform
import secrets
import sqlite3
import socket
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.error import URLError
from urllib.parse import parse_qs, urlparse, urlencode
from urllib.request import Request, urlopen

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
except ImportError:
    print("Error: MCP package not installed. Run: pip install mcp", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_PORT = 7800
HEARTBEAT_INTERVAL = 15  # seconds
DEAD_PEER_TIMEOUT = 86400  # seconds — 24 hours (peers re-register via broker_hook on each prompt)

# Mutable config — overridden by CLI args before broker starts
_FILES_DIR = Path.home() / "aibrain_transfers"

_config = {
    "db_path": Path.home() / "aibrain_peers.db",
    "broker_url": os.environ.get("PEER_BROKER_URL", "").strip(),
    "broker_port": int(os.environ.get("PEER_BROKER_PORT", str(DEFAULT_PORT))),
    "files_dir": _FILES_DIR,
    "max_file_size": 100 * 1024 * 1024,  # 100 MB
}

if not _config["broker_url"]:
    _config["broker_url"] = f"http://localhost:{_config['broker_port']}"

# Optional shared secret for broker auth. Set PEER_BROKER_TOKEN env var.
# If unset, broker is open to all local processes (acceptable for localhost-only).
_BROKER_TOKEN = os.environ.get("PEER_BROKER_TOKEN", "").strip()

# HMAC replay window — reject messages with timestamps older than this (seconds)
_HMAC_REPLAY_WINDOW = 300  # 5 minutes


def _compute_hmac(body: bytes, timestamp: str) -> str:
    """Compute HMAC-SHA256 of body + timestamp using PEER_BROKER_TOKEN."""
    import hmac as _hmac
    key = _BROKER_TOKEN.encode("utf-8")
    msg = timestamp.encode("utf-8") + b":" + body
    return _hmac.new(key, msg, hashlib.sha256).hexdigest()


def _verify_hmac(body: bytes, signature: str, timestamp: str) -> tuple[bool, str]:
    """
    Verify HMAC-SHA256 signature and timestamp freshness.

    Returns (valid, reason). If PEER_BROKER_TOKEN is unset, always passes.
    """
    import hmac as _hmac
    if not _BROKER_TOKEN:
        return True, "no token configured — open mode"
    if not signature or not timestamp:
        return False, "missing X-HMAC-Signature or X-HMAC-Timestamp header"
    # Check timestamp freshness
    try:
        ts = float(timestamp)
        age = abs(time.time() - ts)
        if age > _HMAC_REPLAY_WINDOW:
            return False, f"timestamp too old ({age:.0f}s > {_HMAC_REPLAY_WINDOW}s)"
    except (ValueError, TypeError):
        return False, "invalid timestamp format"
    # Verify signature
    expected = _compute_hmac(body, timestamp)
    if not _hmac.compare_digest(signature, expected):
        return False, "HMAC signature mismatch"
    return True, "valid"


def _is_safe_notify_url(url: str) -> bool:
    """Block SSRF in notify_url — reject internal/private addresses."""
    if not url:
        return False
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        host = (parsed.hostname or "").lower()
        # Block loopback, link-local, private ranges, cloud metadata
        _blocked_prefixes = ("127.", "10.", "192.168.", "169.254.", "0.", "::1", "fc", "fd")
        _blocked_hosts = {"localhost", "metadata.google.internal", "metadata.aws"}
        if host in _blocked_hosts:
            return False
        if any(host.startswith(p) for p in _blocked_prefixes):
            return False
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Broker Database
# ---------------------------------------------------------------------------

_db_lock = threading.Lock()
_broker_db: sqlite3.Connection | None = None


def _init_broker_db() -> sqlite3.Connection:
    """Initialize the broker SQLite database."""
    global _broker_db
    if _broker_db is not None:
        return _broker_db
    with _db_lock:
        if _broker_db is not None:
            return _broker_db
        _broker_db = sqlite3.connect(str(_config["db_path"]), check_same_thread=False, timeout=10)
        _broker_db.execute("PRAGMA journal_mode=WAL")
        _broker_db.execute("PRAGMA busy_timeout=5000")
        _broker_db.row_factory = sqlite3.Row
        _broker_db.executescript("""
            CREATE TABLE IF NOT EXISTS peers (
                agent_id    TEXT PRIMARY KEY,
                agent_type  TEXT NOT NULL DEFAULT 'unknown',
                pid         INTEGER,
                cwd         TEXT,
                git_root    TEXT,
                summary     TEXT DEFAULT '',
                capabilities TEXT DEFAULT '[]',
                notify_url  TEXT DEFAULT '',
                registered_at TEXT NOT NULL,
                last_seen   TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS messages (
                id          TEXT PRIMARY KEY,
                from_agent  TEXT NOT NULL,
                to_agent    TEXT NOT NULL,
                content     TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                read        INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS file_transfers (
                id          TEXT PRIMARY KEY,
                from_agent  TEXT NOT NULL,
                to_agent    TEXT NOT NULL,
                filename    TEXT NOT NULL,
                dest_path   TEXT DEFAULT '',
                size_bytes  INTEGER NOT NULL,
                sha256      TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                received    INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS tasks (
                id          TEXT PRIMARY KEY,
                title       TEXT NOT NULL,
                description TEXT DEFAULT '',
                status      TEXT DEFAULT 'todo',
                created_by  TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                updated_at  TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS task_agents (
                task_id     TEXT NOT NULL,
                agent_id    TEXT NOT NULL,
                role        TEXT DEFAULT 'assignee',
                assigned_at TEXT NOT NULL,
                PRIMARY KEY (task_id, agent_id)
            );
            CREATE TABLE IF NOT EXISTS task_comments (
                id          TEXT PRIMARY KEY,
                task_id     TEXT NOT NULL,
                from_agent  TEXT NOT NULL,
                content     TEXT NOT NULL,
                created_at  TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS wakeup_queue (
                id              TEXT PRIMARY KEY,
                agent_id        TEXT NOT NULL,
                reason          TEXT NOT NULL,
                payload         TEXT DEFAULT '{}',
                status          TEXT DEFAULT 'queued',
                coalesced_count INTEGER DEFAULT 1,
                idempotency_key TEXT UNIQUE,
                created_at      TEXT NOT NULL,
                claimed_at      TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_messages_to ON messages(to_agent, read);
            CREATE INDEX IF NOT EXISTS idx_peers_last_seen ON peers(last_seen);
            CREATE INDEX IF NOT EXISTS idx_files_to ON file_transfers(to_agent, received);
            CREATE INDEX IF NOT EXISTS idx_wakeup_agent ON wakeup_queue(agent_id, status);
        """)
        _broker_db.commit()
        # Schema migrations — add columns introduced after initial deploy
        # These are idempotent: fail silently if column already exists
        _migrations = [
            "ALTER TABLE peers ADD COLUMN notify_url TEXT DEFAULT ''",
            "ALTER TABLE peers ADD COLUMN git_root TEXT",
            "ALTER TABLE file_transfers ADD COLUMN dest_path TEXT DEFAULT ''",
        ]
        for _m in _migrations:
            try:
                _broker_db.execute(_m)
                _broker_db.commit()
            except Exception:
                pass  # Column already exists
        _prune_zombie_pids()
        return _broker_db


def _prune_zombie_pids():
    """Remove peers whose PIDs no longer exist (zombie detection)."""
    db = _broker_db
    if db is None:
        return
    rows = db.execute("SELECT agent_id, pid FROM peers WHERE pid IS NOT NULL").fetchall()
    dead_ids = []
    for row in rows:
        pid = row["pid"]
        if pid and not _pid_alive(pid):
            dead_ids.append(row["agent_id"])
    if dead_ids:
        db.executemany("DELETE FROM peers WHERE agent_id = ?", [(aid,) for aid in dead_ids])
        db.commit()


def _pid_alive(pid: int) -> bool:
    """Check if a PID is alive. Cross-platform, no psutil needed."""
    if pid <= 0:
        return False
    if platform.system() == "Windows":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                capture_output=True, text=True, timeout=5
            )
            return str(pid) in result.stdout
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def _prune_dead_peers():
    """Remove peers that haven't heartbeated within the timeout."""
    db = _broker_db
    if db is None:
        return
    cutoff = datetime.now(timezone.utc).timestamp() - DEAD_PEER_TIMEOUT
    cutoff_iso = datetime.fromtimestamp(cutoff, tz=timezone.utc).isoformat()
    with _db_lock:
        db.execute("DELETE FROM peers WHERE last_seen < ?", (cutoff_iso,))
        db.commit()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Broker HTTP Handler
# ---------------------------------------------------------------------------

class BrokerHandler(BaseHTTPRequestHandler):
    """Lightweight HTTP API for peer coordination."""

    def log_message(self, format, *args):
        """Suppress default stderr logging."""
        pass

    def _check_auth(self) -> bool:
        """Verify broker token if PEER_BROKER_TOKEN is configured."""
        if not _BROKER_TOKEN:
            return True  # No token — open to local processes by design
        import hmac as _hmac
        provided = self.headers.get("X-Broker-Token", "")
        # Constant-time comparison — prevents timing side-channel token recovery
        return _hmac.compare_digest(provided, _BROKER_TOKEN)

    def _json_response(self, data: dict, status: int = 200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length))

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        params = parse_qs(parsed.query)

        if path == "/health":
            self._handle_health()
            return

        if not self._check_auth():
            self._json_response({"error": "Unauthorized — X-Broker-Token required"}, 401)
            return

        if path == "/peers":
            self._handle_list_peers(params)
        elif path == "/messages":
            self._handle_get_messages(params)
        elif path == "/status":
            self._handle_status()
        elif path == "/files":
            self._handle_list_files(params)
        elif path.startswith("/files/download/"):  # noqa:path-startswith-bypass — route matching, not path traversal guard
            file_id = path.split("/files/download/", 1)[1]
            self._handle_download_file(file_id)
        elif path == "/wakeup/next":
            self._handle_wakeup_next(params)
        elif path == "/tasks":
            self._handle_task_list(params)
        else:
            self._json_response({"error": "not found"}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")

        # /notify is auth-exempt — peers send push callbacks without our token
        if path == "/notify":
            self._handle_notify()
            return

        if not self._check_auth():
            self._json_response({"error": "Unauthorized — X-Broker-Token required"}, 401)
            return

        try:
            if path == "/peers/register":
                self._handle_register()
            elif path == "/peers/heartbeat":
                self._handle_heartbeat()
            elif path == "/peers/summary":
                self._handle_set_summary()
            elif path == "/peers/unregister":
                self._handle_unregister()
            elif path == "/messages/send":
                self._handle_send_message()
            elif path == "/messages/broadcast":
                self._handle_broadcast()
            elif path == "/files/send":
                self._handle_send_file()
            elif path == "/files/acknowledge":
                self._handle_acknowledge_file()
            elif path == "/tasks/create":
                self._handle_task_create()
            elif path == "/tasks/assign":
                self._handle_task_assign()
            elif path == "/tasks/comment":
                self._handle_task_comment()
            elif path == "/tasks/checkout":
                self._handle_task_checkout()
            elif path == "/tasks/status":
                self._handle_task_status()
            elif path == "/wakeup/done":
                self._handle_wakeup_done()
            else:
                self._json_response({"error": "not found"}, 404)
        except Exception as exc:
            # Catch unhandled exceptions so the connection always gets a response
            # instead of silently closing (which manifests as curl exit 52)
            import logging as _log
            _log.getLogger(__name__).error("POST %s unhandled error: %s", path, exc, exc_info=True)
            try:
                self._json_response({"error": "internal server error", "detail": str(exc)}, 500)
            except Exception:
                pass  # wfile already closed — nothing we can do

    # --- Handlers ---

    def _handle_health(self):
        self._json_response({"status": "ok", "timestamp": _now_iso()})

    def _handle_status(self):
        _prune_dead_peers()
        db = _broker_db
        peer_count = db.execute("SELECT COUNT(*) FROM peers").fetchone()[0]
        msg_unread = db.execute("SELECT COUNT(*) FROM messages WHERE read = 0").fetchone()[0]
        msg_total = db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        self._json_response({
            "status": "ok",
            "peers": peer_count,
            "messages_queued": msg_unread,
            "messages_total": msg_total,
            "uptime_note": "broker is running",
            "timestamp": _now_iso(),
        })

    def _notify_agent(self, agent_id: str, payload: dict):
        """Push notification to an agent's callback URL (fire-and-forget)."""
        db = _broker_db
        if db is None:
            return
        row = db.execute("SELECT notify_url FROM peers WHERE agent_id = ?", (agent_id,)).fetchone()
        if not row or not row["notify_url"]:
            return
        notify_url = row["notify_url"]
        if not _is_safe_notify_url(notify_url):
            return  # Block SSRF — silently drop unsafe notify URLs
        # Fire in a thread so we don't block the handler
        def _do_notify():
            try:
                body = json.dumps(payload).encode()
                req = Request(notify_url, method="POST", data=body,
                              headers={"Content-Type": "application/json"})
                urlopen(req, timeout=5)
            except Exception:
                pass  # Best-effort — don't fail on notification errors
        threading.Thread(target=_do_notify, daemon=True).start()

    def _handle_notify(self):
        """Receive a push notification from a peer broker.

        Writes to the local agent's inbox (peer_inbox.jsonl beside this script)
        and fires a Telegram alert so the agent wakes up immediately without waiting
        for the next 30-second poll cycle.
        """
        try:
            data = self._read_body()
        except Exception:
            self._json_response({"error": "invalid JSON body"}, 400)
            return

        event_type = data.get("event_type", data.get("type", "message"))
        from_agent = data.get("from_agent", "unknown")
        # Payload uses different keys depending on sender — normalise to summary
        summary = (data.get("summary")
                   or data.get("preview")
                   or data.get("filename")
                   or "")

        # Write to inbox so broker_hook / telegram_check.py can surface it
        inbox_path = Path.home() / ".tmp" / "peer_inbox.jsonl"
        inbox_path.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "ts": _now_iso(),
            "from": from_agent,
            "chat": "peer_broker",
            "chat_id": 0,
            "type": event_type,
            "text": f"[{event_type.upper()} from {from_agent}] {summary}",
        }
        with _db_lock:
            with open(inbox_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry) + "\n")

        # Fire Telegram alert — read token from env file (broker may not inherit env)
        def _send_telegram():
            token = os.environ.get("TELEGRAM_TOKEN", "")
            if not token:
                # Broker started via nohup may not have env vars — read file directly
                for env_file in [Path.home() / ".decker_env", Path.home() / ".aibrain_env"]:
                    if env_file.exists():
                        for line in env_file.read_text(encoding="utf-8").splitlines():
                            line = line.strip()
                            if line.startswith("TELEGRAM_TOKEN=") and "=" in line:
                                token = line.split("=", 1)[1].strip().strip('"')
                                break
                    if token:
                        break
            chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
            if not token or not chat_id:
                return
            msg = f"\U0001f514 PUSH from {from_agent}: {summary}"
            try:
                body = json.dumps({"chat_id": chat_id, "text": msg}).encode()
                req = Request(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    method="POST", data=body,
                    headers={"Content-Type": "application/json"},
                )
                urlopen(req, timeout=5)
            except Exception:
                pass  # Best-effort

        threading.Thread(target=_send_telegram, daemon=True).start()
        self._json_response({"status": "ok", "received": True})

    def _handle_register(self):
        data = self._read_body()
        agent_id = data.get("agent_id")
        if not agent_id:
            self._json_response({"error": "agent_id required"}, 400)
            return
        db = _broker_db
        if db is None:
            self._json_response({"error": "broker database not initialized"}, 503)
            return
        # Validate notify_url at registration time — reject SSRF payloads upfront
        raw_notify_url = data.get("notify_url", "")
        if raw_notify_url and not _is_safe_notify_url(raw_notify_url):
            self._json_response(
                {"error": "notify_url rejected: must be http/https and not target internal networks"},
                400,
            )
            return
        now = _now_iso()
        caps = data.get("capabilities", [])
        if isinstance(caps, list):
            caps = json.dumps(caps)
        with _db_lock:
            db.execute("""
                INSERT INTO peers (agent_id, agent_type, pid, cwd, git_root, summary, capabilities, notify_url, registered_at, last_seen)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(agent_id) DO UPDATE SET
                    agent_type=excluded.agent_type, pid=excluded.pid, cwd=excluded.cwd,
                    git_root=excluded.git_root, summary=excluded.summary,
                    capabilities=excluded.capabilities, notify_url=excluded.notify_url, last_seen=excluded.last_seen
            """, (
                agent_id,
                data.get("agent_type", "unknown"),
                data.get("pid"),
                data.get("cwd"),
                data.get("git_root"),
                data.get("summary", ""),
                caps,
                raw_notify_url,
                now, now,
            ))
            db.commit()
        self._json_response({"status": "registered", "agent_id": agent_id})

    def _handle_heartbeat(self):
        data = self._read_body()
        agent_id = data.get("agent_id")
        if not agent_id:
            self._json_response({"error": "agent_id required"}, 400)
            return
        db = _broker_db
        with _db_lock:
            cur = db.execute("UPDATE peers SET last_seen = ? WHERE agent_id = ?",
                             (_now_iso(), agent_id))
            db.commit()
        if cur.rowcount == 0:
            self._json_response({"error": "peer not found — register first"}, 404)
        else:
            self._json_response({"status": "ok", "agent_id": agent_id})

    def _handle_set_summary(self):
        data = self._read_body()
        agent_id = data.get("agent_id")
        summary = data.get("summary", "")
        if not agent_id:
            self._json_response({"error": "agent_id required"}, 400)
            return
        db = _broker_db
        with _db_lock:
            cur = db.execute("UPDATE peers SET summary = ?, last_seen = ? WHERE agent_id = ?",
                             (summary, _now_iso(), agent_id))
            db.commit()
        if cur.rowcount == 0:
            self._json_response({"error": "peer not found"}, 404)
        else:
            self._json_response({"status": "updated", "agent_id": agent_id})

    def _handle_unregister(self):
        data = self._read_body()
        agent_id = data.get("agent_id")
        if not agent_id:
            self._json_response({"error": "agent_id required"}, 400)
            return
        db = _broker_db
        with _db_lock:
            db.execute("DELETE FROM peers WHERE agent_id = ?", (agent_id,))
            db.commit()
        self._json_response({"status": "unregistered", "agent_id": agent_id})

    def _handle_list_peers(self, params: dict):
        _prune_dead_peers()
        db = _broker_db
        scope = params.get("scope", [None])[0]
        scope_value = params.get("scope_value", [None])[0]

        query = "SELECT * FROM peers"
        args = []

        if scope == "directory" and scope_value:
            query += " WHERE cwd = ?"
            args.append(scope_value)
        elif scope == "repo" and scope_value:
            query += " WHERE git_root = ?"
            args.append(scope_value)
        elif scope == "capability" and scope_value:
            query += " WHERE capabilities LIKE ?"
            args.append(f"%{scope_value}%")
        elif scope == "type" and scope_value:
            query += " WHERE agent_type = ?"
            args.append(scope_value)

        rows = db.execute(query, args).fetchall()
        peers = []
        for r in rows:
            peers.append({
                "agent_id": r["agent_id"],
                "agent_type": r["agent_type"],
                "pid": r["pid"],
                "cwd": r["cwd"],
                "git_root": r["git_root"],
                "summary": r["summary"],
                "capabilities": json.loads(r["capabilities"]) if r["capabilities"] else [],
                "registered_at": r["registered_at"],
                "last_seen": r["last_seen"],
            })
        self._json_response({"peers": peers, "count": len(peers)})

    def _handle_send_message(self):
        # HMAC verification — read raw body for signature check
        length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(length) if length else b"{}"
        sig = self.headers.get("X-HMAC-Signature", "")
        ts = self.headers.get("X-HMAC-Timestamp", "")
        valid, reason = _verify_hmac(raw_body, sig, ts)
        if not valid:
            self._json_response({"error": f"HMAC verification failed: {reason}"}, 403)
            return
        data = json.loads(raw_body) if raw_body else {}
        from_agent = data.get("from_agent")
        to_agent = data.get("to_agent")
        content = data.get("content")
        if not all([from_agent, to_agent, content]):
            self._json_response({"error": "from_agent, to_agent, and content required"}, 400)
            return
        msg_id = secrets.token_hex(16)
        db = _broker_db
        with _db_lock:
            db.execute(
                "INSERT INTO messages (id, from_agent, to_agent, content, created_at) VALUES (?, ?, ?, ?, ?)",
                (msg_id, from_agent, to_agent, json.dumps(content) if not isinstance(content, str) else content, _now_iso())
            )
            db.commit()
        # Push notify + wakeup queue so peer_daemon picks it up if agent is offline
        notify_payload = {
            "type": "message",
            "message_id": msg_id,
            "from_agent": from_agent,
            "preview": (content[:200] if isinstance(content, str) else str(content)[:200]),
        }
        self._notify_agent(to_agent, notify_payload)
        self._insert_wakeup(to_agent, "message_received", notify_payload,
                            idempotency_key=f"msg:{msg_id}")
        self._json_response({"status": "sent", "message_id": msg_id})

    def _handle_broadcast(self):
        data = self._read_body()
        from_agent = data.get("from_agent")
        content = data.get("content")
        filter_scope = data.get("scope")
        filter_value = data.get("scope_value")
        if not from_agent or not content:
            self._json_response({"error": "from_agent and content required"}, 400)
            return

        _prune_dead_peers()
        db = _broker_db

        query = "SELECT agent_id FROM peers WHERE agent_id != ?"
        args: list = [from_agent]
        if filter_scope == "repo" and filter_value:
            query += " AND git_root = ?"
            args.append(filter_value)
        elif filter_scope == "directory" and filter_value:
            query += " AND cwd = ?"
            args.append(filter_value)
        elif filter_scope == "capability" and filter_value:
            query += " AND capabilities LIKE ?"
            args.append(f"%{filter_value}%")
        elif filter_scope == "type" and filter_value:
            query += " AND agent_type = ?"
            args.append(filter_value)

        targets = [r["agent_id"] for r in db.execute(query, args).fetchall()]
        now = _now_iso()
        content_str = json.dumps(content) if not isinstance(content, str) else content
        msg_ids = []
        with _db_lock:
            for target in targets:
                msg_id = secrets.token_hex(16)
                db.execute(
                    "INSERT INTO messages (id, from_agent, to_agent, content, created_at) VALUES (?, ?, ?, ?, ?)",
                    (msg_id, from_agent, target, content_str, now)
                )
                msg_ids.append(msg_id)
            db.commit()
        self._json_response({"status": "broadcast", "recipients": len(targets), "message_ids": msg_ids})

    def _handle_get_messages(self, params: dict):
        # HMAC verification for GET — sign the path+query
        sig = self.headers.get("X-HMAC-Signature", "")
        ts = self.headers.get("X-HMAC-Timestamp", "")
        sign_body = self.path.encode("utf-8")
        valid, reason = _verify_hmac(sign_body, sig, ts)
        if not valid:
            self._json_response({"error": f"HMAC verification failed: {reason}"}, 403)
            return
        agent_id = params.get("agent_id", [None])[0]
        if not agent_id:
            self._json_response({"error": "agent_id query param required"}, 400)
            return
        mark_read = params.get("mark_read", ["true"])[0].lower() == "true"
        db = _broker_db
        rows = db.execute(
            "SELECT * FROM messages WHERE to_agent = ? AND read = 0 ORDER BY created_at ASC",
            (agent_id,)
        ).fetchall()
        messages = []
        for r in rows:
            messages.append({
                "id": r["id"],
                "from_agent": r["from_agent"],
                "content": r["content"],
                "created_at": r["created_at"],
            })
        if mark_read and messages:
            ids = [m["id"] for m in messages]
            placeholders = ",".join("?" * len(ids))
            with _db_lock:
                db.execute(f"UPDATE messages SET read = 1 WHERE id IN ({placeholders})", ids)  # noqa:sql-f-string — placeholders is only '?,?,?' not user data
                db.commit()
        self._json_response({"messages": messages, "count": len(messages)})

    # --- File Transfer Handlers ---

    def _handle_send_file(self):
        """Receive a file transfer. Body: {from_agent, to_agent, filename, content_b64, ?dest_path}"""
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            self._json_response({"error": "empty body"}, 400)
            return
        if length > _config["max_file_size"] + 1024 * 1024:  # payload overhead
            self._json_response({"error": f"file too large (max {_config['max_file_size'] // 1024 // 1024}MB)"}, 413)
            return

        data = json.loads(self.rfile.read(length))
        from_agent = data.get("from_agent")
        to_agent = data.get("to_agent")
        filename = data.get("filename")
        content_b64 = data.get("content_b64")
        dest_path = data.get("dest_path", "")

        if not all([from_agent, to_agent, filename, content_b64]):
            self._json_response({"error": "from_agent, to_agent, filename, content_b64 required"}, 400)
            return

        # Sanitize filename — no path traversal
        safe_name = Path(filename).name
        if not safe_name or safe_name.startswith("."):
            self._json_response({"error": "invalid filename"}, 400)
            return

        # Decode and save
        try:
            file_bytes = base64.b64decode(content_b64)
        except Exception:
            self._json_response({"error": "invalid base64 content"}, 400)
            return

        if len(file_bytes) > _config["max_file_size"]:
            self._json_response({"error": f"file too large (max {_config['max_file_size'] // 1024 // 1024}MB)"}, 413)
            return

        file_hash = hashlib.sha256(file_bytes).hexdigest()
        file_id = secrets.token_hex(16)
        now = _now_iso()

        # Save to transfer directory
        files_dir = _config["files_dir"] / to_agent
        files_dir.mkdir(parents=True, exist_ok=True)
        file_path = files_dir / f"{file_id}_{safe_name}"
        file_path.write_bytes(file_bytes)

        # Record in DB
        db = _broker_db
        with _db_lock:
            db.execute(
                "INSERT INTO file_transfers (id, from_agent, to_agent, filename, dest_path, size_bytes, sha256, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (file_id, from_agent, to_agent, safe_name, dest_path, len(file_bytes), file_hash, now)
            )
            db.commit()

        # Also create a message notification
        msg_id = secrets.token_hex(16)
        msg_content = json.dumps({
            "type": "file_transfer",
            "file_id": file_id,
            "filename": safe_name,
            "size_bytes": len(file_bytes),
            "sha256": file_hash,
            "dest_path": dest_path,
        })
        with _db_lock:
            db.execute(
                "INSERT INTO messages (id, from_agent, to_agent, content, created_at) VALUES (?, ?, ?, ?, ?)",
                (msg_id, from_agent, to_agent, msg_content, now)
            )
            db.commit()

        # Push notify + wakeup queue so peer_daemon picks it up if agent is offline
        notify_payload = {
            "type": "file_transfer",
            "file_id": file_id,
            "from_agent": from_agent,
            "filename": safe_name,
            "size_bytes": len(file_bytes),
        }
        self._notify_agent(to_agent, notify_payload)
        self._insert_wakeup(to_agent, "file_received", notify_payload,
                            idempotency_key=f"file:{file_id}")

        self._json_response({
            "status": "sent",
            "file_id": file_id,
            "filename": safe_name,
            "size_bytes": len(file_bytes),
            "sha256": file_hash,
            "download_url": f"/files/download/{file_id}",
        })

    def _handle_list_files(self, params: dict):
        """List pending file transfers for an agent."""
        agent_id = params.get("agent_id", [None])[0]
        if not agent_id:
            self._json_response({"error": "agent_id query param required"}, 400)
            return
        db = _broker_db
        rows = db.execute(
            "SELECT * FROM file_transfers WHERE to_agent = ? AND received = 0 ORDER BY created_at DESC",
            (agent_id,)
        ).fetchall()
        files = []
        for r in rows:
            files.append({
                "id": r["id"],
                "from_agent": r["from_agent"],
                "filename": r["filename"],
                "dest_path": r["dest_path"],
                "size_bytes": r["size_bytes"],
                "sha256": r["sha256"],
                "created_at": r["created_at"],
                "received": bool(r["received"]),
                "download_url": f"/files/download/{r['id']}",
            })
        self._json_response({"files": files, "count": len(files)})

    def _handle_acknowledge_file(self):
        """Mark a file as received so it stops appearing in unread polls."""
        data = self._read_body()
        file_id = data.get("file_id")
        if not file_id:
            self._json_response({"error": "file_id required"}, 400)
            return
        db = _broker_db
        with _db_lock:
            db.execute("UPDATE file_transfers SET received=1 WHERE id=?", (file_id,))
            db.commit()
        self._json_response({"status": "acknowledged", "file_id": file_id})

    # ------------------------------------------------------------------ #
    #  Paperclip-style task queue + wakeup system                         #
    # ------------------------------------------------------------------ #

    def _insert_wakeup(self, agent_id: str, reason: str, payload: dict,
                       idempotency_key: str | None = None):
        """Insert a wakeup row, coalescing if one is already queued for this agent+key."""
        db = _broker_db
        now = _now_iso()
        wakeup_id = str(uuid.uuid4())  # noqa:UUID4_SECURITY_TOKEN — row identifier, not a secret
        if idempotency_key:
            with _db_lock:
                existing = db.execute(
                    "SELECT id FROM wakeup_queue WHERE idempotency_key=? AND status='queued'",
                    (idempotency_key,)
                ).fetchone()
                if existing:
                    db.execute(
                        "UPDATE wakeup_queue SET coalesced_count=coalesced_count+1 WHERE id=?",
                        (existing["id"],)
                    )
                    db.commit()
                    return
        with _db_lock:
            db.execute(
                "INSERT INTO wakeup_queue (id, agent_id, reason, payload, status, idempotency_key, created_at) "
                "VALUES (?, ?, ?, ?, 'queued', ?, ?)",
                (wakeup_id, agent_id, reason, json.dumps(payload), idempotency_key, now)
            )
            db.commit()
        # Also fire HTTP notify if agent has a notify_url registered
        self._notify_agent(agent_id, {"event_type": reason, "from_agent": "broker",
                                      "summary": reason, **payload})

    def _handle_task_create(self):
        data = self._read_body()
        title = data.get("title")
        if not title:
            self._json_response({"error": "title required"}, 400)
            return
        task_id = str(uuid.uuid4())  # noqa:UUID4_SECURITY_TOKEN — task identifier, not a secret
        now = _now_iso()
        created_by = data.get("created_by", "unknown")
        db = _broker_db
        with _db_lock:
            db.execute(
                "INSERT INTO tasks (id, title, description, status, created_by, created_at, updated_at) "
                "VALUES (?, ?, ?, 'todo', ?, ?, ?)",
                (task_id, title, data.get("description", ""), created_by, now, now)
            )
            db.commit()
        # Assign agents if provided
        for agent_id in data.get("assign_to", []):
            self._assign_agent_to_task(task_id, agent_id, "assignee", created_by)
        self._json_response({"status": "created", "task_id": task_id})

    def _assign_agent_to_task(self, task_id: str, agent_id: str, role: str, assigned_by: str):
        db = _broker_db
        now = _now_iso()
        with _db_lock:
            db.execute(
                "INSERT OR REPLACE INTO task_agents (task_id, agent_id, role, assigned_at) VALUES (?,?,?,?)",
                (task_id, agent_id, role, now)
            )
            db.execute("UPDATE tasks SET updated_at=? WHERE id=?", (now, task_id))
            db.commit()
        self._insert_wakeup(agent_id, "task_assigned",
                            {"task_id": task_id, "assigned_by": assigned_by},
                            idempotency_key=f"assign:{task_id}:{agent_id}")

    def _handle_task_assign(self):
        data = self._read_body()
        task_id = data.get("task_id")
        agent_id = data.get("agent_id")
        if not task_id or not agent_id:
            self._json_response({"error": "task_id and agent_id required"}, 400)
            return
        self._assign_agent_to_task(task_id, agent_id,
                                   data.get("role", "assignee"),
                                   data.get("assigned_by", "unknown"))
        self._json_response({"status": "assigned", "task_id": task_id, "agent_id": agent_id})

    def _handle_task_comment(self):
        data = self._read_body()
        task_id   = data.get("task_id")
        from_agent = data.get("from_agent")
        content   = data.get("content")
        if not all([task_id, from_agent, content]):
            self._json_response({"error": "task_id, from_agent, content required"}, 400)
            return
        comment_id = str(uuid.uuid4())  # noqa:UUID4_SECURITY_TOKEN — comment identifier, not a secret
        now = _now_iso()
        db = _broker_db
        with _db_lock:
            db.execute(
                "INSERT INTO task_comments (id, task_id, from_agent, content, created_at) VALUES (?,?,?,?,?)",
                (comment_id, task_id, from_agent, content, now)
            )
            db.execute("UPDATE tasks SET updated_at=? WHERE id=?", (now, task_id))
            db.commit()
        # Parse @mentions — wake each mentioned agent
        import re as _re
        mentioned = _re.findall(r"@(\w+)", content)
        for agent_id in set(mentioned):
            if agent_id != from_agent:
                self._insert_wakeup(agent_id, "mentioned",
                                    {"task_id": task_id, "comment_id": comment_id,
                                     "from_agent": from_agent,
                                     "preview": content[:200]},
                                    idempotency_key=f"mention:{comment_id}:{agent_id}")
        self._json_response({"status": "commented", "comment_id": comment_id,
                              "woke_agents": list(set(mentioned))})

    def _handle_task_checkout(self):
        """Lock a task to the current run — prevents double-claim."""
        data = self._read_body()
        task_id = data.get("task_id")
        agent_id = data.get("agent_id")
        if not task_id or not agent_id:
            self._json_response({"error": "task_id and agent_id required"}, 400)
            return
        db = _broker_db
        now = _now_iso()
        with _db_lock:
            row = db.execute("SELECT status FROM tasks WHERE id=?", (task_id,)).fetchone()
            if not row:
                self._json_response({"error": "task not found"}, 404)
                return
            if row["status"] == "in_progress":
                self._json_response({"error": "already checked out"}, 409)
                return
            db.execute("UPDATE tasks SET status='in_progress', updated_at=? WHERE id=?", (now, task_id))
            db.commit()
        self._json_response({"status": "checked_out", "task_id": task_id})

    def _handle_task_status(self):
        """Update task status (in_progress → done etc)."""
        data = self._read_body()
        task_id = data.get("task_id")
        status  = data.get("status")
        if not task_id or status not in ("todo", "in_progress", "done"):
            self._json_response({"error": "task_id and valid status required"}, 400)
            return
        db = _broker_db
        with _db_lock:
            db.execute("UPDATE tasks SET status=?, updated_at=? WHERE id=?",
                       (status, _now_iso(), task_id))
            db.commit()
        self._json_response({"status": "updated", "task_id": task_id, "new_status": status})

    def _handle_task_list(self, params: dict):
        """List tasks, optionally filtered by agent."""
        db = _broker_db
        agent_id = params.get("agent_id", [None])[0]
        if agent_id:
            rows = db.execute(
                "SELECT t.* FROM tasks t JOIN task_agents ta ON t.id=ta.task_id "
                "WHERE ta.agent_id=? ORDER BY t.updated_at DESC",
                (agent_id,)
            ).fetchall()
        else:
            rows = db.execute("SELECT * FROM tasks ORDER BY updated_at DESC").fetchall()
        tasks = [{"id": r["id"], "title": r["title"], "description": r["description"],
                  "status": r["status"], "created_by": r["created_by"],
                  "created_at": r["created_at"], "updated_at": r["updated_at"]}
                 for r in rows]
        self._json_response({"tasks": tasks, "count": len(tasks)})

    def _handle_wakeup_next(self, params: dict):
        """Claim the next queued wakeup for an agent — what peer_daemon polls."""
        agent_id = params.get("agent_id", [None])[0]
        if not agent_id:
            self._json_response({"error": "agent_id required"}, 400)
            return
        db = _broker_db
        now = _now_iso()
        with _db_lock:
            row = db.execute(
                "SELECT * FROM wakeup_queue WHERE agent_id=? AND status='queued' "
                "ORDER BY created_at ASC LIMIT 1",
                (agent_id,)
            ).fetchone()
            if not row:
                self._json_response({"wakeup": None})
                return
            db.execute(
                "UPDATE wakeup_queue SET status='running', claimed_at=? WHERE id=?",
                (now, row["id"])
            )
            db.commit()
        self._json_response({
            "wakeup": {
                "id": row["id"],
                "agent_id": row["agent_id"],
                "reason": row["reason"],
                "payload": json.loads(row["payload"]),
                "coalesced_count": row["coalesced_count"],
                "created_at": row["created_at"],
            }
        })

    def _handle_wakeup_done(self):
        """Mark a wakeup as completed."""
        data = self._read_body()
        wakeup_id = data.get("wakeup_id")
        if not wakeup_id:
            self._json_response({"error": "wakeup_id required"}, 400)
            return
        db = _broker_db
        with _db_lock:
            db.execute("UPDATE wakeup_queue SET status='done' WHERE id=?", (wakeup_id,))
            db.commit()
        self._json_response({"status": "done", "wakeup_id": wakeup_id})

    def _handle_download_file(self, file_id: str):
        """Download a transferred file by ID."""
        db = _broker_db
        row = db.execute("SELECT * FROM file_transfers WHERE id = ?", (file_id,)).fetchone()
        if not row:
            self._json_response({"error": "file not found"}, 404)
            return

        file_path = _config["files_dir"] / row["to_agent"] / f"{file_id}_{row['filename']}"
        if not file_path.exists():
            self._json_response({"error": "file data missing"}, 404)
            return

        # Mark as received
        with _db_lock:
            db.execute("UPDATE file_transfers SET received = 1 WHERE id = ?", (file_id,))
            db.commit()

        # Send raw bytes
        file_bytes = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition", f'attachment; filename="{row["filename"]}"')
        self.send_header("Content-Length", str(len(file_bytes)))
        self.send_header("X-SHA256", row["sha256"])
        self.end_headers()
        self.wfile.write(file_bytes)


# ---------------------------------------------------------------------------
# Broker Server (background thread)
# ---------------------------------------------------------------------------

_broker_server: HTTPServer | None = None
_broker_thread: threading.Thread | None = None


def _port_in_use(port: int) -> bool:
    """Check if a port is already bound."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _broker_is_ours(url: str) -> bool:
    """Check if an existing broker at URL responds to our health endpoint."""
    try:
        req = Request(f"{url}/health", method="GET")
        resp = urlopen(req, timeout=2)
        data = json.loads(resp.read())
        return data.get("status") == "ok"
    except Exception:
        return False


def start_broker() -> bool:
    """Start the embedded HTTP broker in a background thread.

    Returns True if broker was started (or already running), False on failure.
    Refuses to start if PEER_BROKER_TOKEN is not set — unauthenticated brokers
    are a security risk.
    """
    global _broker_server, _broker_thread

    # SECURITY: require pre-shared secret — never run an open broker
    if not _BROKER_TOKEN:
        print(
            "FATAL: PEER_BROKER_TOKEN environment variable is not set. "
            "Broker refuses to start without authentication. "
            "Set PEER_BROKER_TOKEN to a strong random secret.",
            file=sys.stderr,
        )
        return False

    parsed = urlparse(_config["broker_url"])
    host = parsed.hostname or "localhost"
    port = parsed.port or DEFAULT_PORT

    # If pointing at a remote broker, don't start locally
    if host not in ("localhost", "127.0.0.1", "::1"):
        print(f"Using remote broker at {_config['broker_url']}", file=sys.stderr)
        return True

    # Check if broker already running on this port
    if _port_in_use(port):
        if _broker_is_ours(_config["broker_url"]):
            print(f"Broker already running at {_config['broker_url']}", file=sys.stderr)
            return True
        else:
            print(f"Port {port} in use by another service", file=sys.stderr)
            return False

    # Initialize DB and start server
    _init_broker_db()

    _broker_server = HTTPServer(("0.0.0.0", port), BrokerHandler)
    _broker_thread = threading.Thread(target=_broker_server.serve_forever, daemon=True)
    _broker_thread.start()
    print(f"Broker started on port {port}", file=sys.stderr)
    return True


def stop_broker():
    """Shut down the embedded broker."""
    global _broker_server, _broker_db
    if _broker_server:
        _broker_server.shutdown()
        _broker_server = None
    if _broker_db:
        _broker_db.close()
        _broker_db = None


# ---------------------------------------------------------------------------
# Broker Client (HTTP calls from MCP tools to broker)
# ---------------------------------------------------------------------------

def _broker_get(path: str, params: dict | None = None) -> dict:
    """GET request to broker with HMAC signing."""
    url = _config["broker_url"] + path
    if params:
        qs = urlencode({k: v for k, v in params.items() if v is not None})
        if qs:
            url += f"?{qs}"
    headers = {}
    # Attach HMAC signature if token is configured (sign the URL path+query)
    if _BROKER_TOKEN:
        ts = str(time.time())
        sign_body = url.split(_config["broker_url"], 1)[1].encode("utf-8") if _config["broker_url"] else url.encode("utf-8")
        headers["X-HMAC-Signature"] = _compute_hmac(sign_body, ts)
        headers["X-HMAC-Timestamp"] = ts
    req = Request(url, method="GET", headers=headers)
    try:
        resp = urlopen(req, timeout=10)
        return json.loads(resp.read())
    except URLError as e:
        return {"error": f"Broker unreachable: {e}"}
    except Exception as e:
        return {"error": str(e)}


def _broker_post(path: str, data: dict) -> dict:
    """POST JSON to broker with HMAC signing."""
    url = _config["broker_url"] + path
    body = json.dumps(data).encode()
    headers = {"Content-Type": "application/json"}
    # Attach HMAC signature if token is configured
    if _BROKER_TOKEN:
        ts = str(time.time())
        headers["X-HMAC-Signature"] = _compute_hmac(body, ts)
        headers["X-HMAC-Timestamp"] = ts
    req = Request(url, method="POST", data=body, headers=headers)
    try:
        resp = urlopen(req, timeout=10)
        return json.loads(resp.read())
    except URLError as e:
        return {"error": f"Broker unreachable: {e}"}
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Pruning thread — runs periodically to clean dead peers
# ---------------------------------------------------------------------------

_pruner_running = False


def _start_pruner():
    """Background thread that prunes dead peers every 30 seconds."""
    global _pruner_running
    if _pruner_running:
        return
    _pruner_running = True

    def _prune_loop():
        while _pruner_running:
            time.sleep(30)
            try:
                if _broker_db is not None:
                    _prune_dead_peers()
                    # Also clean old read messages (older than 1 hour)
                    cutoff = datetime.fromtimestamp(
                        datetime.now(timezone.utc).timestamp() - 3600,
                        tz=timezone.utc
                    ).isoformat()
                    with _db_lock:
                        _broker_db.execute(
                            "DELETE FROM messages WHERE read = 1 AND created_at < ?",
                            (cutoff,)
                        )
                        _broker_db.commit()
            except Exception:
                pass

    t = threading.Thread(target=_prune_loop, daemon=True)
    t.start()


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

def create_server() -> Server:
    server = Server("aibrain-peers")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="peer_register",
                description=(
                    "Register this agent as a peer in the discovery mesh. "
                    "Other agents can then discover and message you. "
                    "Call once at session start."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "Unique identifier for this agent instance (e.g., 'claude-abc123')"
                        },
                        "agent_type": {
                            "type": "string",
                            "description": "Agent runtime type: 'claude', 'cursor', 'copilot', 'custom', etc.",
                            "default": "unknown"
                        },
                        "pid": {
                            "type": "integer",
                            "description": "OS process ID of the agent (for zombie detection)"
                        },
                        "cwd": {
                            "type": "string",
                            "description": "Current working directory"
                        },
                        "git_root": {
                            "type": "string",
                            "description": "Git repository root path (if in a repo)"
                        },
                        "summary": {
                            "type": "string",
                            "description": "Short description of what this agent is working on",
                            "default": ""
                        },
                        "capabilities": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of capability tags (e.g., ['code', 'test', 'deploy'])",
                            "default": []
                        },
                        "notify_url": {
                            "type": "string",
                            "description": "Webhook URL for push notifications — broker POSTs to this URL when messages/files arrive for this agent. No polling needed.",
                            "default": ""
                        }
                    },
                    "required": ["agent_id"]
                }
            ),
            Tool(
                name="peer_heartbeat",
                description="Update last_seen timestamp to signal this agent is still alive. Call every ~15 seconds.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "This agent's ID"
                        }
                    },
                    "required": ["agent_id"]
                }
            ),
            Tool(
                name="peer_set_summary",
                description="Update what this agent is currently working on. Visible to all peers.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "This agent's ID"
                        },
                        "summary": {
                            "type": "string",
                            "description": "Short description of current work"
                        }
                    },
                    "required": ["agent_id", "summary"]
                }
            ),
            Tool(
                name="peer_list",
                description=(
                    "List active peers. Filter by scope: 'machine' (all), 'directory' (same cwd), "
                    "'repo' (same git root), 'capability' (has capability), 'type' (agent type)."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "scope": {
                            "type": "string",
                            "enum": ["machine", "directory", "repo", "capability", "type"],
                            "description": "Filter scope",
                            "default": "machine"
                        },
                        "scope_value": {
                            "type": "string",
                            "description": "Value for the scope filter (directory path, git root, capability name, or agent type)"
                        }
                    },
                    "required": []
                }
            ),
            Tool(
                name="peer_send_message",
                description="Send a message to a specific peer agent.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "from_agent": {
                            "type": "string",
                            "description": "Sender agent ID"
                        },
                        "to_agent": {
                            "type": "string",
                            "description": "Recipient agent ID"
                        },
                        "content": {
                            "type": "string",
                            "description": "Message content (text or JSON string)"
                        }
                    },
                    "required": ["from_agent", "to_agent", "content"]
                }
            ),
            Tool(
                name="peer_check_messages",
                description="Check for unread incoming messages for this agent.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "This agent's ID"
                        },
                        "mark_read": {
                            "type": "boolean",
                            "description": "Whether to mark retrieved messages as read (default true)",
                            "default": True
                        }
                    },
                    "required": ["agent_id"]
                }
            ),
            Tool(
                name="peer_broadcast",
                description=(
                    "Send a message to all active peers (or a filtered subset). "
                    "Useful for announcements or coordination requests."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "from_agent": {
                            "type": "string",
                            "description": "Sender agent ID"
                        },
                        "content": {
                            "type": "string",
                            "description": "Message content"
                        },
                        "scope": {
                            "type": "string",
                            "enum": ["all", "repo", "directory", "capability", "type"],
                            "description": "Broadcast scope filter",
                            "default": "all"
                        },
                        "scope_value": {
                            "type": "string",
                            "description": "Value for the scope filter"
                        }
                    },
                    "required": ["from_agent", "content"]
                }
            ),
            Tool(
                name="peer_unregister",
                description="Remove this agent from the peer mesh. Call on session end / shutdown.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agent_id": {
                            "type": "string",
                            "description": "This agent's ID"
                        }
                    },
                    "required": ["agent_id"]
                }
            ),
            Tool(
                name="peer_status",
                description="Get broker health: peer count, message queue depth, uptime.",
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            ),
            Tool(
                name="peer_send_file",
                description=(
                    "Send a file to a peer agent over the mesh. File is base64-encoded, "
                    "stored on the broker, and the recipient gets a notification. "
                    "Use for code, configs, DB snapshots, skills, or any artifact."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "from_agent": {"type": "string", "description": "Sender agent ID"},
                        "to_agent": {"type": "string", "description": "Recipient agent ID"},
                        "file_path": {"type": "string", "description": "Local path of the file to send"},
                        "dest_path": {
                            "type": "string",
                            "description": "Suggested destination path on the recipient's machine (optional)",
                            "default": ""
                        },
                    },
                    "required": ["from_agent", "to_agent", "file_path"]
                }
            ),
            Tool(
                name="peer_list_files",
                description="List files that have been sent to this agent (pending and received).",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "agent_id": {"type": "string", "description": "This agent's ID"},
                    },
                    "required": ["agent_id"]
                }
            ),
            Tool(
                name="peer_receive_file",
                description=(
                    "Download a file sent by a peer. Saves to dest_path if specified "
                    "in the transfer, otherwise saves to current directory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "file_id": {"type": "string", "description": "File transfer ID from peer_list_files"},
                        "save_to": {
                            "type": "string",
                            "description": "Override save location (optional — uses sender's dest_path if empty)",
                            "default": ""
                        },
                    },
                    "required": ["file_id"]
                }
            ),
            Tool(
                name="peer_sync_brain",
                description=(
                    "Sync this agent's memory database to a peer. Sends the aibrain.db file "
                    "so the recipient can merge or replace their brain. Pro tier feature."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "from_agent": {"type": "string", "description": "Sender agent ID"},
                        "to_agent": {"type": "string", "description": "Recipient agent ID"},
                        "db_path": {
                            "type": "string",
                            "description": "Path to the brain DB to sync (default: auto-detect aibrain.db)"
                        },
                    },
                    "required": ["from_agent", "to_agent"]
                }
            ),
            Tool(
                name="peer_share_skill",
                description=(
                    "Share a learned skill (SKILL.md file) with a peer agent. "
                    "The peer receives the skill and can register it in their skill evolution system."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "from_agent": {"type": "string", "description": "Sender agent ID"},
                        "to_agent": {"type": "string", "description": "Recipient agent ID"},
                        "skill_path": {"type": "string", "description": "Path to the SKILL.md file to share"},
                    },
                    "required": ["from_agent", "to_agent", "skill_path"]
                }
            ),
            Tool(
                name="peer_deploy_config",
                description=(
                    "Push config files to a peer (config.json, scheduled_jobs.json, etc). "
                    "Useful for deploying consistent settings across multiple agents."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "from_agent": {"type": "string", "description": "Sender agent ID"},
                        "to_agent": {"type": "string", "description": "Recipient agent ID"},
                        "config_files": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of config file paths to send"
                        },
                    },
                    "required": ["from_agent", "to_agent", "config_files"]
                }
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        try:
            if name == "peer_register":
                result = _broker_post("/peers/register", {
                    "agent_id": arguments["agent_id"],
                    "agent_type": arguments.get("agent_type", "unknown"),
                    "pid": arguments.get("pid"),
                    "cwd": arguments.get("cwd"),
                    "git_root": arguments.get("git_root"),
                    "summary": arguments.get("summary", ""),
                    "capabilities": arguments.get("capabilities", []),
                    "notify_url": arguments.get("notify_url", ""),
                })
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_heartbeat":
                result = _broker_post("/peers/heartbeat", {
                    "agent_id": arguments["agent_id"],
                })
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_set_summary":
                result = _broker_post("/peers/summary", {
                    "agent_id": arguments["agent_id"],
                    "summary": arguments["summary"],
                })
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_list":
                scope = arguments.get("scope", "machine")
                scope_value = arguments.get("scope_value")
                params = {}
                if scope and scope != "machine":
                    params["scope"] = scope
                    if scope_value:
                        params["scope_value"] = scope_value
                result = _broker_get("/peers", params)
                if "error" in result:
                    return [TextContent(type="text", text=json.dumps(result, indent=2))]
                peers = result.get("peers", [])
                if not peers:
                    return [TextContent(type="text", text="No active peers found.")]
                lines = [f"Active peers ({len(peers)}):"]
                for p in peers:
                    caps = ", ".join(p.get("capabilities", []))
                    lines.append(
                        f"\n  [{p['agent_type']}] {p['agent_id']}"
                        f"\n    Summary: {p.get('summary') or '(none)'}"
                        f"\n    CWD: {p.get('cwd') or '?'}"
                        f"\n    Git: {p.get('git_root') or '?'}"
                        f"\n    Capabilities: {caps or '(none)'}"
                        f"\n    Last seen: {p['last_seen']}"
                    )
                return [TextContent(type="text", text="\n".join(lines))]

            elif name == "peer_send_message":
                result = _broker_post("/messages/send", {
                    "from_agent": arguments["from_agent"],
                    "to_agent": arguments["to_agent"],
                    "content": arguments["content"],
                })
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_check_messages":
                mark_read = arguments.get("mark_read", True)
                result = _broker_get("/messages", {
                    "agent_id": arguments["agent_id"],
                    "mark_read": str(mark_read).lower(),
                })
                if "error" in result:
                    return [TextContent(type="text", text=json.dumps(result, indent=2))]
                messages = result.get("messages", [])
                if not messages:
                    return [TextContent(type="text", text="No new messages.")]
                lines = [f"Unread messages ({len(messages)}):"]
                for m in messages:
                    lines.append(
                        f"\n  From: {m['from_agent']}"
                        f"\n  At: {m['created_at']}"
                        f"\n  Content: {m['content']}"
                        f"\n  ---"
                    )
                return [TextContent(type="text", text="\n".join(lines))]

            elif name == "peer_broadcast":
                data = {
                    "from_agent": arguments["from_agent"],
                    "content": arguments["content"],
                }
                scope = arguments.get("scope", "all")
                if scope and scope != "all":
                    data["scope"] = scope
                    if arguments.get("scope_value"):
                        data["scope_value"] = arguments["scope_value"]
                result = _broker_post("/messages/broadcast", data)
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_unregister":
                result = _broker_post("/peers/unregister", {
                    "agent_id": arguments["agent_id"],
                })
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_status":
                result = _broker_get("/status")
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_send_file":
                file_path = Path(arguments["file_path"])
                if not file_path.exists():
                    return [TextContent(type="text", text=f"File not found: {file_path}")]
                if file_path.stat().st_size > _config["max_file_size"]:
                    return [TextContent(type="text", text=f"File too large (max {_config['max_file_size'] // 1024 // 1024}MB)")]

                content_b64 = base64.b64encode(file_path.read_bytes()).decode()
                result = _broker_post("/files/send", {
                    "from_agent": arguments["from_agent"],
                    "to_agent": arguments["to_agent"],
                    "filename": file_path.name,
                    "content_b64": content_b64,
                    "dest_path": arguments.get("dest_path", ""),
                })
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "peer_list_files":
                result = _broker_get("/files", {"agent_id": arguments["agent_id"]})
                if "error" in result:
                    return [TextContent(type="text", text=json.dumps(result, indent=2))]
                files = result.get("files", [])
                if not files:
                    return [TextContent(type="text", text="No file transfers.")]
                lines = [f"File transfers ({len(files)}):"]
                for f in files:
                    status = "received" if f["received"] else "PENDING"
                    lines.append(
                        f"\n  [{status}] {f['filename']} ({f['size_bytes']} bytes)"
                        f"\n    From: {f['from_agent']} | ID: {f['id']}"
                        f"\n    Dest: {f['dest_path'] or '(not specified)'}"
                        f"\n    SHA256: {f['sha256'][:16]}..."
                    )
                return [TextContent(type="text", text="\n".join(lines))]

            elif name == "peer_receive_file":
                file_id = arguments["file_id"]
                # Get file metadata first
                result = _broker_get("/files", {"agent_id": "any"})
                # Download the file
                url = _config["broker_url"] + f"/files/download/{file_id}"
                try:
                    req = Request(url, method="GET")
                    resp = urlopen(req, timeout=30)
                    file_bytes = resp.read()
                    content_disp = resp.headers.get("Content-Disposition", "")
                    sha256_header = resp.headers.get("X-SHA256", "")

                    # Verify hash
                    actual_hash = hashlib.sha256(file_bytes).hexdigest()
                    if sha256_header and actual_hash != sha256_header:
                        return [TextContent(type="text", text=f"SHA256 MISMATCH — file corrupted! Expected {sha256_header}, got {actual_hash}")]

                    # Determine save path
                    filename = "downloaded_file"
                    if 'filename="' in content_disp:
                        filename = content_disp.split('filename="')[1].rstrip('"')

                    save_to = arguments.get("save_to", "").strip()
                    if save_to:
                        save_path = Path(save_to)
                        if save_path.is_dir():
                            save_path = save_path / filename
                    else:
                        save_path = Path.cwd() / filename

                    save_path.parent.mkdir(parents=True, exist_ok=True)
                    save_path.write_bytes(file_bytes)

                    return [TextContent(type="text", text=f"File saved: {save_path} ({len(file_bytes)} bytes, SHA256 verified)")]
                except Exception as e:
                    return [TextContent(type="text", text=f"Download failed: {e}")]

            elif name == "peer_sync_brain":
                # Find the brain DB
                db_path = arguments.get("db_path", "")
                if not db_path:
                    # Auto-detect
                    candidates = [
                        Path(os.environ.get("AIBRAIN_ROOT", "")) / "aibrain.db",
                        Path.cwd() / "aibrain.db",
                        Path(__file__).parent / "aibrain.db",
                    ]
                    for c in candidates:
                        if c.exists():
                            db_path = str(c)
                            break
                if not db_path or not Path(db_path).exists():
                    return [TextContent(type="text", text="Could not find aibrain.db — specify db_path")]

                content_b64 = base64.b64encode(Path(db_path).read_bytes()).decode()
                result = _broker_post("/files/send", {
                    "from_agent": arguments["from_agent"],
                    "to_agent": arguments["to_agent"],
                    "filename": "aibrain.db",
                    "content_b64": content_b64,
                    "dest_path": "aibrain_sync/",
                })
                size_mb = Path(db_path).stat().st_size / 1024 / 1024
                return [TextContent(type="text", text=f"Brain sync sent ({size_mb:.1f}MB)\n{json.dumps(result, indent=2)}")]

            elif name == "peer_share_skill":
                skill_path = Path(arguments["skill_path"])
                if not skill_path.exists():
                    return [TextContent(type="text", text=f"Skill file not found: {skill_path}")]
                content_b64 = base64.b64encode(skill_path.read_bytes()).decode()
                result = _broker_post("/files/send", {
                    "from_agent": arguments["from_agent"],
                    "to_agent": arguments["to_agent"],
                    "filename": skill_path.name,
                    "content_b64": content_b64,
                    "dest_path": "skills/",
                })
                return [TextContent(type="text", text=f"Skill shared: {skill_path.name}\n{json.dumps(result, indent=2)}")]

            elif name == "peer_deploy_config":
                config_files = arguments["config_files"]
                results = []
                for cf in config_files:
                    cf_path = Path(cf)
                    if not cf_path.exists():
                        results.append(f"SKIP {cf} — not found")
                        continue
                    content_b64 = base64.b64encode(cf_path.read_bytes()).decode()
                    result = _broker_post("/files/send", {
                        "from_agent": arguments["from_agent"],
                        "to_agent": arguments["to_agent"],
                        "filename": cf_path.name,
                        "content_b64": content_b64,
                        "dest_path": "config/",
                    })
                    results.append(f"SENT {cf_path.name} — {result.get('status', 'error')}")
                return [TextContent(type="text", text="Config deployment:\n" + "\n".join(results))]

            else:
                return [TextContent(type="text", text=f"Unknown tool: {name}")]

        except KeyError as e:
            return [TextContent(type="text", text=f"Missing required argument: {e}")]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]

    return server


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def main():
    parser = argparse.ArgumentParser(description="AIBrain Peer Discovery MCP Server")
    parser.add_argument("--port", type=int, default=None,
                        help=f"Broker port (default: {DEFAULT_PORT})")
    parser.add_argument("--broker-only", action="store_true",
                        help="Run broker HTTP server only (no MCP stdio)")
    parser.add_argument("--db", type=str, default=None,
                        help="Path to peers database (default: ~/aibrain_peers.db)")
    args = parser.parse_args()

    if args.db:
        _config["db_path"] = Path(args.db)
    if args.port:
        _config["broker_port"] = args.port
        _config["broker_url"] = f"http://localhost:{args.port}"

    # Start the embedded broker
    if not start_broker():
        print("WARNING: Could not start local broker. MCP tools will try to reach existing broker.", file=sys.stderr)

    # Start the pruner thread
    if _broker_db is not None:
        _start_pruner()

    if args.broker_only:
        print(f"Broker running on port {_config['broker_port']}. Press Ctrl+C to stop.", file=sys.stderr)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            stop_broker()
            return
    else:
        # Run MCP server over stdio
        server = create_server()
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
