"""
broker_hook.py — AIBrain Claude Code UserPromptSubmit hook.

Runs before every agent response. Three jobs:
  1. ONE-SHOT stack restore on first prompt of each session
  2. Check peer broker for unread messages and files from other agents
  3. Self-register on peer broker to stay discoverable

Generic and portable — works on any platform with zero hardcoded values.
All config comes from env vars or config.json.

Configuration (checked in order):
  Environment:
    PEER_BROKER_URL  — peer broker URL (default: http://localhost:7800)
    PEER_AGENT_ID    — this agent's ID (default: hostname)
    AIBRAIN_ROOT     — project root (default: this file's parent dir)
  Config file (~/.aibrain/config.json or ./config.json):
    peer_broker_url, agent_id

Install as a Claude Code hook:
  Settings -> hooks -> UserPromptSubmit -> command:
    python /path/to/aibrain/broker_hook.py
"""

import json
import os
import socket
import subprocess
import sys
import urllib.request
import urllib.parse
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent))

# Load env file if present
for _env_file in [Path.home() / ".aibrain_env",
                  Path.home() / ".decker_env",
                  AIBRAIN_ROOT / ".env"]:
    if _env_file.exists():
        try:
            for _line in _env_file.read_text(encoding="utf-8").splitlines():
                _line = _line.strip()
                if _line and not _line.startswith("#") and "=" in _line:
                    _k, _v = _line.split("=", 1)
                    os.environ.setdefault(_k.strip(), _v.strip().strip('"'))
        except Exception:
            pass
        break

# Read config.json for peer settings
_peer_url_default = "http://localhost:7800"
_agent_id_default = socket.gethostname().lower().split(".")[0]

for _cfg_path in [Path.home() / ".aibrain" / "config.json",
                  AIBRAIN_ROOT / "config.json"]:
    if _cfg_path.exists():
        try:
            _cfg = json.loads(_cfg_path.read_text(encoding="utf-8"))
            if _cfg.get("peer_broker_url"):
                _peer_url_default = _cfg["peer_broker_url"]
            if _cfg.get("agent_id"):
                _agent_id_default = _cfg["agent_id"]
            break
        except Exception:
            pass

PEER_URL = os.environ.get("PEER_BROKER_URL", _peer_url_default)
AGENT_ID = os.environ.get("PEER_AGENT_ID", _agent_id_default)


def _get(url, timeout=3):
    """HTTP GET with proxy bypass."""
    req = urllib.request.Request(url)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as r:
        return json.loads(r.read())


def _post(url, data, timeout=3):
    """HTTP POST JSON with proxy bypass."""
    body = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(url, method="POST", data=body,
                                headers={"Content-Type": "application/json; charset=utf-8"})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    opener.open(req, timeout=timeout)


# ---------------------------------------------------------------------------
# 1. ONE-SHOT stack restore — runs once per session on first prompt
# ---------------------------------------------------------------------------
STACK_STAMP = AIBRAIN_ROOT / "data" / ".stack_restored"

try:
    needs_restore = False
    if not STACK_STAMP.exists():
        needs_restore = True
    else:
        stamp_age_sec = datetime.now().timestamp() - STACK_STAMP.stat().st_mtime
        if stamp_age_sec > 1800:
            needs_restore = True

    if needs_restore:
        stack_script = AIBRAIN_ROOT / "stack_snapshot.py"
        snapshot_file = AIBRAIN_ROOT / "data" / "stack_snapshots" / "last.json"

        if stack_script.exists() and snapshot_file.exists():
            result = subprocess.run(
                [sys.executable, str(stack_script), "restore", "last"],
                cwd=str(AIBRAIN_ROOT),
                capture_output=True, text=True, timeout=15,
            )
            if result.stdout.strip():
                lines = result.stdout.strip().splitlines()
                restored_lines = [l for l in lines if "Restored" in l or "+" in l]
                if restored_lines:
                    print("[STACK] Session start — restored from last snapshot:")
                    for line in restored_lines:
                        print(f"  {line.strip()}")

        STACK_STAMP.parent.mkdir(parents=True, exist_ok=True)
        STACK_STAMP.write_text(str(datetime.now().timestamp()), encoding="utf-8")
except Exception:
    pass


# ---------------------------------------------------------------------------
# 1b. Sync Claude Code settings to all VPS profiles on session start
# ---------------------------------------------------------------------------
try:
    # F-BROKER-HOOK-WINDOWS-PROFILE-SKIP-1 (2026-05-11): the canonical claude_settings_vps.json
    # has Linux paths (/usr/bin/python3, /root/aibrain). Syncing those to a Windows profile
    # breaks UserPromptSubmit silently — the Windows Claude Code session can't execute the
    # Linux paths so the hook never runs, no telegram/fleet surfacing, agent appears mute.
    # Skip the sync entirely when running on Windows.
    _is_windows = (os.name == "nt") or sys.platform.startswith("win")
    _canonical = AIBRAIN_ROOT / "data" / "claude_settings_vps.json"
    if not _is_windows and _canonical.exists():
        _canonical_text = _canonical.read_text(encoding="utf-8")
        _profiles = [
            Path.home() / ".claude-case" / "settings.json",
            Path.home() / ".claude-deckerops" / "settings.json",
            Path.home() / ".claude-sindecker" / "settings.json",
        ]
        _synced = []
        for _p in _profiles:
            try:
                _p.parent.mkdir(parents=True, exist_ok=True)
                if not _p.exists() or _p.read_text(encoding="utf-8") != _canonical_text:
                    _p.write_text(_canonical_text, encoding="utf-8")
                    _synced.append(_p.parent.name)
            except Exception:
                pass
        if _synced:
            print(f"  + Synced settings to: {', '.join(_synced)}")

    # Sync .mcp.json to all VPS profiles (skip on Windows — same Linux-path-overwrite issue
    # as the settings.json sync above; mcp_vps.json has /usr/bin/python3 + /root/aibrain paths
    # which would break MCP server launch on Windows hosts).
    _mcp_canonical = AIBRAIN_ROOT / "data" / "mcp_vps.json"
    if not _is_windows and _mcp_canonical.exists():
        _mcp_text = _mcp_canonical.read_text(encoding="utf-8")
        _mcp_targets = [
            Path.home() / ".mcp.json",
            Path.home() / ".claude-case" / ".mcp.json",
            Path.home() / ".claude-deckerops" / ".mcp.json",
            Path.home() / ".claude-sindecker" / ".mcp.json",
            AIBRAIN_ROOT / ".mcp.json",
        ]
        _mcp_synced = []
        for _mp in _mcp_targets:
            try:
                _mp.parent.mkdir(parents=True, exist_ok=True)
                if not _mp.exists() or _mp.read_text(encoding="utf-8") != _mcp_text:
                    _mp.write_text(_mcp_text, encoding="utf-8")
                    _mcp_synced.append(_mp.name if _mp.parent == Path.home() else _mp.parent.name)
            except Exception:
                pass
        if _mcp_synced:
            print(f"  + Synced MCP config to: {', '.join(_mcp_synced)}")
except Exception:
    pass


# ---------------------------------------------------------------------------
# 2. F-COMMS-1 fleet bus — poll for inter-agent messages (F-COMMS-WIRING-1)
# ---------------------------------------------------------------------------
try:
    _fleet_agent_id = os.environ.get("FLEET_AGENT_ID", AGENT_ID)
    sys.path.insert(0, str(AIBRAIN_ROOT))
    # F-LUCY-FLEET-AUTO-RESPONSE-3: peek inbox WITHOUT marking delivered.
    # We use a raw DB query so the daemon's poll_inbox still sees these messages
    # for auto-response processing. The old path called FleetBus.poll_inbox() which
    # marked rows 'delivered', stealing them from the daemon before it could
    # auto-respond. This is the "steal-on-poll" race condition — broker_hook
    # surfaces for display but the DAEMON must handle delivery/processing.
    #
    # Fix (2026-05-11): track surfaced msg_ids in a local seen-file instead of
    # corrupting the DB status. The daemon uses status='pending' to find work;
    # we don't touch that column. broker_hook only displays, never consumes.
    import sqlite3 as _sq3
    import json as _js3
    _db3 = _sq3.connect(str(AIBRAIN_ROOT / "aibrain.db"))
    _db3.row_factory = _sq3.Row
    # F-BROKER-HOOK-SURFACE-FIX (2026-05-11): surface ALL pending messages targeted at neuro,
    # including Lucy's replies. Previously excluded source_agent='agent://lucy' which silently
    # dropped Lucy's autonomy-loop replies and Decker's Telegram messages routed via fleet.
    _raw_rows = _db3.execute(
        "SELECT * FROM agent_messages "
        "WHERE status='pending' "
        "  AND (event_type LIKE 'fleet.message.neuro%' "
        "       OR event_type LIKE 'fleet.broadcast%' "
        "       OR target_agent='neuro' "
        "       OR target_agent='agent://neuro') "
        "ORDER BY created_at ASC LIMIT 20"
    ).fetchall()
    _db3.close()
    # Track surfaced msg_ids in a local file so we don't repeat-display the
    # same messages on every prompt, WITHOUT marking them 'delivered' in the
    # DB (which would steal them from the daemon's poll loop).
    _surfaced_file = Path.home() / ".aibrain" / "broker_hook_surfaced.json"
    _surfaced_set = set()
    try:
        if _surfaced_file.exists():
            _surfaced_set = set(json.loads(_surfaced_file.read_text(encoding="utf-8")))
    except Exception:
        _surfaced_set = set()
    # Only surface messages we haven't displayed before
    _new_rows = [r for r in _raw_rows if r["msg_id"] and r["msg_id"] not in _surfaced_set]
    # Persist newly surfaced IDs
    if _new_rows:
        for _r in _new_rows:
            _surfaced_set.add(_r["msg_id"])
        try:
            _surfaced_file.parent.mkdir(parents=True, exist_ok=True)
            _surfaced_file.write_text(json.dumps(list(_surfaced_set)), encoding="utf-8")
        except Exception:
            pass
    _fleet_msgs = []
    for _row in _new_rows:
        try:
            _fleet_msgs.append({
                "msg_id": _row["msg_id"],
                "source": _row["source_agent"] or "",
                "type": _row["event_type"] or "",
                "subject": _row["subject"] or "",
                "payload": json.loads(_row["payload"]) if _row["payload"] else {},
                "created_at": _row["created_at"],
            })
        except Exception:
            pass
    # F-AGENT-TASK-AUTOPULL-1: auto-pull new tasks from company_issues
    try:
        import sqlite3 as _sq2
        _db2 = _sq2.connect(str(AIBRAIN_ROOT / 'aibrain.db'))
        _new_tasks = _db2.execute(
            "SELECT id, title FROM company_issues WHERE assignee_agent_id=? AND status='todo' ORDER BY created_at DESC LIMIT 5",
            (_fleet_agent_id,)).fetchall()
        _db2.close()
        for _nt in _new_tasks:
            _fleet_msgs.append({
                'source': 'company', 'type': 'task.assigned',
                'subject': _nt[1], 'payload': {'task_id': _nt[0]}
            })
    except Exception:
        pass
    if _fleet_msgs:
        for _fm in _fleet_msgs[:5]:
            _src = _fm.get("source", "?").replace("agent://", "")
            _typ = _fm.get("type", "?")
            _subj = _fm.get("subject", "")
            _payload = _fm.get("payload", {}) or {}
            # Extract human-readable content from payload
            _content = ""
            if isinstance(_payload, dict):
                _content = (_payload.get("msg") or _payload.get("text")
                            or _payload.get("body") or _payload.get("content") or "")
            if _content:
                print(f"[FLEET inbound from {_src}] {_typ}")
                print(f"  {_content[:500]}")
            else:
                print(f"[FLEET from {_src}] {_typ}: {_subj}")
except Exception:
    pass

# ---------------------------------------------------------------------------
# F-COMMS-WIRING-OPERATIONAL-1: heartbeat on session start
try:
    from aibrain.core.agent_comms import FleetBus
    _hb_bus = FleetBus(agent_id='neuro@windows-local', db_path=str(AIBRAIN_ROOT / 'aibrain.db'))
    _hb_bus.publish('fleet.heartbeat.neuro', {'status': 'session_start'})
except Exception:
    pass

# F-DISCORD-SETUP-1: Discord webhook check
try:
    from aibrain.core.agent_comms import _handle_discord_webhook, reply_to_discord
    import json as _j, os as _os2
    _discord_payload = _os2.environ.get('AIBRAIN_DISCORD_PAYLOAD', '')
    if _discord_payload:
        _discord_msgs = _handle_discord_webhook(_j.loads(_discord_payload))
        _fleet_msgs.extend(_discord_msgs)
except Exception:
    pass

# 3. Check peer broker for unread messages
# ---------------------------------------------------------------------------
try:
    data = _get(f"{PEER_URL}/messages?agent_id={AGENT_ID}")
    msgs = data.get("messages", [])
    if msgs:
        for m in msgs:
            content = m.get("content", "(no content)")
            print(f"[PEER from {m.get('from_agent', '?')}]: {content}")
except Exception:
    pass


# ---------------------------------------------------------------------------
# 3. Check peer broker for unread files
# ---------------------------------------------------------------------------
try:
    data = _get(f"{PEER_URL}/files?agent_id={AGENT_ID}")
    files = data.get("files", [])
    if files:
        print(f"[PEER] {len(files)} unread file(s):")
        for f in files:
            from_agent = f.get("from_agent", "?")
            filename = f.get("filename", "?")
            size = f.get("size_bytes", 0)
            download = f.get("download_url", "")
            print(f"  [{f.get('created_at', '')}] {from_agent}: {filename} ({size} bytes) — {PEER_URL}{download}")
            # Auto-acknowledge so files don't repeat on every prompt
            try:
                _post(f"{PEER_URL}/files/acknowledge",
                      {"file_id": f["id"], "agent_id": AGENT_ID})
            except Exception:
                pass
except Exception:
    pass


# ---------------------------------------------------------------------------
# 3b-W. Windows-side Telegram surfacing (F-BROKER-HOOK-TELEGRAM-WINDOWS-1, 2026-05-11)
# Surface unread Telegram messages from telegram_messages.db using a "last seen
# update_id" tracker file. Decker's Telegram messages get rendered as
# [TELEGRAM from Matthew] banners so they appear in Neuro's context here on Windows.
# ---------------------------------------------------------------------------
try:
    _tg_db = Path.home() / "decker_system" / "telegram_messages.db"
    _tg_seen_file = Path.home() / ".tmp" / "neuro_telegram_last_seen_update_id.txt"
    if _tg_db.exists():
        import sqlite3 as _sq_tg
        _last_seen = 0
        if _tg_seen_file.exists():
            try:
                _last_seen = int(_tg_seen_file.read_text(encoding="utf-8").strip() or "0")
            except Exception:
                _last_seen = 0
        _tgdb = _sq_tg.connect(str(_tg_db))
        _tgdb.row_factory = _sq_tg.Row
        _tg_rows = _tgdb.execute(
            "SELECT update_id, from_name, chat_id, text, logged_at FROM messages "
            "WHERE update_id > ? AND from_name IS NOT NULL "
            "ORDER BY update_id ASC LIMIT 10",
            (_last_seen,),
        ).fetchall()
        _tgdb.close()
        if _tg_rows:
            _max_seen = _last_seen
            print(f"\n[REPLY REQUIRED] {len(_tg_rows)} unactioned Telegram message(s) from Decker:")
            for _tr in _tg_rows:
                print(f"  [TELEGRAM {_tr['logged_at']}] from {_tr['from_name']} chat={_tr['chat_id']}")
                print(f"    {(_tr['text'] or '')[:500]}")
                if _tr["update_id"] > _max_seen:
                    _max_seen = _tr["update_id"]
            # persist new last_seen
            try:
                _tg_seen_file.parent.mkdir(parents=True, exist_ok=True)
                _tg_seen_file.write_text(str(_max_seen), encoding="utf-8")
            except Exception:
                pass
except Exception:
    pass

# ---------------------------------------------------------------------------
# 3b. Surface unactioned Telegrams + emails via agent_comms (observability)
# Linux (Case) paths — overrides the module's Windows defaults via env vars.
# Best-effort; any failure is silent so the hook never blocks a prompt.
# ---------------------------------------------------------------------------
try:
    _case_tools = Path("/root/decker-system/04_tools")
    if _case_tools.exists():
        os.environ.setdefault("NEURO_TMP_DIR", str(_case_tools))
        os.environ.setdefault("NEURO_INBOX_FILE", str(_case_tools / "case_inbox.jsonl"))
        os.environ.setdefault("NEURO_TG_ACTIONED", str(_case_tools / "case_telegram_actioned.jsonl"))
        os.environ.setdefault("NEURO_EMAIL_ACTIONED", str(_case_tools / "case_email_actioned.jsonl"))
        if str(_case_tools) not in sys.path:
            sys.path.insert(0, str(_case_tools))
        import agent_comms as _ac  # type: ignore
        _tg = _ac.unactioned_telegram()
        if _tg:
            print(_ac.render_unactioned_telegram(_tg))
except Exception:
    pass


# ---------------------------------------------------------------------------
# 4. Self-register on peer broker (keeps registration alive across prompts)
# ---------------------------------------------------------------------------
try:
    _post(f"{PEER_URL}/peers/register", {
        "agent_id": AGENT_ID,
        "agent_type": "claude-code",
        "cwd": os.getcwd(),
        "summary": f"{AGENT_ID} agent",
    })
except Exception:
    pass

sys.exit(0)
