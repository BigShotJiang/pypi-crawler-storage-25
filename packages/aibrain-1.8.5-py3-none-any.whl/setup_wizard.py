#!/usr/bin/env python3
"""Deprecated shim — use aibrain.cli.setup_wizard instead."""
import warnings
warnings.warn(
    "setup_wizard.py at repo root is deprecated. Use aibrain.cli.setup_wizard.",
    DeprecationWarning, stacklevel=2
)
from aibrain.cli.setup_wizard import main, run_setup
__all__ = ["main", "run_setup"]

if __name__ == "__main__":
    import sys
    run_setup(sys.argv[1:]) if len(sys.argv) > 1 else main()
