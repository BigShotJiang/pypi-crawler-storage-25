#!/usr/bin/env python3
"""
AIBrain Installer — bootstraps everything including Python if needed.

This script can be run with ANY Python 3.8+ (system, pyenv, conda, etc.)
and it will set up a self-contained AIBrain environment.

Usage:
    python install.py              # Full install
    python install.py --check      # Check what's installed
    python install.py --portable   # Create portable bundle with embedded Python
"""

import json
import os
import platform
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

AIBRAIN_DIR = Path(__file__).parent.resolve()
VENV_DIR = AIBRAIN_DIR / ".venv"
NODE_MIN = "18.0.0"
PYTHON_MIN = (3, 8)

# Embeddable Python for portable mode (Windows)
PYTHON_EMBED_URL = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip"
PYTHON_EMBED_DIR = AIBRAIN_DIR / "runtime" / "python"

# NOTE: Keep in sync with requirements.txt if it exists. Update both when adding deps.
REQUIRED_PACKAGES = [
    "fastapi>=0.111.0",
    "uvicorn>=0.29.0",
    "feedparser>=6.0.0",
    "requests>=2.31.0",
    "beautifulsoup4>=4.12.0",
    "icalendar>=5.0.0",
    "python-dateutil>=2.9.0",
]

COLORS = {
    "reset": "\033[0m",
    "teal": "\033[38;2;0;245;212m",
    "bold": "\033[1m",
    "red": "\033[91m",
    "green": "\033[92m",
    "yellow": "\033[93m",
    "dim": "\033[90m",
}


def c(color, text):
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"


def banner():
    print(f"""
{c('teal', '    +==============================================+')}
{c('teal', '    |')}  {c('bold', 'AIBrain Installer')}                          {c('teal', '|')}
{c('teal', '    |')}  {c('dim', 'One-click agent operating system')}            {c('teal', '|')}
{c('teal', '    +==============================================+')}
""")


def check_python():
    v = sys.version_info
    ok = v >= PYTHON_MIN
    print(f"  Python {v.major}.{v.minor}.{v.micro} {'— OK' if ok else '— TOO OLD (need 3.8+)'}")
    return ok


def check_node():
    try:
        result = subprocess.run(["node", "--version"], capture_output=True, text=True, timeout=15)
        version = result.stdout.strip().lstrip("v")
        print(f"  Node.js {version} — OK")
        return True
    except FileNotFoundError:
        print(f"  Node.js — {c('red', 'NOT FOUND')}")
        return False
    except subprocess.TimeoutExpired:
        print(f"  Node.js — {c('red', 'TIMED OUT')}")
        return False


def check_npm():
    try:
        result = subprocess.run(["npm", "--version"], capture_output=True, text=True, timeout=15)
        print(f"  npm {result.stdout.strip()} — OK")
        return True
    except FileNotFoundError:
        print(f"  npm — {c('red', 'NOT FOUND')}")
        return False
    except subprocess.TimeoutExpired:
        print(f"  npm — {c('red', 'TIMED OUT')}")
        return False


def check_git():
    try:
        result = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=15)
        print(f"  git {result.stdout.strip().split()[-1]} — OK")
        return True
    except FileNotFoundError:
        print(f"  git — {c('yellow', 'NOT FOUND (optional)')}")
        return True  # git is optional
    except subprocess.TimeoutExpired:
        print(f"  git — {c('yellow', 'TIMED OUT (optional)')}")
        return True  # git is optional


def create_venv():
    """Create a virtual environment for AIBrain."""
    if VENV_DIR.exists():
        print(f"  Virtual environment exists at {VENV_DIR}")
        return True

    print(f"  Creating virtual environment...")
    try:
        subprocess.run([sys.executable, "-m", "venv", str(VENV_DIR)], check=True)
        print(f"  {c('green', 'Created')} at {VENV_DIR}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"  {c('red', f'Failed to create venv: {e}')}")
        return False


def get_pip():
    """Get the pip executable from the venv."""
    if platform.system() == "Windows":
        return str(VENV_DIR / "Scripts" / "pip.exe")
    return str(VENV_DIR / "bin" / "pip")


def get_python():
    """Get the Python executable from the venv."""
    if platform.system() == "Windows":
        return str(VENV_DIR / "Scripts" / "python.exe")
    return str(VENV_DIR / "bin" / "python")


def install_packages():
    """Install all required Python packages into the venv."""
    pip = get_pip()
    print(f"  Installing {len(REQUIRED_PACKAGES)} packages...")

    # Upgrade pip first — ignore failure (e.g. network unavailable), existing pip is fine
    try:
        subprocess.run([pip, "install", "--upgrade", "pip"], capture_output=True, timeout=120)
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    for pkg in REQUIRED_PACKAGES:
        name = pkg.split(">=")[0].split("==")[0]
        try:
            subprocess.run([pip, "install", pkg], capture_output=True, check=True, timeout=180)
            print(f"    {c('green', 'OK')} {name}")
        except FileNotFoundError:
            print(f"    {c('red', '✗')} pip not found — is the venv intact?")
            return False
        except subprocess.TimeoutExpired:
            print(f"    {c('yellow', '⚠')} {name} — timed out (network issue?)")
        except subprocess.CalledProcessError:
            print(f"    {c('yellow', '⚠')} {name} — install failed (non-critical)")

    return True


def install_frontend():
    """Install frontend Node.js dependencies."""
    frontend = AIBRAIN_DIR / "frontend"
    if not frontend.exists():
        print(f"  {c('yellow', 'No frontend directory found')}")
        return True

    node_modules = frontend / "node_modules"
    if node_modules.exists():
        print(f"  Frontend dependencies already installed")
        return True

    print(f"  Installing frontend dependencies...")
    try:
        subprocess.run(
            ["npm", "install"],
            cwd=str(frontend),
            capture_output=True,
            check=True,
            timeout=300,
        )
        print(f"  {c('green', 'Frontend dependencies installed')}")
        return True
    except subprocess.TimeoutExpired:
        print(f"  {c('red', 'npm install timed out (network issue?)')}")
        return False
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"  {c('red', f'npm install failed: {e}')}")
        return False


def _migrate_existing_databases(target_db: Path):
    """Scan for any existing SQLite databases that contain memory/brain tables
    and migrate the best one into aibrain.db.

    Handles: agentos.db, brain.db, memory.db, agent.db, or any *.db file
    with a 'memories' table. This makes AIBrain a drop-in replacement for
    any prior agent memory system.
    """
    import shutil

    if target_db.exists() and target_db.stat().st_size > 100_000:
        return  # Already have a substantial DB, don't overwrite

    # Known legacy names (checked first, in priority order)
    legacy_names = ["agentos.db", "brain.db", "memory.db", "agent.db"]
    search_dirs = [
        target_db.parent,                          # Same directory
        Path.home() / "agentos",                   # Legacy AgentOS location
        Path.home() / "projects" / "agentos",      # Dev layout
        Path.home(),                               # Home directory
    ]

    best_db = None
    best_size = target_db.stat().st_size if target_db.exists() else 0

    # Phase 1: Check known legacy names in known locations
    for search_dir in search_dirs:
        for name in legacy_names:
            candidate = search_dir / name
            if candidate.exists() and candidate != target_db:
                if _is_memory_db(candidate) and candidate.stat().st_size > best_size:
                    best_db = candidate
                    best_size = candidate.stat().st_size

    # Phase 2: Scan install directory for ANY .db file with memories table
    if not best_db:
        for candidate in target_db.parent.glob("*.db"):
            if candidate == target_db or candidate.name.startswith("."):
                continue
            if _is_memory_db(candidate) and candidate.stat().st_size > best_size:
                best_db = candidate
                best_size = candidate.stat().st_size

    if best_db:
        print(f"  Found existing brain database: {best_db.name} ({best_size // 1024}KB)")
        print(f"  Migrating to aibrain.db...")
        shutil.copy2(str(best_db), str(target_db))
        for suffix in ["-shm", "-wal"]:
            wal = best_db.parent / (best_db.name + suffix)
            if wal.exists():
                shutil.copy2(str(wal), str(target_db.parent / (target_db.name + suffix)))
        # Backup the old file (don't delete — user might want it)
        try:
            backup = best_db.parent / f"{best_db.name}.migrated"
            best_db.rename(backup)
            print(f"  {c('green', 'Migrated')} — old DB backed up as {backup.name}")
        except OSError:
            print(f"  {c('green', 'Migrated')} — old DB still at {best_db.name} (in use, will clean up later)")


def _is_memory_db(path: Path) -> bool:
    """Check if a SQLite file contains a 'memories' table (our schema marker)."""
    import sqlite3
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='memories'"
        )
        has_table = cursor.fetchone() is not None
        conn.close()
        return has_table
    except Exception:
        return False


def init_database():
    """Initialize the AIBrain database using the canonical schema from aibrain_db.py.
    Also handles migration from any existing SQLite memory database."""
    db_path = AIBRAIN_DIR / "aibrain.db"

    # Scan for ANY existing SQLite database that looks like a memory/brain DB
    # This catches: agentos.db, brain.db, memory.db, agent.db, or any custom name
    _migrate_existing_databases(db_path)

    if db_path.exists():
        print(f"  AIBrain database exists at {db_path}")
        return True

    print(f"  Creating AIBrain database...")
    # Use aibrain_db module for canonical schema if available, else minimal bootstrap
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("aibrain_db", str(AIBRAIN_DIR / "aibrain_db.py"))
        if spec is None:
            raise ImportError("aibrain_db.py not found or not importable")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        mod.get_db()  # This triggers _init_schema with full canonical schema
        print(f"  {c('green', 'Created')} at {db_path} (full schema via aibrain_db.py)")
    except Exception as e:
        # Fallback: minimal schema so the system can at least start
        import sqlite3
        db = sqlite3.connect(str(db_path))
        db.execute("""CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        )""")
        db.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
            USING fts5(name, tags, content, content=memories, content_rowid=id)""")
        # FTS sync triggers — MUST mirror canonical _init_schema() in aibrain_db.py.
        # Without these the FTS index stays empty and memory search silently returns
        # no results. Contentless-FTS with content=memories REQUIRES manual sync via
        # triggers (or rebuild); the FTS5 engine does not auto-populate from the
        # content table.
        db.executescript("""
            CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
                INSERT INTO memories_fts(rowid, name, tags, content)
                VALUES (new.id, new.name, new.tags, new.content);
            END;
            CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
                INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
                VALUES('delete', old.id, old.name, old.tags, old.content);
            END;
            CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
                INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
                VALUES('delete', old.id, old.name, old.tags, old.content);
                INSERT INTO memories_fts(rowid, name, tags, content)
                VALUES (new.id, new.name, new.tags, new.content);
            END;
        """)
        db.commit()
        db.close()
        print(f"  {c('green', 'Created')} at {db_path} (minimal schema, aibrain_db import failed: {e})")
    return True


def download_portable_python():
    """Download embeddable Python for portable distribution (Windows only)."""
    if platform.system() != "Windows":
        print(f"  Portable Python only supported on Windows (use system Python on Linux/Mac)")
        return False

    if PYTHON_EMBED_DIR.exists():
        print(f"  Portable Python already downloaded")
        return True

    print(f"  Downloading embeddable Python 3.11...")
    PYTHON_EMBED_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = PYTHON_EMBED_DIR / "python-embed.zip"

    try:
        # urlretrieve has no built-in timeout; wrap with socket-level timeout
        import socket
        with socket.setdefaulttimeout(120):
            urllib.request.urlretrieve(PYTHON_EMBED_URL, str(zip_path))
        with zipfile.ZipFile(str(zip_path), "r") as z:
            z.extractall(str(PYTHON_EMBED_DIR))
        zip_path.unlink()
        print(f"  {c('green', 'Downloaded')} to {PYTHON_EMBED_DIR}")

        # Enable pip in embedded Python
        pth_file = list(PYTHON_EMBED_DIR.glob("python*._pth"))
        if pth_file:
            content = pth_file[0].read_text(encoding="utf-8")
            content = content.replace("#import site", "import site")
            pth_file[0].write_text(content, encoding="utf-8")

        # Download get-pip.py
        print(f"  Installing pip into portable Python...")
        getpip = PYTHON_EMBED_DIR / "get-pip.py"
        with socket.setdefaulttimeout(60):
            urllib.request.urlretrieve("https://bootstrap.pypa.io/get-pip.py", str(getpip))
        py_exe = PYTHON_EMBED_DIR / "python.exe"
        subprocess.run([str(py_exe), str(getpip)], capture_output=True, timeout=120)
        getpip.unlink()
        print(f"  {c('green', 'pip installed')}")

        return True
    except Exception as e:
        print(f"  {c('red', f'Download failed: {e}')}")
        return False


def generate_launch_scripts():
    """Create platform-specific launch scripts."""
    # Windows batch file
    bat = AIBRAIN_DIR / "start.bat"
    if not bat.exists():
        bat.write_text(
            "@echo off\n"
            "echo Starting AIBrain...\n"
            "cd /d \"%~dp0\"\n"
            "if exist .venv\\Scripts\\python.exe (\n"
            "    set PYTHON=.venv\\Scripts\\python.exe\n"
            ") else if exist runtime\\python\\python.exe (\n"
            "    set PYTHON=runtime\\python\\python.exe\n"
            ") else (\n"
            "    set PYTHON=python\n"
            ")\n"
            "start \"AIBrain Backend\" %PYTHON% -m uvicorn backend.main:app --host 0.0.0.0 --port 8001\n"
            "timeout /t 2 >nul\n"
            "if exist frontend\\node_modules (\n"
            "    cd frontend\n"
            "    start \"AIBrain Frontend\" npm run dev\n"
            "    cd ..\n"
            ")\n"
            "echo.\n"
            "echo AIBrain is running!\n"
            "echo   Backend:  http://localhost:8001\n"
            "echo   Frontend: http://localhost:5173\n"
            "echo.\n"
            "echo Press Ctrl+C to stop.\n"
            "pause\n",
            encoding="utf-8",
        )
        print(f"  {c('green', 'Created')} start.bat")

    # Unix shell script
    sh = AIBRAIN_DIR / "start.sh"
    if not sh.exists():
        sh.write_text(
            "#!/bin/bash\n"
            'echo "Starting AIBrain..."\n'
            'cd "$(dirname "$0")"\n'
            "\n"
            "if [ -f .venv/bin/python ]; then\n"
            "    PYTHON=.venv/bin/python\n"
            "else\n"
            "    PYTHON=python3\n"
            "fi\n"
            "\n"
            "$PYTHON -m uvicorn backend.main:app --host 0.0.0.0 --port 8001 &\n"
            "BACKEND_PID=$!\n"
            "\n"
            "if [ -d frontend/node_modules ]; then\n"
            "    cd frontend && npm run dev &\n"
            "    FRONTEND_PID=$!\n"
            "    cd ..\n"
            "fi\n"
            "\n"
            'echo ""\n'
            'echo "AIBrain is running!"\n'
            'echo "  Backend:  http://localhost:8001"\n'
            'echo "  Frontend: http://localhost:5173"\n'
            'echo ""\n'
            'echo "Press Ctrl+C to stop."\n'
            "\n"
            'trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null" EXIT\n'
            "wait\n",
            encoding="utf-8",
        )
        os.chmod(str(sh), 0o755)
        print(f"  {c('green', 'Created')} start.sh")

    return True


def run_check():
    """Check mode — just report what's installed."""
    banner()
    print(f"{c('bold', 'System Check:')}")
    check_python()
    check_node()
    check_npm()
    check_git()

    print(f"\n{c('bold', 'AIBrain Components:')}")
    workflows_dir = AIBRAIN_DIR / "workflows"
    workflow_count = len(list(workflows_dir.glob("*.py"))) if workflows_dir.exists() else 0
    print(f"  Backend:    {'EXISTS' if (AIBRAIN_DIR / 'backend').exists() else 'MISSING'}")
    print(f"  Frontend:   {'EXISTS' if (AIBRAIN_DIR / 'frontend').exists() else 'MISSING'}")
    print(f"  Workflows:  {workflow_count} scripts")
    print(f"  AIBrain DB: {'EXISTS' if (AIBRAIN_DIR / 'aibrain.db').exists() else 'NOT INITIALIZED'}")
    print(f"  Venv:       {'EXISTS' if VENV_DIR.exists() else 'NOT CREATED'}")
    print(f"  Config:     {'EXISTS' if (AIBRAIN_DIR / 'config.json').exists() else 'USING DEFAULTS'}")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="AIBrain Installer")
    parser.add_argument("--check", action="store_true", help="Check installation status")
    parser.add_argument("--portable", action="store_true", help="Create portable bundle with embedded Python")
    args = parser.parse_args()

    if args.check:
        run_check()
        return

    banner()

    # Step 1: Check prerequisites
    print(f"{c('teal', '[1/8]')} {c('bold', 'Checking prerequisites')}")
    py_ok = check_python()
    node_ok = check_node()
    npm_ok = check_npm()
    check_git()

    if not py_ok:
        print(f"\n  {c('red', 'Python 3.8+ required.')} Install from https://python.org")
        sys.exit(1)

    # Step 2: Create virtual environment
    print(f"\n{c('teal', '[2/8]')} {c('bold', 'Setting up Python environment')}")
    if args.portable:
        download_portable_python()
    else:
        create_venv()
        install_packages()

    # Step 3: Frontend
    print(f"\n{c('teal', '[3/8]')} {c('bold', 'Setting up frontend')}")
    if node_ok and npm_ok:
        install_frontend()
    else:
        print(f"  {c('yellow', 'Skipping frontend (Node.js not found)')}")
        print(f"  Install Node.js 18+ from https://nodejs.org for the GUI")

    # Step 4: Database
    print(f"\n{c('teal', '[4/8]')} {c('bold', 'Initializing database')}")
    init_database()

    # Step 5: Launch scripts
    print(f"\n{c('teal', '[5/8]')} {c('bold', 'Creating launch scripts')}")
    generate_launch_scripts()

    # Step 6: Config + Auto-setup
    print(f"\n{c('teal', '[6/8]')} {c('bold', 'Configuration')}")
    config_path = AIBRAIN_DIR / "config.json"
    if config_path.exists():
        print(f"  config.json exists — keeping current settings")
    else:
        # Run auto-setup (discovers env vars, creates config, no prompts)
        py = get_python() if VENV_DIR.exists() else sys.executable
        setup_wizard = AIBRAIN_DIR / "setup_wizard.py"
        if setup_wizard.exists():
            print(f"  Running auto-setup...")
            try:
                result = subprocess.run(
                    [py, str(setup_wizard), "--auto"],
                    cwd=str(AIBRAIN_DIR),
                    timeout=60,
                )
                if result.returncode != 0:
                    print(f"  {c('yellow', 'Auto-setup exited non-zero — using defaults')}")
            except subprocess.TimeoutExpired:
                print(f"  {c('yellow', 'Auto-setup timed out — using defaults')}")
            except Exception as e:
                print(f"  {c('yellow', f'Auto-setup failed ({e}) — using defaults')}")
        else:
            example = AIBRAIN_DIR / "config.json.example"
            if example.exists():
                shutil.copy(str(example), str(config_path))
                print(f"  Created config.json from template")
            else:
                config_path.write_text(
                    json.dumps({
                        "agent_name": "Agent",
                        "email_to": "",
                        "location_name": "Your City",
                        "location_lat": 0,
                        "location_lon": 0,
                    }, indent=2),
                    encoding="utf-8",
                )
                print(f"  Created default config.json")

    # Step 7: Auto-config free-tier workflows
    print(f"\n{c('teal', '[7/8]')} {c('bold', 'Enabling free-tier workflows')}")
    try:
        sys.path.insert(0, str(AIBRAIN_DIR))
        from aibrain_update import auto_config_free_tier
        enabled, added = auto_config_free_tier()
        if enabled or added:
            print(f"  {c('green', 'Configured')}: {enabled} enabled, {added} added")
        else:
            print(f"  All free-tier workflows already configured")
    except Exception as e:
        print(f"  {c('yellow', f'Skipped: {e}')}")

    # Step 8: Brain pack selection
    print(f"\n{c('teal', '[8/8]')} {c('bold', 'Brain Packs')}")
    packs_path = AIBRAIN_DIR / "brain_packs.json"
    if packs_path.exists():
        packs_data = json.loads(packs_path.read_text(encoding="utf-8"))
        packs = packs_data.get("packs", {})
        print(f"  {len(packs)} brain packs available:")
        for key, pack in packs.items():
            tier = "" if pack.get("tier") == "free" else " [Pro]"
            print(f"    {key:20s} {pack['name']}{tier} — {pack['tagline']}")
        print()

        # Interactive pack selection (skip if --auto or non-interactive)
        if sys.stdin.isatty() and "--auto" not in sys.argv:
            print(f"  Pick a pack to specialise your brain (or press Enter to skip):")
            try:
                choice = input(f"  Pack name: ").strip().lower()
                if choice and choice in packs:
                    py = get_python() if VENV_DIR.exists() else sys.executable
                    try:
                        subprocess.run(
                            [py, "-m", "aibrain", "packs", "activate", choice],
                            cwd=str(AIBRAIN_DIR), timeout=30,
                        )
                    except subprocess.TimeoutExpired:
                        print(f"  {c('yellow', 'Pack activation timed out — run manually: aibrain packs activate ' + choice)}")
                elif choice:
                    print(f"  Unknown pack '{choice}' — skipping. Activate later with: aibrain packs activate <name>")
                else:
                    print(f"  Skipped. Activate anytime with: aibrain packs activate <name>")
            except (EOFError, KeyboardInterrupt):
                print(f"\n  Skipped.")
        else:
            print(f"  Activate a pack: aibrain packs activate <name>")

    # Save initial stack snapshot
    stack_script = AIBRAIN_DIR / "stack_snapshot.py"
    if stack_script.exists():
        py = get_python() if VENV_DIR.exists() else sys.executable
        try:
            subprocess.run(
                [py, str(stack_script), "save", "initial"],
                cwd=str(AIBRAIN_DIR),
                capture_output=True,
                timeout=15,
            )
        except (subprocess.TimeoutExpired, Exception):
            pass  # Snapshot is non-critical; never crash the installer on it

    print(f"\n{'='*50}")
    print(f"{c('teal', '  AIBrain installed successfully!')}")
    print(f"")
    print(f"  Start your brain:")
    print(f"    {c('bold', 'aibrain start')}          — restore stack + launch services")
    print(f"    {c('bold', 'aibrain status')}         — see what's running")
    print(f"    {c('bold', 'aibrain packs')}          — browse brain packs")
    print(f"    {c('bold', 'aibrain packs activate')} — specialise your brain")
    print(f"")
    print(f"  Or launch manually:")
    print(f"    {c('dim', 'start.bat')} (Windows) / {c('dim', './start.sh')} (Linux/Mac)")
    print()


if __name__ == "__main__":
    main()
