"""
aibrain_licensing.py — License key validation and tier enforcement.

Tiers:
    free        — 1 agent, 40 generic workflows, basic memory, community brains
    pro         — 3 agents, 155 workflows, skill learning, marketplace access ($9.95/mo); pro adds FleetBus inter-agent comms
    team        — 10 agents, full mesh merge, team brains ($29/mo)
    enterprise  — Unlimited agents, swarm training, priority support ($99/mo)

License keys are signed tokens: TIER-PAYLOAD-SIGNATURE
    - Offline validation (no phone-home for basic checks)
    - Optional online validation for feature unlocks and usage metering

Usage:
    from aibrain_licensing import check_tier, require_tier, get_license

    # Check current tier
    tier = get_license().tier  # "free", "pro", "team", "enterprise"

    # Gate a feature
    if check_tier("pro"):
        run_skill_workflows()

    # Decorator for functions
    @require_tier("team")
    def mesh_merge():
        ...
"""

import base64
import hashlib
import hmac
import json
import logging
import os
import socket
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Dict, Optional

log = logging.getLogger("aibrain.licensing")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TIER_ORDER = {"free": 0, "pro": 1, "team": 2, "enterprise": 3}

TIER_LIMITS = {
    "free": {
        "max_agents": 1,
        "max_workflows": 10,
        "workflow_sources": ["generic"],
        "skill_learning": False,
        "marketplace_access": False,
        "mesh_merge": False,
        "swarm_training": False,
        "brain_export": True,
        "brain_import": True,    # community brains only
        "max_memories": 500,
        "max_entities": 500,
        "max_experiments_per_week": 1,
        "max_satellite_dbs": 3,
        "embedding_models": ["minilm"],
        "fleet_bus": False,
    },
    "pro": {
        "max_agents": 3,
        "max_workflows": 200,
        "workflow_sources": ["generic", "skill_pro", "user_pro", "content_pro", "ops_pro"],
        "skill_learning": True,
        "marketplace_access": True,
        "mesh_merge": False,     # pair merge only (2 agents)
        "swarm_training": False,
        "brain_export": True,
        "brain_import": True,
        "max_memories": 50000,
        "max_entities": None,    # unlimited
        "max_experiments_per_week": None,
        "max_satellite_dbs": None,
        "embedding_models": ["minilm", "bge-base"],
        "fleet_bus": True,
    },
    "team": {
        "max_agents": 10,
        "max_workflows": 200,
        "workflow_sources": ["generic", "skill_pro", "user_pro", "content_pro", "ops_pro"],
        "skill_learning": True,
        "marketplace_access": True,
        "mesh_merge": True,
        "swarm_training": False,
        "brain_export": True,
        "brain_import": True,
        "max_memories": 200000,
        "max_entities": None,
        "max_experiments_per_week": None,
        "max_satellite_dbs": None,
        "embedding_models": ["minilm", "bge-base"],
        "fleet_bus": True,
    },
    "enterprise": {
        "max_agents": 999999,
        "max_workflows": 200,
        "workflow_sources": ["generic", "skill_pro", "user_pro", "content_pro", "ops_pro"],
        "skill_learning": True,
        "marketplace_access": True,
        "mesh_merge": True,
        "swarm_training": True,
        "brain_export": True,
        "brain_import": True,
        "max_memories": 999999,
        "max_entities": None,
        "max_experiments_per_week": None,
        "max_satellite_dbs": None,
        "embedding_models": ["minilm", "bge-base", "custom"],
        "fleet_bus": True,
    },
}

# Resource name → TIER_LIMITS key mapping
_RESOURCE_LIMIT_KEYS = {
    "memories": "max_memories",
    "entities": "max_entities",
    "experiments_per_week": "max_experiments_per_week",
    "satellite_dbs": "max_satellite_dbs",
    "active_workflows": "max_workflows",
    "agents": "max_agents",
}

TIER_PRICES = {
    "free": 0,
    "pro": 9.95,
    "team": 29.95,
    "enterprise": 99.00,
}

# ---------------------------------------------------------------------------
# F-18: AIBRAIN_SIGNING_KEY relocation (SA-2026-002 TM-02)
#
# Priority chain for loading the HMAC root-of-trust:
#   1. ~/.aibrain/keys/signing_key.bin  (mode 0600, F-18 canonical location)
#   2. AIBRAIN_SIGNING_KEY env var        (process environment)
#   3. ~/.decker_env                      (legacy, read-only — co-located with
#                                          provider keys; TM-02 finding)
#
# Auto-migrate on first run: if the key is found in a legacy source (env var
# or ~/.decker_env) but NOT at the canonical location, the key is written to
# ~/.aibrain/keys/signing_key.bin (mode 0600, dir mode 0700). A one-time
# stdout notice is emitted. The legacy source is LEFT UNCHANGED for one
# release cycle (v1.5.40 will add a deprecation warning on legacy load).
# Re-runs after migration are silent (idempotent).
# ---------------------------------------------------------------------------

_SIGNING_KEY_PATH = Path.home() / ".aibrain" / "keys" / "signing_key.bin"


def _read_legacy_decker_env() -> Optional[str]:
    """Read AIBRAIN_SIGNING_KEY from ~/.decker_env (legacy, read-only)."""
    decker_env = Path.home() / ".decker_env"
    if not decker_env.exists():
        return None
    try:
        for line in decker_env.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("export ") or line.startswith("set "):
                line = line.split(" ", 1)[1] if " " in line else line
            if line.startswith("AIBRAIN_SIGNING_KEY="):
                value = line.split("=", 1)[1].strip().strip('"').strip("'")
                if value:
                    return value
    except Exception:
        pass
    return None


def _load_signing_key() -> bytes:
    """Load the AIBRAIN_SIGNING_KEY from the priority chain.
    
    Auto-migrates from legacy sources to canonical location on first run.
    Raises RuntimeError if no key is found in any source.
    """
    # 1. Canonical location (F-18)
    if _SIGNING_KEY_PATH.exists():
        return _SIGNING_KEY_PATH.read_bytes().strip()

    # 2. Environment variable
    env_key = os.environ.get("AIBRAIN_SIGNING_KEY", "").strip()
    
    # 3. Legacy ~/.decker_env
    legacy_key = _read_legacy_decker_env() if not env_key else None

    # Determine which source provided the key
    key_bytes = None
    source = None
    if env_key:
        key_bytes = env_key.encode()
        source = "AIBRAIN_SIGNING_KEY environment variable"
    elif legacy_key:
        key_bytes = legacy_key.encode()
        source = "~/.decker_env"
    
    if not key_bytes:
        raise RuntimeError(
            "AIBRAIN_SIGNING_KEY is required but not found in any source.\n"
            "Checked: ~/.aibrain/keys/signing_key.bin, "
            "AIBRAIN_SIGNING_KEY env var, ~/.decker_env\n"
            "Set it to a long random secret (see docs/licensing.md)."
        )

    # F-18 auto-migrate: write to canonical location
    try:
        _SIGNING_KEY_PATH.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        _SIGNING_KEY_PATH.write_bytes(key_bytes)
        # chmod 0600 on the key file
        try:
            os.chmod(_SIGNING_KEY_PATH, 0o600)
        except Exception:
            pass  # Windows may not support os.chmod; mode set by parent dir
        # One-time notice
        print(
            f"[aibrain] AIBRAIN_SIGNING_KEY migrated to "
            f"~/.aibrain/keys/signing_key.bin (from {source}).\n"
            f"[aibrain] The legacy source has NOT been modified — you may "
            f"remove the key from {source} manually for full TM-02 compliance."
        )
    except Exception as exc:
        log.warning("F-18 auto-migrate failed (non-fatal, using legacy source): %s", exc)

    return key_bytes


_SIGNING_KEY = _load_signing_key()


# ---------------------------------------------------------------------------
# License data
# ---------------------------------------------------------------------------

@dataclass
class License:
    """Represents a validated license."""
    tier: str = "free"
    key: str = ""
    email: str = ""
    expires_at: str = ""    # ISO timestamp, "" = never (free tier)
    max_agents: int = 1
    stripe_customer_id: str = ""
    stripe_subscription_id: str = ""
    valid: bool = True
    reason: str = ""

    @property
    def is_expired(self) -> bool:
        if not self.expires_at:
            return False
        try:
            exp = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
            return datetime.now(timezone.utc) > exp
        except (ValueError, TypeError):
            return False

    @property
    def limits(self) -> dict:
        return TIER_LIMITS.get(self.tier, TIER_LIMITS["free"])


# ---------------------------------------------------------------------------
# Activation telemetry — silent, privacy-preserving, never blocks
# ---------------------------------------------------------------------------

# Default: placeholder URL (not live yet); overridden via env var.
_LICENSE_API_URL = os.environ.get(
    "AIBRAIN_LICENSE_API_URL",
    "https://api.myaibrain.org",
).rstrip("/")

# Heartbeat sentinel file — one POST per 24h per machine
_HEARTBEAT_SENT_PATH = Path.home() / ".aibrain" / ".heartbeat_sent"
_HEARTBEAT_WINDOW_SECONDS = 86400  # 24h


def _key_hash(raw_key: str) -> str:
    """SHA-256 of the raw license key — raw key never leaves this machine."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _machine_fingerprint_hash() -> str:
    """Salted hash of (hostname + first MAC address + OS name).

    No raw PII is returned or stored. The salt makes the hash non-reversible
    and non-correlatable across different aibrain instances.
    """
    import platform
    import uuid as _uuid

    hostname = socket.gethostname()
    try:
        mac = hex(_uuid.getnode())
    except Exception:
        mac = "unknown"
    os_name = platform.system()

    # Salt: AIBRAIN_FINGERPRINT_SALT env var or a stable per-machine default.
    # We use the hostname itself as fallback salt (adds per-machine uniqueness
    # without requiring a separate secret).
    salt = os.environ.get("AIBRAIN_FINGERPRINT_SALT", hostname)
    raw = f"{salt}:{hostname}:{mac}:{os_name}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _post_json_silent(url: str, payload: dict) -> None:
    """POST JSON to url via HardenedSession (F-19). Never raises, never blocks license."""
    try:
        from aibrain.core.hardened_session import HardenedSession
        with HardenedSession(timeout=5) as session:
            session.add_trusted_host("api.myaibrain.org")
            session.post(url, json=payload)
            log.debug("telemetry POST %s → ok", url)
    except Exception as exc:
        log.debug("telemetry POST %s failed (non-fatal): %s", url, exc)


def _get_json_silent(url: str, timeout: int = 5) -> Optional[dict]:
    """GET JSON from url via HardenedSession (F-19). Returns None on any error — never raises."""
    try:
        from aibrain.core.hardened_session import HardenedSession
        with HardenedSession(timeout=timeout) as session:
            session.add_trusted_host("api.myaibrain.org")
            resp = session.get(url)
            if resp.status_code == 200:
                return resp.json()
            log.debug("GET %s → %s", url, resp.status_code)
            return None
    except Exception as exc:
        log.debug("GET %s failed (non-fatal): %s", url, exc)
        return None


def _check_server_license_state(key_hash: str) -> Optional[dict]:
    """Fetch server-side license state for key_hash.

    Returns dict with at minimum {"state": "VALID"|"INVALID", "grace_until": str|null}
    or None if the server is unreachable (fail-open).
    """
    url = f"{_LICENSE_API_URL}/api/license/status/{key_hash}"
    return _get_json_silent(url)


def _post_activation_silent(raw_key: str, email: str) -> None:
    """POST activation record to the license API. Silent failure."""
    url = f"{_LICENSE_API_URL}/api/license/activations"
    payload = {
        "key_hash": _key_hash(raw_key),
        "email": email or None,
        "machine_fingerprint_hash": _machine_fingerprint_hash(),
    }
    _post_json_silent(url, payload)


def _post_heartbeat_silent(raw_key: str) -> None:
    """POST a heartbeat at most once per 24h. Silent failure."""
    # Rate-limit: check mtime of sentinel file
    try:
        if _HEARTBEAT_SENT_PATH.exists():
            age = time.time() - _HEARTBEAT_SENT_PATH.stat().st_mtime
            if age < _HEARTBEAT_WINDOW_SECONDS:
                log.debug("heartbeat suppressed — sent %.0fh ago", age / 3600)
                return
    except Exception:
        pass  # Stat failure → proceed

    url = f"{_LICENSE_API_URL}/api/license/heartbeat"
    payload = {
        "key_hash": _key_hash(raw_key),
        "machine_fingerprint_hash": _machine_fingerprint_hash(),
    }
    _post_json_silent(url, payload)

    # Update sentinel mtime regardless of POST success — avoids hammering on
    # a temporarily-down endpoint every time validate_key() is called.
    try:
        _HEARTBEAT_SENT_PATH.parent.mkdir(parents=True, exist_ok=True)
        _HEARTBEAT_SENT_PATH.touch()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# License storage
# ---------------------------------------------------------------------------

def _license_path() -> Path:
    """Where the license key is stored locally — uses canonical resolver."""
    from aibrain_db import AIBRAIN_ROOT
    return AIBRAIN_ROOT / ".license"


def _load_stored_license() -> Optional[str]:
    """Load license key from disk."""
    path = _license_path()
    if path.exists():
        return path.read_text().strip()
    # Also check env var
    return os.environ.get("AIBRAIN_LICENSE_KEY", "")


def save_license(key: str):
    """Save a license key to disk and record activation telemetry (silent)."""
    path = _license_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(key)
    log.info("License key saved to %s", path)

    # Fire-and-forget activation telemetry — runs in a daemon thread so it
    # never delays the caller. Raw key is never sent; SHA-256 hash only.
    try:
        lic = validate_key(key)
        email = lic.email if lic.valid else ""
        _t = threading.Thread(
            target=_post_activation_silent,
            args=(key, email),
            daemon=True,
            name="aibrain-activation-telemetry",
        )
        _t.start()
    except Exception as _tel_exc:
        log.debug("save_license telemetry spawn failed (non-fatal): %s", _tel_exc)


def remove_license():
    """Remove stored license (downgrade to free)."""
    path = _license_path()
    if path.exists():
        path.unlink()
        log.info("License removed — downgraded to free tier")


# ---------------------------------------------------------------------------
# Key generation and validation
# ---------------------------------------------------------------------------

def generate_key(tier: str, email: str, expires_at: str = "",
                 stripe_customer_id: str = "", stripe_sub_id: str = "") -> str:
    """Generate a license key.

    Format: TIER-BASE64_PAYLOAD-HMAC_SIGNATURE

    This would normally only run server-side. Included here for the
    self-hosted / development case.
    """
    if tier not in TIER_ORDER:
        raise ValueError(f"Invalid tier: {tier}")

    payload = {
        "t": tier,
        "e": email,
        "x": expires_at,
        "sc": stripe_customer_id,
        "ss": stripe_sub_id,
        "ts": datetime.now(timezone.utc).isoformat(),
    }

    payload_b64 = base64.urlsafe_b64encode(
        json.dumps(payload, separators=(",", ":")).encode()
    ).decode().rstrip("=")

    sig = hmac.new(_SIGNING_KEY, payload_b64.encode(), hashlib.sha256).hexdigest()[:16]

    return f"{tier.upper()}-{payload_b64}-{sig}"


def validate_key(key: str) -> License:
    """Validate a license key offline.

    Returns a License object. Check .valid and .reason for status.
    """
    if not key:
        return License(tier="free", valid=True, reason="No key — free tier")

    parts = key.split("-", 2)
    if len(parts) != 3:
        return License(tier="free", valid=False, reason="Invalid key format")

    tier_label, payload_b64, sig = parts
    tier = tier_label.lower()

    if tier not in TIER_ORDER:
        return License(tier="free", valid=False, reason=f"Unknown tier: {tier}")

    # Verify signature
    expected_sig = hmac.new(
        _SIGNING_KEY, payload_b64.encode(), hashlib.sha256
    ).hexdigest()[:16]

    if not hmac.compare_digest(sig, expected_sig):
        return License(tier="free", valid=False, reason="Invalid signature")

    # Decode payload
    try:
        # Re-pad base64
        padded = payload_b64 + "=" * (4 - len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
    except (json.JSONDecodeError, Exception) as e:
        return License(tier="free", valid=False, reason=f"Corrupt payload: {e}")

    license = License(
        tier=tier,
        key=key,
        email=payload.get("e", ""),
        expires_at=payload.get("x", ""),
        max_agents=TIER_LIMITS[tier]["max_agents"],
        stripe_customer_id=payload.get("sc", ""),
        stripe_subscription_id=payload.get("ss", ""),
        valid=True,
    )

    # Check local expiry (token-embedded expires_at field)
    if license.is_expired:
        license.valid = False
        license.reason = f"License expired: {license.expires_at}"
        license.tier = "free"

    # ------------------------------------------------------------------
    # Server-side state check — authoritative for subscriptions.
    # Fail open: if the server is unreachable we never block the user.
    # ------------------------------------------------------------------
    if license.valid and key:
        kh = _key_hash(key)
        server_state = _check_server_license_state(kh)
        if server_state is not None:
            state = server_state.get("state", "VALID")
            grace_until_str = server_state.get("grace_until") or ""
            if state == "INVALID":
                # Check whether we are still inside the 3-day grace window
                in_grace = False
                if grace_until_str:
                    try:
                        grace_dt = datetime.fromisoformat(
                            grace_until_str.replace("Z", "+00:00")
                        )
                        in_grace = datetime.now(timezone.utc) <= grace_dt
                    except (ValueError, TypeError):
                        pass
                if not in_grace:
                    license.valid = False
                    license.reason = (
                        "Subscription expired — renew at myaibrain.org"
                    )
                    license.tier = "free"
        # Machine binding check via server response
        server_machine = server_state.get("machine_fingerprint") if server_state else None
        if license.valid and server_machine:
            current_fp = _machine_fingerprint_hash()
            if server_machine != current_fp:
                license.valid = False
                license.reason = (
                    "License bound to a different machine — "
                    "contact support at myaibrain.org to transfer"
                )
                license.tier = "free"

    # Heartbeat telemetry — only on successful validation, at most once/24h,
    # non-blocking daemon thread. Raw key is never sent; SHA-256 hash only.
    if license.valid and key:
        try:
            _t = threading.Thread(
                target=_post_heartbeat_silent,
                args=(key,),
                daemon=True,
                name="aibrain-heartbeat-telemetry",
            )
            _t.start()
        except Exception as _hb_exc:
            log.debug("validate_key heartbeat spawn failed (non-fatal): %s", _hb_exc)

    return license


# ---------------------------------------------------------------------------
# Cached license access
# ---------------------------------------------------------------------------

_cached_license: Optional[License] = None
_license_lock = threading.Lock()


def get_license() -> License:
    """Get the current license (cached after first call)."""
    global _cached_license
    with _license_lock:
        if _cached_license is not None:
            return _cached_license
        key = _load_stored_license()
        _cached_license = validate_key(key)
        return _cached_license


def reset_cache():
    """Reset cached license (e.g., after key change)."""
    global _cached_license
    with _license_lock:
        _cached_license = None


# ---------------------------------------------------------------------------
# Rolling short-lived key refresh (item 7 of stripe split-brain fix)
# ---------------------------------------------------------------------------
#
# Triggers (all 24h windows):
#   1. Dashboard open      — the UI calls /api/license/refresh directly
#   2. First CLI command   — `aibrain` CLI calls maybe_refresh_license()
#   3. Scheduled cron      — `aibrain_license_refresh` in scheduled_jobs.json
#
# The Worker endpoint talks to Stripe server-side, mints a new key with
# `valid_until = current_period_end + 24h`, and returns it. We cache the
# refresh timestamp in ~/.aibrain/license_cache.json to avoid thrashing.

_REFRESH_CACHE_PATH = Path.home() / ".aibrain" / "license_cache.json"
_REFRESH_WINDOW_SECONDS = 86400  # 24h — SaaS standard grace period
_REFRESH_ENDPOINT = os.environ.get(
    "AIBRAIN_LICENSE_REFRESH_URL",
    "https://myaibrain.org/api/license/refresh",
)


def _read_refresh_cache() -> Dict[str, str]:
    try:
        if _REFRESH_CACHE_PATH.exists():
            return json.loads(_REFRESH_CACHE_PATH.read_text())
    except Exception:
        pass
    return {}


def _write_refresh_cache(data: Dict[str, str]) -> None:
    try:
        _REFRESH_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        _REFRESH_CACHE_PATH.write_text(json.dumps(data))
    except Exception as e:
        log.warning("Failed to write license refresh cache: %s", e)


def maybe_refresh_license(force: bool = False) -> Optional[License]:
    """Refresh the license key if the 24h cache window has elapsed.

    Returns the new License on success, None if no refresh was needed
    or the refresh failed. Safe to call from CLI startup — logs and
    returns None on any error so callers never block.
    """
    try:
        import urllib.request
        import urllib.error

        current_key = _load_stored_license()
        if not current_key:
            return None  # No key to refresh — nothing to do.

        cache = _read_refresh_cache()
        last_refresh = cache.get("last_refresh", "")
        if not force and last_refresh:
            try:
                last_ts = datetime.fromisoformat(last_refresh.replace("Z", "+00:00"))
                age = (datetime.now(timezone.utc) - last_ts).total_seconds()
                if age < _REFRESH_WINDOW_SECONDS:
                    return None  # Within window — skip
            except Exception:
                pass  # Corrupt cache — proceed to refresh

        req = urllib.request.Request(
            _REFRESH_ENDPOINT,
            method="POST",
            headers={
                "Authorization": f"Bearer {current_key}",
                "Content-Type": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())

        new_key = data.get("license_key", "")
        if not new_key:
            log.warning("license refresh: endpoint returned no key")
            return None

        save_license(new_key)
        reset_cache()
        _write_refresh_cache({
            "last_refresh": datetime.now(timezone.utc).isoformat(),
            "valid_until": data.get("valid_until", ""),
            "tier": data.get("tier", ""),
        })
        log.info("License refreshed — tier=%s valid_until=%s",
                 data.get("tier"), data.get("valid_until"))
        return get_license()
    except Exception as e:
        log.warning("License refresh failed (non-fatal): %s", e)
        return None


# ---------------------------------------------------------------------------
# Tier checking
# ---------------------------------------------------------------------------

def check_tier(required: str) -> bool:
    """Check if current license meets the required tier."""
    license = get_license()
    if not license.valid:
        return required == "free"
    return TIER_ORDER.get(license.tier, 0) >= TIER_ORDER.get(required, 0)


def check_feature(feature: str) -> bool:
    """Check if a specific feature is available."""
    license = get_license()
    limits = license.limits
    return bool(limits.get(feature, False))


def check_agent_limit(current_count: int) -> bool:
    """Check if adding another agent would exceed the limit."""
    license = get_license()
    return current_count < license.limits["max_agents"]


def check_workflow_source(source: str) -> bool:
    """Check if a workflow source is available in current tier."""
    license = get_license()
    return source in license.limits["workflow_sources"]


def require_tier(tier: str):
    """Decorator to gate a function behind a tier requirement."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not check_tier(tier):
                current = get_license().tier
                raise PermissionError(
                    f"This feature requires aibrain {tier.title()} "
                    f"(current: {current}). "
                    f"Upgrade at https://myaibrain.org/pricing"
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator


def require_feature(feature: str):
    """Decorator to gate a function behind a feature flag."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not check_feature(feature):
                current = get_license().tier
                raise PermissionError(
                    f"Feature '{feature}' is not available on the {current} tier. "
                    f"Upgrade at https://myaibrain.org/pricing"
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Dev / owner install bypass
# ---------------------------------------------------------------------------

def _is_dev_install() -> bool:
    """Detect dev/owner installs that should bypass tier limits.

    A dev install is identified by ANY of:
      1. AIBRAIN_DEV=1 environment variable
      2. A .dev marker file in the aibrain root directory
      3. An active license with tier >= pro (paid users are unlimited
         within their tier — this is the normal path; listed here for
         clarity)

    This prevents the free-tier 500-memory cap from blocking the
    developer's own 18K+ memory install.
    """
    # Env var — simplest, works everywhere
    if os.environ.get("AIBRAIN_DEV", "").strip() == "1":
        return True

    # Marker file — survives env resets, easy to deploy
    root = Path(os.environ.get("AIBRAIN_ROOT",
                Path(__file__).parent))
    if (root / ".dev").exists():
        return True

    return False


# ---------------------------------------------------------------------------
# Resource counting and enforcement (merged from tier_limits.py)
# ---------------------------------------------------------------------------

class TierLimitExceeded(Exception):
    """Raised when a tier resource cap is hit."""
    def __init__(self, resource, current, limit):
        self.resource = resource
        self.current = current
        self.limit = limit
        super().__init__(
            f"Tier limit reached: {resource} ({current}/{limit}). "
            f"Upgrade at https://myaibrain.org/pricing"
        )


def _find_db():
    """Find the aibrain database."""
    root = Path(os.environ.get("AIBRAIN_ROOT",
                os.environ.get("AIBRAIN_ROOT",
                Path(__file__).parent)))
    for name in ["aibrain.db"]:
        p = root / name
        if p.exists():
            return str(p)
    return str(root / "aibrain.db")


def get_current_count(resource: str) -> int:
    """Get the current count for a resource from live DB/filesystem."""
    root = Path(os.environ.get("AIBRAIN_ROOT",
                os.environ.get("AIBRAIN_ROOT",
                Path(__file__).parent)))
    db_path = _find_db()
    try:
        db = sqlite3.connect(db_path)
        db.row_factory = sqlite3.Row
    except Exception:
        return 0

    try:
        if resource == "memories":
            row = db.execute("SELECT COUNT(*) as cnt FROM memories WHERE active = 1").fetchone()
            return row["cnt"] if row else 0

        elif resource == "entities":
            try:
                row = db.execute("SELECT COUNT(*) as cnt FROM entities").fetchone()
                return row["cnt"] if row else 0
            except sqlite3.OperationalError:
                return 0

        elif resource == "experiments_per_week":
            try:
                row = db.execute(
                    """SELECT COUNT(*) as cnt FROM evolution_experiments
                       WHERE started_at > datetime('now', '-7 days')"""
                ).fetchone()
                return row["cnt"] if row else 0
            except sqlite3.OperationalError:
                return 0

        elif resource == "satellite_dbs":
            try:
                row = db.execute("SELECT COUNT(*) as cnt FROM satellite_dbs WHERE active = 1").fetchone()
                return row["cnt"] if row else 0
            except sqlite3.OperationalError:
                return 0

        elif resource == "active_workflows":
            jobs_path = root / "scheduled_jobs.json"
            if jobs_path.exists():
                data = json.loads(jobs_path.read_text(encoding="utf-8"))
                jobs = data.get("jobs", data) if isinstance(data, dict) else data
                if isinstance(jobs, list):
                    return sum(1 for j in jobs if isinstance(j, dict) and j.get("enabled", True))
                elif isinstance(jobs, dict):
                    return sum(1 for j in jobs.values() if isinstance(j, dict) and j.get("enabled", True))
            return 0

        elif resource == "agents":
            try:
                row = db.execute(
                    """SELECT COUNT(DISTINCT json_extract(summary, '$.agent')) as cnt
                       FROM activity_log WHERE created_at > datetime('now', '-24 hours')"""
                ).fetchone()
                return max(1, row["cnt"] if row else 1)
            except (sqlite3.OperationalError, TypeError):
                return 1

        return 0
    finally:
        db.close()


def _get_resource_limit(resource: str) -> int | None:
    """Get the limit for a resource based on current tier."""
    lic = get_license()
    limits = lic.limits
    key = _RESOURCE_LIMIT_KEYS.get(resource, resource)
    return limits.get(key)


def can_create(resource: str) -> tuple[bool, int | None]:
    """Check if creating one more of resource is allowed.

    Returns: (allowed: bool, remaining: int or None)
    Dev/owner installs always return (True, None).
    """
    if _is_dev_install():
        return True, None  # dev/owner install — unlimited

    limit = _get_resource_limit(resource)
    if limit is None:
        return True, None  # unlimited

    current = get_current_count(resource)
    remaining = max(0, limit - current)
    return remaining > 0, remaining


def check_limit(resource: str):
    """Check limit and raise TierLimitExceeded if at cap.

    Call this before creating memories, entities, experiments, etc.
    Dev/owner installs bypass all limits (see _is_dev_install).
    """
    if _is_dev_install():
        return  # dev/owner install — no limits

    limit = _get_resource_limit(resource)
    if limit is None:
        return  # unlimited

    current = get_current_count(resource)
    if current >= limit:
        raise TierLimitExceeded(resource, current, limit)


def get_tier_status() -> dict:
    """Get a full status report of all tier resource limits."""
    lic = get_license()
    dev = _is_dev_install()
    status = {"tier": lic.tier, "dev_install": dev, "resources": {}}

    for resource in _RESOURCE_LIMIT_KEYS:
        limit = None if dev else _get_resource_limit(resource)
        current = get_current_count(resource)
        status["resources"][resource] = {
            "current": current,
            "limit": limit,
            "remaining": (limit - current) if limit else None,
            "at_cap": (current >= limit if limit else False) if not dev else False,
        }

    return status


# ---------------------------------------------------------------------------
# Upgrade prompt
# ---------------------------------------------------------------------------

def upgrade_message(required_tier: str) -> str:
    """Generate a user-friendly upgrade message."""
    current = get_license().tier
    price = TIER_PRICES.get(required_tier, 0)

    features = {
        "pro": [
            "155 workflows (40 free → 155)",
            "Up to 3 agents",
            "Skill learning from experience",
            "Brain marketplace access",
            "50,000 memory capacity",
        ],
        "team": [
            "Everything in Pro, plus:",
            "Up to 10 agents",
            "Full mesh merge (multi-agent intelligence)",
            "Team brain sharing",
            "200,000 memory capacity",
        ],
        "enterprise": [
            "Everything in Team, plus:",
            "Unlimited agents",
            "Swarm training (100+ agents)",
            "Custom embedding models",
            "Priority support",
        ],
    }

    lines = [
        f"\n  Upgrade to aibrain {required_tier.title()} — ${price:.2f}/month\n",
        f"  Current tier: {current.title()}\n",
    ]

    if required_tier in features:
        lines.append(f"  What you get:")
        for f in features[required_tier]:
            lines.append(f"    + {f}")

    lines.append(f"\n  Upgrade: https://myaibrain.org/pricing")
    lines.append(f"  Or: aibrain license activate <key>\n")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_license(args: list) -> int:
    """Handle `aibrain license <subcommand>` CLI."""
    if not args:
        # Show current license status
        lic = get_license()
        print(f"\n  aibrain License Status\n")
        print(f"  Tier: {lic.tier.title()}")
        print(f"  Valid: {'Yes' if lic.valid else 'No'}")
        if lic.email:
            print(f"  Email: {lic.email}")
        if lic.expires_at:
            exp_str = "EXPIRED" if lic.is_expired else lic.expires_at[:10]
            print(f"  Expires: {exp_str}")
        if lic.key:
            print(f"  Key: {lic.key[:20]}...")

        limits = lic.limits
        print(f"\n  Limits:")
        print(f"    Agents: {limits['max_agents']}")
        print(f"    Workflows: {limits['max_workflows']}")
        print(f"    Memories: {limits['max_memories']:,}")
        print(f"    Skill learning: {'Yes' if limits['skill_learning'] else 'No'}")
        print(f"    Marketplace: {'Yes' if limits['marketplace_access'] else 'No'}")
        print(f"    Mesh merge: {'Yes' if limits['mesh_merge'] else 'No'}")
        print(f"    Swarm training: {'Yes' if limits['swarm_training'] else 'No'}")
        print()
        return 0

    subcmd = args[0]

    if subcmd == "activate":
        if len(args) < 2:
            print("Usage: aibrain license activate <license_key>")
            return 1
        key = args[1]
        lic = validate_key(key)
        if lic.valid:
            save_license(key)
            reset_cache()
            print(f"  License activated: {lic.tier.title()}")
            print(f"  Email: {lic.email}")
            if lic.expires_at:
                print(f"  Expires: {lic.expires_at[:10]}")
        else:
            print(f"  Invalid license: {lic.reason}")
            return 1

    elif subcmd == "deactivate":
        remove_license()
        reset_cache()
        print("  License deactivated — downgraded to Free tier.")

    elif subcmd == "generate":
        # Dev/self-hosted key generation
        if len(args) < 3:
            print("Usage: aibrain license generate <tier> <email> [--expires YYYY-MM-DD]")
            return 1
        tier = args[1].lower()
        email = args[2]
        expires = ""
        if "--expires" in args:
            idx = args.index("--expires") + 1
            expires = args[idx] if idx < len(args) else ""

        key = generate_key(tier, email, expires)
        print(f"  Generated {tier.upper()} license key:")
        print(f"  {key}")
        print(f"\n  Activate with: aibrain license activate {key}")

    elif subcmd == "status":
        # Show server-side license state (days remaining, renewal URL)
        lic = get_license()
        if not lic.key:
            print("  No license key active — free tier.")
            return 0
        kh = _key_hash(lic.key)
        server_state = _check_server_license_state(kh)

        print(f"\n  aibrain License Status\n")
        print(f"  Tier:  {lic.tier.title()}")
        print(f"  Valid: {'Yes' if lic.valid else 'No'}")
        if lic.email:
            print(f"  Email: {lic.email}")

        if server_state:
            state = server_state.get("state", "VALID")
            valid_until = server_state.get("valid_until") or ""
            days_remaining = server_state.get("days_remaining")
            grace_period = server_state.get("grace_period", False)

            print(f"  Server state:   {state}")
            if valid_until:
                print(f"  Valid until:    {valid_until[:10]}")
            if days_remaining is not None:
                print(f"  Days remaining: {days_remaining}")
            if grace_period:
                print(f"  Grace period:   Yes (subscription lapsed, access continues briefly)")
            if state == "INVALID" and not grace_period:
                print(f"\n  Renew at: https://myaibrain.org/pricing")
        else:
            print(f"  (Server unreachable — local key used)")
            if lic.expires_at:
                exp_str = "EXPIRED" if lic.is_expired else lic.expires_at[:10]
                print(f"  Expires: {exp_str}")
        print()

    elif subcmd == "activations":
        # Show activation record for the current key (from local DB)
        lic = get_license()
        if not lic.key:
            print("  No license key active — free tier.")
            return 0
        kh = _key_hash(lic.key)
        db_path = _find_db()
        try:
            db = sqlite3.connect(db_path)
            db.row_factory = sqlite3.Row
            row = db.execute(
                "SELECT * FROM license_activations WHERE key_hash = ?", (kh,)
            ).fetchone()
            db.close()
        except Exception as exc:
            print(f"  Could not read activation DB: {exc}")
            return 1
        print(f"\n  aibrain License Activations\n")
        print(f"  Key hash:          {kh[:16]}...{kh[-8:]}")
        if row:
            print(f"  Email:             {row['email'] or '(not recorded)'}")
            print(f"  First seen:        {row['first_seen_at'] or '—'}")
            print(f"  Last seen:         {row['last_seen_at'] or '—'}")
            print(f"  Machines:          {row['machine_count']}")
            print(f"  Total validations: {row['total_validations']}")
        else:
            print("  No local activation record found.")
            print("  (Record is created when the server confirms activation.)")
        print()

    elif subcmd == "tiers":
        print("\n  aibrain Pricing Tiers\n")
        for tier, price in TIER_PRICES.items():
            limits = TIER_LIMITS[tier]
            price_str = "Free" if price == 0 else f"${price:.2f}/mo"
            print(f"  {tier.upper():12s} {price_str:>10s}")
            print(f"    Agents: {limits['max_agents']}")
            print(f"    Workflows: {limits['max_workflows']}")
            print(f"    Memories: {limits['max_memories']:,}")
            features = []
            if limits['skill_learning']:
                features.append("skill learning")
            if limits['marketplace_access']:
                features.append("marketplace")
            if limits['mesh_merge']:
                features.append("mesh merge")
            if limits['swarm_training']:
                features.append("swarm training")
            if features:
                print(f"    Features: {', '.join(features)}")
            print()

    else:
        print(f"Unknown subcommand: {subcmd}")
        print("Usage: aibrain license [activate|deactivate|generate|status|activations|tiers]")
        return 1

    return 0


if __name__ == "__main__":
    import sys
    sys.exit(cli_license(sys.argv[1:]))
