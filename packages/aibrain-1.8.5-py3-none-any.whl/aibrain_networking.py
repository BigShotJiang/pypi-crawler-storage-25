"""
AIBrain Networking — Tailscale mesh for agent-to-agent communication.

Handles Tailscale installation, authentication, and peer connectivity.
Pro tier feature — replaces the old fire-and-forget broker with persistent,
encrypted, NAT-traversing mesh networking.

Usage:
    from aibrain_networking import setup_tailscale, get_tailscale_ip, get_peers, is_tailscale_ready

    # During setup wizard
    setup_tailscale()

    # Runtime checks
    if is_tailscale_ready():
        ip = get_tailscale_ip()
        peers = get_peers()
"""

import json
import logging
import os
import platform
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.networking")

# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

def _find_tailscale_bin() -> Optional[str]:
    """Find the tailscale CLI binary."""
    # Check PATH first
    ts = shutil.which("tailscale")
    if ts:
        return ts

    # Platform-specific default locations
    if platform.system() == "Windows":
        candidates = [
            Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Tailscale" / "tailscale.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Tailscale" / "tailscale.exe",
        ]
    elif platform.system() == "Darwin":
        candidates = [
            Path("/usr/local/bin/tailscale"),
            Path("/opt/homebrew/bin/tailscale"),
            Path("/Applications/Tailscale.app/Contents/MacOS/Tailscale"),
        ]
    else:  # Linux
        candidates = [
            Path("/usr/bin/tailscale"),
            Path("/usr/local/bin/tailscale"),
            Path("/snap/bin/tailscale"),
        ]

    for c in candidates:
        if c.exists():
            return str(c)
    return None


def is_tailscale_installed() -> bool:
    """Check if Tailscale is installed."""
    return _find_tailscale_bin() is not None


def is_tailscale_ready() -> bool:
    """Check if Tailscale is installed, running, and connected to a tailnet."""
    ts = _find_tailscale_bin()
    if not ts:
        return False
    try:
        result = subprocess.run(
            [ts, "status", "--json"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return False
        status = json.loads(result.stdout)
        # BackendState "Running" means connected
        return status.get("BackendState") == "Running"
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Info
# ---------------------------------------------------------------------------

def get_tailscale_ip() -> Optional[str]:
    """Get this machine's Tailscale IP (100.x.x.x)."""
    ts = _find_tailscale_bin()
    if not ts:
        return None
    try:
        result = subprocess.run(
            [ts, "ip", "-4"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip().split("\n")[0]
    except Exception:
        pass
    return None


def get_tailscale_hostname() -> Optional[str]:
    """Get this machine's Tailscale MagicDNS hostname."""
    ts = _find_tailscale_bin()
    if not ts:
        return None
    try:
        result = subprocess.run(
            [ts, "status", "--json"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            status = json.loads(result.stdout)
            self_status = status.get("Self", {})
            dns_name = self_status.get("DNSName", "")
            # Remove trailing dot
            return dns_name.rstrip(".")
    except Exception:
        pass
    return None


def get_peers() -> list[dict]:
    """Get all Tailscale peers with their IPs and hostnames."""
    ts = _find_tailscale_bin()
    if not ts:
        return []
    try:
        result = subprocess.run(
            [ts, "status", "--json"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return []
        status = json.loads(result.stdout)
        peers = []
        for node_id, peer in status.get("Peer", {}).items():
            ips = peer.get("TailscaleIPs", [])
            peers.append({
                "hostname": peer.get("HostName", ""),
                "dns_name": peer.get("DNSName", "").rstrip("."),
                "ip": ips[0] if ips else "",
                "online": peer.get("Online", False),
                "os": peer.get("OS", ""),
                "last_seen": peer.get("LastSeen", ""),
            })
        return peers
    except Exception:
        return []


def get_status() -> dict:
    """Get full Tailscale status for dashboard display."""
    ts = _find_tailscale_bin()
    if not ts:
        return {"installed": False, "connected": False}

    try:
        result = subprocess.run(
            [ts, "status", "--json"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return {"installed": True, "connected": False, "error": result.stderr.strip()}

        status = json.loads(result.stdout)
        self_info = status.get("Self", {})
        ips = self_info.get("TailscaleIPs", [])

        return {
            "installed": True,
            "connected": status.get("BackendState") == "Running",
            "ip": ips[0] if ips else None,
            "hostname": self_info.get("HostName", ""),
            "dns_name": self_info.get("DNSName", "").rstrip("."),
            "tailnet": status.get("MagicDNSSuffix", ""),
            "peer_count": len(status.get("Peer", {})),
            "peers": get_peers(),
        }
    except Exception as e:
        return {"installed": True, "connected": False, "error": str(e)}


# ---------------------------------------------------------------------------
# Installation
# ---------------------------------------------------------------------------

def install_tailscale() -> bool:
    """Install Tailscale on the current platform.

    Returns True on success, False on failure.
    Does NOT require admin/root — uses user-space install where possible.
    """
    system = platform.system()

    if is_tailscale_installed():
        log.info("Tailscale already installed")
        return True

    try:
        if system == "Linux":
            # Official one-liner
            result = subprocess.run(
                ["sh", "-c", "curl -fsSL https://tailscale.com/install.sh | sh"],
                capture_output=True, text=True, timeout=120
            )
            return result.returncode == 0

        elif system == "Darwin":
            # Homebrew
            if shutil.which("brew"):
                result = subprocess.run(
                    ["brew", "install", "tailscale"],
                    capture_output=True, text=True, timeout=120
                )
                return result.returncode == 0
            log.warning("Install Tailscale from https://tailscale.com/download/mac")
            return False

        elif system == "Windows":
            # winget preferred, chocolatey fallback
            if shutil.which("winget"):
                result = subprocess.run(
                    ["winget", "install", "Tailscale.Tailscale", "--accept-package-agreements", "--accept-source-agreements"],
                    capture_output=True, text=True, timeout=120
                )
                if result.returncode == 0:
                    return True

            if shutil.which("choco"):
                result = subprocess.run(
                    ["choco", "install", "tailscale", "-y"],
                    capture_output=True, text=True, timeout=120
                )
                return result.returncode == 0

            log.warning("Install Tailscale from https://tailscale.com/download/windows")
            return False

        else:
            log.warning(f"Unsupported platform: {system}")
            return False

    except Exception as e:
        log.error(f"Tailscale install failed: {e}")
        return False


def authenticate_tailscale(auth_key: str = "") -> bool:
    """Authenticate with Tailscale.

    If auth_key is provided, uses it for headless auth.
    Otherwise opens browser for interactive login.
    """
    ts = _find_tailscale_bin()
    if not ts:
        return False

    cmd = [ts, "up"]
    if auth_key:
        cmd.extend(["--authkey", auth_key])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return result.returncode == 0
    except Exception as e:
        log.error(f"Tailscale auth failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Peer Discovery Integration
# ---------------------------------------------------------------------------

def configure_peer_discovery(peer_broker_port: int = 7800) -> dict:
    """Configure peer discovery to use Tailscale networking.

    Returns config dict to merge into config.json.
    """
    ip = get_tailscale_ip()
    hostname = get_tailscale_hostname()
    peers = get_peers()

    config = {
        "networking": {
            "transport": "tailscale",
            "tailscale_ip": ip,
            "tailscale_hostname": hostname,
            "peer_broker_port": peer_broker_port,
            "peer_broker_url": f"http://{ip}:{peer_broker_port}" if ip else None,
        },
        "distributed_mode": True,
    }

    # Auto-discover AIBrain peers on the tailnet
    if peers:
        config["networking"]["discovered_peers"] = [
            {
                "hostname": p["hostname"],
                "ip": p["ip"],
                "url": f"http://{p['ip']}:{peer_broker_port}",
                "online": p["online"],
            }
            for p in peers if p["online"]
        ]

    return config


def peer_url_for(peer_ip: str, port: int = 7800) -> str:
    """Build a peer discovery URL for a Tailscale peer."""
    return f"http://{peer_ip}:{port}"


# ---------------------------------------------------------------------------
# Setup flow (called from setup_wizard.py)
# ---------------------------------------------------------------------------

def setup_tailscale_interactive(print_fn=print, prompt_fn=input) -> dict:
    """Interactive Tailscale setup for the setup wizard.

    Returns config dict to merge into config.json, or empty dict if skipped.
    """
    result = {}

    if is_tailscale_installed():
        print_fn("  Tailscale is installed.")
        if is_tailscale_ready():
            ip = get_tailscale_ip()
            hostname = get_tailscale_hostname()
            peers = get_peers()
            online_peers = [p for p in peers if p["online"]]
            print_fn(f"  Connected: {ip} ({hostname})")
            print_fn(f"  Peers on tailnet: {len(online_peers)} online")
            result = configure_peer_discovery()
        else:
            print_fn("  Tailscale installed but not connected.")
            try:
                answer = prompt_fn("  Authenticate now? [Y/n]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                answer = "n"
            if answer != "n":
                auth_key = ""
                try:
                    key_input = prompt_fn("  Auth key (blank for browser login): ").strip()
                    if key_input:
                        auth_key = key_input
                except (EOFError, KeyboardInterrupt):
                    pass
                if authenticate_tailscale(auth_key):
                    print_fn("  Tailscale connected!")
                    result = configure_peer_discovery()
                else:
                    print_fn("  Auth failed — you can run 'tailscale up' manually later.")
    else:
        print_fn("  Tailscale not found.")
        try:
            answer = prompt_fn("  Install Tailscale for mesh networking? [Y/n]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "n"
        if answer != "n":
            print_fn("  Installing Tailscale...")
            if install_tailscale():
                print_fn("  Installed! Authenticating...")
                auth_key = ""
                try:
                    key_input = prompt_fn("  Auth key (blank for browser login): ").strip()
                    if key_input:
                        auth_key = key_input
                except (EOFError, KeyboardInterrupt):
                    pass
                if authenticate_tailscale(auth_key):
                    print_fn("  Tailscale connected!")
                    result = configure_peer_discovery()
                else:
                    print_fn("  Run 'tailscale up' manually to complete setup.")
            else:
                print_fn("  Auto-install failed. Install manually: https://tailscale.com/download")
        else:
            print_fn("  Skipped — agents will use local-only mode.")

    return result
