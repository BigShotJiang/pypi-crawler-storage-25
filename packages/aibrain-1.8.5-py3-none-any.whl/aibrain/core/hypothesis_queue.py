"""
hypothesis_queue.py — Karpathy-loop hypothesis injection layer.

Preserves Decker's creative abstract input in the loop without forcing him into
mechanical iteration. When the autoresearch engine plateaus (plateau_limit
consecutive non-improving iterations), it pulls the next queued hypothesis from
``research/<target>/hypothesis_queue.md``, marks it ``in_flight``, writes an
``action='hypothesis_pulled'`` row to ``evolution_outcomes``, and emits a
Telegram alert. A separate CLI (``aibrain autoresearch hypothesize <target>``)
then synthesizes the abstract hypothesis into a concrete variant file, and the
approval flow (manual ``/approve`` or ``auto_approved_timeout``) determines
whether the draft enters the loop on the next iteration.

---------------------------------------------------------------------------
Queue file format — ``research/<target>/hypothesis_queue.md``
---------------------------------------------------------------------------

The queue is plain Markdown, parsed structurally. The engine never rewrites
user-authored content; it only appends new entries and flips the ``status``
line via status-only edits. Each hypothesis is one `## Hypothesis:` section:

    ## Hypothesis: <1-liner title>

    status: queued|in_flight|consumed_as_<variant_id>|rejected
    added_by: decker|neuro|agent_<id>
    added_at: 2026-04-19T14:03:00
    consumed_at: (empty until engine pulls it)

    <body — prose: what to try, why it might matter, prior art, cross-refs>

    ---

- Order matters: engine pulls the FIRST entry where ``status=queued``.
- Body is free-form Markdown — Decker can drop a 1-liner abstract ("what if we
  collapsed the 11 modes into 3 clusters?") or a multi-paragraph essay. Neuro
  synthesis reads this verbatim.
- The ``---`` separator between entries is load-bearing for the parser.

---------------------------------------------------------------------------
Plateau hook contract
---------------------------------------------------------------------------

``on_plateau(target, research_root, db_path, telegram_sender)`` — called by the
engine when plateau_limit fires. Returns one of:

- ``{"action": "hypothesis_pulled", "hypothesis": {...}}`` — queue had a queued
  entry; status flipped to ``in_flight``, evolution_outcomes row written,
  Telegram fired. Engine enters DORMANT_AWAITING_SYNTHESIS state.
- ``{"action": "queue_empty"}`` — no queued entries; Telegram fired asking
  Decker for a hypothesis. Engine enters DORMANT_AWAITING_HYPOTHESIS state.
- ``{"action": "disabled"}`` — hypothesis_queue_enabled=False on this loop.

``telegram_sender(text) -> bool`` — injected so smoke tests can mock Telegram.
Production wiring binds it to ``agent_comms.reply_to_telegram`` with the
Decker-DM chat_id.
"""

from __future__ import annotations

import datetime as _dt
import json
import logging
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger("aibrain.hypothesis_queue")

# Decker DM chat_id — from MEMORY.md. Telegram reply target for hypothesis
# events. Group chat (-5288572284) is NOT used here — hypothesis workflow is
# 1:1 between Decker and the engine.
DECKER_DM_CHAT_ID = 8267616606

# ---------------------------------------------------------------------------
# Status enum — explicit, so status parsing cannot drift.
# ---------------------------------------------------------------------------


class HypothesisStatus:
    QUEUED = "queued"
    IN_FLIGHT = "in_flight"
    REJECTED = "rejected"
    # "consumed_as_<variant_id>" is a pattern — handled by prefix check.
    CONSUMED_PREFIX = "consumed_as_"


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------


@dataclass
class Hypothesis:
    title: str
    body: str
    status: str
    added_by: str
    added_at: str
    consumed_at: str = ""
    # Line span in the source file (1-indexed, inclusive). Used for status
    # flips — we rewrite only the ``status:`` line, nothing else.
    start_line: int = 0
    end_line: int = 0
    status_line_offset: int = 0  # offset within [start_line, end_line]

    @property
    def is_queued(self) -> bool:
        return self.status == HypothesisStatus.QUEUED


# ---------------------------------------------------------------------------
# Queue parser + writer
# ---------------------------------------------------------------------------


_HEADER_RE = re.compile(r"^## Hypothesis:\s*(.+?)\s*$")
_FIELD_RE = re.compile(r"^(status|added_by|added_at|consumed_at):\s*(.*)\s*$")
_SEPARATOR = "---"


def queue_path(research_root: Path, target: str) -> Path:
    return Path(research_root) / target / "hypothesis_queue.md"


def parse_queue(path: Path) -> list[Hypothesis]:
    """Parse hypothesis_queue.md into a list of Hypothesis objects.

    Returns empty list if the file does not exist. Malformed entries are
    logged and skipped — the queue is never silently rewritten on parse
    errors (user-content preservation contract).
    """
    if not path.is_file():
        return []
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    hypotheses: list[Hypothesis] = []
    i = 0
    while i < len(lines):
        m = _HEADER_RE.match(lines[i])
        if not m:
            i += 1
            continue
        title = m.group(1).strip()
        start_line = i + 1  # 1-indexed
        fields: dict[str, str] = {}
        status_offset = 0
        body_lines: list[str] = []
        j = i + 1
        # Phase machine: "pre_fields" (skip leading blanks after header)
        # → "in_fields" (consume contiguous field lines) → "in_body"
        # (everything else until separator or next header).
        phase = "pre_fields"
        while j < len(lines):
            if _HEADER_RE.match(lines[j]):
                break
            stripped = lines[j].strip()
            if stripped == _SEPARATOR:
                j += 1
                break
            fm = _FIELD_RE.match(lines[j])
            if phase == "pre_fields":
                if fm:
                    fields[fm.group(1)] = fm.group(2).strip()
                    if fm.group(1) == "status":
                        status_offset = j - i
                    phase = "in_fields"
                elif stripped == "":
                    pass  # still skipping leading blanks
                else:
                    # Content before fields — treat as body (unusual but valid).
                    phase = "in_body"
                    body_lines.append(lines[j])
            elif phase == "in_fields":
                if fm:
                    fields[fm.group(1)] = fm.group(2).strip()
                    if fm.group(1) == "status":
                        status_offset = j - i
                elif stripped == "":
                    phase = "in_body"
                else:
                    phase = "in_body"
                    body_lines.append(lines[j])
            else:  # in_body
                body_lines.append(lines[j])
            j += 1
        end_line = j  # 1-indexed inclusive boundary
        if "status" not in fields:
            log.warning("Malformed hypothesis at %s:%d — missing status field, skipping",
                        path, start_line)
            i = j
            continue
        body = "\n".join(body_lines).strip()
        hypotheses.append(Hypothesis(
            title=title,
            body=body,
            status=fields.get("status", HypothesisStatus.QUEUED),
            added_by=fields.get("added_by", "unknown"),
            added_at=fields.get("added_at", ""),
            consumed_at=fields.get("consumed_at", ""),
            start_line=start_line,
            end_line=end_line,
            status_line_offset=status_offset,
        ))
        i = j
    return hypotheses


def _set_status_line(
    path: Path,
    hypothesis: Hypothesis,
    new_status: str,
    consumed_at: Optional[str] = None,
) -> None:
    """Rewrite only the ``status:`` (and optionally ``consumed_at:``) line(s).

    Never touches title, body, or any other field. Preserves line endings as
    read. Writes atomically via replace().
    """
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    status_idx = (hypothesis.start_line - 1) + hypothesis.status_line_offset
    if 0 <= status_idx < len(lines):
        # Preserve trailing newline from original line if any.
        nl = "\n" if lines[status_idx].endswith("\n") else ""
        lines[status_idx] = f"status: {new_status}{nl}"
    # If consumed_at provided, find and update the consumed_at: line within the
    # entry span. If absent, append a consumed_at field just after status.
    if consumed_at is not None:
        span_start = hypothesis.start_line - 1
        span_end = min(hypothesis.end_line, len(lines))
        found = False
        for k in range(span_start, span_end):
            if _FIELD_RE.match(lines[k].rstrip("\r\n")) and lines[k].lstrip().startswith("consumed_at:"):
                nl = "\n" if lines[k].endswith("\n") else ""
                lines[k] = f"consumed_at: {consumed_at}{nl}"
                found = True
                break
        if not found:
            # Append after status line.
            nl = "\n" if lines[status_idx].endswith("\n") else "\n"
            lines.insert(status_idx + 1, f"consumed_at: {consumed_at}{nl}")
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text("".join(lines), encoding="utf-8")
    tmp.replace(path)


def add_hypothesis(
    path: Path,
    title: str,
    body: str,
    added_by: str,
    added_at: Optional[str] = None,
) -> None:
    """Append a new queued hypothesis to the queue file.

    Creates the file with a header comment if it does not yet exist. Never
    modifies existing entries.
    """
    added_at = added_at or _dt.datetime.utcnow().replace(microsecond=0).isoformat()
    path.parent.mkdir(parents=True, exist_ok=True)
    header = (
        "# Hypothesis queue\n\n"
        "Drop abstract hypotheses here — Neuro synthesizes them into concrete\n"
        "variants when the loop plateaus. Format: see\n"
        "`aibrain/core/hypothesis_queue.py` module docstring.\n\n"
    )
    entry = (
        f"## Hypothesis: {title}\n\n"
        f"status: {HypothesisStatus.QUEUED}\n"
        f"added_by: {added_by}\n"
        f"added_at: {added_at}\n"
        f"consumed_at: \n\n"
        f"{body.strip()}\n\n"
        f"---\n\n"
    )
    if not path.is_file():
        path.write_text(header + entry, encoding="utf-8")
        return
    existing = path.read_text(encoding="utf-8")
    if not existing.endswith("\n"):
        existing += "\n"
    path.write_text(existing + entry, encoding="utf-8")


# ---------------------------------------------------------------------------
# DB write — evolution_outcomes row on plateau pull
# ---------------------------------------------------------------------------


def _write_hypothesis_outcome(
    db_path: str | Path,
    target: str,
    action: str,
    hypothesis_title: str,
    details: dict,
) -> int:
    """Append one hypothesis_* row to evolution_outcomes.

    ``action`` is one of ``hypothesis_pulled``, ``hypothesis_queue_empty``,
    ``hypothesis_synthesized``, ``hypothesis_approved``, ``hypothesis_rejected``,
    ``hypothesis_auto_approved_timeout``.
    """
    conn = sqlite3.connect(str(db_path))
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                session_id TEXT
            )
        """)
        cur = conn.execute(
            """
            INSERT INTO evolution_outcomes
                (source, source_id, action, result, details, failure_reason, duration_seconds)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "autoresearch",
                target,
                action,
                hypothesis_title[:200],
                json.dumps(details, sort_keys=True),
                None,
                0.0,
            ),
        )
        conn.commit()
        return cur.lastrowid or 0
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Telegram adapter — production-bound in _default_telegram_sender, mockable
# ---------------------------------------------------------------------------


def _default_telegram_sender(text: str) -> bool:
    """Production Telegram sender — reply_to_telegram to Decker DM.

    Imports lazily so this module stays importable on hosts without the
    decker_system path. Returns True on success, False on failure (never
    raises — the engine should not crash if Telegram is down).

    Cross-host portability: uses ``aibrain.core.paths.resolve_decker_tools_dir``
    to discover ``decker_system/04_tools`` instead of hardcoding Neuro's
    Windows layout. Any resolver failure is caught and treated as non-fatal
    (Telegram silently unavailable beats engine crash).
    """
    import sys
    try:
        from aibrain.core.paths import resolve_decker_tools_dir
        sys.path.insert(0, str(resolve_decker_tools_dir()))
        from agent_comms import reply_to_telegram  # type: ignore
        return bool(reply_to_telegram(DECKER_DM_CHAT_ID, text))
    except Exception as e:
        log.warning("Telegram send failed (non-fatal): %s", e)
        return False


# ---------------------------------------------------------------------------
# Plateau handler — the engine integration point
# ---------------------------------------------------------------------------


@dataclass
class PlateauResult:
    action: str  # "hypothesis_pulled" | "queue_empty" | "disabled"
    hypothesis: Optional[Hypothesis] = None
    telegram_sent: bool = False
    evolution_outcome_id: int = 0


def on_plateau(
    target: str,
    research_root: str | Path,
    db_path: str | Path,
    current_best_score: Optional[float] = None,
    telegram_sender: Optional[Callable[[str], bool]] = None,
) -> PlateauResult:
    """Engine plateau callback. Pulls next queued hypothesis or signals empty.

    Does NOT mutate the variants/ dir or run the synthesis agent — that is
    the job of ``aibrain autoresearch hypothesize <target>``. This hook only
    (a) flips status queued→in_flight, (b) writes evolution_outcomes,
    (c) sends the Telegram notification.
    """
    sender = telegram_sender or _default_telegram_sender
    path = queue_path(Path(research_root), target)
    hypotheses = parse_queue(path)
    queued = [h for h in hypotheses if h.is_queued]

    score_str = f"{current_best_score:.4f}" if current_best_score is not None else "unknown"

    if not queued:
        msg = (
            f"autoresearch[{target}] plateaued at score {score_str}; "
            f"no queued hypotheses. Drop a hypothesis in {path} to unblock."
        )
        sent = sender(msg)
        outcome_id = _write_hypothesis_outcome(
            db_path, target, "hypothesis_queue_empty", "",
            {"queue_path": str(path), "current_best_score": current_best_score},
        )
        return PlateauResult(
            action="queue_empty",
            telegram_sent=sent,
            evolution_outcome_id=outcome_id,
        )

    h = queued[0]
    now = _dt.datetime.utcnow().replace(microsecond=0).isoformat()
    _set_status_line(path, h, HypothesisStatus.IN_FLIGHT, consumed_at=now)
    # Re-read so downstream callers get the updated object.
    h.status = HypothesisStatus.IN_FLIGHT
    h.consumed_at = now

    msg = (
        f"autoresearch[{target}] plateaued at score {score_str}; "
        f"pulling hypothesis from queue: \"{h.title}\". "
        f"Neuro will synthesize a concrete variant and request review. "
        f"Run: aibrain autoresearch hypothesize {target}"
    )
    sent = sender(msg)
    outcome_id = _write_hypothesis_outcome(
        db_path, target, "hypothesis_pulled", h.title,
        {
            "title": h.title,
            "added_by": h.added_by,
            "added_at": h.added_at,
            "consumed_at": h.consumed_at,
            "current_best_score": current_best_score,
            "queue_path": str(path),
        },
    )
    return PlateauResult(
        action="hypothesis_pulled",
        hypothesis=h,
        telegram_sent=sent,
        evolution_outcome_id=outcome_id,
    )


# ---------------------------------------------------------------------------
# Synthesis helper — CLI binding
# ---------------------------------------------------------------------------


def _slug(title: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "_", title.lower()).strip("_")
    return s[:50] or "hypothesis"


def _next_variant_n(variants_dir: Path) -> int:
    """Return the next vN where N = max(existing vN_*) + 1. Starts at 2 to
    avoid colliding with v2_entry1 baseline convention."""
    if not variants_dir.is_dir():
        return 2
    ns: list[int] = []
    for p in variants_dir.iterdir():
        if not p.is_file():
            continue
        m = re.match(r"^v(\d+)_", p.stem)
        if m:
            try:
                ns.append(int(m.group(1)))
            except ValueError:
                pass
    if not ns:
        return 2
    return max(ns) + 1


def synthesize_hypothesis(
    target: str,
    research_root: str | Path,
    db_path: str | Path,
    synth_callable: Optional[Callable[[Hypothesis, dict], str]] = None,
    context: Optional[dict] = None,
    telegram_sender: Optional[Callable[[str], bool]] = None,
) -> dict:
    """Synthesize the in-flight hypothesis into a concrete draft variant.

    The synthesis itself (persona-voice rewrite) is delegated to
    ``synth_callable(hypothesis, context) -> draft_text`` — in production this
    spawns an agent; in tests we pass a deterministic stub. No agent-spawn
    logic is baked in here so the module stays testable.

    Writes the draft to:
        research/<target>/variants/v<next>_hypothesis_<slug>.md

    Returns dict with draft_path, variant_id, hypothesis_title, telegram_sent.
    Raises if no in_flight hypothesis is found.
    """
    sender = telegram_sender or _default_telegram_sender
    root = Path(research_root)
    path = queue_path(root, target)
    hypotheses = parse_queue(path)
    in_flight = [h for h in hypotheses if h.status == HypothesisStatus.IN_FLIGHT]
    if not in_flight:
        raise RuntimeError(
            f"No in_flight hypothesis for target '{target}'. "
            f"Either the queue is empty or the engine has not plateaued yet."
        )
    h = in_flight[0]

    variants_dir = root / target / "variants"
    variants_dir.mkdir(parents=True, exist_ok=True)
    n = _next_variant_n(variants_dir)
    slug = _slug(h.title)
    variant_id = f"v{n}_hypothesis_{slug}"
    draft_path = variants_dir / f"{variant_id}.md"

    draft_text: str
    if synth_callable is None:
        # Default fallback — no agent wired. Ships a stub that flags the gap
        # so humans can intervene. This is the honest-null: without an agent
        # adapter, we write a placeholder rather than pretend-synthesize.
        draft_text = (
            f"# Draft variant — hypothesis synthesis placeholder\n\n"
            f"**Title:** {h.title}\n"
            f"**Added by:** {h.added_by}\n"
            f"**Added at:** {h.added_at}\n\n"
            f"## Original hypothesis body\n\n"
            f"{h.body}\n\n"
            f"## Synthesis status\n\n"
            f"No synth_callable provided. Neuro/agent must rewrite this file\n"
            f"into a concrete variant that fits the target's baseline shape\n"
            f"(for intel_agent: the V2 persona rewrite pattern). Until then,\n"
            f"this file is DRAFT and should NOT be fed to the loop.\n"
        )
    else:
        draft_text = synth_callable(h, context or {})

    draft_path.write_text(draft_text, encoding="utf-8")

    _write_hypothesis_outcome(
        db_path, target, "hypothesis_synthesized", h.title,
        {
            "title": h.title,
            "variant_id": variant_id,
            "draft_path": str(draft_path),
            "synth_callable_used": synth_callable is not None,
        },
    )

    msg = (
        f"autoresearch[{target}] draft variant ready: {draft_path}. "
        f"Reply /approve {target} to enter the loop or "
        f"/reject {target} <reason> to send back."
    )
    sent = sender(msg)

    return {
        "draft_path": str(draft_path),
        "variant_id": variant_id,
        "hypothesis_title": h.title,
        "hypothesis_body": h.body,
        "telegram_sent": sent,
    }


# ---------------------------------------------------------------------------
# Approval flow
# ---------------------------------------------------------------------------


def approve_hypothesis(
    target: str,
    research_root: str | Path,
    db_path: str | Path,
    auto: bool = False,
) -> dict:
    """Flip the in_flight hypothesis's status to ``consumed_as_<variant_id>``.

    Finds the most recent ``hypothesis_synthesized`` evolution_outcomes row
    for the target to pull the variant_id. Writes a
    ``hypothesis_approved`` (or ``hypothesis_auto_approved_timeout`` when
    ``auto=True``) evolution_outcomes row.
    """
    path = queue_path(Path(research_root), target)
    hypotheses = parse_queue(path)
    in_flight = [h for h in hypotheses if h.status == HypothesisStatus.IN_FLIGHT]
    if not in_flight:
        raise RuntimeError(f"No in_flight hypothesis for target '{target}'")
    h = in_flight[0]

    variant_id = _recent_variant_id_for(db_path, target)
    consumed_status = f"{HypothesisStatus.CONSUMED_PREFIX}{variant_id}" if variant_id else f"{HypothesisStatus.CONSUMED_PREFIX}unknown"
    _set_status_line(path, h, consumed_status)

    action = "hypothesis_auto_approved_timeout" if auto else "hypothesis_approved"
    _write_hypothesis_outcome(
        db_path, target, action, h.title,
        {"title": h.title, "variant_id": variant_id, "auto": auto},
    )
    return {"hypothesis_title": h.title, "variant_id": variant_id, "auto": auto}


def reject_hypothesis(
    target: str,
    research_root: str | Path,
    db_path: str | Path,
    reason: str,
) -> dict:
    path = queue_path(Path(research_root), target)
    hypotheses = parse_queue(path)
    in_flight = [h for h in hypotheses if h.status == HypothesisStatus.IN_FLIGHT]
    if not in_flight:
        raise RuntimeError(f"No in_flight hypothesis for target '{target}'")
    h = in_flight[0]
    _set_status_line(path, h, HypothesisStatus.REJECTED)
    _write_hypothesis_outcome(
        db_path, target, "hypothesis_rejected", h.title,
        {"title": h.title, "reason": reason},
    )
    return {"hypothesis_title": h.title, "reason": reason}


def _recent_variant_id_for(db_path: str | Path, target: str) -> Optional[str]:
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute(
            """
            SELECT details FROM evolution_outcomes
            WHERE source='autoresearch' AND source_id=? AND action='hypothesis_synthesized'
            ORDER BY id DESC LIMIT 1
            """,
            (target,),
        ).fetchone()
        if not row or not row[0]:
            return None
        try:
            d = json.loads(row[0])
            return d.get("variant_id")
        except json.JSONDecodeError:
            return None
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Auto-approval timeout configuration — read per-target from program.md
# ---------------------------------------------------------------------------


_AUTO_APPROVE_RE = re.compile(
    r"^\s*auto_approve_timeout_hours\s*[:=]\s*(\d+(?:\.\d+)?)\s*$",
    re.IGNORECASE,
)


def auto_approve_timeout_hours(research_root: str | Path, target: str,
                               default: float = 12.0) -> float:
    """Read auto_approve_timeout_hours from research/<target>/program.md.

    Looks for a line like ``auto_approve_timeout_hours: 12`` anywhere in
    program.md. Falls back to ``default`` (12h) if missing or unparseable.
    Never hardcoded to a lower value than 12h — constraint from task brief.
    """
    p = Path(research_root) / target / "program.md"
    if not p.is_file():
        return default
    try:
        for line in p.read_text(encoding="utf-8").splitlines():
            m = _AUTO_APPROVE_RE.match(line)
            if m:
                try:
                    val = float(m.group(1))
                    return max(val, 0.0) if val > 0 else default
                except ValueError:
                    continue
    except Exception:
        pass
    return default


_INTEL_AGENT_PERSONA_FILENAME = "intel_agent_v2.md"


def _intel_agent_persona_path() -> Path | None:
    """Resolve ``decker_system/02_subagents/intel_agent_v2.md``.

    Returns None if the decker_system overlay is not discoverable on this
    host — callers treat that as "CLI not found, fall back to stub". Routes
    through ``aibrain.core.paths`` for the same three-branch discovery as
    the other resolvers in this module.
    """
    try:
        from aibrain.core.paths import resolve_decker_subagents_dir
        return resolve_decker_subagents_dir() / _INTEL_AGENT_PERSONA_FILENAME
    except Exception:
        return None

_SYNTH_PROMPT_TEMPLATE = """\
You are synthesizing an abstract hypothesis into a concrete Karpathy-loop variant
file for the ``{target}`` target.

The variant will be read by the autoresearch engine and evaluated against the
target's battery + metric. The variant MUST be a drop-in replacement for the
baseline persona / program file — same shape, same structure, same expected
output contract — but modified per the hypothesis below.

HYPOTHESIS TITLE
{title}

HYPOTHESIS BODY (author: {added_by}, drop-in verbatim — may be a 1-liner)
{body}

BASELINE / PRIOR VARIANT SHAPE REFERENCE
{baseline_ref}

REQUIRED OUTPUT
- Produce ONLY the final concrete variant file content. No preamble, no "here
  is the draft" framing. The engine will write your output verbatim to disk.
- Preserve the baseline's section structure and front-matter. Modify only what
  the hypothesis implies. Everything else passes through unchanged.
- If the hypothesis is under-specified, pick the most load-bearing concrete
  interpretation and mark any unresolved alternatives as ``# TODO(hypothesis)``
  comments inside the file — do NOT invent scope.
- Do NOT mutate the canonical baseline persona file on disk. Your output is a
  NEW variant; the engine writes it to a fresh path.

Additional context (evolution history, feedback log, MEMORY excerpts):
{context}
"""


def _build_intel_agent_context(research_root: Path, target: str,
                               db_path: str | Path) -> str:
    """Collect context strings for intel_agent synthesis: feedback log,
    recent evolution outcomes, baseline variant excerpt."""
    parts: list[str] = []
    try:
        from aibrain.core.paths import resolve_decker_meta_dir
        feedback_log: Path | None = resolve_decker_meta_dir() / "intel_agent_v2_self_feedback_log.md"
    except Exception:
        feedback_log = None
    if feedback_log is not None and feedback_log.is_file():
        try:
            parts.append("## intel_agent_v2 self-feedback log (recent excerpts):\n\n"
                         + feedback_log.read_text(encoding="utf-8", errors="replace")[:4000])
        except Exception as e:
            parts.append(f"(feedback log read failed: {e})")
    # Recent evolution_outcomes for this target
    try:
        conn = sqlite3.connect(str(db_path))
        rows = conn.execute(
            """
            SELECT action, result, details FROM evolution_outcomes
            WHERE source='autoresearch' AND source_id=?
            ORDER BY id DESC LIMIT 10
            """,
            (target,),
        ).fetchall()
        conn.close()
        if rows:
            lines = [f"- {r[0]} | {r[1] or ''}" for r in rows]
            parts.append("## Recent evolution_outcomes (top 10):\n\n" + "\n".join(lines))
    except Exception as e:
        parts.append(f"(evolution_outcomes read failed: {e})")
    return "\n\n".join(parts) if parts else "(no additional context)"


def _baseline_ref_for(target: str, research_root: Path) -> str:
    """Return a truncated baseline / best-variant reference string for the
    synthesis prompt. For intel_agent we include the canonical V2 persona (the
    thing being iterated against). For any other target we use the most recent
    existing variant file in variants/."""
    if target == "intel_agent":
        p = _intel_agent_persona_path()
        if p is not None and p.is_file():
            try:
                return p.read_text(encoding="utf-8", errors="replace")[:8000]
            except Exception as e:
                return f"(baseline persona read failed: {e})"
    variants_dir = research_root / target / "variants"
    if variants_dir.is_dir():
        try:
            vs = sorted(variants_dir.glob("v*.md"))
            if vs:
                return vs[-1].read_text(encoding="utf-8", errors="replace")[:8000]
        except Exception:
            pass
    return "(no baseline reference available — synthesize from the hypothesis alone)"


def claude_synth_callable(
    target: str,
    research_root: str | Path,
    db_path: str | Path,
    model: Optional[str] = None,
    timeout_s: int = 900,
) -> Callable[["Hypothesis", dict], str]:
    """Return a synth_callable bound to the Claude CLI.

    Builds the target-aware synthesis prompt from:
      - the hypothesis title + body + added_by
      - the baseline / prior variant reference
      - per-target context (self-feedback log for intel_agent, recent
        evolution_outcomes rows for any target)

    Invokes ``decker_system/04_tools/claude_cli.py::call_claude_cli`` with the
    canonical Windows-safe path (stdin-pipe, --append-system-prompt-file).

    For ``target='intel_agent'`` the system prompt IS the canonical V2 persona
    file (read-only — never mutated). For other targets the system prompt is a
    generic "act as a methodology-disciplined synthesis agent" stub.

    Honest-null: if ``claude`` is not on PATH, returns the same placeholder
    shape as ``synth_callable=None`` rather than hanging. The stub file will
    flag "CLI not found" in its body so the human path is obvious.
    """
    import sys as _sys
    try:
        from aibrain.core.paths import resolve_decker_tools_dir
        _sys.path.insert(0, str(resolve_decker_tools_dir()))
        from claude_cli import call_claude_cli  # type: ignore
    except Exception as e:
        log.warning("claude_cli import failed: %s — synth will fall back", e)
        call_claude_cli = None  # type: ignore

    root = Path(research_root)

    def _synth(hypothesis: "Hypothesis", context: dict) -> str:
        ctx_str = _build_intel_agent_context(root, target, db_path)
        baseline_ref = _baseline_ref_for(target, root)
        prompt = _SYNTH_PROMPT_TEMPLATE.format(
            target=target,
            title=hypothesis.title,
            added_by=hypothesis.added_by,
            body=hypothesis.body,
            baseline_ref=baseline_ref,
            context=ctx_str,
        )
        system_prompt: Optional[str] = None
        if target == "intel_agent":
            p = _intel_agent_persona_path()
            if p is not None and p.is_file():
                try:
                    system_prompt = p.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    system_prompt = None
        if call_claude_cli is None:
            return (
                f"# Draft variant — claude_cli unavailable\n\n"
                f"**Title:** {hypothesis.title}\n"
                f"**Body:**\n\n{hypothesis.body}\n\n"
                f"## Synthesis status\n\n"
                f"claude_cli import failed. Neuro/human must rewrite this file\n"
                f"into a concrete variant. Until then, this file is DRAFT and\n"
                f"should NOT be fed to the loop.\n"
            )
        rc, stdout, stderr = call_claude_cli(
            prompt=prompt,
            system_prompt=system_prompt,
            model=model,
            timeout_s=timeout_s,
        )
        if rc != 0 or not stdout.strip():
            return (
                f"# Draft variant — synthesis failed (rc={rc})\n\n"
                f"**Title:** {hypothesis.title}\n\n"
                f"## Original hypothesis body\n\n{hypothesis.body}\n\n"
                f"## Synthesis status\n\n"
                f"claude CLI returned rc={rc}. stderr:\n\n"
                f"```\n{stderr[:2000]}\n```\n\n"
                f"This file is DRAFT and should NOT be fed to the loop until\n"
                f"a human rewrites it.\n"
            )
        return stdout

    return _synth


def auto_approve_if_timed_out(
    target: str,
    research_root: str | Path,
    db_path: str | Path,
    now: Optional[_dt.datetime] = None,
) -> Optional[dict]:
    """If the in_flight hypothesis's consumed_at is older than the per-target
    timeout, flip it to consumed_as_<variant_id> and return approval dict.

    Returns None when no action taken (no in_flight, or still within window).
    Intended to be called by a scheduled job (cron). Does NOT send a fresh
    Telegram — the approved-by-timeout message is written once.
    """
    now = now or _dt.datetime.utcnow()
    path = queue_path(Path(research_root), target)
    hypotheses = parse_queue(path)
    in_flight = [h for h in hypotheses if h.status == HypothesisStatus.IN_FLIGHT]
    if not in_flight:
        return None
    h = in_flight[0]
    if not h.consumed_at:
        return None
    try:
        consumed_dt = _dt.datetime.fromisoformat(h.consumed_at.replace("Z", ""))
    except ValueError:
        return None
    timeout_h = auto_approve_timeout_hours(research_root, target)
    elapsed_h = (now - consumed_dt).total_seconds() / 3600.0
    if elapsed_h < timeout_h:
        return None
    return approve_hypothesis(target, research_root, db_path, auto=True)
