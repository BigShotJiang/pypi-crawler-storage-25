"""Post to Twitter/X via Playwright browser automation.

Fallback when the tweepy API path is unavailable (no credits, 402, stub).
Uses TWITTER_USERNAME + TWITTER_PASSWORD from env, or TWITTER_COOKIES_PATH
if a saved session cookie file exists (speeds up repeated runs).

Returns the tweet URL on success, None on failure. Never raises — all
exceptions are caught and logged so callers can fall through gracefully.
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Twitter/X URLs
_HOME_URL = "https://x.com/home"
_COMPOSE_URL = "https://x.com/compose/tweet"
_LOGIN_URL = "https://x.com/i/flow/login"

# Selectors — these can drift when X redesigns its UI.
# If posts stop working, the first thing to check is whether these still match.
_SEL_USERNAME_INPUT = 'input[autocomplete="username"]'
_SEL_PASSWORD_INPUT = 'input[name="password"]'
_SEL_TWEET_TEXTAREA = '[data-testid="tweetTextarea_0"]'
_SEL_TWEET_BUTTON = '[data-testid="tweetButtonInline"]'
_SEL_CONFIRMATION_TWEET = '[data-testid="tweet"]'

# Timeouts in milliseconds
_NAV_TIMEOUT = 30_000
_ACTION_TIMEOUT = 15_000


def _load_cookies(context, cookies_path: str) -> bool:
    """Load cookies from a JSON file into the browser context.

    Returns True if cookies were loaded successfully, False otherwise.
    """
    path = Path(cookies_path)
    if not path.exists():
        logger.debug("twitter_playwright: cookies file not found at %s", cookies_path)
        return False
    try:
        cookies = json.loads(path.read_text(encoding="utf-8"))
        context.add_cookies(cookies)
        logger.debug("twitter_playwright: loaded %d cookies from %s", len(cookies), cookies_path)
        return True
    except Exception as exc:
        logger.warning("twitter_playwright: failed to load cookies from %s — %s", cookies_path, exc)
        return False


def _save_cookies(context, cookies_path: str) -> None:
    """Save current browser context cookies to a JSON file for reuse."""
    try:
        cookies = context.cookies()
        path = Path(cookies_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cookies, indent=2), encoding="utf-8")
        logger.debug("twitter_playwright: saved %d cookies to %s", len(cookies), cookies_path)
    except Exception as exc:
        logger.warning("twitter_playwright: failed to save cookies to %s — %s", cookies_path, exc)


def _is_logged_in(page) -> bool:
    """Check if the current page indicates an authenticated session."""
    try:
        # If we're on the home timeline or compose URL without being
        # redirected to login, we're likely authenticated.
        url = page.url
        return "x.com/login" not in url and "x.com/i/flow/login" not in url
    except Exception:
        return False


def _login(page, username: str, password: str) -> bool:
    """Perform username + password login flow on x.com.

    Returns True on apparent success, False on any failure.
    Logs all failures at WARNING so callers can diagnose without
    needing to re-run with debug flags.
    """
    try:
        logger.debug("twitter_playwright: navigating to login page")
        page.goto(_LOGIN_URL, timeout=_NAV_TIMEOUT)
        page.wait_for_load_state("networkidle", timeout=_NAV_TIMEOUT)

        # Step 1: enter username / email / phone
        logger.debug("twitter_playwright: waiting for username input")
        page.wait_for_selector(_SEL_USERNAME_INPUT, timeout=_ACTION_TIMEOUT)
        page.fill(_SEL_USERNAME_INPUT, username)
        page.keyboard.press("Enter")

        # Step 2: X sometimes inserts a phone/email verification step —
        # check for it and skip if not present.
        try:
            # If there's a "verify your identity" input (not the password)
            unusual_input = page.wait_for_selector(
                'input[data-testid="ocfEnterTextTextInput"]',
                timeout=3_000,
            )
            if unusual_input:
                logger.debug("twitter_playwright: unusual activity gate detected — filling username again")
                unusual_input.fill(username)
                page.keyboard.press("Enter")
        except Exception:
            pass  # No unusual activity gate — continue normally

        # Step 3: enter password
        logger.debug("twitter_playwright: waiting for password input")
        page.wait_for_selector(_SEL_PASSWORD_INPUT, timeout=_ACTION_TIMEOUT)
        page.fill(_SEL_PASSWORD_INPUT, password)
        page.keyboard.press("Enter")

        # Wait for navigation after login attempt
        page.wait_for_load_state("networkidle", timeout=_NAV_TIMEOUT)

        if not _is_logged_in(page):
            logger.warning(
                "twitter_playwright: login appeared to fail — ended up at %s", page.url
            )
            return False

        logger.debug("twitter_playwright: login succeeded — at %s", page.url)
        return True

    except Exception as exc:
        logger.warning("twitter_playwright: login raised an exception — %s", exc)
        return False


def _extract_tweet_url(page, username: str) -> Optional[str]:
    """Try to extract the URL of the tweet that was just posted.

    X redirects to the tweet's permalink after a successful post, but
    this is not guaranteed — the page may stay at the compose URL or
    move to the home timeline. We try several strategies in order:

    1. Direct URL if the page redirected to a /status/ path.
    2. The href of the first tweet card on the resulting page that
       belongs to the authenticated user.

    Returns the tweet URL string or None if it cannot be determined.
    The caller should still treat None as a successful post if the
    tweet textarea is no longer present.
    """
    try:
        current_url = page.url
        if "/status/" in current_url:
            return current_url
    except Exception:
        pass

    try:
        # Look for the first tweet card belonging to the user.
        # The tweet's permalink is in an <a> with a time element and /status/
        # in the href.
        link = page.query_selector(
            f'a[href*="/{username}/status/"]'
        )
        if link:
            href = link.get_attribute("href")
            if href:
                return f"https://x.com{href}" if href.startswith("/") else href
    except Exception as exc:
        logger.debug("twitter_playwright: could not extract tweet URL from page — %s", exc)

    return None


def post_tweet(text: str, env: dict) -> Optional[str]:
    """Post a tweet via Playwright browser automation.

    Parameters
    ----------
    text:
        The tweet body to post. Must be within X's character limit (280 chars
        for standard accounts). Caller is responsible for truncation — this
        function posts whatever it receives.
    env:
        Dict of environment variables. Expected keys:
        - TWITTER_USERNAME — login username / email / phone
        - TWITTER_PASSWORD — account password
        - TWITTER_COOKIES_PATH — (optional) path to a JSON cookies file.
          If the file exists, login is skipped (faster + avoids repeated
          login attempts that can trigger rate limits). If TWITTER_USERNAME
          and TWITTER_PASSWORD are present and TWITTER_COOKIES_PATH is set
          but the file doesn't exist yet, cookies are saved after login.

    Returns
    -------
    str | None
        The tweet URL (e.g. ``https://x.com/username/status/12345``) on
        success, or None on any failure. Never raises.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        logger.warning(
            "twitter_playwright: playwright not installed — "
            "run `pip install playwright && playwright install chromium`"
        )
        return None

    username: str = env.get("TWITTER_USERNAME", "")
    password: str = env.get("TWITTER_PASSWORD", "")
    cookies_path: str = env.get("TWITTER_COOKIES_PATH", "")

    if not text:
        logger.warning("twitter_playwright: post_tweet called with empty text — skipping")
        return None

    # Validate we have enough credentials to proceed
    has_cookies = bool(cookies_path) and Path(cookies_path).exists()
    has_credentials = bool(username) and bool(password)

    if not has_cookies and not has_credentials:
        logger.warning(
            "twitter_playwright: no usable credentials — "
            "set TWITTER_USERNAME + TWITTER_PASSWORD or TWITTER_COOKIES_PATH "
            "(with a valid cookies file) in env"
        )
        return None

    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/122.0.0.0 Safari/537.36"
                ),
                viewport={"width": 1280, "height": 800},
            )
            page = context.new_page()

            # --- Authentication ---
            logged_in = False

            if has_cookies:
                logger.debug("twitter_playwright: attempting cookie-based auth from %s", cookies_path)
                _load_cookies(context, cookies_path)
                # Navigate to home to check if session is still valid
                try:
                    page.goto(_HOME_URL, timeout=_NAV_TIMEOUT)
                    page.wait_for_load_state("networkidle", timeout=_NAV_TIMEOUT)
                    logged_in = _is_logged_in(page)
                    if logged_in:
                        logger.debug("twitter_playwright: cookie session valid")
                    else:
                        logger.debug("twitter_playwright: cookie session expired — will try password login")
                except Exception as exc:
                    logger.warning("twitter_playwright: cookie nav failed — %s", exc)

            if not logged_in and has_credentials:
                logger.debug("twitter_playwright: attempting password login for %s", username)
                logged_in = _login(page, username, password)
                if logged_in and cookies_path:
                    # Persist session for future runs
                    _save_cookies(context, cookies_path)

            if not logged_in:
                logger.warning(
                    "twitter_playwright: could not authenticate — "
                    "check credentials or refresh cookie file"
                )
                browser.close()
                return None

            # --- Compose and post tweet ---
            logger.debug("twitter_playwright: navigating to compose URL")
            try:
                page.goto(_COMPOSE_URL, timeout=_NAV_TIMEOUT)
                page.wait_for_load_state("networkidle", timeout=_NAV_TIMEOUT)
            except Exception as exc:
                logger.warning("twitter_playwright: failed to navigate to compose URL — %s", exc)
                browser.close()
                return None

            # Fill the tweet textarea
            try:
                logger.debug("twitter_playwright: waiting for tweet textarea")
                page.wait_for_selector(_SEL_TWEET_TEXTAREA, timeout=_ACTION_TIMEOUT)
                page.click(_SEL_TWEET_TEXTAREA)
                page.keyboard.type(text, delay=30)  # slight delay mimics human typing
            except Exception as exc:
                logger.warning("twitter_playwright: failed to fill tweet text — %s", exc)
                browser.close()
                return None

            # Click the post button
            try:
                logger.debug("twitter_playwright: clicking post button")
                page.wait_for_selector(_SEL_TWEET_BUTTON, timeout=_ACTION_TIMEOUT)
                page.click(_SEL_TWEET_BUTTON)
            except Exception as exc:
                logger.warning("twitter_playwright: failed to click post button — %s", exc)
                browser.close()
                return None

            # Wait for the post to complete — the compose dialog closes on success
            try:
                # Wait a moment for navigation / DOM update
                page.wait_for_load_state("networkidle", timeout=_NAV_TIMEOUT)
            except Exception:
                # networkidle timeout is non-fatal — the tweet may still have posted
                pass

            # Try to get the tweet URL
            tweet_url = _extract_tweet_url(page, username)

            # Verify the compose textarea is gone (i.e., post likely succeeded)
            compose_still_open = False
            try:
                compose_still_open = page.is_visible(_SEL_TWEET_TEXTAREA, timeout=2_000)
            except Exception:
                pass

            browser.close()

            if compose_still_open:
                logger.warning(
                    "twitter_playwright: tweet compose textarea still visible after submit — "
                    "post may have failed (e.g. character limit exceeded or rate limit)"
                )
                return None

            if tweet_url:
                logger.info("twitter_playwright: tweet posted successfully — %s", tweet_url)
                return tweet_url

            # Post appears to have succeeded (compose closed) but we couldn't
            # extract the URL. Return a sentinel so the caller knows it worked
            # even without a precise URL.
            synthetic_id = f"https://x.com/{username}/status/unknown_{int(time.time())}"
            logger.info(
                "twitter_playwright: tweet posted (URL not extractable) — returning synthetic: %s",
                synthetic_id,
            )
            return synthetic_id

    except Exception as exc:
        logger.warning("twitter_playwright: unexpected error in post_tweet — %s", exc)
        return None


__all__ = ["post_tweet"]
