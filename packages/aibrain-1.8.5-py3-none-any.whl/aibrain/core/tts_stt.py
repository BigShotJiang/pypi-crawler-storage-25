"""tts_stt.py — F-TTS-STT-1: Whisper STT + Kokoro TTS for accessibility.

Speech-to-text via OpenAI Whisper (local or API).
Text-to-speech via Kokoro TTS (MIT-licensed, local).
Lazy model loading — first call downloads models.
"""
import logging, os, tempfile
from pathlib import Path

log = logging.getLogger("aibrain.tts_stt")

# ---- Speech-to-Text (Whisper) ----

def whisper_stt(audio_path: str = None, model: str = "base") -> str:
    """Transcribe speech to text using Whisper.
    If audio_path is None, records from microphone for 5 seconds.
    Returns transcribed text or error string.
    """
    try:
        import whisper
        wmodel = whisper.load_model(model)
        if audio_path:
            result = wmodel.transcribe(audio_path)
        else:
            # Record from mic
            import sounddevice as sd
            import numpy as np
            fs = 16000
            duration = 5
            recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
            sd.wait()
            audio = recording.flatten().astype(np.float32)
            result = wmodel.transcribe(audio, fp16=False)
        return result.get("text", "").strip()
    except ImportError as e:
        return f"[stt] {e}. Install: pip install openai-whisper sounddevice numpy"
    except Exception as e:
        return f"[stt] error: {e}"


# ---- Text-to-Speech (Kokoro) ----

def kokoro_tts(text: str, output_path: str = None, voice: str = "af_heart") -> str:
    """Convert text to speech using Kokoro TTS.
    Returns path to generated WAV file.
    """
    if not output_path:
        output_path = str(Path(tempfile.gettempdir()) / "lucy_tts_output.wav")
    try:
        from kokoro import KPipeline
        pipeline = KPipeline(lang_code='a')
        generator = pipeline(text, voice=voice, speed=1.0)
        import soundfile as sf
        all_audio = []
        for _, _, audio in generator:
            all_audio.append(audio)
        import numpy as np
        combined = np.concatenate(all_audio) if all_audio else np.array([])
        sf.write(output_path, combined, 24000)
        return output_path
    except ImportError as e:
        return f"[tts] {e}. Install: pip install kokoro soundfile"
    except Exception as e:
        return f"[tts] error: {e}"


def lucy_speak(text: str) -> str:
    """Convenience: TTS + play audio. Returns status."""
    try:
        path = kokoro_tts(text)
        if path.startswith("[tts]"):
            return path
        import sounddevice as sd
        import soundfile as sf
        data, sr = sf.read(path)
        sd.play(data, sr)
        sd.wait()
        return f"[spoken] {len(text)} chars"
    except Exception as e:
        return f"[speak] error: {e}"
