import os
import hashlib
import sqlite3
import time

from aibrain.core.memory_provider import MemoryProvider, Memory
from aibrain.core.errors import MemoryProviderUnavailable

CIRCUIT_THRESHOLD = 3
CIRCUIT_COOLDOWN = 60


class MemoryManager:
    def __init__(self, provider: MemoryProvider):
        self.provider = provider
        self._failure_count = 0
        self._circuit_open = False
        self._open_since: float | None = None
        self._ensure_audit_table()

    def _db_path(self) -> str:
        return os.environ.get('AIBRAIN_DB', 'aibrain.db')

    def _ensure_audit_table(self) -> None:
        conn = sqlite3.connect(self._db_path())
        try:
            conn.execute(
                '''CREATE TABLE IF NOT EXISTS provider_audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                    actor TEXT NOT NULL,
                    provider_id TEXT NOT NULL,
                    verb TEXT NOT NULL CHECK (verb IN ('store','retrieve','forget','migrate','init','destroy')),
                    payload_hash TEXT NOT NULL,
                    capability_drop TEXT
                )'''
            )
            conn.commit()
        finally:
            conn.close()

    def _log_audit(self, actor: str, verb: str, payload_hash: str, capability_drop: str | None = None) -> None:
        conn = sqlite3.connect(self._db_path())
        try:
            conn.execute(
                'INSERT INTO provider_audit (actor, provider_id, verb, payload_hash, capability_drop) VALUES (?, ?, ?, ?, ?)',
                (actor, self.provider.id, verb, payload_hash, capability_drop)
            )
            conn.commit()
        finally:
            conn.close()

    def _check_circuit(self) -> None:
        if self._circuit_open:
            elapsed = time.monotonic() - self._open_since
            if elapsed >= CIRCUIT_COOLDOWN:
                self._circuit_open = False
                self._open_since = None
            else:
                raise MemoryProviderUnavailable('circuit open', provider_id=self.provider.id)

    def _record_failure(self) -> None:
        self._failure_count += 1
        if self._failure_count >= CIRCUIT_THRESHOLD:
            self._circuit_open = True
            self._open_since = time.monotonic()

    def _record_success(self) -> None:
        self._failure_count = 0
        self._circuit_open = False

    async def store(self, content: str, metadata: dict, actor: str = 'agent') -> str:
        self._check_circuit()
        payload_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
        try:
            result = await self.provider.store(content, metadata)
            self._record_success()
        except Exception:
            self._record_failure()
            raise
        self._log_audit(actor, 'store', payload_hash)
        return result

    async def retrieve(self, query: str, top_k: int = 5, filters: dict | None = None,
                       actor: str = 'agent', require_capability: str | None = None) -> list[Memory]:
        if require_capability:
            self.provider.check_capability(require_capability)
        self._check_circuit()
        payload_hash = hashlib.sha256(query.encode()).hexdigest()[:16]
        try:
            results = await self.provider.retrieve(query, top_k, filters)
            self._record_success()
        except Exception:
            self._record_failure()
            raise
        self._log_audit(actor, 'retrieve', payload_hash)
        return results

    async def forget(self, memory_id: str, actor: str = 'agent') -> None:
        self.provider.check_capability('forget')
        self._check_circuit()
        payload_hash = hashlib.sha256(memory_id.encode()).hexdigest()[:16]
        try:
            await self.provider.forget(memory_id)
            self._record_success()
        except Exception:
            self._record_failure()
            raise
        self._log_audit(actor, 'forget', payload_hash)

    @property
    def active_provider(self) -> MemoryProvider:
        return self.provider
