"""
db_safety.py — multi-instance SQLite write safety for aibrain.db.

Adds three cheap, additive protections to every write path that touches
shared state (memories, evolution_outcomes, execution_log):

  1. PRAGMA journal_mode = WAL          (concurrent readers + one writer)
  2. PRAGMA busy_timeout = 5000         (fail-slow retry instead of SQLITE_BUSY)
  3. PRAGMA synchronous = NORMAL        (safe under WAL, faster)
  4. session_id TEXT column             (per-process UUID; provenance + forensics)

The session_id is generated exactly once per Python process. Every INSERT
that the canonical write paths perform attaches it, so when two instances
run concurrently (Neuro + Case, or two Neuro terminals, or a daemon + a
CLI), any row can be traced to the writer that produced it. That reveals
silent last-write-wins bugs the moment they happen instead of weeks later.

HARD RULE: this module must stay additive. No table is rewritten; the
column is NULL on pre-existing rows and on any writer that hasn't been
wired yet. See project_multi_instance_memory_safety.md.
"""
from __future__ import annotations

import os
import sqlite3
import threading
import uuid
from typing import Iterable

# ---------------------------------------------------------------------------
# Per-process session id
# ---------------------------------------------------------------------------

_session_id: str | None = None
_session_lock = threading.Lock()


def session_id() -> str:
    """Return the UUID identifying this Python process's writes.

    Generated once per process and cached. Format: "<pid>-<uuid4-hex[:12]>"
    so a human skim of the column reveals both the OS pid and a globally
    unique tie-breaker (pids recycle).
    """
    global _session_id
    if _session_id is not None:
        return _session_id
    with _session_lock:
        if _session_id is None:
            _session_id = f"{os.getpid()}-{uuid.uuid4().hex[:12]}"
    return _session_id


# ---------------------------------------------------------------------------
# Pragma hygiene
# ---------------------------------------------------------------------------

def apply_pragmas(conn: sqlite3.Connection, busy_timeout_ms: int = 5000) -> None:
    """Apply the concurrent-safety pragmas to an open connection.

    Idempotent — safe to call on already-configured connections. Swallows
    errors on read-only connections (mode=ro), which reject journal_mode
    writes.
    """
    try:
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.OperationalError:
        pass  # read-only or locked — fine
    try:
        conn.execute(f"PRAGMA busy_timeout={int(busy_timeout_ms)}")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("PRAGMA synchronous=NORMAL")
    except sqlite3.OperationalError:
        pass


# ---------------------------------------------------------------------------
# Additive migration
# ---------------------------------------------------------------------------

_SESSION_ID_TABLES: tuple[str, ...] = (
    "memories",
    "evolution_outcomes",
    "execution_log",
)


def _table_has_column(conn: sqlite3.Connection, table: str, column: str) -> bool:
    try:
        cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    except sqlite3.OperationalError:
        return False
    return column in cols


def ensure_session_columns(
    conn: sqlite3.Connection,
    tables: Iterable[str] = _SESSION_ID_TABLES,
) -> list[str]:
    """Add session_id TEXT (nullable, default NULL) to each named table if absent.

    Purely additive — no backfill, no down-migration, existing rows stay as-is.
    Returns the list of tables that were actually altered.
    """
    altered: list[str] = []
    for t in tables:
        # Table might not exist yet in a partially-initialized DB — skip silently.
        try:
            conn.execute(f"SELECT 1 FROM {t} LIMIT 1")
        except sqlite3.OperationalError:
            continue
        if _table_has_column(conn, t, "session_id"):
            continue
        try:
            conn.execute(f"ALTER TABLE {t} ADD COLUMN session_id TEXT DEFAULT NULL")
            altered.append(t)
        except sqlite3.OperationalError:
            # Lost a race with another process adding the column — also fine.
            pass
    if altered:
        try:
            conn.commit()
        except sqlite3.OperationalError:
            pass
    return altered


__all__ = ["session_id", "apply_pragmas", "ensure_session_columns"]
