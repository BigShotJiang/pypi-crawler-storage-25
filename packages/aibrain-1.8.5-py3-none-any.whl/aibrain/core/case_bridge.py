"""case_bridge.py — F-CASE-FLEETBUS-BRIDGE-1: cross-host comms bridge.

Case is on VPS, can't reach Windows FleetBus DB. This bridge:
1. Listens on VPS broker (port 8765) for messages from Case
2. Translates to FleetBus agent_messages inserts on Windows side
3. Pushes FleetBus messages addressed to 'case' back to VPS broker

Run on Windows: python -m aibrain.core.case_bridge
Env: AIBRAIN_VPS_BROKER=http://76.13.198.228:8765 (required)
"""
import json, logging, os, sqlite3, sys, threading, time, urllib.request
from pathlib import Path

log = logging.getLogger("aibrain.case_bridge")

VPS_BROKER = os.environ.get("AIBRAIN_VPS_BROKER", "")
POLL_INTERVAL = 10  # seconds
LOCAL_DB = Path(os.environ.get("AIBRAIN_ROOT", str(Path.home()))) / "aibrain.db"


def pull_from_vps() -> list[dict]:
    """Pull messages from VPS broker for Case."""
    if not VPS_BROKER:
        return []
    try:
        url = f"{VPS_BROKER}/messages?agent_id=case"
        with urllib.request.urlopen(url, timeout=5) as r:
            return json.loads(r.read()).get("messages", [])
    except Exception:
        return []


def push_to_vps(msg: dict):
    """Push a FleetBus message addressed to Case to the VPS broker."""
    if not VPS_BROKER:
        return
    try:
        url = f"{VPS_BROKER}/publish"
        data = json.dumps(msg).encode()
        req = urllib.request.Request(url, data=data,
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def store_local(msg: dict):
    """Store a VPS message in local agent_messages for FleetBus poll_inbox."""
    try:
        db = sqlite3.connect(str(LOCAL_DB))
        db.execute(
            """INSERT OR IGNORE INTO agent_messages 
               (msg_id, event_type, source_agent, target_agent, subject, payload, status)
               VALUES (?, ?, ?, ?, ?, ?, 'pending')""",
            (msg.get("id", ""), msg.get("type", "fleet.direct"),
             msg.get("from", "case@vps"), "*",
             msg.get("subject", ""), json.dumps(msg.get("data", {}))))
        db.commit(); db.close()
    except Exception:
        pass


def forward_outbound():
    """Check FleetBus for messages addressed to 'case' and push to VPS."""
    try:
        db = sqlite3.connect(str(LOCAL_DB))
        rows = db.execute(
            """SELECT * FROM agent_messages 
               WHERE target_agent='case' AND status='pending'
               ORDER BY created_at LIMIT 10"""
        ).fetchall()
        for row in rows:
            payload = json.loads(row[5]) if row[5] else {}
            push_to_vps({
                "type": row[2], "source": row[3],
                "subject": row[4], "data": payload
            })
            db.execute(
                "UPDATE agent_messages SET status='relayed' WHERE msg_id=?",
                (row[0],))
        db.commit(); db.close()
    except Exception:
        pass


def run_bridge():
    """Main bridge loop. Pulls from VPS, forwards outbound."""
    log.info(f"Case bridge starting. VPS: {VPS_BROKER or 'NONE'}")
    while True:
        try:
            msgs = pull_from_vps()
            for m in msgs:
                store_local(m)
            forward_outbound()
        except Exception as e:
            log.debug("Bridge cycle error: %s", e)
        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_bridge()
