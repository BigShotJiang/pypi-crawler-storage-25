"""OpenRouter text provider — single API key, 300+ models.

F-LUCY-OPENROUTER-PROVIDER (-8uh_KYt9F8, 2026-05-21). OpenRouter
(https://openrouter.ai) exposes an OpenAI-compatible Chat Completions
endpoint at https://openrouter.ai/api/v1/chat/completions that proxies
to Anthropic, Google Gemini, xAI Grok, Meta Llama, DeepSeek, OpenAI and
many others. One OPENROUTER_API_KEY unlocks the whole catalog, so we
implement OpenRouter as a single text provider whose ``model`` slug
picks the underlying backend (e.g. ``google/gemini-2.5-pro``,
``x-ai/grok-2``, ``anthropic/claude-sonnet-4-5``).

Wire format is OpenAI-compatible: use the ``openai`` SDK with
``base_url='https://openrouter.ai/api/v1'``. OpenRouter recommends
attribution headers (``HTTP-Referer`` + ``X-Title``) so requests are
attributed to our project in their leaderboard; non-fatal if omitted.

Streaming, tools, and the messages-array protocol all pass through
without translation since OpenRouter mirrors OpenAI's wire format.
"""
from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional

from aibrain.core.provider_contract import TextProvider


OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

# Sensible defaults: gemini-2.5-flash is fast + cheap + good for smoke
# tests. Callers should always pass an explicit model slug for
# production traffic — the slug picks the backend.
DEFAULT_MODEL_FOR_TASK_CLASS = {
    "cheap": "google/gemini-2.5-flash",
    "judgment": "google/gemini-2.5-pro",
    "review": "anthropic/claude-sonnet-4-5",
}

SUPPORTED_TASK_CLASSES = ["cheap", "judgment", "review"]


class OpenRouterProviderError(Exception):
    """Errors originating from the OpenRouter provider."""
    pass


def _resolve_model(config: Optional[Dict[str, Any]], task_class: str) -> str:
    if config and "model" in config:
        return config["model"]
    return DEFAULT_MODEL_FOR_TASK_CLASS.get(task_class, "google/gemini-2.5-flash")


def _get_api_key(config: Dict[str, Any]) -> Optional[str]:
    """Pull the OpenRouter key from config, env var, or return None.

    Returns None instead of raising so dispatch_chat() callers that pass
    api_key=... explicitly can construct the provider without an env var
    set. The actual call-site checks for None and raises if still missing.
    """
    env_var = config.get("api_key_env", "OPENROUTER_API_KEY")
    return config.get("api_key") or os.environ.get(env_var)


class OpenRouterTextProvider(TextProvider):
    """Concrete TextProvider for OpenRouter (proxy to 300+ models).

    Construction is tolerant: missing API key at __init__ is allowed (the
    error fires at chat_with_tools() / invoke() time) so dispatch_chat
    can hand the key in explicitly later.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        # Tolerate missing env var at construction time — dispatch_chat
        # callers may pass api_key=... explicitly. Concrete call sites
        # below re-check before any HTTP traffic fires.
        self.api_key: Optional[str] = _get_api_key(self.config)

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._invoke_sync, request)

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        task_class = request.get("task_class", "judgment")
        if task_class not in SUPPORTED_TASK_CLASSES:
            raise OpenRouterProviderError(
                f"Unsupported task class: {task_class}. "
                f"Supported: {SUPPORTED_TASK_CLASSES}"
            )

        model = _resolve_model(self.config, task_class)
        key = self.api_key or _get_api_key(self.config)
        if not key:
            raise OpenRouterProviderError(
                "No OpenRouter API key. Set OPENROUTER_API_KEY or pass "
                "api_key in provider config."
            )

        from openai import OpenAI

        client = OpenAI(
            api_key=key,
            base_url=OPENROUTER_BASE_URL,
            default_headers={
                "HTTP-Referer": "https://myaibrain.org",
                "X-Title": "aibrain/lucy",
            },
        )

        messages = []
        if request.get("system_prompt"):
            messages.append({"role": "system", "content": request["system_prompt"]})
        messages.append({"role": "user", "content": request.get("prompt", "")})

        t0 = time.monotonic()
        resp = client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=request.get("max_tokens", 4096),
            temperature=request.get("temperature", 0.7),
        )
        latency_ms = (time.monotonic() - t0) * 1000.0

        try:
            content = resp.choices[0].message.content or ""
            tokens_in = getattr(resp.usage, "prompt_tokens", 0) if resp.usage else 0
            tokens_out = getattr(resp.usage, "completion_tokens", 0) if resp.usage else 0
        except (AttributeError, IndexError) as exc:
            raise OpenRouterProviderError(
                f"Unexpected OpenRouter response shape: {resp!r}"
            ) from exc

        return {
            "content": content,
            "model_used": getattr(resp, "model", model) or model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "latency_ms": latency_ms,
        }

    # ------------------------------------------------------------------
    # Chat-with-tools dispatch surface
    # ------------------------------------------------------------------
    # F-LUCY-OPENROUTER-PROVIDER (-8uh_KYt9F8, 2026-05-21). OpenRouter
    # speaks OpenAI Chat Completions — pass-through messages + tools.
    # Streaming forwards the SDK iterator directly since OpenRouter's
    # chunks already match Lucy's _stream_wrapped() contract.

    def chat_with_tools(
        self,
        model: str,
        messages: list,
        tools: Optional[list] = None,
        tool_choice: Optional[Any] = None,
        api_key: Optional[str] = None,
        stream: bool = False,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **_extra: Any,
    ) -> Any:
        from openai import OpenAI  # local import — keep module import cheap
        from aibrain.core.provider_contract import (
            make_openai_shaped_response,
            make_tool_call,
        )
        key = (
            api_key
            or self.api_key
            or self.config.get("api_key")
            or os.environ.get("OPENROUTER_API_KEY")
        )
        if not key:
            raise OpenRouterProviderError(
                "No OpenRouter API key. Set OPENROUTER_API_KEY or pass "
                "api_key=... to chat_with_tools()."
            )
        # OpenRouter requires a model slug — default to gemini-flash when
        # the caller passed nothing (matches the task spec).
        model = model or "google/gemini-2.5-flash"
        client = OpenAI(
            api_key=key,
            base_url=OPENROUTER_BASE_URL,
            default_headers={
                "HTTP-Referer": "https://myaibrain.org",
                "X-Title": "aibrain/lucy",
            },
        )
        kwargs: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        if tools:
            kwargs["tools"] = tools
            if tool_choice is not None:
                kwargs["tool_choice"] = tool_choice
        resp = client.chat.completions.create(**kwargs)
        if stream:
            return resp  # SDK iterable already matches _stream_wrapped contract
        msg = resp.choices[0].message
        tcs = None
        if getattr(msg, "tool_calls", None):
            tcs = [
                make_tool_call(
                    call_id=tc.id,
                    name=tc.function.name,
                    arguments_json=tc.function.arguments or "{}",
                )
                for tc in msg.tool_calls
            ]
        return make_openai_shaped_response(
            content=msg.content or "",
            tool_calls=tcs,
            role=msg.role or "assistant",
            model=resp.model or model,
            finish_reason=resp.choices[0].finish_reason or "stop",
            usage={
                "prompt_tokens": getattr(resp.usage, "prompt_tokens", 0) if resp.usage else 0,
                "completion_tokens": getattr(resp.usage, "completion_tokens", 0) if resp.usage else 0,
                "total_tokens": getattr(resp.usage, "total_tokens", 0) if resp.usage else 0,
            },
        )


if __name__ == "__main__":
    # Smoke test: instantiation only — no network call.
    provider = OpenRouterTextProvider({})
    from aibrain.core.provider_contract import TextProvider as _TP
    assert isinstance(provider, _TP)
    print("provider_openrouter smoke test OK")
