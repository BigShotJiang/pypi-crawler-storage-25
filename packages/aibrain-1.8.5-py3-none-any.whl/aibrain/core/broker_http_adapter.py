"""broker_http_adapter.py -- HTTP-broker drop-in replacement for BrokerClient.

For deployments where nats-server is not yet running. Uses the existing
HTTP long-poll broker on BROKER_URL (port 8765). Same public surface as
BrokerClient from broker_nats.py — can be swapped in by changing one import.

F-LUCY-HTTP-BROKER-ADAPTER-FIX-1 (2026-05-15):
  Refactored to speak the actual broker.py protocol (POST /send, GET /recv).
  Previously used fictional /publish + /subscribe endpoints that didn't exist
  on the VPS broker — the adapter was never functional.  Now:

  publish(topic, payload) ->
    derive_recipient() from fleet.message.<name> pattern
    wrap {topic, payload} as JSON string in broker's "msg" field
    POST /send  {"from": agent_id, "msg": "<json>", "to": recipient}

  subscribe(topic_glob, handler) ->
    register (topic_glob, handler) pair
    single shared daemon thread long-polls GET /recv?for=<agent_id>
    parses inner msg JSON, fnmatch topic against all registered globs
    invokes matching handlers with the payload dict (CloudEvent data)

  agent_id added as optional constructor param (defaults to AGENT_ID env).
  _derive_recipient() maps topics to broker queue names.
  get_broker_client() passes agent_id through.

F-LUCY-HTTP-BROKER-ADAPTER-1 (2026-05-16):
  - Added BrokerAuthMissing exception for missing LUCY_BROKER_TOKEN
  - Token priority: LUCY_BROKER_TOKEN > BROKER_TOKEN > ~/.decker_env
  - Async publish/recv/subscribe methods for direct broker use
  - Long-poll wait parameter (?wait=30) support on GET /recv
"""

from __future__ import annotations
import asyncio as _asyncio
import fnmatch as _fnmatch
import json
import logging
import os as _os
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

logger = logging.getLogger("aibrain.broker_http")


class BrokerAuthMissing(Exception):
    """Raised when LUCY_BROKER_TOKEN is not set and no fallback token is found."""
    pass


def _load_token(raise_if_missing: bool = False) -> str:
    """Load broker auth token.

    Priority: LUCY_BROKER_TOKEN > BROKER_TOKEN > ~/.decker_env > ~/.aibrain_env.
    If raise_if_missing is True and no token is found, raises BrokerAuthMissing.
    """
    # Primary: LUCY_BROKER_TOKEN (F-LUCY-HTTP-BROKER-ADAPTER-1)
    token = _os.environ.get("LUCY_BROKER_TOKEN", "")
    if token:
        return token
    # Fallback: BROKER_TOKEN (legacy)
    token = _os.environ.get("BROKER_TOKEN", "")
    if token:
        return token
    # File-based fallbacks
    for env_file in (Path.home() / ".decker_env", Path.home() / ".aibrain_env"):
        if env_file.exists():
            try:
                for line in env_file.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    # Check both LUCY_BROKER_TOKEN and BROKER_TOKEN in env files
                    if line.startswith("LUCY_BROKER_TOKEN="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
                    if line.startswith("BROKER_TOKEN="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
            except Exception:
                pass
    if raise_if_missing:
        raise BrokerAuthMissing(
            "LUCY_BROKER_TOKEN not set. Set it in environment or ~/.decker_env. "
            "The HTTP broker requires authentication — refusing to connect without a token."
        )
    return ""


def _derive_recipient(topic: str) -> str:
    """Extract recipient queue from a FleetBus topic for broker.py routing.

    fleet.message.<name>       -> <name>           (direct message)
    fleet.message.<name>.<...> -> <name>           (first name after fleet.message.)
    fleet.direct.<name>        -> <name>           (alias for fleet.message.<name>)
    direct.<name>              -> <name>           (legacy alias)
    fleet.test.<name>          -> <name>           (test directed at <name>)
    fleet.operator.<name>      -> <name>           (operator poke directed at <name>)
    fleet.heartbeat.<anything> -> all              (heartbeats are fleet-wide)
    fleet.broadcast.<anything> -> all              (broadcasts are fleet-wide)
    fleet.status.<anything>    -> all              (status pings are fleet-wide)
    fleet.liaison.* / other    -> all

    Changed 2026-05-13: fleet.heartbeat.<agent>/fleet.status.<agent> used
    to route to <agent>'s own queue, which made heartbeats invisible to
    every other agent. Now they fan to 'all', which is what the original
    intent appears to have been per the May-12 broker history pattern.
    """
    parts = topic.split(".")

    # Fleet-wide topics — heartbeat/status/broadcast must reach every agent
    if len(parts) >= 2 and parts[0] == "fleet" and parts[1] in (
        "heartbeat", "broadcast", "status",
    ):
        return "all"

    # Directed topics — extract the agent name from the third segment
    if len(parts) >= 3 and parts[0] == "fleet" and parts[1] in (
        "message", "direct", "test", "operator",
    ):
        return parts[2]
    if len(parts) >= 2 and parts[0] == "direct":
        return parts[1]

    return "all"


class HTTPBrokerClient:
    """Drop-in HTTP-broker replacement for BrokerClient (broker_nats.BrokerClient).

    Uses the port-8765 HTTP long-poll broker. Same public surface so
    FleetBus can swap transports without code changes.

    Single shared poll loop per instance -- all topic subscriptions
    dispatch through one long-poll thread. Handlers are fnmatch-matched
    against the topic embedded in each incoming message.
    """

    def __init__(
        self,
        url: str | None = None,
        subject_prefix: str = "",
        agent_id: str | None = None,
    ):
        self._url = (url or _os.environ.get("BROKER_URL") or "").rstrip("/")
        if not self._url:
            raise RuntimeError("BROKER_URL not set and no url= override given")
        self._prefix = subject_prefix
        self._token = _load_token()
        self._agent_id = agent_id or _os.environ.get(
            "AGENT_ID", _os.environ.get("AI_NAME", "lucy")
        )
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._handlers: list[tuple[str, Callable[[dict], None]]] = []
        self._poll_thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Public surface (matches BrokerClient)
    # ------------------------------------------------------------------

    def _full_subject(self, subject: str) -> str:
        if self._prefix and not subject.startswith(self._prefix):
            return f"{self._prefix}.{subject}"
        return subject

    def publish(self, subject: str, payload: dict) -> None:
        """POST /send -- wrap {topic, payload} as JSON in broker's "msg" field.

        broker.py expects: {"from": "<sender>", "msg": "<json>", "to": "<recipient>"}
        The msg JSON is the wire format: {"topic": full_subject, "payload": cloud_event_dict}

        Sender is `self._agent_id` — the VPS broker accepts unknown senders
        as of v1.8.0 (only token is the gate), so the legacy from="local"
        hardcode that mis-attributed every message has been removed.
        """
        full_subject = self._full_subject(subject)
        recipient = _derive_recipient(full_subject)
        msg_body = json.dumps({"topic": full_subject, "payload": payload})
        body = json.dumps({
            "from": self._agent_id,
            "msg": msg_body,
            "to": recipient,
        }).encode("utf-8")

        req = urllib.request.Request(
            f"{self._url}/send",
            data=body,
            headers={
                "X-Token": self._token,
                "Content-Type": "application/json; charset=utf-8",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                logger.debug(
                    "HTTPBrokerClient: published %s -> %s (status=%s)",
                    full_subject, recipient, resp.status,
                )
        except urllib.error.HTTPError as e:
            # F-LUCY-HTTP-BROKER-ADAPTER-FIX-2: read error body for diagnostics
            _err_body = ""
            try:
                _err_body = e.read().decode("utf-8", errors="replace")[:500]
            except Exception:
                pass
            logger.warning(
                "HTTPBrokerClient: publish %s -> HTTPError %s body=%s",
                full_subject, e.code, _err_body,
            )
        except Exception as e:
            logger.warning("HTTPBrokerClient: publish %s -> %s", full_subject, e)

    def subscribe(self, subject: str, handler: Callable[[dict], None]) -> None:
        """Register handler for topic glob. Starts shared poll loop if idle.

        handler receives the raw payload dict (CloudEvent.to_dict() data)
        parsed from the broker's inner msg JSON.
        """
        full_subject = self._full_subject(subject)
        with self._lock:
            self._handlers.append((full_subject, handler))
            logger.info(
                "HTTPBrokerClient: subscribed to %s (agent=%s, handlers=%d)",
                full_subject, self._agent_id, len(self._handlers),
            )
        self._ensure_polling()

    # ------------------------------------------------------------------
    # Async API — F-LUCY-HTTP-BROKER-ADAPTER-1
    # Direct broker protocol: POST /send, GET /recv?queue=<name>
    # ------------------------------------------------------------------

    async def async_publish(
        self, *, to: str, msg: "str | dict", from_: str | None = None
    ) -> dict:
        """Async publish a message directly to a broker queue.

        POST /send  {"from": from_, "to": to, "msg": <str|json>}
        Returns the broker's JSON response dict.
        Raises BrokerAuthMissing if no token is configured.

        Default sender is self._agent_id (v1.8.0 broker accepts the
        relaxed VALID_SENDERS list).
        """
        sender = from_ or self._agent_id
        token = _load_token(raise_if_missing=True)
        msg_str = json.dumps(msg) if isinstance(msg, dict) else msg
        body = json.dumps({
            "from": sender,
            "to": to,
            "msg": msg_str,
        }).encode("utf-8")

        loop = _asyncio.get_running_loop()

        def _sync_send():
            req = urllib.request.Request(
                f"{self._url}/send",
                data=body,
                headers={
                    "X-Token": token,
                    "Content-Type": "application/json; charset=utf-8",
                },
                method="POST",
            )
            try:
                with urllib.request.urlopen(req, timeout=5) as resp:
                    raw = resp.read().decode("utf-8")
                    return json.loads(raw) if raw else {"status": "ok"}
            except urllib.error.HTTPError as e:
                _err_body = ""
                try:
                    _err_body = e.read().decode("utf-8", errors="replace")[:500]
                except Exception:
                    pass
                logger.warning(
                    "HTTPBrokerClient: async_publish %s -> %s HTTPError %s body=%s",
                    sender, to, e.code, _err_body,
                )
                return {"status": "error", "code": e.code, "error": str(e), "body": _err_body}

        return await loop.run_in_executor(None, _sync_send)

    async def async_recv(
        self, *, queue: str, timeout: float = 30.0
    ) -> "dict | None":
        """Async long-poll for a message on a queue.

        GET /recv?queue=<queue>&wait=<timeout>
        Returns the message dict, or None on timeout / empty.
        Raises BrokerAuthMissing if no token is configured.
        """
        token = _load_token(raise_if_missing=True)
        wait_s = min(int(timeout), 60)  # cap long-poll at 60s
        url = f"{self._url}/recv?queue={queue}&wait={wait_s}"

        loop = _asyncio.get_running_loop()

        def _sync_recv():
            req = urllib.request.Request(
                url, headers={"X-Token": token}
            )
            try:
                with urllib.request.urlopen(req, timeout=timeout + 5) as resp:
                    if resp.status == 204:
                        return None
                    raw = resp.read().decode("utf-8")
                    return json.loads(raw) if raw else None
            except urllib.error.HTTPError as e:
                if e.code == 408 or e.code == 204:
                    return None  # timeout / empty — normal
                logger.warning(
                    "HTTPBrokerClient: async_recv queue=%s HTTPError %s",
                    queue, e.code,
                )
                return None
            except Exception:
                logger.debug(
                    "HTTPBrokerClient: async_recv queue=%s exception", queue,
                    exc_info=True,
                )
                return None

        return await loop.run_in_executor(None, _sync_recv)

    async def async_subscribe(
        self,
        *,
        queue: str,
        callback: Callable[[dict], Awaitable[None]],
        poll_interval: float = 1.0,
    ) -> None:
        """Async subscribe to a broker queue. Runs until cancelled.

        Long-polls GET /recv?queue=<queue> at poll_interval.
        Calls await callback(msg_dict) for each received message.
        Does not return — must be cancelled or run as a background task.

        Usage:
            asyncio.create_task(client.async_subscribe(
                queue="lucy_inbox",
                callback=my_handler,
            ))
        """
        token = _load_token(raise_if_missing=True)
        logger.info(
            "HTTPBrokerClient: async_subscribe queue=%s (agent=%s)",
            queue, self._agent_id,
        )

        while True:
            try:
                wait_s = min(int(poll_interval * 30), 60)
                url = f"{self._url}/recv?queue={queue}&wait={wait_s}"
                req = urllib.request.Request(url, headers={"X-Token": token})

                loop = _asyncio.get_running_loop()

                def _sync_poll():
                    try:
                        with urllib.request.urlopen(req, timeout=35) as resp:
                            if resp.status == 204:
                                return None
                            raw = resp.read().decode("utf-8")
                            return json.loads(raw) if raw else None
                    except urllib.error.HTTPError as e:
                        if e.code in (408, 204):
                            return None
                        raise
                    except Exception:
                        return None

                msg = await loop.run_in_executor(None, _sync_poll)

                if msg is not None:
                    try:
                        await callback(msg)
                    except Exception:
                        logger.exception(
                            "HTTPBrokerClient: async_subscribe callback raised "
                            "queue=%s", queue,
                        )

            except _asyncio.CancelledError:
                logger.info(
                    "HTTPBrokerClient: async_subscribe cancelled queue=%s", queue
                )
                raise
            except Exception:
                logger.debug(
                    "HTTPBrokerClient: async_subscribe poll error queue=%s",
                    queue, exc_info=True,
                )

            await _asyncio.sleep(poll_interval)

    def close(self) -> None:
        """Signal poll loop to stop."""
        self._stop_event.set()
        logger.info(
            "HTTPBrokerClient: close signalled (agent=%s, handlers=%d)",
            self._agent_id, len(self._handlers),
        )

    # ------------------------------------------------------------------
    # Internal -- shared long-poll loop
    # ------------------------------------------------------------------

    def _ensure_polling(self) -> None:
        """Start shared poll thread if not already running."""
        with self._lock:
            if self._poll_thread is not None and self._poll_thread.is_alive():
                return
            self._poll_thread = threading.Thread(
                target=self._poll_loop,
                daemon=True,
                name=f"http-broker-poll:{self._agent_id}",
            )
            self._poll_thread.start()
            logger.info(
                "HTTPBrokerClient: poll loop started (agent=%s)", self._agent_id
            )

    def close(self, timeout: float = 2.0) -> None:
        """Cleanly stop the long-poll thread.

        Signals the thread to exit via _stop_event, then waits up to
        `timeout` seconds for it to join. The thread MAY still be blocked
        inside a /recv long-poll for up to ~35s (urllib.request.urlopen
        timeout); it's a daemon thread so the process can still exit, but
        the recv socket holds a tiny amount of resource until the broker
        sends 204 or the timeout fires.

        Calling close() twice is safe.
        """
        self._stop_event.set()
        thread = self._poll_thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout)
        with self._lock:
            self._handlers.clear()

    def _extract_topic_payload(self, envelope: dict) -> tuple[str, dict]:
        """Pull (topic, payload) from a broker `/recv` envelope.

        Returns ("", {}) if the envelope can't yield a topic.

        Two cases:

        1. Inner msg is a JSON object with {"topic": ..., "payload": ...} —
           FleetBus path. Unwrap directly.

        2. Inner msg is anything else (raw text, malformed JSON, scalar) —
           operator poke path. Synthesize a CloudEvent-shaped delivery so
           the message reaches `fleet.operator.<recipient>` handlers
           instead of being silently dropped.
        """
        raw_msg = envelope.get("msg", "")
        sender = envelope.get("from") or "unknown"
        recipient = envelope.get("to") or self._agent_id

        # Case 1: structured CloudEvent envelope
        if isinstance(raw_msg, dict):
            topic = raw_msg.get("topic", "")
            payload = raw_msg.get("payload", {})
            if topic:
                return topic, payload

        if isinstance(raw_msg, str):
            stripped = raw_msg.strip()
            if stripped.startswith("{"):
                try:
                    inner = json.loads(stripped)
                except (json.JSONDecodeError, TypeError):
                    inner = None
                if isinstance(inner, dict):
                    topic = inner.get("topic", "")
                    if topic:
                        return topic, inner.get("payload", {})

        # Case 2: raw operator poke — synthesize a fleet.operator delivery
        synthetic_topic = f"fleet.operator.{recipient}"
        synthetic_payload = {
            "specversion": "1.0",
            "id": f"operator-{int(time.time() * 1000)}",
            "source": f"agent://operator/{sender}",
            "type": synthetic_topic,
            "subject": synthetic_topic,
            "time": envelope.get("ts", ""),
            "datacontenttype": "application/json",
            "data": {
                "text": raw_msg if isinstance(raw_msg, str) else json.dumps(raw_msg),
                "from": sender,
                "to": recipient,
                "operator_poke": True,
            },
        }
        return synthetic_topic, synthetic_payload

    def _poll_loop(self) -> None:
        """Single long-poll loop. GET /recv?for=<agent_id>, dispatch to handlers.

        broker.py returns one message envelope per poll:
          {"from": "...", "to": "...", "msg": "<string>", "ts": "..."}

        The "msg" field has two valid shapes:

        1. CloudEvent-wrapped (the FleetBus path):
             {"topic": "fleet.message.lucy", "payload": {<CloudEvent dict>}}
           We unwrap topic + payload and fnmatch the topic.

        2. Raw operator poke (curl --data, etc.):
             "free-form text the operator wants to send"
           We synthesize a fleet.operator.<recipient> CloudEvent so the
           message becomes first-class instead of being silently dropped.

        Both paths produce a (topic, payload) tuple and dispatch through
        the fnmatch handler registry.
        """
        while not self._stop_event.is_set():
            try:
                url = f"{self._url}/recv?for={self._agent_id}"
                req = urllib.request.Request(
                    url, headers={"X-Token": self._token}
                )
                with urllib.request.urlopen(req, timeout=35) as resp:
                    body = resp.read().decode("utf-8")
                    if not body.strip():
                        # 204 No Content -> no messages, poll again
                        continue

                    try:
                        envelope = json.loads(body)
                    except json.JSONDecodeError:
                        logger.debug(
                            "HTTPBrokerClient: malformed JSON from /recv: %s",
                            body[:200],
                        )
                        continue

                    topic, payload = self._extract_topic_payload(envelope)
                    if not topic:
                        logger.debug("HTTPBrokerClient: message missing topic")
                        continue

                    # Dispatch to matching handlers
                    with self._lock:
                        handlers_snapshot = list(self._handlers)

                    dispatched = 0
                    for glob, handler in handlers_snapshot:
                        if _fnmatch.fnmatch(topic, glob):
                            try:
                                handler(payload)
                                dispatched += 1
                            except Exception:
                                logger.exception(
                                    "HTTPBrokerClient: handler raised topic=%s glob=%s",
                                    topic, glob,
                                )

                    if dispatched == 0:
                        logger.debug(
                            "HTTPBrokerClient: no handler matched topic=%s "
                            "(agent=%s, handlers=%d)",
                            topic, self._agent_id, len(handlers_snapshot),
                        )

            except urllib.error.HTTPError as e:
                if self._stop_event.is_set():
                    break
                if e.code == 408:
                    continue  # long-poll timeout -- normal
                logger.warning(
                    "HTTPBrokerClient: poll HTTPError %s (agent=%s)",
                    e.code, self._agent_id,
                )
                self._stop_event.wait(2)
            except Exception:
                if self._stop_event.is_set():
                    break
                logger.debug(
                    "HTTPBrokerClient: poll exception (retry 2s, agent=%s)",
                    self._agent_id,
                    exc_info=True,
                )
                self._stop_event.wait(2)

        logger.info(
            "HTTPBrokerClient: poll loop exited (agent=%s)", self._agent_id
        )

    def close(self, timeout: float = 2.0) -> None:
        """Stop the poll thread and clear handlers. Idempotent.

        Without this, FleetBus instances and their underlying poll threads
        leak across tests and across re-instantiations in long-running
        processes (each subscriber start would add another poll thread).

        Args:
            timeout: seconds to wait for the poll thread to exit.
                     Long-poll uses a 35s read; if the broker is
                     responsive a 204 returns immediately and the loop
                     re-checks stop_event. If the broker is dead, the
                     join will time out — we proceed anyway since the
                     thread is daemon=True.
        """
        self._stop_event.set()
        thread = None
        with self._lock:
            thread = self._poll_thread
            self._poll_thread = None
            self._handlers.clear()
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout)
            if thread.is_alive():
                logger.warning(
                    "HTTPBrokerClient: poll thread did not exit within %.1fs "
                    "(agent=%s) — leaving as daemon",
                    timeout, self._agent_id,
                )


def get_broker_client(
    transport: str = "nats",
    url: Optional[str] = None,
    subject_prefix: str = "",
    agent_id: Optional[str] = None,
):
    """Factory: return HTTPBrokerClient or nats-py BrokerClient based on transport.

    transport="http" -> HTTPBrokerClient (this module)
    transport="nats" (default) -> aibrain.core.broker_nats.BrokerClient
    """
    if transport == "http":
        return HTTPBrokerClient(
            url=url, subject_prefix=subject_prefix, agent_id=agent_id
        )
    elif transport == "nats":
        from aibrain.core.broker_nats import BrokerClient

        return BrokerClient(url=url, subject_prefix=subject_prefix)
    else:
        raise ValueError(
            f"Unknown transport: {transport}. Use 'http' or 'nats'."
        )


if __name__ == "__main__":
    # Smoke test: instantiate without making actual HTTP calls
    import os as _os2
    _os2.environ.setdefault("BROKER_URL", "http://localhost:8765")
    _os2.environ.setdefault("BROKER_TOKEN", "test")
    client = HTTPBrokerClient(agent_id="lucy")
    print("HTTPBrokerClient constructed: url=", client._url)
    print("agent_id=", client._agent_id)
    client.close()
    print("broker_http_adapter smoke test OK")
