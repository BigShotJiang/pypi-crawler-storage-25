"""
Cooperative cancel flag for graceful interrupt (Ctrl+B).

F-LUCY-CTRL-B-INTERRUPT-1: Pressing Ctrl+B in lucy_agent.py sets a
cooperative cancel flag. The current dispatch / complete_task / tool-call
loop checks the flag between steps and returns to the prompt cleanly,
preserving session state (memory, working dir, dispatch counters,
artifact store).

Importable from anywhere in aibrain.* so dispatch / complete_task / tool
runners all see the same flag.
"""

import threading

_CANCELLED = threading.Event()

# Public API


def request_cancel() -> None:
    """Set the cancel flag. Non-blocking — returns immediately."""
    _CANCELLED.set()


def is_cancelled() -> bool:
    """Check whether cancellation has been requested."""
    return _CANCELLED.is_set()


def clear() -> None:
    """Reset the cancel flag for the next prompt cycle."""
    _CANCELLED.clear()


class CancelledError(Exception):
    """Raised when the cooperative cancel flag is set."""

    pass


def check_and_raise() -> None:
    """If the cancel flag is set, clear it and raise CancelledError.

    Call this at every natural step boundary in Lucy's control loop.
    The caller is expected to catch CancelledError and return to the
    prompt gracefully without losing session state.
    """
    if _CANCELLED.is_set():
        _CANCELLED.clear()
        raise CancelledError("Interrupt requested (Ctrl+B) — returning to prompt")


# ---------------------------------------------------------------------------
# Smoke test (run with: python -m aibrain.core.cancel_flag)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # --- set + check + clear + check ---
    assert not is_cancelled(), "flag should start unset"

    request_cancel()
    assert is_cancelled(), "flag should be set after request_cancel()"

    # check_and_raise should raise CancelledError and clear the flag
    try:
        check_and_raise()
        raise AssertionError("check_and_raise should have raised CancelledError")
    except CancelledError:
        pass  # expected

    assert not is_cancelled(), "flag should be cleared after check_and_raise raised"

    # clear() is idempotent
    clear()
    assert not is_cancelled(), "clear on already-cleared flag should be safe"

    # check_and_raise when not set is a no-op
    try:
        check_and_raise()  # should not raise
    except CancelledError:
        raise AssertionError("check_and_raise should not raise when flag is clear")

    print("cancel_flag smoke test OK")
