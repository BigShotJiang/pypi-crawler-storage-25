"""
Anthropic provider implementation for AIBrain.

Implements TextProvider and ReviewProvider contracts defined in
aibrain.core.provider_contract using the Anthropic Messages API
(version 2023-06-01) via urllib. No external Anthropic SDK required.
"""

import json
import logging
import os
import time
import urllib.request
import urllib.error
import asyncio
from typing import Any, Dict, Optional

from aibrain.core.provider_contract import TextProvider, ReviewProvider

logger = logging.getLogger("aibrain.provider_anthropic")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"

# Model IDs as of 2026-05-12
MODEL_HAIKU = "claude-haiku-4-5"
MODEL_SONNET = "claude-sonnet-4-6"
MODEL_OPUS = "claude-opus-4-7"

DEFAULT_MODEL_FOR_TASK_CLASS: Dict[str, str] = {
    "cheap": MODEL_HAIKU,
    "judgment": MODEL_SONNET,
    "review": MODEL_OPUS,
}

SUPPORTED_TASK_CLASSES = list(DEFAULT_MODEL_FOR_TASK_CLASS.keys())

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class AnthropicProviderError(Exception):
    """Raised when the Anthropic provider encounters an error."""

    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_api_key(config: Dict[str, Any]) -> str:
    """Extract the Anthropic API key from config or environment."""
    api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise AnthropicProviderError(
            "Anthropic API key not found in config or ANTHROPIC_API_KEY env var"
        )
    return api_key


def _resolve_model(config: Dict[str, Any], task_class: str) -> str:
    """Determine which model to use for a given task class."""
    model = config.get("model")
    if model:
        return model
    if task_class not in DEFAULT_MODEL_FOR_TASK_CLASS:
        raise AnthropicProviderError(
            f"Unsupported task_class '{task_class}'. "
            f"Supported: {SUPPORTED_TASK_CLASSES}"
        )
    return DEFAULT_MODEL_FOR_TASK_CLASS[task_class]


def _call_anthropic_http(
    api_key: str,
    model: str,
    system_prompt: str,
    user_content: str,
    max_tokens: int,
    temperature: float,
) -> Dict[str, Any]:
    """Synchronous HTTP call to the Anthropic Messages API.

    Returns a dict with keys: content, tokens_in, tokens_out, model_used, latency_ms.
    """
    headers = {
        "x-api-key": api_key,
        "anthropic-version": ANTHROPIC_VERSION,
        "content-type": "application/json",
    }

    body = {
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_content}],
    }

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(ANTHROPIC_API_URL, data=data, headers=headers, method="POST")

    start = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            raw = resp.read().decode("utf-8")
            elapsed_ms = (time.monotonic() - start) * 1000.0
    except urllib.error.HTTPError as exc:
        err_body = exc.read().decode("utf-8", errors="replace")
        raise AnthropicProviderError(
            f"Anthropic HTTP {exc.code}: {err_body}"
        ) from exc
    except Exception as exc:
        raise AnthropicProviderError(f"Anthropic request failed: {exc}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise AnthropicProviderError(f"Invalid JSON from Anthropic: {raw[:200]}") from exc

    # Extract text from content blocks
    content_blocks = payload.get("content", [])
    text_parts = []
    for block in content_blocks:
        if block.get("type") == "text":
            text_parts.append(block.get("text", ""))
    content = "\n".join(text_parts)

    usage = payload.get("usage", {})
    tokens_in = usage.get("input_tokens", 0)
    tokens_out = usage.get("output_tokens", 0)
    model_used = payload.get("model", model)

    return {
        "content": content,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "model_used": model_used,
        "latency_ms": round(elapsed_ms, 2),
    }


def _iter_anthropic_sse(response, model: str):
    """Generator that parses Anthropic SSE stream events and yields
    OpenAI-shaped chunks (SimpleNamespace with .choices[0].delta.content).

    Parameters
    ----------
    response : http.client.HTTPResponse
        An open urllib response from the Anthropic streaming endpoint.
    model : str
        Fallback model name if message_start is not received.

    Yields
    ------
    SimpleNamespace
        Chunks shaped like OpenAI streaming chunks:
        - Text delta chunks: .choices[0].delta.content = "token text"
        - Final chunk: .choices[0].finish_reason = "stop" (or tool_calls),
          .usage = SimpleNamespace(prompt_tokens, completion_tokens, total_tokens)
    """
    from types import SimpleNamespace

    current_event: Optional[str] = None
    input_tokens = 0
    output_tokens = 0
    model_used = model
    stop_reason = "stop"
    # Accumulate tool_use partial_json per block index (not yielded as text)
    tool_json_accum: Dict[int, str] = {}

    for line_bytes in response:
        line = line_bytes.decode("utf-8", errors="replace")
        # Strip trailing \r and \n
        line = line.rstrip("\r\n")

        # Skip blank lines (event delimiters)
        if not line:
            current_event = None
            continue

        # Skip SSE comments
        if line.startswith(":"):
            continue

        # Track event name
        if line.startswith("event: "):
            current_event = line[7:].strip()
            continue

        # Parse data lines
        if line.startswith("data: "):
            data_str = line[6:]
            try:
                data = json.loads(data_str)
            except json.JSONDecodeError:
                logger.warning("Anthropic SSE: invalid JSON data line: %s", data_str[:120])
                continue

            event_type = data.get("type", "")

            # message_start — capture model and input tokens
            if event_type == "message_start":
                msg = data.get("message", {})
                model_used = msg.get("model", model_used)
                usage = msg.get("usage", {})
                input_tokens = usage.get("input_tokens", 0)
                output_tokens = usage.get("output_tokens", 0)

            # content_block_start — track block index for tool_use
            elif event_type == "content_block_start":
                block = data.get("content_block", {})
                idx = data.get("index", 0)
                if block.get("type") == "tool_use":
                    tool_json_accum[idx] = ""

            # content_block_delta — yield text deltas, accumulate tool JSON
            elif event_type == "content_block_delta":
                delta = data.get("delta", {})
                delta_type = delta.get("type", "")
                idx = data.get("index", 0)

                if delta_type == "text_delta":
                    yield SimpleNamespace(
                        choices=[SimpleNamespace(
                            delta=SimpleNamespace(content=delta.get("text", "")),
                            finish_reason=None,
                            index=0,
                        )],
                        model=model_used,
                    )
                elif delta_type == "input_json_delta":
                    tool_json_accum[idx] = tool_json_accum.get(idx, "") + delta.get("partial_json", "")

            # content_block_stop — no action needed
            elif event_type == "content_block_stop":
                pass

            # message_delta — capture stop_reason and output_tokens
            elif event_type == "message_delta":
                delta = data.get("delta", {})
                stop_reason = delta.get("stop_reason", stop_reason)
                usage = data.get("usage", {})
                output_tokens = usage.get("output_tokens", output_tokens)

            # message_stop — yield final chunk and return
            elif event_type == "message_stop":
                yield SimpleNamespace(
                    choices=[SimpleNamespace(
                        delta=SimpleNamespace(content=""),
                        finish_reason=stop_reason,
                        index=0,
                    )],
                    model=model_used,
                    usage=SimpleNamespace(
                        prompt_tokens=input_tokens,
                        completion_tokens=output_tokens,
                        total_tokens=input_tokens + output_tokens,
                    ),
                )
                return


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------


class AnthropicTextProvider(TextProvider):
    """Concrete TextProvider backed by Anthropic."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke the Anthropic text completion API asynchronously."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "cheap")
        model = _resolve_model(config, task_class)

        system_prompt = request.get("system_prompt", "")
        prompt = request.get("prompt", "")
        max_tokens = request.get("max_tokens", 1024)
        temperature = request.get("temperature", 0.7)

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_anthropic_http,
            api_key,
            model,
            system_prompt,
            prompt,
            max_tokens,
            temperature,
        )

        return {
            "content": result["content"],
            "tokens_in": result["tokens_in"],
            "tokens_out": result["tokens_out"],
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous wrapper for environments without an event loop."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "cheap")
        model = _resolve_model(config, task_class)

        system_prompt = request.get("system_prompt", "")
        prompt = request.get("prompt", "")
        max_tokens = request.get("max_tokens", 1024)
        temperature = request.get("temperature", 0.7)

        result = _call_anthropic_http(
            api_key, model, system_prompt, prompt, max_tokens, temperature
        )

        return {
            "content": result["content"],
            "tokens_in": result["tokens_in"],
            "tokens_out": result["tokens_out"],
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    # ------------------------------------------------------------------
    # Chat-with-tools dispatch surface
    # ------------------------------------------------------------------
    # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21).
    # Anthropic uses /v1/messages with a different message shape than
    # OpenAI: system is a top-level field, tool results are content
    # blocks of type=tool_result inside a user message, and tool calls
    # come back as content blocks of type=tool_use inside the assistant
    # message. This method translates OpenAI-shaped messages/tools to
    # Anthropic format on the way in, and the response back to
    # OpenAI-shaped on the way out so Lucy's chat loop is unchanged.

    def chat_with_tools(
        self,
        model: str,
        messages: list,
        tools: Optional[list] = None,
        tool_choice: Optional[Any] = None,
        api_key: Optional[str] = None,
        stream: bool = False,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **_extra: Any,
    ) -> Any:
        from aibrain.core.provider_contract import (
            make_openai_shaped_response,
            make_tool_call,
            _stream_response_from_text,
        )
        key = api_key or self.config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise AnthropicProviderError(
                "No Anthropic API key. Set ANTHROPIC_API_KEY or pass api_key=..."
            )

        # 1) Pull system message(s) out — Anthropic wants them top-level.
        system_parts: list[str] = []
        anthropic_msgs: list[Dict[str, Any]] = []
        for m in messages:
            role = m.get("role", "user")
            content = m.get("content")
            if role == "system":
                if isinstance(content, str) and content:
                    system_parts.append(content)
                continue
            if role == "tool":
                # OpenAI 'tool' message -> Anthropic user message containing
                # a tool_result block keyed by tool_use_id.
                anthropic_msgs.append({
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": m.get("tool_call_id", ""),
                        "content": str(content) if content is not None else "",
                    }],
                })
                continue
            if role == "assistant":
                # Assistant may have content + tool_calls (OpenAI shape).
                blocks: list[Dict[str, Any]] = []
                if isinstance(content, str) and content:
                    blocks.append({"type": "text", "text": content})
                tcs = m.get("tool_calls") or []
                for tc in tcs:
                    fn = tc.get("function", {})
                    raw_args = fn.get("arguments", "{}") or "{}"
                    try:
                        parsed_args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                    except json.JSONDecodeError:
                        parsed_args = {}
                    blocks.append({
                        "type": "tool_use",
                        "id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "input": parsed_args or {},
                    })
                if not blocks:
                    blocks = [{"type": "text", "text": ""}]
                anthropic_msgs.append({"role": "assistant", "content": blocks})
                continue
            # role == 'user' (or anything else)
            if isinstance(content, list):
                anthropic_msgs.append({"role": "user", "content": content})
            else:
                anthropic_msgs.append({
                    "role": "user",
                    "content": str(content) if content is not None else "",
                })

        system_text = "\n\n".join(p for p in system_parts if p)

        # 2) Translate OpenAI tool schemas to Anthropic schemas.
        anthropic_tools: list[Dict[str, Any]] = []
        if tools:
            for t in tools:
                fn = t.get("function", {})
                anthropic_tools.append({
                    "name": fn.get("name", ""),
                    "description": fn.get("description", ""),
                    "input_schema": fn.get("parameters") or {"type": "object", "properties": {}},
                })

        body: Dict[str, Any] = {
            "model": model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": anthropic_msgs,
        }
        if system_text:
            body["system"] = system_text
        if anthropic_tools:
            body["tools"] = anthropic_tools
            # tool_choice: 'auto' / None / dict — map to Anthropic shape.
            if tool_choice in (None, "auto"):
                body["tool_choice"] = {"type": "auto"}
            elif isinstance(tool_choice, dict) and tool_choice.get("type") == "function":
                body["tool_choice"] = {
                    "type": "tool",
                    "name": tool_choice.get("function", {}).get("name", ""),
                }

        # 3) POST to Anthropic Messages API.
        headers = {
            "x-api-key": key,
            "anthropic-version": ANTHROPIC_VERSION,
            "content-type": "application/json",
        }

        # --- Stream branch ---
        if stream:
            body["stream"] = True
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(ANTHROPIC_API_URL, data=data, headers=headers, method="POST")

            def _stream_generator():
                try:
                    with urllib.request.urlopen(req, timeout=300) as resp:
                        yield from _iter_anthropic_sse(resp, model)
                except urllib.error.HTTPError as exc:
                    err_body = exc.read().decode("utf-8", errors="replace")
                    raise AnthropicProviderError(
                        f"Anthropic HTTP {exc.code}: {err_body}"
                    ) from exc
                except Exception as exc:
                    raise AnthropicProviderError(f"Anthropic stream request failed: {exc}") from exc

            return _stream_generator()

        # --- Non-stream branch (unchanged) ---
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(ANTHROPIC_API_URL, data=data, headers=headers, method="POST")
        start = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=180) as resp_http:
                raw = resp_http.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            raise AnthropicProviderError(
                f"Anthropic HTTP {exc.code}: {err_body}"
            ) from exc
        except Exception as exc:
            raise AnthropicProviderError(f"Anthropic chat request failed: {exc}") from exc

        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise AnthropicProviderError(
                f"Invalid JSON from Anthropic: {raw[:300]}"
            ) from exc
        latency_ms = round((time.monotonic() - start) * 1000.0, 2)

        # 4) Translate Anthropic content blocks -> OpenAI text+tool_calls.
        text_parts: list[str] = []
        tool_calls = []
        for block in payload.get("content", []):
            btype = block.get("type", "")
            if btype == "text":
                text_parts.append(block.get("text", ""))
            elif btype == "tool_use":
                tool_calls.append(make_tool_call(
                    call_id=block.get("id", ""),
                    name=block.get("name", ""),
                    arguments_json=json.dumps(block.get("input") or {}),
                ))

        content = "\n".join(p for p in text_parts if p)
        usage = payload.get("usage", {})
        model_used = payload.get("model", model)
        stop_reason = payload.get("stop_reason", "end_turn")
        finish_reason = "tool_calls" if tool_calls else ("stop" if stop_reason == "end_turn" else stop_reason)

        return make_openai_shaped_response(
            content=content,
            tool_calls=tool_calls or None,
            role="assistant",
            model=model_used,
            finish_reason=finish_reason,
            usage={
                "prompt_tokens": usage.get("input_tokens", 0),
                "completion_tokens": usage.get("output_tokens", 0),
                "total_tokens": usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
            },
        )


class AnthropicReviewProvider(ReviewProvider):
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    """Concrete ReviewProvider backed by Anthropic.

    Expects the model to return a structured response containing
    VERDICT, SCORE, and CRITIQUE markers that are parsed out.
    """

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke the Anthropic API for a review asynchronously."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "review")
        model = _resolve_model(config, task_class)

        persona = request.get("persona", "")
        work_output = request.get("work_output", "")
        acceptance_criteria = request.get("acceptance_criteria", "")

        system_prompt = (
            "You are a meticulous reviewer. Evaluate the work output against "
            "the acceptance criteria. Respond with exactly three lines:\n"
            "VERDICT: PASS or FAIL\n"
            "SCORE: a float between 0.0 and 1.0\n"
            "CRITIQUE: a brief explanation"
        )
        user_content = (
            f"Persona: {persona}\n\n"
            f"Work Output:\n{work_output}\n\n"
            f"Acceptance Criteria:\n{acceptance_criteria}"
        )

        max_tokens = request.get("max_tokens", 512)
        temperature = request.get("temperature", 0.2)

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_anthropic_http,
            api_key,
            model,
            system_prompt,
            user_content,
            max_tokens,
            temperature,
        )

        from aibrain.core.provider_contract import parse_review_response
        verdict, score, critique = parse_review_response(result["content"])

        return {
            "verdict": verdict,
            "score": score,
            "critique": critique,
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous wrapper for environments without an event loop."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "review")
        model = _resolve_model(config, task_class)

        persona = request.get("persona", "")
        work_output = request.get("work_output", "")
        acceptance_criteria = request.get("acceptance_criteria", "")

        system_prompt = (
            "You are a meticulous reviewer. Evaluate the work output against "
            "the acceptance criteria. Respond with exactly three lines:\n"
            "VERDICT: PASS or FAIL\n"
            "SCORE: a float between 0.0 and 1.0\n"
            "CRITIQUE: a brief explanation"
        )
        user_content = (
            f"Persona: {persona}\n\n"
            f"Work Output:\n{work_output}\n\n"
            f"Acceptance Criteria:\n{acceptance_criteria}"
        )

        max_tokens = request.get("max_tokens", 512)
        temperature = request.get("temperature", 0.2)

        result = _call_anthropic_http(
            api_key, model, system_prompt, user_content, max_tokens, temperature
        )

        from aibrain.core.provider_contract import parse_review_response
        verdict, score, critique = parse_review_response(result["content"])

        return {
            "verdict": verdict,
            "score": score,
            "critique": critique,
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    # Review response parsing is handled by the shared
    # parse_review_response() function in provider_contract.


# ---------------------------------------------------------------------------
# Smoke test (instantiation only — no API calls)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Instantiate providers with minimal config
    text_provider = AnthropicTextProvider(config={"api_key": "sk-ant-dummy"})
    review_provider = AnthropicReviewProvider(config={"api_key": "sk-ant-dummy"})

    # Verify they are instances of the correct types
    assert isinstance(text_provider, TextProvider)
    assert isinstance(review_provider, ReviewProvider)

    # Verify constants
    assert "cheap" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "judgment" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "review" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert MODEL_OPUS == "claude-opus-4-7"

    print("provider_anthropic smoke test OK")
