class AIBrainError(Exception):
    """Base exception for all AIBrain errors."""
    def __init__(self, message: str = ''):
        super().__init__(message)

class CompressionError(AIBrainError):
    """Context engine compression failures."""

class MemoryProviderError(AIBrainError):
    """Base for memory provider-related errors."""

class MemoryProviderUnavailable(MemoryProviderError):
    """Provider is unavailable (e.g. circuit breaker open)."""
    def __init__(self, *args, **kwargs):
        self.provider_id = kwargs.pop('provider_id', '')
        super().__init__(*args, **kwargs)

class MemoryCapabilityMissing(MemoryProviderError):
    """Requested capability is not supported by the provider."""
    def __init__(self, capability: str):
        self.capability = capability
        super().__init__(f'Capability missing: {capability}')
