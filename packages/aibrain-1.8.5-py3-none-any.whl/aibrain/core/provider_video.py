"""
Video generation provider implementations for AIBrain.

Implements VideoProvider contract defined in aibrain.core.provider_contract.
Concrete providers: Veo 3 (Google DeepMind), Kling (Kuaishou), Runway Gen-3,
and CogVideoX Local (local GPU inference).

Shape matches provider_anthropic.py: __init__(config), async invoke(request)
returning {url_or_path, model_used, latency_ms}.
"""

import json
import logging
import os
import time
import urllib.request
import urllib.error
import asyncio
from typing import Any, Dict, Optional

from aibrain.core.provider_contract import VideoProvider

logger = logging.getLogger("aibrain.provider_video")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Veo 3 via Vertex AI
VEO3_API_URL_TEMPLATE = (
    "https://{location}-aiplatform.googleapis.com/v1/"
    "projects/{project}/locations/{location}/publishers/google/"
    "models/{model}:predict"
)
KLING_API_URL = "https://api.kling.kuaishou.com/v1/video/generations"
RUNWAY_API_URL = "https://api.runwayml.com/v1/generations"

# Model IDs as of 2026-05
MODEL_VEO3 = "veo-3"
MODEL_KLING = "kling-v1-6"
MODEL_RUNWAY_GEN3 = "gen3-alpha"
MODEL_COGVIDEOX = "cogvideox-2b"

DEFAULT_MODEL_FOR_TASK_CLASS: Dict[str, str] = {
    "video_cinematic": MODEL_VEO3,
    "video_social": MODEL_KLING,
    "video_creative": MODEL_RUNWAY_GEN3,
    "video_local": MODEL_COGVIDEOX,
}

SUPPORTED_TASK_CLASSES = list(DEFAULT_MODEL_FOR_TASK_CLASS.keys())

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class VideoProviderError(Exception):
    """Raised when a video provider encounters an error."""

    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_api_key(config: Dict[str, Any], env_var: str) -> str:
    """Extract the API key from config or environment variable."""
    api_key = config.get("api_key") or os.environ.get(env_var)
    if not api_key:
        raise VideoProviderError(
            f"API key not found in config or {env_var} env var"
        )
    return api_key


def _resolve_model(config: Dict[str, Any], task_class: str) -> str:
    """Determine which model to use for a given task class."""
    model = config.get("model")
    if model:
        return model
    if task_class not in DEFAULT_MODEL_FOR_TASK_CLASS:
        raise VideoProviderError(
            f"Unsupported task_class '{task_class}'. "
            f"Supported: {SUPPORTED_TASK_CLASSES}"
        )
    return DEFAULT_MODEL_FOR_TASK_CLASS[task_class]


def _call_video_http(
    api_url: str,
    api_key: str,
    headers_extra: Dict[str, str],
    body: Dict[str, Any],
    timeout: int = 300,
) -> Dict[str, Any]:
    """Synchronous HTTP call to a video generation API.

    Returns a dict with keys: url_or_path, model_used, latency_ms.
    Video generation is typically async — submits job, polls until complete.
    """
    headers = {
        "Content-Type": "application/json",
    }
    headers.update(headers_extra)

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(api_url, data=data, headers=headers, method="POST")

    start = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            elapsed_ms = (time.monotonic() - start) * 1000.0
    except urllib.error.HTTPError as exc:
        err_body = exc.read().decode("utf-8", errors="replace")
        raise VideoProviderError(
            f"Video API HTTP {exc.code}: {err_body}"
        ) from exc
    except Exception as exc:
        raise VideoProviderError(f"Video API request failed: {exc}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise VideoProviderError(f"Invalid JSON from video API: {raw[:200]}") from exc

    # Poll for completion if the API returns a job/task ID instead of a direct URL
    video_url = (
        payload.get("url")
        or payload.get("video_url")
        or payload.get("output", {}).get("url")
        or payload.get("result", {}).get("url")
        or ""
    )

    job_id = payload.get("id") or payload.get("job_id") or payload.get("task_id")
    if job_id and not video_url:
        video_url = _poll_video_job(api_url, job_id, api_key, headers_extra, start)

    model_used = payload.get("model", body.get("model", "unknown"))

    return {
        "url_or_path": video_url,
        "model_used": model_used,
        "latency_ms": round(elapsed_ms, 2),
    }


def _poll_video_job(
    base_url: str,
    job_id: str,
    api_key: str,
    headers_extra: Dict[str, str],
    start_time: float,
    max_wait_s: int = 600,
    poll_interval_s: float = 5.0,
) -> str:
    """Poll a video generation job until complete or timeout."""
    poll_url = f"{base_url}/{job_id}"
    deadline = start_time + max_wait_s

    while time.monotonic() < deadline:
        time.sleep(poll_interval_s)
        headers = {"Content-Type": "application/json"}
        headers.update(headers_extra)
        req = urllib.request.Request(poll_url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read().decode("utf-8")
                payload = json.loads(raw)
        except Exception:
            continue

        status = (
            payload.get("status", "")
            or payload.get("state", "")
            or ""
        ).lower()

        if status in ("completed", "succeeded", "done", "ready"):
            return (
                payload.get("url")
                or payload.get("video_url")
                or payload.get("output", {}).get("url")
                or ""
            )
        if status in ("failed", "error", "cancelled"):
            raise VideoProviderError(
                f"Video job {job_id} failed: {payload.get('error', 'unknown')}"
            )

    raise VideoProviderError(f"Video job {job_id} timed out after {max_wait_s}s")


# ---------------------------------------------------------------------------
# Veo3VideoProvider (Google DeepMind Veo 3 via Vertex AI)
# ---------------------------------------------------------------------------


class Veo3VideoProvider(VideoProvider):
    """Concrete VideoProvider backed by Google Veo 3 on Vertex AI."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "GOOGLE_API_KEY")
        task_class = request.get("task_class", "video_cinematic")
        model = _resolve_model(config, task_class)

        project = config.get("project") or os.environ.get("GOOGLE_PROJECT_ID", "default")
        location = config.get("location", "us-central1")

        api_url = VEO3_API_URL_TEMPLATE.format(
            location=location,
            project=project,
            model=model,
        )

        prompt = request.get("prompt", "")
        duration = request.get("duration", 8)
        resolution = request.get("resolution", "1080p")

        body = {
            "instances": [{
                "prompt": prompt,
                "duration_seconds": duration,
                "resolution": resolution,
            }],
            "parameters": {
                "sampleCount": 1,
            },
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_video_http,
            api_url,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "GOOGLE_API_KEY")
        task_class = request.get("task_class", "video_cinematic")
        model = _resolve_model(config, task_class)

        project = config.get("project") or os.environ.get("GOOGLE_PROJECT_ID", "default")
        location = config.get("location", "us-central1")

        api_url = VEO3_API_URL_TEMPLATE.format(
            location=location,
            project=project,
            model=model,
        )

        body = {
            "instances": [{
                "prompt": request.get("prompt", ""),
                "duration_seconds": request.get("duration", 8),
                "resolution": request.get("resolution", "1080p"),
            }],
            "parameters": {"sampleCount": 1},
        }

        return _call_video_http(
            api_url,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )


# ---------------------------------------------------------------------------
# KlingVideoProvider (Kuaishou Kling)
# ---------------------------------------------------------------------------


class KlingVideoProvider(VideoProvider):
    """Concrete VideoProvider backed by Kuaishou Kling API."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "KLING_API_KEY")
        task_class = request.get("task_class", "video_social")
        model = _resolve_model(config, task_class)

        prompt = request.get("prompt", "")
        duration = request.get("duration", 5)
        resolution = request.get("resolution", "1080p")

        body = {
            "model": model,
            "prompt": prompt,
            "duration": duration,
            "resolution": resolution,
            "aspect_ratio": request.get("aspect_ratio", "16:9"),
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_video_http,
            KLING_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "KLING_API_KEY")
        task_class = request.get("task_class", "video_social")
        model = _resolve_model(config, task_class)

        body = {
            "model": model,
            "prompt": request.get("prompt", ""),
            "duration": request.get("duration", 5),
            "resolution": request.get("resolution", "1080p"),
            "aspect_ratio": request.get("aspect_ratio", "16:9"),
        }

        return _call_video_http(
            KLING_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )


# ---------------------------------------------------------------------------
# RunwayGen3VideoProvider (Runway Gen-3)
# ---------------------------------------------------------------------------


class RunwayGen3VideoProvider(VideoProvider):
    """Concrete VideoProvider backed by Runway Gen-3 Alpha API."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "RUNWAY_API_KEY")
        task_class = request.get("task_class", "video_creative")
        model = _resolve_model(config, task_class)

        prompt = request.get("prompt", "")
        duration = request.get("duration", 8)
        resolution = request.get("resolution", "1080p")

        body = {
            "model": model,
            "prompt": prompt,
            "duration": duration,
            "resolution": resolution,
            "watermark": True,
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_video_http,
            RUNWAY_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}", "X-Runway-Version": "2024-01-01"},
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "RUNWAY_API_KEY")
        task_class = request.get("task_class", "video_creative")
        model = _resolve_model(config, task_class)

        body = {
            "model": model,
            "prompt": request.get("prompt", ""),
            "duration": request.get("duration", 8),
            "resolution": request.get("resolution", "1080p"),
            "watermark": True,
        }

        return _call_video_http(
            RUNWAY_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}", "X-Runway-Version": "2024-01-01"},
            body,
        )


# ---------------------------------------------------------------------------
# CogVideoXLocalProvider (local CogVideoX GPU inference)
# ---------------------------------------------------------------------------


class CogVideoXLocalProvider(VideoProvider):
    """Concrete VideoProvider backed by local CogVideoX (THUDM).

    No API key required — connects to a local CogVideoX endpoint
    (default http://localhost:7861/generate for a gradio/diffusers wrapper).
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        task_class = request.get("task_class", "video_local")
        model = _resolve_model(config, task_class)

        endpoint = config.get("endpoint", "http://localhost:7861/generate")

        prompt = request.get("prompt", "")
        duration = request.get("duration", 4)
        resolution = request.get("resolution", "480p")
        num_frames = duration * 8  # 8 fps default for CogVideoX

        body = {
            "prompt": prompt,
            "num_frames": num_frames,
            "num_inference_steps": 50,
            "guidance_scale": 6.0,
            "resolution": resolution,
        }

        start = time.monotonic()
        try:
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=600) as resp:
                raw = resp.read().decode("utf-8")
                elapsed_ms = (time.monotonic() - start) * 1000.0
        except Exception as exc:
            raise VideoProviderError(f"CogVideoX local request failed: {exc}") from exc

        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            raise VideoProviderError(f"Invalid JSON from CogVideoX: {raw[:200]}")

        # Local endpoint returns a file path or base64-encoded video
        video_path = (
            payload.get("output_path")
            or payload.get("url")
            or ""
        )
        if not video_path and payload.get("video_base64"):
            import tempfile
            import base64
            video_data = base64.b64decode(payload["video_base64"])
            tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
            tmp.write(video_data)
            tmp.close()
            video_path = tmp.name

        return {
            "url_or_path": video_path,
            "model_used": model,
            "latency_ms": round(elapsed_ms, 2),
        }

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        task_class = request.get("task_class", "video_local")
        model = _resolve_model(config, task_class)

        endpoint = config.get("endpoint", "http://localhost:7861/generate")
        prompt = request.get("prompt", "")
        duration = request.get("duration", 4)
        num_frames = duration * 8

        body = {
            "prompt": prompt,
            "num_frames": num_frames,
            "num_inference_steps": 50,
            "guidance_scale": 6.0,
            "resolution": request.get("resolution", "480p"),
        }

        start = time.monotonic()
        try:
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=600) as resp:
                raw = resp.read().decode("utf-8")
                elapsed_ms = (time.monotonic() - start) * 1000.0
        except Exception as exc:
            raise VideoProviderError(f"CogVideoX local request failed: {exc}") from exc

        payload = json.loads(raw)
        video_path = (
            payload.get("output_path")
            or payload.get("url")
            or ""
        )
        if not video_path and payload.get("video_base64"):
            import tempfile
            import base64
            video_data = base64.b64decode(payload["video_base64"])
            tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
            tmp.write(video_data)
            tmp.close()
            video_path = tmp.name

        return {
            "url_or_path": video_path,
            "model_used": model,
            "latency_ms": round(elapsed_ms, 2),
        }


# ---------------------------------------------------------------------------
# Smoke test (instantiation only — no API calls, no keys required)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Instantiate all providers with minimal/dummy config
    veo3 = Veo3VideoProvider(config={"api_key": "dummy-google-key"})
    kling = KlingVideoProvider(config={"api_key": "dummy-kling-key"})
    runway = RunwayGen3VideoProvider(config={"api_key": "dummy-runway-key"})
    cog = CogVideoXLocalProvider()

    # Verify they are instances of VideoProvider
    assert isinstance(veo3, VideoProvider), "Veo3VideoProvider must be VideoProvider"
    assert isinstance(kling, VideoProvider), "KlingVideoProvider must be VideoProvider"
    assert isinstance(runway, VideoProvider), "RunwayGen3VideoProvider must be VideoProvider"
    assert isinstance(cog, VideoProvider), "CogVideoXLocalProvider must be VideoProvider"

    # Verify DEFAULT_MODEL_FOR_TASK_CLASS has expected entries
    assert "video_cinematic" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "video_social" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "video_creative" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "video_local" in DEFAULT_MODEL_FOR_TASK_CLASS

    # Verify model constants
    assert MODEL_VEO3 == "veo-3"
    assert MODEL_RUNWAY_GEN3 == "gen3-alpha"

    print("provider_video smoke test OK")
