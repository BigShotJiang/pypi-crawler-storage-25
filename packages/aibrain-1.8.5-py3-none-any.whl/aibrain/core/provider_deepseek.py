import time
from typing import Any, Dict, Optional

from aibrain.core.companies import _deepseek_http_call
from aibrain.core.provider_contract import TextProvider, ReviewProvider


DEFAULT_MODEL_FOR_TASK_CLASS = {
    "cheap": "deepseek-v4-pro",
    "judgment": "deepseek-v4-pro",
    "review": "deepseek-v4-pro",
}

SUPPORTED_TASK_CLASSES = ["cheap", "judgment", "review"]


class DeepSeekProviderError(Exception):
    """Errors originating from the DeepSeek provider."""
    pass


def _resolve_model(config: Optional[Dict[str, Any]], task_class: str) -> str:
    """Resolve the model identifier for a given task class.

    If *config* provides a ``model`` key, that value is used; otherwise the
    default for *task_class* is returned.
    """
    if config and "model" in config:
        return config["model"]
    return DEFAULT_MODEL_FOR_TASK_CLASS[task_class]


class DeepSeekTextProvider(TextProvider):
    """Concrete TextProvider that delegates to the canonical DeepSeek HTTP helper."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._invoke_sync_from_request, request)

    def _invoke_sync_from_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        return self._invoke_sync(
            system_prompt=request.get("system_prompt", ""),
            user_prompt=request.get("prompt", ""),
            task_class=request.get("task_class", "judgment"),
            config=self.config,
        )

    def _invoke_sync(
        self,
        system_prompt: str,
        user_prompt: str,
        task_class: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if task_class not in SUPPORTED_TASK_CLASSES:
            raise DeepSeekProviderError(
                f"Unsupported task class: {task_class}. "
                f"Supported: {SUPPORTED_TASK_CLASSES}"
            )

        model = _resolve_model(config, task_class)
        timeout_s = config.get("timeout_s", 120) if config else 120
        thinking = config.get("thinking", False) if config else False
        reasoning_effort = config.get("reasoning_effort", "medium") if config else "medium"

        t0 = time.monotonic()
        try:
            raw = _deepseek_http_call(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                model=model,
                timeout_s=timeout_s,
                thinking=thinking,
                reasoning_effort=reasoning_effort,
            )
        except Exception as exc:
            raise DeepSeekProviderError(
                f"DeepSeek HTTP call failed: {exc}"
            ) from exc

        latency_ms = (time.monotonic() - t0) * 1000.0

        return {
            "content": raw["content"],
            "model_used": model,
            "tokens_in": raw.get("tokens_in", 0),
            "tokens_out": raw.get("tokens_out", 0),
            "latency_ms": latency_ms,
        }

    # ------------------------------------------------------------------
    # Chat-with-tools dispatch surface
    # ------------------------------------------------------------------
    # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21). DeepSeek
    # speaks OpenAI's wire format at api.deepseek.com — use the openai
    # SDK with base_url override. Streaming passes the SDK iterator
    # straight through.

    def chat_with_tools(
        self,
        model: str,
        messages: list,
        tools: Optional[list] = None,
        tool_choice: Optional[Any] = None,
        api_key: Optional[str] = None,
        stream: bool = False,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **_extra: Any,
    ) -> Any:
        import os as _os
        from openai import OpenAI
        from aibrain.core.provider_contract import (
            make_openai_shaped_response,
            make_tool_call,
        )
        key = api_key or self.config.get("api_key") or _os.environ.get("DEEPSEEK_API_KEY")
        if not key:
            raise DeepSeekProviderError(
                "No DeepSeek API key. Set DEEPSEEK_API_KEY or pass api_key=..."
            )
        client = OpenAI(api_key=key, base_url="https://api.deepseek.com")
        kwargs: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        if tools:
            kwargs["tools"] = tools
            if tool_choice is not None:
                kwargs["tool_choice"] = tool_choice
        resp = client.chat.completions.create(**kwargs)
        if stream:
            return resp
        msg = resp.choices[0].message
        # F-LUCY-DEEPSEEK-RC-1A: capture msg.reasoning_content for
        # deepseek-reasoner multi-turn pass-back. DeepSeek 400s on turn 2 if
        # prior assistant messages omit this field when thinking-mode is active.
        rc = getattr(msg, "reasoning_content", None)
        tcs = None
        if getattr(msg, "tool_calls", None):
            tcs = [
                make_tool_call(
                    call_id=tc.id,
                    name=tc.function.name,
                    arguments_json=tc.function.arguments or "{}",
                )
                for tc in msg.tool_calls
            ]
        return make_openai_shaped_response(
            content=msg.content or "",
            tool_calls=tcs,
            role=msg.role or "assistant",
            model=resp.model or model,
            finish_reason=resp.choices[0].finish_reason or "stop",
            usage={
                "prompt_tokens": getattr(resp.usage, "prompt_tokens", 0) if resp.usage else 0,
                "completion_tokens": getattr(resp.usage, "completion_tokens", 0) if resp.usage else 0,
                "total_tokens": getattr(resp.usage, "total_tokens", 0) if resp.usage else 0,
            },
            reasoning_content=rc,
        )


class DeepSeekReviewProvider(ReviewProvider):
    """Concrete ReviewProvider backed by DeepSeek.

    Uses the same _deepseek_http_call helper as DeepSeekTextProvider
    and the shared parse_review_response parser from provider_contract.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke the DeepSeek API for a review asynchronously."""
        import asyncio
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._invoke_sync, request)

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous review call."""
        config = self.config or {}
        persona = request.get("persona", "")
        work_output = request.get("work_output", "")
        acceptance_criteria = request.get("acceptance_criteria", "")

        system_prompt = (
            "You are a meticulous reviewer. Evaluate the work output against "
            "the acceptance criteria. Respond with exactly three lines:\n"
            "VERDICT: PASS or FAIL\n"
            "SCORE: a float between 0.0 and 1.0\n"
            "CRITIQUE: a brief explanation"
        )
        user_prompt = (
            f"Persona: {persona}\n\n"
            f"Work Output:\n{work_output}\n\n"
            f"Acceptance Criteria:\n{acceptance_criteria}"
        )

        model = _resolve_model(config, "review")
        timeout_s = config.get("timeout_s", 120)

        t0 = time.monotonic()
        try:
            raw = _deepseek_http_call(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                model=model,
                timeout_s=timeout_s,
                thinking=False,
            )
        except Exception as exc:
            raise DeepSeekProviderError(
                f"DeepSeek review HTTP call failed: {exc}"
            ) from exc

        latency_ms = (time.monotonic() - t0) * 1000.0

        from aibrain.core.provider_contract import parse_review_response
        parsed = parse_review_response(raw["content"])

        return {
            "verdict": parsed["verdict"],
            "score": parsed["score"],
            "critique": parsed["critique"],
            "model_used": model,
            "latency_ms": latency_ms,
        }


if __name__ == "__main__":
    # Smoke test: instantiation only – no network call is made.
    text_provider = DeepSeekTextProvider({})
    review_provider = DeepSeekReviewProvider({})

    from aibrain.core.provider_contract import TextProvider, ReviewProvider
    assert isinstance(text_provider, TextProvider)
    assert isinstance(review_provider, ReviewProvider)

    print("provider_deepseek smoke test OK")