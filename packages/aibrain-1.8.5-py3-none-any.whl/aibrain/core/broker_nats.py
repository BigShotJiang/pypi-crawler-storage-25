"""
broker_nats.py -- Slim NATS pub/sub client for Neuro/Case inter-agent comms.

NATSBroker  -- async (nats-py). BrokerClient -- sync wrapper for hooks/scripts.
Auth: BROKER_TOKEN env var. Reconnect: nats-py infinite backoff (2s).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)


def _load_token() -> str:
    """Load BROKER_TOKEN from env or ~/.decker_env / ~/.aibrain_env."""
    token = os.environ.get("BROKER_TOKEN", "")
    if token:
        return token
    for env_file in (Path.home() / ".decker_env", Path.home() / ".aibrain_env"):
        if env_file.exists():
            try:
                for line in env_file.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("BROKER_TOKEN=") and not line.startswith("#"):
                        return line.split("=", 1)[1].strip().strip('"')
            except Exception:
                pass
    return ""


class NATSBroker:
    """Async NATS pub/sub client. url falls back to NATS_URL env var (required)."""

    def __init__(self, url: str | None = None, subject_prefix: str = "") -> None:
        raw_url = url or os.environ.get("NATS_URL", "")
        # F-DEEP-NATS-URL-MIXING-DIAG-1: nats-py rejects mixing ws:// and nats:// schemes.
        # Filter to the preferred scheme when multiple URLs are present in a comma-separated list.
        if ',' in raw_url:
            urls = [u.strip() for u in raw_url.split(',') if u.strip()]
            ws_urls = [u for u in urls if u.startswith('ws://') or u.startswith('wss://')]
            nats_urls = [u for u in urls if u.startswith('nats://')]
            raw_url = ','.join(ws_urls or nats_urls or urls)
        self._url = raw_url
        self._prefix = subject_prefix
        self._token = _load_token()
        self._nc: Any = None  # nats.NATS — lazy import, typed Any

    def _full_subject(self, subject: str) -> str:
        if self._prefix and not subject.startswith(self._prefix):
            return f"{self._prefix}.{subject}"
        return subject

    async def connect(self) -> None:
        """Connect to NATS. Idempotent."""
        if self._nc is not None and self._nc.is_connected:
            return
        try:
            import nats
        except ImportError as exc:
            raise ImportError(
                "nats-py is required. Install with: pip install nats-py"
            ) from exc

        self._nc = await nats.connect(
            servers=[self._url],
            token=self._token,
            allow_reconnect=True,
            max_reconnect_attempts=-1,
            reconnect_time_wait=2,
            error_cb=self._on_error,
            disconnected_cb=self._on_disconnect,
            reconnected_cb=self._on_reconnect,
        )
        logger.info("NATSBroker connected to %s", self._url)

    async def publish(self, subject: str, payload: dict) -> None:
        if self._nc is None or not self._nc.is_connected:
            raise RuntimeError("Not connected. Call connect() first.")
        full = self._full_subject(subject)
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        await self._nc.publish(full, data)
        logger.debug("Published to %s", full)

    async def subscribe(
        self,
        subject: str,
        handler: Callable[[dict], Awaitable[None]],
    ) -> None:
        if self._nc is None or not self._nc.is_connected:
            raise RuntimeError("Not connected. Call connect() first.")
        full = self._full_subject(subject)

        async def _cb(msg: Any) -> None:
            try:
                data = json.loads(msg.data.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                logger.warning("Malformed NATS message on %s: %s", full, exc)
                return
            await handler(data)

        await self._nc.subscribe(full, cb=_cb)
        logger.info("Subscribed to %s", full)

    async def close(self) -> None:
        if self._nc and not self._nc.is_closed:
            await self._nc.drain()
        self._nc = None
        logger.info("NATSBroker closed")

    async def _on_error(self, exc: Exception) -> None:
        logger.error("NATS error: %s", exc)

    async def _on_disconnect(self) -> None:
        logger.warning("NATS disconnected — auto-reconnect in progress")

    async def _on_reconnect(self) -> None:
        logger.info("NATS reconnected to %s", self._url)


class BrokerClient:
    """Sync wrapper around NATSBroker. Uses asyncio.run(). Not for async contexts."""

    def __init__(self, url: str | None = None, subject_prefix: str = "") -> None:
        self._broker = NATSBroker(url=url, subject_prefix=subject_prefix)

    def _run(self, coro: Any) -> Any:
        return asyncio.run(coro)

    def publish(self, subject: str, payload: dict) -> None:
        async def _do() -> None:
            await self._broker.connect()
            await self._broker.publish(subject, payload)
        self._run(_do())

    def subscribe(self, subject: str, handler: Callable[[dict], None]) -> None:
        async def _async_handler(msg: dict) -> None:
            handler(msg)
        async def _do() -> None:
            await self._broker.connect()
            await self._broker.subscribe(subject, _async_handler)
        self._run(_do())

    def close(self) -> None:
        self._run(self._broker.close())
