"""Tests for authorization_ledger.py — legal scan authorization tracking."""

import pytest

from aibrain.core.authorization_ledger import (
    authorize_target,
    check_authorization,
    list_authorizations,
    revoke_authorization,
    require_authorization,
    seed_authorizations,
    UnauthorizedScanError,
    _get_db,
)


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary DB for each test."""
    p = str(tmp_path / "test_auth.db")
    # Touch schema by opening once
    db = _get_db(p)
    db.close()
    return p


# --- Test 1: authorize and retrieve ---

def test_authorize_and_check(db_path):
    rec = authorize_target(
        "scanme.nmap.org", "scan_me", "scan_me_header", "full_scan",
        authorized_by="Decker", authorized_date="2026-03-10",
        rate_limit_rps=2.0, db_path=db_path,
    )
    assert rec["target"] == "scanme.nmap.org"
    assert rec["scope"] == "full_scan"
    assert rec["active"] == 1

    found = check_authorization("scanme.nmap.org", db_path=db_path)
    assert found is not None
    assert found["target_type"] == "scan_me"


# --- Test 2: check returns None for unknown target ---

def test_check_unknown_target(db_path):
    assert check_authorization("unknown.example.com", db_path=db_path) is None


# --- Test 3: revoke deactivates authorization ---

def test_revoke(db_path):
    authorize_target(
        "target.example.com", "client", "contract", "discovery_only",
        db_path=db_path,
    )
    assert check_authorization("target.example.com", db_path=db_path) is not None

    count = revoke_authorization("target.example.com", db_path=db_path)
    assert count == 1
    assert check_authorization("target.example.com", db_path=db_path) is None


# --- Test 4: require_authorization raises on missing ---

def test_require_raises(db_path):
    with pytest.raises(UnauthorizedScanError, match="No active authorization"):
        require_authorization("blocked.example.com", db_path=db_path)


# --- Test 5: require_authorization returns record when authorized ---

def test_require_returns_auth(db_path):
    authorize_target(
        "allowed.example.com", "internal", "contract", "full_scan",
        db_path=db_path,
    )
    auth = require_authorization("allowed.example.com", db_path=db_path)
    assert auth["target"] == "allowed.example.com"
    assert auth["scope"] == "full_scan"


# --- Test 6: seed populates expected records ---

def test_seed(db_path):
    count = seed_authorizations(db_path=db_path)
    assert count >= 15  # 9 entities + 4 scan-me + 2 bug bounty

    records = list_authorizations(db_path=db_path)
    targets = {r["target"] for r in records}
    assert "Entity-A" in targets
    assert "scanme.nmap.org" in targets
    assert "hackerone_example" in targets

    # Idempotent — second seed adds 0
    count2 = seed_authorizations(db_path=db_path)
    assert count2 == 0


# --- Test 7: expired authorization returns None ---

def test_expired_authorization(db_path):
    authorize_target(
        "expired.example.com", "client", "contract", "discovery_only",
        authorized_date="2020-01-01", expires="2020-12-31",
        db_path=db_path,
    )
    assert check_authorization("expired.example.com", db_path=db_path) is None


# --- Test 8: invalid target_type rejected ---

def test_invalid_target_type(db_path):
    with pytest.raises(ValueError, match="target_type"):
        authorize_target(
            "x.com", "invalid_type", "contract", "full_scan",
            db_path=db_path,
        )


# --- Test 9: invalid scope rejected ---

def test_invalid_scope(db_path):
    with pytest.raises(ValueError, match="scope"):
        authorize_target(
            "x.com", "internal", "contract", "invalid_scope",
            db_path=db_path,
        )


# --- Test 10: list active_only vs all ---

def test_list_active_vs_all(db_path):
    authorize_target("a.com", "internal", "contract", "full_scan", db_path=db_path)
    authorize_target("b.com", "internal", "contract", "full_scan", db_path=db_path)
    revoke_authorization("b.com", db_path=db_path)

    active = list_authorizations(active_only=True, db_path=db_path)
    all_recs = list_authorizations(active_only=False, db_path=db_path)

    assert len(active) == 1
    assert len(all_recs) == 2
