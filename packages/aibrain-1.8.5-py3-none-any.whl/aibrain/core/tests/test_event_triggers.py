"""Tests for event-triggered workflow execution in workflow_runner."""

import os
import tempfile
from unittest.mock import patch, MagicMock

import pytest

# Point AIBRAIN_ROOT to a temp dir so tests don't touch the real DB
_tmpdir = tempfile.mkdtemp()
os.environ["AIBRAIN_ROOT"] = _tmpdir

from aibrain.core.event_bus import emit, clear_handlers
from aibrain.core.workflow_runner import (
    trigger_on_event,
    untrigger_on_event,
    get_event_triggers,
    clear_event_triggers,
    _registered_event_types,
)


@pytest.fixture(autouse=True)
def _clean_state():
    """Reset triggers and handlers between tests."""
    clear_event_triggers()
    _registered_event_types.clear()
    clear_handlers()
    yield
    clear_event_triggers()
    _registered_event_types.clear()
    clear_handlers()


# ---------------------------------------------------------------------------
# Test 1: trigger_on_event registers and lists
# ---------------------------------------------------------------------------

def test_trigger_registers_workflow():
    """trigger_on_event registers a workflow for an event type."""
    trigger_on_event("heartbeat", "QUALITY_LOW")
    triggers = get_event_triggers()
    assert "QUALITY_LOW" in triggers
    assert "heartbeat" in triggers["QUALITY_LOW"]


# ---------------------------------------------------------------------------
# Test 2: trigger_on_event rejects unknown workflows
# ---------------------------------------------------------------------------

def test_trigger_rejects_unknown_workflow(tmp_path):
    """trigger_on_event raises ValueError for unknown workflows."""
    with pytest.raises(ValueError, match="Unknown workflow"):
        trigger_on_event("nonexistent_workflow_xyz", "SOME_EVENT")


# ---------------------------------------------------------------------------
# Test 3: event fires and triggers workflow execution
# ---------------------------------------------------------------------------

@patch("aibrain.core.workflow_runner.run_workflow")
def test_event_fires_triggers_workflow(mock_run):
    """Emitting an event triggers the registered workflow."""
    mock_run.return_value = MagicMock(success=True, quality=0.8)

    trigger_on_event("heartbeat", "CORRECTION_RECEIVED")

    # Now emit the event
    emit("CORRECTION_RECEIVED", {"name": "test correction"})

    mock_run.assert_called_once()
    args, kwargs = mock_run.call_args
    assert kwargs.get("actor") == "event_trigger" or args[0] == "heartbeat"


# ---------------------------------------------------------------------------
# Test 4: multiple workflows triggered by same event
# ---------------------------------------------------------------------------

@patch("aibrain.core.workflow_runner.run_workflow")
def test_multiple_workflows_same_event(mock_run):
    """Multiple workflows registered for the same event all fire."""
    mock_run.return_value = MagicMock(success=True)

    trigger_on_event("heartbeat", "QUALITY_LOW")
    trigger_on_event("db_backup", "QUALITY_LOW")

    triggers = get_event_triggers()
    assert len(triggers["QUALITY_LOW"]) == 2

    emit("QUALITY_LOW", {"task_name": "test", "eval_score": 0.1})

    assert mock_run.call_count == 2
    workflow_names = [c.args[0] if c.args else c.kwargs.get("name") for c in mock_run.call_args_list]
    # Verify both workflows were called (check positional arg or first arg)
    called_names = []
    for c in mock_run.call_args_list:
        if c.args:
            called_names.append(c.args[0])
        else:
            called_names.append(c.kwargs.get("name"))
    assert "heartbeat" in called_names
    assert "db_backup" in called_names


# ---------------------------------------------------------------------------
# Test 5: untrigger removes registration
# ---------------------------------------------------------------------------

@patch("aibrain.core.workflow_runner.run_workflow")
def test_untrigger_removes_workflow(mock_run):
    """untrigger_on_event removes the workflow from event triggers."""
    trigger_on_event("heartbeat", "CORRECTION_RECEIVED")
    assert untrigger_on_event("heartbeat", "CORRECTION_RECEIVED")

    triggers = get_event_triggers()
    assert "CORRECTION_RECEIVED" not in triggers

    # Emitting should not trigger anything
    emit("CORRECTION_RECEIVED", {"name": "test"})
    mock_run.assert_not_called()


# ---------------------------------------------------------------------------
# Test 6: duplicate registration is idempotent
# ---------------------------------------------------------------------------

def test_duplicate_trigger_idempotent():
    """Registering the same workflow+event twice doesn't create duplicates."""
    trigger_on_event("heartbeat", "QUALITY_LOW")
    trigger_on_event("heartbeat", "QUALITY_LOW")

    triggers = get_event_triggers()
    assert len(triggers["QUALITY_LOW"]) == 1


# ---------------------------------------------------------------------------
# Test 7: event_payload is forwarded to workflow
# ---------------------------------------------------------------------------

@patch("aibrain.core.workflow_runner.run_workflow")
def test_event_payload_forwarded(mock_run):
    """The event payload is passed as event_payload kwarg."""
    mock_run.return_value = MagicMock(success=True)

    trigger_on_event("heartbeat", "SCAN_FINDING_STORED")

    payload = {"finding_id": 42, "severity": "high"}
    emit("SCAN_FINDING_STORED", payload)

    mock_run.assert_called_once()
    kwargs = mock_run.call_args.kwargs
    assert kwargs["event_payload"] == payload


# ---------------------------------------------------------------------------
# Test 8: failing workflow doesn't break other triggers
# ---------------------------------------------------------------------------

@patch("aibrain.core.workflow_runner.run_workflow")
def test_failing_workflow_doesnt_block_others(mock_run):
    """If one triggered workflow raises, the others still run."""
    call_count = {"n": 0}

    def side_effect(name, **kwargs):
        call_count["n"] += 1
        if name == "heartbeat":
            raise RuntimeError("boom")
        return MagicMock(success=True)

    mock_run.side_effect = side_effect

    trigger_on_event("heartbeat", "QUALITY_LOW")
    trigger_on_event("db_backup", "QUALITY_LOW")

    emit("QUALITY_LOW", {"task_name": "test", "eval_score": 0.1})

    # Both should have been attempted
    assert call_count["n"] == 2


# ---------------------------------------------------------------------------
# Test 9: get_event_triggers returns current state
# ---------------------------------------------------------------------------

def test_get_event_triggers_structure():
    """get_event_triggers returns clean dict of event→workflows."""
    trigger_on_event("heartbeat", "QUALITY_LOW")
    trigger_on_event("db_backup", "CORRECTION_RECEIVED")
    trigger_on_event("service_monitor", "QUALITY_LOW")

    triggers = get_event_triggers()
    assert set(triggers.keys()) == {"QUALITY_LOW", "CORRECTION_RECEIVED"}
    assert set(triggers["QUALITY_LOW"]) == {"heartbeat", "service_monitor"}
    assert triggers["CORRECTION_RECEIVED"] == ["db_backup"]
