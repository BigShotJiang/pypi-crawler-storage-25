"""
dynamic_router.py — SelRoute dynamic model routing for AIBrain harness.

Auto-discovers local Ollama models, respects user config from model.toml,
and routes tasks to the cheapest capable model:

  DETERMINISTIC → code_only ($0, no LLM)
  SIMPLE        → smallest local Ollama model ($0)
  JUDGMENT      → large local model (12B+) or Claude Haiku (cheap cloud)
  COMPLEX       → Claude Sonnet/Opus (best quality)

The routing table updates on demand via update_routing_table(), which
re-probes Ollama for newly pulled/removed models.

Replaces the static local_router.py with dynamic discovery and user config
integration.

Usage:
    from aibrain.core.dynamic_router import (
        discover_models, select_model, update_routing_table, get_routing_table,
    )

    models = discover_models()          # probe Ollama + list cloud models
    model_id = select_model("simple")   # cheapest capable for task type
    update_routing_table()              # refresh after pulling new models
    table = get_routing_table()         # current assignments
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("aibrain.dynamic_router")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Default allowlist of safe hostnames for the Ollama base URL.
# Extend at deploy time via OLLAMA_ALLOWED_HOSTS (comma-separated hostnames).
_OLLAMA_DEFAULT_ALLOWED_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})
_OLLAMA_ALLOWED_SCHEMES = frozenset({"http", "https"})


def _validate_ollama_url(url: str) -> str:
    """Validate that *url* is safe to use as the Ollama base URL.

    Allowed hostnames (case-insensitive):
      - localhost, 127.0.0.1, ::1  (built-in loopback allowlist)
      - any hostname listed in the OLLAMA_ALLOWED_HOSTS env var
        (comma-separated, e.g. "my-ollama.internal,10.0.0.5")

    Allowed schemes: http, https only (rejects file://, ftp://, etc.)

    Raises:
        ValueError: with a descriptive message if the URL fails validation.

    Returns:
        The original *url* string unchanged, so callers can write:
            url = _validate_ollama_url(url)
    """
    parsed = urllib.parse.urlparse(url)

    # --- scheme check ---
    if parsed.scheme not in _OLLAMA_ALLOWED_SCHEMES:
        raise ValueError(
            f"OLLAMA_BASE_URL scheme '{parsed.scheme}' is not allowed. "
            f"Use http or https. Got: {url!r}"
        )

    # --- hostname check ---
    hostname = (parsed.hostname or "").lower()

    extra_hosts_raw = os.environ.get("OLLAMA_ALLOWED_HOSTS", "")
    extra_hosts = frozenset(
        h.strip().lower() for h in extra_hosts_raw.split(",") if h.strip()
    )
    allowed_hosts = _OLLAMA_DEFAULT_ALLOWED_HOSTS | extra_hosts

    if hostname not in allowed_hosts:
        raise ValueError(
            f"OLLAMA_BASE_URL hostname '{hostname}' is not in the allowed list. "
            f"Allowed: {sorted(allowed_hosts)}. "
            f"To permit additional hosts set OLLAMA_ALLOWED_HOSTS=host1,host2. "
            f"Got: {url!r}"
        )

    return url


# Validate at module load — fail fast rather than silently allow SSRF.
OLLAMA_BASE_URL = _validate_ollama_url(
    os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
)
OLLAMA_TIMEOUT = 3  # seconds

# Minimum parameter count (billions) to qualify for each tier
_TIER_MIN_PARAMS_B = {
    "simple": 0,       # any model works
    "judgment": 10.0,   # need 10B+ for judgment-quality reasoning
}

# Models to skip (not general-purpose LLMs)
_SKIP_FAMILIES = frozenset({"bert", "clip", "whisper"})
_SKIP_NAME_PATTERNS = ("ocr", "vision", "embed", "minilm", "all-minilm")

# Cloud model definitions
CLOUD_MODELS = {
    "haiku": {"provider": "anthropic", "cost_per_1k": 0.00025, "quality_tier": "simple"},
    "sonnet": {"provider": "anthropic", "cost_per_1k": 0.003, "quality_tier": "judgment"},
    "opus": {"provider": "anthropic", "cost_per_1k": 0.015, "quality_tier": "complex"},
}


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class ModelInfo:
    """Metadata about an available model."""
    name: str
    provider: str           # "ollama" or "anthropic"
    parameter_size: str     # e.g. "4.3B", "27.4B", "unknown"
    params_billions: float  # numeric, 0.0 if unknown
    quantization: str       # e.g. "Q4_K_M", "F16", "n/a"
    size_bytes: int         # disk size
    family: str             # e.g. "gemma3", "qwen2", "anthropic"
    cost_per_1k: float      # $ per 1K tokens (0.0 for local)
    is_local: bool          # True for Ollama models

    @property
    def display_name(self) -> str:
        if self.is_local:
            return f"ollama/{self.name}"
        return self.name

    @property
    def size_human(self) -> str:
        gb = self.size_bytes / (1024 ** 3)
        if gb >= 1.0:
            return f"{gb:.1f}GB"
        mb = self.size_bytes / (1024 ** 2)
        return f"{mb:.0f}MB"


@dataclass
class RoutingTable:
    """Current routing assignments per task tier."""
    deterministic: str = "code_only"
    simple: str = "haiku"
    judgment: str = "sonnet"
    complex: str = "opus"
    last_updated: float = 0.0
    local_models: list = field(default_factory=list)
    cloud_models: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "deterministic": self.deterministic,
            "simple": self.simple,
            "judgment": self.judgment,
            "complex": self.complex,
        }


# Module-level state
_routing_table: Optional[RoutingTable] = None
_discovered_models: list[ModelInfo] = []
_last_discovery: float = 0.0
_CACHE_TTL = 300  # 5 minutes


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

def _parse_param_size(param_str: str) -> float:
    """Parse '27.4B' or '23M' into billions as a float."""
    if not param_str:
        return 0.0
    param_str = param_str.strip().upper()
    try:
        if param_str.endswith("B"):
            return float(param_str[:-1])
        if param_str.endswith("M"):
            return float(param_str[:-1]) / 1000.0
        if param_str.endswith("K"):
            return float(param_str[:-1]) / 1_000_000.0
        return float(param_str)
    except (ValueError, TypeError):
        return 0.0


def _should_skip_model(name: str, family: str) -> bool:
    """Return True if this model isn't a general-purpose LLM."""
    if family.lower() in _SKIP_FAMILIES:
        return True
    name_lower = name.lower()
    return any(pat in name_lower for pat in _SKIP_NAME_PATTERNS)


def _probe_ollama() -> list[ModelInfo]:
    """Query Ollama API for available models. Returns [] on failure."""
    try:
        # Defense-in-depth: re-validate at call time in case the module-level
        # constant was patched after import (e.g. monkeypatching in tests).
        safe_base = _validate_ollama_url(OLLAMA_BASE_URL)
        req = urllib.request.Request(
            f"{safe_base}/api/tags",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        log.debug("Ollama probe failed: %s", e)
        return []

    models = []
    for m in data.get("models", []):
        name = m.get("name", "")
        details = m.get("details", {})
        family = details.get("family", "unknown")

        if _should_skip_model(name, family):
            continue

        param_str = details.get("parameter_size", "")
        params_b = _parse_param_size(param_str)

        models.append(ModelInfo(
            name=name,
            provider="ollama",
            parameter_size=param_str or "unknown",
            params_billions=params_b,
            quantization=details.get("quantization_level", "unknown"),
            size_bytes=m.get("size", 0),
            family=family,
            cost_per_1k=0.0,
            is_local=True,
        ))

    # Sort by parameter count ascending (cheapest first = smallest first)
    models.sort(key=lambda x: x.params_billions)
    return models


def _get_cloud_models() -> list[ModelInfo]:
    """Return static list of known cloud models."""
    return [
        ModelInfo(
            name=name,
            provider=info["provider"],
            parameter_size="n/a",
            params_billions=0.0,
            quantization="n/a",
            size_bytes=0,
            family="anthropic",
            cost_per_1k=info["cost_per_1k"],
            is_local=False,
        )
        for name, info in CLOUD_MODELS.items()
    ]


def discover_models(force: bool = False) -> list[ModelInfo]:
    """
    Discover all available models (local Ollama + cloud).

    Results are cached for _CACHE_TTL seconds unless force=True.

    Returns:
        List of ModelInfo sorted: local models first (by param size asc),
        then cloud models (by cost asc).
    """
    global _discovered_models, _last_discovery

    now = time.time()
    if not force and _discovered_models and (now - _last_discovery) < _CACHE_TTL:
        return list(_discovered_models)

    local = _probe_ollama()
    cloud = _get_cloud_models()

    _discovered_models = local + cloud
    _last_discovery = now

    log.info("Discovered %d local + %d cloud models", len(local), len(cloud))
    return list(_discovered_models)


# ---------------------------------------------------------------------------
# Model selection
# ---------------------------------------------------------------------------

def _pick_local_for_tier(models: list[ModelInfo], tier: str) -> Optional[str]:
    """Pick the best local model for a task tier.

    For 'simple': smallest available model (cheapest).
    For 'judgment': largest model with >= 10B params (most capable local).
    """
    local = [m for m in models if m.is_local]
    if not local:
        return None

    if tier == "simple":
        # Smallest first — already sorted by params_billions asc
        return f"ollama/{local[0].name}"

    if tier == "judgment":
        # Need 10B+ for judgment quality — pick largest available
        capable = [m for m in local if m.params_billions >= _TIER_MIN_PARAMS_B["judgment"]]
        if capable:
            # Largest = last in ascending sort
            return f"ollama/{capable[-1].name}"
        return None

    return None


def _load_user_overrides() -> dict:
    """Load user routing overrides from model.toml config.

    Only returns entries the user has explicitly set in their config file.
    Defaults from DEFAULT_ROUTING are NOT treated as overrides — they would
    defeat the purpose of dynamic routing.
    """
    try:
        from aibrain.tools.model.config import (
            load_config, DEFAULT_ROUTING, _CONFIG_PATH,
        )
        if not _CONFIG_PATH.exists():
            return {}
        cfg = load_config()
        routing_cfg = cfg.get("model", {}).get("routing", {})
        # Only include values the user explicitly wrote in their config file
        # that differ from the static defaults
        overrides = {}
        for tier, val in routing_cfg.items():
            if val != DEFAULT_ROUTING.get(tier):
                overrides[tier] = val
        return overrides
    except Exception:
        return {}


def select_model(task_type: str, complexity: Optional[float] = None) -> str:
    """
    Select the optimal model for a given task type and optional complexity score.

    Args:
        task_type: One of 'deterministic', 'simple', 'judgment', 'complex'.
        complexity: Optional 0.0-1.0 score. If provided and > 0.7 for a
                    'judgment' task, it gets promoted to 'complex'.

    Returns:
        Model identifier string:
          "code_only"          — deterministic, no LLM
          "ollama/<model>"     — local model via Ollama
          "haiku"              — Claude Haiku (cloud, cheap)
          "sonnet"             — Claude Sonnet (cloud, mid)
          "opus"               — Claude Opus (cloud, best)
    """
    task_type = task_type.lower().strip()

    # Complexity-based promotion: high-complexity judgment -> complex
    if complexity is not None and complexity > 0.7 and task_type == "judgment":
        task_type = "complex"
        log.debug("Promoted judgment -> complex (complexity=%.2f)", complexity)

    # Check user overrides first — if user explicitly set a tier, respect it
    overrides = _load_user_overrides()
    user_choice = overrides.get(task_type)
    if user_choice and user_choice != "local":
        # User explicitly chose a specific model (not "local" placeholder)
        if user_choice == "code_only":
            return "code_only"
        return user_choice

    # Deterministic: never needs a model
    if task_type == "deterministic":
        return "code_only"

    # Discover available models
    models = discover_models()

    # Simple: try local first, fall back to haiku
    if task_type == "simple":
        local = _pick_local_for_tier(models, "simple")
        if local:
            log.debug("SIMPLE -> %s (local, $0)", local)
            return local
        return "haiku"

    # Judgment: try large local model, fall back to sonnet
    if task_type == "judgment":
        if user_choice == "local":
            # User explicitly wants local for judgment
            local = _pick_local_for_tier(models, "judgment")
            if local:
                log.debug("JUDGMENT -> %s (local, user override)", local)
                return local
        # Default: try local large model first
        local = _pick_local_for_tier(models, "judgment")
        if local:
            log.debug("JUDGMENT -> %s (local 10B+, $0)", local)
            return local
        return "sonnet"

    # Complex: always cloud (quality is paramount)
    if task_type == "complex":
        return "opus"

    # Unknown task type — safe default
    log.warning("Unknown task type '%s' — defaulting to sonnet", task_type)
    return "sonnet"


# ---------------------------------------------------------------------------
# Routing table management
# ---------------------------------------------------------------------------

def update_routing_table() -> RoutingTable:
    """
    Refresh the routing table by re-probing Ollama and rebuilding assignments.

    Call this after pulling/removing Ollama models, or periodically.
    """
    global _routing_table

    # Force fresh discovery
    models = discover_models(force=True)

    local_models = [m for m in models if m.is_local]
    cloud_models = [m for m in models if not m.is_local]

    table = RoutingTable(
        deterministic="code_only",
        simple=select_model("simple"),
        judgment=select_model("judgment"),
        complex=select_model("complex"),
        last_updated=time.time(),
        local_models=[m.name for m in local_models],
        cloud_models=[m.name for m in cloud_models],
    )

    _routing_table = table
    log.info("Routing table updated: simple=%s, judgment=%s, complex=%s",
             table.simple, table.judgment, table.complex)
    return table


def get_routing_table() -> RoutingTable:
    """Get the current routing table, building it if needed."""
    global _routing_table
    if _routing_table is None:
        return update_routing_table()
    return _routing_table


def invalidate_cache():
    """Force fresh discovery and routing on next call."""
    global _routing_table, _discovered_models, _last_discovery
    _routing_table = None
    _discovered_models = []
    _last_discovery = 0.0


# ---------------------------------------------------------------------------
# CLI: aibrain models
# ---------------------------------------------------------------------------

def _format_size(size_bytes: int) -> str:
    """Human-readable size."""
    if size_bytes == 0:
        return "cloud"
    gb = size_bytes / (1024 ** 3)
    if gb >= 1.0:
        return f"{gb:.1f}GB"
    mb = size_bytes / (1024 ** 2)
    return f"{mb:.0f}MB"


def cli_models(args: list[str] | None = None) -> int:
    """CLI entry point for `aibrain models`."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="aibrain models",
        description="Show available models and routing assignments",
    )
    parser.add_argument("--refresh", action="store_true",
                        help="Force re-probe of Ollama")
    parser.add_argument("--json", action="store_true", dest="as_json",
                        help="Output as JSON")
    parsed = parser.parse_args(args or [])

    if parsed.refresh:
        invalidate_cache()

    models = discover_models(force=parsed.refresh)
    table = get_routing_table()

    if parsed.as_json:
        import json as _json
        data = {
            "routing": table.as_dict(),
            "models": [
                {
                    "name": m.display_name,
                    "provider": m.provider,
                    "params": m.parameter_size,
                    "params_b": m.params_billions,
                    "quantization": m.quantization,
                    "size": _format_size(m.size_bytes),
                    "cost_per_1k": m.cost_per_1k,
                    "local": m.is_local,
                }
                for m in models
            ],
        }
        print(_json.dumps(data, indent=2))
        return 0

    # Pretty print
    local = [m for m in models if m.is_local]
    cloud = [m for m in models if not m.is_local]

    print()
    print("  Available Models")
    print("  " + "-" * 55)

    if local:
        print()
        print("  Local (Ollama) — $0/token:")
        for m in local:
            print(f"    {m.name:<28} {m.parameter_size:>8}  {m.quantization:<8}  {_format_size(m.size_bytes):>7}")
    else:
        print()
        print("  Local: Ollama not available")

    if cloud:
        print()
        print("  Cloud (Anthropic):")
        for m in cloud:
            cost_str = f"${m.cost_per_1k:.5f}/1K tok"
            print(f"    {m.name:<28} {cost_str}")

    print()
    print("  Routing Table")
    print("  " + "-" * 55)

    tier_desc = {
        "deterministic": "no LLM needed",
        "simple": "fast + cheap",
        "judgment": "balanced reasoning",
        "complex": "maximum quality",
    }
    for tier in ("deterministic", "simple", "judgment", "complex"):
        model = getattr(table, tier)
        cost = "$0" if model.startswith("ollama/") or model == "code_only" else "cloud"
        desc = tier_desc.get(tier, "")
        print(f"    {tier:<16} -> {model:<28} ({cost}) {desc}")

    print()
    return 0
