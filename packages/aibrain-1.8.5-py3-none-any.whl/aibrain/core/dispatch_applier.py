"""Dispatch output applier for DeckerOps.

Applies code changes (unified diffs and FILE: blocks) from DeepSeek dispatch
output to the filesystem, with tiered fallback and atomic revert.
"""

import os
import re
import subprocess
import logging

_log = logging.getLogger(__name__)


def _find_git_root_for_path(abs_path: str):
    """Walk up from abs_path to find its enclosing git repository root."""
    check = abs_path if os.path.isdir(abs_path) else os.path.dirname(abs_path)
    while check and check != os.path.dirname(check):
        try:
            r = subprocess.run(
                ['git', 'rev-parse', '--show-toplevel'],
                cwd=check, capture_output=True, text=True,
            )
            if r.returncode == 0:
                return r.stdout.strip()
        except Exception:
            pass
        check = os.path.dirname(check)
    return None


def _rewrite_diff_paths(diff_text: str, old_rel: str, new_rel: str) -> str:
    """Rewrite --- a/OLD and +++ b/OLD headers to use new_rel."""
    diff_text = diff_text.replace(f'--- a/{old_rel}', f'--- a/{new_rel}')
    diff_text = diff_text.replace(f'+++ b/{old_rel}', f'+++ b/{new_rel}')
    diff_text = diff_text.replace(f'--- /{old_rel}', f'--- a/{new_rel}')
    diff_text = diff_text.replace(f'+++ /{old_rel}', f'+++ b/{new_rel}')
    return diff_text


# Environment configuration
# SA-2026-002 F-09: default flipped from "tiered" to "none" — callers that want
# auto-apply must opt in via AIBRAIN_DISPATCH_APPLY_MODE=tiered (or pass tiered
# in their dispatch invocation). Defense-in-depth alongside F-03 (deny-list) and
# F-30 (path-resolution bypass).
APPLY_MODE = os.environ.get("AIBRAIN_DISPATCH_APPLY_MODE", "none")
LLM_TIMEOUT_SECONDS = 120
LLM_CONFIDENCE_FLOOR = 0.7

# SA-2026-002 / F-03 fix: deny-list of paths that an LLM-generated diff is
# never permitted to modify. These are the gate files / security primitives /
# build configs whose tampering would let a prompt-injected dispatch escape
# the gate or persist beyond the immediate task.
#
# Match is by suffix (relative path normalised to forward slashes), so any
# diff whose target ends with one of these strings is refused. Wildcards are
# matched separately by `_DENY_PATH_PATTERNS` below.
# F-LUCY-SELF-EDIT-CARVEOUT-1: paths Lucy can edit from her own loop (not dispatch)
_SELF_EDIT_CARVEOUT_PATHS = frozenset({
    "aibrain/lucy_agent.py",
})

def _self_edit_allowed(rel_path: str) -> bool:
    """Check if this path is a self-edit carve-out. Only allowed when
    AIBRAIN_SELF_EDIT_ALLOWED=1 AND the file is in the carve-out set.
    Origin must be Lucy's own loop, never dispatch_deepseek_task.
    """
    if os.environ.get("AIBRAIN_SELF_EDIT_ALLOWED", "") != "1":
        return False
    normalized = rel_path.replace(chr(92), '/').lower().lstrip('/')
    return normalized in _SELF_EDIT_CARVEOUT_PATHS


_DENY_PATH_SUFFIXES = (
    # Gate / security primitives
    "aibrain/core/companies.py",
    "aibrain/core/task_verification.py",
    "aibrain/core/dispatch_applier.py",
    "aibrain/core/the_hands.py",
    "aibrain/core/agent_dispatch.py",
    "aibrain/core/enforcement.py",
    "aibrain/core/secrets_filter.py",
    "backend/security.py",
    "backend/auth_routes.py",
    # Build / publish config
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "MANIFEST.in",
    # Secrets / env files (must never be applied)
    ".decker_env",
    ".aibrain.env",
    ".aibrain_env",
    ".env",
    ".env.local",
    ".env.production",
    # SA-2026-002 F-16: privileged installers + runtime entry points
    "aibrain/mcp/server.py",
    "aibrain/setup_wizard.py",
    "aibrain/cli/setup_wizard.py",
    "install.py",
    "aibrain/core/lucy_loop.py",
    "aibrain/core/hands_bridge.py",
    "aibrain/cli/oneshot_install.py",
    "aibrain/tools/compress/hook.py",
)

# Pattern-matched deny-list (regex against the relative path).
_DENY_PATH_PATTERNS = (
    re.compile(r"^\.github/workflows/.+\.ya?ml$"),  # CI definitions
    re.compile(r"^\.git/"),                          # git internals
    re.compile(r"^scripts/install\.(ps1|sh|bash)$"), # installer scripts
    re.compile(r".+/_internal/"),                    # vendored / wheel-bundled
    re.compile(r".+\.pyd$|.+\.so$|.+\.dll$"),       # compiled binaries
    # SA-2026-002 F-23: persistence-shaped paths
    re.compile(r"^decker_system/04_tools/git_hooks/"),  # auto-installed git hooks
    re.compile(r"^aibrain/skills/"),                    # skill registry / persistence
    re.compile(r"^aibrain/integrations/"),              # auto-loaded integrations
    re.compile(r"^aibrain/mcp/adapters/"),              # MCP adapter persistence
    re.compile(r"^Dockerfile$"),                        # container build
    re.compile(r"^deploy/"),                            # deploy templates
    re.compile(r"^seed_memories\.json$"),               # memory provenance attack
    re.compile(r"^scripts/pre_commit_hook\.py$"),       # pre-commit hook
)


def _is_path_denied(relpath: str) -> tuple:
    """SA-2026-002 / F-03: refuse diffs that target gate / security / build files.

    Returns (is_denied, matched_rule). Caller raises DispatchApplyFailed when
    is_denied is True. Path is normalised to forward slashes before matching.
    """
    if not relpath:
        return True, "empty path"
    # Normalise: forward slashes only; strip a SINGLE leading "./" (not lstrip,
    # which would eat leading '.' from filenames like .decker_env).
    norm = relpath.replace("\\", "/")
    if norm.startswith("./"):
        norm = norm[2:]
    # Reject absolute paths and parent-traversal — diffs must be in-tree
    if norm.startswith("/") or "../" in norm or norm.startswith(".."):
        return True, f"out-of-tree path {relpath!r}"
    # SA-2026-002 F-17: canonicalise to defeat Windows-specific bypass mutations.
    # Five mutations defeated:
    #   - mixed case          (Windows is case-insensitive)
    #   - trailing dot        (Windows truncates trailing dots)
    #   - trailing whitespace (Windows trims trailing space)
    #   - repeated slashes    (collapse a//b to a/b)
    #   - embedded ./         (collapse a/./b to a/b)
    # Apply to a separate `match_path` so error messages still show the original.
    match_path = norm.lower()
    match_path = match_path.rstrip(". \t")
    while "//" in match_path:
        match_path = match_path.replace("//", "/")
    while "/./" in match_path:
        match_path = match_path.replace("/./", "/")
    # Per-segment trailing dot/whitespace strip (e.g., 'aibrain/core/the_hands.py./more')
    match_path = "/".join(seg.rstrip(". \t") for seg in match_path.split("/"))
    # Suffix match against deny-list (case-insensitive — deny-list is canonical lowercase)
    # F-LUCY-SELF-EDIT-CARVEOUT-1: self-edit allowed bypass
    if _self_edit_allowed(match_path):
        return False, ""
    for suffix in _DENY_PATH_SUFFIXES:
        if match_path.endswith(suffix.lower()) or match_path == suffix.lower():
            return True, f"deny-list suffix match: {suffix}"
    # Pattern match (regex on canonicalised path)
    for pat in _DENY_PATH_PATTERNS:
        if pat.match(match_path):
            return True, f"deny-list pattern match: {pat.pattern}"
    return False, ""

# _REPO_ROOT resolution (M6)
def _resolve_repo_root():
    """Find the git repository root where patches should be applied.
    
    Tries candidate from package location, then fallback to CWD.
    Returns path or None if no git repo found.
    """
    # Try candidate derived from this file's location
    candidate = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--show-toplevel'],
            cwd=candidate,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    # Fallback to current working directory
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--show-toplevel'],
            cwd=os.getcwd(),
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    # F-DISPATCH-APPLIER-GIT-ROOT-1: fallback to AIBRAIN_PROJECT_ROOT env
    _env_root = os.environ.get("AIBRAIN_PROJECT_ROOT", "")
    if _env_root:
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--show-toplevel'],
                cwd=_env_root,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass

    _log.error("Cannot determine git repo root; applier disabled")
    return None

_REPO_ROOT = _resolve_repo_root()

from aibrain.core.companies import DispatchApplyFailed


def apply_dispatch_output(task_id: str, work_output_text: str) -> dict:
    """
    Parse the work_output and apply all code changes to the repo.
    Returns a success dict or raises DispatchApplyFailed on failure.
    """
    if _REPO_ROOT is None:
        raise DispatchApplyFailed(task_id, [], ["No git repo found to apply patches"])
    if APPLY_MODE == 'none':
        return {"applied": True, "applied_files": [], "errors": None}

    # F-DSML-PARSER-DROPOUT-FIX-1: DSML-aware pre-pass.
    # DeepSeek sometimes emits tool calls as DSML pseudo-XML (e.g.
    # <|||DSML|||invoke name="Read">...) instead of FILE: / unified-diff
    # blocks that this applier understands. Previously this fell through
    # silently — extract_blocks returned [], the applier returned success
    # with applied_files=[], and the gate passed (HNLmincCC4E: CHANGELOG
    # dispatch silent-passed but never wrote the file).
    # Pragmatic v1: fail LOUDLY so the gate FAILs, forcing prompts to
    # steer toward FILE: blocks. A DSML -> file-op bridge is future work.
    _dsml_marker_re = re.compile(
        r'<[│｜|]*(?:DSML[│｜|]*)?invoke\s+name='
    )
    if _dsml_marker_re.search(work_output_text):
        err = (
            "DSML tool-call format from DeepSeek detected; dispatch_applier "
            "cannot apply DSML invokes - see F-DSML-PARSER-DROPOUT-FIX-1. "
            "Re-prompt to emit FILE: blocks or unified diffs instead."
        )
        _log.error("dispatch_applier: %s", err)
        raise DispatchApplyFailed(task_id, [], [err])

    blocks = extract_blocks(work_output_text)
    if not blocks:
        return {"applied": True, "applied_files": [], "errors": None}
    
    applied_entries = []  # list of (relpath, existed_before, tracked_before)
    errors = []
    
    try:
        for blk in blocks:
            # SA-2026-002 / F-03 fix: deny-list pre-check on every block before
            # apply. Refuses diffs / FILE blocks that target gate / security /
            # build / secrets files. Raises DispatchApplyFailed with a clear
            # reason so the caller knows WHY the dispatch was rejected.
            blk_path = blk.get('filepath') or ''
            denied, reason = _is_path_denied(blk_path)
            if denied:
                err = f"refused by F-03 deny-list: {blk_path!r} ({reason})"
                _log.error("dispatch_applier: %s", err)
                errors.append(err)
                raise DispatchApplyFailed(task_id, [], errors)
            # SA-2026-002 F-31: also check destination path. An attacker may have
            # submitted a benign --- a/ source with a denied +++ b/ destination,
            # bypassing the source-only check above. Refuse if either is denied.
            _dest_path = blk.get('dest_filepath')
            if _dest_path:
                _dest_denied, _dest_reason = _is_path_denied(_dest_path)
                if _dest_denied:
                    err = f"refused by F-31 dest-path deny-list: {_dest_path!r} ({_dest_reason})"
                    _log.error("dispatch_applier: %s", err)
                    errors.append(err)
                    raise DispatchApplyFailed(task_id, [], errors)
            if blk['type'] == 'diff':
                success, error = _apply_diff(task_id, blk)
            elif blk['type'] == 'file':
                success, error = _apply_file_block(task_id, blk)
            else:
                continue
            if not success:
                errors.append(error)
                raise DispatchApplyFailed(task_id, [], errors)
            filepath = blk['filepath']
            full_path = os.path.join(_REPO_ROOT, filepath)
            existed_before = os.path.exists(full_path)
            tracked_before = _is_tracked(filepath)
            applied_entries.append((filepath, existed_before, tracked_before))
        
        return {
            "applied": True,
            "applied_files": [e[0] for e in applied_entries],
            "errors": None
        }
    except DispatchApplyFailed:
        _revert_applied_entries(applied_entries)
        raise
    except Exception as e:
        _revert_applied_entries(applied_entries)
        errors.append(str(e))
        raise DispatchApplyFailed(task_id, [e[0] for e in applied_entries], errors) from e


def extract_blocks(text: str) -> list:
    """Extract diff and FILE blocks from dispatch output text.

    SA-2026-002 F-42 (V-09): Pass 1 uses a line-based scanner with fence-depth
    counting. Replaces the prior DOTALL regex that swallowed following blocks
    via internal-fence-ambiguity (a benign FILE block whose content contained
    a nested ```lang ... ``` example would terminate at the FIRST bare ```,
    leaving the rest as orphaned text re-parsable as a malicious FILE block
    that escaped the deny-list).

    The line-based scanner counts ```lang opens (depth+=1) and bare ```
    closes (depth-=1). A FILE block ends only when depth returns to 0 at a
    bare close fence — nested fences are correctly nested instead of
    truncating the outer block.
    """
    blocks = []
    lines = text.splitlines(keepends=True)
    n = len(lines)

    # SA-2026-002 F-42: fence-depth scanner regexes
    _fence_re = re.compile(r'^[ \t]*```([^\n]*?)[ \t]*$')
    _file_start_re = re.compile(r'^FILE:\s*(.+?)\s*$')

    consumed = set()  # line indices already absorbed into a FILE block

    i = 0
    while i < n:
        m_file = _file_start_re.match(lines[i].rstrip("\n"))
        if not m_file:
            i += 1
            continue
        block_start = i
        raw_path = m_file.group(1).strip()
        i += 1
        if i >= n:
            break
        m_open = _fence_re.match(lines[i].rstrip("\n"))
        if not m_open:
            # No opening fence — not a valid FILE block, leave for Pass 2
            i += 1
            continue
        fence_lang = m_open.group(1).strip().lower()
        i += 1
        depth = 1
        content_lines = []
        while i < n and depth > 0:
            line_s = lines[i].rstrip("\n")
            m_fence = _fence_re.match(line_s)
            if m_fence:
                lang_tag = m_fence.group(1).strip()
                if lang_tag == "":
                    depth -= 1
                    if depth == 0:
                        i += 1  # consume bare close, do NOT include in content
                        break
                    content_lines.append(lines[i])
                    i += 1
                    continue
                else:
                    depth += 1
                    content_lines.append(lines[i])
                    i += 1
                    continue
            content_lines.append(lines[i])
            i += 1

        if depth != 0:
            # Unterminated FILE block — leave the lines unconsumed; Pass 2 may
            # still extract diff content from them. Safer than producing a
            # block with truncated content.
            continue

        content = "".join(content_lines)
        for k in range(block_start, i):
            consumed.add(k)

        suspicious_path = ' (' in raw_path or ' [' in raw_path
        first_content_line = next((l for l in content.splitlines() if l.strip()), '')
        is_diff_content = first_content_line.startswith(('--- a/', '--- /dev/null', '+++ b/', '@@ '))
        is_diff_fence = fence_lang in ('diff', 'patch', 'udiff')

        if fence_lang == 'diff' or is_diff_content or (suspicious_path and is_diff_fence):
            plus_match = re.search(r'^\+\+\+ b/(.+)$', content, re.MULTILINE)
            real_path = plus_match.group(1).strip() if plus_match else raw_path.split(' (')[0].strip()
            blocks.append({"type": "diff", "filepath": real_path, "content": content})
        else:
            blocks.append({"type": "file", "filepath": raw_path, "content": content})

    # Pass 2 input: text minus consumed FILE block lines
    remaining_lines = [lines[k] for k in range(n) if k not in consumed]
    remaining = "".join(remaining_lines)

    # Pass 2: strip bare fence lines from diff sections, then parse diffs.
    # FILE: blocks already consumed above — remaining contains only diffs.
    remaining = re.sub(r'(?m)^```[a-zA-Z]*\s*$', '', remaining)
    lines = remaining.splitlines(keepends=True)
    i = 0
    while i < len(lines):
        line = lines[i]
        _is_abs_path = line.startswith("--- /") and not line.startswith("--- /dev/null")
        if line.startswith("--- a/") or line.startswith("--- /dev/null") or _is_abs_path:
            # Diff block
            if line.startswith("--- a/"):
                filepath = line[6:].strip()
            elif _is_abs_path:
                # Absolute path format: --- /root/some/repo/file.py
                # Strip leading slash to get a repo-relative-ish path;
                # _apply_unified_diff_via_git resolves the correct git root.
                filepath = line[4:].strip().lstrip('/')
            else:
                filepath = line[13:].strip()
            diff_lines = [line]
            i += 1
            dest_filepath = None  # SA-2026-002 F-31: capture +++ b/ destination path
            if i < len(lines) and lines[i].startswith("+++ "):
                _plus_line = lines[i].rstrip("\n")
                if _plus_line.startswith("+++ b/"):
                    dest_filepath = _plus_line[6:].strip()
                elif _plus_line.startswith("+++ /") and not _plus_line.startswith("+++ /dev/null"):
                    dest_filepath = _plus_line[4:].strip().lstrip("/")
                # /dev/null destination = file deletion; nothing to deny-check
                diff_lines.append(lines[i])
                i += 1
            else:
                continue
            # Gather hunks
            while i < len(lines):
                cur = lines[i]
                if cur.startswith("@@"):
                    diff_lines.append(cur)
                    i += 1
                    # Context lines until next diff/file header or EOF
                    while i < len(lines) and not (
                        lines[i].startswith("--- a/") or
                        lines[i].startswith("--- /dev/null") or
                        lines[i].startswith("FILE:")
                    ):
                        stripped = lines[i].strip()
                        if stripped.startswith("\\ ") and "No newline" in stripped:
                            i += 1
                            continue
                        diff_lines.append(lines[i])
                        i += 1
                    break
                elif cur.startswith("FILE:") or cur.startswith("--- "):
                    break
                else:
                    i += 1
                    break
            content = "".join(diff_lines)
            # SA-2026-002 F-31: include dest_filepath so apply_dispatch_output can deny-check
            # both --- a/ source and +++ b/ destination, defeating same-hunk path-mismatch attacks.
            blocks.append({
                "type": "diff",
                "filepath": filepath,
                "content": content,
                "dest_filepath": dest_filepath,
            })
            continue

        i += 1
    return blocks


def _apply_diff(task_id, blk):
    diff_text = blk['content']
    filepath = blk['filepath']
    success, error = _apply_unified_diff_via_git(diff_text, filepath, fallback=False)
    if success:
        return True, None
    success, error = _apply_unified_diff_via_git(diff_text, filepath, fallback=True)
    if success:
        return True, None
    # Tier 3: GNU patch with fuzz — lenient about off-by-one hunk line counts
    # which LLMs frequently generate even when the content is correct.
    success, error = _apply_via_patch(diff_text, filepath)
    if success:
        return True, None
    llm_result = _apply_via_llm(filepath, diff_text, task_id)
    if llm_result.get('applied'):
        return True, None
    return False, f"All tiers failed for {filepath}: {error or 'LLM stub failed'}"


def _apply_unified_diff_via_git(diff_text, filepath, fallback):
    # Resolve which git repo to apply this patch in.
    # LLMs often output paths relative to filesystem root (e.g. root/proj/file.py)
    # rather than relative to the aibrain repo.  If the file doesn't exist under
    # _REPO_ROOT, try prepending '/' — if that exists, find its git root and
    # rewrite the diff headers so git apply can locate the file.
    apply_cwd = _REPO_ROOT
    full_in_repo = os.path.join(_REPO_ROOT, filepath) if _REPO_ROOT else None
    if full_in_repo and not os.path.exists(full_in_repo):
        # Try candidate paths in order: /filepath, /root/filepath, HOME/filepath
        _candidates = [
            os.path.join('/', filepath),
            os.path.join('/root', filepath),
            os.path.join(os.path.expanduser('~'), filepath),
        ]
        for abs_candidate in _candidates:
            if os.path.exists(abs_candidate):
                # SA-2026-002 F-30: refuse candidate paths that resolve outside AIBRAIN repo
                _real_candidate = os.path.realpath(os.path.abspath(abs_candidate))
                _real_repo = os.path.realpath(os.path.abspath(_REPO_ROOT)) if _REPO_ROOT else None
                if not _real_repo or not (
                    _real_candidate == _real_repo
                    or _real_candidate.startswith(_real_repo + os.sep)
                ):
                    # Candidate resolves outside AIBrain repo — refuse silently and continue
                    continue
                git_root = _find_git_root_for_path(abs_candidate)
                if git_root:
                    # SA-2026-002 F-30: re-check the rewritten relative path against deny-list
                    new_rel = os.path.relpath(abs_candidate, git_root)
                    _denied, _reason = _is_path_denied(new_rel)
                    if _denied:
                        # Resolved path resolves into a deny-listed file — refuse
                        continue
                    diff_text = _rewrite_diff_paths(diff_text, filepath, new_rel)
                    filepath = new_rel
                    apply_cwd = git_root
                    break

    cmd = ['git', 'apply', '--binary']
    if fallback:
        cmd.append('--3way')
    try:
        proc = subprocess.run(
            cmd,
            cwd=apply_cwd,
            input=diff_text,
            capture_output=True,
            text=True,
            encoding='utf-8',
        )
        if proc.returncode == 0:
            return True, None
        return False, proc.stderr.strip() if proc.stderr else 'git apply returned non-zero'
    except Exception as e:
        return False, str(e)


def _apply_file_block(task_id, blk):
    filepath = blk['filepath']
    content = blk['content']
    full_path = os.path.join(_REPO_ROOT, filepath)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    try:
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return True, None
    except Exception as e:
        return False, str(e)


def _is_tracked(relpath):
    try:
        result = subprocess.run(
            ['git', 'ls-files', '--error-unmatch', relpath],
            cwd=_REPO_ROOT,
            capture_output=True,
        )
        return result.returncode == 0
    except Exception:
        return False


def _revert_applied_entries(entries):
    for filepath, existed_before, tracked_before in reversed(entries):
        full_path = os.path.join(_REPO_ROOT, filepath)
        if not existed_before:
            try:
                os.unlink(full_path)
            except Exception:
                pass
        else:
            if tracked_before:
                try:
                    subprocess.run(['git', 'checkout', 'HEAD', '--', filepath], cwd=_REPO_ROOT, check=True)
                except Exception:
                    pass
            # else untracked existed before, no way to recover, leave as is


def _apply_via_patch(diff_text: str, filepath: str):
    """Tier 3: GNU patch -p1 --fuzz=0.

    Handles diffs with off-by-one hunk line counts that git apply rejects as
    'corrupt patch'. Uses the same apply_cwd resolution as _apply_unified_diff_via_git.
    """
    apply_cwd = _REPO_ROOT
    full_in_repo = os.path.join(_REPO_ROOT, filepath) if _REPO_ROOT else None
    if full_in_repo and not os.path.exists(full_in_repo):
        _candidates = [
            os.path.join('/', filepath),
            os.path.join('/root', filepath),
            os.path.join(os.path.expanduser('~'), filepath),
        ]
        for abs_candidate in _candidates:
            if os.path.exists(abs_candidate):
                # SA-2026-002 F-30: refuse candidate paths that resolve outside AIBRAIN repo
                _real_candidate = os.path.realpath(os.path.abspath(abs_candidate))
                _real_repo = os.path.realpath(os.path.abspath(_REPO_ROOT)) if _REPO_ROOT else None
                if not _real_repo or not (
                    _real_candidate == _real_repo
                    or _real_candidate.startswith(_real_repo + os.sep)
                ):
                    # Candidate resolves outside AIBrain repo — refuse silently and continue
                    continue
                git_root = _find_git_root_for_path(abs_candidate)
                if git_root:
                    # SA-2026-002 F-30: re-check the rewritten relative path against deny-list
                    new_rel = os.path.relpath(abs_candidate, git_root)
                    _denied, _reason = _is_path_denied(new_rel)
                    if _denied:
                        # Resolved path resolves into a deny-listed file — refuse
                        continue
                    diff_text = _rewrite_diff_paths(diff_text, filepath, new_rel)
                    filepath = new_rel
                    apply_cwd = git_root
                    break

    try:
        # SA-2026-002 F-32: --fuzz=0 (was --fuzz=3) — silent misapplication via context-line
        # drift produced wrong-code-applied-at-wrong-position incidents. With fuzz=0, drift
        # forces re-dispatch (existing fallback) rather than silent corruption.
        proc = subprocess.run(
            ['patch', '-p1', '--fuzz=0', '--batch', '--no-backup-if-mismatch'],
            cwd=apply_cwd,
            input=diff_text,
            capture_output=True,
            text=True,
            encoding='utf-8',
        )
        if proc.returncode == 0:
            return True, None
        return False, proc.stderr.strip() or proc.stdout.strip() or 'patch returned non-zero'
    except FileNotFoundError:
        return False, 'patch command not found'
    except Exception as e:
        return False, str(e)


def _apply_via_llm(target_path, diff_text, task_id):
    return {"applied": False, "tier": None, "error": "LLM tier not yet implemented (v5 stub — full impl deferred)"}
