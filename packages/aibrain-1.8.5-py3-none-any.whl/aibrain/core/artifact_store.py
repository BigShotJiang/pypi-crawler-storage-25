"""aibrain.core.artifact_store — ArtifactStore for The Hands v1.

Implements ADR-003 (source-before-render guarantee), ADR-004 (namespace isolation),
ADR-005 (Crucible + marketplace metadata baked in day one) per
decker_system/00_meta/specs/the_hands_v1_spec.md.

Usage:
    from aibrain.core.artifact_store import ArtifactStore, ArtifactMetadata

    store = ArtifactStore()  # default ~/.aibrain/artifacts/
    art_id = 'abc123'
    store.save_source(art_id, namespace='aibrain', code=b'<source bytes>', extension='py')
    store.save_render(art_id, namespace='aibrain', data=b'<render bytes>', mimetype='image/png')
    meta = ArtifactMetadata(artifact_id=art_id, type='tool', namespace='aibrain', ...)
    store.put_artifact(meta)
    fetched = store.get_artifact(art_id, namespace='aibrain')
    matches = store.find_artifacts(namespace='aibrain', type='tool')
"""

from __future__ import annotations
import os
import json
import sqlite3
import time
import datetime
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional


class ArtifactStoreError(Exception):
    pass


class SourceNotSavedError(ArtifactStoreError):
    """Raised when save_render is attempted without a prior save_source for the same artifact_id."""
    pass


class ArtifactNotFoundError(ArtifactStoreError):
    pass


@dataclass
class ArtifactMetadata:
    """Schema for artifact metadata. Nullable fields support Crucible + marketplace forward-compat."""
    artifact_id: str
    type: str  # 'tool' | 'graph' | 'mockup' | 'video' | 'component' | 'other'
    namespace: str  # 'aibrain' | 'rogue' | 'paragon' | 'marketplace' | <third-party-id>
    source_path: Optional[str] = None  # filesystem path
    render_path: Optional[str] = None
    prompt_history: List[str] = field(default_factory=list)
    parent_artifact_id: Optional[str] = None
    origin_round: Optional[int] = None
    battle_id: Optional[str] = None
    success_history: List[Dict[str, Any]] = field(default_factory=list)
    curation_state: str = 'quarantined'  # quarantined | approved_for_replay | approved_for_export | approved_for_marketplace
    license: Optional[str] = None
    attribution: Optional[str] = None
    version: str = '1.0.0'
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    extras: Dict[str, Any] = field(default_factory=dict)  # Forward-compat extension column


_SCHEMA = '''
CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id TEXT NOT NULL,
    namespace TEXT NOT NULL,
    type TEXT NOT NULL,
    source_path TEXT,
    render_path TEXT,
    prompt_history TEXT,           -- JSON array
    parent_artifact_id TEXT,
    origin_round INTEGER,
    battle_id TEXT,
    success_history TEXT,          -- JSON array
    curation_state TEXT NOT NULL DEFAULT 'quarantined',
    license TEXT,
    attribution TEXT,
    version TEXT NOT NULL DEFAULT '1.0.0',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    extras TEXT,                   -- JSON object
    PRIMARY KEY (artifact_id, namespace)
);
CREATE INDEX IF NOT EXISTS idx_artifacts_namespace_type ON artifacts(namespace, type);
CREATE INDEX IF NOT EXISTS idx_artifacts_parent ON artifacts(parent_artifact_id);
CREATE INDEX IF NOT EXISTS idx_artifacts_curation ON artifacts(curation_state);

CREATE TABLE IF NOT EXISTS source_saved (
    artifact_id TEXT NOT NULL,
    namespace TEXT NOT NULL,
    saved_at TEXT NOT NULL,
    extension TEXT NOT NULL,
    bytes_len INTEGER NOT NULL,
    PRIMARY KEY (artifact_id, namespace)
);
'''


class ArtifactStore:
    """Stores artifact metadata (SQLite) + source/render files (filesystem).

    Enforces source-before-render guarantee. Namespace-isolated by default; promotion is explicit.
    """

    DEFAULT_BASE_PATH = Path.home() / '.aibrain' / 'artifacts'

    def __init__(self, base_path: Optional[Path] = None, db_path: Optional[Path] = None):
        self.base_path = Path(base_path) if base_path else self.DEFAULT_BASE_PATH
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.db_path = Path(db_path) if db_path else (self.base_path / 'metadata.db')
        self._init_schema()

    def _init_schema(self) -> None:
        conn = sqlite3.connect(str(self.db_path))
        try:
            conn.executescript(_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    def _path_for(self, artifact_id: str, namespace: str, kind: str, extension: str) -> Path:
        """Compute filesystem path for source/render files. Creates parent dir."""
        d = self.base_path / namespace / artifact_id
        d.mkdir(parents=True, exist_ok=True)
        return d / f"{kind}.{extension}"

    def save_source(self, artifact_id: str, namespace: str, code: bytes, extension: str = 'py') -> str:
        """Save artifact source bytes. MUST be called before save_render for the same artifact_id."""
        path = self._path_for(artifact_id, namespace, 'source', extension)
        path.write_bytes(code)
        conn = sqlite3.connect(str(self.db_path))
        try:
            now = _now_iso()
            conn.execute(
                "INSERT OR REPLACE INTO source_saved (artifact_id, namespace, saved_at, extension, bytes_len) VALUES (?, ?, ?, ?, ?)",
                (artifact_id, namespace, now, extension, len(code))
            )
            conn.commit()
        finally:
            conn.close()
        return str(path)

    def has_source(self, artifact_id: str, namespace: str) -> bool:
        conn = sqlite3.connect(str(self.db_path))
        try:
            row = conn.execute(
                "SELECT 1 FROM source_saved WHERE artifact_id = ? AND namespace = ?",
                (artifact_id, namespace)
            ).fetchone()
            return row is not None
        finally:
            conn.close()

    def save_render(self, artifact_id: str, namespace: str, data: bytes, mimetype: str = 'image/png', extension: Optional[str] = None) -> str:
        """Save artifact render bytes. Raises SourceNotSavedError if no prior save_source."""
        if not self.has_source(artifact_id, namespace):
            raise SourceNotSavedError(
                f"No source saved for artifact_id={artifact_id!r} namespace={namespace!r} — "
                f"call save_source() before save_render() per ADR-003 source-before-render guarantee."
            )
        ext = extension or _ext_from_mimetype(mimetype)
        path = self._path_for(artifact_id, namespace, 'render', ext)
        path.write_bytes(data)
        return str(path)

    def put_artifact(self, meta: ArtifactMetadata) -> None:
        """Insert or update full ArtifactMetadata row."""
        if meta.created_at is None:
            meta.created_at = _now_iso()
        meta.updated_at = _now_iso()
        conn = sqlite3.connect(str(self.db_path))
        try:
            conn.execute('''
                INSERT OR REPLACE INTO artifacts (
                    artifact_id, namespace, type, source_path, render_path,
                    prompt_history, parent_artifact_id, origin_round, battle_id,
                    success_history, curation_state, license, attribution, version,
                    created_at, updated_at, extras
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                meta.artifact_id, meta.namespace, meta.type, meta.source_path, meta.render_path,
                json.dumps(meta.prompt_history), meta.parent_artifact_id, meta.origin_round, meta.battle_id,
                json.dumps(meta.success_history), meta.curation_state, meta.license, meta.attribution, meta.version,
                meta.created_at, meta.updated_at, json.dumps(meta.extras),
            ))
            conn.commit()
        finally:
            conn.close()

    def get_artifact(self, artifact_id: str, namespace: str) -> ArtifactMetadata:
        """Fetch a single artifact by composite key. Raises ArtifactNotFoundError."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                "SELECT * FROM artifacts WHERE artifact_id = ? AND namespace = ?",
                (artifact_id, namespace)
            ).fetchone()
            if row is None:
                raise ArtifactNotFoundError(f"{artifact_id!r} not found in namespace={namespace!r}")
            return _row_to_meta(row)
        finally:
            conn.close()

    def find_artifacts(self, namespace: str, type: Optional[str] = None, curation_state: Optional[str] = None, limit: int = 50) -> List[ArtifactMetadata]:
        """Filter artifacts by namespace (REQUIRED) + optional type/curation_state. Namespace-isolated by default."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            where = ["namespace = ?"]
            params: List[Any] = [namespace]
            if type is not None:
                where.append("type = ?")
                params.append(type)
            if curation_state is not None:
                where.append("curation_state = ?")
                params.append(curation_state)
            sql = f"SELECT * FROM artifacts WHERE {' AND '.join(where)} ORDER BY updated_at DESC LIMIT ?"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            return [_row_to_meta(r) for r in rows]
        finally:
            conn.close()

    def update_curation_state(self, artifact_id: str, namespace: str, new_state: str) -> None:
        """Transition curation_state. Allowed values per ADR-005."""
        allowed = {'quarantined', 'approved_for_replay', 'approved_for_export', 'approved_for_marketplace'}
        if new_state not in allowed:
            raise ValueError(f"curation_state must be one of {allowed}, got {new_state!r}")
        conn = sqlite3.connect(str(self.db_path))
        try:
            cur = conn.execute(
                "UPDATE artifacts SET curation_state = ?, updated_at = ? WHERE artifact_id = ? AND namespace = ?",
                (new_state, _now_iso(), artifact_id, namespace)
            )
            if cur.rowcount == 0:
                raise ArtifactNotFoundError(f"{artifact_id!r} not found in namespace={namespace!r}")
            conn.commit()
        finally:
            conn.close()

    def promote_to_namespace(self, artifact_id: str, source_namespace: str, target_namespace: str, new_artifact_id: Optional[str] = None) -> str:
        """Duplicate artifact to a new namespace, preserving provenance via parent_artifact_id link.

        Source artifact is left untouched. Returns the new artifact_id in the target namespace.
        Per ADR-004: promotion is a copy not a move — preserves provenance.
        """
        src = self.get_artifact(artifact_id, source_namespace)
        new_id = new_artifact_id or f"{artifact_id}_promoted_{int(time.time())}"
        new_meta = ArtifactMetadata(
            artifact_id=new_id,
            type=src.type,
            namespace=target_namespace,
            source_path=src.source_path,
            render_path=src.render_path,
            prompt_history=list(src.prompt_history),
            parent_artifact_id=artifact_id,  # link back to source
            origin_round=src.origin_round,
            battle_id=src.battle_id,
            success_history=list(src.success_history),
            curation_state='quarantined',  # promoted artifacts re-enter curation in new namespace
            license=src.license,
            attribution=src.attribution,
            version=src.version,
            extras=dict(src.extras),
        )
        self.put_artifact(new_meta)
        return new_id


def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _ext_from_mimetype(mt: str) -> str:
    mapping = {
        'image/png': 'png', 'image/jpeg': 'jpg', 'image/svg+xml': 'svg',
        'video/mp4': 'mp4', 'text/html': 'html', 'application/json': 'json',
        'text/plain': 'txt', 'application/pdf': 'pdf',
    }
    return mapping.get(mt, 'bin')


def _row_to_meta(row) -> ArtifactMetadata:
    return ArtifactMetadata(
        artifact_id=row['artifact_id'],
        namespace=row['namespace'],
        type=row['type'],
        source_path=row['source_path'],
        render_path=row['render_path'],
        prompt_history=json.loads(row['prompt_history']) if row['prompt_history'] else [],
        parent_artifact_id=row['parent_artifact_id'],
        origin_round=row['origin_round'],
        battle_id=row['battle_id'],
        success_history=json.loads(row['success_history']) if row['success_history'] else [],
        curation_state=row['curation_state'],
        license=row['license'],
        attribution=row['attribution'],
        version=row['version'],
        created_at=row['created_at'],
        updated_at=row['updated_at'],
        extras=json.loads(row['extras']) if row['extras'] else {},
    )
