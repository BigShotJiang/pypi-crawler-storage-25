"""aibrain.core.email_reader — Canonical IMAP email reading.

Extracted 2026-05-02 from workflows/email_triage.py to consolidate the IMAP code
that was previously duplicated across email_triage.py, email_auto_reply.py,
calendar_manager.py, contact_enricher.py, newsletter_digest.py.

This module is also exposed as the `email_read` capability in
yaml_workflow_runner.py (provider: aibrain).

Phase 2 (separate task): refactor the 5 caller .py files to import from here
instead of defining their own copies.
"""
from __future__ import annotations

import email
import imaplib
import re
import sys
import time
from email.header import decode_header
from pathlib import Path


def _load_email_creds():
    """Load email credentials from .decker_env (defensive quote stripping)."""
    creds = {}
    env_file = Path.home() / ".decker_env"
    if not env_file.exists():
        return creds
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            creds[k.strip()] = v.strip().strip('"').strip("'")
    return creds


def decode_mime_header(header):
    if not header:
        return ""
    parts = decode_header(header)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(str(part))
    return " ".join(decoded)


def get_body(msg):
    """Extract plain text body from email message."""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")[:500]
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")[:500]
    return ""


def fetch_unread(imap_host, email_addr, password, max_count=100):
    """Connect via IMAP and fetch unread emails."""
    emails = []
    try:
        mail = imaplib.IMAP4_SSL(imap_host, 993)
        mail.login(email_addr, password)
        mail.select("INBOX", readonly=True)

        _, data = mail.search(None, "UNSEEN")
        msg_ids = data[0].split()

        if len(msg_ids) > max_count:
            msg_ids = msg_ids[-max_count:]

        for mid in msg_ids:
            _, msg_data = mail.fetch(mid, "(RFC822)")
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)

            sender = decode_mime_header(msg.get("From", ""))
            subject = decode_mime_header(msg.get("Subject", ""))
            date = msg.get("Date", "")
            body = get_body(msg)

            match = re.search(r"[\w.+-]+@[\w.-]+", sender)
            sender_email = match.group(0) if match else sender

            emails.append({
                "sender": sender,
                "sender_email": sender_email,
                "subject": subject,
                "date": date,
                "body": body,
            })

        mail.logout()
    except imaplib.IMAP4.error as e:
        print(f"IMAP error: {e}", file=sys.stderr)
        try:
            time.sleep(5)
            mail = imaplib.IMAP4_SSL(imap_host, 993)
            mail.login(email_addr, password)
            mail.select("INBOX", readonly=True)
            _, data = mail.search(None, "UNSEEN")
            count = len(data[0].split())
            emails = [{"note": f"Retry got count: {count} unread. Full fetch failed."}]
            mail.logout()
        except Exception:
            pass
    except Exception as e:
        print(f"Error fetching emails: {e}", file=sys.stderr)
    return emails
