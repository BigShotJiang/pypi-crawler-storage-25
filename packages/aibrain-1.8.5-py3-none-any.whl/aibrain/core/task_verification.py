"""
task_verification.py — Verify-and-followup system for company tasks.

Problem this solves: tasks were being marked done without verification. When
a completion produced gaps or implied new required actions, those follow-ups
were lost. Decker has had to repeat the same work multiple times.

This module:
  1. Parses acceptance criteria from a task's description (numbered lists,
     bullet points, "must" statements).
  2. Checks a caller-supplied work_output against each criterion.
  3. Creates follow-up tasks linked via parent_task_id whenever gaps are
     detected OR whenever the completion output mentions TODOs / follow-ups.
  4. Returns a verification result that complete_task() can use to decide
     whether to actually mark the task done.

Contract:
    verify_and_complete(task_id, work_output) -> {
        'verified': bool,
        'verification_status': 'verified' | 'partial' | 'unverified',
        'gaps': [str, ...],
        'follow_up_tasks': [task_id, ...],
        'criteria': [str, ...],
        'notes': str,
    }

Design notes:
  - The parser is deliberately simple — regex over markdown. If description
    has no explicit criteria, verification falls through to substring match
    against the task title.
  - Follow-up creation uses the same create_task() path (so SelRoute routing,
    evolution logging, etc. still apply) but sets parent_task_id so the
    lineage is preserved.
"""

from __future__ import annotations

import ipaddress
import logging
import os
import re
import socket
import sqlite3
import subprocess
import urllib.parse
import urllib.request
import urllib.error
from pathlib import Path

log = logging.getLogger("aibrain.task_verification")


# ---------------------------------------------------------------------------
# SQL injection whitelist — db rows check
# ---------------------------------------------------------------------------

# Exhaustive list of tables that exist in aibrain.db.  SQLite does not support
# parameterised identifiers, so the table name from a verify: block is validated
# against this frozenset before being interpolated into the f-string.  Any name
# not in this set is rejected — even syntactically valid names — so an attacker
# cannot probe schema state, enumerate tables, or exploit future injection
# vectors by naming a table that happens to match the regex but doesn't exist.
ALLOWED_DB_TABLES: frozenset[str] = frozenset({
    "memories",
    "sqlite_sequence",
    "memories_fts_data",
    "memories_fts_idx",
    "memories_fts_docsize",
    "memories_fts_config",
    "workflows",
    "workflows_fts_data",
    "workflows_fts_idx",
    "workflows_fts_docsize",
    "workflows_fts_config",
    "scheduled_jobs",
    "applications",
    "applications_fts_data",
    "applications_fts_idx",
    "applications_fts_docsize",
    "applications_fts_config",
    "app_emails",
    "app_status_history",
    "approvals",
    "activity",
    "costs",
    "traces",
    "webhook_history",
    "skills",
    "config",
    "entities",
    "memory_entities",
    "projects",
    "project_phases",
    "project_steps",
    "evolution_outcomes",
    "evolution_patterns",
    "evolution_hypotheses",
    "evolution_experiments",
    "evolution_cycles",
    "agent_permissions",
    "permission_audit_log",
    "evolution_critiques",
    "evolution_metrics",
    "evolution_parameter_search",
    "evolution_positive_patterns",
    "evolution_replications",
    "evolution_feedback_loops",
    "entity_links",
    "pattern_bus_events",
    "workflow_steps",
    "workflow_runs",
    "cross_domain_questions",
    "setup_steps",
    "memory_conflicts",
    "memories_vec_info",
    "memories_vec_chunks",
    "memories_vec_rowids",
    "memories_vec_vector_chunks00",
    "memory_passages",
    "passages_fts_data",
    "passages_fts_idx",
    "passages_fts_docsize",
    "passages_fts_config",
    "semantic_facts",
    "fact_evidence",
    "fact_transitions",
    "facts_fts_data",
    "facts_fts_idx",
    "facts_fts_docsize",
    "facts_fts_config",
    "task_routes",
    "task_executions",
    "hyperedges",
    "hyperedge_members",
    "satellite_dbs",
    "graph_build_log",
    "risk_assessments",
    "it_tickets",
    "skill_versions",
    "skill_executions",
    "calendar_events",
    "sync_state",
    "execution_log",
    "config_revisions",
    "budget_policies",
    "budget_incidents",
    "companies",
    "company_agents",
    "company_issues",
    "company_approvals",
    "company_heartbeat_runs",
    "users",
    "invites",
    "memory_history",
    "category_summaries",
    "experiment_results",
    "teams",
    "company_goals",
    "company_projects",
    "agent_secrets",
    "ingestion_log",
    "memories_fts",
    "workflows_fts",
    "applications_fts",
    "memories_vec",
    "passages_fts",
    "facts_fts",
    "social_posts",
    "social_analytics",
    "mcp_servers",
    "event_bus_log",
    "login_attempts",
    "oauth_links",
    "sessions",
    "password_reset_tokens",
    "email_verification_tokens",
    "license_state",
    "oauth_states",
    "attention_log",
    "evolution_outcomes_invalid",
    "routing_outcomes",
    "superworker_runs",
    "unattributed_license_events",
    "push_subscriptions",
    "license_activations",
    "superworker_usage",
    "memory_relations",
    "user_onboarding_phases",
    "buildit_builds",
    "skill_episodes",
    "skill_principles",
    "skill_profiles",
    "retrolearn_log",
    "memory_claims",
    "topic_clusters",
    "verification_log",
    "file_references",
    "telegram_state",
    "telegram_seen_messages",
    "knowledge_triples",
    "chat_messages",
})


# ---------------------------------------------------------------------------
# DB access (mirrors companies.py pattern so we stay consistent)
# ---------------------------------------------------------------------------

def _get_db() -> sqlite3.Connection:
    """Open a connection via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    db = sqlite3.connect(str(AIBRAIN_ROOT / "aibrain.db"))
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA busy_timeout=5000")
    return db


# ---------------------------------------------------------------------------
# Acceptance criteria extraction
# ---------------------------------------------------------------------------

# Patterns that indicate a line is a criterion the work must satisfy
_NUMBERED = re.compile(r"^\s*\d+[\.)]\s+(.+?)\s*$")
_BULLET = re.compile(r"^\s*[-*+]\s+(.+?)\s*$")
_MUST = re.compile(r"(?i)(?:must|should|shall|needs? to|is required to|has to)\s+(.+?)[.!\n]")


def _extract_ac_section_text(description: str) -> str:
    """Extract the text within the first ### Acceptance Criteria section.

    Returns lines between the section heading and the next heading, or '' if none.
    """
    in_ac = False
    lines: list[str] = []
    for raw in description.splitlines():
        stripped = raw.strip()
        if re.match(r'^#{1,4}\s+Acceptance Criteria', stripped, re.IGNORECASE):
            in_ac = True
            continue
        if in_ac:
            if re.match(r'^#{1,4}\s+', stripped):
                break
            lines.append(raw)
    return '\n'.join(lines)


def detect_acceptance_criteria(task_description: str) -> list[str]:
    """Extract acceptance criteria from a task description.

    Only parses criteria from within a dedicated ``### Acceptance Criteria``
    section. Numbered and bullet items outside that section are ignored to
    prevent false-positive follow-up tasks from DONE:/VERIFICATION: prose.

    Within the AC section, applies a minimum-length gate: criteria shorter
    than 30 chars or 5 words are silently skipped — short fragments like
    'DONE', 'None', '- file:' are not testable criteria.

    Filters out obviously noise lines (empty, headings, code fences).
    De-dupes while preserving order.
    """
    if not task_description:
        return []

    criteria: list[str] = []
    seen: set[str] = set()

    in_ac_section = False
    in_code_fence = False
    for raw in task_description.splitlines():
        line = raw.rstrip()
        if line.lstrip().startswith("```"):
            in_code_fence = not in_code_fence
            continue
        if in_code_fence:
            continue
        if not line.strip():
            continue

        # Heading detection — only lines inside an ### Acceptance Criteria
        # section are allowed to contribute criteria.
        if re.match(r'^#{1,4}\s+Acceptance Criteria', line.strip(), re.IGNORECASE):
            in_ac_section = True
            continue
        elif re.match(r'^#{1,4}\s+', line.strip()):
            in_ac_section = False
            continue
        if not in_ac_section:
            continue

        m = _NUMBERED.match(line) or _BULLET.match(line)
        if m:
            text = m.group(1).strip()
            # Strip markdown emphasis/code-tick wrappers
            text = re.sub(r"[`*]", "", text)
            # Min-length gate: ignore fragments shorter than 30 chars or <5 words
            if text and text.lower() not in seen and (len(text) >= 30 or len(text.split()) >= 5):
                criteria.append(text)
                seen.add(text.lower())

    # Also scan prose for must/should statements — but only within the AC section
    # so we don't double-count "must be satisfied" fragments from prose sections.
    ac_section_text = _extract_ac_section_text(task_description)
    for m in _MUST.finditer(ac_section_text):
        text = m.group(1).strip()
        text = re.sub(r"[`*]", "", text)
        low = text.lower()
        # Min-length gate on prose fragments as well
        if not text or low in seen or (len(text) < 30 and len(text.split()) < 5):
            continue
        # Suppress if this fragment is contained within (or contains) an
        # already-captured criterion.
        redundant = any(
            low in existing or existing in low
            for existing in seen
        )
        if redundant:
            continue
        criteria.append(text)
        seen.add(low)

    return criteria


# ---------------------------------------------------------------------------
# Follow-up indicator detection
# ---------------------------------------------------------------------------

# Phrases in completion output that mean "more work pending"
_FOLLOWUP_PATTERNS = [
    re.compile(r"(?i)\bTODO\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bfollow[- ]?up\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bnext step(?:s)?\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bremaining\b[:\- ]+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bstill needs?\b\s+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bnot yet\b\s+(.+?)(?:[.\n]|$)"),
    re.compile(r"(?i)\bFIXME\b[:\- ]+(.+?)(?:[.\n]|$)"),
]


def _extract_followup_hints(text: str) -> list[str]:
    """Scan text for follow-up indicator phrases, return snippets."""
    if not text:
        return []
    hints: list[str] = []
    seen: set[str] = set()
    for pat in _FOLLOWUP_PATTERNS:
        for m in pat.finditer(text):
            snippet = m.group(1).strip()
            # Trim trailing fluff
            snippet = snippet.strip(" `*_-:")
            if len(snippet) < 4 or len(snippet) > 300:
                continue
            key = snippet.lower()
            if key in seen:
                continue
            seen.add(key)
            hints.append(snippet)
    return hints


# ---------------------------------------------------------------------------
# Criterion matching
# ---------------------------------------------------------------------------

def _output_to_text(work_output) -> str:
    """Coerce any work_output shape into searchable text."""
    if work_output is None:
        return ""
    if isinstance(work_output, str):
        return work_output
    if isinstance(work_output, dict):
        # Prefer a dedicated 'output' or 'summary' field if present, but still
        # include the rest so criteria can match against any value.
        parts = []
        for k in ("output", "summary", "report", "result", "notes"):
            v = work_output.get(k)
            if isinstance(v, str):
                parts.append(v)
        try:
            import json
            parts.append(json.dumps(work_output, default=str))
        except Exception:
            parts.append(str(work_output))
        return "\n".join(parts)
    if isinstance(work_output, (list, tuple)):
        return "\n".join(_output_to_text(x) for x in work_output)
    return str(work_output)


_STOPWORDS = {
    "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with",
    "is", "it", "be", "by", "as", "at", "must", "should", "needs", "need",
    "that", "this", "then", "from", "into",
}


def _stem(word: str) -> str:
    """Very lightweight stemmer: trim common English suffixes so "write",
    "writes", "writing", and "written" all compare equal for matching.

    Not linguistically correct — just enough to reduce false negatives
    on ``Write the module`` → ``Module was written``.
    """
    w = word.lower()
    # Irregular common verbs
    irregular = {
        "written": "writ", "wrote": "writ", "writing": "writ", "writes": "writ",
        "built": "buil", "building": "buil", "builds": "buil",
        "ran": "run", "running": "run", "runs": "run",
        "made": "mad", "making": "mak", "makes": "mak",
    }
    if w in irregular:
        return irregular[w]
    for suffix in ("ings", "ing", "ed", "es", "s"):
        if len(w) > len(suffix) + 2 and w.endswith(suffix):
            return w[: -len(suffix)]
    if len(w) > 3 and w.endswith("e"):
        return w[:-1]
    return w


def _criterion_confidence(criterion: str, output_text: str) -> float:
    """Return a confidence score (0.0–1.0) for how well output satisfies criterion.

    - Extracts meaningful keywords (alphanumeric len>=3, not stopwords).
    - Stems both criterion keywords and output words to reduce word-form noise.
    - Returns hits / total_keywords as a raw fraction.
    - Returns 0.0 for empty input, 1.0 when all keywords hit.

    Callers use this to apply their own threshold rather than hardcoding one.
    """
    if not criterion or not output_text:
        return 0.0

    raw_keywords = [
        w for w in re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", criterion)
        if w.lower() not in _STOPWORDS
    ]
    if not raw_keywords:
        return 0.0

    keyword_stems = [_stem(w) for w in raw_keywords]

    # Build a set of stems from the output
    output_stems = {
        _stem(w) for w in re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", output_text)
    }
    # Also keep raw lowered substrings for identifier-style matches
    lower_out = output_text.lower()

    def _kw_in_output(stem: str, raw: str) -> bool:
        if stem in output_stems:
            return True
        # Identifier-style match (snake_case, camelCase fragments, etc.)
        return raw.lower() in lower_out

    hits = sum(1 for s, r in zip(keyword_stems, raw_keywords) if _kw_in_output(s, r))
    return hits / len(raw_keywords)


# Minimum confidence required to declare a criterion satisfied.
# 0.75 means >=75% of keywords must appear in the output.
# Using a confidence score instead of a bare bool allows callers to tune this
# threshold and surfaces partial matches for logging — false positives at 60%
# were the original complaint (task kwZ21-9hzcw).
_CRITERION_CONFIDENCE_THRESHOLD = 0.75


def _criterion_satisfied(criterion: str, output_text: str) -> bool:
    """Return True if _criterion_confidence() >= _CRITERION_CONFIDENCE_THRESHOLD.

    Short-criteria rule: criteria with <=2 keywords require a perfect score (1.0)
    because a 1-of-2 hit at 50% confidence is too easy to trigger accidentally.
    """
    confidence = _criterion_confidence(criterion, output_text)

    raw_keywords = [
        w for w in re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", criterion)
        if w.lower() not in _STOPWORDS
    ]
    if len(raw_keywords) <= 2:
        # All-or-nothing for short criteria — avoids single-word false positives
        return confidence >= 1.0

    return confidence >= _CRITERION_CONFIDENCE_THRESHOLD


# ---------------------------------------------------------------------------
# Follow-up task creation
# ---------------------------------------------------------------------------

def auto_create_followups(parent_task: dict, completion_result) -> list[str]:
    """Scan a completion result for follow-up indicators and create child
    tasks for each. Returns the list of new task IDs.

    The new tasks are linked to the parent via ``parent_task_id`` and stored
    in the same company. They inherit the parent's assignee by default and
    start at priority=medium.
    """
    text = _output_to_text(completion_result)
    hints = _extract_followup_hints(text)
    if not hints:
        return []

    # Lazy import to avoid circular dependency with companies.py
    from aibrain.core.companies import create_task

    company_id = parent_task.get("company_id")
    parent_id = parent_task.get("id")
    parent_title = parent_task.get("title", "")
    assignee = parent_task.get("assignee_agent_id")

    created: list[str] = []
    for hint in hints:
        title = f"Follow-up: {hint[:80]}"
        desc = (
            f"Auto-created follow-up from task {parent_id} ({parent_title}).\n\n"
            f"Reason: completion output flagged this as pending work.\n\n"
            f"Context:\n{hint}"
        )
        try:
            new_task = create_task(
                company_id=company_id,
                title=title,
                description=desc,
                assignee_agent_id=assignee,
                priority="medium",
                auto_route=False,  # inherit parent's assignee verbatim
            )
            new_id = new_task.get("id")
            if not new_id:
                continue
            # Set parent_task_id on the new task
            db = _get_db()
            try:
                db.execute(
                    "UPDATE company_issues SET parent_task_id=? WHERE id=?",
                    (parent_id, new_id),
                )
                db.commit()
            finally:
                db.close()
            created.append(new_id)
            log.info("Auto-created follow-up task %s for parent %s: %s",
                     new_id, parent_id, hint[:60])
        except Exception as e:
            log.warning("Follow-up creation failed for hint %r: %s", hint[:60], e)

    return created


# ---------------------------------------------------------------------------
# Live check execution
# ---------------------------------------------------------------------------

# Single-word forbidden tokens — match on word boundary so legitimate
# identifiers like 'skill_compiler' don't trigger 'kill'. Each entry is
# matched as a standalone shell word, not as a substring of an identifier.
_SAFETY_BLACKLIST_WORDS = [
    "DELETE", "DROP", "format", "truncate", "kill", "killall",
]

# Multi-word / shell-construct forbidden patterns — these are matched as
# bypass-resistant regex patterns that tolerate variable whitespace and
# common evasion attempts (extra spaces, tab separators). These are NOT
# word-boundary matches — they are substring-style with whitespace
# normalisation.
_SAFETY_BLACKLIST_PATTERNS = [
    re.compile(r"rm\s*-rf", re.IGNORECASE),       # rm -rf, rm-rf, rm  -rf
    re.compile(r"--\s*force", re.IGNORECASE),      # --force, -- force
    re.compile(r"--\s*hard", re.IGNORECASE),       # git reset --hard variants
    re.compile(r"dd\s+if=", re.IGNORECASE),        # dd if=/dev/zero ...
    re.compile(r":\s*\(\s*\)\s*\{", re.IGNORECASE),  # fork bomb prefix
    re.compile(r">\s*/dev/sd[a-z]"),               # raw device write
    re.compile(r"mkfs\.", re.IGNORECASE),          # filesystem create
    re.compile(r"shutdown\b|reboot\b|halt\b|poweroff\b", re.IGNORECASE),
]

# Regex to parse verify: lines from task descriptions
_VERIFY_LINE = re.compile(r"(?im)^[ \t]*verify:\s*(.+?)\s*$")


def _safe_check(check: str) -> bool:
    """Return True if the check string is safe to run.

    SA-2026-002 / F-05 fix: hybrid matching to avoid both false positives
    ('kill' blocking 'skill_compiler') AND false negatives ('rm-rf' bypassing
    'rm -rf' word-boundary match). Single-word blocklist uses word-boundary;
    multi-word constructs use whitespace-tolerant regex.
    """
    lcheck = check.lower()
    # Single-word forbidden tokens — word boundary required
    for forbidden in _SAFETY_BLACKLIST_WORDS:
        if re.search(r'\b' + re.escape(forbidden.lower()) + r'\b', lcheck):
            return False
    # Multi-word / shell-construct patterns — bypass-resistant
    for pat in _SAFETY_BLACKLIST_PATTERNS:
        if pat.search(check):  # original case for /dev/sd[a-z] etc.
            return False
    return True


# ---------------------------------------------------------------------------
# SSRF protection
# ---------------------------------------------------------------------------

# Private/reserved IP ranges that must never be reachable via user-supplied URLs.
_BLOCKED_NETWORKS = [
    ipaddress.ip_network('127.0.0.0/8'),       # loopback
    ipaddress.ip_network('10.0.0.0/8'),         # private class A
    ipaddress.ip_network('172.16.0.0/12'),      # private class B
    ipaddress.ip_network('192.168.0.0/16'),     # private class C
    ipaddress.ip_network('169.254.0.0/16'),     # link-local / AWS metadata
    ipaddress.ip_network('100.64.0.0/10'),      # carrier-grade NAT
    ipaddress.ip_network('::1/128'),            # IPv6 loopback
    ipaddress.ip_network('fc00::/7'),           # IPv6 unique local
]


def _validate_url_for_ssrf(url: str) -> None:
    """Raise ValueError if url would reach a private/reserved address (SSRF guard).

    Checks:
      1. Scheme must be http or https.
      2. Hostname must be present.
      3. DNS resolves to at least one address.
      4. Every resolved address must be outside all private/reserved ranges.

    Raises:
        ValueError: with an 'SSRF:' prefix describing the rejection reason.
    """
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"SSRF: scheme '{parsed.scheme}' not allowed — only http/https permitted")
    hostname = parsed.hostname
    if not hostname:
        raise ValueError("SSRF: no hostname in URL")
    try:
        addrs = socket.getaddrinfo(hostname, None)
    except socket.gaierror as e:
        raise ValueError(f"SSRF: DNS resolution failed for '{hostname}': {e}")
    for _, _, _, _, sockaddr in addrs:
        ip = ipaddress.ip_address(sockaddr[0])
        # Unwrap IPv4-mapped IPv6 addresses (e.g. ::ffff:127.0.0.1) so that
        # IPv4 private-range checks still apply to them.
        check_ip = getattr(ip, "ipv4_mapped", None) or ip
        for net in _BLOCKED_NETWORKS:
            if check_ip in net:
                raise ValueError(
                    f"SSRF: URL resolves to private/reserved address {ip} ({check_ip}) "
                    f"in blocked range {net}"
                )


def _run_http_check(url: str, expected_status: int = 200) -> dict:
    """Execute a GET HTTP check, return {passed, detail}."""
    try:
        _validate_url_for_ssrf(url)
    except ValueError as e:
        return {"passed": False, "detail": str(e)}
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            actual = resp.status
            passed = actual == expected_status
            return {
                "passed": passed,
                "detail": f"HTTP {actual} (expected {expected_status})",
            }
    except urllib.error.HTTPError as e:
        passed = e.code == expected_status
        return {
            "passed": passed,
            "detail": f"HTTP {e.code} (expected {expected_status}): {e.reason}",
        }
    except Exception as e:
        return {"passed": False, "detail": f"Connection error: {e}"}


def _normalise_path(path: str) -> Path:
    """Convert POSIX-style /c/Users/... paths to Windows C:\\Users\\... on Windows."""
    import sys
    if sys.platform == "win32":
        # Git Bash / POSIX-style /x/... → X:\...
        posix_m = re.match(r"^/([a-zA-Z])/(.*)$", path)
        if posix_m:
            drive, rest = posix_m.group(1).upper(), posix_m.group(2)
            return Path(f"{drive}:\\{rest.replace('/', chr(92))}")
    return Path(path)


def _confine_path_to_root(path: str) -> tuple:
    """SA-2026-002 F-43 (O-06): confine a verify-line path to AIBRAIN_ROOT.

    Returns (resolved_path, error_dict_or_none).
    - resolved_path: pathlib.Path of the canonical path (only valid when error is None)
    - error_dict_or_none: {'passed': False, 'detail': '...'} if path is outside the
      project root, else None.

    Centralises the F-04 guard so file-exists / grep / db-rows verify forms all
    benefit from the same confinement (O-06 found that F-04 only protected grep).
    """
    resolved = _normalise_path(path)
    try:
        try:
            from aibrain_db import AIBRAIN_ROOT
        except ImportError:
            from ..aibrain_db import AIBRAIN_ROOT
        # Allowlist of trusted working roots — DeckerOps has TWO legitimate
        # repos: the aibrain project root AND decker_system (workflows,
        # configs, internal research). The path-traversal guard stays fully
        # intact for everything OUTSIDE both roots; this only widens the
        # allowlist from one entry to the two known-safe DeckerOps roots.
        # realpath() resolves NTFS junctions/symlinks so a junctioned
        # decker_system path still matches (the rules dir is junctioned).
        _aibrain_root = Path(os.path.realpath(str(AIBRAIN_ROOT)))
        # decker_system is a sibling of the projects/ dir: <home>/decker_system
        _decker_system = Path(os.path.realpath(str(_aibrain_root.parent.parent / "decker_system")))
        trusted_roots = [_aibrain_root, _decker_system]
        # Optional per-host override (Case's VPS has different paths):
        # AIBRAIN_TRUSTED_ROOTS=path1;path2
        _extra = os.environ.get("AIBRAIN_TRUSTED_ROOTS", "")
        if _extra:
            for _r in _extra.replace(";", os.pathsep).split(os.pathsep):
                _r = _r.strip()
                if _r:
                    try:
                        trusted_roots.append(Path(os.path.realpath(_r)))
                    except Exception:
                        pass
        real_resolved = Path(os.path.realpath(str(resolved)))
        _rs = str(real_resolved)
        _ok = any(
            _rs == str(tr) or _rs.startswith(str(tr) + os.sep)
            for tr in trusted_roots
        )
        if not _ok:
            return resolved, {
                "passed": False,
                "detail": (
                    f"Blocked: path '{path}' resolves outside the trusted "
                    f"DeckerOps roots ({', '.join(str(t) for t in trusted_roots)}) "
                    "— path traversal not permitted"
                ),
            }
        return resolved, None
    except Exception as e:
        return resolved, {"passed": False, "detail": f"Path validation error: {e}"}


def _run_file_check(path: str) -> dict:
    """Check that a file exists at the given path."""
    # SA-2026-002 F-43 (O-06): confine to AIBRAIN_ROOT so attacker-supplied verify
    # lines can't enumerate /etc/*, ~/.ssh, etc.
    p, err = _confine_path_to_root(path)
    if err is not None:
        return err
    exists = p.exists()
    return {
        "passed": exists,
        "detail": f"{'exists' if exists else 'not found'}: {path}",
    }


def _run_python_check(code: str) -> dict:
    """Check a Python import statement — ALLOWLIST ONLY, no arbitrary exec.

    Security fix (Task 3 — CVE-class: arbitrary code execution via verify: block):
    Previously this ran ``python -c <code>`` where <code> came verbatim from a
    task description.  Task descriptions are user-controlled, so any string like:
        verify: python -c "import os; os.system('rm -rf /')" exits 0
    would execute as a subprocess with full process privileges.

    Replacement contract: only ``import <module[.submodule]>`` patterns are
    accepted.  The import is attempted inside the current Python process using
    importlib.util.find_spec (no side-effecting code runs — just the module
    finder).  Any code string that doesn't match the import pattern is rejected
    with passed=False and a clear error message.

    Accepted examples::
        import aibrain.core.harness
        import aibrain
        import json

    Rejected examples (all produce passed=False, no execution)::
        import os; os.system('id')
        open('/etc/passwd').read()
        __import__('subprocess').run(['id'])
    """
    import importlib.util

    # Strict allowlist: "import <dotted.module.name>" only — no semicolons,
    # no parentheses, no calls, no multi-statement chains.
    _IMPORT_RE = re.compile(
        r"^import\s+([A-Za-z_][A-Za-z0-9_.]*)\s*$"
    )
    m = _IMPORT_RE.match(code.strip())
    if not m:
        log.warning(
            "verify: python check BLOCKED (not a safe import): %r", code[:200]
        )
        return {
            "passed": False,
            "detail": (
                "Blocked: verify: python -c only supports 'import <module>' — "
                "arbitrary code execution is not permitted. Got: " + code[:100]
            ),
        }

    module_name = m.group(1)
    try:
        spec = importlib.util.find_spec(module_name)
        passed = spec is not None
        detail = f"import {module_name}: {'found' if passed else 'not found'}"
        return {"passed": passed, "detail": detail}
    except (ModuleNotFoundError, ValueError) as e:
        return {"passed": False, "detail": f"import {module_name}: {e}"}


def _run_db_rows_check(db_file: str, table: str, comparator: str, threshold: int) -> dict:
    """Check row count in a sqlite table satisfies comparator threshold."""
    # Security: table name comes from a verify: block in a task description,
    # which IS user-controlled input.  SQLite does not support parameterised
    # identifiers, so we validate the name against a strict allowlist pattern
    # (letters, digits, underscores, hyphens — no spaces, semicolons, or
    # SQL keywords that would allow injection like "users; DROP TABLE users--").
    _TABLE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_\-]*$")
    if not _TABLE_RE.match(table):
        return {
            "passed": False,
            "detail": f"Blocked: table name '{table[:80]}' contains invalid characters (allowlist: [A-Za-z0-9_-])",
        }
    # Whitelist gate: even syntactically valid names are rejected if they are not
    # a known aibrain.db table.  This prevents schema enumeration and closes any
    # future injection vector that might bypass the regex alone.  # nosec B608
    if table not in ALLOWED_DB_TABLES:
        return {
            "passed": False,
            "detail": f"Blocked: table name {table!r} is not in the known-tables whitelist",
        }
    try:
        # SA-2026-002 F-43 (O-06): confine before opening sqlite — attacker can't
        # supply /etc/passwd or another binary the process can read.
        from aibrain_db import AIBRAIN_ROOT
        normed = _normalise_path(db_file)
        if normed.is_absolute():
            db_path, err = _confine_path_to_root(db_file)
            if err is not None:
                return err
        else:
            db_path = AIBRAIN_ROOT / db_file
        conn = sqlite3.connect(str(db_path))
        try:
            # table has been validated against the identifier allowlist above
            count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]  # nosec B608
        finally:
            conn.close()
        op_map = {">": count > threshold, ">=": count >= threshold,
                  "<": count < threshold, "<=": count <= threshold,
                  "==": count == threshold, "=": count == threshold}
        passed = op_map.get(comparator, False)
        return {
            "passed": passed,
            "detail": f"table {table} has {count} rows ({comparator} {threshold})",
        }
    except Exception as e:
        return {"passed": False, "detail": str(e)}


def _run_grep_check(pattern: str, path: str) -> dict:
    """Check that pattern appears in file.

    Security: the path argument comes from a verify: block in a task
    description (user-controlled input).  Without validation an attacker could
    supply '../../../etc/passwd' and leak arbitrary files.

    Guard: resolve the real path and confirm it is a subdirectory of the
    project root (AIBRAIN_ROOT).  Paths outside the project tree are rejected.

    SA-2026-002 / F-04 fix: this guard previously widened to USER_HOME (~),
    which exposed ~/.decker_env, ~/.ssh, ~/.aws, ~/.aibrain, browser profiles,
    etc. to read via verify: grep lines in attacker-supplied task descriptions.
    Reverted to AIBRAIN_ROOT confinement.
    """
    # SA-2026-002 F-04 / F-43 (O-06): confine via shared helper.
    resolved, err = _confine_path_to_root(path)
    if err is not None:
        return err

    try:
        result = subprocess.run(
            ["grep", "-q", pattern, str(resolved)],
            capture_output=True, timeout=5,
        )
        passed = result.returncode == 0
        return {
            "passed": passed,
            "detail": f"pattern {'found' if passed else 'not found'} in {path}",
        }
    except subprocess.TimeoutExpired:
        return {"passed": False, "detail": "grep timed out after 5s"}
    except FileNotFoundError:
        # grep not available — fallback to Python
        try:
            text = resolved.read_text(encoding="utf-8", errors="ignore")
            passed = bool(re.search(pattern, text))
            return {
                "passed": passed,
                "detail": f"pattern {'found' if passed else 'not found'} in {path} (python fallback)",
            }
        except Exception as e:
            return {"passed": False, "detail": str(e)}
    except Exception as e:
        return {"passed": False, "detail": str(e)}


def validate_verify_lines(description: str) -> list[str]:
    """Pre-flight validator for verify: lines in task descriptions.

    Returns a list of actionable error strings. Empty list = all valid.
    Called by create_task() before the DB INSERT so bad patterns are caught
    at authoring time instead of silently failing at gate-execution time.
    """
    errors = []
    _IMPORT_RE = re.compile(r'^import\s+([A-Za-z_][A-Za-z0-9_.]*)\s*$')
    _PYTHON_CHECK_RE = re.compile(r'(?i)python\s+-c\s+"(.+)"\s+exits\s+0')
    _GREP_FLAG_RE = re.compile(r'\s-[a-zA-Z]')

    for m in _VERIFY_LINE.finditer(description):
        check = m.group(1).strip()

        py_m = _PYTHON_CHECK_RE.match(check)
        if py_m:
            code = py_m.group(1).strip()
            if not _IMPORT_RE.match(code):
                errors.append(
                    f"verify: python -c \"{code}\" exits 0 — "
                    f"only 'import <module>' accepted (no 'from ... import', no ';', no calls). "
                    f"Example: verify: python -c \"import aibrain.core.companies\" exits 0"
                )
            continue

        if re.match(r'(?i)grep\s+', check) and _GREP_FLAG_RE.search(check):
            errors.append(
                f"verify: {check} — grep flags not supported (-i, -r, -n etc). "
                f"Use plain: verify: grep \"pattern\" /path/to/file"
            )
            continue

    return errors


def run_live_checks(task_description: str, work_output: str) -> list[dict]:
    """Parse ``verify:`` blocks from task_description and execute each check.

    Supported formats::

        verify: GET http://localhost:8001/api/foo returns 200
        verify: file exists /path/to/file.py
        verify: python -c "import aibrain.core.thing" exits 0
        verify: db rows aibrain.db table_name > 0
        verify: grep "pattern" /path/to/file.py

    Returns a list of dicts: {check, passed, detail}.
    Checks containing DELETE/DROP/rm -rf/--force/format/truncate/kill are skipped.
    All checks have a 5-second timeout.
    """
    results: list[dict] = []

    for m in _VERIFY_LINE.finditer(task_description):
        check = m.group(1).strip()

        if not _safe_check(check):
            log.warning("Live check SKIPPED (safety gate): %s", check)
            results.append({
                "check": check,
                "passed": False,
                "skipped": True,
                "detail": "Skipped — check contains a forbidden operation",
            })
            continue

        outcome: dict = {}

        # --- GET http://... returns <status> ---
        http_m = re.match(r"(?i)GET\s+(https?://\S+)\s+returns\s+(\d+)", check)
        if http_m:
            url, status = http_m.group(1), int(http_m.group(2))
            outcome = _run_http_check(url, status)

        # --- file exists /path ---
        elif re.match(r"(?i)file\s+exists\s+(.+)", check):
            path = re.match(r"(?i)file\s+exists\s+(.+)", check).group(1).strip()
            outcome = _run_file_check(path)

        # --- python -c "..." exits 0 ---
        # _run_python_check enforces an allowlist: only "import <module>" is
        # accepted.  Any other code string is rejected (no subprocess, no exec).
        elif re.match(r'(?i)python\s+-c\s+"(.+)"\s+exits\s+0', check):
            code = re.match(r'(?i)python\s+-c\s+"(.+)"\s+exits\s+0', check).group(1)
            outcome = _run_python_check(code)

        # --- db rows <db_file> <table> <comparator> <n> ---
        elif re.match(r"(?i)db\s+rows\s+(\S+)\s+(\S+)\s*([><=!]+)\s*(\d+)", check):
            db_m = re.match(r"(?i)db\s+rows\s+(\S+)\s+(\S+)\s*([><=!]+)\s*(\d+)", check)
            db_file, table, comp, n = db_m.group(1), db_m.group(2), db_m.group(3), int(db_m.group(4))
            outcome = _run_db_rows_check(db_file, table, comp, n)

        # --- grep "pattern" /path ---
        elif re.match(r'(?i)grep\s+"(.+)"\s+(\S+)', check):
            grep_m = re.match(r'(?i)grep\s+"(.+)"\s+(\S+)', check)
            pattern, path = grep_m.group(1), grep_m.group(2)
            outcome = _run_grep_check(pattern, path)

        else:
            outcome = {"passed": False, "detail": f"Unrecognised check format: {check}"}

        passed = outcome.get("passed", False)
        detail = outcome.get("detail", "")
        if passed:
            log.info("Live check PASSED: %s", check)
        else:
            log.warning("Live check FAILED: %s — %s", check, detail)

        results.append({"check": check, "passed": passed, "detail": detail})

    return results


# ---------------------------------------------------------------------------
# Gap follow-up noise filters
# ---------------------------------------------------------------------------

# Common English verbs — presence of any of these qualifies a line as
# "containing a verb" and therefore worth creating a follow-up for.
_VERB_SET = {
    "add", "fix", "update", "remove", "create", "delete", "implement",
    "build", "write", "test", "verify", "run", "deploy", "migrate", "refactor",
    "check", "configure", "set", "enable", "disable", "connect", "expose",
    "parse", "validate", "handle", "return", "send", "fetch", "load",
    "install", "register", "wire", "hook", "integrate", "ensure", "resolve",
    "investigate", "debug", "trace", "profile", "audit", "review", "document",
    "make", "track", "log", "emit", "measure", "compute", "calculate",
    "generate", "serialize", "deserialize", "encode", "decode", "convert",
    "store", "read", "watch", "listen", "subscribe", "publish", "queue",
    "schedule", "trigger", "spawn", "kill", "restart", "stop", "start",
    "complete", "fail", "pass", "raise", "catch", "throw", "wrap",
}


def _gap_is_followup_worthy(gap: str) -> bool:
    """Return True if a gap string deserves its own follow-up task.

    Filters out:
    - Lines shorter than 15 characters
    - Lines with fewer than 10 words (implementation-detail bullets)
    - Lines that look like code: start with >, contain ::, contain (),
      start with import/from/SELECT/INSERT/CREATE/def
    - Lines with no recognisable verb (pure noun phrases)
    """
    stripped = gap.strip()

    # Length guard
    if len(stripped) < 15:
        return False

    # Word count guard (>10 words required)
    words = stripped.split()
    if len(words) <= 10:
        return False

    # Code-smell guards
    if stripped.startswith(">"):
        return False
    if "::" in stripped:
        return False
    if "(" in stripped and ")" in stripped:
        return False
    code_starts = ("import ", "from ", "SELECT ", "INSERT ", "CREATE ",
                   "def ", "class ", "return ", "async ")
    if any(stripped.startswith(p) for p in code_starts):
        return False

    # Verb presence guard
    lower_words = {w.lower().rstrip("s") for w in words}
    has_verb = bool(lower_words & _VERB_SET)
    return has_verb


# ---------------------------------------------------------------------------
# Main verification entry point
# ---------------------------------------------------------------------------

def verify_and_complete(task_id: str, work_output) -> dict:
    """Verify task completion against acceptance criteria. If verification
    passes, the caller is expected to actually mark the task done.

    This function:
      - Loads the task row.
      - Extracts acceptance criteria from the description.
      - Checks each criterion against the work_output.
      - Creates follow-up tasks for every gap.
      - Also scans the work_output itself for TODO/follow-up hints and
        creates child tasks for those.
      - Updates verification_status and verification_notes on the task row.

    Returns:
        {
            'verified': bool,   # True iff status == 'verified'
            'verification_status': 'verified'|'partial'|'unverified',
            'criteria': [...],
            'gaps': [...],
            'follow_up_tasks': [task_id, ...],
            'notes': str,
        }
    """
    db = _get_db()
    row = db.execute(
        "SELECT * FROM company_issues WHERE id=?", (task_id,)
    ).fetchone()
    if not row:
        db.close()
        return {
            "verified": False,
            "verification_status": "unverified",
            "criteria": [],
            "gaps": [],
            "follow_up_tasks": [],
            "notes": f"Task {task_id} not found",
            "error": "not_found",
        }

    task = dict(row)
    db.close()

    criteria = detect_acceptance_criteria(task.get("description") or "")
    output_text = _output_to_text(work_output)

    gaps: list[str] = []
    for c in criteria:
        if not _criterion_satisfied(c, output_text):
            gaps.append(c)

    # Fallback criterion: if no explicit criteria were parsed, at least
    # check that the output is non-empty and mentions something from the
    # task title.
    if not criteria:
        if not output_text.strip():
            gaps.append("(fallback) task produced no output")
        else:
            title_keywords = [
                w.lower() for w in re.findall(
                    r"[A-Za-z][A-Za-z0-9_\-]{3,}", task.get("title", "")
                )
                if w.lower() not in _STOPWORDS
            ]
            if title_keywords:
                lower_out = output_text.lower()
                hits = sum(1 for kw in title_keywords if kw in lower_out)
                if hits == 0:
                    gaps.append(
                        f"(fallback) output mentions none of the title keywords "
                        f"({', '.join(title_keywords[:5])})"
                    )

    # --- Live checks: parse and execute verify: blocks from the description ---
    live_check_results: list[dict] = []
    description = task.get("description") or ""
    try:
        live_check_results = run_live_checks(description, output_text)
    except Exception as e:
        log.warning("run_live_checks raised an unexpected error: %s", e)

    failed_live_checks = [r for r in live_check_results if not r["passed"]]
    for r in failed_live_checks:
        gaps.append(f"(live check failed) {r['check']} — {r['detail']}")

    # Determine status
    if gaps and criteria:
        status = "partial"
    elif gaps and not criteria:
        # Only fallback gaps → still flag as unverified (no real criteria)
        status = "unverified"
    else:
        status = "verified"

    # Create follow-up tasks for gaps (one per gap) — apply noise filter
    follow_up_ids: list[str] = []
    if gaps:
        from aibrain.core.companies import create_task
        for gap in gaps:
            if not _gap_is_followup_worthy(gap):
                log.debug("Gap follow-up suppressed (noise filter): %s", gap[:80])
                continue
            title = f"Gap follow-up: {gap[:80]}"
            desc = (
                f"Auto-created gap follow-up from parent task {task_id} "
                f"({task.get('title', '')}).\n\n"
                f"Criterion not satisfied by completion output:\n{gap}\n\n"
                f"Resolve this gap, then mark this follow-up complete."
            )
            try:
                new_task = create_task(
                    company_id=task["company_id"],
                    title=title,
                    description=desc,
                    assignee_agent_id=task.get("assignee_agent_id"),
                    priority="medium",
                    auto_route=False,
                )
                new_id = new_task.get("id")
                if new_id:
                    db = _get_db()
                    try:
                        db.execute(
                            "UPDATE company_issues SET parent_task_id=? WHERE id=?",
                            (task_id, new_id),
                        )
                        db.commit()
                    finally:
                        db.close()
                    follow_up_ids.append(new_id)
            except Exception as e:
                log.warning("Gap follow-up creation failed: %s", e)

    # Also scan the work_output for TODO/follow-up hints
    try:
        follow_up_ids.extend(auto_create_followups(task, work_output))
    except Exception as e:
        log.warning("auto_create_followups failed: %s", e)

    # Persist verification status on the parent task
    notes = _format_verification_notes(
        criteria, gaps, follow_up_ids,
        live_check_results=live_check_results,
    )
    db = _get_db()
    try:
        db.execute(
            "UPDATE company_issues "
            "SET verification_status=?, verification_notes=?, updated_at=datetime('now') "
            "WHERE id=?",
            (status, notes, task_id),
        )
        db.commit()
    finally:
        db.close()

    return {
        "verified": status == "verified",
        "verification_status": status,
        "criteria": criteria,
        "gaps": gaps,
        "follow_up_tasks": follow_up_ids,
        "notes": notes,
        "live_checks": live_check_results,
    }


def _format_verification_notes(
    criteria: list[str],
    gaps: list[str],
    follow_up_ids: list[str],
    live_check_results: list[dict] | None = None,
) -> str:
    lines = []
    lines.append(f"criteria_count={len(criteria)}")
    lines.append(f"gap_count={len(gaps)}")
    lines.append(f"follow_ups={len(follow_up_ids)}")
    if live_check_results:
        passed_n = sum(1 for r in live_check_results if r["passed"])
        lines.append(f"live_checks={len(live_check_results)} ({passed_n} passed)")
        for r in live_check_results:
            status_mark = "PASS" if r["passed"] else "FAIL"
            lines.append(f"  [{status_mark}] {r['check'][:100]}: {r['detail'][:100]}")
    if gaps:
        lines.append("gaps:")
        for g in gaps[:10]:
            lines.append(f"  - {g[:140]}")
    if follow_up_ids:
        lines.append("follow_up_task_ids: " + ",".join(follow_up_ids))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Public API for retroactive verification
# ---------------------------------------------------------------------------

def re_verify_task(task_id: str, work_output=None) -> dict:
    """Manually re-verify a task. If no work_output is supplied, any existing
    quality_detail / description columns are used as the completion text
    (best-effort retroactive check). Missing columns are tolerated.
    """
    if work_output is None:
        # Whitelist allowed columns to satisfy security pre-commit (no f-string SQL).
        _ALLOWED = frozenset(("quality_detail", "description"))
        db = _get_db()
        try:
            cols = {r[1] for r in db.execute(
                "PRAGMA table_info(company_issues)"
            ).fetchall()}
            select_cols = [c for c in ("quality_detail", "description") if c in cols and c in _ALLOWED]
            if not select_cols:
                work_output = ""
            else:
                # Build SQL from whitelist only — never user input
                col_sql = ",".join(select_cols)  # noqa:sql-fstring — whitelisted column names only
                row = db.execute(
                    "SELECT " + col_sql + " FROM company_issues WHERE id=?",  # noqa:sql-fstring
                    (task_id,),
                ).fetchone()
                if row:
                    work_output = "\n".join((row[c] or "") for c in select_cols)
                else:
                    work_output = ""
        finally:
            db.close()
    return verify_and_complete(task_id, work_output)


def list_followups(parent_task_id: str) -> list[dict]:
    """List all follow-up tasks linked to a parent."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM company_issues WHERE parent_task_id=? ORDER BY created_at",
        (parent_task_id,),
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]
