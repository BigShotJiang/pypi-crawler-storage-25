"""
DeepSeek primitives for Lucy's direct orchestration.

Three standalone functions Lucy can call directly:
  - deepseek_chat(prompt)          → raw API response, no side effects
  - apply_dispatch_blocks(text)    → apply FILE/EDIT blocks from any source
  - verify_file_state(verify_lines)→ run grep/import/exit checks

Decomposed from dispatch_deepseek_task's black box per the Bruce Lee target
in neuro_decker_strategy_chat_2026_05_09.md. Lucy uses these to:
  1. Prompt-craft with Claude, code-gen with DeepSeek
  2. Read the response herself, judge if it looks right
  3. Run the applier on her own terms
  4. Decide next action based on what landed
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# 1. deepseek_chat — raw API call, no apply, no lifecycle
# ---------------------------------------------------------------------------

def deepseek_chat(
    prompt: str,
    *,
    system_prompt: str = "",
    model: str = "deepseek-v4-pro",
    thinking: bool = False,
    reasoning_effort: str = "high",
) -> Dict:
    """Call the DeepSeek API and return the raw response.

    Pure API call — no task lifecycle, no apply, no verification.
    No side effects on company DB or filesystem.

    Args:
        prompt: User message / task description.
        system_prompt: System-level instruction (optional).
        model: DeepSeek model name (default deepseek-v4-pro).
        thinking: Enable chain-of-thought reasoning mode.
        reasoning_effort: "high" (default) or "max" for complex tasks.

    Returns:
        dict with keys:
            content    — the model's text response
            tokens_in  — input token count
            tokens_out — output token count
            cost_usd   — estimated cost in USD
    """
    from aibrain.core.companies import _deepseek_http_call

    result = _deepseek_http_call(
        system_prompt=system_prompt,
        user_prompt=prompt,
        model=model,
        thinking=thinking,
        reasoning_effort=reasoning_effort,
    )

    n_in = result.get("tokens_in", 0)
    n_out = result.get("tokens_out", 0)
    # DeepSeek rates per 1k tokens: $0.14/M input, $0.28/M output
    cost_usd = (n_in * 0.00014 + n_out * 0.00028) / 1000

    return {
        "content": result["content"],
        "tokens_in": n_in,
        "tokens_out": n_out,
        "cost_usd": round(cost_usd, 6),
    }


# ---------------------------------------------------------------------------
# 2. apply_dispatch_blocks — apply FILE/EDIT blocks from any text
# ---------------------------------------------------------------------------

def _resolve_target_dir(target_dir: Optional[str] = None) -> str:
    """Resolve the target directory for applying blocks.

    Uses target_dir if provided, otherwise finds the git root from CWD.
    """
    if target_dir:
        return os.path.abspath(target_dir)

    # Try git root resolution
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    # Fallback to CWD
    return os.getcwd()


def apply_dispatch_blocks(
    text: str,
    target_dir: Optional[str] = None,
) -> Dict:
    """Apply FILE: and diff blocks from any text source to disk.

    Decoupled from dispatch lifecycle — no task_id required, no
    complete_task calls, no harness bookend functions.

    Uses the same extract_blocks() parser and deny-list checks from
    dispatch_applier.py.

    Args:
        text: Raw text containing FILE: blocks and/or unified diffs.
        target_dir: Directory to apply changes in. If None, resolves
                    from git root or CWD.

    Returns:
        dict: {applied_files: [str], errors: [str], blocks_found: int}
    """
    from aibrain.core.dispatch_applier import extract_blocks, _is_path_denied

    root = _resolve_target_dir(target_dir)
    blocks = extract_blocks(text)

    applied_files: List[str] = []
    errors: List[str] = []

    for blk in blocks:
        blk_path = blk.get("filepath") or ""
        if not blk_path:
            errors.append("block missing filepath — skipped")
            continue

        # Deny-list check
        denied, reason = _is_path_denied(blk_path)
        if denied:
            errors.append(f"denied: {blk_path!r} ({reason})")
            continue

        # Also check dest path for diffs
        dest_path = blk.get("dest_filepath")
        if dest_path:
            dest_denied, dest_reason = _is_path_denied(dest_path)
            if dest_denied:
                errors.append(f"dest denied: {dest_path!r} ({dest_reason})")
                continue

        full_path = os.path.join(root, blk_path)

        try:
            if blk["type"] == "file":
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(blk["content"])
                applied_files.append(blk_path)

            elif blk["type"] == "diff":
                # Write diff to temp file, apply via git
                import tempfile
                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=".diff", delete=False, encoding="utf-8"
                ) as tf:
                    tf.write(blk["content"])
                    diff_path = tf.name

                try:
                    result = subprocess.run(
                        ["git", "apply", "--binary", diff_path],
                        cwd=root,
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )
                    if result.returncode == 0:
                        applied_files.append(blk_path)
                    else:
                        # Try with --3way fallback
                        result2 = subprocess.run(
                            ["git", "apply", "--binary", "--3way", diff_path],
                            cwd=root,
                            capture_output=True,
                            text=True,
                            timeout=10,
                        )
                        if result2.returncode == 0:
                            applied_files.append(blk_path)
                        else:
                            errors.append(
                                f"git apply failed for {blk_path}: "
                                f"{result2.stderr.strip() or result.stderr.strip()}"
                            )
                finally:
                    try:
                        os.unlink(diff_path)
                    except Exception:
                        pass
            else:
                errors.append(f"unknown block type: {blk['type']}")
        except Exception as e:
            errors.append(f"{blk_path}: {e}")

    return {
        "applied_files": applied_files,
        "errors": errors,
        "blocks_found": len(blocks),
    }


# ---------------------------------------------------------------------------
# 3. verify_file_state — grep/import/exit checks
# ---------------------------------------------------------------------------

def verify_file_state(
    verify_lines: List[str],
    cwd: Optional[str] = None,
) -> Dict:
    """Run grep, import, and exit-code verification checks.

    Pure verification — no mutation.

    Each verify_line is one of:
      - "grep: <pattern>: <filepath>"  — regex search in file
      - "import: <module>"             — python -c "import <module>"
      - "exit:N: <command>"           — run command, expect exit code N
      - "exit:0"                       — exit 0 shortcut (always passes)
      - "grep: <pattern>"              — search across project (find/grep)

    Args:
        verify_lines: List of verification spec strings.
        cwd: Working directory for commands. Defaults to git root or CWD.

    Returns:
        dict: {passed: [str], failed: [str], summary: "N/M passed"}
    """
    work_dir = cwd or _resolve_target_dir()
    passed: List[str] = []
    failed: List[str] = []

    for line in verify_lines:
        line = line.strip()
        if not line:
            continue

        # exit:0 shortcut
        if line == "exit:0":
            passed.append(f"exit:0 (trivial)")
            continue

        # exit:N: <command>
        exit_match = re.match(r"^exit:(\d+):\s*(.+)$", line)
        if exit_match:
            expected_code = int(exit_match.group(1))
            cmd = exit_match.group(2)
            try:
                result = subprocess.run(
                    cmd.split(),
                    cwd=work_dir,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode == expected_code:
                    passed.append(f"exit:{expected_code}: {cmd[:60]}")
                else:
                    failed.append(
                        f"exit:{expected_code}: {cmd[:60]} — "
                        f"got {result.returncode}, stderr: {result.stderr[:100]}"
                    )
            except Exception as e:
                failed.append(f"exit:{expected_code}: {cmd[:60]} — {e}")
            continue

        # import: <module>
        import_match = re.match(r"^import:\s*(.+)$", line)
        if import_match:
            module = import_match.group(1).strip()
            try:
                result = subprocess.run(
                    [sys.executable, "-c", f"import {module}"],
                    cwd=work_dir,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
                if result.returncode == 0:
                    passed.append(f"import: {module}")
                else:
                    failed.append(
                        f"import: {module} — {result.stderr.strip()[:100]}"
                    )
            except Exception as e:
                failed.append(f"import: {module} — {e}")
            continue

        # grep: <pattern>: <filepath>
        grep_match = re.match(r"^grep:\s*(.+?)\s*:\s*(.+)$", line)
        if grep_match:
            pattern = grep_match.group(1).strip()
            filepath = grep_match.group(2).strip()
            full_path = os.path.join(work_dir, filepath)
            try:
                if not os.path.exists(full_path):
                    failed.append(f"grep: {pattern} — file not found: {filepath}")
                    continue
                with open(full_path, encoding="utf-8", errors="replace") as f:
                    content = f.read()
                if re.search(pattern, content):
                    passed.append(f"grep: {pattern} in {filepath}")
                else:
                    failed.append(f"grep: {pattern} not found in {filepath}")
            except Exception as e:
                failed.append(f"grep: {pattern} in {filepath} — {e}")
            continue

        # grep: <pattern> (search across project)
        grep_broad_match = re.match(r"^grep:\s*(.+)$", line)
        if grep_broad_match:
            pattern = grep_broad_match.group(1).strip()
            try:
                result = subprocess.run(
                    ["grep", "-r", "-l", pattern, work_dir],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode == 0 and result.stdout.strip():
                    passed.append(f"grep: {pattern} (found in project)")
                else:
                    # Try findstr on Windows
                    result2 = subprocess.run(
                        ["findstr", "/S", "/M", pattern, os.path.join(work_dir, "*")],
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    if result2.returncode == 0 and result2.stdout.strip():
                        passed.append(f"grep: {pattern} (found via findstr)")
                    else:
                        failed.append(f"grep: {pattern} not found in project")
            except Exception as e:
                failed.append(f"grep: {pattern} — {e}")
            continue

        # Unknown format
        failed.append(f"unknown verify format: {line[:80]}")

    total = len(passed) + len(failed)
    return {
        "passed": passed,
        "failed": failed,
        "summary": f"{len(passed)}/{total} passed" if total else "0/0 (no checks)",
    }
