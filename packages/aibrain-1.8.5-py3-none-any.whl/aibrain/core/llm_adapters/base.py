"""base.py — BaseAdapter abstract class for LLM provider adapters.

F-LUCY-PROVIDER-ADAPTER-1. All adapters inherit from this.
"""
from abc import ABC, abstractmethod
from typing import Any, Optional
import logging, time

log = logging.getLogger("aibrain.adapters")


class BaseAdapter(ABC):
    """Abstract base for LLM provider adapters."""

    def __init__(self, api_key: str, base_url: Optional[str] = None,
                 timeout: int = 60, max_retries: int = 3):
        self.api_key = api_key
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries
        self._rate_limit_remaining = None
        self._rate_limit_reset = None

    @abstractmethod
    def chat(self, messages: list[dict], model: str,
             tools: Optional[list[dict]] = None,
             temperature: float = 0.7, max_tokens: int = 4096) -> dict:
        """Send a chat completion request. Returns {"content": str, "tool_calls": list, "usage": dict}."""
        ...

    def _update_rate_limits(self, headers: dict):
        """Extract rate-limit headers from response."""
        self._rate_limit_remaining = headers.get("x-ratelimit-remaining-tokens") or headers.get("x-ratelimit-remaining")
        self._rate_limit_reset = headers.get("x-ratelimit-reset-requests") or headers.get("retry-after")

    def _retry_backoff(self, attempt: int) -> float:
        """Exponential backoff: 1s, 2s, 4s."""
        return min(2 ** attempt, 16)

    def _sleep_or_raise(self, attempt: int, error: Exception):
        """Sleep with backoff or raise on max retries."""
        if attempt >= self.max_retries - 1:
            raise error
        wait = self._retry_backoff(attempt)
        log.debug("Retry %d/%d in %.1fs: %s", attempt + 1, self.max_retries, wait, error)
        time.sleep(wait)
