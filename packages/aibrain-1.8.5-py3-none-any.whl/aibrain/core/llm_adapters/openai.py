"""openai.py — OpenAI adapter (also base for OpenAI-compatible providers)."""
from .base import BaseAdapter

class OpenAIAdapter(BaseAdapter):
    def chat(self, messages, model="gpt-4o", tools=None, temperature=0.7, max_tokens=4096):
        from openai import OpenAI
        client = OpenAI(api_key=self.api_key, base_url=self.base_url)
        kwargs = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
        if tools:
            kwargs["tools"] = tools
        for attempt in range(self.max_retries):
            try:
                resp = client.chat.completions.create(**kwargs)
                self._update_rate_limits(dict(resp.headers) if hasattr(resp, 'headers') else {})
                choice = resp.choices[0]
                return {
                    "content": choice.message.content or "",
                    "tool_calls": [{"name": tc.function.name, "arguments": tc.function.arguments}
                                   for tc in (choice.message.tool_calls or [])],
                    "usage": {"prompt_tokens": resp.usage.prompt_tokens, "completion_tokens": resp.usage.completion_tokens}
                }
            except Exception as e:
                self._sleep_or_raise(attempt, e)
