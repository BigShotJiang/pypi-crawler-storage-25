"""anthropic.py — Anthropic Claude adapter with tool-use schema normalization."""
import json
from .base import BaseAdapter

class AnthropicAdapter(BaseAdapter):
    def _normalize_anthropic_tools(self, tools: list[dict]) -> list[dict]:
        """Normalize OpenAI-format tools to Anthropic format."""
        normalized = []
        for t in tools:
            func = t.get("function", t)
            normalized.append({
                "name": func.get("name", ""),
                "description": func.get("description", ""),
                "input_schema": func.get("parameters", {"type": "object", "properties": {}}),
            })
        return normalized

    def _normalize_response(self, response) -> dict:
        """Normalize Anthropic response to OpenAI-compat format."""
        content = ""
        tool_calls = []
        for block in response.content:
            if block.type == "text":
                content += block.text
            elif block.type == "tool_use":
                tool_calls.append({
                    "name": block.name,
                    "arguments": json.dumps(block.input) if isinstance(block.input, dict) else str(block.input),
                })
        return {
            "content": content,
            "tool_calls": tool_calls,
            "usage": {
                "prompt_tokens": response.usage.input_tokens,
                "completion_tokens": response.usage.output_tokens,
            }
        }

    def chat(self, messages, model="claude-sonnet-4-20250514", tools=None, temperature=0.7, max_tokens=4096):
        from anthropic import Anthropic
        client = Anthropic(api_key=self.api_key)
        system = ""
        user_messages = []
        for m in messages:
            if m["role"] == "system":
                system += m["content"] + "\n"
            else:
                user_messages.append(m)
        kwargs = {"model": model, "messages": user_messages, "max_tokens": max_tokens, "temperature": temperature}
        if system.strip():
            kwargs["system"] = system.strip()
        if tools:
            kwargs["tools"] = self._normalize_anthropic_tools(tools)
        for attempt in range(self.max_retries):
            try:
                resp = client.messages.create(**kwargs)
                return self._normalize_response(resp)
            except Exception as e:
                self._sleep_or_raise(attempt, e)
