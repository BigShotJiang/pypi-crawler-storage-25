"""deepseek.py — DeepSeek adapter (OpenAI-compatible, 2 lines)."""
from .openai import OpenAIAdapter

class DeepSeekAdapter(OpenAIAdapter):
    """DeepSeek is OpenAI-compatible — just sets the base URL."""
    def __init__(self, api_key: str, **kwargs):
        super().__init__(api_key, base_url="https://api.deepseek.com", **kwargs)
