"""llm_adapters — F-LUCY-PROVIDER-ADAPTER-1: vendor-agnostic LLM adapter layer.

REGISTRY maps provider names to Adapter classes.
"""

from .base import BaseAdapter
from .openai import OpenAIAdapter
from .deepseek import DeepSeekAdapter
from .anthropic import AnthropicAdapter

REGISTRY = {
    "openai": OpenAIAdapter,
    "deepseek": DeepSeekAdapter,
    "anthropic": AnthropicAdapter,
}

__all__ = ["BaseAdapter", "OpenAIAdapter", "DeepSeekAdapter", "AnthropicAdapter", "REGISTRY"]
