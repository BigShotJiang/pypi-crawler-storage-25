import logging
import os
from typing import Callable, Optional

log = logging.getLogger(__name__)


def _send_telegram_alert(task_id: str, error: str) -> None:
    try:
        import requests
        token = os.environ.get('TELEGRAM_TOKEN', '')
        if not token:
            log.warning('TELEGRAM_TOKEN not set — cannot send alert for task %s', task_id)
            return
        chat_id = 8267616606
        text = f'[dispatch_with_retry] INTERNAL ERROR\ntask_id: {task_id}\nerror: {error}'
        requests.post(
            f'https://api.telegram.org/bot{token}/sendMessage',
            json={'chat_id': chat_id, 'text': text},
            timeout=10,
        )
    except Exception as _alert_err:
        log.error('Telegram alert send failed: %s', _alert_err)


def _build_retry_prompt(original_prompt: str, critique: str, task_context: dict) -> str:
    gate = task_context.get('gate', 2)
    review_round = task_context.get('review_round', 0)
    return (
        f'{original_prompt}\n\n'
        f'## PREVIOUS ATTEMPT FAILED (Gate {gate}, review_round={review_round})\n\n'
        f'## CRITIQUE FROM GATE\n{critique}\n\n'
        f'## REQUIRED\n'
        f"Fix every issue in the critique above. "
        f"Reproduce the DONE/DIDN'T TOUCH/VERIFICATION/OPEN CONCERNS format. "
        f'Paste real command output in VERIFICATION — not claimed output.'
    )


def dispatch_with_retry(
    task_id: str,
    task_prompt: str,
    agent_id: str,
    plan_summary: str,
    thinking: bool = True,
    task_type: str = 'complex',
    deepseek_peer_review: bool = False,
) -> dict:
    """Single function Neuro calls instead of manually pairing
    dispatch_deepseek_task + complete_task.

    Wires dispatch_deepseek_task → complete_task(retry_handler=_neuro_retry_handler).
    On gate FAIL, _neuro_retry_handler re-dispatches with the critique embedded
    in the prompt so the next attempt has explicit feedback on what to fix.

    On any unhandled exception: sends Telegram DM to Decker (8267616606) and re-raises.
    Returns same dict as dispatch_deepseek_task.
    """
    from aibrain.core.agent_dispatch import dispatch_deepseek_task
    from aibrain.core.companies import complete_task

    _captured_prompt = task_prompt

    def _neuro_retry_handler(critique: str, task_context: dict) -> str:
        retry_prompt = _build_retry_prompt(_captured_prompt, critique, task_context)
        result = dispatch_deepseek_task(
            task_id=task_id,
            task_prompt=retry_prompt,
            agent_id=agent_id,
            plan_summary=plan_summary,
            thinking=thinking,
            task_type=task_type,
            deepseek_peer_review=deepseek_peer_review,
        )
        return result.get('work_output', '')

    try:
        result = dispatch_deepseek_task(
            task_id=task_id,
            task_prompt=task_prompt,
            agent_id=agent_id,
            plan_summary=plan_summary,
            thinking=thinking,
            task_type=task_type,
            deepseek_peer_review=deepseek_peer_review,
        )
        work_output = result.get('work_output', '')
        complete_task(task_id, work_output=work_output, retry_handler=_neuro_retry_handler)
        return result
    except Exception as _err:
        log.error('dispatch_with_retry failed for task %s: %s', task_id, _err)
        _send_telegram_alert(task_id, str(_err))
        raise