"""
Gemini provider implementation for AIBrain.

Implements TextProvider and ReviewProvider contracts defined in
aibrain.core.provider_contract using the Google Gemini API (free tier:
1500 req/day on gemini-2.5-flash, 50 req/day on gemini-2.5-pro at zero
cost via aistudio.google.com) via urllib. No external Google SDK required.
"""

import json
import logging
import os
import time
import urllib.request
import urllib.error
import asyncio
from typing import Any, Dict, Optional

from aibrain.core.provider_contract import TextProvider, ReviewProvider

logger = logging.getLogger("aibrain.provider_gemini")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"

# Model IDs as of 2026-05-12
MODEL_FLASH = "gemini-2.5-flash"
MODEL_PRO = "gemini-2.5-pro"
MODEL_FLASH_15 = "gemini-1.5-flash"

DEFAULT_MODEL_FOR_TASK_CLASS: Dict[str, str] = {
    "cheap": MODEL_FLASH,
    "judgment": MODEL_FLASH,
    "review": MODEL_PRO,
}

SUPPORTED_TASK_CLASSES = list(DEFAULT_MODEL_FOR_TASK_CLASS.keys())

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class GeminiProviderError(Exception):
    """Raised when the Gemini provider encounters an error."""

    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_api_key(config: Dict[str, Any]) -> str:
    """Extract the Gemini API key from config or environment."""
    api_key = config.get("api_key") or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise GeminiProviderError(
            "Gemini API key not found in config or GEMINI_API_KEY env var"
        )
    return api_key


def _resolve_model(config: Dict[str, Any], task_class: str) -> str:
    """Determine which model to use for a given task class."""
    model = config.get("model")
    if model:
        return model
    if task_class not in DEFAULT_MODEL_FOR_TASK_CLASS:
        raise GeminiProviderError(
            f"Unsupported task_class '{task_class}'. "
            f"Supported: {SUPPORTED_TASK_CLASSES}"
        )
    return DEFAULT_MODEL_FOR_TASK_CLASS[task_class]


def _call_gemini_http(
    api_key: str,
    model: str,
    system_prompt: str,
    user_content: str,
    max_tokens: int,
    temperature: float,
) -> Dict[str, Any]:
    """Synchronous HTTP call to the Gemini generateContent API.

    Returns a dict with keys: content, tokens_in, tokens_out, model_used, latency_ms.
    """
    url = f"{GEMINI_API_BASE}/{model}:generateContent?key={api_key}"

    body: Dict[str, Any] = {
        "contents": [{"role": "user", "parts": [{"text": user_content}]}],
        "generationConfig": {
            "maxOutputTokens": max_tokens,
            "temperature": temperature,
        },
    }
    if system_prompt:
        body["systemInstruction"] = {"parts": [{"text": system_prompt}]}

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={"content-type": "application/json"},
        method="POST",
    )

    start = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            raw = resp.read().decode("utf-8")
            elapsed_ms = (time.monotonic() - start) * 1000.0
    except urllib.error.HTTPError as exc:
        err_body = exc.read().decode("utf-8", errors="replace")
        raise GeminiProviderError(
            f"Gemini HTTP {exc.code}: {err_body}"
        ) from exc
    except Exception as exc:
        raise GeminiProviderError(f"Gemini request failed: {exc}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise GeminiProviderError(f"Invalid JSON from Gemini: {raw[:200]}") from exc

    # Extract text from candidates
    text_parts: list[str] = []
    candidates = payload.get("candidates", [])
    if candidates:
        content_obj = candidates[0].get("content", {})
        for part in content_obj.get("parts", []):
            if "text" in part:
                text_parts.append(part["text"])
    content = "\n".join(text_parts)

    usage = payload.get("usageMetadata", {})
    tokens_in = usage.get("promptTokenCount", 0)
    tokens_out = usage.get("candidatesTokenCount", 0)
    model_used = payload.get("modelVersion", model)

    return {
        "content": content,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "model_used": model_used,
        "latency_ms": round(elapsed_ms, 2),
    }


# ---------------------------------------------------------------------------
# Schema sanitisation — Gemini is stricter than OpenAI on JSON Schema
# ---------------------------------------------------------------------------

def _sanitize_schema_for_gemini(schema: Any) -> Any:
    """Recursively patch an OpenAI-shaped JSON schema for Gemini strictness.

    Differences from OpenAI's schema acceptance (observed in real 400
    responses 2026-05-21):
      - Gemini REQUIRES every {"type":"array"} schema to declare "items".
        OpenAI tolerates the omission. Default to permissive
        {"type":"string"} when missing.
      - Gemini rejects unknown keys (e.g. "default", "examples", "title").
        We currently leave those alone — only patch the array.items hole
        because that's the one we've observed reject Lucy's full tool list.
    """
    if isinstance(schema, dict):
        out = {k: _sanitize_schema_for_gemini(v) for k, v in schema.items()}
        if out.get("type") == "array" and "items" not in out:
            out["items"] = {"type": "string"}
        # If properties dict exists, sanitize each property value.
        if isinstance(out.get("properties"), dict):
            out["properties"] = {
                pk: _sanitize_schema_for_gemini(pv)
                for pk, pv in out["properties"].items()
            }
        return out
    if isinstance(schema, list):
        return [_sanitize_schema_for_gemini(x) for x in schema]
    return schema


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------


class GeminiTextProvider(TextProvider):
    """Concrete TextProvider backed by Gemini."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke the Gemini text completion API asynchronously."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "cheap")
        model = _resolve_model(config, task_class)

        system_prompt = request.get("system_prompt", "")
        prompt = request.get("prompt", "")
        max_tokens = request.get("max_tokens", 1024)
        temperature = request.get("temperature", 0.7)

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_gemini_http,
            api_key,
            model,
            system_prompt,
            prompt,
            max_tokens,
            temperature,
        )

        return {
            "content": result["content"],
            "tokens_in": result["tokens_in"],
            "tokens_out": result["tokens_out"],
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous wrapper for environments without an event loop."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "cheap")
        model = _resolve_model(config, task_class)

        system_prompt = request.get("system_prompt", "")
        prompt = request.get("prompt", "")
        max_tokens = request.get("max_tokens", 1024)
        temperature = request.get("temperature", 0.7)

        result = _call_gemini_http(
            api_key, model, system_prompt, prompt, max_tokens, temperature
        )

        return {
            "content": result["content"],
            "tokens_in": result["tokens_in"],
            "tokens_out": result["tokens_out"],
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    # ------------------------------------------------------------------
    # Chat-with-tools dispatch surface
    # ------------------------------------------------------------------
    # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21).
    # Gemini uses generateContent with a non-OpenAI message shape:
    # system is a top-level systemInstruction field, tool results are
    # functionResponse parts inside a user message, and tool calls come
    # back as functionCall parts inside the model message. This method
    # translates OpenAI-shaped messages/tools to Gemini format on the
    # way in, and the response back to OpenAI-shaped on the way out so
    # Lucy's chat loop is unchanged.

    def chat_with_tools(
        self,
        model: str,
        messages: list,
        tools: Optional[list] = None,
        tool_choice: Optional[Any] = None,
        api_key: Optional[str] = None,
        stream: bool = False,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **_extra: Any,
    ) -> Any:
        from aibrain.core.provider_contract import (
            make_openai_shaped_response,
            make_tool_call,
            _stream_response_from_text,
        )
        key = api_key or self.config.get("api_key") or os.environ.get("GEMINI_API_KEY")
        if not key:
            raise GeminiProviderError(
                "No Gemini API key. Set GEMINI_API_KEY or pass api_key=..."
            )

        # 1) Pull system message(s) out — Gemini wants them top-level.
        system_parts: list[str] = []
        gemini_contents: list[Dict[str, Any]] = []
        for m in messages:
            role = m.get("role", "user")
            content = m.get("content")
            if role == "system":
                if isinstance(content, str) and content:
                    system_parts.append(content)
                continue
            if role == "tool":
                # OpenAI 'tool' message -> Gemini user message containing
                # a functionResponse part.
                gemini_contents.append({
                    "role": "user",
                    "parts": [{
                        "functionResponse": {
                            "name": m.get("name") or "",
                            "response": {"content": str(content) if content is not None else ""},
                        }
                    }],
                })
                continue
            if role == "assistant":
                # Assistant may have content + tool_calls (OpenAI shape).
                parts: list[Dict[str, Any]] = []
                if isinstance(content, str) and content:
                    parts.append({"text": content})
                tcs = m.get("tool_calls") or []
                for tc in tcs:
                    fn = tc.get("function", {})
                    raw_args = fn.get("arguments", "{}") or "{}"
                    try:
                        parsed_args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                    except json.JSONDecodeError:
                        parsed_args = {}
                    parts.append({
                        "functionCall": {
                            "name": fn.get("name", ""),
                            "args": parsed_args or {},
                        }
                    })
                if not parts:
                    parts = [{"text": ""}]
                gemini_contents.append({"role": "model", "parts": parts})
                continue
            # role == 'user' (or anything else)
            if isinstance(content, list):
                gemini_contents.append({"role": "user", "parts": content})
            else:
                gemini_contents.append({
                    "role": "user",
                    "parts": [{"text": str(content) if content is not None else ""}],
                })

        system_text = "\n\n".join(p for p in system_parts if p)

        # 2) Translate OpenAI tool schemas to Gemini function_declarations.
        # F-LUCY-GEMINI-PROVIDER (-JSHGYiAy8g, 2026-05-21): Gemini's schema
        # validator is stricter than OpenAI's — it rejects array properties
        # that omit "items". Sanitise on the way in: any array without
        # "items" gets a permissive default. Verified against real 400
        # response: "function_declarations[N].parameters.properties[X].items:
        # missing field" — Lucy's 50+ tool list includes at least one such
        # property (e.g. "steps": {"type": "array"} without items).
        function_declarations: list[Dict[str, Any]] = []
        if tools:
            for t in tools:
                fn = t.get("function", {})
                params = fn.get("parameters") or {"type": "object", "properties": {}}
                params = _sanitize_schema_for_gemini(params)
                function_declarations.append({
                    "name": fn.get("name", ""),
                    "description": fn.get("description", ""),
                    "parameters": params,
                })

        body: Dict[str, Any] = {
            "contents": gemini_contents,
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": temperature,
            },
        }
        if system_text:
            body["systemInstruction"] = {"parts": [{"text": system_text}]}
        if function_declarations:
            body["tools"] = [{"function_declarations": function_declarations}]
            # tool_choice: 'auto' / None / dict — map to Gemini shape.
            if tool_choice in (None, "auto"):
                # Default — Gemini decides.
                pass
            elif isinstance(tool_choice, dict) and tool_choice.get("type") == "function":
                body["toolConfig"] = {
                    "functionCallingConfig": {
                        "mode": "ANY",
                        "allowedFunctionNames": [tool_choice.get("function", {}).get("name", "")],
                    }
                }

        # 3) POST to Gemini generateContent API.
        url = f"{GEMINI_API_BASE}/{model}:generateContent?key={key}"
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url, data=data,
            headers={"content-type": "application/json"},
            method="POST",
        )
        start = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=180) as resp_http:
                raw = resp_http.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            raise GeminiProviderError(
                f"Gemini HTTP {exc.code}: {err_body}"
            ) from exc
        except Exception as exc:
            raise GeminiProviderError(f"Gemini chat request failed: {exc}") from exc

        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise GeminiProviderError(
                f"Invalid JSON from Gemini: {raw[:300]}"
            ) from exc
        latency_ms = round((time.monotonic() - start) * 1000.0, 2)

        # 4) Translate Gemini content parts -> OpenAI text+tool_calls.
        text_parts: list[str] = []
        tool_calls = []
        candidates = payload.get("candidates", [])
        if candidates:
            content_obj = candidates[0].get("content", {})
            for i, part in enumerate(content_obj.get("parts", [])):
                if "text" in part:
                    text_parts.append(part["text"])
                elif "functionCall" in part:
                    fc = part["functionCall"]
                    tool_calls.append(make_tool_call(
                        call_id=f"toolu_{i}",
                        name=fc.get("name", ""),
                        arguments_json=json.dumps(fc.get("args") or {}),
                    ))

        content = "\n".join(p for p in text_parts if p)
        usage = payload.get("usageMetadata") or {}
        model_used = payload.get("modelVersion", model)
        finish_reason = "tool_calls" if tool_calls else "stop"

        if stream:
            # Non-streaming under the hood; wrap text as a single-chunk
            # iterator so Lucy's _stream_wrapped() path still works.
            return _stream_response_from_text(content, model=model_used)

        return make_openai_shaped_response(
            content=content,
            tool_calls=tool_calls or None,
            role="assistant",
            model=model_used,
            finish_reason=finish_reason,
            usage={
                "prompt_tokens": usage.get("promptTokenCount", 0),
                "completion_tokens": usage.get("candidatesTokenCount", 0),
                "total_tokens": usage.get("totalTokenCount", 0),
            },
        )


class GeminiReviewProvider(ReviewProvider):
    """Concrete ReviewProvider backed by Gemini.

    Expects the model to return a structured response containing
    VERDICT, SCORE, and CRITIQUE markers that are parsed out.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke the Gemini API for a review asynchronously."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "review")
        model = _resolve_model(config, task_class)

        persona = request.get("persona", "")
        work_output = request.get("work_output", "")
        acceptance_criteria = request.get("acceptance_criteria", "")

        system_prompt = (
            "You are a meticulous reviewer. Evaluate the work output against "
            "the acceptance criteria. Respond with exactly three lines:\n"
            "VERDICT: PASS or FAIL\n"
            "SCORE: a float between 0.0 and 1.0\n"
            "CRITIQUE: a brief explanation"
        )
        user_content = (
            f"Persona: {persona}\n\n"
            f"Work Output:\n{work_output}\n\n"
            f"Acceptance Criteria:\n{acceptance_criteria}"
        )

        max_tokens = request.get("max_tokens", 512)
        temperature = request.get("temperature", 0.2)

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_gemini_http,
            api_key,
            model,
            system_prompt,
            user_content,
            max_tokens,
            temperature,
        )

        from aibrain.core.provider_contract import parse_review_response
        verdict, score, critique = parse_review_response(result["content"])

        return {
            "verdict": verdict,
            "score": score,
            "critique": critique,
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous wrapper for environments without an event loop."""
        config = self.config or {}
        api_key = _get_api_key(config)
        task_class = request.get("task_class", "review")
        model = _resolve_model(config, task_class)

        persona = request.get("persona", "")
        work_output = request.get("work_output", "")
        acceptance_criteria = request.get("acceptance_criteria", "")

        system_prompt = (
            "You are a meticulous reviewer. Evaluate the work output against "
            "the acceptance criteria. Respond with exactly three lines:\n"
            "VERDICT: PASS or FAIL\n"
            "SCORE: a float between 0.0 and 1.0\n"
            "CRITIQUE: a brief explanation"
        )
        user_content = (
            f"Persona: {persona}\n\n"
            f"Work Output:\n{work_output}\n\n"
            f"Acceptance Criteria:\n{acceptance_criteria}"
        )

        max_tokens = request.get("max_tokens", 512)
        temperature = request.get("temperature", 0.2)

        result = _call_gemini_http(
            api_key, model, system_prompt, user_content, max_tokens, temperature
        )

        from aibrain.core.provider_contract import parse_review_response
        verdict, score, critique = parse_review_response(result["content"])

        return {
            "verdict": verdict,
            "score": score,
            "critique": critique,
            "model_used": result["model_used"],
            "latency_ms": result["latency_ms"],
        }

    # Review response parsing is handled by the shared
    # parse_review_response() function in provider_contract.


# ---------------------------------------------------------------------------
# Smoke test (instantiation only — no API calls)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Instantiate providers with minimal config
    text_provider = GeminiTextProvider(config={"api_key": "dummy"})
    review_provider = GeminiReviewProvider(config={"api_key": "dummy"})

    # Verify they are instances of the correct types
    assert isinstance(text_provider, TextProvider)
    assert isinstance(review_provider, ReviewProvider)

    # Verify constants
    assert "cheap" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "judgment" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "review" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert MODEL_FLASH == "gemini-2.5-flash"

    print("provider_gemini smoke test OK")
