"""aibrain.core.image_vision — shared vision engine for Lucy + dashboard.

encode_image: base64-encode an image file.
detect_image_media_type: detect MIME from magic bytes.
describe_image: route through ProviderRouter('vision') for a textual description.

Reference: AI-content-describer description_service.py pattern.
"""
import base64
import os.path
from typing import Optional

from aibrain.core.provider_contract import ProviderRouter


def encode_image(image_path: str) -> str:
    """Read an image file from disk and return its base64‑encoded string."""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def detect_image_media_type(data: str) -> str:
    """Detect the MIME type of an image from either a file path or base64 data.

    Examines magic bytes rather than relying on file extensions.
    """
    # Heuristic: a short string that exists as a file is treated as a path.
    if len(data) < 1024 and os.path.isfile(data):
        with open(data, "rb") as f:
            header = f.read(32)
    else:
        header = base64.b64decode(data[:32])

    if header[:3] == b'\xff\xd8\xff':
        return "image/jpeg"
    if header[:8] == b'\x89PNG\r\n\x1a\n':
        return "image/png"
    if header[:4] == b'GIF8':
        return "image/gif"
    if header[:4] == b'RIFF' and header[8:12] == b'WEBP':
        return "image/webp"
    # Fallback to PNG if detection fails.
    return "image/png"


def describe_image(
    image_path: str,
    prompt: str = "Describe this image in detail.",
) -> str:
    """Obtain a textual description of an image using a vision‑capable provider.

    The actual vision API call is routed through the AI Brain
    ProviderRouter, which selects the appropriate provider (e.g. OpenAI,
    Anthropic) based on user configuration in ``~/.aibrain/config.yaml``.
    """
    router = ProviderRouter()

    # TODO: Confirm that 'vision' is a valid task_class in ProviderRouter.
    # The returned provider must implement ``describe(image_path, prompt)``.
    provider: Optional[object] = router.get_provider("vision")
    if provider is None:
        raise RuntimeError(
            "No vision provider configured. Please set a vision provider "
            "in ~/.aibrain/config.yaml"
        )
    # The provider interface is expected to expose a ``describe`` method.
    if not hasattr(provider, "describe"):
        raise NotImplementedError(
            f"Vision provider {type(provider).__name__} does not implement "
            "the required ``describe(image_path, prompt)`` method."
        )
    return provider.describe(image_path, prompt)