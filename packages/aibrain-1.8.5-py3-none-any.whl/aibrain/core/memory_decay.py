"""Ebbinghaus decay curve for memory retention scoring.

Implements the mathematical Ebbinghaus forgetting curve::

    R(m, t) = exp(-t / S(m))

where ``R`` is the retention probability at elapsed time ``t`` (days since last
access) and ``S(m)`` is the *memory strength* — a positive scalar assembled
from four factors:

    access_frequency      — how often the memory has been retrieved
    importance            — honest quality_score if available (0.0-1.0)
    confirmation_count    — three-signal learning events
                            (corrections + self-reflections + praise)
    emotional_salience    — placeholder, honest-None for now

The strength function is multiplicative over the factors that are *actually
known*. When a factor cannot be computed we return ``None`` for it and skip
it rather than faking a default — this keeps the honest-rubric invariant.

A small floor is applied so strength never collapses to zero (which would
pin retention at zero for all t > 0).

Inspired by SLM V3.3 + McClelland CLS. This module is a prototype: it does
NOT mutate any rows, does NOT write to the DB, and is opt-in for callers.
"""

from __future__ import annotations

import math
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterable, Optional

# ---------------------------------------------------------------------------
# Tunables
# ---------------------------------------------------------------------------

# Base strength (in days). Fresh memories with zero known factors decay with
# a time constant of BASE_STRENGTH_DAYS — a week-ish half-life-ish curve.
BASE_STRENGTH_DAYS: float = 7.0

# Per-factor weights. These are small because strength is MULTIPLIED by
# (1 + weight * factor_value), so even modest factor values move the curve
# noticeably without letting any single signal dominate.
WEIGHT_ACCESS_FREQUENCY: float = 0.15   # log-scaled on access_count
WEIGHT_IMPORTANCE: float = 2.00         # importance is already 0..1
WEIGHT_CONFIRMATION: float = 0.30       # log-scaled on confirmation_count
WEIGHT_EMOTIONAL_SALIENCE: float = 1.00  # reserved; currently unused

# Never let strength fall below this (avoids div-by-zero).
STRENGTH_FLOOR_DAYS: float = 0.5

# Clamp retention into [0, 1].
RETENTION_FLOOR: float = 0.0
RETENTION_CEILING: float = 1.0


# ---------------------------------------------------------------------------
# Data container
# ---------------------------------------------------------------------------


@dataclass
class DecayFactors:
    """Honest snapshot of the four strength factors.

    Any factor that cannot be computed from the available data is left as
    ``None`` — callers must NOT substitute a default silently.
    """

    access_frequency: Optional[int] = None
    importance: Optional[float] = None
    confirmation_count: Optional[int] = None
    emotional_salience: Optional[float] = None  # placeholder — honest-None

    # Provenance / debugging — populated by the loader when it runs.
    notes: list[str] = field(default_factory=list)

    def known(self) -> dict[str, float]:
        """Return only the factors that are actually known (not None)."""
        out: dict[str, float] = {}
        if self.access_frequency is not None:
            out["access_frequency"] = float(self.access_frequency)
        if self.importance is not None:
            out["importance"] = float(self.importance)
        if self.confirmation_count is not None:
            out["confirmation_count"] = float(self.confirmation_count)
        if self.emotional_salience is not None:
            out["emotional_salience"] = float(self.emotional_salience)
        return out


# ---------------------------------------------------------------------------
# Pure math
# ---------------------------------------------------------------------------


def strength(factors: DecayFactors) -> float:
    """Compute memory strength S(m) in days from the known factors.

    Multiplicative combination: each known factor contributes a
    ``(1 + weight * transform(value))`` multiplier to the base strength.
    Unknown (None) factors are skipped — we do not fake them.
    """
    s = BASE_STRENGTH_DAYS

    if factors.access_frequency is not None:
        # Log-scaled: access_count=1 -> log(2)≈0.69, access_count=10 -> 2.40,
        # access_count=100 -> 4.61. Prevents hot memories from dominating.
        s *= 1.0 + WEIGHT_ACCESS_FREQUENCY * math.log1p(max(0, factors.access_frequency))

    if factors.importance is not None:
        imp = max(0.0, min(1.0, factors.importance))
        s *= 1.0 + WEIGHT_IMPORTANCE * imp

    if factors.confirmation_count is not None:
        s *= 1.0 + WEIGHT_CONFIRMATION * math.log1p(max(0, factors.confirmation_count))

    if factors.emotional_salience is not None:
        sal = max(0.0, min(1.0, factors.emotional_salience))
        s *= 1.0 + WEIGHT_EMOTIONAL_SALIENCE * sal

    return max(s, STRENGTH_FLOOR_DAYS)


def retention(elapsed_days: float, factors: DecayFactors) -> float:
    """Ebbinghaus retention ``R = exp(-t/S)`` clamped into [0, 1]."""
    if elapsed_days < 0:
        # Future timestamp — treat as "just accessed".
        elapsed_days = 0.0
    s = strength(factors)
    r = math.exp(-elapsed_days / s)
    return max(RETENTION_FLOOR, min(RETENTION_CEILING, r))


# ---------------------------------------------------------------------------
# DB loader — maps a memory row to DecayFactors honestly
# ---------------------------------------------------------------------------


def _parse_ts(ts: Optional[str]) -> Optional[datetime]:
    """Parse a SQLite ``datetime('now')`` timestamp. Returns naive UTC dt."""
    if not ts:
        return None
    try:
        # SQLite format: 'YYYY-MM-DD HH:MM:SS' (no tz)
        return datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except ValueError:
        pass
    try:
        # ISO format fallback
        d = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d
    except ValueError:
        return None


def _load_memory_row(db: sqlite3.Connection, memory_id: int) -> Optional[dict]:
    row = db.execute(
        "SELECT id, importance, access_count, last_accessed, created "
        "FROM memories WHERE id = ?",
        (memory_id,),
    ).fetchone()
    if row is None:
        return None
    if isinstance(row, sqlite3.Row):
        return dict(row)
    return {
        "id": row[0],
        "importance": row[1],
        "access_count": row[2],
        "last_accessed": row[3],
        "created": row[4],
    }


def _count_confirmations(db: sqlite3.Connection, memory_id: int) -> Optional[int]:
    """Count three-signal events for this memory.

    Looks at ``memory_history`` for correction / praise / reflection actions.
    Returns ``None`` if the history table is missing — we will not fake a
    default.
    """
    try:
        cur = db.execute(
            "SELECT COUNT(*) FROM memory_history "
            "WHERE memory_id = ? AND action IN "
            "('correction','self_reflection','praise','reinforce','confirm')",
            (memory_id,),
        )
        return int(cur.fetchone()[0])
    except sqlite3.OperationalError:
        return None


def load_factors(db: sqlite3.Connection, memory_id: int) -> Optional[DecayFactors]:
    """Load DecayFactors for ``memory_id`` from ``db``.

    Returns ``None`` if the memory does not exist. Missing factors are left
    as ``None`` in the returned DecayFactors — the caller never gets a fake
    zero.
    """
    row = _load_memory_row(db, memory_id)
    if row is None:
        return None

    factors = DecayFactors()

    # access_frequency: non-null is the honest case; null -> leave None.
    ac = row.get("access_count")
    if ac is not None:
        factors.access_frequency = int(ac)

    # importance: default 0.5 is a Brain fallback, but we treat it as
    # known here because it is the stored value. Callers who want to
    # honor "never-scored" can check for exact 0.5 if they like.
    imp = row.get("importance")
    if imp is not None:
        factors.importance = float(imp)

    cc = _count_confirmations(db, memory_id)
    if cc is not None:
        factors.confirmation_count = cc

    # emotional_salience — deliberately not computed. Honest-None.
    factors.emotional_salience = None
    factors.notes.append("emotional_salience: not yet computed")

    return factors


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compute_decay_score(
    memory_id: int,
    now_ts: Optional[datetime] = None,
    db: Optional[sqlite3.Connection] = None,
) -> Optional[float]:
    """Return a 0.0-1.0 retention score for ``memory_id`` at ``now_ts``.

    Args:
        memory_id: The memories.id to score.
        now_ts: Evaluation time (UTC). Defaults to ``datetime.now(UTC)``.
        db: Optional open connection. If None, opens the canonical aibrain.db
            via :func:`aibrain_db.get_db`.

    Returns:
        A float in [0, 1] or ``None`` if the memory does not exist.
    """
    if now_ts is None:
        now_ts = datetime.now(timezone.utc)
    elif now_ts.tzinfo is None:
        now_ts = now_ts.replace(tzinfo=timezone.utc)

    owns_db = False
    if db is None:
        import aibrain_db  # type: ignore
        db = aibrain_db.get_db()
        owns_db = False  # get_db() returns a shared connection

    try:
        row = _load_memory_row(db, memory_id)
        if row is None:
            return None

        # Pick the reference timestamp: last_accessed preferred, fall back
        # to created. If both are missing (shouldn't happen on a well-formed
        # row) use now_ts → elapsed=0.
        ref = _parse_ts(row.get("last_accessed")) or _parse_ts(row.get("created"))
        if ref is None:
            elapsed_days = 0.0
        else:
            elapsed_days = max(0.0, (now_ts - ref).total_seconds() / 86400.0)

        factors = load_factors(db, memory_id)
        if factors is None:
            return None

        return retention(elapsed_days, factors)
    finally:
        if owns_db:
            try:
                db.close()
            except Exception:
                pass


def compute_decay_fast(row: dict, now_ts: Optional[datetime] = None) -> Optional[float]:
    """Zero-DB Ebbinghaus retention from a row that already carries the
    needed columns (importance, access_count, last_accessed|created).

    IDENTICAL curve to compute_decay_score (same _parse_ts + retention());
    the only difference is confirmation_count is left honest-None (no
    memory_history query) — which is exactly the DecayFactors design
    (unknown factor -> None, omitted from strength()), not a silent default.
    Use in hot paths (recall rerank) where compute_decay_score's 2
    per-memory DB queries would stall retrieval (~3s/call measured)."""
    if now_ts is None:
        now_ts = datetime.now(timezone.utc)
    elif now_ts.tzinfo is None:
        now_ts = now_ts.replace(tzinfo=timezone.utc)
    ref = _parse_ts(row.get("last_accessed")) or _parse_ts(row.get("created"))
    if ref is None:
        elapsed_days = 0.0
    else:
        elapsed_days = max(0.0, (now_ts - ref).total_seconds() / 86400.0)
    ac = row.get("access_count")
    imp = row.get("importance")
    if ac is None and imp is None:
        return None  # no usable signal -> honest None (same as missing factors)
    factors = DecayFactors(
        access_frequency=int(ac) if ac is not None else None,
        importance=float(imp) if imp is not None else None,
        confirmation_count=None,   # honest-None: no memory_history query
        emotional_salience=None,
    )
    return retention(elapsed_days, factors)


def rerank_by_decay(
    results: Iterable[dict],
    *,
    now_ts: Optional[datetime] = None,
    db: Optional[sqlite3.Connection] = None,
    blend: float = 0.3,
    score_key: str = "score",
    id_key: str = "id",
    decay_key: str = "decay_score",
) -> list[dict]:
    """Optional re-ranker stage for memory_recall output.

    Blends each result's existing relevance ``score`` with its decay score::

        final = (1 - blend) * score + blend * decay

    The decay score is attached to each result dict under ``decay_key`` so
    callers can inspect it. Results missing an id or whose decay cannot be
    computed pass through with ``decay_score = None`` and their original
    score unchanged. Default ``blend`` is modest (0.3) to preserve relevance
    as the primary signal — this is an *opt-in* rerank, not a replacement.

    This function is intentionally pure with respect to the caller's data:
    it returns a new sorted list and does not mutate the inputs in place
    beyond adding the ``decay_key`` field.
    """
    if not 0.0 <= blend <= 1.0:
        raise ValueError("blend must be in [0, 1]")

    items = list(results)
    for item in items:
        mid = item.get(id_key)
        if mid is None:
            item[decay_key] = None
            continue
        try:
            # Fast path: if the result row already carries the decay columns,
            # compute with ZERO DB round-trips. compute_decay_score does 2
            # per-memory queries (~3s/call measured) -> would stall recall at
            # any limit>1. Fall back to the slow path only if fields absent.
            if isinstance(item, dict) and ("last_accessed" in item or "created" in item) \
                    and ("importance" in item or "access_count" in item):
                decay = compute_decay_fast(item, now_ts=now_ts)
            else:
                decay = compute_decay_score(int(mid), now_ts=now_ts, db=db)
        except Exception:
            decay = None
        item[decay_key] = decay
        if decay is not None and score_key in item and item[score_key] is not None:
            item[score_key] = (1.0 - blend) * float(item[score_key]) + blend * decay

    items.sort(key=lambda x: x.get(score_key) or 0.0, reverse=True)
    return items


# ---------------------------------------------------------------------------
# Simplified public API — decay_strength() + update_access_time()
# ---------------------------------------------------------------------------

#: Minimum floor returned by :func:`decay_strength` so memories never fully vanish.
DECAY_FLOOR: float = 0.05


def decay_strength(
    importance: float,
    confidence: float,
    age_days: float,
    access_count: int,
) -> float:
    """Ebbinghaus retention: R = exp(-t/S)

    where S = stability (importance * confidence * log1p(access_count))
    t = age_days
    Returns 0.0-1.0 effective retention score.

    Higher importance + higher confidence + more access = slower decay.
    Floor of 0.05 — memories never fully vanish, they just fade.
    """
    # Stability: multiplicative over the three available signals.
    # log1p(0) = 0 so we add 1 to prevent S collapsing to zero on first access.
    stability = (
        max(0.0, min(1.0, importance))
        * max(0.0, min(1.0, confidence))
        * math.log1p(max(0, access_count) + 1)  # +1 so log1p(1)=ln(2)≈0.69 for new memories
    )
    # Safety floor — stability must be strictly positive to avoid ZeroDivisionError
    stability = max(stability, 1e-6)

    t = max(0.0, age_days)
    r = math.exp(-t / stability)

    # Clamp into [DECAY_FLOOR, 1.0]
    return max(DECAY_FLOOR, min(1.0, r))


def update_access_time(memory_id: int, db=None) -> bool:
    """Increment access_count and set last_accessed = now for ``memory_id``.

    This is the reinforcement signal that slows decay. Safe to call multiple
    times (idempotent with respect to correctness — each call is a legitimate
    access event).

    Args:
        memory_id: The memories.id to update.
        db: Optional open sqlite3.Connection. If None, opens via aibrain_db.get_db().

    Returns:
        True if a row was updated, False if the memory_id was not found.
    """
    owns_db = False
    if db is None:
        import aibrain_db  # type: ignore
        db = aibrain_db.get_db()

    try:
        cur = db.execute(
            "UPDATE memories "
            "SET access_count = COALESCE(access_count, 0) + 1, "
            "    last_accessed = datetime('now') "
            "WHERE id = ?",
            (memory_id,),
        )
        db.commit()
        return cur.rowcount > 0
    finally:
        if owns_db:
            try:
                db.close()
            except Exception:
                pass


__all__ = [
    "BASE_STRENGTH_DAYS",
    "STRENGTH_FLOOR_DAYS",
    "DECAY_FLOOR",
    "DecayFactors",
    "strength",
    "retention",
    "load_factors",
    "compute_decay_score",
    "rerank_by_decay",
    "decay_strength",
    "update_access_time",
]
