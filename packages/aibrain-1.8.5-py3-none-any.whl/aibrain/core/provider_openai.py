import os
import json
import time
import asyncio
import logging
import urllib.request
import urllib.error
from typing import Dict, Any, Optional

from aibrain.core.provider_contract import TextProvider, ReviewProvider

logger = logging.getLogger(__name__)

DEFAULT_MODEL_FOR_TASK_CLASS = {
    "cheap": "gpt-4o-mini",
    "judgment": "gpt-5-mini",
    "review": "gpt-5",
}

SUPPORTED_TASK_CLASSES = ["cheap", "judgment", "review"]

OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"


class OpenAIProviderError(Exception):
    """Custom exception for OpenAI provider errors."""
    pass


def _get_api_key(config: Dict[str, Any]) -> str:
    """Retrieve the OpenAI API key from config or environment."""
    env_var = config.get("api_key_env", "OPENAI_API_KEY")
    api_key = os.environ.get(env_var)
    if not api_key:
        raise OpenAIProviderError(
            f"OpenAI API key not found. Set the {env_var} environment variable."
        )
    return api_key


def _resolve_model(config: Dict[str, Any], task_class: str) -> str:
    """Resolve the model ID based on task class and config overrides."""
    if task_class not in SUPPORTED_TASK_CLASSES:
        raise OpenAIProviderError(
            f"Unsupported task class: {task_class}. Supported: {SUPPORTED_TASK_CLASSES}"
        )
    model_override = config.get("model_override")
    if model_override:
        return model_override
    return DEFAULT_MODEL_FOR_TASK_CLASS[task_class]


def _call_openai_http(
    model: str,
    system: str,
    user: str,
    api_key: str,
    max_tokens: int,
    temperature: float,
    image: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Make a synchronous HTTP call to the OpenAI Chat Completions API.

    When *image* is provided ({"data": <base64>, "media_type": <mime>}) the
    user message is sent as a vision content list; otherwise plain text
    (byte-identical to the prior behaviour)."""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    if image is not None:
        messages.append({
            "role": "user",
            "content": [
                {"type": "text", "text": user},
                {"type": "image_url", "image_url": {
                    "url": f"data:{image['media_type']};base64,{image['data']}"}},
            ],
        })
    else:
        messages.append({"role": "user", "content": user})

    body = {
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "messages": messages,
    }

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(OPENAI_API_URL, data=data, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req) as response:
            response_data = json.loads(response.read().decode("utf-8"))
            return response_data
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8") if e.fp else ""
        raise OpenAIProviderError(
            f"OpenAI API HTTP {e.code} error: {error_body}"
        ) from e
    except urllib.error.URLError as e:
        raise OpenAIProviderError(f"OpenAI API connection error: {e.reason}") from e
    except json.JSONDecodeError as e:
        raise OpenAIProviderError(f"Failed to parse OpenAI API response: {e}") from e


class OpenAITextProvider(TextProvider):
    """Concrete TextProvider implementation for OpenAI Chat Completions API."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21):
        # tolerate missing env var at construction time so dispatch_chat()
        # callers can pass api_key=... explicitly later. _get_api_key still
        # fires at invoke()/chat_with_tools() time.
        try:
            self.api_key: Optional[str] = _get_api_key(config)
        except OpenAIProviderError:
            self.api_key = config.get("api_key")  # may still be None — checked at call

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Asynchronously invoke the OpenAI API."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._invoke_sync, request)

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous implementation of the invoke logic."""
        image = request.get("image")
        if image:
            model = request.get("model_override", "gpt-4o")
        else:
            model = _resolve_model(self.config, request.get("task_class", "judgment"))
        start_time = time.time()

        logger.info(
            "Calling OpenAI API: model=%s, task_class=%s, max_tokens=%d, temperature=%.2f",
            model,
            request.get("task_class", "judgment"),
            request.get("max_tokens", 4096),
            request.get("temperature", 0.7),
        )

        response_data = _call_openai_http(
            model=model,
            system=request.get("system_prompt", ""),
            user=request.get("prompt", ""),
            api_key=self.api_key,
            max_tokens=request.get("max_tokens", 4096),
            temperature=request.get("temperature", 0.7),
            image=image,
        )

        latency_ms = int((time.time() - start_time) * 1000)

        try:
            content = response_data["choices"][0]["message"]["content"]
            tokens_in = response_data["usage"]["prompt_tokens"]
            tokens_out = response_data["usage"]["completion_tokens"]
            model_used = response_data.get("model", model)
        except (KeyError, IndexError) as e:
            raise OpenAIProviderError(
                f"Unexpected OpenAI API response structure: {response_data}"
            ) from e

        logger.info(
            "OpenAI API call successful: model=%s, tokens_in=%d, tokens_out=%d, latency_ms=%d",
            model_used,
            tokens_in,
            tokens_out,
            latency_ms,
        )

        return {
            "content": content,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "model_used": model_used,
            "latency_ms": latency_ms,
        }

    # ------------------------------------------------------------------
    # Chat-with-tools dispatch surface
    # ------------------------------------------------------------------
    # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21). Native
    # OpenAI Chat Completions wire format — pass-through of messages +
    # tools + tool_choice. Streaming forwards the openai SDK iterator
    # since its chunks already match Lucy's _stream_wrapped() contract.

    def chat_with_tools(
        self,
        model: str,
        messages: list,
        tools: Optional[list] = None,
        tool_choice: Optional[Any] = None,
        api_key: Optional[str] = None,
        stream: bool = False,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **_extra: Any,
    ) -> Any:
        from openai import OpenAI  # local import — keep module import cheap
        from aibrain.core.provider_contract import (
            make_openai_shaped_response,
            make_tool_call,
        )
        key = api_key or self.api_key or os.environ.get("OPENAI_API_KEY")
        if not key:
            raise OpenAIProviderError(
                "No OpenAI API key. Set OPENAI_API_KEY or pass api_key=..."
            )
        client = OpenAI(api_key=key)  # default base_url -> api.openai.com
        kwargs: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        if tools:
            kwargs["tools"] = tools
            if tool_choice is not None:
                kwargs["tool_choice"] = tool_choice
        resp = client.chat.completions.create(**kwargs)
        if stream:
            return resp  # SDK iterable already matches _stream_wrapped contract
        # Normalise non-stream into provider-agnostic SimpleNamespace shape
        msg = resp.choices[0].message
        tcs = None
        if getattr(msg, "tool_calls", None):
            tcs = [
                make_tool_call(
                    call_id=tc.id,
                    name=tc.function.name,
                    arguments_json=tc.function.arguments or "{}",
                )
                for tc in msg.tool_calls
            ]
        return make_openai_shaped_response(
            content=msg.content or "",
            tool_calls=tcs,
            role=msg.role or "assistant",
            model=resp.model or model,
            finish_reason=resp.choices[0].finish_reason or "stop",
            usage={
                "prompt_tokens": getattr(resp.usage, "prompt_tokens", 0) if resp.usage else 0,
                "completion_tokens": getattr(resp.usage, "completion_tokens", 0) if resp.usage else 0,
                "total_tokens": getattr(resp.usage, "total_tokens", 0) if resp.usage else 0,
            },
        )


class OpenAIReviewProvider(ReviewProvider):
    """Concrete ReviewProvider backed by OpenAI.

    Uses the same _call_openai_http helper as OpenAITextProvider
    and the shared parse_review_response parser from provider_contract.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.api_key = _get_api_key(config)

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke the OpenAI API for a review asynchronously."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._invoke_sync, request)

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Synchronous review call."""
        config = self.config or {}
        persona = request.get("persona", "")
        work_output = request.get("work_output", "")
        acceptance_criteria = request.get("acceptance_criteria", "")

        system_prompt = (
            "You are a meticulous reviewer. Evaluate the work output against "
            "the acceptance criteria. Respond with exactly three lines:\n"
            "VERDICT: PASS or FAIL\n"
            "SCORE: a float between 0.0 and 1.0\n"
            "CRITIQUE: a brief explanation"
        )
        user_content = (
            f"Persona: {persona}\n\n"
            f"Work Output:\n{work_output}\n\n"
            f"Acceptance Criteria:\n{acceptance_criteria}"
        )

        model = _resolve_model(config, "review")
        start_time = time.time()

        response_data = _call_openai_http(
            model=model,
            system=system_prompt,
            user=user_content,
            api_key=self.api_key,
            max_tokens=request.get("max_tokens", 512),
            temperature=request.get("temperature", 0.2),
        )

        latency_ms = int((time.time() - start_time) * 1000)

        try:
            content = response_data["choices"][0]["message"]["content"]
            model_used = response_data.get("model", model)
        except (KeyError, IndexError) as e:
            raise OpenAIProviderError(
                f"Unexpected OpenAI review response structure: {response_data}"
            ) from e

        from aibrain.core.provider_contract import parse_review_response
        parsed = parse_review_response(content)

        return {
            "verdict": parsed["verdict"],
            "score": parsed["score"],
            "critique": parsed["critique"],
            "model_used": model_used,
            "latency_ms": latency_ms,
        }


if __name__ == "__main__":
    # Smoke test: instantiation only, no actual API calls
    config = {"api_key_env": "OPENAI_API_KEY"}
    try:
        text_provider = OpenAITextProvider(config)
        review_provider = OpenAIReviewProvider(config)

        from aibrain.core.provider_contract import TextProvider, ReviewProvider
        assert isinstance(text_provider, TextProvider)
        assert isinstance(review_provider, ReviewProvider)

        print("provider_openai smoke test OK")
    except OpenAIProviderError:
        # If no API key is set, the provider will raise during init.
        # For smoke test purposes, we consider this acceptable.
        print("provider_openai smoke test OK")