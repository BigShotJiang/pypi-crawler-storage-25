"""
dispatch_primitives.py — Decomposed dispatch primitives for Lucy.

Bruce Lee'd from the dispatch_deepseek_task monolith (agent_dispatch.py).
Three standalone primitives Lucy can use independently:

  1. deepseek_chat(system_prompt, user_prompt) → raw response text
  2. apply_dispatch_blocks(text, target_dir) → applies FILE/EDIT blocks to disk
  3. verify_file_state(verify_lines) → run grep/import/exit-0 checks

Each primitive is self-contained and callable without a company task lifecycle.
"""

import os
import re
import json
import subprocess
import logging

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Primitive 1: deepseek_chat — raw DeepSeek API call, no task lifecycle
# ---------------------------------------------------------------------------

def deepseek_chat(
    system_prompt: str = "",
    user_prompt: str = "",
    model: str = "deepseek-v4-pro",
    thinking: bool = False,
    reasoning_effort: str = "high",
    timeout_s: int = 180,
) -> dict:
    """Call DeepSeek chat-completion API and return raw response.

    No task checkout, no persona prepend, no apply step, no complete_task.
    Pure API call — Lucy controls what happens next.

    Args:
        system_prompt: System message (persona/instructions)
        user_prompt:   User message (the actual task)
        model:         DeepSeek model name
        thinking:      Enable chain-of-thought reasoning
        reasoning_effort: "high" or "max"
        timeout_s:     HTTP timeout in seconds

    Returns:
        dict with keys:
            content (str):     The model's response text
            tokens_in (int):   Input tokens consumed
            tokens_out (int):  Output tokens produced
            cost_usd (float):  Estimated cost
            error (str|None):  Error message if call failed

    Raises nothing — errors are returned in the dict.
    """
    api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not api_key:
        return {
            "content": "",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost_usd": 0.0,
            "error": "DEEPSEEK_API_KEY not set",
        }

    import urllib.request
    import urllib.error

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    }
    if thinking:
        payload["thinking"] = {"type": "enabled"}
        payload["reasoning_effort"] = reasoning_effort
    else:
        payload["thinking"] = {"type": "disabled"}
        payload["temperature"] = 0.0

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "https://api.deepseek.com/v1/chat/completions",
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as e:
        return {
            "content": "",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost_usd": 0.0,
            "error": f"DeepSeek HTTP {e.code}: {e.read()[:500].decode('utf-8', errors='replace')}",
        }
    except Exception as e:
        return {
            "content": "",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost_usd": 0.0,
            "error": f"DeepSeek request failed: {e}",
        }

    try:
        body = json.loads(raw.decode("utf-8"))
    except Exception as e:
        return {
            "content": "",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost_usd": 0.0,
            "error": f"DeepSeek response not valid JSON: {e}",
        }

    try:
        msg = body["choices"][0]["message"]
        content = msg.get("content", "") or ""
    except (KeyError, IndexError, TypeError) as e:
        return {
            "content": "",
            "tokens_in": 0,
            "tokens_out": 0,
            "cost_usd": 0.0,
            "error": f"DeepSeek response missing choices[0].message: {e}",
        }

    usage = body.get("usage", {}) or {}
    tokens_in = int(usage.get("prompt_tokens", 0) or 0)
    tokens_out = int(usage.get("completion_tokens", 0) or 0)

    # Cost estimate: deepseek-v4-pro rates per 1M tokens
    cost_usd = (tokens_in * 0.14 + tokens_out * 0.28) / 1_000_000

    return {
        "content": content,
        "tokens_in": max(0, tokens_in),
        "tokens_out": max(0, tokens_out),
        "cost_usd": round(cost_usd, 6),
        "error": None,
    }


# ---------------------------------------------------------------------------
# Primitive 2: apply_dispatch_blocks — parse and apply FILE/EDIT blocks
# ---------------------------------------------------------------------------

# Paths that must never be modified by dispatch output (mirrors dispatch_applier.py)
_DENY_PATH_SUFFIXES = (
    "aibrain/core/companies.py",
    "aibrain/core/task_verification.py",
    "aibrain/core/dispatch_applier.py",
    "aibrain/core/dispatch_primitives.py",
    "aibrain/core/the_hands.py",
    "aibrain/core/agent_dispatch.py",
    "aibrain/core/enforcement.py",
    "aibrain/core/secrets_filter.py",
    "aibrain/lucy_agent.py",
    "aibrain/core/lucy_loop.py",
    "aibrain/core/hands_bridge.py",
    "backend/security.py",
    "backend/auth_routes.py",
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    ".decker_env",
    ".aibrain.env",
    ".env",
    ".env.local",
    ".env.production",
    "aibrain/mcp/server.py",
    "aibrain/setup_wizard.py",
    "install.py",
    "Dockerfile",
)

_DENY_PATH_PATTERNS = [
    re.compile(r"^\.github/workflows/.+\.ya?ml$"),
    re.compile(r"^\.git/"),
    re.compile(r"^scripts/install\.(ps1|sh|bash)$"),
    re.compile(r".+/_internal/"),
    re.compile(r".+\.pyd$|.+\.so$|.+\.dll$"),
    re.compile(r"^decker_system/04_tools/git_hooks/"),
    re.compile(r"^aibrain/skills/"),
    re.compile(r"^aibrain/integrations/"),
    re.compile(r"^aibrain/mcp/adapters/"),
    re.compile(r"^deploy/"),
    re.compile(r"^seed_memories\.json$"),
    re.compile(r"^scripts/pre_commit_hook\.py$"),
]


def _resolve_repo_root(start_dir: str = None):
    """Find the git repository root."""
    if start_dir is None:
        start_dir = os.getcwd()

    # Try candidate from this file's location
    candidate = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=candidate,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    # Try CWD
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=start_dir,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    # Try AIBRAIN_PROJECT_ROOT env
    env_root = os.environ.get("AIBRAIN_PROJECT_ROOT", "")
    if env_root:
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                cwd=env_root,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass

    _log.error("Cannot determine git repo root")
    return None


def _is_path_denied(relpath: str) -> tuple:
    """Check if a path is in the deny-list. Returns (is_denied, reason)."""
    if not relpath:
        return True, "empty path"
    norm = relpath.replace("\\", "/")
    if norm.startswith("./"):
        norm = norm[2:]
    if norm.startswith("/") or "../" in norm or norm.startswith(".."):
        return True, f"out-of-tree path {relpath!r}"

    # Canonicalise for case-insensitive matching
    match_path = norm.lower()
    match_path = match_path.rstrip(". \t")
    while "//" in match_path:
        match_path = match_path.replace("//", "/")
    while "/./" in match_path:
        match_path = match_path.replace("/./", "/")
    match_path = "/".join(seg.rstrip(". \t") for seg in match_path.split("/"))

    for suffix in _DENY_PATH_SUFFIXES:
        if match_path.endswith(suffix.lower()) or match_path == suffix.lower():
            return True, f"deny-list suffix: {suffix}"
    for pat in _DENY_PATH_PATTERNS:
        if pat.match(match_path):
            return True, f"deny-list pattern: {pat.pattern}"
    return False, ""


def extract_blocks(text: str) -> list:
    """Extract FILE and diff blocks from text. Reuses dispatch_applier logic."""
    try:
        from aibrain.core.dispatch_applier import extract_blocks as _extract
        return _extract(text)
    except ImportError:
        pass

    # Fallback: inline simplified extractor
    blocks = []
    file_re = re.compile(r'^FILE:\s*(.+?)\s*$', re.MULTILINE)
    fence_re = re.compile(r'^```(\w*)\s*$', re.MULTILINE)

    # Find FILE: blocks
    for m in file_re.finditer(text):
        filepath = m.group(1).strip()
        start = m.end()
        # Find next ``` fence
        fence_m = fence_re.search(text, start)
        if not fence_m:
            continue
        lang = fence_m.group(1).lower()
        content_start = fence_m.end()
        # Find closing ```
        close_m = fence_re.search(text, content_start)
        if not close_m:
            continue
        content = text[content_start:close_m.start()]

        if lang in ("diff", "patch"):
            blocks.append({"type": "diff", "filepath": filepath, "content": content})
        else:
            blocks.append({"type": "file", "filepath": filepath, "content": content})

    return blocks


def apply_dispatch_blocks(text: str, target_dir: str = None) -> dict:
    """Parse FILE/EDIT/diff blocks from text and apply them to disk.

    Args:
        text:       Raw text containing FILE: blocks, unified diffs, or both
        target_dir: Directory to apply changes in (default: git repo root)

    Returns:
        dict with:
            applied (bool):           Whether any changes were applied
            applied_files (list):     Files modified
            errors (list|None):       Error messages if any
            blocks_found (int):       Number of blocks extracted
            deny_rejected (list):     Blocks rejected by deny-list
    """
    repo_root = _resolve_repo_root(target_dir)
    if repo_root is None:
        return {
            "applied": False,
            "applied_files": [],
            "errors": ["No git repo found — cannot apply patches safely"],
            "blocks_found": 0,
            "deny_rejected": [],
        }

    blocks = extract_blocks(text)
    if not blocks:
        return {
            "applied": True,  # nothing to apply = success
            "applied_files": [],
            "errors": None,
            "blocks_found": 0,
            "deny_rejected": [],
        }

    applied_files = []
    errors = []
    deny_rejected = []
    applied_entries = []  # for atomic revert on failure

    try:
        for blk in blocks:
            filepath = blk.get("filepath", "")

            # Deny-list check
            denied, reason = _is_path_denied(filepath)
            if denied:
                deny_rejected.append({"filepath": filepath, "reason": reason})
                continue

            full_path = os.path.join(repo_root, filepath)

            if blk["type"] == "file":
                # FILE block — write content directly
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                existed = os.path.exists(full_path)
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(blk["content"])
                applied_files.append(filepath)
                applied_entries.append((filepath, existed, full_path))

            elif blk["type"] == "diff":
                # Diff block — try git apply first
                existed = os.path.exists(full_path)
                result = subprocess.run(
                    ["git", "apply", "--binary"],
                    cwd=repo_root,
                    input=blk["content"],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    applied_files.append(filepath)
                    applied_entries.append((filepath, existed, full_path))
                else:
                    # Try with --3way fallback
                    result = subprocess.run(
                        ["git", "apply", "--binary", "--3way"],
                        cwd=repo_root,
                        input=blk["content"],
                        capture_output=True,
                        text=True,
                    )
                    if result.returncode == 0:
                        applied_files.append(filepath)
                        applied_entries.append((filepath, existed, full_path))
                    else:
                        errors.append(
                            f"git apply failed for {filepath}: {result.stderr.strip()[:200]}"
                        )

        if errors:
            # Revert applied entries on failure
            for fp, existed, full_p in reversed(applied_entries):
                if not existed:
                    try:
                        os.unlink(full_p)
                    except Exception:
                        pass
                else:
                    try:
                        subprocess.run(
                            ["git", "checkout", "HEAD", "--", fp],
                            cwd=repo_root,
                            capture_output=True,
                        )
                    except Exception:
                        pass
            return {
                "applied": False,
                "applied_files": [],
                "errors": errors,
                "blocks_found": len(blocks),
                "deny_rejected": deny_rejected,
            }

        return {
            "applied": True,
            "applied_files": applied_files,
            "errors": None,
            "blocks_found": len(blocks),
            "deny_rejected": deny_rejected,
        }

    except Exception as e:
        # Revert on any exception
        for fp, existed, full_p in reversed(applied_entries):
            if not existed:
                try:
                    os.unlink(full_p)
                except Exception:
                    pass
            else:
                try:
                    subprocess.run(
                        ["git", "checkout", "HEAD", "--", fp],
                        cwd=repo_root,
                        capture_output=True,
                    )
                except Exception:
                    pass
        return {
            "applied": False,
            "applied_files": [],
            "errors": [str(e)],
            "blocks_found": len(blocks),
            "deny_rejected": deny_rejected,
        }


# ---------------------------------------------------------------------------
# Primitive 3: verify_file_state — run verification checks
# ---------------------------------------------------------------------------

def verify_file_state(verify_lines: list[str], cwd: str = None) -> dict:
    """Run a list of verification commands and return pass/fail per line.

    Each verify_line can be:
      - A shell command:      grep "pattern" file.py
      - A python one-liner:   python -c "import aibrain; assert ..."
      - A file-exists check:  test -f path/to/file
      - An exit-code signal:  exit 0  (auto-passes)
      - A comment:            # explanation (auto-passes)

    Args:
        verify_lines: List of verification command strings
        cwd:          Working directory for commands (default: repo root)

    Returns:
        dict with:
            verified (bool):      True if ALL checks passed
            checks (list):        List of {line, passed, output, error} per check
            passed_count (int):   Number of checks passed
            failed_count (int):   Number of checks failed
            total_count (int):    Total checks
    """
    repo_root = _resolve_repo_root(cwd)
    if repo_root is None:
        repo_root = cwd or os.getcwd()

    if not verify_lines:
        return {
            "verified": True,
            "checks": [],
            "passed_count": 0,
            "failed_count": 0,
            "total_count": 0,
        }

    checks = []
    passed = 0
    failed = 0

    for line in verify_lines:
        line = line.strip()
        if not line:
            continue

        # Comments and exit 0 are auto-pass
        if line.startswith("#") or line == "exit 0" or line.startswith("exit 0"):
            checks.append({
                "line": line,
                "passed": True,
                "output": "(auto-pass)",
                "error": None,
            })
            passed += 1
            continue

        # Parse command
        try:
            if line.startswith("python -c "):
                # Python one-liner
                code = line[len("python -c "):].strip().strip('"').strip("'")
                result = subprocess.run(
                    ["python", "-c", code],
                    cwd=repo_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            elif line.startswith("test -f ") or line.startswith("test -d "):
                # File/dir existence check
                parts = line.split()
                path = parts[-1] if len(parts) >= 3 else ""
                full = os.path.join(repo_root, path) if not os.path.isabs(path) else path
                exists = os.path.isfile(full) if "-f" in line else os.path.isdir(full)
                result = subprocess.CompletedProcess(
                    args=line,
                    returncode=0 if exists else 1,
                    stdout="exists" if exists else "not found",
                    stderr="",
                )
            elif line.startswith("grep ") or line.startswith("findstr "):
                # Grep command
                result = subprocess.run(
                    line,
                    cwd=repo_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                    shell=True,
                )
            else:
                # Generic shell command
                result = subprocess.run(
                    line,
                    cwd=repo_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                    shell=True,
                )

            p = result.returncode == 0
            checks.append({
                "line": line,
                "passed": p,
                "output": (result.stdout or result.stderr)[:500].strip(),
                "error": result.stderr[:500].strip() if not p and result.stderr else None,
            })
            if p:
                passed += 1
            else:
                failed += 1

        except subprocess.TimeoutExpired:
            checks.append({
                "line": line,
                "passed": False,
                "output": "",
                "error": "timeout after 30s",
            })
            failed += 1
        except Exception as e:
            checks.append({
                "line": line,
                "passed": False,
                "output": "",
                "error": str(e)[:500],
            })
            failed += 1

    return {
        "verified": failed == 0,
        "checks": checks,
        "passed_count": passed,
        "failed_count": failed,
        "total_count": passed + failed,
    }
