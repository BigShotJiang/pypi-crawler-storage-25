"""aibrain.core.hands_bridge — BridgeLayer (four-verb bridge between brain and Hands).

Implements ADR-002 of the_hands_v1_spec.md. Thin wrapper — does not re-implement Hands
or ArtifactStore. The verbs are:

- command_hands(action, params)  -> dict   route to Hands.observe/plan/act/verify
- persist_tool(tool_def)         -> str    save tool source + metadata to ArtifactStore
- recall_tool(query)             -> list   query ArtifactStore for previously saved tools
- context()                      -> dict   in-memory state snapshot for brain consumption

Cross-product ready: namespace is set at __init__, every persist/recall inherits it unless
explicitly overridden in the call.
"""

from __future__ import annotations
import asyncio
import time
from collections import deque
from typing import Any, Deque, Dict, List, Optional, Tuple

from aibrain.core.the_hands import Hands, Observation
from aibrain.core.artifact_store import (
    ArtifactStore,
    ArtifactMetadata,
    ArtifactNotFoundError,
    SourceNotSavedError,
)


def _run_maybe_coro(result: Any) -> Any:
    """If result is a coroutine, run it to completion and return the real value.

    Handles three asyncio-loop cases:
    - No running loop: asyncio.run()
    - Loop running in same thread: create a new event loop, run the coro, close loop.
    - Different thread (shouldn't happen here): same as above but could raise if
      non‑thread‑safe.  BridgeLayer is meant to be used in the main thread.
    """
    if asyncio.iscoroutine(result):
        # Determine loop state UP FRONT. The previous implementation called
        # asyncio.run() then, on ANY RuntimeError, retried the SAME coroutine
        # with run_until_complete — which is impossible (a coroutine can only
        # be awaited once) and also masked the real error raised inside the
        # coroutine as a misleading "cannot reuse already awaited coroutine".
        # Here the coroutine is awaited EXACTLY ONCE, on exactly one path, and
        # any real exception propagates with its true message.
        try:
            asyncio.get_running_loop()
            _loop_running = True
        except RuntimeError:
            _loop_running = False
        if not _loop_running:
            return asyncio.run(result)
        # A loop is already running in this thread: run the coroutine to
        # completion in a dedicated thread with its own fresh loop. Awaited
        # once; the real exception (if any) is re-raised, never swallowed.
        import threading as _th
        _box: Dict[str, Any] = {}

        def _runner(_coro=result) -> None:
            _l = asyncio.new_event_loop()
            try:
                _box["value"] = _l.run_until_complete(_coro)
            except BaseException as _exc:  # noqa: BLE001 - propagate true error
                _box["error"] = _exc
            finally:
                _l.close()

        _t = _th.Thread(target=_runner)
        _t.start()
        _t.join()
        if "error" in _box:
            raise _box["error"]
        return _box["value"]
    return result


class BridgeLayer:
    """Four-verb bridge between brain and Hands.

    Stateless apart from a small in-memory recent_actions deque used by context().
    """

    DEFAULT_RECENT_LIMIT = 20

    def __init__(
        self,
        task_id: str,
        namespace: str = "aibrain",
        hands: Optional[Hands] = None,
        artifact_store: Optional[ArtifactStore] = None,
        recent_limit: int = DEFAULT_RECENT_LIMIT,
        sandbox: Optional[bool] = None,
    ):
        self.task_id = task_id
        self.namespace = namespace
        self.hands = hands or Hands(task_id=task_id, sandbox=sandbox)
        self.artifact_store = artifact_store or ArtifactStore()
        self._recent: Deque[Tuple[float, str, Dict[str, Any]]] = deque(maxlen=recent_limit)

    # --- Verb 1: command_hands -------------------------------------------------

    # Act sub-verbs that route directly to hands.act() — plan() returns these.
    _ACT_SUBVERBS = frozenset({
        "navigate", "click", "type", "extract", "screenshot", "wait",
        "bash", "execute", "shell", "python",
        "write_file", "read_file", "mcp",
    })

    def command_hands(self, action: Dict[str, Any], params: Optional[Dict[str, Any]] = None) -> Any:
        """Route an action to the appropriate Hands method based on action['verb'].

        Supported outer verbs: observe, plan, act, verify.
        Also accepts act sub-verbs directly (navigate, bash, python, write_file, etc.) —
        these are what plan() returns, so LucyLoop can pass steps straight through.
        Returns whatever the Hands method returns. Raises ValueError on unknown verb.
        """
        params = params or {}
        verb = action.get('verb')
        if not verb:
            raise ValueError("action must include a 'verb' key")

        if verb == 'observe':
            url = action.get('url') or params.get('url')
            result = self.hands.observe(url)
        elif verb == 'plan':
            goal = action.get('goal') or params.get('goal') or ''
            context = action.get('context') or params.get('context')
            result = self.hands.plan(goal, context=context)
        elif verb == 'act' or verb in self._ACT_SUBVERBS:
            # Accept both {"verb": "act", ...} and direct sub-verb dicts from plan()
            result = self.hands.act(action)
        elif verb == 'verify':
            expected = action.get('expected') or params.get('expected')
            actual = action.get('actual') or params.get('actual')
            result = self.hands.verify(expected, actual)
        else:
            raise ValueError(f"unknown verb {verb!r}; supported: observe|plan|act|verify or act sub-verbs")

        # Resolve any async result before storing/returning (keep public API sync).
        result = _run_maybe_coro(result)

        self._recent.append((time.time(), verb, _summarize(action)))
        return result

    # --- Verb 2: persist_tool --------------------------------------------------

    def persist_tool(self, tool_def: Dict[str, Any]) -> str:
        """Save a tool to ArtifactStore. tool_def must include source_code (bytes) and artifact_id.

        Optional fields: namespace (defaults to self.namespace), type (defaults to 'tool'),
        extension (defaults to 'py'), and any ArtifactMetadata field.

        Returns the artifact_id.
        """
        artifact_id = tool_def.get('artifact_id')
        if not artifact_id:
            raise ValueError("tool_def must include 'artifact_id'")
        source_code = tool_def.get('source_code')
        if not isinstance(source_code, (bytes, bytearray)):
            raise ValueError("tool_def['source_code'] must be bytes")
        namespace = tool_def.get('namespace', self.namespace)
        extension = tool_def.get('extension', 'py')
        type_ = tool_def.get('type', 'tool')

        source_path = self.artifact_store.save_source(
            artifact_id=artifact_id,
            namespace=namespace,
            code=bytes(source_code),
            extension=extension,
        )
        meta = ArtifactMetadata(
            artifact_id=artifact_id,
            type=type_,
            namespace=namespace,
            source_path=source_path,
            prompt_history=tool_def.get('prompt_history', []),
            parent_artifact_id=tool_def.get('parent_artifact_id'),
            origin_round=tool_def.get('origin_round'),
            battle_id=tool_def.get('battle_id'),
            success_history=tool_def.get('success_history', []),
            curation_state=tool_def.get('curation_state', 'quarantined'),
            license=tool_def.get('license'),
            attribution=tool_def.get('attribution'),
            version=tool_def.get('version', '1.0.0'),
            extras=tool_def.get('extras', {}),
        )
        self.artifact_store.put_artifact(meta)
        return artifact_id

    # --- Verb 3: recall_tool ---------------------------------------------------

    def recall_tool(self, query: Dict[str, Any]) -> List[ArtifactMetadata]:
        """Find previously saved tools.

        query may include: namespace (defaults to self.namespace), type (defaults to 'tool'),
        curation_state, limit.
        """
        namespace = query.get('namespace', self.namespace)
        type_ = query.get('type', 'tool')
        curation_state = query.get('curation_state')
        limit = query.get('limit', 50)
        return self.artifact_store.find_artifacts(
            namespace=namespace,
            type=type_,
            curation_state=curation_state,
            limit=limit,
        )

    # --- Verb 4: context -------------------------------------------------------

    def context(self) -> Dict[str, Any]:
        """Return an in-memory snapshot for brain consumption."""
        try:
            tools = self.artifact_store.find_artifacts(namespace=self.namespace, type='tool', limit=1000)
            tools_count = len(tools)
        except Exception:
            tools_count = -1  # sentinel: store unavailable
        return {
            'task_id': self.task_id,
            'namespace': self.namespace,
            'recent_actions': [
                {'ts': ts, 'verb': verb, 'summary': summary}
                for (ts, verb, summary) in list(self._recent)
            ],
            'available_tools_count': tools_count,
        }


def _summarize(action: Dict[str, Any]) -> Dict[str, Any]:
    """Trim noisy fields and bound size for recent_actions logging."""
    keep_keys = ('verb', 'url', 'selector', 'goal', 'expected', 'actual')
    out: Dict[str, Any] = {}
    for k in keep_keys:
        if k in action:
            v = action[k]
            if isinstance(v, str) and len(v) > 200:
                v = v[:200] + '...'
            out[k] = v
    return out
