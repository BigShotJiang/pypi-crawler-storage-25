"""
memory_lifecycle.py — Staleness computation, state machine, and annotation.

Computes temporal freshness of memories based on claim_type, deadlines,
and verification timestamps. Annotates recall results with staleness
scores and freshness labels.

Part of the Memory Lifecycle v1.6 feature.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Optional

from aibrain.core.claim_classifier import (
    adjusted_staleness_threshold,
)

log = logging.getLogger("aibrain.memory_lifecycle")


def parse_date(date_str: Optional[str]) -> Optional[datetime]:
    """Parse a date string into a datetime object. Returns None on failure."""
    if not date_str:
        return None
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ):
        try:
            dt = datetime.strptime(date_str, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    return None


def compute_staleness(memory: dict, now: Optional[datetime] = None) -> float:
    """Return a 0.0-1.0 staleness score.

    0.0 = fresh (just verified or created)
    1.0 = maximally stale (well past threshold)
    """
    if now is None:
        now = datetime.now(timezone.utc)

    claim_type = memory.get("claim_type", "assertion")
    threshold_days = adjusted_staleness_threshold(memory)

    # For plans: staleness is relative to plan_deadline, not created date
    if claim_type == "plan" and memory.get("plan_deadline"):
        ref_date = parse_date(memory["plan_deadline"])
    else:
        # Use verified_at if available, otherwise updated, otherwise created
        ref_date = (
            parse_date(memory.get("verified_at"))
            or parse_date(memory.get("updated"))
            or parse_date(memory.get("created"))
        )

    if ref_date is None:
        return 1.0  # No date info = maximally stale

    # Ensure timezone-aware comparison
    if ref_date.tzinfo is None:
        ref_date = ref_date.replace(tzinfo=timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)

    elapsed_days = (now - ref_date).total_seconds() / 86400
    return min(1.0, max(0.0, elapsed_days / threshold_days))


def annotate_staleness(results: list[dict], now: Optional[datetime] = None) -> list[dict]:
    """Add staleness_score and freshness_label to each result.

    Labels:
      'fresh' — staleness < 0.3
      'aging' — staleness 0.3-0.7
      'stale' — staleness 0.7-0.9
      'expired' — staleness > 0.9
    """
    if now is None:
        now = datetime.now(timezone.utc)

    for r in results:
        score = compute_staleness(r, now)
        r["staleness_score"] = round(score, 3)
        if score < 0.3:
            r["freshness_label"] = "fresh"
        elif score < 0.7:
            r["freshness_label"] = "aging"
        elif score < 0.9:
            r["freshness_label"] = "stale"
        else:
            r["freshness_label"] = "expired"

        # Adjust effective confidence based on staleness
        base_confidence = r.get("confidence") or 0.5
        r["effective_confidence"] = round(base_confidence * (1.0 - score * 0.5), 3)
        # A stale plan's effective confidence: 0.3 * (1 - 0.9*0.5) = 0.165
        # A fresh verified fact: 0.85 * (1 - 0.0*0.5) = 0.85

    return results


def lifecycle_summary(results: list[dict]) -> str:
    """Generate a brief lifecycle summary for session start.

    Returns a string like:
    "Memory lifecycle: 14 verified, 3 plans (1 past deadline), 2 stale assertions, 1 contradiction detected"
    """
    counts = {
        "verified": 0,
        "plans": 0,
        "plans_past_deadline": 0,
        "stale": 0,
        "contradicted": 0,
    }

    for r in results:
        ct = r.get("claim_type", "assertion")
        if ct == "verified_fact":
            counts["verified"] += 1
        elif ct == "plan":
            counts["plans"] += 1
            if r.get("freshness_label") in ("stale", "expired"):
                counts["plans_past_deadline"] += 1
        if r.get("freshness_label") in ("stale", "expired") and ct != "plan":
            counts["stale"] += 1
        if r.get("contradiction_flag"):
            counts["contradicted"] += 1

    parts = []
    if counts["verified"]:
        parts.append(f"{counts['verified']} verified")
    if counts["plans"]:
        plan_part = f"{counts['plans']} plans"
        if counts["plans_past_deadline"]:
            plan_part += f" ({counts['plans_past_deadline']} past deadline)"
        parts.append(plan_part)
    if counts["stale"]:
        parts.append(f"{counts['stale']} stale assertions")
    if counts["contradicted"]:
        parts.append(f"{counts['contradicted']} contradiction{'s' if counts['contradicted'] != 1 else ''} detected")

    if not parts:
        return "Memory lifecycle: all memories current"
    return "Memory lifecycle: " + ", ".join(parts)
