"""provider_wizard.py -- first-run provider selection wizard for AIBrain.

Walks the user through picking which AI providers to use for each task class
(text_cheap, text_judgment, text_review, image, video, speech). Writes
~/.aibrain/config.yaml on completion. Uses provider_recommendations.yaml
when the user picks "No preference, recommend me."

Public API:
- run_wizard(config_path=None, recommendations_path=None, force_recommend=False) -> dict
- show_recommendations(use_case, budget, has_keys, recommendations_path=None) -> dict
- test_provider(provider_config) -> dict  (stub for credential ping)
"""

from __future__ import annotations
import datetime
import logging
import sys
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("aibrain.provider_wizard")

KNOWN_PROVIDERS = [
    "anthropic", "openai", "deepseek", "google", "xai",
    "ollama_local", "manus", "other",
]
PROVIDER_HELP = {
    "anthropic": "Claude API (Opus, Sonnet, Haiku) - high quality, cloud",
    "openai":    "GPT-5 + GPT-4o-mini - high quality, cloud",
    "deepseek":  "DeepSeek API (v4-pro, reasoner) - cheap workhorse, cloud",
    "google":    "Gemini 2.5 Pro / Flash - quality + speed, cloud",
    "xai":       "Grok 4 - quality, cloud",
    "ollama_local": "Local models via Ollama (offline, no cloud) - free + private",
    "manus":     "Manus.im autonomous agent - sandboxed VM with browser",
    "other":     "Custom OpenAI-compatible endpoint",
}
TASK_CLASS_HELP = {
    "text_cheap":    "bulk dispatch, decomposition, planner steps",
    "text_judgment": "code review, judgment calls, mid-tier reasoning",
    "text_review":   "Liaison gate (highest-quality reviewer)",
    "image":         "image generation",
    "video":         "video generation",
    "speech":        "text-to-speech",
}
USE_CASES = ["build_software", "generate_content", "research_analysis", "multi_purpose"]
BUDGET_POSTURES = ["cost_sensitive", "quality_first", "privacy_first", "balanced"]


def _prompt(question: str, default: Optional[str] = None) -> str:
    """Ask user for input; return their answer (or default if empty)."""
    suffix = f" [{default}]" if default else ""
    raw = input(f"{question}{suffix}: ").strip()
    return raw or (default or "")


def _prompt_choice(question: str, choices: list[str], default_index: int = 0) -> str:
    """Numbered-list prompt. Returns the chosen string."""
    print(f"\n{question}")
    for i, c in enumerate(choices, start=1):
        help_text = PROVIDER_HELP.get(c) or TASK_CLASS_HELP.get(c) or ""
        marker = " (default)" if i == default_index + 1 else ""
        print(f"  {i}. {c}{marker}  {('-- ' + help_text) if help_text else ''}")
    while True:
        raw = input(f"Pick 1-{len(choices)}: ").strip()
        if not raw:
            return choices[default_index]
        try:
            n = int(raw)
            if 1 <= n <= len(choices):
                return choices[n - 1]
        except ValueError:
            pass
        print(f"  ! please enter a number 1-{len(choices)}")


def _ask_yes_no(question: str, default: bool = False) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    raw = input(f"{question}{suffix}: ").strip().lower()
    if not raw:
        return default
    return raw in ("y", "yes")


def show_recommendations(use_case: str, budget: str, has_keys: list[str], recommendations_path: Optional[Path] = None) -> dict:
    """Load recommendations YAML and return the cell for (use_case, budget).

    Returns a dict of {task_class: {provider, model, justification, runner_up}}.
    Applies fallback patterns if user lacks the recommended provider's keys.
    """
    import yaml
    if recommendations_path is None:
        recommendations_path = Path(__file__).parent / "provider_recommendations.yaml"
    if not recommendations_path.exists():
        logger.warning("Recommendations file not found at %s", recommendations_path)
        return {}
    data = yaml.safe_load(recommendations_path.read_text(encoding="utf-8")) or {}
    cell = data.get("recommendations", {}).get(use_case, {}).get(budget, {})
    fallbacks = data.get("fallbacks", [])
    # Apply fallback substitution if user lacks the recommended provider
    has_keys_set = set(has_keys)
    out = {}
    for task_class, entry in cell.items():
        provider = entry.get("provider", "")
        if provider in has_keys_set:
            out[task_class] = entry
        else:
            # Find fallback for missing provider
            sub = None
            for fb in fallbacks:
                if fb.get("if_missing") == provider:
                    for cand in fb.get("prefer", []):
                        if cand in has_keys_set:
                            sub = {"provider": cand, "model": "<recommended-for-" + cand + ">", "justification": f"fallback for {provider} (user lacks keys)", "runner_up": entry.get("runner_up", {})}
                            break
                    break
            if sub is None and entry.get("runner_up", {}).get("provider") in has_keys_set:
                sub = entry["runner_up"]
            out[task_class] = sub or entry  # keep original if no fallback works
    return out


def test_provider(provider_config: dict) -> dict:
    """STUB: ping the configured provider to verify credentials.
    Real implementation comes in Step 5 (/config providers test).
    """
    return {"ok": True, "note": "credential test not yet implemented (Step 5 follow-up)"}


def run_wizard(config_path: Optional[Path] = None, recommendations_path: Optional[Path] = None, force_recommend: bool = False) -> dict:
    """Walk user through provider selection. Writes config to disk, returns dict."""
    from aibrain.core.config_schema import validate_config, DEFAULT_CONFIG_PATH
    if config_path is None:
        config_path = DEFAULT_CONFIG_PATH

    print("=" * 60)
    print("AIBrain provider configuration wizard")
    print("=" * 60)
    print()
    print("This wizard picks which AI providers handle different kinds of work.")
    print("You can edit ~/.aibrain/config.yaml directly any time after.")
    print()

    # Step A: ask which API keys user has
    print("First — which providers do you have keys/credits for?")
    has_keys = []
    for p in KNOWN_PROVIDERS:
        if p == "other":
            continue
        help_t = PROVIDER_HELP.get(p, "")
        if _ask_yes_no(f"  Do you have {p}? -- {help_t}", default=False):
            has_keys.append(p)
    if not has_keys:
        print("\n[ERROR] You need at least one provider configured. Exiting.")
        return {}

    # Step B: main/default provider
    main_provider = _prompt_choice("\nPick your MAIN provider (universal fallback):", has_keys, default_index=0)

    # Step C: main model
    main_model = _prompt(f"What model_id for {main_provider}?", default="<set-me>")

    # Optional: use recommendations
    use_recommend = force_recommend or _ask_yes_no("\nUse our recommendations for per-task-class routing? (y/N)", default=False)
    recommended = {}
    if use_recommend:
        use_case = _prompt_choice("What's your primary use case?", USE_CASES, default_index=3)
        budget   = _prompt_choice("What's your budget posture?",   BUDGET_POSTURES, default_index=3)
        recommended = show_recommendations(use_case, budget, has_keys, recommendations_path)
        if recommended:
            print(f"\nRecommendations for {use_case} + {budget}:")
            for tc, entry in recommended.items():
                print(f"  {tc}: {entry.get('provider')} / {entry.get('model')} -- {entry.get('justification', '')}")

    # Build config
    config = {
        "version": 1,
        "last_updated": datetime.datetime.utcnow().isoformat() + "Z",
        "fallback_provider": {"name": main_provider, "model": main_model},
        "providers": {
            "text": {},
            "image":  {"default": {"name": main_provider, "model": main_model}},
            "video":  {"default": {"name": main_provider, "model": main_model}},
            "speech": {"default": {"name": main_provider, "model": main_model}},
        },
    }
    for tc in ("cheap", "judgment", "review"):
        rec_key = "text_" + tc
        if recommended and rec_key in recommended and recommended[rec_key].get("provider"):
            r = recommended[rec_key]
            config["providers"]["text"][tc] = {"name": r["provider"], "model": r.get("model", main_model)}
        else:
            config["providers"]["text"][tc] = {"name": main_provider, "model": main_model}

    # Apply media recommendations if present
    for media in ("image", "video", "speech"):
        if recommended and media in recommended and recommended[media].get("provider"):
            r = recommended[media]
            config["providers"][media]["default"] = {"name": r["provider"], "model": r.get("model", main_model)}

    # Validate
    ok, errors = validate_config(config)
    if not ok:
        print("\n[ERROR] Config validation failed:")
        for e in errors:
            print(f"  - {e}")
        return {}

    # Write
    import yaml
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    print(f"\n[DONE] Config written to {config_path}")
    return config


if __name__ == "__main__":
    # Allow direct invocation
    run_wizard()
