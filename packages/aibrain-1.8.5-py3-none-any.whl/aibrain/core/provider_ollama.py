import os
import json
import asyncio
import time
from typing import Dict, Any, Optional
import aiohttp
from aibrain.core.provider_contract import TextProvider, ReviewProvider

DEFAULT_MODEL_FOR_TASK_CLASS = {
    "cheap": "llama-3.3-70b",
    "judgment": "qwen2.5-72b",
    "review": "deepseek-coder-v3-33b"
}

SUPPORTED_TASK_CLASSES = ["cheap", "judgment", "review"]

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")


class OllamaProviderError(Exception):
    """Custom exception for Ollama provider errors."""
    pass


def _check_health() -> bool:
    """Check if Ollama is reachable and healthy.
    
    Returns:
        True if Ollama responds with 200, False on any error.
    """
    try:
        import requests
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        return response.status_code == 200
    except Exception:
        return False


def _resolve_model(config: dict, task_class: str) -> str:
    """Resolve which model to use for a given task class.
    
    Args:
        config: Provider configuration dict (may contain model overrides).
        task_class: The task class (cheap, judgment, review).
    
    Returns:
        The model name string.
    """
    # Check config for task-specific override
    model_key = f"model_{task_class}"
    if model_key in config:
        return config[model_key]
    
    # Check config for global model override
    if "model" in config:
        return config["model"]
    
    # Fall back to defaults
    return DEFAULT_MODEL_FOR_TASK_CLASS.get(task_class, "llama-3.3-70b")


def _call_ollama_http(model: str, system: Optional[str], user: str, max_tokens: int = 4096) -> dict:
    """Make synchronous HTTP call to Ollama API.
    
    Args:
        model: The model name to use.
        system: Optional system prompt.
        user: The user prompt.
        max_tokens: Maximum tokens to generate.
    
    Returns:
        Dict with response data from Ollama.
    
    Raises:
        OllamaProviderError: If the API call fails.
    """
    import requests
    
    payload = {
        "model": model,
        "prompt": user,
        "stream": False,
        "options": {
            "num_predict": max_tokens
        }
    }
    
    if system:
        payload["system"] = system
    
    try:
        response = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json=payload,
            timeout=120
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise OllamaProviderError(f"Ollama API call failed: {e}")
    except json.JSONDecodeError as e:
        raise OllamaProviderError(f"Failed to parse Ollama response: {e}")


class OllamaTextProvider(TextProvider):
    """Concrete TextProvider implementation for local Ollama models."""
    
    def __init__(self, config: dict):
        """Initialize the Ollama provider.
        
        Args:
            config: Provider configuration dict.
        """
        self.config = config
    
    async def invoke(self, request: dict) -> dict:
        """Invoke the Ollama model asynchronously.
        
        Args:
            request: Dict with keys: prompt, system_prompt (optional), 
                    task_class, max_tokens, temperature.
        
        Returns:
            Dict with keys: content, tokens_in, tokens_out, model_used, latency_ms.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._invoke_sync, request)
    
    def _invoke_sync(self, request: dict) -> dict:
        """Synchronous implementation of invoke.
        
        Args:
            request: Dict with keys: prompt, system_prompt (optional),
                    task_class, max_tokens, temperature.
        
        Returns:
            Dict with keys: content, tokens_in, tokens_out, model_used, latency_ms.
        
        Raises:
            OllamaProviderError: If Ollama is not healthy or API call fails.
        """
        # Health check
        if not _check_health():
            raise OllamaProviderError("Ollama is not reachable or healthy")
        
        # Extract request parameters using dict.get()
        prompt = request.get("prompt", "")
        system_prompt = request.get("system_prompt")
        task_class = request.get("task_class", "judgment")
        max_tokens = request.get("max_tokens", 4096)
        # temperature is accepted but not used by Ollama in this basic implementation
        
        # Resolve model
        model = _resolve_model(self.config, task_class)
        
        # Call Ollama
        start_time = time.time()
        ollama_response = _call_ollama_http(
            model=model,
            system=system_prompt,
            user=prompt,
            max_tokens=max_tokens
        )
        latency_ms = int((time.time() - start_time) * 1000)
        
        # Build response dict
        return {
            "content": ollama_response.get("response", ""),
            "tokens_in": ollama_response.get("prompt_eval_count", 0),
            "tokens_out": ollama_response.get("eval_count", 0),
            "model_used": ollama_response.get("model", model),
            "latency_ms": latency_ms
        }

    # ------------------------------------------------------------------
    # Chat-with-tools dispatch surface
    # ------------------------------------------------------------------
    # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21).
    # Ollama exposes an OpenAI-compatible Chat Completions endpoint at
    # http://<host>:11434/v1/chat/completions. Use the openai SDK with
    # that base_url so tools, streaming, and the messages-array protocol
    # all work without translation.

    def chat_with_tools(
        self,
        model: str,
        messages: list,
        tools: Optional[list] = None,
        tool_choice: Optional[Any] = None,
        api_key: Optional[str] = None,
        stream: bool = False,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **_extra: Any,
    ) -> Any:
        from openai import OpenAI
        from aibrain.core.provider_contract import (
            make_openai_shaped_response,
            make_tool_call,
        )
        base = os.environ.get("OLLAMA_URL", "http://localhost:11434").rstrip("/")
        if not base.endswith("/v1"):
            base = base + "/v1"
        # Ollama doesn't require auth — openai SDK still wants a non-empty key.
        key = api_key or "ollama-local"
        client = OpenAI(api_key=key, base_url=base)
        kwargs: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        if tools:
            kwargs["tools"] = tools
            if tool_choice is not None:
                kwargs["tool_choice"] = tool_choice
        resp = client.chat.completions.create(**kwargs)
        if stream:
            return resp
        msg = resp.choices[0].message
        tcs = None
        if getattr(msg, "tool_calls", None):
            tcs = [
                make_tool_call(
                    call_id=tc.id,
                    name=tc.function.name,
                    arguments_json=tc.function.arguments or "{}",
                )
                for tc in msg.tool_calls
            ]
        return make_openai_shaped_response(
            content=msg.content or "",
            tool_calls=tcs,
            role=msg.role or "assistant",
            model=resp.model or model,
            finish_reason=resp.choices[0].finish_reason or "stop",
            usage={
                "prompt_tokens": getattr(resp.usage, "prompt_tokens", 0) if resp.usage else 0,
                "completion_tokens": getattr(resp.usage, "completion_tokens", 0) if resp.usage else 0,
                "total_tokens": getattr(resp.usage, "total_tokens", 0) if resp.usage else 0,
            },
        )


class OllamaReviewProvider(ReviewProvider):
    """Concrete ReviewProvider backed by local Ollama models.

    Uses the same _call_ollama_http helper as OllamaTextProvider
    and the shared parse_review_response parser from provider_contract.
    """

    def __init__(self, config: dict):
        self.config = config

    async def invoke(self, request: dict) -> dict:
        """Invoke the Ollama model for a review asynchronously."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._invoke_sync, request)

    def _invoke_sync(self, request: dict) -> dict:
        """Synchronous review call."""
        config = self.config or {}

        # Health check
        if not _check_health():
            raise OllamaProviderError("Ollama is not reachable or healthy")

        persona = request.get("persona", "")
        work_output = request.get("work_output", "")
        acceptance_criteria = request.get("acceptance_criteria", "")

        system_prompt = (
            "You are a meticulous reviewer. Evaluate the work output against "
            "the acceptance criteria. Respond with exactly three lines:\n"
            "VERDICT: PASS or FAIL\n"
            "SCORE: a float between 0.0 and 1.0\n"
            "CRITIQUE: a brief explanation"
        )
        user_prompt = (
            f"Persona: {persona}\n\n"
            f"Work Output:\n{work_output}\n\n"
            f"Acceptance Criteria:\n{acceptance_criteria}"
        )

        model = _resolve_model(config, "review")
        max_tokens = request.get("max_tokens", 512)

        start_time = time.time()
        ollama_response = _call_ollama_http(
            model=model,
            system=system_prompt,
            user=user_prompt,
            max_tokens=max_tokens,
        )
        latency_ms = int((time.time() - start_time) * 1000)

        content = ollama_response.get("response", "")
        model_used = ollama_response.get("model", model)

        from aibrain.core.provider_contract import parse_review_response
        parsed = parse_review_response(content)

        return {
            "verdict": parsed["verdict"],
            "score": parsed["score"],
            "critique": parsed["critique"],
            "model_used": model_used,
            "latency_ms": latency_ms,
        }


if __name__ == "__main__":
    # Smoke test: instantiation only, no network call
    text_provider = OllamaTextProvider({})
    review_provider = OllamaReviewProvider({})

    from aibrain.core.provider_contract import TextProvider, ReviewProvider
    assert isinstance(text_provider, TextProvider)
    assert isinstance(review_provider, ReviewProvider)

    print("provider_ollama smoke test OK")