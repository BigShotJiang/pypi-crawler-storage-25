#!/usr/bin/env python3
"""
YAML workflow execution engine for AIBrain.
Implements the three-layer architecture defined in docs/workflow_format_spec.md.

Executes .workflow.yaml files — separate from workflow_runner.py which handles
the existing Python .py workflow scripts via the harness.

Usage:
    from aibrain.core.yaml_workflow_runner import run_workflow, dry_run

    result = run_workflow("docs/workflows/research_pipeline.workflow.yaml",
                          input_data={"question": "What is X?"})
    report = dry_run("docs/workflows/research_pipeline.workflow.yaml")
"""
import os
import re
import time
import logging
from typing import Any, Dict, List, Optional

import requests
import yaml

from aibrain.core.agent_dispatch import _ollama_http_call

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default capabilities configuration (budget profile) — hardcoded for V1
# Capabilities config resolution: capabilities config file > these defaults.
# ---------------------------------------------------------------------------
DEFAULT_CAPABILITIES: Dict[str, Dict[str, Any]] = {
    # LLM
    "reasoning_model":  {"provider": "ollama",   "model": "gemma3:27b"},
    "fast_model":       {"provider": "ollama",   "model": "qwen2.5:7b-instruct"},
    "vision_model":     {"provider": "none"},
    # Memory
    "memory_store":     {"provider": "aibrain",  "tool": "memory_store_mcp"},
    "memory_search":    {"provider": "aibrain",  "tool": "memory_search_mcp"},
    # Web
    "web_search":       {"provider": "aibrain"},
    "web_scrape":       {"provider": "none"},
    "browser_use":      {"provider": "aibrain"},
    "http_request":     {"provider": "aibrain"},
    # Files
    "file_read":        {"provider": "aibrain",  "tool": "file_read_mcp"},
    "file_write":       {"provider": "aibrain",  "tool": "file_write_mcp"},
    "cloud_storage":    {"provider": "none"},
    # Code / Data
    "code_executor":    {"provider": "aibrain",  "tool": "code_executor_mcp"},
    "embedding_model":  {"provider": "aibrain"},
    "database_query":   {"provider": "aibrain"},
    "vector_store":     {"provider": "aibrain"},
    "document_loader":  {"provider": "aibrain"},
    # Generate
    "image_generate":   {"provider": "none"},
    "video_generate":   {"provider": "none"},
    "video_analyze":    {"provider": "aibrain",  "model": "gemini-2.0-flash", "api_key_env": "GEMINI_API_KEY"},
    "audio_generate":   {"provider": "none"},
    "text_to_speech":   {"provider": "aibrain"},
    "speech_to_text":   {"provider": "none"},
    # Comms
    "email_send":       {"provider": "aibrain"},
    "email_read":       {"provider": "aibrain"},
    "notification_send":{"provider": "aibrain"},
    "social_post":      {"provider": "aibrain"},
    # Integration
    "mcp_tool":         {"provider": "none"},
    # Flow
    "human_in_loop":    {"provider": "none"},
    "workflow_call":    {"provider": "none"},
    "schedule_trigger": {"provider": "none"},
    "event_trigger":    {"provider": "none"},
}

QUALITY_CAPABILITIES: Dict[str, Dict[str, Any]] = {
    "reasoning_model": {"provider": "anthropic", "model": "claude-opus-4-7",            "api_key_env": "ANTHROPIC_API_KEY"},
    "fast_model":      {"provider": "anthropic", "model": "claude-haiku-4-5-20251001",  "api_key_env": "ANTHROPIC_API_KEY"},
    "memory_store":    {"provider": "aibrain", "tool": "memory_store_mcp"},
    "memory_search":   {"provider": "aibrain", "tool": "memory_search_mcp"},
    "web_search":      {"provider": "none"},
    "code_executor":   {"provider": "aibrain", "tool": "code_executor_mcp"},
    "file_read":       {"provider": "aibrain", "tool": "file_read_mcp"},
    "file_write":      {"provider": "aibrain", "tool": "file_write_mcp"},
}

# ---------------------------------------------------------------------------
# Provider routing — maps provider name to OpenAI-compatible base URL.
# Anthropic and Gemini are handled by separate call functions below.
# ---------------------------------------------------------------------------
OPENAI_COMPATIBLE_PROVIDERS: Dict[str, str] = {
    "openai":     "https://api.openai.com/v1",
    "groq":       "https://api.groq.com/openai/v1",
    "together":   "https://api.together.xyz/v1",
    "mistral":    "https://api.mistral.ai/v1",
    "deepseek":   "https://api.deepseek.com/v1",
    "openrouter": "https://openrouter.ai/api/v1",
    "grok":       "https://api.x.ai/v1",
}


def _openai_compatible_call(
    base_url: str, api_key: str, model: str,
    system_prompt: str, user_prompt: str,
    max_tokens: Optional[int] = None,
) -> str:
    """POST to any OpenAI-compatible /chat/completions endpoint."""
    payload: Dict[str, Any] = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ],
    }
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    resp = requests.post(
        f"{base_url}/chat/completions",
        json=payload,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        timeout=60,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"OpenAI-compatible API {resp.status_code}: {resp.text}")
    content = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")
    if not content:
        raise RuntimeError("OpenAI-compatible API returned empty content")
    return content


def _anthropic_call(
    api_key: str, model: str,
    system_prompt: str, user_prompt: str,
    max_tokens: Optional[int] = None,
) -> str:
    """POST to Anthropic Messages API."""
    payload = {
        "model": model,
        "max_tokens": max_tokens or 4096,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}],
    }
    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        json=payload,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        },
        timeout=120,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Anthropic API {resp.status_code}: {resp.text}")
    content_list = resp.json().get("content", [])
    if not content_list:
        raise RuntimeError("Anthropic API returned empty content")
    text = content_list[0].get("text", "")
    if not text:
        raise RuntimeError("Anthropic API returned empty text")
    return text


def _gemini_call(
    api_key: str, model: str,
    system_prompt: str, user_prompt: str,
    max_tokens: Optional[int] = None,
) -> str:
    """POST to Google Gemini generateContent endpoint."""
    combined = f"{system_prompt}\n\n{user_prompt}" if system_prompt else user_prompt
    payload = {
        "contents": [{"parts": [{"text": combined}]}],
        "generationConfig": {"maxOutputTokens": max_tokens or 8192},
    }
    resp = requests.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}",
        json=payload,
        headers={"Content-Type": "application/json"},
        timeout=120,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Gemini API {resp.status_code}: {resp.text}")
    candidates = resp.json().get("candidates", [])
    if not candidates:
        raise RuntimeError("Gemini API returned no candidates")
    text = candidates[0].get("content", {}).get("parts", [{}])[0].get("text", "")
    if not text:
        raise RuntimeError("Gemini API returned empty text")
    return text


# ---------------------------------------------------------------------------
# Template resolution
# Replaces {step_id.field} and {input.field} with values from context.
# ---------------------------------------------------------------------------
TEMPLATE_RE = re.compile(r'\{([a-zA-Z_][\w.]*)\}')


def _resolve_ref(ref: str, context: Dict[str, Any]) -> str:
    """Resolve a dotted reference like 'clarify.clarified_question' from context."""
    if '.' in ref:
        step_id, field = ref.split('.', 1)
        step_val = context.get(step_id, {})
        if isinstance(step_val, dict):
            return str(step_val.get(field, ''))
        return str(step_val)
    return str(context.get(ref, ''))


def resolve_templates(template: str, context: Dict[str, Any]) -> str:
    """Replace all {ref} placeholders in template with values from context."""
    return TEMPLATE_RE.sub(lambda m: _resolve_ref(m.group(1), context), template)


# ---------------------------------------------------------------------------
# Gate evaluation
# Operates on the RAW gate string + context.
# Pre-resolving the gate string would destroy the structural patterns the
# regexes rely on (e.g. "{step.out} is not empty" → "value is not empty").
# ---------------------------------------------------------------------------
def evaluate_gate(condition: str, context: Dict[str, Any]) -> bool:
    """Evaluate a gate condition against current step context. Returns True = proceed."""
    cond = condition.strip()

    # "{step.field} is not empty"
    m = re.match(r'^\{([\w.]+)\}\s+is\s+not\s+empty$', cond)
    if m:
        return bool(_resolve_ref(m.group(1), context).strip())

    # "{step.field} length > N"
    m = re.match(r'^\{([\w.]+)\}\s+length\s*>\s*(\d+)$', cond)
    if m:
        return len(_resolve_ref(m.group(1), context)) > int(m.group(2))

    # "{step.field}" contains "keyword"
    m = re.match(r'^\{([\w.]+)\}\s+contains\s+"([^"]*)"$', cond)
    if m:
        return m.group(2) in _resolve_ref(m.group(1), context)

    # boolean and/or (no nesting in V1)
    if ' and ' in cond:
        return all(evaluate_gate(c.strip(), context) for c in cond.split(' and '))
    if ' or ' in cond:
        return any(evaluate_gate(c.strip(), context) for c in cond.split(' or '))

    logger.warning("Unrecognised gate condition %r — passing by default", cond)
    return True


# ---------------------------------------------------------------------------
# Workflow I/O
# ---------------------------------------------------------------------------
def load_workflow(path_or_id: str) -> dict:
    """Parse and validate a .workflow.yaml file. Raises ValueError on bad format."""
    with open(path_or_id, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict) or 'format_version' not in data:
        raise ValueError(f"Invalid workflow at '{path_or_id}': missing 'format_version' field")
    return data


# ---------------------------------------------------------------------------
# Dry-run validation
# ---------------------------------------------------------------------------
def dry_run(workflow_path_or_id: str) -> dict:
    """Validate a workflow without executing it.

    Returns {"status": "ok"/"warn"/"fail", "issues": list[str]}.
    """
    try:
        wf = load_workflow(workflow_path_or_id)
    except Exception as e:
        return {"status": "fail", "issues": [str(e)]}

    issues: List[str] = []
    for step in wf.get('steps', []):
        cap_name = step.get('capability')
        if not cap_name:
            continue
        cap_conf = DEFAULT_CAPABILITIES.get(cap_name)
        if cap_conf is None:
            issues.append(f"Unknown capability '{cap_name}' in step '{step.get('id', '?')}'")
        elif cap_conf.get('provider') == 'none':
            optional = step.get('optional', False)
            tag = "warn" if optional else "fail"
            issues.append(
                f"[{tag}] capability '{cap_name}' unavailable (provider=none) "
                f"in step '{step.get('id', '?')}'"
                + (" — optional, will skip" if optional else " — REQUIRED, workflow will fail")
            )

    has_fail = any(i.startswith("[fail]") for i in issues)
    status = "fail" if has_fail else ("warn" if issues else "ok")
    return {"status": status, "issues": issues}


# ---------------------------------------------------------------------------
# Aibrain-native tool execution
# ---------------------------------------------------------------------------
def _execute_aibrain_tool(tool_name: str, step: dict, context: Dict[str, Any]) -> str:
    """Execute a known aibrain-native tool capability, returning a string result."""
    resolved_input = resolve_templates(step.get('input', ''), context)
    try:
        if tool_name == 'memory_store':
            from aibrain.core.memory_api import Brain
            results = Brain().add(resolved_input, user_id="workflow")
            if results:
                return str(results[0])
            logger.warning("memory_store returned empty result")
            return ""
        elif tool_name == 'memory_search':
            from aibrain.core.retrieval_router import retrieve
            channel = step.get('channel', 'auto')
            n = int(step.get('n', 10))
            results = retrieve(resolved_input, n=n, channel=channel)
            if results:
                return "\n".join(r.get('memory', r.get('content', '')) for r in results)
            return ""
        elif tool_name == 'file_read':
            from pathlib import Path
            return Path(resolved_input).read_text(encoding="utf-8")
        elif tool_name == 'file_write':
            from pathlib import Path
            if 'path' in step:
                dest = resolve_templates(step['path'], context)
            else:
                dest = f"output_{step.get('id', 'step')}.txt"
            Path(dest).write_text(resolved_input, encoding="utf-8")
            return dest
        elif tool_name == 'video_analyze':
            from aibrain.tools.video_analyse import video_analyse
            import json as _json
            custom_prompt = resolve_templates(step.get('prompt', ''), context) or None
            result = video_analyse(resolved_input, prompt=custom_prompt)
            return _json.dumps(result, ensure_ascii=False)
        elif tool_name == 'web_search':
            from aibrain.tools.builtin import WebSearchTool
            result = WebSearchTool()(query=resolved_input)
            return str(result)
        elif tool_name == 'http_request':
            from aibrain.tools.builtin import WebFetchTool
            url = step.get('url', resolved_input)
            result = WebFetchTool()(url=url)
            return str(result)
        elif tool_name == 'document_loader':
            from aibrain.core.ingest import DocumentIngester
            result_obj = DocumentIngester().ingest(resolved_input)
            if result_obj.errors:
                return f"Ingested with errors: {result_obj.errors}"
            return f"Ingested {result_obj.chunks_stored} chunks from {resolved_input}"
        elif tool_name == 'text_to_speech':
            from aibrain.core.tts import speak
            speak(resolved_input)
            return f"Speech: {len(resolved_input)} chars"
        elif tool_name == 'notification_send':
            from aibrain.core.reactive_chains import _send_telegram
            ok = _send_telegram(resolved_input)
            return "sent" if ok else "failed"
        elif tool_name == 'browser_use':
            url = step.get('url', resolved_input)
            try:
                from aibrain.core.browser_pool import get_pool
                from playwright.sync_api import sync_playwright  # noqa: F401 — import verifies playwright installed
            except ImportError:
                return "browser_use unavailable: playwright not installed"
            with get_pool().checkout() as browser:
                page = browser.new_page()
                page.goto(url)
                content = page.content()[:10000]
                page.close()
                return content
        elif tool_name == 'email_send':
            from aibrain.core.email_sender import _send_via_resend
            to = resolve_templates(step.get('to', ''), context)
            subject = resolve_templates(step.get('subject', 'AIBrain notification'), context)
            success = _send_via_resend(to=to, subject=subject, html=resolved_input)
            return "sent" if success else "failed"
        elif tool_name == 'vector_store':
            import aibrain_db
            aibrain_db.init_embedder()
            vec = aibrain_db._compute_embedding(resolved_input)
            if vec is None:
                return "embedding not available"
            from aibrain.core.vector_store import get_vector_store
            vs = get_vector_store(backend='auto')
            results = vs.search(vec, k=5)
            import json as _json2
            return _json2.dumps({"query_dims": len(vec), "top_k": [[id, score] for id, score in results]}, ensure_ascii=False)
        elif tool_name == 'social_post':
            import os as _os
            from aibrain.core.social.twitter_playwright import post_tweet
            success = post_tweet(text=resolved_input, env=_os.environ.copy())
            return "posted" if success else "failed"
        elif tool_name == 'embedding_model':
            import aibrain_db
            aibrain_db.init_embedder()
            vec = aibrain_db._compute_embedding(resolved_input)
            if vec is None:
                return "embedding unavailable"
            import json as _json3
            return _json3.dumps({"dims": len(vec), "preview": vec[:8]}, ensure_ascii=False)
        elif tool_name == 'email_read':
            import json as _json5
            from aibrain.core.email_reader import fetch_unread, _load_email_creds
            creds = _load_email_creds()
            address = creds.get("GMAIL_ADDRESS", "")
            password = creds.get("GMAIL_APP_PASSWORD", "")
            if not address or not password:
                return _json5.dumps({"error": "GMAIL_ADDRESS or GMAIL_APP_PASSWORD missing in .decker_env"})
            imap_host = step.get('imap_host', 'imap.gmail.com')
            max_count = min(int(step.get('limit', 10) or 10), 50)
            try:
                emails = fetch_unread(imap_host, address, password, max_count=max_count)
                query = (resolved_input or "").strip().lower()
                if query:
                    emails = [e for e in emails if
                              query in (e.get('sender', '') or '').lower()
                              or query in (e.get('subject', '') or '').lower()
                              or query in (e.get('body', '') or '').lower()]
                return _json5.dumps(emails, ensure_ascii=False, default=str)
            except Exception as e:
                return _json5.dumps({"error": str(e)[:300]})
        elif tool_name == 'database_query':
            import json as _json4
            import re as _re
            sql = resolved_input.strip()
            forbidden = r'\b(DROP|DELETE|INSERT|UPDATE|ALTER|CREATE|REPLACE|TRUNCATE|RENAME|ATTACH|DETACH|PRAGMA|VACUUM|ANALYZE|REINDEX)\b'
            if _re.search(forbidden, sql, _re.IGNORECASE):
                return _json4.dumps({"error": "destructive SQL rejected", "sql_keyword_matched": True})
            stripped = sql.rstrip(';').rstrip()
            if ';' in stripped:
                return _json4.dumps({"error": "multi-statement queries not allowed"})
            normalized = sql.lstrip().upper()
            if not (normalized.startswith('SELECT') or normalized.startswith('WITH')):
                return _json4.dumps({"error": "only SELECT queries allowed"})
            try:
                from aibrain_db import get_db as _get_db
                import sqlite3 as _sqlite3
                conn = _get_db()
                conn.row_factory = _sqlite3.Row
                conn.execute("PRAGMA busy_timeout = 5000")
                cur = conn.execute(sql)
                rows = cur.fetchmany(100)
                truncated = len(rows) == 100 and cur.fetchone() is not None
                result = [dict(r) for r in rows]
                if truncated:
                    return _json4.dumps({"rows": result, "truncated": True, "limit": 100}, ensure_ascii=False, default=str)
                return _json4.dumps(result, ensure_ascii=False, default=str)
            except Exception as e:
                return _json4.dumps({"error": str(e)[:300]})
        else:
            placeholder = f"[tool:{tool_name} output placeholder]"
            logger.warning("Unknown aibrain tool '%s' — returning placeholder", tool_name)
            return placeholder
    except Exception as e:
        logger.error("Aibrain tool '%s' failed: %s", tool_name, e)
        return ""


# ---------------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------------
def run_workflow(
    workflow_path_or_id: str,
    input_data: Optional[dict] = None,
    actor: str = "neuro",
    capabilities: Optional[Dict[str, Dict[str, Any]]] = None,
) -> dict:
    """Execute a .workflow.yaml file end-to-end.

    Args:
        workflow_path_or_id: Path to the .workflow.yaml file.
        input_data: Dict of inputs referenced as {input.field} in prompts.
        actor: Who is running this workflow (for audit trail).
        capabilities: Override the default capabilities config.

    Returns:
        {"output": str, "steps": list, "elapsed": float}
    """
    start = time.monotonic()
    input_data = input_data or {}
    caps = capabilities or DEFAULT_CAPABILITIES

    wf = load_workflow(workflow_path_or_id)
    steps = wf.get('steps', [])

    # context maps step_id → output value (str or dict for input steps)
    context: Dict[str, Any] = {"input": input_data}
    step_records: List[dict] = []
    final_output: Optional[str] = None

    for step in steps:
        step_id   = step.get('id', '')
        step_type = step.get('type', '')
        optional  = step.get('optional', False)

        # ── input ────────────────────────────────────────────────────────────
        if step_type == 'input':
            context[step_id] = input_data
            step_records.append({"id": step_id, "type": "input", "output": input_data})
            continue

        # ── tool ─────────────────────────────────────────────────────────────
        if step_type == 'tool':
            tool_cap = step.get('capability', 'unknown')
            cap_conf = caps.get(tool_cap, {})
            if optional and cap_conf.get('provider') == 'none':
                logger.info("Step '%s' skipped (tool '%s' unavailable)", step_id, tool_cap)
                context[step_id] = ""
                step_records.append({"id": step_id, "type": "tool", "output": "", "skipped": True})
                continue
            gate_raw = step.get('gate')
            if gate_raw and not evaluate_gate(gate_raw, context):
                if not optional:
                    raise RuntimeError(f"Gate failed for required step '{step_id}': {gate_raw}")
                logger.info("Gate blocked optional tool step '%s': %s", step_id, gate_raw)
                context[step_id] = ""
                step_records.append({"id": step_id, "type": "tool", "output": "", "skipped": True, "gate_block": True})
                continue
            provider = cap_conf.get('provider', '')
            if provider == 'aibrain':
                output = _execute_aibrain_tool(tool_cap, step, context)
                logger.info("Tool step '%s' (%s) — executed via aibrain", step_id, tool_cap)
            else:
                output = f"[tool:{tool_cap} output placeholder]"
                logger.info("Tool step '%s' (%s) — placeholder (provider=%s)", step_id, tool_cap, provider)
            context[step_id] = output
            step_records.append({"id": step_id, "type": "tool", "output": output})
            continue

        # ── output ───────────────────────────────────────────────────────────
        if step_type == 'output':
            raw_content = step.get('content', '')
            final_output = resolve_templates(raw_content, context) if raw_content else ''
            step_records.append({"id": step_id, "type": "output", "output": final_output})
            break  # output step ends the workflow

        # ── llm ──────────────────────────────────────────────────────────────
        if step_type == 'llm':
            cap      = step.get('capability', '')
            cap_conf = caps.get(cap, {})
            provider = cap_conf.get('provider', 'none')

            # optional + unavailable → skip
            if optional and provider in ('none', None):
                logger.info("Step '%s' skipped (llm '%s' unavailable)", step_id, cap)
                context[step_id] = ""
                step_records.append({"id": step_id, "type": "llm", "output": "", "skipped": True})
                continue

            # gate — evaluated against RAW condition + context
            gate_raw = step.get('gate')
            if gate_raw and not evaluate_gate(gate_raw, context):
                if not optional:
                    raise RuntimeError(
                        f"Gate failed for required step '{step_id}': {gate_raw}"
                    )
                logger.info("Gate blocked optional step '%s': %s", step_id, gate_raw)
                context[step_id] = ""
                step_records.append({
                    "id": step_id, "type": "llm", "output": "",
                    "skipped": True, "gate_block": True,
                })
                continue

            prompt = resolve_templates(step.get('prompt', ''), context)
            model  = cap_conf.get('model', '')

            try:
                if provider == 'ollama':
                    raw = _ollama_http_call(
                        system_prompt="", user_prompt=prompt,
                        model=model, max_tokens=None,
                    )
                    result = raw.get("content", "") if isinstance(raw, dict) else str(raw)
                elif provider in OPENAI_COMPATIBLE_PROVIDERS:
                    api_key = os.environ.get(cap_conf.get('api_key_env', ''), '')
                    if not api_key:
                        raise RuntimeError(
                            f"API key env var '{cap_conf.get('api_key_env')}' not set for step '{step_id}'"
                        )
                    result = _openai_compatible_call(
                        OPENAI_COMPATIBLE_PROVIDERS[provider], api_key, model, "", prompt
                    )
                elif provider == 'anthropic':
                    api_key = os.environ.get(cap_conf.get('api_key_env', ''), '')
                    if not api_key:
                        raise RuntimeError(
                            f"API key env var '{cap_conf.get('api_key_env')}' not set for step '{step_id}'"
                        )
                    result = _anthropic_call(api_key, model, "", prompt)
                elif provider == 'gemini':
                    api_key = os.environ.get(cap_conf.get('api_key_env', ''), '')
                    if not api_key:
                        raise RuntimeError(
                            f"API key env var '{cap_conf.get('api_key_env')}' not set for step '{step_id}'"
                        )
                    result = _gemini_call(api_key, model, "", prompt)
                else:
                    raise RuntimeError(
                        f"Unsupported LLM provider '{provider}' for step '{step_id}'. "
                        "Supported: ollama, openai, anthropic, gemini, groq, together, "
                        "mistral, deepseek, openrouter, grok"
                    )
            except RuntimeError:
                raise
            except Exception as e:
                raise RuntimeError(f"LLM call failed for step '{step_id}': {e}") from e
            context[step_id] = result
            step_records.append({"id": step_id, "type": "llm", "output": result})
            continue

        raise ValueError(f"Unknown step type '{step_type}' in step '{step_id}'")

    elapsed = time.monotonic() - start
    output_str = final_output if final_output is not None else (
        str(step_records[-1]['output']) if step_records else ""
    )
    return {
        "output":  output_str,
        "steps":   step_records,
        "elapsed": round(elapsed, 3),
    }
