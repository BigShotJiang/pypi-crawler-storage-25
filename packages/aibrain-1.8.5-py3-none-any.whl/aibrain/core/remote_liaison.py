from __future__ import annotations

import logging
import os
import socket
import sys
import threading
import time
import uuid
from typing import Any, Callable, Optional

from aibrain.core.agent_comms import FleetBus, CloudEvent

logger = logging.getLogger("aibrain.remote_liaison")

LIAISON_REQUEST_TOPIC = "fleet.liaison.request"
LIAISON_REPLY_TOPIC_LEGACY = "fleet.liaison.reply"
LIAISON_REPLY_TOPIC_PREFIX = "fleet.liaison.reply."
LIAISON_SUBSCRIBER_TIMEOUT_S = 90


class RemoteLiaisonError(Exception):
    """Errors originating from the remote liaison module."""
    pass


# ---------------------------------------------------------------------------
# Server side
# ---------------------------------------------------------------------------

def start_liaison_subscriber(
    host_id: Optional[str] = None,
    broker_url: Optional[str] = None,
) -> dict:
    """
    Start a background FleetBus subscriber that listens for liaison requests,
    runs the local Claude CLI, and publishes verdicts.

    Returns
    -------
    dict
        ``{ok: True, sub_id: str, agent_id: str, bus: FleetBus}`` on success,
        ``{ok: False, error: str}`` on failure.
    """
    # ---- resolve host identity ----
    resolved_host = host_id or socket.gethostname()
    agent_id = f"liaison_subscriber@{resolved_host}"

    try:
        bus = FleetBus(agent_id=agent_id, broker_url=broker_url)
    except Exception as exc:
        logger.error("Failed to instantiate FleetBus for liaison subscriber: %s", exc)
        return {"ok": False, "error": str(exc)}

    # ---- one-time imports & caching (avoid circular imports at module level) ----
    try:
        from aibrain.core.companies import (
            _load_liaison_persona,
            _resolve_decker_tools_dir,
            _LIAISON_REVIEW_PROMPT_TEMPLATE,
            _parse_liaison_verdict,
            record_liaison_verdict,
            _get_db,
        )
    except ImportError as exc:
        logger.error("Cannot import liaison helpers from companies: %s", exc)
        return {"ok": False, "error": f"ImportError: {exc}"}

    # Resolve tools dir and inject into sys.path once
    try:
        tools_dir = _resolve_decker_tools_dir()
        if str(tools_dir) not in sys.path:
            sys.path.insert(0, str(tools_dir))
    except Exception as exc:
        logger.error("Failed to resolve decker tools dir: %s", exc)
        return {"ok": False, "error": f"resolve_decker_tools_dir: {exc}"}

    # Import call_claude_cli once
    try:
        from claude_cli import call_claude_cli  # type: ignore[import-not-found]
    except ImportError as exc:
        logger.error("Cannot import call_claude_cli: %s", exc)
        return {"ok": False, "error": f"ImportError: {exc}"}

    # Load persona once
    try:
        persona = _load_liaison_persona()
    except Exception as exc:
        logger.error("Failed to load liaison persona: %s", exc)
        return {"ok": False, "error": f"_load_liaison_persona: {exc}"}

    # ---- subscription callback ----
    def _on_liaison_request(event: dict) -> None:
        logger.debug("Liaison subscriber received event: %s", event.get("id", "?"))

        payload = event.get("data", {})
        task_id = payload.get("task_id")
        work_output = payload.get("work_output", "")
        reply_topic = payload.get("reply_topic")  # optional – legacy callers omit this

        if not task_id:
            logger.warning("Liaison request missing task_id; ignoring.")
            return

        # Default verdict in case of any failure
        verdict_payload: dict[str, Any] = {
            "task_id": task_id,
            "verdict": "FAIL",
            "score": 0.0,
            "critique": "remote subscriber CLI failed (unknown error)",
        }

        try:
            # Fetch task metadata
            db = _get_db()
            task_row = db.execute(
                "SELECT title, description, priority FROM company_issues WHERE id = ?",
                (task_id,),
            ).fetchone()

            if task_row is None:
                raise RemoteLiaisonError(f"Task {task_id} not found in company_issues")

            title = task_row["title"] or ""
            description = task_row["description"] or ""
            priority = task_row["priority"] or ""

            # Format prompt
            prompt = _LIAISON_REVIEW_PROMPT_TEMPLATE.format(
                task_id=task_id,
                title=title,
                priority=priority,
                description=description,
                work_output=work_output,
            )

            # Call Claude CLI
            rc, stdout, stderr = call_claude_cli(
                prompt,
                system_prompt=persona,
                model=None,
                timeout_s=LIAISON_SUBSCRIBER_TIMEOUT_S,
            )

            if rc != 0:
                logger.warning(
                    "Claude CLI failed for task %s rc=%d stderr=%s",
                    task_id,
                    rc,
                    stderr[:300],
                )
                verdict_payload = {
                    "task_id": task_id,
                    "verdict": "FAIL",
                    "score": 0.0,
                    "critique": f"remote subscriber CLI failed rc={rc} stderr={stderr[:300]}",
                }
            else:
                parsed = _parse_liaison_verdict(stdout)
                verdict_payload = {"task_id": task_id, **parsed}

        except Exception as exc:
            logger.error(
                "Exception during liaison review for task %s: %s", task_id, exc
            )
            verdict_payload = {
                "task_id": task_id,
                "verdict": "FAIL",
                "score": 0.0,
                "critique": f"remote subscriber exception: {exc}",
            }

        # ---- publish verdict ----
        try:
            target_topic = reply_topic if reply_topic else LIAISON_REPLY_TOPIC_LEGACY
            bus.publish(target_topic, verdict_payload)
            logger.debug("Published verdict for task %s to %s", task_id, target_topic)
        except Exception as pub_exc:
            logger.error("Failed to publish verdict for task %s: %s", task_id, pub_exc)

        # ---- record audit ----
        try:
            record_liaison_verdict(
                task_id,
                verdict_payload["verdict"],
                verdict_payload["score"],
                verdict_payload["critique"],
                source="agent_review",
            )
        except Exception as rec_exc:
            logger.error("Failed to record liaison verdict for task %s: %s", task_id, rec_exc)

    # ---- subscribe ----
    try:
        sub_id = bus.subscribe(LIAISON_REQUEST_TOPIC, _on_liaison_request)
    except Exception as exc:
        logger.error("Failed to subscribe to %s: %s", LIAISON_REQUEST_TOPIC, exc)
        return {"ok": False, "error": str(exc)}

    logger.info(
        "Liaison subscriber started (agent_id=%s, sub_id=%s)", agent_id, sub_id
    )
    return {"ok": True, "sub_id": sub_id, "agent_id": agent_id, "bus": bus}


def stop_liaison_subscriber(sub_id: str, bus: FleetBus) -> bool:
    """
    Unsubscribe the liaison subscriber AND tear down the underlying broker
    client. Without the close() the poll thread survives the unsubscribe
    and continues to consume messages from the broker queue, which leaks
    threads across subscriber start/stop cycles and pollutes integration
    tests that boot a fresh broker per case.

    Returns
    -------
    bool
        ``True`` on success.
    """
    ok = True
    try:
        bus.unsubscribe(sub_id)
        logger.info("Liaison subscriber unsubscribed (sub_id=%s)", sub_id)
    except Exception as exc:
        logger.error("Failed to unsubscribe liaison subscriber %s: %s", sub_id, exc)
        ok = False
    # Always attempt to close — even if unsubscribe failed.
    try:
        if hasattr(bus, "close"):
            bus.close()
    except Exception as exc:
        logger.error("Failed to close liaison subscriber bus: %s", exc)
        ok = False
    return ok


# ---------------------------------------------------------------------------
# Caller side (event-driven)
# ---------------------------------------------------------------------------

def publish_liaison_request_async(
    task_id: str,
    work_output: str,
    broker_url: Optional[str] = None,
) -> dict:
    """
    Publish a liaison request on the FleetBus and return immediately.

    Returns
    -------
    dict
        ``{ok: True, reply_topic: str, bus: FleetBus, request_id: str}``
        or ``{ok: False, error: str}``.
    """
    caller_id = f"liaison_caller@{socket.gethostname()}_{uuid.uuid4().hex[:8]}"
    try:
        bus = FleetBus(agent_id=caller_id, broker_url=broker_url)
    except Exception as exc:
        logger.error("Failed to create caller FleetBus: %s", exc)
        return {"ok": False, "error": str(exc)}

    reply_topic = f"{LIAISON_REPLY_TOPIC_PREFIX}{task_id}.{uuid.uuid4().hex[:8]}"
    request_id = uuid.uuid4().hex

    try:
        bus.publish(
            LIAISON_REQUEST_TOPIC,
            {
                "task_id": task_id,
                "work_output": str(work_output),
                "reply_topic": reply_topic,
            },
        )
    except Exception as exc:
        logger.error("Failed to publish liaison request for task %s: %s", task_id, exc)
        return {"ok": False, "error": str(exc)}

    logger.debug(
        "Published liaison request for task %s (reply_topic=%s, request_id=%s)",
        task_id,
        reply_topic,
        request_id,
    )
    return {
        "ok": True,
        "reply_topic": reply_topic,
        "bus": bus,
        "request_id": request_id,
    }


def register_verdict_callback(
    bus: FleetBus,
    reply_topic: str,
    callback: Callable[[dict], None],
) -> str:
    """
    Subscribe to *reply_topic* and invoke *callback(payload)* on each message.

    Returns
    -------
    str
        Subscription id that can be used to unsubscribe later.
    """
    sub_id = bus.subscribe(reply_topic, callback)
    logger.debug("Registered verdict callback on %s (sub_id=%s)", reply_topic, sub_id)
    return sub_id


def wait_for_verdict(
    bus: FleetBus,
    reply_topic: str,
    timeout: float = 360.0,
) -> Optional[dict]:
    """
    Synchronous facade that waits for a single verdict on *reply_topic*.

    Internally uses ``threading.Event`` – **no polling, no sleep loop**.

    Returns
    -------
    Optional[dict]
        The verdict payload (the inner ``data`` field of the CloudEvent),
        or ``None`` if the timeout expires.

    Bug fix (2026-05-13): previously returned the full CloudEvent envelope.
    Callers in companies.py read ``payload["verdict"]`` directly, so the
    envelope shape made every remote-Liaison reply silently parse as FAIL
    (the default in ``payload.get("verdict", "FAIL")``). Now unwraps so
    ``payload`` is the verdict dict shipped by the subscriber.
    """
    event = threading.Event()
    result: Optional[dict] = None

    def _capture(payload: dict) -> None:
        nonlocal result
        # FleetBus subscribers receive the full CloudEvent dict. The verdict
        # the subscriber published is in payload["data"]. Unwrap so the
        # caller's contract matches the subscriber's publish payload.
        if isinstance(payload, dict) and "data" in payload and isinstance(payload["data"], dict):
            result = payload["data"]
        else:
            # Defensive: some callers may already pass an unwrapped dict.
            result = payload
        event.set()

    sub_id = bus.subscribe(reply_topic, _capture)
    logger.debug("Waiting for verdict on %s (timeout=%.1fs)", reply_topic, timeout)

    if not event.wait(timeout=timeout):
        logger.warning("Timed out waiting for verdict on %s", reply_topic)
        bus.unsubscribe(sub_id)
        return None

    bus.unsubscribe(sub_id)
    logger.debug("Received verdict on %s", reply_topic)
    return result