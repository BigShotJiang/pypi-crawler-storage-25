from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional

from aibrain.core.errors import MemoryCapabilityMissing


@dataclass
class Memory:
    id: str
    content: str
    metadata: dict = field(default_factory=dict)
    score: float = 0.0
    provider_id: str = ''

CAPABILITY_TOKENS: frozenset = frozenset({
    'semantic_search', 'transactional', 'batch_store', 'importance_scoring',
    'forget', 'idempotent_store', 'enumerate', 'time_travel',
    'attribution_graph', 'conversational_threads', 'peer_modeling',
    'fact_extraction', 'relation_modeling',
})

class MemoryProvider(ABC):
    @property
    @abstractmethod
    def id(self) -> str:
        ...

    @property
    @abstractmethod
    def capabilities(self) -> frozenset:
        ...

    async def init(self, config: dict) -> None:
        pass

    @abstractmethod
    async def store(self, content: str, metadata: dict) -> str:
        ...

    @abstractmethod
    async def retrieve(self, query: str, top_k: int = 5, filters: dict | None = None) -> list['Memory']:
        ...

    async def destroy(self) -> None:
        pass

    async def forget(self, memory_id: str) -> None:
        if 'forget' in self.capabilities:
            raise NotImplementedError(
                f'Provider {self.id} declared forget but did not implement it'
            )

    def check_capability(self, capability: str) -> None:
        if capability not in self.capabilities:
            raise MemoryCapabilityMissing(capability)
