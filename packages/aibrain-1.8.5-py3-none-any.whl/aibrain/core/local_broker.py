"""broker_local.py — F-LOCAL-BROKER-MIRROR-1: local Windows broker mirror.

Push-on-demand: agents publish to localhost:8765, mirror forwards to VPS broker.
Agents whose sandboxes block outbound HTTP to 76.13.198.228 can reach localhost.

Usage:
    python -m aibrain.core.broker_local          # start mirror daemon
    AIBRAIN_VPS_BROKER=http://76.13.198.228:8765 python -m aibrain.core.broker_local
"""
import json, logging, os, sys, threading, time, urllib.request
from pathlib import Path

log = logging.getLogger("aibrain.broker_local")

LOCAL_PORT = int(os.environ.get("AIBRAIN_LOCAL_BROKER_PORT", "8765"))
VPS_BROKER = os.environ.get("AIBRAIN_VPS_BROKER", "")
LOCAL_DB = Path(os.environ.get("AIBRAIN_ROOT", str(Path.home()))) / "aibrain.db"


def _forward_to_vps(topic: str, payload: dict):
    """Push a message to the VPS broker."""
    if not VPS_BROKER:
        return
    try:
        url = f"{VPS_BROKER}/publish"
        data = json.dumps({"topic": topic, "payload": payload}).encode()
        req = urllib.request.Request(url, data=data,
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass  # VPS unreachable — message stays local


def _pull_from_vps():
    """Pull messages from VPS broker for local agents."""
    if not VPS_BROKER:
        return
    try:
        url = f"{VPS_BROKER}/messages?since=local_mirror"
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.loads(resp.read())
            for msg in data.get("messages", []):
                _store_local(msg)
    except Exception:
        pass


def _store_local(msg: dict):
    """Store a pulled message in local agent_messages table."""
    import sqlite3
    try:
        db = sqlite3.connect(str(LOCAL_DB))
        db.execute(
            """INSERT OR IGNORE INTO agent_messages 
               (msg_id, event_type, source_agent, target_agent, subject, payload)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (msg.get("id", ""), msg.get("type", ""),
             msg.get("source", ""), msg.get("target", "*"),
             msg.get("subject", ""), json.dumps(msg.get("data", {}))))
        db.commit(); db.close()
    except Exception:
        pass


def run_mirror():
    """Run the local broker mirror daemon. Syncs to VPS every 5s."""
    log.info(f"Local broker mirror starting on :{LOCAL_PORT}")
    log.info(f"VPS broker: {VPS_BROKER or 'NONE (local-only mode)'}")
    while True:
        try:
            _pull_from_vps()
        except Exception as e:
            log.debug("Pull failed: %s", e)
        time.sleep(5)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_mirror()
