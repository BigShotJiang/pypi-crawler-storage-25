"""aibrain.core.lucy_loop — LucyLoop: the autonomous gap-closing control loop.

Phases per iteration:
  CLARIFY  -> load GoalEngine, set desired state if provided
  MEASURE  -> compute gap score (0.0-1.0)
  EXECUTE  -> call BridgeLayer to close the gap
  VERIFY   -> update criterion progress from execution result
  CAPTURE  -> store new skills/artifacts via SkillCompiler
  CHECK_IN -> send AgentBus status message every checkin_interval iterations
  REPEAT   -> check halting conditions; loop or return LucyResult

Halting conditions:
  gap >= 0.95                  -> "goal_reached"
  iterations >= max_iterations -> "max_iterations"
  cost > cost_ceiling          -> "cost_ceiling"
  3 iterations delta < 0.02   -> "no_progress"
  needs_clarification()        -> "clarification_needed"

F-LUCY-CTRL-B-INTERRUPT-1: cooperative cancel checkpoints at each phase boundary.
Ctrl+B in the Lucy CLI sets a cancel flag; check_and_raise() in cancel_flag
translates that into a CancelledError caught by the caller (lucy_agent.py).
"""
from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger(__name__)

try:
    from aibrain.core.cancel_flag import check_and_raise as _cancel_check
    _CANCEL_OK = True
except ImportError:
    _CANCEL_OK = False


@dataclass
class LucyResult:
    gap_history: list
    artifacts_created: list
    skills_captured: list
    iterations: int
    final_gap: float
    reason_stopped: str
    clarifications_needed: list = field(default_factory=list)


def _gate_loop_artifact(project_id: str, iteration: int, gap_desc: str,
                        source: bytes, score: float) -> bool:
    """Case-mirrored commit-boundary gate: a durable code artifact is
    reviewed by the company Liaison BEFORE it is persisted. No verify: line
    is used — loop criteria are arbitrary and goal-state lives outside the
    gate sandbox, so an out-of-root verify line would strand the task; the
    Liaison reviews the structured work_output narrative instead. Fail-safe:
    ANY gate error returns False so an unreviewed artifact is never
    persisted (conservative direction — no false 'committed')."""
    try:
        from aibrain.core.companies import (
            create_task, checkout_task, complete_task, TaskReviewFailed,
        )
    except Exception as _imp:
        log.warning("LucyLoop: gate import failed (%s) — artifact NOT persisted",
                    _imp)
        return False
    try:
        src_txt = source.decode("utf-8", "replace")[:1500]
        t = create_task(
            "GT_LRWrEBQQ",
            title=f"LucyLoop {project_id} iter{iteration} artifact (commit boundary)",
            description=(f"Autonomous LucyLoop produced a durable artifact for "
                         f"gap: {gap_desc[:200]}. Review the source against the "
                         f"gap before it is persisted. score={score:.3f}."),
            assignee_agent_id="CDTYrHYkyH8",
            priority="medium",
        )
        checkout_task(t["id"], "CDTYrHYkyH8")
        wo = (
            f"DONE:\n- LucyLoop artifact ready to persist for gap: "
            f"{gap_desc[:200]} (project={project_id} iter={iteration}, "
            f"score={score:.3f}).\n\nSOURCE (first 1500 chars):\n{src_txt}\n\n"
            f"DIDN'T TOUCH:\n- Nothing committed yet; persist is blocked on "
            f"this review (Case-mirrored commit-boundary gate).\n\n"
            f"VERIFICATION:\n- ge.measure() this iteration={score:.3f}, a net "
            f"improvement vs prior best (only net-progress 'fix' artifacts "
            f"reach this gate; churn iterations are not persisted).\n\n"
            f"OPEN CONCERNS:\n- None."
        )
        complete_task(t["id"], work_output=wo)
        return True
    except TaskReviewFailed as _f:
        log.warning("LucyLoop: artifact gate FAIL (%s) — not persisted, loop "
                    "will retry", str(_f)[:160])
        return False
    except Exception as _e:
        log.warning("LucyLoop: artifact gate error (%s: %s) — not persisted "
                    "(fail-safe)", type(_e).__name__, str(_e)[:160])
        return False


class LucyLoop:
    """Autonomous gap-closing control loop -- pluggable by agent_id and project_id."""

    def __init__(self, agent_id: str = "lucy", checkin_interval: int = 5):
        self.agent_id = agent_id
        self.checkin_interval = checkin_interval
        # Highest ge.measure() (fraction criteria achieved, higher=better)
        # seen so far. Only an iteration that beats this is a "fix" worth
        # committing — drives the Case-mirrored commit-boundary gate.
        self._loop_best_score = -1.0

    def _call_judge(self, ge: "GoalEngine") -> str:
        """Independent judge (reuses the gate's text_review reviewer). Returns
        one of: DONE | OFF_TRACK | CONTINUE | PARSE_ERROR. The executor does NOT
        decide its own completion — this is an unbiased external verdict."""
        reviewer_result = None
        try:
            from aibrain.core.provider_contract import ProviderRouter, ProviderConfigError
            router = ProviderRouter()
            reviewer = router.get_provider("text_review")
            import asyncio as _alo
            goal = ge._state["desired_state"]["goal"]
            criteria = ge._state["desired_state"]["acceptance_criteria"]
            evidence = ge._state["current_state"]["evidence"]
            progress = ge._state["current_state"]["progress"]
            lines = [f"Goal: {goal}", "Acceptance criteria:"]
            for i, crit in enumerate(criteria):
                met = "DONE" if (i < len(progress) and progress[i]) else "UNMET"
                lines.append(f"  [{i+1}] ({met}) {crit}")
            lines.append("Evidence gathered:")
            for ev in (evidence or ["(none)"]):
                lines.append(f"  - {ev}")
            work = "\n".join(lines)
            persona = (
                "You are a strict, independent goal-completion judge. You did NOT "
                "perform this work. Decide ONLY from the evidence whether EVERY "
                "acceptance criterion is fully met with concrete, specific proof. "
                "A criterion with no concrete evidence is NOT met. Generic claims "
                "do not count. Be adversarial: assume the goal is incomplete unless "
                "the evidence proves otherwise. If the agent is working on the wrong "
                "thing, say it is off-track."
            )
            reviewer_result = _alo.new_event_loop().run_until_complete(
                reviewer.invoke({
                    "persona": persona,
                    "work_output": work,
                    "acceptance_criteria": work,
                })
            )
        except (ProviderConfigError, Exception) as _pre:
            log.debug("LucyLoop: judge text_review unavailable: %s", _pre)
            return "PARSE_ERROR"
        if reviewer_result is None:
            return "PARSE_ERROR"
        try:
            verdict_text = reviewer_result.get("critique", "") or reviewer_result.get("text", "")
            score = float(reviewer_result.get("score", 0) or 0)
            verdict = reviewer_result.get("verdict", "FAIL")
            if not verdict_text and score:
                verdict = "PASS" if score >= 0.87 else "FAIL"
            if verdict == "PASS" or score >= 0.87:
                return "DONE"
            if verdict_text and ("off-track" in verdict_text.lower() or "off track" in verdict_text.lower() or "replan" in verdict_text.lower()):
                return "OFF_TRACK"
            return "CONTINUE"
        except Exception as e:
            log.warning("LucyLoop: judge result parse error: %s", e)
            return "PARSE_ERROR"

    def run(
        self,
        project_id: str,
        goal: Optional[str] = None,
        acceptance_criteria: Optional[list] = None,
        max_iterations: Optional[int] = 200,
        cost_ceiling: float = 100.0,
        resume: bool = False,
    ) -> LucyResult:
        """Run the control loop until a halting condition is met."""
        # max_iterations None or 0 => unbounded iterations (run until judge says
        # DONE). cost_ceiling stays the always-on runaway-token backstop.
        _max_iters = max_iterations if (max_iterations and max_iterations > 0) else float('inf')
        if _max_iters == float('inf'):
            log.info("LucyLoop: max_iterations disabled (unbounded) — cost_ceiling=%.2f still applies", cost_ceiling)
        judge_parse_errors = 0
        from aibrain.core.goal_engine import GoalEngine
        from aibrain.core.skill_compiler import SkillCompiler

        ge = GoalEngine(project_id)
        sc = SkillCompiler()
        bridge = None

        try:
            from aibrain.core.hands_bridge import BridgeLayer
            bridge = BridgeLayer(task_id=f"lucy_{project_id}_{uuid.uuid4().hex[:8]}")
        except Exception as exc:
            log.warning("LucyLoop: BridgeLayer unavailable (%s) -- EXECUTE phase will be no-op", exc)

        # Phase 1 -- CLARIFY
        if goal is not None and acceptance_criteria is not None:
            ge.set_desired_state(goal, acceptance_criteria)
        elif goal is not None:
            ge.set_desired_state(goal, [])
        else:
            ge.load()

        if ge.needs_clarification():
            return LucyResult(
                gap_history=[],
                artifacts_created=[],
                skills_captured=[],
                iterations=0,
                final_gap=ge.measure(),
                reason_stopped="clarification_needed",
                clarifications_needed=[
                    "What is the specific desired outcome for this project?",
                    "What are the binary acceptance criteria? (each should be verifiable)",
                ],
            )

        gap_history: list = []
        artifacts_created: list = []
        skills_captured: list = []
        cost_accumulated: float = 0.0
        iteration = 0

        # Resume from checkpoint if requested and no new goal was set
        if resume:
            checkpoint = ge.get_checkpoint()
            if checkpoint is not None:
                iteration = checkpoint.get("iteration", 0)
                cost_accumulated = checkpoint.get("cost_accumulated", 0.0)
                log.info("LucyLoop[%s]: resuming from iteration=%d, cost=%.2f",
                         project_id, iteration, cost_accumulated)
                print(f"[Lucy] Resuming from iteration {iteration} (cost_accumulated={cost_accumulated:.2f})")

        # F-LUCY-ACT-CONTEXT-1: running scratchpad of what each iteration did,
        # fed into plan()'s existing context= param so the planner progresses
        # instead of re-planning step 1 (read_file) forever on edit goals.
        _exec_scratchpad: list = []

        # F-LUCY-LOOP-DROPOUT-INSTRUMENTATION-1 (2026-05-23): track last
        # phase entered. Updated as the iteration progresses; surfaced
        # when run() unwinds due to an unhandled exception so we know
        # exactly which phase boundary the loop died at.
        _last_phase = "INIT"

        while iteration < _max_iters:
            iteration += 1
            iteration_start = time.monotonic()

            # F-LUCY-CTRL-B-INTERRUPT-1: check cancel at phase boundary
            if _CANCEL_OK:
                _cancel_check()

            # Phase 2 -- MEASURE (re-read from disk each iteration)
            _last_phase = f"iter{iteration}:MEASURE"
            log.info("LucyLoop[%s] %s", project_id, _last_phase)
            ge.load()
            gap = ge.measure()
            ge.record_iteration(gap)
            gap_history.append(gap)

            log.info("LucyLoop[%s] iter=%d gap=%.3f", project_id, iteration, gap)
            print(f"[Lucy] iter={iteration} gap={gap:.3f} project={project_id}")

            # Phase 2.5 — INDEPENDENT JUDGE (gates the halt; ge.is_done() is now
            # only a secondary signal, not the arbiter — the executor cannot
            # self-certify completion).
            if ge.is_done():
                log.info("LucyLoop[%s] iter=%d GoalEngine is_done=True (secondary) — awaiting independent judge", project_id, iteration)
            _last_phase = f"iter{iteration}:JUDGE"
            log.info("LucyLoop[%s] %s", project_id, _last_phase)
            judge_decision = self._call_judge(ge)
            if judge_decision == "PARSE_ERROR":
                judge_parse_errors += 1
                if judge_parse_errors >= 3:
                    return LucyResult(
                        gap_history=gap_history,
                        artifacts_created=artifacts_created,
                        skills_captured=skills_captured,
                        iterations=iteration,
                        final_gap=gap,
                        reason_stopped="judge_unavailable",
                    )
            else:
                judge_parse_errors = 0
            if judge_decision == "DONE":
                return LucyResult(
                    gap_history=gap_history,
                    artifacts_created=artifacts_created,
                    skills_captured=skills_captured,
                    iterations=iteration,
                    final_gap=gap,
                    reason_stopped="goal_reached_judge",
                )
            elif judge_decision == "OFF_TRACK":
                ge._state["current_state"]["progress"] = []
                ge._state["current_state"]["evidence"] = []
                ge._state["current_state"]["gap_score"] = 1.0
                ge._save()
                log.warning("LucyLoop[%s] iter=%d judge=OFF_TRACK — progress reset to force replan", project_id, iteration)
            # "CONTINUE" / unrecognized -> keep looping

            # Phase 3 -- EXECUTE
            _last_phase = f"iter{iteration}:EXECUTE"
            log.info("LucyLoop[%s] %s", project_id, _last_phase)
            execution_result = None
            if bridge is not None:
                # F-LUCY-CTRL-B-INTERRUPT-1: check cancel before execute
                if _CANCEL_OK:
                    _cancel_check()
                try:
                    task_description = ge.describe_gap()
                    # plan() returns a list of step dicts, each with a verb key
                    plan_result = bridge.command_hands(
                        {"verb": "plan", "goal": task_description,
                         "context": {"progress_so_far": _exec_scratchpad[-15:]}},
                    )
                    execution_result = plan_result
                    # Normalise: plan() returns list; legacy callers may return dict with "steps"
                    steps = (
                        plan_result if isinstance(plan_result, list)
                        else plan_result.get("steps", []) if isinstance(plan_result, dict)
                        else []
                    )
                    for step in steps[:3]:
                        try:
                            # Pass step directly — BridgeLayer routes sub-verbs to hands.act()
                            act_result = bridge.command_hands(step)
                            if act_result:
                                execution_result = act_result
                        except Exception as step_exc:
                            log.warning("LucyLoop: act step failed: %s", step_exc)
                except Exception as exc:
                    log.warning("LucyLoop: EXECUTE phase error: %s", exc)

            # F-LUCY-ACT-CONTEXT-1: record what this iteration did so the next
            # plan() (via context=) progresses instead of repeating step 1.
            try:
                _st = locals().get("steps", []) or []
                _did = [s.get("verb") if isinstance(s, dict) else str(s)
                        for s in _st[:3]]
                _exec_scratchpad.append(
                    f"iter {iteration}: did {_did} -> result: "
                    f"{str(execution_result)[:400]}")
            except Exception:
                pass

            # Phase 4 -- VERIFY
            _last_phase = f"iter{iteration}:VERIFY"
            log.info("LucyLoop[%s] %s", project_id, _last_phase)
            # F-LUCY-CTRL-B-INTERRUPT-1: check cancel before verify
            if _CANCEL_OK:
                _cancel_check()
            criteria = ge.load()["desired_state"]["acceptance_criteria"]
            execution_text = str(execution_result) if execution_result else ""

            def _is_execution_grounded(ev: str) -> bool:
                """Tier-0 #3 invariant: evidence counts as proof ONLY when it
                derives from a real tool execution (os.path.exists / a real
                subprocess), NOT model judgement or text heuristics. Used to
                stop fabricated/inferred 'met' from reaching the judge."""
                if not ev:
                    return False
                return ev.startswith("FILE_EXISTS:") or ev.startswith("CMD exit=")

            for i, criterion in enumerate(criteria):
                met = False
                evidence = ""
                try:
                    import re as _re, os as _os
                    # 1. FILE_EXISTS check
                    _file_match = _re.search(
                        r'(?:file\s+)?([^\s]+)\s+(?:exists|was\s+created|is\s+created)',
                        criterion, _re.IGNORECASE
                    )
                    if _file_match:
                        _path = _file_match.group(1).strip('"\'')
                        met = _os.path.exists(_path)
                        evidence = f"FILE_EXISTS: {_path} -> {met}"
                        ge.record_progress(i, met, evidence=evidence, gate=True)
                        continue

                    # 2. COMMAND check — criterion IS a shell command (SA-2026-002 F-08).
                    # Validate via the F-01 allow-list / deny-pattern controls in Hands.
                    # The pipe-shortcut and per-verb allow-list previously here are removed:
                    # they bypassed the F-01 hardening and were the regression-miss flagged
                    # by Phase 2 AI-safety A-03 / AI-backend PHI-02.
                    from aibrain.core.the_hands import Hands as _LucyHands
                    _ok_cmd, _cmd_reason = _LucyHands._validate_shell_cmd(criterion)
                    if _ok_cmd:
                        import os as _os
                        import shlex as _shlex
                        import subprocess as _sp
                        try:
                            _argv = _shlex.split(criterion, posix=(_os.name != 'nt'))
                        except ValueError:
                            _argv = None
                        if _argv:
                            _proc = _sp.run(
                                _argv,
                                shell=False,
                                capture_output=True,
                                text=True,
                                timeout=30,
                            )
                            met = (_proc.returncode == 0)
                            evidence = f"CMD exit={_proc.returncode}: {_proc.stdout[:300]}"
                            ge.record_progress(i, met, evidence=evidence, gate=True)
                            continue
                    # If validator rejected or shlex failed, fall through to DEEPSEEK_EVAL/
                    # KEYWORD_OVERLAP path — do NOT execute.

                    # 3. DEEPSEEK_EVAL — semantic check via LLM
                    try:
                        from aibrain.core.agent_dispatch import _deepseek_http_call
                        _prompt = (
                            "Does the following execution result satisfy this criterion? "
                            "Answer YES or NO only.\n"
                            f"Criterion: {criterion}\n"
                            f"Execution result: {execution_text[:800]}"
                        )
                        _resp = _deepseek_http_call(_prompt)
                        met = _resp.strip().upper().startswith("YES")
                        evidence = f"DEEPSEEK_EVAL: {_resp[:200]}"
                        if not _is_execution_grounded(evidence):
                            met = False
                            evidence = "UNVERIFIED(model-claim): " + evidence
                        ge.record_progress(i, met, evidence=evidence, gate=True)
                        continue
                    except Exception:
                        pass

                    # 4. KEYWORD_OVERLAP last resort
                    _cwords = set(criterion.lower().split())
                    _rwords = set(execution_text.lower().split())
                    _overlap = _cwords & _rwords
                    met = len(_overlap) >= max(1, len(_cwords) // 3)
                    evidence = f"KEYWORD_OVERLAP: {_overlap}"
                    if not _is_execution_grounded(evidence):
                        met = False
                        evidence = "UNVERIFIED(model-claim): " + evidence
                    ge.record_progress(i, met, evidence=evidence, gate=True)

                except Exception as _verify_exc:
                    # ADDITIVE GUARD (Decker directive: add, don't rewrite). A
                    # criterion that is NOT a runnable shell command (a prose
                    # workstream description) makes _sp.run raise
                    # FileNotFoundError / WinError 2. The old behaviour fell
                    # through and force-recorded met=False, WIPING progress that
                    # was verified out-of-band. Instead: preserve the prior
                    # GoalEngine state for this criterion and skip — the loop is
                    # not the arbiter of non-command criteria.
                    _vmsg = str(_verify_exc).lower()
                    if isinstance(_verify_exc, (FileNotFoundError, NotADirectoryError)) \
                            or "cannot find the file" in _vmsg \
                            or "winerror 2" in _vmsg:
                        log.info(
                            "LucyLoop: criterion %d is not a shell command "
                            "(%s) — preserving prior progress, not wiping", i,
                            type(_verify_exc).__name__)
                        continue
                    log.warning("LucyLoop: VERIFY criterion %d failed: %s", i, _verify_exc)
                    # safe fallback
                    _cwords = set(criterion.lower().split())
                    _rwords = set(execution_text.lower().split())
                    met = len(_cwords & _rwords) >= max(1, len(_cwords) // 3)
                    evidence = "FALLBACK_OVERLAP"
                    if not _is_execution_grounded(evidence):
                        met = False
                        evidence = "UNVERIFIED(model-claim): " + evidence
                    ge.record_progress(i, met, evidence=evidence, gate=True)

            # Phase 5 -- CAPTURE
            _last_phase = f"iter{iteration}:CAPTURE"
            log.info("LucyLoop[%s] %s", project_id, _last_phase)
            # F-LUCY-CTRL-B-INTERRUPT-1: check cancel before capture
            if _CANCEL_OK:
                _cancel_check()
            if execution_result is not None:
                skill_name = f"lucy_{project_id}_iter{iteration}"
                skill_desc = f"Execution for: {ge.describe_gap()[:100]}"
                artifact_path = f"lucy/{project_id}/iter_{iteration}"
                success_score = ge.measure()
                try:
                    skill = sc.capture(
                        name=skill_name,
                        description=skill_desc,
                        artifact_path=artifact_path,
                        success_score=success_score,
                        task_shape=project_id,
                    )
                    # F-LUCY-LOOP-SKILL-CAPTURE-NULL-1 (2026-05-23): capture()
                    # returns None when the SkillCompiler noise gate rejects
                    # the row (short/unstructured/blacklisted prefix). The
                    # previous code did `skill.name` unconditionally and
                    # raised AttributeError mid-loop, killing the iteration
                    # and surfacing as the long-running "'NoneType' object
                    # has no attribute 'name'" failure in autonomous mode.
                    if skill is not None:
                        skills_captured.append(skill.name)
                    else:
                        log.debug(
                            "LucyLoop[%s]: skill capture rejected by noise "
                            "gate iter=%d (name=%s, score=%.3f) — continuing",
                            project_id, iteration, skill_name, success_score,
                        )
                    if bridge is not None:
                        # Case-mirrored commit boundary: only a net-progress
                        # artifact (a "fix", higher ge.measure() than any prior
                        # iteration) is a candidate to persist, and only after
                        # the company Liaison PASSes it. Churn iterations are
                        # scratch — not persisted, so nothing unreviewed ever
                        # becomes durable, and the Liaison is not called every
                        # iteration (which would kill loop throughput).
                        if success_score <= self._loop_best_score:
                            log.info("LucyLoop: iter %d not a net-progress fix "
                                     "(score=%.3f <= best=%.3f) — artifact not "
                                     "persisted", iteration, success_score,
                                     self._loop_best_score)
                        else:
                            self._loop_best_score = success_score
                            source = str(execution_result).encode()[:4096]
                            if _gate_loop_artifact(project_id, iteration,
                                                   ge.describe_gap(), source,
                                                   success_score):
                                try:
                                    artifact_id = bridge.persist_tool({
                                        "artifact_id": skill_name,
                                        "source_code": source,
                                        "type": "lucy_iteration",
                                        "namespace": "lucy",
                                        "extras": {"project_id": project_id, "iteration": iteration},
                                    })
                                    artifacts_created.append(artifact_id)
                                except Exception as persist_exc:
                                    log.warning("LucyLoop: ArtifactStore persist failed: %s", persist_exc)
                            else:
                                log.warning("LucyLoop: artifact gate did not "
                                            "PASS — iter %d not persisted, loop "
                                            "continues", iteration)
                except Exception as capture_exc:
                    log.warning("LucyLoop: SkillCompiler capture failed: %s", capture_exc)

            # Phase 6 -- CHECK_IN
            # F-LUCY-CTRL-B-INTERRUPT-1: check cancel before checkin
            if _CANCEL_OK:
                _cancel_check()
            if iteration % self.checkin_interval == 0:
                self._checkin(project_id, iteration, gap, artifacts_created, ge)

            # Phase 6.5 -- CHECKPOINT (save state for resume on crash)
            ge.save_checkpoint(iteration, cost_accumulated)

            # Phase 7 -- HALTING CONDITIONS
            elapsed = time.monotonic() - iteration_start
            _last_phase = f"iter{iteration}:END"
            log.info("LucyLoop[%s] %s elapsed=%.1fs gap=%.3f",
                     project_id, _last_phase, elapsed, ge.measure())
            cost_accumulated += elapsed * 0.001
            if cost_accumulated > cost_ceiling:
                return LucyResult(
                    gap_history=gap_history,
                    artifacts_created=artifacts_created,
                    skills_captured=skills_captured,
                    iterations=iteration,
                    final_gap=ge.measure(),
                    reason_stopped="cost_ceiling",
                )

            if ge.needs_clarification() and iteration >= 3:
                return LucyResult(
                    gap_history=gap_history,
                    artifacts_created=artifacts_created,
                    skills_captured=skills_captured,
                    iterations=iteration,
                    final_gap=ge.measure(),
                    reason_stopped="no_progress",
                    clarifications_needed=[
                        "Loop stalled -- no progress in last 3 iterations. What should I try differently?",
                        ge.describe_gap(),
                    ],
                )

        return LucyResult(
            gap_history=gap_history,
            artifacts_created=artifacts_created,
            skills_captured=skills_captured,
            iterations=iteration,
            final_gap=ge.measure(),
            reason_stopped="max_iterations",
        )

    def _checkin(self, project_id: str, iteration: int, gap: float,
                 artifacts: list, ge) -> None:
        msg = (
            f"[Lucy checkin] project={project_id} iter={iteration} "
            f"gap={gap:.3f} artifacts={len(artifacts)}\n"
            f"{ge.describe_gap()[:200]}"
        )
        try:
            from aibrain.core.agent_bus import AgentBus
            AgentBus().send(self.agent_id, "neuro", msg)
        except Exception as exc:
            log.warning("LucyLoop: AgentBus checkin failed: %s", exc)
