"""captcha_handler.py — F-CAPTCHA-HANDLER-1: accessibility-framed CAPTCHA handling.

For disabled users who cannot manually solve CAPTCHAs.
Detects CAPTCHA presence via screenshot, then either:
(a) Solves via 2Captcha API (AIBRAIN_2CAPTCHA_KEY env var)
(b) Flags for human assistance
"""
import logging, os, time

log = logging.getLogger("aibrain.captcha")

TWOCAPTCHA_KEY = os.environ.get("AIBRAIN_2CAPTCHA_KEY", "")

def captcha_detect_dom(page) -> dict:
    """Detect CAPTCHA in a Playwright page via DOM patterns.
    Pass a Playwright page object — the most reliable detection path.
    Returns {detected: bool, type: 'hcaptcha'|'recaptcha'|'cloudflare'|'generic'|None, frame: <Locator>|None}.
    """
    try:
        # hCaptcha iframe
        for sel in ['iframe[src*="hcaptcha.com"]', 'iframe[title*="hCaptcha"]',
                    '[data-hcaptcha-widget-id]', '.h-captcha']:
            if page.locator(sel).count() > 0:
                return {"detected": True, "type": "hcaptcha", "frame": page.locator(sel).first}
        # reCAPTCHA iframe
        for sel in ['iframe[src*="recaptcha"]', 'iframe[title*="reCAPTCHA"]',
                    '.g-recaptcha', '[data-sitekey]']:
            if page.locator(sel).count() > 0:
                return {"detected": True, "type": "recaptcha", "frame": page.locator(sel).first}
        # Cloudflare Turnstile
        for sel in ['iframe[src*="challenges.cloudflare.com"]', '.cf-turnstile',
                    '[name="cf-turnstile-response"]']:
            if page.locator(sel).count() > 0:
                return {"detected": True, "type": "cloudflare", "frame": page.locator(sel).first}
        # Generic text-based detection (last resort — page body text)
        try:
            body_text = page.locator("body").inner_text(timeout=1000).lower()
            for phrase in ["verify you are human", "i'm not a robot", "select all images",
                           "prove you're human", "complete the captcha", "security check"]:
                if phrase in body_text:
                    return {"detected": True, "type": "generic", "frame": None}
        except Exception:
            pass
        return {"detected": False, "type": None, "frame": None}
    except Exception as e:
        log.debug("captcha_detect_dom error: %s", e)
        return {"detected": False, "type": None, "frame": None, "error": str(e)}


def captcha_detect() -> bool:
    """Best-effort screenshot-based CAPTCHA detection.

    PREFER captcha_detect_dom(page) when in browser context — much more reliable.
    This function exists as fallback when no Playwright page is available.

    Returns True if a CAPTCHA-like screen is likely visible.
    """
    try:
        import pyautogui
        # Strategy 1: any visible browser window title indicates CAPTCHA?
        try:
            import subprocess, sys
            if sys.platform.startswith("win"):
                r = subprocess.run(
                    ['powershell', '-NoProfile', '-Command',
                     '(Get-Process | Where-Object {$_.MainWindowTitle -match "captcha|verify.*human|cloudflare.*check|are.you.human"}).MainWindowTitle'],
                    capture_output=True, text=True, timeout=5)
                if r.stdout.strip():
                    return True
            else:
                # Linux/macOS: try wmctrl for window list
                r = subprocess.run(['wmctrl', '-l'], capture_output=True, text=True, timeout=5)
                titles = (r.stdout or "").lower()
                for kw in ("captcha", "verify you are human", "cloudflare check"):
                    if kw in titles:
                        return True
        except Exception:
            pass

        # Strategy 2: pyautogui screenshot + on-screen image search for known CAPTCHA assets
        # (image files at ~/.aibrain/captcha_signatures/*.png — if user has provided them).
        try:
            from pathlib import Path
            sig_dir = Path.home() / ".aibrain" / "captcha_signatures"
            if sig_dir.exists():
                for sig in sig_dir.glob("*.png"):
                    try:
                        loc = pyautogui.locateOnScreen(str(sig), confidence=0.7)
                        if loc:
                            return True
                    except Exception:
                        continue
        except Exception:
            pass

        # Strategy 3: tesseract OCR fallback if available (text-on-screen detection)
        try:
            import pytesseract
            img = pyautogui.screenshot()
            text = pytesseract.image_to_string(img, timeout=5).lower()
            for phrase in ("verify you are human", "i'm not a robot", "select all images",
                           "complete the captcha", "security check"):
                if phrase in text:
                    return True
        except Exception:
            # pytesseract not installed or tesseract not on PATH — skip silently
            pass

        return False
    except Exception as e:
        log.debug("captcha_detect error: %s", e)
        return False


def captcha_solve() -> dict:
    """Attempt to solve CAPTCHA via 2Captcha API.
    Returns {"solved": True, "token": str} or {"solved": False, "error": str}.
    """
    if not TWOCAPTCHA_KEY:
        return {"solved": False, "error": "AIBRAIN_2CAPTCHA_KEY not set. Flag for human."}
    try:
        import pyautogui, base64, io, urllib.request, json
        # Screenshot
        img = pyautogui.screenshot()
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        b64 = base64.b64encode(buf.getvalue()).decode()
        
        # Submit to 2Captcha
        url = "https://2captcha.com/in.php"
        data = urllib.parse.urlencode({
            "key": TWOCAPTCHA_KEY,
            "method": "base64",
            "body": b64,
            "json": 1,
        }).encode()
        req = urllib.request.Request(url, data=data)
        with urllib.request.urlopen(req, timeout=30) as r:
            resp = json.loads(r.read())
        
        if resp.get("status") != 1:
            return {"solved": False, "error": f"2Captcha submit failed: {resp}"}
        
        captcha_id = resp["request"]
        # Poll for result
        for _ in range(30):
            time.sleep(5)
            result_url = f"https://2captcha.com/res.php?key={TWOCAPTCHA_KEY}&action=get&id={captcha_id}&json=1"
            with urllib.request.urlopen(result_url, timeout=10) as r2:
                result = json.loads(r2.read())
            if result.get("status") == 1:
                return {"solved": True, "token": result["request"]}
            if result.get("request") == "ERROR_CAPTCHA_UNSOLVABLE":
                return {"solved": False, "error": "CAPTCHA unsolvable"}
        
        return {"solved": False, "error": "2Captcha timeout after 150s"}
    except Exception as e:
        return {"solved": False, "error": str(e)}


def captcha_flag_for_human(reason: str = "CAPTCHA detected") -> str:
    """Flag current CAPTCHA for human assistance. Returns message for Decker."""
    log.warning("CAPTCHA flagged for human: %s", reason)
    try:
        from aibrain.core.agent_comms import FleetBus
        bus = FleetBus(agent_id="lucy")
        bus.publish("fleet.alert.captcha", {"reason": reason, "timestamp": time.time()})
    except Exception:
        pass
    return f"[captcha] Human assistance needed: {reason}. Notify Decker."
