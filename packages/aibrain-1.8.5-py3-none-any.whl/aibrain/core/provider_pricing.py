"""Provider pricing lookup and routing-outcome recording for aibrain.

Public surface:
    PRICING (dict)
    lookup_cost(provider, model, prompt_tokens, completion_tokens) -> float | None
    format_cost_cents(cents, null_label='$0.00') -> str
    record_routing_outcome(provider, model, prompt_tokens, completion_tokens,
        latency_ms=0, task_type='chat', session_id=None, metadata=None,
        db_path=None) -> int | None
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger("aibrain.provider_pricing")

# ---------------------------------------------------------------------------
# Pricing table (USD per 1M tokens: prompt, completion)
# ---------------------------------------------------------------------------

PRICING: dict[str, dict[str, tuple[float, float]] | None] = {
    "openai": {
        "gpt-4o": (2.50, 10.00),
        "gpt-4o-mini": (0.15, 0.60),
        "gpt-4-turbo": (10.00, 30.00),
        "gpt-3.5-turbo": (0.50, 1.50),
        "o1": (15.00, 60.00),
        "o1-mini": (3.00, 12.00),
    },
    "anthropic": {
        "claude-sonnet-4-5": (3.00, 15.00),
        "claude-sonnet-4-6": (3.00, 15.00),
        "claude-opus-4-7": (15.00, 75.00),
        "claude-haiku-4-5": (0.80, 4.00),
    },
    "deepseek": {
        "deepseek-v4-pro": (0.27, 1.10),
        "deepseek-chat": (0.14, 0.28),
        "deepseek-reasoner": (0.55, 2.19),
    },
    "gemini": {
        "gemini-2.5-pro": (1.25, 5.00),
        "gemini-2.5-flash": (0.075, 0.30),
        "gemini-2.5-flash-lite": (0.0375, 0.15),
    },
    "ollama": {"_default": (0.0, 0.0)},
    "ollama_local": {"_default": (0.0, 0.0)},
    "openrouter": None,
    "claude_cli": None,
}


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def lookup_cost(
    provider: str,
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
) -> float | None:
    """Return cost in **cents** for the given provider/model/token counts.

    Returns ``None`` when the provider is unknown, has no static pricing
    (openrouter / claude_cli), or the model cannot be matched.
    """
    provider_lower = provider.lower()

    # Unknown provider
    if provider_lower not in PRICING:
        return None

    pricing = PRICING[provider_lower]

    # Providers with no static rate
    if pricing is None:
        return None

    # Local / zero-cost providers
    if provider_lower in ("ollama", "ollama_local"):
        return 0.0

    # Strip a leading 'provider/' prefix if present (e.g. 'openai/gpt-4o')
    model_clean = model
    prefix = f"{provider_lower}/"
    if model_clean.lower().startswith(prefix):
        model_clean = model_clean[len(prefix):]

    # Exact match
    if model_clean in pricing:
        p_rate, c_rate = pricing[model_clean]
        cost_dollars = (prompt_tokens / 1_000_000) * p_rate + (
            completion_tokens / 1_000_000
        ) * c_rate
        return round(cost_dollars * 100.0, 6)

    # Longest-prefix match (e.g. 'gpt-4o-2024-08-06' -> 'gpt-4o')
    for key in sorted(pricing.keys(), key=len, reverse=True):
        if model_clean.startswith(key):
            p_rate, c_rate = pricing[key]
            cost_dollars = (prompt_tokens / 1_000_000) * p_rate + (
                completion_tokens / 1_000_000
            ) * c_rate
            return round(cost_dollars * 100.0, 6)

    return None


def format_cost_cents(cents: float | None, null_label: str = "$0.00") -> str:
    """Format a cost-in-cents value as a human-readable dollar string."""
    if cents is None:
        return null_label
    if cents == 0:
        return "$0.00"
    if 0 < abs(cents) < 1:
        return f"${cents / 100:.4f}"
    return f"${cents / 100:.2f}"


# ---------------------------------------------------------------------------
# DB recording
# ---------------------------------------------------------------------------

def _default_db_path() -> Path | None:
    """Best-effort resolve of the aibrain database path."""
    try:
        from aibrain_db import AIBRAIN_ROOT  # type: ignore[import-untyped]
        return Path(AIBRAIN_ROOT) / "aibrain.db"
    except Exception:
        return None


def record_routing_outcome(
    provider: str,
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    latency_ms: int = 0,
    task_type: str = "chat",
    session_id: str | None = None,
    metadata: dict[str, Any] | None = None,
    db_path: str | Path | None = None,
) -> int | None:
    """Insert a row into ``routing_outcomes`` and return the new rowid.

    Returns ``None`` on any error (logs a warning).
    """
    try:
        total_tokens = prompt_tokens + completion_tokens
        cost_cents = lookup_cost(provider, model, prompt_tokens, completion_tokens)
        timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        metadata_json = json.dumps(metadata or {})

        if db_path is None:
            db_path = _default_db_path()
        if db_path is None:
            logger.warning("Cannot resolve db_path; skipping record_routing_outcome")
            return None

        db_path = Path(db_path)

        conn = sqlite3.connect(str(db_path), timeout=10.0)
        try:
            # Try the full schema first (legacy + new columns).
            conn.execute(
                """INSERT INTO routing_outcomes (
                    ts, task_type, handler_shape, override_mode, actor,
                    duration_ms, timestamp, provider, model, prompt_tokens,
                    completion_tokens, total_tokens, cost_cents, session_id,
                    metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    int(time.time()),
                    task_type,
                    "chat",
                    "auto",
                    "chat",
                    latency_ms,
                    timestamp,
                    provider,
                    model,
                    prompt_tokens,
                    completion_tokens,
                    total_tokens,
                    cost_cents,
                    session_id,
                    metadata_json,
                ),
            )
        except sqlite3.OperationalError as exc:
            msg = str(exc).lower()
            if "no such column" in msg or "has no column" in msg:
                # Fall back to new-columns-only insert.
                conn.execute(
                    """INSERT INTO routing_outcomes (
                        timestamp, provider, model, prompt_tokens,
                        completion_tokens, total_tokens, cost_cents,
                        task_type, session_id, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        timestamp,
                        provider,
                        model,
                        prompt_tokens,
                        completion_tokens,
                        total_tokens,
                        cost_cents,
                        task_type,
                        session_id,
                        metadata_json,
                    ),
                )
            else:
                raise

        conn.commit()
        rowid: int = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        return rowid
    except Exception:
        logger.warning("record_routing_outcome failed", exc_info=True)
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # lookup_cost
    assert abs(lookup_cost("openai", "gpt-4o", 1_000_000, 1_000_000) - 1250.0) < 0.01
    assert lookup_cost("ollama", "llama3.2:3b", 1000, 1000) == 0.0
    assert lookup_cost("openrouter", "x", 1, 1) is None
    assert lookup_cost("unknown", "x", 1, 1) is None

    # format_cost_cents
    assert format_cost_cents(None) == "$0.00"
    assert format_cost_cents(None, null_label="(sub)") == "(sub)"
    assert format_cost_cents(0) == "$0.00"

    print("provider_pricing smoke test OK")
