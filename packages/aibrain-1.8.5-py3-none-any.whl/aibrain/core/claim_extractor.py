"""
claim_extractor.py — Extract structured subject-predicate-object claims from memory content.

One memory can contain multiple claims. Contradiction detection operates
on claims, not on raw memory content.

Part of the Memory Lifecycle v1.6 feature.
"""

from __future__ import annotations

import hashlib
import logging
import re
import sqlite3

log = logging.getLogger("aibrain.claim_extractor")


def extract_claims(memory_id: int, content: str, claim_type: str) -> list[dict]:
    """Extract structured claims from memory content.

    Uses the existing semantic_facts extraction pipeline (subject/predicate/object)
    but adds claim_type and temporal metadata.

    Returns list of claim dicts ready for INSERT into memory_claims.
    """
    if not content or not content.strip():
        return []

    claims = []
    try:
        from aibrain.core.fact_extractor import extract_facts
        facts = extract_facts(content)
        for fact in facts:
            if fact.get("action") == "NOOP":
                continue
            fact_content = fact.get("content", "")
            if not fact_content.strip():
                continue
            claims.append({
                "memory_id": memory_id,
                "subject": _extract_subject(fact_content),
                "predicate": _extract_predicate(fact_content, fact.get("category", "")),
                "object": _extract_object(fact_content),
                "claim_type": claim_type,
                "confidence": fact.get("confidence", 0.5),
                "source_memory_id": memory_id,
            })
    except Exception as e:
        log.debug("Fact extraction failed, falling back to sentence-level claims: %s", e)

    # Fallback: if no facts extracted, create a single claim from full content
    if not claims and content.strip():
        claims.append({
            "memory_id": memory_id,
            "subject": _extract_subject(content),
            "predicate": "states",
            "object": content[:200].strip(),
            "claim_type": claim_type,
            "confidence": 0.5,
            "source_memory_id": memory_id,
        })

    return claims


def store_claims(db: sqlite3.Connection, claims: list[dict]) -> int:
    """Insert claims into memory_claims table.

    Returns count of claims inserted.
    """
    count = 0
    for claim in claims:
        try:
            db.execute("""
                INSERT INTO memory_claims
                (memory_id, subject, predicate, object, claim_type, confidence, source_memory_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                claim["memory_id"],
                claim["subject"],
                claim["predicate"],
                claim["object"],
                claim["claim_type"],
                claim.get("confidence", 0.5),
                claim["source_memory_id"],
            ))
            count += 1
        except Exception as e:
            log.debug("Failed to store claim: %s", e)
    if count:
        db.commit()
    return count


# --- Internal helpers for SPO extraction ---

# Common entity patterns for subject extraction
_ENTITY_PATTERNS = [
    re.compile(r"^([\w/\-]+(?:\s+[\w/\-]+)?)\s+(?:is|are|was|were|has|have|will)\s", re.IGNORECASE),
    re.compile(r"^([\w/\-]+(?:\s+[\w/\-]+)?)\s+(?:deployed|shipped|published|launched|completed|built|created)", re.IGNORECASE),
    re.compile(r"(AIBrain|Wintermute|Permeate|Remediate|Rogue|Paragon|Obey|SelRoute)", re.IGNORECASE),
    re.compile(r"((?:v\d+\.\d+(?:\.\d+)?)\s+\w+)", re.IGNORECASE),
]


def _extract_subject(text: str) -> str:
    """Extract the primary subject from a sentence."""
    for pat in _ENTITY_PATTERNS:
        m = pat.search(text)
        if m:
            return m.group(1).strip()[:100]

    # Fallback: first 3 words or up to first verb-like word
    words = text.split()[:5]
    # Find first verb-ish word
    verbs = {"is", "are", "was", "were", "has", "have", "will", "shall", "should",
             "can", "could", "would", "may", "might", "must"}
    subject_words = []
    for w in words:
        if w.lower() in verbs:
            break
        subject_words.append(w)
    if subject_words:
        return " ".join(subject_words)[:100]
    return hashlib.md5(text.encode()).hexdigest()[:12]


def _extract_predicate(text: str, category: str = "") -> str:
    """Extract the predicate (relationship/action) from a sentence."""
    if category:
        return category[:50]

    # Try to find a verb phrase
    m = re.search(
        r"\b(is|are|was|were|has|have|will|uses|runs|deployed|shipped|published|"
        r"launched|completed|built|created|migrated|moved|changed|updated|"
        r"confirmed|verified|planned|targeting|scheduled)\b",
        text, re.IGNORECASE
    )
    if m:
        return m.group(1).lower()[:50]
    return "states"


def _extract_object(text: str) -> str:
    """Extract the object/value from a sentence."""
    # Try to get content after common verbs
    m = re.search(
        r"\b(?:is|are|was|were|has|have|uses|runs on|deployed to|"
        r"migrated to|moved to|changed to|updated to)\s+(.+)",
        text, re.IGNORECASE
    )
    if m:
        return m.group(1).strip()[:200]

    # Fallback: second half of the sentence
    mid = len(text) // 2
    return text[mid:].strip()[:200] if len(text) > 20 else text[:200]
