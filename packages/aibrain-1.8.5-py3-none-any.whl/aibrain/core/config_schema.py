"""config_schema.py -- validation for ~/.aibrain/config.yaml.

Defines REQUIRED_TOP_KEYS, REQUIRED_TEXT_TASK_CLASSES, REQUIRED_MEDIA_KEYS,
and a validate_config(config: dict) -> tuple[bool, list[str]] function that
returns (is_valid, list_of_errors). Used by the first-run wizard before
writing, by the provider router on load, and by the hot-reload watcher.
"""
from __future__ import annotations
import logging
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger("aibrain.config_schema")

REQUIRED_TOP_KEYS = ["version", "fallback_provider", "providers"]
REQUIRED_TEXT_TASK_CLASSES = ["cheap", "judgment", "review"]
REQUIRED_MEDIA_KEYS = ["image", "video", "speech"]
SUPPORTED_SCHEMA_VERSION = 1
DEFAULT_CONFIG_PATH = Path.home() / ".aibrain" / "config.yaml"

LEAF_REQUIRED_FIELDS = {"name", "model"}
LEAF_OPTIONAL_FIELDS = {"api_key_env", "endpoint_override"}
LEAF_ALLOWED_FIELDS = LEAF_REQUIRED_FIELDS | LEAF_OPTIONAL_FIELDS


def _validate_leaf(leaf: Any, path: str) -> list[str]:
    """Validate a single provider leaf dict. Returns list of errors."""
    errors: list[str] = []
    if not isinstance(leaf, dict):
        errors.append(f"{path}: must be a mapping, got {type(leaf).__name__}")
        return errors

    # Check for unknown keys
    unknown = set(leaf.keys()) - LEAF_ALLOWED_FIELDS
    if unknown:
        errors.append(f"{path}: unknown fields {sorted(unknown)}")

    # Required fields
    for field in LEAF_REQUIRED_FIELDS:
        if field not in leaf:
            errors.append(f"{path}.{field}: required field missing")
        elif not isinstance(leaf[field], str) or not leaf[field].strip():
            errors.append(f"{path}.{field}: must be a non-empty string")

    # Optional fields type check
    for field in LEAF_OPTIONAL_FIELDS:
        if field in leaf and leaf[field] is not None:
            if not isinstance(leaf[field], str) or not leaf[field].strip():
                errors.append(f"{path}.{field}: if provided, must be a non-empty string")

    return errors


def validate_config(config: dict) -> tuple[bool, list[str]]:
    """Validate a parsed config dict against the schema.

    Returns (True, []) on valid, (False, [error_messages]) on invalid.
    Errors are descriptive -- each names the bad path + the issue.
    """
    errors: list[str] = []

    if not isinstance(config, dict):
        return False, ["config root must be a mapping"]

    # --- version ---
    if "version" not in config:
        errors.append("version: required field missing")
    elif config["version"] != SUPPORTED_SCHEMA_VERSION:
        errors.append(
            f"version: expected {SUPPORTED_SCHEMA_VERSION}, got {config['version']}"
        )

    # --- fallback_provider ---
    if "fallback_provider" not in config:
        errors.append("fallback_provider: required section missing")
    else:
        errors.extend(_validate_leaf(config["fallback_provider"], "fallback_provider"))

    # --- providers ---
    if "providers" not in config:
        errors.append("providers: required section missing")
    elif not isinstance(config["providers"], dict):
        errors.append("providers: must be a mapping")
    else:
        providers = config["providers"]

        # text
        if "text" not in providers:
            errors.append("providers.text: required section missing")
        elif not isinstance(providers["text"], dict):
            errors.append("providers.text: must be a mapping")
        else:
            for task_class in REQUIRED_TEXT_TASK_CLASSES:
                if task_class not in providers["text"]:
                    errors.append(f"providers.text.{task_class}: required task class missing")
                else:
                    errors.extend(
                        _validate_leaf(
                            providers["text"][task_class],
                            f"providers.text.{task_class}",
                        )
                    )

        # image, video, speech
        for media_key in REQUIRED_MEDIA_KEYS:
            if media_key not in providers:
                errors.append(f"providers.{media_key}: required section missing")
            elif not isinstance(providers[media_key], dict):
                errors.append(f"providers.{media_key}: must be a mapping")
            elif "default" not in providers[media_key]:
                errors.append(f"providers.{media_key}.default: required task class missing")
            else:
                errors.extend(
                    _validate_leaf(
                        providers[media_key]["default"],
                        f"providers.{media_key}.default",
                    )
                )

    return (len(errors) == 0, errors)


def load_and_validate(path: Path | None = None) -> tuple[dict | None, list[str]]:
    """Load YAML from path (default ~/.aibrain/config.yaml), validate.

    Returns (config_dict, []) on success, (None, errors) on failure (file
    missing, YAML parse error, or schema violation).
    """
    target = path or DEFAULT_CONFIG_PATH
    if not target.exists():
        return None, [f"config file not found: {target}"]

    try:
        with open(target, "r", encoding="utf-8") as fh:
            config = yaml.safe_load(fh)
    except yaml.YAMLError as exc:
        return None, [f"YAML parse error in {target}: {exc}"]
    except OSError as exc:
        return None, [f"cannot read {target}: {exc}"]

    if config is None:
        config = {}

    ok, errors = validate_config(config)
    if not ok:
        return None, errors
    return config, []


if __name__ == "__main__":
    # Smoke test
    ok, errors = validate_config({})
    assert not ok, "empty config should fail"
    print(f"empty validation: ok={ok}, errors={len(errors)}")

    minimal = {
        "version": 1,
        "fallback_provider": {"name": "X", "model": "Y"},
        "providers": {
            "text": {
                "cheap":    {"name": "X", "model": "Y"},
                "judgment": {"name": "X", "model": "Y"},
                "review":   {"name": "X", "model": "Y"},
            },
            "image":  {"default": {"name": "X", "model": "Y"}},
            "video":  {"default": {"name": "X", "model": "Y"}},
            "speech": {"default": {"name": "X", "model": "Y"}},
        },
    }
    ok, errors = validate_config(minimal)
    assert ok, f"minimal config should pass, got errors: {errors}"
    print("minimal validation: ok=True")
    print("config_schema smoke test OK")