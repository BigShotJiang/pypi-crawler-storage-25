"""workflow_router — Ollama-classifier-based query → workflow execution.

Reads all workflows/*.workflow.yaml on init, extracts router metadata + descriptions.
Given a natural-language query, picks the best-matching workflow via Ollama classifier
(falls back to keyword-overlap heuristic if Ollama unreachable). Executes via run_workflow().

Usage:
    from aibrain.core.workflow_router import route
    result = route("show me system heartbeat")
    # → {matched_workflow_id, confidence, reasoning, run_result}
"""
from __future__ import annotations
import json
import logging
from pathlib import Path
from typing import Optional

import requests
import yaml

from aibrain.core.yaml_workflow_runner import run_workflow, DEFAULT_CAPABILITIES

logger = logging.getLogger("aibrain.workflow_router")

# Find workflows directory — package + repo-root fallback
WORKFLOW_DIRS = [
    Path(__file__).parent.parent.parent / "workflows",  # repo root /workflows
    Path(__file__).parent.parent / "workflows",         # aibrain/workflows
]


def discover_workflows() -> list[dict]:
    """Scan workflow dirs for .workflow.yaml files. Return list of metadata dicts."""
    found = []
    seen_ids = set()
    for wdir in WORKFLOW_DIRS:
        if not wdir.exists():
            continue
        for path in sorted(wdir.glob("*.workflow.yaml")):
            try:
                wf = yaml.safe_load(path.read_text(encoding='utf-8'))
                meta = wf.get('metadata', {})
                router_block = wf.get('router', {})
                wf_id = meta.get('id') or wf.get('name', path.stem)
                if wf_id in seen_ids:
                    continue
                seen_ids.add(wf_id)
                found.append({
                    "path": str(path),
                    "id": wf_id,
                    "name": meta.get('name', meta.get('id', path.stem)),
                    "description": meta.get('description', wf.get('description', '')),
                    "trigger_keywords": router_block.get('trigger_keywords', []),
                    "trigger_patterns": router_block.get('trigger_patterns', []),
                    "task_type": router_block.get('task_type', 'simple'),
                    "tags": meta.get('tags', []),
                })
            except Exception as e:
                logger.warning("Failed to parse %s: %s", path, e)
    return found


def _keyword_score(query: str, wf: dict) -> float:
    """Heuristic: keyword overlap score 0-1. Higher = stronger match."""
    q = query.lower()
    score = 0.0
    # Exact trigger_keyword match: +0.3 each (cap 0.6)
    kw_hits = sum(1 for k in wf['trigger_keywords'] if k.lower() in q)
    score += min(0.3 * kw_hits, 0.6)
    # Description word overlap: small bonus
    desc_words = set(wf['description'].lower().split())
    q_words = set(q.split())
    overlap = desc_words & q_words
    score += min(0.05 * len(overlap), 0.2)
    # Tag match
    tag_hits = sum(1 for t in wf['tags'] if t.lower() in q)
    score += min(0.1 * tag_hits, 0.2)
    return min(score, 1.0)


def _ollama_classify(query: str, candidates: list[dict]) -> Optional[dict]:
    """Use Ollama fast_model to pick best match. Returns dict or None on failure."""
    fast = DEFAULT_CAPABILITIES.get('fast_model', {})
    if fast.get('provider') != 'ollama':
        return None
    model = fast.get('model', 'qwen2.5:7b-instruct')
    candidate_summaries = "\n".join(
        f"  {i+1}. id={c['id']} | desc={c['description'][:120]} | keywords={c['trigger_keywords']}"
        for i, c in enumerate(candidates)
    )
    prompt = (
        f"You are a workflow router. The user's query is:\n\n{query}\n\n"
        f"Available workflows:\n{candidate_summaries}\n\n"
        f"Pick the best-matching workflow. Respond with ONLY a JSON object: "
        f'{{"index": <1-based number>, "confidence": <0.0-1.0>, "reasoning": "<one sentence>"}}.'
    )
    try:
        resp = requests.post(
            "http://localhost:11434/api/chat",
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
                "format": "json",
            },
            timeout=30,
        )
        if resp.status_code != 200:
            return None
        data = resp.json()
        content = data.get('message', {}).get('content', '')
        parsed = json.loads(content)
        idx = parsed.get('index', 0)
        if not (1 <= idx <= len(candidates)):
            return None
        return {
            "matched": candidates[idx - 1],
            "confidence": float(parsed.get('confidence', 0.5)),
            "reasoning": parsed.get('reasoning', ''),
        }
    except Exception as e:
        logger.warning("Ollama classify failed, falling back to heuristic: %s", e)
        return None


def route(query: str, input_data: Optional[dict] = None, execute: bool = True) -> dict:
    """Route a natural-language query to the best-matching workflow and optionally execute it.

    Args:
        query: Natural-language query.
        input_data: Optional input dict to pass to the workflow.
        execute: If True (default), execute the matched workflow. If False, return match only.

    Returns:
        {
            "matched_workflow_id": str,
            "matched_workflow_path": str,
            "confidence": float,
            "reasoning": str,
            "candidates_considered": int,
            "run_result": dict | None,
        }
    """
    workflows = discover_workflows()
    if not workflows:
        return {"error": "no workflows found", "matched_workflow_id": None}

    # 1) Ollama classifier first
    llm_pick = _ollama_classify(query, workflows)
    if llm_pick and llm_pick['confidence'] >= 0.5:
        matched = llm_pick['matched']
        confidence = llm_pick['confidence']
        reasoning = f"ollama: {llm_pick['reasoning']}"
    else:
        # 2) Heuristic fallback
        scored = [(wf, _keyword_score(query, wf)) for wf in workflows]
        scored.sort(key=lambda x: x[1], reverse=True)
        matched = scored[0][0]
        confidence = scored[0][1]
        reasoning = f"heuristic: top score {confidence:.2f}"

    out = {
        "matched_workflow_id": matched['id'],
        "matched_workflow_path": matched['path'],
        "confidence": confidence,
        "reasoning": reasoning,
        "candidates_considered": len(workflows),
        "run_result": None,
    }

    if execute and confidence >= 0.3:
        try:
            res = run_workflow(matched['path'], input_data=input_data or {}, actor='router')
            out['run_result'] = {
                "output": str(res.get('output', ''))[:2000],
                "elapsed": res.get('elapsed'),
                "step_count": len(res.get('steps', [])),
            }
        except Exception as e:
            out['run_result'] = {"error": str(e)[:300]}

    return out
