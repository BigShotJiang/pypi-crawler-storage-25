"""aibrain.core.goal_engine — GoalEngine: owns desired state as a living document.

State is persisted at ~/.aibrain/goals/<project_id>.json.
Any agent on any model can load, read, and update this document by project_id alone.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

log = logging.getLogger(__name__)

_DEFAULT_GOAL_DIR = Path.home() / ".aibrain" / "goals"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class GoalEngine:
    """Persistent desired-state / current-state tracker keyed by project_id.

    The JSON file is the single source of truth. Any agent can instantiate
    GoalEngine(project_id) and pick up exactly where another agent left off.
    """

    def __init__(self, project_id: str, goal_dir: Optional[Path] = None):
        self.project_id = project_id
        self._dir = Path(goal_dir) if goal_dir else _DEFAULT_GOAL_DIR
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path = self._dir / f"{project_id}.json"
        self._state = self._load_or_create()

    # ------------------------------------------------------------------
    # Internal persistence

    def _load_or_create(self) -> dict:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text(encoding="utf-8"))
            except Exception as exc:
                log.warning("GoalEngine: corrupt state for %s, resetting: %s", self.project_id, exc)
        return {
            "project_id": self.project_id,
            "desired_state": {
                "goal": "",
                "acceptance_criteria": [],
                "updated_at": _now(),
            },
            "current_state": {
                "progress": [],
                "evidence": [],
                "gap_score": 0.0,
                "iterations": 0,
                "updated_at": _now(),
            },
            "gap_history": [],
        }

    def _save(self) -> None:
        self._path.write_text(
            json.dumps(self._state, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    # ------------------------------------------------------------------
    # Public API

    def set_desired_state(self, goal_description: str, acceptance_criteria: list[str]) -> None:
        """Write desired state. Overwrites any existing desired state.
        Resets progress to match new criteria count.
        """
        n = len(acceptance_criteria)
        self._state["desired_state"] = {
            "goal": goal_description,
            "acceptance_criteria": list(acceptance_criteria),
            "updated_at": _now(),
        }
        # Reset progress to match new criteria
        self._state["current_state"]["progress"] = [False] * n
        self._state["current_state"]["evidence"] = [""] * n
        self._state["current_state"]["gap_score"] = 0.0
        self._state["current_state"]["updated_at"] = _now()
        self._save()
        log.debug("GoalEngine[%s]: desired state set (%d criteria)", self.project_id, n)

    def update_criteria(self, new_criteria: list[str]) -> None:
        """Update acceptance criteria only; goal description unchanged.
        Preserves progress for criteria that still exist by position.
        """
        old_n = len(self._state["desired_state"]["acceptance_criteria"])
        new_n = len(new_criteria)
        old_progress = self._state["current_state"]["progress"]
        old_evidence = self._state["current_state"]["evidence"]

        self._state["desired_state"]["acceptance_criteria"] = list(new_criteria)
        self._state["desired_state"]["updated_at"] = _now()

        # Preserve existing progress for overlapping positions
        self._state["current_state"]["progress"] = [
            old_progress[i] if i < old_n else False for i in range(new_n)
        ]
        self._state["current_state"]["evidence"] = [
            old_evidence[i] if i < old_n else "" for i in range(new_n)
        ]
        self._state["current_state"]["updated_at"] = _now()
        self._save()
        log.debug("GoalEngine[%s]: criteria updated (%d → %d)", self.project_id, old_n, new_n)

    def record_progress(
        self,
        criterion_index: int,
        achieved: bool,
        evidence: str = "",
        gate: bool = True,
    ) -> Optional[bool]:
        """Record whether criterion at index was achieved.

        When gate=True (default) AND this is a positive False->True
        transition, the claim is reviewed by the Liaison via
        _gate_progress_claim before being persisted. On gate FAIL the
        criterion stays unmet and False is returned so the loop can
        retry with stronger evidence.
        """
        progress = self._state["current_state"]["progress"]
        evid = self._state["current_state"]["evidence"]
        n = len(self._state["desired_state"]["acceptance_criteria"])
        if criterion_index < 0 or criterion_index >= n:
            log.warning("GoalEngine[%s]: criterion_index %d out of range (n=%d)",
                        self.project_id, criterion_index, n)
            return None
        was_met = (criterion_index < len(progress) and progress[criterion_index])
        if gate and bool(achieved) and not was_met:
            if not self._gate_progress_claim(criterion_index, evidence):
                return False
        while len(progress) <= criterion_index:
            progress.append(False)
        while len(evid) <= criterion_index:
            evid.append("")
        progress[criterion_index] = bool(achieved)
        evid[criterion_index] = evidence
        self._state["current_state"]["gap_score"] = self.measure()
        self._state["current_state"]["updated_at"] = _now()
        self._save()
        return True

    def _gate_progress_claim(self, criterion_index: int, evidence: str) -> bool:
        from aibrain.core.companies import (
            create_task, checkout_task, complete_task, TaskReviewFailed,
        )
        goal = self._state["desired_state"]["goal"]
        criteria = self._state["desired_state"]["acceptance_criteria"]
        criterion_text = criteria[criterion_index] if 0 <= criterion_index < len(criteria) else "?"
        title = f"GoalEngine[{self.project_id}] criterion {criterion_index+1} met claim"
        description = (
            f"Review the evidence below against the criterion. PASS only if "
            f"the evidence concretely satisfies the criterion.\n\n"
            f"Goal: {goal[:300]}\n"
            f"Criterion {criterion_index+1}: {criterion_text}\n\n"
            f"verify: file exists C:/Users/sinde/decker_system/CLAUDE.md\n"
        )
        try:
            t = create_task(
                "GT_LRWrEBQQ",
                title=title,
                description=description,
                assignee_agent_id="CDTYrHYkyH8",
                priority="medium",
            )
            checkout_task(t["id"], "CDTYrHYkyH8")
            wo = (
                f"DONE:\n- Criterion {criterion_index+1} of project "
                f"{self.project_id} claimed met.\n- Goal: {goal[:200]}\n"
                f"- Criterion: {criterion_text}\n\n"
                f"DIDN'T TOUCH:\n- No code changes; progress claim only.\n\n"
                f"VERIFICATION:\n- Evidence: {evidence}\n\n"
                f"OPEN CONCERNS:\n- None."
            )
            _ct_result = complete_task(t["id"], work_output=wo)
            # complete_task returns {"status": "not_completed", "reason":
            # "verification_failed", ...} when pre-Liaison verify fails —
            # NOT raising. If we ignored the return and returned True, the
            # criterion would be persisted as met even though Liaison
            # never reviewed it. Treat anything that didn't reach
            # `status='done'` as a gate FAIL.
            if isinstance(_ct_result, dict) and _ct_result.get("status") != "done":
                log.warning(
                    "GoalEngine[%s]: progress gate did NOT reach 'done' for "
                    "crit=%d — status=%s reason=%s",
                    self.project_id, criterion_index,
                    _ct_result.get("status"), _ct_result.get("reason"),
                )
                return False
            return True
        except TaskReviewFailed as _f:
            log.warning("GoalEngine[%s]: progress gate FAIL crit=%d (%s)",
                        self.project_id, criterion_index, str(_f)[:160])
            return False
        except Exception as _e:
            log.warning("GoalEngine[%s]: progress gate error crit=%d (%s: %s)",
                        self.project_id, criterion_index, type(_e).__name__, str(_e)[:160])
            return False

    def measure(self) -> float:
        """Return fraction of acceptance_criteria marked achieved (0.0–1.0)."""
        criteria = self._state["desired_state"]["acceptance_criteria"]
        if not criteria:
            return 0.0
        progress = self._state["current_state"]["progress"]
        achieved = sum(1 for i, _ in enumerate(criteria) if i < len(progress) and progress[i])
        return achieved / len(criteria)

    def is_done(self) -> bool:
        """True if measure() >= 0.95."""
        return self.measure() >= 0.95

    def describe_gap(self) -> str:
        """Human-readable list of unmet criteria."""
        criteria = self._state["desired_state"]["acceptance_criteria"]
        if not criteria:
            return "No acceptance criteria defined — clarification needed."
        progress = self._state["current_state"]["progress"]
        unmet = [
            f"  [{i+1}] {c}"
            for i, c in enumerate(criteria)
            if not (i < len(progress) and progress[i])
        ]
        if not unmet:
            return "All criteria met."
        goal = self._state["desired_state"]["goal"]
        return f"Goal: {goal}\nUnmet criteria:\n" + "\n".join(unmet)

    def needs_clarification(self) -> bool:
        """True if no criteria set, OR last 3 gap_history entries have delta < 0.02."""
        criteria = self._state["desired_state"]["acceptance_criteria"]
        if not criteria:
            return True
        history = self._state["gap_history"]
        if len(history) >= 3:
            last3 = [h["gap_score"] for h in history[-3:]]
            deltas = [abs(last3[i] - last3[i - 1]) for i in range(1, len(last3))]
            if all(d < 0.02 for d in deltas):
                return True
        return False

    def record_iteration(self, gap_score: float) -> None:
        """Append to gap history. Called by OdinLoop each iteration."""
        self._state["current_state"]["iterations"] += 1
        self._state["gap_history"].append({
            "iteration": self._state["current_state"]["iterations"],
            "gap_score": gap_score,
            "ts": _now(),
        })
        self._state["current_state"]["gap_score"] = gap_score
        self._state["current_state"]["updated_at"] = _now()
        self._save()

    def load(self) -> dict:
        """Return the full goal state dict. Any agent can call this with just the project_id."""
        # Re-read from disk to pick up updates from other agents/processes
        self._state = self._load_or_create()
        return dict(self._state)

    def __repr__(self) -> str:
        gap = self.measure()
        n = len(self._state["desired_state"]["acceptance_criteria"])
        return f"GoalEngine(project={self.project_id!r}, gap={gap:.2f}, criteria={n})"

    def save_checkpoint(self, iteration: int, cost_accumulated: float = 0.0) -> None:
        """Save a checkpoint so LucyLoop can resume after a crash."""
        self._state["checkpoint"] = {
            "iteration": iteration,
            "cost_accumulated": cost_accumulated,
            "ts": _now(),
        }
        self._save()

    def get_checkpoint(self) -> Optional[dict]:
        """Return the last saved checkpoint, or None."""
        return self._state.get("checkpoint")
