"""_remote_liaison_caller_scaffold.py � F-DEEP-EVENT-HANDLER-SCAFFOLD-1
Interface-only scaffold for event-driven remote Liaison.
Underscore-prefix: no implementation yet. Neuro wires to remote_liaison.py.
"""
import logging, threading, time, uuid
from typing import Callable

log = logging.getLogger("aibrain.remote_liaison_caller")
_pending_requests: dict = {}
_lock = threading.Lock()
_poller_started = False

def publish_liaison_request_async(task_id: str, work_output: str, on_verdict_callback, timeout_s: int = 360) -> str:
    request_id = str(uuid.uuid4())
    with _lock: _pending_requests[task_id] = on_verdict_callback
    _ensure_poller()
    log.debug("Liaison request %s for task %s", request_id, task_id)
    return request_id

def _ensure_poller():
    global _poller_started
    if _poller_started: return
    _poller_started = True
    t = threading.Thread(target=_poller_loop, daemon=True, name="liaison-poller"); t.start()

def _poller_loop():
    while True: time.sleep(10)

def _on_verdict_received(event: dict):
    payload = event.get('payload', {})
    task_id = payload.get('task_id', '')
    callback = _pending_requests.pop(task_id, None)
    if callback:
        try: callback(payload.get('verdict','FAIL'), float(payload.get('score',0)), payload.get('critique',''))
        except Exception as e: log.error('Verdict callback failed: %s', e)
