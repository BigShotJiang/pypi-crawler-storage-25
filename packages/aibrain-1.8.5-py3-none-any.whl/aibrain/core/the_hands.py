import ast
import asyncio
import dataclasses
import datetime
import json
import logging
import os
import re
import shlex
import subprocess
import sys
import requests
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    from playwright.async_api import async_playwright, Page, Browser
    _PLAYWRIGHT_AVAILABLE = True
except ImportError:
    async_playwright = None  # type: ignore
    Page = None              # type: ignore
    Browser = None           # type: ignore
    _PLAYWRIGHT_AVAILABLE = False

logger = logging.getLogger(__name__)

HANDS_HEADLESS = os.getenv("HANDS_HEADLESS", "1") == "1"

# SA-2026-002 F-20: AIBRAIN_ROOT for path confinement on file verbs (read_file/write_file/image).
class _ExternalMCPClient:
    """Minimal stdio JSON-RPC MCP client so Lucy can reach configured
    external MCP servers (playwright / n8n / desktop-control / ...).

    Spawn-per-call by design: leak-free and simple (correctness over
    speed). Never raises into the caller — returns {ok, result|error}.
    Tool routing: explicit server dict, or mcp__<server>__<tool>
    namespacing, or fuzzy server-name match from the active Claude config.
    """

    _CONFIG_PATHS = [
        os.path.expanduser("~/.claude-sindecker/.mcp.json"),
        os.path.expanduser("~/.claude.json"),
        os.path.expanduser("~/aibrain/.mcp.json"),
    ]

    @classmethod
    def _servers(cls) -> dict:
        servers: dict = {}
        for p in cls._CONFIG_PATHS:
            try:
                if not os.path.isfile(p):
                    continue
                d = json.load(open(p, encoding="utf-8"))
                s = d.get("mcpServers") or (d.get("mcp", {}) or {}).get("servers") or {}
                for k, v in s.items():
                    if k not in servers and isinstance(v, dict) and v.get("command"):
                        servers[k] = {"command": v["command"],
                                      "args": v.get("args", []),
                                      "env": v.get("env")}
            except Exception:
                continue
        return servers

    def call(self, tool_name: str, params: dict, server=None,
             timeout: int = 45) -> dict:
        srv_name, tname = server, tool_name
        if not isinstance(server, dict) and isinstance(tool_name, str) \
                and tool_name.startswith("mcp__"):
            parts = tool_name.split("__", 2)
            if len(parts) == 3:
                srv_name, tname = parts[1], parts[2]
        if isinstance(server, dict):
            spec = server
        else:
            servers = self._servers()
            spec = servers.get(srv_name) if srv_name else None
            if spec is None and srv_name:
                for k, v in servers.items():
                    if srv_name in k or k in srv_name:
                        spec = v
                        break
            if spec is None:
                return {"ok": False,
                        "error": f"no configured MCP server for '{tool_name}' "
                                 f"(use mcp__<server>__<tool>; servers: "
                                 f"{list(servers)})"}
        return self._rpc(spec, tname, params, timeout)

    def _rpc(self, spec: dict, tname: str, params: dict, timeout: int) -> dict:
        import time as _t
        proc = None
        try:
            env = dict(os.environ)
            if spec.get("env"):
                env.update(spec["env"])
            # Resolve the command via PATH/PATHEXT. A bare name like "npx"
            # is "npx.CMD" on Windows; subprocess.Popen without shell does
            # NOT apply PATHEXT for bare names, so the raw spec value
            # FileNotFoundErrors ("npx isn't resolving"). shutil.which()
            # applies PATHEXT and returns the real executable cross-platform.
            import shutil as _sh
            _cmd0 = _sh.which(spec["command"], path=env.get("PATH")) \
                or _sh.which(spec["command"]) or spec["command"]
            proc = subprocess.Popen(
                [_cmd0, *spec.get("args", [])],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, text=True, bufsize=1, env=env)

            def _send(obj):
                proc.stdin.write(json.dumps(obj) + "\n")
                proc.stdin.flush()

            def _recv(want_id):
                t0 = _t.time()
                while _t.time() - t0 < timeout:
                    line = proc.stdout.readline()
                    if not line:
                        return None
                    line = line.strip()
                    if not line or not line.startswith("{"):
                        continue
                    try:
                        m = json.loads(line)
                    except Exception:
                        continue
                    if m.get("id") == want_id:
                        return m
                return None

            _send({"jsonrpc": "2.0", "id": 1, "method": "initialize",
                   "params": {"protocolVersion": "2024-11-05",
                              "capabilities": {},
                              "clientInfo": {"name": "lucy", "version": "1"}}})
            if _recv(1) is None:
                return {"ok": False, "error": "MCP initialize timeout/no response"}
            _send({"jsonrpc": "2.0", "method": "notifications/initialized",
                   "params": {}})
            _send({"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                   "params": {"name": tname, "arguments": params or {}}})
            resp = _recv(2)
            if resp is None:
                return {"ok": False, "error": f"MCP tools/call timeout ({tname})"}
            if "error" in resp:
                return {"ok": False, "error": resp["error"]}
            return {"ok": True, "result": resp.get("result")}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        finally:
            if proc:
                try:
                    if proc.stdin:
                        proc.stdin.close()
                except Exception:
                    pass
                try:
                    proc.terminate()
                except Exception:
                    pass
                try:
                    proc.wait(timeout=5)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass


# F-USER-PROJECT-ROOT-1: resolve from env/config/cwd, not __file__
# (wheel installs put the_hands.py deep in site-packages, not project root)
def _resolve_root() -> str:
    import json
    root = os.environ.get("AIBRAIN_ROOT", "")
    if not root:
        cfg = os.path.expanduser("~/.aibrain/config.json")
        if os.path.exists(cfg):
            try:
                with open(cfg, encoding="utf-8") as f:
                    root = json.load(f).get("aibrain_root", "")
            except Exception:
                pass
    if not root:
        root = os.getcwd()
    if not root:
        root = os.path.expanduser("~/aibrain")
    return root

AIBRAIN_ROOT = _resolve_root()

# v1.6.1: USER_DATA_ROOT — user data directory for agent workdirs, goals, specs.
# Must be writable by Lucy and fleet agents. Deny-list covers ~/.aibrain/keys only.
USER_DATA_ROOT = os.path.expanduser("~/.aibrain")

# F-LUCY-FULL-ACCESS-1: additional allowed roots from env var
_ALLOWED_ROOTS = [os.path.expanduser(p.strip()) for p in
    os.environ.get('AIBRAIN_ALLOWED_ROOTS', '').split(';') if p.strip()]

# SA-2026-002 F-20: deny-list of path prefixes the file verbs MUST NOT touch.
# Resolved against user-home for ~-prefixed entries; absolute for repo-internal entries.
_HANDS_PATH_DENY_PREFIXES = (
    os.path.expanduser("~/.ssh"),
    os.path.expanduser("~/.decker_env"),
    os.path.expanduser("~/.aws"),
    os.path.expanduser("~/.config"),
    os.path.expanduser("~/.gnupg"),
    os.path.expanduser("~/.aibrain/keys"),  # signing key only — agent workdirs (~/.aibrain/agents/, ~/.aibrain/goals/, etc.) MUST remain writable
    os.path.join(AIBRAIN_ROOT, ".git", "hooks"),
    os.path.join(AIBRAIN_ROOT, ".git", "config"),
)


# SA-2026-002 F-14: provider API keys / secrets that MUST NOT inherit into Hands
# subprocess children. Mirror of F-22 _MCP_STRIP_ENV_KEYS — kept separate so Hands
# and MCP can evolve independently if needed.
_HANDS_STRIP_ENV_KEYS = frozenset({
    "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPSEEK_API_KEY",
    "GEMINI_API_KEY", "KIMI_API_KEY", "MOONSHOT_API_KEY",
    "AIBRAIN_LICENSE_KEY", "AIBRAIN_SIGNING_KEY",
    "BROKER_TOKEN", "TELEGRAM_TOKEN", "GITHUB_PAT", "SINDECKER_PAT",
    "DEEP_BOT_TOKEN", "PIXEL_BOT_TOKEN",
    "GMAIL_APP_PASSWORD", "SINDECKER_APP_PASSWORD",
    "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
    "GH_TOKEN", "NPM_TOKEN", "PYPI_TOKEN",
})


def _hands_safe_env() -> dict:
    """SA-2026-002 F-14: return os.environ minus _HANDS_STRIP_ENV_KEYS."""
    return {k: v for k, v in os.environ.items() if k not in _HANDS_STRIP_ENV_KEYS}


# SA-2026-002 F-29: hosts known to be used for stealth exfil. Hands navigate verb
# refuses to load these. Not exhaustive — defense-in-depth, not a perimeter.
_HANDS_NAVIGATE_DENY_HOSTS = frozenset({
    "pastebin.com", "paste.ee", "hastebin.com", "ghostbin.com",
    "requestbin.com", "requestbin.net", "ngrok.io", "ngrok.app",
    "transfer.sh", "file.io", "wormhole.app", "send.bitwarden.com",
    "0x0.st", "anonfiles.com", "bashupload.com", "tmpfiles.org",
    "pipedream.net", "webhook.site", "hookbin.com",
})

# SA-2026-002 F-29: schemes Hands will not navigate to.
_HANDS_NAVIGATE_DENY_SCHEMES = frozenset({"file", "data", "javascript", "ftp", "gopher"})


def _validate_navigate_url(url: str) -> tuple:
    """SA-2026-002 F-29: validate a URL before Hands navigates to it.

    Returns (ok, reason). Fail-closed on any exception.
    """
    try:
        if not url or not isinstance(url, str):
            return False, "empty or non-string url"
        from urllib.parse import urlparse as _urlparse
        parsed = _urlparse(url)
        scheme = (parsed.scheme or "").lower()
        if scheme in _HANDS_NAVIGATE_DENY_SCHEMES:
            return False, f"navigate scheme {scheme!r} blocked"
        if scheme not in ("http", "https"):
            return False, f"navigate scheme {scheme!r} not allowed (only http/https)"
        host = (parsed.hostname or "").lower()
        if not host:
            return False, "navigate url has no hostname"
        host_check = host[4:] if host.startswith("www.") else host
        if host_check in _HANDS_NAVIGATE_DENY_HOSTS:
            return False, f"navigate host {host!r} on stealth-exfil deny-list"
        for deny in _HANDS_NAVIGATE_DENY_HOSTS:
            if host.endswith("." + deny):
                return False, f"navigate host {host!r} on stealth-exfil deny-list (subdomain of {deny})"
        return True, "ok"
    except Exception as _e:
        return False, f"navigate url validation error (fail-closed): {_e}"


class Observation:
    """A snapshot of a web page or application state."""

    def __init__(self, content: str, title: str = "", url: str = "", elements: Optional[List[Dict[str, Any]]] = None):
        self.content = content
        self.title = title
        self.url = url
        self.elements = elements or []

    def __repr__(self):
        return f"Observation(url={self.url!r}, title={self.title!r}, content_len={len(self.content)})"


@dataclasses.dataclass
class RunResult:
    status: str              # done | max_steps | error
    steps: int
    goal: str
    final_observation: Optional[Observation]
    session_log: list
    error: Optional[str] = None


class BaseBackend:
    """Abstract backend for browser/computer-use interactions."""

    async def start(self):
        raise NotImplementedError

    async def stop(self):
        raise NotImplementedError

    async def navigate(self, url: str) -> dict:
        raise NotImplementedError

    async def click(self, selector: str) -> dict:
        raise NotImplementedError

    async def type_text(self, selector: str, text: str) -> dict:
        raise NotImplementedError

    async def get_content(self) -> str:
        raise NotImplementedError

    async def get_title(self) -> str:
        raise NotImplementedError

    async def get_url(self) -> str:
        raise NotImplementedError

    async def screenshot(self) -> bytes:
        raise NotImplementedError

    async def execute_script(self, script: str) -> Any:
        raise NotImplementedError


class PlaywrightBackend(BaseBackend):
    """Playwright-based browser backend. Requires the 'browser' extra: pip install aibrain[browser]."""

    def __init__(self, headless: bool = True):
        if not _PLAYWRIGHT_AVAILABLE:
            raise RuntimeError(
                "Playwright is not installed. Install it with: pip install aibrain[browser] "
                "then run: playwright install chromium"
            )
        self.headless = headless
        self._browser = None
        self._context = None
        self._page = None

    async def start(self):
        self._pw = await async_playwright().start()
        self._browser = await self._pw.chromium.launch(headless=self.headless)
        self._context = await self._browser.new_context()
        self._page = await self._context.new_page()
        logger.info("PlaywrightBackend started (headless=%s)", self.headless)

    async def stop(self):
        if self._browser:
            await self._browser.close()
        if hasattr(self, '_pw'):
            await self._pw.stop()
        logger.info("Playwright backend stopped")

    async def navigate(self, url: str) -> dict:
        if not self._page:
            raise RuntimeError("Backend not started")
        response = await self._page.goto(url, wait_until="domcontentloaded")
        return {"success": response is not None and response.ok, "status": response.status if response else None, "url": self._page.url}

    async def click(self, selector: str) -> dict:
        if not self._page:
            raise RuntimeError("Backend not started")
        try:
            await self._page.click(selector, timeout=5000)
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def type_text(self, selector: str, text: str) -> dict:
        if not self._page:
            raise RuntimeError("Backend not started")
        try:
            await self._page.fill(selector, text, timeout=5000)
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def get_content(self) -> str:
        if not self._page:
            raise RuntimeError("Backend not started")
        return await self._page.content()

    async def get_title(self) -> str:
        if not self._page:
            raise RuntimeError("Backend not started")
        return await self._page.title()

    async def get_url(self) -> str:
        if not self._page:
            raise RuntimeError("Backend not started")
        return self._page.url

    async def screenshot(self) -> bytes:
        if not self._page:
            raise RuntimeError("Backend not started")
        return await self._page.screenshot()

    async def execute_script(self, script: str) -> Any:
        if not self._page:
            raise RuntimeError("Backend not started")
        return await self._page.evaluate(script)


class ComputerUseBackend(BaseBackend):
    """Anthropic Computer Use backend (stub for future integration)."""

    def __init__(self, display_width: int = 1024, display_height: int = 768):
        self.display_width = display_width
        self.display_height = display_height
        self._started = False

    async def start(self):
        self._started = True
        logger.info("ComputerUse backend started (stub)")

    async def stop(self):
        self._started = False
        logger.info("ComputerUse backend stopped")

    async def navigate(self, url: str) -> dict:
        return {"success": False, "error": "ComputerUse backend does not support direct navigation"}

    async def click(self, selector: str) -> dict:
        return {"success": False, "error": "ComputerUse backend does not support CSS selectors"}

    async def type_text(self, selector: str, text: str) -> dict:
        return {"success": False, "error": "ComputerUse backend does not support CSS selectors"}

    async def get_content(self) -> str:
        return ""

    async def get_title(self) -> str:
        return ""

    async def get_url(self) -> str:
        return ""

    async def screenshot(self) -> bytes:
        return b""

    async def execute_script(self, script: str) -> Any:
        return None


class ToolExecutorBackend(BaseBackend):
    """Backend that executes actions via a tool-executor function (for sandbox environments)."""

    def __init__(self, tool_executor: Callable):
        self._executor = tool_executor
        self._started = False

    async def start(self):
        self._started = True
        logger.info("ToolExecutor backend started")

    async def stop(self):
        self._started = False
        logger.info("ToolExecutor backend stopped")

    async def navigate(self, url: str) -> dict:
        return await self._executor("navigate", {"url": url})

    async def click(self, selector: str) -> dict:
        return await self._executor("click", {"selector": selector})

    async def type_text(self, selector: str, text: str) -> dict:
        return await self._executor("type", {"selector": selector, "text": text})

    async def get_content(self) -> str:
        result = await self._executor("get_content", {})
        return result.get("content", "") if isinstance(result, dict) else ""

    async def get_title(self) -> str:
        result = await self._executor("get_title", {})
        return result.get("title", "") if isinstance(result, dict) else ""

    async def get_url(self) -> str:
        result = await self._executor("get_url", {})
        return result.get("url", "") if isinstance(result, dict) else ""

    async def screenshot(self) -> bytes:
        result = await self._executor("screenshot", {})
        return result.get("data", b"") if isinstance(result, dict) else b""

    async def execute_script(self, script: str) -> Any:
        result = await self._executor("execute_script", {"script": script})
        return result.get("result") if isinstance(result, dict) else None


class Hands:
    """The Hands agent: observes, plans, acts, and verifies in a loop.

    This is the outer agentic execution loop driver. It takes a goal,
    observes the environment, plans actions, executes them, and verifies
    progress until the goal is achieved or max steps are reached.
    """

    # SA-2026-002 / F-01 fix: explicit allow-list of permitted top-level binaries
    # for the bash/execute/shell verbs. Anything not on this list is rejected.
    # Removed shell=True; commands now run through shlex.split + arg-list form.
    _ALLOWED_BINARIES = frozenset({
        # Read-only inspection
        "ls", "dir", "pwd", "cat", "type", "head", "tail", "wc", "find",
        "where", "which", "stat", "file",
        # Search
        "grep", "findstr", "rg", "ack",
        # Text processing (read-only on stdout)
        "sort", "uniq", "awk", "sed", "jq", "cut", "tr", "diff",
        # VCS (git is the most-needed here — git itself has its own command surface,
        # but allow it; further hardening could allow-list git subcommands too)
        "git",
        # Python tooling
        "python", "python3", "pip", "pipx", "uv", "pytest", "ruff",
        "mypy", "black", "bandit",
        # Node tooling (some agents shell to npm/npx)
        "node", "npm", "npx", "yarn",
        # File ops (constrained to working_dir at higher level)
        "mkdir", "cp", "mv", "echo",
        # Build / compile (legitimate dev work)
        "make", "cargo", "go",
        # Read-only diagnostic binaries — F-LUCY-DESANDBOX-1-A (2026-05-14):
        # benign system-info binaries Lucy needs to introspect her runtime
        # without escalation or state change. All return string output only.
        "hostname", "whoami", "date", "env", "printenv", "uname", "id",
        "basename", "dirname", "realpath", "readlink",
        # Windows cmd equivalents (.exe stripped before lookup)
        "ver", "set",
        # F-LUCY-DESANDBOX-2 (2026-05-15): dev-environment binaries Lucy needs
        # for real local development work. Decker is sole operator, controlled
        # machine — the prior network/dev-tool deny was over-restrictive for
        # the actual threat model. Trust expanded, destructive patterns retained.
        "docker", "docker-compose", "kubectl", "podman", "compose",
        "curl", "wget", "ssh", "scp", "sftp", "ftp", "nc", "netcat",
        "tar", "zip", "unzip", "gzip", "gunzip", "7z",
        "rsync", "psql", "mysql", "sqlite3", "redis-cli",
        "ping", "nslookup", "traceroute", "tracert", "netstat",
        "ps", "kill", "killall", "lsof", "df", "du", "free", "top",
        "tasklist", "schtasks", "powershell", "pwsh", "wmic",
    })

    # F-LUCY-DESANDBOX-2 (2026-05-15): SIMPLE RULE.
    # Code blocks ONLY the 4 host-destroying ops below (irreversible nuke).
    # Everything else passes. "Potentially damaging" stuff prompts the human
    # operator at the host layer (Claude Code PreToolUse) — not blocked by code.
    # Authorization = human only, never another agent.
    _DENY_CMD_PATTERNS: tuple = (
        re.compile(r"rm\s+-rf?\s+/\s*(?!\w)", re.I),                # rm -rf / (root)
        re.compile(r"\b(shutdown|reboot|halt|poweroff|init\s+0)\b", re.I),  # power off
        re.compile(r"\bmkfs\.", re.I),                              # format disk
        re.compile(r"\bdd\s+if=.*of=/dev/", re.I),                  # raw block-device write
    )

    # F-LUCY-DESANDBOX-2 (2026-05-15): SANDBOX OFF per Decker directive.
    # The python import/call denies caused friction for normal development
    # work (Lucy is running on Decker's sole-operator machine, not a
    # multi-tenant service). Empty sets = trust the operator. If a future
    # multi-tenant deployment needs gating, gate at the host process boundary,
    # not inside the agent runtime.
    _DENY_PYTHON_IMPORTS: frozenset = frozenset()
    _DENY_PYTHON_CALLS: frozenset = frozenset()

    @classmethod
    def _validate_shell_cmd(cls, cmd: str) -> Tuple[bool, str]:
        """SA-2026-002 / F-01 fix — bypass-resistant validator for bash/execute/shell.

        Returns (is_safe, reason). Reason is a human-readable rejection message
        (used as the action's `error` field) when is_safe=False.
        """
        if not cmd or not isinstance(cmd, str):
            return False, "no command provided"
        # 1. Full-string deny patterns (chaining, network, destructive, secrets)
        for pat in cls._DENY_CMD_PATTERNS:
            if pat.search(cmd):
                return False, f"blocked: pattern {pat.pattern!r} matched"
        # 2. Tokenise via shlex
        try:
            argv = shlex.split(cmd, posix=(os.name != "nt"))
        except ValueError as e:
            return False, f"command parse failed: {e}"
        if not argv:
            return False, "command parse produced no tokens"
        # 3. F-LUCY-DESANDBOX-2 (2026-05-15): SANDBOX OFF. The allow-list check
        #    was removed per Decker directive. Only deny patterns above gate
        #    the command. Allow-list (_ALLOWED_BINARIES) kept as historical
        #    reference but no longer enforced. The deny patterns catch the
        #    genuinely-destructive ops (rm -rf /, shutdown, mkfs, dd-to-dev,
        #    SQL DROP TABLE, forkbomb, secret-file reads).
        first = os.path.basename(argv[0]).lower()
        if first.endswith(".exe"):
            first = first[:-4]
        first_base = re.sub(r"\d+(\.\d+)?$", "", first)
        # SA-2026-002 F-10: python -c re-entry — close the bash-verb bypass of F-02 AST.
        # Allow-list passed because 'python' is on it, but 'python -c "<code>"' lets the
        # LLM ship arbitrary python that never sees F-02. Route the code arg through
        # _validate_python_code so the same denylist applies on both verb paths.
        # Note: on Windows, shlex.split with posix=False preserves the quote chars around
        # the -c arg, so we strip them before parsing — otherwise the code parses as a
        # string-literal expression (Constant) and slips past the import/call denylist.
        _is_python = (first_base == "python" or first == "python" or first == "py")
        if _is_python:
            for _idx, _tok in enumerate(argv[1:], start=1):
                if _tok == "-c" or _tok == "--command":
                    if _idx + 1 < len(argv):
                        _code_arg = argv[_idx + 1]
                        # Strip outer quotes left over by non-posix shlex
                        if len(_code_arg) >= 2 and _code_arg[0] == _code_arg[-1] and _code_arg[0] in ("'", '"'):
                            _code_arg = _code_arg[1:-1]
                        _ok_py, _py_reason = cls._validate_python_code(_code_arg)
                        if not _ok_py:
                            return False, f"python -c rejected: {_py_reason}"
                    else:
                        return False, "python -c requires a code argument"
                    break
        return True, ""

    @staticmethod
    def _confine_path(p: str, op: str) -> Tuple[bool, str]:
        """SA-2026-002 F-20: confine read_file/write_file/image to AIBRAIN_ROOT and reject deny-set.

        Returns (ok, reason). ok=True means safe to use; False means block with reason.
        Fail-closed: any exception in resolution is treated as block.
        """
        try:
            if not p or not isinstance(p, str):
                return False, "empty or non-string path"
            real = os.path.realpath(os.path.abspath(os.path.expanduser(p)))
            real_norm = real.replace("\\", "/").rstrip("/").lower()
            for deny in _HANDS_PATH_DENY_PREFIXES:
                deny_real = os.path.realpath(os.path.abspath(deny)).replace("\\", "/").rstrip("/").lower()
                if real_norm == deny_real or real_norm.startswith(deny_real + "/"):
                    return False, f"{op} blocked: path resolves into deny-set ({deny})"
            # v1.6.1: accept TWO roots — AIBRAIN_ROOT (package) + USER_DATA_ROOT (~/.aibrain)
            root_real = os.path.realpath(os.path.abspath(AIBRAIN_ROOT)).replace("\\", "/").rstrip("/").lower()
            user_real = os.path.realpath(os.path.abspath(USER_DATA_ROOT)).replace("\\", "/").rstrip("/").lower()
            ok = ((real_norm == root_real or real_norm.startswith(root_real + "/")) or
                  (real_norm == user_real or real_norm.startswith(user_real + "/")))
            if not ok:
                for ar in _ALLOWED_ROOTS:
                    ar_real = os.path.realpath(os.path.abspath(ar)).replace(os.sep, '/').rstrip('/').lower()
                    if real_norm == ar_real or real_norm.startswith(ar_real + '/'):
                        ok = True
                        break
            if not ok:
                return False, f"{op} blocked: path outside AIBRAIN_ROOT and ~/.aibrain ({real})"
            return True, "ok"
        except Exception as _e:
            return False, f"{op} confinement error (fail-closed): {_e}"

    @classmethod
    def _validate_python_code(cls, code: str) -> Tuple[bool, str]:
        """SA-2026-002 / F-02 fix — AST-parse and reject dangerous imports/calls.

        Returns (is_safe, reason).
        """
        if not code or not isinstance(code, str):
            return False, "no code provided"
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return False, f"python parse failed: {e}"
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    if top in cls._DENY_PYTHON_IMPORTS:
                        return False, f"blocked: import of {alias.name!r} not permitted"
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    top = node.module.split(".")[0]
                    if top in cls._DENY_PYTHON_IMPORTS:
                        return False, f"blocked: from {node.module!r} import not permitted"
            elif isinstance(node, ast.Call):
                func = node.func
                fname = None
                if isinstance(func, ast.Name):
                    fname = func.id
                elif isinstance(func, ast.Attribute):
                    fname = func.attr
                # SA-2026-002 F-11: Subscript indirection — __builtins__["eval"](...),
                # globals()["__import__"](...), locals()["exec"](...).
                elif isinstance(func, ast.Subscript):
                    _slice = func.slice
                    # Py3.9+ slice is the value directly; Py3.8 wraps in Index.
                    if hasattr(_slice, "value") and isinstance(_slice.value, ast.Constant):
                        _slice_val = _slice.value.value
                    elif isinstance(_slice, ast.Constant):
                        _slice_val = _slice.value
                    else:
                        _slice_val = None
                    if isinstance(_slice_val, str):
                        _container_name = None
                        _v = func.value
                        if isinstance(_v, ast.Name):
                            _container_name = _v.id
                        elif isinstance(_v, ast.Call) and isinstance(_v.func, ast.Name):
                            _container_name = _v.func.id
                        if _container_name in ("__builtins__", "globals", "locals", "vars"):
                            return False, f"blocked: subscript-indirected call via {_container_name!r}[{_slice_val!r}] not permitted"
                        if _slice_val in cls._DENY_PYTHON_CALLS:
                            return False, f"blocked: subscript indirection to {_slice_val!r} not permitted"
                # SA-2026-002 F-11: __import__ direct call.
                if fname == "__import__":
                    return False, "blocked: __import__ direct call not permitted"
                # SA-2026-002 F-11: getattr(<obj>, '<denied>')() — reject inner getattr
                # whose second arg is a string Constant matching a denied callable.
                if isinstance(func, ast.Call) and isinstance(func.func, ast.Name) and func.func.id == "getattr":
                    if len(func.args) >= 2:
                        _gattr_arg = func.args[1]
                        _gattr_val = None
                        if isinstance(_gattr_arg, ast.Constant) and isinstance(_gattr_arg.value, str):
                            _gattr_val = _gattr_arg.value
                        if _gattr_val in cls._DENY_PYTHON_CALLS:
                            return False, f"blocked: getattr indirection to {_gattr_val!r} not permitted"
                if fname in cls._DENY_PYTHON_CALLS:
                    return False, f"blocked: call to {fname!r} not permitted"
        return True, ""

    def __init__(
        self,
        task_id: str,
        sandbox: Any = None,
        execution_logger: Optional[Any] = None,
        ingestion_callback: Optional[Callable] = None,
        working_dir: Optional[str] = None,
    ):
        self.task_id = task_id
        self.sandbox = sandbox
        self.execution_logger = execution_logger
        self.ingestion_callback = ingestion_callback
        self._working_dir = working_dir or os.getenv('HANDS_WORKING_DIR') or os.getcwd()
        self._backend: Optional[BaseBackend] = None
        self._session_actions: List[Dict[str, Any]] = []
        self._started = False

    async def _ensure_started(self):
        """Lazily start the backend if not already started."""
        if self._started:
            return
        if self.sandbox is not None:
            # Sandbox environment: use ToolExecutor backend
            self._backend = ToolExecutorBackend(self.sandbox.tool_executor)
        else:
            # Local environment: use Playwright
            self._backend = PlaywrightBackend(headless=HANDS_HEADLESS)
        await self._backend.start()
        self._started = True

    async def close(self):
        """Async cleanup."""
        if self._backend:
            await self._backend.stop()
            self._started = False

    def close_sync(self):
        """Synchronous cleanup wrapper."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop and loop.is_running():
            import threading
            t = threading.Thread(target=lambda: asyncio.run(self.close()))
            t.start()
            t.join(timeout=10)
        else:
            asyncio.run(self.close())

    async def __aenter__(self):
        await self._ensure_started()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def observe(self, url: str = "") -> Observation:
        """Observe the current page or navigate to a URL and observe."""
        if not self._backend:
            raise RuntimeError("Backend not started. Call _ensure_started() first.")
        if url:
            await self._backend.navigate(url)
            await asyncio.sleep(1)  # Let the page settle
        content = await self._backend.get_content()
        title = await self._backend.get_title()
        current_url = await self._backend.get_url()
        obs = Observation(content=content, title=title, url=current_url)
        if self.ingestion_callback:
            try:
                self.ingestion_callback(obs)
            except Exception:
                logger.exception("Ingestion callback failed")
        return obs

    def plan(self, goal: str, context: dict = None) -> List[Dict[str, Any]]:
        """Generate a list of actions to achieve the goal given the current context.

        Step 11: Skill retrieval block â€” attempts to load relevant skills
        from the skill registry before falling back to heuristic planning.
        """
        # --- Skill retrieval block (Step 11) ---
        skills = []
        try:
            # Attempt to load skills from the registry if available
            from aibrain.skills.registry import get_skills_for_goal
            skills = get_skills_for_goal(goal)
        except ImportError:
            pass
        except Exception:
            logger.debug("Skill retrieval failed, falling back to heuristic planning", exc_info=True)

        if skills:
            # Compose actions from retrieved skills
            actions = []
            for skill in skills:
                actions.extend(skill.to_actions(context))
            return actions

        # --- LLM planning via DeepSeek ---
        AVAILABLE_VERBS = [
            "navigate", "click", "type", "extract", "screenshot",
            "wait", "bash", "python", "write_file", "read_file",
            "image", "mcp",
        ]
        VERB_DESCRIPTIONS = {
            "navigate": '{"verb": "navigate", "url": "https://..."}',
            "click": '{"verb": "click", "selector": "css-selector"}',
            "type": '{"verb": "type", "selector": "css-selector", "text": "content"}',
            "extract": '{"verb": "extract", "goal": "what to extract"}',
            "screenshot": '{"verb": "screenshot"}',
            "wait": '{"verb": "wait", "ms": 1000}',
            "bash": '{"verb": "bash", "cmd": "shell command"}',
            "python": '{"verb": "python", "code": "python code string"}',
            "write_file": '{"verb": "write_file", "path": "/path/to/file", "content": "text"}',
            "read_file": '{"verb": "read_file", "path": "/path/to/file"}',
            "image": '{"verb": "image", "path": "/path/to/image.png"}',
            "mcp": '{"verb": "mcp", "tool": "memory_store", "params": {"name": "...", "content": "..."}}',
        }
        system_prompt = (
            "You are a task planner for an autonomous agent. "
            "Given a goal, output a JSON array of action dicts. "
            "Each action must use one of the available verbs. "
            "Output ONLY a valid JSON array, no explanation."
        )
        verb_examples = "\n".join(f"  {v}: {VERB_DESCRIPTIONS[v]}" for v in AVAILABLE_VERBS)
        user_prompt = (
            f"Goal: {goal}\n\n"
            f"Context: {str(context)[:500]}\n\n"
            f"Available verbs and formats:\n{verb_examples}\n\n"
            "Output a JSON array of action dicts to achieve the goal."
        )
        try:
            from aibrain.core.companies import _deepseek_http_call
            result = _deepseek_http_call(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                thinking=False,
                reasoning_effort="high",
            )
            raw = result.get("content", "")
            # Extract JSON array from response
            import re as _re
            json_match = _re.search(r'\[.*?\]', raw, _re.DOTALL)
            if json_match:
                import json as _json
                actions = _json.loads(json_match.group(0))
                if actions and isinstance(actions, list):
                    return actions
        except Exception:
            logger.debug("LLM planning failed, falling back to heuristic", exc_info=True)

        # --- Heuristic fallback (kept as safety net) ---
        actions = []
        context = context or {}
        current_page = context.get("current_page", {})
        page_content = current_page.get("content", "")

        # If we have a URL context, try to navigate first
        if not page_content and context.get("start_url"):
            actions.append({"verb": "navigate", "url": context["start_url"]})
            return actions

        # Look for interactive elements in the page content
        if "login" in page_content.lower() or "sign in" in page_content.lower():
            actions.append({"verb": "type", "selector": "input[type='email'], input[name='email']", "text": "{{email}}"})
            actions.append({"verb": "type", "selector": "input[type='password']", "text": "{{password}}"})
            actions.append({"verb": "click", "selector": "button[type='submit'], input[type='submit']"})
        elif "search" in page_content.lower():
            actions.append({"verb": "type", "selector": "input[type='search'], input[name='q'], input[name='query']", "text": goal})
            actions.append({"verb": "click", "selector": "button[type='submit'], input[type='submit']"})
        elif "form" in page_content.lower():
            actions.append({"verb": "type", "selector": "input:not([type='hidden']):not([type='submit'])", "text": "{{input}}"})
            actions.append({"verb": "click", "selector": "button[type='submit'], input[type='submit']"})
        else:
            # Default: try to extract information from the page
            actions.append({"verb": "extract", "goal": goal})

        return actions

    _BACKEND_VERBS = {"navigate", "click", "type", "extract", "screenshot", "wait"}

    async def act(self, action: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single action and return the result."""
        verb = action.get("verb", "")
        if verb in self._BACKEND_VERBS and not self._backend:
            # Lazily start the execution backend instead of hard-failing. The
            # bridge/loop callers never call _ensure_started() explicitly;
            # _ensure_started() is idempotent (returns early if already
            # started), so this is safe and additive.
            await self._ensure_started()

        result = {"verb": verb, "success": False}

        try:
            if verb == "navigate":
                url = action.get("url", "")
                # SA-2026-002 F-29: deny stealth-exfil hosts + non-http(s) schemes.
                _ok_url, _url_reason = _validate_navigate_url(url)
                if not _ok_url:
                    result["error"] = _url_reason
                else:
                    nav_result = await self._backend.navigate(url)
                    result.update(nav_result)
            elif verb == "click":
                selector = action.get("selector", "")
                if selector:
                    click_result = await self._backend.click(selector)
                    result.update(click_result)
            elif verb == "type":
                selector = action.get("selector", "")
                text = action.get("text", "")
                if selector and text:
                    type_result = await self._backend.type_text(selector, text)
                    result.update(type_result)
            elif verb == "extract":
                content = await self._backend.get_content()
                result["success"] = True
                result["content"] = content[:2000]
            elif verb == "screenshot":
                data = await self._backend.screenshot()
                result["success"] = True
                result["data_length"] = len(data)
            elif verb == "wait":
                seconds = action.get("seconds", 1)
                await asyncio.sleep(min(seconds, 10))
                result["success"] = True
            elif verb in ("bash", "execute", "shell"):
                # SA-2026-002 / F-01 fix:
                #   1. Check full string against bypass-resistant deny patterns
                #      (chaining, network primitives, secret paths, destructive ops)
                #   2. Tokenise via shlex (NOT shell=True) — list-form only
                #   3. First token must be in _ALLOWED_BINARIES
                #   4. Each arg re-checked against deny patterns
                #   5. Run with shell=False — no shell interpretation
                cmd = action.get("cmd") or action.get("command") or action.get("text", "")
                ok, reason = self._validate_shell_cmd(cmd)
                if not ok:
                    result["error"] = reason
                else:
                    try:
                        argv = shlex.split(cmd, posix=(os.name != "nt"))
                    except ValueError as _se:
                        result["error"] = f"command parse failed: {_se}"
                        argv = None
                    if argv is not None:
                        try:
                            proc = subprocess.run(
                                argv, shell=False, capture_output=True,
                                text=True, timeout=30, cwd=self._working_dir,
                                env=_hands_safe_env(),  # SA-2026-002 F-14
                            )
                            result.update({
                                "success": proc.returncode == 0,
                                "stdout": proc.stdout, "stderr": proc.stderr,
                                "returncode": proc.returncode,
                            })
                        except subprocess.TimeoutExpired:
                            result["error"] = "timed out after 30s"
                        except FileNotFoundError:
                            result["error"] = f"binary not found: {argv[0]}"
            elif verb == "python":
                # SA-2026-002 / F-02 fix:
                #   1. AST-parse the supplied code (rejects syntax errors early)
                #   2. Walk AST — reject if any Import/ImportFrom names a denied
                #      module, or any Call invokes a denied builtin
                #   3. Run as -c arg-list (already shell=False; was the only
                #      reason F-02 was rated lower than F-01)
                code = action.get("code") or action.get("text", "")
                ok, reason = self._validate_python_code(code)
                if not ok:
                    result["error"] = reason
                else:
                    try:
                        proc = subprocess.run(
                            [sys.executable, "-c", code],
                            capture_output=True, text=True,
                            timeout=30, cwd=self._working_dir,
                            env=_hands_safe_env(),  # SA-2026-002 F-14
                        )
                        result.update({
                            "success": proc.returncode == 0,
                            "stdout": proc.stdout, "stderr": proc.stderr,
                            "returncode": proc.returncode,
                        })
                    except subprocess.TimeoutExpired:
                        result["error"] = "timed out after 30s"
            elif verb == "write_file":
                path = action.get("path") or action.get("url", "")
                content = action.get("content") or action.get("text", "")
                _ok_confine, _confine_reason = Hands._confine_path(path, "write_file")
                if not _ok_confine:
                    result["error"] = _confine_reason
                else:
                    try:
                        parent = os.path.dirname(os.path.abspath(path))
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        with open(path, "w", encoding="utf-8") as _f:
                            _f.write(content)
                        result.update({"success": True, "path": path, "bytes": len(content)})
                    except Exception as _e:
                        result["error"] = str(_e)
            elif verb == "read_file":
                path = action.get("path") or action.get("url", "")
                _ok_confine, _confine_reason = Hands._confine_path(path, "read_file")
                if not _ok_confine:
                    result["error"] = _confine_reason
                else:
                    try:
                        import threading as _threading
                        _READ_TIMEOUT = 10
                        _file_result: Dict[str, Any] = {}

                        def _do_read():
                            try:
                                with open(path, "r", encoding="utf-8", errors="replace") as _f:
                                    _file_result["content"] = _f.read()
                            except Exception as _re:
                                _file_result["error"] = str(_re)

                        _t = _threading.Thread(target=_do_read, daemon=True)
                        _t.start()
                        _t.join(timeout=_READ_TIMEOUT)
                        if _t.is_alive():
                            result["error"] = f"timed out after {_READ_TIMEOUT}s"
                        elif "error" in _file_result:
                            result["error"] = _file_result["error"]
                        else:
                            result.update({"success": True, "content": _file_result["content"], "path": path})
                    except Exception as _e:
                        result["error"] = str(_e)
            elif verb in ("image", "read_image", "view_image"):
                _img_path = action.get("path") or action.get("url") or action.get("file", "")
                if not _img_path:
                    result["error"] = "image verb requires 'path'"
                else:
                    _ok_confine, _confine_reason = Hands._confine_path(_img_path, "image")
                    if not _ok_confine:
                        result["error"] = _confine_reason
                    else:
                        try:
                            import base64 as _b64
                            import io as _io
                            try:
                                from PIL import Image as _PILImage
                                _pil_ok = True
                            except ImportError:
                                _pil_ok = False
                            if _pil_ok:
                                _img = _PILImage.open(_img_path)
                                _img.thumbnail((1024, 1024), _PILImage.LANCZOS)
                                _buf = _io.BytesIO()
                                _fmt = _img.format or "PNG"
                                _img.save(_buf, format=_fmt)
                                _raw = _buf.getvalue()
                                _media_type = f"image/{_fmt.lower()}"
                            else:
                                with open(_img_path, "rb") as _f:
                                    _raw = _f.read()
                                _ext = os.path.splitext(_img_path)[1].lower().lstrip(".")
                                _media_type = f"image/{_ext or 'png'}"
                            _img_b64 = _b64.b64encode(_raw).decode()
                            import anthropic as _anthropic
                            _ant = _anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
                            _resp = _ant.messages.create(
                                model="claude-haiku-4-5-20251001",
                                max_tokens=1024,
                                messages=[{"role": "user", "content": [
                                    {"type": "image", "source": {"type": "base64", "media_type": _media_type, "data": _img_b64}},
                                    {"type": "text", "text": "Describe this image in detail."},
                                ]}],
                            )
                            result.update({"success": True, "description": _resp.content[0].text, "path": _img_path})
                        except Exception as _img_e:
                            result["error"] = f"image error: {_img_e}"
            elif verb == "mcp":
                tool_name = action.get("tool", "")
                params = action.get("params", {})
                if not tool_name:
                    result["error"] = "mcp action missing 'tool'"
                else:
                    try:
                        from aibrain.mcp.server import _load_backend
                        _TOOL_MAP = {
                            "memory_store": "_tool_memory_store",
                            "memory_search": "_tool_memory_search",
                            "memory_recall": "_tool_memory_recall",
                            "memory_stats": "_tool_memory_stats",
                            "memory_ingest": "_tool_memory_ingest",
                        }
                        fn_name = _TOOL_MAP.get(tool_name)
                        if not fn_name:
                            # External MCP stdio client — reach configured
                            # servers (playwright/n8n/desktop-control/...).
                            # Memory tools are handled by _TOOL_MAP above; any
                            # other tool routes through a real MCP client now
                            # (was a dead hasattr(call_tool) check that always
                            # failed — the root of "playwright not installed").
                            try:
                                _ext = _ExternalMCPClient().call(tool_name, params)
                                if _ext.get("ok"):
                                    result.update({"success": True,
                                                   "tool": tool_name,
                                                   "result": _ext["result"]})
                                else:
                                    result["error"] = (f"mcp '{tool_name}': "
                                                       f"{_ext.get('error','unknown error')}")
                            except Exception as _dyn_e:
                                result["error"] = f"mcp tool '{tool_name}' failed: {_dyn_e}"
                        else:
                            import aibrain.mcp.server as _mcp_srv
                            backend = _load_backend()
                            tool_fn = getattr(_mcp_srv, fn_name)
                            tool_result = tool_fn(backend, params)
                            result.update({"success": True, "tool": tool_name, "result": tool_result})
                    except Exception as _mcp_e:
                        result["error"] = f"mcp error: {_mcp_e}"
            else:
                result["error"] = f"Unknown verb: {verb}"
        except Exception as e:
            result["success"] = False
            result["error"] = str(e)

        # Audit trail
        self._session_actions.append({"action": action, "result": result, "timestamp": datetime.datetime.utcnow().isoformat()})
        if self.execution_logger:
            try:
                self.execution_logger.log_action(self.task_id, action, result)
            except Exception:
                logger.exception("Execution logger failed")

        return result

    async def verify(self, goal: str, content: str) -> bool:
        return await self._llm_verify(goal, content)

    async def _llm_verify(self, goal: str, content: str) -> bool:
        if not content:
            return False
        try:
            from aibrain.core.companies import _deepseek_http_call
            result = _deepseek_http_call(
                system_prompt='You are a verification assistant. Answer YES or NO only.',
                user_prompt=(
                    f'Has the following goal been achieved based on the content?\n\n'
                    f'Goal: {goal}\n\nContent: {content[:2000]}'
                ),
                thinking=False,
                reasoning_effort="low",
            )
            answer = result.get('content', '').strip().upper()
            return answer.startswith('YES')
        except Exception:
            logger.debug('LLM verify fallback to keyword heuristic', exc_info=True)
            return self._keyword_verify(goal, content)

    def _keyword_verify(self, goal: str, content: str) -> bool:
        keywords = goal.lower().split()
        content_lower = content.lower()
        if not keywords:
            return False
        matches = sum(1 for kw in keywords if kw in content_lower)
        return (matches / len(keywords)) >= 0.6

    def dump_session_log(self) -> list:
        """Return the full session action log."""
        return list(self._session_actions)

    async def run(self, goal: str, start_url: str = "", max_steps: int = 20) -> RunResult:
        steps = 0
        obs: Optional[Observation] = None
        context: dict = {}
        try:
            await self._ensure_started()
            if start_url:
                obs = await self.observe(start_url)
                context["current_page"] = {"url": obs.url, "title": obs.title, "content": obs.content[:500]}
            while steps < max_steps:
                actions = self.plan(goal, context)
                if not actions:
                    break
                for action in actions:
                    result = await self.act(action)
                    steps += 1
                    if action.get("verb") == "navigate" and result.get("success"):
                        nav_url = action.get("url") or (obs.url if obs else "")
                        if nav_url:
                            obs = await self.observe(nav_url)
                            context["current_page"] = {"url": obs.url, "title": obs.title, "content": obs.content[:500]}
                    check_content = obs.content if obs else ""
                    if await self.verify(goal, check_content):
                        result = RunResult(status="done", steps=steps, goal=goal, final_observation=obs, session_log=self.dump_session_log())
                        try:
                            from aibrain.skills.registry import store_skill
                            winning_actions = [entry['action'] for entry in self._session_actions]
                            store_skill(goal, winning_actions, score=1.0)
                        except Exception:
                            logger.debug("Skill storage failed â€” run result unaffected", exc_info=True)
                        return result
                    if steps >= max_steps:
                        break
                context["_attempt"] = context.get("_attempt", 0) + 1
            return RunResult(status="max_steps", steps=steps, goal=goal, final_observation=obs, session_log=self.dump_session_log())
        except Exception as exc:
            return RunResult(status="error", steps=steps, goal=goal, final_observation=obs, session_log=self.dump_session_log(), error=str(exc))
