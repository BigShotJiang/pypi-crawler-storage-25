"""aibrain.core.catalog_router — CatalogRouter (namespace promotion policy gate).

Wraps ArtifactStore.promote_to_namespace with the curation_state policy matrix
mandated by Hands v1 spec ADR-004 + ADR-005.
"""

from __future__ import annotations
from typing import Optional, Dict, Tuple

from aibrain.core.artifact_store import ArtifactStore, ArtifactNotFoundError, ArtifactMetadata


class PromotionDeniedError(Exception):
    """Raised when a promote() call violates the namespace policy matrix."""
    pass


# (source_namespace, target_namespace) -> required source curation_state
# A missing entry means the promotion is unconditionally BLOCKED.
PROMOTION_MATRIX: Dict[Tuple[str, str], str] = {
    ('aibrain', 'rogue'): 'approved_for_replay',
    ('aibrain', 'paragon'): 'approved_for_replay',
    ('rogue', 'paragon'): 'approved_for_replay',
    ('paragon', 'rogue'): 'approved_for_replay',
    ('aibrain', 'marketplace'): 'approved_for_marketplace',
    ('paragon', 'marketplace'): 'approved_for_marketplace',
    # rogue -> marketplace is intentionally absent (red-team tools never go to marketplace)
    ('rogue', 'aibrain'): 'approved_for_export',
    ('paragon', 'aibrain'): 'approved_for_export',
    ('marketplace', 'aibrain'): 'approved_for_export',
}


class CatalogRouter:
    """Policy gate over ArtifactStore.promote_to_namespace."""

    def __init__(self, artifact_store: ArtifactStore):
        self.store = artifact_store

    def promote(
        self,
        artifact_id: str,
        source_namespace: str,
        target_namespace: str,
        new_artifact_id: Optional[str] = None,
    ) -> str:
        """Promote artifact across namespaces, gated on curation_state per the matrix.

        Returns the new artifact_id in the target namespace.
        Raises PromotionDeniedError on policy violation; ArtifactNotFoundError on missing source.
        """
        if source_namespace == target_namespace:
            raise PromotionDeniedError(
                f"same-namespace promotion is a no-op (source=target={source_namespace!r})"
            )

        key = (source_namespace, target_namespace)
        required_state = PROMOTION_MATRIX.get(key)
        if required_state is None:
            raise PromotionDeniedError(
                f"promotion {source_namespace!r} -> {target_namespace!r} is BLOCKED by policy"
            )

        # Fetch the source — raises ArtifactNotFoundError if missing
        src = self.store.get_artifact(artifact_id, source_namespace)

        if src.curation_state != required_state:
            raise PromotionDeniedError(
                f"promotion {source_namespace!r} -> {target_namespace!r} requires "
                f"source curation_state={required_state!r}, got curation_state={src.curation_state!r} "
                f"on artifact_id={artifact_id!r}"
            )

        # Policy passed — delegate the duplication to ArtifactStore. promote_to_namespace
        # always sets the new artifact's curation_state='quarantined' and links parent_artifact_id.
        return self.store.promote_to_namespace(
            artifact_id=artifact_id,
            source_namespace=source_namespace,
            target_namespace=target_namespace,
            new_artifact_id=new_artifact_id,
        )

    def can_promote(
        self,
        artifact_id: str,
        source_namespace: str,
        target_namespace: str,
    ) -> Tuple[bool, str]:
        """Dry-run policy check — returns (allowed, reason). Does NOT mutate."""
        if source_namespace == target_namespace:
            return False, "same-namespace promotion is a no-op"
        required_state = PROMOTION_MATRIX.get((source_namespace, target_namespace))
        if required_state is None:
            return False, f"BLOCKED by policy: {source_namespace} -> {target_namespace} not in matrix"
        try:
            src = self.store.get_artifact(artifact_id, source_namespace)
        except ArtifactNotFoundError as e:
            return False, f"source not found: {e}"
        if src.curation_state != required_state:
            return False, (
                f"requires curation_state={required_state!r}, "
                f"got {src.curation_state!r}"
            )
        return True, "policy permits"
