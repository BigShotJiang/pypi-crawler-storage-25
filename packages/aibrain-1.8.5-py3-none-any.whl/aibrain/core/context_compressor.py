"""
context_compressor.py — FTS5-backed context compression for large tool outputs.

compress(text) returns text unchanged if under threshold.
Above threshold: indexes into SQLite FTS5 and returns a compact summary pointer.
decompress(chunk_id) retrieves the original from the FTS5 store.
"""
import hashlib
import os
import re
import sqlite3
from pathlib import Path

_DEFAULT_THRESHOLD = 102400  # 100 KB


def _db_path() -> str:
    return os.environ.get('AIBRAIN_DB', str(Path.home() / 'projects' / 'aibrain' / 'aibrain.db'))


def _ensure_schema(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS compressed_chunks (
            chunk_id  TEXT PRIMARY KEY,
            content   TEXT NOT NULL,
            byte_size INTEGER NOT NULL,
            created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS compressed_chunks_fts
            USING fts5(chunk_id UNINDEXED, content, tokenize='porter ascii');
    """)
    conn.commit()


def _top_terms(text: str, n: int = 8) -> str:
    _STOP = frozenset({
        'the', 'and', 'for', 'are', 'was', 'has', 'not', 'this', 'that',
        'with', 'from', 'they', 'have', 'been', 'will', 'would', 'could',
        'should', 'which', 'their', 'there', 'what', 'when', 'where',
        'your', 'into', 'more', 'also', 'then', 'than', 'some', 'such',
    })
    words = re.findall(r'[a-zA-Z]{4,}', text.lower())
    freq: dict[str, int] = {}
    for w in words:
        if w not in _STOP:
            freq[w] = freq.get(w, 0) + 1
    top = sorted(freq, key=lambda k: -freq[k])[:n]
    return ', '.join(top)


def compress(text: str, threshold_bytes: int = _DEFAULT_THRESHOLD) -> str:
    """Return text unchanged if small; otherwise index and return summary pointer."""
    encoded = text.encode('utf-8', errors='replace')
    if len(encoded) < threshold_bytes:
        return text

    chunk_id = hashlib.sha256(encoded).hexdigest()[:16]
    byte_count = len(encoded)
    terms = _top_terms(text)
    summary = text[:500].replace('\n', ' ')

    try:
        conn = sqlite3.connect(_db_path())
        try:
            _ensure_schema(conn)
            exists = conn.execute(
                'SELECT 1 FROM compressed_chunks WHERE chunk_id = ?', (chunk_id,)
            ).fetchone()
            if not exists:
                conn.execute(
                    'INSERT INTO compressed_chunks (chunk_id, content, byte_size) VALUES (?, ?, ?)',
                    (chunk_id, text, byte_count),
                )
                conn.execute(
                    'INSERT INTO compressed_chunks_fts (chunk_id, content) VALUES (?, ?)',
                    (chunk_id, text),
                )
                conn.commit()
        finally:
            conn.close()
    except Exception:
        # Never lose the original on DB error — fall back to truncated text
        return f'[COMPRESSED: unavailable | {byte_count} bytes]\nSummary: {summary}...'

    return (
        f'[COMPRESSED: {chunk_id} | {byte_count} bytes | Top terms: {terms}]\n'
        f'Summary: {summary}...'
    )


def decompress(chunk_id: str) -> str:
    """Retrieve original content by chunk_id. Returns empty string if not found."""
    try:
        conn = sqlite3.connect(_db_path())
        try:
            _ensure_schema(conn)
            row = conn.execute(
                'SELECT content FROM compressed_chunks WHERE chunk_id = ?', (chunk_id,)
            ).fetchone()
            return row[0] if row else ''
        finally:
            conn.close()
    except Exception:
        return ''
