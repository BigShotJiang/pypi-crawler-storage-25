"""
Image generation provider implementations for AIBrain.

Implements ImageProvider contract defined in aibrain.core.provider_contract.
Concrete providers: Flux (Black Forest Labs), Recraft, Imagen (Google Vertex AI),
and SDXL Local (Stable Diffusion XL running on local GPU).

Shape matches provider_anthropic.py: __init__(config), async invoke(request)
returning {url_or_path, model_used, latency_ms}.
"""

import json
import logging
import os
import time
import urllib.request
import urllib.error
import asyncio
from typing import Any, Dict, Optional

from aibrain.core.provider_contract import ImageProvider

logger = logging.getLogger("aibrain.provider_image")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FLUX_API_URL = "https://api.bfl.ml/v1/flux"
RECRAFT_API_URL = "https://api.recraft.ai/v1/images/generations"
# Imagen uses Google Vertex AI REST: projects/{project}/locations/{location}/publishers/google/models/imagen-3:predict
IMAGEN_API_URL_TEMPLATE = (
    "https://{location}-aiplatform.googleapis.com/v1/"
    "projects/{project}/locations/{location}/publishers/google/"
    "models/{model}:predict"
)

# Model IDs as of 2026-05
MODEL_FLUX_SCHNELL = "flux-schnell"
MODEL_FLUX_PRO = "flux-pro-1.1"
MODEL_RECRAFT_V3 = "recraft-v3"
MODEL_IMAGEN_3 = "imagen-3"
MODEL_SDXL = "sdxl-1.0"

DEFAULT_MODEL_FOR_TASK_CLASS: Dict[str, str] = {
    "image_fast": MODEL_FLUX_SCHNELL,
    "image_quality": MODEL_FLUX_PRO,
    "image_vector": MODEL_RECRAFT_V3,
    "image_photo": MODEL_IMAGEN_3,
    "image_local": MODEL_SDXL,
}

SUPPORTED_TASK_CLASSES = list(DEFAULT_MODEL_FOR_TASK_CLASS.keys())

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ImageProviderError(Exception):
    """Raised when an image provider encounters an error."""

    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_api_key(config: Dict[str, Any], env_var: str) -> str:
    """Extract the API key from config or environment variable."""
    api_key = config.get("api_key") or os.environ.get(env_var)
    if not api_key:
        raise ImageProviderError(
            f"API key not found in config or {env_var} env var"
        )
    return api_key


def _resolve_model(config: Dict[str, Any], task_class: str) -> str:
    """Determine which model to use for a given task class."""
    model = config.get("model")
    if model:
        return model
    if task_class not in DEFAULT_MODEL_FOR_TASK_CLASS:
        raise ImageProviderError(
            f"Unsupported task_class '{task_class}'. "
            f"Supported: {SUPPORTED_TASK_CLASSES}"
        )
    return DEFAULT_MODEL_FOR_TASK_CLASS[task_class]


def _call_image_http(
    api_url: str,
    api_key: str,
    headers_extra: Dict[str, str],
    body: Dict[str, Any],
    timeout: int = 120,
) -> Dict[str, Any]:
    """Synchronous HTTP call to an image generation API.

    Returns a dict with keys: url_or_path, model_used, latency_ms.
    """
    headers = {
        "Content-Type": "application/json",
    }
    headers.update(headers_extra)

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(api_url, data=data, headers=headers, method="POST")

    start = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            elapsed_ms = (time.monotonic() - start) * 1000.0
    except urllib.error.HTTPError as exc:
        err_body = exc.read().decode("utf-8", errors="replace")
        raise ImageProviderError(
            f"Image API HTTP {exc.code}: {err_body}"
        ) from exc
    except Exception as exc:
        raise ImageProviderError(f"Image API request failed: {exc}") from exc

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ImageProviderError(f"Invalid JSON from image API: {raw[:200]}") from exc

    # Extract URL — different APIs put it in different places
    url = (
        payload.get("url")
        or payload.get("image_url")
        or payload.get("output", {}).get("url")
        or ""
    )

    model_used = payload.get("model", body.get("model", "unknown"))

    return {
        "url_or_path": url,
        "model_used": model_used,
        "latency_ms": round(elapsed_ms, 2),
    }


# ---------------------------------------------------------------------------
# FluxImageProvider (Black Forest Labs)
# ---------------------------------------------------------------------------


class FluxImageProvider(ImageProvider):
    """Concrete ImageProvider backed by Black Forest Labs Flux."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "FLUX_API_KEY")
        task_class = request.get("task_class", "image_fast")
        model = _resolve_model(config, task_class)

        prompt = request.get("prompt", "")
        size = request.get("size", "1024x1024")
        quality = request.get("quality", "standard")

        body = {
            "prompt": prompt,
            "width": int(size.split("x")[0]) if "x" in size else 1024,
            "height": int(size.split("x")[1]) if "x" in size else 1024,
            "steps": 28 if quality == "hd" else 20,
            "model": model,
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_image_http,
            f"{FLUX_API_URL}/{model}",
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "FLUX_API_KEY")
        task_class = request.get("task_class", "image_fast")
        model = _resolve_model(config, task_class)

        prompt = request.get("prompt", "")
        size = request.get("size", "1024x1024")

        body = {
            "prompt": prompt,
            "width": int(size.split("x")[0]) if "x" in size else 1024,
            "height": int(size.split("x")[1]) if "x" in size else 1024,
            "model": model,
        }

        return _call_image_http(
            f"{FLUX_API_URL}/{model}",
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )


# ---------------------------------------------------------------------------
# RecraftImageProvider
# ---------------------------------------------------------------------------


class RecraftImageProvider(ImageProvider):
    """Concrete ImageProvider backed by Recraft AI (vector/raster)."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "RECRAFT_API_KEY")
        task_class = request.get("task_class", "image_vector")
        model = _resolve_model(config, task_class)

        prompt = request.get("prompt", "")
        size = request.get("size", "1024x1024")
        quality = request.get("quality", "standard")

        body = {
            "prompt": prompt,
            "style": request.get("style", "vector"),
            "size": size,
            "model": model,
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_image_http,
            RECRAFT_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "RECRAFT_API_KEY")
        task_class = request.get("task_class", "image_vector")
        model = _resolve_model(config, task_class)

        body = {
            "prompt": request.get("prompt", ""),
            "style": request.get("style", "vector"),
            "size": request.get("size", "1024x1024"),
            "model": model,
        }

        return _call_image_http(
            RECRAFT_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )


# ---------------------------------------------------------------------------
# ImagenImageProvider (Google Vertex AI)
# ---------------------------------------------------------------------------


class ImagenImageProvider(ImageProvider):
    """Concrete ImageProvider backed by Google Imagen via Vertex AI."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        # Imagen uses GCP service account or API key via Bearer token
        api_key = _get_api_key(config, "GOOGLE_API_KEY")
        task_class = request.get("task_class", "image_photo")
        model = _resolve_model(config, task_class)

        project = config.get("project") or os.environ.get("GOOGLE_PROJECT_ID", "default")
        location = config.get("location", "us-central1")

        api_url = IMAGEN_API_URL_TEMPLATE.format(
            location=location,
            project=project,
            model=model,
        )

        prompt = request.get("prompt", "")
        size = request.get("size", "1024x1024")
        quality = request.get("quality", "standard")

        body = {
            "instances": [{"prompt": prompt}],
            "parameters": {
                "sampleCount": 1,
                "aspectRatio": size.replace("x", ":"),
                "safetySetting": "block_medium_and_above",
            },
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_image_http,
            api_url,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "GOOGLE_API_KEY")
        task_class = request.get("task_class", "image_photo")
        model = _resolve_model(config, task_class)

        project = config.get("project") or os.environ.get("GOOGLE_PROJECT_ID", "default")
        location = config.get("location", "us-central1")

        api_url = IMAGEN_API_URL_TEMPLATE.format(
            location=location,
            project=project,
            model=model,
        )

        body = {
            "instances": [{"prompt": request.get("prompt", "")}],
            "parameters": {
                "sampleCount": 1,
                "aspectRatio": request.get("size", "1024x1024").replace("x", ":"),
                "safetySetting": "block_medium_and_above",
            },
        }

        return _call_image_http(
            api_url,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )


# ---------------------------------------------------------------------------
# SDXLLocalImageProvider (Stable Diffusion XL — local GPU)
# ---------------------------------------------------------------------------


class SDXLLocalImageProvider(ImageProvider):
    """Concrete ImageProvider backed by local Stable Diffusion XL.

    No API key required — connects to a local SDXL endpoint (default
    http://localhost:7860/sdapi/v1/txt2img for Automatic1111 / ComfyUI).
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        task_class = request.get("task_class", "image_local")
        model = _resolve_model(config, task_class)

        endpoint = config.get("endpoint", "http://localhost:7860/sdapi/v1/txt2img")

        prompt = request.get("prompt", "")
        size = request.get("size", "1024x1024")
        quality = request.get("quality", "standard")

        width = int(size.split("x")[0]) if "x" in size else 1024
        height = int(size.split("x")[1]) if "x" in size else 1024
        steps = 30 if quality == "hd" else 20

        body = {
            "prompt": prompt,
            "negative_prompt": request.get("negative_prompt", ""),
            "width": width,
            "height": height,
            "steps": steps,
            "cfg_scale": 7.0,
        }

        start = time.monotonic()
        try:
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=300) as resp:
                raw = resp.read().decode("utf-8")
                elapsed_ms = (time.monotonic() - start) * 1000.0
        except Exception as exc:
            raise ImageProviderError(f"SDXL local request failed: {exc}") from exc

        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            raise ImageProviderError(f"Invalid JSON from SDXL: {raw[:200]}")

        # Automatic1111 returns {"images": ["base64..."], "info": "..."}
        # We store the base64 data as a local temp file and return its path.
        images = payload.get("images", [])
        if images:
            import tempfile
            import base64
            img_data = base64.b64decode(images[0])
            tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            tmp.write(img_data)
            tmp.close()
            url_or_path = tmp.name
        else:
            url_or_path = ""

        return {
            "url_or_path": url_or_path,
            "model_used": model,
            "latency_ms": round(elapsed_ms, 2),
        }

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # SDXL is local — just call invoke synchronously via the same logic
        config = self.config or {}
        task_class = request.get("task_class", "image_local")
        model = _resolve_model(config, task_class)

        endpoint = config.get("endpoint", "http://localhost:7860/sdapi/v1/txt2img")
        prompt = request.get("prompt", "")
        size = request.get("size", "1024x1024")
        quality = request.get("quality", "standard")

        width = int(size.split("x")[0]) if "x" in size else 1024
        height = int(size.split("x")[1]) if "x" in size else 1024
        steps = 30 if quality == "hd" else 20

        body = {
            "prompt": prompt,
            "negative_prompt": request.get("negative_prompt", ""),
            "width": width,
            "height": height,
            "steps": steps,
            "cfg_scale": 7.0,
        }

        start = time.monotonic()
        try:
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=300) as resp:
                raw = resp.read().decode("utf-8")
                elapsed_ms = (time.monotonic() - start) * 1000.0
        except Exception as exc:
            raise ImageProviderError(f"SDXL local request failed: {exc}") from exc

        payload = json.loads(raw)
        images = payload.get("images", [])
        if images:
            import tempfile
            import base64
            img_data = base64.b64decode(images[0])
            tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            tmp.write(img_data)
            tmp.close()
            url_or_path = tmp.name
        else:
            url_or_path = ""

        return {
            "url_or_path": url_or_path,
            "model_used": model,
            "latency_ms": round(elapsed_ms, 2),
        }


# ---------------------------------------------------------------------------
# Smoke test (instantiation only — no API calls, no keys required)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Instantiate all providers with minimal/dummy config
    flux = FluxImageProvider(config={"api_key": "dummy-flux-key"})
    recraft = RecraftImageProvider(config={"api_key": "dummy-recraft-key"})
    imagen = ImagenImageProvider(config={"api_key": "dummy-google-key"})
    sdxl = SDXLLocalImageProvider()

    # Verify they are instances of ImageProvider
    assert isinstance(flux, ImageProvider), "FluxImageProvider must be ImageProvider"
    assert isinstance(recraft, ImageProvider), "RecraftImageProvider must be ImageProvider"
    assert isinstance(imagen, ImageProvider), "ImagenImageProvider must be ImageProvider"
    assert isinstance(sdxl, ImageProvider), "SDXLLocalImageProvider must be ImageProvider"

    # Verify DEFAULT_MODEL_FOR_TASK_CLASS has expected entries
    assert "image_fast" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "image_quality" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "image_vector" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "image_photo" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "image_local" in DEFAULT_MODEL_FOR_TASK_CLASS

    # Verify model constants
    assert MODEL_FLUX_PRO == "flux-pro-1.1"
    assert MODEL_IMAGEN_3 == "imagen-3"

    print("provider_image smoke test OK")
