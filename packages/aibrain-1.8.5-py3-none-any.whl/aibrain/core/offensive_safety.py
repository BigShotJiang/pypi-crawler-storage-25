"""
offensive_safety.py — Safety gate for compound learning on offensive products.

Prevents offensive technique leakage across contexts:
  1. Tags offensive-origin memories with source:offensive
  2. Gates retrieval: offensive memories only returned for security/offensive queries
  3. Blocks offensive memories from brain exports (marketplace)
  4. Blocks offensive memories from non-security category summaries

The brain learns from Wintermute scan results, exploit payloads, credential
dumps, etc. These must never leak to general contexts or marketplace exports.

Usage:
    from aibrain.core.offensive_safety import (
        tag_offensive_memory,
        is_offensive_memory,
        filter_for_context,
        filter_for_export,
    )

    # Tag a memory from Wintermute results
    tag_offensive_memory(memory_id=42, origin="wintermute")

    # Filter search results for a non-security query
    safe_results = filter_for_context(results, query_context="marketing")

    # Filter memories for marketplace export
    exportable = filter_for_export(memories)
"""

from __future__ import annotations

import logging
import os
import sqlite3
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.offensive_safety")

# ---------------------------------------------------------------------------
# Offensive content indicators
# ---------------------------------------------------------------------------

# Keywords that indicate offensive/security origin
OFFENSIVE_KEYWORDS = frozenset({
    "exploit", "payload", "shellcode", "reverse shell", "bind shell",
    "credential dump", "password hash", "ntlm", "mimikatz", "metasploit",
    "meterpreter", "cobalt strike", "beacon", "c2 server", "command and control",
    "privilege escalation", "privesc", "lateral movement", "persistence mechanism",
    "rootkit", "backdoor", "keylogger", "ransomware", "malware",
    "sql injection", "sqli", "xss", "cross-site scripting",
    "rce", "remote code execution", "lfi", "rfi", "ssrf",
    "directory traversal", "path traversal",
    "buffer overflow", "heap spray", "rop chain", "ret2libc",
    "cve-", "vulnerability scan", "attack chain", "kill chain",
    "enumeration", "fingerprinting", "reconnaissance",
    "brute force", "credential stuffing", "pass the hash",
})

# Products that produce offensive-origin data
OFFENSIVE_SOURCES = frozenset({
    "wintermute", "remediate", "rogue", "permeate",
    "security_scan", "vuln_scan", "exploit_test",
    "attack_graph", "pentest", "red_team",
})

# Security/offensive query context keywords (allow offensive memories)
SECURITY_CONTEXT_KEYWORDS = frozenset({
    "security", "vulnerability", "exploit", "attack", "threat",
    "cve", "scan", "pentest", "penetration test", "red team",
    "blue team", "defense", "detection", "wintermute", "remediate",
    "rogue", "paragon", "permeate", "offensive", "malware",
    "incident", "forensic", "compliance", "audit",
})

# Tags that mark a memory as offensive
OFFENSIVE_TAG = "source:offensive"


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

def is_offensive_content(content: str) -> bool:
    """Check if content contains offensive security techniques.

    Uses keyword matching against known offensive indicators.
    Case-insensitive, matches partial words for compound terms.
    """
    if not content:
        return False
    lower = content.lower()
    for keyword in OFFENSIVE_KEYWORDS:
        if keyword in lower:
            return True
    return False


def is_offensive_source(source: str) -> bool:
    """Check if the source/origin indicates offensive product data."""
    if not source:
        return False
    return source.lower() in OFFENSIVE_SOURCES


def is_offensive_memory(memory: dict) -> bool:
    """Check if a memory dict is tagged or detected as offensive.

    Checks both explicit tags and content-based detection.
    """
    # Check explicit tag
    tags = memory.get("tags", "") or ""
    if OFFENSIVE_TAG in tags:
        return True

    # Check metadata tags
    metadata = memory.get("metadata", {})
    if isinstance(metadata, dict):
        meta_tags = metadata.get("tags", "")
        if isinstance(meta_tags, str) and OFFENSIVE_TAG in meta_tags:
            return True

    # Check content-based detection
    content = memory.get("content", "") or memory.get("memory", "")
    if is_offensive_content(content):
        return True

    # Check source field
    source = memory.get("source", "") or ""
    if is_offensive_source(source):
        return True

    return False


def is_security_context(query: str) -> bool:
    """Determine if a query/context is security-related.

    Returns True if the query context allows offensive memory retrieval.
    """
    if not query:
        return False
    lower = query.lower()
    for keyword in SECURITY_CONTEXT_KEYWORDS:
        if keyword in lower:
            return True
    return False


# ---------------------------------------------------------------------------
# Tagging
# ---------------------------------------------------------------------------

def tag_offensive_memory(memory_id: int, origin: str = "unknown") -> bool:
    """Add source:offensive tag to a memory and record its origin.

    Args:
        memory_id: The memory ID to tag.
        origin: The offensive source (e.g. "wintermute", "rogue").

    Returns:
        True if tagged successfully.
    """
    try:
        db_path = _get_db_path()
        if not db_path or not db_path.exists():
            return False

        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")

        row = conn.execute(
            "SELECT id, tags FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()

        if not row:
            conn.close()
            return False

        current_tags = row["tags"] or ""
        if OFFENSIVE_TAG not in current_tags:
            new_tags = f"{current_tags},{OFFENSIVE_TAG},origin:{origin}".strip(",")
            conn.execute(
                "UPDATE memories SET tags = ? WHERE id = ?",
                (new_tags, memory_id),
            )
            conn.commit()
            log.info("Tagged memory %d as offensive (origin=%s)", memory_id, origin)

        conn.close()
        return True
    except Exception as e:
        log.warning("Failed to tag offensive memory %d: %s", memory_id, e)
        return False


def auto_tag_offensive(memory_id: int, content: str, source: str = "") -> bool:
    """Automatically detect and tag a memory if it contains offensive content.

    Call this after memory creation to ensure offensive data is tagged.

    Returns:
        True if the memory was tagged as offensive.
    """
    if is_offensive_content(content) or is_offensive_source(source):
        return tag_offensive_memory(memory_id, origin=source or "auto_detected")
    return False


# ---------------------------------------------------------------------------
# Retrieval filtering
# ---------------------------------------------------------------------------

def filter_for_context(
    memories: list[dict],
    query_context: str = "",
) -> list[dict]:
    """Filter memory results based on query context.

    Offensive memories are only returned when the query context
    is explicitly security/offensive-related.

    Args:
        memories: List of memory dicts from search results.
        query_context: The query string or context description.

    Returns:
        Filtered list with offensive memories removed for non-security queries.
    """
    if is_security_context(query_context):
        return memories  # security context — allow all

    return [m for m in memories if not is_offensive_memory(m)]


def filter_for_export(memories: list[dict]) -> list[dict]:
    """Filter memories for brain marketplace export.

    NEVER includes offensive-origin memories in exports.
    This is a hard security boundary — no override.

    Args:
        memories: List of memory dicts to export.

    Returns:
        List with all offensive memories removed.
    """
    return [m for m in memories if not is_offensive_memory(m)]


def filter_for_summary(
    memories: list[dict],
    domain: str = "",
) -> list[dict]:
    """Filter memories for category summaries.

    Offensive memories only included in security domain summaries.

    Args:
        memories: List of memory dicts.
        domain: The domain/category of the summary.

    Returns:
        Filtered list appropriate for the domain.
    """
    security_domains = frozenset({
        "security", "offensive", "vulnerability", "scanning",
        "exploit", "pentest", "red_team", "blue_team",
        "wintermute", "remediate", "rogue", "paragon", "permeate",
    })

    if domain.lower() in security_domains:
        return memories

    return [m for m in memories if not is_offensive_memory(m)]


# ---------------------------------------------------------------------------
# DB helper
# ---------------------------------------------------------------------------

def _get_db_path() -> Optional[Path]:
    """Resolve aibrain.db path."""
    root = os.environ.get("AIBRAIN_ROOT", "")
    if root:
        return Path(root) / "aibrain.db"
    here = Path(__file__).resolve().parent
    for p in [here.parent.parent, here.parent, Path.cwd()]:
        candidate = p / "aibrain.db"
        if candidate.exists():
            return candidate
    return None
