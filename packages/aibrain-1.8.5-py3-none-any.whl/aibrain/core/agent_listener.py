"""Persistent FleetBus subscriber loop for a single company-role agent.

Subscribes to fleet.task.assigned, picks up tasks matching self.agent_id,
runs them via dispatch_deepseek_task, publishes fleet.task.completed, and
emits a 60s heartbeat.
"""

from __future__ import annotations

import logging
import os
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Optional, Any

from aibrain.core.agent_comms import FleetBus
from aibrain.core.companies import (
    checkout_task,
    complete_task,
    TaskReviewFailed,
)
from aibrain.core.agent_dispatch import dispatch_deepseek_task

DEFAULT_BROKER_URL = "http://localhost:8765"
HEARTBEAT_INTERVAL_SECONDS = 60
MAX_REVIEW_RETRIES = 2  # 2 retries after initial = 3 total attempts max
DB_POLL_INTERVAL_SECONDS = 30  # F-FLEET-LISTENER-PICKUP-DIAGNOSIS belt-and-braces fallback

log = logging.getLogger("aibrain.agent_listener")


class AgentListener:
    """Persistent FleetBus subscriber loop for a single company-role agent.

    Subscribes to fleet.task.assigned. On each event with data.assignee_agent_id ==
    self.agent_id, checks out the task, runs the work via dispatch_deepseek_task,
    publishes fleet.task.completed, and lets the inline Liaison gate inside
    complete_task() run. On Liaison FAIL re-dispatches up to MAX_REVIEW_RETRIES.
    Emits fleet.heartbeat.<agent_id> every 60s. Handles SIGINT for graceful shutdown.
    """

    def __init__(
        self,
        agent_id: str,
        persona_file: str,
        providers_config: dict | None = None,
        company_id: str = "GT_LRWrEBQQ",
    ) -> None:
        self.agent_id = agent_id
        self.persona_file = persona_file
        self.providers_config = providers_config if providers_config is not None else {}
        self.company_id = company_id

        self._stop = threading.Event()
        self._bus: Optional[FleetBus] = None
        self._sub_id: Optional[str] = None
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._db_poll_thread: Optional[threading.Thread] = None

        # Validate persona file exists; warn and continue if missing.
        if persona_file and not Path(persona_file).is_file():
            log.warning(
                "Persona file %s not found — continuing with empty persona prompt",
                persona_file,
            )

    def _load_persona(self) -> str:
        """Read persona_file from disk. Returns content as str or empty string on miss."""
        if not self.persona_file:
            return ""
        try:
            return Path(self.persona_file).read_text(encoding="utf-8")
        except (IOError, UnicodeDecodeError) as exc:
            log.warning("Could not read persona file %s: %s", self.persona_file, exc)
            return ""

    def start(self, broker_url: str = DEFAULT_BROKER_URL) -> None:
        """Connect to FleetBus broker, subscribe, start heartbeat, install SIGINT, block."""
        self._bus = FleetBus(agent_id=self.agent_id, broker_url=broker_url)
        self._sub_id = self._bus.subscribe("fleet.task.assigned", self.on_task_assigned)

        self._heartbeat_thread = threading.Thread(
            target=self.heartbeat, daemon=True, name="heartbeat"
        )
        self._heartbeat_thread.start()

        # F-FLEET-LISTENER-PICKUP-DIAGNOSIS (2026-05-22): belt-and-braces DB-poll
        # fallback. The HTTP broker adapter's _derive_recipient() routes
        # fleet.task.assigned to the 'all' queue, but listeners poll their own
        # per-agent queue — so push-based pickup never fires. Poll company_issues
        # directly for backlog tasks assigned to this agent_id, synthesize a
        # CloudEvent, dispatch through on_task_assigned() (checkout_task is the
        # dedup gate). Diagnosis: decker_system/00_meta/fleet_listener_pickup_diagnosis_2026_05_22.md
        self._db_poll_thread = threading.Thread(
            target=self._db_poll_loop, daemon=True, name="db-poll-fallback"
        )
        self._db_poll_thread.start()

        # Install SIGINT handler — wrap for Windows non-main-thread safety.
        try:
            signal.signal(signal.SIGINT, lambda *_: self.shutdown())
        except ValueError:
            log.debug("SIGINT handler not installed (non-main thread or Windows)")

        log.info("AgentListener started for %s on %s", self.agent_id, broker_url)
        while not self._stop.is_set():
            self._stop.wait(timeout=1.0)

        # Tear down.
        try:
            if self._bus is not None:
                self._bus.close()
        except Exception:
            log.exception("Error closing FleetBus during shutdown")

    def shutdown(self) -> None:
        """Set the stop flag. Idempotent. Safe to call from signal handler."""
        self._stop.set()

    def on_task_assigned(self, event: dict) -> None:
        """Subscribe callback. event is the raw CloudEvent dict."""
        try:
            data = event.get("data", {})
            if data.get("assignee_agent_id") != self.agent_id:
                return  # not for us

            task_id = data["task_id"]  # KeyError if missing — strict contract

            # 1. Checkout
            try:
                checkout_task(task_id, self.agent_id)
            except ValueError:
                log.info("Task %s already claimed by another agent", task_id)
                return
            except Exception:
                log.exception("Checkout failed for task %s", task_id)
                return

            # 2. Build prompt
            persona_prompt = self._load_persona()
            description = data.get("description") or data.get("title") or ""
            prompt = (
                f"{persona_prompt}\n\nTASK:\n{description}\n\n"
                f"EVIDENCE:\n"
                f"  task_id: {task_id}\n"
                f"  title: {data.get('title', '')}\n"
                f"  acceptance_criteria: {data.get('acceptance_criteria', 'none')}\n"
            )

            # 3. Dispatch with review-retry loop
            attempt = 0
            critique = ""
            while attempt <= MAX_REVIEW_RETRIES:
                try:
                    result = dispatch_deepseek_task(
                        task_id=task_id,
                        task_prompt=prompt,
                        agent_id=self.agent_id,
                        plan_summary=f"AgentListener picks up {task_id}",
                        company_id=self.company_id,
                    )
                    # Success — publish completion
                    self._bus.publish(
                        "fleet.task.completed",
                        {
                            "task_id": task_id,
                            "agent_id": self.agent_id,
                            "status": "done",
                            "work_output_preview": result.get("work_output", "")[:500],
                        },
                    )
                    log.info("Task %s completed successfully", task_id)
                    return

                except TaskReviewFailed as exc:
                    critique = exc.args[0] if exc.args else "Liaison review failed"
                    attempt += 1
                    if attempt > MAX_REVIEW_RETRIES:
                        log.error(
                            "Task %s failed after %d retries: %s",
                            task_id,
                            MAX_REVIEW_RETRIES + 1,
                            critique,
                        )
                        self._bus.publish(
                            "fleet.task.completed",
                            {
                                "task_id": task_id,
                                "agent_id": self.agent_id,
                                "status": "failed",
                                "critique": critique,
                            },
                        )
                        return
                    # Append critique and retry
                    prompt += (
                        f"\n\nPRIOR REVIEW FAILED — fix the following:\n{critique}\n"
                    )
                    log.warning(
                        "Task %s review failed (attempt %d/%d): %s",
                        task_id,
                        attempt,
                        MAX_REVIEW_RETRIES + 1,
                        critique,
                    )

        except Exception:
            log.exception("Unhandled error in on_task_assigned for event %s", event)
            # Do NOT re-raise — one bad event must not kill the loop.

    def _db_poll_loop(self) -> None:
        """Belt-and-braces DB poll for backlog tasks assigned to this agent.

        F-FLEET-LISTENER-PICKUP-DIAGNOSIS (2026-05-22): the HTTP broker adapter's
        _derive_recipient() lumps fleet.task.assigned into the 'all' queue while
        listeners recv from their per-agent queue — so push-based pickup never
        fires. This loop queries company_issues directly for
        WHERE assignee_agent_id=self.agent_id AND status='backlog', picks the
        oldest, synthesizes a CloudEvent-shaped dict, and feeds it through
        on_task_assigned(). checkout_task() inside on_task_assigned() is the
        canonical dedup point — if the FleetBus push DID fire first, the second
        checkout raises ValueError which is already handled.
        """
        import sqlite3
        from pathlib import Path

        # FleetBus already computed the canonical aibrain.db path; reuse it.
        db_path = self._bus._db_path if self._bus is not None else None
        if not db_path or not Path(db_path).is_file():
            log.warning(
                "_db_poll_loop: aibrain.db not found at %s — DB-poll fallback disabled",
                db_path,
            )
            return

        log.info(
            "_db_poll_loop: started for agent=%s db=%s interval=%ds",
            self.agent_id, db_path, DB_POLL_INTERVAL_SECONDS,
        )

        while not self._stop.is_set():
            try:
                conn = sqlite3.connect(db_path, timeout=5.0)
                conn.row_factory = sqlite3.Row
                # F-LISTENER-DEFENSIVE-NULL-ID-1 (2026-05-22): AND id IS NOT NULL
                # prevents looping on corrupt NULL-id rows. Observed earlier this
                # session: 3 NULL-id rows from 2026-04-12 caused infinite re-pickup
                # (checkout_task(None,...) is a silent no-op so the same row was
                # picked up every poll cycle).
                row = conn.execute(
                    """
                    SELECT id, title, description, priority, parent_id
                    FROM company_issues
                    WHERE assignee_agent_id = ? AND status = 'backlog' AND id IS NOT NULL
                    ORDER BY datetime(created_at) ASC
                    LIMIT 1
                    """,
                    (self.agent_id,),
                ).fetchone()
                conn.close()

                if row is not None:
                    log.info(
                        "_db_poll_loop: picked up backlog task %s for %s",
                        row["id"], self.agent_id,
                    )
                    synthetic_event = {
                        "type": "fleet.task.assigned",
                        "source": "agent://db-poll-fallback",
                        "data": {
                            "task_id": row["id"],
                            "title": row["title"] or "",
                            "description": row["description"] or "",
                            "priority": row["priority"] or "",
                            "assignee_agent_id": self.agent_id,
                        },
                    }
                    try:
                        self.on_task_assigned(synthetic_event)
                    except Exception:
                        log.exception(
                            "_db_poll_loop: on_task_assigned raised for task %s",
                            row["id"],
                        )
            except Exception:
                log.exception("_db_poll_loop: poll iteration failed")

            self._stop.wait(timeout=DB_POLL_INTERVAL_SECONDS)

        log.info("_db_poll_loop: exited for agent=%s", self.agent_id)

    def heartbeat(self) -> None:
        """Background loop publishing fleet.heartbeat.<agent_id> every 60s."""
        topic = f"fleet.heartbeat.{self.agent_id}"
        while not self._stop.is_set():
            try:
                if self._bus is not None:
                    self._bus.publish(
                        topic,
                        {
                            "agent_id": self.agent_id,
                            "ts": time.time(),
                            "status": "alive",
                        },
                    )
            except Exception:
                log.exception("Heartbeat publish failed")
            self._stop.wait(timeout=HEARTBEAT_INTERVAL_SECONDS)


# ---------------------------------------------------------------------------
# CLI entry — F-FLEET-LISTENER-CLI-1 (Decker 2026-05-22 ultimatum):
# the disabled launch_fleet.ps1 expected `python -m aibrain.core.agent_listener`
# to work; this is the missing __main__ that makes that command valid.
# ---------------------------------------------------------------------------

def _cli_main() -> int:
    import argparse
    import os
    parser = argparse.ArgumentParser(
        prog="aibrain.core.agent_listener",
        description="Persistent FleetBus listener for a single fleet agent.",
    )
    parser.add_argument("--agent-id", required=True,
                        help="Canonical agent id (e.g. RztUQUCs-h4 for Content Writer)")
    parser.add_argument("--persona-file", required=True,
                        help="Path to persona markdown file used in dispatch prompts")
    parser.add_argument("--broker-url", default=None,
                        help="Override broker URL (default: $BROKER_URL or "
                             "http://localhost:8765)")
    parser.add_argument("--company-id", default="GT_LRWrEBQQ",
                        help="Company id (default: GT_LRWrEBQQ for DeckerOps)")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    broker_url = (
        args.broker_url
        or os.environ.get("BROKER_URL")
        or DEFAULT_BROKER_URL
    )

    log.info(
        "AgentListener CLI: agent_id=%s persona=%s broker=%s company=%s",
        args.agent_id, args.persona_file, broker_url, args.company_id,
    )

    listener = AgentListener(
        agent_id=args.agent_id,
        persona_file=args.persona_file,
        company_id=args.company_id,
    )
    listener.start(broker_url=broker_url)
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli_main())
