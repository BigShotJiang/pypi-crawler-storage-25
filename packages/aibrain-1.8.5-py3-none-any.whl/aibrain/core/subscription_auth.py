"""
RFC-7636 PKCE OAuth 2.0 module for AIBrain subscription providers.

Add a provider = add a row to the PROVIDERS dictionary.
Zero Hermes dependencies (stdlib + httpx only).
"""

import base64
import hashlib
import http.server
import json
import os
import secrets
import socket
import string
import threading
import time
import urllib.parse
import webbrowser
from pathlib import Path

import httpx


class AuthError(Exception):
    """Authentication error (missing credentials, refresh failure, etc.)."""
    pass


# ---------------------------------------------------------------------------
# Provider configuration (one row per provider)
# ---------------------------------------------------------------------------

PROVIDERS = {
    "openai-codex": {
        "client_id": "app_EMoamEEZ73f0CkXaXp7hrann",
        "authorize_url": "https://auth.openai.com/oauth/authorize",
        "token_url": "https://auth.openai.com/oauth/token",
        "base_url": "https://chatgpt.com/backend-api/codex",
        "scope": "openid profile email offline_access",
        "refresh_skew_seconds": 120,
    },
    # Additional providers can be added as rows here.
}


# ---------------------------------------------------------------------------
# PKCE helpers
# ---------------------------------------------------------------------------

_PKCE_CHARSET = string.ascii_letters + string.digits + "-_"


def generate_code_verifier(length: int = 64) -> str:
    """Return a cryptographically-random PKCE code_verifier.

    Length is clamped to [43, 128] characters (RFC 7636).
    """
    length = max(43, min(length, 128))
    return "".join(secrets.choice(_PKCE_CHARSET) for _ in range(length))


def code_challenge_s256(verifier: str) -> str:
    """Return the S256 code_challenge for the given verifier.

    SHA256 -> base64url (no padding).
    """
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


# ---------------------------------------------------------------------------
# Token store (~/.aibrain/subscription_auth.json, mode 0600)
# ---------------------------------------------------------------------------

_TOKEN_DIR = Path.home() / ".aibrain"
_TOKEN_FILE = _TOKEN_DIR / "subscription_auth.json"


def _ensure_store_dir() -> None:
    _TOKEN_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)


def _load_tokens() -> dict:
    """Load all tokens from disk (empty dict if missing or corrupt)."""
    if not _TOKEN_FILE.exists():
        return {}
    try:
        return json.loads(_TOKEN_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save_tokens(provider_id: str, token_data: dict) -> None:
    """Persist token data for provider_id atomically, with mode 0600."""
    _ensure_store_dir()
    tokens = _load_tokens()
    tokens[provider_id] = token_data
    json_text = json.dumps(tokens, indent=2, ensure_ascii=False)

    # Write to a temporary file, then atomically replace.
    tmp_path = _TOKEN_FILE.with_suffix(".tmp" + str(os.getpid()))
    try:
        tmp_path.write_text(json_text, encoding="utf-8")
        try:
            os.chmod(tmp_path, 0o600)
        except OSError:
            pass
        os.replace(tmp_path, _TOKEN_FILE)
    finally:
        # Make sure the temp file is cleaned up.
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass


# ---------------------------------------------------------------------------
# OAuth callback server (internal)
# ---------------------------------------------------------------------------

class _OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    """Minimal handler to capture the OAuth redirect and signal completion."""

    # Shared state between handler and the main thread.
    result: dict | None = None
    expected_state: str | None = None
    redirect_uri: str | None = None
    server_port: int = 0

    def do_GET(self) -> None:
        """Process the callback request."""
        parsed = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed.query)

        if parsed.path != "/callback":
            self.send_error(404)
            return

        error = query.get("error", [None])[0]
        code = query.get("code", [None])[0]
        state = query.get("state", [None])[0]

        if error:
            _OAuthCallbackHandler.result = {"error": error}
        elif state != _OAuthCallbackHandler.expected_state:
            _OAuthCallbackHandler.result = {
                "error": f"State mismatch: expected {_OAuthCallbackHandler.expected_state}, got {state}"
            }
        elif not code:
            _OAuthCallbackHandler.result = {"error": "No authorization code received"}
        else:
            _OAuthCallbackHandler.result = {"code": code}

        # Reply to the browser.
        if _OAuthCallbackHandler.result.get("error"):
            msg = f"Login error: {_OAuthCallbackHandler.result['error']}"
        else:
            msg = "Login successful! You can close this window."
        body = f"<html><body><h1>{msg}</h1></body></html>".encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

        # Signal the main thread that we are done.
        self.server._is_done = True  # type: ignore


def _start_local_server(
    port: int, expected_state: str, redirect_uri: str
) -> http.server.HTTPServer:
    """Create and return a local HTTPServer on the given port."""
    server = http.server.HTTPServer(("127.0.0.1", port), _OAuthCallbackHandler)
    server.timeout = 1  # seconds, so serve_forever can check shutdown flags
    server._is_done = False
    _OAuthCallbackHandler.result = None
    _OAuthCallbackHandler.expected_state = expected_state
    _OAuthCallbackHandler.redirect_uri = redirect_uri
    _OAuthCallbackHandler.server_port = port
    return server


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def begin_login(provider_id: str, timeout: float = 300.0) -> tuple[str, str]:
    """Initiate OAuth PKCE login, returning ``(auth_code, code_verifier)``.

    Blocks until the callback arrives or *timeout* seconds elapse.
    Raises AuthError on failure.
    """
    if provider_id not in PROVIDERS:
        raise AuthError(f"Unknown provider: {provider_id}")
    cfg = PROVIDERS[provider_id]

    # Find an available port.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]

    redirect_uri = f"http://127.0.0.1:{port}/callback"
    state = secrets.token_urlsafe(32)
    verifier = generate_code_verifier()
    challenge = code_challenge_s256(verifier)

    # Build authorization URL.
    params = {
        "response_type": "code",
        "client_id": cfg["client_id"],
        "redirect_uri": redirect_uri,
        "scope": cfg["scope"],
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    authorize_url = cfg["authorize_url"] + "?" + urllib.parse.urlencode(params)

    # Start local server in a background daemon thread.
    server = _start_local_server(port, state, redirect_uri)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    # Open the browser.
    webbrowser.open(authorize_url)

    # Wait for callback or timeout.
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if getattr(server, "_is_done", False):
            break
        time.sleep(0.1)

    # Shut down server.
    server.shutdown()
    server_thread.join(timeout=5)

    if not getattr(server, "_is_done", False):
        raise AuthError(f"Login timed out after {timeout} seconds")
    result = _OAuthCallbackHandler.result
    if result is None or "error" in result:
        raise AuthError(
            f"Login failed: {result.get('error', 'unknown') if result else 'unknown'}"
        )

    return result["code"], verifier


def exchange_code(
    provider_id: str,
    code: str,
    code_verifier: str,
    redirect_uri: str,
) -> dict:
    """Exchange a one-time authorization code for tokens (access + refresh).

    Tokens are persisted to the token store. Returns the full token response
    (a dict with at least ``access_token``, ``refresh_token``, ``expires_in``).
    """
    if provider_id not in PROVIDERS:
        raise AuthError(f"Unknown provider: {provider_id}")
    cfg = PROVIDERS[provider_id]

    url = cfg["token_url"]
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri,
        "client_id": cfg["client_id"],
        "code_verifier": code_verifier,
    }

    try:
        resp = httpx.post(url, data=data, timeout=30.0)
        resp.raise_for_status()
    except httpx.RequestError as exc:
        raise AuthError(f"Token exchange request failed: {exc}") from exc

    token_json = resp.json()
    if "access_token" not in token_json:
        raise AuthError(f"Token response missing access_token: {token_json}")

    # Compute absolute expiry with a safety margin.
    expires_in = int(token_json.get("expires_in", 3600))
    expires_at = time.time() + expires_in - cfg.get("refresh_skew_seconds", 120)

    record = {
        "access_token": token_json["access_token"],
        "refresh_token": token_json.get("refresh_token"),
        "expires_at_epoch": expires_at,
    }
    _save_tokens(provider_id, record)
    return token_json


def get_access_token(provider_id: str) -> str:
    """Return a valid (non-expired) access token for *provider_id*.

    Automatically refreshes the token when it is within
    ``refresh_skew_seconds`` of expiry.  Raises AuthError if no tokens are
    stored (caller should trigger ``begin_login``).
    """
    if provider_id not in PROVIDERS:
        raise AuthError(f"Unknown provider: {provider_id}")
    cfg = PROVIDERS[provider_id]

    # Reuse the existing Codex CLI subscription token — same principle as the
    # claude_cli CLAUDE_CONFIG_DIR fix: reuse the working tool's auth instead
    # of a separate begin_login. The codex CLI stores its OAuth token (kept
    # refreshed by codex itself) at ~/.codex/auth.json -> tokens.access_token.
    if provider_id == "openai-codex":
        try:
            import json as _json
            _cx = Path.home() / ".codex" / "auth.json"
            if _cx.exists():
                _d = _json.loads(_cx.read_text(encoding="utf-8"))
                _tok = (_d.get("tokens") or {}).get("access_token")
                if _tok:
                    return _tok
        except Exception:
            pass  # fall through to native store / begin_login

    tokens = _load_tokens().get(provider_id)
    if not tokens or "access_token" not in tokens:
        raise AuthError(f"No stored tokens for {provider_id} (call begin_login first)")

    now = time.time()
    expires = tokens.get("expires_at_epoch", 0)
    if now >= expires:
        refresh_token = tokens.get("refresh_token")
        if not refresh_token:
            raise AuthError(
                f"Access token expired and no refresh_token available for {provider_id}"
            )

        try:
            resp = httpx.post(
                cfg["token_url"],
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": cfg["client_id"],
                },
                timeout=30.0,
            )
            resp.raise_for_status()
            new_tokens = resp.json()
        except httpx.RequestError as exc:
            raise AuthError(f"Token refresh request failed: {exc}") from exc

        if "access_token" not in new_tokens:
            raise AuthError(f"Refresh response missing access_token: {new_tokens}")

        new_expires_in = int(new_tokens.get("expires_in", 3600))
        new_expires_at = now + new_expires_in - cfg.get("refresh_skew_seconds", 120)
        record = {
            "access_token": new_tokens["access_token"],
            "refresh_token": new_tokens.get("refresh_token", refresh_token),
            "expires_at_epoch": new_expires_at,
        }
        _save_tokens(provider_id, record)
        return record["access_token"]

    return tokens["access_token"]