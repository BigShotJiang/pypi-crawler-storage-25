"""
Speech / text-to-speech provider implementations for AIBrain.

Implements SpeechProvider contract defined in aibrain.core.provider_contract.
Concrete providers: ElevenLabs, OpenAI TTS, and Kokoro Local (offline TTS).

Shape matches provider_anthropic.py: __init__(config), async invoke(request)
returning {url_or_path, model_used, latency_ms}.
"""

import json
import logging
import os
import time
import urllib.request
import urllib.error
import asyncio
from typing import Any, Dict, Optional

from aibrain.core.provider_contract import SpeechProvider

logger = logging.getLogger("aibrain.provider_speech")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ELEVENLABS_API_URL = "https://api.elevenlabs.io/v1/text-to-speech"
OPENAI_TTS_API_URL = "https://api.openai.com/v1/audio/speech"
# Local Kokoro endpoint — default port for kokoro-fastapi or similar wrapper
KOKORO_LOCAL_URL = "http://localhost:8880/v1/audio/speech"

# Model / voice IDs as of 2026-05
MODEL_ELEVENLABS_TURBO = "eleven_turbo_v2_5"
MODEL_ELEVENLABS_MULTILINGUAL = "eleven_multilingual_v2"
MODEL_OPENAI_TTS = "tts-1"
MODEL_OPENAI_TTS_HD = "tts-1-hd"
MODEL_KOKORO = "kokoro-v0.19.4"

VOICE_ELEVENLABS_DEFAULT = "21m00Tcm4TlvDq8ikWAM"  # "Rachel"
VOICE_OPENAI_DEFAULT = "alloy"
VOICE_KOKORO_DEFAULT = "af_heart"

DEFAULT_MODEL_FOR_TASK_CLASS: Dict[str, str] = {
    "speech_natural": MODEL_ELEVENLABS_TURBO,
    "speech_multilingual": MODEL_ELEVENLABS_MULTILINGUAL,
    "speech_fast": MODEL_OPENAI_TTS,
    "speech_hd": MODEL_OPENAI_TTS_HD,
    "speech_local": MODEL_KOKORO,
}

SUPPORTED_TASK_CLASSES = list(DEFAULT_MODEL_FOR_TASK_CLASS.keys())

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class SpeechProviderError(Exception):
    """Raised when a speech provider encounters an error."""

    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_api_key(config: Dict[str, Any], env_var: str) -> str:
    """Extract the API key from config or environment variable."""
    api_key = config.get("api_key") or os.environ.get(env_var)
    if not api_key:
        raise SpeechProviderError(
            f"API key not found in config or {env_var} env var"
        )
    return api_key


def _resolve_model(config: Dict[str, Any], task_class: str) -> str:
    """Determine which model to use for a given task class."""
    model = config.get("model")
    if model:
        return model
    if task_class not in DEFAULT_MODEL_FOR_TASK_CLASS:
        raise SpeechProviderError(
            f"Unsupported task_class '{task_class}'. "
            f"Supported: {SUPPORTED_TASK_CLASSES}"
        )
    return DEFAULT_MODEL_FOR_TASK_CLASS[task_class]


def _call_speech_http(
    api_url: str,
    api_key: str,
    headers_extra: Dict[str, str],
    body: Dict[str, Any],
    timeout: int = 120,
) -> Dict[str, Any]:
    """Synchronous HTTP call to a TTS API.

    Returns a dict with keys: url_or_path, model_used, latency_ms.
    Audio is saved to a temp file; its path is returned.
    """
    headers = {
        "Content-Type": "application/json",
    }
    headers.update(headers_extra)

    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(api_url, data=data, headers=headers, method="POST")

    start = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            audio_bytes = resp.read()
            elapsed_ms = (time.monotonic() - start) * 1000.0
    except urllib.error.HTTPError as exc:
        err_body = exc.read().decode("utf-8", errors="replace")
        raise SpeechProviderError(
            f"Speech API HTTP {exc.code}: {err_body}"
        ) from exc
    except Exception as exc:
        raise SpeechProviderError(f"Speech API request failed: {exc}") from exc

    # Determine file extension from Content-Type header or default to .mp3
    content_type = ""
    if hasattr(resp, "headers"):
        content_type = resp.headers.get("Content-Type", "")
    ext = ".mp3"
    if "ogg" in content_type or "opus" in content_type:
        ext = ".ogg"
    elif "wav" in content_type:
        ext = ".wav"
    elif "aac" in content_type:
        ext = ".aac"
    elif "flac" in content_type:
        ext = ".flac"

    import tempfile
    tmp = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
    tmp.write(audio_bytes)
    tmp.close()

    model_used = body.get("model", "unknown")

    return {
        "url_or_path": tmp.name,
        "model_used": model_used,
        "latency_ms": round(elapsed_ms, 2),
    }


# ---------------------------------------------------------------------------
# ElevenLabsProvider
# ---------------------------------------------------------------------------


class ElevenLabsProvider(SpeechProvider):
    """Concrete SpeechProvider backed by ElevenLabs TTS API.

    Uses the ElevenLabs text-to-speech endpoint with voice cloning
    and multilingual support.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "ELEVENLABS_API_KEY")
        task_class = request.get("task_class", "speech_natural")
        model = _resolve_model(config, task_class)

        text = request.get("text", "")
        voice = request.get("voice", config.get("voice", VOICE_ELEVENLABS_DEFAULT))
        speed = request.get("speed", 1.0)

        # ElevenLabs URL pattern: /v1/text-to-speech/{voice_id}
        api_url = f"{ELEVENLABS_API_URL}/{voice}"

        body = {
            "text": text,
            "model_id": model,
            "voice_settings": {
                "stability": request.get("stability", 0.5),
                "similarity_boost": request.get("similarity_boost", 0.75),
                "speed": speed,
            },
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_speech_http,
            api_url,
            api_key,
            {
                "xi-api-key": api_key,
                "Accept": "audio/mpeg",
            },
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "ELEVENLABS_API_KEY")
        task_class = request.get("task_class", "speech_natural")
        model = _resolve_model(config, task_class)

        voice = request.get("voice", config.get("voice", VOICE_ELEVENLABS_DEFAULT))
        api_url = f"{ELEVENLABS_API_URL}/{voice}"

        body = {
            "text": request.get("text", ""),
            "model_id": model,
            "voice_settings": {
                "stability": request.get("stability", 0.5),
                "similarity_boost": request.get("similarity_boost", 0.75),
                "speed": request.get("speed", 1.0),
            },
        }

        return _call_speech_http(
            api_url,
            api_key,
            {"xi-api-key": api_key, "Accept": "audio/mpeg"},
            body,
        )


# ---------------------------------------------------------------------------
# OpenAITTSProvider
# ---------------------------------------------------------------------------


class OpenAITTSProvider(SpeechProvider):
    """Concrete SpeechProvider backed by OpenAI TTS API.

    Uses the OpenAI audio/speech endpoint with multiple voice options.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "OPENAI_API_KEY")
        task_class = request.get("task_class", "speech_fast")
        model = _resolve_model(config, task_class)

        text = request.get("text", "")
        voice = request.get("voice", config.get("voice", VOICE_OPENAI_DEFAULT))
        speed = request.get("speed", 1.0)

        body = {
            "model": model,
            "input": text,
            "voice": voice,
            "speed": speed,
            "response_format": request.get("format", "mp3"),
        }

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            _call_speech_http,
            OPENAI_TTS_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )
        return result

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        api_key = _get_api_key(config, "OPENAI_API_KEY")
        task_class = request.get("task_class", "speech_fast")
        model = _resolve_model(config, task_class)

        body = {
            "model": model,
            "input": request.get("text", ""),
            "voice": request.get("voice", config.get("voice", VOICE_OPENAI_DEFAULT)),
            "speed": request.get("speed", 1.0),
            "response_format": request.get("format", "mp3"),
        }

        return _call_speech_http(
            OPENAI_TTS_API_URL,
            api_key,
            {"Authorization": f"Bearer {api_key}"},
            body,
        )


# ---------------------------------------------------------------------------
# KokoroLocalProvider
# ---------------------------------------------------------------------------


class KokoroLocalProvider(SpeechProvider):
    """Concrete SpeechProvider backed by local Kokoro TTS (offline).

    No API key required — connects to a local Kokoro endpoint
    (default http://localhost:8880/v1/audio/speech, OpenAI-compatible).
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}

    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        task_class = request.get("task_class", "speech_local")
        model = _resolve_model(config, task_class)

        endpoint = config.get("endpoint", KOKORO_LOCAL_URL)
        text = request.get("text", "")
        voice = request.get("voice", config.get("voice", VOICE_KOKORO_DEFAULT))
        speed = request.get("speed", 1.0)

        body = {
            "model": model,
            "input": text,
            "voice": voice,
            "speed": speed,
            "response_format": request.get("format", "wav"),
        }

        start = time.monotonic()
        try:
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                audio_bytes = resp.read()
                elapsed_ms = (time.monotonic() - start) * 1000.0
        except Exception as exc:
            raise SpeechProviderError(f"Kokoro local request failed: {exc}") from exc

        import tempfile
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp.write(audio_bytes)
        tmp.close()

        return {
            "url_or_path": tmp.name,
            "model_used": model,
            "latency_ms": round(elapsed_ms, 2),
        }

    def _invoke_sync(self, request: Dict[str, Any]) -> Dict[str, Any]:
        config = self.config or {}
        task_class = request.get("task_class", "speech_local")
        model = _resolve_model(config, task_class)

        endpoint = config.get("endpoint", KOKORO_LOCAL_URL)

        body = {
            "model": model,
            "input": request.get("text", ""),
            "voice": request.get("voice", config.get("voice", VOICE_KOKORO_DEFAULT)),
            "speed": request.get("speed", 1.0),
            "response_format": request.get("format", "wav"),
        }

        start = time.monotonic()
        try:
            data = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                audio_bytes = resp.read()
                elapsed_ms = (time.monotonic() - start) * 1000.0
        except Exception as exc:
            raise SpeechProviderError(f"Kokoro local request failed: {exc}") from exc

        import tempfile
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp.write(audio_bytes)
        tmp.close()

        return {
            "url_or_path": tmp.name,
            "model_used": model,
            "latency_ms": round(elapsed_ms, 2),
        }


# ---------------------------------------------------------------------------
# Smoke test (instantiation only — no API calls, no keys required)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Instantiate all providers with minimal/dummy config
    elevenlabs = ElevenLabsProvider(config={"api_key": "dummy-elevenlabs-key"})
    openai_tts = OpenAITTSProvider(config={"api_key": "dummy-openai-key"})
    kokoro = KokoroLocalProvider()

    # Verify they are instances of SpeechProvider
    assert isinstance(elevenlabs, SpeechProvider), "ElevenLabsProvider must be SpeechProvider"
    assert isinstance(openai_tts, SpeechProvider), "OpenAITTSProvider must be SpeechProvider"
    assert isinstance(kokoro, SpeechProvider), "KokoroLocalProvider must be SpeechProvider"

    # Verify DEFAULT_MODEL_FOR_TASK_CLASS has expected entries
    assert "speech_natural" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "speech_multilingual" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "speech_fast" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "speech_hd" in DEFAULT_MODEL_FOR_TASK_CLASS
    assert "speech_local" in DEFAULT_MODEL_FOR_TASK_CLASS

    # Verify model constants
    assert MODEL_OPENAI_TTS_HD == "tts-1-hd"
    assert MODEL_ELEVENLABS_TURBO == "eleven_turbo_v2_5"

    print("provider_speech smoke test OK")
