"""
Minimal circuit breaker for external API calls.
States: CLOSED (normal) → OPEN (tripped, fast-fail) → HALF_OPEN (testing recovery)
Thread-safe via threading.Lock().
"""
import threading
import time
import logging
from dataclasses import dataclass, field
from typing import Callable, Any

log = logging.getLogger("aibrain.circuit_breaker")


@dataclass
class CircuitBreaker:
    name: str
    failure_threshold: int = 5       # failures before OPEN
    recovery_timeout: float = 60.0   # seconds before HALF_OPEN
    _failures: int = field(default=0, init=False, repr=False)
    _state: str = field(default="CLOSED", init=False, repr=False)
    _opened_at: float = field(default=0.0, init=False, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def call(self, fn: Callable, *args, **kwargs) -> Any:
        with self._lock:
            if self._state == "OPEN":
                if time.monotonic() - self._opened_at > self.recovery_timeout:
                    self._state = "HALF_OPEN"
                    log.info("circuit_breaker[%s]: HALF_OPEN — testing recovery", self.name)
                else:
                    raise RuntimeError(f"Circuit breaker [{self.name}] OPEN — fast-failing")
        try:
            result = fn(*args, **kwargs)
            with self._lock:
                if self._state == "HALF_OPEN":
                    self._state = "CLOSED"
                    self._failures = 0
                    log.info("circuit_breaker[%s]: CLOSED — recovered", self.name)
                elif self._state == "CLOSED":
                    self._failures = 0  # reset on success
            return result
        except Exception as exc:
            with self._lock:
                self._failures += 1
                if self._failures >= self.failure_threshold:
                    self._state = "OPEN"
                    self._opened_at = time.monotonic()
                    log.error(
                        "circuit_breaker[%s]: OPEN after %d failures. Last: %s",
                        self.name, self._failures, exc,
                    )
            raise


# Module-level singletons — one breaker per external service
_telegram_cb = CircuitBreaker("telegram", failure_threshold=3, recovery_timeout=120.0)
_stripe_cb   = CircuitBreaker("stripe",   failure_threshold=5, recovery_timeout=300.0)
_github_cb   = CircuitBreaker("github",   failure_threshold=5, recovery_timeout=300.0)


def telegram_call(fn: Callable, *args, **kwargs) -> Any:
    """Wrap any Telegram API call through the shared circuit breaker."""
    return _telegram_cb.call(fn, *args, **kwargs)


def stripe_call(fn: Callable, *args, **kwargs) -> Any:
    """Wrap any Stripe API call through the shared circuit breaker."""
    return _stripe_cb.call(fn, *args, **kwargs)


def github_call(fn: Callable, *args, **kwargs) -> Any:
    """Wrap any GitHub API call through the shared circuit breaker."""
    return _github_cb.call(fn, *args, **kwargs)
