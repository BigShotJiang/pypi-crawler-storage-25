"""
Provider-agnostic dispatch interface for AI Brain.

This module defines the abstract base classes and router that form the
provider contract. Every dispatch backend (text, image, video, speech,
review) must implement the corresponding abstract class. The router
reads user configuration from ~/.aibrain/config.yaml to determine which
concrete provider to return for a given task class.

Concrete provider implementations are wired in separately (Step 7).
No provider names are hard-coded as defaults anywhere in this layer.
"""

from __future__ import annotations

import abc
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VALID_TEXT_TASK_CLASSES: list[str] = ["cheap", "judgment", "review"]
DEFAULT_CONFIG_PATH: Path = Path.home() / ".aibrain" / "config.yaml"

# Provider name → (text_module, text_class, review_module, review_class,
# image_module, image_class, video_module, video_class, speech_module,
# speech_class).
# Concrete provider modules live in aibrain.core.provider_<name>. Lazy-imported
# at get_provider() call time so installing only one provider does not pull in
# unrelated SDK dependencies. Review class can be None if the provider does
# not implement a separate ReviewProvider (text provider is used as fallback).
# Image/video/speech classes can be None for text-only providers.
_PROVIDER_REGISTRY: Dict[str, Dict[str, Optional[str]]] = {
    # ── Text providers ──────────────────────────────────────────────
    "anthropic": {
        "text_module": "aibrain.core.provider_anthropic",
        "text_class": "AnthropicTextProvider",
        "review_module": "aibrain.core.provider_anthropic",
        "review_class": "AnthropicReviewProvider",
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    "openai": {
        "text_module": "aibrain.core.provider_openai",
        "text_class": "OpenAITextProvider",
        "review_module": "aibrain.core.provider_openai",
        "review_class": "OpenAIReviewProvider",
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": "aibrain.core.provider_speech",
        "speech_class": "OpenAITTSProvider",
    },
    "deepseek": {
        "text_module": "aibrain.core.provider_deepseek",
        "text_class": "DeepSeekTextProvider",
        "review_module": "aibrain.core.provider_deepseek",
        "review_class": "DeepSeekReviewProvider",
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    "ollama_local": {
        "text_module": "aibrain.core.provider_ollama",
        "text_class": "OllamaTextProvider",
        "review_module": "aibrain.core.provider_ollama",
        "review_class": "OllamaReviewProvider",
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    # Alias — "ollama" name accepted as shorthand for "ollama_local" so callers
    # like LucyAgent(provider='ollama', ...) resolve cleanly. F-LUCY-CHAT-VIA-
    # PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21).
    "ollama": {
        "text_module": "aibrain.core.provider_ollama",
        "text_class": "OllamaTextProvider",
        "review_module": "aibrain.core.provider_ollama",
        "review_class": "OllamaReviewProvider",
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    # OpenRouter — single API key, 300+ models. The ``model`` slug picks
    # the underlying backend (e.g. google/gemini-2.5-pro, x-ai/grok-2,
    # anthropic/claude-sonnet-4-5). No separate Review class — the same
    # text provider can serve review traffic by selecting a strong slug.
    # F-LUCY-OPENROUTER-PROVIDER (-8uh_KYt9F8, 2026-05-21).
    "openrouter": {
        "text_module": "aibrain.core.provider_openrouter",
        "text_class": "OpenRouterTextProvider",
        "review_module": "aibrain.core.provider_openrouter",
        "review_class": "OpenRouterTextProvider",
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    # Direct Google Gemini — free-tier path (1500 req/day on
    # gemini-2.5-flash, 50 req/day on gemini-2.5-pro at zero cost via
    # aistudio.google.com). Non-OpenAI wire format — chat_with_tools()
    # translates messages/tools/responses to/from OpenAI shape inside the
    # provider (same pattern as anthropic). F-LUCY-GEMINI-PROVIDER
    # (-JSHGYiAy8g, 2026-05-21).
    "gemini": {
        "text_module": "aibrain.core.provider_gemini",
        "text_class": "GeminiTextProvider",
        "review_module": "aibrain.core.provider_gemini",
        "review_class": "GeminiReviewProvider",
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    # ── Image providers ─────────────────────────────────────────────
    "flux": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": "aibrain.core.provider_image",
        "image_class": "FluxImageProvider",
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    "recraft": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": "aibrain.core.provider_image",
        "image_class": "RecraftImageProvider",
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    "imagen": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": "aibrain.core.provider_image",
        "image_class": "ImagenImageProvider",
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    "sdxl_local": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": "aibrain.core.provider_image",
        "image_class": "SDXLLocalImageProvider",
        "video_module": None,
        "video_class": None,
        "speech_module": None,
        "speech_class": None,
    },
    # ── Video providers ─────────────────────────────────────────────
    "veo3": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": None,
        "image_class": None,
        "video_module": "aibrain.core.provider_video",
        "video_class": "Veo3VideoProvider",
        "speech_module": None,
        "speech_class": None,
    },
    "kling": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": None,
        "image_class": None,
        "video_module": "aibrain.core.provider_video",
        "video_class": "KlingVideoProvider",
        "speech_module": None,
        "speech_class": None,
    },
    "runway": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": None,
        "image_class": None,
        "video_module": "aibrain.core.provider_video",
        "video_class": "RunwayGen3VideoProvider",
        "speech_module": None,
        "speech_class": None,
    },
    "cogvideox_local": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": None,
        "image_class": None,
        "video_module": "aibrain.core.provider_video",
        "video_class": "CogVideoXLocalProvider",
        "speech_module": None,
        "speech_class": None,
    },
    # ── Speech providers ────────────────────────────────────────────
    "elevenlabs": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": "aibrain.core.provider_speech",
        "speech_class": "ElevenLabsProvider",
    },
    "kokoro_local": {
        "text_module": None,
        "text_class": None,
        "review_module": None,
        "review_class": None,
        "image_module": None,
        "image_class": None,
        "video_module": None,
        "video_class": None,
        "speech_module": "aibrain.core.provider_speech",
        "speech_class": "KokoroLocalProvider",
    },
}

logger = logging.getLogger("aibrain.provider_contract")


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ProviderConfigError(Exception):
    """Raised when the provider configuration is missing or invalid."""


# ---------------------------------------------------------------------------
# Abstract base provider
# ---------------------------------------------------------------------------

class ProviderContract(abc.ABC):
    """Abstract base for all AI providers.

    Every concrete provider (Anthropic, DeepSeek, Ollama, etc.) must
    implement this interface.  Subclasses further refine the request /
    response schema via docstrings but remain abstract themselves.
    """

    @abc.abstractmethod
    async def invoke(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Invoke the provider with a structured request and return a
        structured response.

        Args:
            request: Provider-specific dictionary.  See concrete
                subclasses for required keys.

        Returns:
            Provider-specific dictionary.  See concrete subclasses for
            guaranteed keys.
        """
        ...


# ---------------------------------------------------------------------------
# Specialised abstract providers (still abstract – no concrete invoke)
# ---------------------------------------------------------------------------

class TextProvider(ProviderContract):
    """Provider for text-generation tasks.

    Required request keys:
        prompt: str          – The user / system prompt.
        max_tokens: int      – Maximum tokens to generate.
        temperature: float   – Sampling temperature (0.0–1.0).

    Required response keys:
        text: str            – The generated text.
        usage: dict          – Token usage with keys "prompt_tokens",
                               "completion_tokens", "total_tokens".

    Valid task_class values: "text_cheap", "text_judgment", "text_review".
    """


class ImageProvider(ProviderContract):
    """Provider for image-generation tasks.

    Required request keys:
        prompt: str          – Description of the desired image.
        size: str            – Image dimensions, e.g. "1024x1024".
        quality: str         – Quality level, e.g. "standard" or "hd".

    Required response keys:
        url: str             – URL of the generated image.
        revised_prompt: str  – The prompt actually used by the model.

    Valid task_class values: "image".
    """


class VideoProvider(ProviderContract):
    """Provider for video-generation tasks.

    Required request keys:
        prompt: str          – Description of the desired video.
        duration: int        – Desired duration in seconds.
        resolution: str      – e.g. "1080p".

    Required response keys:
        url: str             – URL of the generated video.
        status: str          – Generation status, e.g. "completed".

    Valid task_class values: "video".
    """


class SpeechProvider(ProviderContract):
    """Provider for text-to-speech tasks.

    Required request keys:
        text: str            – Text to convert to speech.
        voice: str           – Voice identifier.
        speed: float         – Speaking rate multiplier.

    Required response keys:
        audio_url: str       – URL of the generated audio.
        duration_seconds: float – Length of the audio.

    Valid task_class values: "speech".
    """


class ReviewProvider(ProviderContract):
    """Provider for review / critique tasks.

    Required request keys:
        content: str         – The content to review.
        criteria: list[str]  – List of review criteria.

    Required response keys:
        verdict: str         – Overall verdict, e.g. "pass" / "fail".
        feedback: str        – Detailed feedback.
        score: float         – Numeric score (0.0–1.0).

    Valid task_class values: "text_review".
    """


# ---------------------------------------------------------------------------
# Provider router
# ---------------------------------------------------------------------------

class ProviderRouter:
    """Loads user config and returns the appropriate provider for a task.

    Config is read from ~/.aibrain/config.yaml (or an alternative path).
    The file is expected to follow this layout::

        providers:
          text:
            cheap: <provider_name>
            judgment: <provider_name>
            review: <provider_name>
          image:
            default: <provider_name>
          video:
            default: <provider_name>
          speech:
            default: <provider_name>
          fallback: <provider_name>

    Concrete provider instantiation is **not** performed here – that is
    the responsibility of Step 7 backends.  Until then, ``get_provider``
    raises ``ProviderConfigError`` with a clear placeholder message.
    """

    def __init__(self, config_path: Optional[Path] = None) -> None:
        # Accept both Path and str for config_path; coerce to Path so .exists() works.
        if config_path is None:
            self._config_path = DEFAULT_CONFIG_PATH
        elif isinstance(config_path, Path):
            self._config_path = config_path
        else:
            self._config_path = Path(config_path)
        self._config: Dict[str, Any] = {}
        self.reload()

    # ------------------------------------------------------------------
    def reload(self) -> None:
        """Re-read the configuration file (supports hot-reload)."""
        if not self._config_path.exists():
            logger.warning(
                "Config file %s not found – provider routing will use "
                "fallback or raise ProviderConfigError.",
                self._config_path,
            )
            self._config = {}
            return

        with open(self._config_path, "r", encoding="utf-8") as fh:
            self._config = yaml.safe_load(fh) or {}
        logger.debug("Provider config reloaded from %s", self._config_path)

    # ------------------------------------------------------------------
    def get_provider(self, task_class: str) -> ProviderContract:
        """Return the provider instance configured for *task_class*.

        Args:
            task_class: One of ``"text_cheap"``, ``"text_judgment"``,
                ``"text_review"``, ``"image"``, ``"video"``, ``"speech"``.

        Returns:
            A concrete ``ProviderContract`` subclass instance.

        Raises:
            ProviderConfigError: If no provider is configured for the
                task class and no fallback is defined, OR if the
                concrete backend has not been wired yet (placeholder).
        """
        provider_name = self._resolve_provider_name(task_class)

        # Look up the registry entry for this provider name.
        entry = _PROVIDER_REGISTRY.get(provider_name)
        if entry is None:
            available = sorted(_PROVIDER_REGISTRY.keys())
            raise ProviderConfigError(
                f"Unknown provider '{provider_name}' for task class "
                f"'{task_class}'. Available providers: {available}"
            )

        # Pick the right module/class based on task_class domain.
        # image → image_module/image_class
        # video → video_module/video_class
        # speech → speech_module/speech_class
        # text_review / review → review_module/review_class (falls back to text)
        # everything else (text_cheap, text_judgment, etc.) → text_module/text_class
        if task_class == "image":
            module_name = entry.get("image_module")
            class_name = entry.get("image_class")
        elif task_class == "video":
            module_name = entry.get("video_module")
            class_name = entry.get("video_class")
        elif task_class == "speech":
            module_name = entry.get("speech_module")
            class_name = entry.get("speech_class")
        elif task_class in ("text_review", "review") and entry.get("review_class"):
            module_name = entry["review_module"]
            class_name = entry["review_class"]
        else:
            module_name = entry.get("text_module")
            class_name = entry.get("text_class")

        if not module_name or not class_name:
            raise ProviderConfigError(
                f"Provider '{provider_name}' does not support task class "
                f"'{task_class}' (no {task_class}_module/class in registry)."
            )

        # Lazy import to avoid pulling in every provider's SDK at module load.
        import importlib
        try:
            module = importlib.import_module(module_name)
            provider_cls = getattr(module, class_name)
        except (ImportError, AttributeError) as exc:
            raise ProviderConfigError(
                f"Failed to load concrete provider {module_name}.{class_name}: {exc}"
            ) from exc

        # Build the per-leaf config dict that the provider expects.
        provider_cfg = self._resolve_provider_config(task_class, provider_name)

        try:
            return provider_cls(provider_cfg)
        except Exception as exc:
            raise ProviderConfigError(
                f"Failed to instantiate {class_name} for '{task_class}': {exc}"
            ) from exc

    # ------------------------------------------------------------------
    def _resolve_provider_config(self, task_class: str, provider_name: str) -> dict:
        """Return the config dict for a specific task class.

        The config layout puts model + api_key_env at the leaf (per task class).
        If the task-class-specific config has them, use that. Otherwise fall
        back to the universal fallback_provider section.
        """
        providers_cfg = self._config.get("providers", {})
        leaf: dict = {}

        if task_class.startswith("text_"):
            sub = task_class[len("text_"):]
            text_cfg = providers_cfg.get("text", {}).get(sub, {})
            if isinstance(text_cfg, dict):
                leaf = dict(text_cfg)
        elif task_class in ("image", "video", "speech"):
            section = providers_cfg.get(task_class, {}).get("default", {})
            if isinstance(section, dict):
                leaf = dict(section)

        # If user wrote the leaf as just a provider name string instead of a
        # dict, the leaf will be empty here. Use the fallback section to fill
        # in model + api_key_env.
        if not leaf or "model" not in leaf:
            fallback = self._config.get("fallback_provider", {}) or {}
            for key in ("model", "api_key_env", "endpoint_override"):
                if key not in leaf and key in fallback:
                    leaf[key] = fallback[key]

        # Always include the resolved provider name.
        leaf.setdefault("name", provider_name)
        return leaf

    # ------------------------------------------------------------------
    def _resolve_provider_name(self, task_class: str) -> str:
        """Map a *task_class* to the user-configured provider name.

        Returns the fallback provider name if the specific task class is
        not configured.
        """
        providers_cfg = self._config.get("providers", {})

        # Helper: extract provider name from either a string or a dict leaf.
        def _name_of(value):
            if isinstance(value, str):
                return value
            if isinstance(value, dict):
                return value.get("name", "")
            return ""

        # Text sub-tasks -------------------------------------------------
        if task_class.startswith("text_"):
            sub = task_class[len("text_"):]  # cheap, judgment, review
            text_cfg = providers_cfg.get("text", {})
            if sub in text_cfg:
                name = _name_of(text_cfg[sub])
                if name:
                    return name

        # Image / Video / Speech -----------------------------------------
        elif task_class in ("image", "video", "speech"):
            section = providers_cfg.get(task_class, {})
            if "default" in section:
                name = _name_of(section["default"])
                if name:
                    return name

        # Fallback (two layouts supported: top-level fallback_provider OR
        # providers.fallback) ---------------------------------------------
        fallback = self._config.get("fallback_provider") or providers_cfg.get("fallback")
        if fallback:
            name = _name_of(fallback)
            if name:
                logger.debug(
                    "No explicit provider for '%s' – using fallback '%s'",
                    task_class,
                    name,
                )
                return name

        raise ProviderConfigError(
            f"No provider configured for task class '{task_class}' and "
            f"no fallback defined in {self._config_path}."
        )


# ---------------------------------------------------------------------------
# Shared review response parser
# ---------------------------------------------------------------------------
# Lifted from companies.py _parse_liaison_verdict so ALL ReviewProvider
# implementations use the same parser. Drift in parsers = drift in gate
# behaviour across providers.

import re as _re

_VERDICT_RE = _re.compile(
    r"(?im)^\s*\**\s*VERDICT\s*:?\s*\**\s*(PASS|FAIL)\b"
)
_SCORE_RE = _re.compile(
    r"(?im)^\s*\**\s*SCORE\s*:?\s*\**\s*([01](?:\.\d+)?|\d{1,3}(?:\.\d+)?%?)"
)
_CRITIQUE_RE = _re.compile(
    r"(?ims)^\s*\**\s*CRITIQUE\s*:?\s*\**\s*(.+?)\s*$"
)


class ReviewParseError(Exception):
    """Raised when a review response cannot be parsed."""


def parse_review_response(content: str) -> dict:
    """Parse a review model response into {verdict, score, critique}.

    Tolerates: optional bold/italic markdown around labels, extra
    whitespace, case variation, percentage scores ("87%"), ratio scores
    ("0.87/1.0"), and multi-line critique blocks.

    Returns:
        {"verdict": "PASS"|"FAIL", "score": float, "critique": str}

    Raises:
        ReviewParseError: if VERDICT or SCORE lines are missing or the
            SCORE value cannot be parsed as a float in [0.0, 1.0].
    """
    if not content or not content.strip():
        raise ReviewParseError(
            "Empty review response — cannot parse verdict."
        )

    m_v = _VERDICT_RE.search(content)
    if not m_v:
        raise ReviewParseError(
            f"No VERDICT line found in review output. "
            f"Raw (first 500 chars): {content[:500]!r}"
        )
    verdict = m_v.group(1).upper()

    m_s = _SCORE_RE.search(content)
    if not m_s:
        raise ReviewParseError(
            f"No SCORE line found in review output. "
            f"Raw (first 500 chars): {content[:500]!r}"
        )
    raw_score = m_s.group(1).strip()
    try:
        if raw_score.endswith("%"):
            score = float(raw_score[:-1]) / 100.0
        else:
            parts = raw_score.split("/")
            if len(parts) == 2:
                numerator = float(parts[0])
                denominator = float(parts[1])
                if denominator > 1.0:
                    score = numerator / denominator
                else:
                    score = numerator
            else:
                score = float(parts[0])
        score = max(0.0, min(1.0, score))
    except ValueError:
        raise ReviewParseError(
            f"SCORE value '{raw_score}' is not a float in [0.0, 1.0]."
        )

    m_c = _CRITIQUE_RE.search(content)
    if m_c:
        idx = m_c.start(1)
        critique = content[idx:].strip()
    else:
        critique = "(No CRITIQUE block in review output.)"

    return {"verdict": verdict, "score": score, "critique": critique}


# ---------------------------------------------------------------------------
# Chat dispatch — provider-agnostic chat-with-tools (F-LUCY-CHAT-VIA-
# PROVIDER-ROUTER, cs9PZGiubRI, 2026-05-21).
# ---------------------------------------------------------------------------
# The router exposes one dispatch_chat() entry point that takes an OpenAI-
# shaped {messages, tools, tool_choice, model, ...} request and returns an
# OpenAI-shaped response (SimpleNamespace mimicking openai SDK's
# ChatCompletion.choices[0].message). Each provider implements
# chat_with_tools(...) translating to/from its native wire format.
#
# This is the single source of truth for Lucy's chat path: no more per-
# provider OpenAI-SDK base_url switching in lucy_agent.py.

from types import SimpleNamespace as _SimpleNamespace


def make_openai_shaped_response(
    content: str,
    tool_calls: Optional[list] = None,
    role: str = "assistant",
    model: str = "",
    finish_reason: str = "stop",
    usage: Optional[Dict[str, int]] = None,
    reasoning_content: Optional[str] = None,
) -> Any:
    """Build an OpenAI-SDK-compatible ChatCompletion response shape.

    Lucy's chat loop reads resp.choices[0].message.{content,tool_calls,role}
    and calls _msg.model_dump() to serialise back into the messages list.

    Returns a SimpleNamespace with:
      .choices[0].message.{role, content, tool_calls, model_dump()}
      .model
      .usage.{prompt_tokens, completion_tokens, total_tokens}

    Args:
      content: assistant text content (may be empty string if only tool_calls).
      tool_calls: list of SimpleNamespace tool-call objects each with
        .id (str), .type='function', .function.{name, arguments(json string)}.
        Pass None or [] for a text-only response.
      role: usually 'assistant'.
      model: model identifier echoed in the response.
      finish_reason: 'stop' | 'tool_calls' | etc.
      usage: optional token-count dict.
    """
    tc_list = list(tool_calls) if tool_calls else None

    def _msg_dump():
        # Mirror openai SDK's pydantic .model_dump() so messages_with_tools.append
        # works without surprises. Drop the None tool_calls so providers that
        # didn't emit any don't pollute the wire with an empty array.
        d: Dict[str, Any] = {"role": role, "content": content or None}
        if tc_list:
            d["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in tc_list
            ]
        if reasoning_content is not None:
            d["reasoning_content"] = reasoning_content
        return d

    msg = _SimpleNamespace(
        role=role,
        content=content,
        tool_calls=tc_list,
        reasoning_content=reasoning_content,
        model_dump=_msg_dump,
    )
    choice = _SimpleNamespace(
        message=msg,
        finish_reason=finish_reason,
        index=0,
    )
    return _SimpleNamespace(
        choices=[choice],
        model=model,
        usage=_SimpleNamespace(
            prompt_tokens=(usage or {}).get("prompt_tokens", 0),
            completion_tokens=(usage or {}).get("completion_tokens", 0),
            total_tokens=(usage or {}).get("total_tokens", 0),
        ),
    )


def make_tool_call(call_id: str, name: str, arguments_json: str) -> Any:
    """Build a single SimpleNamespace tool-call object matching openai SDK shape.

    .id, .type='function', .function.{name, arguments (str JSON)}.
    """
    return _SimpleNamespace(
        id=call_id,
        type="function",
        function=_SimpleNamespace(name=name, arguments=arguments_json),
    )


def _stream_response_from_text(text: str, model: str = "") -> Any:
    """Build a minimal iterable mimicking openai SDK streaming output.

    Yields a single chunk with .choices[0].delta.content = text. Lucy's
    _stream_wrapped() iterates chunk.choices[0].delta.content — this lets
    non-streaming providers participate in the streaming code path.
    """

    class _Stream:
        def __init__(self, _text: str, _model: str):
            self._text = _text
            self._model = _model
            self._done = False

        def __iter__(self):
            return self

        def __next__(self):
            if self._done:
                raise StopIteration
            self._done = True
            choice = _SimpleNamespace(
                delta=_SimpleNamespace(content=self._text),
                finish_reason="stop",
                index=0,
            )
            return _SimpleNamespace(choices=[choice], model=self._model)

    return _Stream(text, model)


# Provider name aliases for dispatch_chat — accept both registry names and
# common shorthand. Maps user-facing name -> registry key.
_CHAT_PROVIDER_ALIASES: Dict[str, str] = {
    "anthropic": "anthropic",
    "openai": "openai",
    "deepseek": "deepseek",
    "ollama": "ollama",
    "ollama_local": "ollama_local",
    # F-LUCY-OPENROUTER-PROVIDER (-8uh_KYt9F8, 2026-05-21).
    "openrouter": "openrouter",
    # F-LUCY-GEMINI-PROVIDER (-JSHGYiAy8g, 2026-05-21).
    "gemini": "gemini",
}


def dispatch_chat(
    provider: str,
    model: str,
    messages: list,
    tools: Optional[list] = None,
    tool_choice: Optional[Any] = None,
    api_key: Optional[str] = None,
    stream: bool = False,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    **extra: Any,
) -> Any:
    """Provider-agnostic chat dispatch (the single chat entry point).

    Args:
      provider: 'anthropic' | 'openai' | 'deepseek' | 'ollama'.
      model: model identifier (provider-specific, e.g. 'gpt-4o-mini',
        'claude-sonnet-4-6', 'deepseek-chat', 'llama3.2:3b').
      messages: OpenAI-shaped [{'role': ..., 'content': ...}, ...] including
        tool-result messages with role='tool'.
      tools: optional list of OpenAI-shaped tool definitions
        ({'type': 'function', 'function': {...}}). Passed through if the
        provider supports tools; ignored otherwise.
      tool_choice: 'auto' | None | dict — passed through to the provider.
      api_key: explicit credential override (env vars used otherwise).
      stream: True returns an iterable yielding OpenAI-shaped chunks.
      temperature, max_tokens: standard sampling params.
      **extra: passed to provider implementation untouched.

    Returns:
      OpenAI-shaped response (see make_openai_shaped_response) when
      stream=False, or an iterable of streaming chunks when stream=True.

    Raises:
      ProviderConfigError: unknown provider.
      Per-provider errors propagate untouched.
    """
    name = _CHAT_PROVIDER_ALIASES.get(provider, provider)
    entry = _PROVIDER_REGISTRY.get(name)
    if entry is None or not entry.get("text_module"):
        raise ProviderConfigError(
            f"Unknown chat provider '{provider}'. "
            f"Supported: {sorted(_CHAT_PROVIDER_ALIASES.keys())}"
        )

    import importlib
    module = importlib.import_module(entry["text_module"])
    text_cls = getattr(module, entry["text_class"])
    cfg = {"api_key": api_key} if api_key else {}
    if model:
        cfg["model"] = model
    instance = text_cls(cfg)

    # Each text provider must expose chat_with_tools(...). If the provider
    # has not been upgraded yet, raise a clear error rather than silently
    # falling back to a text-only invoke().
    fn = getattr(instance, "chat_with_tools", None)
    if fn is None:
        raise ProviderConfigError(
            f"Provider '{name}' has no chat_with_tools() — chat dispatch "
            f"unavailable for this provider."
        )

    # F-LUCY-PROVIDER-COST-TRACKING-1 (JWSMNScnUEw, 2026-05-22): record a
    # row in routing_outcomes after each chat call so `aibrain usage` can
    # surface per-provider spend. NEVER raise from the tracking path —
    # cost recording must not break the chat path.
    import time as _time
    _t0 = _time.monotonic()
    response = fn(
        model=model,
        messages=messages,
        tools=tools,
        tool_choice=tool_choice,
        api_key=api_key,
        stream=stream,
        temperature=temperature,
        max_tokens=max_tokens,
        **extra,
    )
    _latency_ms = int((_time.monotonic() - _t0) * 1000)

    # Skip outcome recording for streaming responses — usage data is not
    # surfaced on the streaming chunks. The downstream consumer can call
    # record_routing_outcome() manually after stream collection if needed.
    if not stream:
        try:
            _usage = getattr(response, "usage", None)
            _pt = int(getattr(_usage, "prompt_tokens", 0) or 0) if _usage else 0
            _ct = int(getattr(_usage, "completion_tokens", 0) or 0) if _usage else 0
            # routing_outcomes write — fully isolated from chat path on any error.
            from aibrain.core.provider_pricing import record_routing_outcome as _rro
            _rro(
                provider=name,
                model=model,
                prompt_tokens=_pt,
                completion_tokens=_ct,
                latency_ms=_latency_ms,
                task_type=str(extra.get("task_type", "chat")),
                session_id=extra.get("session_id"),
                metadata={
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "has_tools": bool(tools),
                },
            )
        except Exception as _track_err:  # noqa: BLE001
            logger.warning(
                "routing_outcomes record failed (non-fatal): %s",
                _track_err,
            )

    return response


# Mount dispatch_chat as a method on ProviderRouter too, so callers that
# hold a router instance can use it without an extra import.
def _router_dispatch_chat(self, provider, model, messages, **kw):
    return dispatch_chat(provider, model, messages, **kw)


ProviderRouter.dispatch_chat = _router_dispatch_chat  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Smoke test (run with: python -m aibrain.core.provider_contract)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # 1. Router instantiation must not crash even if config is missing.
    router = ProviderRouter()
    print("ProviderRouter instantiated OK")

    # 2. ABC enforcement – cannot instantiate abstract classes.
    try:
        ProviderContract()  # type: ignore[abstract]
        raise AssertionError("ProviderContract should not be instantiable")
    except TypeError:
        print("ProviderContract ABC enforcement OK")

    try:
        TextProvider()  # type: ignore[abstract]
        raise AssertionError("TextProvider should not be instantiable")
    except TypeError:
        print("TextProvider ABC enforcement OK")

    # 3. Constants
    assert VALID_TEXT_TASK_CLASSES == ["cheap", "judgment", "review"]
    print("VALID_TEXT_TASK_CLASSES OK")

    print("provider_contract smoke test OK")