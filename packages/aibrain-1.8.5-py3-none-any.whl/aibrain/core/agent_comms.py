"""agent_comms.py — F-COMMS-1: inter-agent pub/sub + direct-RPC over CloudEvents.

Extends NATSBroker with CloudEvents 1.0 message schema, agent registry,
topic-based pub/sub, and direct-RPC (request/reply).

Usage:
    from aibrain.core.agent_comms import FleetBus

    bus = FleetBus(agent_id="fix_agent")
    bus.publish("fleet.fix.complete", {"task_id": "...", "finding_id": "..."})
    sub_id = bus.subscribe("fleet.fix.*", lambda msg: print(msg))
    reply = bus.send_to_agent("qa_agent", {"question": "verify F-42?"})
"""

from __future__ import annotations

import fnmatch
import json
import logging
import os
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

# Lazy import — BrokerClient comes from .broker_nats. Imported only when
# AIBRAIN_BROKER_TRANSPORT=nats. The HTTP transport (default) must work
# without nats-py installed.

log = logging.getLogger("aibrain.agent_comms")

# ---------------------------------------------------------------------------
# CloudEvents 1.0 message schema
# ---------------------------------------------------------------------------

@dataclass
class CloudEvent:
    """CNCF CloudEvents 1.0 message. https://cloudevents.io"""
    specversion: str = "1.0"
    id: str = ""
    source: str = ""
    type: str = ""
    subject: str = ""
    time: str = ""
    datacontenttype: str = "application/json"
    data: dict = field(default_factory=dict)

    @classmethod
    def new(cls, source: str, event_type: str, subject: str,
            data: dict, **kwargs) -> "CloudEvent":
        # F-LUCY-COMMS-ROBUSTNESS-1 / Bug C: pop id from kwargs first so caller
        # can override (used by send_to_agent which wants to track msg_id), and
        # the explicit id= below doesn't clash with a kwargs id= passthrough.
        _id = kwargs.pop("id", None) or str(uuid.uuid4())
        return cls(
            id=_id,
            source=f"agent://{source}",
            type=event_type,
            subject=subject,
            time=datetime.now(timezone.utc).isoformat(),
            data=data,
            **{k: v for k, v in kwargs.items() if k in cls.__dataclass_fields__},
        )

    def to_dict(self) -> dict:
        return {
            "specversion": self.specversion,
            "id": self.id,
            "source": self.source,
            "type": self.type,
            "subject": self.subject,
            "time": self.time,
            "datacontenttype": self.datacontenttype,
            "data": self.data,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "CloudEvent":
        return cls(
            specversion=d.get("specversion", "1.0"),
            id=d.get("id", ""),
            source=d.get("source", ""),
            type=d.get("type", ""),
            subject=d.get("subject", ""),
            time=d.get("time", ""),
            datacontenttype=d.get("datacontenttype", "application/json"),
            data=d.get("data", {}),
        )


# ---------------------------------------------------------------------------
# Agent registry (DB-backed)
# ---------------------------------------------------------------------------

def _get_db(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Get a connection to aibrain.db for agent_registry tables."""
    if db_path is None:
        db_path = os.environ.get("AIBRAIN_ROOT", str(Path.home()))
    db_file = Path(db_path) / "aibrain.db" if not db_path.endswith(".db") else Path(db_path)
    conn = sqlite3.connect(str(db_file))
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_registry_tables(db: sqlite3.Connection):
    """Create agent_endpoints + agent_subscriptions tables. Idempotent."""
    db.executescript("""
        CREATE TABLE IF NOT EXISTS agent_endpoints (
            agent_id TEXT PRIMARY KEY,
            agent_name TEXT NOT NULL,
            status TEXT DEFAULT 'online',
            last_seen_at TEXT,
            registered_at TEXT DEFAULT (datetime('now')),
            capabilities TEXT DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS agent_subscriptions (
            sub_id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            topic_glob TEXT NOT NULL,
            callback_name TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (agent_id) REFERENCES agent_endpoints(agent_id)
        );
        CREATE TABLE IF NOT EXISTS agent_messages (
            msg_id TEXT PRIMARY KEY,
            event_type TEXT NOT NULL,
            source_agent TEXT,
            target_agent TEXT,
            subject TEXT,
            payload TEXT,
            status TEXT DEFAULT 'pending',
            created_at TEXT DEFAULT (datetime('now')),
            delivered_at TEXT,
            ack_at TEXT
        );
    """)
    db.commit()

# ---------------------------------------------------------------------------
# Discord integration (F-DISCORD-SETUP-1)
# ---------------------------------------------------------------------------

import os as _os
import json as _json
import logging as _logging
_discord_log = _logging.getLogger('aibrain.discord')

DISCORD_BOT_TOKEN = _os.environ.get('DISCORD_BOT_TOKEN', '')

def reply_to_discord(channel_id: str, content: str) -> dict:
    """Send a message to a Discord channel via bot API."""
    if not DISCORD_BOT_TOKEN:
        return {"ok": False, "error": "DISCORD_BOT_TOKEN not set"}
    try:
        import urllib.request as _ur
        url = f"https://discord.com/api/v10/channels/{channel_id}/messages"
        payload = _json.dumps({"content": content[:2000]}).encode('utf-8')
        headers = {
            "Authorization": f"Bot {DISCORD_BOT_TOKEN}",
            "Content-Type": "application/json; charset=utf-8",
        }
        req = _ur.Request(url, data=payload, headers=headers, method='POST')
        with _ur.urlopen(req, timeout=10) as r:
            resp = _json.loads(r.read())
            return {"ok": True, "message_id": resp.get("id", "")}
    except Exception as e:
        _discord_log.error("Discord send failed: %s", e)
        return {"ok": False, "error": str(e)}


def _handle_discord_webhook(payload: dict) -> list:
    """Parse a Discord webhook interaction into FleetBus messages."""
    msgs = []
    t = payload.get('type', 0)
    if t == 1:
        return msgs
    if t == 2:
        data = payload.get('data', payload)
        author = data.get('author', data.get('member', {}))
        username = author.get('username', 'discord') if isinstance(author, dict) else 'discord'
        content = data.get('content', '')
        channel = payload.get('channel_id', '')
        msgs.append({
            'source': 'discord:' + username,
            'type': 'discord.message',
            'subject': content[:100] if content else '(empty)',
            'data': {
                'content': content,
                'channel_id': channel,
                'author': username,
                'guild_id': payload.get('guild_id', ''),
            }
        })
    return msgs



# ---------------------------------------------------------------------------
# FleetBus — the main API
# ---------------------------------------------------------------------------

class FleetBus:
    """Inter-agent communication bus. Pub/sub + direct-RPC over CloudEvents."""

    def __init__(self, agent_id: str, broker_url: Optional[str] = None,
                 db_path: Optional[str] = None):
        # F-FLEETBUS-TIER-GATE-PRO-1: gate FleetBus to Pro+ tier.
        # Free tier users get PermissionError on construction.
        try:
            from aibrain_licensing import get_license, TIER_LIMITS
            lic = get_license()
            if not TIER_LIMITS.get(lic.tier, TIER_LIMITS["free"]).get("fleet_bus", False):
                raise PermissionError(
                    f"FleetBus requires Pro tier or higher (current: {lic.tier}). "
                    f"Upgrade at https://myaibrain.org/pricing — $9.95/mo unlocks fleet comms + 200 workflows + skill learning."
                )
        except ImportError:
            pass  # licensing module unavailable (dev environment) — fail-open
        self.agent_id = agent_id
        # F-FLEETBUS-TRANSPORT-SWITCH-1 / F-LUCY-HTTP-BROKER-ADAPTER-1:
        # pick transport via AIBRAIN_BROKER_TRANSPORT env var (fallback BROKER_TRANSPORT).
        # Default "http" — the HTTP broker on port 8765 is the primary transport.
        # "nats" routes through the NATS BrokerClient for deployments with nats-server.
        transport = (
            os.environ.get("AIBRAIN_BROKER_TRANSPORT")
            or os.environ.get("BROKER_TRANSPORT")
            or "http"
        ).strip().lower()
        if transport == "http":
            from aibrain.core.broker_http_adapter import HTTPBrokerClient
            # Pass agent_id through so the adapter's recv loop polls the
            # right queue for THIS bus instance. Without this every FleetBus
            # on a host shared the AGENT_ID env queue regardless of agent_id.
            self._broker = HTTPBrokerClient(
                url=broker_url, subject_prefix="fleet", agent_id=agent_id,
            )
            log.info("FleetBus: using HTTP transport (AIBRAIN_BROKER_TRANSPORT=http)")
        else:
            if transport != "nats":
                log.warning("FleetBus: unknown AIBRAIN_BROKER_TRANSPORT=%r — defaulting to nats", transport)
            from .broker_nats import BrokerClient  # noqa: WPS433 — lazy on NATS path only
            self._broker = BrokerClient(url=broker_url, subject_prefix="fleet")
        self._db_path = db_path or str(Path(os.environ.get("AIBRAIN_ROOT",
                                 str(Path.home()))) / "aibrain.db")
        self._subscribers: dict[str, Callable] = {}  # sub_id → callback
        self._register()

    def _register(self):
        """Self-register in agent_endpoints table on startup."""
        try:
            db = _get_db(self._db_path)
            _ensure_registry_tables(db)
            db.execute(
                """INSERT OR REPLACE INTO agent_endpoints 
                   (agent_id, agent_name, status, last_seen_at)
                   VALUES (?, ?, 'online', datetime('now'))""",
                (self.agent_id, self.agent_id)
            )
            db.commit()
            db.close()
            log.info("FleetBus: agent %s registered", self.agent_id)
        except Exception as e:
            log.warning("FleetBus: agent registry failed (non-fatal): %s", e)

    def _heartbeat(self):
        """Update last_seen_at in agent_endpoints."""
        try:
            db = _get_db(self._db_path)
            db.execute(
                "UPDATE agent_endpoints SET last_seen_at=datetime('now') WHERE agent_id=?",
                (self.agent_id,)
            )
            db.commit()
            db.close()
        except Exception:
            pass

    # ── Pub/Sub ────────────────────────────────────────────────────

    def publish(self, topic: str, data: dict):
        """Publish a CloudEvent to a topic. Non-blocking fire-and-forget."""
        self._heartbeat()
        event = CloudEvent.new(
            source=self.agent_id,
            event_type=topic,
            subject=topic,
            data=data,
        )
        self._store_message(event, target=topic)
        try:
            self._broker.publish(topic, event.to_dict())
            log.debug("FleetBus: published %s → %s (NATS)", topic, event.id)
        except Exception as e:
            log.debug("FleetBus: NATS publish %s unavailable — DB-only delivery: %s", topic, e)

    def subscribe(self, topic_glob: str, callback: Callable[[dict], None]) -> str:
        """Subscribe to a topic glob. Returns subscription_id for unsubscribe.

        topic_glob uses fnmatch: 'fleet.fix.*' matches all fix events.
        """
        sub_id = str(uuid.uuid4())
        self._subscribers[sub_id] = callback

        # Persist in agent_subscriptions
        try:
            db = _get_db(self._db_path)
            _ensure_registry_tables(db)
            db.execute(
                "INSERT INTO agent_subscriptions (sub_id, agent_id, topic_glob) VALUES (?, ?, ?)",
                (sub_id, self.agent_id, topic_glob)
            )
            db.commit()
            db.close()
        except Exception as e:
            log.warning("FleetBus: subscription persist failed: %s", e)

        # NATS subscription
        def handler(msg: dict):
            event = CloudEvent.from_dict(msg)
            if fnmatch.fnmatch(event.type, topic_glob):
                callback(msg)

        try:
            self._broker.subscribe(topic_glob, handler)
            log.info("FleetBus: %s subscribed to %s (sub_id=%s)",
                     self.agent_id, topic_glob, sub_id)
        except Exception as e:
            log.warning("FleetBus: NATS subscribe %s failed: %s", topic_glob, e)

        return sub_id

    def unsubscribe(self, sub_id: str):
        """Remove a subscription."""
        self._subscribers.pop(sub_id, None)
        try:
            db = _get_db(self._db_path)
            db.execute("DELETE FROM agent_subscriptions WHERE sub_id=?", (sub_id,))
            db.commit()
            db.close()
        except Exception:
            pass

    def close(self, timeout: float = 2.0) -> None:
        """Tear down the underlying broker client. After close() the bus is
        unusable — caller must construct a new one. Idempotent.

        Needed by stop_liaison_subscriber() so the long-poll thread inside
        the HTTPBrokerClient actually exits rather than leaking past the
        unsubscribe.
        """
        broker = getattr(self, "_broker", None)
        if broker is None:
            return
        try:
            if hasattr(broker, "close"):
                # Pass timeout if signature accepts it; otherwise call bare.
                try:
                    broker.close(timeout=timeout)
                except TypeError:
                    broker.close()
        except Exception as exc:
            log.warning("FleetBus: broker close failed: %s", exc)
        self._broker = None
        self._subscribers.clear()

    # ── Direct-RPC ─────────────────────────────────────────────────

    def send_to_agent(self, to: str, data: dict,
                      expect_reply: bool = False,
                      timeout: int = 30) -> Optional[dict]:
        """Send a direct message to another agent.

        If expect_reply, polls for reply up to timeout seconds.
        Returns the reply CloudEvent data dict, or None on timeout.
        """
        self._heartbeat()
        msg_id = str(uuid.uuid4())
        event = CloudEvent.new(
            source=self.agent_id,
            event_type="fleet.direct",
            subject=msg_id,
            data={"to": to, "from": self.agent_id, **data},
            id=msg_id,
        )

        # Capture wall-clock timestamp BEFORE store so the reply-poll can
        # filter on messages that arrived after this send.
        import datetime as _dt
        sent_at_iso = _dt.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

        self._store_message(event, target=to, msg_id=msg_id)
        try:
            self._broker.publish(f"direct.{to}", event.to_dict())
            log.debug("FleetBus: direct %s → %s (NATS)", to, event.id)
        except Exception as e:
            log.debug("FleetBus: NATS direct %s unavailable — DB-only delivery: %s", to, e)

        if not expect_reply:
            return None

        # Poll for reply
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            reply = self._poll_reply(msg_id, from_agent=to, since_iso=sent_at_iso)
            if reply:
                return reply
            time.sleep(0.5)

        log.warning("FleetBus: send_to_agent %s reply timeout (%ds)", to, timeout)
        return None

    def _poll_reply(self, request_msg_id: str,
                    from_agent: Optional[str] = None,
                    since_iso: Optional[str] = None) -> Optional[dict]:
        """Check for a reply to a specific request message.

        F-FLEETBUS-REPLY-POLL-FIX-1 (2026-05-23): the original query filtered
        on target_agent=self.agent_id AND status='delivered' AND reply_to in
        payload. All three are wrong for the way Lucy / Case actually reply:
        Lucy publishes to topic 'fleet.message.<recipient>' (target_agent is
        that topic, not the bare agent_id); her message stays status='pending'
        on the recipient side until something reads it; her reply_to is empty
        because she doesn't echo the request msg_id. Real-world replies miss
        every filter. The corrected query: ANY non-system message published
        to fleet.message.<self.agent_id> from `from_agent` after `since_iso`.
        Falls back to the legacy reply_to match when from_agent is unknown.
        """
        try:
            db = _get_db(self._db_path)
            # Path 1: known sender + send timestamp — match topic + sender + time window.
            if from_agent and since_iso:
                inbound_topic = f"fleet.message.{self.agent_id}"
                src_a = from_agent
                src_b = f"agent://{from_agent}" if not from_agent.startswith("agent://") else from_agent
                row = db.execute(
                    """SELECT payload FROM agent_messages
                       WHERE event_type = ?
                         AND (source_agent = ? OR source_agent = ?)
                         AND created_at > ?
                       ORDER BY created_at ASC LIMIT 1""",
                    (inbound_topic, src_a, src_b, since_iso),
                ).fetchone()
                if row:
                    db.close()
                    return json.loads(row["payload"])
            # Path 2 (legacy fallback): reply_to in payload.
            row = db.execute(
                """SELECT payload FROM agent_messages
                   WHERE target_agent=? AND source_agent!='system'
                     AND payload LIKE ?
                   ORDER BY created_at DESC LIMIT 1""",
                (self.agent_id, f'%reply_to%{request_msg_id}%'),
            ).fetchone()
            db.close()
            if row:
                return json.loads(row["payload"])
        except Exception:
            pass
        return None

    # ── Session-Start Poll ─────────────────────────────────────────

    def poll_inbox(self) -> list[dict]:
        """Poll for unread messages. Called at session start / each prompt submit.

        Matches messages: (a) directly addressed to this agent_id,
        (b) addressed to a topic glob this agent subscribes to,
        (c) broadcast to '*'.
        Returns list of message dicts the agent should surface.
        """
        self._heartbeat()
        messages = []
        try:
            db = _get_db(self._db_path)

            # F-COMMS-POLL-ATOMIC-1 (2026-05-12): BEGIN IMMEDIATE serializes
            # concurrent poll_inbox() calls.  SQLite's write lock guarantees
            # only one connection can claim pending messages at a time — the
            # second caller's SELECT sees already-delivered rows and returns
            # nothing. This is the fix for the "steal-on-poll" race condition
            # (task bo3l5K-SUoM): previously SELECT-then-UPDATE was a TOCTOU
            # gap where two FleetBus instances could claim the same message,
            # causing duplicate delivery or dropped messages.
            db.execute("BEGIN IMMEDIATE")

            # Get this agent's subscribed topic globs
            subs = db.execute(
                "SELECT topic_glob FROM agent_subscriptions WHERE agent_id=?", 
                (self.agent_id,)
            ).fetchall()
            topic_globs = [s["topic_glob"] for s in subs]
            
            # Build query: direct messages + topic-matched + broadcasts
            # First, get all pending messages not from self
            rows = db.execute(
                """SELECT * FROM agent_messages 
                   WHERE source_agent != ?
                   AND status='pending'
                   ORDER BY created_at ASC""",
                (f"agent://{self.agent_id}",)
            ).fetchall()
            for row in rows:
                target = row["target_agent"] or ""
                event_type = row["event_type"] or ""

                # F-FLEETBUS-DIRECT-ROUTING-1 (2026-05-23): the original
                # match also OR'd in `fnmatch(event_type, sub_glob)` AND
                # `fnmatch(target, sub_glob)` — meaning ANY agent with a
                # broad sub like fleet.direct.* or fleet.message.* would
                # intercept directed messages addressed to OTHER agents.
                # That caused Scout to pull a `fleet.message.lucy`
                # delivery while Lucy's listener never saw it (the
                # poll_inbox SELECT-then-DELETE pattern means whoever
                # claims it first wins).
                #
                # New rule: for DIRECTED messages (target_agent is a
                # specific non-empty non-* agent_id), ONLY that agent
                # receives — full stop. The topic-glob path only applies
                # to undirected messages (broadcast / event-bus pubs).
                is_directed = target and target != "*" and target != ""
                if is_directed:
                    matched = (target == self.agent_id)
                else:
                    # Undirected: topic-glob subs apply.
                    matched = (
                        target == "*" or
                        any(fnmatch.fnmatch(event_type, g) for g in topic_globs) or
                        any(fnmatch.fnmatch(target, g) for g in topic_globs)
                    )
                if not matched:
                    continue
                
                messages.append({
                    "msg_id": row["msg_id"],
                    "source": row["source_agent"],
                    "type": event_type,
                    "subject": row["subject"],
                    "payload": json.loads(row["payload"]) if row["payload"] else {},
                    "created_at": row["created_at"],
                })
                # Mark delivered
                try:
                    db.execute(
                        "UPDATE agent_messages SET status='delivered', delivered_at=datetime('now') WHERE msg_id=?",
                        (row["msg_id"],)
                    )
                except Exception:
                    pass
            db.commit()  # releases the write lock
            db.close()
        except Exception as e:
            log.debug("FleetBus: inbox poll failed: %s", e)
            try:
                db.execute("ROLLBACK")
            except Exception:
                pass
            try:
                db.close()
            except Exception:
                pass
        return messages

    # ── Internal ───────────────────────────────────────────────────

    def _store_message(self, event: CloudEvent, target: str = "",
                       msg_id: str = ""):
        """Persist message to agent_messages table for delivery tracking."""
        try:
            db = _get_db(self._db_path)
            _ensure_registry_tables(db)
            db.execute(
                """INSERT INTO agent_messages 
                   (msg_id, event_type, source_agent, target_agent, subject, payload)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (msg_id or event.id, event.type, event.source,
                 target, event.subject, json.dumps(event.data))
            )
            db.commit()
            db.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Quick-start helper
# ---------------------------------------------------------------------------

def get_fleet_bus(agent_id: Optional[str] = None) -> FleetBus:
    """Get a FleetBus for the current agent. Reads AGENT_ID from env if not given."""
    agent_id = agent_id or os.environ.get("AGENT_ID", os.environ.get("AI_NAME", "unknown"))
    return FleetBus(agent_id=agent_id)
