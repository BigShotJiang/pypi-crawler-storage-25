"""Cross-host path resolvers for ``decker_system`` + Neuro memory dir.

Runtime modules (``companies.py``, ``hypothesis_queue.py``, ``content_gates.py``)
previously hardcoded ``C:\\Users\\sinde\\decker_system\\...`` which broke Case
on Kali. This module centralizes the resolution policy so the same three-branch
discovery (env var → repo-sibling → HOME-relative → raise) is applied
consistently everywhere.

Resolvers
---------

``resolve_decker_tools_dir()`` — ``decker_system/04_tools``
``resolve_decker_subagents_dir()`` — ``decker_system/02_subagents``
``resolve_decker_meta_dir()`` — ``decker_system/00_meta``
``resolve_memory_dir()`` — Neuro memory dir (HOME-relative, NOT decker_system)

Resolution order for the decker_system resolvers (first hit wins):

  1. ``DECKER_SYSTEM_ROOT`` env var + ``<subdir>`` — operator override.
  2. ``aibrain_db.AIBRAIN_ROOT.parent / decker_system / <subdir>`` —
     canonical "repo-sibling" layout (Case/Kali standard).
  3. ``Path.home() / decker_system / <subdir>`` — HOME-relative layout
     used by Neuro on Windows (``C:\\Users\\sinde\\decker_system``).
  4. ``DeckerSystemPathUnavailable`` raised with an informative message
     naming all three fallbacks so any operator on any host can fix the
     path without reading source.

Resolution order for ``resolve_memory_dir()`` (first hit wins):

  1. ``AIBRAIN_MEMORY_DIR`` env var — operator override.
  2. ``Path.home() / .claude-deckerops / projects / C--Users-sinde / memory``
     — the existing Neuro layout the hardcoded string targeted.
  3. ``Path.home() / .claude / projects / C--Users-sinde / memory`` —
     alternate Claude Code layout (no deckerops shard).
  4. ``MemoryDirUnavailable`` raised with an informative message.

Raising vs returning None
-------------------------

All resolvers raise on failure. Callers that need graceful degradation
(e.g. ``content_gates.check_hold_flag_gate`` treats a missing memory dir
as "skip this gate") wrap the call in ``try/except`` at the use site.
That's strictly better than a mode flag because the failure behavior is
explicit where it matters, not buried in a helper kwarg.
"""
from __future__ import annotations

import os as _os
from pathlib import Path
from typing import Optional


__all__ = [
    "DeckerSystemPathUnavailable",
    "MemoryDirUnavailable",
    "resolve_decker_tools_dir",
    "resolve_decker_subagents_dir",
    "resolve_decker_meta_dir",
    "resolve_memory_dir",
]


class DeckerSystemPathUnavailable(Exception):
    """Raised when no ``decker_system/<subdir>`` candidate resolves.

    Message names the env var override, the repo-sibling layout, AND
    the HOME-relative fallback so any operator on any host can fix the
    path without reading source.
    """


class MemoryDirUnavailable(Exception):
    """Raised when the Neuro memory dir cannot be resolved.

    Used by code that MUST have the memory dir. Callers that treat
    absence as a soft skip should wrap in ``try/except``.
    """


def _resolve_decker_subdir(subdir: str) -> Path:
    """Shared resolution logic for ``decker_system/<subdir>``.

    Not part of the public API — callers use the typed wrappers below
    so the error message can name the specific subdir that failed.
    """
    env_root = _os.environ.get("DECKER_SYSTEM_ROOT")
    if env_root:
        candidate = Path(env_root).expanduser() / subdir
        if candidate.is_dir():
            return candidate

    try:
        from aibrain_db import AIBRAIN_ROOT  # type: ignore
        candidate = Path(AIBRAIN_ROOT).parent / "decker_system" / subdir
        if candidate.is_dir():
            return candidate
    except Exception:
        # aibrain_db import failure or AIBRAIN_ROOT absent — fall through
        # to HOME branch rather than masking the whole resolver.
        pass

    home_candidate = Path.home() / "decker_system" / subdir
    if home_candidate.is_dir():
        return home_candidate

    raise DeckerSystemPathUnavailable(
        f"decker_system/{subdir} not found — set DECKER_SYSTEM_ROOT, place "
        f"decker_system next to the aibrain repo "
        f"(AIBRAIN_ROOT.parent/decker_system), or under HOME/decker_system."
    )


def resolve_decker_tools_dir() -> Path:
    """Discover ``decker_system/04_tools``.

    Raises ``DeckerSystemPathUnavailable`` if no candidate resolves.
    """
    return _resolve_decker_subdir("04_tools")


def resolve_decker_subagents_dir() -> Path:
    """Discover ``decker_system/02_subagents``.

    Raises ``DeckerSystemPathUnavailable`` if no candidate resolves.
    """
    return _resolve_decker_subdir("02_subagents")


def resolve_decker_meta_dir() -> Path:
    """Discover ``decker_system/00_meta``.

    Raises ``DeckerSystemPathUnavailable`` if no candidate resolves.
    """
    return _resolve_decker_subdir("00_meta")


def resolve_memory_dir() -> Path:
    """Discover Neuro's persistent memory directory.

    HOME-relative, NOT under decker_system. The path targets the
    ``.claude-deckerops/projects/C--Users-sinde/memory`` layout Neuro
    currently uses on Windows.

    Raises ``MemoryDirUnavailable`` if no candidate resolves. Callers
    that treat absence as a soft skip should wrap in ``try/except``.
    """
    env_root = _os.environ.get("AIBRAIN_MEMORY_DIR")
    if env_root:
        candidate = Path(env_root).expanduser()
        if candidate.is_dir():
            return candidate

    home = Path.home()
    # Preferred layout: .claude-deckerops shard
    candidate = home / ".claude-deckerops" / "projects" / "C--Users-sinde" / "memory"
    if candidate.is_dir():
        return candidate

    # Alternate layout: plain .claude (no deckerops shard)
    candidate = home / ".claude" / "projects" / "C--Users-sinde" / "memory"
    if candidate.is_dir():
        return candidate

    raise MemoryDirUnavailable(
        "Memory dir not found — set AIBRAIN_MEMORY_DIR, or place memory "
        "files under HOME/.claude-deckerops/projects/C--Users-sinde/memory "
        "or HOME/.claude/projects/C--Users-sinde/memory."
    )


def try_resolve_memory_dir() -> Optional[Path]:
    """Soft variant of ``resolve_memory_dir`` — returns None on failure.

    Convenience wrapper for callers where absence is an acceptable state
    (e.g. ``content_gates.check_hold_flag_gate`` skips the gate cleanly
    if no memory dir is present).
    """
    try:
        return resolve_memory_dir()
    except MemoryDirUnavailable:
        return None
