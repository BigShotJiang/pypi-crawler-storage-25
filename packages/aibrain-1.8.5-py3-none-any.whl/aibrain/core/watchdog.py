"""watchdog.py — F-WATCHDOG-SUPERVISOR-1: stuck-detection + auto-recovery daemon.

For disabled users who cannot manually intervene when Lucy stalls.
Monitors heartbeat signals (last activity timestamp), fires recovery
action if timeout exceeded. Used by lucy_agent.py + fleet daemons.

Disable: set AIBRAIN_WATCHDOG_DISABLED=1 OR create ~/.aibrain/.watchdog_disabled
"""
import logging, threading, time
from pathlib import Path

log = logging.getLogger("aibrain.watchdog")

# Shared heartbeat — any component can call watchdog_heartbeat() to reset
_last_heartbeat = time.monotonic()
_lock = threading.Lock()
_stuck_callbacks = []

WATCHDOG_TIMEOUT = 300  # seconds — configurable via AIBRAIN_WATCHDOG_TIMEOUT

def _is_disabled() -> bool:
    """Check if watchdog is suppressed via env var OR sentinel file."""
    import os
    if os.environ.get("AIBRAIN_WATCHDOG_DISABLED", "").strip() in ("1", "true", "yes"):
        return True
    sentinel = Path.home() / ".aibrain" / ".watchdog_disabled"
    if sentinel.exists():
        return True
    return False

def watchdog_heartbeat() -> None:
    """Signal that the agent is alive. Call from main loop per tick."""
    global _last_heartbeat
    with _lock:
        _last_heartbeat = time.monotonic()

def watchdog_seconds_since_heartbeat() -> float:
    """Seconds since last heartbeat signal."""
    with _lock:
        return time.monotonic() - _last_heartbeat

def on_stuck(callback) -> None:
    """Register a recovery callback for when watchdog fires."""
    _stuck_callbacks.append(callback)

def _check_loop():
    """Background thread: checks heartbeat, fires callbacks if stuck."""
    import os
    if _is_disabled():
        log.info("Watchdog disabled — not starting poll loop")
        return
    timeout = int(os.environ.get("AIBRAIN_WATCHDOG_TIMEOUT", WATCHDOG_TIMEOUT))
    while True:
        time.sleep(10)
        if _is_disabled():
            log.info("Watchdog disabled mid-run — exiting poll loop")
            return
        idle = watchdog_seconds_since_heartbeat()
        if idle > timeout:
            log.warning("Watchdog: agent stuck for %.0fs (timeout=%ds)", idle, timeout)
            for cb in _stuck_callbacks:
                try:
                    cb()
                except Exception as e:
                    log.error("Watchdog callback failed: %s", e)


def start_watchdog():
    """Start the watchdog background thread. Call once at boot."""
    if _is_disabled():
        log.info("Watchdog disabled — not starting background thread")
        return
    t = threading.Thread(target=_check_loop, daemon=True, name="watchdog")
    t.start()
    timeout_val = int(__import__('os').environ.get("AIBRAIN_WATCHDOG_TIMEOUT", WATCHDOG_TIMEOUT))
    log.info("Watchdog started (timeout=%ds)", timeout_val)
