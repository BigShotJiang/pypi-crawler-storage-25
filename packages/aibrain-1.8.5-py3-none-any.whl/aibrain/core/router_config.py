"""router_config.py — F-LUCY-ROUTING-POLICY-CONFIG-1: config-driven LLM routing.

Loads routing policy from ~/.aibrain/router_config.json. Maps task classes to
provider→model chains with fallback.
"""
import json, logging, os
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.router_config")

DEFAULT_CONFIG_PATH = Path.home() / ".aibrain" / "router_config.json"

DEFAULT_CONFIG = {
    "version": 1,
    "policies": {
        "code_gen": {
            "provider": "deepseek",
            "model": "deepseek-chat",
            "fallback_chain": [
                {"provider": "openai", "model": "gpt-4o"},
                {"provider": "anthropic", "model": "claude-sonnet-4-20250514"},
            ]
        },
        "judgment": {
            "provider": "anthropic",
            "model": "claude-sonnet-4-20250514",
            "fallback_chain": [
                {"provider": "openai", "model": "gpt-4o"},
            ]
        },
        "simple": {
            "provider": "deepseek",
            "model": "deepseek-chat",
            "fallback_chain": []
        },
        "complex": {
            "provider": "deepseek",
            "model": "deepseek-reasoner",
            "fallback_chain": [
                {"provider": "anthropic", "model": "claude-sonnet-4-20250514"},
            ]
        },
        "summary": {
            "provider": "deepseek",
            "model": "deepseek-chat",
            "fallback_chain": []
        },
    }
}


def validate_router_config(config: dict) -> tuple[bool, str]:
    """Validate router_config.json schema. Returns (ok, reason)."""
    if not isinstance(config, dict):
        return False, "config must be a dict"
    if "version" not in config:
        return False, "missing 'version' field"
    policies = config.get("policies", {})
    if not isinstance(policies, dict):
        return False, "policies must be a dict"
    for name, policy in policies.items():
        if not isinstance(policy, dict):
            return False, f"policy '{name}' must be a dict"
        if "provider" not in policy:
            return False, f"policy '{name}' missing 'provider'"
        if "model" not in policy:
            return False, f"policy '{name}' missing 'model'"
        fallback = policy.get("fallback_chain", [])
        if not isinstance(fallback, list):
            return False, f"policy '{name}' fallback_chain must be a list"
    return True, "ok"


def load_router_config(path: Optional[Path] = None) -> dict:
    """Load router config from disk. Falls back to DEFAULT_CONFIG if not found."""
    path = path or DEFAULT_CONFIG_PATH
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                config = json.load(f)
            ok, reason = validate_router_config(config)
            if ok:
                return config
            log.warning("Router config invalid: %s — using defaults", reason)
        except Exception as e:
            log.warning("Router config load failed: %s — using defaults", e)
    # Write default if not exists
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
    except Exception:
        pass
    return DEFAULT_CONFIG


def get_policy(task_class: str, config: Optional[dict] = None) -> dict:
    """Get the routing policy for a task class. Returns {"provider": str, "model": str, "fallback_chain": list}."""
    config = config or load_router_config()
    policies = config.get("policies", {})
    return policies.get(task_class, policies.get("simple", {"provider": "deepseek", "model": "deepseek-chat", "fallback_chain": []}))


def reload_config():
    """Force-reload router config from disk. Call after editing router_config.json."""
    return load_router_config()
