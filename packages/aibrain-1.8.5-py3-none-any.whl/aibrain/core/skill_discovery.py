"""aibrain.core.skill_discovery — Auto-discovery of skills, workflows, and tools.

Scans the filesystem and AIBrain memory for skills that aren't yet in
skills.json, then imports them automatically. Runs on startup — no user
instruction needed.

Design principles:
- Idempotent: running twice doesn't duplicate skills
- Multi-format: handles .skill.md, workflow .md, skills.json, and AIBrain memory
- Configurable: discovery paths from config.json, with sensible defaults
- Non-destructive: only adds, never removes or overwrites
- Namespace-aware: tracks which source each skill came from

Usage:
    from aibrain.core.skill_discovery import SkillDiscovery
    sd = SkillDiscovery()
    count = sd.discover_all()  # returns number of new skills imported
"""

from __future__ import annotations

import json
import logging
import os
import re
import sqlite3
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any

log = logging.getLogger(__name__)

# ── Default discovery paths ──────────────────────────────────────────
_DEFAULT_ROOT = Path.home()
_DEFAULT_DISCOVERY_PATHS = [
    # Neuro's skill directory (markdown-based) — under home dir
    str(_DEFAULT_ROOT / "decker_system" / "01_skills"),
    # Workflow definitions
    str(_DEFAULT_ROOT / "decker_system" / "04_tools" / "workflows"),
    # Workflow skill sub-definitions (*.skill.md files)
    str(_DEFAULT_ROOT / "decker_system" / "04_tools" / "workflows" / "skills"),
    # Meta workflows
    str(_DEFAULT_ROOT / "decker_system" / "00_meta" / "workflows"),
    # Anthropic skills inventory
    str(_DEFAULT_ROOT / "decker_system" / "04_tools" / "anthropic_skills_inventory.md"),
    # Additional skill files
    str(_DEFAULT_ROOT / "decker_system" / "01_skills" / "factual_question_reasoning_tree"),
    # Project aibrain skills (if installed elsewhere)
    str(_DEFAULT_ROOT / "projects" / "aibrain" / "aibrain" / "core"),
]
# Config key for user-customizable paths
_CONFIG_KEY = "skill_discovery_paths"

# ── Data classes ──────────────────────────────────────────────────────

@dataclass
class DiscoveredSkill:
    """A skill found during discovery, before merging into skills.json."""
    name: str
    description: str
    source_path: str  # where it was found (file path or "aibrain_memory")
    source_type: str  # "skill_md" | "workflow_md" | "skills_json" | "aibrain_memory"
    success_score: float = 0.75  # default for imported skills
    task_shape: str = "imported"
    discovered_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return asdict(self)


# ── Parsers for different formats ─────────────────────────────────────

def _parse_skill_md(filepath: Path) -> Optional[DiscoveredSkill]:
    """Parse a .skill.md file with YAML-like frontmatter."""
    try:
        text = filepath.read_text(encoding="utf-8")
    except Exception:
        return None

    # Extract frontmatter between --- markers
    fm_match = re.match(r'^---\s*\n(.*?)\n---', text, re.DOTALL)
    name = None
    description = ""
    score = 0.75

    if fm_match:
        fm = fm_match.group(1)
        for line in fm.split("\n"):
            line = line.strip()
            if line.startswith("name:") or line.startswith("Name:"):
                name = line.split(":", 1)[1].strip().strip('"').strip("'")
            elif line.startswith("description:") or line.startswith("Description:"):
                description = line.split(":", 1)[1].strip().strip('"').strip("'")
            elif line.startswith("importance:") or line.startswith("success_score:"):
                try:
                    score = float(line.split(":", 1)[1].strip())
                except ValueError:
                    pass

    # Fallback: use first # heading as name
    if not name:
        heading = re.search(r'^#\s+(.+)', text, re.MULTILINE)
        if heading:
            name = heading.group(1).strip().lower().replace(" ", "_").replace(":", "")

    # Fallback: extract description from first non-heading paragraph
    if not description:
        para = re.search(r'(?:^|\n\n)([A-Z][^#\n]{30,200})', text)
        if para:
            description = para.group(1).strip()

    if not name:
        return None

    return DiscoveredSkill(
        name=name,
        description=description or f"Skill from {filepath.name}",
        source_path=str(filepath),
        source_type="skill_md",
        success_score=score,
    )


def _parse_workflow_md(filepath: Path) -> Optional[DiscoveredSkill]:
    """Parse a workflow .md file — extract name from heading, description from intro."""
    try:
        text = filepath.read_text(encoding="utf-8")
    except Exception:
        return None

    # Skip the skills/ subdirectory files (they're .skill.md format)
    if filepath.suffix == ".skill.md" or "skills" in filepath.parts:
        return _parse_skill_md(filepath)

    # Extract name from first # heading
    heading = re.search(r'^#\s+Skill:\s+(.+)', text, re.MULTILINE)
    if not heading:
        heading = re.search(r'^#\s+(.+)', text, re.MULTILINE)

    if not heading:
        return None

    name = heading.group(1).strip().lower().replace(" ", "_").replace(":", "").replace("-", "_")

    # Extract description from first substantive paragraph (after heading, before next heading)
    desc_match = re.search(
        r'^#\s+.+\n\n(.+?)(?:\n\n#|\n##|\Z)',
        text, re.DOTALL
    )
    description = ""
    if desc_match:
        raw = desc_match.group(1).strip()
        # Take first sentence or first 200 chars
        description = raw[:300].replace("\n", " ").strip()

    return DiscoveredSkill(
        name=name,
        description=description or f"Workflow from {filepath.name}",
        source_path=str(filepath),
        source_type="workflow_md",
        success_score=0.80,
        task_shape="workflow",
    )


def _parse_skills_json(filepath: Path, already_known_names: set) -> List[DiscoveredSkill]:
    """Parse an external skills.json and return only skills NOT already known."""
    try:
        data = json.loads(filepath.read_text(encoding="utf-8"))
    except Exception:
        return []

    found = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name", "")
        if not name or name in already_known_names:
            continue
        found.append(DiscoveredSkill(
            name=name,
            description=entry.get("description", ""),
            source_path=str(filepath),
            source_type="skills_json",
            success_score=float(entry.get("success_score", 0.75)),
            task_shape=entry.get("task_shape", "imported"),
        ))
    return found


def _parse_aibrain_memory(db_path: Path, already_known_names: set) -> List[DiscoveredSkill]:
    """Query AIBrain memory API for skill-type and pattern-type entries not in skills.json.

    Uses the HTTP API at localhost:8001 (or AIBRAIN_API_URL env var).
    Falls back gracefully if the API is unreachable.
    """
    import urllib.request
    import urllib.error

    api_url = os.environ.get("AIBRAIN_API_URL", "http://localhost:8001")
    found = []

    for mem_type in ("skill", "pattern"):
        try:
            url = f"{api_url}/memory/search?type={mem_type}&limit=100"
            req = urllib.request.Request(url)
            req.add_header("Accept", "application/json")
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError,
                ConnectionRefusedError, TimeoutError, OSError) as exc:
            log.debug("SkillDiscovery: AIBrain API unreachable for %s: %s", mem_type, exc)
            continue

        results = data if isinstance(data, list) else data.get("results", data.get("memories", []))
        for entry in results:
            if not isinstance(entry, dict):
                continue
            name = entry.get("name", "")
            if not name or name in already_known_names:
                continue
            clean_name = name.lower().replace(" ", "_").replace("-", "_")[:80]
            content = entry.get("content", "")
            description = content[:300].replace("\n", " ").strip()
            importance = float(entry.get("importance", 0.7))

            found.append(DiscoveredSkill(
                name=clean_name,
                description=description,
                source_path="aibrain_memory",
                source_type="aibrain_memory",
                success_score=importance,
                task_shape=mem_type,
            ))
            already_known_names.add(clean_name)

    return found


# ── Main discovery engine ─────────────────────────────────────────────

class SkillDiscovery:
    """Auto-discovers skills, workflows, and tools from the filesystem and AIBrain memory.

    Call discover_all() on startup to import everything found into the active SkillCompiler.
    """

    def __init__(self, config_path: Optional[Path] = None,
                 skills_path: Optional[Path] = None,
                 db_path: Optional[Path] = None):
        self._config_path = config_path or (Path.home() / ".aibrain" / "config.json")
        self._skills_path = skills_path or (Path.home() / ".aibrain" / "skills.json")
        self._db_path = db_path or (Path.home() / ".aibrain" / "aibrain.db")
        self._state_path = Path.home() / ".aibrain" / ".skill_discovery_state.json"

    def get_discovery_paths(self) -> List[str]:
        """Return configured discovery paths, falling back to defaults."""
        # Try config first
        if self._config_path.exists():
            try:
                config = json.loads(self._config_path.read_text(encoding="utf-8"))
                paths = config.get(_CONFIG_KEY)
                if paths and isinstance(paths, list):
                    return paths
            except Exception:
                pass

        # Try environment variable
        env_paths = os.environ.get("AIBRAIN_SKILL_DISCOVERY_PATHS")
        if env_paths:
            return [p.strip() for p in env_paths.split(os.pathsep) if p.strip()]

        # Filter defaults to only existing paths
        valid = []
        for p in _DEFAULT_DISCOVERY_PATHS:
            path = Path(p)
            if path.exists():
                valid.append(p)
        return valid

    def _load_already_known_names(self) -> set:
        """Load names of skills already in skills.json to avoid re-importing."""
        if not self._skills_path.exists():
            return set()
        try:
            data = json.loads(self._skills_path.read_text(encoding="utf-8"))
            return {entry.get("name", "") for entry in data if isinstance(entry, dict)}
        except Exception:
            return set()

    def _load_discovery_state(self) -> dict:
        """Load previous discovery state to skip already-scanned files."""
        if not self._state_path.exists():
            return {"scanned_files": {}, "last_discovery": None}
        try:
            return json.loads(self._state_path.read_text(encoding="utf-8"))
        except Exception:
            return {"scanned_files": {}, "last_discovery": None}

    def _save_discovery_state(self, state: dict) -> None:
        """Save discovery state for incremental scanning."""
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        self._state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")

    def _scan_directory(self, dirpath: Path, already_known: set,
                        state: dict, recursive: bool = True) -> tuple[List[DiscoveredSkill], List[DiscoveredSkill]]:
        """Scan a directory for skill files of all supported formats.

        Returns (new_skills, updated_skills) — updated_skills are skills whose
        name already exists in skills.json but the source file has changed.
        These must be passed to compiler.capture() so descriptions refresh.
        """
        new_skills = []
        updated_skills = []
        scanned_files = state.get("scanned_files", {})

        try:
            entries = list(dirpath.rglob("*") if recursive else dirpath.glob("*"))
        except (PermissionError, OSError):
            return [], []

        for entry in entries:
            if not entry.is_file():
                continue

            key = str(entry)
            mtime = entry.stat().st_mtime

            # Skip if already scanned and unchanged
            if key in scanned_files and scanned_files[key] >= mtime:
                continue

            skill = None
            if entry.suffix == ".md":
                if ".skill.md" in entry.name or "skills" in str(entry):
                    skill = _parse_skill_md(entry)
                else:
                    skill = _parse_workflow_md(entry)

            if skill:
                if skill.name not in already_known:
                    new_skills.append(skill)
                    already_known.add(skill.name)
                else:
                    # F-SKILL-DISCOVERY-REFRESH-1: file changed, name exists.
                    # Pass through as an update so compiler.capture() refreshes
                    # description + artifact_path.  Previously these were silently
                    # dropped — Neuro's workflow improvements never reached Lucy.
                    updated_skills.append(skill)

            scanned_files[key] = mtime

        state["scanned_files"] = scanned_files
        return new_skills, updated_skills

    def discover_all(self, force: bool = False) -> int:
        """Run full discovery across all paths. Returns count of new skills imported.

        Args:
            force: If True, re-scan all files even if unchanged.
        """
        from aibrain.core.skill_compiler import SkillCompiler

        state = self._load_discovery_state() if not force else {"scanned_files": {}, "last_discovery": None}
        already_known = self._load_already_known_names()
        all_discovered: List[DiscoveredSkill] = []

        paths = self.get_discovery_paths()
        log.info("SkillDiscovery: scanning %d paths...", len(paths))

        for path_str in paths:
            path = Path(path_str)
            if not path.exists():
                continue

            if path.is_file():
                # Single file
                if path.suffix == ".json":
                    discovered = _parse_skills_json(path, already_known)
                    all_discovered.extend(discovered)
                    for d in discovered:
                        already_known.add(d.name)
                elif path.suffix == ".md":
                    skill = _parse_workflow_md(path)
                    if skill:
                        if skill.name not in already_known:
                            all_discovered.append(skill)
                            already_known.add(skill.name)
                        else:
                            # F-SKILL-DISCOVERY-REFRESH-1: single .md file changed,
                            # name exists — pass as update so description refreshes
                            all_discovered.append(skill)
            elif path.is_dir():
                new_skills, updated_skills = self._scan_directory(path, already_known, state)
                all_discovered.extend(new_skills)
                all_discovered.extend(updated_skills)  # F-SKILL-DISCOVERY-REFRESH-1

        # Scan AIBrain memory
        memory_skills = _parse_aibrain_memory(self._db_path, already_known)
        all_discovered.extend(memory_skills)

        if not all_discovered:
            log.info("SkillDiscovery: no new skills found.")
            state["last_discovery"] = datetime.now(timezone.utc).isoformat()
            self._save_discovery_state(state)
            return 0

        # Import into SkillCompiler
        compiler = SkillCompiler(skills_path=self._skills_path)
        imported = 0
        for skill in all_discovered:
            result = compiler.capture(
                name=skill.name,
                description=skill.description,
                artifact_path=skill.source_path,
                success_score=skill.success_score,
                task_shape=skill.task_shape,
            )
            if result:
                imported += 1

        state["last_discovery"] = datetime.now(timezone.utc).isoformat()
        state["last_import_count"] = imported
        self._save_discovery_state(state)

        log.info("SkillDiscovery: imported %d new skills (from %d discovered).",
                 imported, len(all_discovered))
        return imported

    def discover_from_path(self, path_str: str, force: bool = False) -> int:
        """Discover skills from a single path. Useful for ad-hoc imports."""
        from aibrain.core.skill_compiler import SkillCompiler

        path = Path(path_str)
        if not path.exists():
            log.warning("SkillDiscovery: path not found: %s", path_str)
            return 0

        already_known = self._load_already_known_names()
        all_discovered = []

        if path.is_file():
            if path.suffix == ".json":
                all_discovered = _parse_skills_json(path, already_known)
            elif path.suffix == ".md":
                skill = _parse_workflow_md(path)
                if skill:
                    all_discovered = [skill]  # F-SKILL-DISCOVERY-REFRESH-1: always include
        elif path.is_dir():
            state = {"scanned_files": {}}
            new_skills, updated_skills = self._scan_directory(path, already_known, state)
            all_discovered = new_skills + updated_skills

        if not all_discovered:
            return 0

        compiler = SkillCompiler(skills_path=self._skills_path)
        imported = 0
        for skill in all_discovered:
            result = compiler.capture(
                name=skill.name,
                description=skill.description,
                artifact_path=skill.source_path,
                success_score=skill.success_score,
                task_shape=skill.task_shape,
            )
            if result:
                imported += 1

        return imported

    def status(self) -> dict:
        """Return discovery status: paths, last run, import count."""
        state = self._load_discovery_state()
        return {
            "discovery_paths": self.get_discovery_paths(),
            "last_discovery": state.get("last_discovery"),
            "last_import_count": state.get("last_import_count", 0),
            "tracked_files": len(state.get("scanned_files", {})),
            "skills_in_store": len(self._load_already_known_names()),
        }


# ── Convenience function for startup ──────────────────────────────────

def auto_discover_on_startup() -> int:
    """Run discovery on startup. Called from __init__.py or bootstrap.

    Returns count of newly imported skills. Non-fatal on failure.

    Cooldown policy (F-SKILL-DISCOVERY-COOLDOWN-1):
    - If previous discovery imported 0 skills, always re-run (the noise gate
      or other filter may have been too strict — retry on next startup).
    - Otherwise, respect the configured cooldown (default 1 hour, not 24 —
      mtime tracking makes re-scans cheap for unchanged files, so a short
      cooldown is safe).
    - Configurable via config.json key "skill_discovery_cooldown_hours" or
      env var AIBRAIN_SKILL_DISCOVERY_COOLDOWN_HOURS.
    """
    try:
        sd = SkillDiscovery()
        state = sd._load_discovery_state()
        last = state.get("last_discovery")
        last_import_count = state.get("last_import_count", -1)

        # F-SKILL-DISCOVERY-COOLDOWN-1: always retry if previous run was a
        # failure (imported 0). The noise gate was likely too strict at the
        # time — retrying is the only way to recover without manual intervention.
        if last is not None and last_import_count > 0:
            try:
                last_dt = datetime.fromisoformat(last)
                age_hours = (datetime.now(timezone.utc) - last_dt).total_seconds() / 3600

                # Read cooldown from config or env, default 1 hour
                cooldown_hours = float(
                    os.environ.get("AIBRAIN_SKILL_DISCOVERY_COOLDOWN_HOURS", "1")
                )
                try:
                    if sd._config_path.exists():
                        config = json.loads(sd._config_path.read_text(encoding="utf-8"))
                        cooldown_hours = float(config.get("skill_discovery_cooldown_hours", cooldown_hours))
                except Exception:
                    pass

                if age_hours < cooldown_hours:
                    log.debug("SkillDiscovery: last run %.1f hours ago (cooldown %.1fh, "
                             "imported %d), skipping.", age_hours, cooldown_hours, last_import_count)
                    return 0
            except (ValueError, TypeError):
                pass
        count = sd.discover_all()
        if count > 0:
            log.info("SkillDiscovery: auto-imported %d new skills on startup.", count)
        return count
    except Exception as exc:
        log.warning("SkillDiscovery: auto-discovery failed (non-fatal): %s", exc)
        return 0
