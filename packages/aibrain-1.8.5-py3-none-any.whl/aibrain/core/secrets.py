"""
secrets.py — Secure secrets vault for AIBrain agents.

Agents can store and retrieve API keys, tokens, and credentials
without them appearing in logs, memories, or git.

Storage: SQLite table `agent_secrets` with encrypted values.
Access: Scoped by agent_id or company-wide.

Usage:
    from aibrain.core.secrets import store_secret, get_secret, list_secrets, delete_secret

    store_secret("openai_key", "sk-...", scope="company", company_id="abc")
    key = get_secret("openai_key", company_id="abc")
    secrets = list_secrets(company_id="abc")  # names only, never values
    delete_secret("openai_key", company_id="abc")
"""

import hashlib
import logging
import os
import secrets as _secrets
import sqlite3
from base64 import b64decode
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger(__name__)


def _get_db():
    """Get DB connection with the secrets table ensured."""
    db_path = os.environ.get("AIBRAIN_DB", str(Path(__file__).parent.parent.parent / "aibrain.db"))
    db = sqlite3.connect(db_path)
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS agent_secrets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            encrypted_value TEXT NOT NULL,
            scope TEXT NOT NULL DEFAULT 'agent',
            company_id TEXT,
            agent_id TEXT,
            version INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            created_by TEXT,
            UNIQUE(name, company_id, agent_id)
        )
    """)
    db.commit()
    return db


def _get_salt() -> bytes:
    """Get or create a random encryption salt.

    On first use, generates os.urandom(16) and stores in .encryption_salt
    next to the aibrain root directory. On subsequent uses, loads from file.
    Falls back to a deterministic salt only if the filesystem is read-only.
    """
    salt_path = Path(__file__).parent.parent.parent / ".encryption_salt"
    try:
        if salt_path.exists():
            salt = salt_path.read_bytes()
            if len(salt) >= 16:
                return salt[:16]
        # Generate new random salt
        salt = os.urandom(16)
        salt_path.write_bytes(salt)
        return salt
    except OSError:
        # Read-only filesystem — fall back to deterministic salt (last resort)
        return hashlib.sha256(b"aibrain-secrets-vault-v1").digest()[:16]


def _derive_key():
    """Derive encryption key from AIBRAIN_SECRET_KEY or an auto-generated key file.

    Key priority:
      1. AIBRAIN_SECRET_KEY env var (explicit, recommended for production)
      2. Auto-generated random key persisted to .encryption_key file
         (created once on first use — survives reboots, tied to filesystem)

    Never falls back to predictable machine fingerprints.
    Requires the 'cryptography' package. Raises RuntimeError if not installed.
    """
    machine_id = os.environ.get("AIBRAIN_SECRET_KEY", "")
    if not machine_id:
        # Try to load or generate a random key file (much stronger than
        # a predictable hostname:arch:user fingerprint)
        key_path = Path(__file__).parent.parent.parent / ".encryption_key"
        try:
            if key_path.exists():
                machine_id = key_path.read_text(encoding="utf-8").strip()
            if not machine_id:
                # First use — generate a cryptographically random key
                machine_id = _secrets.token_hex(32)  # 256 bits
                key_path.write_text(machine_id, encoding="utf-8")
                # Best-effort: restrict permissions on the key file
                try:
                    key_path.chmod(0o600)
                except OSError:
                    pass  # Windows may not support Unix permissions
                log.warning(
                    "SECURITY: AIBRAIN_SECRET_KEY not set — generated random key at %s. "
                    "For portability, set AIBRAIN_SECRET_KEY in ~/.decker_env",
                    key_path,
                )
        except OSError as exc:
            raise RuntimeError(
                f"Cannot read or create encryption key file at {key_path}: {exc}. "
                "Set AIBRAIN_SECRET_KEY environment variable instead."
            ) from exc

    try:
        from cryptography.fernet import Fernet
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes
        import base64
    except ImportError:
        raise RuntimeError(
            "Secrets vault requires the 'cryptography' package. "
            "Install with: pip install cryptography"
        )

    salt = _get_salt()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100_000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(machine_id.encode()))
    return Fernet(key)


def _encrypt(value: str) -> str:
    """Encrypt a secret value. Requires cryptography package."""
    fernet = _derive_key()
    return "fernet:" + fernet.encrypt(value.encode()).decode()


def _decrypt(stored: str) -> str:
    """Decrypt a stored secret value."""
    if stored.startswith("fernet:"):
        fernet = _derive_key()
        if not fernet:
            raise RuntimeError("Cannot decrypt: cryptography package not installed")
        return fernet.decrypt(stored[7:].encode()).decode()
    elif stored.startswith("b64:"):
        log.warning(
            "SECURITY: b64: plaintext secret detected for key '%s' — re-encrypt immediately",
            stored[:20],
        )
        return b64decode(stored[4:]).decode()
    return stored  # plaintext fallback


def store_secret(
    name: str,
    value: str,
    scope: str = "company",
    company_id: str = None,
    agent_id: str = None,
    created_by: str = None,
) -> dict:
    """Store or update a secret."""
    db = _get_db()
    now = datetime.now(timezone.utc).isoformat()
    encrypted = _encrypt(value)

    existing = db.execute(
        "SELECT id, version FROM agent_secrets WHERE name=? AND company_id IS ? AND agent_id IS ?",
        (name, company_id, agent_id),
    ).fetchone()

    if existing:
        new_version = existing["version"] + 1
        db.execute(
            "UPDATE agent_secrets SET encrypted_value=?, version=?, updated_at=?, created_by=? WHERE id=?",
            (encrypted, new_version, now, created_by, existing["id"]),
        )
        db.commit()
        db.close()
        return {"name": name, "version": new_version, "action": "updated"}
    else:
        db.execute(
            "INSERT INTO agent_secrets (name, encrypted_value, scope, company_id, agent_id, version, created_at, updated_at, created_by) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)",
            (name, encrypted, scope, company_id, agent_id, now, now, created_by),
        )
        db.commit()
        db.close()
        return {"name": name, "version": 1, "action": "created"}


def get_secret(name: str, company_id: str = None, agent_id: str = None) -> str | None:
    """Retrieve a decrypted secret value. Returns None if not found."""
    db = _get_db()
    row = db.execute(
        "SELECT encrypted_value FROM agent_secrets WHERE name=? AND company_id IS ? AND agent_id IS ?",
        (name, company_id, agent_id),
    ).fetchone()
    db.close()

    if not row:
        return None
    return _decrypt(row["encrypted_value"])


def list_secrets(company_id: str = None, agent_id: str = None) -> list[dict]:
    """List secret names (never values) with metadata."""
    db = _get_db()
    rows = db.execute(
        "SELECT name, scope, company_id, agent_id, version, created_at, updated_at FROM agent_secrets WHERE company_id IS ? AND agent_id IS ? ORDER BY name",
        (company_id, agent_id),
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def delete_secret(name: str, company_id: str = None, agent_id: str = None) -> bool:
    """Delete a secret. Returns True if found and deleted."""
    db = _get_db()
    cursor = db.execute(
        "DELETE FROM agent_secrets WHERE name=? AND company_id IS ? AND agent_id IS ?",
        (name, company_id, agent_id),
    )
    db.commit()
    deleted = cursor.rowcount > 0
    db.close()
    return deleted


def has_secret(name: str, company_id: str = None, agent_id: str = None) -> bool:
    """Check if a secret exists without decrypting it."""
    db = _get_db()
    row = db.execute(
        "SELECT 1 FROM agent_secrets WHERE name=? AND company_id IS ? AND agent_id IS ?",
        (name, company_id, agent_id),
    ).fetchone()
    db.close()
    return row is not None
