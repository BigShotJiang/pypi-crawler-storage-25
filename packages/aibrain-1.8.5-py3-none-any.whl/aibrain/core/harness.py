"""
harness.py — Universal Execution Harness for AIBrain.

Every task, workflow, skill execution, and agent action passes through this
harness. It wraps execution with:

1. Classification — what type of task is this?
2. Budget check — is there budget remaining?
3. Authority check — does this agent/workflow have permission?
4. Model routing — pick the right model (deterministic/simple/judgment/complex)
5. Execution — run the actual task with timeout
6. Evaluation — score output quality (0.0-1.0)
7. Audit trail — log everything with before/after state
8. Verification — did the result actually succeed?
9. Learning — store corrections, update skill principles
10. Retry/escalate — if quality below threshold, retry or escalate

This is the core engine. Every other feature plugs into it.

Usage:
    from aibrain.core.harness import execute, HarnessConfig

    result = execute(
        task="post_to_linkedin",
        action=lambda: post_linkedin(content),
        config=HarnessConfig(
            authority="standard",
            task_type="deterministic",
            max_cost_cents=10,
        ),
    )
    # result.success — did it complete?
    # result.quality — 0.0-1.0 quality score
    # result.cost_cents — actual cost
    # result.model_used — which model executed
    # result.audit_id — reference to audit trail entry
    # result.retries — how many attempts were needed
"""

import concurrent.futures
import json
import logging
import os
import re
import sqlite3
import threading


def _db_open(path, **kw):
    """Open a SQLite connection with busy_timeout=5000ms to survive concurrent writers."""
    kw.setdefault("timeout", 5)
    conn = sqlite3.connect(str(path), **kw)
    conn.execute("PRAGMA busy_timeout=5000")
    return conn
import time
import traceback
import secrets
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

# Thread-local storage for the current output token budget.
# Set by the harness before each attempt so that action callables
# can optionally read `_harness_output_tokens` to know the active limit.
_tl = threading.local()


def get_current_output_tokens() -> int:
    """Return the output token limit the harness set for the current attempt.

    Actions that are token-aware (e.g. LLM callers) may call this to read
    the active limit rather than hard-coding one themselves.

    Returns 8192 (the default) when called outside of a harness execution.
    """
    return getattr(_tl, "output_tokens", 8192)


# ---------------------------------------------------------------------------
# CapabilityAudit — cooperative runtime capability gate
# ---------------------------------------------------------------------------

class CapabilityAuditError(PermissionError):
    """Raised by check_capability() when the active authority denies the action."""


class CapabilityAuditContext:
    """Thread-local context that records authority + workflow for the current execution.

    Cooperative pattern: workflows opt in by calling check_capability() before
    performing sensitive operations (subprocess, socket, file-write).  The harness
    sets this context in the worker thread around every workflow invocation.

    Usage (inside a workflow):
        from aibrain.core.harness import check_capability
        check_capability("execute_command")  # raises CapabilityAuditError if denied
    """

    def __init__(self, authority: str, workflow_name: str) -> None:
        self.authority = authority
        self.workflow_name = workflow_name

    def check(self, capability: str) -> None:
        """Raise CapabilityAuditError if *capability* is denied for the active authority."""
        ok, msg = _check_capability(self.authority, [capability])
        if not ok:
            raise CapabilityAuditError(
                f"[CapabilityAudit] workflow='{self.workflow_name}' "
                f"authority='{self.authority}': {msg}"
            )


def get_capability_audit_context() -> Optional["CapabilityAuditContext"]:
    """Return the CapabilityAuditContext active on this thread, or None if called outside a workflow."""
    return getattr(_tl, "audit_ctx", None)


def check_capability(action: str) -> None:
    """Convenience function — check *action* against the current thread's audit context.

    Call this at the top of any sensitive operation inside a workflow:
        check_capability("execute_command")  # subprocess
        check_capability("write_file")       # file writes
        check_capability("send_email")       # outbound network

    Silently passes when called outside a harnessed execution (no context set).
    Raises CapabilityAuditError when the active authority denies the action.
    """
    ctx = get_capability_audit_context()
    if ctx is not None:
        ctx.check(action)


from aibrain.core.workflow_quality import evaluate_workflow as _evaluate_workflow_specific

log = logging.getLogger("aibrain.harness")

# Lazy import — avoids circular imports and keeps harness self-contained.
# dynamic_router auto-discovers Ollama models and routes by task complexity.
# Falls back to local_router (static), then to hardcoded MODEL_MAP.
try:
    from aibrain.core.dynamic_router import select_model as _select_model
    _HAS_LOCAL_ROUTER = True
except ImportError:
    try:
        from aibrain.core.local_router import select_model as _select_model
        _HAS_LOCAL_ROUTER = True
    except ImportError:
        _HAS_LOCAL_ROUTER = False
        log.debug("No model router available — using static MODEL_MAP")


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class TaskType(Enum):
    """Task classification for model routing."""
    DETERMINISTIC = "deterministic"   # No LLM needed — code only
    SIMPLE = "simple"                 # Haiku / local model
    JUDGMENT = "judgment"             # Sonnet
    COMPLEX = "complex"              # Opus
    CODE_GEN = "code_gen"            # Code generation — DeepSeek


class Authority(Enum):
    """Permission level for task execution."""
    READ_ONLY = "read_only"
    STANDARD = "standard"
    ELEVATED = "elevated"
    ADMIN = "admin"


class RiskLevel(Enum):
    """Task risk classification for approval routing."""
    LOW = "low"         # Auto-approve, log honestly
    MEDIUM = "medium"   # Auto-approve, log for review
    HIGH = "high"       # Require explicit approval — block until granted


class DataClassification(Enum):
    """Data sensitivity classification for model routing.

    Enterprise blocker: customers with finding data, vulnerability details,
    or internal documents CANNOT send that content to a cloud API.
    This classification layer enforces data residency before model selection.

    Hierarchy (most to least restrictive):
        SECRET    — local model only, also mask in logs
        SENSITIVE — local model only (Ollama / local LLM)
        INTERNAL  — cloud OK but prefer no-training API tier
        PUBLIC    — any model OK
    """
    PUBLIC = "public"
    INTERNAL = "internal"
    SENSITIVE = "sensitive"
    SECRET = "secret"


# Regex patterns for content classification.
# Checked in priority order: SECRET → SENSITIVE → INTERNAL → PUBLIC.
_SECRET_PATTERNS = [
    r'\b(password\s*[=:]\s*\S+|api[_\s]?key\s*[=:]\s*\S+|private[_\s]?key\s*[=:]\s*\S+)',
    r'\b(secret\s*[=:]\s*\S+|token\s*[=:]\s*\S+)',
    r'\b(BEGIN\s+(?:RSA|EC|OPENSSH|PGP)\s+PRIVATE\s+KEY)',
]
_SENSITIVE_PATTERNS = [
    r'\b(CVE-\d{4}-\d+)\b',
    r'\b(vulnerability|exploit|payload|injection|XSS|SQLI|RCE|buffer\s*overflow|zero[_\s]?day)\b',
    r'\b(password|credential|secret|api[_\s]?key|token|private[_\s]?key)\b',
    r'\b(internal[_\s]?only|confidential|restricted|classified)\b',
    r'\b(SSN|social\s+security|credit\s+card|PAN\b|IBAN)\b',
    r'\b(malware|ransomware|backdoor|rootkit|keylogger|shellcode)\b',
]
_INTERNAL_PATTERNS = [
    r'\b(our|my\s+company|our\s+team|our\s+department|our\s+client|our\s+customer)\b',
    r'\b(internal|proprietary|trade\s+secret)\b',
]


def classify_content(
    content: str,
    metadata: dict = None,
) -> DataClassification:
    """Classify content sensitivity for model routing decisions.

    Checks patterns in priority order: SECRET → SENSITIVE → INTERNAL → PUBLIC.
    The env var AIBRAIN_DATA_CLASSIFICATION can force a minimum classification
    level for the whole session (e.g. "sensitive" → always at least SENSITIVE).

    Args:
        content:  The text content to classify (task description, prompt, etc.)
        metadata: Optional dict of extra context (e.g. {"tags": ["security"]})

    Returns:
        DataClassification enum value.
    """
    # Session-level override — operator can force a floor classification
    session_floor = os.environ.get("AIBRAIN_DATA_CLASSIFICATION", "").lower().strip()
    floor_map = {
        "secret": DataClassification.SECRET,
        "sensitive": DataClassification.SENSITIVE,
        "internal": DataClassification.INTERNAL,
        "public": DataClassification.PUBLIC,
    }
    floor = floor_map.get(session_floor)

    # Pattern matching — SECRET first (highest priority)
    for pattern in _SECRET_PATTERNS:
        if re.search(pattern, content, re.IGNORECASE):
            result = DataClassification.SECRET
            return _apply_floor(result, floor)

    # SENSITIVE second
    for pattern in _SENSITIVE_PATTERNS:
        if re.search(pattern, content, re.IGNORECASE):
            result = DataClassification.SENSITIVE
            return _apply_floor(result, floor)

    # INTERNAL third
    for pattern in _INTERNAL_PATTERNS:
        if re.search(pattern, content, re.IGNORECASE):
            result = DataClassification.INTERNAL
            return _apply_floor(result, floor)

    # PUBLIC default
    return _apply_floor(DataClassification.PUBLIC, floor)


def _apply_floor(
    detected: DataClassification,
    floor: Optional[DataClassification],
) -> DataClassification:
    """Return the more restrictive of detected classification vs session floor."""
    if floor is None:
        return detected
    # Hierarchy: SECRET > SENSITIVE > INTERNAL > PUBLIC
    _rank = {
        DataClassification.PUBLIC: 0,
        DataClassification.INTERNAL: 1,
        DataClassification.SENSITIVE: 2,
        DataClassification.SECRET: 3,
    }
    return detected if _rank[detected] >= _rank[floor] else floor


def route_by_classification(
    classification: DataClassification,
    available_models: list,
) -> dict:
    """Return routing decision dict given data classification.

    For SENSITIVE/SECRET: enforces local-only routing via Ollama.
        Raises ValueError if no local model is available.
    For INTERNAL: cloud model OK, sets no_training=True so callers can
        request a no-training API tier.
    For PUBLIC: any model, no restrictions.

    Args:
        classification:   DataClassification enum value.
        available_models: List of model IDs in preference order.

    Returns:
        dict with keys:
            "model"       — model ID string to use
            "no_training" — bool, True when caller MUST use a no-training API tier
    """
    if not available_models:
        return {"model": "code_only", "no_training": False}

    if classification in (DataClassification.SENSITIVE, DataClassification.SECRET):
        # Enforce local model — Ollama or any model with "local" in its name
        local_models = [
            m for m in available_models
            if "ollama" in m.lower() or "local" in m.lower()
        ]
        if local_models:
            return {"model": local_models[0], "no_training": False}
        # No local model in available_models — probe Ollama directly as a last resort.
        try:
            from aibrain.core.local_llm import LocalLLMClient
            _client = LocalLLMClient()
            if _client.is_available():
                _local_name = _client.model_name()
                if _local_name:
                    log.info(
                        "route_by_classification: Ollama available (%s) — routing %s task locally",
                        _local_name,
                        classification.value.upper(),
                    )
                    return {"model": f"ollama/{_local_name}", "no_training": False}
        except Exception as _probe_err:
            log.debug("route_by_classification: Ollama probe failed: %s", _probe_err)

        # No local model available — hard-block, never silently fall back to cloud.
        raise ValueError(
            f"SECRET/SENSITIVE data requires local model — start Ollama first "
            f"(e.g. `ollama pull gemma3:4b`). "
            f"(classification={classification.value.upper()}, "
            f"available_models={available_models})"
        )

    elif classification == DataClassification.INTERNAL:
        # Cloud is OK, but flag no_training so callers use a no-training API tier
        return {"model": available_models[0], "no_training": True}

    else:
        # PUBLIC — any model, no restrictions
        return {"model": available_models[0], "no_training": False}


# Actions that are HIGH risk and must have explicit human approval
HIGH_RISK_ACTIONS = {
    "spend_money", "delete_file", "publish", "post_to_platform",
    "send_email", "trade", "purchase", "buy", "pay",
}

# Actions that are MEDIUM risk — auto-approved but flagged for review
MEDIUM_RISK_ACTIONS = {
    "git_push", "execute_command", "computer_use", "desktop_control",
}


AUTHORITY_CAPABILITIES = {
    Authority.READ_ONLY: {
        "allowed": {"read_file", "search_memory", "query_db", "list_files"},
        "denied": {"write_file", "send_email", "git_push", "delete_file",
                   "spend_money", "execute_command", "post_to_platform",
                   "computer_use", "desktop_control"},
    },
    Authority.STANDARD: {
        "allowed": {"read_file", "write_file", "search_memory", "store_memory",
                    "query_db", "list_files", "format_text"},
        "denied": {"send_email", "git_push", "delete_file", "spend_money",
                   "post_to_platform", "computer_use", "desktop_control"},
    },
    Authority.ELEVATED: {
        "allowed": {"read_file", "write_file", "send_email", "git_push",
                    "search_memory", "store_memory", "query_db",
                    "post_to_platform", "execute_command",
                    "computer_use", "desktop_control"},
        "requires_approval": {"delete_file", "spend_money"},
    },
    Authority.ADMIN: {
        "allowed": {"*"},
        "requires_approval": set(),
    },
}

MODEL_MAP = {
    TaskType.DETERMINISTIC: "code_only",
    TaskType.SIMPLE: "haiku",
    TaskType.JUDGMENT: "sonnet",
    TaskType.COMPLEX: "opus",
    TaskType.CODE_GEN: "deepseek",
}

# F-LUCY-HARNESS-INTEGRATION-1: route LLM calls through adapters + config
def route_call(messages: list, task_type: str = "simple", tools: list = None,
               temperature: float = 0.7, max_tokens: int = 4096) -> dict:
    """Route an LLM call through the adapter layer with fallback chain.
    
    Uses router_config.json policy for the task class, then tries each
    provider in the primary + fallback chain until one succeeds.
    Returns {"content": str, "tool_calls": list, "usage": dict, "provider": str, "model": str}.
    """
    from aibrain.core.llm_adapters import REGISTRY
    from aibrain.core.router_config import get_policy, load_router_config
    import os
    
    config = load_router_config()
    policy = get_policy(task_type, config)
    api_keys = {
        "openai": os.environ.get("OPENAI_API_KEY", ""),
        "deepseek": os.environ.get("DEEPSEEK_API_KEY", os.environ.get("OPENAI_API_KEY", "")),
        "anthropic": os.environ.get("ANTHROPIC_API_KEY", ""),
    }
    
    # Primary + fallback chain
    chain = [{"provider": policy["provider"], "model": policy["model"]}] + policy.get("fallback_chain", [])
    
    last_error = None
    for entry in chain:
        provider = entry["provider"]
        model = entry["model"]
        api_key = api_keys.get(provider, "")
        if not api_key:
            last_error = f"No API key for {provider}"
            continue
        try:
            adapter_cls = REGISTRY.get(provider)
            if not adapter_cls:
                last_error = f"No adapter for {provider}"
                continue
            adapter = adapter_cls(api_key=api_key)
            result = adapter.chat(messages, model=model, tools=tools,
                                 temperature=temperature, max_tokens=max_tokens)
            result["provider"] = provider
            result["model"] = model
            return result
        except Exception as e:
            last_error = str(e)
            continue
    
    raise RuntimeError(f"All providers in fallback chain failed: {last_error}")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class HarnessConfig:
    """Configuration for a harnessed execution."""
    task_type: str = "judgment"           # deterministic, simple, judgment, complex
    authority: str = "standard"           # read_only, standard, elevated, admin
    max_cost_cents: int = 1000            # budget cap for this execution
    timeout_seconds: int = 300            # max execution time
    quality_threshold: float = 0.5        # minimum quality to accept (0.0-1.0)
    max_retries: int = 1                  # retry attempts on low quality
    require_approval: bool = False        # block until human approves
    audit: bool = True                    # log to audit trail
    actor: str = "system"                 # who initiated this
    tags: list = field(default_factory=list)  # metadata tags
    company_task_id: Optional[str] = None  # if set, harness runs verify_and_complete after execution
    initial_output_tokens: int = 8192     # starting output token budget; escalates to 65536 on cap+low-quality
    capabilities: list = field(default_factory=list)  # capabilities this execution needs (e.g. ["subprocess", "network", "filesystem"])


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class HarnessResult:
    """Result from a harnessed execution."""
    success: bool = False
    output: Any = None
    error: Optional[str] = None
    quality: Optional[float] = None      # None = could not measure (no rubric signal); 0.0-1.0 = real measurement
    # cost_cents: None = could not measure; 0 = explicitly free (local model); >0 = real measurement.
    # The harness itself cannot measure cost — the action must self-report via
    # output dict {"_cost_cents": N} OR the model routing must stamp it. Previously
    # defaulted to 0 unconditionally which made every execution_log row read "$0"
    # regardless of actual spend (Round 1 honest-rubric audit).
    cost_cents: Optional[int] = None
    # Token-to-cents equivalence (Apr 11 2026 — task #11).
    # cost_cents_actual:     real money spent (0 for subscription-backed CLI, real int for SDK/API)
    # cost_cents_equivalent: what the same tokens WOULD cost at list rates — computed for ALL
    #                         runs regardless of backend. Gives Decker visibility into subscription
    #                         utilization even when actual=0. Honest-None when token counts
    #                         unavailable (old runs, missing envelope, unknown model).
    # cost_cents stays for backwards compat (mirrors cost_cents_actual).
    cost_cents_actual: Optional[int] = None
    cost_cents_equivalent: Optional[int] = None
    # model_used: None = didn't self-report; "code_only" = deterministic (no LLM);
    # "<model_name>" = action reported actually running this model.
    # The previous version stamped model_used from the ROUTING DECISION (what we
    # planned to use) which made 1,242 rows claim model_used='sonnet' despite
    # max latency 11ms — impossible for a real sonnet call. The routing decision
    # is preserved separately in model_routed.
    model_used: Optional[str] = None
    model_routed: str = "unknown"
    duration_ms: int = 0
    retries: int = 0
    audit_id: str = ""
    run_id: str = ""
    task_type: str = ""
    authority_check: str = "passed"
    approval_status: str = "not_required"   # not_required, auto_approved_low_risk, auto_approved_medium_risk, approved, pending_approval, denied
    budget_check: str = "passed"
    evaluation_detail: str = ""
    quality_verified: bool = False     # True if automated checks ran
    quality_checks: dict = field(default_factory=dict)  # individual check results
    # Self-score path (action self-reports its own quality estimate via
    # output["_self_score"], same convention as _cost_cents). The harness
    # passes it to evaluate_task_quality() which computes divergence vs
    # the independent eval_score. Honest-None throughout: any of these
    # can be None when there is no real signal.
    self_score: Optional[float] = None  # what the action self-reported
    divergence: Optional[float] = None  # abs(self_score - eval_score) when both present
    flagged: bool = False               # True when divergence > 0.3 (chronic over/underclaim)
    verification: Optional[dict] = None  # verify_and_complete output (if company_task_id set)
    follow_up_tasks: list = field(default_factory=list)  # auto-created follow-up task IDs
    data_classification: Optional[str] = None  # DataClassification.value — set by Step 1b, logged to audit
    output_token_escalated: bool = False  # True when a 8K→64K token escalation retry fired
    stub_output: bool = False            # True = placeholder result (e.g. pending_agent_spawn), skip quality eval
    _autoresearch_metrics: Optional[dict] = None  # Karpathy loop metrics: {baseline_score, best_score, iterations, promoted}


# ---------------------------------------------------------------------------
# Core Harness
# ---------------------------------------------------------------------------

def execute(
    task: str,
    action: Callable,
    config: HarnessConfig = None,
    before_state: dict = None,
) -> HarnessResult:
    """
    Execute a task through the full harness pipeline.

    This is the ONLY way tasks should be executed in AIBrain.
    Everything passes through here — no exceptions.
    """
    # Lazy-register reactive chains on first harness call
    try:
        from aibrain.core.reactive_chains import register_reactive_chains
        register_reactive_chains()
    except Exception:
        pass  # Never block execution for chain registration

    if config is None:
        config = HarnessConfig()

    run_id = secrets.token_urlsafe(8)
    result = HarnessResult(run_id=run_id, task_type=config.task_type)
    start_time = time.time()

    # Emit harness.task.start event — fire-and-forget, never blocks execution
    try:
        from aibrain.core.event_bus import emit as _bus_emit, EventTypes as _ET
        _bus_emit(_ET.HARNESS_TASK_START, {
            "run_id": run_id,
            "task": task,
            "task_type": config.task_type,
            "actor": config.actor,
        }, actor=config.actor)
    except Exception:
        pass

    # v1.4 P0-2: Read the thread-local checkout context so this execution
    # can be linked back to a company_issue row in execution_log.
    # checkout_task() stashes the current issue ID on this thread; we pass
    # it through to _log_audit so the row gets entity_type='company_issue'
    # and entity_id=<issue id> instead of the generic 'task' fallback.
    # Lazy import avoids circular dep (companies imports harness helpers).
    try:
        from aibrain.core import companies as _companies_mod
        linked_issue_id: Optional[str] = _companies_mod._get_current_issue_id()
    except Exception:
        linked_issue_id = None

    try:
        # ─── Step 1: Classification ───────────────────────────
        task_type = TaskType(config.task_type)
        if _HAS_LOCAL_ROUTER:
            # SelRoute-inspired local-first routing:
            #   DETERMINISTIC → code_only ($0)
            #   SIMPLE        → ollama/<model> if available, else haiku
            #   JUDGMENT      → sonnet
            #   COMPLEX       → opus
            result.model_routed = _select_model(config.task_type)
        else:
            result.model_routed = MODEL_MAP.get(task_type, "sonnet")
        # DETERMINISTIC tasks never invoke an LLM, so we know in advance that
        # model_used will be "code_only" regardless of what the action self-reports.
        if task_type == TaskType.DETERMINISTIC:
            result.model_used = "code_only"
        # Note: code_only_suspect flagging fires AFTER execution (Step 5) once
        # we have the actual output to inspect. See the post-action block below.

        # ─── Step 1b: Data Classification Routing ────────────
        # Enterprise gate: classify content sensitivity BEFORE model selection.
        # SENSITIVE/SECRET content must stay on local models (Ollama).
        # INTERNAL content may use cloud but prefer no-training API tiers.
        # PUBLIC content may use any model.
        # The AIBRAIN_DATA_CLASSIFICATION env var can force a minimum
        # classification level for the whole session.
        _data_classification = DataClassification.PUBLIC  # default
        if task_type != TaskType.DETERMINISTIC:
            # Classify the task description (what's in the task label and tags)
            _classify_input = task + " " + " ".join(config.tags or [])
            _data_classification = classify_content(_classify_input)

            if _data_classification in (DataClassification.SENSITIVE, DataClassification.SECRET):
                # Override model routing to enforce local model
                _available = [result.model_routed] if result.model_routed else ["haiku"]
                _routing = route_by_classification(_data_classification, _available)
                _local_override = _routing["model"]
                if _local_override != result.model_routed:
                    log.info(
                        "Data classification [%s] overrides model routing: %s → %s",
                        _data_classification.value,
                        result.model_routed,
                        _local_override,
                    )
                    result.model_routed = _local_override
            elif _data_classification == DataClassification.INTERNAL:
                log.debug(
                    "Data classification [internal] — cloud routing OK, no-training tier preferred",
                )

            if _data_classification != DataClassification.PUBLIC:
                log.info(
                    "Data classification: task=%r classification=%s model_routed=%s",
                    task, _data_classification.value, result.model_routed,
                )

        # Always stamp classification on result for audit trail
        result.data_classification = _data_classification.value

        # ─── Step 1c: Routing Settings (SuperWorker mode + daily budget) ──
        # Lazily loaded — no startup cost, graceful when file missing.
        try:
            from aibrain.core.routing_settings import (
                RoutingSettings as _RoutingSettings,
                check_budget_exceeded as _check_routing_budget,
            )
            _routing_settings = _RoutingSettings.load()
            # Daily token budget gate: if exceeded, stamp for callers/SuperWorker
            # to detect and downgrade to single-worker. The harness itself does
            # not execute SuperWorker — it only stamps the signal on the result
            # so the caller (workflow_runner, CLI) can act on it.
            if _check_routing_budget(_routing_settings):
                result.budget_check = "routing_budget_exceeded"
                log.warning(
                    "Daily token budget exceeded — SuperWorker should be skipped for task=%r",
                    task,
                )
            # Stamp routing mode for observability / audit trail
            log.debug(
                "Routing settings: mode=%s fast=%s deep=%s budget_cap=%s",
                _routing_settings.mode,
                _routing_settings.fast_mode,
                _routing_settings.deep_mode,
                _routing_settings.token_budget_per_day_cents,
            )
        except Exception as _rs_exc:
            log.debug("routing_settings load failed (non-fatal): %s", _rs_exc)

        # ─── Step 1d: Config-table Routing Gate (routing.mode + budget) ──
        # Checks the config-table routing.* keys set via `aibrain config set routing.*`.
        # These are the persistent, user-facing routing controls (separate from the
        # per-invocation fast/deep flags in RoutingSettings). Budget exceeded →
        # stamp routing_budget_exceeded so callers downgrade to single-worker.
        try:
            from aibrain.core.routing_config import RoutingConfig as _RoutingConfig
            _rc = _RoutingConfig()
            if _rc.is_budget_exceeded():
                if result.budget_check != "routing_budget_exceeded":
                    result.budget_check = "routing_budget_exceeded"
                    log.warning(
                        "Config-table daily token budget exceeded — "
                        "SuperWorker should be skipped for task=%r",
                        task,
                    )
            _rc_mode = _rc.get_mode()
            log.debug("Config-table routing: mode=%s", _rc_mode)
        except Exception as _rc_exc:
            log.debug("routing_config load failed (non-fatal): %s", _rc_exc)

        # ─── Step 2: Budget Check ─────────────────────────────
        budget_ok, budget_msg = _check_budget(config)
        if not budget_ok:
            result.budget_check = "failed"
            result.error = budget_msg
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            return result

        # ─── Step 3: Authority Check ──────────────────────────
        auth_ok, auth_msg = _check_authority(task, config)
        if not auth_ok:
            result.authority_check = "failed"
            result.error = auth_msg
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            # Emit HIGH-risk authority_override event so the Brain dashboard sees it
            try:
                from aibrain.core.event_bus import emit as _auth_emit
                _auth_emit("authority_override", {
                    "workflow": task,
                    "action": task,
                    "reason": auth_msg,
                    "risk": "HIGH",
                    "timestamp": datetime.utcnow().isoformat(),
                    "actor": config.actor,
                    "authority": config.authority,
                })
            except Exception:
                pass  # Event emission never blocks execution
            return result

        # ─── Step 3b: Enforcement Checks ─────────────────────
        enforcement_ok, enforcement_msg = _check_enforcement(task, config, before_state)
        if not enforcement_ok:
            result.error = enforcement_msg
            result.authority_check = "enforcement_blocked"
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            # Emit HIGH-risk authority_override event for enforcement blocks too
            try:
                from aibrain.core.event_bus import emit as _enf_emit
                _enf_emit("authority_override", {
                    "workflow": task,
                    "action": task,
                    "reason": enforcement_msg,
                    "risk": "HIGH",
                    "timestamp": datetime.utcnow().isoformat(),
                    "actor": config.actor,
                    "authority": config.authority,
                    "enforcement": True,
                })
            except Exception:
                pass  # Event emission never blocks execution
            return result

        # ─── Step 4: Approval Gate (risk-classified) ──────────
        approval_status = _check_approval(task, config)
        result.approval_status = approval_status
        if approval_status in ("pending_approval", "denied"):
            result.error = (
                "Awaiting human approval — task queued"
                if approval_status == "pending_approval"
                else "Task explicitly denied in approval queue"
            )
            result.success = False
            _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)
            return result

        # ─── Step 5: Execute with Timeout ─────────────────────
        # Retry-loop with KEEP-BEST semantics. Every attempt produces a
        # snapshot dict; after the loop, the BEST snapshot wins and gets
        # applied to `result` for persistence. This prevents the load-
        # bearing bug where a successful first attempt gets overwritten by
        # a failed retry's stale state (caught by the Apr 11 SuperWorker
        # dogfood — first SuperWorker call succeeded via CLI backend at
        # cost_cents=0, retry triggered because quality 0.42 < threshold
        # 0.5, retry's SDK fallback path failed with no API key, the
        # FAILED retry's state was what got persisted to execution_log,
        # hiding the successful run entirely).
        #
        # Best-attempt rule:
        #   1. success=True beats success=False
        #   2. within success=True: higher quality_score wins
        #   3. None quality is treated as -0.5 (worse than any measured
        #      score >=0 but better than failure) — this respects the
        #      honest-rubric "couldn't measure" semantics without
        #      promoting None to a fake default.
        attempts: list[dict] = []
        attempt = 0
        # Token escalation state — tracks whether the 8K→64K escalation has
        # already fired for this execution (fires at most once per execute() call).
        _escalation_fired = False
        _current_output_tokens = config.initial_output_tokens
        # Publish the initial token budget on the thread-local so token-aware
        # actions (e.g. LLM callers) can read it via get_current_output_tokens().
        _tl.output_tokens = _current_output_tokens

        # Field snapshot helper — captures every state field a single
        # attempt can mutate, in the order they need to be restored.
        def _snapshot_attempt() -> dict:
            return {
                'success':                  result.success,
                'output':                   result.output,
                'error':                    result.error,
                'cost_cents':               result.cost_cents,
                'cost_cents_actual':        result.cost_cents_actual,
                'cost_cents_equivalent':    result.cost_cents_equivalent,
                'model_used':               result.model_used,
                'self_score':               result.self_score,
                'quality':                  result.quality,
                'divergence':               result.divergence,
                'flagged':                  result.flagged,
                'evaluation_detail':        result.evaluation_detail,
                'quality_verified':         result.quality_verified,
                'quality_checks':           dict(result.quality_checks) if result.quality_checks else {},
                'output_token_escalated':   result.output_token_escalated,
            }

        # Reset helper — restores the per-attempt mutable fields to their
        # neutral start state so a previous attempt's success can't bleed
        # into a subsequent attempt's failure (Bug #4 root cause).
        def _reset_attempt_state():
            result.success = False
            result.output = None
            result.error = None
            result.cost_cents = None
            result.cost_cents_actual = None
            result.cost_cents_equivalent = None
            # model_used stays at "code_only" for deterministic, None elsewhere
            if config.task_type != "deterministic":
                result.model_used = None
            result.self_score = None
            result.quality = None
            result.divergence = None
            result.flagged = False
            result.evaluation_detail = ""
            result.quality_verified = False
            result.quality_checks = {}

        _max_retries = config.max_retries  # snapshot before loop — prevents shared-config mutation from shifting ceiling mid-loop
        # Persistent-failure tracking: if the same error fires 3 consecutive
        # times we abort early rather than burning the remaining budget.
        # Falsifiability: if _consecutive_failures reaches 3, the loop exits
        # with result.error set and result.success=False before hitting _max_retries.
        _consecutive_failures: int = 0
        _last_error: Optional[str] = None
        while attempt <= _max_retries:
            # Reset per-attempt state (except on first attempt where the
            # fields are already at their dataclass defaults)
            if attempt > 0:
                _reset_attempt_state()

            # Publish the current token budget before each attempt.
            # Also set it inside the worker thread via a wrapper so
            # get_current_output_tokens() returns the right value when
            # the action runs in the ThreadPoolExecutor thread.
            _tl.output_tokens = _current_output_tokens
            _tok_for_attempt = _current_output_tokens

            _audit_ctx_for_attempt = CapabilityAuditContext(config.authority, task)

            def _action_with_tokens(_act=action, _tok=_tok_for_attempt,
                                    _ctx=_audit_ctx_for_attempt):
                _tl.output_tokens = _tok
                _tl.audit_ctx = _ctx
                try:
                    return _act()
                finally:
                    _tl.audit_ctx = None

            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(_action_with_tokens)
                    try:
                        output = future.result(timeout=config.timeout_seconds)
                    except concurrent.futures.TimeoutError:
                        result.error = f"Task timed out after {config.timeout_seconds}s"
                        result.success = False
                        log.warning("Harness timeout (attempt %d): %s after %ds",
                                    attempt + 1, task, config.timeout_seconds)
                        attempts.append(_snapshot_attempt())
                        attempt += 1
                        continue
                result.output = output
                result.success = True
                result.error = None

                # Extract self-report fields from action output, if present.
                # Conventions (action-side opt-in):
                #   output["_cost_cents"] = int    — explicit cost in cents
                #   output["_cost_usd"]   = float  — cost in USD (converted to cents)
                #   output["_model_used"] = str    — actual model that ran (not routed)
                #   output["_self_score"] = float  — action self-assessed quality
                # Local models (Ollama, llamafile) should self-report cost=0.
                # If cost not self-reported, cost_cents stays None.
                # If model not self-reported, model_used stays at its default
                # ("code_only" for deterministic, None for everything else).
                if isinstance(output, dict):
                    if "_cost_cents" in output:
                        try:
                            result.cost_cents = int(output["_cost_cents"])
                        except (TypeError, ValueError):
                            pass
                    elif "_cost_usd" in output:
                        try:
                            result.cost_cents = int(round(float(output["_cost_usd"]) * 100))
                        except (TypeError, ValueError):
                            pass
                    # Token-to-cents equivalence fields (Apr 11 2026 — task #11).
                    # Honest-None: missing key OR explicit None → stays None;
                    # any int-like value is captured as-is. Negative values
                    # are rejected silently (honest-rubric — never a fake).
                    if "_cost_cents_actual" in output:
                        v = output["_cost_cents_actual"]
                        if v is None:
                            result.cost_cents_actual = None
                        else:
                            try:
                                iv = int(v)
                                if iv >= 0:
                                    result.cost_cents_actual = iv
                            except (TypeError, ValueError):
                                pass
                    else:
                        # Fallback: if the action only self-reports _cost_cents,
                        # mirror it into _actual so downstream consumers have
                        # both names to read. The CLI path is 0, SDK path is a
                        # real int — either way, it's the actual spend.
                        if result.cost_cents is not None:
                            result.cost_cents_actual = result.cost_cents
                    if "_cost_cents_equivalent" in output:
                        v = output["_cost_cents_equivalent"]
                        if v is None:
                            result.cost_cents_equivalent = None
                        else:
                            try:
                                iv = int(v)
                                if iv >= 0:
                                    result.cost_cents_equivalent = iv
                            except (TypeError, ValueError):
                                pass
                    if "_model_used" in output:
                        m = output["_model_used"]
                        if isinstance(m, str) and m:
                            # v1.4 P0-3: refuse to stamp the bare family name
                            # ('sonnet'/'opus'/'haiku') as model_used. The old
                            # router path did exactly this and polluted 1,242
                            # rows with model_used='sonnet' that were really
                            # 11ms code paths. If the self-report is a bare
                            # family name, we append '-unknown' so the honest
                            # rubric can still see it but downstream analysis
                            # can tell it apart from a fully-qualified slug.
                            m_stripped = m.strip()
                            if m_stripped in ("sonnet", "opus", "haiku"):
                                log.warning(
                                    "model_used self-report is bare family name %r — "
                                    "stamping as %r so unknown-version runs are visible "
                                    "in execution_log. Fix the caller to pass a real "
                                    "version slug (e.g. 'claude-sonnet-4-20250514').",
                                    m_stripped, f"{m_stripped}-unknown",
                                )
                                result.model_used = f"{m_stripped}-unknown"
                            else:
                                result.model_used = m_stripped
                    # Self-score self-report (matches _cost_cents convention).
                    if "_self_score" in output:
                        ss = output["_self_score"]
                        if ss is None:
                            result.self_score = None
                        else:
                            try:
                                ssf = float(ss)
                                if 0.0 <= ssf <= 1.0:
                                    result.self_score = ssf
                                # else: out of range -> stays None (honest-rubric)
                            except (TypeError, ValueError):
                                pass  # invalid -> stays None

                    # Autoresearch metrics extraction (Karpathy loop workflows)
                    # These workflows return: {baseline_score, best_candidate_score, iterations_run, loop_state, ...}
                    if "baseline_score" in output or "best_candidate_score" in output:
                        try:
                            baseline = output.get("baseline_score")
                            best = output.get("best_candidate_score")
                            iterations = output.get("iterations_run", 0)
                            loop_state = output.get("loop_state", "unknown")

                            # Prefer best_candidate_score if a mutation found one, else use baseline
                            if best is not None:
                                result.quality = float(best)
                            elif baseline is not None:
                                result.quality = float(baseline)

                            # Store full metrics dict for downstream consumption (summary output, telemetry)
                            result._autoresearch_metrics = {
                                "baseline_score": baseline,
                                "best_score": best,
                                "iterations": iterations,
                                "promoted": best is not None,
                                "state": loop_state,
                            }
                        except (TypeError, ValueError):
                            pass  # invalid metrics -> stays None

                    # Stub marker — action sets stub_output=True when the result is a
                    # dispatch placeholder (e.g. pending_agent_spawn). Quality eval and
                    # learning recording are skipped for stub results so they don't
                    # pollute evolution_outcomes with meaningless signal.
                    if output.get("stub_output"):
                        result.stub_output = True

                    # ─── Auto-cost from _input_tokens / _output_tokens ───
                    # Actions that call an LLM may return raw token counts without
                    # computing cost themselves.  If _input_tokens and _output_tokens
                    # are present in the output dict AND cost_cents_equivalent is
                    # still None, compute it automatically via llm_pricing so the
                    # execution_log row gets an honest cost signal without requiring
                    # every action to import pricing.py directly.
                    # Fail-open: any error leaves cost_cents_equivalent = None.
                    if (
                        "_input_tokens" in output or "_output_tokens" in output
                    ) and result.cost_cents_equivalent is None:
                        try:
                            from aibrain.core.llm_pricing import compute_cost_cents as _compute_cc
                            _in_tok = output.get("_input_tokens")
                            _out_tok = output.get("_output_tokens")
                            _mdl = result.model_used or result.model_routed
                            if _in_tok is not None and _out_tok is not None and _mdl:
                                _computed = _compute_cc(_mdl, int(_in_tok), int(_out_tok))
                                if _computed is not None:
                                    result.cost_cents_equivalent = _computed
                                    # Also back-fill cost_cents if not yet set
                                    if result.cost_cents is None:
                                        result.cost_cents = _computed
                        except Exception as _cc_err:
                            log.debug("Auto-cost computation failed (non-fatal): %s", _cc_err)

                # ─── code_only_suspect detection ────────────────────────────
                # DETERMINISTIC tasks legitimately cost $0 and use model_used="code_only".
                # However, if the output is suspiciously long and contains sentence-like
                # text, an LLM may have actually run. Flag the row so it appears in cost
                # health queries without changing the cost (we can't retroactively measure).
                if (
                    task_type == TaskType.DETERMINISTIC
                    and result.model_used == "code_only"
                ):
                    _out_text = str(result.output) if result.output is not None else ""
                    # Heuristic: >500 chars AND contains at least one sentence-ending
                    # punctuation followed by a capital letter — code paths rarely do this.
                    _looks_like_llm = (
                        len(_out_text) > 500
                        and bool(re.search(r'[.!?]\s+[A-Z]', _out_text))
                    )
                    if _looks_like_llm:
                        result.model_used = "code_only_suspect"
                        log.warning(
                            "code_only_suspect: DETERMINISTIC task %r produced %d chars of "
                            "sentence-structured output — an LLM may have run unmeasured. "
                            "Flagging model_used='code_only_suspect' for review. "
                            "Cost stays at 0 (cannot retroactively measure).",
                            task, len(_out_text),
                        )

            except RecursionError as e:
                # Recovery path for action-level infinite recursion (e.g. a
                # workflow shadows an imported helper with a self-calling
                # local def). Retrying won't help — same code, same stack.
                # Surface a structured error and short-circuit the retry loop
                # so we fail fast instead of burning the full budget.
                result.error = (
                    f"RecursionError in workflow action (attempt {attempt + 1}): {e}. "
                    "Likely cause: a local function shadows an imported helper and "
                    "calls itself. Aborting retry loop — structural fix required."
                )
                result.success = False
                log.warning(
                    "Harness execution error (attempt %d) — RecursionError: %s. "
                    "Short-circuiting retries; fix the action's call graph.",
                    attempt + 1, e,
                )
                attempts.append(_snapshot_attempt())
                break
            except Exception as e:
                result.error = str(e)
                result.success = False
                log.warning("Harness execution error (attempt %d): %s",
                           attempt + 1, e)

            # ─── Step 6: Evaluate Quality ─────────────────────
            # Stub results (stub_output=True) are dispatch placeholders — no real
            # work happened yet, so quality eval would produce meaningless signal.
            # Skip entirely; quality stays None and no QUALITY_LOW event fires.
            if result.success and not result.stub_output:
                # Preserve autoresearch quality if already extracted (Step 5)
                # so that workflow-specific eval doesn't overwrite with None
                _preserved_quality = result.quality

                eval_result = evaluate_task_quality(
                    output=result.output,
                    task_name=task,
                    config=config,
                    self_score=result.self_score,
                    before_state=before_state,
                )
                quality = eval_result["eval_score"]

                # Only overwrite with eval_score if it's not None, or if we didn't
                # have a workflow-specific quality already (e.g., from autoresearch extraction)
                if quality is not None or _preserved_quality is None:
                    result.quality = quality  # type: ignore[assignment]

                result.quality_verified = eval_result["verified"]
                result.quality_checks = eval_result["checks"]
                result.evaluation_detail = eval_result["detail"]
                result.divergence = eval_result.get("divergence")
                result.flagged = bool(eval_result.get("flagged"))

            # ─── Step 6c: Synthetic quality for deterministic tasks ──────────
            # DETERMINISTIC workflows never call an LLM, so workflow_score and
            # shape_score are always None — evaluate_task_quality returns
            # eval_score=None. This leaves quality=None, which causes two breaks:
            #   1. _record_learning is gated on `quality is not None`, so no
            #      evolution_outcomes row is ever written for deterministic runs.
            #   2. workflow_runner log.info used %.2f on None → TypeError that
            #      prevented the workflow_runs UPDATE from firing (Break 3).
            # Fix: assign a synthetic binary quality score for deterministic tasks
            # that completed — 1.0 if the action returned without error, 0.0 if it
            # raised. This gives the learning loop a real signal even for zero-LLM
            # workflows like dream, retrolearn, heartbeat.
            # Only fires when quality is still None after Step 6 (never overrides
            # a real measured score, and never fires for non-deterministic tasks).
            if (
                task_type == TaskType.DETERMINISTIC
                and result.quality is None
                and not result.stub_output
            ):
                result.quality = 1.0 if result.success else 0.0
                result.evaluation_detail = (
                    (result.evaluation_detail or "") +
                    "; synthetic:deterministic_binary"
                ).lstrip("; ")

            # ─── Step 6b: Adaptive token escalation (qwencode port) ────────
            # If the response length is within 95% of the token cap AND quality
            # is below the escalation threshold (0.7), the model likely hit its
            # output limit before completing the answer.  Fire a single retry
            # with 64K output tokens.  Only fires once per execute() call.
            if (
                result.success
                and not _escalation_fired
                and result.quality is not None
                and result.quality < 0.7
            ):
                _response_text = str(result.output) if result.output is not None else ""
                # Approximate chars-per-token = 4; 95% cap threshold.
                _cap_chars = _current_output_tokens * 4
                if len(_response_text) >= _cap_chars * 0.95:
                    log.info(
                        "Token escalation: response length %d >= 95%% of cap %d chars "
                        "(~%d tokens); quality %.2f < 0.7 — retrying with 65536 output tokens",
                        len(_response_text), _cap_chars, _current_output_tokens, result.quality,
                    )
                    _escalation_fired = True
                    result.output_token_escalated = True
                    _current_output_tokens = 65536
                    _tl.output_tokens = _current_output_tokens
                    # Force a retry regardless of max_retries accounting by
                    # temporarily raising the retry ceiling by 1 for this slot.
                    _max_retries += 1  # increment local snapshot, not shared config — prevents caller config mutation

            # Snapshot this attempt's full state, then decide whether to retry
            attempts.append(_snapshot_attempt())

            if result.success:
                _consecutive_failures = 0  # reset on any success
                _last_error = None
                if result.quality is None:
                    break  # Couldn't measure — accept on success
                if result.quality >= config.quality_threshold:
                    break  # Above threshold — accept
                log.info("Quality %.2f below threshold %.2f (attempt %d) — retrying if budget allows",
                         result.quality, config.quality_threshold, attempt + 1)
            else:
                # Track consecutive identical failures — abort early on persistent error
                current_error = result.error or ""
                if current_error == _last_error:
                    _consecutive_failures += 1
                else:
                    _consecutive_failures = 1
                    _last_error = current_error
                if _consecutive_failures >= 3:
                    log.warning(
                        "Persistent failure after %d consecutive identical errors on %r — "
                        "aborting retry loop to preserve budget. Error: %s",
                        _consecutive_failures, task, current_error[:200],
                    )
                    result.error = f"persistent_failure ({_consecutive_failures}x): {current_error}"
                    break

            attempt += 1

        # ─── Pick the BEST attempt and apply it to result ─────────
        # Honest-rubric attempt comparison: success first, then quality.
        # None quality is treated as worse than any measured score but
        # better than failure (we don't promote None to a fake default).
        def _attempt_score(snap: dict) -> tuple:
            success_pri = 1 if snap.get('success') else 0
            quality = snap.get('quality')
            quality_pri = float(quality) if quality is not None else -0.5
            return (success_pri, quality_pri)

        if attempts:
            best = max(attempts, key=_attempt_score)
            for field, value in best.items():
                setattr(result, field, value)
            # retries = number of attempts AFTER the first
            result.retries = max(0, len(attempts) - 1)

    except Exception as e:
        result.error = f"Harness error: {e}\n{traceback.format_exc()}"
        result.success = False
        log.error("Harness pipeline error: %s", e)

    # ─── Step 6b: Refuse silent cost_cents=0 on non-deterministic tasks ───
    # v1.4 P0-3 residual honest-rubric gate: if this was a successful
    # non-deterministic run, the action stamped cost_cents_actual=0, AND
    # there is no token-based equivalent signal either, we have NO honest
    # measurement of what that call cost. The old default was to silently
    # write 0 into execution_log and move on — that's exactly how 1,242
    # rows ended up claiming "free" sonnet calls that were really
    # unbudgetable noise. Refuse the run so the caller is forced to either
    # supply real token counts, explicitly mark the task deterministic, or
    # hand in a measured cost.
    #
    # Deterministic tasks are exempt — 0 is the honest answer for a code-
    # only path that never touches an LLM.
    #
    # Failures are exempt — if the run raised we never got a chance to
    # measure cost anyway; the error is the signal.
    #
    # Only fires when cost_cents_actual is LITERALLY 0. None stays None
    # (honest "could not measure") and passes through unmodified.
    if (
        result.success
        and config.task_type != "deterministic"
        and result.cost_cents_actual == 0
        and result.cost_cents_equivalent is None
    ):
        raise ValueError(
            f"Cannot measure cost for non-deterministic task {task!r}. Either "
            f"supply cost_cents_actual explicitly, ensure the LLM envelope has "
            f"a usage block, or set task_type='deterministic' if this truly has "
            f"no LLM call."
        )

    # ─── Step 7: Record Timing ────────────────────────────
    result.duration_ms = int((time.time() - start_time) * 1000)

    # ─── Step 8: Audit Trail ──────────────────────────────
    if config.audit:
        result.audit_id = _log_audit(run_id, config, task, result, before_state, linked_issue_id=linked_issue_id)

    # ─── Step 9: Learning ─────────────────────────────────
    # Record learning for ALL execution outcomes — success AND failure. The
    # previous filter `result.success and quality > 0` silently dropped every
    # failure case, so evolution_outcomes had zero record of what went wrong.
    # That's how we ended up with all 1,299 rows stamped `result='success'`
    # (Round 1 honest-rubric audit).
    #
    # Skip ONLY when quality is None AND success — that's "could not measure a
    # successful run" and recording it would seed the learning system with no
    # signal. Failures are always worth recording even if quality is None.
    #
    # Also skip stub results (stub_output=True) — recording a dispatch placeholder
    # as 'no_signal' would permanently pollute evolution_outcomes for this workflow.
    if not result.stub_output and (not result.success or result.quality is not None):
        _record_learning(task, result, config)

    # ─── Step 10: Budget Update ───────────────────────────
    _tokens_in = 0
    _tokens_out = 0
    if isinstance(result.output, dict):
        try:
            _tokens_in = int(result.output.get("_input_tokens", 0) or 0)
            _tokens_out = int(result.output.get("_output_tokens", 0) or 0)
        except (TypeError, ValueError):
            pass
    _update_budget(
        config,
        result.cost_cents,
        cost_cents_equivalent=result.cost_cents_equivalent,
        model_used=result.model_used,
        tokens_in=_tokens_in,
        tokens_out=_tokens_out,
    )

    # ─── Step 11: Verify-and-followup ─────────────────────
    # If this harness run is tied to a company task, verify completion
    # against acceptance criteria and auto-queue follow-ups for gaps.
    if config.company_task_id:
        try:
            from aibrain.core.task_verification import verify_and_complete
            work_output = {
                "output": result.output,
                "success": result.success,
                "error": result.error,
                "quality": result.quality,
                "quality_checks": result.quality_checks,
                "evaluation_detail": result.evaluation_detail,
                "summary": str(result.output)[:4000] if result.output else "",
            }
            verification = verify_and_complete(config.company_task_id, work_output)
            result.verification = verification
            result.follow_up_tasks = verification.get("follow_up_tasks", [])
            if verification.get("gaps"):
                log.info(
                    "Harness verify: task %s status=%s gaps=%d follow_ups=%d",
                    config.company_task_id,
                    verification.get("verification_status"),
                    len(verification["gaps"]),
                    len(verification.get("follow_up_tasks", [])),
                )
        except Exception as e:
            log.warning("Harness verification step failed: %s", e)

    # Emit harness.task.complete / harness.task.fail — fire-and-forget
    try:
        from aibrain.core.event_bus import emit as _bus_emit, EventTypes as _ET
        _event_type = _ET.HARNESS_TASK_COMPLETE if result.success else _ET.HARNESS_TASK_FAIL
        _bus_emit(_event_type, {
            "run_id": run_id,
            "task": task,
            "task_type": config.task_type,
            "actor": config.actor,
            "success": result.success,
            "quality": result.quality,
            "duration_ms": result.duration_ms,
            "model_used": result.model_used,
            "error": result.error,
        }, actor=config.actor)
    except Exception:
        pass

    return result


# ---------------------------------------------------------------------------
# Pipeline Steps
# ---------------------------------------------------------------------------

def _check_budget(config: HarnessConfig) -> tuple[bool, str]:
    """Check if budget allows this execution.

    Checks budget_policies table for applicable limits.
    Creates budget_incidents at 80% (warning) and 100% (hard stop).
    """
    # Deterministic tasks cost nothing — always allowed
    if config.task_type == "deterministic":
        return True, "deterministic: $0"

    try:
        db_path = _find_db()
        if not db_path:
            return True, "no db — skipping budget check"

        import sqlite3
        db = _db_open(db_path)
        db.execute("PRAGMA journal_mode=WAL")
        db.row_factory = sqlite3.Row

        # Find applicable budget policies (global or scoped to actor)
        policies = db.execute("""
            SELECT * FROM budget_policies
            WHERE is_active=1 AND (scope_type='global' OR scope_id=?)
            ORDER BY scope_type DESC
        """, (config.actor,)).fetchall()

        if not policies:
            db.close()
            return True, "no budget policy"

        for policy in policies:
            limit = policy["limit_cents"]
            warn_pct = policy["warn_percent"]

            # Calculate current spend in this window
            if policy["window"] == "month":
                window_sql = "AND timestamp > datetime('now', '-30 days')"
            elif policy["window"] == "week":
                window_sql = "AND timestamp > datetime('now', '-7 days')"
            elif policy["window"] == "day":
                window_sql = "AND timestamp > datetime('now', '-1 day')"
            else:
                window_sql = ""  # lifetime

            try:
                spent_row = db.execute(
                    "SELECT COALESCE(SUM(cost_usd * 100), 0) as spent FROM costs WHERE 1=1 " + window_sql
                ).fetchone()
                spent = int(spent_row["spent"]) if spent_row else 0
            except Exception:
                spent = 0

            # Check thresholds
            if limit > 0:
                pct = (spent / limit * 100) if limit else 0

                if pct >= 100 and policy["hard_stop"]:
                    # Create incident
                    try:
                        db.execute(
                            "INSERT INTO budget_incidents (policy_id, scope_type, scope_id, threshold_type, limit_cents, observed_cents) VALUES (?, ?, ?, 'hard_stop', ?, ?)",
                            (policy["id"], policy["scope_type"], policy["scope_id"], limit, spent)
                        )
                        db.commit()
                    except Exception:
                        pass
                    db.close()
                    return False, f"Budget exceeded: ${spent/100:.2f}/${limit/100:.2f} ({pct:.0f}%)"

                elif pct >= warn_pct:
                    log.warning("Budget warning: %.0f%% used ($%.2f/$%.2f)",
                               pct, spent/100, limit/100)
                    try:
                        db.execute(
                            "INSERT INTO budget_incidents (policy_id, scope_type, scope_id, threshold_type, limit_cents, observed_cents) VALUES (?, ?, ?, 'warning', ?, ?)",
                            (policy["id"], policy["scope_type"], policy["scope_id"], limit, spent)
                        )
                        db.commit()
                    except Exception:
                        pass

        db.close()
        return True, "ok"

    except Exception as e:
        log.warning("Budget check error (failing closed — spend denied): %s", e)
        return False, f"budget check failed — denying spend: {e}"


def _check_capability(authority: str, capabilities: list) -> tuple[bool, str]:
    """Gate execution against AUTHORITY_CAPABILITIES for the requested capability list.

    A capability is allowed when:
    - The authority level's "allowed" set contains "*" (admin), OR
    - The capability is explicitly in the "allowed" set for that authority

    A capability is denied when it appears in the "denied" set.
    Capabilities not listed in either set are allowed by default (permissive unknown).

    Returns:
        (True, "ok") — all capabilities pass
        (False, "<reason>") — at least one capability is denied
    """
    if not capabilities:
        return True, "ok"

    try:
        auth = Authority(authority)
    except ValueError:
        return True, "unknown authority — capability check skipped"

    caps = AUTHORITY_CAPABILITIES.get(auth, {})
    allowed = caps.get("allowed", set())
    denied = caps.get("denied", set())

    if "*" in allowed:
        return True, "ok"  # admin — all capabilities allowed

    for cap in capabilities:
        if cap in denied:
            return False, (
                f"Capability '{cap}' is denied for authority '{authority}'. "
                f"Workflow needs elevated or admin authority to use '{cap}'."
            )

    return True, "ok"


def _check_authority(task: str, config: HarnessConfig) -> tuple[bool, str]:
    """Check if the configured authority level allows this task.

    Two-layer check:
    1. Harness authority level (read_only/standard/elevated/admin)
    2. Database agent_permissions table (allow_always/require_approval/deny)
    """
    try:
        authority = Authority(config.authority)
    except ValueError:
        return True, "unknown authority level — defaulting to allow"

    caps = AUTHORITY_CAPABILITIES.get(authority, {})
    allowed = caps.get("allowed", set())
    denied = caps.get("denied", set())
    needs_approval = caps.get("requires_approval", set())

    # Extract the action type from the task name
    action = task.split(".")[0] if "." in task else task
    # Also check the second part (e.g., "workflow.heartbeat" → check "heartbeat" too)
    sub_action = task.split(".")[-1] if "." in task else task

    if "*" in allowed:
        # Admin level — still check DB permissions for explicit denials
        pass
    elif action in denied:
        return False, f"Authority '{config.authority}' denies action '{action}'"
    elif action in needs_approval:
        return False, f"Action '{action}' requires approval at authority level '{config.authority}'"

    # Layer 1b: Capability gate — enforce declared capabilities against AUTHORITY_CAPABILITIES
    # This is the runtime enforcement for the previously documentation-only AUTHORITY_CAPABILITIES dict.
    # Workflows declare what they need via HarnessConfig.capabilities (populated from WORKFLOW_REGISTRY).
    cap_ok, cap_msg = _check_capability(config.authority, getattr(config, "capabilities", []))
    if not cap_ok:
        return False, cap_msg

    # Layer 2: Check database permissions
    try:
        db_path = _find_db()
        if db_path:
            import sqlite3
            db = _db_open(db_path)
            db.execute("PRAGMA journal_mode=WAL")
            db.row_factory = sqlite3.Row

            # Check for explicit deny or require_approval
            for check_action in [action, sub_action]:
                row = db.execute(
                    "SELECT permission FROM agent_permissions WHERE action_type=? AND (target=? OR target='*') ORDER BY target DESC LIMIT 1",
                    (check_action, config.actor)
                ).fetchone()

                if row:
                    perm = row["permission"]
                    if perm == "deny":
                        db.close()
                        return False, f"Permission denied: '{check_action}' is explicitly denied in agent_permissions"
                    elif perm == "require_approval":
                        db.close()
                        return False, f"Action '{check_action}' requires approval per agent_permissions table"

            db.close()
    except Exception as e:
        log.debug("Permission DB check failed: %s", e)

    return True, "ok"


def _check_enforcement(task: str, config: HarnessConfig, before_state: dict = None) -> tuple[bool, str]:
    """Run HARD RULE enforcement checks before execution.

    Maps task names to enforcement points and runs all applicable rules.
    A single blocking violation stops execution.
    """
    try:
        from aibrain.core.enforcement import enforce, load_rules

        # Map task action to enforcement point(s)
        action = task.split(".")[0] if "." in task else task
        points_to_check = []

        if action in ("git_commit", "commit"):
            points_to_check.append("pre_commit")
        if action in ("git_push", "push"):
            points_to_check.append("pre_push")
        if action in ("delete_file", "delete", "rm", "remove"):
            points_to_check.append("pre_delete")
        if action in ("publish", "post", "send_email", "tweet", "linkedin"):
            points_to_check.append("pre_publish")
        if action in ("spend", "purchase", "buy", "pay", "trade"):
            points_to_check.append("pre_spend")

        # Always run pre_action for any elevated/admin task
        if config.authority in ("elevated", "admin"):
            points_to_check.append("pre_action")

        if not points_to_check:
            return True, "no enforcement points applicable"

        # Build context from before_state and task info
        context = dict(before_state) if before_state else {}
        context.setdefault("action", action)
        context.setdefault("actor", config.actor)

        rules = load_rules()
        all_violations = []

        for point in set(points_to_check):
            result = enforce(point, context, rules=rules)
            all_violations.extend(result.violations)

        if all_violations:
            msgs = [f"[{v.rule_id}] {v.message}" for v in all_violations]
            return False, f"HARD RULE enforcement blocked: {'; '.join(msgs)}"

        return True, "enforcement passed"

    except ImportError:
        log.debug("enforcement module not available — skipping")
        return True, "enforcement module not loaded"
    except Exception as e:
        log.warning("Enforcement check error: %s", e)
        # Fail CLOSED for elevated/admin/critical authority — never allow on exception
        if config.authority in ("elevated", "admin", "critical"):
            return False, "enforcement check failed — denied for safety"
        # Fail open for standard/lower authority — don't break the harness if enforcement has a bug
        return True, f"enforcement error (allowed): {e}"


def classify_risk(task: str, config: HarnessConfig) -> RiskLevel:
    """Classify task risk level based on action type and authority.

    Returns:
        RiskLevel.LOW    — safe, auto-approve
        RiskLevel.MEDIUM — auto-approve but flag for review
        RiskLevel.HIGH   — require explicit human approval
    """
    action = task.split(".")[0] if "." in task else task

    # If caller explicitly requests approval, treat as high risk
    if config.require_approval:
        return RiskLevel.HIGH

    # Check action against risk sets
    if action in HIGH_RISK_ACTIONS:
        return RiskLevel.HIGH
    if action in MEDIUM_RISK_ACTIONS:
        return RiskLevel.MEDIUM

    # Elevated/admin authority doing unknown actions = medium risk
    if config.authority in ("elevated", "admin") and action not in {
        "read_file", "write_file", "search_memory", "store_memory",
        "query_db", "list_files", "format_text",
    }:
        return RiskLevel.MEDIUM

    return RiskLevel.LOW


def _check_approval(task: str, config: HarnessConfig) -> str:
    """Risk-classified approval gate.

    Returns an approval status string:
        "not_required"              — no approval gate applicable
        "auto_approved_low_risk"    — classified low risk, auto-approved honestly
        "auto_approved_medium_risk" — classified medium risk, auto-approved, flagged for review
        "approved"                  — explicit human approval found in DB
        "pending_approval"          — high risk, no approval found, BLOCKS execution
        "denied"                    — explicit human denial found in DB
    """
    risk = classify_risk(task, config)

    # Check DB for explicit approval/denial regardless of risk level
    db_status = _query_approval_db(task, config)

    if db_status == "denied":
        log.warning("Task '%s' explicitly denied in approval queue", task)
        return "denied"
    if db_status == "approved":
        log.info("Task '%s' explicitly approved via queue", task)
        return "approved"

    # No explicit DB entry — route by risk level
    if risk == RiskLevel.LOW:
        log.debug("Task '%s' auto-approved (low risk)", task)
        return "auto_approved_low_risk"

    if risk == RiskLevel.MEDIUM:
        log.info("Task '%s' auto-approved (medium risk) — flagged for review", task)
        return "auto_approved_medium_risk"

    # HIGH risk with no explicit approval — create pending entry and block
    _create_pending_approval(task, config)
    log.warning("Task '%s' requires approval — pending entry created, execution blocked", task)
    return "pending_approval"


def _query_approval_db(task: str, config: HarnessConfig) -> Optional[str]:
    """Query the approvals table for an explicit approval/denial.

    Returns 'approved', 'denied', or None if no entry found.
    """
    try:
        db_path = _find_db()
        if db_path:
            db = _db_open(db_path)
            db.row_factory = sqlite3.Row
            row = db.execute(
                "SELECT status FROM approvals WHERE task=? AND (actor=? OR actor='*') ORDER BY created_at DESC LIMIT 1",
                (task, config.actor or "system")
            ).fetchone()
            db.close()
            if row:
                return row["status"]
    except Exception as e:
        log.debug("Approval DB check failed (table may not exist yet): %s", e)
    return None


def _create_pending_approval(task: str, config: HarnessConfig):
    """Insert a pending approval entry so a human can approve/deny later."""
    try:
        # Bug #6 fix: use _get_or_create_db so approval requests persist on
        # fresh installs instead of silently no-op'ing.
        db_path = _get_or_create_db()
        db = _db_open(db_path)
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""
            CREATE TABLE IF NOT EXISTS approvals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task TEXT NOT NULL,
                actor TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                risk_level TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                resolved_at TIMESTAMP
            )
        """)
        db.execute(
            "INSERT INTO approvals (task, actor, status, risk_level) VALUES (?, ?, 'pending', 'high')",
            (task, config.actor or "system")
        )
        db.commit()
        db.close()
        log.info("Created pending approval entry for task '%s' actor '%s'", task, config.actor)
    except Exception as e:
        log.warning("Failed to create pending approval entry: %s", e)


def _evaluate_quality(task: str, output: Any, config: HarnessConfig):
    """
    Evaluate the quality of task output.

    Returns (score 0.0-1.0 OR None, detail string).

    Returns None as the score when there is no real signal to measure.
    The caller must propagate None and store NULL in quality_score rather
    than fake a baseline. The previous version returned a hardcoded 0.5
    "base score" for JUDGMENT/COMPLEX string outputs which made 79% of
    execution_log rows show quality_score=0.5 exactly (Round 1 honest-rubric audit).

    For deterministic tasks: binary pass/fail based on output existence.
    For LLM tasks: only scores when the output shape is informative.
    """
    task_type = TaskType(config.task_type)

    if output is None:
        # For deterministic tasks, None output with no error = "nothing to do" = success
        if task_type == TaskType.DETERMINISTIC:
            return 0.7, "deterministic: completed with no output (nothing to do)"
        return 0.0, "no output produced"

    score = None  # sentinel — concrete cases below will overwrite; default is "could not measure"
    detail_parts = []

    # ─── Error-signal override (applies to all output types) ─────────────
    # Check the full string representation for hard error signals regardless
    # of any success flag — a dict with success=True but output="Traceback..."
    # should not score 0.9.
    error_override_signals = ["traceback", "exception", "attributeerror", "typeerror",
                               "valueerror", "runtimeerror", "importerror", "keyerror",
                               "zerodivisionerror", "filenotfounderror", "permissionerror"]
    output_repr = str(output).lower()
    has_error_override = any(sig in output_repr for sig in error_override_signals)

    # ─── Type-aware evaluation ────────────────────────────
    # Dict with status/success keys (structured result). A dict WITHOUT an
    # explicit success/error key carries no quality information — we refuse
    # to fake a "structured output" baseline. (Round 1 honest-rubric audit.)
    if isinstance(output, dict):
        # SuperWorker shape — recognize ONLY when there's a real result
        # object with parse_status. Generic actions can use _self_score /
        # _cost_cents WITHOUT being SuperWorkers, so the bare presence
        # of those keys is not enough.
        sw_result = output.get("result")
        is_superworker = (
            sw_result is not None
            and (hasattr(sw_result, "parse_status") or hasattr(sw_result, "synthesis_confidence"))
        )
        if is_superworker:
            ps = getattr(sw_result, "parse_status", None)
            sw_success = getattr(sw_result, "success", None)
            sw_conf = getattr(sw_result, "synthesis_confidence", None)
            if ps == "failed" or sw_success is False:
                score = 0.2
                detail_parts.append(f"superworker failed: parse_status={ps} success={sw_success}")
            elif ps == "partial":
                # Partial parse — synthesis section present but markdown
                # regex couldn't extract everything cleanly. Score
                # honestly: prefer synthesis_confidence if measured,
                # else 0.5 as the partial-floor.
                if sw_conf is not None:
                    score = float(sw_conf) * 0.85  # discount partial output
                else:
                    score = 0.5
                detail_parts.append(f"superworker partial: conf={sw_conf}")
            else:
                # ok parse — score from synthesis_confidence if present,
                # else accept-on-success at 0.85 (lower than the old
                # 0.9 default to leave headroom for divergence).
                if sw_conf is not None:
                    score = float(sw_conf)
                    detail_parts.append(f"superworker ok: synthesis_conf={sw_conf}")
                else:
                    score = 0.85
                    detail_parts.append("superworker ok: no synthesis_conf, accept-on-success")
        elif output.get("error") or output.get("status") == "failed":
            score = 0.2
            detail_parts.append("dict: error indicator present")
        elif has_error_override:
            score = 0.2
            detail_parts.append("dict: exception detected in output values")
        elif output.get("success") or output.get("status") in ("ok", "healthy", "done"):
            score = 0.9
            detail_parts.append("dict: success indicator present")
        else:
            score = None  # no explicit success/error signal — refuse to stamp
            detail_parts.append("dict: no explicit success/error key — could not measure")

    # Tuple (common for count-based results like (ok, failed))
    elif isinstance(output, tuple):
        if len(output) >= 2 and isinstance(output[0], (int, float)):
            ok_count = output[0]
            fail_count = output[1] if len(output) > 1 else 0
            if isinstance(fail_count, (int, float)) and fail_count == 0 and ok_count > 0:
                score = 1.0
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
            elif ok_count > 0:
                score = 0.7
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
            else:
                score = 0.3
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
        else:
            score = 0.6
            detail_parts.append("tuple: non-numeric tuple returned")

    # Boolean
    elif isinstance(output, bool):
        score = 1.0 if output else 0.0
        detail_parts.append(f"bool: {output}")

    # List (results collection)
    elif isinstance(output, list):
        score = 0.8 if len(output) > 0 else 0.3
        detail_parts.append(f"list: {len(output)} items")

    # String or other
    else:
        output_str = str(output)

        # Deterministic: any non-empty output is good
        if task_type == TaskType.DETERMINISTIC:
            score = 0.9 if len(output_str) > 0 else 0.0
            detail_parts.append("deterministic: output produced")
        # Simple
        elif task_type == TaskType.SIMPLE:
            score = 0.8 if len(output_str) > 5 else 0.3
            detail_parts.append("simple: text output")
        # Judgment/Complex: only scoreable when there are explicit signals.
        # Length alone is not signal — long strings can be wrong, short can be right.
        # Refuse to stamp a base score; let the caller treat None as "could not measure".
        else:
            score = None
            detail_parts.append("judgment/complex: no signal in shape alone")

        # Error/success signal check for string outputs.
        # Only apply when we already have a score (DETERMINISTIC/SIMPLE paths).
        # For JUDGMENT/COMPLEX, score is None — we do NOT stamp a number from
        # bare string keywords, which would break the honest-None contract.
        # Exception: hard Python exception signals (traceback, AttributeError, etc.)
        # are reliable and safe to stamp even for JUDGMENT/COMPLEX.
        if has_error_override:
            # Traceback/exception class names: reliable signal, always apply.
            score = 0.2 if score is None else max(0.0, score - 0.3)
            detail_parts.append("exception/traceback detected")
        elif score is not None and any(sig in output_repr for sig in ["error", "failed"]):
            # Bare keyword signals: unreliable (false-positives on substantive output).
            # Only apply when we already have a score, never to stamp None outputs.
            score = max(0.0, score - 0.2)
            detail_parts.append("contains error signals")
        if score is not None and any(sig in output_repr for sig in ["success", "completed", "done", "posted", "created", "saved"]):
            # Same guard: only boost an existing score, never stamp None.
            score = min(1.0, score + 0.1)
            detail_parts.append("contains success signals")

    if score is None:
        return None, "; ".join(detail_parts) or "could not measure (no signal)"
    return max(0.0, min(1.0, score)), "; ".join(detail_parts) or "evaluated"


# ---------------------------------------------------------------------------
# Automated Quality Checks (post-task verification)
# ---------------------------------------------------------------------------

def _check_git_committed(repo_path: str = None) -> tuple[bool, str]:
    """Check if there are uncommitted changes (implies work wasn't committed)."""
    import subprocess
    try:
        cwd = repo_path or "."
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=10, cwd=cwd,
        )
        if result.returncode != 0:
            return False, "git not available"
        dirty = result.stdout.strip()
        if dirty:
            return False, f"uncommitted changes: {len(dirty.splitlines())} files"
        return True, "clean working tree"
    except Exception as e:
        return False, f"git check failed: {e}"


def _check_tests_pass(test_cmd: str = None) -> tuple[bool, str]:
    """Run test suite and check if tests pass."""
    import subprocess
    cmd = test_cmd or "python -m pytest --tb=no -q"
    try:
        result = subprocess.run(
            cmd.split(),
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            return True, "tests pass"
        # Extract failure count from pytest output
        output = result.stdout + result.stderr
        return False, f"tests failed (exit {result.returncode})"
    except Exception as e:
        return False, f"test check failed: {e}"


def _check_files_changed(before_files: dict = None) -> tuple[bool, str]:
    """Check if files were actually modified (not a no-op)."""
    if not before_files:
        return False, "no before_state to compare"
    # If before_state has file counts or hashes, compare
    if "file_count" in before_files:
        return True, "before_state recorded"
    return False, "no file tracking data"


def _check_output_not_error(output: Any) -> tuple[bool, str]:
    """Check that the output doesn't represent an error.

    Honest-rubric rule: check STRUCTURED error indicators only. Never
    pattern-match the full str repr — that gives false positives when an
    action's substantive output happens to discuss error scenarios (e.g.
    a SuperWorker producing a migration plan that mentions "rollback path"
    or "exception handling" gets falsely flagged as containing errors).

    Apr 11 SuperWorker dogfood caught this: the SuperWorker successfully
    produced a 15K-char migration plan with parse_status='ok' and
    success=True, but the str-pattern check found "error" in the synthesis
    body and flagged the run as failed.

    Recognized success/error signals (in priority order):
      1. dict with 'error' key set (truthy) → FAIL
      2. dict with 'success' key explicitly False → FAIL
      3. dict with 'status' in ('failed', 'error') → FAIL
      4. dict with SuperWorker shape (_self_score / _cost_cents / result):
         - if result has parse_status='failed' → FAIL
         - if result has success=False → FAIL
         - else → PASS
      5. dict with explicit success indicators → PASS
      6. None output → FAIL
      7. anything else → PASS (no negative signal)
    """
    if output is None:
        return False, "no output"

    if isinstance(output, dict):
        # SuperWorker shape — recognize via the harness self-report keys
        if "_self_score" in output or "_cost_cents" in output or "result" in output:
            sw_result = output.get("result")
            if sw_result is not None:
                # Check the SuperWorkerResult fields directly
                if getattr(sw_result, "parse_status", None) == "failed":
                    return False, "superworker parse_status=failed"
                if getattr(sw_result, "success", True) is False:
                    return False, "superworker success=False"
                return True, "superworker output ok"
            # No result object but harness self-report keys present — accept
            return True, "harness self-report dict (no error indicator)"
        # Generic dict shape
        if output.get("error"):
            return False, f"dict has error key: {str(output['error'])[:80]}"
        if output.get("success") is False:
            return False, "dict success=False"
        if output.get("status") in ("failed", "error"):
            return False, f"dict status={output['status']}"
        return True, "no structured error indicator"

    # For non-dict outputs (strings, lists, bools, etc.) we used to scan
    # the str repr for error words — that produced false positives for
    # any substantive output that discussed error handling. Per honest-
    # rubric: refuse to fake a signal. Non-dict success cases pass.
    return True, "no structured error indicator"


def _check_output_substantive(output: Any) -> tuple[bool, str]:
    """Check that the output has substance (not empty/trivial)."""
    if output is None:
        return False, "no output"
    if isinstance(output, dict):
        if output.get("success") or output.get("status") in ("ok", "done", "healthy"):
            return True, "success indicator"
        if output.get("error"):
            return False, "error in dict"
        return bool(output), "dict with data" if output else "empty dict"
    if isinstance(output, (list, tuple)):
        return len(output) > 0, f"{len(output)} items"
    if isinstance(output, bool):
        return output, f"bool={output}"
    if isinstance(output, str):
        return len(output) > 5, f"{len(output)} chars"
    return True, "has output"


# Check registry: name -> (check_fn, weight, requires_context)
QUALITY_CHECKS = {
    "output_no_error": (_check_output_not_error, 0.30, False),
    "output_substantive": (_check_output_substantive, 0.30, False),
    "git_committed": (_check_git_committed, 0.20, True),
    "tests_pass": (_check_tests_pass, 0.20, True),
}


def evaluate_task_quality(
    output: Any,
    task_name: str = "",
    config: HarnessConfig = None,
    self_score: float = None,
    run_checks: list = None,
    before_state: dict = None,
    repo_path: str = None,
    test_cmd: str = None,
) -> dict:
    """
    Honest quality evaluation combining automated checks and output analysis.

    Returns:
        {
            "eval_score": float,       # system-measured score (0.0-1.0)
            "self_score": float|None,   # what the caller claimed (if any)
            "verified": bool,           # True if automated checks ran
            "checks": {name: {"passed": bool, "detail": str, "weight": float}},
            "divergence": float|None,   # abs(self_score - eval_score) if both present
            "flagged": bool,            # True if divergence > 0.3
            "detail": str,              # human-readable summary
        }
    """
    if config is None:
        config = HarnessConfig()

    checks_to_run = run_checks or ["output_no_error", "output_substantive"]
    check_results = {}
    weighted_sum = 0.0
    total_weight = 0.0

    for check_name in checks_to_run:
        if check_name not in QUALITY_CHECKS:
            continue
        check_fn, weight, requires_context = QUALITY_CHECKS[check_name]

        # Skip context-dependent checks unless context provided
        if requires_context:
            if check_name == "git_committed" and repo_path is None:
                continue
            if check_name == "tests_pass" and test_cmd is None:
                continue

        try:
            if check_name == "output_no_error":
                passed, detail = check_fn(output)
            elif check_name == "output_substantive":
                passed, detail = check_fn(output)
            elif check_name == "git_committed":
                passed, detail = check_fn(repo_path)
            elif check_name == "tests_pass":
                passed, detail = check_fn(test_cmd)
            else:
                passed, detail = check_fn()
        except Exception as e:
            passed, detail = False, f"check error: {e}"

        check_results[check_name] = {
            "passed": passed,
            "detail": detail,
            "weight": weight,
        }
        weighted_sum += weight * (1.0 if passed else 0.0)
        total_weight += weight

    # Also run the existing output-shape evaluation. Both of these now
    # return None when they cannot make a real measurement — see the
    # Round 1 honest-rubric audit (the previous default-0.5 stamp made 79% of rows
    # collapse to exactly 0.5 regardless of actual quality).
    shape_score, shape_detail = _evaluate_quality(task_name, output, config)
    workflow_score = _evaluate_workflow_specific(task_name, output)

    # Build the eval_score from whichever components have real signal.
    #
    # Honest-rubric rule: a real eval_score requires at least one of
    # workflow_score or shape_score to be non-None. Automated checks like
    # output_no_error / output_substantive are verification flags ("the task
    # didn't crash and produced output") — they are necessary but NOT
    # sufficient to claim quality. A task that doesn't crash but produces
    # garbage should not score 1.0 just because nothing exploded.
    #
    # Without that rule, the 79%-of-rows-stamped-0.5 production bug becomes
    # "79%-of-rows-stamped-0.8214" which is still fake. We refuse to fake.
    if workflow_score is None and shape_score is None:
        # No real quality signal — even if checks passed, we don't claim a number.
        eval_score = None
        verified = total_weight > 0  # checks may still have run; they just don't make a score
    else:
        components = []
        if total_weight > 0:
            components.append(("checks", 0.4, weighted_sum / total_weight))
        if workflow_score is not None:
            components.append(("workflow", 0.3, workflow_score))
        if shape_score is not None:
            components.append(("shape", 0.3, shape_score))
        weight_sum = sum(w for _, w, _ in components)
        eval_score = sum(w * s for _, w, s in components) / weight_sum
        eval_score = max(0.0, min(1.0, eval_score))
        verified = total_weight > 0

    # ─── Domain correction trend adjustment ──────────────────
    # Factor the domain's correction trend into quality score (only when we
    # have a real eval_score to begin with — never invent one from a NULL).
    domain_trend = None
    if eval_score is not None:
        try:
            from aibrain.core.correction_baseline import classify_domain, correction_baseline
            domain = classify_domain(task_name)
            baseline = correction_baseline(days=30)
            domain_info = baseline.get("domains", {}).get(domain)
            if domain_info:
                domain_trend = domain_info.get("trend")
                if domain_trend == "learning":
                    eval_score += 0.05
                elif domain_trend == "regressing":
                    eval_score -= 0.05
                eval_score = max(0.0, min(1.0, eval_score))
        except Exception:
            pass  # Correction trend is advisory — never blocks evaluation

    # Divergence detection — requires both self_score and eval_score to compare.
    divergence = None
    flagged = False
    if self_score is not None and eval_score is not None:
        divergence = abs(self_score - eval_score)
        flagged = divergence > 0.3

    # Build detail string
    detail_parts = []
    for name, result in check_results.items():
        status = "PASS" if result["passed"] else "FAIL"
        detail_parts.append(f"{name}:{status}")
    detail_parts.append(f"workflow:{workflow_score:.2f}" if workflow_score is not None else "workflow:NULL")
    detail_parts.append(f"shape:{shape_score:.2f}" if shape_score is not None else "shape:NULL")
    if domain_trend and domain_trend in ("learning", "regressing"):
        detail_parts.append(f"domain_trend:{domain_trend}")
    if flagged:
        detail_parts.append(f"FLAGGED:divergence={divergence:.2f}")
    if eval_score is None:
        detail_parts.append("eval_score:NULL (no measurable signal — refused to fake a baseline)")

    result = {
        "eval_score": round(eval_score, 4) if eval_score is not None else None,
        "self_score": self_score,
        "verified": verified,
        "checks": check_results,
        "domain_trend": domain_trend,
        "divergence": round(divergence, 4) if divergence is not None else None,
        "flagged": flagged,
        "detail": "; ".join(detail_parts),
    }

    # Emit QUALITY_LOW only when we have a real score and it's actually low.
    if eval_score is not None and eval_score < 0.5:
        try:
            from aibrain.core.event_bus import emit as bus_emit, EventTypes
            bus_emit(EventTypes.QUALITY_LOW, {
                "task_name": task_name,
                "eval_score": round(eval_score, 4),
                "self_score": self_score,
                "flagged": flagged,
                "detail": result["detail"],
            })
        except Exception:
            pass  # Event emission never blocks evaluation

    return result


def _log_audit(
    run_id: str,
    config: HarnessConfig,
    task: str,
    result: HarnessResult,
    before_state: dict = None,
    linked_issue_id: Optional[str] = None,
) -> str:
    """Log execution to audit trail.

    When ``linked_issue_id`` is provided (typically pulled from
    ``companies._current_issue`` during a checkout window), the row is
    stamped with entity_type='company_issue' and entity_id=<issue id> so
    audit queries can join execution_log back to company_issues. When
    ``linked_issue_id`` is None, the row falls back to the legacy
    entity_type='task' / entity_id=NULL behavior for backcompat.
    """
    audit_id = secrets.token_urlsafe(8)

    try:
        # Log to aibrain.db execution_log table. Use _get_or_create_db() so
        # fresh installs get a persisted audit row on the first call instead
        # of silently no-op'ing (Bug #6 — _find_db's existence check made
        # first-ever audit writes disappear on clean machines).
        db_path = _get_or_create_db()
        db = _db_open(db_path)
        db.execute("PRAGMA journal_mode=WAL")

        # Create table if it doesn't exist. Fresh installs get the
        # full schema; existing DBs are migrated via
        # scripts/migrate_execution_log_self_score.py which is also
        # idempotent (existing-column check).
        db.execute("""
            CREATE TABLE IF NOT EXISTS execution_log (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                detail TEXT,
                quality_score REAL,
                self_score REAL,
                divergence REAL,
                flagged INTEGER DEFAULT 0,
                model_used TEXT,
                cost_cents INTEGER,
                cost_cents_actual INTEGER,
                cost_cents_equivalent INTEGER,
                duration_ms INTEGER DEFAULT 0,
                before_state TEXT,
                after_state TEXT,
                success INTEGER DEFAULT 0,
                error TEXT,
                task_type TEXT,
                authority TEXT,
                retries INTEGER DEFAULT 0,
                output_token_escalated INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # Fix 4: migrate existing DBs — change cost_cents DEFAULT 0 to NULL.
        # SQLite cannot ALTER a column default in-place, so we do a targeted
        # UPDATE: set cost_cents=NULL for rows where cost_cents=0 AND there is
        # no self-reported actual cost (cost_cents_actual IS NULL). That's the
        # signature of "DEFAULT 0 snuck in" vs. "action genuinely reported free."
        # Deterministic tasks (task_type='deterministic') legitimately cost 0
        # (no LLM call) — those keep their 0 value.
        #
        # This runs on every harness call but only touches rows matching the
        # exact condition — idempotent, fast (indexed on cost_cents and task_type),
        # no data loss.
        try:
            db.execute("""
                UPDATE execution_log
                SET cost_cents = NULL
                WHERE cost_cents = 0
                  AND cost_cents_actual IS NULL
                  AND (task_type IS NULL OR task_type != 'deterministic')
            """)
        except Exception as _mig_err:
            log.debug("cost_cents NULL migration (non-fatal): %s", _mig_err)
        # Idempotent column migration for pre-Apr11 DBs (task #11 —
        # token-to-cents equivalence + token escalation column).
        # ALTER TABLE throws if the column already exists; we catch and ignore.
        for ddl in (
            "ALTER TABLE execution_log ADD COLUMN cost_cents_actual INTEGER",
            "ALTER TABLE execution_log ADD COLUMN cost_cents_equivalent INTEGER",
            "ALTER TABLE execution_log ADD COLUMN output_token_escalated INTEGER DEFAULT 0",
            "ALTER TABLE execution_log ADD COLUMN text_id TEXT",
        ):
            try:
                db.execute(ddl)
            except sqlite3.OperationalError:
                pass  # column already exists

        # When a company task is checked out on this thread, stamp the
        # row with entity_type='company_issue' and entity_id=<issue id>
        # so audit queries can join execution_log back to company_issues.
        # Otherwise keep the legacy entity_type='task' (entity_id NULL)
        # for backcompat with callers that don't use company checkouts.
        if linked_issue_id:
            entity_type_val = "company_issue"
            entity_id_val = linked_issue_id
        else:
            entity_type_val = "task"
            entity_id_val = None

        # ─── Honest cost sentinel ────────────────────────────────────────────
        # -1 = "ran but couldn't measure" (distinguishable from 0 = explicitly free
        # and NULL = never set). Non-deterministic rows that still have no cost
        # signal at write time get -1 so the dishonesty is visible in queries
        # rather than hidden as NULL or fake-0.
        # Deterministic tasks (code_only) legitimately stay at 0 or NULL.
        _cost_to_log = result.cost_cents
        if (
            _cost_to_log is None
            and config.task_type != "deterministic"
            and result.model_used not in ("code_only",)
        ):
            _cost_to_log = -1

        try:
            from aibrain.core.db_safety import session_id as _sid
            _session_id = _sid()
        except Exception:
            _session_id = None
        db.execute("""
            INSERT INTO execution_log
            (text_id, run_id, actor, action, entity_type, entity_id, detail, quality_score,
             self_score, divergence, flagged,
             model_used, cost_cents, cost_cents_actual, cost_cents_equivalent,
             duration_ms, before_state, after_state,
             success, error, task_type, authority, retries, output_token_escalated, session_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            audit_id, run_id, config.actor, task,
            entity_type_val,
            entity_id_val,
            json.dumps({
                "tags": config.tags,
                "evaluation": result.evaluation_detail,
                "budget_check": result.budget_check,
                "authority_check": result.authority_check,
                "approval_status": result.approval_status,
                "data_classification": result.data_classification,
            }),
            result.quality, result.self_score, result.divergence,
            1 if result.flagged else 0,
            result.model_used, _cost_to_log,
            result.cost_cents_actual, result.cost_cents_equivalent,
            result.duration_ms,
            json.dumps(before_state) if before_state else None,
            json.dumps({"output_preview": str(result.output)[:500]}) if result.output else None,
            1 if result.success else 0,
            result.error,
            config.task_type, config.authority, result.retries,
            1 if result.output_token_escalated else 0,
            _session_id,
        ])
        db.commit()
        db.close()

    except Exception as e:
        log.warning("Failed to write audit log: %s", e)

    return audit_id


def _record_learning(task: str, result: HarnessResult, config: HarnessConfig):
    """Record execution outcome for skill learning and evolution.

    The outcome category is derived from BOTH success and quality, not from
    success alone. The previous version stamped every row with
    `result='success' if no exception' else 'failure'` which made 1,299
    rows in a row all say 'success' regardless of actual outcome
    (Round 1 honest-rubric audit). This version:

      - 'failure'   = execution raised or flag is False (failure_reason set)
      - 'flagged'   = execution OK but measured quality below 0.5
                      (failure_reason describes why)
      - 'partial'   = execution OK, quality 0.5-0.8
      - 'succeeded' = execution OK, quality >= 0.8
      - 'no_signal' = execution OK but quality is None
                      (rubric couldn't measure — we still record for visibility)

    The `source` column now carries `harness:<task_type>` so downstream can
    filter by task complexity (deterministic vs simple vs judgment vs complex)
    rather than seeing a constant 'harness' stamp on every row.
    """
    try:
        # Bug #6 fix: use _get_or_create_db so fresh installs get their first
        # evolution_outcomes row instead of silently no-op'ing.
        db_path = _get_or_create_db()

        db = _db_open(db_path)
        db.execute("PRAGMA journal_mode=WAL")

        # Record in evolution_outcomes for pattern detection
        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Classify the outcome honestly
        failure_reason = None
        if not result.success:
            outcome = "failure"
            failure_reason = (result.error or "execution failed (no error message captured)")[:500]
        elif result.quality is None:
            # Execution succeeded but rubric could not measure — be honest about it.
            outcome = "no_signal"
            failure_reason = "rubric could not measure — no workflow or shape signal"
        elif result.quality >= 0.8:
            outcome = "succeeded"
        elif result.quality >= 0.5:
            outcome = "partial"
            failure_reason = f"quality {result.quality:.2f} in partial band (0.5-0.8)"
        else:
            outcome = "flagged"
            failure_reason = f"quality {result.quality:.2f} below threshold 0.5"

        details_dict = {
            "quality": result.quality,
            "model_used": result.model_used,       # what actually ran (may be None)
            "model_routed": result.model_routed,   # what the router decided to use
            "cost_cents": result.cost_cents,       # may be None (not measured)
            "task_type": config.task_type,
            "retries": result.retries,
            "verified": result.quality_verified,
            "authority": config.authority,
        }
        if result.quality_checks:
            details_dict["checks"] = result.quality_checks
        if result.evaluation_detail:
            details_dict["evaluation_detail"] = result.evaluation_detail

        try:
            from aibrain.core.db_safety import session_id as _sid
            _session_id = _sid()
        except Exception:
            _session_id = None
        db.execute("""
            INSERT INTO evolution_outcomes
                (source, source_id, action, result, details, failure_reason, duration_seconds, session_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            f"harness:{config.task_type}",
            result.run_id,
            task,
            outcome,
            json.dumps(details_dict),
            failure_reason,
            result.duration_ms / 1000.0,
            _session_id,
        ])
        db.commit()
        db.close()

    except Exception as e:
        log.debug("Learning record failed: %s", e)


def _update_budget(
    config: HarnessConfig,
    cost_cents: Optional[int],
    cost_cents_equivalent: Optional[int] = None,
    model_used: Optional[str] = None,
    tokens_in: int = 0,
    tokens_out: int = 0,
):
    """Write a row to the costs table after each execution.

    Uses cost_cents when available (self-reported by the action), falls back to
    cost_cents_equivalent (auto-computed from _input_tokens/_output_tokens via
    llm_pricing). If both are None (e.g. deterministic code-only tasks with no
    token counts) the function is a no-op — we don't record $0 free runs here
    because execution_log already captures the full row.

    Fixes (2026-04-14):
    - Column 'notes' doesn't exist in the costs schema — was silently failing
      every single INSERT since the table was created. Replaced with 'error_msg'.
    - Expanded signature to accept cost_cents_equivalent so token-counted runs
      (where the action returns _input_tokens/_output_tokens but not _cost_cents)
      also land a row in the costs table.
    """
    effective_cost = cost_cents if cost_cents is not None else cost_cents_equivalent
    if effective_cost is None or effective_cost <= 0:
        # None = could not measure; 0 = explicitly free; nothing to record.
        return
    try:
        db_path = _find_db()
        if not db_path:
            return

        db = _db_open(db_path)
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""
            INSERT INTO costs (timestamp, model, category, tokens_in, tokens_out,
                             cost_usd, latency_ms, workflow_id, success, error_msg)
            VALUES (datetime('now'), ?, ?, ?, ?, ?, 0, ?, 1, ?)
        """, [
            model_used or config.task_type,
            "harness",
            tokens_in,
            tokens_out,
            effective_cost / 100.0,
            config.actor,
            f"task={config.tags[0] if config.tags else 'unknown'}",
        ])
        db.commit()
        db.close()
    except Exception as e:
        log.debug("Budget update failed: %s", e)


def _find_db() -> Optional[Path]:
    """Find the aibrain database — read-only semantic.

    Returns the canonical path only if the file already exists. Callers that
    just READ (budget check, authority check, approval query) use this so
    they can safely no-op on fresh installs without creating an empty DB.

    Writers should use _get_or_create_db() instead — that path creates the
    parent dir + empty file if missing, guaranteeing _log_audit, _record_learning,
    and _create_pending_approval can persist their rows on fresh installs.
    Previously _find_db was the only function and the existence check made
    those writers silently no-op (Bug #6, caught in sandboxed dogfood v2).
    """
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    return db_path if db_path.exists() else None


def _get_or_create_db() -> Path:
    """Return the canonical aibrain.db path, creating the file if missing.

    Used by writers (_log_audit, _record_learning, _create_pending_approval)
    that must persist rows even on a fresh install. Parent directory is
    created if needed. The sqlite3 CREATE TABLE IF NOT EXISTS statements in
    each writer handle schema on first touch.

    The canonical resolver in aibrain_db.AIBRAIN_ROOT remains the single
    source of truth for WHERE the DB lives — this function only guarantees
    the file EXISTS at that canonical location.
    """
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    if not db_path.exists():
        db_path.parent.mkdir(parents=True, exist_ok=True)
        # Touch the file so readers see it immediately. sqlite3.connect would
        # also create it, but touching first ensures a consistent state even
        # if the connect fails partway through schema creation.
        db_path.touch()
    return db_path


# ---------------------------------------------------------------------------
# Convenience Wrappers
# ---------------------------------------------------------------------------

def execute_deterministic(task: str, action: Callable, actor: str = "system",
                          tags: list = None) -> HarnessResult:
    """Execute a deterministic task (no LLM, code only)."""
    return execute(task, action, HarnessConfig(
        task_type="deterministic",
        authority="standard",
        max_cost_cents=0,
        timeout_seconds=60,
        quality_threshold=0.1,
        max_retries=0,
        actor=actor,
        tags=tags or [task],
    ))


def execute_simple(task: str, action: Callable, actor: str = "system",
                   tags: list = None) -> HarnessResult:
    """Execute a simple task (Haiku/local model)."""
    return execute(task, action, HarnessConfig(
        task_type="simple",
        authority="standard",
        max_cost_cents=10,
        timeout_seconds=120,
        quality_threshold=0.5,
        max_retries=1,
        actor=actor,
        tags=tags or [task],
    ))


def execute_judgment(task: str, action: Callable, actor: str = "system",
                     tags: list = None) -> HarnessResult:
    """Execute a judgment task (Sonnet)."""
    return execute(task, action, HarnessConfig(
        task_type="judgment",
        authority="elevated",
        max_cost_cents=100,
        timeout_seconds=300,
        quality_threshold=0.6,
        max_retries=1,
        actor=actor,
        tags=tags or [task],
    ))


def execute_complex(task: str, action: Callable, actor: str = "system",
                    tags: list = None) -> HarnessResult:
    """Execute a complex task (Opus)."""
    return execute(task, action, HarnessConfig(
        task_type="complex",
        authority="admin",
        max_cost_cents=1000,
        timeout_seconds=600,
        quality_threshold=0.7,
        max_retries=2,
        actor=actor,
        tags=tags or [task],
    ))


# ---------------------------------------------------------------------------
# Subagent Execution Bookends
# ---------------------------------------------------------------------------
# Agent() tool calls (Claude Code subagent spawns) cannot be wrapped by a
# Python function because the Agent tool is invoked externally by the
# orchestrator, not from within Python. However, the measurement system
# (execution_log, evolution_outcomes) still needs a row for every spawn.
#
# Solution: book-end functions.
#   start_subagent_execution()    — call BEFORE the Agent() spawn.
#                                   Creates the execution_log row in 'started' state.
#   complete_subagent_execution() — call AFTER Agent() returns.
#                                   Updates the row with output, quality, cost, model.
#   score_subagent_output()       — heuristic quality scorer (0.0–1.0) for agent output.
#                                   No LLM needed: checks length, structure, specificity.
#
# Caller pattern (in the orchestrator code before/after each Agent() call):
#
#     from aibrain.core.harness import (
#         start_subagent_execution,
#         complete_subagent_execution,
#         score_subagent_output,
#     )
#
#     exec_id = start_subagent_execution(
#         description="Audit the auth module for IDOR vulnerabilities",
#         task_type="judgment",
#         actor="neuro",
#         company_issue_id="abc123",   # optional — links to company task checkout
#     )
#
#     # <<< Agent() call happens here externally >>>
#     agent_output = "... agent returned output ..."
#
#     complete_subagent_execution(
#         execution_id=exec_id,
#         output_text=agent_output,
#         quality_score=score_subagent_output(agent_output, "Audit the auth module"),
#         cost_cents=None,   # None = could not measure (subscription-backed)
#         model_used=None,   # None = unknown — agent did not self-report
#     )
# ---------------------------------------------------------------------------

def start_subagent_execution(
    description: str,
    task_type: str = "judgment",
    actor: str = "neuro",
    company_issue_id: Optional[str] = None,
    tags: list = None,
) -> str:
    """
    Open an execution_log entry for a pending Agent() spawn.

    Call this BEFORE issuing the Agent() tool call. The row is written with
    success=0 and quality_score=NULL so partially-completed spawns (e.g. if
    the session dies between start and complete) are visible in the audit
    trail as 'started but not completed'.

    Args:
        description:      Short description of the subagent task (used as action).
        task_type:        "judgment" or "complex" for agent work (default: "judgment").
        actor:            Who spawned this agent (default: "neuro").
        company_issue_id: If a company task is checked out, pass its ID here to
                          link the execution_log row to the company_issues table.
        tags:             Optional list of metadata tags (e.g. ["security", "audit"]).

    Returns:
        execution_id (str): The audit_id for this row. Pass to
                            complete_subagent_execution() after Agent() returns.

    Example::

        exec_id = start_subagent_execution(
            "Audit auth module for IDOR", task_type="judgment", actor="neuro"
        )
        # ... Agent() call ...
        complete_subagent_execution(exec_id, result_text, score_subagent_output(result_text, "Audit auth module for IDOR"))
    """
    execution_id = secrets.token_urlsafe(8)
    run_id = secrets.token_urlsafe(8)

    try:
        db_path = _get_or_create_db()
        db = _db_open(db_path)
        db.execute("PRAGMA journal_mode=WAL")

        db.execute("""
            CREATE TABLE IF NOT EXISTS execution_log (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                detail TEXT,
                quality_score REAL,
                self_score REAL,
                divergence REAL,
                flagged INTEGER DEFAULT 0,
                model_used TEXT,
                cost_cents INTEGER,
                cost_cents_actual INTEGER,
                cost_cents_equivalent INTEGER,
                duration_ms INTEGER DEFAULT 0,
                before_state TEXT,
                after_state TEXT,
                success INTEGER DEFAULT 0,
                error TEXT,
                task_type TEXT,
                authority TEXT,
                retries INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Add missing columns for older DBs (idempotent)
        for ddl in (
            "ALTER TABLE execution_log ADD COLUMN cost_cents_actual INTEGER",
            "ALTER TABLE execution_log ADD COLUMN cost_cents_equivalent INTEGER",
            "ALTER TABLE execution_log ADD COLUMN text_id TEXT",
        ):
            try:
                db.execute(ddl)
            except sqlite3.OperationalError:
                pass

        entity_type_val = "company_issue" if company_issue_id else "subagent"
        entity_id_val = company_issue_id

        db.execute("""
            INSERT INTO execution_log
            (text_id, run_id, actor, action, entity_type, entity_id, detail,
             quality_score, model_used, cost_cents,
             duration_ms, success, task_type, authority, retries)
            VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL, 0, 0, ?, 'elevated', 0)
        """, [
            execution_id, run_id, actor,
            f"subagent.{description[:200]}",
            entity_type_val, entity_id_val,
            json.dumps({"tags": tags or [], "status": "started", "subagent": True}),
            task_type,
        ])
        db.commit()
        db.close()

    except Exception as e:
        log.warning("start_subagent_execution: failed to write row: %s", e)

    return execution_id


def complete_subagent_execution(
    execution_id: str,
    output_text: str,
    quality_score: Optional[float] = None,
    cost_cents: Optional[int] = None,
    model_used: Optional[str] = None,
) -> bool:
    """
    Close an execution_log entry created by start_subagent_execution().

    Call this AFTER the Agent() call returns. Updates the row with the agent's
    output, quality score, cost, and model. Marks success=1 if quality_score
    is not None and >= 0.3, otherwise success=0 (low-quality spawn).

    Args:
        execution_id:  The ID returned by start_subagent_execution().
        output_text:   The raw output returned by the Agent() call.
        quality_score: Float 0.0–1.0. Use score_subagent_output() for a
                       heuristic value. Pass None if cannot measure.
        cost_cents:    Integer cents actually spent. None = unmeasurable
                       (subscription-backed sessions). 0 = confirmed free.
        model_used:    Model ID string self-reported by the agent, or None.

    Returns:
        True if the row was updated successfully, False on DB error.

    Example::

        complete_subagent_execution(
            exec_id,
            output_text=agent_result,
            quality_score=score_subagent_output(agent_result, task_description),
            cost_cents=None,    # subscription-backed — cannot measure
            model_used=None,
        )
    """
    success_val = 1 if (quality_score is not None and quality_score >= 0.3) else 0
    output_preview = str(output_text)[:1000] if output_text else ""

    try:
        db_path = _find_db()
        if not db_path:
            log.warning("complete_subagent_execution: DB not found, cannot update row %s", execution_id)
            return False

        db = _db_open(db_path)
        db.execute("PRAGMA journal_mode=WAL")

        db.execute("""
            UPDATE execution_log
            SET quality_score = ?,
                model_used    = ?,
                cost_cents    = ?,
                success       = ?,
                after_state   = ?,
                detail        = json_patch(COALESCE(detail, '{}'), ?)
            WHERE text_id = ?
        """, [
            quality_score,
            model_used,
            cost_cents,
            success_val,
            json.dumps({"output_preview": output_preview}),
            json.dumps({"status": "completed"}),
            execution_id,
        ])
        db.commit()
        db.close()
        return True

    except Exception as e:
        log.warning("complete_subagent_execution: failed to update row %s: %s", execution_id, e)
        return False


def score_subagent_output(output_text: str, task_description: str = "") -> float:
    """
    Heuristic quality scorer for Agent() output (0.0–1.0). No LLM required.

    Scoring dimensions (each contributes up to its stated weight):
      - Length adequacy   (0.30): word count vs task complexity
      - Structure signals (0.25): presence of headers, lists, code blocks, numbered steps
      - Specificity       (0.25): concrete nouns, file paths, function names, numbers
      - Task relevance    (0.20): keyword overlap between output and task_description

    The rubric errs toward 0.5 for ambiguous cases. It does NOT penalise
    outputs that are intentionally short (e.g. a one-line "File not found"
    when the task was to check file existence). Min score floor is 0.1 for
    any non-empty output; empty output scores 0.0.

    Args:
        output_text:      Raw text returned by the Agent() call.
        task_description: The task description passed to start_subagent_execution.
                          Used for keyword overlap scoring. Can be empty.

    Returns:
        float in [0.0, 1.0].

    Example::

        score = score_subagent_output(
            "Found 3 IDOR issues in /api/users endpoint. See lines 42, 87, 201.",
            "Audit the auth module for IDOR vulnerabilities",
        )
        # → ~0.72
    """
    if not output_text or not output_text.strip():
        return 0.0

    text = output_text.strip()
    words = text.split()
    word_count = len(words)

    # ── Dimension 1: Length adequacy (0.30) ──────────────────────────────
    # Calibration: <50 words = sparse, 50–200 = adequate, 200–600 = rich,
    # 600+ gives no extra credit (avoids rewarding padding).
    if word_count < 10:
        length_score = 0.1
    elif word_count < 50:
        length_score = 0.3 + (word_count - 10) / 40 * 0.3   # 0.30–0.60
    elif word_count < 200:
        length_score = 0.6 + (word_count - 50) / 150 * 0.3  # 0.60–0.90
    else:
        length_score = min(1.0, 0.9 + (word_count - 200) / 800 * 0.1)  # 0.90–1.0

    # ── Dimension 2: Structure signals (0.25) ────────────────────────────
    structure_hits = 0
    structure_checks = [
        r'^\s*#{1,3}\s',            # Markdown headers
        r'^\s*[-*+]\s',             # Bullet lists
        r'^\s*\d+[.)]\s',           # Numbered lists
        r'```',                     # Code fences
        r'^\s*\|.*\|',              # Tables
        r'\*\*[^*]+\*\*',           # Bold emphasis
        r'^\s*(DONE|RESULT|SUMMARY|FINDING|ERROR|WARNING|NOTE|STATUS)[\s:]',  # Section labels
    ]
    for pattern in structure_checks:
        if re.search(pattern, text, re.MULTILINE | re.IGNORECASE):
            structure_hits += 1
    structure_score = min(1.0, structure_hits / 3.0)  # saturates at 3+ signals

    # ── Dimension 3: Specificity (0.25) ──────────────────────────────────
    specificity_hits = 0
    specificity_checks = [
        r'[/\\][\w./\\-]+\.\w+',   # File paths
        r'\b\d{1,5}\b',            # Numbers (line numbers, counts, versions)
        r'\b(def |class |import |from |function |async )',  # Code identifiers
        r'\b[A-Z][a-z]+[A-Z]\w+',  # CamelCase (class names, method names)
        r'\b(https?://|git@)\S+',  # URLs / git refs
        r'\b(error|exception|traceback|stack trace)\b',  # Error specifics
        r'`[^`]+`',                # Inline code
    ]
    for pattern in specificity_checks:
        if re.search(pattern, text, re.IGNORECASE):
            specificity_hits += 1
    specificity_score = min(1.0, specificity_hits / 3.0)  # saturates at 3+

    # ── Dimension 4: Task relevance (0.20) ───────────────────────────────
    if task_description.strip():
        task_words = set(
            w.lower().strip('.,;:?!()[]{}"\'-')
            for w in task_description.split()
            if len(w) > 3  # skip stop-word length tokens
        )
        output_words_lower = set(w.lower().strip('.,;:?!()[]{}"\'-') for w in words)
        if task_words:
            overlap = len(task_words & output_words_lower) / len(task_words)
            relevance_score = min(1.0, overlap * 2.0)  # 50% overlap → 1.0
        else:
            relevance_score = 0.5
    else:
        relevance_score = 0.5  # no task description — neutral

    # ── Composite score (weighted sum) ───────────────────────────────────
    score = (
        length_score      * 0.30
        + structure_score * 0.25
        + specificity_score * 0.25
        + relevance_score * 0.20
    )

    # Floor: any non-empty output gets at least 0.10
    return max(0.10, round(score, 3))


# ---------------------------------------------------------------------------
# Vault-Grounded Response Protocol
# ---------------------------------------------------------------------------
# CISO Second Brain methodology (Stephen Bennett, 30yr CISO):
#   "Search the vault before answering. Reference specific files when making
#    claims. Never fabricate information about my organisation."
#   Falsifiability check: "When the AI gives you an answer about your work,
#    ask it which file it found that in. If it can't cite one, treat it with
#    scepticism."
#
# This protocol fires as a pre-response hook whenever a query is classified
# as being about the user's own project state. It grounds the answer in the
# vault (AIBrain memory DB) and tags every used memory with its ID so users
# can verify exactly which memory backed each claim.
#
# Design notes:
#   - Pure additive - no existing code paths change.
#   - Memory search is best-effort: failures produce an honest "no results"
#     prefix rather than blocking the response.
#   - Citation format: [vault:MEM-<id>] inline so LLM downstream can parse it.
# ---------------------------------------------------------------------------

import re as _re

# Patterns that signal the query is about the user's own project, data, or decisions.
_VAULT_TRIGGER_PATTERNS: list[str] = [
    r'\b(my|our|we|the)\s+(project|codebase|code|data|files?|decisions?|notes?|memories?|docs?|tasks?|issues?)\b',
    r'\bwhat\s+(did|have|do)\s+(I|we|you)\b',
    r'\bwhen\s+(did|was|were)\b',
    r'\bwhy\s+(did|was|were)\b',
    r'\bwhich\s+(file|document|memory|note|task|issue|decision)\b',
    r'\bhave\s+(I|we)\s+(decided|discussed|added|removed|built|shipped|deployed|fixed|broken)\b',
    r'\bwhat\s+(is|are)\s+(the\s+)?(current|latest|last)\b',
    r'\bdid\s+(I|we)\s+(decide|discuss|add|remove|build|ship|deploy|fix|break)\b',
]


def is_project_state_query(query: str) -> bool:
    """Return True if the query is about the user's own project state.

    Used by the vault-grounded response protocol to decide whether to fire
    a pre-response memory_search before generating an answer.

    Checks against a list of trigger patterns that signal first-person or
    project-scoped intent. All checks are case-insensitive.

    Args:
        query: The raw user query string.

    Returns:
        True if any trigger pattern matches; False otherwise.

    Examples:
        >>> is_project_state_query("what did I decide about the database?")
        True
        >>> is_project_state_query("what is the capital of France?")
        False
    """
    if not query or not isinstance(query, str):
        return False
    return any(
        _re.search(pattern, query, _re.IGNORECASE)
        for pattern in _VAULT_TRIGGER_PATTERNS
    )


def classify_vault_trigger(query: str) -> bool:
    """Return True if the query should trigger vault grounding.

    Combines two signals with OR semantics (strictly broader than either alone):
    1. classify_query() returning non-'factual' (temporal, preference, ss_user, etc.)
    2. is_project_state_query() regex match for first-person / project-scoped queries

    Falls back to is_project_state_query() only if aibrain_db is unavailable.
    """
    if not query or not isinstance(query, str):
        return False
    try:
        import aibrain_db as _aibrain_db
        if _aibrain_db.classify_query(query) != "factual":
            return True
    except Exception:
        pass
    return is_project_state_query(query)


def vault_search(query: str, top_k: int = 5, query_type: str | None = None) -> list[dict]:
    """Search AIBrain memory for vault-grounding context.

    This is the backing store call for the vault-grounded response protocol.
    Uses the canonical aibrain_db.search_memories() pipeline (SelRoute fusion,
    FTS5, vector, salience scoring).

    Args:
        query: The user query to search against stored memories.
        top_k: Maximum number of memories to return (default 5).

    Returns:
        List of memory dicts, each containing at minimum:
            id (int), content (str), score (float), type (str), tags (str).
        Returns an empty list on any search error (best-effort semantics).
    """
    import logging as _logging
    _log = _logging.getLogger("aibrain.harness")
    try:
        import aibrain_db
        results = aibrain_db.search_memories(query, limit=top_k, search_type=query_type)
        return results if results else []
    except Exception as e:
        _log.debug("vault_search: memory search failed (best-effort, continuing): %s", e)
        return []


def format_vault_context(memories: list[dict]) -> str:
    """Format a list of memory dicts into a grounding context block.

    Each memory is prefixed with its vault citation tag [vault:MEM-<id>] so
    downstream LLM prompts and response parsers can link claims back to
    specific memory IDs for user verification.

    Args:
        memories: Output from vault_search() - list of memory dicts.

    Returns:
        A multi-line string ready to inject as context into an LLM prompt,
        or an empty string when memories is empty.
    """
    if not memories:
        return ""
    lines = []
    for mem in memories:
        mem_id = mem.get("id", "?")
        content = mem.get("content", mem.get("memory", "")).strip()
        mem_type = mem.get("type", "")
        score_raw = mem.get("score", mem.get("score_breakdown", {}).get("combined", None))
        score_str = f" score={score_raw:.3f}" if isinstance(score_raw, (int, float)) else ""
        type_str = f" [{mem_type}]" if mem_type else ""
        lines.append(f"[vault:MEM-{mem_id}]{type_str}{score_str}: {content}")
    return "\n".join(lines)


def build_vault_grounded_prefix(query: str, top_k: int = 5) -> str:
    """Run vault search and build the prefix string for a grounded response.

    This is the top-level entry point for the vault-grounded response protocol.
    Call this before generating any response to a project-state query. Inject
    the returned prefix at the top of the LLM system prompt or response preamble.

    Flow:
        1. is_project_state_query(query) -> if False, skip vault search
        2. vault_search(query, top_k)    -> fetch relevant memories
        3. format_vault_context(memories) -> citation-tagged context block
        4. Return prefix string with count + context for LLM injection

    Args:
        query: The user query.
        top_k: Number of memories to pull (default 5).

    Returns:
        A prefix string. Two forms:
            "[Vault-grounded: found N relevant memories]\\n\\n<context block>\\n\\n"
            "[Vault search: no relevant memories found - answering from general knowledge]\\n\\n"

    Example usage in a query handler::

        if is_project_state_query(user_query):
            prefix = build_vault_grounded_prefix(user_query)
            prompt = prefix + user_query
        else:
            prompt = user_query
        response = llm.complete(prompt)
    """
    try:
        import aibrain_db as _aibrain_db
        _qtype = _aibrain_db.classify_query(query)
    except Exception:
        _qtype = None
    memories = vault_search(query, top_k=top_k, query_type=_qtype)
    if memories:
        context = format_vault_context(memories)
        return (
            f"[Vault-grounded: found {len(memories)} relevant memories]\n\n"
            f"{context}\n\n"
        )
    return "[Vault search: no relevant memories found - answering from general knowledge]\n\n"


# ---------------------------------------------------------------------------
# Cost Tracking Health Report
# ---------------------------------------------------------------------------

def harness_cost_report(limit: int = 100) -> dict:
    """Return cost tracking health stats from execution_log.

    Queries the execution_log table and returns counts/percentages for each
    cost_cents bucket so Decker can see at a glance how honest the cost signal
    is across all harness runs.

    Sentinel semantics for cost_cents:
        > 0  : real measured cost in cents
        = 0  : explicitly free (deterministic / local model confirmed $0)
        = -1 : ran but couldn't measure (non-deterministic, no token envelope)
        NULL : legacy rows written before the -1 sentinel was introduced
               (these pre-date the Apr 2026 honest-rubric audit)

    Args:
        limit: Not used for query capping (we always count all rows) but
               kept as a parameter for future use (e.g. time-window limiting).

    Returns:
        dict with keys:
            total          (int)   — total rows in execution_log
            cost_real      (int)   — rows with cost_cents > 0  (measured spend)
            cost_sentinel  (int)   — rows with cost_cents = -1 (unmeasured)
            cost_free      (int)   — rows with cost_cents = 0  (confirmed free)
            cost_null      (int)   — rows with cost_cents IS NULL (legacy/missing)
            pct_real       (float) — % of total that have a real cost signal
            pct_sentinel   (float) — % of total flagged as unmeasured
            pct_free       (float) — % of total confirmed free
            pct_null       (float) — % of total with NULL (legacy rows)
            health         (str)   — "good" / "degraded" / "poor" summary
            db_path        (str)   — which DB was queried
    """
    result: dict = {
        "total": 0,
        "cost_real": 0,
        "cost_sentinel": 0,
        "cost_free": 0,
        "cost_null": 0,
        "pct_real": 0.0,
        "pct_sentinel": 0.0,
        "pct_free": 0.0,
        "pct_null": 0.0,
        "health": "unknown",
        "db_path": "",
    }

    db_path = _find_db()
    if not db_path:
        result["health"] = "no_db"
        return result

    result["db_path"] = str(db_path)

    try:
        db = _db_open(db_path)
        db.row_factory = sqlite3.Row

        row = db.execute("""
            SELECT
                COUNT(*)                                    AS total,
                SUM(CASE WHEN cost_cents > 0  THEN 1 ELSE 0 END) AS cost_real,
                SUM(CASE WHEN cost_cents = -1 THEN 1 ELSE 0 END) AS cost_sentinel,
                SUM(CASE WHEN cost_cents = 0  THEN 1 ELSE 0 END) AS cost_free,
                SUM(CASE WHEN cost_cents IS NULL THEN 1 ELSE 0 END) AS cost_null
            FROM execution_log
        """).fetchone()

        db.close()

        if row and row["total"]:
            total = row["total"]
            cost_real      = row["cost_real"]      or 0
            cost_sentinel  = row["cost_sentinel"]  or 0
            cost_free      = row["cost_free"]      or 0
            cost_null      = row["cost_null"]      or 0

            result["total"]         = total
            result["cost_real"]     = cost_real
            result["cost_sentinel"] = cost_sentinel
            result["cost_free"]     = cost_free
            result["cost_null"]     = cost_null

            def _pct(n: int) -> float:
                return round(n / total * 100, 1) if total else 0.0

            result["pct_real"]      = _pct(cost_real)
            result["pct_sentinel"]  = _pct(cost_sentinel)
            result["pct_free"]      = _pct(cost_free)
            result["pct_null"]      = _pct(cost_null)

            # Health summary:
            #   good     — ≥10% of rows have real cost OR total rows is very small (<50)
            #   degraded — 1-9% real, mostly sentinel/null
            #   poor     — <1% real, nearly all unmeasured
            if total < 50 or result["pct_real"] >= 10.0:
                result["health"] = "good"
            elif result["pct_real"] >= 1.0:
                result["health"] = "degraded"
            else:
                result["health"] = "poor"

    except Exception as e:
        result["health"] = f"error: {e}"
        log.warning("harness_cost_report: query failed: %s", e)

    return result
