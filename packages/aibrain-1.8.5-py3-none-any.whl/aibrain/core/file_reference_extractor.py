"""
file_reference_extractor.py — Extract and index file path references from memories.

When a memory is stored, extracts file paths from the content and creates
file_references entries. Provides topic-based and semantic file search.

Part of the Memory Lifecycle v1.6 feature (Phase 6).
"""

from __future__ import annotations

import logging
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger("aibrain.file_reference_extractor")

_PATH_PATTERNS = [
    re.compile(r'/[cC]/Users/\S+\.(?:py|md|json|yaml|toml|sql|txt|cfg|ini|db)\b'),  # Unix-style Windows paths with extension
    re.compile(r'[A-Z]:\\(?:Users|projects|decker_system)\\\S+\.(?:py|md|json|yaml|toml|sql|txt)\b'),  # Windows paths
    re.compile(r'(?<!\w)projects/\S+\.(?:py|md|json|yaml|toml|sql|txt)\b'),  # Relative project paths
    re.compile(r'(?<!\w)aibrain/\S+\.py\b'),                         # aibrain module paths
    re.compile(r'(?<!\w)wintermute[_-]v2/\S+\.py\b'),                # wintermute module paths
    re.compile(r'(?<!\w)decker_system/\S+\.(?:py|md|json|yaml|toml|sql|txt|cfg)\b'),  # decker_system paths with extension
    re.compile(r'(?<!\w)decker_system/\d{2}_\w+/[\w/]+(?=[\s,;)\]"\']|$)'),  # decker_system dir paths
]


def extract_file_references(content: str, memory_id: int, topic: str = "") -> list[dict]:
    """Extract file path references from memory content.

    Returns list of dicts ready for INSERT into file_references.
    """
    if not content:
        return []

    refs = []
    seen_paths = set()

    for pattern in _PATH_PATTERNS:
        for match in pattern.finditer(content):
            path = match.group(0).rstrip('.,;:')
            normalized = path.replace('\\', '/')
            if normalized in seen_paths:
                continue
            seen_paths.add(normalized)

            path_type = _classify_path_type(normalized)
            refs.append({
                "memory_id": memory_id,
                "file_path": normalized,
                "path_type": path_type,
                "topic": topic or _infer_topic(normalized),
                "context": "",
            })

    return refs


def store_file_references(db: sqlite3.Connection, refs: list[dict]) -> int:
    """Insert file references into file_references table.

    Avoids duplicates by checking for existing (memory_id, file_path) pairs.
    Returns count of refs inserted.
    """
    count = 0
    for ref in refs:
        try:
            existing = db.execute(
                "SELECT 1 FROM file_references WHERE memory_id = ? AND file_path = ?",
                (ref["memory_id"], ref["file_path"])
            ).fetchone()
            if existing:
                continue
            db.execute(
                "INSERT INTO file_references (memory_id, file_path, path_type, topic, context) "
                "VALUES (?, ?, ?, ?, ?)",
                (ref["memory_id"], ref["file_path"], ref["path_type"],
                 ref["topic"], ref.get("context", ""))
            )
            count += 1
        except Exception as e:
            log.debug("Failed to store file reference: %s", e)
    if count:
        db.commit()
    return count


def get_files_for_topic(
    topic: str,
    db: sqlite3.Connection,
    include_stale: bool = False,
) -> list[dict]:
    """Return all file references for a topic.

    Results sorted by path_type (source first), then by last_verified DESC.
    Optionally excludes stale references (files that were missing at last check).
    """
    sql = """
        SELECT fr.*, m.name as memory_name, m.content as memory_snippet
        FROM file_references fr
        LEFT JOIN memories m ON fr.memory_id = m.id
        WHERE fr.topic = ?
    """
    if not include_stale:
        sql += " AND fr.last_verified_exists = 1"
    sql += " ORDER BY fr.path_type, fr.last_verified DESC"

    return [dict(r) for r in db.execute(sql, (topic,)).fetchall()]


def search_files_by_query(query: str, db: sqlite3.Connection) -> list[dict]:
    """Semantic file search — find files relevant to a natural language query.

    Strategy:
    1. Search memories for query (existing embedding search)
    2. Collect file_references linked to matching memories
    3. Deduplicate by file_path, rank by memory relevance score
    """
    try:
        import aibrain_db
        memories = aibrain_db.search_memories(query, limit=20)
    except Exception as e:
        log.debug("Memory search for file refs failed: %s", e)
        return []

    memory_ids = [m["id"] for m in memories if m.get("id")]

    if not memory_ids:
        return []

    placeholders = ",".join("?" * len(memory_ids))
    sql = f"""
        SELECT DISTINCT fr.file_path, fr.path_type, fr.topic, fr.context,
               fr.last_verified_exists, m.name as memory_name
        FROM file_references fr
        JOIN memories m ON fr.memory_id = m.id
        WHERE fr.memory_id IN ({placeholders})
          AND fr.last_verified_exists = 1
        ORDER BY fr.path_type, fr.last_verified DESC
    """

    return [dict(r) for r in db.execute(sql, memory_ids).fetchall()]


def verify_file_references(db: sqlite3.Connection, batch_size: int = 200) -> dict:
    """Check all file references for existence. Update last_verified and last_verified_exists.

    Returns summary: {"checked": N, "valid": N, "stale": N}
    """
    rows = db.execute(
        "SELECT id, file_path FROM file_references ORDER BY last_verified ASC LIMIT ?",
        (batch_size,)
    ).fetchall()

    stats = {"checked": 0, "valid": 0, "stale": 0}
    now = datetime.now(timezone.utc).isoformat()

    for row in rows:
        fid, fpath = row[0], row[1]
        # Normalize path for OS
        check_path = Path(fpath.replace("/c/", "C:/").replace("/", "\\"))
        exists = check_path.exists()

        db.execute(
            "UPDATE file_references SET last_verified = ?, last_verified_exists = ? WHERE id = ?",
            (now, 1 if exists else 0, fid)
        )
        stats["checked"] += 1
        stats["valid" if exists else "stale"] += 1

    db.commit()
    return stats


def _classify_path_type(path: str) -> str:
    """Classify a file path into a type category."""
    if '/tests/' in path or '/test_' in path:
        return 'test'
    if path.endswith(('.md', '.rst', '.txt')):
        return 'doc'
    if path.endswith(('.json', '.yaml', '.toml', '.ini', '.cfg')):
        return 'config'
    if path.endswith(('.db', '.sqlite', '.csv')):
        return 'data'
    if '/specs/' in path or '/reports/' in path or '/expert_review' in path:
        return 'output'
    return 'source'


def _infer_topic(path: str) -> str:
    """Infer topic from path segments."""
    path_lower = path.lower()
    if 'wintermute' in path_lower:
        return 'wintermute'
    if 'aibrain' in path_lower:
        return 'aibrain'
    if 'permeate' in path_lower:
        return 'permeate'
    if 'remediate' in path_lower:
        return 'remediate'
    if 'sentience' in path_lower or 'movie' in path_lower:
        return 'sentience'
    if 'simon' in path_lower or 'beard' in path_lower:
        return 'simon_beard'
    if 'selroute' in path_lower:
        return 'selroute'
    if 'decker_system' in path_lower:
        return 'decker_system'
    return 'general'
