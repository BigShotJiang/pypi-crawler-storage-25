"""
git_worktree.py — Isolated git worktrees for parallel agent tasks.

Each agent that touches code should work in its own worktree so concurrent
edits never conflict. The worktree is auto-cleaned when the context manager
exits (or when cleanup() is called).

Usage:
    from aibrain.core.git_worktree import WorktreeSession

    with WorktreeSession(repo_path="/path/to/repo", task_id="task-abc") as wt:
        # wt.path — isolated checkout, safe to edit
        do_work(wt.path)
        if wt.has_changes():
            wt.commit("feat: implement X")
            # merge back is the caller's responsibility

Or without context manager:
    wt = WorktreeSession(repo_path=".", task_id="agent-123")
    path = wt.setup()
    # ... do work ...
    wt.cleanup()
"""

import logging
import platform
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

log = logging.getLogger("aibrain.git_worktree")


def _native_path(p: Path | str) -> str:
    """Return an OS-native path string safe for subprocess cwd on Windows.

    On Windows, /c/Users/... (bash-style) is not a valid Win32 path.
    We detect the C: drive prefix and convert accordingly.
    """
    s = str(p)
    if platform.system() == "Windows":
        # Bash-style /c/... → C:/...
        import re
        s = re.sub(r"^/([a-zA-Z])/", lambda m: m.group(1).upper() + ":/", s)
        s = s.replace("/", "\\")
    return s


class WorktreeError(Exception):
    pass


class WorktreeSession:
    """
    A git worktree scoped to one agent task.

    The worktree is created on a new branch (agent/<task_id>) and deleted
    when cleanup() is called or the context manager exits.
    """

    def __init__(
        self,
        repo_path: str | Path | None = None,
        task_id: str | None = None,
        branch_prefix: str = "agent",
        worktree_base: str | Path | None = None,
    ):
        """
        Args:
            repo_path:      Path to the git repo. Defaults to current directory.
            task_id:        Unique identifier for this task. Auto-generated if None.
            branch_prefix:  Branch names are <prefix>/<task_id>.
            worktree_base:  Where to create the worktree dir. Defaults to system temp.
        """
        self.repo_path = Path(repo_path or ".").resolve()
        self.task_id = task_id or uuid.uuid4().hex[:12]  # noqa:UUID4-SECURITY-TOKEN — worktree ID, not a secret
        self.branch = f"{branch_prefix}/{self.task_id}"
        self.worktree_base = Path(worktree_base) if worktree_base else Path(tempfile.gettempdir())
        self.path: Path | None = None
        self._setup_done = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def setup(self) -> Path:
        """Create the worktree. Returns the worktree path."""
        if self._setup_done:
            return self.path

        wt_path = self.worktree_base / f"aibrain_wt_{self.task_id}"
        wt_path.mkdir(parents=True, exist_ok=True)

        native_wt = _native_path(wt_path)
        try:
            self._run(["git", "worktree", "add", "-b", self.branch, native_wt])
        except WorktreeError:
            # Branch may exist from a prior interrupted run — try without -b
            try:
                self._run(["git", "worktree", "add", native_wt, self.branch])
            except WorktreeError as e:
                shutil.rmtree(wt_path, ignore_errors=True)
                raise WorktreeError(f"Failed to create worktree at {wt_path}: {e}") from e

        self.path = wt_path
        self._setup_done = True
        log.info("Worktree created: %s (branch: %s)", self.path, self.branch)
        return self.path

    def cleanup(self, remove_branch: bool = True) -> None:
        """Remove the worktree and optionally delete the branch."""
        if not self._setup_done or self.path is None:
            return

        try:
            self._run(["git", "worktree", "remove", "--force", _native_path(self.path)])
        except WorktreeError as e:
            log.warning("worktree remove failed: %s — forcing rmtree", e)
            shutil.rmtree(self.path, ignore_errors=True)
            try:
                self._run(["git", "worktree", "prune"])
            except WorktreeError:
                pass

        if remove_branch:
            try:
                self._run(["git", "branch", "-D", self.branch])
            except WorktreeError:
                pass  # Branch may not exist if never committed

        self._setup_done = False
        log.info("Worktree cleaned up: %s", self.path)
        self.path = None

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def has_changes(self) -> bool:
        """True if the worktree has uncommitted changes."""
        if not self.path:
            return False
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=self.path, capture_output=True, text=True
        )
        return bool(result.stdout.strip())

    def diff_summary(self) -> str:
        """Return a compact diff summary (changed files only)."""
        if not self.path:
            return ""
        result = subprocess.run(
            ["git", "diff", "--stat", "HEAD"],
            cwd=self.path, capture_output=True, text=True
        )
        return result.stdout.strip()

    def commit(self, message: str, add_all: bool = True) -> str | None:
        """Stage all changes and commit. Returns the new commit hash, or None."""
        if not self.path:
            raise WorktreeError("Worktree not set up")
        if add_all:
            self._run(["git", "add", "-A"], cwd=self.path)
        if not self.has_changes() and not self._has_staged():
            log.info("Nothing to commit in worktree %s", self.path)
            return None
        self._run(["git", "commit", "-m", message], cwd=self.path)
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=self.path, capture_output=True, text=True
        )
        return result.stdout.strip()

    def merge_into(self, target_branch: str = "main", strategy: str = "merge") -> None:
        """
        Merge or rebase this worktree's branch into target_branch.
        Runs in the main repo, not the worktree.
        """
        if strategy == "rebase":
            self._run(["git", "rebase", self.branch, target_branch])
        else:
            current = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=self.repo_path, capture_output=True, text=True
            ).stdout.strip()
            if current != target_branch:
                self._run(["git", "checkout", target_branch])
            self._run(["git", "merge", "--no-ff", self.branch, "-m",
                       f"Merge agent worktree {self.task_id}"])

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "WorktreeSession":
        self.setup()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        # Always clean up, even on exception
        try:
            self.cleanup()
        except Exception as e:
            log.warning("Cleanup error: %s", e)
        return False  # don't suppress exceptions

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _run(self, cmd: list[str], cwd: Path | None = None) -> str:
        """Run a git command. Raises WorktreeError on failure."""
        effective_cwd = _native_path(cwd or self.repo_path)
        result = subprocess.run(
            cmd,
            cwd=effective_cwd,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise WorktreeError(result.stderr.strip() or result.stdout.strip())
        return result.stdout.strip()

    def _has_staged(self) -> bool:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            cwd=self.path, capture_output=True, text=True
        )
        return bool(result.stdout.strip())


def list_agent_worktrees(repo_path: str | Path | None = None) -> list[dict]:
    """Return all active agent/* worktrees for a repo."""
    repo = Path(repo_path or ".").resolve()
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        cwd=repo, capture_output=True, text=True
    )
    worktrees = []
    current = {}
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            if current:
                worktrees.append(current)
            current = {"path": line.split(" ", 1)[1]}
        elif line.startswith("HEAD "):
            current["head"] = line.split(" ", 1)[1]
        elif line.startswith("branch "):
            current["branch"] = line.split(" ", 1)[1]
        elif line == "bare":
            current["bare"] = True
    if current:
        worktrees.append(current)

    return [w for w in worktrees if "agent/" in w.get("branch", "")]
