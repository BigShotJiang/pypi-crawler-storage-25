"""aibrain.core.skill_compiler — SkillCompiler: captures, deduplicates, and indexes skills.

Skills are stored at ~/.aibrain/skills.json — a plain JSON list any agent can read.
Failure captures (success_score=0.0) are as valuable as successes: they tell future
agents what NOT to try for a given goal shape.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sqlite3
import shutil
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from aibrain.core.artifact_store import ArtifactStore

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level lazy singleton — used by capture_safe classmethod
# ---------------------------------------------------------------------------
_SINGLETON: Optional["SkillCompiler"] = None


def _get_singleton() -> "SkillCompiler":
    """Lazy-init the singleton SkillCompiler. Safe to call from any thread."""
    global _SINGLETON
    if _SINGLETON is None:
        _SINGLETON = SkillCompiler()
    return _SINGLETON


# Tools that indicate meaningful work was done (not just read/search)
_CREATIVE_TOOLS = frozenset({
    "edit_file", "write_file", "apply_dispatch_blocks",
    "create_task", "dispatch_deepseek_task", "spawn_subagent",
    "batch_run", "notebook_edit", "complete_task",
})

# File path patterns for extraction from tool results
_PATH_PATTERNS = (
    # Windows absolute: C:\Users\... or \\?\...
    re.compile(r'(?:[A-Za-z]:\\|\\\\\?\\|~?[/\\])[\w.~\-\\/]+\.\w{1,10}'),
    # Unix absolute: /home/.../file.py
    re.compile(r'/[\w.~\-/]+\.\w{1,10}'),
    # Relative with extension: src/engine/building.py
    re.compile(r'(?:^|[^\w])([\w.\-]+/)+[\w.\-]+\.\w{1,10}'),
)

_DEFAULT_SKILLS_PATH = Path.home() / ".aibrain" / "skills.json"
_DEDUP_THRESHOLD = 0.85
_BACKUP_COUNT = 20

# Noise filter thresholds
_MIN_SCORE = 0.15           # Reject only truly worthless (0.0) or near-worthless skills.
                            # Failure captures (0.1-0.3) are as valuable as successes —
                            # they tell future agents what NOT to try.
_NOISE_NAME_PREFIXES = ("lucy_chat_", "conversation_")  # Reject chat-dump names
_NOISE_ARTIFACT_PATHS = ("lucy/conversations",)  # Reject chat-dump artifact paths
_MIN_DESCRIPTION_LENGTH = 30  # Reject trivially short descriptions
_CHAT_SIGNATURE_PATTERNS = (
    re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}"),  # ISO timestamp
    re.compile(r"^(User|Lucy|Human|Assistant|System):", re.IGNORECASE),  # Chat prefix
    re.compile(r"^Q:\s"),  # Q&A pattern
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _tokenize(text: str) -> set:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def _keyword_similarity(a: str, b: str) -> float:
    ta, tb = _tokenize(a), _tokenize(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def _has_structure(description: str) -> bool:
    """Return True if description looks like a skill, not raw chat."""
    if not description:
        return False
    # Numbered step: "1. foo" or "1) foo"
    if re.search(r"\d+[\.\)]\s+\w", description):
        return True
    # Bullet: "- foo" or "* foo"
    if re.search(r"[-*]\s+\w", description):
        return True
    # Multi-paragraph with substantive content
    if len(description) > 200 and description.count("\n") >= 2:
        return True
    # Single-paragraph technical description: >50 chars, no chat signatures.
    # This catches real skills like "Fixed game loop catch block that..."
    # that were previously rejected because they had no bullets/numbers.
    if len(description) > 50:
        for pat in _CHAT_SIGNATURE_PATTERNS:
            if pat.search(description):
                return False
        return True
    return False


def _should_accept(name: str, description: str, artifact_path: str,
                   success_score: float) -> tuple[bool, str]:
    """Reject noise entries before they pollute the skill store.

    Returns (accepted, reason) where reason is empty on acceptance.
    """
    # 1. Score threshold
    if success_score < _MIN_SCORE:
        return False, f"score {success_score:.2f} < {_MIN_SCORE}"

    # 2. Name blacklist — chat dump prefixes
    for prefix in _NOISE_NAME_PREFIXES:
        if name.startswith(prefix):
            return False, f"name starts with noise prefix '{prefix}'"

    # 3. Artifact path blacklist
    for prefix in _NOISE_ARTIFACT_PATHS:
        if artifact_path.startswith(prefix):
            return False, f"artifact_path starts with noise prefix '{prefix}'"

    # 4. Structure check — must be a skill, not raw chat
    if not _has_structure(description):
        return False, "description lacks numbered/bulleted structure"

    # 5. Description length — only a floor for structured entries
    #    (no-structure already rejected above; 12 chars catches "1.a 2.b" noise)
    if len(description) < 12:
        return False, f"description too short ({len(description)} < 12)"

    return True, ""


@dataclass
class Skill:
    name: str
    description: str
    artifact_path: str
    success_score: float
    task_shape: str
    created_at: str
    use_count: int = 0
    failure_count: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Skill":
        return cls(
            name=d["name"],
            description=d.get("description", ""),
            artifact_path=d.get("artifact_path", ""),
            success_score=float(d.get("success_score", 0.0)),
            task_shape=d.get("task_shape", ""),
            created_at=d.get("created_at", _now()),
            use_count=int(d.get("use_count", 0)),
            failure_count=int(d.get("failure_count", 0)),
        )


class SkillCompiler:
    """Captures, deduplicates, and indexes skills created during Odin loop execution."""

    def __init__(self, artifact_store=None, skills_path=None):
        self._skills_path = Path(skills_path) if skills_path else _DEFAULT_SKILLS_PATH
        self._skills_path.parent.mkdir(parents=True, exist_ok=True)
        self._artifact_store = artifact_store
        if self._artifact_store is None:
            try:
                from aibrain.core.artifact_store import ArtifactStore
                self._artifact_store = ArtifactStore()
            except Exception as exc:
                log.warning("SkillCompiler: could not init ArtifactStore: %s", exc)
        self._db_path = self._skills_path.parent / "aibrain.db"
        self._backup_dir = self._skills_path.parent / "skill_backups"

    def _ensure_audit_table(self, conn):
        conn.execute("""
            CREATE TABLE IF NOT EXISTS skill_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                action TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                artifact_path TEXT,
                success_score REAL,
                task_shape TEXT,
                use_count INTEGER,
                failure_count INTEGER,
                trigger TEXT,
                full_state_json TEXT
            )
        """)

    def _audit_write(self, skill: Skill, action: str, trigger: str):
        try:
            conn = sqlite3.connect(str(self._db_path))
            try:
                self._ensure_audit_table(conn)
                conn.execute("""
                    INSERT INTO skill_audit
                        (ts, action, name, description, artifact_path,
                         success_score, task_shape, use_count, failure_count,
                         trigger, full_state_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    _now(),
                    action,
                    skill.name,
                    skill.description,
                    skill.artifact_path,
                    skill.success_score,
                    skill.task_shape,
                    skill.use_count,
                    skill.failure_count,
                    trigger,
                    json.dumps(skill.to_dict(), ensure_ascii=False),
                ))
                conn.commit()
            finally:
                conn.close()
        except Exception as exc:
            log.warning("SkillCompiler: audit write failed (non-fatal): %s", exc)

    def _backup_skills(self, payload: str):
        try:
            self._backup_dir.mkdir(parents=True, exist_ok=True)
            ts = int(time.time())
            backup_path = self._backup_dir / f"skills.{ts}.json"
            backup_path.write_text(payload, encoding="utf-8")
            # Prune to last _BACKUP_COUNT backups
            existing = sorted(
                self._backup_dir.glob("skills.*.json"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            for old_path in existing[_BACKUP_COUNT:]:
                try:
                    old_path.unlink()
                except Exception:
                    pass
        except Exception as exc:
            log.warning("SkillCompiler: backup write failed (non-fatal): %s", exc)

    def _load(self):
        if not self._skills_path.exists():
            return []
        try:
            raw = json.loads(self._skills_path.read_text(encoding="utf-8"))
            return [Skill.from_dict(d) for d in raw]
        except Exception as exc:
            # F-SKILL-COMPILER-NO-SILENT-WIPE-1. A corrupt parse previously made
            # the next _save overwrite the whole store with a near-empty list
            # (443 -> 7 incident 2026-05-16). Preserve exact bytes before
            # returning empty so the data is always recoverable off-disk.
            try:
                import shutil as _sh, time as _t
                _sh.copy2(self._skills_path,
                          self._skills_path.with_suffix(".json.corrupt.%d" % int(_t.time())))
            except Exception:
                pass
            log.warning("SkillCompiler: corrupt skills.json preserved to .corrupt.*, "
                        "returning empty (disk NOT reset): %s", exc)
            return []

    def _save(self, skills) -> None:
        # F-SKILL-COMPILER-NO-SILENT-WIPE-1. Atomic write + last-good backup +
        # forced timestamped backup on any shrink. A wipe can now only lose data
        # if every backup is also destroyed.
        import os as _os, shutil as _sh, time as _t
        payload = json.dumps([s.to_dict() for s in skills], indent=2, ensure_ascii=False)
        path = self._skills_path
        if path.exists():
            try:
                prev = path.read_text(encoding="utf-8")
                _sh.copy2(path, path.with_suffix(".json.bak"))
                try:
                    prev_n = len(json.loads(prev))
                except Exception:
                    prev_n = None
                if prev_n is not None and len(skills) < prev_n:
                    _sh.copy2(path, path.with_suffix(".json.shrink.%d" % int(_t.time())))
                    log.warning("SkillCompiler: store shrinking %d -> %d; "
                                "timestamped backup written", prev_n, len(skills))
            except Exception as exc:
                log.warning("SkillCompiler: pre-save backup failed: %s", exc)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(payload, encoding="utf-8")
        _os.replace(tmp, path)
        # Off-path backup after atomic write
        self._backup_skills(payload)

    def _find_duplicate(self, skills, name: str, description: str):
        for i, s in enumerate(skills):
            if s.name == name:
                return i
            if _keyword_similarity(s.description, description) > _DEDUP_THRESHOLD:
                return i
        return None

    def capture(self, name: str, description: str, artifact_path: str,
                success_score: float, task_shape: str) -> Skill:
        """Save a new skill, or update an existing near-duplicate."""
        skills = self._load()
        dup_idx = self._find_duplicate(skills, name, description)

        if dup_idx is not None:
            existing = skills[dup_idx]
            existing.success_score = (existing.success_score + success_score) / 2
            existing.use_count += 1
            existing.task_shape = task_shape
            # F-SKILL-DISCOVERY-REFRESH-1: refresh description + artifact_path
            # when content has changed. Without this, Neuro's updated workflow
            # files are silently ignored because the skill name already exists.
            if description and description != existing.description:
                log.info("SkillCompiler: refreshing description for %r (len %d→%d)",
                         name, len(existing.description), len(description))
                existing.description = description
            if artifact_path and artifact_path != existing.artifact_path:
                existing.artifact_path = artifact_path
            if success_score <= 0.25:
                existing.failure_count += 1
                if existing.failure_count >= 3:
                    existing = self.rewrite_skill(existing, task_shape)
            elif success_score > 0.7 and existing.failure_count > 0:
                existing.failure_count = max(0, existing.failure_count - 1)
            self._save(skills)
            self._audit_write(existing, "updated", trigger=task_shape)
            log.debug("SkillCompiler: updated duplicate skill %r (idx=%d)", name, dup_idx)
            return existing

        # Noise gate — reject before writing to disk
        accepted, reason = _should_accept(name, description, artifact_path, success_score)
        if not accepted:
            log.info("SkillCompiler: REJECTED %r — %s", name, reason)
            return None

        skill = Skill(
            name=name,
            description=description,
            artifact_path=artifact_path,
            success_score=float(success_score),
            task_shape=task_shape,
            created_at=_now(),
            use_count=1,
            failure_count=1 if success_score <= 0.25 else 0,
        )
        skills.append(skill)
        self._save(skills)
        self._audit_write(skill, "created", trigger=task_shape)
        log.debug("SkillCompiler: captured skill %r (score=%.2f)", name, success_score)
        return skill

    def rewrite_skill(self, skill: "Skill", failure_context: str) -> "Skill":
        """Use DeepSeek to generate an improved skill description after repeated failures."""
        try:
            from aibrain.core.companies import _deepseek_http_call
            result = _deepseek_http_call(
                system_prompt=(
                    "You are a skill improvement agent. A skill has failed 3+ times. "
                    "Rewrite its description to be more specific about when it works and when it does NOT. "
                    "Output ONLY a 1-2 sentence improved description. No preamble."
                ),
                user_prompt=(
                    "Skill name: " + skill.name + "\n"
                    "Current description: " + skill.description + "\n"
                    "Task shape that kept failing: " + failure_context + "\n"
                    "Current success score: " + str(round(skill.success_score, 2)) + "\n"
                    "Write an improved description that helps future agents avoid this failure pattern."
                ),
                thinking=False,
                reasoning_effort="medium",
            )
            improved = result.get("content", "").strip()
            if improved and len(improved) > 10:
                skill.description = "[REVISED] " + improved
                skill.failure_count = 0
                self._audit_write(skill, "rewritten", trigger=failure_context)
                log.info("SkillCompiler: rewrote skill %r after repeated failures", skill.name)
        except Exception as exc:
            log.warning("SkillCompiler: rewrite_skill failed: %s", exc)
        return skill

    def search(self, goal_description: str, top_k: int = 5):
        """Return top_k skills by keyword overlap with goal_description."""
        skills = self._load()
        if not skills:
            return []
        scored = [
            (s, _keyword_similarity(goal_description, f"{s.name} {s.description} {s.task_shape}"))
            for s in skills
        ]
        scored.sort(key=lambda x: (-x[1], -x[0].success_score, -x[0].use_count))
        return [s for s, _ in scored[:top_k]]

    def list_skills(self):
        """Return all stored skills sorted by success_score desc, use_count desc."""
        skills = self._load()
        return sorted(skills, key=lambda s: (-s.success_score, -s.use_count))

    # ------------------------------------------------------------------
    # capture_safe — classmethod for hot tool-result path
    # ------------------------------------------------------------------

    @classmethod
    def capture_safe(cls, tool_name: str, result_preview: str) -> Optional[Skill]:
        """F-SKILL-COMPILER-CAPTURE-SAFE-1: class-level capture for the hot
        tool-result path in lucy_agent.py line 6385.

        Previously this line called SkillCompiler.capture_safe() which did not
        exist — AttributeError, silently caught, zero tool-level skills
        captured for months.

        Design:
        - Only captures *creative* tools (edit_file, write_file,
          dispatch_deepseek_task, etc.) — read-only tools are noise.
        - Extracts file paths from the result preview via regex.
        - Creates structured skill descriptions that pass the noise gate.
        - Uses a module-level lazy singleton (_get_singleton).

        Returns: Skill if captured, None if skipped/error.
        """
        try:
            if tool_name not in _CREATIVE_TOOLS:
                return None
            if not result_preview or len(result_preview) < 20:
                return None

            # Extract file paths from the result
            paths: list[str] = []
            for pat in _PATH_PATTERNS:
                for m in pat.finditer(result_preview):
                    p = m.group(0).strip()
                    if p and len(p) > 6:  # ignore noise like "/a.b"
                        paths.append(p)
            # Dedupe, max 5
            seen = set()
            unique_paths = []
            for p in paths:
                if p not in seen:
                    seen.add(p)
                    unique_paths.append(p)
            unique_paths = unique_paths[:5]

            if not unique_paths:
                return None

            h = hashlib.sha1(
                (tool_name + "||" + "\n".join(unique_paths)).encode()
            ).hexdigest()[:10]
            name = f"auto_{tool_name}_{h}"

            path_list = "\n".join(f"  - {p}" for p in unique_paths)
            preview = result_preview[:300].replace("\n", " ").strip()
            description = (
                f"1. Tool used: {tool_name}\n"
                f"2. Files affected:\n{path_list}\n"
                f"3. Result preview: {preview}"
            )

            artifact_path = unique_paths[0]
            compiler = _get_singleton()
            return compiler.capture(
                name=name,
                description=description,
                artifact_path=artifact_path,
                success_score=0.75,
                task_shape=f"tool:{tool_name}",
            )
        except Exception:
            return None

    def __repr__(self) -> str:
        n = len(self._load())
        return f"SkillCompiler(skills={n}, path={self._skills_path})"