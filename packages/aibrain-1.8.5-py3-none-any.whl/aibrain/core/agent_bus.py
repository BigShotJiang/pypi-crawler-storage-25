"""
AgentBus — transport-agnostic message bus for inter-agent communication.

Same machine: writes/reads ~/.tmp/agent_bus_{agent_id}.jsonl (local file IPC).
Broker (Case on VPS): POST http://76.13.198.228:8765/send with X-Token header.
Discord: stubbed — logs and drops (implement when Discord infra is ready).

Any agent registers in agent_registry.json. Adding a new agent = one JSON entry.
"""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

_REGISTRY_PATH = Path(__file__).parent / "agent_registry.json"
_BUS_DIR = Path.home() / ".tmp"
_LOCK_SUFFIX = ".lock"


def _load_registry() -> dict:
    try:
        return json.loads(_REGISTRY_PATH.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("agent_registry.json load failed: %s", e)
        return {}


def _bus_file(agent_id: str) -> Path:
    return _BUS_DIR / f"agent_bus_{agent_id}.jsonl"


def _make_message(from_id: str, to_id: str, text: str, metadata: dict) -> dict:
    return {
        "id": str(uuid.uuid4()),
        "from": from_id,
        "to": to_id,
        "text": text,
        "metadata": metadata or {},
        "ts": time.time(),
    }


def _send_local(msg: dict) -> None:
    _BUS_DIR.mkdir(parents=True, exist_ok=True)
    dest = _bus_file(msg["to"])
    with open(dest, "a", encoding="utf-8") as f:
        f.write(json.dumps(msg, ensure_ascii=False) + "\n")
    log.debug("AgentBus local: %s→%s %s", msg["from"], msg["to"], msg["text"][:60])


def _send_broker(msg: dict, broker_url: str) -> None:
    import urllib.request
    token = os.environ.get("BROKER_TOKEN", "")
    payload = json.dumps({"from": msg["from"], "to": msg["to"], "msg": msg["text"]}).encode()
    req = urllib.request.Request(
        broker_url,
        data=payload,
        headers={"Content-Type": "application/json", "X-Token": token},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            log.debug("AgentBus broker: %s→%s status=%s", msg["from"], msg["to"], resp.status)
    except Exception as e:
        log.warning("AgentBus broker send failed: %s", e)


def _send_discord(msg: dict) -> None:
    log.info("AgentBus Discord transport not yet implemented — message dropped: %s→%s", msg["from"], msg["to"])


class AgentBus:
    """Universal message bus. Instantiate fresh per call — stateless."""

    def __init__(self, registry_path: Path | None = None):
        self._registry = _load_registry() if registry_path is None else json.loads(Path(registry_path).read_text())

    def send(self, from_id: str, to_id: str, text: str, metadata: dict | None = None) -> None:
        """Route a message from from_id to to_id using the appropriate transport."""
        msg = _make_message(from_id, to_id, text, metadata or {})
        agent = self._registry.get(to_id, {})
        location = agent.get("location", "local")

        if location == "local":
            _send_local(msg)
        elif location == "broker":
            broker_url = agent.get("broker_url", "http://76.13.198.228:8765/send")
            _send_broker(msg, broker_url)
        elif location == "discord":
            _send_discord(msg)
        else:
            log.warning("AgentBus: unknown transport '%s' for agent '%s' — dropping", location, to_id)

    def broadcast(self, from_id: str, text: str, metadata: dict | None = None) -> None:
        """Send to every registered agent except the sender."""
        for agent_id in self._registry:
            if agent_id != from_id:
                self.send(from_id, agent_id, text, metadata)

    def receive(self, agent_id: str, clear: bool = True) -> list[dict[str, Any]]:
        """
        Read and optionally drain all messages queued for agent_id.
        Returns list of message dicts (may be empty).
        """
        dest = _bus_file(agent_id)
        if not dest.exists():
            return []
        try:
            raw = dest.read_text(encoding="utf-8")
            if clear:
                dest.unlink()
            messages = []
            for line in raw.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    messages.append(json.loads(line))
                except json.JSONDecodeError as e:
                    log.warning("AgentBus: bad message line for %s: %s", agent_id, e)
            return messages
        except Exception as e:
            log.warning("AgentBus receive error for %s: %s", agent_id, e)
            return []
