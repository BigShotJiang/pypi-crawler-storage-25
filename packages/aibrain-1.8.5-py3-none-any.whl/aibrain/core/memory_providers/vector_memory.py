from aibrain.core.memory_provider import MemoryProvider, Memory


class VectorMemoryAdapter(MemoryProvider):
    @property
    def id(self) -> str:
        return 'vector_memory'

    @property
    def capabilities(self) -> frozenset:
        return frozenset({
            'semantic_search',
            'importance_scoring',
            'forget',
            'fact_extraction',
            'enumerate',
        })

    async def store(self, content: str, metadata: dict) -> str:
        # Lazy import inside method to avoid circular imports
        import mcp_server
        result = mcp_server._store(
            name=metadata.get('name', 'memory'),
            content=content,
            mem_type=metadata.get('type', 'reference'),
            tags=metadata.get('tags', ''),
            importance=float(metadata.get('importance', 0.5)),
            classification=metadata.get('classification', 'PUBLIC'),
        )
        return str(result.get('id', '0'))

    async def retrieve(self, query: str, top_k: int = 5, filters: dict | None = None) -> list[Memory]:
        import mcp_server
        search_type = (filters or {}).get('search_type')
        results = mcp_server._search(query=query, limit=top_k, search_type=search_type)
        memories = []
        for r in results:
            metadata = {k: v for k, v in r.items() if k not in ('id', 'content', 'score')}
            memories.append(Memory(
                id=str(r['id']),
                content=r.get('content', ''),
                metadata=metadata,
                score=float(r.get('score', 0.0)),
                provider_id='vector_memory',
            ))
        return memories

    async def forget(self, memory_id: str) -> None:
        import aibrain_db
        aibrain_db.delete_memory(int(memory_id))

    async def init(self, config: dict) -> None:
        pass

    async def destroy(self) -> None:
        pass
