"""
companies.py — Companies feature for AIBrain.

Create and manage AI agent teams that learn and improve over time.
Multi-agent orchestration backed by persistent brain memory.

Usage:
    from aibrain.core.companies import create_company, hire_agent, create_task

    company = create_company("Marketing Team", mission="Scale content to 1M reach")
    ceo = hire_agent(company["id"], "CEO", role="ceo")
    task = create_task(company["id"], "Write 5 LinkedIn posts", assignee=ceo["id"])
"""

import atexit
import json
import logging
import secrets
import sqlite3
import threading
import time
from contextlib import closing
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional


class TaskCompletionLockTimeout(Exception):
    """Raised when complete_task() cannot acquire the write lock after retries."""
    def __init__(self, task_id, attempts, last_error):
        super().__init__(
            f"Task {task_id}: WAL lock timed out after {attempts} attempts. "
            f"Last error: {last_error}. Escalate to Decker — do not bypass with direct SQL."
        )
        self.task_id = task_id
        self.attempts = attempts
        self.last_error = last_error


class DispatchApplyFailed(Exception):
    """Raised when dispatch output application fails."""
    def __init__(self, task_id, applied_files, errors):
        super().__init__(f"Task {task_id}: dispatch apply failed. Errors: {', '.join(errors[:3])}")
        self.task_id = task_id
        self.applied_files = applied_files
        self.errors = errors


def _execute_db_update_with_retry(db, sql, params, task_id):
    """Retry-backoff wrapper for the final UPDATE in complete_task().

    Only retries on WAL lock contention (sqlite3.OperationalError with 'lock').
    All other exceptions raise immediately. After retry budget exhausted, raises
    TaskCompletionLockTimeout — caller must escalate, NOT bypass with direct SQL.
    """
    delays = [1, 2, 4, 8, 16]
    last_error = None
    for attempt, delay in enumerate(delays, start=1):
        try:
            db.execute(sql, params)
            db.commit()
            return
        except sqlite3.OperationalError as e:
            if "lock" not in str(e).lower():
                raise
            last_error = e
            if attempt < len(delays):
                time.sleep(delay)
    raise TaskCompletionLockTimeout(task_id, len(delays), last_error)

log = logging.getLogger("aibrain.companies")

import os as _os
# Gate-2 pass threshold — quality_score must meet this to auto-clear the Liaison gate.
# DS_LOOP_GATE2_MIN_SCORE env var can raise the bar but never lower it below 0.87.
GATE2_MIN_SCORE: float = max(0.87, float(_os.environ.get("DS_LOOP_GATE2_MIN_SCORE", "0.87")))


# ---------------------------------------------------------------------------
# Retry helper — wraps SQLite/DB calls that can transiently fail when the
# aibrain backend process is restarting or the DB is temporarily locked.
# ---------------------------------------------------------------------------

_RETRY_ATTEMPTS = 3
_RETRY_BACKOFF_S = 2.0
_BACKEND_OFFLINE_MSG = (
    "aibrain backend offline — restart with: python -m aibrain serve"
)


def _get_dispatch_mode() -> str:
    """Read dispatch_mode: env var override → aibrain.db config table → default force_deepseek."""
    import os as _os
    env_mode = _os.environ.get("AIBRAIN_DEEPSEEK_DISPATCH_MODE")
    if env_mode:
        return env_mode
    try:
        # Resolve aibrain.db relative to this file (../../aibrain.db from core/)
        db_path = Path(__file__).parent.parent.parent / "aibrain.db"
        if not db_path.exists():
            root = _os.environ.get("AIBRAIN_ROOT", str(Path.home() / "projects" / "aibrain"))
            db_path = Path(root) / "aibrain.db"
        with closing(sqlite3.connect(str(db_path), timeout=5)) as conn:
            conn.execute("PRAGMA busy_timeout=30000")
            row = conn.execute("SELECT value FROM config WHERE key=?", ["dispatch_mode"]).fetchone()
        if row and row[0]:
            val = row[0].strip('"')
            if val in ("force_deepseek", "force_claude", "auto"):
                return val
    except Exception:
        pass
    return "force_deepseek"


def _is_non_retryable(exc: Exception) -> bool:
    """Return True for structured logic exceptions that must NOT be retried.

    The retry wrapper exists to shield against transient DB/backend flakiness.
    Logical outcomes — gate FAILs, kill-switch overflow, structural CLI/creds
    unavailability — are deterministic results of the inputs and will repeat
    identically on retry.  Retrying them (a) wastes 6s of backoff, and (b)
    masks the real exception class behind RuntimeError("backend offline"),
    which breaks callers that catch the specific class (pytest.raises(...),
    caller's two-gate retry loop).

    Lookup by class-name string to avoid forward-reference problems (these
    classes are defined later in the module).
    """
    _non_retryable_names = {
        "TaskReviewFailed",
        "HandlerExecutionFailed",  # handler is broken — retrying won't fix it
        "TaskDeepSeekGateFailed",
        "TaskKillSwitchOverflow",
        "ReviewStalemateBlocked",  # stalemate is deterministic — retrying hits it again
        "LiaisonCLIUnavailable",
        "LiaisonReviewCallFailed",
        "SkipNotPermitted",    # structural permission failure — retrying won't change the role
        "AssertionError",  # tests assert on call counts — don't mask
        "ValueError",      # structural precondition failure (e.g. work_output missing for high/critical)
        "UnboundLocalError",  # deterministic code bug — repeats identically; masking
        "NameError",          # it as "backend offline" cost hours of misdiagnosis
    }
    return type(exc).__name__ in _non_retryable_names


def _call_with_retry(fn, *args, **kwargs):
    """Call fn(*args, **kwargs) up to _RETRY_ATTEMPTS times with backoff.

    Catches transient Exception on each attempt. If all attempts fail, raises
    RuntimeError with a clear message naming the restart command.

    Non-retryable exceptions (see _is_non_retryable) propagate immediately.

    Falsifiability: verified by attempting to call a function when the DB
    is unreachable — the caller should see RuntimeError with _BACKEND_OFFLINE_MSG
    after 3 attempts × 2 s backoff (≈6 s total).  Structured logic exceptions
    (TaskReviewFailed, TaskDeepSeekGateFailed, etc.) must propagate on the
    first raise, not be wrapped in RuntimeError.
    """
    last_exc: Exception = RuntimeError("no attempts made")
    for attempt in range(1, _RETRY_ATTEMPTS + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            if _is_non_retryable(exc):
                # Structured logic outcome — propagate so callers can catch
                # the specific class (pytest.raises / two-gate retry loop).
                raise
            last_exc = exc
            if attempt < _RETRY_ATTEMPTS:
                log.warning(
                    "_call_with_retry: attempt %d/%d failed (%s: %s) — retrying in %.1fs",
                    attempt, _RETRY_ATTEMPTS, type(exc).__name__, exc, _RETRY_BACKOFF_S,
                )
                time.sleep(_RETRY_BACKOFF_S)
            else:
                log.error(
                    "_call_with_retry: all %d attempts failed for %s — %s",
                    _RETRY_ATTEMPTS, getattr(fn, "__name__", fn), exc,
                )
    raise RuntimeError(_BACKEND_OFFLINE_MSG) from last_exc


# ---------------------------------------------------------------------------
# Fix 5: Import-time integrity check
# ---------------------------------------------------------------------------

def _validate_harness_integrity() -> None:
    """Verify DB schema has required columns before any operation.

    Runs at module import time. Raises ImportError if the DB exists but is
    missing columns that the review gate and quality enforcement depend on.

    Falsifiability: this check is proven wrong if a DB passes it but a
    subsequent complete_task() call raises sqlite3.OperationalError on one
    of the named columns. That would mean this check is incomplete and the
    missing column must be added to the set below.

    Skips silently if the DB doesn't exist yet (fresh install — schema
    created on first write).
    """
    try:
        from aibrain_db import AIBRAIN_ROOT
        db_path = AIBRAIN_ROOT / "aibrain.db"
        if not db_path.exists():
            return  # fresh install — schema will be created on first use

        with closing(sqlite3.connect(str(db_path), timeout=5)) as db:
            db.execute("PRAGMA busy_timeout=30000")
            db.row_factory = sqlite3.Row

            # Required columns in company_issues for review gate + quality enforcement
            required_issue_columns = {
                "priority", "status", "quality_score", "self_score",
                "eval_score", "quality_verified", "quality_flagged",
            }
            # Required columns in execution_log for honest audit trail
            required_log_columns = {
                "cost_cents", "cost_cents_actual", "cost_cents_equivalent",
                "quality_score", "self_score", "divergence", "flagged",
            }

            def _existing_columns(table: str) -> set:
                rows = db.execute(f"PRAGMA table_info({table})").fetchall()
                return {r["name"] for r in rows}

            def _table_exists(table: str) -> bool:
                row = db.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                    (table,),
                ).fetchone()
                return row is not None

            # If company_issues doesn't exist yet, the schema hasn't been
            # initialised for this DB (e.g. a partial/legacy DB in AIBRAIN_ROOT).
            # Skip the hard-missing check — schema will be created on first write.
            if not _table_exists("company_issues"):
                return

            issues_cols = _existing_columns("company_issues")
            log_cols = _existing_columns("execution_log")

        missing_issues = required_issue_columns - issues_cols
        missing_log = required_log_columns - log_cols

        # Missing review_required and eval columns are auto-migrated in
        # complete_task() — only hard-fail on columns that cannot be
        # auto-added without data loss.
        hard_missing = {c for c in missing_issues if c in {"priority", "status"}}

        if hard_missing:
            raise ImportError(
                f"aibrain.core.companies: company_issues table is missing "
                f"critical columns: {hard_missing}. "
                f"Run: python -m aibrain doctor --fix"
            )

        if missing_issues or missing_log:
            log.debug(
                "companies integrity: soft-missing columns will be auto-migrated "
                "(issues=%s, log=%s)", missing_issues, missing_log
            )

    except ImportError:
        raise  # re-raise ImportError from hard_missing check
    except Exception as e:
        # Non-fatal: DB may be locked, inaccessible on first import, etc.
        log.debug("_validate_harness_integrity skipped: %s", e)


_validate_harness_integrity()


def _migrate_company_issues_status_check() -> None:
    """Idempotent migration that extends the company_issues.status CHECK
    constraint to include ``'needs_human_review'``.

    Task GahbnvK2buQ Criterion 7 requires the kill-switch branch to set
    ``status='needs_human_review'`` literally.  The original schema
    created an exhaustive CHECK(status IN (...)) constraint that did not
    include this value, which forced the prior implementation to use
    the pair ``(status='blocked', terminal_state='needs_human_review')``.
    Liaison review 2026-04-24 rejected the pair as a semantic deviation
    from the binary acceptance criterion.

    SQLite has no ``ALTER TABLE ... DROP CONSTRAINT`` — extending a
    CHECK requires the canonical rename / create-new / copy-rows / drop
    pattern.  This function performs that rebuild once per DB; on
    subsequent calls it detects the extended constraint in
    ``sqlite_master`` and returns without touching anything.

    Safe to call from any entry point because it:
    - runs inside a single transaction (BEGIN ... COMMIT)
    - preserves every existing row and column
    - preserves the self-referential FK (parent_id) via
      ``PRAGMA foreign_keys=OFF`` during the rebuild
    - no external FKs reference company_issues.id (verified
      2026-04-24 via sqlite_master scan)
    - fails closed with a log.warning if the rebuild errors — the
      caller is expected to continue using the existing schema
    """
    try:
        db = _get_db()
        row = db.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='company_issues'"
        ).fetchone()
        if row is None:
            return  # fresh install — other code paths create the schema
        existing_sql = row["sql"] or ""
        if "'needs_human_review'" in existing_sql:
            return  # already migrated — no-op
        if "CHECK(status IN" not in existing_sql:
            return  # no CHECK constraint to extend — nothing to do

        # Capture column list so the copy preserves every field the
        # live production schema has accumulated (terminal_state,
        # review_round, work_output, etc.).
        cols_rows = db.execute("PRAGMA table_info(company_issues)").fetchall()
        col_names = [r["name"] for r in cols_rows]
        col_list = ", ".join(col_names)

        # Build the new CREATE TABLE SQL by replacing the status CHECK
        # constraint in-place.  We derive it from the existing SQL to
        # keep column types, defaults, and ordering identical.
        import re
        new_create_sql = re.sub(
            r"CHECK\(status IN \('backlog','todo','in_progress','in_review','done','blocked','cancelled'\)\)",
            "CHECK(status IN ('backlog','todo','in_progress','in_review','done','blocked','cancelled','needs_human_review'))",
            existing_sql,
            count=1,
        )
        if new_create_sql == existing_sql:
            # Regex did not match — constraint text differs from what we
            # expect.  Fail closed, keep legacy (status='blocked',
            # terminal_state='needs_human_review') pair.
            log.warning(
                "_migrate_company_issues_status_check: status CHECK pattern "
                "did not match; skipping rebuild"
            )
            return
        new_create_sql = new_create_sql.replace(
            "CREATE TABLE company_issues",
            "CREATE TABLE company_issues_new",
            1,
        )

        db.execute("PRAGMA foreign_keys=OFF")
        db.execute("BEGIN IMMEDIATE")
        try:
            db.execute(new_create_sql)
            db.execute(
                f"INSERT INTO company_issues_new ({col_list}) "
                f"SELECT {col_list} FROM company_issues"
            )
            db.execute("DROP TABLE company_issues")
            db.execute("ALTER TABLE company_issues_new RENAME TO company_issues")
            db.execute("COMMIT")
        except Exception:
            db.execute("ROLLBACK")
            raise
        finally:
            db.execute("PRAGMA foreign_keys=ON")
        log.info(
            "_migrate_company_issues_status_check: extended status CHECK to "
            "include 'needs_human_review' (task GahbnvK2buQ)"
        )
    except Exception as _mig_err:
        log.warning(
            "_migrate_company_issues_status_check skipped (non-fatal): %s",
            _mig_err,
        )


# ---------------------------------------------------------------------------
# Thread-local checkout context
# ---------------------------------------------------------------------------
#
# When an agent calls checkout_task(), we stash the task ID and company ID in
# thread-local storage so that any harness.execute() call made during the
# checkout → work → complete window can link its execution_log row back to
# the specific company_issue it's servicing. Without this, the harness has
# no way to know which company issue it's working on and every row lands
# with entity_type='task' (the generic fallback).
#
# v1.4 P0-2 fix: Internal audit 2026-04-11 found 100% of execution_log rows
# stamped entity_type='task', zero linkage to company_issues. Root cause:
# checkout_task returned the task dict but never stashed the issue ID
# anywhere the harness could read it. This thread-local is the missing wire.
#
# Nested checkouts: the new checkout shadows the previous one on the same
# thread. Complete of the outer task clears the stash entirely (both id and
# company_id get set to None). This matches the "last checkout wins" model
# used elsewhere in the codebase for per-thread context.
#
# Thread safety: threading.local() gives each thread its own attribute
# namespace, so two worker threads running parallel checkouts never cross-
# contaminate each other's linkage.
_current_issue = threading.local()


def _get_current_issue_id() -> Optional[str]:
    """Return the currently-checked-out task ID on this thread, or None.

    Used by aibrain.core.harness.execute to stamp execution_log rows with
    entity_type='company_issue' and the correct entity_id when a harness
    call happens inside a checkout → complete window.
    """
    return getattr(_current_issue, "id", None)


def _get_current_company_id() -> Optional[str]:
    """Return the currently-checked-out company ID on this thread, or None."""
    return getattr(_current_issue, "company_id", None)



# ---------------------------------------------------------------------------
# Per-thread DB connection pool
# ---------------------------------------------------------------------------
#
# Each thread gets exactly one persistent sqlite3 connection, created on first
# use and reused for every subsequent _get_db() call on the same thread.
# This eliminates the open→query→close overhead that was firing on every
# function call (N concurrent agent tasks = N redundant connect/close pairs).
#
# Design notes:
#   - check_same_thread=False is required: threading.local() guarantees each
#     thread accesses only its own connection, so the sqlite3 safety check
#     becomes a false positive.
#   - WAL mode + busy_timeout are set once at connection creation, not on
#     every call — valid because PRAGMAs persist for the connection lifetime.
#   - close_all_thread_connections() is the clean-shutdown path (atexit +
#     explicit call). It iterates all stashed connections and closes them.
#   - The _validate_harness_integrity() import-time check opens its own
#     short-lived connection deliberately (runs before the thread-local pool
#     is populated) — that's fine and intentional; it closes its own conn.
#
# Falsifiability: if the pool is working, `grep -c "sqlite3.connect"
# aibrain/core/companies.py` should return 1 (only _get_db opens connections).
# All other functions that previously called sqlite3.connect directly have
# been replaced with _get_db() calls.

_db_pool = threading.local()
# SA-2026-002 F-27: track conns by owning-thread id, periodically prune dead-thread
# entries so the dict can't grow unboundedly when uvicorn / APScheduler recycle workers.
# (sqlite3.Connection isn't weakly-referenceable, so a weakref.WeakSet approach won't work.)
_thread_conns: dict = {}   # thread.ident -> sqlite3.Connection
_pool_lock = threading.Lock()
_PRUNE_EVERY = 50          # SA-2026-002 F-27: prune attempt every N inserts
_prune_counter = 0


def _prune_dead_thread_conns_locked():
    """SA-2026-002 F-27: drop entries whose owning thread is no longer alive.

    Caller MUST hold _pool_lock. Closes each pruned conn before removal so the
    underlying fd is released.
    """
    alive_ids = {t.ident for t in threading.enumerate() if t.ident is not None}
    dead_ids = [tid for tid in list(_thread_conns.keys()) if tid not in alive_ids]
    for tid in dead_ids:
        conn = _thread_conns.pop(tid, None)
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def _get_db():
    """Return the per-thread persistent sqlite3 connection.

    Creates the connection on first call for this thread; reuses it on
    every subsequent call. Never call .close() on the returned connection
    inside normal function bodies — let the persistent connection live.

    text_factory is set defensively so a corrupted row (non-UTF-8 byte in any
    TEXT column) does NOT crash the entire query — the bad bytes are replaced
    with the Unicode replacement character (U+FFFD) and the rest of the row
    comes back intact. Surfaced 2026-04-12 by Case reporting a UTF-8 decode
    error on one agent's capabilities field that was breaking list_agents()
    on his side. Pattern #11 — fix the hole at the connection layer so every
    query benefits, not bail the water in list_agents alone.
    """
    conn = getattr(_db_pool, "conn", None)
    if conn is not None:
        try:
            conn.execute("SELECT 1")
        except sqlite3.ProgrammingError:
            try:
                conn.close()
            except Exception:
                pass
            conn = None
            _db_pool.conn = None
    if conn is None:
        from aibrain_db import AIBRAIN_ROOT
        db_path = AIBRAIN_ROOT / "aibrain.db"
        conn = sqlite3.connect(str(db_path), check_same_thread=False, timeout=35.0)
        conn.row_factory = sqlite3.Row
        conn.text_factory = (
            lambda b: b.decode("utf-8", errors="replace")
            if isinstance(b, (bytes, bytearray))
            else b
        )
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA wal_autocheckpoint=200")
        conn.execute("PRAGMA busy_timeout=30000")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        # Multi-instance safety — additive session_id column migration.
        try:
            from aibrain.core.db_safety import ensure_session_columns as _ess
            _ess(conn)
        except Exception:
            pass
        _db_pool.conn = conn
        with _pool_lock:
            global _prune_counter
            # SA-2026-002 F-27: track conn under owning thread id; prune dead threads periodically
            _thread_conns[threading.get_ident()] = conn
            _prune_counter += 1
            if _prune_counter >= _PRUNE_EVERY:
                _prune_counter = 0
                _prune_dead_thread_conns_locked()
    return conn


def close_all_thread_connections() -> None:
    """Close every pooled thread-local connection.

    Call explicitly on clean shutdown (e.g. end of a batch job or test
    teardown). Also registered with atexit so normal process exit is safe.

    Idempotent: safe to call multiple times; already-closed connections are
    silently skipped.
    """
    with _pool_lock:
        # SA-2026-002 F-27: drain _thread_conns (replaced _all_pool_conns)
        conns = list(_thread_conns.values())
        _thread_conns.clear()
    for conn in conns:
        try:
            conn.close()
        except Exception:
            pass
    # Clear the local-thread stash too so _get_db() recreates if called again
    _db_pool.conn = None


atexit.register(close_all_thread_connections)


# ---------------------------------------------------------------------------
# Companies
# ---------------------------------------------------------------------------

def create_company(name: str, mission: str = "") -> dict:
    """Create a new company."""
    db = _get_db()
    company_id = secrets.token_urlsafe(8)

    # Check tier limits
    try:
        from aibrain_licensing import get_license
        lic = get_license()
        existing = db.execute("SELECT COUNT(*) FROM companies WHERE status='active'").fetchone()[0]
        limits = json.loads(db.execute("SELECT value FROM config WHERE key='companies_tier_limits'").fetchone()[0])
        max_companies = limits.get(f"{lic.tier}_companies", 1)
        if existing >= max_companies:
            return {"error": f"Company limit reached ({existing}/{max_companies}). Upgrade to Pro for unlimited companies."}
    except Exception:
        pass

    db.execute(
        "INSERT INTO companies (id, name, mission) VALUES (?, ?, ?)",
        (company_id, name, mission)
    )
    db.commit()

    result = dict(db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone())

    log.info("Company created: %s (%s)", name, company_id)
    return result


def list_companies(status: str = None) -> list:
    """List all companies."""
    db = _get_db()
    if status:
        rows = db.execute("SELECT * FROM companies WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM companies ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


def get_company(company_id: str) -> Optional[dict]:
    """Get company details with agent count and task stats."""
    db = _get_db()
    company = db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
    if not company:
        return None

    result = dict(company)
    result["agent_count"] = db.execute(
        "SELECT COUNT(*) FROM company_agents WHERE company_id=? AND status != 'terminated'",
        (company_id,)
    ).fetchone()[0]
    result["active_tasks"] = db.execute(
        "SELECT COUNT(*) FROM company_issues WHERE company_id=? AND status IN ('todo','in_progress','in_review')",
        (company_id,)
    ).fetchone()[0]
    result["completed_tasks"] = db.execute(
        "SELECT COUNT(*) FROM company_issues WHERE company_id=? AND status='done'",
        (company_id,)
    ).fetchone()[0]

    return result


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

def hire_agent(company_id: str, name: str, role: str = "general",
               title: str = "", reports_to: str = None,
               model: str = "auto", capabilities: str = "") -> dict:
    """Hire a new agent for a company."""
    db = _get_db()
    agent_id = secrets.token_urlsafe(8)

    # Check tier limits
    try:
        from aibrain_licensing import get_license
        lic = get_license()
        existing = db.execute(
            "SELECT COUNT(*) FROM company_agents WHERE company_id=? AND status != 'terminated'",
            (company_id,)
        ).fetchone()[0]
        limits = json.loads(db.execute("SELECT value FROM config WHERE key='companies_tier_limits'").fetchone()[0])
        max_agents = limits.get(f"{lic.tier}_agents_per_company", 2)
        if existing >= max_agents:
            return {"error": f"Agent limit reached ({existing}/{max_agents}). Upgrade to Pro for more agents."}
    except Exception:
        pass

    # Map role to harness task type and authority
    role_config = {
        "ceo": {"task_type": "complex", "authority": "admin"},
        "manager": {"task_type": "judgment", "authority": "elevated"},
        "general": {"task_type": "simple", "authority": "standard"},
    }
    config = role_config.get(role, role_config["general"])

    db.execute("""
        INSERT INTO company_agents
        (id, company_id, name, role, title, reports_to, model, task_type, authority, capabilities)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (agent_id, company_id, name, role, title or name, reports_to, model,
          config["task_type"], config["authority"], capabilities))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_agents WHERE id=?", (agent_id,)).fetchone())

    log.info("Agent hired: %s (%s) for company %s", name, role, company_id)
    return result


def list_agents(company_id: str, status: str = None) -> list:
    """List all agents in a company."""
    db = _get_db()
    if status:
        rows = db.execute(
            "SELECT * FROM company_agents WHERE company_id=? AND status=? ORDER BY role, name",
            (company_id, status)
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM company_agents WHERE company_id=? AND status != 'terminated' ORDER BY role, name",
            (company_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def get_agent(agent_id: str) -> Optional[dict]:
    """Get agent details."""
    db = _get_db()
    agent = db.execute("SELECT * FROM company_agents WHERE id=?", (agent_id,)).fetchone()
    return dict(agent) if agent else None


# ---------------------------------------------------------------------------
# Tasks / Issues
# ---------------------------------------------------------------------------

def create_task(company_id: str, title: str, description: str = "",
                assignee_agent_id: str = None, priority: str = "medium",
                parent_id: str = None, project: str = "",
                auto_route: bool = True) -> dict:
    """Create a task/issue for a company.

    When auto_route is True (default), uses SelRoute-inspired scoring to
    assign a primary agent (highest fitness) and a secondary agent (reviewer/QA).
    If assignee_agent_id is explicitly provided, it becomes the primary but
    a secondary is still assigned automatically.
    """
    # --- SelRoute agent routing — runs BEFORE validation so auto_route can fill the assignee ---
    secondary_agent_id = None
    if auto_route:
        try:
            from aibrain.core.task_router import route_task
            routing = route_task(
                company_id, title, description,
                explicit_assignee=assignee_agent_id,
            )
            if not assignee_agent_id and routing.get("primary"):
                assignee_agent_id = routing["primary"]
            secondary_agent_id = routing.get("secondary")
        except Exception as e:
            log.debug("Task routing failed (non-fatal): %s", e)

    if auto_route and (not assignee_agent_id or not str(assignee_agent_id).strip()):
        log.warning(
            "create_task: auto_route=True but no agent assigned after routing "
            "(company may have no agents or routing failed) — task will be unassigned"
        )

    # Pre-flight: validate verify: lines so bad formats are caught at authoring
    # time with actionable messages instead of silently failing at gate execution.
    if description:
        try:
            from aibrain.core.task_verification import validate_verify_lines
            _vl_errors = validate_verify_lines(description)
            if _vl_errors:
                raise ValueError(
                    "Invalid verify: line(s) in task description:\n" + "\n".join(_vl_errors)
                )
        except ImportError:
            pass

    db = _get_db()
    task_id = secrets.token_urlsafe(8)

    # Get next issue number for this company
    max_num = db.execute(
        "SELECT COALESCE(MAX(issue_number), 0) FROM company_issues WHERE company_id=?",
        (company_id,)
    ).fetchone()[0]
    issue_number = max_num + 1

    # FIX 1 (2026-04-19, task Iy80OK0PLa0): critical/high priority auto-sets
    # review_required=1 so complete_task()'s Special Liaison gate fires. Without
    # this, the gate saw review_required=0 and skipped review on critical work.
    # EXTENSION (2026-04-19, task 17CQSsnHIWA): extended to medium per Decker
    # override — Iy80OK0PLa0-class scope violations can happen at any priority;
    # coverage over rigor tax. 'low' stays opt-out (escape hatch for trivial
    # work where spawn overhead > the work). Use set_review_required() to
    # manually force any low-priority task into the gate.
    review_required = 1 if priority in ("critical", "high", "medium") else 0

    # Migration-safe: review_required column may not exist on legacy DBs.
    # If the INSERT fails on that column, add the column and retry.
    try:
        db.execute("""
            INSERT INTO company_issues
            (id, company_id, parent_id, title, description, assignee_agent_id, priority, project, issue_number, review_required)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (task_id, company_id, parent_id, title, description,
              assignee_agent_id, priority, project, issue_number, review_required))
    except sqlite3.OperationalError as e:
        if "review_required" in str(e):
            try:
                db.execute(
                    "ALTER TABLE company_issues ADD COLUMN review_required INTEGER DEFAULT 0"
                )
                db.commit()
            except sqlite3.OperationalError:
                pass  # column may have been added concurrently
            db.execute("""
                INSERT INTO company_issues
                (id, company_id, parent_id, title, description, assignee_agent_id, priority, project, issue_number, review_required)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (task_id, company_id, parent_id, title, description,
                  assignee_agent_id, priority, project, issue_number, review_required))
        else:
            raise
    db.commit()

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())

    # Attach routing metadata (not persisted in DB, returned to caller)
    if secondary_agent_id:
        result["secondary_agent_id"] = secondary_agent_id

    log.info("Task created: #%d %s (company %s, primary=%s, secondary=%s)",
             issue_number, title, company_id, assignee_agent_id, secondary_agent_id)

    # Review-contract banner (2026-04-22, Decker directive): surface the review
    # gate at creation time so the caller knows the task will be Codex-reviewed
    # at complete_task() time. Silent for low-priority opt-out tasks.
    if review_required:
        review_notice = (
            f"This task will be reviewed by Codex "
            f"(task_id={task_id}, priority={priority})."
        )
        log.info(review_notice)
        result["review_notice"] = review_notice

    # FLEETBUS-HOOK: publish assignment so daemons receive work in real-time
    if assignee_agent_id:
        try:
            from aibrain.core.agent_comms import FleetBus
            bus = FleetBus(agent_id="system")
            bus.publish("fleet.task.assigned", {
                "task_id": task_id,
                "title": title,
                "assignee_agent_id": assignee_agent_id,
                "priority": priority,
            })
        except Exception as _fleet_pub_err:
            log.debug("FleetBus publish for new task failed (non-fatal): %s", _fleet_pub_err)

    return result


def list_tasks(
    company_id: str,
    status: str = None,
    assignee: str = None,
    limit: int = None,
    offset: int = 0,
    q: str = None,
) -> list:
    """List tasks for a company. Always returns a plain list.

    Use list_tasks_paginated() when you need total count and has_more metadata.
    q: optional text search against title and description (case-insensitive LIKE).
    """
    db = _get_db()
    where = "WHERE company_id=?"
    params: list = [company_id]

    if status:
        where += " AND status=?"
        params.append(status)
    if assignee:
        where += " AND assignee_agent_id=?"
        params.append(assignee)
    if q:
        where += " AND (LOWER(title) LIKE ? OR LOWER(description) LIKE ?)"
        pattern = f"%{q.lower()}%"
        params.extend([pattern, pattern])

    order = " ORDER BY priority, created_at DESC"

    if limit is not None:
        rows = db.execute(
            f"SELECT * FROM company_issues {where}{order} LIMIT ? OFFSET ?",
            params + [limit, offset],
        ).fetchall()
    else:
        rows = db.execute(
            f"SELECT * FROM company_issues {where}{order}", params
        ).fetchall()

    return [dict(r) for r in rows]


def list_tasks_paginated(
    company_id: str,
    status: str = None,
    assignee: str = None,
    limit: int = 50,
    offset: int = 0,
    q: str = None,
) -> dict:
    """List tasks with pagination metadata.

    Returns {"tasks": [...], "total": N, "has_more": bool, "offset": N, "limit": N}.
    Use this when you need to know whether more pages exist (e.g. dashboard, API).
    For simple iteration, use list_tasks() which always returns a plain list.
    """
    db = _get_db()
    where = "WHERE company_id=?"
    params: list = [company_id]

    if status:
        where += " AND status=?"
        params.append(status)
    if assignee:
        where += " AND assignee_agent_id=?"
        params.append(assignee)
    if q:
        where += " AND (LOWER(title) LIKE ? OR LOWER(description) LIKE ?)"
        pattern = f"%{q.lower()}%"
        params.extend([pattern, pattern])

    order = " ORDER BY priority, created_at DESC"

    total = db.execute(
        f"SELECT COUNT(*) FROM company_issues {where}", params
    ).fetchone()[0]
    rows = db.execute(
        f"SELECT * FROM company_issues {where}{order} LIMIT ? OFFSET ?",
        params + [limit, offset],
    ).fetchall()
    tasks = [dict(r) for r in rows]

    return {
        "tasks": tasks,
        "total": total,
        "has_more": (offset + len(tasks)) < total,
        "offset": offset,
        "limit": limit,
    }


def get_task(task_id: str) -> dict | None:
    """Fetch a single task by ID. Returns dict or None if not found."""
    db = _get_db()
    row = db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone()
    return dict(row) if row else None


def update_task(task_id: str, **kwargs) -> dict:
    """Update allowed fields on a task and return the updated dict.

    Allowed fields: status, priority, assignee_agent_id.
    Unknown keys are silently ignored to prevent SQL injection.
    Raises ValueError if task_id not found.
    """
    allowed = {"status", "priority", "assignee_agent_id", "work_output", "title", "description"}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates:
        task = get_task(task_id)
        if task is None:
            raise ValueError(f"Task {task_id} not found")
        return task

    set_clause = ", ".join(f"{col}=?" for col in updates)
    values = list(updates.values()) + [task_id]

    db = _get_db()
    db.execute(
        f"UPDATE company_issues SET {set_clause}, updated_at=datetime('now') WHERE id=?",
        values,
    )
    db.commit()

    task = get_task(task_id)
    if task is None:
        raise ValueError(f"Task {task_id} not found")
    return task


def recover_stale_tasks(company_id: str, stale_minutes: int = 60) -> int:
    """Reset tasks stuck in_progress for >stale_minutes back to todo.

    Returns the number of tasks recovered.
    Tasks are considered stale if updated_at has not changed in stale_minutes.
    """
    db = _get_db()
    # Pass stale_minutes as a plain integer parameter — no f-string injection.
    # SQLite constructs the interval modifier entirely within the DB engine:
    # CAST(? AS TEXT) produces the integer string, '-' || ... || ' minutes'
    # builds the modifier (e.g. "-60 minutes"), all without touching Python
    # string formatting on a user-supplied value.
    cur = db.execute("""
        UPDATE company_issues
        SET status='todo', updated_at=datetime('now')
        WHERE company_id=?
          AND status='in_progress'
          AND updated_at < datetime('now', '-' || CAST(? AS TEXT) || ' minutes')
    """, (company_id, stale_minutes))
    count = cur.rowcount
    db.commit()
    if count:
        log.info("Recovered %d stale in-progress task(s) for company %s", count, company_id)
    return count


def _recover_stale_tasks_for_db(task_id: str, stale_minutes: int = 60) -> None:
    """Internal helper: recover stale tasks in the same company as task_id."""
    try:
        db = _get_db()
        row = db.execute("SELECT company_id FROM company_issues WHERE id=?", (task_id,)).fetchone()
        if row:
            recover_stale_tasks(row["company_id"], stale_minutes)
    except Exception as e:
        log.debug("Stale task recovery failed: %s", e)


def checkout_task(task_id: str, agent_id: str) -> dict:
    """Atomically claim a task. Returns 409-equivalent if already claimed.

    Uses a single atomic UPDATE with rowcount check to eliminate TOCTOU race.
    """
    # Guard: callers historically passed (company_id, task_id) by accident.
    # Company IDs start with 'GT_'; task IDs do not. Fail loud instead of silent no-op.
    if isinstance(task_id, str) and task_id.startswith("GT_"):
        raise ValueError(
            f"checkout_task called with company_id {task_id!r} as task_id. "
            "Signature is checkout_task(task_id, agent_id) — task_id FIRST."
        )

    # Recover any stale in-progress tasks before claiming
    _recover_stale_tasks_for_db(task_id)

    db = _get_db()
    try:
        cur = db.execute("""
            UPDATE company_issues
            SET status='in_progress', assignee_agent_id=?, started_at=datetime('now'), updated_at=datetime('now')
            WHERE id=? AND status IN ('backlog', 'todo', 'blocked')
        """, (agent_id, task_id))
        db.commit()

        if cur.rowcount == 0:
            # Either task doesn't exist or is already in_progress/done — fetch to disambiguate
            task = db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone()
            if not task:
                return {"error": "Task not found"}
            task = dict(task)
            if task["status"] == "in_progress":
                # Idempotent: same agent re-checking out their own task is fine.
                # Stash the thread-local so the harness can still link to it.
                if task["assignee_agent_id"] == agent_id:
                    _current_issue.id = task["id"]
                    _current_issue.company_id = task.get("company_id")
                    return task
                return {"error": "Task already claimed by another agent",
                        "claimed_by": task["assignee_agent_id"]}
            return {"error": f"Cannot claim task in status '{task['status']}'"}

        result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    except Exception:
        db.rollback()
        raise

    # Stash on thread-local so harness.execute can read it. Nested checkouts
    # shadow the previous one on the same thread — this is intentional.
    _current_issue.id = result["id"]
    _current_issue.company_id = result.get("company_id")

    # Emit company.task.checkout event — fire-and-forget
    try:
        from aibrain.core.event_bus import emit as _bus_emit, EventTypes as _ET
        _bus_emit(_ET.COMPANY_TASK_CHECKOUT, {
            "task_id": task_id,
            "agent_id": agent_id,
            "title": result.get("title", ""),
            "priority": result.get("priority", ""),
        }, actor=agent_id)
    except Exception:
        pass

    # Install worktree push-block hook if not already present
    try:
        import os as _os
        _hook_src = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))),
                                   'decker_system', '04_tools', 'git_hooks', 'pre-push')
        _hook_dst = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))),
                                   '.git', 'hooks', 'pre-push')
        if _os.path.exists(_hook_src) and not _os.path.exists(_hook_dst):
            import shutil as _shutil, stat as _stat
            _shutil.copy(_hook_src, _hook_dst)
            _os.chmod(_hook_dst, _os.stat(_hook_dst).st_mode | _stat.S_IEXEC | _stat.S_IXGRP | _stat.S_IXOTH)
    except Exception:
        pass

    return result


def complete_task_with_regen_dispatch(task_id, work_output="", max_regen_rounds=2, regen_on_stalemate=False, **kwargs):
    """F-DEEP-LIAISON-STALEMATE-REGEN-DISPATCH-1."""
    import sqlite3 as _sq3
    from aibrain.core.companies import complete_task as _ct
    if not regen_on_stalemate:
        return _ct(task_id, work_output=work_output, **kwargs)
    wo = work_output
    for rnd in range(1, max_regen_rounds + 1):
        try:
            return _ct(task_id, work_output=wo, **kwargs)
        except Exception as e:
            if rnd >= max_regen_rounds:
                raise
            db = _sq3.connect("aibrain.db"); db.row_factory = _sq3.Row
            row = db.execute("SELECT critique FROM liaison_critique_history WHERE task_id=? ORDER BY round DESC LIMIT 1", (task_id,)).fetchone()
            crit = row["critique"] if row else str(e)[:500]; db.close()
            log.warning("Regen round %d for %s", rnd, task_id)
            wo = wo + chr(10) + chr(10) + "[REGEN ROUND " + str(rnd) + ": " + str(crit[:200]) + "]"
    return _ct(task_id, work_output=wo, **kwargs)

def complete_task(task_id: str, quality_score: float = None, cost_cents: Optional[int] = None,
                  output: object = None, repo_path: str = None,
                  test_cmd: str = None, work_output: object = None,
                  require_verification: bool = True,
                  require_review: bool = False,
                  notes: str = None,
                  skip_liaison_review: bool = False,
                  skip_reason: Optional[str] = None,
                  retry_handler: Optional[Callable[[str, dict], str]] = None,
                  actor_agent_id: Optional[str] = None) -> dict:
    """Mark a task as done with honest quality evaluation AND verification.

    The caller-supplied quality_score is stored as self_score. The system
    runs automated checks to produce an independent eval_score. Both are
    recorded so divergence can be tracked over time.

    If ``work_output`` is supplied, the task goes through
    :func:`aibrain.core.task_verification.verify_and_complete` first:
      - Acceptance criteria are parsed from the task description.
      - Each criterion is checked against work_output.
      - Follow-up tasks are created for any gaps or TODO/follow-up hints.
      - If ``require_verification=True`` and verification fails, the task
        is NOT marked done; the verification result is returned instead.

    TWO-GATE ITERATION LOOP (task GahbnvK2buQ, 2026-04-24):

    When review is required (priority=high/critical, review_required=1, or
    require_review=True), completion goes through TWO gates in order:

      Gate 1 — DeepSeek pre-review (``pre_liaison_deepseek_review``):
        Cheap sanity check against the author's work_output vs task
        acceptance criteria.  Score < DS_GATE1_THRESHOLD (default 0.90)
        raises ``TaskDeepSeekGateFailed`` — caller must fix via DeepSeek
        and retry (zero Claude burn until Gate 1 passes).  Score >= 0.90
        falls through to Gate 2.

      Gate 2 — Claude Liaison (existing, unchanged):
        Authoritative primary gate.  PASS → task complete.  FAIL raises
        ``TaskReviewFailed`` — caller re-enters the loop, going back
        through Gate 1 on the next attempt.

    Kill-switch: review_round reaches ``MAX_RETRIES`` (default 20,
    ``DS_LOOP_MAX_RETRIES`` env var) → ``TaskKillSwitchOverflow``,
    task marked ``status='blocked'`` + ``terminal_state='needs_human_review'``.

    The return dict contains a ``token_cost`` key with six non-negative
    integer counters (``claude_calls``, ``claude_tokens_in``,
    ``claude_tokens_out``, ``deepseek_calls``, ``deepseek_tokens_in``,
    ``deepseek_tokens_out``) tracking the LLM spend of this specific call.

    Backward compat: if ``work_output`` is not supplied, behavior is
    unchanged except a debug warning is logged.

    Args:
        task_id: Task to complete.
        quality_score: Caller's self-assessment (stored as self_score, NOT used as final score).
        cost_cents: Cost of the work.
        output: Task output for automated quality checks (legacy param).
        repo_path: Git repo path for commit verification.
        test_cmd: Test command for test-pass verification.
        work_output: Structured completion output for acceptance-criteria verification.
        require_verification: If True and verification fails, refuse to mark done.
        require_review: If True, gates completion on Special Liaison review passing.
                        Tasks with priority=high or priority=critical auto-require review.
        notes: Optional free-text metadata stored in a dedicated ``notes`` column on
               ``company_issues``. Intended for supersession metadata such as
               "superseded by task <new_id>" when a task is renamed/restructured.
               The column is added idempotently on first use; callers that omit
               this kwarg see no change in behaviour.

    Forward-looking invariant (CSAw0mSJZME, 2026-04-25):

    .. code-block:: sql

        -- Should return 0 for tasks created >= 2026-04-26:
        SELECT COUNT(*) FROM company_issues
        WHERE status='done' AND quality_score < 0.87
          AND created_at >= '2026-04-26'
          AND work_output IS NOT NULL AND work_output != ''
          AND work_output != '[No work_output provided — verification skipped]'
    """
    from aibrain.core.harness import evaluate_task_quality

    # ─── Token-cost counters (task GahbnvK2buQ, 2026-04-24) ────────
    # Tracks every LLM call fired by complete_task() for the two-gate
    # iteration loop — claude_* for Gate 2 (existing Liaison), deepseek_*
    # for Gate 1 (new pre-review).  Returned on the result dict under
    # `token_cost` so callers can measure the Claude-burn reduction
    # delivered by Gate 1.  Non-negative integers by construction.
    _token_cost = {
        "claude_calls": 0,
        "claude_tokens_in": 0,
        "claude_tokens_out": 0,
        "deepseek_calls": 0,
        "deepseek_tokens_in": 0,
        "deepseek_tokens_out": 0,
    }

    # ─── Fix 1: Hard pre-condition — DB layer, not a flag ─────────
    # For high/critical tasks, output MUST be provided before any other
    # logic runs. This is not a flag the caller can toggle; it fires at
    # the application layer before the review gate, before quality eval,
    # before the DB write.
    #
    # Rationale: complete_task(task_id) with no output on a high/critical
    # task used to flow through to review_task() with an empty string, which
    # reliably returned FAIL — but that's a review failure, not a structural
    # rejection. The pattern the mandate identified is callers bypassing the
    # review entirely by catching TaskReviewFailed and retrying with a fake
    # output. The DB-layer guard eliminates that path: if priority is high
    # or critical and no output is provided, the call is dead on arrival.
    #
    # Falsifiability: verified by test_complete_task_hard_gate_no_output
    # (to be added). If that test passes, this guard is live.
    _priority_for_gate = "medium"
    try:
        _db_gate = _get_db()
        _gate_row = _db_gate.execute(
            "SELECT priority FROM company_issues WHERE id=?", (task_id,)
        ).fetchone()
        if _gate_row:
            _priority_for_gate = _gate_row["priority"] or "medium"
    except Exception as _gate_err:
        log.debug("priority pre-check failed (non-fatal): %s", _gate_err)

    if work_output is None and _priority_for_gate in ("high", "critical"):
        raise ValueError(
            f"complete_task({task_id}): work_output is required for {_priority_for_gate} tasks. "
            "Describe what was done and provide at least one verification result."
        )

    # ─── Medium/low tasks without work_output — stub + cap quality ─
    # Agents that call complete_task() without work_output on medium/low tasks
    # can still proceed, but we make the gap explicit and prevent inflated scores.
    _work_output_was_empty = not work_output or not str(work_output).strip()
    if work_output is None:
        work_output = "[No work_output provided — verification skipped]"
        if quality_score is not None and quality_score > 0.5:
            quality_score = 0.5
            log.warning(
                "complete_task(%s): quality_score capped at 0.5 — no work_output provided",
                task_id,
            )

    # ─── Vector 1: Block sub-0.87 no-output path (CSAw0mSJZME, 2026-04-25) ──
    # 442 of 547 sub-threshold tasks exploited the empty-output path: callers
    # passed quality_score < 0.87 with no work_output, bypassing the Liaison
    # gate because the gate only fires on non-empty output.  This guard closes
    # the bypass: empty work_output + quality_score < 0.87 is rejected hard
    # unless the caller explicitly opts out with skip_liaison_review=True.
    #
    # Does NOT affect:
    #   - quality_score=None (honest "could not measure") — None path unchanged
    #   - skip_liaison_review=True with valid skip_reason — carve-out preserved
    #   - quality_score >= 0.87 — no gate needed, caller self-assessed passing
    #
    # Falsifiability: SELECT COUNT(*) FROM company_issues WHERE status='done'
    # AND quality_score < 0.87 AND (work_output IS NULL OR work_output = '')
    # AND created_at >= '2026-04-26' should return 0 for tasks not using the
    # skip_liaison_review carve-out.
    if _work_output_was_empty and quality_score is not None and quality_score < GATE2_MIN_SCORE and not skip_liaison_review:
        raise TaskReviewFailed(
            f"Task {task_id}: quality_score={quality_score} < {GATE2_MIN_SCORE} but work_output is empty. "
            "Provide structured work_output (DONE/DIDN'T TOUCH/VERIFICATION/OPEN CONCERNS) "
            "or use skip_liaison_review=True with a valid skip_reason."
        )

    # ─── Special Liaison review gate ─────────────────────────────
    # Auto-require review for high/critical tasks even if caller didn't pass require_review=True.
    _review_output = work_output if work_output is not None else output
    _effective_require_review = require_review
    if not _effective_require_review:
        try:
            db = _get_db()
            task_row = db.execute(
                "SELECT priority, review_required FROM company_issues WHERE id=?", (task_id,)
            ).fetchone()
            if task_row:
                priority = task_row["priority"] or "medium"
                # Migration-safe: review_required column may not exist yet
                try:
                    review_flag = task_row["review_required"]
                except (IndexError, KeyError):
                    review_flag = 0
                if priority in ("high", "critical") or review_flag:
                    _effective_require_review = True
        except Exception as e:
            log.debug("review gate priority check failed (non-fatal): %s", e)

    _liaison_pass = False  # Initialised here so it is readable after the review gate block.

    # ─── Pre-Liaison verification gate ─────────────────────────────────────
    # Run live checks FIRST so SKIPPED/failed verify: lines abort before
    # the Liaison LLM fires. A check that cannot run is not a pass.
    _pre_verify_result = None
    _pre_verify_output = work_output if work_output is not None else output
    if _pre_verify_output is not None and not skip_liaison_review:
        try:
            from aibrain.core.task_verification import verify_and_complete as _pre_verify_fn
            _pre_verify_result = _pre_verify_fn(task_id, _pre_verify_output)
            if not _pre_verify_result["verified"]:
                _live = _pre_verify_result.get("live_checks", [])
                _has_skipped = any(r.get("skipped") for r in _live)
                _reason = "live_check_skipped" if _has_skipped else "verification_failed"
                log.warning(
                    "Task %s pre-Liaison verification %s (status=%s, gaps=%d) — "
                    "Liaison NOT called",
                    task_id,
                    _reason,
                    _pre_verify_result["verification_status"],
                    len(_pre_verify_result["gaps"]),
                )
                return {
                    "task_id": task_id,
                    "status": "not_completed",
                    "reason": _reason,
                    "verification": _pre_verify_result,
                    "token_cost": _token_cost,
                }
        except Exception as _pv_err:
            log.warning("Pre-Liaison verification check failed (non-fatal): %s", _pv_err)
    # ───────────────────────────────────────────────────────────────────────

    if _effective_require_review:
        # ── Kill-switch check (task GahbnvK2buQ, 2026-04-24) ─────────
        # review_round tracks retry count across both gates.  If it has
        # already reached MAX_RETRIES, skip BOTH gates, mark the task
        # terminally, and raise TaskKillSwitchOverflow.  Neither Gate 1
        # nor Gate 2 fires in this branch — by design — so no further
        # LLM burn is incurred for a task the loop could not resolve.
        _current_review_round = 0
        try:
            _db_kr = _get_db()
            _kr_row = _db_kr.execute(
                "SELECT review_round FROM company_issues WHERE id=?",
                (task_id,),
            ).fetchone()
            if _kr_row is not None:
                try:
                    _current_review_round = int(_kr_row["review_round"] or 0)
                except (IndexError, KeyError, TypeError, ValueError):
                    _current_review_round = 0
        except Exception as _kr_err:
            log.debug("kill-switch review_round check failed (non-fatal): %s", _kr_err)

        if _current_review_round >= MAX_GATE2_ATTEMPTS and not skip_liaison_review:
            # Terminal state — no auto-complete.  Mark task
            # status='needs_human_review' LITERALLY (spec criterion 7).
            # We also keep terminal_state='needs_human_review' as a
            # belt-and-braces signal so older consumers that look at
            # terminal_state still route correctly.
            try:
                _db_ks = _get_db()
                # Best-effort: ensure terminal_state column exists
                # (migration-safe).  aibrain production has it; tests may
                # not.
                try:
                    _db_ks.execute("ALTER TABLE company_issues ADD COLUMN terminal_state TEXT")
                    _db_ks.commit()
                except Exception:
                    pass
                # Extend the CHECK(status IN ...) constraint so the
                # literal 'needs_human_review' value is allowed.  Safe
                # no-op on DBs that have already been migrated.
                _migrate_company_issues_status_check()
                try:
                    _db_ks.execute(
                        "UPDATE company_issues "
                        "SET status='needs_human_review', "
                        "terminal_state='needs_human_review', "
                        "updated_at=datetime('now') WHERE id=?",
                        (task_id,),
                    )
                    _db_ks.commit()
                except sqlite3.IntegrityError:
                    # Migration could not run (rare — e.g. DB file
                    # opened read-only).  Fall back to the legacy pair
                    # (status='blocked', terminal_state=...) which is
                    # the accepted semantic before the rebuild lands.
                    log.warning(
                        "kill-switch: status CHECK extension not applied; "
                        "falling back to status='blocked' pair"
                    )
                    _db_ks.execute(
                        "UPDATE company_issues "
                        "SET status='blocked', terminal_state='needs_human_review', "
                        "updated_at=datetime('now') WHERE id=?",
                        (task_id,),
                    )
                    _db_ks.commit()
            except Exception as _mark_err:
                log.warning(
                    "kill-switch status update failed (non-fatal): %s", _mark_err,
                )
            try:
                record_liaison_verdict(
                    task_id,
                    verdict="FAIL",
                    score=0.0,
                    critique=(
                        f"KILL_SWITCH_OVERFLOW: review_round={_current_review_round} "
                        f">= MAX_GATE2_ATTEMPTS={MAX_GATE2_ATTEMPTS}.  Task marked needs_human_review."
                    ),
                    source="ds_pre_review",
                )
            except Exception as _rec_err:
                log.error(
                    "kill-switch record_liaison_verdict failed: %s",
                    _rec_err,
                )
                raise
            raise TaskKillSwitchOverflow(
                f"Task {task_id} exceeded MAX_GATE2_ATTEMPTS={MAX_GATE2_ATTEMPTS} "
                f"(review_round={_current_review_round}).  Marked "
                f"status='needs_human_review'.  Human intervention required."
            )

        # ── Gate 1: DeepSeek pre-review (task GahbnvK2buQ, 2026-04-24) ──
        # Internal regen loop (task wpoJ4D7EBbI, 2026-04-24): Gate 1 FAIL
        # and Gate 2 FAIL both invoke deepseek_regenerate_work_output with
        # the reviewer's critique; on regen success, the loop re-enters
        # Gate 1 with the revised work_output.  `_gate1_iters` caps
        # Gate-1-only inner iterations to prevent infinite DS churn.
        # `review_round` bumps ONLY on Gate-2 FAIL (spec criterion 2).
        # Exit conditions: Gate 2 PASS (falls through), MAX_GATE2_ATTEMPTS
        # exceeded (kill-switch, needs_human_review), regen unavailable
        # (raise TaskDeepSeekGateFailed / TaskReviewFailed for external
        # caller retry).
        _gate1_iters = 0
        # NOTE: regen loop is emulated via goto-style labels below.  On
        # Gate 1 FAIL → regen → `continue` to _two_gate_retry; on Gate 2
        # FAIL → regen → also `continue` to _two_gate_retry (which
        # re-reads review_round from the DB before re-entering Gate 1).
        while True:
         # `if not skip_liaison_review` body is at +1 space indent inside
         # this while — body-of-while-body indentation is valid Python.
         if not skip_liaison_review:
            # Check for existing PASS row — that's the only idempotent-replay
            # skip.  A prior FAIL does NOT skip Gate 1 (see header above).
            _prior_gate2_verdict = False
            try:
                _db_pre = _get_db()
                try:
                    _db_pre.execute("SELECT source FROM execution_log LIMIT 0")
                    _pre_has_source = True
                except Exception:
                    _pre_has_source = False
                if _pre_has_source:
                    _pre_row = _db_pre.execute(
                        """SELECT verdict, success FROM execution_log
                           WHERE entity_id=? AND actor='special_liaison'
                             AND verdict IS NOT NULL
                             AND COALESCE(source, 'agent_review') IN ('agent_review', 'champion_review')
                           ORDER BY created_at DESC LIMIT 1""",
                        (task_id,),
                    ).fetchone()
                else:
                    _pre_row = _db_pre.execute(
                        """SELECT verdict, success FROM execution_log
                           WHERE entity_id=? AND actor='special_liaison'
                             AND verdict IS NOT NULL
                           ORDER BY created_at DESC LIMIT 1""",
                        (task_id,),
                    ).fetchone()
                # Only a prior PASS is an idempotent-replay skip.  A prior
                # FAIL means the caller is retrying — Gate 1 MUST fire again.
                if _pre_row and _pre_row["verdict"] == "PASS" and _pre_row["success"] == 1:
                    _prior_gate2_verdict = True
            except Exception as _pre_err:
                log.debug("Gate 1 prior-verdict check failed (non-fatal): %s", _pre_err)

            if not _prior_gate2_verdict:
                _ds_work_str = str(_review_output) if _review_output is not None else ""
                _ds_task_desc: dict = {}
                try:
                    _db_td1 = _get_db()
                    _td1_row = _db_td1.execute(
                        "SELECT title, description, priority FROM company_issues WHERE id=?",
                        (task_id,),
                    ).fetchone()
                    if _td1_row:
                        _ds_task_desc = {
                            "title": _td1_row["title"] or "",
                            "description": _td1_row["description"] or "",
                            "priority": _td1_row["priority"] or "medium",
                        }
                except Exception as _td1_err:
                    log.debug("Gate 1 task fetch failed (non-fatal): %s", _td1_err)

                log.info(
                    "Task %s — Gate 1 DeepSeek pre-review (review_round=%d, threshold=%.2f)...",
                    task_id, _current_review_round, DS_GATE1_THRESHOLD,
                )

                _gate1_ok = True
                # F-GATE1-CONN-RELEASE-1 (2026-05-22): mirror Gate 2 pattern at
                # lines ~1749-1765. pre_liaison_deepseek_review calls
                # _deepseek_http_call which urlopens with timeout=120 and up to
                # 3 retries — worst case ~134s with the lock held. Release the
                # thread-local DB conn FIRST so other writers (Lucy pricing,
                # broker, fleet listeners) are not blocked. Lock-investigator
                # candidate #2.
                try:
                    _pre_g1_conn = getattr(_db_pool, "conn", None)
                    if _pre_g1_conn is not None:
                        _pre_g1_conn.close()
                        _db_pool.conn = None
                        with _pool_lock:
                            _thread_conns.pop(threading.get_ident(), None)
                except Exception as _g1_conn_reset_err:
                    log.debug(
                        "DB connection reset before Gate 1 DeepSeek call failed (non-fatal): %s",
                        _g1_conn_reset_err,
                    )
                try:
                    _ds_result = pre_liaison_deepseek_review(
                        task_id=task_id,
                        work_output=_ds_work_str,
                        task_desc=_ds_task_desc,
                    )
                except (LiaisonCLIUnavailable, LiaisonReviewCallFailed) as _g1_err:
                    log.warning(
                        "Task %s — Gate 1 DeepSeek unavailable/failed (%s). "
                        "Skipping Gate 1, proceeding directly to Gate 2.",
                        task_id, _g1_err,
                    )
                    _gate1_ok = False

                if _gate1_ok:
                    # Update token-cost counters (Gate 1 always bumps deepseek_*).
                    _token_cost["deepseek_calls"] += 1
                    _token_cost["deepseek_tokens_in"] += int(_ds_result.get("tokens_in", 0))
                    _token_cost["deepseek_tokens_out"] += int(_ds_result.get("tokens_out", 0))

                    # Always record the Gate 1 verdict (audit only).
                    try:
                        record_liaison_verdict(
                            task_id,
                            verdict=_ds_result["verdict"],
                            score=_ds_result["score"],
                            critique=_ds_result["critique"],
                            source="ds_pre_review",
                        )
                    except Exception as _rec1_err:
                        log.error(
                            "record_liaison_verdict (ds_pre_review) failed: %s",
                            _rec1_err,
                        )
                        raise

                    if _ds_result["score"] < DS_GATE1_THRESHOLD:
                        # Gate 1 FAIL — do NOT increment review_round (criterion 2:
                        # review_round bumps ONLY on Gate-2 FAIL).  Attempt internal
                        # regen via DS generator using the DS critique; on success,
                        # loop back to Gate 1 with the revised work_output.  On
                        # regen unavailability (no DEEPSEEK_API_KEY, network
                        # error), raise TaskDeepSeekGateFailed so the external
                        # caller can retry.  _gate1_iters caps this inner loop.
                        log.info(
                            "Task %s — Gate 1 FAIL (score=%.2f < %.2f, review_round=%d, gate1_iter=%d)",
                            task_id, _ds_result["score"], DS_GATE1_THRESHOLD,
                            _current_review_round, _gate1_iters,
                        )
                        if _gate1_iters + 1 >= MAX_GATE1_ITERATIONS_PER_GATE2:
                            raise TaskDeepSeekGateFailed(
                                f"Gate 1 (DeepSeek pre-review) FAILED for task {task_id} "
                                f"and Gate-1 iteration budget exhausted "
                                f"(gate1_iters={_gate1_iters + 1} >= "
                                f"{MAX_GATE1_ITERATIONS_PER_GATE2}, "
                                f"score={_ds_result['score']:.2f} < "
                                f"{DS_GATE1_THRESHOLD:.2f}): {_ds_result['critique']}",
                                critique=_ds_result["critique"],
                                score=_ds_result["score"],
                                review_round=_current_review_round,
                            )
                        if retry_handler is not None:
                            _handler_ctx = {
                                "task_id": task_id,
                                "title": _ds_task_desc.get("title", ""),
                                "description": _ds_task_desc.get("description", ""),
                                "priority": _ds_task_desc.get("priority", "medium"),
                                "review_round": _current_review_round,
                                "gate": 1,
                            }
                            try:
                                _handler_output = retry_handler(_ds_result["critique"], _handler_ctx)
                            except Exception as _h1_err:
                                raise HandlerExecutionFailed(
                                    f"Gate 1 retry_handler raised for task {task_id}: {_h1_err}"
                                ) from _h1_err
                            _review_output = _handler_output
                            work_output = _handler_output
                            _gate1_iters += 1
                            log.info(
                                "Task %s — Gate 1 retry_handler succeeded (gate1_iter=%d), re-entering Gate 1",
                                task_id, _gate1_iters,
                            )
                            continue  # re-enter the outer while loop → Gate 1
                        try:
                            _regen = deepseek_regenerate_work_output(
                                task_id=task_id,
                                prior_work_output=_ds_work_str,
                                critique=_ds_result["critique"],
                                gate="gate1",
                                task_desc=_ds_task_desc,
                            )
                            _token_cost["deepseek_calls"] += 1
                            _token_cost["deepseek_tokens_in"] += int(_regen.get("tokens_in", 0))
                            _token_cost["deepseek_tokens_out"] += int(_regen.get("tokens_out", 0))
                            _review_output = _regen["work_output"]
                            work_output = _regen["work_output"]
                            _gate1_iters += 1
                            log.info(
                                "Task %s — Gate 1 regen succeeded (gate1_iter=%d), re-entering Gate 1",
                                task_id, _gate1_iters,
                            )
                            continue  # re-enter the outer while loop → Gate 1
                        except (LiaisonCLIUnavailable, LiaisonReviewCallFailed) as _regen_err:
                            log.info(
                                "Task %s — Gate 1 regen unavailable (%s), raising TaskDeepSeekGateFailed",
                                task_id, _regen_err,
                            )
                            raise TaskDeepSeekGateFailed(
                                f"Gate 1 (DeepSeek pre-review) FAILED for task {task_id} "
                                f"(score={_ds_result['score']:.2f} < threshold "
                                f"{DS_GATE1_THRESHOLD:.2f}, review_round={_current_review_round}): "
                                f"{_ds_result['critique']}",
                                critique=_ds_result["critique"],
                                score=_ds_result["score"],
                                review_round=_current_review_round,
                            )

                    # Gate 1 PASS — fall through to Gate 2.
                    log.info(
                        "Task %s — Gate 1 PASS (score=%.2f >= %.2f), proceeding to Gate 2",
                        task_id, _ds_result["score"], DS_GATE1_THRESHOLD,
                    )

         # ── Gate 2: existing Claude Liaison (unchanged below) ─────────
         # ── New architecture (V2): check for Agent-based liaison verdict ──
         # review_task() (regex checks) is now a PRE-FILTER only, called by
         # Neuro before spawning the real Agent-based review. The completion
         # gate checks execution_log for a PASS verdict written by
         # record_liaison_verdict() AFTER the Agent tool review ran.
         #
         # Flow:
         #   1. Neuro calls review_task(task_id, output) — regex pre-filter
         #   2. Neuro spawns Agent tool with Special Liaison persona
         #   3. Agent returns verdict; Neuro calls record_liaison_verdict()
         #   4. complete_task() sees the PASS row here and proceeds
         #
         # If no PASS row exists → TaskReviewFailed (forces proper review first).
         # Most-recent-verdict-wins semantics: a later FAIL must override an
         # earlier PASS. Previously this query filtered success=1, which caused
         # the gate to return the most recent PASS while silently ignoring a
         # subsequent FAIL (bug surfaced on task Iy80OK0PLa0).
         _liaison_pass = False
         _liaison_score = None
         try:
             _db_liaison = _get_db()
             # Source-tag gate (sC9X5a7ytaY, 2026-04-19): only rows written by
             # a legitimate Agent-based review clear the gate. pre_filter and
             # self_recorded rows stay in the audit trail but are informational.
             #
             # Gate-clearing sources (most-recent-verdict-wins within each source):
             #   - 'agent_review'    — legacy Special Liaison Agent tool verdict
             #   - 'champion_review' — Champion primary gate reviewer (2026-04-21)
             #
             # Non-clearing sources (audit only): pre_filter, self_recorded,
             #   skipped_with_reason, liaison_shadow.
             #
             # Most-recent-verdict-wins semantics preserved: we pick the latest
             # row by created_at across all gate-clearing sources, so a later
             # FAIL overrides an earlier PASS.
             try:
                 _db_liaison.execute("SELECT source FROM execution_log LIMIT 0")
                 _has_source_col = True
             except Exception:
                 _has_source_col = False

             if _has_source_col:
                 _liaison_row = _db_liaison.execute(
                     """SELECT verdict, success, quality_score,
                               COALESCE(source, 'agent_review') AS source
                        FROM execution_log
                        WHERE entity_id=? AND actor='special_liaison'
                          AND verdict IS NOT NULL
                          AND COALESCE(source, 'agent_review') IN ('agent_review', 'champion_review')
                        ORDER BY created_at DESC LIMIT 1""",
                     (task_id,),
                 ).fetchone()
             else:
                 # Legacy DB: behave as pre-sC9X5a7ytaY (no gaming protection).
                 _liaison_row = _db_liaison.execute(
                     """SELECT verdict, success, quality_score FROM execution_log
                        WHERE entity_id=? AND actor='special_liaison'
                          AND verdict IS NOT NULL
                        ORDER BY created_at DESC LIMIT 1""",
                     (task_id,),
                 ).fetchone()
             if _liaison_row and _liaison_row["verdict"] == "PASS" and _liaison_row["success"] == 1 and (_liaison_row["quality_score"] or 0) >= GATE2_MIN_SCORE:
                 _liaison_pass = True
                 _liaison_score = _liaison_row["quality_score"]
         except Exception as _ck_err:
             log.debug("Liaison verdict check failed (non-fatal): %s", _ck_err)

         if not _liaison_pass:
             # ── CODEX-AS-PRIMARY-GATE (2026-04-22) ──
             # Architecture:
             #   1. Codex (former Special Liaison, promoted via Karpathy loop
             #      + McKee gate 2026-04-22) is the primary gate reviewer.
             #      Codex PASS → task proceeds. Codex FAIL → TaskReviewFailed.
             #   2. Blind Liaison shadow dropped — Codex IS the Liaison now,
             #      so self-shadowing added no signal. Can be reinstated if
             #      calibration need surfaces.
             #   3. Existing source='agent_review' and source='champion_review'
             #      PASS rows continue to clear the gate (backward-compat with
             #      pre-Codex Liaison and pre-Codex intel_agent-Champion eras).
             #
             # Skip carve-out: skip_liaison_review=True with skip_reason bypasses
             # the primary gate entirely (audited via skipped_with_reason row).
             if skip_liaison_review:
                 assert skip_reason, (
                     "skip_liaison_review=True requires skip_reason kwarg. "
                     "Valid reasons: 'one-shot diagnostic command', "
                     "'single-line fix', 'sub-task under reviewed parent', "
                     "'conversation response'."
                 )
                 # Audit the skip — source='skipped_with_reason', critique
                 # captures the reason. Informational row, never clears a
                 # gate on other tasks (source-tag semantics preserved).
                 try:
                     record_liaison_verdict(
                         task_id,
                         verdict="PASS",
                         score=0.0,
                         critique=f"SKIP: {skip_reason}",
                         source="skipped_with_reason",
                     )
                 except Exception as _rec_err:
                     log.error(
                         "skip_liaison_review audit write failed: %s",
                         _rec_err,
                     )
                     raise
                 log.info(
                     "Task %s review SKIPPED — reason: %s",
                     task_id, skip_reason,
                 )
                 # Fall through to the rest of complete_task with no
                 # quality_score adjustment.
             else:
                 # Fetch task fields once so we don't double-read the DB inside
                 # the callable.
                 _task_desc_for_review: dict = {}
                 try:
                     _db_td = _get_db()
                     _td_row = _db_td.execute(
                         "SELECT title, description, priority FROM company_issues WHERE id=?",
                         (task_id,),
                     ).fetchone()
                     if _td_row:
                         _task_desc_for_review = {
                             "title": _td_row["title"] or "",
                             "description": _td_row["description"] or "",
                             "priority": _td_row["priority"] or "medium",
                         }
                 except Exception as _td_err:
                     log.debug("task fetch for inline review failed (non-fatal): %s", _td_err)

                 _work_str = str(_review_output) if _review_output is not None else ""

                 # Release the thread-local DB connection before the long claude CLI
                 # subprocess wait. The connection can be closed/GC'd during a 2-5 min
                 # block; releasing here guarantees _get_db() creates a fresh connection
                 # when record_liaison_verdict is called after the subprocess returns.
                 try:
                     _pre_review_conn = getattr(_db_pool, "conn", None)
                     if _pre_review_conn is not None:
                         _pre_review_conn.close()
                         _db_pool.conn = None
                         with _pool_lock:
                             # SA-2026-002 F-27: remove from _thread_conns (was _all_pool_conns)
                             _thread_conns.pop(threading.get_ident(), None)
                 except Exception as _conn_reset_err:
                     log.debug(
                         "DB connection reset before Liaison subprocess failed (non-fatal): %s",
                         _conn_reset_err,
                     )

                 # ── Primary gate: LIAISON_PROVIDER registry routing ──
                 # Each agent sets LIAISON_PROVIDER in their own env file.
                 # Registry (_LIAISON_PROVIDER_CALLABLES) maps provider →
                 # callable; adding a new provider is one function + one dict
                 # entry, nothing else. Default (unset or 'claude') keeps the
                 # Claude CLI path.
                 _liaison_provider = _os.environ.get("LIAISON_PROVIDER", "claude").lower()
                 if _liaison_provider in _LIAISON_PROVIDER_CALLABLES:
                     log.info(
                         "Task %s — LIAISON_PROVIDER=%s: calling %s Liaison "
                         "directly (skipping Claude CLI).",
                         task_id, _liaison_provider, _liaison_provider,
                     )
                     _champion_result = _LIAISON_PROVIDER_CALLABLES[_liaison_provider](
                         task_id, _work_str, _task_desc_for_review
                     )
                 else:
                     # ── Primary gate: Codex review via claude CLI ──
                     log.info(
                         "Task %s — invoking inline Codex primary review via claude "
                         "CLI (synchronous, 2-5 min expected)...",
                         task_id,
                     )
                     # LiaisonReviewCallFailed propagates as a hard failure.
                     # LiaisonCLIUnavailable (not-logged-in or CLI missing) falls
                     # back to DeepSeek Gate 2 so the flow works for end users
                     # who install aibrain via pip without Claude CLI auth.
                     try:
                         _champion_result = claude_liaison_review_callable(
                             task_id=task_id,
                             work_output=_work_str,
                             task_desc=_task_desc_for_review,
                             persona_override=_load_champion_persona(),
                         )
                         # Claude call fired — bump counter.
                         _token_cost["claude_calls"] += 1
                     except LiaisonCLIUnavailable as _g2_unavail:
                         # Claude CLI not available or not authenticated.
                         # Fall back to DeepSeek for Gate 2 so users who installed
                         # aibrain via pip (without Claude Code auth) still get
                         # two-gate review via DeepSeek.
                         # LiaisonReviewCallFailed (unparseable output) propagates
                         # as a hard failure — it is not a recoverable fallback case.
                         log.info(
                             "Task %s — Gate 2 Claude CLI unavailable (%s). "
                             "Falling back to DeepSeek for Gate 2.",
                             task_id, _g2_unavail,
                         )
                         _ds_g2 = pre_liaison_deepseek_review(
                             task_id=task_id,
                             work_output=_work_str,
                             task_desc=_task_desc_for_review,
                             model="deepseek-v4-pro",
                             timeout_s=180,
                             thinking=True,
                         )
                         _champion_result = {
                             "verdict": _ds_g2["verdict"],
                             "score": _ds_g2["score"],
                             "critique": f"[DeepSeek Gate 2 fallback] {_ds_g2['critique']}",
                             "duration_s": _ds_g2.get("duration_s", 0),
                             "raw_stdout_chars": 0,
                         }
                 # Record Codex verdict. Written under source='champion_review'
                 # for backward-compat with the previous gate-source-tag regime;
                 # this tag is gate-clearing regardless of the current persona
                 # behind it (see VALID_LIAISON_SOURCES comment).
                 try:
                     record_liaison_verdict(
                         task_id,
                         verdict=_champion_result["verdict"],
                         score=_champion_result["score"],
                         critique=_champion_result["critique"],
                         source="champion_review",
                     )
                 except Exception as _rec_err:
                     log.error(
                         "record_liaison_verdict (primary gate) failed after inline review: %s",
                         _rec_err,
                     )
                     raise

                 # Blind Liaison shadow dropped 2026-04-22 with the Codex
                 # gate swap. Can be reinstated here if calibration data
                 # ever proves needed.

                 # ── Gate decision — primary reviewer (Codex) verdict is authoritative ──
                 # Sub-threshold PASS is treated as FAIL: a PASS verdict with
                 # score < GATE2_MIN_SCORE (0.87) does NOT clear the gate. The
                 # cached-row path (line ~1675) already enforces this bar; the
                 # fresh-review path previously only checked verdict=="FAIL",
                 # letting PASS@<0.87 (e.g. batch1 PASS@0.82) reach status=done.
                 # quality_score=None → 0 → sub-threshold → FAIL (conservative:
                 # an unmeasurable review cannot be confirmed to meet the bar).
                 _champion_below_bar = (_champion_result.get("score") or 0) < GATE2_MIN_SCORE
                 if _champion_result["verdict"] == "FAIL" or _champion_below_bar:
                     # Gate 2 FAIL — bump review_round (criterion 2:
                     # review_round bumps ONLY here), then attempt DS regen
                     # with the Claude critique and re-enter the loop.  On
                     # regen unavailability, raise TaskReviewFailed so the
                     # external caller can retry.  Kill-switch at loop top
                     # catches MAX_GATE2_ATTEMPTS overflow.
                     _new_round_g2 = _current_review_round + 1
                     try:
                         _db_inc2 = _get_db()
                         _db_inc2.execute(
                             "UPDATE company_issues SET review_round=?, updated_at=datetime('now') "
                             "WHERE id=?",
                             (_new_round_g2, task_id),
                         )
                         _db_inc2.commit()
                     except Exception as _inc2_err:
                         log.warning(
                             "Gate 2 review_round increment failed (non-fatal): %s",
                             _inc2_err,
                         )
                     _current_review_round = _new_round_g2
                     log.info(
                         "Task %s — Gate 2 FAIL (score=%.2f, review_round=%d)",
                         task_id, float(_champion_result.get("score") or 0), _new_round_g2,
                     )
                     # Kill-switch: if we've hit the cap with this FAIL,
                     # set status 'blocked_review_stalemate', alert Decker via
                     # Telegram with the last 3 critiques, and raise
                     # ReviewStalemateBlocked (no further automated retries).
                     if _new_round_g2 >= MAX_GATE2_ATTEMPTS:
                         try:
                             _db_ks3 = _get_db()
                             _migrate_company_issues_status_check()
                             try:
                                 _db_ks3.execute(
                                     "UPDATE company_issues SET status='blocked_review_stalemate', "
                                     "terminal_state='blocked_review_stalemate', "
                                     "updated_at=datetime('now') WHERE id=?",
                                     (task_id,),
                                 )
                                 _db_ks3.commit()
                             except sqlite3.IntegrityError:
                                 _db_ks3.execute(
                                     "UPDATE company_issues SET status='blocked', "
                                     "terminal_state='blocked_review_stalemate', "
                                     "updated_at=datetime('now') WHERE id=?",
                                     (task_id,),
                                 )
                                 _db_ks3.commit()
                         except Exception as _mk_err:
                             log.warning("Gate-2 kill-switch mark failed (non-fatal): %s", _mk_err)
                         # Gather last 3 FAIL critiques from execution_log
                         _critiques: list = []
                         try:
                             _db_ks4 = _get_db()
                             _crit_rows = _db_ks4.execute(
                                 "SELECT critique FROM execution_log WHERE entity_id=? "
                                 "AND actor='special_liaison' AND success=0 ORDER BY id DESC LIMIT 3",
                                 (task_id,),
                             ).fetchall()
                             _critiques = [r[0] or "" for r in _crit_rows]
                             _db_ks4.close()
                         except Exception:
                             _critiques = []
                         # Build and send Telegram alert
                         _tg_lines = [
                             f"REVIEW STALEMATE — task {task_id}",
                             f"Rounds: {_new_round_g2} FAILs, task paused",
                         ]
                         for _ci, _cc in enumerate(_critiques, 1):
                             _tg_lines.append(f"Round {_ci}: {_cc[:200]}")
                         _tg_lines.append(
                             "Unblock: override_task / reassign_task / rescope_task / abandon_task"
                         )
                         try:
                             from aibrain.core.reactive_chains import _send_telegram
                             _send_telegram("\n".join(_tg_lines))
                         except Exception as _tg_err:
                             log.warning("Telegram stalemate alert failed (non-fatal): %s", _tg_err)
                         try:
                             record_liaison_verdict(
                                 task_id, verdict="FAIL", score=0.0,
                                 critique=(
                                     f"STALEMATE: review_round={_new_round_g2} "
                                     f">= MAX_GATE2_ATTEMPTS={MAX_GATE2_ATTEMPTS}. "
                                     "follow-up: use override_task/reassign_task/rescope_task/abandon_task to unblock"
                                 ),
                                 source="ds_pre_review",
                             )
                         except Exception as _rec_ks2_err:
                             log.error("record_liaison_verdict (gate-2 kill-switch) failed: %s", _rec_ks2_err)
                             raise
                         raise ReviewStalemateBlocked(
                             f"Task {task_id} exceeded MAX_GATE2_ATTEMPTS={MAX_GATE2_ATTEMPTS} "
                             f"(review_round={_new_round_g2}). Status set to 'blocked_review_stalemate'. "
                             f"Unblock with override_task, reassign_task, rescope_task, or abandon_task."
                         )
                     # Try retry_handler first; fall back to text-only DS regen.
                     if retry_handler is not None:
                         _handler_ctx2 = {
                             "task_id": task_id,
                             "title": _task_desc_for_review.get("title", ""),
                             "description": _task_desc_for_review.get("description", ""),
                             "priority": _task_desc_for_review.get("priority", "medium"),
                             "review_round": _new_round_g2,
                             "gate": 2,
                         }
                         try:
                             _handler_output2 = retry_handler(_champion_result["critique"], _handler_ctx2)
                         except Exception as _h2_err:
                             raise HandlerExecutionFailed(
                                 f"Gate 2 retry_handler raised for task {task_id}: {_h2_err}"
                             ) from _h2_err
                         _review_output = _handler_output2
                         work_output = _handler_output2
                         _gate1_iters = 0  # reset Gate-1 budget per Gate-2 attempt
                         log.info(
                             "Task %s — Gate 2 retry_handler succeeded, re-entering Gate 1",
                             task_id,
                         )
                         continue  # re-enter the while loop → Gate 1
                     # Try internal regen with Claude critique.
                     try:
                         _g2_regen = deepseek_regenerate_work_output(
                             task_id=task_id,
                             prior_work_output=_work_str,
                             critique=_champion_result["critique"],
                             gate="gate2",
                             task_desc=_task_desc_for_review,
                         )
                         _token_cost["deepseek_calls"] += 1
                         _token_cost["deepseek_tokens_in"] += int(_g2_regen.get("tokens_in", 0))
                         _token_cost["deepseek_tokens_out"] += int(_g2_regen.get("tokens_out", 0))
                         _review_output = _g2_regen["work_output"]
                         work_output = _g2_regen["work_output"]
                         _gate1_iters = 0  # reset Gate-1 budget per Gate-2 attempt
                         log.info(
                             "Task %s — Gate 2 regen succeeded, re-entering Gate 1",
                             task_id,
                         )
                         continue  # re-enter the while loop → Gate 1
                     except (LiaisonCLIUnavailable, LiaisonReviewCallFailed) as _g2_regen_err:
                         log.info(
                             "Task %s — Gate 2 regen unavailable (%s), raising TaskReviewFailed",
                             task_id, _g2_regen_err,
                         )
                         raise TaskReviewFailed(
                             f"Inline Codex primary review FAILED for task {task_id} "
                             f"(score={_champion_result['score']:.2f}, "
                             f"duration={_champion_result.get('duration_s', 0)}s, "
                             f"review_round={_new_round_g2}): "
                             f"{_champion_result['critique']}"
                         )

                 # PASS path — enforce score threshold before accepting.
                 # Mirrors the idempotent-replay check at line 1576: both must require score >= GATE2_MIN_SCORE.
                 if _champion_result["score"] < GATE2_MIN_SCORE:
                     log.warning(
                         "Task %s — Gate 2 PASS rejected: score %.2f < threshold %.2f — treating as FAIL for regen",
                         task_id, _champion_result["score"], GATE2_MIN_SCORE,
                     )
                     _champion_result["verdict"] = "FAIL"
                     _champion_result["critique"] = (
                         f"[Score {_champion_result['score']:.2f} below threshold {GATE2_MIN_SCORE} — PASS rejected] "
                         + _champion_result.get("critique", "")
                     )
                     # Increment review_round so the kill-switch fires after MAX_GATE2_ATTEMPTS.
                     # Without this, the bare continue below bypasses the FAIL branch that normally
                     # increments review_round, leaving it 0 forever (infinite loop — task Wt5bNdOwzKQ
                     # looped 12+ times before being manually killed).
                     _rpr_new = _current_review_round + 1
                     try:
                         _db_rpr = _get_db()
                         _db_rpr.execute(
                             "UPDATE company_issues SET review_round=?, updated_at=datetime('now') WHERE id=?",
                             (_rpr_new, task_id),
                         )
                         _db_rpr.commit()
                     except Exception as _rpr_err:
                         log.warning("PASS-rejected review_round increment failed (non-fatal): %s", _rpr_err)
                     _current_review_round = _rpr_new
                     if _rpr_new >= MAX_GATE2_ATTEMPTS:
                         try:
                             _db_rpr2 = _get_db()
                             _migrate_company_issues_status_check()
                             try:
                                 _db_rpr2.execute(
                                     "UPDATE company_issues SET status='blocked_review_stalemate', "
                                     "terminal_state='blocked_review_stalemate', "
                                     "updated_at=datetime('now') WHERE id=?",
                                     (task_id,),
                                 )
                                 _db_rpr2.commit()
                             except sqlite3.IntegrityError:
                                 _db_rpr2.execute(
                                     "UPDATE company_issues SET status='blocked', "
                                     "terminal_state='blocked_review_stalemate', "
                                     "updated_at=datetime('now') WHERE id=?",
                                     (task_id,),
                                 )
                                 _db_rpr2.commit()
                         except Exception as _rpr3_err:
                             log.warning("PASS-rejected kill-switch mark failed (non-fatal): %s", _rpr3_err)
                         raise ReviewStalemateBlocked(
                             f"Task {task_id} exceeded MAX_GATE2_ATTEMPTS={MAX_GATE2_ATTEMPTS} "
                             f"(review_round={_rpr_new}, PASS-rejected path). "
                             "Status set to 'blocked_review_stalemate'."
                         )
                     continue  # re-enter loop; FAIL branch handles regen on next iteration
                 _liaison_pass = True
                 _liaison_score = _champion_result["score"]
                 log.info(
                     "Task %s — Codex primary review PASS (score=%.2f, duration=%.1fs)",
                     task_id, _champion_result["score"], _champion_result.get("duration_s", 0.0),
                 )

         # End of two-gate block — exit the retry loop.  Reached on:
         # Gate 2 PASS, prior-PASS idempotent replay, or skip_liaison_review.
         break

        # PASS confirmed — use review score as quality_score if caller didn't supply one
        if quality_score is None and _liaison_score is not None:
            quality_score = _liaison_score

    # ─── Verification step (backward-compat path) ─────────────
    # Only runs if pre-Liaison verification didn't already run
    # (i.e. skip_liaison_review=True or no work_output on that path).
    verification_result = _pre_verify_result  # may be None
    effective_work_output = work_output if work_output is not None else output
    if effective_work_output is not None and verification_result is None:
        try:
            from aibrain.core.task_verification import verify_and_complete as _verify
            verification_result = _verify(task_id, effective_work_output)
            if require_verification and not verification_result["verified"]:
                # Do NOT mark done — return verification result with gaps.
                # Do NOT clear the thread-local: the task is still checked
                # out and further harness calls on this thread should still
                # link to it.
                log.warning(
                    "Task %s verification FAILED (status=%s, gaps=%d, follow_ups=%d) — "
                    "not marking complete",
                    task_id,
                    verification_result["verification_status"],
                    len(verification_result["gaps"]),
                    len(verification_result["follow_up_tasks"]),
                )
                return {
                    "task_id": task_id,
                    "status": "not_completed",
                    "reason": "verification_failed",
                    "verification": verification_result,
                    "token_cost": _token_cost,
                }
        except Exception as e:
            log.warning("Verification step failed (non-fatal): %s", e)
    else:
        log.debug(
            "complete_task(%s) called without work_output — "
            "verify-and-followup skipped (backward compat)",
            task_id,
        )

    # Run honest evaluation
    checks_to_run = ["output_no_error", "output_substantive"]
    if repo_path:
        checks_to_run.append("git_committed")
    if test_cmd:
        checks_to_run.append("tests_pass")

    eval_result = evaluate_task_quality(
        output=output,
        task_name=f"task:{task_id}",
        self_score=quality_score,
        run_checks=checks_to_run,
        repo_path=repo_path,
        test_cmd=test_cmd,
    )

    eval_score = eval_result["eval_score"]
    verified = eval_result["verified"]
    flagged = eval_result["flagged"]

    # If no output provided and no automated checks possible, mark as unverified
    # and use self_score if provided, otherwise mark as unknown
    if output is None and quality_score is not None:
        final_score = quality_score
        verified = False
    elif output is None and quality_score is None:
        final_score = None
        verified = False
    else:
        final_score = eval_score

    # ─── Vector 2: Floor stored quality_score to 0.87 after Liaison PASS ──
    # (CSAw0mSJZME, 2026-04-25)
    #
    # Problem: evaluate_task_quality() may return an eval_score below 0.87
    # even after a confirmed Liaison PASS, because the harness and Liaison
    # use independent scoring rubrics.  The gate passed — the work was
    # reviewed and approved — but the DB record shows quality_score < 0.87,
    # which means the invariant query (see docstring) would count this task
    # as a violation even though the gate was correctly exercised.
    #
    # Fix: if a Liaison PASS was confirmed in this call, floor the stored
    # quality_score to the gate threshold (0.87) so the DB invariant holds.
    #
    # Does NOT affect:
    #   - Tasks that did not go through the Liaison gate (_liaison_pass=False)
    #   - final_score=None (unmeasured tasks) — None is preserved as-is
    #   - Tasks where eval already scored >= 0.87 — floor is a no-op
    #
    # Falsifiability: after this fix, SELECT COUNT(*) FROM company_issues
    # WHERE status='done' AND quality_score < 0.87 AND created_at >= '2026-04-26'
    # should return 0 for tasks that went through the review gate.
    if _liaison_pass and final_score is not None and final_score < 0.87:
        log.debug(
            "complete_task(%s): final_score=%.3f floored to 0.87 after Liaison PASS",
            task_id, final_score,
        )
        final_score = 0.87

    # ─── Fix 2: Reject explicitly fabricated zero quality scores ──
    # A caller who passes quality_score=0.0 is either reporting a failed task
    # (which should not be marked done) or fabricating a placeholder. Either
    # way, storing quality_score=0.0 for a completed task is dishonest —
    # it pollutes the quality signal and looks identical to "no measurement."
    #
    # This guard rejects only the case where:
    #   (a) caller explicitly passed quality_score=0.0, AND
    #   (b) no real eval_score was measured from output (output is None)
    #
    # It does NOT reject quality_score=None (honest "could not measure") —
    # that's the correct value when no output was provided for a low-priority
    # task. The honest-rubric design explicitly supports NULL for unmeasurable
    # tasks. Only fabricated zeros are rejected.
    #
    # Falsifiability: SELECT COUNT(*) FROM company_issues WHERE status='done'
    # AND quality_score = 0.0 AND eval_score IS NULL should return 0 after
    # all calls pass through this guard.
    if quality_score is not None and quality_score == 0.0 and output is None:
        raise TaskReviewFailed(
            f"Task {task_id}: quality_score=0.0 with no output is rejected. "
            f"A score of 0.0 on a completed task is either a fabricated placeholder "
            f"or a failed task (which should not be marked done). "
            f"Either provide output so the system can measure quality honestly, "
            f"or omit quality_score (None = 'could not measure' is acceptable)."
        )

    # ── Bypass lockdown (bpQ2eHCPngk, 2026-04-25) ──────────────────────
    # skip_liaison_review=True requires documented reason. Undocumented skips
    # enabled yesterday's fabricated closures.
    if skip_liaison_review:
        if not skip_reason or not str(skip_reason).strip():
            raise AssertionError(
                f"Task {task_id}: skip_liaison_review=True requires a non-empty skip_reason. "
                "Valid reasons: 'one-shot diagnostic command', 'single-line fix', "
                "'sub-task under reviewed parent', 'conversation response'."
            )
        # ── CEO-class guard (actor_agent_id check) ──────────────────────────
        # skip_liaison_review is reserved for CEO-class agents (role='ceo').
        # If actor_agent_id is provided, look up the role and block non-CEOs.
        # If actor_agent_id is None, allow silently (backward compat — existing
        # callers that predate this kwarg are treated as trusted orchestrators).
        if actor_agent_id is not None:
            try:
                _role_db = _get_db()
                _role_row = _role_db.execute(
                    "SELECT role FROM company_agents WHERE id=?", (actor_agent_id,)
                ).fetchone()
                _agent_role = _role_row["role"] if _role_row else None
            except Exception as _role_err:
                log.warning("CEO role check failed (non-fatal for DB errors): %s", _role_err)
                _agent_role = None
            if _agent_role is not None and _agent_role != "ceo":
                raise SkipNotPermitted(
                    f"skip_liaison_review is CEO-class only. "
                    f"Agent {actor_agent_id} has role={_agent_role}."
                )
        try:
            import secrets as _sl_secrets
            _bypass_db = _get_db()
            try:
                _bypass_db.execute("ALTER TABLE execution_log ADD COLUMN text_id TEXT")
                _bypass_db.commit()
            except Exception:
                pass
            _bypass_db.execute(
                "INSERT INTO execution_log "
                "(text_id, run_id, actor, action, entity_type, entity_id, detail, success, source, created_at) "
                "VALUES (?, ?, 'system', ?, 'company_issue', ?, ?, 1, 'skip_liaison_review_used', datetime('now'))",
                (_sl_secrets.token_urlsafe(8), _sl_secrets.token_urlsafe(8), f"skip_liaison_review:{task_id}", task_id,
                 json.dumps({"skip_reason": skip_reason, "task_id": task_id}))
            )
            _bypass_db.commit()
        except Exception as _bypass_err:
            log.warning("skip_liaison_review audit log failed (non-fatal): %s", _bypass_err)
    elif _effective_require_review:
        # Defensive post-gate PASS check. Normally unreachable — the gate above writes the
        # PASS row before reaching here. Catches future regressions where gate is bypassed.
        _has_pass_row = False
        try:
            _pass_check_db = _get_db()
            _pass_check_db.row_factory = sqlite3.Row
            _pass_check_row = _pass_check_db.execute(
                "SELECT verdict, quality_score FROM execution_log "
                "WHERE entity_id=? AND actor='special_liaison' AND verdict='PASS' "
                "ORDER BY created_at DESC LIMIT 1",
                (task_id,),
            ).fetchone()
            _has_pass_row = _pass_check_row is not None
            if _has_pass_row and _pass_check_row["quality_score"] is not None:
                _review_score = float(_pass_check_row["quality_score"])
                if final_score is None or quality_score is not None:
                    final_score = _review_score
        except Exception as _pass_check_err:
            log.debug("Liaison PASS pre-closure check failed (non-fatal): %s", _pass_check_err)
        if not _has_pass_row:
            raise TaskReviewFailed(
                f"Task {task_id}: complete_task requires a Liaison PASS in execution_log "
                "before closure. None found. Run the gate via the standard complete_task path "
                "or use skip_liaison_review=True with a documented skip_reason."
            )

    db = _get_db()
    try:
        # Ensure eval columns exist (migration-safe)
        try:
            db.execute("SELECT self_score FROM company_issues LIMIT 0")
        except Exception:
            for col, coltype in [("self_score", "REAL"), ("eval_score", "REAL"),
                                 ("quality_verified", "INTEGER DEFAULT 0"),
                                 ("quality_flagged", "INTEGER DEFAULT 0"),
                                 ("quality_detail", "TEXT DEFAULT ''")]:
                try:
                    db.execute(f"ALTER TABLE company_issues ADD COLUMN {col} {coltype}")
                except Exception:
                    pass
            db.commit()

        # Ensure notes column exists (idempotent — added for supersession metadata support)
        try:
            db.execute("ALTER TABLE company_issues ADD COLUMN notes TEXT")
            db.commit()
        except Exception:
            pass  # Column already exists — safe to ignore

        # Ensure work_output column exists (idempotent — added to persist complete_task output)
        try:
            db.execute("ALTER TABLE company_issues ADD COLUMN work_output TEXT DEFAULT NULL")
            db.commit()
        except Exception:
            pass  # Column already exists — safe to ignore

        _execute_db_update_with_retry(
            db,
            """
            UPDATE company_issues
            SET status='done', completed_at=datetime('now'), updated_at=datetime('now'),
                quality_score=?, cost_cents=?, self_score=?, eval_score=?,
                quality_verified=?, quality_flagged=?, quality_detail=?, notes=?,
                work_output=?
            WHERE id=?
            """,
            (final_score, cost_cents, quality_score, eval_score if output is not None else None,
             1 if verified else 0, 1 if flagged else 0,
             eval_result["detail"] if output is not None else "unverified: no output provided",
             notes,
             work_output,
             task_id),
            task_id,
        )

        result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    except Exception:
        db.rollback()
        raise

    # Memory Lifecycle v1.6: sweep related plan-state memories on task completion
    try:
        from aibrain.core.memory_lifecycle_hooks import sweep_related_memories
        _sweep_db = _get_db()
        sweep_related_memories(result, _sweep_db)
        # Persistent connection — do NOT close; sweep_related_memories uses the same thread conn
    except Exception as _sweep_err:
        log.debug("Memory lifecycle sweep failed (non-fatal): %s", _sweep_err)

    # Record to evolution_outcomes for learning
    try:
        _record_quality_evolution(task_id, eval_result)
    except Exception as e:
        log.debug("Quality evolution record failed: %s", e)

    # Emit company.task.complete event (also fires TASK_COMPLETED for legacy compat)
    try:
        from aibrain.core.event_bus import emit as bus_emit, EventTypes
        _assignee = result.get("assignee_agent_id")
        _payload = {
            "task_id": task_id,
            "eval_score": eval_score if output is not None else None,
            "self_score": quality_score,
            "verified": verified,
            "flagged": flagged,
            "title": result.get("title", ""),
            "verification_status": (
                verification_result["verification_status"]
                if verification_result else None
            ),
            "follow_up_count": (
                len(verification_result["follow_up_tasks"])
                if verification_result else 0
            ),
        }
        bus_emit(EventTypes.COMPANY_TASK_COMPLETE, _payload, actor=_assignee)
        # Legacy event kept for existing subscribers
        bus_emit(EventTypes.TASK_COMPLETED, _payload, actor=_assignee)
    except Exception:
        pass  # Event emission never blocks task completion

    # Attach verification result to the return payload so callers see
    # which follow-ups were queued.
    if verification_result:
        result["verification"] = verification_result
        result["follow_up_tasks"] = verification_result["follow_up_tasks"]

    # Clear the thread-local checkout context IF this is the task currently
    # checked out on this thread. Guards against the case where complete_task
    # is called for a different task than the one currently stashed (e.g.
    # orchestrator code completing tasks out-of-band from the worker thread).
    if getattr(_current_issue, "id", None) == task_id:
        _current_issue.id = None
        _current_issue.company_id = None

    # Token-cost metric (task GahbnvK2buQ).  Attach as a top-level key on
    # the result dict so callers can measure Claude burn reduction from
    # the Gate 1 pre-review loop.  Always present, always 6 non-negative
    # integers.
    result["token_cost"] = _token_cost

    return result


def _record_quality_evolution(task_id: str, eval_result: dict):
    """Store quality evaluation in evolution_outcomes for pattern detection."""
    db = _get_db()
    try:
        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        try:
            from aibrain.core.db_safety import session_id as _sid
            _session_id = _sid()
        except Exception:
            _session_id = None
        db.execute("""
            INSERT INTO evolution_outcomes (source, source_id, action, result, details, session_id)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [
            "quality_eval", task_id, "complete_task",
            "flagged" if eval_result["flagged"] else "verified" if eval_result["verified"] else "unverified",
            json.dumps({
                "eval_score": eval_result["eval_score"],
                "self_score": eval_result["self_score"],
                "divergence": eval_result["divergence"],
                "checks": eval_result["checks"],
                "verified": eval_result["verified"],
            }),
            _session_id,
        ])
        db.commit()
    except Exception as e:
        log.debug("Evolution record failed: %s", e)


# ---------------------------------------------------------------------------
# Special Liaison Review Gate
# ---------------------------------------------------------------------------

class TaskReviewFailed(Exception):
    """Raised by complete_task() when the Special Liaison review returns FAIL.

    The caller must fix the work and retry complete_task().
    The exception message contains the critique from the review.
    """


class HandlerExecutionFailed(Exception):
    """Raised by complete_task() when retry_handler() itself raises an exception.

    Distinct from TaskReviewFailed (gate failed) — this means the retry mechanism
    itself is broken. The caller should inspect the cause and fix the handler.
    """


class SkipNotPermitted(Exception):
    """Raised by complete_task() when a non-CEO agent attempts to use skip_liaison_review=True.

    skip_liaison_review is a CEO-class carve-out (role='ceo' in company_agents).
    Worker agents (Lead Engineer, QA Lead, Research Analyst, etc.) must go through
    the full Liaison review gate.  Pass actor_agent_id=None to preserve backward
    compatibility for callers that do not supply an agent identity.
    """


# ---------------------------------------------------------------------------
# DeepSeek two-gate iteration loop (task GahbnvK2buQ, 2026-04-24)
# ---------------------------------------------------------------------------
#
# CONTEXT: Claude Max 5-hour token window is the real budget constraint.
# Every retry today burns Claude tokens for BOTH generation AND review.
# This two-gate loop adds a cheap DeepSeek pre-review gate BEFORE the
# existing Claude Liaison gate:
#
#   Gate 1 (DeepSeek):
#     - score <  0.90 → TaskDeepSeekGateFailed → caller retries on DeepSeek
#       (zero Claude burn).  review_round incremented.
#     - score >= 0.90 → pass through to Gate 2.
#
#   Gate 2 (Claude Liaison — existing, unchanged):
#     - PASS → task complete.
#     - FAIL → existing TaskReviewFailed.  review_round also incremented,
#       caller retries via DeepSeek generator (loop re-enters Gate 1).
#
#   Kill-switch: retry count (review_round) reaches MAX_RETRIES →
#     status='needs_human_review' (literal, per spec criterion 7),
#     terminal_state='needs_human_review' (belt-and-braces),
#     verdict='KILL_SWITCH_OVERFLOW' row recorded, TaskKillSwitchOverflow
#     raised, no auto-complete.
#
# Claude calls per task drop from ~2N (where N = retries) to exactly 1
# per Gate-2 attempt.  Majority-class tasks see 90%+ Claude reduction.
#
# SCHEMA NOTE — 'needs_human_review' status: The original
# company_issues.status CHECK constraint was
# ('backlog','todo','in_progress','in_review','done','blocked','cancelled').
# SQLite cannot ALTER a CHECK in-place, so the canonical rebuild pattern
# lives in _migrate_company_issues_status_check (idempotent: rename old →
# create new CREATE TABLE with the extended constraint → copy rows → drop
# old).  The kill-switch calls the migrator before the UPDATE, which
# rebuilds once per DB then no-ops on future calls.  The literal
# 'needs_human_review' value is now a first-class status.  Legacy DBs
# that cannot be migrated (e.g. opened read-only) fall back to the pair
# (status='blocked', terminal_state='needs_human_review').
# ---------------------------------------------------------------------------


# Kill-switch cap — configurable via env var.  Default 20 per spec.
# Applied as a ceiling on review_round; once reached, the task is
# terminally marked and the inline review does NOT run.
import os as _os

# Load ~/.decker_env into os.environ for keys not already set (covers DEEPSEEK_API_KEY
# and other credentials that aren't exported to the Claude Code process environment).
def _load_decker_env():
    _env_path = _os.path.expanduser("~/.decker_env")
    try:
        with open(_env_path, encoding="utf-8") as _f:
            for _line in _f:
                _line = _line.strip()
                if not _line or _line.startswith("#") or "=" not in _line:
                    continue
                _k, _, _v = _line.partition("=")
                _k = _k.strip()
                if _k and _k not in _os.environ:
                    _os.environ[_k] = _v.strip()
    except FileNotFoundError:
        pass

_load_decker_env()

MAX_RETRIES = int(_os.environ.get("DS_LOOP_MAX_RETRIES", "20"))

# Gate-2 attempt cap (task wpoJ4D7EBbI, 2026-04-24) — per-spec literal.
# review_round bumps ONLY on Gate-2 FAIL (not Gate-1), so this counts
# Claude Liaison attempts exactly.  On overflow → status='needs_human_review'.
# Env override: DS_MAX_GATE2_ATTEMPTS.
MAX_GATE2_ATTEMPTS = int(_os.environ.get("DS_MAX_GATE2_ATTEMPTS", "3"))

# Gate-1 iteration budget per Gate-2 attempt.  Internal regen loop caps
# DeepSeek-only iterations to prevent a pathological Gate-1-only infinite
# loop.  Cheap DS calls, so budget is liberal.
MAX_GATE1_ITERATIONS_PER_GATE2 = int(
    _os.environ.get("DS_MAX_GATE1_ITERATIONS_PER_GATE2", "10")
)

# Gate 1 pass threshold.  Inherited from prior bench (see task spec
# honest-null: "0.90 threshold is inherited from prior bench.
# Calibration may need tuning in production").  Configurable via env
# var so the production tuner can adjust without a code push.
DS_GATE1_THRESHOLD = float(_os.environ.get("DS_LOOP_GATE1_THRESHOLD", "0.90"))


# SA-2026-002 F-45 (S-01+O-01 CRITICAL) — gate-loop cost cap dataclass.
# Tracks resource consumption across the complete_task gate loop. Three
# independent caps; the FIRST cap to fire terminates the loop. All caps are
# env-var configurable. The existing TaskKillSwitchOverflow (review_round >=
# MAX_GATE2_ATTEMPTS) is preserved as a separate gate-2-fail mechanism; this
# budget is an additional safety net catching resource exhaustion regardless
# of which gate is failing.
@dataclass
class _GateBudget:
    """Tracks resource consumption across the complete_task gate loop.

    Three caps, FIRST to fire terminates. Defaults conservative for personal
    scale. Spec: decker_system/00_meta/sa_2026_002/specs/f45_gate_cost_cap_spec.md
    """
    wall_clock_s: int = 600
    token_budget: int = 100_000
    max_iters: int = 20

    start_time: float = field(default_factory=time.monotonic)
    tokens_in: int = 0
    tokens_out: int = 0
    iter_count: int = 0

    def record_iteration(self, tokens_in: int = 0, tokens_out: int = 0):
        """Call after each gate cycle (Gate 1 + Gate 2 complete)."""
        self.iter_count += 1
        self.tokens_in += int(tokens_in or 0)
        self.tokens_out += int(tokens_out or 0)

    def check(self):
        """Returns reason string if any cap exceeded, else None."""
        elapsed = time.monotonic() - self.start_time
        if elapsed > self.wall_clock_s:
            return f"wall_clock_exceeded:{elapsed:.0f}s>{self.wall_clock_s}s"
        total = self.tokens_in + self.tokens_out
        if total > self.token_budget:
            return f"token_budget_exceeded:{total}>{self.token_budget}"
        if self.iter_count >= self.max_iters:
            return f"max_iters_exceeded:{self.iter_count}>={self.max_iters}"
        return None

    @classmethod
    def from_env(cls) -> "_GateBudget":
        """Create from env vars with documented defaults.

        AIBRAIN_GATE_WALL_CLOCK_S (default 600s)
        AIBRAIN_GATE_TOKEN_BUDGET (default 100_000)
        AIBRAIN_GATE_MAX_ITERS (default 20)
        """
        return cls(
            wall_clock_s=int(_os.environ.get("AIBRAIN_GATE_WALL_CLOCK_S", "600")),
            token_budget=int(_os.environ.get("AIBRAIN_GATE_TOKEN_BUDGET", "100000")),
            max_iters=int(_os.environ.get("AIBRAIN_GATE_MAX_ITERS", "20")),
        )


class TaskDeepSeekGateFailed(Exception):
    """Raised by complete_task() when Gate 1 (DeepSeek pre-review) returns
    a score below DS_GATE1_THRESHOLD (default 0.90).

    The caller must fix the work using the attached critique and retry
    complete_task() — the retry goes through the DeepSeek generator/reviewer
    only, burning zero Claude tokens until Gate 1 passes.

    Attributes:
        critique: The DeepSeek reviewer's critique text.
        score: The Gate 1 score (< DS_GATE1_THRESHOLD).
        review_round: The current retry count (1-indexed).
    """

    def __init__(self, message: str, critique: str = "", score: float = 0.0,
                 review_round: int = 0):
        super().__init__(message)
        self.critique = critique
        self.score = score
        self.review_round = review_round


class TaskKillSwitchOverflow(Exception):
    """Raised by complete_task() when review_round exceeds MAX_RETRIES.

    The task is marked status='blocked' + terminal_state='needs_human_review'
    and a verdict='KILL_SWITCH_OVERFLOW' row is recorded.  The caller must
    surface the task to a human — no further automated retries occur.
    """


class ReviewStalemateBlocked(Exception):
    """Raised by complete_task() when review_round reaches MAX_GATE2_ATTEMPTS.

    The task is marked status='blocked_review_stalemate', a Telegram alert is
    sent to Decker with all 3 critiques side-by-side, and no further automated
    retries occur. Use override_task(), reassign_task(), rescope_task(), or
    abandon_task() to unblock.
    """


def _deepseek_http_call(system_prompt: str, user_prompt: str,
                        model: str = "deepseek-v4-pro",
                        timeout_s: int = 600,
                        thinking: bool = False,
                        reasoning_effort: str = "high",
                        max_tokens: int = 8192) -> dict:
    """Call DeepSeek's OpenAI-compatible chat-completion endpoint.

    Returns ``{'content': str, 'tokens_in': int, 'tokens_out': int}``.

    Raises:
        LiaisonCLIUnavailable — DEEPSEEK_API_KEY env var unset, or the
            DeepSeek API is unreachable.  Structured failure, NOT a silent
            PASS.  Caller must either supply credentials or use
            skip_liaison_review.
        LiaisonReviewCallFailed — HTTP error or malformed response.

    Substance check (not a location check): after a successful call, the
    returned ``content`` contains the model's response text and
    ``tokens_in`` + ``tokens_out`` are non-negative integers.

    Note: this intentionally does NOT route through the Claude CLI — Gate 1
    exists specifically to avoid Claude token burn.  Validated by grepping
    ``aibrain.core.adapters.get_adapter('deepseek')`` + direct HTTP path.
    """
    import json as _json
    import urllib.request
    import urllib.error

    api_key = _os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not api_key:
        raise LiaisonCLIUnavailable(
            "DEEPSEEK_API_KEY env var is unset.  Gate 1 (DeepSeek pre-review) "
            "cannot run without it.  Either export DEEPSEEK_API_KEY or use "
            "skip_liaison_review=True with a skip_reason."
        )

    # Validate DeepSeek adapter is registered (substance check per task
    # acceptance criterion #2).  This ties Gate 1 to the adapter registry
    # so a future rename lights up here immediately.
    from aibrain.core.adapters import get_adapter
    _ds_adapter = get_adapter("deepseek")
    if _ds_adapter is None:
        raise LiaisonCLIUnavailable(
            "DeepSeek adapter not registered in aibrain.core.adapters.  "
            "Gate 1 requires the adapter to be present."
        )

    payload = {
        "model": model,
        "max_tokens": max_tokens,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    }
    if thinking:
        # thinking mode on deepseek-v4-pro — temperature not accepted.
        # reasoning_effort: "high" (default) or "max" for complex tasks.
        payload["thinking"] = {"type": "enabled"}
        payload["reasoning_effort"] = reasoning_effort
    else:
        payload["thinking"] = {"type": "disabled"}
        payload["temperature"] = 0.0
    data = _json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "https://api.deepseek.com/v1/chat/completions",
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    _retry_delays = [2, 4, 8]
    _last_error = None
    for _attempt, _delay in enumerate([0] + _retry_delays):
        if _attempt > 0:
            log.warning("_deepseek_http_call: retry %d/%d after %.1fs — %s",
                         _attempt, len(_retry_delays), _delay, _last_error)
            time.sleep(_delay)
        try:
            with urllib.request.urlopen(req, timeout=timeout_s) as resp:
                raw = resp.read()
            break
        except urllib.error.HTTPError as e:
            raise LiaisonReviewCallFailed(
                f"DeepSeek HTTP {e.code}: {e.read()[:500].decode('utf-8', errors='replace')!r}"
            )
        except (urllib.error.URLError, TimeoutError) as e:
            _last_error = e
            if _attempt >= len(_retry_delays):
                raise LiaisonReviewCallFailed(
                    f"DeepSeek URLError after {len(_retry_delays)} retries: {e.reason}"
                )
        except Exception as e:
            raise LiaisonReviewCallFailed(
                f"DeepSeek request raised unexpected exception: {e}"
            )

    try:
        body = _json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise LiaisonReviewCallFailed(
            f"DeepSeek response not valid JSON: {e}"
        )

    try:
        choice = body["choices"][0]
        finish_reason = choice.get("finish_reason", "unknown")
        if finish_reason == "length":
            log.warning("_deepseek_http_call: response truncated (finish_reason=length, max_tokens=%d)", max_tokens)
            raise LiaisonReviewCallFailed(
                f"DeepSeek response truncated (finish_reason=length, max_tokens={max_tokens}). "
                "Retry with shorter prompt or chunked work."
            )
        msg = choice["message"]
        # Fixed: never fall back to reasoning_content; only content can hold the verdict format.
        content = msg.get("content", "") or ""
    except (KeyError, IndexError, TypeError) as e:
        raise LiaisonReviewCallFailed(
            f"DeepSeek response missing choices[0].message: {e}.  "
            f"Raw (first 500): {str(body)[:500]!r}"
        )
    if not content:
        raise LiaisonReviewCallFailed(
            f"DeepSeek returned empty content and reasoning_content.  "
            f"Raw (first 500): {str(body)[:500]!r}"
        )
    usage = body.get("usage", {}) or {}
    tokens_in = int(usage.get("prompt_tokens", 0) or 0)
    tokens_out = int(usage.get("completion_tokens", 0) or 0)
    return {
        "content": content,
        "tokens_in": max(0, tokens_in),
        "tokens_out": max(0, tokens_out),
    }


def pre_liaison_deepseek_review(task_id: str, work_output: str,
                                task_desc: Optional[dict] = None,
                                model: str = "deepseek-v4-pro",
                                timeout_s: int = 120,
                                thinking: bool = True) -> dict:
    """Gate 1: cheap DeepSeek pre-review BEFORE Claude Liaison (Gate 2).

    This is the entry point for the two-gate iteration loop.  It calls the
    DeepSeek adapter (aibrain.core.adapters.get_adapter('deepseek')), NOT
    Claude — that is the whole point of the gate.  On pass (score >=
    DS_GATE1_THRESHOLD, default 0.90), the caller proceeds to Gate 2.  On
    fail, the caller catches TaskDeepSeekGateFailed and retries via
    DeepSeek.

    Args:
        task_id: The task being reviewed.
        work_output: The author's claim of completion.
        task_desc: Optional {'title', 'description', 'priority'}.  If None,
            fetched from DB.
        model: DeepSeek model name (default 'deepseek-v4-pro').
        timeout_s: HTTP timeout.

    Returns:
        {'verdict': 'PASS'|'FAIL', 'score': float, 'critique': str,
         'tokens_in': int, 'tokens_out': int, 'duration_s': float}.

    Raises:
        LiaisonCLIUnavailable — DEEPSEEK_API_KEY unset or adapter missing.
        LiaisonReviewCallFailed — HTTP error or unparseable response.

    Falsifiability: after calling, the returned dict['verdict'] is in
    {'PASS','FAIL'} and dict['score'] is a float in [0.0, 1.0].  Tokens
    counters are non-negative integers.
    """
    import time as _time

    # Fetch task fields if caller didn't supply.
    title = ""
    description = ""
    priority = "medium"
    if task_desc is None:
        try:
            db = _get_db()
            row = db.execute(
                "SELECT title, description, priority FROM company_issues WHERE id=?",
                (task_id,),
            ).fetchone()
            if row:
                title = row["title"] or ""
                description = row["description"] or ""
                priority = row["priority"] or "medium"
        except Exception as e:
            log.debug("task fetch for DS pre-review failed (non-fatal): %s", e)
    else:
        title = task_desc.get("title", "")
        description = task_desc.get("description", "")
        priority = task_desc.get("priority", "medium")

    # Use the compact DS-specific system prompt, not the full Liaison persona.
    # The Liaison persona is Claude-optimized — DeepSeek ignores the format
    # instruction and echoes work_output when given it as system prompt.
    system_prompt = _DS_REVIEW_SYSTEM_PROMPT

    # Fixed: use the canonical prompt template shared with the Claude path.
    user_prompt = _LIAISON_REVIEW_PROMPT_TEMPLATE.format(
        task_id=task_id,
        title=title,
        priority=priority,
        description=description,
        work_output=work_output,
    )

    t0 = _time.monotonic()
    http_result = _deepseek_http_call(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        model=model,
        timeout_s=timeout_s,
        thinking=False,  # thinking mode suppresses content field on some DS versions
    )
    elapsed = _time.monotonic() - t0

    parsed = _parse_liaison_verdict(http_result["content"])
    return {
        "verdict": parsed["verdict"],
        "score": parsed["score"],
        "critique": parsed["critique"],
        "tokens_in": http_result["tokens_in"],
        "tokens_out": http_result["tokens_out"],
        "duration_s": round(elapsed, 2),
    }


def _call_liaison_deepseek(task_id: str, work_output: str,
                           task_desc: Optional[dict]) -> dict:
    """LIAISON_PROVIDER='deepseek' handler — thin wrapper over pre_liaison_deepseek_review.

    Normalises the return value to the champion_result shape expected by
    complete_task()'s Gate 2 recording path.
    """
    result = pre_liaison_deepseek_review(
        task_id=task_id,
        work_output=work_output,
        task_desc=task_desc,
        model="deepseek-v4-pro",
        timeout_s=180,
        thinking=True,
    )
    return {
        "verdict": result["verdict"],
        "score": result["score"],
        "critique": f"[DeepSeek Liaison] {result['critique']}",
        "duration_s": result.get("duration_s", 0),
        "raw_stdout_chars": 0,
    }


# LIAISON_PROVIDER registry
# Maps provider name → callable(task_id, work_output, task_desc) → verdict dict.
#
# Agents pick their provider via LIAISON_PROVIDER in their own ~/.<agent>_decker_env.
# Default (unset or 'claude') keeps the Claude CLI path in complete_task().
#
# To add a new provider:
#   1. Write a _call_liaison_<provider>(task_id, work_output, task_desc) → dict wrapper above.
#   2. Add one entry to this dict.
#   3. Set LIAISON_PROVIDER=<provider> in the agent's env file.
#   Nothing else changes.
_LIAISON_PROVIDER_CALLABLES: dict = {
    "deepseek": _call_liaison_deepseek,
    # "openai": _call_liaison_openai,  # add when needed
}


def deepseek_regenerate_work_output(task_id: str, prior_work_output: str,
                                    critique: str, gate: str,
                                    task_desc: Optional[dict] = None,
                                    model: str = "deepseek-v4-pro",
                                    timeout_s: int = 120) -> dict:
    """Internal regen: feed reviewer critique back to DeepSeek to produce a
    revised work_output.  Used by complete_task's internal regen loop (task
    wpoJ4D7EBbI, 2026-04-24).

    ``gate`` identifies which reviewer produced the critique: 'gate1' (DS)
    or 'gate2' (Claude Liaison).  Both paths go back through the DS
    generator — this is the "retry via DeepSeek" half of the spec.

    Returns ``{'work_output': str, 'tokens_in': int, 'tokens_out': int,
    'duration_s': float}``.

    Raises LiaisonCLIUnavailable / LiaisonReviewCallFailed identically to
    pre_liaison_deepseek_review; caller treats these as structural regen
    unavailability and falls back to raising TaskDeepSeekGateFailed /
    TaskReviewFailed so the external caller can retry.

    Falsifiability: returned ``work_output`` is a non-empty string; token
    counters are non-negative ints.
    """
    import time as _time
    title = ""
    description = ""
    priority = "medium"
    if task_desc is None:
        try:
            db = _get_db()
            row = db.execute(
                "SELECT title, description, priority FROM company_issues WHERE id=?",
                (task_id,),
            ).fetchone()
            if row:
                title = row["title"] or ""
                description = row["description"] or ""
                priority = row["priority"] or "medium"
        except Exception as e:
            log.debug("regen task fetch failed (non-fatal): %s", e)
    else:
        title = task_desc.get("title", "")
        description = task_desc.get("description", "")
        priority = task_desc.get("priority", "medium")

    system_prompt = (
        "You are a work_output rewriter for a software-engineering "
        "completion gate.  The author's prior work_output was REJECTED by a "
        f"reviewer ({gate}).  Your job: produce a revised work_output that "
        "fixes the specific gaps named in the critique and nothing else.\n\n"
        "Output format — DONE/DIDN'T TOUCH/VERIFICATION/OPEN CONCERNS "
        "sections.  No preamble.  No code fences.  Begin directly with "
        "'DONE:'."
    )
    user_prompt = (
        f"=== TASK ===\nTask ID: {task_id}\nTitle: {title}\nPriority: {priority}\n\n"
        f"Description:\n{description}\n\n"
        f"=== PRIOR WORK OUTPUT (rejected) ===\n{prior_work_output}\n\n"
        f"=== REVIEWER CRITIQUE ({gate}) ===\n{critique}\n\n"
        f"=== REVISED WORK OUTPUT ===\n"
    )
    t0 = _time.monotonic()
    http_result = _deepseek_http_call(
        system_prompt=system_prompt, user_prompt=user_prompt,
        model=model, timeout_s=timeout_s,
    )
    elapsed = _time.monotonic() - t0
    new_work = (http_result["content"] or "").strip()
    if not new_work:
        raise LiaisonReviewCallFailed(
            "DeepSeek regenerator returned empty content.  Caller must "
            "handle as regen unavailable."
        )
    return {
        "work_output": new_work,
        "tokens_in": http_result["tokens_in"],
        "tokens_out": http_result["tokens_out"],
        "duration_s": round(elapsed, 2),
    }


def review_task(task_id: str, output: str, reviewer: str = "special_liaison") -> dict:
    """Evaluate task output via the Special Liaison (intel_agent_v2) review gate.

    Checks the output against:
      (a) Acceptance criteria extracted from the task description
      (b) V2 discipline compliance — falsifiability of claims, absence of weasel
          words, evidence of adversarial self-critique

    Returns:
        {
            "verdict": "PASS" | "FAIL",
            "score": 0.0 – 1.0,
            "critique": "<explanation>",
            "reviewer": "special_liaison",
            "task_id": task_id,
            "checks": {<named check>: bool, ...}
        }

    The review is logged to execution_log with actor="special_liaison" so it
    appears in the audit trail alongside normal harness executions.
    Falsifiability of this function's own verdict: if all named checks pass
    and no weasel words are detected, verdict=PASS. If any check fails,
    verdict=FAIL. The score is (passing checks) / (total checks).
    """
    import re
    import secrets as _secrets
    import time

    t_start = time.monotonic()

    # ── 1. Fetch task details ─────────────────────────────────────
    db = _get_db()
    task_row = db.execute(
        "SELECT title, description, priority FROM company_issues WHERE id=?", (task_id,)
    ).fetchone()

    if not task_row:
        # Task not found — can't review, FAIL defensively
        return {
            "verdict": "FAIL",
            "score": 0.0,
            "critique": f"Task {task_id} not found — cannot evaluate.",
            "reviewer": reviewer,
            "task_id": task_id,
            "checks": {},
        }

    title = task_row["title"] or ""
    description = task_row["description"] or ""
    output_str = output or ""

    # ── 2. Extract acceptance criteria from description ───────────
    # Criteria are numbered lines, bullet points, or lines starting with "- "
    # e.g. "1. Do X\n2. Do Y" or "- criterion A\n- criterion B"
    criteria = []
    for line in description.splitlines():
        stripped = line.strip()
        # Numbered: "1." / "1)" / "Step 1:"
        if re.match(r"^\d+[\.\)]\s+\S", stripped):
            criteria.append(re.sub(r"^\d+[\.\)]\s+", "", stripped))
        # Bullet: "- " or "* "
        elif re.match(r"^[-\*]\s+\S", stripped):
            criteria.append(re.sub(r"^[-\*]\s+", "", stripped))

    # ── 3. Run named checks ───────────────────────────────────────
    checks: dict[str, bool] = {}

    # Check A: output is non-empty / substantive
    checks["output_substantive"] = len(output_str.strip()) >= 20

    # Check B: no weasel words (V2 discipline — "should work", "probably", "seems")
    weasel_pattern = re.compile(
        r"\b(should work|probably fix|seems correct|might work|appears to work"
        r"|hopefully|should be fine|likely works|it seems|probably done)\b",
        re.IGNORECASE,
    )
    checks["no_weasel_words"] = not bool(weasel_pattern.search(output_str))

    # Check C: falsifiable claim present — output contains a verification command,
    # file path, test result, or explicit "verified by" statement
    falsifiability_pattern = re.compile(
        r"(verified|verification|confirmed|test pass|exit 0|grep|SELECT|assert"
        r"|PASS|FAIL|output:|result:|checked|`[^`]+`|\$ [a-z])",
        re.IGNORECASE,
    )
    checks["falsifiable_claim"] = bool(falsifiability_pattern.search(output_str))

    # Check D: acceptance criteria coverage — each criterion keyword appears in output
    if criteria:
        covered = 0
        for criterion in criteria:
            # Extract the first 4 significant words as a keyword probe
            words = [w for w in re.split(r"\W+", criterion.lower()) if len(w) > 3][:4]
            if words and any(w in output_str.lower() for w in words):
                covered += 1
        checks["criteria_coverage"] = (covered / len(criteria)) >= 0.5
    else:
        # No explicit criteria — skip this check (not penalised)
        checks["criteria_coverage"] = True

    # Check E: adversarial critique signal — output acknowledges limitations,
    # edge cases, or explicitly names what was NOT done / what could fail
    adversarial_pattern = re.compile(
        r"(caveat|limitation|edge case|not cover|does not|won't|cannot|known issue"
        r"|open question|follow.?up|gap|risk|falsified if|would fail if|honest.?null)",
        re.IGNORECASE,
    )
    checks["adversarial_critique"] = bool(adversarial_pattern.search(output_str))

    # ── 4. Score and verdict ──────────────────────────────────────
    # Weight: output_substantive is a hard gate (0 score if absent).
    # Other checks each contribute equally to the remaining score.
    if not checks["output_substantive"]:
        score = 0.0
        critique_parts = ["Output is empty or trivially short — cannot evaluate."]
    else:
        scored_checks = {k: v for k, v in checks.items() if k != "output_substantive"}
        passing = sum(1 for v in scored_checks.values() if v)
        total = len(scored_checks)
        score = round(passing / total, 2) if total else 1.0

        critique_parts = []
        if not checks["no_weasel_words"]:
            critique_parts.append(
                "Weasel words detected — replace with verified observable claims."
            )
        if not checks["falsifiable_claim"]:
            critique_parts.append(
                "No falsifiability signal — add a verification command, test result, or explicit"
                " 'verified by' statement."
            )
        if not checks.get("criteria_coverage", True):
            critique_parts.append(
                "Acceptance criteria coverage below 50% — address missing criteria explicitly."
            )
        if not checks["adversarial_critique"]:
            critique_parts.append(
                "No adversarial self-critique found — state what this does NOT cover or what"
                " could still fail."
            )

    # PASS threshold: score >= 0.87 — matches GATE2_MIN_SCORE hard floor
    verdict = "PASS" if score >= 0.87 else "FAIL"
    critique = " | ".join(critique_parts) if critique_parts else "All checks passed."

    # ── Real Special Liaison review goes through Claude Code subscription ──
    # review_task() is a regex pre-filter only. The full LLM review is done
    # via Agent tool spawn by Neuro, NOT via the Anthropic API directly.
    #
    # Flow:
    #   1. Neuro calls review_task(task_id, output) — regex pre-filter (this fn)
    #   2. Neuro spawns Agent tool with intel_agent_v2 / Special Liaison persona
    #   3. Agent returns verdict; Neuro calls record_liaison_verdict(task_id, ...)
    #   4. complete_task() checks execution_log for the PASS row and proceeds
    #
    # No API calls here. No anthropic import. Cost = $0 for this fn.

    duration_ms = int((time.monotonic() - t_start) * 1000)

    # ── 5. Log to execution_log ───────────────────────────────────
    # review_task() is regex-only (pre-filter). Cost = 0, task_type = deterministic.
    # The real Agent-based review is recorded via record_liaison_verdict().
    try:
        db = _get_db()
        run_id = _secrets.token_urlsafe(8)
        try:
            from aibrain.core.db_safety import session_id as _sid
            _session_id = _sid()
        except Exception:
            _session_id = None
        # Migration-safe: add `source` and `text_id` columns if missing.
        for _col_ddl in (
            "ALTER TABLE execution_log ADD COLUMN source TEXT DEFAULT NULL",
            "CREATE TABLE IF NOT EXISTS liaison_critique_history (id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, round INTEGER DEFAULT 1, source TEXT DEFAULT gate, verdict TEXT, score REAL, critique TEXT, created_at TEXT)",
            "ALTER TABLE execution_log ADD COLUMN text_id TEXT",
        ):
            try:
                db.execute(_col_ddl)
                db.commit()
            except Exception:
                pass
        db.execute("""
            INSERT INTO execution_log
            (text_id, run_id, actor, action, entity_type, entity_id,
             detail, quality_score, success, duration_ms,
             cost_cents, cost_cents_actual, cost_cents_equivalent,
             task_type, source, session_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """, (
            _secrets.token_urlsafe(8), run_id,
            reviewer,                           # actor = "special_liaison"
            f"review_prefilter:{task_id}",      # pre-filter pass, not full review
            "company_issue", task_id,
            json.dumps({
                "verdict": verdict, "score": score,
                "critique": critique, "checks": checks,
                "title": title,
                "llm_ran": False,               # regex-only, no LLM
                "source": "pre_filter",
            }),
            score,
            1 if verdict == "PASS" else 0,
            duration_ms,
            0,                # cost_cents: $0 — regex pre-filter
            0,                # cost_cents_actual: $0
            None,             # cost_cents_equivalent
            "deterministic",  # regex-only check
            "pre_filter",     # source — not gate-clearing (sC9X5a7ytaY)
            _session_id,
        ))
        db.commit()
    except Exception as e:
        log.debug("review_task execution_log write failed (non-fatal): %s", e)

    log.info(
        "Special Liaison review: task=%s verdict=%s score=%.2f critique=%s",
        task_id, verdict, score, critique,
    )

    return {
        "verdict": verdict,
        "score": score,
        "critique": critique,
        "reviewer": reviewer,
        "task_id": task_id,
        "checks": checks,
    }


def set_review_required(task_id: str, required: bool = True) -> dict:
    """Mark a task as requiring Special Liaison review before completion.

    High-priority and critical tasks auto-require review without calling this
    function. Use set_review_required() to explicitly gate any other task.

    Returns the updated task dict, or {"error": "..."} if task not found.
    """
    db = _get_db()

    # Migration-safe: add review_required column if it doesn't exist yet
    try:
        db.execute("SELECT review_required FROM company_issues LIMIT 0")
    except Exception:
        try:
            db.execute(
                "ALTER TABLE company_issues ADD COLUMN review_required INTEGER DEFAULT 0"
            )
            db.commit()
            log.info("Migration: added review_required column to company_issues")
        except Exception as e:
            log.debug("review_required migration failed (non-fatal): %s", e)

    cur = db.execute(
        "UPDATE company_issues SET review_required=?, updated_at=datetime('now') WHERE id=?",
        (1 if required else 0, task_id),
    )
    db.commit()

    if cur.rowcount == 0:
        return {"error": f"Task {task_id} not found"}

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    log.info("Task %s review_required set to %s", task_id, required)
    return result


def flag_review_pending(task_id: str) -> dict:
    """Write review_pending=1 to company_issues for the given task.

    Signals that Neuro (CEO) must spawn a Special Liaison Agent review before
    the task can be completed. Does NOT block completion on its own — the gate
    lives in complete_task() which checks execution_log for a PASS verdict
    from record_liaison_verdict().

    Use this as a visual marker so list_tasks() output shows which tasks are
    awaiting liaison review.

    Returns the updated task dict, or {"error": "..."} if task not found.
    """
    db = _get_db()

    # Migration-safe: add review_pending column if it doesn't exist yet
    try:
        db.execute("SELECT review_pending FROM company_issues LIMIT 0")
    except Exception:
        try:
            db.execute(
                "ALTER TABLE company_issues ADD COLUMN review_pending INTEGER DEFAULT 0"
            )
            db.commit()
            log.info("Migration: added review_pending column to company_issues")
        except Exception as e:
            log.debug("review_pending migration failed (non-fatal): %s", e)

    cur = db.execute(
        "UPDATE company_issues SET review_pending=1, updated_at=datetime('now') WHERE id=?",
        (task_id,),
    )
    db.commit()

    if cur.rowcount == 0:
        return {"error": f"Task {task_id} not found"}

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    log.info("Task %s flagged review_pending=1", task_id)
    return result


VALID_LIAISON_SOURCES = (
    "agent_review",
    "pre_filter",
    "self_recorded",
    "skipped_with_reason",
    # Primary-gate source tag. Originally introduced 2026-04-21 for the
    # intel_agent-as-Champion pattern; as of 2026-04-22 the persona behind
    # this tag is Codex (former Special Liaison). Tag name preserved for
    # backward-compat with historical rows.
    "champion_review",
    # Legacy — blind Liaison observational shadow (2026-04-21 to 2026-04-22).
    # Shadow block dropped when Codex became the primary gate. Kept in the
    # valid-sources tuple so historical rows remain loadable.
    "liaison_shadow",
    # Gate 1 source tag — DeepSeek pre-review (task GahbnvK2buQ, 2026-04-24).
    # Audit-trail ONLY — this source does NOT clear the Special Liaison gate
    # (which remains Claude's job).  Used for later Gate-1 vs Gate-2
    # correlation analysis (did Gate 1 agree with Gate 2? what's the FP/FN
    # rate?).  A Gate-1 PASS feeds into the Gate-2 call; a Gate-1 FAIL raises
    # TaskDeepSeekGateFailed without ever reaching the gate-clearing query.
    "ds_pre_review",
)


# ---------------------------------------------------------------------------
# Inline Special Liaison review via claude CLI subprocess
# ---------------------------------------------------------------------------
#
# DESIGN (2026-04-19, task FZgPuupsqrQ — structural close of self-record gaming):
#
# Before this fix: ``complete_task()`` would raise ``TaskReviewFailed`` when
# no ``source='agent_review'`` PASS row existed. The worker was expected to
# MANUALLY spawn an Agent tool, load the Special Liaison persona, run the
# review, and then call ``record_liaison_verdict()``. This worked in theory;
# in practice the manual spawn step was skipped, forgotten, or gamed (worker
# recording their own PASS with ``source='self_recorded'`` — which migration
# sC9X5a7ytaY closed — or simply bypassing the gate altogether).
#
# This fix: ``complete_task()`` now invokes the Liaison SYNCHRONOUSLY via
# a ``claude`` CLI subprocess. The Liaison persona is read from the
# ``company_agents`` row (``bwHDCnvlGFY.instructions``) and passed as the
# system prompt. The task description + work_output is passed as the user
# prompt. The CLI's stdout is parsed for a structured verdict
# (``VERDICT: PASS|FAIL\nSCORE: 0.0-1.0\nCRITIQUE: <text>``) and recorded
# via ``record_liaison_verdict(..., source='agent_review')`` — which clears
# the gate. FAIL raises ``TaskReviewFailed`` as before.
#
# Latency honest-null (per Decker 2026-04-19):
# A ``claude`` CLI spawn costs ~2-5 min per invocation. That's the real cost
# of real review. The prior manual-spawn workflow cost more in practice
# (orchestrator round-trips, missed approvals, backlog) — so synchronous
# 3-min > async 30+-min. Skip carve-outs (``skip_liaison_review=True`` +
# ``skip_reason``) are audited via a ``source='skipped_with_reason'`` row so
# the audit trail reflects the bypass decision explicitly.
#
# Mirrors ``aibrain/core/hypothesis_queue.py::claude_synth_callable`` — same
# primitive (stdin-piped prompt, --append-system-prompt-file for large
# system prompts via ``decker_system/04_tools/claude_cli.py::call_claude_cli``).


# F-CLAUDE-CLI-PATH-ON-DEEP-HOST-1: Windows claude binary detection.
# Mirrors lucy_agent.py _detect_claude_cli_binary.
def _detect_claude_cli_binary() -> str | None:
    import shutil, sys
    if sys.platform.startswith("win"):
        return (
            shutil.which("claude.cmd")
            or shutil.which("claude.exe")
            or shutil.which("claude.bat")
            or shutil.which("claude")
        )
    return shutil.which("claude") or shutil.which("claude.exe")


_SPECIAL_LIAISON_AGENT_ID = "bwHDCnvlGFY"
_LIAISON_PERSONA_FILENAME = "special_liaison.md"

# F-CLAUDE-CLI-PATH-ON-DEEP-HOST-1: trimmed persona for Claude Code free tier.
# The full 12KB persona triggers subscription enforcement. This ~600B version
# keeps only the verdict format + critical rules.
_LIAISON_PERSONA_TRIMMED = """You are a Special Liaison reviewer. Review tasks and output:
VERDICT: PASS|FAIL
SCORE: 0.0-1.0
CRITIQUE: <brief explanation>
FOLLOW-UPS: <if FAIL, specific changes required before re-review>

Rules:
- Every VERIFICATION item must show ACTUAL command output (stdout/stderr/exit code), not just a claim.
- A VERIFICATION that asserts "exits 0" or "grep matches" without showing the real output is NOT evidence — FAIL.
- Check DIDNT TOUCH section: any files claimed untouched that the description references? FAIL.
- DONE section must reference specific changes (functions, commits, files).
- Be brief. 2-5 sentence critique. No essays."""

# Primary gate reviewer — Codex (promoted from Special Liaison via Karpathy
# loop + McKee gate, 2026-04-22, baseline 0.3760 → candidate 0.4060).
# Codex's persona is evolved for review work specifically, which makes it
# the correct primary gate. The earlier Champion-as-gate pattern (intel_agent
# plateau winner rrSo0lFItV0 / research/intel_agent/baseline.md, deployed
# 2026-04-21) reverted on 2026-04-22 — intel_agent is research-optimized,
# role-mismatched against review. Blind Liaison shadow dropped at the same
# time; can be reinstated if calibration data ever proves needed.
#
# Variable name `_CHAMPION_*` kept for minimum diff (it is an internal
# constant, not a user-visible symbol); DB audit-trail source tag
# 'champion_review' also kept for backward-compat with historical rows.
_CHAMPION_AGENT_ID = "bwHDCnvlGFY"
_CHAMPION_PERSONA_FILENAME = "special_liaison/baseline.md"


def _liaison_persona_fallback_path() -> Optional[Path]:
    """Resolve ``decker_system/02_subagents/special_liaison.md`` on disk.

    Returns None if the decker_system overlay is not discoverable on this
    host — callers treat that as "fall back to DB, or fail loudly later."
    Cross-host portability: routes through ``aibrain.core.paths`` so the
    same three-branch discovery applies here as in the tools-dir resolver.
    """
    try:
        from aibrain.core.paths import resolve_decker_subagents_dir
        return resolve_decker_subagents_dir() / _LIAISON_PERSONA_FILENAME
    except Exception:
        return None

_LIAISON_REVIEW_PROMPT_TEMPLATE = """\
You are reviewing a completed task for the Special Liaison Review Gate.

Your job is to issue a PASS or FAIL verdict plus a quality score (0.0-1.0)
and a short critique. You are NOT executing the work; you are auditing the
author's claim that the work is complete.

=== TASK DESCRIPTION ===

Task ID: {task_id}
Title: {title}
Priority: {priority}

Description:
{description}

=== WORK OUTPUT (author's claim) ===

{work_output}

=== VERIFICATION EVIDENCE RULE (HARD) ===

You cannot re-run commands. You can only read what is in the WORK OUTPUT above.

A VERIFICATION item is VALID only if it shows ACTUAL command output -- stdout, stderr,
or an explicit exit 0/1 confirmation pasted from a real run.

A VERIFICATION item that only names a command or asserts "exits 0" without showing
the actual output is NOT evidence -- it is a claim. Claims are not evidence.

TREAT ANY OF THE FOLLOWING AS UNVERIFIED and FAIL with a MAJOR finding:
- "python -c '...' exits 0" with no output shown
- "tests pass" with no test runner output shown
- "import succeeds" with no confirmation shown
- Any VERIFICATION line that names a command but shows no output after it

If VERIFICATION section is present but all items are claims without output:
  FAIL -- MAJOR: "VERIFICATION section contains claims without evidence; pasted command output required"

If VERIFICATION section is absent from a non-trivial work_output:
  FAIL -- MAJOR: "Missing VERIFICATION section"

Exception: single-line trivial fixes where the change is self-evidently correct from the DONE section
(a typo fix, a one-word rename) may omit VERIFICATION.

=== REQUIRED OUTPUT FORMAT ===

Respond with exactly the following structure. No preamble, no narrative wrap,
no markdown code fences. The regex parser is strict — deviation causes the
worker to raise LiaisonReviewCallFailed and retry.

VERDICT: PASS
SCORE: 0.87
CRITIQUE: <2-5 sentences explaining why PASS or FAIL, naming any MAJOR findings>
FOLLOW-UPS: <if FAIL, list 1-3 specific actionable items the author must fix; if PASS write 'None'>

(Replace VERDICT with PASS or FAIL, SCORE with a float in [0.0, 1.0], and
write the critique on ONE logical line — newlines inside the critique are OK
but do not prefix them with blank lines or section headers.
FOLLOW-UPS is required on FAIL — a vague FAIL without follow-up actions is rejected.)
"""

# Compact system prompt for the DeepSeek Gate 1 pre-review path.
# The Liaison persona is Claude-optimized and too long for DeepSeek to follow
# as a format constraint — DeepSeek echoes work_output instead of producing
# VERDICT/SCORE/CRITIQUE when given the full persona. This short prompt
# constrains the model to the exact output structure the parser expects.
_DS_REVIEW_SYSTEM_PROMPT = (
    "You are a strict task-completion reviewer. "
    "Your ENTIRE response MUST follow this exact template — "
    "no preamble, no markdown fences, no extra text before or after:\n\n"
    "VERDICT: PASS\n"
    "SCORE: 0.87\n"
    "CRITIQUE: 2-5 sentences about what passed or failed, naming any MAJOR finding.\n"
    "FOLLOW-UPS: If FAIL list 1-3 specific actionable items. If PASS write None.\n\n"
    "Replace VERDICT with PASS or FAIL. Replace SCORE with a float 0.0-1.0. "
    "Start your response with the literal word VERDICT on line 1. "
    "Do not output anything before VERDICT. "
    "FAIL if VERIFICATION section has only command names or assertions without pasted actual output -- "
    "claimed verification without pasted output is not evidence."
)


# Parser tolerates: optional bold/italic markdown around labels, extra
# whitespace, case variation ("Verdict"/"VERDICT"), the SCORE line being
# written as "0.87" or "87%" or "0.87/1.0", and a CRITIQUE block that spans
# multiple lines until EOF.
_VERDICT_RE = __import__("re").compile(
    r"(?im)^\s*\**\s*VERDICT\s*:?\s*\**\s*(PASS|FAIL)\b"
)
_SCORE_RE = __import__("re").compile(
    r"(?im)^\s*\**\s*SCORE\s*:?\s*\**\s*([01](?:\.\d+)?|\d{1,3}(?:\.\d+)?%?)"
)
_CRITIQUE_RE = __import__("re").compile(
    r"(?ims)^\s*\**\s*CRITIQUE\s*:?\s*\**\s*(.+?)\s*$"
)


class LiaisonCLIUnavailable(Exception):
    """Raised when the ``claude`` CLI is not available on PATH.

    complete_task() cannot run an inline Liaison review without the CLI.
    The caller must either (a) install Claude Code, (b) set
    skip_liaison_review=True with a skip_reason, or (c) run the Agent-based
    review manually and record the verdict via record_liaison_verdict().

    Honest-None: this is a structured failure, not a silent fallback. We
    never fake a PASS because the CLI is missing.
    """


class LiaisonReviewCallFailed(Exception):
    """Raised when the ``claude`` CLI invocation failed or returned output
    that could not be parsed into a VERDICT/SCORE/CRITIQUE structure.

    The caller should fix the underlying issue (CLI timeout, model error,
    or prompt-output mismatch) and retry complete_task(). We do NOT silently
    treat unparseable output as PASS or FAIL — that would mask structural
    breakage in the review loop.
    """


def _resolve_decker_tools_dir() -> Path:
    """Discover ``decker_system/04_tools`` across Neuro (Windows) and Case (Kali).

    Thin wrapper over ``aibrain.core.paths.resolve_decker_tools_dir`` that
    preserves the ``LiaisonCLIUnavailable`` exception type the inline Liaison
    review surface already raises — the shared resolver raises
    ``DeckerSystemPathUnavailable``, and this call site re-raises with the
    liaison-specific context ("required for claude_cli import used by the
    inline Liaison review").

    Resolution order (first hit wins): ``DECKER_SYSTEM_ROOT`` env var →
    ``AIBRAIN_ROOT.parent/decker_system`` → ``HOME/decker_system``.

    Raises:
        LiaisonCLIUnavailable — no candidate resolves to a directory.
        Caller cannot import ``claude_cli`` without this path, so surfacing
        the failure explicitly beats a silent ImportError downstream.
    """
    from aibrain.core.paths import (
        DeckerSystemPathUnavailable,
        resolve_decker_tools_dir as _shared_resolver,
    )

    try:
        return _shared_resolver()
    except DeckerSystemPathUnavailable as e:
        raise LiaisonCLIUnavailable(
            f"{e} Required for claude_cli import used by the inline "
            f"Liaison review."
        )


def _load_liaison_persona() -> Optional[str]:
    """Load the Special Liaison persona used as system prompt.

    Primary source: company_agents row ``bwHDCnvlGFY.instructions``.
    Fallback: ``decker_system/02_subagents/special_liaison.md`` on disk.
    Returns None if neither is available (caller decides whether to fail
    the review or proceed with no system prompt — current policy is
    LiaisonCLIUnavailable since the persona is load-bearing).
    """
    try:
        db = _get_db()
        row = db.execute(
            "SELECT instructions FROM company_agents WHERE id=?",
            (_SPECIAL_LIAISON_AGENT_ID,),
        ).fetchone()
        if row and row["instructions"]:
            return row["instructions"]
    except Exception as e:
        log.debug("liaison persona DB load failed (non-fatal): %s", e)

    try:
        p = _liaison_persona_fallback_path()
        if p is not None and p.is_file():
            return p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        log.debug("liaison persona file load failed (non-fatal): %s", e)

    return None


def _load_champion_persona() -> Optional[str]:
    """Load the primary gate reviewer persona (currently Codex).

    Primary source: company_agents row ``bwHDCnvlGFY.instructions`` (Codex).
    Fallback: ``research/special_liaison/baseline.md`` relative to AIBRAIN_ROOT.
    Returns None if neither is available — caller raises LiaisonCLIUnavailable.

    Codex was promoted from Special Liaison on 2026-04-22 via the Karpathy
    loop + McKee gate (baseline 0.3760 → candidate 0.4060) and replaced the
    intel_agent-as-Champion pattern shortly after because intel_agent's
    plateau is research-optimized, not review-optimized.
    """
    try:
        db = _get_db()
        row = db.execute(
            "SELECT instructions FROM company_agents WHERE id=?",
            (_CHAMPION_AGENT_ID,),
        ).fetchone()
        if row and row["instructions"]:
            return row["instructions"]
    except Exception as e:
        log.debug("primary reviewer persona DB load failed (non-fatal): %s", e)

    # Fallback: read directly from the research directory relative to aibrain root.
    try:
        from aibrain.core.paths import resolve_aibrain_root
        p = resolve_aibrain_root() / "research" / "special_liaison" / "baseline.md"
        if p.is_file():
            return p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        log.debug("primary reviewer persona file load (aibrain root) failed (non-fatal): %s", e)

    # Final fallback: try the path directly in case aibrain is at the well-known location.
    # Checks both Neuro (Windows) and Case (Linux VPS) well-known install dirs;
    # updated 2026-04-22 to point at Codex persona (special_liaison/baseline.md),
    # previously pointed at intel_agent/baseline.md — that stale path would have
    # silently reverted the gate to the research-optimized intel_agent persona
    # if the first two load paths failed (caught by Codex review of 9ed69ed1).
    for _candidate in (
        Path.home() / "projects" / "aibrain" / "research" / "special_liaison" / "baseline.md",
        Path("/root/projects/aibrain/research/special_liaison/baseline.md"),
        Path("/home/kali/projects/aibrain/research/special_liaison/baseline.md"),
    ):
        try:
            if _candidate.is_file():
                return _candidate.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            log.debug("primary reviewer persona hardcoded path %s failed (non-fatal): %s", _candidate, e)

    return None


def _parse_liaison_verdict(stdout: str) -> dict:
    """Parse CLI stdout into {verdict, score, critique}.

    Raises LiaisonReviewCallFailed if the structure cannot be found.
    Tolerates markdown framing, case variation, percentage scores, and
    multi-line critiques. Does NOT tolerate missing VERDICT or SCORE lines.
    """
    if not stdout or not stdout.strip():
        raise LiaisonReviewCallFailed(
            "claude CLI returned empty stdout — cannot parse verdict."
        )

    m_v = _VERDICT_RE.search(stdout)
    if not m_v:
        raise LiaisonReviewCallFailed(
            f"No VERDICT line found in CLI output. Raw output "
            f"(first 500 chars): {stdout[:500]!r}"
        )
    verdict = m_v.group(1).upper()

    m_s = _SCORE_RE.search(stdout)
    if not m_s:
        raise LiaisonReviewCallFailed(
            f"No SCORE line found in CLI output. Raw output "
            f"(first 500 chars): {stdout[:500]!r}"
        )
    raw_score = m_s.group(1).strip()
    try:
        if raw_score.endswith("%"):
            score = float(raw_score[:-1]) / 100.0
        else:
            parts = raw_score.split("/")
            if len(parts) == 2:
                numerator = float(parts[0])
                denominator = float(parts[1])
                if denominator > 1.0:
                    score = numerator / denominator
                else:
                    score = numerator
            else:
                score = float(parts[0])
        score = max(0.0, min(1.0, score))
    except ValueError:
        raise LiaisonReviewCallFailed(
            f"SCORE value '{raw_score}' is not a float in [0.0, 1.0]."
        )

    # Critique: from the CRITIQUE line to EOF. If the label is missing, we
    # degrade to "no critique provided" — don't FAIL the review over it,
    # but surface it via the critique text so the author sees the gap.
    m_c = _CRITIQUE_RE.search(stdout)
    if m_c:
        # Group captures single line; extend to capture trailing lines.
        idx = m_c.start(1)
        critique = stdout[idx:].strip()
    else:
        critique = "(No CRITIQUE block in CLI output — Liaison should include one.)"

    return {"verdict": verdict, "score": score, "critique": critique}


def claude_liaison_review_callable(
    task_id: str,
    work_output: str,
    task_desc: Optional[dict] = None,
    model: Optional[str] = None,
    timeout_s: int = 900,
    persona_override: Optional[str] = None,
) -> dict:
    """Spawn the ``claude`` CLI with a reviewer persona and return a parsed
    verdict dict (no DB write — caller records via ``record_liaison_verdict``).

    Mirrors ``aibrain.core.hypothesis_queue.claude_synth_callable``: the
    system prompt is the reviewer persona (read from company_agents row or
    supplied via ``persona_override``), the user prompt is the task description
    + work output rendered through ``_LIAISON_REVIEW_PROMPT_TEMPLATE``, and
    the output is parsed for a structured VERDICT/SCORE/CRITIQUE triple.

    Args:
        persona_override: If supplied, use this string as the system prompt
            instead of loading the Special Liaison persona from the DB. Used
            by the Champion-as-gate pattern to inject the Champion persona
            while reusing the same callable. When None (default), loads the
            Special Liaison persona from company_agents row ``bwHDCnvlGFY``
            with disk fallback.

    Raises:
        LiaisonCLIUnavailable — ``claude`` not on PATH, or persona not
            loadable. Explicit, never a silent PASS.
        LiaisonReviewCallFailed — CLI errored (non-zero exit) or returned
            output that ``_parse_liaison_verdict`` cannot understand.

    Returns:
        ``{'verdict': 'PASS'|'FAIL', 'score': float, 'critique': str,
           'duration_s': float, 'raw_stdout_chars': int}``
    """
    import sys as _sys
    import time as _time
    # Test-mode short-circuit: AIBRAIN_LIAISON_TEST_MODE=1 returns FAIL
    # immediately without spawning a real subprocess. Set via conftest.py
    # autouse fixture for source-tag gate tests so they don't block on the
    # 2-5 min Claude CLI call.
    if _os.environ.get("AIBRAIN_LIAISON_TEST_MODE") == "1":
        return {
            "verdict": "FAIL",
            "score": 0.0,
            "critique": "AIBRAIN_LIAISON_TEST_MODE=1 — real CLI skipped in test mode. Follow-up: run with real CLI to get actionable critique.",
            "duration_s": 0.0,
            "raw_stdout_chars": 0,
        }
    # Cross-host portability (Neuro on Windows, Case on Kali): resolve
    # decker_system/04_tools via env var + AIBRAIN_ROOT-relative discovery
    # rather than hardcoding a Windows path. Mirrors the pattern already
    # applied in tests/test_inline_liaison_integration.py.
    _decker_tools = _resolve_decker_tools_dir()  # raises LiaisonCLIUnavailable if missing
    _sys.path.insert(0, str(_decker_tools))
    try:
        from claude_cli import call_claude_cli  # type: ignore
    except Exception as e:
        raise LiaisonCLIUnavailable(
            f"claude_cli import failed: {e}. "
            f"Expected at decker_system/04_tools/claude_cli.py (resolved to {_decker_tools})."
        )

    # REVERT 2026-05-11: persona size-based trim swap removed per Decker directive
    # ("do not trim the liason persona, it works"). The full persona must be used in
    # both standalone and integrated paths — they should be identical. The previous
    # F-CLAUDE-CLI-PATH-ON-DEEP-HOST-1 swap was diverging the two paths and causing
    # integrated complete_task() to fail where standalone call_claude_cli() worked.
    # Persona resolution: use caller-supplied override (e.g. Champion persona),
    # otherwise fall back to the Special Liaison persona from DB / disk.
    if persona_override is not None:
        persona = persona_override
        if not persona:
            raise LiaisonCLIUnavailable(
                "persona_override was supplied but is empty. Cannot run inline review."
            )
    else:
        persona = _load_liaison_persona()
        if not persona:
            _fallback_disp = _liaison_persona_fallback_path()
            raise LiaisonCLIUnavailable(
                f"Special Liaison persona not loadable from company_agents "
                f"(id={_SPECIAL_LIAISON_AGENT_ID}) or disk fallback "
                f"({_fallback_disp or 'decker_system/02_subagents/special_liaison.md (path unresolvable)'}). "
                f"Cannot run inline review."
            )

    # Fetch task fields from DB if caller didn't supply them.
    title = ""
    description = ""
    priority = "medium"
    if task_desc is None:
        try:
            db = _get_db()
            row = db.execute(
                "SELECT title, description, priority FROM company_issues WHERE id=?",
                (task_id,),
            ).fetchone()
            if row:
                title = row["title"] or ""
                description = row["description"] or ""
                priority = row["priority"] or "medium"
        except Exception as e:
            log.debug("task fetch for liaison review failed (non-fatal): %s", e)
    else:
        title = task_desc.get("title", "")
        description = task_desc.get("description", "")
        priority = task_desc.get("priority", "medium")

    prompt = _LIAISON_REVIEW_PROMPT_TEMPLATE.format(
        task_id=task_id,
        title=title,
        priority=priority,
        description=description,
        work_output=str(work_output),
    )

    # F-DEEP-LIAISON-PROVIDER-ROUTER-WIRING-1: try ProviderRouter first
    reviewer_result = None
    try:
        from aibrain.core.provider_contract import ProviderRouter, ProviderConfigError
        router = ProviderRouter()
        reviewer = router.get_provider("text_review")
        import asyncio as _alo
        reviewer_result = _alo.new_event_loop().run_until_complete(
            reviewer.invoke({
                "persona": persona,
                "work_output": str(work_output),
                "acceptance_criteria": prompt,
            })
        )
    except (ProviderConfigError, Exception) as _pre:
        log.debug("ProviderRouter text_review not available: %s — falling back to Claude CLI", _pre)

    if reviewer_result is not None:
        # Parse reviewer result into verdict dict
        verdict_text = reviewer_result.get("critique", "") or reviewer_result.get("text", "")
        score = float(reviewer_result.get("score", 0))
        verdict = reviewer_result.get("verdict", "FAIL")
        if not verdict_text and score:
            # Infer from score
            verdict = "PASS" if score >= 0.87 else "FAIL"
        stdout = "VERDICT: " + str(verdict) + "\nSCORE: " + str(score) + "\nCRITIQUE: " + str(verdict_text)
        rc = 0
        stderr = ""
        elapsed = 0.0  # ProviderRouter inline path is not separately timed;
        # without this, line ~3931 hits UnboundLocalError on every
        # complete_task whenever text_review succeeds.
    else:
        t0 = _time.monotonic()
        try:
            rc, stdout, stderr = call_claude_cli(
                prompt=prompt,
                system_prompt=persona,
                model=model,
                timeout_s=timeout_s,
            )
        except Exception as e:
            raise LiaisonReviewCallFailed(
                f"call_claude_cli raised unexpected exception: {e}"
            )
        elapsed = _time.monotonic() - t0

    if rc == 127:
        raise LiaisonCLIUnavailable(
            f"claude CLI not on PATH (rc=127). stderr: {stderr[:500]}"
        )

    if rc != 0:
        # F-DEEP-LIAISON-RETRY-PATH-1 + F-COMPANIES-USE-REMOTE-LIAISON-1: event-driven remote Liaison fallback via FleetBus
        try:
            from aibrain.core.remote_liaison import (
                publish_liaison_request_async,
                wait_for_verdict,
            )
            _publish_result = publish_liaison_request_async(task_id, str(work_output))
            if not _publish_result.get('ok'):
                log.warning('Remote Liaison publish failed: %s', _publish_result.get('error'))
            else:
                _payload = wait_for_verdict(
                    _publish_result['bus'],
                    _publish_result['reply_topic'],
                    timeout=360.0,
                )
                if _payload is not None:
                    verdict = _payload.get('verdict', 'FAIL')
                    score = float(_payload.get('score', 0))
                    critique = _payload.get('critique', 'Remote Liaison verdict — no local Claude CLI available')
                    record_liaison_verdict(task_id, verdict, score, critique, source='agent_review')
                    return {'verdict': verdict, 'score': score, 'critique': critique, 'source': 'remote_liaison', 'duration_s': 0.0, 'raw_stdout_chars': 0}
                log.warning('Remote Liaison timeout for %s after 360s', task_id)
        except Exception as _re:
            log.debug('Remote Liaison fallback failed: %s', _re)
    if rc == 124:
        raise LiaisonReviewCallFailed(
            f"claude CLI timed out after {timeout_s}s. "
            f"Task {task_id} review could not complete."
        )
    if rc != 0:
        # Detect "Not logged in" — CLI found but no auth (OAuth session
        # not accessible from Python subprocess). Raise LiaisonCLIUnavailable
        # so complete_task can fall back to DeepSeek Gate 2 instead of
        # treating this as a hard review failure.
        if "not logged in" in stdout.lower() or "please run /login" in stdout.lower():
            raise LiaisonCLIUnavailable(
                f"claude CLI is not authenticated (rc={rc}). "
                f"stdout: {stdout[:200]!r}. "
                f"This happens when complete_task() runs from a Python subprocess "
                f"that cannot access the Claude Code OAuth session. "
                f"complete_task() will fall back to DeepSeek for Gate 2."
            )
        raise LiaisonReviewCallFailed(
            f"claude CLI returned rc={rc}. stderr (first 500 chars): "
            f"{stderr[:500]}"
        )

    parsed = _parse_liaison_verdict(stdout)
    parsed["duration_s"] = round(elapsed, 2)
    parsed["raw_stdout_chars"] = len(stdout)
    return parsed


def _persist_critique(task_id, round_num, source, verdict, score, critique):
    try:
        import datetime
        db = _get_db()
        db.execute("INSERT INTO liaison_critique_history (task_id, round, source, verdict, score, critique, created_at) VALUES (?,?,?,?,?,?,?)", (task_id, round_num, source, verdict, score, critique, datetime.datetime.now().isoformat()))
    except Exception:
        pass


def record_liaison_verdict(task_id: str, verdict: str, score: float,
                           critique: str = "",
                           source: str = "agent_review",
                           majors: list = None,
                           liaison_instance_id: str = None) -> dict:
    """Record the Special Liaison Agent verdict to execution_log.

    Called by Neuro AFTER the Agent-based Special Liaison review runs and
    returns a verdict. Writes an execution_log row with actor='special_liaison'
    and success=1 (PASS) or success=0 (FAIL).

    Task sC9X5a7ytaY (2026-04-19): added ``source`` kwarg to close the
    author-self-reviews gaming class. Only rows with ``source='agent_review'``
    clear complete_task()'s Special Liaison gate — pre_filter and self_recorded
    stay in the audit trail but are informational, not gate-clearing.

    Args:
        task_id: The task that was reviewed.
        verdict: "PASS" or "FAIL".
        score: Quality score 0.0–1.0 from the liaison agent.
        critique: Explanation from the liaison agent.
        source: Provenance of the verdict. One of
            ``agent_review`` — real Special Liaison Agent tool verdict (default,
                gate-clearing). Use this ONLY when the caller is the Agent-tool
                worker that produced the verdict.
            ``pre_filter`` — review_task() regex pre-filter pass (audit only).
            ``self_recorded`` — author-supplied verdict (audit only, NEVER
                clears the gate). Use when a worker wants to log their own
                self-assessment without gaming the gate.
            ValueError on any other value.

    Returns:
        The execution_log row dict, or {"error": "..."} on failure.

    Falsifiability: after calling this with verdict="PASS" and the default
    source="agent_review", the query
        SELECT * FROM execution_log
        WHERE entity_id=<task_id> AND actor='special_liaison'
          AND success=1 AND source='agent_review'
    must return exactly one row (or more if called multiple times). If source
    is pre_filter or self_recorded, the gate query (complete_task) must NOT
    treat the row as gate-clearing.
    """
    import secrets as _secrets

    if verdict not in ("PASS", "FAIL"):
        return {"error": f"Invalid verdict '{verdict}' — must be 'PASS' or 'FAIL'"}

    if source not in VALID_LIAISON_SOURCES:
        raise ValueError(
            f"Invalid source '{source}' — must be one of {VALID_LIAISON_SOURCES}"
        )

    # FOLLOW-UPS enforcement: FAIL verdicts must reference follow-up actions
    # ds_pre_review is an internal regen signal, not an author-facing verdict — exempt
    if verdict == "FAIL" and source != "ds_pre_review":
        import re as _re
        _fu_pattern = _re.compile(
            r"follow.?up|FOLLOW.UP|next step|action item|must be",
            _re.IGNORECASE,
        )
        if not _fu_pattern.search(critique or ""):
            # F-LIAISON-FAIL-FOLLOWUPS-1: auto-stub instead of rejecting
            critique = (critique or "") + (
                "\n\nFOLLOW-UPS:\n"
                "- Re-review with thicker work_output OR re-file task with stronger AC"
            )

    success = 1 if verdict == "PASS" else 0
    run_id = _secrets.token_urlsafe(8)
    try:
        db = _get_db()
        # Migration-safe: add `source` column if this DB was initialised with
        # an older schema (tests or pre-v16 production DBs). Idempotent.
        try:
            db.execute("SELECT source FROM execution_log LIMIT 0")
        except Exception:
            try:
                db.execute("ALTER TABLE execution_log ADD COLUMN source TEXT DEFAULT NULL")
                db.commit()
                log.info("Migration: added source column to execution_log")
            except Exception as _e:
                log.debug("source column migration failed (non-fatal): %s", _e)
        try:
            from aibrain.core.db_safety import session_id as _sid
            _session_id = _sid()
        except Exception:
            _session_id = None
        _exec_id = _secrets.token_urlsafe(8)
        try:
            db.execute("ALTER TABLE execution_log ADD COLUMN text_id TEXT")
            db.commit()
        except Exception:
            pass
        db.execute("""
            INSERT INTO execution_log
            (text_id, run_id, actor, action, entity_type, entity_id,
             detail, quality_score, success, duration_ms,
             cost_cents, cost_cents_actual,
             task_type, verdict, critique, source, session_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """, (
            _exec_id,
            run_id,
            "special_liaison",
            f"agent_review:{task_id}",
            "company_issue", task_id,
            json.dumps({"verdict": verdict, "score": score, "critique": critique, "source": source}),
            score,
            success,
            0,
            0,
            0,
            "judgment",
            verdict,
            critique,
            source,
            _session_id,
        ))

        # Write to liaison_reviews audit table
        _review_id = _secrets.token_urlsafe(12)
        db.execute(
            """INSERT OR REPLACE INTO liaison_reviews
               (review_id, task_id, liaison_instance_id, verdict, score, majors, created_at)
               VALUES (?, ?, ?, ?, ?, ?, datetime('now'))""",
            (_review_id, task_id, liaison_instance_id, verdict, score,
             json.dumps(majors) if majors else None),
        )

        # Clear review_pending flag if the column exists
        try:
            db.execute(
                "UPDATE company_issues SET review_pending=0, updated_at=datetime('now') WHERE id=?",
                (task_id,),
            )
        except Exception:
            pass  # column may not exist on older schemas — non-fatal

        db.commit()
        result = dict(db.execute(
            "SELECT * FROM execution_log WHERE entity_id=? AND actor='special_liaison' ORDER BY id DESC LIMIT 1", (task_id,)
        ).fetchone())
    except Exception as e:
        log.error("record_liaison_verdict failed: %s", e)
        raise

    log.info(
        "Liaison verdict recorded: task=%s verdict=%s score=%.2f",
        task_id, verdict, score,
    )
    return result


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------

def request_approval(company_id: str, approval_type: str,
                     agent_id: str, payload: dict) -> dict:
    """Request board approval for an action."""
    db = _get_db()
    approval_id = secrets.token_urlsafe(8)

    db.execute("""
        INSERT INTO company_approvals (id, company_id, type, requested_by_agent_id, payload)
        VALUES (?, ?, ?, ?, ?)
    """, (approval_id, company_id, approval_type, agent_id, json.dumps(payload)))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())

    log.info("Approval requested: %s (company %s)", approval_type, company_id)
    return result


def approve(approval_id: str, note: str = "") -> dict:
    """Approve a pending request."""
    db = _get_db()
    db.execute("""
        UPDATE company_approvals
        SET status='approved', decision_note=?, decided_at=datetime('now')
        WHERE id=? AND status IN ('pending', 'revision_requested')
    """, (note, approval_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    return result


def reject(approval_id: str, note: str = "") -> dict:
    """Reject a pending request."""
    db = _get_db()
    db.execute("""
        UPDATE company_approvals
        SET status='rejected', decision_note=?, decided_at=datetime('now')
        WHERE id=? AND status IN ('pending', 'revision_requested')
    """, (note, approval_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    return result


def pending_approvals(company_id: str) -> list:
    """List pending approvals for a company."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM company_approvals WHERE company_id=? AND status IN ('pending','revision_requested') ORDER BY created_at",
        (company_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def all_approvals(company_id: str, limit: int = 100) -> list:
    """List all approvals for a company regardless of status."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM company_approvals WHERE company_id=? ORDER BY created_at DESC LIMIT ?",
        (company_id, limit)
    ).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_main(args: list):
    """Handle company CLI commands."""
    if not args:
        print("Usage:")
        print("  aibrain company create <name> [--mission <text>]")
        print("  aibrain company list")
        print("  aibrain company status <name_or_id>")
        print("  aibrain agent hire <name> --company <id> [--role ceo|manager|general]")
        print("  aibrain agent list --company <id>")
        print("  aibrain task create <title> --company <id> [--assign <agent_id>]")
        print("  aibrain task list --company <id>")
        print("  aibrain inbox --company <id>")
        print("  aibrain approve <approval_id>")
        print("  aibrain reject <approval_id>")
        return

    subcmd = args[0]

    if subcmd == "create":
        name = args[1] if len(args) > 1 else input("Company name: ")
        mission = ""
        if "--mission" in args:
            idx = args.index("--mission")
            mission = args[idx + 1] if idx + 1 < len(args) else ""
        result = create_company(name, mission)
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Company '{name}' created (ID: {result['id']})")

    elif subcmd == "list":
        companies = list_companies()
        if not companies:
            print("No companies. Create one: aibrain company create <name>")
        else:
            print(f"\n{'Name':<25} {'Status':<10} {'Agents':>7} {'ID'}")
            print("-" * 55)
            for c in companies:
                db = _get_db()
                agents = db.execute("SELECT COUNT(*) FROM company_agents WHERE company_id=?", (c['id'],)).fetchone()[0]
                print(f"{c['name']:<25} {c['status']:<10} {agents:>7} {c['id']}")

    elif subcmd == "status":
        company_ref = args[1] if len(args) > 1 else ""
        db = _get_db()
        company = db.execute("SELECT * FROM companies WHERE id=? OR name=?", (company_ref, company_ref)).fetchone()
        if not company:
            print(f"Company '{company_ref}' not found")
            return
        info = get_company(company["id"])
        print(f"\n  {info['name']} ({info['status']})")
        print(f"  Mission: {info.get('mission', '-')}")
        print(f"  Agents: {info['agent_count']}")
        print(f"  Active tasks: {info['active_tasks']}")
        print(f"  Completed: {info['completed_tasks']}")

    else:
        print(f"Unknown company command: {subcmd}")


# ---------------------------------------------------------------------------
# Teams
# ---------------------------------------------------------------------------

def _ensure_teams_table():
    """Create teams table if missing."""
    db = _get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS teams (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            name TEXT NOT NULL,
            agent_ids TEXT DEFAULT '[]',
            task_ids TEXT DEFAULT '[]',
            process TEXT DEFAULT 'sequential',
            status TEXT DEFAULT 'ready',
            last_run TEXT,
            last_result TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (company_id) REFERENCES companies(id)
        )
    """)
    db.commit()


_ensure_teams_table()


def _ensure_review_required_column():
    """Add review_required column to company_issues if it doesn't exist.

    Migration-safe: runs at module import. No-ops if column already present.
    """
    try:
        db = _get_db()
        db.execute("SELECT review_required FROM company_issues LIMIT 0")
    except Exception:
        try:
            db = _get_db()
            db.execute(
                "ALTER TABLE company_issues ADD COLUMN review_required INTEGER DEFAULT 0"
            )
            db.commit()
            log.info("Migration: added review_required column to company_issues")
        except Exception as e:
            log.debug("review_required column migration failed: %s", e)


_ensure_review_required_column()


def create_team(company_id: str, name: str, agent_ids: list = None,
                task_ids: list = None, process: str = "sequential") -> dict:
    """Create a team within a company from selected agents and tasks.

    If agent_ids is None, uses all company agents.
    If task_ids is None, uses all pending/todo tasks.
    """
    db = _get_db()

    # Verify company exists
    company = db.execute("SELECT id FROM companies WHERE id=?", (company_id,)).fetchone()
    if not company:
        return {"error": "Company not found"}

    # Resolve agent IDs — default to all company agents
    if agent_ids is None:
        rows = db.execute(
            "SELECT id FROM company_agents WHERE company_id=? AND status != 'terminated'",
            (company_id,)
        ).fetchall()
        agent_ids = [r["id"] for r in rows]

    # Resolve task IDs — default to all pending/todo tasks
    if task_ids is None:
        rows = db.execute(
            "SELECT id FROM company_issues WHERE company_id=? AND status IN ('backlog','todo','in_progress')",
            (company_id,)
        ).fetchall()
        task_ids = [r["id"] for r in rows]

    team_id = secrets.token_urlsafe(8)
    now = datetime.now().isoformat()

    db.execute("""
        INSERT INTO teams (id, company_id, name, agent_ids, task_ids, process, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (team_id, company_id, name, json.dumps(agent_ids), json.dumps(task_ids), process, now))
    db.commit()

    result = dict(db.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone())

    # Parse JSON fields for the response
    result["agent_ids"] = json.loads(result.get("agent_ids") or "[]")
    result["task_ids"] = json.loads(result.get("task_ids") or "[]")

    log.info("Team created: %s (%s) for company %s", name, team_id, company_id)
    return result


def list_teams(company_id: str) -> list:
    """List all teams for a company."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM teams WHERE company_id=? ORDER BY created_at DESC",
        (company_id,)
    ).fetchall()
    teams = []
    for r in rows:
        t = dict(r)
        t["agent_ids"] = json.loads(t.get("agent_ids") or "[]")
        t["task_ids"] = json.loads(t.get("task_ids") or "[]")
        teams.append(t)
    return teams


def get_team(team_id: str) -> Optional[dict]:
    """Get team details including agent and task info."""
    db = _get_db()
    row = db.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone()
    if not row:
        return None

    result = dict(row)
    result["agent_ids"] = json.loads(result.get("agent_ids") or "[]")
    result["task_ids"] = json.loads(result.get("task_ids") or "[]")

    # Enrich with agent details
    agents = []
    for aid in result["agent_ids"]:
        agent = db.execute("SELECT id, name, role, title, status FROM company_agents WHERE id=?", (aid,)).fetchone()
        if agent:
            agents.append(dict(agent))
    result["agents"] = agents

    # Enrich with task details
    tasks = []
    for tid in result["task_ids"]:
        task = db.execute("SELECT id, title, status, priority, quality_score FROM company_issues WHERE id=?", (tid,)).fetchone()
        if task:
            tasks.append(dict(task))
    result["tasks"] = tasks

    # Parse last_result if present
    if result.get("last_result"):
        try:
            result["last_result"] = json.loads(result["last_result"])
        except (json.JSONDecodeError, TypeError):
            pass

    return result


def delete_team(team_id: str) -> bool:
    """Delete a team."""
    db = _get_db()
    existing = db.execute("SELECT id FROM teams WHERE id=?", (team_id,)).fetchone()
    if not existing:
        return False
    db.execute("DELETE FROM teams WHERE id=?", (team_id,))
    db.commit()
    log.info("Team deleted: %s", team_id)
    return True


def run_team(company_id: str, team_id: str, inputs: dict = None) -> dict:
    """Execute a team — assembles Agent/Task objects, creates Team, calls kickoff().

    Stores results back to the company tasks (updates status, stores output).
    """
    db = _get_db()
    team_row = db.execute(
        "SELECT * FROM teams WHERE id=? AND company_id=?",
        (team_id, company_id)
    ).fetchone()
    if not team_row:
        return {"error": "Team not found"}

    team_data = dict(team_row)
    agent_ids = json.loads(team_data.get("agent_ids") or "[]")
    task_ids = json.loads(team_data.get("task_ids") or "[]")
    process = team_data.get("process", "sequential")

    # Mark team as running
    db.execute("UPDATE teams SET status='running' WHERE id=?", (team_id,))
    db.commit()

    try:
        from aibrain.core.agents import Agent, Task, Team

        # Build Agent objects from DB
        agent_map = {}
        agents = []
        for aid in agent_ids:
            db_agent = get_agent(aid)
            if not db_agent:
                continue
            agent = Agent(
                id=db_agent["id"],
                role=db_agent.get("role", "general"),
                goal=db_agent.get("title", db_agent.get("name", "")),
                llm=db_agent.get("model", "auto"),
                backstory=db_agent.get("capabilities", ""),
            )
            agents.append(agent)
            agent_map[aid] = agent

        # Build Task objects from DB
        tasks = []
        for tid in task_ids:
            db2 = _get_db()
            db_task = db2.execute("SELECT * FROM company_issues WHERE id=?", (tid,)).fetchone()
            if not db_task:
                continue
            db_task = dict(db_task)
            assignee = agent_map.get(db_task.get("assignee_agent_id", ""))
            task = Task(
                id=db_task["id"],
                description=db_task.get("title", ""),
                expected_output=db_task.get("description", "Complete the task successfully"),
                agent=assignee,
            )
            tasks.append(task)

        if not agents:
            db = _get_db()
            db.execute("UPDATE teams SET status='failed', last_run=datetime('now') WHERE id=?", (team_id,))
            db.commit()
            return {"error": "No valid agents found for this team"}

        if not tasks:
            db = _get_db()
            db.execute("UPDATE teams SET status='failed', last_run=datetime('now') WHERE id=?", (team_id,))
            db.commit()
            return {"error": "No valid tasks found for this team"}

        # Create and run the Team
        company = get_company(company_id)
        team = Team(
            name=company.get("name", "team") + "/" + team_data.get("name", "team"),
            agents=agents,
            tasks=tasks,
            process=process,
            memory=True,
        )

        team_output = team.kickoff(inputs=inputs or {})

        # Store results back
        result_dict = team_output.model_dump()
        db = _get_db()

        # Update task statuses with quality scores
        for task_out in team_output.task_outputs:
            if task_out.task_id:
                db.execute("""
                    UPDATE company_issues
                    SET status='done', quality_score=?, completed_at=datetime('now'), updated_at=datetime('now')
                    WHERE id=?
                """, (task_out.quality, task_out.task_id))

        # Update team record
        db.execute("""
            UPDATE teams SET status='completed', last_run=datetime('now'), last_result=?
            WHERE id=?
        """, (json.dumps(result_dict), team_id))
        db.commit()

        log.info("Team run completed: %s (success=%s)", team_id, team_output.success)
        return result_dict

    except Exception as e:
        log.error("Team run failed: %s — %s", team_id, e)
        db = _get_db()
        db.execute("""
            UPDATE teams SET status='failed', last_run=datetime('now'),
            last_result=? WHERE id=?
        """, (json.dumps({"error": str(e)}), team_id))
        db.commit()
        return {"error": str(e), "success": False}


# ---------------------------------------------------------------------------
# Retry-wrapped public API
#
# The four core task-management functions are wrapped with _call_with_retry so
# transient DB-lock / startup failures are retried automatically (3 × 2 s).
# On exhaustion the caller gets RuntimeError(_BACKEND_OFFLINE_MSG) which names
# the exact restart command.
#
# Implementation note: we alias the original implementations to _impl_* names
# and replace the module-level names with thin wrappers.  All original
# signatures are preserved (wrappers forward *args/**kwargs).  Internal callers
# that reference the bare name (e.g. complete_task() calling checkout_task()
# indirectly via _recover_stale_tasks_for_db) are unaffected because they go
# through the module namespace and pick up the wrapper.
#
# Falsifiability: call any of the four functions with a corrupted DB path and
# confirm (a) the WARNING log fires on attempts 1–2, (b) the ERROR log fires
# on attempt 3, and (c) RuntimeError("aibrain backend offline …") is raised.
# ---------------------------------------------------------------------------

_impl_create_task = create_task
_impl_checkout_task = checkout_task
_impl_complete_task = complete_task
_impl_review_task = review_task


def create_task(company_id: str, title: str, description: str = "",
                assignee_agent_id: str = None, priority: str = "medium",
                parent_id: str = None, project: str = "",
                auto_route: bool = True) -> dict:
    """Retry-wrapped version of create_task. See _impl_create_task for docs."""
    return _call_with_retry(
        _impl_create_task,
        company_id, title, description,
        assignee_agent_id=assignee_agent_id, priority=priority,
        parent_id=parent_id, project=project, auto_route=auto_route,
    )


def checkout_task(task_id: str, agent_id: str) -> dict:
    """Retry-wrapped version of checkout_task. See _impl_checkout_task for docs."""
    return _call_with_retry(_impl_checkout_task, task_id, agent_id)


def complete_task_with_regen_dispatch(task_id, work_output="", max_regen_rounds=2, regen_on_stalemate=False, **kwargs):
    """F-DEEP-LIAISON-STALEMATE-REGEN-DISPATCH-1."""
    import sqlite3 as _sq3
    from aibrain.core.companies import complete_task as _ct
    if not regen_on_stalemate:
        return _ct(task_id, work_output=work_output, **kwargs)
    wo = work_output
    for rnd in range(1, max_regen_rounds + 1):
        try:
            return _ct(task_id, work_output=wo, **kwargs)
        except Exception as e:
            if rnd >= max_regen_rounds:
                raise
            db = _sq3.connect("aibrain.db"); db.row_factory = _sq3.Row
            row = db.execute("SELECT critique FROM liaison_critique_history WHERE task_id=? ORDER BY round DESC LIMIT 1", (task_id,)).fetchone()
            crit = row["critique"] if row else str(e)[:500]; db.close()
            log.warning("Regen round %d for %s", rnd, task_id)
            wo = wo + chr(10) + chr(10) + "[REGEN ROUND " + str(rnd) + ": " + str(crit[:200]) + "]"
    return _ct(task_id, work_output=wo, **kwargs)

def complete_task(task_id: str, quality_score: float = None,
                  cost_cents: Optional[int] = None,
                  output: object = None, repo_path: str = None,
                  test_cmd: str = None, work_output: object = None,
                  require_verification: bool = True,
                  require_review: bool = False,
                  notes: str = None,
                  skip_liaison_review: bool = False,
                  skip_reason: Optional[str] = None,
                  retry_handler: Optional[Callable[[str, dict], str]] = None,
                  actor_agent_id: Optional[str] = None) -> dict:
    """Retry-wrapped version of complete_task. See _impl_complete_task for docs."""
    return _call_with_retry(
        _impl_complete_task,
        task_id,
        quality_score=quality_score, cost_cents=cost_cents,
        output=output, repo_path=repo_path, test_cmd=test_cmd,
        work_output=work_output, require_verification=require_verification,
        require_review=require_review, notes=notes,
        skip_liaison_review=skip_liaison_review, skip_reason=skip_reason,
        retry_handler=retry_handler,
        actor_agent_id=actor_agent_id,
    )


def review_task(task_id: str, output: str,
                reviewer: str = "special_liaison") -> dict:
    """Retry-wrapped version of review_task. See _impl_review_task for docs."""
    return _call_with_retry(_impl_review_task, task_id, output, reviewer)


# ---------------------------------------------------------------------------
# Decker-only escalation primitives — unblock tasks stuck in review stalemate
# ---------------------------------------------------------------------------

def override_task(task_id: str, note: str) -> dict:
    """Decker-only: bypass review and complete a stalemate task. Records override note."""
    db = _get_db()
    db.execute(
        "UPDATE company_issues SET status='done', terminal_state='override', "
        "updated_at=datetime('now') WHERE id=?",
        (task_id,),
    )
    db.commit()
    db.close()
    record_liaison_verdict(
        task_id, verdict="PASS", score=1.0,
        critique=f"DECKER OVERRIDE: {note} — follow-up: none required, override is final",
        source="agent_review",
    )
    return {"task_id": task_id, "action": "override", "note": note}


def reassign_task(task_id: str, agent_id: str) -> dict:
    """Decker-only: hand stalemate task to a different agent, reset review_round."""
    db = _get_db()
    db.execute(
        "UPDATE company_issues SET assignee_agent_id=?, review_round=0, "
        "status='in_progress', terminal_state=NULL, updated_at=datetime('now') WHERE id=?",
        (agent_id, task_id),
    )
    db.commit()
    db.close()
    return {"task_id": task_id, "action": "reassign", "new_agent": agent_id}


def rescope_task(task_id: str, new_description: str) -> dict:
    """Decker-only: rewrite task description + reset review_round counter."""
    db = _get_db()
    db.execute(
        "UPDATE company_issues SET description=?, review_round=0, "
        "status='todo', terminal_state=NULL, updated_at=datetime('now') WHERE id=?",
        (new_description, task_id),
    )
    db.commit()
    db.close()
    return {"task_id": task_id, "action": "rescope"}


def abandon_task(task_id: str) -> dict:
    """Decker-only: mark task abandoned — no completion, no retry.

    Uses the schema-valid status='cancelled' with a terminal_state of
    'abandoned_review_stalemate' so the abandonment reason is preserved
    in the audit trail. Previously tried to set status itself to
    'abandoned_review_stalemate', which the company_issues CHECK
    constraint rejects (status must be one of: backlog, todo,
    in_progress, in_review, done, blocked, cancelled, needs_human_review).
    Caught when trying to abandon two GoalEngine gate-orphan duplicates
    in the 2026-05-24 session.
    """
    db = _get_db()
    db.execute(
        "UPDATE company_issues SET status='cancelled', "
        "terminal_state='abandoned_review_stalemate', updated_at=datetime('now') WHERE id=?",
        (task_id,),
    )
    db.commit()
    db.close()
    return {"task_id": task_id, "action": "abandon",
            "status": "cancelled", "terminal_state": "abandoned_review_stalemate"}
