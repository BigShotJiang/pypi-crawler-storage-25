"""
seed_memories.py — Pre-populates a fresh AIBrain install with factual memories
about the product itself.

When users ask AIBrain about itself, it can answer immediately without needing
to search external sources. All facts here are verified from benchmarks
(exp37_full_results.json) and product code.

Usage:
    python aibrain/data/seed_memories.py
    python aibrain/data/seed_memories.py --force   # re-seed even if memories exist
"""

import sys
from pathlib import Path

# Ensure project root is on path so aibrain_db is importable
_project_root = Path(__file__).resolve().parent.parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

import aibrain_db

SEED_TAG = "seed,aibrain,product-knowledge"
SOURCE_AGENT = "seed_memories"

SEED_MEMORIES = [
    # ── Benchmark facts ──────────────────────────────────────────────────────
    {
        "name": "selroute_benchmark_longmemeval_m",
        "type": "knowledge",
        "tags": "selroute,benchmarks,retrieval,performance",
        "importance": 0.95,
        "content": (
            "SelRoute achieves Ra@5=0.789 and NDCG@5=0.796 on the LongMemEval_M benchmark "
            "(n=470 queries). This ranks #1 on that benchmark, beating Meta Contriever "
            "(Ra@5=0.723, 110M parameters) and Stella V5 1.5B (Ra@5=0.720, 1.5 billion parameters) "
            "while using only 22M parameters and requiring zero GPU."
        ),
    },
    {
        "name": "selroute_oracle_split_accuracy",
        "type": "knowledge",
        "tags": "selroute,benchmarks,retrieval,oracle",
        "importance": 0.90,
        "content": (
            "On the LongMemEval Oracle split (ideal routing conditions), SelRoute achieves "
            "Ra@5=0.992 — near-perfect retrieval. This is the upper bound that demonstrates "
            "the architecture is sound: when the routing decision is optimal, recall is essentially perfect."
        ),
    },
    {
        "name": "selroute_fts5_locomo_finding",
        "type": "knowledge",
        "tags": "selroute,fts5,benchmarks,retrieval,locomo",
        "importance": 0.92,
        "content": (
            "Counter-intuitive finding from the SelRoute benchmarks: FTS5 (pure keyword search, "
            "zero ML, zero parameters) outperforms ALL embedding models on the LoCoMo conversational "
            "memory benchmark. SelRoute detects these query types and automatically routes to FTS5. "
            "Routing to zero-ML was not the plan — it was the discovery. This changed how SelRoute "
            "was designed."
        ),
    },
    {
        "name": "selroute_parameter_efficiency",
        "type": "knowledge",
        "tags": "selroute,benchmarks,efficiency,contriever",
        "importance": 0.88,
        "content": (
            "SelRoute uses 22M parameters (MiniLM-L6-v2) versus Contriever's 110M parameters — "
            "5x fewer parameters — yet achieves higher accuracy on LongMemEval_M (Ra@5=0.789 vs 0.723). "
            "Parameter count is not the primary driver of retrieval quality; routing queries to "
            "the right strategy is."
        ),
    },
    # ── Design origins ───────────────────────────────────────────────────────
    {
        "name": "aibrain_cls_theory_foundation",
        "type": "knowledge",
        "tags": "architecture,cls,neuroscience,design",
        "importance": 0.93,
        "content": (
            "AIBrain is built on Complementary Learning Systems (CLS) theory — the dual-memory "
            "architecture of biological brains. CLS describes two complementary systems: "
            "(1) a fast hippocampal system that captures new events quickly but fades without "
            "consolidation, and (2) a slow neocortical system that builds stable patterns through "
            "repeated reinforcement. AIBrain implements both: episodic memory for recent events, "
            "semantic memory for consolidated long-term knowledge."
        ),
    },
    {
        "name": "aibrain_dream_cycle",
        "type": "knowledge",
        "tags": "architecture,dream,consolidation,design",
        "importance": 0.90,
        "content": (
            "The 'aibrain dream' command runs a nightly consolidation pass that mimics biological "
            "sleep consolidation. During the dream cycle, AIBrain replays recent episodic memories, "
            "extracts stable patterns, and promotes them to long-term semantic memory. This is the "
            "mechanism by which the brain compounds across sessions — without the dream cycle, "
            "knowledge accumulates but doesn't consolidate."
        ),
    },
    {
        "name": "aibrain_heraclitean_memory",
        "type": "knowledge",
        "tags": "architecture,philosophy,retrieval,design",
        "importance": 0.88,
        "content": (
            "AIBrain implements the Heraclitean memory principle: every retrieval reshapes what is "
            "stored. 'You can't step in the same river twice.' When AIBrain retrieves a memory, "
            "the act of retrieval slightly updates the memory's weight, recency, and connections. "
            "Memory is a living process, not static storage — consistent with how human memory "
            "actually works (each recall reconstructs and modifies the trace)."
        ),
    },
    {
        "name": "aibrain_connectome_metaphor",
        "type": "knowledge",
        "tags": "architecture,knowledge-graph,design",
        "importance": 0.85,
        "content": (
            "AIBrain models knowledge as a graph of relationships (the connectome metaphor), not a "
            "flat list of facts. When a fact is stored, the system also extracts and stores how "
            "that fact connects to related concepts via entities, entity_links, and semantic_facts "
            "tables. Retrieval can traverse these connections, surfacing related context the user "
            "didn't explicitly query for."
        ),
    },
    {
        "name": "aibrain_three_forgetting_mechanisms",
        "type": "knowledge",
        "tags": "architecture,forgetting,decay,design",
        "importance": 0.87,
        "content": (
            "AIBrain has three built-in forgetting mechanisms — by design, not as bugs: "
            "(1) Temporal decay: old unused memories fade over time proportional to their importance. "
            "(2) Importance weighting: low-signal memories fade faster than high-signal ones. "
            "(3) Conflict resolution: when a new fact contradicts an existing one, the older or "
            "lower-confidence fact is demoted. Forgetting is how the brain stays coherent as new "
            "information arrives."
        ),
    },
    # ── Product facts ────────────────────────────────────────────────────────
    {
        "name": "aibrain_version_and_scale",
        "type": "knowledge",
        "tags": "product,version,workflows,dashboard",
        "importance": 0.85,
        "content": (
            "AIBrain v1.5.33 ships with 79 workflow automations and 42 dashboard pages. "
            "It is pure Python, MIT licensed, and runs entirely locally with no cloud dependency "
            "required for core functionality."
        ),
    },
    {
        "name": "aibrain_default_embedding_model",
        "type": "knowledge",
        "tags": "product,embeddings,minilm,hardware",
        "importance": 0.90,
        "content": (
            "AIBrain's default embedding model is MiniLM-L6-v2 at 22MB. It runs entirely on CPU — "
            "no GPU required. This means AIBrain works on a laptop, a VPS, or any machine with "
            "Python installed, with no special hardware. The model is downloaded once on first use "
            "and cached locally."
        ),
    },
    {
        "name": "aibrain_sqlite_architecture",
        "type": "knowledge",
        "tags": "product,sqlite,database,architecture",
        "importance": 0.88,
        "content": (
            "AIBrain stores the brain in a single SQLite file running in WAL mode. There is no "
            "database server, no ports to configure, and no Docker required for the core brain. "
            "The brain is a file — it can be copied, backed up, moved between machines, and "
            "exported to the Brain Marketplace as a portable .db file."
        ),
    },
    {
        "name": "aibrain_retrieval_modes",
        "type": "knowledge",
        "tags": "product,retrieval,fts5,embeddings,selroute",
        "importance": 0.90,
        "content": (
            "AIBrain has three retrieval modes: (1) Semantic search using MiniLM-L6-v2 embeddings "
            "stored in SQLite-vec. (2) Keyword search using SQLite FTS5 full-text search — zero ML, "
            "zero parameters, often the fastest and most accurate for factual queries. "
            "(3) Hybrid routing via SelRoute, which classifies each query and routes to the optimal "
            "retrieval strategy (or fuses multiple strategies via reciprocal rank fusion)."
        ),
    },
    {
        "name": "aibrain_agent_agnostic",
        "type": "knowledge",
        "tags": "product,compatibility,agents,llm",
        "importance": 0.88,
        "content": (
            "AIBrain is agent-agnostic by design. The brain layer (memory, retrieval, consolidation) "
            "is completely separate from the model layer. AIBrain works with Claude, OpenAI GPT models, "
            "DeepSeek, Ollama (local models), or any LLM that accepts a text interface. There is no "
            "Claude dependency for the core memory system."
        ),
    },
    {
        "name": "aibrain_fts5_primary_retrieval_path",
        "type": "knowledge",
        "tags": "product,fts5,retrieval,performance",
        "importance": 0.85,
        "content": (
            "FTS5 full-text search is the primary retrieval path for most query types in AIBrain. "
            "Despite being zero-ML, FTS5 is highly competitive with embedding-based search for "
            "factual, keyword-heavy, and conversational queries. SelRoute uses FTS5 as the dominant "
            "path for these query classes, saving compute while maintaining accuracy."
        ),
    },
    {
        "name": "aibrain_what_it_is",
        "type": "knowledge",
        "tags": "product,overview,identity",
        "importance": 0.95,
        "content": (
            "AIBrain is a portable cognitive substrate for AI agents — a persistent memory system "
            "built on Complementary Learning Systems (CLS) dual-memory architecture with a nightly "
            "consolidation cycle. It gives agents persistent memory that compounds across sessions, "
            "79 workflow automations, 42 dashboard pages, and a Brain Marketplace for sharing trained "
            "brains. Free, Pro ($9.95/mo), and Team ($29.95/mo) tiers. Published on PyPI as 'aibrain'."
        ),
    },
]


def seed_memories(force: bool = False) -> int:
    """Insert product knowledge memories into a fresh AIBrain install.

    Args:
        force: If True, seeds even if memories already exist in the DB.
               If False (default), skips when the DB has any active memories.

    Returns:
        Number of memories actually inserted.
    """
    db = aibrain_db.get_db()

    # Check if any memories exist already
    existing_count = db.execute(
        "SELECT COUNT(*) FROM memories WHERE active = 1"
    ).fetchone()[0]

    if existing_count > 0 and not force:
        print(
            f"[seed_memories] DB already has {existing_count} memories — skipping. "
            f"Use force=True or --force to re-seed."
        )
        return 0

    inserted = 0
    skipped = 0

    for mem in SEED_MEMORIES:
        result = aibrain_db.create_memory(
            name=mem["name"],
            mem_type=mem["type"],
            content=mem["content"],
            tags=f"{SEED_TAG},{mem.get('tags', '')}",
            importance=mem.get("importance", 0.85),
            source_agent=SOURCE_AGENT,
        )
        # create_memory returns int (new ID) or dict (dedup action)
        if isinstance(result, int):
            inserted += 1
        else:
            # Dedup fired — memory already exists or was reinforced
            action = result.get("action", "unknown")
            skipped += 1
            print(f"[seed_memories] Skipped '{mem['name']}' — dedup action: {action}")

    print(f"[seed_memories] Done: {inserted} inserted, {skipped} skipped (dedup).")
    return inserted


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Seed AIBrain with product knowledge memories."
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-seed even if memories already exist in the DB.",
    )
    args = parser.parse_args()

    n = seed_memories(force=args.force)
    print(f"Seeded {n} memories.")
