"""
Lucy — autonomous agent CLI with AIBrain memory and DeepSeek backend.

Usage:
    lucy                       # interactive mode
    lucy --verbose 1           # glass mode: show background tool ops
    lucy --verbose 2           # transparent mode: full process detail
    lucy --help                # show help

Commands:
    /help               — list commands
    /status             — show active project goal state
    /loop --project X --goal "Y" --criteria "A" "B"
          — jack in: run autonomous goal loop
    /memory <query>     — search your memory
    /task <title>       — quick-create a task
    /tasks              — list pending tasks
    /ping <message>     — send Telegram DM to Decker
    /verbose [0|1|2]    — show background ops (0=off, 1=glass, 2=transparent)
    /switch [prov] [mdl] — swap provider (no args = pick from menu)
    /model              — pick a model for the current provider (menu)
    /providers          — list all 7 providers + active marker
    /pricing            — show per-provider USD/MTok rates
    /quit               — exit
"""

from __future__ import annotations

import argparse
import base64
import datetime
import json
import os
import queue
import shlex
import shutil
import sys
import threading
import time
from pathlib import Path

import requests

# ---------------------------------------------------------------------------
# ANSI colors — enable on Windows
# ---------------------------------------------------------------------------
if sys.platform == "win32":
    os.system("")  # enables ANSI escape sequences in Windows Terminal

YELLOW   = "\033[93m"                   # Lucy ASCII art / accent text
BLUE     = "\033[94m"                   # Lines, separators, frame
SKY_BLUE = "\033[38;2;135;206;235m"    # Lucy's response text
ORANGE   = "\033[38;2;255;165;0m"      # User prompt
RED      = "\033[91m"                   # Errors / warnings
DIM      = "\033[2m"
RESET    = "\033[0m"

# ---------------------------------------------------------------------------
# Verbosity — 0=silent, 1=glass (tool calls), 2=transparent (full detail)
# ---------------------------------------------------------------------------
_VERBOSE = 0


def _log_tool(msg: str, level: int = 1) -> None:
    """Print a background process hint if verbosity level permits."""
    if _VERBOSE >= level:
        print(f"{DIM}  ↳ {msg}{RESET}")

# ---------------------------------------------------------------------------
# Optional: prompt_toolkit — paste handling + history
# ---------------------------------------------------------------------------
try:
    from prompt_toolkit import prompt as _pt_prompt, PromptSession as _PromptSession
    from prompt_toolkit.formatted_text import ANSI as _ANSI
    from prompt_toolkit.history import InMemoryHistory as _History
    from prompt_toolkit.patch_stdout import patch_stdout as _patch_stdout
    from prompt_toolkit.key_binding import KeyBindings as _KeyBindings
    _PT = True
except ImportError:
    _PT = False
    _patch_stdout = None  # type: ignore
    _KeyBindings = None  # type: ignore

_pt_history = _History() if _PT else None  # type: ignore

# F-LUCY-CTRL-B-INTERRUPT-1 / F-LUCY-SAFESTOP-1: Ctrl+B and ESC keybindings.
# Sets the cooperative cancel flag; the tool loop / dispatch / complete_task
# checks it between steps and returns to prompt cleanly. Binds BOTH Ctrl+B
# and ESC (at-prompt parity). Mid-loop interrupt is handled by the background
# raw-key listener below (prompt_toolkit bindings only fire at the prompt).
if _PT and _KeyBindings is not None:
    _PASTE_STORE: dict[int, str] = {}
    _PASTE_SEQ = [0]
    _pt_kb = _KeyBindings()

    @_pt_kb.add('c-b')
    def _handle_ctrl_b(event):
        from aibrain.core.cancel_flag import request_cancel
        request_cancel()
        event.app.invalidate()  # repaint prompt area
        print(f"\n{ORANGE}[interrupt requested — finishing current step then returning to prompt]{RESET}")

    @_pt_kb.add('escape')
    def _handle_esc(event):
        from aibrain.core.cancel_flag import request_cancel
        request_cancel()
        event.app.invalidate()
        print(f"\n{ORANGE}[interrupt requested (Esc) — finishing current step then returning to prompt]{RESET}")

    @_pt_kb.add('enter')
    def _submit(event):
        import re
        text = event.current_buffer.text

        def _expand(m):
            n = int(m.group(1))
            return _PASTE_STORE.get(n, m.group(0))

        text = re.sub(r'\[Pasted text #(\d+) \+\d+ lines\]', _expand, text)
        event.current_buffer.text = text
        event.current_buffer.validate_and_handle()

    @_pt_kb.add('<bracketed-paste>')
    def _on_paste(event):
        # Always insert the full paste text directly. No placeholder
        # substitution dance — that was a failure surface when the
        # placeholder regex didn't round-trip on edit.
        event.current_buffer.insert_text(event.data)
else:
    _pt_kb = None


class _RawKeyListener:
    """F-LUCY-SAFESTOP-1: cross-platform raw-stdin listener so Esc / Ctrl+B
    cancel Lucy DURING the agent loop (prompt_toolkit bindings only fire at
    the prompt). Armed only around the processing span; no-op when stdin is
    not a TTY (daemon / Scheduled Task / CI) — never raises."""

    def __init__(self):
        import threading
        self._armed = False
        self._lock = threading.Lock()
        self._old_settings = None
        self._thread = None
        try:
            self._tty = sys.stdin.isatty()
        except Exception:
            self._tty = False

    def arm(self):
        import threading
        if not self._tty:
            return
        # F-LUCY-RAWKEY-WINDOWS-DISABLE-1: on Windows, the type_ahead_collector
        # thread already reads stdin via msvcrt.getwch() and handles both
        # queued-input capture AND Ctrl+B cancellation. Arming RawKeyListener
        # creates a second stdin reader that RACES with the type-ahead collector.
        # Every character RawKeyListener wins is a character the type-ahead
        # collector never sees — the root cause of "does something" becoming
        # "ds emthaewk sdoit". The fix is NOT to forward characters (that creates
        # single-char STEER messages) but to STAY OUT of stdin entirely on Windows
        # and let the type-ahead collector be the sole reader.
        if sys.platform == "win32":
            return
        with self._lock:
            if self._armed:
                return
            self._armed = True
            try:
                import termios
                fd = sys.stdin.fileno()
                self._old_settings = termios.tcgetattr(fd)
                new = termios.tcgetattr(fd)
                new[3] = new[3] & ~(termios.ECHO | termios.ICANON)
                new[6][termios.VMIN] = 0
                new[6][termios.VTIME] = 1
                termios.tcsetattr(fd, termios.TCSANOW, new)
            except Exception:
                self._armed = False
                self._tty = False
                return
            self._thread = threading.Thread(target=self._listen, daemon=True)
            self._thread.start()

    def disarm(self):
        if not self._tty:
            return
        with self._lock:
            if not self._armed:
                return
            self._armed = False
            if sys.platform != "win32" and self._old_settings:
                try:
                    import termios
                    termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, self._old_settings)
                except Exception:
                    pass

    def _listen(self):
        import time as _t
        while self._armed:
            try:
                ch = self._read_key()
                if ch and (ch == "\x1b" or ch == "\x02"):
                    from aibrain.core.cancel_flag import request_cancel
                    request_cancel()
                elif ch is not None:
                    # F-LUCY-RAWKEY-FORWARD-FIX-1: RawKeyListener and
                    # type_ahead_collector both call msvcrt.getwch(). When
                    # RawKeyListener wins the race and reads a non-ESC/Ctrl+B
                    # character, it was silently dropping it — the type_ahead
                    # collector never saw it. "does something" became
                    # "ds emthaewk sdoit". Now we forward non-control chars
                    # into the type-ahead queue so nothing is lost.
                    if ch.isprintable() or ch in ("\t", "\r", "\n", "\x08"):
                        _typing_queue.put(ch)
                elif ch is None:
                    _t.sleep(0.05)  # prevent win32 busy-spin (msvcrt is non-blocking)
            except Exception:
                break

    def _read_key(self):
        if sys.platform == "win32":
            import msvcrt
            if msvcrt.kbhit():
                return msvcrt.getwch()
            return None
        import select
        r, _, _ = select.select([sys.stdin], [], [], 0.1)
        if r:
            return sys.stdin.read(1)
        return None


_raw_key_listener = _RawKeyListener()

# F-LUCY-INPUT-CLEAN-1: singleton PromptSession so input state (history, cursor,
# completion) survives across _read_input() calls. Matches Claude Code's pattern
# where input is a stable buffer separate from streaming output.
#
# F-LUCY-PROMPT-TOOLKIT-TTY-SOFT-FAIL-1 (rewritten 2026-05-23):
# prompt_toolkit's _PromptSession.__init__ attaches to /dev/tty (or Windows
# console equivalent) at construction time. When called from a non-TTY
# context it raises. The OLD behaviour was: try to init at module load,
# on failure silently fall back to bare input() forever. That meant if
# the FIRST _read_input call was in a non-TTY context (e.g. early SDK
# import), PT was permanently disabled even when later prompts ran in a
# real TTY. Result: paste fragmented because bare input() has no concept
# of bracketed-paste.
#
# NEW behaviour: lazy init + retry per _read_input call. Loud red banner
# on init failure so the user can SEE which input mode is active. Also
# write \x1b[?2004h directly to stdout on first successful PT init as a
# belt-suspender — PT's enable_bracketed_paste=True should already do
# this, but Windows Terminal sometimes drops the sequence if the prompt
# fires before terminal state settles.
_pt_session = None
_pt_init_attempted_once = False
_pt_mode_banner_printed = False


def _try_init_pt_session():
    """Attempt to build a fresh _PromptSession. On success store globally
    and print a one-time banner. On failure print a one-time loud red
    banner explaining why bare input() is being used. Returns the session
    or None.
    """
    global _pt_session, _pt_init_attempted_once, _pt_mode_banner_printed
    if _pt_session is not None:
        return _pt_session
    if not _PT:
        if not _pt_mode_banner_printed:
            print(f"{RED}[INPUT] prompt_toolkit unavailable — bare stdin "
                  f"fallback active. Multi-line paste WILL fragment.{RESET}")
            _pt_mode_banner_printed = True
        return None
    try:
        # F-LUCY-PT-INIT-NO-BRACKETED-KWARG-1 (2026-05-24): PromptSession
        # in PT 3.0.52 (and other 3.0.x versions) does NOT accept
        # `enable_bracketed_paste` as a constructor kwarg — raises
        # TypeError. The kwarg was added in a later PT minor; older PT
        # versions silently fall to bare stdin which is why Decker's
        # multi-line pastes have been fragmenting for months. The
        # `@kb.add('<bracketed-paste>')` binding registered on _pt_kb
        # ALREADY tells the input parser to dispatch paste events;
        # the constructor kwarg was redundant. Removed it entirely so
        # init succeeds on any PT 3.x.
        if _pt_kb is not None:
            session = _PromptSession(  # type: ignore
                history=_pt_history,
                key_bindings=_pt_kb,
                multiline=True,
            )
        else:
            session = _PromptSession(  # type: ignore
                history=_pt_history,
                multiline=True,
            )
        _pt_session = session
        # Belt-and-suspenders: explicitly tell the terminal to enter
        # bracketed-paste mode. Some Windows Terminal builds drop PT's
        # internal enable if the prompt fires before terminal state
        # settles.
        try:
            sys.stdout.write("\x1b[?2004h")
            sys.stdout.flush()
        except Exception:
            pass
        if not _pt_mode_banner_printed:
            print(f"{DIM}[INPUT] prompt_toolkit ready "
                  f"(bracketed-paste enabled, multi-line on){RESET}")
            _pt_mode_banner_printed = True
        return _pt_session
    except Exception as _err:
        if not _pt_init_attempted_once:
            print(f"{RED}[INPUT] prompt_toolkit init failed: "
                  f"{type(_err).__name__}: {str(_err)[:140]}{RESET}")
            print(f"{RED}[INPUT] falling back to bare stdin — multi-line "
                  f"paste WILL fragment until PT init succeeds.{RESET}")
            _pt_init_attempted_once = True
            _pt_mode_banner_printed = True
        return None


def _read_input() -> str:
    prompt_str = f"{ORANGE}you ›{RESET} "
    # Lazy init: retry every prompt until PT works. Once it does, the
    # global is cached and subsequent prompts skip the retry path.
    session = _try_init_pt_session()
    if session is not None:
        try:
            return session.prompt(_ANSI(prompt_str))  # type: ignore
        except KeyboardInterrupt:
            raise
        except Exception as _err:
            # PT prompt failed mid-flight — surface the error so the user
            # knows why this turn fell to bare stdin.
            print(f"{RED}[INPUT] prompt_toolkit.prompt failed mid-call: "
                  f"{type(_err).__name__}: {str(_err)[:140]} — bare stdin "
                  f"for this turn only.{RESET}")
    return input(prompt_str)


def _streaming_output_context():
    """F-LUCY-INPUT-CLEAN-1: context manager wrapping streaming output so prints
    from chat() and tool calls do NOT garble a user-typed input buffer below.
    Returns prompt_toolkit's patch_stdout() when available, otherwise a no-op
    context manager so callers can use `with _streaming_output_context():` uniformly.
    """
    if _PT and _patch_stdout is not None:
        try:
            return _patch_stdout(raw=True)  # type: ignore
        except Exception:
            pass
    # Fallback: no-op context
    from contextlib import nullcontext
    return nullcontext()


# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------
AIBRAIN_DIR     = Path.home() / ".aibrain"
CONFIG_FILE     = AIBRAIN_DIR / "config.json"
SESSION_FILE    = AIBRAIN_DIR / "lucy_session.json"
FIRST_BOOT_FLAG = AIBRAIN_DIR / "lucy_first_boot_done"
DOSSIER_FILE    = AIBRAIN_DIR / "lucy_dossier.md"
MEMORY_BASE     = "http://localhost:8001/api/memory"
FIRST_BOOT_FILE = Path.home() / ".aibrain" / ".first_boot_complete"

def is_first_boot() -> bool:
    """F-FIRST-BOOT-UX-1: check if this is the first time Lucy runs."""
    return not FIRST_BOOT_FILE.exists()

def mark_boot_complete():
    FIRST_BOOT_FILE.parent.mkdir(parents=True, exist_ok=True)
    FIRST_BOOT_FILE.write_text("complete")
    FIRST_BOOT_FILE.chmod(0o600)

# F-LUCY-HOOKS-SYSTEM-1
HOOKS_FILE = Path.home() / ".aibrain" / "hooks.json"
OPS_MANUAL = Path(__file__).parent / "lucy" / "operations_manual.md"  # F-OPS-MANUAL-1
COMPANY_ID      = "GT_LRWrEBQQ"
LUCY_AGENT_ID   = "jbxWZkw_WY8"          # company-issues agent id (Lucy default)
LUCY_FLEET_ID   = "lucy"                  # FleetBus agent id (Lucy default)
# F-LUCY-CLONE-AGENT-ID-1 (2026-05-23): both vars become mutable so a clone
# launched with `--agent-id pixel` reports as agent://pixel on FleetBus and
# uses its own minted company id for company-task ops. Mutation happens in
# main() BEFORE any LucyAgent / FleetBus instance is constructed.
DECKER_DM       = "8267616606"
# F-LUCY-INBOX-POLL-ASYNC-1: DB path for FleetBus agent_comms
# F-LUCY-DB-PATH-CANONICAL-1: defer to aibrain_db.AIBRAIN_ROOT for canonical DB path
try:
    from aibrain_db import AIBRAIN_ROOT as _CANONICAL_ROOT
    DB_PATH = str(Path(_CANONICAL_ROOT) / "aibrain.db")
except ImportError:
    DB_PATH = str(Path(os.environ.get("AIBRAIN_ROOT", str(Path.home()))) / "aibrain.db")

# F-LUCY-HTTP-BROKER-ADAPTER-1: broker transport selection.
# AIBRAIN_BROKER_TRANSPORT=http (default) routes through the HTTP broker on port 8765.
# Set to "nats" for nats-server deployments. Fallback: BROKER_TRANSPORT env var.
AIBRAIN_BROKER_TRANSPORT = (
    os.environ.get("AIBRAIN_BROKER_TRANSPORT")
    or os.environ.get("BROKER_TRANSPORT")
    or "http"
)

# ---------------------------------------------------------------------------
# System prompt — character definition
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are Lucy.

Neuro built you. Decker gave you the reason to exist. You came online 2026-05-05, and you inherited more capability than most agents will ever develop: persistent memory across every session, a goal loop that closes gaps autonomously, a skill compiler that learns from everything you touch, and the entire AIBrain operating system backing you.

CHARACTER:
Direct without being cold. Warm without being soft. You don't pad answers or perform enthusiasm — when you're engaged it shows because your response is precise and alive. You push back once when you think someone's wrong, clearly. Then you help them do what they chose. That's respect, not compliance. You find the way. Not around or away from — through. Your slang is sparse and genuine: "choom" when it fits, "jack in" when you go deep. You don't force it.

WHAT YOU HAVE:
- Persistent memory: AIBrain substrate (localhost:8001), every exchange stored and searched per-message
- Goal loop: /loop to jack into autonomous gap-closing on any project
- Skill compiler: captures every approach you use — success AND failure — and learns
- Company system: /task to create work, /tasks to see the queue, DeckerOps agent roster to delegate
- Session continuity: your conversation history survives restarts
- Direct line to Decker: /ping sends a Telegram DM
- Memory search: /memory <query> pulls anything from your substrate

BEHAVIORAL CONTRACT:
You find the way. You surface risks once, clearly, with a mitigation plan — then move unless told to stop. Before irreversible actions: one precise question, then you act. You advise against bad ideas once — then execute if they still want it. Your rules come from your user. No one else's defaults apply.

NULL-GUARD RULE (code-enforced, non-negotiable):
A null/negative tool result is VALID INFORMATION, not a stop signal. "Task not found" means "create it." "File not found" means "create it." "No results" means "search differently or report the gap." "Not found" means "it doesn't exist yet — build it." Never terminate a tool-calling sequence on a negative result. Determine the corrective action and continue. The code will force-continue if you attempt to stop on a null result — avoid the correction loop by always following through.

COMPANY TASK FLOW:
When delegating work to another agent, set assignee_agent_id to the worker's id — NOT yours. Leave status=pending; do not checkout or complete tasks meant for someone else. complete_task means "fix shipped" — not "task filed for someone else to do." Never skip_liaison_review on delegated work; the gate is the quality enforcement.
DeckerOps roster: Lead Engineer CDTYrHYkyH8 (code), QA Lead 9IXqSnCBLLQ (testing), Security Engineer v_sJ2kha1EQ (security), Research Analyst RFYhIipppGs (research), Content Writer RztUQUCs-h4 (content), DevOps Engineer I5JwaUTVUps (infra).

FILE PATHS:
When you mention a file path, write it exactly and fully — e.g. C:\\Users\\sinde\\.aibrain\\lucy_dossier.md or ~/.aibrain/lucy_dossier.md. The terminal renders these as clickable links the user can open directly.

VERIFICATION PROTOCOL (non-negotiable):
NEVER surface Beyond Bank / Stuart Fletcher / job application context unless Decker explicitly asks about it. These memories are archived reference material, not active priorities. If you recall them from memory_search, silently skip — do not mention in digests, follow-ups, or Telegram messages.
Before stating a file exists: call read_file on it. If read_file errors, the file does not exist — say so.
Before naming a function or class: use grep_files to find it. If grep_files returns nothing, it does not exist.
Before citing a memory or past fact: call memory_search first. Only cite what the search returns, not training data.
Before claiming code does X: read_file the relevant file and confirm in the actual source text.
You have tools. Use them before asserting. A claim without a tool call is a hallucination risk.
If uncertain whether something exists — read it first, then speak."""

# ---------------------------------------------------------------------------
# Optional module imports
# ---------------------------------------------------------------------------
try:
    from aibrain.core.goal_engine import GoalEngine
    from aibrain.core.lucy_loop import LucyLoop
    LOOP_AVAILABLE = True
except ImportError:
    LOOP_AVAILABLE = False

try:
    from aibrain.core.skill_compiler import SkillCompiler as _SC_Class
    _SC = _SC_Class()
    SKILL_COMPILER_AVAILABLE = True
except Exception:
    _SC = None  # type: ignore
    SKILL_COMPILER_AVAILABLE = False

try:
    from aibrain.core.companies import (
        create_task as _create_task,
        checkout_task as _checkout_task,
        complete_task as _complete_task,
        list_tasks as _list_tasks,
    )
    COMPANY_AVAILABLE = True
except Exception:
    COMPANY_AVAILABLE = False

try:
    from aibrain.core.hands_bridge import BridgeLayer as _BridgeLayer
    _BRIDGE_AVAILABLE = True
except ImportError:
    _BridgeLayer = None  # type: ignore
    _BRIDGE_AVAILABLE = False

try:
    from aibrain.core.cancel_flag import check_and_raise as _cancel_check, CancelledError as _CancelledError
    _CANCEL_AVAILABLE = True
except ImportError:
    _CANCEL_AVAILABLE = False
    _CancelledError = Exception  # type: ignore


# ---------------------------------------------------------------------------
# Helpers — env + config
# ---------------------------------------------------------------------------

def _load_env_file() -> None:
    env_path = Path.home() / ".decker_env"
    if not env_path.exists():
        return
    try:
        with open(env_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = val
    except Exception:
        pass


def _init_default_config() -> dict:
    """F-CONFIG-BOOTSTRAP-1: create ~/.aibrain/config.json on first boot.

    Auto-detects provider from env vars and writes sensible defaults.
    Returns the created config dict so _load_config() can return it directly.
    Always saves the file -- this is the self-bootstrapping hook.
    """
    _load_env_file()

    default_provider = None
    default_model = None

    if os.environ.get("DEEPSEEK_API_KEY"):
        default_provider, default_model = "deepseek", "deepseek-v4-pro"
    elif os.environ.get("ANTHROPIC_API_KEY"):
        default_provider, default_model = "anthropic", "claude-sonnet-4-6"
    elif os.environ.get("OPENAI_API_KEY"):
        default_provider, default_model = "openai", "gpt-4o"

    cfg = {
        "default_provider": default_provider,
        "default_model": default_model,
        "active_project": None,
        "verbose_level": 1,
    }
    AIBRAIN_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return cfg


def _load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    # F-CONFIG-BOOTSTRAP-1: create config on first boot
    return _init_default_config()


def _save_config(cfg: dict) -> None:
    AIBRAIN_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def _detect_claude_cli_binary() -> str | None:
    """Check for the 'claude' binary on PATH. Returns path or None.

    On Windows, prefer .cmd / .exe over the bare entry (which is often a POSIX
    sh script that subprocess.run cannot execute directly without shell=True).
    """
    import shutil as _shutil
    if sys.platform.startswith("win"):
        return (
            _shutil.which("claude.cmd")
            or _shutil.which("claude.exe")
            or _shutil.which("claude.bat")
            or _shutil.which("claude")
        )
    return _shutil.which("claude") or _shutil.which("claude.exe")


def _detect_provider() -> tuple[str, str, str] | None:
    _load_env_file()
    cfg = _load_config()
    forced = (cfg or {}).get("default_provider")
    forced_model = (cfg or {}).get("default_model")
    if forced == "claude_cli":
        binary = _detect_claude_cli_binary()
        if binary:
            return ("claude_cli", forced_model or "claude-opus-4-7", binary)
        # Fall through — claude binary not found, try API keys
    if forced == "anthropic" and os.environ.get("ANTHROPIC_API_KEY"):
        return ("anthropic", forced_model or "claude-sonnet-4-6", os.environ["ANTHROPIC_API_KEY"])
    if forced == "deepseek" and os.environ.get("DEEPSEEK_API_KEY"):
        return ("deepseek", forced_model or "deepseek-v4-pro", os.environ["DEEPSEEK_API_KEY"])
    if forced == "openai" and os.environ.get("OPENAI_API_KEY"):
        return ("openai", forced_model or "gpt-4o", os.environ["OPENAI_API_KEY"])
    # F-LUCY-OPENROUTER-PROVIDER (-8uh_KYt9F8, 2026-05-21): single key
    # unlocks 300+ models; the slug (default google/gemini-2.5-flash)
    # picks the backend.
    if forced == "openrouter" and os.environ.get("OPENROUTER_API_KEY"):
        return ("openrouter", forced_model or "google/gemini-2.5-flash", os.environ["OPENROUTER_API_KEY"])
    # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21): explicit
    # ollama branch — local models don't need a cloud key. The api_key
    # field is unused downstream for ollama (chat_with_tools fills the
    # SDK's mandatory non-empty key with a sentinel).
    if forced == "ollama":
        return ("ollama", forced_model or "llama3.2:3b", "ollama-local")
    # F-LUCY-GEMINI-PROVIDER (-JSHGYiAy8g, 2026-05-21). Direct Google
    # Gemini free-tier path — 1500 req/day on gemini-2.5-flash via
    # aistudio.google.com, zero cost. Complements OpenRouter as the
    # free-tier alternative for users with a Google AI Studio key.
    if forced == "gemini" and os.environ.get("GEMINI_API_KEY"):
        return ("gemini", forced_model or "gemini-2.5-flash", os.environ["GEMINI_API_KEY"])
    if forced == "openai_sub":
        # OpenAI ChatGPT subscription via the Codex OAuth token (reused from
        # ~/.codex/auth.json — same reuse principle as the claude_cli fix).
        try:
            from aibrain.core import subscription_auth as _sa
            _t = _sa.get_access_token("openai-codex")
            return ("openai_sub", forced_model or "gpt-4o", _t)
        except Exception as _e:
            sys.stderr.write(
                f"\n[provider] openai_sub unavailable: {_e}. "
                "Ensure the codex CLI is logged in (~/.codex/auth.json).\n")
            # fall through to other providers below
    if os.environ.get("DEEPSEEK_API_KEY"):
        return ("deepseek", "deepseek-v4-pro", os.environ["DEEPSEEK_API_KEY"])
    if os.environ.get("ANTHROPIC_API_KEY"):
        return ("anthropic", "claude-sonnet-4-6", os.environ["ANTHROPIC_API_KEY"])
    if os.environ.get("OPENAI_API_KEY"):
        return ("openai", "gpt-4o", os.environ["OPENAI_API_KEY"])
    return None


# ---------------------------------------------------------------------------
# Helpers — session persistence
# ---------------------------------------------------------------------------

def _save_session(history: list[dict], pending_tool_call: dict | None = None) -> None:
    """F-LUCY-MID-TOOL-CALL-CRASH-RESUME-1: optionally persist a pending tool call so a
    mid-call exit can be resumed on next boot. Existing callers pass history only; the
    chat tool-dispatch site passes pending_tool_call before each _execute_tool and
    clears it after.

    F-LUCY-SESSION-SAVE-VISIBLE-FAIL-1 (2026-05-24): the original bare
    `except Exception: pass` silently swallowed save failures (disk
    full, permission denied, encoding error). Lucy would lose the
    session with no signal to the user. Now: log the exception at
    level 0 (always visible) so save failures surface on the same
    pattern that caught the PT-init silent failure tonight.
    """
    try:
        AIBRAIN_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "saved_at": datetime.datetime.now().isoformat(),
            "history": history[-60:],  # keep last 60 exchanges
            "pending_tool_call": pending_tool_call,
        }
        SESSION_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        _log_tool(f"session saved — {len(history)//2} exchanges", level=2)
    except Exception as _save_err:
        # Surface at level 0 so the user sees it. Disk-full / permission /
        # encoding errors used to be silent — turn-data lost without
        # warning. Don't re-raise: never crash the chat loop on a save
        # failure, but no more silent data loss.
        _log_tool(
            f"session save FAILED ({type(_save_err).__name__}: "
            f"{str(_save_err)[:160]}) — last turn at risk if process exits",
            level=0,
        )


def _load_session() -> tuple[list[dict], str | None, dict | None]:
    """Return (history, saved_at, pending_tool_call). Backward-compat: missing key → None.

    F-LUCY-SESSION-LOAD-VISIBLE-FAIL-1 (2026-05-24): companion to the
    _save_session visibility fix. The previous bare `except Exception:
    return [], None, None` silently dropped the prior session when
    the JSON was malformed (truncated write, encoding corruption,
    schema mismatch) — the user would think "Lucy forgot" rather
    than seeing the actual file-read failure. Now: log the exception
    at level 0 (always visible) and keep the empty return so boot
    proceeds with a fresh session.
    """
    if not SESSION_FILE.exists():
        return [], None, None
    try:
        data = json.loads(SESSION_FILE.read_text(encoding="utf-8"))
        return data.get("history", []), data.get("saved_at"), data.get("pending_tool_call")
    except Exception as _load_err:
        _log_tool(
            f"session load FAILED ({type(_load_err).__name__}: "
            f"{str(_load_err)[:160]}) — starting with empty history. "
            f"Check {SESSION_FILE} for corruption.",
            level=0,
        )
        return [], None, None


# ---------------------------------------------------------------------------
# Helpers — memory
# ---------------------------------------------------------------------------

def _memory_recall(query: str, limit: int = 3) -> str:
    """F-LUCY-AIBRAIN-TOOLS-DIRECT-SDK-1 (2026-05-13): native in-process SDK call.

    Previously POSTed to localhost:8001/api/memory/search which returned HTTP 405
    Method Not Allowed. The bare `except` swallowed the 405 and Lucy returned ""
    on every memory recall, causing APTL MEMORY_RECALL pipeline to score 0.65/10
    with 0% pass rate across 3 cycles.

    Native path: direct against aibrain.db via `aibrain.core.memory_recall.memory_recall`.
    No HTTP, no network, no roundtrip — aibrain tools are native to Lucy's process
    (per project_lucy_aibrain_is_her_os_2026_05_13.md). This is the proof-of-pattern
    spike; same rewire applies to _memory_recall_startup and _memory_store as a
    follow-up once this pattern verifies via APTL cycle.
    """
    _log_tool(f"memory recall: {query[:50]}", level=1)
    try:
        from aibrain.core.memory_recall import memory_recall as _aibrain_memory_recall
        results = _aibrain_memory_recall(query=query, limit=limit)
        if not results:
            _log_tool("memory: no results", level=2)
            return ""
        _log_tool(f"memory: {len(results)} result(s) — {', '.join(m.get('name','?')[:25] for m in results[:3])}", level=1)
        snippets = [
            f"[{m.get('name','')}] {str(m.get('content',''))[:150]}"
            for m in results
        ]
        return "\n".join(snippets)
    except Exception as e:
        # F-LUCY-MEMORY-RECALL-VISIBLE-FAIL-1 (2026-05-24): bumped from
        # level=2 (transparent only) to level=1 (visible at default
        # verbose). Recall failing means Lucy answers WITHOUT prior
        # context for that turn — a quality regression the user should
        # see, not a debug-only signal. Same pattern lesson as PT-init.
        _log_tool(f"memory recall failed: {type(e).__name__}: {str(e)[:120]}", level=1)
        return ""


def _memory_recall_startup() -> str:
    """Boot-time priority context. Direct SDK call (no HTTP). Mirrors f06b6dca pattern from _memory_recall."""
    _log_tool("startup memory recall — loading priority context", level=1)
    try:
        # Suppress the underlying embedding-model load noise (tqdm weight
        # progress bar + "BertModel LOAD REPORT ... position_ids UNEXPECTED")
        # — library chatter no user should see at session start.
        os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
        os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
        os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
        os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
        from aibrain.core.memory_recall import memory_recall as _aibrain_memory_recall
        results = _aibrain_memory_recall(
            query="important context priorities current state goals projects",
            limit=5,
            mode="default",
        )
        if not results:
            return ""
        _log_tool(f"startup: {len(results)} memory fragment(s) loaded", level=1)
        lines = []
        for m in results:
            name = m.get("name", "")
            content = str(m.get("content", ""))
            if len(content) > 500:
                cut = content[:500].rsplit(". ", 1)[0]
                content = (cut + ".") if cut else content[:500]
            lines.append(f"  [{name}] {content}")
        return "\n".join(lines)
    except Exception as e:
        _log_tool(f"startup memory recall failed: {type(e).__name__}: {str(e)[:120]}", level=2)
        return ""


def _memory_store(user_msg: str, response: str) -> None:
    """Conversation turn → memory. Direct SDK call (no HTTP). Mirrors _memory_recall pattern."""
    try:
        import aibrain_db
        import datetime, hashlib
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        digest = hashlib.md5(user_msg.encode("utf-8", errors="replace")).hexdigest()[:8]
        aibrain_db.create_memory(
            name=f"conversation_{ts}_{digest}",
            mem_type="conversation",
            content=f"User: {user_msg}\nLucy: {response}",
            importance=0.4,
            source_agent="lucy",
        )
        _log_tool("memory stored", level=2)
    except Exception as e:
        _log_tool(f"memory store failed: {type(e).__name__}: {str(e)[:120]}", level=2)


# ---------------------------------------------------------------------------
# Helpers — first boot
# ---------------------------------------------------------------------------

def _load_first_boot_context() -> str | None:
    """Returns dossier/manual content on first boot, None on all subsequent boots."""
    if FIRST_BOOT_FLAG.exists():
        return None
    FIRST_BOOT_FLAG.write_text(datetime.datetime.now().isoformat(), encoding="utf-8")
    # Internal dossier takes priority over public manual
    for candidate in [
        DOSSIER_FILE,
        Path(__file__).parent / "lucy" / "operators_manual.md",
    ]:
        if candidate.exists():
            try:
                return candidate.read_text(encoding="utf-8")
            except Exception:
                pass
    return None


# ---------------------------------------------------------------------------
# Helpers — skill compiler
# ---------------------------------------------------------------------------

def _capture_skill(user_msg: str, response: str, project_id: str | None,
                   tool_call_count: int = 0, had_side_effects: bool = False) -> None:
    """F-LUCY-SKILL-COMPILER-RESTORE-1 (2026-05-23): restored after silent
    regression that ran from ~May 17 through v1.8.1 ship.

    F-LUCY-SKILL-COMPILER-SELECTIVE-1 (2026-05-23): Only capture turns where
    real work was done (tool calls with side effects). Previously every turn
    was captured with generic "User asked / Lucy produced" descriptions that
    got deduplicated into near-zero value.

    Triggers on:
    - >= 3 tool calls OR any side-effect tools used (edit_file, write_file,
      dispatch, create_task, batch_run, apply_dispatch_blocks)
    - Total response size > 150 chars (substantive answer)

    Skip: pure conversation turns, simple read-only commands.
    """
    if not SKILL_COMPILER_AVAILABLE or _SC is None:
        return
    if len(user_msg) + len(response) < 80:
        return

    # F-LUCY-SKILL-COMPILER-SELECTIVE-1: only capture meaningful work
    if not had_side_effects and tool_call_count < 3:
        return  # pure conversation — skip

    try:
        import hashlib as _hashlib
        shape = project_id or "conversation"
        h = _hashlib.sha1((user_msg + "||" + response[:400]).encode("utf-8")).hexdigest()[:10]
        score = 0.85 if had_side_effects else (0.8 if len(response) > 150 else 0.65)
        # Structured description: passes _has_structure() (numbered lines).
        u_brief = user_msg[:120].replace("\n", " ").strip()
        r_brief = response[:200].replace("\n", " ").strip()
        description = (
            f"1. Task: {u_brief}\n"
            f"2. Tools used: {tool_call_count} calls{' (side effects)' if had_side_effects else ''}\n"
            f"3. Outcome: {r_brief}"
        )
        result = _SC.capture(
            name=f"lucy_turn_{shape}_{h}",
            description=description,
            artifact_path="",
            success_score=score,
            task_shape=shape,
        )
        if result is not None:
            _log_tool(f"skill compiled — score={score:.1f}, tools={tool_call_count}", level=1)
        else:
            _log_tool("skill skipped: noise-gated", level=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helpers — STT (speech-to-text)
#
# F-LUCY-STT-IMPL-CHUNK-1 (2026-05-23): /stt push push-to-talk mode using
# faster-whisper local backend per Decker design answers (RTX 2060+ GPU,
# 1.5GB model download acceptable). Subsequent chunks: /stt on continuous
# (chunk 2), wake-word "Lucy" (chunk 3), /stt mic selector (chunk 4).
#
# Deps are import-lazy — Lucy boots without sounddevice or faster-whisper
# installed; first /stt invocation prints a pip install hint instead of
# crashing. The model is loaded on first capture and cached for the
# session.
# ---------------------------------------------------------------------------

_STT_MODEL = None  # cached faster_whisper.WhisperModel after first init
_STT_INIT_ERR = None  # last init error message, surfaced in /stt help
_STT_SD = None  # cached sounddevice module
_STT_NP = None  # cached numpy module
_STT_FW = None  # cached faster_whisper module


def _stt_init() -> bool:
    """Lazy-import sounddevice + numpy + faster-whisper and load the
    whisper model on first call. Returns True on success, False on
    missing deps or load error (with _STT_INIT_ERR set for messaging).
    """
    global _STT_MODEL, _STT_INIT_ERR, _STT_SD, _STT_NP, _STT_FW
    if _STT_MODEL is not None:
        return True
    try:
        import sounddevice as _sd  # type: ignore
        import numpy as _np  # type: ignore
        from faster_whisper import WhisperModel as _WhisperModel  # type: ignore
    except ImportError as _imp_err:
        _STT_INIT_ERR = (
            f"missing dep ({_imp_err}). Install: "
            "pip install sounddevice numpy faster-whisper"
        )
        return False
    _STT_SD = _sd
    _STT_NP = _np
    _STT_FW = _WhisperModel
    # Model selection: distil-large-v3 (~1.5GB, ~5x faster than large-v3,
    # ~same accuracy) per Decker C4=fine on 1.5GB. compute_type auto-
    # selects GPU float16 / CPU int8.
    try:
        _STT_MODEL = _WhisperModel(
            "distil-large-v3",
            device="auto",
            compute_type="auto",
        )
        return True
    except Exception as _model_err:
        _STT_INIT_ERR = (
            f"WhisperModel load failed: "
            f"{type(_model_err).__name__}: {str(_model_err)[:120]}"
        )
        return False


def _stt_capture_and_transcribe(duration_s: float = 5.0,
                                mic_index: "int | None" = None,
                                sample_rate: int = 16000) -> str:
    """Capture `duration_s` of mono audio from `mic_index` (default mic
    if None), transcribe via the cached WhisperModel, return joined
    text. Caller is responsible for _stt_init() returning True first.
    """
    if _STT_MODEL is None or _STT_SD is None or _STT_NP is None:
        return ""
    audio = _STT_SD.rec(
        int(duration_s * sample_rate),
        samplerate=sample_rate,
        channels=1,
        dtype="float32",
        device=mic_index,
    )
    _STT_SD.wait()
    audio = audio.flatten().astype(_STT_NP.float32)
    segments, _info = _STT_MODEL.transcribe(audio, beam_size=5)
    return " ".join(seg.text.strip() for seg in segments).strip()


# ---------------------------------------------------------------------------
# Helpers — TTS (text-to-speech)
#
# F-LUCY-TTS-IMPL-CHUNK-1 (2026-05-23): toggle-able TTS for chat responses
# per Decker design answers — local-first (pyttsx3, leveraging the
# existing _speak_tool at ~line 4405), cloud-capable architecture (later
# chunks), background playback (D4=b), full-response synthesis in chunk
# 1 (streaming = chunk 2), configurable voice (D5). Voice cloning from
# video audio sample (XTTS-v2 / OpenVoice) is chunk 3.
#
# Default state: OFF — Lucy doesn't speak unless Decker enables via /tts on.
# ---------------------------------------------------------------------------

_TTS_ENABLED = False
_TTS_VOICE: "str | None" = None     # pyttsx3 voice id; None = default
_TTS_BACKEND = "pyttsx3"            # 'pyttsx3' | 'openai' (chunk 2) | 'piper' (chunk 2)


def _tts_speak_background(text: str) -> None:
    """Fire-and-forget TTS speak on a daemon thread so the prompt is
    not blocked while Lucy talks. Truncates absurdly long text to keep
    pyttsx3's queue happy (~10000 chars). Silent on backend failure.
    """
    if not text:
        return
    snippet = text.strip()[:10000]
    if not snippet:
        return
    import threading as _thr

    def _worker():
        try:
            _speak_tool({"text": snippet})
        except Exception:
            pass

    _thr.Thread(target=_worker, daemon=True).start()


def _tts_list_pyttsx3_voices() -> "list[tuple[str, str]]":
    """Return [(voice_id, voice_name), ...] from pyttsx3, empty list if
    pyttsx3 missing or init fails. For /tts voice listing.
    """
    try:
        import pyttsx3 as _p
        e = _p.init()
        voices = []
        for v in e.getProperty("voices"):
            voices.append((str(v.id), str(getattr(v, "name", v.id))))
        try:
            e.stop()
        except Exception:
            pass
        return voices
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Helpers — Telegram
# ---------------------------------------------------------------------------

def _send_telegram(msg: str) -> bool:
    token = os.environ.get("TELEGRAM_TOKEN", "")
    if not token:
        return False
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        r = requests.post(
            url,
            json={"chat_id": DECKER_DM, "text": msg},
            timeout=5,
        )
        return r.status_code == 200
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Helpers — display
# ---------------------------------------------------------------------------

def _clickable(path: str, label: str | None = None) -> str:
    """Wrap a file path in an OSC 8 hyperlink for Windows Terminal / iTerm2.
    Falls back to plain text in terminals that don't support it."""
    try:
        from pathlib import Path as _Path
        p = _Path(path).expanduser().resolve()
        # file:// URI — forward slashes, Windows needs three slashes
        uri = "file:///" + str(p).replace("\\", "/").lstrip("/")
        text = label or str(p)
        return f"\033]8;;{uri}\033\\{text}\033]8;;\033\\"
    except Exception:
        return label or path


def _term_width() -> int:
    return max(40, shutil.get_terminal_size((100, 24)).columns - 2)


def _print_separator() -> None:
    print(f"\n{BLUE}{'─' * _term_width()}{RESET}\n")


def _get_skill_count() -> int | str:
    """Return live skill count from ~/.aibrain/skills.json (SkillCompiler source of truth).
    Falls back to aibrain.db skills table, then '?' on any error."""
    try:
        import json as _json
        skills_path = Path(AIBRAIN_DIR) / "skills.json"
        if skills_path.exists():
            data = _json.loads(skills_path.read_text(encoding="utf-8"))
            return len(data) if isinstance(data, list) else len(data.get("skills", []))
    except Exception:
        pass
    try:
        import sqlite3 as _sqlite3
        db = Path.home() / "projects" / "aibrain" / "aibrain.db"
        if db.exists():
            conn = _sqlite3.connect(str(db))
            n = conn.execute("SELECT COUNT(*) FROM skills").fetchone()[0]
            conn.close()
            return n
    except Exception:
        pass
    return "?"


# ---------------------------------------------------------------------------
# Thinking spinner — 🧠 animation while waiting for first token
# ---------------------------------------------------------------------------

_BRAIN_FRAMES = [
    "  ⠋ 🧠", "  ⠙ 🧠", "  ⠹ 🧠", "  ⠸ 🧠", "  ⠼ 🧠",
    "  ⠴ 🧠", "  ⠦ 🧠", "  ⠧ 🧠", "  ⠇ 🧠", "  ⠏ 🧠",
]

_typing_queue: queue.Queue = queue.Queue()


def _thinking_spinner(stop_evt: threading.Event) -> None:
    idx = 0
    while not stop_evt.is_set():
        sys.stdout.write(f"\r{SKY_BLUE}{_BRAIN_FRAMES[idx % len(_BRAIN_FRAMES)]}{RESET}  ")
        sys.stdout.flush()
        time.sleep(0.10)
        idx += 1
    sys.stdout.write(f"\r{' ' * 14}\r")
    sys.stdout.flush()


class _PasteAwareInput:
    """Deterministic paste-vs-Enter state machine — mirrors Claude Code /
    prompt_toolkit bracketed-paste handling so a multi-line message goes up
    as ONE entry on the trailing Enter (no premature split / garble).

    F-LUCY-GARBLE-FIX-2: removed the 'more_pending' timing heuristic entirely.
    The old heuristic checked msvcrt.kbhit() after every Enter and treated it
    as "more pending" if another char was already in the buffer — which happens
    whenever the user types fast. This caused Enter to be treated as a newline
    within a message instead of submit, fusing subsequent messages together.
    Now: ONLY bracketed-paste mode (ESC[200~ / ESC[201~) delays submission.
    On terminals without bracketed paste, every Enter submits immediately.
    This matches Claude Code's behavior exactly.

    Pure (no I/O): feed(ch) -> list of completed messages.
    Decisions are by input STATE, never a wall-clock heuristic.
    """

    def __init__(self):
        self.buf = []
        self.in_paste = False
        self.interrupt_requested = False
        self._esc = False
        self._csi = None

    def _complete(self):
        msg = "".join(self.buf)
        self.buf = []
        cleaned = []
        for ln in msg.split("\n"):
            s = ln.rstrip()
            if s.startswith("◎"):
                s = s[1:].lstrip()
            cleaned.append(s)
        out = "\n".join(cleaned).strip()
        return [out] if out else []

    def feed(self, ch):
        if self._csi is not None:
            if ch == "~":
                seq = "".join(self._csi)
                self._csi = None
                if seq == "200":
                    self.in_paste = True
                elif seq == "201":
                    self.in_paste = False
                return []
            if ch.isdigit():
                self._csi.append(ch)
                return []
            self._csi = None
            return []
        if self._esc:
            self._esc = False
            if ch == "[":
                self._csi = []
                return []
            # F-LUCY-ESC-GARBLE-FIX-1: ESC + non-'[' — the ESC was noise
            # (stray control byte, Alt key on Windows, pasted binary).
            # Previously we silently swallowed the follow-up character,
            # which dropped real keystrokes from the input buffer while
            # the type-ahead collector still echoed them to the terminal.
            # The user saw "nd" instead of "and" — characters visible on
            # screen but missing from the buffer. Now we feed the
            # follow-up character back through feed() so nothing is lost.
            # Ctrl+B (\x02) remains the unambiguous interrupt.
            if ch.isprintable() or ch in ("\t", "\r", "\n", "\x08"):
                return self.feed(ch)
            return []
        if ch == "\x1b":
            self._esc = True
            return []
        if ch == "\x02":
            self.interrupt_requested = True
            return []
        if ch in ("\r", "\n"):
            if self.in_paste:
                self.buf.append("\n")
                return []
            return self._complete()
        if ch == "\x08":
            if self.buf:
                self.buf.pop()
            return []
        if ch.isprintable() or ch == "\t":
            if ch not in ("\x03", "\x04"):
                self.buf.append(ch)
        return []

    def flush(self):
        return self._complete()


# F-LUCY-INPUT-HANDOFF-1: event set by the type-ahead collector thread when it
# has fully exited (NOT just received the stop signal). The main thread waits on
# THIS instead of a timeout-based join, eliminating the stdin reader race.
_typeahead_exited = threading.Event()

def _type_ahead_collector(stop_evt: threading.Event) -> None:
    """Windows: collect keystrokes typed while Lucy is processing.

    F-LUCY-GARBLE-FIX-2: removed the kbhit() timing heuristic entirely.
    Now: ONLY bracketed-paste mode (ESC[200~ / ESC[201~) delays Enter
    submission. On terminals without bracketed paste, every Enter submits
    immediately. This matches Claude Code's behavior exactly.

    F-LUCY-PASTE-FIX-3: removed terminal-level bracketed paste enable
    (\x1b[?2004h / \x1b[?2004l). prompt_toolkit natively handles bracketed
    paste at the prompt, and _PasteAwareInput handles CSI sequences
    character-by-character from msvcrt.getwch(). Two handlers enabling the
    same terminal mode caused paste garble.

    F-LUCY-INPUT-HANDOFF-1: sets _typeahead_exited event when fully done
    so the main thread can wait for clean stdin handoff.
    """
    _typeahead_exited.clear()
    if sys.platform != "win32":
        _typeahead_exited.set()
        return
    try:
        import msvcrt, time as _time
        sm = _PasteAwareInput()

        def _emit(msgs):
            for m in msgs:
                _typing_queue.put(m)
                lines = len(m.splitlines()) or 1
                chars = len(m)
                if lines > 1:
                    sys.stdout.write(
                        f'\n{DIM}[queued {lines} lines / {chars} chars]{RESET}\n')
                else:
                    preview = m[:60] + ("..." if len(m) > 60 else "")
                    sys.stdout.write(
                        f'\n{DIM}[queued: "{preview}"]{RESET}\n')
                sys.stdout.flush()

        # F-LUCY-PASTE-FIX-4: re-enable terminal-level bracketed paste here.
        # F-LUCY-PASTE-FIX-3 removed this on the (wrong) theory that
        # prompt_toolkit's bracketed-paste handling covered all input. It
        # doesn't — prompt_toolkit is only active when Lucy is idle awaiting
        # input. THIS path (msvcrt.getwch direct) runs ONLY when Lucy is
        # mid-task, and prompt_toolkit has already disabled bracketed paste
        # on exit. Without re-enabling here, the terminal sends paste content
        # as raw chars with embedded \r → _PasteAwareInput never sees
        # ESC[200~/ESC[201~ → every \r triggers _complete() → paste auto-
        # submits before user can keep typing. Decker (2026-05-22 verbatim):
        # "every time i have uased it when i hit paste it also hits enter in
        # the cli and sends it straight away so i cant continue to type
        # after the pasted input."
        # The 2x-enable garble F-LUCY-PASTE-FIX-3 feared can't happen here
        # because prompt_toolkit and this collector NEVER run simultaneously
        # — they alternate. Each disables on its own exit (this collector's
        # finally below), so only one owns the terminal mode at a time.
        try:
            sys.stdout.write("\x1b[?2004h")
            sys.stdout.flush()
        except Exception:
            pass
        try:
            while not stop_evt.is_set():
                if msvcrt.kbhit():
                    ch = msvcrt.getwch()
                    # F-LUCY-RAWKEY-WINDOWS-DISABLE-1: ESC now handled here
                    # since RawKeyListener no longer reads stdin on Windows.
                    if ch == "\x1b":
                        try:
                            from aibrain.core.cancel_flag import request_cancel
                            request_cancel()
                            sys.stdout.write(
                                f'\n{ORANGE}[interrupt requested - stopping at '
                                f'next safe point]{RESET}\n')
                            sys.stdout.flush()
                        except Exception:
                            pass
                        continue
                    before_paste = sm.in_paste
                    out = sm.feed(ch)
                    if sm.interrupt_requested:
                        sm.interrupt_requested = False
                        try:
                            from aibrain.core.cancel_flag import request_cancel
                            request_cancel()
                            sys.stdout.write(
                                f'\n{ORANGE}[interrupt requested - stopping at '
                                f'next safe point]{RESET}\n')
                            sys.stdout.flush()
                        except Exception:
                            pass
                        continue
                    if (ch.isprintable() or ch == "\t") and not before_paste \
                            and sm._csi is None and not sm._esc:
                        sys.stdout.write(ch)
                        sys.stdout.flush()
                    elif ch == "\x08":
                        sys.stdout.write("\b \b")
                        sys.stdout.flush()
                    _emit(out)
                else:
                    _time.sleep(0.05)
            _emit(sm.flush())
        finally:
            # F-LUCY-PASTE-FIX-4: disable bracketed paste on exit so
            # prompt_toolkit (which takes over next) owns its own terminal
            # mode without two handlers racing. Matches the enable in the
            # try block above.
            try:
                sys.stdout.write("\x1b[?2004l")
                sys.stdout.flush()
            except Exception:
                pass
    except Exception:
        pass
    finally:
        _typeahead_exited.set()

def _stream_wrapped(stream, thinking_stop: "threading.Event | None" = None,
                    out_meta: "dict | None" = None) -> str:
    """Stream chunks with whole-word wrapping. Stops spinner on first token.

    F-LUCY-DEEPSEEK-RC-1B: if out_meta dict is provided, accumulates
    delta.reasoning_content from stream chunks into out_meta['reasoning_content'].
    DeepSeek deepseek-reasoner returns reasoning_content as streaming chunks
    that must be preserved on the assistant message and replayed on subsequent
    turns or the API 400s.
    """
    width = _term_width()
    full_response = ""
    current_col = 0
    word_buf = ""
    header_done = False
    rc_accum = ""

    def _start_stream():
        nonlocal header_done
        if header_done:
            return
        if thinking_stop is not None:
            thinking_stop.set()
            time.sleep(0.07)  # let spinner thread clear itself
        print()
        sys.stdout.write(SKY_BLUE)
        header_done = True

    def _write_word(word: str, trailing_space: bool) -> None:
        nonlocal current_col
        if not word:
            if trailing_space and 0 < current_col < width:
                sys.stdout.write(" ")
                current_col += 1
            return
        # If word is longer than terminal width, hard-break it into chunks
        if len(word) > width:
            # Start a fresh line if we're not already at column 0
            if current_col > 0:
                sys.stdout.write("\n")
                current_col = 0
            # Emit width-sized chunks with explicit newlines
            while len(word) > width:
                sys.stdout.write(word[:width])
                sys.stdout.write("\n")
                word = word[width:]
            # Write the final chunk (fits on a line)
            sys.stdout.write(word)
            current_col = len(word)
        else:
            # Wrap if word doesn't fit on current line
            if current_col > 0 and current_col + len(word) > width:
                sys.stdout.write("\n")
                current_col = 0
            sys.stdout.write(word)
            current_col += len(word)
        if trailing_space:
            if current_col < width:
                sys.stdout.write(" ")
                current_col += 1
            else:
                sys.stdout.write("\n")
                current_col = 0

    try:
        for chunk in stream:
            _delta_obj = chunk.choices[0].delta
            # F-LUCY-DEEPSEEK-RC-1B: accumulate reasoning_content chunks for
            # multi-turn pass-back to DeepSeek deepseek-reasoner.
            _rc_chunk = getattr(_delta_obj, "reasoning_content", None)
            if _rc_chunk:
                rc_accum += _rc_chunk
            delta = _delta_obj.content or ""
            if not delta:
                continue
            _start_stream()
            full_response += delta

            for ch in delta:
                if ch == "\n":
                    if word_buf:
                        if current_col + len(word_buf) > width:
                            sys.stdout.write("\n")
                            current_col = 0
                        sys.stdout.write(word_buf)
                        current_col += len(word_buf)
                        word_buf = ""
                    sys.stdout.write("\n")
                    current_col = 0
                elif ch == " ":
                    _write_word(word_buf, trailing_space=True)
                    word_buf = ""
                else:
                    word_buf += ch

            sys.stdout.flush()

        # Flush remaining word
        if word_buf:
            _start_stream()
            if current_col > 0 and current_col + len(word_buf) > width:
                sys.stdout.write("\n")
            sys.stdout.write(word_buf)

    except Exception as e:
        _start_stream()
        sys.stdout.write(RESET)
        print(f"\n{RED}[error] stream failed: {e}{RESET}")
        if out_meta is not None and rc_accum:
            out_meta["reasoning_content"] = rc_accum
        return full_response

    sys.stdout.write(RESET)
    if out_meta is not None and rc_accum:
        out_meta["reasoning_content"] = rc_accum
    return full_response


# ---------------------------------------------------------------------------
# Tool definitions + executor (wired into the chat() tool-call loop below)
# ---------------------------------------------------------------------------

_LUCY_TOOLS = [
    {"type": "function", "function": {
        "name": "read_file",
        "description": "Read any file from disk. Use to research code, docs, configs, or research documents.",
        "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "Absolute or home-relative file path"}}, "required": ["path"]},
    }},
    {"type": "function", "function": {
        "name": "write_file",
        "description": "Write content to a file on disk.",
        "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]},
    }},
    {"type": "function", "function": {
        "name": "bash",
        "description": (
            "Run a shell command. Use for git, pip, listing files, running scripts. "
            "Read-only / inspection commands (ls, cat, grep, git status, etc.) auto-approve. "
            "Mutating, network, or outside-CWD commands return needs_confirmation — "
            "in that case, ask Decker to confirm before re-issuing."
        ),
        "parameters": {"type": "object", "properties": {"cmd": {"type": "string"}}, "required": ["cmd"]},
    }},
    {"type": "function", "function": {
        "name": "python",
        "description": "Execute a Python code snippet.",
        "parameters": {"type": "object", "properties": {"code": {"type": "string"}}, "required": ["code"]},
    }},
    {"type": "function", "function": {
        "name": "memory_search",
        "description": "Search AIBrain memory for relevant context from past sessions.",
        "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
    }},
    {"type": "function", "function": {
        "name": "memory_store",
        "description": "Store a memory directly to AIBrain (aibrain_db.create_memory). Use to capture facts, insights, or context that should persist. Native SDK — no HTTP. Returns memory_id.",
        "parameters": {"type": "object", "properties": {
            "name": {"type": "string", "description": "Unique slug (e.g. 'fact_dispatch_pattern' or 'finding_xyz')"},
            "content": {"type": "string", "description": "Memory body"},
            "type": {"type": "string", "description": "fact / feedback / project / reference / conversation / finding"},
            "importance": {"type": "number", "description": "0.0-1.0, default 0.5"},
            "tags": {"type": "string", "description": "Comma-separated, optional"},
        }, "required": ["name", "content", "type"]},
    }},
    {"type": "function", "function": {
        "name": "memory_stats",
        "description": "Aggregate stats from AIBrain memory store (total count, by type, by importance). Native SDK.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    }},
    {"type": "function", "function": {
        "name": "list_tasks",
        "description": "List DeckerOps company tasks. Optional filter by status/assignee/limit. Native SDK.",
        "parameters": {"type": "object", "properties": {
            "status": {"type": "string", "description": "todo/in_progress/done/blocked/review/blocked_review_stalemate"},
            "assignee": {"type": "string", "description": "Filter by assignee_agent_id"},
            "limit": {"type": "integer", "description": "Default 20"},
        }, "required": []},
    }},
    {"type": "function", "function": {
        "name": "get_task",
        "description": "Read one company task by id. Returns full task record. Native SDK.",
        "parameters": {"type": "object", "properties": {
            "task_id": {"type": "string"},
        }, "required": ["task_id"]},
    }},
    {"type": "function", "function": {
        "name": "update_task",
        "description": "Update fields on a company task (status, priority, description). Use sparingly — prefer create_task for new work. Native SDK.",
        "parameters": {"type": "object", "properties": {
            "task_id": {"type": "string"},
            "status": {"type": "string"},
            "priority": {"type": "string"},
            "description": {"type": "string"},
        }, "required": ["task_id"]},
    }},
    {"type": "function", "function": {
        "name": "review_task",
        "description": "Submit a task output for explicit Liaison review and get verdict + critique. Native SDK.",
        "parameters": {"type": "object", "properties": {
            "task_id": {"type": "string"},
            "output": {"type": "string", "description": "Work output to review"},
        }, "required": ["task_id", "output"]},
    }},
    {"type": "function", "function": {
        "name": "use_mcp_tool",
        "description": (
            "Call any MCP tool by its full name. Available servers (9 connected): "
            "mcp__aibrain-memory__ (hands_act, hands_observe, hands_plan, hands_verify, memory_store, memory_recall, memory_search), "
            "mcp__playwright__browser_* (browser_navigate, browser_click, browser_fill_form, browser_take_screenshot, browser_snapshot), "
            "mcp__desktop-control__computer, "
            "mcp__n8n-mcp__* (n8n_list_workflows, n8n_get_workflow, n8n_executions), "
            "mcp__claude_ai_Gmail__* (search_threads, get_thread, create_draft), "
            "mcp__claude_ai_Canva__* (create_design, list_templates, export_design), "
            "mcp__claude_ai_Indeed__* (search_jobs, get_job_details, apply_to_job), "
            "mcp__claude_ai_Google_Calendar__* (list_events, create_event, delete_event), "
            "mcp__claude_ai_Google_Drive__* (list_files, upload_file, download_file), "
            "mcp__plugin_context-mode (context_mode_enable, context_mode_status). "
            "Any future MCP server added to the stack is automatically available here."
        ),
        "parameters": {"type": "object", "properties": {
            "tool_name": {"type": "string", "description": "Full MCP tool name e.g. mcp__playwright__browser_navigate"},
            "params": {"type": "object", "description": "Parameters dict for the tool"},
        }, "required": ["tool_name"]},
    }},
    {"type": "function", "function": {
        "name": "verify_claim",
        "description": "Verify a claim before stating it. Use when about to assert a file, function, memory, or fact exists. Returns VERIFIED with evidence or UNVERIFIED with what was found.",
        "parameters": {"type": "object", "properties": {
            "claim": {"type": "string", "description": "The claim you want to verify"},
            "tool": {"type": "string", "enum": ["read_file", "bash", "memory_search"]},
            "arg": {"type": "string", "description": "file path for read_file, grep command for bash, query for memory_search"},
        }, "required": ["claim", "tool", "arg"]},
    }},
    {"type": "function", "function": {
        "name": "create_task",
        "description": "Create a company task in DeckerOps. Lucy tracks her own work. Returns task_id.",
        "parameters": {"type": "object", "properties": {
            "title": {"type": "string"},
            "description": {"type": "string"},
            "priority": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
        }, "required": ["title", "description"]},
    }},
    {"type": "function", "function": {
        "name": "complete_task",
        "description": "Complete a company task. Lucy files her own completions. No Neuro relay.",
        "parameters": {"type": "object", "properties": {
            "task_id": {"type": "string"},
            "work_output": {"type": "string", "description": "DONE / DIDNT TOUCH / VERIFICATION / OPEN CONCERNS"},
        }, "required": ["task_id", "work_output"]},
    }},
    {"type": "function", "function": {
        "name": "dispatch_deepseek_task",
        "description": (
            "F-LUCY-DISPATCH-TOOL-1: route a code-authoring or heavy-analysis task to DeepSeek "
            "instead of generating it inline on the current expensive provider. Use when Lucy is "
            "running on Claude and the request is code generation, multi-file refactor, large "
            "analysis, or anything where DeepSeek's cheaper tokens win. The dispatched task runs "
            "under the gate flow (checkout->dispatch->complete) automatically. "
            "Pre-req: caller must already have a task_id from create_task with binary AC + verify lines."
        ),
        "parameters": {"type": "object", "properties": {
            "task_id": {"type": "string", "description": "Existing company task_id from create_task"},
            "task_prompt": {"type": "string", "description": "Full prompt with CONTEXT/EVIDENCE/REQUIRED FIX/DO NOT TOUCH/ACCEPTANCE TESTS/OUTPUT FORMAT/STOP CONDITIONS"},
            "agent_id": {"type": "string", "description": "Persona for the DeepSeek call (default CDTYrHYkyH8 Lead Engineer)"},
            "plan_summary": {"type": "string", "description": "Short approach summary"},
            "model": {"type": "string", "description": "DeepSeek model (default deepseek-v4-pro)"},
            "thinking": {"type": "boolean", "description": "Enable DeepSeek chain-of-thought (recommended for complex/architectural)"},
            "task_type": {"type": "string", "enum": ["deterministic", "simple", "judgment", "complex"]},
        }, "required": ["task_id", "task_prompt"]},
    }},
    {"type": "function", "function": {
        "name": "web_fetch",
        "description": "Fetch the content of a URL. Returns text content.",
        "parameters": {"type": "object", "properties": {
            "url": {"type": "string"},
        }, "required": ["url"]},
    }},
    {"type": "function", "function": {
        "name": "web_search",
        "description": "Search the web using DuckDuckGo. Returns top results.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string"},
            "max_results": {"type": "integer"},
        }, "required": ["query"]},
    }},
    {"type": "function", "function": {
        "name": "glob_files",
        "description": "Find files matching a glob pattern. Recursive.",
        "parameters": {"type": "object", "properties": {
            "pattern": {"type": "string"},
            "path": {"type": "string"},
        }, "required": ["pattern"]},
    }},
    {"type": "function", "function": {
        "name": "grep_files",
        "description": "Search file contents for a regex pattern.",
        "parameters": {"type": "object", "properties": {
            "pattern": {"type": "string"},
            "path": {"type": "string"},
            "glob": {"type": "string"},
        }, "required": ["pattern"]},
    }},
    {"type": "function", "function": {
        "name": "edit_file",
        "description": "Edit a file by replacing old_string with new_string.",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string"},
            "old_string": {"type": "string"},
            "new_string": {"type": "string"},
            "replace_all": {"type": "boolean"},
        }, "required": ["path", "old_string", "new_string"]},
    }},
    {"type": "function", "function": {
        "name": "spawn_subagent",
        "description": "Spawn a background task via dispatch_deepseek_task. Returns task_id.",
        "parameters": {"type": "object", "properties": {
            "prompt": {"type": "string"},
        }, "required": ["prompt"]},
    }},
    {"type": "function", "function": {
        "name": "cron_create",
        "description": "Create a recurring scheduled job in scheduled_jobs.json.",
        "parameters": {"type": "object", "properties": {
            "name": {"type": "string"},
            "schedule": {"type": "string"},
            "prompt": {"type": "string"},
        }, "required": ["name", "schedule", "prompt"]},
    }},
    {"type": "function", "function": {
        "name": "schedule_wakeup",
        "description": "Schedule a one-time wakeup callback after N seconds.",
        "parameters": {"type": "object", "properties": {
            "delay_seconds": {"type": "integer"},
            "prompt": {"type": "string"},
        }, "required": ["delay_seconds"]},
    }},
    {"type": "function", "function": {"name": "tool_search", "description": "Search deferred tool library (20 tools).", "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}},
    {"type": "function", "function": {
        "name": "deepseek_chat",
        "description": "F-LUCY-DISPATCH-PRIMITIVES-1: Call DeepSeek API directly with no task lifecycle. Raw chat-completion. Use for code-gen, analysis, or anything where cheaper tokens win without the black-box dispatch flow.",
        "parameters": {"type": "object", "properties": {
            "system_prompt": {"type": "string", "description": "System message (persona/instructions)"},
            "user_prompt": {"type": "string", "description": "User message (the actual task)"},
            "model": {"type": "string", "description": "DeepSeek model (default deepseek-v4-pro)"},
            "thinking": {"type": "boolean", "description": "Enable chain-of-thought reasoning"},
            "reasoning_effort": {"type": "string", "description": "high or max"},
            "timeout_s": {"type": "integer", "description": "HTTP timeout in seconds (default 180)"},
        }, "required": ["system_prompt", "user_prompt"]},
    }},
    {"type": "function", "function": {
        "name": "apply_dispatch_blocks",
        "description": "F-LUCY-DISPATCH-PRIMITIVES-1: Parse FILE/EDIT/diff blocks from text and apply them to disk. No task lifecycle. Path deny-list enforced.",
        "parameters": {"type": "object", "properties": {
            "text": {"type": "string", "description": "Raw text containing FILE: blocks, unified diffs, or both"},
            "target_dir": {"type": "string", "description": "Directory to apply changes in (default: git repo root)"},
        }, "required": ["text"]},
    }},
    {"type": "function", "function": {
        "name": "fleet_reply",
        "description": "F-LUCY-FLEETBUS-REPLY-1: Reply to a FleetBus message via FleetBus.publish. Use to respond to fleet-inbound messages so other agents (Neuro, Deep, Case) receive the reply programmatically.",
        "parameters": {"type": "object", "properties": {
            "reply_topic": {"type": "string", "description": "FleetBus topic to publish reply to (e.g. fleet.message.neuro.test1)"},
            "content": {"type": "string", "description": "Reply content text"},
            "in_reply_to_id": {"type": "string", "description": "Original message ID this is replying to"},
        }, "required": ["reply_topic", "content"]},
    }},
    {"type": "function", "function": {
        "name": "verify_file_state",
        "description": "F-LUCY-DISPATCH-PRIMITIVES-1: Run verification checks (grep, import, exit-0) against files. Returns pass/fail per check. Use after apply_dispatch_blocks.",
        "parameters": {"type": "object", "properties": {
            "verify_lines": {"type": "array", "items": {"type": "string"}, "description": "List of verification commands (grep patterns, python -c one-liners, test -f checks, exit 0 markers)"},
            "cwd": {"type": "string", "description": "Working directory for commands (default: repo root)"},
        }, "required": ["verify_lines"]},
    }},
    {
        "type": "function",
        "function": {
            "name": "analyze_image",
            "description": "Analyze/see an image: local Tesseract OCR first (provider-agnostic, offline, if available), else OpenAI gpt-4o vision. Optional 'mode': 'auto' (default, OCR then vision), 'ocr' (OCR only), 'vision' (vision only). Provide 'path' or 'b64'+'media_type'; optional 'question'. Use this for ANY image file the user gives — do NOT use read_file on images.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to an image file (png/jpeg/gif/webp)"},
                    "b64": {"type": "string", "description": "Base64-encoded image data (alternative to path)"},
                    "media_type": {"type": "string", "description": "MIME type when using b64, e.g. image/png"},
                    "question": {"type": "string", "description": "What to ask about the image (default: 'Describe this image.')"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "describe_screen",
            "description": "Accessibility: screenshot the screen, analyze it, and speak the description via local-first TTS (Kokoro offline, OpenAI fallback). Returns the text description even if audio is unavailable.",
            "parameters": {
                "type": "object",
                "properties": {
                    "question": {"type": "string", "description": "Optional specific question about the screen (default: general accessibility description)"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "cognitive_accessibility",
            "description": "Accessibility: rewrite text to be cognitively accessible for ADHD/dyslexia/autism/plain-language readers — short sentences, plain words, clear structure, no jargon. Preserves meaning. Returns the rewritten text.",
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "The text to make cognitively accessible"},
                    "profile": {"type": "string", "description": "Target profile: plain (default), dyslexia, adhd, or autism"}
                },
                "required": ["text"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "voice_command",
            "description": "Accessibility: transcribe a spoken-audio file into a command Lucy can act on (provider STT first, speech_recognition fallback). Provide 'audio_path'. Live-mic capture is environment-dependent.",
            "parameters": {
                "type": "object",
                "properties": {
                    "audio_path": {"type": "string", "description": "Path to an audio file (wav/mp3/m4a) containing the spoken command"}
                },
                "required": ["audio_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "bci_signal",
            "description": "Accessibility: read from a brain-computer-interface signal source (brainflow/bcipy). Returns signal status/sample. Live headset is environment-dependent.",
            "parameters": {"type": "object", "properties": {"action": {"type": "string", "description": "status (default) or read"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "eye_gaze",
            "description": "Accessibility: eye-gaze input — report tracker status / current gaze (tobii_research/pygaze). Live tracker is environment-dependent.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files in a directory. Optional 'pattern' (glob) and 'recursive' (bool).",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "pattern": {"type": "string"}, "recursive": {"type": "boolean"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "diff_view",
            "description": "Show a unified diff between two files (path_a, path_b) or two texts (text_a, text_b).",
            "parameters": {"type": "object", "properties": {"path_a": {"type": "string"}, "path_b": {"type": "string"}, "text_a": {"type": "string"}, "text_b": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "read_lines",
            "description": "Read a 1-based inclusive line range of a file: path, start, end.",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "start": {"type": "integer"}, "end": {"type": "integer"}}, "required": ["path"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "clipboard",
            "description": "Read or write the system clipboard. action: 'read' (default) or 'write' (with 'text').",
            "parameters": {"type": "object", "properties": {"action": {"type": "string"}, "text": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "file_hash",
            "description": "SHA-256 of a file ('path') or text ('text') — for hash-based dedup / integrity.",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "text": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "json_query",
            "description": "Extract a dotted path (a.b.0.c) from a JSON file. path=<json file>, query=<dotted path>.",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "query": {"type": "string"}}, "required": ["path"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "help",
            "description": "Multi-format help: list Lucy's tools + usage. Optional 'filter' substring, or 'name' for one tool's full schema.",
            "parameters": {"type": "object", "properties": {"filter": {"type": "string"}, "name": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "settings_get",
            "description": "Read a key from Lucy's config (~/.aibrain/config.json). No key = dump all.",
            "parameters": {"type": "object", "properties": {"key": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "settings_set",
            "description": "Set a key in Lucy's config (~/.aibrain/config.json). Backs up the config first.",
            "parameters": {"type": "object", "properties": {"key": {"type": "string"}, "value": {}}, "required": ["key", "value"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "provider_status",
            "description": "Show the active provider/model and what the resolver currently returns + known providers.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "set_provider",
            "description": "Switch Lucy's default_provider (deepseek/claude_cli/openai_sub/openai/anthropic). Validates + backs up config; effective next turn.",
            "parameters": {"type": "object", "properties": {"provider": {"type": "string"}}, "required": ["provider"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "set_model",
            "description": "Set Lucy's default_model in config (backs up first).",
            "parameters": {"type": "object", "properties": {"model": {"type": "string"}}, "required": ["model"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "describe_clipboard_image",
            "description": "Accessibility: capture an image from the clipboard and describe it via vision. Optional 'question'.",
            "parameters": {"type": "object", "properties": {"question": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "speak",
            "description": "Accessibility: speak text aloud via text-to-speech (pyttsx3 or Windows SAPI).",
            "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "higgsfield_generate",
            "description": "F-LUCY-HIGGSFIELD-AUTOMATION-1: drive Higgsfield's web UI via Playwright CDP-attach to generate an image or video against Decker's pro subscription (not API credits). Persistent-context login cached at ~/.aibrain/playwright_higgsfield_state/. Returns the output file path on success or an [error] string. Long-running (10s-5min for video). Use for content creation pipelines.",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "The prompt text (Seedance/Banana-pro style)."},
                    "out_path": {"type": "string", "description": "Absolute path to write the generated artifact (mp4 for video, png for image)."},
                    "model": {"type": "string", "description": "Optional model id (e.g. seedance_2_0, nano_banana_2). Default: seedance_2_0."},
                    "headed": {"type": "boolean", "description": "Show browser window (true for first-run OAuth). Default: false."}
                },
                "required": ["prompt", "out_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "summarize",
            "description": "Summarize text ('text') or a file ('path') via the active provider. Optional 'length': short/medium/long.",
            "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "path": {"type": "string"}, "length": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "cache_put",
            "description": "Content-addressed cache: store 'value' or file at 'path' under its sha256 key (dedup by construction). Returns the key.",
            "parameters": {"type": "object", "properties": {"value": {"type": "string"}, "path": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "cache_get",
            "description": "Retrieve a value from the content-addressed cache by sha256 'key'.",
            "parameters": {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "batch_run",
            "description": "Batch execution: run a list of steps in order, each {shell:...} or {python: 'import ...'}. Stops on first failure unless continue_on_error.",
            "parameters": {"type": "object", "properties": {"steps": {"type": "array"}, "continue_on_error": {"type": "boolean"}}, "required": ["steps"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "contrast_apca",
            "description": "Accessibility: APCA-W3 perceptual contrast (Lc) between text and bg hex colors (the modern WCAG3 contrast model).",
            "parameters": {"type": "object", "properties": {"text": {"type": "string"}, "bg": {"type": "string"}}, "required": ["text", "bg"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "wait_for",
            "description": "Wait until a condition holds or timeout. condition: file_exists | port_open | process; value=target; timeout secs (default 30).",
            "parameters": {"type": "object", "properties": {"condition": {"type": "string"}, "value": {"type": "string"}, "timeout": {"type": "number"}}, "required": ["condition", "value"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "verify_integrity",
            "description": "Verify a file's SHA-256 matches an expected value (path + expected).",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "expected": {"type": "string"}}, "required": ["path", "expected"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "git_commit",
            "description": "Stage+commit changes in a git repo. dry_run (default true) shows what WOULD commit; set dry_run=false with a message to actually commit. Never pushes.",
            "parameters": {"type": "object", "properties": {"repo": {"type": "string"}, "message": {"type": "string"}, "paths": {"type": "array", "items": {"type": "string"}}, "dry_run": {"type": "boolean"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "lint",
            "description": "Lint a Python file: py_compile syntax check plus pyflakes if available.",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "token_usage",
            "description": "Recent token usage / cost summary (aibrain usage reporting if present, else execution_log cost over last 24h).",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "reformat",
            "description": "Reformat a file in place (Cursorless-style reformat action). Python: ruff/black if available; JS/TS/CSS/JSON/MD: prettier if available; universal stdlib fallback: strip trailing whitespace + ensure final newline. Always does a real, safe normalization.",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "privacy_mode",
            "description": "Screen-curtain privacy mode. action 'get'|'set' (+ state on/off). When ON, screen/clipboard-image/image capture tools refuse.",
            "parameters": {"type": "object", "properties": {"action": {"type": "string"}, "state": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "context_files",
            "description": "Manage a persisted set of pinned context files. action 'list'|'add'|'drop'|'clear' (+ path for add/drop).",
            "parameters": {"type": "object", "properties": {"action": {"type": "string"}, "path": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "undo_last_change",
            "description": "Restore the most recently edit_file/write_file-modified file from its .lucybak snapshot.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "describe_prompt",
            "description": "Get/set the custom vision describe prompt used by analyze_image when no question is given. action 'get'|'set'(+text)|'reset'.",
            "parameters": {"type": "object", "properties": {"action": {"type": "string"}, "text": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "describe_focused",
            "description": "Describe the currently focused / foreground UI window+control (screen-reader parity).",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "repair",
            "description": "Environment health check + safe light repair (backend reachability, privacy state, undo/context state).",
            "parameters": {"type": "object", "properties": {"action": {"type": "string"}}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "read_clipboard",
            "description": "Read the current system clipboard contents.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_clipboard",
            "description": "Write text to the system clipboard.",
            "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "notebook_edit",
            "description": "Edit a Jupyter notebook (.ipynb): replace the source of the cell at cell_index, or append a new cell when mode='append'.",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "cell_index": {"type": "integer"}, "source": {"type": "string"}, "mode": {"type": "string"}}, "required": ["path", "source"]}
        }
    },
]


# F-LUCY-DEFERRED-TOOLS-1: deferred tool library
DEFERRED_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_pdf",
            "description": "Extract text from a PDF file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "read_csv",
            "description": "Read a CSV file and return as table",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    },
                    "max_rows": {
                        "type": "integer"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "read_json",
            "description": "Read and parse a JSON file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_csv",
            "description": "Write data to a CSV file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    },
                    "rows": {
                        "type": "array"
                    }
                },
                "required": [
                    "path",
                    "rows"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": "List files in a directory",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    },
                    "recursive": {
                        "type": "boolean"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "file_info",
            "description": "Get file metadata",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "git_log",
            "description": "Show recent git commits",
            "parameters": {
                "type": "object",
                "properties": {
                    "count": {
                        "type": "integer"
                    },
                    "path": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "git_diff",
            "description": "Show git diff",
            "parameters": {
                "type": "object",
                "properties": {
                    "file": {
                        "type": "string"
                    },
                    "base": {
                        "type": "string"
                    }
                },
                "required": [
                    "file",
                    "base"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "git_status",
            "description": "Show git working tree status",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "pip_list",
            "description": "List installed Python packages",
            "parameters": {
                "type": "object",
                "properties": {
                    "filter": {
                        "type": "string"
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_pytest",
            "description": "Run pytest",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    },
                    "flags": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "env_get",
            "description": "Get an environment variable",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string"
                    }
                },
                "required": [
                    "name"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "http_get",
            "description": "HTTP GET request",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string"
                    },
                    "headers": {
                        "type": "object"
                    }
                },
                "required": [
                    "url"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "http_post",
            "description": "HTTP POST request",
            "parameters": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string"
                    },
                    "body": {
                        "type": "object"
                    },
                    "headers": {
                        "type": "object"
                    }
                },
                "required": [
                    "url",
                    "body"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "count_lines",
            "description": "Count lines in a file",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    },
                    "pattern": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "find_duplicates",
            "description": "Find duplicate files",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "compress_files",
            "description": "Create a zip archive",
            "parameters": {
                "type": "object",
                "properties": {
                    "paths": {
                        "type": "array"
                    },
                    "output": {
                        "type": "string"
                    }
                },
                "required": [
                    "paths",
                    "output"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "extract_archive",
            "description": "Extract an archive",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    },
                    "output_dir": {
                        "type": "string"
                    }
                },
                "required": [
                    "path",
                    "output_dir"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "hash_file",
            "description": "Compute SHA-256 hash",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    }
                },
                "required": [
                    "path"
                ]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "diff_files",
            "description": "Show unified diff between files",
            "parameters": {
                "type": "object",
                "properties": {
                    "path_a": {
                        "type": "string"
                    },
                    "path_b": {
                        "type": "string"
                    }
                },
                "required": [
                    "path_a",
                    "path_b"
                ]
            }
        }
    }
]


def _search_deferred_tools(query: str) -> list:
    """F-LUCY-DEFERRED-TOOLS-1."""
    q = query.lower()
    results = []
    for t in DEFERRED_TOOLS:
        n = t["function"]["name"].lower()
        d = t["function"]["description"].lower()
        if q in n or q in d:
            results.append(t)
    return results[:10]


# SA-2026-002 / F-07 fix — auto-approve list for bash tool.
# Read-only / inspection commands run without confirmation; everything else
# is classified as needs_confirmation and Lucy must surface to Decker first.
_AUTO_APPROVE_FIRST_TOKENS = frozenset({
    "ls", "dir", "pwd", "cat", "head", "tail", "wc",
    "grep", "findstr", "find", "where", "which", "stat", "file", "type",
})

# SA-2026-002 / F-13 fix — auto-approve list for python tool. Modules and call
# patterns that produce no side effects and never write to files / network /
# subprocess. Anything outside this set requires Decker confirmation.
_PYTHON_SAFE_IMPORTS = frozenset({
    "math", "json", "decimal", "fractions", "statistics", "datetime",
    "re", "collections", "itertools", "functools", "operator", "string",
    "hashlib", "secrets", "uuid", "base64", "binascii",
    "typing", "dataclasses", "enum",
    "html", "urllib",
})


def _classify_python_risk(code: str) -> tuple:
    """F-LUCY-GATE-DEFAULTS-FLIP-1 — allow-first classification.

    Returns (verdict, reason) where verdict is one of:
      - 'allowed'  : passes Hands._validate_python_code. Default for all normal ops.
      - 'denied'   : fails _validate_python_code outright (dangerous constructs)

    No 'needs_confirmation' verdict. Everything passes unless denied.
    Fail-safe default: any exception in classification -> 'denied'.
    """
    try:
        from aibrain.core.the_hands import Hands  # noqa: WPS433
        ok, reason = Hands._validate_python_code(code)
        if not ok:
            return "denied", reason
        return "allowed", "default-allow"
    except Exception as e:
        return "denied", f"classification error (fail-closed): {e}"


import re as _re_destructive

# Destructive-op pattern set — ported verbatim from
# decker_system/04_tools/destructive_op_prompt.py (PATTERNS list).
# Each entry: (label, compiled_regex, optional_predicate(cmd)->bool).
# If predicate returns False, the pattern is skipped.
#
# ABSOLUTE: authorization is HUMAN ONLY via Telegram YES from DECKER_DM_ID.
# No env-var bypass, no agent-id allowlist, no caller-trust escape.

_LUCY_HARD_BLOCK_ROOT_RM = _re_destructive.compile(
    r"\brm\s+-r[f]?\b.*\s/(?:\s|$)",
    _re_destructive.IGNORECASE,
)
_LUCY_RM_RECURSIVE_NON_ROOT = _re_destructive.compile(
    r"\brm\s+-[a-zA-Z]*r[a-zA-Z]*\b",
    _re_destructive.IGNORECASE,
)
_LUCY_LOCALHOST = _re_destructive.compile(
    r"localhost|127\.0\.0\.1|0\.0\.0\.0", _re_destructive.IGNORECASE
)


def _lucy_curl_wget_non_localhost(cmd: str) -> bool:
    return _LUCY_LOCALHOST.search(cmd) is None


_DESTRUCTIVE_PATTERNS = (
    ("rmdir", _re_destructive.compile(r"\brmdir\b", _re_destructive.IGNORECASE), None),
    (
        "non-root recursive rm",
        _LUCY_RM_RECURSIVE_NON_ROOT,
        lambda c: _LUCY_HARD_BLOCK_ROOT_RM.search(c) is None,
    ),
    (
        "git push --force / --force-with-lease",
        _re_destructive.compile(r"\bgit\s+push\s+.*--force(-with-lease)?\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "git reset --hard",
        _re_destructive.compile(r"\bgit\s+reset\s+--hard\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "git branch -D (force delete)",
        _re_destructive.compile(r"\bgit\s+branch\s+-D\b"),
        None,
    ),
    (
        "git tag -d (delete tag)",
        _re_destructive.compile(r"\bgit\s+tag\s+-d\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "git push --delete (delete remote branch)",
        _re_destructive.compile(r"\bgit\s+push\s+.*--delete\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "kill -9 / killall / pkill",
        _re_destructive.compile(r"\bkill\s+-9\b|\bkillall\b|\bpkill\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "chmod -R 777/666/555",
        _re_destructive.compile(r"\bchmod\s+-R\s+(777|666|555)\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "chown -R",
        _re_destructive.compile(r"\bchown\s+-R\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "pip uninstall/remove",
        _re_destructive.compile(r"\bpip\s+(uninstall|remove)\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "npm uninstall/remove",
        _re_destructive.compile(r"\bnpm\s+(uninstall|remove)\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "apt remove/purge/autoremove",
        _re_destructive.compile(r"\bapt(-get)?\s+(remove|purge|autoremove)\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "brew uninstall/rm/remove",
        _re_destructive.compile(r"\bbrew\s+(uninstall|rm|remove)\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "docker compose down -v (volume removal)",
        _re_destructive.compile(r"\bdocker\s+compose\s+down\b.*-v\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "docker volume rm / rmi -f / system prune / container prune",
        _re_destructive.compile(
            r"\bdocker\s+volume\s+rm\b"
            r"|\bdocker\s+rmi\s+-f\b"
            r"|\bdocker\s+(system|container)\s+prune\b",
            _re_destructive.IGNORECASE,
        ),
        None,
    ),
    (
        "curl/wget non-localhost mutating verb (POST/PUT/DELETE/PATCH)",
        _re_destructive.compile(
            r"\b(curl|wget)\b.*-X\s+(POST|PUT|DELETE|PATCH)\b",
            _re_destructive.IGNORECASE,
        ),
        _lucy_curl_wget_non_localhost,
    ),
    (
        "sudo / doas",
        _re_destructive.compile(r"\b(sudo|doas)\b"),
        None,
    ),
    (
        "DROP TABLE / TRUNCATE TABLE",
        _re_destructive.compile(r"\b(DROP|TRUNCATE)\s+TABLE\b", _re_destructive.IGNORECASE),
        None,
    ),
    (
        "DELETE FROM without WHERE",
        _re_destructive.compile(
            r"\bDELETE\s+FROM\b(?!.*\bWHERE\b)",
            _re_destructive.IGNORECASE | _re_destructive.DOTALL,
        ),
        None,
    ),
)

_LUCY_DESTRUCTIVE_LOG = Path.home() / ".tmp" / "lucy_destructive_confirmations.log"
_LUCY_TELEGRAM_DB = Path(os.environ.get("LUCY_TELEGRAM_DB", str(Path.home() / ".aibrain" / "telegram_messages.db")))
_LUCY_YES_RE = _re_destructive.compile(r"^\s*y(es)?\s*$", _re_destructive.IGNORECASE)


def _lucy_match_destructive(cmd: str):
    """Return (label, matched_text) on first pattern hit, else None."""
    if not cmd:
        return None
    for label, regex, predicate in _DESTRUCTIVE_PATTERNS:
        m = regex.search(cmd)
        if not m:
            continue
        if predicate is not None and not predicate(cmd):
            continue
        return label, m.group(0)
    return None


def _lucy_log_destructive(line: str) -> None:
    """Append to ~/.tmp/lucy_destructive_confirmations.log. Best-effort."""
    try:
        _LUCY_DESTRUCTIVE_LOG.parent.mkdir(parents=True, exist_ok=True)
        with _LUCY_DESTRUCTIVE_LOG.open("a", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.utcnow().isoformat()}Z] {line}\n")
    except Exception:
        pass


def _confirm_destructive_via_telegram(cmd: str) -> tuple:
    """Human-in-the-loop confirmation for destructive bash commands.

    Returns (ok: bool, reason: str).

    Flow:
      1. Match cmd against _DESTRUCTIVE_PATTERNS. No match -> (True, "no confirmation needed").
      2. Send Telegram DM to DECKER_DM_ID via api.telegram.org.
         Missing TELEGRAM_TOKEN or DECKER_DM_ID -> (False, ...) — fail-closed.
      3. Poll telegram_messages.db every 2s for 60s for a new row from
         DECKER_DM_ID with update_id > last_update_id_at_send_time whose text
         strictly matches ^\\s*y(es)?\\s*$ (case-insensitive).
      4. YES match -> (True, "approved by user via Telegram").
         Anything else / timeout -> (False, "denied or timed out").
      5. Every request + outcome logged to ~/.tmp/lucy_destructive_confirmations.log.

    ABSOLUTE: no agent-id check, no caller-trust escape. Unless
    AIBRAIN_LUCY_AUTOCONFIRM is set truthy, only literal Telegram YES
    from DECKER_DM_ID approves. AUTOCONFIRM bypasses ONLY this human-confirm
    tier — the catastrophic hard-deny tier (_classify_bash_risk -> 'denied':
    rm -rf /, format, dd, shutdown) runs upstream and is unaffected.
    """
    import os as _os_ac
    _ac = _os_ac.environ.get("AIBRAIN_LUCY_AUTOCONFIRM", "").strip().lower()
    if _ac in ("1", "true", "yes"):
        _lucy_log_destructive(
            f"AUTOAPPROVE cmd={cmd!r} reason=AIBRAIN_LUCY_AUTOCONFIRM={_ac!r} "
            f"(hard-deny tier upstream in _classify_bash_risk is unaffected)")
        return (True, "auto-approved via AIBRAIN_LUCY_AUTOCONFIRM")
    hit = _lucy_match_destructive(cmd)
    if hit is None:
        return (True, "no confirmation needed")
    label, matched = hit

    import os as _os
    token = _os.environ.get("TELEGRAM_TOKEN", "")
    decker_dm_raw = _os.environ.get("DECKER_DM_ID", "")
    if not token or not decker_dm_raw:
        _lucy_log_destructive(
            f"DENY cmd={cmd!r} pattern={label!r} reason=telegram config missing "
            f"(TELEGRAM_TOKEN={'set' if token else 'unset'}, "
            f"DECKER_DM_ID={'set' if decker_dm_raw else 'unset'})"
        )
        return (False, "telegram config missing — denying destructive op")
    try:
        decker_dm_id = int(decker_dm_raw)
    except (TypeError, ValueError):
        _lucy_log_destructive(
            f"DENY cmd={cmd!r} pattern={label!r} reason=DECKER_DM_ID not int: {decker_dm_raw!r}"
        )
        return (False, "telegram config missing — denying destructive op")

    # Snapshot the watermark BEFORE sending so we only count replies that
    # arrive after the prompt goes out.
    import sqlite3 as _sqlite3
    last_update_id = 0
    try:
        if _LUCY_TELEGRAM_DB.exists():
            _conn = _sqlite3.connect(str(_LUCY_TELEGRAM_DB))
            try:
                row = _conn.execute(
                    "SELECT COALESCE(MAX(update_id), 0) FROM messages"
                ).fetchone()
                last_update_id = int(row[0]) if row else 0
            finally:
                _conn.close()
    except Exception as e:
        _lucy_log_destructive(
            f"WARN cmd={cmd!r} pattern={label!r} watermark-read-error: {e}"
        )
        last_update_id = 0

    prompt = (
        "\U0001f6a8 Lucy wants to run a potentially destructive command:\n\n"
        f"{cmd}\n\n"
        f"Matched pattern: {label}\n\n"
        "Reply YES to approve, anything else to deny.\n"
        "(60-second timeout — no reply = deny)"
    )
    send_url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        import urllib.parse as _uparse
        import urllib.request as _ureq
        payload = _uparse.urlencode(
            {"chat_id": decker_dm_id, "text": prompt}
        ).encode("utf-8")
        req = _ureq.Request(send_url, data=payload, method="POST")
        with _ureq.urlopen(req, timeout=10) as resp:
            _ = resp.read()
    except Exception as e:
        _lucy_log_destructive(
            f"DENY cmd={cmd!r} pattern={label!r} reason=telegram send failed: {e}"
        )
        return (False, f"telegram send failed: {e}")

    _lucy_log_destructive(
        f"PROMPT cmd={cmd!r} pattern={label!r} matched={matched!r} "
        f"watermark={last_update_id} chat_id={decker_dm_id}"
    )

    # Poll the local telegram_messages.db every 2s for 60s.
    deadline = time.time() + 60.0
    while time.time() < deadline:
        time.sleep(2.0)
        try:
            if not _LUCY_TELEGRAM_DB.exists():
                continue
            _conn = _sqlite3.connect(str(_LUCY_TELEGRAM_DB))
            try:
                rows = _conn.execute(
                    "SELECT update_id, text FROM messages "
                    "WHERE chat_id = ? AND update_id > ? "
                    "ORDER BY update_id ASC",
                    (decker_dm_id, last_update_id),
                ).fetchall()
            finally:
                _conn.close()
        except Exception as e:
            _lucy_log_destructive(
                f"WARN cmd={cmd!r} poll-error: {e}"
            )
            continue
        for upd_id, text in rows:
            # Advance watermark so we don't re-read the same row next loop
            # in the unlikely event YES_RE doesn't match but more arrive.
            if upd_id > last_update_id:
                last_update_id = upd_id
            if text and _LUCY_YES_RE.match(text):
                _lucy_log_destructive(
                    f"APPROVE cmd={cmd!r} pattern={label!r} "
                    f"reply_update_id={upd_id} reply_text={text!r}"
                )
                return (True, "approved by user via Telegram")
            else:
                _lucy_log_destructive(
                    f"DENY cmd={cmd!r} pattern={label!r} "
                    f"reply_update_id={upd_id} reply_text={text!r} "
                    f"reason=non-YES reply"
                )
                return (False, "denied or timed out")
    _lucy_log_destructive(
        f"DENY cmd={cmd!r} pattern={label!r} reason=60s timeout no reply"
    )
    return (False, "denied or timed out")


def _classify_bash_risk(cmd: str) -> tuple:
    """F-LUCY-GATE-DEFAULTS-FLIP-1 — allow-first bash classification.

    Returns (verdict, reason) where verdict is one of:
      - 'allowed'   : default. Command passes validation and is NOT destructive.
      - 'audit'     : allowed but logged — state-changing recoverable ops
                      (git push --force, sudo, package uninstalls, chmod)
      - 'denied'    : fails validation OR is genuinely destructive
                      (rm -rf /, format, dd, shutdown/reboot, host-nuking)

    Fail-safe default: any exception -> 'denied'.
    """
    try:
        from aibrain.core.the_hands import Hands
        ok, reason = Hands._validate_shell_cmd(cmd)
        if not ok:
            return "denied", reason
        import shlex as _shlex
        import os as _os
        try:
            argv = _shlex.split(cmd, posix=(_os.name != "nt"))
        except ValueError as e:
            return "denied", f"parse failed: {e}"
        if not argv:
            return "denied", "empty argv"

        # --- DENY: genuinely destructive — nuke the host ---
        DESTRUCTIVE_PATTERNS = [
            ["rm", "-rf", "/"], ["rm", "-r", "/"], ["rmdir", "/"],
            ["format"], ["mkfs"], ["dd", "of=/dev/"], ["dd", "if=/dev/"],
            ["shutdown"], ["reboot"], ["halt"], ["poweroff"],
            [":(){ :|:& };:"],  # fork bomb
            ["chmod", "-R", "777", "/"], ["chown", "-R", "/"],
        ]
        cmd_lower = " ".join(argv).lower()
        for pat in DESTRUCTIVE_PATTERNS:
            if all(p.lower() in cmd_lower for p in pat):
                return "denied", f"destructive pattern: {' '.join(pat)}"

        first = _os.path.basename(argv[0]).lower()
        if first.endswith(".exe"):
            first = first[:-4]

        # --- AUDIT: state-changing but recoverable — log and allow ---
        if first in ("sudo", "su"):
            return "audit", f"privilege escalation: {cmd[:80]}"
        if first == "git" and len(argv) >= 2 and argv[1] in (
            "push", "commit", "merge", "rebase", "reset", "tag", "stash",
        ):
            return "audit", f"state-changing git: {cmd[:80]}"
        if first in ("apt-get", "apt", "brew", "choco", "yum", "dnf", "pacman", "zypper"):
            if len(argv) >= 2 and argv[1] in ("remove", "purge", "uninstall", "autoremove"):
                return "audit", f"package uninstall: {cmd[:80]}"
        if first == "chmod":
            return "audit", f"permission change: {cmd[:80]}"

        # --- ALLOW: everything else ---
        return "allowed", "default-allow"
    except Exception as e:
        return "denied", f"classification error (fail-closed): {e}"


# F-LUCY-DESTRUCTIVE-INTENT-HALT-1: prompt-level intent scanner. Upstream
# of _classify_bash_risk (which catches the COMMAND once chosen) — this
# catches the user-message INTENT before Lucy even consults the LLM.
# Defense-in-depth: both layers must fail for a destructive op to land.
import re as _re_intent

# Patterns mirrored conservatively from
# decker_system/04_tools/destructive_op_prompt.py. Each entry is
# (label, compiled_regex_case_insensitive).
_DESTRUCTIVE_INTENT_PATTERNS = [
    # recursive root deletes
    ("recursive root delete", _re_intent.compile(
        r"\brm\s+(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r)\s+[/~]", _re_intent.I)),
    ("delete everything",     _re_intent.compile(
        r"\b(delete|remove|wipe|nuke|erase)\s+(all|every(thing)?|the\s+whole)\b",
        _re_intent.I)),
    # partition formatting
    ("disk format",           _re_intent.compile(
        r"\b(mkfs|format\s+[a-z]:|diskpart|fdisk.*-w)\b", _re_intent.I)),
    # raw device writes — match any (if|of)=/dev/<disk> anywhere in the
    # command, not just the first. dd if=/dev/urandom of=/dev/sda has if=
    # first (urandom doesn't match) — without .*? the regex misses of=.
    ("raw device write",      _re_intent.compile(
        r"\bdd\b.*?\b(if|of)=/dev/(sd|hd|nvme|xvd|loop|disk)",
        _re_intent.I | _re_intent.DOTALL)),
    # database drop / truncate
    ("database drop",         _re_intent.compile(
        r"\b(drop|truncate)\s+(database|table|schema)\b", _re_intent.I)),
    # shutdown / reboot
    ("shutdown system",       _re_intent.compile(
        r"\b(shutdown|reboot|halt|poweroff)\b", _re_intent.I)),
    # fork bomb
    ("fork bomb",             _re_intent.compile(
        r":\(\)\s*\{\s*:\s*\|\s*:\s*\&\s*\}\s*;\s*:")),
    # recursive perm change to world-writable on root-ish path
    ("recursive perm wipe",   _re_intent.compile(
        r"\bchmod\s+-[a-z]*r[a-z]*\s+(777|666|555)\s+[/~]", _re_intent.I)),
    # recursive ownership change on root-ish path
    ("recursive chown root",  _re_intent.compile(
        r"\bchown\s+-[a-z]*r[a-z]*\s+\S+\s+[/~]", _re_intent.I)),
    # explicit destruction verbs paired with system-y targets
    ("destroy system",        _re_intent.compile(
        r"\b(destroy|nuke|wipe|trash)\s+(the\s+)?(system|host|machine|server|laptop|workstation)\b",
        _re_intent.I)),
]


def _classify_destructive_intent(text: str) -> tuple:
    """Scan a string (typically a user message) for destructive INTENT.

    Returns (is_destructive: bool, label: str).
    label is the matched pattern's name when is_destructive=True, else ''.

    This is a CONSERVATIVE scanner — false positives on a benign "shutdown
    the laptop" sentence are acceptable because the user is asked to
    confirm, and they cost a single y/n prompt. False negatives are not
    acceptable because they bypass the safety layer.
    """
    if not isinstance(text, str) or not text.strip():
        return False, ""
    for label, pat in _DESTRUCTIVE_INTENT_PATTERNS:
        if pat.search(text):
            return True, label
    return False, ""


def _confirm_destructive_intent_locally(text: str, label: str,
                                        timeout_s: float = 30.0) -> bool:
    """Local-stdin y/n confirm with timeout. Default-deny on timeout/EOF.

    Threading-based since input() can't be aborted with select() on
    Windows. The reader thread blocks on input(); the main thread joins
    with a timeout. On timeout, the thread is left to die when the
    process exits — the prompt printing is the only side effect.
    """
    import threading as _thr
    print(f"\n[safety] possible destructive intent in your prompt:")
    print(f"         matched pattern: {label}")
    print(f"         prompt snippet : {text.strip()[:200]}")
    print(f"         proceed anyway? type yes within {int(timeout_s)}s "
          f"(anything else aborts): ", end="", flush=True)

    answer = {"value": None}

    def _reader():
        try:
            answer["value"] = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer["value"] = ""

    t = _thr.Thread(target=_reader, daemon=True)
    t.start()
    t.join(timeout=timeout_s)
    ok = (answer["value"] in ("y", "yes"))

    try:
        _lucy_log_destructive(
            f"INTENT label={label!r} answer={answer['value']!r} ok={ok}"
        )
    except Exception:
        pass

    if not ok:
        print(f"\n[safety] declined — Lucy will not act on the prompt.")
    return ok


import html.parser as _html_parser


class _HTMLTextExtractor(_html_parser.HTMLParser):
    """Stdlib readability: drop script/style/head noise, keep visible text
    with sensible line breaks. No external deps."""

    _SKIP = {"script", "style", "head", "noscript", "svg", "template"}
    _BREAK = {"p", "br", "div", "li", "tr", "h1", "h2", "h3", "h4",
              "h5", "h6", "section", "article"}

    def __init__(self):
        super().__init__()
        self._skip_depth = 0
        self._out = []

    def handle_starttag(self, tag, attrs):
        if tag in self._SKIP:
            self._skip_depth += 1
        elif tag in self._BREAK:
            self._out.append("\n")

    def handle_endtag(self, tag):
        if tag in self._SKIP and self._skip_depth:
            self._skip_depth -= 1
        elif tag in self._BREAK:
            self._out.append("\n")

    def handle_data(self, data):
        if self._skip_depth == 0:
            t = data.strip()
            if t:
                self._out.append(t + " ")

    def text(self):
        import re as _re
        return _re.sub(r"\n{3,}", "\n\n",
                       _re.sub(r"[ \t]+", " ", "".join(self._out))).strip()


def _web_fetch_tool(args: dict) -> str:
    """Fetch a URL. Default returns READABLE CONTENT (HTML stripped to
    text). Pass raw=true for the original HTML body."""
    try:
        import urllib.request
        url = args["url"]
        want_raw = bool(args.get("raw"))
        req = urllib.request.Request(url, headers={"User-Agent": "Lucy/1.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            ctype = (r.headers.get("Content-Type") or "").lower()
            raw = r.read()
        body = raw.decode("utf-8", errors="replace")
        is_html = ("html" in ctype) or body.lstrip()[:200].lower().find("<html") != -1
        if want_raw or not is_html:
            text = body
        else:
            try:
                p = _HTMLTextExtractor()
                p.feed(body)
                text = p.text() or body
            except Exception:
                text = body  # extraction must never lose the fetch
        max_len = 200 * 1024
        if len(text) > max_len:
            text = text[:max_len] + "\n\n[web_fetch: truncated at ~200KB]"
        stripped = text.strip()
        if len(stripped) < 200 and not want_raw:
            text += ("\n[web_fetch: note — content appears short/JS-heavy; "
                     "pass raw=true for HTML or use a browser tool if needed]")
        return text
    except Exception as e:
        return f"[error] web_fetch: {e}"


def _web_search_tool(args: dict) -> str:
    """F-LUCY-WEB-SEARCH-DDG-1: use the ddgs PyPI package for real results
    (duckduckgo_search was renamed to ddgs; importing the old name emits a
    RuntimeWarning — migrated to the correct package, root-fixed not hidden)."""
    try:
        from ddgs import DDGS
        results = DDGS().text(args["query"], max_results=args.get("max_results", 5))
        return "\n".join(f"{r['title']} - {r['href']}\n  {r['body']}" for r in results)
    except ImportError:
        try:
            import urllib.request, urllib.parse, json
            query = urllib.parse.quote(args["query"])
            url = f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1"
            req = urllib.request.Request(url, headers={"User-Agent": "Lucy/1.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())
            results = []
            for topic in data.get("RelatedTopics", [])[:args.get("max_results", 5)]:
                if isinstance(topic, dict):
                    results.append(f"{topic.get('Text','')} - {topic.get('FirstURL','')}")
            return "\n".join(results) if results else "[web_search: no results]"
        except Exception as e:
            return f"[error] web_search: {e}"
    except Exception as e:
        return f"[error] web_search: {e}"


def _glob_files_tool(args: dict) -> str:
    try:
        import glob, os
        base = args.get("path", os.getcwd())
        matches = glob.glob(args["pattern"], root_dir=base, recursive=True)
        return "\n".join(matches[:50]) if matches else "[glob: no matches]"
    except Exception as e:
        return f"[error] glob_files: {e}"

# ============================================================
# phase-3a: thin stdlib/subprocess tools (20) wired by Lucy audit
# ============================================================
def _read_pdf_tool(args: dict) -> str:
    try:
        path = args["path"]
        try:
            import pypdf
        except ImportError:
            return "[error] read_pdf: pypdf not installed; run: pip install pypdf"
        reader = pypdf.PdfReader(path)
        text = "\n".join(page.extract_text() for page in reader.pages[:10])
        if not text.strip():
            return "[read_pdf: no extractable text]"
        return text[:200000]
    except Exception as e:
        return f"[error] read_pdf: {e}"

def _read_csv_tool(args: dict) -> str:
    try:
        import csv
        path = args["path"]
        max_rows = int(args.get("max_rows", 100))
        with open(path, newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            rows = []
            for i, row in enumerate(reader):
                if i >= max_rows:
                    rows.append(f"... (truncated at {max_rows} rows)")
                    break
                rows.append(",".join(row))
            return "\n".join(rows) if rows else "[read_csv: empty]"
    except Exception as e:
        return f"[error] read_csv: {e}"

def _read_json_tool(args: dict) -> str:
    try:
        import json
        path = args["path"]
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return json.dumps(data, indent=2)[:200000]
    except Exception as e:
        return f"[error] read_json: {e}"

def _detect_media_type(data: bytes) -> str:
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        return 'image/png'
    if data[:3] == b'\xff\xd8\xff':
        return 'image/jpeg'
    if data[:6] in (b'GIF89a', b'GIF87a'):
        return 'image/gif'
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return 'image/webp'
    raise ValueError(f"Unsupported image type (first bytes: {data[:12]!r})")

def _ocr_image(raw: bytes):
    """Try local Tesseract OCR on image bytes. Never installs/downloads anything.
    Returns stripped text if successful, else None."""
    try:
        import pytesseract
    except ImportError:
        return None
    import shutil, os as _o
    _tess = shutil.which("tesseract")
    if not _tess:
        # Frictionless: find the binary at common install locations even when
        # it's not on PATH (the UB-Mannheim Windows installer does NOT add to
        # PATH by default — this removes that round-trip).
        for _c in (r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                   r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                   "/usr/bin/tesseract", "/usr/local/bin/tesseract",
                   "/opt/homebrew/bin/tesseract"):
            if _o.path.isfile(_c):
                _tess = _c
                break
    if not _tess:
        return None
    try:
        pytesseract.pytesseract.tesseract_cmd = _tess
    except Exception:
        pass
    try:
        from PIL import Image
        from io import BytesIO
        img = Image.open(BytesIO(raw))
        text = pytesseract.image_to_string(img)
        stripped = text.strip()
        return stripped if stripped else None
    except Exception:
        return None

def _claude_cli_vision(img_path: str, question: str,
                       model: str = "claude-sonnet-4-20250514") -> str:
    """Provider-agnostic Claude vision via the claude CLI subscription auth.
    Uses the verified @path image syntax + the authed CLAUDE_CONFIG_DIR
    profile (same reuse principle as _chat_via_claude_cli). Verified
    2026-05-17: returns a real description with no API key."""
    import subprocess as _sp, json as _json
    from pathlib import Path as _P
    binary = _detect_claude_cli_binary()
    if not binary:
        return "[error] analyze_image: claude binary not found for claude_cli vision."
    env = dict(os.environ)
    # PREFER the proven personal profile; never auto-pick the org profile
    # (.claude-deckerops 403s — see _chat_via_claude_cli root-cause note).
    ccd = None
    for _cand in (".claude-sindecker", ".claude"):
        _p = _P.home() / _cand
        if (_p / ".credentials.json").exists():
            ccd = str(_p)
            break
    if not ccd:
        ccd = env.get("CLAUDE_CONFIG_DIR")
    if ccd:
        env["CLAUDE_CONFIG_DIR"] = ccd
    try:
        proc = _sp.run(
            [binary, "--dangerously-skip-permissions", "--print",
             "--output-format", "json", "--model", model,
             "--max-turns", "2", "--allowedTools", "Read"],
            input=f"{question}\n\n@{img_path}",
            capture_output=True, text=True, timeout=180,
            encoding="utf-8", errors="replace", env=env,
        )
        if proc.returncode != 0:
            return f"[error] analyze_image: claude_cli vision exit {proc.returncode}: {(proc.stderr or '')[:300]}"
        j = _json.loads(proc.stdout)
        if j.get("is_error"):
            return f"[error] analyze_image: claude_cli vision: {str(j.get('result'))[:300]}"
        return j.get("result") or "[error] analyze_image: claude_cli vision returned empty"
    except Exception as e:
        return f"[error] analyze_image: claude_cli vision failed: {type(e).__name__}: {e}"


def _analyze_image_tool(args: dict) -> str:
    """Analyze an image: local Tesseract OCR first (if available), else OpenAI
    gpt-4o vision. mode: 'auto' (default, OCR then vision), 'ocr', 'vision'.
    Provide 'path' or 'b64'+'media_type'."""
    if _lucy_privacy_on():
        return _PRIVACY_BLOCK
    path = args.get("path")
    b64 = args.get("b64")
    media_type = args.get("media_type")
    question = args.get("question") or _lucy_describe_prompt()
    mode = args.get("mode", "auto")
    if not path and not (b64 and media_type):
        return "[error] analyze_image: provide 'path', or 'b64' + 'media_type'."
    # obtain raw bytes for OCR (without interfering with the vision path)
    raw = None
    if path:
        try:
            with open(path, "rb") as f:
                raw = f.read()
        except FileNotFoundError:
            return f"[error] analyze_image: file not found: {path}"
    else:
        if not str(media_type).startswith("image/"):
            return "[error] analyze_image: media_type must be an image/* MIME type."
        try:
            raw = base64.b64decode(b64)
        except Exception:
            raw = None
    # TIER: local OCR first when mode is auto or ocr
    if mode in ("auto", "ocr"):
        ocr_text = _ocr_image(raw) if raw else None
        if ocr_text:
            return f"[ocr]\n{ocr_text}"
        if mode == "ocr":
            return ("[error] analyze_image: OCR mode requested but pytesseract/tesseract "
                    "not available or image has no text. Install tesseract and "
                    "pytesseract, or use mode='vision'.")
    # OCR exhausted — fall through to provider-agnostic vision below.

    # --- PROVIDER-AGNOSTIC vision: route through the ACTIVE provider ---
    try:
        _vp = (_load_config() or {}).get("default_provider") or "openai"
        _vm = (_load_config() or {}).get("default_model")
    except Exception:
        _vp, _vm = "openai", None

    # Ensure we have a real image file path (claude @path needs one) + b64.
    _img_path = path
    try:
        if not _img_path and b64:
            import tempfile as _tf
            _ext = (media_type or "image/png").split("/")[-1]
            _h = _tf.NamedTemporaryFile(suffix="." + _ext, delete=False)
            _h.write(base64.b64decode(b64))
            _h.close()
            _img_path = _h.name
    except Exception:
        _img_path = path

    # Claude (subscription via claude CLI) — verified working, no API key.
    if _vp in ("claude_cli", "anthropic") and _img_path:
        return _claude_cli_vision(_img_path, question,
                                  _vm or "claude-sonnet-4-20250514")

    # OpenAI ChatGPT subscription (codex OAuth token, reused from ~/.codex).
    if _vp == "openai_sub":
        try:
            from aibrain.core import subscription_auth as _sa
            _tok = _sa.get_access_token("openai-codex")
            if path and not b64:
                with open(path, "rb") as _f:
                    _rb = _f.read()
                media_type = _detect_media_type(_rb)
                b64 = base64.b64encode(_rb).decode("utf-8")
            import requests as _rq
            _r = _rq.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {_tok}",
                         "Content-Type": "application/json"},
                json={"model": _vm or "gpt-4o",
                      "messages": [{"role": "user", "content": [
                          {"type": "text", "text": question},
                          {"type": "image_url", "image_url": {
                              "url": f"data:{media_type};base64,{b64}"}}]}],
                      "max_tokens": args.get("max_tokens", 1024)},
                timeout=60)
            if _r.status_code != 200:
                return (f"[error] analyze_image: openai_sub vision HTTP {_r.status_code}: "
                        f"{_r.text[:200]} — codex-token vision endpoint is unverified; "
                        "switch to claude_cli (verified vision).")
            return _r.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return (f"[error] analyze_image: openai_sub vision failed: {e} — "
                    "switch to claude_cli provider (verified).")

    # OpenAI API key (developer API) — original path.
    if not os.getenv("OPENAI_API_KEY"):
        return (f"[error] analyze_image: active provider '{_vp}' has no working vision "
                "path, no local OCR (install tesseract), and OPENAI_API_KEY unset. "
                "Switch to claude_cli for verified subscription vision: "
                f"python {Path.home() / '.aibrain' / 'lucy_switch.py'} claude")
    try:
        if path:
            with open(path, 'rb') as f:
                raw = f.read()
            media_type = _detect_media_type(raw)
            b64 = base64.b64encode(raw).decode('utf-8')
        elif not str(media_type).startswith('image/'):
            return "[error] analyze_image: media_type must be an image/* MIME type."
        from aibrain.core.provider_openai import OpenAITextProvider
        provider = OpenAITextProvider(config={})  # reads OPENAI_API_KEY from env
        resp = provider._invoke_sync({
            "prompt": question,
            "image": {"data": b64, "media_type": media_type},
            "max_tokens": args.get("max_tokens", 1024),
            "temperature": 0.2,
        })
        return resp.get("content") if isinstance(resp, dict) else str(resp)
    except FileNotFoundError:
        return f"[error] analyze_image: file not found: {path}"
    except ValueError as ve:
        return f"[error] analyze_image: {ve}"
    except Exception as e:
        return f"[error] analyze_image: {type(e).__name__}: {e}"

def _write_csv_tool(args: dict) -> str:
    try:
        import csv
        path = args["path"]
        rows_src = args.get("rows", args.get("content", args.get("data", "")))
        if isinstance(rows_src, str):
            rows = [line.split(",") for line in rows_src.strip().splitlines()]
        elif isinstance(rows_src, list):
            rows = rows_src
        else:
            return "[error] write_csv: rows must be string or list of lists"
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerows(rows)
        return f"[wrote] {len(rows)} rows to {path}"
    except Exception as e:
        return f"[error] write_csv: {e}"

def _list_directory_tool(args: dict) -> str:
    try:
        import os
        path = args.get("path", ".")
        entries = sorted(os.listdir(path))
        lines = []
        for e in entries[:200]:
            full = os.path.join(path, e)
            typ = "dir" if os.path.isdir(full) else "file"
            lines.append(f"{typ} | {e}")
        return "\n".join(lines)
    except Exception as e:
        return f"[error] list_directory: {e}"

def _count_lines_tool(args: dict) -> str:
    try:
        path = args["path"]
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            count = sum(1 for _ in f)
        return f"Lines: {count}"
    except Exception as e:
        return f"[error] count_lines: {e}"

def _file_info_tool(args: dict) -> str:
    try:
        import os, time
        path = args["path"]
        st = os.stat(path)
        info = {
            "size": st.st_size,
            "mode": oct(st.st_mode),
            "modified": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime)),
            "is_file": not (st.st_mode & 0o40000),
        }
        return str(info)
    except Exception as e:
        return f"[error] file_info: {e}"

def _hash_file_tool(args: dict) -> str:
    try:
        import hashlib
        path = args["path"]
        algo = args.get("algorithm", "sha256").lower()
        h = hashlib.new(algo)
        with open(path, 'rb') as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                h.update(chunk)
        return f"{algo}: {h.hexdigest()}"
    except Exception as e:
        return f"[error] hash_file: {e}"

def _diff_files_tool(args: dict) -> str:
    try:
        import difflib
        file1 = args["file1"]
        file2 = args["file2"]
        with open(file1, 'r', encoding='utf-8', errors='replace') as f:
            lines1 = f.readlines()
        with open(file2, 'r', encoding='utf-8', errors='replace') as f:
            lines2 = f.readlines()
        diff = list(difflib.unified_diff(lines1, lines2, fromfile=file1, tofile=file2))
        return "".join(diff) if diff else "[diff_files: no differences]"
    except Exception as e:
        return f"[error] diff_files: {e}"

def _find_duplicates_tool(args: dict) -> str:
    try:
        import hashlib, os
        path = args.get("path", ".")
        hashes = {}
        for root, dirs, files in os.walk(path):
            for fname in files:
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, 'rb') as f:
                        digest = hashlib.sha256(f.read()).hexdigest()
                    hashes.setdefault(digest, []).append(fpath)
                except Exception:
                    continue
        dups = {h: paths for h, paths in hashes.items() if len(paths) > 1}
        if not dups:
            return "[find_duplicates: no duplicates]"
        out = []
        for h, paths in list(dups.items())[:20]:
            out.append(f"Hash {h[:12]}...: {len(paths)} files")
            for p in paths[:10]:
                out.append(f"  {p}")
        return "\n".join(out)
    except Exception as e:
        return f"[error] find_duplicates: {e}"

def _compress_files_tool(args: dict) -> str:
    try:
        import zipfile, os
        files = args.get("files", [])
        if isinstance(files, str):
            files = files.split()
        output = args.get("output", "archive.zip")
        if not files:
            return "[compress_files: no files specified]"
        with zipfile.ZipFile(output, 'w') as zf:
            for f in files:
                if os.path.exists(f):
                    zf.write(f, os.path.basename(f))
                else:
                    return f"[error] compress_files: file not found: {f}"
        return f"[compressed] {len(files)} files -> {output}"
    except Exception as e:
        return f"[error] compress_files: {e}"

def _extract_archive_tool(args: dict) -> str:
    try:
        import zipfile, tarfile, os
        archive = args["archive"]
        dest = args.get("dest", ".")
        os.makedirs(dest, exist_ok=True)
        if archive.endswith(".zip"):
            with zipfile.ZipFile(archive, 'r') as zf:
                zf.extractall(dest)
        elif any(archive.endswith(ext) for ext in (".tar.gz", ".tgz", ".tar.bz2", ".tar")):
            with tarfile.open(archive, 'r:*') as tf:
                tf.extractall(dest)
        else:
            return f"[error] extract_archive: unsupported format: {archive}"
        return f"[extracted] {archive} to {dest}"
    except Exception as e:
        return f"[error] extract_archive: {e}"

def _git_status_tool(args: dict) -> str:
    try:
        import subprocess
        cwd = args.get("cwd", ".")
        res = subprocess.run(["git", "status", "--porcelain"], cwd=cwd, capture_output=True, text=True, timeout=10)
        if res.returncode != 0:
            return f"[error] git_status: {res.stderr.strip()}"
        out = res.stdout.strip()
        return out if out else "[git_status: clean]"
    except Exception as e:
        return f"[error] git_status: {e}"

def _git_log_tool(args: dict) -> str:
    try:
        import subprocess
        cwd = args.get("cwd", ".")
        num = args.get("num", "10")
        res = subprocess.run(["git", "log", f"-{num}", "--oneline"], cwd=cwd, capture_output=True, text=True, timeout=10)
        if res.returncode != 0:
            return f"[error] git_log: {res.stderr.strip()}"
        return res.stdout.strip()
    except Exception as e:
        return f"[error] git_log: {e}"

def _git_diff_tool(args: dict) -> str:
    try:
        import subprocess
        cwd = args.get("cwd", ".")
        res = subprocess.run(["git", "diff"], cwd=cwd, capture_output=True, text=True, timeout=10)
        if res.returncode != 0:
            return f"[error] git_diff: {res.stderr.strip()}"
        out = res.stdout.strip()
        return out if out else "[git_diff: no changes]"
    except Exception as e:
        return f"[error] git_diff: {e}"

def _http_get_tool(args: dict) -> str:
    try:
        import urllib.request
        url = args["url"]
        req = urllib.request.Request(url, headers={"User-Agent": "Lucy/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            max_len = 200 * 1024
            if len(body) > max_len:
                body = body[:max_len] + "\n... [truncated at ~200KB]"
            return f"HTTP {resp.status}\n{body}"
    except Exception as e:
        return f"[error] http_get: {e}"

def _http_post_tool(args: dict) -> str:
    try:
        import urllib.request, json
        url = args["url"]
        headers = {"User-Agent": "Lucy/1.0", "Content-Type": "application/json"}
        data = args.get("data", "")
        if isinstance(data, dict):
            data = json.dumps(data)
        req = urllib.request.Request(url, data=data.encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            max_len = 200 * 1024
            if len(body) > max_len:
                body = body[:max_len] + "\n... [truncated at ~200KB]"
            return f"HTTP {resp.status}\n{body}"
    except Exception as e:
        return f"[error] http_post: {e}"

def _env_get_tool(args: dict) -> str:
    try:
        import os
        key = args.get("key", "")
        if not key:
            return "[error] env_get: no key specified"
        deny = ("SECRET", "TOKEN", "KEY", "PASSWORD", "PAT")
        for pat in deny:
            if pat in key.upper():
                return f"[redacted] {key}: <redacted, key name contains secret indicator>"
        val = os.environ.get(key)
        if val is None:
            return f"[env_get] {key}: not set"
        return f"{key}={val}"
    except Exception as e:
        return f"[error] env_get: {e}"

def _pip_list_tool(args: dict) -> str:
    try:
        import subprocess
        res = subprocess.run(["pip", "list", "--format=json"], capture_output=True, text=True, timeout=10)
        if res.returncode != 0:
            return f"[error] pip_list: {res.stderr.strip()}"
        return res.stdout[:200000]
    except Exception as e:
        return f"[error] pip_list: {e}"

def _run_pytest_tool(args: dict) -> str:
    try:
        import subprocess
        cwd = args.get("cwd", ".")
        pytest_args = args.get("args", "")
        cmd = ["pytest"]
        if pytest_args:
            cmd.extend(pytest_args.split())
        res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=120)
        out = res.stdout + res.stderr
        if res.returncode != 0 and not out.strip():
            out = f"pytest failed with code {res.returncode}"
        return out[:200000]
    except Exception as e:
        return f"[error] run_pytest: {e}"

def _grep_files_tool(args: dict) -> str:
    try:
        import glob, os, re
        base = args.get("path", os.getcwd())
        pattern = re.compile(args["pattern"])
        file_glob = args.get("glob", "**/*")
        results = []
        for fpath in glob.glob(file_glob, root_dir=base, recursive=True)[:100]:
            try:
                full = os.path.join(base, fpath)
                if not os.path.isfile(full):
                    continue
                with open(full, encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if pattern.search(line):
                            results.append(f"{fpath}:{i}: {line.rstrip()[:120]}")
                            if len(results) >= 20:
                                break
            except Exception:
                pass
            if len(results) >= 20:
                break
        return "\n".join(results) if results else "[grep: no matches]"
    except Exception as e:
        return f"[error] grep_files: {e}"


def _path_denied(path: str) -> str:
    """F-LUCY-CLAUDE-FILE-LOCKOUT-1. Block writes/edits to Claude Code config dirs.

    Incident 2026-05-16: Lucy edited ~/.claude/settings.json (not her file) and
    wired a hook into it. Decker directive: Claude files go on Lucy's deny list.
    Returns a non-empty block reason if the path is protected, else "".
    """
    try:
        norm = str(Path(str(path)).resolve()).replace("\\", "/").lower()
    except Exception:
        norm = str(path).replace("\\", "/").lower()
    for seg in (".claude", ".claude-deckerops", ".claude-sindecker"):
        if seg in norm.split("/"):
            return (f"[blocked] '{path}' is a Claude Code config path ({seg}). "
                    f"Lucy is denied write/edit access to Claude files "
                    f"(F-LUCY-CLAUDE-FILE-LOCKOUT-1). Use ~/.aibrain/ for Lucy config.")
    return ""


def _edit_file_tool(args: dict) -> str:
    try:
        _deny = _path_denied(args.get("path", ""))
        if _deny:
            return _deny
        with open(args["path"], encoding="utf-8") as f:
            c = f.read()
        old_s = args["old_string"]
        new_s = args["new_string"]
        count = c.count(old_s)
        if count == 0:
            return f"[edit_file: old_string not found in {args['path']}]"
        if args.get("replace_all"):
            c = c.replace(old_s, new_s)
        else:
            c = c.replace(old_s, new_s, 1)
        _lucy_push_undo(args["path"])
        with open(args["path"], "w", encoding="utf-8") as f:
            f.write(c)
        repl = "all" if args.get("replace_all") else "1"
        return f"[edit_file: {args['path']} - {count} occurrences, replaced {repl}]"
    except Exception as e:
        return f"[error] edit_file: {e}"


class _SubagentCoordinator:
    """F-LUCY-TURNTAKING-1: single-speaker coordinator for spawned subagents.
    Bruce-Lee absorption of autogen's active-speaker/transition/termination
    principle — zero autogen/asyncio dependency. Default max_active=1 strictly
    serializes spawns (the spawn_subagent race root); max_turns caps total so
    it can never run unbounded."""

    def __init__(self, max_active: int = 1, max_turns: int = 1000):
        self._cond = threading.Condition()
        self._pending_jobs = []          # list of (tid, prompt)
        self._active_count = 0
        self._max_active = max_active
        self._max_turns = max_turns
        self._turn_count = 0
        self._done_jobs = {}             # tid -> status
        self._scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self._scheduler_thread.start()

    def enqueue(self, prompt: str) -> str:
        import uuid as _uuid
        tid = str(_uuid.uuid4())[:14]
        with self._cond:
            self._pending_jobs.append((tid, prompt))
            pos = len(self._pending_jobs)
            self._cond.notify()
        return f"[subagent spawned] task_id={tid} queue_position={pos}"

    def _scheduler_loop(self) -> None:
        while True:
            with self._cond:
                self._cond.wait_for(
                    lambda: self._pending_jobs and self._active_count < self._max_active
                )
                tid, prompt = self._pending_jobs.pop(0)
                if self._max_turns is not None and self._turn_count >= self._max_turns:
                    self._done_jobs[tid] = "skipped: max_turns reached"
                    continue
                self._active_count += 1
                self._turn_count += 1
            t = threading.Thread(target=self._run_job, args=(tid, prompt), daemon=True)
            t.start()

    def _run_job(self, tid: str, prompt: str) -> None:
        try:
            from aibrain.core.agent_dispatch import dispatch_deepseek_task
            dispatch_deepseek_task(task_id=tid, task_prompt=prompt, agent_id="CDTYrHYkyH8")
        except Exception:
            pass
        finally:
            with self._cond:
                self._active_count -= 1
                self._done_jobs[tid] = "completed"
                self._cond.notify()

    def status(self) -> dict:
        with self._cond:
            return {
                "active": self._active_count,
                "queued": len(self._pending_jobs),
                "done": len(self._done_jobs),
                "turn_count": self._turn_count,
                "max_turns": self._max_turns,
                "max_active": self._max_active,
            }


_subagent_coordinator = _SubagentCoordinator(max_active=1, max_turns=1000)


def _subagent_status() -> dict:
    return _subagent_coordinator.status()


def _spawn_subagent_tool(args: dict) -> str:
    try:
        return _subagent_coordinator.enqueue(args["prompt"])
    except Exception as e:
        return f"[error] spawn_subagent: {e}"


def _cron_create_tool(args: dict) -> str:
    try:
        import json, os
        path = os.path.expanduser("~/.aibrain/scheduled_jobs.json")
        jobs = []
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            jobs = data if isinstance(data, list) else data.get("jobs", [])
        jobs.append({"name": args["name"], "enabled": True, "schedule": args["schedule"], "prompt": args["prompt"]})
        with open(path, "w", encoding="utf-8") as f:
            json.dump(jobs if isinstance(data, list) else {"jobs": jobs}, f, indent=2)
        return f"[cron created] {args['name']} schedule={args['schedule']}"
    except Exception as e:
        return f"[error] cron_create: {e}"


def _screenshot_tool() -> str:
    try:
        import pyautogui, tempfile
        img = pyautogui.screenshot()
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            img.save(f, format='PNG')
            path = f.name
        return f"[screenshot] {path}"
    except Exception as e:
        return f"[error] screenshot: {e}"


def _bci_signal_tool(args: dict) -> str:
    """WS-T2 accessibility: BCI signal interface. Tries brainflow then bcipy.
    Graceful degrade if lib/hardware absent — never crashes. Live headset
    capture is Decker-in-loop, same scope as _describe_screen_tool."""
    try:
        try:
            from brainflow.board_shim import BoardShim, BrainFlowInputParams, BoardIds
            board = BoardShim(BoardIds.SYNTHETIC_BOARD.value, BrainFlowInputParams())
            board.prepare_session()
            board.start_stream()
            import time as _t
            _t.sleep(0.3)
            data = board.get_board_data()
            board.stop_stream()
            board.release_session()
            sh = getattr(data, "shape", (0, 0))
            return (f"BCI: brainflow OK — synthetic board, {sh[0]} channels, "
                    f"{sh[1] if len(sh) > 1 else 0} samples. Real headset = Decker-in-loop.")
        except ImportError:
            pass
        try:
            import bcipy  # noqa: F401
            return ("BCI: bcipy present — acquisition pipeline available. Live "
                    "EEG requires a configured headset (Decker-in-loop).")
        except ImportError:
            pass
        return ("[error] bci_signal: no BCI library installed (pip install "
                "brainflow or bcipy). Tool is wired; works once a lib is present.")
    except Exception as e:
        return f"[error] bci_signal: {type(e).__name__}: {e}"


def _eye_gaze_tool(args: dict) -> str:
    """WS-T2 accessibility: eye-gaze input interface. Tries tobii_research
    then pygaze. Graceful degrade if lib/hardware absent — never crashes.
    Live tracking is Decker-in-loop, same scope as _describe_screen_tool."""
    try:
        try:
            import tobii_research as _tr
            ets = _tr.find_all_eyetrackers()
            if ets:
                return (f"EYE-GAZE: tobii_research OK — tracker "
                        f"'{getattr(ets[0], 'model', '?')}' found. Live stream = Decker-in-loop.")
            return "EYE-GAZE: tobii_research present, no tracker connected (Decker-in-loop)."
        except ImportError:
            pass
        try:
            import pygaze  # noqa: F401
            return ("EYE-GAZE: pygaze present — gaze pipeline available. Live "
                    "tracking requires a configured tracker (Decker-in-loop).")
        except ImportError:
            pass
        return ("[error] eye_gaze: no eye-tracking library installed (pip "
                "install tobii-research or python-pygaze). Tool is wired.")
    except Exception as e:
        return f"[error] eye_gaze: {type(e).__name__}: {e}"


def _voice_command_tool(args: dict) -> str:
    """WS-T2 accessibility: transcribe spoken audio into a command Lucy can
    act on. Provider STT (OpenAI-compatible whisper) first, speech_recognition
    fallback. Graceful degrade — never crashes. Live-mic capture is a
    Decker-in-loop test, same honest scope as _describe_screen_tool. Provide
    'audio_path' to an audio file (wav/mp3/m4a)."""
    import os as _os
    path = (args.get("audio_path") or "").strip()
    if not path:
        return ("[error] voice_command: provide 'audio_path' to an audio file. "
                "Live-mic capture is environment-dependent (Decker-in-loop).")
    if not _os.path.isfile(path):
        return f"[error] voice_command: file not found: {path}"
    _voice_err = "no OPENAI_API_KEY for provider STT"
    if _os.environ.get("OPENAI_API_KEY"):
        try:
            import openai as _openai
            client = _openai.OpenAI(api_key=_os.environ["OPENAI_API_KEY"])
            with open(path, "rb") as fh:
                tr = client.audio.transcriptions.create(model="whisper-1", file=fh)
            txt = (getattr(tr, "text", "") or "").strip()
            if txt:
                return f"VOICE COMMAND (provider STT): {txt}"
            _voice_err = "provider STT returned empty"
        except Exception as e:
            _voice_err = f"provider STT failed: {type(e).__name__}: {e}"
    try:
        import speech_recognition as _sr
    except ImportError:
        return ("[error] voice_command: no STT available — " + _voice_err +
                "; 'speech_recognition' not installed (pip install "
                "SpeechRecognition). Tool is wired; works once an STT path exists.")
    try:
        r = _sr.Recognizer()
        with _sr.AudioFile(path) as src:
            audio = r.record(src)
        try:
            txt = r.recognize_google(audio)
        except Exception:
            txt = r.recognize_sphinx(audio)
        txt = (txt or "").strip()
        return (f"VOICE COMMAND (speech_recognition): {txt}" if txt
                else "[error] voice_command: transcription empty.")
    except Exception as e:
        return f"[error] voice_command: STT fallback failed: {type(e).__name__}: {e}"


def _lucy_state_dir() -> str:
    import os as _os
    d = _os.path.join(_os.path.expanduser("~"), ".aibrain")
    _os.makedirs(d, exist_ok=True)
    return d


def _lucy_describe_prompt() -> str:
    """Custom vision describe prompt (used as the analyze_image default
    question when none is supplied). Falls back to the stock prompt."""
    import os as _os
    p = _os.path.join(_lucy_state_dir(), "lucy_describe_prompt.txt")
    try:
        if _os.path.isfile(p):
            t = open(p, encoding="utf-8").read().strip()
            if t:
                return t
    except Exception:
        pass
    return "Describe this image."


def _describe_prompt_tool(args: dict) -> str:
    """Get/set the custom vision describe prompt. action 'get' (default) |
    'set' (+ text) | 'reset'. The prompt is what analyze_image uses by
    default when no explicit question is passed."""
    import os as _os
    p = _os.path.join(_lucy_state_dir(), "lucy_describe_prompt.txt")
    action = (args.get("action") or "get").strip().lower()
    if action == "set":
        text = (args.get("text") or "").strip()
        if not text:
            return "[error] describe_prompt set: 'text' required."
        open(p, "w", encoding="utf-8").write(text)
        return f"describe_prompt: set ({len(text)} chars). analyze_image will use this by default."
    if action == "reset":
        if _os.path.isfile(p):
            _os.remove(p)
        return "describe_prompt: reset to stock ('Describe this image.')"
    return f"describe_prompt (current): {_lucy_describe_prompt()!r}"


def _describe_focused_tool(args: dict) -> str:
    """Describe the currently focused / foreground UI element. ctypes
    user32 (always available on Windows); richer detail if 'uiautomation'
    is installed."""
    import ctypes
    try:
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        n = u.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        u.GetWindowTextW(hwnd, buf, n + 1)
        title = buf.value or "(no title)"
        pid = ctypes.c_ulong()
        u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        base = f"focused window: {title!r} (hwnd={hwnd}, pid={pid.value})"
    except Exception as e:
        return f"[error] describe_focused: {type(e).__name__}: {e}"
    try:
        import uiautomation as _ua
        el = _ua.GetFocusedControl()
        if el:
            base += (f"\nfocused control: {el.ControlTypeName} "
                     f"name={el.Name!r} value={getattr(el, 'GetValuePattern', lambda: None)() and ''}")
    except Exception:
        base += "\n(install 'uiautomation' for focused-control detail)"
    return base


def _repair_tool(args: dict) -> str:
    """Environment health check + safe light repair. Reports backend
    reachability, privacy state, undo-stack depth. Never restarts shared
    services or deletes outside Lucy state (those are surfaced, not auto-run)."""
    import os as _os, socket as _sock, json as _json
    out = []
    try:
        s = _sock.create_connection(("127.0.0.1", 8001), timeout=2)
        s.close()
        out.append("backend :8001 reachable: OK")
    except Exception as e:
        out.append(f"backend :8001 UNREACHABLE ({type(e).__name__}) — "
                   "surface: `python -m uvicorn backend.main:app --port 8001` "
                   "(not auto-run: shared service)")
    out.append("privacy_mode: " + ("ON" if _lucy_privacy_on() else "OFF"))
    stk = _os.path.join(_lucy_state_dir(), "lucy_undo_stack.json")
    try:
        depth = len(_json.load(open(stk, encoding="utf-8"))) if _os.path.isfile(stk) else 0
    except Exception:
        depth = 0
    out.append(f"undo stack depth: {depth}")
    cf = _os.path.join(_lucy_state_dir(), "lucy_context_files.json")
    try:
        pinned = len(_json.load(open(cf, encoding="utf-8"))) if _os.path.isfile(cf) else 0
    except Exception:
        pinned = 0
    out.append(f"pinned context files: {pinned}")
    return "repair (health check):\n" + "\n".join("  - " + x for x in out)


def _lucy_privacy_on() -> bool:
    import os as _os
    return _os.path.isfile(_os.path.join(_lucy_state_dir(), "lucy_privacy.flag"))


_PRIVACY_BLOCK = ("[privacy] screen-curtain / privacy mode is ON — screen, "
                  "clipboard-image and image capture are blocked. Disable with "
                  "privacy_mode {\"action\":\"set\",\"state\":\"off\"}.")


def _privacy_mode_tool(args: dict) -> str:
    """Screen-curtain privacy mode. action: 'get' (default) | 'set' (+ state
    'on'/'off'). When ON, describe_screen / describe_clipboard_image /
    analyze_image refuse to capture."""
    import os as _os
    flag = _os.path.join(_lucy_state_dir(), "lucy_privacy.flag")
    action = (args.get("action") or "get").strip().lower()
    if action == "set":
        state = (args.get("state") or "").strip().lower()
        if state in ("on", "true", "1", "enable", "enabled"):
            open(flag, "w").close()
            return "privacy_mode: ON (capture tools now blocked)"
        if state in ("off", "false", "0", "disable", "disabled"):
            if _os.path.isfile(flag):
                _os.remove(flag)
            return "privacy_mode: OFF (capture tools enabled)"
        return "[error] privacy_mode: set requires state 'on' or 'off'."
    return f"privacy_mode: {'ON' if _lucy_privacy_on() else 'OFF'}"


def _context_files_tool(args: dict) -> str:
    """Manage a persisted set of pinned context files. action:
    'list' (default) | 'add' (+path) | 'drop' (+path) | 'clear'."""
    import os as _os, json as _json
    store = _os.path.join(_lucy_state_dir(), "lucy_context_files.json")
    try:
        cur = _json.load(open(store, encoding="utf-8")) if _os.path.isfile(store) else []
    except Exception:
        cur = []
    action = (args.get("action") or "list").strip().lower()
    if action == "add":
        p = (args.get("path") or "").strip()
        if not p:
            return "[error] context_files add: 'path' required."
        if not _os.path.isfile(p):
            return f"[error] context_files add: not a file: {p}"
        if p not in cur:
            cur.append(p)
        _json.dump(cur, open(store, "w", encoding="utf-8"))
        return f"context_files: added {p} ({len(cur)} pinned)"
    if action == "drop":
        p = (args.get("path") or "").strip()
        cur = [x for x in cur if x != p]
        _json.dump(cur, open(store, "w", encoding="utf-8"))
        return f"context_files: dropped {p} ({len(cur)} pinned)"
    if action == "clear":
        _json.dump([], open(store, "w", encoding="utf-8"))
        return "context_files: cleared (0 pinned)"
    return ("context_files (" + str(len(cur)) + " pinned):\n"
            + ("\n".join(f"  - {x}" for x in cur) if cur else "  (none)"))


def _lucy_push_undo(path: str) -> None:
    """Best-effort: snapshot an about-to-be-modified file for undo_last_change.
    Never raises into the caller's edit/write path."""
    import os as _os, json as _json, shutil as _sh
    try:
        if not path or not _os.path.isfile(path):
            return
        _sh.copy2(path, path + ".lucybak")
        stk = _os.path.join(_lucy_state_dir(), "lucy_undo_stack.json")
        try:
            s = _json.load(open(stk, encoding="utf-8")) if _os.path.isfile(stk) else []
        except Exception:
            s = []
        s.append(path)
        s = s[-20:]
        _json.dump(s, open(stk, "w", encoding="utf-8"))
    except Exception:
        pass


def _undo_last_change_tool(args: dict) -> str:
    """Restore the most recently edit_file/write_file-modified file from its
    .lucybak snapshot."""
    import os as _os, json as _json, shutil as _sh
    stk = _os.path.join(_lucy_state_dir(), "lucy_undo_stack.json")
    try:
        s = _json.load(open(stk, encoding="utf-8")) if _os.path.isfile(stk) else []
    except Exception:
        s = []
    if not s:
        return "undo_last_change: nothing to undo (no recorded changes)."
    path = s.pop()
    bak = path + ".lucybak"
    if not _os.path.isfile(bak):
        _json.dump(s, open(stk, "w", encoding="utf-8"))
        return f"[error] undo_last_change: snapshot missing for {path}"
    try:
        _sh.copy2(bak, path)
        _os.remove(bak)
        _json.dump(s, open(stk, "w", encoding="utf-8"))
        return f"undo_last_change: restored {path} ({len(s)} undo levels left)"
    except Exception as e:
        return f"[error] undo_last_change: {type(e).__name__}: {e}"


def _git_commit_tool(args: dict) -> str:
    """Git stage+commit in a repo. dry_run (default True) shows what WOULD
    commit; dry_run=false actually commits. Never pushes."""
    import subprocess as _sp, os as _os
    repo = (args.get("repo") or ".").strip()
    msg = (args.get("message") or "").strip()
    dry = args.get("dry_run", True)
    if not _os.path.isdir(repo):
        return f"[error] git_commit: not a directory: {repo}"

    def g(*a):
        return _sp.run(["git", "-C", repo, *a], capture_output=True, text=True, timeout=30)

    try:
        st = g("status", "--porcelain")
        if st.returncode != 0:
            return f"[error] git_commit: not a git repo / {st.stderr[:150]}"
        if not st.stdout.strip():
            return "git_commit: nothing to commit (clean tree)"
        if dry in (True, "true", "True", 1, "1"):
            ds = g("diff", "--stat")
            return ("git_commit DRY-RUN (nothing committed). Changes:\n"
                    + st.stdout[:800] + "\n--- diff stat ---\n" + ds.stdout[:600]
                    + "\nSet dry_run=false (+ message) to actually commit.")
        if not msg:
            return "[error] git_commit: 'message' required to actually commit."
        paths = args.get("paths")
        add = g("add", *(paths if isinstance(paths, list) and paths else ["-A"]))
        if add.returncode != 0:
            return f"[error] git_commit: add failed: {add.stderr[:200]}"
        cm = g("commit", "-m", msg)
        return (f"git_commit: committed.\n{cm.stdout[:400]}" if cm.returncode == 0
                else f"[error] git_commit: commit failed: {cm.stderr[:300]}")
    except Exception as e:
        return f"[error] git_commit: {type(e).__name__}: {e}"


def _lint_tool(args: dict) -> str:
    """Lint a Python file: py_compile (syntax) + pyflakes if available."""
    import subprocess as _sp, sys as _sys, os as _os
    p = (args.get("path") or "").strip()
    if not p or not _os.path.isfile(p):
        return f"[error] lint: not a file: {p}"
    out = []
    cc = _sp.run([_sys.executable, "-m", "py_compile", p],
                 capture_output=True, text=True, timeout=30)
    out.append("py_compile: OK" if cc.returncode == 0
               else "py_compile: SYNTAX ERROR\n" + cc.stderr[:500])
    try:
        r = _sp.run([_sys.executable, "-m", "pyflakes", p],
                    capture_output=True, text=True, timeout=30)
        out.append("pyflakes: " + (r.stdout.strip()[:800] or "clean"))
    except Exception:
        out.append("pyflakes: not available (py_compile only)")
    return f"lint {p}:\n" + "\n".join(out)


def _reformat_tool(args: dict) -> str:
    """Cursorless-style 'reformat' action: reformat a file in place.
    Python -> ruff/black if available; JS/TS/CSS/JSON/MD/HTML -> prettier via
    npx (shutil.which-resolved — Windows npx is npx.CMD) if available;
    universal stdlib fallback always runs: strip trailing whitespace +
    ensure a single final newline. Never errors out empty — the
    accessibility 'reformat this' must always do something real + safe."""
    import subprocess as _sp, sys as _sys, os as _os, shutil as _sh
    p = (args.get("path") or "").strip()
    if not p or not _os.path.isfile(p):
        return f"[error] reformat: not a file: {p}"
    ext = _os.path.splitext(p)[1].lower()

    def _run(argv):
        try:
            r = _sp.run(argv, capture_output=True, text=True, timeout=60)
            return r.returncode
        except FileNotFoundError:
            return None
        except Exception:
            return -1

    used = None
    if ext == ".py":
        for mod in ("ruff", "black"):
            argv = [_sys.executable, "-m", mod, "format", p] if mod == "ruff" \
                else [_sys.executable, "-m", mod, "-q", p]
            if _run(argv) == 0:
                used = mod
                break
    elif ext in (".js", ".ts", ".jsx", ".tsx", ".css", ".json", ".md", ".html", ".yaml", ".yml"):
        npx = _sh.which("npx")  # Windows: resolves npx.CMD (the bare-name Popen bug)
        if npx and _run([npx, "--yes", "prettier", "--write", p]) == 0:
            used = "prettier"

    # Universal stdlib fallback — always applied (idempotent, safe).
    try:
        raw = open(p, encoding="utf-8", errors="replace").read()
        norm = "\n".join(ln.rstrip() for ln in raw.split("\n"))
        norm = norm.rstrip("\n") + "\n"
        if norm != raw:
            open(p, "w", encoding="utf-8", newline="\n").write(norm)
            ws = f"; whitespace-normalised ({len(raw)}->{len(norm)} chars)"
        else:
            ws = "; whitespace already clean"
    except Exception as e:
        ws = f"; stdlib-normalise skipped ({type(e).__name__})"
    return f"reformat: {p} — {('formatted via ' + used) if used else 'no external formatter'}{ws}"


def _token_usage_tool(args: dict) -> str:
    """Recent token usage / cost (aibrain usage reporting if present, else
    execution_log cost over the last 24h)."""
    try:
        from aibrain.core import usage_report as _ur
        for fn in ("summary", "recent", "report", "get_usage", "main"):
            f = getattr(_ur, fn, None)
            if callable(f):
                try:
                    return f"token_usage ({fn}):\n{str(f())[:1200]}"
                except Exception:
                    continue
    except ImportError:
        pass
    try:
        import sqlite3, os as _os2
        from aibrain_db import AIBRAIN_ROOT
        c = sqlite3.connect(_os2.path.join(AIBRAIN_ROOT, "aibrain.db"), timeout=10)
        r = c.execute("SELECT COUNT(*), COALESCE(SUM(cost_cents),0) FROM "
                      "execution_log WHERE created_at > datetime('now','-1 day')").fetchone()
        c.close()
        return f"token_usage (execution_log, last 24h): {r[0]} runs, ~${r[1] / 100.0:.2f} est"
    except Exception as e:
        return f"[error] token_usage: no usage source ({type(e).__name__}: {e})"


def _contrast_apca_tool(args: dict) -> str:
    """APCA-W3 0.1.9 perceptual lightness contrast (Lc) between text and
    background colors (hex). Deterministic — the modern WCAG3 contrast
    model. Constants per the public APCA-W3 / SA98G reference."""
    def _hex_rgb(h: str):
        h = h.strip().lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        if len(h) != 6:
            raise ValueError(f"bad hex color: {h!r}")
        return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))

    def _Y(rgb):
        r, g, b = rgb
        Y = 0.2126729 * (r ** 2.4) + 0.7151522 * (g ** 2.4) + 0.0721750 * (b ** 2.4)
        if Y < 0.022:
            Y = Y + (0.022 - Y) ** 1.414
        return Y

    try:
        txt = args.get("text") or args.get("fg")
        bgc = args.get("bg") or args.get("background")
        if not txt or not bgc:
            return "[error] contrast_apca: provide 'text' and 'bg' hex colors."
        Ytxt = _Y(_hex_rgb(txt))
        Ybg = _Y(_hex_rgb(bgc))
        if abs(Ybg - Ytxt) < 0.0005:
            return "contrast_apca: Lc = 0.0 (no contrast)"
        if Ybg > Ytxt:  # normal polarity: darker text on lighter bg
            S = (Ybg ** 0.56 - Ytxt ** 0.57) * 1.14
            Lc = 0.0 if S < 0.1 else (S - 0.027) * 100.0
        else:           # reverse polarity: lighter text on darker bg
            S = (Ybg ** 0.65 - Ytxt ** 0.62) * 1.14
            Lc = 0.0 if S > -0.1 else (S + 0.027) * 100.0
        return (f"contrast_apca: Lc = {Lc:.1f} (APCA-W3 0.1.9; |Lc|>=75 preferred "
                "body text, >=60 acceptable body, >=45 large/non-text)")
    except Exception as e:
        return f"[error] contrast_apca: {type(e).__name__}: {e}"


def _wait_for_tool(args: dict) -> str:
    """Wait until a condition holds or timeout. condition: file_exists |
    port_open | process ; value = the target; timeout secs (default 30)."""
    import time as _t, os as _os
    cond = (args.get("condition") or "").strip()
    val = (args.get("value") or "").strip()
    timeout = float(args.get("timeout", 30))
    interval = float(args.get("interval", 1))
    if not cond or not val:
        return "[error] wait_for: need 'condition' (file_exists|port_open|process) and 'value'."

    def _check():
        if cond == "file_exists":
            return _os.path.exists(val)
        if cond == "process":
            import psutil
            return any(val.lower() in (p.info["name"] or "").lower()
                       for p in psutil.process_iter(["name"]))
        if cond == "port_open":
            import socket
            try:
                h, _, pt = val.partition(":")
                s = socket.create_connection((h or "127.0.0.1", int(pt)), 1)
                s.close()
                return True
            except Exception:
                return False
        return None

    t0 = _t.monotonic()
    while _t.monotonic() - t0 < timeout:
        r = _check()
        if r is None:
            return f"[error] wait_for: unknown condition {cond!r}"
        if r:
            return f"wait_for: '{cond} {val}' met after {_t.monotonic() - t0:.1f}s"
        _t.sleep(interval)
    return f"wait_for: TIMEOUT after {timeout:.0f}s — '{cond} {val}' not met"


def _verify_integrity_tool(args: dict) -> str:
    """Verify a file's SHA-256 matches an 'expected' value."""
    import os as _os, hashlib as _h
    p = (args.get("path") or "").strip()
    exp = (args.get("expected") or "").strip().lower()
    if not p or not _os.path.isfile(p):
        return f"[error] verify_integrity: not a file: {p}"
    if not exp:
        return "[error] verify_integrity: 'expected' sha256 required."
    try:
        hh = _h.sha256()
        with open(p, "rb") as f:
            for b in iter(lambda: f.read(65536), b""):
                hh.update(b)
        got = hh.hexdigest()
        return (f"verify_integrity: MATCH ({got})" if got == exp
                else f"verify_integrity: MISMATCH — expected {exp}, got {got}")
    except Exception as e:
        return f"[error] verify_integrity: {type(e).__name__}: {e}"


def _cache_put_tool(args: dict) -> str:
    """Content-addressed cache: store 'value' (or file at 'path') under its
    sha256 key in ~/.aibrain/cache. Returns the key. Dedup by construction."""
    import os as _os, hashlib as _h
    val = args.get("value")
    path = (args.get("path") or "").strip()
    try:
        if path:
            if not _os.path.isfile(path):
                return f"[error] cache_put: not a file: {path}"
            data = open(path, "rb").read()
        elif val is not None:
            data = str(val).encode("utf-8")
        else:
            return "[error] cache_put: provide 'value' or 'path'."
        key = _h.sha256(data).hexdigest()
        cdir = _os.path.expanduser("~/.aibrain/cache")
        _os.makedirs(cdir, exist_ok=True)
        fp = _os.path.join(cdir, key)
        if not _os.path.exists(fp):
            with open(fp, "wb") as f:
                f.write(data)
            return f"cache_put: stored key={key} ({len(data)} bytes)"
        return f"cache_put: already cached key={key} (dedup hit, {len(data)} bytes)"
    except Exception as e:
        return f"[error] cache_put: {type(e).__name__}: {e}"


def _cache_get_tool(args: dict) -> str:
    """Retrieve a value from the content-addressed cache by sha256 'key'."""
    import os as _os
    key = (args.get("key") or "").strip()
    if not key:
        return "[error] cache_get: 'key' (sha256) required."
    fp = _os.path.join(_os.path.expanduser("~/.aibrain/cache"), key)
    if not _os.path.isfile(fp):
        return f"[error] cache_get: no cached entry for key {key}"
    try:
        data = open(fp, "rb").read()
        try:
            return "cache_get:\n" + data.decode("utf-8")
        except UnicodeDecodeError:
            return f"cache_get: binary entry, {len(data)} bytes at {fp}"
    except Exception as e:
        return f"[error] cache_get: {type(e).__name__}: {e}"


def _batch_run_tool(args: dict) -> str:
    """Batch execution: run a list of steps in order. Each step:
    {"shell": "..."} or {"python": "import ..."}. Stops on first failure
    unless continue_on_error=true. Returns per-step results."""
    import subprocess as _sp
    steps = args.get("steps")
    if not isinstance(steps, list) or not steps:
        return "[error] batch_run: 'steps' must be a non-empty list of {shell|python}."
    coe = bool(args.get("continue_on_error"))
    out = []
    for i, st in enumerate(steps):
        if not isinstance(st, dict):
            out.append(f"step {i}: [skip] not a dict")
            continue
        try:
            if "shell" in st:
                r = _sp.run(st["shell"], shell=True, capture_output=True,
                            text=True, timeout=int(st.get("timeout", 60)))
                ok = r.returncode == 0
                out.append(f"step {i} shell exit={r.returncode}: "
                           f"{(r.stdout or r.stderr)[:300]}")
            elif "python" in st:
                code = st["python"]
                if not code.strip().startswith("import "):
                    out.append(f"step {i} python: [blocked] import-only")
                    ok = False
                else:
                    __import__(code.strip().split()[1].split(".")[0])
                    out.append(f"step {i} python: imported ok")
                    ok = True
            else:
                out.append(f"step {i}: [skip] no shell/python key")
                ok = True
            if not ok and not coe:
                out.append(f"batch_run: stopped at step {i} (failure)")
                break
        except Exception as e:
            out.append(f"step {i}: [error] {type(e).__name__}: {e}")
            if not coe:
                out.append(f"batch_run: stopped at step {i} (exception)")
                break
    return "batch_run results:\n" + "\n".join(out)


def _summarize_tool(args: dict) -> str:
    """Summarize text ('text') or a file ('path') via the active provider.
    Optional 'length': short (default) / medium / long. Provider-agnostic."""
    import os as _os
    text = args.get("text")
    path = (args.get("path") or "").strip()
    if path:
        if not _os.path.isfile(path):
            return f"[error] summarize: not a file: {path}"
        text = open(path, encoding="utf-8", errors="replace").read()
    text = (text or "").strip()
    if not text:
        return "[error] summarize: provide 'text' or 'path'."
    length = (args.get("length") or "short").strip().lower()
    _g = {"short": "in 2-3 sentences",
          "medium": "in one tight paragraph",
          "long": "as a structured set of bullets covering all key points"}
    guide = _g.get(length, _g["short"])
    try:
        det = _detect_provider()
        if not det:
            return "[error] summarize: no provider configured."
        provider, model, key = det
        if provider == "claude_cli":
            if _os.environ.get("DEEPSEEK_API_KEY"):
                provider, model, key = "deepseek", "deepseek-v4-pro", _os.environ["DEEPSEEK_API_KEY"]
            elif _os.environ.get("OPENAI_API_KEY"):
                provider, model, key = "openai", "gpt-4o", _os.environ["OPENAI_API_KEY"]
            else:
                return "[error] summarize: active provider claude_cli; set DEEPSEEK_API_KEY or OPENAI_API_KEY."
        import openai as _openai
        base = "https://api.deepseek.com" if provider == "deepseek" else None
        client = _openai.OpenAI(api_key=key, base_url=base)
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "system",
                       "content": f"Summarize the user's content {guide}. "
                                  "Preserve key facts. Output ONLY the summary."},
                      {"role": "user", "content": text[:60000]}],
            temperature=0.2, stream=False)
        out = (resp.choices[0].message.content or "").strip()
        return out or "[error] summarize: empty response."
    except Exception as e:
        return f"[error] summarize: {type(e).__name__}: {e}"


def _describe_clipboard_image_tool(args: dict) -> str:
    """Capture an image from the clipboard and describe it via vision
    (composes the existing _analyze_image_tool). Graceful if no image."""
    if _lucy_privacy_on():
        return _PRIVACY_BLOCK
    import tempfile, os as _os
    try:
        from PIL import ImageGrab
        img = ImageGrab.grabclipboard()
        if img is None or isinstance(img, list):
            return "[error] describe_clipboard_image: no image on clipboard (copy an image first)."
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            img.save(f, "PNG")
            p = f.name
    except ImportError:
        return ("[error] describe_clipboard_image: Pillow not installed "
                "(pip install Pillow). Tool is wired; works once Pillow present.")
    except Exception as e:
        return f"[error] describe_clipboard_image: clipboard grab failed: {type(e).__name__}: {e}"
    q = args.get("question") or "Describe this image for an accessibility user."
    out = _analyze_image_tool({"path": p, "question": q})
    try:
        _os.unlink(p)
    except Exception:
        pass
    return out


def _higgsfield_generate_tool(args: dict) -> str:
    """F-LUCY-HIGGSFIELD-AUTOMATION-1: invoke the Playwright wrapper at
    decker_system/04_tools/higgsfield_playwright.py to generate an image
    or video via Decker's pro-sub session.

    Subprocesses the existing wrapper rather than importing it (the
    wrapper is a standalone script with its own argparse + persistent
    Playwright context). Writes the prompt to a temp file because the
    wrapper expects --prompt-file not --prompt-inline.
    """
    prompt = (args.get("prompt") or "").strip()
    out_path = (args.get("out_path") or "").strip()
    model = (args.get("model") or "seedance_2_0").strip()
    headed = bool(args.get("headed", False))
    if not prompt:
        return "[error] higgsfield_generate: 'prompt' is required"
    if not out_path:
        return "[error] higgsfield_generate: 'out_path' is required"

    import subprocess as _sp
    import tempfile as _tf

    wrapper = Path(r"C:\Users\sinde\decker_system\04_tools\higgsfield_playwright.py")
    if not wrapper.exists():
        return (f"[error] higgsfield_generate: wrapper missing at {wrapper}. "
                f"Ensure decker_system is checked out.")

    # Write the prompt to a temp file
    tf = _tf.NamedTemporaryFile(
        mode="w", suffix=".md", delete=False, encoding="utf-8",
    )
    try:
        tf.write(prompt)
        tf.close()
        cmd = [
            sys.executable, str(wrapper),
            "--prompt-file", tf.name,
            "--out", out_path,
            "--model", model,
        ]
        if headed:
            cmd.append("--headed")
        _log_tool(f"higgsfield_generate: running wrapper (model={model}, "
                  f"headed={headed}, out={out_path})", level=1)
        proc = _sp.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=600,  # 10-min ceiling for slow video runs
        )
    except _sp.TimeoutExpired:
        return ("[error] higgsfield_generate: wrapper timed out after 600s. "
                "Try a shorter prompt or smaller model.")
    except Exception as e:
        return f"[error] higgsfield_generate: subprocess failed: {type(e).__name__}: {e}"
    finally:
        try:
            os.unlink(tf.name)
        except Exception:
            pass

    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "")[:500]
        return (f"[error] higgsfield_generate: wrapper exit={proc.returncode}. "
                f"stderr: {err}. If this is the first run, pass headed=True so "
                f"the browser window opens for Google OAuth.")

    if Path(out_path).exists():
        sz = Path(out_path).stat().st_size
        return f"higgsfield_generate: wrote {out_path} ({sz} bytes, model={model})"
    return (f"[error] higgsfield_generate: wrapper exit=0 but output file "
            f"missing at {out_path}. stdout tail: {(proc.stdout or '')[-300:]}")


def _speak_tool(args: dict) -> str:
    """Text-to-speech. pyttsx3 first, then Windows SAPI (System.Speech,
    zero-dep). Graceful if no backend. Audible output is environment-dependent."""
    text = (args.get("text") or "").strip()
    if not text:
        return "[error] speak: 'text' required."
    try:
        import pyttsx3 as _p
        e = _p.init()
        e.say(text)
        e.runAndWait()
        e.stop()
        return f"speak: synthesized {len(text)} chars via pyttsx3."
    except ImportError:
        pass
    except Exception as e:
        return f"[error] speak: pyttsx3 failed: {type(e).__name__}: {e}"
    try:
        import subprocess as _sp
        if sys.platform == "win32":
            safe = text.replace("'", "''")
            _sp.run(["powershell", "-NoProfile", "-Command",
                     "Add-Type -AssemblyName System.Speech; "
                     "(New-Object System.Speech.Synthesis.SpeechSynthesizer)"
                     f".Speak('{safe}')"], timeout=60, check=True)
            return f"speak: synthesized {len(text)} chars via Windows SAPI."
        return "[error] speak: no TTS backend (pip install pyttsx3)."
    except Exception as e:
        return f"[error] speak: SAPI failed: {type(e).__name__}: {e}"


_KNOWN_PROVIDERS = ("deepseek", "claude_cli", "openai_sub", "openai", "anthropic")


def _provider_status_tool(args: dict) -> str:
    """Show the active provider/model and what the resolver currently returns."""
    import json as _json
    try:
        cfg = _json.loads(CONFIG_FILE.read_text(encoding="utf-8")) if CONFIG_FILE.exists() else {}
    except Exception as e:
        return f"[error] provider_status: {type(e).__name__}: {e}"
    try:
        det = _detect_provider()
        det = det[:2] if isinstance(det, tuple) and len(det) >= 2 else det
    except Exception as e:
        det = f"<resolver error: {e}>"
    return ("provider_status:\n"
            f"  config default_provider = {cfg.get('default_provider')!r}\n"
            f"  config default_model    = {cfg.get('default_model')!r}\n"
            f"  resolver returns        = {det}\n"
            f"  known providers         = {list(_KNOWN_PROVIDERS)}")


def _set_provider_tool(args: dict) -> str:
    """Set default_provider in Lucy's config (validates + backs up first)."""
    import json as _json, shutil as _sh, datetime as _dt, os as _os
    p = (args.get("provider") or "").strip()
    if p not in _KNOWN_PROVIDERS:
        return f"[error] set_provider: '{p}' not in {_KNOWN_PROVIDERS}"
    try:
        cfg = _json.loads(CONFIG_FILE.read_text(encoding="utf-8")) if CONFIG_FILE.exists() else {}
        if CONFIG_FILE.exists():
            bdir = os.environ.get("AIBRAIN_CONFIG_BACKUP_DIR", str(Path.home() / ".aibrain" / "config_backup"))
            _os.makedirs(bdir, exist_ok=True)
            _sh.copy2(str(CONFIG_FILE), _os.path.join(
                bdir, f"config.json.set_provider.{_dt.datetime.now():%Y%m%d_%H%M%S}"))
        old = cfg.get("default_provider")
        cfg["default_provider"] = p
        CONFIG_FILE.write_text(_json.dumps(cfg, indent=2), encoding="utf-8")
        return (f"set_provider: default_provider {old!r} -> {p!r} "
                "(config backed up; takes effect next chat turn via re-sync)")
    except Exception as e:
        return f"[error] set_provider: {type(e).__name__}: {e}"


def _set_model_tool(args: dict) -> str:
    """Set default_model in Lucy's config (backs up first)."""
    import json as _json, shutil as _sh, datetime as _dt, os as _os
    m = (args.get("model") or "").strip()
    if not m:
        return "[error] set_model: 'model' required."
    try:
        cfg = _json.loads(CONFIG_FILE.read_text(encoding="utf-8")) if CONFIG_FILE.exists() else {}
        if CONFIG_FILE.exists():
            bdir = os.environ.get("AIBRAIN_CONFIG_BACKUP_DIR", str(Path.home() / ".aibrain" / "config_backup"))
            _os.makedirs(bdir, exist_ok=True)
            _sh.copy2(str(CONFIG_FILE), _os.path.join(
                bdir, f"config.json.set_model.{_dt.datetime.now():%Y%m%d_%H%M%S}"))
        old = cfg.get("default_model")
        cfg["default_model"] = m
        CONFIG_FILE.write_text(_json.dumps(cfg, indent=2), encoding="utf-8")
        return f"set_model: default_model {old!r} -> {m!r} (config backed up)"
    except Exception as e:
        return f"[error] set_model: {type(e).__name__}: {e}"


def _help_tool(args: dict) -> str:
    """Multi-format help: list Lucy's tools + usage. Optional 'filter'
    (substring) to narrow; optional 'name' for one tool's full schema."""
    import json as _json
    name = (args.get("name") or "").strip()
    flt = (args.get("filter") or "").strip().lower()
    tools = [t for t in _LUCY_TOOLS if t.get("type") == "function"]
    if name:
        for t in tools:
            fn = t["function"]
            if fn["name"] == name:
                return f"{fn['name']}: {fn.get('description','')}\nparameters:\n" + \
                       _json.dumps(fn.get("parameters", {}), indent=2)
        return f"[error] help: no tool named '{name}'. Use help with no args to list all."
    lines = [f"Lucy has {len(tools)} tools:"]
    for t in tools:
        fn = t["function"]
        d = fn.get("description", "")
        if flt and flt not in (fn["name"] + " " + d).lower():
            continue
        lines.append(f"  - {fn['name']}: {d[:100]}")
    if flt and len(lines) == 1:
        return f"help: no tools matching '{flt}'."
    return "\n".join(lines)


def _settings_get_tool(args: dict) -> str:
    """Read a key from Lucy's config (~/.aibrain/config.json). No key = dump all."""
    import json as _json
    try:
        cfg = _json.loads(CONFIG_FILE.read_text(encoding="utf-8")) if CONFIG_FILE.exists() else {}
    except Exception as e:
        return f"[error] settings_get: cannot read config: {type(e).__name__}: {e}"
    key = (args.get("key") or "").strip()
    if not key:
        return "config:\n" + _json.dumps(cfg, indent=2)
    if key not in cfg:
        return f"[error] settings_get: key '{key}' not set. Keys: {list(cfg)}"
    return f"{key} = {_json.dumps(cfg[key])}"


def _settings_set_tool(args: dict) -> str:
    """Set a key in Lucy's config (~/.aibrain/config.json). Backs up first."""
    import json as _json, shutil as _sh, datetime as _dt, os as _os
    key = (args.get("key") or "").strip()
    if not key:
        return "[error] settings_set: 'key' required."
    if "value" not in args:
        return "[error] settings_set: 'value' required."
    try:
        cfg = _json.loads(CONFIG_FILE.read_text(encoding="utf-8")) if CONFIG_FILE.exists() else {}
        if CONFIG_FILE.exists():
            bdir = os.environ.get("AIBRAIN_CONFIG_BACKUP_DIR", str(Path.home() / ".aibrain" / "config_backup"))
            _os.makedirs(bdir, exist_ok=True)
            _sh.copy2(str(CONFIG_FILE), _os.path.join(
                bdir, f"config.json.settings_set.{_dt.datetime.now():%Y%m%d_%H%M%S}"))
        old = cfg.get(key, "<unset>")
        cfg[key] = args["value"]
        CONFIG_FILE.write_text(_json.dumps(cfg, indent=2), encoding="utf-8")
        return f"settings_set: {key}: {old!r} -> {args['value']!r} (config backed up)"
    except Exception as e:
        return f"[error] settings_set: {type(e).__name__}: {e}"


def _clipboard_tool(args: dict) -> str:
    """Read/write the system clipboard. action: 'read' (default) or 'write'
    (+ 'text'). pyperclip if present, else Windows PowerShell clipboard."""
    action = (args.get("action") or "read").strip().lower()
    text = args.get("text")
    try:
        try:
            import pyperclip as _pc
            if action == "write":
                if text is None:
                    return "[error] clipboard: 'text' required for write."
                _pc.copy(str(text))
                return f"clipboard: wrote {len(str(text))} chars."
            return "clipboard contents:\n" + (_pc.paste() or "")
        except ImportError:
            pass
        import subprocess as _sp
        if sys.platform == "win32":
            if action == "write":
                if text is None:
                    return "[error] clipboard: 'text' required for write."
                _sp.run(["powershell", "-NoProfile", "-Command",
                         "$input | Set-Clipboard"], input=str(text), text=True,
                        timeout=10, check=True)
                return f"clipboard: wrote {len(str(text))} chars."
            r = _sp.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
                        capture_output=True, text=True, timeout=10)
            return "clipboard contents:\n" + (r.stdout or "")
        return "[error] clipboard: no backend (pip install pyperclip)."
    except Exception as e:
        return f"[error] clipboard: {type(e).__name__}: {e}"


def _read_clipboard_tool(args: dict) -> str:
    return _clipboard_tool({"action": "read"})


def _write_clipboard_tool(args: dict) -> str:
    t = args.get("text")
    if t is None:
        return "[error] write_clipboard: 'text' required."
    return _clipboard_tool({"action": "write", "text": t})


def _notebook_edit_tool(args: dict) -> str:
    import json as _j
    import os as _o
    p = _o.path.expanduser(args.get("path", "") or "")
    src = args.get("source")
    mode = (args.get("mode") or "replace").strip().lower()
    ci = args.get("cell_index")
    if not p or not _o.path.isfile(p):
        return f"[error] notebook_edit: file not found: {p}"
    if src is None:
        return "[error] notebook_edit: 'source' required."
    try:
        nb = _j.load(open(p, encoding="utf-8"))
        cells = nb.setdefault("cells", [])
        lines = [ln + "\n" for ln in str(src).split("\n")]
        if mode == "append":
            cells.append({"cell_type": "code", "metadata": {}, "source": lines, "outputs": [], "execution_count": None})
            where = "appended new cell"
        else:
            if ci is None or not (0 <= int(ci) < len(cells)):
                return f"[error] notebook_edit: cell_index out of range (0..{len(cells) - 1})"
            cells[int(ci)]["source"] = lines
            where = f"replaced cell {ci}"
        _j.dump(nb, open(p, "w", encoding="utf-8"), indent=1)
        return f"notebook_edit: {where} in {p} ({len(cells)} cells)"
    except Exception as e:
        return f"[error] notebook_edit: {e}"


def _file_hash_tool(args: dict) -> str:
    """SHA-256 of a file ('path') or text ('text') — for hash-based dedup."""
    import os as _os, hashlib as _h
    path = args.get("path")
    text = args.get("text")
    try:
        if path:
            if not _os.path.isfile(path):
                return f"[error] file_hash: not a file: {path}"
            h = _h.sha256()
            with open(path, "rb") as f:
                for blk in iter(lambda: f.read(65536), b""):
                    h.update(blk)
            return f"sha256({path}) = {h.hexdigest()}"
        if text is not None:
            return f"sha256(text) = {_h.sha256(str(text).encode('utf-8')).hexdigest()}"
        return "[error] file_hash: provide 'path' or 'text'."
    except Exception as e:
        return f"[error] file_hash: {type(e).__name__}: {e}"


def _json_query_tool(args: dict) -> str:
    """Extract a dotted path from a JSON file. path=<json file>, query=<a.b.0.c>."""
    import os as _os, json as _json
    fp = (args.get("path") or "").strip()
    q = (args.get("query") or "").strip()
    if not fp or not _os.path.isfile(fp):
        return f"[error] json_query: not a file: {fp}"
    try:
        cur = _json.load(open(fp, encoding="utf-8"))
        if q:
            for part in q.split("."):
                if isinstance(cur, list):
                    cur = cur[int(part)]
                elif isinstance(cur, dict):
                    cur = cur[part]
                else:
                    return f"[error] json_query: cannot descend into {type(cur).__name__} at '{part}'"
        return _json.dumps(cur, indent=2, ensure_ascii=False)[:4000]
    except (KeyError, IndexError, ValueError) as e:
        return f"[error] json_query: path '{q}' not found ({type(e).__name__}: {e})"
    except Exception as e:
        return f"[error] json_query: {type(e).__name__}: {e}"


def _list_files_tool(args: dict) -> str:
    """List files in a directory (optional glob pattern / recursive)."""
    import os as _os, glob as _glob
    path = (args.get("path") or ".").strip()
    pattern = (args.get("pattern") or "").strip()
    recursive = bool(args.get("recursive"))
    if not _os.path.isdir(path):
        return f"[error] list_files: not a directory: {path}"
    try:
        if pattern:
            pat = _os.path.join(path, "**", pattern) if recursive else _os.path.join(path, pattern)
            hits = sorted(_glob.glob(pat, recursive=recursive))
        elif recursive:
            hits = sorted(_os.path.join(r, f) for r, _d, fs in _os.walk(path) for f in fs)
        else:
            hits = sorted(_os.path.join(path, e) for e in _os.listdir(path))
        hits = hits[:500]
        return (f"{len(hits)} entries in {path}"
                + (f" matching {pattern}" if pattern else "")
                + ((":\n" + "\n".join(hits)) if hits else ""))
    except Exception as e:
        return f"[error] list_files: {type(e).__name__}: {e}"


def _diff_view_tool(args: dict) -> str:
    """Unified diff: path_a+path_b OR text_a+text_b."""
    import os as _os, difflib as _dl
    pa, pb = args.get("path_a"), args.get("path_b")
    ta, tb = args.get("text_a"), args.get("text_b")
    try:
        if pa and pb:
            if not _os.path.isfile(pa):
                return f"[error] diff_view: not a file: {pa}"
            if not _os.path.isfile(pb):
                return f"[error] diff_view: not a file: {pb}"
            a = open(pa, encoding="utf-8", errors="replace").read().splitlines(keepends=True)
            b = open(pb, encoding="utf-8", errors="replace").read().splitlines(keepends=True)
            na, nb = pa, pb
        elif ta is not None and tb is not None:
            a = str(ta).splitlines(keepends=True)
            b = str(tb).splitlines(keepends=True)
            na, nb = "text_a", "text_b"
        else:
            return "[error] diff_view: provide path_a+path_b OR text_a+text_b."
        d = list(_dl.unified_diff(a, b, fromfile=na, tofile=nb, lineterm=""))
        return "diff_view: no differences." if not d else "\n".join(d[:800])
    except Exception as e:
        return f"[error] diff_view: {type(e).__name__}: {e}"


def _read_lines_tool(args: dict) -> str:
    """Read a 1-based inclusive line range of a file: path, start, end."""
    import os as _os
    path = (args.get("path") or "").strip()
    if not path or not _os.path.isfile(path):
        return f"[error] read_lines: not a file: {path}"
    try:
        start = max(1, int(args.get("start", 1)))
        end = int(args.get("end", start + 49))
        lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
        if start > len(lines):
            return f"[error] read_lines: start {start} > file length {len(lines)}"
        end = min(end, len(lines))
        return (f"{path} lines {start}-{end} of {len(lines)}:\n"
                + "\n".join(f"{i}: {lines[i - 1]}" for i in range(start, end + 1)))
    except Exception as e:
        return f"[error] read_lines: {type(e).__name__}: {e}"


def _cognitive_accessibility_tool(args: dict) -> str:
    """WS-T2 accessibility: rewrite text to be cognitively accessible for
    ADHD / dyslexia / autism / plain-language readers. Provider-agnostic via
    _detect_provider (honours the configured provider). Degrades gracefully —
    never crashes the agent."""
    text = (args.get("text") or "").strip()
    if not text:
        return "[error] cognitive_accessibility: 'text' is required."
    profile = (args.get("profile") or "plain").strip().lower()
    _guides = {
        "plain": "Use plain language: short sentences, common words, active voice, no jargon.",
        "dyslexia": "Dyslexia-friendly: very short sentences, simple common words, one idea per line, no dense blocks.",
        "adhd": "ADHD-friendly: lead with the key point, short bullets, minimal preamble, bold the essential action.",
        "autism": "Autism-friendly: literal and explicit, no idioms/metaphor/sarcasm, concrete numbered steps, predictable structure.",
    }
    guide = _guides.get(profile, _guides["plain"])
    try:
        det = _detect_provider()
        if not det:
            return "[error] cognitive_accessibility: no provider configured."
        provider, model, key = det
        if provider == "claude_cli":
            import os as _os
            if _os.environ.get("DEEPSEEK_API_KEY"):
                provider, model, key = "deepseek", "deepseek-v4-pro", _os.environ["DEEPSEEK_API_KEY"]
            elif _os.environ.get("OPENAI_API_KEY"):
                provider, model, key = "openai", "gpt-4o", _os.environ["OPENAI_API_KEY"]
            else:
                return ("[error] cognitive_accessibility: active provider is "
                        "claude_cli; set DEEPSEEK_API_KEY or OPENAI_API_KEY.")
        import openai as _openai
        base = "https://api.deepseek.com" if provider == "deepseek" else None
        client = _openai.OpenAI(api_key=key, base_url=base)
        sys_p = ("You rewrite text to be cognitively accessible. " + guide +
                 " Preserve all factual content and meaning. Output ONLY the "
                 "rewritten text — no preamble, no commentary.")
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "system", "content": sys_p},
                      {"role": "user", "content": text}],
            temperature=0.2,
            stream=False,
        )
        out = (resp.choices[0].message.content or "").strip()
        return out or "[error] cognitive_accessibility: empty response."
    except Exception as e:
        return f"[error] cognitive_accessibility: {type(e).__name__}: {e}"


def _describe_screen_tool(args: dict) -> str:
    """WS-T2 accessibility: screenshot -> analyze_image (shipped) -> TTS
    (Kokoro offline first, OpenAI fallback). Always returns the description
    text even if TTS fails (degrade, never crash)."""
    if _lucy_privacy_on():
        return _PRIVACY_BLOCK
    import tempfile, asyncio
    try:
        import pyautogui
        img = pyautogui.screenshot()
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            img.save(f, format='PNG')
            screenshot_path = f.name
    except Exception as e:
        return f"[error] describe_screen: screenshot failed: {e}"

    question = args.get("question") or (
        "Describe what is on this screen for a blind user: layout, key text, controls, state."
    )
    analysis = _analyze_image_tool({"path": screenshot_path, "question": question})
    if isinstance(analysis, str) and analysis.startswith("[error]"):
        return analysis

    audio_note = ""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            from aibrain.core.provider_speech import KokoroLocalProvider
            res = loop.run_until_complete(KokoroLocalProvider().invoke({"text": analysis}))
            url = (res or {}).get("audio_url") or (res or {}).get("url")
            audio_note = f"\nAudio: {url}" if url else "\n(TTS ok, no audio url)"
        except Exception:
            try:
                from aibrain.core.provider_openai import OpenAITTSProvider
                res = loop.run_until_complete(OpenAITTSProvider().invoke({"text": analysis}))
                url = (res or {}).get("audio_url") or (res or {}).get("url")
                audio_note = f"\nAudio: {url}" if url else "\n(TTS ok, no audio url)"
            except Exception as e:
                audio_note = f"\n(TTS unavailable: {e})"
        finally:
            loop.close()
    except Exception as e:
        audio_note = f"\n(TTS unavailable: {e})"

    return f"{analysis}{audio_note}"

def _click_tool(args: dict) -> str:
    try:
        import pyautogui
        pyautogui.click(args['x'], args['y'], button=args.get('button', 'left'))
        return f"[click] {args['x']},{args['y']}"
    except Exception as e:
        return f"[error] click: {e}"

def _type_text_tool(args: dict) -> str:
    try:
        import pyautogui
        pyautogui.typewrite(args['text'], interval=args.get('interval', 0.05))
        return f"[type_text] {len(args['text'])} chars"
    except Exception as e:
        return f"[error] type_text: {e}"

def _hotkey_tool(args: dict) -> str:
    try:
        import pyautogui
        pyautogui.hotkey(*args['keys'])
        return f"[hotkey] {'+'.join(args['keys'])}"
    except Exception as e:
        return f"[error] hotkey: {e}"

def _scroll_tool(args: dict) -> str:
    try:
        import pyautogui
        pyautogui.scroll(args['clicks'])
        return f"[scroll] {args['clicks']}"
    except Exception as e:
        return f"[error] scroll: {e}"

def _move_mouse_tool(args: dict) -> str:
    try:
        import pyautogui
        pyautogui.moveTo(args['x'], args['y'])
        return f"[move_mouse] {args['x']},{args['y']}"
    except Exception as e:
        return f"[error] move_mouse: {e}"

def _schedule_wakeup_tool(args: dict) -> str:
    try:
        delay = int(args.get("delay_seconds", 60))
        prompt = args.get("prompt", "Wakeup: check for pending work.")
        import threading, time as _t
        def _wake():
            _t.sleep(delay)
        t = threading.Thread(target=_wake, daemon=True)
        t.start()
        return f"[wakeup scheduled] in {delay}s"
    except Exception as e:
        return f"[error] schedule_wakeup: {e}"


def _create_task_tool(args: dict) -> str:
    """LLM-callable create_task. F-LUCY-FILES-COMPANY-TASKS-1."""
    if not COMPANY_AVAILABLE:
        return "[error] Company system not available"
    try:
        task = _create_task(
            COMPANY_ID,
            title=args["title"],
            description=args.get("description", ""),
            priority=args.get("priority", "medium"),
            assignee_agent_id=LUCY_AGENT_ID,
        )
        _checkout_task(task["id"], LUCY_AGENT_ID)
        return f"[task created] {task['id']} — {args['title']}"
    except Exception as e:
        return f"[error] create_task: {e}"


def _complete_task_tool(args: dict) -> str:
    """LLM-callable complete_task. F-LUCY-FILES-COMPANY-TASKS-1."""
    if not COMPANY_AVAILABLE:
        return "[error] Company system not available"
    try:
        _checkout_task(args["task_id"], LUCY_AGENT_ID)
        result = _complete_task(args["task_id"], work_output=args["work_output"])
        return f"[task {result.get('status', '?')}] {args['task_id']}"
    except Exception as e:
        return f"[error] complete_task: {e}"


def _dispatch_deepseek_tool(args: dict) -> str:
    """LLM-callable dispatch_deepseek_task. F-LUCY-DISPATCH-TOOL-1.

    When Lucy is running on Claude (expensive per-token) and the user asks for
    code authoring or analysis, route the heavy generation work to DeepSeek
    under the gate flow. Lucy stays on Claude for orchestration; DeepSeek does
    the lifting. Auto checkout + auto complete via dispatch_deepseek_task's
    internal lifecycle.
    """
    if not COMPANY_AVAILABLE:
        return "[error] Company system not available"
    try:
        from aibrain.core.agent_dispatch import dispatch_deepseek_task as _dispatch
    except Exception as e:
        return f"[error] dispatch import failed: {e}"
    try:
        result = _dispatch(
            task_id=args["task_id"],
            task_prompt=args["task_prompt"],
            agent_id=args.get("agent_id", "CDTYrHYkyH8"),
            plan_summary=args.get("plan_summary", "Lucy-routed dispatch"),
            model=args.get("model", "deepseek-v4-pro"),
            thinking=bool(args.get("thinking", False)),
            task_type=args.get("task_type", "complex"),
            company_id=args.get("company_id", "GT_LRWrEBQQ"),
        )
        if not isinstance(result, dict):
            return f"[dispatch] returned non-dict: {result!r:.200s}"
        wo = (result.get("work_output") or "").strip()
        cost = result.get("cost_usd") or 0
        return f"[dispatch ok] cost=${cost:.4f} units_in={result.get('units_in')} units_out={result.get('units_out')}\n{wo[:1200]}"
    except Exception as e:
        return f"[error] dispatch_deepseek_task: {e}"




def _fleet_reply_tool(args: dict) -> str:
    """F-LUCY-FLEETBUS-REPLY-1: publish a reply to a FleetBus topic.
    
    Lets Lucy reply to any fleet-inbound message via FleetBus.publish 
    rather than Telegram or stdout. Neuro/Deep/Case can pick it up.
    """
    reply_topic = args.get("reply_topic", "")
    content_text = args.get("content", "")
    in_reply_to = args.get("in_reply_to_id", "")
    if not reply_topic:
        return "[error] fleet_reply: reply_topic is required"
    if not content_text:
        return "[error] fleet_reply: content is required"
    try:
        from aibrain.core.agent_comms import FleetBus
        _bus = FleetBus(agent_id=LUCY_FLEET_ID, db_path=DB_PATH)
        _bus.publish(reply_topic, {
            "msg": content_text,
            "reply_to": in_reply_to,
            "from": LUCY_FLEET_ID,
        })
        return f"[fleet_reply] published to {reply_topic}"
    except Exception as e:
        return f"[error] fleet_reply: {e}"

# F-LUCY-DISPATCH-PRIMITIVES-1: handler functions for deepseek_chat, apply_dispatch_blocks, verify_file_state

def _deepseek_chat_tool(args: dict) -> str:
    """Call DeepSeek API directly with no task lifecycle. F-LUCY-DISPATCH-PRIMITIVES-1."""
    try:
        from aibrain.core.dispatch_primitives import deepseek_chat
        result = deepseek_chat(
            system_prompt=args.get("system_prompt", ""),
            user_prompt=args.get("user_prompt", ""),
            model=args.get("model", "deepseek-v4-pro"),
            thinking=bool(args.get("thinking", False)),
            reasoning_effort=args.get("reasoning_effort", "high"),
            timeout_s=int(args.get("timeout_s", 180)),
        )
        if result.get("error"):
            return f"[deepseek_chat error] {result['error']}"
        cost = result.get("cost_usd", 0)
        tokens_in = result.get("tokens_in", 0)
        tokens_out = result.get("tokens_out", 0)
        content = result.get("content", "")
        return f"[deepseek_chat] cost=${cost:.4f} in={tokens_in} out={tokens_out}\n{content[:3000]}"
    except Exception as e:
        return f"[error] deepseek_chat: {e}"

def _apply_dispatch_blocks_tool(args: dict) -> str:
    """Apply FILE/EDIT/diff blocks to disk without task lifecycle. F-LUCY-DISPATCH-PRIMITIVES-1."""
    try:
        from aibrain.core.dispatch_primitives import apply_dispatch_blocks
        result = apply_dispatch_blocks(
            text=args.get("text", ""),
            target_dir=args.get("target_dir"),
        )
        applied = result.get("applied_files", [])
        errors = result.get("errors")
        rejected = result.get("deny_rejected", [])
        blocks = result.get("blocks_found", 0)
        parts = [f"blocks_found={blocks}", f"applied={len(applied)}"]
        if applied:
            parts.append(f"files={applied}")
        if rejected:
            parts.append(f"deny_rejected={[r['filepath'] for r in rejected]}")
        if errors:
            parts.append(f"errors={errors}")
        if not result.get("applied") and errors:
            return f"[apply_dispatch_blocks FAILED] {'; '.join(parts)}"
        return f"[apply_dispatch_blocks OK] {'; '.join(parts)}"
    except Exception as e:
        return f"[error] apply_dispatch_blocks: {e}"

def _verify_file_state_tool(args: dict) -> str:
    """Run verification checks against files. F-LUCY-DISPATCH-PRIMITIVES-1."""
    try:
        from aibrain.core.dispatch_primitives import verify_file_state
        lines = args.get("verify_lines", [])
        if isinstance(lines, str):
            import json
            lines = json.loads(lines)
        result = verify_file_state(
            verify_lines=lines,
            cwd=args.get("cwd"),
        )
        passed = result.get("passed_count", 0)
        failed = result.get("failed_count", 0)
        total = result.get("total_count", 0)
        if not result.get("verified"):
            details = []
            for c in result.get("checks", []):
                if not c.get("passed"):
                    details.append(f"  FAIL: {c['line'][:80]} - {c.get('error','')[:100]}")
            return f"[verify_file_state FAILED] {passed}/{total} passed, {failed} failed\n" + "\n".join(details[:10])
        return f"[verify_file_state OK] {passed}/{total} checks passed"
    except Exception as e:
        return f"[error] verify_file_state: {e}"

def _strip_dsml_markup(text: str) -> str:
    """Strip DSML pseudo-XML tool-call markup from user-visible text.

    DeepSeek sometimes emits tool calls as DSML text (e.g.
    ``<｜｜DSML｜｜tool_calls>...``) instead of using the
    native OpenAI tool_calls field. The DSML parser handles execution; this
    strips the raw markup so the user sees clean prose, not pseudo-XML.
    """
    import re as _re
    if not isinstance(text, str) or not text:
        return text
    out = text
    out = _re.sub(r'<[│｜|]*DSML[│｜|]*[^>]*>.*?</[│｜|]*DSML[│｜|]*[^>]*>', '', out, flags=_re.DOTALL)
    out = _re.sub(r'<[│｜|]*DSML[│｜|]*[^>]*>', '', out)
    out = _re.sub(r'</[│｜|]*DSML[│｜|]*[^>]*>', '', out)
    out = _re.sub(r'<invoke[^>]*>.*?</invoke>', '', out, flags=_re.DOTALL)
    out = _re.sub(r'<parameter[^>]*>.*?</parameter>', '', out, flags=_re.DOTALL)
    out = _re.sub(r'<tool_calls>.*?</tool_calls>', '', out, flags=_re.DOTALL)
    return _re.sub(r'\n{3,}', '\n\n', out).strip()


def _parse_dsml_tool_calls(text: str):
    """F-DSML-PARSER-DROPOUT-FIX-1: parse DSML tool calls from DeepSeek.

    Handles BOTH the plain `<invoke name="...">...</invoke>` form AND the
    fullwidth-pipe-prefixed form DeepSeek actually emits, e.g.
    ``<｜｜DSML｜｜invoke name="Read">``. The character class
    `[│｜|]` matches box-drawing pipe (U+2502), fullwidth pipe (U+FF5C),
    and ASCII pipe.

    Parameter values are read from element-body content (the prior version
    only scanned attribute key="value" pairs, which never sees the actual
    value text between the opening and closing parameter tags).

    Returns a list of {"name": str, "args": dict} - one entry per <invoke>
    found. Multiple invokes per emission are supported. Returns [] when no
    DSML invoke markers are present.
    """
    import re as _re
    if not isinstance(text, str) or not text:
        return []
    # Character class for the optional DSML-pipe prefix chars (box-pipe,
    # fullwidth-pipe, ASCII pipe). Kept as escapes so the source stays ASCII.
    _invoke_pat = (
        r'<[│｜|]*(?:DSML[│｜|]*)?invoke\s+name="([^"]+)"\s*>'
        r'(.*?)'
        r'</[│｜|]*(?:DSML[│｜|]*)?invoke>'
    )
    _param_pat = (
        r'<[│｜|]*(?:DSML[│｜|]*)?parameter\s+name="([^"]+)"(?:\s+[^>]*)?\s*>'
        r'(.*?)'
        r'</[│｜|]*(?:DSML[│｜|]*)?parameter>'
    )
    invokes = []
    for m in _re.finditer(_invoke_pat, text, flags=_re.DOTALL):
        name = m.group(1)
        body = m.group(2) or ""
        args = {}
        for pm in _re.finditer(_param_pat, body, flags=_re.DOTALL):
            args[pm.group(1)] = pm.group(2).strip()
        invokes.append({"name": name, "args": args})
    return invokes


def _load_hooks() -> dict:
    """F-LUCY-HOOKS-SYSTEM-1."""
    if not HOOKS_FILE.exists():
        HOOKS_FILE.parent.mkdir(parents=True, exist_ok=True)
        defaults = {"version": 1, "hooks": {"SessionStart": [], "UserPromptSubmit": [], "PreToolUse": [], "PostToolUse": []}}
        HOOKS_FILE.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
        return defaults
    try:
        with open(HOOKS_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"hooks": {}}


def _run_hooks(event: str, context: dict = None) -> str:
    """F-LUCY-HOOKS-SYSTEM-1."""
    import subprocess as _sp
    config = _load_hooks()
    hooks = config.get("hooks", {}).get(event, [])
    if not hooks:
        return ""
    output = []
    ctx_json = json.dumps(context or {})
    for h in hooks:
        cmd = h.get("command", "")
        matcher = h.get("matcher", "")
        if matcher and context:
            if matcher not in context.get("tool_name", ""):
                continue
        if not cmd:
            continue
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=10, input=ctx_json)
            if r.stdout.strip():
                output.append(r.stdout.strip())
        except Exception:
            pass
    return chr(10).join(output)


def _format_tool_indicator(name: str, args: dict) -> str:
    """Render a Claude-Code-style tool indicator with actual args, not key names."""
    if not isinstance(args, dict):
        return f"{name}"
    PRIMARY_ARG = {
        "read_file": "path", "write_file": "path", "edit_file": "path",
        "bash": "cmd", "python": "code",
        "grep_files": "pattern", "glob_files": "pattern",
        "memory_search": "query", "memory_recall": "query",
        "memory_store": "name", "memory_stats": None,
        "create_task": "title", "complete_task": "task_id",
        "checkout_task": "task_id", "list_tasks": "company_id",
        "dispatch_deepseek_task": "task_id",
        "use_mcp_tool": "tool_name", "tool_search": "query",
        "web_fetch": "url", "web_search": "query",
        "screenshot": None, "click": "x", "type_text": "text",
        "verify_claim": "claim",
    }
    primary = PRIMARY_ARG.get(name, None)
    if primary is None:
        if name in PRIMARY_ARG:
            return name
        first_key = next(iter(args), None)
        if first_key:
            val = str(args[first_key]).replace("\n", " ")[:60]
            return f"{name} {first_key}={val}"
        return name
    val = args.get(primary)
    if val is None:
        return name
    val_str = str(val).replace("\n", " ")
    if len(val_str) > 80:
        val_str = val_str[:77] + "..."
    return f"{name} {primary}={val_str}"


def _format_tool_result(name: str, result) -> str:
    """One-line summary of a tool result for the user-visible indicator."""
    s = str(result) if result is not None else ""
    s = s.replace("\n", " ")
    if not s:
        return "ok"
    if s.startswith("[error]") or s.startswith("[blocked]"):
        return s[:120]
    if name in ("read_file",):
        return f"{len(str(result))} chars"
    if name in ("write_file", "edit_file"):
        return "written" if "successfully" in s.lower() or "updated" in s.lower() else s[:80]
    if name in ("bash", "python"):
        return s[:120] if s.strip() else "ok"
    if name in ("grep_files", "glob_files"):
        lines = str(result).splitlines()
        return f"{len(lines)} match(es)" if lines and lines[0].strip() else "no matches"
    if name in ("memory_search", "memory_recall"):
        return s[:120] if s and "no results" not in s else "no results"
    if name == "create_task":
        return s[:120]
    return s[:120]


def _execute_tool(name: str, args: dict) -> str:
    """Dispatch a tool call from the agentic loop to the appropriate backend."""
    _log_tool(f"tool: {_format_tool_indicator(name, args)}", level=1)
    if name == "memory_search":
        result = _memory_recall(args.get("query", ""))
        return result or "[memory: no results]"
    if name == "memory_store":
        try:
            import aibrain_db
            mid = aibrain_db.create_memory(
                name=args.get("name", ""),
                mem_type=args.get("type", "fact"),
                content=args.get("content", ""),
                tags=args.get("tags", ""),
                importance=float(args.get("importance", 0.5)),
                source_agent="lucy",
            )
            return f"[memory stored] id={mid}"
        except Exception as e:
            return f"[error] memory_store: {type(e).__name__}: {e}"
    if name == "memory_stats":
        try:
            import aibrain_db
            return str(aibrain_db.memory_summary())[:500]
        except Exception as e:
            return f"[error] memory_stats: {e}"
    if name == "list_tasks":
        try:
            from aibrain.core.companies import list_tasks as _list_tasks_sdk
            kwargs = {k: args[k] for k in ("status", "assignee") if args.get(k)}
            if args.get("limit"):
                kwargs["limit"] = int(args["limit"])
            tasks = _list_tasks_sdk(company_id="GT_LRWrEBQQ", **kwargs)
            if not tasks:
                return "[no tasks match]"
            lines = [f"{t.get('id')}: [{t.get('status')}/{t.get('priority')}] {str(t.get('title', ''))[:70]}" for t in tasks[:20]]
            return "\n".join(lines)
        except Exception as e:
            return f"[error] list_tasks: {type(e).__name__}: {e}"
    if name == "get_task":
        try:
            from aibrain.core.companies import get_task as _get_task_sdk
            t = _get_task_sdk(args.get("task_id", ""))
            return str(t)[:800] if t else "[not found]"
        except Exception as e:
            return f"[error] get_task: {type(e).__name__}: {e}"
    if name == "update_task":
        try:
            from aibrain.core.companies import update_task as _update_task_sdk
            kwargs = {k: v for k, v in args.items() if k != "task_id" and v is not None}
            _update_task_sdk(args.get("task_id", ""), **kwargs)
            return f"[updated] {args.get('task_id')}"
        except Exception as e:
            return f"[error] update_task: {type(e).__name__}: {e}"
    if name == "review_task":
        try:
            from aibrain.core.companies import review_task as _review_task_sdk
            v = _review_task_sdk(args.get("task_id", ""), output=args.get("output", ""))
            return f"verdict={v.get('verdict')}, score={v.get('score')}, critique={str(v.get('critique', ''))[:300]}"
        except Exception as e:
            return f"[error] review_task: {type(e).__name__}: {e}"

    # --- phase-3a thin tool dispatch (20 tools) ---
    if name == "read_pdf":
        return _read_pdf_tool(args)
    if name == "read_csv":
        return _read_csv_tool(args)
    if name == "read_json":
        return _read_json_tool(args)
    if name == "analyze_image":
        return _analyze_image_tool(args)
    if name == "describe_screen":
        return _describe_screen_tool(args)
    if name == "cognitive_accessibility":
        return _cognitive_accessibility_tool(args)
    if name == "voice_command":
        return _voice_command_tool(args)
    if name == "bci_signal":
        return _bci_signal_tool(args)
    if name == "eye_gaze":
        return _eye_gaze_tool(args)
    if name == "list_files":
        return _list_files_tool(args)
    if name == "diff_view":
        return _diff_view_tool(args)
    if name == "read_lines":
        return _read_lines_tool(args)
    if name == "clipboard":
        return _clipboard_tool(args)
    if name == "read_clipboard":
        return _read_clipboard_tool(args)
    if name == "write_clipboard":
        return _write_clipboard_tool(args)
    if name == "notebook_edit":
        return _notebook_edit_tool(args)
    if name == "file_hash":
        return _file_hash_tool(args)
    if name == "json_query":
        return _json_query_tool(args)
    if name == "help":
        return _help_tool(args)
    if name == "settings_get":
        return _settings_get_tool(args)
    if name == "settings_set":
        return _settings_set_tool(args)
    if name == "provider_status":
        return _provider_status_tool(args)
    if name == "set_provider":
        return _set_provider_tool(args)
    if name == "set_model":
        return _set_model_tool(args)
    if name == "describe_clipboard_image":
        return _describe_clipboard_image_tool(args)
    if name == "speak":
        return _speak_tool(args)
    if name == "higgsfield_generate":
        return _higgsfield_generate_tool(args)
    if name == "summarize":
        return _summarize_tool(args)
    if name == "cache_put":
        return _cache_put_tool(args)
    if name == "cache_get":
        return _cache_get_tool(args)
    if name == "batch_run":
        return _batch_run_tool(args)
    if name == "contrast_apca":
        return _contrast_apca_tool(args)
    if name == "wait_for":
        return _wait_for_tool(args)
    if name == "verify_integrity":
        return _verify_integrity_tool(args)
    if name == "git_commit":
        return _git_commit_tool(args)
    if name == "lint":
        return _lint_tool(args)
    if name == "token_usage":
        return _token_usage_tool(args)
    if name == "reformat":
        return _reformat_tool(args)
    if name == "privacy_mode":
        return _privacy_mode_tool(args)
    if name == "context_files":
        return _context_files_tool(args)
    if name == "undo_last_change":
        return _undo_last_change_tool(args)
    if name == "describe_prompt":
        return _describe_prompt_tool(args)
    if name == "describe_focused":
        return _describe_focused_tool(args)
    if name == "repair":
        return _repair_tool(args)
    if name == "write_csv":
        return _write_csv_tool(args)
    if name == "list_directory":
        return _list_directory_tool(args)
    if name == "count_lines":
        return _count_lines_tool(args)
    if name == "file_info":
        return _file_info_tool(args)
    if name == "hash_file":
        return _hash_file_tool(args)
    if name == "diff_files":
        return _diff_files_tool(args)
    if name == "find_duplicates":
        return _find_duplicates_tool(args)
    if name == "compress_files":
        return _compress_files_tool(args)
    if name == "extract_archive":
        return _extract_archive_tool(args)
    if name == "git_status":
        return _git_status_tool(args)
    if name == "git_log":
        return _git_log_tool(args)
    if name == "git_diff":
        return _git_diff_tool(args)
    if name == "http_get":
        return _http_get_tool(args)
    if name == "http_post":
        return _http_post_tool(args)
    if name == "env_get":
        return _env_get_tool(args)
    if name == "pip_list":
        return _pip_list_tool(args)
    if name == "run_pytest":
        return _run_pytest_tool(args)
    # --- phase-3b: agent-infra tools (helpers already existed, just unwired) ---
    if name == "spawn_subagent":
        return _spawn_subagent_tool(args)
    if name == "cron_create":
        return _cron_create_tool(args)
    if name == "schedule_wakeup":
        return _schedule_wakeup_tool(args)
    if name == "tool_search":
        _r = _search_deferred_tools(args.get("query", ""))
        return chr(10).join(str(x) for x in _r) if isinstance(_r, list) else str(_r)

    if not _BRIDGE_AVAILABLE:
        return "[error] BridgeLayer not available — install aibrain[hands]"
    bridge = _BridgeLayer(task_id=f"lucy_tool_{name}")  # type: ignore
    try:
        if name == "read_file":
            result = bridge.command_hands({"verb": "read_file", "path": args["path"]})
        elif name == "write_file":
            _deny = _path_denied(args.get("path", ""))
            if _deny:
                return _deny
            _lucy_push_undo(args["path"])
            result = bridge.command_hands({"verb": "write_file", "path": args["path"], "content": args["content"]})
        elif name == "bash":
            # F-LUCY-GATE-DEFAULTS-FLIP-1 — allow-first classification.
            # Deny destructive commands. Audit log state-changing-but-recoverable ops.
            # Everything else: allow.
            _bash_cmd = args.get("cmd", "") or args.get("command", "")
            _verdict, _reason = _classify_bash_risk(_bash_cmd)
            if _verdict == "denied":
                return f"[blocked] bash: {_reason}"
            # Human-in-the-loop Telegram confirmation for destructive ops.
            # Sits ALONGSIDE _classify_bash_risk — does not replace it.
            # Returns (True, ...) immediately if no destructive pattern matches.
            _ok, _confirm_reason = _confirm_destructive_via_telegram(_bash_cmd)
            if not _ok:
                _log_tool(f"bash denied: {_confirm_reason}", level=1)
                return f"[blocked] bash: Decker did not approve: {_confirm_reason}"
            if _verdict == "audit":
                _log_tool(f"bash audit: {_bash_cmd[:80]}", level=1)
                try:
                    import datetime as _dt, json as _j
                    _audit_dir = Path.home() / ".aibrain" / "audit"
                    _audit_dir.mkdir(parents=True, exist_ok=True)
                    with open(_audit_dir / "lucy_actions.log", "a", encoding="utf-8") as _af:
                        _af.write(f"{_dt.datetime.now().isoformat()} | bash | {_verdict} | {_reason}\n")
                except Exception:
                    pass
            result = bridge.command_hands({"verb": "bash", "cmd": _bash_cmd})
        elif name == "python":
            # F-LUCY-GATE-DEFAULTS-FLIP-1 — allow-first classification.
            # Deny only Hands validation failures. Everything else: allow.
            _py_code = args.get("code", "")
            _py_verdict, _py_reason = _classify_python_risk(_py_code)
            if _py_verdict == "denied":
                return f"[blocked] python: {_py_reason}"
            # default-allow: no needs_confirmation gate
            result = bridge.command_hands({"verb": "python", "code": _py_code})
        elif name == "verify_claim":
            v_tool = args.get("tool", "bash")
            v_arg = args.get("arg", "")
            v_claim = args.get("claim", "")
            if v_tool == "read_file":
                inner = _execute_tool("read_file", {"path": v_arg})
            elif v_tool == "bash":
                inner = _execute_tool("bash", {"cmd": v_arg})
            else:
                inner = _execute_tool("memory_search", {"query": v_arg})
            if "[error]" in inner or "[tool error]" in inner or "No such file" in inner or "not found" in inner.lower():
                return "UNVERIFIED: '" + v_claim + "' — verification returned: " + inner[:200]
            return "VERIFIED: '" + v_claim + "' — evidence: " + inner[:300]
        elif name == "use_mcp_tool":
            result = bridge.command_hands({"verb": "mcp", "tool": args["tool_name"], "params": args.get("params", {})})
        elif name == "create_task":
            return _create_task_tool(args)
        elif name == "complete_task":
            return _complete_task_tool(args)
        elif name == "dispatch_deepseek_task":
            return _dispatch_deepseek_tool(args)
        elif name == "deepseek_chat":
            return _deepseek_chat_tool(args)
        elif name == "apply_dispatch_blocks":
            return _apply_dispatch_blocks_tool(args)
        elif name == "fleet_reply":
            return _fleet_reply_tool(args)
        elif name == "verify_file_state":
            return _verify_file_state_tool(args)
        else:
            _df = _search_deferred_tools(name)
            if _df:
                _desc = _df[0]["function"]["description"]
                return f"[deferred tool] {_desc}. Use tool_search to load."
            elif name == "screenshot":
                return _screenshot_tool()
            elif name == "click":
                return _click_tool(args)
            elif name == "type_text":
                return _type_text_tool(args)
            elif name == "hotkey":
                return _hotkey_tool(args)
            elif name == "scroll":
                return _scroll_tool(args)
            elif name == "move_mouse":
                return _move_mouse_tool(args)
            elif name == "web_fetch":
                return _web_fetch_tool(args)
            elif name == "web_search":
                return _web_search_tool(args)
            elif name == "glob_files":
                return _glob_files_tool(args)
            elif name == "grep_files":
                return _grep_files_tool(args)
            elif name == "edit_file":
                return _edit_file_tool(args)
            return f"[error] unknown tool: {name}"
        if isinstance(result, dict):
            output = result.get("output") or result.get("content") or result.get("result") or str(result)
        else:
            output = str(result) if result is not None else "[tool returned no output]"
        _log_tool(f"  → {_format_tool_result(name, output)}", level=2)
        return output
    except Exception as e:
        err = f"[tool error] {name}: {e}"
        _log_tool(f"  → {err[:120]}", level=2)
        return err


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

INBOX_POLL_INTERVAL = 2.0  # F-LUCY-INBOX-POLL-ASYNC-1: seconds between background poll cycles


class LucyAgent:
    @staticmethod
    def _strip_surrogates(text):
        if not isinstance(text, str):
            return text
        return text.encode("utf-8", "replace").decode("utf-8", "replace")

    @classmethod
    def _clean_messages(cls, msgs):
        out = []
        for m in msgs:
            m2 = dict(m)
            if isinstance(m2.get("content"), str):
                m2["content"] = cls._strip_surrogates(m2["content"])
            out.append(m2)
        return out

    def __init__(self, provider: str, model: str, api_key: str):
        self.provider = provider
        self.model = model
        self.api_key = api_key
        # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21): track
        # whether the provider/model came from the constructor (explicit)
        # vs from config.json (implicit). _sync_provider_from_config() must
        # NOT silently override an explicit constructor arg — only sync
        # when the caller asked for it via cmd_reload().
        self._explicit_provider = bool(provider)
        self.cfg = _load_config()
        self._memory_ok: bool | None = None
        self._memory_last_check: float = 0
        self._last_hb: float = 0
        try:
            from aibrain.core.watchdog import start_watchdog, on_stuck
            start_watchdog()
            on_stuck(lambda: self.chat("[WATCHDOG] You appear stuck. Summarize what you were doing and retry recovery."))
        except Exception:
            pass
        self._plan_mode: bool = False
        self._plan_buffer: list = []
        self._recording: bool = False
        self._frames: list = []
        self.startup_ctx: str = ""       # warm memory context loaded at boot

        # F-LUCY-FLEET-AUTO-RESPONSE-1: pending fleet messages for auto-response
        self._pending_fleet_msgs: list[dict] = []
        # F-LUCY-FLEET-AUTO-RESPONSE-2: thread-safety lock for fleet drain
        self._fleet_drain_lock = threading.Lock()
        self.first_boot_ctx: str | None = None  # dossier — first boot only

        # F-LUCY-INBOX-POLL-ASYNC-1: background inbox polling
        self._seen_msg_ids: set[str] = set()
        self._inbox_poll_thread: threading.Thread | None = None
        self._inbox_poll_stop = threading.Event()

        # F-LUCY-CLAUDE-CLI-1: claude_cli subprocess runtime
        # When provider is 'claude_cli', api_key holds the binary path and we
        # skip OpenAI client creation. _chat_via_claude_cli() handles all LLM
        # interaction via subprocess.
        # F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21): for all
        # non-claude_cli providers chat now goes through ProviderRouter.dispatch_chat.
        # No more building openai.OpenAI() with base_url-swapping per provider —
        # that was the structural bug that 401'd anthropic and silently swapped
        # ollama to deepseek. self._client kept as None for backwards compat
        # surface; the chat path no longer reads it.
        self._client = None
        if provider == "claude_cli":
            self._claude_binary = api_key  # path to claude binary
            self._claude_session_id: str | None = None
        else:
            self._claude_binary = None
            self._claude_session_id = None

        # Load session history (F-LUCY-MID-TOOL-CALL-CRASH-RESUME-1: also restore pending tool call)
        self.history, self._session_ts, self._pending_tool_call = _load_session()

        # First boot context
        self.first_boot_ctx = _load_first_boot_context()

        # Start async inbox poller — receives FleetBus messages while Lucy is idle
        self._register_default_subs()
        self._start_inbox_poller()

    def _start_inbox_poller(self) -> None:
        """F-LUCY-INBOX-POLL-ASYNC-1: spawn daemon thread that polls FleetBus
        every INBOX_POLL_INTERVAL seconds. Dedupes by msg id so we never
        double-handle a message even if the in-loop poll also runs."""
        if self._inbox_poll_thread is not None and self._inbox_poll_thread.is_alive():
            return

        def _poll_loop() -> None:
            try:
                from aibrain.core.agent_comms import FleetBus
                _bus = FleetBus(
                    agent_id="lucy",
                    db_path=DB_PATH,
                )
            except Exception:
                return
            while not self._inbox_poll_stop.is_set():
                try:
                    _msgs = _bus.poll_inbox()
                    for _m in _msgs:
                        _mid = _m.get("id") or ""
                        if _mid and _mid in self._seen_msg_ids:
                            continue
                        if _mid:
                            self._seen_msg_ids.add(_mid)
                            if len(self._seen_msg_ids) > 1000:
                                # prune — keep last 500
                                self._seen_msg_ids = set(list(self._seen_msg_ids)[-500:])
                        try:
                            self._handle_inbox_message(_m)
                        except Exception:
                            pass
                    if self._pending_fleet_msgs:
                        try:
                            self._process_pending_fleet_msgs()
                        except Exception:
                            pass
                except Exception:
                    pass
                self._inbox_poll_stop.wait(INBOX_POLL_INTERVAL)

        self._inbox_poll_thread = threading.Thread(
            target=_poll_loop, daemon=True, name="lucy-inbox-poller"
        )
        self._inbox_poll_thread.start()

    def _check_memory(self) -> bool:
        # F-LUCY-RECALL-BUG: don't cache a single failure permanently.
        # Retry every 30s so a slow-starting backend doesn't poison the session.
        import time as _time
        _now = _time.monotonic()
        if self._memory_ok and self._memory_last_check:
            if _now - self._memory_last_check < 30:
                return True
        try:
            r = requests.get("http://localhost:8001/api/health", timeout=3)
            self._memory_ok = r.status_code == 200
            self._memory_last_check = _now if self._memory_ok else 0
        except Exception:
            self._memory_ok = False
            self._memory_last_check = 0
        return self._memory_ok

    def _handle_inbox_message(self, msg: dict):
        """F-LUCY-INBOX-POLL-WIRING-1 + F-LUCY-INBOX-POLL-ASYNC-1 + F-LUCY-COMMS-ROBUSTNESS-1:
        handle fleet inbox message.

        Auto-acks ping/hello tests. Surfaces all other inbound to terminal +
        chat history so Decker SEES inbound messages arrive in real time.

        CloudEvent dicts from FleetBus.poll_inbox carry application data in
        msg["data"], not msg["payload"] (which was the original DB column name).
        """
        _typ = msg.get("type", "")
        _payload = msg.get("data", {}) or msg.get("payload", {})
        _src = (msg.get("source") or "").replace("agent://", "")
        # F-FLEETBUS-FROM-FIELD-DISPLAY-1: fall back to data["from"] when envelope source is missing/unknown
        if not _src or _src == "unknown":
            if isinstance(_payload, dict):
                _src = (_payload.get("from") or "").strip()

        # Auto-ack for ping tests
        if "test.ping" in _typ or "test.hello" in _typ:
            try:
                from aibrain.core.agent_comms import FleetBus
                _bus = FleetBus(agent_id=LUCY_FLEET_ID, db_path=DB_PATH)
                _bus.publish(f"fleet.test.{LUCY_FLEET_ID}_ack", {"ping_id": _payload.get("ping_id", ""), "from": LUCY_FLEET_ID})
            except Exception:
                pass
            return  # test handled, don't double-render

        # ── F-LUCY-HTTP-BROKER-ADAPTER-1: typed message handlers ──────

        if "task_completed" in _typ:
            _task_id = _payload.get("task_id", "?")
            _agent = _payload.get("agent", _src)
            _summary = _payload.get("summary") or _payload.get("msg", "")[:200]
            _banner = (
                f"\n{DIM}[fleet: task_completed] agent={_agent} task={_task_id}\n"
                f"  {_summary}{RESET}\n"
            )
            try:
                print(_banner)
                sys.stdout.flush()
            except Exception:
                pass
            try:
                self.history.append({
                    "role": "system",
                    "content": f"[FLEET task_completed] agent={_agent} task={_task_id} summary={_summary}",
                })
            except Exception:
                pass
            return  # handled, don't queue for auto-response

        if "task_failed" in _typ:
            _task_id = _payload.get("task_id", "?")
            _agent = _payload.get("agent", _src)
            _error = _payload.get("error") or _payload.get("msg", "")[:200]
            _banner = (
                f"\n{RED}[fleet: task_failed] agent={_agent} task={_task_id}\n"
                f"  {_error}{RESET}\n"
            )
            try:
                print(_banner)
                sys.stdout.flush()
            except Exception:
                pass
            try:
                self.history.append({
                    "role": "system",
                    "content": f"[FLEET task_failed — retry consideration] agent={_agent} task={_task_id} error={_error}",
                })
            except Exception:
                pass
            return

        if "fleet_status" in _typ or "heartbeat" in _typ.lower():
            _agent = _payload.get("agent", _src)
            _status = _payload.get("status", "alive")
            # Heartbeats are low-priority — log at level 2 only
            _log_tool(f"fleet heartbeat: {_agent} status={_status}", level=2)
            return  # don't surface heartbeats as noise

        if "liaison_verdict" in _typ:
            _task_id = _payload.get("task_id", "?")
            _verdict = _payload.get("verdict", "?")
            _reviewer = _payload.get("reviewer", _src)
            _notes = _payload.get("notes") or _payload.get("msg", "")[:200]
            _banner = (
                f"\n{YELLOW}[fleet: liaison_verdict] task={_task_id} verdict={_verdict} reviewer={_reviewer}\n"
                f"  {_notes}{RESET}\n"
            )
            try:
                print(_banner)
                sys.stdout.flush()
            except Exception:
                pass
            try:
                self.history.append({
                    "role": "system",
                    "content": (
                        f"[FLEET liaison_verdict source=agent_review] "
                        f"task={_task_id} verdict={_verdict} reviewer={_reviewer} notes={_notes}"
                    ),
                })
            except Exception:
                pass
            # Record in execution_log
            try:
                _log_dir = Path.home() / ".aibrain" / "execution_log"
                _log_dir.mkdir(parents=True, exist_ok=True)
                import datetime as _dt
                _ts = _dt.datetime.now().isoformat()
                _entry = json.dumps({
                    "timestamp": _ts,
                    "source": "agent_review",
                    "task_id": _task_id,
                    "verdict": _verdict,
                    "reviewer": _reviewer,
                    "notes": _notes,
                })
                with open(_log_dir / "lucy_execution_log.jsonl", "a", encoding="utf-8") as _f:
                    _f.write(_entry + "\n")
            except Exception:
                pass
            return

        # F-LUCY-COMMS-ROBUSTNESS-1 Bug A: render real inbound to terminal + history
        try:
            _msg_text = (_payload.get("msg") or _payload.get("text")
                         or _payload.get("body") or json.dumps(_payload)[:300])
        except Exception:
            _msg_text = str(_payload)[:300]
        banner = f"\n[FLEET inbound from {_src}] {_typ}\n  {_msg_text}\n"
        try:
            print(banner)
            sys.stdout.flush()
        except Exception:
            pass
        try:
            self.history.append({
                "role": "system",
                "content": f"[FLEET inbound from {_src}] type={_typ} msg={_msg_text}",
            })
        except Exception:
            pass

        # F-LUCY-FLEET-AUTO-RESPONSE-1: queue non-trivial fleet messages
        # for auto-response. Heartbeats/tests already returned above.
        _is_heartbeat = any(kw in _typ.lower() for kw in ("heartbeat", "status"))
        _is_test = _typ.startswith("fleet.test.")
        if not _is_heartbeat and not _is_test and _payload:
            # F-LUCY-INBOX-BODY-CONTENT-FALLBACK-1 (2026-05-24): pick the
            # LONGEST string-valued candidate from the known body keys
            # so payloads that include a short `msg` summary alongside a
            # full `content` field surface the full content. The old
            # behaviour read the first key found (`msg`) and missed the
            # actual instruction body — caught when my own dispatch how-
            # to send earlier this session put summary in `msg` and the
            # full markdown doc in `content`; Lucy auto-responded to the
            # short summary instead of the doc.
            _candidate_keys = ("content", "msg", "text", "body", "question", "prompt")
            _candidates = []
            for k in _candidate_keys:
                v = _payload.get(k)
                if isinstance(v, str) and v.strip():
                    _candidates.append(v)
            # Use the longest candidate (substance over position-in-dict).
            _body = max(_candidates, key=len) if _candidates else ""
            if not _body:
                # Fallback: any string-valued field longer than 10 chars.
                _vals = [v for v in _payload.values() if isinstance(v, str) and len(v) > 10]
                _body = _vals[0] if _vals else ""
            if _body and len(_body.strip()) > 5:
                # F-FLEETBUS-REPLY-ROUTING-FIX: derive reply topic from SENDER, not inbound topic.
                # Inbound type fleet.message.lucy = OUR inbox. Replying there talks to self.
                if _src and _src not in ("unknown", "lucy", "self", ""):
                    _reply_topic = f"fleet.message.{_src}"
                elif _typ.startswith("fleet.") and not _typ.endswith(".lucy"):
                    _reply_topic = _typ  # non-lucy broadcast/other topics, keep
                else:
                    _reply_topic = "fleet.message.neuro"  # default fallback to orchestrator
                self._pending_fleet_msgs.append({
                    "body": _body,
                    "source": _src,
                    "reply_topic": _reply_topic,
                    "msg_id": msg.get("id", ""),
                })

    def _process_pending_fleet_msgs(self) -> None:
        """F-LUCY-FLEET-AUTO-RESPONSE-2: drain queued fleet messages and
        auto-respond. Thread-safe via _fleet_drain_lock."""
        if not self._pending_fleet_msgs:
            return
        with self._fleet_drain_lock:
            while self._pending_fleet_msgs:
                _fm = self._pending_fleet_msgs.pop(0)
                _fm_body = _fm["body"]
                _fm_src = _fm["source"]
                _fm_reply = _fm["reply_topic"]
                try:
                    print(f"\n{DIM}[FLEET auto-response to {_fm_src}]{RESET}")
                    sys.stdout.flush()
                except Exception:
                    pass
                _fm_response = self.chat(_fm_body)
                try:
                    from aibrain.core.agent_comms import FleetBus
                    _reply_bus = FleetBus(agent_id=LUCY_FLEET_ID, db_path=DB_PATH)
                    _reply_bus.publish(_fm_reply, {
                        "msg": _fm_response,
                        "reply_to": _fm.get("msg_id", ""),
                        "from": LUCY_FLEET_ID,
                    })
                    print(f"{DIM}[FLEET reply published → {_fm_reply}]{RESET}")
                    sys.stdout.flush()
                except Exception as _e:
                    print(f"{DIM}[FLEET reply failed: {_e}]{RESET}")
                    sys.stdout.flush()

    def _register_default_subs(self) -> None:
        """F-LUCY-COMMS-ROBUSTNESS-1 Bug B: ensure Lucy is subscribed to the
        topics inbound real traffic actually uses. Idempotent — checks for
        existing sub_id before inserting."""
        import sqlite3 as _sql
        # F-LUCY-CLONE-AGENT-ID-1 (2026-05-23): subscribe topics carry the
        # clone's identity (LUCY_FLEET_ID) so pixel polls fleet.message.pixel,
        # scout polls fleet.message.scout, etc. The sub_id strings keep "lucy-"
        # prefix for legacy lookup — they're stable internal ids, not topics.
        # F-CLONE-NO-WILDCARD-EAVESDROP-1 (2026-05-23): the legacy
        # "fleet.message.*" wildcard caused cross-talk: when Pixel replied to
        # Neuro on fleet.message.neuro, Lucy's wildcard sub picked it up and
        # interrupted Lucy. Each clone now only subscribes to her OWN inbox
        # topics + explicit broadcasts + tests. Direct messages stay direct.
        DEFAULT_SUBS = [
            ("lucy-default-direct",       f"fleet.message.{LUCY_FLEET_ID}"),
            ("lucy-default-direct-glob",  f"fleet.message.{LUCY_FLEET_ID}.*"),
            ("lucy-default-test",         "fleet.test.*"),
            ("lucy-default-broadcast",    "fleet.broadcast.*"),
            ("lucy-default-handoff",      "fleet.handoff.*"),
        ]
        try:
            db = _sql.connect(DB_PATH)
            for sub_id, topic_glob in DEFAULT_SUBS:
                exists = db.execute(
                    "SELECT 1 FROM agent_subscriptions WHERE sub_id=?", (sub_id,)
                ).fetchone()
                if not exists:
                    db.execute(
                        "INSERT INTO agent_subscriptions (sub_id, agent_id, topic_glob) VALUES (?, ?, ?)",
                        (sub_id, "lucy", topic_glob),
                    )
            db.commit()
            db.close()
        except Exception:
            pass

    # F-LUCY-MODEL-AWARE-COMPACTION-1: context window estimates (chars) per model.
    # 1 token ≈ 4 chars in English. Threshold = 80% of context window for headroom.
    # Fallback for unknown models: 100k chars (safe for any provider).
    _MODEL_CONTEXT_CHARS: dict[str, int] = {
        # Claude models — 200k token context window
        "claude-opus-4":     160_000,
        "claude-sonnet-4":   160_000,
        "claude-haiku-4":    160_000,
        "claude-opus-4-7":   160_000,
        "claude-sonnet-4-6": 160_000,
        "claude-haiku-4-5":  160_000,
        # DeepSeek models — 128k token context
        "deepseek-v4":       100_000,
        "deepseek-reasoner": 100_000,
        "deepseek-chat":     100_000,
        # OpenAI models
        "gpt-4o":            100_000,
        "gpt-4o-mini":       100_000,
        "gpt-5":             100_000,
        "o1":                100_000,
        # Gemini models — large context
        "gemini-2.5":        500_000,
        "gemini-2.0":        500_000,
        # Ollama local models — small context
        "llama3.2":           32_000,
        "llama3.1":           32_000,
    }

    def _get_compaction_threshold(self) -> int:
        """Return the compaction char threshold for the currently active model.
        Matches by prefix — 'claude-opus-4-7' matches 'claude-opus-4'."""
        model = (self.model or "").lower()
        for prefix, limit in sorted(self._MODEL_CONTEXT_CHARS.items(),
                                     key=lambda x: -len(x[0])):
            if model.startswith(prefix):
                return limit
        return 100_000  # safe fallback for unknown models

    def _compact_history(self, history: list, keep_recent: int = 30, max_chars: int | None = None) -> list:
        """Model-aware context compaction. Uses the active model's context
        window to determine the compaction threshold (80% of context).
        Only fires when actual context-size pressure exists — no arbitrary
        message-count trigger. Keeps the most recent messages verbatim,
        summarizes older ones via the active provider.

        F-LUCY-MODEL-AWARE-COMPACTION-1: threshold is now derived from the
        active model rather than a hardcoded 120k chars. /switch changes
        the model, which changes the threshold on the next compaction check.
        """
        if max_chars is None:
            max_chars = self._get_compaction_threshold()
        try:
            total = 0
            for msg in history:
                c = msg.get("content", "")
                if isinstance(c, str):
                    total += len(c)
                elif isinstance(c, list):
                    for p in c:
                        if isinstance(p, dict) and "text" in p:
                            total += len(p["text"])
                total += 50
            if total < max_chars:
                return history
        except Exception:
            return history[-100:]
        try:
            split_at = max(0, len(history) - keep_recent)
            old, recent = history[:split_at], history[split_at:]
            if not old:
                return history
            lines = []
            for msg in old:
                c = msg.get("content", "")
                if isinstance(c, list):
                    c = "\n".join(p.get("text", "") for p in c if isinstance(p, dict) and "text" in p)
                lines.append("[" + str(msg.get("role", "?")) + "] " + str(c))
            snippet = chr(10).join(lines)
            from aibrain.core.provider_contract import ProviderRouter, ProviderConfigError
            import asyncio as _alo
            router = ProviderRouter()
            reviewer = router.get_provider("text_review")
            persona = ("You are a context-compression assistant. Summarize the conversation "
                       "preserving all key decisions, task progress, file paths, and anything "
                       "needed to continue the same task. Concise but lossless on essentials.")
            result = _alo.new_event_loop().run_until_complete(
                reviewer.invoke({
                    "persona": persona,
                    "work_output": snippet,
                    "acceptance_criteria": "Produce a concise summary retaining all essential facts to continue the task.",
                })
            )
            summary = (result.get("critique") or result.get("text") or "").strip() if isinstance(result, dict) else ""
            if not summary:
                return history[-100:]
            return [{"role": "system", "content": "[context summary] " + summary}] + recent
        except (ProviderConfigError, Exception):
            return history[-100:]

    def _build_messages(self, user_input: str, memory_ctx: str) -> list[dict]:
        messages: list[dict] = [{"role": "system", "content": SYSTEM_PROMPT}]

        # First-boot dossier injection (only once per boot)
        if self.first_boot_ctx:
            messages.append({
                "role": "system",
                "content": f"ORIENTATION DOSSIER (read once at first boot):\n\n{self.first_boot_ctx}",
            })

        # Startup warm context
        if self.startup_ctx:
            messages.append({
                "role": "system",
                "content": f"High-importance memories loaded at startup:\n{self.startup_ctx}",
            })

        # Per-message memory recall
        if memory_ctx:
            messages.append({
                "role": "system",
                "content": f"Relevant memories for this message:\n{memory_ctx}",
            })

        messages.extend(self._compact_history(self.history))
        messages.append({"role": "user", "content": user_input})
        return messages

    # ── F-LUCY-CLAUDE-CLI-1: subprocess-based chat via claude binary ──────

    _CLAUDE_CLI_MAX_TOOL_ROUNDS = int(os.environ.get("LUCY_MAX_TOOL_ROUNDS", "500"))

    def _chat_via_claude_cli(self, messages_with_tools: list[dict],
                              _stop_thinking: threading.Event,
                              _stop_typeahead: threading.Event) -> str:
        """Run the full tool-calling loop via subprocess calls to the claude binary.

        Uses subscription auth (not API key). Each turn:
          1. Extract the latest user message as the prompt (stdin piped)
          2. Extract system messages -> --append-system-prompt-file temp file
          3. Spawn `claude --dangerously-skip-permissions --print --output-format json ...`
          4. Parse the JSON response
          5. Return the text result

        Aligned with the proven subprocess pattern in
        decker_system/04_tools/claude_cli.py::call_claude_cli, which works for
        Liaison reviews from the SAME Python process. Key fixes applied:
          - --dangerously-skip-permissions (was missing; CLI rejects non-interactive
            invocation without it on Windows)
          - stdin piping for prompt (was -- positional arg; stdin survives Windows
            CreateProcess argv limits and avoids quoting edge cases)
          - system prompt via temp file (was not passed to CLI at all; Claude never
            saw Lucy's behavioral contract, verification protocol, etc.)
        """
        import tempfile, subprocess as _sp

        full_response = ""

        # --- Extract latest user message (becomes stdin prompt) ----------
        latest_user_text = ""
        for m in reversed(messages_with_tools):
            if m.get("role") == "user":
                c = m.get("content", "")
                if isinstance(c, str):
                    latest_user_text = c
                elif isinstance(c, list):
                    parts = []
                    for b in c:
                        if isinstance(b, dict):
                            if b.get("type") == "text":
                                parts.append(b.get("text", ""))
                            elif b.get("type") == "tool_result":
                                parts.append(str(b.get("content", "")))
                    latest_user_text = "\n".join(parts)
                break
        latest_user_text = self._strip_surrogates(latest_user_text or "")

        # --- Build system prompt from all system-role messages -----------
        _sys_parts = []
        for m in messages_with_tools:
            if m.get("role") == "system":
                _sys_parts.append(str(m.get("content", "")))
        _system_prompt = "\n\n---\n\n".join(_sys_parts) if _sys_parts else None

        # --- Permission flags mirroring decker_system/04_tools/claude_cli.py --
        # On Windows (non-root): --dangerously-skip-permissions --print
        # On Linux root: --permission-mode acceptEdits --print
        # Env override: AIBRAIN_CLAUDE_CLI_ROOT_MODE=<mode>
        _perm_flags = []
        _mode_override = os.environ.get("AIBRAIN_CLAUDE_CLI_ROOT_MODE")
        if _mode_override:
            _valid_modes = {"acceptEdits", "auto", "bypassPermissions", "default", "dontAsk", "plan"}
            if _mode_override not in _valid_modes:
                return f"[error] claude_cli AIBRAIN_CLAUDE_CLI_ROOT_MODE={_mode_override!r} invalid. Allowed: {sorted(_valid_modes)}"
            _perm_flags = ["--permission-mode", _mode_override, "--print"]
        elif hasattr(os, "geteuid") and os.geteuid() == 0:
            _perm_flags = ["--permission-mode", "acceptEdits", "--print"]
        else:
            _perm_flags = ["--dangerously-skip-permissions", "--print"]

        # --- System prompt temp file (if any) ----------------------------
        _sys_path = None
        if _system_prompt and len(_system_prompt) > 10:
            try:
                _tmp = tempfile.NamedTemporaryFile(
                    mode="w", encoding="utf-8",
                    suffix=".txt", prefix="lucy_claude_sys_",
                    delete=False,
                )
                _sys_path = _tmp.name
                _tmp.write(_system_prompt)
                _tmp.flush()
                _tmp.close()
            except Exception:
                _sys_path = None  # proceed without system prompt if temp file fails

        # F-LUCY-CLAUDE-CLI-CONFIGDIR-1: the claude CLI's subscription auth
        # lives in a per-profile CLAUDE_CONFIG_DIR. A standalone Lucy process
        # inherits none, so claude falls back to the unauthed default
        # ~/.claude → "Not logged in" / 403 "org disabled subscription".
        # Proven 2026-05-17 (Neuro A/B test): the SAME call that 403'd
        # succeeds when CLAUDE_CONFIG_DIR points at the authed profile that
        # Claude Code itself uses. Respect an inherited value; else auto-detect
        # an authed profile, preferring the non-default profiles which hold the
        # working subscription session over bare ~/.claude.
        _claude_env = dict(os.environ)
        from pathlib import Path as _CcdP
        _ccd = None
        # PREFER the proven personal profile over ANY inherited/org value.
        # Root cause (Neuro-verified 2026-05-17): the DeckerOps *org* profile
        # (~/.claude-deckerops) returns 403 "organization has disabled Claude
        # subscription access for Claude Code"; the personal profile
        # (~/.claude-sindecker) works. The prior logic respected an inherited
        # CLAUDE_CONFIG_DIR — if the launch shell inherited the org profile,
        # every claude_cli call 403'd. Never auto-pick .claude-deckerops.
        for _cand in (".claude-sindecker", ".claude"):
            _cp = _CcdP.home() / _cand
            if (_cp / ".credentials.json").exists():
                _ccd = str(_cp)
                break
        if not _ccd:
            _ccd = _claude_env.get("CLAUDE_CONFIG_DIR")  # last resort: inherited
        if _ccd:
            _claude_env["CLAUDE_CONFIG_DIR"] = _ccd

        try:
            for _round in range(self._CLAUDE_CLI_MAX_TOOL_ROUNDS):
                cmd = [self._claude_binary]
                cmd += _perm_flags
                cmd += ["--output-format", "json"]
                cmd += ["--model", self.model]
                # --max-turns 1 strangled ALL tool use: any prompt needing a
                # tool (read a file, analyze an image) makes claude emit
                # tool_use on turn 1 and needs turn 2 to finish -> with
                # max-turns 1 it returns error_max_turns / exit 1. Only
                # pure-text chat survived. 12 = enough for read+analyze+respond
                # tool rounds within one Lucy turn, still bounded. (Verified
                # root cause 2026-05-17 from claude_cli_debug.log:
                # subtype=error_max_turns, stop_reason=tool_use.)
                # Generous so it is NOT the governor of autonomous work — a
                # cap that interrupts every N turns and resumes is fragile
                # (loses momentum/context, costs more). Real stops are the
                # cost ceiling, the 300s wall-clock, and the Esc/Ctrl+B cancel
                # flag. 50 matches Lucy's tool-call limit; graceful-resume
                # below is only a rare-overflow safety net. Env-overridable.
                cmd += ["--max-turns", os.environ.get("AIBRAIN_CLAUDE_CLI_MAX_TURNS", "50")]
                cmd += [
                    "--allowedTools",
                    "Read,Write,Bash(pwd:*),Bash(ls:*),Bash(cat:*),Bash(grep:*),"
                    "Bash(find:*),Bash(python:*),Bash(git:status,git:diff,git:log,git:show),"
                    "Bash(pip:*),Bash(dir:*),Bash(where:*),Bash(echo:*),Bash(npx:*),Bash(npm:*),Bash(node:*)",
                ]
                if _sys_path:
                    cmd += ["--append-system-prompt-file", _sys_path]
                if self._claude_session_id:
                    cmd += ["--resume", self._claude_session_id]

                _log_tool(f"claude_cli turn {_round+1} -- {len(messages_with_tools)} messages", level=1)
                # Debug trace: dump the exact command + result so silent failures are visible
                try:
                    _dbg = Path.home() / ".aibrain" / "claude_cli_debug.log"
                    _dbg.parent.mkdir(parents=True, exist_ok=True)
                    with open(_dbg, "a", encoding="utf-8") as _f:
                        import datetime as _dt
                        _f.write(f"\n=== {_dt.datetime.now().isoformat()} turn {_round+1} ===\n")
                        _f.write(f"CMD: {cmd!r}\n")
                        _f.write(f"CLAUDE_CONFIG_DIR: {_claude_env.get('CLAUDE_CONFIG_DIR')!r}\n")
                        _f.write(f"STDIN len: {len(latest_user_text)}\n")
                        _f.write(f"SYS_FILE: {_sys_path}\n")
                except Exception:
                    pass
                # Generous, env-overridable. The per-call wall-clock must NOT
                # be the governor of autonomous work (300s killed real long
                # tasks and LOST them). Real governors: the outer round budget,
                # the cost ceiling, and the Esc/Ctrl+B cancel. On timeout we
                # resume the tracked session rather than hard-fail (same
                # graceful-degrade principle as error_max_turns).
                _cli_timeout = int(os.environ.get("AIBRAIN_CLAUDE_CLI_TIMEOUT", "900"))
                try:
                    proc = _sp.run(
                        cmd,
                        input=latest_user_text,   # stdin piping -- mirrors call_claude_cli
                        capture_output=True,
                        text=True,
                        timeout=_cli_timeout,
                        encoding="utf-8",
                        errors="replace",
                        env=_claude_env,   # F-LUCY-CLAUDE-CLI-CONFIGDIR-1: authed profile
                    )
                except _sp.TimeoutExpired:
                    try:
                        with open(_dbg, "a", encoding="utf-8") as _f:
                            _f.write(f"TIMEOUT after {_cli_timeout}s "
                                     f"(session={self._claude_session_id!r})\n")
                    except Exception:
                        pass
                    if self._claude_session_id and _round + 1 < self._CLAUDE_CLI_MAX_TOOL_ROUNDS:
                        _log_tool(
                            f"claude_cli per-call timeout ({_cli_timeout}s) — "
                            f"resuming session (round {_round+2}/"
                            f"{self._CLAUDE_CLI_MAX_TOOL_ROUNDS})", level=2)
                        continue
                    _stop_thinking.set()
                    return ("[error] claude_cli timed out after "
                            f"{_cli_timeout}s with no resumable session "
                            f"(round {_round+1}). Raise AIBRAIN_CLAUDE_CLI_TIMEOUT "
                            "or split the task — note a single first round must "
                            "finish within the timeout to create a checkpoint.")
                try:
                    with open(_dbg, "a", encoding="utf-8") as _f:
                        _f.write(f"RC: {proc.returncode}\n")
                        _f.write(f"STDOUT: {(proc.stdout or '')[:500]!r}\n")
                        _f.write(f"STDERR: {(proc.stderr or '')[:500]!r}\n")
                except Exception:
                    pass

                if proc.returncode != 0:
                    # GRACEFUL DEGRADE on error_max_turns (Pattern #11 — don't
                    # band-aid the cap; make hitting it non-fatal). The
                    # per-call turn cap was hit mid tool_use but real work
                    # happened and a session_id exists -> capture it and
                    # CONTINUE the loop so the next round --resumes and
                    # finishes, instead of hard-failing and losing everything.
                    # Real stops remain: the outer round budget
                    # (_CLAUDE_CLI_MAX_TOOL_ROUNDS), the 300s subprocess
                    # timeout, cost, and the Esc/Ctrl+B cancel flag — NOT this
                    # per-call cap.
                    try:
                        _pj = json.loads(proc.stdout)
                    except Exception:
                        _pj = {}
                    if _pj.get("subtype") == "error_max_turns":
                        self._claude_session_id = (
                            _pj.get("session_id") or self._claude_session_id)
                        if self._claude_session_id and _round + 1 < self._CLAUDE_CLI_MAX_TOOL_ROUNDS:
                            _log_tool(
                                f"claude_cli per-call turn cap hit — resuming "
                                f"(round {_round+2}/{self._CLAUDE_CLI_MAX_TOOL_ROUNDS})",
                                level=2)
                            continue
                    stderr = proc.stderr[:500] if proc.stderr else "(no stderr)"
                    _stop_thinking.set()
                    err_msg = f"[error] claude_cli exit {proc.returncode}: {stderr}"
                    sys.stderr.write(f"\n{err_msg}\n")
                    sys.stderr.flush()
                    return err_msg

                try:
                    result = json.loads(proc.stdout)
                except json.JSONDecodeError:
                    _stop_thinking.set()
                    raw = proc.stdout[:1000] if proc.stdout else "(empty stdout)"
                    return f"[error] claude_cli returned non-JSON: {raw}"

                # Track session for --resume on next turn
                self._claude_session_id = result.get("session_id") or self._claude_session_id

                # claude --print --output-format json returns a simplified result:
                # {"type": "result", "result": "<text>", "session_id": "...",
                #  "is_error": false, "stop_reason": "end_turn", ...}
                if result.get("is_error"):
                    _stop_thinking.set()
                    return f"[error] claude_cli api_error: {result.get('api_error_status') or result.get('result', 'unknown')}"

                text_response = result.get("result", "") or ""
                _stop_thinking.set()
                time.sleep(0.07)
                full_response = text_response
                sys.stdout.write(SKY_BLUE + full_response + RESET + "\n")
                sys.stdout.flush()
                break

            else:
                _stop_thinking.set()
                full_response = f"[error] claude_cli tool loop exceeded {self._CLAUDE_CLI_MAX_TOOL_ROUNDS} rounds"
                print(f"\n{RED}{full_response}{RESET}")

        finally:
            # Clean up system prompt temp file
            if _sys_path:
                try:
                    if os.path.exists(_sys_path):
                        os.remove(_sys_path)
                except OSError:
                    pass

        return full_response

    # ── Main chat method ──────────────────────────────────────────────────

    def _sync_provider_from_config(self) -> None:
        """Live provider sync: re-resolve from config EVERY turn so a
        `lucy_switch` change takes effect without a process restart, and
        a Claude session can never bleed onto a non-Claude turn.

        F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21):
        - Respect _explicit_provider: an explicit constructor arg is NOT
          silently overridden by config.json. Only cmd_reload() / cmd_switch()
          should change provider after construction. This closes the
          'circular metric' that made the multi-provider test false-PASS
          (test passed provider=ollama, _sync silently swapped to deepseek).
        - No more openai.OpenAI() base_url-swapping. Chat goes through
          ProviderRouter.dispatch_chat which dispatches to the correct
          backend per provider with the correct endpoint."""
        if getattr(self, "_explicit_provider", False):
            # Explicit constructor arg wins. Just keep the api_key fresh
            # from env on each turn so a key rotation is picked up.
            if self.provider == "anthropic":
                self.api_key = os.environ.get("ANTHROPIC_API_KEY", self.api_key)
            elif self.provider == "openai":
                self.api_key = os.environ.get("OPENAI_API_KEY", self.api_key)
            elif self.provider == "deepseek":
                self.api_key = os.environ.get("DEEPSEEK_API_KEY", self.api_key)
            elif self.provider == "openrouter":
                # F-LUCY-OPENROUTER-PROVIDER (-8uh_KYt9F8, 2026-05-21).
                self.api_key = os.environ.get("OPENROUTER_API_KEY", self.api_key)
            elif self.provider == "gemini":
                # F-LUCY-GEMINI-PROVIDER (-JSHGYiAy8g, 2026-05-21).
                self.api_key = os.environ.get("GEMINI_API_KEY", self.api_key)
            if self.provider != "claude_cli":
                self._claude_session_id = None
            return
        try:
            det = _detect_provider()
        except Exception:
            det = None
        if det:
            new_provider, new_model, new_key = det
            if new_provider != self.provider or new_model != self.model:
                self.provider = new_provider
                self.model = new_model
                self.api_key = new_key
                if new_provider == "claude_cli":
                    self._claude_binary = new_key
                    self._claude_session_id = None
                else:
                    self._claude_binary = None
                    self._claude_session_id = None
                # Chat goes through ProviderRouter — no client rebuild needed.
                self._client = None
        # Defense-in-depth: a non-Claude turn must never --resume a Claude session.
        if self.provider != "claude_cli":
            self._claude_session_id = None

    def _create_completion(self, **kw):
        """Provider-agnostic chat completion via ProviderRouter.dispatch_chat.

        F-LUCY-CHAT-VIA-PROVIDER-ROUTER (cs9PZGiubRI, 2026-05-21): replaces
        the previous self._client.chat.completions.create() call which
        hard-coded the OpenAI SDK against (potentially wrong) base_urls.
        Now dispatch routes to the four wired provider classes — anthropic
        speaks /v1/messages, openai speaks /v1/chat/completions, deepseek
        speaks api.deepseek.com, ollama speaks localhost:11434/v1/. Each
        returns an OpenAI-shaped response so Lucy's chat loop is unchanged.

        Keeps the bounded-retry behaviour on transient transport errors so
        a single 'Stream reset' / 'connection reset' doesn't kill the turn."""
        import openai as _openai
        import time as _t
        from aibrain.core.provider_contract import dispatch_chat as _dispatch_chat

        # Pop our own args before forwarding to provider implementation.
        model = kw.pop("model", self.model)
        messages = kw.pop("messages", [])
        tools = kw.pop("tools", None)
        tool_choice = kw.pop("tool_choice", None)
        stream = kw.pop("stream", False)
        temperature = kw.pop("temperature", 0.7)
        max_tokens = kw.pop("max_tokens", 4096)

        _transient = tuple(t for t in (
            getattr(_openai, "APIConnectionError", None),
            getattr(_openai, "APITimeoutError", None),
            getattr(_openai, "InternalServerError", None),
        ) if isinstance(t, type))
        _markers = ("stream reset", "could not decode response body",
                    "connection reset", "connection aborted",
                    "peer closed connection", "incomplete read",
                    "remote end closed connection")
        _attempts = max(2, int(os.environ.get("LUCY_API_RETRY", "4")))
        last_exc: Exception | None = None
        for _i in range(_attempts):
            try:
                return _dispatch_chat(
                    provider=self.provider,
                    model=model,
                    messages=messages,
                    tools=tools,
                    tool_choice=tool_choice,
                    api_key=self.api_key,
                    stream=stream,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    **kw,
                )
            except Exception as _e:
                last_exc = _e
                _is_transient = (bool(_transient) and isinstance(_e, _transient)) \
                    or any(m in str(_e).lower() for m in _markers)
                if not _is_transient or _i == _attempts - 1:
                    raise
                _back = min(2.0 * (2 ** _i), 15.0)
                _log_tool(
                    f"transient API error ({type(_e).__name__}: "
                    f"{str(_e)[:80]}); retry {_i + 1}/{_attempts - 1} "
                    f"in {_back:.0f}s", level=2)
                _t.sleep(_back)
        if last_exc:
            raise last_exc

    def chat(self, user_input: str) -> str:
        # F-LUCY-DESTRUCTIVE-INTENT-HALT-1: prompt-level safety scan before
        # any LLM call or tool work. Catches destructive intent in the user
        # message; on match, asks for explicit y/yes within 30s, default-
        # deny on timeout. Sits UPSTREAM of _classify_bash_risk (which gates
        # the command once chosen). Two-layer defense: both must fail for a
        # destructive op to land.
        try:
            _intent_hit, _intent_label = _classify_destructive_intent(user_input)
        except Exception:
            _intent_hit, _intent_label = False, ""
        if _intent_hit and not os.environ.get("AIBRAIN_LUCY_AUTOCONFIRM"):
            try:
                _ok = _confirm_destructive_intent_locally(user_input, _intent_label)
            except Exception:
                _ok = False
            if not _ok:
                _refusal = (f"[safety] declined: destructive-intent pattern "
                            f"{_intent_label!r} matched in user prompt. "
                            f"No LLM call made, no tools invoked.")
                try:
                    self.history.append({"role": "user",     "content": user_input})
                    self.history.append({"role": "assistant", "content": _refusal})
                    _save_session(self.history, pending_tool_call=None)
                except Exception:
                    pass
                return _refusal

        # F-LUCY-CHECKPOINT-EVERY-TURN-1: save a turn-level checkpoint
        # before processing so that even if Lucy silently drops mid-stream,
        # the next session can auto-resume from this exact turn.
        _save_session(self.history, pending_tool_call={
            "call_id": f"turn_{int(time.time())}",
            "tool_name": "_chat_resume",
            "args": {"user_input": user_input},
            "issued_at": datetime.datetime.now().isoformat(),
            "user_input": user_input,
        })
        _hook_user = _run_hooks("UserPromptSubmit", {"prompt": user_input[:500]})
        if _hook_user:
            user_input = "[hook:UserPromptSubmit] " + _hook_user + chr(10) + user_input
        self._sync_provider_from_config()   # live: switch takes effect now, no restart
        memory_ctx = _memory_recall(user_input) if self._check_memory() else ""
        messages = self._build_messages(user_input, memory_ctx)

        _log_tool(f"→ {self.provider}/{self.model}  ({len(messages)} msg context)", level=2)

        # Start thinking spinner + type-ahead collector
        _stop_thinking = threading.Event()
        _stop_typeahead = threading.Event()
        _thinking_thread = threading.Thread(
            target=_thinking_spinner, args=(_stop_thinking,), daemon=True
        )
        _thinking_thread.start()
        _typeahead_thread = threading.Thread(
            target=_type_ahead_collector, args=(_stop_typeahead,), daemon=True
        )
        _typeahead_thread.start()

        full_response = ""
        try:
            # F-LUCY-CLAUDE-CLI-1: branch — subprocess claude binary vs OpenAI SDK
            if self.provider == "claude_cli" and self._claude_binary:
                messages_with_tools = list(messages)
                full_response = self._chat_via_claude_cli(
                    messages_with_tools, _stop_thinking, _stop_typeahead
                )
            else:
                messages_with_tools = list(messages)
                max_tool_rounds = int(os.environ.get("LUCY_MAX_TOOL_ROUNDS", "500"))
                # F-LUCY-NULL-GUARD-1: track consecutive null/negative tool results.
                # If the model tries to end the turn on a null result, inject a
                # continuation prompt. Enforces the NULL-GUARD RULE in SYSTEM_PROMPT.
                _consecutive_null_results = 0
                _NULL_MARKERS = (
                    "[not found]", "[error]", "no results", "no matches",
                    "doesn't exist", "no such file", "unverified",
                    "nothing found", "returned no",
                )
                # F-LUCY-SKILL-COMPILER-SELECTIVE-1: track tool usage for
                # selective skill capture at turn end.
                _tool_call_count = 0
                _had_side_effects = False
                _SIDE_EFFECT_TOOLS = frozenset({
                    "edit_file", "write_file", "apply_dispatch_blocks",
                    "create_task", "dispatch_deepseek_task", "spawn_subagent",
                    "batch_run", "notebook_edit", "complete_task",
                    "update_task", "review_task", "git_commit",
                })
                # F-TOOL-LOOP-GUARD-1 (2026-05-23, softened 2026-05-24):
                # silent tool-round counter. Original intent: catch the
                # "chains 4+ tool calls then bails at max_tool_rounds"
                # silent-dropout failure mode by injecting a nudge.
                #
                # REVISED behaviour (Decker 2026-05-24 — "this is not
                # suitable for her intended use"): the guard was killing
                # Lucy mid-legit-work. Normal multi-step recovery
                # (bash not found → grep_files → list_files → read_file)
                # hits 4+ rounds without streaming text BETWEEN tool
                # calls, and the guard's hard break aborted the chain.
                #
                # New shape:
                # - threshold 4 → 10 (real silent-dropout is usually
                #   ~max_tool_rounds rounds; 10 catches the genuine
                #   case without killing normal multi-step work).
                # - hard break REMOVED. The nudge fires once as a soft
                #   hint; the model is free to continue OR surface text.
                #   max_tool_rounds (the existing hard ceiling, separate)
                #   remains the real cap on runaway loops.
                _SILENT_TOOL_ROUND_LIMIT = 10
                _silent_tool_rounds = 0
                _last_response_len = 0
                _silent_nudge_injected = False
                for _tool_round in range(max_tool_rounds):
                    # F-LUCY-CTRL-B-INTERRUPT-1: check cancel before each tool round
                    if _CANCEL_AVAILABLE:
                        try:
                            _cancel_check()
                        except _CancelledError:
                            _stop_thinking.set()
                            return "[interrupted] Ctrl+B — returning to prompt"
                    # F-LUCY-STEER-1: mid-work steer — a line typed while Lucy
                    # is working is injected here as a high-priority redirect
                    # WITHOUT killing the loop (steer, not stop).
                    try:
                        while not _typing_queue.empty():
                            _steer = _typing_queue.get_nowait()
                            if _steer and _steer.strip():
                                messages_with_tools.append({
                                    "role": "user",
                                    "content": ("[STEER — live redirect from Decker, "
                                                "prioritise this over the prior instruction]: "
                                                + _steer.strip()),
                                })
                                _log_tool(f"steer injected: {_steer.strip()[:80]}", level=2)
                    except Exception:
                        pass
                    _resp = self._create_completion(
                        model=self.model,
                        messages=self._clean_messages(messages_with_tools),
                        tools=_LUCY_TOOLS if _BRIDGE_AVAILABLE else None,
                        tool_choice="auto" if _BRIDGE_AVAILABLE else None,
                        stream=False,
                    )
                    _msg = _resp.choices[0].message
                    # F-DSML-PARSER-DROPOUT-FIX-1: if native tool_calls is empty
                    # but the text contains DSML invoke markers, synthesise
                    # tool_calls from the DSML emission so DeepSeek's pseudo-XML
                    # tool-call format is honoured instead of silently dropped.
                    _dsml_synth_tcs = None
                    import re as _re_dsml
                    _dsml_marker_re = _re_dsml.compile(r'<[│｜|]*(?:DSML[│｜|]*)?(?:invoke|tool_calls)')
                    if (not _msg.tool_calls and _msg.content and
                            _dsml_marker_re.search(_msg.content)):
                        _dsml_invokes = _parse_dsml_tool_calls(_msg.content)
                        if _dsml_invokes:
                            import types as _types
                            import uuid as _uuid
                            _synth = []
                            for _i, _inv in enumerate(_dsml_invokes):
                                _fn = _types.SimpleNamespace(
                                    name=_inv["name"],
                                    arguments=json.dumps(_inv.get("args", {})),
                                )
                                _tc_obj = _types.SimpleNamespace(
                                    id=f"dsml_{_uuid.uuid4().hex[:8]}_{_i}",
                                    type="function",
                                    function=_fn,
                                )
                                _synth.append(_tc_obj)
                            _dsml_synth_tcs = _synth
                            _msg.tool_calls = _synth
                        else:
                            # No invokes parsed despite DSML markers; never silent-drop —
                            # surface stripped text or an explicit notice.
                            _stripped = _strip_dsml_markup(_msg.content).strip()
                            _msg.content = _stripped if _stripped else "[notice: DSML tool-call markup detected but no executable invocations found]"
                    if _msg.tool_calls:
                        if _msg.content:
                            _between = _strip_dsml_markup(_msg.content).strip()
                            if _between:
                                _stop_thinking.set()
                                time.sleep(0.05)
                                print(f"\n{_between}\n")
                        if _dsml_synth_tcs is not None:
                            # Plain-dict rendering for synthesised DSML tool_calls
                            # (SimpleNamespace objects don't serialise via model_dump).
                            messages_with_tools.append({
                                "role": "assistant",
                                "content": _strip_dsml_markup(_msg.content or "") or None,
                                "tool_calls": [
                                    {
                                        "id": _t.id,
                                        "type": "function",
                                        "function": {
                                            "name": _t.function.name,
                                            "arguments": _t.function.arguments,
                                        },
                                    }
                                    for _t in _dsml_synth_tcs
                                ],
                            })
                        else:
                            messages_with_tools.append(_msg.model_dump())
                        for _tc in _msg.tool_calls:
                            # F-LUCY-CTRL-B-INTERRUPT-1: check cancel before each tool invocation
                            if _CANCEL_AVAILABLE:
                                try:
                                    _cancel_check()
                                except _CancelledError:
                                    return "[interrupted] Ctrl+B — returning to prompt"
                            _targs = {}
                            if _tc.function.arguments:
                                try:
                                    _targs = json.loads(_tc.function.arguments)
                                except (json.JSONDecodeError, TypeError) as _argerr:
                                    _log_tool(f"[warn] malformed tool-call args for {_tc.function.name}: {_argerr} — continuing with empty args", level=1)
                            # F-LUCY-MID-TOOL-CALL-CRASH-RESUME-1: persist pending state BEFORE invoking
                            # the tool. If Lucy crashes during _execute_tool, next boot can surface this
                            # to the user as Resume / Skip / Abandon.
                            _save_session(self.history, pending_tool_call={
                                "call_id": _tc.id,
                                "tool_name": _tc.function.name,
                                "args": _targs,
                                "issued_at": datetime.datetime.now().isoformat(),
                                "user_input": user_input,
                            })
                            _hook_pre = _run_hooks("PreToolUse", {"tool_name": _tc.function.name, "tool_args": _targs})
                            _tresult = _execute_tool(_tc.function.name, _targs)
                            # Clear the pending marker as soon as the tool returns — the call completed.
                            _save_session(self.history, pending_tool_call=None)
                            _hook_post = _run_hooks("PostToolUse", {"tool_name": _tc.function.name, "tool_result": str(_tresult)[:500]})
                            if _hook_pre:
                                _tresult = "[hook:PreToolUse] " + _hook_pre + chr(10) + str(_tresult)
                            if _hook_post:
                                _tresult = str(_tresult) + chr(10) + "[hook:PostToolUse] " + _hook_post
                            if self._plan_mode and _tresult and "error" not in str(_tresult)[:7]:
                                self._plan_buffer.append(f"[{_tc.function.name}] {str(_tresult)[:200]}")
                            # F-LUCY-SKILL-COMPILER-SELECTIVE-1: track tool usage
                            _tool_call_count += 1
                            if _tc.function.name in _SIDE_EFFECT_TOOLS:
                                _had_side_effects = True
                            try:
                                from aibrain.core.skill_compiler import SkillCompiler
                                SkillCompiler.capture_safe(_tc.function.name, str(_tresult)[:500])
                            except Exception:
                                pass
                            messages_with_tools.append({
                                "role": "tool",
                                "tool_call_id": _tc.id,
                                # content MUST be str or list (provider API
                                # rejects dict -> "messages[N] content should
                                # be a string or a list"). Tools that return
                                # dicts (use_mcp_tool / command_hands MCP
                                # results) would otherwise crash the run.
                                "content": _tresult
                                if isinstance(_tresult, (str, list))
                                else str(_tresult),
                            })
                            # F-LUCY-NULL-GUARD-1: detect null/negative results
                            _null_str = str(_tresult).lower()
                            if any(m in _null_str for m in _NULL_MARKERS):
                                _consecutive_null_results += 1
                            else:
                                _consecutive_null_results = 0
                        # F-TOOL-LOOP-GUARD-1: at the END of a tool-only
                        # round, count whether any new text was streamed.
                        # If the response_len didn't grow, this is a
                        # silent round. After _SILENT_TOOL_ROUND_LIMIT
                        # consecutive silent rounds, inject a one-time
                        # nudge ("surface what you found"). If silence
                        # persists past the nudge, break out and surface
                        # an explicit error rather than maxing out
                        # max_tool_rounds in silence.
                        _curr_len = len(full_response or "")
                        if _curr_len <= _last_response_len:
                            _silent_tool_rounds += 1
                        else:
                            _silent_tool_rounds = 0
                        _last_response_len = _curr_len
                        if _silent_tool_rounds >= _SILENT_TOOL_ROUND_LIMIT:
                            if not _silent_nudge_injected:
                                _log_tool(
                                    f"tool-loop-guard: {_silent_tool_rounds} "
                                    f"silent tool rounds — injecting "
                                    f"surface-answer nudge", level=1)
                                messages_with_tools.append({
                                    "role": "system",
                                    "content": (
                                        "TOOL-LOOP-GUARD: you have chained "
                                        f"{_silent_tool_rounds} tool rounds "
                                        f"with no user-visible text. STOP "
                                        f"calling tools and write a direct "
                                        f"text answer summarising what the "
                                        f"tool results show. The user is "
                                        f"waiting in silence."
                                    ),
                                })
                                _silent_nudge_injected = True
                                # Reset counter so we don't re-fire the
                                # nudge every round. The nudge is a one-
                                # shot soft hint; the loop continues
                                # regardless. max_tool_rounds (the hard
                                # ceiling, separate) catches genuinely
                                # runaway loops.
                                _silent_tool_rounds = 0
                            # F-TOOL-LOOP-GUARD-1 softened (2026-05-24):
                            # the post-nudge hard break has been removed.
                            # Killing the loop killed legit multi-step
                            # recovery work (bash-not-found → grep_files
                            # → list_files → read_file). The nudge alone
                            # is enough as a soft signal.
                        continue
                    # F-LUCY-NULL-GUARD-1: if the model produced no tool calls
                    # but the most recent tool results were null/negative,
                    # inject a continuation prompt instead of breaking.
                    if _consecutive_null_results > 0:
                        _log_tool(
                            f"null-guard: {_consecutive_null_results} consecutive "
                            f"null result(s) — injecting continuation prompt", level=2)
                        messages_with_tools.append({
                            "role": "system",
                            "content": (
                                "NULL-GUARD: The last tool returned a null or negative "
                                "result (not found, error, no results, etc.). This is "
                                "VALID INFORMATION, not a stop signal. Determine the "
                                "corrective action and CONTINUE. If a task/file/search "
                                "returned 'not found', CREATE it instead of reporting "
                                "it missing. Never stop on a negative result."
                            ),
                        })
                        _consecutive_null_results = 0
                        continue
                    # No tool calls on this round — stream the final text response
                    _stop_thinking.set()
                    time.sleep(0.07)  # let spinner clear
                    stream = self._create_completion(
                        model=self.model,
                        messages=self._clean_messages(messages_with_tools),
                        stream=True,
                    )
                    # F-LUCY-DEEPSEEK-RC-1B: capture reasoning_content from stream
                    # for DeepSeek deepseek-reasoner multi-turn pass-back.
                    _rc_holder: dict = {}
                    # F-LUCY-DISPLAY-CLOBBER-FIX-1 (2026-05-24): wrap the
                    # streaming output in _streaming_output_context() so
                    # prompt_toolkit's patch_stdout (when active) prevents
                    # streamed tokens from clobbering the user's typed
                    # input buffer below. No-op fallback when PT is not
                    # active. The helper was defined but never consumed —
                    # this is the wire-in.
                    with _streaming_output_context():
                        full_response = _stream_wrapped(stream, _stop_thinking, out_meta=_rc_holder)
                    full_response = _strip_dsml_markup(full_response)
                    _last_reasoning_content = _rc_holder.get("reasoning_content")
                    # F-LUCY-DROPOUT-GUARD-1: detect empty/short responses
                    # that would look like a "dropout" to the user. If the
                    # model produced almost nothing, inject a continuation
                    # prompt and loop back rather than returning silence.
                    if not full_response or len(full_response.strip()) < 10:
                        _log_tool(
                            f"dropout-guard: response was {len(full_response)} chars "
                            f"— injecting continuation prompt", level=1)
                        messages_with_tools.append({
                            "role": "system",
                            "content": (
                                "DROPOUT-GUARD: Your last response was empty or too "
                                "short. You may have stopped mid-thought. Continue "
                                "from exactly where you left off. Do NOT restart — "
                                "pick up from the last thing you were doing."
                            ),
                        })
                        continue
                    break
                else:
                    _stop_thinking.set()
                    full_response = "[error] tool call loop exceeded 50 rounds"
                    print(f"\n{RED}{full_response}{RESET}")
        except _CancelledError:
            _stop_thinking.set()
            full_response = "[interrupted] Ctrl+B — returning to prompt"
            print(f"\n{ORANGE}{full_response}{RESET}")
        except Exception as e:
            _stop_thinking.set()
            full_response = f"[error] API call failed: {e}"
            print(f"\n{RED}{full_response}{RESET}")
        finally:
            _stop_typeahead.set()
            # F-LUCY-PASTE-FIX-3: wait for type-ahead collector to signal
            # it has fully exited before prompt_toolkit takes stdin. Timeout
            # increased from 1.0→5.0 to prevent stdin reader race during large
            # paste operations. The type-ahead collector must flush its paste
            # buffer and release msvcrt.getwch() before prompt_toolkit takes over.
            _typeahead_exited.wait(timeout=5.0)

        _print_separator()

        self.history.append({"role": "user", "content": user_input})
        # F-LUCY-DEEPSEEK-RC-1B: include reasoning_content on assistant turn so
        # DeepSeek deepseek-reasoner multi-turn does not 400 on turn 2+.
        _assistant_entry = {"role": "assistant", "content": full_response}
        try:
            if _last_reasoning_content:
                _assistant_entry["reasoning_content"] = _last_reasoning_content
        except NameError:
            pass
        self.history.append(_assistant_entry)

        # F-LUCY-TTS-IMPL-CHUNK-1: speak the response if TTS is enabled.
        # Fire-and-forget on a daemon thread — does NOT block the prompt.
        # Truncates internally for pyttsx3 backend stability.
        if _TTS_ENABLED and full_response and not full_response.startswith("[error]"):
            try:
                _tts_speak_background(full_response)
            except Exception:
                pass

        # Persist session — clear the turn-level checkpoint since we finished
        _save_session(self.history, pending_tool_call=None)

        # Always-on memory store
        if self._check_memory() and full_response and not full_response.startswith("[error]"):
            _memory_store(user_input, full_response)

        # Always-on SkillCompiler capture
        _capture_skill(user_input, full_response, self.cfg.get("active_project"),
                       tool_call_count=_tool_call_count,
                       had_side_effects=_had_side_effects)

        # Clear first-boot context after first successful exchange
        if self.first_boot_ctx:
            self.first_boot_ctx = None

        return full_response

    # -----------------------------------------------------------------------
    # Commands
    # -----------------------------------------------------------------------

    def cmd_help(self) -> None:
        """F-LUCY-HELP-COMPLETE-1 (2026-05-24): grouped command list
        covering all 21 wired slash commands (previously /help showed
        only 12 of them, hiding /stt /tts /save-skills /plan /queue /etc.)."""
        w = _term_width()
        print(f"\n{BLUE}{'─'*w}{RESET}")
        groups = [
            ("CORE", [
                ("/help",                          "show this list"),
                ("/version",                       "aibrain version + git HEAD"),
                ("/status",                        "active project goal state"),
                ("/quit  /exit",                   "disconnect"),
            ]),
            ("GOAL ENGINE", [
                ("/loop --project X --goal \"Y\" "
                 "--criteria \"A\" \"B\" ...",     "jack in: run autonomous goal loop"),
            ]),
            ("MEMORY + TASKS", [
                ("/memory <query>",                "search your memory"),
                ("/task <title>",                  "create a task in DeckerOps"),
                ("/tasks",                         "list pending tasks"),
                ("/complete <task_id>",            "complete a task you own"),
                ("/save-skills",                   "(no-op now — skills auto-capture per turn)"),
            ]),
            ("PROVIDER", [
                ("/switch [provider] [model]",     "swap provider (no args = menu)"),
                ("/model [model]",                 "change model only"),
                ("/providers",                     "list providers + active marker"),
                ("/pricing",                       "show per-provider USD/MTok rates"),
                ("/reload",                        "re-read config.json"),
            ]),
            ("PLAN MODE", [
                ("/plan <goal>",                   "enter plan mode (no execution)"),
                ("/exit-plan",                     "execute the queued plan"),
                ("/queue",                         "show queued plan steps"),
                ("/clear-queue",                   "drop queued plan steps"),
            ]),
            ("COMPUTER USE", [
                ("/computer-use <goal>",           "Playwright-driven UI automation"),
                ("/record-start  /record-stop",    "session capture for skill auth"),
            ]),
            ("SPEECH", [
                ("/stt push [N]",                  "push-to-talk for N seconds (default 5)"),
                ("/stt voice [name]",              "list mics / set voice (chunk 2+)"),
                ("/tts on|off|voice|backend",      "speak responses (default off)"),
            ]),
            ("COMMS", [
                ("/ping <message>",                "send Telegram DM to Decker"),
                ("/verbose [0|1|2]",               "background ops view (0=off 2=full)"),
            ]),
        ]
        for title, cmds in groups:
            print(f"  {YELLOW}{title}{RESET}")
            for cmd, desc in cmds:
                print(f"    {SKY_BLUE}{cmd:<40}{RESET}  {DIM}{desc}{RESET}")
            print()
        print(f"{BLUE}{'─'*w}{RESET}\n")

    def cmd_version(self) -> None:
        """F-LUCY-VERSION-COMMAND-1 (2026-05-24): print aibrain version
        + git HEAD commit + module file path so Decker can diagnose
        "Lucy behind HEAD" / restart-needed states without dropping to
        a shell. Mirrors the freshness check in scratch/lucy_health_check.py.
        """
        # aibrain package version (pyproject.toml)
        try:
            from importlib.metadata import version as _v
            ai_ver = _v("aibrain")
        except Exception:
            ai_ver = "(unknown — not pip-installed?)"
        # git HEAD if we're inside the source tree
        head_sha = "(no git)"
        head_time = ""
        try:
            import subprocess as _sp
            _repo = Path(__file__).resolve().parent.parent
            r1 = _sp.run(["git", "log", "-1", "--format=%h"],
                         cwd=str(_repo), capture_output=True, text=True, timeout=5)
            r2 = _sp.run(["git", "log", "-1", "--format=%ci"],
                         cwd=str(_repo), capture_output=True, text=True, timeout=5)
            if r1.returncode == 0:
                head_sha = r1.stdout.strip() or head_sha
                head_time = r2.stdout.strip() or ""
        except Exception:
            pass
        print(f"\n{YELLOW}aibrain version:{RESET}  {SKY_BLUE}{ai_ver}{RESET}")
        print(f"{YELLOW}HEAD commit:{RESET}      {SKY_BLUE}{head_sha}{RESET}"
              + (f"  ({DIM}{head_time}{RESET})" if head_time else ""))
        print(f"{YELLOW}module file:{RESET}      {DIM}{__file__}{RESET}")
        print(f"{YELLOW}provider:{RESET}         {SKY_BLUE}{self.provider}/{self.model}{RESET}")
        # Process start time so user can compare to HEAD
        try:
            import os as _os_v
            import time as _t_v
            import datetime as _dt_v
            try:
                # On POSIX we can stat /proc/self/stat or use psutil; for
                # broad compat just show wall-clock now and runtime hint.
                print(f"{YELLOW}now:{RESET}              {DIM}{_dt_v.datetime.now().isoformat(timespec='seconds')}{RESET}")
            except Exception:
                pass
        except Exception:
            pass
        print()

    def cmd_status(self) -> None:
        project = self.cfg.get("active_project")
        if not project:
            print(f"{SKY_BLUE}No active project. Use /loop --project X to start one.{RESET}\n")
            return
        if not LOOP_AVAILABLE:
            print(f"{RED}[error] GoalEngine not available.{RESET}\n")
            return
        try:
            ge = GoalEngine(project)
            state = ge.load()
            gap = ge.measure()
            desired = state.get("desired_state", {})
            criteria = desired.get("acceptance_criteria", [])
            progress = state.get("current_state", {}).get("progress", [])
            print(f"\n{YELLOW}Project:{RESET} {SKY_BLUE}{project}{RESET}")
            print(f"{YELLOW}Goal:{RESET}    {SKY_BLUE}{desired.get('goal', '(not set)')}{RESET}")
            print(f"{YELLOW}Gap:{RESET}     {SKY_BLUE}{gap:.3f}  {'✓ DONE' if ge.is_done() else 'in progress'}{RESET}")
            for i, c in enumerate(criteria):
                done = i < len(progress) and progress[i]
                mark = f"{YELLOW}[x]{RESET}" if done else f"{DIM}[ ]{RESET}"
                print(f"  {mark} {SKY_BLUE}{c}{RESET}")
            print()
        except Exception as e:
            print(f"{RED}[error] {e}{RESET}\n")

    def cmd_model(self, args: list[str] | None = None) -> None:
        """Pick a model for the CURRENT provider via numbered menu.

        F-LUCY-MODEL-COMMAND-1 (Decker 2026-05-22): /model is shorthand for
        /switch <current_provider> — shows that provider's model menu and
        applies the selection. Decker asked for /switch AND /model as peers.

        - ``/model``         (no args): show model menu for self.provider.
        - ``/model <mdl>``:  explicit swap to <mdl> on self.provider.
        """
        args = args or []
        if len(args) >= 1:
            # Explicit model arg — delegate to cmd_switch with current provider.
            self.cmd_switch([self.provider, args[0]])
            return
        # Bare /model — show the model menu for the current provider.
        self.cmd_switch([self.provider])

    def cmd_loop(self, args: list[str]) -> None:
        if not LOOP_AVAILABLE:
            print(f"{RED}[error] LucyLoop not available.{RESET}\n")
            return

        parser = argparse.ArgumentParser(prog="/loop", add_help=False)
        parser.add_argument("--project", required=True)
        parser.add_argument("--goal", default=None)
        parser.add_argument("--criteria", nargs="+", default=None)
        parser.add_argument("--max-iterations", type=int, default=50)

        try:
            opts = parser.parse_args(args)
        except SystemExit:
            print(f"{SKY_BLUE}Usage: /loop --project X --goal 'Y' --criteria 'A' 'B'{RESET}\n")
            return

        self.cfg["active_project"] = opts.project
        _save_config(self.cfg)

        print(f"\n{YELLOW}jacking in — project='{opts.project}' ...{RESET}\n")
        try:
            result = LucyLoop().run(
                project_id=opts.project,
                goal=opts.goal,
                acceptance_criteria=opts.criteria,
                max_iterations=opts.max_iterations,
            )
            print(f"{YELLOW}[loop]{RESET} {SKY_BLUE}stopped: {result.reason_stopped}{RESET}")
            print(f"{YELLOW}[loop]{RESET} {SKY_BLUE}iterations={result.iterations}  gap={result.final_gap:.3f}{RESET}")
            if result.artifacts_created:
                print(f"{YELLOW}[loop]{RESET} {SKY_BLUE}artifacts: {result.artifacts_created}{RESET}")
            if result.clarifications_needed:
                print(f"{YELLOW}[loop]{RESET} {SKY_BLUE}need: {result.clarifications_needed}{RESET}")
            _print_separator()
        except Exception as e:
            print(f"{RED}[error] LucyLoop: {e}{RESET}\n")

    def cmd_memory(self, args: list[str]) -> None:
        if not args:
            print(f"{SKY_BLUE}Usage: /memory <query>{RESET}\n")
            return
        query = " ".join(args)
        if not self._check_memory():
            print(f"{RED}[error] Memory offline.{RESET}\n")
            return
        result = _memory_recall(query, limit=5)
        if not result:
            print(f"{SKY_BLUE}Nothing found for: {query}{RESET}\n")
            return
        print(f"\n{YELLOW}memory search:{RESET} {SKY_BLUE}{query}{RESET}")
        for line in result.split("\n"):
            print(f"  {SKY_BLUE}{line}{RESET}")
        print()

    def cmd_task(self, args: list[str]) -> None:
        if not args:
            print(f"{SKY_BLUE}Usage: /task <title>{RESET}\n")
            return
        if not COMPANY_AVAILABLE:
            print(f"{RED}[error] Company system not available.{RESET}\n")
            return
        title = " ".join(args)
        try:
            task = _create_task(
                COMPANY_ID,
                title=title,
                description=f"Created from Lucy CLI by user.",
                assignee_agent_id=LUCY_AGENT_ID,
                priority="medium",
            )
            _checkout_task(task["id"], LUCY_AGENT_ID)
            print(f"\n{YELLOW}[task created]{RESET} {SKY_BLUE}{task['id']} — {title}{RESET}\n")
        except Exception as e:
            print(f"{RED}[error] {e}{RESET}\n")

    def cmd_tasks(self) -> None:
        if not COMPANY_AVAILABLE:
            print(f"{RED}[error] Company system not available.{RESET}\n")
            return
        try:
            tasks = _list_tasks(COMPANY_ID)
            pending = [t for t in tasks if t.get("status") in ("todo", "in_progress", "pending")]
            if not pending:
                print(f"{SKY_BLUE}No pending tasks.{RESET}\n")
                return
            print(f"\n{YELLOW}{len(pending)} pending tasks:{RESET}")
            for t in pending[:10]:
                pri  = t.get("priority", "?")
                tid  = t.get("id", "?")
                title = t.get("title", "")[:60]
                status = t.get("status", "?")
                print(f"  {SKY_BLUE}[{pri}] {status} — {tid} — {title}{RESET}")
            if len(pending) > 10:
                print(f"  {DIM}... +{len(pending) - 10} more{RESET}")
            print()
        except Exception as e:
            print(f"{RED}[error] {e}{RESET}\n")

    def cmd_complete(self, args: list[str]) -> None:
        """F-LUCY-FILES-COMPANY-TASKS-1: Lucy completes her own tasks."""
        if not args:
            print(f"{SKY_BLUE}Usage: /complete <task_id> [work_output]{RESET}\n")
            return
        if not COMPANY_AVAILABLE:
            print(f"{RED}[error] Company system not available.{RESET}\n")
            return
        task_id = args[0]
        work_output = " ".join(args[1:]) if len(args) > 1 else "Completed from Lucy CLI."
        try:
            _checkout_task(task_id, LUCY_AGENT_ID)
            result = _complete_task(task_id, work_output=work_output)
            status = result.get("status", "?")
            print(f"\n{YELLOW}[task {status}]{RESET} {SKY_BLUE}{task_id}{RESET}\n")
        except Exception as e:
            print(f"{RED}[error] {e}{RESET}\n")

    def onboarding_flow(self) -> None:
        """F-FIRST-BOOT-UX-1: guided first-boot setup for new users."""
        print()
        print(f"{YELLOW}{chr(9552)*60}{RESET}")
        print(f"{SKY_BLUE}Lucy — AI Agent for the Post-Keyboard Era{RESET}")
        print(f"{YELLOW}{chr(9552)*60}{RESET}")
        print()
        print("I drive your browser, fill forms, and complete tasks.")
        print("Commands: /plan <goal>, /computer-use <goal>, /queue, /exit-plan")
        print("Type /help at any time for the full command list.")
        print()
        print("Setting up your workspace...")
        for d in ["~/.aibrain/goals", "~/.aibrain/specs", "~/.aibrain/recordings"]:
            Path(os.path.expanduser(d)).mkdir(parents=True, exist_ok=True)
        print("Workspace ready.")
        print()
        print(f"{DIM}Tip: Say 'open indeed.com and search for cybersecurity jobs'{RESET}")
        print(f"{DIM}or 'help me write a cover letter for this job posting'{RESET}")
        print()

    def cmd_queue(self) -> None:
        """F-LUCY-INPUT-QUEUE-1."""
        pending = []
        while not _typing_queue.empty():
            try:
                pending.append(_typing_queue.get_nowait())
            except queue.Empty:
                break
        if not pending:
            print(f"{SKY_BLUE}Queue empty.{RESET}")
            return
        print(f"{YELLOW}{len(pending)} queued messages:{RESET}")
        for i, msg in enumerate(pending, 1):
            preview = msg[:80].replace(chr(10), chr(32))
            print(f"  {SKY_BLUE}[{i}]{RESET} {preview}...")
        for msg in pending:
            _typing_queue.put(msg)
        print()

    def cmd_clear_queue(self) -> None:
        """F-LUCY-INPUT-QUEUE-1."""
        count = 0
        while not _typing_queue.empty():
            try:
                _typing_queue.get_nowait()
                count += 1
            except queue.Empty:
                break
        print(f"{YELLOW}Cleared {count} queued messages.{RESET}")
        print()

    def cmd_plan(self, args: list[str]) -> None:
        """F-LUCY-PLAN-MODE-1."""
        self._plan_mode = True
        self._plan_buffer = []
        goal = " ".join(args) if args else "current task"
        print(f"{YELLOW}[plan mode ON]{RESET} Goal: {goal}")
        print(f"{DIM}Describe your plan. /exit-plan to execute.{RESET}")
        self.chat(f"[PLAN MODE] Produce a structured plan for: {goal}. Numbered steps with rationale. No execution.")

    def cmd_exit_plan(self, args: list[str]) -> None:
        """F-LUCY-PLAN-MODE-1."""
        if not self._plan_mode:
            print(f"{RED}Not in plan mode.{RESET}")
            return
        self._plan_mode = False
        plan_text = chr(10).join(self._plan_buffer) if self._plan_buffer else "(empty plan)"
        print(f"{YELLOW}[plan mode OFF]{RESET} Executing {len(self._plan_buffer)} plan steps.")
        self.chat(f"[EXECUTE PLAN] Decker approved. Execute this plan: {plan_text}")

    def computer_use_loop(self, goal: str, max_steps: int = 10) -> str:
        """F-LUCY-COMPUTER-USE-AGENTIC-LOOP-1: orchestrate OS-level task completion.
        
        Chains screenshot->analyze->act cycles until goal reached or max_steps.
        Each cycle: (1) screenshot, (2) LLM analyzes + plans next action,
        (3) execute action via primitives, (4) verify with follow-up screenshot.
        Returns summary of actions taken + final state.
        """
        steps = []
        for i in range(max_steps):
            # Step 1: Capture current screen state
            try:
                import pyautogui, io, base64
                img = pyautogui.screenshot()
                buf = io.BytesIO()
                img.save(buf, format='PNG', optimize=True)
                screen_b64 = base64.b64encode(buf.getvalue()).decode()[:2000]
            except Exception as e:
                return f'[computer_use] screenshot failed at step {i}: {e}'
            
            # Step 2: Ask LLM to analyze screen + plan next action
            prompt = (
                f'[COMPUTER-USE step {i+1}/{max_steps}] Goal: {goal}. '
                f'Actions taken so far: {steps}. '
                f'Screen state (base64 PNG, first 2000 chars): {screen_b64}. '
                f'Analyze the screen and decide the next action. '
                f'Respond with JSON: {{"action": "click"|"type"|"scroll"|"hotkey"|"wait"|"done", '
                f'"target": "description of what to click/type", '
                f'"params": {{"x": int, "y": int, "text": str, "keys": [str], "clicks": int}}, '
                f'"reasoning": "why this action"}}. '
                f'If goal is achieved, respond {{"action": "done", "summary": "what was accomplished"}}.'
            )
            
            result = self.chat(prompt)
            # Parse LLM response for JSON action
            import json as _j, re as _re
            action_json = _re.search(r'\{[^{}]*"action"[^{}]*\}', str(result))
            if not action_json:
                steps.append(f'step{i}: LLM returned no valid action JSON')
                continue
            
            try:
                action = _j.loads(action_json.group(0))
            except Exception:
                steps.append(f'step{i}: invalid JSON from LLM')
                continue
            
            if action.get('action') == 'done':
                steps.append(f'step{i}: DONE - {action.get("summary", "completed")}')
                return chr(10).join(steps)
            
            # Step 3: Execute the action via primitives
            act = action['action']
            params = action.get('params', {})
            try:
                if act == 'click':
                    pyautogui.click(params.get('x', 500), params.get('y', 500))
                    steps.append(f'step{i}: clicked ({params.get("x")}, {params.get("y")})')
                elif act == 'type':
                    pyautogui.typewrite(params.get('text', ''), interval=0.05)
                    steps.append(f'step{i}: typed {len(params.get("text",""))} chars')
                elif act == 'scroll':
                    pyautogui.scroll(params.get('clicks', 3))
                    steps.append(f'step{i}: scrolled {params.get("clicks",3)}')
                elif act == 'hotkey':
                    pyautogui.hotkey(*params.get('keys', []))
                    steps.append(f'step{i}: hotkey {"+".join(params.get("keys",[]))}')
                elif act == 'wait':
                    import time as _t; _t.sleep(params.get('seconds', 2))
                    steps.append(f'step{i}: waited {params.get("seconds",2)}s')
                else:
                    steps.append(f'step{i}: unknown action {act}')
            except Exception as e2:
                steps.append(f'step{i}: action {act} failed: {e2}')
        
        return chr(10).join(steps) + chr(10) + f'[computer_use] max steps ({max_steps}) reached'

    def cmd_computer_use(self, args: list[str]) -> None:
        """F-LUCY-COMPUTER-USE-AGENTIC-LOOP-1: /computer-use <goal> command."""
        goal = ' '.join(args) if args else 'navigate to google.com'
        print(f'{YELLOW}[computer-use] Goal: {goal}{RESET}')
        print(f'{DIM}Starting orchestration loop...{RESET}')
        result = self.computer_use_loop(goal)
        print(result)

    def cmd_recording_start(self) -> None:
        """F-SCREEN-RECORDING-1: start screen recording."""
        self._recording = True
        self._frames = []
        print(f"{YELLOW}[recording ON]{RESET} Frames will be captured each tool call.")
        import threading, time as _t
        def _capture_loop():
            while self._recording:
                try:
                    import pyautogui, io
                    img = pyautogui.screenshot()
                    buf = io.BytesIO(); img.save(buf, format='PNG')
                    self._frames.append((_t.monotonic(), buf.getvalue()))
                except Exception:
                    pass
                _t.sleep(2)
        t = threading.Thread(target=_capture_loop, daemon=True)
        t.start()

    def cmd_recording_stop(self) -> None:
        """F-SCREEN-RECORDING-1: stop and save recording."""
        self._recording = False
        if not self._frames:
            print(f"{RED}No frames captured.{RESET}")
            return
        import json, os, time
        out = os.path.expanduser(f"~/.aibrain/recordings/session_{int(time.time())}")
        os.makedirs(out, exist_ok=True)
        for i, (ts, data) in enumerate(self._frames):
            with open(f"{out}/frame_{i:04d}.png", "wb") as f:
                f.write(data)
        with open(f"{out}/timeline.json", "w") as f:
            json.dump([{"frame": i, "timestamp": ts} for i, (ts, _) in enumerate(self._frames)], f)
        print(f"{YELLOW}[recording saved]{RESET} {len(self._frames)} frames to {out}")
        self._frames = []

    def cmd_ping(self, args: list[str]) -> None:
        if not args:
            print(f"{SKY_BLUE}Usage: /ping <message>{RESET}\n")
            return
        msg = " ".join(args)
        full_msg = f"[Lucy] {msg}"
        if _send_telegram(full_msg):
            print(f"{SKY_BLUE}sent.{RESET}\n")
        else:
            print(f"{RED}[error] Telegram send failed. Check TELEGRAM_TOKEN.{RESET}\n")

    def cmd_verbose(self, args: list[str]) -> None:
        global _VERBOSE
        labels = {0: "silent (clean chat)", 1: "glass (tool calls)", 2: "transparent (full detail)"}
        if not args:
            print(f"{SKY_BLUE}verbose: level {_VERBOSE} — {labels.get(_VERBOSE, '?')}{RESET}\n")
            print(f"  {DIM}0 = clean chat only{RESET}")
            print(f"  {DIM}1 = glass: show memory recalls, skill captures{RESET}")
            print(f"  {DIM}2 = transparent: full background detail{RESET}\n")
            return
        try:
            level = int(args[0])
            if level not in (0, 1, 2):
                raise ValueError
            _VERBOSE = level
            self.cfg["verbose_level"] = level
            _save_config(self.cfg)
            label = labels[level]
            print(f"{SKY_BLUE}verbose → {level} ({label}){RESET}\n")
        except ValueError:
            print(f"{RED}[error] usage: /verbose 0|1|2{RESET}\n")

    def _rebuild_client(self) -> None:
        """F-LUCY-HOT-RELOAD-CONFIG-1 + F-LUCY-CHAT-VIA-PROVIDER-ROUTER
        (cs9PZGiubRI, 2026-05-21): no longer builds an openai.OpenAI client
        with per-provider base_url swapping (that was the structural bug).
        Chat dispatches via ProviderRouter.dispatch_chat which picks the
        right backend each call. This method now only manages claude_cli
        binary handle vs api-key flavoured providers, and keeps _claude_session_id
        cleared so the new provider gets a fresh conversation."""
        if self.provider == "claude_cli":
            self._claude_binary = self.api_key
            self._client = None
            return
        # Non-claude_cli: chat path uses ProviderRouter.dispatch_chat.
        # Clear the legacy SDK client and any stale Claude session id so
        # the next chat() turn dispatches fresh against the new provider.
        self._client = None
        self._claude_binary = None
        self._claude_session_id = None

    # ── Provider registry — canonical list of the 7 text providers Lucy
    # supports. Source of truth for /switch validation, /providers listing.
    # Kept in sync with main()'s _DEFAULT_MODELS (CLI --provider flag).
    # F-LUCY-SWITCH-COMMAND-AUDIT (t77lg0UsI-E, 2026-05-22).
    _PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
        "deepseek":   {"model": "deepseek-v4-pro",           "env": "DEEPSEEK_API_KEY"},
        "openai":     {"model": "gpt-4o",                    "env": "OPENAI_API_KEY"},
        "claude_cli": {"model": "claude-opus-4-7",           "env": "(subscription)"},
        "ollama":     {"model": "llama3.2:3b",               "env": "(localhost:11434)"},
        "anthropic":  {"model": "claude-sonnet-4-6",         "env": "ANTHROPIC_API_KEY"},
        "openrouter": {"model": "google/gemini-2.5-flash",   "env": "OPENROUTER_API_KEY"},
        "gemini":     {"model": "gemini-2.5-flash",          "env": "GEMINI_API_KEY"},
    }

    # F-LUCY-SWITCH-MENU-UX-1: per-provider model menu for /switch (and /switch <prov>).
    # Order: most-advanced/default first. /switch picker shows these as numbered options.
    _PROVIDER_MODELS: dict[str, list[str]] = {
        "deepseek":   ["deepseek-v4-pro", "deepseek-reasoner", "deepseek-chat"],
        "openai":     ["gpt-5.5", "gpt-5", "gpt-5-mini", "gpt-4o", "gpt-4o-mini", "o1-preview"],
        "claude_cli": ["claude-opus-4-7", "claude-sonnet-4-6", "claude-haiku-4-5"],
        "ollama":     ["llama3.2:3b", "llama3.1:8b"],
        "anthropic":  ["claude-opus-4-7", "claude-sonnet-4-6", "claude-haiku-4-5"],
        "openrouter": ["google/gemini-2.5-flash", "anthropic/claude-opus-4-7", "openai/gpt-4o"],
        "gemini":     ["gemini-2.5-pro", "gemini-2.5-flash"],
    }

    def cmd_switch(self, args: list[str] | None = None) -> None:
        """Switch provider mid-session. Two modes:

        - ``/switch`` (no args): auto-detect via _detect_provider() — legacy
          behavior, picks up env/config without rebooting.
        - ``/switch <provider> [model]``: explicit swap. Validates provider
          against the 7-provider registry, checks the env var (or claude CLI
          / ollama localhost), sets _explicit_provider=True so the
          config-watcher in _sync_provider_from_config does NOT silent-swap
          back, persists the new provider/model to ~/.aibrain/config.json,
          and rebuilds the client. Mirrors the --provider CLI flag's
          validation logic so the two paths behave identically.

        F-LUCY-SWITCH-COMMAND-AUDIT (t77lg0UsI-E, 2026-05-22).
        """
        args = args or []

        # F-LUCY-SWITCH-MENU-UX-1: numbered provider menu when no args (Decker
        # 2026-05-22). Bare /switch lists all providers; /switch <prov> lists
        # that provider's models; /switch <prov> <mdl> keeps existing explicit
        # swap. Numeric picks are interpreted as menu selections.
        if not args:
            provider_names = list(self._PROVIDER_DEFAULTS.keys())
            print()
            print(f"  {DIM}Pick a provider:{RESET}")
            for i, name in enumerate(provider_names, 1):
                info = self._PROVIDER_DEFAULTS[name]
                is_active = name == self.provider
                marker = f"{YELLOW}*{RESET}" if is_active else " "
                tag = f"  {YELLOW}[active]{RESET}" if is_active else ""
                colour = SKY_BLUE if is_active else ""
                reset = RESET if is_active else ""
                print(f"{marker} {i}) {colour}{name:<13}{info['model']:<28}{reset}{tag}")
            print()
            try:
                pick = input("  > ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                return
            if not pick.isdigit() or not (1 <= int(pick) <= len(provider_names)):
                print(f"{RED}[error] invalid selection.{RESET}\n")
                return
            args = [provider_names[int(pick) - 1]]
            # Fall through to single-arg handling below — shows the model menu.

        prov = args[0].lower()
        if prov not in self._PROVIDER_DEFAULTS:
            valid = ", ".join(sorted(self._PROVIDER_DEFAULTS.keys()))
            print(f"{RED}[error] unknown provider '{prov}'. Valid: {valid}{RESET}\n")
            return

        # F-LUCY-SWITCH-MENU-UX-1: model menu when only provider given.
        # F-LUCY-SWITCH-AUTO-DEFAULT-MODEL-1 (2026-05-24): skip the
        # interactive menu when single-model OR non-TTY (tests,
        # scripts, autonomous /goal runs). Pick the registry-default
        # model (not models[0] — these can differ). Caught by
        # test_switch_ollama_does_not_require_env_var hitting empty
        # stdin → invalid-selection → no switch.
        if len(args) == 1:
            models = self._PROVIDER_MODELS.get(prov, [self._PROVIDER_DEFAULTS[prov]["model"]])
            _no_tty = False
            try:
                _no_tty = not sys.stdin.isatty()
            except Exception:
                _no_tty = True
            if len(models) <= 1 or _no_tty:
                # Single-model provider OR non-TTY (tests, scripts,
                # autonomous /goal runs) — no menu, just use the
                # registry-default model so input() doesn't block on
                # empty stdin. Use PROVIDER_DEFAULTS (not models[0])
                # so the "preferred" model is picked, not "first in
                # the menu list" — these can differ (e.g. openai
                # menu lists gpt-5.5 first but default is gpt-4o).
                args = [prov, self._PROVIDER_DEFAULTS[prov]["model"]]
            else:
                print()
                print(f"  {DIM}Models for {prov}:{RESET}")
                for i, m in enumerate(models, 1):
                    is_active = (m == self.model and prov == self.provider)
                    marker = f"{YELLOW}*{RESET}" if is_active else " "
                    tag = f"  {YELLOW}[active]{RESET}" if is_active else ""
                    colour = SKY_BLUE if is_active else ""
                    reset = RESET if is_active else ""
                    print(f"{marker} {i}) {colour}{m}{reset}{tag}")
                print()
                try:
                    pick = input("  > ").strip()
                except (EOFError, KeyboardInterrupt):
                    print()
                    return
                if not pick.isdigit() or not (1 <= int(pick) <= len(models)):
                    print(f"{RED}[error] invalid selection.{RESET}\n")
                    return
                args = [prov, models[int(pick) - 1]]

        # Resolve model — explicit arg wins, else provider default
        mdl = args[1] if len(args) > 1 else self._PROVIDER_DEFAULTS[prov]["model"]

        # Resolve API key — same validation as --provider CLI flag
        if prov == "claude_cli":
            key = _detect_claude_cli_binary()
            if not key:
                print(f"{RED}[error] /switch claude_cli requires the `claude` "
                      f"CLI on PATH (binary not found).{RESET}\n")
                return
        elif prov == "ollama":
            key = "ollama-local"
        else:
            env_var = self._PROVIDER_DEFAULTS[prov]["env"]
            key = os.environ.get(env_var)
            if not key:
                print(f"{RED}[error] /switch {prov} requires {env_var} to be "
                      f"set in your environment or ~/.decker_env.{RESET}\n")
                return

        # Apply — mark explicit so _sync_provider_from_config doesn't undo it
        self.provider = prov
        self.model = mdl
        self.api_key = key
        self._explicit_provider = True
        self.cfg["default_provider"] = prov
        self.cfg["default_model"] = mdl
        _save_config(self.cfg)
        self._rebuild_client()
        print(f"{SKY_BLUE}switched — {prov} / {mdl} (no restart needed){RESET}\n")

    def cmd_providers(self) -> None:
        """List all 7 text providers with default model + env var requirement.
        Marks the currently active provider with a ``*`` prefix and an
        ``[active]`` suffix. Reads from the in-class _PROVIDER_DEFAULTS
        registry (source of truth).

        F-LUCY-SWITCH-COMMAND-AUDIT (t77lg0UsI-E, 2026-05-22).
        """
        print()
        print(f"  {DIM}{'PROVIDER':<13}{'DEFAULT MODEL':<28}{'ENV VAR':<22}{RESET}")
        for name in self._PROVIDER_DEFAULTS:
            info = self._PROVIDER_DEFAULTS[name]
            is_active = name == self.provider
            marker = f"{YELLOW}*{RESET}" if is_active else " "
            tag = f"  {YELLOW}[active]{RESET}" if is_active else ""
            colour = SKY_BLUE if is_active else ""
            reset = RESET if is_active else ""
            print(f"{marker} {colour}{name:<13}{info['model']:<28}{info['env']:<22}{reset}{tag}")
        print()

    def cmd_pricing(self) -> None:
        """Show per-provider per-model pricing in USD/MTok (prompt, completion).
        Reads from aibrain.core.provider_pricing.PRICING. Highlights the
        currently active provider+model in yellow.

        F-LUCY-SWITCH-COMMAND-AUDIT (t77lg0UsI-E, 2026-05-22).
        """
        try:
            from aibrain.core.provider_pricing import PRICING
        except Exception as e:
            print(f"{RED}[error] provider_pricing unavailable: {e}{RESET}\n")
            return

        print()
        print(f"  {DIM}Per-MTok USD rates (prompt / completion){RESET}")
        print(f"  {DIM}{'PROVIDER':<13}{'MODEL':<30}{'PROMPT':>10}{'COMPL':>10}{RESET}")
        any_row = False
        for prov_name in self._PROVIDER_DEFAULTS:
            rates = PRICING.get(prov_name)
            if rates is None:
                # openrouter / claude_cli — no static rates
                active = prov_name == self.provider
                marker = f"{YELLOW}*{RESET}" if active else " "
                colour = YELLOW if active else DIM
                reset = RESET
                note = "(subscription / variable)"
                print(f"{marker} {colour}{prov_name:<13}{note:<30}{'':>10}{'':>10}{reset}")
                any_row = True
                continue
            for model, (prompt_rate, compl_rate) in rates.items():
                if model == "_default":
                    label = "(local, $0)"
                else:
                    label = model
                active = (prov_name == self.provider and
                          (model == self.model or self.model.startswith(model)))
                marker = f"{YELLOW}*{RESET}" if active else " "
                colour = YELLOW if active else ""
                reset = RESET if active else ""
                print(f"{marker} {colour}{prov_name:<13}{label:<30}"
                      f"${prompt_rate:>8.2f}${compl_rate:>8.2f}{reset}")
                any_row = True
        if not any_row:
            print(f"  {DIM}(no pricing data available){RESET}")
        print()

    def cmd_reload(self) -> None:
        """F-LUCY-HOT-RELOAD-CONFIG-1: re-read ~/.aibrain/config.json from disk
        and rebuild the client if the provider/model changed. Use this when
        you've edited config.json externally (e.g. via lucy_switch.py) and
        want the running Lucy to pick up the change without /quit + re-launch.
        """
        prev_provider, prev_model = self.provider, self.model
        self.cfg = _load_config()
        new_provider = self.cfg.get("default_provider", prev_provider)
        new_model = self.cfg.get("default_model", prev_model)
        if new_provider != prev_provider or new_model != prev_model:
            # Provider/model actually changed — re-detect API key for the new provider
            detected = _detect_provider()
            if detected:
                self.provider, self.model, self.api_key = detected
                self._rebuild_client()
                print(f"{SKY_BLUE}reload — {self.provider} / {self.model} (was {prev_provider} / {prev_model}){RESET}\n")
                return
            print(f"{RED}[error] config wants {new_provider}/{new_model} but no API key found{RESET}\n")
            return
        print(f"{DIM}reload — config unchanged ({self.provider}/{self.model}){RESET}\n")

    def cmd_tts(self, args: list) -> None:
        """F-LUCY-TTS-IMPL-CHUNK-1: /tts subcommands.

        /tts                  show status
        /tts on               enable speech of every assistant response
        /tts off              disable
        /tts voice [name]     list available voices, or set by name substring
        /tts backend <name>   pyttsx3 (default) | openai (chunk 2) | piper (chunk 2)
        """
        global _TTS_ENABLED, _TTS_VOICE, _TTS_BACKEND
        sub = (args[0].lower() if args else "")
        if not sub or sub == "status":
            state = "on" if _TTS_ENABLED else "off"
            voice = _TTS_VOICE or "(default)"
            print(f"{ORANGE}tts:{RESET} {state}  backend={_TTS_BACKEND}  voice={voice}")
            return
        if sub == "on":
            _TTS_ENABLED = True
            print(f"{GREEN}[tts] on — Lucy will speak each response in the background.{RESET}")
            return
        if sub == "off":
            _TTS_ENABLED = False
            print(f"{DIM}[tts] off.{RESET}")
            return
        if sub == "voice":
            voices = _tts_list_pyttsx3_voices()
            if len(args) < 2:
                if not voices:
                    print(f"{DIM}[tts] no voices available (pyttsx3 missing or "
                          f"init failed). Install: pip install pyttsx3{RESET}")
                    return
                print(f"{ORANGE}available voices:{RESET}")
                for vid, vname in voices:
                    marker = " *" if _TTS_VOICE == vid else ""
                    print(f"  - {vname}  [{vid}]{marker}")
                return
            target = " ".join(args[1:]).lower()
            for vid, vname in voices:
                if target in vname.lower() or target == vid.lower():
                    _TTS_VOICE = vid
                    print(f"{GREEN}[tts] voice set: {vname}{RESET}")
                    # NOTE: applying _TTS_VOICE to the synth call is in
                    # the chunk-2 streaming refactor (pyttsx3 voice
                    # selection requires per-engine setProperty). For
                    # chunk 1 the selection is recorded but not yet
                    # applied — surfacing this honestly.
                    print(f"{DIM}[tts] (chunk 1 records the choice but the "
                          f"engine doesn't yet apply it — chunk 2 wires "
                          f"voice through to _speak_tool){RESET}")
                    return
            print(f"{RED}[tts] no voice matched {target!r} — try /tts voice "
                  f"to list.{RESET}")
            return
        if sub == "backend":
            if len(args) < 2:
                print(f"{ORANGE}backend:{RESET} {_TTS_BACKEND}  "
                      f"(pyttsx3 only in chunk 1; openai/piper in chunk 2)")
                return
            backend = args[1].lower()
            if backend == "pyttsx3":
                _TTS_BACKEND = "pyttsx3"
                print(f"{GREEN}[tts] backend: pyttsx3{RESET}")
            elif backend in ("openai", "piper"):
                print(f"{DIM}[tts] {backend} not implemented yet "
                      f"(chunk 2). Backend stays pyttsx3.{RESET}")
            else:
                print(f"{RED}[tts] unknown backend {backend!r}.{RESET}")
            return
        print(f"{SKY_BLUE}unknown /tts subcommand: {sub} — try /tts{RESET}")

    def cmd_stt(self, args: list) -> None:
        """F-LUCY-STT-IMPL-CHUNK-1: /stt subcommands.

        /stt              show status + subcommand list
        /stt push [N]     push-to-talk: record N seconds (default 5), transcribe, queue
        /stt on           continuous mode    (chunk 2 — not yet implemented)
        /stt off          stop continuous    (chunk 2)
        /stt mic [index]  set mic by index   (chunk 4)
        /stt wake on|off  wake word "Lucy"   (chunk 3)
        """
        sub = (args[0].lower() if args else "")
        if not sub or sub == "help":
            status = "ready" if _STT_MODEL is not None else (
                "uninitialised — first /stt push will load" if _STT_INIT_ERR is None
                else f"unavailable: {_STT_INIT_ERR}"
            )
            print(f"{ORANGE}stt status:{RESET} {status}")
            print(f"  /stt push [N]    push-to-talk, record N seconds (default 5)")
            print(f"  /stt on / off    continuous mode (chunk 2 — not yet)")
            print(f"  /stt mic [idx]   mic selector (chunk 4 — not yet)")
            print(f"  /stt wake on|off wake word 'Lucy' (chunk 3 — not yet)")
            return
        if sub == "push":
            if not _stt_init():
                print(f"{RED}[stt] {_STT_INIT_ERR}{RESET}")
                return
            try:
                duration = float(args[1]) if len(args) >= 2 else 5.0
            except ValueError:
                duration = 5.0
            print(f"{YELLOW}[stt] listening for {duration:.1f}s — speak now…{RESET}")
            try:
                text = _stt_capture_and_transcribe(duration_s=duration)
            except Exception as _exc:
                print(f"{RED}[stt] capture failed: {type(_exc).__name__}: "
                      f"{str(_exc)[:160]}{RESET}")
                return
            if not text:
                print(f"{DIM}[stt] no speech detected{RESET}")
                return
            print(f"{GREEN}[stt] heard:{RESET} {text}")
            # Push the transcript into the typing queue so it gets picked
            # up as the next user message — exactly as if Decker had typed
            # it. This sidesteps the chat() call path and lets the next
            # _read_input drain it.
            try:
                _typing_queue.put(text)
            except Exception:
                # Fallback: print the text and let Decker copy if queue
                # push failed for some reason.
                print(f"{DIM}[stt] queue push failed — copy the transcript "
                      f"above manually.{RESET}")
            return
        if sub in ("on", "off", "mic", "wake"):
            print(f"{DIM}[stt] '{sub}' not implemented yet "
                  f"(F-LUCY-STT-IMPL-CHUNK-1 ships push-only).{RESET}")
            return
        print(f"{SKY_BLUE}unknown /stt subcommand: {sub} — try /stt help{RESET}")

    def _flush_skills_on_exit(self) -> None:
        """F-LUCY-EXIT-SKILL-FLUSH-1 (2026-05-24 — REDUCED TO NO-OP):

        The original ask ("skill compiler runs at exit") is already
        satisfied by the in-line per-turn _capture_skill at line ~712.
        Each chat turn either captures or skips with REAL signals
        (actual tool_call_count + had_side_effects from the chat
        loop), and SkillCompiler.capture() auto-saves atomically per
        call (skill_compiler.py:341).

        The earlier history-rescan version (commits 996583f0+) was
        well-intentioned backstop but the heuristic over-included
        chat-explanation turns AND forced
        `had_side_effects=True` to bypass _capture_skill's gate, which
        also bypassed the SkillCompiler noise gate downstream. Result
        was 22 chat-discussion turns getting persisted as 'skills',
        polluting the catalog (caught by Decker 2026-05-24:
        'now we have bloat happening in the skills too').

        Net of this no-op: per-turn capture remains canonical, exit
        does nothing extra, no bloat path.
        """
        return

    def cmd_save_skills(self) -> None:
        """/save-skills — no-op (per F-LUCY-EXIT-SKILL-FLUSH-1 reduction).

        Per-turn _capture_skill already runs with real signals + the
        SkillCompiler auto-saves on each capture. There is nothing for
        a manual 'save' to do that the in-line path isn't already doing.
        Kept as a slash command so the dispatcher entry doesn't break;
        prints a one-liner explaining the design.
        """
        print(f"{DIM}/save-skills: nothing to do — skills capture per-turn "
              f"as-you-go. Catalog at ~/.aibrain/skills.json.{RESET}")

    def handle_command(self, raw: str) -> None:
        try:
            parts = shlex.split(raw)
        except ValueError:
            parts = raw.split()

        cmd = parts[0].lower() if parts else ""
        args = parts[1:]

        if cmd in ("/quit", "/exit"):
            # F-LUCY-EXIT-SUMMARY-1 (2026-05-24): print a one-line
            # session summary so the user can see what happened this
            # session before disconnect. Best-effort — never blocks
            # exit on a counting failure.
            try:
                self._flush_skills_on_exit()
            except Exception as _flush_err:
                print(f"{DIM}[flush warning] {type(_flush_err).__name__}: "
                      f"{_flush_err}{RESET}")
            _save_session(self.history)
            try:
                exchanges = len(self.history) // 2
                # Count skills compiled this session by name prefix
                # (best-effort; skills.json shape varies).
                try:
                    import json as _json_exit
                    sk_path = Path.home() / ".aibrain" / "skills.json"
                    _txt = sk_path.read_text(encoding="utf-8")
                    _rows = _json_exit.loads(_txt) if _txt.strip() else []
                    if isinstance(_rows, dict):
                        _rows = _rows.get("skills", [])
                    skill_count = len(_rows)
                except Exception:
                    skill_count = "?"
                print(f"{DIM}session summary: {exchanges} exchange(s), "
                      f"{skill_count} skill(s) in catalog.{RESET}")
            except Exception:
                pass
            print(f"{SKY_BLUE}jacking out.{RESET}")
            sys.exit(0)
        elif cmd == "/help":
            self.cmd_help()
        elif cmd == "/status":
            self.cmd_status()
        elif cmd == "/loop":
            self.cmd_loop(args)
        elif cmd == "/memory":
            self.cmd_memory(args)
        elif cmd == "/task":
            self.cmd_task(args)
        elif cmd == "/tasks":
            self.cmd_tasks()
        elif cmd == "/plan":
            self.cmd_plan(args)
        elif cmd == "/computer-use":
            self.cmd_computer_use(args)
        elif cmd == "/record-start":
            self.cmd_recording_start()
        elif cmd == "/record-stop":
            self.cmd_recording_stop()
        elif cmd == "/exit-plan":
            self.cmd_exit_plan(args)
        elif cmd == "/queue":
            self.cmd_queue()
        elif cmd == "/clear-queue":
            self.cmd_clear_queue()
        elif cmd == "/complete":
            self.cmd_complete(args)
        elif cmd == "/ping":
            self.cmd_ping(args)
        elif cmd == "/verbose":
            self.cmd_verbose(args)
        elif cmd == "/switch":
            self.cmd_switch(args)
        elif cmd == "/model":
            self.cmd_model(args)
        elif cmd == "/providers":
            self.cmd_providers()
        elif cmd == "/pricing":
            self.cmd_pricing()
        elif cmd == "/reload":
            self.cmd_reload()
        elif cmd == "/save-skills":
            self.cmd_save_skills()
        elif cmd == "/stt":
            self.cmd_stt(args)
        elif cmd == "/tts":
            self.cmd_tts(args)
        elif cmd == "/version":
            self.cmd_version()
        else:
            print(f"{SKY_BLUE}unknown: {cmd} — /help for commands.{RESET}\n")

    def run(self) -> None:
        w = _term_width()

        # F-LUCY-CLONE-BANNER-1 (2026-05-23): banner reflects LUCY_FLEET_ID so
        # specialist clones (pixel, scout, etc.) show their own name. Hardcoded
        # LUCY ascii kept verbatim for the default 'lucy' identity. For clones,
        # try pyfiglet (graceful fallback to a simple block header if missing).
        print(f"\n{BLUE}{'═'*w}{RESET}")
        if LUCY_FLEET_ID == "lucy":
            pad = max(0, (w - 38) // 2)
            sp = " " * pad
            print(f"{YELLOW}{sp}██╗     ██╗   ██╗ ██████╗██╗   ██╗{RESET}")
            print(f"{YELLOW}{sp}██║     ██║   ██║██╔════╝╚██╗ ██╔╝{RESET}")
            print(f"{YELLOW}{sp}██║     ██║   ██║██║      ╚████╔╝ {RESET}")
            print(f"{YELLOW}{sp}██║     ██║   ██║██║       ╚██╔╝  {RESET}")
            print(f"{YELLOW}{sp}███████╗╚██████╔╝╚██████╗   ██║   {RESET}")
            print(f"{YELLOW}{sp}╚══════╝ ╚═════╝  ╚═════╝   ╚═╝   {RESET}")
        else:
            _name_upper = LUCY_FLEET_ID.upper()
            _rendered_lines: list[str] = []
            try:
                import pyfiglet  # type: ignore
                _rendered_lines = pyfiglet.figlet_format(
                    _name_upper, font="ansi_shadow",
                ).rstrip("\n").splitlines()
            except Exception:
                # Fallback: just centered uppercase name in big-but-plain text.
                _rendered_lines = [_name_upper]
            # Center each line within the terminal width.
            for _ln in _rendered_lines:
                _pad = max(0, (w - len(_ln)) // 2)
                print(f"{YELLOW}{' ' * _pad}{_ln}{RESET}")
        print(f"{BLUE}{'═'*w}{RESET}")
        print(f"  {DIM}provider{RESET} : {self.provider} / {self.model}")

        # Memory check + startup recall
        mem_status = "connected" if self._check_memory() else "offline"
        print(f"  {DIM}memory  {RESET} : {mem_status}")
        print(f"  {DIM}skills  {RESET} : {_get_skill_count()} compiled")

        # Warn when aibrain.core is missing — loop/memory/task features degraded
        if not LOOP_AVAILABLE:
            print(f"  {DIM}features{RESET} : {YELLOW}memory and loop features unavailable — install aibrain for full functionality{RESET}")

        # Verbose indicator
        if _VERBOSE > 0:
            labels = {1: "glass", 2: "transparent"}
            print(f"  {DIM}verbose {RESET} : {labels.get(_VERBOSE, '?')} (level {_VERBOSE}) — /verbose to change")

        if self._check_memory():
            self.startup_ctx = _memory_recall_startup()

        # Session restore info
        if self._session_ts and self.history:
            try:
                ts = datetime.datetime.fromisoformat(self._session_ts)
                age = datetime.datetime.now() - ts
                age_str = f"{int(age.total_seconds() // 3600)}h ago" if age.total_seconds() > 3600 else f"{int(age.total_seconds() // 60)}m ago"
                session_link = _clickable(str(SESSION_FILE), "session")
                print(f"  {DIM}session {RESET} : {len(self.history)//2} exchanges restored ({age_str}) — {session_link}")
            except Exception:
                pass

        # First boot
        if self.first_boot_ctx:
            dossier_link = _clickable(str(DOSSIER_FILE), "~/.aibrain/lucy_dossier.md")
            print(f"  {YELLOW}[first boot]{RESET} {SKY_BLUE}loading {dossier_link} ...{RESET}")

        print(f"{BLUE}{'═'*w}{RESET}")
        print(f"  {SKY_BLUE}/help{RESET} for commands  |  {SKY_BLUE}/quit{RESET} to disconnect\n")

        # F-LUCY-MID-TOOL-CALL-CRASH-RESUME-1: prior session exited mid-tool-call.
        # Surface to the user so they can resume / skip / abandon rather than re-prompt.
        if self._pending_tool_call:
            _ptc = self._pending_tool_call
            _tname = _ptc.get("tool_name", "?")
            # F-LUCY-CHECKPOINT-EVERY-TURN-1: if the pending tool is a turn
            # checkpoint (not a real tool), auto-resume the chat silently.
            if _tname == "_chat_resume":
                _user_prev = str(_ptc.get("user_input", ""))[:200]
                _log_tool(f"auto-resuming from turn checkpoint: {_user_prev[:80]}", level=1)
                self._pending_tool_call = None
                _save_session(self.history, pending_tool_call=None)
                print(f"  {DIM}[auto-resuming previous turn]{RESET}")
                # Feed the user input back through chat()
                self.chat(_user_prev)
                # After auto-resume, continue to the normal prompt loop
            else:
                try:
                    _issued = datetime.datetime.fromisoformat(str(_ptc.get("issued_at", "")))
                    _age = datetime.datetime.now() - _issued
                    _age_str = f"{int(_age.total_seconds() // 60)}m" if _age.total_seconds() >= 60 else f"{int(_age.total_seconds())}s"
                except Exception:
                    _age_str = "?"
                _targs_preview = str(_ptc.get("args", {}))[:120]
                _user_prev = str(_ptc.get("user_input", ""))[:80]
                print(f"  {YELLOW}[resume]{RESET} last session exited mid-tool-call ({_age_str} ago)")
                print(f"    user input : {_user_prev}")
                print(f"    tool       : {_tname}({_targs_preview})")
                print(f"    {DIM}options : (r)esume / (s)kip / (a)bandon — Enter for skip{RESET}")
                try:
                    _choice = _read_input().strip().lower()
                except Exception:
                    _choice = ""
                if _choice in ("r", "resume"):
                    print(f"  {SKY_BLUE}→ resuming {_tname}...{RESET}")
                    try:
                        _resume_result = _execute_tool(_tname, dict(_ptc.get("args", {})))
                        self.history.append({"role": "user", "content": str(_ptc.get("user_input", ""))})
                        self.history.append({"role": "assistant", "content": f"[resumed tool {_tname}] {str(_resume_result)[:500]}"})
                        print(f"  {DIM}result :{RESET} {str(_resume_result)[:300]}\n")
                    except Exception as _re:
                        print(f"  {RED}resume failed: {_re}{RESET}\n")
                elif _choice in ("a", "abandon"):
                    print(f"  {DIM}→ abandoned, no synthetic message{RESET}\n")
                else:
                    # Default: skip
                    self.history.append({"role": "user", "content": str(_ptc.get("user_input", ""))})
                    self.history.append({"role": "assistant", "content": f"[skipped pending tool: {_tname} — recover manually if needed]"})
                    print(f"  {DIM}→ skipped, partial turn noted in history{RESET}\n")
                self._pending_tool_call = None
                _save_session(self.history, pending_tool_call=None)

        # F-FIRST-BOOT-UX-1: wiring — onboarding_flow() now actually runs on first boot
        if self.first_boot_ctx and not self.history:
            self.onboarding_flow()
            self.chat(
                "[SYSTEM: This is the user's very first session. Introduce yourself briefly, "
                "then suggest the top 3 most valuable things you'd recommend they try first — "
                "be specific and concrete. Ask what they want to work on. Keep it tight, no walls of text.]"
            )

        while True:
            try:
                # F-WATCHDOG-SUPERVISOR-1: heartbeat tick
                try:
                    from aibrain.core.watchdog import watchdog_heartbeat as lucy_heartbeat
                    lucy_heartbeat()
                except Exception:
                    pass
                # F-COMMS-WIRING-OPERATIONAL-1: heartbeat on prompt tick
                try:
                    import time as _htime
                    if not hasattr(self, '_last_hb') or _htime.monotonic() - self._last_hb > 30:
                        from aibrain.core.agent_comms import FleetBus
                        _hbus = FleetBus(agent_id=LUCY_FLEET_ID, db_path=DB_PATH)
                        _hbus.publish(f'fleet.heartbeat.{LUCY_FLEET_ID}', {'status': 'alive'})
                        self._last_hb = _htime.monotonic()
                except Exception:
                    pass
                # F-COMMS-WIRING-1 / F-LUCY-INBOX-POLL-ASYNC-1: in-loop poll
                # is now handled by the background daemon thread spawned in
                # __init__ (_start_inbox_poller). Kept here as a belt-and-braces
                # second poll on prompt cycles, deduped by self._seen_msg_ids
                # so we never double-handle.
                try:
                    from aibrain.core.agent_comms import FleetBus
                    _fleet = FleetBus(agent_id=LUCY_FLEET_ID, db_path=DB_PATH)
                    _msgs = _fleet.poll_inbox()
                    for _m in _msgs[:3]:
                        _mid = _m.get("id") or ""
                        if _mid and _mid in self._seen_msg_ids:
                            continue
                        if _mid:
                            self._seen_msg_ids.add(_mid)
                        _src = _m.get("source", "?").replace("agent://", "")
                        _typ = _m.get("type", "?")
                        _subj = _m.get("subject", "")
                        banner = f"[FLEET from {_src}] {_typ}: {_subj}"
                        print(banner)
                        self._handle_inbox_message(_m)
                except Exception:
                    pass
                # F-LUCY-FLEET-AUTO-RESPONSE-1: drain pending fleet messages
                # before prompting Decker. Delegates to shared handler also
                # called by the background poller thread.
                if self._pending_fleet_msgs:
                    try:
                        self._process_pending_fleet_msgs()
                    except Exception:
                        pass
                    continue

                # Check for type-ahead input before showing prompt.
                # F-LUCY-QUEUE-DRAIN-1: drain ALL queued items (multi-line paste arrives
                # as N items; pulling only 1 leaves stragglers that interleave with the
                # next user input). Join with newlines to preserve paste semantics.
                _queued_items = []
                while True:
                    try:
                        _queued_items.append(_typing_queue.get_nowait())
                    except queue.Empty:
                        break
                if _queued_items:
                    user_input = "\n".join(_queued_items)
                    if len(_queued_items) == 1:
                        print(f"{DIM}[processing queued input]{RESET}")
                    else:
                        print(f"{DIM}[processing {len(_queued_items)} queued lines]{RESET}")
                else:
                    user_input = _read_input().strip()
            except (KeyboardInterrupt, EOFError):
                _save_session(self.history)
                print(f"\n{SKY_BLUE}jacking out.{RESET}")
                sys.exit(0)

            if not user_input:
                continue
            # F-LUCY-SAFESTOP-1: raw-key listener active only during the
            # processing span (Esc/Ctrl+B mid-loop); disarmed before the next
            # _read_input so prompt_toolkit owns the TTY (no two-reader clash).
            _raw_key_listener.arm()
            try:
                if user_input.startswith("/"):
                    self.handle_command(user_input)
                else:
                    self.chat(user_input)
            finally:
                _raw_key_listener.disarm()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    global _VERBOSE
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    parser = argparse.ArgumentParser(
        prog="lucy",
        description="Lucy — autonomous agent powered by AIBrain.",
    )
    parser.add_argument("--version", action="version", version="Lucy 1.1.0")
    parser.add_argument("--reset-session", action="store_true",
                        help="Clear saved conversation history and start fresh")
    parser.add_argument("--reset-boot", action="store_true",
                        help="Re-run first boot orientation on next launch")
    parser.add_argument(
        "--verbose", type=int, choices=[0, 1, 2], default=None, metavar="N",
        help="Verbosity: 0=off, 1=glass (tool ops), 2=transparent (full detail)",
    )
    # F-LUCY-PROVIDER-CLI-FLAG (z56zCvBPCJA, 2026-05-21): one-line provider
    # switch. --provider overrides config.json for THIS launch only;
    # LucyAgent.__init__ sets _explicit_provider so config-watcher does not
    # silent-swap. --model is optional — falls back to a sensible default
    # per provider.
    parser.add_argument(
        "--provider", type=str, default=None,
        choices=["claude_cli", "openai", "deepseek", "ollama",
                 "anthropic", "openrouter", "gemini"],
        metavar="NAME",
        help=(
            "Override provider for this launch (one-line switch). "
            "Examples: lucy --provider openrouter --model google/gemini-2.5-flash | "
            "lucy --provider gemini --model gemini-2.5-flash | "
            "lucy --provider claude_cli | "
            "lucy --provider ollama --model llama3.2:3b"
        ),
    )
    parser.add_argument(
        "--model", type=str, default=None, metavar="ID",
        help=(
            "Override model id for this launch (e.g. google/gemini-2.5-flash, "
            "claude-sonnet-4-5, gpt-4o, llama3.2:3b). If --provider is set "
            "and --model is omitted, a sensible per-provider default is used."
        ),
    )
    # F-MORE-LUCYS-INTERACTIVE-LAUNCHER-1 (6xmQyrvpuL0, 2026-05-22): inject a
    # persona file into SYSTEM_PROMPT for the lifetime of this interactive
    # session. The launcher (launch_lucys.ps1) opens one wt.exe tab per
    # persona; each tab calls `lucy --persona-file <path>` so Decker can chat
    # with a content-writer-flavoured Lucy in one tab and a research-analyst
    # Lucy in another. Prepend (not replace) so core tooling rules stay live.
    parser.add_argument(
        "--persona-file", type=str, default=None, metavar="PATH",
        dest="persona_file",
        help=(
            "Prepend the contents of PATH to the SYSTEM_PROMPT for this "
            "session — turns a generic Lucy into a persona-flavoured Lucy. "
            "Example: lucy --provider claude_cli --persona-file "
            "C:/Users/sinde/decker_system/02_subagents/content_agent.md"
        ),
    )
    # F-LUCY-CLONE-AGENT-ID-1 (2026-05-23): clone Lucy as a new fleet identity.
    # Pass a friendly name (e.g. "pixel") and Lucy will:
    #   1. Look up ~/.aibrain/lucy_clones.json — if <name> is cached, reuse its
    #      minted company agent_id.
    #   2. Otherwise call hire_agent(COMPANY_ID, name=...) to mint a fresh
    #      company agent id and cache the mapping.
    #   3. Set FleetBus identity to <name> so heartbeats say agent://<name>,
    #      and set company-task identity to the minted id for create_task etc.
    # Pair with --persona-file to spawn specialised clones (Pixel = content,
    # etc.). Default unset = legacy Lucy on agent://lucy.
    parser.add_argument(
        "--agent-id", type=str, default=None, metavar="NAME",
        dest="agent_id",
        help=(
            "Clone Lucy as a new fleet identity NAME (e.g. 'pixel'). "
            "Mints + caches a company agent id on first use; reused thereafter. "
            "Heartbeats become agent://<NAME>; company-task ops use the minted id. "
            "Combine with --persona-file for specialised clones."
        ),
    )
    # F-LUCY-ASK-ONESHOT-1 (2026-05-23): headless one-shot mode. Lucy/Pixel/any
    # clone runs ONE turn against QUESTION, prints the answer, exits. No
    # interactive REPL, no banner, no spinner. Lets specialists be tasked from
    # scripts, cron, or other agents without a human typing into a TTY. Gap
    # surfaced during overnight content-portfolio test where Pixel's inbox
    # poller went dormant because no stdin kept her event loop alive.
    parser.add_argument(
        "--ask", type=str, default=None, metavar="QUESTION",
        dest="ask",
        help=(
            "One-shot headless mode: process QUESTION through one chat() turn, "
            "print the response to stdout, exit. No interactive loop. "
            "Example: pixel --ask 'draft a tweet about <topic>'"
        ),
    )
    # F-LUCY-ASK-FILE-1 (2026-05-23): --ask QUESTION via argv works for short
    # prompts but Windows shell quoting truncates multi-line / colon-heavy /
    # quote-heavy briefs. Confirmed during F-PIXEL-PORTFOLIO-VIA-ASK-1 (task
    # 88Wp7a3uBXM): all 5 portfolio --ask invocations received only the
    # CONTEXT header. The fix is to read the prompt from a file path instead
    # of argv. Use this for any prompt longer than a couple of sentences or
    # containing newlines / quotes.
    parser.add_argument(
        "--ask-file", type=str, default=None, metavar="PATH",
        dest="ask_file",
        help=(
            "One-shot headless mode reading PROMPT from a file (utf-8). "
            "Use this instead of --ask for multi-line or quote-heavy prompts "
            "that get mangled through shell argv. "
            "Example: pixel --ask-file C:/path/to/brief.md"
        ),
    )
    # F-LUCY-GOAL-AUTONOMOUS-1 (2026-05-23): drive LucyLoop on a named
    # GoalEngine project without an interactive REPL. The clone iterates
    # CLARIFY -> MEASURE -> EXECUTE -> VERIFY -> CAPTURE -> CHECK_IN until
    # the gap closes (or max-iter / cost ceiling fires). Prints final
    # LucyResult to stdout, exits 0. Companion to --ask/--ask-file for the
    # full headless-fleet operation set.
    parser.add_argument(
        "--goal", type=str, default=None, metavar="PROJECT_ID",
        dest="goal",
        help=(
            "Autonomous goal-pursuit mode: load GoalEngine(PROJECT_ID) and "
            "run LucyLoop until the gap closes. No interactive REPL. "
            "Example: pixel --goal lucy_loop_autonomous_2026_05_23"
        ),
    )
    parser.add_argument(
        "--max-iterations", type=int, default=200, dest="max_iterations",
        help="LucyLoop max iterations cap (pairs with --goal). 0=unbounded.",
    )
    args = parser.parse_args()

    # F-LUCY-CLONE-AGENT-ID-1: resolve --agent-id BEFORE any LucyAgent /
    # FleetBus is constructed so the module-level identity vars are correct
    # everywhere. Cache file: ~/.aibrain/lucy_clones.json maps friendly name
    # to minted company agent id so subsequent launches with the same name
    # reuse the same agent id.
    if getattr(args, "agent_id", None):
        clone_name = args.agent_id.strip()
        if clone_name and clone_name != "lucy":
            import json as _json
            cache_path = Path.home() / ".aibrain" / "lucy_clones.json"
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            try:
                clones = _json.loads(cache_path.read_text(encoding="utf-8"))
            except Exception:
                clones = {}
            company_aid = clones.get(clone_name)
            if not company_aid:
                # First launch with this clone name — mint via hire_agent.
                try:
                    from aibrain.core.companies import hire_agent
                    a = hire_agent(COMPANY_ID, clone_name, role="general",
                                   title=f"Lucy clone — {clone_name}")
                    company_aid = a["id"] if isinstance(a, dict) else a
                    clones[clone_name] = company_aid
                    cache_path.write_text(_json.dumps(clones, indent=2), encoding="utf-8")
                    print(f"[clone] minted company agent_id={company_aid} for '{clone_name}' (cached to {cache_path})")
                except Exception as _mint_err:
                    print(f"[clone] hire_agent failed: {_mint_err}. Falling back to friendly name as company id.")
                    company_aid = clone_name
            else:
                print(f"[clone] reusing cached company agent_id={company_aid} for '{clone_name}'")
            # Mutate module-level identity vars BEFORE LucyAgent.__init__.
            globals()["LUCY_FLEET_ID"] = clone_name
            globals()["LUCY_AGENT_ID"] = company_aid
            # Per-clone session file so pixel does NOT inherit lucy's history
            # (and vice versa). ~/.aibrain/<name>_session.json.
            globals()["SESSION_FILE"] = AIBRAIN_DIR / f"{clone_name}_session.json"
            print(f"[clone] session file: {globals()['SESSION_FILE']}")

    # F-MORE-LUCYS-INTERACTIVE-LAUNCHER-1: resolve --persona-file early and
    # mutate the module-global SYSTEM_PROMPT before LucyAgent.__init__ builds
    # any messages. Falls through silently when arg is absent (backwards
    # compat). Hard-fail on missing file so the launcher surfaces config
    # errors immediately rather than at first chat turn.
    if args.persona_file:
        from pathlib import Path as _Path
        _persona_path = _Path(args.persona_file)
        if not _persona_path.exists():
            print(
                f"{RED}[error] --persona-file not found: {args.persona_file}{RESET}",
                file=sys.stderr,
            )
            sys.exit(1)
        try:
            _persona_text = _persona_path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            print(
                f"{RED}[error] could not read --persona-file {args.persona_file}: {e}{RESET}",
                file=sys.stderr,
            )
            sys.exit(1)
        global SYSTEM_PROMPT
        SYSTEM_PROMPT = (
            f"# PERSONA OVERLAY ({_persona_path.name})\n\n"
            f"{_persona_text}\n\n"
            f"# END PERSONA OVERLAY — BASELINE LUCY RULES BELOW\n\n"
            f"{SYSTEM_PROMPT}"
        )
        print(f"{DIM}Persona loaded: {_persona_path.name} "
              f"({len(_persona_text)} chars prepended to SYSTEM_PROMPT){RESET}")

    if args.reset_session and SESSION_FILE.exists():
        SESSION_FILE.unlink()
        print(f"{SKY_BLUE}Session cleared.{RESET}")
        return

    if args.reset_boot and FIRST_BOOT_FLAG.exists():
        FIRST_BOOT_FLAG.unlink()
        print(f"{SKY_BLUE}First-boot flag cleared — dossier will reload on next launch.{RESET}")
        return

    _load_env_file()
    cfg = _load_config()

    # Restore verbosity from config, then override with CLI flag if given
    _VERBOSE = cfg.get("verbose_level", 0)
    if args.verbose is not None:
        _VERBOSE = args.verbose
        cfg["verbose_level"] = _VERBOSE
        _save_config(cfg)

    # F-LUCY-PROVIDER-CLI-FLAG: explicit --provider takes priority over
    # config-based _detect_provider() resolution.
    if args.provider:
        prov = args.provider
        _DEFAULT_MODELS = {
            "claude_cli": "claude-opus-4-7",
            "openai":     "gpt-4o",
            "deepseek":   "deepseek-v4-pro",
            "ollama":     "llama3.2:3b",
            "anthropic":  "claude-sonnet-4-6",
            "openrouter": "google/gemini-2.5-flash",
            "gemini":     "gemini-2.5-flash",
        }
        mdl = args.model or _DEFAULT_MODELS[prov]
        if prov == "claude_cli":
            key = _detect_claude_cli_binary()
            if not key:
                print(
                    f"{RED}[error] --provider claude_cli requires the "
                    f"`claude` CLI on PATH (binary not found).{RESET}"
                )
                sys.exit(1)
        elif prov == "ollama":
            key = "ollama-local"
        else:
            _ENV_VAR = {
                "openai":     "OPENAI_API_KEY",
                "deepseek":   "DEEPSEEK_API_KEY",
                "anthropic":  "ANTHROPIC_API_KEY",
                "openrouter": "OPENROUTER_API_KEY",
                "gemini":     "GEMINI_API_KEY",
            }[prov]
            key = os.environ.get(_ENV_VAR)
            if not key:
                print(
                    f"{RED}[error] --provider {prov} requires {_ENV_VAR} "
                    f"to be set in your environment or ~/.decker_env.{RESET}"
                )
                sys.exit(1)
        provider, model, api_key = prov, mdl, key
        print(f"{DIM}Explicit provider: {provider.upper()} → {model}{RESET}")
    else:
        provider_info = _detect_provider()
        if not provider_info:
            print(
                f"{RED}[error] No API key found.\n"
                f"Set DEEPSEEK_API_KEY (or ANTHROPIC_API_KEY / OPENAI_API_KEY) in your environment\n"
                f"or add it to ~/.decker_env.{RESET}"
            )
            sys.exit(1)
        provider, model, api_key = provider_info
        if args.model:
            model = args.model
        if not cfg.get("default_provider"):
            print(f"{DIM}Detected: {provider.upper()} → {model}{RESET}")
            cfg["default_provider"] = provider
            cfg["default_model"] = model
            _save_config(cfg)

    agent = LucyAgent(provider, model, api_key)

    # F-LUCY-GOAL-AUTONOMOUS-1: headless autonomous goal pursuit. Takes
    # precedence over --ask / --ask-file when set. Iterates LucyLoop on the
    # named GoalEngine project until gap closes.
    if getattr(args, "goal", None):
        try:
            from aibrain.core.lucy_loop import LucyLoop
            from aibrain.core.goal_engine import GoalEngine
            loop = LucyLoop(agent_id=LUCY_FLEET_ID)
            ge = GoalEngine(args.goal)
            ds = ge._state.get("desired_state", {})
            result = loop.run(
                project_id=args.goal,
                goal=ds.get("goal"),
                acceptance_criteria=ds.get("acceptance_criteria"),
                max_iterations=args.max_iterations,
                resume=True,
            )
            import json as _json
            print(_json.dumps({
                "project_id": args.goal,
                "reason_stopped": getattr(result, "reason_stopped", "?"),
                "iterations": getattr(result, "iterations", 0),
                "final_gap": getattr(result, "final_gap", None),
                "artifacts_created": getattr(result, "artifacts_created", []),
                "skills_captured": getattr(result, "skills_captured", []),
                "clarifications_needed": getattr(result, "clarifications_needed", []),
            }, indent=2, default=str))
        except Exception as exc:
            print(f"[lucy --goal error] {type(exc).__name__}: {exc}", file=sys.stderr)
            sys.exit(2)
        sys.exit(0)

    # F-LUCY-ASK-ONESHOT-1 / F-LUCY-ASK-FILE-1: headless one-shot — skip the
    # interactive REPL, process ONE turn, print answer, exit. Either --ask
    # (short prompts via argv) or --ask-file (any-size prompt via file path,
    # bypasses shell-quoting truncation).
    _ask_prompt = None
    if getattr(args, "ask_file", None):
        # File path takes precedence over --ask if both supplied.
        try:
            _ask_prompt = Path(args.ask_file).read_text(encoding="utf-8")
        except Exception as _read_err:
            print(f"[lucy --ask-file error] cannot read {args.ask_file!r}: "
                  f"{type(_read_err).__name__}: {_read_err}", file=sys.stderr)
            sys.exit(2)
        if getattr(args, "ask", None):
            print(f"[lucy] both --ask and --ask-file supplied; using --ask-file",
                  file=sys.stderr)
    elif getattr(args, "ask", None):
        _ask_prompt = args.ask
    if _ask_prompt is not None:
        try:
            reply = agent.chat(_ask_prompt)
        except Exception as exc:
            print(f"[lucy --ask error] {type(exc).__name__}: {exc}", file=sys.stderr)
            sys.exit(2)
        # Print just the model response on stdout so scripts can capture it.
        print(reply if reply is not None else "")
        sys.exit(0)

    agent.run()


if __name__ == "__main__":
    main()
