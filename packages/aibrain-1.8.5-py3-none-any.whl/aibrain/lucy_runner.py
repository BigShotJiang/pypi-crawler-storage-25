#!/usr/bin/env python3
"""Lucy autonomous agent loop -- terminal entry point.

Usage:
    python aibrain/lucy_runner.py --project fishbuddy --goal "Build a fish prediction API"
    python aibrain/lucy_runner.py --project fishbuddy               # load existing goal from store
    python aibrain/lucy_runner.py --project fishbuddy --status      # show gap, do not run
    python aibrain/lucy_runner.py --project fishbuddy --criteria "API returns 200" "Auth works"
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _print_status(project_id: str) -> None:
    from aibrain.core.goal_engine import GoalEngine
    ge = GoalEngine(project_id)
    state = ge.load()
    gap = ge.measure()
    desired = state.get("desired_state", {})
    current = state.get("current_state", {})
    criteria = desired.get("acceptance_criteria", [])
    progress = current.get("progress", [])

    print(f"Project:    {project_id}")
    print(f"Goal:       {desired.get('goal', '(not set)')}")
    print(f"Gap score:  {gap:.3f}  ({'DONE' if ge.is_done() else 'in progress'})")
    print(f"Iterations: {current.get('iterations', 0)}")
    print(f"Criteria ({len(criteria)}):")
    for i, c in enumerate(criteria):
        done = i < len(progress) and progress[i]
        mark = "[x]" if done else "[ ]"
        print(f"  {mark} {c}")
    if not criteria:
        print("  (none -- run with --goal and --criteria to set desired state)")
    history = state.get("gap_history", [])
    if history:
        last5 = history[-5:]
        print(f"Gap history (last {len(last5)}): {[round(h['gap_score'], 3) for h in last5]}")


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="lucy_runner",
        description="Lucy autonomous agent loop -- closes gap between current and desired state",
    )
    parser.add_argument("--project", required=True, help="Project ID (key for goal state store)")
    parser.add_argument("--goal", default=None, help="Goal description (sets desired state)")
    parser.add_argument("--criteria", nargs="+", default=None,
                        help="Acceptance criteria (space-separated quoted strings)")
    parser.add_argument("--max-iterations", type=int, default=200)
    parser.add_argument("--cost-ceiling", type=float, default=100.0)
    parser.add_argument("--timeout", type=int, default=600,
                        help="HTTP timeout for DeepSeek calls in seconds")
    parser.add_argument("--resume", action="store_true",
                        help="Resume from last checkpoint instead of starting fresh")
    parser.add_argument("--agent-id", default="lucy")
    parser.add_argument("--status", action="store_true",
                        help="Print current goal state and exit (do not run loop)")

    args = parser.parse_args()

    if args.status:
        _print_status(args.project)
        return 0

    from aibrain.core.lucy_loop import LucyLoop

    loop = LucyLoop(agent_id=args.agent_id)

    print(f"[Lucy] Starting loop for project={args.project!r}")
    if args.goal:
        print(f"[Lucy] Goal: {args.goal}")
    if args.criteria:
        print(f"[Lucy] Criteria: {args.criteria}")

    result = loop.run(
        project_id=args.project,
        goal=args.goal,
        acceptance_criteria=args.criteria,
        max_iterations=args.max_iterations,
        cost_ceiling=args.cost_ceiling,
        resume=args.resume,
    )

    print()
    print("=" * 60)
    print(f"[Lucy] STOPPED: {result.reason_stopped}")
    print(f"[Lucy] Iterations: {result.iterations}")
    print(f"[Lucy] Final gap:  {result.final_gap:.3f}")
    print(f"[Lucy] Artifacts:  {len(result.artifacts_created)}")
    print(f"[Lucy] Skills:     {len(result.skills_captured)}")
    print(f"[Lucy] Gap history: {[round(g, 3) for g in result.gap_history]}")

    if result.clarifications_needed:
        print()
        print("[Lucy] CLARIFICATION NEEDED:")
        for q in result.clarifications_needed:
            print(f"  -> {q}")

    if result.reason_stopped == "goal_reached":
        print("[Lucy] Goal reached.")
        return 0
    elif result.reason_stopped in ("no_progress", "clarification_needed"):
        return 2
    return 1


if __name__ == "__main__":
    sys.exit(main())
