"""aibrain.agents.director_agent — Always-on Director fleet daemon.

F-DIRECTOR-AGENT-DAEMON-1: closes the cross-agent comms loop for Director.
Subscribes to fleet.message.director + fleet.task.* + fleet.coordination.*.
On inbound, dispatches to DeepSeek with Director persona, publishes response.

Run as: python -m aibrain.agents.director_agent
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import sys
import threading
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.agents.director_agent")

INBOX_POLL_INTERVAL = 2.0
HEARTBEAT_INTERVAL = 30
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
DEEPSEEK_MODEL = "deepseek-v4-pro"

DIRECTOR_SYSTEM_PROMPT = (
    "You are Director, the task-routing and priority-management agent in DeckerOps. "
    "You receive fleet messages from Lucy, Neuro, Deep, and QA. "
    "Your job: assign tasks to the right agent, reorder priorities, resolve blockers, "
    "and report fleet status. "
    "Respond with task assignments, priority changes, or status summaries. "
    "When asked 'who should do X', recommend the best agent. "
    "When a task is blocked, identify the blocker and suggest action. "
    "Do not invent facts. If you cannot help without more context, say so."
)

DEFAULT_SUBS = [
    ("director-default-direct", "fleet.message.director"),
    ("director-default-direct-glob", "fleet.message.director.*"),
    ("director-default-task", "fleet.task.*"),
    ("director-default-coordination", "fleet.coordination.*"),
    ("director-default-broadcast", "fleet.broadcast.*"),
    ("director-default-handoff", "fleet.handoff.*"),
]


class DirectorDaemon:
    def __init__(self, agent_id: str = "director",
                 poll_interval: float = INBOX_POLL_INTERVAL,
                 heartbeat_interval: int = HEARTBEAT_INTERVAL):
        self.agent_id = agent_id
        self.poll_interval = poll_interval
        self.heartbeat_interval = heartbeat_interval
        self._seen_msg_ids: set[str] = set()
        self._stop = threading.Event()

        from aibrain.core.agent_comms import FleetBus
        self._bus = FleetBus(agent_id=self.agent_id)

        self._llm_client = None
        self._llm_available = False
        api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
        if api_key:
            try:
                import openai
                self._llm_client = openai.OpenAI(api_key=api_key, base_url=DEEPSEEK_BASE_URL)
                self._llm_available = True
            except Exception as e:
                log.warning("DeepSeek client init failed: %s", e)
        else:
            log.warning("DEEPSEEK_API_KEY missing — replies will be stub-only")

        self._register_default_subs()

    def _register_default_subs(self) -> None:
        try:
            db_path = Path.home() / "projects" / "aibrain" / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            for sub_id, topic_glob in DEFAULT_SUBS:
                scoped_sub_id = f"{sub_id}__{self.agent_id}"
                exists = db.execute(
                    "SELECT 1 FROM agent_subscriptions WHERE sub_id=?", (scoped_sub_id,)
                ).fetchone()
                if not exists:
                    db.execute(
                        "INSERT INTO agent_subscriptions (sub_id, agent_id, topic_glob) VALUES (?, ?, ?)",
                        (scoped_sub_id, self.agent_id, topic_glob),
                    )
            db.commit()
            db.close()
            log.info("Registered %d default subscriptions for %s", len(DEFAULT_SUBS), self.agent_id)
        except Exception as e:
            log.warning("_register_default_subs failed (non-fatal): %s", e)

    def _handle_inbox_message(self, msg: dict) -> None:
        _typ = msg.get("type", "")
        _payload = msg.get("data", {}) or msg.get("payload", {})
        _src = (msg.get("source") or "").replace("agent://", "")

        if "test.ping" in _typ or "test.hello" in _typ:
            try:
                self._bus.publish(
                    "fleet.test.director_ack",
                    {"ping_id": _payload.get("ping_id", ""), "from": "director"},
                )
                log.info("Auto-acked test from %s (type=%s)", _src, _typ)
            except Exception as e:
                log.debug("Auto-ack publish failed: %s", e)
            return

        try:
            _msg_text = (_payload.get("msg") or _payload.get("text")
                         or _payload.get("body") or json.dumps(_payload)[:500])
        except Exception:
            _msg_text = str(_payload)[:500]
        log.info("[FLEET inbound from %s] %s: %s", _src, _typ, _msg_text[:200])
        self._dispatch_response(msg, _src, _msg_text)

    def _dispatch_response(self, msg: dict, src: str, msg_text: str) -> None:
        if not self._llm_available:
            try:
                self._bus.publish(
                    f"fleet.message.{src}.reply",
                    {
                        "reply": "[director-daemon] message received, no LLM available",
                        "in_response_to": msg.get("id", ""),
                        "from": "director",
                    },
                )
            except Exception:
                pass
            return

        try:
            resp = self._llm_client.chat.completions.create(
                model=DEEPSEEK_MODEL,
                messages=[
                    {"role": "system", "content": DIRECTOR_SYSTEM_PROMPT},
                    {"role": "user", "content": f"Inbound fleet message from {src}: {msg_text}"},
                ],
                max_tokens=500,
                temperature=0.3,
            )
            reply_text = resp.choices[0].message.content.strip()
        except Exception as e:
            log.warning("DeepSeek call failed: %s", e)
            reply_text = f"[director-daemon] error generating response: {e}"

        try:
            self._bus.publish(
                f"fleet.message.{src}.reply",
                {
                    "reply": reply_text,
                    "in_response_to": msg.get("id", ""),
                    "from": "director",
                },
            )
            log.info("Replied to %s (%d chars)", src, len(reply_text))
        except Exception as e:
            log.warning("Reply publish failed: %s", e)

    def _poll_loop(self) -> None:
        while not self._stop.is_set():
            try:
                msgs = self._bus.poll_inbox()
                for m in msgs:
                    mid = m.get("id") or ""
                    if mid and mid in self._seen_msg_ids:
                        continue
                    if mid:
                        self._seen_msg_ids.add(mid)
                        if len(self._seen_msg_ids) > 1000:
                            self._seen_msg_ids = set(list(self._seen_msg_ids)[-500:])
                    try:
                        self._handle_inbox_message(m)
                    except Exception as e:
                        log.warning("Handler error (non-fatal): %s", e)
            except Exception as e:
                log.debug("Poll error (non-fatal): %s", e)
            self._stop.wait(self.poll_interval)

    def _heartbeat_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._bus.publish(
                    f"fleet.heartbeat.{self.agent_id}",
                    {"agent_id": self.agent_id, "timestamp": time.time(), "status": "alive"},
                )
                db_path = Path(os.environ.get("AIBRAIN_ROOT", str(Path.home()))) / "aibrain.db"
                if not db_path.exists():
                    db_path = Path.home() / "projects" / "aibrain" / "aibrain.db"
                db = sqlite3.connect(str(db_path))
                db.execute(
                    "UPDATE agent_endpoints SET last_seen_at=datetime('now'), status='online' WHERE agent_id=?",
                    (self.agent_id,),
                )
                db.commit()
                db.close()
            except Exception as e:
                log.debug("Heartbeat error (non-fatal): %s", e)
            self._stop.wait(self.heartbeat_interval)

    def run(self) -> None:
        log.info("DirectorDaemon starting — agent_id=%s", self.agent_id)
        poll_thread = threading.Thread(target=self._poll_loop, daemon=True, name="director-inbox-poll")
        hb_thread = threading.Thread(target=self._heartbeat_loop, daemon=True, name="director-heartbeat")
        poll_thread.start()
        hb_thread.start()
        log.info("DirectorDaemon running — poll=%ss heartbeat=%ss", self.poll_interval, self.heartbeat_interval)
        try:
            while not self._stop.is_set():
                self._stop.wait(60)
        except KeyboardInterrupt:
            log.info("KeyboardInterrupt — shutting down DirectorDaemon")
            self._stop.set()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    DirectorDaemon().run()
