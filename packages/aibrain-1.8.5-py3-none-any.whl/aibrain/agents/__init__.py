"""aibrain.agents — Fleet agent lifecycle management.

F-AGENT-SPAWN-1: spawn, list, stop, start, rm subcommands.
Canonical entry: python -m aibrain.agents.spawn
CLI wrapper: aibrain agent <subcommand>

F-FLEET-START-1: fleet daemon launcher (subprocess-based, no Task Scheduler).
Canonical entry: python -m aibrain.agents.fleet_start
CLI wrapper: aibrain fleet {start|stop|status}
"""

from .spawn import cli, spawn_agent, list_agents, stop_agent, start_agent, remove_agent
from .fleet_start import start_all, stop_all, fleet_status

__all__ = [
    "cli", "spawn_agent", "list_agents", "stop_agent", "start_agent", "remove_agent",
    "start_all", "stop_all", "fleet_status",
]
