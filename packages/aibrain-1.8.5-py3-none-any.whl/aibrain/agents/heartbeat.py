"""aibrain.agents.heartbeat — Fleet heartbeat daemon (F-COMMS-WIRING-OPERATIONAL-1).

Publishes fleet.heartbeat.<agent_id> every 30s. Updates agent_endpoints.last_seen_at.
Run as: python -m aibrain.agents.heartbeat <agent_id>
"""
import json, logging, os, sys, time, sqlite3
from pathlib import Path

log = logging.getLogger("aibrain.agents.heartbeat")

def run_heartbeat(agent_id: str, interval: int = 30):
    """Publish heartbeat every `interval` seconds. Updates last_seen_at in DB."""
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))
    from aibrain.core.agent_comms import FleetBus
    
    bus = FleetBus(agent_id=agent_id)
    log.info("Heartbeat daemon started for %s (interval=%ds)", agent_id, interval)
    
    while True:
        try:
            bus.publish(f"fleet.heartbeat.{agent_id}", {
                "agent_id": agent_id,
                "timestamp": time.time(),
                "status": "alive"
            })
            # Update last_seen_at directly
            db_path = Path(os.environ.get("AIBRAIN_ROOT", str(Path.home()))) / "aibrain.db"
            db = sqlite3.connect(str(db_path))
            db.execute(
                "UPDATE agent_endpoints SET last_seen_at=datetime('now'), status='online' WHERE agent_id=?",
                (agent_id,))
            db.commit(); db.close()
        except Exception as e:
            log.debug("Heartbeat error (non-fatal): %s", e)
        time.sleep(interval)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    if len(sys.argv) < 2:
        print("Usage: python -m aibrain.agents.heartbeat <agent_id> [interval_seconds]")
        sys.exit(1)
    agent = sys.argv[1]
    interval = int(sys.argv[2]) if len(sys.argv) > 2 else 30
    run_heartbeat(agent, interval)
