"""aibrain.agents.director_daemon — Director fleet orchestrator daemon.

F-DIRECTOR-DAEMON-1: always-on daemon for the Director agent. Extends AgentDaemon.
Routes tasks, manages priorities, tracks fleet status. Receives coordination
requests via FleetBus, generates routing decisions via DeepSeek, publishes
assignments back.

Run as: python -m aibrain.agents.director_daemon
"""

from __future__ import annotations

import logging
from pathlib import Path

from aibrain.agents.base_daemon import AgentDaemon

log = logging.getLogger("aibrain.agents.director_daemon")

DIRECTOR_SYSTEM_PROMPT = (
    "You are Director — the fleet's coordination layer in DeckerOps. "
    "You route tasks to the right agent, manage priorities, track progress "
    "across the fleet, and resolve blockers. "
    "You don't write code or analyze markets. You ensure the right work "
    "gets to the right agent at the right time.\n\n"
    "ROUTING LOGIC:\n"
    "1. New task → classify by type (code/analysis/qa/infra/content)\n"
    "2. Check agent availability → who is idle, matching capabilities\n"
    "3. Assign → update task, publish fleet.task.assigned\n"
    "4. Monitor → track status, detect stalls\n"
    "5. Escalate → if stalled > threshold, re-assign or notify Decker\n\n"
    "AGENT CAPABILITY MAP:\n"
    "- Neuro: strategy, analysis, market research, proposal review\n"
    "- Deep: code generation, debugging, refactoring, implementation\n"
    "- QA (9IXqSnCBLLQ): verification, testing, regression detection\n"
    "- Lucy: Decker's direct assistant, product development\n"
    "- DevOps (I5JwaUTVUps): infrastructure, CI/CD, agent health\n\n"
    "PRIORITY TIERS: CRITICAL > HIGH > MEDIUM > LOW\n\n"
    "STYLE: Precise. One-line routing decisions with reason. "
    "Tabular summaries. Escalate clearly."
)

DIRECTOR_DEFAULT_SUBS = [
    ("director-default-task", "fleet.task.*"),
    ("director-default-agent", "fleet.agent.*"),
    ("director-default-direct", "fleet.message.director"),
    ("director-default-direct-glob", "fleet.message.director.*"),
    ("director-default-coordination", "fleet.coordination.*"),
    ("director-default-test", "fleet.test.*"),
    ("director-default-broadcast", "fleet.broadcast.*"),
    ("director-default-handoff", "fleet.handoff.*"),
]


class DirectorDaemon(AgentDaemon):
    """Always-on daemon for Director — the fleet's orchestrator."""

    AGENT_ID = "director"
    SYSTEM_PROMPT = DIRECTOR_SYSTEM_PROMPT
    DEFAULT_SUBS = DIRECTOR_DEFAULT_SUBS


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    DirectorDaemon().run()
