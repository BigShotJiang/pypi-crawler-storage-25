"""aibrain.agents.base_daemon — Shared Fleet Agent Daemon base class.

F-FLEET-DAEMON-BASE-1: every fleet agent (Neuro, Deep, Director) extends this.
Handles FleetBus connect, inbox poll loop, heartbeat, seen_msg_ids dedup,
DeepSeek response generation, and reply publishing.

Usage:
    class MyDaemon(AgentDaemon):
        AGENT_ID = "my_agent"
        SYSTEM_PROMPT = "You are MyAgent..."
        DEFAULT_SUBS = [("sub-id", "fleet.message.my_agent"), ...]

    MyDaemon().run()
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.agents.base_daemon")

INBOX_POLL_INTERVAL = 2.0
HEARTBEAT_INTERVAL = 30
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
DEEPSEEK_MODEL = "deepseek-v4-pro"

# F-LUCY-DB-PATH-CANONICAL-1: canonical DB path resolution
try:
    from aibrain_db import AIBRAIN_ROOT as _CANONICAL_ROOT
    DB_PATH = str(Path(_CANONICAL_ROOT) / "aibrain.db")
except ImportError:
    DB_PATH = str(Path(os.environ.get("AIBRAIN_ROOT", str(Path.home()))) / "aibrain.db")


def _load_decker_env() -> None:
    """Load ~/.decker_env into os.environ if present and not already loaded."""
    env_file = Path.home() / ".decker_env"
    if not env_file.exists():
        return
    try:
        with open(env_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("export "):
                    line = line[7:]
                if "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip("'").strip('"')
                if key and key not in os.environ:
                    os.environ[key] = value
    except Exception:
        pass  # Non-fatal


# Load env at module import time
_load_decker_env()


class AgentDaemon:
    """Base class for all fleet agent daemons.

    Subclasses override:
      - AGENT_ID (str)
      - SYSTEM_PROMPT (str)
      - DEFAULT_SUBS (list of (sub_id, topic_glob) tuples)
      - _generate_response(msg, src, msg_text) → str (optional)
    """

    AGENT_ID: str = "base"
    SYSTEM_PROMPT: str = "You are a fleet agent in DeckerOps. Respond concisely."
    DEFAULT_SUBS: list[tuple[str, str]] = []

    def __init__(self, poll_interval: float = INBOX_POLL_INTERVAL,
                 heartbeat_interval: int = HEARTBEAT_INTERVAL):
        self.poll_interval = poll_interval
        self.heartbeat_interval = heartbeat_interval
        self._seen_msg_ids: set[str] = set()
        self._stop = threading.Event()

        # FleetBus connection
        from aibrain.core.agent_comms import FleetBus
        self._bus = FleetBus(agent_id=self.AGENT_ID, db_path=DB_PATH)

        # DeepSeek client (lazy — only if API key present)
        self._llm_client = None
        self._llm_available = False
        api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
        if api_key:
            try:
                import openai
                self._llm_client = openai.OpenAI(
                    api_key=api_key, base_url=DEEPSEEK_BASE_URL
                )
                self._llm_available = True
            except Exception as e:
                log.warning("%s: DeepSeek client init failed: %s", self.AGENT_ID, e)
        else:
            log.warning("%s: DEEPSEEK_API_KEY missing — replies will be stub-only", self.AGENT_ID)

        self._register_default_subs()

    # ── Subscriptions ──────────────────────────────────────────────

    def _register_default_subs(self) -> None:
        """Idempotent subscription registration. Scoped by (sub_id, agent_id)."""
        try:
            db = sqlite3.connect(DB_PATH)
            for sub_id, topic_glob in self.DEFAULT_SUBS:
                scoped_sub_id = f"{sub_id}__{self.AGENT_ID}"
                exists = db.execute(
                    "SELECT 1 FROM agent_subscriptions WHERE sub_id=?",
                    (scoped_sub_id,)
                ).fetchone()
                if not exists:
                    db.execute(
                        "INSERT INTO agent_subscriptions (sub_id, agent_id, topic_glob) "
                        "VALUES (?, ?, ?)",
                        (scoped_sub_id, self.AGENT_ID, topic_glob),
                    )
            db.commit()
            db.close()
            log.info("%s: registered %d default subscriptions",
                     self.AGENT_ID, len(self.DEFAULT_SUBS))
        except Exception as e:
            log.warning("%s: _register_default_subs failed (non-fatal): %s",
                        self.AGENT_ID, e)

    # ── Message handling ───────────────────────────────────────────

    def _handle_inbox_message(self, msg: dict) -> None:
        """Process one inbound fleet message. Subclasses may override."""
        _typ = msg.get("type", "")
        _payload = msg.get("data", {}) or msg.get("payload", {})
        _src = (msg.get("source") or "").replace("agent://", "")

        # F-LUCY-REPLY-ROUTING-FIX-1: prefer payload.from over msg.source
        # So task_bridge can set from=lucy and replies route correctly
        _payload_from = ""
        if isinstance(_payload, dict):
            _payload_from = (_payload.get("from") or "").strip()

        if _payload_from and _payload_from not in (
            "task_bridge", "fleet_start", "fleet_start_test", "unknown",
        ):
            _src = _payload_from
        elif not _src or _src == "unknown":
            _src = _payload_from

        # Auto-ack ping/hello tests
        if "test.ping" in _typ or "test.hello" in _typ:
            try:
                self._bus.publish(
                    f"fleet.test.{self.AGENT_ID}_ack",
                    {"ping_id": _payload.get("ping_id", ""), "from": self.AGENT_ID},
                )
                log.info("%s: auto-acked test from %s (type=%s)", self.AGENT_ID, _src, _typ)
            except Exception as e:
                log.debug("%s: auto-ack publish failed: %s", self.AGENT_ID, e)
            return

        # Extract message body
        try:
            _msg_text = (_payload.get("msg") or _payload.get("text")
                         or _payload.get("body") or _payload.get("question")
                         or _payload.get("prompt") or
                         json.dumps(_payload)[:500])
        except Exception:
            _msg_text = str(_payload)[:500]

        log.info("[%s inbound from %s] %s: %s",
                 self.AGENT_ID, _src, _typ, _msg_text[:200])

        # Generate and publish response
        self._dispatch_response(msg, _src, _msg_text)

    def _dispatch_response(self, msg: dict, src: str, msg_text: str) -> None:
        """Generate a response via DeepSeek and publish it back."""
        reply_text = self._generate_response(msg, src, msg_text)

        # Derive reply topic
        if src and src not in ("unknown", self.AGENT_ID, "self", ""):
            reply_topic = f"fleet.message.{src}"
        elif msg.get("type", "").startswith("fleet.message."):
            reply_topic = msg["type"]
        else:
            reply_topic = f"fleet.message.{src}" if src else "fleet.broadcast"

        try:
            self._bus.publish(
                reply_topic,
                {
                    "msg": reply_text,
                    "reply_to": msg.get("id", ""),
                    "from": self.AGENT_ID,
                },
            )
            log.info("%s: replied to %s via %s (%d chars)",
                     self.AGENT_ID, src, reply_topic, len(reply_text))
        except Exception as e:
            log.warning("%s: reply publish failed: %s", self.AGENT_ID, e)

    def _generate_response(self, msg: dict, src: str, msg_text: str) -> str:
        """Generate a response using DeepSeek. Override for custom behavior."""
        if not self._llm_available:
            return (f"[{self.AGENT_ID}-daemon] message received from {src}. "
                    "No LLM available for response generation.")

        try:
            resp = self._llm_client.chat.completions.create(
                model=DEEPSEEK_MODEL,
                messages=[
                    {"role": "system", "content": self.SYSTEM_PROMPT},
                    {"role": "user",
                     "content": f"Inbound fleet message from {src}: {msg_text}"},
                ],
                max_tokens=500,
                temperature=0.3,
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            log.warning("%s: DeepSeek call failed: %s", self.AGENT_ID, e)
            return f"[{self.AGENT_ID}-daemon] error generating response: {e}"

    # ── Background loops ───────────────────────────────────────────

    def _poll_loop(self) -> None:
        """Background thread: poll inbox every poll_interval seconds."""
        while not self._stop.is_set():
            try:
                msgs = self._bus.poll_inbox()
                for m in msgs:
                    mid = m.get("id") or m.get("msg_id") or ""
                    if mid and mid in self._seen_msg_ids:
                        continue
                    if mid:
                        self._seen_msg_ids.add(mid)
                        if len(self._seen_msg_ids) > 1000:
                            self._seen_msg_ids = set(list(self._seen_msg_ids)[-500:])
                    try:
                        self._handle_inbox_message(m)
                    except Exception as e:
                        log.warning("%s: handler error (non-fatal): %s",
                                    self.AGENT_ID, e)
            except Exception as e:
                log.debug("%s: poll error (non-fatal): %s", self.AGENT_ID, e)
            self._stop.wait(self.poll_interval)

    def _heartbeat_loop(self) -> None:
        """Background thread: publish heartbeat every interval."""
        while not self._stop.is_set():
            try:
                self._bus.publish(
                    f"fleet.heartbeat.{self.AGENT_ID}",
                    {"agent_id": self.AGENT_ID, "timestamp": time.time(),
                     "status": "alive"},
                )
                # Update last_seen_at in agent_endpoints
                db = sqlite3.connect(DB_PATH)
                db.execute(
                    "UPDATE agent_endpoints SET last_seen_at=datetime('now'), "
                    "status='online' WHERE agent_id=?",
                    (self.AGENT_ID,),
                )
                db.commit()
                db.close()
            except Exception as e:
                log.debug("%s: heartbeat error (non-fatal): %s", self.AGENT_ID, e)
            self._stop.wait(self.heartbeat_interval)

    # ── Lifecycle ──────────────────────────────────────────────────

    def run(self) -> None:
        """Main entrypoint: spawn poll + heartbeat threads, block forever."""
        log.info("%s daemon starting — agent_id=%s", self.AGENT_ID, self.AGENT_ID)
        poll_thread = threading.Thread(
            target=self._poll_loop, daemon=True,
            name=f"{self.AGENT_ID}-inbox-poll",
        )
        hb_thread = threading.Thread(
            target=self._heartbeat_loop, daemon=True,
            name=f"{self.AGENT_ID}-heartbeat",
        )
        poll_thread.start()
        hb_thread.start()
        log.info("%s daemon running — poll=%ss heartbeat=%ss",
                 self.AGENT_ID, self.poll_interval, self.heartbeat_interval)
        try:
            while not self._stop.is_set():
                self._stop.wait(60)
        except KeyboardInterrupt:
            log.info("%s: KeyboardInterrupt — shutting down", self.AGENT_ID)
            self._stop.set()

    def stop(self) -> None:
        """Signal the daemon to stop."""
        self._stop.set()
