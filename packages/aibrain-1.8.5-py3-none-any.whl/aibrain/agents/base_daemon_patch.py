    def _handle_inbox_message(self, msg: dict) -> None:
        """Process one inbound fleet message. Subclasses may override."""
        _typ = msg.get("type", "")
        _payload = msg.get("data", {}) or msg.get("payload", {})
        _src = (msg.get("source") or "").replace("agent://", "")

        # Prefer payload.from over msg.source for reply routing
        # (e.g. task_bridge sets from=lucy so replies come back to Lucy)
        _payload_from = ""
        if isinstance(_payload, dict):
            _payload_from = (_payload.get("from") or "").strip()

        if _payload_from and _payload_from not in (
            "task_bridge", "fleet_start", "fleet_start_test", "unknown",
        ):
            _src = _payload_from
        elif not _src or _src == "unknown":
            _src = _payload_from

        # Auto-ack ping/hello tests
        if "test.ping" in _typ or "test.hello" in _typ:
            try:
                self._bus.publish(
                    f"fleet.test.{self.AGENT_ID}_ack",
                    {"ping_id": _payload.get("ping_id", ""), "from": self.AGENT_ID},
                )
                log.info("%s: auto-acked test from %s (type=%s)", self.AGENT_ID, _src, _typ)
            except Exception as e:
                log.debug("%s: auto-ack publish failed: %s", self.AGENT_ID, e)
            return

        # Extract message body
        try:
            _msg_text = (_payload.get("msg") or _payload.get("text")
                         or _payload.get("body") or _payload.get("question")
                         or _payload.get("prompt") or
                         json.dumps(_payload)[:500])
        except Exception:
            _msg_text = str(_payload)[:500]

        log.info("[%s inbound from %s] %s: %s",
                 self.AGENT_ID, _src, _typ, _msg_text[:200])

        # Generate and publish response
        self._dispatch_response(msg, _src, _msg_text)