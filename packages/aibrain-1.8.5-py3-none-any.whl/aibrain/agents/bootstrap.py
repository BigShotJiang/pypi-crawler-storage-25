"""aibrain.agents.bootstrap — Fleet agent bootstrap and verification.

F-FLEET-BOOTSTRAP-1: one-shot fleet initialization and cross-agent comms test.

Usage:
    python -m aibrain.agents.bootstrap              # full init + verify
    python -m aibrain.agents.bootstrap --verify-only  # verify only (no launch)
    python -m aibrain.agents.bootstrap --launch-only   # launch daemons only
    python -m aibrain.agents.bootstrap --agent neuro    # single agent

Launches Neuro, Deep, and Director daemons as background threads, verifies
cross-agent comms, and prints fleet status.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sqlite3
import sys
import threading
import time
from pathlib import Path

log = logging.getLogger("aibrain.agents.bootstrap")

# Ensure the project root is on sys.path
_PROJECT_ROOT = Path(__file__).parent.parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

# DB path (same resolution as base_daemon)
try:
    from aibrain_db import AIBRAIN_ROOT as _CANONICAL_ROOT
    DB_PATH = str(Path(_CANONICAL_ROOT) / "aibrain.db")
except ImportError:
    DB_PATH = str(Path(os.environ.get("AIBRAIN_ROOT", str(Path.home()))) / "aibrain.db")

AGENTS = ["neuro", "deep", "director"]


def _check_prerequisites() -> bool:
    """Verify everything needed is installed and configured."""
    all_ok = True

    # 1. DEEPSEEK_API_KEY
    if not os.environ.get("DEEPSEEK_API_KEY"):
        print("  ⚠ DEEPSEEK_API_KEY not set — agents will use stub replies")
        # Not fatal — agents run without LLM

    # 2. DB exists
    db_path = Path(DB_PATH)
    if not db_path.exists():
        print(f"  ⚠ aibrain.db not found at {DB_PATH}")
        all_ok = False

    # 3. Agent personas exist
    for agent_name in AGENTS:
        persona_path = Path.home() / ".aibrain" / "agents" / agent_name / "persona.md"
        if not persona_path.exists():
            print(f"  ✗ Missing persona: {persona_path}")
            all_ok = False

    # 4. Import check
    try:
        from aibrain.agents.base_daemon import AgentDaemon  # noqa: F401
    except ImportError as e:
        print(f"  ✗ Cannot import AgentDaemon: {e}")
        all_ok = False

    # 5. FleetBus check
    try:
        from aibrain.core.agent_comms import FleetBus  # noqa: F401
    except ImportError as e:
        print(f"  ✗ Cannot import FleetBus: {e}")
        all_ok = False

    return all_ok


def _verify_fleet_state() -> dict:
    """Check current fleet state: DB tables, subscriptions, agent status."""
    state = {"agents": {}, "subscriptions": 0, "pending_messages": 0}

    try:
        db = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row

        # Agent endpoints
        rows = db.execute("SELECT * FROM agent_endpoints").fetchall()
        for r in rows:
            state["agents"][r["agent_id"]] = {
                "status": r["status"],
                "last_seen": r["last_seen_at"],
            }

        # Subscription count
        state["subscriptions"] = db.execute(
            "SELECT COUNT(*) FROM agent_subscriptions"
        ).fetchone()[0]

        # Pending messages
        state["pending_messages"] = db.execute(
            "SELECT COUNT(*) FROM agent_messages WHERE status='pending'"
        ).fetchone()[0]

        db.close()
    except Exception as e:
        state["error"] = str(e)

    return state


def _launch_agent(agent_name: str, daemons: dict) -> threading.Thread | None:
    """Launch a single agent daemon in a background thread."""
    from aibrain.agents.daemon import _get_daemon_class

    try:
        daemon_cls = _get_daemon_class(agent_name)
        daemon = daemon_cls()
        daemons[agent_name] = daemon

        thread = threading.Thread(
            target=daemon.run,
            daemon=True,
            name=f"bootstrap-{agent_name}",
        )
        thread.start()
        return thread
    except Exception as e:
        log.error("Failed to launch %s: %s", agent_name, e)
        return None


def _cross_agent_handoff_test() -> bool:
    """Test: publish a message to neuro, verify it's delivered and ack'd."""
    from aibrain.core.agent_comms import FleetBus

    bus = FleetBus(agent_id="bootstrap_test", db_path=DB_PATH)
    test_msg_id = f"bootstrap-test-{int(time.time())}"

    # Publish test to neuro
    bus.publish(
        "fleet.test.bootstrap",
        {
            "msg": "Bootstrap cross-agent handoff test. Reply if received.",
            "ping_id": test_msg_id,
            "from": "bootstrap",
        },
    )

    # Wait for ack or reply
    deadline = time.monotonic() + 15
    while time.monotonic() < deadline:
        try:
            db = sqlite3.connect(DB_PATH)
            db.row_factory = sqlite3.Row
            # Check for ack message
            ack = db.execute(
                "SELECT * FROM agent_messages WHERE payload LIKE ? ORDER BY created_at DESC LIMIT 1",
                (f"%{test_msg_id}%",)
            ).fetchone()
            db.close()
            if ack:
                print(f"  ✓ Cross-agent handoff confirmed: {ack['event_type']}")
                return True
        except Exception:
            pass
        time.sleep(1)

    print("  ⚠ Cross-agent handoff: no ack within 15s (agents may still be starting)")
    return False


def bootstrap(verify_only: bool = False, launch_only: bool = False,
              single_agent: str | None = None) -> bool:
    """Main bootstrap routine."""
    agents_to_launch = [single_agent] if single_agent else AGENTS

    print("=" * 60)
    print("FLEET BOOTSTRAP")
    print("=" * 60)

    # Step 1: Prerequisites
    print("\n[1/4] Checking prerequisites...")
    if not _check_prerequisites():
        print("  ⚠ Some prerequisites missing — continuing anyway")
    else:
        print("  ✓ All prerequisites met")

    # Step 2: Pre-flight state
    print("\n[2/4] Pre-flight fleet state:")
    state_before = _verify_fleet_state()
    for agent_id, info in state_before.get("agents", {}).items():
        print(f"  {agent_id}: {info['status']} (last seen: {info['last_seen']})")
    if not state_before.get("agents"):
        print("  (no agents registered)")
    print(f"  subscriptions: {state_before.get('subscriptions', 0)}")
    print(f"  pending messages: {state_before.get('pending_messages', 0)}")

    if verify_only:
        return True

    # Step 3: Launch
    if not launch_only or single_agent:
        print(f"\n[3/4] Launching agents: {', '.join(agents_to_launch)}")
        daemons = {}
        threads = []
        for agent_name in agents_to_launch:
            t = _launch_agent(agent_name, daemons)
            if t:
                threads.append(t)
                print(f"  ✓ {agent_name} daemon started")
            else:
                print(f"  ✗ {agent_name} daemon failed to start")

        # Give daemons a moment to register and subscribe
        time.sleep(3)

    # Step 4: Verify
    print("\n[4/4] Post-launch fleet state:")
    state_after = _verify_fleet_state()
    for agent_id, info in state_after.get("agents", {}).items():
        print(f"  {agent_id}: {info['status']} (last seen: {info['last_seen']})")
    print(f"  subscriptions: {state_after.get('subscriptions', 0)}")
    print(f"  pending messages: {state_after.get('pending_messages', 0)}")

    # Cross-agent handoff test
    print("\nCross-agent handoff test:")
    _cross_agent_handoff_test()

    print("\n" + "=" * 60)
    print("BOOTSTRAP COMPLETE")
    print("=" * 60)
    print("\nAgents running in background threads.")
    print("Press Ctrl+C to stop all agents.")
    print(f"Logs: ~/.aibrain/agents/<name>/logs/<name>.log")

    # Block until interrupted (if not in verify-only mode)
    try:
        while True:
            time.sleep(10)
    except KeyboardInterrupt:
        print("\nShutting down fleet...")
        if 'daemons' in dir():
            for name, daemon in daemons.items():
                try:
                    daemon.stop()
                    print(f"  ✓ {name} stopped")
                except Exception:
                    pass

    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="fleet-bootstrap",
        description="Fleet agent bootstrap and verification",
    )
    parser.add_argument("--verify-only", action="store_true",
                        help="Check fleet state without launching agents")
    parser.add_argument("--launch-only", action="store_true",
                        help="Launch agents without pre-flight checks")
    parser.add_argument("--agent", type=str, default=None,
                        help="Launch a single agent (neuro, deep, director)")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    ok = bootstrap(
        verify_only=args.verify_only,
        launch_only=args.launch_only,
        single_agent=args.agent,
    )
    sys.exit(0 if ok else 1)
