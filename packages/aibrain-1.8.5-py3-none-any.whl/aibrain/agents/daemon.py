"""aibrain.agents.daemon — Fleet agent daemon entry point.

F-AGENT-SPAWN-1: Entry point for Windows Task Scheduler or CLI.
    python -m aibrain.agents.daemon <agent_name>

Reads agent_name from CLI arg, loads persona from ~/.aibrain/agents/<name>/,
connects to fleet bus via F-COMMS-1, starts the appropriate AgentDaemon subclass.

Supported agents: neuro, deep, director
"""

import logging
import os
import signal
import sys
import time
from pathlib import Path

log = logging.getLogger("aibrain.agents.daemon")

# Agent name → daemon class mapping
_AGENT_DAEMON_MAP = {
    "neuro": "aibrain.agents.neuro_agent:NeuroDaemon",
    "deep": "aibrain.agents.deep_daemon:DeepDaemon",
    "director": "aibrain.agents.director_daemon:DirectorDaemon",
}


def _get_daemon_class(agent_name: str):
    """Import and return the daemon class for a given agent name."""
    import importlib

    class_path = _AGENT_DAEMON_MAP.get(agent_name)
    if not class_path:
        log.error("Unknown agent: %s. Known: %s", agent_name,
                  list(_AGENT_DAEMON_MAP.keys()))
        sys.exit(1)

    module_path, class_name = class_path.split(":")
    try:
        module = importlib.import_module(module_path)
        return getattr(module, class_name)
    except (ImportError, AttributeError) as e:
        log.error("Failed to load daemon class for %s: %s", agent_name, e)
        sys.exit(1)


def run_daemon(agent_name: str):
    """Main daemon function. Blocks until SIGTERM or crash loop."""
    agent_dir = Path.home() / ".aibrain" / "agents" / agent_name
    log_dir = agent_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    # Per-agent logging
    fh = logging.FileHandler(log_dir / f"{agent_name}.log")
    fh.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    logging.getLogger().addHandler(fh)

    log.info("Agent %s daemon starting (PID=%d)", agent_name, os.getpid())

    # Verify persona exists
    persona_path = agent_dir / "persona.md"
    if not persona_path.exists():
        log.error("Persona not found: %s", persona_path)
        sys.exit(1)

    # Get the daemon class and instantiate
    daemon_cls = _get_daemon_class(agent_name)
    daemon = daemon_cls()

    # Graceful shutdown on SIGTERM / SIGBREAK (Windows)
    def _shutdown(signum, frame):
        log.info("Agent %s received signal %d — shutting down", agent_name, signum)
        daemon.stop()

    signal.signal(signal.SIGTERM, _shutdown)
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, _shutdown)

    # Crash restart loop
    max_restarts = 5
    restart_delay = 60
    for attempt in range(max_restarts):
        try:
            daemon.run()
            break  # Clean exit
        except KeyboardInterrupt:
            break
        except Exception as e:
            log.error("Agent %s crashed (attempt %d/%d): %s",
                      agent_name, attempt + 1, max_restarts, e)
            if attempt < max_restarts - 1:
                log.info("Restarting in %ds...", restart_delay)
                time.sleep(restart_delay)
            else:
                log.critical("Agent %s: max restarts reached — exiting", agent_name)

    # Mark offline
    try:
        import sqlite3
        from aibrain.agents.base_daemon import DB_PATH
        db = sqlite3.connect(DB_PATH)
        db.execute(
            "UPDATE agent_endpoints SET status='offline', "
            "last_seen_at=datetime('now') WHERE agent_id=?",
            (agent_name,))
        db.commit()
        db.close()
    except Exception:
        pass

    log.info("Agent %s daemon stopped", agent_name)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    if len(sys.argv) < 2:
        print("Usage: python -m aibrain.agents.daemon <agent_name>")
        print(f"Known agents: {', '.join(_AGENT_DAEMON_MAP.keys())}")
        sys.exit(1)
    run_daemon(sys.argv[1])
