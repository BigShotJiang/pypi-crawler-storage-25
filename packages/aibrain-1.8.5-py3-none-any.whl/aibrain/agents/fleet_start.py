"""aibrain.agents.fleet_start — Fleet daemon launcher.

F-FLEET-START-1: Launches Neuro, Deep, and Director daemons as independent
subprocesses. No Windows Task Scheduler required. Suitable for dev, CI, and
production (with a process manager wrapper).

Usage:
    python -m aibrain.agents.fleet_start              # start all 3
    python -m aibrain.agents.fleet_start --agent neuro  # single agent
    python -m aibrain.agents.fleet_start --stop         # stop all
    python -m aibrain.agents.fleet_start --status       # check running state

Daemons run via: python -m aibrain.agents.daemon <name>
PIDs saved to ~/.aibrain/fleet/pids.json
Logs at ~/.aibrain/agents/<name>/logs/<name>.log
"""

from __future__ import annotations

import json
import logging
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

log = logging.getLogger("aibrain.agents.fleet_start")

FLEET_DIR = Path.home() / ".aibrain" / "fleet"
PID_FILE = FLEET_DIR / "pids.json"

FLEET_AGENTS = ["neuro", "deep", "director"]


def _ensure_fleet_dir():
    FLEET_DIR.mkdir(parents=True, exist_ok=True)


def _read_pids() -> dict:
    """Return {agent_name: pid} from PID_FILE."""
    if not PID_FILE.exists():
        return {}
    try:
        return json.loads(PID_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _write_pids(pids: dict):
    _ensure_fleet_dir()
    PID_FILE.write_text(json.dumps(pids, indent=2), encoding="utf-8")


def _is_process_alive(pid: int) -> bool:
    """Check if a process is running by PID. Windows-compatible."""
    # Try psutil first (most reliable cross-platform)
    try:
        import psutil
        return psutil.pid_exists(pid)
    except ImportError:
        pass

    # Windows: use tasklist
    if sys.platform == "win32":
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                capture_output=True, text=True, timeout=5,
            )
            return str(pid) in result.stdout
        except Exception:
            return False

    # Unix fallback: os.kill with signal 0
    try:
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def start_agent(agent_name: str) -> dict:
    """Launch a single fleet agent daemon as a subprocess.

    Returns: {"agent": name, "pid": int, "status": "started" | "already_running" | "error"}
    """
    pids = _read_pids()

    # Check if already running
    existing_pid = pids.get(agent_name)
    if existing_pid and _is_process_alive(existing_pid):
        return {"agent": agent_name, "pid": existing_pid, "status": "already_running"}

    # Verify persona exists
    persona_path = Path.home() / ".aibrain" / "agents" / agent_name / "persona.md"
    if not persona_path.exists():
        return {"agent": agent_name, "pid": None, "status": "error",
                "error": f"Persona not found: {persona_path}"}

    # Launch daemon
    try:
        proc = subprocess.Popen(
            [sys.executable, "-m", "aibrain.agents.daemon", agent_name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
        pids[agent_name] = proc.pid
        _write_pids(pids)
        log.info("Fleet agent %s started (PID=%d)", agent_name, proc.pid)
        return {"agent": agent_name, "pid": proc.pid, "status": "started"}
    except Exception as e:
        log.error("Failed to start %s: %s", agent_name, e)
        return {"agent": agent_name, "pid": None, "status": "error", "error": str(e)}


def stop_agent(agent_name: str) -> dict:
    """Stop a running fleet agent daemon. Windows: uses taskkill."""
    pids = _read_pids()
    pid = pids.get(agent_name)

    if not pid:
        return {"agent": agent_name, "status": "not_running"}

    if not _is_process_alive(pid):
        pids.pop(agent_name, None)
        _write_pids(pids)
        return {"agent": agent_name, "status": "already_dead"}

    try:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/F"],
                capture_output=True, timeout=10,
            )
        else:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.5)
            if _is_process_alive(pid):
                os.kill(pid, signal.SIGKILL if hasattr(signal, "SIGKILL") else signal.SIGTERM)
        pids.pop(agent_name, None)
        _write_pids(pids)
        return {"agent": agent_name, "pid": pid, "status": "stopped"}
    except Exception as e:
        return {"agent": agent_name, "pid": pid, "status": "error", "error": str(e)}


def fleet_status() -> dict:
    """Return status of all fleet agents."""
    pids = _read_pids()
    status = {}
    for agent_name in FLEET_AGENTS:
        pid = pids.get(agent_name)
        if pid and _is_process_alive(pid):
            status[agent_name] = {"pid": pid, "status": "running"}
        elif pid:
            status[agent_name] = {"pid": pid, "status": "dead"}
            # Clean up dead PID
            pids.pop(agent_name, None)
            _write_pids(pids)
        else:
            status[agent_name] = {"pid": None, "status": "stopped"}
    return status


def start_all() -> dict:
    """Launch all fleet agents. Returns per-agent results."""
    results = {}
    for agent_name in FLEET_AGENTS:
        results[agent_name] = start_agent(agent_name)
    return results


def stop_all() -> dict:
    """Stop all fleet agents."""
    results = {}
    for agent_name in FLEET_AGENTS:
        results[agent_name] = stop_agent(agent_name)
    return results


def quick_cross_agent_test() -> bool:
    """Publish a test message and verify agents see it.

    Publishes to fleet.message.neuro, fleet.message.deep, fleet.message.director.
    Returns True if publish succeeded (delivery requires agents running + polling).
    """
    try:
        from aibrain.core.agent_comms import FleetBus
        bus = FleetBus(agent_id="fleet_start_test")
        for agent in ["neuro", "deep", "director"]:
            bus.publish(f"fleet.message.{agent}", {
                "msg": f"fleet_start: cross-agent handshake to {agent}",
                "from": "fleet_start",
                "timestamp": time.time(),
            })
        log.info("Cross-agent test messages published to all 3 agents")
        return True
    except Exception as e:
        log.warning("Cross-agent test failed: %s", e)
        return False


# ── CLI ─────────────────────────────────────────────────────────────

def cli(args: list = None) -> int:
    """CLI entry point."""
    if args is None:
        args = sys.argv[1:]

    # --help or -h
    if args and args[0] in ("--help", "-h"):
        _print_help()
        return 0

    # No args → start all
    if not args:
        results = start_all()
        for name, r in results.items():
            status_str = r['status']
            if status_str == 'started':
                print(f"  + {name} started (PID={r['pid']})")
            elif status_str == 'already_running':
                print(f"  = {name} already running (PID={r['pid']})")
            else:
                print(f"  ! {name}: {status_str}" +
                      (f" - {r.get('error')}" if r.get('error') else ""))
        time.sleep(2)
        quick_cross_agent_test()
        return 0

    cmd = args[0]

    if cmd == "--stop":
        results = stop_all()
        for name, r in results.items():
            print(f"  {name}: {r['status']}")
        return 0

    if cmd == "--status":
        status = fleet_status()
        print(f"{'AGENT':12s} {'PID':8s} {'STATUS'}")
        print("-" * 30)
        for name, info in status.items():
            pid_str = str(info['pid']) if info['pid'] else '-'
            print(f"{name:12s} {pid_str:8s} {info['status']}")
        return 0

    if cmd == "--agent":
        if len(args) < 2:
            print("Error: --agent requires a name")
            return 1
        agent_name = args[1]
        if agent_name not in FLEET_AGENTS:
            print(f"Error: unknown agent '{agent_name}'. Known: {', '.join(FLEET_AGENTS)}")
            return 1
        result = start_agent(agent_name)
        print(f"  {result['agent']}: {result['status']}" +
              (f" (PID={result['pid']})" if result.get('pid') else ""))
        if result.get("error"):
            print(f"    Error: {result['error']}")
        return 0 if result['status'] != 'error' else 1

    # Unknown flag
    _print_help()
    return 1


def _print_help():
    print("Usage: python -m aibrain.agents.fleet_start [--agent <name>] [--stop] [--status]")
    print(f"  Agents: {', '.join(FLEET_AGENTS)}")
    print("  (no args)       Start all fleet agents")
    print("  --agent <name>  Start a single agent")
    print("  --stop          Stop all fleet agents")
    print("  --status        Show fleet status")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    sys.exit(cli())
