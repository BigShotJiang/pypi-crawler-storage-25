"""aibrain.agents.neuro_orchestrator — Telegram + delegation glue on top of NeuroDaemon.

Closes the loop Decker demanded 2026-05-22:
    Decker -> Telegram -> Neuro daemon (this) -> /delegate intent ->
    create_task(assignee_agent_id) -> specialist's agent_listener picks up via
    DB-poll -> dispatch_deepseek_task -> complete_task fires inline Liaison
    gate -> agent_listener publishes fleet.task.completed -> THIS daemon hears it
    -> reply_to_telegram(Decker) with work_output preview.

No copy-paste required from Decker. All inter-agent comms via FleetBus.
Telegram I/O is Neuro-only (single bot, single surface) per the architecture
laid out in claude_case_rules/fleet_comms.md.

Run as:
    python -m aibrain.agents.neuro_orchestrator

Coexists with:
- existing interactive Claude Code Neuro session (agent_id=neuro@windows-local)
- existing NeuroDaemon at agent_id=neuro (this daemon BECOMES that, not a third one)
- agent_listener.py processes for the 4 specialists
"""

from __future__ import annotations

import logging
import os
import sys
import threading
from pathlib import Path
from typing import Optional

# Path bridge so we can import decker_system/04_tools/agent_comms (Telegram I/O)
_DECKER_TOOLS = Path(r"C:\Users\sinde\decker_system\04_tools")
if _DECKER_TOOLS.is_dir():
    sys.path.insert(0, str(_DECKER_TOOLS))

from aibrain.agents.neuro_agent import NeuroDaemon, NEURO_DEFAULT_SUBS, NEURO_SYSTEM_PROMPT

log = logging.getLogger("aibrain.agents.neuro_orchestrator")


# Canonical persona -> agent_id map for /delegate intent parsing.
# Source of truth: CLAUDE.md DeckerOps agent roster.
PERSONA_TO_AGENT_ID: dict[str, str] = {
    "content_writer":       "RztUQUCs-h4",
    "content":              "RztUQUCs-h4",
    "research_analyst":     "RFYhIipppGs",
    "research":             "RFYhIipppGs",
    "outreach_coordinator": "RrYNwHqrzYY",
    "outreach":             "RrYNwHqrzYY",
    "communications":       "RrYNwHqrzYY",
    "job_search":           "Ou3UIxW9-7c",
    "lead_engineer":        "CDTYrHYkyH8",
    "engineer":             "CDTYrHYkyH8",
    "security_engineer":    "v_sJ2kha1EQ",
    "security":             "v_sJ2kha1EQ",
    "devops":               "I5JwaUTVUps",
    "data_analyst":         "wAfRAIHL_Kc",
    "qa":                   "9IXqSnCBLLQ",
    "qa_lead":              "9IXqSnCBLLQ",
    "cto":                  "w_wqv7t9huE",
    "cmo":                  "vZX67BqBmjo",
    "coo":                  "m2FRRZhP5lw",
    "cfo":                  "5nvOImJifUU",
    "accountant":           "NyFKX783dO8",
    "hr":                   "FlTsbFpW4TQ",
    "legal":                "iEsw2ApS2gU",
    "product":              "B3OLnCI3fXk",
    "product_manager":      "B3OLnCI3fXk",
    "community":            "ag89hZc-swI",
    "seo":                  "BCQ0gfGgsZ0",
    "video":                "1KHYPUDXh2g",
    "liaison":              "bwHDCnvlGFY",
}

_ORCH_SUBS = NEURO_DEFAULT_SUBS + [
    ("neuro-orch-task-completed", "fleet.task.completed"),
    ("neuro-orch-task-failed",    "fleet.task.failed"),
]

# Trusted senders — these agents trigger DeepSeek auto-reply on fleet.message.neuro*
# even without payload.expect_reply=True. Other senders stay silent-by-default
# to prevent ping-pong loops with agents that have their own auto-reply paths
# (e.g. Lucy). Decker 2026-05-22: needed so Deep + Case can talk to Neuro
# without per-message ceremony.
TRUSTED_SENDERS: set[str] = {
    "deep",
    "case",
    "case@vps",
    "director",
}


class NeuroOrchestratorDaemon(NeuroDaemon):
    """NeuroDaemon + Telegram inbox poller + fleet.task.completed bridge."""

    AGENT_ID = "neuro"
    SYSTEM_PROMPT = NEURO_SYSTEM_PROMPT
    DEFAULT_SUBS = _ORCH_SUBS

    TG_POLL_INTERVAL = 2.0

    def __init__(self):
        super().__init__()
        # Telegram source = the canonical SQLite store written by
        # decker_system/04_tools/telegram_logger.py (the SINGLE getUpdates
        # poller — anything else competing for the bot token gets HTTP 409
        # Conflict and dies). Reading from this DB removes the dual-poller race
        # that left neuro_inbox.jsonl empty for hours on 2026-05-22.
        self._tg_db_path = Path(
            os.environ.get("TELEGRAM_LOGGER_DB",
                           str(Path.home() / "decker_system" / "telegram_messages.db"))
        )
        # Watermark — only process messages with update_id > this value.
        # Initialized to current MAX(update_id) at startup so daemon does NOT
        # reply to historical messages.
        self._tg_last_update_id: int = self._current_max_update_id()
        # In-memory map: task_id -> {chat_id, ts, original_text}
        # Used to route fleet.task.completed back to the right Decker DM
        self._delegated: dict[str, dict] = {}
        # Drain stale fleet inbox on startup so daemon does NOT auto-reply to
        # days-old Lucy/Deep chatter (caused cross-agent ping-pong 2026-05-22).
        self._drain_fleet_inbox_on_startup()

    def _current_max_update_id(self) -> int:
        """Return the latest update_id already in the Telegram archive — daemon
        will only process update_ids STRICTLY greater than this. Prevents
        replying to historical messages on startup."""
        try:
            import sqlite3
            if not self._tg_db_path.is_file():
                log.warning("telegram archive missing at %s — watermark=0",
                            self._tg_db_path)
                return 0
            con = sqlite3.connect(str(self._tg_db_path), timeout=5.0)
            row = con.execute("SELECT COALESCE(MAX(update_id), 0) FROM messages").fetchone()
            con.close()
            wm = int(row[0]) if row else 0
            log.info("orchestrator: telegram watermark on startup = %d", wm)
            return wm
        except Exception:
            log.exception("orchestrator: telegram watermark init failed (defaulting 0)")
            return 0

    def _drain_fleet_inbox_on_startup(self) -> None:
        """Mark all currently-pending agent_messages targeting this agent as
        delivered, WITHOUT firing handlers. Daemon then starts fresh from now."""
        try:
            import sqlite3
            from aibrain.agents.base_daemon import DB_PATH
            db = sqlite3.connect(DB_PATH)
            cur = db.execute(
                """UPDATE agent_messages
                   SET status='delivered',
                       delivered_at=datetime('now')
                   WHERE status='pending'
                     AND source_agent != ?""",
                (f"agent://{self.AGENT_ID}",),
            )
            drained = cur.rowcount
            db.commit()
            db.close()
            log.info("orchestrator: drained %d stale pending messages on startup",
                     drained)
        except Exception:
            log.exception("orchestrator: startup drain failed (non-fatal)")

    # ------------------------------------------------------------------
    # Override base inbox handler.
    # 1. fleet.task.completed/failed -> Telegram bridge (if we tracked the task)
    # 2. fleet.test.* -> base class auto-ack (preserved)
    # 3. fleet.message.* with payload.expect_reply=True -> DeepSeek reply
    # 4. Anything else -> LOG ONLY (no DeepSeek auto-response).
    #
    # The default base_daemon._handle_inbox_message would DeepSeek-reply to
    # every fleet.message.* it sees, which caused a ping-pong loop with Lucy's
    # own auto-reply path (2026-05-22). Silence is the default; reply only on
    # explicit ask. This is the "no chatty cross-agent loop" discipline.
    # ------------------------------------------------------------------
    def _handle_inbox_message(self, msg: dict) -> None:
        msg_type = msg.get("type", "") or ""
        payload = msg.get("payload", {}) or {}
        if not isinstance(payload, dict):
            payload = {}

        # Task lifecycle -> Telegram bridge
        if msg_type in ("fleet.task.completed", "fleet.task.failed"):
            try:
                self._handle_task_completion(msg)
            except Exception:
                log.exception("task completion bridge failed")
            return

        # Preserve base auto-ack for test pings
        if "test.ping" in msg_type or "test.hello" in msg_type:
            super()._handle_inbox_message(msg)
            return

        # Identify sender — prefer payload.from over msg.source (matches base
        # daemon's reply-routing logic at base_daemon._handle_inbox_message).
        src = (msg.get("source") or "").replace("agent://", "")
        payload_from = (payload.get("from") or "").strip().lower()
        sender = (payload_from or src or "").lower().split("@")[0]

        # LOOP-BREAK: if the message has a reply_to set, it is already a reply
        # in an existing thread. Replying to a reply triggers ping-pong with
        # any agent that auto-responds (which is most of them). Treat
        # reply-to-set messages as thread-end markers and log only.
        reply_to = (payload.get("reply_to") or "").strip()
        if reply_to:
            log.info("orchestrator: skip auto-reply (msg is itself a reply, "
                     "reply_to=%s sender=%s)", reply_to, sender or "?")
            return

        # DeepSeek auto-reply when (a) sender explicitly asked OR (b) sender is
        # in the trusted-senders allowlist (Deep, Case, Director — no known
        # auto-reply loop OR loop-broken by the reply_to check above).
        expect_reply = bool(payload.get("expect_reply"))
        if expect_reply or sender in TRUSTED_SENDERS:
            super()._handle_inbox_message(msg)
            return

        # Otherwise: log + move on, no auto-reply.
        log.info("orchestrator: silent inbox observed type=%s src=%s (sender=%s "
                 "not trusted, no expect_reply, no reply_to — no auto-reply)",
                 msg_type, src, sender or "?")

    def _handle_task_completion(self, msg: dict) -> None:
        payload = msg.get("payload", {}) or {}
        task_id = payload.get("task_id")
        if not task_id:
            return
        origin = self._delegated.pop(task_id, None)
        if origin is None:
            # Not one we tracked — skip (could be filtered later if Decker wants
            # global completion visibility)
            return

        agent_id = payload.get("agent_id", "?")
        status = payload.get("status", "done")
        preview = (payload.get("work_output_preview") or "")[:1500]
        critique = payload.get("critique", "")

        if status == "done":
            tg_text = (
                f"Task complete (delegated to {agent_id}):\n"
                f'> "{origin["text"][:160]}"\n\n'
                f"{preview}"
            )
        else:
            tg_text = (
                f"Task FAILED (delegated to {agent_id}):\n"
                f'> "{origin["text"][:160]}"\n\n'
                f"{critique[:1000]}"
            )

        try:
            from agent_comms import reply_to_telegram
            reply_to_telegram(origin["chat_id"], tg_text)
            log.info("orchestrator: telegram reply sent for completed task %s", task_id)
        except Exception:
            log.exception("telegram reply on completion failed")

    # ------------------------------------------------------------------
    # Telegram poll loop — reads from the canonical SQLite archive written by
    # telegram_logger.py. Update_id watermark ensures only new messages fire.
    # ------------------------------------------------------------------
    def _telegram_poll_loop(self) -> None:
        import sqlite3
        from datetime import datetime as _dt
        while not self._stop.is_set():
            try:
                if not self._tg_db_path.is_file():
                    log.debug("telegram_messages.db missing — sleeping")
                else:
                    con = sqlite3.connect(str(self._tg_db_path), timeout=5.0)
                    con.row_factory = sqlite3.Row
                    rows = con.execute(
                        "SELECT update_id, chat_id, from_name, date, text "
                        "FROM messages "
                        "WHERE update_id > ? AND text IS NOT NULL AND text != '' "
                        "ORDER BY update_id ASC LIMIT 50",
                        (self._tg_last_update_id,),
                    ).fetchall()
                    con.close()
                    for r in rows:
                        # Advance watermark BEFORE handling so a handler crash
                        # doesn't cause infinite retry on the same message.
                        self._tg_last_update_id = max(
                            self._tg_last_update_id, int(r["update_id"])
                        )
                        msg = {
                            "ts": _dt.fromtimestamp(int(r["date"])).strftime(
                                "%Y-%m-%d %H:%M:%S"
                            ),
                            "from": r["from_name"] or "?",
                            "chat_id": r["chat_id"],
                            "text": r["text"] or "",
                            "update_id": int(r["update_id"]),
                        }
                        try:
                            self._handle_telegram_message(msg)
                        except Exception:
                            log.exception(
                                "telegram handler error for update_id=%s",
                                msg["update_id"],
                            )
            except Exception:
                log.debug("telegram poll iteration failed", exc_info=True)
            self._stop.wait(self.TG_POLL_INTERVAL)

    def _handle_telegram_message(self, m: dict) -> None:
        """Decide: /delegate => task creation; otherwise => direct Neuro reply."""
        text = (m.get("text") or "").strip()
        chat_id = m.get("chat_id")
        ts = m.get("ts")
        if not text or chat_id is None:
            return

        lowered = text.lower()
        if lowered.startswith("/delegate"):
            self._handle_delegate(text, chat_id, ts)
            return
        if lowered.startswith("/fleet"):
            self._handle_fleet_status(chat_id, ts)
            return
        # Default: direct reply from Neuro
        self._handle_direct_reply(text, chat_id, ts)

    def _handle_direct_reply(self, text: str, chat_id: int, ts: str) -> None:
        """Generate a Neuro response via DeepSeek and send via Telegram."""
        try:
            reply = self._generate_response({"type": "telegram.direct"},
                                            "Decker", text)
        except Exception:
            log.exception("direct-reply generation failed")
            reply = "[neuro-daemon] error generating response — see daemon log."
        try:
            from agent_comms import reply_to_telegram
            reply_to_telegram(
                chat_id, reply,
                auto_action_ts=ts,
                auto_action_summary="direct-reply via NeuroOrchestratorDaemon",
            )
            log.info("orchestrator: direct telegram reply sent (%d chars)", len(reply))
        except Exception:
            log.exception("telegram direct reply send failed")

    def _handle_delegate(self, text: str, chat_id: int, ts: str) -> None:
        """Parse `/delegate <persona> <task description>` and dispatch."""
        # Strip command prefix; rest is "<persona> <task description>"
        rest = text[len("/delegate"):].lstrip()
        parts = rest.split(None, 1)
        from agent_comms import reply_to_telegram, mark_telegram_actioned
        if len(parts) < 2:
            reply_to_telegram(
                chat_id,
                "Usage: /delegate <persona> <task description>\n"
                f"Available personas: {', '.join(sorted(set(PERSONA_TO_AGENT_ID)))}",
                auto_action_ts=ts,
                auto_action_summary="delegate usage hint",
            )
            return
        persona, task_desc = parts[0].lower(), parts[1]
        agent_id = PERSONA_TO_AGENT_ID.get(persona)
        if not agent_id:
            reply_to_telegram(
                chat_id,
                f"Unknown persona '{persona}'.\n"
                f"Try one of: {', '.join(sorted(set(PERSONA_TO_AGENT_ID)))}",
                auto_action_ts=ts,
                auto_action_summary="delegate unknown persona",
            )
            return

        try:
            from aibrain.core.companies import create_task
            title = f"[TG-delegate] {task_desc[:60]}"
            description = (
                f"Delegated from Decker via Telegram by NeuroOrchestratorDaemon.\n\n"
                f"ORIGINAL ASK:\n{task_desc}\n\n"
                f"ACCEPTANCE CRITERIA (default): deliver substantive work_output\n"
                f"addressing the original ask. Include a structured\n"
                f"DONE/DIDN'T TOUCH/VERIFICATION/OPEN CONCERNS block.\n\n"
                f"verify: grep \"agent://\" C:/Users/sinde/projects/aibrain/aibrain/core/agent_comms.py\n"
            )
            task = create_task(
                company_id="GT_LRWrEBQQ",
                title=title,
                description=description,
                assignee_agent_id=agent_id,
                priority="medium",
            )
        except Exception as e:
            log.exception("create_task failed for delegate")
            reply_to_telegram(
                chat_id, f"Delegate failed: {e}", auto_action_ts=ts,
                auto_action_summary="delegate create_task failure",
            )
            return

        task_id = task["id"]
        self._delegated[task_id] = {
            "text": task_desc,
            "chat_id": chat_id,
            "ts": ts,
        }
        reply_to_telegram(
            chat_id,
            f"Delegated to {persona} ({agent_id}). Task {task_id}.\n"
            f"Listener will pick up within 30s via DB-poll; "
            f"I'll Telegram the result when Liaison clears it.",
            auto_action_ts=ts,
            auto_action_summary=f"delegated to {agent_id} task={task_id}",
        )
        log.info("orchestrator: delegated task %s -> agent %s (persona %s)",
                 task_id, agent_id, persona)

    def _handle_fleet_status(self, chat_id: int, ts: str) -> None:
        """`/fleet` => quick status: which agents heartbeating recently."""
        try:
            import sqlite3
            from datetime import datetime
            from aibrain.agents.base_daemon import DB_PATH
            db = sqlite3.connect(DB_PATH)
            db.row_factory = sqlite3.Row
            cur = db.execute(
                "SELECT event_type, source_agent, MAX(created_at) AS last "
                "FROM agent_messages "
                "WHERE event_type LIKE 'fleet.heartbeat.%' "
                "GROUP BY event_type, source_agent "
                "ORDER BY last DESC LIMIT 12"
            )
            lines = ["Fleet heartbeat status (most recent first):"]
            for r in cur.fetchall():
                lines.append(
                    f"  {r['source_agent']:24s} last={r['last']}"
                )
            db.close()
            text = "\n".join(lines)
        except Exception as e:
            text = f"/fleet status query failed: {e}"
        try:
            from agent_comms import reply_to_telegram
            reply_to_telegram(chat_id, text, auto_action_ts=ts,
                              auto_action_summary="/fleet status")
        except Exception:
            log.exception("telegram /fleet send failed")

    # ------------------------------------------------------------------
    # Override run() to add the Telegram polling thread.
    # ------------------------------------------------------------------
    def run(self) -> None:
        log.info("NeuroOrchestratorDaemon starting (agent_id=%s)", self.AGENT_ID)
        tg_thread = threading.Thread(
            target=self._telegram_poll_loop,
            daemon=True,
            name="neuro-orch-tg-poll",
        )
        tg_thread.start()
        log.info(
            "NeuroOrchestratorDaemon Telegram poll thread started (interval=%ss)",
            self.TG_POLL_INTERVAL,
        )
        super().run()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    NeuroOrchestratorDaemon().run()
