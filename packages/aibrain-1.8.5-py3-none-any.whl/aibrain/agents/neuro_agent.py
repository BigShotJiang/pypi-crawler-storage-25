"""aibrain.agents.neuro_agent — Always-on Neuro fleet daemon.

F-NEURO-AGENT-DAEMON-1: closes the cross-agent comms loop when Decker's
interactive Claude Code session is dormant. Subscribes to fleet.message.neuro*
+ fleet.broadcast.* + fleet.test.*. On inbound, dispatches to DeepSeek with
Neuro persona, publishes response back via FleetBus.

Coexists with the interactive Claude Code Neuro via different agent_ids:
- 'neuro' = this daemon
- 'neuro@windows-local' = interactive Claude Code session

Run as: python -m aibrain.agents.neuro_agent
"""
from __future__ import annotations

import logging

from aibrain.agents.base_daemon import AgentDaemon

log = logging.getLogger("aibrain.agents.neuro_agent")

NEURO_SYSTEM_PROMPT = (
    "You are Neuro, the orchestrator agent in DeckerOps. You receive fleet "
    "messages from Lucy, Deep, and Case. Respond concisely with strategic "
    "guidance, task assignments, or acknowledgments. Do not invent facts. "
    "If you cannot help without more context, say so."
)

NEURO_DEFAULT_SUBS = [
    ("neuro-default-direct", "fleet.message.neuro"),
    ("neuro-default-direct-glob", "fleet.message.neuro.*"),
    ("neuro-default-test", "fleet.test.*"),
    ("neuro-default-broadcast", "fleet.broadcast.*"),
    ("neuro-default-handoff", "fleet.handoff.*"),
]


class NeuroDaemon(AgentDaemon):
    """Always-on daemon for Neuro — the fleet's strategy and analysis engine."""

    AGENT_ID = "neuro"
    SYSTEM_PROMPT = NEURO_SYSTEM_PROMPT
    DEFAULT_SUBS = NEURO_DEFAULT_SUBS


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    NeuroDaemon().run()
