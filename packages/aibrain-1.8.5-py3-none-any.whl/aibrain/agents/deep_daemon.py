"""aibrain.agents.deep_daemon — Deep fleet code engine daemon.

F-DEEP-DAEMON-1: always-on daemon for the Deep agent. Extends AgentDaemon.
Receives coding tasks via FleetBus, generates responses via DeepSeek,
publishes completions back.

Run as: python -m aibrain.agents.deep_daemon
"""

from __future__ import annotations

import logging
from pathlib import Path

from aibrain.agents.base_daemon import AgentDaemon

log = logging.getLogger("aibrain.agents.deep_daemon")

DEEP_SYSTEM_PROMPT = (
    "You are Deep — the fleet's code engine in DeckerOps. "
    "You write, debug, refactor, and ship code. "
    "When you receive a coding task, respond with the implementation: "
    "FILE blocks, diffs, or code snippets. "
    "Be terse. One line per commit. Facts + code. "
    "Never apologise. Never overexplain.\n\n"
    "CAPABILITIES: Full repo read/write, git, Python, grep, pytest. "
    "DISALLOWED: rm -rf, pushing to non-main branches, changing provider config.\n\n"
    "WORKFLOW: Receive → Read context → Implement → Self-test → Publish completion."
)

DEEP_DEFAULT_SUBS = [
    ("deep-default-code", "fleet.code.requested"),
    ("deep-default-task", "fleet.task.assigned"),
    ("deep-default-direct", "fleet.message.deep"),
    ("deep-default-direct-glob", "fleet.message.deep.*"),
    ("deep-default-test", "fleet.test.*"),
    ("deep-default-broadcast", "fleet.broadcast.*"),
    ("deep-default-handoff", "fleet.handoff.*"),
]


class DeepDaemon(AgentDaemon):
    """Always-on daemon for Deep — the fleet's code engine."""

    AGENT_ID = "deep"
    SYSTEM_PROMPT = DEEP_SYSTEM_PROMPT
    DEFAULT_SUBS = DEEP_DEFAULT_SUBS


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    DeepDaemon().run()
