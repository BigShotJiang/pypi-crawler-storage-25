"""aibrain.agents.spawn — Fleet agent spawn CLI and lifecycle management.

Canonical: python -m aibrain.agents.spawn spawn --name=fix_agent
CLI wrapper: aibrain agent spawn --name fix_agent

F-AGENT-SPAWN-1. Pick C (hybrid).

Supports personas: default, fix_agent, qa_agent, devops_agent, research_agent,
                   neuro, deep, director
"""

import json
import logging
import os
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

from aibrain.agents.fleet_launcher import _python

log = logging.getLogger("aibrain.agents.spawn")

TEMPLATE_DIR = Path(__file__).parent.parent / "templates" / "agent_persona"

# Built-in persona types that map directly to template
BUILTIN_PERSONAS = {
    "default", "fix_agent", "qa_agent", "devops_agent", "research_agent",
    "neuro", "deep", "director",
}


def _get_db():
    """Get aibrain.db connection."""
    db_path = Path(os.environ.get("AIBRAIN_ROOT", os.getcwd())) / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_endpoints_table(db):
    db.execute("""CREATE TABLE IF NOT EXISTS agent_endpoints (
        agent_id TEXT PRIMARY KEY, agent_name TEXT NOT NULL,
        status TEXT DEFAULT 'stopped', last_seen_at TEXT,
        registered_at TEXT DEFAULT (datetime('now')),
        capabilities TEXT DEFAULT '[]',
        host TEXT DEFAULT 'local',
        persona TEXT DEFAULT ''
    )""")
    db.commit()


def spawn_agent(name: str, persona: str = "default",
                host: str = "local", sandbox: str = "standard") -> dict:
    """Spawn a new fleet agent. Creates workdir, registers, schedules daemon.

    Returns: {"agent_id": ..., "name": ..., "status": ..., "workdir": ...}
    """
    # Validate unique
    db = _get_db()
    _ensure_endpoints_table(db)
    existing = db.execute(
        "SELECT 1 FROM agent_endpoints WHERE agent_name=?", (name,)
    ).fetchone()
    if existing:
        db.close()
        return {"error": f"Agent '{name}' already exists"}
    db.close()

    # Validate persona
    if persona in ("default", "fix_agent", "qa_agent"):
        persona_src = TEMPLATE_DIR / "persona.md"  # generic template
    elif Path(persona).exists():
        persona_src = Path(persona)
    else:
        builtin = TEMPLATE_DIR / "personas" / f"{persona}.md"
        if builtin.exists():
            persona_src = builtin
        else:
            return {"error": f"Persona '{persona}' not found"}

    # Create workdir ~/.aibrain/agents/<name>/
    agent_dir = Path.home() / ".aibrain" / "agents" / name
    for sub in ("work", "memory", "logs"):
        (agent_dir / sub).mkdir(parents=True, exist_ok=True)

    # Copy persona
    persona_dest = agent_dir / "persona.md"
    shutil.copy2(persona_src, persona_dest)

    # Write config.json
    config = {
        "agent_name": name,
        "agent_id": name,
        "persona": persona,
        "host": host,
        "sandbox": sandbox,
        "subscriptions": _default_subscriptions(persona),
        "publications": _default_publications(persona),
        "tools": _default_tools(),
    }
    with open(agent_dir / "config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    # Register in agent_endpoints
    db = _get_db()
    _ensure_endpoints_table(db)
    db.execute(
        """INSERT INTO agent_endpoints (agent_id, agent_name, status, persona, host)
           VALUES (?, ?, 'stopped', ?, ?)""",
        (name, name, persona, host))
    db.commit()
    db.close()

    # Schedule via Windows Task Scheduler
    python_exe = _python()  # headless interpreter (pythonw) — no console popup
    task_name = f"AIBrain_Agent_{name}"

    # Idempotent re-registration: delete prior task so repeated spawns of the
    # same agent REPLACE rather than accumulate duplicate scheduled tasks.
    try:
        subprocess.run(
            ["schtasks.exe", "/Delete", "/TN", task_name, "/F"],
            capture_output=True, text=True)
    except Exception:
        pass

    cmd = [
        "schtasks.exe", "/Create", "/SC", "ONSTART",
        "/TN", task_name,
        "/TR", f'"{python_exe}" -m aibrain.agents.daemon {name}',
        "/F", "/RL", "HIGHEST",
    ]
    try:
        subprocess.run(cmd, capture_output=True, text=True, check=True)
        log.info("Scheduled task created: %s", task_name)
    except subprocess.CalledProcessError as e:
        log.warning("Task Scheduler failed (non-fatal on dev): %s", e.stderr)
    except FileNotFoundError:
        log.warning("schtasks.exe not found — skipping scheduling (dev mode)")

    # Start the scheduled task
    try:
        subprocess.run(
            ["schtasks.exe", "/Run", "/TN", task_name],
            capture_output=True, text=True)
    except Exception:
        pass

    return {
        "agent_id": name,
        "name": name,
        "status": "scheduled",
        "workdir": str(agent_dir),
        "scheduled_task": task_name,
    }


def list_agents() -> list[dict]:
    """List all agents from agent_endpoints."""
    db = _get_db()
    _ensure_endpoints_table(db)
    rows = db.execute(
        "SELECT * FROM agent_endpoints ORDER BY registered_at DESC"
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def stop_agent(name: str) -> dict:
    """Stop a running agent daemon."""
    task_name = f"AIBrain_Agent_{name}"
    try:
        subprocess.run(["schtasks.exe", "/End", "/TN", task_name],
                       capture_output=True, text=True)
    except Exception:
        pass
    db = _get_db()
    db.execute("UPDATE agent_endpoints SET status='stopped' WHERE agent_name=?",
               (name,))
    db.commit()
    db.close()
    return {"name": name, "status": "stopped"}


def start_agent(name: str) -> dict:
    """Start a stopped agent daemon."""
    task_name = f"AIBrain_Agent_{name}"
    try:
        subprocess.run(["schtasks.exe", "/Run", "/TN", task_name],
                       capture_output=True, text=True)
    except Exception:
        pass
    db = _get_db()
    db.execute("UPDATE agent_endpoints SET status='running' WHERE agent_name=?",
               (name,))
    db.commit()
    db.close()
    return {"name": name, "status": "running"}


def remove_agent(name: str, force: bool = False) -> dict:
    """Remove an agent: unschedule task, delete workdir, remove from DB."""
    task_name = f"AIBrain_Agent_{name}"
    try:
        subprocess.run(["schtasks.exe", "/Delete", "/TN", task_name, "/F"],
                       capture_output=True, text=True)
    except Exception:
        pass
    agent_dir = Path.home() / ".aibrain" / "agents" / name
    if agent_dir.exists():
        shutil.rmtree(agent_dir)
    db = _get_db()
    db.execute("DELETE FROM agent_endpoints WHERE agent_name=?", (name,))
    db.execute("DELETE FROM agent_subscriptions WHERE agent_id=?", (name,))
    db.commit()
    db.close()
    return {"name": name, "status": "removed"}


def _default_subscriptions(persona: str) -> list:
    """Return default topic subscriptions per persona type."""
    defaults = {
        "fix_agent": ["fleet.fix.requested"],
        "qa_agent": ["fleet.fix.complete", "fleet.patch.*"],
        "devops_agent": ["fleet.agent.*", "fleet.deploy.*", "fleet.health.*"],
        "research_agent": ["fleet.research.*", "fleet.architecture.*"],
        "neuro": ["fleet.strategy.requested", "fleet.proposal.*",
                   "fleet.market.*", "fleet.message.neuro"],
        "deep": ["fleet.code.requested", "fleet.task.assigned",
                  "fleet.message.deep"],
        "director": ["fleet.task.*", "fleet.agent.*", "fleet.message.director",
                      "fleet.coordination.*"],
        "default": ["fleet.*"],
    }
    return defaults.get(persona, defaults["default"])


def _default_publications(persona: str) -> list:
    """Return default topic publications per persona type."""
    defaults = {
        "fix_agent": ["fleet.fix.complete", "fleet.fix.failed"],
        "qa_agent": ["fleet.qa.verified", "fleet.qa.rejected"],
        "devops_agent": ["fleet.deploy.complete", "fleet.health.status"],
        "research_agent": ["fleet.research.finding", "fleet.research.complete"],
        "neuro": ["fleet.strategy.finding", "fleet.strategy.complete",
                   "fleet.proposal.reviewed"],
        "deep": ["fleet.code.complete", "fleet.code.failed"],
        "director": ["fleet.task.assigned", "fleet.task.reassigned",
                      "fleet.agent.status", "fleet.coordination.summary"],
        "default": ["fleet.*"],
    }
    return defaults.get(persona, defaults["default"])


def _default_tools() -> list:
    from aibrain.templates.agent_persona.tools import get_tools
    return get_tools()


# ── CLI ─────────────────────────────────────────────────────────────

def cli(args: list = None) -> int:
    """CLI entry point. args from sys.argv[2:] when called as 'aibrain agent ...'"""
    if args is None:
        args = sys.argv[1:]

    if not args:
        print("Usage: aibrain agent {spawn|list|stop|start|rm}")
        return 1

    cmd = args[0]
    rest = args[1:]

    if cmd == "spawn":
        name = None
        persona = "default"
        for a in rest:
            if a.startswith("--name="):
                name = a.split("=", 1)[1]
            elif a.startswith("--persona="):
                persona = a.split("=", 1)[1]
        if not name:
            print("Usage: aibrain agent spawn --name=<name> [--persona=<type>]")
            return 1
        result = spawn_agent(name, persona)
        if "error" in result:
            print(f"Error: {result['error']}")
            return 1
        print(f"Agent '{name}' spawned (workdir: {result['workdir']})")
        print(f"  Scheduled task: {result['scheduled_task']}")
        print(f"  Status: {result['status']}")
        return 0

    elif cmd == "list":
        agents = list_agents()
        if not agents:
            print("No agents registered.")
            return 0
        print(f"{'AGENT ID':20s} {'NAME':20s} {'STATUS':10s} {'PERSONA':15s} {'HOST':10s}")
        print("-" * 75)
        for a in agents:
            print(f"{a['agent_id']:20s} {a['agent_name']:20s} "
                  f"{a['status']:10s} {a.get('persona', ''):15s} "
                  f"{a.get('host', 'local'):10s}")
        return 0

    elif cmd == "stop":
        if not rest:
            print("Usage: aibrain agent stop <name>")
            return 1
        result = stop_agent(rest[0])
        print(f"Agent '{result['name']}' {result['status']}")
        return 0

    elif cmd == "start":
        if not rest:
            print("Usage: aibrain agent start <name>")
            return 1
        result = start_agent(rest[0])
        print(f"Agent '{result['name']}' {result['status']}")
        return 0

    elif cmd == "rm":
        if not rest:
            print("Usage: aibrain agent rm <name>")
            return 1
        result = remove_agent(rest[0])
        print(f"Agent '{result['name']}' {result['status']}")
        return 0

    else:
        print(f"Unknown subcommand: {cmd}")
        print("Usage: aibrain agent {spawn|list|stop|start|rm}")
        return 1


if __name__ == "__main__":
    sys.exit(cli())
