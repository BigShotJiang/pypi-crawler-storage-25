"""aibrain.agents.task_bridge — Bridge between company task system and FleetBus.

F-TASK-BRIDGE-1: When a company task is assigned to a fleet agent (neuro/deep/director),
publish a notification to fleet.task.assigned so the agent's daemon picks it up.

Usage:
    from aibrain.agents.task_bridge import notify_agent_of_task
    notify_agent_of_task(task_id, "deep", {"title": "...", "description": "..."})

Replies come back to Lucy — the from field is set to "lucy" so daemon responses
route to fleet.message.lucy, which the Lucy CLI polls and displays.
"""

from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger("aibrain.agents.task_bridge")

# Map company assignee_agent_ids to fleet agent names
AGENT_ID_TO_FLEET_NAME = {
    "CDTYrHYkyH8": "deep",    # Lead Engineer
    "9IXqSnCBLLQ": "deep",    # QA Lead → also Deep for now
    "v_sJ2kha1EQ": "neuro",   # Security Engineer → Neuro
    "RFYhIipppGs": "neuro",   # Research Analyst → Neuro
    "RztUQUCs-h4": "neuro",   # Content Writer → Neuro
    "I5JwaUTVUps": "deep",    # DevOps Engineer → Deep
}

FLEET_AGENT_NAMES = {"neuro", "deep", "director"}


def notify_agent_of_task(task_id: str, assignee_agent_id: str,
                         task_data: dict | None = None) -> bool:
    """Publish a fleet.task.assigned message for a given task.

    Args:
        task_id: Company task ID (e.g. 'bo3l5K-SUoM')
        assignee_agent_id: Company agent ID (e.g. 'CDTYrHYkyH8')
        task_data: Optional dict with title, description, priority

    Returns:
        True if published, False if no fleet agent mapped
    """
    fleet_name = AGENT_ID_TO_FLEET_NAME.get(assignee_agent_id)
    if not fleet_name:
        log.debug("No fleet agent mapped for company agent %s", assignee_agent_id)
        return False

    try:
        from aibrain.core.agent_comms import FleetBus
        bus = FleetBus(agent_id="task_bridge")

        payload = {
            "task_id": task_id,
            "assignee_agent_id": assignee_agent_id,
            "fleet_agent": fleet_name,
            "action": "assigned",
            "from": "lucy",  # Replies come back to Lucy
        }
        if task_data:
            payload.update(task_data)

        bus.publish("fleet.task.assigned", payload)
        log.info("Published fleet.task.assigned: task=%s → %s", task_id, fleet_name)
        return True
    except Exception as e:
        log.warning("Failed to publish task notification: %s", e)
        return False


def notify_task_closed(task_id: str, assignee_agent_id: str) -> bool:
    """Publish a fleet.task.closed message."""
    fleet_name = AGENT_ID_TO_FLEET_NAME.get(assignee_agent_id)
    if not fleet_name:
        return False

    try:
        from aibrain.core.agent_comms import FleetBus
        bus = FleetBus(agent_id="task_bridge")
        bus.publish("fleet.task.closed", {
            "task_id": task_id,
            "fleet_agent": fleet_name,
            "action": "closed",
            "from": "lucy",
        })
        return True
    except Exception as e:
        log.warning("Failed to publish task close: %s", e)
        return False
