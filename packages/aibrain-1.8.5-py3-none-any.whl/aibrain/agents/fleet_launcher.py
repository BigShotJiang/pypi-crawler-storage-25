"""aibrain.agents.fleet_launcher — Start all fleet daemons as subprocesses.

F-FLEET-LAUNCH-1: Launches neuro, deep, director daemons as independent
subprocesses so they survive the parent. Each runs in its own Python process.
Use pythonw for headless operation.

Usage:
    python -m aibrain.agents.fleet_launcher          # blocking, stdout
    pythonw -m aibrain.agents.fleet_launcher         # headless background
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
import time
from pathlib import Path

log = logging.getLogger("aibrain.agents.fleet_launcher")

DAEMONS = {
    "neuro": "aibrain.agents.neuro_agent",
    "deep": "aibrain.agents.deep_daemon",
    "director": "aibrain.agents.director_daemon",
}


def _python() -> str:
    """Return path to pythonw (headless) or python."""
    pythonw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if os.path.exists(pythonw):
        return pythonw
    return sys.executable


def launch_fleet(headless: bool = False) -> dict[str, subprocess.Popen]:
    """Start all fleet daemons. Returns dict of agent_name → Popen."""
    processes = {}
    python_exe = _python() if headless else sys.executable

    for agent_name, module in DAEMONS.items():
        log.info("Launching %s daemon (%s)...", agent_name, module)
        try:
            proc = subprocess.Popen(
                [python_exe, "-m", module],
                stdout=subprocess.DEVNULL if headless else None,
                stderr=subprocess.DEVNULL if headless else None,
                creationflags=subprocess.CREATE_NO_WINDOW if headless else 0,
                cwd=str(Path(__file__).resolve().parent.parent.parent),
            )
            processes[agent_name] = proc
            log.info("  %s: PID=%d", agent_name, proc.pid)
        except Exception as e:
            log.error("  %s: FAILED — %s", agent_name, e)

    return processes


def check_fleet(processes: dict[str, subprocess.Popen]) -> dict[str, str]:
    """Check which daemons are still alive."""
    status = {}
    for name, proc in processes.items():
        if proc.poll() is None:
            status[name] = "running"
        else:
            status[name] = f"exited (rc={proc.returncode})"
    return status


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    headless = "--headless" in sys.argv
    log.info("Fleet launcher starting (headless=%s)", headless)
    procs = launch_fleet(headless=headless)

    if not procs:
        log.error("No daemons launched — exiting")
        sys.exit(1)

    log.info("All daemons launched. Monitoring...")
    try:
        while True:
            status = check_fleet(procs)
            alive = sum(1 for s in status.values() if s == "running")
            log.info("Fleet status: %d/%d alive — %s", alive, len(procs), status)
            if alive == 0:
                log.error("All daemons died — exiting")
                break
            time.sleep(60)
    except KeyboardInterrupt:
        log.info("Shutting down fleet...")
        for name, proc in procs.items():
            if proc.poll() is None:
                log.info("Terminating %s (PID=%d)...", name, proc.pid)
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
        log.info("Fleet stopped.")
