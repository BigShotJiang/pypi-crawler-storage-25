"""aibrain/cli/demo.py — demo entry points for AIBrain.

Two demos:
  run_demo()         — 30-second memory before/after demo (used by setup wizard)
  run_liaison_demo() — 6-scene Liaison gate FAIL->retry->PASS cycle (aibrain-demo)

Both are zero API keys, zero network calls, standalone after pip install aibrain.
"""
from __future__ import annotations
import sys
import time
import json
import threading


def _c(style: str, text: str) -> str:
    codes = {
        "bold":   "\033[1m",
        "dim":    "\033[2m",
        "green":  "\033[32m",
        "yellow": "\033[33m",
        "teal":   "\033[36m",
        "reset":  "\033[0m",
    }
    return f"{codes.get(style, '')}{text}{codes['reset']}"


def run_demo(brain_name: str = "your brain") -> None:
    print()
    print(f"  {_c('teal', '─' * 52)}")
    print(f"  {_c('bold', 'The 30-second memory demo')}")
    print(f"  {_c('teal', '─' * 52)}")
    print()
    time.sleep(0.3)

    print(f"  {_c('yellow', 'WITHOUT AIBrain:')} {_c('dim', 'your agent starts fresh every session')}")
    print()

    for speaker, line in [
        ("You",   "My API key is sk-proj-XXXX. Save it."),
        ("Agent", "Got it! I'll remember that."),
        ("—",     "[ New session ]"),
        ("You",   "What was my API key?"),
        ("Agent", "I don't have access to previous conversations."),
        ("You",   "I just told you this."),
        ("Agent", "I'm sorry — each session starts fresh."),
    ]:
        if speaker == "—":
            time.sleep(0.2)
            print(f"\n    {_c('dim', line)}\n")
            time.sleep(0.2)
        elif speaker == "You":
            time.sleep(0.15)
            print(f"    {_c('bold', 'You:  ')}{line}")
        else:
            time.sleep(0.15)
            print(f"    {_c('dim', 'AI:   ')}{_c('dim', line)}")

    print()
    time.sleep(0.4)

    print(f"  {_c('green', 'WITH AIBrain:')} {_c('dim', 'memories persist — forever')}")
    print()

    for speaker, line in [
        ("You",   "My API key is sk-proj-XXXX. Save it."),
        ("Agent", f"Stored in {brain_name}. I'll never forget this."),
        ("—",     f"[ New session — {brain_name} loaded ]"),
        ("You",   "What was my API key?"),
        ("Agent", "Your API key is sk-proj-XXXX — stored 3 days ago."),
        ("You",   "Perfect."),
        ("Agent", "Always. That's what I'm here for."),
    ]:
        if speaker == "—":
            time.sleep(0.2)
            print(f"\n    {_c('dim', line)}\n")
            time.sleep(0.2)
        elif speaker == "You":
            time.sleep(0.15)
            print(f"    {_c('bold', 'You:  ')}{line}")
        else:
            time.sleep(0.15)
            print(f"    {_c('green', 'AI:   ')}{line}")

    print()
    time.sleep(0.3)

    spinner_frames = ["|", "/", "-", "\\"]
    stop = threading.Event()

    def _spin():
        i = 0
        while not stop.is_set():
            print(f"\r  {_c('teal', spinner_frames[i % len(spinner_frames)])} {_c('dim', f'Loading {brain_name}...')}  ",
                  end="", flush=True)
            time.sleep(0.1)
            i += 1

    t = threading.Thread(target=_spin, daemon=True)
    t.start()
    time.sleep(2.0)
    stop.set()
    t.join(timeout=0.5)

    print(f"\r  {_c('green', '[OK]')} {_c('bold', brain_name)} is ready.{' ' * 30}")
    print()
    print(f"  {_c('teal', 'Your agent will now remember everything.')}")
    print()


# ---------------------------------------------------------------------------
# aibrain-demo: Liaison gate FAIL -> retry -> PASS cycle (zero API keys)
# ---------------------------------------------------------------------------

# ANSI helpers for composite styles (extends the basic _c() above)
_ANSI = {
    "reset":       "\033[0m",
    "bold":        "\033[1m",
    "dim":         "\033[2m",
    "red":         "\033[31m",
    "green":       "\033[32m",
    "yellow":      "\033[33m",
    "teal":        "\033[36m",
    "bold_red":    "\033[1;31m",
    "bold_green":  "\033[1;32m",
    "bold_yellow": "\033[1;33m",
    "bold_teal":   "\033[1;36m",
    "dim_green":   "\033[2;32m",
    "dim_teal":    "\033[2;36m",
}


def _cc(style: str, text: str) -> str:
    """Color helper for the Liaison demo — supports composite styles."""
    return f"{_ANSI.get(style, '')}{text}{_ANSI['reset']}"


_FIXTURE = {
    "task_id": "Iy80OK0PLa0",
    "title": "Wire Liaison gate auto-trigger for medium-priority tasks",
    "agent_id": "CDTYrHYkyH8",
    "special_liaison_id": "bwHDCnvlGFY",
    "round1": {
        "quality_score": 0.55,
        "verdict": "FAIL",
        "work_output": (
            'DONE:\n'
            '- create_task(): added review_required=1 for medium-priority tasks.\n\n'
            'VERIFICATION:\n'
            '- grep review_required aibrain/core/companies.py  (shows flag set)\n\n'
            'OPEN CONCERNS:\n'
            '- None'
        ),
        "critique": (
            'Gate condition not verified. create_task() sets review_required=1\n'
            'but complete_task() does not query execution_log for a PASS row\n'
            'before closing. Author self-review bypass still possible.\n'
            'Criterion 2 not met: no substance check that the guard fires.'
        ),
    },
    "round2": {
        "quality_score": 0.92,
        "verdict": "PASS",
        "source": "agent_review",
        "note": "Guard confirmed. Criterion 2 verified. Scope clean.",
    },
    "fix_diff": (
        '+  # Guard: query execution_log for actor=\'special_liaison\' PASS row\n'
        '+  if not liaison_pass_row:\n'
        '+      raise TaskReviewFailed(\'No Liaison PASS found for this task\')'
    ),
    "memory_writes": [
        "[episodic]  task Iy80OK0PLa0 — FAIL 0.55 -> PASS 0.92 stored",
        "[semantic]  Liaison gate: medium tasks need execution_log PASS before close",
        "[pattern]   Fix the holes, not bail the water — structural guard over patch",
    ],
}


def _typewriter(text: str, delay: float = 0.015) -> None:
    """Print text character-by-character (stdlib only)."""
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        if ch != '\n':
            time.sleep(delay)
    if not text.endswith('\n'):
        sys.stdout.write('\n')
    sys.stdout.flush()


def _run_spinner(message: str, duration: float) -> None:
    """Run a spinner for <duration> seconds then clear the line."""
    frames = ["|", "/", "-", "\\"]
    stop_event = threading.Event()

    def _spin() -> None:
        i = 0
        while not stop_event.is_set():
            frame = frames[i % len(frames)]
            sys.stdout.write(f"\r{_ANSI['teal']}{frame} {message}{_ANSI['reset']}")
            sys.stdout.flush()
            time.sleep(0.1)
            i += 1
        sys.stdout.write("\r" + " " * (len(message) + 4) + "\r")
        sys.stdout.flush()

    t = threading.Thread(target=_spin, daemon=True)
    t.start()
    time.sleep(duration)
    stop_event.set()
    t.join(timeout=1.0)


def _scene_header(n: int, total: int, title: str) -> None:
    print()
    print(_cc("bold_yellow", f"  ─── Scene {n}/{total}: {title} ───"))
    print()
    time.sleep(0.6)


def run_liaison_demo() -> None:
    """6-scene Liaison gate FAIL->retry->PASS demo. Zero API keys."""
    try:
        # ── Scene 1: Agent submits task ──────────────────────────────────────
        _scene_header(1, 6, "Agent submits task")
        payload = {
            "task_id":       _FIXTURE["task_id"],
            "title":         _FIXTURE["title"],
            "agent_id":      _FIXTURE["agent_id"],
            "work_output":   _FIXTURE["round1"]["work_output"],
            "quality_score": _FIXTURE["round1"]["quality_score"],
        }
        print(_cc("dim", json.dumps(payload, indent=2)))
        print()
        time.sleep(1.5)
        print(_cc("teal", "  Firing inline Liaison review via claude CLI..."))
        time.sleep(1.5)

        # ── Scene 2: Liaison reviews — FAIL ──────────────────────────────────
        _scene_header(2, 6, "Special Liaison reviews — FAIL")
        _run_spinner("Special Liaison reviewing", 2.5)
        print(_cc("bold_red",  "  VERDICT: FAIL"))
        print(_cc("red",       "  SCORE:   0.55"))
        print(_cc("bold_red",  "  CRITIQUE:"))
        critique = _FIXTURE["round1"]["critique"]
        for line in critique.splitlines():
            sys.stdout.write(_ANSI["red"] + "    " + line + _ANSI["reset"] + "\n")
            sys.stdout.flush()
            time.sleep(0.8)
        print()
        print(_cc("red", "  TaskReviewFailed raised — task stays open."))
        print(_cc("dim", "  source='agent_review' verdict=FAIL does NOT clear the gate."))
        time.sleep(0.5)

        # ── Scene 3: Agent reads critique, revises ────────────────────────────
        _scene_header(3, 6, "Agent reads critique and revises")
        print(_cc("dim", "  Critique: " + critique.splitlines()[0] + "..."))
        print()
        _run_spinner("Agent applying structural fix", 3.0)
        print(_cc("dim_green", "  Patch applied:"))
        for diff_line in _FIXTURE["fix_diff"].splitlines():
            _typewriter(_cc("dim_green", "    " + diff_line), delay=0.02)
        time.sleep(0.5)

        # ── Scene 4: Liaison reviews — PASS ──────────────────────────────────
        _scene_header(4, 6, "Re-submitting for Liaison review")
        _run_spinner("Re-submitting for Liaison review", 2.5)
        print(_cc("bold_green", "  VERDICT: PASS"))
        print(_cc("green",      "  SCORE:   0.92"))
        print(_cc("green",      "  SOURCE:  agent_review   ← only source that clears the gate"))
        print(_cc("green",      f"  NOTE:    {_FIXTURE['round2']['note']}"))
        print()
        print(_cc("bold_green", "  Task status → done"))
        time.sleep(1.0)

        # ── Scene 5: Memory stored ────────────────────────────────────────────
        _scene_header(5, 6, "Brain stores the outcome")
        for mem in _FIXTURE["memory_writes"]:
            print(_cc("dim", "  " + mem))
            time.sleep(0.8)
        print()
        print(_cc("dim_teal", "  Nightly dream cycle will consolidate episodic → semantic."))
        time.sleep(1.0)

        # ── Scene 6: Summary stats ────────────────────────────────────────────
        _scene_header(6, 6, "Session summary")
        rows = [
            ("Tasks completed:",  "1"),
            ("Liaison reviews:",  "2  (1 FAIL, 1 PASS)"),
            ("Gate catches:",     "1  silent failure prevented"),
            ("Routing decision:", "complex → claude-sonnet-4-6  (judgment task)"),
            ("Quality score:",    "0.92"),
            ("Learning signal:",  "1 correction → evolution_outcomes"),
        ]
        for label, value in rows:
            print(_cc("bold_teal", f"  {label:<20} {value}"))
        print()
        print(_cc("teal", "  " + "─" * 52))
        print(_cc("bold",  "  aibrain — the brain that gets better every run"))
        print(_cc("dim",   "  pip install aibrain  |  myaibrain.org"))
        print()
        time.sleep(1.0)

    except KeyboardInterrupt:
        print()
        sys.exit(0)


def main() -> None:
    run_liaison_demo()


if __name__ == "__main__":
    main()
