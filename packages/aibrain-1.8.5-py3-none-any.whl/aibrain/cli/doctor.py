"""aibrain/cli/doctor.py — health check that doesn't report the same file twice.

Fixes in this version vs. what the transcript showed:
  1. DB dedup uses resolved absolute paths, not raw paths. Two discoveries of
     the same file via different search methods collapse to one row.
  2. Schema check now checks for evolution_outcomes (it was missing before).
  3. Does NOT attempt to download a desktop installer from a 404 URL.
     That's the setup wizard's concern, and it should read the current version
     from pyproject/package metadata rather than hardcoding 'v1.5.12'.
  4. Reports problems honestly — exit code reflects reality.
"""
from __future__ import annotations
import os
import sys
import sqlite3
from pathlib import Path

# Gap 5 — share REQUIRED_TABLES with setup_wizard (single source of truth)
from aibrain.cli.setup_wizard import REQUIRED_TABLES
from aibrain.cli.utils import clickable


def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if sys.stdout.isatty() else text
def _green(t): return _c("32", t)
def _red(t): return _c("31", t)
def _yellow(t): return _c("33", t)
def _dim(t): return _c("2", t)
def _bold(t): return _c("1", t)


def _canonical_root() -> Path:
    """Where should aibrain.db live?"""
    env = os.environ.get("AIBRAIN_ROOT")
    if env:
        return Path(env)
    return Path.home() / "aibrain"


def _find_all_dbs() -> list[Path]:
    """Find every aibrain.db on the system, deduplicated by resolved path.

    THIS is the fix for the 'Found 2 DB files' bug — the transcript showed
    the same canonical path listed twice because the old code found it via
    two different enumeration methods and forgot to dedup.
    """
    search_roots = [
        Path.home() / "aibrain",
        Path.home() / ".aibrain",
        Path.cwd(),
    ]
    # Windows: also check AppData
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA")
        if appdata:
            search_roots.append(Path(appdata) / "aibrain")
        localappdata = os.environ.get("LOCALAPPDATA")
        if localappdata:
            search_roots.append(Path(localappdata) / "aibrain")

    found_resolved: set[Path] = set()
    results: list[Path] = []
    for root in search_roots:
        if not root.exists():
            continue
        for candidate in root.rglob("aibrain.db"):
            # Resolve symlinks and relative components so two paths that
            # point at the same file collapse to one entry.
            try:
                resolved = candidate.resolve()
            except Exception:
                continue
            if resolved in found_resolved:
                continue
            found_resolved.add(resolved)
            results.append(resolved)
    return results


def _schema_check(db_path: Path) -> tuple[list, list]:
    """Return (present_tables, missing_tables)."""
    try:
        conn = sqlite3.connect(str(db_path))
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
        conn.close()
        present = {r[0] for r in rows}
        missing = [t for t in REQUIRED_TABLES if t not in present]
        return sorted(present), missing
    except Exception as exc:
        return [], [f"<error: {exc}>"]


def _current_version() -> str:
    """Read the installed aibrain version. Don't hardcode."""
    try:
        from importlib.metadata import version
        return version("aibrain")
    except Exception:
        return "unknown"


def main() -> int:
    print()
    print(_bold("  aibrain doctor"))
    print(_dim("  " + "─" * 40))
    print()

    canonical = _canonical_root()
    canonical_db = canonical / "aibrain.db"

    print(f"  Canonical root:    {clickable(canonical)}")
    print(f"  Canonical DB:      {clickable(canonical_db)}")
    print(f"  Canonical exists:  {'yes' if canonical_db.exists() else 'NO'}")
    if canonical_db.exists():
        size = canonical_db.stat().st_size
        print(f"  Canonical size:    {size:,} bytes")
    print(f"  aibrain version:   {_current_version()}")
    print()

    # Find all DBs (properly deduped)
    all_dbs = _find_all_dbs()
    print(f"  aibrain.db files found on system: {len(all_dbs)}")
    for db in all_dbs:
        marker = _green("[CANONICAL]") if db == canonical_db.resolve() else _yellow("[OTHER]   ")
        size = db.stat().st_size if db.exists() else 0
        print(f"    {marker} {clickable(db)}  ({size:,} bytes)")
    print()

    problems = []

    # Schema check on canonical DB only
    if canonical_db.exists():
        present, missing = _schema_check(canonical_db)
        if missing:
            print(_red(f"  ✗ Schema check: MISSING tables {missing}"))
            problems.append(f"missing_tables: {missing}")
            print(_dim("    Fix: aibrain setup  (re-runs schema creation, idempotent)"))
        else:
            print(_green(f"  ✓ Schema check: all {len(REQUIRED_TABLES)} required tables present"))
    else:
        print(_red("  ✗ Canonical DB does not exist"))
        problems.append("canonical_db_missing")
        print(_dim("    Fix: aibrain setup"))

    # Rogue DB check (excluding canonical)
    rogues = [db for db in all_dbs if db != canonical_db.resolve()]
    if rogues:
        print(_yellow(f"  ⚠ {len(rogues)} non-canonical DB file(s) — these may be shadows"))
        for r in rogues:
            print(_dim(f"    {clickable(r)}"))
        print(_dim("    Fix: aibrain migrate-shadow <path> to merge into canonical"))

    print()
    print(_dim("  " + "─" * 40))
    if problems:
        print(_red(_bold(f"  STATUS: {len(problems)} problem(s) detected")))
        print()
        return 1
    else:
        print(_green(_bold("  STATUS: healthy")))
        print()
        return 0


if __name__ == "__main__":
    sys.exit(main())
