"""
AIbrain share subcommand: public read-only link for a task run.

`aibrain share <run_id>` exports the run transcript + Liaison verdict +
diff summary to Cloudflare R2 and returns a short share URL.

Requires Cloudflare R2 credentials in environment variables:
  CLOUDFLARE_ACCOUNT_ID
  CLOUDFLARE_R2_ACCESS_KEY_ID
  CLOUDFLARE_R2_SECRET_ACCESS_KEY
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import sys
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any

import boto3
from botocore.client import Config as BotoConfig

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Database helpers
# ------------------------------------------------------------------

def _get_aibrain_root() -> str:
    """Return the brain data directory, defaulting to ~/.aibrain."""
    root = os.environ.get("AIBRAIN_ROOT")
    if root:
        return os.path.expanduser(root)
    # Typical AIbrain default – may be configurable via settings.
    # Fallback to the documented default location.
    return os.path.expanduser(os.path.join("~", ".aibrain"))


def _get_db_path() -> str:
    """Absolute path to the SQLite database file."""
    return os.path.join(_get_aibrain_root(), "aibrain.db")


def _get_conn() -> sqlite3.Connection:
    """Open and return a read-only SQLite connection."""
    db_path = _get_db_path()
    if not os.path.exists(db_path):
        raise FileNotFoundError(
            f"AIbrain database not found at {db_path}. Run 'aibrain init' first."
        )
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def _find_run(run_id: str) -> Dict[str, Any]:
    """
    Look up an execution log row by id or dispatch_id.
    Returns a dict of the row, or raises ValueError if not found.
    """
    conn = _get_conn()
    try:
        cursor = conn.cursor()
        # attempt exact match on integer id if run_id looks numeric,
        # then fall back to dispatch_id string match.
        try:
            numeric_id = int(run_id)
            cursor.execute(
                "SELECT * FROM execution_log WHERE id = ?",
                (numeric_id,),
            )
            row = cursor.fetchone()
            if row:
                return dict(row)
        except ValueError:
            pass  # not an integer

        # Try dispatch_id
        cursor.execute(
            "SELECT * FROM execution_log WHERE dispatch_id = ?",
            (run_id,),
        )
        row = cursor.fetchone()
        if row:
            return dict(row)

        raise ValueError(f"No execution_log row found for run_id='{run_id}'")
    finally:
        conn.close()


def _get_issue(issue_id: int) -> Dict[str, Any]:
    """Look up a company_issues row by id."""
    conn = _get_conn()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM company_issues WHERE id = ?", (issue_id,))
        row = cursor.fetchone()
        if not row:
            raise ValueError(f"No company_issues row with id={issue_id}")
        return dict(row)
    finally:
        conn.close()


# ------------------------------------------------------------------
# Share logic
# ------------------------------------------------------------------

def _generate_share_id(run_id: str, timestamp: float) -> str:
    """Return first 12 hex characters of sha256(run_id + timestamp)."""
    raw = f"{run_id}{timestamp}".encode()
    return hashlib.sha256(raw).hexdigest()[:12]


def _extract_diff_summary(work_output: Optional[str]) -> List[str]:
    """
    Parse the DONE section of a work_output to produce a list of
    changed files/directories.  Returns an empty list if nothing parsed.
    """
    if not work_output:
        return []

    lines = work_output.splitlines()
    collecting = False
    files = []
    for line in lines:
        stripped = line.strip()
        if stripped.upper().startswith("DONE"):
            collecting = True
            continue
        if stripped.upper().startswith("DIDN'T TOUCH") or stripped.upper().startswith("VERIFICATION"):
            break
        if collecting and stripped.startswith("-"):
            # typical format: "- [/path/to/file]: description"
            entry = stripped[1:].strip()
            # keep only the path part before ':'
            path = entry.split(":", 1)[0].strip()
            if path:
                files.append(path)
    return files


def _build_share_blob(
    run_id: str,
    exec_row: Dict[str, Any],
    issue_row: Dict[str, Any],
    now: datetime,
) -> Dict[str, Any]:
    """Assemble the JSON object stored in R2."""
    # Determine transcript – output field from execution_log.
    transcript = exec_row.get("output", "")
    if isinstance(transcript, bytes):
        transcript = transcript.decode("utf-8", errors="replace")

    verdict = issue_row.get("work_output", "")
    quality_score = issue_row.get("quality_score")

    diff_summary = _extract_diff_summary(verdict)

    expires_at = now + timedelta(days=30)

    blob = {
        "run_id": run_id,
        "title": issue_row.get("title", "Untitled Run"),
        "transcript": transcript,
        "liaison_verdict": verdict,
        "diff_summary": diff_summary,
        "quality_score": quality_score,
        "shared_at": now.replace(tzinfo=timezone.utc).isoformat(),
        "expires_at": expires_at.replace(tzinfo=timezone.utc).isoformat(),
    }
    return blob


def _get_r2_client() -> boto3.client:
    """Create a boto3 S3 client for Cloudflare R2."""
    account_id = os.environ.get("CLOUDFLARE_ACCOUNT_ID")
    access_key = os.environ.get("CLOUDFLARE_R2_ACCESS_KEY_ID")
    secret_key = os.environ.get("CLOUDFLARE_R2_SECRET_ACCESS_KEY")

    if not all((account_id, access_key, secret_key)):
        missing = [k for k in ("CLOUDFLARE_ACCOUNT_ID", "CLOUDFLARE_R2_ACCESS_KEY_ID", "CLOUDFLARE_R2_SECRET_ACCESS_KEY") if not os.environ.get(k)]
        raise EnvironmentError(
            f"Missing Cloudflare R2 credentials: {', '.join(missing)}. "
            "Set them in ~/.decker_env or export them."
        )

    endpoint = f"https://{account_id}.r2.cloudflarestorage.com"
    return boto3.client(
        "s3",
        endpoint_url=endpoint,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        config=BotoConfig(signature_version="s3v4"),
    )


def share_run(run_id: str) -> str:
    """
    Export a run's transcript + verdict to Cloudflare R2 and return the
    public share URL.

    Args:
        run_id: The execution_log id or dispatch_id.

    Returns:
        Full URL of the share page (https://myaibrain.org/r/<share_id>).

    Raises:
        ValueError: if run_id not found.
        EnvironmentError: if R2 credentials are missing.
        boto3 exceptions: on upload failure.
    """
    exec_row = _find_run(run_id)
    task_id = exec_row.get("task_id")
    if task_id is None:
        raise ValueError("execution_log row has no task_id")

    issue_row = _get_issue(int(task_id))

    now = datetime.now(timezone.utc)
    share_id = _generate_share_id(run_id, now.timestamp())
    blob = _build_share_blob(run_id, exec_row, issue_row, now)

    client = _get_r2_client()
    bucket = "aibrain-shares"
    key = f"{share_id}.json"

    client.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(blob, indent=2, ensure_ascii=False).encode("utf-8"),
        ContentType="application/json",
        # Optional: tag with expiration note; worker enforces.
    )

    url = f"https://myaibrain.org/r/{share_id}"
    logger.info("Share uploaded successfully: %s", url)
    return url


# ------------------------------------------------------------------
# CLI integration
# ------------------------------------------------------------------

def register_parser(subparsers: "argparse._SubParsersAction") -> None:
    """Register the 'share' subcommand."""
    parser = subparsers.add_parser(
        "share",
        help="Create a public share link for a task run (<run_id>)",
        description="Generates a read-only public link containing the run transcript, Liaison verdict, and diff summary.",
    )
    parser.add_argument(
        "run_id",
        metavar="run_id",
        help="The execution_log id or dispatch_id of the run to share.",
    )
    parser.set_defaults(func=run)


def run(args: "argparse.Namespace") -> None:
    """Entry point when the 'share' subcommand is invoked."""
    try:
        url = share_run(args.run_id)
        print(f"Share link created: {url}")
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
