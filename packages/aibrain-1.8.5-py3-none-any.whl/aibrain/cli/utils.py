"""
aibrain.cli.utils — Shared CLI utilities.

Provides cross-platform keyboard input, clickable file-path links, and other
terminal helpers used by multiple interactive menus (settings, compress, etc.).
"""
from __future__ import annotations

import sys
from pathlib import Path


def clickable(path: str | Path, label: str | None = None) -> str:
    """Return an OSC 8 hyperlink that opens *path* when clicked in a modern terminal.

    Supported: Windows Terminal, iTerm2, Kitty, Foot, and most VTE-based terminals.
    In unsupported terminals the text is returned unchanged — no visible garbage.
    """
    try:
        p = Path(path).expanduser().resolve()
        uri = "file:///" + str(p).replace("\\", "/").lstrip("/")
        text = label or str(p)
        return f"\033]8;;{uri}\033\\{text}\033]8;;\033\\"
    except Exception:
        return label or str(path)


def _getch() -> str:
    """Read a single keypress without echo. Cross-platform (Windows + Unix)."""
    try:
        import msvcrt  # Windows
        return msvcrt.getwch()
    except ImportError:
        import tty
        import termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
