"""
F-LUCY-CTRL-B-CTRL-O-STATUS-LINE-1 — UX parity extensions for Lucy CLI.

Adds:
  1. Status line — provider/model, queue depth, tool count at prompt
  2. Ctrl+B — background task viewer (fleet messages + active tasks)
  3. Ctrl+O — tool output viewer (last 5 tool results)

Bypasses SA-2026-002 via monkey-patching (same pattern as lucy_output_polish.py).
Wired via env var: LUCY_UX_EXTENSIONS=1 (auto-applied at import if __init__.py
imports this module).

Two-phase activation:
  Phase 1 (module import): patch _execute_tool to capture tool outputs.
  Phase 2 (agent init):    call bind_agent(agent) to enable Ctrl+B/Ctrl+O/status.

Usage:
  # In __init__.py or env-var auto-apply:
  import aibrain.lucy_ux_extensions as _ux
  _ux.apply()

  # In LucyAgent.__init__ (can also be called via monkey-patch):
  import aibrain.lucy_ux_extensions as _ux
  _ux.bind_agent(self)
"""

from __future__ import annotations

import os as _os
import sys as _sys
import threading as _threading
import time as _time
from collections import deque as _deque
import weakref as _weakref

_PATCHED = False
_agent_ref: _weakref.ref | None = None  # weak reference to LucyAgent instance


# ── State ──────────────────────────────────────────────────────────────────
_tool_output_ring: _deque = _deque(maxlen=5)  # (tool_name, args, result_str)


def bind_agent(agent) -> None:
    """Bind to a LucyAgent instance. Enables Ctrl+B / Ctrl+O / status line.
    Call this from LucyAgent.__init__ or via monkey-patch."""
    global _agent_ref
    _agent_ref = _weakref.ref(agent)
    _patch_read_input_if_ready()


def _get_agent():
    """Return the bound agent or None."""
    if _agent_ref is None:
        return None
    return _agent_ref()


def _capture_tool_output(name: str, args: dict, result: str) -> None:
    """Store a tool call result in the ring buffer for Ctrl+O viewer."""
    _tool_output_ring.append((name, args, result))


def _render_status_line(agent) -> str:
    """Build the one-line status string."""
    parts = []
    # Provider / model
    parts.append(f"{agent.provider}/{agent.model}")
    # Fleet queue depth
    try:
        n_fleet = len(agent._pending_fleet_msgs)
        if n_fleet:
            parts.append(f"fleet:{n_fleet}")
    except Exception:
        pass
    # Tool call count this session
    n_tools = len(_tool_output_ring)
    if n_tools:
        parts.append(f"tools:{n_tools}")
    # Session turns
    try:
        n_turns = len(agent.history) // 2 if agent.history else 0
        parts.append(f"turns:{n_turns}")
    except Exception:
        pass
    return " | ".join(parts)


def _show_background_viewer(agent) -> None:
    """Ctrl+B handler: display fleet messages and background tasks."""
    width = 60
    print(f"\n{'─' * width}")
    print("  BACKGROUND TASKS")
    print(f"{'─' * width}")

    # Fleet messages
    try:
        fleet = getattr(agent, '_pending_fleet_msgs', [])
        if fleet:
            print(f"  Fleet queue ({len(fleet)}):")
            for i, fm in enumerate(fleet[:5]):
                body = str(fm.get('body', ''))[:60]
                src = fm.get('source', '?')
                print(f"    [{i+1}] from {src}: {body}")
            if len(fleet) > 5:
                print(f"    ... +{len(fleet)-5} more")
        else:
            print("  Fleet queue: empty")
    except Exception:
        print("  Fleet queue: unavailable")

    # Recent tool outputs
    if _tool_output_ring:
        print(f"\n  Recent tools ({len(_tool_output_ring)}):")
        for i, (name, args, result) in enumerate(reversed(_tool_output_ring)):
            arg_str = str(args).replace('\n', ' ')[:40]
            res_str = str(result).replace('\n', ' ')[:60]
            print(f"    [{i+1}] {name}({arg_str}) → {res_str}")

    print(f"{'─' * width}\n")


def _show_tool_output_viewer() -> None:
    """Ctrl+O handler: show full output of most recent tool call."""
    if not _tool_output_ring:
        print("\n  No tool calls yet this session.\n")
        return

    name, args, result = _tool_output_ring[-1]
    width = 60
    print(f"\n{'─' * width}")
    print(f"  TOOL OUTPUT: {name}")
    print(f"{'─' * width}")
    print(f"  Args: {args}")
    print(f"  Output:")
    for line in str(result).split('\n')[:40]:
        print(f"    {line[:120]}")
    if len(str(result).split('\n')) > 40:
        print(f"    ... truncated ({len(str(result))} total chars)")
    print(f"{'─' * width}\n")


_patched_read_input = False


def _patch_read_input_if_ready() -> None:
    """Patch _read_input to add Ctrl+B/Ctrl+O keybindings + status line.
    Safe to call multiple times — only patches once."""
    global _patched_read_input
    if _patched_read_input:
        return

    agent = _get_agent()
    if agent is None:
        return  # agent not bound yet, try later

    import aibrain.lucy_agent as _la

    _orig_read_input = _la._read_input

    def _patched_read_input():
        agent = _get_agent()

        # Print status line before prompt
        if agent is not None:
            try:
                status = _render_status_line(agent)
                _sys.stderr.write(f"\033[2K\r  {_la.DIM}{status}{_la.RESET}")
                _sys.stderr.flush()
            except Exception:
                pass

        # Try prompt_toolkit with keybindings first
        if _la._PT:
            try:
                from prompt_toolkit.key_binding import KeyBindings
                from prompt_toolkit import prompt as _pt_prompt
                from prompt_toolkit.formatted_text import ANSI as _ANSI

                kb = KeyBindings()

                @kb.add('c-b')
                def _ctrl_b(event):
                    """Ctrl+B: show background task viewer."""
                    event.app.exit(result='__CTRL_B__')

                @kb.add('c-o')
                def _ctrl_o(event):
                    """Ctrl+O: show tool output viewer."""
                    event.app.exit(result='__CTRL_O__')

                prompt_str = f"{_la.ORANGE}you ›{_la.RESET} "
                result = _pt_prompt(
                    _ANSI(prompt_str),
                    history=_la._pt_history,
                    key_bindings=kb,
                )
                if result == '__CTRL_B__':
                    ag = _get_agent()
                    if ag:
                        _show_background_viewer(ag)
                    return ''
                elif result == '__CTRL_O__':
                    _show_tool_output_viewer()
                    return ''
                return result
            except (KeyboardInterrupt, EOFError):
                raise
            except Exception:
                pass

        # Fallback: plain input() — no keybindings, status only
        try:
            return input(f"{_la.ORANGE}you ›{_la.RESET} ")
        except (KeyboardInterrupt, EOFError):
            raise

    _la._read_input = _patched_read_input
    _patched_read_input = True


def _patch_execute_tool() -> None:
    """Patch _execute_tool to capture outputs into the ring buffer."""
    global _patched_execute_tool_flag
    if _patched_execute_tool_flag:
        return

    import aibrain.lucy_agent as _la

    _orig_execute_tool = _la._execute_tool

    def _patched_execute_tool(name, args):
        result = _orig_execute_tool(name, args)
        _capture_tool_output(name, args, str(result))
        return result

    _la._execute_tool = _patched_execute_tool
    _patched_execute_tool_flag = True


_patched_execute_tool_flag = False


def apply() -> bool:
    """Apply UX extensions (Phase 1: tool capture). Idempotent.

    Phase 2 (Ctrl+B/Ctrl+O/status) activates when bind_agent() is called.
    """
    global _PATCHED
    if _PATCHED:
        return True

    try:
        _patch_execute_tool()
        _PATCHED = True
        return True
    except Exception as e:
        print(f"[lucy_ux_extensions] patch failed: {e}", file=_sys.stderr)
        return False


# Phase 2 trigger: if agent is somehow available at import time, patch now
_patch_read_input_if_ready()


# Auto-apply Phase 1 if env var set
if _os.environ.get("LUCY_UX_EXTENSIONS") == "1":
    apply()
