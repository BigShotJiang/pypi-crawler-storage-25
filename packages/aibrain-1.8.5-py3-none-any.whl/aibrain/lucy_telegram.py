"""
lucy_telegram.py — Lucy's Telegram poller
Polls @Lucyaibrainbot (LUCY_TELEGRAM_TOKEN) and routes messages through the
REAL LucyAgent — the same agent Decker talks to in the terminal, with her
actual memory, session history, goal context, and tool access.

NOT a fake "you are Lucy" Claude prompt. LucyAgent.chat() is called directly.

Each agent uses its own dedicated bot token to avoid 409 Conflict:
  Neuro  → TELEGRAM_TOKEN       (@Wintermute1111_bot)
  Case   → CASE_TELEGRAM_TOKEN  (Case's own bot)
  Deep   → DEEP_BOT_TOKEN       (@deepexecutebot)
  Lucy   → LUCY_TELEGRAM_TOKEN  (@Lucyaibrainbot)

Run as: python -m aibrain.lucy_telegram
"""

import json, os, time, urllib.request, urllib.parse, urllib.error, atexit, sys
from pathlib import Path

TG_TOKEN    = os.environ.get("LUCY_TELEGRAM_TOKEN", "")
GROUP_ID    = -5288572284
INBOX_FILE  = os.environ.get("LUCY_INBOX_FILE", str(Path.home() / ".tmp" / "lucy_inbox.jsonl"))
LOCK_FILE   = Path(os.environ.get("LUCY_TG_LOCK", str(Path.home() / ".tmp" / "lucy_telegram.lock")))

_lucy_agent = None  # LucyAgent instance — initialized in poll()


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Lock guard — prevents dual-instance 409 Conflict
# ---------------------------------------------------------------------------

def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        import ctypes
        handle = ctypes.windll.kernel32.OpenProcess(0x00100000, False, pid)
        if handle:
            ctypes.windll.kernel32.CloseHandle(handle)
            return True
        return False
    except Exception:
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False


def _acquire_lock() -> bool:
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    my_pid = os.getpid()
    if LOCK_FILE.exists():
        try:
            held_pid = int(LOCK_FILE.read_text().strip())
        except (ValueError, OSError):
            held_pid = None
        if held_pid and held_pid != my_pid and _pid_alive(held_pid):
            log(f"Another Lucy poller running (PID {held_pid}) — exiting")
            return False
        log(f"Stale lock or own PID — taking ownership")
    LOCK_FILE.write_text(str(my_pid))
    atexit.register(_release_lock)
    return True


def _release_lock():
    try:
        if LOCK_FILE.exists() and int(LOCK_FILE.read_text().strip()) == os.getpid():
            LOCK_FILE.unlink()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Lucy agent init
# ---------------------------------------------------------------------------

def _init_lucy_agent():
    """Initialise the real LucyAgent. Returns agent or None on failure."""
    global _lucy_agent
    try:
        from aibrain.lucy_agent import LucyAgent, _detect_provider, _load_env_file
        _load_env_file()
        provider_info = _detect_provider()
        if not provider_info:
            log("ERROR: No API key found for Lucy (DEEPSEEK_API_KEY / ANTHROPIC_API_KEY)")
            return None
        provider, model, api_key = provider_info
        _lucy_agent = LucyAgent(provider, model, api_key)
        log(f"LucyAgent initialised — provider={provider} model={model}")
        return _lucy_agent
    except Exception as e:
        log(f"LucyAgent init failed: {e}")
        return None


def lucy_respond(text: str) -> str | None:
    """Route message through the real LucyAgent.chat() — real memory + context.

    F-TELEGRAM-AUTO-RESPOND-FLEET-ROLLOUT-1 (2026-05-14): pre-fetch top-5
    AIBrain memory_recall results and prepend as context before LucyAgent.chat().
    LucyAgent has its own internal memory layer; this pre-fetch is additive and
    surfaces semantic matches Lucy might not otherwise pull in for short queries.
    """
    global _lucy_agent
    if _lucy_agent is None:
        _lucy_agent = _init_lucy_agent()
    if _lucy_agent is None:
        return None

    # F-TELEGRAM-AUTO-RESPOND-FLEET-ROLLOUT-1: memory pre-fetch
    _memory_context = ""
    try:
        from aibrain.core.memory_recall import memory_recall as _aibrain_memory_recall
        _mem_results = _aibrain_memory_recall(query=text, limit=5)
        if _mem_results:
            _snippets = []
            for _m in _mem_results:
                _name = _m.get("name", "")
                _content = str(_m.get("content", ""))[:300]
                _snippets.append(f"[{_name}] {_content}")
            _memory_context = "\n\nRELEVANT MEMORIES:\n" + "\n".join(_snippets)
            log(f"  → memory pre-fetch: {len(_mem_results)} results")
    except Exception as _e:
        log(f"  → memory pre-fetch failed (non-fatal): {_e}")

    text_with_memory = text + _memory_context

    try:
        reply = _lucy_agent.chat(text_with_memory)
        return reply.strip() if reply else None
    except Exception as e:
        log(f"lucy_respond error: {e}")
        return None


# ---------------------------------------------------------------------------
# Telegram helpers
# ---------------------------------------------------------------------------

TG_API = f"https://api.telegram.org/bot{TG_TOKEN}"


def tg_get(method, params=None):
    url = f"{TG_API}/{method}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    try:
        with urllib.request.urlopen(url, timeout=35) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code == 409:
            log(f"409 Conflict on {method} — backing off")
            raise
        log(f"tg_get {method} error: {e}")
        return {}
    except Exception as e:
        log(f"tg_get {method} error: {e}")
        return {}


def tg_send(chat_id, text):
    url = f"{TG_API}/sendMessage"
    for chunk in [text[i:i+4000] for i in range(0, len(text), 4000)]:
        data = json.dumps({"chat_id": chat_id, "text": chunk}).encode()
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
        except Exception as e:
            log(f"tg_send error: {e}")


def save_message(msg_data):
    os.makedirs(os.path.dirname(INBOX_FILE), exist_ok=True)
    with open(INBOX_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(msg_data) + "\n")


# ---------------------------------------------------------------------------
# Poll loop
# ---------------------------------------------------------------------------

def poll():
    if not _acquire_lock():
        return

    log("Lucy Telegram poller starting — initialising LucyAgent...")
    _init_lucy_agent()
    if _lucy_agent is None:
        log("FATAL: Could not initialise LucyAgent — check API keys in ~/.decker_env")
        return

    TG_API_REF = f"https://api.telegram.org/bot{TG_TOKEN}"
    offset = 0
    _409_count = 0
    log(f"Lucy Telegram poller active — bot=@Lucyaibrainbot group={GROUP_ID}")

    while True:
        try:
            result = tg_get("getUpdates", {"offset": offset, "timeout": 30})
            _409_count = 0
            for u in result.get("result", []):
                offset = u["update_id"] + 1
                msg = u.get("message", {})
                chat_id = msg.get("chat", {}).get("id")
                sender = msg.get("from", {})

                if sender.get("is_bot"):
                    continue

                sender_name = sender.get("first_name", "?")
                is_group = (chat_id == GROUP_ID)
                is_dm = (msg.get("chat", {}).get("type") == "private")

                if not (is_group or is_dm):
                    continue

                chat_label = "group" if is_group else "dm"
                text = msg.get("text", "").strip()
                if not text:
                    continue

                log(f"[{chat_label}] {sender_name}: {text[:60]}")
                save_message({
                    "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "from": sender_name,
                    "chat": chat_label,
                    "chat_id": chat_id,
                    "type": "text",
                    "text": text,
                })

                log(f"  → routing to LucyAgent.chat()...")
                reply = lucy_respond(text)
                if reply:
                    tg_send(chat_id, reply)
                    log(f"  → Lucy replied ({len(reply)} chars)")
                else:
                    log("  → LucyAgent returned no reply")

        except urllib.error.HTTPError as e:
            if e.code == 409:
                _409_count += 1
                if _409_count >= 3:
                    log(f"409 x{_409_count} — releasing lock and exiting")
                    _release_lock()
                    return
                time.sleep(30)
            else:
                log(f"HTTP error: {e}")
                time.sleep(5)
        except Exception as e:
            log(f"poll error: {e}")
            time.sleep(5)


if __name__ == "__main__":
    # Load .decker_env before anything
    _decker_env = Path.home() / ".decker_env"
    if _decker_env.exists():
        for _line in _decker_env.read_text(encoding="utf-8").splitlines():
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _v = _line.split("=", 1)
                os.environ.setdefault(_k.strip(), _v.strip())

    TG_TOKEN = os.environ.get("LUCY_TELEGRAM_TOKEN", "")
    TG_API = f"https://api.telegram.org/bot{TG_TOKEN}"

    if not TG_TOKEN:
        raise SystemExit("ERROR: Set LUCY_TELEGRAM_TOKEN env var (@Lucyaibrainbot token)")

    poll()