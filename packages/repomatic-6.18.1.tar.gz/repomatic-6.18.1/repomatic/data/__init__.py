# Copyright Kevin Deldycke <kevin@deldycke.com> and contributors.
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

"""Bundled data files for repomatic.

This package contains label configurations, labeller rules, bumpversion template,
Ruff configuration, workflow templates, Claude Code skill definitions, and
awesome-template boilerplate files.

Configuration files (labels, labellers, bumpversion, ruff) are stored directly
in this directory. Workflow templates are symlinked from `.github/workflows/`
and skill definitions from `.claude/skills/` to maintain a single source of
truth while still being bundled in the package. The `awesome_template/`
sub-package contains boilerplate files for downstream `awesome-*` repositories.

All files are accessible at runtime via `importlib.resources`.
"""
