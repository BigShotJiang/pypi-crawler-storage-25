"""
Bootstrap KOs from Claude Code JSONL session logs.

Scans ~/.claude/projects/ for historical conversations and extracts
decisions, facts, preferences, and problems as KOs. Solves the cold
start problem for new users who have Claude Code history.

Two extraction modes:
1. LLM extraction (--llm or non-dry-run with ANTHROPIC_API_KEY): Uses
   Haiku to parse conversation chunks into structured KOs.
2. Regex fallback (default for --dry-run or no API key): Pattern
   matching for explicit phrases. Catches less but costs nothing.

Usage:
    coretx bootstrap                    # extract and write KOs (LLM if key set)
    coretx bootstrap --dry-run          # regex preview, no cost
    coretx bootstrap --dry-run --llm    # LLM preview (costs money, no writes)
    coretx bootstrap --limit-per-session 10
    coretx bootstrap --path /custom/path
    coretx bootstrap undo <run_id>      # delete every KO from a prior run
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from coretx.server import _api_get, _api_post, _api_delete, API_KEY


DEFAULT_LOG_DIR = Path.home() / ".claude" / "projects"
MANIFEST_DIR = Path.home() / ".coretx" / "bootstrap_runs"
HAIKU_MODEL = "claude-haiku-4-5-20251001"
DEFAULT_LIMIT_PER_SESSION = 10
DEFAULT_MAX_SESSION_BYTES = 500_000  # skip mega-transcripts that would dominate cost
LLM_TIMEOUT_SECS = 120
LLM_MAX_RETRIES = 3

# ─── Regex patterns (fallback when no API key or --dry-run without --llm) ───

DECISION_PATTERNS = [
    re.compile(r"(?:let's go with|we should|the plan is|I've decided|we're going to|decided to|approved|rejected)\s+(.{10,200})", re.I),
]

FACT_PATTERNS = [
    re.compile(r"(?:the (?:API|database|server|service) (?:is at|uses|runs on|is))\s+(.{5,200})", re.I),
    re.compile(r"(?:deployed (?:at|to))\s+(https?://\S+)", re.I),
    re.compile(r"(?:version|v)\s*(\d+\.\d+(?:\.\d+)?)", re.I),
]

PROBLEM_PATTERNS = [
    re.compile(r"(?:the (?:bug|issue|problem) is)\s+(.{10,200})", re.I),
    re.compile(r"(?:doesn't work|is broken|fails? (?:with|because|when))\s+(.{10,200})", re.I),
]

PREFERENCE_PATTERNS = [
    re.compile(r"(?:I prefer|always use|never do|from now on)\s+(.{5,200})", re.I),
]


# ─── LLM Extraction ─────────────────────────────────────────────

EXTRACTION_PROMPT = """Extract knowledge claims from this conversation between a user and an AI assistant.
Each claim is a single declarative sentence that stands alone.

Return ONLY a valid JSON array. Each element:
{{
  "subject": "<2-5 word topic label>",
  "predicate": "<claim type: decided as, rule is, finding is, status is, architecture is, located at, problem is, preference is>",
  "object_value": "<FULL CLAIM as a complete standalone sentence. Include specifics: names, numbers, paths. 1-2 sentences.>",
  "ko_type": "<insight|method|problem|hypothesis|finding|connection|negative_result>",
  "memory_type": "<episodic|semantic>",
  "pinned": false,
  "tags": ["<1-3 tags>"]
}}

RULES:
- object_value must be a COMPLETE SENTENCE readable without context
- Semantic = stable knowledge (conventions, architecture, decisions). Episodic = session-specific.
- Set pinned=true ONLY for critical constraints ("never do X", "always use Y")
- Skip: greetings, debugging dead-ends, file reads, tool call outputs, code blocks
- Extract ALL genuine decisions, facts, findings, problems, and preferences
- BAD: {{"subject":"auth","predicate":"uses","object_value":"cookies"}}
- GOOD: {{"subject":"auth system","predicate":"architecture is","object_value":"Authentication uses HMAC-SHA256 signed HttpOnly cookies with 30-day expiry, replacing the previous localStorage approach."}}

Conversation:
{text}"""


def _llm_extract_chunk(chunk: str, api_key: str) -> list[dict]:
    """Extract KOs from a conversation chunk using Haiku, with retries (F4)."""
    prompt = EXTRACTION_PROMPT.format(text=chunk[:12000])
    body = json.dumps({
        "model": HAIKU_MODEL,
        "max_tokens": 4000,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()

    last_err: Exception | None = None
    for attempt in range(LLM_MAX_RETRIES):
        try:
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                },
            )
            with urllib.request.urlopen(req, timeout=LLM_TIMEOUT_SECS) as resp:
                result = json.loads(resp.read())
                text = result["content"][0]["text"]
                start = text.find("[")
                end = text.rfind("]") + 1
                if start >= 0 and end > start:
                    kos = json.loads(text[start:end])
                    valid = []
                    for ko in kos:
                        if isinstance(ko, dict) and ko.get("subject") and ko.get("predicate") and ko.get("object_value"):
                            if len(ko["object_value"]) > 15:
                                valid.append(ko)
                    return valid
                return []
        except urllib.error.HTTPError as e:
            # Fail fast on auth/permission/bad-request — retrying just burns
            # quota and racks up bills with a wrong key. Retry only on
            # transient failures: 408, 429, 5xx.
            if e.code in (401, 403):
                print(f"  LLM extraction blocked: HTTP {e.code} (auth — check ANTHROPIC_API_KEY)", file=sys.stderr)
                return []
            if e.code in (400, 404):
                print(f"  LLM extraction failed: HTTP {e.code} (won't retry)", file=sys.stderr)
                return []
            last_err = e
        except Exception as e:
            last_err = e
        if attempt < LLM_MAX_RETRIES - 1:
            backoff = (attempt + 1) ** 2
            time.sleep(backoff)
            continue
    print(f"  LLM extraction failed after {LLM_MAX_RETRIES} attempts: {last_err}", file=sys.stderr)
    return []


def _chunk_transcript(text: str, max_chars: int = 10000) -> list[str]:
    """Split transcript into chunks at user message boundaries."""
    parts = re.split(r'\n(?=(?:Human|User|assistant|human):)', text)
    chunks = []
    current = ""
    for part in parts:
        if len(current) + len(part) > max_chars and current:
            chunks.append(current)
            current = part
        else:
            current += "\n" + part if current else part
    if current.strip():
        chunks.append(current)
    return chunks if chunks else [text[:max_chars]]


# ─── JSONL Parsing ───────────────────────────────────────────────

def _derive_project(jsonl_file: Path) -> str:
    """F2: Derive project name from cwd inside the JSONL, falling back to dirname.

    Claude Code records cwd on user/assistant entries. Read the first line that
    has one and take its basename. Falls back to a sanitised dirname.
    """
    try:
        with open(jsonl_file, "r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i > 200:
                    break
                line = line.strip()
                if not line.startswith("{"):
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                cwd = record.get("cwd")
                if not cwd and isinstance(record.get("message"), dict):
                    cwd = record["message"].get("cwd")
                if cwd:
                    return Path(cwd).name
    except Exception:
        pass

    # Fallback: dirname-based heuristic. Strip a leading user-home segment if
    # we can find one (-Users-<name>-Code-... → coretx-coretx-connect → take
    # everything after Code).
    name = jsonl_file.parent.name
    for marker in ("-Code-", "-code-"):
        idx = name.find(marker)
        if idx >= 0:
            return name[idx + len(marker):] or name
    return name.lstrip("-")


def _earliest_timestamp(filepath: Path) -> str:
    """Return the earliest record timestamp in a JSONL, or '' if absent."""
    earliest: str = ""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line.startswith("{"):
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ts = record.get("timestamp") or record.get("createdAt")
                if isinstance(ts, str) and ts:
                    if not earliest or ts < earliest:
                        earliest = ts
                        return earliest  # JSONL is append-only; first hit is earliest
    except Exception:
        pass
    return earliest


def _parse_jsonl_to_text(filepath: Path) -> str:
    """Parse JSONL into a readable transcript for LLM extraction."""
    lines = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue

                role = record.get("type", "")
                message = record.get("message", {})
                content = message.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        block.get("text", "") for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    )
                if not isinstance(content, str) or len(content) < 10:
                    continue

                if role == "assistant":
                    lines.append(f"Assistant: {content}")
                elif role == "human" or role == "user":
                    lines.append(f"Human: {content}")
    except Exception as e:
        print(f"  Error reading {filepath}: {e}", file=sys.stderr)

    return "\n\n".join(lines)


def _scan_jsonl_regex(filepath: Path) -> list[dict]:
    """Scan a JSONL file using regex patterns (fallback mode)."""
    found = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if record.get("type") != "assistant":
                    continue

                message = record.get("message", {})
                content = message.get("content", "")
                if isinstance(content, list):
                    content = " ".join(
                        block.get("text", "") for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    )
                if not isinstance(content, str) or len(content) < 20:
                    continue

                timestamp = record.get("timestamp", "")

                for pattern in DECISION_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "decided as",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "tags": [],
                            "timestamp": timestamp,
                        })

                for pattern in FACT_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(0)[:80].strip().rstrip("."),
                            "predicate": "established as",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "tags": [],
                            "timestamp": timestamp,
                        })

                for pattern in PROBLEM_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "problem is",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "problem",
                            "memory_type": "episodic",
                            "tags": [],
                            "timestamp": timestamp,
                        })

                for pattern in PREFERENCE_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "preference is",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "pinned": True,
                            "tags": [],
                            "timestamp": timestamp,
                        })

    except Exception as e:
        print(f"  Error reading {filepath}: {e}", file=sys.stderr)

    return found


# ─── Ranking, dedup, provenance (F3, F5, F6) ────────────────────

PREDICATE_WEIGHT = {
    "decided as": 3,
    "rule is": 3,
    "preference is": 3,
    "architecture is": 2,
    "method is": 2,
    "finding is": 1,
    "located at": 1,
    "status is": 0,
    "problem is": 0,
}


def _dedup_key(ko: dict) -> tuple[str, str]:
    """F3: Stable dedup key on (subject, predicate), normalised."""
    return (
        (ko.get("subject") or "").strip().lower(),
        (ko.get("predicate") or "").strip().lower(),
    )


def _score_ko(ko: dict) -> float:
    """F5: Higher = more universally useful for a fresh session.

    Pinned > semantic > predicate weight > completeness of object_value.
    """
    score = 0.0
    if ko.get("pinned"):
        score += 100
    if ko.get("memory_type") == "semantic":
        score += 30
    score += PREDICATE_WEIGHT.get(ko.get("predicate", ""), 0) * 5
    obj = ko.get("object_value") or ""
    score += min(len(obj), 400) / 40.0  # 0–10 for length, capped
    if ko.get("ko_type") in ("method", "insight"):
        score += 5
    return score


def _add_provenance(ko: dict, run_id: str, session_id: str, when: str) -> dict:
    """F6: Stamp KO with run_id, session_id, and bootstrap timestamp."""
    tags = list(ko.get("tags") or [])
    for t in ("bootstrap", f"run:{run_id}", f"session:{session_id}", f"bootstrapped_at:{when}"):
        if t not in tags:
            tags.append(t)
    ko["tags"] = tags
    return ko


# ─── Manifest (F8) ──────────────────────────────────────────────

def _save_manifest(run_id: str, kos: list[dict], stats: dict) -> Path:
    """F8: Persist a per-run manifest so a run can be undone later.

    Manifest contains KO subjects/predicates/projects (no object_value, no
    transcript content). File is created 0600 because subjects can still be
    sensitive on a shared machine.
    """
    MANIFEST_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = MANIFEST_DIR / f"{run_id}.json"
    payload = {
        "run_id": run_id,
        "started_at": stats.get("started_at"),
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "mode": stats.get("mode"),
        "kos": [{"subject": k.get("subject"), "predicate": k.get("predicate"), "project": k.get("project")} for k in kos],
        "stats": stats,
    }
    path.write_text(json.dumps(payload, indent=2))
    try:
        path.chmod(0o600)
    except OSError:
        pass  # non-POSIX, best-effort
    return path


def _load_manifest(run_id: str) -> dict | None:
    path = MANIFEST_DIR / f"{run_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


# ─── Main Bootstrap ──────────────────────────────────────────────

def bootstrap(
    log_dir: Path = DEFAULT_LOG_DIR,
    dry_run: bool = False,
    use_llm: bool | None = None,
    limit_per_session: int = DEFAULT_LIMIT_PER_SESSION,
    run_id: str | None = None,
    max_session_bytes: int = DEFAULT_MAX_SESSION_BYTES,
) -> dict:
    """Scan Claude Code logs and extract KOs.

    Args:
        log_dir: Directory containing per-project JSONL subdirs.
        dry_run: Don't write KOs to the server.
        use_llm: True forces LLM, False forces regex, None autodetects
            (regex when dry_run, LLM otherwise iff ANTHROPIC_API_KEY set).
        limit_per_session: Top-N KOs per session after ranking (F5).
        run_id: Caller-provided run ID; auto-generated if None.

    Returns: {"sessions", "extracted", "ranked", "written", "skipped",
              "mode", "run_id", "manifest_path"}
    """
    if not log_dir.exists():
        print(f"Log directory not found: {log_dir}", file=sys.stderr)
        return {"sessions": 0, "extracted": 0, "ranked": 0, "written": 0, "skipped": 0, "mode": "none"}

    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if use_llm is None:
        use_llm = (not dry_run) and bool(anthropic_key)
    elif use_llm and not anthropic_key:
        print("--llm requested but ANTHROPIC_API_KEY not set; falling back to regex.", file=sys.stderr)
        use_llm = False

    run_id = run_id or uuid.uuid4().hex[:12]
    started_at = datetime.now(timezone.utc).isoformat()

    if use_llm:
        print(f"Using LLM extraction ({HAIKU_MODEL}). ~$0.01/session.")
    else:
        print("Using regex fallback (zero cost, lower recall).")

    # F3: Fetch existing KOs for dedup on (subject, predicate)
    existing_pairs: set[tuple[str, str]] = set()
    if not dry_run and API_KEY:
        result = _api_get("list", {"limit": 1000})
        for ko in result.get("kos", result.get("results", [])):
            existing_pairs.add((
                (ko.get("subject") or "").lower(),
                (ko.get("predicate") or "").lower(),
            ))

    sessions = 0
    extracted = 0
    ranked = 0
    written = 0
    skipped = 0
    written_kos: list[dict] = []

    for project_dir in sorted(log_dir.iterdir()):
        if not project_dir.is_dir():
            continue

        jsonl_files = list(project_dir.glob("*.jsonl"))

        for jsonl_file in jsonl_files:
            sessions += 1
            project = _derive_project(jsonl_file)  # F2: per-file
            session_id = jsonl_file.stem

            try:
                file_size = jsonl_file.stat().st_size
            except OSError:
                file_size = 0
            if max_session_bytes and file_size > max_session_bytes:
                print(f"  {jsonl_file.name}: skipped ({file_size:,} bytes > {max_session_bytes:,} cap)")
                skipped += 1
                continue

            if use_llm:
                transcript = _parse_jsonl_to_text(jsonl_file)
                if len(transcript) < 100:
                    continue
                chunks = _chunk_transcript(transcript)
                found: list[dict] = []
                for i, chunk in enumerate(chunks):
                    chunk_kos = _llm_extract_chunk(chunk, anthropic_key)
                    found.extend(chunk_kos)
                    if len(chunks) > 1:
                        sys.stderr.write(f"  {jsonl_file.name} chunk {i+1}/{len(chunks)}: {len(chunk_kos)} KOs\n")
            else:
                found = _scan_jsonl_regex(jsonl_file)

            extracted += len(found)
            if not found:
                continue

            # F3: within-batch dedup by (subject, predicate). Keep highest-scored.
            best_by_key: dict[tuple[str, str], dict] = {}
            for ko in found:
                key = _dedup_key(ko)
                if not key[0] or not key[1]:
                    continue
                cur = best_by_key.get(key)
                if cur is None or _score_ko(ko) > _score_ko(cur):
                    best_by_key[key] = ko

            # F5: rank, cap at limit_per_session
            session_kos = sorted(best_by_key.values(), key=_score_ko, reverse=True)[:limit_per_session]
            ranked += len(session_kos)

            session_ts = _earliest_timestamp(jsonl_file)

            for ko in session_kos:
                key = _dedup_key(ko)
                if key in existing_pairs:
                    skipped += 1
                    continue

                ko["project"] = project
                ko["__source_session"] = session_id
                ko["__source_ts"] = session_ts
                _add_provenance(ko, run_id, session_id, started_at)

                if dry_run:
                    ko_type = ko.get("ko_type", "insight")
                    pinned = " [PINNED]" if ko.get("pinned") else ""
                    mem_type = ko.get("memory_type", "episodic")
                    print(f"  [{project}] {ko_type}/{mem_type}{pinned}: {ko['subject'][:60]} ({ko['predicate']})")
                    if ko.get("object_value"):
                        print(f"    → {ko['object_value'][:120]}")
                    written += 1
                    written_kos.append(ko)
                else:
                    result = _api_post({
                        "action": "write",
                        "subject": ko["subject"],
                        "predicate": ko["predicate"],
                        "object_value": ko["object_value"],
                        "ko_type": ko.get("ko_type", "insight"),
                        "memory_type": ko.get("memory_type", "episodic"),
                        "project": project,
                        "tags": ko.get("tags", []),
                        "pinned": ko.get("pinned", False),
                        "confidence": ko.get("confidence"),
                        "visibility": "private",
                    })
                    if "error" not in result and result.get("action") != "gated":
                        written += 1
                        written_kos.append(ko)
                        existing_pairs.add(key)
                    else:
                        skipped += 1

            print(f"  {jsonl_file.name}: {len(found)} extracted → {len(session_kos)} ranked")

    stats = {
        "sessions": sessions,
        "extracted": extracted,
        "ranked": ranked,
        "written": written,
        "skipped": skipped,
        "mode": "llm" if use_llm else "regex",
        "run_id": run_id,
        "started_at": started_at,
        "dry_run": dry_run,
    }

    # F8: write manifest only when KOs actually persisted (or dry-run preview).
    if written_kos:
        manifest_path = _save_manifest(run_id, written_kos, stats)
        stats["manifest_path"] = str(manifest_path)
    else:
        stats["manifest_path"] = None

    return stats


# ─── Undo (F8) ──────────────────────────────────────────────────

def undo(run_id: str) -> dict:
    """F8: Delete every KO recorded for a prior bootstrap run.

    Caveat: deletion is by (subject, predicate) since the server's delete
    endpoint takes those keys. If you've manually re-written a KO with the
    same subject+predicate as a bootstrap-created one *after* the run, undo
    will delete your manual edit too. In practice this is rare because
    bootstrap dedups against existing KOs at write-time. Surface a warning
    in `coretx bootstrap undo` output rather than silently delete.
    """
    manifest = _load_manifest(run_id)
    if manifest is None:
        print(f"No manifest for run_id={run_id}", file=sys.stderr)
        return {"deleted": 0, "missing": 0, "errors": 0}
    if not API_KEY:
        print("CORETX_API_KEY not set.", file=sys.stderr)
        sys.exit(1)

    print(f"Undoing run {run_id} ({len(manifest.get('kos', []))} KOs).")
    print("  Note: delete is by (subject, predicate). If you've manually")
    print("  edited a KO with the same key after the run, that edit will")
    print("  also be removed. Press Ctrl-C now to abort.")
    deleted = 0
    missing = 0
    errors = 0
    for entry in manifest.get("kos", []):
        subj = entry.get("subject")
        pred = entry.get("predicate")
        if not subj or not pred:
            continue
        result = _api_delete({"subject": subj, "predicate": pred})
        err = result.get("error", "")
        if not err:
            deleted += 1
        elif "not found" in err.lower() or "404" in err:
            missing += 1
        else:
            errors += 1
            print(f"  Error deleting {subj}/{pred}: {err}", file=sys.stderr)

    print(f"Undo {run_id}: deleted {deleted}, missing {missing}, errors {errors}.")
    return {"deleted": deleted, "missing": missing, "errors": errors}


# ─── Setup-time offer ───────────────────────────────────────────

def _eligible_sessions(log_dir: Path) -> list[Path]:
    """Sessions under the size cap that bootstrap would actually process."""
    if not log_dir.exists():
        return []
    out: list[Path] = []
    for project_dir in log_dir.iterdir():
        if not project_dir.is_dir():
            continue
        for f in project_dir.glob("*.jsonl"):
            try:
                if f.stat().st_size <= DEFAULT_MAX_SESSION_BYTES:
                    out.append(f)
            except OSError:
                continue
    return out


def _estimate_cost(n_sessions: int) -> tuple[float, float]:
    """Conservative low/high band per session × cap-limited transcripts."""
    return max(0.01, round(n_sessions * 0.005, 2)), round(n_sessions * 0.02, 2)


def post_setup_offer(
    action: str | None = None,
    log_dir: Path = DEFAULT_LOG_DIR,
    stdin: object = sys.stdin,
) -> None:
    """Offer to bootstrap immediately after `coretx setup`.

    action:
      - "yes": run bootstrap non-interactively (set by `coretx setup --bootstrap`)
      - "no": print nothing (set by `coretx setup --no-bootstrap`)
      - None: prompt y/N if stdin is a TTY; otherwise print the informational
        hint and exit without running anything.

    Bootstrap is gated behind ANTHROPIC_API_KEY. Without it the offer falls
    back to a hint with instructions, since regex-mode bootstrap scores
    `session_1_aha_rate = 0.00` empirically — not worth the user's time.
    """
    if action == "no":
        return

    sessions = _eligible_sessions(log_dir)
    if not sessions:
        return

    n = len(sessions)
    est_low, est_high = _estimate_cost(n)
    has_anthropic_key = bool(os.environ.get("ANTHROPIC_API_KEY", ""))
    has_coretx_key = bool(API_KEY)

    print()
    print("─" * 60)
    print(f"Bootstrap: {n} Claude Code session{'s' if n != 1 else ''} detected.")
    print(f"  Mining them now lets retrieval fire on your very first new")
    print(f"  session, instead of waiting for KOs to accumulate.")
    print()
    print(f"  Estimated cost: ~${est_low:.2f}–${est_high:.2f} (Haiku 4.5)")

    # Eligibility checks. Both keys required to actually run.
    blocked: list[str] = []
    if not has_coretx_key:
        blocked.append("CORETX_API_KEY not set — run `coretx init` or `coretx setup KEY`")
    if not has_anthropic_key:
        blocked.append("ANTHROPIC_API_KEY not set — bootstrap LLM mode requires it")
    if blocked:
        print()
        for b in blocked:
            print(f"  ⚠ {b}")
        print()
        print("  When ready:    coretx bootstrap --llm")
        print("  Free preview:  coretx bootstrap --dry-run")
        print("─" * 60)
        return

    # Decide: interactive prompt, force-run, or informational fallback.
    is_tty = False
    try:
        is_tty = bool(getattr(stdin, "isatty", lambda: False)())
    except Exception:
        is_tty = False

    if action == "yes":
        run_now = True
    elif action is None and is_tty:
        print()
        try:
            answer = input("  Run bootstrap now? [y/N]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            print("  Skipped. Run later with: coretx bootstrap --llm")
            print("─" * 60)
            return
        run_now = answer in ("y", "yes")
    else:
        # Non-interactive without explicit --bootstrap: print hint, don't run.
        print()
        print("  Run now:       coretx bootstrap --llm")
        print("  Free preview:  coretx bootstrap --dry-run")
        print("  Roll back:     coretx bootstrap undo <run_id>")
        print("─" * 60)
        return

    if not run_now:
        print()
        print("  Skipped. Run later with: coretx bootstrap --llm")
        print("─" * 60)
        return

    print("─" * 60)
    print()
    stats = bootstrap(log_dir=log_dir, dry_run=False, use_llm=True)
    print(
        f"\nBootstrap done ({stats['mode']}). "
        f"Sessions {stats['sessions']}, ranked {stats['ranked']}, "
        f"wrote {stats['written']}, skipped {stats['skipped']}."
    )
    if stats.get("manifest_path") and stats.get("written", 0) > 0:
        print(f"Roll back with: coretx bootstrap undo {stats['run_id']}")


# Back-compat: server.py imports post_setup_hint. Keep the old name as an alias.
post_setup_hint = post_setup_offer


# ─── CLI ────────────────────────────────────────────────────────

def _parse_flag(args: list[str], name: str, has_value: bool = False) -> tuple[bool, str | None, list[str]]:
    """Tiny flag parser. Returns (present, value, remaining_args)."""
    out = []
    present = False
    value = None
    skip = False
    for i, a in enumerate(args):
        if skip:
            skip = False
            continue
        if a == name:
            present = True
            if has_value and i + 1 < len(args):
                value = args[i + 1]
                skip = True
            continue
        out.append(a)
    return present, value, out


def main():
    args = sys.argv[1:]
    # Strip leading "bootstrap" if invoked as `coretx bootstrap ...`
    if args and args[0] == "bootstrap":
        args = args[1:]

    if args and args[0] == "undo":
        if len(args) < 2:
            print("Usage: coretx bootstrap undo <run_id>", file=sys.stderr)
            sys.exit(2)
        undo(args[1])
        return

    if "--help" in args or "-h" in args:
        print("coretx bootstrap [options]")
        print("  Scan Claude Code logs and extract KOs for cold start.")
        print()
        print("  --dry-run                  Don't write to the server (regex by default)")
        print("  --llm                      Force LLM extraction (overrides --dry-run regex default)")
        print("  --regex                    Force regex even if API key is available")
        print("  --path PATH                Override log directory (default: ~/.claude/projects)")
        print(f"  --limit-per-session N      Top-N KOs per session after ranking (default: {DEFAULT_LIMIT_PER_SESSION})")
        print(f"  --max-session-bytes N      Skip JSONL files larger than this (default: {DEFAULT_MAX_SESSION_BYTES:,})")
        print()
        print("  coretx bootstrap undo <run_id>")
        return

    dry_run, _, args = _parse_flag(args, "--dry-run")
    llm_flag, _, args = _parse_flag(args, "--llm")
    regex_flag, _, args = _parse_flag(args, "--regex")
    _, path_val, args = _parse_flag(args, "--path", has_value=True)
    _, limit_val, args = _parse_flag(args, "--limit-per-session", has_value=True)
    _, max_bytes_val, args = _parse_flag(args, "--max-session-bytes", has_value=True)

    log_path = Path(path_val) if path_val else DEFAULT_LOG_DIR
    limit = int(limit_val) if limit_val else DEFAULT_LIMIT_PER_SESSION
    max_bytes = int(max_bytes_val) if max_bytes_val else DEFAULT_MAX_SESSION_BYTES

    use_llm: bool | None
    if llm_flag and regex_flag:
        print("--llm and --regex are mutually exclusive.", file=sys.stderr)
        sys.exit(2)
    elif llm_flag:
        use_llm = True
    elif regex_flag:
        use_llm = False
    else:
        # F7: --dry-run defaults to regex; non-dry-run defaults to LLM iff key set.
        use_llm = None

    if not API_KEY and not dry_run:
        print("CORETX_API_KEY not set. Use --dry-run to preview without writing.", file=sys.stderr)
        sys.exit(1)

    print(f"Scanning {log_path}...")
    if dry_run:
        print("(dry run -- nothing will be written)\n")

    stats = bootstrap(
        log_path,
        dry_run=dry_run,
        use_llm=use_llm,
        limit_per_session=limit,
        max_session_bytes=max_bytes,
    )

    print(
        f"\nDone ({stats['mode']}). "
        f"Sessions {stats['sessions']}, extracted {stats['extracted']}, "
        f"ranked {stats['ranked']}, wrote {stats['written']}, skipped {stats['skipped']}."
    )
    print(f"Run ID: {stats['run_id']}")
    if stats.get("manifest_path"):
        print(f"Manifest: {stats['manifest_path']}")
        if stats["written"] > 0 and not dry_run:
            print(f"Undo with: coretx bootstrap undo {stats['run_id']}")


if __name__ == "__main__":
    main()
