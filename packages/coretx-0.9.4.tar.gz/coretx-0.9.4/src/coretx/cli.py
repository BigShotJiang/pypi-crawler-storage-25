"""CoreTx CLI -- account setup and management."""
from __future__ import annotations
import getpass, json, os, re, sys, time
import urllib.error, urllib.request
from http.cookiejar import CookieJar
from pathlib import Path
from typing import Any
from coretx import __version__

CONFIG_DIR = Path.home() / ".coretx"
CONFIG_PATH = CONFIG_DIR / "config.json"
SIGNING_KEY_PATH = CONFIG_DIR / "signing.key"
DEFAULT_API_URL = "https://api.coretx.ai"
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# Shared cookie jar for auth flow (signup sets session cookie, key gen uses it)
_cookie_jar = CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_cookie_jar))


def load_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}

def save_config(config: dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    try: os.chmod(CONFIG_PATH, 0o600)
    except OSError: pass

def remove_config() -> bool:
    if CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
        return True
    return False

def get_api_key() -> str:
    return os.environ.get("CORETX_API_KEY", "") or load_config().get("api_key", "")

def get_api_url() -> str:
    return os.environ.get("CORETX_API_URL", "") or load_config().get("api_url", DEFAULT_API_URL)

# -- HTTP -------------------------------------------------------------------

def _post(url: str, body: dict, headers: dict | None = None) -> dict:
    hdrs = {"Content-Type": "application/json", **(headers or {})}
    return _do(urllib.request.Request(url, json.dumps(body).encode(), hdrs, method="POST"))

def _get(url: str, headers: dict | None = None) -> dict:
    return _do(urllib.request.Request(url, headers=headers or {}, method="GET"))

def _delete(url: str, headers: dict | None = None) -> dict:
    return _do(urllib.request.Request(url, headers=headers or {}, method="DELETE"))

def _do(req: urllib.request.Request) -> dict:
    try:
        with _opener.open(req, timeout=15) as resp:
            raw = resp.read().decode()
            status = getattr(resp, "status", None)
            if not raw:
                return {"_status": status}
            try:
                return {**json.loads(raw), "_status": status}
            except json.JSONDecodeError:
                # Server returned 2xx with a non-JSON body. Callers that only
                # care about success vs. failure can rely on _status; we drop
                # the body rather than carry an unused field.
                return {"_status": status}
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        try: return {**json.loads(body), "_status": e.code}
        except Exception: return {"error": body[:300] or f"HTTP {e.code}", "_status": e.code}
    except urllib.error.URLError:
        return {"error": "network"}
    except Exception as e:
        return {"error": str(e)}

# -- Auth helpers -----------------------------------------------------------

def _auth(api_url: str, email: str, password: str, invite_code: str = "") -> dict:
    """Sign up or sign in. The API uses the same endpoint for both."""
    body: dict[str, str] = {"email": email, "password": password}
    if invite_code:
        body["invite_code"] = invite_code
    return _post(f"{api_url}/api/auth/email", body)

def _generate_key(api_url: str) -> dict:
    """Generate an API key using the session cookie from auth."""
    return _post(f"{api_url}/api/keys", {"name": "coretx-cli"})

# -- Output helpers ---------------------------------------------------------

def _network_error() -> int:
    print("\n  Could not reach CoreTx servers. Check your connection.")
    print("  If the problem persists, try: coretx init --key YOUR_API_KEY\n")
    return 1

def _manual_fallback() -> int:
    print("\n  Automatic key generation failed. Please:")
    print("    1. Sign in at sapience.coretx.ai")
    print("    2. Go to API Keys in the top bar")
    print("    3. Create a key and run: coretx init --key YOUR_API_KEY\n")
    return 1

def _save_and_verify(api_key: str, api_url: str, email: str = "") -> int:
    # Look up email from API if not provided
    if not email or email == "(manual)":
        me = _get(f"{api_url}/api/me", {"Authorization": f"Bearer {api_key}"})
        user = me.get("user", {})
        email = user.get("email", "") or email

    config = {"api_key": api_key, "api_url": api_url, "email": email,
              "tier": "network", "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    save_config(config)
    print(f"\n  API key saved to {CONFIG_PATH}")
    result = _get(f"{api_url}/api/kos?action=stats", {"Authorization": f"Bearer {api_key}"})
    if "error" not in result:
        total = result.get("total_kos", 0)
        print(f"  Connected. {total} KOs in your store.")
        config["tier"] = result.get("tier", "network")
        save_config(config)
    else:
        print("  Saved, but could not verify connection. Check your key.")
    print("\n  Next steps:")
    print("    coretx setup        Configure Claude Desktop + Claude Code")
    print("    coretx status       Check connectivity\n")
    return 0

# -- Commands ---------------------------------------------------------------

def cmd_init(args: list[str]) -> int:
    api_url, manual_key, invite_code = DEFAULT_API_URL, "", ""
    i = 0
    while i < len(args):
        if args[i] == "--api-url" and i + 1 < len(args):
            api_url = args[i + 1]; i += 2
        elif args[i] == "--key" and i + 1 < len(args):
            manual_key = args[i + 1]; i += 2
        elif args[i] == "--invite-code" and i + 1 < len(args):
            invite_code = args[i + 1]; i += 2
        else:
            i += 1
    api_url = os.environ.get("CORETX_API_URL", api_url)

    print("\n  CoreTx")
    print("  Structured memory for AI that persists, attributes, and connects.")
    print("  Learn more: https://coretx.ai\n")

    existing = load_config()
    if existing.get("api_key"):
        print(f"  Found existing config ({existing.get('email', 'unknown')}).")
        if input("  Overwrite? [y/N] ").strip().lower() not in ("y", "yes"):
            print("  Keeping existing config.")
            return 0

    if manual_key:
        return _save_and_verify(manual_key, api_url, email="(manual)")

    print("  Create your CoreTx account or sign in:\n")
    if not invite_code:
        invite_code = input("  Invite code (leave blank to sign in): ").strip()
    while True:
        email = input("  Email: ").strip()
        if _EMAIL_RE.match(email): break
        print("  Please enter a valid email address.")
    while True:
        password = getpass.getpass("  Password: ")
        if len(password) >= 8: break
        print("  Password must be at least 8 characters.")

    print("\n  Signing in...", end="", flush=True)
    result = _auth(api_url, email, password, invite_code=invite_code)

    if result.get("error") == "network":
        print(" failed."); return _network_error()
    if "error" in result:
        print(f" failed.")
        print(f"\n  {result.get('error', 'Unknown error')}")
        return 1

    is_new = result.get("is_new", False)
    print(" account created." if is_new else " done.")

    # Generate API key using session cookie from auth
    print("  Generating API key...", end="", flush=True)
    key_result = _generate_key(api_url)
    api_key = key_result.get("key", "")
    if "error" in key_result or not api_key:
        print(" failed."); return _manual_fallback()
    print(" done.")
    return _save_and_verify(api_key, api_url, email=email)


def cmd_status(args: list[str]) -> int:
    print(f"\n  CoreTx v{__version__}")
    api_key, api_url, config = get_api_key(), get_api_url(), load_config()
    if not api_key:
        print("  Status: not configured\n  Run 'coretx init' to set up.\n")
        return 1

    # When CORETX_API_KEY env var is set with a value different from config,
    # it silently overrides the config key for API calls. The previous behavior
    # showed config's email but env-key's KOs — internally inconsistent and
    # confusing. Detect this and (a) warn the user, (b) skip trusting config's
    # email since it's for a different account.
    env_key = os.environ.get("CORETX_API_KEY", "")
    config_key = config.get("api_key", "")
    env_overriding = bool(env_key) and bool(config_key) and env_key != config_key
    if env_overriding:
        print("  Note: CORETX_API_KEY env var is overriding the key in ~/.coretx/config.json")

    # Resolve email: prefer config (unless env is overriding — then look up live).
    email = "" if env_overriding else config.get("email", "")
    if not email or email in ("(manual)", "(env var)"):
        me = _get(f"{api_url}/api/me", {"Authorization": f"Bearer {api_key}"})
        email = me.get("user", {}).get("email", "")
        if email and not env_overriding and email != config.get("email"):
            config["email"] = email
            save_config(config)

    if email:
        print(f"  Email: {email}")

    result = _get(f"{api_url}/api/kos?action=stats", {"Authorization": f"Bearer {api_key}"})
    if "error" not in result:
        tier = result.get("tier", config.get("tier", "network"))
        print(f"  Tier: {tier} (beta)")
        print(f"  KOs: {result.get('total_kos', 0)}")
        print(f"  API: {api_url} (connected)")
    else:
        # Distinguish auth failure from network failure. Previous behavior labeled
        # any error as "unreachable", which made a revoked/wrong key look like a
        # connectivity problem.
        status_code = result.get("_status")
        if status_code in (401, 403):
            label = f"auth failed (HTTP {status_code} — key may be invalid or revoked)"
        elif result.get("error") == "network":
            label = "unreachable (network)"
        else:
            label = f"error: {result.get('error', 'unknown')}"
        print(f"  Tier: {config.get('tier', 'unknown')}")
        print(f"  API: {api_url} ({label})")
    print()
    return 0


def cmd_wipe(args: list[str]) -> int:
    """Delete the user's CoreTx account (server cascade) and remove local state.

    Server side: cascades all KOs, signing key registrations, and the account
    row via DELETE /api/account.

    Local side: removes ~/.coretx/config.json and ~/.coretx/signing.key.

    Destructive and irreversible. Requires explicit confirmation unless --yes
    is passed.
    """
    skip_confirm = "--yes" in args or "-y" in args
    api_url = get_api_url()
    api_key = get_api_key()
    config = load_config()

    # If CORETX_API_KEY is set and differs from the key in config.json, the
    # DELETE will target the env-key's account, not the config's. Look up the
    # live email so the confirmation prompt reflects what will actually be
    # deleted (mirrors cmd_status's handling).
    env_key = os.environ.get("CORETX_API_KEY", "")
    config_key = config.get("api_key", "")
    env_overriding = bool(env_key) and bool(config_key) and env_key != config_key
    email = "" if env_overriding else config.get("email", "")

    print("\n  CoreTx wipe")
    print("  This will permanently delete:")
    print("    • Your CoreTx account on the server (all KOs, signing key registrations)")
    print(f"    • Your local config ({CONFIG_PATH})")
    print(f"    • Your local signing key ({SIGNING_KEY_PATH})")
    print("  This cannot be undone.\n")

    if not api_key:
        # Without an API key we can't call the server. Offer to clean local
        # state only (covers users who already revoked their key elsewhere).
        print("  No API key configured — cannot delete the server account.")
        if not (CONFIG_PATH.exists() or SIGNING_KEY_PATH.exists()):
            print("  No local state to remove either.\n")
            return 0
        if not skip_confirm:
            ans = input("  Remove local config + signing key only? [y/N] ").strip().lower()
            if ans not in ("y", "yes"):
                print("  Cancelled.\n")
                return 1
        return _wipe_local()

    if env_overriding:
        print("  Note: CORETX_API_KEY env var is overriding the key in ~/.coretx/config.json")
        print("  Looking up account...", end="", flush=True)
        me = _get(f"{api_url}/api/me", {"Authorization": f"Bearer {api_key}"})
        if "error" in me:
            print(" failed.")
            if me.get("error") == "network":
                reason = "could not reach CoreTx servers"
            else:
                reason = me.get("error", "unknown")
            print(f"  Could not verify which account this key belongs to: {reason}.")
            print("  Refusing to wipe without confirmation of the target account.\n")
            return 1
        email = me.get("user", {}).get("email", "")
        print(" done.")

    if email:
        print(f"  Account: {email}")
    print(f"  API: {api_url}")
    if not skip_confirm:
        ans = input("\n  Type 'wipe' to confirm: ").strip().lower()
        if ans != "wipe":
            print("  Cancelled.\n")
            return 1

    print("\n  Deleting server account...", end="", flush=True)
    result = _delete(
        f"{api_url}/api/account",
        {"Authorization": f"Bearer {api_key}"},
    )
    status = result.get("_status")
    if result.get("error") == "network":
        print(" failed.")
        print("  Could not reach CoreTx servers. Local state was not touched.\n")
        return 1
    # Success = 2xx or 404 (already gone). Anything else (including a missing
    # status with an error string) means the server did not confirm deletion;
    # leave local state intact so the user can retry without losing the key.
    if status == 404:
        print(" already gone.")
    elif status is not None and 200 <= status < 300:
        print(" done.")
    else:
        label = f"HTTP {status}" if status is not None else "no response"
        print(f" failed ({label}).")
        print(f"  {result.get('error', 'Unknown error')}")
        print("  Local state was not touched. Re-run when the issue is resolved.\n")
        return 1

    return _wipe_local()


def _wipe_local() -> int:
    """Remove ~/.coretx/config.json and ~/.coretx/signing.key. Idempotent."""
    print("  Removing local state...", end="", flush=True)
    removed: list[str] = []
    for path in (CONFIG_PATH, SIGNING_KEY_PATH):
        if path.exists():
            try:
                path.unlink()
                removed.append(path.name)
            except OSError as e:
                print(f" failed.\n  Could not remove {path}: {e}\n")
                return 1
    print(" done.")
    if removed:
        print(f"  Removed: {', '.join(removed)}")
    print("\n  Wipe complete.\n")
    return 0


def cmd_logout(args: list[str]) -> int:
    if remove_config():
        print(f"\n  Signed out. Config removed from {CONFIG_PATH}\n")
    else:
        print("\n  No config found. Nothing to remove.\n")
    return 0


def cmd_help() -> int:
    print(f"""
  CoreTx v{__version__}
  Structured memory for AI that persists, attributes, and connects.

  Usage: coretx <command> [options]

  Commands:
    init              Create account and configure API key
    init --key KEY    Set API key manually (skip signup)
    status            Show current config and connectivity
    logout            Remove saved config
    wipe              Delete CoreTx account (server) + local config + signing key
    wipe --yes        Skip the confirmation prompt
    serve             Run the MCP server (default)
    setup [KEY]              Wire ko-memory MCP server into Claude Desktop + Claude Code (also saves KEY to ~/.coretx/config.json). Detects Cursor/Windsurf and points to the waitlist if found.
    setup [KEY] --bootstrap     Same, plus immediately bootstrap KOs from Claude Code history (LLM, ~$0.01–0.02/session)
    setup [KEY] --no-bootstrap  Same, but skip the bootstrap offer entirely
    setup [KEY] --skip-cursor   Suppress the Cursor-detected waitlist notice
    setup [KEY] --skip-windsurf Suppress the Windsurf-detected waitlist notice
    setup --remove           Unwire ko-memory from Claude Desktop + Claude Code (does not touch local config or your account)
    test              Verify API connectivity
    bootstrap                Extract KOs from Claude Code session logs
    bootstrap --dry-run      Preview without writing (regex, free)
    bootstrap --llm          LLM extraction (Haiku, ~$0.01/session, much higher quality)
    bootstrap undo <run_id>  Roll back a bootstrap run by manifest id

  Options:
    --api-url URL     Override API server URL
    --version         Show version
    --help            Show this message
""")
    return 0


# -- Entry point ------------------------------------------------------------

def main() -> None:
    args = sys.argv[1:]
    if not args or args[0] == "serve":
        from coretx.server import main as server_main
        server_main()
        return
    cmd, rest = args[0], args[1:]
    if cmd == "--version":
        print(f"coretx {__version__}"); return
    if cmd in ("--help", "-h", "help"):
        cmd_help(); return
    if cmd == "init":
        sys.exit(cmd_init(rest))
    if cmd == "status":
        sys.exit(cmd_status(rest))
    if cmd == "logout":
        sys.exit(cmd_logout(rest))
    if cmd == "wipe":
        sys.exit(cmd_wipe(rest))
    if cmd in ("setup", "test", "--test"):
        from coretx.server import main as server_main
        server_main(); return
    if cmd == "bootstrap":
        from coretx.bootstrap import main as bootstrap_main
        bootstrap_main(); return
    if cmd == "reclassify":
        from coretx.reclassify import main as reclassify_main
        reclassify_main(); return
    print(f"  Unknown command: {cmd}")
    print(f"  Run 'coretx --help' for usage.")
    sys.exit(1)
