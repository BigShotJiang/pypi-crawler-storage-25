function byId(id) {
    return document.getElementById(id);
}

function showToast(message) {
    const toastEl = byId("toast");
    if (!toastEl) {
        return;
    }
    toastEl.textContent = message;
    toastEl.hidden = false;
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => {
        toastEl.hidden = true;
    }, 6000);
}

function flushPendingToast() {
    const pending = sessionStorage.getItem("pendingToast");
    if (pending) {
        showToast(pending);
        sessionStorage.removeItem("pendingToast");
    }
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", flushPendingToast);
} else {
    flushPendingToast();
}

function escapeHtml(s) {
    if (s == null || s === "") {
        return "";
    }
    return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function normalizeUser(s) {
    return String(s || "")
        .trim()
        .toLowerCase()
        .replace(/\//g, "\\");
}

function formatCell(v) {
    if (v == null) {
        return "—";
    }
    if (typeof v === "object") {
        return escapeHtml(JSON.stringify(v));
    }
    return escapeHtml(v);
}

function renderDataTable(items, emptyLabel) {
    if (!items || !items.length) {
        return `<p class="empty-hint">${escapeHtml(emptyLabel)}</p>`;
    }
    const keys = [...new Set(items.flatMap((row) => (row && typeof row === "object" ? Object.keys(row) : [])))];
    if (!keys.length) {
        return `<p class="empty-hint">${escapeHtml(emptyLabel)}</p>`;
    }
    const thead = `<tr>${keys.map((k) => `<th>${escapeHtml(k)}</th>`).join("")}</tr>`;
    const tbody = items
        .map((row) => {
            if (!row || typeof row !== "object") {
                return `<tr><td colspan="${keys.length}">${formatCell(row)}</td></tr>`;
            }
            return `<tr>${keys.map((k) => `<td>${formatCell(row[k])}</td>`).join("")}</tr>`;
        })
        .join("");
    return `<div class="table-wrap"><table class="data-table"><thead>${thead}</thead><tbody>${tbody}</tbody></table></div>`;
}

function findMachineCard(machineName) {
    const cards = document.querySelectorAll(".machine-card");
    for (const card of cards) {
        if (card.dataset.machine === machineName) {
            return card;
        }
    }
    return null;
}

async function fetchRdpTarget(machineName, actingAs) {
    const params = new URLSearchParams();
    if (actingAs && String(actingAs).trim()) {
        params.set("acting_as", String(actingAs).trim());
    }
    const q = params.toString();
    const url = `/api/machines/${encodeURIComponent(machineName)}/rdp-target${q ? `?${q}` : ""}`;
    const res = await fetch(url);
    if (!res.ok) {
        let msg = "Could not get RDP target.";
        const ct = res.headers.get("content-type") || "";
        if (ct.includes("application/json")) {
            const err = await res.json().catch(() => ({}));
            if (err.detail) {
                msg = typeof err.detail === "string" ? err.detail : JSON.stringify(err.detail);
            }
        }
        throw new Error(msg);
    }
    return res.json();
}

function resetRdpLaunchUi() {
    const main = byId("rdpMainStack");
    const panel = byId("rdpLaunchPanel");
    const link = byId("rdpLaunchLink");
    if (main) {
        main.hidden = false;
    }
    if (panel) {
        panel.hidden = true;
    }
    if (link) {
        link.href = "#";
    }
}

function showRdpLaunchPanel(protocolUrl, reloadAfterClose) {
    const main = byId("rdpMainStack");
    const panel = byId("rdpLaunchPanel");
    const link = byId("rdpLaunchLink");
    if (!panel || !link) {
        return;
    }
    link.href = protocolUrl;
    if (main) {
        main.hidden = true;
    }
    panel.hidden = false;
    if (reloadAfterClose) {
        sessionStorage.setItem("reloadAfterRdp", "1");
    } else {
        sessionStorage.removeItem("reloadAfterRdp");
    }
}

async function copyText(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast("Copied to clipboard.");
    } catch {
        prompt("Copy this command:", text);
    }
}

async function downloadRdpFile(machineName, actingAs) {
    const params = new URLSearchParams();
    if (actingAs && String(actingAs).trim()) {
        params.set("acting_as", String(actingAs).trim());
    }
    const q = params.toString();
    const res = await fetch(`/api/machines/${encodeURIComponent(machineName)}/rdp${q ? `?${q}` : ""}`);
    if (!res.ok) {
        let message = "Could not build RDP file.";
        const ct = res.headers.get("content-type") || "";
        if (ct.includes("application/json")) {
            const err = await res.json().catch(() => ({}));
            message = typeof err.detail === "string" ? err.detail : message;
        } else {
            const t = await res.text().catch(() => "");
            if (t) {
                message = t.slice(0, 400);
            }
        }
        throw new Error(message);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${machineName}.rdp`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}

function renderDetails(data) {
    if (!data || typeof data !== "object") {
        return '<p class="details-error">Invalid response from server.</p>';
    }
    const machine = data.machine;
    if (!machine || typeof machine !== "object") {
        return '<p class="details-error">Missing machine data in response.</p>';
    }

    const appUsage = data.app_usage && typeof data.app_usage === "object" ? data.app_usage : {};
    const apps =
        Array.isArray(appUsage.apps_with_users) && appUsage.apps_with_users.length
            ? appUsage.apps_with_users
            : Array.isArray(appUsage.tracked_processes)
              ? appUsage.tracked_processes
              : [];
    const listening = Array.isArray(data.listening_ports) ? data.listening_ports : [];
    const camera = Array.isArray(data.camera_usage) ? data.camera_usage : [];
    const comPorts = Array.isArray(data.active_com_ports) ? data.active_com_ports : [];
    const sessions = Array.isArray(data.active_sessions) ? data.active_sessions : [];

    const locked = Boolean(data.lock_state && data.lock_state.is_locked);
    const lockUser =
        data.lock_state && data.lock_state.lock_user != null ? String(data.lock_state.lock_user) : "";
    const lockBadge = locked
        ? `<span class="badge badge--lock">Locked · ${escapeHtml(lockUser || "—")}</span>`
        : `<span class="badge badge--free">Available</span>`;

    const pollLine =
        data.poll_interval_seconds != null
            ? `Background refresh ~every ${escapeHtml(String(data.poll_interval_seconds))}s · source: ${escapeHtml(
                  String(data.source || "")
              )}`
            : `Source: ${escapeHtml(String(data.source || ""))}`;

    const rawErr = Array.isArray(data.raw_errors) ? data.raw_errors : [];
    const errors =
        rawErr.length > 0
            ? `<div class="alert alert--warn"><strong>Probe notes</strong><ul>${rawErr
                  .map((e) => `<li>${escapeHtml(String(e))}</li>`)
                  .join("")}</ul></div>`
            : "";

    const name = String(machine.name || "");
    const hostname = String(machine.hostname || "");
    const ip = machine.ip_address != null ? String(machine.ip_address) : "no IP";

    return `
        <div class="details-hero">
            <div>
                <h2 class="details-hero__title">${escapeHtml(name)}</h2>
                <p class="details-hero__sub">${escapeHtml(hostname)} · ${escapeHtml(ip)}</p>
            </div>
            <div class="details-hero__badges">${lockBadge}</div>
        </div>
        <p class="details-meta">${escapeHtml(pollLine)} · snapshot ${escapeHtml(data.collected_at || "—")}</p>
        <button type="button" class="btn btn--secondary btn--sm details-live-refresh" data-machine="${escapeHtml(
            name
        )}">Refresh now (live probe)</button>
        ${errors}
        <section class="detail-section">
            <h3 class="detail-section__title">Interactive sessions</h3>
            ${renderDataTable(sessions, "No session rows returned (remote probe may need admin / WinRM).")}
        </section>
        <section class="detail-section">
            <h3 class="detail-section__title">Applications &amp; Windows user</h3>
            <p class="detail-section__lead">Terminal tools, ETGui, Remote Desktop client, etc., with process owner when WinRM allows.</p>
            ${renderDataTable(
                apps,
                "No matching applications found (patterns may need expanding, or probe lacks permission)."
            )}
        </section>
        <section class="detail-section">
            <h3 class="detail-section__title">Listening TCP ports</h3>
            <p class="detail-section__lead">Ports used by tracked tools or common lab ports (SSH, serial tunnels, RDP, VNC, …).</p>
            ${renderDataTable(listening, "No listening ports matched (firewall or probe permissions).")}
        </section>
        <section class="detail-section">
            <h3 class="detail-section__title">Camera-related processes</h3>
            ${renderDataTable(camera, "None detected.")}
        </section>
        <section class="detail-section">
            <h3 class="detail-section__title">COM / serial devices</h3>
            ${renderDataTable(comPorts, "No serial devices reported.")}
        </section>
    `;
}

async function showDetails(machineName, live) {
    const detailsContent = byId("detailsContent");
    const detailsDialog = byId("detailsDialog");
    if (!detailsContent || !detailsDialog) {
        return;
    }
    detailsContent.innerHTML = '<div class="details-loading"><span class="spinner"></span> Loading…</div>';
    detailsDialog.showModal();
    const query = live ? "?live=1" : "";
    try {
        const response = await fetch(`/api/machines/${encodeURIComponent(machineName)}/details${query}`);
        if (!response.ok) {
            const ct = response.headers.get("content-type") || "";
            let msg = "Could not load details.";
            if (ct.includes("application/json")) {
                const err = await response.json().catch(() => ({}));
                if (err.detail) {
                    msg = typeof err.detail === "string" ? err.detail : JSON.stringify(err.detail);
                }
            }
            detailsContent.innerHTML = `<p class="details-error">${escapeHtml(msg)}</p>`;
            return;
        }
        const data = await response.json();
        detailsContent.innerHTML = renderDetails(data);
    } catch (e) {
        detailsContent.innerHTML = `<p class="details-error">${escapeHtml(e.message || "Failed to load details.")}</p>`;
    }
}

async function postJson(url, payload) {
    const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
    });
    if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        const message = data.detail || "Request failed.";
        alert(typeof message === "string" ? message : JSON.stringify(message));
        throw new Error(typeof message === "string" ? message : "Request failed.");
    }
}

function initDashboard() {
    const lockDialog = byId("lockDialog");
    const releaseDialog = byId("releaseDialog");
    const detailsDialog = byId("detailsDialog");
    const rdpDialog = byId("rdpDialog");

    const detailsContentHost = byId("detailsContent");
    if (detailsContentHost) {
        detailsContentHost.addEventListener("click", async (event) => {
            const button = event.target.closest(".details-live-refresh");
            if (!button) {
                return;
            }
            event.preventDefault();
            const machineName = button.getAttribute("data-machine");
            if (machineName) {
                await showDetails(machineName, true);
            }
        });
    }

    const lockCancel = byId("lockCancel");
    if (lockCancel && lockDialog) {
        lockCancel.addEventListener("click", () => lockDialog.close());
    }
    const releaseCancel = byId("releaseCancel");
    if (releaseCancel && releaseDialog) {
        releaseCancel.addEventListener("click", () => releaseDialog.close());
    }
    const rdpCancel = byId("rdpCancel");
    if (rdpCancel && rdpDialog) {
        rdpCancel.addEventListener("click", () => {
            resetRdpLaunchUi();
            rdpDialog.close();
        });
    }
    const detailsCloseBtn = byId("detailsCloseBtn");
    if (detailsCloseBtn && detailsDialog) {
        detailsCloseBtn.addEventListener("click", () => detailsDialog.close());
    }

    const rdpDoneAfterLaunch = byId("rdpDoneAfterLaunch");
    if (rdpDoneAfterLaunch && rdpDialog) {
        rdpDoneAfterLaunch.addEventListener("click", () => {
            const reload = sessionStorage.getItem("reloadAfterRdp") === "1";
            resetRdpLaunchUi();
            rdpDialog.close();
            sessionStorage.removeItem("reloadAfterRdp");
            if (reload) {
                window.location.reload();
            }
        });
    }

    document.querySelectorAll(".machine-card").forEach((card) => {
        const machineName = card.dataset.machine;
        if (!machineName) {
            return;
        }
        const lockBtn = card.querySelector(".lock-btn");
        const releaseBtn = card.querySelector(".release-btn");
        const detailsBtn = card.querySelector(".details-btn");
        const rdpBtn = card.querySelector(".rdp-btn");
        if (lockBtn && lockDialog) {
            lockBtn.addEventListener("click", () => {
                const el = byId("lockMachineName");
                if (el) {
                    el.value = machineName;
                }
                lockDialog.showModal();
            });
        }
        if (releaseBtn && releaseDialog) {
            releaseBtn.addEventListener("click", () => {
                const el = byId("releaseMachineName");
                if (el) {
                    el.value = machineName;
                }
                releaseDialog.showModal();
            });
        }
        if (detailsBtn) {
            detailsBtn.addEventListener("click", async () => {
                await showDetails(machineName, false);
            });
        }
        if (rdpBtn) {
            rdpBtn.addEventListener("click", () => openRdpDialog(machineName));
        }
    });

    function syncRdpLockFields() {
        const chk = byId("rdpLockFirst");
        const box = byId("rdpLockFields");
        if (!chk || !box) {
            return;
        }
        const on = chk.checked;
        box.hidden = !on;
        ["rdpRequestedBy", "rdpLockUser", "rdpTaskReason"].forEach((id) => {
            const el = byId(id);
            if (el) {
                el.required = on;
            }
        });
    }

    const rdpLockFirst = byId("rdpLockFirst");
    if (rdpLockFirst) {
        rdpLockFirst.addEventListener("change", syncRdpLockFields);
    }

    async function openRdpDialog(machineName) {
        resetRdpLaunchUi();
        const line = byId("rdpTargetLine");
        const nameEl = byId("rdpMachineName");
        const hostEl = byId("rdpHost");
        const portEl = byId("rdpPort");
        const actingEl = byId("rdpActingAs");
        const hint = byId("rdpLockHint");
        const card = findMachineCard(machineName);
        if (!nameEl || !hostEl || !portEl || !rdpDialog) {
            return;
        }
        nameEl.value = machineName;
        hostEl.value = "";
        portEl.value = "";
        if (actingEl) {
            actingEl.value = "";
        }
        if (card && card.dataset.isLocked === "1") {
            if (actingEl) {
                actingEl.value = card.dataset.lockUser || "";
            }
            if (hint) {
                hint.hidden = false;
                hint.textContent = `This machine is reserved for Windows user “${card.dataset.lockUser || "?"}”. Enter the same value in Connecting as (or release first).`;
            }
        } else if (hint) {
            hint.hidden = true;
        }
        if (line) {
            line.innerHTML = 'Resolving target… <a href="/setup/rdp" target="_blank" rel="noopener">Handler setup</a>';
        }
        try {
            const acting =
                actingEl && actingEl.value.trim()
                    ? actingEl.value.trim()
                    : card && card.dataset.isLocked === "1"
                      ? card.dataset.lockUser || ""
                      : "";
            const t = await fetchRdpTarget(machineName, acting || undefined);
            hostEl.value = String(t.host || "");
            portEl.value = String(t.port != null ? t.port : 3389);
            const displayHost = hostEl.value || "—";
            const displayPort = portEl.value || "3389";
            if (line) {
                line.innerHTML = `Connect to <strong>${escapeHtml(displayHost)}:${escapeHtml(
                    displayPort
                )}</strong> · <span class="mono-inline">${escapeHtml(t.protocol_url || "")}</span> ·
                <a href="/setup/rdp" target="_blank" rel="noopener">One-time setup</a>`;
            }
        } catch (e) {
            if (line) {
                line.innerHTML = `<span class="details-error">${escapeHtml(e.message || "Could not resolve target.")}</span>`;
            }
            showToast(e.message || "Could not resolve RDP target.");
        }

        const rb = byId("rdpRequestedBy");
        const lu = byId("rdpLockUser");
        const tr = byId("rdpTaskReason");
        const lfirst = byId("rdpLockFirst");
        if (rb) {
            rb.value = "";
        }
        if (lu) {
            lu.value = "";
        }
        if (tr) {
            tr.value = "";
        }
        if (lfirst) {
            lfirst.checked = true;
        }
        syncRdpLockFields();
        rdpDialog.showModal();
    }

    async function runRdpWithOptionalLock(lockFirst) {
        const machineName = (byId("rdpMachineName") && byId("rdpMachineName").value) || "";
        const card = findMachineCard(machineName);
        const serverLocked = card && card.dataset.isLocked === "1";
        const actingField = byId("rdpActingAs");
        const actingTyped = actingField ? actingField.value.trim() : "";

        let actingForApi = "";

        try {
            if (lockFirst) {
                const requestedBy = byId("rdpRequestedBy") && byId("rdpRequestedBy").value.trim();
                const lockUser = byId("rdpLockUser") && byId("rdpLockUser").value.trim();
                const reason = byId("rdpTaskReason") && byId("rdpTaskReason").value.trim();
                if (requestedBy.length < 2 || lockUser.length < 2 || reason.length < 5) {
                    alert("Fill in your name, allowed user, and task (min 5 characters) to reserve before connecting.");
                    return;
                }
                await postJson(`/api/machines/${encodeURIComponent(machineName)}/lock`, {
                    requested_by: requestedBy,
                    lock_user: lockUser,
                    reason,
                });
                actingForApi = lockUser;
                if (actingField) {
                    actingField.value = lockUser;
                }
            } else {
                actingForApi = actingTyped;
                if (serverLocked) {
                    if (!actingForApi) {
                        alert('Enter “Connecting as” with the reserved Windows user (see hint), or release the machine.');
                        return;
                    }
                    const lu = (card && card.dataset.lockUser) || "";
                    if (normalizeUser(actingForApi) !== normalizeUser(lu)) {
                        alert(
                            `This machine is reserved for “${lu}”. Use that exact Windows user in Connecting as, or release first.`
                        );
                        return;
                    }
                }
            }

            const data = await fetchRdpTarget(machineName, actingForApi || undefined);
            showRdpLaunchPanel(data.protocol_url, Boolean(lockFirst));
            showToast(
                lockFirst
                    ? "Click “Open Remote Desktop”. When finished, use Release on the dashboard."
                    : "Click “Open Remote Desktop”. If nothing opens, use Setup or Copy mstsc command."
            );
        } catch (e) {
            if (e && e.message) {
                alert(e.message);
            }
        }
    }

    const rdpOpenConnect = byId("rdpOpenConnect");
    if (rdpOpenConnect) {
        rdpOpenConnect.addEventListener("click", async () => {
            const lockFirst = byId("rdpLockFirst") && byId("rdpLockFirst").checked;
            await runRdpWithOptionalLock(Boolean(lockFirst));
        });
    }
    const rdpOpenOnly = byId("rdpOpenOnly");
    if (rdpOpenOnly) {
        rdpOpenOnly.addEventListener("click", async () => {
            await runRdpWithOptionalLock(false);
        });
    }
    const rdpCopyMstsc = byId("rdpCopyMstsc");
    if (rdpCopyMstsc) {
        rdpCopyMstsc.addEventListener("click", async () => {
            const machineName = (byId("rdpMachineName") && byId("rdpMachineName").value) || "";
            const acting = (byId("rdpActingAs") && byId("rdpActingAs").value.trim()) || "";
            const card = findMachineCard(machineName);
            if (card && card.dataset.isLocked === "1" && !acting) {
                alert("Enter Connecting as (reserved Windows user) before copying the command.");
                return;
            }
            try {
                const t = await fetchRdpTarget(machineName, acting || undefined);
                await copyText(t.mstsc_command);
            } catch (e) {
                alert(e.message || "Could not build command.");
            }
        });
    }
    const rdpDownloadFile = byId("rdpDownloadFile");
    if (rdpDownloadFile) {
        rdpDownloadFile.addEventListener("click", async () => {
            const machineName = (byId("rdpMachineName") && byId("rdpMachineName").value) || "";
            const acting = (byId("rdpActingAs") && byId("rdpActingAs").value.trim()) || "";
            const card = findMachineCard(machineName);
            if (card && card.dataset.isLocked === "1" && !acting) {
                alert("Enter Connecting as (reserved Windows user) before downloading.");
                return;
            }
            try {
                await downloadRdpFile(machineName, acting || undefined);
                showToast("Open the downloaded .rdp file to start Remote Desktop.");
            } catch (e) {
                alert(e.message || "Download failed.");
            }
        });
    }

    const lockForm = byId("lockForm");
    if (lockForm && lockDialog) {
        lockForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            const machineName = (byId("lockMachineName") && byId("lockMachineName").value) || "";
            const rq = byId("lockRequestedBy");
            const u = byId("lockUser");
            const r = byId("lockReason");
            const payload = {
                requested_by: (rq && rq.value.trim()) || "",
                lock_user: (u && u.value.trim()) || "",
                reason: (r && r.value.trim()) || "",
            };
            await postJson(`/api/machines/${encodeURIComponent(machineName)}/lock`, payload);
            lockDialog.close();
            window.location.reload();
        });
    }

    const releaseForm = byId("releaseForm");
    if (releaseForm && releaseDialog) {
        releaseForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            const mn = byId("releaseMachineName");
            const rb = byId("releaseRequestedBy");
            const rr = byId("releaseReason");
            const machineName = (mn && mn.value) || "";
            const payload = {
                requested_by: (rb && rb.value.trim()) || "",
                reason: (rr && rr.value.trim()) || "",
            };
            await postJson(`/api/machines/${encodeURIComponent(machineName)}/release`, payload);
            releaseDialog.close();
            sessionStorage.setItem("pendingToast", "Machine released — anyone on the network can use it again.");
            window.location.reload();
        });
    }
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initDashboard);
} else {
    initDashboard();
}
