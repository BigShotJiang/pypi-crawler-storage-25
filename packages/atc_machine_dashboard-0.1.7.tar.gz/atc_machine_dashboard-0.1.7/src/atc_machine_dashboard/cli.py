"""Console entry point for the PyPI distribution."""

from __future__ import annotations

import argparse
import os
import sys


def main(argv: list[str] | None = None) -> None:
    if argv is None:
        argv = sys.argv[1:]
    parser = argparse.ArgumentParser(
        prog="atc-machine-dashboard",
        description="ATC lab machine web dashboard (FastAPI + uvicorn).",
    )
    parser.add_argument(
        "--host",
        default=os.environ.get("ATC_DASHBOARD_HOST", "0.0.0.0"),
        help="Bind address (default: 0.0.0.0 or ATC_DASHBOARD_HOST).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("ATC_DASHBOARD_PORT", os.environ.get("PORT", "8080"))),
        help="TCP port (default: 8080, or ATC_DASHBOARD_PORT / PORT).",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Development only: reload on code changes.",
    )
    args = parser.parse_args(argv)

    import uvicorn

    uvicorn.run(
        "atc_machine_dashboard.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
