# One-time: register with register-atc-rdp.reg (see /setup/rdp in the dashboard).
# Launches mstsc.exe for URLs like: atc-rdp://192.168.1.10:3389
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string] $Uri
)
$ErrorActionPreference = 'Stop'
if ($Uri -notmatch '^atc-rdp://([^/?#]+)(?::(\d+))?') {
    [Console]::Error.WriteLine("Invalid URI (expected atc-rdp://host or atc-rdp://host:port): $Uri")
    exit 1
}
$target = $Matches[1]
$port = if ($Matches[2]) { $Matches[2] } else { '3389' }
$mstsc = Join-Path $env:SystemRoot 'System32\mstsc.exe'
if (-not (Test-Path -LiteralPath $mstsc)) {
    [Console]::Error.WriteLine("mstsc.exe not found at $mstsc")
    exit 1
}
Start-Process -FilePath $mstsc -ArgumentList "/v:${target}:${port}"
