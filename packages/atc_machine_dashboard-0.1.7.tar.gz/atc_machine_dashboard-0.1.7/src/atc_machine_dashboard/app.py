from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
import subprocess
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress
from datetime import date, datetime, timezone
from importlib import resources
from io import StringIO
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Any
from uuid import UUID

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from starlette.requests import Request
from starlette.responses import JSONResponse

from atc_machine_dashboard import __version__


def _to_json_safe(obj: Any) -> Any:
    """Recursively build JSON-serializable data (stdlib types only)."""
    if obj is None:
        return None
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, (int, float, str)):
        return obj
    if isinstance(obj, BaseModel):
        return _to_json_safe(obj.model_dump(mode="json"))
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, date):
        return obj.isoformat()
    if isinstance(obj, UUID):
        return str(obj)
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, dict):
        return {str(k): _to_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_json_safe(v) for v in obj]
    if isinstance(obj, set):
        return [_to_json_safe(v) for v in sorted(obj, key=lambda x: str(x))]
    if isinstance(obj, (bytes, bytearray)):
        return bytes(obj).decode("utf-8", errors="replace")
    return str(obj)


def _json_response(data: Any) -> JSONResponse:
    """Bypass FastAPI jsonable_encoder (it can raise TypeError: unhashable type: 'dict')."""
    return JSONResponse(_to_json_safe(data))


def _normalize_lock_row(raw: dict[str, Any]) -> dict[str, Any]:
    """Stable shape for templates + JSON (SQLite may store 0/1 for booleans)."""

    def _txt(v: Any) -> str | None:
        if v is None:
            return None
        if isinstance(v, (bytes, bytearray)):
            return bytes(v).decode("utf-8", errors="replace")
        return str(v)

    return {
        "machine_name": _txt(raw.get("machine_name")),
        "is_locked": bool(raw.get("is_locked")),
        "lock_user": _txt(raw.get("lock_user")),
        "reason": _txt(raw.get("reason")),
        "requested_by": _txt(raw.get("requested_by")),
        "updated_at": _txt(raw.get("updated_at")),
    }


class Machine(BaseModel):
    name: str
    hostname: str
    ip_address: str | None = None
    rdp_port: int = 3389
    tags: list[str] = Field(default_factory=list)


class LockRequest(BaseModel):
    requested_by: str = Field(min_length=2, max_length=100)
    lock_user: str = Field(min_length=2, max_length=100)
    reason: str = Field(min_length=5, max_length=500)


class ReleaseRequest(BaseModel):
    requested_by: str = Field(min_length=2, max_length=100)
    reason: str = Field(min_length=5, max_length=500)


PACKAGE_DIR = Path(__file__).resolve().parent


def _data_dir() -> Path:
    return Path(os.environ.get("MACHINE_DASHBOARD_DATA_DIR", Path.cwd()))


DATA_DIR = _data_dir()
INVENTORY_PATH = Path(os.environ.get("MACHINE_DASHBOARD_INVENTORY", DATA_DIR / "machines.json"))
DB_PATH = Path(os.environ.get("MACHINE_DASHBOARD_DB", DATA_DIR / "machine_dashboard.db"))
LOCK_SCRIPT = os.environ.get("MACHINE_DASHBOARD_LOCK_SCRIPT")
RELEASE_SCRIPT = os.environ.get("MACHINE_DASHBOARD_RELEASE_SCRIPT")

# Background polling: probe all machines every N seconds (set to 0 to disable).
_POLL_SECONDS_RAW = os.environ.get("MACHINE_DASHBOARD_POLL_SECONDS", "60")
POLL_SECONDS = float(_POLL_SECONDS_RAW) if _POLL_SECONDS_RAW.strip() else 0.0
POLL_ENABLED = os.environ.get("MACHINE_DASHBOARD_POLL_ENABLED", "1").strip().lower() not in (
    "0",
    "false",
    "no",
    "off",
)

_logger = logging.getLogger("atc_machine_dashboard")


def _ensure_default_inventory() -> None:
    """If default machines.json is missing, copy machines.example.json once."""
    if os.environ.get("MACHINE_DASHBOARD_INVENTORY"):
        return
    default_path = DATA_DIR / "machines.json"
    local_example = PACKAGE_DIR / "machines.example.json"
    if default_path.exists():
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        text = resources.files("atc_machine_dashboard").joinpath("machines.example.json").read_text(encoding="utf-8")
    except (OSError, FileNotFoundError, TypeError, ValueError):
        if local_example.exists():
            text = local_example.read_text(encoding="utf-8")
        else:
            _logger.warning("Bundled machines.example.json not found; create %s manually.", default_path)
            return
    default_path.write_text(text, encoding="utf-8")
    _logger.warning(
        "Created %s from machines.example.json — edit hostnames and IPs for your network.",
        default_path,
    )


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    init_db()
    _ensure_default_inventory()
    poll_task: asyncio.Task[None] | None = None
    if POLL_ENABLED and POLL_SECONDS > 0:
        poll_task = asyncio.create_task(_poll_loop(), name="machine_dashboard_poll")
    try:
        yield
    finally:
        if poll_task is not None:
            poll_task.cancel()
            with suppress(asyncio.CancelledError):
                await poll_task


app = FastAPI(title="ATC Machine Dashboard", version=__version__, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=PACKAGE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(PACKAGE_DIR / "templates"))

_FAVICON_PATH = PACKAGE_DIR / "static" / "favicon.svg"
_ALLOWED_EXTRA_FILES = frozenset({"Open-AtcRdp.ps1", "register-atc-rdp.reg.template"})


@app.get("/favicon.ico", include_in_schema=False)
def favicon() -> FileResponse:
    """Browsers request /favicon.ico by default; serve bundled SVG to avoid 404 noise."""
    return FileResponse(_FAVICON_PATH, media_type="image/svg+xml")


@app.get("/setup/rdp", response_class=HTMLResponse)
def setup_rdp(request: Request) -> HTMLResponse:
    tpl = templates.get_template("setup_rdp.html")
    return HTMLResponse(content=tpl.render(request=request))


@app.get("/extras/{filename}", include_in_schema=False)
def serve_extra(filename: str) -> FileResponse:
    safe = Path(filename).name
    if safe not in _ALLOWED_EXTRA_FILES:
        raise HTTPException(status_code=404, detail="Not found")
    path = PACKAGE_DIR / "extras" / safe
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(path, media_type="text/plain; charset=utf-8", filename=safe)


def load_machines() -> list[Machine]:
    if not INVENTORY_PATH.exists():
        hint = (
            f"Missing inventory: {INVENTORY_PATH}. "
            "Set MACHINE_DASHBOARD_INVENTORY, or place machines.json under MACHINE_DASHBOARD_DATA_DIR "
            f"(default: current directory, currently {DATA_DIR}). "
            "Run once so auto-seed can create machines.json from the bundled example."
        )
        raise FileNotFoundError(hint)
    payload = json.loads(INVENTORY_PATH.read_text(encoding="utf-8"))
    return [Machine.model_validate(item) for item in payload["machines"]]


def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS machine_locks (
                machine_name TEXT PRIMARY KEY,
                is_locked INTEGER NOT NULL,
                lock_user TEXT,
                reason TEXT,
                requested_by TEXT,
                updated_at TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS lock_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                machine_name TEXT NOT NULL,
                action TEXT NOT NULL,
                lock_user TEXT,
                reason TEXT NOT NULL,
                requested_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS machine_snapshots (
                machine_name TEXT PRIMARY KEY,
                collected_at TEXT NOT NULL,
                payload_json TEXT NOT NULL
            )
            """
        )


def get_lock_state(machine_name: str) -> dict[str, Any]:
    with connect_db() as conn:
        row = conn.execute("SELECT * FROM machine_locks WHERE machine_name = ?", (machine_name,)).fetchone()
    if row is None:
        return _normalize_lock_row(
            {"machine_name": machine_name, "is_locked": False, "lock_user": None, "reason": None}
        )
    return _normalize_lock_row(dict(row))


def write_lock(machine_name: str, lock_user: str, reason: str, requested_by: str) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as conn:
        conn.execute(
            """
            INSERT INTO machine_locks(machine_name, is_locked, lock_user, reason, requested_by, updated_at)
            VALUES (?, 1, ?, ?, ?, ?)
            ON CONFLICT(machine_name)
            DO UPDATE SET is_locked=1, lock_user=excluded.lock_user, reason=excluded.reason,
                          requested_by=excluded.requested_by, updated_at=excluded.updated_at
            """,
            (machine_name, lock_user, reason, requested_by, now),
        )
        conn.execute(
            """
            INSERT INTO lock_history(machine_name, action, lock_user, reason, requested_by, created_at)
            VALUES (?, 'lock', ?, ?, ?, ?)
            """,
            (machine_name, lock_user, reason, requested_by, now),
        )
    return get_lock_state(machine_name)


def write_release(machine_name: str, reason: str, requested_by: str) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    with connect_db() as conn:
        prev = conn.execute("SELECT lock_user FROM machine_locks WHERE machine_name = ?", (machine_name,)).fetchone()
        prior_lock_user = prev["lock_user"] if prev else None
        conn.execute(
            """
            INSERT INTO machine_locks(machine_name, is_locked, lock_user, reason, requested_by, updated_at)
            VALUES (?, 0, NULL, ?, ?, ?)
            ON CONFLICT(machine_name)
            DO UPDATE SET is_locked=0, lock_user=NULL, reason=excluded.reason,
                          requested_by=excluded.requested_by, updated_at=excluded.updated_at
            """,
            (machine_name, reason, requested_by, now),
        )
        conn.execute(
            """
            INSERT INTO lock_history(machine_name, action, lock_user, reason, requested_by, created_at)
            VALUES (?, 'release', ?, ?, ?, ?)
            """,
            (machine_name, prior_lock_user, reason, requested_by, now),
        )
    return get_lock_state(machine_name)


def run_script(command: str) -> str | None:
    out = subprocess.run(["powershell", "-NoProfile", "-Command", command], capture_output=True, text=True, timeout=25)
    if out.returncode != 0:
        return out.stderr.strip() or "policy script failed"
    return None


def run_probe(hostname: str, script_block: str) -> tuple[Any, str | None]:
    # Avoid embedding `{ ... }` in -ScriptBlock { ... } — inner `}` would truncate the block.
    # Single-quote the script for [scriptblock]::Create and double embedded single quotes.
    esc = script_block.replace("'", "''")
    ps_cmd = (
        f"$sb = [scriptblock]::Create('{esc}'); "
        f"Invoke-Command -ComputerName '{hostname}' -ScriptBlock $sb | ConvertTo-Json -Depth 6"
    )
    cmd = ["powershell", "-NoProfile", "-Command", ps_cmd]
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
    if out.returncode != 0:
        return None, out.stderr.strip() or "probe failed"
    if not out.stdout.strip():
        return [], None
    try:
        return json.loads(out.stdout), None
    except json.JSONDecodeError as exc:
        return None, str(exc)


def normalize(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        return [payload]
    return []


def _normalize_identity(value: str | None) -> str:
    if not value:
        return ""
    s = str(value).strip().lower()
    s = s.replace("/", "\\")
    return s


def _rdp_lock_denied_detail(machine_name: str) -> str:
    st = get_lock_state(machine_name)
    lu = (st.get("lock_user") or "").strip()
    if lu:
        return (
            f"Machine is reserved for Windows user {lu!r} only. "
            "Use the same value in “Connecting as”, or release the machine first."
        )
    return "Machine is locked. Release it first or connect as the reserved user."


def assert_rdp_allowed(machine_name: str, acting_as: str | None) -> None:
    """Block RDP helper endpoints when locked unless acting_as matches lock_user."""
    st = get_lock_state(machine_name)
    if not st.get("is_locked"):
        return
    lock_user = _normalize_identity(st.get("lock_user"))
    actor = _normalize_identity(acting_as)
    if not actor:
        raise HTTPException(status_code=403, detail=_rdp_lock_denied_detail(machine_name))
    if actor != lock_user:
        raise HTTPException(status_code=403, detail=_rdp_lock_denied_detail(machine_name))


_APPS_AND_PORTS_SCRIPT = r"""
$patterns = @(
  '*MobaXterm*','*mobaxterm*','*PuTTY*','*putty*','*ETGui*','*etgui*',
  '*mstsc*','*ssh*','*WinSCP*','*winscp*','*plink*','*telnet*',
  '*Realterm*','*TeraTerm*','*teraterm*','*Serial*','*SecureCRT*','*VanDyke*'
)
$procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
$rows = New-Object System.Collections.Generic.List[object]
foreach ($p in $procs) {
  if (-not $p.Name) { continue }
  $match = $false
  foreach ($pat in $patterns) {
    if ($p.Name -like $pat) { $match = $true; break }
  }
  if (-not $match) { continue }
  $owner = $null
  try {
    $ow = Invoke-CimMethod -InputObject $p -MethodName GetOwner -ErrorAction SilentlyContinue
    if ($ow -and $ow.ReturnValue -eq 0 -and $ow.Domain -and $ow.User) {
      $owner = "$($ow.Domain)\$($ow.User)"
    }
  } catch { }
  $cmd = $p.CommandLine
  if ($cmd -and $cmd.Length -gt 500) { $cmd = $cmd.Substring(0, 500) }
  $sid = $p.SessionId
  $rows.Add([pscustomobject]@{
    ProcessName = $p.Name
    ProcessId = [int]$p.ProcessId
    SessionId = $(if ($null -ne $sid) { [int]$sid } else { $null })
    Owner = $owner
    CommandLine = $cmd
  })
}
$pids = @($rows | ForEach-Object { $_.ProcessId } | Sort-Object -Unique)
$portHint = 22,23,2222,2323,3389,3390,3391,5900,5901,8080,8443,2345,502,503,2000,4000,9001
$listen = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
  Where-Object { $_.LocalPort -ne 0 -and ($portHint -contains $_.LocalPort -or $pids -contains $_.OwningProcess) } |
  Select-Object -First 100 LocalAddress, LocalPort, OwningProcess)
$portRows = New-Object System.Collections.Generic.List[object]
foreach ($L in $listen) {
  $pn = $null; $own = $null
  try { $pn = (Get-Process -Id $L.OwningProcess -ErrorAction SilentlyContinue).ProcessName } catch { }
  try {
    $pr = Get-CimInstance Win32_Process -Filter "ProcessId=$($L.OwningProcess)" -ErrorAction SilentlyContinue
    if ($pr) {
      $ow = Invoke-CimMethod -InputObject $pr -MethodName GetOwner -ErrorAction SilentlyContinue
      if ($ow -and $ow.ReturnValue -eq 0 -and $ow.Domain -and $ow.User) {
        $own = "$($ow.Domain)\$($ow.User)"
      }
    }
  } catch { }
  $portRows.Add([pscustomobject]@{
    LocalAddress = [string]$L.LocalAddress
    LocalPort = [int]$L.LocalPort
    OwningProcess = [int]$L.OwningProcess
    ProcessName = $pn
    Owner = $own
  })
}
[pscustomobject]@{ Apps = @($rows); ListeningPorts = @($portRows) }
"""


def collect_machine_details_payload(machine: Machine) -> dict[str, Any]:
    errors: list[str] = []
    sessions, err = run_probe(
        machine.hostname,
        """
        $sessions = query user 2>$null | Select-Object -Skip 1 | ForEach-Object {
          $line = $_.Trim(); if (-not $line) { return }
          $parts = ($line -replace '\\s{2,}', ',').Split(',')
          [pscustomobject]@{ userName=$parts[0]; sessionName=$parts[1]; id=$parts[2]; state=$parts[3] }
        }; $sessions
        """,
    )
    if err:
        errors.append(f"sessions: {err}")

    apps_bundle, err = run_probe(machine.hostname, _APPS_AND_PORTS_SCRIPT)
    apps_list: list[dict[str, Any]] = []
    listen_list: list[dict[str, Any]] = []
    if err:
        errors.append(f"apps_ports: {err}")
    elif isinstance(apps_bundle, dict):
        apps_list = normalize(apps_bundle.get("Apps"))
        listen_list = normalize(apps_bundle.get("ListeningPorts"))
    elif apps_bundle is not None:
        errors.append("apps_ports: unexpected probe shape")

    camera, err = run_probe(
        machine.hostname,
        """
        $cameraProcs = @('WindowsCamera.exe', 'python.exe', 'pythonw.exe')
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $cameraProcs -contains $_.Name } |
        ForEach-Object {
          $own = $null
          try {
            $ow = Invoke-CimMethod -InputObject $_ -MethodName GetOwner -ErrorAction SilentlyContinue
            if ($ow -and $ow.ReturnValue -eq 0 -and $ow.Domain -and $ow.User) {
              $own = "$($ow.Domain)\$($ow.User)"
            }
          } catch { }
          [pscustomobject]@{ ProcessName = $_.Name; ProcessId = [int]$_.ProcessId; Owner = $own; CommandLine = $_.CommandLine }
        }
        """,
    )
    if err:
        errors.append(f"camera: {err}")

    com_ports, err = run_probe(
        machine.hostname,
        "Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue | Select-Object DeviceID, Description, Status, PNPDeviceID",
    )
    if err:
        errors.append(f"comports: {err}")

    return {
        "active_sessions": normalize(sessions),
        "app_usage": {
            "tracked_processes": apps_list,
            "apps_with_users": apps_list,
        },
        "listening_ports": listen_list,
        "camera_usage": normalize(camera),
        "active_com_ports": normalize(com_ports),
        "raw_errors": errors,
    }


def save_snapshot(machine_name: str, payload: dict[str, Any]) -> str:
    collected_at = datetime.now(timezone.utc).isoformat()
    safe_payload = _to_json_safe(payload)
    if not isinstance(safe_payload, dict):
        safe_payload = {"data": safe_payload}
    with connect_db() as conn:
        conn.execute(
            """
            INSERT INTO machine_snapshots(machine_name, collected_at, payload_json)
            VALUES (?, ?, ?)
            ON CONFLICT(machine_name)
            DO UPDATE SET collected_at=excluded.collected_at, payload_json=excluded.payload_json
            """,
            (machine_name, collected_at, json.dumps(safe_payload)),
        )
    return collected_at


def get_cached_snapshot(machine_name: str) -> tuple[str | None, dict[str, Any] | None]:
    with connect_db() as conn:
        row = conn.execute(
            "SELECT collected_at, payload_json FROM machine_snapshots WHERE machine_name = ?",
            (machine_name,),
        ).fetchone()
    if row is None:
        return None, None
    raw = row["payload_json"]
    try:
        parsed = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        _logger.warning("Bad snapshot JSON for %s — ignoring cache.", machine_name)
        return None, None
    if not isinstance(parsed, dict):
        return None, None
    return row["collected_at"], _to_json_safe(parsed)


def snapshot_times_all() -> dict[str, str]:
    with connect_db() as conn:
        rows = conn.execute("SELECT machine_name, collected_at FROM machine_snapshots").fetchall()
    return {str(r["machine_name"]): str(r["collected_at"]) for r in rows}


def _poll_round() -> None:
    try:
        machines = load_machines()
    except FileNotFoundError as exc:
        _logger.warning("Poll skipped: %s", exc)
        return
    for machine in machines:
        try:
            payload = collect_machine_details_payload(machine)
            save_snapshot(machine.name, payload)
        except Exception:
            _logger.exception("Background probe failed for %s", machine.name)


async def _poll_loop() -> None:
    _logger.info(
        "Background polling every %.1f s (set MACHINE_DASHBOARD_POLL_SECONDS=0 to disable).",
        POLL_SECONDS,
    )
    while True:
        await asyncio.to_thread(_poll_round)
        await asyncio.sleep(POLL_SECONDS)


@app.get("/", response_class=HTMLResponse)
def index(request: Request) -> HTMLResponse:
    machines = load_machines()
    times = snapshot_times_all()
    rows = [
        {
            "machine": m.model_dump(),
            "lock_state": get_lock_state(m.name),
            "last_collected_at": times.get(m.name),
        }
        for m in machines
    ]
    tpl = templates.get_template("index.html")
    html = tpl.render(
        request=request,
        rows=rows,
        poll_enabled=POLL_ENABLED and POLL_SECONDS > 0,
        poll_seconds=POLL_SECONDS,
    )
    return HTMLResponse(content=html)


@app.get("/api/machines")
def list_machines():
    machines = load_machines()
    data = [
        {"machine": m.model_dump(mode="json"), "lock_state": get_lock_state(m.name)}
        for m in machines
    ]
    return _json_response(data)


@app.post("/api/machines/{machine_name}/lock")
def lock_machine(machine_name: str, body: LockRequest):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    if LOCK_SCRIPT:
        err = run_script(
            LOCK_SCRIPT.format(
                hostname=machine.hostname,
                machine_name=machine.name,
                lock_user=body.lock_user,
                reason=body.reason.replace('"', "'"),
            )
        )
        if err:
            raise HTTPException(status_code=500, detail=err)
    return _json_response(write_lock(machine_name, body.lock_user, body.reason, body.requested_by))


@app.post("/api/machines/{machine_name}/release")
def release_machine(machine_name: str, body: ReleaseRequest):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    if RELEASE_SCRIPT:
        err = run_script(
            RELEASE_SCRIPT.format(
                hostname=machine.hostname,
                machine_name=machine.name,
                reason=body.reason.replace('"', "'"),
            )
        )
        if err:
            raise HTTPException(status_code=500, detail=err)
    return _json_response(write_release(machine_name, body.reason, body.requested_by))


@app.get("/api/machines/{machine_name}/details")
def machine_details(machine_name: str, live: bool = Query(False, description="Force immediate probe (slower).")):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")

    if live:
        payload = collect_machine_details_payload(machine)
        collected_at = save_snapshot(machine.name, payload)
        source = "live"
    else:
        collected_at_cache, cached = get_cached_snapshot(machine_name)
        if cached is None:
            payload = collect_machine_details_payload(machine)
            collected_at = save_snapshot(machine.name, payload)
            source = "live_first"
        else:
            payload = cached
            collected_at = collected_at_cache
            source = "cache"

    body: dict[str, Any] = {
        "machine": machine.model_dump(mode="json"),
        "lock_state": get_lock_state(machine_name),
        **payload,
        "collected_at": collected_at,
        "source": source,
        "poll_interval_seconds": POLL_SECONDS if POLL_ENABLED and POLL_SECONDS > 0 else None,
    }
    return _json_response(body)


@app.get("/api/poll/status")
def poll_status():
    return _json_response(
        {
            "poll_enabled": POLL_ENABLED and POLL_SECONDS > 0,
            "poll_interval_seconds": POLL_SECONDS if POLL_ENABLED else None,
            "inventory_path": str(INVENTORY_PATH),
            "database_path": str(DB_PATH),
            "data_dir": str(DATA_DIR),
        }
    )


@app.get("/api/machines/{machine_name}/rdp-target")
def rdp_target(machine_name: str, acting_as: str | None = Query(None, description="Windows user connecting (must match lock when reserved).")):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    assert_rdp_allowed(machine_name, acting_as)
    host = machine.ip_address or machine.hostname
    port = int(machine.rdp_port)
    protocol_url = f"atc-rdp://{host}:{port}"
    mstsc_command = f"mstsc /v:{host}:{port}"
    return _json_response(
        {
            "machine_name": machine.name,
            "host": host,
            "port": port,
            "protocol_url": protocol_url,
            "mstsc_command": mstsc_command,
        }
    )


@app.get("/api/machines/{machine_name}/rdp", response_class=PlainTextResponse)
def rdp(machine_name: str, acting_as: str | None = Query(None)):
    machines = {m.name: m for m in load_machines()}
    machine = machines.get(machine_name)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    assert_rdp_allowed(machine_name, acting_as)
    host = machine.ip_address or machine.hostname
    buff = StringIO()
    buff.write("screen mode id:i:2\n")
    buff.write("use multimon:i:0\n")
    buff.write("desktopwidth:i:1920\n")
    buff.write("desktopheight:i:1080\n")
    buff.write("session bpp:i:32\n")
    buff.write(f"full address:s:{host}:{machine.rdp_port}\n")
    buff.write("prompt for credentials on client:i:1\n")
    return PlainTextResponse(
        content=buff.getvalue(),
        media_type="application/rdp",
        headers={"Content-Disposition": f'attachment; filename="{machine.name}.rdp"'},
    )

