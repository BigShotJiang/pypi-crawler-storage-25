# ATC Machine Dashboard

Browser-based Python tool to manage ATC lab machines from a server PC (Windows).

## Features

- Dashboard list of machines (ATC names, hostnames, IPs)
- Per machine actions: Lock, Release, Details, RDP
- Mandatory reason for Lock/Release
- Background polling of session/app/COM/network probes into SQLite
- Details shows cached snapshots; optional live refresh
- `.rdp` file generation for one-click Remote Desktop

## Install from PyPI

```powershell
pip install atc-machine-dashboard
```

Run (binds `0.0.0.0:8080` by default):

```powershell
atc-machine-dashboard
```

Or with options:

```powershell
atc-machine-dashboard --host 127.0.0.1 --port 8080
```

Or via module:

```powershell
python -m atc_machine_dashboard --port 8080
```

Open `http://<server-ip>:8080`.

### Data directory (production)

Config and the SQLite DB default to the **current working directory**:

- `machines.json` — inventory (auto-created from the bundled example on first run if missing)
- `machine_dashboard.db` — locks + probe cache

Override with:

| Variable | Purpose |
|----------|---------|
| `MACHINE_DASHBOARD_DATA_DIR` | Directory for `machines.json` and `machine_dashboard.db` (unless overridden below) |
| `MACHINE_DASHBOARD_INVENTORY` | Full path to `machines.json` |
| `MACHINE_DASHBOARD_DB` | Full path to SQLite file |

Example:

```powershell
$env:MACHINE_DASHBOARD_DATA_DIR = "E:\atc-dashboard-data"
cd $env:MACHINE_DASHBOARD_DATA_DIR
atc-machine-dashboard
```

## Development (from this repo)

```powershell
cd path\to\atc_machine_dashboard
pip install -e ".[dev]"
atc-machine-dashboard --reload --port 8080
```

## Environment variables

- `MACHINE_DASHBOARD_DATA_DIR` — base directory for inventory and DB (default: current directory)
- `MACHINE_DASHBOARD_INVENTORY` — path to `machines.json`
- `MACHINE_DASHBOARD_DB` — path to SQLite DB
- `MACHINE_DASHBOARD_LOCK_SCRIPT` / `MACHINE_DASHBOARD_RELEASE_SCRIPT` — optional PowerShell policy hooks
- `MACHINE_DASHBOARD_POLL_SECONDS` — background poll interval (default `60`; `0` disables the loop)
- `MACHINE_DASHBOARD_POLL_ENABLED` — `0` / `false` disables background polling
- `ATC_DASHBOARD_HOST` / `ATC_DASHBOARD_PORT` / `PORT` — defaults for the CLI server

## Publishing to PyPI (maintainers)

Create API tokens on [pypi.org](https://pypi.org/manage/account/token/) (and TestPyPI if you like). Then:

```powershell
pip install build twine
python -m build
python -m twine upload dist/*
```

Use TestPyPI first if you want a dry run:

```powershell
python -m twine upload --repository testpypi dist/*
pip install -i https://test.pypi.org/simple/ atc-machine-dashboard
```

Bump the version in `pyproject.toml` and `src/atc_machine_dashboard/__init__.py` before each release.
