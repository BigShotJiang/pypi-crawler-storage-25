# kalcend

Execute Kalcend tools from Python. Designed for use inside OpenAI shell containers.

## Install

```bash
pip install kalcend
```

## Usage

```python
from kalcend import run, run_df, download, upload

# Execute any tool
result = run("db_query", query="SELECT * FROM users", credential_id="cred_123")

# Get results as a DataFrame
df = run_df("db_query", query="SELECT * FROM orders", credential_id="cred_123")

# Download a file from the org store
download("file_abc", "/mnt/data/input.csv")

# Upload a file to the org store
upload("/mnt/data/chart.png", "Q1_Chart.png")
```

## Environment

- `KALCEND_TOKEN` — JWT token (auto-injected by OpenAI domain_secrets)
- `KALCEND_BASE_URL` — API base URL (default: `https://api.kalcend.com/agent-exec`)
