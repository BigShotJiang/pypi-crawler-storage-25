"""
Kalcend — Execute Kalcend tools from Python.

Usage in OpenAI shell:

    !pip install -q kalcend
    from kalcend import run, run_df, download, upload, list_files

    result = run("db_query", query="SELECT * FROM users", credential_id="cred_123")
    df = run_df("db_query", query="SELECT * FROM users", credential_id="cred_123")

    download("file_abc", "/mnt/data/input.csv")
    upload("/mnt/data/chart.png", "Q1_Chart.png")

Environment variables:
    KALCEND_TOKEN    — JWT token (injected by OpenAI domain_secrets sidecar)
    KALCEND_BASE_URL — API base URL (default: https://api.kalcend.com/agent-exec)
"""

import os
import json
import base64
import mimetypes
import urllib.request
import urllib.error

__version__ = "0.3.0"

_BASE = os.environ.get("KALCEND_BASE_URL", "https://api.kalcend.com/agent-exec")
_TOKEN = os.environ.get("KALCEND_TOKEN", "")
_TIMEOUT = 120


def _headers():
    return {
        "Authorization": f"Bearer {_TOKEN}",
        "Content-Type": "application/json",
    }


def run(tool_name, **params):
    """Execute any Kalcend tool by name. Returns result dict.

    Example:
        result = run("db_query", query="SELECT 1", credential_id="cred_123")
        print(result["rows"])
    """
    payload = {"action": "tool_exec", "tool": tool_name, "params": params}
    data = json.dumps(payload).encode()
    req = urllib.request.Request(_BASE, data=data, headers=_headers())
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Kalcend API error {e.code}: {body}") from None


def run_df(tool_name, **params):
    """Execute a tool and return the result as a pandas DataFrame.

    Expects the tool result to contain 'rows' and optionally 'columns'.
    Raises RuntimeError if the tool call fails.

    Example:
        df = run_df("db_query", query="SELECT * FROM orders", credential_id="cred_123")
        print(df.describe())
    """
    result = run(tool_name, **params)
    if not result.get("success", True):
        raise RuntimeError(result.get("error", f"{tool_name} failed"))
    import pandas as pd

    return pd.DataFrame(result.get("rows", []), columns=result.get("columns"))


def download(file_id, local_path):
    """Download a file from the org file store to a local path.

    Example:
        download("file_abc123", "/mnt/data/input.csv")
    """
    payload = {"action": "file_download", "fileId": file_id}
    data = json.dumps(payload).encode()
    req = urllib.request.Request(_BASE, data=data, headers=_headers())
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            with open(local_path, "wb") as f:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Kalcend download error {e.code}: {body}") from None
    return local_path


def upload(local_path, filename=None):
    """Upload a local file to the org file store. Returns { file_id, filename }.

    The file is base64-encoded and sent as JSON (no multipart needed).

    Example:
        result = upload("/mnt/data/chart.png", "Q1_Revenue_Chart.png")
        print(result["file_id"])
    """
    if filename is None:
        filename = os.path.basename(local_path)

    mime = mimetypes.guess_type(local_path)[0] or "application/octet-stream"

    with open(local_path, "rb") as f:
        file_data = f.read()

    payload = {
        "action": "file_upload",
        "filename": filename,
        "data": base64.b64encode(file_data).decode("ascii"),
        "mime_type": mime,
    }
    data = json.dumps(payload).encode()

    req = urllib.request.Request(_BASE, data=data, headers=_headers())
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Kalcend upload error {e.code}: {body}") from None


def list_files(query="", mime_type="", limit=20):
    """List files in the org file store. Returns list of file dicts.

    Each file has: file_id, filename, mime_type, file_size, status, created_at.

    Example:
        files = list_files()
        for f in files:
            print(f["file_id"], f["filename"])

        csvs = list_files(mime_type="text/csv")
    """
    result = run("list_files", query=query, mime_type=mime_type, limit=limit)
    return result.get("results", [])
