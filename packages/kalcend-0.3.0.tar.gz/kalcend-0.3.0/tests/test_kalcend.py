"""Unit tests for the kalcend package."""

import io
import json
import os
import tempfile
import unittest
from unittest.mock import patch, MagicMock
import urllib.error


class TestRun(unittest.TestCase):
    """Tests for kalcend.run()"""

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_run_success(self, mock_urlopen):
        # Re-import to pick up env vars
        import importlib
        import kalcend
        importlib.reload(kalcend)

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({"success": True, "rows": [{"id": 1}]}).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        result = kalcend.run("db_query", query="SELECT 1", credential_id="cred_123")

        self.assertEqual(result["success"], True)
        self.assertEqual(result["rows"], [{"id": 1}])

        # Verify request — single endpoint, action in body
        call_args = mock_urlopen.call_args
        req = call_args[0][0]
        self.assertEqual(req.full_url, "http://localhost:8080")
        self.assertEqual(req.get_header("Authorization"), "Bearer test-jwt")
        self.assertEqual(req.get_header("Content-type"), "application/json")

        body = json.loads(req.data)
        self.assertEqual(body["action"], "tool_exec")
        self.assertEqual(body["tool"], "db_query")
        self.assertEqual(body["params"]["query"], "SELECT 1")
        self.assertEqual(body["params"]["credential_id"], "cred_123")

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_run_http_error(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        error_body = json.dumps({"error": "unauthorized", "message": "Token expired"}).encode()
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="http://localhost:8080",
            code=401,
            msg="Unauthorized",
            hdrs=None,
            fp=io.BytesIO(error_body),
        )

        with self.assertRaises(RuntimeError) as ctx:
            kalcend.run("db_query", query="SELECT 1")
        self.assertIn("401", str(ctx.exception))

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_run_rate_limited(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        error_body = json.dumps({"error": "rate_limited", "retry_after": 60}).encode()
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="http://localhost:8080",
            code=429,
            msg="Too Many Requests",
            hdrs=None,
            fp=io.BytesIO(error_body),
        )

        with self.assertRaises(RuntimeError) as ctx:
            kalcend.run("db_query", query="SELECT 1")
        self.assertIn("429", str(ctx.exception))


class TestRunDf(unittest.TestCase):
    """Tests for kalcend.run_df()"""

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_run_df_success(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "success": True,
            "rows": [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}],
            "columns": ["id", "name"],
        }).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        df = kalcend.run_df("db_query", query="SELECT * FROM users")

        self.assertEqual(len(df), 2)
        self.assertListEqual(list(df.columns), ["id", "name"])
        self.assertEqual(df.iloc[0]["name"], "Alice")

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_run_df_tool_failure(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "success": False,
            "error": "relation \"users\" does not exist",
        }).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        with self.assertRaises(RuntimeError) as ctx:
            kalcend.run_df("db_query", query="SELECT * FROM users")
        self.assertIn("does not exist", str(ctx.exception))


class TestDownload(unittest.TestCase):
    """Tests for kalcend.download()"""

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_download_success(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        # Simulate chunked reading
        file_content = b"col1,col2\n1,hello\n2,world\n"
        mock_resp = MagicMock()
        mock_resp.read.side_effect = [file_content, b""]
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            result = kalcend.download("file_abc123", tmp_path)
            self.assertEqual(result, tmp_path)

            with open(tmp_path, "rb") as f:
                self.assertEqual(f.read(), file_content)

            # Verify request — POST with action body
            req = mock_urlopen.call_args[0][0]
            self.assertEqual(req.full_url, "http://localhost:8080")
            self.assertEqual(req.get_header("Authorization"), "Bearer test-jwt")

            body = json.loads(req.data)
            self.assertEqual(body["action"], "file_download")
            self.assertEqual(body["fileId"], "file_abc123")
        finally:
            os.unlink(tmp_path)


class TestUpload(unittest.TestCase):
    """Tests for kalcend.upload()"""

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_upload_success(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "success": True,
            "file_id": "file_new_123",
            "filename": "chart.png",
        }).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        # Create a temp file to upload
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp.write(b"\x89PNG\r\n\x1a\nfake-png-data")
            tmp_path = tmp.name

        try:
            result = kalcend.upload(tmp_path, "chart.png")

            self.assertEqual(result["file_id"], "file_new_123")
            self.assertEqual(result["filename"], "chart.png")

            # Verify request — single endpoint, action in body
            req = mock_urlopen.call_args[0][0]
            self.assertEqual(req.full_url, "http://localhost:8080")
            self.assertEqual(req.get_header("Content-type"), "application/json")

            body = json.loads(req.data)
            self.assertEqual(body["action"], "file_upload")
            self.assertEqual(body["filename"], "chart.png")
            self.assertEqual(body["mime_type"], "image/png")
            # Verify base64 data decodes correctly
            import base64
            decoded = base64.b64decode(body["data"])
            self.assertTrue(decoded.startswith(b"\x89PNG"))
        finally:
            os.unlink(tmp_path)

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_upload_infers_filename(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "success": True,
            "file_id": "file_xyz",
            "filename": "data.csv",
        }).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, prefix="data") as tmp:
            tmp.write(b"a,b\n1,2\n")
            tmp_path = tmp.name

        try:
            # Call without explicit filename — should infer from path
            result = kalcend.upload(tmp_path)

            body = json.loads(mock_urlopen.call_args[0][0].data)
            self.assertEqual(body["action"], "file_upload")
            # Filename should be the basename of the temp file
            self.assertTrue(body["filename"].endswith(".csv"))
        finally:
            os.unlink(tmp_path)


class TestListFiles(unittest.TestCase):
    """Tests for kalcend.list_files()"""

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_list_files_success(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "success": True,
            "results": [
                {"file_id": "f1", "filename": "data.csv", "mime_type": "text/csv", "file_size": 1024},
                {"file_id": "f2", "filename": "report.pdf", "mime_type": "application/pdf", "file_size": 2048},
            ],
            "totalCount": 2,
            "returned": 2,
        }).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        files = kalcend.list_files()

        self.assertEqual(len(files), 2)
        self.assertEqual(files[0]["file_id"], "f1")
        self.assertEqual(files[1]["filename"], "report.pdf")

        # Verify request body
        body = json.loads(mock_urlopen.call_args[0][0].data)
        self.assertEqual(body["action"], "tool_exec")
        self.assertEqual(body["tool"], "list_files")
        self.assertEqual(body["params"]["query"], "")
        self.assertEqual(body["params"]["mime_type"], "")
        self.assertEqual(body["params"]["limit"], 20)

    @patch.dict(os.environ, {"KALCEND_TOKEN": "test-jwt", "KALCEND_BASE_URL": "http://localhost:8080"})
    @patch("urllib.request.urlopen")
    def test_list_files_with_filter(self, mock_urlopen):
        import importlib
        import kalcend
        importlib.reload(kalcend)

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({
            "success": True,
            "results": [{"file_id": "f1", "filename": "data.csv", "mime_type": "text/csv", "file_size": 1024}],
            "totalCount": 1,
            "returned": 1,
        }).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        files = kalcend.list_files(mime_type="text/csv", limit=5)

        self.assertEqual(len(files), 1)

        body = json.loads(mock_urlopen.call_args[0][0].data)
        self.assertEqual(body["params"]["mime_type"], "text/csv")
        self.assertEqual(body["params"]["limit"], 5)


if __name__ == "__main__":
    unittest.main()
