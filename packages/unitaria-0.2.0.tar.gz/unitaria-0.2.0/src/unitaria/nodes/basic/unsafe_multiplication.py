from __future__ import annotations

from typing import Sequence

import numpy as np

from unitaria.circuit import Circuit
from unitaria.subspace import Subspace
from unitaria.nodes.node import Node


class UnsafeMul(Node):
    """
    Node for chaining the circuits of two nodes

    This is mostly for internal usage. To properly multiply two matrices, use
    `~unitaria.nodes.prox_node.Mul` instead. The order of operations is,
    like with matrix multiplication, from right to left, i.e. B is applied first.

    :param A:
        The left factor
    :param B:
        The right factor
    """

    A: Node
    B: Node

    def __init__(self, A: Node, B: Node):
        self.A = A
        self.B = B
        if not B.subspace_out.match_nonzero(A.subspace_in):
            raise ValueError(f"Non matching qubit maps {repr(A.subspace_out)} and {repr(B.subspace_in)}")

        super().__init__(B.dimension_in, A.dimension_out)

    def children(self) -> list[Node]:
        return [self.A, self.B]

    def compute(self, input: np.ndarray | None) -> np.ndarray:
        input = self.B.compute(input)
        input = self.A.compute(input)
        return input

    def compute_adjoint(self, input: np.ndarray | None) -> np.ndarray:
        input = self.A.compute_adjoint(input)
        input = self.B.compute_adjoint(input)
        return input

    def _circuit(
        self, target: Sequence[int], clean_ancillae: Sequence[int], borrowed_ancillae: Sequence[int]
    ) -> Circuit:
        circuit = Circuit()
        circuit += self.B.circuit(target, clean_ancillae, borrowed_ancillae)
        circuit += self.A.circuit(target, clean_ancillae, borrowed_ancillae)
        return circuit

    def _subspace_in(self) -> Subspace:
        max_qubits = max(self.B.subspace_in.total_qubits, self.A.subspace_out.total_qubits)
        return Subspace("0" * (max_qubits - self.B.subspace_in.total_qubits)) & self.B.subspace_in

    def _subspace_out(self) -> Subspace:
        max_qubits = max(self.B.subspace_in.total_qubits, self.A.subspace_out.total_qubits)
        return Subspace("0" * (max_qubits - self.A.subspace_out.total_qubits)) & self.A.subspace_out

    def _normalization(self) -> float:
        return self.A.normalization * self.B.normalization

    def clean_ancilla_count(self) -> int:
        return max(self.A.clean_ancilla_count(), self.B.clean_ancilla_count())

    def borrowed_ancilla_count(self) -> int:
        return max(self.A.borrowed_ancilla_count(), self.B.borrowed_ancilla_count())
