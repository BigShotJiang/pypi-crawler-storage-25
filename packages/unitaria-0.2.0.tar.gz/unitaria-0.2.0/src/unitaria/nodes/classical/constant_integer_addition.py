from typing import Sequence

import numpy as np

from unitaria.nodes.node import Node
from unitaria.nodes.classical.classical import Classical
from unitaria.subspace import Subspace
from unitaria.circuit import Circuit
from unitaria.circuits.arithmetic import const_addition_circuit


class ConstantIntegerAddition(Classical):
    """
    Node implementing the (wrapping) addition of a constant to an integer.

    :param bits:
        The size of the quantum state. The addition is performed modulo ``2 ** bits``.
    :param constant:
        The contant that should be added. Has to be positive.
    """

    bits: int
    constant: int

    def __init__(self, bits: int, constant: int):
        super().__init__(bits, bits)
        self.bits = bits
        self.constant = constant

    def children(self) -> list[Node]:
        return []

    def parameters(self) -> dict:
        return {"bits": self.bits, "constant": self.constant}

    def _subspace_in(self) -> Subspace:
        return Subspace("#" * self.bits)

    def _subspace_out(self) -> Subspace:
        return Subspace("#" * self.bits)

    def is_guaranteed_unitary(self) -> bool:
        return True

    def compute_classical(self, input: np.ndarray) -> np.ndarray:
        return (input + self.constant) % 2**self.bits

    def compute_reverse_classical(self, input: np.ndarray) -> np.ndarray:
        return (input - self.constant) % 2**self.bits

    def compute(self, input: np.ndarray) -> np.ndarray:
        return np.roll(input, self.constant, axis=-1)

    def compute_adjoint(self, input: np.ndarray) -> np.ndarray:
        return np.roll(input, -self.constant, axis=-1)

    def _circuit(
        self, target: Sequence[int], clean_ancillae: Sequence[int], borrowed_ancillae: Sequence[int]
    ) -> Circuit:
        circuit = const_addition_circuit(target, self.constant, borrowed_ancillae)
        return Circuit(circuit)

    def clean_ancilla_count(self) -> int:
        return 0

    def borrowed_ancilla_count(self) -> int:
        return 2
