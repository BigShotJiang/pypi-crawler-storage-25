from unitaria.nodes.node import Node
from unitaria.nodes.proxy_node import ProxyNode
from unitaria.nodes.basic.adjoint import Adjoint
from unitaria.nodes.qsvt.qsvt import QSVT
from unitaria.poly_approx import qcheb_poly, rescale_domain


class Pseudoinverse(ProxyNode):
    """
    This node implements the Moore-Penrose pseudoinverse of ``A`` with the
    given tolerance, if `condition` is the ratio between ``A.normalization`` and
    ``A`` s smallest singular value.

    Implements Theorem 41 from https://arxiv.org/abs/1806.01838

    :param A:
        The node to be inverted
    :param condition:
        An upper bound on the inverse of nonzero singular values of A. This is
        the same as the usual definition of the condition of a matrix iff the
        largest singular value is its normalization, i.e. if the block-encoding
        has optimal subnormalization.
    :param tolerance:
        The absolute error tolerance
    :param guaranteed:
        Determines if the accuracy should be guaranteed using analytical
        bounds (ignoring numerical errors). If this is set to false, this
        function will use a heuristic which will result in polynomials of
        lower degrees while usually still providing the requested precision.
    """

    # TODO: The condition should actually be the condition of the matrix,
    #   the dependence on the subnormalization should be hidden from the user.
    def __init__(self, A: Node, condition: float, tolerance: float, guaranteed: bool = False):
        super().__init__(A.dimension_out, A.dimension_in)
        assert condition >= 1
        self.A = A
        self.condition = condition
        self.tolerance = tolerance
        self.guaranteed = guaranteed

    def definition(self):
        poly = qcheb_poly(1 / self.condition, self.tolerance * self.A.normalization)

        # Rescale the polynomial, so that it fits the input normalization
        poly = rescale_domain(poly, self.A.normalization) / self.A.normalization
        return QSVT(Adjoint(self.A), poly)

    def children(self) -> list[Node]:
        return [self.A]

    def parameters(self) -> dict:
        return {"condition": self.condition, "tolerance": self.tolerance, "guaranteed": self.guaranteed}
