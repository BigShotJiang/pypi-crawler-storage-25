#!/usr/bin/env bash
# ============================================================================
# run_mapobs.sh — Wrapper for pikobs.mapobs (Live Monitor & Auto-Close)
# ============================================================================
set -euo pipefail

# === USER SETTINGS ==========================================================
PATHWORK="/home/dlo001/sites8/pikobsmapsobs2/"
PATH_EXPERIENCE="/home/dlo001/sites8/Data_pikobs/monitoring/"
EXPERIENCE_NAME="experiment"
DATESTART="2026020100"
DATEEND="2026020200"
FAMILY="to_amsua_allsky to_amsub_allsky sw sc ro ch" 
FLAGS_CRITERIA="all assimilee cloudy_sky clear_sky"
N_CPUS=40
# ============================================================================

# --- 1. AUTO-QSUB WITH LIVE MONITORING ---
if [[ -z "${PBS_JOBID:-}" ]]; then
    echo "🚀 Launching from login node. Auto-submitting to qsub..."
    LOG_FILE="mapobs_$(date +%Y%m%d_%H%M%S).log"
    
    JOB_ID=$(qsub -N PikobsMapobs -l nodes=1:ppn=${N_CPUS} -l walltime=02:00:00 -j oe -o "$LOG_FILE" "$0")
    
    echo "✅ Job submitted to PBS: $JOB_ID"
    echo "👀 Waiting for the node to start and stream output..."
    
    while [ ! -f "$LOG_FILE" ]; do sleep 2; done
    echo "-----------------------------------------------------------------"
    tail -f "$LOG_FILE" &
    TAIL_PID=$!
    
    while qstat "$JOB_ID" >/dev/null 2>&1; do sleep 5; done
    
    sleep 2
    kill $TAIL_PID 2>/dev/null || true
    echo "================================================================="
    echo "🏁 Job finished and closed. Output saved in: $LOG_FILE"
    exit 0
fi

# --- 2. HPC PROTECTION ---
export PYTHONNOUSERSITE=1
echo "================================================================="
echo "🖥️  Running on compute node: $(hostname) (JobID: $PBS_JOBID)"

# --- 3. LOAD ENVIRONMENT ---
set +eu
LOADER="/fs/homeu3/eccc/cmd/cmda/dlo001/pikobs_install/load_pikobs.sh"

if [[ ! -f "$LOADER" ]]; then
    echo "❌ Error: load_pikobs.sh not found at $LOADER"
    exit 1
fi

source "$LOADER"
set -eu

# Conectar la ruta de tu código fuente
export PYTHONPATH="/fs/homeu3/eccc/cmd/cmda/dlo001/python/Pikobs:$PYTHONPATH"

# --- 4. VERIFY VERSIONS ---
PY_VER=$(python -c "import platform; print(platform.python_version())" 2>/dev/null || echo "Unknown")
echo "🐍 Active Python version: $PY_VER"

PIKOBS_VER=$(python -c "import pikobs; print(getattr(pikobs, '__version__', 'Local Source'))" 2>/dev/null || echo "ERROR")
if [[ "$PIKOBS_VER" == "ERROR" ]]; then
    echo "❌ ERROR: pikobs cannot be imported. Check PYTHONPATH."
    exit 1
fi
echo "📦 Active Pikobs version: $PIKOBS_VER"
echo "================================================================="

# --- 5. EXECUTION ---
python -c "import pikobs; pikobs.mapobs.arg_call()" \
    --path_experience "${PATH_EXPERIENCE}" \
    --experience_name "${EXPERIENCE_NAME}" \
    --pathwork        "${PATHWORK}" \
    --datestart       "${DATESTART}" \
    --dateend         "${DATEEND}" \
    --family          ${FAMILY} \
    --flags_criteria  ${FLAGS_CRITERIA} \
    --n_cpus          "${N_CPUS}"

echo "✅ Process completed successfully."
