#!/usr/bin/env bash
# ==============================================================================
# setup_pikobs.sh — One-shot installer for Pikobs at CMC
# ------------------------------------------------------------------------------
# Run ONCE per user account. This script:
#
#   1. Configures the CMC web proxy (persistent + current session).
#   2. Loads the official mamba module.
#   3. Creates $PROJECT_DIR/env, a Conda environment built from the
#      pinned pikobs_env.yml fetched from GitLab.
#   4. Writes $PROJECT_DIR/load_pikobs.sh — the single helper that every
#      run_<module>.sh sources to activate the environment.
#
# Usage:
#   wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs/script/setup_pikobs.sh
#   chmod +x setup_pikobs.sh
#   ./setup_pikobs.sh                                # uses defaults
#   ./setup_pikobs.sh --project-dir /path/to/dir     # custom location
#   PROJECT_DIR=/path/to/dir ./setup_pikobs.sh       # same via env var
# ==============================================================================

set -euo pipefail

# === USER-CONFIGURABLE ========================================================
DEFAULT_PROJECT_DIR="${HOME}/pikobs_install"
ENV_NAME="pikobs_env"
PROXY_URL="http://webproxy.science.gc.ca:8888/"
PIKOBS_ENV_YML="https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs_env.yml"
MAMBA_MODULE_LOAD="r.load.dot crd/ccrp/ssm/mamba_2026.02.18_all"
# ==============================================================================

# --- Parse CLI flags ----------------------------------------------------------
PROJECT_DIR="${PROJECT_DIR:-$DEFAULT_PROJECT_DIR}"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --project-dir) PROJECT_DIR="$2"; shift 2 ;;
        -h|--help)
            sed -n '1,/^# ====/p' "$0" | sed 's/^# \?//'
            exit 0 ;;
        *) echo "Unknown argument: $1" >&2; exit 1 ;;
    esac
done

PROJECT_DIR="$(realpath -m "${PROJECT_DIR}")"
ENV_PATH="${PROJECT_DIR}/env"
CACHE_DIR="${PROJECT_DIR}/mamba_cache"
PROFILE_FILE="${HOME}/.profile.d/interactive/post"

echo "============================================================"
echo "  Pikobs setup"
echo "  PROJECT_DIR = ${PROJECT_DIR}"
echo "  ENV_PATH    = ${ENV_PATH}"
echo "============================================================"

# --- 1. Proxy: persist + load into current session ----------------------------
echo "🔍 Configuring CMC proxy..."
mkdir -p "$(dirname "${PROFILE_FILE}")"
touch "${PROFILE_FILE}"

_append_unique() {
    grep -qF "$1" "${PROFILE_FILE}" || echo "$1" >> "${PROFILE_FILE}"
}
_append_unique "export http_proxy=${PROXY_URL}"
_append_unique 'export HTTP_PROXY=$http_proxy'
_append_unique 'export https_proxy=$http_proxy'
_append_unique 'export HTTPS_PROXY=$http_proxy'

export http_proxy="${PROXY_URL}"
export HTTP_PROXY="${PROXY_URL}"
export https_proxy="${PROXY_URL}"
export HTTPS_PROXY="${PROXY_URL}"
echo "✅ Proxy ready (session + ${PROFILE_FILE})"

# --- 2. Load mamba module -----------------------------------------------------
echo "🧩 Loading mamba module..."
# r.load.dot is a CMC system script that references unset variables
# (e.g. USE_RECURSIVE_SHORTCUTS). Temporarily disable `set -u` so it
# does not abort us, then restore it.
set +u
# shellcheck disable=SC1091,SC2086
. ${MAMBA_MODULE_LOAD}
set -u

export CONDA_SUBDIR=linux-64
export CONDA_SAT_SOLVER_TIMEOUT=180
export CONDA_DOWNLOAD_THREADS=10

# --- 3. Workspace -------------------------------------------------------------
echo "📂 Preparing ${PROJECT_DIR}..."
mkdir -p "${PROJECT_DIR}" "${CACHE_DIR}"
cd "${PROJECT_DIR}"

# --- 4. Fetch the official env YAML ------------------------------------------
echo "📥 Fetching pikobs_env.yml..."
curl -fSL "${PIKOBS_ENV_YML}" -o "${PROJECT_DIR}/pikobs_env.yml"

# --- 5. Create / update the env ----------------------------------------------
export CONDA_PKGS_DIRS="${CACHE_DIR}"

# Silence the harmless Anaconda "commercial channel" warnings printed
# by libmamba on every call (we use conda-forge anyway).
export MAMBA_NO_BANNER=1
export CONDA_PLUGINS_AUTO_ACCEPT_TOS=yes

cat << 'BANNER'

──────────────────────────────────────────────────────────────
⏳  Building the conda environment...
    This usually takes 5 to 15 minutes the first time.
    Mamba is downloading and solving ~200 packages — relax,
    grab a coffee, this is the long step.
──────────────────────────────────────────────────────────────

BANNER

if [[ -d "${ENV_PATH}" ]]; then
    echo "♻️  Existing env detected at ${ENV_PATH}. Updating..."
    mamba env update -p "${ENV_PATH}" -f "${PROJECT_DIR}/pikobs_env.yml" --prune 2> >(
        grep -v -E "libmamba 'repo\.anaconda\.com'|libmamba Please make sure|libmamba See: https://legal\.anaconda" >&2
    )
else
    echo "🛠️  Building environment at ${ENV_PATH}..."
    mamba env create  -p "${ENV_PATH}" -f "${PROJECT_DIR}/pikobs_env.yml" 2> >(
        grep -v -E "libmamba 'repo\.anaconda\.com'|libmamba Please make sure|libmamba See: https://legal\.anaconda" >&2
    )
fi

# --- 5b. Verify pikobs is installed in the new env ---------------------------
echo ""
echo "🔎 Verifying pikobs inside ${ENV_PATH}..."

# Activate the env to query pikobs (relax `-u` while sourcing conda hooks).
set +u
# shellcheck disable=SC1091
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "${ENV_PATH}"
set -u

INSTALLED_VERSION=$(python -c "
import sys
try:
    import pikobs
except ImportError:
    sys.exit(1)
try:
    print(pikobs.__version__)
except AttributeError:
    try:
        from importlib.metadata import version
        print(version('pikobs'))
    except Exception:
        print('installed')
" 2>/dev/null || true)

if [[ -n "${INSTALLED_VERSION}" ]]; then
    echo "✅ pikobs ${INSTALLED_VERSION} is already installed in this env."
else
    cat << EOF

⚠️  pikobs itself is NOT yet installed in the new environment.
    (The YAML provides only the dependency stack: numpy, dask, cartopy, ...)

    Recommended: install the latest release from PyPI now into THIS env:
        pip install --upgrade pikobs

EOF
    # Interactive prompt — default Yes. Skip with --yes or PIKOBS_AUTO_INSTALL=1.
    if [[ "${PIKOBS_AUTO_INSTALL:-0}" == "1" ]]; then
        REPLY="y"
    else
        read -rp "    Install pikobs now? [Y/n] " REPLY
        REPLY="${REPLY:-Y}"
    fi

    if [[ "${REPLY}" =~ ^[Yy]$ ]]; then
        echo "📦 Installing pikobs into ${ENV_PATH}..."
        pip install --upgrade pikobs
        INSTALLED_VERSION=$(python -c "
import sys
try:
    import pikobs
except ImportError:
    sys.exit(1)
try:
    print(pikobs.__version__)
except AttributeError:
    try:
        from importlib.metadata import version
        print(version('pikobs'))
    except Exception:
        print('installed')
" 2>/dev/null || true)
        if [[ -n "${INSTALLED_VERSION}" ]]; then
            echo "✅ pikobs ${INSTALLED_VERSION} installed."
        else
            echo "❌ pip install reported success but 'import pikobs' still fails."
            echo "   Check the proxy and re-run: pip install --upgrade pikobs"
            exit 1
        fi
    else
        echo "⏭️  Skipped. Install later with:"
        echo "     conda activate ${ENV_PATH}"
        echo "     pip install --upgrade pikobs"
    fi
fi

# --- 6. Write the load helper -------------------------------------------------
LOAD_HELPER="${PROJECT_DIR}/load_pikobs.sh"
echo "📝 Writing ${LOAD_HELPER}..."

cat > "${LOAD_HELPER}" << 'EOF'
#!/usr/bin/env bash
# ============================================================================
# load_pikobs.sh — Activate the Pikobs runtime environment.
# Sourced by every run_<module>.sh script.
#
# Steps (idempotent — safe to source multiple times):
#   1. Ensure CMC proxy is set in the current shell.
#   2. Open an interactive PBS session if we are not inside one yet.
#   3. Load the mamba module.
#   4. Activate the conda env at $PIKOBS_ENV_PATH.
#   5. Verify pikobs imports cleanly.
# ============================================================================

# --- Resolve project layout from THIS file's location ----------------------
PIKOBS_PROJECT_DIR="${PIKOBS_PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PIKOBS_ENV_PATH="${PIKOBS_ENV_PATH:-${PIKOBS_PROJECT_DIR}/env}"

echo "[pikobs] PROJECT_DIR = ${PIKOBS_PROJECT_DIR}"
echo "[pikobs] ENV_PATH    = ${PIKOBS_ENV_PATH}"

if [[ ! -d "${PIKOBS_ENV_PATH}" ]]; then
    echo "[pikobs] ERROR env directory does not exist: ${PIKOBS_ENV_PATH}" >&2
    echo "         Did you run setup_pikobs.sh? Or set PIKOBS_PROJECT_DIR." >&2
    return 1 2>/dev/null || exit 1
fi

# --- 1. Proxy --------------------------------------------------------------
if [[ -z "${http_proxy:-}" ]]; then
    export http_proxy=http://webproxy.science.gc.ca:8888/
    export HTTP_PROXY=${http_proxy}
    export https_proxy=${http_proxy}
    export HTTPS_PROXY=${http_proxy}
fi

# --- 2. Interactive PBS session --------------------------------------------
if [[ -z "${PBS_JOBID:-}" ]]; then
    echo "[pikobs] No PBS job detected — opening interactive session..."
    qsub -I -X \
         -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb \
         -l place=scatter \
         -l walltime=6:0:0
    echo "[pikobs] Re-run your run_<module>.sh inside the interactive shell."
    return 0 2>/dev/null || exit 0
fi
echo "[pikobs] Inside PBS job ${PBS_JOBID}"

# --- 3. Load mamba module --------------------------------------------------
echo "[pikobs] Loading mamba module..."
_pikobs_had_u=0
case $- in *u*) _pikobs_had_u=1; set +u ;; esac
# shellcheck disable=SC1091
. r.load.dot crd/ccrp/ssm/mamba_2026.02.18_all
[[ "${_pikobs_had_u}" == "1" ]] && set -u
unset _pikobs_had_u

# --- 4. Activate the environment -------------------------------------------
if [[ "${CONDA_PREFIX:-}" != "${PIKOBS_ENV_PATH}" ]]; then
    echo "[pikobs] Activating env: ${PIKOBS_ENV_PATH}"
    _pikobs_had_u=0
    case $- in *u*) _pikobs_had_u=1; set +u ;; esac
    # shellcheck disable=SC1091
    source "$(conda info --base)/etc/profile.d/conda.sh"
    if ! conda activate "${PIKOBS_ENV_PATH}"; then
        echo "[pikobs] ERROR conda activate failed for ${PIKOBS_ENV_PATH}" >&2
        return 1 2>/dev/null || exit 1
    fi
    [[ "${_pikobs_had_u}" == "1" ]] && set -u
    unset _pikobs_had_u
else
    echo "[pikobs] Env already active: ${CONDA_PREFIX}"
fi

# --- 5. Version check ------------------------------------------------------
_installed=$(python -c "
import sys
try:
    import pikobs
except ImportError:
    sys.exit(1)
try:
    print(pikobs.__version__)
except AttributeError:
    try:
        from importlib.metadata import version
        print(version('pikobs'))
    except Exception:
        print('installed')
" 2>/dev/null)
if [[ -z "${_installed}" ]]; then
    echo "[pikobs] ERROR pikobs is not installed in '${PIKOBS_ENV_PATH}'." >&2
    echo "         Activate the env manually and run: pip install --upgrade pikobs" >&2
    return 1 2>/dev/null || exit 1
fi
echo "[pikobs] ✅ Env ready — pikobs ${_installed}"
EOF

chmod +x "${LOAD_HELPER}"

# --- 7. Final summary ---------------------------------------------------------
cat << EOF

============================================================
✅ Pikobs setup complete.

  Project dir : ${PROJECT_DIR}
  Env path    : ${ENV_PATH}
  Loader      : ${LOAD_HELPER}
  Pikobs ver. : ${INSTALLED_VERSION:-<not installed>}

Next step — to run any pikobs module:

  wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs/script/run_mapobs.sh
  chmod +x run_mapobs.sh
  ./run_mapobs.sh

Each run_<module>.sh sources load_pikobs.sh automatically.
============================================================
EOF
