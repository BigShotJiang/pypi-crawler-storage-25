=========================================================
Pikobs: CMC Observational Data Processing Toolkit
=========================================================

.. image:: https://img.shields.io/badge/python-3.10+-blue.svg
   :target: https://www.python.org/downloads/
   :alt: Python Version

.. image:: https://img.shields.io/badge/docs-Sphinx-green.svg
   :target: https://www.sphinx-doc.org/
   :alt: Built with Sphinx

Welcome to the **Pikobs** documentation. Pikobs is a Python toolkit
for the extraction, processing and visualization of **CMC (Canadian
Meteorological Centre)** observational data. It bundles a coherent set
of modules to analyze, statistically monitor and quality-control both
conventional and satellite meteorological observations.

---

Overview
--------

Pikobs bridges raw assimilation-cycle files and data-driven
decision-making. The core workflow lets researchers and meteorologists:

* **Extract** data from the CMC assimilation-cycle outputs
  (monitoring/banco) used by the ``psmon`` system, including
  `RDB files <https://wiki.cmc.ec.gc.ca/wiki/Tables_Relationnelles_pour_les_observations>`_
  from ``evalalt``, ``bgckalt`` and ``postalt``.
* **Filter** observations with precise bitmask criteria — see
  :doc:`assimilation flags <flags_criteria>` and
  :doc:`geographical regions <region>`.
* **Compute** statistical metrics including O-B (omp), O-A (oma),
  observation density and bias corrections.
* **Visualize** results with metric-specific renderers — see
  :doc:`Scatter Plots <scatter>`, :doc:`Geographical Maps <mapobs>`,
  :doc:`Histograms <histogram>`, and more.

---

Installation
------------

Pikobs installs in **two steps**: a one-time bootstrap script, then
a per-module wrapper for daily use. Both scripts are short, idempotent,
and live in the ``pikobs/script/`` folder of the repository.

Step 1 — One-time install
~~~~~~~~~~~~~~~~~~~~~~~~

Download and run ``setup_pikobs.sh``. It configures the CMC proxy,
loads the official mamba module, fetches the pinned ``pikobs_env.yml``
from GitLab, and creates the Conda environment under
``$PROJECT_DIR/env``:

.. code-block:: bash

   wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/setup_pikobs.sh
   chmod +x setup_pikobs.sh

   # Default install location: $HOME/pikobs_install
   ./setup_pikobs.sh

   # Or pick your own location:
   ./setup_pikobs.sh --project-dir /home/your_user/my_pikobs

What the script does, in order:

#. **Proxy.** Exports ``http_proxy``/``https_proxy`` for the current
   shell and persists them in ``~/.profile.d/interactive/post`` so
   future logins inherit them.
#. **Mamba.** Loads
   ``r.load.dot crd/ccrp/ssm/mamba_2026.02.18_all``.
#. **Workspace.** Creates ``$PROJECT_DIR`` and a local package cache
   ``$PROJECT_DIR/mamba_cache``.
#. **Environment.** Fetches
   ``https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs_env.yml``
   and creates ``$PROJECT_DIR/env`` from it (or updates it if it
   already exists, idempotent).
#. **Loader helper.** Writes ``$PROJECT_DIR/load_pikobs.sh`` — the
   single helper that every per-module wrapper will source on every
   run.

When ``setup_pikobs.sh`` finishes you will see:

.. code-block:: text

   ✅ Pikobs setup complete.

     Project dir : /home/your_user/pikobs_install
     Env path    : /home/your_user/pikobs_install/env
     Loader      : /home/your_user/pikobs_install/load_pikobs.sh

.. note::
   This step is needed **only once per user account**. You do **not**
   need to re-run ``setup_pikobs.sh`` before every module run.

Step 2 — Run a module
~~~~~~~~~~~~~~~~~~~~

Each Pikobs module ships its own ``run_<module>.sh`` wrapper in
``pikobs/script/``. Pick the wrapper you need, download it, edit the
``USER SETTINGS`` block at the top, and launch it:

.. code-block:: bash

   # Example: mapobs (geographic coverage dashboards)
   wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs/script/run_mapobs.sh
   chmod +x run_mapobs.sh

   # 1. Edit the USER SETTINGS block at the top of run_mapobs.sh
   #    (PATHWORK, PATH_EXPERIENCE, DATESTART, DATEEND, FAMILY, ...)
   $EDITOR run_mapobs.sh

   # 2. Run it
   ./run_mapobs.sh

Internally, the wrapper sources ``$PIKOBS_PROJECT_DIR/load_pikobs.sh``
which:

#. **Verifies the proxy** is set in the current shell.
#. **Opens an interactive PBS session** if you are not already inside
   one (``qsub -I -X`` with the standard CMC HPC allocation:
   ``select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb``,
   walltime 6 h).
#. **Loads mamba** and **activates** the conda environment at
   ``$PROJECT_DIR/env``.
#. **Verifies** that ``pikobs`` imports cleanly and prints its version.
#. **Runs the module** with the parameters you configured.

The loader is **idempotent**: if you are already inside a PBS session
with the environment active, sourcing it again is a no-op.

Finding ``load_pikobs.sh``
~~~~~~~~~~~~~~~~~~~~~~~~~

By default each ``run_<module>.sh`` looks for ``load_pikobs.sh`` in:

#. ``$PIKOBS_PROJECT_DIR`` (set by you if you installed elsewhere),
#. ``$HOME/pikobs_install`` (the default location of
   ``setup_pikobs.sh``),
#. the same directory as the wrapper itself.

If your install lives somewhere non-standard, export the variable
before running the wrapper:

.. code-block:: bash

   export PIKOBS_PROJECT_DIR=/home/your_user/my_pikobs
   ./run_mapobs.sh

Available wrappers
~~~~~~~~~~~~~~~~~

Every module documented under :ref:`Core Modules <core-modules>`
ships with its matching wrapper. The naming convention is fixed:

.. code-block:: text

   https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs/script/run_<module>.sh

For example: ``run_mapobs.sh``, ``run_scatter.sh``,
``run_timeserie.sh``, ``run_profile_ft2.sh``, ``run_obscountdb.sh``, …

Verifying the installation
~~~~~~~~~~~~~~~~~~~~~~~~~

After ``setup_pikobs.sh`` finishes, you can confirm everything is
wired correctly with:

.. code-block:: bash

   source $HOME/pikobs_install/load_pikobs.sh
   python -c "import pikobs; print('OK', pikobs.__version__)"

Expected output:

.. code-block:: text

   [pikobs] Env ready — pikobs 3.0.75 (at /home/your_user/pikobs_install/env)
   OK 3.0.75

Updating
~~~~~~~

To pull the latest pinned environment from GitLab and update your
existing install, simply re-run ``setup_pikobs.sh``. It detects the
existing environment and runs ``mamba env update --prune`` instead of
recreating it.

---

.. _core-modules:

Core Modules Overview
---------------------

Each module is engineered with distinct characteristics and
specialized parameters. Explore the individual pages for detailed
usage:

* :doc:`scatter`: Generate 2-D geographical scatter plots of metrics.
* :doc:`timeserie`: Analyze the temporal evolution of statistics.
* :doc:`cardio`: Monitor system health and assimilation flow.
* :doc:`vdedr`: Vertical profiles and specific observational metrics.
* :doc:`zone`: Statistical aggregations across regional zones.
* :doc:`flag`: Quality-Control deep dive on rejection / assimilation
  flags.
* :doc:`mapobs`: Detailed geographical maps of observation locations.
* :doc:`histogram`: Statistical distributions and frequencies.
* :doc:`profile`: Vertical distribution of metrics across pressure
  levels or channels.
* :doc:`profile_ft`: Bias and standard deviation across pressure
  levels or channels.
* :doc:`profile_ft2`: Pairwise comparisons between experiments with
  F-test significance, observation-count change metrics and automated
  SQLite aggregation.
* :doc:`spatial`: Multi-dimensional correlation of observational
  statistics.
* :doc:`obscountdb`: Compare observation volumes between two cycles.

Utility
-------

* :doc:`pikobsburp2rdb`: Convert raw BURP/BUFR data into standard RDB
  structures.

Documentation Index
-------------------

.. toctree::
   :maxdepth: 2
   :caption: 🛠️ Core Modules

   scatter
   timeserie
   cardio
   vdedr
   zone
   flag
   mapobs
   histogram
   profile
   profile_ft
   profile_ft2
   spatial
   obscountdb

.. toctree::
   :maxdepth: 2
   :caption: 🔧 Utility

   pikobsburp2rdb

.. toctree::
   :maxdepth: 2
   :caption: ⚙️ Configuration

   region
   projection
   flags_criteria
   families
   varno

.. toctree::
   :maxdepth: 2
   :caption: 🧪 Development

   unittest

---

Resources & Contact
-------------------

* **Repository:**
  `Pikobs on GitLab <https://gitlab.science.gc.ca/dlo001/Pikobs>`_
* **Issues / bug reports:**
  `<https://gitlab.science.gc.ca/dlo001/Pikobs/-/issues>`_
* **RDB Data Reference:**
  `RDB Files Documentation (Wiki) <https://wiki.cmc.ec.gc.ca/wiki/Tables_Relationnelles_pour_les_observations>`_
