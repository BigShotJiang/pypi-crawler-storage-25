"""Lark Deck for Cog"""
__version__ = "1.0.0"
