"""
quantglide-ibkr CLI entry point.

First-time setup:
    quantglide-ibkr --token <token_from_dashboard>

Subsequent runs:
    quantglide-ibkr
    quantglide-ibkr --port 4002   # switch to paper trading
    quantglide-ibkr --dry-run     # test without placing orders
"""
import argparse
import sys
from pathlib import Path

CONFIG_DIR = Path.home() / ".quantglide"
CONFIG_FILE = CONFIG_DIR / ".env"


def _read_config() -> dict:
    from dotenv import dotenv_values
    return dotenv_values(str(CONFIG_FILE))


def _write_config(data: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = []
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            lines = f.readlines()
    for key, value in data.items():
        found = False
        for i, line in enumerate(lines):
            if line.startswith(f"{key}="):
                lines[i] = f"{key}={value}\n"
                found = True
                break
        if not found:
            lines.append(f"{key}={value}\n")
    with open(CONFIG_FILE, "w") as f:
        f.writelines(lines)


def main():
    parser = argparse.ArgumentParser(
        prog="quantglide-ibkr",
        description="QuantGlide IBKR relay agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  First-time setup:
    quantglide-ibkr --token <paste_token_from_dashboard>

  Start the agent:
    quantglide-ibkr

  Paper trading:
    quantglide-ibkr --port 4002

  Test without placing real orders:
    quantglide-ibkr --dry-run
        """,
    )
    parser.add_argument("--token", metavar="TOKEN",
                        help="Setup token from the QuantGlide dashboard (first-time only)")
    parser.add_argument("--port", type=int, choices=[4001, 4002],
                        help="IB Gateway port: 4001=live (default), 4002=paper")
    parser.add_argument("--no-time-gate", action="store_true",
                        help="Skip trading hours check (useful for testing)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Claim signals but don't place real orders")
    args = parser.parse_args()

    # ── First-time setup: just save the token UUID ────────────────────────────
    if args.token:
        _write_config({
            "QUANTGLIDE_TOKEN": args.token.strip(),
            "IBKR_HOST":        "127.0.0.1",
            "IBKR_PORT":        str(args.port or 4001),
            "IBKR_CLIENT_ID":   "10",
        })
        print(f"Setup complete. Config saved to {CONFIG_FILE}")
        print()
        print("Make sure IB Gateway is running, then start the agent:")
        print("    quantglide-ibkr")
        return

    # ── Config must exist ─────────────────────────────────────────────────────
    if not CONFIG_FILE.exists():
        print("No config found. Run setup first:")
        print()
        print("    quantglide-ibkr --token <paste_token_from_dashboard>")
        print()
        print("Get your token from the QuantGlide dashboard under Settings → IBKR.")
        sys.exit(1)

    # ── Apply port override ───────────────────────────────────────────────────
    if args.port:
        _write_config({"IBKR_PORT": str(args.port)})
        print(f"Port set to {args.port} ({'paper' if args.port == 4002 else 'live'} trading)")

    # ── Launch agent ──────────────────────────────────────────────────────────
    from quantglide_ibkr.agent import run
    run(
        env_path=str(CONFIG_FILE),
        no_time_gate=args.no_time_gate,
        dry_run=args.dry_run,
    )
