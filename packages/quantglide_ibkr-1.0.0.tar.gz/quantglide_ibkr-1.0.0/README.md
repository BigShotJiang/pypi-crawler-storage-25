# quantglide-ibkr

QuantGlide IBKR relay agent. Polls for trade signals from QuantGlide and places orders via IB Gateway.

## Requirements

- Python 3.9+
- IB Gateway running locally ([download](https://www.interactivebrokers.com/en/trading/ibgateway-stable.php))

## Install

```bash
pip install quantglide-ibkr
```

## Setup (one time)

1. Go to the QuantGlide dashboard → Settings → IBKR
2. Copy your setup token
3. Run:

```bash
quantglide-ibkr --token <paste_token_here>
```

## Run

```bash
quantglide-ibkr
```

For paper trading (IB Gateway on port 4002):

```bash
quantglide-ibkr --port 4002
```

Test without placing real orders:

```bash
quantglide-ibkr --dry-run
```

## How it works

The agent connects to IB Gateway on your machine and polls QuantGlide for trade signals. When a signal arrives, it places the order via IB Gateway. Keep the agent running during trading hours (10:25–13:00 ET).

Config is stored in `~/.quantglide/.env`. Refresh tokens are automatically rotated.
