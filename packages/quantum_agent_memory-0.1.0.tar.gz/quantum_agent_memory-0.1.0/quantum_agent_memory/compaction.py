"""
Layer 2 — QAOA Compaction

Select the optimal K memories to KEEP from M total.
Each qubit represents one memory: |1⟩ = keep, |0⟩ = archive.

Cost function combines:
  - Individual value (length, diversity, metadata)  25%
  - Recency                                         20%
  - Coverage diversity (low overlap = better)        30%
  - Coherence (related memories reinforce)           25%

A quadratic budget penalty forces exactly K selections.

Copyright 2026 Coinkong (Chef's Attraction). MIT License.
"""

import time
import random
from itertools import combinations
from datetime import datetime, timezone

import numpy as np
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator

__all__ = ["run_compaction"]

# Weights
W_VALUE = 0.25
W_RECENCY = 0.20
W_COVERAGE = 0.30
W_COHERENCE = 0.25
PENALTY_WEIGHT = 5.0


# ── scoring helpers ──────────────────────────────────────────────

def _tokenize(text):
    return set(text.lower().split())


def _word_overlap(t1, t2):
    s1, s2 = _tokenize(t1), _tokenize(t2)
    if not s1 or not s2:
        return 0.0
    return len(s1 & s2) / len(s1 | s2)


def _individual_value(mem):
    text = mem.get("memory", "")
    length_score = min(len(text) / 200.0, 1.0)
    words = text.lower().split()
    diversity = len(set(words)) / len(words) if words else 0.0
    meta_bonus = 0.1 if mem.get("metadata") else 0.0
    return min(0.4 * length_score + 0.5 * diversity + 0.1 * meta_bonus, 1.0)


def _recency_score(mem, now_ts, min_ts, max_ts):
    try:
        ts = datetime.fromisoformat(
            mem.get("created_at", "").replace("Z", "+00:00")
        ).timestamp()
    except (ValueError, AttributeError):
        ts = min_ts
    if max_ts == min_ts:
        return 0.5
    return (ts - min_ts) / (max_ts - min_ts)


def _build_cost_matrices(memories):
    M = len(memories)
    now_ts = datetime.now(timezone.utc).timestamp()
    timestamps = []
    for mem in memories:
        try:
            ts = datetime.fromisoformat(
                mem.get("created_at", "").replace("Z", "+00:00")
            ).timestamp()
        except (ValueError, AttributeError):
            ts = now_ts
        timestamps.append(ts)

    min_ts = min(timestamps) if timestamps else now_ts
    max_ts = max(timestamps) if timestamps else now_ts

    individual = np.zeros(M)
    for i in range(M):
        val = _individual_value(memories[i])
        rec = _recency_score(memories[i], now_ts, min_ts, max_ts)
        individual[i] = W_VALUE * val + W_RECENCY * rec

    pairwise = np.zeros((M, M))
    for i in range(M):
        for j in range(i + 1, M):
            overlap = _word_overlap(memories[i].get("memory", ""), memories[j].get("memory", ""))
            cov = 1.0 - overlap
            coh = np.exp(-((overlap - 0.3) ** 2) / 0.1)
            score = W_COVERAGE * cov + W_COHERENCE * coh
            pairwise[i][j] = pairwise[j][i] = score

    return individual, pairwise


def _evaluate_selection(selection, individual, pairwise):
    score = sum(individual[i] for i in selection)
    for a in range(len(selection)):
        for b in range(a + 1, len(selection)):
            score += pairwise[selection[a]][selection[b]]
    return score


# ── QAOA circuit ──────────────────────────────────────────────────

def _build_qaoa_circuit(gamma, beta, individual, pairwise, M, K):
    qc = QuantumCircuit(M)
    for i in range(M):
        qc.h(i)

    # individual terms
    for i in range(M):
        qc.rz(gamma * individual[i], i)

    # pairwise terms
    for i in range(M):
        for j in range(i + 1, M):
            if abs(pairwise[i][j]) > 1e-10:
                qc.cx(i, j)
                qc.rz(gamma * pairwise[i][j] / 2, j)
                qc.cx(i, j)

    # budget penalty — linear
    pen_linear = PENALTY_WEIGHT * (1 - 2 * K)
    for i in range(M):
        qc.rz(-gamma * pen_linear / 2, i)

    # budget penalty — quadratic
    pen_quad = PENALTY_WEIGHT * 2
    for i in range(M):
        for j in range(i + 1, M):
            qc.cx(i, j)
            qc.rz(-gamma * pen_quad / 2, j)
            qc.cx(i, j)

    for i in range(M):
        qc.rx(2 * beta, i)

    qc.measure_all()
    return qc


def _run_qaoa(individual, pairwise, M, K, grid_size=10, shots=1024):
    sim = AerSimulator()
    gamma_range = np.linspace(0.1, np.pi, grid_size)
    beta_range = np.linspace(0.1, np.pi / 2, grid_size)

    best_score = -np.inf
    best_selection = None

    t0 = time.time()
    for gamma in gamma_range:
        for beta in beta_range:
            qc = _build_qaoa_circuit(gamma, beta, individual, pairwise, M, K)
            result = sim.run(qc, shots=shots).result()
            counts = result.get_counts()

            for bitstring, count in counts.items():
                bits = bitstring.replace(" ", "")[::-1]
                selection = [i for i, b in enumerate(bits) if b == "1"]
                if len(selection) != K:
                    continue
                score = _evaluate_selection(selection, individual, pairwise)
                if score > best_score:
                    best_score = score
                    best_selection = sorted(selection)

    elapsed = time.time() - t0

    if best_selection is None:
        best_selection = sorted(range(K))
        best_score = _evaluate_selection(best_selection, individual, pairwise)

    return {"selection": best_selection, "score": float(best_score), "time": elapsed}


# ── classical baselines ──────────────────────────────────────────

def _brute_force(individual, pairwise, M, K):
    t0 = time.time()
    best_score, best_sel = -np.inf, None
    for combo in combinations(range(M), K):
        score = _evaluate_selection(list(combo), individual, pairwise)
        if score > best_score:
            best_score = score
            best_sel = list(combo)
    return {"selection": best_sel, "score": float(best_score), "time": time.time() - t0}


def _greedy(individual, pairwise, M, K):
    t0 = time.time()
    selected = []
    for _ in range(K):
        best_idx, best_gain = -1, -np.inf
        for i in range(M):
            if i in selected:
                continue
            gain = individual[i] + sum(pairwise[i][j] for j in selected)
            if gain > best_gain:
                best_gain = gain
                best_idx = i
        selected.append(best_idx)
    score = _evaluate_selection(sorted(selected), individual, pairwise)
    return {"selection": sorted(selected), "score": float(score), "time": time.time() - t0}


# ── public entry point ───────────────────────────────────────────

def run_compaction(memories, K, grid_size=10, shots=1024):
    """
    Run QAOA compaction + classical baselines.

    Args:
        memories: list of memory dicts
        K: number of memories to keep
        grid_size: QAOA parameter grid resolution
        shots: simulator shots per circuit

    Returns dict with quantum, classical, greedy results.
    """
    M = len(memories)
    individual, pairwise = _build_cost_matrices(memories)

    quantum = _run_qaoa(individual, pairwise, M, K, grid_size, shots)
    classical = _brute_force(individual, pairwise, M, K)
    greedy = _greedy(individual, pairwise, M, K)

    opt = classical["score"]
    q_pct = (quantum["score"] / opt * 100) if opt > 0 else 0.0
    overlap = len(set(quantum["selection"]) & set(classical["selection"]))

    return {
        "M": M,
        "K": K,
        "quantum": quantum,
        "classical": classical,
        "greedy": greedy,
        "quantum_vs_optimal_pct": float(q_pct),
        "overlap_with_optimal": overlap,
    }
