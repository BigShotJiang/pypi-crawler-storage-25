"""
Layer 1 — QAOA Clustering

Balanced graph-cut formulation using QAOA to partition agent memories
into two semantically coherent clusters.

Hamiltonian:
  H = -sum_{i<j} w_ij Z_i Z_j  +  λ (sum_i Z_i)²
  First term: cluster memories with high pairwise cost together.
  Second term: penalise lopsided partitions (balance constraint).

Copyright 2026 Coinkong (Chef's Attraction). MIT License.
"""

import time
from itertools import product as iter_product

import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import SparsePauliOp
from qiskit_aer import AerSimulator

from .cost_function import build_combined_cost_matrix

__all__ = ["run_clustering"]

BALANCE_LAMBDA = 0.15


# ── cost evaluation ───────────────────────────────────────────────

def evaluate_cost(bitstring, cost_matrix, balance_lambda=BALANCE_LAMBDA):
    """Balanced clustering cost: intra-cluster similarity − balance penalty."""
    n = len(bitstring)
    intra = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            if bitstring[i] == bitstring[j]:
                intra += cost_matrix[i][j]
    c0 = sum(1 for b in bitstring if b == 0)
    c1 = n - c0
    penalty = balance_lambda * ((c0 - c1) ** 2)
    return intra - penalty


# ── Hamiltonian ───────────────────────────────────────────────────

def _cost_hamiltonian(cost_matrix, balance_lambda=BALANCE_LAMBDA):
    n = cost_matrix.shape[0]
    terms = []

    # ZZ clustering terms
    for i in range(n):
        for j in range(i + 1, n):
            w = cost_matrix[i][j]
            if abs(w) < 1e-10:
                continue
            label = ["I"] * n
            label[i] = "Z"
            label[j] = "Z"
            terms.append(("".join(reversed(label)), -w))

    # Balance penalty ZZ terms
    for i in range(n):
        for j in range(i + 1, n):
            label = ["I"] * n
            label[i] = "Z"
            label[j] = "Z"
            pauli = "".join(reversed(label))
            terms.append((pauli, balance_lambda))

    merged = {}
    for ps, coeff in terms:
        merged[ps] = merged.get(ps, 0.0) + coeff

    pauli_list = [(ps, c) for ps, c in merged.items() if abs(c) > 1e-12]
    if not pauli_list:
        pauli_list = [("I" * n, 0.0)]

    return SparsePauliOp.from_list(pauli_list)


# ── QAOA circuit ──────────────────────────────────────────────────

def _build_qaoa_circuit(hamiltonian, n_qubits, gamma, beta):
    qc = QuantumCircuit(n_qubits)
    for i in range(n_qubits):
        qc.h(i)

    for pauli_str, coeff in hamiltonian.to_list():
        z_pos = [i for i, c in enumerate(reversed(pauli_str)) if c == "Z"]
        if len(z_pos) == 2:
            qi, qj = z_pos
            angle = 2 * gamma * coeff.real
            qc.cx(qi, qj)
            qc.rz(angle, qj)
            qc.cx(qi, qj)
        elif len(z_pos) == 1:
            qi = z_pos[0]
            angle = 2 * gamma * coeff.real
            qc.rz(angle, qi)

    for i in range(n_qubits):
        qc.rx(2 * beta, i)

    qc.measure_all()
    return qc


# ── classical brute-force ────────────────────────────────────────

def _classical_brute_force(cost_matrix, balance_lambda=BALANCE_LAMBDA):
    n = cost_matrix.shape[0]
    best_cost, best_bits = -np.inf, None
    for bits in iter_product([0, 1], repeat=n):
        if all(b == bits[0] for b in bits):
            continue  # skip trivial
        c = evaluate_cost(list(bits), cost_matrix, balance_lambda)
        if c > best_cost:
            best_cost = c
            best_bits = "".join(str(b) for b in bits)
    return best_bits, best_cost


# ── public entry point ───────────────────────────────────────────

def run_clustering(memories, n_gamma=12, n_beta=12, shots=4096):
    """
    Run QAOA clustering + classical brute-force on a set of memories.

    Returns dict with quantum result, classical result, and comparison.
    """
    n = len(memories)
    cost_matrix, components = build_combined_cost_matrix(memories)
    ham = _cost_hamiltonian(cost_matrix)
    sim = AerSimulator()

    gamma_range = np.linspace(0.1, 2 * np.pi, n_gamma)
    beta_range = np.linspace(0.1, np.pi, n_beta)

    best_exp = -np.inf
    best_params = (0.0, 0.0)
    best_counts = None

    t0 = time.time()
    for gv in gamma_range:
        for bv in beta_range:
            qc = _build_qaoa_circuit(ham, n, gv, bv)
            result = sim.run(qc, shots=shots).result()
            counts = result.get_counts()

            exp = 0.0
            for bs, cnt in counts.items():
                bits = [int(b) for b in bs]
                exp += evaluate_cost(bits, cost_matrix) * cnt
            exp /= shots

            if exp > best_exp:
                best_exp = exp
                best_params = (gv, bv)
                best_counts = counts

    qaoa_time = time.time() - t0

    # best non-trivial from QAOA
    q_best_bs, q_best_cost = None, -np.inf
    for bs, cnt in best_counts.items():
        bits = [int(b) for b in bs]
        if all(b == bits[0] for b in bits):
            continue
        c = evaluate_cost(bits, cost_matrix)
        if c > q_best_cost:
            q_best_cost = c
            q_best_bs = bs

    if q_best_bs is None:
        q_best_bs = max(best_counts, key=best_counts.get)
        q_best_cost = evaluate_cost([int(b) for b in q_best_bs], cost_matrix)

    # complement check
    comp = "".join("1" if b == "0" else "0" for b in q_best_bs)
    comp_cost = evaluate_cost([int(b) for b in comp], cost_matrix)
    if comp_cost > q_best_cost:
        q_best_bs, q_best_cost = comp, comp_cost

    # classical
    t0 = time.time()
    c_best_bs, c_best_cost = _classical_brute_force(cost_matrix)
    classical_time = time.time() - t0

    # complement check on classical too
    comp = "".join("1" if b == "0" else "0" for b in c_best_bs)
    comp_cost = evaluate_cost([int(b) for b in comp], cost_matrix)
    if comp_cost > c_best_cost:
        c_best_bs, c_best_cost = comp, comp_cost

    # match?
    def _match(a, b):
        c = "".join("1" if x == "0" else "0" for x in b)
        return a == b or a == c

    approx_ratio = q_best_cost / c_best_cost if c_best_cost > 0 else 0.0
    exact = _match(q_best_bs, c_best_bs)

    return {
        "n": n,
        "quantum": {
            "bitstring": q_best_bs,
            "cost": float(q_best_cost),
            "time": qaoa_time,
            "gamma": float(best_params[0]),
            "beta": float(best_params[1]),
        },
        "classical": {
            "bitstring": c_best_bs,
            "cost": float(c_best_cost),
            "time": classical_time,
        },
        "approx_ratio": float(approx_ratio),
        "exact_match": exact,
    }
