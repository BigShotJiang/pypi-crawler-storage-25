"""
Benchmark runner — executes all 3 quantum layers and produces a report.

Copyright 2026 Coinkong (Chef's Attraction). MIT License.
"""

import json
import os
import time
from datetime import datetime, timezone

from .demo_data import get_demo_memories
from .clustering import run_clustering
from .compaction import run_compaction
from .recall import run_recall

__all__ = ["run_benchmark"]

RESULTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "results")

# Demo queries for recall layer
DEMO_QUERIES = [
    "What are the current project deadlines and milestones?",
    "What preferences do team members have for communication and tools?",
]


def _box(text, width=50):
    """Draw a box line, padded to width."""
    inner = text.ljust(width - 4)
    return f"║  {inner}║"


def run_benchmark(memories=None, mem0_url=None):
    """
    Run the full 3-layer benchmark.

    Args:
        memories: list of memory dicts (uses demo data if None)
        mem0_url: optional Mem0 API URL to fetch live memories

    Returns:
        dict with full benchmark results
    """
    # Fetch memories
    if mem0_url:
        try:
            import requests
            resp = requests.get(f"{mem0_url}/memories", timeout=10)
            resp.raise_for_status()
            data = resp.json()
            memories = data.get("memories", data) if isinstance(data, dict) else data
            print(f"[+] Fetched {len(memories)} memories from Mem0")
        except Exception as e:
            print(f"[!] Mem0 fetch failed ({e}), falling back to demo data")
            memories = None

    if memories is None:
        memories = get_demo_memories()
        print(f"[+] Using {len(memories)} demo memories")

    t_start = time.time()
    results = {"layers": {}, "timestamp": datetime.now(timezone.utc).isoformat()}

    # ── Layer 1: Clustering ──────────────────────────────────────
    print("\n[Layer 1] Clustering...")
    clustering_results = []
    for n in [8, 10, 12]:
        subset = memories[:n]
        if len(subset) < n:
            break
        r = run_clustering(subset, n_gamma=12, n_beta=12, shots=4096)
        clustering_results.append(r)
        pct = r["approx_ratio"] * 100
        print(f"  n={n}: Quantum {pct:.1f}% optimal [{r['quantum']['time']:.1f}s]")

    results["layers"]["clustering"] = clustering_results

    # ── Layer 2: Compaction ──────────────────────────────────────
    print("\n[Layer 2] Compaction...")
    compaction_results = []
    for M, K in [(10, 5), (12, 6)]:
        subset = memories[:M]
        if len(subset) < M:
            break
        r = run_compaction(subset, K, grid_size=10, shots=1024)
        compaction_results.append(r)
        print(f"  M={M},K={K}: Quantum {r['quantum_vs_optimal_pct']:.1f}% optimal")

    results["layers"]["compaction"] = compaction_results

    # ── Layer 3: Recall ──────────────────────────────────────────
    print("\n[Layer 3] Recall...")
    recall_results = []
    subset = memories[:12] if len(memories) >= 12 else memories
    for i, query in enumerate(DEMO_QUERIES):
        r = run_recall(query, subset, K=5, grid_size=10, shots=1024)
        recall_results.append(r)
        print(f"  Query {i+1}: Quantum {r['quantum_vs_optimal_pct']:.1f}% | "
              f"Top-K {r['topk_vs_optimal_pct']:.1f}%")

    results["layers"]["recall"] = recall_results

    total_time = time.time() - t_start
    results["total_time"] = total_time

    # ── Summary stats ────────────────────────────────────────────
    all_pcts = []
    for r in clustering_results:
        all_pcts.append(r["approx_ratio"] * 100)
    for r in compaction_results:
        all_pcts.append(r["quantum_vs_optimal_pct"])
    for r in recall_results:
        all_pcts.append(r["quantum_vs_optimal_pct"])

    avg_accuracy = sum(all_pcts) / len(all_pcts) if all_pcts else 0.0
    results["avg_accuracy"] = avg_accuracy
    results["n_layers_tested"] = 3

    # ── Print report ─────────────────────────────────────────────
    w = 52
    border = "═" * (w - 2)
    print()
    print(f"╔{border}╗")
    print(_box("QUANTUM AGENT MEMORY — BENCHMARK REPORT", w))
    print(f"╠{border}╣")

    print(_box("Layer 1: Clustering", w))
    for r in clustering_results:
        n = r["n"]
        pct = r["approx_ratio"] * 100
        t = r["quantum"]["time"]
        print(_box(f"  n={n:>2}: Quantum {pct:>5.1f}% optimal  [{t:.1f}s]", w))

    print(_box("Layer 2: Compaction", w))
    for r in compaction_results:
        M, K = r["M"], r["K"]
        pct = r["quantum_vs_optimal_pct"]
        print(_box(f"  M={M},K={K}: Quantum {pct:>5.1f}% optimal", w))

    print(_box("Layer 3: Recall", w))
    for i, r in enumerate(recall_results):
        qp = r["quantum_vs_optimal_pct"]
        tp = r["topk_vs_optimal_pct"]
        print(_box(f"  Query {i+1}: Quantum {qp:>5.1f}% | Top-K {tp:>5.1f}%", w))

    print(_box(f"Summary: Avg accuracy {avg_accuracy:.1f}%, "
               f"{results['n_layers_tested']} layers tested", w))
    print(f"╚{border}╝")

    # ── Save JSON ────────────────────────────────────────────────
    os.makedirs(RESULTS_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_path = os.path.join(RESULTS_DIR, f"benchmark_{ts}.json")
    with open(json_path, "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\n[+] Results saved to {json_path}")

    return results
