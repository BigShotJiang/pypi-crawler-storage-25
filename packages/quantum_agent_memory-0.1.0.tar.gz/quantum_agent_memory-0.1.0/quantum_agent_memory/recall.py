"""
Layer 3 — QAOA Recall

Find the optimal COMBINATION of K memories to inject into an LLM context
window for a given query. Not just "most similar" — memories that are
individually low-relevance can be critical when combined (synergy).

Cost function:
  - Individual relevance (40%) — word overlap with query
  - Pair synergy (30%) — complementary query coverage
  - Coverage diversity (20%) — avoid redundant memories
  - Recency (10%) — prefer fresher memories

Budget penalty forces exactly K selections.

Copyright 2026 Coinkong (Chef's Attraction). MIT License.
"""

import time
from itertools import combinations
from datetime import datetime, timezone

import numpy as np
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator

__all__ = ["run_recall"]

W_RELEVANCE = 0.40
W_SYNERGY = 0.30
W_COVERAGE = 0.20
W_RECENCY = 0.10
PENALTY_WEIGHT = 6.0

STOP_WORDS = frozenset({
    "the", "is", "a", "an", "and", "or", "but", "in", "on", "at",
    "to", "for", "of", "with", "by", "from", "was", "were", "are",
    "be", "been", "being", "have", "has", "had", "do", "does", "did",
    "will", "would", "could", "should", "may", "might", "can", "this",
    "that", "these", "those", "it", "its", "not", "no", "he", "she",
    "his", "her", "my", "me", "i", "you", "we", "us", "they", "them",
    "what", "who", "how", "when", "where", "which",
})


# ── text helpers ─────────────────────────────────────────────────

def _tokenize(text):
    words = set()
    for w in text.lower().split():
        w = "".join(c for c in w if c.isalnum())
        if len(w) > 2 and w not in STOP_WORDS:
            words.add(w)
    return words


def _individual_relevance(query, memories):
    qt = _tokenize(query)
    scores = []
    for mem in memories:
        mt = _tokenize(mem.get("memory", ""))
        if not qt or not mt:
            scores.append(0.0)
            continue
        overlap = qt & mt
        recall = len(overlap) / len(qt)
        precision = len(overlap) / len(mt)
        f1 = 2 * recall * precision / (recall + precision) if (recall + precision) > 0 else 0.0
        scores.append(f1)
    return np.array(scores)


def _pair_synergy(query, memories):
    n = len(memories)
    qt = _tokenize(query)
    mts = [_tokenize(m.get("memory", "")) for m in memories]

    matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            qi = qt & mts[i]
            qj = qt & mts[j]
            combined = qi | qj

            if qt:
                combined_recall = len(combined) / len(qt)
                max_individual = max(len(qi), len(qj)) / len(qt)
                complementary = combined_recall - max_individual
            else:
                complementary = 0.0

            mi, mj = mts[i], mts[j]
            if mi | mj:
                jaccard = len(mi & mj) / len(mi | mj)
            else:
                jaccard = 0.0
            relatedness = np.exp(-((jaccard - 0.2) ** 2) / 0.05)

            shared_entities = mi & mj - qt
            bridge_bonus = min(len(shared_entities) / 5.0, 0.3)

            synergy = max(0.0, complementary * 0.5 + relatedness * 0.3 + bridge_bonus * 0.2)
            matrix[i][j] = matrix[j][i] = synergy
    return matrix


def _coverage_diversity(memories):
    n = len(memories)
    mts = [_tokenize(m.get("memory", "")) for m in memories]
    matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            if mts[i] | mts[j]:
                overlap = len(mts[i] & mts[j]) / len(mts[i] | mts[j])
            else:
                overlap = 0.0
            matrix[i][j] = matrix[j][i] = 1.0 - overlap
    return matrix


def _recency_scores(memories):
    now = datetime.now(timezone.utc).timestamp()
    timestamps = []
    for mem in memories:
        try:
            ts = datetime.fromisoformat(
                mem.get("updated_at", mem.get("created_at", "")).replace("Z", "+00:00")
            ).timestamp()
        except (ValueError, AttributeError):
            ts = now
        timestamps.append(ts)
    ts = np.array(timestamps)
    span = max(ts.max() - ts.min(), 1.0)
    return (ts - ts.min()) / span


# ── evaluate selection ───────────────────────────────────────────

def _evaluate_selection(selection, relevance, synergy, diversity, recency, K):
    if not selection:
        return -999.0

    rel_score = sum(relevance[i] for i in selection)
    max_rel = sum(sorted(relevance, reverse=True)[:K])
    norm_rel = rel_score / max_rel if max_rel > 0 else 0.0

    pair_count = 0
    syn_score = div_score = 0.0
    for a in range(len(selection)):
        for b in range(a + 1, len(selection)):
            syn_score += synergy[selection[a]][selection[b]]
            div_score += diversity[selection[a]][selection[b]]
            pair_count += 1
    norm_syn = syn_score / pair_count if pair_count else 0.0
    norm_div = div_score / pair_count if pair_count else 0.0

    rec_score = np.mean([recency[i] for i in selection])

    return (
        W_RELEVANCE * norm_rel
        + W_SYNERGY * norm_syn
        + W_COVERAGE * norm_div
        + W_RECENCY * rec_score
    )


# ── QAOA circuit ──────────────────────────────────────────────────

def _build_qaoa_circuit(gamma, beta, relevance, synergy, diversity, recency, M, K):
    qc = QuantumCircuit(M)
    for i in range(M):
        qc.h(i)

    # individual terms
    for i in range(M):
        ind = W_RELEVANCE * relevance[i] + W_RECENCY * recency[i]
        if abs(ind) > 1e-10:
            qc.rz(gamma * ind, i)

    # pairwise terms
    for i in range(M):
        for j in range(i + 1, M):
            pair = W_SYNERGY * synergy[i][j] + W_COVERAGE * diversity[i][j]
            if abs(pair) > 1e-10:
                qc.cx(i, j)
                qc.rz(gamma * pair / 2, j)
                qc.cx(i, j)

    # budget penalty — linear
    pen_linear = PENALTY_WEIGHT * (1 - 2 * K)
    for i in range(M):
        qc.rz(-gamma * pen_linear / 2, i)

    # budget penalty — quadratic
    pen_quad = PENALTY_WEIGHT * 2
    for i in range(M):
        for j in range(i + 1, M):
            qc.cx(i, j)
            qc.rz(-gamma * pen_quad / 2, j)
            qc.cx(i, j)

    for i in range(M):
        qc.rx(2 * beta, i)

    qc.measure_all()
    return qc


def _run_qaoa(relevance, synergy, diversity, recency, M, K, grid_size=10, shots=1024):
    sim = AerSimulator()
    gamma_range = np.linspace(0.1, np.pi, grid_size)
    beta_range = np.linspace(0.1, np.pi / 2, grid_size)

    best_score = -np.inf
    best_selection = None

    t0 = time.time()
    for gamma in gamma_range:
        for beta in beta_range:
            qc = _build_qaoa_circuit(gamma, beta, relevance, synergy, diversity, recency, M, K)
            result = sim.run(qc, shots=shots).result()
            counts = result.get_counts()

            for bitstring, count in counts.items():
                bits = bitstring.replace(" ", "")[::-1]
                selection = [i for i, b in enumerate(bits) if b == "1"]
                if len(selection) != K:
                    continue
                score = _evaluate_selection(selection, relevance, synergy, diversity, recency, K)
                if score > best_score:
                    best_score = score
                    best_selection = sorted(selection)

    elapsed = time.time() - t0

    if best_selection is None:
        best_selection = sorted(range(K))
        best_score = _evaluate_selection(best_selection, relevance, synergy, diversity, recency, K)

    return {"selection": best_selection, "score": float(best_score), "time": elapsed}


# ── classical baselines ──────────────────────────────────────────

def _topk_similarity(relevance, K):
    t0 = time.time()
    sel = sorted(range(len(relevance)), key=lambda i: -relevance[i])[:K]
    return {"selection": sorted(sel), "time": time.time() - t0}


def _brute_force(relevance, synergy, diversity, recency, M, K):
    t0 = time.time()
    best_score, best_sel = -np.inf, None
    for combo in combinations(range(M), K):
        score = _evaluate_selection(list(combo), relevance, synergy, diversity, recency, K)
        if score > best_score:
            best_score = score
            best_sel = list(combo)
    return {"selection": best_sel, "score": float(best_score), "time": time.time() - t0}


# ── public entry point ───────────────────────────────────────────

def run_recall(query, memories, K=5, grid_size=10, shots=1024):
    """
    Run QAOA recall for a query against a set of memories.

    Returns dict with quantum, top-K, and brute-force optimal results.
    """
    M = len(memories)
    relevance = _individual_relevance(query, memories)
    synergy = _pair_synergy(query, memories)
    diversity = _coverage_diversity(memories)
    recency = _recency_scores(memories)

    quantum = _run_qaoa(relevance, synergy, diversity, recency, M, K, grid_size, shots)
    topk = _topk_similarity(relevance, K)
    topk["score"] = _evaluate_selection(topk["selection"], relevance, synergy, diversity, recency, K)
    brute = _brute_force(relevance, synergy, diversity, recency, M, K)

    opt = brute["score"]
    q_pct = (quantum["score"] / opt * 100) if opt > 0 else 0.0
    t_pct = (topk["score"] / opt * 100) if opt > 0 else 0.0

    return {
        "query": query,
        "M": M,
        "K": K,
        "quantum": quantum,
        "topk": {**topk, "score": float(topk["score"])},
        "brute_force": brute,
        "quantum_vs_optimal_pct": float(q_pct),
        "topk_vs_optimal_pct": float(t_pct),
    }
