"""
CLI entry point — run with: python -m quantum_agent_memory <command>

Commands:
  benchmark              Run all 3 quantum layers on demo data
  benchmark --mem0-url   Run against a live Mem0 instance
  submit --ibm-token     Submit circuits to IBM Quantum hardware
"""

import argparse
import sys


def cmd_benchmark(args):
    from .benchmark import run_benchmark
    run_benchmark(mem0_url=args.mem0_url)


def cmd_submit(args):
    if not args.ibm_token:
        print("Error: --ibm-token is required for submit")
        sys.exit(1)

    try:
        from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
        from qiskit import transpile
    except ImportError:
        print("[!] qiskit-ibm-runtime required. Install with:")
        print("    pip install qiskit-ibm-runtime")
        sys.exit(1)

    from qiskit import QuantumCircuit
    import numpy as np

    # Build representative circuits for each layer
    def _sample_clustering_circuit(n=8):
        qc = QuantumCircuit(n)
        gamma, beta = 1.2, 0.8
        for i in range(n):
            qc.h(i)
        for i in range(n):
            for j in range(i + 1, n):
                weight = 0.3 + 0.2 * ((i * 7 + j * 3) % 5) / 5.0
                qc.cx(i, j)
                qc.rz(2 * gamma * weight, j)
                qc.cx(i, j)
        for i in range(n):
            for j in range(i + 1, n):
                qc.cx(i, j)
                qc.rz(2 * gamma * 0.15, j)
                qc.cx(i, j)
        for i in range(n):
            qc.rx(2 * beta, i)
        qc.measure_all()
        return qc

    def _sample_compaction_circuit(n=12, K=6):
        qc = QuantumCircuit(n)
        gamma, beta = 0.9, 0.6
        for i in range(n):
            qc.h(i)
        for i in range(n):
            val = 0.2 + 0.6 * ((i * 11 + 3) % 7) / 7.0
            qc.rz(gamma * val, i)
        for i in range(n):
            for j in range(i + 1, n):
                pair = 0.1 + 0.3 * ((i * 5 + j * 13) % 9) / 9.0
                if pair > 0.15:
                    qc.cx(i, j)
                    qc.rz(gamma * pair / 2, j)
                    qc.cx(i, j)
        pen = 6.0 * (1 - 2 * K)
        for i in range(n):
            qc.rz(-gamma * pen / 2, i)
        pen_q = 12.0
        for i in range(n):
            for j in range(i + 1, n):
                qc.cx(i, j)
                qc.rz(-gamma * pen_q / 2, j)
                qc.cx(i, j)
        for i in range(n):
            qc.rx(2 * beta, i)
        qc.measure_all()
        return qc

    def _sample_recall_circuit(n=12, K=5):
        qc = QuantumCircuit(n)
        gamma, beta = 1.0, 0.7
        for i in range(n):
            qc.h(i)
        for i in range(n):
            rel = 0.1 + 0.5 * ((i * 7 + 2) % 6) / 6.0
            rec = 0.3 + 0.5 * i / n
            qc.rz(gamma * (0.4 * rel + 0.1 * rec), i)
        for i in range(n):
            for j in range(i + 1, n):
                syn = 0.05 + 0.2 * ((i * 3 + j * 7) % 11) / 11.0
                div = 0.3 + 0.4 * ((i * 13 + j * 5) % 8) / 8.0
                pair = 0.3 * syn + 0.2 * div
                if pair > 0.05:
                    qc.cx(i, j)
                    qc.rz(gamma * pair / 2, j)
                    qc.cx(i, j)
        pen = 6.0 * (1 - 2 * K)
        for i in range(n):
            qc.rz(-gamma * pen / 2, i)
        pen_q = 12.0
        for i in range(n):
            for j in range(i + 1, n):
                qc.cx(i, j)
                qc.rz(-gamma * pen_q / 2, j)
                qc.cx(i, j)
        for i in range(n):
            qc.rx(2 * beta, i)
        qc.measure_all()
        return qc

    print("[+] Configuring IBM Quantum service...")
    QiskitRuntimeService.save_account(
        channel="ibm_quantum", token=args.ibm_token, overwrite=True,
    )
    service = QiskitRuntimeService(channel="ibm_quantum")

    print("[+] Available backends:")
    backends = service.backends()
    for b in backends:
        st = b.status()
        print(f"    {b.name}: {b.num_qubits} qubits, pending={st.pending_jobs}")

    from qiskit_ibm_runtime import least_busy
    suitable = [b for b in backends if b.num_qubits >= 12 and b.status().operational]
    if not suitable:
        suitable = [b for b in backends if b.status().operational]
    backend = least_busy(suitable)
    print(f"[+] Selected: {backend.name} ({backend.num_qubits} qubits)")

    circuits = {
        "clustering": _sample_clustering_circuit(8),
        "compaction": _sample_compaction_circuit(12, 6),
        "recall": _sample_recall_circuit(12, 5),
    }

    for name, qc in circuits.items():
        print(f"\n[+] Submitting {name}...")
        transpiled = transpile(qc, backend=backend, optimization_level=2)
        print(f"    Transpiled: depth={transpiled.depth()}, gates={transpiled.size()}")
        sampler = SamplerV2(backend)
        job = sampler.run([transpiled], shots=1024)
        print(f"    Job ID: {job.job_id()}")
        print(f"    Waiting for results...")
        result = job.result()
        counts = result[0].data.meas.get_counts()
        top = sorted(counts.items(), key=lambda x: -x[1])[:5]
        print(f"    Top 5 bitstrings:")
        for bs, cnt in top:
            print(f"      {bs}: {cnt}/1024 ({cnt/1024*100:.1f}%)")

    print("\n[+] IBM Quantum hardware submission complete!")


def main():
    parser = argparse.ArgumentParser(
        prog="quantum_agent_memory",
        description="Quantum Agent Memory — QAOA-powered memory management for AI agents",
    )
    subparsers = parser.add_subparsers(dest="command")

    bench = subparsers.add_parser("benchmark", help="Run 3-layer benchmark")
    bench.add_argument("--mem0-url", default=None,
                       help="Mem0 API base URL (e.g. http://localhost:8500)")

    submit = subparsers.add_parser("submit", help="Submit to IBM Quantum hardware")
    submit.add_argument("--ibm-token", required=True, help="IBM Quantum API token")

    args = parser.parse_args()

    if args.command == "benchmark":
        cmd_benchmark(args)
    elif args.command == "submit":
        cmd_submit(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
