"""
Shared cost matrix builder — 4-dimension scoring for agent memories.

Dimensions:
  1. Temporal coherence  — memories close in time score higher
  2. Relational coherence — shared entities/words score higher (Jaccard)
  3. Categorical coherence — same agent/source/batch score higher
  4. Recency weighting    — newer memories weighted higher

Copyright 2026 Coinkong (Chef's Attraction). MIT License.
"""

import numpy as np
from datetime import datetime, timezone

__all__ = [
    "build_combined_cost_matrix",
    "temporal_coherence",
    "relational_coherence",
    "categorical_coherence",
    "recency_weighting",
    "parse_timestamp",
]

# Default dimension weights
DEFAULT_WEIGHTS = {
    "temporal": 0.25,
    "relational": 0.30,
    "categorical": 0.25,
    "recency": 0.20,
}


def parse_timestamp(ts_str):
    """Parse ISO timestamp string to epoch seconds."""
    if not ts_str:
        return datetime.now(timezone.utc).timestamp()
    try:
        clean = ts_str.replace("Z", "+00:00")
        dt = datetime.fromisoformat(clean)
        return dt.timestamp()
    except Exception:
        return datetime.now(timezone.utc).timestamp()


def temporal_coherence(memories):
    """Pairwise temporal proximity — closer in time => higher score."""
    n = len(memories)
    ts = np.array([parse_timestamp(m.get("created_at", "")) for m in memories])
    matrix = np.zeros((n, n))
    span = max(ts.max() - ts.min(), 1.0)
    for i in range(n):
        for j in range(i + 1, n):
            s = 1.0 - abs(ts[i] - ts[j]) / span
            matrix[i][j] = matrix[j][i] = s
    return matrix


def relational_coherence(memories):
    """Pairwise word/entity overlap (Jaccard similarity)."""
    n = len(memories)
    word_sets = []
    for m in memories:
        text = m.get("memory", "").lower()
        words = set(w for w in text.split() if len(w) > 3)
        agent = m.get("agent_id", "")
        if agent:
            words.add(f"agent:{agent}")
        word_sets.append(words)

    matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            u = len(word_sets[i] | word_sets[j])
            s = len(word_sets[i] & word_sets[j]) / u if u else 0.0
            matrix[i][j] = matrix[j][i] = s
    return matrix


def categorical_coherence(memories):
    """Score based on shared source, batch, and agent metadata."""
    n = len(memories)
    cats = []
    for m in memories:
        meta = m.get("metadata", None) or {}
        cats.append((
            meta.get("source", "unknown"),
            meta.get("batch", "none"),
            m.get("agent_id", "unknown"),
        ))

    matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            s = 0.0
            if cats[i][0] == cats[j][0]:
                s += 0.4
            if cats[i][1] == cats[j][1]:
                s += 0.3
            if cats[i][2] == cats[j][2]:
                s += 0.3
            matrix[i][j] = matrix[j][i] = s
    return matrix


def recency_weighting(memories):
    """Pairwise recency — two recent memories together score higher."""
    n = len(memories)
    ts = np.array([
        parse_timestamp(m.get("updated_at", m.get("created_at", "")))
        for m in memories
    ])
    oldest, newest = ts.min(), ts.max()
    span = max(newest - oldest, 1.0)
    recency = (ts - oldest) / span

    matrix = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            s = np.sqrt(recency[i] * recency[j])
            matrix[i][j] = matrix[j][i] = s
    return matrix


def build_combined_cost_matrix(memories, weights=None):
    """
    Build the 4-dimension combined cost matrix for a list of memories.

    Returns:
        combined (np.ndarray): N×N pairwise cost matrix
        components (dict): individual dimension matrices
    """
    if weights is None:
        weights = DEFAULT_WEIGHTS

    t = temporal_coherence(memories)
    r = relational_coherence(memories)
    c = categorical_coherence(memories)
    w = recency_weighting(memories)

    combined = (
        weights["temporal"] * t
        + weights["relational"] * r
        + weights["categorical"] * c
        + weights["recency"] * w
    )

    return combined, {"temporal": t, "relational": r, "categorical": c, "recency": w}
