"""
Quantum Agent Memory — QAOA-powered memory management for AI agents.

Three quantum layers:
  1. Clustering  — group memories by semantic similarity using balanced graph cuts
  2. Compaction  — select optimal K memories to retain from M total
  3. Recall      — find optimal memory combinations for context injection

Copyright 2026 Coinkong (Chef's Attraction). MIT License.
"""

__version__ = "0.1.0"
__author__ = "Coinkong (Chef's Attraction)"
