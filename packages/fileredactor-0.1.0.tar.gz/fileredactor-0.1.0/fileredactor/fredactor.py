import re
import os

def found(file, word):
    with open(file, 'r', encoding='utf-8') as f:
        data = f.read()
    
    return word in data

def addword(file, word):
    with open(file, 'a', encoding='utf-8') as f:
        f.write(word)

def rewrite(file, word):
    with open(file, 'w', encoding='utf-8') as f:
        f.write(word)

def removeword(file, word):
    with open(file, "r", encoding="utf-8") as f:
        data = f.read()
    data = re.sub(rf"\b{word}\b", "", data)
    with open(file, "w", encoding="utf-8") as f:
        f.write(data)

def removefile(file):
    os.remove(file)

def createfile(file):
    with open(file, 'x', encoding='utf-8'):
        file = file