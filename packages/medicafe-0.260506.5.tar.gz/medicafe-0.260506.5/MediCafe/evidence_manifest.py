# -*- coding: utf-8 -*-
"""
Unified evidence bundle manifest (XP-compatible: Python 3.4).

Step 1: EvidenceRequest normalization, lab state reads, Phase C failure contract,
manifest_to_extra_files / manifest_to_extra_meta, merge_extra_files for callers.

attachment_contract_status (explicit semantics):
- pass: every Phase-C-required attachment for this request resolved to a path or
  inline body (no missing_required_evidence entries for required items).
- degraded: at least one required attachment is missing (recorded in
  missing_required_evidence) but the bundle may still be useful to send
  (e.g. diagnostics_state + run_cursor without run-aligned ingest summary).
- fail: contract is not meaningfully actionable (reserved for future bundle_kind
  policy; first slice uses this only when lab_root is unusable and nothing resolved).
"""
from __future__ import print_function

import json
import os
import time

try:
    from MediCafe.evidence_contracts import (
        EVIDENCE_MANIFEST_SCHEMA_VERSION,
        EVIDENCE_REQUEST_SCHEMA_VERSION,
        PHASE_C_CORRELATION_ARCHIVE_NAME,
    )
except Exception:
    try:
        from evidence_contracts import (
            EVIDENCE_MANIFEST_SCHEMA_VERSION,
            EVIDENCE_REQUEST_SCHEMA_VERSION,
            PHASE_C_CORRELATION_ARCHIVE_NAME,
        )
    except Exception:
        EVIDENCE_REQUEST_SCHEMA_VERSION = 1
        EVIDENCE_MANIFEST_SCHEMA_VERSION = 1
        PHASE_C_CORRELATION_ARCHIVE_NAME = "phase_c_bundle_correlation_note.txt"


def _safe_str(value):
    if value is None:
        return ""
    return str(value)


def _read_json_dict(path):
    """Return dict from JSON file, or None if missing/invalid."""
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
        return None
    except Exception:
        return None


def build_evidence_request(bundle_kind, send_source, lab_root, **kwargs):
    """Normalize caller context into an EvidenceRequest dict."""
    anchor_run_id = _safe_str(kwargs.get("anchor_run_id"))
    active_run_id = _safe_str(kwargs.get("active_run_id"))
    if not active_run_id:
        active_run_id = anchor_run_id
    request = {
        "schema_version": EVIDENCE_REQUEST_SCHEMA_VERSION,
        "bundle_kind": _safe_str(bundle_kind),
        "send_source": _safe_str(send_source),
        "lab_root": _safe_str(lab_root),
        "anchor_run_id": anchor_run_id,
        "active_run_id": active_run_id,
        "failed_phase": _safe_str(kwargs.get("failed_phase")),
        "error_code": _safe_str(kwargs.get("error_code")),
        "recommendation_action_kind": _safe_str(kwargs.get("recommendation_action_kind")),
        "operator_surface": _safe_str(kwargs.get("operator_surface")) or "developer_support",
        "include_traceback": bool(kwargs.get("include_traceback")),
        "reason": _safe_str(kwargs.get("reason")),
        "phase_f_report_json_path": _safe_str(kwargs.get("phase_f_report_json_path")),
        "phase_f_report_txt_path": _safe_str(kwargs.get("phase_f_report_txt_path")),
        "phase_f_evidence_index_path": _safe_str(kwargs.get("phase_f_evidence_index_path")),
        "follow_recommendation_now": _safe_str(kwargs.get("follow_recommendation_now")),
        "operator_manual_review_required": bool(kwargs.get("operator_manual_review_required")),
        "reply_required": bool(kwargs.get("reply_required")),
        "evidence_snapshot_mixed_note": _safe_str(kwargs.get("evidence_snapshot_mixed_note")),
    }
    # Caller-only context (not part of stable schema; stripped from audits if needed)
    if "_cloud_health_diagnostics" in kwargs:
        request["_cloud_health_diagnostics"] = kwargs.get("_cloud_health_diagnostics")
    if kwargs.get("_prefetched_evidence_tuples") is not None:
        request["_prefetched_evidence_tuples"] = list(kwargs.get("_prefetched_evidence_tuples") or [])
    for _orch_key in (
        "_orchestrator_result",
        "_orchestrator_payload",
        "_orchestrator_diagnostic_path",
        "_orchestrator_report_path",
    ):
        if _orch_key in kwargs:
            request[_orch_key] = kwargs.get(_orch_key)
    return request


def read_lab_state(lab_root):
    """
    Read diagnostics_state.json and run_cursor.json once.

    Returns dict with keys diagnostics_state, run_cursor (dict or None), and paths
    mapping logical names to absolute paths.
    """
    root = _safe_str(lab_root)
    paths = {
        "diagnostics_state.json": os.path.join(root, "diagnostics_state.json"),
        "run_cursor.json": os.path.join(root, "run_cursor.json"),
    }
    diagnostics_state = _read_json_dict(paths["diagnostics_state.json"])
    run_cursor = _read_json_dict(paths["run_cursor.json"])
    return {
        "diagnostics_state": diagnostics_state,
        "run_cursor": run_cursor,
        "paths": paths,
    }


def resolve_phase_c_summary(lab_root, state, cursor):
    """
    Strict run-aligned Phase C ingest summary resolution.

    If last_phase_c_run_id (from state) is non-empty and
    reports/ingest_write_summary_<run_id>.json is missing, callers must record
    missing_required_evidence — no mtime or latest fallback.

    state/cursor may be None (treated as empty dict for run id lookup).
    """
    root = _safe_str(lab_root)
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    run_id = _safe_str(st.get("last_phase_c_run_id"))
    if not run_id:
        run_id = _safe_str(cr.get("last_phase_c_run_id"))
    expected_name = ""
    expected_path = ""
    if run_id:
        expected_name = "ingest_write_summary_{0}.json".format(run_id)
        expected_path = os.path.join(root, "reports", expected_name)
    summary_obj = None
    exists = False
    if run_id and expected_path and os.path.isfile(expected_path):
        exists = True
        summary_obj = _read_json_dict(expected_path)
    return {
        "run_id": run_id,
        "expected_archive_name": expected_name,
        "expected_path": expected_path,
        "exists": exists,
        "summary": summary_obj,
    }


def _manifest_sha_tokens(state, cursor, summary):
    """Extract comparable Phase C manifest sha tokens from state/cursor/summary."""
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    sm = summary if isinstance(summary, dict) else {}
    out = []
    for src in (st, cr):
        for key in ("last_ingest_manifest_sha256", "last_manifest_sha256", "manifest_sha256"):
            val = _safe_str(src.get(key)).strip()
            if val:
                out.append(val)
    m_sha = _safe_str(sm.get("manifest_sha256")).strip()
    if m_sha:
        out.append(m_sha)
    return out


def _compute_coherence_status(state, cursor, summary_info):
    """If all three manifest sha fields exist and any differ, review_required."""
    if not summary_info.get("exists"):
        return "ready"
    summary = summary_info.get("summary")
    if not isinstance(summary, dict):
        return "ready"
    tokens = _manifest_sha_tokens(state, cursor, summary)
    if len(tokens) < 2:
        return "ready"
    if len(set(tokens)) == 1:
        return "ready"
    return "review_required"


def _phase_c_correlation_body(request, state, cursor, summary_info):
    """Deterministic non-PHI correlation text for Phase C bundle."""
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    lines = [
        "phase_c_bundle_correlation",
        "bundle_kind={0}".format(_safe_str(request.get("bundle_kind"))),
        "send_source={0}".format(_safe_str(request.get("send_source"))),
        "anchor_run_id={0}".format(_safe_str(request.get("anchor_run_id"))),
        "active_run_id={0}".format(_safe_str(request.get("active_run_id"))),
        "failed_phase={0}".format(_safe_str(request.get("failed_phase"))),
        "error_code={0}".format(_safe_str(request.get("error_code"))),
        "last_phase_c_run_id={0}".format(_safe_str(st.get("last_phase_c_run_id"))),
        "last_phase_c_ok={0}".format(st.get("last_phase_c_ok")),
        "last_phase_c_error_code={0}".format(_safe_str(st.get("last_phase_c_error_code"))),
        "last_phase_c_shadow_recovery_status={0}".format(_safe_str(st.get("last_phase_c_shadow_recovery_status"))),
        "last_phase_c_shadow_recovery_report_path={0}".format(_safe_str(st.get("last_phase_c_shadow_recovery_report_path"))),
        "ingest_summary_attached={0}".format("yes" if summary_info.get("exists") else "no"),
        "last_manifest_sha256_state={0}".format(_safe_str(st.get("last_manifest_sha256"))),
        "last_manifest_sha256_cursor={0}".format(_safe_str(cr.get("last_manifest_sha256"))),
    ]
    if isinstance(summary_info.get("summary"), dict):
        sm = summary_info["summary"]
        lines.append("ingest_summary_manifest_sha256={0}".format(_safe_str(sm.get("manifest_sha256"))))
    return "\n".join(lines) + "\n"


ATTACHMENT_STALE_AFTER_SEC = 86400


def _attachment_freshness_for_path(source_path):
    """Classify manifest file attachments with the same 24h stale boundary as bundle meta."""
    path = _safe_str(source_path)
    if not path or not os.path.isfile(path):
        return "current_run"
    try:
        age_sec = int(max(0, int(time.time()) - int(os.path.getmtime(path))))
        if age_sec > ATTACHMENT_STALE_AFTER_SEC:
            return "historical_snapshot"
    except Exception:
        pass
    return "current_run"


def _attachment_dict(archive_name, source_path=None, inline_content=None, required=True, **extra):
    row = {
        "archive_name": archive_name,
        "source_path": source_path or "",
        "inline_content": inline_content,
        "required": required,
        "freshness": extra.get("freshness") or _attachment_freshness_for_path(source_path),
        "scope": extra.get("scope", ""),
        "run_id": extra.get("run_id", ""),
        "source_kind": extra.get("source_kind", ""),
        "missing_reason": extra.get("missing_reason", ""),
        "correlation_note_role": extra.get("correlation_note_role", ""),
    }
    return row


def _manifest_has_archive_name(manifest, archive_name):
    name = _safe_str(archive_name)
    if not name:
        return False
    for row in manifest.get("attachments") or []:
        if isinstance(row, dict) and _safe_str(row.get("archive_name")) == name:
            return True
    return False


def _find_attachment_by_archive_name(manifest, archive_name):
    name = _safe_str(archive_name)
    if not name or not isinstance(manifest, dict):
        return None
    for row in manifest.get("attachments") or []:
        if isinstance(row, dict) and _safe_str(row.get("archive_name")) == name:
            return row
    return None


def add_required_attachment(manifest, archive_name, source_path, scope, run_id):
    """
    Attach file if present; otherwise append missing_required_evidence.
    scope and run_id are plain strings for manifest rows.
    """
    if not isinstance(manifest, dict):
        return
    name = _safe_str(archive_name)
    attachments = manifest.setdefault("attachments", [])
    missing = manifest.setdefault("missing_required_evidence", [])
    path = _safe_str(source_path)
    existing = _find_attachment_by_archive_name(manifest, name)
    if existing is not None:
        existing["required"] = True
        if scope:
            existing["scope"] = scope
        if run_id:
            existing["run_id"] = run_id
        return
    if path and os.path.isfile(path):
        attachments.append(
            _attachment_dict(
                name,
                source_path=path,
                required=True,
                scope=scope,
                run_id=run_id,
                source_kind="file",
            )
        )
        return
    expected_path = path
    missing.append(
        {
            "archive_name": name,
            "expected_path": expected_path,
            "expected_pattern": "",
            "reason_code": "missing_required_file",
        }
    )


def add_optional_attachment(manifest, archive_name, source_path, scope, run_id):
    """Attach when present; never records missing_required_evidence."""
    if not isinstance(manifest, dict):
        return
    name = _safe_str(archive_name)
    if _manifest_has_archive_name(manifest, name):
        return
    path = _safe_str(source_path)
    if not path or not os.path.isfile(path):
        return
    manifest.setdefault("attachments", []).append(
        _attachment_dict(
            name,
            source_path=path,
            required=False,
            scope=scope,
            run_id=run_id,
            source_kind="file",
        )
    )


def add_optional_inline_attachment(manifest, archive_name, inline_content, scope, run_id):
    """Attach caller-provided inline evidence; never records missing evidence."""
    if not isinstance(manifest, dict):
        return
    name = _safe_str(archive_name)
    if not name or _manifest_has_archive_name(manifest, name):
        return
    manifest.setdefault("attachments", []).append(
        _attachment_dict(
            name,
            inline_content=inline_content,
            required=False,
            scope=scope,
            run_id=run_id,
            source_kind="prefetched_inline",
        )
    )


def _phase_c_rules_apply(request, diagnostics_state):
    diag = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    failed = _safe_str(request.get("failed_phase")).strip().upper()
    err = _safe_str(request.get("error_code"))
    if failed == "C":
        return True
    if err.startswith("PHASE_C_"):
        return True
    if diag.get("last_phase_c_ok") is False:
        return True
    return False


def _try_shadow_lock_redacted(lab_root):
    try:
        from lab_lock import read_lab_lock_diagnostic_metadata
    except Exception:
        return None
    try:
        stub = read_lab_lock_diagnostic_metadata(lab_root)
        if isinstance(stub, dict) and stub:
            return stub
    except Exception:
        pass
    return None


PHASE_F_BC_CORRELATION_ARCHIVE_NAME = "phase_f_bc_correlation_note.txt"


def collect_shadow_evidence_index_referenced_paths(index_path):
    """
    Parse shadow_evidence_index JSON (artifact_files[] with path/exists).

    Algorithm: read JSON dict; prefer list ``artifact_files``; each item may be
    dict with ``path`` (absolute or relative). Skip missing paths, __MISSING__,
    exists=False, non-files. Returns [(archive_basename, abs_path), ...].
    """
    out = []
    path = _safe_str(index_path)
    if not path or not os.path.isfile(path):
        return out
    payload = _read_json_dict(path)
    if not isinstance(payload, dict):
        return out
    rows = payload.get("artifact_files")
    if not isinstance(rows, list):
        rows = payload.get("files")
    if not isinstance(rows, list):
        return out
    base_dir = os.path.dirname(os.path.abspath(path))
    for item in rows:
        if not isinstance(item, dict):
            continue
        if item.get("exists") is False:
            continue
        raw = _safe_str(item.get("path", "")).strip()
        if not raw or raw == "__MISSING__":
            continue
        if not os.path.isabs(raw):
            cand = os.path.normpath(os.path.join(base_dir, raw))
        else:
            cand = raw
        if not os.path.isfile(cand):
            continue
        out.append((os.path.basename(cand), cand))
    return out


def _normalize_prefetched_tuples(raw):
    """Normalize caller-supplied (archive_name, path_or_inline) pairs."""
    out = []
    if not raw:
        return out
    try:
        iterable = list(raw)
    except Exception:
        return out
    for item in iterable:
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            out.append((_safe_str(item[0]), item[1]))
        elif isinstance(item, dict):
            a = item.get("archive_name")
            p = item.get("source_path")
            if a and p:
                out.append((_safe_str(a), p))
            elif a and "inline_content" in item:
                out.append((_safe_str(a), item.get("inline_content")))
    return out


def _layer1_debug_effective_for_request(request):
    """Best-effort gate: attach Layer1 debug only when current/effective."""
    req = request if isinstance(request, dict) else {}
    lab_root = _safe_str(req.get("lab_root"))
    if not lab_root:
        return False
    reports_dir = os.path.join(lab_root, "reports")
    diag = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json")) or {}
    try:
        from MediCafe.layer1_readiness_model import build_layer1_readiness_model
        from MediCafe.layer1_readiness_model import STATUS_READY_TO_EVALUATE
        from MediCafe.layer1_readiness_model import STATUS_EVALUATED_BLOCKED
        from MediCafe.layer1_readiness_model import STATUS_EVALUATED_OK
    except Exception:
        return False
    anchor = _safe_str(req.get("anchor_run_id"))
    pack_context = {"anchor_run_id": anchor, "pack_scope": "completed_run"} if anchor else {}
    model = build_layer1_readiness_model(lab_root, reports_dir, diag, pack_context=pack_context)
    if not isinstance(model, dict):
        return False
    if bool(model.get("historical_layer1_debug_only")):
        return False
    return _safe_str(model.get("layer1_readiness_status")) in (
        STATUS_READY_TO_EVALUATE, STATUS_EVALUATED_BLOCKED, STATUS_EVALUATED_OK
    )


def _merge_prefetched_into_manifest(manifest, request, scope_tag, run_id_token):
    rid = _safe_str(run_id_token)
    layer1_effective = None
    for archive_name, pth in _normalize_prefetched_tuples(request.get("_prefetched_evidence_tuples")):
        if not _manifest_has_archive_name(manifest, archive_name):
            path = _safe_str(pth)
            if path and os.path.isfile(path):
                scoped = _safe_str(scope_tag)
                if archive_name.startswith("layer1_join_debug_"):
                    scoped = "historical_layer1_context"
                    if rid and (
                            archive_name.startswith("layer1_join_debug_pack_{0}".format(rid)) or
                            archive_name.startswith("layer1_join_debug_summary_{0}".format(rid)) or
                            archive_name.startswith("layer1_join_debug_samples_{0}".format(rid))):
                        scoped = "current_layer1_context"
                        if layer1_effective is None:
                            layer1_effective = _layer1_debug_effective_for_request(request)
                        if not layer1_effective:
                            continue
                    else:
                        continue
                add_optional_attachment(manifest, archive_name, path, scoped, rid)
            elif pth is not None:
                add_optional_inline_attachment(manifest, archive_name, pth, scope_tag, rid)


def _apply_prefetched_phase_letter_evidence(manifest, lab_root, lab, request):
    """phase_b_evidence / phase_c_evidence / phase_d_evidence / phase_e_evidence (manual menu sends)."""
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    _merge_prefetched_into_manifest(
        manifest, request, "manual_phase_letter_prefetch", request.get("anchor_run_id")
    )


def _apply_config_write_contention_bundle(manifest, lab_root, lab, request):
    """config_write_contention: optional lab state plus telemetry files from caller."""
    paths = lab.get("paths") or {}
    add_optional_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "config_write_context",
        "",
    )
    add_optional_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "config_write_context",
        "",
    )
    _merge_prefetched_into_manifest(manifest, request, "config_write_telemetry", "")


def _apply_error_report_lab_context(manifest, lab_root, lab, request):
    """Generic error_report: optional lab diagnostics when lab_root is valid."""
    paths = lab.get("paths") or {}
    add_optional_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "error_report_context",
        "",
    )
    add_optional_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "error_report_context",
        "",
    )


def _apply_orchestrator_failure_bundle(manifest, lab_root, lab, request):
    """Shadow orchestrator auto-report: lab context plus structured result/payload."""
    paths = lab.get("paths") or {}
    add_optional_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "orchestrator_failure",
        "",
    )
    add_optional_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "orchestrator_failure",
        "",
    )
    tracker = os.path.join(_safe_str(lab_root), "cloud_health_tracker.json")
    if os.path.isfile(tracker):
        add_optional_attachment(
            manifest,
            "cloud_health_tracker.json",
            tracker,
            "orchestrator_failure",
            "",
        )
    res = request.get("_orchestrator_result")
    if isinstance(res, dict) and res:
        if not _manifest_has_archive_name(manifest, "orchestrator_result.json"):
            manifest["attachments"].append(
                _attachment_dict(
                    "orchestrator_result.json",
                    inline_content=res,
                    required=True,
                    scope="orchestrator_failure",
                    source_kind="orchestrator_result",
                )
            )
    pay = request.get("_orchestrator_payload")
    if isinstance(pay, dict) and pay:
        if not _manifest_has_archive_name(manifest, "orchestrator_payload.json"):
            manifest["attachments"].append(
                _attachment_dict(
                    "orchestrator_payload.json",
                    inline_content=pay,
                    required=False,
                    scope="orchestrator_failure",
                    source_kind="orchestrator_payload",
                )
            )
    dp = _safe_str(request.get("_orchestrator_diagnostic_path"))
    if dp and os.path.isfile(dp):
        add_optional_attachment(
            manifest,
            os.path.basename(dp),
            dp,
            "orchestrator_failure",
            "",
        )
    rp = _safe_str(request.get("_orchestrator_report_path"))
    if rp and os.path.isfile(rp):
        add_optional_attachment(
            manifest,
            os.path.basename(rp),
            rp,
            "orchestrator_failure",
            "",
        )


def _reports_dir(lab_root):
    return os.path.join(_safe_str(lab_root), "reports")


def _apply_dat_qa_full_block_contract(manifest, lab_root, request):
    """Phase D DAT QA full-block required artifacts (anchor_run_id)."""
    rid = _safe_str(request.get("anchor_run_id"))
    if not rid:
        return
    rep = _reports_dir(lab_root)
    specs = [
        ("artifact_triage_pack_{0}.txt".format(rid), os.path.join(rep, "artifact_triage_pack_{0}.txt".format(rid))),
        ("qa_canonical_summary_{0}.json".format(rid), os.path.join(rep, "qa_canonical_summary_{0}.json".format(rid))),
        ("qa_reject_samples_{0}.jsonl".format(rid), os.path.join(rep, "qa_reject_samples_{0}.jsonl".format(rid))),
        ("layer1_join_debug_summary_{0}.json".format(rid), os.path.join(rep, "layer1_join_debug_summary_{0}.json".format(rid))),
        ("layer1_join_debug_pack_{0}.txt".format(rid), os.path.join(rep, "layer1_join_debug_pack_{0}.txt".format(rid))),
        ("run_artifact_index_{0}.txt".format(rid), os.path.join(rep, "run_artifact_index_{0}.txt".format(rid))),
    ]
    for archive_name, fullpath in specs:
        add_required_attachment(manifest, archive_name, fullpath, "dat_qa_full_block", rid)
    oc = manifest.setdefault("operator_contract", {})
    oc["operator_manual_review_required"] = False
    oc["reply_required"] = False
    if _safe_str(request.get("follow_recommendation_now")):
        oc["follow_recommendation_now"] = _safe_str(request.get("follow_recommendation_now"))
    rec_lines = [
        "recommended_action_kind={0}".format(_safe_str(request.get("recommendation_action_kind"))),
        "follow_recommendation_now={0}".format(_safe_str(request.get("follow_recommendation_now"))),
        "operator_manual_review_required={0}".format(request.get("operator_manual_review_required")),
        "reply_required={0}".format(request.get("reply_required")),
    ]
    manifest["attachments"].append(
        _attachment_dict(
            "dat_qa_full_block_recommendation_lines.txt",
            inline_content="\n".join(rec_lines) + "\n",
            required=True,
            scope="dat_qa_full_block",
            source_kind="recommendation_note",
        )
    )


def _phase_f_evidence_correlation_body(request, state, cursor, summary_info_phase_c):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    fp = _safe_str(request.get("failed_phase")).strip().upper()
    shadow_run_id = _safe_str(request.get("anchor_run_id"))
    phase_b_run = ""
    phase_c_run = ""
    try:
        prids = st.get("last_shadow_pipeline_phase_run_ids")
        if isinstance(prids, dict):
            phase_b_run = _safe_str(prids.get("B", ""))
            phase_c_run = _safe_str(prids.get("C", ""))
    except Exception:
        phase_b_run = ""
        phase_c_run = ""
    if not phase_c_run:
        phase_c_run = _safe_str(st.get("last_phase_c_run_id"))
    phase_c_attach = "no"
    sm = summary_info_phase_c if isinstance(summary_info_phase_c, dict) else {}
    if sm.get("exists"):
        phase_c_attach = "yes"
    manifest_sha = ""
    if isinstance(sm.get("summary"), dict):
        manifest_sha = _safe_str(sm["summary"].get("manifest_sha256"))
    lines = [
        "phase_f_evidence_correlation",
        "shadow_run_id={0}".format(shadow_run_id or "-"),
        "failed_phase={0}".format(fp or "-"),
        "phase_b_manifest_run_id={0}".format(phase_b_run or "-"),
        "phase_c_run_id={0}".format(phase_c_run or "-"),
        "phase_c_failure_summary_attached={0}".format(phase_c_attach),
        "manifest_sha256={0}".format(manifest_sha or "-"),
    ]
    if shadow_run_id and phase_c_run and shadow_run_id != phase_c_run:
        lines.append(
            "note=Phase F run id differs from Phase C run id; ingest summary may belong to a parallel pipeline attempt."
        )
    return "\n".join(lines) + "\n"


def _apply_phase_f_evidence_bundle(manifest, lab_root, lab, request, state, cursor):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    rep = _reports_dir(lab_root)
    anchor = _safe_str(request.get("anchor_run_id"))
    jpath = _safe_str(request.get("phase_f_report_json_path"))
    tpath = _safe_str(request.get("phase_f_report_txt_path"))
    ipath = _safe_str(request.get("phase_f_evidence_index_path"))
    if not jpath and anchor:
        cand = os.path.join(rep, "shadow_run_report_{0}.json".format(anchor))
        if os.path.isfile(cand):
            jpath = cand
    if not tpath and anchor:
        cand = os.path.join(rep, "shadow_run_report_{0}.txt".format(anchor))
        if os.path.isfile(cand):
            tpath = cand
    if not ipath and anchor:
        cand = os.path.join(rep, "shadow_evidence_index_{0}.json".format(anchor))
        if os.path.isfile(cand):
            ipath = cand
    add_required_attachment(manifest, "shadow_run_report.json", jpath, "phase_f_report", anchor)
    add_required_attachment(manifest, "shadow_run_report.txt", tpath, "phase_f_report", anchor)
    add_required_attachment(manifest, "shadow_evidence_index.json", ipath, "phase_f_index", anchor)
    for archive_name, src in collect_shadow_evidence_index_referenced_paths(ipath):
        add_optional_attachment(manifest, archive_name, src, "phase_f_index_ref", anchor)
    summary_info_pc = resolve_phase_c_summary(lab_root, state, cursor)
    corr = _phase_f_evidence_correlation_body(request, state, cursor, summary_info_pc)
    if not _manifest_has_archive_name(manifest, PHASE_F_BC_CORRELATION_ARCHIVE_NAME):
        manifest["attachments"].append(
            _attachment_dict(
                PHASE_F_BC_CORRELATION_ARCHIVE_NAME,
                inline_content=corr,
                required=True,
                scope="phase_f_bc",
                source_kind="correlation_note",
                correlation_note_role="phase_f_bc",
            )
        )
    _merge_prefetched_into_manifest(manifest, request, "phase_f_manual_prefetch", request.get("anchor_run_id"))


def _apply_cloud_health_escalation_bundle(manifest, lab_root, lab, request):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    diag = request.get("_cloud_health_diagnostics")
    diag_arg = diag if isinstance(diag, dict) else None
    try:
        from MediCafe.cloud_readiness import collect_cloud_health_phase_evidence_tuples

        for archive_name, pth in collect_cloud_health_phase_evidence_tuples(lab_root, diag_arg):
            add_optional_attachment(
                manifest,
                archive_name,
                pth,
                "cloud_health_phase",
                "",
            )
    except Exception:
        pass
    manifest.setdefault("scope", {})["coherence_status"] = "review_required"


def _apply_system_health_pack_bundle(manifest, lab_root, lab, request):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    note = _safe_str(request.get("evidence_snapshot_mixed_note"))
    if note:
        manifest["scope"]["coherence_status"] = "review_required"
        manifest["validation"]["warnings"].append("mixed_snapshot:{0}".format(note))


def _apply_run_evidence_bundle_base(manifest, lab_root, lab, request):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )


def _apply_pipeline_failure_report_bundle(manifest, lab_root, lab, request):
    """Pipeline failure report: lab state plus caller-produced report attachments."""
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    _merge_prefetched_into_manifest(
        manifest,
        request,
        "pipeline_failure_prefetch",
        request.get("anchor_run_id"),
    )


def _apply_phase_c_failure_contract(manifest, lab_root, lab, request, state, cursor):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    summary_info = resolve_phase_c_summary(lab_root, st, cr)
    rid = summary_info.get("run_id") or ""
    if rid:
        if summary_info.get("exists"):
            add_required_attachment(
                manifest,
                summary_info.get("expected_archive_name") or "",
                summary_info.get("expected_path") or "",
                "phase_c_run",
                rid,
            )
        else:
            manifest.setdefault("missing_required_evidence", []).append(
                {
                    "archive_name": summary_info.get("expected_archive_name") or "",
                    "expected_path": summary_info.get("expected_path") or "",
                    "expected_pattern": "",
                    "reason_code": "phase_c_summary_missing_strict",
                }
            )
    recovery_path = _safe_str(
        st.get("last_phase_c_shadow_recovery_report_path")
        or cr.get("last_phase_c_shadow_recovery_report_path")
    )
    if recovery_path and os.path.isfile(recovery_path):
        add_optional_attachment(
            manifest,
            os.path.basename(recovery_path),
            recovery_path,
            "phase_c_shadow_recovery",
            _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id")),
        )
        if recovery_path.lower().endswith(".json"):
            recovery_txt = recovery_path[:-5] + ".txt"
            if os.path.isfile(recovery_txt) and not _manifest_has_archive_name(
                manifest, os.path.basename(recovery_txt)
            ):
                add_optional_attachment(
                    manifest,
                    os.path.basename(recovery_txt),
                    recovery_txt,
                    "phase_c_shadow_recovery",
                    _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id")),
                )
    exec_handoff_path = _safe_str(
        st.get("last_phase_c_execution_handoff_report_path")
        or cr.get("last_phase_c_execution_handoff_report_path")
    )
    anchor_rid = _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id"))
    if exec_handoff_path and os.path.isfile(exec_handoff_path):
        add_optional_attachment(
            manifest,
            os.path.basename(exec_handoff_path),
            exec_handoff_path,
            "phase_c_execution_handoff",
            anchor_rid,
        )
        if exec_handoff_path.endswith(".json"):
            txt_handoff = exec_handoff_path[:-5] + ".txt"
            if os.path.isfile(txt_handoff):
                add_optional_attachment(
                    manifest,
                    os.path.basename(txt_handoff),
                    txt_handoff,
                    "phase_c_execution_handoff",
                    anchor_rid,
                )
    bootstrap_path = os.path.join(lab_root, "reports", "ingest_from_manifest_bootstrap_latest.json")
    if os.path.isfile(bootstrap_path) and not _manifest_has_archive_name(
        manifest, "ingest_from_manifest_bootstrap_latest.json"
    ):
        add_optional_attachment(
            manifest,
            "ingest_from_manifest_bootstrap_latest.json",
            bootstrap_path,
            "phase_c_ingest_bootstrap",
            anchor_rid,
        )
    lock_stub = _try_shadow_lock_redacted(lab_root)
    if lock_stub is not None and not _manifest_has_archive_name(manifest, "shadow_lock_redacted.json"):
        manifest.setdefault("attachments", []).append(
            _attachment_dict(
                "shadow_lock_redacted.json",
                inline_content=lock_stub,
                required=False,
                scope="lab_lock",
                source_kind="lab_lock_redacted",
            )
        )
    self_heal_path = os.path.join(lab_root, "reports", "phase_c_self_heal_status_latest.txt")
    if os.path.isfile(self_heal_path) and not _manifest_has_archive_name(manifest, "phase_c_self_heal_status_latest.txt"):
        add_optional_attachment(
            manifest,
            "phase_c_self_heal_status_latest.txt",
            self_heal_path,
            "phase_c_self_heal_status",
            _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id")),
        )
    stderr_tail_path = os.path.join(lab_root, "reports", "phase_c_ingest_stderr_tail_latest.txt")
    if os.path.isfile(stderr_tail_path) and not _manifest_has_archive_name(
        manifest, "phase_c_ingest_stderr_tail_latest.txt"
    ):
        add_optional_attachment(
            manifest,
            "phase_c_ingest_stderr_tail_latest.txt",
            stderr_tail_path,
            "phase_c_ingest_stderr",
            anchor_rid,
        )
    ingest_diag_path = os.path.join(lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json")
    if os.path.isfile(ingest_diag_path) and not _manifest_has_archive_name(
        manifest, "ingest_from_manifest_diagnostics_latest.json"
    ):
        add_optional_attachment(
            manifest,
            "ingest_from_manifest_diagnostics_latest.json",
            ingest_diag_path,
            "phase_c_ingest_from_manifest_diag",
            anchor_rid,
        )
    try:
        from MediCafe.phase_c_db_health_probe import write_phase_c_db_health_probe_latest

        probe_path = write_phase_c_db_health_probe_latest(lab_root, st)
        if probe_path and os.path.isfile(probe_path) and not _manifest_has_archive_name(
            manifest, "phase_c_db_health_probe_latest.json"
        ):
            add_optional_attachment(
                manifest,
                "phase_c_db_health_probe_latest.json",
                probe_path,
                "phase_c_db_health_probe",
                anchor_rid,
            )
    except Exception:
        pass
    if not _manifest_has_archive_name(manifest, PHASE_C_CORRELATION_ARCHIVE_NAME):
        corr_text = _phase_c_correlation_body(request, st, cr, summary_info)
        manifest["attachments"].append(
            _attachment_dict(
                PHASE_C_CORRELATION_ARCHIVE_NAME,
                inline_content=corr_text,
                required=True,
                scope="phase_c_bundle",
                source_kind="correlation_note",
                correlation_note_role="phase_c_bundle",
            )
        )
    coh = _compute_coherence_status(st, cr, summary_info)
    prev = _safe_str(manifest.get("scope", {}).get("coherence_status"))
    if coh == "review_required" or prev == "review_required":
        manifest.setdefault("scope", {})["coherence_status"] = "review_required"
    else:
        manifest.setdefault("scope", {})["coherence_status"] = coh


def _merge_operator_contract_from_request(manifest, request):
    oc = manifest.setdefault("operator_contract", {})
    if request.get("operator_manual_review_required"):
        oc["operator_manual_review_required"] = True
    if request.get("reply_required"):
        oc["reply_required"] = True
    fn = _safe_str(request.get("follow_recommendation_now"))
    if fn:
        oc["follow_recommendation_now"] = fn


def _finalize_manifest_validation(manifest):
    missing = manifest.get("missing_required_evidence") or []
    invalid_lab = any(
        isinstance(m, dict) and m.get("reason_code") == "invalid_lab_root" for m in missing
    )
    named_missing = any(
        isinstance(m, dict) and _safe_str(m.get("archive_name")) for m in missing
    )
    if invalid_lab:
        manifest.setdefault("validation", {})["attachment_contract_status"] = "fail"
        manifest["validation"]["ok_to_send"] = False
    elif named_missing:
        manifest.setdefault("validation", {})["attachment_contract_status"] = "degraded"
    else:
        manifest.setdefault("validation", {})["attachment_contract_status"] = "pass"


def resolve_evidence_manifest(request):
    """
    Resolve attachments and validation for an EvidenceRequest.

    Dispatch (see architecture plan A.4): DAT QA full-block first, then
    bundle_kind rules, then Phase C failure union when applicable.
    """
    req = request if isinstance(request, dict) else {}
    lab_root = _safe_str(req.get("lab_root"))
    req_public = {}
    for k, v in req.items():
        if not k.startswith("_"):
            try:
                req_public[k] = v
            except Exception:
                pass
    lab = read_lab_state(lab_root)
    state = lab.get("diagnostics_state")
    cursor = lab.get("run_cursor")
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}

    manifest = {
        "schema_version": EVIDENCE_MANIFEST_SCHEMA_VERSION,
        "request": dict(req_public),
        "extra_meta": {},
        "attachments": [],
        "missing_required_evidence": [],
        "scope": {
            "bundle_kind": _safe_str(req.get("bundle_kind")),
            "scope_kind": _safe_str(req.get("bundle_kind")),
            "anchor_run_id": _safe_str(req.get("anchor_run_id")),
            "artifact_run_id": _safe_str(req.get("active_run_id")),
            "phase_artifact_scope": "run_aligned",
            "coherence_status": "ready",
        },
        "operator_contract": {
            "operator_manual_review_required": False,
            "reply_required": False,
            "follow_recommendation_now": "",
        },
        "validation": {
            "ok_to_send": True,
            "warnings": [],
            "errors": [],
            "attachment_contract_status": "",
        },
    }

    if not lab_root or not os.path.isdir(lab_root):
        manifest["missing_required_evidence"].append(
            {
                "archive_name": "",
                "expected_path": lab_root,
                "expected_pattern": "",
                "reason_code": "invalid_lab_root",
            }
        )
        manifest["validation"]["attachment_contract_status"] = "fail"
        manifest["validation"]["ok_to_send"] = False
        return manifest

    rec_kind = _safe_str(req.get("recommendation_action_kind"))
    if rec_kind == "review_dat_qa_full_block":
        _apply_dat_qa_full_block_contract(manifest, lab_root, req)

    bk = _safe_str(req.get("bundle_kind"))
    if bk in ("phase_b_evidence", "phase_c_evidence", "phase_d_evidence", "phase_e_evidence"):
        _apply_prefetched_phase_letter_evidence(manifest, lab_root, lab, req)
    elif bk == "config_write_contention":
        _apply_config_write_contention_bundle(manifest, lab_root, lab, req)
    elif bk == "error_report":
        _apply_error_report_lab_context(manifest, lab_root, lab, req)
    elif bk == "orchestrator_failure":
        _apply_orchestrator_failure_bundle(manifest, lab_root, lab, req)
    elif bk == "phase_f_evidence":
        _apply_phase_f_evidence_bundle(manifest, lab_root, lab, req, st, cr)
    elif bk == "cloud_health_escalation":
        _apply_cloud_health_escalation_bundle(manifest, lab_root, lab, req)
    elif bk == "system_health_pack":
        _apply_system_health_pack_bundle(manifest, lab_root, lab, req)
    elif bk == "run_evidence_bundle":
        _apply_run_evidence_bundle_base(manifest, lab_root, lab, req)
    elif bk == "pipeline_failure_report":
        _apply_pipeline_failure_report_bundle(manifest, lab_root, lab, req)
    elif bk == "phase_c_unresolvable":
        _apply_pipeline_failure_report_bundle(manifest, lab_root, lab, req)

    if _phase_c_rules_apply(req, st):
        _apply_phase_c_failure_contract(manifest, lab_root, lab, req, st, cr)

    _merge_operator_contract_from_request(manifest, req)

    _finalize_manifest_validation(manifest)
    return manifest


def manifest_to_extra_files(manifest):
    """Convert manifest attachment dicts to (archive_name, path_or_unicode) tuples."""
    out = []
    if not isinstance(manifest, dict):
        return out
    for row in manifest.get("attachments") or []:
        if not isinstance(row, dict):
            continue
        name = _safe_str(row.get("archive_name"))
        if not name:
            continue
        path = _safe_str(row.get("source_path"))
        inline = row.get("inline_content")
        if path and os.path.isfile(path):
            out.append((name, path))
        elif isinstance(inline, dict):
            out.append((name, inline))
        elif inline is not None:
            if isinstance(inline, bytes):
                try:
                    inline = inline.decode("utf-8")
                except Exception:
                    inline = ""
            out.append((name, inline))
    return out


def manifest_to_extra_meta(manifest):
    """
    Flatten manifest fields for support bundle meta.json.

    Includes attachment_contract_status, coherence_status, missing_required_evidence,
    evidence_manifest_schema_version, and optional embedded evidence_request.
    """
    out = {}
    if not isinstance(manifest, dict):
        return out
    req = manifest.get("request")
    if isinstance(req, dict):
        out["evidence_request"] = dict(req)
        if req.get("bundle_kind"):
            out["bundle_kind"] = _safe_str(req.get("bundle_kind"))
    out["evidence_manifest_schema_version"] = manifest.get("schema_version")
    missing = manifest.get("missing_required_evidence")
    if isinstance(missing, list):
        out["missing_required_evidence"] = list(missing)
    else:
        out["missing_required_evidence"] = []
    scope = manifest.get("scope")
    coh = "ready"
    if isinstance(scope, dict):
        coh = _safe_str(scope.get("coherence_status")) or "ready"
    out["coherence_status"] = coh
    val = manifest.get("validation")
    acs = "pass"
    if isinstance(val, dict) and val.get("attachment_contract_status"):
        acs = _safe_str(val.get("attachment_contract_status"))
    elif out["missing_required_evidence"]:
        acs = "degraded"
    out["attachment_contract_status"] = acs
    oc = manifest.get("operator_contract")
    if isinstance(oc, dict):
        out["operator_contract"] = dict(oc)
    sc = manifest.get("scope")
    if isinstance(sc, dict):
        out["evidence_scope"] = dict(sc)
    return out


def merge_extra_files(primary, secondary):
    """
    Concatenate primary then secondary, dedupe by archive_name keeping first.

    Manifest-derived tuples should be passed as primary so contract paths win.
    """
    seen = set()
    out = []
    for seq in (primary, secondary):
        for item in seq or []:
            try:
                name = _safe_str(item[0])
            except Exception:
                continue
            if not name or name in seen:
                continue
            seen.add(name)
            out.append((item[0], item[1]))
    return out


def try_resolve_error_report_manifest(send_source="generic_error_bundle"):
    """
    Resolve an error_report manifest when MEDICAFE_LAB_DIR points at a lab tree.

    Returns None when lab is unknown or resolution fails (callers send without manifest).
    """
    lab_root = _safe_str(os.environ.get("MEDICAFE_LAB_DIR", "")).strip()
    if not lab_root or not os.path.isdir(lab_root):
        return None
    try:
        req = build_evidence_request(
            "error_report",
            _safe_str(send_source) or "generic_error_bundle",
            lab_root,
        )
        return resolve_evidence_manifest(req)
    except Exception:
        return None


def manifest_enqueue_snapshot(manifest):
    """
    Trim resolved manifest for support_send_jobs JSON (no large inline bodies).

    Preserves request/scope/validation/missing entries; summarizes attachments.
    """
    if not isinstance(manifest, dict):
        return {}
    atts = []
    for row in manifest.get("attachments") or []:
        if not isinstance(row, dict):
            continue
        entry = {
            "archive_name": _safe_str(row.get("archive_name")),
            "required": bool(row.get("required")),
            "freshness": _safe_str(row.get("freshness")),
            "scope": _safe_str(row.get("scope")),
            "source_kind": _safe_str(row.get("source_kind")),
        }
        path = _safe_str(row.get("source_path"))
        if path:
            entry["source_path_tail"] = os.path.basename(path)
        inline = row.get("inline_content")
        if inline is not None:
            entry["has_inline_content"] = True
            if isinstance(inline, str):
                entry["inline_len"] = len(inline)
            elif isinstance(inline, dict):
                entry["inline_len"] = len(json.dumps(inline, ensure_ascii=True))
        atts.append(entry)
    req = manifest.get("request")
    scope = manifest.get("scope")
    val = manifest.get("validation")
    oc = manifest.get("operator_contract")
    miss = manifest.get("missing_required_evidence")
    return {
        "schema_version": manifest.get("schema_version"),
        "request": dict(req) if isinstance(req, dict) else {},
        "scope": dict(scope) if isinstance(scope, dict) else {},
        "validation": dict(val) if isinstance(val, dict) else {},
        "missing_required_evidence": list(miss) if isinstance(miss, list) else [],
        "operator_contract": dict(oc) if isinstance(oc, dict) else {},
        "attachments_summary": atts,
    }


def operator_evidence_contract_preview_lines(lab_root, recommendation):
    """
    Compact resolver preview lines for operator runbooks (system health / run evidence).
    """
    lines = []
    root = _safe_str(lab_root).strip()
    if not root or not os.path.isdir(root):
        return lines
    rec = recommendation if isinstance(recommendation, dict) else {}
    rrk = _safe_str(rec.get("recommended_report_kind"))
    if rrk == "system_health_pack":
        bk = "system_health_pack"
    else:
        bk = "run_evidence_bundle"
    anchor = _safe_str(rec.get("recommendation_anchor_run_id"))
    live = _safe_str(rec.get("recommendation_live_run_id")) or anchor
    try:
        req = build_evidence_request(
            bk,
            "operator_ui_preview",
            root,
            anchor_run_id=anchor,
            active_run_id=live,
            recommendation_action_kind=_safe_str(rec.get("recommended_action_kind")),
        )
        man = resolve_evidence_manifest(req)
    except Exception:
        return lines
    val = man.get("validation") if isinstance(man.get("validation"), dict) else {}
    acs = _safe_str(val.get("attachment_contract_status")) or "-"
    scope = man.get("scope") if isinstance(man.get("scope"), dict) else {}
    coh = _safe_str(scope.get("coherence_status")) or "-"
    miss = man.get("missing_required_evidence")
    miss_n = len(miss) if isinstance(miss, list) else 0
    lines.append("Evidence contract preview (resolver; bundle_kind={0}):".format(bk))
    lines.append(" - attachment_contract_status={0}".format(acs))
    lines.append(" - coherence_status={0}".format(coh))
    lines.append(" - missing_required_evidence_count={0}".format(miss_n))
    return lines
