# -*- coding: utf-8 -*-
"""Human-readable Phase C self-heal / circuit status for bundles and System Health Pack."""
from __future__ import print_function

import hashlib
import json
import os


def _read(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _file_sha256_prefix16(path):
    if not path or not os.path.isfile(path):
        return ""
    try:
        with open(path, "rb") as handle:
            h = hashlib.sha256()
            block = handle.read(65536)
            while block:
                h.update(block)
                block = handle.read(65536)
        return h.hexdigest()[:16]
    except Exception:
        return ""


def format_phase_c_self_heal_lines(lab_root):
    """Return lines for System Health Pack (no trailing blank required)."""
    lab_root = str(lab_root or "").strip()
    if not lab_root:
        return [" - status=unavailable", " - detail=missing_lab_root"]
    st = _read(os.path.join(lab_root, "diagnostics_state.json"))
    cr = _read(os.path.join(lab_root, "run_cursor.json"))
    circuit = bool(st.get("phase_c_circuit_open") or cr.get("phase_c_circuit_open"))
    try:
        fc = int(st.get("phase_c_self_heal_failure_count_for_b_sha", 0) or 0)
    except Exception:
        fc = 0
    tracked = str(st.get("phase_c_self_heal_tracked_b_sha") or cr.get("phase_c_self_heal_tracked_b_sha") or "").strip()
    b_sha = str(st.get("last_manifest_sha256") or cr.get("last_manifest_sha256") or "").strip()
    c_sha = str(st.get("last_ingest_manifest_sha256") or cr.get("last_ingest_manifest_sha256") or "").strip()
    lines = [
        " - circuit_open={0}".format("yes" if circuit else "no"),
        " - failure_count_for_b_sha={0}".format(fc),
        " - tracked_b_sha_prefix={0}".format(tracked[:16] + ("..." if len(tracked) > 16 else "")),
        " - last_manifest_sha256_prefix={0}".format(b_sha[:16] + ("..." if len(b_sha) > 16 else "")),
        " - last_ingest_manifest_sha256_prefix={0}".format(c_sha[:16] + ("..." if len(c_sha) > 16 else "")),
    ]
    if cr.get("last_discovery_skipped_due_to_phase_c_circuit"):
        lines.append(" - discovery_skipped_due_to_circuit=yes")
    pend = str(cr.get("last_discovery_pending_manifest_sha256") or "").strip()
    if pend:
        lines.append(" - pending_manifest_sha256_prefix={0}".format(pend[:16] + ("..." if len(pend) > 16 else "")))
    spath = str(st.get("last_phase_c_subprocess_script_path") or cr.get("last_phase_c_subprocess_script_path") or "").strip()
    lines.append(" - phase_c_subprocess_script_path={0}".format(spath[:120] + ("..." if len(spath) > 120 else "")))
    rp = str(st.get("last_phase_c_subprocess_script_sha256_prefix") or cr.get("last_phase_c_subprocess_script_sha256_prefix") or "").strip()
    lines.append(" - phase_c_subprocess_script_sha256_prefix_stored={0}".format(rp[:16] + ("..." if len(rp) > 16 else "")))
    try:
        rsz = int(st.get("last_phase_c_subprocess_script_size_bytes") or cr.get("last_phase_c_subprocess_script_size_bytes") or 0)
    except Exception:
        rsz = 0
    lines.append(" - phase_c_subprocess_script_size_bytes_stored={0}".format(rsz))
    ondisk = _file_sha256_prefix16(spath)
    lines.append(" - phase_c_subprocess_script_sha256_prefix_on_disk={0}".format(ondisk[:16] + ("..." if len(ondisk) > 16 else "")))
    if not spath:
        drift_s = "unknown"
    elif not ondisk:
        drift_s = "unknown"
    elif rp and (ondisk != rp):
        drift_s = "yes"
    elif rp:
        drift_s = "no"
    else:
        drift_s = "unknown"
    lines.append(" - phase_c_subprocess_script_drift={0}".format(drift_s))
    dp = str(st.get("last_ingest_from_manifest_diag_path") or cr.get("last_ingest_from_manifest_diag_path") or "").strip()
    lines.append(" - last_ingest_from_manifest_diag_path={0}".format(dp[:120] + ("..." if len(dp) > 120 else "")))
    du = str(st.get("last_ingest_from_manifest_diag_at_utc") or cr.get("last_ingest_from_manifest_diag_at_utc") or "").strip()
    lines.append(" - last_ingest_from_manifest_diag_at_utc={0}".format(du))
    drid = str(st.get("last_ingest_from_manifest_diag_run_id") or cr.get("last_ingest_from_manifest_diag_run_id") or "").strip()
    lines.append(" - last_ingest_from_manifest_diag_run_id={0}".format(drid))
    diag_latest = os.path.join(lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json")
    ingest_pres = os.path.isfile(diag_latest)
    if dp:
        ingest_pres = ingest_pres or os.path.isfile(dp)
    lines.append(" - ingest_diag_present={0}".format("yes" if ingest_pres else "no"))
    hist = st.get("phase_c_remediation_history")
    if isinstance(hist, list) and hist:
        last = hist[-1]
        if isinstance(last, dict):
            lines.append(
                " - last_remediation_event={0}".format(str(last.get("event", "") or "")[:80])
            )
    lines.append(
        " - Next_action: Circuit auto-resets after deploy version change or "
        "{0}h cooldown ({1}); no operator reset required.".format(
            str(os.environ.get("MEDICAFE_PHASE_C_CIRCUIT_COOLDOWN_HOURS", "24") or "24"),
            "env MEDICAFE_PHASE_C_CIRCUIT_COOLDOWN_HOURS",
        )
    )
    return lines


def shallow_phase_c_self_heal_meta(lab_root):
    """Flatten keys for support bundle meta.json (shallow strings/bools/ints)."""
    lab_root = str(lab_root or "").strip()
    out = {
        "phase_c_circuit_open": False,
        "phase_c_attempts_for_current_b_sha": 0,
        "phase_c_last_attempt_action": "",
        "phase_c_last_attempt_outcome": "",
        "phase_c_subprocess_script_path": "",
        "phase_c_subprocess_script_sha256_prefix_stored": "",
        "phase_c_subprocess_script_size_bytes_stored": 0,
        "phase_c_subprocess_script_sha256_prefix_on_disk": "",
        "phase_c_subprocess_script_drift": "unknown",
        "last_ingest_from_manifest_diag_path": "",
        "last_ingest_from_manifest_diag_at_utc": "",
        "last_ingest_from_manifest_diag_run_id": "",
        "ingest_diag_present": False,
    }
    if not lab_root:
        return out
    st = _read(os.path.join(lab_root, "diagnostics_state.json"))
    cr = _read(os.path.join(lab_root, "run_cursor.json"))
    out["phase_c_circuit_open"] = bool(st.get("phase_c_circuit_open") or cr.get("phase_c_circuit_open"))
    try:
        out["phase_c_attempts_for_current_b_sha"] = int(st.get("phase_c_self_heal_failure_count_for_b_sha", 0) or 0)
    except Exception:
        out["phase_c_attempts_for_current_b_sha"] = 0
    out["phase_c_last_attempt_action"] = str(st.get("phase_c_last_self_heal_tier", "") or "").strip()
    out["phase_c_last_attempt_outcome"] = str(st.get("phase_c_last_self_heal_outcome", "") or "").strip()
    spath = str(st.get("last_phase_c_subprocess_script_path") or cr.get("last_phase_c_subprocess_script_path") or "").strip()
    out["phase_c_subprocess_script_path"] = spath
    rp = str(st.get("last_phase_c_subprocess_script_sha256_prefix") or cr.get("last_phase_c_subprocess_script_sha256_prefix") or "").strip()
    out["phase_c_subprocess_script_sha256_prefix_stored"] = rp
    try:
        out["phase_c_subprocess_script_size_bytes_stored"] = int(
            st.get("last_phase_c_subprocess_script_size_bytes") or cr.get("last_phase_c_subprocess_script_size_bytes") or 0
        )
    except Exception:
        out["phase_c_subprocess_script_size_bytes_stored"] = 0
    ondisk = _file_sha256_prefix16(spath)
    out["phase_c_subprocess_script_sha256_prefix_on_disk"] = ondisk
    if not spath:
        out["phase_c_subprocess_script_drift"] = "unknown"
    elif not ondisk:
        out["phase_c_subprocess_script_drift"] = "unknown"
    elif rp and (ondisk != rp):
        out["phase_c_subprocess_script_drift"] = "yes"
    elif rp:
        out["phase_c_subprocess_script_drift"] = "no"
    else:
        out["phase_c_subprocess_script_drift"] = "unknown"
    dp = str(st.get("last_ingest_from_manifest_diag_path") or cr.get("last_ingest_from_manifest_diag_path") or "").strip()
    out["last_ingest_from_manifest_diag_path"] = dp
    out["last_ingest_from_manifest_diag_at_utc"] = str(
        st.get("last_ingest_from_manifest_diag_at_utc") or cr.get("last_ingest_from_manifest_diag_at_utc") or ""
    ).strip()
    out["last_ingest_from_manifest_diag_run_id"] = str(
        st.get("last_ingest_from_manifest_diag_run_id") or cr.get("last_ingest_from_manifest_diag_run_id") or ""
    ).strip()
    diag_latest = os.path.join(lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json")
    ingest_pres = os.path.isfile(diag_latest)
    if dp:
        ingest_pres = ingest_pres or os.path.isfile(dp)
    out["ingest_diag_present"] = bool(ingest_pres)
    return out


def write_phase_c_self_heal_status_txt(lab_root, target_path=None):
    """
    Write phase_c_self_heal_status_latest.txt under lab/reports/, or to target_path when set.
    Returns path written or "".
    """
    lab_root = str(lab_root or "").strip()
    if not lab_root:
        return ""
    lines = [
        "Phase C Self-Heal Status",
        "generated_for_lab={0}".format(lab_root),
    ]
    lines.extend(format_phase_c_self_heal_lines(lab_root))
    hist = _read(os.path.join(lab_root, "diagnostics_state.json")).get("phase_c_remediation_history")
    if isinstance(hist, list) and hist:
        lines.append("")
        lines.append("Recent remediation history (newest last, capped):")
        for ev in hist[-12:]:
            if not isinstance(ev, dict):
                continue
            lines.append(
                " - {0} @ {1}".format(str(ev.get("event", "")), str(ev.get("at_utc", "")))
            )
    body = "\n".join(lines) + "\n"
    out_path = target_path or os.path.join(lab_root, "reports", "phase_c_self_heal_status_latest.txt")
    out_dir = os.path.dirname(out_path)
    try:
        if out_dir and not os.path.isdir(out_dir):
            os.makedirs(out_dir)
    except Exception:
        return ""
    try:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(body)
        return out_path
    except Exception:
        return ""
