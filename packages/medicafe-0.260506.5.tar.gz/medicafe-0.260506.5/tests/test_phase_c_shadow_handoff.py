# -*- coding: utf-8 -*-
"""Shadow pipeline Phase C handoff coherence (pytest)."""

from __future__ import print_function

import hashlib
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest
from contextlib import contextmanager

try:
    from contextlib import ExitStack
except ImportError:
    ExitStack = None

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

from phase_c_common import PHASE_C_CIRCUIT_OPEN, PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION


def _touch_min_ingest_diag_latest(lab_root):
    """Avoid phase_c_ingest_diagnostics_missing when testing other blocker overrides."""
    p = os.path.join(lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json")
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
    except Exception:
        pass
    with open(p, "w", encoding="utf-8") as handle:
        handle.write('{"schema_version":1}\n')


def _touch_bootstrap_ingest_diag_latest(lab_root, stage):
    p = os.path.join(lab_root, "reports", "ingest_from_manifest_bootstrap_latest.json")
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
    except Exception:
        pass
    with open(p, "w", encoding="utf-8") as handle:
        handle.write(
            json.dumps({"schema_version": 1, "stage": stage}, ensure_ascii=True, sort_keys=True) + "\n"
        )


def _phase_c_subproc_bridge_from_run_phase():
    """After _run_phase is patched, Phase C stderr wrapper delegates to that mock."""
    import run_shadow_pipeline as _rsp
    import time as _time

    def _bridge(script_name, lab_root, python_exe, repo_root, env):
        ok, rc = _rsp._run_phase(script_name, lab_root, python_exe, repo_root, env)
        script_path = os.path.join(repo_root, "scripts", "unified_model", script_name)
        started_at = _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())
        t4_sz = 0
        t4_sha = ""
        if os.path.isfile(script_path):
            try:
                t4_sz = int(os.path.getsize(script_path))
            except Exception:
                t4_sz = 0
            try:
                with open(script_path, "rb") as sf:
                    h = hashlib.sha256()
                    blk = sf.read(65536)
                    while blk:
                        h.update(blk)
                        blk = sf.read(65536)
                t4_sha = h.hexdigest()[:16]
            except Exception:
                t4_sha = ""
        return ok, rc, "", {
            "script_name": script_name,
            "script_path": script_path,
            "python_exe": python_exe,
            "cwd": repo_root,
            "started_at_utc": started_at,
            "finished_at_utc": started_at,
            "elapsed_sec": 0.0,
            "return_code": rc,
            "ok": ok,
            "subproc_stderr_tail": "",
            "subproc_stdout_tail": "",
            "script_sha256_prefix": t4_sha,
            "script_size_bytes": t4_sz,
        }

    return _bridge


@contextmanager
def _shadow_pipeline_std_mocks(run_phase_side_effect=None, run_phase_return=(True, 0)):
    """Nested patches for the usual run_shadow_pipeline unittest stack (DRY)."""
    if ExitStack is None:
        raise unittest.SkipTest("contextlib.ExitStack required (Python 3.3+)")
    with ExitStack() as stack:
        if run_phase_side_effect is not None:
            stack.enter_context(patch("run_shadow_pipeline._run_phase", side_effect=run_phase_side_effect))
        else:
            stack.enter_context(patch("run_shadow_pipeline._run_phase", return_value=run_phase_return))
        stack.enter_context(
            patch(
                "run_shadow_pipeline._run_phase_c_subprocess_with_stderr",
                side_effect=_phase_c_subproc_bridge_from_run_phase(),
            )
        )
        mp = stack.enter_context(patch("package_shadow_run_report.run_package"))
        mp.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
        stack.enter_context(patch("phase_e_auto_report.submit_phase_e_failure_report"))
        yield


class TestPhaseCHandoffCoherence(unittest.TestCase):
    """Subprocess exit 0 must match persisted Phase C handoff."""

    def _make_lab(self):
        lab_root = tempfile.mkdtemp(prefix="mc_pc_handoff_")
        os.makedirs(os.path.join(lab_root, "reports"))
        return lab_root

    def _write_lab_missing_c_summary(self, lab_root):
        """Phase C claims c-missing but reports/ingest_write_summary_c-missing.json is absent."""
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "last_manifest_sha256": "m1",
                    "last_phase_c_ok": True,
                    "last_ingest_manifest_sha256": "m1",
                    "last_phase_c_run_id": "c-missing",
                },
                f,
            )
        with open(cursor_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "last_phase_c_ok": True,
                    "last_ingest_manifest_sha256": "m1",
                    "last_phase_c_run_id": "c-missing",
                },
                f,
            )
        return state_path, cursor_path

    def test_handoff_fails_when_cursor_and_state_phase_c_ok_disagree(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_ok": False, "last_ingest_manifest_sha256": "m1"}, f)

            with _shadow_pipeline_std_mocks():
                ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_cursor_and_state_ingest_sha_disagree(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "bsha",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "state-sha",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "cursor-sha",
                    },
                    f,
                )

            with _shadow_pipeline_std_mocks():
                ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_canonical_phase_c_summary_missing(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        try:
            self._write_lab_missing_c_summary(lab_root)

            with _shadow_pipeline_std_mocks():
                ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_canonical_phase_c_summary_reports_failure(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": False,
                        "error_code": "PHASE_C_DB_WRITE_ERROR",
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with _shadow_pipeline_std_mocks():
                ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_DB_WRITE_ERROR")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_prefers_incoherent_when_failed_phase_c_state_is_stale(self):
        from run_shadow_pipeline import _phase_c_handoff_failure

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_old-c.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "old-c",
                        "ok": False,
                        "error_code": "PHASE_C_DB_WRITE_ERROR",
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "old-manifest-sha",
                    },
                    f,
                )
            state = {
                "last_manifest_sha256": "new-phase-b-manifest-sha",
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                "last_ingest_manifest_sha256": "old-manifest-sha",
                "last_phase_c_run_id": "old-c",
            }
            cursor = {
                "last_phase_c_ok": False,
                "last_ingest_manifest_sha256": "old-manifest-sha",
                "last_phase_c_run_id": "old-c",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(state, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(cursor, f)

            error_code, detail = _phase_c_handoff_failure(lab_root)

            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
            self.assertIn("last_manifest_sha256", detail)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_reports_incomplete_when_recovery_completed_but_phase_c_stayed_stale(self):
        from run_shadow_pipeline import _phase_c_handoff_failure

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            state = {
                "last_manifest_sha256": "new-phase-b-manifest-sha",
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                "last_ingest_manifest_sha256": "old-manifest-sha",
                "last_phase_c_run_id": "old-c",
                "phase_c_shadow_recovery": {
                    "status": "completed",
                    "trigger_reason": "phase_c_ingest_manifest_sha_mismatch",
                    "pipeline_run_id": "pipe-run",
                },
            }
            cursor = {
                "last_phase_c_ok": False,
                "last_ingest_manifest_sha256": "old-manifest-sha",
                "last_phase_c_run_id": "old-c",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(state, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(cursor, f)

            error_code, detail = _phase_c_handoff_failure(lab_root)

            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOMPLETE")
            self.assertIn("recovery completed", detail)
            self.assertIn("fresh ingest handoff", detail)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_avoids_stale_run_id_summary_requirement_without_fresh_diag_link(self):
        from run_shadow_pipeline import _phase_c_handoff_failure

        lab_root = self._make_lab()
        try:
            state = {
                "last_manifest_sha256": "same-sha",
                "last_ingest_manifest_sha256": "same-sha",
                "last_phase_c_ok": True,
                "last_phase_c_run_id": "old-c",
                "last_ingest_from_manifest_diag_run_id": "new-c",
            }
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(state, f)
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "old-c"}, f)
            err, detail = _phase_c_handoff_failure(lab_root)
            self.assertEqual(err, "PHASE_C_HANDOFF_INCOMPLETE")
            self.assertIn("fresh ingest handoff", detail)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_rebuilds_only_lab_db(self):
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_new-b.jsonl")
        source_path = os.path.join(lab_root, "source_DAT_DO_NOT_TOUCH.dat")
        try:
            with open(source_path, "w", encoding="utf-8") as f:
                f.write("source-data")
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE old_shadow_marker (id INTEGER PRIMARY KEY)")
                conn.execute("INSERT INTO old_shadow_marker (id) VALUES (1)")
                conn.commit()
            finally:
                conn.close()
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                lab_root, _REPO_ROOT, "pipe-run")

            self.assertTrue(ok)
            self.assertEqual(error_code, "")
            self.assertEqual(detail, "")
            self.assertEqual(recovery.get("status"), "completed")
            self.assertFalse(recovery.get("source_files_touched"))
            self.assertTrue(os.path.exists(recovery.get("quarantined_db_path")))
            self.assertTrue(os.path.exists(recovery.get("report_json_path")))
            with open(source_path, "r", encoding="utf-8") as f:
                self.assertEqual(f.read(), "source-data")
            conn = sqlite3.connect(db_path)
            try:
                tables = set([row[0] for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'").fetchall()])
            finally:
                conn.close()
            self.assertIn("ingest_artifact", tables)
            self.assertNotIn("old_shadow_marker", tables)
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual(state.get("last_phase_c_shadow_recovery_status"), "completed")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_triggers_for_current_manifest_db_write_error(self):
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_current-b.jsonl")
        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE old_shadow_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            state = {
                "last_phase_b_run_id": "current-b",
                "last_phase_c_run_id": "failed-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "same-sha",
                "last_ingest_manifest_sha256": "same-sha",
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(state, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(state, f)

            ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                lab_root, _REPO_ROOT, "pipe-run-current")

            self.assertTrue(ok)
            self.assertEqual(error_code, "")
            self.assertEqual(detail, "")
            self.assertEqual(recovery.get("trigger_reason"), "phase_c_db_write_error_for_current_manifest")
            self.assertEqual(recovery.get("status"), "completed")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_retries_transient_db_rename_lock(self):
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_retry.jsonl")
        rename_calls = {"n": 0}
        real_rename = os.rename

        def transient_rename(src, dst):
            rename_calls["n"] += 1
            if src == db_path and rename_calls["n"] == 1:
                raise OSError("[WinError 32] simulated transient DB lock")
            return real_rename(src, dst)

        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE retry_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            with patch.dict(os.environ, {"MEDICAFE_PHASE_C_RECOVERY_RENAME_RETRY_SEC": "0.001"}, clear=False):
                with patch("run_shadow_pipeline.os.rename", side_effect=transient_rename):
                    ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                        lab_root, _REPO_ROOT, "pipe-retry")

            self.assertTrue(ok)
            self.assertEqual(error_code, "")
            self.assertEqual(detail, "")
            self.assertEqual(recovery.get("status"), "completed")
            self.assertGreaterEqual(int(recovery.get("quarantine_retry_count") or 0), 1)
            self.assertIn("WinError 32", recovery.get("quarantine_retry_last_error", ""))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_rolls_back_db_when_sidecar_rename_fails(self):
        """If quarantine fails mid-way, the original DB must return to its path."""
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        wal_path = db_path + "-wal"
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_rollback.jsonl")
        real_rename = os.rename

        def flaky_rename(src, dst):
            if src == wal_path:
                raise OSError("simulated rename failure")
            return real_rename(src, dst)

        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("CREATE TABLE rollback_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            with open(wal_path, "wb") as wf:
                wf.write(b"\x00")
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            with patch.dict(os.environ, {"MEDICAFE_PHASE_C_RECOVERY_RENAME_RETRY_SEC": "0.001"}, clear=False):
                with patch("run_shadow_pipeline.os.rename", side_effect=flaky_rename):
                    ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                        lab_root, _REPO_ROOT, "pipe-rollback")

            self.assertFalse(ok)
            self.assertEqual(error_code, "PHASE_C_SHADOW_RECOVERY_FAILED")
            self.assertTrue(os.path.isfile(db_path))
            conn = sqlite3.connect(db_path)
            try:
                rows = conn.execute("SELECT COUNT(*) FROM rollback_marker").fetchone()
            finally:
                conn.close()
            self.assertEqual(rows[0], 0)
            self.assertEqual(recovery.get("quarantined_db_path"), "")
            self.assertEqual(recovery.get("quarantined_sidecars"), [])
            self.assertEqual(recovery.get("quarantine_retry_failed_label"), "-wal")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_shadow_recovery_restores_db_when_executescript_fails(self):
        """After quarantine, connect() creates an empty file; failed executescript must not block rollback."""
        from run_shadow_pipeline import _run_phase_c_shadow_recovery_if_needed

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_execfail.jsonl")
        _real_connect = sqlite3.connect

        class _ConnWrapper(object):
            def __init__(self, path, args, kwargs):
                self._conn = _real_connect(path, *args, **kwargs)

            def execute(self, *a, **kw):
                return self._conn.execute(*a, **kw)

            def executescript(self, _sql):
                raise sqlite3.DatabaseError("simulated executescript failure")

            def commit(self):
                return self._conn.commit()

            def close(self):
                return self._conn.close()

        def _fake_connect(path, *args, **kwargs):
            return _ConnWrapper(path, args, kwargs)

        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute(
                    "CREATE TABLE pre_quarantine_marker (id INTEGER PRIMARY KEY)"
                )
                conn.execute("INSERT INTO pre_quarantine_marker (id) VALUES (1)")
                conn.commit()
            finally:
                conn.close()
            stale = {
                "last_phase_b_run_id": "new-b",
                "last_phase_c_run_id": "old-c",
                "last_manifest_path": manifest_path,
                "last_manifest_sha256": "new-sha",
                "last_ingest_manifest_sha256": "old-sha",
            }
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(stale, f)

            with patch("run_shadow_pipeline.sqlite3.connect", side_effect=_fake_connect):
                ok, error_code, detail, recovery = _run_phase_c_shadow_recovery_if_needed(
                    lab_root, _REPO_ROOT, "pipe-execfail"
                )

            self.assertFalse(ok)
            self.assertEqual(error_code, "PHASE_C_SHADOW_RECOVERY_FAILED")
            self.assertTrue(os.path.isfile(db_path))
            conn2 = sqlite3.connect(db_path)
            try:
                rows = conn2.execute(
                    "SELECT COUNT(*) FROM pre_quarantine_marker"
                ).fetchone()
            finally:
                conn2.close()
            self.assertEqual(rows[0], 1)
            self.assertEqual(recovery.get("quarantined_db_path"), "")
            self.assertEqual(recovery.get("quarantined_sidecars"), [])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_pipeline_autonomously_recovers_stale_phase_c_before_d(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        manifest_path = os.path.join(reports, "artifact_manifest_new-b.jsonl")
        calls = []
        try:
            with open(manifest_path, "w", encoding="utf-8") as f:
                f.write("{}\n")
            conn = sqlite3.connect(db_path)
            try:
                conn.execute("CREATE TABLE old_shadow_marker (id INTEGER PRIMARY KEY)")
                conn.commit()
            finally:
                conn.close()
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_phase_b_run_id": "new-b",
                    "last_phase_c_run_id": "old-c",
                    "last_manifest_path": manifest_path,
                    "last_manifest_sha256": "new-sha",
                    "last_ingest_manifest_sha256": "old-sha",
                }, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_b_run_id": "new-b"}, f)

            def fake_run_phase(script_name, lab_root_arg, python_exe, repo_root, env):
                calls.append(script_name)
                if script_name == "ingest_from_manifest.py":
                    c_rid = "current-c"
                    summary_path = os.path.join(reports, "ingest_write_summary_{0}.json".format(c_rid))
                    with open(summary_path, "w", encoding="utf-8") as sf:
                        json.dump({
                            "run_id": c_rid,
                            "ok": True,
                            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                            "manifest_sha256": "new-sha",
                        }, sf)
                    with open(cursor_path, "w", encoding="utf-8") as cf:
                        json.dump({
                            "last_phase_b_run_id": "new-b",
                            "last_phase_c_run_id": c_rid,
                            "last_phase_c_ok": True,
                            "last_ingest_manifest_sha256": "new-sha",
                        }, cf)
                    with open(state_path, "r", encoding="utf-8") as stf:
                        st = json.load(stf)
                    st["last_phase_c_run_id"] = c_rid
                    st["last_phase_c_ok"] = True
                    st["last_ingest_manifest_sha256"] = "new-sha"
                    st["last_phase_c_error_code"] = None
                    with open(state_path, "w", encoding="utf-8") as stf:
                        json.dump(st, stf)
                return True, 0

            with patch("run_shadow_pipeline._run_phase", side_effect=fake_run_phase):
                with patch(
                    "run_shadow_pipeline._run_phase_c_subprocess_with_stderr",
                    side_effect=_phase_c_subproc_bridge_from_run_phase(),
                ):
                    with patch("package_shadow_run_report.run_package") as mock_pkg:
                        mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                        with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                            ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)

            self.assertTrue(ok)
            self.assertIsNone(failed_phase)
            self.assertIn(error_code, (None, ""))
            self.assertEqual(calls, [
                "bootstrap_lab.py",
                "discover_artifacts.py",
                "ingest_from_manifest.py",
                "run_qa_canonical.py",
                "run_projection_parity.py",
            ])
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual(state.get("last_phase_c_shadow_recovery_status"), "completed")
            self.assertTrue(os.path.exists(state.get("last_phase_c_shadow_recovery_report_path")))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_summary_schema_version_missing(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with _shadow_pipeline_std_mocks():
                ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_summary_schema_version_mismatch(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION + 1,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with _shadow_pipeline_std_mocks():
                ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_passes_when_summary_schema_version_matches(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with _shadow_pipeline_std_mocks():
                ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertTrue(ok)
            self.assertIsNone(failed_phase)
            self.assertIn(error_code, (None, ""))
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            self.assertTrue(report_path and os.path.isfile(report_path))
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_handoff_ok")
            self.assertEqual(st_after.get("last_phase_c_execution_handoff_blocker_class"), "phase_c_handoff_ok")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_diag_expected_summary_missing(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path, _cursor_path = self._write_lab_missing_c_summary(lab_root)
        try:
            _touch_min_ingest_diag_latest(lab_root)
            with _shadow_pipeline_std_mocks():
                ok, rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            self.assertTrue(report_path and os.path.isfile(report_path))
            self.assertTrue(report_path.endswith("phase_c_execution_handoff_{0}.json".format(rid)))
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_expected_summary_missing")
            txt_path = report_path[:-5] + ".txt"
            self.assertTrue(os.path.isfile(txt_path))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_diag_subprocess_nonzero(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_b_run_id": "b1",
                        "last_phase_c_run_id": "c0",
                        "last_phase_c_ok": True,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )

            def phase_side_effect(script_name, *args, **kwargs):
                if script_name == "ingest_from_manifest.py":
                    return (False, 9)
                return (True, 0)

            with _shadow_pipeline_std_mocks(run_phase_side_effect=phase_side_effect):
                ok, rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_subprocess_nonzero")
            self.assertEqual((diag.get("subprocess") or {}).get("return_code"), 9)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_diag_recovery_failed_before_ingest(self):
        from run_shadow_pipeline import PHASE_C_SHADOW_RECOVERY_FAILED, run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"last_manifest_sha256": "m1", "last_ingest_manifest_sha256": "m1"}, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            recovery = {
                "status": "failed",
                "error_code": PHASE_C_SHADOW_RECOVERY_FAILED,
                "error_detail": "schema file missing",
                "report_json_path": "",
                "trigger_reason": "phase_c_ingest_manifest_sha_mismatch",
            }

            def fake_recovery(*_a, **_kw):
                return (False, PHASE_C_SHADOW_RECOVERY_FAILED, "schema file missing", recovery)

            with patch("run_shadow_pipeline._run_phase_c_shadow_recovery_if_needed", side_effect=fake_recovery):
                with _shadow_pipeline_std_mocks():
                    ok, _rid, failed_phase, _ec = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            self.assertTrue(report_path and os.path.isfile(report_path))
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_not_run_recovery_failed")
            self.assertTrue(diag.get("recovery", {}).get("recovery_attempted"))
            self.assertEqual(diag.get("subprocess") or {}, {})
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_emit_post_recovery_incomplete_blocker(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "new-b",
                        "last_ingest_manifest_sha256": "old-c",
                        "last_phase_c_run_id": "old-c",
                        "phase_c_shadow_recovery": {
                            "status": "completed",
                            "trigger_reason": "phase_c_ingest_manifest_sha_mismatch",
                        },
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            recovery = {
                "status": "completed",
                "trigger_reason": "phase_c_ingest_manifest_sha_mismatch",
                "report_json_path": os.path.join(lab_root, "reports", "phase_c_shadow_recovery_x.json"),
            }
            exec_info = {
                "script_name": "ingest_from_manifest.py",
                "return_code": 0,
                "ok": True,
                "elapsed_sec": 0.1,
            }
            _touch_min_ingest_diag_latest(lab_root)
            detail = (
                "Phase C shadow recovery completed, but Phase C did not persist a fresh ingest handoff "
                "for latest Phase B manifest."
            )
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-test",
                {},
                recovery,
                exec_info,
                True,
                True,
                "PHASE_C_HANDOFF_INCOMPLETE",
                detail,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_post_recovery_handoff_incomplete")
            self.assertEqual(
                st_after.get("last_phase_c_execution_handoff_blocker_class"),
                "phase_c_post_recovery_handoff_incomplete",
            )
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_stamp_skips_corrupt_state_preserves_cursor(self):
        """Corrupt diagnostics_state.json must not be replaced by an empty doc (data loss)."""
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                f.write("{ not valid json")
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_manifest_path": "/keep/me", "last_phase_b_run_id": "b-keep"}, f)

            _emit_phase_c_execution_handoff_report(
                lab_root,
                "stamp-skip-test",
                {},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "",
                "",
            )
            with open(state_path, "r", encoding="utf-8") as f:
                corrupt_body = f.read()
            self.assertIn("not valid", corrupt_body)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cur = json.load(f)
            self.assertEqual(cur.get("last_manifest_path"), "/keep/me")
            self.assertEqual(cur.get("last_phase_b_run_id"), "b-keep")
            self.assertTrue(cur.get("last_phase_c_execution_handoff_report_path", "").endswith(
                "phase_c_execution_handoff_stamp-skip-test.json"
            ))
            self.assertEqual(cur.get("last_phase_c_execution_handoff_status"), "ok")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_shadow_recovery_stamp_skips_corrupt_state_preserves_lineage(self):
        """Corrupt diagnostics_state.json must not be replaced when stamping shadow recovery."""
        from run_shadow_pipeline import _stamp_phase_c_shadow_recovery_state

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                f.write("{ not valid json")
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_manifest_path": "/keep/me", "last_phase_b_run_id": "b-keep"}, f)

            recovery = {
                "schema_version": 1,
                "generated_at_utc": "2020-01-01T00:00:00Z",
                "status": "failed",
                "action": "phase_c_shadow_rebuild",
                "report_json_path": os.path.join(lab_root, "reports", "phase_c_shadow_recovery_x.json"),
            }
            _stamp_phase_c_shadow_recovery_state(lab_root, recovery)

            with open(state_path, "r", encoding="utf-8") as f:
                corrupt_body = f.read()
            self.assertIn("not valid", corrupt_body)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cur = json.load(f)
            self.assertEqual(cur.get("last_manifest_path"), "/keep/me")
            self.assertEqual(cur.get("last_phase_b_run_id"), "b-keep")
            self.assertEqual(cur.get("last_phase_c_shadow_recovery_status"), "failed")
            self.assertEqual(cur.get("phase_c_shadow_recovery", {}).get("status"), "failed")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_build_phase_f_supplemental_includes_execution_handoff(self):
        from phase_e_auto_report import build_phase_f_bundle_supplemental_files

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        try:
            hj = os.path.join(reports, "phase_c_execution_handoff_run1.json")
            ht = os.path.join(reports, "phase_c_execution_handoff_run1.txt")
            os.makedirs(reports, exist_ok=True)
            with open(hj, "w", encoding="utf-8") as jf:
                json.dump({"blocker_class": "phase_c_subprocess_nonzero"}, jf)
            with open(ht, "w", encoding="utf-8") as tf:
                tf.write("txt\n")
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as sf:
                json.dump({"last_phase_c_execution_handoff_report_path": hj}, sf)
            extras = build_phase_f_bundle_supplemental_files(
                lab_root,
                {"failed_phase": "C", "run_id": "run1"},
            )
            names = [t[0] for t in extras]
            self.assertIn(os.path.basename(hj), names)
            self.assertIn(os.path.basename(ht), names)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_subproc_stderr_tail_round_trip(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-run-stderr",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            tail = "sqlite3.OperationalError: locked\nsecond line\r\n"
            exec_info = {
                "script_name": "ingest_from_manifest.py",
                "return_code": 0,
                "ok": True,
                "elapsed_sec": 0.01,
                "subproc_stderr_tail": tail,
            }
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-stderr-tail",
                {"last_phase_c_run_id": "c-run-stderr"},
                {},
                exec_info,
                True,
                True,
                "",
                "",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("subprocess", {}).get("subproc_stderr_tail"), tail)
            txt_path = report_path[:-5] + ".txt"
            with open(txt_path, "r", encoding="utf-8") as tf:
                body = tf.read()
            self.assertIn("subproc_stderr_tail=", body)
            self.assertIn("OperationalError: locked", body)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_subproc_stdout_tail_round_trip(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-run-stdout",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            tail = "ingest_from_manifest: success line one\nsecond line\n"
            exec_info = {
                "script_name": "ingest_from_manifest.py",
                "return_code": 0,
                "ok": True,
                "elapsed_sec": 0.01,
                "subproc_stdout_tail": tail,
                "subproc_stderr_tail": "",
            }
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-stdout-tail",
                {"last_phase_c_run_id": "c-run-stdout"},
                {},
                exec_info,
                True,
                True,
                "",
                "",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("subprocess", {}).get("subproc_stdout_tail"), tail)
            txt_path = report_path[:-5] + ".txt"
            with open(txt_path, "r", encoding="utf-8") as tf:
                body = tf.read()
            self.assertIn("subproc_stdout_tail=", body)
            self.assertIn("success line one", body)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_handoff_failure_empty_ingest_sha_when_b_sha_set(self):
        from run_shadow_pipeline import _phase_c_handoff_failure

        for label, st, cr in (
            (
                "empty_strings",
                {"last_manifest_sha256": "b1", "last_ingest_manifest_sha256": ""},
                {"last_ingest_manifest_sha256": ""},
            ),
            (
                "missing_keys",
                {"last_manifest_sha256": "b1"},
                {},
            ),
            (
                "whitespace_only",
                {"last_manifest_sha256": "b1", "last_ingest_manifest_sha256": "  \t"},
                {"last_ingest_manifest_sha256": ""},
            ),
        ):
            with self.subTest(label=label):
                lab_root = self._make_lab()
                try:
                    with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                        json.dump(st, f)
                    with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                        json.dump(cr, f)
                    err, detail = _phase_c_handoff_failure(lab_root)
                    self.assertEqual(err, "PHASE_C_HANDOFF_INCOHERENT")
                    self.assertIn("ingest manifest sha256 missing", detail.lower())
                finally:
                    shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_stamps_script_fingerprint_to_lab_state(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "c-fp",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "c-other"}, f)
            exec_info = {
                "script_name": "ingest_from_manifest.py",
                "script_path": "/repo/scripts/unified_model/ingest_from_manifest.py",
                "script_sha256_prefix": "a1b2c3d4e5f67890",
                "script_size_bytes": 12345,
                "return_code": 0,
                "ok": True,
                "subproc_stdout_tail": "",
                "subproc_stderr_tail": "",
            }
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-fp",
                {"last_phase_c_run_id": "pre-fp"},
                {},
                exec_info,
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase B vs ingest mismatch synthetic",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            with open(cursor_path, "r", encoding="utf-8") as cf:
                cur_after = json.load(cf)
            self.assertEqual(
                st_after.get("last_phase_c_subprocess_script_path"),
                "/repo/scripts/unified_model/ingest_from_manifest.py",
            )
            self.assertEqual(st_after.get("last_phase_c_subprocess_script_sha256_prefix"), "a1b2c3d4e5f67890")
            self.assertEqual(st_after.get("last_phase_c_subprocess_script_size_bytes"), 12345)
            self.assertEqual(cur_after.get("last_phase_c_subprocess_script_sha256_prefix"), "a1b2c3d4e5f67890")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_persist_did_not_touch_state_when_mtime_unchanged(self):
        from run_shadow_pipeline import (
            _emit_phase_c_execution_handoff_report,
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
        )

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "c-mtime",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "c-mtime-live"}, f)
            mt = os.path.getmtime(state_path)
            snap_pre = {"last_phase_c_run_id": "ghost-pre", "diagnostics_state_mtime_epoch": mt}
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-mtime",
                snap_pre,
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_persist_did_not_touch_state")
            self.assertIn("mtime did not advance", diag.get("operator_summary_line", "").lower())
            self.assertEqual(diag.get("diagnostics_state_mtime_epoch_before"), mt)
            self.assertEqual(diag.get("diagnostics_state_mtime_epoch_after"), mt)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_c_handoff_failure_merges_phase_b_sha_from_cursor(self):
        """If diagnostics_state omits last_manifest_sha256, use run_cursor (parity with snapshots)."""
        from run_shadow_pipeline import _phase_c_handoff_failure

        lab_root = self._make_lab()
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_ingest_manifest_sha256": "",
                    },
                    f,
                )
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"last_manifest_sha256": "from-cursor-bsha"}, f)
            err, detail = _phase_c_handoff_failure(lab_root)
            self.assertEqual(err, "PHASE_C_HANDOFF_INCOHERENT")
            self.assertIn("ingest manifest sha256 missing", detail.lower())
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_mtime_persist_skipped_when_return_code_nonzero(self):
        from run_shadow_pipeline import (
            _emit_phase_c_execution_handoff_report,
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
        )

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "c-rc",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "c-rc-live"}, f)
            mt = os.path.getmtime(state_path)
            snap_pre = {"last_phase_c_run_id": "ghost-pre", "diagnostics_state_mtime_epoch": mt}
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-rcnz",
                snap_pre,
                {},
                {"return_code": 1, "ok": False},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_latest_manifest_sha_mismatch")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_subproc_ok_but_no_persist_when_run_id_unchanged(self):
        from run_shadow_pipeline import (
            _emit_phase_c_execution_handoff_report,
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
        )

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "c-stuck",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "c-stuck"}, f)
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-no-persist",
                {"last_phase_c_run_id": "c-stuck"},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_subproc_ok_but_no_persist")
            self.assertEqual(
                diag.get("persist_run_id", {}).get("before"),
                diag.get("persist_run_id", {}).get("after"),
            )
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_run_id_stuck_not_overridden_by_equal_mtime(self):
        """When run id is unchanged, prefer subproc_ok_but_no_persist over mtime-unchanged."""
        from run_shadow_pipeline import (
            _emit_phase_c_execution_handoff_report,
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
        )

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "c-stuck",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "c-stuck"}, f)
            _touch_min_ingest_diag_latest(lab_root)
            mt = os.path.getmtime(state_path)
            snap_pre = {"last_phase_c_run_id": "c-stuck", "diagnostics_state_mtime_epoch": mt}
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-stuck-mtime",
                snap_pre,
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_subproc_ok_but_no_persist")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_script_entrypoint_not_observed(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report, _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "r-ingest-diag",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            snap_pre = {"last_phase_c_run_id": "pre-other", "diagnostics_state_mtime_epoch": 0.0}
            exec_info = {"return_code": 0, "ok": True}
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-ingest-diag",
                snap_pre,
                {},
                exec_info,
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_script_entrypoint_not_observed")
            self.assertFalse(diag.get("summary_present"))
            self.assertFalse(diag.get("ingest_diagnostics_present"))
            self.assertFalse(diag.get("bootstrap_diagnostics_present"))
            self.assertEqual(diag.get("bootstrap_diagnostics_path"), "")
            self.assertEqual(diag.get("bootstrap_stage"), "")
            self.assertFalse(diag.get("state_lineage_updated"))
            self.assertFalse(diag.get("cursor_lineage_updated"))
            self.assertTrue(diag.get("persist_run_id_changed"))
            self.assertEqual(diag.get("publish_failure_class"), "entrypoint_not_observed")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_script_entered_but_no_finish_diag(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report, _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "r-bootstrap-only",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            _touch_bootstrap_ingest_diag_latest(lab_root, "before_run_ingest")
            snap_pre = {"last_phase_c_run_id": "pre-other", "diagnostics_state_mtime_epoch": 0.0}
            exec_info = {"return_code": 0, "ok": True}
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-bootstrap-only",
                snap_pre,
                {},
                exec_info,
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_script_entered_but_no_finish_diag")
            self.assertFalse(diag.get("summary_present"))
            self.assertFalse(diag.get("ingest_diagnostics_present"))
            self.assertTrue(diag.get("bootstrap_diagnostics_present"))
            self.assertEqual(diag.get("bootstrap_stage"), "before_run_ingest")
            self.assertTrue(diag.get("bootstrap_diagnostics_path", "").endswith("ingest_from_manifest_bootstrap_latest.json"))
            self.assertEqual(diag.get("publish_failure_class"), "finish_diagnostics_missing")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_publish_class_state_lineage_missing_with_summary_present(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c-state-missing.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c-state-missing",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-state-missing",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "c-state-missing",
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-state-lineage-missing",
                {"last_phase_c_run_id": "c-before"},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "synthetic publish classification check",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertTrue(diag.get("summary_present"))
            self.assertTrue(diag.get("ingest_diagnostics_present"))
            self.assertFalse(diag.get("state_lineage_updated"))
            self.assertTrue(diag.get("cursor_lineage_updated"))
            self.assertTrue(diag.get("persist_run_id_changed"))
            self.assertEqual(diag.get("publish_failure_class"), "state_lineage_missing")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_publish_class_cursor_lineage_missing_with_summary_present(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c-cursor-missing.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c-cursor-missing",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-cursor-missing",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "c-cursor-missing",
                        "last_ingest_manifest_sha256": "",
                    },
                    f,
                )
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-cursor-lineage-missing",
                {"last_phase_c_run_id": "c-before"},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "synthetic publish classification check",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertTrue(diag.get("summary_present"))
            self.assertTrue(diag.get("ingest_diagnostics_present"))
            self.assertTrue(diag.get("state_lineage_updated"))
            self.assertFalse(diag.get("cursor_lineage_updated"))
            self.assertTrue(diag.get("persist_run_id_changed"))
            self.assertEqual(diag.get("publish_failure_class"), "cursor_lineage_missing")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_publish_class_state_lineage_stale_nonempty_mismatch(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c-state-stale.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c-state-stale",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-state-stale",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "old-sha-nonempty",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "c-state-stale",
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-state-lineage-stale",
                {"last_phase_c_run_id": "c-before"},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "synthetic publish classification check",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertFalse(diag.get("state_lineage_updated"))
            self.assertTrue(diag.get("cursor_lineage_updated"))
            self.assertEqual(diag.get("publish_failure_class"), "state_lineage_missing")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_publish_class_manifest_sha_missing(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c-manifest-missing.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c-manifest-missing",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-manifest-missing",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "c-manifest-missing",
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-manifest-sha-missing",
                {"last_phase_c_run_id": "c-before"},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "synthetic publish classification check",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertTrue(diag.get("summary_present"))
            self.assertTrue(diag.get("ingest_diagnostics_present"))
            self.assertTrue(diag.get("state_lineage_updated"))
            self.assertTrue(diag.get("cursor_lineage_updated"))
            self.assertEqual(diag.get("publish_failure_class"), "manifest_sha_missing")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_publish_class_publish_ok_when_all_artifacts_present(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c-publish-ok.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c-publish-ok",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-publish-ok",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "c-publish-ok",
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-publish-ok",
                {"last_phase_c_run_id": "c-before"},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "",
                "",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("status"), "ok")
            self.assertEqual(diag.get("publish_failure_class"), "publish_ok")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_publish_ok_when_phase_b_manifest_sha_absent(self):
        """Ingest-only coherent success: no last_manifest_sha256 in lab state, handoff still ok."""
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c-ingest-only.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c-ingest-only",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "c-ingest-only",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": "c-ingest-only",
                        "last_ingest_manifest_sha256": "m1",
                    },
                    f,
                )
            _touch_min_ingest_diag_latest(lab_root)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-ingest-only-ok",
                {"last_phase_c_run_id": "c-before"},
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "",
                "",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("status"), "ok")
            self.assertEqual(diag.get("publish_failure_class"), "publish_ok")
            self.assertTrue(diag.get("state_lineage_updated"))
            self.assertTrue(diag.get("cursor_lineage_updated"))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_subprocess_script_drift(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report, _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        script_path = os.path.join(lab_root, "reports", "fake_ingest_script.py")
        try:
            with open(script_path, "w", encoding="utf-8") as sf:
                sf.write("version-one")
            h = hashlib.sha256()
            with open(script_path, "rb") as bf:
                blk = bf.read(65536)
                while blk:
                    h.update(blk)
                    blk = bf.read(65536)
            pref = h.hexdigest()[:16]
            sz = os.path.getsize(script_path)
            with open(script_path, "a", encoding="utf-8") as sf:
                sf.write("-mutated")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "r-drift",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            _touch_min_ingest_diag_latest(lab_root)
            snap_pre = {"last_phase_c_run_id": "ghost-pre", "diagnostics_state_mtime_epoch": 0.0}
            exec_info = {
                "return_code": 0,
                "ok": True,
                "script_path": script_path,
                "script_sha256_prefix": pref,
                "script_size_bytes": sz,
            }
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-drift",
                snap_pre,
                {},
                exec_info,
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_subprocess_script_drift")
            self.assertTrue((diag.get("subprocess") or {}).get("script_drift_detected"))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_execution_handoff_mtime_override_beats_ingest_diagnostics_missing(self):
        """Equal diagnostics_state mtime + missing ingest diag -> persist_did_not_touch_state (priority 1)."""
        from run_shadow_pipeline import (
            _emit_phase_c_execution_handoff_report,
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
        )

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_ingest_manifest_sha256": "m0",
                        "last_phase_c_run_id": "c-mtime",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": "c-mtime-live"}, f)
            mt = os.path.getmtime(state_path)
            snap_pre = {"last_phase_c_run_id": "ghost-pre", "diagnostics_state_mtime_epoch": mt}
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-mtime-beats-diag",
                snap_pre,
                {},
                {"return_code": 0, "ok": True},
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_persist_did_not_touch_state")
            self.assertFalse(diag.get("ingest_diagnostics_present"))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


class TestPhaseCExecutionHandoffClassifier(unittest.TestCase):
    """Table-driven contract for _classify_phase_c_execution_blocker (stdlib subTest, no pytest required)."""

    def test_classify_execution_blocker_matrix(self):
        from run_shadow_pipeline import (
            _classify_phase_c_execution_blocker,
            _HANDOFF_DETAIL_CURSOR_STATE_INGEST_SHA,
            _HANDOFF_DETAIL_CURSOR_STATE_PHASE_C_OK,
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            _HANDOFF_DETAIL_SUMMARY_SCHEMA_VERSION,
        )

        mismatch_detail = "{0} expected={1} got={2}".format(
            _HANDOFF_DETAIL_SUMMARY_SCHEMA_VERSION,
            PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION + 1,
        )
        cases = [
            (False, False, "", "", 0, "phase_c_not_run_recovery_failed"),
            (True, True, PHASE_C_CIRCUIT_OPEN, "", 0, "phase_c_circuit_open"),
            (True, False, "", "", 5, "phase_c_subprocess_nonzero"),
            (True, True, "", "", 0, "phase_c_handoff_ok"),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOMPLETE",
                "Phase C shadow recovery completed, but Phase C did not persist a fresh ingest handoff "
                "for latest Phase B manifest.",
                0,
                "phase_c_post_recovery_handoff_incomplete",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C canonical ingest summary is missing for last_phase_c_run_id=c1",
                0,
                "phase_c_expected_summary_missing",
            ),
            (True, True, "PHASE_C_HANDOFF_INCOHERENT", mismatch_detail, 0, "phase_c_summary_schema_mismatch"),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C canonical ingest summary reports ok=False.",
                0,
                "phase_c_summary_reports_not_ok",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_CURSOR_STATE_PHASE_C_OK,
                0,
                "phase_c_state_cursor_disagree",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_CURSOR_STATE_INGEST_SHA,
                0,
                "phase_c_state_cursor_disagree",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
                0,
                "phase_c_latest_manifest_sha_mismatch",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C ingest manifest sha256 missing after subprocess ok (Phase B summary lineage missing or ingest did not persist).",
                0,
                "phase_c_ingest_manifest_sha_missing",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C subprocess exited 0 but diagnostics_state.json mtime did not advance (test).",
                0,
                "phase_c_persist_did_not_touch_state",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "ingest_from_manifest_diagnostics_latest.json missing under reports",
                0,
                "phase_c_ingest_diagnostics_missing",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C subprocess script drift (script fingerprint drift)",
                0,
                "phase_c_subprocess_script_drift",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C canonical summary manifest_sha256 disagrees with diagnostics_state.",
                0,
                "phase_c_state_cursor_disagree",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOMPLETE",
                "Phase C did not persist last_phase_c_ok=True for latest Phase B manifest",
                0,
                "phase_c_latest_manifest_sha_mismatch",
            ),
            (
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                "summary_schema_version drift in body",
                0,
                "phase_c_summary_schema_mismatch",
            ),
            (True, True, "CUSTOM_HANDOFF_CODE", "opaque failure detail", 0, "phase_c_summary_reports_not_ok"),
        ]
        for recovery_ok, subproc_ok, he, hd, rc, expected in cases:
            with self.subTest(recovery_ok=recovery_ok, subproc_ok=subproc_ok, handoff_err=he, rc=rc):
                bc, _ln = _classify_phase_c_execution_blocker(recovery_ok, subproc_ok, he, hd, rc)
                self.assertEqual(bc, expected)

    def test_classify_subprocess_launch_failure_variants(self):
        from run_shadow_pipeline import _classify_phase_c_execution_blocker

        cases = [
            ("script_missing", "phase_c_script_missing"),
            ("script_zero_bytes", "phase_c_script_zero_bytes"),
            ("spawn_exception", "phase_c_subprocess_spawn_exception"),
        ]
        for kind, expected in cases:
            with self.subTest(kind=kind):
                bc, _ln = _classify_phase_c_execution_blocker(
                    True,
                    False,
                    "",
                    "",
                    -1,
                    {"launch_failure_kind": kind},
                )
                self.assertEqual(bc, expected)


class TestPhaseCLaunchDiagnostics(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_launch_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        return root

    def test_phase_c_script_missing_and_zero_byte_classification(self):
        from run_shadow_pipeline import (
            _classify_phase_c_execution_blocker,
            _run_phase_c_subprocess_with_stderr,
        )

        lab_root = self._lab()
        repo_root = tempfile.mkdtemp(prefix="mc_pc_repo_")
        try:
            script_dir = os.path.join(repo_root, "scripts", "unified_model")
            os.makedirs(script_dir, exist_ok=True)

            ok, rc, _tail, info = _run_phase_c_subprocess_with_stderr(
                "ingest_from_manifest.py",
                lab_root,
                sys.executable,
                repo_root,
                os.environ.copy(),
            )
            self.assertFalse(ok)
            self.assertEqual(rc, -1)
            self.assertEqual(info.get("launch_failure_kind"), "script_missing")
            bc, _ln = _classify_phase_c_execution_blocker(True, False, "", "", rc, info)
            self.assertEqual(bc, "phase_c_script_missing")

            with open(os.path.join(script_dir, "ingest_from_manifest.py"), "w", encoding="utf-8") as f:
                f.write("")
            ok2, rc2, _tail2, info2 = _run_phase_c_subprocess_with_stderr(
                "ingest_from_manifest.py",
                lab_root,
                sys.executable,
                repo_root,
                os.environ.copy(),
            )
            self.assertFalse(ok2)
            self.assertEqual(rc2, -1)
            self.assertEqual(info2.get("launch_failure_kind"), "script_zero_bytes")
            bc2, _ln2 = _classify_phase_c_execution_blocker(True, False, "", "", rc2, info2)
            self.assertEqual(bc2, "phase_c_script_zero_bytes")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)
            shutil.rmtree(repo_root, ignore_errors=True)

    def test_phase_c_spawn_exception_captured_and_stderr_tail_written(self):
        from run_shadow_pipeline import (
            _emit_phase_c_execution_handoff_report,
            _run_phase_c_subprocess_with_stderr,
        )

        lab_root = self._lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        repo_root = tempfile.mkdtemp(prefix="mc_pc_repo_spawn_")
        try:
            script_dir = os.path.join(repo_root, "scripts", "unified_model")
            os.makedirs(script_dir, exist_ok=True)
            script_path = os.path.join(script_dir, "ingest_from_manifest.py")
            with open(script_path, "w", encoding="utf-8") as f:
                f.write("print('hello')\n")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"last_manifest_sha256": "m1", "last_ingest_manifest_sha256": "m1"}, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            with patch("run_shadow_pipeline.subprocess.Popen", side_effect=OSError("spawn boom")):
                ok, rc, tail, info = _run_phase_c_subprocess_with_stderr(
                    "ingest_from_manifest.py",
                    lab_root,
                    sys.executable,
                    repo_root,
                    os.environ.copy(),
                )
            self.assertFalse(ok)
            self.assertEqual(rc, -1)
            self.assertIn("spawn", tail.lower())
            self.assertEqual(info.get("launch_failure_kind"), "spawn_exception")
            self.assertEqual(info.get("spawn_exception_class"), "OSError")
            self.assertIn("spawn boom", info.get("spawn_exception_message", ""))

            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-spawn",
                {},
                {},
                info,
                True,
                False,
                "",
                "",
            )
            stderr_tail_path = os.path.join(lab_root, "reports", "phase_c_ingest_stderr_tail_latest.txt")
            with open(stderr_tail_path, "r", encoding="utf-8") as f:
                body = f.read()
            self.assertIn("spawn boom", body)
            self.assertIn("launch failed", body.lower())
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)
            shutil.rmtree(repo_root, ignore_errors=True)

    def test_launch_failure_kind_persists_failure_context_details(self):
        from run_shadow_pipeline import run_shadow_pipeline

        cases = [
            (
                "script_missing",
                "PHASE_C_SCRIPT_MISSING",
                "LookupError",
                "ingest script is missing",
                "ingest_from_manifest.py",
            ),
            (
                "script_zero_bytes",
                "PHASE_C_SCRIPT_ZERO_BYTES",
                "ValueError",
                "zero bytes",
                "script is zero bytes",
            ),
            (
                "spawn_exception",
                "PHASE_C_SPAWN_EXCEPTION",
                "OSError",
                "subprocess spawn",
                "spawn boom from test",
            ),
        ]
        for launch_kind, expected_code, expected_src, expected_detail_1, expected_detail_2 in cases:
            with self.subTest(launch_kind=launch_kind):
                lab_root = self._lab()
                state_path = os.path.join(lab_root, "diagnostics_state.json")
                cursor_path = os.path.join(lab_root, "run_cursor.json")
                try:
                    with open(state_path, "w", encoding="utf-8") as f:
                        json.dump({"last_manifest_sha256": "m1", "last_ingest_manifest_sha256": "m1"}, f)
                    with open(cursor_path, "w", encoding="utf-8") as f:
                        json.dump({}, f)

                    exec_info = {
                        "script_name": "ingest_from_manifest.py",
                        "script_path": "/tmp/repo/scripts/unified_model/ingest_from_manifest.py",
                        "return_code": -1,
                        "ok": False,
                        "subproc_stderr_tail": "spawn boom from test",
                        "launch_failure_kind": launch_kind,
                        "spawn_exception_class": "OSError",
                        "spawn_exception_message": "spawn boom from test",
                    }

                    with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                        with patch("run_shadow_pipeline._run_phase_c_with_timing", return_value=(False, -1, exec_info)):
                            with patch("package_shadow_run_report.run_package") as mock_pkg:
                                mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                                with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                                    ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)

                    self.assertFalse(ok)
                    self.assertEqual(failed_phase, "C")
                    self.assertEqual(error_code, expected_code)

                    with open(state_path, "r", encoding="utf-8") as sf:
                        st_after = json.load(sf)
                    self.assertEqual(st_after.get("last_error_code"), expected_code)
                    self.assertEqual(st_after.get("last_error_source_exception_class"), expected_src)
                    self.assertIn(expected_detail_1, st_after.get("last_error_detail", ""))
                    self.assertIn(expected_detail_2, st_after.get("last_error_detail", ""))
                finally:
                    shutil.rmtree(lab_root, ignore_errors=True)

    def test_circuit_open_preserves_latest_root_blocker_class(self):
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        lab_root = self._lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"last_manifest_sha256": "m1", "last_ingest_manifest_sha256": "m1"}, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({}, f)
            _emit_phase_c_execution_handoff_report(
                lab_root,
                "pipe-circuit-root",
                {},
                {},
                {"circuit_open_root_blocker_class": "phase_c_subprocess_spawn_exception"},
                True,
                False,
                PHASE_C_CIRCUIT_OPEN,
                "Phase C self-heal circuit is open; ingest skipped until auto-reset.",
            )
            with open(state_path, "r", encoding="utf-8") as sf:
                st_after = json.load(sf)
            report_path = st_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as rf:
                diag = json.load(rf)
            self.assertEqual(diag.get("blocker_class"), "phase_c_subprocess_spawn_exception")
            self.assertIn("circuit is open", (diag.get("operator_summary_line") or "").lower())
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
