# -*- coding: utf-8 -*-
"""Phase C circuit auto-reset (cooldown)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

import phase_c_self_heal_state as phase_c_self_heal_state  # noqa: E402

from phase_c_self_heal_state import maybe_auto_reset_phase_c_circuit  # noqa: E402


class TestCircuitAutoReset(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_ar_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        return root

    def test_cooldown_clears_circuit(self):
        lab = self._lab()
        try:
            ver = "unknown"
            try:
                from MediCafe import __version__ as _v

                ver = str(_v or "").strip() or "unknown"
            except Exception:
                pass
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": ver,
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                        "phase_c_self_heal_failure_count_for_b_sha": 3,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertFalse(st.get("phase_c_circuit_open"))
            self.assertEqual(st.get("phase_c_self_heal_failure_count_for_b_sha"), 0)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_no_reset_when_circuit_closed(self):
        lab = self._lab()
        try:
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"version": 2, "phase_c_circuit_open": False}, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            self.assertFalse(maybe_auto_reset_phase_c_circuit(lab))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_no_reset_when_opened_at_invalid_iso_and_same_version(self):
        lab = self._lab()
        try:
            ver = "v-locked-for-test"
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": ver,
                        "phase_c_circuit_opened_at_utc": "not-an-iso-timestamp",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value=ver):
                self.assertFalse(maybe_auto_reset_phase_c_circuit(lab))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_no_reset_when_opened_in_future_relative_to_clock(self):
        lab = self._lab()
        try:
            ver = "v-same"
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": ver,
                        "phase_c_circuit_opened_at_utc": "2037-01-01T00:00:00Z",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value=ver):
                self.assertFalse(maybe_auto_reset_phase_c_circuit(lab))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_version_bump_resets_even_when_opened_recently(self):
        lab = self._lab()
        try:
            manifest = os.path.join(lab, "reports", "pending_m.jsonl")
            with open(manifest, "w", encoding="utf-8") as f:
                f.write("{}\n")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": "deploy-old",
                        "phase_c_circuit_opened_at_utc": "2035-06-01T00:00:00Z",
                        "phase_c_self_heal_failure_count_for_b_sha": 3,
                        "last_manifest_sha256": "old-state-canonical",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "pending-sha-9",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 1,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "old-canonical",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "pending-sha-9",
                    },
                    f,
                )
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value="deploy-new"):
                self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertFalse(cr.get("phase_c_circuit_open"))
            self.assertEqual(cr.get("last_manifest_sha256"), "pending-sha-9")
            self.assertEqual(cr.get("last_manifest_path"), manifest)
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertFalse(st.get("phase_c_circuit_open"))
            self.assertEqual(st.get("last_manifest_sha256"), "pending-sha-9")
            self.assertEqual(st.get("last_manifest_path"), manifest)
            self.assertEqual(st.get("last_discovery_pending_manifest_path"), "")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_auto_reset_skips_promotion_when_pending_sha_empty_but_file_exists(self):
        lab = self._lab()
        try:
            manifest = os.path.join(lab, "reports", "has_file.jsonl")
            with open(manifest, "w", encoding="utf-8") as f:
                f.write("{}\n")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": "v-old",
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                        "last_manifest_sha256": "stay-state",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 1,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "stay-cursor",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "",
                    },
                    f,
                )
            self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertEqual(st.get("last_manifest_sha256"), "stay-state")
            self.assertEqual(cr.get("last_manifest_sha256"), "stay-cursor")
            self.assertEqual(st.get("last_discovery_pending_manifest_path"), "")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_auto_reset_skips_promotion_when_pending_file_missing(self):
        lab = self._lab()
        try:
            missing = os.path.join(lab, "reports", "missing_manifest.jsonl")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": "v-old",
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 1,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "stay-put",
                        "last_discovery_pending_manifest_path": missing,
                        "last_discovery_pending_manifest_sha256": "ghost-sha",
                    },
                    f,
                )
            self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertEqual(cr.get("last_manifest_sha256"), "stay-put")
        finally:
            shutil.rmtree(lab, ignore_errors=True)
