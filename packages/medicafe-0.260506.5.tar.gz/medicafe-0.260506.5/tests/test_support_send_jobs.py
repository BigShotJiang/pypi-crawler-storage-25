#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _wait_worker_quiet(manager, rounds=80, delay_sec=0.02):
    for _ in range(int(max(1, rounds))):
        thread = getattr(manager, '_worker_thread', None)
        if thread is None or not thread.is_alive():
            return
        time.sleep(delay_sec)


class TestSupportSendQueuePolicy(unittest.TestCase):

    def test_dedup_key_includes_anchor_context_and_issue(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        policy = SupportSendQueuePolicy(dedup_ttl_sec=60)
        key = policy.dedup_key({
            'send_type': 'run_evidence',
            'anchor_run_id': 'a1',
            'context_run_id': 'c1',
            'issue_code': 'x1',
            'source_scope_hash': 'h1',
        })
        self.assertEqual(key, 'run_evidence|a1|c1|x1|h1')


class TestSupportSendJobManager(unittest.TestCase):

    def test_enqueue_accepts_even_if_legacy_async_env_is_off(self):
        """MEDICAFE_SUPPORT_SEND_ASYNC is obsolete; queue is always used for supported types."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_ASYNC': '0',
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-legacy',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                self.assertNotEqual(str(res.get('policy_decision', '')), 'sync_fallback')
                _wait_worker_quiet(mgr)

    def test_background_job_logger_receives_progress_heartbeat(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((event_name, dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)

                def _execute(_job, progress_callback):
                    progress_callback('creating zip bundle')
                    return True, 'sent', {}

                mgr._execute_send = _execute
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-heartbeat|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                _wait_worker_quiet(mgr)

        names = [name for name, _details in events]
        self.assertIn('job_accepted', names)
        self.assertIn('job_started', names)
        self.assertIn('job_progress', names)
        self.assertIn('job_finished', names)
        progress = [details for name, details in events if name == 'job_progress'][0]
        self.assertEqual(progress.get('progress_stage'), 'creating zip bundle')
        self.assertEqual(progress.get('installed_version'), '1.1.0')
        self.assertEqual(progress.get('recommendation_action_kind'), 'send_bundle')
        self.assertTrue(progress.get('heartbeat_at_utc'))
    def test_enqueue_records_post_update_autofollow_tags(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-post-update|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                job = mgr._read_job(str(res.get('job_id', '') or ''))
                self.assertEqual(job.get('source'), 'post_update_cloud_autofollow')
                self.assertEqual(job.get('installed_version'), '1.1.0')
                self.assertEqual(job.get('recommendation_action_kind'), 'send_bundle')
                _wait_worker_quiet(mgr)

    def test_enqueue_persists_evidence_manifest_enqueue_snapshot(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                snap = {
                    'schema_version': 1,
                    'request': {'bundle_kind': 'run_evidence_bundle'},
                    'scope': {},
                    'validation': {'attachment_contract_status': 'pass'},
                    'missing_required_evidence': [],
                    'operator_contract': {},
                    'attachments_summary': [{'archive_name': 'x.json', 'has_inline_content': False}],
                }
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-manifest',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                    'evidence_manifest_enqueue': snap,
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                job = mgr._read_job(str(res.get('job_id', '') or ''))
                self.assertEqual(job.get('evidence_manifest_enqueue'), snap)
                _wait_worker_quiet(mgr)

    def test_recover_requeues_running_post_update_job_after_launcher_restart(self):
        import json
        from MediCafe.support_send_jobs import SupportSendJobManager, _utc_now
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-recover|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                job = mgr._build_job_record(req, 'started', 'started_immediately')
                job['status'] = 'running'
                job['progress_stage'] = 'sending email to support'
                job['heartbeat_at_utc'] = _utc_now()
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job.get('job_id')}, handle)
                with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                    result = mgr.recover_jobs_after_launcher_restart(
                        source='post_update_cloud_autofollow',
                        installed_version='1.1.0')
                recovered = result.get('recovered_job_ids', [])
                self.assertIn(job.get('job_id'), recovered)
                recovered_job = mgr._read_job(job.get('job_id'))
                self.assertEqual(recovered_job.get('status'), 'queued')
                self.assertEqual(recovered_job.get('policy_reason'), 'running_job_recovered_after_launcher_restart')
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                queue_state = mgr._read_queue_state()
                self.assertIn(job.get('job_id'), queue_state.get('queued_job_ids', []))
                ensure_worker.assert_called_once_with()

    def test_preflight_reaps_weeks_old_running_job_and_releases_lock(self):
        import json
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-stale',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                job['status'] = 'running'
                job['progress_stage'] = 'building anchored context pack'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job_id}, handle)

                reaped = mgr.preflight_reap_stale_running_jobs()
                reaped_job = mgr._read_job(job_id)

                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertIn(str(reaped_job.get('policy_reason')), (
                    'abandoned_running_job_reaped',
                    'abandoned_running_job_reaped_pid_may_be_reused',
                    'abandoned_in_process_job_reaped_current_launcher',
                ))
                self.assertEqual(reaped_job.get('previous_status_before_stale_reap'), 'running')
                self.assertTrue(reaped_job.get('suppress_restart_recovery'))
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                self.assertNotIn(job_id, mgr._read_queue_state().get('queued_job_ids', []))
                self.assertEqual(mgr._find_active_job().get('job_id'), None)
                audit = mgr.read_stale_preflight_audit()
                self.assertEqual(audit.get('stale_running_jobs_found'), 1)
                self.assertEqual(audit.get('resolved_count'), 1)
                self.assertTrue(os.path.isfile(mgr.stale_preflight_latest_txt_path))
                self.assertTrue(os.path.isfile(mgr.stale_preflight_latest_path))

    def test_preflight_reaps_stale_dead_pid_without_waiting_for_abandoned_age(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-stale-dead-pid',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = ''
                mgr._write_job(job)

                reaped = mgr.preflight_reap_stale_running_jobs()
                reaped_job = mgr._read_job(job_id)

                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertEqual(reaped_job.get('policy_reason'), 'stale_running_job_reaped')
                self.assertGreaterEqual(int(reaped_job.get('stale_reap_heartbeat_age_sec') or 0), 3600)

    def test_preflight_terminates_stale_known_detached_worker(self):
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-stale-detached',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['worker_mode'] = 'detached_worker'
                job['worker_pid'] = '424242'
                job['worker_command'] = os.path.join(repo, 'scripts', 'support_send_worker.py')
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                mgr._write_job(job)

                with patch.object(jobs_mod, '_pid_running', return_value=True), \
                        patch.object(mgr, '_terminate_stale_worker_process', return_value={
                            'attempted': True,
                            'ok': True,
                            'method': 'taskkill',
                            'return_code': '0',
                            'message': '',
                        }) as terminate:
                    reaped = mgr.preflight_reap_stale_running_jobs()

                reaped_job = mgr._read_job(job_id)
                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertEqual(reaped_job.get('policy_reason'), 'stale_detached_worker_terminated')
                self.assertTrue(reaped_job.get('stale_reap_known_detached_worker'))
                self.assertTrue(reaped_job.get('stale_reap_termination', {}).get('attempted'))
                terminate.assert_called_once_with(424242)

    def test_preflight_keeps_stale_live_unknown_pid_until_abandoned(self):
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-live-unknown',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['worker_mode'] = 'unknown_worker'
                job['worker_pid'] = '424243'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                mgr._write_job(job)

                with patch.object(jobs_mod, '_pid_running', return_value=True):
                    reaped = mgr.preflight_reap_stale_running_jobs()
                    active = mgr._find_active_job()

                self.assertEqual(reaped, [])
                self.assertEqual(active.get('job_id'), job_id)
                self.assertEqual(mgr._read_job(job_id).get('status'), 'running')
                audit = mgr.read_stale_preflight_audit()
                self.assertEqual(audit.get('stale_running_jobs_found'), 1)
                self.assertEqual(audit.get('resolved_count'), 0)
                self.assertEqual(audit.get('unresolved_count'), 1)
                self.assertEqual((audit.get('jobs') or [{}])[0].get('reason'), 'stale_running_job_pid_still_live')

    def test_preflight_does_not_abandon_reap_long_queued_job_recently_started_same_pid(self):
        """Abandonment must use running age (started_at), not enqueue age (created_at)."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        import json
        now = time.time()
        old_created = now - (14 * 24 * 60 * 60)
        recent_start = now - 120
        stale_hb = now - (2 * 60 * 60)
        created_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(old_created))
        started_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(recent_start))
        hb_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(stale_hb))
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': str(24 * 60 * 60),
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-long-queue-recent-start',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                job['status'] = 'running'
                job['created_at_utc'] = created_utc
                job['created_epoch'] = old_created
                job['started_at_utc'] = started_utc
                job['heartbeat_at_utc'] = hb_utc
                job['worker_pid'] = str(os.getpid())
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job_id}, handle)

                reaped = mgr.preflight_reap_stale_running_jobs()
                still = mgr._read_job(job_id)

                self.assertEqual(reaped, [])
                self.assertEqual(still.get('status'), 'running')
                self.assertTrue(os.path.isfile(mgr.single_flight_lock_path))

    def test_enqueue_after_stale_running_job_starts_new_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                stale = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-old',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }, 'started', 'started_immediately')
                stale_id = str(stale.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                stale['status'] = 'running'
                stale['created_at_utc'] = old_utc
                stale['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                stale['heartbeat_at_utc'] = old_utc
                stale['worker_pid'] = '999999'
                mgr._write_job(stale)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})

                res = mgr.enqueue({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-new',
                    'context_run_id': 'run-new',
                    'issue_code': 'issue-new',
                    'source_scope_hash': 'scope-new',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                })

                self.assertTrue(res.get('accepted'))
                self.assertEqual(res.get('policy_decision'), 'started')
                self.assertEqual(mgr._read_job(stale_id).get('status'), 'failed')
                _wait_worker_quiet(mgr)

    def test_restart_recovery_does_not_requeue_stale_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-stale-recover',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = '999999'
                mgr._write_job(job)

                result = mgr.recover_jobs_after_launcher_restart(
                    source='post_update_cloud_autofollow',
                    installed_version='1.1.0')

                self.assertEqual(result.get('recovered_job_ids', []), [])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'failed')
                self.assertEqual(mgr._read_queue_state().get('queued_job_ids', []), [])

    def test_run_single_job_defers_while_shadow_pipeline_lock_owned(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-pipeline-active',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)

                with patch.object(mgr, '_shadow_pipeline_lock_owner', return_value={
                    'pid': str(os.getpid()),
                    'heartbeat_at_utc': '2026-05-03T05:45:29Z',
                    'lock_path': os.path.join(lab_root, 'shadow_pipeline.lock'),
                    'owner_running': True,
                }):
                    mgr._run_single_job(job)

                deferred = mgr._read_job(job_id)
                self.assertEqual(deferred.get('status'), 'queued')
                self.assertEqual(deferred.get('policy_reason'), 'shadow_pipeline_running')
                self.assertEqual(deferred.get('progress_stage'), 'waiting for shadow pipeline')
                self.assertEqual(deferred.get('shadow_pipeline_lock_pid'), str(os.getpid()))
                self.assertIn(job_id, mgr._read_queue_state().get('queued_job_ids', []))
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))

    def test_worker_waits_for_shadow_pipeline_before_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING': '1',
                'MEDICAFE_SUPPORT_SEND_PIPELINE_WAIT_POLL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-pipeline-wait',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                calls = []

                def _execute(_job, progress_callback):
                    calls.append(_job.get('job_id'))
                    progress_callback('sending email to support')
                    return True, 'sent', {}

                owner = {
                    'pid': str(os.getpid()),
                    'heartbeat_at_utc': '2026-05-03T05:45:29Z',
                    'lock_path': os.path.join(lab_root, 'shadow_pipeline.lock'),
                    'owner_running': True,
                }
                mgr._execute_send = _execute
                with patch.object(mgr, '_shadow_pipeline_lock_owner', side_effect=[owner, owner, {}, {}, {}]), \
                        patch('MediCafe.support_send_jobs.time.sleep', return_value=None):
                    mgr._worker_loop()

                self.assertEqual(calls, [job_id])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'succeeded')

    def test_enqueue_deduplicates_recent_equivalent_request(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                # Give worker a brief moment to persist running/terminal state.
                time.sleep(0.05)
                second = mgr.enqueue(req)
                self.assertTrue(second.get('accepted'))
                self.assertEqual(second.get('policy_decision'), 'deduplicated')
                msg = str(second.get('message') or '')
                self.assertIn('run_evidence', msg)
                self.assertIn('run-1', msg)
                self.assertIn('issue-1', msg)
                self.assertIn('scope-1', msg)
                _wait_worker_quiet(mgr)

    def test_blocked_job_is_requeued_when_single_flight_busy(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                # Simulate post-dequeue state where picked job id was removed.
                mgr._write_queue_state([])
                mgr._acquire_single_flight = lambda _job_id: False
                mgr._run_single_job(job)
                refreshed = mgr._read_job(job_id)
                queue_state = mgr._read_queue_state()
                self.assertEqual(str(refreshed.get('status', '')), 'blocked')
                self.assertIn(job_id, queue_state.get('queued_job_ids', []))

    def test_retry_preserves_source_scope_hash_for_dedup_key(self):
        from MediCafe.support_send_jobs import SupportSendJobManager, SupportSendQueuePolicy
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'requested_artifact_scope': 'latest_live_snapshot',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                first_job_id = str(first.get('job_id', '') or '')
                first_job = mgr._read_job(first_job_id)
                first_job['created_epoch'] = float(time.time()) - 3600.0
                mgr._write_job(first_job)

                retried = mgr.retry(first_job_id)
                self.assertTrue(retried.get('accepted'))
                retried_id = str(retried.get('job_id', '') or '')
                self.assertTrue(retried_id and retried_id != first_job_id)
                retried_job = mgr._read_job(retried_id)
                self.assertEqual(str(retried_job.get('source_scope_hash', '') or ''), 'scope-1')
                expected = SupportSendQueuePolicy().dedup_key({
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                })
                self.assertEqual(str(retried_job.get('dedup_key', '') or ''), expected)
                _wait_worker_quiet(mgr)

    def test_cancel_queued_job_removes_from_queue_and_sets_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                res = mgr.cancel_job_if_possible(job_id, reason='test_cancel')
                self.assertTrue(res.get('ok'))
                self.assertEqual(str(res.get('policy_reason')), 'canceled_queued')
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'canceled')
                self.assertTrue(refreshed.get('suppress_restart_recovery'))
                queue_state = mgr._read_queue_state()
                self.assertNotIn(job_id, queue_state.get('queued_job_ids', []))

    def test_cancel_running_job_returns_running_not_cancelable(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'running'
            mgr._write_job(job)
            res = mgr.cancel_job_if_possible(job_id, reason='x')
            self.assertFalse(res.get('ok'))
            self.assertEqual(str(res.get('policy_reason')), 'running_not_cancelable')

    def test_run_single_job_skips_when_job_file_marked_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            mgr._write_job(job)
            calls = []

            def _track(_j, _cb):
                calls.append(1)
                return (True, 'ok', {})

            mgr._execute_send = _track
            mgr._run_single_job({'job_id': job_id})
            self.assertEqual(calls, [])

    def test_recover_skips_jobs_with_suppress_restart_recovery(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            job['suppress_restart_recovery'] = True
            mgr._write_job(job)
            mgr._write_queue_state([])
            recovery = mgr.recover_jobs_after_launcher_restart()
            self.assertEqual(recovery.get('recovered_job_ids', []), [])
            queue_state = mgr._read_queue_state()
            self.assertEqual(queue_state.get('queued_job_ids', []), [])

    def test_queued_job_is_active_and_kicks_worker_from_status_check(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'post_update_cloud_autofollow',
                'priority': 'high',
                'send_type': 'system_health',
                'source_scope_hash': 'scope-queued-active',
                'installed_version': '1.1.0',
                'recommendation_action_kind': 'resolve_layer1_upstream_blocker',
            }, 'started', 'started_immediately')
            job_id = str(job.get('job_id'))
            mgr._write_job(job)
            mgr._write_queue_state([job_id])

            with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                active = mgr._find_active_job()

            self.assertEqual(active.get('job_id'), job_id)
            self.assertEqual(active.get('status'), 'queued')
            ensure_worker.assert_called_once_with()

    def test_enqueue_behind_queued_job_records_queued_pending_reason(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            first = mgr._build_job_record({
                'source': 'post_update_cloud_autofollow',
                'priority': 'high',
                'send_type': 'system_health',
                'anchor_run_id': 'queued-head',
                'source_scope_hash': 'scope-first',
            }, 'started', 'started_immediately')
            first_id = str(first.get('job_id'))
            mgr._write_job(first)
            mgr._write_queue_state([first_id])

            with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                result = mgr.enqueue({
                    'source': 'deferred_operator_send',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'queued-tail',
                    'source_scope_hash': 'scope-second',
                })

            self.assertTrue(result.get('accepted'))
            self.assertEqual(result.get('policy_decision'), 'queued')
            second = mgr._read_job(str(result.get('job_id') or ''))
            self.assertEqual(second.get('policy_reason'), 'queued_jobs_pending')
            self.assertEqual(second.get('queued_before'), 1)
            queue_state = mgr._read_queue_state()
            self.assertEqual(queue_state.get('queued_job_ids', [])[0], first_id)
            self.assertIn(second.get('job_id'), queue_state.get('queued_job_ids', []))
            ensure_worker.assert_called_once_with()


class TestFrozenRecommendationRunEvidence(unittest.TestCase):

    def test_run_evidence_send_skips_recompute_when_frozen_recommendation_provided(self):
        from MediCafe import cloud_readiness as cr_mod
        from MediCafe import cloud_readiness_recommendations as rec_mod
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            triage_path = os.path.join(reports_dir, 'artifact_triage_pack_test.txt')
            index_path = os.path.join(reports_dir, 'run_artifact_index_test.txt')
            bundle_path = os.path.join(reports_dir, 'support_bundle_test.zip')
            stale_txt = os.path.join(reports_dir, 'support_send_stale_preflight_latest.txt')
            stale_json = os.path.join(reports_dir, 'support_send_stale_preflight_latest.json')
            for p in (triage_path, index_path, bundle_path, stale_txt, stale_json):
                with open(p, 'w') as h:
                    h.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab_root,
                'reports_dir': reports_dir,
                'run_id': '20260410-011341-b73de336',
                'artifact_files': [],
                'context_files': [],
            }
            frozen = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': '20260410-011341-b73de336',
                'action_preview': {'anchor_run_id': '20260410-011341-b73de336'},
            }
            with patch.object(cr_mod, 'collect_support_bundle', return_value=bundle_path, create=True) as mock_collect, \
                    patch.object(cr_mod, 'submit_support_bundle_email', return_value=True, create=True), \
                    patch.object(cr_mod, '_build_run_artifact_snapshot', return_value=(True, '', snapshot), create=True), \
                    patch.object(cr_mod, '_artifact_bundle_quality', return_value={
                        'score': 100, 'label': 'GREEN', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'ready'
                    }, create=True), \
                    patch.object(cr_mod, '_write_artifact_triage_pack', return_value=triage_path, create=True), \
                    patch.object(cr_mod, '_write_run_artifact_index', return_value=index_path, create=True), \
                    patch.object(cr_mod, 'open_report_delivery_status', return_value=(False, '', ''), create=True), \
                    patch.object(cr_mod, '_collect_run_evidence_context_attachment', return_value=('', {}), create=True), \
                    patch.object(cr_mod, '_phase_d_dat_smoke_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(cr_mod, '_review_dat_qa_full_block_forced_attachment_paths', return_value=[], create=True), \
                    patch.object(cr_mod, '_phase_d_reprocess_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(cr_mod, '_latest_interrupt_report_paths', return_value=[], create=True), \
                    patch.object(cr_mod, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {}), create=True), \
                    patch.object(cr_mod, 'compute_operator_support_send_recommendation_core') as mock_compute:
                ok, msg, data = rec_mod.send_latest_run_evidence_bundle(
                    repo,
                    frozen_recommendation=frozen,
                )
            mock_compute.assert_not_called()
            self.assertTrue(isinstance(ok, bool))
            self.assertTrue(isinstance(msg, str))
            extra_files = mock_collect.call_args[1].get('extra_files', [])
            basenames = [item[0] for item in extra_files]
            self.assertIn('support_send_stale_preflight_latest.txt', basenames)
            self.assertIn('support_send_stale_preflight_latest.json', basenames)


class TestSupportSendDequeueAndDeliveryResolve(unittest.TestCase):
    """RCCA: blocked jobs must not disappear from queue when a queued job is dequeued."""

    def test_dequeue_preserves_blocked_job_ids_in_queue_order(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            jid_blocked = 'ssj_blocked_unit'
            jid_queued = 'ssj_queued_unit'
            mgr._write_job({
                'job_id': jid_blocked,
                'status': 'blocked',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-01T00:00:00Z',
                'created_epoch': 1.0,
                'priority': 'normal',
                'progress_stage': 'blocked',
            })
            mgr._write_job({
                'job_id': jid_queued,
                'status': 'queued',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-02T00:00:00Z',
                'created_epoch': 2.0,
                'priority': 'normal',
                'progress_stage': 'queued',
            })
            mgr._write_queue_state([jid_blocked, jid_queued])
            with mgr._state_lock:
                picked = mgr._dequeue_next_job_locked()
            self.assertEqual(str(picked.get('job_id')), jid_queued)
            state = mgr._read_queue_state()
            self.assertEqual(state.get('queued_job_ids'), [jid_blocked])

    def test_dequeue_no_ready_jobs_compacts_orphans_keeps_blocked(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            jid_blocked = 'ssj_blocked_only'
            mgr._write_job({
                'job_id': jid_blocked,
                'status': 'blocked',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-01T00:00:00Z',
                'created_epoch': 1.0,
                'priority': 'normal',
                'progress_stage': 'blocked',
            })
            mgr._write_queue_state(['missing_job_json', jid_blocked])
            with mgr._state_lock:
                picked = mgr._dequeue_next_job_locked()
            self.assertEqual(picked, {})
            state = mgr._read_queue_state()
            self.assertEqual(state.get('queued_job_ids'), [jid_blocked])

    def test_resolve_delivery_diagnostics_falls_back_to_lab_report_status(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            status_path = os.path.join(reports_dir, 'report_delivery_status.txt')
            with open(status_path, 'w') as handle:
                handle.write('delivery ok\n')
            mgr = SupportSendJobManager(repo, lab_root)
            path = mgr.resolve_delivery_diagnostics_path({
                'send_type': 'system_health',
                'status': 'queued',
                'delivery_status_path': '',
            })
            self.assertEqual(path, status_path)

    def test_list_jobs_includes_resolved_delivery_path(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            status_path = os.path.join(reports_dir, 'report_delivery_status.txt')
            with open(status_path, 'w') as handle:
                handle.write('x\n')
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            mgr._write_job({
                'job_id': 'ssj_list_resolve',
                'status': 'queued',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-03T00:00:00Z',
                'created_epoch': 3.0,
                'priority': 'normal',
                'delivery_status_path': '',
            })
            rows = mgr.list_jobs(limit=5)
            by_id = {str(r.get('job_id')): r for r in rows if isinstance(r, dict)}
            self.assertEqual(by_id['ssj_list_resolve'].get('delivery_diagnostics_resolved_path'), status_path)


class TestSystemHealthDedupAndWorkerPreflight(unittest.TestCase):

    def test_system_health_dedup_key_format(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        policy = SupportSendQueuePolicy()
        with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
            key = policy.dedup_key({
                'send_type': 'system_health',
                'anchor_run_id': 'run-a',
                'layer1_current_blocker': 'phase_c_db',
                'source_scope_hash': 'ignored-for-shp',
            })
        self.assertEqual(key, 'system_health|run-a|phase_c_db|20260505')

    def test_enqueue_suppresses_duplicate_when_blocked_system_health(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '900',
            }, clear=False):
                with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                    mgr = SupportSendJobManager(repo, lab_root)
                    req = {
                        'source': 'test',
                        'priority': 'high',
                        'send_type': 'system_health',
                        'anchor_run_id': 'ax',
                        'layer1_current_blocker': 'bx',
                    }
                    job = mgr._build_job_record(req, 'queued', 'queued_jobs_pending')
                    job['status'] = 'blocked'
                    job['policy_reason'] = 'single_flight_busy'
                    mgr._write_job(job)
                    dup = mgr.enqueue(req)
                self.assertTrue(dup.get('accepted'))
                self.assertEqual(str(dup.get('policy_decision')), 'deduplicated')

    def test_enqueue_system_health_allows_second_after_utc_day_changes(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'same',
                    'layer1_current_blocker': 'same',
                }
                with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260504'):
                    first = mgr.enqueue(req)
                    self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                    second = mgr.enqueue(req)
                self.assertTrue(second.get('accepted'))
                self.assertEqual(str(second.get('policy_decision')), 'started')
                self.assertNotEqual(str(second.get('job_id')), str(first.get('job_id')))
                _wait_worker_quiet(mgr)

    def test_worker_loop_invokes_preflight_before_handling_empty_queue(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        calls = []

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            real_preflight = mgr.preflight_reap_stale_running_jobs

            def _wrap_preflight():
                calls.append(1)
                return real_preflight()

            mgr.preflight_reap_stale_running_jobs = _wrap_preflight
            with patch.object(mgr, '_shadow_pipeline_lock_owner', return_value={}):
                mgr._worker_loop()
        self.assertEqual(calls, [1])

    def test_preflight_recovers_blocked_single_flight_jobs_when_lock_missing(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-blocked-missing-lock',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                _safe_lock = mgr.single_flight_lock_path
                if os.path.exists(_safe_lock):
                    os.remove(_safe_lock)
                recovered = mgr.preflight_reap_stale_running_jobs()
                self.assertEqual(recovered, [])
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'queued')
                self.assertEqual(str(refreshed.get('policy_reason')), 'single_flight_recovered_after_orphan_lock')
                self.assertEqual(int(refreshed.get('recovery_count') or 0), 1)

    def test_preflight_recovers_blocked_single_flight_jobs_when_lock_pid_dead(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-blocked-dead-pid',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    handle.write('{"job_id":"x","pid":"999999","acquired_at_utc":"2026-01-01T00:00:00Z","heartbeat_at_utc":"2026-01-01T00:00:00Z"}')
                mgr.preflight_reap_stale_running_jobs()
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'queued')
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))

    def test_preflight_does_not_recover_blocked_job_when_lock_pid_alive_and_owner_running(self):
        """Stale heartbeat must not orphan when the lock owner job is still running."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        import json
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-blocked-stale-hb-live-pid',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                owner_job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-live-owner',
                }, 'started', 'started_immediately')
                owner_job['job_id'] = 'other-job'
                owner_job['status'] = 'running'
                owner_job['worker_pid'] = str(os.getpid())
                owner_job['started_at_utc'] = str(owner_job.get('created_at_utc') or '')
                mgr._write_job(owner_job)
                live_pid = str(os.getpid())
                lock_body = {
                    'job_id': 'other-job',
                    'pid': live_pid,
                    'acquired_at_utc': '2000-01-01T00:00:00Z',
                    'heartbeat_at_utc': '2000-01-01T00:00:00Z',
                    'acquired_epoch': 946684800.0,
                }
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    handle.write(json.dumps(lock_body))
                mgr.preflight_reap_stale_running_jobs()
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'blocked')
                self.assertTrue(os.path.isfile(mgr.single_flight_lock_path))

    def test_preflight_recovers_blocked_job_when_lock_pid_alive_but_owner_missing(self):
        """Live PID + stale heartbeat should recover when lock owner metadata is stale."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        import json
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_HEARTBEAT_STALE_SEC': '300',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-live-pid-missing-owner',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                lock_body = {
                    'job_id': 'missing-owner-job',
                    'pid': str(os.getpid()),
                    'acquired_at_utc': '2000-01-01T00:00:00Z',
                    'heartbeat_at_utc': '2000-01-01T00:00:00Z',
                    'acquired_epoch': 946684800.0,
                }
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    handle.write(json.dumps(lock_body))
                mgr.preflight_reap_stale_running_jobs()
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'queued')
                self.assertEqual(str(refreshed.get('policy_reason')), 'single_flight_recovered_after_orphan_lock')
                self.assertFalse(os.path.isfile(mgr.single_flight_lock_path))

    def test_acquire_single_flight_open_failure_without_lock_file_returns_false(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                with patch('MediCafe.support_send_jobs.os.open', side_effect=OSError('open failed')):
                    ok = mgr._acquire_single_flight('job-1')
                self.assertFalse(ok)
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))

    def test_list_jobs_recovers_worker_liveness_when_queue_pending(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((str(event_name or ''), dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-worker-liveness',
                }, 'queued', 'queued_jobs_pending')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    mgr.list_jobs(limit=5)
                names = [name for name, _payload in events]
                self.assertIn('worker_liveness_recovered', names)

    def test_ensure_pending_worker_liveness_wakes_queued_job_without_list_jobs(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((str(event_name or ''), dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-autowake-no-list',
                }, 'queued', 'queued_jobs_pending')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    woke = mgr.ensure_pending_worker_liveness(reason='post_update_autofollow_poll')
                self.assertTrue(woke)
                names = [name for name, _payload in events]
                self.assertIn('worker_liveness_recovered', names)

    def test_worker_should_run_preflight_throttled_without_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr.preflight_min_interval_sec = 3600
            mgr._worker_preflight_last_epoch = time.time()
            self.assertFalse(mgr._worker_should_run_preflight())

    def test_worker_should_run_preflight_bypasses_throttle_when_running_job_present(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr.preflight_min_interval_sec = 999999
            mgr._worker_preflight_last_epoch = time.time()
            job = mgr._build_job_record({
                'send_type': 'system_health',
                'anchor_run_id': 'x',
                'layer1_current_blocker': '',
            }, 'queued', 'test')
            job['status'] = 'running'
            mgr._write_job(job)
            self.assertTrue(mgr._worker_should_run_preflight())

    def test_find_existing_job_for_dedup_key_prefers_newest_active(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }
                k = mgr.policy.dedup_key(req)
                old = mgr._build_job_record(req, 'queued', 'x')
                old['job_id'] = 'ssj_old'
                old['status'] = 'queued'
                old['created_epoch'] = 10.0
                old['dedup_key'] = k
                new = dict(old)
                new['job_id'] = 'ssj_new'
                new['created_epoch'] = 20.0
                mgr._write_job(old)
                mgr._write_job(new)
            found = mgr.find_existing_job_for_dedup_key(k)
            self.assertEqual(str(found.get('job_id')), 'ssj_new')

    def test_stuck_reap_preflight_does_not_require_new_enqueue(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '60',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr.running_stale_sec = 60
                job = mgr._build_job_record({
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }, 'queued', 'x')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - 120))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - 120
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = ''
                mgr._write_job(job)
                reaped = mgr.preflight_reap_stale_running_jobs()
                self.assertEqual(reaped, [job_id])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'failed')
