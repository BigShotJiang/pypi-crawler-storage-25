# -*- coding: utf-8 -*-
"""main() finish-coherence and ingest diagnostics stamp coverage (pytest runs unittest)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

from phase_c_common import PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION


class TestIngestFromManifestMainFinish(unittest.TestCase):
    def test_main_exits_on_missing_ingest_diagnostics(self):
        from ingest_from_manifest import main

        lab = tempfile.mkdtemp(prefix="mc_ingest_fin_")
        reports = os.path.join(lab, "reports")
        os.makedirs(reports)
        rid = "finish-miss-1"
        summary = {
            "run_id": rid,
            "manifest_sha256": "abc123",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 0,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        with open(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), "w", encoding="utf-8") as f:
            json.dump(summary, f)
        for name in ("run_cursor.json", "diagnostics_state.json"):
            with open(os.path.join(lab, name), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": rid,
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "abc123",
                    },
                    f,
                )
        argv_bak = sys.argv[:]
        stderr_buf = __import__("io").StringIO()
        try:
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab]
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                with patch("sys.stderr", stderr_buf):
                    with self.assertRaises(SystemExit) as ctx:
                        main()
            self.assertEqual(ctx.exception.code, 1)
            self.assertIn("finish_incoherent", stderr_buf.getvalue())
            self.assertIn("ingest_from_manifest_diagnostics", stderr_buf.getvalue())
        finally:
            sys.argv = argv_bak
            shutil.rmtree(lab, ignore_errors=True)

    def test_main_exits_zero_when_finish_checks_pass(self):
        from ingest_from_manifest import main

        lab = tempfile.mkdtemp(prefix="mc_ingest_fin_ok_")
        reports = os.path.join(lab, "reports")
        os.makedirs(reports)
        rid = "finish-ok-1"
        summary = {
            "run_id": rid,
            "manifest_sha256": "abc123",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 1,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        with open(os.path.join(reports, "ingest_write_summary_{0}.json".format(rid)), "w", encoding="utf-8") as f:
            json.dump(summary, f)
        for fn in (
            "ingest_from_manifest_diagnostics_latest.json",
            "ingest_from_manifest_diagnostics_{0}.json".format(rid),
        ):
            with open(os.path.join(reports, fn), "w", encoding="utf-8") as f:
                json.dump({"schema_version": 1}, f)
        for name in ("run_cursor.json", "diagnostics_state.json"):
            with open(os.path.join(lab, name), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": rid,
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "abc123",
                    },
                    f,
                )
        argv_bak = sys.argv[:]
        try:
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab]
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                main()
        finally:
            sys.argv = argv_bak
            shutil.rmtree(lab, ignore_errors=True)


class TestIngestDiagPointerStamp(unittest.TestCase):
    def test_stamp_skips_corrupt_state_preserves_lineage(self):
        """Corrupt JSON on disk must not be replaced by a near-empty doc (data-loss guard)."""
        from ingest_from_manifest import _write_ingest_from_manifest_diagnostics

        lab = tempfile.mkdtemp(prefix="mc_ingest_stamp_")
        reports = os.path.join(lab, "reports")
        os.makedirs(reports)
        rid = "stamp-skip-1"
        corrupt_marker = '{"last_phase_c_run_id": "KEEP_ME", NOT_JSON'
        state_path = os.path.join(lab, "diagnostics_state.json")
        cursor_path = os.path.join(lab, "run_cursor.json")
        with open(state_path, "w", encoding="utf-8") as f:
            f.write(corrupt_marker)
        with open(cursor_path, "w", encoding="utf-8") as f:
            f.write(corrupt_marker)
        summary = {
            "run_id": rid,
            "manifest_sha256": "deadbeef",
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 0,
            "rows_skipped_duplicate": 0,
            "ok": True,
        }
        try:
            _write_ingest_from_manifest_diagnostics(lab, True, rid, summary, "")
            with open(state_path, "r", encoding="utf-8") as f:
                after_state = f.read()
            with open(cursor_path, "r", encoding="utf-8") as f:
                after_cursor = f.read()
            self.assertIn("KEEP_ME", after_state)
            self.assertIn("KEEP_ME", after_cursor)
            self.assertIn("NOT_JSON", after_state)
        finally:
            shutil.rmtree(lab, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
