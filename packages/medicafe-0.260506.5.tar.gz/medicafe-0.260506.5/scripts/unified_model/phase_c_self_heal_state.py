#!/usr/bin/env python
"""
Phase C self-heal ladder state: circuit breaker, failure counts per B-sha, remediation history.
XP-compatible (Python 3.4.4, stdlib only). Mutates diagnostics_state.json and run_cursor.json.
"""
from __future__ import print_function

import calendar
import json
import os
import re
import shutil
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import iso_utc_now
from phase_c_common import PHASE_C_CIRCUIT_OPEN

try:
    from lab_lock import replace_safe_write
except Exception:
    replace_safe_write = None

_SELF_HEAL_HISTORY_MAX = 50
_PHASE_C_COOLDOWN_ENV = "MEDICAFE_PHASE_C_CIRCUIT_COOLDOWN_HOURS"


def _medicafe_version_string():
    try:
        from MediCafe import __version__ as _mv

        return str(_mv or "").strip() or "unknown"
    except Exception:
        return "unknown"


def _parse_iso_utc_epoch(value):
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        return int(calendar.timegm(time.strptime(raw.replace("Z", ""), "%Y-%m-%dT%H:%M:%S")))
    except Exception:
        return None


def _circuit_cooldown_hours():
    raw = str(os.environ.get(_PHASE_C_COOLDOWN_ENV, "") or "").strip()
    if not raw:
        return 24
    try:
        v = float(raw)
        return max(1.0, v)
    except Exception:
        return 24


def _read_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _safe_write_json(path, doc):
    if replace_safe_write is not None:
        try:
            replace_safe_write(path, doc)
            return True
        except Exception:
            pass
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _merge_doc(path, mutator):
    doc = _read_json_dict(path)
    if not path or (os.path.exists(path) and not isinstance(doc, dict)):
        return False
    if not os.path.exists(path) and not doc:
        doc = {}
    try:
        mutator(doc)
    except Exception:
        return False
    doc["updated_at_utc"] = iso_utc_now()
    return _safe_write_json(path, doc)


def phase_c_circuit_is_open(lab_root):
    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    return bool(st.get("phase_c_circuit_open"))


def maybe_auto_reset_phase_c_circuit(lab_root):
    """
    Auto-reset open circuit when MediCafe version changes or cooldown elapsed.
    Promotes pending Phase B manifest (written under circuit) to canonical pointers.
    Returns True if a reset was applied.
    """
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    st = _read_json_dict(state_path)
    if not st.get("phase_c_circuit_open"):
        return False
    opened_ver = str(st.get("phase_c_circuit_opened_at_medicafe_version") or "").strip()
    opened_at = str(st.get("phase_c_circuit_opened_at_utc") or "").strip()
    cur_ver = _medicafe_version_string()
    now_ep = int(time.time())
    opened_ep = _parse_iso_utc_epoch(opened_at)
    cooldown = _circuit_cooldown_hours()
    version_bump = bool(opened_ver) and opened_ver != cur_ver
    cooldown_ok = False
    if opened_ep is not None:
        cooldown_ok = (now_ep - opened_ep) >= int(cooldown * 3600)
    if not version_bump and not cooldown_ok:
        return False

    def _mut_state(doc):
        hist = doc.get("phase_c_remediation_history")
        if not isinstance(hist, list):
            hist = []
        hist.append(
            {
                "event": "circuit_auto_reset",
                "at_utc": iso_utc_now(),
                "reason": "version_bump" if version_bump else "cooldown",
                "prior_version": opened_ver,
                "current_version": cur_ver,
            }
        )
        doc["phase_c_remediation_history"] = hist[-_SELF_HEAL_HISTORY_MAX:]
        doc["phase_c_circuit_open"] = False
        doc["phase_c_circuit_opened_at_utc"] = ""
        doc["phase_c_circuit_opened_at_medicafe_version"] = ""
        doc["phase_c_self_heal_failure_count_for_b_sha"] = 0
        doc["phase_c_unresolvable_bundle_sent_at_utc"] = ""
        pend_path = str(doc.get("last_discovery_pending_manifest_path") or "").strip()
        pend_sha = str(doc.get("last_discovery_pending_manifest_sha256") or "").strip()
        if pend_path and os.path.isfile(pend_path) and pend_sha:
            doc["last_manifest_path"] = pend_path
            doc["last_manifest_sha256"] = pend_sha
        doc["last_discovery_skipped_due_to_phase_c_circuit"] = False
        doc["last_discovery_pending_manifest_path"] = ""
        doc["last_discovery_pending_manifest_sha256"] = ""
        doc["last_discovery_pending_phase_b_run_id"] = ""

    def _mut_cursor(doc):
        doc["phase_c_circuit_open"] = False
        pend_path = str(doc.get("last_discovery_pending_manifest_path") or "").strip()
        pend_sha = str(doc.get("last_discovery_pending_manifest_sha256") or "").strip()
        if pend_path and os.path.isfile(pend_path) and pend_sha:
            doc["last_manifest_path"] = pend_path
            doc["last_manifest_sha256"] = pend_sha
        doc["last_discovery_skipped_due_to_phase_c_circuit"] = False
        doc["last_discovery_pending_manifest_path"] = ""
        doc["last_discovery_pending_manifest_sha256"] = ""
        doc["last_discovery_pending_phase_b_run_id"] = ""

    changed = _merge_doc(state_path, _mut_state)
    changed = _merge_doc(cursor_path, _mut_cursor) or changed
    return changed


def sync_phase_c_self_heal_tracked_b_sha(lab_root):
    """If Phase B manifest sha changed, reset failure counter for the new lineage."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    st = _read_json_dict(state_path)
    cr = _read_json_dict(cursor_path)
    b_sha = str(st.get("last_manifest_sha256") or cr.get("last_manifest_sha256") or "").strip()
    tracked = str(st.get("phase_c_self_heal_tracked_b_sha") or "").strip()

    if not b_sha or b_sha == tracked:
        return

    def _mut(doc):
        doc["phase_c_self_heal_tracked_b_sha"] = b_sha
        doc["phase_c_self_heal_failure_count_for_b_sha"] = 0

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)


def phase_c_self_heal_failure_count(lab_root):
    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    try:
        return int(st.get("phase_c_self_heal_failure_count_for_b_sha", 0) or 0)
    except Exception:
        return 0


def remediation_tier_for_failure_count(fc):
    """1=default shadow recovery, 2=forced rebuild+integrity, 3=reports quarantine+rediscover, 4=circuit."""
    try:
        n = int(fc)
    except Exception:
        n = 0
    if n >= 3:
        return 4
    return n + 1


def append_phase_c_remediation_event(lab_root, event_dict):
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    def _mut(doc):
        hist = doc.get("phase_c_remediation_history")
        if not isinstance(hist, list):
            hist = []
        ev = dict(event_dict) if isinstance(event_dict, dict) else {}
        ev.setdefault("at_utc", iso_utc_now())
        hist.append(ev)
        doc["phase_c_remediation_history"] = hist[-_SELF_HEAL_HISTORY_MAX:]

    _merge_doc(state_path, _mut)


def increment_phase_c_self_heal_failure(lab_root, pipeline_run_id, detail):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")

    def _mut(doc):
        try:
            fc = int(doc.get("phase_c_self_heal_failure_count_for_b_sha", 0) or 0)
        except Exception:
            fc = 0
        doc["phase_c_self_heal_failure_count_for_b_sha"] = min(fc + 1, 3)

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)
    append_phase_c_remediation_event(
        lab_root,
        {
            "event": "phase_c_failure",
            "pipeline_run_id": str(pipeline_run_id or ""),
            "detail": str(detail or "")[:500],
            "failure_count_after": phase_c_self_heal_failure_count(lab_root),
        },
    )


def reset_phase_c_self_heal_on_success(lab_root, pipeline_run_id):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")

    def _mut(doc):
        doc["phase_c_self_heal_failure_count_for_b_sha"] = 0
        doc["phase_c_circuit_open"] = False
        doc["phase_c_circuit_opened_at_utc"] = ""
        doc["phase_c_circuit_opened_at_medicafe_version"] = ""
        doc["last_discovery_skipped_due_to_phase_c_circuit"] = False

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)
    append_phase_c_remediation_event(
        lab_root,
        {"event": "phase_c_handoff_ok", "pipeline_run_id": str(pipeline_run_id or "")},
    )


def open_phase_c_circuit(lab_root, pipeline_run_id, reason):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    ver = _medicafe_version_string()
    now = iso_utc_now()

    def _mut(doc):
        doc["phase_c_circuit_open"] = True
        doc["phase_c_circuit_opened_at_utc"] = now
        doc["phase_c_circuit_opened_at_medicafe_version"] = ver
        doc["last_phase_c_error_code"] = PHASE_C_CIRCUIT_OPEN

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)
    append_phase_c_remediation_event(
        lab_root,
        {
            "event": "circuit_opened",
            "pipeline_run_id": str(pipeline_run_id or ""),
            "reason": str(reason or "")[:300],
        },
    )


def phase_c_unresolvable_bundle_already_sent(lab_root):
    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    return bool(str(st.get("phase_c_unresolvable_bundle_sent_at_utc") or "").strip())


def stamp_phase_c_unresolvable_bundle_sent(lab_root):
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    def _mut(doc):
        doc["phase_c_unresolvable_bundle_sent_at_utc"] = iso_utc_now()

    _merge_doc(state_path, _mut)


def stamp_phase_c_last_self_heal_telemetry(lab_root, tier_label, outcome):
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    def _mut(doc):
        doc["phase_c_last_self_heal_tier"] = str(tier_label or "")[:80]
        doc["phase_c_last_self_heal_outcome"] = str(outcome or "")[:200]

    _merge_doc(state_path, _mut)


def quarantine_shadow_reports_and_rediscover(lab_root, pipeline_run_id, python_exe, repo_root, env):
    """
    Move shadow report artifacts aside and re-run discover_artifacts.py subprocess.
    Does not touch upstream CSV/DOCX/DAT sources.
    """
    import subprocess

    reports_dir = os.path.join(lab_root, "reports")
    dest_parent = os.path.join(lab_root, "shadow_reports_quarantine")
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(pipeline_run_id or "unknown"))
    dest = os.path.join(dest_parent, safe_rid)
    try:
        if not os.path.isdir(dest_parent):
            os.makedirs(dest_parent)
    except Exception:
        return False, "mkdir_quarantine_failed"
    try:
        if not os.path.isdir(dest):
            os.makedirs(dest)
    except Exception:
        return False, "mkdir_dest_failed"
    prefixes = (
        "artifact_manifest_",
        "ingest_write_summary_",
        "qa_canonical_summary_",
    )
    moved = 0
    if os.path.isdir(reports_dir):
        for name in os.listdir(reports_dir):
            hit = False
            for pfx in prefixes:
                if name.startswith(pfx):
                    hit = True
                    break
            if not hit:
                continue
            src = os.path.join(reports_dir, name)
            if not os.path.isfile(src):
                continue
            dst = os.path.join(dest, name)
            try:
                shutil.move(src, dst)
                moved += 1
            except Exception:
                pass

    def _clear_manifest_keys(doc):
        doc["last_manifest_path"] = ""
        doc["last_manifest_sha256"] = ""
        doc["last_ingest_manifest_path"] = ""
        doc["last_ingest_manifest_sha256"] = ""

    _merge_doc(os.path.join(lab_root, "diagnostics_state.json"), _clear_manifest_keys)
    _merge_doc(os.path.join(lab_root, "run_cursor.json"), _clear_manifest_keys)

    script_path = os.path.join(repo_root, "scripts", "unified_model", "discover_artifacts.py")
    if not os.path.isfile(script_path):
        return False, "discover_script_missing"
    proc_env = env.copy() if isinstance(env, dict) else {}
    proc_env["MEDICAFE_LAB_DIR"] = lab_root
    try:
        rc = subprocess.call([python_exe, script_path], cwd=repo_root, env=proc_env)
    except Exception:
        return False, "discover_subprocess_exception"
    if rc != 0:
        return False, "discover_exit_{0}".format(rc)
    append_phase_c_remediation_event(
        lab_root,
        {
            "event": "tier3_reports_quarantine_rediscover",
            "pipeline_run_id": str(pipeline_run_id or ""),
            "moved_file_count": moved,
        },
    )
    return True, ""


