# MediLink_UI.py
from datetime import datetime
import os, sys
import json
import csv

# Set up paths using core utilities
from MediCafe.core_utils import setup_module_paths
setup_module_paths(__file__)

from MediCafe.core_utils import get_config_loader_with_fallback, extract_medilink_config
MediLink_ConfigLoader = get_config_loader_with_fallback()
import MediLink_DataMgmt
import MediLink_PatientProcessor
import MediLink_Display_Utils

try:
    from MediLink_RemittancePipeline import (
        group_records_for_merge,
        merge_remittance_group,
        canonical_to_posting_row,
    )
except ImportError:
    group_records_for_merge = None
    merge_remittance_group = None
    canonical_to_posting_row = None

try:
    from MediCafe.error_reporter import (
        collect_support_bundle,
        submit_support_bundle_email,
        list_queued_bundles,
        submit_all_queued_bundles,
        resolve_queued_bundles_flow,
        optional_error_report_manifest,
    )
except ImportError:
    collect_support_bundle = None
    submit_support_bundle_email = None
    list_queued_bundles = None
    submit_all_queued_bundles = None
    resolve_queued_bundles_flow = None
    optional_error_report_manifest = None

try:
    from MediCafe.patient_financial_display import get_patient_financial_display
except ImportError:
    get_patient_financial_display = None

def display_welcome():
    print("\n" + "-" * 60)
    print("          *~^~*:    Welcome to MediLink!    :*~^~*")
    print("-" * 60)

def display_menu(options, zero_option=None):
    print("Menu Options:")
    if zero_option is not None:
        print("0. {0}".format(zero_option))
    for i, option in enumerate(options):
        print("{0}. {1}".format(i + 1, option))
    try:
        sys.stdout.flush()
    except Exception:
        pass

def get_user_choice():
    """Get menu choice with flush-safe prompt so it appears under buffered/redirected stdout."""
    prompt = "Enter your choice: "
    try:
        sys.stdout.write(prompt)
        sys.stdout.flush()
    except Exception:
        pass
    return input().strip()

def display_exit_message():
    print("\nExiting MediLink.")

def display_invalid_choice():
    print("Invalid choice. Please select a valid option.")

def prompt_press_enter_to_continue():
    """Single place for 'Press Enter to continue' prompt. ASCII, XP/Python 3.4 compatible."""
    try:
        input("\nPress Enter to continue...")
    except Exception:
        pass

def display_section_header(title):
    """Print a 60-char separator, title, and separator. ASCII-only."""
    print("\n" + "="*60)
    print(title)
    print("="*60)

def display_connectivity_results(connectivity_results):
    """Print connectivity test results dict from MediLink_Down.test_endpoint_connectivity. ASCII-only."""
    print("\nConnectivity Test Results:")
    print("="*60)
    for endpoint, res in connectivity_results.items():
        print("\n{}: {}".format(endpoint, res["status"]))
        for detail in res["details"]:
            print("  - {}".format(detail))
    print("\n" + "="*60)

def view_remittance_summary(config):
    """
    View summary of remittance data from JSONL ledgers.
    Displays file ledger, posting queue, and parsed remittance counts.
    ASCII-only, XP/Python 3.4 compatible.
    """
    medi = extract_medilink_config(config)
    local_storage = medi.get('local_storage_path', '.')
    display_section_header("Remittance Data Summary")

    file_ledger_path = os.path.join(local_storage, 'remittance_file_ledger.jsonl')
    parsed_path = os.path.join(local_storage, 'remittance_parsed.jsonl')

    print("\nFile Ledger:")
    if os.path.exists(file_ledger_path):
        try:
            file_count = 0
            file_types = {}
            with open(file_ledger_path, 'r') as f:
                for line in f:
                    if line.strip():
                        file_count += 1
                        try:
                            record = json.loads(line)
                            ftype = record.get('file_type', 'unknown')
                            file_types[ftype] = file_types.get(ftype, 0) + 1
                        except Exception:
                            pass
            print("  Total files: {}".format(file_count))
            for ftype, count in file_types.items():
                print("    {}: {}".format(ftype, count))
        except Exception as e:
            print("  Error reading file ledger: {}".format(e))
    else:
        print("  No file ledger found. Run 'Sync now' to populate.")

    print("\nExport basis (merged view from remittance_parsed.jsonl):")
    if os.path.exists(parsed_path) and group_records_for_merge and merge_remittance_group:
        try:
            records = []
            with open(parsed_path, 'r') as f:
                for line in f:
                    if line.strip():
                        try:
                            records.append(json.loads(line))
                        except Exception:
                            pass
            groups = group_records_for_merge(records)
            merged_rows = []
            for _gk, rows in groups.items():
                merged_rows.append(merge_remittance_group(rows))
            claim_count = len(merged_rows)
            total_paid = 0.0
            total_allowed = 0.0
            total_patient_resp = 0.0
            for record in merged_rows:
                try:
                    total_paid += float(str(record.get('paid', '0') or '0').replace(',', ''))
                except (ValueError, TypeError, AttributeError):
                    pass
                try:
                    total_allowed += float(str(record.get('allowed', '0') or '0').replace(',', ''))
                except (ValueError, TypeError, AttributeError):
                    pass
                try:
                    total_patient_resp += float(str(record.get('patient_resp', '0') or '0').replace(',', ''))
                except (ValueError, TypeError, AttributeError):
                    pass
            print("  Merged claim groups: {}".format(claim_count))
            print("  Total paid (merged): ${:.2f}".format(total_paid))
            print("  Total allowed (merged): ${:.2f}".format(total_allowed))
            print("  Total patient responsibility (merged): ${:.2f}".format(total_patient_resp))
        except Exception as e:
            print("  Error summarizing parsed remittances: {}".format(e))
    elif os.path.exists(os.path.join(local_storage, 'posting_queue.jsonl')):
        print("  (Legacy) posting_queue.jsonl present; export uses remittance_parsed.jsonl only.")
        print("  Parsed file missing or merge helpers unavailable; sync to refresh remittance_parsed.jsonl.")
    else:
        print("  No remittance_parsed.jsonl yet. Run 'Sync now' to populate.")

    print("\nParsed Remittances:")
    if os.path.exists(parsed_path):
        try:
            record_count = 0
            payer_counts = {}
            with open(parsed_path, 'r') as f:
                for line in f:
                    if line.strip():
                        record_count += 1
                        try:
                            record = json.loads(line)
                            payer = record.get('payer_name', 'unknown')
                            payer_counts[payer] = payer_counts.get(payer, 0) + 1
                        except Exception:
                            pass
            print("  Total records: {}".format(record_count))
            if payer_counts:
                print("  By payer:")
                for payer, count in sorted(payer_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
                    print("    {}: {}".format(payer, count))
        except Exception as e:
            print("  Error reading parsed remittances: {}".format(e))
    else:
        print("  No parsed remittances found. Run 'Sync now' to populate.")

    print("\n" + "="*60)
    prompt_press_enter_to_continue()

def view_remittance_details(config):
    """
    View detailed remittance data with per-file/claim drill-down.
    ASCII-only, XP/Python 3.4 compatible.
    """
    medi = extract_medilink_config(config)
    local_storage = medi.get('local_storage_path', '.')
    parsed_path = os.path.join(local_storage, 'remittance_parsed.jsonl')

    display_section_header("Remittance Details")

    if not os.path.exists(parsed_path):
        print("\nNo parsed remittance data found.")
        print("Run 'Sync now' to download and parse remittances.")
        prompt_press_enter_to_continue()
        return

    try:
        records = []
        with open(parsed_path, 'r') as f:
            for line in f:
                if line.strip():
                    try:
                        records.append(json.loads(line))
                    except Exception:
                        pass

        if not records:
            print("\nNo valid records found in parsed remittances.")
            prompt_press_enter_to_continue()
            return

        print("\nFound {} parsed remittance record(s).".format(len(records)))
        print("\nShowing first 10 records:")
        print("-" * 60)

        for i, record in enumerate(records[:10]):
            print("\nRecord {}:".format(i + 1))
            print("  Payer: {}".format(record.get('payer_name', 'N/A')))
            print("  Claim #: {}".format(record.get('claim_number', 'N/A')))
            print("  Patient: {}".format(record.get('patient_name', 'N/A')))
            print("  DOS: {}".format(record.get('dos', 'N/A')))
            print("  Status: {}".format(record.get('status', 'N/A')))
            print("  Paid: ${}".format(record.get('paid', '0.00')))
            print("  Allowed: ${}".format(record.get('allowed', '0.00')))
            print("  Patient Resp: ${}".format(record.get('patient_resp', '0.00')))

        if len(records) > 10:
            print("\n... and {} more record(s)".format(len(records) - 10))

        print("\n" + "="*60)

    except Exception as e:
        print("\nError reading remittance details: {}".format(e))

    prompt_press_enter_to_continue()

def export_remittance_data(config):
    """
    Export remittance data to CSV format (Option A: remittance_parsed.jsonl only, merged groups).
    ASCII-only, XP/Python 3.4 compatible.
    """
    medi = extract_medilink_config(config)
    local_storage = medi.get('local_storage_path', '.')
    parsed_path = os.path.join(local_storage, 'remittance_parsed.jsonl')

    display_section_header("Export Remittance Data")

    if not os.path.exists(parsed_path):
        print("\nNo remittance_parsed.jsonl found.")
        print("Run 'Sync now' or Claims Inquiry to populate canonical remittance rows first.")
        prompt_press_enter_to_continue()
        return

    if not (group_records_for_merge and merge_remittance_group and canonical_to_posting_row):
        print("\nExport helpers unavailable (MediLink_RemittancePipeline import failed).")
        prompt_press_enter_to_continue()
        return

    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        export_path = os.path.join(local_storage, "remittance_export_{}.csv".format(timestamp))

        records = []
        with open(parsed_path, 'r') as f:
            for line in f:
                if line.strip():
                    try:
                        records.append(json.loads(line))
                    except Exception:
                        pass

        if not records:
            print("\nNo records to export.")
            prompt_press_enter_to_continue()
            return

        groups = group_records_for_merge(records)
        posting_rows = []
        for _gk, rows in groups.items():
            merged = merge_remittance_group(rows)
            posting_rows.append(canonical_to_posting_row(merged))

        with open(export_path, 'w') as csvfile:
            fieldnames = ['patid', 'dos', 'payer_id', 'paid', 'allowed', 'patient_resp', 'status', 'source_claim_number']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames, lineterminator='\n')
            writer.writeheader()
            for record in posting_rows:
                writer.writerow({
                    'patid': record.get('patid', ''),
                    'dos': record.get('dos', ''),
                    'payer_id': record.get('payer_id', ''),
                    'paid': record.get('paid', '0.00'),
                    'allowed': record.get('allowed', '0.00'),
                    'patient_resp': record.get('patient_resp', '0.00'),
                    'status': record.get('status', ''),
                    'source_claim_number': record.get('source_claim_number', '')
                })

        print("\nExported {} merged row(s) (from {} JSONL line(s)) to:".format(len(posting_rows), len(records)))
        print("  {}".format(export_path))

    except Exception as e:
        print("\nError exporting remittance data: {}".format(e))

    prompt_press_enter_to_continue()

def tools_menu(config, medi, claims_ops_handler=None):
    """Low-use maintenance tools submenu."""
    while True:
        display_section_header("Maintenance Tools")
        options = [
            "Rebuild submission index now",
            "Submit Error Report (email)",
            "Resolve Queued Error Reports",
            "Export Humana/Aetna list (by month, printable TXT)",
            "Export NACOR XML",
            "Claim lifecycle & financial operations",
        ]
        display_menu(options, zero_option='Back')
        choice = get_user_choice().strip()
        if choice == '0':
            break
        if choice == '1':
            receipts_root = medi.get('local_claims_path', None)
            if not receipts_root:
                print("No receipts folder configured (local_claims_path missing).")
                continue
            try:
                from MediCafe.submission_index import build_initial_index
                receipts_root = os.path.normpath(receipts_root)
                print("Rebuilding submission index... (this may take a while)")
                count = build_initial_index(receipts_root)
                print("Index rebuild complete. Indexed {} records.".format(count))
            except Exception as e:
                print("Index rebuild error: {}".format(e))
        elif choice == '2':
            if collect_support_bundle is None or submit_support_bundle_email is None:
                print("Error reporting module not available.")
                continue
            try:
                print("\nSubmitting Error Report (email)...")
                zip_path = collect_support_bundle(
                    include_traceback=True,
                    evidence_manifest=optional_error_report_manifest('medilink_ui_manual_report')
                    if optional_error_report_manifest else None,
                )
                if not zip_path:
                    print("Failed to create support bundle.")
                else:
                    ok = submit_support_bundle_email(zip_path)
                    if ok:
                        try:
                            os.remove(zip_path)
                        except Exception:
                            pass
                        print("Error report sent successfully. You do not need to send another report.")
                        prompt_press_enter_to_continue()
                    else:
                        print("Submission failed. Bundle saved at {} for manual handling.".format(zip_path))
            except Exception as e:
                print("Error during email report submission: {}".format(e))
        elif choice == '3':
            if resolve_queued_bundles_flow is None:
                print("Error reporting module not available.")
                continue
            try:
                resolve_queued_bundles_flow()
            except Exception as e:
                print("Error while processing queued bundles: {}".format(e))
        elif choice == '4':
            try:
                from MediLink.MediLink_Humana_Aetna_Export import run_humana_aetna_export
                display_section_header("Humana/Aetna Patient List Export")
                result = run_humana_aetna_export(config)
                if result.get('success'):
                    print("\nExport completed successfully!")
                    print("Total patients: {}".format(result.get('total_patients', 0)))
                    print("Months: {}".format(result.get('months', 0)))
                else:
                    print("\nExport completed with errors. See details above.")
                prompt_press_enter_to_continue()
            except ImportError as e:
                print("Error: Humana/Aetna export module not available: {}".format(e))
            except Exception as e:
                print("Error during Humana/Aetna export: {}".format(e))
                import traceback
                traceback.print_exc()
        elif choice == '5':
            try:
                from MediLink.MediLink_NACOR_Export import run_nacor_export
                display_section_header("NACOR XML Export")
                result = run_nacor_export(config)
                if result.get('success'):
                    print("\nExport completed successfully!")
                else:
                    print("\nExport completed with errors. See summary above.")
                prompt_press_enter_to_continue()
            except ImportError as e:
                print("Error: NACOR export module not available: {}".format(e))
            except Exception as e:
                print("Error during NACOR export: {}".format(e))
                import traceback
                traceback.print_exc()
        elif choice == '6':
            if claims_ops_handler is None:
                print("Claim lifecycle tools are unavailable in this runtime.")
                prompt_press_enter_to_continue()
            else:
                try:
                    claims_ops_handler()
                except Exception as e:
                    print("Claim lifecycle menu error: {}".format(e))
        else:
            display_invalid_choice()

def display_patient_options(detailed_patient_data):
    """
    Displays a list of patients with their current suggested endpoints, prompting for selections to adjust.
    """
    print("\nPlease select the patients to adjust by entering their numbers separated by commas\n(e.g., 1,3,5):")
    # Can disable this extra print for now because the px list would already be on-screen.
    #for i, data in enumerate(detailed_patient_data, start=1):
    #    patient_info = "{0} ({1}) - {2}".format(data['patient_name'], data['patient_id'], data['surgery_date'])
    #    endpoint = data.get('suggested_endpoint', 'N/A')
    #    print("{:<3}. {:<30} Current Endpoint: {}".format(i, patient_info, endpoint))

def get_selected_indices(patient_count):
    """
    Collects user input for selected indices to adjust endpoints.
    
    Args:
        patient_count: Total number of patients available for selection
    
    Returns:
        List of valid zero-based indices selected by the user
    """
    selected_indices_input = input("> ")
    if not selected_indices_input.strip():
        return []
    return _parse_selection_input(selected_indices_input, patient_count)


def _parse_selection_input(raw_input, max_count):
    """
    Parse a selection string like "1,3,6-7" into zero-based indices.
    Returns a list of valid indices; prints warning for invalid entries.
    """
    if not raw_input:
        return []
    raw_input = raw_input.strip()
    if not raw_input:
        return []
    command = raw_input.lower()
    if command == 'all':
        return list(range(max_count))
    if command == 'none':
        return []

    selected_indices = []
    invalid_entries = []
    for part in raw_input.split(','):
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            bounds = part.split('-', 1)
            if len(bounds) != 2:
                invalid_entries.append(part)
                continue
            start_str, end_str = bounds[0].strip(), bounds[1].strip()
            if start_str.isdigit() and end_str.isdigit():
                start_idx = int(start_str) - 1
                end_idx = int(end_str) - 1
                if start_idx > end_idx:
                    start_idx, end_idx = end_idx, start_idx
                for idx in range(start_idx, end_idx + 1):
                    if 0 <= idx < max_count:
                        selected_indices.append(idx)
                    else:
                        invalid_entries.append(part)
                        break
            else:
                invalid_entries.append(part)
        elif part.isdigit():
            idx = int(part) - 1
            if 0 <= idx < max_count:
                selected_indices.append(idx)
            else:
                invalid_entries.append(part)
        else:
            invalid_entries.append(part)
    # De-duplicate while preserving order
    seen = set()
    deduped = []
    for idx in selected_indices:
        if idx not in seen:
            seen.add(idx)
            deduped.append(idx)
    if invalid_entries:
        print("Warning: Invalid entries ignored: {}".format(", ".join(sorted(set(invalid_entries)))))
    return deduped


# Local CLM strings for override gate (must match claim_lifecycle_display vocabulary).
_HIGH_RISK_CLM_STATES = set(['Final', 'Remit'])


def _submit_advisory_from_clm_state(state):
    """Map normalized internal _clm_state to short Advisory column text."""
    s = str(state or '').strip()
    if s == '-' or not s:
        return 'Unknown'
    mapping = {
        'Remit': 'Override',
        'Final': 'Override',
        'Acked': 'Check status',
        'Submitted': 'Check status',
        'Not Sent': 'No local submit',
    }
    return mapping.get(s, 'Unknown')


def _attach_lifecycle_fields_to_rows(rows, config=None):
    """
    Attach _clm_state, _clm_detail, _submit_advisory to normalized row dicts (mutates in place).
    Safe when config is None or lifecycle imports fail.
    """
    if not rows:
        return rows
    if config is None:
        for r in rows:
            if isinstance(r, dict):
                r['_clm_state'] = '-'
                r['_clm_detail'] = '-'
                r['_submit_advisory'] = 'Unknown'
        return rows
    try:
        from MediCafe.claim_lifecycle_display import (
            build_claim_lifecycle_context,
            get_claim_lifecycle_display_for_row,
        )
        ctx = build_claim_lifecycle_context(config=config)
    except Exception:
        for r in rows:
            if isinstance(r, dict):
                r['_clm_state'] = '-'
                r['_clm_detail'] = '-'
                r['_submit_advisory'] = 'Unknown'
        return rows
    for r in rows:
        if not isinstance(r, dict):
            continue
        try:
            payload = get_claim_lifecycle_display_for_row(
                r, context=ctx, state_max=32, detail_max=18
            )
            state = str(payload.get('claim_state_display') or '').strip()
            if state not in ('Not Sent', 'Submitted', 'Acked', 'Final', 'Remit'):
                state = '-'
            r['_clm_state'] = state
            r['_clm_detail'] = str(payload.get('claim_substatus_display') or '')[:18]
            r['_submit_advisory'] = _submit_advisory_from_clm_state(state)
        except Exception:
            r['_clm_state'] = '-'
            r['_clm_detail'] = '-'
            r['_submit_advisory'] = 'Unknown'
    return rows


def _selected_rows_need_lifecycle_override(rows):
    """Return rows where local CLM indicates Final or Remit (override required)."""
    out = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        st = str(r.get('_clm_state') or '').strip()
        if st in _HIGH_RISK_CLM_STATES:
            out.append(r)
    return out


def _confirm_lifecycle_override(risky_rows):
    """
    Prompt for CONFIRM after local Final/Remit warning. ASCII-only.
    """
    n = len(risky_rows or [])
    print("Warning: {} selected row(s) show Final or Remit in local CLM records.".format(n))
    print("This may reflect cached claim status or local ERA/remittance data.")
    for row in (risky_rows or [])[:3]:
        if not isinstance(row, dict):
            continue
        print("  {} | DOS {} | Payer {} | CLM {}".format(
            str(row.get('_display_patient_name', '') or '')[:20],
            str(row.get('_display_dos', '') or '')[:12],
            str(row.get('_display_payer', '') or '')[:12],
            str(row.get('_clm_state', '') or ''),
        ))
    print("Type CONFIRM to continue selecting these rows for submit review:")
    try:
        text = input("> ").strip()
    except Exception:
        text = ''
    if text == 'CONFIRM':
        return True
    print("Override cancelled.")
    return False


def _confirm_selected_rows_for_submit_review(selected_rows, proceed_prompt="Proceed with selected rows? (Y/n): "):
    """
    Standard Y/n then CONFIRM for Final/Remit. Returns True to finalize selection.
    """
    try:
        confirm = input(proceed_prompt).strip().lower()
    except Exception:
        confirm = ''
    if confirm not in ('', 'y', 'yes'):
        print("Selection cancelled.")
        return False
    risky = _selected_rows_need_lifecycle_override(selected_rows)
    if not risky:
        return True
    return _confirm_lifecycle_override(risky)


def _selected_patient_payloads_from_rows(selected_rows):
    """
    Return parsed patient payloads carried by enriched selector rows.
    De-duplicates by object identity while preserving row order.
    """
    payloads = []
    seen = set()
    for row in selected_rows or []:
        if not isinstance(row, dict):
            continue
        payload = row.get('_parsed_patient_data')
        if not isinstance(payload, dict):
            continue
        marker = id(payload)
        if marker in seen:
            continue
        seen.add(marker)
        payloads.append(payload)
    return payloads


def prompt_current_export_parse_failure(consolidated_available):
    """
    When current Z.DAT files exist but parsing produces no actionable rows.
    Returns 'broad' | 'legacy' | 'cancel'.
    """
    print("No patient rows could be parsed from the current Z.DAT export.")
    print("Export files are present but produced no actionable rows.")
    if consolidated_available:
        print("  1/broad Show broader recent claim activity")
    print("  2/legacy Use legacy Z.DAT file picker")
    print("  0/cancel Cancel")
    try:
        ch = get_user_choice().strip().lower()
    except Exception:
        ch = ''
    if ch in ('1', 'broad') and consolidated_available:
        return 'broad'
    if ch in ('2', 'legacy'):
        return 'legacy'
    return 'cancel'


def _display_patient_selection_list(detailed_patient_data):
    """
    Display a simple list of patients in current order for manual selection.
    """
    print("\nSelect patients to submit (examples: 1,3,6-7, all, none).")
    print("{:<3} {:<8} {:<20} {:<12} {:<10}".format("No.", "ID", "Name", "DOS", "Endpoint"))
    print("-" * 60)
    for i, data in enumerate(detailed_patient_data, start=1):
        patient_id = data.get('patient_id', '') or data.get('patid', '')
        patient_name = (data.get('patient_name', '') or '')[:20]
        dos = data.get('surgery_date', '') or ''
        endpoint = data.get('confirmed_endpoint') or data.get('suggested_endpoint', '')
        print("{:<3} {:<8} {:<20} {:<12} {:<10}".format(i, patient_id, patient_name, dos, endpoint))


def _normalize_date_for_filter(value):
    """
    Normalize user-input or row date values to YYYY-MM-DD when possible.
    Returns stripped raw text when parsing fails.
    """
    raw = str(value or '').strip()
    if not raw:
        return ''
    patterns = [
        '%Y-%m-%d', '%Y/%m/%d', '%Y.%m.%d',
        '%m/%d/%Y', '%m-%d-%Y', '%m.%d.%Y',
        '%m/%d/%y', '%m-%d-%y', '%m.%d.%y',
    ]
    for pattern in patterns:
        try:
            return datetime.strptime(raw, pattern).strftime('%Y-%m-%d')
        except Exception:
            continue
    # Already includes time? keep date prefix for filtering.
    if len(raw) >= 10:
        return raw[:10]
    return raw


def _resolve_submission_candidate_endpoint_preview(row, config=None, crosswalk=None):
    """
    Best-effort claim submission endpoint preview for the preselection table.

    The downstream detailed parser remains authoritative; this only uses fields
    already present on consolidated/current-export rows.
    """
    if not isinstance(row, dict):
        return ''

    existing = (
        row.get('confirmed_endpoint') or
        row.get('user_preferred_endpoint') or
        row.get('suggested_endpoint')
    )
    if existing:
        return str(existing).strip()

    payer_id = str(row.get('payer_id') or row.get('primary_payer_id') or '').strip()
    if not payer_id:
        return ''

    legacy_endpoint = ''
    if isinstance(crosswalk, dict):
        try:
            legacy_endpoint = str(
                crosswalk.get('payer_id', {}).get(payer_id, {}).get('endpoint', '') or ''
            ).strip()
        except Exception:
            legacy_endpoint = ''

    if config is not None and crosswalk is not None:
        try:
            from MediCafe.api_core import resolve_operation_route_decision

            class _RoutingClient(object):
                def __init__(self, cfg, cw):
                    self.config = cfg
                    self.crosswalk = cw

            decision = resolve_operation_route_decision(
                _RoutingClient(config, crosswalk),
                payer_id,
                'claim_submission'
            )
            routed = str(decision.get('selected_endpoint') or '').strip()
            if routed:
                return routed
        except Exception:
            pass

    return legacy_endpoint


def _is_current_export_submit_preamble(preamble_kind):
    """True when submit preselection is scoped to current Z.DAT export (compact Rem Amt column)."""
    k = str(preamble_kind or '').strip().lower()
    return k in ('current_export', 'current_export_enriched')


def _submission_financial_patient_id(row):
    """Patid first, then patient_id — matches deductible cache lookup conventions."""
    if not isinstance(row, dict):
        return ''
    pid = str(row.get('patid') or '').strip()
    if pid:
        return pid
    return str(row.get('patient_id') or '').strip()


def _compact_submit_last_column_spec(preamble_kind):
    """
    Last compact column: activity date for broad history, Rem Amt for current export scope.
    Returns dict: header (str), field (row key), width (int).
    """
    if _is_current_export_submit_preamble(preamble_kind):
        return {'header': 'Rem Amt', 'field': '_display_rem_amt', 'width': 10}
    return {'header': 'Date', 'field': '_display_date', 'width': 10}


def _compact_submit_rule_width(last_spec):
    """Total hyphen count for compact submit table rule line."""
    w = int(last_spec.get('width') or 10)
    return 4 + 18 + 10 + 10 + 10 + 6 + w


def _normalize_submission_candidate_row(
    row,
    config=None,
    crosswalk=None,
    financial_display_for_compact=False,
):
    """
    Normalize one consolidated latest-variant row for UI display and filtering.
    """
    if not isinstance(row, dict):
        return None

    claim_key = str(row.get('claim_key') or '').strip()
    claim_key_patient = ''
    if claim_key and '|' in claim_key:
        claim_key_patient = claim_key.split('|', 1)[0].strip()

    patient_name = (
        row.get('patient_name') or
        "{} {}".format(
            row.get('member_first_name', '') or '',
            row.get('member_last_name', '') or ''
        ).strip() or
        row.get('patient_id') or
        row.get('member_id') or
        claim_key_patient or
        'Unknown'
    )
    patient_id = row.get('patient_id') or row.get('member_id') or row.get('patid') or claim_key_patient or ''
    payer = row.get('payer_id') or row.get('primary_insurance') or ''
    dos_norm = _normalize_date_for_filter(row.get('dos') or row.get('service_start_date') or '')
    insurance_type = row.get('insurance_type') or ''
    insurance_source = row.get('insurance_type_source') or ''
    procedure_code = row.get('primary_procedure_code') or row.get('procedure_code') or ''
    amount = row.get('amount') or ''
    duplicate_candidate = row.get('duplicate_candidate')

    first_seen = row.get('first_seen_str') or ''
    latest_seen = row.get('latest_seen_str') or ''
    if not first_seen:
        first_seen = str(row.get('first_seen_at') or '')[:16]
    if not latest_seen:
        latest_seen = str(row.get('latest_seen_at') or '')[:16]
    display_date = str(latest_seen or first_seen or '').strip()

    normalized = dict(row)
    normalized['_display_patient_name'] = str(patient_name or '').strip()
    normalized['_display_patient_id'] = str(patient_id or '').strip()
    normalized['_display_payer'] = str(payer or '').strip()
    normalized['_display_dos'] = dos_norm
    normalized['_display_added'] = str(first_seen or '').strip()
    normalized['_display_latest'] = str(latest_seen or '').strip()
    normalized['_display_date'] = display_date
    normalized['_display_endpoint'] = _resolve_submission_candidate_endpoint_preview(
        row, config=config, crosswalk=crosswalk
    )
    normalized['_display_insurance_type'] = str(insurance_type or '').strip()
    normalized['_display_insurance_source'] = str(insurance_source or '').strip()
    normalized['_display_procedure'] = str(procedure_code or '').strip()
    normalized['_display_amount'] = str(amount or '').strip()
    if duplicate_candidate is True:
        normalized['_display_duplicate'] = 'Y'
    elif duplicate_candidate is False:
        normalized['_display_duplicate'] = 'N'
    else:
        normalized['_display_duplicate'] = '-'
    normalized['_is_actionable'] = bool(
        normalized['_display_patient_id'] or
        (normalized['_display_patient_name'] and normalized['_display_patient_name'].lower() != 'unknown')
    )

    if financial_display_for_compact:
        rem_display = 'N/A'
        if get_patient_financial_display:
            fin_pid = _submission_financial_patient_id(normalized)
            svc_date = normalized.get('_display_dos') or row.get('dos') or row.get('service_start_date')
            try:
                fin_payload = get_patient_financial_display(
                    fin_pid,
                    config=config,
                    service_date=svc_date,
                )
                if isinstance(fin_payload, dict):
                    rem_display = str(fin_payload.get('remaining_amount_display') or 'N/A')
            except Exception:
                rem_display = 'N/A'
        normalized['_display_rem_amt'] = rem_display

    return normalized


def _get_paginated_rows(rows, page_index=0, page_size=12):
    total = len(rows or [])
    if total <= 0:
        return [], 0, 0, 0, 0
    safe_size = max(1, int(page_size or 12))
    total_pages = int((total + safe_size - 1) / safe_size)
    safe_page = max(0, min(int(page_index or 0), total_pages - 1))
    start_idx = safe_page * safe_size
    end_idx = min(start_idx + safe_size, total)
    return rows[start_idx:end_idx], safe_page, total_pages, start_idx, end_idx


def _print_submit_consolidated_preamble(preamble_kind):
    """ASCII preamble for recent activity vs current export scope."""
    k = str(preamble_kind or 'broad').strip().lower()
    if k == 'current_export_enriched':
        print("This list shows patients parsed from your current Z.DAT export files.")
        print("Endpoint and insurance fields came from detailed parse; final confirmation happens later.")
        return
    if k == 'current_export':
        print("This list shows patients parsed from your current Z.DAT export files.")
        print("Review selections before continuing to submit review.")
        print("Endpoint is a routing preview; final confirmation happens after detailed parse.")
        return
    if k == 'none':
        return
    print("This list shows recent claim activity from local submit index, receipts, and DAT sources.")
    print("It is not a guarantee that a row is safe to submit again. Review CLM before selecting.")
    print("CLM is local evidence and may be stale; run Claim Status follow-up if unsure.")
    print("Endpoint is a routing preview; final confirmation happens after detailed parse.")


def _print_consolidated_candidates_table(
    rows,
    title='Recent claim activity',
    compact_mode=True,
    page_index=0,
    page_size=12,
    preamble_kind='broad',
):
    """
    Display recent activity rows for submit preselection (compact unchanged v1; expanded adds CLM/Advisory).
    """
    display_section_header(title)
    _print_submit_consolidated_preamble(preamble_kind)
    if not rows:
        print("No recent claim activity to display.")
        return

    page_rows, safe_page, total_pages, start_idx, end_idx = _get_paginated_rows(
        rows, page_index=page_index, page_size=page_size
    )
    mode_label = "compact" if compact_mode else "expanded"
    print("View: {} | Page {}/{} | Showing rows {}-{} of {}".format(
        mode_label, safe_page + 1, total_pages, start_idx + 1, end_idx, len(rows)
    ))

    if compact_mode:
        last_spec = _compact_submit_last_column_spec(preamble_kind)
        lw = int(last_spec.get('width') or 10)
        hdr = last_spec.get('header') or 'Date'
        fld = last_spec.get('field') or '_display_date'
        print("{:<4} {:<18} {:<10} {:<10} {:<10} {:<6} {:<{lw}}".format(
            'No.', 'Patient', 'DOS', 'Payer', 'Endpoint', 'Ins', hdr, lw=lw
        ))
        print("-" * _compact_submit_rule_width(last_spec))
        for idx, row in enumerate(page_rows, start=1):
            if fld == '_display_rem_amt':
                last_cell = str(row.get('_display_rem_amt') or 'N/A')[:lw]
            else:
                last_cell = str(row.get('_display_date', '') or '')[:lw]
            print("{:<4} {:<18} {:<10} {:<10} {:<10} {:<6} {:<{lw}}".format(
                idx,
                row.get('_display_patient_name', '')[:18],
                row.get('_display_dos', '')[:10],
                row.get('_display_payer', '')[:10],
                str(row.get('_display_endpoint', '') or '-')[:10],
                str(row.get('_display_insurance_type', '') or '-')[:6],
                last_cell,
                lw=lw,
            ))
    else:
        print("{:<4} {:<15} {:<8} {:<10} {:<9} {:<10} {:<5} {:<7} {:<6} {:<8} {:<3} {:<8} {:<10}".format(
            'No.', 'Patient', 'PatientID', 'DOS', 'Payer', 'Endpoint', 'Ins', 'Src', 'Proc', 'Amt', 'Dup', 'CLM', 'Advisory'
        ))
        print("-" * 132)
        for idx, row in enumerate(page_rows, start=1):
            print("{:<4} {:<15} {:<8} {:<10} {:<9} {:<10} {:<5} {:<7} {:<6} {:<8} {:<3} {:<8} {:<10}".format(
                idx,
                row.get('_display_patient_name', '')[:15],
                row.get('_display_patient_id', '')[:8],
                row.get('_display_dos', '')[:10],
                row.get('_display_payer', '')[:9],
                str(row.get('_display_endpoint', '') or '-')[:10],
                str(row.get('_display_insurance_type', '') or '-')[:5],
                str(row.get('_display_insurance_source', '') or '-')[:7],
                str(row.get('_display_procedure', '') or '-')[:6],
                str(row.get('_display_amount', '') or '-')[:8],
                str(row.get('_display_duplicate', '') or '-')[:3],
                str(row.get('_clm_state', '-') or '-')[:8],
                str(row.get('_submit_advisory', 'Unknown') or 'Unknown')[:10],
            ))


def _apply_consolidated_filters(rows, name_filter='', date_filter='', dos_filter=''):
    """
    Apply text/date filters to normalized consolidated rows.
    """
    out = []
    name_filter_l = str(name_filter or '').strip().lower()
    date_norm = _normalize_date_for_filter(date_filter)
    dos_norm = _normalize_date_for_filter(dos_filter)

    for row in rows:
        if not isinstance(row, dict):
            continue

        if name_filter_l:
            patient_name_l = str(row.get('_display_patient_name', '')).lower()
            if name_filter_l not in patient_name_l:
                continue

        if date_norm:
            date_val = _normalize_date_for_filter(row.get('_display_date') or row.get('_display_latest') or row.get('_display_added'))
            if not str(date_val or '').startswith(date_norm):
                continue

        if dos_norm:
            row_dos = _normalize_date_for_filter(row.get('_display_dos') or row.get('dos'))
            if not str(row_dos or '').startswith(dos_norm):
                continue

        out.append(row)
    return out


def _sort_consolidated_rows(rows, sort_mode):
    """
    Supported sort modes:
      - date_desc
      - name_asc
      - dos_desc
    """
    if sort_mode == 'date_desc':
        return sorted(
            rows,
            key=lambda r: str(r.get('_display_date', '') or r.get('_display_latest', '') or r.get('_display_added', '')),
            reverse=True
        )
    if sort_mode == 'name_asc':
        return sorted(
            rows,
            key=lambda r: str(r.get('_display_patient_name', '')).lower()
        )
    if sort_mode == 'dos_desc':
        return sorted(
            rows,
            key=lambda r: str(r.get('_display_dos', '')),
            reverse=True
        )
    return _sort_consolidated_rows(rows, 'date_desc')


def select_patients_from_consolidated_menu(
    consolidated_rows,
    fallback_file_list=None,
    config=None,
    crosswalk=None,
    table_title='Recent claim activity',
    preamble_kind='broad',
    allow_broad_activity=False,
    broad_activity_available=False,
):
    """
    Interactive recent-activity selector used before submit review (broad history or current export rows).

    Returns a dict with:
      - action: 'selected' | 'legacy' | 'legacy_unusable' | 'cancel' | 'refresh' | 'broad_activity'
      - selected_rows: list (only when action == 'selected')
    """
    normalized_rows = []
    skipped_non_actionable = 0
    skipped_examples = []
    financial_display_for_compact = _is_current_export_submit_preamble(preamble_kind)
    for row in consolidated_rows or []:
        norm = _normalize_submission_candidate_row(
            row,
            config=config,
            crosswalk=crosswalk,
            financial_display_for_compact=financial_display_for_compact,
        )
        if norm and norm.get('_is_actionable', True):
            normalized_rows.append(norm)
        elif norm:
            skipped_non_actionable += 1
            if len(skipped_examples) < 3:
                skipped_examples.append(
                    "{}|{}|{}|{}".format(
                        str(norm.get('source') or '').strip() or '-',
                        str(norm.get('claim_key') or '').strip() or '-',
                        str(norm.get('_display_dos') or '').strip() or '-',
                        str(norm.get('_display_payer') or '').strip() or '-'
                    )
                )

    if skipped_non_actionable and MediLink_ConfigLoader:
        try:
            sample_text = ", ".join(skipped_examples) if skipped_examples else "none"
            MediLink_ConfigLoader.log(
                "Submit selector: skipped {} non-actionable consolidated row(s) with missing patient identity. examples={}".format(
                    skipped_non_actionable, sample_text
                ),
                level="INFO"
            )
        except Exception:
            pass

    if not normalized_rows:
        if skipped_non_actionable:
            print("Consolidated rows lacked usable patient identity. Falling back to legacy picker.")
        return {'action': 'legacy_unusable', 'selected_rows': []}

    normalized_rows = _attach_lifecycle_fields_to_rows(normalized_rows, config=config)

    sort_mode = 'date_desc'
    name_filter = ''
    date_filter = ''
    dos_filter = ''
    page_index = 0
    page_size = 12
    compact_mode = True

    while True:
        filtered_rows = _apply_consolidated_filters(
            normalized_rows,
            name_filter=name_filter,
            date_filter=date_filter,
            dos_filter=dos_filter
        )
        visible = _sort_consolidated_rows(filtered_rows, sort_mode)
        page_rows, page_index, total_pages, _start_idx, _end_idx = _get_paginated_rows(
            visible, page_index=page_index, page_size=page_size
        )

        _print_consolidated_candidates_table(
            visible,
            title=table_title,
            compact_mode=compact_mode,
            page_index=page_index,
            page_size=page_size,
            preamble_kind=preamble_kind,
        )
        print("\nSelect patients:")
        print("  Enter row numbers from this page: 1,3,5-7")
        print("  all choose all filtered rows")
        print("\nControls (shortcut):")
        print("  date sort date, sn sort name, sd sort DOS")
        if financial_display_for_compact:
            print("  fn filter name, fdate filter file-activity date, fd filter DOS, clear clear filters")
        else:
            print("  fn filter name, fdate filter date, fd filter DOS, clear clear filters")
        print("  p prev page, n next page, view toggle compact/expanded")
        print("  refresh refresh this list")
        if allow_broad_activity and broad_activity_available:
            print("  broad Show broader recent claim activity")
        if fallback_file_list:
            print("  legacy use legacy Z.DAT file picker")
        print("  0/cancel cancel")
        print("Filters: name='{}' date='{}' dos='{}'".format(
            name_filter or '*', date_filter or '*', dos_filter or '*'
        ))
        choice = get_user_choice().strip().lower()

        if choice in ('0', 'cancel'):
            return {'action': 'cancel', 'selected_rows': []}
        if choice == 'all':
            if not visible:
                print("No rows in current view.")
                continue
            if not _confirm_selected_rows_for_submit_review(
                visible,
                proceed_prompt="Proceed with all {} filtered rows? (Y/n): ".format(len(visible)),
            ):
                continue
            return {
                'action': 'selected',
                'selected_rows': visible,
                'selected_patient_data': _selected_patient_payloads_from_rows(visible),
            }
        if choice == 'select':
            if not page_rows:
                print("No rows in current view.")
                continue
            raw = input("Select row numbers on this page (examples: 1,3,5-7, all, none): ").strip()
            if not raw:
                print("No selection made.")
                continue
            indices = _parse_selection_input(raw, len(page_rows))
            if not indices:
                print("No valid selection.")
                continue
            selected_rows = [page_rows[i] for i in indices]
            print("Selected {} patient row(s).".format(len(selected_rows)))
            if not _confirm_selected_rows_for_submit_review(selected_rows):
                continue
            return {
                'action': 'selected',
                'selected_rows': selected_rows,
                'selected_patient_data': _selected_patient_payloads_from_rows(selected_rows),
            }
        if choice and any(ch.isdigit() for ch in choice):
            if not page_rows:
                print("No rows in current view.")
                continue
            indices = _parse_selection_input(choice, len(page_rows))
            if indices:
                selected_rows = [page_rows[i] for i in indices]
                print("Selected {} patient row(s).".format(len(selected_rows)))
                if not _confirm_selected_rows_for_submit_review(selected_rows):
                    continue
                return {
                    'action': 'selected',
                    'selected_rows': selected_rows,
                    'selected_patient_data': _selected_patient_payloads_from_rows(selected_rows),
                }
            print("No valid row selection.")
            continue
        if choice == 'date':
            sort_mode = 'date_desc'
            page_index = 0
            continue
        if choice == 'sn':
            sort_mode = 'name_asc'
            page_index = 0
            continue
        if choice == 'sd':
            sort_mode = 'dos_desc'
            page_index = 0
            continue
        if choice == 'fn':
            name_filter = input("Enter patient name filter (contains): ").strip()
            page_index = 0
            continue
        if choice == 'fdate':
            date_filter = input("Enter date filter (YYYY-MM-DD): ").strip()
            page_index = 0
            continue
        if choice == 'fd':
            dos_filter = input("Enter DOS filter (YYYY-MM-DD): ").strip()
            page_index = 0
            continue
        if choice == 'clear':
            name_filter = ''
            date_filter = ''
            dos_filter = ''
            page_index = 0
            continue
        if choice == 'p':
            if not visible:
                print("No rows to page.")
                continue
            if page_index > 0:
                page_index -= 1
            continue
        if choice == 'n':
            if not visible:
                print("No rows to page.")
                continue
            if page_index < max(0, total_pages - 1):
                page_index += 1
            continue
        if choice == 'view':
            compact_mode = not compact_mode
            continue
        if choice == 'refresh':
            return {'action': 'refresh', 'selected_rows': []}
        if choice == 'broad' and allow_broad_activity and broad_activity_available:
            return {'action': 'broad_activity', 'selected_rows': []}
        if choice == 'legacy' and fallback_file_list:
            return {'action': 'legacy', 'selected_rows': []}
        display_invalid_choice()


def _print_retry_policy_summary(total_count, retained_count, policy_label):
    excluded_count = max(0, int(total_count) - int(retained_count))
    print("\nRetry filter summary")
    print("-" * 40)
    print("  Total from selected file(s): {}".format(total_count))
    print("  Retained after retry policy: {}".format(retained_count))
    print("  Excluded by retry policy: {}".format(excluded_count))
    print("  Policy mode: {}".format(policy_label))
    print("-" * 40)


def _get_retry_last_choice(config):
    medi_cfg = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
    remember = bool(medi_cfg.get('retry_policy_remember_last_choice', False))
    last_choice = str(medi_cfg.get('retry_policy_last_choice', '') or '').strip()
    # Legacy: 5 was "Cancel submission" before cancel moved to 0
    if last_choice == '5':
        last_choice = '0'
    if not remember or last_choice not in ['0', '1', '2', '3', '4']:
        return '1'
    return last_choice


def _set_retry_last_choice(config, choice):
    try:
        medi_cfg = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
        if bool(medi_cfg.get('retry_policy_remember_last_choice', False)):
            medi_cfg['retry_policy_last_choice'] = str(choice)
    except Exception:
        pass


def backfill_missing_claim_keys(detailed_patient_data):
    """
    Set claim_key on patient dicts when absent, using the same compute_claim_key
    shape as MediLink_PatientProcessor (payer_id blank at parse time).
    Enables retry-policy ledger matching when upstream omitted the key.
    """
    if not detailed_patient_data:
        return
    try:
        from MediCafe.submission_index import compute_claim_key
    except Exception:
        return
    for d in detailed_patient_data:
        if not isinstance(d, dict):
            continue
        if d.get('claim_key'):
            continue
        try:
            pid = str(d.get('patient_id', '') or '').strip()
            ins = str(d.get('primary_insurance', '') or '').strip()
            dos = str(d.get('surgery_date_iso', d.get('surgery_date', '')) or '').strip()
            proc = str(d.get('primary_procedure_code', '') or '').strip()
            key = compute_claim_key(pid, '', ins, dos, proc)
            if any([pid, ins, dos, proc]):
                d['claim_key'] = key
        except Exception:
            pass


def apply_retry_policy(detailed_patient_data, config):
    """
    Apply custody-aware retry policy using submission attempts ledger.
    Returns:
      - filtered list if policy selected
      - original list if no prior attempts or user chooses submit-all
      - None if user cancels
    """
    try:
        from MediCafe import submission_attempts
    except Exception:
        return detailed_patient_data

    backfill_missing_claim_keys(detailed_patient_data)

    # Build claim key list for lookup
    claim_keys = [d.get('claim_key', '') for d in detailed_patient_data if d.get('claim_key')]
    if not claim_keys:
        return detailed_patient_data

    attempts = submission_attempts.load_attempts(config)
    if not attempts:
        return detailed_patient_data

    summary, latest = submission_attempts.summarize_attempts_for_claims(claim_keys, attempts)
    if summary.get("attempted", 0) <= 0:
        return detailed_patient_data

    print("\nPrior submission attempts detected for current patients:")
    print("  In-custody failures: {}".format(summary.get("in_custody", 0)))
    print("  Returned (rejected 277/999): {}".format(summary.get("returned_to_custody", 0)))
    print("  Out-of-custody (submitted/pending): {}".format(summary.get("out_of_custody", 0)))
    print("  No prior attempt: {}".format(summary.get("no_attempt", 0)))

    default_choice = _get_retry_last_choice(config)

    default_hint = " (default)" if default_choice == "1" else ""
    print("\nRetry policy options:")
    print("  0) Cancel submission")
    print("  1) Retry safe failures only{}".format(default_hint))
    print("  2) Retry safe failures + rejected (277/999)")
    print("  3) Manual select patients")
    print("  4) Submit all (ignore prior attempts)")
    choice = input("Select option [{}]: ".format(default_choice)).strip()
    if not choice:
        choice = default_choice
    if choice in ['0', '1', '2', '3', '4']:
        _set_retry_last_choice(config, choice)

    if choice == "0":
        return None
    if choice == "1":
        filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
        _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
        return filtered
    if choice == "2":
        filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=True)
        _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures + rejected")
        return filtered
    if choice == "3":
        _display_patient_selection_list(detailed_patient_data)
        selected = input("> ").strip().lower()
        if not selected:
            print("No selection made. Proceeding with safe failures only.")
            filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
            _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
            return filtered
        indices = _parse_selection_input(selected, len(detailed_patient_data))
        retained_count = len(indices)
        print("Manual selection retained {} patient(s).".format(retained_count))
        confirm_manual = input("Proceed with this selection? (Y/n): ").strip().lower()
        if confirm_manual not in ['', 'y', 'yes']:
            print("Manual selection cancelled. Proceeding with safe failures only.")
            filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
            _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
            return filtered
        filtered = [detailed_patient_data[i] for i in indices]
        _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "manual selection")
        return filtered
    if choice == "4":
        _print_retry_policy_summary(len(detailed_patient_data), len(detailed_patient_data), "submit all")
        return detailed_patient_data
    print("Invalid selection. Proceeding with safe failures only.")
    filtered = submission_attempts.filter_candidates(detailed_patient_data, latest, include_rejected=False)
    _print_retry_policy_summary(len(detailed_patient_data), len(filtered), "safe failures only")
    return filtered

def display_patient_for_adjustment(patient_name, suggested_endpoint):
    """
    Displays the current endpoint for a selected patient and prompts for a change.
    """
    print("\n- {0} | Current Endpoint: {1}".format(patient_name, suggested_endpoint))

def get_endpoint_decision():
    """
    Asks the user if they want to change the endpoint.
    Ensures a valid entry of 'Y' or 'N'.
    """
    while True:
        decision = input("Change endpoint? (Y/N): ").strip().lower()
        if decision in ['y', 'n']:
            return decision
        else:
            print("Invalid input. Please enter 'Y' for Yes or 'N' for No.")

def display_endpoint_options(endpoints_config):
    """
    Displays the endpoint options to the user based on the provided mapping.

    Args:
        endpoints_config (dict): A dictionary mapping endpoint keys to their properties, 
                                 where each property includes a 'name' key for the user-friendly name.
                                 Example: {'Availity': {'name': 'Availity'}, 'OptumEDI': {'name': 'OptumEDI'}, ...}

    Returns:
        None
    """
    print("Select the new endpoint for the patient:")
    for index, (key, details) in enumerate(endpoints_config.items(), 1):
        # Safely get the name, fallback to key if 'name' is missing
        endpoint_name = details.get('name', key) if isinstance(details, dict) else key
        print("{0}. {1}".format(index, endpoint_name))

def get_new_endpoint_choice():
    """
    Gets the user's choice for a new endpoint.
    Single selection only.
    """
    while True:
        choice = input("Select desired endpoint (e.g. 1): ").strip()
        corrected_choice = choice.replace(' ', '')
        if corrected_choice.isdigit():
            return int(corrected_choice)
        else:
            print("Invalid input. Please enter a single number corresponding to the endpoint.")

# Display functions moved to MediLink_Display_Utils.py to eliminate circular dependencies

def extract_patient_last_names(file_path, config, max_names=5):
    """
    Extracts up to max_names unique patient last names from a Z file.
    
    Args:
        file_path: Path to the Z file
        config: Configuration dictionary needed for parsing fixed-width data
        max_names: Maximum number of last names to return (default: 5)
    
    Returns:
        A comma-separated string of last names, or empty string if extraction fails
    """
    # Check if file exists before attempting to read
    if not os.path.exists(file_path):
        return ""
    
    last_names = []
    seen_names = set()
    
    try:
        # Read and parse the fixed-width Z file
        for record_index, record in enumerate(MediLink_DataMgmt.read_fixed_width_data(file_path), start=1):
            if not isinstance(record, tuple) or len(record) != 5:
                try:
                    MediLink_ConfigLoader.log(
                        "extract_patient_last_names: skipping record {} (expected 5-tuple Medisoft row)".format(record_index),
                        level="WARNING",
                    )
                except Exception:
                    pass
                continue
            personal_info, insurance_info, service_info, service_info_2, service_info_3 = record
            try:
                # Parse the fixed-width data to extract patient information
                parsed_data = MediLink_DataMgmt.parse_fixed_width_data(
                    personal_info, insurance_info, service_info,
                    service_info_2, service_info_3, config
                )
                
                # Extract last name from parsed data
                last_name = parsed_data.get('LAST', '').strip()
                
                # Add to list if it's a valid, unique name and we haven't reached the limit
                if last_name and last_name not in seen_names and len(last_names) < max_names:
                    last_names.append(last_name)
                    seen_names.add(last_name)
                    
                    # Early exit if we've collected enough names
                    if len(last_names) >= max_names:
                        break
            except Exception:
                # Skip this record if parsing fails, continue with next
                continue
    except Exception:
        # If file reading fails, return empty string (will be handled gracefully in display)
        return ""
    
    # Return comma-separated list of last names
    return ", ".join(last_names) if last_names else ""

def user_select_files(file_list):
    # Handle empty file list
    if not file_list:
        print("\nNo files available to select.")
        return []
    
    # Load configuration for parsing Z files
    try:
        config, _ = MediLink_ConfigLoader.load_configuration()
    except Exception:
        config = None
    
    # Sort files by creation time in descending order
    file_list = sorted(file_list, key=os.path.getctime, reverse=True)[:10]  # Limit to max 10 files
    
    print("\nSelect the Z-form files to submit from the following list:\n")

    if file_list and config:
        MediLink_ConfigLoader.log("Reading {} fixed-width file(s) for display.".format(len(file_list)), config=config, level="INFO")
    formatted_files = []
    for i, file in enumerate(file_list):
        basename = os.path.basename(file)
        parts = basename.split('_')
        
        # Try to parse the timestamp from the filename
        if len(parts) > 2:
            try:
                timestamp_str = parts[1] + parts[2].split('.')[0]
                timestamp = datetime.strptime(timestamp_str, '%Y%m%d%H%M%S')
                formatted_date = timestamp.strftime('%m/%d %I:%M %p')  # Changed to 12HR format with AM/PM
            except ValueError:
                formatted_date = basename  # Fallback to original filename if parsing fails
        else:
            formatted_date = basename  # Fallback to original filename if no timestamp
        
        # Extract patient last names preview from the Z file
        patient_preview = ""
        if config:
            try:
                last_names_str = extract_patient_last_names(file, config, max_names=5)
                if last_names_str:
                    patient_preview = " - Patients: {}".format(last_names_str)
            except Exception:
                # Silently fail if extraction fails - just show date without preview
                pass
        
        formatted_files.append((formatted_date, file))
        # Display date with patient preview on the same line
        print("{}: {}{}".format(i + 1, formatted_date, patient_preview))
    if file_list and config:
        MediLink_ConfigLoader.log("Successfully read {} fixed-width file(s).".format(len(file_list)), config=config, level="INFO")
    
    selected_indices = input("\nEnter the numbers of the files to process, separated by commas\n(or press Enter to select all): ")
    if not selected_indices:
        return [file for _, file in formatted_files]
    
    # Parse and validate selected indices
    try:
        selected_indices = [int(i.strip()) - 1 for i in selected_indices.split(',')]
        # Validate indices are within range
        valid_indices = [idx for idx in selected_indices if 0 <= idx < len(formatted_files)]
        if not valid_indices:
            print("No valid file selections. Please enter numbers between 1 and {}.".format(len(formatted_files)))
            return []
        if len(valid_indices) < len(selected_indices):
            invalid_count = len(selected_indices) - len(valid_indices)
            print("Warning: {} invalid selection(s) were ignored.".format(invalid_count))
        selected_files = [formatted_files[i][1] for i in valid_indices]
        return selected_files
    except ValueError:
        print("Invalid input. Please enter numbers separated by commas (e.g., 1,3,5).")
        return []


def user_decision_on_suggestions(detailed_patient_data, config, insurance_edited, crosswalk):
    """
    Presents the user with all patient summaries and suggested endpoints,
    then asks for confirmation to proceed with all or specify adjustments manually.
    
    FIXED: Display now properly shows effective endpoints (user preferences over original suggestions)
    """
    if insurance_edited:
        # Display summaries only if insurance types were edited
        MediLink_Display_Utils.display_patient_summaries(detailed_patient_data, config)

    while True:
        proceed_input = input("Do you want to proceed with all suggested endpoints? (Y/N): ").strip().lower()
        if proceed_input in ['y', 'yes']:
            proceed = True
            break
        elif proceed_input in ['n', 'no']:
            proceed = False
            break
        else:
            print("Invalid input. Please enter 'Y' for yes or 'N' for no.")

    # If the user agrees to proceed with all suggested endpoints, confirm them.
    if proceed:
        return MediLink_DataMgmt.confirm_all_suggested_endpoints(detailed_patient_data), crosswalk
    # Otherwise, allow the user to adjust the endpoints manually.
    else:
        return select_and_adjust_files(detailed_patient_data, config, crosswalk)
   

def select_and_adjust_files(detailed_patient_data, config, crosswalk):
    """
    Allows users to select patients and adjust their endpoints by interfacing with UI functions.
    
    FIXED: Now properly updates suggested_endpoint and persists user preferences to crosswalk.
    """
    # Display options for patients
    display_patient_options(detailed_patient_data)

    # Get user-selected indices for adjustment
    selected_indices = get_selected_indices(len(detailed_patient_data))
    
    # Get an ordered list of endpoint keys
    medi = extract_medilink_config(config)
    endpoint_keys = list(medi.get('endpoints', {}).keys())
    
    # Iterate over each selected index and process endpoint changes
    for i in selected_indices:
        data = detailed_patient_data[i]
        current_effective_endpoint = MediLink_PatientProcessor.get_effective_endpoint(data)
        display_patient_for_adjustment(data['patient_name'], current_effective_endpoint)
        
        endpoint_change = get_endpoint_decision()
        if endpoint_change == 'y':
            display_endpoint_options(medi.get('endpoints', {}))
            endpoint_index = get_new_endpoint_choice() - 1  # Adjusting for zero-based index
            
            if 0 <= endpoint_index < len(endpoint_keys):
                selected_endpoint_key = endpoint_keys[endpoint_index]
                print("Endpoint changed to {0} for patient {1}.".format(medi.get('endpoints', {}).get(selected_endpoint_key, {}).get('name', selected_endpoint_key), data['patient_name']))
                
                # Use the new endpoint management system
                updated_crosswalk = MediLink_DataMgmt.update_suggested_endpoint_with_user_preference(
                    detailed_patient_data, i, selected_endpoint_key, config, crosswalk
                )
                if updated_crosswalk:
                    crosswalk = updated_crosswalk
                # STRATEGIC NOTE (Medicare Crossover UI): High-risk implementation requiring strategic decisions
                # 
                # CRITICAL QUESTIONS FOR IMPLEMENTATION:
                # 1. **Crossover Detection**: How to detect Medicare crossover failures?
                #    - Automatic from claim status API responses?
                #    - Manual user indication?
                #    - Time-based detection (no crossover after X days)?
                # 
                # 2. **Secondary Claim Workflow**: How should secondary claim creation be integrated?
                #    - Automatic prompt when crossover failure detected?
                #    - Manual option in patient management interface?
                #    - Batch processing for multiple failed crossovers?
                # 
                # 3. **Data Requirements**: What data is needed for secondary claims?
                #    - Medicare payment amount (required vs optional)?
                #    - Denial/adjustment reasons from Medicare?
                #    - Secondary payer eligibility verification?
                #
                # To implement: Add crossover failure detection and secondary claim creation UI
                # with proper validation and error handling for Medicare -> Secondary workflow
            else:
                print("Invalid selection. Keeping the current endpoint.")
                data['confirmed_endpoint'] = current_effective_endpoint
        else:
            data['confirmed_endpoint'] = current_effective_endpoint

    return detailed_patient_data, crosswalk
