# src/config.py

LANG_PATTERNS = {
    "Python":     ["requirements.txt", "setup.py", "pyproject.toml", "*.py", "Pipfile"],
    "JavaScript": ["package.json", "*.js", ".eslintrc", ".babelrc"],
    "TypeScript": ["tsconfig.json", "*.ts", "*.tsx"],
    "C++":        ["CMakeLists.txt", "*.cpp", "*.hpp", "Makefile"],
    "C":          ["*.c", "*.h", "Makefile"],
    "Rust":       ["Cargo.toml", "*.rs"],
    "Go":         ["go.mod", "*.go"],
    "Java":       ["pom.xml", "build.gradle", "*.java"],
    "HTML/CSS":   ["*.html", "*.css"],
    "Shell":      ["*.sh", "*.bash"],
    "PowerShell": ["*.ps1"],
}

LICENSE_NAMES = {
    "LICENSE":        "Unknown",
    "LICENSE.md":     "Unknown",
    "LICENSE.txt":    "Unknown",
    "LICENSE-MIT":    "MIT",
    "LICENSE-APACHE": "Apache-2.0",
}

SKIP_DIRS = {
    ".git", ".svn", "__pycache__", "node_modules",
    ".venv", "venv", "env", ".env",
    "dist", "build", ".next", ".nuxt",
    "target", "bin", "obj",
    ".idea", ".vscode",
}

SKIP_FILES = {
    ".DS_Store", "Thumbs.db", "desktop.ini",
    "*.pyc", "*.pyo", "*.class", "*.o",
}

DEFAULT_CONFIG = {
    "template":          "standard",
    "output_file":       "README.md",
    "include_tree":      True,
    "max_tree_depth":    3,
    "include_badges":    True,
    "gemini_enabled":    False,
    "author":            "",
    "github_username":   "",
}

TEMPLATES_DIR = "templates"