# src/scanner.py

import os
import sys
import json
from pathlib import Path

from projectreadmegen.config import SKIP_DIRS, SKIP_FILES, DEFAULT_CONFIG


def scan_directory(root_path: str, max_depth: int | None = None) -> dict:
    """
    Walk a directory and collect metadata about its structure.

    Parameters:
        root_path (str): Absolute or relative path to the project root.
        max_depth (int): Maximum depth to traverse. None = unlimited.

    Returns:
        dict: {
            "root": str — absolute path,
            "name": str — folder name (used as project title),
            "files": list[str] — all file names found (not paths),
            "dirs":  list[str] — all directory names found,
            "tree":  str — ASCII tree representation,
            "has_license": bool,
            "has_contributing": bool,
            "has_gitignore": bool,
            "has_existing_readme": bool,
            "file_extensions": list[str] — unique extensions found,
        }
    """
    root = Path(root_path).resolve()
    
    all_files = []
    all_dirs  = []
    extensions = set()
    
    for dirpath, dirnames, filenames in os.walk(root):
        current_depth = len(Path(dirpath).relative_to(root).parts)
        
        if max_depth is not None and current_depth >= max_depth:
            dirnames.clear()
            continue
        
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith('.')]
        
        for filename in filenames:
            if filename.startswith('.') and filename not in ['.gitignore', '.env.example']:
                continue
            
            all_files.append(filename)
            ext = Path(filename).suffix.lower()
            if ext:
                extensions.add(ext)
        
        for dirname in dirnames:
            all_dirs.append(dirname)
    
    tree_str = _build_tree(root, max_depth)
    
    return {
        "root":               str(root),
        "name":               root.name,
        "files":              all_files,
        "dirs":               all_dirs,
        "tree":               tree_str,
        "has_license":        any(f in all_files for f in ["LICENSE", "LICENSE.md", "LICENSE.txt", "license"]),
        "has_contributing":   any(f.upper() in ["CONTRIBUTING.MD", "CONTRIBUTING.TXT"] for f in all_files),
        "has_gitignore":      ".gitignore" in all_files,
        "has_existing_readme": any(f.lower() == "readme.md" for f in all_files),
        "file_extensions":    sorted(list(extensions)),
    }


def _build_tree(root: Path, max_depth: int | None = None, prefix: str = "", current_depth: int = 0) -> str:
    """
    Recursively build an ASCII directory tree string.

    Parameters:
        root (Path): Current directory path.
        max_depth (int): Maximum recursion depth.
        prefix (str): Indentation prefix for the current level.
        current_depth (int): Tracks current recursion depth.

    Returns:
        str: Multi-line ASCII tree string.
    """
    if max_depth is not None and current_depth > max_depth:
        return ""
    
    lines = []
    
    try:
        entries = sorted(root.iterdir(), key=lambda e: (e.is_file(), e.name.lower()))
    except PermissionError:
        return ""
    
    entries = [e for e in entries 
               if not e.name.startswith('.') 
               and e.name not in SKIP_DIRS]
    
    for i, entry in enumerate(entries):
        is_last = (i == len(entries) - 1)
        connector = "└── " if is_last else "├── "
        lines.append(f"{prefix}{connector}{entry.name}")
        
        if entry.is_dir():
            extension = "    " if is_last else "│   "
            subtree = _build_tree(entry, max_depth, prefix + extension, current_depth + 1)
            if subtree:
                lines.append(subtree)
    
    return "\n".join(lines)


def load_config(root_path: str) -> dict:
    """
    Load readmegen.config.json from the project root if it exists,
    otherwise return DEFAULT_CONFIG.

    Parameters:
        root_path (str): Path to the project root.

    Returns:
        dict: Merged configuration (user config overrides defaults).
    """
    config_path = Path(root_path) / "readmegen.config.json"
    config = DEFAULT_CONFIG.copy()
    
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            user_config = json.load(f)
        config.update(user_config)
    
    return config


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "."
    result = scan_directory(path, max_depth=3)
    print(f"Project: {result['name']}")
    print(f"Files found: {len(result['files'])}")
    print(f"Extensions: {result['file_extensions']}")
    print(f"\nTree:\n{result['tree']}")