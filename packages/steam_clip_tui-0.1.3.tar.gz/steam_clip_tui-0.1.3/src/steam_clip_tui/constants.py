"""Platform-specific paths and constants for Steam data."""

import sys
from pathlib import Path


def _steam_base_path() -> Path:
    """Return the platform-specific Steam installation root."""
    if sys.platform == "darwin":
        return Path.home() / "Library/Application Support/Steam"
    if sys.platform == "linux":
        return Path.home() / ".local/share/Steam"
    if sys.platform == "win32":
        import os

        base = os.environ.get("PROGRAMFILES(X86)", "C:\\Program Files (x86)")
        return Path(base) / "Steam"
    raise RuntimeError(f"Unsupported platform: {sys.platform}")


def default_steam_userdata_path() -> Path:
    """Return the default Steam userdata directory for the current platform."""
    return _steam_base_path() / "userdata"


def default_steam_libraryfolders_path() -> Path:
    """Return the default Steam libraryfolders.vdf path for the current platform."""
    return _steam_base_path() / "steamapps" / "libraryfolders.vdf"


CLIP_DIR_PATTERN = "clip_"
THUMBNAIL_FILENAME = "thumbnail.jpg"
CLIP_PROTO_FILENAME = "clip.pb"
SESSION_MPD_FILENAME = "session.mpd"
VIDEO_DIR_NAME = "video"
TIMELINES_DIR_NAME = "timelines"
