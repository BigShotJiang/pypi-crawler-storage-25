"""
aaiclick.data examples package.
"""
