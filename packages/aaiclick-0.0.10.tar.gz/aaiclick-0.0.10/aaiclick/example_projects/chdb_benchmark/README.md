chdb Benchmark
---

Compares aaiclick's Object API against native chdb SQL on identical data (1M rows, 10 runs averaged). Measures ingest, column sum, multiply, filter, sort, count distinct, and group-by operations.

```bash
./chdb_benchmark.sh

# Custom parameters
./chdb_benchmark.sh --rows 500000 --runs 5
```
