"""
Table 1 Generation Tools

Generate baseline characteristics tables for medical papers.
Every tool call records provenance to data-artifacts.yaml for reproducibility.
"""

import os
from collections.abc import Callable
from pathlib import Path
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from med_paper_assistant.infrastructure.persistence.data_artifact_tracker import DataArtifactTracker
from med_paper_assistant.infrastructure.services.analyzer import Analyzer

from .._shared import (
    ensure_project_context,
    get_optional_tool_decorator,
    get_project_list_for_prompt,
    log_tool_call,
    log_tool_error,
    log_tool_result,
    resolve_project_context,
)


def _get_tracker(project_info: dict) -> DataArtifactTracker | None:
    """Create a DataArtifactTracker for the current project, or None if no project."""
    if not project_info or not project_info.get("project_path"):
        return None
    project_dir = Path(project_info["project_path"])
    return DataArtifactTracker(project_dir / ".audit", project_dir)


def register_table_one_tools(
    mcp: FastMCP,
    analyzer: Analyzer,
    *,
    register_public_verbs: bool = True,
) -> dict[str, Callable[..., Any]]:
    """Register Table 1 generation tools."""

    tool = get_optional_tool_decorator(mcp, register_public_verbs=register_public_verbs)

    @tool()
    def generate_table_one(
        filename: str,
        group_col: str,
        continuous_cols: str,
        categorical_cols: str,
        output_name: Optional[str] = None,
        project: Optional[str] = None,
    ) -> str:
        """
        Generate Table 1 (baseline characteristics) with mean±SD, n(%), and p-values.

        Args:
            filename: CSV filename in data/ directory
            group_col: Grouping column name (e.g., "treatment")
            continuous_cols: Comma-separated continuous variables
            categorical_cols: Comma-separated categorical variables
            output_name: Output filename (optional, saves to tables/)
            project: Project slug (uses current if omitted)
        """
        log_tool_call(
            "generate_table_one",
            {
                "filename": filename,
                "group_col": group_col,
                "continuous_cols": continuous_cols,
                "categorical_cols": categorical_cols,
                "project": project,
            },
        )

        _, workflow_error = resolve_project_context(
            project,
            required_mode="manuscript",
        )
        if workflow_error:
            return workflow_error

        project_info = None
        if project:
            is_valid, msg, project_info = ensure_project_context(project)
            if not is_valid:
                return f"❌ {msg}\n\n{get_project_list_for_prompt()}"
        else:
            is_valid, _, project_info = ensure_project_context()

        # Parse column lists
        continuous_list = [c.strip() for c in continuous_cols.split(",") if c.strip()]
        categorical_list = [c.strip() for c in categorical_cols.split(",") if c.strip()]

        if not continuous_list and not categorical_list:
            return "❌ Please specify at least one continuous or categorical column."

        try:
            result = analyzer.generate_table_one(
                filename=filename,
                group_col=group_col,
                continuous_cols=continuous_list,
                categorical_cols=categorical_list,
                output_name=output_name,
            )

            # Record provenance
            tracker = _get_tracker(project_info) if project_info else None
            if tracker:
                params = {
                    "filename": filename,
                    "group_col": group_col,
                    "continuous_cols": continuous_list,
                    "categorical_cols": categorical_list,
                    "output_name": output_name,
                }
                # Compute output path if saved to file
                output_rel = None
                if output_name:
                    oname = output_name if output_name.endswith(".md") else output_name + ".md"
                    output_rel = f"results/tables/{oname}"

                cont_str = ", ".join(f"'{c}'" for c in continuous_list)
                cat_str = ", ".join(f"'{c}'" for c in categorical_list)
                out_arg = f", output_name='{output_name}'" if output_name else ""
                tracker.record_artifact(
                    tool_name="generate_table_one",
                    artifact_type="table",
                    parameters=params,
                    output_path=output_rel,
                    data_source=filename,
                    result_summary=result[:200] if result else None,
                    provenance_code=(
                        f"from med_paper_assistant.infrastructure.services.analyzer import Analyzer\n"
                        f"analyzer = Analyzer()\n"
                        f"result = analyzer.generate_table_one(\n"
                        f"    filename='{filename}',\n"
                        f"    group_col='{group_col}',\n"
                        f"    continuous_cols=[{cont_str}],\n"
                        f"    categorical_cols=[{cat_str}]{out_arg},\n"
                        f")\n"
                        f"print(result)"
                    ),
                )

            # Add usage tips
            tips = "\n\n---\n"
            tips += "💡 **Next Steps:**\n"
            tips += "1. Copy this table to your Methods or Results section\n"
            tips += "2. Use `write_draft` to insert into your manuscript\n"
            tips += "3. Verify variable labels match your study protocol\n"

            log_tool_result("generate_table_one", "success", success=True)
            return result + tips

        except FileNotFoundError as e:
            error_msg = f"❌ Data file not found: {e}\n\nMake sure '{filename}' exists in the data/ directory."
            log_tool_error("generate_table_one", e, {"filename": filename})
            return error_msg
        except KeyError as e:
            error_msg = f"❌ Column not found: {e}\n\nCheck column names in your CSV file."
            log_tool_error("generate_table_one", e, {"filename": filename})
            return error_msg
        except Exception as e:
            error_msg = f"❌ Error generating Table 1: {str(e)}"
            log_tool_error("generate_table_one", e, {"filename": filename})
            return error_msg

    @tool()
    def detect_variable_types(filename: str, project: Optional[str] = None) -> str:
        """
        Analyze CSV and suggest variable types for Table 1 (continuous vs categorical).

        Args:
            filename: CSV filename in data/ directory
            project: Project slug (uses current if omitted)
        """
        import pandas as pd

        log_tool_call("detect_variable_types", {"filename": filename, "project": project})

        _, workflow_error = resolve_project_context(
            project,
            required_mode="manuscript",
        )
        if workflow_error:
            return workflow_error

        if project:
            is_valid, msg, _ = ensure_project_context(project)
            if not is_valid:
                return f"❌ {msg}\n\n{get_project_list_for_prompt()}"

        try:
            df = analyzer.load_data(filename)
        except FileNotFoundError:
            return f"❌ Data file '{filename}' not found in data/ directory."

        output = f"## 📊 Variable Analysis: {filename}\n\n"
        output += f"**Total rows**: {len(df)}\n"
        output += f"**Total columns**: {len(df.columns)}\n\n"

        continuous = []
        categorical = []
        potential_groups = []
        id_cols = []

        for col in df.columns:
            n_unique = df[col].nunique()
            n_missing = df[col].isna().sum()
            dtype = df[col].dtype

            # Detect ID columns (too many unique values)
            if n_unique == len(df) or n_unique > len(df) * 0.9:
                id_cols.append((col, n_unique))
                continue

            # Detect potential grouping variables
            if n_unique <= 5:
                potential_groups.append((col, n_unique, list(df[col].unique())))

            # Classify by type
            if pd.api.types.is_numeric_dtype(dtype):
                if n_unique <= 10:
                    categorical.append((col, n_unique, n_missing))
                else:
                    continuous.append((col, df[col].mean(), df[col].std(), n_missing))
            else:
                categorical.append((col, n_unique, n_missing))

        # Output potential grouping variables
        if potential_groups:
            output += "### 🎯 Potential Grouping Variables\n"
            output += "| Column | Categories | Values |\n"
            output += "|--------|------------|--------|\n"
            for col, n, values in potential_groups:
                values_str = ", ".join(str(v) for v in values[:5])
                if len(values) > 5:
                    values_str += "..."
                output += f"| {col} | {n} | {values_str} |\n"
            output += "\n"

        # Output continuous variables
        if continuous:
            output += "### 📈 Continuous Variables (for mean ± SD)\n"
            output += "| Column | Mean | SD | Missing |\n"
            output += "|--------|------|----|---------|\n"
            for col, mean, std, missing in continuous:
                output += f"| {col} | {mean:.2f} | {std:.2f} | {missing} |\n"
            output += "\n"

        # Output categorical variables
        if categorical:
            output += "### 📊 Categorical Variables (for n (%))\n"
            output += "| Column | Categories | Missing |\n"
            output += "|--------|------------|---------|\n"
            for col, n, missing in categorical:
                output += f"| {col} | {n} | {missing} |\n"
            output += "\n"

        # Skip ID columns
        if id_cols:
            output += "### ⏭️ Skipped (ID/unique columns)\n"
            for col, n in id_cols:
                output += f"- {col} ({n} unique values)\n"
            output += "\n"

        # Generate suggested command
        output += "---\n"
        output += "### 💡 Suggested Command\n\n"

        group_var = potential_groups[0][0] if potential_groups else "GROUP_COLUMN"
        cont_vars = ",".join(c[0] for c in continuous[:5]) if continuous else "age,weight"
        cat_vars = ",".join(c[0] for c in categorical[:5]) if categorical else "sex,diabetes"

        output += "```\n"
        output += "generate_table_one(\n"
        output += f'    filename="{filename}",\n'
        output += f'    group_col="{group_var}",\n'
        output += f'    continuous_cols="{cont_vars}",\n'
        output += f'    categorical_cols="{cat_vars}"\n'
        output += ")\n"
        output += "```\n"

        log_tool_result("detect_variable_types", "success", success=True)
        return output

    @tool()
    def list_data_files(project: Optional[str] = None) -> str:
        """
        List all CSV/Excel files in data/ directory with row/column counts.

        Args:
            project: Project slug (uses current if omitted)
        """
        import pandas as pd

        log_tool_call("list_data_files", {"project": project})

        _, workflow_error = resolve_project_context(
            project,
            required_mode="manuscript",
        )
        if workflow_error:
            return workflow_error

        if project:
            is_valid, msg, _ = ensure_project_context(project)
            if not is_valid:
                return f"❌ {msg}\n\n{get_project_list_for_prompt()}"

        data_dir = analyzer.data_dir
        if not os.path.exists(data_dir):
            return "📁 No data/ directory found.\n\nCreate one and add your CSV files."

        files = [f for f in os.listdir(data_dir) if f.endswith((".csv", ".xlsx", ".xls"))]

        if not files:
            return (
                "📁 No data files found in data/ directory.\n\nSupported formats: .csv, .xlsx, .xls"
            )

        output = "## 📁 Available Data Files\n\n"
        output += "| File | Rows | Columns | Size |\n"
        output += "|------|------|---------|------|\n"

        for f in sorted(files):
            filepath = os.path.join(data_dir, f)
            size = os.path.getsize(filepath)
            size_str = (
                f"{size / 1024:.1f} KB" if size < 1024 * 1024 else f"{size / 1024 / 1024:.1f} MB"
            )

            try:
                if f.endswith(".csv"):
                    df = pd.read_csv(filepath)
                else:
                    df = pd.read_excel(filepath)
                output += f"| {f} | {len(df)} | {len(df.columns)} | {size_str} |\n"
            except Exception:
                output += f"| {f} | Error | - | {size_str} |\n"

        output += "\n💡 Use `detect_variable_types(filename)` to analyze a file's structure."

        log_tool_result("list_data_files", f"found {len(files)} files", success=True)
        return output

    return {
        "generate_table_one": generate_table_one,
        "detect_variable_types": detect_variable_types,
        "list_data_files": list_data_files,
    }
