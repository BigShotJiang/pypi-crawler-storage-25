import os
import re


def method_allowed(func):
    def wrapper(self, *args, **kwargs):
        if hasattr(self, 'allowed_methods') and self.allowed_methods is not None:
            if func.__name__ not in self.allowed_methods:
                raise AttributeError(f"Method '{func.__name__}' is not allowed.")
        return func(self, *args, **kwargs)

    return wrapper


class RepositoryManager:
    allowed_methods = ['get', 'values', 'filter', 'create', 'update', 'delete']

    def __init__(self):
        self.table = self.__class__.data_source(
            table_name=self.__class__.__name__
        )
        self.objects = self.Objects(
            parent=self,
            allowed_methods=getattr(self, 'allowed_methods', None)
        )

    class Objects:
        def __init__(self, parent, allowed_methods=None):
            self.parent = parent
            self.allowed_methods = allowed_methods

        def _escape_value(self, value) -> str:
            if value is None:
                return 'null'
            return re.sub(r'([\\(),~])', r'\\\1', str(value))

        @method_allowed
        def get(self, **kwargs):
            if not kwargs:
                return self.parent.table.data
            items = self._execute_filter(limit=1, **kwargs)
            if items:
                return items if isinstance(items, list) else items
            raise KeyError(f'No item found matching {kwargs}')

        @method_allowed
        def values(self, *args):
            fields = list(args) if args else None
            return self.parent.table.values(fields=fields)

        @method_allowed
        def filter(self, **kwargs):
            return self._execute_filter(**kwargs)

        def _execute_filter(self, limit=None, **kwargs):
            if not kwargs:
                return self.parent.table.data

            expression_list = []
            supported_operators = {
                '__gt': 'gt', '__gte': 'gte',
                '__lt': 'lt', '__lte': 'lte',
                '__ne': 'ne', '__like': 'like',
                '__date_gt': 'gt', '__date_gte': 'gte',
                '__date_lt': 'lt', '__date_lte': 'lte'
            }

            for field, value in kwargs.items():
                if field.endswith('__in'):
                    clean_field = field.replace('__in', '')
                    if isinstance(value, (list, tuple, set)):
                        escaped_values = [self._escape_value(v) for v in value]
                        in_exp = '~or'.join([f'({clean_field},eq,{v})' for v in escaped_values])
                        expression_list.append(f'({in_exp})')

                elif any(field.endswith(suffix) for suffix in supported_operators):
                    suffix = next(s for s in supported_operators if field.endswith(s))
                    clean_field = field.replace(suffix, '')
                    api_operator = supported_operators[suffix]
                    escaped_value = self._escape_value(value)

                    if 'date_' in suffix:
                        expression_list.append(f'({clean_field},{api_operator},exactDate,{escaped_value})')
                    else:
                        expression_list.append(f'({clean_field},{api_operator},{escaped_value})')

                else:
                    expression_list.append(f'({field},eq,{self._escape_value(value)})')

            expression = '~and'.join(expression_list)

            if limit is not None and hasattr(self.parent.table, 'filter_with_limit'):
                return self.parent.table.filter_with_limit(where=expression, limit=limit)

            return self.parent.table.filter(where=expression)

        @method_allowed
        def create(self, **kwargs):
            if not kwargs:
                raise Exception('Append is broken: undefined target')
            return self.parent.table.append(target=kwargs)

        @method_allowed
        def update(self, target=None, **kwargs):
            data = target if target is not None else kwargs
            if not data or ('Id' not in data and 'id' not in data):
                raise AttributeError("Update requires an ID (Primary Key) in target data.")
            return self.parent.table.update(target=data)

        @method_allowed
        def delete(self, Id: int):
            if not Id:
                raise AttributeError("Delete requires a valid record ID.")
            return self.parent.table.delete(target={'Id': Id})

        @method_allowed
        def upload(self, file, filename=None):
            if hasattr(file, 'read'):
                content = file.read()
                name = filename or getattr(file, 'name', 'upload_file')
            else:
                with open(file, 'rb') as f:
                    content = f.read()
                    name = filename or os.path.basename(file)
            return self.parent.table.upload(content, name)