import numba


# ensures a consistent Numba type signature for functions passed into jitted functions
# this is used for the metrics argument in combined_metric()
def typed_metric_wrapper(f):
    return numba.jit("f4(f4[:],f4[:])")(f.py_func)


def partial_metric(dist_fn, kwargs: dict):
    args = tuple(kwargs.values())

    @numba.njit("f4(f4[:],f4[:])")
    def d(x, y):
        return dist_fn(x, y, *args)

    return d


# used for the metrics argument in combined_metric_sparse()
# adds n_features param for a consistent type signature
def typed_metric_wrapper_sparse(f):
    @numba.njit
    def wrapper(ind1, data1, ind2, data2, n_features):
        return f(ind1, data1, ind2, data2)

    return typed_metric_wrapper_sparse_n_features(wrapper)


# used for the metrics argument in combined_metric_sparse()
def typed_metric_wrapper_sparse_n_features(f):
    return numba.jit("f4(i4[::1],f4[::1],i4[::1],f4[::1],i4)")(f.py_func)


def partial_metric_sparse(dist_fn, kwargs: dict):
    args = tuple(kwargs.values())

    @numba.njit("f4(i4[::1],f4[::1],i4[::1],f4[::1])")
    def d(ind1, data1, ind2, data2):
        return dist_fn(ind1, data1, ind2, data2, *args)

    return d


def partial_metric_sparse_n_features(dist_fn, kwargs: dict):
    args = tuple(kwargs.values())

    @numba.njit("f4(i4[::1],f4[::1],i4[::1],f4[::1],i4)")
    def d(ind1, data1, ind2, data2, n_features):
        return dist_fn(ind1, data1, ind2, data2, n_features, *args)

    return d
