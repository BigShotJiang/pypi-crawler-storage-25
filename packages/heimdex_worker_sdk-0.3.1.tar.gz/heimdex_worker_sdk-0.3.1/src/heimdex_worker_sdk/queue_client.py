"""
Queue-agnostic client protocol for Heimdex workers.

Defines ``QueueMessage`` and ``QueueClient`` — the abstraction layer that
lets workers run on SQS, RabbitMQ, or any other message broker without
code changes.  Concrete implementations live in ``sqs_client.py`` and
``rabbitmq_client.py``.

The ``QueueDepth`` dataclass supports the GPU orchestrator's queue-depth
polling for auto-start/stop decisions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Protocol, runtime_checkable


@dataclass(frozen=True)
class QueueMessage:
    """Queue-agnostic message container.

    Attributes:
        message_id: Unique message identifier assigned by the broker.
        ack_id: Opaque token used to acknowledge or extend the message.
            SQS: ``receipt_handle``.  RabbitMQ: ``delivery_tag``.
        body: Parsed JSON message body.
        receive_count: Approximate number of times this message has been
            delivered (includes the current delivery).
    """

    message_id: str
    ack_id: str
    body: dict[str, Any]
    receive_count: int


@dataclass(frozen=True)
class QueueDepth:
    """Snapshot of a queue's backlog.

    Used by the GPU orchestrator to decide when to start/stop workers.
    """

    waiting: int
    """Messages ready for consumption."""

    in_flight: int
    """Messages currently being processed (not yet acknowledged)."""


@runtime_checkable
class QueueClient(Protocol):
    """Protocol for queue backends (SQS, RabbitMQ, etc.).

    Implementations must provide all five methods.  The consumer loop,
    visibility heartbeat, and message adapters depend only on this
    protocol — never on a concrete client class.
    """

    def receive_jobs(
        self,
        max_messages: int = 1,
        wait_time: int = 20,
        visibility_timeout: int = 60,
    ) -> list[QueueMessage]:
        """Long-poll the queue for messages.

        Returns an empty list when ``wait_time`` expires with no messages.
        """
        ...

    def complete_job(self, ack_id: str) -> None:
        """Acknowledge a successfully processed message (delete/ack)."""
        ...

    def extend_visibility(self, ack_id: str, timeout: int) -> None:
        """Extend the processing lease for an in-flight message.

        SQS: ``ChangeMessageVisibility``.
        RabbitMQ: no native equivalent — implementations may nack+requeue
        or rely on consumer timeout configuration.
        """
        ...

    def send_job(
        self,
        body: dict[str, Any],
        deduplication_id: Optional[str] = None,
    ) -> str:
        """Publish a job message.  Returns the broker-assigned message ID."""
        ...

    def get_queue_depth(self) -> QueueDepth:
        """Return current queue backlog for orchestrator decisions."""
        ...
