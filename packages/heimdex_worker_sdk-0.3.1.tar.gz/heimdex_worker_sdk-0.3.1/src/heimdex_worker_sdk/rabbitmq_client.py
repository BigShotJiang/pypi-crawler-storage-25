"""
RabbitMQ client implementing the ``QueueClient`` protocol.

Uses ``pika`` (AMQP 0-9-1) for communication.  Designed to be a drop-in
replacement for ``SQSJobClient`` in on-premise deployments where AWS SQS
is not available.

Key semantic mappings:
  - ``complete_job`` → ``basic_ack``
  - ``extend_visibility`` → no-op (RabbitMQ uses consumer ack timeout
    configured at the queue level via ``x-consumer-timeout``)
  - ``receive_jobs`` → ``basic_get`` (polling, not push-based)
  - ``send_job`` → ``basic_publish``
  - ``get_queue_depth`` → ``queue_declare(passive=True)``
"""

import json
import logging
import uuid
from typing import Any, Optional

import pika
import pika.exceptions

from .queue_client import QueueDepth, QueueMessage

logger = logging.getLogger(__name__)


class RabbitMQJobClient:
    """RabbitMQ implementation of the ``QueueClient`` protocol.

    Args:
        host: RabbitMQ server hostname.
        port: AMQP port (default 5672).
        username: Auth username (default ``"guest"``).
        password: Auth password (default ``"guest"``).
        vhost: Virtual host (default ``"/"``).
        queue_name: Queue to consume from / publish to.
        durable: Whether the queue is durable (default ``True``).
        prefetch_count: Consumer prefetch limit (default ``1``).
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 5672,
        username: str = "guest",
        password: str = "guest",
        vhost: str = "/",
        queue_name: str = "",
        durable: bool = True,
        prefetch_count: int = 1,
    ) -> None:
        self._queue_name = queue_name
        self._durable = durable
        self._prefetch_count = prefetch_count

        self._credentials = pika.PlainCredentials(username, password)
        self._params = pika.ConnectionParameters(
            host=host,
            port=port,
            virtual_host=vhost,
            credentials=self._credentials,
            heartbeat=600,
            blocked_connection_timeout=300,
            connection_attempts=3,
            retry_delay=2,
        )
        self._connection: Optional[pika.BlockingConnection] = None
        self._channel: Optional[pika.adapters.blocking_connection.BlockingChannel] = None

    def _ensure_connection(self) -> pika.adapters.blocking_connection.BlockingChannel:
        """Lazily connect and declare the queue.  Reconnects on failure."""
        if self._connection is not None and self._connection.is_open:
            if self._channel is not None and self._channel.is_open:
                return self._channel

        try:
            self._connection = pika.BlockingConnection(self._params)
            self._channel = self._connection.channel()
            self._channel.basic_qos(prefetch_count=self._prefetch_count)
            self._channel.queue_declare(
                queue=self._queue_name, durable=self._durable
            )
            return self._channel
        except pika.exceptions.AMQPConnectionError as e:
            logger.error("rabbitmq_connection_failed", extra={"error": str(e)})
            raise

    # ── Consumer operations ───────────────────────────────────────────

    def receive_jobs(
        self,
        max_messages: int = 1,
        wait_time: int = 20,
        visibility_timeout: int = 60,
    ) -> list[QueueMessage]:
        """Poll the queue for messages using ``basic_get``.

        RabbitMQ's ``basic_get`` is non-blocking (returns immediately).
        To emulate SQS long-polling behavior, we poll in a loop with
        short sleeps up to ``wait_time`` seconds.
        """
        channel = self._ensure_connection()
        messages: list[QueueMessage] = []
        import time

        deadline = time.monotonic() + wait_time
        attempts = 0

        while len(messages) < max_messages:
            method, properties, body_bytes = channel.basic_get(
                queue=self._queue_name, auto_ack=False
            )

            if method is not None:
                try:
                    body = json.loads(body_bytes)
                except (json.JSONDecodeError, TypeError):
                    logger.warning(
                        "rabbitmq_invalid_message_body",
                        extra={"delivery_tag": method.delivery_tag},
                    )
                    channel.basic_nack(
                        delivery_tag=method.delivery_tag, requeue=False
                    )
                    continue

                # RabbitMQ doesn't track receive count natively.
                # Use x-death header count if available (from DLX redelivery),
                # otherwise default to 1.
                receive_count = 1
                if properties.headers and "x-death" in properties.headers:
                    try:
                        receive_count = sum(
                            d.get("count", 0)
                            for d in properties.headers["x-death"]
                        ) + 1
                    except (TypeError, KeyError):
                        pass
                elif method.redelivered:
                    receive_count = 2

                messages.append(
                    QueueMessage(
                        message_id=properties.message_id or str(method.delivery_tag),
                        ack_id=str(method.delivery_tag),
                        body=body,
                        receive_count=receive_count,
                    )
                )
            else:
                # No message available — sleep briefly then retry
                if time.monotonic() >= deadline:
                    break
                time.sleep(min(0.5, deadline - time.monotonic()))
                attempts += 1

        return messages

    def complete_job(self, ack_id: str) -> None:
        """Acknowledge a message (removes it from the queue)."""
        channel = self._ensure_connection()
        channel.basic_ack(delivery_tag=int(ack_id))

    def extend_visibility(self, ack_id: str, timeout: int) -> None:
        """No-op for RabbitMQ.

        RabbitMQ manages message redelivery via consumer ack timeout
        (``x-consumer-timeout`` queue argument or ``consumer_timeout``
        in rabbitmq.conf).  There is no per-message visibility extension.

        The heartbeat mechanism in ``ConsumerLoop`` still calls this
        periodically, but it has no effect on RabbitMQ.
        """
        pass

    # ── Producer operations ───────────────────────────────────────────

    def send_job(
        self,
        body: dict[str, Any],
        deduplication_id: Optional[str] = None,
    ) -> str:
        """Publish a message to the queue.  Returns a generated message ID."""
        channel = self._ensure_connection()
        message_id = deduplication_id or str(uuid.uuid4())

        channel.basic_publish(
            exchange="",
            routing_key=self._queue_name,
            body=json.dumps(body, default=str),
            properties=pika.BasicProperties(
                delivery_mode=2,  # persistent
                content_type="application/json",
                message_id=message_id,
            ),
        )
        return message_id

    # ── Orchestrator operations ──────────────────────────────────────

    def get_queue_depth(self) -> QueueDepth:
        """Return queue depth via passive ``queue_declare``."""
        channel = self._ensure_connection()
        result = channel.queue_declare(
            queue=self._queue_name, durable=self._durable, passive=True
        )
        return QueueDepth(
            waiting=result.method.message_count,
            in_flight=result.method.consumer_count,
        )

    # ── Lifecycle ────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the connection gracefully."""
        if self._connection and self._connection.is_open:
            try:
                self._connection.close()
            except Exception:
                pass
        self._connection = None
        self._channel = None
