# Heimdex Worker SDK

Shared worker utilities for the Heimdex ecosystem.

## Quick Reference

```bash
pip install -e ".[dev]"
pytest -v
```

## Design Philosophy

This package provides shared infrastructure for Heimdex workers:
- S3/MinIO dual-mode client
- SQS consumer with heartbeat and visibility extension
- Aircloud GPU worker lifecycle management (start/stop/scale)
- Internal API client for livecommerce endpoints
- Deterministic S3 key generation helpers
- MIME type classification

Dependencies are intentionally minimal: `pydantic-settings`, `boto3`, `requests`.

## Package Structure

```
src/heimdex_worker_sdk/
├── aircloud_client.py    # Aircloud External API (start/stop/scale/status)
├── gpu_orchestrator.py   # Auto start/stop GPU workers based on SQS queue depth
├── sqs_client.py         # Thin boto3 SQS wrapper
├── sqs_consumer.py       # Background SQS polling loop with heartbeat
├── s3.py                 # S3/MinIO dual-mode client
├── settings.py           # WorkerSettings (pydantic-settings, 60+ env vars)
├── internal_api.py       # HTTP client for livecommerce /internal/drive/* endpoints
├── drive_keys.py         # Deterministic S3 key generation (Drive files)
├── youtube_keys.py       # S3 key generation (YouTube files)
├── youtube_api.py        # HTTP client for YouTube internal endpoints
├── content_type.py       # MIME type classification
└── message_adapters.py   # SQS message → dataclass converters
```

## Consumers

Changes here affect ALL downstream repos. Always verify impact before merging.

| Consumer | What it uses |
|---------|-------------|
| dev-heimdex-for-livecommerce (8 workers + API) | Full SDK |
| dev-heimdex-playground | aircloud_client, gpu_orchestrator |

## Release

- Trigger: Git tag `v*`
- Pipeline: Test -> Build -> Publish to PyPI -> GitHub Release
- Current version: 0.2.0

### Worker registration (GPU orchestrator)

Adding a new GPU worker means touching **three places** in lockstep so the orchestrator can wake/stop it:

1. `gpu_orchestrator._GPU_JOB_TYPES` — maps job type string to `WorkerSettings` attr for the queue URL
2. `gpu_orchestrator._JOB_TYPE_TO_WORKER` — maps job type string to worker name (usually identical)
3. `settings.WorkerSettings` — add `sqs_<worker>_queue_url` and `aircloud_endpoint_<worker>` fields

Example: v0.2.0 added `"blur"` entry to both dicts plus `sqs_blur_queue_url`, `aircloud_endpoint_blur`, `blur_enabled`, `drive_blur_concurrency`, `blur_owl_*`, and `blur_allow_cpu` fields. Downstream consumers (api, drive-worker) automatically pick up new workers via `getattr(settings, f"aircloud_endpoint_{name}", "")` so no consumer code changes are needed — just bump the pin and set the env vars.

## Rules

- Keep dependencies minimal (no torch, cv2, or heavy ML libs)
- All Aircloud calls must be fire-and-forget (never block ingest)
- GPU orchestrator settings are injected via `configure_settings_provider()`, not hardcoded imports
- Version bumps must consider downstream consumer compatibility
- **`AircloudClient.start/stop/get_status(endpoint_id)`**: `endpoint_id` is the management-API UUID, which in Aircloud's current schema IS the container UUID (same identifier serves control and serving planes). Stable across container restarts; changes on delete+recreate.
- **Staging override mount**: `dev-heimdex-for-livecommerce/docker-compose.override.yml` mounts this repo as an editable install into drive-worker / drive-ocr-worker / drive-blur-worker. Bumping the Dockerfile pin has no effect on staging — the mount wins. To ship a fix to staging: `git pull` on `/opt/heimdex/heimdex-worker-sdk/` on the EC2 host, then restart the affected container. Production baking is different (not shadowed).
