"""Tests for RabbitMQJobClient — mocked pika, no real broker needed."""

import json
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from heimdex_worker_sdk.rabbitmq_client import RabbitMQJobClient
from heimdex_worker_sdk.queue_client import QueueClient, QueueDepth, QueueMessage


class TestRabbitMQProtocolConformance:
    """Verify RabbitMQJobClient satisfies QueueClient protocol."""

    def test_is_queue_client(self):
        assert issubclass(RabbitMQJobClient, QueueClient)

    def test_instance_check(self):
        with patch("pika.BlockingConnection"):
            client = RabbitMQJobClient(queue_name="test")
            assert isinstance(client, QueueClient)


class TestReceiveJobs:
    """Test receive_jobs with mocked pika channel."""

    def _make_client(self):
        with patch("pika.BlockingConnection") as mock_conn:
            client = RabbitMQJobClient(queue_name="heimdex.test")
            mock_channel = MagicMock()
            mock_channel.is_open = True
            mock_conn.return_value.is_open = True
            mock_conn.return_value.channel.return_value = mock_channel
            client._connection = mock_conn.return_value
            client._channel = mock_channel
            return client, mock_channel

    def test_returns_parsed_message(self):
        client, channel = self._make_client()
        body = {"file_id": "abc-123", "org_id": "org-1"}
        method = MagicMock()
        method.delivery_tag = 42
        method.redelivered = False
        props = MagicMock()
        props.message_id = "msg-001"
        props.headers = None

        # First call returns message, second returns empty (breaks loop)
        channel.basic_get.side_effect = [
            (method, props, json.dumps(body).encode()),
            (None, None, None),
        ]

        messages = client.receive_jobs(max_messages=1, wait_time=0)
        assert len(messages) == 1
        msg = messages[0]
        assert isinstance(msg, QueueMessage)
        assert msg.message_id == "msg-001"
        assert msg.ack_id == "42"
        assert msg.body == body
        assert msg.receive_count == 1

    def test_returns_empty_on_timeout(self):
        client, channel = self._make_client()
        channel.basic_get.return_value = (None, None, None)

        messages = client.receive_jobs(max_messages=1, wait_time=0)
        assert messages == []

    def test_skips_invalid_json(self):
        client, channel = self._make_client()
        method = MagicMock()
        method.delivery_tag = 1
        props = MagicMock()
        props.headers = None

        channel.basic_get.side_effect = [
            (method, props, b"not json"),
            (None, None, None),
        ]

        messages = client.receive_jobs(max_messages=1, wait_time=0)
        assert messages == []
        channel.basic_nack.assert_called_once_with(delivery_tag=1, requeue=False)

    def test_redelivered_increments_count(self):
        client, channel = self._make_client()
        body = {"key": "val"}
        method = MagicMock()
        method.delivery_tag = 5
        method.redelivered = True
        props = MagicMock()
        props.message_id = "msg-002"
        props.headers = None

        channel.basic_get.side_effect = [
            (method, props, json.dumps(body).encode()),
            (None, None, None),
        ]

        messages = client.receive_jobs(max_messages=1, wait_time=0)
        assert messages[0].receive_count == 2


class TestCompleteJob:
    def test_acks_message(self):
        with patch("pika.BlockingConnection"):
            client = RabbitMQJobClient(queue_name="test")
            mock_channel = MagicMock()
            mock_channel.is_open = True
            client._connection = MagicMock()
            client._connection.is_open = True
            client._channel = mock_channel

            client.complete_job("42")
            mock_channel.basic_ack.assert_called_once_with(delivery_tag=42)


class TestExtendVisibility:
    def test_is_noop(self):
        """RabbitMQ has no per-message visibility extension."""
        with patch("pika.BlockingConnection"):
            client = RabbitMQJobClient(queue_name="test")
            # Should not raise
            client.extend_visibility("42", 60)


class TestSendJob:
    def test_publishes_message(self):
        with patch("pika.BlockingConnection"):
            client = RabbitMQJobClient(queue_name="heimdex.test")
            mock_channel = MagicMock()
            mock_channel.is_open = True
            client._connection = MagicMock()
            client._connection.is_open = True
            client._channel = mock_channel

            body = {"file_id": "f1", "org_id": "o1"}
            msg_id = client.send_job(body, deduplication_id="dedup-1")

            assert msg_id == "dedup-1"
            mock_channel.basic_publish.assert_called_once()
            call_kwargs = mock_channel.basic_publish.call_args
            assert call_kwargs.kwargs["routing_key"] == "heimdex.test"
            assert json.loads(call_kwargs.kwargs["body"]) == body


class TestGetQueueDepth:
    def test_returns_depth(self):
        with patch("pika.BlockingConnection"):
            client = RabbitMQJobClient(queue_name="test")
            mock_channel = MagicMock()
            mock_channel.is_open = True
            client._connection = MagicMock()
            client._connection.is_open = True
            client._channel = mock_channel

            mock_result = MagicMock()
            mock_result.method.message_count = 5
            mock_result.method.consumer_count = 2
            mock_channel.queue_declare.return_value = mock_result

            depth = client.get_queue_depth()
            assert isinstance(depth, QueueDepth)
            assert depth.waiting == 5
            assert depth.in_flight == 2


class TestBuildQueueClient:
    """Test the factory function from __init__.py."""

    @patch("boto3.client")
    def test_builds_sqs_client(self, mock_boto):
        from heimdex_worker_sdk import build_queue_client, WorkerSettings
        settings = WorkerSettings(
            queue_backend="sqs",
            sqs_caption_queue_url="https://sqs.us-east-1.amazonaws.com/123/caption",
            sqs_region="us-east-1",
        )
        client = build_queue_client("caption", settings=settings)
        from heimdex_worker_sdk.sqs_client import SQSJobClient
        assert isinstance(client, SQSJobClient)

    def test_builds_rabbitmq_client(self):
        from heimdex_worker_sdk import build_queue_client, WorkerSettings
        with patch("pika.BlockingConnection"):
            settings = WorkerSettings(
                queue_backend="rabbitmq",
                rabbitmq_host="rabbit.local",
                rabbitmq_queue_prefix="heimdex",
            )
            client = build_queue_client("caption", settings=settings)
            assert isinstance(client, RabbitMQJobClient)

    def test_raises_on_missing_sqs_url(self):
        from heimdex_worker_sdk import build_queue_client, WorkerSettings
        settings = WorkerSettings(queue_backend="sqs")
        with pytest.raises(ValueError, match="No SQS queue URL"):
            build_queue_client("nonexistent_queue", settings=settings)
