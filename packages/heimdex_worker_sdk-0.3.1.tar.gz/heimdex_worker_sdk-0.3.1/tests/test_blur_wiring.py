"""Wiring test for the blur job type additions in PR 4.

Does NOT make any Aircloud or SQS network calls. Verifies:

  * ``blur`` is registered in the gpu_orchestrator job-type and queue
    mappings with the correct attribute names
  * ``WorkerSettings`` exposes the new fields with safe defaults
  * ``ensure_worker_running("blur")`` is a no-op when disabled
    (never raises, never blocks)
  * The orchestrator builder picks up ``aircloud_endpoint_blur`` and
    routes wake-ups through it
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from heimdex_worker_sdk.gpu_orchestrator import (
    GPUOrchestrator,
    _GPU_JOB_TYPES,
    _JOB_TYPE_TO_WORKER,
    ensure_worker_running,
)
from heimdex_worker_sdk.settings import WorkerSettings


def test_blur_registered_in_gpu_job_types():
    assert _GPU_JOB_TYPES["blur"] == "sqs_blur_queue_url"


def test_blur_registered_in_job_type_to_worker():
    assert _JOB_TYPE_TO_WORKER["blur"] == "blur"


def test_worker_settings_exposes_blur_fields():
    settings = WorkerSettings()
    # All new fields are safely defaulted so existing workers are untouched.
    assert settings.sqs_blur_queue_url == ""
    assert settings.aircloud_endpoint_blur == ""
    assert settings.blur_enabled is False
    assert settings.drive_blur_concurrency == 1
    assert settings.blur_owl_stride == 5
    assert settings.blur_owl_score_threshold == 0.35
    assert settings.blur_owl_model == "google/owlv2-base-patch16-ensemble"
    assert settings.blur_allow_cpu is False


def test_ensure_worker_running_blur_is_noop_when_disabled():
    """With no env configured, ensure_worker_running must never raise."""
    # ensure_worker_running is fire-and-forget and guards every failure
    # path. Even the brand-new "blur" job type should be a clean no-op.
    ensure_worker_running("blur")  # no assertion — success is "didn't raise"


def test_orchestrator_wakes_blur_endpoint():
    """The orchestrator routes ``ensure_running("blur")`` to the Aircloud
    endpoint registered under the ``"blur"`` worker name, honoring the
    wake debounce just like every other job type."""
    aircloud = MagicMock()
    orch = GPUOrchestrator(
        aircloud_client=aircloud,
        endpoint_map={"blur": "blur-endpoint-id-xyz"},
        queue_url_map={"blur": "https://sqs.example/blur-queue"},
        wake_debounce_seconds=0,  # no debounce for the test
    )
    orch.ensure_running("blur")
    aircloud.start.assert_called_once_with("blur-endpoint-id-xyz")


def test_orchestrator_unknown_job_type_no_raise():
    aircloud = MagicMock()
    orch = GPUOrchestrator(
        aircloud_client=aircloud,
        endpoint_map={},
        queue_url_map={},
    )
    orch.ensure_running("not-a-real-job-type")
    aircloud.start.assert_not_called()


def test_orchestrator_blur_without_endpoint_no_raise():
    """When blur_enabled=true but no Aircloud endpoint is configured,
    ensure_running is a clean no-op — never raises, never calls
    aircloud.start."""
    aircloud = MagicMock()
    orch = GPUOrchestrator(
        aircloud_client=aircloud,
        endpoint_map={},  # no blur endpoint registered
        queue_url_map={"blur": "https://sqs.example/blur-queue"},
    )
    orch.ensure_running("blur")
    aircloud.start.assert_not_called()
