# heimdex-worker-sdk

Shared worker utilities for the Heimdex ecosystem: S3 client, SQS consumer, Aircloud GPU orchestrator, and internal API helpers.

## Install

```bash
pip install heimdex-worker-sdk
```

## Modules

| Module | Purpose |
|--------|---------|
| `aircloud_client` | HTTP client for Aircloud External API (start/stop/scale/status) |
| `gpu_orchestrator` | Auto start/stop GPU workers based on SQS queue depth |
| `sqs_client` | Thin boto3 SQS wrapper |
| `sqs_consumer` | Background SQS polling loop with heartbeat |
| `s3` | S3/MinIO dual-mode client |
| `settings` | WorkerSettings via pydantic-settings |
| `internal_api` | HTTP client for livecommerce internal endpoints |
| `drive_keys` | Deterministic S3 key generation for Drive files |
| `youtube_keys` | S3 key generation for YouTube files |
| `youtube_api` | HTTP client for YouTube internal endpoints |
| `content_type` | MIME type classification |
| `message_adapters` | SQS message to dataclass converters |

## Consumers

| Product | What it uses |
|---------|-------------|
| dev-heimdex-for-livecommerce | Full SDK (all modules) |
| dev-heimdex-playground | `aircloud_client`, `gpu_orchestrator` |

## Release

1. Update `version` in `pyproject.toml`
2. `git tag vX.Y.Z && git push origin vX.Y.Z`
3. CI runs tests, builds wheel, publishes to PyPI, creates GitHub Release

## Development

```bash
pip install -e ".[dev]"
pytest -v
```
