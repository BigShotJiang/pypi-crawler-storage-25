import{ap as o,aq as n}from"./index-BwV5unrn.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
