from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="sentinel-sim",
    version="0.2.1",
    description="Python SDK for Sentinel SIM — AI agent governance, tool routing, and observability",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sentinel SIM",
    url="https://github.com/fbk2111/sentinel-backend-1774545718",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=["httpx>=0.24.0"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords=["ai", "agents", "llm", "sentinel", "sdk", "tool-calling", "observability"],
)
