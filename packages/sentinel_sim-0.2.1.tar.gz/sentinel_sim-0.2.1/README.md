# sentinel-sim

Python SDK for [Sentinel SIM](https://sentinel-frontend-1774545237.vercel.app) — the infrastructure layer for AI agent tool calls.

Route any tool call through Sentinel with full observability, policy enforcement, and budget control.

## Install

```bash
pip install sentinel-sim
```

## Quick start

```python
from sentinel import Sentinel

client = Sentinel(
    api_key="sk_agent_...",           # from dashboard.sentinel-sim.com
    base_url="https://api.sentinel-sim.com",
)

# Chat via OpenAI
result = client.openai_chat([
    {"role": "user", "content": "Hello!"}
])

# Deploy to Vercel
result = client.vercel_deploy("my-app", files=[
    {"file": "index.html", "data": "<h1>Hello</h1>"}
])

# Create a GitHub repo
result = client.github_create_repo("my-repo", private=True)

# Deploy a Railway service
result = client.railway_create_project("my-project")
```

## Async support

```python
from sentinel import AsyncSentinel
import asyncio

async def main():
    async with AsyncSentinel(api_key="sk_agent_...") as client:
        result = await client.openai_chat([{"role": "user", "content": "Hi"}])

asyncio.run(main())
```

## Supported providers

| Provider | Tools |
|----------|-------|
| OpenAI | chat, embedding, image_generation, transcription |
| Anthropic | chat, vision, tool_use, streaming |
| GitHub | create_repo, push_file, create_issue, create_pr |
| Vercel | deploy, manage_project, manage_domain |
| Railway | create_project, create_service, deploy_service, upsert_variables |
| Stripe | create_payment_intent, create_customer, create_refund |
| Replicate | image_generation, model inference |
| Resend | send_email |

## Links

- [Dashboard](https://sentinel-frontend-1774545237.vercel.app)
- [API Docs](https://api.sentinel-sim.com/docs)
