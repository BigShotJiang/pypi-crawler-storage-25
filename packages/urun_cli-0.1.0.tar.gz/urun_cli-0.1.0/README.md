# urun CLI

Deploy Python apps to urun from your terminal.

[![PyPI](https://img.shields.io/pypi/v/urun-cli.svg)](https://pypi.org/project/urun-cli/)
[![Python](https://img.shields.io/pypi/pyversions/urun-cli.svg)](https://pypi.org/project/urun-cli/)

## Install

```bash
uv tool install urun-cli
# or
pip install urun-cli
```

The package installs the `urun` command:

```bash
urun --version
```

For one-off `uvx` usage:

```bash
uvx --from urun-cli urun --version
# or the package-matching command alias
uvx urun-cli --version
```

## Quick start

Set your API key:

```bash
export URUN_API_KEY=urun_<32hex>
```

Create `app.py`:

```python
print("hello from urun")
```

Deploy it:

```bash
urun deploy app.py
```

The API key identifies your account on the server side. There is no separate org
ID, login step, or local project setup for the v1 CLI.

## What gets deployed

`urun deploy` creates a source manifest from your Python entrypoint:

| Entrypoint | Included source |
| --- | --- |
| `urun deploy app.py` | `app.py` and local Python files it imports |

Dependency declarations are included when present. `pyproject.toml` is preferred;
`requirements.txt` is used when no `pyproject.toml` exists.

Generated/cache content such as `.git`, dotfiles, `__pycache__`, and `.pyc`
files is excluded. Add `.urunignore` to exclude additional paths.

Non-Python assets such as templates, static files, and data files are not
auto-included yet.

## Common options

| Option | Description |
| --- | --- |
| `--name` | Override the derived app name. |
| `--api-url` | Override the API URL; defaults to `https://api.urun.sh/v1`. |
| `--api-key` | API key; prefer `URUN_API_KEY` to avoid shell history leaks. |
| `--no-wait` | Finalize but do not poll for readiness. |
| `--poll-interval`, `--timeout` | Control readiness polling. |

## Troubleshooting

| Error | Fix |
| --- | --- |
| `missing API key` | Set `URUN_API_KEY` or pass `--api-key`. |
| `invalid API key format` | Use `urun_<32 lowercase hex chars>`. |
| `entrypoint not found` | Run from the project root or pass the entrypoint path. |
| `path is outside the project root` | Move the file under the project before deploying. |
| Expected files are missing | Import local Python files from `app.py`; non-Python assets are not auto-included yet. |

## Development

Contributing and test instructions are in [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT.
