# Changelog

## 0.1.0

- Initial public `urun deploy` CLI.
- Deploy from a Python app file with local Python imports included automatically.
- Source manifest generation, dependency declaration upload, and API deploy flow.
- Public docs for the config-free v1 CLI surface.
