from __future__ import annotations

import ast
import fnmatch
from pathlib import Path

from .errors import UrunError
from .manifest import FileBlob, file_blob


def derive_app_name(entrypoint: str | None) -> str:
    if not entrypoint:
        raise UrunError("missing entrypoint")
    p = Path(entrypoint)
    if p.name == "__main__.py" and p.parent.name:
        return p.parent.name
    if p.parent != Path("."):
        return p.parent.name
    return p.stem


def load_urunignore(root: Path) -> list[str]:
    ignore = root / ".urunignore"
    if not ignore.exists():
        return []
    return [
        line.strip()
        for line in ignore.read_text().splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]


def is_ignored(path: Path, project_root: Path, patterns: list[str]) -> bool:
    try:
        rel = path.resolve().relative_to(project_root.resolve()).as_posix()
    except ValueError as exc:
        raise UrunError(f"path is outside the project root: {path}") from exc
    parts = rel.split("/")
    if any(part == "__pycache__" for part in parts):
        return True
    if any(part == ".git" for part in parts):
        return True
    if path.name.startswith(".") or any(part.startswith(".") for part in parts):
        return True
    if path.suffix == ".pyc":
        return True
    return any(
        fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(path.name, pattern) for pattern in patterns
    )


def auto_include(entrypoint: Path, project_root: Path) -> list[FileBlob]:
    files = discover_local_python_files(entrypoint, project_root, load_urunignore(project_root))
    blobs: list[FileBlob] = []
    for p in sorted(files):
        try:
            blobs.append(file_blob(p, project_root))
        except ValueError as exc:
            raise UrunError(f"path is outside the project root: {p}") from exc
    return blobs


def discover_local_python_files(
    entrypoint: Path, project_root: Path, patterns: list[str]
) -> set[Path]:
    if not entrypoint.exists() or not entrypoint.is_file():
        raise UrunError(f"entrypoint not found: {entrypoint}")
    if entrypoint.suffix != ".py":
        raise UrunError("entrypoint must be a .py file")

    root = project_root.resolve()
    stack = [entrypoint.resolve()]
    seen: set[Path] = set()

    while stack:
        current = stack.pop()
        try:
            current.relative_to(root)
        except ValueError as exc:
            raise UrunError(f"path is outside the project root: {current}") from exc
        if current in seen:
            continue
        if is_ignored(current, project_root, patterns):
            label = "entrypoint" if current == entrypoint.resolve() else "imported file"
            raise UrunError(f"{label} is ignored by defaults or .urunignore: {current}")
        seen.add(current)
        stack.extend(p for p in referenced_local_files(current, project_root) if p not in seen)

    return seen


def referenced_local_files(source: Path, project_root: Path) -> set[Path]:
    try:
        tree = ast.parse(source.read_text(), filename=str(source))
    except SyntaxError as exc:
        raise UrunError(f"entrypoint has invalid Python syntax: {source}") from exc

    candidates: set[Path] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                candidates.update(resolve_absolute_import(alias.name, project_root))
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                candidates.update(resolve_relative_import(node, source, project_root))
            elif node.module:
                candidates.update(resolve_absolute_import(node.module, project_root))
                for alias in node.names:
                    if alias.name != "*":
                        candidates.update(
                            resolve_absolute_import(f"{node.module}.{alias.name}", project_root)
                        )
    return candidates


def resolve_absolute_import(name: str, project_root: Path) -> set[Path]:
    parts = name.split(".")
    return module_path_candidates(project_root, parts)


def resolve_relative_import(node: ast.ImportFrom, source: Path, project_root: Path) -> set[Path]:
    base = source.parent
    for _ in range(max(node.level - 1, 0)):
        base = base.parent
    parts = node.module.split(".") if node.module else []
    candidates = module_path_candidates(base, parts)
    for alias in node.names:
        if alias.name != "*":
            candidates.update(module_path_candidates(base, [*parts, alias.name]))
    return {p for p in candidates if is_under_project(p, project_root)}


def module_path_candidates(base: Path, parts: list[str]) -> set[Path]:
    if not parts:
        return set()
    path = base.joinpath(*parts)
    candidates: set[Path] = set()
    module_file = path.with_suffix(".py")
    package_init = path / "__init__.py"
    if module_file.is_file():
        candidates.add(module_file.resolve())
    if package_init.is_file():
        candidates.add(package_init.resolve())
    return candidates


def is_under_project(path: Path, project_root: Path) -> bool:
    try:
        path.resolve().relative_to(project_root.resolve())
    except ValueError:
        return False
    return True


def discover_main_files(
    entrypoint_arg: str | None, project_root: Path
) -> tuple[str, list[FileBlob]]:
    if not entrypoint_arg:
        raise UrunError("provide an entrypoint file")
    entrypoint_path = Path(entrypoint_arg)
    if not entrypoint_path.is_absolute():
        entrypoint_path = project_root / entrypoint_path
    files = auto_include(entrypoint_path, project_root)
    try:
        manifest_entrypoint = (
            entrypoint_path.resolve().relative_to(project_root.resolve()).as_posix()
        )
    except ValueError as exc:
        raise UrunError(f"entrypoint is outside the project root: {entrypoint_path}") from exc
    return manifest_entrypoint, files
