from __future__ import annotations

import tomllib
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path


def _source_tree_version() -> str:
    for parent in Path(__file__).resolve().parents:
        pyproject = parent / "pyproject.toml"
        if pyproject.is_file():
            data = tomllib.loads(pyproject.read_text())
            project_version = (data.get("project") or {}).get("version")
            if isinstance(project_version, str) and project_version:
                return project_version
    return "0.0.0"


try:
    __version__ = version("urun-cli")
except PackageNotFoundError:  # pragma: no cover - source tree fallback
    __version__ = _source_tree_version()
