from __future__ import annotations

import argparse
import os
import re
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from . import __version__
from .api import DEFAULT_API_URL, ApiClient, poll_until_done, upload_missing_blobs
from .deps import resolve_deps
from .discovery import derive_app_name, discover_main_files
from .errors import UrunError
from .manifest import manifest_hash, unique_blobs

API_KEY_RE = re.compile(r"^urun_[0-9a-f]{32}$")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "deploy":
            return deploy(args)
        parser.print_help()
        return 2
    except UrunError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("aborted", file=sys.stderr)
        return 130


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="urun")
    parser.add_argument("--version", action="version", version=f"urun {__version__}")
    sub = parser.add_subparsers(dest="command")
    deploy = sub.add_parser("deploy", help="Deploy a Python app to urun")
    deploy.add_argument("entrypoint", nargs="?", help="Python app file, e.g. app.py")
    deploy.add_argument("--name", help="App name (defaults from entrypoint file)")
    deploy.add_argument(
        "--api-url", default=os.getenv("URUN_API_URL", DEFAULT_API_URL), help="API base URL"
    )
    deploy.add_argument(
        "--api-key", default=os.getenv("URUN_API_KEY"), help="API key (or URUN_API_KEY)"
    )
    deploy.add_argument(
        "--no-wait", action="store_true", help="Finalize deployment but do not poll for readiness"
    )
    deploy.add_argument("--poll-interval", type=float, default=2.0)
    deploy.add_argument("--timeout", type=float, default=1800.0)
    return parser


def deploy(args: argparse.Namespace) -> int:
    if not args.api_key:
        raise UrunError("missing API key; set URUN_API_KEY or pass --api-key")
    if not API_KEY_RE.fullmatch(args.api_key):
        raise UrunError("invalid API key format; expected urun_<32 lowercase hex chars>")
    if args.poll_interval <= 0:
        raise UrunError("--poll-interval must be greater than 0")
    if args.timeout <= 0:
        raise UrunError("--timeout must be greater than 0")

    project_root = Path.cwd()
    entrypoint, files = discover_main_files(args.entrypoint, project_root)
    deps, deps_blob, python_version = resolve_deps(project_root)

    app_name = args.name or derive_app_name(args.entrypoint)
    all_blobs = files + ([deps_blob] if deps_blob is not None else [])
    manifest = {
        "version": 1,
        "app_name": app_name,
        "entrypoint": entrypoint,
        "python_version": python_version,
        "files": [b.manifest_entry() for b in sorted(files, key=lambda b: b.path)],
        "deps": deps,
        "created_at": datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "client_version": f"urun-cli/{__version__}",
    }
    mh = manifest_hash(manifest)

    print(f"Deploying {app_name} ({mh[:12]})")
    print(f"Files: {len(files)} app, deps: {deps['kind']}")

    client = ApiClient(args.api_url, args.api_key)
    register = client.register_manifest(manifest)
    server_hash = register.get("manifest_hash")
    if server_hash and server_hash != mh:
        raise UrunError(f"server manifest hash mismatch: local {mh}, server {server_hash}")
    missing = register.get("missing_blobs", [])
    print(f"Uploading {len(missing)} missing blob(s)")
    upload_missing_blobs(missing, unique_blobs(all_blobs))

    final = client.finalize(mh)
    print(f"Deployment {final.get('status', 'queued')}: {mh}")
    if args.no_wait:
        status_url = register.get("status_url")
        if status_url:
            print(f"Status: {status_url}")
        return 0

    status = poll_until_done(client, mh, args.poll_interval, args.timeout)
    if status.get("status") == "failed":
        err = status.get("error") or {}
        code = err.get("code")
        message = err.get("message")
        detail = f"{code}: {message}" if code and message else (message or code or "unknown error")
        raise UrunError(f"deployment failed: {detail}")
    print_ready(status)
    return 0


def print_ready(status: dict[str, Any]) -> None:
    print("Deployment ready")
    if status.get("url"):
        print(f"URL: {status['url']}")


if __name__ == "__main__":
    raise SystemExit(main())
