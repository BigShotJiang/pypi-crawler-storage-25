"""HassCheck package."""

__version__ = "0.15.4"
