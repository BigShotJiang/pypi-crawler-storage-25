"""C++ zen principles as Pydantic models."""

from pydantic import HttpUrl

from mcp_zen_of_languages.rules.base_models import LanguageZenPrinciples
from mcp_zen_of_languages.rules.base_models import PrincipleCategory
from mcp_zen_of_languages.rules.base_models import ZenPrinciple


CPP_ZEN = LanguageZenPrinciples(
    language="cpp",
    name="C++",
    philosophy="Modern C++ Best Practices (C++11/14/17/20)",
    source_text="C++ Core Guidelines",
    source_url=HttpUrl("https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines"),
    principles=[
        ZenPrinciple(
            id="cpp-001",
            principle="Use RAII for resource management",
            category=PrincipleCategory.RESOURCE_MANAGEMENT,
            severity=9,
            description="Resources should be tied to object lifetime",
            violations=[
                "Manual new/delete",
                "Naked pointers for ownership",
                "Not using smart pointers",
                "Missing destructors for resource cleanup",
            ],
            detectable_patterns=["new ", "delete ", "malloc(", "free("],
            recommended_alternative="unique_ptr, shared_ptr, RAII wrappers",
        ),
        ZenPrinciple(
            id="cpp-002",
            principle="Prefer smart pointers over raw pointers",
            category=PrincipleCategory.MEMORY_MANAGEMENT,
            severity=9,
            description="Use unique_ptr, shared_ptr for ownership",
            violations=[
                "new/delete in modern code",
                "Raw pointers for ownership",
                "Manual memory management",
                "Not using make_unique/make_shared",
            ],
            detectable_patterns=["new Type", "delete ptr"],
        ),
        ZenPrinciple(
            id="cpp-003",
            principle="Use auto for type deduction",
            category=PrincipleCategory.IDIOMS,
            severity=6,
            description="Let the compiler deduce obvious types",
            violations=[
                "Verbose type declarations when auto works",
                "Iterator types spelled out",
                "Not using auto in range-based for",
            ],
            detectable_patterns=["!auto "],
        ),
        ZenPrinciple(
            id="cpp-004",
            principle="Prefer nullptr over NULL or 0",
            category=PrincipleCategory.CORRECTNESS,
            severity=7,
            description="Use nullptr for pointer initialization",
            violations=[
                "Using NULL macro",
                "Using 0 for null pointers",
                "Not using nullptr",
            ],
            detectable_patterns=["= NULL", "== NULL", "ptr = 0"],
        ),
        ZenPrinciple(
            id="cpp-005",
            principle="Use range-based for loops",
            category=PrincipleCategory.IDIOMS,
            severity=6,
            description="Prefer for(auto& item : container)",
            violations=[
                "Index-based iteration",
                "Iterator-based loops when range-for works",
                "Manual iteration with .begin()/.end()",
            ],
            detectable_patterns=[".begin()", ".end()"],
        ),
        ZenPrinciple(
            id="cpp-006",
            principle="Avoid manual memory allocation",
            category=PrincipleCategory.MEMORY_MANAGEMENT,
            severity=9,
            description="Use containers and smart pointers",
            violations=[
                "malloc/free in C++ code",
                "new[] without corresponding delete[]",
                "Manual array management",
                "Not using std::vector, std::array",
            ],
            detectable_patterns=["malloc(", "free(", "new[", "delete["],
        ),
        ZenPrinciple(
            id="cpp-007",
            principle="Use const correctness",
            category=PrincipleCategory.CORRECTNESS,
            severity=8,
            description="Mark everything const that can be const",
            violations=[
                "Non-const member functions that don't modify",
                "Missing const references in parameters",
                "Mutable data without justification",
                "Not using constexpr when possible",
            ],
            detectable_patterns=["!const "],
        ),
        ZenPrinciple(
            id="cpp-008",
            principle="Avoid C-style casts",
            category=PrincipleCategory.TYPE_SAFETY,
            severity=7,
            description="Use static_cast, dynamic_cast, const_cast",
            violations=[
                "C-style casts: (Type)value",
                "Implicit dangerous conversions",
                "Not using explicit casts",
            ],
            detectable_patterns=["(Type)", "C-style cast"],
        ),
        ZenPrinciple(
            id="cpp-009",
            principle="Follow Rule of Zero/Three/Five",
            category=PrincipleCategory.DESIGN,
            severity=8,
            description="Properly manage special member functions",
            violations=[
                "Custom destructor without copy/move control",
                "Copy constructor without assignment operator",
                "Not using =default or =delete",
                "Incomplete rule of five",
            ],
            detectable_patterns=["operator=", " = delete", " = default"],
        ),
        ZenPrinciple(
            id="cpp-010",
            principle="Use std::move for rvalue references",
            category=PrincipleCategory.PERFORMANCE,
            severity=7,
            description="Enable move semantics for efficiency",
            violations=[
                "Copying when moving would work",
                "Not implementing move constructors",
                "Not using std::forward in templates",
            ],
            detectable_patterns=["!std::move"],
        ),
        ZenPrinciple(
            id="cpp-011",
            principle="Avoid global variables",
            category=PrincipleCategory.DESIGN,
            severity=8,
            description="Minimize mutable global state",
            violations=[
                "Mutable global variables",
                "Singleton abuse",
                "Static member variables as globals",
            ],
            detectable_patterns=["static ", "extern "],
        ),
        ZenPrinciple(
            id="cpp-012",
            principle="Use override and final keywords",
            category=PrincipleCategory.CORRECTNESS,
            severity=7,
            description="Explicitly mark virtual function overrides",
            violations=[
                "Virtual functions without override",
                "Not using final for non-overridable functions",
                "Missing virtual in base class",
            ],
            detectable_patterns=["virtual function without override keyword"],
        ),
        ZenPrinciple(
            id="cpp-013",
            principle="Prefer std::optional over null pointers",
            category=PrincipleCategory.DESIGN,
            severity=6,
            description="Use std::optional for optional values",
            violations=[
                "Pointers for optional values",
                "Special sentinel values (-1, nullptr)",
                "Not using std::optional in C++17+",
            ],
            detectable_patterns=["!std::optional"],
        ),
    ],
)
