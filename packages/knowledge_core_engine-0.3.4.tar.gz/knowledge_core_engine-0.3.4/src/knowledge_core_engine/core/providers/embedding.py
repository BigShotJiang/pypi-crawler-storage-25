"""Embedding provider abstraction for flexible embedding integration."""

import asyncio
from http import HTTPStatus
from abc import abstractmethod
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass
import numpy as np

from .base import Provider, ProviderConfig, ProviderFactory


@dataclass
class EmbeddingConfig(ProviderConfig):
    """Embedding-specific configuration."""
    model: str = None  # Model name
    dimensions: int = None  # Vector dimensions
    batch_size: int = 25
    normalize: bool = True


@dataclass
class EmbeddingResult:
    """Standard embedding result format."""
    text: str
    embedding: Union[List[float], np.ndarray]
    model: str
    usage: Dict[str, int] = None
    
    def __post_init__(self):
        if self.usage is None:
            self.usage = {}
    
    @property
    def dimension(self) -> int:
        return len(self.embedding)


class EmbeddingProvider(Provider):
    """Base class for embedding providers."""
    
    @abstractmethod
    async def embed(self, text: str) -> EmbeddingResult:
        """Embed a single text.
        
        Args:
            text: Text to embed
            
        Returns:
            EmbeddingResult with vector
        """
        pass
    
    @abstractmethod
    async def embed_batch(self, texts: List[str]) -> List[EmbeddingResult]:
        """Embed multiple texts in batch.
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of EmbeddingResults
        """
        pass
    
    @abstractmethod
    def get_dimension(self) -> int:
        """Get the dimension of embeddings."""
        pass
    
    def prepare_text(self, text: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Prepare text for embedding (can be overridden).
        
        Default implementation for multi-vector strategy.
        """
        if not metadata:
            return text
        
        parts = [f"Content: {text}"]
        
        if metadata.get("summary"):
            parts.append(f"Summary: {metadata['summary']}")
        
        if metadata.get("questions"):
            questions = metadata["questions"]
            if isinstance(questions, list):
                parts.append(f"Questions: {' '.join(questions)}")
        
        return "\n\n".join(parts)

    def _normalize_embedding(self, embedding: List[float]) -> List[float]:
        """Normalize embedding vector when configured."""
        normalize = getattr(self.config, "normalize", True)
        if not normalize:
            return embedding
        norm = np.linalg.norm(embedding)
        if norm > 0:
            return (np.array(embedding) / norm).tolist()
        return embedding

    def _response_value(self, value: Any, key: str, default: Any = None) -> Any:
        """Read a key from dict-like or object-like provider responses."""
        if isinstance(value, dict):
            return value.get(key, default)
        return getattr(value, key, default)

    def _usage_from_response(self, response: Any) -> Dict[str, int]:
        """Extract usage data from provider responses."""
        usage = getattr(response, "usage", None)
        if usage is None and isinstance(response, dict):
            usage = response.get("usage")
        if hasattr(usage, "model_dump"):
            return usage.model_dump()
        if isinstance(usage, dict):
            return usage
        return {}


# --- DashScope Implementation ---

class DashScopeEmbeddingProvider(EmbeddingProvider):
    """DashScope (Alibaba Cloud) embedding provider."""
    
    def __init__(self, config: EmbeddingConfig):
        super().__init__(config)
        self.model = config.model or "text-embedding-v3"
        self.dimensions = getattr(config, "dimensions", None) or 1024
        self.api_base = config.api_base or "https://dashscope.aliyuncs.com/api/v1"
        self.batch_size = min(getattr(config, "batch_size", 25), 10)
        self._dashscope = None
    
    async def initialize(self):
        """Initialize DashScope client."""
        if not self.config.api_key:
            raise ValueError("DashScope API key is required")

        try:
            import dashscope
        except ImportError as exc:
            raise RuntimeError(
                "dashscope is not installed. Install it with: pip install dashscope"
            ) from exc

        self._dashscope = dashscope
    
    async def embed(self, text: str) -> EmbeddingResult:
        """Embed using DashScope API."""
        results = await self.embed_batch([text])
        return results[0]
    
    async def embed_batch(self, texts: List[str]) -> List[EmbeddingResult]:
        """Batch embed using DashScope API."""
        results = []
        for i in range(0, len(texts), self.batch_size):
            batch = texts[i:i + self.batch_size]
            kwargs = {
                "model": self.model,
                "input": batch,
                "api_key": self.config.api_key,
            }
            if self.dimensions:
                kwargs["dimension"] = self.dimensions

            response = await self._call_dashscope_with_retry(kwargs)
            status_code = self._response_value(response, "status_code")
            if status_code != HTTPStatus.OK:
                code = self._response_value(response, "code", "unknown")
                message = self._response_value(
                    response,
                    "message",
                    "DashScope embedding failed",
                )
                raise RuntimeError(f"DashScope embedding failed: {code} {message}")

            output = self._response_value(response, "output", {}) or {}
            embedding_items = self._response_value(output, "embeddings", [])
            ordered_items = sorted(
                embedding_items,
                key=lambda item: self._response_value(item, "text_index", 0),
            )
            usage = self._usage_from_response(response)
            for text, item in zip(batch, ordered_items):
                embedding = self._response_value(item, "embedding")
                if embedding is None:
                    raise RuntimeError("DashScope embedding item missing embedding vector")
                results.append(EmbeddingResult(
                    text=text,
                    embedding=self._normalize_embedding(list(embedding)),
                    model=self.model,
                    usage=usage,
                ))
        return results

    async def _call_dashscope_with_retry(self, kwargs: Dict[str, Any]) -> Any:
        """Call DashScope embedding API with lightweight retry."""
        max_retries = int(getattr(self.config, "max_retries", 3))
        last_error = None
        for attempt in range(max_retries):
            try:
                return await asyncio.to_thread(self._dashscope.TextEmbedding.call, **kwargs)
            except Exception as exc:
                last_error = exc
                if attempt >= max_retries - 1:
                    break
                await asyncio.sleep(0.3 * (2 ** attempt))
        raise RuntimeError(f"DashScope embedding request failed: {last_error}") from last_error
    
    def get_dimension(self) -> int:
        return self.dimensions
    
    async def close(self):
        """Clean up resources."""
        pass


# --- OpenAI Implementation ---

class OpenAIEmbeddingProvider(EmbeddingProvider):
    """OpenAI embedding provider."""
    
    def __init__(self, config: EmbeddingConfig):
        super().__init__(config)
        self.model = config.model or "text-embedding-3-large"
        self.dimensions = getattr(config, "dimensions", None) or 3072
        self.api_base = config.api_base or "https://api.openai.com/v1"
        self._client = None
    
    async def initialize(self):
        """Initialize OpenAI client."""
        if not self.config.api_key:
            raise ValueError("OpenAI API key is required")
        try:
            from openai import AsyncOpenAI
        except ImportError as exc:
            raise RuntimeError(
                "openai is not installed. Install it with: pip install openai"
            ) from exc

        self._client = AsyncOpenAI(
            api_key=self.config.api_key,
            base_url=self.api_base,
        )
    
    async def embed(self, text: str) -> EmbeddingResult:
        """Embed using OpenAI API."""
        results = await self.embed_batch([text])
        return results[0]
    
    async def embed_batch(self, texts: List[str]) -> List[EmbeddingResult]:
        """Batch embed using OpenAI API."""
        if not texts:
            return []
        if self._client is None:
            await self.initialize()

        kwargs = {"model": self.model, "input": texts}
        if self.dimensions and self.model.startswith("text-embedding-3"):
            kwargs["dimensions"] = self.dimensions

        response = await self._client.embeddings.create(**kwargs)
        data = sorted(response.data, key=lambda item: item.index)
        usage = response.usage.model_dump() if response.usage else {}

        return [
            EmbeddingResult(
                text=text,
                embedding=self._normalize_embedding(list(item.embedding)),
                model=self.model,
                usage=usage,
            )
            for text, item in zip(texts, data)
        ]
    
    def get_dimension(self) -> int:
        return self.dimensions
    
    async def close(self):
        """Clean up resources."""
        if self._client is not None:
            await self._client.close()


# --- HuggingFace Local Implementation ---

class HuggingFaceEmbeddingProvider(EmbeddingProvider):
    """HuggingFace local embedding provider."""
    
    def __init__(self, config: EmbeddingConfig):
        super().__init__(config)
        self.model = config.model or "BAAI/bge-large-zh-v1.5"
        self.dimensions = getattr(config, "dimensions", None) or 1024
        self._model = None
    
    async def initialize(self):
        """Load HuggingFace model."""
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "sentence-transformers is required for HuggingFace embeddings. "
                "Install with: pip install knowledge-core-engine[huggingface]"
            ) from exc

        self._model = SentenceTransformer(self.model)
    
    async def embed(self, text: str) -> EmbeddingResult:
        """Embed using local model."""
        results = await self.embed_batch([text])
        return results[0]
    
    async def embed_batch(self, texts: List[str]) -> List[EmbeddingResult]:
        """Batch embed using local model."""
        if not texts:
            return []
        if self._model is None:
            await self.initialize()

        embeddings = await asyncio.to_thread(
            self._model.encode,
            texts,
            normalize_embeddings=True,
            convert_to_numpy=True,
        )

        return [
            EmbeddingResult(
                text=text,
                embedding=np.asarray(embedding, dtype=float).tolist(),
                model=self.model,
                usage={"tokens": 0},
            )
            for text, embedding in zip(texts, embeddings)
        ]
    
    def get_dimension(self) -> int:
        return self.dimensions
    
    async def close(self):
        """Clean up resources."""
        self._model = None


# Register providers
ProviderFactory.register("embedding", "dashscope", DashScopeEmbeddingProvider)
ProviderFactory.register("embedding", "openai", OpenAIEmbeddingProvider)
ProviderFactory.register("embedding", "huggingface", HuggingFaceEmbeddingProvider)


# --- Usage Example ---
"""
# Configuration
config = {
    "provider": "dashscope",
    "api_key": "sk-xxx",  # or from env: DASHSCOPE_API_KEY
    "model": "text-embedding-v3",
    "dimensions": 1536,
    "batch_size": 25
}

# Create embedding provider
embedder = ProviderFactory.create("embedding", config)
await embedder.initialize()

# Simple embedding
result = await embedder.embed("What is RAG?")
print(f"Dimension: {result.dimension}")

# With metadata (multi-vector strategy)
text = "RAG combines retrieval and generation"
metadata = {
    "summary": "RAG技术结合检索和生成",
    "questions": ["什么是RAG?", "RAG如何工作?"]
}
prepared = embedder.prepare_text(text, metadata)
result = await embedder.embed(prepared)

# Batch embedding
texts = ["text1", "text2", "text3"]
results = await embedder.embed_batch(texts)
"""
