from collections.abc import Iterable, Iterator, Mapping

from copy import deepcopy
from itertools import chain
from heaobject.root import DesktopObjectTypeVar
from heaobject.person import Group, GroupView, Person, PersonView
from heaobject.util import to_bool
from heaserver.service.aiohttp import SPECIAL_QUERY_PARAMETERS, SortOrder
from heaserver.service.aiohttp import extract_sorts_and_sort_attrs_from_params, resolve_single_query_params, resolve_missing_attr_params
from typing import Generic
from multidict import MultiDict
import logging


class QueryParamManager(Generic[DesktopObjectTypeVar]):
    def __init__(self, params: Mapping[str, str], type_: type[DesktopObjectTypeVar],
                 api_supported_query_params: Mapping[str, str] | None = None,
                 api_sort_attr: str | None = None):
        """
        Parses and handles mappings from query parameters to attributes for filtering and sorting, as well as handling
        any parameters that should be passed directly to the Keycloak REST API (for Person/Group types) vs. those that
        should be handled by the service itself.
        :param params: The query parameters from the request.
        :param type_: The type of object being queried, used to validate query parameters and determine which
        attributes are valid for filtering/sorting.
        :param supported_query_params_by_api: An optional mapping of type name to the set of query parameters that
        should be passed directly to the API for that type.
        :param api_sort_attr: An optional attribute name that, if present in the sort parameters, indicates that the
        sort can be done by Keycloak and the results returned in native sort order, so that pagination can be applied
        by Keycloak's REST API rather than in memory.
        :raises ValueError: If any query parameters were unexpected.
        """
        logger = logging.getLogger(__name__)
        assert all(v is not None for v in params.values()), \
            f'Unexpected None value for query parameter(s) {set(k for k, v in params.items() if v is None)}'
        self.api_supported_query_params = dict((k, deepcopy(v)) for k, v in api_supported_query_params.items()) \
            if api_supported_query_params else dict()
        obj = type_()
        obj_attributes = set(obj.get_attributes())
        infix_obj_attributes = set(v for k, v in params.items() if k == 'filter_attr')
        sort_attributes = set(v for k, v in params.items() if k == 'sort_attr')
        if any(k not in list(chain(obj_attributes, iter(SPECIAL_QUERY_PARAMETERS), iter(('excludesystem',)))) for k in params.keys()):
            raise ValueError(f'Unexpected query parameter(s) {set(params.keys()).difference(obj_attributes)} for type {type_.get_type_name()}')
        if any(k not in obj_attributes for k in infix_obj_attributes):
            raise ValueError(f'Unexpected filter_attr query parameter(s) {infix_obj_attributes.difference(obj_attributes)} for type {type_.get_type_name()}')
        if any(k not in obj_attributes for k in sort_attributes):
            raise ValueError(f'Unexpected sort_attr query parameter(s) {sort_attributes.difference(obj_attributes)} for type {type_.get_type_name()}')
        self.params = params
        self.for_ = type_

        # All other "contains" search fields supported by keycloak are not used. Rather, they're passed into the q
        # query parameter.
        resolved_params = resolve_missing_attr_params(resolve_single_query_params(params.items(),
                                                                                  obj=obj,
                                                                                  extra_singles=('excludesystem',)))
        self.sorts = list(extract_sorts_and_sort_attrs_from_params(MultiDict((k, v) for k, v in resolved_params.items() if v is not None)))
        logger.debug('Extracted sorts are %s', self.sorts)
        logger.debug('Resolved params are %s', resolved_params)
        self.exclude_system_users = to_bool(resolved_params.get('excludesystem', 'no'))

        # default filter with no filter_attr
        self.infix_default_filter = next((v for k, v in zip(resolved_params.getall('filter_attr', []),
                                         resolved_params.getall('filter', [])) if k is None), None)
        # non-default filter_attr/filter pairs
        self.infix_attr_filter = [(k, v) for k, v in zip(resolved_params.getall('filter_attr', []),
                                                     resolved_params.getall('filter', [])) \
                                                        if k in self.api_supported_query_params.keys()]

        self.__rest_call_params = resolve_missing_attr_params(resolve_single_query_params(
                                                    (p for p in params.items() if p[0] in self.api_supported_query_params.keys()),
                                                    obj=obj, extra_singles=('excludesystem',),
                                                    key_mapping={k: v for k, v in self.api_supported_query_params.items() if k != v}))

        mapped_exact_attr_filter = set(self.api_supported_query_params.values()).intersection(self.__rest_call_params.keys())
        self.both = bool(mapped_exact_attr_filter and (self.infix_default_filter or self.infix_attr_filter))
        if not self.both:
            self.exact_attr_filter = tuple((k, v) for k, v in resolved_params.items() if k in self.api_supported_query_params.keys() if v is not None)
        else:
            self.exact_attr_filter = tuple()
        if mapped_exact_attr_filter:
            if not self.both:
                self.__rest_call_params['exact'] = "true"
                # we'll still need to filter by attributes that Keycloak doesn't support infix matching on.
                for exact_match in mapped_exact_attr_filter:
                    if exact_match not in set(self.api_supported_query_params.values()):
                        self.__rest_call_params.pop(exact_match, None)
            else:
                # we'll filter all the exact filter attrs from the results of the Keycloak call.
                for exact_match in mapped_exact_attr_filter:
                    self.__rest_call_params.pop(exact_match, None)
        if self.infix_default_filter:
            self.__rest_call_params['search'] = self.infix_default_filter
        for k, v in self.infix_attr_filter:
            self.__rest_call_params[self.api_supported_query_params[k]] = v
        self.unused_infix_params = [(k, v) for k, v in zip((v for v in resolved_params.getall('filter_attr', []) if v is not None),
                                                           (v for v in resolved_params.getall('filter', []) if v is not None)) \
                                                           if k not in self.api_supported_query_params.keys()]
        self.__rest_call_params.popall('filter_attr', None)
        self.__rest_call_params.popall('filter', None)
        self.unused_exact_params = tuple((k, v) for k, v in resolved_params.items() \
                                         if k not in dict(self.exact_attr_filter) and k in obj_attributes \
                                            and k not in self.__rest_call_params and v is not None)
        self.api_sort_attr = api_sort_attr
        api_sort_part = not self.sorts or not api_sort_attr or (len(self.sorts) == 1 and self.sorts[0][1] == api_sort_attr and \
                                           (self.sorts[0][0] is None or self.sorts[0][0] == SortOrder.ASC))
        self.api_sort = api_sort_part
        self.api_paginate = self.api_sort and not self.unused_exact_params and not self.unused_infix_params

    @property
    def rest_call_params(self) -> MultiDict[str]:
        return MultiDict((k, v) for k, v in self.__rest_call_params.items() if v is not None)

    def filter_by_unused_params(self, persons: Iterable[DesktopObjectTypeVar]) -> Iterator[DesktopObjectTypeVar]:
        return self.filter_by_unused_infix_params(self.filter_by_unused_exact_params(persons))

    def filter_by_unused_infix_params(self, persons: Iterable[DesktopObjectTypeVar]) -> Iterator[DesktopObjectTypeVar]:
        return (person for person in persons if all(v in str(getattr(person, k)) for k, v in self.unused_infix_params))

    def filter_by_unused_exact_params(self, persons: Iterable[DesktopObjectTypeVar]) -> Iterator[DesktopObjectTypeVar]:
        return (person for person in persons if all(getattr(person, k) == v for k, v in self.unused_exact_params))

    def filter_by_all_params(self, persons: Iterable[DesktopObjectTypeVar]) -> Iterator[DesktopObjectTypeVar]:
        if self.infix_default_filter:
            persons = (person for person in persons if any(self.infix_default_filter in str(getattr(person, attr)) \
                                                           for attr in self.api_supported_query_params.keys()))
        if self.infix_attr_filter:
            def infix_attr_filter_func(person):
                for k, v in self.infix_attr_filter:
                    person_v = str(getattr(person, k))
                    if v is not None and v not in person_v:
                        return False
                return True
            persons = (person for person in persons if infix_attr_filter_func(person))
        for k, v in self.exact_attr_filter or []:
            persons = (person for person in persons if getattr(person, k) == v)
        return self.filter_by_unused_params(persons)

    def has_filter_params(self) -> bool:
        return bool(self.infix_default_filter or self.infix_attr_filter or self.exact_attr_filter or self.unused_exact_params or self.unused_infix_params)


class PersonViewQueryParamManager(QueryParamManager[PersonView]):
    def __init__(self, params: Mapping[str, str]):
        super().__init__(params, PersonView,
                         api_supported_query_params={'name': 'username', 'first_name': 'firstName',
                                                     'last_name': 'lastName', 'email': 'email'},
                         api_sort_attr='username')


class PersonQueryParamManager(QueryParamManager[Person]):
    def __init__(self, params: Mapping[str, str]):
        super().__init__(params, Person,
                         api_supported_query_params={'name': 'username', 'first_name': 'firstName',
                                                     'last_name': 'lastName', 'email': 'email'},
                         api_sort_attr='username')


class GroupViewQueryParamManager(QueryParamManager[GroupView]):
    def __init__(self, params: Mapping[str, str]):
        super().__init__(params, GroupView, api_supported_query_params={'group': 'search'},
                         api_sort_attr='group')


class GroupQueryParamManager(QueryParamManager[Group]):
    def __init__(self, params: Mapping[str, str]):
        super().__init__(params, Group, api_supported_query_params={'group': 'search'},
                         api_sort_attr='group')
