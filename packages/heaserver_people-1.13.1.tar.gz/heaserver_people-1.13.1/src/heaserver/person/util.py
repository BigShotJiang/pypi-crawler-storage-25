from aiohttp.web import Request

def get_pagination_params(request: Request) -> tuple[int, int | None, int | None]:
    begin = int(request.query.get('begin', 0))
    end_str = request.query.get('end')
    limit_str = request.query.get('limit')
    end: int | None
    limit: int | None
    if end_str is not None:
        end = int(end_str)
        limit = end - begin
    elif limit_str is not None:
        limit = int(limit_str)
        end = begin + limit
    else:
        end = None
        limit = None
    return begin, end, limit
