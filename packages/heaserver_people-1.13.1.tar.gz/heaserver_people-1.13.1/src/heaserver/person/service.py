"""
The HEA Person Microservice is a wrapper around a Keycloak server for HEA to access user information. It accesses
Keycloak using an admin account. The default account is 'admin' with password of 'admin'. To configure this (and you
must do this to be secure!), add a Keycloak section to the service's configuration file with the following properties:
    Realm = the Keyclock realm from which to request user information.
    VerifySSL = whether to verify the Keycloak server's SSL certificate (defaults to True).
    Host = The Keycloak host (defaults to https://localhost:8444).
    Username = the admin account username (defaults to admin).
    Password = the admin account password.
    PasswordFile = the path to the filename with the password (overrides use of the PASSWORD property).

This microservice tries getting the password from the following places, in order:
    1) the KEYCLOAK_QUERY_USERS_PASSWORD property in the HEA Server Registry Microservice.
    2) the above config file.

If not present in any of those sources, a password of admin will be used.
"""
import asyncio
import logging

from heaserver.service import response, client
from heaserver.service.runner import routes, start, web
from heaserver.service.wstl import action, builder_factory, add_run_time_action, RuntimeWeSTLDocumentBuilder
from heaserver.service import appproperty
from heaserver.service.heaobjectsupport import new_heaobject_from_type, type_to_resource_url, HEAServerPermissionContext
from heaserver.service.oidcclaimhdrs import SUB
from heaserver.service.requestproperty import HEA_WSTL_BUILDER
from heaserver.service.config import Configuration
from heaserver.service.aiohttp import sorted_response_data, is_sorting_requested
from heaobject.error import DeserializeException
from heaobject.person import Group, PersonView, Role, decode_role, decode_group, Person
from heaobject.registry import Collection
from heaobject.root import ViewerPermissionContext, to_dict

from .util import get_pagination_params
from .keycloakmongo import KeycloakMongo, KeycloakMongoManager
from heaobject.user import NONE_USER, is_system_user
from aiohttp import ClientResponseError, hdrs
from binascii import Error as B64DecodeError
from collections.abc import Mapping
from multidict import istr, MultiDict
from yarl import URL
from typing import cast

MONGODB_PERSON_COLLECTION = 'people'

_logger = logging.getLogger(__name__)


@routes.get('/ping')
async def ping(request: web.Request) -> web.Response:
    """
    For testing whether the service is up. It performs a health check on the Keycloak server. To construct the URL to
    use for the test, it concatenates the value of the Host property in the Keycloak section of the service's
    configuration file with '/health/ready'.

    :param request: the HTTP request.
    :return: Returns an HTTP response with status code 200 if successful, otherwise 503 (service unavailable).
    ---
    summary: A health check.
    tags:
        - heaserver-people
    responses:
        '200':
            $ref: '#/components/responses/200'
        '503':
            description: Service unavailable.
    """
    health_check_url = URL(request.app[appproperty.HEA_DB].base_url) / 'health' / 'ready'
    async with client._client_session(request.app).get(health_check_url) as response_:
        if response_.status != 200:
            _logger.error('Health check failed with error connecting to Keycloak, status %s: %s', response_.status,
                          await response_.text())
            return response.status_generic_error(503, body='Health check failed')
        resp_json = await response_.json()
        if resp_json.get('status') != 'UP':
            _logger.error('Health check failed with Keycloak status %s: %s', resp_json.get('status'), resp_json)
            return response.status_generic_error(503, body='Health check failed')
        return response.status_ok(None)


@routes.get('/people/me')
@action(name='heaserver-people-person-get-properties', rel='hea-properties')
@action(name='heaserver-people-person-get-self', rel='self', path='people/{id}')
@action(name='heaserver-people-person-get-organizations', rel='application/x.organization', path='organizations/')
@action(name='heaserver-people-person-get-volumes', rel='application/x.volume', path='volumes/')
@action(name='heaserver-people-person-get-desktop-object-actions', rel='application/x.desktopobjectaction', path='desktopobjectactions/')
async def get_me(request: web.Request) -> web.Response:
    """
    Gets the currently logged in person.

    :param request: the HTTP request.
    :return: the requested person or Not Found.
    ---
    summary: A specific person.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
      '404':
        $ref: '#/components/responses/404'
    """
    logger = logging.getLogger(__name__)
    sub = request.headers.get(SUB, NONE_USER)
    try:
        person = cast(Person, await request.app[appproperty.HEA_DB].get_user(request, sub))
    except ClientResponseError as e:
        if e.status == 404:
            person = None
        else:
            return response.status_generic(e.status, body=e.message)
    if person is not None:
        await _add_collection_run_time_actions(request, person, sub)
        context = request.app[appproperty.HEA_DB].get_default_permission_context(request) if 'return_attr' not in request.query else ViewerPermissionContext(sub)
        return await response.get(request, to_dict(person, attrs=request.query.getall('return_attr', None)),
                                  permissions=await person.get_permissions(context),
                                  attribute_permissions=await person.get_all_attribute_permissions(context))
    else:
        return await response.get(request, None)


@routes.get('/people/{id}')
@action(name='heaserver-people-person-get-properties', rel='hea-properties')
@action(name='heaserver-people-person-get-self', rel='self', path='people/{id}')
@action(name='heaserver-people-person-get-organizations', rel='application/x.organization', path='organizations/')
@action(name='heaserver-people-person-get-volumes', rel='application/x.volume', path='volumes/')
@action(name='heaserver-people-person-get-desktop-object-actions', rel='application/x.desktopobjectaction', path='desktopobjectactions/')
async def get_person(request: web.Request) -> web.Response:
    """
    Gets the person with the specified id.
    :param request: the HTTP request.
    :return: the requested person or Not Found.
    ---
    summary: A specific person.
    tags:
        - heaserver-people
    parameters:
        - $ref: '#/components/parameters/id'
    responses:
      '200':
        $ref: '#/components/responses/200'
      '404':
        $ref: '#/components/responses/404'
    """
    logger = logging.getLogger(__name__)
    sub = request.headers.get(SUB, NONE_USER)
    try:
        person = await cast(KeycloakMongo, request.app[appproperty.HEA_DB]).get_user(request, request.match_info['id'])
    except ClientResponseError as e:
        if e.status == 404:
            person = None
        else:
            return response.status_generic(e.status, body=e.message)
    if person is not None:
        await _add_collection_run_time_actions(request, person, sub)
        context = request.app[appproperty.HEA_DB].get_default_permission_context(request) if 'return_attr' not in request.query else ViewerPermissionContext(sub)
        return await response.get(request, to_dict(person, attrs=request.query.getall('return_attr', None)),
                                  permissions=await person.get_permissions(context),
                                  attribute_permissions=await person.get_all_attribute_permissions(context))
    else:
        return await response.get(request, None)


@routes.get('/peopleviews/{id}')
@action(name='heaserver-people-person-get-actual', rel='hea-actual', path='{+actual_object_uri}')
async def get_person_view(request: web.Request) -> web.Response:
    """
    Gets the PersonView with the specified id. PersonView ids are the same as their corresponding Person objects.

    :param request: the HTTP request.
    :return: the requested person view or Not Found.
    ---
    summary: A specific person view.
    tags:
        - heaserver-people
    parameters:
        - $ref: '#/components/parameters/id'
    responses:
      '200':
        $ref: '#/components/responses/200'
      '404':
        $ref: '#/components/responses/404'
    """
    sub = request.headers.get(SUB, NONE_USER)
    try:
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        person = await keycloak_mongo.get_user_view(request, request.match_info['id'])
    except ClientResponseError as e:
        if e.status == 404:
            person = None
        else:
            return response.status_generic(e.status, body=e.message)
    if person is not None:
        context = ViewerPermissionContext(sub)
        return await response.get(request, to_dict(person, attrs=request.query.getall('return_attr', None)),
                                  permissions=await person.get_permissions(context),
                                  attribute_permissions=await person.get_all_attribute_permissions(context))
    else:
        return await response.get(request, None)


@routes.get('/people/byname/{name}')
@action(name='heaserver-people-person-get-self', rel='self', path='people/{id}')
async def get_person_by_name(request: web.Request) -> web.Response:
    """
    Gets the person with the specified id.
    :param request: the HTTP request.
    :return: the requested person or Not Found.
    ---
    summary: A specific person, by name.
    tags:
        - heaserver-people
    parameters:
        - $ref: '#/components/parameters/name'
    responses:
      '200':
        $ref: '#/components/responses/200'
      '404':
        $ref: '#/components/responses/404'
    """
    try:
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        persons = await keycloak_mongo.get_users(request, params={'name': request.match_info['name']})
        if persons:
            context = keycloak_mongo.get_default_permission_context(request)
            first_person = persons[0]
            return await response.get(request, to_dict(first_person),
                                      permissions=await first_person.get_permissions(context),
                                      attribute_permissions=await first_person.get_all_attribute_permissions(context))
        else:
            return await response.get(request, None)
    except ClientResponseError as e:
        return response.status_generic(e.status, body=e.message)


@routes.get('/peopleviews')
@routes.get('/peopleviews/')
@action(name='heaserver-people-person-get-actual', rel='hea-actual', path='{+actual_object_uri}')
async def get_all_person_views(request: web.Request) -> web.Response:
    """
    Gets all person views. The endpoint supports begin, end, and limit query parameters for paging, and it also supports
    sorting. The default sort attribute is name. PersonView ids are the same as their corresponding Person objects.

    :param request: the HTTP request.
    :return: all person views.
    ---
    summary: All person views.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    logger = logging.getLogger(__name__)
    sub = request.headers.get(SUB, NONE_USER)
    try:
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        persons = await keycloak_mongo.get_user_views(request)
        # Do not generate collection run-time actions when retrieving all people because the actions will be based on
        # the user requesting the data not the collections specific to each person in the list.
        context = ViewerPermissionContext(sub)
        return_attrs = request.query.getall('return_attr', None)
        data = [to_dict(person, attrs=return_attrs) for person in persons]
        perms = list(await asyncio.gather(*[person.get_permissions(context) for person in persons]))
        attr_perms = list(await asyncio.gather(*[person.get_all_attribute_permissions(context) for person in persons]))
        return await response.get_all(request, data, permissions=perms, attribute_permissions=attr_perms)
    except ClientResponseError as e:
        return response.status_generic(e.status, body=e.message)


@routes.get('/people')
@routes.get('/people/')
@action(name='heaserver-people-person-get-properties', rel='hea-properties')
@action(name='heaserver-people-person-get-self', rel='self', path='people/{id}')
@action(name='heaserver-people-person-get-organizations', rel='application/x.organization', path='organizations/')
@action(name='heaserver-people-person-get-volumes', rel='application/x.volume', path='volumes/')
@action(name='heaserver-people-person-get-desktop-object-actions', rel='application/x.desktopobjectaction', path='desktopobjectactions/')
async def get_all_people(request: web.Request) -> web.Response:
    """
    Gets all persons. The endpoint supports begin, end, and limit query parameters for paging, and it also supports
    sorting. The default sort attribute is name.

    :param request: the HTTP request.
    :return: all persons.
    ---
    summary: All persons.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    logger = logging.getLogger(__name__)
    sub = request.headers.get(SUB, NONE_USER)
    try:
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        persons = await keycloak_mongo.get_users(request)
        # Do not generate collection run-time actions when retrieving all people because the actions will be based on
        # the user requesting the data not the collections specific to each person in the list.
        use_built_in_sorting = request.query.get('sort_attr') in (None, 'name') and request.query.get('sort', 'desc').lower() == 'asc'
        if not use_built_in_sorting:
            begin, end, _ = get_pagination_params(request)
            persons = persons[begin:end] if end is not None else persons[begin:]
        context = HEAServerPermissionContext(request, sub=sub) if 'return_attr' not in request.query else ViewerPermissionContext(sub)
        return_attrs = request.query.getall('return_attr', None)
        data = [to_dict(person, attrs=return_attrs) for person in persons]
        perms = list(await asyncio.gather(*[person.get_permissions(context) for person in persons]))
        attr_perms = list(await asyncio.gather(*[person.get_all_attribute_permissions(context) for person in persons]))
        if is_sorting_requested(request) and not use_built_in_sorting:
            sorted_data, sorted_perms, sorted_attr_perms = sorted_response_data(request, data, perms, attr_perms)
            return await response.get_all(request, sorted_data, permissions=sorted_perms, attribute_permissions=sorted_attr_perms)
        return await response.get_all(request, data, permissions=perms, attribute_permissions=attr_perms)
    except ClientResponseError as e:
        return response.status_generic(e.status, body=e.message)


@routes.get('/roles')
@routes.get('/roles/')
@action(name='heaserver-people-role-get-properties', rel='hea-properties')
@action(name='heaserver-people-role-get-self', rel='self', path='roles/{id}')
async def get_all_roles(request: web.Request) -> web.Response:
    """
    Gets all roles that are known to Keycloak.
    :param request: the HTTP request.
    :return: all roles.
    ---
    summary: All roles.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    sub = request.headers.get(SUB, NONE_USER)
    try:
        roles = await request.app[appproperty.HEA_DB].get_all_roles(request)
        context = request.app[appproperty.HEA_DB].get_default_permission_context(request) if 'return_attr' not in request.query else ViewerPermissionContext(sub)
        return_attrs = request.query.getall('return_attr', None)
        data = [to_dict(role, attrs=return_attrs) for role in roles]
        perms = list(await asyncio.gather(*[role.get_permissions(context) for role in roles]))
        attr_perms = list(await asyncio.gather(*[role.get_all_attribute_permissions(context) for role in roles]))
        if is_sorting_requested(request):
            sorted_data, sorted_perms, sorted_attr_perms = sorted_response_data(request, data, perms, attr_perms)
            return await response.get_all(request, sorted_data, permissions=sorted_perms, attribute_permissions=sorted_attr_perms)
        return await response.get_all(request, data, permissions=perms, attribute_permissions=attr_perms)
    except ClientResponseError as e:
        if e.status == 404:
            return await response.get_all(request, [])
        else:
            return response.status_generic(e.status, body=e.message)


@routes.get('/roles/{id}')
@action(name='heaserver-people-role-get-properties', rel='hea-properties')
@action(name='heaserver-people-role-get-self', rel='self', path='roles/{id}')
async def get_role(request: web.Request) -> web.Response:
    """
    Gets the requested role.

    :param request: the HTTP request. Requires an Authorization header with a valid Bearer token, in
    addition to the usual OIDC_CLAIM_sub header.
    :return: all roles.
    ---
    summary: All roles.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    sub = request.headers.get(SUB, NONE_USER)
    id_ = request.match_info['id']
    try:
        roles = await request.app[appproperty.HEA_DB].get_all_roles(request)
        role = next((role for role in roles if role.id == id_), None)
        if role is not None:
            context = request.app[appproperty.HEA_DB].get_default_permission_context(request) if 'return_attr' not in request.query else ViewerPermissionContext(sub)
            return await response.get(request, to_dict(role, attrs=request.query.getall('return_attr', None)),
                                      permissions=await role.get_permissions(context),
                                      attribute_permissions=await role.get_all_attribute_permissions(context))
        else:
            return await response.get(request, None)
    except ClientResponseError as e:
        if e.status == 404:
            return response.status_not_found()
        else:
            return response.status_generic(e.status, body=e.message)


@routes.get('/roles/byname/{name}')
async def get_role_by_name(request: web.Request) -> web.Response:
    """
    Gets the requested role. Requires an Authorization header with a valid Bearer token, in
    addition to the usual OIDC_CLAIM_sub header.

    :param request: the HTTP request.
    :return: all roles.
    ---
    summary: All roles.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    sub = request.headers.get(SUB, NONE_USER)
    name = request.match_info['name']
    try:
        roles = await request.app[appproperty.HEA_DB].get_all_roles(request)
        role = next((role for role in roles if role.name == name), None)
        if role is not None:
            context = request.app[appproperty.HEA_DB].get_default_permission_context(request)
            return await response.get(request, role.to_dict(),
                                      permissions=await role.get_permissions(context),
                                      attribute_permissions=await role.get_all_attribute_permissions(context))
        else:
            return await response.get(request, None)
    except ClientResponseError as e:
        if e.status == 404:
            return response.status_not_found()
        else:
            return response.status_generic(e.status, body=e.message)

@routes.post('/roles/internal')
@routes.post('/roles/internal/')
async def create_role_internal(request: web.Request) -> web.Response:
    try:
        obj = await new_heaobject_from_type(request, Role)
    except DeserializeException as e:
        raise response.status_bad_request(str(e))
    if not obj.role:
        raise response.status_bad_request('Role name must be provided')
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    location = await keycloak_mongo.create_role(request, obj.role)
    headers: Mapping[str | istr, str] = {hdrs.LOCATION: location}
    return web.HTTPCreated(headers=headers)


@routes.delete('/roles/internal/{id}')
async def delete_role_internal(request: web.Request) -> web.Response:
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    await keycloak_mongo.delete_role(request, decode_role(request.match_info['id']))
    return await response.delete(True)

@routes.delete('/roles/internal/byname/{name}')
async def delete_role_internal_byname(request: web.Request) -> web.Response:
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    await keycloak_mongo.delete_role(request, decode_role(request.match_info['name']))
    return await response.delete(True)


@routes.post('/groups/internal')
@routes.post('/groups/internal/')
async def create_group_internal(request: web.Request) -> web.Response:
    try:
        obj = await new_heaobject_from_type(request, Group)
    except DeserializeException as e:
        return response.status_bad_request(str(e))
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    location = await keycloak_mongo.create_group(request, obj)
    headers: Mapping[str | istr, str] = {hdrs.LOCATION: location}
    return web.HTTPCreated(headers=headers)


@routes.delete('/groups/internal/{id}')
async def delete_group_internal(request: web.Request) -> web.Response:
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    await keycloak_mongo.delete_group_recursive(request, request.match_info['id'])
    return await response.delete(True)

@routes.delete('/groups/internal/byname/{name}')
async def delete_group_internal_byname(request: web.Request) -> web.Response:
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    name = request.match_info['name']
    path = _group_name_to_path_or_raise(name)
    await keycloak_mongo.delete_group_by_path_recursive(request, path, delete_empty_ancestors=True)
    return await response.delete(True)


@routes.get('/groups')
@routes.get('/groups/')
@action(name='heaserver-people-group-get-properties', rel='hea-properties')
@action(name='heaserver-people-group-get-self', rel='self', path='groups/{id}')
async def get_all_groups(request: web.Request) -> web.Response:
    """
    Gets all groups that are known to Keycloak. The default sort attribute is display_name, which is the name of the
    group.

    :param request: the HTTP request.
    :return: all groups.
    ---
    summary: All groups.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    logger = logging.getLogger(__name__)
    sub = request.headers.get(SUB, NONE_USER)
    try:
        groups = await request.app[appproperty.HEA_DB].get_all_groups(request)
        logger.debug('groups: %s', groups)
        context = request.app[appproperty.HEA_DB].get_default_permission_context(request) if 'return_attr' not in request.query else ViewerPermissionContext(sub)
        return_attrs = request.query.getall('return_attr', None)
        data = [to_dict(group, attrs=return_attrs) for group in groups]
        perms = list(await asyncio.gather(*[group.get_permissions(context) for group in groups]))
        attr_perms = list(await asyncio.gather(*[group.get_all_attribute_permissions(context) for group in groups]))
        if is_sorting_requested(request):
            sorted_data, sorted_perms, sorted_attr_perms = sorted_response_data(request, data, perms, attr_perms)
            return await response.get_all(request, sorted_data, permissions=sorted_perms, attribute_permissions=sorted_attr_perms)
        return await response.get_all(request, data, permissions=perms, attribute_permissions=attr_perms)
    except ClientResponseError as e:
        if e.status == 404:
            return await response.get_all(request, [])
        else:
            return response.status_generic(e.status, body=e.message)


@routes.get('/groupviews')
@routes.get('/groupviews/')
@action(name='heaserver-people-group-get-actual', rel='hea-actual', path='{+actual_object_uri}')
async def get_all_group_views(request: web.Request) -> web.Response:
    """
    Gets all group views that are known to Keycloak. The default sort attribute is display_name, which is the name of
    the group. GroupView ids are the same as their corresponding Group objects.

    :param request: the HTTP request.
    :return: all group views.
    ---
    summary: All group views.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    logger = logging.getLogger(__name__)
    sub = request.headers.get(SUB, NONE_USER)
    try:
        groups = await cast(KeycloakMongo, request.app[appproperty.HEA_DB]).get_all_group_views(request)
        logger.debug('groups: %s', groups)
        context = ViewerPermissionContext(sub)
        return_attrs = request.query.getall('return_attr', None)
        data = [to_dict(group, attrs=return_attrs) for group in groups]
        perms = list(await asyncio.gather(*[group.get_permissions(context) for group in groups]))
        attr_perms = list(await asyncio.gather(*[group.get_all_attribute_permissions(context) for group in groups]))
        if is_sorting_requested(request):
            sorted_data, sorted_perms, sorted_attr_perms = sorted_response_data(request, data, perms, attr_perms)
            return await response.get_all(request, sorted_data, permissions=sorted_perms, attribute_permissions=sorted_attr_perms)
        return await response.get_all(request, data, permissions=perms, attribute_permissions=attr_perms)
    except ClientResponseError as e:
        if e.status == 404:
            return await response.get_all(request, [])
        else:
            return response.status_generic(e.status, body=e.message)


@routes.get('/groups/{id}')
@action(name='heaserver-people-group-get-properties', rel='hea-properties')
@action(name='heaserver-people-group-get-self', rel='self', path='groups/{id}')
async def get_group(request: web.Request) -> web.Response:
    """
    Gets the requested group. Requires an Authorization header with a valid Bearer token, in
    addition to the usual OIDC_CLAIM_sub header.

    :param request: the HTTP request.
    :return: all groups.
    ---
    summary: All groups.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    sub = request.headers.get(SUB, NONE_USER)
    id_ = request.match_info['id']
    try:
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        group = await keycloak_mongo.get_group(request, id_)
        if group is not None:
            context = keycloak_mongo.get_default_permission_context(request) if 'return_attr' not in request.query else ViewerPermissionContext(sub)
            return await response.get(request, to_dict(group, attrs=request.query.getall('return_attr', None)),
                                      permissions=await group.get_permissions(context),
                                      attribute_permissions=await group.get_all_attribute_permissions(context))
        else:
            return await response.get(request, None)
    except ClientResponseError as e:
        if e.status == 404:
            raise response.status_not_found()
        else:
            raise response.status_generic_error(e.status, body=e.message)


@routes.get('/groupviews/{id}')
@action(name='heaserver-people-group-get-actual', rel='hea-actual', path='{+actual_object_uri}')
async def get_group_view(request: web.Request) -> web.Response:
    """
    Gets the group view with the specified id. GroupView ids are the same as their corresponding Group objects.

    :param request: the HTTP request.
    :return: the requested group view or Not Found.
    ---
    summary: A specific group view.
    tags:
        - heaserver-people
    parameters:
        - $ref: '#/components/parameters/id'
    responses:
      '200':
        $ref: '#/components/responses/200'
      '404':
        $ref: '#/components/responses/404'
    """
    sub = request.headers.get(SUB, NONE_USER)
    try:
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        group = await keycloak_mongo.get_group_view(request, request.match_info['id'])
    except ClientResponseError as e:
        if e.status == 404:
            group = None
        else:
            raise response.status_generic_error(e.status, body=e.message)
    if group is not None:
        context = ViewerPermissionContext(sub)
        return await response.get(request, to_dict(group, attrs=request.query.getall('return_attr', None)),
                                  permissions=await group.get_permissions(context),
                                  attribute_permissions=await group.get_all_attribute_permissions(context))
    else:
        return await response.get(request, None)


@routes.get('/groups/byname/{name}')
async def get_group_by_name(request: web.Request) -> web.Response:
    """
    Gets the requested group. Requires an Authorization header with a valid Bearer token, in
    addition to the usual OIDC_CLAIM_sub header.

    :param request: the HTTP request.
    :return: all groups.
    ---
    summary: All groups.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    logger = logging.getLogger(__name__)
    name = request.match_info['name']
    path = _group_name_to_path_or_raise(name)
    try:
        logger.debug('Getting group by name %s', name)
        group = await request.app[appproperty.HEA_DB].get_group_by_group(request, path)
        logger.debug('group %s with name %s', group, name)
        if group is not None:
            context = request.app[appproperty.HEA_DB].get_default_permission_context(request)
            return await response.get(request, group.to_dict(),
                                      permissions=await group.get_permissions(context),
                                      attribute_permissions=await group.get_all_attribute_permissions(context))
        else:
            return await response.get(request, None)
    except ClientResponseError as e:
        logger.exception('Got client response error')
        if e.status == 404:
            return response.status_not_found()
        else:
            return response.status_generic(e.status, body=e.message)


@routes.get('/groupviews/byname/{name}')
async def get_group_view_by_name(request: web.Request) -> web.Response:
    """
    Gets the requested group view. Requires an Authorization header with a valid Bearer token, in
    addition to the usual OIDC_CLAIM_sub header.

    :param request: the HTTP request.
    :return: the requested group view.
    ---
    summary: Get group view by name.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    logger = logging.getLogger(__name__)
    name = request.match_info['name']
    path = _group_name_to_path_or_raise(name)
    try:
        logger.debug('Getting group view by name %s', name)
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        group = await keycloak_mongo.get_group_view_by_group(request, path)
        logger.debug('group view %s with name %s', group, name)
        if group is not None:
            context = ViewerPermissionContext(request.headers.get(SUB, NONE_USER))
            return await response.get(request, to_dict(group),
                                      permissions=await group.get_permissions(context),
                                      attribute_permissions=await group.get_all_attribute_permissions(context))
        else:
            return await response.get(request, None)
    except ClientResponseError as e:
        logger.exception('Got client response error')
        if e.status == 404:
            return response.status_not_found()
        else:
            return response.status_generic(e.status, body=e.message)


@routes.post('/people/{person_id}/groups')
@routes.post('/people/{person_id}/groups/')
async def post_user_group(request: web.Request) -> web.Response:
    logger = logging.getLogger(__name__)
    person_id = request.match_info['person_id']
    logger.debug('Adding group to user %s', person_id)
    try:
        obj = await new_heaobject_from_type(request, Group)
    except DeserializeException as e:
        return response.status_bad_request(str(e))
    logger.debug('Adding group %r to user %s', obj, person_id)
    if person_id == 'me':
        await request.app[appproperty.HEA_DB].add_current_user_to_group(request, obj.id)
    else:
        if is_system_user(person_id):
            return response.status_forbidden('System users are read-only')
        await request.app[appproperty.HEA_DB].add_user_to_group(request, person_id, obj.id)
    return await response.post(request, obj.id, 'groups')

@routes.get('/people/{person_id}/groups')
@routes.get('/people/{person_id}/groups/')
async def get_user_group(request: web.Request) -> web.Response:
    """
    Gets all groups for the current user.
    :param request: the HTTP request.
    :return: all groups.
    ---
    summary: All groups.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    person_id = request.match_info['person_id']
    try:
        if person_id == 'me':
            groups = await request.app[appproperty.HEA_DB].get_current_user_groups(request)
        else:
            groups = await request.app[appproperty.HEA_DB].get_user_groups(request, person_id)
        context = request.app[appproperty.HEA_DB].get_default_permission_context(request)
        perms = list(await asyncio.gather(*[group.get_permissions(context) for group in groups]))
        attr_perms = list(await asyncio.gather(*[group.get_all_attribute_permissions(context) for group in groups]))
        return await response.get_all(request, [group.to_dict() for group in groups],
                                      permissions=perms,
                                      attribute_permissions=attr_perms)
    except ClientResponseError as e:
        if e.status == 404:
            return await response.get_all(request, [])
        else:
            return response.status_generic(e.status, body=e.message)


@routes.get('/people/{person_id}/groupviews')
@routes.get('/people/{person_id}/groupviews/')
async def get_user_group_views(request: web.Request) -> web.Response:
    """
    Gets all group views for the current user.
    :param request: the HTTP request.
    :return: all group views.
    ---
    summary: All group views.
    tags:
        - heaserver-people
    responses:
      '200':
        $ref: '#/components/responses/200'
    """
    person_id = request.match_info['person_id']
    try:
        keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
        if person_id == 'me':
            groups = await keycloak_mongo.get_current_user_group_views(request)
        else:
            groups = await keycloak_mongo.get_user_group_views(request, person_id)
        context = ViewerPermissionContext(request.headers.get(SUB, NONE_USER))
        perms = list(await asyncio.gather(*[group.get_permissions(context) for group in groups]))
        attr_perms = list(await asyncio.gather(*[group.get_all_attribute_permissions(context) for group in groups]))
        return await response.get_all(request, [to_dict(group) for group in groups],
                                      permissions=perms,
                                      attribute_permissions=attr_perms)
    except ClientResponseError as e:
        if e.status == 404:
            return await response.get_all(request, [])
        else:
            return response.status_generic(e.status, body=e.message)


@routes.delete('/people/{person_id}/groups/{id}')
async def delete_user_group(request: web.Request) -> web.Response:
    id_ = request.match_info['id']
    person_id = request.match_info['person_id']
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    if person_id == 'me':
        result = await keycloak_mongo.remove_current_user_group(request, id_)
    else:
        if is_system_user(person_id):
            raise response.status_forbidden('System users are read-only')
        result = await keycloak_mongo.remove_user_group(request, person_id, id_)
    return await response.delete(result)

@routes.delete('/people/{person_id}/groups/bygroup/{group}')
async def delete_group_by_group(request: web.Request) -> web.Response:
    path = request.match_info['group']
    person_id = request.match_info['person_id']
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    if person_id == 'me':
        result = await keycloak_mongo.remove_current_user_group_by_path(request, path)
    else:
        if is_system_user(person_id):
            raise response.status_forbidden('System users are read-only')
        result = await keycloak_mongo.remove_user_group_by_path(request, person_id, path)
    return await response.delete(result)

@routes.delete('/people/{person_id}/groups/byname/{name}')
async def delete_group_by_name(request: web.Request) -> web.Response:
    name = request.match_info['name']
    person_id = request.match_info['person_id']
    path = _group_name_to_path_or_raise(name)
    keycloak_mongo = cast(KeycloakMongo, request.app[appproperty.HEA_DB])
    if person_id == 'me':
        result = await keycloak_mongo.remove_current_user_group_by_path(request, path)
    else:
        result = await keycloak_mongo.remove_user_group_by_path(request, person_id, path)
    return await response.delete(result)


@routes.get('/people/internal/token')
async def get_token(request: web.Request) -> web.Response:
    logger = logging.getLogger(__name__)
    try:
        if logger.getEffectiveLevel() == logging.DEBUG:
            logger.debug('headers %s', request.headers)
        token = await request.app[appproperty.HEA_DB].get_keycloak_alt_access_token(request)
    except ClientResponseError as e:
        logger.exception('Got client response error')
        if e.status == 404:
            return response.status_not_found()
        else:
            return response.status_generic(e.status, body=e.message)
    except B64DecodeError as e:
        return response.status_not_found()
    return await response.get(request, token.to_dict())

def start_with(config: Configuration) -> None:
    start(package_name='heaserver-people', db=KeycloakMongoManager, config=config,
          wstl_builder_factory=builder_factory(__package__))


async def _add_collection_run_time_actions(request: web.Request, person: Person, sub: str):
    if is_system_user(sub) or sub != person.id:
        return
    url = await type_to_resource_url(request, Collection)
    return_attrs = ('collection_type_name', 'display_in_system_menu', 'display_in_user_menu', 'display_name')
    query_params: MultiDict[str] = MultiDict()
    for attr in return_attrs:
        query_params.add('return_attr', attr)
    async for collection in client.get_all(request.app, url, Collection, headers={SUB: sub},
                                           query_params=query_params):
        assert collection.collection_type_name is not None, 'collection.collection_type_name cannot be None'
        if collection.display_in_system_menu or collection.display_in_user_menu:
            wstl_ = cast(RuntimeWeSTLDocumentBuilder, request[HEA_WSTL_BUILDER])
            wstl_.add_design_time_action({
                "name": "heaserver-people-person-get-collection-" + collection.collection_type_name,
                "description": f"View and edit {collection.display_name.lower()}",
                "type": "safe",
                "action": "read",
                "target": "item read cj",
                "prompt": collection.display_name
            })
            rell = []
            if collection.display_in_system_menu:
                rell.append('hea-system-menu-item')
            if collection.display_in_user_menu:
                rell.append('hea-user-menu-item')
            rell.append(collection.collection_type_name)
            add_run_time_action(request,
                                name='heaserver-people-person-get-collection-' + collection.collection_type_name,
                                rel=' '.join(rell),
                                path=str((URL('collections') / collection.collection_type_name)))


def _group_name_to_path_or_raise(name: str) -> str:
    try:
        path = decode_group(name)
        if not path.startswith('/'):
            raise response.status_bad_request(f'Invalid name {name}')
        return path
    except DeserializeException as e:
        raise response.status_bad_request(str(e))
