from typing import Any, cast
from heaserver.service.db.mongo import Mongo, MongoManager
from heaserver.service.client import get_property
from heaserver.service.util import LockManager, queued_processing, merge_multi_mappings_iter
from heaserver.service.aiohttp import SortOrder, extract_sorts_and_sort_attrs_from_params, extract_sorts_from_params, resolve_missing_attr_params, resolve_single_query_params, \
    sort_desktop_objects_from_params, filter_desktop_objects_from_params, sort_desktop_objects_from_sort_info
from heaserver.service.heaobjectsupport import HEAServerPermissionContext
from heaserver.service.oidcclaimhdrs import SUB
from heaserver.service.config import Configuration
from heaserver.service.crypt import SecretDecryption
from heaserver.service import appproperty, response
from heaobject.person import Person, get_system_people, AccessToken, PersonView, Group, GroupView, Role, encode_role, \
    decode_role, GroupType, get_system_person_view, get_system_people_views, get_system_person
from heaobject.root import DesktopObjectDict, Permission, Share, ShareImpl
from heaobject.util import to_bool, system_timezone
from heaobject.user import NONE_USER, CREDENTIALS_MANAGER_USER, ALL_USERS, is_system_user
from aiohttp.web import Request, Application
from aiohttp import ClientResponseError, ClientSession, hdrs
from yarl import URL
import logging
from pathlib import Path
from datetime import datetime, timedelta
from enum import Enum
from functools import partial
from asyncio import gather
from cachetools import TTLCache
from copy import copy, deepcopy
from collections.abc import Mapping, AsyncIterator, Sequence, Iterable
from collections import deque
from asyncio import Lock
from itertools import islice
from .queryparammanager import GroupQueryParamManager, GroupViewQueryParamManager, PersonViewQueryParamManager, QueryParamManager
from .util import get_pagination_params
import urllib
from multidict import MultiDict


KEYCLOAK_QUERY_ADMIN_SECRET = 'KEYCLOAK_QUERY_ADMIN_SECRET'
DEFAULT_CLIENT_ID = 'hea'
DEFAULT_ADMIN_CLIENT_ID = 'admin-cli'
DEFAULT_REALM = 'hea'
DEFAULT_HOST = 'https://localhost:8444'
DEFAULT_SECRET_FILE = '.secret'
DEFAULT_VERIFY_SSL = True

CONFIG_SECTION = 'Keycloak'
KEYCLOAK_TEST_IMAGE = 'quay.io/keycloak/keycloak:15.0.2'

_ACCESS_TOKEN_LOCK = Lock()


class KeycloakCompatibility(Enum):
    """Keycloak compatibility levels:
        FIFTEEN: APIs prior to version 19. We have only tested with 15.
        NINETEEN: APIs for version 19 and later.
    """
    FIFTEEN = "15"
    NINETEEN = "19"

DEFAULT_KEYCLOAK_COMPATIBILITY = KeycloakCompatibility.FIFTEEN


class PeopleServicePermissionContext(HEAServerPermissionContext):
    """
    A permission context for the HEA server. It is used to check permissions for the HEA server. It overrides methods
    of HEAServerPermissionContext that query the people service via its REST APIs. It instead queries the Keycloak
    server directly.
    """

    def __init__(self, request: Request, keycloak_mongo: 'KeycloakMongo'):
        """
        Initializes the permission context.

        :param keycloak_mongo: the KeycloakMongo object.
        """
        super().__init__(request)
        self.__keycloak_mongo = keycloak_mongo

    async def get_permissions(self, obj) -> list[Permission]:
        """
        Gets the permissions for the given object. A user never gets the DELETER permission for their own Person
        object.

        :param obj: the object to get permissions for.
        :return: a list of Permission objects.
        """
        candidate_perms = await super().get_permissions(obj)
        if isinstance(obj, Person) and self.sub == obj.id:
            return list(p for p in candidate_perms if p not in (Permission.DELETER, Permission.COOWNER))
        else:
            return candidate_perms

    async def get_groups(self) -> list[str]:
        return await self.__keycloak_mongo.get_user_group_ids(self.request, self.sub)

    async def group_id_from(self, group: str) -> str | None:
        group_ = await self.__keycloak_mongo.get_user_group_view_by_path(self.request, self.sub, group)
        if not group_:
            return None
        assert group_.id is not None, f'Group {group} has no id'
        return group_.id


class KeycloakMongo(Mongo):
    """
    Database object for accessing a keycloak server. It subclasses Mongo so that some user data that Keycloak does not
    support might be stored in Mongo.
    """

    _all_groups_lock = Lock()
    _all_people_lock = Lock()

    def __init__(self, config: Configuration | None = None,
                 client_id: str | None = DEFAULT_CLIENT_ID,
                 admin_client_id: str | None = DEFAULT_ADMIN_CLIENT_ID,
                 realm: str | None = DEFAULT_REALM,
                 host: str | None = DEFAULT_HOST,
                 alt_host: str | None = None,
                 secret: str | None = None,
                 secret_file: str | None = DEFAULT_SECRET_FILE,
                 verify_ssl: bool = DEFAULT_VERIFY_SSL,
                 keycloak_compatibility: KeycloakCompatibility | None = KeycloakCompatibility.FIFTEEN,
                 request: Request | None = None):
        """
        Initializes Keycloak access with a configparser object or manually set configuration parameters. For all
        manually set configuration parameters, the empty string is treated the same as None.

        :param config: a Configuration object, which should have a Keycloak section with the following properties:

            Realm = the Keycloak realm.
            VerifySSL = whether to verify SSL certificates (defaults to yes).
            Host = the host part of the base URL string to use in constructing URLs to query Keycloak's REST APIs
            (defaults to https://localhost:8444).
            AltHost = the alternate host for getting the alt access token. Defaults to the value of host if
            unspecified.
            Secret = the secret for accessing keycloak.
            SecretFile = alternatively, a file with one line containing the secret.
            Compatibility = 15 or 19 denoting Keycloak 15-18 versus >= 19. The default is 15.
            ClientId = the client id to use. The default is hea.
            AdminClientId = the admin client id to use. The default is admin-cli.

        :param client_id: the client id to use. The default is hea.
        :param admin_client_id: the admin client id to use. The default is admin-cli.
        :param realm: the realm to use if there is no config file or the config file does not specify one. The default
        is hea.
        :param host: the host part of the base URL string to use in constructing URLs to query Keycloak's REST APIs. If
        a configparser.ConfigParser object is provided and has a Host value, this parameter is ignored. The default is
        https://localhost:8444.
        :param alt_host: the alternate hostname for getting the alt access token. If a configparser.ConfigParser object
        is provided and has an AltHost value, this parameter is ignored. Defaults to the value of host if unspecified
        in the config or this parameter.
        :param secret: the secret to use if there is no config file or the config file does not specify one.
        :param secret_file: the path of a file with one line containing the secret if there is no config file or the
        config file does not specify one. There must be either a secret or a secret file.
        :param verify_ssl: whether to verify Keycloak's SSL certificate. The default value is True.
        :param keycloak_compatibility: the compatibility level if there is no config file or the config file does not
        specify one. Defaults to FIFTEEN.
        """
        super().__init__(config, request=request)
        self.__ttl_cache: TTLCache[tuple, Any] = TTLCache(maxsize=128, ttl=30)
        self.__config = config
        if config and CONFIG_SECTION in config.parsed_config:
            _section = config.parsed_config[CONFIG_SECTION]
            _realm = _section.get('Realm', realm)
            self.__realm = str(_realm) if _realm is not None else DEFAULT_REALM
            self.__verify_ssl = _section.getboolean('VerifySSL',
                                                    verify_ssl if verify_ssl is not None else DEFAULT_VERIFY_SSL)
            self.__host = str(_section.get('Host', host) or DEFAULT_HOST)
            self.__alt_host = str(_section.get('AltHost', alt_host) or self.__host)
            _secret = _section.get('Secret', secret)
            self.__secret = _secret if _secret else None
            _secret_file = _section.get('SecretFile', secret_file)
            self.__secret_file = _secret_file if _secret_file else None
            compat = _section.get('Compatibility',
                                  None) or keycloak_compatibility or DEFAULT_KEYCLOAK_COMPATIBILITY.value
            self.__keycloak_compatibility = KeycloakCompatibility(compat)
            _client_id = _section.get('ClientId', client_id)
            self.__client_id = str(_client_id) if _client_id is not None else DEFAULT_CLIENT_ID
            _admin_client_id = _section.get('AdminClientId', admin_client_id)
            self.__admin_client_id = str(_admin_client_id) if _admin_client_id is not None else DEFAULT_ADMIN_CLIENT_ID
        else:
            self.__realm = str(realm) if realm is not None else DEFAULT_REALM
            self.__verify_ssl = bool(verify_ssl) if verify_ssl is not None else DEFAULT_VERIFY_SSL
            self.__host = str(host) if host is not None else DEFAULT_HOST
            self.__alt_host = str(alt_host) if alt_host is not None else self.__host
            self.__secret = str(secret) if secret is not None else None
            self.__secret_file = str(secret_file) if secret_file is not None else None
            if keycloak_compatibility is not None and not isinstance(keycloak_compatibility, KeycloakCompatibility):
                raise ValueError(
                    f'Keycloak_compatibility must be a KeycloakCompatibility enum value or None but was {keycloak_compatibility}')
            self.__keycloak_compatibility = keycloak_compatibility or DEFAULT_KEYCLOAK_COMPATIBILITY
            self.__client_id = str(client_id) if client_id is not None else DEFAULT_CLIENT_ID
            self.__admin_client_id = str(admin_client_id) if admin_client_id is not None else DEFAULT_ADMIN_CLIENT_ID
        if self.keycloak_compatibility == KeycloakCompatibility.FIFTEEN:
            self.__base_url = URL(self.host) / 'auth'
            self.__alt_base_url = URL(self.alt_host) / 'auth' if self.__alt_host else self.__base_url
        else:
            self.__base_url = URL(self.host)
            self.__alt_base_url = URL(self.alt_host) if self.__alt_host else self.__base_url
        logger = logging.getLogger(__name__)
        logger.info('Using Keycloak %s mode', self.__keycloak_compatibility.value)
        if self.__host is None:
            raise ValueError
        logger.debug('host is %s', self.__host)
        self.__expiry: datetime | None = None
        self.__access_token: AccessToken | None = None
        self.__client_uuid: str | None = None
        self.__user_lock_manager = LockManager[str]()
        self.__realm_base_url = self.base_url / 'admin' / 'realms' / self.realm

    @property
    def client_id(self) -> str:
        """The Keycloak client id. The default is hea."""
        return self.__client_id

    @property
    def admin_client_id(self) -> str:
        """The Keycloak admin client id. The default is admin-cli."""
        return self.__admin_client_id

    @property
    def realm(self) -> str:
        return self.__realm

    @property
    def host(self) -> str:
        """The url string specified in the Host property in the HEA config file, passed into the object's constructor,
        or the default value of https://localhost:8444."""
        return self.__host

    @property
    def alt_host(self) -> str:
        """The alternate hostname for getting the alt access token. Defaults to the value of host if unspecified in the
        config or this parameter."""
        return self.__alt_host

    async def get_secret(self, request: Request | None = None, app: Application | None = None) -> str | None:
        """The Keycloak secret specified in the Secret property in the HEA config file, the file specified in the HEA
        config, passed into the object's constructor, or obtained from a HEA property. The secret is decrypted on the
        fly if necessary.

        :param request: the HTTP request (optional). If not provided, the request passed into the constructor is used,
        if any. If neither is provided, the secret is obtained only from the secret file, config, or constructor.
        :param app: the application (optional). Used if no request is provided.
        :return: the secret or None if not found."""
        logger = logging.getLogger(__name__)
        _request = request or self.request
        secret: str | None = None
        if self.secret_file and (secret_file_path := Path(self.secret_file)).exists():
            secret = secret_file_path.read_text(encoding='utf-8')
            logger.debug('Read secret from file')
        elif self.__secret is not None:
            secret = self.__secret
            logger.debug('Read secret from config or constructor')
        elif _request and (secret_property := await get_property(_request.app, KEYCLOAK_QUERY_ADMIN_SECRET)):
            secret = secret_property.value
            logger.debug('Read secret from registry service')
        elif app and (secret_property := await get_property(app, KEYCLOAK_QUERY_ADMIN_SECRET)):
            secret = secret_property.value
            logger.debug('Read secret from registry service')
        if _request:
            secret_decryption = SecretDecryption.from_request(_request)
        elif app:
            secret_decryption = SecretDecryption.from_app(app)
        else:
            secret_decryption = self.__config.get_secret_decryption() if self.__config else None
        if secret and secret_decryption:
            return secret_decryption.decrypt_config_property(secret)
        return secret

    @property
    def secret_file(self) -> str | None:
        return self.__secret_file

    @property
    def verify_ssl(self) -> bool:
        return self.__verify_ssl

    @property
    def keycloak_compatibility(self) -> KeycloakCompatibility:
        return self.__keycloak_compatibility

    @property
    def base_url(self) -> URL:
        """The host URL plus /auth or not depending on whether keycloak compatibility is set to 15 or 19."""
        return self.__base_url

    def get_default_permission_context(self, request: Request) -> PeopleServicePermissionContext:
        return PeopleServicePermissionContext(request, self)

    async def get_keycloak_access_token(self, request: Request) -> AccessToken | None:
        """
        Request an access token from Keycloak. It tries obtaining a secret from the following places, in order:
        1) The secret parameter of this class' constructor, or the Secret property of the Keycloak section of the HEA
        config file.
        2) A file whose name is passed into the constructor, or provided in the SecretFile property of the Keycloak
        section of the HEA config file. The file must contain one line with the secret.
        3) The KEYCLOAK_QUERY_ADMIN_SECRET registry property.

        :param use_alt_base_url:
        :param request: the HTTP request (request).
        :return: the access token or None if not found.
        """
        async with _ACCESS_TOKEN_LOCK:
            if self.__expiry and self.__expiry >= datetime.now() + timedelta(minutes=1):
                return self.__access_token
            else:
                session = _client_session(request)
                logger = logging.getLogger(__name__)

                token_url = self.__base_url / 'realms' / self.realm / 'protocol' / 'openid-connect' / 'token'
                logger.debug('Requesting new access token using credentials')
                if secret := await self.get_secret(request):
                    pass
                else:
                    raise ValueError('No secret defined')
                token_body = {
                    'client_secret': secret,
                    'client_id': self.admin_client_id,
                    'grant_type': 'client_credentials'
                }
                logger.debug('Going to verify ssl? %r', self.verify_ssl)
                async with session.post(token_url, data=token_body, ssl=self.verify_ssl) as response_:
                    content = await response_.json()
                    logger.debug('content %s', content)
                    access_token = content['access_token']
                    self.__expiry = datetime.now() + timedelta(seconds=int(content['expires_in']))
                    access_token_obj = AccessToken()
                    access_token_obj.id = access_token
                    self.__access_token = access_token_obj
                return access_token_obj

    async def get_keycloak_alt_access_token(self, request: Request) -> AccessToken:
        """
        Request an access token from Keycloak with alternate path. It tries obtaining a secret from the following places, in order:
        1) The secret parameter of this class' constructor, or the Secret property of the Keycloak section of the HEA
        config file.
        2) A file whose name is passed into the constructor, or provided in the SecretFile property of the Keycloak
        section of the HEA config file. The file must contain one line with the secret.
        3) The KEYCLOAK_QUERY_ADMIN_SECRET registry property.

        :param request: the HTTP request (request).
        :return: the access token or None if not found.
        """
        async with _ACCESS_TOKEN_LOCK:
            session = _client_session(request)
            logger = logging.getLogger(__name__)

            token_url = self.__alt_base_url / 'realms' / self.realm / 'protocol' / 'openid-connect' / 'token'
            logger.debug('Requesting new access token using credentials')
            if secret := await self.get_secret(request):
                pass
            else:
                raise ValueError('No secret defined')
            token_body = {
                'client_secret': secret,
                'client_id': self.admin_client_id,
                'grant_type': 'client_credentials'
            }
            logger.debug('Going to verify ssl? %r', self.verify_ssl)
            async with session.post(token_url, data=token_body, ssl=self.verify_ssl) as response_:
                content = await response_.json()
                logger.debug('content %s', content)
                access_token = content['access_token']
                access_token_obj = AccessToken()
                access_token_obj.id = access_token
            return access_token_obj

    async def get_users(self, request: Request, params: dict[str, str] | None = None) -> list[Person]:
        """
        Gets a list of users from Keycloak using the '/auth/admin/realms/{realm}/users' REST API call.

        :param request: the HTTP request (required).
        :param params: any query parameters to add to the users request.
        :return: a list of Person objects, or the empty list if there are none.
        """
        logger = logging.getLogger(__name__)
        async with self._all_people_lock:
            exclude_system_users = to_bool(request.query.get('excludesystem', 'no'))
            ids = set(request.query.getall('id', []))
            cached_val = self.__ttl_cache.get(('all_users', exclude_system_users, None))
            if cached_val is not None:
                return list(val for val in cached_val if not ids or val.id in ids)
            else:
                access_token_obj = await self.get_keycloak_access_token(request)
                assert access_token_obj is not None, 'access_token_obj cannot be None'
                access_token = access_token_obj.id
                session = _client_session(request)
                users_url_ = self.__base_url / 'admin' / 'realms' / self.realm / 'users'
                params_ = {}
                for k, v in (params or {}).items():
                    match k:
                        case 'name':
                            params_['username'] = v
                        case 'first_name':
                            params_['firstName'] = v
                        case 'last_name':
                            params_['lastName'] = v
                        case _:
                            params_[k] = v
                if exclude_system_users:
                    persons: list[Person] = []
                else:
                    persons = [system_person for system_person in get_system_people() if (not ids or system_person.id in ids) and (not params or params.get('name') == system_person.name)]
                person_ids = set(p.id for p in persons)
                logger.debug('Getting users from URL %s', users_url_)
                async with session.get(users_url_,
                                    headers={'Authorization': f'Bearer {access_token}'},
                                    ssl=self.verify_ssl) as response_:
                    async def get_groups(user_json: Mapping[str, Any]) -> list[dict[str, Any]]:
                        group_dicts: list[dict[str, Any]] = []
                        async for group_dict in self.__get_user_groups_json(request, user_json['id']):
                            group_dicts.append(group_dict)
                        return group_dicts
                    async def worker(user_json: Mapping[str, Any]):
                        person = self.__keycloak_user_to_person(user_json, await get_groups(user_json))
                        if not params or all(p for p in params.keys() if getattr(person, p) == params[p]):
                            persons.append(person)
                    async def user_iterator() -> AsyncIterator[dict[str, Any]]:
                        for user_json in await response_.json():
                            if user_json['id'] not in person_ids and (not ids or user_json['id'] in ids):
                                person_ids.add(user_json['id'])
                                yield user_json
                    await queued_processing(user_iterator(), worker)
                self.__ttl_cache[('all_users', exclude_system_users, None)] = persons
                for person in persons:
                    self.__ttl_cache[('one_user', person.id)] = person
                return deepcopy(persons)

    async def get_user_views(self, request: Request, params: Mapping[str, str] | None = None) -> list[PersonView]:
        """
        Gets a list of users from Keycloak using the '/auth/admin/realms/{realm}/users' REST API call as PersonView
        objects.  Supports begin, end, and limit query parameters for paging. Also supports filter_attr and filter
        query parameters for filtering by an arbitrary PersonView attribute. For example, filter_attr=username and
        filter=jsmith would filter by username. If multiple filter_attr and filter parameters are provided, they are
        combined with AND logic. Providing a filter parameter without a filter_attr parameter applies the filter to
        keycloak's default search fields, which are username, first name, last name, and email. Only one filter
        parameter is allowed per filter attribute, and if more than one is provided, only the last one is applied.
        Similarly, sort_attr and sort query parameters are supported for sorting by an arbitrary PersonView attribute,
        and return_attr query parameters are supported for specifying arbitrary PersonView attributes to return. The
        default sort_attr is username, and the sort parameter is required for sorting.

        :param request: the HTTP request (required).
        :param params: any query parameters to add to the users request.
        :return: a list of PersonView objects, or the empty list if there are none.
        """
        logger = logging.getLogger(__name__)
        async with self._all_people_lock:
            resolved_params = resolve_missing_attr_params(resolve_single_query_params(merge_multi_mappings_iter(request.query, params or {}),
                                                                                    obj=PersonView(),
                                                                                    extra_singles=('excludesystem',)))
            logger.debug('Resolved params are %s', resolved_params)
            exclude_system_users = to_bool(resolved_params.get('excludesystem', 'no'))
            cache_key = ('all_user_views', exclude_system_users, None)
            cached_val = cast(list[PersonView], self.__ttl_cache.get(cache_key))
            try:
                query_param_mgr = PersonViewQueryParamManager({k: v for k, v in merge_multi_mappings_iter(request.query, params or {})})
            except ValueError as e:
                raise response.status_bad_request(f'{e}') from e
            begin, _, limit = get_pagination_params(request)
            logger.debug('begin is %d, limit is %d', begin, limit)
            if cached_val is not None:
                logger.debug('Found user views in all_user_views cache')
                return list(islice((deepcopy(o) for o in sort_desktop_objects_from_sort_info(query_param_mgr.sorts, query_param_mgr.filter_by_all_params(cached_val))), begin, (begin + limit) if limit is not None else None))
            elif cached_all_users := cast(list[Person], self.__ttl_cache.get(('all_users', exclude_system_users, None))):
                logger.debug('Found users in all_users cache, converting to user views')
                result = list(_person_to_person_view(val) for val in cached_all_users)
                self.__ttl_cache[cache_key] = result
                return list(islice((deepcopy(o) for o in sort_desktop_objects_from_sort_info(query_param_mgr.sorts, query_param_mgr.filter_by_all_params(result))), begin, (begin + limit) if limit is not None else None))
            else:
                # Include system users that are not in keycloak (or not).
                if exclude_system_users:
                    persons: list[PersonView] = []
                else:
                    persons = list(query_param_mgr.filter_by_all_params(get_system_people_views()))

                # Keycloak only supports sorting by username ascending, otherwise paginate and sort after we get results back from Keycloak.
                access_token_obj = await self.get_keycloak_access_token(request)
                assert access_token_obj is not None, 'access_token_obj cannot be None'
                access_token = access_token_obj.id
                session = _client_session(request)
                users_url = self.__base_url / 'admin' / 'realms' / self.realm / 'users'
                rest_call_params = query_param_mgr.rest_call_params
                logger.debug('rest_call_params are %s; using API for sort? %s; using API for paginate? %s',
                            rest_call_params, query_param_mgr.api_sort, query_param_mgr.api_paginate)
                if query_param_mgr.api_paginate:
                    rest_call_params.update({'first': begin, 'max': limit} if limit is not None else {'first': begin})
                users_url_ = users_url.with_query(rest_call_params)
                logger.debug('Getting user views from URL %s', users_url_)
                async with session.get(users_url_,
                                    headers={'Authorization': f'Bearer {access_token}'},
                                    ssl=self.verify_ssl) as response_:
                    json_response = await response_.json()
                    all_persons = [self.__keycloak_user_to_person_view(user_json) for user_json in json_response]
                    if not query_param_mgr.has_filter_params():
                        self.__ttl_cache[cache_key] = persons + all_persons
                    for another_person_view in query_param_mgr.filter_by_unused_params(all_persons):
                        persons.append(another_person_view)
                if not query_param_mgr.api_sort:
                    logger.debug('Sorting in memory with %s', query_param_mgr.sorts)
                    persons = sort_desktop_objects_from_params(resolved_params, persons)
                if not query_param_mgr.api_paginate:
                    logger.debug('Paginating in memory with begin %s and limit %s', begin, limit)
                    persons = persons[begin:(begin + limit) if limit is not None else None]
                return deepcopy(persons)


    async def get_user(self, request: Request, id_: str) -> Person | None:
        """
        Gets the user from Keycloak with the given id using the '/auth/admin/realms/{realm}/users/{id}' REST API call.

        :param request: the HTTP request (required).
        :param id_: the user id (required).
        :return: a Person object.
        :raises ClientResponseError if an error occurred or the person was not found.
        """
        logger = logging.getLogger(__name__)
        logger.debug('getting user %s', id_)
        async with self._all_people_lock:
            async with self.__user_lock_manager.lock(id_):
                cached_val = self.__ttl_cache.get(('one_user', id_))
                if cached_val is not None:
                    logger.debug('Found user %s in one_user cache', id_)
                    return deepcopy(cached_val)
                elif all_users := self.__ttl_cache.get(('all_users', False, None)):
                    try:
                        person = next(p for p in all_users if p.id == id_)
                        self.__ttl_cache[('one_user', id_)] = person
                        logger.debug('Found user %s in all_users cache', id_)
                        return deepcopy(person)
                    except StopIteration:
                        return None
                if is_system_user(id_):
                    person = get_system_person(id_)
                    self.__ttl_cache[('one_user', id_)] = person
                    logger.debug('Found user %s in system users', id_)
                    return person
                else:
                    async def get_user_json() -> dict[str, Any] | None:
                        user_json = await self.__get_user_json(request, id_)
                        logger.debug('Response getting user was %s', user_json)
                        if 'error' in user_json:
                            if user_json['error'] == 'User not found':
                                return None
                            else:
                                raise ValueError(user_json['error'])
                        else:
                            return user_json
                    user_json, group_ids = await gather(get_user_json(), self.get_user_group_ids(request, id_))
                    user_json = await get_user_json()
                    if user_json is None:
                        return None
                    group_dicts = [{'id': group_id} for group_id in group_ids]
                    person = self.__keycloak_user_to_person(user_json, group_dicts)
                    self.__ttl_cache[('one_user', id_)] = person
                    return deepcopy(person)

    async def get_user_view(self, request: Request, id_: str) -> PersonView | None:
        """
        Gets the user view from Keycloak with the given id using the '/auth/admin/realms/{realm}/users/{id}' REST API call.

        :param request: the HTTP request (required).
        :param id_: the user id (required).
        :return: a PersonView object.
        :raises ClientResponseError if an error occurred or the person was not found.
        """
        logger = logging.getLogger(__name__)
        logger.debug('getting user view %s', id_)
        async with self._all_people_lock:
            async with self.__user_lock_manager.lock(id_):
                cached_val = self.__ttl_cache.get(('one_user_view', id_))
                if cached_val is not None:
                    logger.debug('Found user view %s in one_user_view cache', id_)
                    return deepcopy(cached_val)
                elif all_users := self.__ttl_cache.get(('all_user_views', False, None)):
                    try:
                        person = next(p for p in all_users if p.id == id_)
                        self.__ttl_cache[('one_user_view', id_)] = person
                        logger.debug('Found user view %s in all_user_views cache', id_)
                        return deepcopy(person)
                    except StopIteration:
                        return None
                if is_system_user(id_):
                    logger.debug('Getting system user view %s', id_)
                    person = get_system_person_view(id_)
                    self.__ttl_cache[('one_user_view', id_)] = person
                    logger.debug('Found user view %s in system users', id_)
                    return person
                else:
                    async def get_user_json() -> dict[str, Any] | None:
                        user_json = await self.__get_user_json(request, id_)
                        logger.debug('Response getting user view was %s', user_json)
                        if 'error' in user_json:
                            if user_json['error'] == 'User not found':
                                return None
                            else:
                                raise ValueError(user_json['error'])
                        else:
                            return user_json
                    logger.debug('Getting user view %s from keycloak', id_)
                    user_json = await get_user_json()
                    if user_json is None:
                        return None
                    person = self.__keycloak_user_to_person_view(user_json)
                    self.__ttl_cache[('one_user_view', id_)] = person
                    return deepcopy(person)

    async def get_current_user_roles(self, request: Request) -> list[Role]:
        """
        Gets the current user's roles.

        :param request: the HTTP request (required).
        :returns: a list of Role objects.
        :raises ClientResponseError: if something went wrong getting role information.
        :raises ValueError: if something went wrong getting role information.

        """
        logger = logging.getLogger(__name__)
        sub = request.headers.get(SUB, NONE_USER)
        cached_val = self.__ttl_cache.get(('my_roles', sub))
        if cached_val is not None:
            return cached_val
        else:
            values = [self.__new_role(sub, role_json) async for role_json in self.__get_my_roles_json(request)]
            self.__ttl_cache[('my_roles', sub)] = values
            return values

    async def has_role_current_user(self, request: Request, role_name: str) -> bool:
        """
        Returns whether the current user has the given role.

        :param request: the HTTP request (required).
        :param role_name: the role to check (required).
        :returns: True or False.
        :raises ClientResponseError: if something went wrong getting role information.
        :raises ValueError: if something went wrong getting role information due to an internal server error.
        """
        for role in await self.get_current_user_roles(request):
            if role.role == role_name:
                return True
        else:
            return False

    async def get_user_groups(self, request: Request, sub: str) -> list[Group]:
        """
        Gets a user's groups.

        :param request: the HTTP request (required).
        :returns: a list of Group objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.

        """
        async with self._all_groups_lock:
            return await self.__get_user_groups(request, sub)

    async def get_user_group_views(self, request: Request, sub: str) -> list[GroupView]:
        """
        Gets a user's group views.

        :param request: the HTTP request (required).
        :returns: a list of GroupView objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.

        """
        async with self._all_groups_lock:
            return await self.__get_user_group_views(request, sub)

    async def get_user_group_ids(self, request: Request, sub: str) -> list[str]:
        """
        Gets the current user's group ids.

        :param request: the HTTP request (required).
        :returns: a list of group ids.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.

        """
        async with self._all_groups_lock:
            cached_val = self.__ttl_cache.get(('my_group_ids', sub))
            if cached_val is not None:
                return copy(cached_val)
            else:
                res = [cast(str, group_json['id']) async for group_json in self.__get_user_groups_json(request, sub)]
                self.__ttl_cache[('my_group_ids', sub)] = res
                return copy(res)

    async def get_current_user_groups(self, request: Request) -> list[Group]:
        """
        Gets the current user's groups.

        :param request: the HTTP request (required).
        :returns: a list of Group objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.

        """
        async with self._all_groups_lock:
            return await self.__get_current_user_groups(request)

    async def get_current_user_group_views(self, request: Request) -> list[GroupView]:
        """
        Gets the current user's group views.

        :param request: the HTTP request (required).
        :returns: a list of GroupView objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.

        """
        async with self._all_groups_lock:
            return await self.__get_current_user_group_views(request)

    async def get_all_groups(self, request: Request) -> list[Group]:
        """
        Returns all groups known to Keycloak.

        :param request: the HTTP request (required).
        :return: a list of Group objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the groups due an internal server error.
        """
        async with self._all_groups_lock:
            return await self.__get_all_groups(request)

    async def get_all_group_views(self, request: Request) -> list[GroupView]:
        """
        Returns all group views known to Keycloak.

        :param request: the HTTP request (required).
        :return: a list of Group objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the groups due an internal server error.
        """
        async with self._all_groups_lock:
            return await self.__get_all_group_views(request)

    async def get_group(self, request: Request, id_: str) -> Group | None:
        """
        Gets the group for the given group.

        :param request: the HTTP request (required).
        :param id_: the group id (required).
        :return: a Group object or None if not found.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the groups due an internal server error.
        """
        async with self._all_groups_lock:
            return await self.__get_group(request, id_)

    async def get_group_view(self, request: Request, id_: str) -> GroupView | None:
        """
        Gets the group view for the given group.

        :param request: the HTTP request (required).
        :param id_: the group id (required).
        :return: a GroupView object or None if not found.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the groups due an internal server error.
        """
        async with self._all_groups_lock:
            return await self.__get_group_view(request, id_)

    async def create_group(self, request: Request, group: Group):
        sub = request.headers.get(SUB, NONE_USER)
        async with self._all_groups_lock:
            location = await self.__create_group(request, group)
            self.__ttl_cache.pop(('all_groups', None), None)
            self.__ttl_cache.pop(('all_group_views', None), None)
            self.__ttl_cache.pop(('my_groups', sub), None)
            self.__ttl_cache.pop(('my_group_views', sub), None)
        return location

    async def delete_group_recursive(self, request: Request, id_: str):
        sub = request.headers.get(SUB, NONE_USER)
        async with self._all_groups_lock:
            await self.__delete_group(request, id_)
            self.__clear_group_cache(sub)

    async def delete_group_by_path_recursive(self, request: Request, path: str,
                                             delete_empty_ancestors = False):
        logger = logging.getLogger(__name__)
        sub = request.headers.get(SUB, NONE_USER)
        logger.debug('Deleting group recursively %s', path)
        async with self._all_groups_lock:
            group = await self.__get_group_by_path(request, path)
            if group:
                assert group.id is not None, 'group.id cannot be None'
                await self.__delete_group(request, group.id)
                if delete_empty_ancestors:
                    path_ = group.group
                    assert path_ is not None, 'group.group cannot be None'
                    # loop through ancestors, get children, and delete if no children
                    while True:
                        path_ = path_[:path_.rindex('/')]
                        if not path_:
                            break
                        group_ = await self.__get_group_by_path(request, path_)
                        if group_:
                            assert group_.id is not None, 'group.id cannot be None'
                            url = self.__realm_base_url / 'groups' / group_.id / 'children'
                            access_token_obj = await self.get_keycloak_access_token(request)
                            assert access_token_obj is not None, 'access_token_obj cannot be None'
                            access_token = access_token_obj.id
                            async with _client_session(request).get(url,
                                                                    headers={'Authorization': f'Bearer {access_token}'},
                                                                    ssl=self.verify_ssl) as response_:
                                children = await response_.json()
                            if not children:
                                await self.__delete_group(request, group_.id)
            self.__clear_group_cache(sub)

    async def get_current_user_group_by_path(self, request: Request, path: str) -> Group | None:
        async with self._all_groups_lock:
            return await self.__get_current_user_group_by_path(request, path)

    async def get_current_user_group_view_by_path(self, request: Request, path: str) -> GroupView | None:
        async with self._all_groups_lock:
            return await self.__get_current_user_group_view_by_path(request, path)

    async def get_user_group_by_path(self, request: Request, sub: str, path: str) -> Group | None:
        async with self._all_groups_lock:
            return await self.__get_user_group_by_path(request, sub, path)

    async def get_user_group_view_by_path(self, request: Request, sub: str, path: str) -> GroupView | None:
        async with self._all_groups_lock:
            return await self.__get_user_group_view_by_path(request, sub, path)

    async def add_current_user_to_group(self, request: Request, id_: str):
        sub = request.headers.get(SUB, NONE_USER)
        await self.add_user_to_group(request, sub, id_)

    async def add_user_to_group(self, request: Request, sub: str, id_: str):
        logger = logging.getLogger(__name__)
        actual_sub = request.headers.get(SUB, NONE_USER)
        if actual_sub not in (sub, CREDENTIALS_MANAGER_USER):
            raise response.status_not_found()
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        group_base_url = self.__realm_base_url / 'users' / sub / 'groups'
        session_put = partial(session.put,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl)
        try:
            logger.debug('Adding user %s to group %s', sub, id_)
            async with self._all_groups_lock:
                async with session_put(group_base_url / id_) as response_:
                    self.__ttl_cache.pop(('my_groups', sub), None)
                    self.__ttl_cache.pop(('all_users', True, None), None)
                    self.__ttl_cache.pop(('all_users', False, None), None)
                    self.__ttl_cache.pop(('one_user', sub), None)
                    self.__ttl_cache.pop(('my_roles', sub), None)
        except ClientResponseError as e:
            raise response.status_generic_error(status=e.status, body=e.message)

    async def remove_current_user_group(self, request: Request, id_: str) -> bool:
        sub = request.headers.get(SUB, NONE_USER)
        return await self.remove_user_group(request, sub, id_)

    async def remove_user_group(self, request: Request, sub: str, id_: str) -> bool:
        async with self._all_groups_lock:
            return await self.__remove_user_group(request, sub, id_)

    async def remove_current_user_group_by_path(self, request: Request, path: str) -> bool:
        sub = request.headers.get(SUB, NONE_USER)
        async with self._all_groups_lock:
            if (group_obj := await self.__get_current_user_group_by_path(request, path)) is None:
                return False
            assert group_obj.id is not None, 'group_obj.id cannot be None'
            return await self.__remove_user_group(request, sub, group_obj.id)

    async def remove_user_group_by_path(self, request: Request, sub: str, path: str) -> bool:
        async with self._all_groups_lock:
            if (group_obj := await self.__get_group_by_path(request, path)) is None:
                return False
            assert group_obj.id is not None, 'group_obj.id cannot be None'
            return await self.__remove_user_group(request, sub, group_obj.id)

    async def get_group_by_group(self, request: Request, group: str) -> Group | None:
        async with self._all_groups_lock:
            return await self.__get_group_by_path(request, group)

    async def get_group_view_by_group(self, request: Request, group: str) -> GroupView | None:
        async with self._all_groups_lock:
            return await self.__get_group_view_by_group(request, group)

    async def get_all_roles(self, request: Request) -> list[Role]:
        sub = request.headers.get(SUB, NONE_USER)
        async with self._all_groups_lock:
            cached_val = self.__ttl_cache.get(('all_roles', sub))
            if cached_val is not None:
                return deepcopy(cached_val)
            else:
                values = [self.__new_role(sub, role_json) async for role_json in self.__get_all_roles_json(request)]
                self.__ttl_cache[('all_roles', sub)] = values
                return values

    async def create_role(self, request: Request, name: str) -> str:
        sub = request.headers.get(SUB, NONE_USER)
        async with self._all_groups_lock:
            location = await self.__create_role(request, name)
            self.__ttl_cache.pop(('all_roles', sub), None)
            self.__ttl_cache.pop(('my_roles', sub), None)
            return location

    async def delete_role(self, request: Request, name: str):
        """
         Deletes the role with the given name. Note that Keycloak does a cascade delete of this role, so it will be
         removed from all users and groups that have it.

         :param request: the HTTP request (required).
         :param name: the role name (required).
         :raises ClientResponseError: if something went wrong deleting the role.
         """
        sub = request.headers.get(SUB, NONE_USER)
        async with self._all_groups_lock:
            await self.__delete_role(request, name)
            self.__ttl_cache.pop(('all_roles', sub), None)
            self.__ttl_cache.pop(('my_roles', sub), None)
            self.__clear_group_cache(sub)

    async def __remove_user_group(self, request: Request, sub: str, id_: str) -> bool:
        actual_sub = request.headers.get(SUB, NONE_USER)
        if actual_sub not in (sub, CREDENTIALS_MANAGER_USER):
            return False
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)

        role_base_url = self.__realm_base_url / 'users' / sub / 'groups'
        session_delete = partial(session.delete,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl, raise_for_status=False)
        async with session_delete(role_base_url / id_) as response_:
            if response_.status == 404:
                return False
            if response_.status != 204:
                raise ValueError('Adding user to group failed')
            self.__ttl_cache.pop(('all_users', True, None), None)
            self.__ttl_cache.pop(('all_users', False, None), None)
            self.__ttl_cache.pop(('one_user', sub), None)
            self.__ttl_cache.pop(('my_roles', sub), None)
            return True

    async def __get_current_user_group_by_path(self, request: Request, path: str) -> Group | None:
        try:
            return next(g for g in await self.__get_current_user_groups(request) if g.group == path)
        except StopIteration:
            return None

    async def __get_current_user_group_view_by_path(self, request: Request, path: str) -> GroupView | None:
        try:
            return next(g for g in await self.__get_current_user_group_views(request) if g.group == path)
        except StopIteration:
            return None

    async def __get_user_group_by_path(self, request: Request, sub: str, path: str) -> Group | None:
        try:
            return next(g for g in await self.__get_user_groups(request, sub) if g.group == path)
        except StopIteration:
            return None

    async def __get_user_group_view_by_path(self, request: Request, sub: str, path: str) -> GroupView | None:
        try:
            return next(g for g in await self.__get_user_group_views(request, sub) if g.group == path)
        except StopIteration:
            return None

    async def __get_current_user_groups(self, request: Request) -> list[Group]:
        """
        Gets a copy of the current user's groups.

        :param request: the HTTP request (required).
        :returns: a newly created copy of Group objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.

        """
        logger = logging.getLogger(__name__)
        sub = request.headers.get(SUB, NONE_USER)
        cached_val = self.__ttl_cache.get(('my_groups', sub))
        if cached_val is not None:
            return deepcopy(cached_val)
        else:
            groups = [self.__new_group(group_json) async for group_json in self.__get_my_groups_json(request)]
            access_token_obj = await self.get_keycloak_access_token(request)
            assert access_token_obj is not None, 'access_token_obj cannot be None'
            access_token = access_token_obj.id
            session = _client_session(request)
            role_base_url = self.__realm_base_url
            session_get = partial(session.get,
                                    headers={'Authorization': f'Bearer {access_token}'},
                                    ssl=self.verify_ssl)
            for group in groups:
                try:
                    assert group.id is not None, 'group.id cannot be None'
                    async with session_get(role_base_url / 'groups' / group.id / 'role-mappings') as response_:
                        for role_dict in await response_.json():
                            role = self.__new_role(sub, role_dict)
                            assert role.id is not None, 'role.id cannot be None'
                            group.add_role_id(role.id)
                except ClientResponseError as e:
                    raise ValueError(f'Error getting role mapping information for group {group.group}') from e
            await self.__add_roles_to_groups(request, sub, groups)
            self.__ttl_cache[('my_groups', sub)] = groups
            return deepcopy(groups)

    async def __get_current_user_group_views(self, request: Request) -> list[GroupView]:
        """
        Gets a copy ofthe current user's group views.

        :param request: the HTTP request (required).
        :returns: a newly created list containing a copy of GroupView objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.

        """
        sub = request.headers.get(SUB, NONE_USER)
        cached_val = self.__ttl_cache.get(('my_group_views', sub))
        if cached_val is not None:
            return deepcopy(cached_val)
        else:
            groups = [self.__new_group_view(group_json) async for group_json in self.__get_my_groups_json(request)]
            self.__ttl_cache[('my_group_views', sub)] = groups
            return deepcopy(groups)

    async def __get_user_groups(self, request: Request, sub: str) -> list[Group]:
        """
        Gets a copy of a user's groups.

        :param request: the HTTP request (required).
        :param sub: the user's sub (required).
        :returns: a newly created copy of Group objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.
        """
        cached_val = self.__ttl_cache.get(('my_groups', sub))
        if cached_val is not None:
            return deepcopy(cached_val)
        else:
            groups = [self.__new_group(group_json) async for group_json in self.__get_user_groups_json(request, sub)]
            await gather(*(self.__get_group_roles(request, sub, group) for group in groups))
            self.__ttl_cache[('my_groups', sub)] = groups
            self.__ttl_cache[('my_group_ids', sub)] = [group.id for group in groups]
            return deepcopy(groups)

    async def __get_user_group_views(self, request: Request, sub: str) -> list[GroupView]:
        """
        Gets a copy of a user's group views.

        :param request: the HTTP request (required).
        :param sub: the user's sub (required).
        :returns: a newly created list containing a copy of GroupView objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError: if something went wrong getting group information due to an internal server error.
        """
        cached_val = self.__ttl_cache.get(('my_group_views', sub))
        if cached_val is not None:
            return deepcopy(cached_val)
        else:
            groups = [self.__new_group_view(group_json) async for group_json in self.__get_user_groups_json(request, sub)]
            self.__ttl_cache[('my_group_views', sub)] = groups
            return deepcopy(groups)

    async def __get_group(self, request: Request, id_: str) -> Group | None:
        """
        Gets the group for the given group id.

        :param request: the HTTP request (required).
        :param id_: the group id (required).
        :return: a newly created Group object or None if not found.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the group due an internal server error."""
        logger = logging.getLogger(__name__)
        logger.debug('Getting group by id %s', id_)
        cache_key = ('group_by_id', id_)
        cached_val = self.__ttl_cache.get(cache_key)
        if cached_val is not None:
            logger.debug('Found group by id %s in cache', id_)
            return deepcopy(cached_val)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        url = self.__realm_base_url / 'groups' / id_
        async with session.get(url,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl) as response_:
            if response_.status == 404:
                logger.debug('Group with id %s not found', id_)
                self.__ttl_cache[cache_key] = None
                return None
            result_json = await response_.json()
            logger.debug('Got group by id response %s', result_json)
            result = self.__new_group(result_json)
            await self.__get_group_roles(request, request.headers.get(SUB, NONE_USER), result)
            logger.debug('Got group by id %s: %s', id_, result)
            self.__ttl_cache[cache_key] = result
            return deepcopy(result)

    async def __get_group_view(self, request: Request, id_: str) -> GroupView | None:
        """
        Gets the group view for the given group id.

        :param request: the HTTP request (required).
        :param id_: the group id (required).
        :return: a newly created GroupView object or None if not found.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the group due an internal server error."""
        logger = logging.getLogger(__name__)
        logger.debug('Getting group view by id %s', id_)
        cache_key = ('group_view_by_id', id_)
        cached_val = self.__ttl_cache.get(cache_key)
        if cached_val is not None:
            logger.debug('Found group view by id %s in cache', id_)
            return deepcopy(cached_val)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        url = self.__realm_base_url / 'groups' / id_
        async with session.get(url,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl) as response_:
            if response_.status == 404:
                logger.debug('Group view with id %s not found', id_)
                self.__ttl_cache[cache_key] = None
                return None
            result_json = await response_.json()
            logger.debug('Got group view by id response %s', result_json)
            result = self.__new_group_view(result_json)
            logger.debug('Got group view by id %s: %s', id_, result)
            self.__ttl_cache[cache_key] = result
            return deepcopy(result)

    async def __get_group_by_path(self, request: Request, path: str) -> Group | None:
        """
        Gets the group for the given group path.

        :param request: the HTTP request (required).
        :param path: the group path (required).
        :return: a newly created Group object or None if not found.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the group due an internal server error.
        """
        logger = logging.getLogger(__name__)
        assert path, 'path must be populated'
        logger.debug('Getting group by group %s', path)
        cache_key = ('group_by_group', path)
        cached_val = self.__ttl_cache.get(cache_key)
        if cached_val is not None:
            logger.debug('Found group by path %s in cache', path)
            return deepcopy(cached_val)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        url = self.__realm_base_url / 'group-by-path'
        url_str = str(url) + path
        async with session.get(url_str,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl) as response_:
            if response_.status == 404:
                logger.debug('Group path %s not found', path)
                self.__ttl_cache[cache_key] = None
                return None
            result_json = await response_.json()
            logger.debug('Got group by path response %s', result_json)
            result = self.__new_group(result_json)
            await self.__get_group_roles(request, request.headers.get(SUB, NONE_USER), result)
            logger.debug('Got group by path %s: %s', path, result)
            self.__ttl_cache[cache_key] = result
            return deepcopy(result)

    async def __get_group_view_by_group(self, request: Request, group: str) -> GroupView | None:
        """
        Gets the group view for the given group name.

        :param request: the HTTP request (required).
        :param group: the group name (required).
        :return: a newly created GroupView object or None if not found.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the group due an internal server error.
        """
        logger = logging.getLogger(__name__)
        logger.debug('Getting group view by group %s', group)
        cache_key = ('group_view_by_group', group)
        cached_val = self.__ttl_cache.get(cache_key)
        if cached_val is not None:
            logger.debug('Found group view by group %s in cache', group)
            return deepcopy(cached_val)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        url = (self.__realm_base_url / 'group-by-path')
        url_str = str(url) + group
        async with session.get(url_str,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl) as response_:
            if response_.status == 404:
                logger.debug('Group %s not found', group)
                self.__ttl_cache[cache_key] = None
                return None
            result_json = await response_.json()
            logger.debug('Got group view by group response %s', result_json)
            result = self.__new_group_view(result_json)
            logger.debug('Got group view by group %s: %s', group, result)
            self.__ttl_cache[cache_key] = result
            return deepcopy(result)

    async def __get_all_groups(self, request: Request) -> list[Group]:
        """
        Returns all groups known to Keycloak.

        :param request: the HTTP request (required).
        :return: a list of Group objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the groups due an internal server error.
        """
        logger = logging.getLogger(__name__)
        sub = request.headers.get(SUB, NONE_USER)
        cached_val = self.__ttl_cache.get(('all_groups', None))
        query_param_mgr = GroupQueryParamManager(request.query)
        if cached_val is not None:
            logger.debug('Getting cached groups %s', cached_val)
            filtered = query_param_mgr.filter_by_all_params(cached_val)
            if not query_param_mgr.api_sort:
                filtered_ = sort_desktop_objects_from_sort_info(query_param_mgr.sorts, filtered)
            else:
                filtered_ = list(filtered)
            begin, end, _ = get_pagination_params(request)
            filtered_ = filtered_[begin:end] if end is not None else filtered_[begin:]
            return filtered_
        else:
            groups = [self.__new_group(group_json) async for group_json in self.__get_all_groups_json(request, query_param_mgr)]
            await self.__add_roles_to_groups(request, sub, groups)
            if not query_param_mgr.rest_call_params:
                self.__ttl_cache[('all_groups', None)] = groups
            groups_ = query_param_mgr.filter_by_unused_params(groups)
            if not query_param_mgr.api_sort:
                groups_l = sort_desktop_objects_from_sort_info(query_param_mgr.sorts, groups)
            else:
                groups_l = list(groups_)
            logger.debug('Getting group views %s', groups_l)
            if not query_param_mgr.api_paginate:
                begin, end, _ = get_pagination_params(request)
                groups_l = groups_l[begin:end] if end is not None else groups_l[begin:]
            return groups_l

    async def __get_all_group_views(self, request: Request) -> list[GroupView]:
        """
        Returns all group views known to Keycloak.

        :param request: the HTTP request (required).
        :return: a list of GroupView objects.
        :raises ClientResponseError: if something went wrong getting group information.
        :raises ValueError if an error occurred getting the groups due an internal server error.
        """
        logger = logging.getLogger(__name__)
        query_param_mgr = GroupViewQueryParamManager(request.query)
        cached_val = self.__ttl_cache.get(('all_group_views', None))
        if cached_val is not None:
            logger.debug('Getting cached group views %s', cached_val)
            filtered = query_param_mgr.filter_by_all_params(cached_val)
            if not query_param_mgr.api_sort:
                filtered_ = sort_desktop_objects_from_sort_info(query_param_mgr.sorts, filtered)
            else:
                filtered_ = list(filtered)
            begin, end, _ = get_pagination_params(request)
            filtered_ = filtered_[begin:end] if end is not None else filtered_[begin:]
            return filtered_
        else:
            groups = [self.__new_group_view(group_json) async for group_json in self.__get_all_groups_json(request, query_param_mgr)]
            if not query_param_mgr.rest_call_params:
                self.__ttl_cache[('all_group_views', None)] = groups
            groups_ = query_param_mgr.filter_by_unused_params(groups)
            if not query_param_mgr.api_sort:
                groups_l = sort_desktop_objects_from_sort_info(query_param_mgr.sorts, groups_)
            else:
                groups_l = list(groups_)
            logger.debug('Getting group views %s', groups_l)
            if not query_param_mgr.api_paginate:
                begin, end, _ = get_pagination_params(request)
                groups_l = groups_l[begin:end] if end is not None else groups_l[begin:]
            return groups_l

    def __new_role(self, sub: str, role_dict: dict[str, Any]) -> Role:
        """
        Returns a Role object from Keycloak role json.

        :param sub: the user id (required).
        :param role_dict: the role json (required).
        :return: a newly Role object.
        """
        role: Role = Role()
        role.role = role_dict['name']
        role.description = role_dict.get('description')
        role.owner = NONE_USER
        share1: Share = ShareImpl()
        share1.user = ALL_USERS
        share1.permissions = [Permission.VIEWER]
        role.user_shares = [share1]
        role.source = 'Keycloak'
        return role

    async def __get_client_uuid(self, request: Request) -> str:
         if self.__client_uuid is not None:
            return self.__client_uuid
         else:
            session = _client_session(request)
            access_token_obj = await self.get_keycloak_access_token(request)
            assert access_token_obj is not None, 'access_token_obj cannot be None'
            access_token = access_token_obj.id
            session_get = partial(session.get,
                                headers={'Authorization': f'Bearer {access_token}'},
                                ssl=self.verify_ssl)
            async with session_get(self.__realm_base_url / 'clients') as response_:
                for client_ in await response_.json():
                    if client_['clientId'] == self.client_id:
                        self.__client_uuid = client_['id']
                        return self.__client_uuid
                else:
                    raise ValueError(f'No client with id {self.client_id}')

    async def __get_user_json(self, request: Request, id_: str) -> dict[str, Any]:
        logger = logging.getLogger(__name__)
        logger.debug('Getting user json for user %s', id_)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        user_url = self.__base_url / 'admin' / 'realms' / self.realm / 'users' / id_
        async with session.get(user_url,
                        headers={'Authorization': f'Bearer {access_token}'},
                        ssl=self.verify_ssl) as response_:
            logger.debug('Got user json response %s', response_)
            return await response_.json()

    async def __get_my_roles_json(self, request: Request) -> AsyncIterator[dict[str, Any]]:
        logger = logging.getLogger(__name__)
        sub = request.headers.get(SUB, NONE_USER)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_get = partial(session.get,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl)
        roles = {}
        client_id_ = await self.__get_client_uuid(request)
        async def one():
            async with session_get(self.__realm_base_url / 'users' / sub / 'role-mappings' / 'clients' / client_id_ / 'composite') as response_:
                for role_dict in await response_.json():
                    roles[role_dict['name']] = role_dict
        async def two():
            async with session_get(self.__realm_base_url / 'users' / sub / 'role-mappings' / 'clients' / client_id_) as response_:
                for role_dict in await response_.json():
                    roles[role_dict['name']] = role_dict
        await gather(one(), two())
        logger.debug('roles are %s', roles)
        for role_ in roles.values():
            yield role_

    async def __get_all_roles_json(self, request: Request) -> AsyncIterator[dict[str, Any]]:
        logger = logging.getLogger(__name__)
        sub = request.headers.get(SUB, NONE_USER)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_get = partial(session.get,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl)
        roles = {}
        async with session_get(self.__realm_base_url / 'clients') as response_:
            for client_ in await response_.json():
                if client_['clientId'] == self.client_id:
                    client_id_ = client_['id']
                    break
            else:
                raise ValueError(f'No client with id {self.client_id}')

        async with session_get(self.__realm_base_url / 'clients' / client_id_ / 'roles') as response_:
            for role_dict in await response_.json():
                roles[role_dict['name']] = role_dict

        logger.debug('roles are %s', roles)
        for role_ in roles.values():
            yield role_

    async def __create_role(self, request: Request, name: str) -> str:
        logger = logging.getLogger(__name__)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_get = partial(session.get,
                              headers={'Authorization': f'Bearer {access_token}'},
                              ssl=self.verify_ssl)
        async with session_get(self.__realm_base_url / 'clients') as response_:
            for client_ in await response_.json():
                if client_['clientId'] == self.client_id:
                    client_id_ = client_['id']
                    break
            else:
                raise ValueError(f'No client with id {self.client_id}')
        session_post = partial(session.post,
                               headers={'Authorization': f'Bearer {access_token}',
                                        hdrs.CONTENT_TYPE: 'application/json'},
                               ssl=self.verify_ssl)
        logger.debug('Creating role %s for client %s', name, client_id_)
        try:
            async with session_post(self.__realm_base_url / 'clients' / client_id_ / 'roles', json={'name': name}) as response_:
                return str(URL(request.app[appproperty.HEA_COMPONENT]) / 'roles' / encode_role(name))
        except ClientResponseError as e:
            raise response.status_generic_error(status=e.status, body=e.message)

    async def __delete_role(self, request: Request, name: str):
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_get = partial(session.get,
                              headers={'Authorization': f'Bearer {access_token}'},
                              ssl=self.verify_ssl)
        async with session_get(self.__realm_base_url / 'clients') as response_:
            for client_ in await response_.json():
                if client_['clientId'] == self.client_id:
                    client_id_ = client_['id']
                    break
            else:
                raise ValueError(f'No client with id {self.client_id}')
        session_delete = partial(session.delete,
                               headers={'Authorization': f'Bearer {access_token}',
                                        hdrs.CONTENT_TYPE: 'application/json'},
                               ssl=self.verify_ssl)
        try:
            async with session_delete(self.__realm_base_url / 'clients' / client_id_ / 'roles' / name) as response_:
                pass
        except ClientResponseError as e:
            raise response.status_generic_error(status=e.status, body=e.message)

    async def __create_group(self, request: Request, group: Group) -> str:
        logger = logging.getLogger(__name__)
        logger.debug('Creating group %r', group)
        name = group.group
        assert name is not None, 'group.group cannot be None'
        logger.debug('group path: %s', name)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_post = partial(session.post,
                               headers={hdrs.AUTHORIZATION: f'Bearer {access_token}',
                                        hdrs.CONTENT_TYPE: 'application/json'},
                               ssl=self.verify_ssl)
        session_get = partial(session.get,
                               headers={hdrs.AUTHORIZATION: f'Bearer {access_token}'},
                               ssl=self.verify_ssl)
        parent_id: str | None = None
        parent_name: str | None = None
        last: str = ''

        for group_name in name.split('/')[1:]:
            logger.debug('group: %s', group_name)
            data = {'name': group_name}
            if parent_id is None:
                try:
                    async with session_post(self.__realm_base_url / 'groups', json=data) as response_:
                        id_ = response_.headers[hdrs.LOCATION].rsplit('/', maxsplit=1)[1]
                        logger.debug(f'Group {group_name} created successfully')
                except ClientResponseError as e:
                    if e.status != 409:
                        raise response.status_generic_error(status=e.status, body=e.message)
                    else:
                        logger.debug('Group %s already exists', group_name)
                        group_ = await self.__get_group_by_path(request, name[:name.index(group_name)] + group_name)
                        assert group_ is not None, 'group cannot be None'
                        assert group_.id is not None, 'id_ cannot be None'
                        id_ = group_.id
                parent_id = id_
                parent_name = group_name
                last = str(URL(request.app[appproperty.HEA_COMPONENT]) / 'groups' / id_)
            else:
                logger.debug('Making %s a child of %s (%s)', group_name, parent_name, parent_id)
                try:
                    async with session_post(self.__realm_base_url / 'groups' / parent_id / 'children', json={'name': group_name}) as response_:
                        logger.debug('Group %s made a child of %s (%s) successfully', group_name, parent_name, parent_id)
                        parent_id = response_.headers[hdrs.LOCATION].rsplit('/', maxsplit=1)[1]
                        assert parent_id is not None, 'parent_id cannot be None'
                        last = str(URL(request.app[appproperty.HEA_COMPONENT]) / 'groups' / parent_id)
                        parent_name = group_name
                except ClientResponseError as e:
                    if e.status != 409:
                        raise response.status_generic_error(status=e.status, body=e.message)
                    else:
                        logger.debug('Group %s is already a child of %s', group_name, parent_name)
                        parent_name = group_name
                        group_ = await self.__get_group_by_path(request, name[:name.index(group_name)] + group_name)
                        assert group_ is not None, 'group_ cannot be None'
                        parent_id = group_.id
        logger.debug('Parent set to %s', parent_name)
        client_uuid = await self.__get_client_uuid(request)
        for role_name in group.role_ids:
            role_name_decoded = decode_role(role_name)
            logger.debug('Adding role %s to client %s', role_name_decoded, self.client_id)
            role_id: str | None = None
            try:
                async with session_post(self.__realm_base_url / 'clients' / client_uuid / 'roles', json={'name': role_name_decoded}) as response_:
                    role_id = response_.headers[hdrs.LOCATION].rsplit('/', maxsplit=1)[1]
            except ClientResponseError as e:
                if e.status == 409:
                    logger.debug('Role %s already exists', role_name_decoded)
                    # yarl messes up the path part escaping here, probably because the role name may have a slash in it.
                    async with session_get(f'{self.__realm_base_url}/clients/{client_uuid}/roles/{urllib.parse.quote_plus(role_name_decoded)}') as response_:
                        role_id = (await response_.json())['id']
                else:
                    raise e
            assert role_id is not None, 'role_id cannot be None'
            logger.debug('Role %s has id %s', role_name_decoded, role_id)
            try:
                async with session_post(self.__realm_base_url / 'groups' / last.rsplit('/', maxsplit=1)[1] / 'role-mappings' / 'clients' / client_uuid,
                                        json=[{'id': role_id, 'name': role_name_decoded, 'composite': False, 'clientRole': True}]) as response_:
                    pass
            except ClientResponseError as e:
                if e.status == 409:
                    logger.debug('Role %s already exists', role_name_decoded)
                else:
                    raise e
        return last

    async def __delete_group(self, request: Request, id_: str):
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_delete = partial(session.delete,
                               headers={'Authorization': f'Bearer {access_token}',
                                        hdrs.CONTENT_TYPE: 'application/json'},
                               ssl=self.verify_ssl)
        try:
            async with session_delete(self.__realm_base_url / 'groups' / id_) as response_:
                pass
        except ClientResponseError as e:
            raise response.status_generic_error(status=e.status, body=e.message)

    def __new_group(self, group_dict: Mapping[str, Any]) -> Group:
        """
        Returns a Group object from Keycloak group json.

        :param group_dict: the group json (required).
        :return: a newly Group object.
        """
        group: Group = Group()
        group.id = group_dict['id']
        group.group = group_dict['path']
        group.owner = NONE_USER
        share1: Share = ShareImpl()
        share1.user = ALL_USERS
        share1.permissions = [Permission.VIEWER]
        group.user_shares = [share1]
        group.group_type = GroupType.ADMIN if group_dict['path'].startswith('/*') else GroupType.ORGANIZATION
        group.source = 'Keycloak'
        return group

    def __new_group_view(self, group_dict: Mapping[str, Any]) -> GroupView:
        """
        Returns a GroupView object from Keycloak group json.

        :param group_dict: the group json (required).
        :return: a newly GroupView object.
        """
        group: GroupView = GroupView()
        group.id = group_dict['id']
        group.group = group_dict['path']
        group.owner = NONE_USER
        share1: Share = ShareImpl()
        share1.user = ALL_USERS
        share1.permissions = [Permission.VIEWER]
        group.user_shares = [share1]
        group.group_type = GroupType.ADMIN if group_dict['path'].startswith('/*') else GroupType.ORGANIZATION
        group.source = 'Keycloak'
        group.actual_object_id = group_dict['id']
        group.actual_object_type_name = Group.get_type_name()
        group.actual_object_uri = f'groups/{group_dict["id"]}'
        return group

    async def __get_my_groups_json(self, request: Request) -> AsyncIterator[dict[str, Any]]:
        sub = request.headers.get(SUB, NONE_USER)
        if not is_system_user(sub):
            async for group_dict in self.__get_user_groups_json(request, sub):
                yield group_dict

    async def __get_user_groups_json(self, request: Request, sub: str) -> AsyncIterator[dict[str, Any]]:
        logger = logging.getLogger(__name__)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_get = partial(session.get,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl)
        if not is_system_user(sub):
            async with session_get(self.__realm_base_url / 'users' / sub / 'groups') as response_:
                for group_dict in await response_.json():
                    logger.debug('Returning group %s', group_dict)
                    yield group_dict

    async def __get_all_groups_json(self, request: Request, query_param_mgr: QueryParamManager[Group] | QueryParamManager[GroupView]) -> AsyncIterator[dict[str, Any]]:
        logger = logging.getLogger(__name__)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_get = partial(session.get,
                            headers={'Authorization': f'Bearer {access_token}'},
                            ssl=self.verify_ssl)
        query_params = query_param_mgr.rest_call_params or MultiDict({'q': '*'})
        if query_param_mgr.api_paginate:
            begin, _, limit = get_pagination_params(request)
            query_params['first'] = str(begin)
            query_params['max'] = str(limit)
        async with session_get((self.__realm_base_url / 'groups').with_query(query_params)) as response_:
            q: deque[dict[str, Any]] = deque()
            for group_dict in await response_.json():
                q.append(group_dict)
            while len(q) > 0:
                group_dict = q.popleft()
                for subGroup in group_dict['subGroups']:
                    q.append(subGroup)
                logger.debug('Returning group %s', group_dict)
                yield group_dict

    async def __add_roles_to_groups(self, request: Request, sub: str, groups: Sequence[Group]):
        """
        Adds roles to the given groups.

        :param request: the HTTP request (required).
        :param sub: the username (required).
        :param groups: the groups (required). Assumes the groups have all been persisted.
        :raises ValueError if an error occurred adding the roles due an internal server error.
        """
        logger = logging.getLogger(__name__)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id

        session = _client_session(request)

        session_get = partial(session.get,
                                headers={'Authorization': f'Bearer {access_token}'},
                                ssl=self.verify_ssl)
        for group in groups:
            try:
                assert group.id is not None, 'group.id cannot be None'
                async with session_get(self.__realm_base_url / 'groups' / group.id / 'role-mappings') as response_:
                    response_json = await response_.json()
                    logger.debug('role mappings json for group %s: %s', group, response_json)
                    role_mappings = response_json.get('clientMappings', {}).get(self.client_id, {}).get('mappings', [])
                    for role_dict in role_mappings:
                        role = self.__new_role(sub, role_dict)
                        assert role.id is not None, 'role.id cannot be None'
                        group.add_role_id(role.id)
            except ClientResponseError as e:
                raise ValueError(f'Error getting role mapping information for group {group.group}') from e

    def __keycloak_user_to_person(self, user: Mapping[str, Any], groups: Iterable[Mapping[str, Any]]) -> Person:
        """
        Converts a user JSON object from Keycloak to a HEA Person object.

        :param user: a Keycloak user object as a JSON dict.
        :param groups: the groups the user is in as an iterable of JSON dicts. Uses only the 'id' property of each
        dict.
        :return: a Person object.
        """
        person: Person = Person()
        person.id = user['id']
        person.name = user['username']
        person.first_name = user.get('firstName')
        person.last_name = user.get('lastName')
        person.email = user.get('email')
        person.created = datetime.fromtimestamp(user['createdTimestamp'] / 1000.0, tz=system_timezone())
        person.owner = NONE_USER
        person.source = 'Keycloak';
        share1: Share = ShareImpl()
        share1.user = ALL_USERS
        share1.permissions = [Permission.VIEWER]
        share2: Share = ShareImpl()
        share2.user = CREDENTIALS_MANAGER_USER
        share2.permissions = [Permission.EDITOR]
        person.user_shares = [share1, share2]
        group_ids = [group['id'] for group in groups]
        assert all(group_id is not None for group_id in group_ids), 'group_ids cannot be None'
        person.group_ids = group_ids  # type:ignore[assignment]
        return person

    def __keycloak_user_to_person_view(self, user: Mapping[str, Any]) -> PersonView:
        """
        Converts a user JSON object from Keycloak to a HEA PersonView object.

        :param user: a Keycloak user object as a JSON dict.
        :param groups: the groups the user is in as an iterable of JSON dicts. Uses only the 'id' property of each
        dict.
        :return: a PersonView object.
        """
        person_view: PersonView = PersonView()
        person_view.id = user['id']
        person_view.name = user['username']
        person_view.first_name = user.get('firstName')
        person_view.last_name = user.get('lastName')
        person_view.email = user.get('email')
        person_view.created = datetime.fromtimestamp(user['createdTimestamp'] / 1000.0, tz=system_timezone())
        share1: Share = ShareImpl()
        share1.user = ALL_USERS
        share1.permissions = [Permission.VIEWER]
        share2: Share = ShareImpl()
        share2.user = CREDENTIALS_MANAGER_USER
        share2.permissions = [Permission.EDITOR]
        person_view.user_shares = [share1, share2]
        person_view.actual_object_id = user['id']
        person_view.actual_object_type_name = Person.get_type_name()
        person_view.actual_object_uri = f'people/{user["id"]}'
        return person_view

    async def __get_group_roles(self, request, sub, group):
        logger = logging.getLogger(__name__)
        access_token_obj = await self.get_keycloak_access_token(request)
        assert access_token_obj is not None, 'access_token_obj cannot be None'
        access_token = access_token_obj.id
        session = _client_session(request)
        session_get = partial(session.get,
                                headers={'Authorization': f'Bearer {access_token}'},
                                ssl=self.verify_ssl)
        try:
            assert group.id is not None, 'group.id cannot be None'
            async with session_get(self.__realm_base_url / 'groups' / group.id / 'role-mappings') as response_:
                logger.debug('role mappings for group %s: %s', group.id, await response_.json())
                for role_dict in (await response_.json()).get('clientMappings', {}).get(self.client_id, {}).get('mappings', []):
                    role = self.__new_role(sub, role_dict)
                    assert role.id is not None, 'role.id cannot be None'
                    group.add_role_id(role.id)
        except ClientResponseError as e:
            raise ValueError(f'Error getting role mapping information for group {group.group}') from e

    def __clear_group_cache(self, sub: str):
        self.__ttl_cache.pop(('all_groups', sub), None)
        self.__ttl_cache.pop(('all_groups', None), None)
        self.__ttl_cache.pop(('all_group_views', None), None)
        self.__ttl_cache.pop(('my_groups', sub), None)
        self.__ttl_cache.pop(('my_group_views', sub), None)
        for cache_key in self.__ttl_cache.keys():
            if cache_key[0] == 'group_by_group':
                self.__ttl_cache.pop(cache_key, None)
            elif cache_key[0] == 'group_view_by_group':
                self.__ttl_cache.pop(cache_key, None)
            elif cache_key[0] == 'my_group_ids':
                self.__ttl_cache.pop(cache_key, None)


class KeycloakMongoManager(MongoManager):
    """
    Keycloak database manager object. It subclasses the Mongo database manager so that user data that Keycloak does not
    support can be stored in Mongo.
    """
    def __init__(self, config: Configuration | None = None,
                 client_id: str | None = DEFAULT_CLIENT_ID,
                 admin_client_id: str | None = DEFAULT_ADMIN_CLIENT_ID,
                 realm: str | None = None,
                 secret: str | None = None,
                 secret_file: str | None = None,
                 verify_ssl: bool = True):
        super().__init__(config)
        self.__client_id = str(client_id) if client_id is not None else DEFAULT_CLIENT_ID
        self.__admin_client_id = str(admin_client_id) if admin_client_id is not None else DEFAULT_ADMIN_CLIENT_ID
        self.__realm = str(realm) if realm is not None else DEFAULT_REALM
        self.__secret: str | None = str(secret) if secret is not None else None
        self.__secret_file: str | None = str(secret_file) if secret_file is not None else DEFAULT_SECRET_FILE
        self.__verify_ssl: bool = bool(verify_ssl)
        self.__keycloak_external_url: str | None = None

    @property
    def client_id(self) -> str:
        return self.__client_id

    @client_id.setter
    def client_id(self, client_id: str):
        self.__client_id = str(client_id) if client_id is not None else DEFAULT_CLIENT_ID

    @property
    def admin_client_id(self) -> str:
        return self.__admin_client_id

    @admin_client_id.setter
    def admin_client_id(self, admin_client_id: str):
        self.__admin_client_id = str(admin_client_id) if admin_client_id is not None else DEFAULT_ADMIN_CLIENT_ID

    @property
    def realm(self) -> str:
        return self.__realm

    @realm.setter
    def realm(self, realm: str):
        self.__realm = str(realm) if realm is not None else DEFAULT_REALM

    @property
    def secret(self) -> str | None:
        return self.__secret

    @secret.setter
    def secret(self, secret: str | None):
        self.__secret = str(secret) if secret is not None else None

    @property
    def secret_file(self) -> str | None:
        return self.__secret_file

    @secret_file.setter
    def secret_file(self, secret_file: str | None):
        self.__secret_file = str(secret_file) if secret_file is not None else None

    @property
    def verify_ssl(self) -> bool:
        return self.__verify_ssl

    @verify_ssl.setter
    def verify_ssl(self, verify_ssl: bool):
        self.__verify_ssl = bool(verify_ssl)

    @property
    def keycloak_external_url(self) -> str | None:
        return self.__keycloak_external_url

    def get_database(self) -> KeycloakMongo:
        return KeycloakMongo(config=self.config,
                            client_id=self.client_id,
                            admin_client_id=self.admin_client_id,
                            realm=self.realm,
                            host=self.keycloak_external_url,
                            secret=self.secret,
                            secret_file=self.secret_file,
                            verify_ssl=self.verify_ssl)


def _client_session(request: Request) -> ClientSession:
    return request.app[appproperty.HEA_CLIENT_SESSION]


def _person_to_person_view(person: Person) -> PersonView:
    person_view = PersonView()
    person_view.id = person.id
    person_view.name = person.name
    person_view.first_name = person.first_name
    person_view.last_name = person.last_name
    person_view.email = person.email
    person_view.created = person.created
    person_view.user_shares = copy(person.user_shares)
    person_view.actual_object_id = person.id
    person_view.actual_object_type_name = Person.get_type_name()
    person_view.actual_object_uri = f'people/{person.id}'
    return person_view
