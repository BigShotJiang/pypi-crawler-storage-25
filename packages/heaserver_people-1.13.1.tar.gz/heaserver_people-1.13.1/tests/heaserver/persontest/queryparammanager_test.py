from unittest import TestCase

from multidict import MultiDict
from heaserver.person.queryparammanager import GroupViewQueryParamManager, PersonViewQueryParamManager
from heaserver.service.aiohttp import SortOrder
from heaobject.person import GroupView, GroupView, PersonView
from aiohttp.test_utils import make_mocked_request


class TestPersonQueryParamManager(TestCase):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.maxDiff = None

    def test_exclude_system_users_param_true(self):
        params = {'excludesystem': 'true'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertTrue(query_param_manager.exclude_system_users)

    def test_exclude_system_users_param_false(self):
        params = {'excludesystem': 'false'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertFalse(query_param_manager.exclude_system_users)

    def test_exclude_system_users_param_default(self):
        params = {}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertFalse(query_param_manager.exclude_system_users)

    def test_sort_default(self):
        params = {}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual([], query_param_manager.sorts)

    def test_sort_without_sort_attr(self):
        params = {'sort': 'asc'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual([(SortOrder.ASC, 'display_name')], query_param_manager.sorts)

    def test_sort_with_sort_attr(self):
        params = {'sort': 'desc', 'sort_attr': 'name'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual([(SortOrder.DESC, 'name')], query_param_manager.sorts)

    def test_infix_filter_default(self):
        params = {'filter': 'test'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual('test', query_param_manager.infix_default_filter)
        self.assertEqual([], query_param_manager.infix_attr_filter)
        self.assertFalse(query_param_manager.both)

    def test_infix_filter_with_filter_attr_rest_call_params(self):
        params = {'filter': 'test', 'filter_attr': 'first_name'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertIsNone(query_param_manager.infix_default_filter)
        self.assertEqual([('first_name', 'test')], query_param_manager.infix_attr_filter)
        self.assertEqual(MultiDict({'firstName': 'test'}), query_param_manager.rest_call_params)
        self.assertFalse(query_param_manager.both)

    def test_infix_filter_with_filter_attr_and_exact_filter_rest_call_params(self):
        params = {'filter': 'test', 'filter_attr': 'first_name', 'name': 'testuser'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertIsNone(query_param_manager.infix_default_filter)
        self.assertEqual([('first_name', 'test')], query_param_manager.infix_attr_filter)
        self.assertEqual(tuple(), query_param_manager.exact_attr_filter)
        self.assertEqual(MultiDict({'firstName': 'test'}), query_param_manager.rest_call_params)
        self.assertEqual(set((('name', 'testuser'),)), set(query_param_manager.unused_exact_params))
        self.assertEqual(set(), set(query_param_manager.unused_infix_params))
        self.assertTrue(query_param_manager.both)

    def test_exact_filter_rest_call_params(self):
        params = {'name': 'testuser', 'first_name': 'test', 'last_name': 'user', 'email': 'test@example.com'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertIsNone(query_param_manager.infix_default_filter)
        self.assertEqual([], query_param_manager.infix_attr_filter)
        self.assertEqual((('name', 'testuser'), ('first_name', 'test'),
                          ('last_name', 'user'), ('email', 'test@example.com')),
                          query_param_manager.exact_attr_filter)
        self.assertEqual(MultiDict({'username': 'testuser', 'firstName': 'test',
                                    'lastName': 'user', 'email': 'test@example.com', 'exact': "true"}),
                         query_param_manager.rest_call_params)
        self.assertFalse(query_param_manager.both)

    def test_bad_exact_filter(self):
        params = {'username': 'testuser', 'firstName': 'test', 'lastName': 'user', 'email': 'test@example.com'}
        with self.assertRaises(ValueError):
            PersonViewQueryParamManager(params)

    def test_no_bad_exact_filters(self):
        params = {'display_name': 'testuser', 'first_name': 'test', 'last_name': 'user', 'email': 'test@example.com',
                  'begin': '0', 'limit': '10', 'return_attr': 'display_name', 'filter': 'test'}
        try:
            PersonViewQueryParamManager(params)
        except ValueError:
            self.fail('PersonViewQueryParamManager raised ValueError unexpectedly with params %s' % params)

    def test_unused_exact_params_none(self):
        params = {'name': 'testuser', 'first_name': 'test', 'last_name': 'user', 'email': 'test@example.com'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual(tuple(), query_param_manager.unused_exact_params)

    def test_unused_exact_params_some(self):
        params = {'name': 'testuser', 'first_name': 'test', 'last_name': 'user',
                  'email': 'test@example.com', 'created': '2024-01-01T00:00:00Z'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual((('created', '2024-01-01T00:00:00Z'),), query_param_manager.unused_exact_params)

    def test_unused_infix_params_none(self):
        params = {'filter': 'test', 'filter_attr': 'first_name', 'name': 'testuser', 'created': '2024-01-01T00:00:00Z'}
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual(set(), set(query_param_manager.unused_infix_params))

    def test_unused_infix_params_some(self):
        params = MultiDict((('filter', 'test'), ('filter_attr', 'first_name'), ('name', 'testuser'),
                  ('filter_attr', 'created'), ('filter', '2024-01-01T00:00:00Z')))
        query_param_manager = PersonViewQueryParamManager(params)
        self.assertEqual(set((('created', '2024-01-01T00:00:00Z'),)), set(query_param_manager.unused_infix_params))

    def test_filter_by_all_params(self):
        params = MultiDict((('filter', 'test'), ('filter_attr', 'first_name'), ('name', 'testuser'),
                  ('filter_attr', 'created'), ('filter', '2024-01-01 00:00:00+00:00'), ('last_name', 'user')))
        query_param_manager = PersonViewQueryParamManager(params)
        person1 = PersonView()
        person1.first_name = '1test'
        person1.name = 'testuser'
        person1.created = '2024-01-01T00:00:00Z'
        person1.last_name = 'user'
        person2 = PersonView()
        person2.first_name = 'test'
        person2.name = 'testuser'
        person2.created = '2024-01-01T00:00:00Z'
        person2.last_name = 'wronglast'
        person3 = PersonView()
        person3.first_name = '1test2'
        person3.name = 'testuser'
        person3.created = '2024-01-01T00:00:00Z'
        person3.last_name = 'user'
        person4 = PersonView()
        person4.first_name = 'test2'
        person4.name = 'testuser'
        person4.created = '2024-01-01T00:00:00Z'
        person4.last_name = 'user'
        results = list(query_param_manager.filter_by_all_params([person1, person2, person3, person4]))
        self.assertEqual([person1, person3, person4], results)
        self.assertIs(results[0], person1)

    def test_not_api_sort_and_not_api_paginate(self):
        url = 'http://localhost:4200/api/peopleviews/?excludesystem=yes&sort=asc&sort_attr=display_name&return_attr=id&return_attr=display_name&return_attr=actual_object_uri&begin=20&end=40&return_attr=id&return_attr=display_name'
        request = make_mocked_request('GET', url)
        query_param_mgr = PersonViewQueryParamManager(request.query)
        self.assertEqual([(SortOrder.ASC, 'display_name')], query_param_mgr.sorts)
        self.assertEqual({}, query_param_mgr.rest_call_params)
        self.assertFalse(query_param_mgr.api_sort)
        self.assertFalse(query_param_mgr.api_paginate)


class TestGroupQueryParamManager(TestCase):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.maxDiff = None

    def test_exclude_system_users_param_true(self):
        params = {'excludesystem': 'true'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertTrue(query_param_manager.exclude_system_users)

    def test_exclude_system_users_param_false(self):
        params = {'excludesystem': 'false'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertFalse(query_param_manager.exclude_system_users)

    def test_exclude_system_users_param_default(self):
        params = {}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertFalse(query_param_manager.exclude_system_users)

    def test_sort_default(self):
        params = {}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual([], query_param_manager.sorts)

    def test_sort_without_sort_attr(self):
        params = {'sort': 'asc'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual([(SortOrder.ASC, 'display_name')], query_param_manager.sorts)

    def test_sort_with_sort_attr(self):
        params = {'sort': 'desc', 'sort_attr': 'group'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual([(SortOrder.DESC, 'group')], query_param_manager.sorts)

    def test_infix_filter_default(self):
        params = {'filter': 'test'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual('test', query_param_manager.infix_default_filter)
        self.assertEqual([], query_param_manager.infix_attr_filter)
        self.assertFalse(query_param_manager.both)

    def test_infix_filter_with_filter_attr_rest_call_params(self):
        params = {'filter': 'test', 'filter_attr': 'group'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertIsNone(query_param_manager.infix_default_filter)
        self.assertEqual([('group', 'test')], query_param_manager.infix_attr_filter)
        self.assertEqual(MultiDict({'search': 'test'}), query_param_manager.rest_call_params)
        self.assertFalse(query_param_manager.both)

    def test_infix_filter_with_filter_attr_and_exact_filter_rest_call_params(self):
        params = {'filter': 'test', 'filter_attr': 'group', 'group': 'testgroup'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertIsNone(query_param_manager.infix_default_filter)
        self.assertEqual([('group', 'test')], query_param_manager.infix_attr_filter)
        self.assertEqual(tuple(), query_param_manager.exact_attr_filter)
        self.assertEqual(MultiDict({'search': 'test'}), query_param_manager.rest_call_params)
        self.assertEqual(set((('group', 'testgroup'),)), set(query_param_manager.unused_exact_params))
        self.assertEqual(set(), set(query_param_manager.unused_infix_params))
        self.assertTrue(query_param_manager.both)

    def test_exact_filter_rest_call_params(self):
        params = {'group': 'testgroup'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertIsNone(query_param_manager.infix_default_filter)
        self.assertEqual([], query_param_manager.infix_attr_filter)
        self.assertEqual((('group', 'testgroup'),), query_param_manager.exact_attr_filter)
        self.assertEqual(MultiDict({'search': 'testgroup', 'exact': "true"}), query_param_manager.rest_call_params)
        self.assertFalse(query_param_manager.both)

    def test_bad_exact_filter(self):
        params = {'username': 'testuser', 'firstName': 'test', 'lastName': 'user', 'email': 'test@example.com'}
        with self.assertRaises(ValueError):
            GroupViewQueryParamManager(params)

    def test_no_bad_exact_filters(self):
        params = {'name': 'testuser', 'begin': '0', 'limit': '10', 'return_attr': 'display_name', 'filter': 'test'}
        try:
            GroupViewQueryParamManager(params)
        except ValueError:
            self.fail('GroupViewQueryParamManager raised ValueError unexpectedly with params %s' % params)

    def test_unused_exact_params_none(self):
        params = {'group': 'testgroup'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual(tuple(), query_param_manager.unused_exact_params)

    def test_unused_exact_params_some(self):
        params = {'group': 'testgroup', 'created': '2024-01-01T00:00:00Z'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual((('created', '2024-01-01T00:00:00Z'),), query_param_manager.unused_exact_params)

    def test_unused_infix_params_none(self):
        params = {'filter': 'test', 'filter_attr': 'group', 'name': 'testgroup', 'created': '2024-01-01T00:00:00Z'}
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual(set(), set(query_param_manager.unused_infix_params))

    def test_unused_infix_params_some(self):
        params = MultiDict((('filter', 'test'), ('filter_attr', 'id'), ('name', 'testgroup'),
                  ('filter_attr', 'created'), ('filter', '2024-01-01T00:00:00Z')))
        query_param_manager = GroupViewQueryParamManager(params)
        self.assertEqual(set((('created', '2024-01-01T00:00:00Z'), ('id', 'test'))), set(query_param_manager.unused_infix_params))

    def test_filter_by_all_params(self):
        params = MultiDict((('filter', 'test'), ('filter_attr', 'group'),
                  ('filter_attr', 'created'), ('filter', '2024-01-01 00:00:00+00:00')))
        query_param_manager = GroupViewQueryParamManager(params)
        group1 = GroupView()
        group1.group = 'testgroup'
        group1.created = '2024-01-01T00:00:00Z'
        group2 = GroupView()
        group2.group = 'test'
        group2.created = '2024-01-01T00:00:00Z'
        group3 = GroupView()
        group3.group = 'grouptestgroup'
        group3.created = '2024-01-01T00:00:00Z'
        group4 = GroupView()
        group4.group = 'group'
        group4.created = '2024-01-01T00:00:00Z'
        self.assertEqual(set((('group', 'test'),)), set(query_param_manager.infix_attr_filter))
        self.assertEqual(set((('created', '2024-01-01 00:00:00+00:00'),)), set(query_param_manager.unused_infix_params))
        results = list(query_param_manager.filter_by_all_params([group1, group2, group3, group4]))
        self.assertEqual([group1, group2, group3], results)
        self.assertIs(results[0], group1)
