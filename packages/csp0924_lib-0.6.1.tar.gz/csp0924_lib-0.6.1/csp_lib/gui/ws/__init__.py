"""WebSocket real-time streaming."""
