"""Objective verification helpers."""
