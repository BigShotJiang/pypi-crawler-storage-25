# pylint: disable=R0801, duplicate-code, R0914, too-many-instance-attributes

"""
HTTPX-based OpenAI Language Model module implementation

This module implements the LanguageModel interface using direct REST
calls to the OpenAI API via httpx. It replicates the functionality of the
SDK‑based modules, supporting both synchronous and asynchronous methods.

"""

from typing import Any, Dict, List, Literal, Optional, Type, Union

import httpx
from openai.lib._parsing import type_to_response_format_param

from autorag.language_models.base import LanguageModel
from autorag.types.language_models import (
    ContentPolicyError,
    Generation,
    Logprobs,
    ParsedGeneration,
    ToolCall,
    Usage,
)
from autorag.types.language_models.generation import Logprob, ResponseFormatT

# Define a type variable for response_format parameter


class RestApiOpenAILanguageModel(LanguageModel):
    """
    OpenAI Language Model implementation using REST API with httpx.

    This class implements the interface of the SDK-based OpenAILanguageModel
    but uses httpx to make HTTP requests directly to the OpenAI API.
    """

    def __init__(
        self,
        api_version: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        auth_header: dict[str, str] | None = None,
        timeouts: dict[str, float] | None = None,
        verify_ssl: bool = True,
        pass_model_name_in_payload: bool = True,
        api_type: Literal["chat-completions", "responses"] = "responses",
    ) -> None:
        """
        Initializes the HTTPX OpenAI client.

        Args:
            api_key (Optional[str]): Your OpenAI API key.
            base_url (Optional[str]): The API base URL.
            api_type (Literal): Whether to use the Responses or Chat Completions API.
        """
        super().__init__()
        self._api_version = api_version
        self.api_type = api_type
        if not api_key and not auth_header:
            raise ValueError(
                "The api_key  or Auth Header via  must be provided by parameter"
            )
        self.base_url = base_url

        self._params = {"api-version": api_version}

        if not self.base_url:
            raise ValueError("The base_url must be proviced via parameter")

        default_headers = {"Content-Type": "application/json"}

        headers = {}

        if auth_header:
            headers = {**auth_header, **default_headers}
        elif api_key:
            headers = {"api-key": api_key, **default_headers}

        self._headers = headers

        timeout_dict: dict[str, float] = {}
        if timeouts is not None:
            timeout_dict = timeouts

        self._timeout_obj = httpx.Timeout(
            connect=timeout_dict.get("connect", 60),
            read=timeout_dict.get("read", 600),
            write=timeout_dict.get("write", 60),
            pool=timeout_dict.get("pool", 60),
        )

        self._client = httpx.Client(
            base_url=self.base_url,
            params=self._params,
            headers=headers,
            timeout=self._timeout_obj,
            verify=verify_ssl,
        )

        self._verify_ssl = verify_ssl

        self._pass_model_name_in_payload = pass_model_name_in_payload

    async def _get_async_client(self) -> httpx.AsyncClient:
        """
        Create an Async httpx client
        """
        return httpx.AsyncClient(
            base_url=self.base_url,  # type: ignore
            params=self._params,
            headers=self._headers,
            timeout=self._timeout_obj,
            verify=self._verify_ssl,
        )

    def _build_responses_payload(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        tool: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Builds a Responses API payload. Only non-None values are included."""
        payload: Dict[str, Any] = {"input": messages}
        if self._pass_model_name_in_payload:
            payload["model"] = model

        if tool is not None:
            payload["tools"] = [tool]
        if max_tokens is not None:
            payload["max_output_tokens"] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature

        include: list[str] = []
        if logprobs or top_logprobs is not None:
            include.append("message.output_text.logprobs")
        if include:
            payload["include"] = include
        if top_logprobs is not None:
            payload["top_logprobs"] = top_logprobs

        for key, value in kwargs.items():
            if value is not None:
                payload[key] = value

        return payload

    def _build_chat_completions_payload(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        tool: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        stop: Optional[Union[str, List[str]]] = None,
        temperature: Optional[float] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Builds a Chat Completions API payload. Only non-None values are included."""
        payload: Dict[str, Any] = {"messages": messages}
        if self._pass_model_name_in_payload:
            payload["model"] = model

        if tool is not None:
            payload["tools"] = [tool]
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature
        if logprobs is not None:
            payload["logprobs"] = logprobs
        if top_logprobs is not None:
            payload["top_logprobs"] = top_logprobs
        if frequency_penalty is not None:
            payload["frequency_penalty"] = frequency_penalty
        if presence_penalty is not None:
            payload["presence_penalty"] = presence_penalty
        if seed is not None:
            payload["seed"] = seed
        if stop is not None:
            payload["stop"] = stop

        for key, value in kwargs.items():
            if value is not None:
                payload[key] = value

        return payload

    # ------------------------------------------------------------------ #
    # Responses API extraction helpers                                     #
    # ------------------------------------------------------------------ #

    def _extract_response_message(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        for item in data.get("output", []) or []:
            if item.get("type") == "message":
                return item
        return None

    def _extract_content(self, data: Dict[str, Any]) -> Optional[str]:
        output_text = data.get("output_text")
        if output_text:
            return output_text

        message = self._extract_response_message(data)
        if not message:
            return None

        texts: list[str] = []
        for content in message.get("content", []) or []:
            if content.get("type") == "output_text" and content.get("text"):
                texts.append(content["text"])
        return "".join(texts) if texts else None

    def _extract_tool_call(self, data: Dict[str, Any]) -> Optional[ToolCall]:
        for item in data.get("output", []) or []:
            if item.get("type") == "function_call":
                return ToolCall(
                    name=item.get("name"),
                    arguments=item.get("arguments"),
                )
        return None

    def _extract_logprobs(self, data: Dict[str, Any]) -> Optional[List[Logprobs]]:
        message = self._extract_response_message(data)
        if not message:
            return None

        for content in message.get("content", []) or []:
            if content.get("type") != "output_text":
                continue
            raw_logprobs = content.get("logprobs")
            if raw_logprobs:
                return [Logprobs(**item) for item in raw_logprobs]
        return None

    def _extract_finish_reason(self, data: Dict[str, Any]) -> Optional[str]:
        if self._extract_tool_call(data) is not None:
            return "tool_calls"

        status = data.get("status")
        if status == "completed":
            return "stop"

        if status == "incomplete":
            reason = (data.get("incomplete_details") or {}).get("reason")
            if reason == "max_output_tokens":
                return "length"
            if reason == "content_filter":
                return "content_filter"
        return None

    def _extract_role(self, data: Dict[str, Any]) -> Optional[str]:
        message = self._extract_response_message(data)
        if message is not None:
            return message.get("role", "assistant")
        if self._extract_tool_call(data) is not None:
            return "assistant"
        return None

    def _severity_from_policy_details(self, details: Any) -> str:
        if isinstance(details, dict):
            severity = details.get("severity")
            if severity:
                return str(severity)
            if details.get("filtered") is True:
                return "filtered"
            if details.get("detected") is True:
                return "detected"
        return "unknown"

    def _policy_errors_from_result(
        self, results: Any, source: str
    ) -> list[ContentPolicyError]:
        errors: list[ContentPolicyError] = []
        if isinstance(results, list):
            for item in results:
                errors.extend(self._policy_errors_from_result(item, source))
            return errors
        if not isinstance(results, dict):
            return errors

        for policy_type, details in results.items():
            if not isinstance(details, dict):
                continue
            severity = self._severity_from_policy_details(details)
            is_violation = (
                details.get("filtered") is True
                or details.get("detected") is True
                or details.get("blocked") is True
                or details.get("violation") is True
            )
            if not is_violation and severity.lower() in {"safe", "none"}:
                continue
            if not is_violation and severity == "unknown":
                continue
            errors.append(
                ContentPolicyError(
                    content_policy_type=str(policy_type),
                    severity=severity,
                    source=source,  # type: ignore[arg-type]
                )
            )
        return errors

    def _extract_content_policy_errors(
        self, data: Dict[str, Any]
    ) -> list[ContentPolicyError]:
        errors: list[ContentPolicyError] = []

        for attr_name in ("prompt_filter_results", "prompt_filter_result"):
            errors.extend(self._policy_errors_from_result(data.get(attr_name), "Prompt"))

        for item in data.get("input", []) or []:
            for attr_name in ("content_filter_results", "content_filter_result"):
                errors.extend(
                    self._policy_errors_from_result(item.get(attr_name), "Prompt")
                )

        incomplete_details = data.get("incomplete_details") or {}
        for attr_name in ("content_filter_results", "content_filter_result"):
            errors.extend(
                self._policy_errors_from_result(
                    incomplete_details.get(attr_name), "Completion"
                )
            )
            errors.extend(
                self._policy_errors_from_result(data.get(attr_name), "Completion")
            )

        for item in data.get("output", []) or []:
            for attr_name in ("content_filter_results", "content_filter_result"):
                errors.extend(
                    self._policy_errors_from_result(item.get(attr_name), "Completion")
                )

        if not errors and incomplete_details.get("reason") == "content_filter":
            errors.append(
                ContentPolicyError(
                    content_policy_type="content_filter",
                    severity="unknown",
                    source="Completion",
                )
            )

        deduped: list[ContentPolicyError] = []
        seen: set[tuple[str, str, str]] = set()
        for error in errors:
            key = (error.content_policy_type, error.severity, error.source)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(error)
        return deduped

    def _extract_usage(self, data: Dict[str, Any]) -> Usage:
        usage_data = data.get("usage", {})
        input_details = usage_data.get("input_tokens_details", {})
        return Usage(
            completion_tokens=usage_data.get("output_tokens"),
            prompt_tokens=usage_data.get("input_tokens"),
            total_tokens=usage_data.get("total_tokens"),
            cached_tokens=input_details.get("cached_tokens"),
        )

    def _handle_response(self, data: Dict[str, Any]) -> Generation:
        """Converts a Responses API JSON response into a Generation object."""
        return Generation(
            content=self._extract_content(data),
            finish_reason=self._extract_finish_reason(data),  # type: ignore[arg-type]
            role=self._extract_role(data),
            usage=self._extract_usage(data),
            tool_call=self._extract_tool_call(data),
            logprobs=self._extract_logprobs(data),
            content_policy_errors=self._extract_content_policy_errors(data),
        )

    def _handle_parsed_response(
        self, data: Dict[str, Any], response_format: Type[ResponseFormatT]
    ) -> ParsedGeneration:
        """Converts a Responses API JSON response into a ParsedGeneration object."""
        return ParsedGeneration(
            content=self._extract_content(data),
            finish_reason=self._extract_finish_reason(data),  # type: ignore[arg-type]
            role=self._extract_role(data),
            usage=self._extract_usage(data),
            tool_call=None,
            parsed=response_format.model_validate_json(self._extract_content(data) or ""),
            content_policy_errors=self._extract_content_policy_errors(data),
        )

    # ------------------------------------------------------------------ #
    # Chat Completions API extraction helpers                              #
    # ------------------------------------------------------------------ #

    def _extract_chat_completion_content(self, data: Dict[str, Any]) -> Optional[str]:
        choices = data.get("choices") or []
        if not choices:
            return None
        return (choices[0].get("message") or {}).get("content")

    def _extract_chat_completion_role(self, data: Dict[str, Any]) -> Optional[str]:
        choices = data.get("choices") or []
        if not choices:
            return None
        return (choices[0].get("message") or {}).get("role", "assistant")

    def _extract_chat_completion_finish_reason(self, data: Dict[str, Any]) -> Optional[str]:
        choices = data.get("choices") or []
        if not choices:
            return None
        raw = choices[0].get("finish_reason")
        if raw == "function_call":
            return "tool_calls"
        return raw

    def _extract_chat_completion_tool_call(self, data: Dict[str, Any]) -> Optional[ToolCall]:
        choices = data.get("choices") or []
        if not choices:
            return None
        message = choices[0].get("message") or {}
        tool_calls = message.get("tool_calls") or []
        if tool_calls:
            func = tool_calls[0].get("function") or {}
            return ToolCall(name=func.get("name"), arguments=func.get("arguments"))
        return None

    def _extract_chat_completion_logprobs(self, data: Dict[str, Any]) -> Optional[List[Logprobs]]:
        choices = data.get("choices") or []
        if not choices:
            return None
        logprobs_obj = choices[0].get("logprobs") or {}
        content = logprobs_obj.get("content") or []
        if not content:
            return None
        result: list[Logprobs] = []
        for item in content:
            top_raw = item.get("top_logprobs") or []
            result.append(
                Logprobs(
                    token=item.get("token"),
                    bytes=item.get("bytes"),
                    logprob=item.get("logprob"),
                    top_logprobs=[
                        Logprob(
                            token=t.get("token"),
                            bytes=t.get("bytes"),
                            logprob=t.get("logprob"),
                        )
                        for t in top_raw
                    ],
                )
            )
        return result if result else None

    def _extract_chat_completion_usage(self, data: Dict[str, Any]) -> Usage:
        usage_data = data.get("usage") or {}
        prompt_details = usage_data.get("prompt_tokens_details") or {}
        return Usage(
            completion_tokens=usage_data.get("completion_tokens"),
            prompt_tokens=usage_data.get("prompt_tokens"),
            total_tokens=usage_data.get("total_tokens"),
            cached_tokens=prompt_details.get("cached_tokens"),
        )

    def _handle_chat_completion_response(self, data: Dict[str, Any]) -> Generation:
        """Converts a Chat Completions API JSON response into a Generation object."""
        return Generation(
            content=self._extract_chat_completion_content(data),
            finish_reason=self._extract_chat_completion_finish_reason(data),  # type: ignore[arg-type]
            role=self._extract_chat_completion_role(data),
            usage=self._extract_chat_completion_usage(data),
            tool_call=self._extract_chat_completion_tool_call(data),
            logprobs=self._extract_chat_completion_logprobs(data),
            content_policy_errors=[],
        )

    def _handle_chat_completion_parsed_response(
        self, data: Dict[str, Any], response_format: Type[ResponseFormatT]
    ) -> ParsedGeneration:
        """Converts a Chat Completions API JSON response into a ParsedGeneration object."""
        content = self._extract_chat_completion_content(data)
        return ParsedGeneration(
            content=content,
            finish_reason=self._extract_chat_completion_finish_reason(data),  # type: ignore[arg-type]
            role=self._extract_chat_completion_role(data),
            usage=self._extract_chat_completion_usage(data),
            tool_call=None,
            parsed=response_format.model_validate_json(content or ""),
            content_policy_errors=[],
        )

    def _create_response_format_schema(
        self, response_format: Type[ResponseFormatT]
    ) -> Dict[str, Any]:
        """
        Build the `text.format` dict for the OpenAI Responses endpoint,
        using the JSON schema of the given Pydantic model.
        """
        return type_to_response_format_param(response_format=response_format) # type: ignore

    def _generate(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        tool: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        stop: Optional[Union[str, List[str]]] = None,
        temperature: Optional[float] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> Generation:
        """
        Synchronously generates a response using the OpenAI REST API.
        """
        if self.api_type == "chat-completions":
            payload = self._build_chat_completions_payload(
                messages=messages,
                model=model,
                tool=tool,
                max_tokens=max_tokens,
                frequency_penalty=frequency_penalty,
                presence_penalty=presence_penalty,
                seed=seed,
                stop=stop,
                temperature=temperature,
                logprobs=logprobs,
                top_logprobs=top_logprobs,
                **kwargs,
            )
            response = self._client.post("/chat/completions", json=payload)
            response.raise_for_status()
            return self._handle_chat_completion_response(response.json())

        payload = self._build_responses_payload(
            messages=messages,
            model=model,
            tool=tool,
            max_tokens=max_tokens,
            temperature=temperature,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            **kwargs,
        )
        response = self._client.post("/responses", json=payload)
        response.raise_for_status()
        return self._handle_response(response.json())

    async def agenerate(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        tool: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        stop: Optional[Union[str, List[str]]] = None,
        temperature: Optional[float] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> Generation:
        """
        Asynchronously generates a response using the OpenAI REST API.
        """
        if self.api_type == "chat-completions":
            payload = self._build_chat_completions_payload(
                messages=messages,
                model=model,
                tool=tool,
                max_tokens=max_tokens,
                frequency_penalty=frequency_penalty,
                presence_penalty=presence_penalty,
                seed=seed,
                stop=stop,
                temperature=temperature,
                logprobs=logprobs,
                top_logprobs=top_logprobs,
                **kwargs,
            )
            async with await self._get_async_client() as client:
                resp = await client.post("/chat/completions", json=payload)
                resp.raise_for_status()
            return self._handle_chat_completion_response(resp.json())

        payload = self._build_responses_payload(
            messages=messages,
            model=model,
            tool=tool,
            max_tokens=max_tokens,
            temperature=temperature,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            **kwargs,
        )
        async with await self._get_async_client() as client:
            resp = await client.post("/responses", json=payload)
            resp.raise_for_status()
            data = resp.json()
        return self._handle_response(data)

    def _parse(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        response_format: Type[ResponseFormatT],
        seed: Optional[int] = None,
        temperature: Optional[float] = None,
        **kwargs: Any,
    ) -> ParsedGeneration[ResponseFormatT]:
        """
        Synchronously generates a parsed response using the beta parse endpoint.
        The desired response format is passed as the name of the response_format class.
        """
        if self.api_type == "chat-completions":
            payload = self._build_chat_completions_payload(
                messages=messages,
                model=model,
                seed=seed,
                temperature=temperature,
                **kwargs,
            )
            payload["response_format"] = self._create_response_format_schema(response_format)
            response = self._client.post("/chat/completions", json=payload)
            response.raise_for_status()
            return self._handle_chat_completion_parsed_response(response.json(), response_format)

        payload = self._build_responses_payload(
            messages=messages,
            model=model,
            seed=seed,
            temperature=temperature,
            **kwargs,
        )
        payload.update(
            {
                "text": {
                    "format": self._create_response_format_schema(
                        response_format=response_format
                    )
                }
            }
        )

        response = self._client.post("/responses", json=payload)
        response.raise_for_status()
        return self._handle_parsed_response(response.json(), response_format)

    async def aparse(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        response_format: Type[ResponseFormatT],
        seed: Optional[int] = None,
        temperature: Optional[float] = None,
        **kwargs: Any,
    ) -> ParsedGeneration[ResponseFormatT]:
        """
        Asynchronously generates a parsed response using the beta parse endpoint.
        """
        if self.api_type == "chat-completions":
            payload = self._build_chat_completions_payload(
                messages=messages,
                model=model,
                seed=seed,
                temperature=temperature,
                **kwargs,
            )
            payload["response_format"] = self._create_response_format_schema(response_format)
            async with await self._get_async_client() as client:
                resp = await client.post("/chat/completions", json=payload)
                resp.raise_for_status()
            return self._handle_chat_completion_parsed_response(resp.json(), response_format)

        payload = self._build_responses_payload(
            messages=messages,
            model=model,
            seed=seed,
            temperature=temperature,
            **kwargs,
        )
        payload.update(
            {
                "text": {
                    "format": self._create_response_format_schema(
                        response_format=response_format
                    )
                }
            }
        )

        async with await self._get_async_client() as client:
            resp = await client.post(
                "/responses",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
        return self._handle_parsed_response(data, response_format)
