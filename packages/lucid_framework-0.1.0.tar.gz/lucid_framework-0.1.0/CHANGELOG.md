# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-04-06

### Added

- `Application` class — entry point with container, config, and event dispatcher wired at construction
- `app.configure(defaults, env_path)` — cascading config loading: defaults → `.env` → `.env.local` → environment variables; missing files skipped silently
- `app.register(ProviderClass)` — instantiates and calls `register()` immediately; raises `RuntimeError` if called after boot
- `app.boot()` — dispatches `AppBooting`, calls `boot()` on all providers in registration order, sets `is_booted`, dispatches `AppBooted`; idempotent
- `app.make(abstract)` — shorthand for `app.container.make()`
- `app.container`, `app.config`, `app.events` — direct property access to core sub-systems
- `app.is_booted` — bool property indicating boot state
- `ServiceProvider` base class with `self.app`, `register()`, and `boot()` hooks
- `AppBooting` event — dispatched at the start of `boot()`, carries `app` reference
- `AppBooted` event — dispatched after all providers have booted, carries `app` reference
- Re-exports of the full lucid ecosystem from the top-level `lucid` package: `Container`, `Config`, `ConfigContract`, `Event`, `Dispatcher`, `DispatcherContract`, `Listener`, `AsyncListener`, `Subscriber`, `Pipeline`, `AsyncPipeline`, `Pipe`, `AsyncPipe`
- 68 tests covering application lifecycle, configuration, container resolution, service providers, lifecycle events, re-exports, and integration scenarios

### Dependencies

- `lucid-container >= 0.1.0`
- `lucid-config >= 0.1.0`
- `lucid-events >= 0.1.0`
- `lucid-pipeline >= 0.1.0`
