from lucid_events import Event


class AppBooting(Event):
    def __init__(self, app: "Application") -> None:  # type: ignore[name-defined]
        self.app = app
