from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lucid.application import Application


class ServiceProvider:
    def __init__(self, app: "Application") -> None:
        self.app = app

    def register(self) -> None:
        """Bind things into the container. Called immediately on app.register()."""
        pass

    def boot(self) -> None:
        """Called after all providers have registered. Safe to resolve dependencies."""
        pass
