from __future__ import annotations

from lucid_container import Container
from lucid_config import Config, ConfigContract
from lucid_events import Dispatcher, DispatcherContract

from lucid.service_provider import ServiceProvider
from lucid.events.app_booting import AppBooting
from lucid.events.app_booted import AppBooted


class Application:
    def __init__(self) -> None:
        self._container = Container()
        self._config = Config()
        self._dispatcher = Dispatcher(container=self._container)
        self._providers: list[ServiceProvider] = []
        self._booted = False

        # Bind core services
        self._container.instance("app", self)
        self._container.instance(ConfigContract, self._config)
        self._container.alias("config", ConfigContract)
        self._container.instance(DispatcherContract, self._dispatcher)
        self._container.alias("events", DispatcherContract)

    @property
    def container(self) -> Container:
        return self._container

    @property
    def config(self) -> Config:
        return self._config

    @property
    def events(self) -> Dispatcher:
        return self._dispatcher

    @property
    def is_booted(self) -> bool:
        return self._booted

    def configure(self, defaults: dict, env_path: str = ".env") -> None:
        """Load config from defaults, .env, .env.local, and environment variables."""
        self._config.load_dict(defaults)
        self._load_env_silent(env_path)
        self._load_env_silent(f"{env_path}.local")
        self._config.load_env_vars()

    def _load_env_silent(self, path: str) -> None:
        """Load a .env file, silently skipping if it doesn't exist."""
        try:
            self._config.load_env(path)
        except FileNotFoundError:
            pass

    def register(self, provider_class: type) -> None:
        """Instantiate a service provider and call its register() immediately."""
        if self._booted:
            raise RuntimeError(
                f"Cannot register {provider_class.__name__} after the application has booted."
            )
        provider = provider_class(self)
        self._providers.append(provider)
        provider.register()

    def make(self, abstract: object) -> object:
        """Resolve any binding from the container."""
        return self._container.make(abstract)

    def boot(self) -> None:
        """Boot the application: run providers, fire lifecycle events."""
        if self._booted:
            return

        self._dispatcher.dispatch(AppBooting(self))

        for provider in self._providers:
            provider.boot()

        self._booted = True
        self._dispatcher.dispatch(AppBooted(self))
