"""Full-stack integration tests."""
import pytest

from lucid import (
    Application,
    ServiceProvider,
    Pipeline,
    Pipe,
    Event,
    Listener,
)
from lucid.events import AppBooted


# ── Domain objects ────────────────────────────────────────────────────────────

class EmailContract:
    pass


class FakeMailer(EmailContract):
    def __init__(self) -> None:
        self.sent: list[str] = []

    def send(self, to: str, subject: str) -> None:
        self.sent.append(subject)


class UserRegistered(Event):
    def __init__(self, email: str) -> None:
        self.email = email


class OrderCompleted(Event):
    def __init__(self, order_id: int) -> None:
        self.order_id = order_id


class PaymentService:
    def __init__(self, mailer: EmailContract) -> None:
        self.mailer = mailer

    def charge(self, amount: int) -> dict:
        return {"charged": amount}


# ── Providers ─────────────────────────────────────────────────────────────────

class MailProvider(ServiceProvider):
    def register(self) -> None:
        self.app.container.instance(EmailContract, FakeMailer())


class EventProvider(ServiceProvider):
    def boot(self) -> None:
        self.app.events.listen(
            UserRegistered,
            lambda e: self.app.make(EmailContract).send(e.email, "Welcome"),
        )


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_full_stack_configure_register_boot_make():
    app = Application()
    app.configure({"app": {"name": "test", "debug": True}})
    app.register(MailProvider)
    app.boot()

    mailer = app.make(EmailContract)
    assert isinstance(mailer, FakeMailer)
    assert app.config.get("app.name") == "test"
    assert app.is_booted is True


def test_provider_registers_binding_another_provider_resolves_during_boot():
    resolved = []

    class BindingProvider(ServiceProvider):
        def register(self) -> None:
            self.app.container.singleton(FakeMailer, FakeMailer)

    class ResolvingProvider(ServiceProvider):
        def boot(self) -> None:
            resolved.append(self.app.make(FakeMailer))

    app = Application()
    app.register(BindingProvider)
    app.register(ResolvingProvider)
    app.boot()
    assert len(resolved) == 1
    assert isinstance(resolved[0], FakeMailer)


def test_event_listener_registered_in_provider_fires():
    app = Application()
    app.register(MailProvider)
    app.register(EventProvider)
    app.boot()

    app.events.dispatch(UserRegistered("alice@example.com"))
    mailer = app.make(EmailContract)
    assert "Welcome" in mailer.sent


def test_config_loaded_in_configure_read_by_provider():
    names = []

    class ReadConfigProvider(ServiceProvider):
        def register(self) -> None:
            names.append(self.app.config.get("app.name"))

    app = Application()
    app.configure({"app": {"name": "my-service"}})
    app.register(ReadConfigProvider)
    assert names == ["my-service"]


def test_container_autowires_service_with_provider_bound_deps():
    app = Application()
    app.register(MailProvider)
    app.boot()

    svc = app.make(PaymentService)
    assert isinstance(svc.mailer, FakeMailer)


def test_pipeline_inside_container_resolved_service():
    class NormalizeStep(Pipe):
        def handle(self, data: dict, next_pipe) -> dict:
            data["email"] = data["email"].strip().lower()
            return next_pipe(data)

    class ValidateStep(Pipe):
        def handle(self, data: dict, next_pipe) -> dict:
            assert "@" in data["email"]
            return next_pipe(data)

    class PipelineService:
        def process(self, raw: dict) -> dict:
            return (
                Pipeline(raw)
                .through([NormalizeStep(), ValidateStep()])
                .then(lambda d: d)
            )

    app = Application()
    app.boot()
    svc = app.make(PipelineService)
    result = svc.process({"email": "  Alice@Example.COM  "})
    assert result["email"] == "alice@example.com"


def test_instance_override_replaces_singleton_for_testing():
    app = Application()
    app.register(MailProvider)
    app.boot()

    fake = FakeMailer()
    fake.sent = ["pre-existing"]
    app.container.instance(EmailContract, fake)

    mailer = app.make(EmailContract)
    assert mailer.sent == ["pre-existing"]


def test_app_booted_event_has_correct_config():
    received_name = []

    app = Application()
    app.configure({"app": {"name": "boot-test"}})
    app.events.listen(AppBooted, lambda e: received_name.append(e.app.config.get("app.name")))
    app.boot()

    assert received_name == ["boot-test"]


def test_application_with_no_providers_boots_successfully():
    app = Application()
    app.boot()
    assert app.is_booted is True


def test_application_with_no_config_boots_successfully():
    app = Application()
    app.boot()
    assert app.is_booted is True


def test_make_before_boot_works_for_registered_bindings():
    app = Application()
    app.register(MailProvider)
    # make() before boot() — MailProvider.register() already ran
    mailer = app.make(EmailContract)
    assert isinstance(mailer, FakeMailer)


def test_two_providers_binding_same_abstract_last_wins():
    class FirstProvider(ServiceProvider):
        def register(self) -> None:
            self.app.container.singleton(EmailContract, lambda c: FakeMailer())

    class SecondProvider(ServiceProvider):
        def register(self) -> None:
            fake = FakeMailer()
            fake.sent = ["second"]
            self.app.container.instance(EmailContract, fake)

    app = Application()
    app.register(FirstProvider)
    app.register(SecondProvider)
    app.boot()

    mailer = app.make(EmailContract)
    assert mailer.sent == ["second"]


def test_provider_register_exception_surfaces():
    class BadProvider(ServiceProvider):
        def register(self) -> None:
            raise RuntimeError("register failed")

    app = Application()
    with pytest.raises(RuntimeError, match="register failed"):
        app.register(BadProvider)


def test_provider_boot_exception_surfaces():
    class BadProvider(ServiceProvider):
        def boot(self) -> None:
            raise RuntimeError("boot failed")

    app = Application()
    app.register(BadProvider)
    with pytest.raises(RuntimeError, match="boot failed"):
        app.boot()


def test_register_after_boot_raises():
    app = Application()
    app.boot()

    class LateProvider(ServiceProvider):
        pass

    with pytest.raises(RuntimeError, match="after the application has booted"):
        app.register(LateProvider)
