"""Tests for re-exported symbols from lucid top-level package."""


def test_import_application():
    from lucid import Application
    assert Application is not None


def test_import_service_provider():
    from lucid import ServiceProvider
    assert ServiceProvider is not None


def test_import_container():
    from lucid import Container
    assert Container is not None


def test_import_config_and_contract():
    from lucid import Config, ConfigContract
    assert Config is not None
    assert ConfigContract is not None


def test_import_event_dispatcher():
    from lucid import Event, Dispatcher, DispatcherContract
    assert Event is not None
    assert Dispatcher is not None
    assert DispatcherContract is not None


def test_import_listener_types():
    from lucid import Listener, AsyncListener, Subscriber
    assert Listener is not None
    assert AsyncListener is not None
    assert Subscriber is not None


def test_import_pipeline():
    from lucid import Pipeline, AsyncPipeline, Pipe, AsyncPipe
    assert Pipeline is not None
    assert AsyncPipeline is not None
    assert Pipe is not None
    assert AsyncPipe is not None


def test_import_lifecycle_events():
    from lucid import AppBooting, AppBooted
    assert AppBooting is not None
    assert AppBooted is not None
