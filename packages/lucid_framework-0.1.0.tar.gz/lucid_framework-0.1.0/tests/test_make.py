"""Tests for container resolution through app.make()."""
import pytest

from lucid import Application, Container, Config, ConfigContract, Dispatcher, DispatcherContract


class SimpleService:
    pass


class DependentService:
    def __init__(self, simple: SimpleService) -> None:
        self.simple = simple


def test_make_returns_app_itself():
    app = Application()
    assert app.make("app") is app


def test_make_config_alias():
    app = Application()
    assert app.make("config") is app.config


def test_make_events_alias():
    app = Application()
    assert app.make("events") is app.events


def test_make_config_contract():
    app = Application()
    assert app.make(ConfigContract) is app.config


def test_make_dispatcher_contract():
    app = Application()
    assert app.make(DispatcherContract) is app.events


def test_make_singleton_binding():
    app = Application()
    app.container.singleton(SimpleService, SimpleService)
    s1 = app.make(SimpleService)
    s2 = app.make(SimpleService)
    assert s1 is s2


def test_make_bind_creates_new_each_time():
    app = Application()
    app.container.bind(SimpleService, SimpleService)
    s1 = app.make(SimpleService)
    s2 = app.make(SimpleService)
    assert s1 is not s2


def test_make_autowires_dependencies():
    app = Application()
    app.container.singleton(SimpleService, SimpleService)
    svc = app.make(DependentService)
    assert isinstance(svc.simple, SimpleService)


def test_make_container_returns_container():
    app = Application()
    assert app.make(Container) is app.container
