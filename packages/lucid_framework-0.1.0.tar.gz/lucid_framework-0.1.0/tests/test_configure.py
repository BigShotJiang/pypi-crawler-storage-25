"""Tests for app.configure()."""
import os
import tempfile

import pytest

from lucid import Application


def test_configure_loads_defaults():
    app = Application()
    app.configure({"app": {"name": "test-app", "debug": False}})
    assert app.config.get("app.name") == "test-app"


def test_configure_accessible_via_get():
    app = Application()
    app.configure({"database": {"host": "localhost", "port": 5432}})
    assert app.config.get("database.host") == "localhost"
    assert app.config.get("database.port") == 5432


def test_configure_missing_env_file_does_not_raise():
    app = Application()
    app.configure({}, env_path="/nonexistent/.env")  # Should not raise


def test_configure_missing_env_local_file_does_not_raise():
    app = Application()
    app.configure({})  # .env and .env.local both missing — no raise


def test_configure_type_casting_boolean():
    app = Application()
    app.configure({"app": {"debug": False}})
    assert app.config.boolean("app.debug") is False


def test_configure_type_casting_integer():
    app = Application()
    app.configure({"database": {"port": 5432}})
    assert app.config.integer("database.port") == 5432


def test_configure_env_file_overrides_defaults():
    app = Application()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".env", delete=False) as f:
        f.write("APP_NAME=from-env\n")
        env_path = f.name

    try:
        app.configure({"app": {"name": "default"}}, env_path=env_path)
        assert app.config.get("app.name") == "from-env"
    finally:
        os.unlink(env_path)


def test_configure_env_local_overrides_env():
    app = Application()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".env", delete=False) as f:
        f.write("APP_NAME=from-env\n")
        env_path = f.name

    local_path = env_path + ".local"
    with open(local_path, "w") as f:
        f.write("APP_NAME=from-local\n")

    try:
        app.configure({"app": {"name": "default"}}, env_path=env_path)
        assert app.config.get("app.name") == "from-local"
    finally:
        os.unlink(env_path)
        os.unlink(local_path)


def test_configure_environment_variables_override_defaults(monkeypatch):
    monkeypatch.setenv("APP_NAME", "from-os-env")
    app = Application()
    app.configure({"app": {"name": "default"}})
    assert app.config.get("app.name") == "from-os-env"
