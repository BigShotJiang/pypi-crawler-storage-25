"""Tests for ServiceProvider registration and boot lifecycle."""
import pytest

from lucid import Application, ServiceProvider


class SimpleService:
    pass


class UpstreamService:
    pass


class DownstreamService:
    def __init__(self, upstream: UpstreamService) -> None:
        self.upstream = upstream


class TrackingProvider(ServiceProvider):
    calls: list[str] = []

    def register(self) -> None:
        self.calls.append("register")

    def boot(self) -> None:
        self.calls.append("boot")


class RegisteringProvider(ServiceProvider):
    def register(self) -> None:
        self.app.container.singleton(SimpleService, SimpleService)


class BootResolvingProvider(ServiceProvider):
    resolved: list[object] = []

    def boot(self) -> None:
        self.resolved.append(self.app.make(SimpleService))


class ConfigReadingProvider(ServiceProvider):
    name: str = ""

    def register(self) -> None:
        ConfigReadingProvider.name = self.app.config.get("app.name", "")


class EventRegisteringProvider(ServiceProvider):
    def boot(self) -> None:
        from lucid.events import AppBooted
        self.app.events.listen(AppBooted, lambda e: None)


def test_register_instantiates_with_app():
    app = Application()
    providers = []

    class CapturingProvider(ServiceProvider):
        def register(self) -> None:
            providers.append(self)

    app.register(CapturingProvider)
    assert len(providers) == 1
    assert providers[0].app is app


def test_register_calls_register_immediately():
    app = Application()
    TrackingProvider.calls = []
    app.register(TrackingProvider)
    assert "register" in TrackingProvider.calls


def test_register_does_not_call_boot_immediately():
    app = Application()
    TrackingProvider.calls = []
    app.register(TrackingProvider)
    assert "boot" not in TrackingProvider.calls


def test_boot_calls_boot_on_all_providers():
    app = Application()
    TrackingProvider.calls = []
    app.register(TrackingProvider)
    app.boot()
    assert "boot" in TrackingProvider.calls


def test_boot_calls_providers_in_registration_order():
    order = []

    class FirstProvider(ServiceProvider):
        def boot(self) -> None:
            order.append("first")

    class SecondProvider(ServiceProvider):
        def boot(self) -> None:
            order.append("second")

    class ThirdProvider(ServiceProvider):
        def boot(self) -> None:
            order.append("third")

    app = Application()
    app.register(FirstProvider)
    app.register(SecondProvider)
    app.register(ThirdProvider)
    app.boot()
    assert order == ["first", "second", "third"]


def test_provider_can_bind_in_register():
    app = Application()
    app.register(RegisteringProvider)
    svc = app.make(SimpleService)
    assert isinstance(svc, SimpleService)


def test_provider_boot_can_resolve_bindings_from_other_providers():
    app = Application()
    BootResolvingProvider.resolved = []
    app.register(RegisteringProvider)
    app.register(BootResolvingProvider)
    app.boot()
    assert len(BootResolvingProvider.resolved) == 1
    assert isinstance(BootResolvingProvider.resolved[0], SimpleService)


def test_provider_register_reads_config():
    app = Application()
    app.configure({"app": {"name": "my-app"}})
    app.register(ConfigReadingProvider)
    assert ConfigReadingProvider.name == "my-app"


def test_provider_boot_can_access_event_dispatcher():
    app = Application()
    app.register(EventRegisteringProvider)
    app.boot()  # Should not raise


def test_multiple_providers_no_conflict():
    app = Application()

    class ProviderA(ServiceProvider):
        def register(self) -> None:
            self.app.container.singleton("service_a", lambda c: object())

    class ProviderB(ServiceProvider):
        def register(self) -> None:
            self.app.container.singleton("service_b", lambda c: object())

    app.register(ProviderA)
    app.register(ProviderB)
    app.boot()
    assert app.make("service_a") is not None
    assert app.make("service_b") is not None


def test_provider_self_app_is_application():
    app = Application()

    captured = []

    class CapturingProvider(ServiceProvider):
        def register(self) -> None:
            captured.append(self.app)

    app.register(CapturingProvider)
    assert captured[0] is app
