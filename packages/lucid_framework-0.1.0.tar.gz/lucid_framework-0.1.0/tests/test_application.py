"""Tests for Application lifecycle."""
import pytest

from lucid import Application
from lucid_container import Container
from lucid_config import Config
from lucid_events import Dispatcher


def test_application_creates_container():
    app = Application()
    assert isinstance(app.container, Container)


def test_application_creates_config():
    app = Application()
    assert isinstance(app.config, Config)


def test_application_creates_dispatcher():
    app = Application()
    assert isinstance(app.events, Dispatcher)


def test_is_booted_false_before_boot():
    app = Application()
    assert app.is_booted is False


def test_is_booted_true_after_boot():
    app = Application()
    app.boot()
    assert app.is_booted is True


def test_boot_called_twice_is_idempotent():
    app = Application()
    app.boot()
    app.boot()  # Should not raise or change state
    assert app.is_booted is True


def test_boot_twice_does_not_re_dispatch_events():
    app = Application()
    from lucid.events import AppBooted

    calls = []
    app.events.listen(AppBooted, lambda e: calls.append(1))
    app.boot()
    app.boot()
    assert len(calls) == 1
