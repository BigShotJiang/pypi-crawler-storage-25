"""Tests for AppBooting and AppBooted lifecycle events."""
import pytest

from lucid import Application
from lucid.events import AppBooting, AppBooted


def test_app_booting_dispatched_before_providers_boot():
    order = []

    class TrackingProvider:
        def __init__(self, app):
            self.app = app

        def register(self):
            pass

        def boot(self):
            order.append("provider_boot")

    app = Application()
    app.events.listen(AppBooting, lambda e: order.append("booting"))
    app.register(TrackingProvider)
    app.boot()
    assert order.index("booting") < order.index("provider_boot")


def test_app_booted_dispatched_after_providers_boot():
    order = []

    class TrackingProvider:
        def __init__(self, app):
            self.app = app

        def register(self):
            pass

        def boot(self):
            order.append("provider_boot")

    app = Application()
    app.events.listen(AppBooted, lambda e: order.append("booted"))
    app.register(TrackingProvider)
    app.boot()
    assert order.index("provider_boot") < order.index("booted")


def test_app_booting_carries_app_reference():
    app = Application()
    captured = []
    app.events.listen(AppBooting, lambda e: captured.append(e.app))
    app.boot()
    assert captured[0] is app


def test_app_booted_carries_app_reference():
    app = Application()
    captured = []
    app.events.listen(AppBooted, lambda e: captured.append(e.app))
    app.boot()
    assert captured[0] is app


def test_listeners_registered_before_boot_receive_events():
    app = Application()
    received = []
    app.events.listen(AppBooted, lambda e: received.append(True))
    app.boot()
    assert received == [True]


def test_app_booting_fires_before_app_booted():
    order = []
    app = Application()
    app.events.listen(AppBooting, lambda e: order.append("booting"))
    app.events.listen(AppBooted, lambda e: order.append("booted"))
    app.boot()
    assert order == ["booting", "booted"]


def test_events_not_fired_on_second_boot():
    app = Application()
    count = []
    app.events.listen(AppBooted, lambda e: count.append(1))
    app.boot()
    app.boot()
    assert len(count) == 1


def test_listen_decorator_form():
    """README shows @app.events.listen(EventType) as a decorator."""
    app = Application()
    received = []

    @app.events.listen(AppBooted)
    def on_booted(event):
        received.append(event)

    app.boot()
    assert len(received) == 1
    assert received[0].app is app


def test_listen_decorator_with_priority():
    """Higher-priority listeners run first regardless of registration order."""
    order = []
    app = Application()

    @app.events.listen(AppBooted, priority=0)
    def low(event):
        order.append("low")

    @app.events.listen(AppBooted, priority=10)
    def high(event):
        order.append("high")

    app.boot()
    assert order == ["high", "low"]
