import os
import gc

from types import SimpleNamespace

from huggingface_hub import (
    hf_hub_download,
    list_repo_files
)

from llama_cpp import Llama

from llama_cpp.llama_chat_format import (
    Llava15ChatHandler
)

# 共有
from ..media_normalizer import MediaNormalizer
from ..message_adapter import MessageAdapter


# =========================================================
# llama.cpp Interface
# =========================================================

class LlamaCppLLM:

    # -----------------------------------------------------
    def __init__(
        self,
        model_path: str,
        filename: str = None,
        use_vision: bool = False,
        mmproj_path: str = None,
        mmproj_filename: str = (
            "mmproj-model-f16.gguf"
        ),
        temp: float = 0.7,
        top_p: float = 0.95,
        top_k: int = 40,
        max_tokens: int = 4096,
        n_ctx: int = 40960,
        n_gpu_layers: int = -1,
        keep_alive: bool = False,
        verbose: bool = False,
    ):

        self.model_path_input = model_path
        self.filename = filename

        self.use_vision = use_vision
        self.mmproj_path = mmproj_path
        self.mmproj_filename = mmproj_filename

        self.temp = temp
        self.top_p = top_p
        self.top_k = top_k
        self.max_tokens = max_tokens
        self.n_ctx = n_ctx

        self.n_gpu_layers = n_gpu_layers

        self.keep_alive = keep_alive
        self.verbose = verbose

        self.model = None

        # resolve model
        self.model_path = self._resolve_model_path(
            model_path,
            filename
        )

        # resolve mmproj
        if self.use_vision and self.mmproj_path:

            self.mmproj_path = (
                self._resolve_model_path(
                    self.mmproj_path,
                    self.mmproj_filename
                )
            )

    # -----------------------------------------------------
    def _resolve_model_path(self,path_or_repo,filename=None):

        # local file
        if os.path.isfile(path_or_repo):
            return path_or_repo

        # local folder
        if os.path.isdir(path_or_repo):
            keyword = (filename or ".gguf").replace("*", "").lower()

            for f in os.listdir(path_or_repo):
                if (f.endswith(".gguf") and keyword in f.lower()):
                    return os.path.join(path_or_repo,f)

            raise ValueError("GGUF not found.")

        # HF repo
        files = list_repo_files(path_or_repo)

        preferred_quants = [
            "Q4_K_M",
            "Q5_K_M",
            "Q8_0",
        ]

        target = None

        # filename search
        if filename:
            keyword = (filename.replace("*", "").lower())
            for f in files:
                if (f.endswith(".gguf") and keyword in f.lower()):
                    target = f
                    break

        # auto quant
        if target is None:
            for quant in preferred_quants:
                for f in files:
                    if (f.endswith(".gguf") and quant.lower() in f.lower()):
                        target = f
                        break

                if target:
                    break

        if target is None:
            raise ValueError("Suitable GGUF not found.")

        print(f"Loading: {target}")

        return hf_hub_download(
            repo_id=path_or_repo,
            filename=target
        )

    # -----------------------------------------------------
    def _load_model(self):

        if self.model is not None:
            return

        chat_handler = None

        if self.use_vision:
            if not self.mmproj_path:
                raise ValueError("mmproj required.")

            chat_handler = Llava15ChatHandler(
                clip_model_path=self.mmproj_path
            )

        self.model = Llama(
            model_path=self.model_path,
            n_ctx=self.n_ctx,
            n_gpu_layers=self.n_gpu_layers,
            chat_handler=chat_handler,
            logits_all=False,
            embedding=False,
            use_mmap=True,
            use_mlock=False,
            verbose=self.verbose,
        )

    # -----------------------------------------------------
    def _free_model(self):
        self.model = None
        gc.collect()

    # -----------------------------------------------------
    # high-level API
    # -----------------------------------------------------
    def respond(
        self,
        user_text: str,
        media=None,
        system_prompt=None,
        history=None,
        stream=False,
    ):

        messages = []

        # system
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })

        # history
        if history:
            messages.extend(history)

        # normalize media
        frames = MediaNormalizer.normalize(media)

        # build content
        content = []

        content.append({
            "type": "text",
            "text": user_text
        })

        for frame in frames:
            content.append({
                "type": "media",
                "media": frame
            })

        messages.append({
            "role": "user",
            "content": content
        })

        # generate
        yield from self.generate(
            messages=messages,
            stream=stream
        )

    # -----------------------------------------------------
    # low-level API
    # -----------------------------------------------------
    def generate(self, messages, stream=False):

        self._load_model()

        try:
            llama_messages = (
                MessageAdapter.to_llama_cpp(
                    messages
                )
            )

            response = (
                self.model.create_chat_completion(
                    messages=llama_messages,
                    temperature=self.temp,
                    top_p=self.top_p,
                    top_k=self.top_k,
                    max_tokens=self.max_tokens,
                    stream=stream,
                )
            )

            # stream
            if stream:
                for chunk in response:
                    delta = (chunk["choices"][0].get("delta", {}))
                    text = delta.get("content")

                    if text:
                        yield SimpleNamespace(text=text)

            # non-stream
            else:
                text = (response["choices"][0]["message"]["content"])
                yield SimpleNamespace(text=text)

        finally:
            if not self.keep_alive:
                self._free_model()