
import base64

from io import BytesIO

# =========================================================
# Message Adapter
# =========================================================

class MessageAdapter:

    # -----------------------------------------------------
    @staticmethod
    def pil_to_base64(image):

        buffer = BytesIO()

        image.save(buffer, format="JPEG")

        encoded = base64.b64encode(
            buffer.getvalue()
        ).decode("utf-8")

        return f"data:image/jpeg;base64,{encoded}"

    # -----------------------------------------------------
    @classmethod
    def to_llama_cpp(
        cls,
        messages
    ):

        converted = []

        for msg in messages:

            role = msg["role"]

            content = msg["content"]

            # text only
            if isinstance(content, str):

                converted.append({
                    "role": role,
                    "content": content
                })

                continue

            new_content = []

            for item in content:

                # text
                if item["type"] == "text":

                    new_content.append({
                        "type": "text",
                        "text": item["text"]
                    })

                # media
                elif item["type"] == "media":

                    image = item["media"]

                    image_url = cls.pil_to_base64(image)

                    new_content.append({
                        "type": "image_url",
                        "image_url": {
                            "url": image_url
                        }
                    })

            converted.append({
                "role": role,
                "content": new_content
            })

        return converted