
import os
import base64
from io import BytesIO

from PIL import Image

import imageio.v3 as iio

# =========================================================
# Media Normalizer
# =========================================================

class MediaNormalizer:

    # -----------------------------------------------------
    @staticmethod
    def normalize(media_input):

        if media_input is None:
            return []

        # single -> list
        if not isinstance(media_input, list):
            media_input = [media_input]

        normalized_frames = []

        for item in media_input:

            frames = MediaNormalizer._to_frames(item)

            normalized_frames.extend(frames)

        return normalized_frames

    # -----------------------------------------------------
    @staticmethod
    def _to_frames(media):

        # PIL Image
        if isinstance(media, Image.Image):

            return [media.convert("RGB")]

        # bytes
        if isinstance(media, bytes):

            img = Image.open(
                BytesIO(media)
            ).convert("RGB")

            return [img]

        # string
        if isinstance(media, str):

            # local path
            if os.path.exists(media):

                ext = os.path.splitext(media)[1].lower()

                # image
                if ext in [
                    ".jpg",
                    ".jpeg",
                    ".png",
                    ".webp",
                    ".bmp"
                ]:

                    img = Image.open(media).convert("RGB")

                    return [img]

                # gif
                if ext == ".gif":

                    return MediaNormalizer._load_gif(media)

                # video
                if ext in [
                    ".mp4",
                    ".mov",
                    ".avi",
                    ".mkv"
                ]:

                    return MediaNormalizer._load_video(media)

            # base64 image
            if media.startswith("data:image"):

                encoded = media.split(",")[1]

                data = base64.b64decode(encoded)

                img = Image.open(
                    BytesIO(data)
                ).convert("RGB")

                return [img]

        raise ValueError(
            f"Unsupported media: {type(media)}"
        )

    # -----------------------------------------------------
    @staticmethod
    def _load_gif(path):

        gif = Image.open(path)

        frames = []

        try:

            while True:

                frame = gif.copy().convert("RGB")

                frames.append(frame)

                gif.seek(gif.tell() + 1)

        except EOFError:
            pass

        return frames

    # -----------------------------------------------------
    @staticmethod
    def _load_video(
        path,
        sample_every_sec=1
    ):

        frames = []

        meta = iio.immeta(path)

        fps = meta.get("fps", 30)

        step = max(
            int(fps * sample_every_sec),
            1
        )

        video = iio.imiter(path)

        for idx, frame in enumerate(video):

            if idx % step != 0:
                continue

            pil = Image.fromarray(frame).convert("RGB")

            frames.append(pil)

        return frames