"""LangGraph runtime — dual-mode executor with state persistence."""

import asyncio
import logging
from typing import Any, Dict, Optional

from .state import GraphState, add_error, create_initial_state

logger = logging.getLogger(__name__)

try:
    from langgraph.graph import StateGraph
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False

_STATE_STORE: Dict[str, GraphState] = {}


class GraphRuntime:
    """Execute LangGraph flows with automatic fallback to direct runners."""

    def __init__(self, timeout_seconds: int = 60):
        self.timeout_seconds = timeout_seconds
        self._graphs = {}
        self._direct_runners = {}

    def register_graph(self, name: str, graph=None, direct_runner=None):
        if graph is not None:
            self._graphs[name] = graph
        if direct_runner is not None:
            self._direct_runners[name] = direct_runner

    @property
    def langgraph_available(self) -> bool:
        return LANGGRAPH_AVAILABLE

    async def run(self, graph_name: str, inputs: Dict[str, Any], trace_id: str = None, timeout: int = None) -> Dict[str, Any]:
        timeout = timeout or self.timeout_seconds
        state = create_initial_state(goal=graph_name, inputs=inputs, trace_id=trace_id)
        _STATE_STORE[state["trace_id"]] = state

        try:
            graph = self._graphs.get(graph_name)
            direct_runner = self._direct_runners.get(graph_name)

            if graph is None and direct_runner is None:
                return {"ok": False, "type": graph_name, "data": None, "error": f"Unknown graph: {graph_name}", "trace": state["trace_id"]}

            if graph is not None and LANGGRAPH_AVAILABLE:
                final_state = await asyncio.wait_for(asyncio.to_thread(graph.invoke, state), timeout=timeout)
            elif direct_runner is not None:
                final_state = await asyncio.wait_for(direct_runner(state), timeout=timeout)
            else:
                return {"ok": False, "type": graph_name, "data": None, "error": "No execution method", "trace": state["trace_id"]}

            _STATE_STORE[state["trace_id"]] = final_state
            outputs = final_state.get("outputs", {})
            if "ok" in outputs:
                return outputs
            return {
                "ok": len(final_state.get("errors", [])) == 0,
                "type": graph_name,
                "data": outputs,
                "error": final_state.get("errors", [])[-1].get("error") if final_state.get("errors") else None,
                "trace": state["trace_id"],
            }
        except asyncio.TimeoutError:
            add_error(state, f"Timed out after {timeout}s", recoverable=False)
            return {"ok": False, "type": graph_name, "data": None, "error": f"Timed out after {timeout}s", "trace": state["trace_id"]}
        except Exception as e:
            add_error(state, str(e), recoverable=False)
            return {"ok": False, "type": graph_name, "data": None, "error": str(e), "trace": state["trace_id"]}

    def get_state(self, trace_id: str) -> Optional[GraphState]:
        return _STATE_STORE.get(trace_id)

    def list_traces(self, limit: int = 100) -> list:
        return list(_STATE_STORE.keys())[-limit:]


_runtime: Optional[GraphRuntime] = None


def get_runtime() -> GraphRuntime:
    global _runtime
    if _runtime is None:
        _runtime = GraphRuntime()
    return _runtime


async def run_graph(graph_name: str, inputs: Dict[str, Any], trace_id: str = None, timeout: int = None) -> Dict[str, Any]:
    return await get_runtime().run(graph_name, inputs, trace_id, timeout)
