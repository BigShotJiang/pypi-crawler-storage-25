"""Unified state for all LangGraph flows."""

import time
import uuid
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

try:
    from typing import TypedDict
except ImportError:
    from typing_extensions import TypedDict


class BudgetConfig(TypedDict, total=False):
    retrieval: float
    rerank: float
    synthesis: float
    total: float


class IndexStatus(TypedDict, total=False):
    state: str  # FRESH | STALE | MISSING
    last_indexed_at: str
    sources: List[Dict[str, Any]]
    mapped_tests_count: int
    gaps_count: int


class TriageResult(TypedDict, total=False):
    test_id: str
    title: str
    journey: str
    status: str  # KEEP | UPDATE | RETIRE | NEW | UNKNOWN
    reason: str
    citations: List[Dict[str, Any]]
    confidence: float


class PrioritizationScore(TypedDict, total=False):
    item: str
    score: int
    priority: str  # P0 | P1 | P2
    business_criticality: int
    change_impact: int
    why: str


class DecisionCard(TypedDict, total=False):
    decision: str
    why: str
    evidence: List[Dict[str, Any]]
    action: str
    owner_suggestion: str
    confidence: float


class GraphState(TypedDict, total=False):
    trace_id: str
    goal: str
    mode: str
    inputs: Dict[str, Any]
    outputs: Dict[str, Any]
    query: str
    budgets: BudgetConfig
    timers: Dict[str, float]
    start_time: float
    latency_ms: float
    context: Dict[str, Any]
    evidence: List[Dict[str, Any]]
    sources: List[Dict[str, Any]]
    index_status: IndexStatus
    decisions: List[Dict[str, Any]]
    confidence_score: float
    model_used: str
    fallback_used: bool
    errors: List[Dict[str, Any]]
    timestamps: Dict[str, str]
    current_step: str
    step_results: List[Dict[str, Any]]
    retry_count: int
    max_retries: int
    should_continue: bool
    budget_exceeded: bool
    # RAG-specific
    query_expansions: List[str]
    retrieved_chunks: List[Dict[str, Any]]
    answer: str
    citations: List[Dict[str, Any]]
    verification_status: str
    # API-specific
    workflow_name: str
    workflow_steps: List[Dict[str, Any]]
    current_step_index: int
    step_variables: Dict[str, Any]
    # Migration-specific
    source_docs: List[Dict[str, Any]]
    triage_results: List[TriageResult]
    triage_summary: Dict[str, int]
    golden_pack: Dict[str, List[str]]
    decision_cards: List[DecisionCard]
    leadership_summary: Dict[str, Any]
    readiness_status: str
    top_risks: List[Dict[str, Any]]
    next_actions: List[Dict[str, Any]]


def create_initial_state(goal: str, inputs: Dict[str, Any] = None, trace_id: str = None, mode: str = "rag") -> GraphState:
    now = datetime.utcnow().isoformat()
    return GraphState(
        trace_id=trace_id or f"trace_{uuid.uuid4().hex[:12]}",
        goal=goal,
        mode=mode,
        inputs=inputs or {},
        outputs={},
        query=inputs.get("query", "") if inputs else "",
        budgets=BudgetConfig(retrieval=1.5, rerank=1.0, synthesis=5.0, total=10.0),
        timers={},
        start_time=time.time(),
        latency_ms=0,
        context={},
        evidence=[],
        sources=[],
        decisions=[],
        confidence_score=0.0,
        model_used="",
        fallback_used=False,
        errors=[],
        timestamps={"created": now, "updated": now},
        current_step="init",
        step_results=[],
        retry_count=0,
        max_retries=2,
        should_continue=True,
        budget_exceeded=False,
        query_expansions=[],
        retrieved_chunks=[],
        answer="",
        citations=[],
        verification_status="",
        triage_results=[],
        triage_summary={},
        golden_pack={},
        decision_cards=[],
        leadership_summary={},
        readiness_status="",
        top_risks=[],
        next_actions=[],
    )


def add_decision(state: GraphState, decision: str, reason: str, data: Any = None) -> GraphState:
    state["decisions"].append({
        "timestamp": datetime.utcnow().isoformat(),
        "step": state.get("current_step", "unknown"),
        "decision": decision,
        "reason": reason,
        "data": data,
    })
    state["timestamps"]["updated"] = datetime.utcnow().isoformat()
    return state


def add_error(state: GraphState, error: str, step: str = None, recoverable: bool = True) -> GraphState:
    state["errors"].append({
        "timestamp": datetime.utcnow().isoformat(),
        "step": step or state.get("current_step", "unknown"),
        "error": error,
        "recoverable": recoverable,
    })
    state["timestamps"]["updated"] = datetime.utcnow().isoformat()
    return state
