import importlib
import logging
from importlib.metadata import entry_points
from typing import Dict, List

from ..agents.base_agent import BaseAgent
from .registry import agent_registry

logger = logging.getLogger(__name__)


def discover_agents(group: str = "flowpilot.agents") -> List[str]:
    """Auto-discover agents registered via entry_points in installed packages.

    Packages register agents in their pyproject.toml:
        [project.entry-points."flowpilot.agents"]
        my_agent = "my_package.agent:MyAgent"
    """
    discovered = []
    try:
        eps = entry_points()
        agent_eps = eps.get(group, []) if isinstance(eps, dict) else eps.select(group=group)
        for ep in agent_eps:
            try:
                agent_cls = ep.load()
                if isinstance(agent_cls, type) and issubclass(agent_cls, BaseAgent):
                    instance = agent_cls.__new__(agent_cls)
                    name = getattr(instance, "name", ep.name) if hasattr(agent_cls, "name") else ep.name
                    logger.info("Discovered agent '%s' from %s", name, ep.value)
                    discovered.append(name)
            except Exception as exc:
                logger.warning("Failed to load agent '%s': %s", ep.name, exc)
    except Exception as exc:
        logger.debug("Entry point discovery failed: %s", exc)
    return discovered
