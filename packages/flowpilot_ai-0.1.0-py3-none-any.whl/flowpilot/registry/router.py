import logging
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class EnterpriseRouter:
    """Routes incoming messages to the appropriate agent handler."""

    def __init__(self):
        self._routes: Dict[str, Callable] = {}

    def register(self, mode: str, handler: Callable) -> None:
        self._routes[mode] = handler
        logger.info("EnterpriseRouter: registered agent '%s'", mode)

    def get(self, mode: str) -> Optional[Callable]:
        return self._routes.get(mode)

    def list_agents(self) -> List[str]:
        return list(self._routes.keys())

    def route(self, mode: str, message: str = "") -> Optional[Callable]:
        fn = self._routes.get(mode)
        if fn is None:
            logger.warning(
                "EnterpriseRouter: no handler for mode='%s', falling back to chat",
                mode,
            )
        return fn


def build_router() -> EnterpriseRouter:
    """Wire all agents into the router. Called once at startup."""
    router = EnterpriseRouter()
    return router
