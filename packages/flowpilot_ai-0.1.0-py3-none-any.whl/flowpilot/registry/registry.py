import logging
from typing import Any, Dict, List, Optional

from ..agents.base_agent import BaseAgent
from ..tools.base_tool import BaseTool

logger = logging.getLogger(__name__)


class AgentRegistry:
    """Dict-backed registry mapping agent names to instances."""

    def __init__(self):
        self._agents: Dict[str, BaseAgent] = {}

    def register(self, name: str, agent: BaseAgent) -> None:
        self._agents[name] = agent
        logger.info("AgentRegistry: registered '%s'", name)

    def get(self, name: str) -> Optional[BaseAgent]:
        return self._agents.get(name)

    def list_agents(self) -> List[str]:
        return list(self._agents.keys())

    def unregister(self, name: str) -> bool:
        if name in self._agents:
            del self._agents[name]
            logger.info("AgentRegistry: unregistered '%s'", name)
            return True
        return False

    async def health_summary(self) -> Dict[str, Dict]:
        results = {}
        for name, agent in self._agents.items():
            try:
                results[name] = await agent.health_check()
            except Exception as exc:
                results[name] = {"status": "error", "error": str(exc)}
        return results


class ToolRegistry:
    """Dict-backed registry mapping tool names to instances."""

    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}

    def register(self, name: str, tool: BaseTool) -> None:
        self._tools[name] = tool
        logger.info("ToolRegistry: registered '%s'", name)

    def get(self, name: str) -> Optional[BaseTool]:
        return self._tools.get(name)

    def list_tools(self) -> List[str]:
        return list(self._tools.keys())

    def unregister(self, name: str) -> bool:
        if name in self._tools:
            del self._tools[name]
            return True
        return False


# Singletons
agent_registry = AgentRegistry()
tool_registry = ToolRegistry()
