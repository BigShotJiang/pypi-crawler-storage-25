"""Conversation service — session-based chat history."""

import logging
import time
from collections import OrderedDict
from typing import Dict, List

logger = logging.getLogger(__name__)


class ConversationService:
    _cache: OrderedDict = OrderedDict()
    _MAX_CACHED_SESSIONS = 1000
    _MAX_MESSAGES = 30
    _SESSION_TTL = 7200

    @staticmethod
    def add_user_message(session_id: str, message: str, tenant_id: str = None):
        ConversationService._ensure_session(session_id)
        ConversationService._cache[session_id]["messages"].append(
            {"role": "user", "content": message, "timestamp": time.time()}
        )
        ConversationService._trim(session_id)

    @staticmethod
    def add_assistant_message(session_id: str, message: str, tenant_id: str = None):
        ConversationService._ensure_session(session_id)
        ConversationService._cache[session_id]["messages"].append(
            {"role": "assistant", "content": message, "timestamp": time.time()}
        )
        ConversationService._trim(session_id)

    @staticmethod
    def get_history(session_id: str, last_n: int = 8) -> List[Dict[str, str]]:
        if session_id not in ConversationService._cache:
            return []
        msgs = ConversationService._cache[session_id]["messages"]
        return [{"role": m["role"], "content": m["content"]} for m in msgs[-last_n:]]

    @staticmethod
    def _ensure_session(session_id: str):
        if session_id not in ConversationService._cache:
            ConversationService._cache[session_id] = {"messages": [], "created": time.time()}
            if len(ConversationService._cache) > ConversationService._MAX_CACHED_SESSIONS:
                ConversationService._cache.popitem(last=False)

    @staticmethod
    def _trim(session_id: str):
        msgs = ConversationService._cache[session_id]["messages"]
        if len(msgs) > ConversationService._MAX_MESSAGES:
            ConversationService._cache[session_id]["messages"] = msgs[-ConversationService._MAX_MESSAGES:]
