"""Embedding service using sentence-transformers."""

import logging
import os
import threading
from typing import Any, List, Optional

logger = logging.getLogger(__name__)

_model = None
_model_lock = threading.Lock()


def get_embedding_model(model_name: str = None):
    """Get or create the global embedding model instance."""
    global _model
    if _model is not None:
        return _model

    with _model_lock:
        if _model is not None:
            return _model
        name = model_name or os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
        try:
            from sentence_transformers import SentenceTransformer
            _model = SentenceTransformer(name)
            logger.info("Loaded embedding model: %s", name)
        except Exception as exc:
            logger.warning("Failed to load embedding model: %s", exc)
            _model = None
    return _model


def embed_texts(texts: List[str], model_name: str = None) -> Optional[List[List[float]]]:
    """Embed a list of texts. Returns list of vectors or None."""
    model = get_embedding_model(model_name)
    if model is None:
        return None
    try:
        embeddings = model.encode(texts, show_progress_bar=False)
        return embeddings.tolist()
    except Exception as exc:
        logger.error("Embedding failed: %s", exc)
        return None
