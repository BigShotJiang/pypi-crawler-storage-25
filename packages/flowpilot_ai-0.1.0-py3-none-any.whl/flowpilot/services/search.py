"""OpenSearch integration service."""

import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_client = None


def _get_client():
    global _client
    if _client is not None:
        return _client
    try:
        from opensearchpy import OpenSearch
        url = os.getenv("OPENSEARCH_URL", "http://localhost:9200")
        _client = OpenSearch(
            hosts=[url],
            http_auth=(os.getenv("OPENSEARCH_USER", ""), os.getenv("OPENSEARCH_PASSWORD", "")),
            use_ssl=url.startswith("https"),
            verify_certs=False,
        )
    except Exception as exc:
        logger.warning("OpenSearch not available: %s", exc)
    return _client


class SearchService:
    @staticmethod
    def index_document(index: str, doc_id: str, body: Dict) -> bool:
        client = _get_client()
        if not client:
            return False
        try:
            client.index(index=index, id=doc_id, body=body)
            return True
        except Exception as exc:
            logger.error("Index failed: %s", exc)
            return False

    @staticmethod
    def search(index: str, query: Dict, size: int = 10) -> List[Dict]:
        client = _get_client()
        if not client:
            return []
        try:
            resp = client.search(index=index, body=query, size=size)
            return [hit["_source"] for hit in resp.get("hits", {}).get("hits", [])]
        except Exception:
            return []

    @staticmethod
    def index_prompt(prompt_id: str, data: Dict):
        SearchService.index_document("prompts", prompt_id, data)
