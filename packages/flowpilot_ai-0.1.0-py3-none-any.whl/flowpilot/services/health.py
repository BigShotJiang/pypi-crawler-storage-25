"""Health service — component health checks and latency tracking."""

import logging
import time
from collections import deque
from datetime import datetime
from typing import Any, Dict

logger = logging.getLogger(__name__)

_start_time = time.time()
_latency_window: deque = deque(maxlen=1000)
_error_counts: Dict[str, int] = {}


def record_latency(latency_ms: float, endpoint: str = "chat"):
    _latency_window.append({"latency": latency_ms, "endpoint": endpoint, "ts": time.time()})


def record_error(endpoint: str = "chat", error_type: str = "unknown"):
    key = f"{endpoint}:{error_type}"
    _error_counts[key] = _error_counts.get(key, 0) + 1


class HealthService:
    @staticmethod
    def get_uptime() -> Dict[str, Any]:
        uptime = time.time() - _start_time
        return {
            "status": "ok",
            "uptime_seconds": round(uptime, 2),
            "started_at": datetime.fromtimestamp(_start_time).isoformat(),
        }

    @staticmethod
    def get_realtime_latency() -> Dict[str, Any]:
        if not _latency_window:
            return {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "count": 0}
        latencies = sorted([e["latency"] for e in _latency_window])
        n = len(latencies)
        return {
            "avg_ms": round(sum(latencies) / n, 2),
            "p50_ms": round(latencies[int(n * 0.5)], 2),
            "p95_ms": round(latencies[int(n * 0.95)], 2),
            "p99_ms": round(latencies[min(int(n * 0.99), n - 1)], 2),
            "count": n,
        }

    @staticmethod
    def get_error_rate() -> Dict[str, Any]:
        return {"errors": dict(_error_counts), "total": sum(_error_counts.values())}
