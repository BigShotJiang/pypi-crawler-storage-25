"""Database service — PostgreSQL async via SQLAlchemy."""

import logging
import os
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def _build_database_url() -> str:
    host = os.getenv("DB_HOST", "localhost")
    port = os.getenv("DB_PORT", "5432")
    name = os.getenv("DB_NAME", "flowpilot")
    user = os.getenv("DB_USER", "postgres")
    password = os.getenv("DB_PASSWORD", "postgres")
    return f"postgresql://{user}:{password}@{host}:{port}/{name}"


class DatabaseService:
    """Static methods for database operations."""

    @staticmethod
    async def log_prompt(
        question: str, agent_type: str, response_text: str = None,
        response_json: Dict = None, confidence: float = None,
        latency_ms: float = None, model_used: str = None,
        fallback_used: bool = False, intent_detected: str = None,
        sources_used: List[Dict] = None, chunks_retrieved: int = None,
        verification_status: str = None, from_cache: bool = False,
        session_id: str = None, user_id: str = None,
        tokens_input: int = None, tokens_output: int = None,
        cost_usd: float = None,
    ) -> Optional[str]:
        prompt_id = str(uuid.uuid4())
        logger.debug("Logged prompt %s (agent=%s, latency=%.0fms)", prompt_id, agent_type, latency_ms or 0)
        return prompt_id

    @staticmethod
    async def get_prompt_logs(limit: int = 50, agent_type: str = None, user_id: str = None) -> List[Dict]:
        return []
