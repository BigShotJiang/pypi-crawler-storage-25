"""Multi-provider LLM service with automatic fallback chain."""

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import requests as _requests

logger = logging.getLogger(__name__)

PROVIDER_URLS = {
    "local": "http://localhost:1234/v1",
    "openrouter": "https://openrouter.ai/api/v1",
    "groq": "https://api.groq.com/openai/v1",
    "openai": "https://api.openai.com/v1",
    "anthropic": "https://api.anthropic.com/v1",
    "together": "https://api.together.xyz/v1",
}

DEFAULT_MODELS = {
    "local": "mistralai/ministral-3-3b",
    "openrouter": "openai/gpt-4o-mini",
    "groq": "llama-3.1-8b-instant",
    "openai": "gpt-4o-mini",
    "anthropic": "claude-3-haiku-20240307",
    "together": "meta-llama/Llama-3.3-70B-Instruct-Turbo",
}

API_KEY_ENV = {
    "openrouter": "OPENROUTER_API_KEY",
    "groq": "GROQ_API_KEY",
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "together": "TOGETHER_API_KEY",
}

FALLBACK_CONFIGS = [
    {"provider": "openai", "model": "gpt-4o-mini", "base_url": "https://api.openai.com/v1"},
    {"provider": "openai", "model": "gpt-4o", "base_url": "https://api.openai.com/v1"},
]

SLOW_LOCAL_MODELS = ["deepseek", "r1", "qwen", "70b", "32b"]


@dataclass
class LLMResponse:
    content: str = ""
    model: str = ""
    provider: str = ""
    usage: Optional[Dict] = None
    fallback_used: bool = False
    latency_ms: float = 0.0
    confidence_score: int = 100


class LLMClient:
    """Multi-provider LLM with configurable mode and auto-fallback."""

    def __init__(
        self,
        provider: str = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        temperature: float = None,
        max_tokens: int = None,
        timeout: int = None,
        enable_fallback: bool = True,
        try_local_first: bool = None,
    ):
        self.mode = os.getenv("LLM_MODE", "auto").lower()
        self.provider = (provider or os.getenv("LLM_PROVIDER", "openrouter")).lower()
        self.temperature = temperature if temperature is not None else float(os.getenv("LLM_TEMPERATURE", "0.3"))
        self.max_tokens = max_tokens if max_tokens is not None else int(os.getenv("LLM_MAX_TOKENS", "1000"))
        self.local_timeout = int(os.getenv("LLM_LOCAL_TIMEOUT", "5"))
        self.cloud_timeout = timeout if timeout is not None else int(os.getenv("LLM_CLOUD_TIMEOUT", "8"))
        self.enable_fallback = enable_fallback

        if try_local_first is not None:
            self.try_local_first = try_local_first
        else:
            self.try_local_first = self.mode == "auto"

        if self.mode == "local":
            self.provider = "local"
            self.try_local_first = False
            self.enable_fallback = False
        elif self.mode == "cloud":
            self.try_local_first = False

        if api_key:
            self.api_key = api_key
        else:
            env_key = API_KEY_ENV.get(self.provider)
            self.api_key = os.getenv(env_key) if env_key else None

        self.base_url = base_url or PROVIDER_URLS.get(self.provider, PROVIDER_URLS["openrouter"])
        env_model = os.getenv("LLM_MODEL", "").strip()
        self.model = model or env_model or DEFAULT_MODELS.get(self.provider, "gpt-4o-mini")

        self._request_count = 0
        self._fallback_count = 0

    def _get_headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.provider == "openrouter":
            headers["HTTP-Referer"] = "https://flowpilot.local"
            headers["X-Title"] = "FlowPilot"
        return headers

    def _get_endpoint(self) -> str:
        base = self.base_url.rstrip("/")
        if "/chat/completions" in base:
            return base
        return f"{base}/chat/completions"

    def chat(self, messages: List[Dict[str, str]], tools: Optional[List[Dict]] = None) -> LLMResponse:
        start = time.time()
        self._request_count += 1

        # Try local first
        if self.try_local_first and self.provider != "local":
            local_result = self._try_local(messages)
            if local_result and not local_result.content.startswith("Error:"):
                local_result.latency_ms = round((time.time() - start) * 1000, 2)
                return local_result

        # Primary provider
        result = self._call_provider(self.base_url, self.model, self._get_headers(), self.cloud_timeout, messages)
        if result:
            result.latency_ms = round((time.time() - start) * 1000, 2)
            return result

        # Fallback chain
        if self.enable_fallback:
            for fb in FALLBACK_CONFIGS:
                fb_key = os.getenv("OPENAI_API_KEY", "")
                if not fb_key:
                    continue
                fb_headers = {"Content-Type": "application/json", "Authorization": f"Bearer {fb_key}"}
                fb_result = self._call_provider(fb["base_url"], fb["model"], fb_headers, 30, messages)
                if fb_result:
                    self._fallback_count += 1
                    fb_result.fallback_used = True
                    fb_result.latency_ms = round((time.time() - start) * 1000, 2)
                    return fb_result

        return LLMResponse(content="Error: All providers failed", confidence_score=0)

    def _try_local(self, messages: List[Dict]) -> Optional[LLMResponse]:
        local_url = os.getenv("LOCAL_LLM_URL", "http://localhost:1234/v1/chat/completions")
        local_model = os.getenv("LOCAL_LLM_MODEL", "local-model")
        headers = {"Content-Type": "application/json"}
        return self._call_provider(local_url, local_model, headers, self.local_timeout, messages)

    def _call_provider(self, base_url: str, model: str, headers: Dict, timeout: int, messages: List[Dict]) -> Optional[LLMResponse]:
        endpoint = base_url.rstrip("/")
        if "/chat/completions" not in endpoint:
            endpoint += "/chat/completions"
        payload = {
            "model": model,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": min(self.max_tokens, 4000),
        }
        try:
            resp = _requests.post(endpoint, json=payload, headers=headers, timeout=timeout)
            if resp.status_code != 200:
                return None
            data = resp.json()
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            usage = data.get("usage")
            return LLMResponse(content=content, model=model, provider=self._detect_provider(base_url), usage=usage)
        except Exception:
            return None

    def _detect_provider(self, url: str) -> str:
        for name, base in PROVIDER_URLS.items():
            if base in url:
                return name
        return "unknown"

    @property
    def metrics(self) -> Dict[str, Any]:
        return {
            "requests": self._request_count,
            "fallbacks": self._fallback_count,
            "fallback_rate": round(self._fallback_count / max(self._request_count, 1), 4),
        }
