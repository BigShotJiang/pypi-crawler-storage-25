"""Prompt template registry."""

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

PROMPTS_DIR = Path(__file__).resolve().parents[3] / "prompts"
_FILE_PROMPTS: Dict[str, Dict[str, Any]] = {}
_loaded = False


def _load_prompt_files():
    global _loaded
    if _loaded:
        return
    if not PROMPTS_DIR.exists():
        _loaded = True
        return
    for md_file in PROMPTS_DIR.rglob("*.md"):
        key = md_file.stem
        _FILE_PROMPTS[key] = {
            "key": key,
            "content": md_file.read_text(encoding="utf-8"),
            "path": str(md_file),
        }
    _loaded = True
    logger.info("Loaded %d prompt templates from %s", len(_FILE_PROMPTS), PROMPTS_DIR)


def get_prompt(key: str, version: str = None) -> str:
    _load_prompt_files()
    entry = _FILE_PROMPTS.get(key)
    if entry:
        return entry["content"]
    return ""


def list_prompts() -> List[Dict[str, Any]]:
    _load_prompt_files()
    return [{"key": k, "path": v["path"]} for k, v in _FILE_PROMPTS.items()]
