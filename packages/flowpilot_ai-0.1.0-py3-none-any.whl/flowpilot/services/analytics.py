"""Analytics service — usage metrics collection."""

import logging
import os
import threading
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger(__name__)


class AnalyticsService:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self.metrics = {
            "total_queries": 0,
            "total_response_time": 0.0,
            "cache_hits": 0,
            "cache_misses": 0,
            "provider_usage": defaultdict(int),
            "agent_usage": defaultdict(int),
            "errors": 0,
            "session_start": datetime.utcnow().isoformat(),
        }

    def record_query(self, agent: str, provider: str, latency_ms: float, from_cache: bool = False):
        self.metrics["total_queries"] += 1
        self.metrics["total_response_time"] += latency_ms
        self.metrics["provider_usage"][provider] += 1
        self.metrics["agent_usage"][agent] += 1
        if from_cache:
            self.metrics["cache_hits"] += 1
        else:
            self.metrics["cache_misses"] += 1

    def record_error(self):
        self.metrics["errors"] += 1

    def get_summary(self) -> Dict[str, Any]:
        total = self.metrics["total_queries"]
        return {
            "total_queries": total,
            "avg_latency_ms": round(self.metrics["total_response_time"] / max(total, 1), 2),
            "cache_hit_rate": round(self.metrics["cache_hits"] / max(total, 1), 4),
            "error_rate": round(self.metrics["errors"] / max(total, 1), 4),
            "provider_usage": dict(self.metrics["provider_usage"]),
            "agent_usage": dict(self.metrics["agent_usage"]),
            "uptime_since": self.metrics["session_start"],
        }
