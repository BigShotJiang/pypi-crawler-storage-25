"""
FlowPilot — AI Agent Orchestration Framework
=============================================

A lightweight framework for building, orchestrating, and deploying
multi-agent AI systems with tool integration and RAG capabilities.

Quick start::

    from flowpilot import BaseAgent, AgentRequest, AgentResponse, AgentContract
    from flowpilot import tool, skill

    class MyAgent(BaseAgent):
        async def handle(self, request):
            return AgentResponse(answer="Hello!", confidence=0.9)

        async def health_check(self):
            return {"status": "ok"}
"""

from ._version import __version__

# --- Agent SDK ---
from .agents import BaseAgent, AgentRequest, AgentResponse, AgentContract

# --- Registry ---
from .registry import AgentRegistry, agent_registry, EnterpriseRouter

# --- Decorators ---
from .decorators import tool, skill, agent

# --- Tool SDK ---
from .tools import (
    BaseTool,
    ToolContract,
    ToolPermission,
    ToolRequest,
    ToolResponse,
    BashTool,
    GrepTool,
    GlobTool,
    FileReadTool,
    FileWriteTool,
    FileEditTool,
)

# --- Configuration ---
from .config import FlowPilotConfig, LLMConfig, LocalModelConfig, load_config

__all__ = [
    "__version__",
    # Agents
    "BaseAgent",
    "AgentRequest",
    "AgentResponse",
    "AgentContract",
    "AgentRegistry",
    "agent_registry",
    "EnterpriseRouter",
    # Decorators
    "tool",
    "skill",
    "agent",
    # Tools
    "BaseTool",
    "ToolContract",
    "ToolPermission",
    "ToolRequest",
    "ToolResponse",
    "BashTool",
    "GrepTool",
    "GlobTool",
    "FileReadTool",
    "FileWriteTool",
    "FileEditTool",
    # Config
    "FlowPilotConfig",
    "LLMConfig",
    "LocalModelConfig",
    "load_config",
]
