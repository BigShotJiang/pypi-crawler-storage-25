"""GrepTool — Ripgrep-powered content search.

Ported from claude-code GrepTool.ts. Searches file contents using
ripgrep with support for multiple output modes, context lines,
head limits, and file type filtering.
"""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base_tool import BaseTool, ToolContract, ToolPermission, ToolRequest, ToolResponse
from ._ripgrep import build_base_args, ripgrep_available, run_ripgrep

DEFAULT_HEAD_LIMIT = 250


class GrepTool(BaseTool):
    """Search file contents using ripgrep."""

    def __init__(self):
        super().__init__(
            ToolContract(
                name="grep",
                description="Search file contents using regex patterns",
                permission=ToolPermission.READ_ONLY,
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string"},
                        "path": {"type": "string"},
                        "glob": {"type": "string"},
                        "output_mode": {"type": "string", "enum": ["content", "files_with_matches", "count"]},
                        "-A": {"type": "integer"},
                        "-B": {"type": "integer"},
                        "-C": {"type": "integer"},
                        "-i": {"type": "boolean"},
                        "-n": {"type": "boolean"},
                        "type": {"type": "string"},
                        "head_limit": {"type": "integer"},
                        "offset": {"type": "integer"},
                        "multiline": {"type": "boolean"},
                    },
                    "required": ["pattern"],
                },
                is_read_only=True,
                is_concurrency_safe=True,
                max_result_size_chars=200_000,
            )
        )

    def validate(self, request: ToolRequest) -> Optional[str]:
        if not request.parameters.get("pattern"):
            return "Pattern cannot be empty"
        if not ripgrep_available():
            return "ripgrep (rg) is not installed"
        return None

    async def call(self, request: ToolRequest) -> ToolResponse:
        p = request.parameters
        args = build_base_args()

        if p.get("multiline"):
            args.extend(["-U", "--multiline-dotall"])
        if p.get("-i"):
            args.append("-i")

        mode = p.get("output_mode", "files_with_matches")
        if mode == "files_with_matches":
            args.append("-l")
        elif mode == "count":
            args.append("-c")

        if mode == "content" and p.get("-n", True):
            args.append("-n")

        # Context flags
        c_val = p.get("-C")
        if c_val is not None:
            args.extend(["-C", str(c_val)])
        else:
            b_val = p.get("-B")
            a_val = p.get("-A")
            if b_val is not None:
                args.extend(["-B", str(b_val)])
            if a_val is not None:
                args.extend(["-A", str(a_val)])

        if p.get("glob"):
            args.extend(["--glob", p["glob"]])
        if p.get("type"):
            args.extend(["--type", p["type"]])

        pattern = p["pattern"]
        if pattern.startswith("-"):
            args.extend(["-e", pattern])
        else:
            args.append(pattern)

        search_path = p.get("path", request.working_directory)
        args.append(search_path)

        lines, returncode = await run_ripgrep(args, cwd=request.working_directory)

        head_limit = p.get("head_limit", DEFAULT_HEAD_LIMIT)
        offset = p.get("offset", 0)

        if head_limit == 0:
            result_lines = lines[offset:]
            truncated = False
        else:
            result_lines = lines[offset : offset + head_limit]
            truncated = len(lines) - offset > head_limit

        # Relativize paths
        cwd = request.working_directory
        if cwd and not cwd.endswith("/"):
            cwd += "/"
        result_lines = [line.replace(cwd, "") for line in result_lines]

        if mode == "content":
            return ToolResponse(
                success=True,
                output={
                    "mode": "content",
                    "content": "\n".join(result_lines),
                    "num_lines": len(result_lines),
                    "truncated": truncated,
                },
            )
        elif mode == "count":
            total_matches = 0
            file_count = 0
            for line in result_lines:
                idx = line.rfind(":")
                if idx > 0:
                    try:
                        total_matches += int(line[idx + 1 :])
                        file_count += 1
                    except ValueError:
                        pass
            return ToolResponse(
                success=True,
                output={
                    "mode": "count",
                    "num_matches": total_matches,
                    "num_files": file_count,
                    "truncated": truncated,
                },
            )
        else:
            return ToolResponse(
                success=True,
                output={
                    "mode": "files_with_matches",
                    "filenames": result_lines,
                    "num_files": len(result_lines),
                    "truncated": truncated,
                },
            )
