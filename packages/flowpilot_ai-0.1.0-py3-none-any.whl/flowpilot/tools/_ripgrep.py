"""Low-level ripgrep subprocess wrapper."""

import asyncio
import shutil
from typing import List, Optional


def ripgrep_available() -> bool:
    """Check if ripgrep (rg) is installed."""
    return shutil.which("rg") is not None


async def run_ripgrep(
    args: List[str],
    cwd: str = ".",
    timeout: float = 30.0,
) -> tuple:
    """Execute ripgrep with given arguments.

    Returns:
        (stdout_lines, returncode)
    """
    proc = await asyncio.create_subprocess_exec(
        "rg",
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=cwd,
    )
    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=timeout
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        return [], -1

    lines = stdout.decode("utf-8", errors="replace").strip().split("\n")
    lines = [line for line in lines if line]
    return lines, proc.returncode


def build_base_args() -> List[str]:
    """Build standard ripgrep arguments with VCS exclusions."""
    args = ["--hidden"]
    for vcs_dir in [".git", ".svn", ".hg", ".bzr", ".jj", ".sl"]:
        args.extend(["--glob", f"!{vcs_dir}"])
    args.extend(["--max-columns", "500"])
    return args
