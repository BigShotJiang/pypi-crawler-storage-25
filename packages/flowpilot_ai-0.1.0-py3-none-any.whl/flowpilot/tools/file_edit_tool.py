"""FileEditTool — String replacement in files.

Ported from claude-code FileEditTool.ts. Performs exact string replacement
with uniqueness checking, quote normalization, and staleness detection.
"""

from pathlib import Path
from typing import Optional

from .base_tool import BaseTool, ToolContract, ToolPermission, ToolRequest, ToolResponse
from .file_read_tool import _read_state


def _find_actual_string(content: str, search: str) -> Optional[str]:
    """Find the actual string in content, handling curly quote normalization."""
    if search in content:
        return search

    # Normalize curly/smart quotes to straight quotes
    quote_map = {
        "\u2018": "'", "\u2019": "'",  # single curly
        "\u201c": '"', "\u201d": '"',  # double curly
    }
    normalized_search = search
    normalized_content = content
    for curly, straight in quote_map.items():
        normalized_search = normalized_search.replace(curly, straight)
        normalized_content = normalized_content.replace(curly, straight)

    idx = normalized_content.find(normalized_search)
    if idx != -1:
        return content[idx : idx + len(search)]
    return None


class FileEditTool(BaseTool):
    """Replace strings in files with uniqueness checking."""

    def __init__(self):
        super().__init__(
            ToolContract(
                name="file_edit",
                description="Replace a string in a file",
                permission=ToolPermission.READ_WRITE,
                input_schema={
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string"},
                        "old_string": {"type": "string"},
                        "new_string": {"type": "string"},
                        "replace_all": {"type": "boolean", "default": False},
                    },
                    "required": ["file_path", "old_string", "new_string"],
                },
                is_read_only=False,
                is_concurrency_safe=False,
            )
        )

    def validate(self, request: ToolRequest) -> Optional[str]:
        p = request.parameters
        if not p.get("file_path"):
            return "file_path is required"
        if "old_string" not in p:
            return "old_string is required"
        if "new_string" not in p:
            return "new_string is required"
        if p.get("old_string") == p.get("new_string"):
            return "old_string and new_string must be different"
        return None

    async def call(self, request: ToolRequest) -> ToolResponse:
        p = request.parameters
        file_path = p["file_path"]
        old_string = p["old_string"]
        new_string = p["new_string"]
        replace_all = p.get("replace_all", False)

        path = Path(file_path)
        if not path.exists():
            return ToolResponse(success=False, error=f"File not found: {file_path}")

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            return ToolResponse(success=False, error=f"Read failed: {exc}")

        # Staleness detection
        state = _read_state.get(file_path)
        if state:
            try:
                current_mtime = path.stat().st_mtime
                if current_mtime > state["mtime"]:
                    is_full_read = state.get("offset") is None or (
                        state.get("offset") == 0 and state.get("limit") is None
                    )
                    if not is_full_read or content != state["content"]:
                        return ToolResponse(
                            success=False,
                            error="File modified since last read. Read the file again before editing.",
                        )
            except OSError:
                pass

        # Find actual string (with quote normalization)
        actual = _find_actual_string(content, old_string)
        if actual is None:
            return ToolResponse(
                success=False,
                error="String to replace not found in file",
            )

        # Uniqueness check
        count = content.count(actual)
        if count > 1 and not replace_all:
            return ToolResponse(
                success=False,
                error=f"Found {count} matches. Use replace_all=True or provide more context to make it unique.",
            )

        # Apply replacement
        if replace_all:
            new_content = content.replace(actual, new_string)
        else:
            new_content = content.replace(actual, new_string, 1)

        # Write
        try:
            path.write_text(new_content, encoding="utf-8")
        except Exception as exc:
            return ToolResponse(success=False, error=f"Write failed: {exc}")

        # Update staleness state
        _read_state[file_path] = {
            "content": new_content,
            "mtime": path.stat().st_mtime,
            "offset": None,
            "limit": None,
        }

        return ToolResponse(
            success=True,
            output={
                "file_path": file_path,
                "replacements": count if replace_all else 1,
            },
        )
