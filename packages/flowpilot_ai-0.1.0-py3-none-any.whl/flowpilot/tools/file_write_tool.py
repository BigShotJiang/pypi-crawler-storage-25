"""FileWriteTool — File writing with staleness detection.

Ported from claude-code FileWriteTool.ts. Creates or overwrites files
with parent directory creation and staleness checks.
"""

from pathlib import Path
from typing import Optional

from .base_tool import BaseTool, ToolContract, ToolPermission, ToolRequest, ToolResponse
from .file_read_tool import _read_state


class FileWriteTool(BaseTool):
    """Write content to a file with staleness detection."""

    def __init__(self):
        super().__init__(
            ToolContract(
                name="file_write",
                description="Write content to a file (creates or overwrites)",
                permission=ToolPermission.READ_WRITE,
                input_schema={
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string", "description": "Absolute path to file"},
                        "content": {"type": "string", "description": "Full file content to write"},
                    },
                    "required": ["file_path", "content"],
                },
                is_read_only=False,
                is_concurrency_safe=False,
            )
        )

    def validate(self, request: ToolRequest) -> Optional[str]:
        if not request.parameters.get("file_path"):
            return "file_path is required"
        if "content" not in request.parameters:
            return "content is required"
        return None

    async def call(self, request: ToolRequest) -> ToolResponse:
        file_path = request.parameters["file_path"]
        content = request.parameters["content"]
        path = Path(file_path)

        mode = "update" if path.exists() else "create"

        # Staleness detection for existing files
        if mode == "update":
            state = _read_state.get(file_path)
            if state:
                try:
                    current_mtime = path.stat().st_mtime
                    if current_mtime > state["mtime"]:
                        # Check content as fallback (mtime can be unreliable)
                        is_full_read = state.get("offset") is None or (
                            state.get("offset") == 0 and state.get("limit") is None
                        )
                        if is_full_read:
                            old_content = path.read_text(encoding="utf-8", errors="replace")
                            if old_content != state["content"]:
                                return ToolResponse(
                                    success=False,
                                    error="File modified since last read. Read the file again before writing.",
                                )
                        else:
                            return ToolResponse(
                                success=False,
                                error="File modified since last read. Read the file again before writing.",
                            )
                except OSError:
                    pass

        # Create parent directories
        path.parent.mkdir(parents=True, exist_ok=True)

        # Write atomically
        try:
            path.write_text(content, encoding="utf-8")
        except Exception as exc:
            return ToolResponse(success=False, error=f"Write failed: {exc}")

        # Update staleness state
        _read_state[file_path] = {
            "content": content,
            "mtime": path.stat().st_mtime,
            "offset": None,
            "limit": None,
        }

        return ToolResponse(
            success=True,
            output={"mode": mode, "file_path": file_path},
        )
