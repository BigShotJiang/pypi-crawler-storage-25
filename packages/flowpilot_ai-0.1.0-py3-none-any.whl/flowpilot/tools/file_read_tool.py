"""FileReadTool — File reading with line ranges.

Ported from claude-code FileReadTool.ts. Reads files with line numbering,
offset/limit support, device path blocking, and staleness state tracking.
"""

from pathlib import Path
from typing import Dict, Optional

from .base_tool import BaseTool, ToolContract, ToolPermission, ToolRequest, ToolResponse

BLOCKED_PATHS = {
    "/dev/zero", "/dev/stdin", "/dev/null", "/dev/random", "/dev/urandom",
    "/proc/self/fd/0", "/proc/self/fd/1", "/proc/self/fd/2",
}
MAX_FILE_SIZE = 100_000_000  # 100MB

# Shared state for staleness detection across Read/Edit/Write
_read_state: Dict[str, Dict] = {}


class FileReadTool(BaseTool):
    """Read file contents with line numbering and range support."""

    def __init__(self):
        super().__init__(
            ToolContract(
                name="file_read",
                description="Read a file with optional line range",
                permission=ToolPermission.READ_ONLY,
                input_schema={
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string", "description": "Absolute path to file"},
                        "offset": {"type": "integer", "description": "Starting line (0-indexed)", "default": 0},
                        "limit": {"type": "integer", "description": "Number of lines to read", "default": 2000},
                    },
                    "required": ["file_path"],
                },
                is_read_only=True,
                is_concurrency_safe=True,
            )
        )

    def validate(self, request: ToolRequest) -> Optional[str]:
        file_path = request.parameters.get("file_path", "")
        if not file_path:
            return "file_path is required"
        if file_path in BLOCKED_PATHS:
            return f"Cannot read device path: {file_path}"
        return None

    async def call(self, request: ToolRequest) -> ToolResponse:
        file_path = request.parameters["file_path"]
        offset = request.parameters.get("offset", 0)
        limit = request.parameters.get("limit", 2000)

        path = Path(file_path)
        if not path.exists():
            return ToolResponse(success=False, error=f"File not found: {file_path}")

        try:
            file_size = path.stat().st_size
        except OSError as exc:
            return ToolResponse(success=False, error=str(exc))

        if file_size > MAX_FILE_SIZE:
            return ToolResponse(
                success=False,
                error=f"File too large: {file_size} bytes (max {MAX_FILE_SIZE})",
            )

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            return ToolResponse(success=False, error=f"Failed to read: {exc}")

        lines = content.split("\n")
        total_lines = len(lines)
        sliced = lines[offset : offset + limit]
        numbered = [f"{offset + i + 1}\t{line}" for i, line in enumerate(sliced)]

        # Track for staleness detection by FileEdit/FileWrite
        _read_state[file_path] = {
            "content": content,
            "mtime": path.stat().st_mtime,
            "offset": offset,
            "limit": limit,
        }

        return ToolResponse(
            success=True,
            output={
                "content": "\n".join(numbered),
                "num_lines": len(sliced),
                "start_line": offset + 1,
                "total_lines": total_lines,
            },
        )


def get_read_state() -> Dict[str, Dict]:
    """Access read state for staleness detection."""
    return _read_state
