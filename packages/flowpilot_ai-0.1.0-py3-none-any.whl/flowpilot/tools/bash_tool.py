"""BashTool — Shell command execution.

Ported from claude-code BashTool.tsx. Executes shell commands with
timeout handling, background task support, and output truncation.
"""

import asyncio
import uuid
from typing import Dict, Optional, Set

from .base_tool import BaseTool, ToolContract, ToolPermission, ToolRequest, ToolResponse

_background_tasks: Dict[str, asyncio.Task] = {}
_background_results: Dict[str, ToolResponse] = {}

READONLY_PREFIXES: Set[str] = {
    "ls", "cat", "head", "tail", "grep", "find", "git log", "git status",
    "git diff", "git branch", "pwd", "echo", "which", "type", "wc",
    "file", "stat", "du", "df", "env", "printenv", "uname", "whoami",
    "date", "uptime", "ps", "top", "free", "id",
}


class BashTool(BaseTool):
    """Execute shell commands with timeout and background support."""

    def __init__(self):
        super().__init__(
            ToolContract(
                name="bash",
                description="Execute a shell command and return its output",
                permission=ToolPermission.EXECUTE,
                input_schema={
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Shell command to execute"},
                        "timeout": {"type": "integer", "description": "Timeout in milliseconds"},
                        "run_in_background": {"type": "boolean", "default": False},
                        "description": {"type": "string", "description": "What the command does"},
                    },
                    "required": ["command"],
                },
                is_read_only=False,
                is_concurrency_safe=False,
                max_result_size_chars=200_000,
            )
        )

    def validate(self, request: ToolRequest) -> Optional[str]:
        command = request.parameters.get("command", "").strip()
        if not command:
            return "Command cannot be empty"
        return None

    def _is_readonly(self, command: str) -> bool:
        cmd_lower = command.strip().lower()
        return any(cmd_lower.startswith(prefix) for prefix in READONLY_PREFIXES)

    async def call(self, request: ToolRequest) -> ToolResponse:
        command = request.parameters["command"]
        timeout_ms = request.parameters.get("timeout", self.contract.timeout_ms)
        run_bg = request.parameters.get("run_in_background", False)
        cwd = request.working_directory

        if run_bg:
            task_id = uuid.uuid4().hex[:8]
            task = asyncio.create_task(self._run_command(command, cwd, timeout_ms))
            _background_tasks[task_id] = task

            async def _store_result():
                try:
                    result = await task
                    _background_results[task_id] = result
                except Exception as exc:
                    _background_results[task_id] = ToolResponse(
                        success=False, error=str(exc)
                    )
                finally:
                    _background_tasks.pop(task_id, None)

            asyncio.create_task(_store_result())

            return ToolResponse(
                success=True,
                output=f"Background task started: {task_id}",
                extras={"background_task_id": task_id},
            )

        return await self._run_command(command, cwd, timeout_ms)

    async def _run_command(
        self, command: str, cwd: str, timeout_ms: int
    ) -> ToolResponse:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_ms / 1000
            )
        except asyncio.TimeoutError:
            proc.terminate()
            await asyncio.sleep(0.5)
            if proc.returncode is None:
                proc.kill()
                try:
                    await asyncio.wait_for(proc.communicate(), timeout=2)
                except asyncio.TimeoutError:
                    pass
            return ToolResponse(
                success=False,
                error=f"Command timed out after {timeout_ms}ms",
                extras={"returncode": -1},
            )

        output = (stdout or b"").decode("utf-8", errors="replace")
        err_output = (stderr or b"").decode("utf-8", errors="replace")
        if err_output:
            output = output + "\n" + err_output if output else err_output

        return ToolResponse(
            success=(proc.returncode == 0),
            output=output,
            extras={
                "returncode": proc.returncode,
                "is_readonly": self._is_readonly(command),
            },
        )


def get_background_result(task_id: str) -> Optional[ToolResponse]:
    """Get result of a background task, if completed."""
    return _background_results.pop(task_id, None)
