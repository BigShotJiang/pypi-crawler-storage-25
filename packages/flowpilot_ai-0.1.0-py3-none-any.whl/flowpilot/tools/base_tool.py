import asyncio
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class ToolPermission(Enum):
    READ_ONLY = "read_only"
    READ_WRITE = "read_write"
    EXECUTE = "execute"


@dataclass
class ToolRequest:
    """Universal input for every tool."""

    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    tool_name: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    working_directory: str = "."
    timeout_ms: int = 120_000
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ToolResponse:
    """Universal output from every tool."""

    trace_id: str = ""
    tool_name: str = ""
    success: bool = True
    output: Any = None
    error: Optional[str] = None
    latency_ms: float = 0.0
    truncated: bool = False
    extras: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ToolContract:
    """Declarative contract for a tool."""

    name: str
    description: str
    permission: ToolPermission = ToolPermission.READ_ONLY
    input_schema: Dict[str, Any] = field(default_factory=dict)
    timeout_ms: int = 120_000
    is_read_only: bool = True
    is_concurrency_safe: bool = True
    max_result_size_chars: int = 100_000


class BaseTool(ABC):
    """Abstract base class for all tools.

    Mirrors the BaseAgent pattern: execute() wraps call() with timeout,
    validation, tracing, error handling, result truncation, and metrics.
    """

    def __init__(self, contract: ToolContract):
        self.contract = contract
        self._call_count: int = 0
        self._error_count: int = 0

    @abstractmethod
    async def call(self, request: ToolRequest) -> ToolResponse:
        """Execute the tool. Every tool implements this."""
        ...

    def validate(self, request: ToolRequest) -> Optional[str]:
        """Validate input before execution. Return error string or None."""
        return None

    async def execute(self, request: ToolRequest) -> ToolResponse:
        """Wrapper: validation + timeout + tracing + error handling + metrics."""
        start = time.time()
        self._call_count += 1

        validation_error = self.validate(request)
        if validation_error:
            return ToolResponse(
                trace_id=request.trace_id,
                tool_name=self.contract.name,
                success=False,
                error=f"Validation failed: {validation_error}",
                latency_ms=round((time.time() - start) * 1000, 2),
            )

        timeout_s = (request.timeout_ms or self.contract.timeout_ms) / 1000.0
        try:
            response = await asyncio.wait_for(
                self.call(request),
                timeout=timeout_s,
            )
            response.trace_id = request.trace_id
            response.tool_name = self.contract.name
            response.latency_ms = round((time.time() - start) * 1000, 2)

            if (
                isinstance(response.output, str)
                and len(response.output) > self.contract.max_result_size_chars
            ):
                response.output = response.output[: self.contract.max_result_size_chars]
                response.truncated = True

            return response

        except asyncio.TimeoutError:
            self._error_count += 1
            return ToolResponse(
                trace_id=request.trace_id,
                tool_name=self.contract.name,
                success=False,
                error=f"Tool timed out after {timeout_s:.1f}s",
                latency_ms=round((time.time() - start) * 1000, 2),
            )
        except Exception as exc:
            self._error_count += 1
            return ToolResponse(
                trace_id=request.trace_id,
                tool_name=self.contract.name,
                success=False,
                error=str(exc),
                latency_ms=round((time.time() - start) * 1000, 2),
            )

    @property
    def is_read_only(self) -> bool:
        return self.contract.is_read_only

    @property
    def metrics(self) -> Dict[str, Any]:
        return {
            "tool": self.contract.name,
            "calls": self._call_count,
            "errors": self._error_count,
            "error_rate": round(self._error_count / max(self._call_count, 1), 4),
        }
