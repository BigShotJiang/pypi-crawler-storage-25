"""GlobTool — File pattern matching.

Ported from claude-code GlobTool.ts. Finds files matching glob patterns
with result limiting and modification time sorting.
"""

import time as _time
from pathlib import Path
from typing import Optional

from .base_tool import BaseTool, ToolContract, ToolPermission, ToolRequest, ToolResponse

MAX_RESULTS = 100


class GlobTool(BaseTool):
    """Find files matching glob patterns."""

    def __init__(self):
        super().__init__(
            ToolContract(
                name="glob",
                description="Find files matching a glob pattern",
                permission=ToolPermission.READ_ONLY,
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string", "description": "Glob pattern (e.g. **/*.py)"},
                        "path": {"type": "string", "description": "Directory to search in"},
                    },
                    "required": ["pattern"],
                },
                is_read_only=True,
                is_concurrency_safe=True,
                max_result_size_chars=100_000,
            )
        )

    def validate(self, request: ToolRequest) -> Optional[str]:
        if not request.parameters.get("pattern"):
            return "Pattern cannot be empty"
        return None

    async def call(self, request: ToolRequest) -> ToolResponse:
        start = _time.time()
        pattern = request.parameters["pattern"]
        search_dir = Path(request.parameters.get("path", request.working_directory))

        if not search_dir.exists():
            return ToolResponse(
                success=False,
                error=f"Directory not found: {search_dir}",
            )

        try:
            matches = []
            for f in search_dir.glob(pattern):
                if f.is_file():
                    try:
                        matches.append((f, f.stat().st_mtime))
                    except OSError:
                        matches.append((f, 0))
        except Exception as exc:
            return ToolResponse(success=False, error=str(exc))

        matches.sort(key=lambda x: x[1], reverse=True)
        truncated = len(matches) > MAX_RESULTS
        matches = matches[:MAX_RESULTS]

        filenames = []
        for f, _ in matches:
            try:
                filenames.append(str(f.relative_to(search_dir)))
            except ValueError:
                filenames.append(str(f))

        return ToolResponse(
            success=True,
            output={
                "filenames": filenames,
                "num_files": len(filenames),
                "truncated": truncated,
                "duration_ms": round((_time.time() - start) * 1000, 2),
            },
        )
