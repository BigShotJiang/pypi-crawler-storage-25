import os
from dataclasses import dataclass, field
from typing import List


@dataclass
class AgentContract:
    """Runtime-enforced contract for an agent."""

    name: str
    purpose: str
    allowed_tasks: List[str] = field(default_factory=list)
    forbidden_tasks: List[str] = field(default_factory=list)
    tools_allowed: List[str] = field(default_factory=list)
    fallback_model: str = "openai/gpt-4o-mini"
    confidence_threshold: float = 0.4
    failure_message: str = "Could not process your request."
    timeout_seconds: float = 10.0
    max_retries: int = 2


CODE_CONTRACT = AgentContract(
    name="code",
    purpose="Playwright browser automation, UI testing, and code analysis",
    allowed_tasks=[
        "browser_automation", "ui_testing", "screenshot", "accessibility",
        "test_generation", "github_push", "responsive_testing",
    ],
    forbidden_tasks=["delete_production_data", "modify_source_code"],
    tools_allowed=["playwright", "httpx", "github_api"],
    fallback_model=os.getenv("CODE_AGENT_FALLBACK_MODEL", "openai/gpt-4o-mini"),
    confidence_threshold=0.4,
    failure_message="Could not complete browser task. Please check that Playwright is installed.",
    timeout_seconds=float(os.getenv("CODE_AGENT_TIMEOUT", "120")),
    max_retries=1,
)

RAG_CONTRACT = AgentContract(
    name="rag",
    purpose="Retrieval-augmented question answering from indexed documents",
    allowed_tasks=["search", "answer", "summarise", "citation"],
    forbidden_tasks=[],
    tools_allowed=["opensearch", "faiss", "llm"],
    fallback_model=os.getenv("RAG_AGENT_FALLBACK_MODEL", "openai/gpt-4o-mini"),
    confidence_threshold=0.3,
    failure_message="Could not find a confident answer in the knowledge base.",
    timeout_seconds=float(os.getenv("RAG_AGENT_TIMEOUT", "30")),
    max_retries=2,
)

API_CONTRACT = AgentContract(
    name="api",
    purpose="API test generation, execution, bulk runner, and spec parsing",
    allowed_tasks=[
        "parse_spec", "generate_tests", "run_tests", "bulk_run",
        "e2e_flow", "api_discovery",
    ],
    forbidden_tasks=["delete_production_data"],
    tools_allowed=["httpx", "openapi_parser", "llm"],
    fallback_model=os.getenv("API_AGENT_FALLBACK_MODEL", "openai/gpt-4o-mini"),
    confidence_threshold=0.4,
    failure_message="Could not parse or test the API artifact. Try pasting a cURL command or OpenAPI spec.",
    timeout_seconds=float(os.getenv("API_AGENT_TIMEOUT", "60")),
    max_retries=1,
)

V25_CONTRACT = AgentContract(
    name="v25",
    purpose="XStore v18 to v25 migration analysis, triage, risk assessment, and golden pack generation",
    allowed_tasks=[
        "migration_triage", "coverage_analysis", "risk_assessment",
        "golden_pack_generation", "cutover_planning", "lv_customisation",
    ],
    forbidden_tasks=["modify_production_data"],
    tools_allowed=["rag", "llm", "opensearch"],
    fallback_model=os.getenv("V25_AGENT_FALLBACK_MODEL", "openai/gpt-4o"),
    confidence_threshold=0.5,
    failure_message="Could not complete migration analysis. Please provide more context about the migration scope.",
    timeout_seconds=float(os.getenv("V25_AGENT_TIMEOUT", "60")),
    max_retries=1,
)

SUPPORT_CONTRACT = AgentContract(
    name="support",
    purpose="Incident triage, runbook lookup, and escalation guidance",
    allowed_tasks=["triage", "runbook", "escalate", "status"],
    forbidden_tasks=[],
    tools_allowed=["rag", "llm"],
    fallback_model=os.getenv("SUPPORT_AGENT_FALLBACK_MODEL", "openai/gpt-4o-mini"),
    confidence_threshold=0.4,
    failure_message="Could not resolve incident. Please escalate to on-call engineer.",
    timeout_seconds=float(os.getenv("SUPPORT_AGENT_TIMEOUT", "20")),
    max_retries=1,
)

WEB_CONTRACT = AgentContract(
    name="web_agent",
    purpose="Conversational browser control, Playwright recording, and test generation",
    allowed_tasks=[
        "browser_navigate", "browser_click", "browser_fill", "browser_screenshot",
        "scenario_run", "test_generate",
    ],
    forbidden_tasks=[],
    tools_allowed=["playwright", "llm"],
    fallback_model=os.getenv("WEB_AGENT_FALLBACK_MODEL", "openai/gpt-4o-mini"),
    confidence_threshold=0.3,
    failure_message="Could not execute browser instruction. The session may have expired.",
    timeout_seconds=float(os.getenv("WEB_AGENT_TIMEOUT", "180")),
    max_retries=1,
)
