from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class AgentResponse:
    """Universal output from every agent in the platform."""

    trace_id: str = ""
    agent_name: str = ""
    success: bool = True
    answer: str = ""
    confidence: float = 0.0
    sources: List[Dict] = field(default_factory=list)
    citations: List[str] = field(default_factory=list)
    out_of_scope: bool = False
    error: Optional[str] = None
    latency_ms: float = 0.0
    model_used: str = ""
    fallback_used: bool = False
    extras: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "agent_name": self.agent_name,
            "success": self.success,
            "answer": self.answer,
            "confidence": self.confidence,
            "sources": self.sources,
            "citations": self.citations,
            "out_of_scope": self.out_of_scope,
            "error": self.error,
            "latency_ms": self.latency_ms,
            "model_used": self.model_used,
            "fallback_used": self.fallback_used,
            "extras": self.extras,
        }
