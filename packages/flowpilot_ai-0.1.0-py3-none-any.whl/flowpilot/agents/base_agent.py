import asyncio
import time
from abc import ABC, abstractmethod
from typing import Any, Dict

from .contracts import AgentContract
from .request import AgentRequest
from .response import AgentResponse


class BaseAgent(ABC):
    """Abstract base class for all agents in the platform.

    Subclasses must implement:
        handle()       — process a request (pure business logic)
        health_check() — return agent health status

    The execute() wrapper adds timeout enforcement, confidence gating,
    automatic tracing, latency tracking, and error handling.
    """

    def __init__(self, contract: AgentContract, llm_service=None):
        self.contract = contract
        self.llm = llm_service
        self._request_count: int = 0
        self._error_count: int = 0

    @abstractmethod
    async def handle(self, request: AgentRequest) -> AgentResponse:
        """Process a request. Every agent implements this."""
        ...

    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """Return agent health status."""
        ...

    async def execute(self, request: AgentRequest) -> AgentResponse:
        """Wrapper: contract enforcement + tracing + error handling + metrics."""
        start = time.time()
        self._request_count += 1
        try:
            response = await asyncio.wait_for(
                self.handle(request),
                timeout=self.contract.timeout_seconds,
            )
            response.trace_id = request.trace_id
            response.agent_name = self.contract.name
            response.latency_ms = round((time.time() - start) * 1000, 2)

            if response.confidence < self.contract.confidence_threshold and not response.error:
                response.answer = self.contract.failure_message
                response.out_of_scope = True
            return response
        except asyncio.TimeoutError:
            self._error_count += 1
            return AgentResponse(
                trace_id=request.trace_id,
                agent_name=self.contract.name,
                success=False,
                error=f"Agent timed out after {self.contract.timeout_seconds}s",
                answer=self.contract.failure_message,
                latency_ms=round((time.time() - start) * 1000, 2),
            )
        except Exception as exc:
            self._error_count += 1
            return AgentResponse(
                trace_id=request.trace_id,
                agent_name=self.contract.name,
                success=False,
                error=str(exc),
                answer=self.contract.failure_message,
                latency_ms=round((time.time() - start) * 1000, 2),
            )

    async def cleanup(self):
        """Called on shutdown. Override for resource cleanup."""
        pass

    @property
    def metrics(self) -> Dict[str, Any]:
        return {
            "agent": self.contract.name,
            "requests": self._request_count,
            "errors": self._error_count,
            "error_rate": round(
                self._error_count / max(self._request_count, 1), 4
            ),
        }
