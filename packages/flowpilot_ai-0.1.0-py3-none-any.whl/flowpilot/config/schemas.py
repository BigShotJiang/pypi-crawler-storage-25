from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class LocalModelConfig(BaseModel):
    """Configuration for local LLM server (Ollama, LM Studio, vLLM, etc.)."""

    url: str = "http://localhost:1234/v1/chat/completions"
    model: str = "mistralai/ministral-3-3b"
    timeout: int = 8
    enabled: bool = True


class CloudProviderConfig(BaseModel):
    """Configuration for cloud LLM provider."""

    provider: str = "openrouter"
    model: str = "anthropic/claude-3.5-sonnet"
    api_key: str = ""
    base_url: str = ""
    timeout: int = 30


class FallbackConfig(BaseModel):
    """Configuration for a fallback LLM provider."""

    provider: str = "openai"
    model: str = "gpt-4o-mini"
    api_key: str = ""


class PerAgentOverride(BaseModel):
    """Per-agent LLM configuration overrides."""

    model: Optional[str] = None
    timeout: Optional[int] = None
    fallback_model: Optional[str] = None


class LLMConfig(BaseModel):
    """Top-level LLM configuration."""

    mode: str = Field(default="auto", description="auto | local | cloud")
    local: LocalModelConfig = Field(default_factory=LocalModelConfig)
    cloud: CloudProviderConfig = Field(default_factory=CloudProviderConfig)
    fallback: List[FallbackConfig] = Field(
        default_factory=lambda: [
            FallbackConfig(provider="openai", model="gpt-4o-mini"),
            FallbackConfig(provider="openai", model="gpt-4o"),
        ]
    )
    per_agent: Dict[str, PerAgentOverride] = Field(default_factory=dict)
    temperature: float = 0.3
    max_tokens: int = 1000


class RAGConfig(BaseModel):
    """RAG retrieval configuration."""

    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_dim: int = 384
    chunk_size: int = 512
    chunk_overlap: int = 50
    top_k: int = 10
    keyword_top_k: int = 10
    rrf_k: int = 60
    rerank_top_n: int = 5
    confidence_threshold: float = 0.3
    max_retries: int = 2
    quality_threshold: int = 3


class DatabaseConfig(BaseModel):
    """Database configuration."""

    url: str = "postgresql://localhost:5432/flowpilot"
    pool_size: int = 5
    max_overflow: int = 10


class SearchConfig(BaseModel):
    """OpenSearch configuration."""

    url: str = "http://localhost:9200"
    username: str = ""
    password: str = ""


class ServerConfig(BaseModel):
    """Server configuration."""

    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    reload: bool = False


class FlowPilotConfig(BaseModel):
    """Top-level configuration for the entire platform."""

    llm: LLMConfig = Field(default_factory=LLMConfig)
    rag: RAGConfig = Field(default_factory=RAGConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    search: SearchConfig = Field(default_factory=SearchConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)
    app_env: str = "dev"
    api_secret_key: str = ""
    default_tenant_id: str = "default"
