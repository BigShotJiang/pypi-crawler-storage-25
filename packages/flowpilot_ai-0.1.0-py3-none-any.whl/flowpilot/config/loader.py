import os
import re
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

from .schemas import FlowPilotConfig


def load_config(
    cli_args: Optional[Dict[str, Any]] = None,
    config_path: Optional[str] = None,
    env_prefix: str = "FLOWPILOT_",
) -> FlowPilotConfig:
    """Load configuration with layered resolution.

    Priority (last wins):
        1. Built-in defaults (Pydantic model defaults)
        2. Global config   (~/.flowpilot/config.yaml)
        3. Project config  (./flowpilot.yaml)
        4. Environment variables (FLOWPILOT_*)
        5. CLI arguments
        6. Programmatic overrides
    """
    data: Dict[str, Any] = {}

    # Layer 2: Global config
    global_path = Path.home() / ".flowpilot" / "config.yaml"
    if global_path.exists():
        data = _deep_merge(data, _load_yaml(global_path))

    # Layer 3: Project config
    project_path = Path(config_path or "./flowpilot.yaml")
    if project_path.exists():
        data = _deep_merge(data, _load_yaml(project_path))

    # Layer 4: Environment variables
    data = _deep_merge(data, _env_to_dict(env_prefix))

    # Layer 5: CLI arguments
    if cli_args:
        data = _deep_merge(data, cli_args)

    # Resolve ${VAR} references
    data = _resolve_env_refs(data)

    return FlowPilotConfig(**data) if data else FlowPilotConfig()


def _load_yaml(path: Path) -> Dict[str, Any]:
    try:
        with open(path) as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def _env_to_dict(prefix: str) -> Dict[str, Any]:
    """Convert FLOWPILOT_LLM_MODE=auto → {"llm": {"mode": "auto"}}."""
    result: Dict[str, Any] = {}
    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue
        parts = key[len(prefix):].lower().split("_")
        current = result
        for part in parts[:-1]:
            current = current.setdefault(part, {})
        current[parts[-1]] = _parse_value(value)
    return result


def _parse_value(value: str) -> Any:
    if value.lower() in ("true", "yes", "1"):
        return True
    if value.lower() in ("false", "no", "0"):
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def _resolve_env_refs(data: Any) -> Any:
    """Resolve ${VAR} references in string values."""
    if isinstance(data, str):
        pattern = r"\$\{([^}]+)\}"
        return re.sub(pattern, lambda m: os.getenv(m.group(1), m.group(0)), data)
    if isinstance(data, dict):
        return {k: _resolve_env_refs(v) for k, v in data.items()}
    if isinstance(data, list):
        return [_resolve_env_refs(v) for v in data]
    return data


def _deep_merge(base: Dict, override: Dict) -> Dict:
    """Deep merge override into base."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result
