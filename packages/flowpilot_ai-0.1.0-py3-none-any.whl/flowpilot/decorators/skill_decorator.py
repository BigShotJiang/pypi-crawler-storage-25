import functools
import inspect
from typing import Callable, Dict

_skill_registry: Dict[str, Dict] = {}


def skill(
    name: str = "",
    description: str = "",
    when: str = "",
):
    """Decorator that registers a function as a reusable skill."""

    def decorator(func: Callable):
        skill_name = name or func.__name__

        _skill_registry[skill_name] = {
            "name": skill_name,
            "description": description or func.__doc__ or "",
            "when": when,
            "func": func,
        }

        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            return func(*args, **kwargs)

        wrapper._skill_name = skill_name
        return wrapper

    return decorator


def get_skill_registry() -> Dict[str, Dict]:
    return _skill_registry
