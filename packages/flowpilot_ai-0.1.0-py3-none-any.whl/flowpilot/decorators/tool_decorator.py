import functools
import inspect
from typing import Any, Callable, Dict, Optional

from ..tools.base_tool import BaseTool, ToolContract, ToolPermission, ToolRequest, ToolResponse


def _signature_to_json_schema(sig: inspect.Signature) -> Dict[str, Any]:
    """Convert a function signature to a JSON Schema dict."""
    properties = {}
    required = []
    type_map = {str: "string", int: "integer", float: "number", bool: "boolean", list: "array", dict: "object"}

    for name, param in sig.parameters.items():
        annotation = param.annotation
        json_type = type_map.get(annotation, "string") if annotation != inspect.Parameter.empty else "string"
        properties[name] = {"type": json_type}
        if param.default is inspect.Parameter.empty:
            required.append(name)

    return {"type": "object", "properties": properties, "required": required}


def tool(
    name: str = "",
    description: str = "",
    permission: str = "read_only",
    timeout_ms: int = 120_000,
    max_result_size_chars: int = 100_000,
):
    """Decorator that wraps a function into a BaseTool subclass and registers it."""

    def decorator(func: Callable):
        tool_name = name or func.__name__
        tool_perm = ToolPermission(permission)
        sig = inspect.signature(func)
        input_schema = _signature_to_json_schema(sig)

        contract = ToolContract(
            name=tool_name,
            description=description or func.__doc__ or "",
            permission=tool_perm,
            input_schema=input_schema,
            timeout_ms=timeout_ms,
            is_read_only=(tool_perm == ToolPermission.READ_ONLY),
            max_result_size_chars=max_result_size_chars,
        )

        class FuncTool(BaseTool):
            async def call(self, request: ToolRequest) -> ToolResponse:
                if inspect.iscoroutinefunction(func):
                    result = await func(**request.parameters)
                else:
                    result = func(**request.parameters)
                return ToolResponse(success=True, output=result)

        tool_instance = FuncTool(contract)

        from ..registry.registry import tool_registry
        tool_registry.register(tool_name, tool_instance)

        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            return func(*args, **kwargs)

        wrapper._tool = tool_instance
        return wrapper

    return decorator
