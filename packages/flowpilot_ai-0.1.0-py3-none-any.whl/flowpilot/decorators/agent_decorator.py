from typing import Optional

from ..agents.base_agent import BaseAgent
from ..agents.contracts import AgentContract


def agent(
    name: str = "",
    mode: str = "",
    purpose: str = "",
    timeout_seconds: float = 30.0,
    confidence_threshold: float = 0.4,
):
    """Class decorator that registers a BaseAgent subclass with a contract."""

    def decorator(cls):
        if not issubclass(cls, BaseAgent):
            raise TypeError(f"{cls.__name__} must extend BaseAgent")

        agent_name = name or cls.__name__.lower().replace("agent", "")
        contract = AgentContract(
            name=agent_name,
            purpose=purpose or cls.__doc__ or "",
            timeout_seconds=timeout_seconds,
            confidence_threshold=confidence_threshold,
        )

        cls._auto_contract = contract
        cls._auto_mode = mode or agent_name

        from ..registry.registry import agent_registry
        try:
            instance = cls(contract=contract)
            agent_registry.register(agent_name, instance)
        except Exception:
            pass

        return cls

    return decorator
