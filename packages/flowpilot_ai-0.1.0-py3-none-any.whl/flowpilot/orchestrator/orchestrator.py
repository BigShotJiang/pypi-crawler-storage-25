"""Agent orchestrator — deterministic multi-agent routing with self-healing retry."""

import asyncio
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

USE_LANGGRAPH = os.getenv("USE_LANGGRAPH", "true").lower() in ("true", "1", "yes", "on")

MIGRATION_KEYWORDS = [
    "v18", "v25", "migration", "migrate", "golden pack", "golden regression",
    "triage", "retire", "xstore", "traceability",
]

MODEL_COSTS = {
    "anthropic/claude-3.5-sonnet": (3.0, 15.0),
    "anthropic/claude-3-haiku": (0.25, 1.25),
    "gpt-4o": (2.50, 10.0),
    "gpt-4o-mini": (0.15, 0.60),
    "meta-llama/llama-3": (0.05, 0.10),
    "deepseek": (0.14, 0.28),
    "mistral": (0.10, 0.30),
}


def generate_trace_id() -> str:
    return f"trace_{uuid.uuid4().hex[:12]}"


class AgentOrchestrator:
    """Deterministic multi-agent router with self-healing retry."""

    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.agents = {}
        self.shared_memory = None
        self.memory_agent = None
        self.llm = None
        self._langgraph_runtime = None
        self.base_dir = Path(__file__).resolve().parents[1]

    def initialize(self, llm_client=None, memory_agent=None):
        self.llm = llm_client
        self.shared_memory = memory_agent
        self.memory_agent = memory_agent
        logger.info("Orchestrator initialized (LangGraph: %s)", "ON" if USE_LANGGRAPH else "OFF")

    @property
    def langgraph_runtime(self):
        if self._langgraph_runtime is None:
            from ..graphs.runtime import get_runtime
            self._langgraph_runtime = get_runtime()
        return self._langgraph_runtime

    async def route_request(self, request: Dict) -> Dict:
        start_time = time.time()
        trace_id = request.get("trace_id") or generate_trace_id()
        request_type = request.get("type", "chat")

        try:
            message = request.get("message", "").lower()
            is_migration = any(kw in message for kw in MIGRATION_KEYWORDS)

            if request_type in ("chat", "rag.query", "rag"):
                if is_migration:
                    result = await self._handle_migration(request, trace_id)
                else:
                    result = await self._handle_chat(request, trace_id)
            elif request_type == "migration.v25":
                result = await self._handle_migration(request, trace_id)
            elif request_type == "browser":
                result = await self._handle_browser(request, trace_id)
            elif request_type in ("api", "api.single"):
                result = await self._handle_api(request, trace_id)
            elif request_type == "api.workflow":
                result = await self._handle_api_workflow(request, trace_id)
            else:
                result = {"error": f"Unknown request type: {request_type}", "agent": "orchestrator"}

            # Self-healing retry on low confidence
            confidence = result.get("confidence")
            if confidence is not None and confidence < 0.4 and request_type in ("chat", "rag.query", "rag") and not request.get("_is_retry"):
                retry_request = {**request, "_is_retry": True}
                retry_result = await self._handle_chat(retry_request, trace_id)
                if retry_result.get("confidence", 0) > confidence:
                    result = retry_result

            latency_ms = round((time.time() - start_time) * 1000, 2)
            result["trace_id"] = trace_id
            result["latency_ms"] = latency_ms
            result["request_type"] = request_type

            # Async logging
            try:
                asyncio.create_task(self._log_to_db(request, result, latency_ms))
            except Exception:
                pass

            return result
        except Exception as e:
            latency_ms = round((time.time() - start_time) * 1000, 2)
            return {"error": str(e), "agent": "orchestrator", "trace_id": trace_id, "latency_ms": latency_ms}

    async def _handle_chat(self, request: Dict, trace_id: str) -> Dict:
        if USE_LANGGRAPH:
            return await self.langgraph_runtime.run("rag.query", request, trace_id)
        return {"answer": "", "agent": "rag", "confidence": 0.0, "sources": []}

    async def _handle_migration(self, request: Dict, trace_id: str) -> Dict:
        if USE_LANGGRAPH:
            return await self.langgraph_runtime.run("migration.v25", request, trace_id)
        return {"answer": "", "agent": "v25", "confidence": 0.0}

    async def _handle_browser(self, request: Dict, trace_id: str) -> Dict:
        return {"answer": "Browser agent placeholder", "agent": "code", "confidence": 0.5}

    async def _handle_api(self, request: Dict, trace_id: str) -> Dict:
        return {"answer": "API agent placeholder", "agent": "api", "confidence": 0.5}

    async def _handle_api_workflow(self, request: Dict, trace_id: str) -> Dict:
        if USE_LANGGRAPH:
            return await self.langgraph_runtime.run("api.workflow", request, trace_id)
        return {"answer": "", "agent": "api", "confidence": 0.0}

    def _estimate_cost(self, model: str, usage: Dict) -> tuple:
        tokens_in = usage.get("prompt_tokens", 0) if usage else 0
        tokens_out = usage.get("completion_tokens", 0) if usage else 0
        if not tokens_in and not tokens_out:
            return None, None, None
        cost_rates = None
        model_lower = (model or "").lower()
        for prefix, rates in MODEL_COSTS.items():
            if prefix in model_lower:
                cost_rates = rates
                break
        if not cost_rates:
            cost_rates = (1.0, 3.0)
        cost = (tokens_in / 1_000_000 * cost_rates[0]) + (tokens_out / 1_000_000 * cost_rates[1])
        return tokens_in, tokens_out, round(cost, 8)

    async def _log_to_db(self, request: Dict, result: Dict, latency_ms: float):
        try:
            from ..services.database import DatabaseService
            usage = result.get("usage")
            model_used = result.get("model_used")
            tokens_in, tokens_out, cost_usd = self._estimate_cost(model_used, usage)
            await DatabaseService.log_prompt(
                question=request.get("message", ""),
                agent_type=result.get("agent", "unknown"),
                response_text=result.get("answer", ""),
                confidence=result.get("confidence"),
                latency_ms=latency_ms,
                model_used=model_used,
                tokens_input=tokens_in,
                tokens_output=tokens_out,
                cost_usd=cost_usd,
            )
        except Exception:
            pass
