"""FastAPI application factory."""

import json
import logging
import os
import time
from typing import Any, Dict

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .._version import __version__
from ..config import load_config
from ..orchestrator import AgentOrchestrator
from ..services.llm_client import LLMClient
from ..services.health import HealthService, record_latency

logger = logging.getLogger(__name__)

_orchestrator = None


def get_orchestrator() -> AgentOrchestrator:
    global _orchestrator
    if _orchestrator is None:
        config = load_config()
        llm = LLMClient(
            provider=config.llm.cloud.provider,
            model=config.llm.cloud.model,
            api_key=config.llm.cloud.api_key or None,
            temperature=config.llm.temperature,
            max_tokens=config.llm.max_tokens,
        )
        _orchestrator = AgentOrchestrator()
        _orchestrator.initialize(llm_client=llm)
    return _orchestrator


def create_app() -> FastAPI:
    app = FastAPI(
        title="FlowPilot",
        version=__version__,
        description="AI Agent Orchestration Framework",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health():
        info = HealthService.get_uptime()
        info["version"] = __version__
        return info

    @app.post("/chat")
    async def chat(request: Request):
        body = await request.json()
        message = body.get("message", "")
        mode = body.get("mode", "chat")
        session_id = body.get("session_id")

        orchestrator = get_orchestrator()
        request_type = {
            "auto": "chat", "chat": "chat", "rag": "rag.query",
            "api": "api", "code": "browser", "migration": "migration.v25",
            "support": "chat", "web": "browser",
        }.get(mode, "chat")

        result = await orchestrator.route_request({
            "message": message,
            "type": request_type,
            "session_id": session_id,
        })

        record_latency(result.get("latency_ms", 0))
        return result

    @app.get("/api/v1/admin/agents")
    async def list_agents():
        orchestrator = get_orchestrator()
        return {"agents": list(orchestrator.agents.keys())}

    @app.get("/api/v1/admin/config")
    async def show_config():
        config = load_config()
        return config.model_dump()

    @app.get("/api/v1/observability/dashboard")
    async def observability():
        from ..services.analytics import AnalyticsService
        analytics = AnalyticsService()
        return {
            "health": HealthService.get_uptime(),
            "latency": HealthService.get_realtime_latency(),
            "errors": HealthService.get_error_rate(),
            "analytics": analytics.get_summary(),
        }

    return app
