import click

from .._version import __version__


@click.group()
@click.version_option(version=__version__, prog_name="flowpilot")
def cli():
    """FlowPilot — AI Agent Orchestration Framework"""
    pass


@cli.command()
@click.option("--host", default="0.0.0.0", help="Bind host")
@click.option("--port", default=8000, type=int, help="Bind port")
@click.option("--reload", is_flag=True, help="Enable auto-reload")
@click.option("--workers", default=1, type=int, help="Number of workers")
@click.option("--local-url", default=None, help="Local LLM URL")
@click.option("--local-model", default=None, help="Local LLM model name")
@click.option("--mode", default=None, type=click.Choice(["auto", "local", "cloud"]))
@click.option("--provider", default=None, help="Cloud LLM provider")
@click.option("--model", default=None, help="Cloud LLM model")
def serve(host, port, reload, workers, local_url, local_model, mode, provider, model):
    """Start the FlowPilot server."""
    import uvicorn

    cli_args = {}
    if mode:
        cli_args.setdefault("llm", {})["mode"] = mode
    if local_url:
        cli_args.setdefault("llm", {}).setdefault("local", {})["url"] = local_url
    if local_model:
        cli_args.setdefault("llm", {}).setdefault("local", {})["model"] = local_model
    if provider:
        cli_args.setdefault("llm", {}).setdefault("cloud", {})["provider"] = provider
    if model:
        cli_args.setdefault("llm", {}).setdefault("cloud", {})["model"] = model

    # Store CLI args for the app factory to pick up
    import os
    import json
    if cli_args:
        os.environ["_FLOWPILOT_CLI_ARGS"] = json.dumps(cli_args)

    uvicorn.run(
        "flowpilot.server.app:create_app",
        host=host,
        port=port,
        reload=reload,
        workers=workers,
        factory=True,
    )


@cli.command("create-agent")
@click.argument("name")
@click.option("--template", default="basic_agent", help="Template to use")
@click.option("--output-dir", default=".", help="Output directory")
def create_agent(name, template, output_dir):
    """Scaffold a new agent from a template."""
    from pathlib import Path

    agent_dir = Path(output_dir) / name
    agent_dir.mkdir(parents=True, exist_ok=True)
    (agent_dir / "__init__.py").write_text("")
    (agent_dir / "agent.py").write_text(
        f'''from flowpilot import BaseAgent, AgentRequest, AgentResponse, AgentContract


class {name.title().replace("_", "")}Agent(BaseAgent):
    """Custom agent: {name}"""

    async def handle(self, request: AgentRequest) -> AgentResponse:
        return AgentResponse(
            success=True,
            answer=f"Hello from {name} agent!",
            confidence=0.9,
        )

    async def health_check(self):
        return {{"status": "ok"}}
'''
    )
    (agent_dir / "config.yaml").write_text(
        f"""name: {name}
purpose: "Custom agent"
timeout_seconds: 30
confidence_threshold: 0.4
"""
    )
    tests_dir = agent_dir / "tests"
    tests_dir.mkdir(exist_ok=True)
    (tests_dir / "__init__.py").write_text("")
    (tests_dir / f"test_{name}.py").write_text(
        f'''import asyncio
from {name}.agent import {name.title().replace("_", "")}Agent
from flowpilot import AgentContract, AgentRequest


def test_{name}_agent():
    contract = AgentContract(name="{name}", purpose="test")
    agent = {name.title().replace("_", "")}Agent(contract=contract)
    request = AgentRequest(message="test")
    response = asyncio.run(agent.execute(request))
    assert response.success
'''
    )
    click.echo(f"Created agent '{name}' at {agent_dir}")


@cli.command()
@click.argument("agent_path")
@click.option("--name", default=None, help="Override agent name")
def register(agent_path, name):
    """Register an agent with the platform."""
    click.echo(f"Registered agent from {agent_path}")


@cli.command()
@click.option("--server", required=True, help="FlowPilot server URL")
@click.option("--concurrency", default=10, type=int)
@click.option("--timeout", default=15, type=int)
def run(server, concurrency, timeout):
    """Run bulk API tests."""
    click.echo(f"Running tests against {server}")


@cli.group("config")
def config_group():
    """Configuration management."""
    pass


@config_group.command("show")
def config_show():
    """Display resolved configuration."""
    from ..config import load_config
    cfg = load_config()
    click.echo(cfg.model_dump_json(indent=2))


@config_group.command("init")
@click.option("--output", default="flowpilot.yaml", help="Output file path")
def config_init(output):
    """Generate a flowpilot.yaml template."""
    from pathlib import Path
    import importlib.resources as pkg_resources

    defaults_path = Path(__file__).parent.parent / "config" / "defaults.yaml"
    if defaults_path.exists():
        content = defaults_path.read_text()
    else:
        content = "# FlowPilot configuration\nllm:\n  mode: auto\n"

    Path(output).write_text(content)
    click.echo(f"Created {output}")
