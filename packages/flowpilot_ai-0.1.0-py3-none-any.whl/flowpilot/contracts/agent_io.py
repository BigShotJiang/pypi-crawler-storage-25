"""Data contracts for agent I/O — standardized result schemas."""

from typing import Any, Dict, List, Optional

SCHEMA_VERSION = "1.0"


def build_api_test_result(
    summary: Dict[str, Any],
    by_category: Dict[str, Any],
    test_cases: List[Dict[str, Any]],
) -> Dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "type": "api_test_result",
        "summary": summary,
        "by_category": by_category,
        "test_cases": test_cases,
    }


def build_api_workflow_result(
    summary: Dict[str, Any],
    workflow: Dict[str, Any],
    steps: Optional[List[Dict[str, Any]]] = None,
    dataset_results: Optional[List[Dict[str, Any]]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "type": "api_workflow_result",
        "summary": summary,
        "workflow": workflow,
        "steps": steps or [],
        "dataset_results": dataset_results or [],
        "metadata": metadata or {},
    }


def build_rag_response(
    answer: str,
    confidence: float,
    sections: Optional[List[Dict[str, Any]]] = None,
    citations: Optional[List[str]] = None,
    sources: Optional[List[Dict[str, Any]]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "type": "rag_response",
        "answer": answer,
        "confidence": confidence,
        "sections": sections or [],
        "citations": citations or [],
        "sources": sources or [],
        "metadata": metadata or {},
    }
