"""Brain Console - 知识库可视化 Web UI"""
from .app import create_console_app

__all__ = ["create_console_app"]
