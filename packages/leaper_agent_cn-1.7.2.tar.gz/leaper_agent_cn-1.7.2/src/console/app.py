"""Brain Console Web 应用 - aiohttp 实现"""

from __future__ import annotations

import json
import webbrowser
from pathlib import Path
from typing import Any

import aiosqlite
from aiohttp import web

from .static import INDEX_HTML


class BrainConsole:
    """Brain Console Web 应用"""

    def __init__(self, brain_path: str):
        self.brain_path = brain_path
        self._db: aiosqlite.Connection | None = None

    async def _get_db(self) -> aiosqlite.Connection:
        if self._db is None:
            self._db = await aiosqlite.connect(self.brain_path)
            self._db.row_factory = aiosqlite.Row
        return self._db

    async def close(self):
        if self._db:
            await self._db.close()
            self._db = None

    # --- Handlers ---

    async def handle_index(self, request: web.Request) -> web.Response:
        return web.Response(text=INDEX_HTML, content_type="text/html")

    async def handle_stats(self, request: web.Request) -> web.Response:
        db = await self._get_db()
        stats: dict[str, Any] = {}

        async with db.execute("SELECT COUNT(*) FROM entries WHERE status='active'") as cur:
            row = await cur.fetchone()
            stats["total"] = row[0] if row else 0

        async with db.execute(
            "SELECT entry_type, COUNT(*) as cnt FROM entries WHERE status='active' GROUP BY entry_type"
        ) as cur:
            stats["by_type"] = {r[0]: r[1] async for r in cur}

        async with db.execute(
            "SELECT category, COUNT(*) as cnt FROM entries WHERE status='active' GROUP BY category ORDER BY cnt DESC LIMIT 10"
        ) as cur:
            stats["by_category"] = {r[0]: r[1] async for r in cur}

        async with db.execute(
            "SELECT COUNT(*) FROM entries WHERE status='active' AND updated_at > datetime('now', '-7 days')"
        ) as cur:
            row = await cur.fetchone()
            stats["active_last_7d"] = row[0] if row else 0

        async with db.execute(
            "SELECT COUNT(*) FROM profiles"
        ) as cur:
            row = await cur.fetchone()
            stats["profiles_count"] = row[0] if row else 0

        return web.json_response(stats)

    async def handle_entries(self, request: web.Request) -> web.Response:
        db = await self._get_db()
        page = int(request.query.get("page", "1"))
        size = int(request.query.get("size", "20"))
        q = request.query.get("q", "").strip()
        offset = (page - 1) * size

        if q:
            sql = (
                "SELECT id, entry_type, content, category, confidence, access_count, "
                "last_accessed, created_at, status FROM entries "
                "WHERE status='active' AND content LIKE ? "
                "ORDER BY updated_at DESC LIMIT ? OFFSET ?"
            )
            params = (f"%{q}%", size, offset)
            count_sql = "SELECT COUNT(*) FROM entries WHERE status='active' AND content LIKE ?"
            count_params = (f"%{q}%",)
        else:
            sql = (
                "SELECT id, entry_type, content, category, confidence, access_count, "
                "last_accessed, created_at, status FROM entries "
                "WHERE status='active' ORDER BY updated_at DESC LIMIT ? OFFSET ?"
            )
            params = (size, offset)
            count_sql = "SELECT COUNT(*) FROM entries WHERE status='active'"
            count_params = ()

        async with db.execute(count_sql, count_params) as cur:
            row = await cur.fetchone()
            total = row[0] if row else 0

        entries = []
        async with db.execute(sql, params) as cur:
            async for row in cur:
                entries.append({
                    "id": row[0],
                    "entry_type": row[1],
                    "content": row[2],
                    "category": row[3],
                    "confidence": row[4],
                    "access_count": row[5],
                    "last_accessed": row[6],
                    "created_at": row[7],
                    "status": row[8],
                })

        return web.json_response({
            "entries": entries,
            "total": total,
            "page": page,
            "size": size,
            "pages": (total + size - 1) // size if size > 0 else 0,
        })

    async def handle_entry_detail(self, request: web.Request) -> web.Response:
        db = await self._get_db()
        entry_id = request.match_info["id"]

        async with db.execute(
            "SELECT id, agent_id, entry_type, content, category, confidence, "
            "access_count, last_accessed, source_ids, metadata, created_at, updated_at, status "
            "FROM entries WHERE id=?",
            (entry_id,),
        ) as cur:
            row = await cur.fetchone()

        if not row:
            raise web.HTTPNotFound(text="Entry not found")

        # Update access count
        await db.execute(
            "UPDATE entries SET access_count = access_count + 1, last_accessed = datetime('now') WHERE id=?",
            (entry_id,),
        )
        await db.commit()

        return web.json_response({
            "id": row[0],
            "agent_id": row[1],
            "entry_type": row[2],
            "content": row[3],
            "category": row[4],
            "confidence": row[5],
            "access_count": row[6],
            "last_accessed": row[7],
            "source_ids": json.loads(row[8]) if row[8] else [],
            "metadata": json.loads(row[9]) if row[9] else {},
            "created_at": row[10],
            "updated_at": row[11],
            "status": row[12],
        })

    async def handle_delete_entry(self, request: web.Request) -> web.Response:
        db = await self._get_db()
        entry_id = request.match_info["id"]

        await db.execute(
            "UPDATE entries SET status='deleted' WHERE id=?", (entry_id,)
        )
        await db.commit()
        return web.json_response({"ok": True, "id": entry_id})

    async def handle_pin_entry(self, request: web.Request) -> web.Response:
        db = await self._get_db()
        entry_id = request.match_info["id"]

        # Toggle pin via metadata
        async with db.execute("SELECT metadata FROM entries WHERE id=?", (entry_id,)) as cur:
            row = await cur.fetchone()
        if not row:
            raise web.HTTPNotFound(text="Entry not found")

        meta = json.loads(row[0]) if row[0] else {}
        meta["pinned"] = not meta.get("pinned", False)
        await db.execute(
            "UPDATE entries SET metadata=? WHERE id=?",
            (json.dumps(meta, ensure_ascii=False), entry_id),
        )
        await db.commit()
        return web.json_response({"ok": True, "pinned": meta["pinned"]})

    async def handle_evolution_history(self, request: web.Request) -> web.Response:
        db = await self._get_db()
        entries = []
        try:
            async with db.execute(
                "SELECT id, agent_id, entry_id_old, entry_id_new, category, "
                "old_content, new_content, transition_type, created_at "
                "FROM transitions ORDER BY created_at DESC LIMIT 50"
            ) as cur:
                async for row in cur:
                    entries.append({
                        "id": row[0],
                        "agent_id": row[1],
                        "entry_id_old": row[2],
                        "entry_id_new": row[3],
                        "category": row[4],
                        "old_content": row[5],
                        "new_content": row[6],
                        "transition_type": row[7],
                        "created_at": row[8],
                    })
        except Exception:
            pass  # Table may not exist
        return web.json_response({"history": entries})

    async def handle_profiles(self, request: web.Request) -> web.Response:
        db = await self._get_db()
        profiles = []
        try:
            async with db.execute(
                "SELECT id, agent_id, dimension, key, value, confidence, updated_at "
                "FROM profiles ORDER BY updated_at DESC"
            ) as cur:
                async for row in cur:
                    profiles.append({
                        "id": row[0],
                        "agent_id": row[1],
                        "dimension": row[2],
                        "key": row[3],
                        "value": row[4],
                        "confidence": row[5],
                        "updated_at": row[6],
                    })
        except Exception:
            pass
        return web.json_response({"profiles": profiles})


def create_app(brain_path: str) -> tuple[web.Application, BrainConsole]:
    """Create the aiohttp application."""
    console = BrainConsole(brain_path)
    app = web.Application()
    app.router.add_get("/", console.handle_index)
    app.router.add_get("/api/stats", console.handle_stats)
    app.router.add_get("/api/entries", console.handle_entries)
    app.router.add_get("/api/entries/{id}", console.handle_entry_detail)
    app.router.add_delete("/api/entries/{id}", console.handle_delete_entry)
    app.router.add_post("/api/entries/{id}/pin", console.handle_pin_entry)
    app.router.add_get("/api/evolution/history", console.handle_evolution_history)
    app.router.add_get("/api/profiles", console.handle_profiles)

    async def on_shutdown(app):
        await console.close()

    app.on_shutdown.append(on_shutdown)
    return app, console


async def create_console_app(brain_path: str, host: str = "127.0.0.1", port: int = 8765):
    """创建并启动 Brain Console Web 应用"""
    app, console = create_app(brain_path)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    await site.start()
    print(f"🧠 Brain Console 已启动: http://{host}:{port}")
    webbrowser.open(f"http://{host}:{port}")
    return runner
