"""Brain Console 前端 SPA - 内嵌 HTML/CSS/JS"""

INDEX_HTML = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🧠 Brain Console</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  --bg: #191919; --surface: #252525; --surface2: #2f2f2f;
  --border: #383838; --text: #e0e0e0; --text2: #999;
  --accent: #5b9bd5; --accent2: #7ec8e3; --danger: #e05555;
  --success: #4caf50; --radius: 8px;
}
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
a { color: var(--accent); text-decoration: none; }

/* Layout */
.header { background: var(--surface); border-bottom: 1px solid var(--border); padding: 16px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; }
.header h1 { font-size: 1.3rem; }
.search-box { display: flex; gap: 8px; }
.search-box input { background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius); padding: 8px 14px; color: var(--text); width: 260px; font-size: 14px; }
.search-box input:focus { outline: none; border-color: var(--accent); }

.container { max-width: 1200px; margin: 0 auto; padding: 20px; }
.tabs { display: flex; gap: 4px; margin-bottom: 20px; flex-wrap: wrap; }
.tab { padding: 8px 16px; border-radius: var(--radius); cursor: pointer; background: var(--surface); border: 1px solid var(--border); font-size: 14px; color: var(--text2); transition: all .2s; }
.tab.active, .tab:hover { background: var(--accent); color: #fff; border-color: var(--accent); }

/* Stats */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
.stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; }
.stat-card .label { color: var(--text2); font-size: 12px; margin-bottom: 4px; }
.stat-card .value { font-size: 28px; font-weight: 700; color: var(--accent); }

/* Chart */
.bar-chart { display: flex; flex-direction: column; gap: 8px; }
.bar-row { display: flex; align-items: center; gap: 10px; }
.bar-label { width: 100px; font-size: 12px; color: var(--text2); text-align: right; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bar { height: 22px; border-radius: 4px; background: var(--accent); transition: width .3s; min-width: 2px; }
.bar-value { font-size: 12px; color: var(--text2); }

/* Table */
.entries-table { width: 100%; border-collapse: collapse; font-size: 14px; }
.entries-table th, .entries-table td { padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); }
.entries-table th { color: var(--text2); font-weight: 500; background: var(--surface); position: sticky; top: 0; }
.entries-table tr:hover { background: var(--surface2); cursor: pointer; }
.entries-table .content-cell { max-width: 400px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; background: var(--surface2); color: var(--text2); }
.badge.fact { background: #1a3a2a; color: var(--success); }
.badge.preference { background: #1a2a3a; color: var(--accent2); }
.badge.skill { background: #3a2a1a; color: #e0a050; }

/* Pagination */
.pagination { display: flex; justify-content: center; gap: 8px; margin-top: 16px; }
.pagination button { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 6px 12px; color: var(--text); cursor: pointer; }
.pagination button:disabled { opacity: 0.4; cursor: default; }
.pagination button:hover:not(:disabled) { border-color: var(--accent); }

/* Detail */
.detail-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.6); display: none; z-index: 100; justify-content: center; align-items: center; }
.detail-overlay.show { display: flex; }
.detail-panel { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 24px; max-width: 700px; width: 90%; max-height: 80vh; overflow-y: auto; }
.detail-panel h3 { margin-bottom: 16px; }
.detail-panel .field { margin-bottom: 12px; }
.detail-panel .field-label { color: var(--text2); font-size: 12px; margin-bottom: 2px; }
.detail-panel .field-value { font-size: 14px; white-space: pre-wrap; word-break: break-all; }
.detail-actions { display: flex; gap: 8px; margin-top: 16px; }
.btn { padding: 8px 16px; border-radius: var(--radius); border: 1px solid var(--border); cursor: pointer; font-size: 13px; }
.btn-danger { background: var(--danger); color: #fff; border-color: var(--danger); }
.btn-close { background: var(--surface2); color: var(--text); }

/* Timeline */
.timeline { position: relative; padding-left: 24px; }
.timeline::before { content: ''; position: absolute; left: 8px; top: 0; bottom: 0; width: 2px; background: var(--border); }
.timeline-item { position: relative; margin-bottom: 20px; padding: 12px 16px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); }
.timeline-item::before { content: ''; position: absolute; left: -20px; top: 16px; width: 10px; height: 10px; border-radius: 50%; background: var(--accent); }
.timeline-item .time { font-size: 11px; color: var(--text2); }
.timeline-item .type { font-size: 12px; color: var(--accent); margin: 4px 0; }

/* Profile cards */
.profile-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; }
.profile-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; }
.profile-card .dim { color: var(--accent); font-size: 12px; font-weight: 600; margin-bottom: 8px; }
.profile-card .kv { display: flex; justify-content: space-between; padding: 4px 0; border-bottom: 1px solid var(--border); font-size: 13px; }
.profile-card .kv:last-child { border-bottom: none; }

.empty { text-align: center; padding: 40px; color: var(--text2); }

@media (max-width: 768px) {
  .header { padding: 12px 16px; }
  .search-box input { width: 160px; }
  .container { padding: 12px; }
  .entries-table { font-size: 12px; }
  .entries-table th:nth-child(n+4), .entries-table td:nth-child(n+4) { display: none; }
}
</style>
</head>
<body>
<div class="header">
  <h1>🧠 Brain Console</h1>
  <div class="search-box">
    <input id="searchInput" type="text" placeholder="搜索知识..." />
  </div>
</div>
<div class="container">
  <div class="tabs">
    <div class="tab active" data-tab="entries">📋 知识条目</div>
    <div class="tab" data-tab="stats">📊 统计</div>
    <div class="tab" data-tab="evolution">🔄 进化历史</div>
    <div class="tab" data-tab="profiles">👤 用户画像</div>
  </div>
  <div id="content"></div>
</div>

<div class="detail-overlay" id="detailOverlay">
  <div class="detail-panel" id="detailPanel"></div>
</div>

<script>
const state = { tab: 'entries', page: 1, size: 20, q: '', stats: null, entries: null, evolution: null, profiles: null };

// Tabs
document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
  t.classList.add('active');
  state.tab = t.dataset.tab;
  render();
}));

// Search
let searchTimer;
document.getElementById('searchInput').addEventListener('input', e => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { state.q = e.target.value; state.page = 1; loadEntries(); }, 300);
});

// Detail overlay
document.getElementById('detailOverlay').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeDetail();
});

function closeDetail() { document.getElementById('detailOverlay').classList.remove('show'); }

async function api(path) { const r = await fetch(path); return r.json(); }

async function loadStats() { state.stats = await api('/api/stats'); if (state.tab === 'stats') renderStats(); }
async function loadEntries() { state.entries = await api(`/api/entries?page=${state.page}&size=${state.size}&q=${encodeURIComponent(state.q)}`); if (state.tab === 'entries') renderEntries(); }
async function loadEvolution() { state.evolution = await api('/api/evolution/history'); if (state.tab === 'evolution') renderEvolution(); }
async function loadProfiles() { state.profiles = await api('/api/profiles'); if (state.tab === 'profiles') renderProfiles(); }

function render() {
  if (state.tab === 'stats') { loadStats(); renderStats(); }
  else if (state.tab === 'entries') { loadEntries(); }
  else if (state.tab === 'evolution') { loadEvolution(); }
  else if (state.tab === 'profiles') { loadProfiles(); }
}

function renderStats() {
  const s = state.stats;
  if (!s) { content('加载中...'); return; }
  const maxCat = Math.max(...Object.values(s.by_category || {}), 1);
  let bars = '';
  for (const [k, v] of Object.entries(s.by_category || {})) {
    bars += `<div class="bar-row"><span class="bar-label">${k || '(无)'}</span><div class="bar" style="width:${(v/maxCat)*100}%"></div><span class="bar-value">${v}</span></div>`;
  }
  content(`
    <div class="stats-grid">
      <div class="stat-card"><div class="label">总条目</div><div class="value">${s.total}</div></div>
      <div class="stat-card"><div class="label">近7天活跃</div><div class="value">${s.active_last_7d}</div></div>
      <div class="stat-card"><div class="label">用户画像</div><div class="value">${s.profiles_count}</div></div>
    </div>
    <h3 style="margin-bottom:12px">按类型</h3>
    <div class="stats-grid" style="margin-bottom:24px">
      ${Object.entries(s.by_type||{}).map(([k,v])=>`<div class="stat-card"><div class="label">${k||'(无)'}</div><div class="value">${v}</div></div>`).join('')}
    </div>
    <h3 style="margin-bottom:12px">按分类 Top 10</h3>
    <div class="bar-chart">${bars}</div>
  `);
}

function renderEntries() {
  const d = state.entries;
  if (!d) { content('加载中...'); return; }
  if (!d.entries.length) { content('<div class="empty">暂无知识条目</div>'); return; }
  let rows = d.entries.map(e => `
    <tr onclick="showDetail('${e.id}')">
      <td><code style="font-size:11px">${e.id.slice(0,8)}</code></td>
      <td class="content-cell">${escHtml(e.content?.slice(0,80) || '')}</td>
      <td><span class="badge ${e.entry_type}">${e.entry_type||'-'}</span></td>
      <td>${(e.confidence||0).toFixed(2)}</td>
      <td>${e.access_count||0}</td>
      <td style="font-size:12px;color:var(--text2)">${(e.last_accessed||'').slice(0,16)}</td>
    </tr>
  `).join('');
  const pages = d.pages || 1;
  content(`
    <table class="entries-table">
      <thead><tr><th>ID</th><th>内容</th><th>类型</th><th>置信度</th><th>访问</th><th>最后访问</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="pagination">
      <button ${state.page<=1?'disabled':''} onclick="changePage(-1)">← 上一页</button>
      <span style="padding:6px 12px;color:var(--text2)">${state.page} / ${pages}</span>
      <button ${state.page>=pages?'disabled':''} onclick="changePage(1)">下一页 →</button>
    </div>
  `);
}

function renderEvolution() {
  const d = state.evolution;
  if (!d) { content('加载中...'); return; }
  if (!d.history.length) { content('<div class="empty">暂无进化记录</div>'); return; }
  content(`<div class="timeline">${d.history.map(h => `
    <div class="timeline-item">
      <div class="time">${(h.created_at||'').slice(0,19)}</div>
      <div class="type">${h.transition_type} · ${h.category||''}</div>
      <div style="font-size:13px;margin-top:4px">${escHtml((h.new_content||'').slice(0,200))}</div>
    </div>
  `).join('')}</div>`);
}

function renderProfiles() {
  const d = state.profiles;
  if (!d) { content('加载中...'); return; }
  if (!d.profiles.length) { content('<div class="empty">暂无画像数据</div>'); return; }
  const grouped = {};
  d.profiles.forEach(p => { (grouped[p.dimension] = grouped[p.dimension]||[]).push(p); });
  content(`<div class="profile-grid">${Object.entries(grouped).map(([dim, items]) => `
    <div class="profile-card">
      <div class="dim">${dim}</div>
      ${items.map(i => `<div class="kv"><span>${i.key}</span><span>${escHtml((i.value||'').slice(0,60))}</span></div>`).join('')}
    </div>
  `).join('')}</div>`);
}

async function showDetail(id) {
  const d = await api('/api/entries/' + id);
  document.getElementById('detailPanel').innerHTML = `
    <h3>知识详情</h3>
    <div class="field"><div class="field-label">ID</div><div class="field-value">${d.id}</div></div>
    <div class="field"><div class="field-label">类型</div><div class="field-value">${d.entry_type||'-'}</div></div>
    <div class="field"><div class="field-label">分类</div><div class="field-value">${d.category||'-'}</div></div>
    <div class="field"><div class="field-label">置信度</div><div class="field-value">${d.confidence}</div></div>
    <div class="field"><div class="field-label">访问次数</div><div class="field-value">${d.access_count}</div></div>
    <div class="field"><div class="field-label">内容</div><div class="field-value">${escHtml(d.content||'')}</div></div>
    <div class="field"><div class="field-label">元数据</div><div class="field-value">${JSON.stringify(d.metadata||{},null,2)}</div></div>
    <div class="field"><div class="field-label">创建时间</div><div class="field-value">${d.created_at||'-'}</div></div>
    <div class="detail-actions">
      <button class="btn btn-danger" onclick="deleteEntry('${d.id}')">🗑 删除</button>
      <button class="btn" onclick="pinEntry('${d.id}')">📌 置顶</button>
      <button class="btn btn-close" onclick="closeDetail()">关闭</button>
    </div>
  `;
  document.getElementById('detailOverlay').classList.add('show');
}

async function deleteEntry(id) {
  if (!confirm('确定删除此条目？')) return;
  await fetch('/api/entries/' + id, { method: 'DELETE' });
  closeDetail();
  loadEntries();
}

async function pinEntry(id) {
  await fetch('/api/entries/' + id + '/pin', { method: 'POST' });
  closeDetail();
  loadEntries();
}

function changePage(delta) { state.page += delta; loadEntries(); }
function content(html) { document.getElementById('content').innerHTML = html; }
function escHtml(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// Init
render();
</script>
</body>
</html>"""
