"""中国网站特殊适配 — 处理反爬（UA、cookies、特殊解析）"""
from __future__ import annotations

import re
import json
from typing import Any

import httpx

# 通用请求头
_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
}


class WechatMPAdapter:
    """微信公众号文章抓取"""

    async def fetch_article(self, url: str) -> dict:
        """抓取公众号文章：标题、作者、正文、发布时间"""
        async with httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
            resp = await client.get(url, headers=_HEADERS)
            resp.raise_for_status()
            html = resp.text

        return self.parse_article(html)

    @staticmethod
    def parse_article(html: str) -> dict:
        """解析公众号文章 HTML"""
        # 标题
        title_m = re.search(r'var\s+msg_title\s*=\s*["\'](.+?)["\']', html)
        title = title_m.group(1) if title_m else ""
        if not title:
            title_m = re.search(r'<h1[^>]*class="rich_media_title"[^>]*>(.*?)</h1>', html, re.S)
            title = re.sub(r"<[^>]+>", "", title_m.group(1)).strip() if title_m else ""

        # 作者
        author_m = re.search(r'var\s+nickname\s*=\s*["\'](.+?)["\']', html)
        author = author_m.group(1) if author_m else ""

        # 发布时间
        time_m = re.search(r'var\s+publish_time\s*=\s*["\'](.+?)["\']', html)
        if not time_m:
            time_m = re.search(r'"publish_time"\s*:\s*"(.+?)"', html)
        publish_time = time_m.group(1) if time_m else ""

        # 正文
        content_m = re.search(
            r'<div[^>]*class="rich_media_content"[^>]*id="js_content"[^>]*>(.*?)</div>\s*<!--',
            html, re.S
        )
        if not content_m:
            content_m = re.search(r'id="js_content"[^>]*>(.*?)</div>', html, re.S)
        content_html = content_m.group(1) if content_m else ""
        # 简单去标签
        content = re.sub(r"<[^>]+>", "", content_html).strip()
        content = re.sub(r"\s+", "\n", content)

        return {
            "title": title,
            "author": author,
            "content": content,
            "publish_time": publish_time,
        }


class DouyinAdapter:
    """抖音内容提取"""

    async def fetch_video_info(self, url: str) -> dict:
        """提取视频信息：标题、作者、点赞、评论数"""
        async with httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
            resp = await client.get(url, headers=_HEADERS)
            resp.raise_for_status()
            html = resp.text

        return self.parse_video_info(html)

    @staticmethod
    def parse_video_info(html: str) -> dict:
        """解析抖音页面"""
        # 尝试从 SSR 数据中提取
        data_m = re.search(r'window\._SSR_DATA\s*=\s*({.+?})\s*</script>', html, re.S)
        if not data_m:
            data_m = re.search(r'RENDER_DATA["\s]*[=:]\s*({.+?})\s*</script>', html, re.S)

        if data_m:
            try:
                data = json.loads(data_m.group(1))
                # 结构可能变化，尽力提取
                return {"raw_data": data, "source": "ssr"}
            except json.JSONDecodeError:
                pass

        # fallback: meta 标签
        title_m = re.search(r'<title>(.*?)</title>', html)
        desc_m = re.search(r'name="description"\s+content="(.*?)"', html)
        return {
            "title": title_m.group(1) if title_m else "",
            "description": desc_m.group(1) if desc_m else "",
        }


class BilibiliAdapter:
    """B站内容提取"""

    async def fetch_video_info(self, url: str) -> dict:
        """提取视频信息"""
        async with httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
            resp = await client.get(url, headers=_HEADERS)
            resp.raise_for_status()
            html = resp.text

        return self.parse_video_info(html)

    @staticmethod
    def parse_video_info(html: str) -> dict:
        """解析 B 站视频页面"""
        # 从 __INITIAL_STATE__ 提取
        state_m = re.search(r'window\.__INITIAL_STATE__\s*=\s*({.+?});\s*\(function', html, re.S)
        if state_m:
            try:
                state = json.loads(state_m.group(1))
                video_data = state.get("videoData", {})
                return {
                    "title": video_data.get("title", ""),
                    "author": video_data.get("owner", {}).get("name", ""),
                    "views": video_data.get("stat", {}).get("view", 0),
                    "likes": video_data.get("stat", {}).get("like", 0),
                    "coins": video_data.get("stat", {}).get("coin", 0),
                    "description": video_data.get("desc", ""),
                }
            except json.JSONDecodeError:
                pass

        # fallback
        title_m = re.search(r'<title[^>]*>(.*?)</title>', html)
        return {"title": title_m.group(1) if title_m else ""}


class ZhihuAdapter:
    """知乎内容提取"""

    async def fetch_answer(self, url: str) -> dict:
        """提取知乎回答"""
        headers = {**_HEADERS, "Cookie": ""}
        async with httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            html = resp.text

        return self.parse_answer(html)

    @staticmethod
    def parse_answer(html: str) -> dict:
        """解析知乎回答页面"""
        # 从 initialData 提取
        data_m = re.search(r'id="js-initialData"[^>]*>(.*?)</script>', html, re.S)
        if data_m:
            try:
                data = json.loads(data_m.group(1))
                entities = data.get("initialState", {}).get("entities", {})
                answers = entities.get("answers", {})
                if answers:
                    first_answer = next(iter(answers.values()))
                    return {
                        "author": first_answer.get("author", {}).get("name", ""),
                        "content": first_answer.get("content", "")[:2000],
                        "voteup_count": first_answer.get("voteupCount", 0),
                        "comment_count": first_answer.get("commentCount", 0),
                    }
            except (json.JSONDecodeError, StopIteration):
                pass

        # fallback: meta
        title_m = re.search(r'<title[^>]*>(.*?)</title>', html)
        desc_m = re.search(r'name="description"\s+content="(.*?)"', html)
        return {
            "title": title_m.group(1) if title_m else "",
            "description": desc_m.group(1) if desc_m else "",
        }
