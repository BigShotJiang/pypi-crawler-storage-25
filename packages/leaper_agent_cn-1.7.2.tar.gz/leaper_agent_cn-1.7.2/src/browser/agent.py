"""浏览器自动化 Agent — Playwright 优先，httpx fallback"""
from __future__ import annotations

import json
import re
from typing import Any


# 默认 User-Agent，模拟正常浏览器
DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)


class BrowserAgent:
    """浏览器自动化 Agent
    基于 Playwright（可选依赖），fallback 到 httpx 简单抓取
    """

    def __init__(self, headless: bool = True):
        self._headless = headless
        self._browser = None
        self._page = None
        self._playwright = None
        self._pw_context = None
        self._playwright_available = False
        # fallback 时缓存最后抓取的 HTML
        self._last_html: str = ""
        self._last_url: str = ""

    async def initialize(self):
        """尝试初始化 Playwright，失败则标记为不可用"""
        try:
            from playwright.async_api import async_playwright
            self._pw_context = async_playwright()
            self._playwright = await self._pw_context.start()
            self._browser = await self._playwright.chromium.launch(headless=self._headless)
            self._page = await self._browser.new_page(user_agent=DEFAULT_UA)
            self._playwright_available = True
        except (ImportError, Exception):
            self._playwright_available = False

    async def navigate(self, url: str) -> str:
        """导航到 URL，返回页面文本内容"""
        if not self._playwright_available:
            return await self._fallback_navigate(url)
        await self._page.goto(url, wait_until="domcontentloaded")
        self._last_url = url
        return await self._page.inner_text("body")

    async def click(self, selector: str) -> bool:
        """点击元素"""
        if not self._playwright_available:
            return False
        try:
            await self._page.click(selector)
            return True
        except Exception:
            return False

    async def fill(self, selector: str, value: str) -> bool:
        """填充表单"""
        if not self._playwright_available:
            return False
        try:
            await self._page.fill(selector, value)
            return True
        except Exception:
            return False

    async def extract_text(self, selector: str = "body") -> str:
        """提取元素文本"""
        if not self._playwright_available:
            # fallback: 从缓存 HTML 提取
            return self._extract_text_from_html(self._last_html, selector)
        try:
            return await self._page.inner_text(selector)
        except Exception:
            return ""

    async def extract_links(self) -> list[dict]:
        """提取页面所有链接"""
        if not self._playwright_available:
            return self._extract_links_from_html(self._last_html)
        links = await self._page.eval_on_selector_all(
            "a[href]",
            "els => els.map(e => ({href: e.href, text: e.innerText.trim()}))"
        )
        return links

    async def screenshot(self, path: str = "") -> bytes:
        """截图"""
        if not self._playwright_available:
            return b""
        kwargs: dict[str, Any] = {"full_page": True}
        if path:
            kwargs["path"] = path
        return await self._page.screenshot(**kwargs)

    async def execute_js(self, script: str) -> str:
        """执行 JavaScript"""
        if not self._playwright_available:
            return ""
        result = await self._page.evaluate(script)
        return json.dumps(result, ensure_ascii=False) if result is not None else ""

    async def wait_for(self, selector: str, timeout: int = 5000) -> bool:
        """等待元素出现"""
        if not self._playwright_available:
            return False
        try:
            await self._page.wait_for_selector(selector, timeout=timeout)
            return True
        except Exception:
            return False

    async def close(self):
        """关闭浏览器"""
        if self._browser:
            await self._browser.close()
            self._browser = None
        if self._playwright:
            await self._playwright.stop() if hasattr(self._playwright, 'stop') else None
            self._playwright = None

    # ─── Fallback 方法 ───────────────────────────────────────────

    async def _fallback_navigate(self, url: str) -> str:
        """用 httpx 抓取 + 正则/bs4 解析"""
        import httpx

        headers = {"User-Agent": DEFAULT_UA}
        async with httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            self._last_html = resp.text
            self._last_url = url

        return self._html_to_text(self._last_html)

    # ─── 工具方法 ────────────────────────────────────────────────

    @staticmethod
    def _html_to_text(html: str) -> str:
        """HTML 转纯文本（优先 bs4，fallback 正则）"""
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "html.parser")
            # 移除 script/style
            for tag in soup(["script", "style"]):
                tag.decompose()
            return soup.get_text(separator="\n", strip=True)
        except ImportError:
            # 正则 fallback
            text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.S | re.I)
            text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.S | re.I)
            text = re.sub(r"<[^>]+>", "", text)
            text = re.sub(r"\s+", "\n", text)
            return text.strip()

    @staticmethod
    def _extract_text_from_html(html: str, selector: str) -> str:
        """从 HTML 中按选择器提取文本"""
        if not html:
            return ""
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "html.parser")
            el = soup.select_one(selector)
            return el.get_text(separator="\n", strip=True) if el else ""
        except ImportError:
            # 无 bs4 时返回全文
            return BrowserAgent._html_to_text(html)

    @staticmethod
    def _extract_links_from_html(html: str) -> list[dict]:
        """从 HTML 中提取链接"""
        if not html:
            return []
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, "html.parser")
            links = []
            for a in soup.find_all("a", href=True):
                links.append({"href": a["href"], "text": a.get_text(strip=True)})
            return links
        except ImportError:
            # 正则 fallback
            pattern = r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>'
            matches = re.findall(pattern, html, re.S | re.I)
            return [{"href": m[0], "text": re.sub(r"<[^>]+>", "", m[1]).strip()} for m in matches]
