"""浏览器工具 — 作为 Skill 注册到系统"""
from __future__ import annotations

from ..skills.base import Skill
from .agent import BrowserAgent


def create_browser_skill() -> Skill:
    """创建浏览器技能实例"""
    agent = BrowserAgent(headless=True)
    _initialized = False

    async def _execute(arguments: dict) -> str:
        nonlocal _initialized
        if not _initialized:
            await agent.initialize()
            _initialized = True

        action = arguments.get("action", "")
        url = arguments.get("url", "")
        selector = arguments.get("selector", "")
        value = arguments.get("value", "")

        if action == "navigate":
            if not url:
                return "错误：navigate 动作需要提供 url 参数"
            text = await agent.navigate(url)
            return text[:5000] if text else "页面内容为空"

        elif action == "click":
            if not selector:
                return "错误：click 动作需要提供 selector 参数"
            ok = await agent.click(selector)
            return "点击成功" if ok else "点击失败（无 Playwright 或元素不存在）"

        elif action == "fill":
            if not selector or not value:
                return "错误：fill 动作需要提供 selector 和 value 参数"
            ok = await agent.fill(selector, value)
            return "填充成功" if ok else "填充失败（无 Playwright 或元素不存在）"

        elif action == "extract_text":
            text = await agent.extract_text(selector or "body")
            return text[:5000] if text else "未提取到文本"

        elif action == "extract_links":
            links = await agent.extract_links()
            import json
            return json.dumps(links[:100], ensure_ascii=False)

        elif action == "screenshot":
            data = await agent.screenshot()
            return f"截图完成（{len(data)} bytes）" if data else "截图失败（无 Playwright）"

        else:
            return f"未知动作: {action}"

    return Skill(
        name="browser",
        description="浏览器自动化：导航网页、点击、填表、提取内容",
        triggers=["打开网页", "浏览", "网站", "登录", "表单"],
        parameters={
            "action": {
                "type": "string",
                "enum": ["navigate", "click", "fill", "extract_text", "extract_links", "screenshot"],
                "description": "浏览器动作",
                "required": True,
            },
            "url": {"type": "string", "description": "目标 URL（navigate 时必填）"},
            "selector": {"type": "string", "description": "CSS 选择器"},
            "value": {"type": "string", "description": "填充值（fill 时必填）"},
        },
        execute_fn=_execute,
    )


# 便捷别名
BrowserTool = create_browser_skill
