"""网关运行状态查询

提供运行时状态信息：在线渠道、活跃 session、消息统计、运行时间、内存使用。
"""
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class MessageStats:
    """消息处理统计"""
    total: int = 0
    success: int = 0
    failed: int = 0
    avg_latency_ms: float = 0.0
    _latencies: List[float] = field(default_factory=list, repr=False)

    def record(self, success: bool, latency_ms: float = 0.0) -> None:
        """记录一条消息处理结果"""
        self.total += 1
        if success:
            self.success += 1
        else:
            self.failed += 1
        if latency_ms > 0:
            self._latencies.append(latency_ms)
            # 只保留最近 1000 条
            if len(self._latencies) > 1000:
                self._latencies = self._latencies[-500:]
            self.avg_latency_ms = sum(self._latencies) / len(self._latencies)

    def to_dict(self) -> Dict[str, Any]:
        """转为字典"""
        return {
            "total": self.total,
            "success": self.success,
            "failed": self.failed,
            "avg_latency_ms": round(self.avg_latency_ms, 2),
        }


class GatewayStatus:
    """网关运行状态管理器

    跟踪：
    - 在线渠道列表
    - 活跃 session 数
    - 消息处理统计
    - 运行时间
    - 内存使用
    """

    def __init__(self) -> None:
        self._start_time: float = time.time()
        self._channels: Dict[str, str] = {}  # {name: status}
        self._active_sessions: int = 0
        self._stats = MessageStats()

    @property
    def uptime_seconds(self) -> float:
        """运行时间（秒）"""
        return time.time() - self._start_time

    @property
    def uptime_human(self) -> str:
        """人类可读的运行时间"""
        secs = int(self.uptime_seconds)
        days, secs = divmod(secs, 86400)
        hours, secs = divmod(secs, 3600)
        minutes, secs = divmod(secs, 60)
        parts = []
        if days:
            parts.append(f"{days}天")
        if hours:
            parts.append(f"{hours}小时")
        if minutes:
            parts.append(f"{minutes}分钟")
        parts.append(f"{secs}秒")
        return "".join(parts)

    def get_memory_mb(self) -> float:
        """当前进程内存使用（MB）"""
        try:
            import resource
            # Linux/macOS
            usage = resource.getrusage(resource.RUSAGE_SELF)
            return usage.ru_maxrss / 1024  # KB → MB
        except ImportError:
            pass
        try:
            # Windows: 用 os.popen
            import ctypes
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            # 简化：读 /proc/self/status 或返回估算值
            pass
        except Exception:
            pass
        # fallback：无法获取
        return 0.0

    # ─── 渠道管理 ──────────────────────────────────────
    def channel_online(self, name: str) -> None:
        """标记渠道上线"""
        self._channels[name] = "online"
        logger.info("渠道上线: %s", name)

    def channel_offline(self, name: str) -> None:
        """标记渠道下线"""
        self._channels[name] = "offline"
        logger.info("渠道下线: %s", name)

    def channel_error(self, name: str) -> None:
        """标记渠道异常"""
        self._channels[name] = "error"

    def get_online_channels(self) -> List[str]:
        """获取在线渠道列表"""
        return [n for n, s in self._channels.items() if s == "online"]

    # ─── Session 管理 ─────────────────────────────────
    def set_active_sessions(self, count: int) -> None:
        """更新活跃 session 数"""
        self._active_sessions = count

    # ─── 消息统计 ──────────────────────────────────────
    def record_message(self, success: bool, latency_ms: float = 0.0) -> None:
        """记录消息处理结果"""
        self._stats.record(success, latency_ms)

    # ─── 状态输出 ──────────────────────────────────────
    def get_status(self) -> Dict[str, Any]:
        """获取完整状态信息"""
        return {
            "status": "running",
            "uptime": self.uptime_human,
            "uptime_seconds": round(self.uptime_seconds, 1),
            "channels": {
                "online": self.get_online_channels(),
                "all": dict(self._channels),
            },
            "sessions": {
                "active": self._active_sessions,
            },
            "messages": self._stats.to_dict(),
            "memory_mb": round(self.get_memory_mb(), 1),
        }

    def get_health(self) -> Dict[str, Any]:
        """健康检查（轻量级）"""
        online = self.get_online_channels()
        all_channels = list(self._channels.keys())
        # 没有配置任何渠道时也算 ok；有渠道但全离线才是 degraded
        is_ok = (not all_channels) or len(online) > 0
        return {
            "status": "ok" if is_ok else "degraded",
            "channels_online": len(online),
            "uptime_seconds": round(self.uptime_seconds, 1),
        }
