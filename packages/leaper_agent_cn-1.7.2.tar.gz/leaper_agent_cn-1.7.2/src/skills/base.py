"""技能基类定义"""
from __future__ import annotations

import asyncio
import json
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable


@dataclass
class Skill:
    """技能定义"""
    name: str
    description: str
    version: str = "1.0.0"
    author: str = ""
    triggers: list[str] = field(default_factory=list)  # 触发关键词
    parameters: dict = field(default_factory=dict)  # JSON Schema (properties 格式)
    execute_fn: Callable | None = None  # 内置执行函数
    script_path: str = ""  # 外部脚本路径

    def to_tool_def(self) -> dict:
        """转为 OpenAI function calling 格式"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": self.parameters,
                    "required": [
                        k for k, v in self.parameters.items()
                        if isinstance(v, dict) and v.get("required", False)
                    ],
                },
            },
        }

    async def execute(self, arguments: dict) -> str:
        """执行技能"""
        # 优先使用内置函数
        if self.execute_fn is not None:
            if asyncio.iscoroutinefunction(self.execute_fn):
                return await self.execute_fn(arguments)
            return self.execute_fn(arguments)

        # 使用外部脚本（沙箱执行）
        if self.script_path and Path(self.script_path).exists():
            return await self._run_script(arguments)

        return f"技能 {self.name} 无可执行逻辑"

    async def _run_script(self, arguments: dict) -> str:
        """在子进程中执行脚本（沙箱 + 超时）"""
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, self.script_path,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            input_data = json.dumps(arguments, ensure_ascii=False).encode("utf-8")
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(input=input_data), timeout=30
            )
            if proc.returncode != 0:
                return f"脚本执行失败: {stderr.decode('utf-8', errors='replace')[:500]}"
            return stdout.decode("utf-8", errors="replace")[:5000]
        except asyncio.TimeoutError:
            return f"脚本执行超时（30s）"
        except Exception as e:
            return f"脚本执行异常: {e}"
