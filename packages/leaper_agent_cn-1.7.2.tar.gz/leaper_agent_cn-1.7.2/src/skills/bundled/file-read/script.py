"""读取文件"""
import json
import sys
from pathlib import Path


def main():
    args = json.loads(sys.stdin.read())
    path = args.get("path", "")
    encoding = args.get("encoding", "utf-8")

    if not path:
        print(json.dumps({"error": "path 不能为空"}, ensure_ascii=False))
        return

    p = Path(path).expanduser()
    if not p.exists():
        print(json.dumps({"error": f"文件不存在: {path}"}, ensure_ascii=False))
        return

    try:
        content = p.read_text(encoding=encoding)
        # 限制输出大小
        if len(content) > 10000:
            content = content[:10000] + "\n...[截断，共 {} 字符]".format(len(content))
        print(json.dumps({"content": content}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
