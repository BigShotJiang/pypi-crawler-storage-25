# file-read
> 读取文件内容

## Triggers
- 读文件
- read file
- 查看文件
- cat

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| path | string | yes | 文件路径 |
| encoding | string | no | 编码（默认utf-8） |

## Script
script.py
