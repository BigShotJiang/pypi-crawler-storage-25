# summary
> 文本摘要生成（基于提取式摘要）

## Triggers
- 摘要
- summary
- 总结
- 概括

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| text | string | yes | 需要摘要的文本 |
| max_sentences | integer | no | 最大句子数（默认3） |

## Script
script.py
