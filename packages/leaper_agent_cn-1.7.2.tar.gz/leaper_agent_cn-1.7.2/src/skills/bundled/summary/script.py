"""提取式文本摘要"""
import json
import re
import sys


def main():
    args = json.loads(sys.stdin.read())
    text = args.get("text", "")
    max_sentences = args.get("max_sentences", 3)

    if not text:
        print(json.dumps({"error": "text 不能为空"}, ensure_ascii=False))
        return

    # 简单按句子拆分，取前 N 句作为摘要
    sentences = re.split(r'[。！？.!?\n]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]

    summary = "。".join(sentences[:max_sentences])
    if summary and not summary.endswith(("。", "！", "？", ".", "!", "?")):
        summary += "。"

    print(json.dumps({"summary": summary, "original_length": len(text)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
