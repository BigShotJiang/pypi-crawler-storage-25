# translate
> 中英文互译

## Triggers
- 翻译
- translate
- 中译英
- 英译中

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| text | string | yes | 待翻译文本 |
| target | string | no | 目标语言（en或zh，默认自动检测） |

## Script
script.py
