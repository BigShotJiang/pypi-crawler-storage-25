"""简单中英翻译（基于字符检测 + 字典映射示例）"""
import json
import sys
import re


def is_chinese(text: str) -> bool:
    """判断文本是否主要是中文"""
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
    return chinese_chars > len(text) * 0.3


def main():
    args = json.loads(sys.stdin.read())
    text = args.get("text", "")
    target = args.get("target", "")

    if not text:
        print(json.dumps({"error": "text 不能为空"}, ensure_ascii=False))
        return

    # 自动检测方向
    if not target:
        target = "en" if is_chinese(text) else "zh"

    # 注：实际翻译需要调用 LLM provider，此处返回提示信息
    result = {
        "text": text,
        "target": target,
        "note": "翻译功能需配合 LLM provider 使用，此为离线占位",
        "detected_source": "zh" if is_chinese(text) else "en",
    }
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
