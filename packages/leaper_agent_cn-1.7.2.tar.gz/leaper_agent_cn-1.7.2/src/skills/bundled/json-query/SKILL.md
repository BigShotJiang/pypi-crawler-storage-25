# json-query
> JSON 数据查询和提取

## Triggers
- json
- 查询json
- jq
- 提取数据

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| data | string | yes | JSON 字符串 |
| path | string | yes | 查询路径（点号分隔，如 a.b.c） |

## Script
script.py
