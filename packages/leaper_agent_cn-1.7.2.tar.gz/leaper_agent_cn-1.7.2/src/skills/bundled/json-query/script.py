"""JSON 数据查询"""
import json
import sys


def query_path(data, path: str):
    """通过点号路径查询 JSON 数据"""
    keys = path.split(".")
    current = data
    for key in keys:
        if not key:
            continue
        # 支持数组索引 如 items.0
        if isinstance(current, list):
            try:
                current = current[int(key)]
            except (ValueError, IndexError):
                return None
        elif isinstance(current, dict):
            current = current.get(key)
            if current is None:
                return None
        else:
            return None
    return current


def main():
    args = json.loads(sys.stdin.read())
    data_str = args.get("data", "")
    path = args.get("path", "")

    if not data_str:
        print(json.dumps({"error": "data 不能为空"}, ensure_ascii=False))
        return

    try:
        data = json.loads(data_str) if isinstance(data_str, str) else data_str
    except json.JSONDecodeError as e:
        print(json.dumps({"error": f"JSON 解析失败: {e}"}, ensure_ascii=False))
        return

    if not path:
        print(json.dumps({"result": data}, ensure_ascii=False))
        return

    result = query_path(data, path)
    print(json.dumps({"result": result, "path": path}, ensure_ascii=False))


if __name__ == "__main__":
    main()
