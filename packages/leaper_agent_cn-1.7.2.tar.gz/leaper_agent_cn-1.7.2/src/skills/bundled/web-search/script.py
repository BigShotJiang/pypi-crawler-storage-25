"""DuckDuckGo 搜索"""
import json
import sys
import urllib.request
import urllib.parse


def main():
    args = json.loads(sys.stdin.read())
    query = args.get("query", "")
    max_results = args.get("max_results", 5)

    if not query:
        print(json.dumps({"error": "query 不能为空"}, ensure_ascii=False))
        return

    # 使用 DuckDuckGo HTML 版本（无需 API key）
    url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
    headers = {"User-Agent": "Mozilla/5.0 (compatible; LeaperBot/1.0)"}
    req = urllib.request.Request(url, headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            html = resp.read().decode("utf-8", errors="replace")

        # 简单提取结果
        import re
        results = []
        for m in re.finditer(r'class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>', html):
            link, title = m.group(1), re.sub(r'<[^>]+>', '', m.group(2))
            results.append({"title": title.strip(), "url": link})
            if len(results) >= max_results:
                break

        print(json.dumps({"results": results}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
