# web-search
> 使用 DuckDuckGo 搜索互联网信息

## Triggers
- 搜索
- search
- 查找
- 查一下

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| query | string | yes | 搜索关键词 |
| max_results | integer | no | 最大结果数（默认5） |

## Script
script.py
