"""执行 Python 代码（沙箱）"""
import json
import sys
import io
import contextlib


def main():
    args = json.loads(sys.stdin.read())
    code = args.get("code", "")

    if not code:
        print(json.dumps({"error": "code 不能为空"}, ensure_ascii=False))
        return

    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()

    try:
        with contextlib.redirect_stdout(stdout_buf), contextlib.redirect_stderr(stderr_buf):
            exec(code, {"__builtins__": __builtins__}, {})
        output = stdout_buf.getvalue()
        errors = stderr_buf.getvalue()
        result = {"stdout": output[:5000]}
        if errors:
            result["stderr"] = errors[:2000]
        print(json.dumps(result, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": str(e), "stdout": stdout_buf.getvalue()[:2000]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
