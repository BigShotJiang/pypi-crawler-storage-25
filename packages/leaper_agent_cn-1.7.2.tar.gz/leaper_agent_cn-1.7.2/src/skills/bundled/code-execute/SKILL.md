# code-execute
> 执行 Python 代码片段

## Triggers
- 执行代码
- run code
- python
- 运行

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| code | string | yes | Python 代码 |

## Script
script.py
