# calculator
> 数学计算器，支持四则运算和常用数学函数

## Triggers
- 计算
- calculate
- 算一下
- math

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| expression | string | yes | 数学表达式 |

## Script
script.py
