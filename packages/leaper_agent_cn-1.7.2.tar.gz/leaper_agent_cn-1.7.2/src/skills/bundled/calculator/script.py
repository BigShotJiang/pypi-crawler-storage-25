"""安全数学计算器"""
import json
import math
import sys


def main():
    args = json.loads(sys.stdin.read())
    expression = args.get("expression", "")

    if not expression:
        print(json.dumps({"error": "expression 不能为空"}, ensure_ascii=False))
        return

    # 安全环境：只允许数学操作
    allowed = {
        "abs": abs, "round": round, "min": min, "max": max,
        "sum": sum, "pow": pow, "int": int, "float": float,
        "math": math, "pi": math.pi, "e": math.e,
        "sqrt": math.sqrt, "log": math.log, "log10": math.log10,
        "sin": math.sin, "cos": math.cos, "tan": math.tan,
        "ceil": math.ceil, "floor": math.floor,
    }

    try:
        result = eval(expression, {"__builtins__": {}}, allowed)
        print(json.dumps({"result": result}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": f"计算失败: {e}"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
