# file-write
> 写入文件内容

## Triggers
- 写文件
- write file
- 保存文件
- save

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| path | string | yes | 文件路径 |
| content | string | yes | 文件内容 |
| encoding | string | no | 编码（默认utf-8） |

## Script
script.py
