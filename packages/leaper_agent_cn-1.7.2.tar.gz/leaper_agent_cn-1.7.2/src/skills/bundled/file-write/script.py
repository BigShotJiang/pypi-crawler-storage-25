"""写入文件"""
import json
import sys
from pathlib import Path


def main():
    args = json.loads(sys.stdin.read())
    path = args.get("path", "")
    content = args.get("content", "")
    encoding = args.get("encoding", "utf-8")

    if not path:
        print(json.dumps({"error": "path 不能为空"}, ensure_ascii=False))
        return

    p = Path(path).expanduser()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding=encoding)
        print(json.dumps({"success": True, "path": str(p), "bytes": len(content.encode(encoding))}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
