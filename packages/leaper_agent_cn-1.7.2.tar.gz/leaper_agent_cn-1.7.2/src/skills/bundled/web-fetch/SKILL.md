# web-fetch
> 抓取网页内容并提取文本

## Triggers
- 抓取网页
- fetch
- 获取网页
- 访问链接

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| url | string | yes | 网页 URL |
| max_chars | integer | no | 最大字符数（默认5000） |

## Script
script.py
