"""抓取网页内容"""
import json
import re
import sys
import urllib.request


def main():
    args = json.loads(sys.stdin.read())
    url = args.get("url", "")
    max_chars = args.get("max_chars", 5000)

    if not url:
        print(json.dumps({"error": "url 不能为空"}, ensure_ascii=False))
        return

    headers = {"User-Agent": "Mozilla/5.0 (compatible; LeaperBot/1.0)"}
    req = urllib.request.Request(url, headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            html = resp.read().decode("utf-8", errors="replace")

        # 简单去标签提取文本
        text = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.S)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.S)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()

        if len(text) > max_chars:
            text = text[:max_chars] + "..."

        print(json.dumps({"content": text, "url": url}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
