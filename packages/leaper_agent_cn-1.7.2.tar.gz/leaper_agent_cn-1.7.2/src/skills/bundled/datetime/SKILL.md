# datetime
> 日期时间查询和计算

## Triggers
- 时间
- 日期
- datetime
- 几点了
- 今天几号

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| action | string | no | 操作类型（now/format/delta，默认now） |
| format | string | no | 格式化模板 |
| days | integer | no | 日期偏移天数 |

## Script
script.py
