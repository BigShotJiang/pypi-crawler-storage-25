"""日期时间操作"""
import json
import sys
from datetime import datetime, timedelta


def main():
    args = json.loads(sys.stdin.read())
    action = args.get("action", "now")
    fmt = args.get("format", "%Y-%m-%d %H:%M:%S")
    days = args.get("days", 0)

    now = datetime.now()

    if action == "now":
        result = {
            "datetime": now.strftime(fmt),
            "timestamp": int(now.timestamp()),
            "weekday": ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][now.weekday()],
        }
    elif action == "delta":
        target = now + timedelta(days=days)
        result = {
            "datetime": target.strftime(fmt),
            "days_offset": days,
        }
    elif action == "format":
        result = {"formatted": now.strftime(fmt)}
    else:
        result = {"error": f"未知操作: {action}"}

    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
