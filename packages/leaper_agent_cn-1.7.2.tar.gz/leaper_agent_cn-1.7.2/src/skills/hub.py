"""Skill Hub - 远程 Skill 仓库管理、搜索、安装、版本控制"""

from __future__ import annotations

import json
import os
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class SkillInfo:
    """Skill 元信息"""
    name: str
    version: str = "0.0.1"
    description: str = ""
    source: str = ""  # 来源（git URL 或本地路径）
    installed_at: float = 0.0
    updated_at: float = 0.0
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "source": self.source,
            "installed_at": self.installed_at,
            "updated_at": self.updated_at,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SkillInfo":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


class SkillHub:
    """Skill 仓库管理器

    管理本地 Skill 的搜索、安装、卸载和更新
    """

    def __init__(self, skills_dir: str, registry_file: Optional[str] = None):
        """
        skills_dir: 本地 Skill 存储目录
        registry_file: Skill 注册表文件路径（JSON）
        """
        self._skills_dir = Path(skills_dir)
        self._skills_dir.mkdir(parents=True, exist_ok=True)
        self._registry_file = Path(registry_file or (self._skills_dir / ".registry.json"))
        self._registry: dict[str, SkillInfo] = {}
        self._load_registry()

    def _load_registry(self) -> None:
        """加载注册表"""
        if self._registry_file.exists():
            try:
                data = json.loads(self._registry_file.read_text(encoding="utf-8"))
                for name, info in data.items():
                    self._registry[name] = SkillInfo.from_dict(info)
            except (json.JSONDecodeError, KeyError):
                self._registry = {}

    def _save_registry(self) -> None:
        """保存注册表"""
        data = {name: info.to_dict() for name, info in self._registry.items()}
        self._registry_file.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def search_skills(self, query: str) -> list[SkillInfo]:
        """搜索已安装的 Skill

        在名称、描述、标签中匹配关键词
        """
        query_lower = query.lower()
        results = []
        for info in self._registry.values():
            if (
                query_lower in info.name.lower()
                or query_lower in info.description.lower()
                or any(query_lower in t.lower() for t in info.tags)
            ):
                results.append(info)
        return results

    def install_skill(self, name: str, source: str) -> None:
        """安装 Skill

        source 支持：
        - 本地路径（复制到 skills_dir）
        - git URL（需要系统有 git，暂用本地路径）
        """
        source_path = Path(source)
        if not source_path.exists():
            raise FileNotFoundError(f"Skill 来源不存在: {source}")
        if not source_path.is_dir():
            raise ValueError(f"Skill 来源必须是目录: {source}")

        # 检查 SKILL.md 是否存在
        skill_md = source_path / "SKILL.md"
        if not skill_md.exists():
            raise ValueError(f"Skill 目录缺少 SKILL.md: {source}")

        # 复制到 skills_dir
        dest = self._skills_dir / name
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(source_path, dest)

        # 读取版本信息
        version = "0.0.1"
        version_file = dest / "version.txt"
        if version_file.exists():
            version = version_file.read_text(encoding="utf-8").strip()

        # 读取描述（SKILL.md 第一行）
        description = ""
        try:
            lines = skill_md.read_text(encoding="utf-8").splitlines()
            for line in lines:
                line = line.strip()
                if line and not line.startswith("#"):
                    description = line[:200]
                    break
        except Exception:
            pass

        # 注册
        now = time.time()
        self._registry[name] = SkillInfo(
            name=name,
            version=version,
            description=description,
            source=str(source),
            installed_at=now,
            updated_at=now,
        )
        self._save_registry()

    def uninstall_skill(self, name: str) -> None:
        """卸载 Skill"""
        if name not in self._registry:
            raise KeyError(f"Skill 未安装: {name}")

        dest = self._skills_dir / name
        if dest.exists():
            shutil.rmtree(dest)

        del self._registry[name]
        self._save_registry()

    def update_skill(self, name: str) -> None:
        """更新 Skill（从原始来源重新安装）"""
        if name not in self._registry:
            raise KeyError(f"Skill 未安装: {name}")
        source = self._registry[name].source
        if not source:
            raise ValueError(f"Skill 缺少来源信息: {name}")
        self.install_skill(name, source)

    def list_skills(self) -> list[SkillInfo]:
        """列出所有已安装的 Skill"""
        return list(self._registry.values())

    def get_skill(self, name: str) -> Optional[SkillInfo]:
        """获取指定 Skill 信息"""
        return self._registry.get(name)
