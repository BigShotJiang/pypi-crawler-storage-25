"""技能管理器 — 统一管理所有技能的加载、查找、执行"""
from __future__ import annotations

from pathlib import Path

from .base import Skill
from .loader import SkillLoader


class SkillManager:
    """技能管理器"""

    def __init__(self, skill_dirs: list[str] | None = None):
        """
        skill_dirs: 技能搜索目录列表
        默认搜索：
        1. ~/.leaper-cn/skills/  （用户自定义）
        2. 内置 skills/  （bundled）
        """
        self._loader = SkillLoader()
        self._skills: dict[str, Skill] = {}

        if skill_dirs is None:
            skill_dirs = [
                str(Path.home() / ".leaper-cn" / "skills"),
                str(Path(__file__).parent / "bundled"),
            ]

        for d in skill_dirs:
            for skill in self._loader.load_from_directory(d):
                self._skills[skill.name] = skill

    def register(self, skill: Skill) -> None:
        """手动注册一个 skill"""
        self._skills[skill.name] = skill

    def get_all_skills(self) -> list[Skill]:
        """获取所有可用技能"""
        return list(self._skills.values())

    def find_skill(self, query: str) -> Skill | None:
        """根据用户输入匹配最相关的 skill（trigger 关键词匹配）"""
        query_lower = query.lower()

        # 精确名称匹配
        if query_lower in self._skills:
            return self._skills[query_lower]

        # trigger 关键词匹配
        best: Skill | None = None
        best_score = 0
        for skill in self._skills.values():
            for trigger in skill.triggers:
                if trigger.lower() in query_lower:
                    score = len(trigger)
                    if score > best_score:
                        best = skill
                        best_score = score
        return best

    def to_tool_defs(self) -> list[dict]:
        """将所有 skill 转为 tool_defs 格式"""
        return [s.to_tool_def() for s in self._skills.values()]

    async def execute_skill(self, name: str, arguments: dict) -> str:
        """执行指定 skill"""
        skill = self._skills.get(name)
        if not skill:
            return f"技能 {name} 不存在"
        return await skill.execute(arguments)
