"""Skill Preprocessing - Skill 执行前的预处理

支持变量替换、条件段落、引用文件展开、长度截断。
"""
from __future__ import annotations

import os
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional


class SkillPreprocessor:
    """Skill 内容预处理器"""

    def __init__(self, max_length: int = 50000) -> None:
        self.max_length = max_length
        # 变量模式: {{variable_name}}
        self._var_pattern = re.compile(r"\{\{(\w+)\}\}")
        # 条件段落: {{#if condition}}...{{/if}}
        self._if_pattern = re.compile(
            r"\{\{#if\s+(\w+)\}\}(.*?)\{\{/if\}\}",
            re.DOTALL
        )
        # 引用文件: {{@file:path/to/file}}
        self._ref_pattern = re.compile(r"\{\{@file:([^}]+)\}\}")

    def preprocess(self, skill_content: str, context: Dict[str, str]) -> str:
        """预处理 Skill 内容"""
        result = skill_content

        # 1. 条件段落处理（先于变量替换）
        result = self._process_conditions(result, context)

        # 2. 变量替换
        result = self._replace_variables(result, context)

        # 3. 引用文件展开
        workspace = context.get("workspace", "")
        result = self._expand_references(result, workspace)

        # 4. 长度截断
        if len(result) > self.max_length:
            result = result[:self.max_length] + "\n\n... [Skill 内容过长，已截断]"

        return result

    def _replace_variables(self, content: str, context: Dict[str, str]) -> str:
        """替换 {{variable}} 形式的变量"""
        # 内置变量
        now = datetime.now()
        builtins = {
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "datetime": now.strftime("%Y-%m-%d %H:%M:%S"),
            "year": str(now.year),
            "month": str(now.month),
            "day": str(now.day),
        }
        merged = {**builtins, **context}

        def replacer(m: re.Match) -> str:
            key = m.group(1)
            return merged.get(key, m.group(0))

        return self._var_pattern.sub(replacer, content)

    def _process_conditions(self, content: str, context: Dict[str, str]) -> str:
        """处理 {{#if var}}...{{/if}} 条件段落"""
        def replacer(m: re.Match) -> str:
            var_name = m.group(1)
            body = m.group(2)
            # 变量存在且非空则保留
            val = context.get(var_name, "")
            if val and val.lower() not in ("false", "0", "no", ""):
                return body.strip()
            return ""

        return self._if_pattern.sub(replacer, content)

    def _expand_references(self, content: str, workspace: str) -> str:
        """展开 {{@file:path}} 引用"""
        def replacer(m: re.Match) -> str:
            file_path = m.group(1).strip()
            # 相对路径基于 workspace
            if not os.path.isabs(file_path) and workspace:
                file_path = os.path.join(workspace, file_path)
            try:
                path = Path(file_path)
                if not path.exists():
                    return f"[引用文件不存在: {file_path}]"
                if path.stat().st_size > 100000:
                    return f"[引用文件过大: {file_path} ({path.stat().st_size} bytes)]"
                return path.read_text(encoding="utf-8", errors="replace")
            except Exception as e:
                return f"[引用文件读取失败: {e}]"

        return self._ref_pattern.sub(replacer, content)

    def extract_references(self, skill_content: str) -> List[str]:
        """提取 Skill 中引用的文件路径"""
        return [m.group(1).strip() for m in self._ref_pattern.finditer(skill_content)]

    def validate_references(self, references: List[str], workspace: str) -> List[str]:
        """验证引用文件是否存在，返回缺失的文件列表"""
        missing = []
        for ref in references:
            path = ref
            if not os.path.isabs(ref) and workspace:
                path = os.path.join(workspace, ref)
            if not Path(path).exists():
                missing.append(ref)
        return missing
