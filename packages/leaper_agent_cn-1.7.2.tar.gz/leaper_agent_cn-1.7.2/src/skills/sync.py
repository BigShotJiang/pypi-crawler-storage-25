"""Skill 同步 - 远程同步、增量更新、冲突检测"""

from __future__ import annotations

import json
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class SyncResult:
    """同步结果"""
    skill_name: str
    status: str  # "updated" | "conflict" | "unchanged" | "error"
    message: str
    timestamp: float = 0.0


class SkillSync:
    """Skill 同步管理器

    支持从源目录同步 Skill 到本地，增量更新，冲突检测
    """

    def __init__(self, local_dir: str, sync_state_file: Optional[str] = None):
        """
        local_dir: 本地 Skill 安装目录
        sync_state_file: 同步状态文件路径
        """
        self._local_dir = Path(local_dir)
        self._local_dir.mkdir(parents=True, exist_ok=True)
        self._state_file = Path(sync_state_file or (self._local_dir / ".sync_state.json"))
        self._state: dict[str, dict] = {}
        self._load_state()

    def _load_state(self) -> None:
        if self._state_file.exists():
            try:
                self._state = json.loads(self._state_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                self._state = {}

    def _save_state(self) -> None:
        self._state_file.write_text(
            json.dumps(self._state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def sync_skill(self, name: str, source_dir: str) -> SyncResult:
        """同步单个 Skill

        Args:
            name: Skill 名称
            source_dir: 源目录路径

        Returns:
            SyncResult
        """
        source = Path(source_dir)
        dest = self._local_dir / name
        now = time.time()

        if not source.exists():
            return SyncResult(name, "error", f"源目录不存在: {source_dir}", now)

        # 检查冲突：本地有修改且源也有更新
        if dest.exists() and self._has_local_changes(name, dest):
            source_mtime = self._get_dir_mtime(source)
            last_sync = self._state.get(name, {}).get("last_sync", 0)
            if source_mtime > last_sync:
                return SyncResult(name, "conflict", "本地和远程都有修改，需手动解决", now)

        # 检查是否需要更新
        if dest.exists():
            source_mtime = self._get_dir_mtime(source)
            last_sync = self._state.get(name, {}).get("last_sync", 0)
            if source_mtime <= last_sync:
                return SyncResult(name, "unchanged", "无需更新", now)

        # 执行同步
        try:
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(source, dest)
            self._state[name] = {
                "last_sync": now,
                "source": str(source),
                "file_hashes": self._snapshot_dir(dest),
            }
            self._save_state()
            return SyncResult(name, "updated", "同步成功", now)
        except Exception as e:
            return SyncResult(name, "error", f"同步失败: {e}", now)

    def check_conflicts(self, name: str, source_dir: str) -> bool:
        """检查是否存在冲突"""
        dest = self._local_dir / name
        if not dest.exists():
            return False
        source = Path(source_dir)
        if not source.exists():
            return False
        source_mtime = self._get_dir_mtime(source)
        last_sync = self._state.get(name, {}).get("last_sync", 0)
        return source_mtime > last_sync and self._has_local_changes(name, dest)

    def _has_local_changes(self, name: str, dest: Path) -> bool:
        """检查本地是否有修改"""
        saved = self._state.get(name, {}).get("file_hashes", {})
        if not saved:
            return True
        current = self._snapshot_dir(dest)
        return current != saved

    @staticmethod
    def _snapshot_dir(path: Path) -> dict[str, float]:
        """快照目录文件修改时间"""
        result: dict[str, float] = {}
        for f in path.rglob("*"):
            if f.is_file():
                rel = str(f.relative_to(path))
                result[rel] = f.stat().st_mtime
        return result

    @staticmethod
    def _get_dir_mtime(path: Path) -> float:
        """获取目录中最新文件修改时间"""
        latest = 0.0
        for f in path.rglob("*"):
            if f.is_file():
                latest = max(latest, f.stat().st_mtime)
        return latest
