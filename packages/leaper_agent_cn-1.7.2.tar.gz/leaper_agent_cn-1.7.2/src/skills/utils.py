"""Skill Utils - Skill 相关工具函数

解析 SKILL.md、匹配 Skill、格式化 Skill。
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional


def parse_skill_md(content: str) -> Dict[str, str]:
    """解析 SKILL.md 文件，提取关键字段

    返回 dict 包含: name, description, triggers, location, references
    """
    result: Dict[str, str] = {
        "name": "",
        "description": "",
        "triggers": "",
        "location": "",
        "references": "",
    }

    # 提取标题作为 name
    title_match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
    if title_match:
        result["name"] = title_match.group(1).strip()

    # 提取 description（第一个非标题段落）
    lines = content.split("\n")
    desc_lines = []
    in_desc = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#"):
            if in_desc:
                break
            in_desc = True
            continue
        if in_desc and stripped:
            desc_lines.append(stripped)
        elif in_desc and not stripped and desc_lines:
            break
    if desc_lines:
        result["description"] = " ".join(desc_lines)

    # 提取 triggers（Triggers: 或 触发词: 后面的内容）
    trigger_match = re.search(
        r"(?:Triggers?|触发词?)[：:]\s*(.+?)(?:\n\n|\n#|$)",
        content, re.DOTALL | re.IGNORECASE
    )
    if trigger_match:
        result["triggers"] = trigger_match.group(1).strip()

    # 提取 location
    loc_match = re.search(r"(?:Location|位置)[：:]\s*(.+)", content, re.IGNORECASE)
    if loc_match:
        result["location"] = loc_match.group(1).strip()

    # 提取 references
    ref_match = re.search(
        r"(?:References?|引用|参考)[：:]\s*(.+?)(?:\n\n|\n#|$)",
        content, re.DOTALL | re.IGNORECASE
    )
    if ref_match:
        result["references"] = ref_match.group(1).strip()

    return result


def match_skill(message: str, skills: List[Dict[str, str]]) -> Optional[Dict[str, str]]:
    """匹配最相关的 Skill

    基于关键词匹配 + 描述相似度打分。
    返回最佳匹配或 None。
    """
    if not message or not skills:
        return None

    msg_lower = message.lower()
    msg_words = set(re.findall(r"\w+", msg_lower))

    best_skill = None
    best_score = 0

    for skill in skills:
        score = 0

        # 1. name 完全匹配
        name = skill.get("name", "").lower()
        if name and name in msg_lower:
            score += 10

        # 2. triggers 匹配
        triggers = skill.get("triggers", "").lower()
        if triggers:
            trigger_words = re.findall(r"[\w\u4e00-\u9fff]+", triggers)
            for tw in trigger_words:
                if tw in msg_lower:
                    score += 5

        # 3. description 词重叠
        desc = skill.get("description", "").lower()
        desc_words = set(re.findall(r"\w+", desc))
        overlap = msg_words & desc_words
        score += len(overlap)

        if score > best_score:
            best_score = score
            best_skill = skill

    if best_score > 0:
        return best_skill
    return None


def format_skill_for_prompt(skill: Dict[str, str]) -> str:
    """格式化 Skill 供 system prompt 注入"""
    parts = []
    name = skill.get("name", "未知")
    desc = skill.get("description", "")
    triggers = skill.get("triggers", "")
    location = skill.get("location", "")

    parts.append(f"### {name}")
    if desc:
        parts.append(desc)
    if triggers:
        parts.append(f"触发词: {triggers}")
    if location:
        parts.append(f"位置: {location}")

    return "\n".join(parts)
