"""Skill 安全守卫 - Skill 格式检查、危险代码检测"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

from ..constants import SKILL_MANIFEST_FILE, SKILL_MAX_SCRIPT_SIZE


# 脚本中的危险模式
_DANGEROUS_PATTERNS: list[tuple[str, str]] = [
    (r"\bos\.system\s*\(", "使用 os.system() 执行命令"),
    (r"\bsubprocess\.call\s*\(.*shell\s*=\s*True", "subprocess shell=True"),
    (r"\beval\s*\(", "使用 eval()"),
    (r"\bexec\s*\(", "使用 exec()"),
    (r"\b__import__\s*\(", "动态导入 __import__()"),
    (r"\bopen\s*\([^)]*['\"]\/etc\/", "读取 /etc 系统文件"),
    (r"\brmtree\s*\(", "递归删除目录"),
    (r"\bos\.remove\s*\(", "删除文件"),
    (r"\bos\.unlink\s*\(", "删除文件"),
    (r"\bctypes\b", "使用 ctypes（可能不安全）"),
    (r"\bsocket\.socket\s*\(", "创建原始 socket"),
]


def validate_skill(skill_dir: str) -> list[str]:
    """验证 Skill 目录的安全性和格式

    返回问题列表（空列表 = 通过）
    """
    issues: list[str] = []
    skill_path = Path(skill_dir)

    if not skill_path.exists():
        return [f"Skill 目录不存在: {skill_dir}"]
    if not skill_path.is_dir():
        return [f"路径不是目录: {skill_dir}"]

    # 1. 检查 SKILL.md
    skill_md = skill_path / SKILL_MANIFEST_FILE
    if not skill_md.exists():
        issues.append(f"缺少 {SKILL_MANIFEST_FILE}")
    else:
        issues.extend(_check_skill_md(skill_md))

    # 2. 检查 scripts/ 目录
    scripts_dir = skill_path / "scripts"
    if scripts_dir.exists():
        issues.extend(_check_scripts(scripts_dir))

    # 3. 检查文件大小
    for file in skill_path.rglob("*"):
        if file.is_file() and file.stat().st_size > SKILL_MAX_SCRIPT_SIZE:
            issues.append(f"文件过大（>{SKILL_MAX_SCRIPT_SIZE // 1024}KB）: {file.name}")

    return issues


def _check_skill_md(skill_md: Path) -> list[str]:
    """检查 SKILL.md 格式"""
    issues: list[str] = []
    try:
        content = skill_md.read_text(encoding="utf-8")
    except Exception as e:
        return [f"无法读取 SKILL.md: {e}"]

    if not content.strip():
        issues.append("SKILL.md 内容为空")
        return issues

    # 检查必要段落
    if "# " not in content:
        issues.append("SKILL.md 缺少标题（# 开头）")

    # 检查描述
    lines = content.splitlines()
    has_description = False
    for line in lines:
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and not stripped.startswith("```"):
            has_description = True
            break
    if not has_description:
        issues.append("SKILL.md 缺少描述文本")

    return issues


def _check_scripts(scripts_dir: Path) -> list[str]:
    """检查 scripts/ 目录中的危险代码"""
    issues: list[str] = []
    for script in scripts_dir.rglob("*"):
        if not script.is_file():
            continue
        if script.suffix not in (".py", ".js", ".sh", ".ps1", ".mjs"):
            continue
        try:
            content = script.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        for pattern, description in _DANGEROUS_PATTERNS:
            if re.search(pattern, content):
                issues.append(f"⚠ {script.name}: {description}")

    return issues


def is_skill_safe_to_run(skill_dir: str) -> bool:
    """快速检查 Skill 是否安全可运行"""
    issues = validate_skill(skill_dir)
    # 只有 ⚠ 开头的才是真正的安全问题
    security_issues = [i for i in issues if i.startswith("⚠")]
    return len(security_issues) == 0
