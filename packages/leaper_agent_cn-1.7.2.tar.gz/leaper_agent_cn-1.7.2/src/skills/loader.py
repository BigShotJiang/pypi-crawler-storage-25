"""技能加载器 — 从目录扫描并解析 SKILL.md"""
from __future__ import annotations

import re
from pathlib import Path

from .base import Skill


class SkillLoader:
    """从目录加载 Skill"""

    def load_from_directory(self, skill_dir: str) -> list[Skill]:
        """扫描目录，读取每个 SKILL.md 文件解析为 Skill 对象"""
        skills: list[Skill] = []
        base = Path(skill_dir)
        if not base.exists():
            return skills

        for child in base.iterdir():
            if not child.is_dir():
                continue
            skill_md = child / "SKILL.md"
            if not skill_md.exists():
                continue
            try:
                content = skill_md.read_text(encoding="utf-8")
                skill = self.parse_skill_md(content)
                # 设置脚本路径
                script_file = child / "script.py"
                if script_file.exists():
                    skill.script_path = str(script_file)
                skills.append(skill)
            except Exception:
                continue  # 解析失败静默跳过

        return skills

    def parse_skill_md(self, content: str) -> Skill:
        """解析 SKILL.md 文件为 Skill 对象

        格式：
        # Skill Name
        > Description

        ## Triggers
        - keyword1

        ## Parameters
        | Name | Type | Required | Description |
        |------|------|----------|-------------|
        | query | string | yes | 搜索内容 |

        ## Script
        script.py
        """
        lines = content.strip().split("\n")

        name = ""
        description = ""
        triggers: list[str] = []
        parameters: dict = {}
        version = "1.0.0"
        author = ""

        section = ""
        for line in lines:
            stripped = line.strip()

            # 标题 = 技能名
            if stripped.startswith("# ") and not stripped.startswith("## "):
                name = stripped[2:].strip()
                continue

            # 描述（blockquote）
            if stripped.startswith("> ") and not description:
                description = stripped[2:].strip()
                continue

            # 段落标题
            if stripped.startswith("## "):
                section = stripped[3:].strip().lower()
                continue

            # Triggers 段
            if section == "triggers" and stripped.startswith("- "):
                triggers.append(stripped[2:].strip())
                continue

            # Parameters 段（Markdown 表格）
            if section == "parameters" and stripped.startswith("|"):
                # 跳过表头和分隔行
                if "---" in stripped or "Name" in stripped:
                    continue
                cols = [c.strip() for c in stripped.split("|")[1:-1]]
                if len(cols) >= 4:
                    p_name, p_type, p_required, p_desc = cols[0], cols[1], cols[2], cols[3]
                    parameters[p_name] = {
                        "type": p_type,
                        "description": p_desc,
                    }
                    if p_required.lower() in ("yes", "true", "1"):
                        parameters[p_name]["required"] = True
                continue

            # Version
            if section == "version" and stripped:
                version = stripped
                continue

            # Author
            if section == "author" and stripped:
                author = stripped
                continue

        return Skill(
            name=name or "unknown",
            description=description or name,
            version=version,
            author=author,
            triggers=triggers,
            parameters=parameters,
        )
