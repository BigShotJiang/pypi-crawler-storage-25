"""Plugin 基类 — 所有插件的父类

插件通过继承 Plugin 类并重写生命周期方法来实现功能。
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class Plugin:
    """插件基类

    所有插件必须继承此类。可重写以下生命周期方法：
    - on_load: 插件加载时调用
    - on_unload: 插件卸载时调用
    - on_message: 收到用户消息时调用
    - on_response: 发出响应前调用
    - on_tool_call: 工具调用前调用
    - register_tools: 注册插件提供的工具

    属性:
        name: 插件名称
        version: 插件版本
        description: 插件描述
        enabled: 是否启用
    """

    name: str = "unnamed"
    version: str = "0.1.0"
    description: str = ""
    enabled: bool = True

    def __init__(self) -> None:
        self._loaded = False
        self._config: Dict[str, Any] = {}

    @property
    def loaded(self) -> bool:
        """是否已加载"""
        return self._loaded

    async def on_load(self, config: Dict[str, Any]) -> None:
        """插件加载时调用

        Args:
            config: 插件配置字典
        """
        self._config = config
        self._loaded = True

    async def on_unload(self) -> None:
        """插件卸载时调用"""
        self._loaded = False

    async def on_message(self, message: str, context: Dict[str, Any]) -> Optional[str]:
        """收到用户消息时调用

        返回 None 表示不拦截，返回字符串表示拦截并使用该字符串作为响应。

        Args:
            message: 用户消息
            context: 上下文字典

        Returns:
            拦截的响应或 None
        """
        return None

    async def on_response(self, response: str, context: Dict[str, Any]) -> str:
        """响应发出前调用，可修改响应

        Args:
            response: 原始响应
            context: 上下文字典

        Returns:
            修改后的响应
        """
        return response

    async def on_tool_call(self, tool_name: str, args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """工具调用前调用

        返回 None 表示不拦截，返回字典表示替换参数。

        Args:
            tool_name: 工具名称
            args: 工具参数

        Returns:
            修改后的参数或 None
        """
        return None

    def register_tools(self) -> List[Dict[str, Any]]:
        """注册插件提供的工具

        Returns:
            工具定义列表
        """
        return []

    def __repr__(self) -> str:
        return f"<Plugin {self.name} v{self.version} loaded={self._loaded}>"
