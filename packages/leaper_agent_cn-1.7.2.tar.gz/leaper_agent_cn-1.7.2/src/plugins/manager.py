"""PluginManager — 插件生命周期管理器

支持动态发现、加载、卸载插件，以及消息/响应/工具调用的 dispatch。
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import Plugin

logger = logging.getLogger(__name__)


@dataclass
class PluginInfo:
    """插件信息"""
    name: str
    version: str
    description: str
    enabled: bool
    loaded: bool
    path: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "enabled": self.enabled,
            "loaded": self.loaded,
            "path": self.path,
        }


class PluginManager:
    """插件管理器

    负责插件的发现、加载、卸载和生命周期管理。
    插件可以是单个 .py 文件或包含 __init__.py 的目录。

    用法：
        manager = PluginManager()
        manager.load_all("~/.leaper-cn/plugins")
        result = await manager.dispatch_message("你好", {})
    """

    def __init__(self) -> None:
        self._plugins: Dict[str, Plugin] = {}
        self._plugin_paths: Dict[str, str] = {}

    def load_plugin(self, plugin_path: str, config: Optional[Dict[str, Any]] = None) -> str:
        """加载单个插件

        Args:
            plugin_path: 插件文件或目录路径
            config: 插件配置

        Returns:
            插件名称

        Raises:
            FileNotFoundError: 插件路径不存在
            ValueError: 无法从插件中找到 Plugin 子类
        """
        path = Path(plugin_path)
        if not path.exists():
            raise FileNotFoundError(f"插件路径不存在: {plugin_path}")

        plugin_cls = self._import_plugin_class(path)
        if plugin_cls is None:
            raise ValueError(f"未在 {plugin_path} 中找到 Plugin 子类")

        plugin = plugin_cls()

        # 如果已存在同名插件，先卸载
        if plugin.name in self._plugins:
            logger.info(f"替换已有插件: {plugin.name}")
            # 不 await on_unload，同步上下文中无法
            self._plugins.pop(plugin.name)

        self._plugins[plugin.name] = plugin
        self._plugin_paths[plugin.name] = str(path)
        logger.info(f"已加载插件: {plugin.name} v{plugin.version}")
        return plugin.name

    async def load_plugin_async(self, plugin_path: str, config: Optional[Dict[str, Any]] = None) -> str:
        """异步加载插件（会调用 on_load）"""
        name = self.load_plugin(plugin_path, config)
        plugin = self._plugins[name]
        await plugin.on_load(config or {})
        return name

    def unload_plugin(self, name: str) -> bool:
        """卸载插件

        Args:
            name: 插件名称

        Returns:
            是否成功卸载
        """
        if name not in self._plugins:
            return False

        self._plugins.pop(name)
        self._plugin_paths.pop(name, None)
        logger.info(f"已卸载插件: {name}")
        return True

    async def unload_plugin_async(self, name: str) -> bool:
        """异步卸载插件（会调用 on_unload）"""
        plugin = self._plugins.get(name)
        if plugin is None:
            return False

        await plugin.on_unload()
        return self.unload_plugin(name)

    def list_plugins(self) -> List[PluginInfo]:
        """列出所有已加载的插件"""
        result = []
        for name, plugin in self._plugins.items():
            result.append(PluginInfo(
                name=plugin.name,
                version=plugin.version,
                description=plugin.description,
                enabled=plugin.enabled,
                loaded=plugin.loaded,
                path=self._plugin_paths.get(name, ""),
            ))
        return result

    def get_plugin(self, name: str) -> Optional[Plugin]:
        """根据名称获取插件"""
        return self._plugins.get(name)

    def has_plugin(self, name: str) -> bool:
        """检查是否已加载指定插件"""
        return name in self._plugins

    # ── Dispatch hooks ──

    async def dispatch_message(self, message: str, context: Dict[str, Any]) -> Optional[str]:
        """分发消息到所有启用的插件

        如果某个插件返回非 None，则视为拦截，立即返回。

        Args:
            message: 用户消息
            context: 上下文

        Returns:
            拦截的响应或 None
        """
        for plugin in self._active_plugins():
            try:
                result = await plugin.on_message(message, context)
                if result is not None:
                    logger.debug(f"消息被插件 {plugin.name} 拦截")
                    return result
            except Exception as e:
                logger.warning(f"插件 {plugin.name}.on_message 异常: {e}")
        return None

    async def dispatch_response(self, response: str, context: Dict[str, Any]) -> str:
        """分发响应到所有启用的插件（链式修改）

        Args:
            response: 原始响应
            context: 上下文

        Returns:
            修改后的响应
        """
        result = response
        for plugin in self._active_plugins():
            try:
                result = await plugin.on_response(result, context)
            except Exception as e:
                logger.warning(f"插件 {plugin.name}.on_response 异常: {e}")
        return result

    async def dispatch_tool_call(self, tool_name: str, args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """分发工具调用到所有启用的插件

        如果某个插件返回非 None，则视为修改参数。

        Args:
            tool_name: 工具名称
            args: 工具参数

        Returns:
            修改后的参数或 None
        """
        for plugin in self._active_plugins():
            try:
                result = await plugin.on_tool_call(tool_name, args)
                if result is not None:
                    return result
            except Exception as e:
                logger.warning(f"插件 {plugin.name}.on_tool_call 异常: {e}")
        return None

    def collect_tools(self) -> List[Dict[str, Any]]:
        """收集所有插件注册的工具"""
        tools = []
        for plugin in self._active_plugins():
            try:
                plugin_tools = plugin.register_tools()
                tools.extend(plugin_tools)
            except Exception as e:
                logger.warning(f"插件 {plugin.name}.register_tools 异常: {e}")
        return tools

    # ── 发现 ──

    def discover_plugins(self, plugins_dir: str) -> List[str]:
        """发现目录下的插件

        Args:
            plugins_dir: 插件目录

        Returns:
            发现的插件路径列表
        """
        path = Path(plugins_dir).expanduser()
        if not path.is_dir():
            return []

        found = []
        for item in sorted(path.iterdir()):
            if item.is_file() and item.suffix == ".py" and not item.name.startswith("_"):
                found.append(str(item))
            elif item.is_dir() and (item / "__init__.py").exists():
                found.append(str(item))
        return found

    def load_all(self, plugins_dir: str, configs: Optional[Dict[str, Dict[str, Any]]] = None) -> int:
        """发现并加载目录下所有插件

        Args:
            plugins_dir: 插件目录
            configs: 各插件的配置 {name: config}

        Returns:
            成功加载的插件数
        """
        paths = self.discover_plugins(plugins_dir)
        loaded = 0
        for p in paths:
            try:
                self.load_plugin(p)
                loaded += 1
            except Exception as e:
                logger.warning(f"加载插件失败 {p}: {e}")
        return loaded

    # ── 内部方法 ──

    def _active_plugins(self) -> List[Plugin]:
        """获取所有已启用的插件"""
        return [p for p in self._plugins.values() if p.enabled]

    def _import_plugin_class(self, path: Path) -> Optional[type]:
        """从路径导入 Plugin 子类

        Args:
            path: 插件文件或目录

        Returns:
            Plugin 子类或 None
        """
        try:
            if path.is_file():
                module_name = f"_leaper_plugin_{path.stem}"
                spec = importlib.util.spec_from_file_location(module_name, str(path))
                if spec is None or spec.loader is None:
                    return None
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
            elif path.is_dir():
                init_file = path / "__init__.py"
                if not init_file.exists():
                    return None
                module_name = f"_leaper_plugin_{path.name}"
                spec = importlib.util.spec_from_file_location(
                    module_name, str(init_file),
                    submodule_search_locations=[str(path)]
                )
                if spec is None or spec.loader is None:
                    return None
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
            else:
                return None

            # 查找 Plugin 子类
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    isinstance(attr, type)
                    and issubclass(attr, Plugin)
                    and attr is not Plugin
                ):
                    return attr
            return None
        except Exception as e:
            logger.warning(f"导入插件模块失败 {path}: {e}")
            return None
