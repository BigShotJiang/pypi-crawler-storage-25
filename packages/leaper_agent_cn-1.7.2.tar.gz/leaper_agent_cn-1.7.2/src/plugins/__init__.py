"""插件系统

提供 Plugin 基类和 PluginManager，支持动态加载/卸载插件。
"""

from src.plugins.base import Plugin
from src.plugins.manager import PluginManager, PluginInfo

__all__ = ["Plugin", "PluginManager", "PluginInfo"]
