"""API 调用频率告警插件"""

from __future__ import annotations

import logging
import time
from collections import deque
from typing import Any, Dict, Optional

from ..base import Plugin

logger = logging.getLogger(__name__)


class RateAlertPlugin(Plugin):
    """API 调用频率告警

    当工具调用频率超过阈值时记录警告。

    配置:
        max_calls: 窗口内最大调用次数，默认 30
        window_seconds: 时间窗口（秒），默认 60
    """

    name = "rate_alert"
    version = "0.1.0"
    description = "API 调用频率告警"

    def __init__(self) -> None:
        super().__init__()
        self._max_calls: int = 30
        self._window_seconds: float = 60.0
        self._call_times: deque = deque()
        self._alert_count: int = 0

    async def on_load(self, config: Dict[str, Any]) -> None:
        await super().on_load(config)
        self._max_calls = config.get("max_calls", 30)
        self._window_seconds = config.get("window_seconds", 60.0)

    async def on_tool_call(self, tool_name: str, args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """记录工具调用，检查频率"""
        now = time.monotonic()
        self._call_times.append(now)

        # 清理过期记录
        cutoff = now - self._window_seconds
        while self._call_times and self._call_times[0] < cutoff:
            self._call_times.popleft()

        # 检查是否超阈值
        if len(self._call_times) > self._max_calls:
            self._alert_count += 1
            logger.warning(
                f"[RateAlert] 工具调用频率过高: "
                f"{len(self._call_times)} 次/{self._window_seconds}s "
                f"(阈值: {self._max_calls})"
            )

        return None

    @property
    def alert_count(self) -> int:
        """告警次数"""
        return self._alert_count

    @property
    def current_rate(self) -> int:
        """当前窗口内的调用次数"""
        now = time.monotonic()
        cutoff = now - self._window_seconds
        while self._call_times and self._call_times[0] < cutoff:
            self._call_times.popleft()
        return len(self._call_times)
