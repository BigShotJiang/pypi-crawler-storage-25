"""自动保存插件 — 自动保存对话历史到文件"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..base import Plugin


class AutoSavePlugin(Plugin):
    """自动保存对话历史到文件

    配置:
        save_dir: 保存目录，默认 ~/.leaper-cn/history
        max_entries: 最大保存条目数，默认 1000
    """

    name = "auto_save"
    version = "0.1.0"
    description = "自动保存对话历史到文件"

    def __init__(self) -> None:
        super().__init__()
        self._save_dir: str = ""
        self._max_entries: int = 1000
        self._history: List[Dict[str, Any]] = []

    async def on_load(self, config: Dict[str, Any]) -> None:
        await super().on_load(config)
        self._save_dir = config.get("save_dir", os.path.expanduser("~/.leaper-cn/history"))
        self._max_entries = config.get("max_entries", 1000)
        Path(self._save_dir).mkdir(parents=True, exist_ok=True)

    async def on_message(self, message: str, context: Dict[str, Any]) -> Optional[str]:
        """记录用户消息"""
        self._history.append({
            "role": "user",
            "content": message,
            "timestamp": time.time(),
        })
        self._trim_history()
        return None

    async def on_response(self, response: str, context: Dict[str, Any]) -> str:
        """记录 Agent 响应并保存"""
        self._history.append({
            "role": "assistant",
            "content": response,
            "timestamp": time.time(),
        })
        self._trim_history()
        self._save()
        return response

    def _trim_history(self) -> None:
        """裁剪历史到最大条目数"""
        if len(self._history) > self._max_entries:
            self._history = self._history[-self._max_entries:]

    def _save(self) -> None:
        """保存历史到文件"""
        if not self._save_dir:
            return
        try:
            save_path = Path(self._save_dir) / "latest.json"
            save_path.write_text(
                json.dumps(self._history, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    @property
    def history(self) -> List[Dict[str, Any]]:
        return list(self._history)
