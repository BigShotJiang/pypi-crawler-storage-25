"""关键词触发器插件 — 匹配关键词自动执行动作"""

from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional, Tuple

from ..base import Plugin


class KeywordTriggerPlugin(Plugin):
    """关键词触发器

    当用户消息匹配关键词时，自动返回预设响应。

    配置:
        triggers: 触发规则列表
            - keyword: 关键词（支持正则）
            - response: 预设响应
            - regex: 是否使用正则，默认 False
    """

    name = "keyword_trigger"
    version = "0.1.0"
    description = "关键词触发器：匹配到关键词自动执行动作"

    def __init__(self) -> None:
        super().__init__()
        self._triggers: List[Dict[str, Any]] = []
        self._compiled: List[Tuple[re.Pattern, str]] = []

    async def on_load(self, config: Dict[str, Any]) -> None:
        await super().on_load(config)
        self._triggers = config.get("triggers", [])
        self._compiled = []
        for t in self._triggers:
            keyword = t.get("keyword", "")
            response = t.get("response", "")
            use_regex = t.get("regex", False)
            if keyword:
                if use_regex:
                    pattern = re.compile(keyword, re.IGNORECASE)
                else:
                    pattern = re.compile(re.escape(keyword), re.IGNORECASE)
                self._compiled.append((pattern, response))

    async def on_message(self, message: str, context: Dict[str, Any]) -> Optional[str]:
        """检查消息是否匹配关键词"""
        for pattern, response in self._compiled:
            if pattern.search(message):
                return response
        return None

    def add_trigger(self, keyword: str, response: str, regex: bool = False) -> None:
        """动态添加触发器"""
        self._triggers.append({"keyword": keyword, "response": response, "regex": regex})
        if regex:
            pattern = re.compile(keyword, re.IGNORECASE)
        else:
            pattern = re.compile(re.escape(keyword), re.IGNORECASE)
        self._compiled.append((pattern, response))

    def remove_trigger(self, keyword: str) -> bool:
        """移除触发器"""
        for i, t in enumerate(self._triggers):
            if t.get("keyword") == keyword:
                self._triggers.pop(i)
                self._compiled.pop(i)
                return True
        return False

    @property
    def trigger_count(self) -> int:
        return len(self._triggers)
