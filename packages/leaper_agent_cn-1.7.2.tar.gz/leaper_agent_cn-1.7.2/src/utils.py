"""通用工具函数 - 中英文 token 估算、文本处理、时间格式化等"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from typing import Any, Callable, Optional, TypeVar

from .constants import (
    CHARS_PER_TOKEN_CN,
    CHARS_PER_TOKEN_EN,
    RE_CHINESE,
    RE_DURATION,
)

T = TypeVar("T")

# 时间单位映射（秒）
_DURATION_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400}


def estimate_tokens(text: str) -> int:
    """估算文本的 token 数（中英文混合）

    中文字符按 ~1.5 char/token，英文按 ~4 char/token
    """
    if not text:
        return 0
    cn_chars = len(RE_CHINESE.findall(text))
    en_chars = len(text) - cn_chars
    tokens = cn_chars / CHARS_PER_TOKEN_CN + en_chars / CHARS_PER_TOKEN_EN
    return max(1, int(tokens))


def truncate_text(text: str, max_chars: int, suffix: str = "...") -> str:
    """截断文本到指定长度，超出部分用 suffix 替代"""
    if not text or len(text) <= max_chars:
        return text
    return text[: max_chars - len(suffix)] + suffix


def safe_json_loads(text: str) -> Optional[dict]:
    """容错 JSON 解析，失败返回 None

    会尝试从文本中提取 JSON 块（```json ... ```）
    """
    if not text:
        return None
    # 直接尝试
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        pass
    # 尝试提取 ```json ... ``` 块
    m = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1).strip())
        except (json.JSONDecodeError, TypeError):
            pass
    # 尝试提取 { ... } 块
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except (json.JSONDecodeError, TypeError):
            pass
    return None


def format_timestamp(ts: Optional[float] = None) -> str:
    """格式化时间戳为中文可读格式：2024-01-15 14:30:05"""
    t = time.localtime(ts or time.time())
    return time.strftime("%Y-%m-%d %H:%M:%S", t)


def human_readable_size(size_bytes: int) -> str:
    """字节数转人类可读格式：1024 -> '1.0 KB'"""
    if size_bytes < 0:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(size_bytes) < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0  # type: ignore
    return f"{size_bytes:.1f} PB"


def is_chinese(text: str) -> bool:
    """判断文本是否以中文为主（中文字符占比 > 30%）"""
    if not text:
        return False
    cn_count = len(RE_CHINESE.findall(text))
    total = len(text.strip())
    if total == 0:
        return False
    return cn_count / total > 0.3


def deep_merge(base: dict, override: dict) -> dict:
    """深度合并两个字典，override 覆盖 base"""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


async def retry_async(
    func: Callable[..., Any],
    retries: int = 3,
    delay: float = 1.0,
    *args: Any,
    **kwargs: Any,
) -> Any:
    """异步重试装饰器

    Args:
        func: 异步函数
        retries: 最大重试次数
        delay: 重试间隔（秒）
    """
    last_error: Optional[Exception] = None
    for attempt in range(retries + 1):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            last_error = e
            if attempt < retries:
                await asyncio.sleep(delay * (attempt + 1))
    raise last_error  # type: ignore


def hash_text(text: str) -> str:
    """计算文本的 SHA256 哈希（用于去重）"""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def parse_duration(s: str) -> int:
    """解析时间字符串为秒数

    支持格式：5s, 10m, 2h, 1d
    """
    if not s:
        raise ValueError("空的时间字符串")
    s = s.strip()
    # 纯数字默认为秒
    if s.isdigit():
        return int(s)
    m = RE_DURATION.match(s)
    if not m:
        raise ValueError(f"无法解析时间字符串: {s}")
    value = int(m.group(1))
    unit = m.group(2).lower()
    return value * _DURATION_UNITS[unit]
