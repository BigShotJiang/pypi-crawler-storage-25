"""JSON Schema 清理器 — 确保 tool schema 兼容各 provider

参考 Hermes tools/schema_sanitizer.py
不同 provider 对 JSON Schema 的支持程度不同，此模块统一清理。
"""

from __future__ import annotations

import copy
from typing import List

# 需要从 schema 中移除的顶层字段
_REMOVE_FIELDS = {
    "$schema", "$id", "$comment", "additionalProperties",
    "patternProperties", "unevaluatedProperties",
    "if", "then", "else", "allOf", "anyOf", "oneOf", "not",
    "contentMediaType", "contentEncoding",
}

# 需要从 property 中移除的字段
_REMOVE_PROPERTY_FIELDS = {
    "$comment", "examples", "readOnly", "writeOnly",
    "deprecated", "contentMediaType", "contentEncoding",
}


def sanitize_schema(schema: dict) -> dict:
    """清理 JSON Schema，确保兼容各 provider

    Args:
        schema: 原始 JSON Schema dict

    Returns:
        清理后的 schema（深拷贝，不修改原始对象）
    """
    if not schema:
        return {"type": "object", "properties": {}}

    result = copy.deepcopy(schema)

    # 移除不支持的顶层字段
    for field in _REMOVE_FIELDS:
        result.pop(field, None)

    # 确保 type 存在
    if "type" not in result:
        result["type"] = "object"

    # 确保 required 是 list
    if "required" in result:
        if not isinstance(result["required"], list):
            result["required"] = list(result["required"]) if result["required"] else []

    # 递归处理 properties
    if "properties" in result:
        result["properties"] = _sanitize_properties(result["properties"])

    return result


def _sanitize_properties(properties: dict) -> dict:
    """递归清理 properties"""
    if not isinstance(properties, dict):
        return {}

    cleaned = {}
    for name, prop in properties.items():
        if not isinstance(prop, dict):
            cleaned[name] = {"type": "string"}
            continue

        p = copy.deepcopy(prop)

        # 移除不支持的字段
        for field in _REMOVE_PROPERTY_FIELDS:
            p.pop(field, None)

        # 确保有 type
        if "type" not in p and "enum" not in p:
            p["type"] = "string"

        # 递归处理嵌套 object
        if p.get("type") == "object" and "properties" in p:
            p["properties"] = _sanitize_properties(p["properties"])
            p.pop("additionalProperties", None)

        # 递归处理 array items
        if p.get("type") == "array" and "items" in p:
            items = p["items"]
            if isinstance(items, dict):
                if items.get("type") == "object" and "properties" in items:
                    items["properties"] = _sanitize_properties(items["properties"])
                    items.pop("additionalProperties", None)

        cleaned[name] = p

    return cleaned


def validate_tool_def(tool_def: dict) -> List[str]:
    """验证 tool 定义格式，返回问题列表

    Args:
        tool_def: 工具定义 dict，格式为 {"type": "function", "function": {...}}

    Returns:
        问题描述列表，空列表表示验证通过
    """
    issues: List[str] = []

    if not isinstance(tool_def, dict):
        return ["tool_def 不是 dict"]

    if tool_def.get("type") != "function":
        issues.append("缺少 type='function'")

    func = tool_def.get("function")
    if not isinstance(func, dict):
        issues.append("缺少 function 字段")
        return issues

    if not func.get("name"):
        issues.append("缺少 function.name")

    if not func.get("description"):
        issues.append("缺少 function.description")

    params = func.get("parameters")
    if params is not None:
        if not isinstance(params, dict):
            issues.append("function.parameters 不是 dict")
        else:
            if params.get("type") != "object":
                issues.append("parameters.type 应为 'object'")

            props = params.get("properties")
            if props is not None and not isinstance(props, dict):
                issues.append("parameters.properties 不是 dict")

            required = params.get("required")
            if required is not None and not isinstance(required, list):
                issues.append("parameters.required 不是 list")

    return issues
