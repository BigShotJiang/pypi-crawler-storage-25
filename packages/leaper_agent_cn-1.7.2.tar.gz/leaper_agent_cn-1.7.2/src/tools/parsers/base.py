"""
工具调用解析器基类

提供统一的 ToolCall 数据类和 ToolCallParser 抽象基类。
各国产模型的 parser 继承此基类实现具体解析逻辑。
"""
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any


@dataclass
class ToolCall:
    """单次工具调用"""
    id: str = field(default_factory=lambda: f"call_{uuid.uuid4().hex[:8]}")
    name: str = ""
    arguments: Dict[str, Any] = field(default_factory=dict)


# 解析结果类型：(剩余文本内容, 工具调用列表)
ParseResult = Tuple[Optional[str], Optional[List[ToolCall]]]


class ToolCallParser(ABC):
    """
    工具调用解析器基类

    每个子类负责解析特定模型格式的 tool call 输出。
    """

    @abstractmethod
    def parse_response(self, response_text: str) -> List[ToolCall]:
        """从模型响应中解析工具调用列表"""
        ...

    def format_tool_result(self, tool_name: str, result: str) -> str:
        """格式化工具结果返回给模型，子类可覆盖"""
        return f"<tool_response>\n{{\n  \"name\": \"{tool_name}\",\n  \"result\": {result}\n}}\n</tool_response>"

    def get_stop_tokens(self) -> List[str]:
        """返回模型停止 token 列表，子类可覆盖"""
        return []

    def parse(self, text: str) -> ParseResult:
        """解析文本，返回 (content, tool_calls)"""
        calls = self.parse_response(text)
        if not calls:
            return text, None
        return None, calls
