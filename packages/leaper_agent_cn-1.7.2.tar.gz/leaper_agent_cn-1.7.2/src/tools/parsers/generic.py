"""
通用 Fallback 工具调用解析器

当模型没有对应的专用 parser 时使用。
尝试从 JSON 代码块或纯 JSON 文本中提取 tool call。
"""
import json
import re
from typing import List

from src.tools.parsers.base import ToolCall, ToolCallParser
import src.tools.parsers as _registry


@_registry.register_parser("generic")
class GenericToolCallParser(ToolCallParser):
    """通用 fallback 解析器，从 JSON 代码块中提取 tool call"""

    # ```json ... ``` 代码块
    CODE_BLOCK_RE = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.DOTALL)
    # 直接匹配 {"name": "...", "arguments": {...}} 模式
    INLINE_RE = re.compile(
        r'\{\s*"name"\s*:\s*"([^"]+)"\s*,\s*"arguments"\s*:\s*(\{.*?\})\s*\}',
        re.DOTALL,
    )
    # <tool_call> 标签
    TAG_RE = re.compile(r"<tool_call>\s*(.*?)\s*</tool_call>", re.DOTALL)

    def parse_response(self, response_text: str) -> List[ToolCall]:
        calls: List[ToolCall] = []

        # 1. 先尝试 <tool_call> 标签
        for m in self.TAG_RE.finditer(response_text):
            raw = m.group(1).strip()
            tc = self._try_parse_json(raw)
            if tc:
                calls.append(tc)
        if calls:
            return calls

        # 2. 再尝试代码块
        for m in self.CODE_BLOCK_RE.finditer(response_text):
            raw = m.group(1).strip()
            tc = self._try_parse_json(raw)
            if tc:
                calls.append(tc)
        if calls:
            return calls

        # 3. 最后尝试内联 JSON 匹配
        for m in self.INLINE_RE.finditer(response_text):
            name = m.group(1)
            try:
                args = json.loads(m.group(2))
            except (json.JSONDecodeError, TypeError):
                args = {}
            calls.append(ToolCall(name=name, arguments=args))

        return calls

    @staticmethod
    def _try_parse_json(raw: str) -> "ToolCall | None":
        """尝试从 JSON 字符串解析 ToolCall"""
        try:
            data = json.loads(raw)
            if isinstance(data, dict) and "name" in data:
                return ToolCall(
                    name=data["name"],
                    arguments=data.get("arguments", {}),
                )
        except (json.JSONDecodeError, TypeError):
            pass
        return None

    def get_stop_tokens(self) -> List[str]:
        return ["</tool_call>"]

    def parse(self, text: str):
        calls = self.parse_response(text)
        if not calls:
            return text, None
        # 尝试提取 tool call 之前的内容
        for marker in ["<tool_call>", "```json", '{"name"']:
            idx = text.find(marker)
            if idx > 0:
                content = text[:idx].strip()
                return content if content else None, calls
        return None, calls
