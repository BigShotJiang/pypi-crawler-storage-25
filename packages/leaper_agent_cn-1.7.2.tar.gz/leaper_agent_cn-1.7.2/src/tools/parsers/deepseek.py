"""
DeepSeek 工具调用解析器

DeepSeek V3 使用特殊 Unicode token 格式：
    <｜tool▁calls▁begin｜>
    <｜tool▁call▁begin｜>type<｜tool▁sep｜>function_name
    ```json
    {"arg": "value"}
    ```
    <｜tool▁call▁end｜>

同时支持 <think>...</think> 标签过滤。
"""
import json
import re
from typing import List

from src.tools.parsers.base import ToolCall, ToolCallParser
import src.tools.parsers as _registry


@_registry.register_parser("deepseek")
class DeepSeekToolCallParser(ToolCallParser):
    """DeepSeek V3 tool call 解析器"""

    START_TOKEN = "<｜tool▁calls▁begin｜>"
    THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL)
    CALL_RE = re.compile(
        r"<｜tool▁call▁begin｜>(?P<type>.*?)<｜tool▁sep｜>(?P<name>.*?)\s*"
        r"```json\s*(?P<args>.*?)\s*```\s*<｜tool▁call▁end｜>",
        re.DOTALL,
    )

    def parse_response(self, response_text: str) -> List[ToolCall]:
        # 先移除 thinking 标签
        text = self.THINK_RE.sub("", response_text)
        if self.START_TOKEN not in text:
            return []
        calls: List[ToolCall] = []
        for m in self.CALL_RE.finditer(text):
            name = m.group("name").strip()
            try:
                args = json.loads(m.group("args").strip())
            except (json.JSONDecodeError, TypeError):
                args = {}
            calls.append(ToolCall(name=name, arguments=args))
        return calls

    def get_stop_tokens(self) -> List[str]:
        return ["<｜tool▁calls▁end｜>", "<｜tool▁call▁end｜>"]

    def format_tool_result(self, tool_name: str, result: str) -> str:
        return f"<｜tool▁output▁begin｜>{result}<｜tool▁output▁end｜>"

    def parse(self, text: str):
        clean = self.THINK_RE.sub("", text)
        calls = self.parse_response(text)
        if not calls:
            return text, None
        idx = clean.find(self.START_TOKEN)
        content = clean[:idx].strip() if idx > 0 else None
        return content, calls
