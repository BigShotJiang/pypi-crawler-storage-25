"""
Moonshot (Kimi) 工具调用解析器

Moonshot 使用标准 OpenAI function calling 格式。
此解析器处理文本中嵌入的 JSON tool call 格式。
"""
import json
import re
from typing import List

from src.tools.parsers.base import ToolCall, ToolCallParser
import src.tools.parsers as _registry


@_registry.register_parser("moonshot")
class MoonshotToolCallParser(ToolCallParser):
    """Moonshot/Kimi 解析器，标准 OpenAI 格式"""

    # Moonshot 有时用 <tool_call>JSON</tool_call> 格式
    PATTERN = re.compile(
        r"<tool_call>\s*(.*?)\s*</tool_call>", re.DOTALL
    )

    def parse_response(self, response_text: str) -> List[ToolCall]:
        if "<tool_call>" not in response_text:
            return []
        calls: List[ToolCall] = []
        for m in self.PATTERN.finditer(response_text):
            raw = m.group(1).strip()
            try:
                data = json.loads(raw)
                if "name" in data:
                    calls.append(ToolCall(
                        name=data["name"],
                        arguments=data.get("arguments", {}),
                    ))
            except (json.JSONDecodeError, TypeError):
                continue
        return calls

    def get_stop_tokens(self) -> List[str]:
        return ["</tool_call>"]

    def parse(self, text: str):
        calls = self.parse_response(text)
        if not calls:
            return text, None
        idx = text.find("<tool_call>")
        content = text[:idx].strip() if idx > 0 else None
        return content, calls
