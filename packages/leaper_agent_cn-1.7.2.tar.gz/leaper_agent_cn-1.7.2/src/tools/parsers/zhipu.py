"""
智谱 GLM 工具调用解析器

GLM 4.5 使用 arg_key/arg_value 标签格式：
    <tool_call>function_name
    <arg_key>param</arg_key><arg_value>value</arg_value>
    </tool_call>

GLM 4.7+ 使用标准 <tool_call>JSON</tool_call> 格式。
"""
import ast
import json
import re
from typing import Any, Dict, List

from src.tools.parsers.base import ToolCall, ToolCallParser
import src.tools.parsers as _registry


def _deserialize(value: str) -> Any:
    """尝试反序列化字符串值"""
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        pass
    try:
        return ast.literal_eval(value)
    except (ValueError, SyntaxError, TypeError):
        pass
    return value


@_registry.register_parser("zhipu")
class ZhipuToolCallParser(ToolCallParser):
    """智谱 GLM tool call 解析器，支持 GLM4.5 和 GLM4.7 两种格式"""

    # GLM 4.5: arg_key/arg_value 格式
    CALL_RE = re.compile(r"<tool_call>(.*?)</tool_call>", re.DOTALL)
    DETAIL_RE = re.compile(r"<tool_call>([^\n]*)\n(.*)</tool_call>", re.DOTALL)
    ARG_RE = re.compile(r"<arg_key>(.*?)</arg_key>\s*<arg_value>(.*?)</arg_value>", re.DOTALL)

    def parse_response(self, response_text: str) -> List[ToolCall]:
        if "<tool_call>" not in response_text:
            return []
        calls: List[ToolCall] = []
        for block in self.CALL_RE.findall(response_text):
            full = f"<tool_call>{block}</tool_call>"
            # 先尝试 JSON 格式 (GLM4.7)
            try:
                data = json.loads(block.strip())
                if isinstance(data, dict) and "name" in data:
                    calls.append(ToolCall(
                        name=data["name"],
                        arguments=data.get("arguments", {}),
                    ))
                    continue
            except (json.JSONDecodeError, TypeError):
                pass
            # 再尝试 arg_key/arg_value 格式 (GLM4.5)
            detail = self.DETAIL_RE.search(full)
            if not detail:
                continue
            fname = detail.group(1).strip()
            args_raw = detail.group(2)
            args: Dict[str, Any] = {}
            for key, val in self.ARG_RE.findall(args_raw):
                args[key.strip()] = _deserialize(val.strip())
            calls.append(ToolCall(name=fname, arguments=args))
        return calls

    def get_stop_tokens(self) -> List[str]:
        return ["</tool_call>", "观察"]

    def parse(self, text: str):
        calls = self.parse_response(text)
        if not calls:
            return text, None
        idx = text.find("<tool_call>")
        content = text[:idx].strip() if idx > 0 else None
        return content, calls
