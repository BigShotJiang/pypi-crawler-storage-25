"""
通义千问 (Qwen) 工具调用解析器

支持两种格式：
1. Qwen 2.5: <tool_call>{"name": "...", "arguments": {...}}</tool_call>  (Hermes 格式)
2. Qwen3-Coder: <tool_call><function=name><parameter=key>value</parameter></function></tool_call>
"""
import ast
import json
import re
from typing import Any, Dict, List

from src.tools.parsers.base import ToolCall, ToolCallParser

# 延迟导入避免循环
import src.tools.parsers as _registry


@_registry.register_parser("qwen")
class QwenToolCallParser(ToolCallParser):
    """Qwen 2.5 格式：<tool_call>JSON</tool_call>"""

    PATTERN = re.compile(
        r"<tool_call>\s*(.*?)\s*</tool_call>|<tool_call>\s*(.*)", re.DOTALL
    )

    def parse_response(self, response_text: str) -> List[ToolCall]:
        if "<tool_call>" not in response_text:
            return []
        calls: List[ToolCall] = []
        for m in self.PATTERN.finditer(response_text):
            raw = (m.group(1) or m.group(2) or "").strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
                if "name" in data:
                    calls.append(ToolCall(
                        name=data["name"],
                        arguments=data.get("arguments", {}),
                    ))
            except (json.JSONDecodeError, TypeError):
                continue
        return calls

    def get_stop_tokens(self) -> List[str]:
        return ["</tool_call>"]

    def format_tool_result(self, tool_name: str, result: str) -> str:
        return f"<tool_response>\n{{\"name\": \"{tool_name}\", \"result\": {result}}}\n</tool_response>"

    def parse(self, text: str):
        calls = self.parse_response(text)
        if not calls:
            return text, None
        idx = text.find("<tool_call>")
        content = text[:idx].strip() if idx > 0 else None
        return content, calls


def _try_convert(value: str) -> Any:
    """尝试将字符串转为 Python 原生类型"""
    s = value.strip()
    if s.lower() == "null":
        return None
    try:
        return json.loads(s)
    except (json.JSONDecodeError, TypeError):
        pass
    try:
        return ast.literal_eval(s)
    except (ValueError, SyntaxError, TypeError):
        pass
    return s


@_registry.register_parser("qwen3")
class Qwen3ToolCallParser(ToolCallParser):
    """Qwen3-Coder XML 格式"""

    TOOL_RE = re.compile(r"<tool_call>(.*?)</tool_call>|<tool_call>(.*?)$", re.DOTALL)
    FUNC_RE = re.compile(r"<function=(.*?)</function>|<function=(.*)$", re.DOTALL)
    PARAM_RE = re.compile(
        r"<parameter=(.*?)(?:</parameter>|(?=<parameter=)|(?=</function>)|$)", re.DOTALL
    )

    def parse_response(self, response_text: str) -> List[ToolCall]:
        if "<function=" not in response_text:
            return []
        calls: List[ToolCall] = []
        for tm in self.TOOL_RE.finditer(response_text):
            block = tm.group(1) or tm.group(2) or ""
            for fm in self.FUNC_RE.finditer(block):
                fstr = fm.group(1) or fm.group(2) or ""
                try:
                    gt = fstr.index(">")
                    fname = fstr[:gt].strip()
                    params_str = fstr[gt + 1:]
                except ValueError:
                    continue
                args: Dict[str, Any] = {}
                for pm in self.PARAM_RE.finditer(params_str):
                    ptext = pm.group(1) or ""
                    if ">" not in ptext:
                        continue
                    eq = ptext.index(">")
                    pname = ptext[:eq].strip()
                    pval = ptext[eq + 1:].strip()
                    args[pname] = _try_convert(pval)
                calls.append(ToolCall(name=fname, arguments=args))
        return calls

    def get_stop_tokens(self) -> List[str]:
        return ["</tool_call>"]

    def parse(self, text: str):
        calls = self.parse_response(text)
        if not calls:
            return text, None
        idx = text.find("<tool_call>")
        if idx < 0:
            idx = text.find("<function=")
        content = text[:idx].strip() if idx > 0 else None
        return content, calls
