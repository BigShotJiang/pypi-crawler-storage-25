"""
工具调用解析器注册表

根据模型名称自动选择对应的 tool call 解析器。
支持通义千问、DeepSeek、智谱、Moonshot 等国产模型。
"""
from typing import Dict, List, Type

from src.tools.parsers.base import ToolCallParser, ToolCall  # noqa: F401

# 全局注册表：parser 名称 -> parser 类
PARSER_REGISTRY: Dict[str, Type[ToolCallParser]] = {}


def register_parser(name: str):
    """装饰器：注册解析器"""
    def decorator(cls: Type[ToolCallParser]) -> Type[ToolCallParser]:
        PARSER_REGISTRY[name] = cls
        return cls
    return decorator


def get_parser(model_name: str) -> ToolCallParser:
    """根据模型名称获取解析器实例"""
    # 精确匹配
    if model_name in PARSER_REGISTRY:
        return PARSER_REGISTRY[model_name]()
    # 模糊匹配
    lower = model_name.lower()
    for key in ("qwen3", "qwen", "deepseek", "glm", "zhipu", "moonshot", "kimi", "generic"):
        if key in lower and key in PARSER_REGISTRY:
            return PARSER_REGISTRY[key]()
    # 默认 fallback
    if "generic" in PARSER_REGISTRY:
        return PARSER_REGISTRY["generic"]()
    raise KeyError(f"未找到模型 '{model_name}' 对应的解析器，可用: {list_parsers()}")


def list_parsers() -> List[str]:
    """返回所有已注册的解析器名称"""
    return sorted(PARSER_REGISTRY.keys())


# 导入所有 parser 模块触发注册
from src.tools.parsers.qwen import QwenToolCallParser, Qwen3ToolCallParser  # noqa: E402, F401
from src.tools.parsers.deepseek import DeepSeekToolCallParser  # noqa: E402, F401
from src.tools.parsers.zhipu import ZhipuToolCallParser  # noqa: E402, F401
from src.tools.parsers.moonshot import MoonshotToolCallParser  # noqa: E402, F401
from src.tools.parsers.generic import GenericToolCallParser  # noqa: E402, F401
