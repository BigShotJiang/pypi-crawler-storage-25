"""代码执行工具 — 增强版

参考 Hermes code_execution_tool.py 简化实现。
安全: subprocess 隔离，超时控制，危险代码检查。
"""
import asyncio
import re
import sys
from src.tools.base import Tool

# 危险代码模式
_DANGEROUS_CODE_PATTERNS = [
    re.compile(r'\bos\.system\b'),
    re.compile(r'\bsubprocess\b'),
    re.compile(r'\b__import__\b'),
    re.compile(r'\beval\s*\('),
    re.compile(r'\bexec\s*\('),
    re.compile(r'\bopen\s*\(\s*["\']\/etc'),
    re.compile(r'\bshutil\.rmtree\b'),
    re.compile(r'\bos\.remove\b'),
    re.compile(r'\bos\.unlink\b'),
]

DEFAULT_TIMEOUT = 10
MAX_OUTPUT = 10000


def check_dangerous_code(code: str) -> str | None:
    """检查危险代码模式，返回匹配的模式或 None"""
    for pat in _DANGEROUS_CODE_PATTERNS:
        if pat.search(code):
            return pat.pattern
    return None


class CodeExecTool(Tool):
    name = "code_exec"
    description = "安全执行 Python 代码片段（subprocess 隔离）"
    parameters = {
        "type": "object",
        "properties": {
            "code": {"type": "string", "description": "要执行的 Python 代码"},
            "timeout": {"type": "integer", "description": "超时秒数，默认 10"},
        },
        "required": ["code"],
    }

    async def execute(self, arguments: dict) -> str:
        code = arguments["code"]
        timeout = arguments.get("timeout", DEFAULT_TIMEOUT)

        # 安全检查
        danger = check_dangerous_code(code)
        if danger:
            return f"🚫 危险代码被拦截: 匹配规则 [{danger}]"

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-c", code,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except Exception:
                pass
            return f"⏱️ 代码执行超时 ({timeout}s)"
        except Exception as e:
            return f"错误: 执行失败 — {e}"

        output = ""
        if stdout:
            output += stdout.decode(errors="replace")
        if stderr:
            if output:
                output += "\n"
            output += "[STDERR]\n" + stderr.decode(errors="replace")

        # 截断
        if len(output) > MAX_OUTPUT:
            output = output[:MAX_OUTPUT] + f"\n\n... [截断: 输出共 {len(output)} 字符]"

        if proc.returncode != 0:
            output += f"\n[退出码: {proc.returncode}]"

        return output.strip() or "(无输出)"
