"""文件操作工具集 — 增强版

参考 Hermes file_tools.py + file_operations.py 简化实现。
包含: read_file, write_file, edit_file, list_dir, search_files
安全: 路径穿越检查、编码自动检测、大文件分页读取
"""
import fnmatch
import os
import re
from pathlib import Path
from src.tools.base import Tool

# ──────────────────── 安全辅助 ────────────────────

def _check_path_traversal(path_str: str, base_dir: str | None = None) -> str | None:
    """检查路径穿越攻击，返回错误信息或 None（安全）"""
    # 标准化路径
    p = Path(path_str).expanduser().resolve()
    # 检查是否包含可疑的穿越模式
    normalized = str(p)
    # 禁止访问系统敏感目录
    sensitive = ["/etc/shadow", "/etc/passwd", "C:\\Windows\\System32\\config"]
    for s in sensitive:
        if normalized.replace("\\", "/").lower().startswith(s.replace("\\", "/").lower()):
            return f"🚫 安全拦截: 禁止访问系统敏感路径 {s}"
    return None


def _detect_encoding(file_path: Path) -> str:
    """自动检测文件编码: 优先 UTF-8，失败尝试 GBK"""
    try:
        file_path.read_text(encoding="utf-8")
        return "utf-8"
    except UnicodeDecodeError:
        try:
            file_path.read_text(encoding="gbk")
            return "gbk"
        except Exception:
            return "utf-8"  # fallback


# ──────────────────── read_file ────────────────────

class ReadFileTool(Tool):
    """读取文件内容（支持 offset/limit 分页、自动编码检测）"""
    name = "read_file"
    description = "读取文件内容，支持大文件分页读取（offset/limit）"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "文件路径"},
            "offset": {"type": "integer", "description": "从第几行开始（1-indexed，默认 1）"},
            "limit": {"type": "integer", "description": "最多读几行（默认全部，上限 2000）"},
        },
        "required": ["path"],
    }

    async def execute(self, arguments: dict) -> str:
        path_str = arguments["path"]
        err = _check_path_traversal(path_str)
        if err:
            return err

        path = Path(path_str).expanduser().resolve()
        if not path.exists():
            return f"错误: 文件不存在 — {path}"
        if not path.is_file():
            return f"错误: 不是文件 — {path}"

        encoding = _detect_encoding(path)
        try:
            content = path.read_text(encoding=encoding)
        except Exception as e:
            return f"错误: 读取失败 — {e}"

        lines = content.splitlines(keepends=True)
        total = len(lines)
        offset = max(1, arguments.get("offset", 1))
        limit = min(arguments.get("limit", 2000), 2000)

        selected = lines[offset - 1: offset - 1 + limit]
        result = "".join(selected)

        # 截断保护
        if len(result) > 50000:
            result = result[:50000] + "\n\n... [截断，内容过大]"

        header = f"[{path.name}] 行 {offset}-{offset + len(selected) - 1}/{total} | 编码: {encoding}\n"
        return header + result


# ──────────────────── write_file ────────────────────

class WriteFileTool(Tool):
    name = "write_file"
    description = "写入内容到文件（自动创建目录）"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "文件路径"},
            "content": {"type": "string", "description": "要写入的内容"},
        },
        "required": ["path", "content"],
    }

    async def execute(self, arguments: dict) -> str:
        path_str = arguments["path"]
        err = _check_path_traversal(path_str)
        if err:
            return err

        path = Path(path_str).expanduser().resolve()
        content = arguments["content"]
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return f"✅ 已写入 {len(content)} 字符到 {path}"
        except Exception as e:
            return f"错误: 写入失败 — {e}"


# ──────────────────── edit_file (patch) ────────────────────

class EditFileTool(Tool):
    name = "edit_file"
    description = "编辑文件：精确替换指定文本（old_text → new_text）"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "文件路径"},
            "old_text": {"type": "string", "description": "要被替换的原文（必须精确匹配）"},
            "new_text": {"type": "string", "description": "替换后的新文本"},
        },
        "required": ["path", "old_text", "new_text"],
    }

    async def execute(self, arguments: dict) -> str:
        path_str = arguments["path"]
        err = _check_path_traversal(path_str)
        if err:
            return err

        path = Path(path_str).expanduser().resolve()
        if not path.exists():
            return f"错误: 文件不存在 — {path}"

        old_text = arguments["old_text"]
        new_text = arguments["new_text"]

        encoding = _detect_encoding(path)
        content = path.read_text(encoding=encoding)

        count = content.count(old_text)
        if count == 0:
            return "错误: 未找到匹配的文本"
        if count > 1:
            return f"警告: 找到 {count} 处匹配，请提供更精确的文本以避免误改"

        new_content = content.replace(old_text, new_text, 1)
        path.write_text(new_content, encoding="utf-8")
        return f"✅ 已替换 1 处文本 ({len(old_text)} → {len(new_text)} 字符)"


# ──────────────────── list_dir ────────────────────

class ListDirTool(Tool):
    name = "list_dir"
    description = "列出目录下的文件和子目录（含文件大小）"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "目录路径，默认当前目录"},
            "pattern": {"type": "string", "description": "文件名过滤模式，如 *.py"},
        },
        "required": [],
    }

    async def execute(self, arguments: dict) -> str:
        path = Path(arguments.get("path", ".")).expanduser().resolve()
        pattern = arguments.get("pattern")

        if not path.exists():
            return f"错误: 目录不存在 — {path}"
        if not path.is_dir():
            return f"错误: 不是目录 — {path}"

        entries = []
        try:
            for item in sorted(path.iterdir()):
                if pattern and not fnmatch.fnmatch(item.name, pattern):
                    continue
                if item.is_dir():
                    entries.append(f"📁 {item.name}/")
                else:
                    size = item.stat().st_size
                    if size < 1024:
                        sz = f"{size}B"
                    elif size < 1024 * 1024:
                        sz = f"{size // 1024}KB"
                    else:
                        sz = f"{size // (1024 * 1024)}MB"
                    entries.append(f"📄 {item.name}  ({sz})")
        except Exception as e:
            return f"错误: 列出目录失败 — {e}"

        if not entries:
            return "(空目录)" if not pattern else f"(没有匹配 {pattern} 的文件)"
        return f"📂 {path}\n" + "\n".join(entries)


# ──────────────────── search_files ────────────────────

class SearchFilesTool(Tool):
    name = "search_files"
    description = "在目录中递归搜索文件内容（grep 风格）"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "搜索的根目录"},
            "pattern": {"type": "string", "description": "搜索的正则表达式或字符串"},
            "file_pattern": {"type": "string", "description": "文件名过滤，如 *.py"},
            "max_results": {"type": "integer", "description": "最大结果数，默认 50"},
        },
        "required": ["path", "pattern"],
    }

    async def execute(self, arguments: dict) -> str:
        root = Path(arguments["path"]).expanduser().resolve()
        pattern = arguments["pattern"]
        file_pattern = arguments.get("file_pattern", "*")
        max_results = arguments.get("max_results", 50)

        if not root.exists():
            return f"错误: 目录不存在 — {root}"

        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            return f"错误: 无效正则 — {e}"

        results: list[str] = []
        # 排除常见大目录
        skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv"}

        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in skip_dirs]
            for fname in filenames:
                if not fnmatch.fnmatch(fname, file_pattern):
                    continue
                fpath = Path(dirpath) / fname
                try:
                    text = fpath.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    continue
                for i, line in enumerate(text.splitlines(), 1):
                    if regex.search(line):
                        rel = fpath.relative_to(root)
                        results.append(f"{rel}:{i}: {line.strip()[:120]}")
                        if len(results) >= max_results:
                            return f"找到 {len(results)}+ 条结果（已截断）:\n" + "\n".join(results)

        if not results:
            return f"未找到匹配 '{pattern}' 的内容"
        return f"找到 {len(results)} 条结果:\n" + "\n".join(results)
