"""飞书文档工具 — 通过飞书开放平台 API 操作文档

参考 Hermes feishu_doc_tool.py + feishu_drive_tool.py 简化实现。
仅用 urllib（不引入 requests）。
需要配置: FEISHU_APP_ID, FEISHU_APP_SECRET 环境变量。
"""
import json
import os
import urllib.request
import urllib.error
from src.tools.base import Tool

_BASE_URL = "https://open.feishu.cn/open-apis"


def _get_tenant_token() -> str:
    """获取 tenant_access_token"""
    app_id = os.environ.get("FEISHU_APP_ID", "")
    app_secret = os.environ.get("FEISHU_APP_SECRET", "")
    if not app_id or not app_secret:
        raise RuntimeError("未配置 FEISHU_APP_ID / FEISHU_APP_SECRET 环境变量")

    url = f"{_BASE_URL}/auth/v3/tenant_access_token/internal"
    data = json.dumps({"app_id": app_id, "app_secret": app_secret}).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        result = json.loads(resp.read().decode())
    if result.get("code") != 0:
        raise RuntimeError(f"获取 token 失败: {result.get('msg')}")
    return result["tenant_access_token"]


def _feishu_api(method: str, path: str, body: dict | None = None) -> dict:
    """调用飞书 API"""
    token = _get_tenant_token()
    url = f"{_BASE_URL}{path}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode())


class FeishuCreateDocTool(Tool):
    name = "feishu_create_doc"
    description = "在飞书中创建新文档"
    parameters = {
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "文档标题"},
            "folder_token": {"type": "string", "description": "目标文件夹 token（可选）"},
        },
        "required": ["title"],
    }

    async def execute(self, arguments: dict) -> str:
        title = arguments["title"]
        folder_token = arguments.get("folder_token", "")

        try:
            body = {"title": title, "folder_token": folder_token} if folder_token else {"title": title}
            result = _feishu_api("POST", "/docx/v1/documents", body)
            if result.get("code") != 0:
                return f"错误: 创建文档失败 — {result.get('msg')}"
            doc = result.get("data", {}).get("document", {})
            doc_id = doc.get("document_id", "unknown")
            return f"✅ 文档已创建\n标题: {title}\nID: {doc_id}\nURL: https://feishu.cn/docx/{doc_id}"
        except Exception as e:
            return f"错误: 创建文档失败 — {e}"


class FeishuReadDocTool(Tool):
    name = "feishu_read_doc"
    description = "读取飞书文档内容"
    parameters = {
        "type": "object",
        "properties": {
            "document_id": {"type": "string", "description": "文档 ID"},
        },
        "required": ["document_id"],
    }

    async def execute(self, arguments: dict) -> str:
        doc_id = arguments["document_id"]
        try:
            result = _feishu_api("GET", f"/docx/v1/documents/{doc_id}/raw_content")
            if result.get("code") != 0:
                return f"错误: 读取文档失败 — {result.get('msg')}"
            content = result.get("data", {}).get("content", "(空文档)")
            return f"📄 文档内容 [{doc_id}]:\n{content}"
        except Exception as e:
            return f"错误: 读取文档失败 — {e}"


class FeishuUpdateDocTool(Tool):
    name = "feishu_update_doc"
    description = "更新飞书文档内容（追加文本块）"
    parameters = {
        "type": "object",
        "properties": {
            "document_id": {"type": "string", "description": "文档 ID"},
            "content": {"type": "string", "description": "要追加的文本内容"},
        },
        "required": ["document_id", "content"],
    }

    async def execute(self, arguments: dict) -> str:
        doc_id = arguments["document_id"]
        content = arguments["content"]

        try:
            # 先获取文档信息以拿到最新 revision
            doc_info = _feishu_api("GET", f"/docx/v1/documents/{doc_id}")
            if doc_info.get("code") != 0:
                return f"错误: 获取文档信息失败 — {doc_info.get('msg')}"

            # 创建文本块
            body = {
                "children": [{
                    "block_type": 2,  # text block
                    "text": {
                        "elements": [{
                            "text_run": {"content": content}
                        }]
                    }
                }],
                "index": -1,  # 追加到末尾
            }
            result = _feishu_api(
                "POST",
                f"/docx/v1/documents/{doc_id}/blocks/{doc_id}/children",
                body,
            )
            if result.get("code") != 0:
                return f"错误: 更新文档失败 — {result.get('msg')}"
            return f"✅ 已追加内容到文档 [{doc_id}]，共 {len(content)} 字符"
        except Exception as e:
            return f"错误: 更新文档失败 — {e}"
