"""
消息发送工具 — Agent 主动发送消息到渠道

注册为 tool 后，agent 可主动向用户发送消息或广播通知。
"""
import json
import logging
from typing import Dict, List, Optional

from src.tools.base import Tool

logger = logging.getLogger(__name__)


class SendMessageTool(Tool):
    """主动发送消息到指定渠道"""

    name = "send_message"
    description = "发送消息到指定渠道的指定用户"
    parameters = {
        "type": "object",
        "properties": {
            "channel": {"type": "string", "description": "渠道名（如 telegram, feishu, dingtalk）"},
            "user_id": {"type": "string", "description": "目标用户 ID"},
            "content": {"type": "string", "description": "消息内容"},
            "message_type": {
                "type": "string",
                "description": "消息类型：text/markdown/image",
                "default": "text",
            },
        },
        "required": ["channel", "user_id", "content"],
    }

    def __init__(self, channel_registry: Optional[Dict] = None):
        """
        Args:
            channel_registry: 渠道名 -> 发送函数的映射
        """
        self._channels: Dict = channel_registry or {}

    def register_channel(self, name: str, sender) -> None:
        """注册渠道发送器"""
        self._channels[name] = sender

    async def execute(self, arguments: dict) -> str:
        channel = arguments["channel"]
        user_id = arguments["user_id"]
        content = arguments["content"]
        message_type = arguments.get("message_type", "text")

        if channel not in self._channels:
            available = list(self._channels.keys())
            return json.dumps({
                "success": False,
                "error": f"未知渠道: {channel}，可用渠道: {available}",
            }, ensure_ascii=False)

        try:
            sender = self._channels[channel]
            result = await sender(user_id=user_id, content=content, message_type=message_type)
            return json.dumps({
                "success": True,
                "channel": channel,
                "user_id": user_id,
                "result": result,
            }, ensure_ascii=False)
        except Exception as e:
            logger.error(f"发送消息失败 channel={channel} user={user_id}: {e}")
            return json.dumps({
                "success": False,
                "error": str(e),
            }, ensure_ascii=False)


async def send_message(
    channel: str,
    user_id: str,
    content: str,
    message_type: str = "text",
    channel_registry: Optional[Dict] = None,
) -> Dict:
    """发送消息到指定渠道的指定用户"""
    tool = SendMessageTool(channel_registry=channel_registry)
    raw = await tool.execute({
        "channel": channel,
        "user_id": user_id,
        "content": content,
        "message_type": message_type,
    })
    return json.loads(raw)


async def send_notification(
    channels: List[str],
    content: str,
    channel_registry: Optional[Dict] = None,
) -> Dict:
    """广播通知到多个渠道"""
    results: Dict[str, Dict] = {}
    tool = SendMessageTool(channel_registry=channel_registry)
    for ch in channels:
        raw = await tool.execute({
            "channel": ch,
            "user_id": "broadcast",
            "content": content,
            "message_type": "text",
        })
        results[ch] = json.loads(raw)
    return {"channels": results, "total": len(channels)}
