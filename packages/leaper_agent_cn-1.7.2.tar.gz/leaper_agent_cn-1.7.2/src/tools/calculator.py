"""
计算器工具 - 安全地计算数学表达式

只允许数学运算，禁止任何代码执行。
"""

import ast
import math
import operator
from typing import Union

from src.tools.base import Tool

# 允许的数学运算符
_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

# 允许的数学函数
_FUNCTIONS = {
    "abs": abs,
    "round": round,
    "int": int,
    "float": float,
    "sqrt": math.sqrt,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "log": math.log,
    "log10": math.log10,
    "pi": math.pi,
    "e": math.e,
}


def _safe_eval_node(node: ast.AST) -> Union[int, float]:
    """递归安全求值 AST 节点"""
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError(f"不允许的常量类型: {type(node.value)}")
    elif isinstance(node, ast.BinOp):
        op_type = type(node.op)
        if op_type not in _OPERATORS:
            raise ValueError(f"不允许的运算符: {op_type.__name__}")
        left = _safe_eval_node(node.left)
        right = _safe_eval_node(node.right)
        return _OPERATORS[op_type](left, right)
    elif isinstance(node, ast.UnaryOp):
        op_type = type(node.op)
        if op_type not in _OPERATORS:
            raise ValueError(f"不允许的一元运算符: {op_type.__name__}")
        operand = _safe_eval_node(node.operand)
        return _OPERATORS[op_type](operand)
    elif isinstance(node, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id in _FUNCTIONS:
            func = _FUNCTIONS[node.func.id]
            if callable(func):
                args = [_safe_eval_node(a) for a in node.args]
                return func(*args)
            return func  # 常量如 pi, e
        raise ValueError(f"不允许的函数: {ast.dump(node.func)}")
    elif isinstance(node, ast.Name):
        if node.id in _FUNCTIONS:
            val = _FUNCTIONS[node.id]
            if not callable(val):
                return val
        raise ValueError(f"不允许的变量: {node.id}")
    raise ValueError(f"不支持的表达式类型: {type(node).__name__}")


def calculate(expression: str) -> str:
    """
    安全计算数学表达式（保留向后兼容的函数式接口）

    Args:
        expression: 数学表达式字符串，如 "2 + 3 * 4"

    Returns:
        计算结果字符串
    """
    try:
        tree = ast.parse(expression, mode="eval")
        result = _safe_eval_node(tree.body)
        return str(result)
    except Exception as e:
        return f"计算错误: {e}"


class CalculatorTool(Tool):
    """安全数学计算工具"""
    name = "calculator"
    description = "安全地计算数学表达式，支持基本运算和常用数学函数"
    parameters = {
        "type": "object",
        "properties": {
            "expression": {"type": "string", "description": "数学表达式，如 '2 + 3 * 4' 或 'sqrt(16)'"},
        },
        "required": ["expression"],
    }

    async def execute(self, arguments: dict) -> str:
        return calculate(arguments["expression"])
