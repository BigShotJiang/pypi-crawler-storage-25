"""Image Generation 工具 — 国内图片生成 API

支持：
- 智谱 CogView：https://open.bigmodel.cn/api/paas/v4/images/generations
- 通义万相：https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis
"""

from __future__ import annotations

import json
import os
import time
from typing import Any
from urllib import request as urllib_request


# ── 常量 ──

PROVIDERS = {
    "zhipu": {
        "name": "智谱 CogView",
        "url": "https://open.bigmodel.cn/api/paas/v4/images/generations",
        "env_key": "ZHIPU_API_KEY",
        "models": ["cogview-3-plus", "cogview-3"],
    },
    "dashscope": {
        "name": "通义万相",
        "url": "https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis",
        "env_key": "DASHSCOPE_API_KEY",
        "models": ["wanx-v1"],
    },
}

SUPPORTED_SIZES = ["512x512", "768x768", "1024x1024", "1280x720", "720x1280"]


# ── 辅助函数 ──

def get_available_provider() -> str | None:
    """自动检测可用的 provider（优先用已配置 API key 的）"""
    for name, cfg in PROVIDERS.items():
        if os.environ.get(cfg["env_key"]):
            return name
    return None


def _get_api_key(provider: str) -> str:
    """获取指定 provider 的 API key"""
    env_key = PROVIDERS[provider]["env_key"]
    key = os.environ.get(env_key, "")
    if not key:
        raise ValueError(
            f"未配置 {provider} 的 API key，请设置环境变量 {env_key}"
        )
    return key


# ── 请求构造 ──

def build_zhipu_request(prompt: str, size: str, model: str = "cogview-3-plus") -> tuple[str, dict, dict]:
    """构造智谱 CogView 请求

    Returns:
        (url, headers, body)
    """
    api_key = _get_api_key("zhipu")
    url = PROVIDERS["zhipu"]["url"]
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    body = {
        "model": model,
        "prompt": prompt,
        "size": size,
    }
    return url, headers, body


def build_dashscope_request(prompt: str, size: str, model: str = "wanx-v1") -> tuple[str, dict, dict]:
    """构造通义万相请求

    Returns:
        (url, headers, body)
    """
    api_key = _get_api_key("dashscope")
    url = PROVIDERS["dashscope"]["url"]
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "X-DashScope-Async": "enable",
    }
    # 通义万相的 size 格式是 "1024*1024"
    ds_size = size.replace("x", "*")
    body = {
        "model": model,
        "input": {"prompt": prompt},
        "parameters": {"size": ds_size, "n": 1},
    }
    return url, headers, body


# ── 核心功能 ──

async def generate_image(
    prompt: str,
    provider: str = "zhipu",
    size: str = "1024x1024",
) -> str:
    """生成图片

    Args:
        prompt: 图片描述提示词
        provider: 使用的 provider（zhipu 或 dashscope）
        size: 图片尺寸，默认 1024x1024

    Returns:
        图片 URL

    Raises:
        ValueError: provider 未配置或参数错误
        ConnectionError: API 调用失败
    """
    # 自动选择 provider
    if provider == "auto":
        auto = get_available_provider()
        if auto is None:
            raise ValueError(
                "未检测到可用的图片生成 API key，"
                "请设置 ZHIPU_API_KEY 或 DASHSCOPE_API_KEY"
            )
        provider = auto

    if provider not in PROVIDERS:
        raise ValueError(f"不支持的 provider: {provider}，支持: {list(PROVIDERS.keys())}")

    if provider == "zhipu":
        return await _generate_zhipu(prompt, size)
    else:
        return await _generate_dashscope(prompt, size)


async def _generate_zhipu(prompt: str, size: str) -> str:
    """调用智谱 CogView API"""
    url, headers, body = build_zhipu_request(prompt, size)
    try:
        req = urllib_request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with urllib_request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        # 智谱返回格式: {"data": [{"url": "..."}]}
        images = result.get("data", [])
        if images and "url" in images[0]:
            return images[0]["url"]
        raise ConnectionError(f"智谱 API 未返回图片: {result}")
    except Exception as e:
        raise ConnectionError(f"智谱 CogView 调用失败: {e}")


async def _generate_dashscope(prompt: str, size: str) -> str:
    """调用通义万相 API（异步任务模式）"""
    url, headers, body = build_dashscope_request(prompt, size)
    try:
        req = urllib_request.Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with urllib_request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        # 通义万相异步模式：先拿 task_id，再轮询
        task_id = result.get("output", {}).get("task_id")
        if not task_id:
            raise ConnectionError(f"通义万相未返回 task_id: {result}")

        # 轮询任务状态
        import asyncio
        status_url = f"https://dashscope.aliyuncs.com/api/v1/tasks/{task_id}"
        api_key = _get_api_key("dashscope")
        for _ in range(30):  # 最多等 60 秒
            await asyncio.sleep(2)
            status_req = urllib_request.Request(
                status_url,
                headers={"Authorization": f"Bearer {api_key}"},
            )
            with urllib_request.urlopen(status_req, timeout=30) as resp:
                status = json.loads(resp.read().decode("utf-8"))
            task_status = status.get("output", {}).get("task_status")
            if task_status == "SUCCEEDED":
                results = status.get("output", {}).get("results", [])
                if results and "url" in results[0]:
                    return results[0]["url"]
            elif task_status == "FAILED":
                raise ConnectionError(f"通义万相任务失败: {status}")

        raise ConnectionError("通义万相任务超时")
    except ConnectionError:
        raise
    except Exception as e:
        raise ConnectionError(f"通义万相调用失败: {e}")


# ── Tool 定义 ──

IMAGE_GEN_TOOLS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "generate_image",
            "description": "根据文字描述生成图片，支持智谱CogView和通义万相",
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "图片描述提示词",
                    },
                    "provider": {
                        "type": "string",
                        "description": "图片生成服务商",
                        "enum": ["zhipu", "dashscope", "auto"],
                        "default": "auto",
                    },
                    "size": {
                        "type": "string",
                        "description": "图片尺寸",
                        "enum": SUPPORTED_SIZES,
                        "default": "1024x1024",
                    },
                },
                "required": ["prompt"],
            },
        },
    },
]
