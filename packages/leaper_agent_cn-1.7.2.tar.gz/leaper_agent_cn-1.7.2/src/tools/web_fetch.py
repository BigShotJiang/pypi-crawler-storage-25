"""网页抓取工具 — 抓取 URL 提取正文文本"""
import re
import httpx
from src.tools.base import Tool


class WebFetchTool(Tool):
    name = "web_fetch"
    description = "抓取网页 URL，提取正文文本内容"
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "要抓取的 URL"},
            "max_chars": {"type": "integer", "description": "最大返回字符数，默认 5000"},
        },
        "required": ["url"],
    }

    async def execute(self, arguments: dict) -> str:
        url = arguments["url"]
        max_chars = arguments.get("max_chars", 5000)

        try:
            async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
                resp = await client.get(
                    url,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; LeaperBot/1.0)"},
                )
                resp.raise_for_status()
        except Exception as e:
            return f"错误: 抓取失败 — {e}"

        text = self._html_to_text(resp.text)
        if len(text) > max_chars:
            text = text[:max_chars] + "\n\n... [截断]"
        return text

    @staticmethod
    def _html_to_text(html: str) -> str:
        """简单的 HTML → 纯文本转换"""
        # 移除 script/style
        html = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', html, flags=re.DOTALL | re.IGNORECASE)
        # 块级标签换行
        html = re.sub(r'<(br|p|div|h[1-6]|li|tr)[^>]*>', '\n', html, flags=re.IGNORECASE)
        # 移除所有标签
        text = re.sub(r'<[^>]+>', '', html)
        # 解码常见 HTML 实体
        text = text.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&nbsp;', ' ').replace('&quot;', '"')
        # 压缩空行
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()
