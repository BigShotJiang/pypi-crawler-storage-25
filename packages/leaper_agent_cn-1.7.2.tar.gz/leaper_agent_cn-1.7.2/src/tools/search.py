"""搜索工具 - DuckDuckGo HTML 搜索，Bing 兜底，零 API key"""
import json
import re
from typing import Any

import httpx
from src.tools.base import Tool


class SearchTool(Tool):
    name = "search"
    description = "搜索互联网信息，支持中英文搜索"
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "搜索关键词"},
            "max_results": {"type": "integer", "description": "最大结果数，默认 5", "default": 5},
        },
        "required": ["query"],
    }

    # 公共请求头
    _HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }

    async def execute(self, arguments: dict) -> str:
        """执行搜索：先 DuckDuckGo，失败则 fallback 到 Bing"""
        query = arguments["query"]
        max_results = arguments.get("max_results", 5)

        async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
            # 先尝试 DuckDuckGo
            results = await self._search_ddg(client, query, max_results)
            if not results:
                # Fallback 到 Bing
                results = await self._search_bing(client, query, max_results)

        if not results:
            return json.dumps([], ensure_ascii=False)
        return json.dumps(results, ensure_ascii=False)

    async def _search_ddg(self, client: httpx.AsyncClient, query: str, max_results: int) -> list[dict]:
        """DuckDuckGo HTML 搜索（免费，无需 API key）"""
        try:
            resp = await client.post(
                "https://html.duckduckgo.com/html/",
                data={"q": query, "kl": "cn-zh"},  # 中文搜索优化
                headers=self._HEADERS,
            )
            resp.raise_for_status()
            return self._parse_ddg_html(resp.text, max_results)
        except Exception:
            return []

    async def _search_bing(self, client: httpx.AsyncClient, query: str, max_results: int) -> list[dict]:
        """Bing 搜索兜底（免费，无需 API key）"""
        try:
            resp = await client.get(
                "https://www.bing.com/search",
                params={"q": query, "setlang": "zh-Hans", "count": str(max_results)},
                headers=self._HEADERS,
            )
            resp.raise_for_status()
            return self._parse_bing_html(resp.text, max_results)
        except Exception:
            return []

    @staticmethod
    def _parse_ddg_html(html: str, max_results: int) -> list[dict]:
        """解析 DuckDuckGo HTML 搜索结果页"""
        results = []
        # 提取结果链接块
        # DuckDuckGo 结果格式：<a class="result__a" href="...">title</a> ... <a class="result__snippet">snippet</a>
        titles = re.findall(r'class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>', html, re.DOTALL)
        snippets = re.findall(r'class="result__snippet"[^>]*>(.*?)</(?:a|span)', html, re.DOTALL)

        for i, ((url, title), snippet) in enumerate(zip(titles[:max_results], snippets[:max_results])):
            # 清理 HTML 标签
            title_clean = re.sub(r'<[^>]+>', '', title).strip()
            snippet_clean = re.sub(r'<[^>]+>', '', snippet).strip()
            # DuckDuckGo 的 URL 可能是重定向链接，提取真实 URL
            real_url = url
            uddg_match = re.search(r'uddg=([^&]+)', url)
            if uddg_match:
                from urllib.parse import unquote
                real_url = unquote(uddg_match.group(1))
            if title_clean:
                results.append({
                    "title": title_clean,
                    "url": real_url,
                    "snippet": snippet_clean,
                })
        return results

    @staticmethod
    def _parse_bing_html(html: str, max_results: int) -> list[dict]:
        """解析 Bing 搜索结果页"""
        results = []
        # Bing 搜索结果格式：<li class="b_algo"><h2><a href="url">title</a></h2><p>snippet</p></li>
        blocks = re.findall(r'<li class="b_algo">(.*?)</li>', html, re.DOTALL)
        for block in blocks[:max_results]:
            # 提取标题和链接
            title_match = re.search(r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', block, re.DOTALL)
            # 提取摘要
            snippet_match = re.search(r'<p[^>]*>(.*?)</p>', block, re.DOTALL)
            if title_match:
                url = title_match.group(1)
                title = re.sub(r'<[^>]+>', '', title_match.group(2)).strip()
                snippet = ""
                if snippet_match:
                    snippet = re.sub(r'<[^>]+>', '', snippet_match.group(1)).strip()
                results.append({
                    "title": title,
                    "url": url,
                    "snippet": snippet,
                })
        return results
