"""Transcription / 文件解析工具

支持 CSV、JSON、文本、PDF、DOCX、XLSX 等格式的解析。
docx/xlsx 使用 zipfile + xml.etree 直接解析，不引入第三方库。
"""
from __future__ import annotations

import csv
import io
import json
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

from .base import Tool


# ── 解析函数 ──

def parse_csv(file_path: str) -> str:
    """用标准库 csv 模块解析 CSV 文件"""
    path = Path(file_path)
    if not path.exists():
        return f"[错误] 文件不存在: {file_path}"
    text = path.read_text(encoding="utf-8", errors="replace")
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        return "[空 CSV 文件]"
    # 表格格式化
    lines = []
    for i, row in enumerate(rows[:200]):  # 最多200行
        lines.append(" | ".join(row))
        if i == 0:
            lines.append("-" * 40)
    if len(rows) > 200:
        lines.append(f"... (共 {len(rows)} 行，已截断)")
    return "\n".join(lines)


def parse_json(file_path: str) -> str:
    """格式化 JSON 文件"""
    path = Path(file_path)
    if not path.exists():
        return f"[错误] 文件不存在: {file_path}"
    text = path.read_text(encoding="utf-8", errors="replace")
    try:
        data = json.loads(text)
        formatted = json.dumps(data, indent=2, ensure_ascii=False)
        if len(formatted) > 50000:
            return formatted[:50000] + "\n... [内容过长，已截断]"
        return formatted
    except json.JSONDecodeError as e:
        return f"[JSON 解析错误] {e}"


def parse_text(file_path: str) -> str:
    """读取文本文件"""
    path = Path(file_path)
    if not path.exists():
        return f"[错误] 文件不存在: {file_path}"
    text = path.read_text(encoding="utf-8", errors="replace")
    if len(text) > 50000:
        return text[:50000] + "\n... [内容过长，已截断]"
    return text


async def parse_pdf(file_path: str) -> str:
    """尝试用 PyMuPDF 解析 PDF，没有则提示"""
    path = Path(file_path)
    if not path.exists():
        return f"[错误] 文件不存在: {file_path}"
    try:
        import fitz  # type: ignore
        doc = fitz.open(file_path)
        pages = []
        for i, page in enumerate(doc):
            text = page.get_text()
            if text.strip():
                pages.append(f"--- 第 {i+1} 页 ---\n{text.strip()}")
        doc.close()
        if not pages:
            return "[PDF 文件无可提取文本，可能是扫描件]"
        result = "\n\n".join(pages)
        if len(result) > 50000:
            return result[:50000] + "\n... [内容过长，已截断]"
        return result
    except ImportError:
        return "[需要 PyMuPDF 来解析 PDF。请运行: pip install PyMuPDF]"


async def parse_docx(file_path: str) -> str:
    """用 zipfile + xml.etree 解析 docx（不依赖 python-docx）"""
    path = Path(file_path)
    if not path.exists():
        return f"[错误] 文件不存在: {file_path}"
    try:
        with zipfile.ZipFile(file_path, "r") as z:
            if "word/document.xml" not in z.namelist():
                return "[错误] 无效的 docx 文件"
            xml_content = z.read("word/document.xml")
        root = ET.fromstring(xml_content)
        # docx 命名空间
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        paragraphs = []
        for p in root.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
            texts = []
            for t in p.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"):
                if t.text:
                    texts.append(t.text)
            if texts:
                paragraphs.append("".join(texts))
        if not paragraphs:
            return "[docx 文件无文本内容]"
        result = "\n\n".join(paragraphs)
        if len(result) > 50000:
            return result[:50000] + "\n... [内容过长，已截断]"
        return result
    except zipfile.BadZipFile:
        return "[错误] 文件不是有效的 docx 格式"
    except Exception as e:
        return f"[docx 解析错误] {e}"


async def parse_xlsx(file_path: str) -> str:
    """用 zipfile + xml.etree 解析 xlsx（不依赖 openpyxl）"""
    path = Path(file_path)
    if not path.exists():
        return f"[错误] 文件不存在: {file_path}"
    try:
        with zipfile.ZipFile(file_path, "r") as z:
            # 读取共享字符串
            shared_strings: list[str] = []
            if "xl/sharedStrings.xml" in z.namelist():
                ss_xml = z.read("xl/sharedStrings.xml")
                ss_root = ET.fromstring(ss_xml)
                ns_ss = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
                for si in ss_root.iter(f"{{{ns_ss}}}si"):
                    texts = []
                    for t in si.iter(f"{{{ns_ss}}}t"):
                        if t.text:
                            texts.append(t.text)
                    shared_strings.append("".join(texts))

            # 读取第一个 sheet
            sheet_path = "xl/worksheets/sheet1.xml"
            if sheet_path not in z.namelist():
                return "[错误] xlsx 中没有 sheet1"
            sheet_xml = z.read(sheet_path)

        sheet_root = ET.fromstring(sheet_xml)
        ns_main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        rows = []
        for row in sheet_root.iter(f"{{{ns_main}}}row"):
            cells = []
            for c in row.iter(f"{{{ns_main}}}c"):
                val_el = c.find(f"{{{ns_main}}}v")
                if val_el is not None and val_el.text is not None:
                    cell_type = c.get("t", "")
                    if cell_type == "s":
                        # 共享字符串索引
                        idx = int(val_el.text)
                        cells.append(shared_strings[idx] if idx < len(shared_strings) else "")
                    else:
                        cells.append(val_el.text)
                else:
                    cells.append("")
            rows.append(cells)

        if not rows:
            return "[xlsx 文件无数据]"
        lines = []
        for i, row in enumerate(rows[:200]):
            lines.append(" | ".join(row))
            if i == 0:
                lines.append("-" * 40)
        if len(rows) > 200:
            lines.append(f"... (共 {len(rows)} 行，已截断)")
        return "\n".join(lines)
    except zipfile.BadZipFile:
        return "[错误] 文件不是有效的 xlsx 格式"
    except Exception as e:
        return f"[xlsx 解析错误] {e}"


async def parse_file(file_path: str) -> str:
    """自动检测文件类型并解析为文本"""
    ext = Path(file_path).suffix.lower()
    if ext == ".pdf":
        return await parse_pdf(file_path)
    if ext in (".doc", ".docx"):
        return await parse_docx(file_path)
    if ext in (".xls", ".xlsx"):
        return await parse_xlsx(file_path)
    if ext == ".csv":
        return parse_csv(file_path)
    if ext == ".json":
        return parse_json(file_path)
    if ext in (".md", ".txt", ".py", ".js", ".ts", ".html", ".css", ".yaml", ".yml", ".toml", ".cfg", ".ini", ".sh", ".bat", ".ps1"):
        return parse_text(file_path)
    if ext in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"):
        return "[图片文件，请使用 vision 工具分析]"
    if ext in (".mp3", ".wav", ".ogg", ".m4a", ".flac"):
        return "[音频文件，请使用语音转文字工具]"
    if ext in (".mp4", ".avi", ".mkv", ".mov"):
        return "[视频文件，暂不支持直接解析]"
    return f"[不支持的文件格式: {ext}]"


# ── Tool 注册 ──

class ParseFileTool(Tool):
    """文件解析工具 - 注册为 agent tool"""
    name = "parse_file"
    description = "解析文件内容为文本。支持 CSV、JSON、文本、PDF、DOCX、XLSX 等格式。"
    parameters = {
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "要解析的文件路径"
            }
        },
        "required": ["file_path"]
    }

    async def execute(self, arguments: dict) -> str:
        file_path = arguments.get("file_path", "")
        if not file_path:
            return "[错误] 请提供文件路径"
        return await parse_file(file_path)
