"""工具基类"""
from abc import ABC, abstractmethod


class Tool(ABC):
    """所有工具的抽象基类"""
    name: str
    description: str
    parameters: dict  # JSON Schema

    @abstractmethod
    async def execute(self, arguments: dict) -> str:
        """执行工具，返回文本结果"""
        ...
