"""工具输出限制 — 防止过长输出撑爆 context

参考 Hermes tools/tool_output_limits.py
"""

from __future__ import annotations

# 各工具的输出字符数上限
TOOL_LIMITS: dict[str, int] = {
    "terminal": 10000,
    "read_file": 20000,
    "web_fetch": 15000,
    "code_exec": 5000,
    "web_search": 5000,
    "list_dir": 5000,
    "search_files": 5000,
    "edit_file": 3000,
    "_default": 10000,
}


def get_limit(tool_name: str) -> int:
    """获取指定工具的输出上限"""
    return TOOL_LIMITS.get(tool_name, TOOL_LIMITS["_default"])


def set_limit(tool_name: str, limit: int) -> None:
    """动态设置工具输出上限"""
    TOOL_LIMITS[tool_name] = limit


def truncate_output(text: str, tool_name: str = None) -> str:
    """超出限制时截断：保留前 80% + 后 20%，中间插入省略提示

    Args:
        text: 原始输出文本
        tool_name: 工具名称，用于查找对应的输出限制

    Returns:
        截断后的文本（或原文如果未超限）
    """
    if not text:
        return text

    limit = get_limit(tool_name) if tool_name else TOOL_LIMITS["_default"]

    if len(text) <= limit:
        return text

    # 前 80% + 后 20%
    head_size = int(limit * 0.8)
    tail_size = limit - head_size
    omitted = len(text) - head_size - tail_size

    return (
        text[:head_size]
        + f"\n\n... [省略 {omitted} 字符] ...\n\n"
        + text[-tail_size:]
    )
