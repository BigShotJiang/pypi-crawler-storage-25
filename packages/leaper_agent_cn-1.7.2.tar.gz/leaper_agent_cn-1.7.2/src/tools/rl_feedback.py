"""
用户反馈收集器 — 用于 RL 训练数据准备

收集用户对模型输出的评分和反馈，存储为 JSON 文件，
可导出为训练数据用于后续改进。
"""
import json
import os
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional


@dataclass
class FeedbackEntry:
    """单条反馈记录"""
    message_id: str
    rating: int  # 1-5 评分
    comment: str = ""
    timestamp: float = field(default_factory=time.time)
    session_id: str = ""
    model: str = ""
    prompt_summary: str = ""
    response_summary: str = ""


class FeedbackCollector:
    """
    用户反馈收集和管理

    反馈存储在 .feedback/ 目录下，每个 session 一个 JSON 文件。
    """

    def __init__(self, feedback_dir: str = ".feedback"):
        self._dir = feedback_dir
        os.makedirs(self._dir, exist_ok=True)

    def _session_path(self, session_id: str) -> str:
        """获取 session 反馈文件路径"""
        safe_name = session_id.replace("/", "_").replace("\\", "_")
        return os.path.join(self._dir, f"{safe_name}.json")

    def _load_session(self, session_id: str) -> List[Dict]:
        """加载 session 的反馈数据"""
        path = self._session_path(session_id)
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

    def _save_session(self, session_id: str, entries: List[Dict]) -> None:
        """保存 session 的反馈数据"""
        path = self._session_path(session_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=2)

    def record_feedback(
        self,
        message_id: str,
        rating: int,
        comment: str = "",
        session_id: str = "default",
        model: str = "",
        prompt_summary: str = "",
        response_summary: str = "",
    ) -> None:
        """
        记录一条反馈

        Args:
            message_id: 消息 ID
            rating: 评分 1-5
            comment: 用户文字评论
            session_id: 会话 ID
            model: 使用的模型名
            prompt_summary: prompt 摘要
            response_summary: 回复摘要
        """
        if not 1 <= rating <= 5:
            raise ValueError(f"评分必须在 1-5 之间，收到: {rating}")

        entry = FeedbackEntry(
            message_id=message_id,
            rating=rating,
            comment=comment,
            session_id=session_id,
            model=model,
            prompt_summary=prompt_summary,
            response_summary=response_summary,
        )
        entries = self._load_session(session_id)
        entries.append(asdict(entry))
        self._save_session(session_id, entries)

    def get_feedback_stats(self) -> Dict:
        """
        获取反馈统计

        Returns:
            包含总数、平均分、各分数分布等的字典
        """
        all_entries: List[Dict] = []
        if not os.path.isdir(self._dir):
            return {"total": 0, "average": 0.0, "distribution": {}}

        for fname in os.listdir(self._dir):
            if not fname.endswith(".json"):
                continue
            path = os.path.join(self._dir, fname)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        all_entries.extend(data)
            except (json.JSONDecodeError, IOError):
                continue

        if not all_entries:
            return {"total": 0, "average": 0.0, "distribution": {}}

        ratings = [e.get("rating", 0) for e in all_entries]
        distribution: Dict[int, int] = {}
        for r in ratings:
            distribution[r] = distribution.get(r, 0) + 1

        return {
            "total": len(ratings),
            "average": round(sum(ratings) / len(ratings), 2),
            "distribution": distribution,
            "sessions": len([f for f in os.listdir(self._dir) if f.endswith(".json")]),
        }

    def get_improvement_suggestions(self) -> List[str]:
        """
        根据低分反馈提取改进建议

        Returns:
            评论中的改进建议列表
        """
        suggestions: List[str] = []
        if not os.path.isdir(self._dir):
            return suggestions

        for fname in os.listdir(self._dir):
            if not fname.endswith(".json"):
                continue
            path = os.path.join(self._dir, fname)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if not isinstance(data, list):
                        continue
                    for entry in data:
                        # 低分（<=2）且有评论的
                        if entry.get("rating", 5) <= 2 and entry.get("comment"):
                            suggestions.append(entry["comment"])
            except (json.JSONDecodeError, IOError):
                continue

        return suggestions

    def export_training_data(self, path: str) -> int:
        """
        导出训练数据为 JSONL 格式

        Args:
            path: 导出文件路径

        Returns:
            导出的记录数
        """
        count = 0
        with open(path, "w", encoding="utf-8") as out:
            if not os.path.isdir(self._dir):
                return 0
            for fname in os.listdir(self._dir):
                if not fname.endswith(".json"):
                    continue
                fpath = os.path.join(self._dir, fname)
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if not isinstance(data, list):
                            continue
                        for entry in data:
                            out.write(json.dumps(entry, ensure_ascii=False) + "\n")
                            count += 1
                except (json.JSONDecodeError, IOError):
                    continue
        return count
