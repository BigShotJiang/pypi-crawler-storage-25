"""代码执行工具 — 在 subprocess 中执行 Python 代码"""
import asyncio
import sys
from src.tools.base import Tool


class CodeExecuteTool(Tool):
    name = "code_execute"
    description = "执行 Python 代码片段并返回输出结果"
    parameters = {
        "type": "object",
        "properties": {
            "code": {"type": "string", "description": "要执行的 Python 代码"},
            "timeout": {"type": "integer", "description": "超时秒数，默认 30"},
        },
        "required": ["code"],
    }

    async def execute(self, arguments: dict) -> str:
        code = arguments["code"]
        timeout = arguments.get("timeout", 30)

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-c", code,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return f"错误: 代码执行超时 ({timeout}s)"
        except Exception as e:
            return f"错误: 执行失败 — {e}"

        output = ""
        if stdout:
            output += stdout.decode(errors="replace")
        if stderr:
            output += "\n[STDERR]\n" + stderr.decode(errors="replace")
        if proc.returncode != 0:
            output += f"\n[退出码: {proc.returncode}]"

        return output.strip() or "(无输出)"
