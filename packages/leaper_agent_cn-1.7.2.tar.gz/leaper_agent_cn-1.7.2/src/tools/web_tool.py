"""Web 工具 — DuckDuckGo 搜索 + URL 抓取

参考 Hermes web_tools.py 简化实现。
仅用 urllib（不引入 requests/httpx 新依赖）。
"""
import json
import re
import urllib.request
import urllib.parse
import urllib.error
from html.parser import HTMLParser
from src.tools.base import Tool

_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
MAX_FETCH_BYTES = 50 * 1024  # 50KB


# ──────────────────── HTML → 纯文本 ────────────────────

def _strip_html(html: str) -> str:
    """简单 HTML → 纯文本"""
    # 移除 script/style
    html = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', html, flags=re.DOTALL | re.IGNORECASE)
    # 块级标签换行
    html = re.sub(r'<(br|p|div|h[1-6]|li|tr)[^>]*>', '\n', html, flags=re.IGNORECASE)
    # 移除标签
    text = re.sub(r'<[^>]+>', '', html)
    # 常见实体
    for old, new in [('&amp;', '&'), ('&lt;', '<'), ('&gt;', '>'),
                     ('&nbsp;', ' '), ('&quot;', '"'), ('&#39;', "'")]:
        text = text.replace(old, new)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def _url_fetch(url: str, max_bytes: int = MAX_FETCH_BYTES) -> str:
    """用 urllib 抓取 URL，返回文本"""
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = resp.read(max_bytes)
        # 尝试从 header 获取编码
        charset = resp.headers.get_content_charset() or "utf-8"
        return data.decode(charset, errors="replace")


# ──────────────────── web_search ────────────────────

class WebSearchTool(Tool):
    name = "web_search"
    description = "使用 DuckDuckGo 搜索互联网（无需 API key）"
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "搜索关键词"},
            "max_results": {"type": "integer", "description": "最大结果数，默认 5"},
        },
        "required": ["query"],
    }

    async def execute(self, arguments: dict) -> str:
        query = arguments["query"]
        max_results = arguments.get("max_results", 5)

        # DuckDuckGo HTML lite 版搜索
        params = urllib.parse.urlencode({"q": query})
        url = f"https://html.duckduckgo.com/html/?{params}"

        try:
            html = _url_fetch(url, max_bytes=100_000)
        except Exception as e:
            return f"错误: 搜索请求失败 — {e}"

        # 解析搜索结果
        results = self._parse_ddg_results(html, max_results)
        if not results:
            return f"未找到关于 '{query}' 的搜索结果"

        lines = [f"🔍 搜索: {query}\n"]
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. **{r['title']}**")
            lines.append(f"   {r['url']}")
            if r.get("snippet"):
                lines.append(f"   {r['snippet']}")
            lines.append("")
        return "\n".join(lines)

    @staticmethod
    def _parse_ddg_results(html: str, max_results: int) -> list[dict]:
        """从 DuckDuckGo HTML 页面提取搜索结果"""
        results = []
        # 匹配结果链接
        # DuckDuckGo HTML 格式: <a rel="nofollow" class="result__a" href="...">title</a>
        link_pattern = re.compile(
            r'<a[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
            re.DOTALL | re.IGNORECASE,
        )
        snippet_pattern = re.compile(
            r'<a[^>]*class="result__snippet"[^>]*>(.*?)</a>',
            re.DOTALL | re.IGNORECASE,
        )

        links = link_pattern.findall(html)
        snippets = snippet_pattern.findall(html)

        for i, (href, title) in enumerate(links[:max_results]):
            # DDG 的 href 可能是 redirect URL
            actual_url = href
            if "uddg=" in href:
                m = re.search(r'uddg=([^&]+)', href)
                if m:
                    actual_url = urllib.parse.unquote(m.group(1))

            snippet = ""
            if i < len(snippets):
                snippet = re.sub(r'<[^>]+>', '', snippets[i]).strip()

            results.append({
                "title": re.sub(r'<[^>]+>', '', title).strip(),
                "url": actual_url,
                "snippet": snippet,
            })
        return results


# ──────────────────── web_fetch ────────────────────

class WebFetchTool(Tool):
    name = "web_fetch"
    description = "抓取网页 URL，提取正文文本内容"
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "要抓取的 URL"},
            "max_chars": {"type": "integer", "description": "最大返回字符数，默认 5000"},
        },
        "required": ["url"],
    }

    async def execute(self, arguments: dict) -> str:
        url = arguments["url"]
        max_chars = arguments.get("max_chars", 5000)

        try:
            html = _url_fetch(url)
        except Exception as e:
            return f"错误: 抓取失败 — {e}"

        text = _strip_html(html)
        if len(text) > max_chars:
            text = text[:max_chars] + "\n\n... [截断]"
        return text
