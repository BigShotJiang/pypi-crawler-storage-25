"""工具注册表 — 统一管理所有工具（native / MCP / skill）

参考 Hermes tools/registry.py
支持优先级机制：native(100) > MCP(50) > Skill(10)
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union

from .base import Tool
from .schema_sanitizer import sanitize_schema, validate_tool_def

logger = logging.getLogger(__name__)

# 优先级常量
PRIORITY_NATIVE = 100
PRIORITY_MCP = 50
PRIORITY_SKILL = 10


@dataclass
class ToolInfo:
    """工具信息"""
    name: str
    description: str
    schema: dict
    priority: int = 0
    source: str = "native"  # native / mcp / skill


@dataclass
class ToolHandler:
    """工具处理器，包含元信息和执行逻辑"""
    name: str
    handler: Any  # Tool 实例、async callable、或 callable
    schema: dict
    priority: int = 0
    source: str = "native"
    description: str = ""

    def to_info(self) -> ToolInfo:
        return ToolInfo(
            name=self.name,
            description=self.description,
            schema=self.schema,
            priority=self.priority,
            source=self.source,
        )


class ToolRegistry:
    """统一工具注册表

    - 注册/卸载工具
    - 优先级冲突检测
    - 生成 tool schemas 给 LLM
    - 执行工具调用
    """

    def __init__(self):
        self._handlers: Dict[str, ToolHandler] = {}
        self._conflict_log: List[str] = []

    def register(
        self,
        name: str,
        handler: Any,
        schema: dict,
        priority: int = 0,
        source: str = "native",
        description: str = "",
    ) -> None:
        """注册工具

        如果同名工具已存在：
        - 新优先级 >= 旧优先级：覆盖，记录警告
        - 新优先级 < 旧优先级：忽略，记录警告

        Args:
            name: 工具名
            handler: Tool 实例或 callable
            schema: JSON Schema 参数定义
            priority: 优先级（越大越高）
            source: 来源标识
            description: 工具描述
        """
        if name in self._handlers:
            existing = self._handlers[name]
            if priority >= existing.priority:
                msg = (
                    f"工具 '{name}' 被覆盖: "
                    f"{existing.source}(pri={existing.priority}) → "
                    f"{source}(pri={priority})"
                )
                self._conflict_log.append(msg)
                logger.warning(msg)
            else:
                msg = (
                    f"工具 '{name}' 注册被忽略: "
                    f"{source}(pri={priority}) < "
                    f"{existing.source}(pri={existing.priority})"
                )
                self._conflict_log.append(msg)
                logger.info(msg)
                return

        self._handlers[name] = ToolHandler(
            name=name,
            handler=handler,
            schema=schema,
            priority=priority,
            source=source,
            description=description,
        )

    def register_tool(self, tool: Tool, priority: int = PRIORITY_NATIVE) -> None:
        """便捷方法：从 Tool 实例注册"""
        self.register(
            name=tool.name,
            handler=tool,
            schema=tool.parameters,
            priority=priority,
            source="native",
            description=tool.description,
        )

    def unregister(self, name: str) -> bool:
        """卸载工具

        Returns:
            是否成功卸载
        """
        return self._handlers.pop(name, None) is not None

    def get(self, name: str) -> Optional[ToolHandler]:
        """获取工具处理器"""
        return self._handlers.get(name)

    def has(self, name: str) -> bool:
        """检查工具是否已注册"""
        return name in self._handlers

    def list_all(self) -> List[ToolInfo]:
        """列出所有已注册工具的信息"""
        return [h.to_info() for h in self._handlers.values()]

    def get_schemas(self) -> List[dict]:
        """生成所有工具的 JSON Schema 定义列表（用于 LLM）"""
        schemas = []
        for h in self._handlers.values():
            sanitized = sanitize_schema(h.schema)
            schemas.append({
                "type": "function",
                "function": {
                    "name": h.name,
                    "description": h.description,
                    "parameters": sanitized,
                },
            })
        return schemas

    def get_filtered_schemas(self, tool_names: List[str]) -> List[dict]:
        """只返回指定工具名的 schemas"""
        schemas = []
        for name in tool_names:
            h = self._handlers.get(name)
            if h:
                sanitized = sanitize_schema(h.schema)
                schemas.append({
                    "type": "function",
                    "function": {
                        "name": h.name,
                        "description": h.description,
                        "parameters": sanitized,
                    },
                })
        return schemas

    async def execute(self, name: str, args: dict) -> str:
        """执行工具调用

        Args:
            name: 工具名
            args: 参数 dict

        Returns:
            工具执行结果字符串

        Raises:
            KeyError: 工具不存在
        """
        handler_info = self._handlers.get(name)
        if not handler_info:
            raise KeyError(f"工具 '{name}' 未注册")

        handler = handler_info.handler

        # Tool 实例
        if isinstance(handler, Tool):
            return await handler.execute(args)

        # async callable
        if asyncio.iscoroutinefunction(handler):
            return str(await handler(**args))

        # sync callable
        if callable(handler):
            return str(handler(**args))

        raise TypeError(f"工具 '{name}' 的 handler 类型不支持: {type(handler)}")

    def register_from_skills(self, skills_dir: str) -> int:
        """从 skills 目录批量注册工具（占位，后续由 SkillManager 调用）

        Args:
            skills_dir: 技能目录路径

        Returns:
            注册的工具数量
        """
        # 实际逻辑由 SkillManager.to_tool_defs() 提供
        # 这里提供接口兼容
        return 0

    def register_from_mcp(self, mcp_tools: list) -> int:
        """从 MCP 工具列表批量注册

        Args:
            mcp_tools: MCP 工具定义列表，每个元素需有 name/description/schema/handler

        Returns:
            注册的工具数量
        """
        count = 0
        for tool in mcp_tools:
            if not isinstance(tool, dict):
                continue
            name = tool.get("name", "")
            if not name:
                continue
            self.register(
                name=name,
                handler=tool.get("handler"),
                schema=tool.get("schema", {}),
                priority=PRIORITY_MCP,
                source="mcp",
                description=tool.get("description", ""),
            )
            count += 1
        return count

    def get_conflicts(self) -> List[str]:
        """获取冲突日志"""
        return list(self._conflict_log)

    def clear(self) -> None:
        """清空所有注册的工具"""
        self._handlers.clear()
        self._conflict_log.clear()

    def __len__(self) -> int:
        return len(self._handlers)

    def __contains__(self, name: str) -> bool:
        return name in self._handlers
