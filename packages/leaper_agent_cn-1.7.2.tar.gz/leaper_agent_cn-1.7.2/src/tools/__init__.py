"""Tools 模块 - Agent 内置工具

包含原生 native tools（优先）和旧版兼容工具。
native tools 同名时覆盖旧版 Skill-based tools。
"""
from .base import Tool
from .calculator import CalculatorTool, calculate
from .search import SearchTool

# ── 旧版工具（保留兼容） ──
from .file_ops import ReadFileTool as _OldReadFileTool
from .file_ops import WriteFileTool as _OldWriteFileTool
from .file_ops import ListDirectoryTool as _OldListDirectoryTool
from .web_fetch import WebFetchTool as _OldWebFetchTool
from .code_execute import CodeExecuteTool as _OldCodeExecuteTool

# ── Native Tools（新增，优先级高于旧版） ──
from .terminal import TerminalTool
from .file_tool import ReadFileTool, WriteFileTool, EditFileTool, ListDirTool, SearchFilesTool
from .web_tool import WebSearchTool, WebFetchTool
from .code_exec import CodeExecTool
from .todo import AddTodoTool, ListTodosTool, CompleteTodoTool, DeleteTodoTool
from .feishu_doc import FeishuCreateDocTool, FeishuReadDocTool, FeishuUpdateDocTool


def get_all_tools() -> list[Tool]:
    """返回所有内置工具实例（native tools 优先）"""
    return [
        # ── Native Tools ──
        TerminalTool(),
        ReadFileTool(),
        WriteFileTool(),
        EditFileTool(),
        ListDirTool(),
        SearchFilesTool(),
        WebSearchTool(),
        WebFetchTool(),
        CodeExecTool(),
        AddTodoTool(),
        ListTodosTool(),
        CompleteTodoTool(),
        DeleteTodoTool(),
        FeishuCreateDocTool(),
        FeishuReadDocTool(),
        FeishuUpdateDocTool(),
        # ── 旧版工具（不会覆盖同名 native tool） ──
        CalculatorTool(),
        SearchTool(),
    ]


def get_tools_dict() -> dict[str, Tool]:
    """返回 {name: Tool} 字典，供 AgentLoop 使用
    
    注意: 后注册的不会覆盖先注册的，因此 native tools 排在前面。
    如果旧版工具同名，会被 native 覆盖（dict 先到先得改为后到覆盖 → 
    这里用反向逻辑：先放旧版，再放 native 覆盖）。
    """
    tools: dict[str, Tool] = {}
    # 先注册旧版
    for t in [CalculatorTool(), SearchTool(),
              _OldReadFileTool(), _OldWriteFileTool(), _OldListDirectoryTool(),
              _OldWebFetchTool(), _OldCodeExecuteTool()]:
        tools[t.name] = t
    # 再注册 native（同名覆盖旧版）
    for t in [TerminalTool(), ReadFileTool(), WriteFileTool(), EditFileTool(),
              ListDirTool(), SearchFilesTool(), WebSearchTool(), WebFetchTool(),
              CodeExecTool(), AddTodoTool(), ListTodosTool(), CompleteTodoTool(),
              DeleteTodoTool(), FeishuCreateDocTool(), FeishuReadDocTool(),
              FeishuUpdateDocTool()]:
        tools[t.name] = t
    return tools


__all__ = [
    "Tool", "get_all_tools", "get_tools_dict",
    # Native tools
    "TerminalTool", "ReadFileTool", "WriteFileTool", "EditFileTool",
    "ListDirTool", "SearchFilesTool", "WebSearchTool", "WebFetchTool",
    "CodeExecTool", "AddTodoTool", "ListTodosTool", "CompleteTodoTool",
    "DeleteTodoTool", "FeishuCreateDocTool", "FeishuReadDocTool", "FeishuUpdateDocTool",
    # Legacy
    "CalculatorTool", "calculate", "SearchTool",
]
