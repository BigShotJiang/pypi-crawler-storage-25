"""进程注册表 — 管理子进程的生命周期

参考 Hermes tools/process_registry.py
负责进程的创建、追踪、输出收集、超时管理和僵尸清理。
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# 默认配置
DEFAULT_TIMEOUT = 30  # 秒
MAX_CONCURRENT_PROCESSES = 20
ZOMBIE_CHECK_INTERVAL = 60  # 秒
KILL_GRACE_PERIOD = 5  # SIGTERM 后等待秒数再 SIGKILL
OUTPUT_BUFFER_SIZE = 10000  # 最大输出行数


@dataclass
class ProcessInfo:
    """进程信息（外部可见）"""
    pid: int
    cmd: str
    cwd: str
    started_at: float
    is_running: bool
    exit_code: Optional[int] = None


@dataclass
class ProcessHandle:
    """进程句柄（内部使用）"""
    pid: int
    cmd: str
    cwd: str
    started_at: float
    process: asyncio.subprocess.Process
    _stdout_buffer: List[str] = field(default_factory=list)
    _stderr_buffer: List[str] = field(default_factory=list)
    _reader_task: Optional[asyncio.Task] = field(default=None, repr=False)
    _timeout_task: Optional[asyncio.Task] = field(default=None, repr=False)
    timeout: float = DEFAULT_TIMEOUT
    exit_code: Optional[int] = None

    @property
    def is_running(self) -> bool:
        return self.process.returncode is None

    def to_info(self) -> ProcessInfo:
        return ProcessInfo(
            pid=self.pid,
            cmd=self.cmd,
            cwd=self.cwd,
            started_at=self.started_at,
            is_running=self.is_running,
            exit_code=self.process.returncode,
        )


class ProcessRegistry:
    """进程注册表

    功能：
    - 创建和追踪子进程
    - 异步收集 stdout/stderr
    - 超时自动终止
    - 僵尸进程防护
    - 最大并发限制
    """

    def __init__(self, max_concurrent: int = MAX_CONCURRENT_PROCESSES):
        self._processes: Dict[int, ProcessHandle] = {}
        self._max_concurrent = max_concurrent
        self._cleanup_task: Optional[asyncio.Task] = None

    async def spawn(
        self,
        cmd: str,
        cwd: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
        env: Optional[dict] = None,
    ) -> ProcessHandle:
        """创建子进程

        Args:
            cmd: 要执行的命令
            cwd: 工作目录
            timeout: 超时秒数（0 = 不限时）
            env: 环境变量覆盖

        Returns:
            ProcessHandle 进程句柄

        Raises:
            RuntimeError: 超过最大并发数
        """
        # 检查并发限制
        running_count = sum(1 for h in self._processes.values() if h.is_running)
        if running_count >= self._max_concurrent:
            raise RuntimeError(
                f"进程数已达上限 ({self._max_concurrent})，"
                f"请先终止部分进程"
            )

        # 构建环境变量
        proc_env = dict(os.environ)
        if env:
            proc_env.update(env)

        # 创建子进程
        work_dir = cwd or os.getcwd()

        # 根据平台选择 shell
        if sys.platform == "win32":
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE,
                cwd=work_dir,
                env=proc_env,
            )
        else:
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.PIPE,
                cwd=work_dir,
                env=proc_env,
                preexec_fn=os.setsid if hasattr(os, "setsid") else None,
            )

        handle = ProcessHandle(
            pid=process.pid,
            cmd=cmd,
            cwd=work_dir,
            started_at=time.time(),
            process=process,
            timeout=timeout,
        )

        # 启动输出读取任务
        handle._reader_task = asyncio.create_task(
            self._read_output_loop(handle)
        )

        # 启动超时监控
        if timeout > 0:
            handle._timeout_task = asyncio.create_task(
                self._timeout_watchdog(handle)
            )

        self._processes[process.pid] = handle
        logger.info(f"进程已启动: pid={process.pid}, cmd='{cmd[:50]}'")
        return handle

    async def kill(self, pid: int) -> None:
        """终止指定进程

        先发 SIGTERM，等待 KILL_GRACE_PERIOD 秒，
        如果还活着则 SIGKILL。

        Args:
            pid: 进程 ID
        """
        handle = self._processes.get(pid)
        if not handle:
            logger.warning(f"进程 {pid} 不在注册表中")
            return

        if not handle.is_running:
            return

        await self._terminate_process(handle)

    async def kill_all(self) -> None:
        """终止所有运行中的进程"""
        running = [h for h in self._processes.values() if h.is_running]
        if not running:
            return

        tasks = [self._terminate_process(h) for h in running]
        await asyncio.gather(*tasks, return_exceptions=True)
        logger.info(f"已终止 {len(running)} 个进程")

    def list_running(self) -> List[ProcessInfo]:
        """列出所有运行中的进程"""
        return [
            h.to_info() for h in self._processes.values()
            if h.is_running
        ]

    def list_all(self) -> List[ProcessInfo]:
        """列出所有进程（含已结束的）"""
        return [h.to_info() for h in self._processes.values()]

    async def read_output(self, pid: int, timeout: float = 5) -> str:
        """读取进程的输出

        Args:
            pid: 进程 ID
            timeout: 等待超时

        Returns:
            stdout + stderr 合并的输出文本
        """
        handle = self._processes.get(pid)
        if not handle:
            return f"错误: 进程 {pid} 不存在"

        # 如果进程还在运行，等一小段时间收集输出
        if handle.is_running and not handle._stdout_buffer:
            await asyncio.sleep(min(timeout, 0.5))

        lines = list(handle._stdout_buffer)
        if handle._stderr_buffer:
            lines.append("--- stderr ---")
            lines.extend(handle._stderr_buffer)

        return "\n".join(lines) if lines else "(无输出)"

    async def write_input(self, pid: int, data: str) -> None:
        """向进程 stdin 写入数据

        Args:
            pid: 进程 ID
            data: 要写入的文本

        Raises:
            RuntimeError: 进程不存在或已结束
        """
        handle = self._processes.get(pid)
        if not handle:
            raise RuntimeError(f"进程 {pid} 不存在")
        if not handle.is_running:
            raise RuntimeError(f"进程 {pid} 已结束")
        if handle.process.stdin:
            handle.process.stdin.write(data.encode())
            await handle.process.stdin.drain()

    async def wait(self, pid: int, timeout: Optional[float] = None) -> int:
        """等待进程结束

        Args:
            pid: 进程 ID
            timeout: 等待超时（None = 无限等待）

        Returns:
            进程退出码

        Raises:
            RuntimeError: 进程不存在
            asyncio.TimeoutError: 等待超时
        """
        handle = self._processes.get(pid)
        if not handle:
            raise RuntimeError(f"进程 {pid} 不存在")

        if not handle.is_running:
            return handle.process.returncode

        if timeout is not None:
            return await asyncio.wait_for(
                handle.process.wait(), timeout=timeout
            )
        return await handle.process.wait()

    def cleanup_zombies(self) -> int:
        """清理已结束的进程记录

        Returns:
            清理的进程数量
        """
        dead_pids = [
            pid for pid, h in self._processes.items()
            if not h.is_running
        ]
        for pid in dead_pids:
            handle = self._processes.pop(pid)
            # 取消相关任务
            if handle._reader_task and not handle._reader_task.done():
                handle._reader_task.cancel()
            if handle._timeout_task and not handle._timeout_task.done():
                handle._timeout_task.cancel()

        if dead_pids:
            logger.info(f"清理了 {len(dead_pids)} 个已结束的进程")
        return len(dead_pids)

    @property
    def running_count(self) -> int:
        """当前运行中的进程数"""
        return sum(1 for h in self._processes.values() if h.is_running)

    @property
    def total_count(self) -> int:
        """注册表中的总进程数"""
        return len(self._processes)

    # ── 内部方法 ──

    async def _read_output_loop(self, handle: ProcessHandle) -> None:
        """异步读取进程输出到缓冲区"""
        try:
            async def _read_stream(stream, buffer):
                while True:
                    line = await stream.readline()
                    if not line:
                        break
                    text = line.decode("utf-8", errors="replace").rstrip("\n\r")
                    if len(buffer) < OUTPUT_BUFFER_SIZE:
                        buffer.append(text)

            tasks = []
            if handle.process.stdout:
                tasks.append(_read_stream(handle.process.stdout, handle._stdout_buffer))
            if handle.process.stderr:
                tasks.append(_read_stream(handle.process.stderr, handle._stderr_buffer))

            if tasks:
                await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.debug(f"读取进程 {handle.pid} 输出异常: {e}")

    async def _timeout_watchdog(self, handle: ProcessHandle) -> None:
        """超时监控，到时自动终止进程"""
        try:
            await asyncio.sleep(handle.timeout)
            if handle.is_running:
                logger.warning(
                    f"进程 {handle.pid} 超时 ({handle.timeout}s)，正在终止"
                )
                handle._stdout_buffer.append(
                    f"\n[超时: 进程在 {handle.timeout}s 后被终止]"
                )
                await self._terminate_process(handle)
        except asyncio.CancelledError:
            pass

    async def _terminate_process(self, handle: ProcessHandle) -> None:
        """终止进程：先 SIGTERM，再 SIGKILL"""
        if not handle.is_running:
            return

        try:
            # 先尝试温和终止
            if sys.platform == "win32":
                handle.process.terminate()
            else:
                # 尝试终止进程组
                try:
                    os.killpg(os.getpgid(handle.pid), signal.SIGTERM)
                except (ProcessLookupError, PermissionError, OSError):
                    handle.process.terminate()

            # 等待退出
            try:
                await asyncio.wait_for(
                    handle.process.wait(),
                    timeout=KILL_GRACE_PERIOD,
                )
                logger.info(f"进程 {handle.pid} 已温和终止")
                return
            except asyncio.TimeoutError:
                pass

            # 强制终止
            try:
                handle.process.kill()
                await asyncio.wait_for(handle.process.wait(), timeout=2)
            except (ProcessLookupError, asyncio.TimeoutError):
                pass

            logger.info(f"进程 {handle.pid} 已强制终止")

        except ProcessLookupError:
            pass  # 进程已不存在
        except Exception as e:
            logger.error(f"终止进程 {handle.pid} 失败: {e}")
