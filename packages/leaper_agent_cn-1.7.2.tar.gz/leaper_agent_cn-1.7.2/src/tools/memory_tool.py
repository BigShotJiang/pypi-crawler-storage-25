"""Memory Tool - Agent 主动操作记忆的工具

提供 remember / recall / forget / memory_stats / list_memories 五个工具，
与 brain engine 集成。
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .base import Tool


@dataclass
class MemoryEntry:
    """一条记忆"""
    id: str
    content: str
    category: str
    timestamp: float
    metadata: Dict[str, str] = field(default_factory=dict)


class MemoryStore:
    """内存中的记忆存储（可与 brain engine 集成）"""

    def __init__(self) -> None:
        self._memories: Dict[str, MemoryEntry] = {}

    def add(self, content: str, category: str = "general", metadata: Optional[Dict[str, str]] = None) -> MemoryEntry:
        """添加一条记忆"""
        entry = MemoryEntry(
            id=uuid.uuid4().hex[:12],
            content=content,
            category=category,
            timestamp=time.time(),
            metadata=metadata or {},
        )
        self._memories[entry.id] = entry
        return entry

    def search(self, query: str, limit: int = 5) -> List[MemoryEntry]:
        """简单关键词搜索记忆"""
        query_lower = query.lower()
        scored = []
        for entry in self._memories.values():
            text = (entry.content + " " + entry.category).lower()
            # 简单匹配：包含所有查询词
            words = query_lower.split()
            score = sum(1 for w in words if w in text)
            if score > 0:
                scored.append((score, entry))
        scored.sort(key=lambda x: (-x[0], -x[1].timestamp))
        return [e for _, e in scored[:limit]]

    def delete(self, memory_id: str) -> bool:
        """删除一条记忆"""
        if memory_id in self._memories:
            del self._memories[memory_id]
            return True
        return False

    def list(self, category: Optional[str] = None, limit: int = 20) -> List[MemoryEntry]:
        """列出记忆"""
        entries = list(self._memories.values())
        if category:
            entries = [e for e in entries if e.category == category]
        entries.sort(key=lambda e: -e.timestamp)
        return entries[:limit]

    def stats(self) -> Dict[str, int]:
        """统计信息"""
        categories: Dict[str, int] = {}
        for e in self._memories.values():
            categories[e.category] = categories.get(e.category, 0) + 1
        return {"total": len(self._memories), "categories": categories}


# 全局记忆存储实例
_global_store = MemoryStore()


def get_memory_store() -> MemoryStore:
    """获取全局记忆存储"""
    return _global_store


def _format_entry(e: MemoryEntry) -> str:
    """格式化单条记忆"""
    from datetime import datetime
    ts = datetime.fromtimestamp(e.timestamp).strftime("%Y-%m-%d %H:%M")
    return f"[{e.id}] ({e.category}) {ts}\n{e.content}"


# ── Tool 类 ──

class RememberTool(Tool):
    """主动记住一条信息"""
    name = "remember"
    description = "记住一条信息到记忆库中"
    parameters = {
        "type": "object",
        "properties": {
            "content": {"type": "string", "description": "要记住的内容"},
            "category": {"type": "string", "description": "分类，默认 general", "default": "general"},
        },
        "required": ["content"],
    }

    async def execute(self, arguments: dict) -> str:
        content = arguments.get("content", "")
        category = arguments.get("category", "general")
        if not content:
            return "[错误] 内容不能为空"
        entry = _global_store.add(content, category)
        return f"✅ 已记住 (ID: {entry.id}, 分类: {entry.category})"


class RecallTool(Tool):
    """搜索记忆"""
    name = "recall"
    description = "搜索记忆库中的相关信息"
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "搜索关键词"},
            "limit": {"type": "integer", "description": "最多返回条数", "default": 5},
        },
        "required": ["query"],
    }

    async def execute(self, arguments: dict) -> str:
        query = arguments.get("query", "")
        limit = arguments.get("limit", 5)
        if not query:
            return "[错误] 请提供搜索关键词"
        results = _global_store.search(query, limit)
        if not results:
            return "未找到相关记忆"
        lines = [f"找到 {len(results)} 条相关记忆：\n"]
        for e in results:
            lines.append(_format_entry(e))
            lines.append("")
        return "\n".join(lines)


class ForgetTool(Tool):
    """删除一条记忆"""
    name = "forget"
    description = "删除一条记忆"
    parameters = {
        "type": "object",
        "properties": {
            "memory_id": {"type": "string", "description": "要删除的记忆 ID"},
        },
        "required": ["memory_id"],
    }

    async def execute(self, arguments: dict) -> str:
        memory_id = arguments.get("memory_id", "")
        if not memory_id:
            return "[错误] 请提供记忆 ID"
        if _global_store.delete(memory_id):
            return f"✅ 已删除记忆 {memory_id}"
        return f"[错误] 未找到记忆 ID: {memory_id}"


class MemoryStatsTool(Tool):
    """记忆统计"""
    name = "memory_stats"
    description = "查看记忆库统计信息"
    parameters = {"type": "object", "properties": {}}

    async def execute(self, arguments: dict) -> str:
        stats = _global_store.stats()
        lines = [f"📊 记忆统计", f"总数: {stats['total']}"]
        cats = stats.get("categories", {})
        if cats:
            lines.append("分类:")
            for cat, count in sorted(cats.items()):
                lines.append(f"  - {cat}: {count}")
        return "\n".join(lines)


class ListMemoriesTool(Tool):
    """列出记忆"""
    name = "list_memories"
    description = "列出记忆库中的记忆"
    parameters = {
        "type": "object",
        "properties": {
            "category": {"type": "string", "description": "按分类过滤（可选）"},
            "limit": {"type": "integer", "description": "最多返回条数", "default": 20},
        },
    }

    async def execute(self, arguments: dict) -> str:
        category = arguments.get("category")
        limit = arguments.get("limit", 20)
        entries = _global_store.list(category, limit)
        if not entries:
            return "记忆库为空" if not category else f"分类 '{category}' 下无记忆"
        lines = [f"📝 记忆列表 ({len(entries)} 条):\n"]
        for e in entries:
            lines.append(_format_entry(e))
            lines.append("")
        return "\n".join(lines)
