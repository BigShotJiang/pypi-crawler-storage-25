"""
Web 研究工具 — 自动搜索、抓取、提取、汇总

利用已有的 SearchTool 和 WebFetchTool 实现自动化 web 研究流程。
"""
import asyncio
import json
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from src.tools.search import SearchTool
from src.tools.web_fetch import WebFetchTool


@dataclass
class Source:
    """单个来源"""
    url: str
    title: str = ""
    snippet: str = ""
    content: str = ""
    relevance: float = 0.0


@dataclass
class ResearchResult:
    """研究结果"""
    query: str
    sources: List[Source] = field(default_factory=list)
    key_facts: List[str] = field(default_factory=list)
    summary: str = ""


@dataclass
class FactCheckResult:
    """事实核查结果"""
    claim: str
    verdict: str = "未知"  # 可信/存疑/不可信/未知
    confidence: float = 0.0
    supporting: List[Source] = field(default_factory=list)
    contradicting: List[Source] = field(default_factory=list)


class WebResearcher:
    """
    自动化 Web 研究工具

    流程：搜索 → 抓取 → 提取 → 去重 → 汇总
    """

    def __init__(
        self,
        max_concurrent: int = 3,
        fetch_max_chars: int = 5000,
    ):
        self._search = SearchTool()
        self._fetch = WebFetchTool()
        self._max_concurrent = max_concurrent
        self._fetch_max_chars = fetch_max_chars

    async def research(
        self, query: str, max_sources: int = 5
    ) -> ResearchResult:
        """
        自动搜索 → 抓取 → 提取关键信息

        Args:
            query: 搜索查询
            max_sources: 最大来源数
        """
        result = ResearchResult(query=query)

        # 1. 搜索获取 URL 列表
        search_raw = await self._search.execute({
            "query": query,
            "max_results": max_sources + 2,  # 多搜几个以防有些抓取失败
        })
        try:
            search_results = json.loads(search_raw)
        except (json.JSONDecodeError, TypeError):
            return result

        if not search_results:
            return result

        # 2. 构建来源列表
        sources: List[Source] = []
        for item in search_results[:max_sources + 2]:
            url = item.get("url") or item.get("href", "")
            if not url:
                continue
            sources.append(Source(
                url=url,
                title=item.get("title", ""),
                snippet=item.get("snippet", item.get("body", "")),
            ))

        # 3. 并发抓取
        sem = asyncio.Semaphore(self._max_concurrent)

        async def _fetch_one(src: Source) -> Source:
            async with sem:
                try:
                    content = await self._fetch.execute({
                        "url": src.url,
                        "max_chars": self._fetch_max_chars,
                    })
                    src.content = content
                except Exception:
                    src.content = ""
            return src

        tasks = [_fetch_one(s) for s in sources[:max_sources]]
        fetched = await asyncio.gather(*tasks, return_exceptions=True)

        # 4. 过滤有效来源
        valid_sources: List[Source] = []
        for item in fetched:
            if isinstance(item, Source) and (item.content or item.snippet):
                valid_sources.append(item)
        result.sources = valid_sources

        # 5. 提取关键事实（简单去重）
        seen: set = set()
        for src in valid_sources:
            text = src.snippet or src.content[:200]
            # 按句号分割提取关键句
            sentences = re.split(r'[。.！!？?]', text)
            for sent in sentences:
                sent = sent.strip()
                if len(sent) > 10 and sent not in seen:
                    seen.add(sent)
                    result.key_facts.append(sent)
                    if len(result.key_facts) >= 10:
                        break

        # 6. 生成摘要
        if valid_sources:
            titles = [s.title for s in valid_sources if s.title]
            result.summary = f"从 {len(valid_sources)} 个来源获取了关于「{query}」的信息。"
            if titles:
                result.summary += f" 来源包括：{'、'.join(titles[:3])}"

        return result

    async def fact_check(self, claim: str) -> FactCheckResult:
        """
        事实核查：搜索 → 对比多来源 → 判断可信度

        Args:
            claim: 需要核查的声明
        """
        result = FactCheckResult(claim=claim)

        # 搜索声明相关内容
        research = await self.research(f"{claim} 真实性 事实", max_sources=5)

        if not research.sources:
            result.verdict = "未知"
            result.confidence = 0.0
            return result

        # 简单判断：看关键事实中是否有支持或矛盾
        claim_lower = claim.lower()
        support_count = 0
        contradict_count = 0

        for src in research.sources:
            text = (src.snippet + " " + src.content[:300]).lower()
            # 简单关键词匹配
            deny_words = ["假", "谣言", "辟谣", "不实", "虚假", "fake", "false", "debunk"]
            affirm_words = ["确认", "证实", "真实", "属实", "confirmed", "true", "verified"]

            has_deny = any(w in text for w in deny_words)
            has_affirm = any(w in text for w in affirm_words)

            if has_deny and not has_affirm:
                contradict_count += 1
                result.contradicting.append(src)
            elif has_affirm and not has_deny:
                support_count += 1
                result.supporting.append(src)

        total = support_count + contradict_count
        if total == 0:
            result.verdict = "未知"
            result.confidence = 0.0
        elif support_count > contradict_count:
            result.verdict = "可信"
            result.confidence = support_count / total
        elif contradict_count > support_count:
            result.verdict = "存疑"
            result.confidence = contradict_count / total
        else:
            result.verdict = "未知"
            result.confidence = 0.5

        return result

    def to_dict(self, result: ResearchResult) -> Dict:
        """将研究结果转为可序列化的字典"""
        return {
            "query": result.query,
            "summary": result.summary,
            "key_facts": result.key_facts,
            "sources": [
                {"url": s.url, "title": s.title, "snippet": s.snippet}
                for s in result.sources
            ],
        }
