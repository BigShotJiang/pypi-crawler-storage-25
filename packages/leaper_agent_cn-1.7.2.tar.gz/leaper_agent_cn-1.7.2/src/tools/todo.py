"""Todo 待办事项工具

参考 Hermes todo_tool.py 简化实现。
存储: workspace 下 .todos.json
"""
import json
import time
from pathlib import Path
from src.tools.base import Tool

_DEFAULT_TODO_FILE = ".todos.json"


def _load_todos(filepath: Path) -> list[dict]:
    """加载 todo 列表"""
    if not filepath.exists():
        return []
    try:
        return json.loads(filepath.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save_todos(filepath: Path, todos: list[dict]) -> None:
    """保存 todo 列表"""
    filepath.write_text(json.dumps(todos, ensure_ascii=False, indent=2), encoding="utf-8")


class AddTodoTool(Tool):
    name = "add_todo"
    description = "添加一条待办事项"
    parameters = {
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "待办标题"},
            "priority": {"type": "string", "enum": ["high", "medium", "low"], "description": "优先级，默认 medium"},
            "workspace": {"type": "string", "description": "工作目录（todo 文件所在目录）"},
        },
        "required": ["title"],
    }

    async def execute(self, arguments: dict) -> str:
        ws = Path(arguments.get("workspace", ".")).resolve()
        filepath = ws / _DEFAULT_TODO_FILE
        todos = _load_todos(filepath)

        todo = {
            "id": len(todos) + 1,
            "title": arguments["title"],
            "priority": arguments.get("priority", "medium"),
            "done": False,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        todos.append(todo)
        _save_todos(filepath, todos)
        return f"✅ 已添加待办 #{todo['id']}: {todo['title']}"


class ListTodosTool(Tool):
    name = "list_todos"
    description = "列出所有待办事项"
    parameters = {
        "type": "object",
        "properties": {
            "show_done": {"type": "boolean", "description": "是否显示已完成项，默认 false"},
            "workspace": {"type": "string", "description": "工作目录"},
        },
        "required": [],
    }

    async def execute(self, arguments: dict) -> str:
        ws = Path(arguments.get("workspace", ".")).resolve()
        filepath = ws / _DEFAULT_TODO_FILE
        todos = _load_todos(filepath)

        if not todos:
            return "📋 待办列表为空"

        show_done = arguments.get("show_done", False)
        lines = ["📋 待办列表:"]
        for t in todos:
            if not show_done and t.get("done"):
                continue
            status = "✅" if t.get("done") else "⬜"
            pri = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(t.get("priority", "medium"), "🟡")
            lines.append(f"  {status} #{t['id']} [{pri}] {t['title']}")

        return "\n".join(lines) if len(lines) > 1 else "📋 没有未完成的待办"


class CompleteTodoTool(Tool):
    name = "complete_todo"
    description = "标记待办事项为已完成"
    parameters = {
        "type": "object",
        "properties": {
            "id": {"type": "integer", "description": "待办 ID"},
            "workspace": {"type": "string", "description": "工作目录"},
        },
        "required": ["id"],
    }

    async def execute(self, arguments: dict) -> str:
        ws = Path(arguments.get("workspace", ".")).resolve()
        filepath = ws / _DEFAULT_TODO_FILE
        todos = _load_todos(filepath)
        todo_id = arguments["id"]

        for t in todos:
            if t["id"] == todo_id:
                t["done"] = True
                t["completed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                _save_todos(filepath, todos)
                return f"✅ 已完成待办 #{todo_id}: {t['title']}"

        return f"错误: 未找到待办 #{todo_id}"


class DeleteTodoTool(Tool):
    name = "delete_todo"
    description = "删除一条待办事项"
    parameters = {
        "type": "object",
        "properties": {
            "id": {"type": "integer", "description": "待办 ID"},
            "workspace": {"type": "string", "description": "工作目录"},
        },
        "required": ["id"],
    }

    async def execute(self, arguments: dict) -> str:
        ws = Path(arguments.get("workspace", ".")).resolve()
        filepath = ws / _DEFAULT_TODO_FILE
        todos = _load_todos(filepath)
        todo_id = arguments["id"]

        for i, t in enumerate(todos):
            if t["id"] == todo_id:
                removed = todos.pop(i)
                _save_todos(filepath, todos)
                return f"🗑️ 已删除待办 #{todo_id}: {removed['title']}"

        return f"错误: 未找到待办 #{todo_id}"
