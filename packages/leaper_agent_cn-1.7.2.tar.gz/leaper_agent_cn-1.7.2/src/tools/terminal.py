"""终端命令执行工具 — 在 subprocess 中执行 shell 命令

参考 Hermes terminal_tool.py 简化实现。
支持 Windows (PowerShell) + Linux (bash)。
"""
import asyncio
import os
import platform
import re
from src.tools.base import Tool

# 危险命令黑名单（正则）
_DANGEROUS_PATTERNS: list[re.Pattern] = [
    re.compile(r'\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+)?(/|~)\b', re.IGNORECASE),
    re.compile(r'\brm\s+-rf\s+/', re.IGNORECASE),
    re.compile(r'\bformat\s+[a-zA-Z]:', re.IGNORECASE),
    re.compile(r'\bdel\s+/s\b', re.IGNORECASE),
    re.compile(r'\bshutdown\b', re.IGNORECASE),
    re.compile(r'\breboot\b', re.IGNORECASE),
    re.compile(r'\bmkfs\b', re.IGNORECASE),
    re.compile(r'\bdd\s+if=.+of=/dev/', re.IGNORECASE),
    re.compile(r'>\s*/dev/sda', re.IGNORECASE),
    re.compile(r'\b:(){ :\|:& };:', re.IGNORECASE),  # fork bomb
]

MAX_OUTPUT_CHARS = 10000
DEFAULT_TIMEOUT = 30


def is_dangerous(command: str) -> str | None:
    """检查命令是否危险，返回匹配的模式描述或 None"""
    for pat in _DANGEROUS_PATTERNS:
        if pat.search(command):
            return pat.pattern
    return None


class TerminalTool(Tool):
    name = "terminal"
    description = "在终端中执行 shell 命令（Windows PowerShell / Linux bash）"
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "要执行的 shell 命令"},
            "timeout": {"type": "integer", "description": "超时秒数，默认 30"},
            "cwd": {"type": "string", "description": "工作目录（可选）"},
        },
        "required": ["command"],
    }

    async def execute(self, arguments: dict) -> str:
        command = arguments["command"]
        timeout = arguments.get("timeout", DEFAULT_TIMEOUT)
        cwd = arguments.get("cwd")

        # 安全检查
        danger = is_dangerous(command)
        if danger:
            return f"🚫 危险命令被拦截: 匹配规则 [{danger}]"

        # 根据平台选择 shell
        is_win = platform.system() == "Windows"
        if is_win:
            shell_cmd = ["powershell", "-NoProfile", "-Command", command]
        else:
            shell_cmd = ["/bin/bash", "-c", command]

        try:
            proc = await asyncio.create_subprocess_exec(
                *shell_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
                env={**os.environ},
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except Exception:
                pass
            return f"⏱️ 命令超时 ({timeout}s): {command[:100]}"
        except FileNotFoundError:
            return f"错误: shell 不存在"
        except Exception as e:
            return f"错误: 执行失败 — {e}"

        # 拼接输出
        output = ""
        if stdout:
            output += stdout.decode(errors="replace")
        if stderr:
            if output:
                output += "\n"
            output += "[STDERR]\n" + stderr.decode(errors="replace")

        # 截断
        if len(output) > MAX_OUTPUT_CHARS:
            half = MAX_OUTPUT_CHARS // 2
            output = (
                output[:half]
                + f"\n\n... [截断: 输出过长，共 {len(output)} 字符] ...\n\n"
                + output[-half:]
            )

        if proc.returncode != 0:
            output += f"\n[退出码: {proc.returncode}]"

        return output.strip() or "(无输出)"
