"""工具集管理 — 预定义工具组合，支持自定义和合并

参考 Hermes toolsets.py
"""

from __future__ import annotations

from typing import Dict, List, Optional

# 预定义工具集
TOOLSETS: Dict[str, List[str]] = {
    "minimal": [
        "terminal", "read_file", "write_file",
    ],
    "standard": [
        "terminal", "read_file", "write_file", "edit_file",
        "list_dir", "search_files", "web_search", "web_fetch",
    ],
    "full": [
        "terminal", "read_file", "write_file", "edit_file",
        "list_dir", "search_files", "web_search", "web_fetch",
        "code_exec", "calculator", "add_todo", "list_todos",
        "complete_todo", "delete_todo", "analyze_image",
        "feishu_create_doc", "feishu_read_doc", "feishu_update_doc",
    ],
    "safe": [
        "read_file", "list_dir", "web_search", "web_fetch",
        "calculator",
    ],
    "coding": [
        "terminal", "read_file", "write_file", "edit_file",
        "list_dir", "search_files", "code_exec",
    ],
    "research": [
        "web_search", "web_fetch", "read_file", "write_file",
        "analyze_image",
    ],
    "creative": [
        "web_search", "web_fetch", "read_file", "write_file",
    ],
}

# 自定义工具集注册表
_custom_toolsets: Dict[str, List[str]] = {}


def get_toolset(name: str) -> List[str]:
    """获取指定名称的工具集

    Args:
        name: 工具集名称

    Returns:
        工具名称列表

    Raises:
        KeyError: 工具集不存在
    """
    # 先查自定义，再查内置
    if name in _custom_toolsets:
        return list(_custom_toolsets[name])
    if name in TOOLSETS:
        return list(TOOLSETS[name])
    raise KeyError(f"未知的工具集: {name}")


def list_toolsets() -> Dict[str, List[str]]:
    """列出所有可用工具集（内置 + 自定义）

    Returns:
        {工具集名称: 工具列表} 字典
    """
    result = {}
    result.update({k: list(v) for k, v in TOOLSETS.items()})
    result.update({k: list(v) for k, v in _custom_toolsets.items()})
    return result


def merge_toolsets(
    base: str,
    add: Optional[List[str]] = None,
    remove: Optional[List[str]] = None,
) -> List[str]:
    """基于现有工具集进行增删，生成新的工具列表

    Args:
        base: 基础工具集名称
        add: 要添加的工具名称列表
        remove: 要移除的工具名称列表

    Returns:
        合并后的工具名称列表（去重，保持顺序）
    """
    tools = get_toolset(base)

    if add:
        for tool in add:
            if tool not in tools:
                tools.append(tool)

    if remove:
        tools = [t for t in tools if t not in remove]

    return tools


def register_toolset(name: str, tools: List[str]) -> None:
    """注册自定义工具集

    Args:
        name: 工具集名称
        tools: 工具名称列表
    """
    _custom_toolsets[name] = list(tools)


def unregister_toolset(name: str) -> bool:
    """移除自定义工具集

    Args:
        name: 工具集名称

    Returns:
        是否成功移除
    """
    return _custom_toolsets.pop(name, None) is not None
