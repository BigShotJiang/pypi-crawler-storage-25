"""文件操作工具"""
import os
from pathlib import Path
from src.tools.base import Tool


class ReadFileTool(Tool):
    name = "read_file"
    description = "读取文件内容"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "文件路径"},
        },
        "required": ["path"],
    }

    async def execute(self, arguments: dict) -> str:
        path = Path(arguments["path"]).expanduser()
        if not path.exists():
            return f"错误: 文件不存在 — {path}"
        if not path.is_file():
            return f"错误: 不是文件 — {path}"
        try:
            content = path.read_text(encoding="utf-8")
            # 截断过大文件
            if len(content) > 50000:
                return content[:50000] + "\n\n... [截断，文件过大]"
            return content
        except Exception as e:
            return f"错误: 读取失败 — {e}"


class WriteFileTool(Tool):
    name = "write_file"
    description = "写入内容到文件（自动创建目录）"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "文件路径"},
            "content": {"type": "string", "description": "要写入的内容"},
        },
        "required": ["path", "content"],
    }

    async def execute(self, arguments: dict) -> str:
        path = Path(arguments["path"]).expanduser()
        content = arguments["content"]
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return f"已写入 {len(content)} 字符到 {path}"
        except Exception as e:
            return f"错误: 写入失败 — {e}"


class ListDirectoryTool(Tool):
    name = "list_directory"
    description = "列出目录下的文件和子目录"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "目录路径，默认当前目录"},
        },
        "required": [],
    }

    async def execute(self, arguments: dict) -> str:
        path = Path(arguments.get("path", ".")).expanduser()
        if not path.exists():
            return f"错误: 目录不存在 — {path}"
        if not path.is_dir():
            return f"错误: 不是目录 — {path}"

        entries = []
        try:
            for item in sorted(path.iterdir()):
                prefix = "📁 " if item.is_dir() else "📄 "
                entries.append(f"{prefix}{item.name}")
            return "\n".join(entries) if entries else "(空目录)"
        except Exception as e:
            return f"错误: 列出目录失败 — {e}"
