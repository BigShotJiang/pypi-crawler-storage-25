"""Voice 工具 — TTS（Edge TTS 协议）+ STT 占位

TTS 使用 Microsoft Edge TTS 免费协议，通过 WebSocket 连接。
不引入 edge-tts 包，直接用标准库 asyncio + ssl + struct 实现。
"""

from __future__ import annotations

import asyncio
import io
import json
import ssl
import struct
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any


# ── 常量 ──

# Edge TTS WebSocket 端点
EDGE_TTS_URL = (
    "wss://speech.platform.bing.com/consumer/speech/synthesize"
    "/readaloud/edge/v1"
    "?TrustedClientToken=6A5AA1D4EAFF4E9FB37E23D68491D6F4"
)

# 支持的中文声音
SUPPORTED_VOICES = {
    "zh-CN-XiaoxiaoNeural": "女声-晓晓（温柔）",
    "zh-CN-YunxiNeural": "男声-云希（年轻）",
    "zh-CN-YunyangNeural": "男声-云扬（新闻）",
    "zh-CN-XiaoyiNeural": "女声-晓伊（活泼）",
    "zh-CN-YunjianNeural": "男声-云健（沉稳）",
}

DEFAULT_VOICE = "zh-CN-XiaoxiaoNeural"

# 默认输出格式
OUTPUT_FORMAT = "audio-24khz-48kbitrate-mono-mp3"


# ── 辅助函数 ──

def _build_config_message(voice: str, rate: str = "+0%", volume: str = "+0%") -> str:
    """构建 SSML 配置消息"""
    return (
        "X-Timestamp:" + datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z\r\n"
        "Content-Type:application/json; charset=utf-8\r\n"
        "Path:speech.config\r\n\r\n"
        '{"context":{"synthesis":{"audio":{"metadataoptions":{'
        '"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},'
        '"outputFormat":"' + OUTPUT_FORMAT + '"}}}}'
    )


def _build_ssml_message(text: str, voice: str, rate: str = "+0%", volume: str = "+0%") -> str:
    """构建 SSML 合成请求消息"""
    request_id = uuid.uuid4().hex
    ssml = (
        f'<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" '
        f'xmlns:mstts="https://www.w3.org/2001/mstts" xml:lang="zh-CN">'
        f'<voice name="{voice}">'
        f'<prosody rate="{rate}" volume="{volume}">'
        f'{_escape_xml(text)}'
        f'</prosody></voice></speak>'
    )
    return (
        f"X-RequestId:{request_id}\r\n"
        "Content-Type:application/ssml+xml\r\n"
        f"X-Timestamp:{datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]}Z\r\n"
        "Path:ssml\r\n\r\n"
        + ssml
    )


def _escape_xml(text: str) -> str:
    """转义 XML 特殊字符"""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def _extract_audio_from_binary(data: bytes) -> bytes:
    """从 WebSocket 二进制帧中提取音频数据

    Edge TTS 二进制帧格式：
    - 前 2 字节：header 长度（big-endian unsigned short）
    - 接下来 header_len 字节：文本 header
    - 剩余字节：音频数据
    """
    if len(data) < 2:
        return b""
    header_len = struct.unpack(">H", data[:2])[0]
    return data[2 + header_len:]


# ── 核心功能 ──

async def text_to_speech(
    text: str,
    voice: str = DEFAULT_VOICE,
    output_path: str | None = None,
    rate: str = "+0%",
    volume: str = "+0%",
) -> bytes:
    """文字转语音（Edge TTS 协议）

    Args:
        text: 要转换的文本
        voice: 声音名称，默认 zh-CN-XiaoxiaoNeural
        output_path: 可选，保存到文件的路径
        rate: 语速调整，如 "+20%", "-10%"
        volume: 音量调整，如 "+50%", "-30%"

    Returns:
        MP3 音频数据的 bytes

    Raises:
        ConnectionError: WebSocket 连接失败
        ValueError: 不支持的声音
    """
    if voice not in SUPPORTED_VOICES:
        raise ValueError(
            f"不支持的声音: {voice}，支持的声音: {list(SUPPORTED_VOICES.keys())}"
        )

    if not text.strip():
        raise ValueError("文本不能为空")

    # 注意：实际 WebSocket 连接需要 websockets 库或底层 asyncio 实现
    # 这里提供协议层的完整实现，但由于不引入 websockets 依赖，
    # 在没有标准库 WebSocket 支持的环境中会降级返回错误提示
    audio_data = await _tts_via_websocket(text, voice, rate, volume)

    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(audio_data)

    return audio_data


async def _tts_via_websocket(
    text: str, voice: str, rate: str, volume: str
) -> bytes:
    """通过 WebSocket 连接 Edge TTS 服务获取音频

    使用 Python 标准库实现简化版 WebSocket 客户端。
    实际生产环境建议用 asyncio 底层 socket 实现完整握手。
    """
    try:
        # 尝试用标准库的底层 socket 实现
        return await _tts_raw_websocket(text, voice, rate, volume)
    except Exception as e:
        raise ConnectionError(
            f"Edge TTS 连接失败: {e}。"
            f"请确保网络可访问 speech.platform.bing.com"
        )


async def _tts_raw_websocket(
    text: str, voice: str, rate: str, volume: str
) -> bytes:
    """使用底层 asyncio 实现 WebSocket 连接

    简化实现：构建 HTTP Upgrade 握手，然后收发 WebSocket 帧。
    """
    import hashlib

    host = "speech.platform.bing.com"
    port = 443
    path = (
        "/consumer/speech/synthesize/readaloud/edge/v1"
        "?TrustedClientToken=6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    )

    # 创建 SSL 连接
    ssl_ctx = ssl.create_default_context()
    reader, writer = await asyncio.open_connection(host, port, ssl=ssl_ctx)

    # WebSocket 握手
    ws_key = "dGhlIHNhbXBsZSBub25jZQ=="  # 固定 key（简化）
    handshake = (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Upgrade: websocket\r\n"
        f"Connection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {ws_key}\r\n"
        f"Sec-WebSocket-Version: 13\r\n"
        f"Origin: chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold\r\n"
        f"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        f"AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0\r\n"
        f"\r\n"
    )
    writer.write(handshake.encode())
    await writer.drain()

    # 读取握手响应
    response = await reader.readuntil(b"\r\n\r\n")
    if b"101" not in response:
        writer.close()
        raise ConnectionError(f"WebSocket 握手失败: {response.decode(errors='replace')}")

    # 发送配置消息
    config_msg = _build_config_message(voice)
    await _ws_send_text(writer, config_msg)

    # 发送 SSML 消息
    ssml_msg = _build_ssml_message(text, voice, rate, volume)
    await _ws_send_text(writer, ssml_msg)

    # 接收音频数据
    audio_chunks: list[bytes] = []
    while True:
        opcode, payload = await _ws_recv_frame(reader)
        if opcode == 0x1:  # 文本帧
            text_data = payload.decode("utf-8", errors="replace")
            if "turn.end" in text_data:
                break
        elif opcode == 0x2:  # 二进制帧（音频）
            audio = _extract_audio_from_binary(payload)
            if audio:
                audio_chunks.append(audio)
        elif opcode == 0x8:  # 关闭帧
            break

    writer.close()
    return b"".join(audio_chunks)


async def _ws_send_text(writer: asyncio.StreamWriter, text: str) -> None:
    """发送 WebSocket 文本帧（客户端需要 masking）"""
    payload = text.encode("utf-8")
    frame = _build_ws_frame(0x1, payload, mask=True)
    writer.write(frame)
    await writer.drain()


def _build_ws_frame(opcode: int, payload: bytes, mask: bool = True) -> bytes:
    """构建 WebSocket 帧"""
    import os
    frame = bytearray()
    frame.append(0x80 | opcode)  # FIN + opcode

    length = len(payload)
    mask_bit = 0x80 if mask else 0

    if length < 126:
        frame.append(mask_bit | length)
    elif length < 65536:
        frame.append(mask_bit | 126)
        frame.extend(struct.pack(">H", length))
    else:
        frame.append(mask_bit | 127)
        frame.extend(struct.pack(">Q", length))

    if mask:
        mask_key = os.urandom(4)
        frame.extend(mask_key)
        masked = bytearray(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        frame.extend(masked)
    else:
        frame.extend(payload)

    return bytes(frame)


async def _ws_recv_frame(reader: asyncio.StreamReader) -> tuple[int, bytes]:
    """接收 WebSocket 帧，返回 (opcode, payload)"""
    header = await reader.readexactly(2)
    opcode = header[0] & 0x0F
    masked = bool(header[1] & 0x80)
    length = header[1] & 0x7F

    if length == 126:
        length = struct.unpack(">H", await reader.readexactly(2))[0]
    elif length == 127:
        length = struct.unpack(">Q", await reader.readexactly(8))[0]

    if masked:
        mask_key = await reader.readexactly(4)
        raw = await reader.readexactly(length)
        payload = bytearray(b ^ mask_key[i % 4] for i, b in enumerate(raw))
    else:
        payload = await reader.readexactly(length)

    return opcode, bytes(payload)


# ── STT 占位 ──

async def speech_to_text(audio_path: str) -> str:
    """语音转文字（占位）

    当前未集成 STT API，需要配置后使用。

    Args:
        audio_path: 音频文件路径

    Returns:
        提示信息
    """
    return "需要配置 STT API（如百度语音、讯飞等）才能使用语音转文字功能"


# ── Tool 定义 ──

VOICE_TOOLS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "text_to_speech",
            "description": "将文字转换为语音（MP3格式），支持多种中文声音",
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "要转换的文本内容",
                    },
                    "voice": {
                        "type": "string",
                        "description": "声音名称",
                        "enum": list(SUPPORTED_VOICES.keys()),
                        "default": DEFAULT_VOICE,
                    },
                    "output_path": {
                        "type": "string",
                        "description": "可选，保存音频文件的路径",
                    },
                },
                "required": ["text"],
            },
        },
    },
]
