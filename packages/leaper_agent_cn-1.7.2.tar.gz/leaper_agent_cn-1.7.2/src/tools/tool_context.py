"""
工具执行上下文

为工具调用提供安全的执行环境，包括工作目录、权限检查、环境变量等。
"""
import os
from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class ToolContext:
    """工具执行上下文"""
    workspace_dir: str = ""
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    is_sandbox: bool = False
    permissions: Dict[str, bool] = field(default_factory=dict)
    env_vars: Dict[str, str] = field(default_factory=dict)

    def get_safe_cwd(self) -> str:
        """获取安全的工作目录，确保目录存在"""
        cwd = self.workspace_dir or os.getcwd()
        if not os.path.isdir(cwd):
            os.makedirs(cwd, exist_ok=True)
        return cwd

    def check_permission(self, tool_name: str) -> bool:
        """检查工具是否有执行权限"""
        # 未配置权限时默认允许
        if not self.permissions:
            return True
        # 显式配置了则查表
        return self.permissions.get(tool_name, not self.is_sandbox)

    def get_env(self, key: str, default: str = "") -> str:
        """获取环境变量，优先上下文中的，再查系统"""
        return self.env_vars.get(key, os.environ.get(key, default))

    def set_env(self, key: str, value: str) -> None:
        """设置上下文环境变量"""
        self.env_vars[key] = value

    def get_workspace_path(self, relative: str) -> str:
        """获取工作区内的绝对路径"""
        base = self.get_safe_cwd()
        full = os.path.normpath(os.path.join(base, relative))
        # sandbox 模式下禁止路径逃逸
        if self.is_sandbox and not full.startswith(os.path.normpath(base)):
            raise PermissionError(f"沙箱模式禁止访问工作区外路径: {relative}")
        return full

    def to_dict(self) -> Dict:
        """序列化"""
        return {
            "workspace_dir": self.workspace_dir,
            "user_id": self.user_id,
            "session_id": self.session_id,
            "is_sandbox": self.is_sandbox,
            "permissions": self.permissions,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "ToolContext":
        """反序列化"""
        return cls(
            workspace_dir=data.get("workspace_dir", ""),
            user_id=data.get("user_id"),
            session_id=data.get("session_id"),
            is_sandbox=data.get("is_sandbox", False),
            permissions=data.get("permissions", {}),
        )
