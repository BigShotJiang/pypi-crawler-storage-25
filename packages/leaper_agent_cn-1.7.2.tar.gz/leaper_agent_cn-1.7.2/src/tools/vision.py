"""Vision 工具 — 图片理解与 OCR

通过支持 vision 的模型（qwen-vl, glm-4v）实现图片理解和文字提取。
不引入额外依赖，基于现有 provider 的 chat 接口。
"""

from __future__ import annotations

import base64
import re
from typing import Any

from ..providers.base import LLMProvider, Message


# ── 辅助函数 ──

def is_url(source: str) -> bool:
    """判断是否为 URL"""
    return bool(re.match(r"https?://", source.strip()))


def is_base64(source: str) -> bool:
    """判断是否为 base64 编码的图片数据"""
    # 去掉 data URI 前缀
    cleaned = re.sub(r"^data:image/[^;]+;base64,", "", source.strip())
    if len(cleaned) < 20:
        return False
    try:
        decoded = base64.b64decode(cleaned, validate=True)
        return len(decoded) > 10
    except Exception:
        return False


def build_image_url(source: str) -> str:
    """将 image_source 统一为 URL 格式

    - 如果已是 URL，直接返回
    - 如果是 base64（含或不含 data URI 前缀），转为 data URI
    """
    if is_url(source):
        return source.strip()
    # base64 → data URI
    cleaned = source.strip()
    if cleaned.startswith("data:image/"):
        return cleaned
    return f"data:image/png;base64,{cleaned}"


def build_vision_messages(image_source: str, prompt: str) -> list[dict]:
    """构造 multimodal 消息格式（OpenAI 兼容）

    Returns:
        消息列表，包含 image_url content block
    """
    image_url = build_image_url(image_source)
    return [
        {
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {"url": image_url},
                },
                {
                    "type": "text",
                    "text": prompt,
                },
            ],
        }
    ]


# ── 核心功能 ──

async def analyze_image(
    image_source: str,
    prompt: str = "请描述这张图片的内容",
    provider: LLMProvider | None = None,
) -> str:
    """分析图片内容

    Args:
        image_source: 图片 URL 或 base64 字符串
        prompt: 分析提示词
        provider: LLM provider（需支持 vision 模型）

    Returns:
        模型对图片的分析文本
    """
    if provider is None:
        return "错误：未提供 LLM provider，无法分析图片"

    messages = build_vision_messages(image_source, prompt)
    # 将 dict 消息转为 Message 对象
    msg_objects = [
        Message(role="user", content=None)  # 占位，实际内容在 content blocks 中
    ]
    # 大多数兼容 OpenAI 的 provider 支持传入原始 dict
    # 这里直接构造 Message，content 用 JSON 序列化 multimodal 内容
    import json
    multimodal_content = json.dumps(messages[0]["content"], ensure_ascii=False)
    msg_objects = [Message(role="user", content=multimodal_content)]

    try:
        response = await provider.chat(messages=msg_objects, temperature=0.3)
        return response.content or "模型未返回内容"
    except Exception as e:
        return f"图片分析失败: {e}"


async def extract_text_from_image(
    image_source: str,
    provider: LLMProvider | None = None,
) -> str:
    """从图片中提取文字（OCR）

    Args:
        image_source: 图片 URL 或 base64 字符串
        provider: LLM provider（需支持 vision 模型）

    Returns:
        提取的文字内容
    """
    return await analyze_image(
        image_source=image_source,
        prompt="请提取这张图片中的所有文字内容，保持原始格式。如果没有文字，请说明。",
        provider=provider,
    )


# ── Tool 定义（JSON Schema，供 Agent 使用） ──

VISION_TOOLS: list[dict] = [
    {
        "type": "function",
        "function": {
            "name": "analyze_image",
            "description": "分析图片内容，支持 URL 或 base64 编码的图片",
            "parameters": {
                "type": "object",
                "properties": {
                    "image_source": {
                        "type": "string",
                        "description": "图片 URL 或 base64 编码字符串",
                    },
                    "prompt": {
                        "type": "string",
                        "description": "分析提示词，默认为'请描述这张图片的内容'",
                        "default": "请描述这张图片的内容",
                    },
                },
                "required": ["image_source"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ocr_image",
            "description": "从图片中提取文字（OCR），支持 URL 或 base64 编码的图片",
            "parameters": {
                "type": "object",
                "properties": {
                    "image_source": {
                        "type": "string",
                        "description": "图片 URL 或 base64 编码字符串",
                    },
                },
                "required": ["image_source"],
            },
        },
    },
]
