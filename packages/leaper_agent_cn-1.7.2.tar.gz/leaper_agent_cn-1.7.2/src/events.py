"""事件系统

全局事件发射器，支持同步/异步处理函数、once 一次性监听。
用于模块间松耦合通信。

事件类型约定：
- message.received / message.sent
- tool.called / tool.completed
- brain.stored / brain.recalled
- error.occurred
- session.started / session.ended
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable


class EventEmitter:
    """异步事件发射器

    支持：
    - on / off 注册/注销处理函数
    - once 一次性监听
    - emit 异步触发（自动处理同步/异步 handler）
    """

    def __init__(self) -> None:
        # event -> list[handler]
        self._handlers: dict[str, list[Callable]] = {}
        # 标记 once handler
        self._once_handlers: set[int] = set()

    def on(self, event: str, handler: Callable) -> None:
        """注册事件处理函数

        Args:
            event: 事件名（如 'message.received'）
            handler: 处理函数，可以是同步或异步函数
        """
        self._handlers.setdefault(event, []).append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """注销事件处理函数"""
        handlers = self._handlers.get(event)
        if handlers and handler in handlers:
            handlers.remove(handler)
            self._once_handlers.discard(id(handler))

    def once(self, event: str, handler: Callable) -> None:
        """注册一次性事件处理函数（触发一次后自动注销）"""
        self._handlers.setdefault(event, []).append(handler)
        self._once_handlers.add(id(handler))

    async def emit(self, event: str, **kwargs: Any) -> None:
        """触发事件

        Args:
            event: 事件名
            **kwargs: 传递给处理函数的关键字参数
        """
        handlers = self._handlers.get(event)
        if not handlers:
            return

        to_remove: list[Callable] = []
        for handler in list(handlers):  # 拷贝列表，避免迭代中修改
            try:
                if inspect.iscoroutinefunction(handler):
                    await handler(**kwargs)
                else:
                    handler(**kwargs)
            except Exception:
                # 事件处理函数异常不应影响其他 handler
                pass

            # 处理 once
            if id(handler) in self._once_handlers:
                to_remove.append(handler)
                self._once_handlers.discard(id(handler))

        for h in to_remove:
            if h in handlers:
                handlers.remove(h)

    def listeners(self, event: str) -> list[Callable]:
        """获取某事件的所有处理函数"""
        return list(self._handlers.get(event, []))

    def clear(self, event: str | None = None) -> None:
        """清除事件处理函数

        Args:
            event: 指定事件名则只清除该事件，None 清除所有
        """
        if event is None:
            self._handlers.clear()
            self._once_handlers.clear()
        else:
            handlers = self._handlers.pop(event, [])
            for h in handlers:
                self._once_handlers.discard(id(h))


# 全局事件总线（单例）
event_bus = EventEmitter()
