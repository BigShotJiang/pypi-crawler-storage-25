"""HTTP 网关 — 深度增强版

功能：
- Session 管理：per-user session，支持多用户并发，持久化到文件
- Stream Consumer：处理 LLM 流式响应，超时处理
- 消息队列：per-user 消息队列，防止并发冲突
- Webhook 服务器：统一路由各渠道回调
- 健康检查 & 状态端点
- 优雅关闭：signal handler，等待进行中的请求完成
"""
import asyncio
import json
import logging
import os
import signal
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Awaitable, Dict, List, Optional

from aiohttp import web

from .channels import Channel, create_channel
from .channels.feishu import FeishuChannel
from .channels.dingtalk import DingTalkChannel
from .gateway_config import GatewayConfig
from .gateway_status import GatewayStatus

if TYPE_CHECKING:
    from .agent.multi import MultiAgentManager

logger = logging.getLogger(__name__)

# 消息处理回调类型
MessageCallback = Callable[[str, str, str, Optional[str]], Awaitable[str]]


# ─── Session 管理 ──────────────────────────────────────
@dataclass
class GatewaySession:
    """单用户会话

    Attributes:
        session_id: 唯一标识
        user_id: 用户 ID
        channel: 来源渠道名
        history: 对话历史 [(role, content), ...]
        created_at: 创建时间
        last_active: 最后活跃时间
        metadata: 额外元数据
    """
    session_id: str = ""
    user_id: str = ""
    channel: str = ""
    history: List[Dict[str, str]] = field(default_factory=list)
    created_at: float = 0.0
    last_active: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.session_id:
            self.session_id = str(uuid.uuid4())
        now = time.time()
        if not self.created_at:
            self.created_at = now
        if not self.last_active:
            self.last_active = now

    def add_message(self, role: str, content: str) -> None:
        """添加消息到历史"""
        self.history.append({"role": role, "content": content})
        self.last_active = time.time()

    def is_expired(self, timeout: int = 86400) -> bool:
        """检查 session 是否过期"""
        return (time.time() - self.last_active) > timeout

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "channel": self.channel,
            "history": self.history,
            "created_at": self.created_at,
            "last_active": self.last_active,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GatewaySession":
        """从字典恢复"""
        return cls(
            session_id=data.get("session_id", ""),
            user_id=data.get("user_id", ""),
            channel=data.get("channel", ""),
            history=data.get("history", []),
            created_at=data.get("created_at", 0.0),
            last_active=data.get("last_active", 0.0),
            metadata=data.get("metadata", {}),
        )


class SessionManager:
    """Session 管理器：创建、查找、过期清理、持久化"""

    def __init__(self, session_dir: str = ".sessions",
                 timeout: int = 86400) -> None:
        self._sessions: Dict[str, GatewaySession] = {}  # key = user_id:channel
        self._session_dir = Path(session_dir)
        self._timeout = timeout

    def _key(self, user_id: str, channel: str) -> str:
        return f"{channel}:{user_id}"

    def get_or_create(self, user_id: str, channel: str) -> GatewaySession:
        """获取或创建 session"""
        key = self._key(user_id, channel)
        session = self._sessions.get(key)
        if session and not session.is_expired(self._timeout):
            session.last_active = time.time()
            return session

        # 尝试从文件恢复
        session = self._load(key)
        if session and not session.is_expired(self._timeout):
            self._sessions[key] = session
            session.last_active = time.time()
            return session

        # 创建新 session
        session = GatewaySession(user_id=user_id, channel=channel)
        self._sessions[key] = session
        return session

    def get(self, user_id: str, channel: str) -> Optional[GatewaySession]:
        """获取 session（不创建）"""
        key = self._key(user_id, channel)
        session = self._sessions.get(key)
        if session and not session.is_expired(self._timeout):
            return session
        return None

    def active_count(self) -> int:
        """活跃 session 数"""
        now = time.time()
        return sum(
            1 for s in self._sessions.values()
            if (now - s.last_active) <= self._timeout
        )

    def cleanup(self) -> int:
        """清理过期 session，返回清理数"""
        expired_keys = [
            k for k, s in self._sessions.items()
            if s.is_expired(self._timeout)
        ]
        for key in expired_keys:
            del self._sessions[key]
            # 删除持久化文件
            fp = self._session_dir / f"{key}.json"
            if fp.exists():
                fp.unlink()
        if expired_keys:
            logger.info("清理过期 session: %d 个", len(expired_keys))
        return len(expired_keys)

    def save(self, session: GatewaySession) -> None:
        """持久化 session 到文件"""
        self._session_dir.mkdir(parents=True, exist_ok=True)
        key = self._key(session.user_id, session.channel)
        fp = self._session_dir / f"{key}.json"
        with open(fp, "w", encoding="utf-8") as f:
            json.dump(session.to_dict(), f, ensure_ascii=False)

    def save_all(self) -> None:
        """保存所有活跃 session"""
        for session in self._sessions.values():
            if not session.is_expired(self._timeout):
                self.save(session)

    def _load(self, key: str) -> Optional[GatewaySession]:
        """从文件加载 session"""
        fp = self._session_dir / f"{key}.json"
        if not fp.exists():
            return None
        try:
            with open(fp, "r", encoding="utf-8") as f:
                data = json.load(f)
            return GatewaySession.from_dict(data)
        except Exception as e:
            logger.warning("加载 session 失败 [%s]: %s", key, e)
            return None

    def all_sessions(self) -> List[GatewaySession]:
        """获取所有活跃 session"""
        return [
            s for s in self._sessions.values()
            if not s.is_expired(self._timeout)
        ]


# ─── Stream Consumer ──────────────────────────────────
class StreamConsumer:
    """处理 LLM 流式响应

    收集 stream chunks，支持超时处理和打字状态回调。
    """

    def __init__(self, timeout: float = 60.0) -> None:
        self.timeout = timeout
        self._chunks: List[str] = []
        self._done = False

    async def consume(self, stream, typing_callback: Optional[Callable] = None) -> str:
        """消费流式响应

        Args:
            stream: 异步迭代器，yield str chunks
            typing_callback: 打字状态回调（可选）

        Returns:
            完整响应文本
        """
        self._chunks = []
        self._done = False

        try:
            async with asyncio.timeout(self.timeout):
                async for chunk in stream:
                    self._chunks.append(chunk)
                    # 每收到 chunk 发一次打字状态
                    if typing_callback and len(self._chunks) % 5 == 1:
                        try:
                            await typing_callback()
                        except Exception:
                            pass
        except (asyncio.TimeoutError, TimeoutError):
            logger.warning("Stream 超时 (%ss)", self.timeout)
            if not self._chunks:
                return "回复超时，请稍后重试。"
        except Exception as e:
            logger.error("Stream 消费失败: %s", e)
            if not self._chunks:
                return f"处理出错: {e}"

        self._done = True
        return "".join(self._chunks)

    @property
    def partial_result(self) -> str:
        """获取已收集的部分结果"""
        return "".join(self._chunks)


# ─── 消息队列 ────────────────────────────────────────
class UserMessageQueue:
    """Per-user 消息队列，确保每个用户的消息按顺序处理"""

    def __init__(self, max_concurrent: int = 10) -> None:
        self._queues: Dict[str, asyncio.Queue] = {}  # type: ignore[type-arg]
        self._workers: Dict[str, asyncio.Task] = {}  # type: ignore[type-arg]
        self._max_concurrent = max_concurrent
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._processor: Optional[Callable] = None

    def set_processor(self, processor: Callable) -> None:
        """设置消息处理函数

        processor(channel_name, user_id, content, session) -> reply
        """
        self._processor = processor

    async def enqueue(self, channel_name: str, user_id: str,
                      content: str, session: GatewaySession) -> None:
        """将消息加入用户队列"""
        key = f"{channel_name}:{user_id}"
        if key not in self._queues:
            self._queues[key] = asyncio.Queue()
            self._workers[key] = asyncio.create_task(self._worker(key))

        await self._queues[key].put((channel_name, user_id, content, session))

    async def _worker(self, key: str) -> None:
        """per-user 消息处理 worker"""
        queue = self._queues[key]
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=300)
            except asyncio.TimeoutError:
                # 5 分钟无消息，清理 worker
                del self._queues[key]
                del self._workers[key]
                return

            if self._processor:
                async with self._semaphore:
                    try:
                        await self._processor(*item)
                    except Exception as e:
                        logger.error("消息处理失败 [%s]: %s", key, e)

            queue.task_done()

    async def wait_all(self) -> None:
        """等待所有队列处理完毕"""
        for queue in self._queues.values():
            await queue.join()

    def pending_count(self) -> int:
        """总待处理消息数"""
        return sum(q.qsize() for q in self._queues.values())


# ─── 增强版网关 ──────────────────────────────────────
class Gateway:
    """HTTP 网关，统一管理各渠道 webhook 路由

    增强功能：
    - Session 管理（per-user，持久化）
    - Stream Consumer（LLM 流式响应处理）
    - 消息队列（per-user，防并发冲突）
    - 健康检查 & 状态端点
    - 优雅关闭
    """

    # 渠道对应的 webhook 路径映射
    WEBHOOK_ROUTES: Dict[str, str] = {
        "feishu": "/webhook/feishu",
        "dingtalk": "/webhook/dingtalk",
        "wecom": "/webhook/wecom",
        "wechat": "/webhook/wechat",
        "weixin": "/webhook/weixin",
        "qqbot": "/webhook/qqbot",
    }

    def __init__(self, config: dict,
                 multi_agent_manager: "Optional[MultiAgentManager]" = None):
        # 支持 dict 或 GatewayConfig
        if isinstance(config, GatewayConfig):
            self._gw_config = config
            self.config = config.to_dict()
        else:
            self._gw_config = GatewayConfig.from_dict(config)
            self.config = config

        self.host = self._gw_config.host
        self.port = self._gw_config.port
        self.app = web.Application()
        self.channels: Dict[str, Channel] = {}
        self.multi_agent_manager = multi_agent_manager
        self._message_callback: Optional[MessageCallback] = None

        # 增强组件
        self.sessions = SessionManager(
            session_dir=self._gw_config.session_dir,
            timeout=self._gw_config.session_timeout,
        )
        self.status = GatewayStatus()
        self.message_queue = UserMessageQueue(
            max_concurrent=self._gw_config.max_concurrent,
        )

        # 优雅关闭
        self._shutting_down = False
        self._cleanup_task: Optional[asyncio.Task] = None  # type: ignore[type-arg]

    def on_message(self, callback: MessageCallback) -> None:
        """注册全局消息回调"""
        self._message_callback = callback

    def register_channel(self, name: str, channel: Channel) -> None:
        """注册渠道并绑定 webhook 路由"""
        self.channels[name] = channel

        if name in self.WEBHOOK_ROUTES:
            path = self.WEBHOOK_ROUTES[name]
            handler = self._get_webhook_handler(channel)
            if handler:
                self.app.router.add_route("*", path, handler)
                logger.info("注册 webhook: %s → %s", name, path)

    def _get_webhook_handler(self, channel: Channel):
        """获取渠道的 webhook 处理函数"""
        from .channels.wecom import WeComChannel
        from .channels.wechat import WeChatChannel

        # 新渠道
        try:
            from .channels.weixin import WeixinChannel
            if isinstance(channel, WeixinChannel):
                return channel.handle_webhook
        except ImportError:
            pass

        try:
            from .channels.qqbot import QQBotChannel
            if isinstance(channel, QQBotChannel):
                return channel.handle_webhook
        except ImportError:
            pass

        if isinstance(channel, FeishuChannel):
            return channel.handle_webhook
        elif isinstance(channel, DingTalkChannel):
            return channel.handle_webhook
        elif isinstance(channel, WeComChannel):
            return channel.handle_webhook
        elif isinstance(channel, WeChatChannel):
            return channel.handle_webhook
        return None

    def setup_from_config(self) -> None:
        """从配置文件自动创建并注册所有渠道"""
        channels_config = self.config.get("channels", {})
        for name, ch_config in channels_config.items():
            try:
                channel = create_channel(name, ch_config)

                if self._message_callback or self.multi_agent_manager:
                    channel.on_message(self._create_channel_handler(name))

                self.register_channel(name, channel)
                logger.info("渠道已创建: %s", name)
            except Exception as e:
                logger.error("渠道创建失败 [%s]: %s", name, e)

    def _create_channel_handler(self, channel_name: str):
        """为渠道创建消息处理回调（带 session）"""
        from .channels.base import IncomingMessage

        async def handler(incoming: IncomingMessage) -> Optional[str]:
            if self._shutting_down:
                return "系统维护中，请稍后重试。"

            start_time = time.time()
            try:
                # 获取/创建 session
                session = self.sessions.get_or_create(
                    incoming.user_id, channel_name
                )
                session.add_message("user", incoming.content)

                # 路由消息
                reply: Optional[str] = None
                if self.multi_agent_manager:
                    reply = await self.route_message(
                        message=incoming.content,
                        channel_name=channel_name,
                        user_id=incoming.user_id,
                    )
                elif self._message_callback:
                    reply = await self._message_callback(
                        channel_name, incoming.user_id, incoming.content, None
                    )

                if reply:
                    session.add_message("assistant", reply)

                # 统计
                latency = (time.time() - start_time) * 1000
                self.status.record_message(True, latency)
                self.status.set_active_sessions(self.sessions.active_count())

                return reply
            except Exception as e:
                logger.error("消息处理失败 [%s]: %s", channel_name, e)
                self.status.record_message(False)
                return None

        return handler

    async def _on_startup(self, app: web.Application) -> None:
        """启动时初始化"""
        for name, channel in self.channels.items():
            try:
                await channel.start()
                self.status.channel_online(name)
                logger.info("渠道启动: %s", name)
            except Exception as e:
                self.status.channel_error(name)
                logger.error("渠道启动失败: %s - %s", name, e)

        # 启动定期清理任务
        self._cleanup_task = asyncio.create_task(self._periodic_cleanup())

    async def _on_shutdown(self, app: web.Application) -> None:
        """优雅关闭"""
        self._shutting_down = True
        logger.info("网关正在关闭...")

        # 等待消息队列处理完毕（最多 10 秒）
        try:
            await asyncio.wait_for(self.message_queue.wait_all(), timeout=10)
        except asyncio.TimeoutError:
            logger.warning("消息队列等待超时，强制关闭")

        # 保存所有 session
        self.sessions.save_all()

        # 停止渠道
        for name, channel in self.channels.items():
            try:
                await channel.stop()
                self.status.channel_offline(name)
                logger.info("渠道停止: %s", name)
            except Exception as e:
                logger.error("渠道停止失败: %s - %s", name, e)

        # 取消清理任务
        if self._cleanup_task:
            self._cleanup_task.cancel()

    async def _periodic_cleanup(self) -> None:
        """定期清理过期 session（每 10 分钟）"""
        while not self._shutting_down:
            await asyncio.sleep(600)
            self.sessions.cleanup()
            self.status.set_active_sessions(self.sessions.active_count())

    # ─── HTTP 端点 ────────────────────────────────────
    async def _health(self, request: web.Request) -> web.Response:
        """健康检查端点"""
        health = self.status.get_health()
        # 兼容旧格式：包含 channels 列表
        health["channels"] = list(self.channels.keys())
        return web.json_response(health)

    async def _status_endpoint(self, request: web.Request) -> web.Response:
        """状态查询端点"""
        status = self.status.get_status()
        status["sessions"]["active"] = self.sessions.active_count()
        status["queue_pending"] = self.message_queue.pending_count()
        return web.json_response(status)

    def run(self) -> None:
        """启动服务（阻塞）"""
        self.app.on_startup.append(self._on_startup)
        self.app.on_shutdown.append(self._on_shutdown)
        self.app.router.add_get("/health", self._health)
        self.app.router.add_get("/status", self._status_endpoint)

        logger.info("网关启动: %s:%s", self.host, self.port)
        web.run_app(self.app, host=self.host, port=self.port)

    async def route_message(self, message: str, channel_name: str,
                            user_id: Optional[str] = None) -> str:
        """通过 MultiAgentManager 将消息路由到 Agent"""
        if not self.multi_agent_manager:
            raise RuntimeError("未配置 MultiAgentManager")

        agent_name = self.multi_agent_manager.get_channel_agent(channel_name)
        return await self.multi_agent_manager.route_message(
            message=message, agent_name=agent_name, user_id=user_id
        )
