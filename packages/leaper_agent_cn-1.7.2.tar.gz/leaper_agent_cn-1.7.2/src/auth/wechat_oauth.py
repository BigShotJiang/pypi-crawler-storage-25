"""微信 OAuth 2.0 认证

支持微信开放平台 / 微信公众平台的 OAuth 流程：
- 构造授权 URL（扫码登录 / 公众号网页授权）
- code 换 access_token
- 刷新 access_token
- 获取用户信息
"""
from __future__ import annotations

import time
import logging
from typing import Any, Dict

from src.auth.oauth import TokenInfo, http_get

logger = logging.getLogger(__name__)

# 微信 OAuth 端点
WECHAT_AUTH_URL = "https://open.weixin.qq.com/connect/qrconnect"
WECHAT_MP_AUTH_URL = "https://open.weixin.qq.com/connect/oauth2/authorize"
WECHAT_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token"
WECHAT_REFRESH_URL = "https://api.weixin.qq.com/sns/oauth2/refresh_token"
WECHAT_USERINFO_URL = "https://api.weixin.qq.com/sns/userinfo"


class WechatOAuth:
    """微信 OAuth 2.0 实现

    Args:
        app_id: 微信应用 AppID
        app_secret: 微信应用 AppSecret
        is_mp: 是否为公众号模式（默认 False = 开放平台扫码）
    """

    def __init__(self, app_id: str, app_secret: str,
                 is_mp: bool = False) -> None:
        self.app_id = app_id
        self.app_secret = app_secret
        self.is_mp = is_mp

    @property
    def provider_name(self) -> str:
        return "wechat"

    def get_auth_url(self, redirect_uri: str, state: str = "") -> str:
        """构造微信授权 URL

        开放平台：扫码登录（PC 端）
        公众号：网页授权（移动端）
        """
        import urllib.parse
        params = {
            "appid": self.app_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "snsapi_userinfo" if self.is_mp else "snsapi_login",
            "state": state or "leaper",
        }
        base = WECHAT_MP_AUTH_URL if self.is_mp else WECHAT_AUTH_URL
        url = f"{base}?{urllib.parse.urlencode(params)}#wechat_redirect"
        return url

    async def exchange_code(self, code: str,
                            redirect_uri: str = "") -> TokenInfo:
        """用 code 换取 access_token"""
        url = (f"{WECHAT_TOKEN_URL}?appid={self.app_id}"
               f"&secret={self.app_secret}"
               f"&code={code}&grant_type=authorization_code")
        data = http_get(url)

        if "errcode" in data and data["errcode"] != 0:
            raise RuntimeError(
                f"微信 OAuth 换码失败: {data.get('errmsg', '未知错误')}")

        return TokenInfo(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            expires_at=time.time() + data.get("expires_in", 7200),
            scope=data.get("scope", ""),
            provider="wechat",
            extra={"openid": data.get("openid", ""),
                   "unionid": data.get("unionid", "")},
        )

    async def refresh_token(self, refresh_token: str) -> TokenInfo:
        """刷新 access_token"""
        url = (f"{WECHAT_REFRESH_URL}?appid={self.app_id}"
               f"&grant_type=refresh_token"
               f"&refresh_token={refresh_token}")
        data = http_get(url)

        if "errcode" in data and data["errcode"] != 0:
            raise RuntimeError(
                f"微信 token 刷新失败: {data.get('errmsg', '未知错误')}")

        return TokenInfo(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            expires_at=time.time() + data.get("expires_in", 7200),
            scope=data.get("scope", ""),
            provider="wechat",
            extra={"openid": data.get("openid", "")},
        )

    async def get_user_info(self, token: TokenInfo) -> Dict[str, Any]:
        """获取微信用户信息"""
        openid = token.extra.get("openid", "")
        url = (f"{WECHAT_USERINFO_URL}"
               f"?access_token={token.access_token}"
               f"&openid={openid}&lang=zh_CN")
        data = http_get(url)

        if "errcode" in data and data["errcode"] != 0:
            raise RuntimeError(
                f"获取微信用户信息失败: {data.get('errmsg', '未知错误')}")

        return {
            "openid": data.get("openid", ""),
            "unionid": data.get("unionid", ""),
            "nickname": data.get("nickname", ""),
            "avatar": data.get("headimgurl", ""),
            "sex": data.get("sex", 0),
            "province": data.get("province", ""),
            "city": data.get("city", ""),
            "country": data.get("country", ""),
        }
