"""统一 OAuth 管理器

为微信、飞书、钉钉提供统一的 OAuth 接口。
所有 provider 注册后，通过 provider name 分发到具体实现。
"""
from __future__ import annotations

import time
import logging
import urllib.request
import urllib.parse
import json
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Protocol

logger = logging.getLogger(__name__)


@dataclass
class TokenInfo:
    """OAuth token 信息"""
    access_token: str
    refresh_token: Optional[str] = None
    expires_at: float = 0.0
    scope: str = ""
    provider: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_expired(self) -> bool:
        """判断 token 是否过期（提前 60 秒）"""
        if self.expires_at <= 0:
            return False
        return time.time() >= (self.expires_at - 60)


class OAuthProvider(Protocol):
    """OAuth provider 协议，各平台实现此接口"""

    @property
    def provider_name(self) -> str:
        """provider 名称"""
        ...

    def get_auth_url(self, redirect_uri: str, state: str = "") -> str:
        """构造授权 URL"""
        ...

    async def exchange_code(self, code: str, redirect_uri: str = "") -> TokenInfo:
        """用 code 换 access_token"""
        ...

    async def refresh_token(self, refresh_token: str) -> TokenInfo:
        """刷新 token"""
        ...

    async def get_user_info(self, token: TokenInfo) -> Dict[str, Any]:
        """获取用户信息"""
        ...


class OAuthManager:
    """统一 OAuth 管理器

    注册多个 provider，通过 provider name 分发调用。
    """

    def __init__(self) -> None:
        self._providers: Dict[str, OAuthProvider] = {}
        self._tokens: Dict[str, TokenInfo] = {}  # provider -> token 缓存

    def register(self, provider: OAuthProvider) -> None:
        """注册 OAuth provider"""
        self._providers[provider.provider_name] = provider
        logger.info("注册 OAuth provider: %s", provider.provider_name)

    def get_provider(self, name: str) -> OAuthProvider:
        """获取指定 provider"""
        if name not in self._providers:
            raise ValueError(f"未注册的 OAuth provider: {name}，"
                             f"已注册: {list(self._providers.keys())}")
        return self._providers[name]

    @property
    def providers(self) -> list[str]:
        """已注册的 provider 列表"""
        return list(self._providers.keys())

    def get_auth_url(self, provider: str, redirect_uri: str,
                     state: str = "") -> str:
        """获取授权 URL"""
        p = self.get_provider(provider)
        url = p.get_auth_url(redirect_uri, state)
        logger.debug("生成授权 URL: provider=%s", provider)
        return url

    async def exchange_code(self, provider: str, code: str,
                            redirect_uri: str = "") -> TokenInfo:
        """用授权码换 token"""
        p = self.get_provider(provider)
        token = await p.exchange_code(code, redirect_uri)
        self._tokens[provider] = token
        logger.info("换取 token 成功: provider=%s", provider)
        return token

    async def refresh_token(self, provider: str,
                            refresh_token: str) -> TokenInfo:
        """刷新 token"""
        p = self.get_provider(provider)
        token = await p.refresh_token(refresh_token)
        self._tokens[provider] = token
        logger.info("刷新 token 成功: provider=%s", provider)
        return token

    async def get_user_info(self, provider: str,
                            token: TokenInfo) -> Dict[str, Any]:
        """获取用户信息"""
        p = self.get_provider(provider)
        return await p.get_user_info(token)

    def is_token_expired(self, token_info: TokenInfo) -> bool:
        """检查 token 是否过期"""
        return token_info.is_expired

    def get_cached_token(self, provider: str) -> Optional[TokenInfo]:
        """获取缓存的 token"""
        return self._tokens.get(provider)

    async def ensure_valid_token(self, provider: str) -> Optional[TokenInfo]:
        """确保返回有效 token，过期则自动刷新"""
        token = self._tokens.get(provider)
        if token is None:
            return None
        if not token.is_expired:
            return token
        if token.refresh_token:
            return await self.refresh_token(provider, token.refresh_token)
        logger.warning("token 已过期且无 refresh_token: provider=%s", provider)
        return None


def http_get(url: str, headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """同步 HTTP GET（不引入额外依赖）"""
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


def http_post(url: str, data: Optional[Dict[str, Any]] = None,
              headers: Optional[Dict[str, str]] = None,
              json_body: bool = True) -> Dict[str, Any]:
    """同步 HTTP POST（不引入额外依赖）"""
    h = headers or {}
    if json_body:
        body = json.dumps(data or {}).encode("utf-8")
        h.setdefault("Content-Type", "application/json")
    else:
        body = urllib.parse.urlencode(data or {}).encode("utf-8")
        h.setdefault("Content-Type", "application/x-www-form-urlencoded")
    req = urllib.request.Request(url, data=body, headers=h, method="POST")
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))
