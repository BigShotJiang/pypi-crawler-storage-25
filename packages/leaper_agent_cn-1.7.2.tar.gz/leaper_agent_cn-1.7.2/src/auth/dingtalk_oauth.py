"""钉钉 OAuth 认证

支持钉钉开放平台的 OAuth 流程：
- 企业内部应用 access_token
- 第三方应用 access_token（suiteTicket 模式）
- 用户授权登录
"""
from __future__ import annotations

import time
import logging
from typing import Any, Dict

from src.auth.oauth import TokenInfo, http_post, http_get

logger = logging.getLogger(__name__)

# 钉钉 OAuth 端点
DINGTALK_AUTH_URL = "https://login.dingtalk.com/oauth2/auth"
DINGTALK_TOKEN_URL = "https://api.dingtalk.com/v1.0/oauth2/accessToken"
DINGTALK_USER_TOKEN_URL = "https://api.dingtalk.com/v1.0/oauth2/userAccessToken"
DINGTALK_USERINFO_URL = "https://api.dingtalk.com/v1.0/contact/users/me"


class DingTalkOAuth:
    """钉钉 OAuth 实现

    Args:
        app_key: 钉钉应用 AppKey（即 client_id）
        app_secret: 钉钉应用 AppSecret（即 client_secret）
    """

    def __init__(self, app_key: str, app_secret: str) -> None:
        self.app_key = app_key
        self.app_secret = app_secret
        self._corp_token: str = ""
        self._corp_token_expires: float = 0

    @property
    def provider_name(self) -> str:
        return "dingtalk"

    def get_auth_url(self, redirect_uri: str, state: str = "") -> str:
        """构造钉钉用户授权 URL"""
        import urllib.parse
        params = {
            "client_id": self.app_key,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": "openid",
            "state": state or "leaper",
            "prompt": "consent",
        }
        return f"{DINGTALK_AUTH_URL}?{urllib.parse.urlencode(params)}"

    async def get_corp_access_token(self) -> str:
        """获取企业内部应用 access_token"""
        if self._corp_token and time.time() < self._corp_token_expires:
            return self._corp_token

        data = http_post(DINGTALK_TOKEN_URL, {
            "appKey": self.app_key,
            "appSecret": self.app_secret,
        })

        if "accessToken" not in data:
            raise RuntimeError(
                f"获取钉钉 access_token 失败: {data.get('message', '未知错误')}")

        self._corp_token = data["accessToken"]
        self._corp_token_expires = time.time() + data.get("expireIn", 7200) - 60
        return self._corp_token

    async def exchange_code(self, code: str,
                            redirect_uri: str = "") -> TokenInfo:
        """用 authCode 换取 user_access_token"""
        data = http_post(DINGTALK_USER_TOKEN_URL, {
            "clientId": self.app_key,
            "clientSecret": self.app_secret,
            "code": code,
            "grantType": "authorization_code",
        })

        if "accessToken" not in data:
            raise RuntimeError(
                f"钉钉 OAuth 换码失败: {data.get('message', '未知错误')}")

        return TokenInfo(
            access_token=data["accessToken"],
            refresh_token=data.get("refreshToken"),
            expires_at=time.time() + data.get("expireIn", 7200),
            scope="openid",
            provider="dingtalk",
            extra={
                "corp_id": data.get("corpId", ""),
            },
        )

    async def refresh_token(self, refresh_token: str) -> TokenInfo:
        """刷新 user_access_token"""
        data = http_post(DINGTALK_USER_TOKEN_URL, {
            "clientId": self.app_key,
            "clientSecret": self.app_secret,
            "refreshToken": refresh_token,
            "grantType": "refresh_token",
        })

        if "accessToken" not in data:
            raise RuntimeError(
                f"钉钉 token 刷新失败: {data.get('message', '未知错误')}")

        return TokenInfo(
            access_token=data["accessToken"],
            refresh_token=data.get("refreshToken"),
            expires_at=time.time() + data.get("expireIn", 7200),
            scope="openid",
            provider="dingtalk",
        )

    async def get_user_info(self, token: TokenInfo) -> Dict[str, Any]:
        """获取钉钉用户信息"""
        data = http_get(DINGTALK_USERINFO_URL, headers={
            "x-acs-dingtalk-access-token": token.access_token,
        })

        return {
            "union_id": data.get("unionId", ""),
            "open_id": data.get("openId", ""),
            "nick": data.get("nick", ""),
            "avatar": data.get("avatarUrl", ""),
            "mobile": data.get("mobile", ""),
            "email": data.get("email", ""),
            "state_code": data.get("stateCode", ""),
        }
