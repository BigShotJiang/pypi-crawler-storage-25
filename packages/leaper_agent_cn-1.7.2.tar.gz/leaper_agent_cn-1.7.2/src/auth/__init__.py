"""国内 OAuth 认证模块

支持微信、飞书、钉钉 OAuth 2.0 认证流程。
"""

from src.auth.oauth import OAuthManager, TokenInfo
from src.auth.wechat_oauth import WechatOAuth
from src.auth.feishu_oauth import FeishuOAuth
from src.auth.dingtalk_oauth import DingTalkOAuth

__all__ = [
    "OAuthManager",
    "TokenInfo",
    "WechatOAuth",
    "FeishuOAuth",
    "DingTalkOAuth",
]
