"""飞书 OAuth 认证

支持飞书开放平台的 OAuth 流程：
- app_access_token（应用级别）
- tenant_access_token（租户级别）
- user_access_token（用户级别）
- token 刷新
"""
from __future__ import annotations

import time
import logging
from typing import Any, Dict

from src.auth.oauth import TokenInfo, http_post, http_get

logger = logging.getLogger(__name__)

# 飞书 OAuth 端点
FEISHU_AUTH_URL = "https://open.feishu.cn/open-apis/authen/v1/authorize"
FEISHU_APP_TOKEN_URL = "https://open.feishu.cn/open-apis/auth/v3/app_access_token/internal"
FEISHU_TENANT_TOKEN_URL = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
FEISHU_USER_TOKEN_URL = "https://open.feishu.cn/open-apis/authen/v1/oidc/access_token"
FEISHU_REFRESH_URL = "https://open.feishu.cn/open-apis/authen/v1/oidc/refresh_access_token"
FEISHU_USERINFO_URL = "https://open.feishu.cn/open-apis/authen/v1/user_info"


class FeishuOAuth:
    """飞书 OAuth 实现

    Args:
        app_id: 飞书应用 App ID
        app_secret: 飞书应用 App Secret
    """

    def __init__(self, app_id: str, app_secret: str) -> None:
        self.app_id = app_id
        self.app_secret = app_secret
        self._app_token: str = ""
        self._app_token_expires: float = 0

    @property
    def provider_name(self) -> str:
        return "feishu"

    def get_auth_url(self, redirect_uri: str, state: str = "") -> str:
        """构造飞书用户授权 URL"""
        import urllib.parse
        params = {
            "app_id": self.app_id,
            "redirect_uri": redirect_uri,
            "state": state or "leaper",
        }
        return f"{FEISHU_AUTH_URL}?{urllib.parse.urlencode(params)}"

    async def get_app_access_token(self) -> str:
        """获取 app_access_token（自建应用）"""
        # 缓存未过期，直接返回
        if self._app_token and time.time() < self._app_token_expires:
            return self._app_token

        data = http_post(FEISHU_APP_TOKEN_URL, {
            "app_id": self.app_id,
            "app_secret": self.app_secret,
        })

        if data.get("code", -1) != 0:
            raise RuntimeError(
                f"获取飞书 app_access_token 失败: {data.get('msg', '未知错误')}")

        self._app_token = data["app_access_token"]
        self._app_token_expires = time.time() + data.get("expire", 7200) - 60
        return self._app_token

    async def get_tenant_access_token(self) -> str:
        """获取 tenant_access_token（自建应用）"""
        data = http_post(FEISHU_TENANT_TOKEN_URL, {
            "app_id": self.app_id,
            "app_secret": self.app_secret,
        })

        if data.get("code", -1) != 0:
            raise RuntimeError(
                f"获取飞书 tenant_access_token 失败: {data.get('msg', '未知错误')}")

        return data["tenant_access_token"]

    async def exchange_code(self, code: str,
                            redirect_uri: str = "") -> TokenInfo:
        """用 code 换取 user_access_token"""
        app_token = await self.get_app_access_token()
        data = http_post(FEISHU_USER_TOKEN_URL, {
            "grant_type": "authorization_code",
            "code": code,
        }, headers={
            "Authorization": f"Bearer {app_token}",
        })

        if data.get("code", -1) != 0:
            raise RuntimeError(
                f"飞书 OAuth 换码失败: {data.get('msg', '未知错误')}")

        d = data.get("data", {})
        return TokenInfo(
            access_token=d["access_token"],
            refresh_token=d.get("refresh_token"),
            expires_at=time.time() + d.get("expires_in", 7200),
            scope=d.get("scope", ""),
            provider="feishu",
            extra={
                "token_type": d.get("token_type", "Bearer"),
                "open_id": d.get("open_id", ""),
                "union_id": d.get("union_id", ""),
                "tenant_key": d.get("tenant_key", ""),
            },
        )

    async def refresh_token(self, refresh_token: str) -> TokenInfo:
        """刷新 user_access_token"""
        app_token = await self.get_app_access_token()
        data = http_post(FEISHU_REFRESH_URL, {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        }, headers={
            "Authorization": f"Bearer {app_token}",
        })

        if data.get("code", -1) != 0:
            raise RuntimeError(
                f"飞书 token 刷新失败: {data.get('msg', '未知错误')}")

        d = data.get("data", {})
        return TokenInfo(
            access_token=d["access_token"],
            refresh_token=d.get("refresh_token"),
            expires_at=time.time() + d.get("expires_in", 7200),
            scope=d.get("scope", ""),
            provider="feishu",
            extra={"open_id": d.get("open_id", "")},
        )

    async def get_user_info(self, token: TokenInfo) -> Dict[str, Any]:
        """获取飞书用户信息"""
        data = http_get(FEISHU_USERINFO_URL, headers={
            "Authorization": f"Bearer {token.access_token}",
        })

        if data.get("code", -1) != 0:
            raise RuntimeError(
                f"获取飞书用户信息失败: {data.get('msg', '未知错误')}")

        d = data.get("data", {})
        return {
            "open_id": d.get("open_id", ""),
            "union_id": d.get("union_id", ""),
            "name": d.get("name", ""),
            "avatar": d.get("avatar_url", ""),
            "email": d.get("email", ""),
            "mobile": d.get("mobile", ""),
            "tenant_key": d.get("tenant_key", ""),
        }
