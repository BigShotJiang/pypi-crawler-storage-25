"""性能指标收集器

收集 Agent 运行时的延迟、token 用量、错误率、工具使用等指标。
支持 Prometheus 格式导出。
"""

from __future__ import annotations

import time
import math
from typing import Any, Optional


class MetricsCollector:
    """性能指标收集器

    线程不安全（单线程 asyncio 场景足够）。
    指标按操作名分组，支持延迟百分位数计算。
    """

    def __init__(self) -> None:
        # 延迟记录：operation -> list[duration_ms]
        self._latencies: dict[str, list[float]] = {}
        # token 用量：model -> {prompt: int, completion: int, total: int}
        self._tokens: dict[str, dict[str, int]] = {}
        # 错误计数：error_type -> count
        self._errors: dict[str, int] = {}
        # 工具使用：tool_name -> {success: int, failure: int}
        self._tool_usage: dict[str, dict[str, int]] = {}
        # 总请求数
        self._request_count: int = 0
        self._start_time: float = time.time()

    # ------------------------------------------------------------------
    # 记录方法
    # ------------------------------------------------------------------

    def record_latency(self, operation: str, duration_ms: float) -> None:
        """记录一次操作延迟"""
        self._latencies.setdefault(operation, []).append(duration_ms)
        self._request_count += 1

    def record_tokens(self, model: str, prompt: int, completion: int) -> None:
        """记录 token 使用量"""
        bucket = self._tokens.setdefault(model, {"prompt": 0, "completion": 0, "total": 0})
        bucket["prompt"] += prompt
        bucket["completion"] += completion
        bucket["total"] += prompt + completion

    def record_error(self, error_type: str) -> None:
        """记录一次错误"""
        self._errors[error_type] = self._errors.get(error_type, 0) + 1

    def record_tool_usage(self, tool_name: str, success: bool) -> None:
        """记录工具调用"""
        bucket = self._tool_usage.setdefault(tool_name, {"success": 0, "failure": 0})
        if success:
            bucket["success"] += 1
        else:
            bucket["failure"] += 1

    # ------------------------------------------------------------------
    # 查询方法
    # ------------------------------------------------------------------

    def get_summary(self, period: str = "all") -> dict[str, Any]:
        """获取指标摘要

        Args:
            period: 'all' 返回全部（暂不支持时间段过滤）
        """
        uptime = time.time() - self._start_time
        return {
            "uptime_seconds": round(uptime, 1),
            "total_requests": self._request_count,
            "total_errors": sum(self._errors.values()),
            "tokens": dict(self._tokens),
            "errors": dict(self._errors),
            "tool_usage": dict(self._tool_usage),
            "operations": {
                op: {
                    "count": len(vals),
                    "avg_ms": round(sum(vals) / len(vals), 2) if vals else 0,
                    "max_ms": round(max(vals), 2) if vals else 0,
                    "min_ms": round(min(vals), 2) if vals else 0,
                }
                for op, vals in self._latencies.items()
            },
        }

    def get_latency_percentiles(self, operation: str) -> dict[str, float]:
        """计算 P50, P90, P99 延迟

        Returns:
            {"p50": x, "p90": y, "p99": z} (ms)
        """
        vals = sorted(self._latencies.get(operation, []))
        if not vals:
            return {"p50": 0.0, "p90": 0.0, "p99": 0.0}

        def _pct(p: float) -> float:
            idx = math.ceil(len(vals) * p / 100) - 1
            return round(vals[max(idx, 0)], 2)

        return {"p50": _pct(50), "p90": _pct(90), "p99": _pct(99)}

    def export_prometheus(self) -> str:
        """导出为 Prometheus exposition 格式"""
        lines: list[str] = []

        # 延迟
        for op, vals in self._latencies.items():
            safe_op = op.replace(".", "_").replace("-", "_")
            lines.append(f"# HELP leaper_{safe_op}_duration_ms 操作延迟")
            lines.append(f"# TYPE leaper_{safe_op}_duration_ms summary")
            pcts = self.get_latency_percentiles(op)
            for label, val in pcts.items():
                q = {"p50": "0.5", "p90": "0.9", "p99": "0.99"}[label]
                lines.append(f'leaper_{safe_op}_duration_ms{{quantile="{q}"}} {val}')
            lines.append(f"leaper_{safe_op}_duration_ms_count {len(vals)}")
            lines.append(f"leaper_{safe_op}_duration_ms_sum {round(sum(vals), 2)}")

        # token
        for model, bucket in self._tokens.items():
            safe_model = model.replace(".", "_").replace("-", "_")
            lines.append(f'leaper_tokens_total{{model="{safe_model}",type="prompt"}} {bucket["prompt"]}')
            lines.append(f'leaper_tokens_total{{model="{safe_model}",type="completion"}} {bucket["completion"]}')

        # 错误
        for err, cnt in self._errors.items():
            safe_err = err.replace(".", "_").replace("-", "_")
            lines.append(f'leaper_errors_total{{type="{safe_err}"}} {cnt}')

        # 工具
        for tool, bucket in self._tool_usage.items():
            safe_tool = tool.replace(".", "_").replace("-", "_")
            lines.append(f'leaper_tool_calls_total{{tool="{safe_tool}",result="success"}} {bucket["success"]}')
            lines.append(f'leaper_tool_calls_total{{tool="{safe_tool}",result="failure"}} {bucket["failure"]}')

        return "\n".join(lines) + "\n"

    def reset(self) -> None:
        """重置所有指标"""
        self._latencies.clear()
        self._tokens.clear()
        self._errors.clear()
        self._tool_usage.clear()
        self._request_count = 0
        self._start_time = time.time()
