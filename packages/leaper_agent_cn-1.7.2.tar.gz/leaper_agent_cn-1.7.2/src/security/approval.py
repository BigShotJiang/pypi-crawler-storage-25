"""操作审批机制 - 危险操作分级审批"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from ..constants import RE_DANGEROUS_CMD, SENSITIVE_PATHS

logger = logging.getLogger("leaper.security.approval")


class ApprovalLevel(Enum):
    """审批级别"""
    AUTO_APPROVE = "auto_approve"    # 自动批准
    PROMPT_USER = "prompt_user"      # 需要用户确认
    DENY = "deny"                    # 直接拒绝


class ApprovalStatus(Enum):
    """审批结果状态"""
    APPROVED = "approved"
    DENIED = "denied"
    PENDING = "pending"


@dataclass
class ApprovalResult:
    """审批结果"""
    status: ApprovalStatus
    reason: str
    level: ApprovalLevel
    timestamp: float = field(default_factory=time.time)

    @property
    def is_approved(self) -> bool:
        return self.status == ApprovalStatus.APPROVED

    @property
    def is_denied(self) -> bool:
        return self.status == ApprovalStatus.DENIED


# 操作类型定义
class ActionType(Enum):
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    FILE_DELETE = "file_delete"
    COMMAND_EXEC = "command_exec"
    NETWORK_REQUEST = "network_request"
    SYSTEM_MODIFY = "system_modify"
    CODE_EXECUTE = "code_execute"


# 系统文件路径模式
_SYSTEM_FILE_PATTERNS = [
    re.compile(r"^/etc/", re.IGNORECASE),
    re.compile(r"^/usr/", re.IGNORECASE),
    re.compile(r"^/boot/", re.IGNORECASE),
    re.compile(r"^C:\\Windows\\", re.IGNORECASE),
    re.compile(r"^C:\\Program Files", re.IGNORECASE),
]

# 已知安全域名（自动批准网络请求）
_SAFE_DOMAINS = {
    "api.deepleaper.com",
    "portal.deepleaper.com",
    "dashscope.aliyuncs.com",
    "open.bigmodel.cn",
    "api.deepseek.com",
    "api.moonshot.cn",
}


class ApprovalEngine:
    """审批引擎 - 根据规则判断操作是否需要审批"""

    def __init__(self):
        self._history: list[ApprovalResult] = []
        self._user_approved_actions: set[str] = set()  # 用户已批准的操作签名

    def check_approval(
        self,
        action: ActionType,
        context: Optional[dict] = None,
    ) -> ApprovalResult:
        """检查操作是否需要审批

        Args:
            action: 操作类型
            context: 上下文信息，如 path、command、url 等

        Returns:
            ApprovalResult
        """
        ctx = context or {}

        # 根据操作类型分发
        if action == ActionType.FILE_READ:
            result = self._check_file_read(ctx)
        elif action == ActionType.FILE_WRITE:
            result = self._check_file_write(ctx)
        elif action == ActionType.FILE_DELETE:
            result = self._check_file_delete(ctx)
        elif action == ActionType.COMMAND_EXEC:
            result = self._check_command(ctx)
        elif action == ActionType.NETWORK_REQUEST:
            result = self._check_network(ctx)
        elif action == ActionType.SYSTEM_MODIFY:
            result = ApprovalResult(
                status=ApprovalStatus.DENIED,
                reason="系统文件修改被禁止",
                level=ApprovalLevel.DENY,
            )
        elif action == ActionType.CODE_EXECUTE:
            result = self._check_code_execute(ctx)
        else:
            result = ApprovalResult(
                status=ApprovalStatus.PENDING,
                reason=f"未知操作类型: {action}",
                level=ApprovalLevel.PROMPT_USER,
            )

        self._history.append(result)
        return result

    def approve_action(self, action_signature: str) -> None:
        """用户手动批准某个操作"""
        self._user_approved_actions.add(action_signature)

    def get_history(self) -> list[ApprovalResult]:
        """获取审批历史"""
        return list(self._history)

    # --- 内部检查方法 ---

    def _check_file_read(self, ctx: dict) -> ApprovalResult:
        path = ctx.get("path", "")
        # 敏感路径检查
        normalized = path.replace("\\", "/").lower()
        for sensitive in SENSITIVE_PATHS:
            if sensitive.lower() in normalized:
                return ApprovalResult(
                    status=ApprovalStatus.DENIED,
                    reason=f"敏感路径禁止读取: {path}",
                    level=ApprovalLevel.DENY,
                )
        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason="文件读取自动批准",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_file_write(self, ctx: dict) -> ApprovalResult:
        path = ctx.get("path", "")
        if self._is_system_file(path):
            return ApprovalResult(
                status=ApprovalStatus.DENIED,
                reason=f"系统文件禁止写入: {path}",
                level=ApprovalLevel.DENY,
            )
        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason="文件写入自动批准",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_file_delete(self, ctx: dict) -> ApprovalResult:
        path = ctx.get("path", "")
        if self._is_system_file(path):
            return ApprovalResult(
                status=ApprovalStatus.DENIED,
                reason=f"系统文件禁止删除: {path}",
                level=ApprovalLevel.DENY,
            )
        return ApprovalResult(
            status=ApprovalStatus.PENDING,
            reason=f"删除文件需要确认: {path}",
            level=ApprovalLevel.PROMPT_USER,
        )

    def _check_command(self, ctx: dict) -> ApprovalResult:
        command = ctx.get("command", "")
        if RE_DANGEROUS_CMD.search(command):
            return ApprovalResult(
                status=ApprovalStatus.PENDING,
                reason=f"危险命令需要确认: {command}",
                level=ApprovalLevel.PROMPT_USER,
            )
        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason="命令执行自动批准",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_network(self, ctx: dict) -> ApprovalResult:
        url = ctx.get("url", "")
        # 网络请求默认自动批准但记录
        logger.info("网络请求: %s", url)
        return ApprovalResult(
            status=ApprovalStatus.APPROVED,
            reason=f"网络请求自动批准（已记录）: {url}",
            level=ApprovalLevel.AUTO_APPROVE,
        )

    def _check_code_execute(self, ctx: dict) -> ApprovalResult:
        return ApprovalResult(
            status=ApprovalStatus.PENDING,
            reason="代码执行需要确认",
            level=ApprovalLevel.PROMPT_USER,
        )

    @staticmethod
    def _is_system_file(path: str) -> bool:
        for pattern in _SYSTEM_FILE_PATTERNS:
            if pattern.match(path):
                return True
        return False
