"""沙箱执行 - 命令检查 + 进程隔离 + 资源限制 + 临时目录隔离"""

import asyncio
import os
import re
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# 危险命令黑名单(正则)
_COMMAND_BLACKLIST: list[tuple[str, str]] = [
    (r"\brm\s+(-\w*)?rf\s+/\s*$", "递归删除根目录"),
    (r"\brm\s+(-\w*)?rf\s+/\s", "递归删除根目录"),
    (r"\bformat\b", "格式化磁盘"),
    (r"\bshutdown\b", "关机命令"),
    (r"\breboot\b", "重启命令"),
    (r"\bmkfs\b", "创建文件系统"),
    (r"\bdd\s+.*of=/dev/", "直接写入设备"),
    (r">\s*/dev/sda", "直接写入设备"),
    (r"\bchmod\s+777\s+/", "修改根目录权限"),
    (r"\bcurl\b.*\|\s*\bbash\b", "远程代码执行"),
    (r"\bwget\b.*\|\s*\bbash\b", "远程代码执行"),
]


@dataclass
class ResourceLimits:
    """资源限制配置"""
    max_memory_mb: int = 512        # 最大内存（MB）
    max_cpu_seconds: int = 30       # 最大 CPU 时间（秒）
    max_file_count: int = 100       # 最大文件数
    max_file_size_mb: int = 10      # 单文件最大大小（MB）
    allow_network: bool = True      # 是否允许网络访问
    use_temp_dir: bool = False      # 是否使用临时目录隔离


class Sandbox:
    """沙箱执行器"""

    def __init__(
        self,
        allowed_dirs: list[str] | None = None,
        timeout: int = 30,
        resource_limits: Optional[ResourceLimits] = None,
    ):
        """
        allowed_dirs: 允许访问的目录（默认为当前目录）
        timeout: 执行超时时间(秒)
        resource_limits: 资源限制配置
        """
        if allowed_dirs:
            self._allowed_dirs = [os.path.abspath(d) for d in allowed_dirs]
        else:
            self._allowed_dirs = [os.getcwd()]
        self._timeout = timeout
        self._limits = resource_limits or ResourceLimits()

    def check_file_access(self, path: str) -> bool:
        """检查文件路径是否在允许范围"""
        abs_path = os.path.abspath(path)
        return any(abs_path.startswith(d) for d in self._allowed_dirs)

    def check_command(self, command: str) -> tuple[bool, str]:
        """检查命令安全性,返回 (是否允许, 原因)"""
        cmd_lower = command.strip().lower()
        for pattern, reason in _COMMAND_BLACKLIST:
            if re.search(pattern, cmd_lower):
                return False, reason
        return True, "通过"

    async def execute_code(self, code: str, language: str = "python") -> str:
        """沙箱执行代码(subprocess + timeout)"""
        if language != "python":
            return f"不支持 {language} 语言执行"

        # 确定工作目录
        work_dir = None
        temp_dir_obj = None
        if self._limits.use_temp_dir:
            temp_dir_obj = tempfile.TemporaryDirectory(prefix="leaper_sandbox_")
            work_dir = temp_dir_obj.name

        # 写入临时文件
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8",
            dir=work_dir,
        ) as f:
            f.write(code)
            tmp_path = f.name

        try:
            env = os.environ.copy()
            # 如果限制网络，设置代理为无效地址（简单方案）
            if not self._limits.allow_network:
                env["http_proxy"] = "http://0.0.0.0:0"
                env["https_proxy"] = "http://0.0.0.0:0"

            proc = await asyncio.create_subprocess_exec(
                sys.executable, tmp_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=work_dir,
                env=env,
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=self._timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                return f"执行超时({self._timeout}秒)"

            output = stdout.decode(errors="replace")
            if stderr:
                output += "\n[stderr] " + stderr.decode(errors="replace")
            return output.strip() or "(无输出)"
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            if temp_dir_obj:
                try:
                    temp_dir_obj.cleanup()
                except OSError:
                    pass

    async def execute_command(self, command: str) -> str:
        """沙箱执行命令"""
        allowed, reason = self.check_command(command)
        if not allowed:
            return f"命令被拒绝: {reason}"

        env = os.environ.copy()
        if not self._limits.allow_network:
            env["http_proxy"] = "http://0.0.0.0:0"
            env["https_proxy"] = "http://0.0.0.0:0"

        work_dir = None
        temp_dir_obj = None
        if self._limits.use_temp_dir:
            temp_dir_obj = tempfile.TemporaryDirectory(prefix="leaper_sandbox_")
            work_dir = temp_dir_obj.name

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=work_dir,
                env=env,
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=self._timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                return f"执行超时({self._timeout}秒)"

            output = stdout.decode(errors="replace")
            if stderr:
                output += "\n[stderr] " + stderr.decode(errors="replace")
            return output.strip() or "(无输出)"
        finally:
            if temp_dir_obj:
                try:
                    temp_dir_obj.cleanup()
                except OSError:
                    pass
