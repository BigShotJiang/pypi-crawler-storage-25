"""URL 安全守卫 - SSRF 防护、危险域名检查"""

from __future__ import annotations

import re
from urllib.parse import urlparse

from ..constants import DANGEROUS_DOMAINS, RE_INTERNAL_IP


def is_safe_url(url: str) -> bool:
    """检查 URL 是否安全

    规则：
    1. 必须是 http/https 协议
    2. 不允许访问内网 IP（127.x, 10.x, 172.16-31.x, 192.168.x）
    3. 不允许访问危险域名（云平台 metadata 等）
    4. 不允许 file:// 等其他协议
    """
    if not url:
        return False

    try:
        parsed = urlparse(url)

        # 只允许 http/https
        if parsed.scheme not in ("http", "https"):
            return False

        hostname = (parsed.hostname or "").lower().strip()
        if not hostname:
            return False

        # 检查内网 IP
        if RE_INTERNAL_IP.match(hostname):
            return False

        # 检查危险域名
        for domain in DANGEROUS_DOMAINS:
            if hostname == domain or hostname.endswith("." + domain):
                return False

        # 检查 0.0.0.0
        if hostname in ("0.0.0.0", "[::]"):
            return False

        return True
    except Exception:
        return False


def normalize_url(url: str) -> str:
    """URL 规范化：补全协议、清理多余字符"""
    if not url:
        return ""

    url = url.strip()

    # 补全协议
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        parsed = urlparse(url)
        # 重建 URL（去除 fragment 等）
        normalized = f"{parsed.scheme}://{parsed.netloc}{parsed.path or '/'}"
        if parsed.query:
            normalized += f"?{parsed.query}"
        return normalized
    except Exception:
        return url
