"""File Safety - 文件操作安全检查

检查文件读取、写入、删除操作的安全性。
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Tuple

# 50MB 大小限制
MAX_READ_SIZE = 50 * 1024 * 1024

# 受保护的关键文件名
PROTECTED_FILES = frozenset({
    "MEMORY.md", "SOUL.md", "USER.md", "IDENTITY.md",
    "AGENTS.md", "TOOLS.md", ".env", ".gitignore",
})

# 系统关键目录（禁止写入/删除）
SYSTEM_DIRS = [
    "C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)",
    "/bin", "/sbin", "/usr/bin", "/usr/sbin", "/etc", "/boot",
    "/System", "/Library",
]

# 二进制文件扩展名
BINARY_EXTENSIONS = frozenset({
    ".exe", ".dll", ".so", ".dylib", ".bin", ".dat",
    ".zip", ".gz", ".tar", ".7z", ".rar",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico",
    ".mp3", ".mp4", ".avi", ".mkv", ".wav",
    ".pdf", ".doc", ".xls", ".ppt",
})


def _normalize(path: str) -> str:
    """标准化路径"""
    return os.path.normpath(os.path.abspath(path))


def _is_path_traversal(path: str, workspace: str) -> bool:
    """检查是否存在路径穿越"""
    if not workspace:
        return False
    norm_path = _normalize(path)
    norm_ws = _normalize(workspace)
    return not norm_path.startswith(norm_ws)


def _in_system_dir(path: str) -> bool:
    """检查路径是否在系统目录中"""
    norm = _normalize(path)
    for sd in SYSTEM_DIRS:
        if norm.startswith(_normalize(sd)):
            return True
    return False


def is_safe_to_read(path: str, workspace: str) -> Tuple[bool, str]:
    """检查文件是否可以安全读取

    返回 (安全, 原因)
    """
    p = Path(path)

    # 路径穿越检查
    if workspace and _is_path_traversal(path, workspace):
        return False, f"路径超出工作区范围: {path}"

    if not p.exists():
        return False, f"文件不存在: {path}"

    # 大小检查
    try:
        size = p.stat().st_size
        if size > MAX_READ_SIZE:
            return False, f"文件过大 ({size / 1024 / 1024:.1f}MB > 50MB): {path}"
    except OSError as e:
        return False, f"无法获取文件信息: {e}"

    # 二进制文件检查
    if p.suffix.lower() in BINARY_EXTENSIONS:
        return False, f"二进制文件，不建议直接读取: {path}"

    return True, "安全"


def is_safe_to_write(path: str, workspace: str) -> Tuple[bool, str]:
    """检查文件是否可以安全写入

    返回 (安全, 原因)
    """
    # 路径穿越检查
    if workspace and _is_path_traversal(path, workspace):
        return False, f"路径超出工作区范围: {path}"

    # 系统目录保护
    if _in_system_dir(path):
        return False, f"系统目录禁止写入: {path}"

    # 关键配置文件保护（仅警告，不拦截）
    name = Path(path).name
    if name in PROTECTED_FILES:
        return True, f"⚠️ 注意：正在写入受保护文件 {name}"

    return True, "安全"


def is_safe_to_delete(path: str, workspace: str) -> Tuple[bool, str]:
    """检查文件是否可以安全删除

    返回 (安全, 原因)
    """
    # workspace 外禁止删除
    if workspace and _is_path_traversal(path, workspace):
        return False, f"禁止删除工作区外的文件: {path}"

    # 系统目录保护
    if _in_system_dir(path):
        return False, f"禁止删除系统文件: {path}"

    # 关键文件保护
    name = Path(path).name
    if name in PROTECTED_FILES:
        return False, f"禁止删除关键文件: {name}"

    # 目录删除需额外警惕
    p = Path(path)
    if p.is_dir():
        try:
            count = sum(1 for _ in p.rglob("*"))
            if count > 100:
                return False, f"目录包含 {count} 个文件，请确认后手动删除"
        except OSError:
            pass

    return True, "安全"
