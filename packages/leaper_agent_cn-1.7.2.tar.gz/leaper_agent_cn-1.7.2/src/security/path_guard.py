"""路径安全守卫 - 防止路径穿越、敏感路径访问"""

from __future__ import annotations

import os
from pathlib import Path

from ..constants import SENSITIVE_PATHS


def is_safe_path(path: str, workspace: str) -> bool:
    """检查路径是否安全

    规则：
    1. 不允许路径穿越（.. 逃逸 workspace）
    2. 不允许访问敏感路径
    3. 不允许符号链接指向 workspace 外
    """
    if not path or not workspace:
        return False

    try:
        # 解析为绝对路径
        abs_workspace = os.path.abspath(workspace)
        abs_path = os.path.abspath(os.path.join(abs_workspace, path))

        # 检查路径穿越：解析后必须在 workspace 内
        if not abs_path.startswith(abs_workspace + os.sep) and abs_path != abs_workspace:
            return False

        # 检查敏感路径（用 / 归一化比对）
        normalized = abs_path.replace("\\", "/").lower()
        for sensitive in SENSITIVE_PATHS:
            if sensitive.lower() in normalized:
                return False

        # 如果路径存在，检查符号链接
        if os.path.exists(abs_path) and os.path.islink(abs_path):
            real_path = os.path.realpath(abs_path)
            if not real_path.startswith(abs_workspace + os.sep) and real_path != abs_workspace:
                return False

        return True
    except (OSError, ValueError):
        return False


def sanitize_path(path: str) -> str:
    """清理路径：移除 null 字节、归一化

    不做安全判断，仅做格式清理
    """
    if not path:
        return ""
    # 移除 null 字节
    cleaned = path.replace("\x00", "")
    # 归一化
    cleaned = os.path.normpath(cleaned)
    return cleaned


def is_sensitive_path(path: str) -> bool:
    """检查路径是否在敏感路径黑名单中"""
    if not path:
        return False
    normalized = path.replace("\\", "/").lower()
    for sensitive in SENSITIVE_PATHS:
        if sensitive.lower() in normalized:
            return True
    return False
