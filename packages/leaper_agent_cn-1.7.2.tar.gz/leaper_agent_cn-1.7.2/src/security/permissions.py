"""权限管理器 — 工具调用前的权限检查"""


# 默认配置
DEFAULT_PERMISSION_CONFIG = {
    "auto_approve": ["web-search", "calculator", "datetime", "recall"],
    "require_approval": ["file-write", "code-execute", "web-fetch"],
    "deny": ["rm", "format", "shutdown", "reboot"],
}


class PermissionManager:
    """权限管理器"""

    def __init__(self, config: dict | None = None):
        cfg = config or DEFAULT_PERMISSION_CONFIG
        self._auto_approve: set[str] = set(cfg.get("auto_approve", []))
        self._require_approval: set[str] = set(cfg.get("require_approval", []))
        self._deny: set[str] = set(cfg.get("deny", []))
        self._session_approved: set[str] = set()  # 本次会话已批准的

    def check_permission(self, tool_name: str, arguments: dict | None = None) -> str:
        """返回 'allow' | 'ask' | 'deny'"""
        if tool_name in self._deny:
            return "deny"
        if tool_name in self._auto_approve or tool_name in self._session_approved:
            return "allow"
        if tool_name in self._require_approval:
            return "ask"
        # 未配置的工具默认需要审批
        return "ask"

    def approve(self, tool_name: str):
        """用户批准（本次会话有效）"""
        self._session_approved.add(tool_name)

    def get_approval_prompt(self, tool_name: str, arguments: dict | None = None) -> str:
        """生成审批提示信息"""
        args_str = ""
        if arguments:
            args_str = ", ".join(f"{k}={v!r}" for k, v in arguments.items())
        return f"⚠️ 工具 [{tool_name}] 需要您的批准才能执行。参数: {args_str or '无'}\n输入 y 批准，n 拒绝: "
