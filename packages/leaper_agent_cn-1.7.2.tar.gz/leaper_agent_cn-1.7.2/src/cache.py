"""通用缓存系统

支持 TTL 过期、LRU 淘汰、缓存装饰器。
用于：API 响应缓存、access_token 缓存、搜索结果缓存等。
"""

from __future__ import annotations

import functools
import hashlib
import json
import time
import threading
from collections import OrderedDict
from typing import Any, Callable, Optional


class Cache:
    """通用内存缓存

    特性：
    - TTL（秒）过期
    - LRU 淘汰（超过 max_size 时移除最久未访问的项）
    - 线程安全（通过 Lock）
    - 缓存装饰器
    """

    def __init__(self, max_size: int = 1000, ttl: int = 3600) -> None:
        """
        Args:
            max_size: 最大缓存条目数
            ttl: 默认过期时间（秒），0 表示永不过期
        """
        self.max_size = max_size
        self.ttl = ttl
        # OrderedDict 实现 LRU：最近访问的移到末尾
        self._data: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._lock = threading.Lock()
        # 统计
        self._hits = 0
        self._misses = 0

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值，过期或不存在返回 None"""
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                self._misses += 1
                return None
            value, expire_at = entry
            if expire_at > 0 and time.time() > expire_at:
                # 已过期
                del self._data[key]
                self._misses += 1
                return None
            # LRU: 移到末尾
            self._data.move_to_end(key)
            self._hits += 1
            return value

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """设置缓存值

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 过期时间（秒），None 使用默认 TTL，0 永不过期
        """
        actual_ttl = ttl if ttl is not None else self.ttl
        expire_at = time.time() + actual_ttl if actual_ttl > 0 else 0

        with self._lock:
            if key in self._data:
                self._data.move_to_end(key)
            self._data[key] = (value, expire_at)
            # LRU 淘汰
            while len(self._data) > self.max_size:
                self._data.popitem(last=False)

    def delete(self, key: str) -> bool:
        """删除缓存项，返回是否存在"""
        with self._lock:
            if key in self._data:
                del self._data[key]
                return True
            return False

    def clear(self) -> None:
        """清空所有缓存"""
        with self._lock:
            self._data.clear()
            self._hits = 0
            self._misses = 0

    def size(self) -> int:
        """当前缓存条目数"""
        with self._lock:
            return len(self._data)

    def cleanup(self) -> int:
        """清理所有过期项

        Returns:
            清理的条目数
        """
        now = time.time()
        removed = 0
        with self._lock:
            expired_keys = [
                k for k, (_, exp) in self._data.items()
                if exp > 0 and now > exp
            ]
            for k in expired_keys:
                del self._data[k]
                removed += 1
        return removed

    def stats(self) -> dict[str, int]:
        """缓存统计"""
        with self._lock:
            return {
                "size": len(self._data),
                "max_size": self.max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": round(self._hits / max(self._hits + self._misses, 1) * 100, 1),
            }

    def cached(self, ttl: Optional[int] = None) -> Callable:
        """缓存装饰器

        用于缓存函数返回值，key 由函数名+参数自动生成。

        Args:
            ttl: 过期时间，None 使用默认 TTL

        Example:
            cache = Cache()

            @cache.cached(ttl=60)
            def fetch_data(url: str) -> str:
                ...
        """
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                # 生成缓存 key
                key = self._make_key(func.__qualname__, args, kwargs)
                result = self.get(key)
                if result is not None:
                    return result
                result = func(*args, **kwargs)
                self.set(key, result, ttl=ttl)
                return result
            return wrapper
        return decorator

    @staticmethod
    def _make_key(func_name: str, args: tuple, kwargs: dict) -> str:
        """根据函数名和参数生成缓存 key"""
        raw = json.dumps({"f": func_name, "a": repr(args), "k": repr(sorted(kwargs.items()))})
        return hashlib.md5(raw.encode()).hexdigest()
