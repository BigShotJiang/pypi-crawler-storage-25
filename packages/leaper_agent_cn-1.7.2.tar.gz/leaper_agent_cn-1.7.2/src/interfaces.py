"""
接口契约定义 — 所有模块间交互的 Protocol 定义

解决跨模块调用时"靠猜"的问题，让类型检查器和开发者都能明确知道接口签名。
Python 3.10 兼容。
"""

from __future__ import annotations

from typing import Any, AsyncGenerator, Literal, Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# Brain 协议
# ---------------------------------------------------------------------------

@runtime_checkable
class BrainProtocol(Protocol):
    """LeaperBrain 的公开接口契约"""

    agent_id: str
    db_path: str

    async def initialize(self) -> None: ...
    async def close(self) -> None: ...
    async def store_message(self, session_id: str, role: str, content: str) -> str: ...
    async def store_entry(
        self,
        entry_type: str,
        content: str,
        category: str = "",
        confidence: float = 0.8,
        source_ids: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str: ...
    async def get_entries(
        self,
        agent_id: str | None = None,
        entry_type: str | None = None,
        status: str = "active",
        limit: int = 50,
    ) -> list[dict]: ...
    async def recall(self, query: str, limit: int = 5) -> list[dict]: ...
    async def extract_knowledge(self, conversation: list[dict]) -> list[dict]: ...
    async def record_transition(
        self, old_entry: dict, new_entry: dict, transition_type: str = "update"
    ) -> str: ...


# ---------------------------------------------------------------------------
# Provider 协议
# ---------------------------------------------------------------------------

@runtime_checkable
class ProviderProtocol(Protocol):
    """LLM Provider 的公开接口契约

    注意：
    - messages 参数类型为 list[Message]（from providers.base）
    - tools 参数兼容 list[ToolFunction] 和 list[dict]（各 provider 内部已做适配）
    """

    async def chat(
        self,
        messages: list,
        tools: list | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> Any: ...

    async def chat_stream(
        self,
        messages: list,
        tools: list | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> AsyncGenerator: ...


# ---------------------------------------------------------------------------
# Session 协议
# ---------------------------------------------------------------------------

@runtime_checkable
class SessionProtocol(Protocol):
    """SessionManager 的公开接口契约"""

    async def ensure_tables(self) -> None: ...
    async def create_session(self, agent_id: str, user_id: str) -> str: ...
    async def get_or_create(self, agent_id: str, user_id: str) -> str: ...
    async def add_message(self, session_id: str, role: str, content: str) -> None: ...
    async def get_history(self, session_id: str, limit: int = 50) -> list[dict]: ...
    async def get_context_window(self, session_id: str, max_tokens: int = 8000) -> list[dict]: ...


# ---------------------------------------------------------------------------
# Skill 协议
# ---------------------------------------------------------------------------

@runtime_checkable
class SkillProtocol(Protocol):
    """Skill 的公开接口契约"""

    name: str
    description: str

    def to_tool_def(self) -> dict: ...
    async def execute(self, arguments: dict) -> str: ...


# ---------------------------------------------------------------------------
# SkillManager 协议
# ---------------------------------------------------------------------------

@runtime_checkable
class SkillManagerProtocol(Protocol):
    """SkillManager 的公开接口契约"""

    def get_all_skills(self) -> list: ...
    def to_tool_defs(self) -> list[dict]: ...
    async def execute_skill(self, name: str, arguments: dict) -> str: ...


# ---------------------------------------------------------------------------
# Scheduler 协议
# ---------------------------------------------------------------------------

@runtime_checkable
class SchedulerProtocol(Protocol):
    """Scheduler 的公开接口契约"""

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    def add_job(self, name: str, cron_expr: str, agent_id: str, payload: str) -> Any: ...
    def remove_job(self, job_id: str) -> bool: ...
    def list_jobs(self) -> list: ...
    def parse_natural_language(self, text: str) -> str | None: ...
