"""LLM Provider 抽象基类"""
from abc import ABC, abstractmethod
from typing import AsyncGenerator, Literal
from dataclasses import dataclass


@dataclass
class Message:
    role: Literal["system", "user", "assistant", "tool"]
    content: str | None = None
    tool_calls: list | None = None
    tool_call_id: str | None = None
    name: str | None = None


@dataclass
class ToolFunction:
    name: str
    description: str
    parameters: dict


@dataclass
class Usage:
    prompt_tokens: int
    completion_tokens: int


@dataclass
class Response:
    content: str | None
    tool_calls: list | None
    finish_reason: Literal["stop", "tool_calls", "length"]
    usage: Usage | None = None


@dataclass
class StreamChunk:
    type: Literal["token", "tool_call_start", "tool_call_delta", "tool_call_end", "done"]
    content: str | None = None
    tool_call: dict | None = None
    finish_reason: str | None = None


class LLMProvider(ABC):
    """LLM 提供商抽象基类，所有 provider 必须实现 chat 和 chat_stream"""

    @abstractmethod
    async def chat(
        self,
        messages: list[Message],
        tools: list[ToolFunction] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> Response: ...

    @abstractmethod
    async def chat_stream(
        self,
        messages: list[Message],
        tools: list[ToolFunction] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> AsyncGenerator[StreamChunk, None]: ...
