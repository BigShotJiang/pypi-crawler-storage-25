"""企业微信渠道适配 - XML 解析 + AES 解密 + access_token + 消息收发"""
import asyncio
import base64
import hashlib
import os
import struct
import time
import xml.etree.ElementTree as ET

import httpx
from aiohttp import web

from .base import Channel, IncomingMessage


def _get_aes():
    """延迟导入 AES 加密模块"""
    try:
        from Crypto.Cipher import AES
        return AES
    except ImportError:
        raise ImportError("企微消息加解密需要 pycryptodome: pip install pycryptodome")


class WeComChannel(Channel):
    """企业微信渠道

    config:
        corp_id: 企业 ID
        agent_id: 应用 AgentId
        secret: 应用 Secret
        token: 回调 Token
        encoding_aes_key: 回调 EncodingAESKey
    """

    TOKEN_URL = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
    SEND_MSG_URL = "https://qyapi.weixin.qq.com/cgi-bin/message/send"

    def __init__(self, config: dict):
        super().__init__(config)
        self.corp_id = config["corp_id"]
        self.agent_id = config["agent_id"]
        self.secret = config["secret"]
        self.token = config["token"]
        self.encoding_aes_key = config["encoding_aes_key"]
        # 解码 AES key（Base64 编码，43字符 → 32字节）
        self._aes_key = base64.b64decode(self.encoding_aes_key + "=")
        self._access_token: str = ""
        self._token_expires: float = 0
        # 消息去重
        self._processed_msgs: dict[str, float] = {}
        self._max_msg_cache = 1000

    @staticmethod
    def compute_signature(token: str, timestamp: str, nonce: str, echostr: str) -> str:
        """计算企微签名

        算法: SHA1(sort([token, timestamp, nonce, echostr]))
        """
        sort_list = sorted([token, timestamp, nonce, echostr])
        return hashlib.sha1("".join(sort_list).encode("utf-8")).hexdigest()

    def _verify_signature(self, msg_signature: str, timestamp: str, nonce: str, echostr: str) -> bool:
        """验证企微回调签名"""
        expected = self.compute_signature(self.token, timestamp, nonce, echostr)
        return msg_signature == expected

    def _decrypt(self, encrypted: str) -> str:
        """AES-CBC 解密消息"""
        AES = _get_aes()
        cipher = AES.new(self._aes_key, AES.MODE_CBC, self._aes_key[:16])
        decrypted = cipher.decrypt(base64.b64decode(encrypted))
        # 去除 PKCS7 padding
        pad = decrypted[-1]
        content = decrypted[:-pad]
        # 格式: 16字节随机数 + 4字节消息长度 + 消息内容 + corp_id
        msg_len = struct.unpack(">I", content[16:20])[0]
        msg = content[20:20 + msg_len].decode("utf-8")
        return msg

    def _encrypt(self, reply: str) -> str:
        """AES-CBC 加密消息"""
        AES = _get_aes()
        rand_bytes = os.urandom(16)
        msg_bytes = reply.encode("utf-8")
        corp_bytes = self.corp_id.encode("utf-8")
        msg_len = struct.pack(">I", len(msg_bytes))
        plaintext = rand_bytes + msg_len + msg_bytes + corp_bytes
        # PKCS7 padding
        pad_len = 32 - (len(plaintext) % 32)
        plaintext += bytes([pad_len] * pad_len)
        cipher = AES.new(self._aes_key, AES.MODE_CBC, self._aes_key[:16])
        encrypted = base64.b64encode(cipher.encrypt(plaintext)).decode()
        return encrypted

    def _is_duplicate(self, msg_id: str) -> bool:
        """消息去重"""
        if not msg_id:
            return False
        if msg_id in self._processed_msgs:
            return True
        now = time.time()
        if len(self._processed_msgs) >= self._max_msg_cache:
            expired = [k for k, v in self._processed_msgs.items() if now - v > 300]
            for k in expired:
                del self._processed_msgs[k]
        self._processed_msgs[msg_id] = now
        return False

    async def _get_access_token(self) -> str:
        """获取 access_token"""
        if self._access_token and time.time() < self._token_expires:
            return self._access_token
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                self.TOKEN_URL,
                params={"corpid": self.corp_id, "corpsecret": self.secret},
            )
            data = resp.json()
            self._access_token = data["access_token"]
            self._token_expires = time.time() + data.get("expires_in", 7200) - 300
        return self._access_token

    async def verify_url(self, params: dict) -> str:
        """URL 验证（用于企微后台配置回调时的验证请求）

        Args:
            params: 请求参数 {"msg_signature": ..., "timestamp": ..., "nonce": ..., "echostr": ...}

        Returns:
            解密后的 echostr（需要原样返回给企微）
        """
        msg_signature = params.get("msg_signature", "")
        timestamp = params.get("timestamp", "")
        nonce = params.get("nonce", "")
        echostr = params.get("echostr", "")

        if not self._verify_signature(msg_signature, timestamp, nonce, echostr):
            raise ValueError("签名验证失败")
        return self._decrypt(echostr)

    async def handle_webhook(self, request: web.Request) -> web.Response:
        """处理企微事件回调"""
        msg_signature = request.query.get("msg_signature", "")
        timestamp = request.query.get("timestamp", "")
        nonce = request.query.get("nonce", "")

        # GET 请求 = URL 验证
        if request.method == "GET":
            echostr = request.query.get("echostr", "")
            if self._verify_signature(msg_signature, timestamp, nonce, echostr):
                decrypted = self._decrypt(echostr)
                return web.Response(text=decrypted)
            return web.Response(status=403, text="invalid signature")

        # POST 请求 = 消息回调
        body = await request.text()
        xml_tree = ET.fromstring(body)
        encrypt_node = xml_tree.find("Encrypt")
        if encrypt_node is None:
            return web.Response(status=400, text="missing Encrypt node")

        encrypted = encrypt_node.text or ""
        # 验签（对密文进行签名验证）
        if not self._verify_signature(msg_signature, timestamp, nonce, encrypted):
            return web.Response(status=403, text="invalid signature")

        # 解密消息
        decrypted_xml = self._decrypt(encrypted)
        msg_tree = ET.fromstring(decrypted_xml)
        msg_type = msg_tree.findtext("MsgType", "")
        content = msg_tree.findtext("Content", "").strip()
        from_user = msg_tree.findtext("FromUserName", "")
        msg_id = msg_tree.findtext("MsgId", "")

        # 消息去重
        if self._is_duplicate(msg_id):
            return web.Response(text="success")

        if msg_type == "text" and content and self._handler:
            incoming = IncomingMessage(
                channel="wecom",
                user_id=from_user,
                content=content,
                raw={"xml": decrypted_xml},
            )
            asyncio.create_task(self._process_and_reply(incoming))

        return web.Response(text="success")

    async def _process_and_reply(self, incoming: IncomingMessage) -> None:
        """处理并回复"""
        if not self._handler:
            return
        reply = await self._handler(incoming)
        if reply:
            await self.send(incoming.user_id, reply)

    async def send(self, user_id: str, content: str) -> None:
        """发送文本消息"""
        token = await self._get_access_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                params={"access_token": token},
                json={
                    "touser": user_id,
                    "msgtype": "text",
                    "agentid": self.agent_id,
                    "text": {"content": content},
                },
            )

    async def send_markdown(self, user_id: str, content: str) -> None:
        """发送 Markdown 消息

        Args:
            user_id: 用户 ID（企微 userid）
            content: Markdown 格式文本
        """
        token = await self._get_access_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                params={"access_token": token},
                json={
                    "touser": user_id,
                    "msgtype": "markdown",
                    "agentid": self.agent_id,
                    "markdown": {"content": content},
                },
            )

    async def send_card(self, user_id: str, title: str, description: str,
                        url: str = "", btn_text: str = "详情") -> None:
        """发送文本卡片消息

        Args:
            user_id: 用户 ID
            title: 卡片标题
            description: 卡片描述（最多 512 字节）
            url: 点击跳转 URL
            btn_text: 按钮文案
        """
        token = await self._get_access_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                params={"access_token": token},
                json={
                    "touser": user_id,
                    "msgtype": "textcard",
                    "agentid": self.agent_id,
                    "textcard": {
                        "title": title,
                        "description": description,
                        "url": url,
                        "btntxt": btn_text,
                    },
                },
            )

    async def start(self) -> None:
        """启动"""
        await self._get_access_token()

    async def stop(self) -> None:
        """停止"""
        pass
