"""飞书渠道适配 - webhook 回调 + 签名验证 + 事件去重"""
import asyncio
import hashlib
import json
import time
from typing import Any

import httpx
from aiohttp import web

from .base import Channel, IncomingMessage


class FeishuChannel(Channel):
    """飞书开放平台渠道

    config:
        app_id: 飞书应用 app_id
        app_secret: 飞书应用 app_secret
        verification_token: 事件订阅验证 token
        encrypt_key: 事件加密密钥（可选，用于签名验证）
    """

    TENANT_TOKEN_URL = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    SEND_MSG_URL = "https://open.feishu.cn/open-apis/im/v1/messages"

    def __init__(self, config: dict):
        super().__init__(config)
        self.app_id = config["app_id"]
        self.app_secret = config["app_secret"]
        self.verification_token = config.get("verification_token", "")
        self.encrypt_key = config.get("encrypt_key", "")
        self._tenant_token: str = ""
        self._token_expires: float = 0
        # 事件去重：记录已处理的 event_id，最多保留 1000 条
        self._processed_events: dict[str, float] = {}
        self._max_event_cache = 1000

    def _verify_signature(self, timestamp: str, nonce: str, body: str) -> bool:
        """验证飞书事件回调签名（SHA256）

        签名算法：sha256(timestamp + nonce + encrypt_key + body)
        """
        if not self.encrypt_key:
            return True  # 未配置加密密钥时跳过签名验证（仅验证 token）
        content = timestamp + nonce + self.encrypt_key + body
        computed = hashlib.sha256(content.encode("utf-8")).hexdigest()
        return True  # 需要对比 header 中的签名，见 handle_webhook

    @staticmethod
    def compute_signature(timestamp: str, nonce: str, encrypt_key: str, body: str) -> str:
        """计算飞书事件签名，供外部调用和测试"""
        content = timestamp + nonce + encrypt_key + body
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def _is_duplicate(self, event_id: str) -> bool:
        """事件去重检查"""
        if not event_id:
            return False
        if event_id in self._processed_events:
            return True
        # 清理过期事件（超过 5 分钟）
        now = time.time()
        if len(self._processed_events) >= self._max_event_cache:
            expired = [k for k, v in self._processed_events.items() if now - v > 300]
            for k in expired:
                del self._processed_events[k]
        self._processed_events[event_id] = now
        return False

    async def _get_tenant_token(self) -> str:
        """获取 tenant_access_token，带缓存"""
        if self._tenant_token and time.time() < self._token_expires:
            return self._tenant_token
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                self.TENANT_TOKEN_URL,
                json={"app_id": self.app_id, "app_secret": self.app_secret},
            )
            data = resp.json()
            self._tenant_token = data["tenant_access_token"]
            self._token_expires = time.time() + data.get("expire", 7200) - 300
        return self._tenant_token

    async def handle_webhook(self, request: web.Request) -> web.Response:
        """处理飞书事件回调"""
        body_text = await request.text()
        body = json.loads(body_text)

        # URL 验证请求（challenge）
        if "challenge" in body:
            return web.json_response({"challenge": body["challenge"]})

        # 签名验证（当配置了 encrypt_key 时）
        if self.encrypt_key:
            timestamp = request.headers.get("X-Lark-Request-Timestamp", "")
            nonce = request.headers.get("X-Lark-Request-Nonce", "")
            signature = request.headers.get("X-Lark-Signature", "")
            expected = self.compute_signature(timestamp, nonce, self.encrypt_key, body_text)
            if signature != expected:
                return web.Response(status=403, text="invalid signature")

        # 验证 token
        header = body.get("header", {})
        if header.get("token") != self.verification_token:
            return web.Response(status=403, text="invalid token")

        # 事件去重
        event_id = header.get("event_id", "")
        if self._is_duplicate(event_id):
            return web.json_response({"code": 0, "msg": "duplicate event"})

        # 解析消息内容
        event = body.get("event", {})
        msg = event.get("message", {})
        if msg.get("message_type") == "text":
            content_json = json.loads(msg.get("content", "{}"))
            text = content_json.get("text", "")
            sender = event.get("sender", {}).get("sender_id", {})
            user_id = sender.get("open_id", "unknown")

            if self._handler:
                incoming = IncomingMessage(
                    channel="feishu",
                    user_id=user_id,
                    content=text,
                    raw=body,
                )
                asyncio.create_task(self._process_and_reply(incoming, msg.get("chat_id", "")))

        return web.json_response({"code": 0})

    async def _process_and_reply(self, incoming: IncomingMessage, chat_id: str) -> None:
        """处理消息并回复"""
        if not self._handler:
            return
        reply = await self._handler(incoming)
        if reply and chat_id:
            await self._send_to_chat(chat_id, reply)

    async def _send_to_chat(self, chat_id: str, content: str) -> None:
        """发送消息到群聊"""
        token = await self._get_tenant_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                params={"receive_id_type": "chat_id"},
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "receive_id": chat_id,
                    "msg_type": "text",
                    "content": json.dumps({"text": content}),
                },
            )

    async def send(self, user_id: str, content: str) -> None:
        """发送消息给用户（通过 open_id）"""
        token = await self._get_tenant_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                params={"receive_id_type": "open_id"},
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "receive_id": user_id,
                    "msg_type": "text",
                    "content": json.dumps({"text": content}),
                },
            )

    async def send_card(self, chat_id: str, card: dict) -> None:
        """发送互动卡片到群聊

        Args:
            chat_id: 群聊 ID
            card: 飞书卡片 JSON（interactive 格式）
        """
        token = await self._get_tenant_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                params={"receive_id_type": "chat_id"},
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "receive_id": chat_id,
                    "msg_type": "interactive",
                    "content": json.dumps(card),
                },
            )

    async def send_post(self, chat_id: str, title: str, content_lines: list[list[dict]]) -> None:
        """发送富文本消息（post 格式）

        Args:
            chat_id: 群聊 ID
            title: 消息标题
            content_lines: 富文本内容行，每行是 tag 数组
                例: [[{"tag": "text", "text": "内容"}], [{"tag": "a", "href": "url", "text": "链接"}]]
        """
        token = await self._get_tenant_token()
        post_content = {
            "zh_cn": {
                "title": title,
                "content": content_lines,
            }
        }
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                params={"receive_id_type": "chat_id"},
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "receive_id": chat_id,
                    "msg_type": "post",
                    "content": json.dumps(post_content),
                },
            )

    async def start(self) -> None:
        """启动"""
        await self._get_tenant_token()

    async def stop(self) -> None:
        """停止"""
        pass
