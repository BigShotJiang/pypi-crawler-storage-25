"""QQ 开放平台机器人渠道 — HTTP 回调模式

功能：
- HTTP 回调接收消息/事件
- Ed25519 签名验证
- 消息发送（文本/Markdown）
- 事件分发（消息/指令/成员变动）
- 频道/群消息处理

QQ Bot 开放平台文档: https://bot.q.qq.com/wiki/
"""
import hashlib
import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, Awaitable, Dict, List, Optional

import httpx
from aiohttp import web

from .base import Channel, IncomingMessage

logger = logging.getLogger(__name__)

# ─── 常量 ─────────────────────────────────────────────
QQ_API_BASE = "https://api.sgroup.qq.com"
QQ_SANDBOX_API_BASE = "https://sandbox.api.sgroup.qq.com"

# 事件类型
OPCODE_DISPATCH = 0
OPCODE_HEARTBEAT = 1
OPCODE_IDENTIFY = 2
OPCODE_RESUME = 6
OPCODE_RECONNECT = 7
OPCODE_HELLO = 10
OPCODE_HEARTBEAT_ACK = 11
OPCODE_HTTP_CALLBACK_ACK = 12

# 事件名称
EVENT_C2C_MESSAGE = "C2C_MESSAGE_CREATE"
EVENT_GROUP_AT_MESSAGE = "GROUP_AT_MESSAGE_CREATE"
EVENT_CHANNEL_MESSAGE = "AT_MESSAGE_CREATE"
EVENT_DIRECT_MESSAGE = "DIRECT_MESSAGE_CREATE"
EVENT_INTERACTION = "INTERACTION_CREATE"
EVENT_MEMBER_ADD = "GROUP_ADD_ROBOT"
EVENT_MEMBER_REMOVE = "GROUP_DEL_ROBOT"


@dataclass
class QQBotMessage:
    """解析后的 QQ Bot 消息"""
    msg_id: str = ""
    msg_type: str = ""
    content: str = ""
    author_id: str = ""
    channel_id: str = ""
    group_id: str = ""
    group_openid: str = ""
    user_openid: str = ""
    timestamp: str = ""
    event_type: str = ""
    raw: Optional[dict] = None


def parse_qq_event(payload: dict) -> QQBotMessage:
    """解析 QQ Bot 回调事件 → QQBotMessage"""
    msg = QQBotMessage(raw=payload)
    d = payload.get("d", {})
    msg.event_type = payload.get("t", "")
    msg.msg_id = d.get("id", "")
    msg.content = d.get("content", "").strip()
    msg.timestamp = d.get("timestamp", "")

    # 作者信息
    author = d.get("author", {})
    msg.author_id = author.get("id", "") or author.get("member_openid", "")

    # 群/频道信息
    msg.channel_id = d.get("channel_id", "")
    msg.group_id = d.get("group_id", "")
    msg.group_openid = d.get("group_openid", "")
    msg.user_openid = d.get("author", {}).get("user_openid", "") or d.get("user_openid", "")

    return msg


class QQBotChannel(Channel):
    """QQ 开放平台机器人渠道（HTTP 回调模式）

    config:
        app_id: str        — 机器人 AppID
        app_secret: str    — 机器人密钥
        token: str         — 回调验证 Token（可选）
        sandbox: bool      — 是否使用沙箱环境（默认 False）
        secret: str        — Ed25519 签名密钥（可选）
    """

    def __init__(self, config: dict):
        super().__init__(config)
        self.app_id: str = config["app_id"]
        self.app_secret: str = config["app_secret"]
        self.bot_token: str = config.get("token", "")
        self.sandbox: bool = config.get("sandbox", False)
        self.secret: str = config.get("secret", "")

        self._api_base = QQ_SANDBOX_API_BASE if self.sandbox else QQ_API_BASE
        self._access_token: str = ""
        self._token_expires: float = 0

        # 事件处理器
        self._event_handlers: Dict[str, Callable] = {}

        # 统计
        self._stats = {"received": 0, "sent": 0, "errors": 0}

    # ─── Access Token ──────────────────────────────────
    async def get_access_token(self) -> str:
        """获取 QQ Bot access_token"""
        if self._access_token and time.time() < self._token_expires:
            return self._access_token

        url = f"{QQ_API_BASE}/app/getAppAccessToken"
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(url, json={
                "appId": self.app_id,
                "clientSecret": self.app_secret,
            })
            data = resp.json()

        if "access_token" not in data:
            raise RuntimeError(f"获取 QQ access_token 失败: {data}")

        self._access_token = data["access_token"]
        expires_in = int(data.get("expires_in", 7200))
        self._token_expires = time.time() + expires_in - 300
        logger.info("QQ Bot access_token 已刷新")
        return self._access_token

    def _auth_headers(self, token: str) -> dict:
        """构造认证 headers"""
        return {
            "Authorization": f"QQBot {token}",
            "Content-Type": "application/json",
        }

    # ─── 签名验证 ──────────────────────────────────────
    def verify_signature(self, payload: bytes, signature: str,
                         timestamp: str) -> bool:
        """Ed25519 签名验证（简化版：HMAC-SHA256）

        QQ Bot 平台使用 Ed25519 或简单签名，
        这里实现 seed + timestamp + body 的 HMAC 验证。
        """
        if not self.secret:
            return True  # 未配置密钥，跳过验证

        # QQ Bot 使用 bot_secret 做签名
        msg = timestamp.encode("utf-8") + payload
        expected = hashlib.sha256(self.secret.encode("utf-8") + msg).hexdigest()
        return expected == signature

    # ─── HTTP 回调处理 ────────────────────────────────
    async def handle_webhook(self, request: web.Request) -> web.Response:
        """处理 QQ Bot HTTP 回调"""
        body = await request.read()
        text = body.decode("utf-8")

        # 签名验证
        signature = request.headers.get("X-Signature-Ed25519", "")
        timestamp = request.headers.get("X-Signature-Timestamp", "")
        if self.secret and not self.verify_signature(body, signature, timestamp):
            return web.Response(status=401, text="Invalid signature")

        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return web.Response(status=400, text="Invalid JSON")

        op = payload.get("op")

        # URL 验证（op=13）
        if op == 13:
            d = payload.get("d", {})
            plain_token = d.get("plain_token", "")
            # 简单回显
            return web.json_response({
                "plain_token": plain_token,
                "signature": "",  # 实际需要 Ed25519 签名
            })

        # 事件分发（op=0）
        if op == OPCODE_DISPATCH:
            self._stats["received"] += 1
            event_type = payload.get("t", "")
            msg = parse_qq_event(payload)

            # 分发到事件处理器
            if event_type in self._event_handlers:
                try:
                    await self._event_handlers[event_type](msg)
                except Exception as e:
                    logger.error("QQ 事件处理失败 [%s]: %s", event_type, e)
                    self._stats["errors"] += 1

            # 消息类型自动回复
            if event_type in (EVENT_C2C_MESSAGE, EVENT_GROUP_AT_MESSAGE,
                              EVENT_CHANNEL_MESSAGE, EVENT_DIRECT_MESSAGE):
                await self._handle_message(msg)

        return web.json_response({"op": OPCODE_HTTP_CALLBACK_ACK})

    async def _handle_message(self, msg: QQBotMessage) -> None:
        """处理消息事件"""
        if not self._handler or not msg.content:
            return

        # 去掉 @ 机器人的文本
        content = msg.content
        if content.startswith(f"<@!{self.app_id}>"):
            content = content[len(f"<@!{self.app_id}>"):].strip()

        user_id = msg.user_openid or msg.author_id
        incoming = IncomingMessage(
            channel="qqbot",
            user_id=user_id,
            content=content,
            raw=msg.raw,
        )

        try:
            reply = await self._handler(incoming)
            if reply:
                # 根据来源类型回复
                if msg.group_openid:
                    await self.send_group_message(msg.group_openid, reply, msg.msg_id)
                elif msg.channel_id:
                    await self.send_channel_message(msg.channel_id, reply, msg.msg_id)
                elif msg.user_openid:
                    await self.send_c2c_message(msg.user_openid, reply, msg.msg_id)
        except Exception as e:
            logger.error("QQ 消息处理失败: %s", e)
            self._stats["errors"] += 1

    # ─── 消息发送 ──────────────────────────────────────
    async def send_message(self, channel_id: str, content: str,
                           msg_id: str = "") -> dict:
        """发送频道消息"""
        return await self.send_channel_message(channel_id, content, msg_id)

    async def send_channel_message(self, channel_id: str, content: str,
                                   msg_id: str = "") -> dict:
        """发送频道消息

        Args:
            channel_id: 子频道 ID
            content: 消息内容
            msg_id: 回复的消息 ID（被动回复时必填）
        """
        token = await self.get_access_token()
        url = f"{self._api_base}/channels/{channel_id}/messages"
        payload: Dict[str, Any] = {"content": content}
        if msg_id:
            payload["msg_id"] = msg_id

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(url, headers=self._auth_headers(token),
                                     json=payload)
            self._stats["sent"] += 1
            return resp.json()

    async def send_group_message(self, group_openid: str, content: str,
                                 msg_id: str = "") -> dict:
        """发送群消息

        Args:
            group_openid: 群 OpenID
            content: 消息内容
            msg_id: 回复的消息 ID
        """
        token = await self.get_access_token()
        url = f"{self._api_base}/v2/groups/{group_openid}/messages"
        payload: Dict[str, Any] = {"content": content, "msg_type": 0}
        if msg_id:
            payload["msg_id"] = msg_id

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(url, headers=self._auth_headers(token),
                                     json=payload)
            self._stats["sent"] += 1
            return resp.json()

    async def send_c2c_message(self, user_openid: str, content: str,
                               msg_id: str = "") -> dict:
        """发送单聊消息

        Args:
            user_openid: 用户 OpenID
            content: 消息内容
            msg_id: 回复的消息 ID
        """
        token = await self.get_access_token()
        url = f"{self._api_base}/v2/users/{user_openid}/messages"
        payload: Dict[str, Any] = {"content": content, "msg_type": 0}
        if msg_id:
            payload["msg_id"] = msg_id

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(url, headers=self._auth_headers(token),
                                     json=payload)
            self._stats["sent"] += 1
            return resp.json()

    async def send_markdown(self, channel_id: str, content: str,
                            msg_id: str = "") -> dict:
        """发送 Markdown 消息（频道）

        Args:
            channel_id: 子频道 ID
            content: Markdown 内容
            msg_id: 回复的消息 ID
        """
        token = await self.get_access_token()
        url = f"{self._api_base}/channels/{channel_id}/messages"
        payload: Dict[str, Any] = {
            "markdown": {"content": content},
        }
        if msg_id:
            payload["msg_id"] = msg_id

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(url, headers=self._auth_headers(token),
                                     json=payload)
            self._stats["sent"] += 1
            return resp.json()

    # ─── 事件注册 ──────────────────────────────────────
    def on_event(self, event_type: str,
                 handler: Callable[[QQBotMessage], Awaitable[None]]) -> None:
        """注册事件处理器"""
        self._event_handlers[event_type] = handler

    # ─── Channel 接口实现 ──────────────────────────────
    async def start(self, config: Optional[dict] = None) -> None:
        """启动渠道"""
        if config:
            self.config.update(config)
        try:
            await self.get_access_token()
            logger.info("QQ Bot 渠道启动成功: app_id=%s", self.app_id)
        except Exception as e:
            logger.warning("QQ Bot 启动时获取 token 失败: %s", e)

    async def send(self, user_id: str, content: str) -> None:
        """发送消息（默认 C2C）"""
        await self.send_c2c_message(user_id, content)

    async def stop(self) -> None:
        """停止渠道"""
        logger.info("QQ Bot 渠道已停止")

    def get_stats(self) -> dict:
        """获取统计信息"""
        return dict(self._stats)
