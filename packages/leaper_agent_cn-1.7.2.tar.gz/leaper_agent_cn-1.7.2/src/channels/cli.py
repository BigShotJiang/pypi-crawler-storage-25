"""CLI 交互渠道 - 终端输入输出，支持 /quit 退出"""
import asyncio
import sys

from .base import Channel, IncomingMessage


class CLIChannel(Channel):
    """命令行交互渠道，用于本地调试"""

    def __init__(self, config: dict | None = None):
        super().__init__(config or {})
        self._running = False

    async def start(self) -> None:
        """启动 CLI 输入循环"""
        self._running = True
        print("🤖 Leaper Agent CLI (输入 /quit 退出)")
        print("-" * 40)

        loop = asyncio.get_event_loop()
        while self._running:
            try:
                # 异步读取 stdin
                line = await loop.run_in_executor(None, sys.stdin.readline)
                if not line:
                    break
                text = line.strip()
                if not text:
                    continue
                if text == "/quit":
                    print("👋 再见！")
                    self._running = False
                    break

                # 调用消息处理器
                if self._handler:
                    msg = IncomingMessage(
                        channel="cli",
                        user_id="local",
                        content=text,
                    )
                    reply = await self._handler(msg)
                    if reply:
                        print(f"\n🤖 {reply}\n")
            except (EOFError, KeyboardInterrupt):
                self._running = False
                break

    async def send(self, user_id: str, content: str) -> None:
        """输出到终端"""
        print(f"\n🤖 {content}\n")

    async def stop(self) -> None:
        """停止 CLI"""
        self._running = False
