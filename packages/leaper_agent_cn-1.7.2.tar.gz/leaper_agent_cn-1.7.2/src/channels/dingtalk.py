"""钉钉渠道适配 - webhook 回调 + 签名验证 + 消息收发"""
import hashlib
import hmac
import base64
import time
import json
from typing import Any

import httpx
from aiohttp import web

from .base import Channel, IncomingMessage


class DingTalkChannel(Channel):
    """钉钉机器人渠道

    config:
        app_key: 钉钉 AppKey
        app_secret: 钉钉 AppSecret
        robot_code: 机器人编码
    """

    SEND_MSG_URL = "https://api.dingtalk.com/v1.0/robot/oToMessages/batchSend"
    TOKEN_URL = "https://api.dingtalk.com/v1.0/oauth2/accessToken"

    def __init__(self, config: dict):
        super().__init__(config)
        self.app_key = config["app_key"]
        self.app_secret = config["app_secret"]
        self.robot_code = config.get("robot_code", "")
        self._access_token: str = ""
        self._token_expires: float = 0
        # 消息去重
        self._processed_msgs: dict[str, float] = {}
        self._max_msg_cache = 1000

    @staticmethod
    def compute_signature(timestamp: str, secret: str) -> str:
        """计算签名

        算法: Base64(HMAC-SHA256(timestamp + '\\n' + secret, secret))
        """
        string_to_sign = f"{timestamp}\n{secret}"
        hmac_code = hmac.new(
            secret.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha256
        ).digest()
        return base64.b64encode(hmac_code).decode("utf-8")

    def _verify_signature(self, timestamp: str, sign: str) -> bool:
        """验证回调签名

        检查项:
        1. 签名是否正确
        2. 时间戳是否在 1 小时内（防止重放攻击）
        """
        try:
            ts = int(timestamp)
            now = int(time.time() * 1000)
            if abs(now - ts) > 3600000:  # 1小时
                return False
        except (ValueError, TypeError):
            return False

        expected = self.compute_signature(timestamp, self.app_secret)
        return hmac.compare_digest(sign, expected)

    def _is_duplicate(self, msg_id: str) -> bool:
        """消息去重"""
        if not msg_id:
            return False
        if msg_id in self._processed_msgs:
            return True
        now = time.time()
        if len(self._processed_msgs) >= self._max_msg_cache:
            expired = [k for k, v in self._processed_msgs.items() if now - v > 300]
            for k in expired:
                del self._processed_msgs[k]
        self._processed_msgs[msg_id] = now
        return False

    async def _get_access_token(self) -> str:
        """获取钉钉内部应用 access_token"""
        if self._access_token and time.time() < self._token_expires:
            return self._access_token
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                self.TOKEN_URL,
                json={"appKey": self.app_key, "appSecret": self.app_secret},
            )
            data = resp.json()
            self._access_token = data["accessToken"]
            self._token_expires = time.time() + data.get("expireIn", 7200) - 300
        return self._access_token

    async def handle_webhook(self, request: web.Request) -> web.Response:
        """处理钉钉事件回调"""
        # 签名验证（如果配置了密钥，必须验证）
        timestamp = request.headers.get("timestamp", "")
        sign = request.headers.get("sign", "")
        if not timestamp or not sign:
            return web.Response(status=403, text="missing signature")
        if not self._verify_signature(timestamp, sign):
            return web.Response(status=403, text="invalid signature")

        body = await request.json()

        # 消息去重
        msg_id = body.get("msgId", "")
        if self._is_duplicate(msg_id):
            return web.json_response({"msgtype": "empty"})

        # 提取消息内容
        text = body.get("text", {}).get("content", "").strip()
        sender_id = body.get("senderStaffId") or body.get("senderId", "unknown")
        conversation_id = body.get("conversationId", "")

        if text and self._handler:
            incoming = IncomingMessage(
                channel="dingtalk",
                user_id=sender_id,
                content=text,
                raw=body,
            )
            reply = await self._handler(incoming)
            if reply:
                return web.json_response({
                    "msgtype": "text",
                    "text": {"content": reply},
                })

        return web.json_response({"msgtype": "empty"})

    async def send(self, user_id: str, content: str) -> None:
        """发送单聊消息给用户"""
        token = await self._get_access_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.SEND_MSG_URL,
                headers={"x-acs-dingtalk-access-token": token},
                json={
                    "robotCode": self.robot_code,
                    "userIds": [user_id],
                    "msgKey": "sampleText",
                    "msgParam": json.dumps({"content": content}),
                },
            )

    async def send_markdown(self, webhook_url: str, title: str, text: str) -> None:
        """通过 webhook 发送 markdown 消息到群

        Args:
            webhook_url: 钉钉群自定义机器人 webhook URL
            title: 消息标题（会话列表显示）
            text: Markdown 正文
        """
        async with httpx.AsyncClient() as client:
            await client.post(
                webhook_url,
                json={
                    "msgtype": "markdown",
                    "markdown": {
                        "title": title,
                        "text": text,
                    },
                },
            )

    async def send_action_card(self, webhook_url: str, title: str, text: str,
                                btn_title: str = "", btn_url: str = "") -> None:
        """通过 webhook 发送 ActionCard 消息

        Args:
            webhook_url: 群 webhook URL
            title: 卡片标题
            text: Markdown 正文
            btn_title: 按钮文本
            btn_url: 按钮链接
        """
        card: dict[str, Any] = {
            "msgtype": "actionCard",
            "actionCard": {
                "title": title,
                "text": text,
                "btnOrientation": "0",
            },
        }
        if btn_title and btn_url:
            card["actionCard"]["singleTitle"] = btn_title
            card["actionCard"]["singleURL"] = btn_url
        async with httpx.AsyncClient() as client:
            await client.post(webhook_url, json=card)

    async def start(self) -> None:
        """启动"""
        await self._get_access_token()

    async def stop(self) -> None:
        """停止"""
        pass
