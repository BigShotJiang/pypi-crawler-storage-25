"""邮件渠道 — 通过 IMAP/SMTP 收发邮件，支持国内主流邮箱"""
from __future__ import annotations

import asyncio
import email
import email.mime.text
import email.mime.multipart
import email.header
import email.utils
import imaplib
import logging
import smtplib
import time
from dataclasses import dataclass, field
from typing import Callable, Awaitable, List, Optional

from .base import Channel, IncomingMessage

logger = logging.getLogger(__name__)


# 国内主流邮箱预设配置
PRESET_PROVIDERS = {
    "qq": {
        "imap_host": "imap.qq.com",
        "imap_port": 993,
        "smtp_host": "smtp.qq.com",
        "smtp_port": 465,
        "smtp_ssl": True,
    },
    "163": {
        "imap_host": "imap.163.com",
        "imap_port": 993,
        "smtp_host": "smtp.163.com",
        "smtp_port": 465,
        "smtp_ssl": True,
    },
    "126": {
        "imap_host": "imap.126.com",
        "imap_port": 993,
        "smtp_host": "smtp.126.com",
        "smtp_port": 465,
        "smtp_ssl": True,
    },
    "wecom": {
        "imap_host": "imap.exmail.qq.com",
        "imap_port": 993,
        "smtp_host": "smtp.exmail.qq.com",
        "smtp_port": 465,
        "smtp_ssl": True,
    },
    "outlook": {
        "imap_host": "outlook.office365.com",
        "imap_port": 993,
        "smtp_host": "smtp.office365.com",
        "smtp_port": 587,
        "smtp_ssl": False,
        "smtp_starttls": True,
    },
}


@dataclass
class EmailMessage:
    """解析后的邮件消息"""
    message_id: str
    from_addr: str
    to_addr: str
    subject: str
    body: str
    date: str = ""
    reply_to: str = ""
    raw_headers: dict = field(default_factory=dict)


def _decode_header(value: str) -> str:
    """解码邮件头（处理 =?UTF-8?B?...?= 等编码）"""
    if not value:
        return ""
    decoded_parts = email.header.decode_header(value)
    result = []
    for part, charset in decoded_parts:
        if isinstance(part, bytes):
            result.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            result.append(part)
    return "".join(result)


def _extract_body(msg: email.message.Message) -> str:
    """从邮件对象中提取正文"""
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            if content_type == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")
        # fallback: 取第一个 text/html
        for part in msg.walk():
            if part.get_content_type() == "text/html":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")
    return ""


def _parse_email(raw_bytes: bytes) -> EmailMessage:
    """解析原始邮件字节为 EmailMessage"""
    msg = email.message_from_bytes(raw_bytes)
    return EmailMessage(
        message_id=msg.get("Message-ID", ""),
        from_addr=_decode_header(msg.get("From", "")),
        to_addr=_decode_header(msg.get("To", "")),
        subject=_decode_header(msg.get("Subject", "")),
        body=_extract_body(msg),
        date=msg.get("Date", ""),
        reply_to=msg.get("Reply-To", msg.get("From", "")),
    )


class EmailChannel(Channel):
    """邮件渠道 — IMAP 收件 + SMTP 发件

    配置示例：
        {
            "provider": "qq",          # 或 163/126/wecom，或自定义
            "email": "bot@qq.com",
            "password": "授权码",
            "imap_host": "...",        # provider 预设时可省略
            "smtp_host": "...",
            "poll_interval": 30,       # 轮询间隔（秒）
            "folder": "INBOX",
            "mark_read": true,
        }
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        # 合并预设配置
        provider = config.get("provider", "")
        if provider in PRESET_PROVIDERS:
            merged = {**PRESET_PROVIDERS[provider], **config}
        else:
            merged = config
        self._email = merged.get("email", "")
        self._password = merged.get("password", "")
        self._imap_host = merged.get("imap_host", "")
        self._imap_port = merged.get("imap_port", 993)
        self._smtp_host = merged.get("smtp_host", "")
        self._smtp_port = merged.get("smtp_port", 465)
        self._smtp_ssl = merged.get("smtp_ssl", True)
        self._smtp_starttls = merged.get("smtp_starttls", False)
        self._poll_interval = merged.get("poll_interval", 30)
        self._folder = merged.get("folder", "INBOX")
        self._mark_read = merged.get("mark_read", True)
        self._running = False
        self._poll_task: Optional[asyncio.Task] = None
        self._seen_ids: set = set()

    async def start(self) -> None:
        """启动邮件轮询"""
        self._running = True
        self._poll_task = asyncio.create_task(self.poll_loop())
        logger.info("邮件渠道启动: %s, 轮询间隔 %ds", self._email, self._poll_interval)

    async def stop(self) -> None:
        """停止邮件轮询"""
        self._running = False
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        logger.info("邮件渠道已停止")

    async def send(self, user_id: str, content: str) -> None:
        """发送邮件回复

        Args:
            user_id: 收件人邮箱地址
            content: 邮件正文
        """
        await self.send_reply(to=user_id, subject="Re: 来自 AI 助手", body=content)

    async def check_inbox(self) -> List[EmailMessage]:
        """检查收件箱，返回未读邮件列表"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._check_inbox_sync)

    def _check_inbox_sync(self) -> List[EmailMessage]:
        """同步检查收件箱（在线程池中执行）"""
        messages: List[EmailMessage] = []
        try:
            imap = imaplib.IMAP4_SSL(self._imap_host, self._imap_port)
            imap.login(self._email, self._password)
            imap.select(self._folder)

            # 搜索未读邮件
            status, data = imap.search(None, "UNSEEN")
            if status != "OK":
                return messages

            msg_ids = data[0].split() if data[0] else []
            for mid in msg_ids[-20:]:  # 最多处理 20 封
                status, msg_data = imap.fetch(mid, "(RFC822)")
                if status != "OK" or not msg_data[0]:
                    continue
                raw = msg_data[0][1] if isinstance(msg_data[0], tuple) else b""
                if not raw:
                    continue
                parsed = _parse_email(raw)
                # 去重
                if parsed.message_id in self._seen_ids:
                    continue
                self._seen_ids.add(parsed.message_id)
                messages.append(parsed)

                # 标记已读
                if self._mark_read:
                    imap.store(mid, "+FLAGS", "\\Seen")

            imap.close()
            imap.logout()
        except Exception as e:
            logger.error("检查收件箱失败: %s", e)
        return messages

    async def send_reply(
        self,
        to: str,
        subject: str,
        body: str,
        reply_to: Optional[str] = None,
    ) -> None:
        """发送邮件

        Args:
            to: 收件人
            subject: 主题
            body: 正文
            reply_to: 回复的 Message-ID
        """
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None, self._send_reply_sync, to, subject, body, reply_to
        )

    def _send_reply_sync(
        self, to: str, subject: str, body: str, reply_to: Optional[str]
    ) -> None:
        """同步发送邮件"""
        msg = email.mime.text.MIMEText(body, "plain", "utf-8")
        msg["From"] = self._email
        msg["To"] = to
        msg["Subject"] = subject
        if reply_to:
            msg["In-Reply-To"] = reply_to
            msg["References"] = reply_to
        msg["Date"] = email.utils.formatdate(localtime=True)

        try:
            if self._smtp_ssl:
                smtp = smtplib.SMTP_SSL(self._smtp_host, self._smtp_port)
            else:
                smtp = smtplib.SMTP(self._smtp_host, self._smtp_port)
                if self._smtp_starttls:
                    smtp.starttls()
            smtp.login(self._email, self._password)
            smtp.send_message(msg)
            smtp.quit()
            logger.info("邮件已发送: %s -> %s", self._email, to)
        except Exception as e:
            logger.error("发送邮件失败: %s", e)
            raise

    async def poll_loop(self, interval: Optional[int] = None) -> None:
        """轮询收件箱

        Args:
            interval: 轮询间隔（秒），默认使用配置值
        """
        poll_interval = interval or self._poll_interval
        while self._running:
            try:
                messages = await self.check_inbox()
                for msg in messages:
                    if self._handler:
                        incoming = IncomingMessage(
                            channel="email",
                            user_id=msg.from_addr,
                            content=f"[{msg.subject}] {msg.body}",
                            raw={
                                "message_id": msg.message_id,
                                "from": msg.from_addr,
                                "subject": msg.subject,
                                "body": msg.body,
                            },
                        )
                        reply = await self._handler(incoming)
                        if reply:
                            await self.send_reply(
                                to=msg.from_addr,
                                subject=f"Re: {msg.subject}",
                                body=reply,
                                reply_to=msg.message_id,
                            )
            except Exception as e:
                logger.error("邮件轮询异常: %s", e)
            await asyncio.sleep(poll_interval)
