"""短信渠道 — 支持阿里云短信和腾讯云短信（webhook + HTTP API）"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import time
import urllib.parse
import urllib.request
import uuid
import base64
from typing import Any, Dict, List, Optional

from .base import Channel, IncomingMessage

logger = logging.getLogger(__name__)


class SMSChannel(Channel):
    """短信渠道 — webhook 接收 + API 发送

    配置示例：
        {
            "provider": "aliyun",       # aliyun 或 tencent
            "access_key": "...",
            "access_secret": "...",
            "sign_name": "跃盟科技",
            "template_code": "SMS_123456",
            # 腾讯云额外字段
            "sdk_app_id": "1400...",
        }
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._provider = config.get("provider", "aliyun")
        self._access_key = config.get("access_key", "")
        self._access_secret = config.get("access_secret", "")
        self._sign_name = config.get("sign_name", "")
        self._template_code = config.get("template_code", "")
        self._sdk_app_id = config.get("sdk_app_id", "")  # 腾讯云
        self._running = False

    async def start(self) -> None:
        """启动短信渠道（等待 webhook 回调）"""
        self._running = True
        logger.info("短信渠道启动: provider=%s", self._provider)

    async def stop(self) -> None:
        """停止短信渠道"""
        self._running = False
        logger.info("短信渠道已停止")

    async def send(self, user_id: str, content: str) -> None:
        """发送短信

        Args:
            user_id: 手机号
            content: 短信内容（将作为模板参数）
        """
        await self.send_sms(user_id, content)

    async def handle_webhook(self, body: dict) -> Optional[str]:
        """处理短信 webhook 回调（上行短信）

        Args:
            body: webhook 请求体

        Returns:
            AI 回复内容，或 None
        """
        # 解析不同平台的 webhook 格式
        if self._provider == "aliyun":
            phone = body.get("phone_number", body.get("phone", ""))
            content = body.get("content", "")
        elif self._provider == "tencent":
            phone = body.get("mobile", body.get("phone", ""))
            content = body.get("text", body.get("content", ""))
        else:
            phone = body.get("phone", "")
            content = body.get("content", "")

        if not phone or not content:
            logger.warning("短信 webhook 数据不完整: %s", body)
            return None

        if self._handler:
            incoming = IncomingMessage(
                channel="sms",
                user_id=phone,
                content=content,
                raw=body,
            )
            reply = await self._handler(incoming)
            if reply:
                await self.send_sms(phone, reply)
            return reply
        return None

    async def send_sms(self, phone: str, content: str) -> dict:
        """发送短信

        Args:
            phone: 手机号
            content: 短信内容

        Returns:
            API 返回结果
        """
        if self._provider == "aliyun":
            return await self._send_aliyun(phone, content)
        elif self._provider == "tencent":
            return await self._send_tencent(phone, content)
        else:
            raise ValueError(f"不支持的短信服务商: {self._provider}")

    async def _send_aliyun(self, phone: str, content: str) -> dict:
        """阿里云短信 API"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._send_aliyun_sync, phone, content)

    def _send_aliyun_sync(self, phone: str, content: str) -> dict:
        """阿里云短信同步发送"""
        timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        nonce = uuid.uuid4().hex

        params = {
            "AccessKeyId": self._access_key,
            "Action": "SendSms",
            "Format": "JSON",
            "PhoneNumbers": phone,
            "RegionId": "cn-hangzhou",
            "SignName": self._sign_name,
            "SignatureMethod": "HMAC-SHA1",
            "SignatureNonce": nonce,
            "SignatureVersion": "1.0",
            "TemplateCode": self._template_code,
            "TemplateParam": json.dumps({"content": content}, ensure_ascii=False),
            "Timestamp": timestamp,
            "Version": "2017-05-25",
        }

        # 构造签名
        sorted_params = sorted(params.items())
        query_string = urllib.parse.urlencode(sorted_params, quote_via=urllib.parse.quote)
        string_to_sign = f"GET&{urllib.parse.quote('/', safe='')}&{urllib.parse.quote(query_string, safe='')}"
        sign_key = (self._access_secret + "&").encode("utf-8")
        signature = base64.b64encode(
            hmac.new(sign_key, string_to_sign.encode("utf-8"), hashlib.sha1).digest()
        ).decode()
        params["Signature"] = signature

        url = "https://dysmsapi.aliyuncs.com/?" + urllib.parse.urlencode(params)
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read().decode())
                logger.info("阿里云短信发送结果: %s", result.get("Code", "Unknown"))
                return result
        except Exception as e:
            logger.error("阿里云短信发送失败: %s", e)
            return {"Code": "Error", "Message": str(e)}

    async def _send_tencent(self, phone: str, content: str) -> dict:
        """腾讯云短信 API"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._send_tencent_sync, phone, content)

    def _send_tencent_sync(self, phone: str, content: str) -> dict:
        """腾讯云短信同步发送（TC3-HMAC-SHA256 签名）"""
        timestamp = int(time.time())
        date = time.strftime("%Y-%m-%d", time.gmtime(timestamp))
        service = "sms"
        host = "sms.tencentcloudapi.com"

        # 请求体
        payload = json.dumps({
            "SmsSdkAppId": self._sdk_app_id,
            "SignName": self._sign_name,
            "TemplateId": self._template_code,
            "TemplateParamSet": [content],
            "PhoneNumberSet": [f"+86{phone}" if not phone.startswith("+") else phone],
        })

        # TC3 签名
        hashed_payload = hashlib.sha256(payload.encode()).hexdigest()
        http_request = f"POST\n/\n\ncontent-type:application/json\nhost:{host}\n\ncontent-type;host\n{hashed_payload}"
        credential_scope = f"{date}/{service}/tc3_request"
        string_to_sign = f"TC3-HMAC-SHA256\n{timestamp}\n{credential_scope}\n{hashlib.sha256(http_request.encode()).hexdigest()}"

        def _hmac_sha256(key: bytes, msg: str) -> bytes:
            return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

        secret_date = _hmac_sha256(f"TC3{self._access_secret}".encode(), date)
        secret_service = _hmac_sha256(secret_date, service)
        secret_signing = _hmac_sha256(secret_service, "tc3_request")
        signature = hmac.new(secret_signing, string_to_sign.encode(), hashlib.sha256).hexdigest()

        authorization = (
            f"TC3-HMAC-SHA256 Credential={self._access_key}/{credential_scope}, "
            f"SignedHeaders=content-type;host, Signature={signature}"
        )

        headers = {
            "Content-Type": "application/json",
            "Host": host,
            "Authorization": authorization,
            "X-TC-Action": "SendSms",
            "X-TC-Version": "2021-01-11",
            "X-TC-Timestamp": str(timestamp),
        }

        try:
            req = urllib.request.Request(
                f"https://{host}",
                data=payload.encode(),
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read().decode())
                logger.info("腾讯云短信发送结果: %s", result)
                return result
        except Exception as e:
            logger.error("腾讯云短信发送失败: %s", e)
            return {"Error": str(e)}
