"""Home Assistant 渠道 — 通过 REST API 集成智能家居"""
from __future__ import annotations

import asyncio
import json
import logging
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional

from .base import Channel, IncomingMessage

logger = logging.getLogger(__name__)


class HomeAssistantChannel(Channel):
    """Home Assistant 渠道 — 作为 HA 的对话代理

    配置示例：
        {
            "ha_url": "http://192.168.1.100:8123",
            "token": "长期访问令牌",
            "poll_interval": 5,       # 轮询对话输入间隔
        }
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._ha_url = config.get("ha_url", "http://localhost:8123").rstrip("/")
        self._token = config.get("token", "")
        self._poll_interval = config.get("poll_interval", 5)
        self._running = False
        self._poll_task: Optional[asyncio.Task] = None

    def _headers(self) -> Dict[str, str]:
        """构建 HTTP 请求头"""
        return {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        }

    async def start(self) -> None:
        """启动 HA 渠道"""
        self._running = True
        logger.info("Home Assistant 渠道启动: %s", self._ha_url)

    async def stop(self) -> None:
        """停止 HA 渠道"""
        self._running = False
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        logger.info("Home Assistant 渠道已停止")

    async def send(self, user_id: str, content: str) -> None:
        """发送消息（通过 HA 通知服务）"""
        await self.call_service("notify", "notify", {
            "message": content,
            "title": "AI 助手",
        })

    async def handle_intent(self, intent: dict) -> str:
        """处理 HA 对话意图

        Args:
            intent: HA conversation/process 的请求体

        Returns:
            AI 回复文本
        """
        text = intent.get("text", intent.get("speech", {}).get("plain", {}).get("speech", ""))
        user_id = intent.get("user_id", "ha_user")

        if self._handler and text:
            incoming = IncomingMessage(
                channel="homeassistant",
                user_id=user_id,
                content=text,
                raw=intent,
            )
            reply = await self._handler(incoming)
            return reply or "抱歉，我没有理解您的意思。"
        return "AI 助手未就绪"

    async def call_service(
        self, domain: str, service: str, data: dict
    ) -> dict:
        """调用 HA 服务

        Args:
            domain: 服务域（如 light, switch, notify）
            service: 服务名（如 turn_on, turn_off）
            data: 服务数据

        Returns:
            API 返回结果
        """
        url = f"{self._ha_url}/api/services/{domain}/{service}"
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self._http_post, url, data
        )

    async def get_states(self) -> List[dict]:
        """获取所有实体状态

        Returns:
            实体状态列表
        """
        url = f"{self._ha_url}/api/states"
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._http_get, url)

    async def get_state(self, entity_id: str) -> dict:
        """获取单个实体状态"""
        url = f"{self._ha_url}/api/states/{entity_id}"
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._http_get, url)

    def _http_get(self, url: str) -> Any:
        """同步 GET 请求"""
        try:
            req = urllib.request.Request(url, headers=self._headers())
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            logger.error("HA API GET 失败 [%s]: %s", url, e)
            return {"error": str(e)}

    def _http_post(self, url: str, data: dict) -> Any:
        """同步 POST 请求"""
        try:
            payload = json.dumps(data).encode()
            req = urllib.request.Request(url, data=payload, headers=self._headers(), method="POST")
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = resp.read().decode()
                return json.loads(body) if body else {}
        except Exception as e:
            logger.error("HA API POST 失败 [%s]: %s", url, e)
            return {"error": str(e)}
