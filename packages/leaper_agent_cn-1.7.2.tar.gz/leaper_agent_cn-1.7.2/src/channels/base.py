"""渠道抽象基类"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Awaitable, Optional


@dataclass
class IncomingMessage:
    """收到的消息"""
    channel: str          # 渠道标识
    user_id: str          # 用户唯一 ID
    content: str          # 消息内容
    raw: Optional[dict] = None  # 原始数据


# 消息处理回调类型
MessageHandler = Callable[[IncomingMessage], Awaitable[Optional[str]]]


class Channel(ABC):
    """渠道抽象基类，所有渠道必须实现 start/send/stop"""

    def __init__(self, config: dict):
        self.config = config
        self._handler: Optional[MessageHandler] = None

    def on_message(self, handler: MessageHandler) -> None:
        """注册消息处理回调"""
        self._handler = handler

    @abstractmethod
    async def start(self) -> None:
        """启动渠道（注册 webhook 路由等）"""
        ...

    @abstractmethod
    async def send(self, user_id: str, content: str) -> None:
        """主动发送消息给用户"""
        ...

    @abstractmethod
    async def stop(self) -> None:
        """停止渠道，释放资源"""
        ...
