"""微信公众号渠道 - XML 回调 + 5秒超时处理（先回空，后推客服消息）"""
import asyncio
import hashlib
import time
import xml.etree.ElementTree as ET

import httpx
from aiohttp import web

from .base import Channel, IncomingMessage


class WeChatChannel(Channel):
    """微信公众号

    config:
        app_id: 公众号 AppID
        app_secret: 公众号 AppSecret
        token: 服务器验证 Token

    注意：微信要求 5 秒内回复，超时则先回空串，后通过客服消息接口异步推送。
    """

    TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token"
    CUSTOM_SEND_URL = "https://api.weixin.qq.com/cgi-bin/message/custom/send"

    def __init__(self, config: dict):
        super().__init__(config)
        self.app_id = config["app_id"]
        self.app_secret = config["app_secret"]
        self.token = config["token"]
        self._access_token: str = ""
        self._token_expires: float = 0

    def _check_signature(self, signature: str, timestamp: str, nonce: str) -> bool:
        """验证微信签名"""
        tmp = sorted([self.token, timestamp, nonce])
        sha1 = hashlib.sha1("".join(tmp).encode()).hexdigest()
        return sha1 == signature

    async def _get_access_token(self) -> str:
        """获取 access_token"""
        if self._access_token and time.time() < self._token_expires:
            return self._access_token
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                self.TOKEN_URL,
                params={
                    "grant_type": "client_credential",
                    "appid": self.app_id,
                    "secret": self.app_secret,
                },
            )
            data = resp.json()
            self._access_token = data["access_token"]
            self._token_expires = time.time() + data.get("expires_in", 7200) - 300
        return self._access_token

    async def handle_webhook(self, request: web.Request) -> web.Response:
        """处理微信公众号回调"""
        signature = request.query.get("signature", "")
        timestamp = request.query.get("timestamp", "")
        nonce = request.query.get("nonce", "")

        if not self._check_signature(signature, timestamp, nonce):
            return web.Response(status=403)

        # GET = 验证
        if request.method == "GET":
            echostr = request.query.get("echostr", "")
            return web.Response(text=echostr)

        # POST = 消息
        body = await request.text()
        xml_tree = ET.fromstring(body)
        msg_type = xml_tree.findtext("MsgType", "")
        content = xml_tree.findtext("Content", "").strip()
        from_user = xml_tree.findtext("FromUserName", "")
        to_user = xml_tree.findtext("ToUserName", "")

        if msg_type == "text" and content and self._handler:
            incoming = IncomingMessage(
                channel="wechat",
                user_id=from_user,
                content=content,
                raw={"xml": body},
            )
            # 5秒超时策略：先返回空，异步处理后通过客服消息推送
            asyncio.create_task(self._process_and_send_custom(incoming))

        # 返回空串（success），避免微信重试
        return web.Response(text="success")

    async def _process_and_send_custom(self, incoming: IncomingMessage) -> None:
        """异步处理消息，通过客服消息接口回复"""
        if not self._handler:
            return
        reply = await self._handler(incoming)
        if reply:
            await self.send(incoming.user_id, reply)

    async def send(self, user_id: str, content: str) -> None:
        """通过客服消息接口发送（需公众号有客服消息权限）"""
        token = await self._get_access_token()
        async with httpx.AsyncClient() as client:
            await client.post(
                self.CUSTOM_SEND_URL,
                params={"access_token": token},
                json={
                    "touser": user_id,
                    "msgtype": "text",
                    "text": {"content": content},
                },
            )

    async def start(self) -> None:
        """启动"""
        await self._get_access_token()

    async def stop(self) -> None:
        """停止"""
        pass
