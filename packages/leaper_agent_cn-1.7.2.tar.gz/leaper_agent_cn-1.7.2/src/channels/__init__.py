"""消息渠道 - 国内 IM 平台统一接入"""
from .base import Channel, IncomingMessage, MessageHandler
from .cli import CLIChannel
from .feishu import FeishuChannel
from .dingtalk import DingTalkChannel

__all__ = [
    "Channel", "IncomingMessage", "MessageHandler",
    "CLIChannel", "FeishuChannel", "DingTalkChannel",
    "create_channel",
]


def create_channel(name: str, config: dict) -> Channel:
    """工厂函数：根据名称创建渠道实例

    Args:
        name: 渠道名称 (cli/feishu/dingtalk/wecom/wechat)
        config: 渠道配置

    Returns:
        Channel 实例
    """
    from typing import Dict, Type
    _CHANNELS: Dict[str, Type[Channel]] = {
        "cli": CLIChannel,
        "feishu": FeishuChannel,
        "dingtalk": DingTalkChannel,
    }

    # 企微和微信需要 pycryptodome，lazy import
    if name == "wecom":
        from .wecom import WeComChannel
        return WeComChannel(config)
    elif name == "wechat":
        from .wechat import WeChatChannel
        return WeChatChannel(config)
    elif name == "weixin":
        from .weixin import WeixinChannel
        return WeixinChannel(config)
    elif name == "qqbot":
        from .qqbot import QQBotChannel
        return QQBotChannel(config)
    elif name == "email":
        from .email_channel import EmailChannel
        return EmailChannel(config)
    elif name == "sms":
        from .sms import SMSChannel
        return SMSChannel(config)
    elif name == "homeassistant":
        from .homeassistant import HomeAssistantChannel
        return HomeAssistantChannel(config)

    if name not in _CHANNELS:
        raise ValueError(f"未知渠道: {name}，可选: {list(_CHANNELS.keys()) + ['wecom', 'wechat', 'weixin', 'qqbot', 'email', 'sms', 'homeassistant']}")
    cls = _CHANNELS[name]
    return cls(config)
