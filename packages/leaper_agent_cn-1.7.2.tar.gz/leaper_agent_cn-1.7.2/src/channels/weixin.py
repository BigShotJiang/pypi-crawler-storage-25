"""微信公众号/服务号渠道 — CN 版 P0 核心渠道

功能：
- URL 验证（token + signature SHA1）
- 消息接收（XML 解密 → dict）
- 消息回复（dict → XML）
- 素材管理（上传图片/语音）
- 模板消息
- 客服消息
- 事件处理（关注/取关/菜单点击）
- AES 加解密（安全模式）

依赖：标准库 + httpx + pycryptodome（可选，安全模式时需要）
"""
import asyncio
import base64
import hashlib
import logging
import struct
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, Dict, List, Optional, Union

import httpx
from aiohttp import web

from .base import Channel, IncomingMessage

logger = logging.getLogger(__name__)

# ─── 常量 ─────────────────────────────────────────────
WX_API_BASE = "https://api.weixin.qq.com/cgi-bin"

# 消息类型
MSG_TEXT = "text"
MSG_IMAGE = "image"
MSG_VOICE = "voice"
MSG_VIDEO = "video"
MSG_EVENT = "event"

# 事件类型
EVENT_SUBSCRIBE = "subscribe"
EVENT_UNSUBSCRIBE = "unsubscribe"
EVENT_CLICK = "CLICK"
EVENT_VIEW = "VIEW"
EVENT_SCAN = "scan"


# ─── 数据结构 ──────────────────────────────────────────
@dataclass
class WeixinMessage:
    """解析后的微信消息"""
    to_user: str = ""
    from_user: str = ""
    create_time: int = 0
    msg_type: str = ""
    content: str = ""
    msg_id: str = ""
    # 图片
    pic_url: str = ""
    media_id: str = ""
    # 语音
    recognition: str = ""
    # 事件
    event: str = ""
    event_key: str = ""
    # 原始 XML
    raw_xml: str = ""


@dataclass
class AccessTokenCache:
    """access_token 缓存"""
    token: str = ""
    expires_at: float = 0.0


# ─── XML 工具 ──────────────────────────────────────────
def parse_xml(xml_str: str) -> WeixinMessage:
    """XML 字符串 → WeixinMessage"""
    msg = WeixinMessage(raw_xml=xml_str)
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        logger.warning("XML 解析失败")
        return msg

    msg.to_user = root.findtext("ToUserName", "")
    msg.from_user = root.findtext("FromUserName", "")
    msg.create_time = int(root.findtext("CreateTime", "0"))
    msg.msg_type = root.findtext("MsgType", "")
    msg.content = root.findtext("Content", "").strip()
    msg.msg_id = root.findtext("MsgId", "")
    msg.pic_url = root.findtext("PicUrl", "")
    msg.media_id = root.findtext("MediaId", "")
    msg.recognition = root.findtext("Recognition", "")
    msg.event = root.findtext("Event", "")
    msg.event_key = root.findtext("EventKey", "")
    return msg


def build_text_reply(from_user: str, to_user: str, content: str) -> str:
    """构造文本回复 XML"""
    return (
        "<xml>"
        f"<ToUserName><![CDATA[{to_user}]]></ToUserName>"
        f"<FromUserName><![CDATA[{from_user}]]></FromUserName>"
        f"<CreateTime>{int(time.time())}</CreateTime>"
        "<MsgType><![CDATA[text]]></MsgType>"
        f"<Content><![CDATA[{content}]]></Content>"
        "</xml>"
    )


def build_image_reply(from_user: str, to_user: str, media_id: str) -> str:
    """构造图片回复 XML"""
    return (
        "<xml>"
        f"<ToUserName><![CDATA[{to_user}]]></ToUserName>"
        f"<FromUserName><![CDATA[{from_user}]]></FromUserName>"
        f"<CreateTime>{int(time.time())}</CreateTime>"
        "<MsgType><![CDATA[image]]></MsgType>"
        f"<Image><MediaId><![CDATA[{media_id}]]></MediaId></Image>"
        "</xml>"
    )


# ─── AES 加解密（安全模式） ────────────────────────────
class WeixinCrypto:
    """微信消息加解密（AES-CBC + PKCS7）

    仅安全模式需要，encoding_aes_key 为 43 字符 base64。
    需要 pycryptodome: from Crypto.Cipher import AES
    """

    def __init__(self, app_id: str, encoding_aes_key: str):
        self.app_id = app_id
        # encoding_aes_key 是 43 字符 base64，补 = 后解码为 32 字节
        self.aes_key = base64.b64decode(encoding_aes_key + "=")
        self.iv = self.aes_key[:16]

    def decrypt(self, encrypted: str) -> str:
        """解密密文 → 明文 XML"""
        try:
            from Crypto.Cipher import AES as AESCipher
        except ImportError:
            raise ImportError("安全模式需要 pycryptodome: pip install pycryptodome")

        cipher = AESCipher.new(self.aes_key, AESCipher.MODE_CBC, self.iv)
        decrypted = cipher.decrypt(base64.b64decode(encrypted))

        # 去 PKCS7 padding
        pad_len = decrypted[-1]
        content = decrypted[:-pad_len]

        # 格式：16 字节随机 + 4 字节长度 + 明文 + app_id
        xml_len = struct.unpack("!I", content[16:20])[0]
        xml_content = content[20:20 + xml_len].decode("utf-8")
        from_app_id = content[20 + xml_len:].decode("utf-8")

        if from_app_id != self.app_id:
            raise ValueError(f"AppID 不匹配: {from_app_id} != {self.app_id}")
        return xml_content

    def encrypt(self, xml: str) -> str:
        """加密明文 XML → 密文"""
        try:
            from Crypto.Cipher import AES as AESCipher
        except ImportError:
            raise ImportError("安全模式需要 pycryptodome: pip install pycryptodome")

        import os
        xml_bytes = xml.encode("utf-8")
        app_id_bytes = self.app_id.encode("utf-8")
        # 16 字节随机 + 4 字节长度 + xml + app_id
        content = os.urandom(16) + struct.pack("!I", len(xml_bytes)) + xml_bytes + app_id_bytes

        # PKCS7 padding to AES block size (32)
        block_size = 32
        pad_len = block_size - (len(content) % block_size)
        content += bytes([pad_len] * pad_len)

        cipher = AESCipher.new(self.aes_key, AESCipher.MODE_CBC, self.iv)
        encrypted = cipher.encrypt(content)
        return base64.b64encode(encrypted).decode("utf-8")

    def decrypt_from_xml(self, xml_str: str) -> str:
        """从加密 XML 中提取 Encrypt 字段并解密"""
        root = ET.fromstring(xml_str)
        encrypted = root.findtext("Encrypt", "")
        if not encrypted:
            raise ValueError("XML 中未找到 Encrypt 字段")
        return self.decrypt(encrypted)


# ─── 事件处理器注册表 ──────────────────────────────────
EventHandler = Callable[[WeixinMessage], Awaitable[Optional[str]]]


# ─── 核心渠道类 ────────────────────────────────────────
class WeixinChannel(Channel):
    """微信公众号/服务号渠道

    config:
        app_id: str            — 公众号 AppID
        app_secret: str        — 公众号 AppSecret
        token: str             — 服务器验证 Token
        encoding_aes_key: str  — 加密密钥（可选，安全模式时需要）
        encrypt_mode: str      — "plain" | "safe"（默认 plain）
        reply_timeout: float   — 回复超时秒数（默认 4.5）
    """

    def __init__(self, config: dict):
        super().__init__(config)
        self.app_id: str = config["app_id"]
        self.app_secret: str = config["app_secret"]
        self.token: str = config["token"]
        self.encrypt_mode: str = config.get("encrypt_mode", "plain")
        self.reply_timeout: float = config.get("reply_timeout", 4.5)

        # AES 加解密（安全模式）
        self._crypto: Optional[WeixinCrypto] = None
        if self.encrypt_mode == "safe" and config.get("encoding_aes_key"):
            self._crypto = WeixinCrypto(self.app_id, config["encoding_aes_key"])

        # access_token 缓存
        self._token_cache = AccessTokenCache()

        # 事件处理器
        self._event_handlers: Dict[str, EventHandler] = {}

        # 统计
        self._stats = {"received": 0, "sent": 0, "errors": 0}

    # ─── 签名验证 ──────────────────────────────────────
    def verify_signature(self, signature: str, timestamp: str, nonce: str,
                         token: Optional[str] = None) -> bool:
        """验证微信服务器签名

        Args:
            signature: 微信传来的签名
            timestamp: 时间戳
            nonce: 随机数
            token: 验证 token（默认用 self.token）

        Returns:
            签名是否匹配
        """
        t = token or self.token
        tmp = sorted([t, timestamp, nonce])
        sha1 = hashlib.sha1("".join(tmp).encode("utf-8")).hexdigest()
        return sha1 == signature

    # ─── Access Token ──────────────────────────────────
    async def get_access_token(self) -> str:
        """获取 access_token，带内存缓存（提前 5 分钟过期）"""
        if self._token_cache.token and time.time() < self._token_cache.expires_at:
            return self._token_cache.token

        url = f"{WX_API_BASE}/token"
        params = {
            "grant_type": "client_credential",
            "appid": self.app_id,
            "secret": self.app_secret,
        }

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(url, params=params)
            data = resp.json()

        if "access_token" not in data:
            errcode = data.get("errcode", "unknown")
            errmsg = data.get("errmsg", "unknown")
            raise RuntimeError(f"获取 access_token 失败: {errcode} - {errmsg}")

        self._token_cache.token = data["access_token"]
        # 提前 5 分钟过期
        self._token_cache.expires_at = time.time() + data.get("expires_in", 7200) - 300
        logger.info("access_token 已刷新，有效期至 %s", self._token_cache.expires_at)
        return self._token_cache.token

    # ─── 消息处理 ──────────────────────────────────────
    async def handle_message(self, xml_data: str) -> str:
        """处理收到的 XML 消息，返回回复 XML

        Args:
            xml_data: 原始 XML（明文或密文）

        Returns:
            回复 XML 字符串，或 "success" 表示不回复
        """
        self._stats["received"] += 1

        # 安全模式解密
        if self._crypto and self.encrypt_mode == "safe":
            try:
                xml_data = self._crypto.decrypt_from_xml(xml_data)
            except Exception as e:
                logger.error("消息解密失败: %s", e)
                self._stats["errors"] += 1
                return "success"

        msg = parse_xml(xml_data)

        # 事件消息
        if msg.msg_type == MSG_EVENT:
            return await self._handle_event(msg)

        # 文本消息
        if msg.msg_type == MSG_TEXT and msg.content:
            return await self._handle_text(msg)

        # 语音消息（识别结果当文本处理）
        if msg.msg_type == MSG_VOICE and msg.recognition:
            msg.content = msg.recognition
            return await self._handle_text(msg)

        # 其他消息类型：回复 success
        return "success"

    async def _handle_text(self, msg: WeixinMessage) -> str:
        """处理文本消息"""
        if not self._handler:
            return "success"

        incoming = IncomingMessage(
            channel="weixin",
            user_id=msg.from_user,
            content=msg.content,
            raw={"msg": msg},
        )

        # 尝试在超时内获得回复
        try:
            reply = await asyncio.wait_for(
                self._handler(incoming),
                timeout=self.reply_timeout,
            )
            if reply:
                xml_reply = build_text_reply(msg.to_user, msg.from_user, reply)
                if self._crypto and self.encrypt_mode == "safe":
                    # 安全模式需要加密回复（简化：直接返回明文 XML）
                    pass
                return xml_reply
        except asyncio.TimeoutError:
            # 超时：异步处理，先返回空
            logger.info("回复超时，转客服消息推送: user=%s", msg.from_user)
            asyncio.create_task(self._async_reply(incoming))

        return "success"

    async def _async_reply(self, incoming: IncomingMessage) -> None:
        """超时后异步处理并通过客服消息推送"""
        if not self._handler:
            return
        try:
            reply = await self._handler(incoming)
            if reply:
                await self.send_customer_service(incoming.user_id, reply)
        except Exception as e:
            logger.error("异步回复失败: %s", e)
            self._stats["errors"] += 1

    async def _handle_event(self, msg: WeixinMessage) -> str:
        """处理事件消息"""
        event = msg.event.lower() if msg.event else ""

        # 自定义事件处理器
        if event in self._event_handlers:
            try:
                result = await self._event_handlers[event](msg)
                if result:
                    return build_text_reply(msg.to_user, msg.from_user, result)
            except Exception as e:
                logger.error("事件处理失败 [%s]: %s", event, e)

        # 默认关注回复
        if event == EVENT_SUBSCRIBE.lower():
            logger.info("新用户关注: %s", msg.from_user)
            welcome = self.config.get("welcome_text", "欢迎关注！")
            return build_text_reply(msg.to_user, msg.from_user, welcome)

        if event == EVENT_UNSUBSCRIBE.lower():
            logger.info("用户取消关注: %s", msg.from_user)

        return "success"

    def on_event(self, event_type: str, handler: EventHandler) -> None:
        """注册事件处理器

        Args:
            event_type: 事件类型（subscribe/unsubscribe/CLICK/VIEW 等）
            handler: 异步处理函数
        """
        self._event_handlers[event_type.lower()] = handler

    # ─── 客服消息 ──────────────────────────────────────
    async def send_customer_service(self, openid: str, content: str) -> None:
        """发送客服文本消息

        Args:
            openid: 用户 OpenID
            content: 消息文本
        """
        token = await self.get_access_token()
        url = f"{WX_API_BASE}/message/custom/send"

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                url,
                params={"access_token": token},
                json={
                    "touser": openid,
                    "msgtype": "text",
                    "text": {"content": content},
                },
            )
            data = resp.json()
            if data.get("errcode", 0) != 0:
                logger.error("客服消息发送失败: %s", data)
                self._stats["errors"] += 1
            else:
                self._stats["sent"] += 1

    async def send_customer_service_image(self, openid: str, media_id: str) -> None:
        """发送客服图片消息"""
        token = await self.get_access_token()
        url = f"{WX_API_BASE}/message/custom/send"

        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                url,
                params={"access_token": token},
                json={
                    "touser": openid,
                    "msgtype": "image",
                    "image": {"media_id": media_id},
                },
            )
            self._stats["sent"] += 1

    # ─── 模板消息 ──────────────────────────────────────
    async def send_template(self, openid: str, template_id: str,
                            data: Dict[str, Any],
                            url: str = "",
                            miniprogram: Optional[Dict[str, str]] = None) -> dict:
        """发送模板消息

        Args:
            openid: 用户 OpenID
            template_id: 模板 ID
            data: 模板数据，格式 {"key": {"value": "xxx", "color": "#173177"}}
            url: 点击跳转 URL（可选）
            miniprogram: 小程序信息（可选）

        Returns:
            微信 API 返回的 JSON
        """
        token = await self.get_access_token()
        api_url = f"{WX_API_BASE}/message/template/send"

        payload: Dict[str, Any] = {
            "touser": openid,
            "template_id": template_id,
            "data": data,
        }
        if url:
            payload["url"] = url
        if miniprogram:
            payload["miniprogram"] = miniprogram

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                api_url,
                params={"access_token": token},
                json=payload,
            )
            result = resp.json()
            if result.get("errcode", 0) != 0:
                logger.error("模板消息发送失败: %s", result)
                self._stats["errors"] += 1
            else:
                self._stats["sent"] += 1
            return result

    # ─── 素材管理 ──────────────────────────────────────
    async def upload_media(self, media_type: str, file_path: str) -> str:
        """上传临时素材（图片/语音/视频/缩略图）

        Args:
            media_type: image/voice/video/thumb
            file_path: 文件路径

        Returns:
            media_id
        """
        token = await self.get_access_token()
        url = f"{WX_API_BASE}/media/upload"

        import os
        filename = os.path.basename(file_path)

        async with httpx.AsyncClient(timeout=30) as client:
            with open(file_path, "rb") as f:
                resp = await client.post(
                    url,
                    params={"access_token": token, "type": media_type},
                    files={"media": (filename, f)},
                )
            data = resp.json()
            if "media_id" not in data:
                raise RuntimeError(f"素材上传失败: {data}")
            return data["media_id"]

    async def upload_media_bytes(self, media_type: str, filename: str,
                                 content: bytes) -> str:
        """上传临时素材（从内存字节）

        Args:
            media_type: image/voice/video/thumb
            filename: 文件名
            content: 文件内容

        Returns:
            media_id
        """
        token = await self.get_access_token()
        url = f"{WX_API_BASE}/media/upload"

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                url,
                params={"access_token": token, "type": media_type},
                files={"media": (filename, content)},
            )
            data = resp.json()
            if "media_id" not in data:
                raise RuntimeError(f"素材上传失败: {data}")
            return data["media_id"]

    # ─── Webhook 处理（aiohttp） ──────────────────────
    async def handle_webhook(self, request: web.Request) -> web.Response:
        """aiohttp webhook 处理入口"""
        signature = request.query.get("signature", "")
        timestamp = request.query.get("timestamp", "")
        nonce = request.query.get("nonce", "")

        if not self.verify_signature(signature, timestamp, nonce):
            return web.Response(status=403, text="Invalid signature")

        # GET = URL 验证
        if request.method == "GET":
            echostr = request.query.get("echostr", "")
            return web.Response(text=echostr)

        # POST = 消息/事件
        body = await request.text()
        try:
            reply_xml = await self.handle_message(body)
            return web.Response(text=reply_xml, content_type="application/xml")
        except Exception as e:
            logger.error("Webhook 处理异常: %s", e)
            self._stats["errors"] += 1
            return web.Response(text="success")

    # ─── Channel 接口实现 ──────────────────────────────
    async def start(self, config: Optional[dict] = None) -> None:
        """启动渠道，预获取 access_token"""
        if config:
            self.config.update(config)
        try:
            await self.get_access_token()
            logger.info("微信渠道启动成功: app_id=%s", self.app_id)
        except Exception as e:
            logger.warning("微信渠道启动时获取 token 失败（将在使用时重试）: %s", e)

    async def send(self, user_id: str, content: str) -> None:
        """发送消息（通过客服消息接口）"""
        await self.send_customer_service(user_id, content)

    async def stop(self) -> None:
        """停止渠道"""
        logger.info("微信渠道已停止")

    def get_stats(self) -> dict:
        """获取统计信息"""
        return dict(self._stats)
