"""
输出格式化模块 — ANSI 彩色输出、表格、进度条等

不引入 rich 以外的依赖（rich 已在项目中使用），
但本模块提供纯 ANSI escape code 版本，用于轻量场景。
"""

from __future__ import annotations

import json
import sys
from typing import Any, Sequence

# ---------------------------------------------------------------------------
# ANSI 颜色常量
# ---------------------------------------------------------------------------

class Colors:
    """ANSI 转义序列颜色常量"""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"

    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    GRAY = "\033[90m"

    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"


def _supports_color() -> bool:
    """检测终端是否支持 ANSI 颜色"""
    if not hasattr(sys.stdout, "isatty"):
        return False
    if not sys.stdout.isatty():
        return False
    return True


def _c(color: str, text: str) -> str:
    """有条件地应用颜色"""
    if not _supports_color():
        return text
    return f"{color}{text}{Colors.RESET}"


# ---------------------------------------------------------------------------
# 格式化函数
# ---------------------------------------------------------------------------

def format_tool_call(name: str, args: dict[str, Any] | None = None) -> str:
    """格式化工具调用显示

    示例输出: 🔧 search_web(query="AI trends", limit=5)
    """
    if not args:
        return _c(Colors.CYAN, f"🔧 {name}()")

    # 格式化参数，截断过长的值
    parts = []
    for k, v in args.items():
        val_str = json.dumps(v, ensure_ascii=False) if not isinstance(v, str) else f'"{v}"'
        if len(val_str) > 50:
            val_str = val_str[:47] + "..."
        parts.append(f"{k}={val_str}")

    args_str = ", ".join(parts)
    return _c(Colors.CYAN, f"🔧 {name}({args_str})")


def format_response(text: str, stream: bool = False) -> str:
    """格式化 AI 回复

    stream=True 时返回原文（用于逐字输出场景）
    """
    if stream:
        return text
    return _c(Colors.GREEN, "AI") + _c(Colors.GRAY, " > ") + text


def format_error(error: Exception | str) -> str:
    """用户友好的错误信息（不泄露技术堆栈）

    将常见错误映射为中文提示
    """
    msg = str(error)

    # 常见错误模式映射
    _ERROR_MAP = {
        "401": "API 密钥验证失败，请检查 api_key 配置",
        "403": "API 访问被拒绝，请检查账号权限",
        "429": "请求过于频繁，请稍后重试",
        "timeout": "请求超时，请检查网络连接",
        "connect": "无法连接到服务器，请检查网络或 API 地址",
        "invalid": "请求参数无效，请检查配置",
        "quota": "API 配额已用完，请充值或更换 Key",
    }

    for pattern, friendly_msg in _ERROR_MAP.items():
        if pattern.lower() in msg.lower():
            return _c(Colors.RED, f"❌ {friendly_msg}")

    # 通用错误，不泄露细节
    return _c(Colors.RED, f"❌ 操作失败，请稍后重试")


def format_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    """简单 ASCII 表格

    >>> format_table(["名称", "状态"], [["brain.db", "✅"], ["config", "❌"]])
    """
    if not headers:
        return ""

    # 计算每列最大宽度（考虑中文字符宽度）
    def _display_width(s: str) -> int:
        """计算字符串显示宽度（中文字符算2）"""
        w = 0
        for ch in s:
            if '\u4e00' <= ch <= '\u9fff' or '\uff00' <= ch <= '\uffef':
                w += 2
            else:
                w += 1
        return w

    all_rows = [list(headers)] + [list(r) for r in rows]
    col_widths = []
    for col_idx in range(len(headers)):
        max_w = 0
        for row in all_rows:
            if col_idx < len(row):
                max_w = max(max_w, _display_width(str(row[col_idx])))
        col_widths.append(max_w)

    def _pad(text: str, width: int) -> str:
        """按显示宽度对齐"""
        dw = _display_width(text)
        return text + " " * max(0, width - dw)

    lines = []
    # 表头
    header_line = " | ".join(_pad(str(h), col_widths[i]) for i, h in enumerate(headers))
    lines.append(header_line)
    # 分隔线
    sep_line = "-+-".join("-" * w for w in col_widths)
    lines.append(sep_line)
    # 数据行
    for row in rows:
        cells = []
        for i in range(len(headers)):
            cell = str(row[i]) if i < len(row) else ""
            cells.append(_pad(cell, col_widths[i]))
        lines.append(" | ".join(cells))

    return "\n".join(lines)


def format_progress(current: int, total: int, label: str = "") -> str:
    """进度条

    示例: 导入记忆 [████████░░░░░░░░] 50% (5/10)
    """
    if total <= 0:
        return f"{label} [{'░' * 20}] 0%"

    ratio = min(current / total, 1.0)
    filled = int(ratio * 20)
    bar = "█" * filled + "░" * (20 - filled)
    pct = int(ratio * 100)

    parts = []
    if label:
        parts.append(label)
    parts.append(f"[{bar}] {pct}% ({current}/{total})")

    return " ".join(parts)


def format_check(passed: bool, label: str, detail: str = "") -> str:
    """格式化检查项结果（用于 doctor 命令）

    ✅ Python 版本 >= 3.10 (3.12.0)
    ❌ brain.db 不可读写 (权限不足)
    """
    icon = "✅" if passed else "❌"
    line = f"  {icon} {label}"
    if detail:
        line += _c(Colors.GRAY, f" ({detail})")
    return line
