"""AgentRunner — 完整的 Agent 运行引擎，统一入口

参考 Hermes run_agent.py，在 AgentLoop 上层封装完整的 agent 运行逻辑，
包括初始化、工具注册、安全检查、轨迹记录、优雅关闭等。
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ..config import LeaperConfig
from ..tools.base import Tool
from ..tools.registry import ToolRegistry, PRIORITY_NATIVE, PRIORITY_MCP, PRIORITY_SKILL
from ..tools.toolsets import get_toolset, TOOLSETS
from ..tools.output_limits import truncate_output
from ..tools.schema_sanitizer import sanitize_schema
from ..tools.process_registry import ProcessRegistry

from .loop import AgentLoop
from .state import AgentState
from .trajectory import TrajectoryRecorder
from .compressor import compress_if_needed
from .rate_limiter import RateLimiter
from .credential_pool import CredentialPool, AllCredentialsExhausted
from .error_classifier import classify_error
from .retry import retry_with_backoff
from .redact import redact_sensitive
from . import insights as insights_mod
from . import model_meta

logger = logging.getLogger(__name__)


class AgentRunner:
    """完整的 Agent 运行引擎

    统一管理 Agent 的生命周期：
    - 初始化所有子系统（tools, brain, mcp, session, ...）
    - 提供 run_single / run_interactive / run_gateway 入口
    - 工具调用安全检查 + 输出限制
    - 轨迹记录和状态追踪
    - 优雅关闭
    """

    def __init__(
        self,
        config: LeaperConfig,
        workspace_dir: str,
        brain: Any = None,
    ):
        self.config = config
        self.workspace = workspace_dir
        self.brain = brain

        # 子系统（initialize() 后可用）
        self.loop: Optional[AgentLoop] = None
        self.state: AgentState = AgentState()
        self.tool_registry: ToolRegistry = ToolRegistry()
        self.process_registry: ProcessRegistry = ProcessRegistry()
        self.trajectory: TrajectoryRecorder = TrajectoryRecorder(
            save_dir=os.path.join(workspace_dir, ".trajectories")
        )
        self.rate_limiter: RateLimiter = RateLimiter(max_calls=30, window_seconds=60.0)

        # 可选子系统
        self.credential_pool: Optional[CredentialPool] = None
        self.prompt_builder: Any = None  # LeaperPromptBuilder
        self.context_engine: Any = None  # ContextEngine
        self.mcp_manager: Any = None  # MCPManager
        self.compressor: Any = None  # 压缩器

        # 运行状态
        self._initialized = False
        self._shutdown_called = False
        self._model_name: str = config.provider.model or ""
        self._model_max_tokens: int = model_meta.get_max_tokens(self._model_name) if self._model_name else 100000
        self._provider: Any = None
        self._system_prompt: str = ""
        self._toolset_name: str = "standard"  # 默认工具集

    async def initialize(self, toolset: str = "standard") -> None:
        """初始化所有子系统

        Args:
            toolset: 使用的工具集名称
        """
        if self._initialized:
            logger.warning("AgentRunner 已初始化，跳过重复初始化")
            return

        self._toolset_name = toolset
        logger.info(f"开始初始化 AgentRunner (workspace={self.workspace})")

        # 1. 创建 provider
        self._provider = self._create_provider()

        # 2. 注册 native tools
        self._register_native_tools(toolset)

        # 3. 初始化 credential pool
        api_keys = self._get_api_keys()
        if len(api_keys) > 1:
            self.credential_pool = CredentialPool(api_keys)

        # 4. 初始化 brain
        if self.config.brain.enabled and self.brain is None:
            self.brain = await self._create_brain()

        # 5. 构建 system prompt
        self._system_prompt = self._load_system_prompt()

        # 6. 初始化 prompt builder
        try:
            from .prompt_builder import LeaperPromptBuilder
            self.prompt_builder = LeaperPromptBuilder(self.workspace, self.brain)
        except ImportError:
            pass

        # 7. 初始化 MCP manager
        await self._init_mcp()

        # 8. 创建 AgentLoop
        tools_dict = self._build_tools_dict()
        self.loop = AgentLoop(
            provider=self._provider,
            brain=self.brain,
            tools=tools_dict,
            system_prompt=self._system_prompt,
            workspace_dir=self.workspace,
            agent_id=self.config.agent.name or "default",
            model_name=self._model_name,
            api_keys=api_keys if len(api_keys) > 1 else None,
        )

        # 9. 加载状态
        self.state.is_running = True
        self.state.load()

        # 10. 初始化轨迹记录器
        self.trajectory = TrajectoryRecorder(
            save_dir=os.path.join(self.workspace, ".trajectories")
        )

        self._initialized = True
        logger.info(
            f"AgentRunner 初始化完成: "
            f"tools={len(self.tool_registry)}, "
            f"model={self._model_name}, "
            f"toolset={toolset}"
        )

    async def run_single(self, message: str, session_id: Optional[str] = None) -> str:
        """执行单次对话

        Args:
            message: 用户消息
            session_id: 可选的会话 ID

        Returns:
            助手回复文本
        """
        if not self._initialized:
            await self.initialize()

        # 限流检查
        await self.rate_limiter.wait_if_needed()
        self.rate_limiter.record_call()

        # 开始轨迹记录
        self.trajectory.start_turn(message)

        try:
            # 通过 AgentLoop 执行对话
            start_ms = int(time.time() * 1000)
            response = await self.loop.chat(message)
            latency_ms = int(time.time() * 1000) - start_ms

            # 记录 LLM 调用（近似值，实际 token 数需要 provider 返回）
            self.trajectory.record_llm_call(
                prompt_tokens=0,  # AgentLoop 不暴露 token 数
                response_tokens=0,
                model=self._model_name,
                latency_ms=latency_ms,
            )

            # 脱敏处理
            response = redact_sensitive(response)

            # 记录状态
            self.state.record_message(tokens=0, model=self._model_name)

            # 结束轨迹
            self.trajectory.end_turn(response)

            return response

        except Exception as e:
            error_info = classify_error(e)
            self.state.record_error(error_info.category)
            self.trajectory.end_turn(f"错误: {e}")
            raise

    async def run_interactive(self) -> None:
        """启动交互式 REPL

        使用 rich 的终端 UI，支持 /quit 退出。
        """
        if not self._initialized:
            await self.initialize()

        from rich.console import Console
        from rich.prompt import Prompt

        console = Console()
        console.print(f"[bold blue]🤖 Agent 就绪[/bold blue] (模型: {self._model_name})")
        console.print(f"[dim]工具集: {self._toolset_name} ({len(self.tool_registry)} 个工具)[/dim]")
        console.print("[dim]输入 /quit 退出，/stats 查看统计[/dim]\n")

        while True:
            try:
                user_input = Prompt.ask("[bold blue]你[/bold blue]")
            except (KeyboardInterrupt, EOFError):
                break

            text = user_input.strip()
            if text in ("/quit", "/exit", "exit", "quit"):
                break

            if text == "/stats":
                stats = self.trajectory.get_stats()
                console.print(f"[dim]轮次: {stats['total_turns']}, "
                            f"Tokens: {stats['total_tokens']}, "
                            f"工具调用: {stats['total_tool_calls']}, "
                            f"成本: ¥{stats['total_cost_yuan']}[/dim]")
                continue

            if text == "/tools":
                for info in self.tool_registry.list_all():
                    console.print(f"  • [bold]{info.name}[/bold] ({info.source}, pri={info.priority})")
                continue

            if not text:
                continue

            try:
                reply = await self.run_single(text)
                console.print(f"[bold green]AI[/bold green]> {reply}\n")
            except Exception as e:
                console.print(f"[red]❌ {e}[/red]\n")

        await self.shutdown()
        console.print("[dim]👋 再见！[/dim]")

    async def run_gateway(self, gateway_config: dict) -> None:
        """Gateway 模式（渠道网关）

        Args:
            gateway_config: 网关配置 dict
        """
        if not self._initialized:
            await self.initialize()

        from ..gateway import Gateway

        gateway = Gateway(gateway_config)
        gateway.setup_from_config()

        # 注入 runner 到 gateway（如果支持）
        if hasattr(gateway, "set_runner"):
            gateway.set_runner(self)

        gateway.run()

    async def handle_tool_calls(self, tool_calls: list) -> List[dict]:
        """执行工具调用列表（带安全检查和输出限制）

        Args:
            tool_calls: LLM 返回的 tool_calls 列表

        Returns:
            工具执行结果列表
        """
        results = []

        for tc in tool_calls:
            func_name = tc.get("function", {}).get("name", "")
            func_args_raw = tc.get("function", {}).get("arguments", {})

            # 解析参数
            if isinstance(func_args_raw, str):
                try:
                    func_args = json.loads(func_args_raw) if func_args_raw else {}
                except json.JSONDecodeError:
                    func_args = {}
            else:
                func_args = func_args_raw

            # 执行工具
            try:
                if self.tool_registry.has(func_name):
                    result = await self.tool_registry.execute(func_name, func_args)
                    success = True
                else:
                    result = f"工具 '{func_name}' 未注册"
                    success = False
            except Exception as e:
                result = f"工具执行失败: {type(e).__name__}: {e}"
                success = False

            # 输出限制
            result = truncate_output(result, func_name)

            # 脱敏
            result = redact_sensitive(result)

            # 记录
            self.state.record_tool_call(func_name, success)
            self.trajectory.record_tool_call(
                tool=func_name,
                args=func_args,
                result=result,
                success=success,
            )

            results.append({
                "tool_call_id": tc.get("id", ""),
                "content": result,
            })

        return results

    async def shutdown(self) -> None:
        """优雅关闭所有子系统"""
        if self._shutdown_called:
            return
        self._shutdown_called = True

        logger.info("AgentRunner 正在关闭...")

        # 保存状态
        self.state.is_running = False
        try:
            self.state.save()
        except Exception as e:
            logger.error(f"保存状态失败: {e}")

        # 保存轨迹
        try:
            session_id = self.config.agent.name or "default"
            self.trajectory.save(session_id)
        except Exception as e:
            logger.error(f"保存轨迹失败: {e}")

        # 终止所有子进程
        try:
            await self.process_registry.kill_all()
        except Exception as e:
            logger.error(f"终止子进程失败: {e}")

        # 断开 MCP
        if self.mcp_manager:
            try:
                await self.mcp_manager.disconnect_all()
            except Exception:
                pass

        logger.info("AgentRunner 已关闭")

    # ── 内部方法 ──

    def _create_provider(self) -> Any:
        """根据配置创建 LLM provider"""
        from ..providers import create_provider

        return create_provider(self.config.provider.name, {
            "api_key": self.config.provider.api_key,
            "model": self.config.provider.model,
        })

    def _get_api_keys(self) -> List[str]:
        """获取 API key 列表"""
        keys = []
        primary = self.config.provider.api_key
        if primary:
            keys.append(primary)
        # 支持环境变量中的备用 key
        extra = os.environ.get("LEAPER_API_KEYS", "")
        if extra:
            keys.extend(k.strip() for k in extra.split(",") if k.strip())
        return keys

    def _register_native_tools(self, toolset: str = "standard") -> None:
        """根据工具集注册 native tools"""
        from ..tools import get_tools_dict

        all_tools = get_tools_dict()
        try:
            allowed = get_toolset(toolset)
        except KeyError:
            allowed = list(all_tools.keys())  # fallback to all

        for name, tool in all_tools.items():
            if name in allowed:
                self.tool_registry.register(
                    name=name,
                    handler=tool,
                    schema=tool.parameters,
                    priority=PRIORITY_NATIVE,
                    source="native",
                    description=tool.description,
                )

    def _build_tools_dict(self) -> Dict[str, Tool]:
        """从 registry 构建 {name: Tool} dict（兼容 AgentLoop）"""
        result = {}
        for handler_info in self.tool_registry._handlers.values():
            if isinstance(handler_info.handler, Tool):
                result[handler_info.name] = handler_info.handler
        return result

    def _load_system_prompt(self) -> str:
        """从 workspace 加载 system prompt"""
        ws_path = Path(self.workspace).expanduser()
        _PROMPT_FILES = [
            "PREAMBLE.md", "IDENTITY.md", "SOUL.md", "EGO.md", "USER.md",
            "AGENTS.md", "MEMORY.md", "ROLE-TYPES.md", "SELF-CHECK.md",
            "LIFECYCLE.md", "TRIGGERS.md", "ONBOARDING.md",
        ]
        parts = []
        for fname in _PROMPT_FILES:
            fpath = ws_path / fname
            if fpath.exists():
                try:
                    content = fpath.read_text(encoding="utf-8")
                    parts.append(f"## {fname}\n{content}")
                except OSError:
                    pass
        return "\n\n---\n\n".join(parts) if parts else ""

    async def _create_brain(self) -> Any:
        """创建 Brain 实例"""
        try:
            from ..brain.engine import LeaperBrain
            db_path = self.config.brain.db_path
            brain = LeaperBrain(
                db_path=db_path,
                agent_id=self.config.agent.name or "leaper-agent",
            )
            await brain.initialize()
            return brain
        except Exception as e:
            logger.warning(f"Brain 初始化失败，降级运行: {e}")
            return None

    async def _init_mcp(self) -> None:
        """初始化 MCP Manager"""
        try:
            from ..mcp.manager import MCPManager
            self.mcp_manager = MCPManager()
            # MCP 配置从 config 读取（如果有）
            mcp_config = getattr(self.config, "mcp", None)
            if mcp_config and hasattr(mcp_config, "servers"):
                for server_cfg in mcp_config.servers:
                    await self.mcp_manager.connect(server_cfg)
                    # 注册 MCP 工具到 registry
                    mcp_tools = self.mcp_manager.get_tools()
                    self.tool_registry.register_from_mcp(mcp_tools)
        except (ImportError, AttributeError, Exception) as e:
            logger.debug(f"MCP 未配置或初始化失败: {e}")
            self.mcp_manager = None

    def get_status(self) -> dict:
        """获取 runner 状态摘要"""
        return {
            "initialized": self._initialized,
            "model": self._model_name,
            "toolset": self._toolset_name,
            "tools_count": len(self.tool_registry),
            "processes_running": self.process_registry.running_count,
            "brain_enabled": self.brain is not None,
            "state": self.state.get_summary(),
            "trajectory_stats": self.trajectory.get_stats(),
        }
