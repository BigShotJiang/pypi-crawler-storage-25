"""
Credential Pool - 多 API Key 轮转管理

支持多个 API key 轮转使用，自动跳过被标记为耗尽（429/超额）的 key。
所有 key 耗尽时抛出 AllCredentialsExhausted。
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class AllCredentialsExhausted(Exception):
    """所有 API key 均已耗尽"""
    pass


class CredentialPool:
    """多 API Key 轮转池

    线程安全的 key 轮转管理器。支持标记 key 为耗尽状态，
    自动跳过耗尽的 key，并在恢复后重新启用。

    示例::

        pool = CredentialPool(["key1", "key2", "key3"])
        key = pool.get_next()  # -> "key1"
        key = pool.get_next()  # -> "key2"
        pool.mark_exhausted("key1")
        key = pool.get_next()  # -> "key3" (跳过 key1)
    """

    def __init__(self, keys: List[str]):
        """初始化 credential pool

        Args:
            keys: API key 列表，不能为空

        Raises:
            ValueError: keys 为空
        """
        if not keys:
            raise ValueError("keys 列表不能为空")

        # 去重但保持顺序
        seen: set = set()
        unique_keys: List[str] = []
        for k in keys:
            if k and k not in seen:
                seen.add(k)
                unique_keys.append(k)

        if not unique_keys:
            raise ValueError("keys 列表不能为空（去重后）")

        self._keys = unique_keys
        self._exhausted: Set[str] = set()
        self._exhausted_at: Dict[str, float] = {}  # key -> timestamp
        self._index = 0
        self._lock = threading.Lock()

    @property
    def total_keys(self) -> int:
        """总 key 数"""
        return len(self._keys)

    @property
    def available_keys(self) -> int:
        """可用 key 数"""
        return len(self._keys) - len(self._exhausted)

    @property
    def exhausted_keys(self) -> int:
        """已耗尽 key 数"""
        return len(self._exhausted)

    def get_next(self) -> str:
        """轮转获取下一个可用 key

        Returns:
            API key 字符串

        Raises:
            AllCredentialsExhausted: 所有 key 均已耗尽
        """
        with self._lock:
            # 尝试遍历所有 key 找到一个可用的
            for _ in range(len(self._keys)):
                key = self._keys[self._index % len(self._keys)]
                self._index += 1
                if key not in self._exhausted:
                    return key

            # 所有 key 都耗尽了
            raise AllCredentialsExhausted(
                f"所有 {len(self._keys)} 个 API key 均已耗尽"
            )

    def mark_exhausted(self, key: str) -> None:
        """标记 key 为耗尽状态（429/超额）

        Args:
            key: 要标记的 API key
        """
        with self._lock:
            if key in self._keys:
                self._exhausted.add(key)
                self._exhausted_at[key] = time.time()
                logger.warning(
                    "API key 已标记耗尽: %s...%s (剩余 %d/%d)",
                    key[:4], key[-4:] if len(key) > 8 else "****",
                    self.available_keys, self.total_keys,
                )

    def mark_recovered(self, key: str) -> None:
        """标记 key 已恢复可用

        Args:
            key: 要恢复的 API key
        """
        with self._lock:
            self._exhausted.discard(key)
            self._exhausted_at.pop(key, None)
            logger.info(
                "API key 已恢复: %s...%s (可用 %d/%d)",
                key[:4], key[-4:] if len(key) > 8 else "****",
                self.available_keys, self.total_keys,
            )

    def recover_after(self, seconds: float) -> int:
        """自动恢复超过指定时间的耗尽 key

        Args:
            seconds: 超过此时间（秒）自动恢复

        Returns:
            恢复的 key 数量
        """
        now = time.time()
        recovered = 0
        with self._lock:
            to_recover = [
                k for k, t in self._exhausted_at.items()
                if now - t >= seconds
            ]
            for k in to_recover:
                self._exhausted.discard(k)
                self._exhausted_at.pop(k, None)
                recovered += 1

        if recovered:
            logger.info("自动恢复 %d 个 API key", recovered)
        return recovered

    def reset(self) -> None:
        """重置所有状态，恢复所有 key"""
        with self._lock:
            self._exhausted.clear()
            self._exhausted_at.clear()
            self._index = 0
