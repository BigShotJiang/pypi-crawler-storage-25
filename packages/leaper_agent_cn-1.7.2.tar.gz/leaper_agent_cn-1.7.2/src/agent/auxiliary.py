"""Auxiliary Client - 辅助 LLM 调用

用较便宜的模型（如 deepseek-chat）执行辅助任务：
摘要、分类、关键词提取、翻译、回复审查。
"""
from __future__ import annotations

import json
from typing import Dict, List, Optional, Any


class AuxiliaryClient:
    """辅助 LLM 客户端"""

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        config = config or {}
        self.model: str = config.get("auxiliary_model", "deepseek-chat")
        self.provider: Optional[Any] = None
        self._config = config

    def _get_provider(self) -> Any:
        """延迟获取 provider"""
        if self.provider is not None:
            return self.provider
        # 尝试从已有 provider 创建
        try:
            from ..providers import get_provider
            self.provider = get_provider(self.model)
        except Exception:
            self.provider = None
        return self.provider

    async def _call_llm(self, system_prompt: str, user_prompt: str) -> str:
        """调用辅助 LLM"""
        provider = self._get_provider()
        if provider is None:
            return "[辅助模型不可用，请检查配置]"
        try:
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
            response = await provider.chat(messages, model=self.model)
            if isinstance(response, dict):
                return response.get("content", str(response))
            return str(response)
        except Exception as e:
            return f"[辅助模型调用失败: {e}]"

    async def summarize(self, text: str, max_length: int = 200) -> str:
        """用辅助模型总结文本"""
        if not text.strip():
            return ""
        system = f"你是一个摘要助手。请将以下内容总结为不超过{max_length}字的摘要，保留关键信息。只输出摘要，不要解释。"
        return await self._call_llm(system, text)

    async def classify(self, text: str, categories: List[str]) -> str:
        """用辅助模型分类"""
        if not text.strip() or not categories:
            return ""
        cats = "、".join(categories)
        system = f"你是一个分类助手。请将以下内容分类到这些类别之一: {cats}。只输出类别名称，不要解释。"
        return await self._call_llm(system, text)

    async def extract_keywords(self, text: str, max_keywords: int = 10) -> List[str]:
        """提取关键词"""
        if not text.strip():
            return []
        system = f"提取以下文本的关键词，最多{max_keywords}个。用逗号分隔，只输出关键词。"
        result = await self._call_llm(system, text)
        if result.startswith("["):
            return []
        return [kw.strip() for kw in result.split(",") if kw.strip()][:max_keywords]

    async def translate(self, text: str, target_lang: str = "zh") -> str:
        """翻译"""
        if not text.strip():
            return ""
        lang_map = {"zh": "中文", "en": "英文", "ja": "日文", "ko": "韩文"}
        lang_name = lang_map.get(target_lang, target_lang)
        system = f"将以下内容翻译为{lang_name}。只输出翻译结果。"
        return await self._call_llm(system, text)

    async def review_response(self, response: str, context: str) -> str:
        """审查回复质量"""
        if not response.strip():
            return "回复为空"
        system = "你是一个回复质量审查助手。请检查以下回复是否准确、完整、专业。指出问题并给出改进建议。"
        user = f"上下文:\n{context}\n\n回复:\n{response}"
        return await self._call_llm(system, user)
