"""Agent Profile 系统 — Agent 配置文件管理

从 workspace 目录自动构建 AgentProfile，支持加载/保存。
读取 SOUL.md、IDENTITY.md、leaper.yaml 等文件。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import yaml


@dataclass
class AgentProfile:
    """Agent 配置文件"""
    name: str = ""
    role: str = "assistant"          # ceo-coach, cto, cfo, cpo, cmo...
    soul: str = ""                   # SOUL.md 内容
    workspace: str = ""              # workspace 路径
    model: str = ""                  # 使用的模型
    tools: list[str] = field(default_factory=list)      # 可用工具列表
    keywords: list[str] = field(default_factory=list)    # 路由关键词
    brain_namespace: str = ""        # brain 命名空间
    description: str = ""            # 简要描述
    identity: dict[str, str] = field(default_factory=dict)  # IDENTITY.md 解析结果


def load_profile(workspace_dir: str) -> AgentProfile:
    """从 workspace 目录加载 AgentProfile

    自动读取以下文件（如果存在）：
    - SOUL.md → soul 字段
    - IDENTITY.md → identity 字段（解析 key-value）
    - leaper.yaml / agent.yaml → 其他配置字段

    Args:
        workspace_dir: workspace 目录路径

    Returns:
        AgentProfile 实例
    """
    ws = Path(workspace_dir).expanduser()
    profile = AgentProfile(workspace=str(ws))

    # 读取 SOUL.md
    soul_path = ws / "SOUL.md"
    if soul_path.exists():
        profile.soul = soul_path.read_text(encoding="utf-8")

    # 解析 IDENTITY.md
    identity_path = ws / "IDENTITY.md"
    if identity_path.exists():
        profile.identity = _parse_identity(identity_path.read_text(encoding="utf-8"))
        profile.name = profile.identity.get("name", profile.identity.get("Name", ""))
        profile.role = profile.identity.get("role", profile.identity.get("Creature", "assistant"))

    # 读取 agent.yaml 或 leaper.yaml
    for yaml_name in ["agent.yaml", "leaper.yaml"]:
        yaml_path = ws / yaml_name
        if yaml_path.exists():
            _apply_yaml_config(profile, yaml_path)
            break

    # 如果 name 还是空，用目录名
    if not profile.name:
        profile.name = ws.name

    # 自动生成 brain_namespace
    if not profile.brain_namespace:
        profile.brain_namespace = f"agent/{profile.name}"

    return profile


def save_profile(profile: AgentProfile, workspace_dir: str) -> None:
    """保存 AgentProfile 到 workspace 目录

    生成 agent.yaml 文件（不覆盖 SOUL.md / IDENTITY.md）。

    Args:
        profile: AgentProfile 实例
        workspace_dir: workspace 目录路径
    """
    ws = Path(workspace_dir).expanduser()
    ws.mkdir(parents=True, exist_ok=True)

    # 保存到 agent.yaml
    config = {
        "name": profile.name,
        "role": profile.role,
        "model": profile.model,
        "tools": profile.tools,
        "keywords": profile.keywords,
        "brain_namespace": profile.brain_namespace,
        "description": profile.description,
    }
    yaml_path = ws / "agent.yaml"
    with open(yaml_path, "w", encoding="utf-8") as f:
        yaml.dump(config, f, allow_unicode=True, default_flow_style=False)


def build_profile_from_config(
    name: str,
    config: dict[str, Any],
    workspace_dir: str = "",
) -> AgentProfile:
    """从配置字典构建 AgentProfile

    Args:
        name: agent 名称
        config: 配置字典
        workspace_dir: workspace 路径

    Returns:
        AgentProfile 实例
    """
    return AgentProfile(
        name=name,
        role=config.get("role", "assistant"),
        soul=config.get("soul", ""),
        workspace=workspace_dir,
        model=config.get("model", ""),
        tools=config.get("tools", []),
        keywords=config.get("keywords", []),
        brain_namespace=config.get("brain_namespace", f"agent/{name}"),
        description=config.get("description", ""),
    )


# ── 内部函数 ──

def _parse_identity(content: str) -> dict[str, str]:
    """解析 IDENTITY.md 中的 key-value 对

    格式：
    - **Key:** Value
    或
    - Key: Value
    """
    result: dict[str, str] = {}
    for line in content.splitlines():
        line = line.strip()
        if not line.startswith("-"):
            continue
        line = line.lstrip("- ").strip()
        # 去掉 ** 标记
        line = line.replace("**", "")
        if ":" in line:
            key, _, value = line.partition(":")
            result[key.strip()] = value.strip()
    return result


def _apply_yaml_config(profile: AgentProfile, yaml_path: Path) -> None:
    """从 yaml 文件应用配置到 profile"""
    try:
        with open(yaml_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    except Exception:
        return

    if isinstance(cfg, dict):
        if "name" in cfg and not profile.name:
            profile.name = cfg["name"]
        if "role" in cfg:
            profile.role = cfg["role"]
        if "model" in cfg:
            profile.model = cfg["model"]
        if "tools" in cfg:
            profile.tools = cfg["tools"]
        if "keywords" in cfg:
            profile.keywords = cfg["keywords"]
        if "brain_namespace" in cfg:
            profile.brain_namespace = cfg["brain_namespace"]
        if "description" in cfg:
            profile.description = cfg["description"]

        # 嵌套在 agent 下的配置
        agent_cfg = cfg.get("agent", {})
        if isinstance(agent_cfg, dict):
            if "name" in agent_cfg and not profile.name:
                profile.name = agent_cfg["name"]
            if "model" in agent_cfg:
                profile.model = agent_cfg["model"]
