"""Seed Loader — 启动时加载 workspace 文件

参考 Hermes 的 leaper_seed_loader.py，加载 SOUL.md / IDENTITY.md 等
workspace 文件，组装为 system prompt 上下文。
"""
from __future__ import annotations

import os
import sys
import platform
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# 需要加载的 seed 文件列表
SEED_FILES = [
    "SOUL.md",
    "IDENTITY.md",
    "MEMORY.md",
    "TOOLS.md",
    "AGENTS.md",
    "USER.md",
    "HEARTBEAT.md",
]

# 必须存在的文件
REQUIRED_FILES = ["SOUL.md", "IDENTITY.md"]


class SeedLoader:
    """Workspace seed 文件加载器

    启动时扫描 workspace 目录，加载预定义的 .md 文件，
    并收集运行时环境信息，用于构建 agent system prompt。

    Args:
        workspace_dir: workspace 目录路径
    """

    def __init__(self, workspace_dir: str) -> None:
        self.workspace = Path(workspace_dir).expanduser().resolve()

    def load_all(self) -> Dict[str, Optional[str]]:
        """加载所有 seed 文件 + 运行时信息

        Returns:
            dict，key 为文件名（无后缀小写），value 为文件内容或 None
        """
        result: Dict[str, Optional[str]] = {}

        for filename in SEED_FILES:
            key = filename.replace(".md", "").lower()
            result[key] = self.load_file(filename)

        # 追加运行时信息
        result["os_info"] = self.get_os_info()
        result["runtime_info"] = self.get_runtime_info()

        loaded = [k for k, v in result.items() if v is not None]
        logger.info("SeedLoader: 加载了 %d 个 seed (%s)",
                     len(loaded), ", ".join(loaded))
        return result

    def load_file(self, filename: str) -> Optional[str]:
        """加载单个文件

        Args:
            filename: 文件名（相对于 workspace 目录）

        Returns:
            文件内容字符串，不存在返回 None
        """
        filepath = self.workspace / filename
        if not filepath.exists():
            logger.debug("Seed 文件不存在，跳过: %s", filepath)
            return None
        try:
            content = filepath.read_text(encoding="utf-8").strip()
            if not content:
                logger.debug("Seed 文件为空: %s", filepath)
                return None
            logger.debug("加载 seed: %s (%d 字符)", filename, len(content))
            return content
        except Exception as e:
            logger.warning("读取 seed 文件失败: %s — %s", filepath, e)
            return None

    def get_os_info(self) -> str:
        """动态检测 OS 信息"""
        return (f"OS: {platform.system()} {platform.release()} "
                f"({platform.machine()})\n"
                f"Version: {platform.version()}\n"
                f"Hostname: {platform.node()}")

    def get_runtime_info(self) -> str:
        """运行时信息：Python 版本、工作目录、时区"""
        py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

        # 检测时区
        try:
            tz_offset = datetime.now(timezone.utc).astimezone().strftime("%z")
            tz_name = datetime.now().astimezone().tzname() or "Unknown"
        except Exception:
            tz_offset = "+0000"
            tz_name = "UTC"

        return (f"Python: {py_ver}\n"
                f"Working Directory: {os.getcwd()}\n"
                f"Workspace: {self.workspace}\n"
                f"Timezone: {tz_name} ({tz_offset})\n"
                f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    def validate_workspace(self) -> List[str]:
        """验证 workspace 必要文件是否存在

        Returns:
            问题列表（空 = 全部通过）
        """
        issues: List[str] = []

        if not self.workspace.exists():
            issues.append(f"Workspace 目录不存在: {self.workspace}")
            return issues

        if not self.workspace.is_dir():
            issues.append(f"Workspace 路径不是目录: {self.workspace}")
            return issues

        for filename in REQUIRED_FILES:
            filepath = self.workspace / filename
            if not filepath.exists():
                issues.append(f"必要文件缺失: {filename}")

        return issues

    def build_system_context(self) -> str:
        """将所有 seed 组装为 system prompt 上下文

        Returns:
            格式化的上下文字符串
        """
        seeds = self.load_all()
        parts: List[str] = []

        # 按优先级排列
        order = ["soul", "identity", "user", "tools", "agents",
                 "memory", "heartbeat", "os_info", "runtime_info"]

        for key in order:
            content = seeds.get(key)
            if content:
                header = key.upper().replace("_", " ")
                parts.append(f"## {header}\n{content}")

        return "\n\n".join(parts)
