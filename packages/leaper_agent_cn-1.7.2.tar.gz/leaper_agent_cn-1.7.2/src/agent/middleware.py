"""中间件系统 — 请求/响应处理链

提供可插拔的中间件机制，用于请求预处理和响应后处理。
内置脱敏、日志、限流、缓存等中间件。
"""
from __future__ import annotations

import re
import time
import logging
import hashlib
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class Middleware:
    """中间件基类

    子类可覆盖 process_request / process_response。
    """

    @property
    def name(self) -> str:
        return self.__class__.__name__

    async def process_request(self, message: str,
                              context: Dict[str, Any]) -> str:
        """处理请求（默认透传）"""
        return message

    async def process_response(self, response: str,
                               context: Dict[str, Any]) -> str:
        """处理响应（默认透传）"""
        return response


class MiddlewareChain:
    """中间件链 — 按优先级顺序执行"""

    def __init__(self) -> None:
        # (priority, middleware)，priority 越小越先执行
        self._middlewares: List[Tuple[int, Middleware]] = []

    def add(self, middleware: Middleware, priority: int = 0) -> None:
        """添加中间件"""
        self._middlewares.append((priority, middleware))
        self._middlewares.sort(key=lambda x: x[0])
        logger.debug("添加中间件: %s (priority=%d)", middleware.name, priority)

    def remove(self, name: str) -> bool:
        """按名称移除中间件"""
        before = len(self._middlewares)
        self._middlewares = [(p, m) for p, m in self._middlewares
                             if m.name != name]
        return len(self._middlewares) < before

    @property
    def middlewares(self) -> List[str]:
        """已注册的中间件名称列表"""
        return [m.name for _, m in self._middlewares]

    async def run_request(self, message: str,
                          context: Dict[str, Any]) -> str:
        """执行请求中间件链"""
        for _, mw in self._middlewares:
            try:
                message = await mw.process_request(message, context)
            except Exception as e:
                logger.warning("中间件 %s 处理请求异常: %s", mw.name, e)
        return message

    async def run_response(self, response: str,
                           context: Dict[str, Any]) -> str:
        """执行响应中间件链（反序）"""
        for _, mw in reversed(self._middlewares):
            try:
                response = await mw.process_response(response, context)
            except Exception as e:
                logger.warning("中间件 %s 处理响应异常: %s", mw.name, e)
        return response


# ── 内置中间件 ──────────────────────────────────────


class RedactMiddleware(Middleware):
    """脱敏中间件 — 在响应中屏蔽敏感信息"""

    # 默认脱敏模式
    DEFAULT_PATTERNS = [
        # API key 格式: sk-xxx, ak-xxx
        (re.compile(r'\b(sk-|ak-|api[_-]?key[=:]\s*)[A-Za-z0-9]{8,}'),
         r'\1***'),
        # 手机号
        (re.compile(r'\b1[3-9]\d{9}\b'), '1**********'),
        # 邮箱局部脱敏
        (re.compile(r'(\w{2})\w+(@\w+\.\w+)'), r'\1***\2'),
        # 身份证号
        (re.compile(r'\b\d{6}(19|20)\d{2}(0[1-9]|1[0-2])\d{2}\d{3}[\dXx]\b'),
         '******'),
    ]

    def __init__(self, extra_patterns: Optional[List[Tuple[re.Pattern, str]]] = None) -> None:
        self._patterns = list(self.DEFAULT_PATTERNS)
        if extra_patterns:
            self._patterns.extend(extra_patterns)

    async def process_response(self, response: str,
                               context: Dict[str, Any]) -> str:
        """对响应进行脱敏"""
        for pattern, replacement in self._patterns:
            response = pattern.sub(replacement, response)
        return response


class LoggingMiddleware(Middleware):
    """日志中间件 — 记录请求/响应摘要"""

    def __init__(self, max_log_len: int = 200) -> None:
        self.max_log_len = max_log_len

    async def process_request(self, message: str,
                              context: Dict[str, Any]) -> str:
        preview = message[:self.max_log_len]
        logger.info("[请求] %s%s", preview,
                     "..." if len(message) > self.max_log_len else "")
        return message

    async def process_response(self, response: str,
                               context: Dict[str, Any]) -> str:
        preview = response[:self.max_log_len]
        logger.info("[响应] %s%s", preview,
                     "..." if len(response) > self.max_log_len else "")
        return response


class RateLimitMiddleware(Middleware):
    """限流中间件 — 简单滑动窗口限流"""

    def __init__(self, max_requests: int = 60,
                 window_seconds: float = 60.0) -> None:
        self.max_requests = max_requests
        self.window = window_seconds
        self._timestamps: List[float] = []

    async def process_request(self, message: str,
                              context: Dict[str, Any]) -> str:
        now = time.time()
        # 清理过期记录
        self._timestamps = [t for t in self._timestamps
                             if now - t < self.window]
        if len(self._timestamps) >= self.max_requests:
            from src.errors import RateLimitError
            raise RateLimitError(
                f"请求频率超限: {self.max_requests} 次/{self.window}秒",
                code="RATE_LIMIT",
            )
        self._timestamps.append(now)
        return message


class CacheMiddleware(Middleware):
    """缓存中间件 — 相同请求缓存响应"""

    def __init__(self, max_size: int = 100,
                 ttl_seconds: float = 300.0) -> None:
        self.max_size = max_size
        self.ttl = ttl_seconds
        # key -> (response, timestamp)
        self._cache: Dict[str, Tuple[str, float]] = {}

    def _make_key(self, message: str) -> str:
        """生成缓存 key"""
        return hashlib.md5(message.encode("utf-8")).hexdigest()

    async def process_request(self, message: str,
                              context: Dict[str, Any]) -> str:
        key = self._make_key(message)
        if key in self._cache:
            resp, ts = self._cache[key]
            if time.time() - ts < self.ttl:
                context["__cache_hit"] = True
                context["__cached_response"] = resp
                logger.debug("缓存命中: %s", key[:8])
        return message

    async def process_response(self, response: str,
                               context: Dict[str, Any]) -> str:
        # 如果是缓存命中，返回缓存
        if context.get("__cache_hit"):
            return context.get("__cached_response", response)

        # 缓存新响应
        msg = context.get("original_message", "")
        if msg:
            key = self._make_key(msg)
            self._cache[key] = (response, time.time())
            # 简单淘汰：超出限制删最旧的
            if len(self._cache) > self.max_size:
                oldest = min(self._cache, key=lambda k: self._cache[k][1])
                del self._cache[oldest]
        return response

    def clear(self) -> None:
        """清空缓存"""
        self._cache.clear()

    @property
    def size(self) -> int:
        return len(self._cache)
