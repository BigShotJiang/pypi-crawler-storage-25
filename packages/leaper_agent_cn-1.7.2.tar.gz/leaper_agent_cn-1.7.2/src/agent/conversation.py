"""对话历史管理器

管理 Agent 与用户之间的对话历史，支持 token 截断、持久化和摘要。
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Optional


class ConversationManager:
    """对话历史管理器

    功能：
    - 多角色消息管理（system / user / assistant / tool）
    - 工具调用记录
    - 按 token 数量截断旧消息
    - JSON 持久化（save / load）
    - 对话摘要
    """

    def __init__(self, max_turns: int = 100) -> None:
        self.messages: list[dict[str, Any]] = []
        self.max_turns = max_turns
        self._created_at: float = time.time()

    # ------------------------------------------------------------------
    # 添加消息
    # ------------------------------------------------------------------

    def add_message(self, role: str, content: str, **kwargs: Any) -> None:
        """添加一条消息

        Args:
            role: 角色 (system / user / assistant / tool)
            content: 消息内容
            **kwargs: 附加字段（如 name, tool_call_id 等）
        """
        msg: dict[str, Any] = {"role": role, "content": content}
        if kwargs:
            msg.update(kwargs)
        msg["_ts"] = time.time()
        self.messages.append(msg)
        self._enforce_max_turns()

    def add_tool_call(self, tool_name: str, args: dict, result: str) -> None:
        """添加一次工具调用记录（assistant 请求 + tool 响应）

        Args:
            tool_name: 工具名称
            args: 调用参数
            result: 工具返回结果
        """
        # assistant 的工具请求
        self.messages.append({
            "role": "assistant",
            "content": None,
            "tool_calls": [{
                "type": "function",
                "function": {"name": tool_name, "arguments": json.dumps(args, ensure_ascii=False)},
            }],
            "_ts": time.time(),
        })
        # tool 的响应
        self.messages.append({
            "role": "tool",
            "name": tool_name,
            "content": result,
            "_ts": time.time(),
        })
        self._enforce_max_turns()

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------

    def get_messages(self, max_tokens: Optional[int] = None) -> list[dict[str, Any]]:
        """获取消息列表

        如果指定 max_tokens，会从最新消息向前截断，保留 system 消息。

        Args:
            max_tokens: 最大 token 数（按字符估算：1 token ≈ 2 中文字 / 4 英文字符）

        Returns:
            消息列表（不含内部 _ts 字段）
        """
        if max_tokens is None:
            return self._strip_internal(self.messages)

        # 分离 system 消息和其余消息
        system_msgs = [m for m in self.messages if m.get("role") == "system"]
        other_msgs = [m for m in self.messages if m.get("role") != "system"]

        system_tokens = sum(self._estimate_tokens(m) for m in system_msgs)
        budget = max_tokens - system_tokens
        if budget <= 0:
            return self._strip_internal(system_msgs)

        # 从最新消息往前选取
        selected: list[dict] = []
        used = 0
        for msg in reversed(other_msgs):
            t = self._estimate_tokens(msg)
            if used + t > budget:
                break
            selected.append(msg)
            used += t
        selected.reverse()

        return self._strip_internal(system_msgs + selected)

    def get_last_n(self, n: int) -> list[dict[str, Any]]:
        """获取最近 n 条消息"""
        return self._strip_internal(self.messages[-n:])

    def get_summary(self) -> str:
        """获取对话摘要统计"""
        roles: dict[str, int] = {}
        for m in self.messages:
            r = m.get("role", "unknown")
            roles[r] = roles.get(r, 0) + 1
        total = len(self.messages)
        tokens = self.count_tokens()
        parts = [f"共 {total} 条消息, 约 {tokens} tokens"]
        for r, c in sorted(roles.items()):
            parts.append(f"  {r}: {c}")
        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Token 相关
    # ------------------------------------------------------------------

    def count_tokens(self) -> int:
        """估算当前对话的 token 数"""
        return sum(self._estimate_tokens(m) for m in self.messages)

    def trim_to_tokens(self, max_tokens: int) -> int:
        """截断到 token 限制，保留 system 消息

        Returns:
            移除的消息数
        """
        system_msgs = [m for m in self.messages if m.get("role") == "system"]
        other_msgs = [m for m in self.messages if m.get("role") != "system"]

        system_tokens = sum(self._estimate_tokens(m) for m in system_msgs)
        budget = max_tokens - system_tokens

        # 从最新往前保留
        keep: list[dict] = []
        used = 0
        for msg in reversed(other_msgs):
            t = self._estimate_tokens(msg)
            if used + t > budget:
                break
            keep.append(msg)
            used += t
        keep.reverse()

        removed = len(other_msgs) - len(keep)
        self.messages = system_msgs + keep
        return removed

    @staticmethod
    def _estimate_tokens(msg: dict) -> int:
        """简单 token 估算：中文 1字≈1.5token，英文 1词≈1token，取字符数/2"""
        content = msg.get("content") or ""
        if isinstance(content, list):
            content = str(content)
        extra = json.dumps(msg.get("tool_calls", []), ensure_ascii=False) if msg.get("tool_calls") else ""
        total_chars = len(content) + len(extra)
        return max(total_chars // 2, 1)

    # ------------------------------------------------------------------
    # 持久化
    # ------------------------------------------------------------------

    def save(self, path: str) -> None:
        """保存对话到 JSON 文件"""
        data = {
            "max_turns": self.max_turns,
            "created_at": self._created_at,
            "messages": self.messages,
        }
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def load(self, path: str) -> None:
        """从 JSON 文件加载对话"""
        p = Path(path)
        data = json.loads(p.read_text(encoding="utf-8"))
        self.max_turns = data.get("max_turns", 100)
        self._created_at = data.get("created_at", time.time())
        self.messages = data.get("messages", [])

    # ------------------------------------------------------------------
    # 管理
    # ------------------------------------------------------------------

    def clear(self) -> None:
        """清空所有消息"""
        self.messages.clear()

    def _enforce_max_turns(self) -> None:
        """强制最大轮次限制"""
        # 一轮 ≈ user + assistant = 2 条（tool 不算）
        non_system = [m for m in self.messages if m.get("role") != "system"]
        if len(non_system) > self.max_turns * 2:
            system_msgs = [m for m in self.messages if m.get("role") == "system"]
            keep = non_system[-(self.max_turns * 2):]
            self.messages = system_msgs + keep

    @staticmethod
    def _strip_internal(msgs: list[dict]) -> list[dict]:
        """移除内部字段（_ts 等）"""
        result = []
        for m in msgs:
            cleaned = {k: v for k, v in m.items() if not k.startswith("_")}
            result.append(cleaned)
        return result
