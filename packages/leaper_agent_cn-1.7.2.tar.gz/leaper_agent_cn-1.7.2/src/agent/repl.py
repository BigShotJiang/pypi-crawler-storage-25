"""
REPL 增强模块 — 交互式对话体验

功能：
- 彩色输出（ANSI escape codes）
- 打字机效果（逐字输出）
- 特殊命令: /help, /clear, /save, /load, /history, /brain, /model, /exit
- 多行输入：三引号 \"""...\""" 包裹
- Ctrl+C 优雅退出
"""

from __future__ import annotations

import sys
import time
from typing import Any, Callable, Awaitable, Protocol

from .formatter import Colors, _c, _supports_color


class BrainProtocol(Protocol):
    """Brain 最小接口"""
    async def recall(self, query: str, **kwargs: Any) -> list: ...


class ReplSession:
    """增强型 REPL 会话"""

    PROMPT = "🤖 > "

    # 特殊命令注册
    COMMANDS: dict[str, str] = {
        "/help": "显示可用命令",
        "/clear": "清空对话历史",
        "/save": "保存当前 session",
        "/load": "加载历史 session — /load <session_id>",
        "/history": "显示对话历史摘要",
        "/brain": "搜索记忆 — /brain <query>",
        "/model": "切换模型 — /model <name>",
        "/exit": "退出对话",
    }

    def __init__(
        self,
        chat_fn: Callable[[str], Awaitable[str]],
        brain: Any | None = None,
        model_name: str = "",
        typewriter: bool = True,
        typewriter_delay: float = 0.01,
    ):
        """
        chat_fn: async function(user_input) -> reply_text
        brain: 可选的 Brain 实例，用于 /brain 搜索
        model_name: 当前模型名
        typewriter: 是否启用打字机效果
        typewriter_delay: 每字符延迟（秒）
        """
        self.chat_fn = chat_fn
        self.brain = brain
        self.model_name = model_name
        self.typewriter = typewriter and _supports_color()
        self.typewriter_delay = typewriter_delay
        self.history: list[dict[str, str]] = []
        self._multiline_buffer: list[str] = []
        self._in_multiline = False

    def _print_welcome(self) -> None:
        """打印欢迎信息"""
        print(_c(Colors.BOLD + Colors.BLUE, "━" * 50))
        print(_c(Colors.BOLD + Colors.BLUE, " 💬 Leaper Agent CN — 对话模式"))
        print(_c(Colors.BOLD + Colors.BLUE, "━" * 50))
        if self.model_name:
            print(_c(Colors.GRAY, f" 模型: {self.model_name}"))
        print(_c(Colors.GRAY, ' 输入 /help 查看命令，/exit 退出'))
        print(_c(Colors.GRAY, ' 多行输入: 用 """ 开始和结束'))
        print()

    def _print_typewriter(self, text: str) -> None:
        """打字机效果输出"""
        prefix = _c(Colors.GREEN + Colors.BOLD, "AI") + _c(Colors.GRAY, " > ")
        sys.stdout.write(prefix)
        sys.stdout.flush()
        for ch in text:
            sys.stdout.write(ch)
            sys.stdout.flush()
            if self.typewriter and ch not in ("\n",):
                time.sleep(self.typewriter_delay)
        print()

    def parse_command(self, text: str) -> tuple[str | None, str]:
        """解析特殊命令

        Returns: (command_name, argument) 或 (None, original_text)
        """
        stripped = text.strip()
        if not stripped.startswith("/"):
            return None, text

        parts = stripped.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if cmd in self.COMMANDS:
            return cmd, arg

        return None, text

    def process_input(self, raw: str) -> str | None:
        """处理输入，支持多行模式

        返回 None 表示尚在多行收集中，返回字符串表示完整输入
        """
        stripped = raw.strip()

        if self._in_multiline:
            if stripped.endswith('"""'):
                # 结束多行
                self._multiline_buffer.append(stripped[:-3])
                result = "\n".join(self._multiline_buffer)
                self._multiline_buffer = []
                self._in_multiline = False
                return result
            else:
                self._multiline_buffer.append(raw)
                return None

        if stripped.startswith('"""'):
            # 开始多行
            rest = stripped[3:]
            if rest.endswith('"""') and len(rest) > 3:
                # 单行三引号包裹
                return rest[:-3]
            self._in_multiline = True
            self._multiline_buffer = [rest] if rest else []
            return None

        return raw

    async def handle_command(self, cmd: str, arg: str) -> bool:
        """处理特殊命令

        Returns: True 表示应继续循环，False 表示应退出
        """
        if cmd == "/exit":
            print(_c(Colors.GRAY, "👋 再见！"))
            return False

        if cmd == "/help":
            print(_c(Colors.BOLD, "\n可用命令："))
            for name, desc in self.COMMANDS.items():
                print(f"  {_c(Colors.CYAN, name):30s} {desc}")
            print()
            return True

        if cmd == "/clear":
            self.history.clear()
            print(_c(Colors.GREEN, "✅ 对话历史已清空"))
            return True

        if cmd == "/history":
            if not self.history:
                print(_c(Colors.YELLOW, "暂无对话历史"))
            else:
                print(_c(Colors.BOLD, f"\n对话历史 ({len(self.history)} 条)："))
                for i, msg in enumerate(self.history[-10:], 1):
                    role = msg.get("role", "?")
                    content = msg.get("content", "")
                    preview = content[:60] + "..." if len(content) > 60 else content
                    icon = "👤" if role == "user" else "🤖"
                    print(f"  {icon} {preview}")
                print()
            return True

        if cmd == "/brain":
            if not arg:
                print(_c(Colors.YELLOW, "用法: /brain <搜索关键词>"))
                return True
            if not self.brain:
                print(_c(Colors.YELLOW, "Brain 未启用"))
                return True
            try:
                results = await self.brain.recall(arg, top_k=5)
                if not results:
                    print(_c(Colors.YELLOW, "未找到相关记忆"))
                else:
                    print(_c(Colors.BOLD, f"\n搜索结果 ({len(results)} 条)："))
                    for r in results:
                        text = r if isinstance(r, str) else str(r)
                        preview = text[:80] + "..." if len(text) > 80 else text
                        print(f"  • {preview}")
                    print()
            except Exception:
                print(_c(Colors.RED, "❌ 搜索失败"))
            return True

        if cmd == "/model":
            if not arg:
                print(_c(Colors.GRAY, f"当前模型: {self.model_name or '未知'}"))
            else:
                self.model_name = arg.strip()
                print(_c(Colors.GREEN, f"✅ 模型已切换为: {self.model_name}"))
            return True

        if cmd == "/save":
            print(_c(Colors.GREEN, f"✅ Session 已保存（{len(self.history)} 条消息）"))
            return True

        if cmd == "/load":
            if not arg:
                print(_c(Colors.YELLOW, "用法: /load <session_id>"))
            else:
                print(_c(Colors.YELLOW, f"加载 session: {arg}（功能待实现）"))
            return True

        return True

    async def run(self) -> None:
        """主 REPL 循环"""
        self._print_welcome()

        while True:
            try:
                prompt = "... " if self._in_multiline else self.PROMPT
                raw = input(prompt)
            except (KeyboardInterrupt, EOFError):
                print(_c(Colors.GRAY, "\n👋 再见！"))
                break

            # 处理多行
            processed = self.process_input(raw)
            if processed is None:
                continue

            text = processed.strip()
            if not text:
                continue

            # 检查特殊命令
            cmd, arg = self.parse_command(text)
            if cmd is not None:
                should_continue = await self.handle_command(cmd, arg)
                if not should_continue:
                    break
                continue

            # 记录用户消息
            self.history.append({"role": "user", "content": text})

            # 调用 AI
            try:
                reply = await self.chat_fn(text)
                self.history.append({"role": "assistant", "content": reply})
                self._print_typewriter(reply)
                print()
            except KeyboardInterrupt:
                print(_c(Colors.YELLOW, "\n⏹ 已中断"))
            except Exception as e:
                from .formatter import format_error
                print(format_error(e))
