"""
Model Metadata - 模型能力与限制注册表

记录各国产模型的能力参数（max_tokens, 工具支持, 视觉支持, 成本等）。
仅包含国内模型/渠道，不引入海外模型。
"""

from __future__ import annotations

from typing import Any, Dict, Optional

# 国产模型注册表
MODEL_REGISTRY: Dict[str, Dict[str, Any]] = {
    # DeepSeek 系列
    "deepseek-chat": {
        "max_tokens": 128000,
        "supports_tools": True,
        "supports_vision": False,
        "cost_per_1k_input": 0.001,
        "cost_per_1k_output": 0.002,
        "provider": "deepseek",
    },
    "deepseek-v4-pro": {
        "max_tokens": 128000,
        "supports_tools": True,
        "supports_vision": True,
        "cost_per_1k_input": 0.01,
        "cost_per_1k_output": 0.02,
        "provider": "deepseek",
    },
    "deepseek-reasoner": {
        "max_tokens": 128000,
        "supports_tools": False,
        "supports_vision": False,
        "cost_per_1k_input": 0.004,
        "cost_per_1k_output": 0.016,
        "provider": "deepseek",
    },
    # 通义千问系列
    "qwen-turbo": {
        "max_tokens": 131072,
        "supports_tools": True,
        "supports_vision": False,
        "cost_per_1k_input": 0.0003,
        "cost_per_1k_output": 0.0006,
        "provider": "dashscope",
    },
    "qwen-plus": {
        "max_tokens": 131072,
        "supports_tools": True,
        "supports_vision": False,
        "cost_per_1k_input": 0.0008,
        "cost_per_1k_output": 0.002,
        "provider": "dashscope",
    },
    "qwen-max": {
        "max_tokens": 131072,
        "supports_tools": True,
        "supports_vision": True,
        "cost_per_1k_input": 0.004,
        "cost_per_1k_output": 0.012,
        "provider": "dashscope",
    },
    # 智谱 GLM 系列
    "glm-4-flash": {
        "max_tokens": 128000,
        "supports_tools": True,
        "supports_vision": False,
        "cost_per_1k_input": 0.0001,
        "cost_per_1k_output": 0.0001,
        "provider": "zhipu",
    },
    "glm-4": {
        "max_tokens": 128000,
        "supports_tools": True,
        "supports_vision": True,
        "cost_per_1k_input": 0.015,
        "cost_per_1k_output": 0.015,
        "provider": "zhipu",
    },
    # Moonshot 系列
    "moonshot-v1-8k": {
        "max_tokens": 8000,
        "supports_tools": True,
        "supports_vision": False,
        "cost_per_1k_input": 0.012,
        "cost_per_1k_output": 0.012,
        "provider": "moonshot",
    },
    "moonshot-v1-32k": {
        "max_tokens": 32000,
        "supports_tools": True,
        "supports_vision": False,
        "cost_per_1k_input": 0.024,
        "cost_per_1k_output": 0.024,
        "provider": "moonshot",
    },
    "moonshot-v1-128k": {
        "max_tokens": 128000,
        "supports_tools": True,
        "supports_vision": False,
        "cost_per_1k_input": 0.06,
        "cost_per_1k_output": 0.06,
        "provider": "moonshot",
    },
}

# 默认值（未知模型的 fallback）
_DEFAULT_MODEL_INFO: Dict[str, Any] = {
    "max_tokens": 8000,
    "supports_tools": False,
    "supports_vision": False,
    "cost_per_1k_input": 0.0,
    "cost_per_1k_output": 0.0,
    "provider": "unknown",
}


def get_model_info(model_name: str) -> Dict[str, Any]:
    """获取模型信息

    Args:
        model_name: 模型名称

    Returns:
        模型信息字典。未知模型返回默认值。
    """
    return MODEL_REGISTRY.get(model_name, _DEFAULT_MODEL_INFO.copy())


def get_max_tokens(model_name: str) -> int:
    """获取模型的最大 token 数

    Args:
        model_name: 模型名称

    Returns:
        最大 token 数，未知模型返回 8000
    """
    info = get_model_info(model_name)
    return info.get("max_tokens", 8000)


def supports_tools(model_name: str) -> bool:
    """检查模型是否支持工具调用

    Args:
        model_name: 模型名称

    Returns:
        True 表示支持工具调用
    """
    info = get_model_info(model_name)
    return bool(info.get("supports_tools", False))


def supports_vision(model_name: str) -> bool:
    """检查模型是否支持视觉输入

    Args:
        model_name: 模型名称

    Returns:
        True 表示支持视觉
    """
    info = get_model_info(model_name)
    return bool(info.get("supports_vision", False))


def list_models(provider: Optional[str] = None) -> list[str]:
    """列出所有已注册模型名称

    Args:
        provider: 可选，按 provider 过滤

    Returns:
        模型名称列表
    """
    if provider:
        return [
            name for name, info in MODEL_REGISTRY.items()
            if info.get("provider") == provider
        ]
    return list(MODEL_REGISTRY.keys())
