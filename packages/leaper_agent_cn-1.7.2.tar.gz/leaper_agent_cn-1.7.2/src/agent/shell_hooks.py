"""Shell Hooks - 命令执行前后的 hook 机制

提供 pre/post hook 用于：
- 危险命令拦截
- 输出截断
- 命令日志
- 错误分析
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Awaitable, Union


@dataclass
class HookResult:
    """Hook 执行结果"""
    allow: bool = True
    modified_command: Optional[str] = None
    warning: Optional[str] = None


@dataclass
class CommandRecord:
    """命令执行记录"""
    command: str
    cwd: str
    exit_code: Optional[int] = None
    output: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    duration: Optional[float] = None


# 类型: hook 函数可以是同步或异步
PreHookFn = Callable[[str, str], Union[HookResult, Awaitable[HookResult]]]
PostHookFn = Callable[[str, int, str], Union[None, Awaitable[None]]]


class ShellHooks:
    """命令执行 hook 管理器"""

    def __init__(self) -> None:
        self.pre_hooks: List[PreHookFn] = []
        self.post_hooks: List[PostHookFn] = []
        self.history: List[CommandRecord] = []
        self._max_history: int = 500

    def add_pre_hook(self, hook: PreHookFn) -> None:
        """添加前置 hook"""
        self.pre_hooks.append(hook)

    def add_post_hook(self, hook: PostHookFn) -> None:
        """添加后置 hook"""
        self.post_hooks.append(hook)

    async def run_pre_hooks(self, command: str, cwd: str) -> HookResult:
        """执行所有前置 hook，任何一个拒绝则整体拒绝"""
        import asyncio
        result = HookResult(allow=True)
        current_cmd = command
        warnings = []
        for hook in self.pre_hooks:
            r = hook(current_cmd, cwd)
            if asyncio.iscoroutine(r):
                r = await r
            if not r.allow:
                return r
            if r.modified_command:
                current_cmd = r.modified_command
            if r.warning:
                warnings.append(r.warning)
        result.modified_command = current_cmd if current_cmd != command else None
        result.warning = "; ".join(warnings) if warnings else None
        return result

    async def run_post_hooks(self, command: str, exit_code: int, output: str) -> None:
        """执行所有后置 hook"""
        import asyncio
        for hook in self.post_hooks:
            r = hook(command, exit_code, output)
            if asyncio.iscoroutine(r):
                await r

    def record(self, rec: CommandRecord) -> None:
        """记录命令"""
        self.history.append(rec)
        if len(self.history) > self._max_history:
            self.history = self.history[-self._max_history:]


# ── 内置 Hooks ──

# 危险命令正则
_DANGEROUS_PATTERNS = [
    re.compile(r"\brm\s+-[rf]{1,3}\s+/"),
    re.compile(r"\brm\s+-[rf]{1,3}\s+~"),
    re.compile(r"\bformat\s+[a-zA-Z]:", re.IGNORECASE),
    re.compile(r"\bdd\s+.*of=/dev/sd", re.IGNORECASE),
    re.compile(r"\bmkfs\b", re.IGNORECASE),
    re.compile(r"\bdel\s+/[sS]\s+/[qQ]\s+[A-Z]:\\", re.IGNORECASE),
    re.compile(r"\bRemove-Item\s+.*-Recurse.*[A-Z]:\\", re.IGNORECASE),
]


def dangerous_command_guard(command: str, cwd: str) -> HookResult:
    """拦截危险命令"""
    for pat in _DANGEROUS_PATTERNS:
        if pat.search(command):
            return HookResult(
                allow=False,
                warning=f"⚠️ 危险命令被拦截: {command}"
            )
    return HookResult(allow=True)


def output_truncator(command: str, exit_code: int, output: str) -> None:
    """截断过长输出（本函数不修改 output，仅作为示例；实际截断在调用方处理）"""
    pass


_command_log: List[CommandRecord] = []


def command_logger(command: str, cwd: str) -> HookResult:
    """记录命令（pre hook 形式，总是放行）"""
    _command_log.append(CommandRecord(command=command, cwd=cwd))
    if len(_command_log) > 1000:
        _command_log.pop(0)
    return HookResult(allow=True)


def get_command_log() -> List[CommandRecord]:
    """获取命令日志"""
    return list(_command_log)


# 常见错误模式 → 建议
_ERROR_SUGGESTIONS = {
    "command not found": "命令未找到，请检查 PATH 或安装对应工具",
    "permission denied": "权限不足，可能需要 sudo 或管理员权限",
    "no such file": "文件或目录不存在，请检查路径",
    "connection refused": "连接被拒绝，请检查服务是否启动",
    "out of memory": "内存不足，尝试关闭其他程序或增加内存",
    "disk full": "磁盘已满，请清理磁盘空间",
    "timeout": "操作超时，请检查网络或增加超时时间",
}


def error_analyzer(command: str, exit_code: int, output: str) -> None:
    """分析常见错误并记录建议（post hook）"""
    if exit_code == 0:
        return
    lower_output = output.lower()
    for pattern, suggestion in _ERROR_SUGGESTIONS.items():
        if pattern in lower_output:
            # 实际场景中这里可以写入日志或通知
            break


def truncate_output(output: str, max_lines: int = 200, max_chars: int = 50000) -> str:
    """工具函数：截断过长输出"""
    if len(output) > max_chars:
        output = output[:max_chars] + "\n... [输出过长，已截断]"
    lines = output.split("\n")
    if len(lines) > max_lines:
        head = lines[:50]
        tail = lines[-10:]
        output = "\n".join(head) + f"\n\n... [省略 {len(lines) - 60} 行] ...\n\n" + "\n".join(tail)
    return output


def create_default_hooks() -> ShellHooks:
    """创建带默认内置 hooks 的 ShellHooks 实例"""
    hooks = ShellHooks()
    hooks.add_pre_hook(dangerous_command_guard)
    hooks.add_pre_hook(command_logger)
    hooks.add_post_hook(error_analyzer)
    return hooks
