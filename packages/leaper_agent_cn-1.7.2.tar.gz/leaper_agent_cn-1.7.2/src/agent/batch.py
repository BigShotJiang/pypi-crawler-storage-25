"""BatchRunner — 批量任务执行引擎

支持串行/并行执行多条任务，错误隔离，进度回调，结果导出。
"""

from __future__ import annotations

import asyncio
import json
import csv
import logging
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .runner import AgentRunner

logger = logging.getLogger(__name__)


@dataclass
class BatchResult:
    """单个批量任务的执行结果"""
    task: str
    response: str = ""
    success: bool = False
    duration_ms: int = 0
    tokens_used: int = 0
    error: Optional[str] = None
    index: int = 0

    def to_dict(self) -> dict:
        """转为字典"""
        return asdict(self)


@dataclass
class BatchSummary:
    """批量执行的汇总统计"""
    total: int = 0
    success: int = 0
    failed: int = 0
    total_duration_ms: int = 0
    total_tokens: int = 0
    avg_duration_ms: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


class BatchRunner:
    """批量任务执行器

    支持串行和并行执行，错误隔离，进度回调。

    用法：
        runner = BatchRunner(agent_runner)
        results = await runner.run_batch(["任务1", "任务2"], concurrency=2)
        summary = runner.get_summary()
        runner.export_results("output.json")
    """

    def __init__(self, runner: AgentRunner):
        """初始化批量执行器

        Args:
            runner: AgentRunner 实例，用于执行单个任务
        """
        self.runner = runner
        self.results: List[BatchResult] = []
        self._running = False
        self._cancelled = False

    async def run_batch(
        self,
        tasks: List[str],
        concurrency: int = 1,
        on_progress: Optional[Callable[[int, int, BatchResult], Any]] = None,
    ) -> List[BatchResult]:
        """批量执行任务

        Args:
            tasks: 任务列表
            concurrency: 并发数，1 为串行
            on_progress: 进度回调 (completed, total, result)

        Returns:
            执行结果列表
        """
        if not tasks:
            return []

        if concurrency < 1:
            concurrency = 1

        self.results = []
        self._running = True
        self._cancelled = False

        total = len(tasks)
        completed = 0

        if concurrency == 1:
            # 串行执行
            for i, task in enumerate(tasks):
                if self._cancelled:
                    break
                result = await self._execute_single(task, i)
                self.results.append(result)
                completed += 1
                if on_progress:
                    try:
                        on_progress(completed, total, result)
                    except Exception:
                        pass
        else:
            # 并行执行，使用信号量控制并发
            semaphore = asyncio.Semaphore(concurrency)
            results_map: Dict[int, BatchResult] = {}

            async def _run_with_sem(idx: int, task: str) -> None:
                nonlocal completed
                if self._cancelled:
                    return
                async with semaphore:
                    if self._cancelled:
                        return
                    result = await self._execute_single(task, idx)
                    results_map[idx] = result
                    completed += 1
                    if on_progress:
                        try:
                            on_progress(completed, total, result)
                        except Exception:
                            pass

            await asyncio.gather(
                *[_run_with_sem(i, t) for i, t in enumerate(tasks)],
                return_exceptions=True,
            )

            # 按原始顺序排列结果
            for i in range(total):
                if i in results_map:
                    self.results.append(results_map[i])

        self._running = False
        return self.results

    async def run_from_file(
        self,
        file_path: str,
        concurrency: int = 1,
        on_progress: Optional[Callable[[int, int, BatchResult], Any]] = None,
    ) -> List[BatchResult]:
        """从文件读取任务列表执行

        文件格式：每行一个任务，空行和 # 开头的行会被跳过。

        Args:
            file_path: 任务文件路径
            concurrency: 并发数
            on_progress: 进度回调

        Returns:
            执行结果列表
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"任务文件不存在: {file_path}")

        tasks: List[str] = []
        text = path.read_text(encoding="utf-8")
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                tasks.append(line)

        if not tasks:
            return []

        return await self.run_batch(tasks, concurrency=concurrency, on_progress=on_progress)

    def cancel(self) -> None:
        """取消批量执行"""
        self._cancelled = True

    def export_results(self, path: str, format: str = "json") -> None:
        """导出结果到文件

        Args:
            path: 输出文件路径
            format: 导出格式，支持 "json" 和 "csv"
        """
        out_path = Path(path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        if format == "csv":
            self._export_csv(out_path)
        else:
            self._export_json(out_path)

    def _export_json(self, path: Path) -> None:
        """导出为 JSON"""
        data = {
            "summary": self.get_summary(),
            "results": [r.to_dict() for r in self.results],
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _export_csv(self, path: Path) -> None:
        """导出为 CSV"""
        if not self.results:
            path.write_text("", encoding="utf-8")
            return

        fieldnames = ["index", "task", "response", "success", "duration_ms", "tokens_used", "error"]
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in self.results:
                writer.writerow(r.to_dict())

    def get_summary(self) -> dict:
        """获取执行统计摘要"""
        total = len(self.results)
        success = sum(1 for r in self.results if r.success)
        failed = total - success
        total_duration = sum(r.duration_ms for r in self.results)
        total_tokens = sum(r.tokens_used for r in self.results)

        return BatchSummary(
            total=total,
            success=success,
            failed=failed,
            total_duration_ms=total_duration,
            total_tokens=total_tokens,
            avg_duration_ms=round(total_duration / total, 1) if total > 0 else 0.0,
        ).to_dict()

    async def _execute_single(self, task: str, index: int) -> BatchResult:
        """执行单个任务，错误隔离

        Args:
            task: 任务内容
            index: 任务索引

        Returns:
            BatchResult
        """
        start = time.monotonic()
        try:
            # 调用 AgentRunner 的 run_single 方法
            response = await self.runner.run_single(task)
            duration_ms = int((time.monotonic() - start) * 1000)

            # 尝试从 state 获取 token 使用量
            tokens = 0
            if hasattr(self.runner, "state") and self.runner.state:
                tokens = getattr(self.runner.state, "total_tokens", 0)

            return BatchResult(
                task=task,
                response=response if isinstance(response, str) else str(response),
                success=True,
                duration_ms=duration_ms,
                tokens_used=tokens,
                error=None,
                index=index,
            )
        except Exception as e:
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.warning(f"批量任务 #{index} 执行失败: {e}")
            return BatchResult(
                task=task,
                response="",
                success=False,
                duration_ms=duration_ms,
                tokens_used=0,
                error=str(e),
                index=index,
            )
