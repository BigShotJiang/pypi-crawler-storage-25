"""API 调用限流器 — 滑动窗口计数器，预防 429。

简单实现：跟踪最近 N 秒内的调用次数，超限时等待。
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

logger = logging.getLogger(__name__)


class RateLimiter:
    """滑动窗口限流器。

    Args:
        max_calls: 窗口内最大调用次数。
        window_seconds: 窗口大小（秒）。
    """

    def __init__(self, max_calls: int = 30, window_seconds: float = 60.0):
        self.max_calls = max_calls
        self.window_seconds = window_seconds
        self._timestamps: list[float] = []

    def _cleanup(self) -> None:
        """清理过期的时间戳。"""
        cutoff = time.monotonic() - self.window_seconds
        # 找到第一个未过期的位置
        i = 0
        while i < len(self._timestamps) and self._timestamps[i] < cutoff:
            i += 1
        if i > 0:
            self._timestamps = self._timestamps[i:]

    def check_rate_limit(self) -> bool:
        """检查是否可以调用。

        Returns:
            True 表示可以调用，False 表示超限。
        """
        self._cleanup()
        return len(self._timestamps) < self.max_calls

    def record_call(self) -> None:
        """记录一次调用。"""
        self._timestamps.append(time.monotonic())

    def seconds_until_available(self) -> float:
        """返回需要等待的秒数（0 表示可以立即调用）。"""
        self._cleanup()
        if len(self._timestamps) < self.max_calls:
            return 0.0
        # 最早的时间戳过期后即可调用
        oldest = self._timestamps[0]
        wait = (oldest + self.window_seconds) - time.monotonic()
        return max(0.0, wait)

    async def wait_if_needed(self) -> None:
        """如果超限，异步等待直到可以调用。"""
        wait = self.seconds_until_available()
        if wait > 0:
            logger.info("限流等待 %.1f 秒", wait)
            await asyncio.sleep(wait)

    @property
    def current_count(self) -> int:
        """当前窗口内的调用次数。"""
        self._cleanup()
        return len(self._timestamps)
