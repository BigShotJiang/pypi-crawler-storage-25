"""对话历史压缩器 — 超出 token 限制时自动压缩。

策略：保留最新 N 轮 + 摘要老对话。
参考 Hermes context_compressor.py 的简化版。
"""

from __future__ import annotations

import logging
from typing import List, Optional, Union

logger = logging.getLogger(__name__)

# ── Token 估算 ──────────────────────────────────────────────────────────

def _is_chinese(ch: str) -> bool:
    """判断字符是否为中文"""
    cp = ord(ch)
    return (0x4E00 <= cp <= 0x9FFF or 0x3400 <= cp <= 0x4DBF
            or 0x20000 <= cp <= 0x2A6DF or 0xF900 <= cp <= 0xFAFF)


def estimate_tokens(text: str) -> int:
    """估算 token 数：中文约 1 字 ≈ 2 token，英文约 4 字符 ≈ 1 token。"""
    if not text:
        return 0
    chinese_count = sum(1 for ch in text if _is_chinese(ch))
    other_count = len(text) - chinese_count
    return chinese_count * 2 + other_count // 4


def estimate_messages_tokens(messages: List[dict]) -> int:
    """估算消息列表的总 token 数。"""
    total = 0
    for msg in messages:
        content = msg.get("content") or ""
        if isinstance(content, str):
            total += estimate_tokens(content)
        # tool_calls 也占 token
        tool_calls = msg.get("tool_calls")
        if tool_calls:
            total += estimate_tokens(str(tool_calls))
        # 每条消息的 role/metadata 开销 ~4 token
        total += 4
    return total


# ── 压缩策略 ──────────────────────────────────────────────────────────

_SUMMARY_TEMPLATE = "[对话摘要] 之前有 {count} 条消息被压缩。主要内容：{topics}"


def _extract_topics(messages: List[dict], max_topics: int = 5) -> str:
    """从消息中提取关键话题（简单实现：取 user 消息前 50 字符）。"""
    topics: list[str] = []
    for msg in messages:
        if msg.get("role") == "user" and msg.get("content"):
            text = msg["content"][:50].replace("\n", " ")
            topics.append(text)
            if len(topics) >= max_topics:
                break
    return "；".join(topics) if topics else "（无法提取）"


def compress_if_needed(
    messages: List[dict],
    max_tokens: int = 100000,
    keep_recent: int = 20,
    system_roles: Optional[set] = None,
) -> List[dict]:
    """如果消息列表 token 数超出限制，压缩老消息。

    Args:
        messages: 完整消息列表（含 system/user/assistant/tool）。
        max_tokens: token 上限。
        keep_recent: 保留最近多少条非 system 消息。
        system_roles: 被视为 system 消息的角色集合，默认 {"system"}。

    Returns:
        压缩后的消息列表。如果未超限，返回原列表。
    """
    if system_roles is None:
        system_roles = {"system"}

    current_tokens = estimate_messages_tokens(messages)
    if current_tokens <= max_tokens:
        return messages

    logger.info("对话 token 数 %d 超出限制 %d，开始压缩", current_tokens, max_tokens)

    # 分离 system 消息和对话消息
    system_msgs: list[dict] = []
    conversation_msgs: list[dict] = []
    for msg in messages:
        if msg.get("role") in system_roles:
            system_msgs.append(msg)
        else:
            conversation_msgs.append(msg)

    if len(conversation_msgs) <= keep_recent:
        # 对话消息本身就不多，无法再压缩
        return messages

    # 保留最近 keep_recent 条，压缩更早的
    old_msgs = conversation_msgs[:-keep_recent]
    recent_msgs = conversation_msgs[-keep_recent:]

    # 生成摘要
    topics = _extract_topics(old_msgs)
    summary = _SUMMARY_TEMPLATE.format(count=len(old_msgs), topics=topics)
    summary_msg = {"role": "system", "content": summary}

    result = system_msgs + [summary_msg] + recent_msgs
    new_tokens = estimate_messages_tokens(result)
    logger.info("压缩完成：%d → %d token（移除 %d 条消息）",
                current_tokens, new_tokens, len(old_msgs))
    return result
