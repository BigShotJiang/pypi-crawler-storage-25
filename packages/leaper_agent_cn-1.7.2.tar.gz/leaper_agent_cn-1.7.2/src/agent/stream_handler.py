"""流式响应处理器

处理 LLM 流式响应，支持逐 chunk 处理、工具调用检测和 token 用量统计。
参考 leaper-python/gateway/stream_consumer.py 的设计。
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable, Optional


@dataclass
class StreamResult:
    """流式响应结果"""
    text: str = ""
    tool_calls: list[dict] = field(default_factory=list)
    usage: dict = field(default_factory=dict)
    duration_ms: float = 0.0
    chunk_count: int = 0
    finish_reason: str = ""


class StreamHandler:
    """LLM 流式响应处理器

    支持：
    - 逐 chunk 文本拼接
    - 工具调用（tool_call）检测与解析
    - on_chunk 回调（用于实时显示）
    - token 用量收集
    """

    def __init__(self) -> None:
        self.chunks: list[str] = []
        self.tool_calls: list[dict] = []
        self.is_complete: bool = False
        self._usage: dict = {}
        self._finish_reason: str = ""
        # 工具调用增量拼接缓冲
        self._pending_tool_calls: dict[int, dict] = {}

    # ------------------------------------------------------------------
    # 核心方法
    # ------------------------------------------------------------------

    async def process_stream(
        self,
        stream: AsyncIterator[dict[str, Any]],
        on_chunk: Optional[Callable[[str], None]] = None,
    ) -> StreamResult:
        """处理 LLM 流式响应

        Args:
            stream: 异步迭代器，每个元素为一个 SSE chunk（dict）
            on_chunk: 可选回调，每当收到文本 chunk 时调用

        Returns:
            StreamResult: 完整的流式响应结果
        """
        start = time.monotonic()
        chunk_count = 0

        async for chunk in stream:
            chunk_count += 1
            self._handle_chunk(chunk, on_chunk)

        self.is_complete = True
        duration_ms = (time.monotonic() - start) * 1000

        # 合并未完成的工具调用
        self._finalize_tool_calls()

        return StreamResult(
            text=self.get_text(),
            tool_calls=self.get_tool_calls(),
            usage=self.get_usage(),
            duration_ms=round(duration_ms, 2),
            chunk_count=chunk_count,
            finish_reason=self._finish_reason,
        )

    def _handle_chunk(
        self, chunk: dict[str, Any], on_chunk: Optional[Callable[[str], None]]
    ) -> None:
        """处理单个 chunk"""
        # 兼容 OpenAI 格式的 choices
        choices = chunk.get("choices", [])
        if not choices:
            # 顶层 usage（部分 provider 在最后一个 chunk 返回）
            if "usage" in chunk:
                self._merge_usage(chunk["usage"])
            return

        choice = choices[0]
        delta = choice.get("delta", {})
        finish = choice.get("finish_reason")

        # 文本内容
        content = delta.get("content")
        if content:
            self.chunks.append(content)
            if on_chunk:
                on_chunk(content)

        # 工具调用增量
        tc_deltas = delta.get("tool_calls", [])
        for tc in tc_deltas:
            self._accumulate_tool_call(tc)

        # 结束原因
        if finish:
            self._finish_reason = finish

        # usage
        if "usage" in chunk:
            self._merge_usage(chunk["usage"])

    def _accumulate_tool_call(self, tc_delta: dict) -> None:
        """增量拼接工具调用"""
        idx = tc_delta.get("index", 0)
        if idx not in self._pending_tool_calls:
            self._pending_tool_calls[idx] = {
                "id": tc_delta.get("id", ""),
                "type": tc_delta.get("type", "function"),
                "function": {"name": "", "arguments": ""},
            }
        pending = self._pending_tool_calls[idx]

        fn = tc_delta.get("function", {})
        if "name" in fn and fn["name"]:
            pending["function"]["name"] += fn["name"]
        if "arguments" in fn:
            pending["function"]["arguments"] += fn["arguments"]
        if tc_delta.get("id"):
            pending["id"] = tc_delta["id"]

    def _finalize_tool_calls(self) -> None:
        """将增量缓冲合并为最终工具调用列表"""
        for idx in sorted(self._pending_tool_calls):
            tc = self._pending_tool_calls[idx]
            # 尝试解析 arguments JSON
            args_str = tc["function"]["arguments"]
            try:
                tc["function"]["arguments_parsed"] = json.loads(args_str)
            except (json.JSONDecodeError, TypeError):
                tc["function"]["arguments_parsed"] = {}
            self.tool_calls.append(tc)

    def _merge_usage(self, usage: dict) -> None:
        """合并 usage 信息"""
        for k, v in usage.items():
            if isinstance(v, (int, float)):
                self._usage[k] = self._usage.get(k, 0) + v
            else:
                self._usage[k] = v

    # ------------------------------------------------------------------
    # 查询方法
    # ------------------------------------------------------------------

    def get_text(self) -> str:
        """获取完整文本"""
        return "".join(self.chunks)

    def get_tool_calls(self) -> list[dict]:
        """获取工具调用列表"""
        return list(self.tool_calls)

    def get_usage(self) -> dict:
        """获取 token 使用量"""
        return dict(self._usage)

    def reset(self) -> None:
        """重置状态，可复用"""
        self.chunks.clear()
        self.tool_calls.clear()
        self.is_complete = False
        self._usage.clear()
        self._finish_reason = ""
        self._pending_tool_calls.clear()
