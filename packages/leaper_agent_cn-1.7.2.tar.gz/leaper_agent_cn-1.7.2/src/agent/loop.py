"""
AgentLoop - 核心对话循环

负责：
1. 接收用户消息
2. 调用 provider 获取 LLM 响应
3. 处理 tool_calls 并循环
4. 注入记忆上下文（recall）
5. 后台异步提取知识（extract_and_learn）
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, Callable, Protocol

try:
    from ..providers.base import Message, Response
except ImportError:
    from providers.base import Message, Response

try:
    from ..tools.base import Tool
except ImportError:
    from tools.base import Tool

from .onboarding import OnboardingManager
from .session import SessionManager
from .context import ContextEngine
from .compressor import compress_if_needed
from .error_classifier import classify_error
from .rate_limiter import RateLimiter
from .retry import retry_with_backoff
from . import context_engine as ctx_engine_mod
from . import insights as insights_mod
from . import model_meta
from .credential_pool import CredentialPool, AllCredentialsExhausted


class Provider(Protocol):
    """LLM Provider 协议 - 支持返回 Response 对象或 dict"""
    async def chat(self, messages: list[Message], tools: list[dict] | None = None) -> Response: ...


class Brain(Protocol):
    """Brain 记忆协议 - 兼容 core.py 和 engine.py 的 LeaperBrain"""
    async def recall(self, query: str, top_k: int = 5) -> list[dict]: ...
    async def extract_and_learn(self, user_msg: str, assistant_msg: str) -> None: ...


class AgentLoop:
    """核心 Agent 对话循环"""

    def __init__(
        self,
        provider: Provider,
        brain: Brain | None = None,
        tools: dict[str, Any] | None = None,
        system_prompt: str = "",
        workspace_dir: str = "",
        agent_id: str = "default",
        user_id: str = "default",
        skill_manager=None,
        model_name: str = "",
        api_keys: list[str] | None = None,
    ):
        self.provider = provider
        self.brain = brain
        # tools 支持 {name: Tool} 或 {name: Callable}，统一存储
        self.tools = tools or {}
        self.system_prompt = system_prompt
        self.workspace_dir = workspace_dir
        self.skill_manager = skill_manager  # SkillManager 实例
        self._history: list[dict] = []
        self._onboarding = OnboardingManager(brain, workspace_dir)
        self._agent_id = agent_id
        self._user_id = user_id
        self._rate_limiter = RateLimiter(max_calls=30, window_seconds=60.0)

        # session + context engine（brain 可用时启用持久化）
        self._session_manager: SessionManager | None = None
        self._context_engine: ContextEngine | None = None
        self._session_id: str | None = None

        # 路线 D 增强：model_meta + credential_pool + insights
        self._model_name = model_name
        self._model_max_tokens = model_meta.get_max_tokens(model_name) if model_name else 100000
        self._credential_pool: CredentialPool | None = None
        if api_keys and len(api_keys) > 1:
            self._credential_pool = CredentialPool(api_keys)
        self._turn_count = 0
        self._loop_check_interval = 5  # 每 5 轮检查一次死循环

    async def _ensure_session(self) -> str | None:
        """确保 session 已初始化（懒加载）"""
        if self._session_id:
            return self._session_id
        if not self.brain or not hasattr(self.brain, "db"):
            return None
        try:
            if self._session_manager is None:
                self._session_manager = SessionManager(self.brain)
                await self._session_manager.ensure_tables()
                self._context_engine = ContextEngine(
                    self.brain, self._session_manager, self.workspace_dir
                )
            self._session_id = await self._session_manager.get_or_create(
                self._agent_id, self._user_id
            )
            return self._session_id
        except Exception:
            return None

    async def _recall_memories(self, query: str) -> str:
        """调用 brain.recall 获取相关记忆，graceful fallback"""
        if not self.brain or not hasattr(self.brain, "recall"):
            return ""
        try:
            # 先尝试位置参数 + limit（兼容 engine.py 和测试 mock）
            memories = await self.brain.recall(query)
        except TypeError:
            try:
                memories = await self.brain.recall(query=query, limit=5)
            except Exception:
                return ""
        except Exception:
            return ""

        if not memories:
            return ""

        # 格式化：上限 5 条，每条截断 200 字符
        lines: list[str] = []
        for entry in memories[:5]:
            # 兼容 dict 或 str
            if isinstance(entry, dict):
                text = entry.get("content", "") or entry.get("text", "") or str(entry)
            else:
                text = str(entry)
            if len(text) > 200:
                text = text[:200] + "…"
            lines.append(f"- {text}")

        if not lines:
            return ""
        return "[相关记忆]\n" + "\n".join(lines)

    async def _safe_extract(self, user_msg: str, content: str):
        """安全地后台提取知识，异常静默失败不影响用户"""
        try:
            await self.brain.extract_and_learn(user_msg, content)
        except Exception:
            pass  # 静默失败，不影响用户

    def _normalize_response(self, response) -> dict:
        """将 Response 对象或 dict 统一为 dict 格式（兼容层）"""
        if isinstance(response, Response):
            return {
                "content": response.content,
                "tool_calls": response.tool_calls,
                "finish_reason": response.finish_reason,
            }
        # 已经是 dict（兼容旧测试）
        return response

    def _to_messages(self, dicts: list[dict]) -> list[Message]:
        """将内部 dict 格式消息列表转为 Message 对象列表，传给 provider"""
        result = []
        for d in dicts:
            result.append(Message(
                role=d["role"],
                content=d.get("content"),
                tool_calls=d.get("tool_calls"),
                tool_call_id=d.get("tool_call_id"),
                name=d.get("name"),
            ))
        return result

    async def chat(self, user_message: str) -> str:
        """处理一次用户消息，返回助手回复"""
        # 尝试启用持久化 session
        session_id = await self._ensure_session()

        # 持久化模式：用 ContextEngine 构建 context
        if session_id and self._session_manager and self._context_engine:
            return await self._chat_with_session(user_message, session_id)

        # 回退到原始 in-memory 模式
        return await self._chat_in_memory(user_message)

    async def _chat_with_session(self, user_message: str, session_id: str) -> str:
        """持久化模式的对话处理"""
        sm = self._session_manager
        ce = self._context_engine

        # 1. 持久化用户消息
        await sm.add_message(session_id, "user", user_message)

        # 2. 构建 context
        onboarding_needed = await self._onboarding.async_needs_onboarding()
        onboarding_prompt = ""
        if onboarding_needed:
            onboarding_prompt = self._onboarding.get_onboarding_prompt() or ""

        messages = await ce.build_context(
            session_id, user_message,
            system_prompt=self.system_prompt,
            onboarding_prompt=onboarding_prompt,
        )

        # 也同步到 in-memory history（兼容 onboarding 检查等）
        self._history.append({"role": "user", "content": user_message})

        # 工具定义
        tool_defs = self._build_tool_defs()

        # 循环处理 tool_calls
        content = await self._run_tool_loop(messages, tool_defs, onboarding_needed, user_message)

        # 每 N 轮检查死循环
        self._turn_count += 1
        if self._turn_count % self._loop_check_interval == 0:
            if insights_mod.detect_loop(self._history):
                content += "\n\n⚠️ 检测到可能的循环调用，建议调整策略。"

        # 4. 持久化助手回复
        await sm.add_message(session_id, "assistant", content)

        # 5. 后台知识提取
        if self.brain and hasattr(self.brain, "extract_and_learn"):
            asyncio.create_task(self._safe_extract(user_message, content))

        return content

    async def _chat_in_memory(self, user_message: str) -> str:
        """原始 in-memory 模式（无 brain.db 时的回退）"""
        # 历史长度限制：超过 80 条消息（40 轮）截断保留最近 40 条（20 轮）
        if len(self._history) > 80:
            self._history = self._history[-40:]

        # 冷启动引导检查
        onboarding_needed = await self._onboarding.async_needs_onboarding()

        # 记忆召回注入
        memory_context = await self._recall_memories(user_message)

        # 构建消息列表（内部用 dict，传给 provider 前转 Message）
        messages = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        if onboarding_needed:
            onboarding_prompt = self._onboarding.get_onboarding_prompt()
            if onboarding_prompt:
                messages.append({"role": "system", "content": onboarding_prompt})
        if memory_context:
            messages.append({"role": "system", "content": memory_context})
        messages.extend(self._history)
        messages.append({"role": "user", "content": user_message})

        self._history.append({"role": "user", "content": user_message})

        tool_defs = self._build_tool_defs()

        # 循环处理 tool_calls
        content = await self._run_tool_loop(messages, tool_defs, onboarding_needed, user_message)

        # 后台异步提取知识（不阻塞回复）
        if self.brain and hasattr(self.brain, "extract_and_learn"):
            asyncio.create_task(self._safe_extract(user_message, content))
        return content

    def _build_tool_defs(self) -> list[dict] | None:
        """构建工具定义列表（含 skill_manager 的技能）"""
        tool_defs = []
        for k, v in (self.tools or {}).items():
            if isinstance(v, Tool):
                tool_defs.append({
                    "type": "function",
                    "function": {
                        "name": v.name,
                        "description": v.description,
                        "parameters": v.parameters,
                    },
                })
            else:
                tool_defs.append({"type": "function", "function": {"name": k}})
        # 注入 skill_manager 的技能
        if self.skill_manager:
            tool_defs.extend(self.skill_manager.to_tool_defs())
        return tool_defs if tool_defs else None

    async def _run_tool_loop(
        self, messages: list[dict], tool_defs: list[dict] | None,
        onboarding_needed: bool, user_message: str,
    ) -> str:
        """循环处理 tool_calls，返回最终文本回复"""
        # 压缩对话历史（超限时自动压缩）
        messages = compress_if_needed(messages, max_tokens=self._model_max_tokens, keep_recent=20)

        max_rounds = 10
        for _ in range(max_rounds):
            # 限流检查
            await self._rate_limiter.wait_if_needed()
            self._rate_limiter.record_call()

            # 带重试的 API 调用
            try:
                raw_response = await retry_with_backoff(
                    self.provider.chat,
                    self._to_messages(messages),
                    tools=tool_defs,
                    max_retries=2,
                )
            except Exception as exc:
                error_info = classify_error(exc)
                if error_info.should_compress:
                    messages = compress_if_needed(messages, max_tokens=50000, keep_recent=10)
                    raw_response = await self.provider.chat(self._to_messages(messages), tools=tool_defs)
                else:
                    raise
            response = self._normalize_response(raw_response)

            if not response.get("tool_calls"):
                content = response.get("content", "") or ""
                self._history.append({"role": "assistant", "content": content})

                if onboarding_needed and self._onboarding.check_onboarding_complete(self._history):
                    user_info = await self._onboarding.extract_user_info(self._history)
                    if user_info:
                        await self._onboarding.complete_onboarding(user_info)

                return content

            assistant_msg = {"role": "assistant", "tool_calls": response["tool_calls"]}
            messages.append(assistant_msg)
            self._history.append(assistant_msg)

            for tc in response["tool_calls"]:
                func_name = tc["function"]["name"]
                func_args_raw = tc["function"].get("arguments", {})
                if isinstance(func_args_raw, str):
                    try:
                        func_args = json.loads(func_args_raw) if func_args_raw else {}
                    except json.JSONDecodeError:
                        func_args = {}
                else:
                    func_args = func_args_raw
                if func_name in self.tools:
                    tool_or_fn = self.tools[func_name]
                    if isinstance(tool_or_fn, Tool):
                        result = await tool_or_fn.execute(func_args)
                    elif asyncio.iscoroutinefunction(tool_or_fn):
                        result = await tool_or_fn(**func_args)
                    else:
                        result = tool_or_fn(**func_args)
                elif self.skill_manager and func_name in [s.name for s in self.skill_manager.get_all_skills()]:
                    result = await self.skill_manager.execute_skill(func_name, func_args)
                else:
                    result = f"工具 {func_name} 不存在"
                tool_msg = {
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": str(result),
                }
                messages.append(tool_msg)
                self._history.append(tool_msg)

        return "达到最大工具调用轮数"
