"""
MultiAgentManager - 多 Agent 管理器

支持一个进程内运行多个 Agent（不同角色），通过消息路由到对应 Agent。
Agent 之间共享 Brain 数据库（同一个 db 文件，用 agent_id 隔离）。
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from .loop import AgentLoop

logger = logging.getLogger(__name__)


class MultiAgentManager:
    """多 Agent 管理器：一个进程内运行多个 Agent"""

    def __init__(self, config_dir: str = "~/.leaper-cn"):
        """扫描 workspaces 目录下所有 Agent

        Args:
            config_dir: 配置根目录，包含 leaper.yaml 和 workspaces/
        """
        self.config_dir = Path(config_dir).expanduser()
        self.workspaces_dir = self.config_dir / "workspaces"
        self._agents: dict[str, AgentLoop] = {}  # 懒加载缓存
        self._agent_configs: dict[str, dict] = {}  # agent 名 → 配置信息
        self._global_config: dict = {}
        self._load_config()
        self._scan_agents()

    def _load_config(self) -> None:
        """加载全局配置"""
        config_path = self.config_dir / "leaper.yaml"
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                self._global_config = yaml.safe_load(f) or {}

    def _scan_agents(self) -> None:
        """扫描 workspaces 目录下所有 Agent"""
        if not self.workspaces_dir.exists():
            logger.warning(f"workspaces 目录不存在: {self.workspaces_dir}")
            return

        for ws_path in self.workspaces_dir.iterdir():
            if not ws_path.is_dir():
                continue
            # 检查是否有 agent.yaml 配置
            agent_yaml = ws_path / "agent.yaml"
            if agent_yaml.exists():
                with open(agent_yaml, "r", encoding="utf-8") as f:
                    agent_cfg = yaml.safe_load(f) or {}
            else:
                # 没有 agent.yaml，用目录名作为 agent 名
                agent_cfg = {}

            name = agent_cfg.get("name", ws_path.name)
            self._agent_configs[name] = {
                "name": name,
                "role": agent_cfg.get("role", "assistant"),
                "workspace": str(ws_path),
                "config": agent_cfg,
            }

    def list_agents(self) -> list[dict]:
        """列出所有已创建的 Agent（名称、角色、workspace 路径）

        Returns:
            包含 name, role, workspace 字段的字典列表
        """
        return [
            {"name": info["name"], "role": info["role"], "workspace": info["workspace"]}
            for info in self._agent_configs.values()
        ]

    def get_agent(self, name: str) -> AgentLoop:
        """获取指定 Agent 的 loop 实例（懒加载）

        Args:
            name: Agent 名称

        Returns:
            AgentLoop 实例

        Raises:
            KeyError: Agent 不存在
        """
        if name not in self._agent_configs:
            raise KeyError(f"Agent 不存在: {name}")

        # 懒加载：只有收到消息时才创建 AgentLoop
        if name not in self._agents:
            self._agents[name] = self._create_agent(name)

        return self._agents[name]

    def _create_agent(self, name: str) -> AgentLoop:
        """创建 AgentLoop 实例

        共享 Brain 数据库，用 agent_id 隔离数据。
        """
        info = self._agent_configs[name]
        ws_path = Path(info["workspace"])

        # 读取 system prompt（从 workspace 的 SOUL.md）
        system_prompt = ""
        soul_file = ws_path / "SOUL.md"
        if soul_file.exists():
            system_prompt = soul_file.read_text(encoding="utf-8")

        # 创建 provider（从全局配置）
        provider = self._create_provider()

        # 创建 Brain（共享 db，用 agent_id 隔离）
        brain = self._create_brain(agent_id=name)

        loop = AgentLoop(
            provider=provider,
            brain=brain,
            system_prompt=system_prompt,
            workspace_dir=str(ws_path),
        )
        logger.info(f"Agent 已创建: {name} (role={info['role']})")
        return loop

    def _create_provider(self):
        """从全局配置创建 provider"""
        from ..providers import create_provider

        provider_cfg = self._global_config.get("provider", {})
        provider_name = provider_cfg.get("name", "deepseek")
        return create_provider(provider_name, {
            "api_key": provider_cfg.get("api_key", ""),
            "model": provider_cfg.get("model", ""),
        })

    def _create_brain(self, agent_id: str):
        """创建共享 Brain 实例，用 agent_id 隔离数据"""
        from ..brain.engine import LeaperBrain

        brain_cfg = self._global_config.get("brain", {})
        if not brain_cfg.get("enabled", True):
            return None

        db_path = brain_cfg.get("db_path", str(self.config_dir / "brain.db"))
        try:
            return LeaperBrain(db_path=db_path, agent_id=agent_id)
        except TypeError:
            # 如果 LeaperBrain 不支持 agent_id 参数，降级
            try:
                return LeaperBrain(db_path=db_path)
            except Exception:
                return None

    async def route_message(
        self, message: str, agent_name: str | None = None, user_id: str | None = None
    ) -> str:
        """路由消息到指定 Agent。如果未指定，用默认 Agent

        Args:
            message: 用户消息
            agent_name: 目标 Agent 名称，None 则用默认
            user_id: 用户标识（用于上下文隔离）

        Returns:
            Agent 回复文本
        """
        target = agent_name or self.get_default_agent()
        if not target:
            raise ValueError("未指定 Agent 且无默认 Agent")

        agent = self.get_agent(target)
        reply = await agent.chat(message)
        return reply

    def get_default_agent(self) -> str:
        """从 config 读取默认 Agent 名

        优先级：
        1. 全局配置中的 multi_agent.default
        2. agent.name 配置
        3. 第一个扫描到的 agent
        """
        # 从 multi_agent 配置读取
        multi_cfg = self._global_config.get("multi_agent", {})
        if multi_cfg.get("default"):
            return multi_cfg["default"]

        # 从 agent 配置读取
        agent_cfg = self._global_config.get("agent", {})
        if agent_cfg.get("name") and agent_cfg["name"] in self._agent_configs:
            return agent_cfg["name"]

        # 返回第一个
        if self._agent_configs:
            return next(iter(self._agent_configs))

        return ""

    def get_channel_agent(self, channel_name: str) -> str | None:
        """获取渠道绑定的 Agent 名

        在配置中 multi_agent.channel_bindings 指定：
        multi_agent:
          default: my-cto
          channel_bindings:
            feishu: my-cpo
            dingtalk: my-cto
        """
        multi_cfg = self._global_config.get("multi_agent", {})
        bindings = multi_cfg.get("channel_bindings", {})
        return bindings.get(channel_name)
