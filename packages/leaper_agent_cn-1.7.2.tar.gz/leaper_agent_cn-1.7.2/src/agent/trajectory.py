"""轨迹记录器 — 记录 Agent 运行轨迹用于调试和分析

参考 Hermes trajectory_compressor.py
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class LLMCallRecord:
    """单次 LLM 调用记录"""
    prompt_tokens: int
    response_tokens: int
    model: str
    latency_ms: int
    timestamp: float = field(default_factory=time.time)


@dataclass
class ToolCallRecord:
    """单次工具调用记录"""
    tool: str
    args: dict
    result_preview: str  # 结果预览（截断）
    success: bool
    timestamp: float = field(default_factory=time.time)


@dataclass
class TurnRecord:
    """单轮对话记录"""
    turn_id: int
    user_message: str
    assistant_response: str = ""
    llm_calls: List[LLMCallRecord] = field(default_factory=list)
    tool_calls: List[ToolCallRecord] = field(default_factory=list)
    started_at: float = field(default_factory=time.time)
    ended_at: Optional[float] = None

    @property
    def duration_ms(self) -> int:
        if self.ended_at:
            return int((self.ended_at - self.started_at) * 1000)
        return 0

    @property
    def total_tokens(self) -> int:
        return sum(c.prompt_tokens + c.response_tokens for c in self.llm_calls)

    def to_dict(self) -> dict:
        return {
            "turn_id": self.turn_id,
            "user_message": self.user_message[:200],  # 截断
            "assistant_response": self.assistant_response[:200],
            "llm_calls": [
                {
                    "prompt_tokens": c.prompt_tokens,
                    "response_tokens": c.response_tokens,
                    "model": c.model,
                    "latency_ms": c.latency_ms,
                }
                for c in self.llm_calls
            ],
            "tool_calls": [
                {
                    "tool": c.tool,
                    "args_keys": list(c.args.keys()),
                    "success": c.success,
                }
                for c in self.tool_calls
            ],
            "duration_ms": self.duration_ms,
            "total_tokens": self.total_tokens,
            "started_at": self.started_at,
        }


# Token 成本映射（每百万 token，单位：元）
MODEL_COSTS: Dict[str, Dict[str, float]] = {
    "deepseek-v4-flash": {"input": 1.0, "output": 4.0},
    "deepseek-chat": {"input": 1.0, "output": 2.0},
    "qwen-max": {"input": 20.0, "output": 60.0},
    "qwen-plus": {"input": 0.8, "output": 2.0},
    "glm-4-flash": {"input": 0.0, "output": 0.0},  # 免费
    "glm-4": {"input": 100.0, "output": 100.0},
    "moonshot-v1-8k": {"input": 12.0, "output": 12.0},
}

RESULT_PREVIEW_MAX = 200


class TrajectoryRecorder:
    """Agent 运行轨迹记录器

    功能：
    - 按轮次记录 user → LLM calls → tool calls → assistant
    - 保存/加载轨迹文件
    - 压缩历史轨迹
    - 统计 tokens/成本/耗时
    """

    def __init__(self, save_dir: str = ".trajectories"):
        self._save_dir = Path(save_dir)
        self._turns: List[TurnRecord] = []
        self._current_turn: Optional[TurnRecord] = None
        self._turn_counter = 0

    def start_turn(self, user_message: str) -> None:
        """开始新的一轮对话

        Args:
            user_message: 用户消息
        """
        # 如果上一轮未结束，自动结束
        if self._current_turn:
            self.end_turn("")

        self._turn_counter += 1
        self._current_turn = TurnRecord(
            turn_id=self._turn_counter,
            user_message=user_message,
        )

    def record_llm_call(
        self,
        prompt_tokens: int,
        response_tokens: int,
        model: str,
        latency_ms: int,
    ) -> None:
        """记录一次 LLM 调用

        Args:
            prompt_tokens: 输入 token 数
            response_tokens: 输出 token 数
            model: 模型名称
            latency_ms: 延迟毫秒
        """
        if not self._current_turn:
            return

        self._current_turn.llm_calls.append(LLMCallRecord(
            prompt_tokens=prompt_tokens,
            response_tokens=response_tokens,
            model=model,
            latency_ms=latency_ms,
        ))

    def record_tool_call(
        self,
        tool: str,
        args: dict,
        result: str,
        success: bool,
    ) -> None:
        """记录一次工具调用

        Args:
            tool: 工具名
            args: 参数
            result: 结果
            success: 是否成功
        """
        if not self._current_turn:
            return

        # 结果预览截断
        preview = result[:RESULT_PREVIEW_MAX] if result else ""

        self._current_turn.tool_calls.append(ToolCallRecord(
            tool=tool,
            args=args,
            result_preview=preview,
            success=success,
        ))

    def end_turn(self, assistant_response: str) -> None:
        """结束当前轮

        Args:
            assistant_response: 助手回复
        """
        if not self._current_turn:
            return

        self._current_turn.assistant_response = assistant_response
        self._current_turn.ended_at = time.time()
        self._turns.append(self._current_turn)
        self._current_turn = None

    def save(self, session_id: str) -> str:
        """保存轨迹到文件

        Args:
            session_id: 会话 ID

        Returns:
            保存的文件路径
        """
        self._save_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{session_id}_{int(time.time())}.json"
        filepath = self._save_dir / filename

        data = {
            "session_id": session_id,
            "saved_at": time.time(),
            "total_turns": len(self._turns),
            "stats": self.get_stats(),
            "turns": [t.to_dict() for t in self._turns],
        }

        filepath.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return str(filepath)

    def load(self, session_id: str) -> List[dict]:
        """加载轨迹文件

        Args:
            session_id: 会话 ID（匹配文件名前缀）

        Returns:
            轨迹数据列表
        """
        if not self._save_dir.exists():
            return []

        results = []
        for f in sorted(self._save_dir.glob(f"{session_id}_*.json")):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                results.append(data)
            except (json.JSONDecodeError, OSError):
                continue
        return results

    def compress(self, max_turns: int = 50) -> None:
        """压缩轨迹，只保留最近 max_turns 轮

        Args:
            max_turns: 保留的最大轮数
        """
        if len(self._turns) > max_turns:
            self._turns = self._turns[-max_turns:]

    def get_stats(self) -> dict:
        """获取统计信息

        Returns:
            包含 total_turns, total_tokens, total_cost 等的字典
        """
        total_prompt = 0
        total_response = 0
        total_tool_calls = 0
        total_tool_errors = 0
        total_latency = 0
        total_cost = 0.0
        models_used: Dict[str, int] = {}
        tools_used: Dict[str, int] = {}

        for turn in self._turns:
            for llm in turn.llm_calls:
                total_prompt += llm.prompt_tokens
                total_response += llm.response_tokens
                total_latency += llm.latency_ms
                models_used[llm.model] = models_used.get(llm.model, 0) + 1

                # 计算成本
                costs = MODEL_COSTS.get(llm.model)
                if costs:
                    total_cost += (
                        llm.prompt_tokens * costs["input"] / 1_000_000
                        + llm.response_tokens * costs["output"] / 1_000_000
                    )

            for tc in turn.tool_calls:
                total_tool_calls += 1
                if not tc.success:
                    total_tool_errors += 1
                tools_used[tc.tool] = tools_used.get(tc.tool, 0) + 1

        return {
            "total_turns": len(self._turns),
            "total_prompt_tokens": total_prompt,
            "total_response_tokens": total_response,
            "total_tokens": total_prompt + total_response,
            "total_tool_calls": total_tool_calls,
            "total_tool_errors": total_tool_errors,
            "total_latency_ms": total_latency,
            "total_cost_yuan": round(total_cost, 4),
            "models_used": models_used,
            "tools_used": tools_used,
        }

    def clear(self) -> None:
        """清空所有轨迹"""
        self._turns.clear()
        self._current_turn = None
        self._turn_counter = 0
