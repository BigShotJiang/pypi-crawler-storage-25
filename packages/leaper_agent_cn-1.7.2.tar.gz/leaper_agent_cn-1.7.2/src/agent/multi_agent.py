"""Multi-Agent 编排器 — 多 Agent 协作路由、广播、链式、辩论

支持：
- 关键词路由：根据消息关键词匹配 agent
- LLM 路由：用 LLM 判断消息应发给哪个 agent
- 广播：消息发给所有 agent
- 链式调用：按顺序调用多个 agent
- 辩论模式（War Room）：多 agent 辩论后综合结论
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

from ..providers.base import LLMProvider, Message, Response

logger = logging.getLogger(__name__)


# ── 配置 ──

@dataclass
class AgentConfig:
    """单个 Agent 的配置"""
    name: str
    role: str = "assistant"
    system_prompt: str = ""
    model: str = ""
    keywords: list[str] = field(default_factory=list)
    description: str = ""  # 用于 LLM 路由的描述

    # 可选的自定义 chat 函数（用于测试或外部 agent）
    chat_fn: Callable[[str], Awaitable[str]] | None = None


@dataclass
class RouteResult:
    """路由结果"""
    agent_name: str
    response: str
    method: str = "keyword"  # keyword / llm / default


class MultiAgentOrchestrator:
    """多 Agent 协作编排器"""

    def __init__(
        self,
        agents: dict[str, AgentConfig],
        provider: LLMProvider | None = None,
        default_agent: str | None = None,
    ):
        """初始化编排器

        Args:
            agents: agent 名称到配置的映射
            provider: LLM provider（用于 LLM 路由和 agent 对话）
            default_agent: 默认 agent 名称（无法路由时使用）
        """
        self.agents = agents
        self.provider = provider
        self.default_agent = default_agent or (
            next(iter(agents)) if agents else None
        )

    async def _chat_with_agent(
        self, agent_name: str, message: str, context: list[Message] | None = None
    ) -> str:
        """与指定 agent 对话

        如果 agent 配置了 chat_fn，使用自定义函数；
        否则用 provider.chat()。
        """
        cfg = self.agents.get(agent_name)
        if not cfg:
            return f"错误：Agent '{agent_name}' 不存在"

        # 自定义 chat 函数
        if cfg.chat_fn:
            return await cfg.chat_fn(message)

        # 用 provider
        if not self.provider:
            return f"错误：未配置 LLM provider"

        messages = []
        if cfg.system_prompt:
            messages.append(Message(role="system", content=cfg.system_prompt))
        if context:
            messages.extend(context)
        messages.append(Message(role="user", content=message))

        try:
            resp = await self.provider.chat(messages=messages)
            return resp.content or ""
        except Exception as e:
            return f"Agent '{agent_name}' 调用失败: {e}"

    # ── 路由 ──

    def _keyword_match(self, message: str) -> str | None:
        """关键词匹配路由

        扫描所有 agent 的 keywords，返回匹配最多的 agent。
        """
        scores: dict[str, int] = {}
        msg_lower = message.lower()
        for name, cfg in self.agents.items():
            score = sum(1 for kw in cfg.keywords if kw.lower() in msg_lower)
            if score > 0:
                scores[name] = score

        if not scores:
            return None

        # 返回匹配分数最高的
        return max(scores, key=scores.get)  # type: ignore

    async def _llm_route(self, message: str) -> str | None:
        """LLM 路由：用一次 LLM 调用判断消息该发给哪个 agent"""
        if not self.provider:
            return None

        agent_list = "\n".join(
            f"- {name}: {cfg.role} — {cfg.description or '无描述'}"
            for name, cfg in self.agents.items()
        )
        prompt = (
            f"你是一个消息路由器。根据用户消息判断应该交给哪个 Agent 处理。\n\n"
            f"可用的 Agent:\n{agent_list}\n\n"
            f"用户消息: {message}\n\n"
            f"请只回复 Agent 的名称（一个词），不要解释。"
        )

        try:
            resp = await self.provider.chat(
                messages=[Message(role="user", content=prompt)],
                temperature=0.1,
                max_tokens=50,
            )
            agent_name = (resp.content or "").strip()
            if agent_name in self.agents:
                return agent_name
        except Exception:
            pass

        return None

    async def route_message(self, message: str) -> RouteResult:
        """路由消息到合适的 agent

        路由优先级：关键词匹配 → LLM 路由 → 默认 agent

        Args:
            message: 用户消息

        Returns:
            RouteResult(agent_name, response, method)
        """
        # 1. 关键词匹配
        agent = self._keyword_match(message)
        if agent:
            response = await self._chat_with_agent(agent, message)
            return RouteResult(agent_name=agent, response=response, method="keyword")

        # 2. LLM 路由
        agent = await self._llm_route(message)
        if agent:
            response = await self._chat_with_agent(agent, message)
            return RouteResult(agent_name=agent, response=response, method="llm")

        # 3. 默认 agent
        if self.default_agent and self.default_agent in self.agents:
            response = await self._chat_with_agent(self.default_agent, message)
            return RouteResult(
                agent_name=self.default_agent, response=response, method="default"
            )

        return RouteResult(agent_name="", response="没有可用的 Agent", method="none")

    # ── 广播 ──

    async def broadcast(self, message: str) -> dict[str, str]:
        """广播消息给所有 agent，并行执行

        Args:
            message: 广播消息

        Returns:
            {agent_name: response} 字典
        """
        tasks = {
            name: self._chat_with_agent(name, message)
            for name in self.agents
        }
        results = {}
        for name, coro in tasks.items():
            try:
                results[name] = await coro
            except Exception as e:
                results[name] = f"错误: {e}"
        return results

    # ── 链式调用 ──

    async def chain(self, message: str, agent_sequence: list[str]) -> str:
        """链式调用：按顺序调用多个 agent，上一个的输出作为下一个的输入

        Args:
            message: 初始消息
            agent_sequence: agent 名称序列

        Returns:
            最后一个 agent 的输出
        """
        current = message
        for agent_name in agent_sequence:
            current = await self._chat_with_agent(agent_name, current)
        return current

    # ── 辩论模式（War Room） ──

    async def debate(
        self,
        topic: str,
        agents: list[str] | None = None,
        rounds: int = 3,
    ) -> str:
        """辩论模式：多个 agent 就同一话题展开讨论

        流程：
        1. 每个 agent 独立回答
        2. 其他 agent 看到回答后给出评价
        3. 重复 N 轮
        4. 生成综合结论

        Args:
            topic: 辩论话题
            agents: 参与辩论的 agent 列表（默认全部）
            rounds: 辩论轮数

        Returns:
            综合结论文本
        """
        participants = agents or list(self.agents.keys())
        if len(participants) < 2:
            if participants:
                return await self._chat_with_agent(participants[0], topic)
            return "至少需要 2 个 Agent 参与辩论"

        history: list[dict[str, str]] = []  # [{agent, content}]

        for round_num in range(1, rounds + 1):
            for agent_name in participants:
                # 构造上下文：包含之前所有发言
                context = f"话题: {topic}\n\n"
                if history:
                    context += "=== 之前的讨论 ===\n"
                    for entry in history:
                        context += f"\n【{entry['agent']}】: {entry['content']}\n"
                    context += "\n=== 请发表你的观点 ===\n"
                    if round_num > 1:
                        context += "请评价其他人的观点，并完善或反驳。\n"
                else:
                    context += "请就这个话题发表你的独立观点。\n"

                response = await self._chat_with_agent(agent_name, context)
                history.append({"agent": agent_name, "content": response})

        # 生成综合结论
        summary = await self._generate_summary(topic, history, participants)
        return summary

    async def _generate_summary(
        self,
        topic: str,
        history: list[dict[str, str]],
        participants: list[str],
    ) -> str:
        """生成辩论综合结论"""
        discussion = "\n".join(
            f"【{e['agent']}】: {e['content']}" for e in history
        )

        # 如果有 provider，用 LLM 总结
        if self.provider:
            prompt = (
                f"以下是多个专家就「{topic}」展开的讨论：\n\n"
                f"{discussion}\n\n"
                f"请生成一份综合结论，包括：\n"
                f"1. 各方共识\n"
                f"2. 主要分歧\n"
                f"3. 综合建议"
            )
            try:
                resp = await self.provider.chat(
                    messages=[Message(role="user", content=prompt)],
                    temperature=0.3,
                )
                return resp.content or discussion
            except Exception:
                pass

        # 降级：直接拼接
        parts = [f"=== 辩论话题: {topic} ===\n"]
        for entry in history:
            parts.append(f"\n【{entry['agent']}】:\n{entry['content']}\n")
        return "\n".join(parts)
