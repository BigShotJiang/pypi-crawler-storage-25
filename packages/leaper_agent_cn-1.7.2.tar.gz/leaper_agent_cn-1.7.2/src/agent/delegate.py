"""
Delegate - 子任务委派管理器

将子任务委派给另一个 agent 实例，运行在独立 asyncio task 中。
通过 asyncio.Queue 传递结果，支持超时自动取消。
"""

from __future__ import annotations

import asyncio
import enum
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


class SubAgentStatus(enum.Enum):
    """子 agent 状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


@dataclass
class SubAgentResult:
    """子 agent 执行结果"""
    output: str = ""
    error: Optional[str] = None
    status: SubAgentStatus = SubAgentStatus.PENDING
    elapsed_seconds: float = 0.0


@dataclass
class SubAgentHandle:
    """子 agent 句柄，用于跟踪和管理子任务"""
    id: str = ""
    task_description: str = ""
    status: SubAgentStatus = SubAgentStatus.PENDING
    created_at: float = 0.0
    # 内部字段
    _task: Optional[asyncio.Task] = field(default=None, repr=False)
    _result_queue: asyncio.Queue = field(default_factory=asyncio.Queue, repr=False)


@dataclass
class DelegateConfig:
    """委派配置"""
    system_prompt: str = ""
    max_turns: int = 10
    timeout: float = 300.0  # 秒
    # 传递给子 agent 的额外参数
    extra: Dict[str, Any] = field(default_factory=dict)


# 子 agent 执行函数类型：接收 (task, config) 返回 str
SubAgentFn = Callable[[str, DelegateConfig], Coroutine[Any, Any, str]]


async def _default_subagent_fn(task: str, config: DelegateConfig) -> str:
    """默认子 agent 实现（占位，实际使用时需注入真实实现）"""
    return f"[子任务完成] {task}"


class DelegateManager:
    """子任务委派管理器

    管理多个子 agent 的生命周期：spawn / wait / cancel。
    子 agent 运行在独立 asyncio.Task 中，通过 Queue 返回结果。

    示例::

        manager = DelegateManager(subagent_fn=my_agent_fn)
        handle = await manager.spawn_subagent("分析这段代码", DelegateConfig(timeout=60))
        result = await manager.wait_for_result(handle, timeout=60)
        print(result)
    """

    def __init__(
        self,
        subagent_fn: Optional[SubAgentFn] = None,
        max_concurrent: int = 5,
    ):
        """初始化委派管理器

        Args:
            subagent_fn: 子 agent 执行函数，接收 (task, config)，返回结果字符串
            max_concurrent: 最大并发子 agent 数
        """
        self._subagent_fn = subagent_fn or _default_subagent_fn
        self._max_concurrent = max_concurrent
        self._handles: Dict[str, SubAgentHandle] = {}
        self._semaphore = asyncio.Semaphore(max_concurrent)

    @property
    def active_count(self) -> int:
        """当前活跃的子 agent 数"""
        return sum(
            1 for h in self._handles.values()
            if h.status in (SubAgentStatus.PENDING, SubAgentStatus.RUNNING)
        )

    def list_handles(self) -> List[SubAgentHandle]:
        """列出所有子 agent 句柄"""
        return list(self._handles.values())

    async def spawn_subagent(
        self,
        task: str,
        config: Optional[DelegateConfig] = None,
    ) -> SubAgentHandle:
        """创建并启动子 agent

        Args:
            task: 任务描述
            config: 委派配置，默认使用 DelegateConfig()

        Returns:
            SubAgentHandle 句柄

        Raises:
            RuntimeError: 并发数超限
        """
        if config is None:
            config = DelegateConfig()

        if self.active_count >= self._max_concurrent:
            raise RuntimeError(
                f"子 agent 并发数已达上限 ({self._max_concurrent})，"
                "请等待现有任务完成或取消后再试"
            )

        handle = SubAgentHandle(
            id=uuid.uuid4().hex[:12],
            task_description=task[:200],
            status=SubAgentStatus.PENDING,
            created_at=time.time(),
        )

        # 启动 asyncio task
        handle._task = asyncio.create_task(
            self._run_subagent(handle, task, config)
        )
        self._handles[handle.id] = handle

        logger.info("子 agent 已创建: %s (任务: %s)", handle.id, task[:50])
        return handle

    async def _run_subagent(
        self,
        handle: SubAgentHandle,
        task: str,
        config: DelegateConfig,
    ) -> None:
        """执行子 agent（内部方法）"""
        start_time = time.time()
        handle.status = SubAgentStatus.RUNNING

        try:
            async with self._semaphore:
                # 带超时执行
                result_str = await asyncio.wait_for(
                    self._subagent_fn(task, config),
                    timeout=config.timeout,
                )

            elapsed = time.time() - start_time
            handle.status = SubAgentStatus.COMPLETED
            await handle._result_queue.put(SubAgentResult(
                output=result_str,
                status=SubAgentStatus.COMPLETED,
                elapsed_seconds=elapsed,
            ))

        except asyncio.TimeoutError:
            elapsed = time.time() - start_time
            handle.status = SubAgentStatus.TIMEOUT
            await handle._result_queue.put(SubAgentResult(
                error=f"子任务超时 ({config.timeout}s)",
                status=SubAgentStatus.TIMEOUT,
                elapsed_seconds=elapsed,
            ))
            logger.warning("子 agent %s 超时 (%.1fs)", handle.id, elapsed)

        except asyncio.CancelledError:
            handle.status = SubAgentStatus.CANCELLED
            await handle._result_queue.put(SubAgentResult(
                error="子任务已取消",
                status=SubAgentStatus.CANCELLED,
                elapsed_seconds=time.time() - start_time,
            ))

        except Exception as e:
            elapsed = time.time() - start_time
            handle.status = SubAgentStatus.FAILED
            await handle._result_queue.put(SubAgentResult(
                error=str(e),
                status=SubAgentStatus.FAILED,
                elapsed_seconds=elapsed,
            ))
            logger.error("子 agent %s 失败: %s", handle.id, e)

    async def wait_for_result(
        self,
        handle: SubAgentHandle,
        timeout: float = 300.0,
    ) -> str:
        """等待子 agent 完成并返回结果

        Args:
            handle: 子 agent 句柄
            timeout: 等待超时（秒）

        Returns:
            子 agent 输出字符串

        Raises:
            TimeoutError: 等待超时
            RuntimeError: 子 agent 执行失败
        """
        try:
            result: SubAgentResult = await asyncio.wait_for(
                handle._result_queue.get(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            raise TimeoutError(f"等待子 agent {handle.id} 超时 ({timeout}s)")

        if result.status == SubAgentStatus.COMPLETED:
            return result.output
        elif result.status == SubAgentStatus.TIMEOUT:
            raise TimeoutError(result.error or "子任务超时")
        elif result.status == SubAgentStatus.CANCELLED:
            raise RuntimeError(result.error or "子任务已取消")
        else:
            raise RuntimeError(result.error or "子任务执行失败")

    async def cancel(self, handle: SubAgentHandle) -> None:
        """取消子 agent

        Args:
            handle: 要取消的子 agent 句柄
        """
        if handle._task and not handle._task.done():
            handle._task.cancel()
            logger.info("子 agent %s 已请求取消", handle.id)

    async def cancel_all(self) -> int:
        """取消所有活跃的子 agent

        Returns:
            取消的数量
        """
        cancelled = 0
        for handle in self._handles.values():
            if handle._task and not handle._task.done():
                handle._task.cancel()
                cancelled += 1
        if cancelled:
            logger.info("已取消 %d 个子 agent", cancelled)
        return cancelled

    def cleanup_completed(self) -> int:
        """清理已完成的子 agent 记录

        Returns:
            清理的数量
        """
        done_ids = [
            hid for hid, h in self._handles.items()
            if h.status not in (SubAgentStatus.PENDING, SubAgentStatus.RUNNING)
        ]
        for hid in done_ids:
            del self._handles[hid]
        return len(done_ids)
