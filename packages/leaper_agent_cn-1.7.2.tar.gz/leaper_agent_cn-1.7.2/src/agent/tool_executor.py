"""工具执行器 — 接收 tool_calls 列表，逐个执行并返回结果"""
import asyncio
import json
from typing import Any


class ToolExecutor:
    """工具执行器，管理并调用注册的工具"""

    def __init__(self, tools: list | None = None, timeout: float = 60.0):
        self._tools: dict = {}
        self.timeout = timeout
        if tools:
            for tool in tools:
                self.register(tool)

    def register(self, tool) -> None:
        """注册一个工具"""
        self._tools[tool.name] = tool

    def get_tool_schemas(self) -> list[dict]:
        """获取所有工具的 JSON Schema 定义（用于 LLM function calling）"""
        schemas = []
        for tool in self._tools.values():
            schemas.append({
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            })
        return schemas

    async def execute_batch(self, tool_calls: list[dict]) -> list[dict]:
        """批量执行 tool_calls，返回结果列表"""
        results = []
        for call in tool_calls:
            tool_call_id = call.get("id", "")
            func = call.get("function", {})
            name = func.get("name", "")
            arguments_raw = func.get("arguments", "{}")

            # 解析参数
            try:
                arguments = json.loads(arguments_raw) if isinstance(arguments_raw, str) else arguments_raw
            except json.JSONDecodeError:
                arguments = {}

            # 执行工具（带超时保护）
            content = await self._execute_one(name, arguments)
            results.append({"tool_call_id": tool_call_id, "content": content})

        return results

    async def _execute_one(self, name: str, arguments: dict) -> str:
        """执行单个工具，带超时保护"""
        tool = self._tools.get(name)
        if not tool:
            return f"错误: 未找到工具 '{name}'"

        try:
            result = await asyncio.wait_for(tool.execute(arguments), timeout=self.timeout)
            return result
        except asyncio.TimeoutError:
            return f"错误: 工具 '{name}' 执行超时 ({self.timeout}s)"
        except Exception as e:
            return f"错误: 工具 '{name}' 执行失败 — {type(e).__name__}: {e}"
