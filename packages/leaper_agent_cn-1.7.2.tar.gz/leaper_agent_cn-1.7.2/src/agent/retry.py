"""重试工具 — 指数退避重试，结合 error_classifier。

参考 Hermes retry_utils.py 的简化版。
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import Any, Callable, Optional, TypeVar

from .error_classifier import classify_error, ErrorCategory, ErrorInfo

logger = logging.getLogger(__name__)

T = TypeVar("T")


def jittered_backoff(
    attempt: int,
    base_delay: float = 2.0,
    max_delay: float = 60.0,
    jitter_ratio: float = 0.5,
) -> float:
    """计算带抖动的指数退避延迟。

    Args:
        attempt: 第几次重试（从 1 开始）。
        base_delay: 基础延迟秒数。
        max_delay: 最大延迟秒数。
        jitter_ratio: 抖动比例。

    Returns:
        延迟秒数。
    """
    exponent = max(0, attempt - 1)
    delay = min(base_delay * (2 ** exponent), max_delay)
    jitter = random.uniform(0, jitter_ratio * delay)
    return delay + jitter


async def retry_with_backoff(
    func: Callable[..., Any],
    *args: Any,
    max_retries: int = 3,
    classify: bool = True,
    on_retry: Optional[Callable[[int, ErrorInfo], None]] = None,
    **kwargs: Any,
) -> Any:
    """带指数退避的异步重试。

    Args:
        func: 要重试的异步函数。
        *args: 传给 func 的位置参数。
        max_retries: 最大重试次数。
        classify: 是否使用 error_classifier 分类错误。
        on_retry: 每次重试时的回调。
        **kwargs: 传给 func 的关键字参数。

    Returns:
        func 的返回值。

    Raises:
        最后一次重试仍失败时抛出原始异常。
    """
    last_exc: Optional[Exception] = None

    for attempt in range(1, max_retries + 2):  # +1 for initial attempt
        try:
            if asyncio.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            else:
                return func(*args, **kwargs)
        except Exception as exc:
            last_exc = exc

            if attempt > max_retries:
                break

            if classify:
                info = classify_error(exc)
                if not info.retryable:
                    logger.warning("不可重试错误 [%s]: %s", info.category.value, info.message)
                    raise
                wait = max(info.wait_seconds, jittered_backoff(attempt))
            else:
                info = ErrorInfo(category=ErrorCategory.unknown)
                wait = jittered_backoff(attempt)

            if on_retry:
                on_retry(attempt, info)

            logger.info("第 %d/%d 次重试，等待 %.1f 秒: %s",
                        attempt, max_retries, wait, str(exc)[:100])
            await asyncio.sleep(wait)

    raise last_exc  # type: ignore[misc]
