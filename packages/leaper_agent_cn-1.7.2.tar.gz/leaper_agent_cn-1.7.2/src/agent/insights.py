"""
Insights - 对话分析模块

分析对话质量和模式，检测循环，提供改善建议。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ConversationInsights:
    """对话分析结果"""
    total_turns: int = 0
    avg_response_length: float = 0.0
    tool_usage_count: int = 0
    error_count: int = 0
    topics_discussed: List[str] = field(default_factory=list)
    loop_detected: bool = False
    # 详细统计
    user_message_count: int = 0
    assistant_message_count: int = 0
    tool_message_count: int = 0
    total_tokens_estimate: int = 0


def _estimate_tokens(text: str) -> int:
    """粗略估算 token 数"""
    if not text:
        return 0
    cn_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    rest = len(text) - cn_chars
    return cn_chars * 2 + max(rest // 4, 1)


def _extract_tool_calls(message: dict) -> List[dict]:
    """从消息中提取 tool_calls"""
    tc = message.get("tool_calls")
    if isinstance(tc, list):
        return tc
    return []


def _extract_topics(messages: list[dict], max_topics: int = 10) -> List[str]:
    """从对话中提取讨论话题（简单实现：取用户消息的前 30 字作为话题）"""
    topics: List[str] = []
    seen: set = set()
    for msg in messages:
        if msg.get("role") != "user":
            continue
        content = msg.get("content", "") or ""
        if not content.strip():
            continue
        # 取前 30 字作为话题摘要
        topic = content.strip()[:30].replace("\n", " ")
        if topic not in seen:
            seen.add(topic)
            topics.append(topic)
            if len(topics) >= max_topics:
                break
    return topics


def analyze_conversation(history: list[dict]) -> ConversationInsights:
    """分析对话历史，返回 ConversationInsights

    Args:
        history: 对话历史，每项为 {"role": "user"|"assistant"|"tool"|"system", "content": "..."}

    Returns:
        ConversationInsights 分析结果
    """
    if not history:
        return ConversationInsights()

    insights = ConversationInsights()

    user_msgs: list[str] = []
    assistant_msgs: list[str] = []
    total_tokens = 0

    for msg in history:
        role = msg.get("role", "")
        content = msg.get("content", "") or ""
        total_tokens += _estimate_tokens(content)

        if role == "user":
            insights.user_message_count += 1
            user_msgs.append(content)
        elif role == "assistant":
            insights.assistant_message_count += 1
            assistant_msgs.append(content)
            # 统计 tool_calls
            tool_calls = _extract_tool_calls(msg)
            insights.tool_usage_count += len(tool_calls)
        elif role == "tool":
            insights.tool_message_count += 1
            # 检查错误
            if content and ("error" in content.lower() or "错误" in content or "失败" in content):
                insights.error_count += 1

    # 总轮数 = user + assistant 消息对数
    insights.total_turns = min(insights.user_message_count, insights.assistant_message_count)
    if insights.total_turns == 0 and (insights.user_message_count > 0 or insights.assistant_message_count > 0):
        insights.total_turns = max(insights.user_message_count, insights.assistant_message_count)

    # 平均回复长度
    if assistant_msgs:
        insights.avg_response_length = sum(len(m) for m in assistant_msgs) / len(assistant_msgs)

    # 话题提取
    insights.topics_discussed = _extract_topics(history)

    # token 估算
    insights.total_tokens_estimate = total_tokens

    # 循环检测
    insights.loop_detected = detect_loop(history)

    return insights


def detect_loop(history: list[dict], window: int = 5) -> bool:
    """检测 agent 是否陷入循环（重复相同 tool call）

    策略：在最近 window 个 assistant 消息中，如果同名 tool call 出现 >= 3 次且
    参数完全相同，判定为循环。

    Args:
        history: 对话历史
        window: 检查的最近 assistant 消息窗口大小

    Returns:
        True 表示检测到循环
    """
    if not history:
        return False

    # 提取最近 window 个带 tool_calls 的 assistant 消息
    recent_tool_calls: list[str] = []
    for msg in reversed(history):
        if len(recent_tool_calls) >= window:
            break
        if msg.get("role") != "assistant":
            continue
        calls = _extract_tool_calls(msg)
        for tc in calls:
            func = tc.get("function", {})
            # 用 name + arguments 的字符串作为指纹
            fingerprint = f"{func.get('name', '')}:{func.get('arguments', '')}"
            recent_tool_calls.append(fingerprint)

    if len(recent_tool_calls) < 3:
        return False

    # 检查是否有重复 >= 3 次的 tool call
    from collections import Counter
    counts = Counter(recent_tool_calls)
    for fingerprint, count in counts.items():
        if count >= 3 and fingerprint != ":":  # 忽略空指纹
            logger.warning("检测到循环 tool call: %s (出现 %d 次)", fingerprint, count)
            return True

    return False


def suggest_improvements(insights: ConversationInsights) -> list[str]:
    """根据分析结果提供改善建议

    Args:
        insights: ConversationInsights 分析结果

    Returns:
        建议列表
    """
    suggestions: list[str] = []

    if insights.loop_detected:
        suggestions.append("检测到循环 tool call，建议中断并重新组织策略")

    if insights.error_count > 0:
        error_rate = insights.error_count / max(insights.tool_usage_count, 1)
        if error_rate > 0.5:
            suggestions.append(
                f"工具调用错误率过高 ({insights.error_count}/{insights.tool_usage_count})，"
                "建议检查工具参数或切换策略"
            )

    if insights.avg_response_length > 5000:
        suggestions.append("平均回复过长，建议精简输出，避免 token 浪费")

    if insights.avg_response_length < 10 and insights.assistant_message_count > 3:
        suggestions.append("回复过短，可能存在问题，建议检查 prompt 或 provider")

    if insights.total_tokens_estimate > 100000:
        suggestions.append("Token 使用量过高，建议压缩历史或启用摘要")

    if insights.tool_usage_count > 20 and insights.total_turns < 5:
        suggestions.append("工具调用过多但对话轮数少，可能在重复尝试，建议优化策略")

    if not suggestions:
        suggestions.append("对话质量良好，无需调整")

    return suggestions
