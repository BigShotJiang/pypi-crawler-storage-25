"""
ContextEngine - 上下文引擎

组装最终传给 LLM 的 context，包括：
1. system prompt（workspace .md 文件）
2. brain recall 结果（相关记忆注入）
3. conversation history（context window）
4. onboarding 提示（如需要）
5. user message
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from .session import _estimate_tokens

logger = logging.getLogger(__name__)

# 默认 context window token 预算
DEFAULT_TOKEN_BUDGET = 8000


class ContextEngine:
    """上下文引擎：组装最终传给 LLM 的 context"""

    def __init__(self, brain, session_manager, workspace_dir: str = ""):
        self.brain = brain
        self.session_manager = session_manager
        self.workspace_dir = workspace_dir
        self._workspace_cache: str | None = None

    async def build_context(
        self,
        session_id: str,
        user_message: str,
        system_prompt: str = "",
        onboarding_prompt: str = "",
        max_tokens: int = DEFAULT_TOKEN_BUDGET,
    ) -> list[dict]:
        """构建完整 context：
        1. system prompt
        2. workspace 文件内容
        3. brain recall 结果
        4. conversation history（context window）
        5. onboarding 提示
        6. user message
        """
        messages: list[dict] = []

        # 1. System prompt
        parts = []
        if system_prompt:
            parts.append(system_prompt)

        # 2. Workspace 文件
        ws_content = self._load_workspace_files()
        if ws_content:
            parts.append(ws_content)

        if parts:
            messages.append({"role": "system", "content": "\n\n".join(parts)})

        # 3. Brain recall（相关记忆注入）
        memory_context = await self._recall_memories(user_message)
        if memory_context:
            messages.append({"role": "system", "content": memory_context})

        # 4. Onboarding
        if onboarding_prompt:
            messages.append({"role": "system", "content": onboarding_prompt})

        # 5. Conversation history（context window）
        # 为 history 留出预算：总预算 - system 消息 - user 消息预估
        system_tokens = sum(_estimate_tokens(m["content"]) for m in messages)
        user_tokens = _estimate_tokens(user_message)
        history_budget = max(max_tokens - system_tokens - user_tokens - 500, 1000)

        history = await self.session_manager.get_context_window(
            session_id, max_tokens=history_budget
        )
        messages.extend(history)

        # 6. User message
        messages.append({"role": "user", "content": user_message})

        # 最终截断保护
        messages = self._truncate_to_budget(messages, max_tokens)

        return messages

    def _load_workspace_files(self) -> str:
        """加载 workspace 下的 .md 文件作为 system prompt 一部分"""
        if self._workspace_cache is not None:
            return self._workspace_cache

        if not self.workspace_dir or not os.path.isdir(self.workspace_dir):
            self._workspace_cache = ""
            return ""

        parts: list[str] = []
        ws = Path(self.workspace_dir)
        # 只读顶层 .md 文件，避免递归太深
        for md_file in sorted(ws.glob("*.md")):
            try:
                content = md_file.read_text(encoding="utf-8")
                # 限制每个文件最多 2000 字
                if len(content) > 2000:
                    content = content[:2000] + "\n...[截断]"
                parts.append(f"## {md_file.name}\n{content}")
            except Exception:
                continue

        self._workspace_cache = "\n\n".join(parts) if parts else ""
        return self._workspace_cache

    async def _recall_memories(self, query: str) -> str:
        """从 brain recall 相关记忆"""
        if not self.brain or not hasattr(self.brain, "recall"):
            return ""
        try:
            memories = await self.brain.recall(query, limit=5)
        except TypeError:
            try:
                memories = await self.brain.recall(query)
            except Exception:
                return ""
        except Exception:
            return ""

        if not memories:
            return ""

        lines: list[str] = []
        for entry in memories[:5]:
            if isinstance(entry, dict):
                text = entry.get("content", "") or entry.get("text", "") or str(entry)
            else:
                text = str(entry)
            if len(text) > 200:
                text = text[:200] + "..."
            lines.append(f"- {text}")

        if not lines:
            return ""
        return "[相关记忆]\n" + "\n".join(lines)

    def _truncate_to_budget(self, messages: list[dict], budget: int) -> list[dict]:
        """按 token 预算截断，保留系统消息和最近消息"""
        if not messages:
            return messages

        total = sum(_estimate_tokens(m.get("content", "") or "") for m in messages)
        if total <= budget:
            return messages

        # 策略：保留第一条 system + 最后一条 user，中间从旧到新裁剪
        # 找出系统消息和最后的 user 消息
        system_msgs = [m for m in messages if m["role"] == "system"]
        non_system = [m for m in messages if m["role"] != "system"]

        if not non_system:
            return messages

        # 保留所有 system + 从后往前尽可能多的非 system 消息
        system_tokens = sum(_estimate_tokens(m.get("content", "") or "") for m in system_msgs)
        remaining_budget = budget - system_tokens

        kept_non_system: list[dict] = []
        for m in reversed(non_system):
            t = _estimate_tokens(m.get("content", "") or "")
            if remaining_budget - t < 0 and kept_non_system:
                break
            remaining_budget -= t
            kept_non_system.insert(0, m)

        return system_msgs + kept_non_system
