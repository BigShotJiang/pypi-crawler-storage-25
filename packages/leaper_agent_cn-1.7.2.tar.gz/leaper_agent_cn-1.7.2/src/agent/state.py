"""Agent 状态管理 - 运行状态、统计、成本追踪、持久化

参考 Hermes hermes_state.py 的精简版，保留核心功能。
"""

from __future__ import annotations

import json
import os
import time
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from ..constants import (
    STATE_FILE,
    STATE_SAVE_INTERVAL,
    STATE_SAVE_OPS_THRESHOLD,
)


# ── 数据结构 ──────────────────────────────────────────────────────────


@dataclass
class MessageStats:
    """消息统计"""
    total: int = 0
    user_messages: int = 0
    assistant_messages: int = 0
    system_messages: int = 0
    total_tokens: int = 0

    def to_dict(self) -> dict:
        return {
            "total": self.total,
            "user_messages": self.user_messages,
            "assistant_messages": self.assistant_messages,
            "system_messages": self.system_messages,
            "total_tokens": self.total_tokens,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MessageStats":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ToolStats:
    """工具调用统计"""
    total_calls: int = 0
    success_count: int = 0
    error_count: int = 0
    by_tool: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "total_calls": self.total_calls,
            "success_count": self.success_count,
            "error_count": self.error_count,
            "by_tool": dict(self.by_tool),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ToolStats":
        return cls(
            total_calls=data.get("total_calls", 0),
            success_count=data.get("success_count", 0),
            error_count=data.get("error_count", 0),
            by_tool=dict(data.get("by_tool", {})),
        )


@dataclass
class CostTracker:
    """成本追踪"""
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_api_calls: int = 0
    by_provider: dict[str, dict[str, int]] = field(default_factory=dict)

    def record(self, provider: str, model: str, tokens_in: int, tokens_out: int) -> None:
        """记录一次 API 调用"""
        self.total_tokens_in += tokens_in
        self.total_tokens_out += tokens_out
        self.total_api_calls += 1
        key = f"{provider}/{model}"
        if key not in self.by_provider:
            self.by_provider[key] = {"tokens_in": 0, "tokens_out": 0, "calls": 0}
        self.by_provider[key]["tokens_in"] += tokens_in
        self.by_provider[key]["tokens_out"] += tokens_out
        self.by_provider[key]["calls"] += 1

    def to_dict(self) -> dict:
        return {
            "total_tokens_in": self.total_tokens_in,
            "total_tokens_out": self.total_tokens_out,
            "total_api_calls": self.total_api_calls,
            "by_provider": dict(self.by_provider),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CostTracker":
        obj = cls()
        obj.total_tokens_in = data.get("total_tokens_in", 0)
        obj.total_tokens_out = data.get("total_tokens_out", 0)
        obj.total_api_calls = data.get("total_api_calls", 0)
        obj.by_provider = {k: dict(v) for k, v in data.get("by_provider", {}).items()}
        return obj


@dataclass
class ErrorRecord:
    """错误记录"""
    error_type: str
    message: str
    timestamp: float
    context: Optional[str] = None

    def to_dict(self) -> dict:
        d: dict[str, Any] = {
            "error_type": self.error_type,
            "message": self.message,
            "timestamp": self.timestamp,
        }
        if self.context:
            d["context"] = self.context
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "ErrorRecord":
        return cls(
            error_type=data.get("error_type", "unknown"),
            message=data.get("message", ""),
            timestamp=data.get("timestamp", 0.0),
            context=data.get("context"),
        )


@dataclass
class SessionInfo:
    """会话信息"""
    session_id: str
    started_at: float
    last_active: float
    message_count: int = 0
    channel: str = "unknown"

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "started_at": self.started_at,
            "last_active": self.last_active,
            "message_count": self.message_count,
            "channel": self.channel,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SessionInfo":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


# ── 主状态类 ──────────────────────────────────────────────────────────


class AgentState:
    """Agent 运行状态管理

    功能：
    - 记录消息/工具调用/错误
    - 统计 token 消耗和成本
    - 管理活跃 session
    - 持久化到 .state.json
    - 定期自动保存（基于时间或操作次数）
    """

    def __init__(self, state_dir: Optional[str] = None):
        """
        state_dir: 状态文件存储目录（默认当前目录）
        """
        self._state_dir = Path(state_dir) if state_dir else Path.cwd()
        self._state_file = self._state_dir / STATE_FILE
        self._lock = threading.Lock()

        # 核心状态
        self.messages = MessageStats()
        self.tools = ToolStats()
        self.costs = CostTracker()
        self.errors: list[ErrorRecord] = []
        self.sessions: dict[str, SessionInfo] = {}

        # 元数据
        self.started_at: float = time.time()
        self.last_save: float = 0.0
        self._ops_since_save: int = 0
        self._max_errors: int = 100  # 最多保留的错误记录数

    # ── 记录方法 ──────────────────────────────────────────────────

    def record_message(
        self,
        role: str,
        tokens: int = 0,
        session_id: Optional[str] = None,
    ) -> None:
        """记录一条消息

        Args:
            role: user / assistant / system
            tokens: 消息 token 数
            session_id: 所属会话 ID
        """
        with self._lock:
            self.messages.total += 1
            self.messages.total_tokens += tokens
            if role == "user":
                self.messages.user_messages += 1
            elif role == "assistant":
                self.messages.assistant_messages += 1
            elif role == "system":
                self.messages.system_messages += 1

            # 更新 session
            if session_id and session_id in self.sessions:
                self.sessions[session_id].message_count += 1
                self.sessions[session_id].last_active = time.time()

            self._tick_ops()

    def record_tool_call(
        self,
        tool_name: str,
        success: bool = True,
    ) -> None:
        """记录工具调用"""
        with self._lock:
            self.tools.total_calls += 1
            if success:
                self.tools.success_count += 1
            else:
                self.tools.error_count += 1
            self.tools.by_tool[tool_name] = self.tools.by_tool.get(tool_name, 0) + 1
            self._tick_ops()

    def record_api_call(
        self,
        provider: str,
        model: str,
        tokens_in: int = 0,
        tokens_out: int = 0,
    ) -> None:
        """记录 API 调用"""
        with self._lock:
            self.costs.record(provider, model, tokens_in, tokens_out)
            self._tick_ops()

    def record_error(
        self,
        error_type: str,
        message: str,
        context: Optional[str] = None,
    ) -> None:
        """记录错误"""
        with self._lock:
            record = ErrorRecord(
                error_type=error_type,
                message=message,
                timestamp=time.time(),
                context=context,
            )
            self.errors.append(record)
            # 超过上限时裁剪
            if len(self.errors) > self._max_errors:
                self.errors = self.errors[-self._max_errors:]
            self._tick_ops()

    # ── Session 管理 ──────────────────────────────────────────────

    def start_session(
        self,
        session_id: str,
        channel: str = "unknown",
    ) -> SessionInfo:
        """创建新会话"""
        now = time.time()
        info = SessionInfo(
            session_id=session_id,
            started_at=now,
            last_active=now,
            channel=channel,
        )
        with self._lock:
            self.sessions[session_id] = info
        return info

    def end_session(self, session_id: str) -> None:
        """结束会话"""
        with self._lock:
            self.sessions.pop(session_id, None)

    def get_active_sessions(self) -> list[SessionInfo]:
        """获取所有活跃会话"""
        return list(self.sessions.values())

    # ── 汇总 ──────────────────────────────────────────────────────

    def get_summary(self) -> dict[str, Any]:
        """获取状态汇总"""
        uptime = time.time() - self.started_at
        return {
            "uptime_seconds": round(uptime, 1),
            "messages": self.messages.to_dict(),
            "tools": self.tools.to_dict(),
            "costs": self.costs.to_dict(),
            "error_count": len(self.errors),
            "active_sessions": len(self.sessions),
            "last_save": self.last_save,
        }

    # ── 持久化 ────────────────────────────────────────────────────

    def save(self) -> None:
        """保存状态到文件"""
        with self._lock:
            data = {
                "version": 1,
                "started_at": self.started_at,
                "saved_at": time.time(),
                "messages": self.messages.to_dict(),
                "tools": self.tools.to_dict(),
                "costs": self.costs.to_dict(),
                "errors": [e.to_dict() for e in self.errors],
                "sessions": {k: v.to_dict() for k, v in self.sessions.items()},
            }
            self._state_dir.mkdir(parents=True, exist_ok=True)
            tmp_file = self._state_file.with_suffix(".tmp")
            try:
                tmp_file.write_text(
                    json.dumps(data, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                # 原子替换
                if os.name == "nt":
                    # Windows 不支持 os.replace 到已存在文件，先删
                    if self._state_file.exists():
                        self._state_file.unlink()
                tmp_file.rename(self._state_file)
            except OSError:
                # 回退：直接写
                try:
                    self._state_file.write_text(
                        json.dumps(data, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                except OSError:
                    pass
                finally:
                    if tmp_file.exists():
                        try:
                            tmp_file.unlink()
                        except OSError:
                            pass
            self.last_save = time.time()
            self._ops_since_save = 0

    def load(self) -> bool:
        """从文件加载状态，返回是否成功"""
        if not self._state_file.exists():
            return False
        try:
            data = json.loads(self._state_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return False

        with self._lock:
            self.started_at = data.get("started_at", self.started_at)
            self.messages = MessageStats.from_dict(data.get("messages", {}))
            self.tools = ToolStats.from_dict(data.get("tools", {}))
            self.costs = CostTracker.from_dict(data.get("costs", {}))
            self.errors = [
                ErrorRecord.from_dict(e) for e in data.get("errors", [])
            ]
            self.sessions = {
                k: SessionInfo.from_dict(v)
                for k, v in data.get("sessions", {}).items()
            }
            self.last_save = data.get("saved_at", 0.0)
        return True

    # ── 内部 ──────────────────────────────────────────────────────

    def _tick_ops(self) -> None:
        """操作计数，达到阈值自动保存"""
        self._ops_since_save += 1
        now = time.time()
        if (
            self._ops_since_save >= STATE_SAVE_OPS_THRESHOLD
            or (self.last_save > 0 and now - self.last_save >= STATE_SAVE_INTERVAL)
        ):
            # 在锁内触发保存（_tick_ops 已在锁内调用）
            # 释放锁后再保存，避免死锁
            pass  # 实际保存由外部调度或显式调用

    def reset(self) -> None:
        """重置所有状态"""
        with self._lock:
            self.messages = MessageStats()
            self.tools = ToolStats()
            self.costs = CostTracker()
            self.errors = []
            self.sessions = {}
            self.started_at = time.time()
            self.last_save = 0.0
            self._ops_since_save = 0
