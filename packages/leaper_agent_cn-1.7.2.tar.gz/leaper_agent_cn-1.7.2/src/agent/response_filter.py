"""响应过滤器

对 LLM 响应进行清理：移除工具调用痕迹、thinking tags、内部标记等，
确保返回给用户的内容干净可读。
"""

from __future__ import annotations

import re


class ResponseFilter:
    """响应内容过滤器"""

    # 默认最大回复长度（字符）
    DEFAULT_MAX_LENGTH = 8000

    def __init__(self, max_length: int = DEFAULT_MAX_LENGTH) -> None:
        self.max_length = max_length

    def filter(self, response: str) -> str:
        """过滤响应内容（完整流水线）

        依次执行：
        1. 移除 thinking tags
        2. 移除工具调用痕迹
        3. 清理格式
        4. 截断过长回复
        """
        if not response:
            return ""
        text = self.remove_thinking(response)
        text = self.remove_tool_traces(text)
        text = self.clean_formatting(text)
        text = self._truncate(text)
        return text

    def remove_tool_traces(self, text: str) -> str:
        """移除工具调用痕迹（对用户不可见的内部标记）"""
        # <tool_call>...</tool_call>
        text = re.sub(r"<tool_call>.*?</tool_call>", "", text, flags=re.DOTALL)
        # <tool_result>...</tool_result>
        text = re.sub(r"<tool_result>.*?</tool_result>", "", text, flags=re.DOTALL)
        # <function_call>...</function_call>
        text = re.sub(r"<function_call>.*?</function_call>", "", text, flags=re.DOTALL)
        # [tool: xxx] 或 [Tool: xxx]
        text = re.sub(r"\[(?:t|T)ool:\s*[^\]]*\]", "", text)
        # ```tool_code ... ``` 块
        text = re.sub(r"```tool_code\n.*?```", "", text, flags=re.DOTALL)
        return text

    def remove_thinking(self, text: str) -> str:
        """移除 thinking / reasoning 标签"""
        # <thinking>...</thinking>
        text = re.sub(r"<thinking>.*?</thinking>", "", text, flags=re.DOTALL)
        # <think>...</think>（DeepSeek 格式）
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
        # <reasoning>...</reasoning>
        text = re.sub(r"<reasoning>.*?</reasoning>", "", text, flags=re.DOTALL)
        # <inner_thought>...</inner_thought>
        text = re.sub(r"<inner_thought>.*?</inner_thought>", "", text, flags=re.DOTALL)
        return text

    def clean_formatting(self, text: str) -> str:
        """清理格式问题"""
        # 连续 3 个及以上空行 → 2 个空行
        text = re.sub(r"\n{3,}", "\n\n", text)
        # 行首尾多余空格
        lines = text.split("\n")
        lines = [line.rstrip() for line in lines]
        text = "\n".join(lines)
        # 首尾空白
        text = text.strip()
        return text

    def _truncate(self, text: str) -> str:
        """截断过长回复"""
        if len(text) <= self.max_length:
            return text
        # 在 max_length 附近找段落边界
        cut = text[:self.max_length]
        last_para = cut.rfind("\n\n")
        if last_para > self.max_length * 0.7:
            cut = cut[:last_para]
        return cut.rstrip() + "\n\n…（回复已截断）"
