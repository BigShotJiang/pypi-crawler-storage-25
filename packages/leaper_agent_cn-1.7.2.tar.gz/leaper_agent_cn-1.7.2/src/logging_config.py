"""日志配置 - 结构化日志、轮转、脱敏"""

from __future__ import annotations

import json
import logging
import os
import time
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Optional

from .agent.redact import redact_sensitive
from .constants import LOG_BACKUP_COUNT, LOG_DIR


class JsonFormatter(logging.Formatter):
    """JSON 格式日志格式化器"""

    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "message": redact_sensitive(record.getMessage()),
        }
        if record.exc_info and record.exc_info[1]:
            log_data["exception"] = str(record.exc_info[1])
        # 附加额外字段
        for key in ("provider", "model", "tokens", "latency", "tool_name", "result_len"):
            val = getattr(record, key, None)
            if val is not None:
                log_data[key] = val
        return json.dumps(log_data, ensure_ascii=False)


class RedactFilter(logging.Filter):
    """敏感信息脱敏过滤器"""

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = redact_sensitive(record.msg)
        return True


def setup_logging(
    level: str = "INFO",
    log_dir: Optional[str] = None,
    console: bool = True,
) -> logging.Logger:
    """配置日志系统

    Args:
        level: 日志级别（DEBUG/INFO/WARNING/ERROR）
        log_dir: 日志文件目录（None 则不写文件）
        console: 是否输出到控制台

    Returns:
        根 logger
    """
    root_logger = logging.getLogger("leaper")
    root_logger.setLevel(logging.DEBUG)

    # 清除已有 handler（避免重复添加）
    root_logger.handlers.clear()

    # 控制台 handler（INFO+）
    if console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(getattr(logging, level.upper(), logging.INFO))
        console_handler.setFormatter(
            logging.Formatter("[%(levelname)s] %(name)s: %(message)s")
        )
        console_handler.addFilter(RedactFilter())
        root_logger.addHandler(console_handler)

    # 文件 handler（DEBUG+，按天轮转）
    if log_dir:
        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        file_handler = TimedRotatingFileHandler(
            filename=str(log_path / "leaper.log"),
            when="midnight",
            interval=1,
            backupCount=LOG_BACKUP_COUNT,
            encoding="utf-8",
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(JsonFormatter())
        file_handler.addFilter(RedactFilter())
        root_logger.addHandler(file_handler)

    return root_logger


def get_logger(module: str) -> logging.Logger:
    """获取模块 logger

    约定模块名：agent, gateway, brain, tools, security, skills
    """
    return logging.getLogger(f"leaper.{module}")


def log_api_call(
    provider: str,
    model: str,
    tokens: int,
    latency: float,
) -> None:
    """记录 API 调用日志"""
    logger = logging.getLogger("leaper.api")
    logger.info(
        "API 调用: %s/%s, tokens=%d, latency=%.2fs",
        provider, model, tokens, latency,
        extra={"provider": provider, "model": model, "tokens": tokens, "latency": latency},
    )


def log_tool_call(
    tool_name: str,
    args: dict,
    result_len: int,
) -> None:
    """记录工具调用日志"""
    logger = logging.getLogger("leaper.tools")
    args_summary = {k: str(v)[:50] for k, v in (args or {}).items()}
    logger.info(
        "工具调用: %s, args=%s, result_len=%d",
        tool_name, args_summary, result_len,
        extra={"tool_name": tool_name, "result_len": result_len},
    )
