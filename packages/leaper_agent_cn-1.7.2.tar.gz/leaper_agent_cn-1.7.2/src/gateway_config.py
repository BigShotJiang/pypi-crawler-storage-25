"""网关配置解析和验证

从 leaper.yaml 的 `gateway:` 段读取配置，支持环境变量覆盖。
"""
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# 支持的渠道名称
SUPPORTED_CHANNELS = {"feishu", "dingtalk", "wecom", "wechat", "weixin", "qqbot", "cli"}

# 环境变量前缀
ENV_PREFIX = "LEAPER_GATEWAY_"

# 渠道必填字段
CHANNEL_REQUIRED_FIELDS: Dict[str, List[str]] = {
    "feishu": ["app_id", "app_secret"],
    "dingtalk": ["app_key", "app_secret"],
    "wecom": ["corp_id", "agent_id", "secret"],
    "wechat": ["app_id", "app_secret", "token"],
    "weixin": ["app_id", "app_secret", "token"],
    "qqbot": ["app_id", "app_secret"],
    "cli": [],
}


@dataclass
class ChannelConfig:
    """单个渠道配置"""
    name: str
    enabled: bool = True
    config: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> List[str]:
        """验证渠道配置，返回错误列表"""
        errors: List[str] = []
        required = CHANNEL_REQUIRED_FIELDS.get(self.name, [])
        for f in required:
            if f not in self.config or not self.config[f]:
                errors.append(f"渠道 [{self.name}] 缺少必填字段: {f}")
        return errors


@dataclass
class GatewayConfig:
    """网关配置

    Attributes:
        host: 监听地址
        port: 监听端口
        channels: 渠道配置 {name: config_dict}
        session_timeout: session 过期时间（秒）
        max_concurrent: 最大并发消息处理数
        log_level: 日志级别
        session_dir: session 持久化目录
        webhook_prefix: webhook 路径前缀
    """
    host: str = "0.0.0.0"
    port: int = 8080
    channels: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    session_timeout: int = 86400  # 24 小时
    max_concurrent: int = 10
    log_level: str = "INFO"
    session_dir: str = ".sessions"
    webhook_prefix: str = "/webhook"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GatewayConfig":
        """从字典创建配置

        Args:
            data: 配置字典（通常从 leaper.yaml 的 gateway 段读取）

        Returns:
            GatewayConfig 实例
        """
        config = cls(
            host=data.get("host", cls.host),
            port=data.get("port", cls.port),
            channels=data.get("channels", {}),
            session_timeout=data.get("session_timeout", cls.session_timeout),
            max_concurrent=data.get("max_concurrent", cls.max_concurrent),
            log_level=data.get("log_level", cls.log_level),
            session_dir=data.get("session_dir", cls.session_dir),
            webhook_prefix=data.get("webhook_prefix", cls.webhook_prefix),
        )
        # 应用环境变量覆盖
        config._apply_env_overrides()
        return config

    @classmethod
    def from_yaml(cls, yaml_path: str) -> "GatewayConfig":
        """从 YAML 文件加载配置

        Args:
            yaml_path: YAML 文件路径

        Returns:
            GatewayConfig 实例
        """
        import yaml
        with open(yaml_path, "r", encoding="utf-8") as f:
            full_config = yaml.safe_load(f) or {}
        gateway_data = full_config.get("gateway", {})
        return cls.from_dict(gateway_data)

    def _apply_env_overrides(self) -> None:
        """应用环境变量覆盖

        支持的环境变量：
        - LEAPER_GATEWAY_HOST
        - LEAPER_GATEWAY_PORT
        - LEAPER_GATEWAY_SESSION_TIMEOUT
        - LEAPER_GATEWAY_MAX_CONCURRENT
        - LEAPER_GATEWAY_LOG_LEVEL
        """
        env_map = {
            f"{ENV_PREFIX}HOST": ("host", str),
            f"{ENV_PREFIX}PORT": ("port", int),
            f"{ENV_PREFIX}SESSION_TIMEOUT": ("session_timeout", int),
            f"{ENV_PREFIX}MAX_CONCURRENT": ("max_concurrent", int),
            f"{ENV_PREFIX}LOG_LEVEL": ("log_level", str),
        }

        for env_key, (attr, converter) in env_map.items():
            val = os.environ.get(env_key)
            if val is not None:
                try:
                    setattr(self, attr, converter(val))
                    logger.debug("环境变量覆盖: %s=%s", env_key, val)
                except (ValueError, TypeError) as e:
                    logger.warning("环境变量 %s 值无效: %s", env_key, e)

    def validate(self) -> List[str]:
        """验证配置，返回错误列表

        Returns:
            错误消息列表，空列表表示配置有效
        """
        errors: List[str] = []

        # 端口范围
        if not (1 <= self.port <= 65535):
            errors.append(f"端口范围无效: {self.port}（需要 1-65535）")

        # session_timeout
        if self.session_timeout < 60:
            errors.append(f"session_timeout 太短: {self.session_timeout}（最小 60 秒）")

        # max_concurrent
        if self.max_concurrent < 1:
            errors.append(f"max_concurrent 无效: {self.max_concurrent}（最小 1）")

        # 渠道验证
        for name, ch_config in self.channels.items():
            if name not in SUPPORTED_CHANNELS:
                errors.append(f"未知渠道: {name}，支持: {SUPPORTED_CHANNELS}")
                continue
            ch = ChannelConfig(name=name, config=ch_config)
            errors.extend(ch.validate())

        return errors

    def is_valid(self) -> bool:
        """配置是否有效"""
        return len(self.validate()) == 0

    def get_channel_config(self, name: str) -> Optional[Dict[str, Any]]:
        """获取指定渠道的配置"""
        return self.channels.get(name)

    def get_enabled_channels(self) -> List[str]:
        """获取所有已配置的渠道名称"""
        return list(self.channels.keys())

    def get_webhook_path(self, channel_name: str) -> str:
        """获取渠道的 webhook 路径"""
        return f"{self.webhook_prefix}/{channel_name}"

    def to_dict(self) -> Dict[str, Any]:
        """转为字典"""
        return {
            "host": self.host,
            "port": self.port,
            "channels": self.channels,
            "session_timeout": self.session_timeout,
            "max_concurrent": self.max_concurrent,
            "log_level": self.log_level,
            "session_dir": self.session_dir,
            "webhook_prefix": self.webhook_prefix,
        }
