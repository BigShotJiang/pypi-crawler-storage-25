"""配置管理 — 加载 leaper.yaml"""
from dataclasses import dataclass, field
import base64
from pathlib import Path
from typing import Any, Union

import yaml


DEFAULT_CONFIG_PATH = Path.home() / ".leaper-cn" / "leaper.yaml"


@dataclass
class ProviderConfig:
    name: str = "openai-compatible"
    model: str = "gpt-4o"
    api_key: str = ""
    base_url: str = "https://api.openai.com/v1"


@dataclass
class ChannelConfig:
    type: str = "cli"  # cli / feishu / dingtalk / wechat
    extra: dict = field(default_factory=dict)


@dataclass
class BrainConfig:
    enabled: bool = True
    db_path: str = str(Path("~/.leaper-cn/brain.db").expanduser())
    evolution_l1: bool = True
    evolution_l2: bool = True
    evolution_l3: bool = False


@dataclass
class AgentConfig:
    name: str = "leaper-agent"
    role: str = "assistant"
    industry: str = ""
    workspace: str = str(Path("~/.leaper-cn/workspaces/default").expanduser())


@dataclass
class LeaperConfig:
    provider: ProviderConfig = field(default_factory=ProviderConfig)
    channel: ChannelConfig = field(default_factory=ChannelConfig)
    brain: BrainConfig = field(default_factory=BrainConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)

    @classmethod
    def load(cls, path: Union[Path, str, None] = None) -> "LeaperConfig":
        """从 YAML 文件加载配置"""
        config_path = Path(path) if path else DEFAULT_CONFIG_PATH
        if not config_path.exists():
            return cls()

        with open(config_path, "r", encoding="utf-8") as f:
            raw: dict = yaml.safe_load(f) or {}

        cfg = cls()
        if "provider" in raw:
            provider_raw = {k: v for k, v in raw["provider"].items() if k in ProviderConfig.__dataclass_fields__}
            # api_key base64 解码，兼容旧明文格式
            if "api_key" in provider_raw and provider_raw["api_key"]:
                raw_key = provider_raw["api_key"]
                try:
                    provider_raw["api_key"] = base64.b64decode(raw_key).decode()
                except Exception:
                    provider_raw["api_key"] = raw_key
            cfg.provider = ProviderConfig(**provider_raw)
        if "channel" in raw:
            ch = raw["channel"]
            cfg.channel = ChannelConfig(type=ch.get("type", "cli"), extra={k: v for k, v in ch.items() if k != "type"})
        if "brain" in raw:
            cfg.brain = BrainConfig(**{k: v for k, v in raw["brain"].items() if k in BrainConfig.__dataclass_fields__})
        if "agent" in raw:
            cfg.agent = AgentConfig(**{k: v for k, v in raw["agent"].items() if k in AgentConfig.__dataclass_fields__})

        return cfg

    def save(self, path: Union[Path, str, None] = None) -> None:
        """保存配置到 YAML"""
        config_path = Path(path) if path else DEFAULT_CONFIG_PATH
        config_path.parent.mkdir(parents=True, exist_ok=True)

        data: dict[str, Any] = {
            "provider": {
                "name": self.provider.name,
                "model": self.provider.model,
                "api_key": base64.b64encode(self.provider.api_key.encode()).decode() if self.provider.api_key else "",
                "base_url": self.provider.base_url,
            },
            "channel": {"type": self.channel.type, **self.channel.extra},
            "brain": {
                "enabled": self.brain.enabled,
                "db_path": self.brain.db_path,
                "evolution_l1": self.brain.evolution_l1,
                "evolution_l2": self.brain.evolution_l2,
                "evolution_l3": self.brain.evolution_l3,
            },
            "agent": {
                "name": self.agent.name,
                "role": self.agent.role,
                "industry": self.agent.industry,
                "workspace": self.agent.workspace,
            },
        }

        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)

    def get_nested(self, dotted_key: str) -> Any:
        """支持 dot notation 读取配置值

        例: config.get_nested("provider.model") → "deepseek-v4-flash"
        """
        # 先检查环境变量覆盖: provider.model → LEAPER_PROVIDER_MODEL
        import os
        env_key = "LEAPER_" + dotted_key.upper().replace(".", "_")
        env_val = os.environ.get(env_key)
        if env_val is not None:
            return env_val

        parts = dotted_key.split(".")
        obj: Any = self
        for part in parts:
            if hasattr(obj, part):
                obj = getattr(obj, part)
            elif isinstance(obj, dict) and part in obj:
                obj = obj[part]
            else:
                return None
        return obj

    def set_nested(self, dotted_key: str, value: Any) -> bool:
        """支持 dot notation 写入配置值

        例: config.set_nested("provider.model", "qwen-max")
        返回是否成功
        """
        parts = dotted_key.split(".")
        if len(parts) == 1:
            if hasattr(self, parts[0]):
                setattr(self, parts[0], value)
                return True
            return False

        obj: Any = self
        for part in parts[:-1]:
            if hasattr(obj, part):
                obj = getattr(obj, part)
            else:
                return False

        attr = parts[-1]
        if hasattr(obj, attr):
            # 类型转换
            current = getattr(obj, attr)
            if isinstance(current, bool):
                value = str(value).lower() in ("true", "1", "yes")
            elif isinstance(current, int):
                try:
                    value = int(value)
                except (ValueError, TypeError):
                    return False
            setattr(obj, attr, value)
            return True
        return False

    def to_display_dict(self, mask_secrets: bool = True) -> dict[str, Any]:
        """输出脱敏后的配置字典，用于显示"""
        d: dict[str, Any] = {
            "provider.name": self.provider.name,
            "provider.model": self.provider.model,
            "provider.api_key": self._mask(self.provider.api_key) if mask_secrets else self.provider.api_key,
            "provider.base_url": self.provider.base_url,
            "channel.type": self.channel.type,
            "brain.enabled": self.brain.enabled,
            "brain.db_path": self.brain.db_path,
            "agent.name": self.agent.name,
            "agent.role": self.agent.role,
            "agent.industry": self.agent.industry,
            "agent.workspace": self.agent.workspace,
        }
        return d

    @staticmethod
    def _mask(secret: str) -> str:
        """脱敏处理：只显示前3位和后3位"""
        if not secret:
            return "(未设置)"
        if len(secret) <= 8:
            return secret[:2] + "***"
        return secret[:3] + "***" + secret[-3:]


class ConfigManager:
    """高级配置管理器

    在 LeaperConfig 之上提供：配置文件查找、环境变量合并、
    dot notation 访问、脱敏输出、分组获取等功能。
    """

    SEARCH_PATHS = [
        Path.cwd() / "leaper.yaml",
        Path.home() / ".leaper-cn" / "leaper.yaml",
        Path("/etc/leaper-cn/leaper.yaml"),
    ]

    def __init__(self, config_path: str = None) -> None:
        self.path = config_path or self._find_config()
        self.config: LeaperConfig = LeaperConfig()
        self._env_overrides: dict[str, str] = {}

    def _find_config(self) -> str:
        """查找配置文件：cwd → ~/.leaper-cn/ → /etc/leaper-cn/"""
        for p in self.SEARCH_PATHS:
            if p.exists():
                return str(p)
        return str(DEFAULT_CONFIG_PATH)

    def load(self) -> None:
        """加载配置 + 环境变量覆盖"""
        self.config = LeaperConfig.load(self.path)
        self.merge_env()

    def get(self, key: str, default=None):
        """支持 dot notation: config.get('provider.model')"""
        val = self.config.get_nested(key)
        return val if val is not None else default

    def set(self, key: str, value) -> None:
        """设置值"""
        self.config.set_nested(key, value)

    def save(self) -> None:
        """保存到文件"""
        self.config.save(self.path)

    def validate(self) -> list[str]:
        """验证配置完整性"""
        return validate_config(self.config)

    def get_masked(self) -> dict:
        """返回脱敏后的配置（API key → sk-***）"""
        return self.config.to_display_dict(mask_secrets=True)

    def merge_env(self) -> None:
        """合并环境变量 LEAPER_* 到配置"""
        import os
        prefix = "LEAPER_"
        for key, value in os.environ.items():
            if key.startswith(prefix):
                # LEAPER_PROVIDER_MODEL → provider.model
                dotted = key[len(prefix):].lower().replace("_", ".", 1)
                # 尝试更深的 dot notation
                parts = key[len(prefix):].lower().split("_", 1)
                if len(parts) == 2:
                    dotted = f"{parts[0]}.{parts[1]}"
                else:
                    dotted = parts[0]
                self._env_overrides[key] = value

    def get_provider_config(self) -> dict:
        """获取 provider 配置"""
        p = self.config.provider
        return {
            "name": p.name,
            "model": p.model,
            "api_key": p.api_key,
            "base_url": p.base_url,
        }

    def get_brain_config(self) -> dict:
        """获取 brain 配置"""
        b = self.config.brain
        return {
            "enabled": b.enabled,
            "db_path": b.db_path,
            "evolution_l1": b.evolution_l1,
            "evolution_l2": b.evolution_l2,
            "evolution_l3": b.evolution_l3,
        }

    def get_gateway_config(self) -> dict:
        """获取 gateway 配置（预留）"""
        return {
            "channel_type": self.config.channel.type,
            "channel_extra": self.config.channel.extra,
        }

    def export_env(self) -> dict:
        """导出为环境变量格式"""
        d = self.config.to_display_dict(mask_secrets=False)
        result = {}
        for key, value in d.items():
            env_key = "LEAPER_" + key.upper().replace(".", "_")
            result[env_key] = str(value)
        return result


def validate_config(config: LeaperConfig) -> list[str]:
    """验证配置完整性，返回问题列表（空列表表示全部通过）"""
    issues: list[str] = []

    # 必填项检查
    if not config.provider.api_key:
        issues.append("provider.api_key 未配置")
    if not config.provider.base_url:
        issues.append("provider.base_url 未配置")
    if not config.provider.model:
        issues.append("provider.model 未配置")

    # API key 格式粗略检查
    key = config.provider.api_key
    if key and len(key) < 10:
        issues.append("provider.api_key 长度异常（< 10 字符）")

    # base_url 格式检查
    url = config.provider.base_url
    if url and not (url.startswith("http://") or url.startswith("https://")):
        issues.append("provider.base_url 必须以 http:// 或 https:// 开头")

    # workspace 路径
    ws = config.agent.workspace
    if ws:
        ws_path = Path(ws).expanduser()
        if not ws_path.exists():
            issues.append(f"agent.workspace 目录不存在: {ws}")

    return issues
