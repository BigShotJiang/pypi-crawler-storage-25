"""MCP (Model Context Protocol) 客户端 - JSON-RPC 2.0

支持 stdio 和 HTTP 两种传输方式，实现完整的 MCP 协议：
- tools/list + tools/call
- resources/list + resources/read
- 自动重连（指数退避）
- 超时控制
- 优雅降级

参考: Hermes Agent mcp_tool.py，简化为纯 asyncio 实现（无需 mcp SDK）
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 安全：凭证过滤
# ---------------------------------------------------------------------------
_CREDENTIAL_PATTERN = re.compile(
    r"(?:ghp_[A-Za-z0-9_]{1,255}"
    r"|sk-[A-Za-z0-9_]{1,255}"
    r"|Bearer\s+\S+"
    r"|token=[^\s&,;\"']{1,255}"
    r"|key=[^\s&,;\"']{1,255}"
    r"|secret=[^\s&,;\"']{1,255})",
    re.IGNORECASE,
)

# 允许传递给子进程的安全环境变量
_SAFE_ENV_KEYS = frozenset({
    "PATH", "HOME", "USER", "LANG", "LC_ALL", "TERM", "SHELL", "TMPDIR",
    "USERPROFILE", "SYSTEMROOT", "COMSPEC",  # Windows 兼容
})

# 默认超时（秒）
DEFAULT_TOOL_TIMEOUT = 120
DEFAULT_CONNECT_TIMEOUT = 60
DEFAULT_READ_TIMEOUT = 30
MAX_RECONNECT_RETRIES = 5
MAX_BACKOFF_SECONDS = 60


def _sanitize_error(text: str) -> str:
    """从错误消息中移除凭证信息"""
    return _CREDENTIAL_PATTERN.sub("[REDACTED]", text)


def _build_safe_env(user_env: Optional[dict] = None) -> dict:
    """构建安全的子进程环境变量，只传递安全变量 + 用户显式指定的变量"""
    env: dict[str, str] = {}
    for key, value in os.environ.items():
        if key in _SAFE_ENV_KEYS or key.startswith("XDG_"):
            env[key] = value
    if user_env:
        env.update(user_env)
    return env


class MCPClient:
    """MCP 协议客户端，支持 stdio 和 HTTP transport

    用法:
        client = MCPClient(transport="stdio")
        await client.connect({"command": "npx", "args": ["-y", "@some/server"]})
        tools = await client.list_tools()
        result = await client.call_tool("calculator", {"expr": "1+1"})
        await client.disconnect()
    """

    def __init__(self, transport: str = "stdio"):
        self._transport = transport
        self._tools: list[dict] = []
        self._resources: list[dict] = []
        self._next_id = 1
        self._connected = False
        self._server_name: str = ""

        # stdio transport 状态
        self._process: Optional[asyncio.subprocess.Process] = None

        # http transport 状态
        self._http_url: Optional[str] = None
        self._http_headers: dict[str, str] = {}

        # 超时配置
        self._tool_timeout: float = DEFAULT_TOOL_TIMEOUT
        self._connect_timeout: float = DEFAULT_CONNECT_TIMEOUT

        # 重连状态
        self._reconnect_retries = 0
        self._server_config: Optional[dict] = None

        # 初始化信息（MCP initialize 握手）
        self._server_info: Optional[dict] = None
        self._server_capabilities: Optional[dict] = None

    @property
    def connected(self) -> bool:
        """是否已连接"""
        return self._connected

    @property
    def server_name(self) -> str:
        return self._server_name

    @property
    def tools(self) -> list[dict]:
        """缓存的工具列表"""
        return self._tools

    @property
    def server_capabilities(self) -> Optional[dict]:
        return self._server_capabilities

    # ========== 连接管理 ==========

    async def connect(self, server_config: dict) -> None:
        """统一连接入口，根据配置自动选择 transport

        server_config 格式:
            stdio: {"command": "npx", "args": [...], "env": {}, "name": "..."}
            http:  {"url": "http://...", "headers": {}, "name": "..."}
        """
        self._server_config = server_config
        self._server_name = server_config.get("name", "unnamed")
        self._tool_timeout = server_config.get("timeout", DEFAULT_TOOL_TIMEOUT)
        self._connect_timeout = server_config.get("connect_timeout", DEFAULT_CONNECT_TIMEOUT)

        transport = server_config.get("transport", self._transport)
        self._transport = transport

        try:
            if transport == "stdio":
                await self._connect_stdio(server_config)
            elif transport in ("http", "sse"):
                await self._connect_http(server_config)
            else:
                raise ValueError(f"不支持的 transport: {transport}")

            # MCP 协议握手 (initialize)
            await self._initialize()
            self._connected = True
            self._reconnect_retries = 0
            logger.info("MCP 服务器已连接: %s (transport=%s)", self._server_name, transport)

        except Exception as e:
            self._connected = False
            logger.error("MCP 连接失败 [%s]: %s", self._server_name, _sanitize_error(str(e)))
            raise

    async def _connect_stdio(self, config: dict) -> None:
        """通过 stdio 连接 MCP server — 启动子进程，通过 stdin/stdout 通信"""
        command = config.get("command", "")
        args = config.get("args", [])
        user_env = config.get("env", {})

        if not command:
            raise ValueError("stdio transport 需要 command 参数")

        env = _build_safe_env(user_env)

        try:
            self._process = await asyncio.wait_for(
                asyncio.create_subprocess_exec(
                    command, *args,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    env=env,
                ),
                timeout=self._connect_timeout,
            )
        except FileNotFoundError:
            raise RuntimeError(f"MCP 命令未找到: {command}（请确认已安装）")
        except asyncio.TimeoutError:
            raise RuntimeError(f"MCP 启动超时（{self._connect_timeout}s）: {command}")

    async def _connect_http(self, config: dict) -> None:
        """连接 HTTP/SSE MCP server"""
        url = config.get("url", "")
        if not url:
            raise ValueError("http transport 需要 url 参数")
        self._http_url = url
        self._http_headers = config.get("headers", {})

    async def disconnect(self) -> None:
        """断开连接，清理资源"""
        if self._process:
            try:
                # 发送 shutdown 通知（best-effort）
                try:
                    await asyncio.wait_for(
                        self._send_notification("notifications/cancelled", {}),
                        timeout=2,
                    )
                except Exception:
                    pass

                self._process.terminate()
                try:
                    await asyncio.wait_for(self._process.wait(), timeout=5)
                except asyncio.TimeoutError:
                    self._process.kill()
                    await self._process.wait()
            except ProcessLookupError:
                pass  # 进程已退出
            self._process = None

        self._http_url = None
        self._connected = False
        self._tools = []
        self._resources = []
        self._server_info = None
        self._server_capabilities = None
        logger.info("MCP 已断开: %s", self._server_name)

    async def reconnect(self) -> bool:
        """重连（指数退避），返回是否成功"""
        if not self._server_config:
            return False

        if self._reconnect_retries >= MAX_RECONNECT_RETRIES:
            logger.error("MCP 重连次数已达上限 [%s]", self._server_name)
            return False

        self._reconnect_retries += 1
        backoff = min(2 ** self._reconnect_retries, MAX_BACKOFF_SECONDS)
        logger.info("MCP 重连中 [%s]，第 %d 次，等待 %.1fs",
                     self._server_name, self._reconnect_retries, backoff)
        await asyncio.sleep(backoff)

        try:
            await self.disconnect()
            await self.connect(self._server_config)
            return True
        except Exception as e:
            logger.warning("MCP 重连失败 [%s]: %s", self._server_name, _sanitize_error(str(e)))
            return False

    # ========== MCP 协议方法 ==========

    async def _initialize(self) -> None:
        """MCP 协议初始化握手"""
        resp = await self._send_request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "roots": {"listChanged": False},
            },
            "clientInfo": {
                "name": "leaper-cn",
                "version": "1.0.0",
            },
        })
        result = resp.get("result", {})
        self._server_info = result.get("serverInfo", {})
        self._server_capabilities = result.get("capabilities", {})

        # 发送 initialized 通知
        await self._send_notification("notifications/initialized", {})

    async def list_tools(self) -> list[dict]:
        """获取 MCP server 支持的工具列表"""
        self._ensure_connected()
        try:
            resp = await self._send_request("tools/list")
            tools = resp.get("result", {}).get("tools", [])
            self._tools = tools
            return tools
        except Exception as e:
            logger.warning("list_tools 失败 [%s]: %s", self._server_name, e)
            return self._tools  # 返回缓存

    async def call_tool(self, name: str, arguments: dict | None = None) -> str:
        """调用 MCP 工具

        Args:
            name: 工具名称
            arguments: 工具参数

        Returns:
            工具返回的文本结果
        """
        self._ensure_connected()
        try:
            resp = await asyncio.wait_for(
                self._send_request("tools/call", {
                    "name": name,
                    "arguments": arguments or {},
                }),
                timeout=self._tool_timeout,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(f"MCP 工具调用超时（{self._tool_timeout}s）: {name}")

        # 检查错误
        if "error" in resp:
            error = resp["error"]
            msg = error.get("message", str(error))
            raise RuntimeError(f"MCP 工具错误 [{name}]: {_sanitize_error(msg)}")

        # 解析 content 数组
        result = resp.get("result", {})
        content = result.get("content", [])
        if content:
            texts = []
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "text":
                        texts.append(item.get("text", ""))
                    elif item.get("type") == "image":
                        texts.append(f"[图片: {item.get('mimeType', 'image/*')}]")
                    elif item.get("type") == "resource":
                        texts.append(f"[资源: {item.get('resource', {}).get('uri', '')}]")
                    else:
                        texts.append(json.dumps(item, ensure_ascii=False))
            return "\n".join(texts) if texts else json.dumps(result, ensure_ascii=False)
        return json.dumps(result, ensure_ascii=False)

    async def list_resources(self) -> list[dict]:
        """获取 MCP server 的资源列表"""
        self._ensure_connected()
        if not self._server_capabilities or not self._server_capabilities.get("resources"):
            return []
        try:
            resp = await self._send_request("resources/list")
            resources = resp.get("result", {}).get("resources", [])
            self._resources = resources
            return resources
        except Exception as e:
            logger.warning("list_resources 失败 [%s]: %s", self._server_name, e)
            return []

    async def read_resource(self, uri: str) -> str:
        """读取 MCP 资源

        Args:
            uri: 资源 URI

        Returns:
            资源内容文本
        """
        self._ensure_connected()
        try:
            resp = await asyncio.wait_for(
                self._send_request("resources/read", {"uri": uri}),
                timeout=DEFAULT_READ_TIMEOUT,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(f"MCP 资源读取超时: {uri}")

        if "error" in resp:
            error = resp["error"]
            raise RuntimeError(f"MCP 资源错误: {_sanitize_error(error.get('message', str(error)))}")

        contents = resp.get("result", {}).get("contents", [])
        if contents:
            texts = []
            for item in contents:
                if isinstance(item, dict):
                    text = item.get("text", "")
                    if text:
                        texts.append(text)
                    elif "blob" in item:
                        texts.append(f"[二进制数据: {item.get('mimeType', 'application/octet-stream')}]")
            return "\n".join(texts)
        return ""

    async def list_prompts(self) -> list[dict]:
        """获取 MCP server 的 prompt 模板列表"""
        self._ensure_connected()
        if not self._server_capabilities or not self._server_capabilities.get("prompts"):
            return []
        try:
            resp = await self._send_request("prompts/list")
            return resp.get("result", {}).get("prompts", [])
        except Exception:
            return []

    # ========== JSON-RPC 传输层 ==========

    def _build_request(self, method: str, params: dict | None = None) -> dict:
        """构建 JSON-RPC 2.0 请求"""
        msg_id = self._next_id
        self._next_id += 1
        msg: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "id": msg_id,
        }
        if params is not None:
            msg["params"] = params
        return msg

    def _build_notification(self, method: str, params: dict | None = None) -> dict:
        """构建 JSON-RPC 2.0 通知（无 id）"""
        msg: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
        }
        if params is not None:
            msg["params"] = params
        return msg

    async def _send_request(self, method: str, params: dict | None = None) -> dict:
        """发送请求并等待响应"""
        request = self._build_request(method, params)
        if self._transport == "stdio":
            return await self._send_stdio(request)
        elif self._transport in ("http", "sse"):
            return await self._send_http(request)
        raise RuntimeError(f"不支持的 transport: {self._transport}")

    async def _send_notification(self, method: str, params: dict | None = None) -> None:
        """发送通知（不等待响应）"""
        notification = self._build_notification(method, params)
        if self._transport == "stdio":
            await self._write_stdio(notification)
        elif self._transport in ("http", "sse"):
            await self._post_http(notification)

    async def _send_stdio(self, request: dict) -> dict:
        """通过 stdio 发送请求并读取响应"""
        if not self._process or not self._process.stdin or not self._process.stdout:
            raise RuntimeError("未连接到 MCP server(stdio)")

        # 检查进程是否存活
        if self._process.returncode is not None:
            raise RuntimeError(f"MCP 进程已退出 (code={self._process.returncode})")

        data = json.dumps(request) + "\n"
        self._process.stdin.write(data.encode())
        await self._process.stdin.drain()

        # 读取响应（跳过通知消息）
        while True:
            try:
                line = await asyncio.wait_for(
                    self._process.stdout.readline(), timeout=self._tool_timeout
                )
            except asyncio.TimeoutError:
                raise RuntimeError(f"MCP 响应超时（{self._tool_timeout}s）")

            if not line:
                raise RuntimeError("MCP server 连接断开")

            try:
                response = json.loads(line.decode())
            except json.JSONDecodeError:
                logger.debug("MCP 忽略非 JSON 行: %s", line[:200])
                continue

            # 跳过通知（无 id 的消息）
            if "id" not in response:
                logger.debug("MCP 收到通知: %s", response.get("method", "unknown"))
                continue

            # 匹配请求 id
            if response.get("id") == request.get("id"):
                return response

            logger.debug("MCP id 不匹配: 期望 %s，收到 %s", request.get("id"), response.get("id"))

    async def _write_stdio(self, message: dict) -> None:
        """通过 stdio 写入消息（不等待响应）"""
        if not self._process or not self._process.stdin:
            return
        data = json.dumps(message) + "\n"
        self._process.stdin.write(data.encode())
        await self._process.stdin.drain()

    async def _send_http(self, request: dict) -> dict:
        """通过 HTTP POST 发送请求"""
        if not self._http_url:
            raise RuntimeError("未连接到 MCP server(HTTP)")

        import urllib.request
        import urllib.error

        data = json.dumps(request).encode("utf-8")
        headers = {
            **self._http_headers,
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(self._http_url, data=data, headers=headers, method="POST")

        loop = asyncio.get_event_loop()
        try:
            response = await asyncio.wait_for(
                loop.run_in_executor(None, lambda: urllib.request.urlopen(req, timeout=int(self._tool_timeout))),
                timeout=self._tool_timeout + 5,
            )
            body = response.read().decode("utf-8")
            return json.loads(body)
        except urllib.error.URLError as e:
            raise RuntimeError(f"MCP HTTP 请求失败: {_sanitize_error(str(e))}")
        except asyncio.TimeoutError:
            raise RuntimeError(f"MCP HTTP 请求超时（{self._tool_timeout}s）")
        except json.JSONDecodeError as e:
            raise RuntimeError(f"MCP HTTP 响应解析失败: {e}")

    async def _post_http(self, message: dict) -> None:
        """通过 HTTP POST 发送通知（不关心响应）"""
        if not self._http_url:
            return
        import urllib.request
        data = json.dumps(message).encode("utf-8")
        headers = {**self._http_headers, "Content-Type": "application/json"}
        req = urllib.request.Request(self._http_url, data=data, headers=headers, method="POST")
        loop = asyncio.get_event_loop()
        try:
            await asyncio.wait_for(
                loop.run_in_executor(None, lambda: urllib.request.urlopen(req, timeout=10)),
                timeout=15,
            )
        except Exception:
            pass  # 通知失败不影响主流程

    # ========== 工具方法 ==========

    def _ensure_connected(self) -> None:
        """确保已连接"""
        if not self._connected:
            raise RuntimeError(f"MCP 未连接: {self._server_name}")

    def get_tool_definitions(self) -> list[dict]:
        """将 MCP 工具转换为标准 tool definition 格式（兼容 OpenAI function calling）

        Returns:
            list of {"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}
        """
        defs = []
        for tool in self._tools:
            name = tool.get("name", "")
            desc = tool.get("description", "")
            schema = tool.get("inputSchema", {"type": "object", "properties": {}})

            # 添加 MCP server 前缀避免命名冲突
            prefixed_name = f"mcp_{self._server_name}_{name}" if self._server_name else f"mcp_{name}"
            # 清理名称（只保留字母数字下划线）
            prefixed_name = re.sub(r"[^a-zA-Z0-9_]", "_", prefixed_name)

            defs.append({
                "type": "function",
                "function": {
                    "name": prefixed_name,
                    "description": f"[MCP:{self._server_name}] {desc}",
                    "parameters": schema,
                },
                "_mcp_server": self._server_name,
                "_mcp_tool": name,
            })
        return defs

    def __repr__(self) -> str:
        status = "已连接" if self._connected else "未连接"
        return f"<MCPClient name={self._server_name!r} transport={self._transport!r} {status} tools={len(self._tools)}>"
