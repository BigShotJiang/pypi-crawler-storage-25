"""MCP Manager — 管理多个 MCP server 连接

负责：
- 从配置加载多个 MCP server
- 批量连接 / 断开
- 汇总所有 server 的 tools，统一注册
- 连接失败优雅降级（不影响其他 server 和主功能）
- 工具调用路由（根据前缀找到正确的 server）
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

from .client import MCPClient

logger = logging.getLogger(__name__)


class MCPManager:
    """MCP 多服务器管理器

    用法:
        manager = MCPManager()
        await manager.load_config(config["mcp_servers"])
        tools = manager.get_all_tool_definitions()
        result = await manager.call_tool("mcp_filesystem_read_file", {"path": "/tmp/a.txt"})
        await manager.shutdown()
    """

    def __init__(self):
        self._clients: dict[str, MCPClient] = {}  # name -> client
        self._tool_map: dict[str, tuple[str, str]] = {}  # prefixed_name -> (server_name, original_name)

    @property
    def clients(self) -> dict[str, MCPClient]:
        return self._clients

    @property
    def connected_count(self) -> int:
        return sum(1 for c in self._clients.values() if c.connected)

    async def load_config(self, servers_config: dict | list) -> None:
        """从配置加载并连接所有 MCP server

        支持两种格式:
        1. dict 格式（Hermes / Claude Desktop 风格）:
            {"server_name": {"command": "npx", "args": [...]}}
        2. list 格式:
            [{"name": "server_name", "command": "npx", "args": [...]}]
        """
        if isinstance(servers_config, list):
            configs = {s.get("name", f"server_{i}"): s for i, s in enumerate(servers_config)}
        elif isinstance(servers_config, dict):
            configs = servers_config
        else:
            logger.warning("MCP 配置格式错误，跳过")
            return

        # 并发连接所有 server
        tasks = []
        for name, config in configs.items():
            if not isinstance(config, dict):
                continue
            # 补充 name 字段
            config.setdefault("name", name)
            # 自动推断 transport
            if "url" in config and "transport" not in config:
                config["transport"] = "http"
            elif "command" in config and "transport" not in config:
                config["transport"] = "stdio"
            tasks.append(self._connect_server(name, config))

        if tasks:
            await asyncio.gather(*tasks)
            # 连接完成后汇总 tools
            await self._refresh_all_tools()

        logger.info("MCP Manager: %d/%d 服务器已连接",
                     self.connected_count, len(self._clients))

    async def _connect_server(self, name: str, config: dict) -> None:
        """连接单个 server，失败时优雅降级"""
        client = MCPClient()
        self._clients[name] = client
        try:
            await client.connect(config)
        except Exception as e:
            logger.warning("MCP 服务器 '%s' 连接失败（已跳过）: %s", name, e)

    async def _refresh_all_tools(self) -> None:
        """刷新所有已连接 server 的工具列表"""
        self._tool_map.clear()
        tasks = []
        for name, client in self._clients.items():
            if client.connected:
                tasks.append(self._refresh_server_tools(name, client))
        if tasks:
            await asyncio.gather(*tasks)

    async def _refresh_server_tools(self, name: str, client: MCPClient) -> None:
        """刷新单个 server 的工具"""
        try:
            await client.list_tools()
            # 建立映射
            for td in client.get_tool_definitions():
                prefixed = td["function"]["name"]
                original = td["_mcp_tool"]
                self._tool_map[prefixed] = (name, original)
        except Exception as e:
            logger.warning("MCP 工具列表获取失败 [%s]: %s", name, e)

    def get_all_tool_definitions(self) -> list[dict]:
        """获取所有 server 的工具定义（合并去重）"""
        defs = []
        for client in self._clients.values():
            if client.connected:
                defs.extend(client.get_tool_definitions())
        return defs

    def is_mcp_tool(self, tool_name: str) -> bool:
        """检查一个工具名是否是 MCP 工具"""
        return tool_name in self._tool_map

    async def call_tool(self, prefixed_name: str, arguments: dict | None = None) -> str:
        """通过前缀名调用 MCP 工具（自动路由到正确的 server）

        Args:
            prefixed_name: 带前缀的工具名（如 mcp_filesystem_read_file）
            arguments: 工具参数

        Returns:
            工具返回文本
        """
        if prefixed_name not in self._tool_map:
            raise ValueError(f"未知的 MCP 工具: {prefixed_name}")

        server_name, original_name = self._tool_map[prefixed_name]
        client = self._clients.get(server_name)
        if not client or not client.connected:
            raise RuntimeError(f"MCP 服务器 '{server_name}' 未连接")

        try:
            return await client.call_tool(original_name, arguments or {})
        except RuntimeError:
            # 尝试重连一次
            logger.info("MCP 工具调用失败，尝试重连 [%s]", server_name)
            if await client.reconnect():
                return await client.call_tool(original_name, arguments or {})
            raise

    async def shutdown(self) -> None:
        """关闭所有连接"""
        tasks = []
        for name, client in self._clients.items():
            if client.connected:
                tasks.append(self._disconnect_safe(name, client))
        if tasks:
            await asyncio.gather(*tasks)
        self._clients.clear()
        self._tool_map.clear()
        logger.info("MCP Manager 已关闭")

    async def _disconnect_safe(self, name: str, client: MCPClient) -> None:
        """安全断开单个 server"""
        try:
            await client.disconnect()
        except Exception as e:
            logger.warning("MCP 断开失败 [%s]: %s", name, e)

    def get_status(self) -> dict:
        """获取所有 server 的状态摘要"""
        servers = {}
        for name, client in self._clients.items():
            servers[name] = {
                "connected": client.connected,
                "transport": client._transport,
                "tools_count": len(client.tools),
                "tools": [t.get("name", "") for t in client.tools],
            }
        return {
            "total": len(self._clients),
            "connected": self.connected_count,
            "total_tools": len(self._tool_map),
            "servers": servers,
        }

    def __repr__(self) -> str:
        return f"<MCPManager servers={len(self._clients)} connected={self.connected_count} tools={len(self._tool_map)}>"
