"""LeaperBrain 核心 — 记忆存储与检索（占位实现）"""


class LeaperBrain:
    """记忆大脑，提供 recall / extract_and_learn 接口"""

    def __init__(self, enabled: bool = True, db_path: str = ""):
        self.enabled = enabled
        self.db_path = db_path

    async def recall(self, query: str, user_id: str = "default", top_k: int = 5) -> list[str]:
        """检索相关记忆片段"""
        # TODO: 接入向量数据库或关键词搜索
        return []

    async def extract_and_learn(self, user_msg: str, reply: str, user_id: str = "default") -> None:
        """从对话中提取知识并学习（异步，不阻塞主流程）"""
        # TODO: 实现记忆提取与持久化
        pass
