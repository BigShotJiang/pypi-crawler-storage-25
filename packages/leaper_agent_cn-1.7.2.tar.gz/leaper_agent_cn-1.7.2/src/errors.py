"""统一错误处理框架

定义 Leaper CN 所有异常层次结构，以及用户友好错误转换。
"""
from __future__ import annotations

import logging
import traceback
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class LeaperError(Exception):
    """基础异常 — 所有 Leaper CN 异常的父类"""

    def __init__(self, message: str, code: Optional[str] = None,
                 details: Optional[Dict[str, Any]] = None) -> None:
        self.code = code
        self.details = details or {}
        super().__init__(message)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}('{self}', code={self.code!r})"


class ConfigError(LeaperError):
    """配置错误"""
    pass


class ProviderError(LeaperError):
    """AI 服务 provider 错误"""
    pass


class ToolError(LeaperError):
    """工具调用错误"""
    pass


class SecurityError(LeaperError):
    """安全策略错误"""
    pass


class BrainError(LeaperError):
    """Brain 知识库错误"""
    pass


class ChannelError(LeaperError):
    """渠道错误（飞书/钉钉/微信等）"""
    pass


class AuthError(LeaperError):
    """认证/授权错误"""
    pass


class RateLimitError(ProviderError):
    """请求频率限制"""
    pass


class TokenExhaustedError(ProviderError):
    """Token 额度耗尽"""
    pass


class TimeoutError(LeaperError):
    """超时错误"""
    pass


class ValidationError(LeaperError):
    """数据验证错误"""
    pass


# 用户友好错误消息映射
_FRIENDLY_MESSAGES: Dict[type, str] = {
    ProviderError: "AI 服务暂时不可用，请稍后重试",
    RateLimitError: "请求太频繁，请等一分钟后再试",
    TokenExhaustedError: "Token 额度已用完，请检查账户余额",
    SecurityError: "该操作被安全策略禁止",
    ConfigError: "配置有误，请运行 leaper-cn doctor 检查",
    BrainError: "知识库操作失败，请检查 brain.db 是否可读写",
    ChannelError: "消息渠道连接失败，请检查渠道配置",
    AuthError: "认证失败，请重新登录",
    TimeoutError: "操作超时，请稍后重试",
    ValidationError: "输入数据格式有误，请检查后重试",
    ToolError: "工具执行失败",
}


def user_friendly_error(error: Exception) -> str:
    """将技术异常转为用户友好消息

    按 MRO 顺序查找最匹配的错误类型。
    """
    for cls in type(error).__mro__:
        if cls in _FRIENDLY_MESSAGES:
            return _FRIENDLY_MESSAGES[cls]
    return "发生未知错误，请稍后重试"


def log_error(error: Exception, context: Optional[Dict[str, Any]] = None) -> None:
    """记录错误日志（详细信息，不泄露给用户）"""
    ctx_str = ""
    if context:
        # 脱敏：过滤可能包含密钥的字段
        safe_ctx = {k: ("***" if "key" in k.lower() or "secret" in k.lower()
                        or "token" in k.lower() or "password" in k.lower()
                        else v)
                    for k, v in context.items()}
        ctx_str = f" | context={safe_ctx}"

    if isinstance(error, LeaperError):
        logger.error(
            "LeaperError: %s (code=%s, details=%s)%s",
            error, error.code, error.details, ctx_str,
        )
    else:
        logger.error(
            "Unexpected error: %s%s\n%s",
            error, ctx_str, traceback.format_exc(),
        )


def wrap_error(error: Exception, target_cls: type = LeaperError,
               code: Optional[str] = None) -> LeaperError:
    """将任意异常包装为 LeaperError"""
    if isinstance(error, LeaperError):
        return error
    return target_cls(str(error), code=code, details={"original": type(error).__name__})
