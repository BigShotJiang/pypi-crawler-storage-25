"""终端渲染器 — ANSI 转义序列实现彩色终端输出"""
from __future__ import annotations

import json
import textwrap
from typing import Any, Dict, Optional


# ANSI 颜色码
class Colors:
    """ANSI 颜色常量"""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"

    # 前景色
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    GRAY = "\033[90m"

    # 背景色
    BG_BLUE = "\033[44m"
    BG_GREEN = "\033[42m"
    BG_RED = "\033[41m"
    BG_YELLOW = "\033[43m"


# 角色对应颜色
ROLE_COLORS = {
    "user": Colors.GREEN,
    "assistant": Colors.CYAN,
    "system": Colors.YELLOW,
    "tool": Colors.MAGENTA,
}

# 角色对应 emoji
ROLE_ICONS = {
    "user": "👤",
    "assistant": "🤖",
    "system": "⚙️",
    "tool": "🔧",
}


class TerminalRenderer:
    """终端渲染器，用 ANSI 转义序列输出彩色文本

    支持消息、工具调用、思考过程、错误、状态栏等渲染。
    """

    def __init__(self, width: int = 80, color_enabled: bool = True) -> None:
        """初始化渲染器

        Args:
            width: 终端宽度（字符数）
            color_enabled: 是否启用颜色
        """
        self.width = width
        self.color_enabled = color_enabled

    def _c(self, color: str, text: str) -> str:
        """给文本加颜色，color_enabled=False 时返回原文"""
        if not self.color_enabled:
            return text
        return f"{color}{text}{Colors.RESET}"

    def render_message(self, role: str, content: str) -> str:
        """渲染聊天消息

        Args:
            role: 角色（user/assistant/system/tool）
            content: 消息内容
        """
        color = ROLE_COLORS.get(role, Colors.WHITE)
        icon = ROLE_ICONS.get(role, "💬")
        header = self._c(f"{Colors.BOLD}{color}", f"{icon} {role.upper()}")
        separator = self._c(Colors.DIM, "─" * self.width)
        # 内容缩进
        wrapped = textwrap.fill(content, width=self.width - 2)
        body = "\n".join(f"  {line}" for line in wrapped.split("\n"))
        return f"{separator}\n{header}\n{body}\n"

    def render_tool_call(self, tool_name: str, args: dict) -> str:
        """渲染工具调用

        Args:
            tool_name: 工具名称
            args: 工具参数
        """
        header = self._c(f"{Colors.BOLD}{Colors.MAGENTA}", f"🔧 调用工具: {tool_name}")
        args_str = json.dumps(args, ensure_ascii=False, indent=2)
        # 限制参数显示长度
        if len(args_str) > 500:
            args_str = args_str[:500] + "\n  ... (截断)"
        body = self._c(Colors.DIM, args_str)
        return f"{header}\n{body}\n"

    def render_thinking(self, text: str) -> str:
        """渲染思考过程

        Args:
            text: 思考内容
        """
        header = self._c(f"{Colors.ITALIC}{Colors.GRAY}", "💭 思考中...")
        # 思考内容用灰色
        wrapped = textwrap.fill(text, width=self.width - 4)
        body = "\n".join(f"    {line}" for line in wrapped.split("\n"))
        return f"{header}\n{self._c(Colors.GRAY, body)}\n"

    def render_error(self, error: str) -> str:
        """渲染错误信息

        Args:
            error: 错误描述
        """
        header = self._c(f"{Colors.BOLD}{Colors.RED}", "❌ 错误")
        body = self._c(Colors.RED, f"  {error}")
        return f"{header}\n{body}\n"

    def render_status_bar(self, info: dict) -> str:
        """渲染状态栏

        Args:
            info: 状态信息，如 {"model": "qwen", "tokens": 1234, "session": "abc"}
        """
        parts = []
        if "model" in info:
            parts.append(self._c(Colors.CYAN, f"模型: {info['model']}"))
        if "tokens" in info:
            parts.append(self._c(Colors.GREEN, f"Token: {info['tokens']}"))
        if "session" in info:
            parts.append(self._c(Colors.YELLOW, f"会话: {info['session'][:8]}"))
        if "sessions" in info:
            parts.append(self._c(Colors.BLUE, f"连接: {info['sessions']}"))
        bar_content = " │ ".join(parts) if parts else "就绪"
        border = self._c(Colors.DIM, "═" * self.width)
        return f"{border}\n {bar_content}\n{border}"

    def clear_screen(self) -> str:
        """返回清屏转义序列"""
        return "\033[2J\033[H"

    def render_welcome(self, agent_name: str = "Leaper CN") -> str:
        """渲染欢迎界面

        Args:
            agent_name: Agent 名称
        """
        border = self._c(Colors.CYAN, "╔" + "═" * (self.width - 2) + "╗")
        bottom = self._c(Colors.CYAN, "╚" + "═" * (self.width - 2) + "╝")
        title = self._c(f"{Colors.BOLD}{Colors.CYAN}", f"  🚀 {agent_name} TUI Gateway")
        hint = self._c(Colors.DIM, "  输入消息开始对话，Ctrl+C 退出")
        return f"{border}\n{title}\n{hint}\n{bottom}\n"

    def render_stream_token(self, token: str) -> str:
        """渲染流式输出的单个 token（不换行）"""
        return self._c(Colors.CYAN, token)
