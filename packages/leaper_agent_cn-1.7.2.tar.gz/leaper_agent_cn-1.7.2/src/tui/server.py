"""TUI WebSocket 服务器 — 用 asyncio 原生实现简化版 WebSocket 网关"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import struct
import time
import uuid
from typing import Any, Dict, Optional, TYPE_CHECKING

from .event_bus import EventBus, EVENT_MESSAGE, EVENT_ERROR, EVENT_STATUS
from .render import TerminalRenderer

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# WebSocket 操作码
WS_OP_TEXT = 0x1
WS_OP_CLOSE = 0x8
WS_OP_PING = 0x9
WS_OP_PONG = 0xA

# WebSocket 握手魔数
WS_MAGIC = "258EAFA5-E914-47DA-95CA-5AB53FF40174"


class TUISession:
    """单个 TUI 会话"""

    def __init__(self, session_id: str, writer: asyncio.StreamWriter) -> None:
        self.session_id = session_id
        self.writer = writer
        self.created_at = time.time()
        self.last_active = time.time()
        self.message_count = 0

    def touch(self) -> None:
        """更新最后活跃时间"""
        self.last_active = time.time()
        self.message_count += 1

    def to_dict(self) -> dict:
        """序列化为字典"""
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "last_active": self.last_active,
            "message_count": self.message_count,
        }


def _ws_accept_key(key: str) -> str:
    """计算 WebSocket 握手的 Sec-WebSocket-Accept"""
    raw = key.strip() + WS_MAGIC
    sha1 = hashlib.sha1(raw.encode()).digest()
    return base64.b64encode(sha1).decode()


def _build_ws_frame(payload: bytes, opcode: int = WS_OP_TEXT) -> bytes:
    """构建 WebSocket 帧（服务端发送，不需要 mask）"""
    frame = bytearray()
    frame.append(0x80 | opcode)  # FIN + opcode
    length = len(payload)
    if length < 126:
        frame.append(length)
    elif length < 65536:
        frame.append(126)
        frame.extend(struct.pack("!H", length))
    else:
        frame.append(127)
        frame.extend(struct.pack("!Q", length))
    frame.extend(payload)
    return bytes(frame)


def _parse_ws_frame(data: bytes) -> Optional[tuple]:
    """解析 WebSocket 帧，返回 (opcode, payload, consumed_bytes) 或 None"""
    if len(data) < 2:
        return None

    opcode = data[0] & 0x0F
    masked = bool(data[1] & 0x80)
    length = data[1] & 0x7F
    offset = 2

    if length == 126:
        if len(data) < 4:
            return None
        length = struct.unpack("!H", data[2:4])[0]
        offset = 4
    elif length == 127:
        if len(data) < 10:
            return None
        length = struct.unpack("!Q", data[2:10])[0]
        offset = 10

    if masked:
        if len(data) < offset + 4 + length:
            return None
        mask_key = data[offset:offset + 4]
        offset += 4
        payload = bytearray(data[offset:offset + length])
        for i in range(length):
            payload[i] ^= mask_key[i % 4]
        payload = bytes(payload)
    else:
        if len(data) < offset + length:
            return None
        payload = data[offset:offset + length]

    return (opcode, payload, offset + length)


class TUIServer:
    """终端 UI WebSocket 服务器

    用 asyncio 原生实现，不依赖第三方 WebSocket 库。
    支持多 session 并发连接。
    """

    def __init__(self, message_handler: Optional[Any] = None) -> None:
        """初始化 TUI 服务器

        Args:
            message_handler: 消息处理回调，签名 async def handler(session_id, content) -> str
        """
        self.sessions: Dict[str, TUISession] = {}
        self.event_bus = EventBus()
        self.renderer = TerminalRenderer()
        self._message_handler = message_handler
        self._server: Optional[asyncio.AbstractServer] = None
        self._host = "127.0.0.1"
        self._port = 3000

    async def start(self, host: str = "127.0.0.1", port: int = 3000) -> None:
        """启动 WebSocket 服务器

        Args:
            host: 绑定地址
            port: 绑定端口
        """
        self._host = host
        self._port = port
        self._server = await asyncio.start_server(
            self._handle_tcp_connection, host, port
        )
        logger.info("TUI 服务器启动: ws://%s:%d", host, port)
        await self.event_bus.emit(EVENT_STATUS, {"status": "started", "host": host, "port": port})

    async def stop(self) -> None:
        """停止服务器"""
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        # 关闭所有会话
        for sid in list(self.sessions):
            try:
                self.sessions[sid].writer.close()
            except Exception:
                pass
        self.sessions.clear()
        logger.info("TUI 服务器已停止")

    async def _handle_tcp_connection(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        """处理 TCP 连接，完成 WebSocket 握手后转为 WS 通信"""
        try:
            # 读取 HTTP 请求头
            request_data = await asyncio.wait_for(reader.read(4096), timeout=10)
            request_text = request_data.decode("utf-8", errors="ignore")

            # 提取 Sec-WebSocket-Key
            ws_key = None
            for line in request_text.split("\r\n"):
                if line.lower().startswith("sec-websocket-key:"):
                    ws_key = line.split(":", 1)[1].strip()
                    break

            if not ws_key:
                # 非 WebSocket 请求，返回简单 HTTP 响应
                response = (
                    "HTTP/1.1 200 OK\r\n"
                    "Content-Type: application/json\r\n\r\n"
                    + json.dumps(self.get_status())
                )
                writer.write(response.encode())
                await writer.drain()
                writer.close()
                return

            # WebSocket 握手响应
            accept_key = _ws_accept_key(ws_key)
            handshake = (
                "HTTP/1.1 101 Switching Protocols\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                f"Sec-WebSocket-Accept: {accept_key}\r\n\r\n"
            )
            writer.write(handshake.encode())
            await writer.drain()

            # 创建会话
            session_id = uuid.uuid4().hex[:12]
            session = TUISession(session_id, writer)
            self.sessions[session_id] = session
            logger.info("新 TUI 会话: %s", session_id)

            # 发送欢迎消息
            welcome = {"type": "welcome", "session_id": session_id}
            await self._ws_send(writer, welcome)

            # 消息循环
            await self._ws_message_loop(reader, writer, session)

        except asyncio.TimeoutError:
            logger.warning("连接超时")
        except ConnectionResetError:
            logger.debug("连接重置")
        except Exception as e:
            logger.error("连接处理异常: %s", e)
        finally:
            # 清理会话
            for sid, s in list(self.sessions.items()):
                if s.writer is writer:
                    del self.sessions[sid]
                    logger.info("会话断开: %s", sid)
                    break
            try:
                writer.close()
            except Exception:
                pass

    async def _ws_message_loop(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        session: TUISession,
    ) -> None:
        """WebSocket 消息循环"""
        buffer = b""
        while True:
            try:
                chunk = await asyncio.wait_for(reader.read(65536), timeout=300)
                if not chunk:
                    break
                buffer += chunk

                # 尝试解析帧
                while buffer:
                    result = _parse_ws_frame(buffer)
                    if result is None:
                        break
                    opcode, payload, consumed = result
                    buffer = buffer[consumed:]

                    if opcode == WS_OP_TEXT:
                        session.touch()
                        await self._handle_ws_message(session, payload.decode("utf-8"))
                    elif opcode == WS_OP_PING:
                        pong = _build_ws_frame(payload, WS_OP_PONG)
                        writer.write(pong)
                        await writer.drain()
                    elif opcode == WS_OP_CLOSE:
                        close_frame = _build_ws_frame(b"", WS_OP_CLOSE)
                        writer.write(close_frame)
                        await writer.drain()
                        return

            except asyncio.TimeoutError:
                # 发送 ping 保活
                ping = _build_ws_frame(b"ping", WS_OP_PING)
                writer.write(ping)
                await writer.drain()

    async def _handle_ws_message(self, session: TUISession, raw: str) -> None:
        """处理收到的 WebSocket 消息"""
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            # 纯文本当作用户消息
            message = {"type": "message", "content": raw}

        msg_type = message.get("type", "message")
        content = message.get("content", "")

        await self.event_bus.emit(EVENT_MESSAGE, {
            "session_id": session.session_id,
            "content": content,
            "raw": message,
        })

        # 调用消息处理器
        if self._message_handler and content:
            try:
                reply = await self._message_handler(session.session_id, content)
                if reply:
                    await self._ws_send(session.writer, {
                        "type": "reply",
                        "content": reply,
                    })
            except Exception as e:
                logger.error("消息处理异常: %s", e)
                await self._ws_send(session.writer, {
                    "type": "error",
                    "content": str(e),
                })

    async def _ws_send(self, writer: asyncio.StreamWriter, data: dict) -> None:
        """通过 WebSocket 发送 JSON 消息"""
        payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
        frame = _build_ws_frame(payload)
        writer.write(frame)
        await writer.drain()

    async def broadcast(self, data: dict) -> None:
        """广播消息到所有连接的会话

        Args:
            data: 要广播的 JSON 数据
        """
        dead = []
        for sid, session in self.sessions.items():
            try:
                await self._ws_send(session.writer, data)
            except Exception:
                dead.append(sid)
        for sid in dead:
            self.sessions.pop(sid, None)

    def get_status(self) -> dict:
        """获取服务器状态"""
        return {
            "server": "leaper-cn-tui",
            "host": self._host,
            "port": self._port,
            "running": self._server is not None and self._server.is_serving() if self._server else False,
            "sessions": len(self.sessions),
            "session_list": [s.to_dict() for s in self.sessions.values()],
        }
