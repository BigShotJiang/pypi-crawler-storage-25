"""事件总线 — TUI 与 Agent 之间的异步通信桥梁"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Awaitable, Dict, List, Optional

logger = logging.getLogger(__name__)

# 支持的事件类型
EVENT_MESSAGE = "message"
EVENT_TOOL_CALL = "tool_call"
EVENT_THINKING = "thinking"
EVENT_ERROR = "error"
EVENT_STATUS = "status"
EVENT_STREAM = "stream"

ALL_EVENT_TYPES = [
    EVENT_MESSAGE, EVENT_TOOL_CALL, EVENT_THINKING,
    EVENT_ERROR, EVENT_STATUS, EVENT_STREAM,
]

# 事件处理器类型
EventHandler = Callable[[dict], Awaitable[None]]


class EventBus:
    """事件总线，支持异步订阅/发布模式

    用于 TUI Server 和 Agent Runner 之间解耦通信。
    """

    def __init__(self) -> None:
        self._handlers: Dict[str, List[EventHandler]] = {}
        self._history: List[dict] = []
        self._max_history: int = 100
        self._lock = asyncio.Lock()

    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        """订阅事件

        Args:
            event_type: 事件类型（message/tool_call/thinking/error/status/stream）
            handler: 异步回调函数，签名 async def handler(data: dict) -> None
        """
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        if handler not in self._handlers[event_type]:
            self._handlers[event_type].append(handler)
            logger.debug("订阅事件 %s，当前 %d 个处理器", event_type, len(self._handlers[event_type]))

    def unsubscribe(self, event_type: str, handler: EventHandler) -> None:
        """取消订阅

        Args:
            event_type: 事件类型
            handler: 要移除的处理器
        """
        if event_type in self._handlers:
            try:
                self._handlers[event_type].remove(handler)
                logger.debug("取消订阅事件 %s", event_type)
            except ValueError:
                pass

    async def emit(self, event_type: str, data: dict) -> None:
        """发布事件，通知所有订阅者

        Args:
            event_type: 事件类型
            data: 事件数据
        """
        event = {"type": event_type, "data": data}

        # 记录历史
        async with self._lock:
            self._history.append(event)
            if len(self._history) > self._max_history:
                self._history = self._history[-self._max_history:]

        # 通知所有处理器
        handlers = self._handlers.get(event_type, [])
        if not handlers:
            return

        tasks = []
        for handler in handlers:
            try:
                tasks.append(asyncio.ensure_future(handler(data)))
            except Exception as e:
                logger.error("创建事件处理任务失败: %s", e)

        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error("事件处理器异常: %s", result)

    def get_history(self, event_type: Optional[str] = None, limit: int = 50) -> List[dict]:
        """获取事件历史

        Args:
            event_type: 过滤事件类型，None 则返回全部
            limit: 最多返回条数
        """
        if event_type:
            filtered = [e for e in self._history if e["type"] == event_type]
        else:
            filtered = list(self._history)
        return filtered[-limit:]

    def clear_history(self) -> None:
        """清空事件历史"""
        self._history.clear()

    @property
    def subscriber_count(self) -> Dict[str, int]:
        """各事件类型的订阅者数量"""
        return {k: len(v) for k, v in self._handlers.items() if v}
