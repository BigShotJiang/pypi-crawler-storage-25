"""CLI 入口 — leaper-cn 命令行工具"""
import os
os.environ.setdefault("PYTHONUTF8", "1")

import asyncio
import io
import sys
from pathlib import Path


def _ensure_utf8_stdio():
    """Fix Windows terminals (cp1252 etc.) crashing on emoji output."""
    if sys.platform != "win32":
        return
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name)
        if (
            hasattr(stream, "buffer")
            and not isinstance(stream, io.TextIOWrapper)
            or (isinstance(stream, io.TextIOWrapper) and stream.encoding and stream.encoding.lower().replace("-", "") != "utf8")
        ):
            try:
                setattr(
                    sys,
                    name,
                    io.TextIOWrapper(stream.buffer, encoding="utf-8", errors="replace", line_buffering=stream.line_buffering),
                )
            except Exception:
                pass  # pytest capture or frozen env — skip

import click
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.markdown import Markdown

from .config import LeaperConfig, DEFAULT_CONFIG_PATH

console = Console()

# Provider 默认模型映射
# 行业列表
INDUSTRIES = [
    "互联网", "SaaS", "AI", "金融", "教育科技", "医疗",
    "IoT", "新能源汽车", "电商", "游戏", "企业服务",
    "物流", "房地产", "制造业", "文娱传媒",
]

PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "deepseek": {"base_url": "https://api.deepseek.com/v1", "model": "deepseek-v4-flash"},
    "qwen": {"base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1", "model": "qwen-max"},
    "zhipu": {"base_url": "https://open.bigmodel.cn/api/paas/v4", "model": "glm-4-flash"},
    "moonshot": {"base_url": "https://api.moonshot.cn/v1", "model": "moonshot-v1-8k"},
}

# 模板角色列表
TEMPLATE_ROLES = ["cto", "cpo", "cfo", "cmo", "coo", "cso", "cco", "chro", "clo", "ceo-coach"]


@click.group()
def main():
    """Leaper Agent CN — 面向中国市场的自进化 AI Agent 框架"""
    _ensure_utf8_stdio()


@main.command()
def version():
    """显示版本"""
    from . import __version__
    console.print(f"[bold]leaper-agent-cn[/bold] v{__version__}")


@main.command()
def init():
    """交互式初始化配置"""
    console.print(Panel("🚀 Leaper Agent CN 初始化配置", style="bold green"))

    provider_name = Prompt.ask(
        "选择 LLM Provider",
        choices=["deepseek", "qwen", "zhipu", "moonshot"],
        default="deepseek",
    )
    api_key = Prompt.ask("输入 API Key", password=True)

    if not api_key.strip():
        console.print("[red]❌ API Key 不能为空[/red]")
        raise SystemExit(1)

    defaults = PROVIDER_DEFAULTS[provider_name]
    model = Prompt.ask("模型名称", default=defaults["model"])

    cfg = LeaperConfig()
    cfg.provider.name = provider_name
    cfg.provider.api_key = api_key.strip()
    cfg.provider.base_url = defaults["base_url"]
    cfg.provider.model = model
    cfg.save()

    console.print(f"\n[green]✅ 配置已保存到 {DEFAULT_CONFIG_PATH}[/green]")


@main.command()
@click.argument("name", required=False, default=None)
@click.option("--name", "-n", "opt_name", default=None, help="Agent 名称")
@click.option("--template", "-t", "template", default=None, help="角色模板 (cto/cpo/cfo/cmo/coo/cso/cco/chro/clo/ceo-coach)")
def create(name: str | None, opt_name: str | None, template: str | None):
    """交互式创建 Agent

    支持: leaper-cn create / leaper-cn create my-agent --template cto / leaper-cn create --name my-agent --template cto
    """
    from .templates.deployer import TemplateDeployer

    console.print(Panel("🤖 创建新 Agent", style="bold green"))

    # Resolve role from --template or interactive
    role = template
    if role:
        if role not in TEMPLATE_ROLES:
            console.print(f"[red]❌ 无效模板: {role}[/red]")
            console.print(f"[dim]可选: {', '.join(TEMPLATE_ROLES)}[/dim]")
            raise SystemExit(1)
    else:
        # 1. 选角色
        console.print("\n[bold]可选角色：[/bold]")
        for i, r in enumerate(TEMPLATE_ROLES, 1):
            console.print(f"  {i}. {r}")
        role_idx = Prompt.ask(
            "\n选择角色编号",
            default="1",
        )
        try:
            role = TEMPLATE_ROLES[int(role_idx) - 1]
        except (ValueError, IndexError):
            console.print("[red]❌ 无效的角色编号[/red]")
            raise SystemExit(1)

    # Resolve agent name: positional arg > --name > interactive
    agent_name = name or opt_name
    if not agent_name:
        agent_name = Prompt.ask("输入 Agent 名字", default=f"my-{role}")

    # 3. 选行业（可跳过）
    console.print("\n[bold]可选行业（回车跳过）：[/bold]")
    for i, ind in enumerate(INDUSTRIES, 1):
        console.print(f"  {i}. {ind}")
    industry_idx = Prompt.ask("\n选择行业编号", default="")
    industry = None
    if industry_idx.strip():
        try:
            industry = INDUSTRIES[int(industry_idx) - 1]
        except (ValueError, IndexError):
            console.print("[yellow]⚠️ 无效编号，跳过行业选择[/yellow]")

    # 4. 用户信息
    user_name = Prompt.ask("你的名字（回车跳过）", default="")
    company_name = Prompt.ask("公司名称（回车跳过）", default="")
    user_info = {}
    if user_name.strip():
        user_info["Name"] = user_name.strip()
    if company_name.strip():
        user_info["Company"] = company_name.strip()

    # 5. 选 provider
    provider_name = Prompt.ask(
        "选择 LLM Provider",
        choices=["deepseek", "qwen", "zhipu", "moonshot"],
        default="deepseek",
    )

    # 4. 检查是否有配置，没有则要求输入 API key
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        api_key = Prompt.ask("输入 API Key", password=True)
        if not api_key.strip():
            console.print("[red]❌ API Key 不能为空[/red]")
            raise SystemExit(1)
        defaults = PROVIDER_DEFAULTS[provider_name]
        cfg.provider.name = provider_name
        cfg.provider.api_key = api_key.strip()
        cfg.provider.base_url = defaults["base_url"]
        cfg.provider.model = defaults["model"]
        cfg.save()
        console.print(f"[dim]配置已保存到 {DEFAULT_CONFIG_PATH}[/dim]")

    # 部署模板
    deployer = TemplateDeployer()
    workspace = deployer.deploy(
        role=role,
        agent_name=agent_name,
        industry=industry,
        user_info=user_info or None,
    )

    # 更新配置
    cfg.agent.name = agent_name
    cfg.agent.role = role
    cfg.agent.industry = industry or ""
    cfg.agent.workspace = str(workspace)
    cfg.save()

    console.print(f"\n[green]✅ Agent 已创建: {workspace}[/green]")
    console.print(f"\n[bold]启动对话：[/bold]")
    console.print(f"  leaper-cn chat --agent {agent_name}")


@main.command()
def agents():
    """列出所有已创建的 Agent"""
    from .agent.multi import MultiAgentManager

    cfg = LeaperConfig.load()
    config_dir = str(Path(DEFAULT_CONFIG_PATH).parent)
    manager = MultiAgentManager(config_dir=config_dir)
    agent_list = manager.list_agents()

    if not agent_list:
        console.print("[yellow]未发现任何 Agent，请先运行 leaper-cn create[/yellow]")
        return

    console.print(f"[bold]已创建的 Agent ({len(agent_list)} 个)：[/bold]\n")
    default_name = manager.get_default_agent()
    for a in agent_list:
        marker = " ⭐" if a["name"] == default_name else ""
        console.print(f"  • [bold]{a['name']}[/bold] (role: {a['role']}){marker}")
        console.print(f"    workspace: {a['workspace']}")


@main.command()
@click.option("--workspace", "-w", default=None, help="工作区目录")
@click.option("--agent", "-a", "agent_name", default=None, help="指定 Agent 名称")
@click.option("--toolset", "-t", default="standard", help="工具集 (minimal/standard/full/safe/coding/research)")
def chat(workspace: str | None, agent_name: str | None, toolset: str):
    """启动 CLI 对话模式"""
    # 加载配置
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        console.print("[yellow]⚠️  未找到配置，启动初始化向导...[/yellow]\n")
        from click.testing import CliRunner
        # 直接调用 init
        ctx = click.Context(init)
        ctx.invoke(init)
        cfg = LeaperConfig.load()
        if not cfg.provider.api_key:
            console.print("[red]❌ 初始化未完成，退出[/red]")
            raise SystemExit(1)

    # 如果指定了 --agent，用 MultiAgentManager 找到 workspace
    if agent_name:
        from .agent.multi import MultiAgentManager
        config_dir = str(Path(DEFAULT_CONFIG_PATH).parent)
        manager = MultiAgentManager(config_dir=config_dir)
        try:
            agent_info = manager._agent_configs[agent_name]
            ws_dir = agent_info["workspace"]
        except KeyError:
            console.print(f"[red]❌ Agent 不存在: {agent_name}[/red]")
            raise SystemExit(1)
    else:
        ws_dir = workspace or cfg.agent.workspace

    console.print(Panel("💬 Leaper Agent CN — 对话模式", style="bold blue"))
    console.print(f"[dim]模型: {cfg.provider.model} | Provider: {cfg.provider.name}[/dim]")
    console.print("[dim]输入 /quit 退出，Ctrl+C 中断[/dim]\n")

    try:
        asyncio.run(_chat_loop(cfg, ws_dir))
    except KeyboardInterrupt:
        console.print("\n[dim]👋 再见！[/dim]")


async def _chat_loop(cfg: LeaperConfig, workspace_dir: str):
    """对话主循环"""
    from .providers import create_provider
    from .brain.engine import LeaperBrain
    from .agent.loop import AgentLoop

    # 创建 provider
    try:
        provider = create_provider(cfg.provider.name, {
            "api_key": cfg.provider.api_key,
            "model": cfg.provider.model,
        })
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        return

    # 创建 Brain
    brain = None
    if cfg.brain.enabled:
        try:
            db_path = cfg.brain.db_path if cfg.brain.db_path != ":memory:" else ":memory:"
            brain = LeaperBrain(db_path=db_path, agent_id=cfg.agent.name or "leaper-agent")
            await brain.initialize()
        except Exception:
            brain = None  # graceful fallback

    # 加载 system prompt（按顺序加载 workspace 下全部 .md 文件）
    system_prompt = ""
    ws_path = Path(workspace_dir).expanduser()
    _PROMPT_FILES = [
        "PREAMBLE.md", "IDENTITY.md", "SOUL.md", "EGO.md", "USER.md",
        "AGENTS.md", "MEMORY.md", "ROLE-TYPES.md", "SELF-CHECK.md",
        "LIFECYCLE.md", "TRIGGERS.md", "ONBOARDING.md",
    ]
    prompt_parts = []
    for fname in _PROMPT_FILES:
        fpath = ws_path / fname
        if fpath.exists():
            content = fpath.read_text(encoding="utf-8")
            prompt_parts.append(f"## {fname}\n{content}")
    if prompt_parts:
        system_prompt = "\n\n---\n\n".join(prompt_parts)

    # 尝试读取 workspace 的 config.yaml 覆盖
    ws_config_file = ws_path / "config.yaml"
    if ws_config_file.exists():
        import yaml as _ws_yaml
        try:
            with open(ws_config_file, "r", encoding="utf-8") as f:
                ws_cfg = _ws_yaml.safe_load(f) or {}
            # 只覆盖 brain 和 evolution 配置（provider 由全局管理）
            if "brain" in ws_cfg:
                for k, v in ws_cfg["brain"].items():
                    if hasattr(cfg.brain, k):
                        setattr(cfg.brain, k, v)
        except Exception:
            pass  # workspace config 解析失败不影响启动

    # 创建 AgentLoop
    loop = AgentLoop(
        provider=provider,
        brain=brain,
        system_prompt=system_prompt,
        workspace_dir=str(ws_path),
    )

    # REPL
    while True:
        try:
            user_input = Prompt.ask("[bold blue]你[/bold blue]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]👋 再见！[/dim]")
            break

        if user_input.strip() in ("/quit", "/exit", "exit", "quit"):
            console.print("[dim]👋 再见！[/dim]")
            break

        if not user_input.strip():
            continue

        try:
            reply = await loop.chat(user_input)
            console.print(f"[bold green]AI[/bold green]> {reply}\n")
        except Exception as e:
            error_msg = str(e)
            if "401" in error_msg or "Unauthorized" in error_msg or "invalid" in error_msg.lower():
                console.print("[red]❌ API 密钥验证失败，请检查配置中的 api_key[/red]\n")
            elif "timeout" in error_msg.lower() or "connect" in error_msg.lower():
                console.print("[red]❌ 网络连接失败，请检查网络或 API 地址[/red]\n")
            else:
                console.print(f"[red]❌ 请求失败: {error_msg}[/red]\n")


@main.command()
@click.option("--channel", "-c", default=None, help="指定渠道 (feishu/dingtalk)")
@click.option("--host", default=None, help="绑定地址")
@click.option("--port", "-p", default=None, type=int, help="端口号")
def run(channel: str | None, host: str | None, port: int | None):
    """启动渠道网关服务"""
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        console.print("[red]❌ 未找到配置，请先运行 leaper-cn init[/red]")
        raise SystemExit(1)

    from .gateway import Gateway

    # 构建 gateway config
    gw_config: dict = {
        "host": host or "0.0.0.0",
        "port": port or 8080,
        "channels": {},
    }

    # 从 channel config 或命令行参数决定渠道
    ch_type = channel or cfg.channel.type
    if ch_type and ch_type != "cli":
        gw_config["channels"][ch_type] = cfg.channel.extra

    console.print(Panel(f"🚀 启动网关服务", style="bold green"))
    console.print(f"[dim]地址: {gw_config['host']}:{gw_config['port']}[/dim]")
    if gw_config["channels"]:
        console.print(f"[dim]渠道: {', '.join(gw_config['channels'].keys())}[/dim]")
    else:
        console.print("[yellow]⚠️  未配置渠道，仅健康检查端点可用[/yellow]")
    console.print("[dim]Ctrl+C 停止服务[/dim]\n")

    try:
        gateway = Gateway(gw_config)
        gateway.setup_from_config()
        gateway.run()
    except KeyboardInterrupt:
        console.print("\n[dim]🛑 服务已停止[/dim]")
    except Exception as e:
        console.print(f"[red]❌ 网关启动失败: {e}[/red]")
        raise SystemExit(1)


@main.command()
@click.option("--port", default=8765, help="服务端口")
@click.option("--brain", default=None, help="brain.db 路径")
def console_cmd(port: int, brain: str | None):
    """启动 Brain Console 知识库可视化 Web UI"""
    from .console import create_console_app

    if brain is None:
        brain = str(Path.home() / ".leaper-cn" / "brain.db")

    brain_path = Path(brain)
    if not brain_path.exists():
        console.print(f"[red]✗ 数据库不存在: {brain_path}[/red]")
        raise SystemExit(1)

    async def _run():
        runner = await create_console_app(str(brain_path), port=port)
        try:
            while True:
                await asyncio.sleep(3600)
        except (KeyboardInterrupt, asyncio.CancelledError):
            await runner.cleanup()

    console.print(f"[bold green]🧠 Brain Console[/bold green] → http://127.0.0.1:{port}")
    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print("\n[dim]已关闭[/dim]")


# Register alias
main.add_command(console_cmd, "console")


@main.group()
def skills():
    """技能管理"""
    pass


@skills.command("list")
def skills_list():
    """列出所有可用技能"""
    from .skills import SkillManager

    manager = SkillManager()
    all_skills = manager.get_all_skills()

    if not all_skills:
        console.print("[yellow]未发现任何技能[/yellow]")
        return

    console.print(f"[bold]可用技能 ({len(all_skills)} 个)：[/bold]\n")
    for s in all_skills:
        triggers = ", ".join(s.triggers[:3]) if s.triggers else ""
        console.print(f"  • [bold]{s.name}[/bold] — {s.description}")
        if triggers:
            console.print(f"    触发词: {triggers}")


@skills.command("install")
@click.argument("path")
def skills_install(path: str):
    """从目录安装 skill"""
    from .skills import SkillLoader
    import shutil

    src = Path(path).resolve()
    if not (src / "SKILL.md").exists():
        console.print(f"[red]❌ {path} 中未找到 SKILL.md[/red]")
        raise SystemExit(1)

    dest = Path.home() / ".leaper-cn" / "skills" / src.name
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copytree(str(src), str(dest), dirs_exist_ok=True)
    console.print(f"[green]✅ 技能已安装到 {dest}[/green]")


@skills.command("create")
def skills_create():
    """交互式创建新 skill"""
    name = Prompt.ask("技能名称")
    description = Prompt.ask("描述")
    triggers = Prompt.ask("触发词（逗号分隔）", default="")

    skill_dir = Path.home() / ".leaper-cn" / "skills" / name
    skill_dir.mkdir(parents=True, exist_ok=True)

    md = f"# {name}\n> {description}\n\n## Triggers\n"
    for t in triggers.split(","):
        t = t.strip()
        if t:
            md += f"- {t}\n"
    md += "\n## Parameters\n| Name | Type | Required | Description |\n|------|------|----------|-------------|\n"
    md += "\n## Script\nscript.py\n"

    (skill_dir / "SKILL.md").write_text(md, encoding="utf-8")
    (skill_dir / "script.py").write_text(
        '"""技能脚本"""\nimport json, sys\n\ndef main():\n    args = json.loads(sys.stdin.read())\n    print(json.dumps({"result": "TODO"}, ensure_ascii=False))\n\nif __name__ == "__main__":\n    main()\n',
        encoding="utf-8",
    )
    console.print(f"[green]✅ 技能已创建: {skill_dir}[/green]")



# ---------- 定时调度 CLI ----------

@main.group()
def schedule():
    """定时任务管理"""
    pass


@schedule.command("add")
@click.argument("description")
@click.option("--agent", "-a", default="default", help="目标 Agent ID")
@click.option("--cron", "-c", default=None, help="cron 表达式（留空则从描述解析）")
def schedule_add(description: str, agent: str, cron: str | None):
    """添加定时任务（支持自然语言）

    例: leaper-cn schedule add "每天早上8点发日报" --agent ceo-coach
    """
    from .scheduler.engine import Scheduler, parse_natural_language

    cron_expr = cron
    if not cron_expr:
        cron_expr = parse_natural_language(description)
        if not cron_expr:
            console.print("[red]❌ 无法从描述解析 cron 表达式，请用 --cron 手动指定[/red]")
            raise SystemExit(1)
        console.print(f"[dim]解析 cron: {cron_expr}[/dim]")

    s = Scheduler()
    job = s.add_job(name=description, cron_expr=cron_expr, agent_id=agent, payload=description)
    console.print("[green]✅ 已添加任务[/green]")
    console.print(f"  ID: {job.id}")
    console.print(f"  名称: {job.name}")
    console.print(f"  Cron: {job.cron_expr}")
    console.print(f"  Agent: {job.agent_id}")
    if job.next_run:
        console.print(f"  下次执行: {job.next_run}")


@schedule.command("list")
def schedule_list():
    """列出所有定时任务"""
    from .scheduler.engine import Scheduler

    s = Scheduler()
    s._load_jobs()
    jobs = s.list_jobs()
    if not jobs:
        console.print("[dim]暂无定时任务[/dim]")
        return
    for j in jobs:
        status = "✅" if j.enabled else "⏸️"
        console.print(f"  {status} [{j.id}] {j.name}  cron={j.cron_expr}  agent={j.agent_id}")


@schedule.command("remove")
@click.argument("job_id")
def schedule_remove(job_id: str):
    """删除定时任务"""
    from .scheduler.engine import Scheduler

    s = Scheduler()
    s._load_jobs()
    if s.remove_job(job_id):
        console.print(f"[green]✅ 已删除任务 {job_id}[/green]")
    else:
        console.print(f"[red]❌ 未找到任务 {job_id}[/red]")


# ---------- doctor / status / config / brain / upgrade ----------

@main.command()
def doctor():
    """诊断运行环境，检查配置是否正确"""
    import platform
    import urllib.request
    import urllib.error

    checks_passed = 0
    checks_total = 0

    def _check(label: str, passed: bool, detail: str = ""):
        nonlocal checks_passed, checks_total
        checks_total += 1
        if passed:
            checks_passed += 1
        icon = "✅" if passed else "❌"
        msg = f"  {icon} {label}"
        if detail:
            msg += f" ({detail})"
        console.print(msg)

    console.print("[bold]🩺 Leaper Agent CN 环境诊断[/bold]\n")

    # 1. Python 版本
    ver = sys.version_info
    _check("Python 版本 >= 3.10", ver >= (3, 10), f"{ver.major}.{ver.minor}.{ver.micro}")

    # 2. 配置文件
    cfg_exists = DEFAULT_CONFIG_PATH.exists()
    _check("配置文件 leaper.yaml", cfg_exists, str(DEFAULT_CONFIG_PATH))

    cfg = LeaperConfig.load() if cfg_exists else LeaperConfig()

    # 3. API Key
    has_key = bool(cfg.provider.api_key)
    masked = cfg._mask(cfg.provider.api_key) if has_key else "未设置"
    _check("API Key 已配置", has_key, masked)

    # 4. workspace 目录
    ws_path = Path(cfg.agent.workspace).expanduser()
    ws_exists = ws_path.exists()
    _check("Workspace 目录", ws_exists, str(ws_path))

    # 5. brain.db 可读写
    db_path = Path(cfg.brain.db_path).expanduser()
    db_ok = False
    db_detail = str(db_path)
    if db_path.exists():
        try:
            db_ok = os.access(str(db_path), os.R_OK | os.W_OK)
            if not db_ok:
                db_detail += " 权限不足"
        except Exception as e:
            db_detail += f" {e}"
    else:
        db_detail += " 不存在（首次 chat 时自动创建）"
        db_ok = True  # 不存在但目录可写即可
    _check("brain.db 可读写", db_ok, db_detail)

    # 6. 网络连通性
    net_ok = False
    net_detail = cfg.provider.base_url
    if cfg.provider.base_url:
        try:
            # 提取 base URL，拼接简单端点
            url = cfg.provider.base_url.rstrip("/")
            req = urllib.request.Request(url, method="HEAD")
            req.add_header("User-Agent", "leaper-cn-doctor/1.0")
            urllib.request.urlopen(req, timeout=5)
            net_ok = True
        except urllib.error.HTTPError as e:
            # HTTP 错误也说明网络通
            net_ok = True
            net_detail += f" HTTP {e.code}"
        except Exception as e:
            net_detail += f" {type(e).__name__}"
    else:
        net_detail = "base_url 未配置"
    _check("网络连通性", net_ok, net_detail)

    # 7. 配置验证
    from .config import validate_config
    issues = validate_config(cfg)
    _check("配置完整性", len(issues) == 0, "; ".join(issues) if issues else "全部通过")

    console.print(f"\n[bold]{checks_passed}/{checks_total} 项通过[/bold]")
    if checks_passed == checks_total:
        console.print("[green]✅ 环境正常[/green]")
    else:
        console.print("[yellow]⚠️ 部分检查未通过，请根据提示修复[/yellow]")


@main.command()
def status():
    """显示当前 agent 状态"""
    from . import __version__

    cfg = LeaperConfig.load()
    ws_path = Path(cfg.agent.workspace).expanduser()
    db_path = Path(cfg.brain.db_path).expanduser()

    console.print("[bold]📊 Agent 状态[/bold]\n")
    console.print(f"  版本:      v{__version__}")
    console.print(f"  Agent:     {cfg.agent.name} ({cfg.agent.role})")
    console.print(f"  行业:      {cfg.agent.industry or '(未设置)'}")
    console.print(f"  Provider:  {cfg.provider.name}")
    console.print(f"  模型:      {cfg.provider.model}")
    console.print(f"  配置文件:  {DEFAULT_CONFIG_PATH}")
    console.print(f"  Workspace: {ws_path}")

    # brain.db 记忆条数
    if db_path.exists():
        try:
            import sqlite3
            conn = sqlite3.connect(str(db_path))
            cur = conn.execute("SELECT COUNT(*) FROM memories")
            count = cur.fetchone()[0]
            conn.close()
            console.print(f"  记忆条数:  {count}")
        except Exception:
            console.print(f"  记忆条数:  (读取失败)")
    else:
        console.print(f"  记忆条数:  0 (数据库未创建)")


@main.command("config")
@click.argument("key", required=False, default=None)
@click.argument("value", required=False, default=None)
def config_cmd(key: str | None, value: str | None):
    """查看或修改配置（支持 dot notation）"""
    cfg = LeaperConfig.load()

    if key is None:
        # 显示全部配置（脱敏）
        console.print("[bold]⚙️ 当前配置[/bold]\n")
        for k, v in cfg.to_display_dict().items():
            console.print(f"  {k} = {v}")
        return

    if value is None:
        # 读取单个配置
        val = cfg.get_nested(key)
        if val is None:
            console.print(f"[red]❌ 未知的配置项: {key}[/red]")
        else:
            # 脱敏输出 api_key
            if "key" in key.lower() or "secret" in key.lower() or "token" in key.lower():
                console.print(f"{key} = {cfg._mask(str(val))}")
            else:
                console.print(f"{key} = {val}")
        return

    # 设置配置
    ok = cfg.set_nested(key, value)
    if ok:
        cfg.save()
        console.print(f"[green]✅ {key} = {value}[/green]")
    else:
        console.print(f"[red]❌ 无法设置: {key}[/red]")


@main.group()
def brain():
    """记忆库管理"""
    pass


@brain.command("stats")
def brain_stats():
    """显示记忆库统计"""
    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在，暂无记忆[/yellow]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))

        total = conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]

        # 尝试按 tier 统计
        try:
            tiers = conn.execute(
                "SELECT tier, COUNT(*) FROM memories GROUP BY tier ORDER BY tier"
            ).fetchall()
        except Exception:
            tiers = []

        # 文件大小
        size_bytes = db_path.stat().st_size
        if size_bytes < 1024:
            size_str = f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            size_str = f"{size_bytes / 1024:.1f} KB"
        else:
            size_str = f"{size_bytes / (1024*1024):.1f} MB"

        conn.close()

        console.print("[bold]🧠 记忆库统计[/bold]\n")
        console.print(f"  总记忆数:  {total}")
        console.print(f"  数据库大小: {size_str}")
        console.print(f"  路径:      {db_path}")
        if tiers:
            console.print("\n  [bold]按层级：[/bold]")
            for tier, count in tiers:
                console.print(f"    L{tier}: {count} 条")
    except Exception as e:
        console.print(f"[red]❌ 读取失败: {e}[/red]")


@brain.command("search")
@click.argument("query")
def brain_search(query: str):
    """搜索记忆"""
    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在[/yellow]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        # 简单 LIKE 搜索
        rows = conn.execute(
            "SELECT content, created_at FROM memories WHERE content LIKE ? LIMIT 10",
            (f"%{query}%",),
        ).fetchall()
        conn.close()

        if not rows:
            console.print(f"[yellow]未找到包含 '{query}' 的记忆[/yellow]")
            return

        console.print(f"[bold]搜索结果 ({len(rows)} 条)：[/bold]\n")
        for content, created_at in rows:
            preview = content[:100] + "..." if len(content) > 100 else content
            console.print(f"  • {preview}")
            if created_at:
                console.print(f"    [dim]{created_at}[/dim]")
    except Exception as e:
        console.print(f"[red]❌ 搜索失败: {e}[/red]")


@brain.command("export")
@click.option("--output", "-o", default="brain_export.json", help="导出文件路径")
def brain_export(output: str):
    """导出记忆为 JSON"""
    import json

    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在[/yellow]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        rows = conn.execute("SELECT * FROM memories").fetchall()
        cols = [desc[0] for desc in conn.execute("SELECT * FROM memories LIMIT 0").description]
        conn.close()

        data = [dict(zip(cols, row)) for row in rows]
        with open(output, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)

        console.print(f"[green]✅ 已导出 {len(data)} 条记忆到 {output}[/green]")
    except Exception as e:
        console.print(f"[red]❌ 导出失败: {e}[/red]")


@brain.command("clear")
def brain_clear():
    """清空记忆库（需确认）"""
    cfg = LeaperConfig.load()
    db_path = Path(cfg.brain.db_path).expanduser()

    if not db_path.exists():
        console.print("[yellow]brain.db 不存在[/yellow]")
        return

    confirm = Prompt.ask("确认清空所有记忆？此操作不可逆", choices=["yes", "no"], default="no")
    if confirm != "yes":
        console.print("[dim]已取消[/dim]")
        return

    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        conn.execute("DELETE FROM memories")
        conn.commit()
        conn.close()
        console.print("[green]✅ 记忆库已清空[/green]")
    except Exception as e:
        console.print(f"[red]❌ 清空失败: {e}[/red]")


@main.command()
def upgrade():
    """检查并升级到最新版本"""
    from . import __version__
    import subprocess

    console.print(f"[dim]当前版本: v{__version__}[/dim]")
    console.print("[dim]正在检查更新...[/dim]")

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--dry-run", "leaper-agent-cn"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if "already satisfied" in result.stdout.lower() or "already up-to-date" in result.stdout.lower():
            console.print(f"[green]✅ 已是最新版本 v{__version__}[/green]")
        else:
            console.print("[yellow]发现新版本，正在升级...[/yellow]")
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", "leaper-agent-cn"],
                timeout=60,
            )
            console.print("[green]✅ 升级完成[/green]")
    except subprocess.TimeoutExpired:
        console.print("[red]❌ 检查更新超时[/red]")
    except Exception as e:
        console.print(f"[red]❌ 升级失败: {e}[/red]")


@main.command()
@click.option("--host", default="0.0.0.0", help="绑定地址")
@click.option("--port", "-p", default=8080, type=int, help="端口号")
@click.option("--toolset", "-t", default="standard", help="工具集")
@click.option("--agent", "-a", "agent_name", default=None, help="指定 Agent 名称")
def serve(host: str, port: int, toolset: str, agent_name: str | None):
    """使用 AgentRunner 启动网关服务"""
    cfg = LeaperConfig.load()
    if not cfg.provider.api_key:
        console.print("[red]❌ 未找到配置，请先运行 leaper-cn init[/red]")
        raise SystemExit(1)

    ws_dir = cfg.agent.workspace
    if agent_name:
        from .agent.multi import MultiAgentManager
        config_dir = str(Path(DEFAULT_CONFIG_PATH).parent)
        manager = MultiAgentManager(config_dir=config_dir)
        try:
            ws_dir = manager._agent_configs[agent_name]["workspace"]
        except KeyError:
            console.print(f"[red]❌ Agent 不存在: {agent_name}[/red]")
            raise SystemExit(1)

    console.print(Panel(f"🚀 AgentRunner Gateway 模式", style="bold green"))
    console.print(f"[dim]地址: {host}:{port} | 工具集: {toolset}[/dim]")

    async def _serve():
        from .agent.runner import AgentRunner
        runner = AgentRunner(config=cfg, workspace_dir=ws_dir)
        await runner.initialize(toolset=toolset)
        await runner.run_gateway({"host": host, "port": port})

    try:
        asyncio.run(_serve())
    except KeyboardInterrupt:
        console.print("\n[dim]🛑 服务已停止[/dim]")


if __name__ == "__main__":
    main()
