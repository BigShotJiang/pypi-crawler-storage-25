"""健康检查系统

为 leaper-cn doctor 命令提供系统健康检查能力。
"""
from __future__ import annotations

import os
import sys
import shutil
import asyncio
import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Coroutine, List, Optional

logger = logging.getLogger(__name__)


class CheckStatus(Enum):
    """检查结果状态"""
    OK = "ok"
    WARN = "warn"
    FAIL = "fail"
    SKIP = "skip"


@dataclass
class CheckResult:
    """单项检查结果"""
    name: str
    status: CheckStatus
    message: str = ""
    details: dict = field(default_factory=dict)


@dataclass
class HealthReport:
    """完整健康报告"""
    results: List[CheckResult] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """所有检查都通过"""
        return all(r.status in (CheckStatus.OK, CheckStatus.SKIP)
                   for r in self.results)

    @property
    def summary(self) -> str:
        """摘要信息"""
        counts = {}
        for r in self.results:
            counts[r.status.value] = counts.get(r.status.value, 0) + 1
        parts = [f"{v} {k}" for k, v in counts.items()]
        status = "✅ 健康" if self.ok else "⚠️ 有问题"
        return f"{status} ({', '.join(parts)})"

    def to_dict(self) -> dict:
        """转为字典"""
        return {
            "ok": self.ok,
            "summary": self.summary,
            "checks": [
                {"name": r.name, "status": r.status.value,
                 "message": r.message, "details": r.details}
                for r in self.results
            ],
        }


# 类型别名：异步检查函数
CheckFunc = Callable[[], Coroutine[Any, Any, CheckResult]]


class HealthChecker:
    """健康检查器

    注册多个检查项，批量运行并生成报告。
    """

    def __init__(self, config: Any = None) -> None:
        self._checks: List[CheckFunc] = []
        self.config = config
        self._register_default_checks()

    def register_check(self, check: CheckFunc) -> None:
        """注册一个检查项"""
        self._checks.append(check)

    def _register_default_checks(self) -> None:
        """注册默认检查项"""
        self.register_check(self.check_python_version)
        self.register_check(self.check_config)
        self.register_check(self.check_disk_space)
        self.register_check(self.check_memory)
        self.register_check(self.check_brain)

    async def run_all(self) -> HealthReport:
        """运行所有检查"""
        report = HealthReport()
        for check in self._checks:
            try:
                result = await check()
                report.results.append(result)
            except Exception as e:
                report.results.append(CheckResult(
                    name=getattr(check, "__name__", "unknown"),
                    status=CheckStatus.FAIL,
                    message=f"检查异常: {e}",
                ))
        return report

    async def check_python_version(self) -> CheckResult:
        """检查 Python 版本 >= 3.10"""
        ver = sys.version_info
        if ver >= (3, 10):
            return CheckResult(
                name="python_version",
                status=CheckStatus.OK,
                message=f"Python {ver.major}.{ver.minor}.{ver.micro}",
            )
        return CheckResult(
            name="python_version",
            status=CheckStatus.FAIL,
            message=f"Python {ver.major}.{ver.minor} < 3.10",
        )

    async def check_config(self) -> CheckResult:
        """检查配置文件"""
        if self.config is None:
            return CheckResult(
                name="config",
                status=CheckStatus.SKIP,
                message="未提供配置",
            )

        # 调用 validate_config 如果有的话
        from src.config import validate_config
        issues = validate_config(self.config)
        if not issues:
            return CheckResult(
                name="config",
                status=CheckStatus.OK,
                message="配置完整",
            )
        return CheckResult(
            name="config",
            status=CheckStatus.WARN,
            message=f"配置问题: {'; '.join(issues)}",
            details={"issues": issues},
        )

    async def check_disk_space(self) -> CheckResult:
        """检查磁盘空间"""
        try:
            usage = shutil.disk_usage(Path.home())
            free_gb = usage.free / (1024 ** 3)
            pct_free = (usage.free / usage.total) * 100
            if free_gb < 1:
                return CheckResult(
                    name="disk_space",
                    status=CheckStatus.FAIL,
                    message=f"磁盘空间不足: {free_gb:.1f} GB",
                    details={"free_gb": round(free_gb, 2),
                             "pct_free": round(pct_free, 1)},
                )
            if free_gb < 5:
                return CheckResult(
                    name="disk_space",
                    status=CheckStatus.WARN,
                    message=f"磁盘空间偏低: {free_gb:.1f} GB",
                    details={"free_gb": round(free_gb, 2),
                             "pct_free": round(pct_free, 1)},
                )
            return CheckResult(
                name="disk_space",
                status=CheckStatus.OK,
                message=f"磁盘空间充足: {free_gb:.1f} GB ({pct_free:.0f}%)",
                details={"free_gb": round(free_gb, 2),
                         "pct_free": round(pct_free, 1)},
            )
        except Exception as e:
            return CheckResult(
                name="disk_space",
                status=CheckStatus.WARN,
                message=f"无法检查磁盘: {e}",
            )

    async def check_memory(self) -> CheckResult:
        """检查系统内存（跨平台简易版）"""
        try:
            # 尝试读 /proc/meminfo（Linux）
            meminfo = Path("/proc/meminfo")
            if meminfo.exists():
                lines = meminfo.read_text().splitlines()
                mem = {}
                for line in lines:
                    parts = line.split(":")
                    if len(parts) == 2:
                        key = parts[0].strip()
                        val = parts[1].strip().split()[0]
                        mem[key] = int(val)
                total = mem.get("MemTotal", 0) / 1024  # MB
                avail = mem.get("MemAvailable", 0) / 1024
                if avail < 256:
                    return CheckResult(
                        name="memory", status=CheckStatus.FAIL,
                        message=f"内存不足: {avail:.0f} MB / {total:.0f} MB",
                    )
                return CheckResult(
                    name="memory", status=CheckStatus.OK,
                    message=f"内存正常: {avail:.0f} MB / {total:.0f} MB",
                )
            # Windows / macOS：跳过详细检查
            return CheckResult(
                name="memory", status=CheckStatus.OK,
                message="内存检查（简易模式）: 正常",
            )
        except Exception as e:
            return CheckResult(
                name="memory", status=CheckStatus.WARN,
                message=f"无法检查内存: {e}",
            )

    async def check_brain(self) -> CheckResult:
        """检查 brain.db 可读写"""
        if self.config is None:
            return CheckResult(
                name="brain", status=CheckStatus.SKIP,
                message="未提供配置",
            )
        db_path = getattr(getattr(self.config, "brain", None), "db_path", None)
        if not db_path:
            return CheckResult(
                name="brain", status=CheckStatus.SKIP,
                message="未配置 brain.db 路径",
            )
        p = Path(db_path).expanduser()
        if p.exists():
            if os.access(p, os.R_OK | os.W_OK):
                return CheckResult(
                    name="brain", status=CheckStatus.OK,
                    message=f"brain.db 可读写: {p}",
                )
            return CheckResult(
                name="brain", status=CheckStatus.FAIL,
                message=f"brain.db 无读写权限: {p}",
            )
        # 文件不存在，检查父目录是否可写
        parent = p.parent
        if parent.exists() and os.access(parent, os.W_OK):
            return CheckResult(
                name="brain", status=CheckStatus.OK,
                message=f"brain.db 尚未创建，父目录可写: {parent}",
            )
        return CheckResult(
            name="brain", status=CheckStatus.WARN,
            message=f"brain.db 路径不可写: {p}",
        )

    async def check_provider(self) -> CheckResult:
        """检查 AI provider 连通性（仅检查配置，不实际请求）"""
        if self.config is None:
            return CheckResult(
                name="provider", status=CheckStatus.SKIP,
                message="未提供配置",
            )
        provider = getattr(self.config, "provider", None)
        if not provider or not getattr(provider, "api_key", ""):
            return CheckResult(
                name="provider", status=CheckStatus.WARN,
                message="provider.api_key 未配置",
            )
        return CheckResult(
            name="provider", status=CheckStatus.OK,
            message=f"provider 已配置: {getattr(provider, 'name', 'unknown')}",
        )

    async def check_channels(self) -> CheckResult:
        """检查渠道配置"""
        if self.config is None:
            return CheckResult(
                name="channels", status=CheckStatus.SKIP,
                message="未提供配置",
            )
        channel = getattr(self.config, "channel", None)
        ch_type = getattr(channel, "type", "cli") if channel else "cli"
        return CheckResult(
            name="channels", status=CheckStatus.OK,
            message=f"渠道类型: {ch_type}",
        )
