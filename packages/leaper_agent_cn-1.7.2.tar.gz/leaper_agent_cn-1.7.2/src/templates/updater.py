"""TemplateUpdater — 模板自动更新器

检查和更新本地模板到最新版本。
"""

from __future__ import annotations

import json
import logging
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class UpdateInfo:
    """模板更新信息"""
    name: str
    current_version: str
    latest_version: str
    has_update: bool
    changelog: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "current_version": self.current_version,
            "latest_version": self.latest_version,
            "has_update": self.has_update,
            "changelog": self.changelog,
        }


class TemplateUpdater:
    """模板自动更新器

    管理本地模板的版本和更新。模板元数据存储在
    templates_dir/metadata.json 中。

    用法:
        updater = TemplateUpdater("~/.leaper-cn/templates")
        updates = await updater.check_updates()
        count = await updater.update_all()
    """

    def __init__(self, templates_dir: str, registry_dir: Optional[str] = None) -> None:
        """初始化

        Args:
            templates_dir: 本地模板安装目录
            registry_dir: 模板注册源目录（模拟远程仓库）
        """
        self._templates_dir = Path(templates_dir).expanduser()
        self._registry_dir = Path(registry_dir).expanduser() if registry_dir else None
        self._metadata_file = self._templates_dir / "metadata.json"
        self._templates_dir.mkdir(parents=True, exist_ok=True)

    def get_installed_version(self, name: str) -> str:
        """获取已安装模板的版本

        Args:
            name: 模板名称

        Returns:
            版本号，未安装返回空字符串
        """
        metadata = self._load_metadata()
        info = metadata.get(name, {})
        return info.get("version", "")

    def set_installed_version(self, name: str, version: str) -> None:
        """设置已安装模板的版本"""
        metadata = self._load_metadata()
        if name not in metadata:
            metadata[name] = {}
        metadata[name]["version"] = version
        self._save_metadata(metadata)

    async def check_updates(self) -> List[UpdateInfo]:
        """检查所有模板的可用更新

        Returns:
            更新信息列表
        """
        metadata = self._load_metadata()
        registry = self._load_registry()
        updates = []

        # 检查已安装的模板
        all_names = set(list(metadata.keys()) + list(registry.keys()))
        for name in sorted(all_names):
            current = metadata.get(name, {}).get("version", "0.0.0")
            latest = registry.get(name, {}).get("version", current)
            changelog = registry.get(name, {}).get("changelog", "")
            has_update = self._version_gt(latest, current)
            updates.append(UpdateInfo(
                name=name,
                current_version=current,
                latest_version=latest,
                has_update=has_update,
                changelog=changelog,
            ))

        return updates

    async def update_template(self, name: str, version: str = "latest") -> bool:
        """更新指定模板

        Args:
            name: 模板名称
            version: 目标版本，"latest" 表示最新

        Returns:
            是否更新成功
        """
        registry = self._load_registry()
        info = registry.get(name)
        if info is None:
            logger.warning(f"模板 {name} 未在注册源中找到")
            return False

        target_version = info.get("version", "0.1.0") if version == "latest" else version
        current = self.get_installed_version(name)

        if current == target_version:
            logger.info(f"模板 {name} 已是最新版本 {target_version}")
            return False

        # 复制模板文件（如果有源目录）
        if self._registry_dir:
            src = self._registry_dir / name
            dst = self._templates_dir / name
            if src.is_dir():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)

        self.set_installed_version(name, target_version)
        logger.info(f"已更新模板 {name}: {current} → {target_version}")
        return True

    async def update_all(self) -> int:
        """更新所有有新版本的模板

        Returns:
            成功更新的数量
        """
        updates = await self.check_updates()
        count = 0
        for info in updates:
            if info.has_update:
                ok = await self.update_template(info.name, info.latest_version)
                if ok:
                    count += 1
        return count

    # ── 内部方法 ──

    def _load_metadata(self) -> Dict[str, Any]:
        """加载本地元数据"""
        if not self._metadata_file.exists():
            return {}
        try:
            return json.loads(self._metadata_file.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_metadata(self, metadata: Dict[str, Any]) -> None:
        """保存本地元数据"""
        self._metadata_file.write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _load_registry(self) -> Dict[str, Any]:
        """加载注册源数据"""
        if self._registry_dir is None:
            return {}
        registry_file = self._registry_dir / "registry.json"
        if not registry_file.exists():
            return {}
        try:
            return json.loads(registry_file.read_text(encoding="utf-8"))
        except Exception:
            return {}

    @staticmethod
    def _version_gt(v1: str, v2: str) -> bool:
        """比较版本号 v1 > v2"""
        def _parse(v: str) -> List[int]:
            parts = []
            for p in v.split("."):
                try:
                    parts.append(int(p))
                except ValueError:
                    parts.append(0)
            return parts

        p1 = _parse(v1)
        p2 = _parse(v2)
        # 补齐长度
        max_len = max(len(p1), len(p2))
        p1.extend([0] * (max_len - len(p1)))
        p2.extend([0] * (max_len - len(p2)))
        return p1 > p2
