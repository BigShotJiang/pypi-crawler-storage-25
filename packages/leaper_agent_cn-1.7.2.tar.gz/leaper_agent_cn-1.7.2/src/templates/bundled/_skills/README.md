# 行业 Skill

此目录存放行业专属 Skill。

## 目录结构
每个行业一个子目录，包含 SKILL.md 和 script.py：
```
_skills/
  tech/
    SKILL.md
    script.py
  finance/
    SKILL.md
    script.py
```

## 添加方式
1. 手动创建目录和文件
2. 使用 `leaper-cn skills create` 命令
