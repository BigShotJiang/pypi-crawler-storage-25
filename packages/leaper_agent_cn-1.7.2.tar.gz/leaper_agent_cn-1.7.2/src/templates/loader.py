"""运行时模板加载器 — 加载 workspace 下的 .md 文件作为 system prompt"""
from pathlib import Path


class TemplateLoader:
    """加载 workspace 目录下所有 .md 文件"""

    def __init__(self, workspace: Path):
        self.workspace = Path(workspace).expanduser()

    def load_all(self) -> str:
        """加载所有顶层 .md 文件，拼接为 system prompt 片段"""
        parts: list[str] = []

        if not self.workspace.exists():
            return ""

        # 按文件名排序，确保稳定顺序
        md_files = sorted(self.workspace.glob("*.md"))
        for f in md_files:
            content = f.read_text(encoding="utf-8").strip()
            if content:
                parts.append(f"## {f.stem}\n\n{content}")

        return "\n\n---\n\n".join(parts)

    def load_file(self, name: str) -> str | None:
        """加载指定文件"""
        path = self.workspace / name
        if path.exists():
            return path.read_text(encoding="utf-8")
        return None
