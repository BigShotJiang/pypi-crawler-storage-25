"""TemplateEngine — 简化版模板引擎

自实现模板渲染，不依赖 Jinja2。
支持变量替换、条件、循环、默认值、过滤器。
"""

from __future__ import annotations

import re
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ── 内置过滤器 ──

_BUILTIN_FILTERS: Dict[str, Any] = {}


def _filter_upper(value: str) -> str:
    return str(value).upper()


def _filter_lower(value: str) -> str:
    return str(value).lower()


def _filter_strip(value: str) -> str:
    return str(value).strip()


def _filter_title(value: str) -> str:
    return str(value).title()


def _filter_length(value: Any) -> int:
    return len(value) if hasattr(value, "__len__") else 0


def _filter_truncate(value: str, length: int = 100) -> str:
    s = str(value)
    if len(s) <= length:
        return s
    return s[:length] + "..."


def _filter_default(value: Any, default_val: str = "") -> Any:
    if value is None or value == "":
        return default_val
    return value


_BUILTIN_FILTERS = {
    "upper": _filter_upper,
    "lower": _filter_lower,
    "strip": _filter_strip,
    "title": _filter_title,
    "length": _filter_length,
    "truncate": _filter_truncate,
    "default": _filter_default,
}

# ── 正则模式 ──

# {{variable}}, {{variable|filter}}, {{variable|filter(arg)}}
_VAR_PATTERN = re.compile(r"\{\{(.+?)\}\}")

# {% if condition %}...{% endif %}
_IF_PATTERN = re.compile(
    r"\{%\s*if\s+(.+?)\s*%\}(.*?)\{%\s*endif\s*%\}",
    re.DOTALL,
)

# {% for item in list %}...{% endfor %}
_FOR_PATTERN = re.compile(
    r"\{%\s*for\s+(\w+)\s+in\s+(\w+)\s*%\}(.*?)\{%\s*endfor\s*%\}",
    re.DOTALL,
)


class TemplateEngine:
    """简化版模板引擎

    支持：
    - 变量替换：{{variable}}
    - 过滤器：{{variable|upper}}, {{variable|truncate(50)}}
    - 默认值：{{variable|default("默认值")}}
    - 条件：{% if condition %}...{% endif %}
    - 循环：{% for item in list %}...{% endfor %}

    不支持（设计简化）：
    - 嵌套条件/循环
    - else / elif
    - 表达式求值
    """

    def __init__(self) -> None:
        self._filters: Dict[str, Any] = dict(_BUILTIN_FILTERS)

    def register_filter(self, name: str, func: Any) -> None:
        """注册自定义过滤器"""
        self._filters[name] = func

    def render(self, template_str: str, variables: Dict[str, Any]) -> str:
        """渲染模板字符串

        Args:
            template_str: 模板字符串
            variables: 变量字典

        Returns:
            渲染后的字符串
        """
        result = template_str

        # 1. 处理 for 循环
        result = self._process_for(result, variables)

        # 2. 处理 if 条件
        result = self._process_if(result, variables)

        # 3. 处理变量替换
        result = self._process_vars(result, variables)

        return result

    def render_file(self, template_path: str, variables: Dict[str, Any]) -> str:
        """渲染模板文件

        Args:
            template_path: 模板文件路径
            variables: 变量字典

        Returns:
            渲染后的字符串
        """
        path = Path(template_path)
        if not path.exists():
            raise FileNotFoundError(f"模板文件不存在: {template_path}")
        content = path.read_text(encoding="utf-8")
        return self.render(content, variables)

    def discover_variables(self, template_str: str) -> List[str]:
        """发现模板中的变量名

        Args:
            template_str: 模板字符串

        Returns:
            变量名列表（去重）
        """
        variables = set()

        # 从 {{ }} 中提取
        for match in _VAR_PATTERN.finditer(template_str):
            expr = match.group(1).strip()
            var_name = expr.split("|")[0].strip()
            if var_name:
                variables.add(var_name)

        # 从 {% if %} 中提取
        for match in _IF_PATTERN.finditer(template_str):
            cond = match.group(1).strip()
            # 简单提取变量名（不含 not 等关键词）
            for token in re.split(r"\s+", cond):
                token = token.strip()
                if token and token not in ("not", "and", "or", "true", "false"):
                    variables.add(token)

        # 从 {% for %} 中提取列表变量
        for match in _FOR_PATTERN.finditer(template_str):
            list_var = match.group(2).strip()
            variables.add(list_var)

        return sorted(variables)

    def validate_template(self, template_str: str) -> List[str]:
        """验证模板语法

        Args:
            template_str: 模板字符串

        Returns:
            问题列表（空列表表示无问题）
        """
        issues: List[str] = []

        # 检查未闭合的 {{ }}
        open_count = template_str.count("{{")
        close_count = template_str.count("}}")
        if open_count != close_count:
            issues.append(f"变量标签不匹配: {{ 有 {open_count} 个，}} 有 {close_count} 个")

        # 检查未闭合的 {% if %}
        if_count = len(re.findall(r"\{%\s*if\s+", template_str))
        endif_count = len(re.findall(r"\{%\s*endif\s*%\}", template_str))
        if if_count != endif_count:
            issues.append(f"if/endif 不匹配: if 有 {if_count} 个，endif 有 {endif_count} 个")

        # 检查未闭合的 {% for %}
        for_count = len(re.findall(r"\{%\s*for\s+", template_str))
        endfor_count = len(re.findall(r"\{%\s*endfor\s*%\}", template_str))
        if for_count != endfor_count:
            issues.append(f"for/endfor 不匹配: for 有 {for_count} 个，endfor 有 {endfor_count} 个")

        # 检查空变量
        for match in _VAR_PATTERN.finditer(template_str):
            expr = match.group(1).strip()
            if not expr:
                issues.append("发现空的变量标签: {{}}")

        return issues

    # ── 内部处理 ──

    def _process_for(self, template: str, variables: Dict[str, Any]) -> str:
        """处理 for 循环"""
        def _replace_for(match: re.Match) -> str:
            item_name = match.group(1)
            list_name = match.group(2)
            body = match.group(3)

            items = variables.get(list_name)
            if not items or not hasattr(items, "__iter__"):
                return ""

            parts = []
            for item in items:
                # 创建局部变量环境
                local_vars = dict(variables)
                local_vars[item_name] = item
                # 递归渲染 body 中的变量
                rendered = self._process_vars(body, local_vars)
                parts.append(rendered)
            return "".join(parts)

        return _FOR_PATTERN.sub(_replace_for, template)

    def _process_if(self, template: str, variables: Dict[str, Any]) -> str:
        """处理 if 条件"""
        def _replace_if(match: re.Match) -> str:
            condition = match.group(1).strip()
            body = match.group(2)

            if self._eval_condition(condition, variables):
                return body
            return ""

        return _IF_PATTERN.sub(_replace_if, template)

    def _eval_condition(self, condition: str, variables: Dict[str, Any]) -> bool:
        """简单的条件求值

        支持：变量名（truthy 检查）、not 变量名
        """
        condition = condition.strip()

        # not 前缀
        if condition.startswith("not "):
            inner = condition[4:].strip()
            return not self._eval_condition(inner, variables)

        # 直接变量名
        value = variables.get(condition)
        return bool(value)

    def _process_vars(self, template: str, variables: Dict[str, Any]) -> str:
        """处理变量替换和过滤器"""
        def _replace_var(match: re.Match) -> str:
            expr = match.group(1).strip()
            return self._eval_expression(expr, variables)

        return _VAR_PATTERN.sub(_replace_var, template)

    def _eval_expression(self, expr: str, variables: Dict[str, Any]) -> str:
        """求值表达式（变量 + 过滤器链）"""
        parts = expr.split("|")
        var_name = parts[0].strip()
        value = variables.get(var_name)

        # 应用过滤器
        for i in range(1, len(parts)):
            filter_expr = parts[i].strip()
            value = self._apply_filter(filter_expr, value)

        if value is None:
            return ""
        return str(value)

    def _apply_filter(self, filter_expr: str, value: Any) -> Any:
        """应用过滤器

        支持格式：filter_name 或 filter_name(arg1, arg2)
        """
        # 解析过滤器名和参数
        match = re.match(r"(\w+)\((.+)\)", filter_expr)
        if match:
            filter_name = match.group(1)
            args_str = match.group(2)
            args = self._parse_filter_args(args_str)
        else:
            filter_name = filter_expr.strip()
            args = []

        func = self._filters.get(filter_name)
        if func is None:
            logger.warning(f"未知过滤器: {filter_name}")
            return value

        try:
            if args:
                return func(value, *args)
            return func(value)
        except Exception as e:
            logger.warning(f"过滤器 {filter_name} 执行失败: {e}")
            return value

    def _parse_filter_args(self, args_str: str) -> list:
        """解析过滤器参数"""
        args = []
        for arg in args_str.split(","):
            arg = arg.strip()
            # 字符串参数（去引号）
            if (arg.startswith('"') and arg.endswith('"')) or \
               (arg.startswith("'") and arg.endswith("'")):
                args.append(arg[1:-1])
            # 数字
            elif arg.isdigit():
                args.append(int(arg))
            elif re.match(r"^\d+\.\d+$", arg):
                args.append(float(arg))
            else:
                args.append(arg)
        return args
