# Leaper Agent CN 🚀

> **一句话定位**：面向中国开发者的 AI Agent 框架 —— 开箱即用的记忆引擎 + 角色模板 + 全渠道接入，零外部依赖，纯国产大模型。

## ✨ 核心特性

| 特性 | 说明 |
|------|------|
| 🧠 **DeepBrain 记忆引擎** | 4-Gate 记忆筛选 + BM25 语义召回，Agent 越用越聪明 |
| 🔄 **六层记忆进化** | 工作记忆 → 短期 → 长期 → 核心 → 元认知 → 人格，模拟真人记忆演化 |
| 👥 **10+ 角色模板** | CTO / CFO / CMO / CPO / 法务 / 客服 / 产品经理……开箱即用 |
| 📡 **四大渠道** | CLI / 飞书 / 钉钉 / 企业微信，一份配置多端接入 |
| 🔌 **国产大模型** | DeepSeek / 通义千问 / 智谱 / Moonshot，按需切换 |
| 🛠️ **内置工具** | 搜索 / 计算器 / 文件读写 / 代码执行，零 API key |
| 🔒 **安全验签** | 每个渠道强制签名验证，webhook 来源可信 |

## 📦 安装

```bash
pip install leaper-agent-cn
```

## 🚀 快速开始（3 步）

```bash
# 1️⃣ 初始化项目
leaper init my-agent

# 2️⃣ 创建 Agent（交互式选择角色 + 模型）
leaper create

# 3️⃣ 开始对话
leaper chat
```

就这么简单。30 秒内你就有了一个带记忆、能进化的 AI Agent。

## 🏗️ 架构

```
┌──────────────────────────────────────────────────┐
│                   Leaper Agent                    │
├──────────┬──────────┬──────────┬─────────────────┤
│   CLI    │   飞书   │   钉钉   │    企业微信      │  ← 渠道层
├──────────┴──────────┴──────────┴─────────────────┤
│              Gateway (aiohttp)                    │  ← 网关层
├──────────────────────────────────────────────────┤
│              Agent Loop                           │  ← 核心循环
│  ┌────────────┐ ┌──────────┐ ┌────────────────┐  │
│  │PromptBuilder│ │ToolRouter│ │ContextEngine   │  │
│  └────────────┘ └──────────┘ └────────────────┘  │
├──────────────────────────────────────────────────┤
│           DeepBrain 记忆引擎                      │  ← 记忆层
│  ┌──────┐ ┌────────┐ ┌──────────┐ ┌──────────┐  │
│  │Engine│ │Evolution│ │Orchestrator│ │Profile │  │
│  └──────┘ └────────┘ └──────────┘ └──────────┘  │
├──────────────────────────────────────────────────┤
│            LLM Provider 适配层                    │  ← 模型层
│  DeepSeek │ 通义千问 │ 智谱 GLM │ Moonshot       │
└──────────────────────────────────────────────────┘
```

## ⚙️ 配置参考

`leaper.yaml` 完整配置：

```yaml
# 大模型配置
provider:
  name: deepseek                    # deepseek / qwen / zhipu / moonshot
  api_key: ${DEEPSEEK_API_KEY}      # 环境变量引用
  model: deepseek-chat

# Agent 角色
agent:
  role: cto                         # 内置角色模板
  industry: finance                 # 行业上下文（可选）
  system_prompt: ""                 # 自定义 prompt（可选）

# 记忆引擎
brain:
  enabled: true
  db_path: ./data/brain.db
  recall_top_k: 5                   # 每次召回 top-K 条记忆

# 渠道配置（多渠道并行）
channels:
  - type: cli                       # 命令行（默认）
  - type: feishu                    # 飞书
    app_id: ${FEISHU_APP_ID}
    app_secret: ${FEISHU_APP_SECRET}
    verification_token: ${FEISHU_TOKEN}
    encrypt_key: ${FEISHU_ENCRYPT_KEY}
  - type: dingtalk                  # 钉钉
    app_key: ${DINGTALK_APP_KEY}
    app_secret: ${DINGTALK_APP_SECRET}
    robot_code: ${DINGTALK_ROBOT_CODE}
  - type: wecom                     # 企业微信
    corp_id: ${WECOM_CORP_ID}
    agent_id: ${WECOM_AGENT_ID}
    secret: ${WECOM_SECRET}
    token: ${WECOM_TOKEN}
    encoding_aes_key: ${WECOM_AES_KEY}

# 内置工具
tools:
  - search                          # 互联网搜索（零配置）
  - calculator                      # 计算器
  - file_read                       # 文件读取
  - file_write                      # 文件写入
  - code_execute                    # 代码执行
```

敏感信息建议放 `.env` 文件，框架自动加载。

## 🤖 支持的大模型

| 厂商 | 模型 | 特点 |
|------|------|------|
| DeepSeek | deepseek-chat / deepseek-reasoner | 性价比之王 |
| 通义千问 | qwen-max / qwen-plus / qwen-turbo | 阿里全家桶 |
| 智谱 AI | glm-4 / glm-4-flash | 清华系 |
| Moonshot | moonshot-v1-8k/32k/128k | 长上下文 |
| 兼容 API | 任何 OpenAI 格式 API | 自定义 base_url |

## 📊 对比

| 维度 | Leaper Agent | ChatGPT | Coze | LangChain |
|------|-------------|---------|------|-----------|
| 中文原生 | ✅ 从设计到文档 | ❌ 英文优先 | ⚠️ 部分中文 | ❌ 英文生态 |
| 记忆系统 | ✅ 六层进化 | ❌ 无持久记忆 | ⚠️ 简单变量 | ⚠️ 需自建 |
| 国产模型 | ✅ 4 家原生支持 | ❌ GPT only | ⚠️ 有限 | ⚠️ 需适配 |
| IM 渠道 | ✅ 飞书/钉钉/企微 | ❌ 无 | ⚠️ 飞书 | ❌ 需自建 |
| 角色模板 | ✅ 10+ 开箱即用 | ❌ 手写 prompt | ⚠️ 有限 | ❌ 需自建 |
| 部署方式 | pip install | SaaS | SaaS | pip install |
| 零配置搜索 | ✅ 内置 | ❌ 需插件 | ⚠️ 需配置 | ❌ 需 API key |

## 🧪 开发

```bash
# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest tests/ -v

# 类型检查
mypy src/
```

## 📁 项目结构

```
leaper-cn-python/
├── src/
│   ├── agent/          # Agent 核心引擎
│   ├── brain/          # DeepBrain 记忆系统
│   ├── providers/      # LLM 大模型适配
│   ├── channels/       # 渠道适配（CLI/飞书/钉钉/企微）
│   ├── tools/          # 内置工具
│   └── templates/      # 角色模板
├── tests/              # 测试用例
├── leaper.yaml.example # 配置模板
└── README.md
```

## 📄 License

[BSL 1.1](LICENSE) — Business Source License 1.1

商业使用限制：未经授权不得用于与跃盟科技直接竞争的商业产品。
变更日期后自动转为 Apache 2.0。

---

**跃盟科技 (Deepleaper)** — AI 情景智能
