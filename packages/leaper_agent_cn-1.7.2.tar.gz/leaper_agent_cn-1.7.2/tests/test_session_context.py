"""测试 SessionManager + ContextEngine"""

import pytest
import asyncio
import tempfile
import os
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone, timedelta

import aiosqlite
import pytest_asyncio

from src.brain.engine import LeaperBrain
from src.agent.session import SessionManager, _estimate_tokens, SESSION_TIMEOUT_MINUTES
from src.agent.context import ContextEngine


@pytest_asyncio.fixture
async def brain(tmp_path):
    """创建真实的 LeaperBrain 实例（用临时 DB）"""
    db_path = str(tmp_path / "test.db")
    b = LeaperBrain(db_path=db_path, agent_id="test-agent")
    await b.initialize()
    yield b
    await b.close()


@pytest_asyncio.fixture
async def session_mgr(brain):
    """创建 SessionManager"""
    sm = SessionManager(brain)
    await sm.ensure_tables()
    return sm


@pytest_asyncio.fixture
async def context_engine(brain, session_mgr, tmp_path):
    """创建 ContextEngine"""
    ws = tmp_path / "workspace"
    ws.mkdir()
    return ContextEngine(brain, session_mgr, str(ws))


# ==================== SessionManager 测试 ====================

@pytest.mark.asyncio
async def test_create_session(session_mgr):
    """创建新会话，返回有效 session_id"""
    sid = await session_mgr.create_session("agent-1", "user-1")
    assert isinstance(sid, str)
    assert len(sid) == 32  # uuid4().hex


@pytest.mark.asyncio
async def test_get_or_create_existing(session_mgr):
    """30 分钟内 get_or_create 应返回同一个 session"""
    sid1 = await session_mgr.get_or_create("agent-1", "user-1")
    sid2 = await session_mgr.get_or_create("agent-1", "user-1")
    assert sid1 == sid2


@pytest.mark.asyncio
async def test_get_or_create_expired(session_mgr, brain):
    """超过 30 分钟后应创建新 session"""
    sid1 = await session_mgr.create_session("agent-1", "user-1")
    # 手动把 last_active 设为 31 分钟前
    old_time = (datetime.now(timezone.utc) - timedelta(minutes=31)).isoformat()
    await brain.db.execute(
        "UPDATE sessions SET last_active = ? WHERE id = ?", (old_time, sid1)
    )
    await brain.db.commit()
    sid2 = await session_mgr.get_or_create("agent-1", "user-1")
    assert sid1 != sid2


@pytest.mark.asyncio
async def test_add_and_get_history(session_mgr):
    """添加消息后能正确获取历史"""
    sid = await session_mgr.create_session("agent-1", "user-1")
    await session_mgr.add_message(sid, "user", "你好")
    await session_mgr.add_message(sid, "assistant", "你好！有什么可以帮你的？")
    await session_mgr.add_message(sid, "user", "天气怎么样？")

    history = await session_mgr.get_history(sid)
    assert len(history) == 3
    assert history[0]["role"] == "user"
    assert history[0]["content"] == "你好"
    assert history[1]["role"] == "assistant"
    assert history[2]["content"] == "天气怎么样？"


@pytest.mark.asyncio
async def test_context_window_limit(session_mgr):
    """context window 应按 token 预算裁剪"""
    sid = await session_mgr.create_session("agent-1", "user-1")

    # 添加大量消息
    for i in range(100):
        role = "user" if i % 2 == 0 else "assistant"
        await session_mgr.add_message(sid, role, f"这是第{i}条消息，包含一些内容用来测试 token 预算限制。" * 5)

    # 用很小的 token 预算
    window = await session_mgr.get_context_window(sid, max_tokens=500)
    # 应该比 100 条少很多
    assert len(window) < 100
    assert len(window) > 0
    # 最后一条应该是最新的消息
    assert "第99条" in window[-1]["content"]


# ==================== ContextEngine 测试 ====================

@pytest.mark.asyncio
async def test_build_full_context(context_engine, session_mgr):
    """build_context 应包含 system + history + user message"""
    sid = await session_mgr.create_session("agent-1", "user-1")
    await session_mgr.add_message(sid, "user", "你好")
    await session_mgr.add_message(sid, "assistant", "你好！")

    messages = await context_engine.build_context(
        sid, "今天天气怎么样？", system_prompt="你是助手"
    )

    # 至少有 system + history(2) + user = 4 条
    assert len(messages) >= 4
    assert messages[0]["role"] == "system"
    assert "你是助手" in messages[0]["content"]
    assert messages[-1]["role"] == "user"
    assert messages[-1]["content"] == "今天天气怎么样？"


@pytest.mark.asyncio
async def test_workspace_files_loaded(context_engine, tmp_path):
    """workspace 下的 .md 文件应被加载到 system prompt"""
    ws = tmp_path / "workspace"
    (ws / "README.md").write_text("# 测试项目\n这是一个测试", encoding="utf-8")
    (ws / "SOUL.md").write_text("# 灵魂\n我是助手", encoding="utf-8")

    ce = ContextEngine(context_engine.brain, context_engine.session_manager, str(ws))
    content = ce._load_workspace_files()
    assert "测试项目" in content
    assert "灵魂" in content


@pytest.mark.asyncio
async def test_brain_recall_injected(context_engine, session_mgr, brain):
    """如果 brain 有相关记忆，应注入到 context"""
    # 先存一些知识
    await brain.store_entry("knowledge", "Python 是最好的编程语言", category="tech")

    sid = await session_mgr.create_session("agent-1", "user-1")
    messages = await context_engine.build_context(sid, "Python 怎么样？")

    # 检查是否有记忆注入的 system 消息
    system_msgs = [m for m in messages if m["role"] == "system"]
    # 可能有也可能没有（取决于 recall 得分），不强制断言
    # 但 user message 一定在最后
    assert messages[-1]["content"] == "Python 怎么样？"


@pytest.mark.asyncio
async def test_truncate_to_budget(context_engine):
    """_truncate_to_budget 应保留 system 和最近消息"""
    messages = [
        {"role": "system", "content": "你是助手"},
        {"role": "user", "content": "消息1" * 500},
        {"role": "assistant", "content": "回复1" * 500},
        {"role": "user", "content": "消息2" * 500},
        {"role": "assistant", "content": "回复2" * 500},
        {"role": "user", "content": "最新消息"},
    ]

    result = context_engine._truncate_to_budget(messages, budget=200)

    # system 消息应保留
    assert result[0]["role"] == "system"
    # 最新的 user 消息应保留
    assert result[-1]["content"] == "最新消息"
    # 总条数应小于原始
    assert len(result) < len(messages)


# ==================== _estimate_tokens 测试 ====================

def test_estimate_tokens_chinese():
    """中文 token 估算"""
    text = "你好世界"  # 4 个中文字 = 8 tokens
    assert _estimate_tokens(text) == 8 + 1  # cn*2 + rest//4 (0 rest -> 1 min)


def test_estimate_tokens_english():
    """英文 token 估算"""
    text = "hello world test"
    tokens = _estimate_tokens(text)
    assert tokens > 0


def test_estimate_tokens_empty():
    assert _estimate_tokens("") == 0
