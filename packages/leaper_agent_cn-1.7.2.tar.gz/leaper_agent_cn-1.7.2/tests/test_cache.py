"""Cache 测试"""

import time
import pytest
from src.cache import Cache


class TestCache:
    """缓存系统测试"""

    def test_set_get(self):
        c = Cache()
        c.set("k1", "v1")
        assert c.get("k1") == "v1"

    def test_get_missing(self):
        c = Cache()
        assert c.get("nope") is None

    def test_ttl_expiry(self):
        c = Cache(ttl=1)
        c.set("k", "v", ttl=0)  # 永不过期
        assert c.get("k") == "v"
        c.set("k2", "v2", ttl=1)
        # 不 sleep，应该还没过期
        assert c.get("k2") == "v2"

    def test_delete(self):
        c = Cache()
        c.set("k", "v")
        assert c.delete("k") is True
        assert c.get("k") is None
        assert c.delete("k") is False

    def test_clear(self):
        c = Cache()
        c.set("a", 1)
        c.set("b", 2)
        c.clear()
        assert c.size() == 0

    def test_size(self):
        c = Cache()
        assert c.size() == 0
        c.set("a", 1)
        assert c.size() == 1

    def test_lru_eviction(self):
        c = Cache(max_size=3, ttl=0)
        c.set("a", 1)
        c.set("b", 2)
        c.set("c", 3)
        c.set("d", 4)  # a 应被淘汰
        assert c.get("a") is None
        assert c.get("b") == 2

    def test_lru_access_order(self):
        c = Cache(max_size=3, ttl=0)
        c.set("a", 1)
        c.set("b", 2)
        c.set("c", 3)
        c.get("a")  # a 移到末尾
        c.set("d", 4)  # b 应被淘汰
        assert c.get("a") == 1
        assert c.get("b") is None

    def test_cleanup(self):
        c = Cache(ttl=0)
        # 手动设置已过期的项
        c._data["expired"] = ("val", time.time() - 10)
        c.set("fresh", "val", ttl=0)
        removed = c.cleanup()
        assert removed == 1
        assert c.get("expired") is None
        assert c.get("fresh") == "val"

    def test_stats(self):
        c = Cache()
        c.set("k", "v")
        c.get("k")  # hit
        c.get("nope")  # miss
        s = c.stats()
        assert s["hits"] == 1
        assert s["misses"] == 1
        assert s["size"] == 1

    def test_cached_decorator(self):
        c = Cache(ttl=60)
        call_count = 0

        @c.cached(ttl=60)
        def expensive(x):
            nonlocal call_count
            call_count += 1
            return x * 2

        assert expensive(5) == 10
        assert expensive(5) == 10  # 缓存命中
        assert call_count == 1

    def test_cached_different_args(self):
        c = Cache()
        @c.cached()
        def add(a, b):
            return a + b
        assert add(1, 2) == 3
        assert add(3, 4) == 7
        assert c.size() == 2
