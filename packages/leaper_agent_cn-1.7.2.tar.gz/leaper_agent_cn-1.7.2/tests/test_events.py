"""EventEmitter 测试"""

import asyncio
import pytest
from src.events import EventEmitter, event_bus


class TestEventEmitter:
    """事件系统测试"""

    @pytest.mark.asyncio
    async def test_on_emit(self):
        ee = EventEmitter()
        received = []
        ee.on("test", lambda **kw: received.append(kw))
        await ee.emit("test", data="hello")
        assert len(received) == 1
        assert received[0]["data"] == "hello"

    @pytest.mark.asyncio
    async def test_multiple_handlers(self):
        ee = EventEmitter()
        results = []
        ee.on("ev", lambda **kw: results.append("a"))
        ee.on("ev", lambda **kw: results.append("b"))
        await ee.emit("ev")
        assert results == ["a", "b"]

    @pytest.mark.asyncio
    async def test_off(self):
        ee = EventEmitter()
        results = []
        handler = lambda **kw: results.append(1)
        ee.on("ev", handler)
        ee.off("ev", handler)
        await ee.emit("ev")
        assert results == []

    @pytest.mark.asyncio
    async def test_once(self):
        ee = EventEmitter()
        results = []
        ee.once("ev", lambda **kw: results.append(1))
        await ee.emit("ev")
        await ee.emit("ev")
        assert results == [1]  # 只触发一次

    @pytest.mark.asyncio
    async def test_async_handler(self):
        ee = EventEmitter()
        results = []

        async def handler(**kw):
            results.append(kw.get("val"))

        ee.on("ev", handler)
        await ee.emit("ev", val=42)
        assert results == [42]

    @pytest.mark.asyncio
    async def test_emit_no_handlers(self):
        ee = EventEmitter()
        await ee.emit("nonexistent")  # 不应报错

    @pytest.mark.asyncio
    async def test_handler_exception_ignored(self):
        ee = EventEmitter()
        results = []

        def bad(**kw):
            raise ValueError("boom")

        ee.on("ev", bad)
        ee.on("ev", lambda **kw: results.append("ok"))
        await ee.emit("ev")
        assert results == ["ok"]  # 异常不影响后续 handler

    def test_listeners(self):
        ee = EventEmitter()
        h1 = lambda **kw: None
        h2 = lambda **kw: None
        ee.on("ev", h1)
        ee.on("ev", h2)
        assert len(ee.listeners("ev")) == 2

    def test_clear_specific(self):
        ee = EventEmitter()
        ee.on("a", lambda **kw: None)
        ee.on("b", lambda **kw: None)
        ee.clear("a")
        assert len(ee.listeners("a")) == 0
        assert len(ee.listeners("b")) == 1

    def test_clear_all(self):
        ee = EventEmitter()
        ee.on("a", lambda **kw: None)
        ee.on("b", lambda **kw: None)
        ee.clear()
        assert len(ee.listeners("a")) == 0
        assert len(ee.listeners("b")) == 0

    def test_global_event_bus(self):
        assert isinstance(event_bus, EventEmitter)
