"""Environment 相关模块测试：ToolContext, FeedbackCollector, SendMessage, WebResearcher"""
import asyncio
import json
import os
import shutil
import tempfile

import pytest

from src.tools.tool_context import ToolContext
from src.tools.rl_feedback import FeedbackCollector
from src.tools.send_message import SendMessageTool, send_message, send_notification


# ── ToolContext ────────────────────────────────────────

class TestToolContext:
    def test_default_permission(self):
        ctx = ToolContext()
        assert ctx.check_permission("any_tool") is True

    def test_explicit_permission(self):
        ctx = ToolContext(permissions={"search": True, "terminal": False})
        assert ctx.check_permission("search") is True
        assert ctx.check_permission("terminal") is False

    def test_sandbox_default_deny(self):
        ctx = ToolContext(is_sandbox=True, permissions={"search": True})
        assert ctx.check_permission("search") is True
        assert ctx.check_permission("unknown") is False  # sandbox 未配置默认拒绝

    def test_get_safe_cwd(self):
        with tempfile.TemporaryDirectory() as td:
            ctx = ToolContext(workspace_dir=td)
            assert ctx.get_safe_cwd() == td

    def test_get_safe_cwd_creates(self):
        with tempfile.TemporaryDirectory() as td:
            new_dir = os.path.join(td, "sub", "dir")
            ctx = ToolContext(workspace_dir=new_dir)
            cwd = ctx.get_safe_cwd()
            assert os.path.isdir(cwd)

    def test_env_vars(self):
        ctx = ToolContext(env_vars={"KEY": "val"})
        assert ctx.get_env("KEY") == "val"
        assert ctx.get_env("MISSING", "default") == "default"

    def test_set_env(self):
        ctx = ToolContext()
        ctx.set_env("X", "1")
        assert ctx.get_env("X") == "1"

    def test_workspace_path(self):
        with tempfile.TemporaryDirectory() as td:
            ctx = ToolContext(workspace_dir=td)
            p = ctx.get_workspace_path("file.txt")
            assert p.endswith("file.txt")
            assert td in p

    def test_sandbox_path_escape(self):
        with tempfile.TemporaryDirectory() as td:
            ctx = ToolContext(workspace_dir=td, is_sandbox=True)
            with pytest.raises(PermissionError):
                ctx.get_workspace_path("../../etc/passwd")

    def test_to_from_dict(self):
        ctx = ToolContext(workspace_dir="/tmp", user_id="u1", is_sandbox=True)
        d = ctx.to_dict()
        ctx2 = ToolContext.from_dict(d)
        assert ctx2.workspace_dir == "/tmp"
        assert ctx2.is_sandbox is True


# ── FeedbackCollector ─────────────────────────────────

class TestFeedbackCollector:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.collector = FeedbackCollector(feedback_dir=self.tmpdir)

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_record_and_stats(self):
        self.collector.record_feedback("m1", 5, session_id="s1")
        self.collector.record_feedback("m2", 3, session_id="s1")
        stats = self.collector.get_feedback_stats()
        assert stats["total"] == 2
        assert stats["average"] == 4.0

    def test_invalid_rating(self):
        with pytest.raises(ValueError):
            self.collector.record_feedback("m1", 0)
        with pytest.raises(ValueError):
            self.collector.record_feedback("m1", 6)

    def test_improvement_suggestions(self):
        self.collector.record_feedback("m1", 1, comment="太差了", session_id="s1")
        self.collector.record_feedback("m2", 5, comment="很好", session_id="s1")
        suggestions = self.collector.get_improvement_suggestions()
        assert "太差了" in suggestions
        assert "很好" not in suggestions

    def test_export_training_data(self):
        self.collector.record_feedback("m1", 4, session_id="s1")
        self.collector.record_feedback("m2", 2, session_id="s2")
        export_path = os.path.join(self.tmpdir, "export.jsonl")
        count = self.collector.export_training_data(export_path)
        assert count == 2
        with open(export_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        assert len(lines) == 2

    def test_empty_stats(self):
        stats = self.collector.get_feedback_stats()
        assert stats["total"] == 0

    def test_distribution(self):
        self.collector.record_feedback("a", 5, session_id="s")
        self.collector.record_feedback("b", 5, session_id="s")
        self.collector.record_feedback("c", 3, session_id="s")
        stats = self.collector.get_feedback_stats()
        assert stats["distribution"][5] == 2
        assert stats["distribution"][3] == 1


# ── SendMessage ───────────────────────────────────────

class TestSendMessage:
    def test_unknown_channel(self):
        tool = SendMessageTool()
        result = asyncio.get_event_loop().run_until_complete(
            tool.execute({"channel": "nope", "user_id": "u", "content": "hi"})
        )
        data = json.loads(result)
        assert data["success"] is False
        assert "未知渠道" in data["error"]

    def test_registered_channel(self):
        sent = []

        async def mock_sender(user_id, content, message_type="text"):
            sent.append({"user_id": user_id, "content": content})
            return "ok"

        tool = SendMessageTool(channel_registry={"test": mock_sender})
        result = asyncio.get_event_loop().run_until_complete(
            tool.execute({"channel": "test", "user_id": "u1", "content": "hello"})
        )
        data = json.loads(result)
        assert data["success"] is True
        assert len(sent) == 1

    def test_send_message_func(self):
        async def run():
            result = await send_message("missing", "u", "hi")
            assert result["success"] is False
        asyncio.get_event_loop().run_until_complete(run())

    def test_send_notification(self):
        async def run():
            result = await send_notification(["a", "b"], "msg")
            assert result["total"] == 2
            assert all(not v["success"] for v in result["channels"].values())
        asyncio.get_event_loop().run_until_complete(run())

    def test_register_channel(self):
        tool = SendMessageTool()
        tool.register_channel("ch", lambda **kw: None)
        assert "ch" in tool._channels
