"""基础设施测试 - constants / utils / logging_config / state / skills"""

import json
import logging
import os
import tempfile
import time

import pytest

from src.constants import (
    VERSION,
    DEFAULT_MODEL,
    MAX_CONTEXT_TOKENS,
    RE_CHINESE,
    RE_DURATION,
    RE_DANGEROUS_CMD,
    RE_INTERNAL_IP,
    SENSITIVE_PATHS,
)
from src.utils import (
    estimate_tokens,
    truncate_text,
    safe_json_loads,
    format_timestamp,
    human_readable_size,
    is_chinese,
    deep_merge,
    hash_text,
    parse_duration,
)
from src.logging_config import (
    setup_logging,
    get_logger,
    log_api_call,
    log_tool_call,
    JsonFormatter,
)
from src.agent.state import AgentState, MessageStats, ToolStats, CostTracker
from src.skills.hub import SkillHub, SkillInfo
from src.skills.guard import validate_skill, is_skill_safe_to_run
from src.skills.sync import SkillSync


# ── constants ─────────────────────────────────────────────────────────


class TestConstants:
    def test_version_format(self):
        parts = VERSION.split(".")
        assert len(parts) >= 2

    def test_default_model_is_cn(self):
        assert DEFAULT_MODEL in ("qwen-plus", "deepseek-chat", "glm-4")

    def test_re_chinese_matches(self):
        assert RE_CHINESE.search("你好")
        assert not RE_CHINESE.search("hello")

    def test_re_duration_matches(self):
        assert RE_DURATION.match("30s")
        assert RE_DURATION.match("5m")
        assert not RE_DURATION.match("abc")

    def test_re_dangerous_cmd(self):
        assert RE_DANGEROUS_CMD.search("rm -rf /tmp")
        assert not RE_DANGEROUS_CMD.search("echo hello")

    def test_re_internal_ip(self):
        assert RE_INTERNAL_IP.match("127.0.0.1")
        assert RE_INTERNAL_IP.match("10.0.0.1")
        assert not RE_INTERNAL_IP.match("8.8.8.8")


# ── utils ─────────────────────────────────────────────────────────────


class TestUtils:
    def test_estimate_tokens_chinese(self):
        tokens = estimate_tokens("你好世界")
        assert tokens > 0

    def test_estimate_tokens_empty(self):
        assert estimate_tokens("") == 0

    def test_truncate_text(self):
        assert truncate_text("abcdef", 5) == "ab..."

    def test_truncate_text_short(self):
        assert truncate_text("ab", 5) == "ab"

    def test_safe_json_loads_valid(self):
        result = safe_json_loads('{"a": 1}')
        assert result == {"a": 1}

    def test_safe_json_loads_invalid(self):
        assert safe_json_loads("not json") is None

    def test_safe_json_loads_codeblock(self):
        result = safe_json_loads('```json\n{"b": 2}\n```')
        assert result == {"b": 2}

    def test_format_timestamp(self):
        ts = format_timestamp(0)
        assert len(ts) > 10  # 至少有日期部分

    def test_human_readable_size(self):
        assert "KB" in human_readable_size(2048)
        assert "B" in human_readable_size(100)

    def test_is_chinese_true(self):
        assert is_chinese("你好世界啊") is True

    def test_is_chinese_false(self):
        assert is_chinese("hello world") is False

    def test_deep_merge(self):
        base = {"a": 1, "b": {"x": 1}}
        over = {"b": {"y": 2}, "c": 3}
        result = deep_merge(base, over)
        assert result["a"] == 1
        assert result["b"] == {"x": 1, "y": 2}
        assert result["c"] == 3

    def test_hash_text(self):
        h1 = hash_text("hello")
        h2 = hash_text("hello")
        assert h1 == h2
        assert len(h1) == 16

    def test_parse_duration(self):
        assert parse_duration("30s") == 30
        assert parse_duration("2m") == 120
        assert parse_duration("1h") == 3600
        assert parse_duration("1d") == 86400

    def test_parse_duration_pure_number(self):
        assert parse_duration("60") == 60

    def test_parse_duration_invalid(self):
        with pytest.raises(ValueError):
            parse_duration("abc")


# ── logging_config ────────────────────────────────────────────────────


class TestLogging:
    def test_setup_returns_logger(self):
        logger = setup_logging(level="WARNING", console=True)
        assert isinstance(logger, logging.Logger)
        assert logger.name == "leaper"

    def test_get_logger(self):
        logger = get_logger("test_module")
        assert logger.name == "leaper.test_module"

    def test_json_formatter(self):
        fmt = JsonFormatter()
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="hello", args=(), exc_info=None,
        )
        output = fmt.format(record)
        data = json.loads(output)
        assert "timestamp" in data
        assert data["level"] == "INFO"

    def test_log_api_call_no_crash(self):
        setup_logging(level="WARNING", console=False)
        log_api_call("qwen", "qwen-plus", 100, 0.5)  # 不应崩溃

    def test_log_tool_call_no_crash(self):
        setup_logging(level="WARNING", console=False)
        log_tool_call("read", {"path": "/tmp/x"}, 500)


# ── state ─────────────────────────────────────────────────────────────


class TestAgentState:
    def test_record_message(self):
        state = AgentState()
        state.record_message("user", tokens=10)
        state.record_message("assistant", tokens=20)
        assert state.messages.total == 2
        assert state.messages.user_messages == 1
        assert state.messages.total_tokens == 30

    def test_record_tool_call(self):
        state = AgentState()
        state.record_tool_call("read", success=True)
        state.record_tool_call("read", success=False)
        assert state.tools.total_calls == 2
        assert state.tools.success_count == 1
        assert state.tools.error_count == 1
        assert state.tools.by_tool["read"] == 2

    def test_record_api_call(self):
        state = AgentState()
        state.record_api_call("qwen", "qwen-plus", 100, 50)
        assert state.costs.total_api_calls == 1
        assert state.costs.total_tokens_in == 100

    def test_record_error(self):
        state = AgentState()
        state.record_error("timeout", "API 超时", context="qwen")
        assert len(state.errors) == 1
        assert state.errors[0].error_type == "timeout"

    def test_session_lifecycle(self):
        state = AgentState()
        info = state.start_session("s1", channel="telegram")
        assert info.session_id == "s1"
        assert len(state.get_active_sessions()) == 1
        state.end_session("s1")
        assert len(state.get_active_sessions()) == 0

    def test_save_and_load(self, tmp_path):
        state = AgentState(state_dir=str(tmp_path))
        state.record_message("user", tokens=10)
        state.record_tool_call("exec")
        state.record_error("test", "test error")
        state.save()

        state2 = AgentState(state_dir=str(tmp_path))
        assert state2.load() is True
        assert state2.messages.total == 1
        assert state2.tools.total_calls == 1
        assert len(state2.errors) == 1

    def test_get_summary(self):
        state = AgentState()
        summary = state.get_summary()
        assert "uptime_seconds" in summary
        assert "messages" in summary
        assert "costs" in summary

    def test_reset(self):
        state = AgentState()
        state.record_message("user")
        state.reset()
        assert state.messages.total == 0


# ── skills hub / guard / sync ─────────────────────────────────────────


class TestSkillHub:
    def test_list_empty(self, tmp_path):
        hub = SkillHub(str(tmp_path / "skills"))
        assert hub.list_skills() == []

    def test_install_and_search(self, tmp_path):
        skills_dir = tmp_path / "skills"
        source = tmp_path / "my_skill"
        source.mkdir()
        (source / "SKILL.md").write_text("# My Skill\nA test skill", encoding="utf-8")

        hub = SkillHub(str(skills_dir))
        hub.install_skill("my_skill", str(source))
        results = hub.search_skills("my")
        assert len(results) == 1
        assert results[0].name == "my_skill"

    def test_uninstall(self, tmp_path):
        skills_dir = tmp_path / "skills"
        source = tmp_path / "sk"
        source.mkdir()
        (source / "SKILL.md").write_text("# SK\nDesc", encoding="utf-8")

        hub = SkillHub(str(skills_dir))
        hub.install_skill("sk", str(source))
        hub.uninstall_skill("sk")
        assert hub.list_skills() == []


class TestSkillGuard:
    def test_missing_dir(self):
        issues = validate_skill("/nonexistent/path")
        assert len(issues) > 0

    def test_valid_skill(self, tmp_path):
        (tmp_path / "SKILL.md").write_text("# Test\nDescription", encoding="utf-8")
        issues = validate_skill(str(tmp_path))
        assert len(issues) == 0

    def test_missing_skill_md(self, tmp_path):
        issues = validate_skill(str(tmp_path))
        assert any("SKILL.md" in i for i in issues)


class TestSkillSync:
    def test_sync_new_skill(self, tmp_path):
        local = tmp_path / "local"
        source = tmp_path / "source" / "sk"
        source.mkdir(parents=True)
        (source / "SKILL.md").write_text("# SK", encoding="utf-8")

        sync = SkillSync(str(local))
        result = sync.sync_skill("sk", str(source))
        assert result.status == "updated"

    def test_sync_unchanged(self, tmp_path):
        local = tmp_path / "local"
        source = tmp_path / "source" / "sk"
        source.mkdir(parents=True)
        (source / "SKILL.md").write_text("# SK", encoding="utf-8")

        sync = SkillSync(str(local))
        sync.sync_skill("sk", str(source))
        result = sync.sync_skill("sk", str(source))
        assert result.status == "unchanged"
