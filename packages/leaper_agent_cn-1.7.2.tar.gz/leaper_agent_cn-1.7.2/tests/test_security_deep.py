"""安全模块深度测试 - path_guard / url_guard / approval / sandbox"""

import asyncio
import os
import sys
import tempfile

import pytest

from src.security.path_guard import is_safe_path, sanitize_path, is_sensitive_path
from src.security.url_guard import is_safe_url, normalize_url
from src.security.approval import (
    ApprovalEngine, ActionType, ApprovalLevel, ApprovalStatus,
)
from src.security.sandbox import Sandbox, ResourceLimits


# ── path_guard ────────────────────────────────────────────────────────


class TestPathGuard:
    """路径安全守卫测试"""

    def test_safe_path_normal(self, tmp_path):
        ws = str(tmp_path)
        assert is_safe_path("sub/file.txt", ws) is True

    def test_path_traversal_blocked(self, tmp_path):
        ws = str(tmp_path)
        assert is_safe_path("../../etc/passwd", ws) is False

    def test_sensitive_path_blocked(self, tmp_path):
        ws = str(tmp_path / "project")
        # 含 .ssh 的路径应被拒
        assert is_safe_path("/.ssh/id_rsa", ws) is False

    def test_empty_path_rejected(self, tmp_path):
        assert is_safe_path("", str(tmp_path)) is False

    def test_sanitize_removes_null(self):
        assert "\x00" not in sanitize_path("foo\x00bar.txt")

    def test_sanitize_normalizes(self):
        result = sanitize_path("a/b/../c")
        assert ".." not in result

    def test_is_sensitive_path_true(self):
        assert is_sensitive_path("/home/user/.ssh/id_rsa") is True

    def test_is_sensitive_path_false(self):
        assert is_sensitive_path("/home/user/readme.md") is False


# ── url_guard ─────────────────────────────────────────────────────────


class TestUrlGuard:
    """URL 安全守卫测试"""

    def test_safe_url(self):
        assert is_safe_url("https://example.com/api") is True

    def test_localhost_blocked(self):
        assert is_safe_url("http://localhost:8080/") is False

    def test_internal_ip_blocked(self):
        assert is_safe_url("http://10.0.0.1/admin") is False
        assert is_safe_url("http://192.168.1.1/") is False
        assert is_safe_url("http://172.16.0.1/") is False

    def test_metadata_blocked(self):
        assert is_safe_url("http://169.254.169.254/latest/meta-data/") is False

    def test_file_protocol_blocked(self):
        assert is_safe_url("file:///etc/passwd") is False

    def test_empty_url(self):
        assert is_safe_url("") is False

    def test_normalize_adds_scheme(self):
        assert normalize_url("example.com").startswith("https://")

    def test_normalize_preserves_https(self):
        result = normalize_url("https://example.com/path?q=1")
        assert "example.com" in result
        assert "q=1" in result


# ── approval ──────────────────────────────────────────────────────────


class TestApprovalEngine:
    """操作审批引擎测试"""

    def setup_method(self):
        self.engine = ApprovalEngine()

    def test_file_read_auto_approve(self):
        result = self.engine.check_approval(ActionType.FILE_READ, {"path": "/tmp/foo.txt"})
        assert result.is_approved

    def test_sensitive_read_denied(self):
        result = self.engine.check_approval(ActionType.FILE_READ, {"path": "/home/.ssh/id_rsa"})
        assert result.is_denied

    def test_file_delete_needs_prompt(self):
        result = self.engine.check_approval(ActionType.FILE_DELETE, {"path": "/tmp/foo.txt"})
        assert result.level == ApprovalLevel.PROMPT_USER

    def test_system_modify_denied(self):
        result = self.engine.check_approval(ActionType.SYSTEM_MODIFY)
        assert result.is_denied

    def test_dangerous_command_prompt(self):
        result = self.engine.check_approval(
            ActionType.COMMAND_EXEC, {"command": "rm -rf /tmp/data"}
        )
        assert result.level == ApprovalLevel.PROMPT_USER

    def test_safe_command_auto_approve(self):
        result = self.engine.check_approval(
            ActionType.COMMAND_EXEC, {"command": "ls -la"}
        )
        assert result.is_approved

    def test_system_file_write_denied(self):
        result = self.engine.check_approval(
            ActionType.FILE_WRITE, {"path": "C:\\Windows\\system32\\foo"}
        )
        assert result.is_denied

    def test_history_recorded(self):
        self.engine.check_approval(ActionType.FILE_READ, {"path": "/tmp/x"})
        self.engine.check_approval(ActionType.FILE_READ, {"path": "/tmp/y"})
        assert len(self.engine.get_history()) == 2


# ── sandbox ───────────────────────────────────────────────────────────


class TestSandbox:
    """沙箱测试"""

    def test_dangerous_command_rejected(self):
        sb = Sandbox()
        ok, reason = sb.check_command("rm -rf /")
        assert not ok

    def test_safe_command_allowed(self):
        sb = Sandbox()
        ok, _ = sb.check_command("echo hello")
        assert ok

    def test_resource_limits_defaults(self):
        limits = ResourceLimits()
        assert limits.max_memory_mb == 512
        assert limits.allow_network is True

    def test_temp_dir_isolation(self):
        limits = ResourceLimits(use_temp_dir=True)
        sb = Sandbox(resource_limits=limits)
        assert sb._limits.use_temp_dir is True
