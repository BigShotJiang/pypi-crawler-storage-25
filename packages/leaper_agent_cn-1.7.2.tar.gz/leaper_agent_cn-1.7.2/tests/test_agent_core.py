"""Agent Core 模块测试 — 压缩器、错误分类、限流器、重试、脱敏、Prompt Builder。"""

from __future__ import annotations

import asyncio
import time
import pytest

# ── 压缩器测试 ──────────────────────────────────────────────────────────

from src.agent.compressor import (
    compress_if_needed,
    estimate_tokens,
    estimate_messages_tokens,
)


class TestCompressor:
    def test_empty_history(self):
        """空历史不压缩"""
        result = compress_if_needed([], max_tokens=1000)
        assert result == []

    def test_short_history_no_compress(self):
        """短历史不触发压缩"""
        msgs = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
        ]
        result = compress_if_needed(msgs, max_tokens=100000)
        assert result == msgs

    def test_long_history_compress(self):
        """长历史触发压缩"""
        msgs = [{"role": "system", "content": "你是助手"}]
        for i in range(100):
            msgs.append({"role": "user", "content": f"问题{i} " * 50})
            msgs.append({"role": "assistant", "content": f"回答{i} " * 50})
        result = compress_if_needed(msgs, max_tokens=500, keep_recent=10)
        # 应该有 system + summary + 10 条最近消息
        assert len(result) < len(msgs)
        # 检查摘要消息
        summary_msgs = [m for m in result if "对话摘要" in (m.get("content") or "")]
        assert len(summary_msgs) == 1

    def test_chinese_token_estimate(self):
        """中文 token 估算"""
        text = "你好世界"  # 4 个中文字符
        tokens = estimate_tokens(text)
        assert tokens == 8  # 4 * 2

    def test_english_token_estimate(self):
        """英文 token 估算"""
        text = "hello world test"  # 16 chars
        tokens = estimate_tokens(text)
        assert tokens == 4  # 16 // 4

    def test_mixed_token_estimate(self):
        """中英混合 token 估算"""
        text = "你好 hello"  # 2 中文 + 6 英文
        tokens = estimate_tokens(text)
        assert tokens == 2 * 2 + 6 // 4  # 4 + 1 = 5


# ── 错误分类测试 ──────────────────────────────────────────────────────────

from src.agent.error_classifier import classify_error, ErrorCategory


class _FakeResponse:
    def __init__(self, status_code, headers=None):
        self.status_code = status_code
        self.headers = headers or {}


class _FakeHTTPError(Exception):
    def __init__(self, status_code, message="", headers=None):
        super().__init__(message)
        self.response = _FakeResponse(status_code, headers)


class TestErrorClassifier:
    def test_429_rate_limit(self):
        """429 归类为 rate_limit"""
        info = classify_error(_FakeHTTPError(429, "Too Many Requests"))
        assert info.category == ErrorCategory.rate_limit
        assert info.retryable is True

    def test_401_auth(self):
        """401 归类为 auth"""
        info = classify_error(_FakeHTTPError(401, "Unauthorized"))
        assert info.category == ErrorCategory.auth
        assert info.retryable is False

    def test_500_server_error(self):
        """500 归类为 server_error"""
        info = classify_error(_FakeHTTPError(500, "Internal Server Error"))
        assert info.category == ErrorCategory.server_error
        assert info.retryable is True

    def test_network_error(self):
        """网络错误归类为 network"""
        info = classify_error(ConnectionError("Connection refused"))
        assert info.category == ErrorCategory.network
        assert info.retryable is True

    def test_context_overflow(self):
        """上下文过长"""
        info = classify_error(Exception("maximum context length exceeded"))
        assert info.category == ErrorCategory.context_overflow
        assert info.should_compress is True

    def test_retry_after_header(self):
        """从 Retry-After 头提取等待时间"""
        exc = _FakeHTTPError(429, "rate limit", headers={"retry-after": "45"})
        info = classify_error(exc)
        assert info.wait_seconds == 45.0


# ── 限流器测试 ──────────────────────────────────────────────────────────

from src.agent.rate_limiter import RateLimiter


class TestRateLimiter:
    def test_normal_pass(self):
        """正常情况下允许调用"""
        limiter = RateLimiter(max_calls=10, window_seconds=60)
        assert limiter.check_rate_limit() is True

    def test_over_limit(self):
        """超限后拒绝调用"""
        limiter = RateLimiter(max_calls=3, window_seconds=60)
        for _ in range(3):
            limiter.record_call()
        assert limiter.check_rate_limit() is False

    def test_current_count(self):
        """计数准确"""
        limiter = RateLimiter(max_calls=10, window_seconds=60)
        limiter.record_call()
        limiter.record_call()
        assert limiter.current_count == 2


# ── 重试测试 ──────────────────────────────────────────────────────────

from src.agent.retry import retry_with_backoff, jittered_backoff


class TestRetry:
    def test_success_no_retry(self):
        """成功时不重试"""
        async def ok():
            return "ok"
        result = asyncio.get_event_loop().run_until_complete(
            retry_with_backoff(ok, max_retries=3)
        )
        assert result == "ok"

    def test_eventual_success(self):
        """失败后重试成功"""
        call_count = 0
        async def flaky():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ConnectionError("timeout")
            return "recovered"
        result = asyncio.get_event_loop().run_until_complete(
            retry_with_backoff(flaky, max_retries=3, classify=False)
        )
        assert result == "recovered"
        assert call_count == 3

    def test_max_retries_exceeded(self):
        """超过最大重试次数后抛出"""
        async def always_fail():
            raise ConnectionError("timeout")
        with pytest.raises(ConnectionError):
            asyncio.get_event_loop().run_until_complete(
                retry_with_backoff(always_fail, max_retries=1, classify=False)
            )

    def test_non_retryable_error(self):
        """不可重试的错误直接抛出"""
        async def auth_fail():
            raise _FakeHTTPError(401, "Unauthorized")
        with pytest.raises(_FakeHTTPError):
            asyncio.get_event_loop().run_until_complete(
                retry_with_backoff(auth_fail, max_retries=3, classify=True)
            )

    def test_jittered_backoff_increases(self):
        """退避延迟随重试次数增加"""
        d1 = jittered_backoff(1, base_delay=1.0, jitter_ratio=0)
        d2 = jittered_backoff(2, base_delay=1.0, jitter_ratio=0)
        d3 = jittered_backoff(3, base_delay=1.0, jitter_ratio=0)
        assert d1 < d2 < d3


# ── 脱敏测试 ──────────────────────────────────────────────────────────

from src.agent.redact import redact_sensitive


class TestRedact:
    def test_api_key_redact(self):
        """API key 脱敏"""
        text = "key is sk-abcdefghijklmnopqrstuvwxyz1234567890"
        result = redact_sensitive(text)
        assert "sk-abc" not in result or "..." in result
        assert "1234567890" not in result or len(result) < len(text)

    def test_phone_redact(self):
        """手机号脱敏"""
        text = "联系电话：13812345678"
        result = redact_sensitive(text)
        assert "138****5678" in result

    def test_id_card_redact(self):
        """身份证号脱敏"""
        text = "身份证：110101199001011234"
        result = redact_sensitive(text)
        assert "1101" in result
        assert "1234" in result
        assert "199001011" not in result

    def test_empty_text(self):
        """空文本不报错"""
        assert redact_sensitive("") == ""
        assert redact_sensitive(None) is None


# ── Prompt Builder 测试 ──────────────────────────────────────────────

from src.agent.prompt_builder import LeaperPromptBuilder


class TestPromptBuilder:
    def test_build_env_info(self):
        """环境信息包含 OS"""
        builder = LeaperPromptBuilder("/nonexistent", None)
        info = builder._build_env_info()
        assert "OS:" in info

    def test_load_missing_file(self):
        """缺失文件优雅降级"""
        builder = LeaperPromptBuilder("/nonexistent/path", None)
        result = builder._load_file("SOUL.md")
        assert result == ""

    def test_truncate(self):
        """截断长文本"""
        builder = LeaperPromptBuilder("/tmp", None)
        long_text = "a" * 3000
        result = builder._truncate(long_text, max_chars=100)
        assert len(result) <= 100
        assert "truncated" in result
