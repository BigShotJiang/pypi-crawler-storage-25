"""
Brain + Evolution 端到端集成测试。
用 :memory: 数据库，不 mock brain，验证完整流程。
"""

import pytest
from src.brain.engine import LeaperBrain
from src.brain.evolution import LeaperEvolution


AGENT_ID = "test-agent"


@pytest.fixture
async def brain():
    """创建并初始化一个内存 brain"""
    b = LeaperBrain(":memory:", agent_id=AGENT_ID)
    await b.initialize()
    yield b
    await b.close()


@pytest.fixture
async def evolution(brain):
    """基于 brain 的 evolution 引擎"""
    return LeaperEvolution(brain)


# ── 辅助函数 ──────────────────────────────────────────────────────────

async def _seed_conversations(brain: LeaperBrain, count: int = 10):
    """往 brain 里存 count 条对话"""
    for i in range(count):
        await brain.store_message("s1", "user", f"用户消息第{i}条，关于AI技术和产品设计")
        await brain.store_message("s1", "assistant", f"助手回复第{i}条，我们的AI产品使用深度学习模型")


async def _seed_knowledge(brain: LeaperBrain):
    """通过 extract_knowledge 注入一些知识条目"""
    conversations = [
        [
            {"role": "user", "content": "我们公司做AI情景智能，主要产品叫瞬知引擎，服务B端客户"},
            {"role": "assistant", "content": "了解，你们的AI情景智能引擎叫瞬知，面向B端提供智能推荐服务，这是很好的方向"},
        ],
        [
            {"role": "user", "content": "我喜欢用Python写后端，团队擅长深度学习和NLP技术"},
            {"role": "assistant", "content": "Python后端加深度学习NLP是很好的技术栈组合，适合AI产品开发"},
        ],
        [
            {"role": "user", "content": "昨天我们完成了新版本部署，服务器在阿里云上运行"},
            {"role": "assistant", "content": "新版本部署到阿里云完成，建议做好监控和告警配置"},
        ],
    ]
    for conv in conversations:
        await brain.extract_knowledge(conv)


# ── 完整生命周期 ──────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_full_lifecycle(brain, evolution):
    """完整生命周期：存储 → 提取 → 进化 → 召回"""
    # 存对话
    await _seed_conversations(brain)

    # 提取知识
    await _seed_knowledge(brain)

    # 验证有知识条目
    entries = await brain.get_entries(entry_type="knowledge")
    assert len(entries) > 0, "extract_knowledge 应产生知识条目"

    # 召回
    recalled = await brain.recall("AI 公司 产品")
    assert len(recalled) > 0, "recall 应返回相关条目"

    # 触发完整进化
    summary = await evolution.run_full_evolution()
    assert "l5_health" in summary
    assert summary["l5_health"]["total_entries"] >= 0


# ── L1: 经验提取 ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_l1_experience_extraction(brain, evolution):
    """L1: 从对话中提取经验条目"""
    conversation = [
        {"role": "user", "content": "我们的部署流程是先在staging环境测试，然后灰度发布到生产环境"},
        {"role": "assistant", "content": "这个部署流程很规范：staging测试加灰度发布，能有效降低上线风险"},
    ]
    extracted = await evolution.evolve_l1_extract(conversation)

    # 应至少提取出一些条目
    assert len(extracted) > 0, "L1 应从对话中提取出经验"

    # 验证条目有必要字段
    for entry in extracted:
        assert "content" in entry
        assert "category" in entry
        assert "confidence" in entry
        assert entry["status"] == "active"

    # 验证持久化 — 通过 brain.get_entries 应能查到
    all_entries = await brain.get_entries()
    assert len(all_entries) > 0


@pytest.mark.asyncio
async def test_l1_dedup(brain, evolution):
    """L1: 重复内容不应重复提取"""
    conversation = [
        {"role": "user", "content": "我们公司的主要产品是AI推荐引擎，服务于电商平台"},
    ]
    first = await evolution.evolve_l1_extract(conversation)
    second = await evolution.evolve_l1_extract(conversation)

    # 第二次提取应因去重而返回更少或 0 条
    assert len(second) <= len(first), "重复对话不应重复提取"


# ── L2: 知识整合 ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_l2_consolidation(brain, evolution):
    """L2: 相似条目应被合并"""
    # 插入多条相似知识
    for i in range(5):
        await brain.store_entry(
            entry_type="knowledge",
            content=f"我们的AI产品使用深度学习模型进行推荐，效果很好，版本{i}",
            category="tech",
            confidence=0.8,
        )

    consolidated = await evolution.evolve_l2_consolidate()
    # 5 条高相似度内容应触发合并
    # （取决于相似度阈值，可能合并也可能不合并）
    # 至少不应报错
    assert isinstance(consolidated, list)


@pytest.mark.asyncio
async def test_l2_different_categories_not_merged(brain, evolution):
    """L2: 不同类别的条目不应合并"""
    await brain.store_entry("knowledge", "AI技术架构设计方案", category="tech", confidence=0.8)
    await brain.store_entry("knowledge", "市场营销策略分析报告", category="business", confidence=0.8)

    consolidated = await evolution.evolve_l2_consolidate()
    # 不同类别不应合并
    assert len(consolidated) == 0


# ── L3: 技能提升 ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_l3_skill_promotion(brain, evolution):
    """L3: 高频高置信度条目应被提升为 skill"""
    # 插入一个高置信度、高访问量的条目
    entry_id = await brain.store_entry(
        entry_type="knowledge",
        content="使用Docker部署微服务的标准流程和最佳实践",
        category="tech",
        confidence=0.9,
    )
    # 模拟多次访问
    await brain.increment_access(entry_id)
    await brain.increment_access(entry_id)

    promoted = await evolution.evolve_l3_skill()
    assert len(promoted) > 0, "高频高置信度条目应被提升"
    assert promoted[0]["category"] == "skill"


@pytest.mark.asyncio
async def test_l3_low_access_not_promoted(brain, evolution):
    """L3: 低访问量条目不应被提升"""
    await brain.store_entry(
        entry_type="knowledge",
        content="某个很少被用到的知识点内容",
        category="tech",
        confidence=0.9,
    )
    # 不增加访问量

    promoted = await evolution.evolve_l3_skill()
    assert len(promoted) == 0, "低访问量条目不应被提升"


# ── L4: 画像构建 ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_l4_profile_building(brain, evolution):
    """L4: 从知识条目构建用户画像"""
    # 插入各维度的知识
    await brain.store_entry("knowledge", "用户喜欢简洁的代码风格，偏好函数式编程", category="preference", confidence=0.8)
    await brain.store_entry("knowledge", "用户擅长Python和机器学习，有10年经验", category="tech", confidence=0.8)
    await brain.store_entry("knowledge", "用户在AI公司工作，负责技术团队管理", category="business", confidence=0.8)

    profile = await evolution.evolve_l4_profile("test-user")

    assert profile["user_id"] == "test-user"
    assert len(profile["preference"]) > 0, "应检测到偏好维度"
    assert len(profile["expertise"]) > 0, "应检测到专业维度"
    assert len(profile["context"]) > 0, "应检测到上下文维度"


# ── L5: 元健康检查 ───────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_l5_meta_health(brain, evolution):
    """L5: 知识库健康度检查"""
    # 空库
    report = await evolution.evolve_l5_meta()
    assert report["total_entries"] == 0
    assert report["consistency_score"] == 1.0

    # 添加一些知识
    await brain.store_entry("knowledge", "AI技术相关知识", category="fact", confidence=0.8)
    await brain.store_entry("knowledge", "用户偏好记录", category="preference", confidence=0.7)

    report = await evolution.evolve_l5_meta()
    assert report["total_entries"] == 2
    assert report["coverage_score"] > 0, "应有维度覆盖"
    assert "decay_report" in report


# ── 进化后召回 ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_recall_after_evolution(brain, evolution):
    """进化后的 recall 应正常工作"""
    await _seed_knowledge(brain)

    # 进化前召回
    before = await brain.recall("AI 产品 推荐")

    # 执行进化
    await evolution.run_full_evolution()

    # 进化后召回
    after = await brain.recall("AI 产品 推荐")

    # 进化后不应崩溃，且应有结果
    assert isinstance(after, list)


# ── 幂等性 ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_evolution_idempotent(brain, evolution):
    """连续两次进化不应崩溃"""
    await _seed_knowledge(brain)

    result1 = await evolution.run_full_evolution()
    result2 = await evolution.run_full_evolution()

    assert "l5_health" in result1
    assert "l5_health" in result2


# ── 通过 orchestrator 使用完整 brain ─────────────────────────────────

@pytest.mark.asyncio
async def test_brain_with_orchestrator(tmp_path):
    """通过 orchestrator 使用完整 brain（轻量集成）"""
    from src.brain.orchestrator import LeaperOrchestrator

    workspace = str(tmp_path / "workspace")
    db_path = ":memory:"

    orch = LeaperOrchestrator(agent_id=AGENT_ID, db_path=db_path, workspace_dir=workspace)
    await orch.initialize()

    assert orch.brain is not None
    assert orch.evolution is not None

    # 存消息 + 提取知识
    await orch.on_response("s1", "我们用FastAPI做后端", "好的，FastAPI是很好的选择")

    # 召回
    recalled = await orch.brain.recall("FastAPI 后端")
    # 可能有也可能没有（取决于 4-gate），但不应崩溃
    assert isinstance(recalled, list)

    # 会话结束触发进化
    await orch.on_session_end("s1")

    await orch.shutdown()


# ── L1 通过 evolution 提取 + brain 4-gate 提取对比 ───────────────────

@pytest.mark.asyncio
async def test_l1_vs_brain_extract(brain, evolution):
    """L1 evolution 提取和 brain.extract_knowledge 都能工作"""
    conv = [
        {"role": "user", "content": "我们团队有15个人，分成3个小组，每组负责不同的模块"},
        {"role": "assistant", "content": "15人团队分3组的架构很合理，可以保证模块间的独立性和并行开发"},
    ]

    # brain 的 extract_knowledge
    brain_extracted = await brain.extract_knowledge(conv)

    # evolution 的 L1（可能会因去重而提取更少）
    evo_extracted = await evolution.evolve_l1_extract(conv)

    # 两者都不应崩溃
    assert isinstance(brain_extracted, list)
    assert isinstance(evo_extracted, list)
