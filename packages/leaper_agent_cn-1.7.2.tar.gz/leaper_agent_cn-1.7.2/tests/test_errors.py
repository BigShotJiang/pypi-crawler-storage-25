"""错误处理框架测试"""
import pytest

from src.errors import (
    LeaperError, ConfigError, ProviderError, ToolError,
    SecurityError, BrainError, ChannelError, AuthError,
    RateLimitError, TokenExhaustedError, TimeoutError,
    ValidationError, user_friendly_error, log_error, wrap_error,
)


class TestLeaperError:
    def test_basic(self):
        e = LeaperError("test error")
        assert str(e) == "test error"
        assert e.code is None
        assert e.details == {}

    def test_with_code_and_details(self):
        e = LeaperError("fail", code="E001", details={"key": "val"})
        assert e.code == "E001"
        assert e.details["key"] == "val"

    def test_repr(self):
        e = LeaperError("msg", code="X")
        assert "LeaperError" in repr(e)
        assert "X" in repr(e)

    def test_inheritance(self):
        assert issubclass(RateLimitError, ProviderError)
        assert issubclass(ProviderError, LeaperError)
        assert issubclass(TokenExhaustedError, ProviderError)
        assert issubclass(AuthError, LeaperError)


class TestUserFriendlyError:
    def test_provider_error(self):
        msg = user_friendly_error(ProviderError("api down"))
        assert "不可用" in msg

    def test_rate_limit(self):
        msg = user_friendly_error(RateLimitError("429"))
        assert "频繁" in msg

    def test_security_error(self):
        msg = user_friendly_error(SecurityError("blocked"))
        assert "禁止" in msg

    def test_config_error(self):
        msg = user_friendly_error(ConfigError("missing key"))
        assert "配置" in msg

    def test_unknown_error(self):
        msg = user_friendly_error(ValueError("random"))
        assert "未知" in msg

    def test_auth_error(self):
        msg = user_friendly_error(AuthError("expired"))
        assert "认证" in msg or "登录" in msg


class TestLogError:
    def test_log_leaper_error(self, caplog):
        import logging
        with caplog.at_level(logging.ERROR):
            log_error(LeaperError("test", code="E1"))
        assert "E1" in caplog.text

    def test_log_generic_error(self, caplog):
        import logging
        with caplog.at_level(logging.ERROR):
            log_error(ValueError("oops"))
        assert "oops" in caplog.text

    def test_log_with_sensitive_context(self, caplog):
        import logging
        with caplog.at_level(logging.ERROR):
            log_error(LeaperError("x"), context={"api_key": "sk-secret"})
        assert "sk-secret" not in caplog.text
        assert "***" in caplog.text


class TestWrapError:
    def test_wrap_generic(self):
        e = wrap_error(ValueError("bad"), ConfigError, code="C1")
        assert isinstance(e, ConfigError)
        assert e.code == "C1"

    def test_wrap_already_leaper(self):
        orig = ProviderError("already")
        assert wrap_error(orig) is orig
