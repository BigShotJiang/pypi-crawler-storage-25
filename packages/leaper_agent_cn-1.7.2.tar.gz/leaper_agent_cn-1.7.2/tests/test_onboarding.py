"""测试冷启动引导管理器"""

import asyncio
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from agent.onboarding import OnboardingManager


@pytest.fixture
def mock_brain():
    brain = AsyncMock()
    brain.recall = AsyncMock(return_value=[])
    brain.extract_and_learn = AsyncMock()
    return brain


@pytest.fixture
def manager(mock_brain):
    return OnboardingManager(mock_brain, workspace_dir="")


class TestNeedsOnboarding:
    def test_needs_onboarding_empty_brain(self, manager):
        """brain 中无用户信息时，需要引导"""
        # needs_onboarding 同步版本，默认返回 True（未完成）
        assert manager.needs_onboarding() is True

    def test_needs_onboarding_with_user_info(self, mock_brain):
        """brain 中已有用户信息时，不需要引导"""
        mock_brain.recall = AsyncMock(return_value=["用户信息: 公司: 跃盟科技, 行业: AI"])
        mgr = OnboardingManager(mock_brain, workspace_dir="")
        # 通过 async 方法验证
        result = asyncio.get_event_loop().run_until_complete(mgr.async_needs_onboarding())
        assert result is False

    def test_needs_onboarding_after_complete(self, manager):
        """complete_onboarding 后不再需要引导"""
        asyncio.get_event_loop().run_until_complete(
            manager.complete_onboarding({"company": "测试公司"})
        )
        assert manager.needs_onboarding() is False


class TestGetOnboardingPrompt:
    def test_get_onboarding_prompt_from_workspace(self):
        """从 workspace_dir 读取 ONBOARDING.md"""
        with tempfile.TemporaryDirectory() as tmpdir:
            ob_file = Path(tmpdir) / "ONBOARDING.md"
            ob_file.write_text("# 测试引导内容", encoding="utf-8")
            mgr = OnboardingManager(None, workspace_dir=tmpdir)
            assert "测试引导内容" in mgr.get_onboarding_prompt()

    def test_get_onboarding_prompt_fallback(self):
        """workspace 没有时 fallback 到 bundled _common"""
        mgr = OnboardingManager(None, workspace_dir="/nonexistent/path")
        prompt = mgr.get_onboarding_prompt()
        # fallback 路径存在则有内容，不存在则空字符串
        # 这里验证不会抛异常
        assert isinstance(prompt, str)


class TestCheckComplete:
    def test_check_complete_by_rounds(self, manager):
        """超过 5 轮用户消息时，引导完成"""
        conversation = [
            {"role": "user", "content": f"消息{i}"} for i in range(5)
        ]
        assert manager.check_onboarding_complete(conversation) is True

    def test_check_complete_by_info(self, manager):
        """对话中包含足够信息时（公司+行业），引导完成"""
        conversation = [
            {"role": "user", "content": "我是跃盟科技的，我们做AI"},
            {"role": "user", "content": "目前B轮阶段"},
        ]
        assert manager.check_onboarding_complete(conversation) is True

    def test_check_incomplete(self, manager):
        """信息不足且轮数不够时，引导未完成"""
        conversation = [
            {"role": "user", "content": "你好"},
        ]
        assert manager.check_onboarding_complete(conversation) is False


class TestExtractUserInfo:
    def test_extract_user_info_basic(self, manager):
        """提取基本用户信息"""
        conversation = [
            {"role": "user", "content": "我是跃盟科技的CEO"},
            {"role": "user", "content": "我们做AI，目前B轮，团队有50人"},
        ]
        result = asyncio.get_event_loop().run_until_complete(
            manager.extract_user_info(conversation)
        )
        assert result is not None
        assert result.get("company") == "跃盟科技"
        assert result.get("industry") == "AI"
        assert result.get("stage") == "B轮"
        assert result.get("team_size") == "50"

    def test_extract_no_info(self, manager):
        """对话中无有效信息时返回 None"""
        conversation = [
            {"role": "user", "content": "你好"},
            {"role": "user", "content": "今天天气怎么样"},
        ]
        result = asyncio.get_event_loop().run_until_complete(
            manager.extract_user_info(conversation)
        )
        assert result is None

    def test_extract_empty_conversation(self, manager):
        """空对话返回 None"""
        result = asyncio.get_event_loop().run_until_complete(
            manager.extract_user_info([])
        )
        assert result is None
