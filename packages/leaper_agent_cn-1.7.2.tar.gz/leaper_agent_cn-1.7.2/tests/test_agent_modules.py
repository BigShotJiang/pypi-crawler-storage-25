"""Agent 辅助模块测试 — session_manager / queue_manager / prompt_builder"""
import pytest
import pytest_asyncio
import asyncio
from unittest.mock import AsyncMock, MagicMock

from src.agent.session_manager import LeaperSessionManager
from src.agent.queue_manager import LeaperQueueManager
from src.agent.prompt_builder import LeaperPromptBuilder


class TestSessionManager:
    def test_create_session(self, tmp_path):
        """创建新 session"""
        sm = LeaperSessionManager(sessions_dir=str(tmp_path))
        session = sm.get_or_create("agent-1", "chat-1")
        assert session["agent_id"] == "agent-1"
        assert session["chat_id"] == "chat-1"
        assert "id" in session

    def test_get_existing_session(self, tmp_path):
        """获取已有 session 返回同一个"""
        sm = LeaperSessionManager(sessions_dir=str(tmp_path))
        s1 = sm.get_or_create("agent-1", "chat-1")
        s2 = sm.get_or_create("agent-1", "chat-1")
        assert s1["id"] == s2["id"]

    def test_list_sessions(self, tmp_path):
        """列出所有 session"""
        sm = LeaperSessionManager(sessions_dir=str(tmp_path))
        sm.get_or_create("agent-1", "chat-1")
        sm.get_or_create("agent-1", "chat-2")
        sessions = sm.list_sessions("agent-1")
        assert len(sessions) >= 2


class TestQueueManager:
    @pytest.mark.asyncio
    async def test_enqueue(self):
        """入队消息"""
        qm = LeaperQueueManager(debounce_ms=10)
        await qm.enqueue("sess-1", "消息一")
        count = qm.pending_count("sess-1")
        assert count >= 1

    @pytest.mark.asyncio
    async def test_drain(self):
        """drain 取出所有消息"""
        qm = LeaperQueueManager(debounce_ms=10)
        await qm.enqueue("sess-1", "消息一")
        await asyncio.sleep(0.05)
        messages = await qm.drain("sess-1")
        assert isinstance(messages, (list, str))

    @pytest.mark.asyncio
    async def test_clear(self):
        """clear 清空队列"""
        qm = LeaperQueueManager(debounce_ms=10)
        await qm.enqueue("sess-1", "消息")
        qm.clear("sess-1")
        assert qm.pending_count("sess-1") == 0


class TestPromptBuilder:
    @pytest.mark.asyncio
    async def test_build_prompt(self, tmp_path):
        """构建 prompt 返回字符串"""
        mock_brain = MagicMock()
        mock_brain.recall = AsyncMock(return_value=[])
        pb = LeaperPromptBuilder(workspace_dir=str(tmp_path), brain=mock_brain)
        prompt = await pb.build(query="你好")
        assert isinstance(prompt, str)
        assert len(prompt) > 0

    @pytest.mark.asyncio
    async def test_build_with_workspace_files(self, tmp_path):
        """workspace 有 SOUL.md 时包含在 prompt 中"""
        (tmp_path / "SOUL.md").write_text("我是测试助手", encoding="utf-8")
        mock_brain = MagicMock()
        mock_brain.recall = AsyncMock(return_value=[])
        pb = LeaperPromptBuilder(workspace_dir=str(tmp_path), brain=mock_brain)
        prompt = await pb.build(query="你好")
        assert "测试助手" in prompt
