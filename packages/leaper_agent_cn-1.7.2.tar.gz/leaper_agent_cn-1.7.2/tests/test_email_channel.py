"""邮件渠道 + 短信渠道 + HA 渠道 测试"""
import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock


# ============ EmailChannel 测试 ============

class TestEmailChannel:
    """邮件渠道测试"""

    def test_init_with_preset(self):
        """使用预设配置初始化"""
        from src.channels.email_channel import EmailChannel
        ch = EmailChannel({"provider": "qq", "email": "test@qq.com", "password": "abc"})
        assert ch._imap_host == "imap.qq.com"
        assert ch._smtp_host == "smtp.qq.com"
        assert ch._smtp_port == 465

    def test_init_163(self):
        """163 邮箱预设"""
        from src.channels.email_channel import EmailChannel
        ch = EmailChannel({"provider": "163", "email": "test@163.com", "password": "abc"})
        assert ch._imap_host == "imap.163.com"

    def test_init_custom(self):
        """自定义配置"""
        from src.channels.email_channel import EmailChannel
        ch = EmailChannel({
            "imap_host": "imap.custom.com",
            "smtp_host": "smtp.custom.com",
            "email": "x@y.com",
            "password": "p",
        })
        assert ch._imap_host == "imap.custom.com"

    def test_decode_header_plain(self):
        """解码普通邮件头"""
        from src.channels.email_channel import _decode_header
        assert _decode_header("Hello") == "Hello"

    def test_decode_header_empty(self):
        """空头"""
        from src.channels.email_channel import _decode_header
        assert _decode_header("") == ""

    def test_parse_email(self):
        """解析原始邮件"""
        from src.channels.email_channel import _parse_email
        raw = (
            b"From: sender@test.com\r\n"
            b"To: recv@test.com\r\n"
            b"Subject: Hello\r\n"
            b"Content-Type: text/plain; charset=utf-8\r\n\r\n"
            b"Body content here"
        )
        msg = _parse_email(raw)
        assert msg.from_addr == "sender@test.com"
        assert msg.subject == "Hello"
        assert "Body content" in msg.body

    @pytest.mark.asyncio
    async def test_start_stop(self):
        """启动和停止"""
        from src.channels.email_channel import EmailChannel
        ch = EmailChannel({"provider": "qq", "email": "t@qq.com", "password": "p"})
        # mock check_inbox to avoid real IMAP
        ch.check_inbox = AsyncMock(return_value=[])
        await ch.start()
        assert ch._running is True
        await ch.stop()
        assert ch._running is False

    def test_preset_wecom(self):
        """企业微信邮箱预设"""
        from src.channels.email_channel import EmailChannel
        ch = EmailChannel({"provider": "wecom", "email": "t@corp.com", "password": "p"})
        assert ch._imap_host == "imap.exmail.qq.com"

    def test_email_message_dataclass(self):
        """EmailMessage 数据类"""
        from src.channels.email_channel import EmailMessage
        msg = EmailMessage(
            message_id="<123>",
            from_addr="a@b.com",
            to_addr="c@d.com",
            subject="Test",
            body="Hello",
        )
        assert msg.subject == "Test"
        assert msg.reply_to == ""


# ============ SMSChannel 测试 ============

class TestSMSChannel:
    """短信渠道测试"""

    def test_init_aliyun(self):
        """阿里云初始化"""
        from src.channels.sms import SMSChannel
        ch = SMSChannel({"provider": "aliyun", "access_key": "k", "access_secret": "s"})
        assert ch._provider == "aliyun"

    def test_init_tencent(self):
        """腾讯云初始化"""
        from src.channels.sms import SMSChannel
        ch = SMSChannel({"provider": "tencent", "sdk_app_id": "1400xxx"})
        assert ch._sdk_app_id == "1400xxx"

    @pytest.mark.asyncio
    async def test_start_stop(self):
        """启动停止"""
        from src.channels.sms import SMSChannel
        ch = SMSChannel({"provider": "aliyun"})
        await ch.start()
        assert ch._running is True
        await ch.stop()
        assert ch._running is False

    @pytest.mark.asyncio
    async def test_webhook_aliyun(self):
        """阿里云 webhook 处理"""
        from src.channels.sms import SMSChannel
        ch = SMSChannel({"provider": "aliyun"})
        handler = AsyncMock(return_value="收到")
        ch.on_message(handler)
        ch.send_sms = AsyncMock()
        result = await ch.handle_webhook({"phone_number": "13800138000", "content": "你好"})
        assert result == "收到"

    @pytest.mark.asyncio
    async def test_webhook_empty(self):
        """空 webhook 数据"""
        from src.channels.sms import SMSChannel
        ch = SMSChannel({"provider": "aliyun"})
        result = await ch.handle_webhook({})
        assert result is None

    @pytest.mark.asyncio
    async def test_send_unknown_provider(self):
        """未知服务商报错"""
        from src.channels.sms import SMSChannel
        ch = SMSChannel({"provider": "unknown"})
        with pytest.raises(ValueError, match="不支持"):
            await ch.send_sms("13800", "test")


# ============ HomeAssistantChannel 测试 ============

class TestHomeAssistantChannel:
    """HA 渠道测试"""

    def test_init(self):
        """初始化"""
        from src.channels.homeassistant import HomeAssistantChannel
        ch = HomeAssistantChannel({"ha_url": "http://ha:8123", "token": "tok"})
        assert ch._ha_url == "http://ha:8123"

    @pytest.mark.asyncio
    async def test_handle_intent(self):
        """处理意图"""
        from src.channels.homeassistant import HomeAssistantChannel
        ch = HomeAssistantChannel({"ha_url": "http://ha:8123", "token": "t"})
        handler = AsyncMock(return_value="灯已打开")
        ch.on_message(handler)
        result = await ch.handle_intent({"text": "开灯", "user_id": "u1"})
        assert result == "灯已打开"

    @pytest.mark.asyncio
    async def test_handle_intent_no_handler(self):
        """无处理器"""
        from src.channels.homeassistant import HomeAssistantChannel
        ch = HomeAssistantChannel({"ha_url": "http://ha:8123", "token": "t"})
        result = await ch.handle_intent({"text": "开灯"})
        assert "未就绪" in result

    @pytest.mark.asyncio
    async def test_start_stop(self):
        """启动停止"""
        from src.channels.homeassistant import HomeAssistantChannel
        ch = HomeAssistantChannel({"ha_url": "http://ha:8123", "token": "t"})
        await ch.start()
        assert ch._running is True
        await ch.stop()
        assert ch._running is False


# ============ create_channel 工厂测试 ============

class TestCreateChannel:
    """渠道工厂函数测试"""

    def test_create_email(self):
        """创建邮件渠道"""
        from src.channels import create_channel
        ch = create_channel("email", {"provider": "qq", "email": "t@qq.com", "password": "p"})
        assert ch.__class__.__name__ == "EmailChannel"

    def test_create_sms(self):
        """创建短信渠道"""
        from src.channels import create_channel
        ch = create_channel("sms", {"provider": "aliyun"})
        assert ch.__class__.__name__ == "SMSChannel"

    def test_create_homeassistant(self):
        """创建 HA 渠道"""
        from src.channels import create_channel
        ch = create_channel("homeassistant", {"ha_url": "http://ha:8123", "token": "t"})
        assert ch.__class__.__name__ == "HomeAssistantChannel"
