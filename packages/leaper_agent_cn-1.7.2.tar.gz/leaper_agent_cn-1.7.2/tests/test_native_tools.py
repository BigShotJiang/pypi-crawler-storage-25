"""Native Tools 测试 — 至少 20 个测试覆盖所有新工具"""
import asyncio
import json
import os
import platform
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


# ──────────────────── Terminal ────────────────────

class TestTerminalTool:
    @pytest.fixture
    def tool(self):
        from src.tools.terminal import TerminalTool
        return TerminalTool()

    @pytest.mark.asyncio
    async def test_normal_command(self, tool):
        """正常命令执行"""
        cmd = "echo hello" if platform.system() != "Windows" else "Write-Output hello"
        result = await tool.execute({"command": cmd})
        assert "hello" in result

    @pytest.mark.asyncio
    async def test_dangerous_command_blocked(self, tool):
        """危险命令拦截"""
        result = await tool.execute({"command": "rm -rf /"})
        assert "拦截" in result or "🚫" in result

    @pytest.mark.asyncio
    async def test_dangerous_shutdown(self, tool):
        """shutdown 命令拦截"""
        result = await tool.execute({"command": "shutdown -s"})
        assert "拦截" in result or "🚫" in result

    @pytest.mark.asyncio
    async def test_timeout(self, tool):
        """超时控制"""
        cmd = "sleep 100" if platform.system() != "Windows" else "Start-Sleep 100"
        result = await tool.execute({"command": cmd, "timeout": 1})
        assert "超时" in result or "⏱️" in result

    @pytest.mark.asyncio
    async def test_output_truncation(self, tool):
        """输出截断"""
        from src.tools.terminal import MAX_OUTPUT_CHARS
        # 生成超长输出
        if platform.system() == "Windows":
            cmd = "1..5000 | ForEach-Object { Write-Output ('A' * 100) }"
        else:
            cmd = "python3 -c \"print('A'*100000)\""
        result = await tool.execute({"command": cmd})
        # 输出应该被截断或正常完成
        assert len(result) <= MAX_OUTPUT_CHARS * 2  # 允许头尾各一半+中间提示


# ──────────────────── File Tool ────────────────────

class TestFileTool:
    @pytest.mark.asyncio
    async def test_read_file(self, tmp_path):
        """读取文件"""
        from src.tools.file_tool import ReadFileTool
        f = tmp_path / "test.txt"
        f.write_text("line1\nline2\nline3", encoding="utf-8")
        tool = ReadFileTool()
        result = await tool.execute({"path": str(f)})
        assert "line1" in result
        assert "line2" in result

    @pytest.mark.asyncio
    async def test_read_file_offset_limit(self, tmp_path):
        """分页读取"""
        from src.tools.file_tool import ReadFileTool
        f = tmp_path / "big.txt"
        f.write_text("\n".join(f"line{i}" for i in range(100)), encoding="utf-8")
        tool = ReadFileTool()
        result = await tool.execute({"path": str(f), "offset": 50, "limit": 5})
        assert "line49" in result
        assert "line54" not in result or "line53" in result

    @pytest.mark.asyncio
    async def test_write_file(self, tmp_path):
        """写入文件"""
        from src.tools.file_tool import WriteFileTool
        f = tmp_path / "sub" / "new.txt"
        tool = WriteFileTool()
        result = await tool.execute({"path": str(f), "content": "hello"})
        assert "写入" in result
        assert f.read_text() == "hello"

    @pytest.mark.asyncio
    async def test_edit_file(self, tmp_path):
        """编辑文件"""
        from src.tools.file_tool import EditFileTool
        f = tmp_path / "edit.txt"
        f.write_text("foo bar baz", encoding="utf-8")
        tool = EditFileTool()
        result = await tool.execute({"path": str(f), "old_text": "bar", "new_text": "QUX"})
        assert "替换" in result
        assert f.read_text() == "foo QUX baz"

    @pytest.mark.asyncio
    async def test_list_dir(self, tmp_path):
        """列出目录"""
        from src.tools.file_tool import ListDirTool
        (tmp_path / "a.txt").write_text("x")
        (tmp_path / "sub").mkdir()
        tool = ListDirTool()
        result = await tool.execute({"path": str(tmp_path)})
        assert "a.txt" in result
        assert "sub" in result

    @pytest.mark.asyncio
    async def test_path_traversal_blocked(self, tmp_path):
        """路径穿越拦截"""
        from src.tools.file_tool import ReadFileTool
        tool = ReadFileTool()
        result = await tool.execute({"path": "/etc/shadow"})
        assert "拦截" in result or "🚫" in result or "不存在" in result

    @pytest.mark.asyncio
    async def test_gbk_file(self, tmp_path):
        """GBK 编码文件"""
        from src.tools.file_tool import ReadFileTool
        f = tmp_path / "gbk.txt"
        f.write_bytes("你好世界".encode("gbk"))
        tool = ReadFileTool()
        result = await tool.execute({"path": str(f)})
        assert "你好世界" in result

    @pytest.mark.asyncio
    async def test_search_files(self, tmp_path):
        """搜索文件内容"""
        from src.tools.file_tool import SearchFilesTool
        (tmp_path / "a.py").write_text("def hello():\n    pass\n")
        (tmp_path / "b.py").write_text("def world():\n    pass\n")
        tool = SearchFilesTool()
        result = await tool.execute({"path": str(tmp_path), "pattern": "hello"})
        assert "a.py" in result
        assert "hello" in result


# ──────────────────── Web Tool ────────────────────

class TestWebTool:
    @pytest.mark.asyncio
    async def test_web_fetch_mock(self):
        """web_fetch mock 测试"""
        from src.tools.web_tool import WebFetchTool
        tool = WebFetchTool()
        html = "<html><body><p>Hello World</p></body></html>"
        with patch("src.tools.web_tool._url_fetch", return_value=html):
            result = await tool.execute({"url": "https://example.com"})
        assert "Hello World" in result

    @pytest.mark.asyncio
    async def test_web_fetch_truncation(self):
        """大页面截断"""
        from src.tools.web_tool import WebFetchTool
        tool = WebFetchTool()
        html = "<p>" + "A" * 10000 + "</p>"
        with patch("src.tools.web_tool._url_fetch", return_value=html):
            result = await tool.execute({"url": "https://example.com", "max_chars": 100})
        assert "截断" in result
        assert len(result) < 200

    @pytest.mark.asyncio
    async def test_web_search_mock(self):
        """web_search mock 测试"""
        from src.tools.web_tool import WebSearchTool
        tool = WebSearchTool()
        fake_html = '''
        <a class="result__a" href="https://example.com">Example Title</a>
        <a class="result__snippet">Example snippet</a>
        '''
        with patch("src.tools.web_tool._url_fetch", return_value=fake_html):
            result = await tool.execute({"query": "test"})
        assert "Example Title" in result


# ──────────────────── Code Exec ────────────────────

class TestCodeExec:
    @pytest.fixture
    def tool(self):
        from src.tools.code_exec import CodeExecTool
        return CodeExecTool()

    @pytest.mark.asyncio
    async def test_normal_execution(self, tool):
        """正常代码执行"""
        result = await tool.execute({"code": "print(1+1)"})
        assert "2" in result

    @pytest.mark.asyncio
    async def test_dangerous_code_blocked(self, tool):
        """危险代码拦截"""
        result = await tool.execute({"code": "import subprocess; subprocess.run(['ls'])"})
        assert "拦截" in result or "🚫" in result

    @pytest.mark.asyncio
    async def test_timeout(self, tool):
        """超时控制"""
        result = await tool.execute({"code": "import time; time.sleep(100)", "timeout": 1})
        assert "超时" in result or "⏱️" in result


# ──────────────────── Todo ────────────────────

class TestTodo:
    @pytest.mark.asyncio
    async def test_add_and_list(self, tmp_path):
        """添加和列出待办"""
        from src.tools.todo import AddTodoTool, ListTodosTool
        add = AddTodoTool()
        lst = ListTodosTool()
        ws = str(tmp_path)

        result = await add.execute({"title": "测试任务", "workspace": ws})
        assert "已添加" in result

        result = await lst.execute({"workspace": ws})
        assert "测试任务" in result

    @pytest.mark.asyncio
    async def test_complete_todo(self, tmp_path):
        """完成待办"""
        from src.tools.todo import AddTodoTool, CompleteTodoTool, ListTodosTool
        ws = str(tmp_path)
        await AddTodoTool().execute({"title": "task1", "workspace": ws})
        result = await CompleteTodoTool().execute({"id": 1, "workspace": ws})
        assert "已完成" in result

    @pytest.mark.asyncio
    async def test_delete_todo(self, tmp_path):
        """删除待办"""
        from src.tools.todo import AddTodoTool, DeleteTodoTool
        ws = str(tmp_path)
        await AddTodoTool().execute({"title": "to delete", "workspace": ws})
        result = await DeleteTodoTool().execute({"id": 1, "workspace": ws})
        assert "已删除" in result


# ──────────────────── Tool Registry ────────────────────

class TestToolRegistry:
    def test_native_overrides_old(self):
        """native tools 覆盖旧版同名工具"""
        from src.tools import get_tools_dict
        from src.tools.file_tool import ReadFileTool as NativeReadFile
        tools = get_tools_dict()
        # read_file 应该是 native 版本
        assert isinstance(tools["read_file"], NativeReadFile)

    def test_all_native_tools_registered(self):
        """所有 native tools 都已注册"""
        from src.tools import get_tools_dict
        tools = get_tools_dict()
        expected = [
            "terminal", "read_file", "write_file", "edit_file", "list_dir",
            "search_files", "web_search", "web_fetch", "code_exec",
            "add_todo", "list_todos", "complete_todo", "delete_todo",
            "feishu_create_doc", "feishu_read_doc", "feishu_update_doc",
        ]
        for name in expected:
            assert name in tools, f"工具 {name} 未注册"

    def test_tool_count(self):
        """工具总数检查"""
        from src.tools import get_tools_dict
        tools = get_tools_dict()
        # 至少 18 个（16 native + calculator + search）
        assert len(tools) >= 18
