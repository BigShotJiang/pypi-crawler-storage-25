"""Plugin 系统测试"""

import asyncio
import os
import tempfile
from pathlib import Path

import pytest

from src.plugins.base import Plugin
from src.plugins.manager import PluginManager, PluginInfo
from src.plugins.builtin.auto_save import AutoSavePlugin
from src.plugins.builtin.keyword_trigger import KeywordTriggerPlugin
from src.plugins.builtin.rate_alert import RateAlertPlugin


# ── Plugin 基类测试 ──

class TestPlugin:
    def test_default_attrs(self):
        p = Plugin()
        assert p.name == "unnamed"
        assert p.version == "0.1.0"
        assert p.enabled is True
        assert p.loaded is False

    @pytest.mark.asyncio
    async def test_lifecycle(self):
        p = Plugin()
        await p.on_load({"key": "val"})
        assert p.loaded is True
        await p.on_unload()
        assert p.loaded is False

    @pytest.mark.asyncio
    async def test_default_hooks(self):
        p = Plugin()
        assert await p.on_message("hi", {}) is None
        assert await p.on_response("resp", {}) == "resp"
        assert await p.on_tool_call("tool", {}) is None
        assert p.register_tools() == []


# ── PluginManager 测试 ──

class TestPluginManager:
    def _write_plugin(self, tmpdir, name, code):
        """写一个测试插件文件"""
        path = Path(tmpdir) / f"{name}.py"
        path.write_text(code, encoding="utf-8")
        return str(path)

    def test_load_and_list(self):
        manager = PluginManager()
        with tempfile.TemporaryDirectory() as td:
            code = '''
from src.plugins.base import Plugin

class TestP(Plugin):
    name = "test_p"
    version = "1.0.0"
    description = "测试插件"
'''
            path = self._write_plugin(td, "test_p", code)
            manager.load_plugin(path)
            plugins = manager.list_plugins()
            assert len(plugins) == 1
            assert plugins[0].name == "test_p"

    def test_unload(self):
        manager = PluginManager()
        with tempfile.TemporaryDirectory() as td:
            code = '''
from src.plugins.base import Plugin
class P(Plugin):
    name = "rm_me"
'''
            path = self._write_plugin(td, "rm_me", code)
            manager.load_plugin(path)
            assert manager.has_plugin("rm_me")
            manager.unload_plugin("rm_me")
            assert not manager.has_plugin("rm_me")

    def test_unload_nonexistent(self):
        manager = PluginManager()
        assert manager.unload_plugin("nope") is False

    def test_discover_plugins(self):
        manager = PluginManager()
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / "plugin_a.py").write_text("x=1", encoding="utf-8")
            (Path(td) / "_hidden.py").write_text("x=1", encoding="utf-8")
            pkg = Path(td) / "plugin_b"
            pkg.mkdir()
            (pkg / "__init__.py").write_text("x=1", encoding="utf-8")

            found = manager.discover_plugins(td)
            names = [os.path.basename(p) for p in found]
            assert "plugin_a.py" in names
            assert "plugin_b" in names
            assert "_hidden.py" not in names

    def test_discover_nonexistent(self):
        manager = PluginManager()
        assert manager.discover_plugins("/nonexistent/dir") == []

    @pytest.mark.asyncio
    async def test_dispatch_message_intercept(self):
        manager = PluginManager()
        with tempfile.TemporaryDirectory() as td:
            code = '''
from src.plugins.base import Plugin
class Interceptor(Plugin):
    name = "interceptor"
    async def on_message(self, message, context):
        if "stop" in message:
            return "已拦截"
        return None
'''
            path = self._write_plugin(td, "interceptor", code)
            await manager.load_plugin_async(path)
            result = await manager.dispatch_message("please stop", {})
            assert result == "已拦截"
            result = await manager.dispatch_message("hello", {})
            assert result is None

    @pytest.mark.asyncio
    async def test_dispatch_response_chain(self):
        manager = PluginManager()
        with tempfile.TemporaryDirectory() as td:
            code = '''
from src.plugins.base import Plugin
class Appender(Plugin):
    name = "appender"
    async def on_response(self, response, context):
        return response + " [modified]"
'''
            path = self._write_plugin(td, "appender", code)
            await manager.load_plugin_async(path)
            result = await manager.dispatch_response("hello", {})
            assert result == "hello [modified]"

    @pytest.mark.asyncio
    async def test_dispatch_tool_call(self):
        manager = PluginManager()
        result = await manager.dispatch_tool_call("any_tool", {"a": 1})
        assert result is None

    def test_collect_tools_empty(self):
        manager = PluginManager()
        assert manager.collect_tools() == []

    def test_load_all(self):
        manager = PluginManager()
        with tempfile.TemporaryDirectory() as td:
            code = '''
from src.plugins.base import Plugin
class A(Plugin):
    name = "a"
'''
            self._write_plugin(td, "a", code)
            count = manager.load_all(td)
            assert count == 1

    def test_load_invalid(self):
        manager = PluginManager()
        with tempfile.TemporaryDirectory() as td:
            # 文件没有 Plugin 子类
            (Path(td) / "bad.py").write_text("x = 1\n", encoding="utf-8")
            with pytest.raises(ValueError):
                manager.load_plugin(str(Path(td) / "bad.py"))

    def test_load_not_found(self):
        manager = PluginManager()
        with pytest.raises(FileNotFoundError):
            manager.load_plugin("/nonexistent.py")


# ── 内置插件测试 ──

class TestAutoSavePlugin:
    @pytest.mark.asyncio
    async def test_save_history(self):
        p = AutoSavePlugin()
        with tempfile.TemporaryDirectory() as td:
            await p.on_load({"save_dir": td})
            await p.on_message("hello", {})
            result = await p.on_response("hi there", {})
            assert result == "hi there"
            assert len(p.history) == 2


class TestKeywordTriggerPlugin:
    @pytest.mark.asyncio
    async def test_trigger(self):
        p = KeywordTriggerPlugin()
        await p.on_load({"triggers": [
            {"keyword": "帮助", "response": "有什么可以帮你？"},
        ]})
        result = await p.on_message("我需要帮助", {})
        assert result == "有什么可以帮你？"
        result = await p.on_message("你好", {})
        assert result is None

    @pytest.mark.asyncio
    async def test_regex_trigger(self):
        p = KeywordTriggerPlugin()
        await p.on_load({"triggers": [
            {"keyword": r"\d{3,}", "response": "检测到数字", "regex": True},
        ]})
        assert await p.on_message("code 12345", {}) == "检测到数字"
        assert await p.on_message("no digits", {}) is None

    def test_add_remove(self):
        p = KeywordTriggerPlugin()
        p.add_trigger("test", "ok")
        assert p.trigger_count == 1
        p.remove_trigger("test")
        assert p.trigger_count == 0


class TestRateAlertPlugin:
    @pytest.mark.asyncio
    async def test_alert(self):
        p = RateAlertPlugin()
        await p.on_load({"max_calls": 2, "window_seconds": 60})
        await p.on_tool_call("t1", {})
        await p.on_tool_call("t2", {})
        assert p.alert_count == 0
        await p.on_tool_call("t3", {})  # 超过阈值
        assert p.alert_count == 1
