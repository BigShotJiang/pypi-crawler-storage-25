"""共享测试 fixtures"""

import pytest
from unittest.mock import AsyncMock, MagicMock
import tempfile
import os


@pytest.fixture
def mock_provider():
    """模拟 LLM Provider"""
    provider = AsyncMock()
    provider.chat = AsyncMock(return_value={"content": "你好！", "tool_calls": None})
    return provider


@pytest.fixture
def mock_brain():
    """模拟 Brain 记忆引擎"""
    brain = AsyncMock()
    brain.recall = AsyncMock(return_value=[])
    brain.extract = AsyncMock(return_value=None)
    return brain


@pytest.fixture
def tmp_workspace(tmp_path):
    """临时工作空间目录"""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    return workspace
