"""定时调度器测试"""
import asyncio
import json
import sqlite3
import tempfile
import os
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock

import pytest

from src.scheduler.engine import (
    Scheduler, Job, parse_natural_language, calculate_next_run,
    cron_matches, parse_cron,
)


class TestParseNaturalLanguage:
    """test_parse_natural_language"""
    
    def test_every_day_morning(self):
        assert parse_natural_language("每天早上8点") == "0 8 * * *"
    
    def test_every_hour(self):
        assert parse_natural_language("每小时") == "0 * * * *"
    
    def test_every_monday(self):
        assert parse_natural_language("每周一上午10点") == "0 10 * * 1"
    
    def test_monthly(self):
        assert parse_natural_language("每月1号") == "0 9 1 * *"
    
    def test_every_n_minutes(self):
        assert parse_natural_language("每5分钟") == "*/5 * * * *"
    
    def test_workday_afternoon(self):
        assert parse_natural_language("工作日下午6点") == "0 18 * * 1-5"
    
    def test_unknown(self):
        assert parse_natural_language("随便什么时候") is None


class TestAddRemoveJob:
    """test_add_remove_job"""
    
    def test_add_job(self):
        s = Scheduler()
        job = s.add_job("日报", "0 8 * * *", "ceo-coach", "发送日报")
        assert job.name == "日报"
        assert job.cron_expr == "0 8 * * *"
        assert len(s.list_jobs()) == 1
    
    def test_remove_job(self):
        s = Scheduler()
        job = s.add_job("日报", "0 8 * * *", "ceo-coach", "发送日报")
        assert s.remove_job(job.id)
        assert len(s.list_jobs()) == 0
    
    def test_remove_nonexistent(self):
        s = Scheduler()
        assert not s.remove_job("nonexistent")
    
    def test_invalid_cron(self):
        s = Scheduler()
        with pytest.raises(ValueError):
            s.add_job("坏任务", "invalid", "agent", "payload")


class TestCalculateNextRun:
    """test_calculate_next_run"""
    
    def test_every_hour(self):
        after = datetime(2026, 5, 4, 10, 30, 0)
        nxt = calculate_next_run("0 * * * *", after)
        assert nxt == datetime(2026, 5, 4, 11, 0, 0)
    
    def test_daily_8am(self):
        after = datetime(2026, 5, 4, 9, 0, 0)
        nxt = calculate_next_run("0 8 * * *", after)
        # 已过 8 点，下次是明天 8 点
        assert nxt == datetime(2026, 5, 5, 8, 0, 0)
    
    def test_before_target(self):
        after = datetime(2026, 5, 4, 7, 0, 0)
        nxt = calculate_next_run("0 8 * * *", after)
        assert nxt == datetime(2026, 5, 4, 8, 0, 0)


class TestCronExpressionMatching:
    """test_cron_expression_matching"""
    
    def test_match(self):
        dt = datetime(2026, 5, 4, 8, 0, 0)  # 周一
        assert cron_matches("0 8 * * *", dt)
    
    def test_no_match_minute(self):
        dt = datetime(2026, 5, 4, 8, 5, 0)
        assert not cron_matches("0 8 * * *", dt)
    
    def test_weekday_match(self):
        # 2026-05-04 is Monday (weekday=0 in Python, dow=1 in cron)
        dt = datetime(2026, 5, 4, 10, 0, 0)
        assert cron_matches("0 10 * * 1", dt)
    
    def test_every_5_minutes(self):
        dt = datetime(2026, 5, 4, 10, 15, 0)
        assert cron_matches("*/5 * * * *", dt)
        dt2 = datetime(2026, 5, 4, 10, 13, 0)
        assert not cron_matches("*/5 * * * *", dt2)


class TestJobPersistence:
    """test_job_persistence"""
    
    def test_persist_and_load(self):
        # 创建临时数据库
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name
        try:
            brain = MagicMock()
            brain.db_path = db_path
            
            s1 = Scheduler(brain=brain)
            s1.add_job("日报", "0 8 * * *", "ceo-coach", "发日报")
            s1.add_job("周报", "0 9 * * 1", "ceo-coach", "发周报")
            
            # 新 scheduler 加载
            s2 = Scheduler(brain=brain)
            s2._load_jobs()
            assert len(s2.list_jobs()) == 2
            assert s2.list_jobs()[0].name == "日报"
        finally:
            os.unlink(db_path)


class TestSchedulerStartStop:
    """test_scheduler_start_stop"""
    
    @pytest.mark.asyncio
    async def test_start_stop(self):
        s = Scheduler()
        await s.start()
        assert s._running
        await s.stop()
        assert not s._running
    
    @pytest.mark.asyncio
    async def test_double_stop(self):
        s = Scheduler()
        await s.start()
        await s.stop()
        await s.stop()  # 不应报错
        assert not s._running
