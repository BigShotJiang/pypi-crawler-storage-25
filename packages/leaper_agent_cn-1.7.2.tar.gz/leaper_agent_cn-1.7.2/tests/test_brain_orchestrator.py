"""LeaperOrchestrator 编排器测试"""
import pytest
import pytest_asyncio
import tempfile
import os
from unittest.mock import AsyncMock, patch, MagicMock

from src.brain.orchestrator import LeaperOrchestrator


@pytest_asyncio.fixture
async def orchestrator(tmp_path):
    db_path = str(tmp_path / "test.db")
    workspace = str(tmp_path / "workspace")
    orch = LeaperOrchestrator(agent_id="test", db_path=db_path, workspace_dir=workspace)
    await orch.initialize()
    yield orch
    await orch.shutdown()


class TestInitialize:
    @pytest.mark.asyncio
    async def test_initialize(self, tmp_path):
        """所有子系统初始化"""
        db_path = str(tmp_path / "test.db")
        workspace = str(tmp_path / "ws")
        orch = LeaperOrchestrator(agent_id="test", db_path=db_path, workspace_dir=workspace)
        await orch.initialize()
        assert orch._initialized
        assert orch.brain is not None
        assert orch.evolution is not None
        assert orch.profile is not None
        assert orch.meta is not None
        assert orch.prompt_builder is not None
        assert orch.queue is not None
        assert orch.session_manager is not None
        await orch.shutdown()

    @pytest.mark.asyncio
    async def test_double_initialize(self, tmp_path):
        """重复初始化不报错"""
        db_path = str(tmp_path / "test.db")
        orch = LeaperOrchestrator(agent_id="t", db_path=db_path, workspace_dir=str(tmp_path))
        await orch.initialize()
        await orch.initialize()
        assert orch._initialized
        await orch.shutdown()


class TestHandleMessage:
    @pytest.mark.asyncio
    async def test_handle_message(self, orchestrator: LeaperOrchestrator):
        """handle_message 返回 prompt 字符串"""
        result = await orchestrator.handle_message("sess-1", "你好")
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.asyncio
    async def test_not_initialized_raises(self, tmp_path):
        """未初始化时调用报 RuntimeError"""
        orch = LeaperOrchestrator(agent_id="t", db_path=str(tmp_path / "x.db"), workspace_dir=str(tmp_path))
        with pytest.raises(RuntimeError):
            await orch.handle_message("s", "msg")


class TestOnResponse:
    @pytest.mark.asyncio
    async def test_on_response(self, orchestrator: LeaperOrchestrator):
        """on_response 存消息并提取知识"""
        await orchestrator.on_response("sess-1", "用户消息", "助手回复内容较长以通过长度检查确保有效提取")
        # 验证消息已存储
        async with orchestrator.brain.db.execute(
            "SELECT COUNT(*) FROM messages WHERE session_id = ?", ("sess-1",)
        ) as cur:
            count = (await cur.fetchone())[0]
        assert count == 2


class TestShutdown:
    @pytest.mark.asyncio
    async def test_shutdown(self, tmp_path):
        """优雅关闭所有子系统"""
        db_path = str(tmp_path / "test.db")
        orch = LeaperOrchestrator(agent_id="t", db_path=db_path, workspace_dir=str(tmp_path))
        await orch.initialize()
        await orch.shutdown()
        assert not orch._initialized
        assert orch.brain is None
        assert orch.evolution is None
