"""测试 MultiAgentManager - 多 Agent 管理器"""
import asyncio
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, patch, MagicMock

import pytest
import yaml


@pytest.fixture
def multi_agent_dir(tmp_path):
    """创建模拟的多 Agent 目录结构"""
    config_dir = tmp_path / ".leaper-cn"
    config_dir.mkdir()

    # 全局配置
    global_config = {
        "provider": {
            "name": "deepseek",
            "api_key": "test-key",
            "model": "deepseek-v4-flash",
            "base_url": "https://api.deepseek.com/v1",
        },
        "brain": {"enabled": False},
        "multi_agent": {
            "default": "my-cto",
            "channel_bindings": {
                "feishu": "my-cpo",
                "dingtalk": "my-cto",
            },
        },
    }
    with open(config_dir / "leaper.yaml", "w") as f:
        yaml.dump(global_config, f)

    # 创建 workspaces
    ws_dir = config_dir / "workspaces"
    ws_dir.mkdir()

    # Agent 1: my-cto
    cto_dir = ws_dir / "my-cto"
    cto_dir.mkdir()
    with open(cto_dir / "agent.yaml", "w") as f:
        yaml.dump({"name": "my-cto", "role": "cto"}, f)
    (cto_dir / "SOUL.md").write_text("你是 CTO 技术顾问", encoding="utf-8")

    # Agent 2: my-cpo
    cpo_dir = ws_dir / "my-cpo"
    cpo_dir.mkdir()
    with open(cpo_dir / "agent.yaml", "w") as f:
        yaml.dump({"name": "my-cpo", "role": "cpo"}, f)
    (cpo_dir / "SOUL.md").write_text("你是 CPO 产品顾问", encoding="utf-8")

    # Agent 3: 没有 agent.yaml（用目录名）
    default_dir = ws_dir / "default"
    default_dir.mkdir()

    return config_dir


class TestMultiAgentManager:
    """多 Agent 管理器测试"""

    def test_list_agents(self, multi_agent_dir):
        """列出 workspaces 下的所有 agents"""
        from src.agent.multi import MultiAgentManager

        manager = MultiAgentManager(config_dir=str(multi_agent_dir))
        agents = manager.list_agents()

        assert len(agents) == 3
        names = {a["name"] for a in agents}
        assert "my-cto" in names
        assert "my-cpo" in names
        assert "default" in names

        # 验证角色
        cto = next(a for a in agents if a["name"] == "my-cto")
        assert cto["role"] == "cto"

    def test_get_agent(self, multi_agent_dir):
        """获取并初始化 agent（懒加载）"""
        from src.agent.multi import MultiAgentManager

        manager = MultiAgentManager(config_dir=str(multi_agent_dir))

        # 还没创建实例
        assert "my-cto" not in manager._agents

        # mock provider 创建以避免真实 API 调用
        with patch.object(manager, "_create_provider") as mock_provider:
            mock_provider.return_value = MagicMock()
            agent = manager.get_agent("my-cto")

        # 已缓存
        assert "my-cto" in manager._agents
        assert agent is manager._agents["my-cto"]

    def test_get_agent_not_found(self, multi_agent_dir):
        """获取不存在的 agent 应抛出 KeyError"""
        from src.agent.multi import MultiAgentManager

        manager = MultiAgentManager(config_dir=str(multi_agent_dir))
        with pytest.raises(KeyError, match="not-exist"):
            manager.get_agent("not-exist")

    @pytest.mark.asyncio
    async def test_route_message(self, multi_agent_dir):
        """路由消息到正确的 agent"""
        from src.agent.multi import MultiAgentManager

        manager = MultiAgentManager(config_dir=str(multi_agent_dir))

        # Mock get_agent 返回带 chat 方法的 mock
        mock_loop = MagicMock()
        mock_loop.chat = AsyncMock(return_value="来自 CTO 的回复")

        with patch.object(manager, "get_agent", return_value=mock_loop):
            reply = await manager.route_message("你好", agent_name="my-cto")

        assert reply == "来自 CTO 的回复"
        mock_loop.chat.assert_called_once_with("你好")

    @pytest.mark.asyncio
    async def test_route_message_default(self, multi_agent_dir):
        """未指定 agent 时路由到默认 agent"""
        from src.agent.multi import MultiAgentManager

        manager = MultiAgentManager(config_dir=str(multi_agent_dir))

        mock_loop = MagicMock()
        mock_loop.chat = AsyncMock(return_value="默认回复")

        with patch.object(manager, "get_agent", return_value=mock_loop) as mock_get:
            reply = await manager.route_message("你好")

        # 应该路由到默认 agent "my-cto"
        mock_get.assert_called_once_with("my-cto")
        assert reply == "默认回复"

    def test_default_agent(self, multi_agent_dir):
        """默认 agent 逻辑"""
        from src.agent.multi import MultiAgentManager

        manager = MultiAgentManager(config_dir=str(multi_agent_dir))

        # 配置中指定了 multi_agent.default = "my-cto"
        assert manager.get_default_agent() == "my-cto"

    def test_default_agent_fallback(self, tmp_path):
        """无 multi_agent 配置时的 fallback 逻辑"""
        from src.agent.multi import MultiAgentManager

        config_dir = tmp_path / ".leaper-cn"
        config_dir.mkdir()
        (config_dir / "leaper.yaml").write_text("{}")
        ws_dir = config_dir / "workspaces"
        ws_dir.mkdir()
        (ws_dir / "only-agent").mkdir()

        manager = MultiAgentManager(config_dir=str(config_dir))
        # 应返回第一个（也是唯一一个）
        assert manager.get_default_agent() == "only-agent"

    def test_channel_agent_binding(self, multi_agent_dir):
        """渠道绑定 Agent"""
        from src.agent.multi import MultiAgentManager

        manager = MultiAgentManager(config_dir=str(multi_agent_dir))

        assert manager.get_channel_agent("feishu") == "my-cpo"
        assert manager.get_channel_agent("dingtalk") == "my-cto"
        assert manager.get_channel_agent("unknown") is None
