"""Seed Loader + ConfigManager 测试"""
import os
import tempfile
import pytest
from pathlib import Path

from src.agent.seed_loader import SeedLoader, SEED_FILES, REQUIRED_FILES
from src.config import ConfigManager, LeaperConfig


class TestSeedLoader:
    def test_load_nonexistent_workspace(self):
        loader = SeedLoader("/nonexistent/path")
        seeds = loader.load_all()
        # 所有文件都应该是 None
        assert seeds.get("soul") is None
        # 但 os_info 和 runtime_info 存在
        assert seeds["os_info"] is not None
        assert seeds["runtime_info"] is not None

    def test_load_file_exists(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "SOUL.md").write_text("I am soul", encoding="utf-8")
            loader = SeedLoader(d)
            assert loader.load_file("SOUL.md") == "I am soul"

    def test_load_file_missing(self):
        with tempfile.TemporaryDirectory() as d:
            loader = SeedLoader(d)
            assert loader.load_file("NONEXIST.md") is None

    def test_load_file_empty(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "SOUL.md").write_text("", encoding="utf-8")
            loader = SeedLoader(d)
            assert loader.load_file("SOUL.md") is None

    def test_get_os_info(self):
        loader = SeedLoader(".")
        info = loader.get_os_info()
        assert "OS:" in info

    def test_get_runtime_info(self):
        loader = SeedLoader(".")
        info = loader.get_runtime_info()
        assert "Python:" in info

    def test_validate_workspace_missing_dir(self):
        loader = SeedLoader("/nonexistent")
        issues = loader.validate_workspace()
        assert len(issues) > 0

    def test_validate_workspace_ok(self):
        with tempfile.TemporaryDirectory() as d:
            for f in REQUIRED_FILES:
                Path(d, f).write_text("content", encoding="utf-8")
            loader = SeedLoader(d)
            assert loader.validate_workspace() == []

    def test_build_system_context(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "SOUL.md").write_text("Be helpful", encoding="utf-8")
            loader = SeedLoader(d)
            ctx = loader.build_system_context()
            assert "Be helpful" in ctx
            assert "SOUL" in ctx


class TestConfigManager:
    def test_init_default(self):
        mgr = ConfigManager()
        assert mgr.path is not None

    def test_get_set(self):
        mgr = ConfigManager()
        mgr.config = LeaperConfig()
        mgr.set("provider.model", "qwen-max")
        assert mgr.get("provider.model") == "qwen-max"

    def test_get_default(self):
        mgr = ConfigManager()
        mgr.config = LeaperConfig()
        assert mgr.get("nonexistent.key", "fallback") == "fallback"

    def test_validate(self):
        mgr = ConfigManager()
        mgr.config = LeaperConfig()
        issues = mgr.validate()
        assert isinstance(issues, list)

    def test_get_masked(self):
        mgr = ConfigManager()
        mgr.config = LeaperConfig()
        mgr.config.provider.api_key = "sk-1234567890abcdef"
        masked = mgr.get_masked()
        assert "1234567890" not in str(masked)

    def test_get_provider_config(self):
        mgr = ConfigManager()
        mgr.config = LeaperConfig()
        pc = mgr.get_provider_config()
        assert "name" in pc
        assert "model" in pc

    def test_get_brain_config(self):
        mgr = ConfigManager()
        mgr.config = LeaperConfig()
        bc = mgr.get_brain_config()
        assert "enabled" in bc

    def test_export_env(self):
        mgr = ConfigManager()
        mgr.config = LeaperConfig()
        env = mgr.export_env()
        assert any(k.startswith("LEAPER_") for k in env)

    def test_save_load(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "leaper.yaml")
            mgr = ConfigManager(config_path=path)
            mgr.config = LeaperConfig()
            mgr.config.provider.model = "test-model"
            mgr.save()
            # 重新加载
            mgr2 = ConfigManager(config_path=path)
            mgr2.load()
            assert mgr2.get("provider.model") == "test-model"
