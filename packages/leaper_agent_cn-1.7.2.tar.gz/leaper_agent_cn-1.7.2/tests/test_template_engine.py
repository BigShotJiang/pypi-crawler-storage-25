"""TemplateEngine + TemplateUpdater + WorkspaceManager 测试"""

import json
import os
import tempfile
from pathlib import Path

import pytest

from src.templates.engine import TemplateEngine
from src.templates.updater import TemplateUpdater, UpdateInfo
from src.workspace import WorkspaceManager, WorkspaceInfo


# ── TemplateEngine 测试 ──

class TestTemplateEngine:
    def setup_method(self):
        self.engine = TemplateEngine()

    def test_simple_variable(self):
        result = self.engine.render("Hello {{name}}!", {"name": "World"})
        assert result == "Hello World!"

    def test_missing_variable(self):
        result = self.engine.render("{{missing}}", {})
        assert result == ""

    def test_filter_upper(self):
        result = self.engine.render("{{text|upper}}", {"text": "hello"})
        assert result == "HELLO"

    def test_filter_lower(self):
        result = self.engine.render("{{text|lower}}", {"text": "HELLO"})
        assert result == "hello"

    def test_filter_truncate(self):
        result = self.engine.render("{{text|truncate(5)}}", {"text": "hello world"})
        assert result == "hello..."

    def test_filter_default(self):
        result = self.engine.render('{{x|default("默认值")}}', {})
        assert result == "默认值"

    def test_filter_default_with_value(self):
        result = self.engine.render('{{x|default("默认值")}}', {"x": "实际值"})
        assert result == "实际值"

    def test_if_true(self):
        result = self.engine.render("{% if show %}visible{% endif %}", {"show": True})
        assert result == "visible"

    def test_if_false(self):
        result = self.engine.render("{% if show %}visible{% endif %}", {"show": False})
        assert result == ""

    def test_if_not(self):
        result = self.engine.render("{% if not hidden %}ok{% endif %}", {"hidden": False})
        assert result == "ok"

    def test_for_loop(self):
        result = self.engine.render(
            "{% for item in items %}{{item}} {% endfor %}",
            {"items": ["a", "b", "c"]}
        )
        assert result == "a b c "

    def test_for_loop_empty(self):
        result = self.engine.render(
            "{% for x in empty %}{{x}}{% endfor %}",
            {"empty": []}
        )
        assert result == ""

    def test_discover_variables(self):
        tmpl = "Hello {{name}}, {% if active %}{{role}}{% endif %} {% for x in items %}{{x}}{% endfor %}"
        vars = self.engine.discover_variables(tmpl)
        assert "name" in vars
        assert "items" in vars

    def test_validate_ok(self):
        issues = self.engine.validate_template("Hello {{name}}!")
        assert issues == []

    def test_validate_mismatched_if(self):
        issues = self.engine.validate_template("{% if x %}oops")
        assert any("if/endif" in i for i in issues)

    def test_validate_mismatched_for(self):
        issues = self.engine.validate_template("{% for x in y %}oops")
        assert any("for/endfor" in i for i in issues)

    def test_render_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
            f.write("Hi {{name}}")
            path = f.name
        try:
            result = self.engine.render_file(path, {"name": "Test"})
            assert result == "Hi Test"
        finally:
            os.unlink(path)

    def test_render_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            self.engine.render_file("/nonexistent.txt", {})

    def test_filter_chain(self):
        result = self.engine.render("{{text|strip|upper}}", {"text": "  hello  "})
        assert result == "HELLO"

    def test_custom_filter(self):
        self.engine.register_filter("reverse", lambda s: str(s)[::-1])
        result = self.engine.render("{{text|reverse}}", {"text": "abc"})
        assert result == "cba"


# ── TemplateUpdater 测试 ──

class TestTemplateUpdater:
    @pytest.mark.asyncio
    async def test_check_updates(self):
        with tempfile.TemporaryDirectory() as td:
            templates_dir = os.path.join(td, "installed")
            registry_dir = os.path.join(td, "registry")
            os.makedirs(templates_dir)
            os.makedirs(registry_dir)

            # 写注册信息
            registry = {"my-template": {"version": "1.1.0", "changelog": "新功能"}}
            Path(registry_dir, "registry.json").write_text(json.dumps(registry), encoding="utf-8")

            updater = TemplateUpdater(templates_dir, registry_dir)
            updater.set_installed_version("my-template", "1.0.0")

            updates = await updater.check_updates()
            assert len(updates) == 1
            assert updates[0].has_update is True
            assert updates[0].latest_version == "1.1.0"

    @pytest.mark.asyncio
    async def test_update_template(self):
        with tempfile.TemporaryDirectory() as td:
            templates_dir = os.path.join(td, "installed")
            registry_dir = os.path.join(td, "registry")
            os.makedirs(templates_dir)
            os.makedirs(registry_dir)

            registry = {"tmpl": {"version": "2.0.0"}}
            Path(registry_dir, "registry.json").write_text(json.dumps(registry), encoding="utf-8")

            updater = TemplateUpdater(templates_dir, registry_dir)
            updater.set_installed_version("tmpl", "1.0.0")

            ok = await updater.update_template("tmpl")
            assert ok is True
            assert updater.get_installed_version("tmpl") == "2.0.0"

    @pytest.mark.asyncio
    async def test_update_already_latest(self):
        with tempfile.TemporaryDirectory() as td:
            templates_dir = os.path.join(td, "installed")
            registry_dir = os.path.join(td, "registry")
            os.makedirs(templates_dir)
            os.makedirs(registry_dir)

            registry = {"tmpl": {"version": "1.0.0"}}
            Path(registry_dir, "registry.json").write_text(json.dumps(registry), encoding="utf-8")

            updater = TemplateUpdater(templates_dir, registry_dir)
            updater.set_installed_version("tmpl", "1.0.0")

            ok = await updater.update_template("tmpl")
            assert ok is False

    def test_version_compare(self):
        assert TemplateUpdater._version_gt("1.1.0", "1.0.0") is True
        assert TemplateUpdater._version_gt("1.0.0", "1.0.0") is False
        assert TemplateUpdater._version_gt("0.9.0", "1.0.0") is False


# ── WorkspaceManager 测试 ──

class TestWorkspaceManager:
    def test_create_and_validate(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            path = mgr.create("test-ws")
            issues = mgr.validate(path)
            assert issues == []

    def test_create_with_template(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            path = mgr.create("cto-ws", template="cto")
            soul = Path(path) / "SOUL.md"
            assert soul.exists()
            assert "CTO" in soul.read_text(encoding="utf-8")

    def test_create_duplicate(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            mgr.create("dup")
            with pytest.raises(FileExistsError):
                mgr.create("dup")

    def test_list_workspaces(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            mgr.create("ws1")
            mgr.create("ws2")
            wss = mgr.list_workspaces()
            names = [w.name for w in wss]
            assert "ws1" in names
            assert "ws2" in names

    def test_delete(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            path = mgr.create("del-me")
            mgr.delete(path)
            assert not Path(path).exists()

    def test_get_info(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            path = mgr.create("info-ws")
            info = mgr.get_info(path)
            assert info.name == "info-ws"
            assert info.valid is True
            assert info.files > 0

    def test_validate_missing_files(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            # 创建空目录
            ws = Path(td) / "empty"
            ws.mkdir()
            issues = mgr.validate(str(ws))
            assert len(issues) > 0

    def test_migrate(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            path = mgr.create("migrate-ws")
            logs = mgr.migrate(path, "1.0.0", "2.0.0")
            assert any("2.0.0" in log for log in logs)
            info = mgr.get_info(path)
            assert info.version == "2.0.0"

    def test_init_files_default(self):
        with tempfile.TemporaryDirectory() as td:
            mgr = WorkspaceManager(td)
            ws = Path(td) / "init-test"
            ws.mkdir()
            mgr.init_files(str(ws))
            assert (ws / "SOUL.md").exists()
            assert (ws / "MEMORY.md").exists()
