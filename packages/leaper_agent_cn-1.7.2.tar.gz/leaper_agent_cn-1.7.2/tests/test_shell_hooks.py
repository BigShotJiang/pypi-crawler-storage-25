"""Shell Hooks 测试"""
import asyncio

import pytest

from src.agent.shell_hooks import (
    ShellHooks, HookResult, CommandRecord,
    dangerous_command_guard, command_logger, error_analyzer,
    truncate_output, create_default_hooks, get_command_log,
)


def test_hook_result_defaults():
    r = HookResult()
    assert r.allow is True
    assert r.modified_command is None


def test_dangerous_command_guard_rm_rf():
    r = dangerous_command_guard("rm -rf /", "/home")
    assert r.allow is False
    assert "危险" in r.warning


def test_dangerous_command_guard_safe():
    r = dangerous_command_guard("ls -la", "/home")
    assert r.allow is True


def test_dangerous_command_guard_format():
    r = dangerous_command_guard("format C:", ".")
    assert r.allow is False


def test_command_logger():
    r = command_logger("echo hello", "/tmp")
    assert r.allow is True
    log = get_command_log()
    assert any(rec.command == "echo hello" for rec in log)


def test_truncate_output_short():
    assert truncate_output("hello") == "hello"


def test_truncate_output_long_lines():
    text = "\n".join(f"line {i}" for i in range(300))
    result = truncate_output(text, max_lines=100)
    assert "省略" in result


def test_truncate_output_long_chars():
    text = "x" * 60000
    result = truncate_output(text, max_chars=50000)
    assert "截断" in result


@pytest.mark.asyncio
async def test_shell_hooks_pre():
    hooks = ShellHooks()
    hooks.add_pre_hook(lambda cmd, cwd: HookResult(allow=True))
    r = await hooks.run_pre_hooks("ls", "/tmp")
    assert r.allow is True


@pytest.mark.asyncio
async def test_shell_hooks_pre_block():
    hooks = ShellHooks()
    hooks.add_pre_hook(lambda cmd, cwd: HookResult(allow=False, warning="blocked"))
    r = await hooks.run_pre_hooks("rm -rf /", "/")
    assert r.allow is False


@pytest.mark.asyncio
async def test_shell_hooks_pre_modify():
    def modifier(cmd, cwd):
        return HookResult(allow=True, modified_command=cmd + " --safe")
    hooks = ShellHooks()
    hooks.add_pre_hook(modifier)
    r = await hooks.run_pre_hooks("deploy", "/app")
    assert r.modified_command == "deploy --safe"


@pytest.mark.asyncio
async def test_shell_hooks_post():
    called = []
    hooks = ShellHooks()
    hooks.add_post_hook(lambda cmd, code, out: called.append(cmd))
    await hooks.run_post_hooks("echo hi", 0, "hi")
    assert "echo hi" in called


@pytest.mark.asyncio
async def test_shell_hooks_record():
    hooks = ShellHooks()
    hooks.record(CommandRecord(command="test", cwd="/"))
    assert len(hooks.history) == 1


@pytest.mark.asyncio
async def test_default_hooks():
    hooks = create_default_hooks()
    r = await hooks.run_pre_hooks("rm -rf /", "/")
    assert r.allow is False


def test_error_analyzer_no_crash():
    # 应该不抛异常
    error_analyzer("cmd", 1, "command not found")
    error_analyzer("cmd", 0, "success")
