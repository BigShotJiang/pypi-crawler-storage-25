"""Tool Call Parser 测试"""
import json
import pytest
from src.tools.parsers.base import ToolCall, ToolCallParser
from src.tools.parsers.qwen import QwenToolCallParser, Qwen3ToolCallParser
from src.tools.parsers.deepseek import DeepSeekToolCallParser
from src.tools.parsers.zhipu import ZhipuToolCallParser
from src.tools.parsers.moonshot import MoonshotToolCallParser
from src.tools.parsers.generic import GenericToolCallParser
from src.tools.parsers import get_parser, list_parsers


# ── Qwen 2.5 ──────────────────────────────────────────

class TestQwenParser:
    def setup_method(self):
        self.parser = QwenToolCallParser()

    def test_single_call(self):
        text = '前缀文字<tool_call>{"name": "search", "arguments": {"query": "天气"}}</tool_call>'
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "search"
        assert calls[0].arguments == {"query": "天气"}

    def test_multiple_calls(self):
        text = '<tool_call>{"name": "a", "arguments": {}}</tool_call><tool_call>{"name": "b", "arguments": {"x": 1}}</tool_call>'
        calls = self.parser.parse_response(text)
        assert len(calls) == 2

    def test_no_tool_call(self):
        assert self.parser.parse_response("普通文本") == []

    def test_invalid_json(self):
        text = "<tool_call>not json</tool_call>"
        assert self.parser.parse_response(text) == []

    def test_parse_content_and_calls(self):
        text = '先说话<tool_call>{"name": "f", "arguments": {}}</tool_call>'
        content, calls = self.parser.parse(text)
        assert content == "先说话"
        assert calls is not None and len(calls) == 1

    def test_stop_tokens(self):
        assert "</tool_call>" in self.parser.get_stop_tokens()

    def test_format_tool_result(self):
        result = self.parser.format_tool_result("test", '"ok"')
        assert "test" in result
        assert "ok" in result


# ── Qwen3 Coder ──────────────────────────────────────

class TestQwen3Parser:
    def setup_method(self):
        self.parser = Qwen3ToolCallParser()

    def test_xml_format(self):
        text = """<tool_call>
<function=search>
<parameter=query>AI 新闻</parameter>
<parameter=max_results>5</parameter>
</function>
</tool_call>"""
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "search"
        assert calls[0].arguments["query"] == "AI 新闻"
        assert calls[0].arguments["max_results"] == 5

    def test_no_function_tag(self):
        assert self.parser.parse_response("普通文本") == []

    def test_null_value(self):
        text = "<tool_call><function=f><parameter=x>null</parameter></function></tool_call>"
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].arguments["x"] is None


# ── DeepSeek ──────────────────────────────────────────

class TestDeepSeekParser:
    def setup_method(self):
        self.parser = DeepSeekToolCallParser()

    def test_v3_format(self):
        text = """一些思考
<｜tool▁calls▁begin｜>
<｜tool▁call▁begin｜>function<｜tool▁sep｜>search
```json
{"query": "test"}
```
<｜tool▁call▁end｜>
<｜tool▁calls▁end｜>"""
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "search"
        assert calls[0].arguments == {"query": "test"}

    def test_with_think_tag(self):
        text = """<think>我在想</think>
<｜tool▁calls▁begin｜>
<｜tool▁call▁begin｜>function<｜tool▁sep｜>calc
```json
{"expr": "1+1"}
```
<｜tool▁call▁end｜>
<｜tool▁calls▁end｜>"""
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "calc"

    def test_no_token(self):
        assert self.parser.parse_response("普通回复") == []

    def test_stop_tokens(self):
        tokens = self.parser.get_stop_tokens()
        assert len(tokens) >= 1

    def test_format_result(self):
        r = self.parser.format_tool_result("f", "ok")
        assert "tool▁output" in r


# ── 智谱 GLM ──────────────────────────────────────────

class TestZhipuParser:
    def setup_method(self):
        self.parser = ZhipuToolCallParser()

    def test_glm45_format(self):
        text = """<tool_call>search
<arg_key>query</arg_key><arg_value>AI</arg_value>
<arg_key>count</arg_key><arg_value>3</arg_value>
</tool_call>"""
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "search"
        assert calls[0].arguments["query"] == "AI"
        assert calls[0].arguments["count"] == 3

    def test_glm47_json_format(self):
        text = '<tool_call>{"name": "search", "arguments": {"q": "test"}}</tool_call>'
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "search"

    def test_no_call(self):
        assert self.parser.parse_response("无工具调用") == []


# ── Moonshot ──────────────────────────────────────────

class TestMoonshotParser:
    def setup_method(self):
        self.parser = MoonshotToolCallParser()

    def test_basic(self):
        text = '<tool_call>{"name": "web", "arguments": {"url": "https://x.com"}}</tool_call>'
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "web"

    def test_no_call(self):
        assert self.parser.parse_response("hello") == []


# ── Generic ──────────────────────────────────────────

class TestGenericParser:
    def setup_method(self):
        self.parser = GenericToolCallParser()

    def test_code_block(self):
        text = '分析一下\n```json\n{"name": "search", "arguments": {"q": "AI"}}\n```'
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "search"

    def test_inline_json(self):
        text = '调用 {"name": "calc", "arguments": {"expr": "1+1"}} 来计算'
        calls = self.parser.parse_response(text)
        assert len(calls) == 1
        assert calls[0].name == "calc"

    def test_tag_format(self):
        text = '<tool_call>{"name": "f", "arguments": {}}</tool_call>'
        calls = self.parser.parse_response(text)
        assert len(calls) == 1

    def test_no_match(self):
        assert self.parser.parse_response("纯文本") == []

    def test_parse_with_content(self):
        text = '思考\n```json\n{"name": "f", "arguments": {}}\n```'
        content, calls = self.parser.parse(text)
        assert calls is not None
        assert content is not None


# ── Registry ──────────────────────────────────────────

class TestRegistry:
    def test_get_parser_exact(self):
        p = get_parser("qwen")
        assert isinstance(p, QwenToolCallParser)

    def test_get_parser_fuzzy(self):
        p = get_parser("qwen3-coder-latest")
        assert isinstance(p, Qwen3ToolCallParser)

    def test_get_parser_deepseek(self):
        p = get_parser("deepseek-v3")
        assert isinstance(p, DeepSeekToolCallParser)

    def test_get_parser_unknown_fallback(self):
        p = get_parser("unknown-model-xyz")
        assert isinstance(p, GenericToolCallParser)

    def test_list_parsers(self):
        parsers = list_parsers()
        assert "qwen" in parsers
        assert "deepseek" in parsers
        assert "generic" in parsers
