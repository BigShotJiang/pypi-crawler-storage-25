"""
CLI 增强功能测试 — doctor / status / config / brain / formatter / repl / onboarding
"""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from click.testing import CliRunner

from src.cli import main
from src.config import LeaperConfig, validate_config
from src.agent.formatter import (
    format_tool_call,
    format_response,
    format_error,
    format_table,
    format_progress,
    format_check,
    Colors,
)
from src.agent.repl import ReplSession


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def tmp_config(tmp_path):
    """创建临时配置文件"""
    cfg = LeaperConfig()
    cfg.provider.api_key = "sk-test-key-1234567890"
    cfg.provider.model = "deepseek-v4-flash"
    cfg.provider.name = "deepseek"
    cfg.provider.base_url = "https://api.deepseek.com/v1"
    cfg.agent.workspace = str(tmp_path / "workspace")
    cfg.brain.db_path = str(tmp_path / "brain.db")
    (tmp_path / "workspace").mkdir()
    config_path = tmp_path / "leaper.yaml"
    cfg.save(config_path)
    return config_path, cfg, tmp_path


@pytest.fixture
def tmp_brain_db(tmp_path):
    """创建临时 brain.db"""
    db_path = tmp_path / "brain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id TEXT PRIMARY KEY,
            content TEXT,
            tier INTEGER DEFAULT 1,
            created_at TEXT,
            agent_id TEXT
        )
    """)
    # 插入测试数据
    conn.execute(
        "INSERT INTO memories (id, content, tier, created_at, agent_id) VALUES (?, ?, ?, ?, ?)",
        ("m1", "用户信息：公司是跃盟科技", 1, "2025-01-01", "test"),
    )
    conn.execute(
        "INSERT INTO memories (id, content, tier, created_at, agent_id) VALUES (?, ?, ?, ?, ?)",
        ("m2", "技术选型：选择 DeepSeek 作为主模型", 2, "2025-01-02", "test"),
    )
    conn.execute(
        "INSERT INTO memories (id, content, tier, created_at, agent_id) VALUES (?, ?, ?, ?, ?)",
        ("m3", "产品需求：需要支持飞书渠道", 1, "2025-01-03", "test"),
    )
    conn.commit()
    conn.close()
    return db_path


# ---------------------------------------------------------------------------
# doctor 命令测试
# ---------------------------------------------------------------------------

class TestDoctor:
    def test_doctor_runs(self, runner):
        """doctor 命令能正常运行"""
        result = runner.invoke(main, ["doctor"])
        assert result.exit_code == 0
        assert "诊断" in result.output or "通过" in result.output

    def test_doctor_checks_python_version(self, runner):
        """doctor 检查 Python 版本"""
        result = runner.invoke(main, ["doctor"])
        assert "Python" in result.output


# ---------------------------------------------------------------------------
# status 命令测试
# ---------------------------------------------------------------------------

class TestStatus:
    def test_status_runs(self, runner):
        """status 命令能正常运行"""
        result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "版本" in result.output or "Agent" in result.output

    def test_status_shows_version(self, runner):
        """status 显示版本号"""
        result = runner.invoke(main, ["status"])
        assert "v" in result.output


# ---------------------------------------------------------------------------
# config 命令测试
# ---------------------------------------------------------------------------

class TestConfig:
    def test_config_show_all(self, runner):
        """config 无参数显示全部配置"""
        result = runner.invoke(main, ["config"])
        assert result.exit_code == 0
        # 应该能看到配置项名称
        assert "provider" in result.output or "配置" in result.output

    def test_config_dot_notation_get(self):
        """dot notation 读取配置"""
        cfg = LeaperConfig()
        cfg.provider.model = "qwen-max"
        assert cfg.get_nested("provider.model") == "qwen-max"
        assert cfg.get_nested("provider.name") == "openai-compatible"
        assert cfg.get_nested("brain.enabled") is True

    def test_config_dot_notation_set(self):
        """dot notation 写入配置"""
        cfg = LeaperConfig()
        ok = cfg.set_nested("provider.model", "glm-4-flash")
        assert ok
        assert cfg.provider.model == "glm-4-flash"

    def test_config_dot_notation_set_bool(self):
        """dot notation 写入布尔值"""
        cfg = LeaperConfig()
        ok = cfg.set_nested("brain.enabled", "false")
        assert ok
        assert cfg.brain.enabled is False

    def test_config_env_override(self):
        """环境变量覆盖配置"""
        cfg = LeaperConfig()
        cfg.provider.model = "deepseek-v4-flash"
        os.environ["LEAPER_PROVIDER_MODEL"] = "env-override-model"
        try:
            val = cfg.get_nested("provider.model")
            assert val == "env-override-model"
        finally:
            del os.environ["LEAPER_PROVIDER_MODEL"]

    def test_config_display_dict_masks_key(self):
        """显示配置时 api_key 脱敏"""
        cfg = LeaperConfig()
        cfg.provider.api_key = "sk-1234567890abcdef"
        d = cfg.to_display_dict()
        assert "1234567890" not in d["provider.api_key"]
        assert "***" in d["provider.api_key"]

    def test_config_unknown_key(self):
        """未知 key 返回 None"""
        cfg = LeaperConfig()
        assert cfg.get_nested("nonexistent.key") is None
        assert cfg.set_nested("nonexistent.key", "val") is False


# ---------------------------------------------------------------------------
# validate_config 测试
# ---------------------------------------------------------------------------

class TestValidateConfig:
    def test_valid_config(self, tmp_path):
        """有效配置无问题"""
        cfg = LeaperConfig()
        cfg.provider.api_key = "sk-valid-key-1234567890"
        cfg.provider.base_url = "https://api.deepseek.com/v1"
        cfg.provider.model = "deepseek-v4-flash"
        cfg.agent.workspace = str(tmp_path)
        issues = validate_config(cfg)
        assert issues == []

    def test_missing_api_key(self):
        """缺少 api_key"""
        cfg = LeaperConfig()
        cfg.provider.api_key = ""
        issues = validate_config(cfg)
        assert any("api_key" in i for i in issues)

    def test_bad_base_url(self):
        """无效的 base_url"""
        cfg = LeaperConfig()
        cfg.provider.api_key = "sk-valid-key-1234567890"
        cfg.provider.base_url = "not-a-url"
        issues = validate_config(cfg)
        assert any("base_url" in i for i in issues)


# ---------------------------------------------------------------------------
# brain CLI 测试
# ---------------------------------------------------------------------------

class TestBrainCli:
    def test_brain_stats(self, runner, tmp_brain_db):
        """brain stats 显示统计"""
        with patch("src.cli.LeaperConfig.load") as mock_load:
            cfg = LeaperConfig()
            cfg.brain.db_path = str(tmp_brain_db)
            mock_load.return_value = cfg
            result = runner.invoke(main, ["brain", "stats"])
            assert result.exit_code == 0
            assert "3" in result.output  # 3 条记忆

    def test_brain_search(self, runner, tmp_brain_db):
        """brain search 搜索记忆"""
        with patch("src.cli.LeaperConfig.load") as mock_load:
            cfg = LeaperConfig()
            cfg.brain.db_path = str(tmp_brain_db)
            mock_load.return_value = cfg
            result = runner.invoke(main, ["brain", "search", "跃盟"])
            assert result.exit_code == 0
            assert "跃盟" in result.output


# ---------------------------------------------------------------------------
# formatter 测试
# ---------------------------------------------------------------------------

class TestFormatter:
    def test_format_tool_call(self):
        """格式化工具调用"""
        result = format_tool_call("search", {"query": "AI"})
        assert "search" in result
        assert "AI" in result

    def test_format_tool_call_no_args(self):
        """无参数的工具调用"""
        result = format_tool_call("get_time")
        assert "get_time" in result

    def test_format_tool_call_long_value(self):
        """长参数值截断"""
        result = format_tool_call("fn", {"data": "a" * 100})
        assert "..." in result

    def test_format_response(self):
        """格式化 AI 回复"""
        result = format_response("你好世界")
        assert "你好世界" in result

    def test_format_response_stream(self):
        """stream 模式返回原文"""
        result = format_response("hello", stream=True)
        assert result == "hello"

    def test_format_error_401(self):
        """401 错误映射"""
        result = format_error("HTTP 401 Unauthorized")
        assert "密钥" in result or "验证" in result

    def test_format_error_timeout(self):
        """timeout 错误映射"""
        result = format_error("Connection timeout")
        assert "超时" in result or "连接" in result

    def test_format_error_generic(self):
        """通用错误不泄露细节"""
        result = format_error("some internal traceback xyz")
        assert "traceback" not in result
        assert "❌" in result

    def test_format_table(self):
        """表格格式化"""
        result = format_table(["名称", "值"], [["model", "qwen"], ["key", "sk-***"]])
        assert "model" in result
        assert "qwen" in result
        assert "---" in result or "-+-" in result

    def test_format_table_empty(self):
        """空表格"""
        assert format_table([], []) == ""

    def test_format_progress(self):
        """进度条"""
        result = format_progress(5, 10, "导入")
        assert "50%" in result
        assert "█" in result
        assert "导入" in result

    def test_format_progress_complete(self):
        """100% 进度"""
        result = format_progress(10, 10)
        assert "100%" in result

    def test_format_progress_zero(self):
        """0 total"""
        result = format_progress(0, 0)
        assert "0%" in result

    def test_format_check(self):
        """检查项格式化"""
        passed = format_check(True, "Python 版本", "3.12")
        failed = format_check(False, "brain.db", "权限不足")
        assert "✅" in passed
        assert "❌" in failed


# ---------------------------------------------------------------------------
# REPL 测试
# ---------------------------------------------------------------------------

class TestRepl:
    def test_parse_command_help(self):
        """解析 /help 命令"""
        repl = ReplSession(chat_fn=AsyncMock())
        cmd, arg = repl.parse_command("/help")
        assert cmd == "/help"

    def test_parse_command_brain_with_arg(self):
        """解析 /brain query 命令"""
        repl = ReplSession(chat_fn=AsyncMock())
        cmd, arg = repl.parse_command("/brain AI 趋势")
        assert cmd == "/brain"
        assert arg == "AI 趋势"

    def test_parse_command_normal_text(self):
        """普通文本不是命令"""
        repl = ReplSession(chat_fn=AsyncMock())
        cmd, arg = repl.parse_command("你好")
        assert cmd is None

    def test_parse_command_unknown(self):
        """未知命令不解析"""
        repl = ReplSession(chat_fn=AsyncMock())
        cmd, arg = repl.parse_command("/unknown")
        assert cmd is None

    def test_multiline_input(self):
        """多行输入处理"""
        repl = ReplSession(chat_fn=AsyncMock())
        assert repl.process_input('"""') is None  # 开始多行
        assert repl.process_input("line1") is None
        assert repl.process_input("line2") is None
        result = repl.process_input('"""')
        assert result is not None
        assert "line1" in result
        assert "line2" in result

    def test_single_line_triple_quotes(self):
        """单行三引号包裹"""
        repl = ReplSession(chat_fn=AsyncMock())
        result = repl.process_input('"""hello world"""')
        assert result == "hello world"

    @pytest.mark.asyncio
    async def test_handle_exit(self):
        """处理 /exit 命令"""
        repl = ReplSession(chat_fn=AsyncMock())
        should_continue = await repl.handle_command("/exit", "")
        assert should_continue is False

    @pytest.mark.asyncio
    async def test_handle_clear(self):
        """处理 /clear 命令"""
        repl = ReplSession(chat_fn=AsyncMock())
        repl.history = [{"role": "user", "content": "hi"}]
        should_continue = await repl.handle_command("/clear", "")
        assert should_continue is True
        assert repl.history == []

    @pytest.mark.asyncio
    async def test_handle_model_switch(self):
        """处理 /model 命令"""
        repl = ReplSession(chat_fn=AsyncMock(), model_name="old-model")
        await repl.handle_command("/model", "new-model")
        assert repl.model_name == "new-model"


# ---------------------------------------------------------------------------
# onboarding 检测测试
# ---------------------------------------------------------------------------

class TestOnboarding:
    def test_needs_onboarding_no_brain(self):
        """无 brain 时需要引导"""
        from src.agent.onboarding import OnboardingManager
        mgr = OnboardingManager(brain=None)
        assert mgr.needs_onboarding() is True

    def test_onboarding_done_flag(self):
        """标记完成后不再需要引导"""
        from src.agent.onboarding import OnboardingManager
        mgr = OnboardingManager(brain=None)
        mgr._onboarding_done = True
        assert mgr.needs_onboarding() is False

    def test_check_complete_by_rounds(self):
        """5 轮对话后认为引导完成"""
        from src.agent.onboarding import OnboardingManager
        mgr = OnboardingManager(brain=None)
        conversation = [{"role": "user", "content": f"msg{i}"} for i in range(5)]
        assert mgr.check_onboarding_complete(conversation) is True

    @pytest.mark.asyncio
    async def test_extract_user_info(self):
        """从对话提取用户信息"""
        from src.agent.onboarding import OnboardingManager
        mgr = OnboardingManager(brain=None)
        conversation = [
            {"role": "user", "content": "我是跃盟科技的CEO，公司做AI，B轮，团队有50人"},
        ]
        info = await mgr.extract_user_info(conversation)
        assert info is not None
        assert info.get("industry") == "AI"
