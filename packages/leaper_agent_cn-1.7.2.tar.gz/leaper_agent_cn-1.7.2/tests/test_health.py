"""健康检查测试"""
import pytest
import asyncio

from src.health import (
    HealthChecker, HealthReport, CheckResult, CheckStatus,
)
from src.config import LeaperConfig


class TestCheckResult:
    def test_ok(self):
        r = CheckResult(name="test", status=CheckStatus.OK, message="good")
        assert r.status == CheckStatus.OK

    def test_fail(self):
        r = CheckResult(name="test", status=CheckStatus.FAIL)
        assert r.status == CheckStatus.FAIL


class TestHealthReport:
    def test_empty_is_ok(self):
        report = HealthReport()
        assert report.ok

    def test_all_ok(self):
        report = HealthReport(results=[
            CheckResult("a", CheckStatus.OK),
            CheckResult("b", CheckStatus.SKIP),
        ])
        assert report.ok

    def test_has_fail(self):
        report = HealthReport(results=[
            CheckResult("a", CheckStatus.OK),
            CheckResult("b", CheckStatus.FAIL),
        ])
        assert not report.ok

    def test_summary(self):
        report = HealthReport(results=[
            CheckResult("a", CheckStatus.OK),
            CheckResult("b", CheckStatus.WARN),
        ])
        s = report.summary
        assert "ok" in s or "warn" in s

    def test_to_dict(self):
        report = HealthReport(results=[
            CheckResult("a", CheckStatus.OK, message="fine"),
        ])
        d = report.to_dict()
        assert d["ok"] is True
        assert len(d["checks"]) == 1


class TestHealthChecker:
    @pytest.mark.asyncio
    async def test_run_all_no_config(self):
        checker = HealthChecker(config=None)
        report = await checker.run_all()
        assert isinstance(report, HealthReport)
        assert len(report.results) > 0

    @pytest.mark.asyncio
    async def test_python_version(self):
        checker = HealthChecker()
        result = await checker.check_python_version()
        # 我们跑测试的 Python 肯定 >= 3.10
        assert result.status == CheckStatus.OK

    @pytest.mark.asyncio
    async def test_disk_space(self):
        checker = HealthChecker()
        result = await checker.check_disk_space()
        assert result.status in (CheckStatus.OK, CheckStatus.WARN)

    @pytest.mark.asyncio
    async def test_memory_check(self):
        checker = HealthChecker()
        result = await checker.check_memory()
        assert result.status in (CheckStatus.OK, CheckStatus.WARN)

    @pytest.mark.asyncio
    async def test_config_check_with_valid(self):
        cfg = LeaperConfig()
        cfg.provider.api_key = "sk-test1234567890"
        checker = HealthChecker(config=cfg)
        result = await checker.check_config()
        # api_key 设置了，至少不会报缺失
        assert result.status in (CheckStatus.OK, CheckStatus.WARN)

    @pytest.mark.asyncio
    async def test_brain_check_skip(self):
        checker = HealthChecker(config=None)
        result = await checker.check_brain()
        assert result.status == CheckStatus.SKIP

    def test_register_custom_check(self):
        checker = HealthChecker()
        count_before = len(checker._checks)

        async def custom():
            return CheckResult("custom", CheckStatus.OK)

        checker.register_check(custom)
        assert len(checker._checks) == count_before + 1
