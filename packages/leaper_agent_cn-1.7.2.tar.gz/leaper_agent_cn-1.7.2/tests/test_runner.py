"""AgentRunner + ToolRegistry + ProcessRegistry + Toolsets + OutputLimits + SchemaSanitizer + Trajectory 测试

至少 25 个测试覆盖路线 I 的所有模块。
"""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
from pathlib import Path
from typing import Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── 导入被测模块 ──
from src.tools.registry import ToolRegistry, ToolHandler, PRIORITY_NATIVE, PRIORITY_MCP, PRIORITY_SKILL
from src.tools.toolsets import (
    get_toolset, list_toolsets, merge_toolsets,
    register_toolset, unregister_toolset, TOOLSETS, _custom_toolsets,
)
from src.tools.output_limits import truncate_output, get_limit, set_limit, TOOL_LIMITS
from src.tools.schema_sanitizer import sanitize_schema, validate_tool_def
from src.tools.process_registry import ProcessRegistry, ProcessHandle
from src.agent.trajectory import TrajectoryRecorder
from src.tools.base import Tool


# ── 辅助 ──

class DummyTool(Tool):
    """测试用的假工具"""
    name = "dummy"
    description = "测试工具"
    parameters = {"type": "object", "properties": {"msg": {"type": "string"}}}

    async def execute(self, arguments: dict) -> str:
        return f"echo: {arguments.get('msg', '')}"


class FailTool(Tool):
    """总是失败的工具"""
    name = "fail_tool"
    description = "会失败的工具"
    parameters = {"type": "object", "properties": {}}

    async def execute(self, arguments: dict) -> str:
        raise RuntimeError("故意失败")


# ══════════════════════════════════════════════════════════════
# ToolRegistry 测试
# ══════════════════════════════════════════════════════════════

class TestToolRegistry:
    def test_register_and_get(self):
        """注册工具后能获取"""
        reg = ToolRegistry()
        reg.register("test", lambda: "ok", {"type": "object"}, priority=10, description="测试")
        assert reg.has("test")
        handler = reg.get("test")
        assert handler is not None
        assert handler.name == "test"

    def test_unregister(self):
        """卸载工具"""
        reg = ToolRegistry()
        reg.register("test", lambda: "ok", {})
        assert reg.unregister("test")
        assert not reg.has("test")
        assert not reg.unregister("nonexistent")

    def test_priority_override(self):
        """高优先级覆盖低优先级"""
        reg = ToolRegistry()
        reg.register("tool", lambda: "low", {}, priority=10, source="skill")
        reg.register("tool", lambda: "high", {}, priority=100, source="native")
        handler = reg.get("tool")
        assert handler.source == "native"

    def test_priority_ignore(self):
        """低优先级不覆盖高优先级"""
        reg = ToolRegistry()
        reg.register("tool", lambda: "high", {}, priority=100, source="native")
        reg.register("tool", lambda: "low", {}, priority=10, source="skill")
        handler = reg.get("tool")
        assert handler.source == "native"

    def test_conflict_log(self):
        """冲突日志记录"""
        reg = ToolRegistry()
        reg.register("x", lambda: "a", {}, priority=10)
        reg.register("x", lambda: "b", {}, priority=20)
        conflicts = reg.get_conflicts()
        assert len(conflicts) == 1

    def test_list_all(self):
        """列出所有工具"""
        reg = ToolRegistry()
        reg.register("a", lambda: "", {}, description="aaa")
        reg.register("b", lambda: "", {}, description="bbb")
        infos = reg.list_all()
        assert len(infos) == 2
        names = {i.name for i in infos}
        assert names == {"a", "b"}

    def test_get_schemas(self):
        """生成 schemas"""
        reg = ToolRegistry()
        tool = DummyTool()
        reg.register_tool(tool)
        schemas = reg.get_schemas()
        assert len(schemas) == 1
        assert schemas[0]["function"]["name"] == "dummy"

    @pytest.mark.asyncio
    async def test_execute_tool_instance(self):
        """执行 Tool 实例"""
        reg = ToolRegistry()
        reg.register_tool(DummyTool())
        result = await reg.execute("dummy", {"msg": "hello"})
        assert result == "echo: hello"

    @pytest.mark.asyncio
    async def test_execute_async_callable(self):
        """执行 async callable"""
        reg = ToolRegistry()

        async def my_func(x: int = 0):
            return x * 2

        reg.register("double", my_func, {})
        result = await reg.execute("double", {"x": 5})
        assert result == "10"

    @pytest.mark.asyncio
    async def test_execute_missing_tool(self):
        """执行不存在的工具"""
        reg = ToolRegistry()
        with pytest.raises(KeyError):
            await reg.execute("nonexistent", {})

    def test_register_from_mcp(self):
        """从 MCP 列表批量注册"""
        reg = ToolRegistry()
        mcp_tools = [
            {"name": "mcp_a", "description": "MCP A", "schema": {}, "handler": lambda: ""},
            {"name": "mcp_b", "description": "MCP B", "schema": {}, "handler": lambda: ""},
        ]
        count = reg.register_from_mcp(mcp_tools)
        assert count == 2
        assert reg.has("mcp_a")
        assert reg.has("mcp_b")

    def test_clear(self):
        """清空注册表"""
        reg = ToolRegistry()
        reg.register("a", lambda: "", {})
        reg.register("b", lambda: "", {})
        reg.clear()
        assert len(reg) == 0

    def test_len_and_contains(self):
        """__len__ 和 __contains__"""
        reg = ToolRegistry()
        reg.register("x", lambda: "", {})
        assert len(reg) == 1
        assert "x" in reg
        assert "y" not in reg


# ══════════════════════════════════════════════════════════════
# Toolsets 测试
# ══════════════════════════════════════════════════════════════

class TestToolsets:
    def setup_method(self):
        _custom_toolsets.clear()

    def test_get_builtin(self):
        """获取内置工具集"""
        tools = get_toolset("minimal")
        assert "terminal" in tools
        assert "read_file" in tools

    def test_get_unknown_raises(self):
        """未知工具集抛异常"""
        with pytest.raises(KeyError):
            get_toolset("nonexistent_xyz")

    def test_list_toolsets(self):
        """列出所有工具集"""
        result = list_toolsets()
        assert "minimal" in result
        assert "standard" in result
        assert "full" in result

    def test_merge_add(self):
        """工具集合并-添加"""
        tools = merge_toolsets("minimal", add=["web_search"])
        assert "web_search" in tools
        assert "terminal" in tools

    def test_merge_remove(self):
        """工具集合并-移除"""
        tools = merge_toolsets("standard", remove=["terminal"])
        assert "terminal" not in tools
        assert "read_file" in tools

    def test_custom_toolset(self):
        """注册自定义工具集"""
        register_toolset("my_set", ["a", "b", "c"])
        tools = get_toolset("my_set")
        assert tools == ["a", "b", "c"]
        assert unregister_toolset("my_set")
        with pytest.raises(KeyError):
            get_toolset("my_set")


# ══════════════════════════════════════════════════════════════
# Output Limits 测试
# ══════════════════════════════════════════════════════════════

class TestOutputLimits:
    def test_within_limit(self):
        """不超限不截断"""
        text = "hello" * 10
        result = truncate_output(text, "terminal")
        assert result == text

    def test_truncate(self):
        """超限截断"""
        text = "x" * 20000
        result = truncate_output(text, "terminal")  # limit=10000
        assert len(result) < 20000
        assert "省略" in result

    def test_empty(self):
        """空文本不截断"""
        assert truncate_output("", "terminal") == ""
        assert truncate_output(None, "terminal") is None

    def test_custom_limit(self):
        """自定义限制"""
        set_limit("my_tool", 100)
        text = "a" * 200
        result = truncate_output(text, "my_tool")
        assert len(result) < 200
        # 清理
        TOOL_LIMITS.pop("my_tool", None)


# ══════════════════════════════════════════════════════════════
# Schema Sanitizer 测试
# ══════════════════════════════════════════════════════════════

class TestSchemaSanitizer:
    def test_sanitize_removes_fields(self):
        """清理不支持的字段"""
        schema = {
            "type": "object",
            "$schema": "http://...",
            "additionalProperties": False,
            "properties": {"name": {"type": "string"}},
        }
        result = sanitize_schema(schema)
        assert "$schema" not in result
        assert "additionalProperties" not in result
        assert result["properties"]["name"]["type"] == "string"

    def test_sanitize_empty(self):
        """空 schema 补全"""
        result = sanitize_schema({})
        assert result["type"] == "object"

    def test_sanitize_nested(self):
        """嵌套 object 清理"""
        schema = {
            "type": "object",
            "properties": {
                "inner": {
                    "type": "object",
                    "additionalProperties": True,
                    "properties": {"x": {"type": "integer"}},
                },
            },
        }
        result = sanitize_schema(schema)
        inner = result["properties"]["inner"]
        assert "additionalProperties" not in inner

    def test_validate_valid(self):
        """验证正确的 tool def"""
        tool_def = {
            "type": "function",
            "function": {
                "name": "test",
                "description": "测试",
                "parameters": {"type": "object", "properties": {}},
            },
        }
        issues = validate_tool_def(tool_def)
        assert len(issues) == 0

    def test_validate_missing_fields(self):
        """验证缺失字段"""
        issues = validate_tool_def({"type": "function", "function": {}})
        assert any("name" in i for i in issues)


# ══════════════════════════════════════════════════════════════
# Trajectory 测试
# ══════════════════════════════════════════════════════════════

class TestTrajectory:
    def test_record_turn(self):
        """记录完整一轮"""
        tr = TrajectoryRecorder()
        tr.start_turn("你好")
        tr.record_llm_call(100, 50, "qwen-max", 500)
        tr.record_tool_call("web_search", {"q": "test"}, "结果", True)
        tr.end_turn("你好！")

        stats = tr.get_stats()
        assert stats["total_turns"] == 1
        assert stats["total_tokens"] == 150
        assert stats["total_tool_calls"] == 1

    def test_save_and_load(self):
        """保存和加载"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tr = TrajectoryRecorder(save_dir=tmpdir)
            tr.start_turn("test")
            tr.end_turn("reply")
            path = tr.save("test_session")
            assert os.path.exists(path)

            tr2 = TrajectoryRecorder(save_dir=tmpdir)
            loaded = tr2.load("test_session")
            assert len(loaded) == 1
            assert loaded[0]["total_turns"] == 1

    def test_compress(self):
        """压缩轨迹"""
        tr = TrajectoryRecorder()
        for i in range(100):
            tr.start_turn(f"msg_{i}")
            tr.end_turn(f"reply_{i}")
        assert len(tr._turns) == 100
        tr.compress(max_turns=20)
        assert len(tr._turns) == 20

    def test_stats_cost(self):
        """成本计算"""
        tr = TrajectoryRecorder()
        tr.start_turn("test")
        tr.record_llm_call(1000000, 0, "qwen-max", 100)  # 1M input tokens
        tr.end_turn("done")

        stats = tr.get_stats()
        assert stats["total_cost_yuan"] > 0

    def test_clear(self):
        """清空轨迹"""
        tr = TrajectoryRecorder()
        tr.start_turn("test")
        tr.end_turn("reply")
        tr.clear()
        assert tr.get_stats()["total_turns"] == 0


# ══════════════════════════════════════════════════════════════
# ProcessRegistry 测试
# ══════════════════════════════════════════════════════════════

class TestProcessRegistry:
    @pytest.mark.asyncio
    async def test_spawn_and_list(self):
        """创建进程并列出"""
        pr = ProcessRegistry()
        # 跨平台命令
        cmd = "echo hello"
        handle = await pr.spawn(cmd, timeout=10)
        assert handle.pid > 0
        # 等待完成
        await asyncio.sleep(1)
        all_procs = pr.list_all()
        assert len(all_procs) >= 1

    @pytest.mark.asyncio
    async def test_read_output(self):
        """读取进程输出"""
        pr = ProcessRegistry()
        cmd = "echo test_output_123"
        handle = await pr.spawn(cmd, timeout=10)
        await asyncio.sleep(1)
        output = await pr.read_output(handle.pid)
        assert "test_output_123" in output

    @pytest.mark.asyncio
    async def test_cleanup_zombies(self):
        """清理已结束的进程"""
        pr = ProcessRegistry()
        handle = await pr.spawn("echo done", timeout=10)
        await asyncio.sleep(1)
        cleaned = pr.cleanup_zombies()
        assert cleaned >= 1
        assert pr.total_count == 0

    @pytest.mark.asyncio
    async def test_max_concurrent(self):
        """超过最大并发限制"""
        pr = ProcessRegistry(max_concurrent=1)
        # 启动一个长时间运行的进程
        import sys
        if sys.platform == "win32":
            cmd = "ping -n 10 127.0.0.1"
        else:
            cmd = "sleep 10"
        await pr.spawn(cmd, timeout=30)
        with pytest.raises(RuntimeError, match="上限"):
            await pr.spawn("echo second", timeout=10)
        await pr.kill_all()

    @pytest.mark.asyncio
    async def test_kill(self):
        """终止进程"""
        pr = ProcessRegistry()
        import sys
        if sys.platform == "win32":
            cmd = "ping -n 100 127.0.0.1"
        else:
            cmd = "sleep 100"
        handle = await pr.spawn(cmd, timeout=0)
        assert handle.is_running
        await pr.kill(handle.pid)
        await asyncio.sleep(1)
        assert not handle.is_running


# ══════════════════════════════════════════════════════════════
# AgentRunner 测试（mock 化）
# ══════════════════════════════════════════════════════════════

class TestAgentRunner:
    def _make_config(self):
        """创建测试用 config"""
        from src.config import LeaperConfig
        cfg = LeaperConfig()
        cfg.provider.name = "deepseek"
        cfg.provider.api_key = "test-key-12345"
        cfg.provider.model = "deepseek-chat"
        cfg.brain.enabled = False
        return cfg

    @pytest.mark.asyncio
    async def test_initialize(self):
        """初始化不报错"""
        from src.agent.runner import AgentRunner

        cfg = self._make_config()
        with tempfile.TemporaryDirectory() as tmpdir:
            cfg.agent.workspace = tmpdir
            runner = AgentRunner(config=cfg, workspace_dir=tmpdir)

            # mock provider creation
            with patch("src.agent.runner.AgentRunner._create_provider") as mock_prov:
                mock_prov.return_value = MagicMock()
                await runner.initialize(toolset="minimal")

            assert runner._initialized
            assert len(runner.tool_registry) > 0
            await runner.shutdown()

    @pytest.mark.asyncio
    async def test_shutdown_idempotent(self):
        """shutdown 可重复调用"""
        from src.agent.runner import AgentRunner

        cfg = self._make_config()
        with tempfile.TemporaryDirectory() as tmpdir:
            cfg.agent.workspace = tmpdir
            runner = AgentRunner(config=cfg, workspace_dir=tmpdir)
            await runner.shutdown()
            await runner.shutdown()  # 不应报错

    @pytest.mark.asyncio
    async def test_handle_tool_calls(self):
        """handle_tool_calls 执行正确"""
        from src.agent.runner import AgentRunner

        cfg = self._make_config()
        with tempfile.TemporaryDirectory() as tmpdir:
            cfg.agent.workspace = tmpdir
            runner = AgentRunner(config=cfg, workspace_dir=tmpdir)
            runner.tool_registry.register_tool(DummyTool())

            results = await runner.handle_tool_calls([
                {
                    "id": "call_1",
                    "function": {
                        "name": "dummy",
                        "arguments": json.dumps({"msg": "hi"}),
                    },
                }
            ])

            assert len(results) == 1
            assert results[0]["content"] == "echo: hi"

    @pytest.mark.asyncio
    async def test_handle_tool_calls_missing(self):
        """调用不存在的工具"""
        from src.agent.runner import AgentRunner

        cfg = self._make_config()
        with tempfile.TemporaryDirectory() as tmpdir:
            cfg.agent.workspace = tmpdir
            runner = AgentRunner(config=cfg, workspace_dir=tmpdir)

            results = await runner.handle_tool_calls([
                {
                    "id": "call_1",
                    "function": {"name": "nonexistent", "arguments": "{}"},
                }
            ])
            assert "未注册" in results[0]["content"]

    def test_get_status(self):
        """获取状态"""
        from src.agent.runner import AgentRunner

        cfg = self._make_config()
        runner = AgentRunner(config=cfg, workspace_dir=".")
        status = runner.get_status()
        assert "initialized" in status
        assert status["initialized"] is False
