"""LeaperEvolution 进化引擎测试"""
import pytest
import pytest_asyncio
from unittest.mock import AsyncMock, patch

from src.brain.engine import LeaperBrain
from src.brain.evolution import LeaperEvolution


@pytest_asyncio.fixture
async def brain(tmp_path):
    """用文件 db（evolution 内部会独立 connect）"""
    db_path = str(tmp_path / "test.db")
    b = LeaperBrain(db_path=db_path, agent_id="test-agent")
    await b.initialize()
    yield b
    await b.close()


@pytest_asyncio.fixture
async def evolution(brain):
    return LeaperEvolution(brain=brain)


class TestInit:
    def test_init(self, brain):
        """初始化 LeaperEvolution"""
        evo = LeaperEvolution(brain=brain)
        assert evo.brain is brain


class TestRunFullEvolution:
    @pytest.mark.asyncio
    async def test_run_full_evolution_empty(self, evolution: LeaperEvolution):
        """空库运行完整进化不崩溃"""
        with patch.object(evolution, "evolve_l4_profile", new_callable=AsyncMock) as mock_l4:
            mock_l4.return_value = {"personality": [], "preference": [], "expertise": [], "context": []}
            summary = await evolution.run_full_evolution()
        assert "l2_consolidated" in summary
        assert summary["l2_consolidated"] == 0


class TestEvolutionWithEntries:
    @pytest.mark.asyncio
    async def test_l1_extract(self, evolution: LeaperEvolution):
        """L1 从对话提取条目"""
        conversation = [
            {"role": "user", "content": "我每天使用 Python 做数据分析工作"},
            {"role": "assistant", "content": "Python 是数据分析的主流语言，配合 pandas 和 numpy 效率很高"},
        ]
        extracted = await evolution.evolve_l1_extract(conversation)
        assert isinstance(extracted, list)

    @pytest.mark.asyncio
    async def test_l2_consolidate_empty(self, evolution: LeaperEvolution):
        """空库 L2 合并返回空列表"""
        result = await evolution.evolve_l2_consolidate()
        assert result == []

    @pytest.mark.asyncio
    async def test_l3_skill_empty(self, evolution: LeaperEvolution):
        """空库 L3 提升返回空列表"""
        result = await evolution.evolve_l3_skill()
        assert result == []

    @pytest.mark.asyncio
    async def test_l5_meta_empty(self, evolution: LeaperEvolution):
        """空库 L5 健康报告"""
        report = await evolution.evolve_l5_meta()
        assert report["total_entries"] == 0
        assert report["consistency_score"] == 1.0

    @pytest.mark.asyncio
    async def test_keyword_similarity(self):
        """关键词相似度计算"""
        sim = LeaperEvolution._keyword_similarity("Python 数据分析", "Python 数据分析")
        assert sim == 1.0
        sim2 = LeaperEvolution._keyword_similarity("Python", "Java")
        assert sim2 == 0.0
