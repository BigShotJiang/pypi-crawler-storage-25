"""Tests for Brain Console Web UI"""

import json
import pytest
import aiosqlite
from aiohttp.test_utils import TestClient, TestServer

from src.console.app import create_app


@pytest.fixture
async def brain_db(tmp_path):
    """Create a test brain.db with sample data."""
    db_path = str(tmp_path / "brain.db")
    async with aiosqlite.connect(db_path) as db:
        await db.executescript("""
            CREATE TABLE IF NOT EXISTS entries (
                id TEXT PRIMARY KEY, agent_id TEXT, entry_type TEXT, content TEXT,
                category TEXT, confidence REAL DEFAULT 0.8, access_count INTEGER DEFAULT 0,
                last_accessed TEXT, source_ids TEXT, metadata TEXT,
                created_at TEXT, updated_at TEXT, status TEXT DEFAULT 'active'
            );
            CREATE TABLE IF NOT EXISTS profiles (
                id TEXT PRIMARY KEY, agent_id TEXT, dimension TEXT, key TEXT,
                value TEXT, confidence REAL DEFAULT 0.8, evidence_ids TEXT, updated_at TEXT
            );
            CREATE TABLE IF NOT EXISTS transitions (
                id TEXT PRIMARY KEY, agent_id TEXT, entry_id_old TEXT, entry_id_new TEXT,
                category TEXT, old_content TEXT, new_content TEXT,
                transition_type TEXT DEFAULT 'update', created_at TEXT
            );
        """)
        for i in range(25):
            await db.execute(
                "INSERT INTO entries (id, agent_id, entry_type, content, category, confidence, "
                "access_count, last_accessed, source_ids, metadata, created_at, updated_at, status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (f"entry{i:03d}", "test-agent", "fact" if i % 2 == 0 else "preference",
                 f"这是第{i}条测试知识内容，关于AI技术", "tech" if i < 15 else "personal",
                 0.8 + (i % 3) * 0.05, i, "2025-01-01T00:00:00", "[]",
                 json.dumps({"pinned": i == 0}), "2025-01-01T00:00:00", "2025-01-01T00:00:00", "active"),
            )
        await db.execute(
            "INSERT INTO profiles VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("p1", "test-agent", "interests", "AI", "深度学习", 0.9, "[]", "2025-01-01"),
        )
        await db.execute(
            "INSERT INTO transitions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("t1", "test-agent", "entry000", "entry001", "tech", "旧内容", "新内容", "consolidate", "2025-01-01"),
        )
        await db.commit()
    return db_path


@pytest.fixture
async def client(brain_db):
    app, console = create_app(brain_db)
    async with TestClient(TestServer(app)) as c:
        yield c


@pytest.mark.asyncio
async def test_static_page(client):
    resp = await client.get("/")
    assert resp.status == 200
    text = await resp.text()
    assert "Brain Console" in text


@pytest.mark.asyncio
async def test_stats_endpoint(client):
    resp = await client.get("/api/stats")
    assert resp.status == 200
    data = await resp.json()
    assert data["total"] == 25
    assert "by_type" in data
    assert data["profiles_count"] == 1


@pytest.mark.asyncio
async def test_entries_list(client):
    resp = await client.get("/api/entries")
    data = await resp.json()
    assert data["total"] == 25
    assert len(data["entries"]) == 20
    assert data["pages"] == 2

    resp = await client.get("/api/entries?page=2&size=20")
    data = await resp.json()
    assert len(data["entries"]) == 5

    resp = await client.get("/api/entries?q=第3条")
    data = await resp.json()
    assert data["total"] >= 1


@pytest.mark.asyncio
async def test_entry_detail(client):
    resp = await client.get("/api/entries/entry005")
    assert resp.status == 200
    data = await resp.json()
    assert data["id"] == "entry005"

    resp = await client.get("/api/entries/nonexist")
    assert resp.status == 404


@pytest.mark.asyncio
async def test_delete_entry(client):
    resp = await client.delete("/api/entries/entry010")
    assert resp.status == 200
    data = await resp.json()
    assert data["ok"] is True

    resp = await client.get("/api/entries?size=100")
    data = await resp.json()
    ids = [e["id"] for e in data["entries"]]
    assert "entry010" not in ids
