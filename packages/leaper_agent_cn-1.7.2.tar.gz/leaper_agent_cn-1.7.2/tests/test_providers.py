"""测试所有 LLM Provider（全部 mock httpx）"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock
import json
import time
import hashlib
import hmac


# ===== DeepSeek Provider 测试 =====

@pytest.mark.asyncio
async def test_deepseek_chat():
    """测试 DeepSeek 普通对话"""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"role": "assistant", "content": "你好"}}]
    }

    with patch("httpx.AsyncClient") as MockClient:
        client = AsyncMock()
        client.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.__aenter__ = AsyncMock(return_value=client)
        MockClient.return_value.__aexit__ = AsyncMock(return_value=False)

        # 模拟 DeepSeek API 调用
        async with MockClient() as c:
            resp = await c.post(
                "https://api.deepseek.com/v1/chat/completions",
                json={"model": "deepseek-chat", "messages": [{"role": "user", "content": "你好"}]},
                headers={"Authorization": "Bearer sk-test"},
            )
            data = resp.json()
            assert data["choices"][0]["message"]["content"] == "你好"


@pytest.mark.asyncio
async def test_deepseek_stream():
    """测试 DeepSeek 流式输出"""
    chunks = [
        'data: {"choices":[{"delta":{"content":"你"}}]}\n\n'.encode("utf-8"),
        'data: {"choices":[{"delta":{"content":"好"}}]}\n\n'.encode("utf-8"),
        b'data: [DONE]\n\n',
    ]

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.aiter_lines = AsyncMock(return_value=iter([
        'data: {"choices":[{"delta":{"content":"你"}}]}',
        'data: {"choices":[{"delta":{"content":"好"}}]}',
        'data: [DONE]',
    ]))

    with patch("httpx.AsyncClient") as MockClient:
        client = AsyncMock()
        client.stream = MagicMock()
        MockClient.return_value.__aenter__ = AsyncMock(return_value=client)
        MockClient.return_value.__aexit__ = AsyncMock(return_value=False)

        # 验证流式解析逻辑
        collected = ""
        for line in ['data: {"choices":[{"delta":{"content":"你"}}]}',
                     'data: {"choices":[{"delta":{"content":"好"}}]}',
                     'data: [DONE]']:
            if line.startswith("data: ") and line != "data: [DONE]":
                chunk_data = json.loads(line[6:])
                delta = chunk_data["choices"][0]["delta"]
                if "content" in delta:
                    collected += delta["content"]
        assert collected == "你好"


@pytest.mark.asyncio
async def test_deepseek_tool_calls():
    """测试 DeepSeek 工具调用"""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{
            "message": {
                "role": "assistant",
                "content": None,
                "tool_calls": [{
                    "id": "call_123",
                    "type": "function",
                    "function": {"name": "search", "arguments": '{"query": "天气"}'}
                }]
            }
        }]
    }

    with patch("httpx.AsyncClient") as MockClient:
        client = AsyncMock()
        client.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.__aenter__ = AsyncMock(return_value=client)
        MockClient.return_value.__aexit__ = AsyncMock(return_value=False)

        async with MockClient() as c:
            resp = await c.post(
                "https://api.deepseek.com/v1/chat/completions",
                json={"model": "deepseek-chat", "messages": [], "tools": []},
                headers={"Authorization": "Bearer sk-test"},
            )
            data = resp.json()
            tool_calls = data["choices"][0]["message"]["tool_calls"]
            assert len(tool_calls) == 1
            assert tool_calls[0]["function"]["name"] == "search"


@pytest.mark.asyncio
async def test_qwen_chat():
    """测试通义千问对话"""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"role": "assistant", "content": "我是通义千问"}}]
    }

    with patch("httpx.AsyncClient") as MockClient:
        client = AsyncMock()
        client.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.__aenter__ = AsyncMock(return_value=client)
        MockClient.return_value.__aexit__ = AsyncMock(return_value=False)

        async with MockClient() as c:
            resp = await c.post(
                "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
                json={"model": "qwen-max", "messages": [{"role": "user", "content": "你好"}]},
                headers={"Authorization": "Bearer sk-test"},
            )
            data = resp.json()
            assert data["choices"][0]["message"]["content"] == "我是通义千问"


@pytest.mark.asyncio
async def test_zhipu_jwt_generation():
    """测试智谱 JWT token 生成"""
    api_key = "abc123.secret456"
    kid, secret = api_key.split(".")

    # 模拟 JWT 生成逻辑
    import base64

    header = base64.urlsafe_b64encode(
        json.dumps({"alg": "HS256", "sign_type": "SIGN", "kid": kid}).encode()
    ).rstrip(b"=").decode()

    payload = base64.urlsafe_b64encode(
        json.dumps({"api_key": kid, "exp": int(time.time()) + 3600, "timestamp": int(time.time())}).encode()
    ).rstrip(b"=").decode()

    signature_input = f"{header}.{payload}"
    signature = base64.urlsafe_b64encode(
        hmac.new(secret.encode(), signature_input.encode(), hashlib.sha256).digest()
    ).rstrip(b"=").decode() if hasattr(hmac, 'new') else "mock_sig"

    # 验证 JWT 结构
    assert kid == "abc123"
    assert secret == "secret456"
    assert "." in f"{header}.{payload}"


@pytest.mark.asyncio
async def test_moonshot_chat():
    """测试 Moonshot (Kimi) 对话"""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"role": "assistant", "content": "我是 Kimi"}}]
    }

    with patch("httpx.AsyncClient") as MockClient:
        client = AsyncMock()
        client.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.__aenter__ = AsyncMock(return_value=client)
        MockClient.return_value.__aexit__ = AsyncMock(return_value=False)

        async with MockClient() as c:
            resp = await c.post(
                "https://api.moonshot.cn/v1/chat/completions",
                json={"model": "moonshot-v1-8k", "messages": [{"role": "user", "content": "你好"}]},
                headers={"Authorization": "Bearer sk-test"},
            )
            data = resp.json()
            assert data["choices"][0]["message"]["content"] == "我是 Kimi"


def test_create_provider_factory():
    """测试 provider 工厂模式创建"""
    # 模拟工厂函数
    providers_registry = {
        "deepseek": {"base_url": "https://api.deepseek.com/v1", "default_model": "deepseek-chat"},
        "qwen": {"base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1", "default_model": "qwen-max"},
        "zhipu": {"base_url": "https://open.bigmodel.cn/api/paas/v4", "default_model": "glm-4"},
        "moonshot": {"base_url": "https://api.moonshot.cn/v1", "default_model": "moonshot-v1-8k"},
    }

    def create_provider(name: str, api_key: str):
        if name not in providers_registry:
            raise ValueError(f"不支持的 provider: {name}")
        config = providers_registry[name]
        return {"name": name, "api_key": api_key, **config}

    # 验证各 provider 创建
    for name in ["deepseek", "qwen", "zhipu", "moonshot"]:
        p = create_provider(name, "sk-test")
        assert p["name"] == name
        assert p["api_key"] == "sk-test"

    # 验证不支持的 provider 报错
    with pytest.raises(ValueError):
        create_provider("unknown", "sk-test")
