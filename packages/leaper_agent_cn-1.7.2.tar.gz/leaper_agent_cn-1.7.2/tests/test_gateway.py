"""Gateway 网关测试"""
import pytest
from unittest.mock import MagicMock
from aiohttp import web

from src.gateway import Gateway


class TestCreateApp:
    def test_create_gateway(self):
        """创建 Gateway 实例"""
        gw = Gateway(config={"host": "0.0.0.0", "port": 8080})
        assert gw.app is not None
        assert isinstance(gw.app, web.Application)
        assert gw.host == "0.0.0.0"
        assert gw.port == 8080

    def test_register_health(self):
        """注册 /health 路由"""
        gw = Gateway(config={})
        gw.app.router.add_get("/health", gw._health)
        resources = [r.get_info().get("path", "") for r in gw.app.router.resources()]
        assert "/health" in resources

    def test_default_values(self):
        """默认 host/port"""
        gw = Gateway(config={})
        assert gw.host == "0.0.0.0"
        assert gw.port == 8080


class TestHealthEndpoint:
    @pytest.fixture
    def gateway_app(self):
        gw = Gateway(config={})
        gw.app.router.add_get("/health", gw._health)
        return gw

    @pytest.mark.asyncio
    async def test_health_returns_200(self, gateway_app):
        """模拟 /health 请求返回正确响应"""
        from aiohttp.test_utils import TestClient, TestServer
        async with TestClient(TestServer(gateway_app.app)) as client:
            resp = await client.get("/health")
            assert resp.status == 200
            data = await resp.json()
            assert data["status"] == "ok"

    @pytest.mark.asyncio
    async def test_health_lists_channels(self, gateway_app):
        """/health 列出已注册渠道"""
        gateway_app.channels["test-ch"] = MagicMock()
        from aiohttp.test_utils import TestClient, TestServer
        async with TestClient(TestServer(gateway_app.app)) as client:
            resp = await client.get("/health")
            data = await resp.json()
            assert "test-ch" in data["channels"]
