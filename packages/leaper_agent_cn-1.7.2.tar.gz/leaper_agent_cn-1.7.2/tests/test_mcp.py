"""MCP 客户端和管理器测试"""
import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src.mcp.client import MCPClient, _sanitize_error, _build_safe_env
from src.mcp.manager import MCPManager


# ============ JSON-RPC 消息格式 ============

class TestMCPMessageFormat:
    """JSON-RPC 2.0 消息构建"""

    def test_build_request_basic(self):
        client = MCPClient()
        msg = client._build_request("tools/list")
        assert msg["jsonrpc"] == "2.0"
        assert msg["method"] == "tools/list"
        assert "id" in msg

    def test_build_request_with_params(self):
        client = MCPClient()
        msg = client._build_request("tools/call", {"name": "calc", "arguments": {"a": 1}})
        assert msg["params"]["name"] == "calc"

    def test_id_increments(self):
        client = MCPClient()
        m1 = client._build_request("a")
        m2 = client._build_request("b")
        assert m2["id"] == m1["id"] + 1

    def test_build_notification_no_id(self):
        client = MCPClient()
        msg = client._build_notification("notifications/initialized")
        assert "id" not in msg
        assert msg["jsonrpc"] == "2.0"
        assert msg["method"] == "notifications/initialized"


# ============ 工具发现 ============

class TestDiscoverTools:
    """工具列表解析"""

    @pytest.mark.asyncio
    async def test_discover_parses_tools(self):
        client = MCPClient()
        client._connected = True
        client._server_name = "test"
        mock_response = {
            "jsonrpc": "2.0",
            "result": {
                "tools": [
                    {"name": "calculator", "description": "计算器"},
                    {"name": "search", "description": "搜索"},
                ]
            },
            "id": 1,
        }
        client._send_request = AsyncMock(return_value=mock_response)
        tools = await client.list_tools()
        assert len(tools) == 2
        assert tools[0]["name"] == "calculator"

    def test_tool_definitions_format(self):
        """测试工具定义转换为 OpenAI function calling 格式"""
        client = MCPClient()
        client._server_name = "fs"
        client._tools = [
            {"name": "read_file", "description": "读取文件", "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}}}},
        ]
        defs = client.get_tool_definitions()
        assert len(defs) == 1
        assert defs[0]["type"] == "function"
        assert defs[0]["function"]["name"] == "mcp_fs_read_file"
        assert "[MCP:fs]" in defs[0]["function"]["description"]
        assert defs[0]["_mcp_server"] == "fs"
        assert defs[0]["_mcp_tool"] == "read_file"


# ============ 工具调用 ============

class TestCallTool:
    """工具调用"""

    @pytest.mark.asyncio
    async def test_call_returns_text(self):
        client = MCPClient()
        client._connected = True
        client._server_name = "test"
        mock_response = {
            "jsonrpc": "2.0",
            "result": {
                "content": [{"type": "text", "text": "42"}]
            },
            "id": 2,
        }
        client._send_request = AsyncMock(return_value=mock_response)
        result = await client.call_tool("calculator", {"expr": "6*7"})
        assert result == "42"

    @pytest.mark.asyncio
    async def test_call_empty_content(self):
        client = MCPClient()
        client._connected = True
        client._server_name = "test"
        mock_response = {"jsonrpc": "2.0", "result": {"content": []}, "id": 3}
        client._send_request = AsyncMock(return_value=mock_response)
        result = await client.call_tool("noop", {})
        assert "content" in result

    @pytest.mark.asyncio
    async def test_call_error_response(self):
        """工具调用错误处理"""
        client = MCPClient()
        client._connected = True
        client._server_name = "test"
        mock_response = {
            "jsonrpc": "2.0",
            "error": {"code": -32600, "message": "Invalid params"},
            "id": 4,
        }
        client._send_request = AsyncMock(return_value=mock_response)
        with pytest.raises(RuntimeError, match="MCP 工具错误"):
            await client.call_tool("bad_tool", {})


# ============ stdio 传输 ============

class TestStdioTransport:
    """stdio 传输层"""

    @pytest.mark.asyncio
    async def test_send_stdio_format(self):
        """验证 stdio 消息格式正确"""
        client = MCPClient(transport="stdio")
        client._connected = True

        mock_proc = MagicMock()
        mock_stdin = MagicMock()
        mock_stdin.write = MagicMock()
        mock_stdin.drain = AsyncMock()
        mock_proc.stdin = mock_stdin
        mock_proc.returncode = None

        response_line = json.dumps({"jsonrpc": "2.0", "result": {}, "id": 1}).encode() + b"\n"
        mock_stdout = AsyncMock()
        mock_stdout.readline = AsyncMock(return_value=response_line)
        mock_proc.stdout = mock_stdout

        client._process = mock_proc

        result = await client._send_stdio({"jsonrpc": "2.0", "method": "test", "id": 1})
        assert result["jsonrpc"] == "2.0"
        written = mock_stdin.write.call_args[0][0]
        assert written.endswith(b"\n")
        assert json.loads(written.decode())["method"] == "test"


# ============ 配置解析 ============

class TestConfigParsing:
    """配置格式兼容"""

    @pytest.mark.asyncio
    async def test_load_dict_config(self):
        """Hermes/Claude Desktop 风格 dict 配置"""
        manager = MCPManager()
        # connect 会失败（没有真正的 server），但配置解析不应崩溃
        config = {
            "filesystem": {"command": "npx", "args": ["-y", "server-fs"]},
            "remote": {"url": "http://localhost:8080/mcp"},
        }
        await manager.load_config(config)
        assert "filesystem" in manager.clients
        assert "remote" in manager.clients

    @pytest.mark.asyncio
    async def test_load_list_config(self):
        """list 格式配置"""
        manager = MCPManager()
        config = [
            {"name": "fs", "command": "npx", "args": ["-y", "server-fs"]},
            {"name": "api", "url": "http://localhost:8080/mcp"},
        ]
        await manager.load_config(config)
        assert "fs" in manager.clients
        assert "api" in manager.clients

    def test_auto_detect_transport(self):
        """transport 自动推断"""
        manager = MCPManager()
        config_stdio = {"command": "npx", "args": []}
        config_http = {"url": "http://localhost/mcp"}
        # 补充 transport 后检查
        config_stdio.setdefault("name", "s")
        if "url" in config_stdio and "transport" not in config_stdio:
            config_stdio["transport"] = "http"
        elif "command" in config_stdio and "transport" not in config_stdio:
            config_stdio["transport"] = "stdio"
        assert config_stdio.get("transport") == "stdio"

        config_http.setdefault("name", "h")
        if "url" in config_http and "transport" not in config_http:
            config_http["transport"] = "http"
        assert config_http.get("transport") == "http"


# ============ 连接失败降级 ============

class TestGracefulDegradation:
    """连接失败优雅降级"""

    @pytest.mark.asyncio
    async def test_connect_failure_no_crash(self):
        """单个 server 连接失败不影响其他"""
        manager = MCPManager()
        config = {
            "bad_server": {"command": "nonexistent_command_xyz", "args": []},
        }
        # 不应抛出异常
        await manager.load_config(config)
        assert manager.connected_count == 0
        assert "bad_server" in manager.clients

    @pytest.mark.asyncio
    async def test_unknown_tool_raises(self):
        """调用不存在的工具应报错"""
        manager = MCPManager()
        with pytest.raises(ValueError, match="未知的 MCP 工具"):
            await manager.call_tool("mcp_nonexistent_tool", {})


# ============ Manager 管理 ============

class TestMCPManager:
    """多 server 管理"""

    def test_status_empty(self):
        manager = MCPManager()
        status = manager.get_status()
        assert status["total"] == 0
        assert status["connected"] == 0

    def test_is_mcp_tool(self):
        manager = MCPManager()
        manager._tool_map["mcp_fs_read"] = ("fs", "read")
        assert manager.is_mcp_tool("mcp_fs_read")
        assert not manager.is_mcp_tool("builtin_search")

    @pytest.mark.asyncio
    async def test_shutdown_safe(self):
        """shutdown 不应崩溃（即使没有连接）"""
        manager = MCPManager()
        await manager.shutdown()
        assert len(manager.clients) == 0


# ============ 安全工具 ============

class TestSecurity:
    """凭证过滤和环境变量安全"""

    def test_sanitize_credentials(self):
        msg = "Error with token ghp_abc123 and key sk-xyz456"
        cleaned = _sanitize_error(msg)
        assert "ghp_abc123" not in cleaned
        assert "sk-xyz456" not in cleaned
        assert "[REDACTED]" in cleaned

    def test_safe_env_filters(self):
        """只传递安全的环境变量"""
        import os
        env = _build_safe_env({"MY_API_KEY": "secret123"})
        assert "MY_API_KEY" in env
        assert env["MY_API_KEY"] == "secret123"
        # PATH 应该被保留
        if "PATH" in os.environ:
            assert "PATH" in env

    def test_timeout_config(self):
        """超时配置"""
        client = MCPClient()
        assert client._tool_timeout == 120
        assert client._connect_timeout == 60
