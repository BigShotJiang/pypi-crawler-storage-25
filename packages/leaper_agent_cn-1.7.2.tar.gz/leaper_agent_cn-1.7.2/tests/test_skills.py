"""技能系统测试"""
import asyncio
import json
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from src.skills.base import Skill
from src.skills.loader import SkillLoader
from src.skills.manager import SkillManager
from src.skills.creator import SkillCreator


# ====== test_parse_skill_md ======

def test_parse_skill_md():
    """测试解析 SKILL.md 文件"""
    loader = SkillLoader()
    content = """# my-tool
> 这是一个测试工具

## Triggers
- 测试
- test

## Parameters
| Name | Type | Required | Description |
|------|------|----------|-------------|
| query | string | yes | 搜索内容 |
| limit | integer | no | 数量限制 |

## Script
script.py
"""
    skill = loader.parse_skill_md(content)
    assert skill.name == "my-tool"
    assert skill.description == "这是一个测试工具"
    assert "测试" in skill.triggers
    assert "test" in skill.triggers
    assert "query" in skill.parameters
    assert skill.parameters["query"]["required"] is True
    assert skill.parameters["limit"].get("required") is not True


# ====== test_load_from_directory ======

def test_load_from_directory(tmp_path):
    """测试从目录加载技能"""
    # 创建 skill 目录
    skill_dir = tmp_path / "test-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("# test-skill\n> 测试技能\n\n## Triggers\n- hello\n", encoding="utf-8")
    (skill_dir / "script.py").write_text("import json,sys\nprint(json.dumps({'ok':True}))", encoding="utf-8")

    loader = SkillLoader()
    skills = loader.load_from_directory(str(tmp_path))
    assert len(skills) == 1
    assert skills[0].name == "test-skill"
    assert skills[0].script_path.endswith("script.py")


# ====== test_skill_to_tool_def ======

def test_skill_to_tool_def():
    """测试 Skill 转为 OpenAI tool_def 格式"""
    skill = Skill(
        name="calculator",
        description="数学计算",
        parameters={
            "expression": {"type": "string", "description": "表达式", "required": True},
        },
    )
    td = skill.to_tool_def()
    assert td["type"] == "function"
    assert td["function"]["name"] == "calculator"
    assert "expression" in td["function"]["parameters"]["properties"]
    assert "expression" in td["function"]["parameters"]["required"]


# ====== test_find_skill_by_trigger ======

def test_find_skill_by_trigger(tmp_path):
    """测试通过 trigger 关键词查找 skill"""
    # 创建两个 skill
    s1 = tmp_path / "calc"
    s1.mkdir()
    (s1 / "SKILL.md").write_text("# calc\n> 计算\n\n## Triggers\n- 计算\n- calculate\n", encoding="utf-8")

    s2 = tmp_path / "search"
    s2.mkdir()
    (s2 / "SKILL.md").write_text("# search\n> 搜索\n\n## Triggers\n- 搜索\n- search\n", encoding="utf-8")

    manager = SkillManager(skill_dirs=[str(tmp_path)])
    found = manager.find_skill("帮我搜索一下天气")
    assert found is not None
    assert found.name == "search"


# ====== test_execute_skill ======

@pytest.mark.asyncio
async def test_execute_skill(tmp_path):
    """测试执行 skill 脚本"""
    skill_dir = tmp_path / "echo"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("# echo\n> 回声\n\n## Triggers\n- echo\n", encoding="utf-8")
    (skill_dir / "script.py").write_text(
        'import json,sys\nargs=json.loads(sys.stdin.read())\nprint(json.dumps({"echo":args}))',
        encoding="utf-8",
    )

    manager = SkillManager(skill_dirs=[str(tmp_path)])
    result = await manager.execute_skill("echo", {"msg": "hello"})
    data = json.loads(result)
    assert data["echo"]["msg"] == "hello"


# ====== test_execute_skill_with_fn ======

@pytest.mark.asyncio
async def test_execute_skill_with_fn():
    """测试通过内置函数执行 skill"""
    def my_fn(args):
        return f"result: {args.get('x', 0) * 2}"

    skill = Skill(name="double", description="翻倍", execute_fn=my_fn)
    result = await skill.execute({"x": 5})
    assert result == "result: 10"


# ====== test_skill_creator_detect_pattern ======

@pytest.mark.asyncio
async def test_skill_creator_detect_pattern():
    """测试 SkillCreator 检测重复模式"""
    creator = SkillCreator()
    # 构造包含 4 次相同 tool_call 的对话
    conversation = []
    for _ in range(4):
        conversation.append({
            "role": "assistant",
            "tool_calls": [{"function": {"name": "web-search", "arguments": {"query": "test"}}}],
        })
    assert await creator.should_create_skill(conversation) is True

    # 只有 2 次不触发
    short_conv = conversation[:2]
    assert await creator.should_create_skill(short_conv) is False


# ====== test_bundled_skills_loaded ======

def test_bundled_skills_loaded():
    """测试内置技能能正确加载"""
    bundled_dir = str(Path(__file__).parent.parent / "src" / "skills" / "bundled")
    manager = SkillManager(skill_dirs=[bundled_dir])
    skills = manager.get_all_skills()
    assert len(skills) >= 10
    names = [s.name for s in skills]
    assert "calculator" in names
    assert "web-search" in names
    assert "datetime" in names


# ====== test_skill_integration_with_loop ======

@pytest.mark.asyncio
async def test_skill_integration_with_loop(tmp_path):
    """测试 skill 与 AgentLoop 集成"""
    from src.agent.loop import AgentLoop

    # 创建 workspace 并写入 MEMORY.md 跳过 onboarding
    (tmp_path / "MEMORY.md").write_text("user: test\n", encoding="utf-8")

    # Mock provider：用函数而非 side_effect 列表，更灵活
    call_count = {"n": 0}
    async def mock_chat(messages, tools=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return {
                "content": None,
                "tool_calls": [{
                    "id": "tc1",
                    "function": {"name": "test-skill", "arguments": json.dumps({"x": 1})},
                }],
                "finish_reason": "tool_calls",
            }
        return {"content": "完成", "tool_calls": None, "finish_reason": "stop"}

    mock_provider = MagicMock()
    mock_provider.chat = mock_chat

    # 创建带 skill 的 manager
    def test_fn(args):
        return f"executed with {args}"

    skill = Skill(name="test-skill", description="test", execute_fn=test_fn)
    sm = SkillManager(skill_dirs=[])  # 空目录
    sm.register(skill)

    loop = AgentLoop(provider=mock_provider, skill_manager=sm, workspace_dir=str(tmp_path))
    result = await loop.chat("测试")
    assert result == "完成"


# ====== test_skill_creator_save ======

@pytest.mark.asyncio
async def test_skill_creator_save(tmp_path):
    """测试保存 skill 到目录"""
    creator = SkillCreator(skill_dir=str(tmp_path))
    skill = Skill(
        name="my-new-skill",
        description="自动创建的技能",
        triggers=["auto"],
        parameters={"input": {"type": "string", "description": "输入"}},
    )
    path = await creator.save_skill(skill)
    assert Path(path).exists()
    assert (Path(path) / "SKILL.md").exists()
    assert (Path(path) / "script.py").exists()

    # 验证能被重新加载
    loader = SkillLoader()
    skills = loader.load_from_directory(str(tmp_path))
    assert len(skills) == 1
    assert skills[0].name == "my-new-skill"
