"""配置管理测试"""
import pytest
from pathlib import Path

from src.config import LeaperConfig, ProviderConfig, BrainConfig


class TestDefaultConfig:
    def test_default_config(self):
        """默认值正确"""
        cfg = LeaperConfig()
        assert cfg.provider.model == "gpt-4o"
        assert cfg.channel.type == "cli"
        assert cfg.brain.enabled is True
        assert cfg.agent.name == "leaper-agent"

    def test_default_provider(self):
        """Provider 默认值"""
        p = ProviderConfig()
        assert p.name == "openai-compatible"
        assert "openai" in p.base_url


class TestLoadYaml:
    def test_load_yaml(self, tmp_path):
        """从 YAML 文件加载配置"""
        yaml_content = """
provider:
  name: deepseek
  model: deepseek-chat
  api_key: sk-test
  base_url: https://api.deepseek.com/v1
channel:
  type: feishu
brain:
  enabled: false
agent:
  name: my-agent
  role: cto
"""
        f = tmp_path / "leaper.yaml"
        f.write_text(yaml_content, encoding="utf-8")
        cfg = LeaperConfig.load(f)
        assert cfg.provider.name == "deepseek"
        assert cfg.provider.model == "deepseek-chat"
        assert cfg.channel.type == "feishu"
        assert cfg.brain.enabled is False
        assert cfg.agent.role == "cto"

    def test_load_nonexistent(self, tmp_path):
        """不存在的文件返回默认配置"""
        cfg = LeaperConfig.load(tmp_path / "nope.yaml")
        assert cfg.provider.model == "gpt-4o"


class TestSaveYaml:
    def test_save_yaml(self, tmp_path):
        """保存到文件后可重新加载"""
        cfg = LeaperConfig()
        cfg.provider.model = "qwen-max"
        out = tmp_path / "out.yaml"
        cfg.save(out)
        assert out.exists()
        loaded = LeaperConfig.load(out)
        assert loaded.provider.model == "qwen-max"


class TestExpandUser:
    def test_expanduser_in_brain_db_path(self):
        """BrainConfig 默认路径包含展开的 home"""
        cfg = BrainConfig()
        assert "~" not in cfg.db_path
        assert Path(cfg.db_path).is_absolute()
