"""测试各工具"""

import pytest
import asyncio
import os
import sys
from unittest.mock import patch, AsyncMock, MagicMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from tools.calculator import calculate


# ===== 计算器工具（已实现）=====

def test_calculator_basic():
    """测试基本四则运算"""
    assert calculate("2 + 3") == "5"
    assert calculate("10 - 3") == "7"
    assert calculate("4 * 5") == "20"
    assert calculate("10 / 2") == "5.0"


def test_calculator_complex():
    """测试复杂表达式"""
    assert calculate("2 ** 10") == "1024"
    assert calculate("(1 + 2) * 3") == "9"


def test_calculator_reject_dangerous():
    """测试拒绝危险表达式"""
    result = calculate("__import__('os').system('ls')")
    assert "错误" in result


# ===== 搜索工具（mock）=====

@pytest.mark.asyncio
async def test_search_tool():
    """测试搜索工具"""
    async def mock_search(query: str) -> str:
        return f"搜索结果: 关于 '{query}' 的信息"

    result = await mock_search("Python 教程")
    assert "Python 教程" in result


# ===== 文件工具 =====

def test_file_read(tmp_path):
    """测试文件读取工具"""
    test_file = tmp_path / "test.txt"
    test_file.write_text("你好世界", encoding="utf-8")

    # 模拟 file_read 工具
    def file_read(path: str) -> str:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    result = file_read(str(test_file))
    assert result == "你好世界"


def test_file_write(tmp_path):
    """测试文件写入工具"""
    test_file = tmp_path / "output.txt"

    def file_write(path: str, content: str) -> str:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return f"已写入 {len(content)} 字符到 {path}"

    result = file_write(str(test_file), "测试内容")
    assert "已写入" in result
    assert test_file.read_text(encoding="utf-8") == "测试内容"


# ===== Web Fetch 工具 =====

@pytest.mark.asyncio
async def test_web_fetch():
    """测试网页抓取工具（mock httpx）"""
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = "<html><body><h1>标题</h1><p>内容</p></body></html>"

    with patch("httpx.AsyncClient") as MockClient:
        client = AsyncMock()
        client.get = AsyncMock(return_value=mock_resp)
        MockClient.return_value.__aenter__ = AsyncMock(return_value=client)
        MockClient.return_value.__aexit__ = AsyncMock(return_value=False)

        async with MockClient() as c:
            resp = await c.get("https://example.com")
            assert resp.status_code == 200
            assert "标题" in resp.text


# ===== 代码执行工具 =====

def test_code_execute_success():
    """测试代码执行成功"""
    import subprocess

    # 模拟安全的代码执行
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="Hello World\n",
            stderr="",
        )
        result = subprocess.run(
            ["python", "-c", "print('Hello World')"],
            capture_output=True, text=True, timeout=10,
        )
        assert result.returncode == 0
        assert "Hello World" in result.stdout


def test_code_execute_timeout():
    """测试代码执行超时"""
    import subprocess

    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="python", timeout=5)

        with pytest.raises(subprocess.TimeoutExpired):
            subprocess.run(
                ["python", "-c", "import time; time.sleep(100)"],
                capture_output=True, text=True, timeout=5,
            )
