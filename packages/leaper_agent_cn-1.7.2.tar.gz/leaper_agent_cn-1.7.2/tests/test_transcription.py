"""Transcription 工具测试"""
import asyncio
import json
import os
import tempfile
import zipfile

import pytest

from src.tools.transcription import (
    parse_csv, parse_json, parse_text, parse_file, parse_docx, parse_xlsx,
    ParseFileTool,
)


@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


def test_parse_csv(tmp_dir):
    p = os.path.join(tmp_dir, "test.csv")
    with open(p, "w", encoding="utf-8") as f:
        f.write("名字,年龄\n张三,25\n李四,30\n")
    result = parse_csv(p)
    assert "张三" in result
    assert "年龄" in result


def test_parse_csv_empty(tmp_dir):
    p = os.path.join(tmp_dir, "empty.csv")
    with open(p, "w") as f:
        pass
    assert "空" in parse_csv(p)


def test_parse_csv_not_exist():
    assert "不存在" in parse_csv("/nonexistent/file.csv")


def test_parse_json(tmp_dir):
    p = os.path.join(tmp_dir, "test.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump({"key": "值", "num": 42}, f, ensure_ascii=False)
    result = parse_json(p)
    assert "值" in result
    assert "42" in result


def test_parse_json_invalid(tmp_dir):
    p = os.path.join(tmp_dir, "bad.json")
    with open(p, "w") as f:
        f.write("{invalid json")
    assert "错误" in parse_json(p)


def test_parse_text(tmp_dir):
    p = os.path.join(tmp_dir, "test.txt")
    with open(p, "w", encoding="utf-8") as f:
        f.write("Hello 你好世界")
    assert "你好" in parse_text(p)


def test_parse_text_not_exist():
    assert "不存在" in parse_text("/no/such/file.txt")


@pytest.mark.asyncio
async def test_parse_docx(tmp_dir):
    """创建一个简单的 docx（zip 格式）并解析"""
    p = os.path.join(tmp_dir, "test.docx")
    doc_xml = '''<?xml version="1.0" encoding="UTF-8"?>
    <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
      <w:body>
        <w:p><w:r><w:t>测试文档内容</w:t></w:r></w:p>
        <w:p><w:r><w:t>第二段落</w:t></w:r></w:p>
      </w:body>
    </w:document>'''
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("word/document.xml", doc_xml)
    result = await parse_docx(p)
    assert "测试文档内容" in result
    assert "第二段落" in result


@pytest.mark.asyncio
async def test_parse_docx_invalid(tmp_dir):
    p = os.path.join(tmp_dir, "bad.docx")
    with open(p, "w") as f:
        f.write("not a zip")
    result = await parse_docx(p)
    assert "错误" in result


@pytest.mark.asyncio
async def test_parse_xlsx(tmp_dir):
    """创建简单 xlsx 并解析"""
    p = os.path.join(tmp_dir, "test.xlsx")
    ss_xml = '''<?xml version="1.0" encoding="UTF-8"?>
    <sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="3">
      <si><t>姓名</t></si>
      <si><t>年龄</t></si>
      <si><t>张三</t></si>
    </sst>'''
    sheet_xml = '''<?xml version="1.0" encoding="UTF-8"?>
    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <sheetData>
        <row r="1">
          <c r="A1" t="s"><v>0</v></c>
          <c r="B1" t="s"><v>1</v></c>
        </row>
        <row r="2">
          <c r="A2" t="s"><v>2</v></c>
          <c r="B2"><v>25</v></c>
        </row>
      </sheetData>
    </worksheet>'''
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("xl/sharedStrings.xml", ss_xml)
        z.writestr("xl/worksheets/sheet1.xml", sheet_xml)
    result = await parse_xlsx(p)
    assert "姓名" in result
    assert "张三" in result
    assert "25" in result


@pytest.mark.asyncio
async def test_parse_file_image():
    result = await parse_file("test.png")
    assert "图片" in result


@pytest.mark.asyncio
async def test_parse_file_audio():
    result = await parse_file("test.mp3")
    assert "音频" in result


@pytest.mark.asyncio
async def test_parse_file_unsupported():
    result = await parse_file("test.xyz")
    assert "不支持" in result


@pytest.mark.asyncio
async def test_parse_file_tool(tmp_dir):
    p = os.path.join(tmp_dir, "test.txt")
    with open(p, "w") as f:
        f.write("tool test content")
    tool = ParseFileTool()
    assert tool.name == "parse_file"
    result = await tool.execute({"file_path": p})
    assert "tool test content" in result


@pytest.mark.asyncio
async def test_parse_file_tool_empty():
    tool = ParseFileTool()
    result = await tool.execute({})
    assert "错误" in result
