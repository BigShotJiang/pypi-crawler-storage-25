"""Tool Calling 端到端测试"""
import asyncio
import json
import pytest

from src.tools import get_all_tools, get_tools_dict
from src.tools.base import Tool
from src.agent.loop import AgentLoop
from src.providers.base import Response


# ── 1. tool_defs 格式验证 ──────────────────────────────────────────


def test_tool_defs_format():
    """验证所有工具都有完整的 name / description / parameters schema"""
    tools = get_all_tools()
    assert len(tools) >= 6, f"预期至少 6 个工具，实际 {len(tools)}"

    for t in tools:
        assert isinstance(t, Tool), f"{t} 不是 Tool 实例"
        assert isinstance(t.name, str) and t.name, f"name 不合法: {t.name}"
        assert isinstance(t.description, str) and t.description, f"description 不合法: {t}"
        params = t.parameters
        assert isinstance(params, dict), f"parameters 不是 dict: {t.name}"
        assert params.get("type") == "object", f"parameters.type != object: {t.name}"
        assert "properties" in params, f"缺少 properties: {t.name}"


def test_tool_defs_no_duplicate_names():
    """工具名不能重复"""
    tools = get_all_tools()
    names = [t.name for t in tools]
    assert len(names) == len(set(names)), f"重复工具名: {names}"


def test_get_tools_dict():
    """get_tools_dict 返回 {name: Tool} 映射"""
    d = get_tools_dict()
    assert isinstance(d, dict)
    for k, v in d.items():
        assert k == v.name
        assert isinstance(v, Tool)


# ── 2. 单工具调用 ──────────────────────────────────────────────────


class MockProvider:
    """可编程的 mock provider，按顺序返回预设 responses"""

    def __init__(self, responses: list[Response]):
        self._responses = list(responses)
        self._call_count = 0
        self.last_tools = None

    async def chat(self, messages, tools=None):
        self.last_tools = tools
        resp = self._responses[self._call_count]
        self._call_count += 1
        return resp


@pytest.mark.asyncio
async def test_tool_call_execution():
    """mock provider 返回 tool_call，验证 calculator 工具被调用并返回结果"""
    tool_call_response = Response(
        content=None,
        tool_calls=[{
            "id": "call_1",
            "function": {
                "name": "calculator",
                "arguments": json.dumps({"expression": "2 + 3"}),
            },
        }],
        finish_reason="tool_calls",
    )
    final_response = Response(content="结果是 5", tool_calls=None, finish_reason="stop")

    provider = MockProvider([tool_call_response, final_response])
    tools_dict = get_tools_dict()
    loop = AgentLoop(provider=provider, tools=tools_dict)

    result = await loop.chat("2 加 3 等于多少？")
    assert result == "结果是 5"
    assert provider._call_count == 2


@pytest.mark.asyncio
async def test_tool_result_format():
    """验证 tool result 以正确格式传回 provider（role=tool, tool_call_id）"""
    tool_call_response = Response(
        content=None,
        tool_calls=[{
            "id": "call_abc",
            "function": {
                "name": "calculator",
                "arguments": json.dumps({"expression": "10 * 5"}),
            },
        }],
        finish_reason="tool_calls",
    )
    final_response = Response(content="50", tool_calls=None, finish_reason="stop")

    provider = MockProvider([tool_call_response, final_response])
    tools_dict = get_tools_dict()
    loop = AgentLoop(provider=provider, tools=tools_dict)

    await loop.chat("10 乘 5")

    # 检查 history 中有 tool message
    tool_msgs = [m for m in loop._history if m["role"] == "tool"]
    assert len(tool_msgs) == 1
    assert tool_msgs[0]["tool_call_id"] == "call_abc"
    assert tool_msgs[0]["content"] == "50"


# ── 3. 多工具调用 ──────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_multi_tool_calls():
    """一次返回多个 tool_calls，全部被执行"""
    tool_call_response = Response(
        content=None,
        tool_calls=[
            {
                "id": "call_1",
                "function": {
                    "name": "calculator",
                    "arguments": json.dumps({"expression": "1 + 1"}),
                },
            },
            {
                "id": "call_2",
                "function": {
                    "name": "calculator",
                    "arguments": json.dumps({"expression": "2 * 3"}),
                },
            },
        ],
        finish_reason="tool_calls",
    )
    final_response = Response(content="2 和 6", tool_calls=None, finish_reason="stop")

    provider = MockProvider([tool_call_response, final_response])
    tools_dict = get_tools_dict()
    loop = AgentLoop(provider=provider, tools=tools_dict)

    result = await loop.chat("算两个")
    assert result == "2 和 6"

    tool_msgs = [m for m in loop._history if m["role"] == "tool"]
    assert len(tool_msgs) == 2
    assert tool_msgs[0]["content"] == "2"
    assert tool_msgs[1]["content"] == "6"


# ── 4. tool_defs 传递给 provider 格式正确 ─────────────────────────


@pytest.mark.asyncio
async def test_tool_defs_sent_to_provider():
    """验证传给 provider 的 tool_defs 包含完整 schema"""
    final_response = Response(content="hi", tool_calls=None, finish_reason="stop")
    provider = MockProvider([final_response])
    tools_dict = get_tools_dict()
    loop = AgentLoop(provider=provider, tools=tools_dict)

    await loop.chat("hello")

    # 检查 provider 收到的 tools
    assert provider.last_tools is not None
    for td in provider.last_tools:
        assert td["type"] == "function"
        func = td["function"]
        assert "name" in func
        assert "description" in func
        assert "parameters" in func
        assert func["parameters"]["type"] == "object"


# ── 5. 不存在的工具 ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_unknown_tool():
    """调用不存在的工具返回错误信息而不崩溃"""
    tool_call_response = Response(
        content=None,
        tool_calls=[{
            "id": "call_x",
            "function": {"name": "nonexistent", "arguments": "{}"},
        }],
        finish_reason="tool_calls",
    )
    final_response = Response(content="工具不存在", tool_calls=None, finish_reason="stop")

    provider = MockProvider([tool_call_response, final_response])
    tools_dict = get_tools_dict()
    loop = AgentLoop(provider=provider, tools=tools_dict)

    result = await loop.chat("用个不存在的工具")
    assert "不存在" in result or provider._call_count == 2

    tool_msgs = [m for m in loop._history if m["role"] == "tool"]
    assert len(tool_msgs) == 1
    assert "不存在" in tool_msgs[0]["content"]
