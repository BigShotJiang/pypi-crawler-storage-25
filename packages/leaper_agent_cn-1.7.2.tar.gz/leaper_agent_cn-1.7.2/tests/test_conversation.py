"""ConversationManager 测试"""

import json
import os
import tempfile
import pytest
from src.agent.conversation import ConversationManager


class TestConversationManager:
    """对话管理器测试"""

    def test_init(self):
        cm = ConversationManager(max_turns=50)
        assert cm.messages == []
        assert cm.max_turns == 50

    def test_add_message(self):
        cm = ConversationManager()
        cm.add_message("user", "你好")
        cm.add_message("assistant", "你好！")
        msgs = cm.get_messages()
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"
        assert msgs[1]["content"] == "你好！"

    def test_add_tool_call(self):
        cm = ConversationManager()
        cm.add_tool_call("search", {"q": "test"}, "结果")
        msgs = cm.get_messages()
        assert len(msgs) == 2
        assert msgs[0]["role"] == "assistant"
        assert msgs[1]["role"] == "tool"
        assert msgs[1]["name"] == "search"

    def test_get_last_n(self):
        cm = ConversationManager()
        for i in range(10):
            cm.add_message("user", f"msg-{i}")
        last3 = cm.get_last_n(3)
        assert len(last3) == 3
        assert last3[0]["content"] == "msg-7"

    def test_clear(self):
        cm = ConversationManager()
        cm.add_message("user", "hi")
        cm.clear()
        assert cm.messages == []

    def test_count_tokens(self):
        cm = ConversationManager()
        cm.add_message("user", "一二三四五六七八")
        tokens = cm.count_tokens()
        assert tokens > 0

    def test_trim_to_tokens(self):
        cm = ConversationManager()
        cm.add_message("system", "sys")
        for i in range(20):
            cm.add_message("user", "x" * 100)
        removed = cm.trim_to_tokens(200)
        assert removed > 0
        assert cm.count_tokens() <= 200

    def test_get_messages_with_max_tokens(self):
        cm = ConversationManager()
        cm.add_message("system", "you are helpful")
        for i in range(10):
            cm.add_message("user", f"message {i} " * 20)
        msgs = cm.get_messages(max_tokens=100)
        # 应该包含 system + 部分消息
        assert any(m["role"] == "system" for m in msgs)
        assert len(msgs) < 11

    def test_get_summary(self):
        cm = ConversationManager()
        cm.add_message("user", "hi")
        cm.add_message("assistant", "hello")
        summary = cm.get_summary()
        assert "2" in summary
        assert "user" in summary

    def test_save_load(self):
        cm = ConversationManager()
        cm.add_message("user", "保存测试")
        cm.add_message("assistant", "OK")

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            path = f.name
        try:
            cm.save(path)
            cm2 = ConversationManager()
            cm2.load(path)
            msgs = cm2.get_messages()
            assert len(msgs) == 2
            assert msgs[0]["content"] == "保存测试"
        finally:
            os.unlink(path)

    def test_internal_fields_stripped(self):
        cm = ConversationManager()
        cm.add_message("user", "test")
        msgs = cm.get_messages()
        assert "_ts" not in msgs[0]

    def test_max_turns_enforcement(self):
        cm = ConversationManager(max_turns=5)
        for i in range(20):
            cm.add_message("user", f"u-{i}")
            cm.add_message("assistant", f"a-{i}")
        non_sys = [m for m in cm.messages if m.get("role") != "system"]
        assert len(non_sys) <= 10  # 5 turns * 2
