"""高级功能测试 — Vision / Voice / Image Gen / Multi-Agent / Profile / Scheduler 增强"""

import asyncio
import base64
import json
import os
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ═══════════════════════════════════════════
# Vision 测试
# ═══════════════════════════════════════════

class TestVision:
    """Vision 工具测试"""

    def test_is_url_http(self):
        from src.tools.vision import is_url
        assert is_url("https://example.com/image.png") is True
        assert is_url("http://example.com/img.jpg") is True

    def test_is_url_not_url(self):
        from src.tools.vision import is_url
        assert is_url("iVBORw0KGgo=") is False
        assert is_url("data:image/png;base64,abc") is False

    def test_is_base64_valid(self):
        from src.tools.vision import is_base64
        # 至少 20 字符的合法 base64
        data = base64.b64encode(b"x" * 20).decode()
        assert is_base64(data) is True

    def test_is_base64_with_data_uri(self):
        from src.tools.vision import is_base64
        data = base64.b64encode(b"x" * 20).decode()
        assert is_base64(f"data:image/png;base64,{data}") is True

    def test_build_image_url_from_url(self):
        from src.tools.vision import build_image_url
        url = "https://example.com/img.png"
        assert build_image_url(url) == url

    def test_build_image_url_from_base64(self):
        from src.tools.vision import build_image_url
        data = base64.b64encode(b"fakepng").decode()
        result = build_image_url(data)
        assert result.startswith("data:image/png;base64,")

    def test_build_vision_messages(self):
        from src.tools.vision import build_vision_messages
        msgs = build_vision_messages("https://example.com/img.png", "描述图片")
        assert len(msgs) == 1
        assert msgs[0]["role"] == "user"
        content = msgs[0]["content"]
        assert len(content) == 2
        assert content[0]["type"] == "image_url"
        assert content[1]["type"] == "text"
        assert content[1]["text"] == "描述图片"

    @pytest.mark.asyncio
    async def test_analyze_image_no_provider(self):
        from src.tools.vision import analyze_image
        result = await analyze_image("https://example.com/img.png")
        assert "未提供" in result

    def test_vision_tools_schema(self):
        from src.tools.vision import VISION_TOOLS
        assert len(VISION_TOOLS) == 2
        names = {t["function"]["name"] for t in VISION_TOOLS}
        assert "analyze_image" in names
        assert "ocr_image" in names


# ═══════════════════════════════════════════
# Voice 测试
# ═══════════════════════════════════════════

class TestVoice:
    """Voice 工具测试"""

    def test_supported_voices(self):
        from src.tools.voice import SUPPORTED_VOICES, DEFAULT_VOICE
        assert DEFAULT_VOICE in SUPPORTED_VOICES
        assert len(SUPPORTED_VOICES) >= 3

    def test_escape_xml(self):
        from src.tools.voice import _escape_xml
        assert _escape_xml("<b>test</b>") == "&lt;b&gt;test&lt;/b&gt;"
        assert _escape_xml("A & B") == "A &amp; B"

    def test_build_ssml_message(self):
        from src.tools.voice import _build_ssml_message
        msg = _build_ssml_message("你好", "zh-CN-XiaoxiaoNeural")
        assert "zh-CN-XiaoxiaoNeural" in msg
        assert "你好" in msg
        assert "ssml" in msg.lower()

    def test_build_config_message(self):
        from src.tools.voice import _build_config_message
        msg = _build_config_message("zh-CN-XiaoxiaoNeural")
        assert "speech.config" in msg
        assert "audio-24khz" in msg

    def test_extract_audio_from_binary(self):
        from src.tools.voice import _extract_audio_from_binary
        import struct
        header = b"some-header"
        audio = b"audio-data-here"
        frame = struct.pack(">H", len(header)) + header + audio
        result = _extract_audio_from_binary(frame)
        assert result == audio

    def test_extract_audio_empty(self):
        from src.tools.voice import _extract_audio_from_binary
        assert _extract_audio_from_binary(b"") == b""

    @pytest.mark.asyncio
    async def test_tts_invalid_voice(self):
        from src.tools.voice import text_to_speech
        with pytest.raises(ValueError, match="不支持的声音"):
            await text_to_speech("你好", voice="invalid-voice")

    @pytest.mark.asyncio
    async def test_tts_empty_text(self):
        from src.tools.voice import text_to_speech
        with pytest.raises(ValueError, match="不能为空"):
            await text_to_speech("", voice="zh-CN-XiaoxiaoNeural")

    @pytest.mark.asyncio
    async def test_stt_placeholder(self):
        from src.tools.voice import speech_to_text
        result = await speech_to_text("/tmp/audio.wav")
        assert "需要配置" in result

    def test_voice_tools_schema(self):
        from src.tools.voice import VOICE_TOOLS
        assert len(VOICE_TOOLS) == 1
        assert VOICE_TOOLS[0]["function"]["name"] == "text_to_speech"


# ═══════════════════════════════════════════
# Image Gen 测试
# ═══════════════════════════════════════════

class TestImageGen:
    """Image Generation 工具测试"""

    def test_providers_defined(self):
        from src.tools.image_gen import PROVIDERS
        assert "zhipu" in PROVIDERS
        assert "dashscope" in PROVIDERS

    def test_get_available_provider_none(self):
        from src.tools.image_gen import get_available_provider
        # 清除环境变量
        with patch.dict(os.environ, {}, clear=True):
            assert get_available_provider() is None

    def test_get_available_provider_zhipu(self):
        from src.tools.image_gen import get_available_provider
        with patch.dict(os.environ, {"ZHIPU_API_KEY": "test-key"}):
            assert get_available_provider() == "zhipu"

    def test_build_zhipu_request(self):
        from src.tools.image_gen import build_zhipu_request
        with patch.dict(os.environ, {"ZHIPU_API_KEY": "test-key"}):
            url, headers, body = build_zhipu_request("一只猫", "1024x1024")
            assert "bigmodel.cn" in url
            assert "Bearer test-key" in headers["Authorization"]
            assert body["prompt"] == "一只猫"

    def test_build_dashscope_request(self):
        from src.tools.image_gen import build_dashscope_request
        with patch.dict(os.environ, {"DASHSCOPE_API_KEY": "ds-key"}):
            url, headers, body = build_dashscope_request("一只猫", "1024x1024")
            assert "dashscope" in url
            assert body["input"]["prompt"] == "一只猫"
            # 通义万相用 * 分隔
            assert body["parameters"]["size"] == "1024*1024"

    @pytest.mark.asyncio
    async def test_generate_image_no_key(self):
        from src.tools.image_gen import generate_image
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="未检测到"):
                await generate_image("一只猫", provider="auto")

    def test_image_gen_tools_schema(self):
        from src.tools.image_gen import IMAGE_GEN_TOOLS
        assert len(IMAGE_GEN_TOOLS) == 1
        assert IMAGE_GEN_TOOLS[0]["function"]["name"] == "generate_image"


# ═══════════════════════════════════════════
# Multi-Agent 测试
# ═══════════════════════════════════════════

class TestMultiAgent:
    """Multi-Agent 编排器测试"""

    def _make_agents(self):
        from src.agent.multi_agent import AgentConfig

        async def echo_cto(msg):
            return f"[CTO] {msg}"

        async def echo_cpo(msg):
            return f"[CPO] {msg}"

        return {
            "cto": AgentConfig(
                name="cto", role="CTO",
                keywords=["架构", "技术", "代码"],
                chat_fn=echo_cto,
            ),
            "cpo": AgentConfig(
                name="cpo", role="CPO",
                keywords=["产品", "需求", "用户"],
                chat_fn=echo_cpo,
            ),
        }

    def test_keyword_match(self):
        from src.agent.multi_agent import MultiAgentOrchestrator
        agents = self._make_agents()
        orch = MultiAgentOrchestrator(agents=agents)
        assert orch._keyword_match("我们讨论一下架构设计") == "cto"
        assert orch._keyword_match("用户需求分析") == "cpo"
        assert orch._keyword_match("天气怎么样") is None

    @pytest.mark.asyncio
    async def test_route_by_keyword(self):
        from src.agent.multi_agent import MultiAgentOrchestrator
        agents = self._make_agents()
        orch = MultiAgentOrchestrator(agents=agents)
        result = await orch.route_message("讨论技术方案")
        assert result.agent_name == "cto"
        assert "[CTO]" in result.response
        assert result.method == "keyword"

    @pytest.mark.asyncio
    async def test_route_default(self):
        from src.agent.multi_agent import MultiAgentOrchestrator
        agents = self._make_agents()
        orch = MultiAgentOrchestrator(agents=agents, default_agent="cpo")
        result = await orch.route_message("今天心情不错")  # 无关键词
        assert result.agent_name == "cpo"
        assert result.method == "default"

    @pytest.mark.asyncio
    async def test_broadcast(self):
        from src.agent.multi_agent import MultiAgentOrchestrator
        agents = self._make_agents()
        orch = MultiAgentOrchestrator(agents=agents)
        results = await orch.broadcast("大家好")
        assert "cto" in results
        assert "cpo" in results
        assert "[CTO]" in results["cto"]
        assert "[CPO]" in results["cpo"]

    @pytest.mark.asyncio
    async def test_chain(self):
        from src.agent.multi_agent import MultiAgentOrchestrator
        agents = self._make_agents()
        orch = MultiAgentOrchestrator(agents=agents)
        result = await orch.chain("初始消息", ["cto", "cpo"])
        # cto 先处理，然后 cpo 处理 cto 的输出
        assert "[CPO]" in result
        assert "[CTO]" in result

    @pytest.mark.asyncio
    async def test_debate(self):
        from src.agent.multi_agent import MultiAgentOrchestrator
        agents = self._make_agents()
        orch = MultiAgentOrchestrator(agents=agents)
        result = await orch.debate("微服务 vs 单体架构", rounds=1)
        assert "CTO" in result or "CPO" in result


# ═══════════════════════════════════════════
# Profile 测试
# ═══════════════════════════════════════════

class TestProfile:
    """Agent Profile 系统测试"""

    def test_parse_identity(self):
        from src.agent.profile import _parse_identity
        content = """# IDENTITY.md
- **Name:** Ray CTO
- **Role:** CTO
- **Emoji:** 💻
"""
        result = _parse_identity(content)
        assert result["Name"] == "Ray CTO"
        assert result["Role"] == "CTO"

    def test_load_profile_from_workspace(self):
        from src.agent.profile import load_profile
        with tempfile.TemporaryDirectory() as tmpdir:
            # 创建 SOUL.md
            Path(tmpdir, "SOUL.md").write_text("我是测试 Agent", encoding="utf-8")
            # 创建 IDENTITY.md
            Path(tmpdir, "IDENTITY.md").write_text(
                "- **Name:** test-agent\n- **Creature:** assistant\n",
                encoding="utf-8",
            )
            profile = load_profile(tmpdir)
            assert profile.name == "test-agent"
            assert "测试 Agent" in profile.soul

    def test_save_and_load_profile(self):
        from src.agent.profile import AgentProfile, save_profile, load_profile
        with tempfile.TemporaryDirectory() as tmpdir:
            profile = AgentProfile(
                name="my-cto",
                role="CTO",
                model="deepseek-chat",
                keywords=["架构", "技术"],
            )
            save_profile(profile, tmpdir)
            # 验证文件存在
            assert (Path(tmpdir) / "agent.yaml").exists()

    def test_build_profile_from_config(self):
        from src.agent.profile import build_profile_from_config
        profile = build_profile_from_config(
            "test",
            {"role": "CTO", "model": "qwen", "keywords": ["tech"]},
        )
        assert profile.name == "test"
        assert profile.role == "CTO"
        assert profile.brain_namespace == "agent/test"

    def test_profile_auto_namespace(self):
        from src.agent.profile import load_profile
        with tempfile.TemporaryDirectory() as tmpdir:
            profile = load_profile(tmpdir)
            assert profile.brain_namespace.startswith("agent/")


# ═══════════════════════════════════════════
# Scheduler 增强测试
# ═══════════════════════════════════════════

class TestSchedulerEnhanced:
    """Scheduler 增强功能测试"""

    def test_add_interval_job(self):
        from src.scheduler.engine import Scheduler
        s = Scheduler()
        job = s.add_job("test", "30", "ping", schedule_type="interval")
        assert job.schedule_type == "interval"
        assert job.interval_minutes == 30
        assert job.next_run is not None

    def test_add_at_job(self):
        from src.scheduler.engine import Scheduler
        future = (datetime.now() + timedelta(hours=1)).isoformat()
        s = Scheduler()
        job = s.add_job("test", future, "ping", schedule_type="at")
        assert job.schedule_type == "at"
        assert job.at_time is not None

    def test_add_cron_job(self):
        from src.scheduler.engine import Scheduler
        s = Scheduler()
        job = s.add_job("test", "*/5 * * * *", "ping", schedule_type="cron")
        assert job.schedule_type == "cron"
        assert job.cron_expr == "*/5 * * * *"

    def test_get_job_runs_empty(self):
        from src.scheduler.engine import Scheduler
        s = Scheduler()
        assert s.get_job_runs("nonexistent") == []

    def test_persist_to_file(self):
        from src.scheduler.engine import Scheduler
        with tempfile.TemporaryDirectory() as tmpdir:
            s = Scheduler(persist_dir=tmpdir)
            s.add_job("test", "0 9 * * *", "hello", schedule_type="cron")
            # 验证文件已创建
            assert (Path(tmpdir) / "jobs.json").exists()

    def test_load_from_file(self):
        from src.scheduler.engine import Scheduler
        with tempfile.TemporaryDirectory() as tmpdir:
            s1 = Scheduler(persist_dir=tmpdir)
            s1.add_job("test", "0 9 * * *", "hello", schedule_type="cron")

            # 新 scheduler 加载
            s2 = Scheduler(persist_dir=tmpdir)
            s2._load_jobs()
            assert len(s2.list_jobs()) == 1
            assert s2.list_jobs()[0].name == "test"

    def test_job_run_dataclass(self):
        from src.scheduler.engine import JobRun
        run = JobRun(job_id="j1", run_id="r1", started_at="2024-01-01T00:00:00")
        d = run.to_dict()
        assert d["job_id"] == "j1"
        restored = JobRun.from_dict(d)
        assert restored.job_id == "j1"

    def test_cron_parse_range_step(self):
        from src.scheduler.engine import _parse_cron_field
        result = _parse_cron_field("1-10/3", 0, 59)
        assert result == {1, 4, 7, 10}

    def test_remove_job(self):
        from src.scheduler.engine import Scheduler
        s = Scheduler()
        job = s.add_job("test", "0 9 * * *", "hello", schedule_type="cron")
        assert s.remove_job(job.id) is True
        assert len(s.list_jobs()) == 0
        assert s.remove_job("nonexistent") is False
