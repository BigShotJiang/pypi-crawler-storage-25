"""Memory Tool 测试"""
import pytest

from src.tools.memory_tool import (
    MemoryStore, RememberTool, RecallTool, ForgetTool,
    MemoryStatsTool, ListMemoriesTool, get_memory_store,
)


@pytest.fixture
def store():
    return MemoryStore()


def test_store_add(store):
    e = store.add("测试内容", "test")
    assert e.content == "测试内容"
    assert e.category == "test"
    assert len(e.id) == 12


def test_store_search(store):
    store.add("Python 编程技巧", "tech")
    store.add("今天天气不错", "daily")
    results = store.search("Python")
    assert len(results) >= 1
    assert "Python" in results[0].content


def test_store_search_no_match(store):
    store.add("hello world", "test")
    results = store.search("完全不相关的内容xyz")
    assert len(results) == 0


def test_store_delete(store):
    e = store.add("删除测试", "test")
    assert store.delete(e.id) is True
    assert store.delete(e.id) is False  # 已删除


def test_store_list(store):
    store.add("a", "cat1")
    store.add("b", "cat2")
    store.add("c", "cat1")
    all_items = store.list()
    assert len(all_items) == 3
    cat1_items = store.list(category="cat1")
    assert len(cat1_items) == 2


def test_store_stats(store):
    store.add("x", "a")
    store.add("y", "b")
    store.add("z", "a")
    stats = store.stats()
    assert stats["total"] == 3
    assert stats["categories"]["a"] == 2


@pytest.mark.asyncio
async def test_remember_tool():
    tool = RememberTool()
    result = await tool.execute({"content": "记住这个", "category": "test"})
    assert "已记住" in result


@pytest.mark.asyncio
async def test_remember_tool_empty():
    tool = RememberTool()
    result = await tool.execute({"content": ""})
    assert "错误" in result


@pytest.mark.asyncio
async def test_recall_tool():
    store = get_memory_store()
    store.add("Python 是最好的语言", "tech")
    tool = RecallTool()
    result = await tool.execute({"query": "Python"})
    assert "Python" in result


@pytest.mark.asyncio
async def test_forget_tool():
    store = get_memory_store()
    e = store.add("临时数据", "tmp")
    tool = ForgetTool()
    result = await tool.execute({"memory_id": e.id})
    assert "已删除" in result


@pytest.mark.asyncio
async def test_forget_tool_not_found():
    tool = ForgetTool()
    result = await tool.execute({"memory_id": "nonexistent"})
    assert "未找到" in result


@pytest.mark.asyncio
async def test_memory_stats_tool():
    tool = MemoryStatsTool()
    result = await tool.execute({})
    assert "统计" in result


@pytest.mark.asyncio
async def test_list_memories_tool():
    tool = ListMemoriesTool()
    result = await tool.execute({})
    # 可能有记忆也可能没有，不崩就行
    assert isinstance(result, str)
