"""OAuth 模块测试"""
import time
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from src.auth.oauth import OAuthManager, TokenInfo
from src.auth.wechat_oauth import WechatOAuth
from src.auth.feishu_oauth import FeishuOAuth
from src.auth.dingtalk_oauth import DingTalkOAuth


# ── TokenInfo 测试 ──

class TestTokenInfo:
    def test_not_expired(self):
        t = TokenInfo(access_token="abc", expires_at=time.time() + 3600)
        assert not t.is_expired

    def test_expired(self):
        t = TokenInfo(access_token="abc", expires_at=time.time() - 100)
        assert t.is_expired

    def test_zero_expires_never_expired(self):
        t = TokenInfo(access_token="abc", expires_at=0)
        assert not t.is_expired

    def test_extra_fields(self):
        t = TokenInfo(access_token="abc", provider="wechat",
                      extra={"openid": "123"})
        assert t.extra["openid"] == "123"
        assert t.provider == "wechat"


# ── OAuthManager 测试 ──

class TestOAuthManager:
    def test_register_and_list(self):
        mgr = OAuthManager()
        wechat = WechatOAuth("appid", "secret")
        mgr.register(wechat)
        assert "wechat" in mgr.providers

    def test_get_provider_not_found(self):
        mgr = OAuthManager()
        with pytest.raises(ValueError, match="未注册"):
            mgr.get_provider("nonexistent")

    def test_get_auth_url_wechat(self):
        mgr = OAuthManager()
        mgr.register(WechatOAuth("test_appid", "test_secret"))
        url = mgr.get_auth_url("wechat", "https://example.com/callback")
        assert "test_appid" in url
        assert "example.com" in url

    def test_is_token_expired(self):
        mgr = OAuthManager()
        expired = TokenInfo(access_token="x", expires_at=time.time() - 100)
        valid = TokenInfo(access_token="x", expires_at=time.time() + 3600)
        assert mgr.is_token_expired(expired)
        assert not mgr.is_token_expired(valid)

    def test_cached_token(self):
        mgr = OAuthManager()
        assert mgr.get_cached_token("wechat") is None


# ── WechatOAuth 测试 ──

class TestWechatOAuth:
    def test_provider_name(self):
        w = WechatOAuth("id", "secret")
        assert w.provider_name == "wechat"

    def test_auth_url_open_platform(self):
        w = WechatOAuth("myapp", "secret", is_mp=False)
        url = w.get_auth_url("https://cb.com/auth")
        assert "qrconnect" in url
        assert "snsapi_login" in url

    def test_auth_url_mp(self):
        w = WechatOAuth("myapp", "secret", is_mp=True)
        url = w.get_auth_url("https://cb.com/auth")
        assert "oauth2/authorize" in url
        assert "snsapi_userinfo" in url


# ── FeishuOAuth 测试 ──

class TestFeishuOAuth:
    def test_provider_name(self):
        f = FeishuOAuth("id", "secret")
        assert f.provider_name == "feishu"

    def test_auth_url(self):
        f = FeishuOAuth("myapp", "secret")
        url = f.get_auth_url("https://cb.com/auth", state="test")
        assert "myapp" in url
        assert "test" in url


# ── DingTalkOAuth 测试 ──

class TestDingTalkOAuth:
    def test_provider_name(self):
        d = DingTalkOAuth("key", "secret")
        assert d.provider_name == "dingtalk"

    def test_auth_url(self):
        d = DingTalkOAuth("mykey", "secret")
        url = d.get_auth_url("https://cb.com/auth")
        assert "mykey" in url
        assert "openid" in url

    def test_multiple_providers(self):
        """测试 OAuthManager 注册多个 provider"""
        mgr = OAuthManager()
        mgr.register(WechatOAuth("w", "s"))
        mgr.register(FeishuOAuth("f", "s"))
        mgr.register(DingTalkOAuth("d", "s"))
        assert sorted(mgr.providers) == ["dingtalk", "feishu", "wechat"]
