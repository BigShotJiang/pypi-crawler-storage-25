"""测试 AgentLoop 核心对话循环"""

import pytest
import asyncio
from unittest.mock import AsyncMock, patch, MagicMock
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from agent.loop import AgentLoop


@pytest.mark.asyncio
async def test_simple_chat(mock_provider, mock_brain):
    """测试简单对话（无工具调用）"""
    mock_provider.chat = AsyncMock(return_value={"content": "你好，有什么可以帮你？", "tool_calls": None})

    loop = AgentLoop(provider=mock_provider, brain=mock_brain, system_prompt="你是助手")
    result = await loop.chat("你好")

    assert result == "你好，有什么可以帮你？"
    mock_provider.chat.assert_called_once()


@pytest.mark.asyncio
async def test_with_tool_calls(mock_provider, mock_brain):
    """测试一轮工具调用"""
    # 第一次返回 tool_call，第二次返回文本
    mock_provider.chat = AsyncMock(side_effect=[
        {
            "content": None,
            "tool_calls": [{
                "id": "call_1",
                "function": {"name": "search", "arguments": {"query": "天气"}},
            }]
        },
        {"content": "今天天气晴朗", "tool_calls": None},
    ])

    def mock_search(query=""):
        return f"搜索结果: {query}"

    loop = AgentLoop(
        provider=mock_provider,
        brain=mock_brain,
        tools={"search": mock_search},
    )
    result = await loop.chat("今天天气怎么样？")

    assert result == "今天天气晴朗"
    assert mock_provider.chat.call_count == 2


@pytest.mark.asyncio
async def test_multi_turn_tools(mock_provider, mock_brain):
    """测试多轮工具调用"""
    mock_provider.chat = AsyncMock(side_effect=[
        {
            "content": None,
            "tool_calls": [{"id": "call_1", "function": {"name": "search", "arguments": {"query": "北京天气"}}}]
        },
        {
            "content": None,
            "tool_calls": [{"id": "call_2", "function": {"name": "calc", "arguments": {"expr": "20+5"}}}]
        },
        {"content": "北京今天25度", "tool_calls": None},
    ])

    loop = AgentLoop(
        provider=mock_provider,
        brain=mock_brain,
        tools={
            "search": lambda query="": f"结果:{query}",
            "calc": lambda expr="": str(eval(expr)),
        },
    )
    result = await loop.chat("北京天气多少度？")

    assert result == "北京今天25度"
    assert mock_provider.chat.call_count == 3


@pytest.mark.asyncio
async def test_memory_recall_injection(mock_provider, mock_brain):
    """测试记忆注入"""
    mock_brain.recall = AsyncMock(return_value=[
        {"content": "用户偏好：简洁回答"},
        {"content": "用户名字：Ray"},
    ])
    mock_provider.chat = AsyncMock(return_value={"content": "好的Ray", "tool_calls": None})

    loop = AgentLoop(provider=mock_provider, brain=mock_brain)
    result = await loop.chat("你好")

    # 验证记忆被 recall（onboarding 也会调一次 recall）
    assert any(
        call.args == ("你好",)
        for call in mock_brain.recall.call_args_list
    )
    # 验证 provider 收到包含记忆的 messages
    call_args = mock_provider.chat.call_args
    messages = call_args[0][0]
    memory_msg = [m for m in messages if m.content and "相关记忆" in m.content]
    assert len(memory_msg) == 1
    assert "用户偏好" in memory_msg[0].content


@pytest.mark.asyncio
async def test_background_extract(mock_provider, mock_brain):
    """测试异步提取不阻塞主流程"""
    extract_called = asyncio.Event()

    async def slow_extract(user_msg, reply, user_id="default"):
        await asyncio.sleep(0.1)
        extract_called.set()

    mock_brain.extract_and_learn = slow_extract
    mock_provider.chat = AsyncMock(return_value={"content": "回复", "tool_calls": None})

    loop = AgentLoop(provider=mock_provider, brain=mock_brain)
    result = await loop.chat("测试")

    # 回复应该立即返回，不等待 extract
    assert result == "回复"

    # 等待后台任务完成
    await asyncio.sleep(0.3)
    assert extract_called.is_set()
