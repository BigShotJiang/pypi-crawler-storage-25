"""Skill Advanced 测试 — Preprocessing / Utils / Auxiliary / File Safety"""
import os
import tempfile
from unittest.mock import AsyncMock, patch

import pytest

from src.skills.preprocessing import SkillPreprocessor
from src.skills.utils import parse_skill_md, match_skill, format_skill_for_prompt
from src.agent.auxiliary import AuxiliaryClient
from src.security.file_safety import is_safe_to_read, is_safe_to_write, is_safe_to_delete


# ── Preprocessing ──

@pytest.fixture
def preprocessor():
    return SkillPreprocessor()


def test_variable_replacement(preprocessor):
    result = preprocessor.preprocess("Hello {{user}}", {"user": "Ray"})
    assert "Ray" in result


def test_builtin_date_variable(preprocessor):
    result = preprocessor.preprocess("Today is {{date}}", {})
    assert "20" in result  # 年份


def test_unknown_variable_kept(preprocessor):
    result = preprocessor.preprocess("{{unknown_var}}", {})
    assert "{{unknown_var}}" in result


def test_condition_true(preprocessor):
    result = preprocessor.preprocess(
        "Before {{#if show}}VISIBLE{{/if}} After",
        {"show": "true"}
    )
    assert "VISIBLE" in result


def test_condition_false(preprocessor):
    result = preprocessor.preprocess(
        "Before {{#if show}}HIDDEN{{/if}} After",
        {"show": "false"}
    )
    assert "HIDDEN" not in result


def test_file_reference_expand(preprocessor):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("referenced content")
        f.flush()
        result = preprocessor.preprocess(f"See: {{{{@file:{f.name}}}}}", {})
    assert "referenced content" in result
    os.unlink(f.name)


def test_extract_references(preprocessor):
    refs = preprocessor.extract_references("Use {{@file:a.md}} and {{@file:b.txt}}")
    assert len(refs) == 2


def test_validate_references(preprocessor):
    missing = preprocessor.validate_references(["nonexistent.md"], "/tmp")
    assert "nonexistent.md" in missing


def test_truncation(preprocessor):
    pp = SkillPreprocessor(max_length=100)
    result = pp.preprocess("x" * 200, {})
    assert "截断" in result


# ── Skill Utils ──

def test_parse_skill_md():
    content = """# My Skill
This is a description of the skill.

Triggers: hello, 你好, greet
Location: /path/to/skill
"""
    result = parse_skill_md(content)
    assert result["name"] == "My Skill"
    assert "description" in result["description"].lower() or len(result["description"]) > 0
    assert "hello" in result["triggers"]


def test_match_skill():
    skills = [
        {"name": "weather", "description": "get weather info", "triggers": "天气, weather"},
        {"name": "search", "description": "search the web", "triggers": "搜索, search"},
    ]
    result = match_skill("今天天气怎么样", skills)
    assert result is not None
    assert result["name"] == "weather"


def test_match_skill_no_match():
    skills = [{"name": "a", "description": "b", "triggers": "c"}]
    result = match_skill("完全不相关xyz", skills)
    # 可能 None 或低分匹配
    # 不强制 None，只要不崩


def test_match_skill_empty():
    assert match_skill("hello", []) is None
    assert match_skill("", [{"name": "a"}]) is None


def test_format_skill():
    skill = {"name": "Test", "description": "A test skill", "triggers": "test"}
    result = format_skill_for_prompt(skill)
    assert "Test" in result
    assert "test" in result


# ── Auxiliary Client ──

@pytest.mark.asyncio
async def test_auxiliary_summarize_empty():
    client = AuxiliaryClient()
    result = await client.summarize("")
    assert result == ""


@pytest.mark.asyncio
async def test_auxiliary_classify_empty():
    client = AuxiliaryClient()
    result = await client.classify("", ["a", "b"])
    assert result == ""


@pytest.mark.asyncio
async def test_auxiliary_keywords_empty():
    client = AuxiliaryClient()
    result = await client.extract_keywords("")
    assert result == []


@pytest.mark.asyncio
async def test_auxiliary_translate_empty():
    client = AuxiliaryClient()
    result = await client.translate("")
    assert result == ""


@pytest.mark.asyncio
async def test_auxiliary_review_empty():
    client = AuxiliaryClient()
    result = await client.review_response("", "ctx")
    assert "空" in result


# ── File Safety ──

def test_safe_read_nonexistent():
    ok, msg = is_safe_to_read("/nonexistent/file.txt", "/workspace")
    assert ok is False


def test_safe_read_binary():
    with tempfile.NamedTemporaryFile(suffix=".exe", delete=False) as f:
        f.write(b"MZ")
        f.flush()
        ok, msg = is_safe_to_read(f.name, "")
    assert ok is False
    assert "二进制" in msg
    os.unlink(f.name)


def test_safe_write_system_dir():
    ok, msg = is_safe_to_write("C:\\Windows\\test.txt", "/workspace")
    assert ok is False


def test_safe_write_protected():
    ok, msg = is_safe_to_write("/workspace/SOUL.md", "/workspace")
    assert ok is True  # 允许但有警告
    assert "注意" in msg or "安全" in msg


def test_safe_write_normal():
    ok, msg = is_safe_to_write("/workspace/output.txt", "/workspace")
    assert ok is True


def test_safe_delete_outside_workspace():
    ok, msg = is_safe_to_delete("/etc/passwd", "/workspace")
    assert ok is False


def test_safe_delete_protected_file():
    ok, msg = is_safe_to_delete("/workspace/MEMORY.md", "/workspace")
    assert ok is False
    assert "关键文件" in msg


def test_safe_delete_normal():
    with tempfile.NamedTemporaryFile(delete=False, dir=tempfile.gettempdir()) as f:
        ok, msg = is_safe_to_delete(f.name, tempfile.gettempdir())
    assert ok is True
    os.unlink(f.name)
