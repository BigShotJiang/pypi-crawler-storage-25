"""
测试 Agent Core 路线 D 增强模块

覆盖：ContextEngine, Insights, Delegate, ModelMeta, CredentialPool, Session persistence
"""

from __future__ import annotations

import asyncio
import json
import os
import pytest
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

# 被测模块
from src.agent.context_engine import ContextEngine as CtxEngine
from src.agent.insights import (
    analyze_conversation,
    detect_loop,
    suggest_improvements,
    ConversationInsights,
)
from src.agent.delegate import DelegateManager, DelegateConfig, SubAgentStatus
from src.agent.model_meta import (
    get_model_info,
    get_max_tokens,
    supports_tools,
    supports_vision,
    list_models,
)
from src.agent.credential_pool import CredentialPool, AllCredentialsExhausted
from src.agent.session import (
    save_session,
    load_session,
    list_sessions,
    delete_session,
)


# ============================================================
# Context Engine 测试
# ============================================================

class TestContextEngine:
    def test_inject_workspace_with_md_files(self, tmp_path):
        """workspace 注入：扫描 .md 文件"""
        (tmp_path / "README.md").write_text("# Hello", encoding="utf-8")
        (tmp_path / "NOTES.md").write_text("some notes", encoding="utf-8")
        (tmp_path / "data.json").write_text("{}", encoding="utf-8")  # 不应被注入

        engine = CtxEngine()
        result = engine.inject_workspace(str(tmp_path))

        assert "README.md" in result
        assert "Hello" in result
        assert "NOTES.md" in result
        assert "data.json" not in result

    def test_inject_workspace_empty_dir(self, tmp_path):
        """空目录容错"""
        engine = CtxEngine()
        result = engine.inject_workspace(str(tmp_path))
        assert result == ""

    def test_inject_workspace_nonexistent_dir(self):
        """不存在的目录容错"""
        engine = CtxEngine()
        result = engine.inject_workspace("/nonexistent/path/xyz")
        assert result == ""

    def test_inject_workspace_file_truncation(self, tmp_path):
        """单文件超长截断"""
        (tmp_path / "big.md").write_text("x" * 5000, encoding="utf-8")
        engine = CtxEngine(file_max_chars=100)
        result = engine.inject_workspace(str(tmp_path))
        assert "截断" in result
        assert len(result) < 5000

    @pytest.mark.asyncio
    async def test_inject_brain_recall(self):
        """brain recall 注入"""
        brain = AsyncMock()
        brain.recall = AsyncMock(return_value=[
            {"content": "记忆 1"},
            {"content": "记忆 2"},
        ])
        engine = CtxEngine()
        result = await engine.inject_brain_recall(brain, "测试查询")
        assert "相关记忆" in result
        assert "记忆 1" in result

    @pytest.mark.asyncio
    async def test_inject_brain_recall_none_brain(self):
        """brain 为 None 时容错"""
        engine = CtxEngine()
        result = await engine.inject_brain_recall(None, "query")
        assert result == ""

    @pytest.mark.asyncio
    async def test_inject_brain_recall_empty_query(self):
        """空查询容错"""
        brain = AsyncMock()
        engine = CtxEngine()
        result = await engine.inject_brain_recall(brain, "")
        assert result == ""

    def test_inject_tool_results(self):
        """tool 结果注入"""
        results = [
            {"name": "search", "output": "搜索结果 ABC"},
            {"name": "read", "output": "文件内容 XYZ"},
        ]
        engine = CtxEngine()
        result = engine.inject_tool_results(results)
        assert "工具结果" in result
        assert "search" in result
        assert "ABC" in result

    def test_inject_tool_results_truncation(self):
        """tool 结果截断"""
        results = [{"name": "big", "output": "x" * 20000}]
        engine = CtxEngine(tool_max_chars=500)
        result = engine.inject_tool_results(results)
        assert len(result) <= 600  # 略大于 max 因为有标题

    def test_inject_tool_results_empty(self):
        """空 tool 结果"""
        engine = CtxEngine()
        assert engine.inject_tool_results([]) == ""
        assert engine.inject_tool_results(None) == ""

    @pytest.mark.asyncio
    async def test_build_context(self, tmp_path):
        """完整 build_context"""
        (tmp_path / "README.md").write_text("# Project", encoding="utf-8")
        brain = AsyncMock()
        brain.recall = AsyncMock(return_value=[{"content": "memory"}])

        engine = CtxEngine()
        result = await engine.build_context(
            workspace_dir=str(tmp_path),
            brain=brain,
            query="test",
            tool_results=[{"name": "tool1", "output": "out1"}],
        )
        assert "Project" in result
        assert "memory" in result
        assert "tool1" in result


# ============================================================
# Insights 测试
# ============================================================

class TestInsights:
    def test_analyze_empty_history(self):
        """空历史分析"""
        insights = analyze_conversation([])
        assert insights.total_turns == 0
        assert insights.avg_response_length == 0.0

    def test_analyze_normal_conversation(self):
        """正常对话分析"""
        history = [
            {"role": "user", "content": "你好"},
            {"role": "assistant", "content": "你好！有什么可以帮你？"},
            {"role": "user", "content": "帮我写代码"},
            {"role": "assistant", "content": "好的，什么样的代码？"},
        ]
        insights = analyze_conversation(history)
        assert insights.total_turns == 2
        assert insights.user_message_count == 2
        assert insights.assistant_message_count == 2
        assert insights.avg_response_length > 0

    def test_detect_loop_no_loop(self):
        """无循环场景"""
        history = [
            {"role": "assistant", "content": "", "tool_calls": [
                {"function": {"name": "search", "arguments": '{"q": "a"}'}}
            ]},
            {"role": "assistant", "content": "", "tool_calls": [
                {"function": {"name": "read", "arguments": '{"f": "b"}'}}
            ]},
        ]
        assert detect_loop(history) is False

    def test_detect_loop_with_loop(self):
        """检测到循环"""
        tc = {"function": {"name": "search", "arguments": '{"q": "same"}'}}
        history = [
            {"role": "assistant", "content": "", "tool_calls": [tc]},
            {"role": "assistant", "content": "", "tool_calls": [tc]},
            {"role": "assistant", "content": "", "tool_calls": [tc]},
        ]
        assert detect_loop(history) is True

    def test_suggest_improvements_loop(self):
        """循环时的建议"""
        insights = ConversationInsights(loop_detected=True)
        suggestions = suggest_improvements(insights)
        assert any("循环" in s for s in suggestions)

    def test_suggest_improvements_healthy(self):
        """健康对话的建议"""
        insights = ConversationInsights(
            total_turns=5, avg_response_length=200,
            tool_usage_count=3, error_count=0,
        )
        suggestions = suggest_improvements(insights)
        assert any("良好" in s for s in suggestions)


# ============================================================
# Delegate 测试
# ============================================================

class TestDelegate:
    @pytest.mark.asyncio
    async def test_spawn_and_wait(self):
        """spawn + wait 正常流程"""
        async def mock_fn(task, config):
            return f"完成: {task}"

        mgr = DelegateManager(subagent_fn=mock_fn)
        handle = await mgr.spawn_subagent("测试任务")
        result = await mgr.wait_for_result(handle, timeout=5)
        assert "完成" in result
        assert handle.status == SubAgentStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_spawn_timeout(self):
        """超时测试"""
        async def slow_fn(task, config):
            await asyncio.sleep(100)
            return "done"

        mgr = DelegateManager(subagent_fn=slow_fn)
        handle = await mgr.spawn_subagent("慢任务", DelegateConfig(timeout=0.1))
        with pytest.raises((TimeoutError, RuntimeError)):
            await mgr.wait_for_result(handle, timeout=2)

    @pytest.mark.asyncio
    async def test_cancel(self):
        """取消测试"""
        async def slow_fn(task, config):
            await asyncio.sleep(100)
            return "done"

        mgr = DelegateManager(subagent_fn=slow_fn)
        handle = await mgr.spawn_subagent("长任务", DelegateConfig(timeout=100))
        await asyncio.sleep(0.05)
        await mgr.cancel(handle)
        # 等一小段时间让取消生效
        await asyncio.sleep(0.1)
        assert handle.status in (SubAgentStatus.CANCELLED, SubAgentStatus.RUNNING)

    @pytest.mark.asyncio
    async def test_max_concurrent(self):
        """并发上限"""
        async def slow_fn(task, config):
            await asyncio.sleep(10)
            return "done"

        mgr = DelegateManager(subagent_fn=slow_fn, max_concurrent=1)
        await mgr.spawn_subagent("任务1", DelegateConfig(timeout=10))
        with pytest.raises(RuntimeError, match="上限"):
            await mgr.spawn_subagent("任务2")
        await mgr.cancel_all()


# ============================================================
# Model Meta 测试
# ============================================================

class TestModelMeta:
    def test_known_model(self):
        """已知模型查询"""
        info = get_model_info("deepseek-chat")
        assert info["max_tokens"] == 128000
        assert info["supports_tools"] is True

    def test_unknown_model_fallback(self):
        """未知模型返回默认值"""
        info = get_model_info("nonexistent-model")
        assert info["max_tokens"] == 8000
        assert info["supports_tools"] is False

    def test_get_max_tokens(self):
        assert get_max_tokens("qwen-max") == 131072
        assert get_max_tokens("unknown") == 8000

    def test_supports_tools(self):
        assert supports_tools("deepseek-chat") is True
        assert supports_tools("deepseek-reasoner") is False

    def test_supports_vision(self):
        assert supports_vision("qwen-max") is True
        assert supports_vision("qwen-turbo") is False

    def test_list_models(self):
        all_models = list_models()
        assert len(all_models) > 5
        assert "deepseek-chat" in all_models

    def test_list_models_by_provider(self):
        ds_models = list_models(provider="deepseek")
        assert all("deepseek" in m for m in ds_models)


# ============================================================
# Credential Pool 测试
# ============================================================

class TestCredentialPool:
    def test_round_robin(self):
        """轮转获取"""
        pool = CredentialPool(["k1", "k2", "k3"])
        assert pool.get_next() == "k1"
        assert pool.get_next() == "k2"
        assert pool.get_next() == "k3"
        assert pool.get_next() == "k1"  # 循环回来

    def test_mark_exhausted(self):
        """标记耗尽后跳过"""
        pool = CredentialPool(["k1", "k2"])
        pool.mark_exhausted("k1")
        assert pool.get_next() == "k2"
        assert pool.get_next() == "k2"  # k1 被跳过

    def test_all_exhausted(self):
        """所有 key 耗尽"""
        pool = CredentialPool(["k1", "k2"])
        pool.mark_exhausted("k1")
        pool.mark_exhausted("k2")
        with pytest.raises(AllCredentialsExhausted):
            pool.get_next()

    def test_mark_recovered(self):
        """恢复 key"""
        pool = CredentialPool(["k1", "k2"])
        pool.mark_exhausted("k1")
        pool.mark_recovered("k1")
        # 现在 k1 应该可用
        results = {pool.get_next() for _ in range(4)}
        assert "k1" in results

    def test_empty_keys_raises(self):
        """空 key 列表"""
        with pytest.raises(ValueError):
            CredentialPool([])

    def test_properties(self):
        pool = CredentialPool(["k1", "k2", "k3"])
        assert pool.total_keys == 3
        assert pool.available_keys == 3
        pool.mark_exhausted("k1")
        assert pool.exhausted_keys == 1
        assert pool.available_keys == 2

    def test_reset(self):
        pool = CredentialPool(["k1", "k2"])
        pool.mark_exhausted("k1")
        pool.mark_exhausted("k2")
        pool.reset()
        assert pool.available_keys == 2
        assert pool.get_next() == "k1"


# ============================================================
# Session Persistence 测试
# ============================================================

class TestSessionPersistence:
    def test_save_and_load(self, tmp_path):
        """保存和加载"""
        save_session(
            "sess-001", str(tmp_path),
            agent_id="agent1", user_id="user1",
            messages=[{"role": "user", "content": "hi"}],
            summary="测试会话",
        )
        loaded = load_session("sess-001", str(tmp_path))
        assert loaded is not None
        assert loaded.session_id == "sess-001"
        assert loaded.agent_id == "agent1"
        assert len(loaded.messages) == 1
        assert loaded.summary == "测试会话"

    def test_load_nonexistent(self, tmp_path):
        """加载不存在的 session"""
        assert load_session("nonexistent", str(tmp_path)) is None

    def test_list_sessions(self, tmp_path):
        """列出所有 session"""
        save_session("s1", str(tmp_path), agent_id="a", user_id="u", messages=[])
        save_session("s2", str(tmp_path), agent_id="a", user_id="u", messages=[{"role": "user", "content": "x"}])

        sessions = list_sessions(str(tmp_path))
        assert len(sessions) == 2
        ids = {s.session_id for s in sessions}
        assert "s1" in ids
        assert "s2" in ids

    def test_delete_session(self, tmp_path):
        """删除 session"""
        save_session("to-delete", str(tmp_path), messages=[])
        assert delete_session("to-delete", str(tmp_path)) is True
        assert load_session("to-delete", str(tmp_path)) is None
        # 删除不存在的返回 False
        assert delete_session("to-delete", str(tmp_path)) is False

    def test_list_empty(self, tmp_path):
        """空目录列出"""
        assert list_sessions(str(tmp_path)) == []
