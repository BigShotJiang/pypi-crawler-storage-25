"""LeaperBrain 引擎测试 — 覆盖 engine.py 的核心功能"""
import pytest
import pytest_asyncio

from src.brain.engine import LeaperBrain, tokenize, extract_entities


@pytest_asyncio.fixture
async def brain():
    """创建 :memory: 数据库的 LeaperBrain 实例"""
    b = LeaperBrain(db_path=":memory:", agent_id="test-agent")
    await b.initialize()
    yield b
    await b.close()


class TestInitialize:
    @pytest.mark.asyncio
    async def test_initialize_creates_tables(self, brain: LeaperBrain):
        """初始化后应创建 entries/messages/profiles/meta/transitions 表"""
        async with brain.db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ) as cur:
            tables = {row[0] for row in await cur.fetchall()}
        for t in ("entries", "messages", "profiles", "meta", "transitions"):
            assert t in tables, f"缺少表 {t}"

    @pytest.mark.asyncio
    async def test_double_initialize(self):
        """多次 initialize 不报错"""
        b = LeaperBrain(db_path=":memory:", agent_id="x")
        await b.initialize()
        await b.initialize()  # 第二次不应崩溃
        await b.close()


class TestStoreAndRecall:
    @pytest.mark.asyncio
    async def test_store_and_recall(self, brain: LeaperBrain):
        """存入记忆后 recall 能找到"""
        await brain.store_entry("knowledge", "Python asyncio 是异步编程核心框架", category="tech")
        results = await brain.recall("asyncio 异步", limit=5)
        assert len(results) >= 1
        assert "asyncio" in results[0]["content"]

    @pytest.mark.asyncio
    async def test_recall_empty(self, brain: LeaperBrain):
        """空库 recall 返回空列表"""
        results = await brain.recall("任意查询", limit=5)
        assert results == []

    @pytest.mark.asyncio
    async def test_recall_limit(self, brain: LeaperBrain):
        """limit 参数限制返回条数"""
        for i in range(10):
            await brain.store_entry("knowledge", f"知识条目 entry{i} 关于技术 topic{i}", category="tech")
        results = await brain.recall("知识 技术", limit=3)
        assert len(results) <= 3


class TestStoreMessage:
    @pytest.mark.asyncio
    async def test_store_message(self, brain: LeaperBrain):
        """存消息后能从数据库查到"""
        msg_id = await brain.store_message("sess-1", "user", "你好世界")
        assert msg_id
        async with brain.db.execute("SELECT * FROM messages WHERE id = ?", (msg_id,)) as cur:
            row = await cur.fetchone()
        assert row is not None
        assert dict(row)["content"] == "你好世界"

    @pytest.mark.asyncio
    async def test_store_multiple_messages(self, brain: LeaperBrain):
        """同一 session 可存多条消息"""
        await brain.store_message("sess-1", "user", "消息一")
        await brain.store_message("sess-1", "assistant", "回复一")
        async with brain.db.execute("SELECT COUNT(*) FROM messages WHERE session_id = ?", ("sess-1",)) as cur:
            count = (await cur.fetchone())[0]
        assert count == 2


class TestExtractKnowledge:
    @pytest.mark.asyncio
    async def test_extract_knowledge(self, brain: LeaperBrain):
        """从对话提取知识条目"""
        conversation = [
            {"role": "user", "content": "请介绍一下 Python 的 asyncio 库"},
            {"role": "assistant", "content": "Python asyncio 是标准库中的异步IO框架，提供事件循环、协程、Task等核心概念，广泛用于高并发网络服务开发"},
        ]
        extracted = await brain.extract_knowledge(conversation)
        assert isinstance(extracted, list)
        # 至少提取到一些知识
        if extracted:
            assert "content" in extracted[0]
            assert "confidence" in extracted[0]

    @pytest.mark.asyncio
    async def test_extract_empty_conversation(self, brain: LeaperBrain):
        """空对话返回空列表"""
        result = await brain.extract_knowledge([])
        assert result == []


class TestEntryOperations:
    @pytest.mark.asyncio
    async def test_get_entries(self, brain: LeaperBrain):
        """get_entries 获取已存条目"""
        await brain.store_entry("knowledge", "测试内容", category="tech")
        entries = await brain.get_entries()
        assert len(entries) == 1
        assert entries[0]["content"] == "测试内容"

    @pytest.mark.asyncio
    async def test_update_entry_status(self, brain: LeaperBrain):
        """更新条目状态"""
        eid = await brain.store_entry("knowledge", "将被归档", category="tech")
        await brain.update_entry_status(eid, "archived")
        entries = await brain.get_entries(status="archived")
        assert len(entries) == 1

    @pytest.mark.asyncio
    async def test_increment_access(self, brain: LeaperBrain):
        """访问计数递增"""
        eid = await brain.store_entry("knowledge", "热门内容", category="tech")
        await brain.increment_access(eid)
        await brain.increment_access(eid)
        entries = await brain.get_entries()
        assert entries[0]["access_count"] == 2

    @pytest.mark.asyncio
    async def test_record_transition(self, brain: LeaperBrain):
        """记录知识变迁"""
        old = {"id": "old-1", "content": "旧事实", "category": "tech"}
        new = {"id": "new-1", "content": "新事实", "category": "tech"}
        tid = await brain.record_transition(old, new, "update")
        assert tid
        transitions = await brain.get_transitions()
        assert len(transitions) == 1


class TestTokenize:
    def test_english_tokens(self):
        """英文分词去停用词"""
        tokens = tokenize("The quick brown fox")
        assert "quick" in tokens
        assert "the" not in tokens

    def test_chinese_bigrams(self):
        """中文二元分词"""
        tokens = tokenize("异步编程框架")
        assert "异步" in tokens
        assert "编程" in tokens


class TestExtractEntities:
    def test_camel_case(self):
        """识别 CamelCase 实体"""
        entities = extract_entities("Use LangGraph for orchestration")
        assert "langgraph" in entities

    def test_acronyms(self):
        """识别大写缩写"""
        entities = extract_entities("The API and SDK are ready")
        assert "api" in entities
