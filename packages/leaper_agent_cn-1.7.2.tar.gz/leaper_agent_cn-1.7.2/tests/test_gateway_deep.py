"""Gateway 深度测试 — 覆盖 Session / StreamConsumer / MessageQueue / Config / Status / 渠道集成

至少 25 个测试用例。
"""
import asyncio
import json
import time
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from src.gateway import (
    Gateway, GatewaySession, SessionManager,
    StreamConsumer, UserMessageQueue,
)
from src.gateway_config import GatewayConfig, ChannelConfig, SUPPORTED_CHANNELS
from src.gateway_status import GatewayStatus, MessageStats
from src.channels.base import IncomingMessage
from src.channels.weixin import (
    WeixinChannel, WeixinCrypto, WeixinMessage,
    parse_xml, build_text_reply, build_image_reply,
)
from src.channels.qqbot import (
    QQBotChannel, QQBotMessage, parse_qq_event,
)


# ═══════════════════════════════════════════════════════
# GatewaySession 测试
# ═══════════════════════════════════════════════════════

class TestGatewaySession:
    def test_create_session(self):
        """创建 session 自动生成 ID 和时间戳"""
        s = GatewaySession(user_id="u1", channel="weixin")
        assert s.session_id
        assert s.user_id == "u1"
        assert s.channel == "weixin"
        assert s.created_at > 0
        assert s.history == []

    def test_add_message(self):
        """添加消息到历史"""
        s = GatewaySession(user_id="u1", channel="feishu")
        s.add_message("user", "你好")
        s.add_message("assistant", "你好！")
        assert len(s.history) == 2
        assert s.history[0] == {"role": "user", "content": "你好"}

    def test_is_expired(self):
        """session 过期检测"""
        s = GatewaySession(user_id="u1", channel="feishu")
        assert not s.is_expired(timeout=3600)
        s.last_active = time.time() - 7200
        assert s.is_expired(timeout=3600)

    def test_serialize_roundtrip(self):
        """序列化/反序列化往返"""
        s = GatewaySession(user_id="u1", channel="qqbot")
        s.add_message("user", "test")
        d = s.to_dict()
        s2 = GatewaySession.from_dict(d)
        assert s2.user_id == "u1"
        assert s2.channel == "qqbot"
        assert len(s2.history) == 1


# ═══════════════════════════════════════════════════════
# SessionManager 测试
# ═══════════════════════════════════════════════════════

class TestSessionManager:
    def test_get_or_create(self, tmp_path):
        """获取或创建 session"""
        mgr = SessionManager(session_dir=str(tmp_path), timeout=3600)
        s1 = mgr.get_or_create("u1", "weixin")
        s2 = mgr.get_or_create("u1", "weixin")
        assert s1.session_id == s2.session_id

    def test_different_users(self, tmp_path):
        """不同用户获取不同 session"""
        mgr = SessionManager(session_dir=str(tmp_path), timeout=3600)
        s1 = mgr.get_or_create("u1", "weixin")
        s2 = mgr.get_or_create("u2", "weixin")
        assert s1.session_id != s2.session_id

    def test_cleanup_expired(self, tmp_path):
        """清理过期 session"""
        mgr = SessionManager(session_dir=str(tmp_path), timeout=1)
        s = mgr.get_or_create("u1", "feishu")
        s.last_active = time.time() - 10
        cleaned = mgr.cleanup()
        assert cleaned == 1
        assert mgr.active_count() == 0

    def test_save_and_load(self, tmp_path):
        """持久化和恢复"""
        mgr = SessionManager(session_dir=str(tmp_path), timeout=3600)
        s = mgr.get_or_create("u1", "weixin")
        s.add_message("user", "hello")
        mgr.save(s)

        mgr2 = SessionManager(session_dir=str(tmp_path), timeout=3600)
        s2 = mgr2.get_or_create("u1", "weixin")
        assert len(s2.history) == 1


# ═══════════════════════════════════════════════════════
# StreamConsumer 测试
# ═══════════════════════════════════════════════════════

class TestStreamConsumer:
    @pytest.mark.asyncio
    async def test_consume_normal(self):
        """正常消费流"""
        async def gen():
            for chunk in ["你", "好", "世界"]:
                yield chunk

        sc = StreamConsumer(timeout=5.0)
        result = await sc.consume(gen())
        assert result == "你好世界"

    @pytest.mark.asyncio
    async def test_consume_timeout(self):
        """超时处理"""
        async def gen():
            yield "部分"
            await asyncio.sleep(10)
            yield "结果"

        sc = StreamConsumer(timeout=0.1)
        result = await sc.consume(gen())
        assert "部分" in result  # 至少有部分结果

    @pytest.mark.asyncio
    async def test_consume_empty(self):
        """空流超时返回提示"""
        async def gen():
            await asyncio.sleep(10)
            yield "never"

        sc = StreamConsumer(timeout=0.1)
        result = await sc.consume(gen())
        assert "超时" in result


# ═══════════════════════════════════════════════════════
# UserMessageQueue 测试
# ═══════════════════════════════════════════════════════

class TestUserMessageQueue:
    @pytest.mark.asyncio
    async def test_enqueue_and_process(self):
        """入队并处理消息"""
        results = []

        async def processor(channel, uid, content, session):
            results.append(content)

        q = UserMessageQueue(max_concurrent=5)
        q.set_processor(processor)
        session = GatewaySession(user_id="u1", channel="weixin")
        await q.enqueue("weixin", "u1", "msg1", session)
        await asyncio.sleep(0.2)
        assert "msg1" in results

    @pytest.mark.asyncio
    async def test_pending_count(self):
        """待处理消息计数"""
        q = UserMessageQueue(max_concurrent=1)
        # 无 processor，消息会入队但不处理
        assert q.pending_count() == 0


# ═══════════════════════════════════════════════════════
# GatewayConfig 测试
# ═══════════════════════════════════════════════════════

class TestGatewayConfig:
    def test_from_dict_defaults(self):
        """默认配置"""
        cfg = GatewayConfig.from_dict({})
        assert cfg.host == "0.0.0.0"
        assert cfg.port == 8080
        assert cfg.session_timeout == 86400

    def test_from_dict_custom(self):
        """自定义配置"""
        cfg = GatewayConfig.from_dict({
            "host": "127.0.0.1",
            "port": 9090,
            "max_concurrent": 20,
        })
        assert cfg.host == "127.0.0.1"
        assert cfg.port == 9090
        assert cfg.max_concurrent == 20

    def test_validate_ok(self):
        """有效配置无错误"""
        cfg = GatewayConfig.from_dict({
            "port": 8080,
            "channels": {
                "weixin": {"app_id": "wx123", "app_secret": "sec", "token": "tok"},
            }
        })
        assert cfg.is_valid()

    def test_validate_bad_port(self):
        """无效端口"""
        cfg = GatewayConfig(port=0)
        errors = cfg.validate()
        assert any("端口" in e for e in errors)

    def test_validate_missing_channel_fields(self):
        """渠道缺少必填字段"""
        cfg = GatewayConfig(channels={"weixin": {"app_id": "wx123"}})
        errors = cfg.validate()
        assert any("app_secret" in e for e in errors)

    def test_validate_unknown_channel(self):
        """未知渠道名"""
        cfg = GatewayConfig(channels={"unknown_ch": {}})
        errors = cfg.validate()
        assert any("未知渠道" in e for e in errors)

    def test_env_override(self):
        """环境变量覆盖"""
        with patch.dict("os.environ", {"LEAPER_GATEWAY_PORT": "3000"}):
            cfg = GatewayConfig.from_dict({})
            assert cfg.port == 3000

    def test_to_dict(self):
        """序列化"""
        cfg = GatewayConfig(host="localhost", port=9999)
        d = cfg.to_dict()
        assert d["host"] == "localhost"
        assert d["port"] == 9999

    def test_get_webhook_path(self):
        """webhook 路径"""
        cfg = GatewayConfig(webhook_prefix="/hook")
        assert cfg.get_webhook_path("feishu") == "/hook/feishu"


# ═══════════════════════════════════════════════════════
# GatewayStatus 测试
# ═══════════════════════════════════════════════════════

class TestGatewayStatus:
    def test_uptime(self):
        """运行时间"""
        status = GatewayStatus()
        assert status.uptime_seconds >= 0
        assert isinstance(status.uptime_human, str)

    def test_channel_lifecycle(self):
        """渠道上下线"""
        status = GatewayStatus()
        status.channel_online("weixin")
        status.channel_online("qqbot")
        assert set(status.get_online_channels()) == {"weixin", "qqbot"}
        status.channel_offline("weixin")
        assert status.get_online_channels() == ["qqbot"]

    def test_message_stats(self):
        """消息统计"""
        status = GatewayStatus()
        status.record_message(True, 100.0)
        status.record_message(True, 200.0)
        status.record_message(False)
        s = status.get_status()
        assert s["messages"]["total"] == 3
        assert s["messages"]["success"] == 2
        assert s["messages"]["failed"] == 1
        assert s["messages"]["avg_latency_ms"] == 150.0

    def test_health_ok(self):
        """健康检查 — 有在线渠道"""
        status = GatewayStatus()
        status.channel_online("feishu")
        h = status.get_health()
        assert h["status"] == "ok"

    def test_health_degraded(self):
        """健康检查 — 渠道全部离线"""
        status = GatewayStatus()
        status.channel_online("weixin")
        status.channel_offline("weixin")
        h = status.get_health()
        assert h["status"] == "degraded"


# ═══════════════════════════════════════════════════════
# MessageStats 测试
# ═══════════════════════════════════════════════════════

class TestMessageStats:
    def test_record(self):
        """记录统计"""
        ms = MessageStats()
        ms.record(True, 50.0)
        ms.record(True, 150.0)
        assert ms.total == 2
        assert ms.avg_latency_ms == 100.0

    def test_to_dict(self):
        """序列化"""
        ms = MessageStats()
        ms.record(True, 100.0)
        d = ms.to_dict()
        assert "total" in d
        assert "avg_latency_ms" in d


# ═══════════════════════════════════════════════════════
# 微信渠道测试
# ═══════════════════════════════════════════════════════

class TestWeixinChannel:
    def _make_channel(self):
        return WeixinChannel({
            "app_id": "wx_test",
            "app_secret": "secret_test",
            "token": "test_token",
        })

    def test_verify_signature_ok(self):
        """签名验证 — 正确"""
        ch = self._make_channel()
        import hashlib
        ts, nonce = "12345", "nonce1"
        tmp = sorted(["test_token", ts, nonce])
        sig = hashlib.sha1("".join(tmp).encode()).hexdigest()
        assert ch.verify_signature(sig, ts, nonce)

    def test_verify_signature_bad(self):
        """签名验证 — 错误"""
        ch = self._make_channel()
        assert not ch.verify_signature("bad_sig", "123", "nonce")

    def test_parse_xml(self):
        """XML 解析"""
        xml = """<xml>
        <ToUserName><![CDATA[gh_test]]></ToUserName>
        <FromUserName><![CDATA[user123]]></FromUserName>
        <CreateTime>1234567890</CreateTime>
        <MsgType><![CDATA[text]]></MsgType>
        <Content><![CDATA[你好]]></Content>
        <MsgId>123456</MsgId>
        </xml>"""
        msg = parse_xml(xml)
        assert msg.from_user == "user123"
        assert msg.msg_type == "text"
        assert msg.content == "你好"

    def test_build_text_reply(self):
        """构造文本回复"""
        xml = build_text_reply("gh_test", "user1", "回复内容")
        assert "<MsgType><![CDATA[text]]></MsgType>" in xml
        assert "回复内容" in xml

    def test_build_image_reply(self):
        """构造图片回复"""
        xml = build_image_reply("gh_test", "user1", "media_123")
        assert "media_123" in xml
        assert "<MsgType><![CDATA[image]]></MsgType>" in xml

    @pytest.mark.asyncio
    async def test_handle_text_message(self):
        """处理文本消息"""
        ch = self._make_channel()

        async def handler(msg):
            return f"收到: {msg.content}"

        ch.on_message(handler)
        xml = """<xml>
        <ToUserName><![CDATA[gh_test]]></ToUserName>
        <FromUserName><![CDATA[user1]]></FromUserName>
        <CreateTime>1234567890</CreateTime>
        <MsgType><![CDATA[text]]></MsgType>
        <Content><![CDATA[测试消息]]></Content>
        <MsgId>100</MsgId>
        </xml>"""
        reply = await ch.handle_message(xml)
        assert "收到: 测试消息" in reply

    @pytest.mark.asyncio
    async def test_handle_subscribe_event(self):
        """处理关注事件"""
        ch = self._make_channel()
        xml = """<xml>
        <ToUserName><![CDATA[gh_test]]></ToUserName>
        <FromUserName><![CDATA[user1]]></FromUserName>
        <CreateTime>1234567890</CreateTime>
        <MsgType><![CDATA[event]]></MsgType>
        <Event><![CDATA[subscribe]]></Event>
        </xml>"""
        reply = await ch.handle_message(xml)
        assert "欢迎" in reply

    def test_stats(self):
        """统计信息"""
        ch = self._make_channel()
        stats = ch.get_stats()
        assert stats["received"] == 0


# ═══════════════════════════════════════════════════════
# QQ Bot 渠道测试
# ═══════════════════════════════════════════════════════

class TestQQBotChannel:
    def _make_channel(self):
        return QQBotChannel({
            "app_id": "qq_test",
            "app_secret": "qq_secret",
        })

    def test_parse_qq_event(self):
        """解析 QQ 事件"""
        payload = {
            "op": 0,
            "t": "C2C_MESSAGE_CREATE",
            "d": {
                "id": "msg1",
                "content": "你好",
                "author": {"user_openid": "user_open_1"},
            },
        }
        msg = parse_qq_event(payload)
        assert msg.msg_id == "msg1"
        assert msg.content == "你好"
        assert msg.event_type == "C2C_MESSAGE_CREATE"

    def test_auth_headers(self):
        """认证 headers"""
        ch = self._make_channel()
        h = ch._auth_headers("tok123")
        assert h["Authorization"] == "QQBot tok123"

    def test_verify_no_secret(self):
        """无密钥跳过验证"""
        ch = self._make_channel()
        assert ch.verify_signature(b"body", "sig", "ts") is True

    def test_stats(self):
        """统计"""
        ch = self._make_channel()
        assert ch.get_stats()["received"] == 0


# ═══════════════════════════════════════════════════════
# Gateway 集成测试
# ═══════════════════════════════════════════════════════

class TestGatewayIntegration:
    def test_create_gateway(self):
        """创建网关"""
        gw = Gateway({"host": "localhost", "port": 9999})
        assert gw.host == "localhost"
        assert gw.port == 9999

    def test_register_channel(self):
        """注册渠道"""
        gw = Gateway({"host": "localhost", "port": 8080})
        ch = MagicMock()
        ch.handle_webhook = AsyncMock()
        gw.register_channel("test_ch", ch)
        assert "test_ch" in gw.channels

    def test_webhook_routes(self):
        """webhook 路由映射"""
        assert "weixin" in Gateway.WEBHOOK_ROUTES
        assert "qqbot" in Gateway.WEBHOOK_ROUTES
        assert "feishu" in Gateway.WEBHOOK_ROUTES


# ═══════════════════════════════════════════════════════
# ChannelConfig 测试
# ═══════════════════════════════════════════════════════

class TestChannelConfig:
    def test_validate_ok(self):
        """有效渠道配置"""
        cc = ChannelConfig(name="weixin", config={
            "app_id": "wx", "app_secret": "s", "token": "t"
        })
        assert cc.validate() == []

    def test_validate_missing(self):
        """缺少字段"""
        cc = ChannelConfig(name="feishu", config={})
        errors = cc.validate()
        assert len(errors) == 2  # app_id, app_secret
