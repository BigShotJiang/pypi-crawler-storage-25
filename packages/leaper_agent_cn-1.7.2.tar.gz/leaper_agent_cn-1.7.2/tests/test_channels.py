"""渠道测试 - 飞书/钉钉/企微 消息解析 + 签名验证 + Gateway 路由"""
import hashlib
import hmac
import base64
import json
import time
import struct
import pytest
from unittest.mock import AsyncMock, MagicMock, patch


# ============ 飞书 ============

class TestFeishuChannel:
    """飞书渠道测试"""

    def test_feishu_challenge_response(self):
        """测试 URL 验证请求返回 challenge"""
        from src.channels.feishu import FeishuChannel

        channel = FeishuChannel({
            "app_id": "test_app",
            "app_secret": "test_secret",
            "verification_token": "test_token",
        })
        body = {"challenge": "ajls384kdjx98XX", "token": "test_token", "type": "url_verification"}
        assert body["challenge"] == "ajls384kdjx98XX"

    def test_feishu_signature_verification(self):
        """飞书签名验证（SHA256）"""
        from src.channels.feishu import FeishuChannel

        timestamp = "1234567890"
        nonce = "abc123"
        encrypt_key = "my_encrypt_key"
        body = '{"hello":"world"}'

        expected = FeishuChannel.compute_signature(timestamp, nonce, encrypt_key, body)
        content = timestamp + nonce + encrypt_key + body
        manual = hashlib.sha256(content.encode("utf-8")).hexdigest()
        assert expected == manual

        different = FeishuChannel.compute_signature(timestamp, nonce, encrypt_key, '{"other":"data"}')
        assert different != expected

    def test_feishu_event_dedup(self):
        """事件去重"""
        from src.channels.feishu import FeishuChannel

        channel = FeishuChannel({
            "app_id": "test", "app_secret": "test",
            "verification_token": "tok",
        })
        assert not channel._is_duplicate("evt_001")
        assert channel._is_duplicate("evt_001")
        assert not channel._is_duplicate("")

    def test_feishu_message_parse(self):
        """飞书消息体解析"""
        event = {
            "header": {"event_id": "e001", "token": "tok"},
            "event": {
                "message": {
                    "message_type": "text",
                    "content": json.dumps({"text": "你好"}),
                    "chat_id": "oc_123",
                },
                "sender": {"sender_id": {"open_id": "ou_abc"}},
            }
        }
        msg = event["event"]["message"]
        text = json.loads(msg["content"]).get("text", "")
        user_id = event["event"]["sender"]["sender_id"]["open_id"]
        assert text == "你好"
        assert user_id == "ou_abc"


# ============ 钉钉 ============

class TestDingTalkChannel:
    """钉钉渠道测试"""

    def test_dingtalk_message_parse(self):
        """钉钉 outgoing 消息解析"""
        body = {
            "msgtype": "text",
            "text": {"content": "你好机器人"},
            "senderStaffId": "user123",
            "conversationId": "conv456",
            "msgId": "msg789",
        }
        text = body.get("text", {}).get("content", "").strip()
        sender = body.get("senderStaffId") or body.get("senderId", "unknown")
        assert text == "你好机器人"
        assert sender == "user123"

    def test_dingtalk_signature_verification(self):
        """钉钉签名验证（HMAC-SHA256）"""
        from src.channels.dingtalk import DingTalkChannel

        secret = "SEC_test_secret_key_12345"
        timestamp = str(int(time.time() * 1000))

        correct_sign = DingTalkChannel.compute_signature(timestamp, secret)

        string_to_sign = f"{timestamp}\n{secret}"
        hmac_code = hmac.new(secret.encode(), string_to_sign.encode(), hashlib.sha256).digest()
        manual_sign = base64.b64encode(hmac_code).decode()
        assert correct_sign == manual_sign

        channel = DingTalkChannel({
            "app_key": "test_key", "app_secret": secret, "robot_code": "bot",
        })
        assert channel._verify_signature(timestamp, correct_sign)
        assert not channel._verify_signature(timestamp, "wrong_sign_here")

    def test_dingtalk_dedup(self):
        """消息去重"""
        from src.channels.dingtalk import DingTalkChannel

        channel = DingTalkChannel({
            "app_key": "k", "app_secret": "s", "robot_code": "r",
        })
        assert not channel._is_duplicate("msg_001")
        assert channel._is_duplicate("msg_001")

    def test_dingtalk_expired_timestamp(self):
        """过期时间戳应拒绝"""
        from src.channels.dingtalk import DingTalkChannel

        channel = DingTalkChannel({
            "app_key": "k", "app_secret": "s", "robot_code": "r",
        })
        old_ts = str(int(time.time() * 1000) - 7200000)  # 2小时前
        sign = DingTalkChannel.compute_signature(old_ts, "s")
        assert not channel._verify_signature(old_ts, sign)


# ============ 企业微信 ============

class TestWeComChannel:
    """企微渠道测试"""

    def test_wecom_xml_parse(self):
        """企微 XML 消息解析"""
        import xml.etree.ElementTree as ET

        xml_str = """<xml>
            <ToUserName><![CDATA[corp_id]]></ToUserName>
            <FromUserName><![CDATA[user001]]></FromUserName>
            <MsgType><![CDATA[text]]></MsgType>
            <Content><![CDATA[测试消息]]></Content>
            <MsgId>12345</MsgId>
        </xml>"""
        tree = ET.fromstring(xml_str)
        assert tree.findtext("MsgType") == "text"
        assert tree.findtext("Content") == "测试消息"
        assert tree.findtext("FromUserName") == "user001"
        assert tree.findtext("MsgId") == "12345"

    def test_wecom_signature_verification(self):
        """企微签名验证（SHA1）"""
        from src.channels.wecom import WeComChannel

        token = "test_token"
        timestamp = "1409659813"
        nonce = "nonce_value"
        echostr = "encrypted_msg_content"

        computed = WeComChannel.compute_signature(token, timestamp, nonce, echostr)
        sort_list = sorted([token, timestamp, nonce, echostr])
        manual = hashlib.sha1("".join(sort_list).encode("utf-8")).hexdigest()
        assert computed == manual

        channel = WeComChannel({
            "corp_id": "corp", "agent_id": "1000002", "secret": "sec",
            "token": token,
            "encoding_aes_key": base64.b64encode(b"0" * 32).decode().rstrip("="),
        })
        assert channel._verify_signature(computed, timestamp, nonce, echostr)
        assert not channel._verify_signature("wrong_sig", timestamp, nonce, echostr)

    def test_wecom_dedup(self):
        """企微消息去重"""
        from src.channels.wecom import WeComChannel

        channel = WeComChannel({
            "corp_id": "corp", "agent_id": "1000002", "secret": "sec",
            "token": "tok",
            "encoding_aes_key": base64.b64encode(b"0" * 32).decode().rstrip("="),
        })
        assert not channel._is_duplicate("msg_001")
        assert channel._is_duplicate("msg_001")

    def test_wecom_encrypt_decrypt(self):
        """企微加解密往返测试"""
        pytest.importorskip("Crypto", reason="pycryptodome 未安装")
        from src.channels.wecom import WeComChannel

        # 生成合法的 43 字符 AES key
        aes_key_bytes = b"A" * 32
        encoding_aes_key = base64.b64encode(aes_key_bytes).decode().rstrip("=")

        channel = WeComChannel({
            "corp_id": "test_corp", "agent_id": "1000002", "secret": "sec",
            "token": "tok",
            "encoding_aes_key": encoding_aes_key,
        })
        original = "Hello 企微测试消息"
        encrypted = channel._encrypt(original)
        decrypted = channel._decrypt(encrypted)
        assert decrypted == original


# ============ 渠道工厂 ============

class TestChannelFactory:
    """渠道工厂函数"""

    def test_create_feishu(self):
        from src.channels import create_channel
        ch = create_channel("feishu", {"app_id": "a", "app_secret": "s", "verification_token": "t"})
        from src.channels.feishu import FeishuChannel
        assert isinstance(ch, FeishuChannel)

    def test_create_dingtalk(self):
        from src.channels import create_channel
        ch = create_channel("dingtalk", {"app_key": "k", "app_secret": "s"})
        from src.channels.dingtalk import DingTalkChannel
        assert isinstance(ch, DingTalkChannel)

    def test_create_unknown_raises(self):
        from src.channels import create_channel
        with pytest.raises(ValueError, match="未知渠道"):
            create_channel("telegram", {})


# ============ Gateway 路由 ============

class TestGateway:
    """Gateway 路由测试"""

    def test_gateway_registers_channels(self):
        from src.gateway import Gateway
        gw = Gateway(config={"channels": {}})
        from src.channels.feishu import FeishuChannel
        ch = FeishuChannel({"app_id": "a", "app_secret": "s", "verification_token": "t"})
        gw.register_channel("feishu", ch)
        assert "feishu" in gw.channels

    def test_gateway_health(self):
        from src.gateway import Gateway
        gw = Gateway(config={})
        gw.register_channel("feishu", MagicMock())
        gw.register_channel("dingtalk", MagicMock())
        # channels 应包含两个
        assert len(gw.channels) == 2

    @pytest.mark.asyncio
    async def test_route_without_manager_raises(self):
        from src.gateway import Gateway
        gw = Gateway(config={})
        with pytest.raises(RuntimeError, match="MultiAgentManager"):
            await gw.route_message("hello", "feishu")


# ============ CLI 渠道 ============

def test_cli_channel():
    """CLI 渠道基础功能"""
    class CLIChannel:
        def __init__(self):
            self.output_buffer = []
        def send(self, message: str):
            self.output_buffer.append(message)
        def receive(self, user_input: str) -> str:
            return user_input.strip()

    channel = CLIChannel()
    assert channel.receive("  你好  ") == "你好"
    channel.send("收到消息")
    assert channel.output_buffer == ["收到消息"]
