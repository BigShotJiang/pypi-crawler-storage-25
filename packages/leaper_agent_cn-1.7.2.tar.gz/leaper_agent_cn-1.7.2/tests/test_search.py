"""搜索工具测试 - mock httpx 测 DuckDuckGo + Bing 解析"""
import json
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from src.tools.search import SearchTool


# DuckDuckGo 搜索结果 HTML 片段（模拟真实返回）
DDG_HTML = """
<div class="result results_links results_links_deep web-result">
  <div class="links_main links_deep result__body">
    <a class="result__a" rel="noopener" href="https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fpage1&rut=abc">
      <b>示例</b>标题一
    </a>
    <a class="result__snippet" href="https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fpage1">
      这是第一个搜索结果的摘要文本
    </a>
  </div>
</div>
<div class="result results_links results_links_deep web-result">
  <div class="links_main links_deep result__body">
    <a class="result__a" rel="noopener" href="https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fpage2&rut=def">
      标题二 <b>关键词</b>
    </a>
    <a class="result__snippet" href="https://duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fpage2">
      第二个结果的摘要内容
    </a>
  </div>
</div>
"""

# Bing 搜索结果 HTML 片段
BING_HTML = """
<ol id="b_results">
  <li class="b_algo">
    <h2><a href="https://bing-result.com/page1">Bing 结果标题</a></h2>
    <p>Bing 搜索结果摘要文本</p>
  </li>
  <li class="b_algo">
    <h2><a href="https://bing-result.com/page2">第二个 Bing 结果</a></h2>
    <p>另一个摘要</p>
  </li>
</ol>
"""


class TestSearchTool:
    """搜索工具测试"""

    def test_parse_ddg_html(self):
        """DuckDuckGo HTML 解析"""
        results = SearchTool._parse_ddg_html(DDG_HTML, 5)
        assert len(results) == 2
        assert results[0]["title"] == "示例标题一"
        assert results[0]["url"] == "https://example.com/page1"
        assert "第一个搜索结果" in results[0]["snippet"]
        assert results[1]["title"] == "标题二 关键词"

    def test_parse_bing_html(self):
        """Bing HTML 解析"""
        results = SearchTool._parse_bing_html(BING_HTML, 5)
        assert len(results) == 2
        assert results[0]["title"] == "Bing 结果标题"
        assert results[0]["url"] == "https://bing-result.com/page1"
        assert "Bing 搜索结果摘要" in results[0]["snippet"]

    def test_parse_empty_html(self):
        """空 HTML 应返回空列表"""
        assert SearchTool._parse_ddg_html("", 5) == []
        assert SearchTool._parse_bing_html("", 5) == []

    def test_max_results_limit(self):
        """结果数量限制"""
        results = SearchTool._parse_ddg_html(DDG_HTML, 1)
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_search_ddg_success(self):
        """DuckDuckGo 搜索成功时返回 JSON 结果"""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = DDG_HTML
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = AsyncMock(return_value=mock_response)
            instance.get = AsyncMock(return_value=mock_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            tool = SearchTool()
            result = await tool.execute({"query": "测试搜索"})
            parsed = json.loads(result)
            assert len(parsed) == 2
            assert parsed[0]["title"] == "示例标题一"

    @pytest.mark.asyncio
    async def test_search_fallback_to_bing(self):
        """DuckDuckGo 失败时 fallback 到 Bing"""
        ddg_error = Exception("DuckDuckGo 超时")
        bing_response = MagicMock()
        bing_response.status_code = 200
        bing_response.text = BING_HTML
        bing_response.raise_for_status = MagicMock()

        with patch("httpx.AsyncClient") as MockClient:
            instance = AsyncMock()
            instance.post = AsyncMock(side_effect=ddg_error)
            instance.get = AsyncMock(return_value=bing_response)
            instance.__aenter__ = AsyncMock(return_value=instance)
            instance.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = instance

            tool = SearchTool()
            result = await tool.execute({"query": "测试搜索"})
            parsed = json.loads(result)
            assert len(parsed) == 2
            assert "Bing" in parsed[0]["title"]

    def test_return_format(self):
        """返回格式符合 [{title, url, snippet}]"""
        results = SearchTool._parse_ddg_html(DDG_HTML, 5)
        for r in results:
            assert "title" in r
            assert "url" in r
            assert "snippet" in r
            assert isinstance(r["title"], str)
            assert isinstance(r["url"], str)
