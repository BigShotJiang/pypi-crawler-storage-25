"""TUI Gateway 测试 — EventBus + TerminalRenderer + TUIServer"""
import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch


# ============ EventBus 测试 ============

class TestEventBus:
    """事件总线测试"""

    def test_import(self):
        """能正常导入"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        assert bus is not None

    def test_subscribe_and_count(self):
        """订阅后计数正确"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        handler = AsyncMock()
        bus.subscribe("message", handler)
        assert bus.subscriber_count == {"message": 1}

    def test_unsubscribe(self):
        """取消订阅"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        handler = AsyncMock()
        bus.subscribe("message", handler)
        bus.unsubscribe("message", handler)
        assert bus.subscriber_count == {}

    def test_unsubscribe_nonexistent(self):
        """取消未订阅的处理器不报错"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        bus.unsubscribe("message", AsyncMock())  # 不抛异常

    @pytest.mark.asyncio
    async def test_emit_calls_handler(self):
        """发布事件后调用处理器"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        handler = AsyncMock()
        bus.subscribe("message", handler)
        await bus.emit("message", {"text": "hello"})
        handler.assert_called_once_with({"text": "hello"})

    @pytest.mark.asyncio
    async def test_emit_no_handler(self):
        """没有处理器时不报错"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        await bus.emit("message", {"text": "hello"})  # 不抛异常

    @pytest.mark.asyncio
    async def test_history(self):
        """事件历史记录"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        await bus.emit("message", {"a": 1})
        await bus.emit("error", {"b": 2})
        history = bus.get_history()
        assert len(history) == 2
        assert history[0]["type"] == "message"

    @pytest.mark.asyncio
    async def test_history_filter(self):
        """按类型过滤历史"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        await bus.emit("message", {"a": 1})
        await bus.emit("error", {"b": 2})
        assert len(bus.get_history("error")) == 1

    @pytest.mark.asyncio
    async def test_clear_history(self):
        """清空历史"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        await bus.emit("message", {"a": 1})
        bus.clear_history()
        assert len(bus.get_history()) == 0

    @pytest.mark.asyncio
    async def test_handler_exception_not_propagate(self):
        """处理器异常不影响其他处理器"""
        from src.tui.event_bus import EventBus
        bus = EventBus()
        bad = AsyncMock(side_effect=RuntimeError("boom"))
        good = AsyncMock()
        bus.subscribe("x", bad)
        bus.subscribe("x", good)
        await bus.emit("x", {})
        good.assert_called_once()


# ============ TerminalRenderer 测试 ============

class TestTerminalRenderer:
    """终端渲染器测试"""

    def test_render_message_user(self):
        """渲染用户消息"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_message("user", "你好")
        assert "USER" in result
        assert "你好" in result

    def test_render_message_assistant(self):
        """渲染助手消息"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_message("assistant", "回复")
        assert "ASSISTANT" in result

    def test_render_tool_call(self):
        """渲染工具调用"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_tool_call("search", {"query": "test"})
        assert "search" in result
        assert "query" in result

    def test_render_thinking(self):
        """渲染思考"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_thinking("分析问题...")
        assert "分析问题" in result

    def test_render_error(self):
        """渲染错误"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_error("连接失败")
        assert "连接失败" in result

    def test_render_status_bar(self):
        """渲染状态栏"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_status_bar({"model": "qwen", "tokens": 100})
        assert "qwen" in result

    def test_clear_screen(self):
        """清屏序列"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        assert "\033[2J" in r.clear_screen()

    def test_no_color(self):
        """禁用颜色"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer(color_enabled=False)
        result = r.render_message("user", "test")
        assert "\033[" not in result

    def test_render_welcome(self):
        """渲染欢迎界面"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_welcome("TestBot")
        assert "TestBot" in result

    def test_render_stream_token(self):
        """渲染流式 token"""
        from src.tui.render import TerminalRenderer
        r = TerminalRenderer()
        result = r.render_stream_token("hello")
        assert "hello" in result


# ============ TUIServer 测试 ============

class TestTUIServer:
    """TUI 服务器测试"""

    def test_init(self):
        """初始化"""
        from src.tui.server import TUIServer
        server = TUIServer()
        assert server.sessions == {}
        assert server.event_bus is not None

    def test_get_status_not_running(self):
        """未启动时的状态"""
        from src.tui.server import TUIServer
        server = TUIServer()
        status = server.get_status()
        assert status["running"] is False
        assert status["sessions"] == 0

    def test_ws_accept_key(self):
        """WebSocket Accept Key 计算（RFC 6455 规范）"""
        from src.tui.server import _ws_accept_key
        key = "dGhlIHNhbXBsZSBub25jZQ=="
        # 验证：结果是 base64 编码的 SHA1
        result = _ws_accept_key(key)
        import base64
        assert len(base64.b64decode(result)) == 20  # SHA1 = 20 bytes

    def test_build_and_parse_frame(self):
        """构建和解析 WebSocket 帧"""
        from src.tui.server import _build_ws_frame, _parse_ws_frame, WS_OP_TEXT
        payload = b"hello"
        frame = _build_ws_frame(payload, WS_OP_TEXT)
        # 服务端帧无 mask，直接解析
        result = _parse_ws_frame(frame)
        assert result is not None
        opcode, data, consumed = result
        assert opcode == WS_OP_TEXT
        assert data == b"hello"

    def test_session_to_dict(self):
        """会话序列化"""
        from src.tui.server import TUISession
        session = TUISession("abc123", MagicMock())
        d = session.to_dict()
        assert d["session_id"] == "abc123"
        assert d["message_count"] == 0

    def test_session_touch(self):
        """会话活跃度更新"""
        from src.tui.server import TUISession
        session = TUISession("abc", MagicMock())
        old_time = session.last_active
        session.touch()
        assert session.message_count == 1
