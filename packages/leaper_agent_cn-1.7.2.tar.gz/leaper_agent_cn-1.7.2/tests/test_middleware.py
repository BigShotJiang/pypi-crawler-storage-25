"""中间件系统测试"""
import time
import pytest

from src.agent.middleware import (
    Middleware, MiddlewareChain,
    RedactMiddleware, LoggingMiddleware,
    RateLimitMiddleware, CacheMiddleware,
)


class TestMiddlewareChain:
    @pytest.mark.asyncio
    async def test_empty_chain(self):
        chain = MiddlewareChain()
        msg = await chain.run_request("hello", {})
        assert msg == "hello"

    @pytest.mark.asyncio
    async def test_priority_order(self):
        """优先级小的先执行"""
        order = []

        class A(Middleware):
            name = "A"
            async def process_request(self, msg, ctx):
                order.append("A")
                return msg

        class B(Middleware):
            name = "B"
            async def process_request(self, msg, ctx):
                order.append("B")
                return msg

        chain = MiddlewareChain()
        chain.add(B(), priority=10)
        chain.add(A(), priority=1)
        await chain.run_request("test", {})
        assert order == ["A", "B"]

    @pytest.mark.asyncio
    async def test_response_reverse_order(self):
        order = []

        class A(Middleware):
            name = "A"
            async def process_response(self, resp, ctx):
                order.append("A")
                return resp

        class B(Middleware):
            name = "B"
            async def process_response(self, resp, ctx):
                order.append("B")
                return resp

        chain = MiddlewareChain()
        chain.add(A(), priority=1)
        chain.add(B(), priority=10)
        await chain.run_response("test", {})
        # 响应反序：B 先执行
        assert order == ["B", "A"]

    def test_remove(self):
        chain = MiddlewareChain()
        chain.add(LoggingMiddleware(), priority=0)
        assert "LoggingMiddleware" in chain.middlewares
        chain.remove("LoggingMiddleware")
        assert "LoggingMiddleware" not in chain.middlewares

    def test_middlewares_list(self):
        chain = MiddlewareChain()
        chain.add(LoggingMiddleware())
        chain.add(RedactMiddleware())
        assert len(chain.middlewares) == 2


class TestRedactMiddleware:
    @pytest.mark.asyncio
    async def test_redact_phone(self):
        mw = RedactMiddleware()
        result = await mw.process_response("电话 13812345678 请联系", {})
        assert "13812345678" not in result
        assert "1**" in result

    @pytest.mark.asyncio
    async def test_redact_api_key(self):
        mw = RedactMiddleware()
        result = await mw.process_response("key is sk-abcdefghijklmnop", {})
        assert "abcdefghijklmnop" not in result

    @pytest.mark.asyncio
    async def test_no_redaction_needed(self):
        mw = RedactMiddleware()
        result = await mw.process_response("正常文本", {})
        assert result == "正常文本"


class TestLoggingMiddleware:
    @pytest.mark.asyncio
    async def test_passthrough(self):
        mw = LoggingMiddleware()
        msg = await mw.process_request("hello", {})
        assert msg == "hello"
        resp = await mw.process_response("world", {})
        assert resp == "world"


class TestRateLimitMiddleware:
    @pytest.mark.asyncio
    async def test_within_limit(self):
        mw = RateLimitMiddleware(max_requests=5, window_seconds=60)
        for _ in range(5):
            await mw.process_request("msg", {})

    @pytest.mark.asyncio
    async def test_exceed_limit(self):
        from src.errors import RateLimitError
        mw = RateLimitMiddleware(max_requests=2, window_seconds=60)
        await mw.process_request("1", {})
        await mw.process_request("2", {})
        with pytest.raises(RateLimitError):
            await mw.process_request("3", {})


class TestCacheMiddleware:
    @pytest.mark.asyncio
    async def test_cache_miss(self):
        mw = CacheMiddleware()
        ctx: dict = {}
        await mw.process_request("hello", ctx)
        assert not ctx.get("__cache_hit")

    @pytest.mark.asyncio
    async def test_cache_hit(self):
        mw = CacheMiddleware()
        # 先缓存
        ctx1 = {"original_message": "hello"}
        await mw.process_request("hello", ctx1)
        await mw.process_response("world", ctx1)
        # 再查
        ctx2: dict = {}
        await mw.process_request("hello", ctx2)
        assert ctx2.get("__cache_hit") is True

    def test_clear(self):
        mw = CacheMiddleware()
        mw._cache["k"] = ("v", time.time())
        assert mw.size == 1
        mw.clear()
        assert mw.size == 0
