"""StreamHandler 测试"""

import asyncio
import pytest
from src.agent.stream_handler import StreamHandler, StreamResult


async def _make_stream(chunks):
    """创建模拟异步流"""
    for c in chunks:
        yield c


class TestStreamHandler:
    """流式处理器测试"""

    def test_init(self):
        h = StreamHandler()
        assert h.chunks == []
        assert h.tool_calls == []
        assert h.is_complete is False

    @pytest.mark.asyncio
    async def test_empty_stream(self):
        h = StreamHandler()
        result = await h.process_stream(_make_stream([]))
        assert result.text == ""
        assert result.tool_calls == []
        assert h.is_complete is True

    @pytest.mark.asyncio
    async def test_text_chunks(self):
        chunks = [
            {"choices": [{"delta": {"content": "你好"}, "finish_reason": None}]},
            {"choices": [{"delta": {"content": "世界"}, "finish_reason": "stop"}]},
        ]
        h = StreamHandler()
        result = await h.process_stream(_make_stream(chunks))
        assert result.text == "你好世界"
        assert result.finish_reason == "stop"
        assert result.chunk_count == 2

    @pytest.mark.asyncio
    async def test_on_chunk_callback(self):
        received = []
        chunks = [
            {"choices": [{"delta": {"content": "A"}, "finish_reason": None}]},
            {"choices": [{"delta": {"content": "B"}, "finish_reason": None}]},
        ]
        h = StreamHandler()
        await h.process_stream(_make_stream(chunks), on_chunk=received.append)
        assert received == ["A", "B"]

    @pytest.mark.asyncio
    async def test_tool_call_detection(self):
        chunks = [
            {"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "call_1", "type": "function", "function": {"name": "search", "arguments": ""}}]}, "finish_reason": None}]},
            {"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": '{"q":"test"}'}}]}, "finish_reason": None}]},
            {"choices": [{"delta": {}, "finish_reason": "tool_calls"}]},
        ]
        h = StreamHandler()
        result = await h.process_stream(_make_stream(chunks))
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["function"]["name"] == "search"
        assert result.tool_calls[0]["function"]["arguments_parsed"] == {"q": "test"}

    @pytest.mark.asyncio
    async def test_usage_collection(self):
        chunks = [
            {"choices": [{"delta": {"content": "hi"}, "finish_reason": "stop"}]},
            {"usage": {"prompt_tokens": 10, "completion_tokens": 5}},
        ]
        h = StreamHandler()
        result = await h.process_stream(_make_stream(chunks))
        assert result.usage["prompt_tokens"] == 10
        assert result.usage["completion_tokens"] == 5

    def test_reset(self):
        h = StreamHandler()
        h.chunks.append("test")
        h.reset()
        assert h.chunks == []
        assert h.is_complete is False

    def test_get_text_empty(self):
        h = StreamHandler()
        assert h.get_text() == ""

    def test_get_tool_calls_empty(self):
        h = StreamHandler()
        assert h.get_tool_calls() == []
