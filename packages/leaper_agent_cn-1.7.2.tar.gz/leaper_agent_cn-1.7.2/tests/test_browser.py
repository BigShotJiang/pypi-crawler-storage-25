"""浏览器自动化模块测试 — 全部 mock，不真实请求网络"""
from __future__ import annotations

import json
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from src.browser.agent import BrowserAgent
from src.browser.tool import create_browser_skill
from src.browser.china_adapters import (
    WechatMPAdapter, ZhihuAdapter, BilibiliAdapter,
)


# ─── test_browser_tool_schema ─────────────────────────────────────────

def test_browser_tool_schema():
    """schema 格式正确"""
    skill = create_browser_skill()
    tool_def = skill.to_tool_def()

    assert tool_def["type"] == "function"
    fn = tool_def["function"]
    assert fn["name"] == "browser"
    assert "action" in fn["parameters"]["properties"]
    props = fn["parameters"]["properties"]
    assert props["action"]["type"] == "string"
    assert "navigate" in props["action"]["enum"]
    assert "action" in fn["parameters"]["required"]


# ─── test_navigate_fallback ───────────────────────────────────────────

@pytest.mark.asyncio
async def test_navigate_fallback():
    """无 Playwright 时 httpx fallback"""
    agent = BrowserAgent()
    agent._playwright_available = False

    fake_html = "<html><body><h1>Hello</h1><p>World</p></body></html>"

    mock_resp = MagicMock()
    mock_resp.text = fake_html
    mock_resp.raise_for_status = MagicMock()

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client_cls.return_value = mock_client

        text = await agent.navigate("https://example.com")

    assert "Hello" in text
    assert "World" in text


# ─── test_extract_text ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_extract_text():
    """文本提取（fallback 模式）"""
    agent = BrowserAgent()
    agent._playwright_available = False
    agent._last_html = '<div class="main"><p>提取这段文字</p></div>'

    text = await agent.extract_text(".main")
    assert "提取这段文字" in text


# ─── test_extract_links ───────────────────────────────────────────────

@pytest.mark.asyncio
async def test_extract_links():
    """链接提取（fallback 模式）"""
    agent = BrowserAgent()
    agent._playwright_available = False
    agent._last_html = '''
    <html><body>
        <a href="https://a.com">链接A</a>
        <a href="https://b.com">链接B</a>
    </body></html>
    '''

    links = await agent.extract_links()
    assert len(links) == 2
    assert links[0]["href"] == "https://a.com"
    assert links[0]["text"] == "链接A"


# ─── test_wechat_mp_parse ────────────────────────────────────────────

def test_wechat_mp_parse():
    """公众号文章解析"""
    html = '''
    <html>
    <script>var msg_title = "测试文章标题";</script>
    <script>var nickname = "测试公众号";</script>
    <script>var publish_time = "2024-01-15";</script>
    <div class="rich_media_content" id="js_content">
        <p>这是文章正文内容</p>
    </div><!-- -->
    </html>
    '''
    adapter = WechatMPAdapter()
    result = adapter.parse_article(html)

    assert result["title"] == "测试文章标题"
    assert result["author"] == "测试公众号"
    assert result["publish_time"] == "2024-01-15"
    assert "文章正文内容" in result["content"]


# ─── test_zhihu_parse ─────────────────────────────────────────────────

def test_zhihu_parse():
    """知乎内容解析"""
    initial_data = {
        "initialState": {
            "entities": {
                "answers": {
                    "123": {
                        "author": {"name": "知乎大V"},
                        "content": "这是回答内容",
                        "voteupCount": 1000,
                        "commentCount": 50,
                    }
                }
            }
        }
    }
    html = f'<script id="js-initialData">{json.dumps(initial_data)}</script>'

    adapter = ZhihuAdapter()
    result = adapter.parse_answer(html)

    assert result["author"] == "知乎大V"
    assert "回答内容" in result["content"]
    assert result["voteup_count"] == 1000


# ─── test_bilibili_parse ──────────────────────────────────────────────

def test_bilibili_parse():
    """B站内容解析"""
    state = {
        "videoData": {
            "title": "B站测试视频",
            "owner": {"name": "UP主"},
            "stat": {"view": 10000, "like": 500, "coin": 100},
            "desc": "视频简介",
        }
    }
    html = f'window.__INITIAL_STATE__={json.dumps(state)};(function(){{}})();'

    adapter = BilibiliAdapter()
    result = adapter.parse_video_info(html)

    assert result["title"] == "B站测试视频"
    assert result["author"] == "UP主"
    assert result["views"] == 10000
    assert result["likes"] == 500


# ─── test_browser_as_skill ────────────────────────────────────────────

@pytest.mark.asyncio
async def test_browser_as_skill():
    """作为 skill 注册并执行"""
    skill = create_browser_skill()

    assert skill.name == "browser"
    assert "浏览器" in skill.description
    assert "打开网页" in skill.triggers

    # 测试 navigate（mock httpx）
    fake_html = "<html><body><p>技能测试</p></body></html>"
    mock_resp = MagicMock()
    mock_resp.text = fake_html
    mock_resp.raise_for_status = MagicMock()

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client_cls.return_value = mock_client

        result = await skill.execute({"action": "navigate", "url": "https://test.com"})

    assert "技能测试" in result
