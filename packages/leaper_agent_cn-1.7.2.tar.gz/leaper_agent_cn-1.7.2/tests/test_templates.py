"""测试模板部署"""

import pytest
import os
import sys
import json
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def test_deploy_basic_role(tmp_path):
    """测试部署基础角色模板"""
    # 模拟模板结构
    template_dir = tmp_path / "templates" / "cto"
    template_dir.mkdir(parents=True)
    (template_dir / "SOUL.md").write_text("你是 CTO 顾问", encoding="utf-8")
    (template_dir / "AGENTS.md").write_text("## 核心任务\n技术战略", encoding="utf-8")

    workspace = tmp_path / "workspace"
    workspace.mkdir()

    # 模拟部署逻辑
    import shutil
    for f in template_dir.iterdir():
        shutil.copy(f, workspace / f.name)

    assert (workspace / "SOUL.md").exists()
    assert "CTO" in (workspace / "SOUL.md").read_text(encoding="utf-8")


def test_deploy_with_industry(tmp_path):
    """测试带行业叠加的模板部署"""
    # 基础角色
    base_dir = tmp_path / "templates" / "cfo"
    base_dir.mkdir(parents=True)
    (base_dir / "SOUL.md").write_text("你是 CFO 顾问\n{industry_context}", encoding="utf-8")

    # 行业叠加
    industry_dir = tmp_path / "skills" / "L1-industry" / "finance"
    industry_dir.mkdir(parents=True)
    (industry_dir / "context.md").write_text("金融行业专业知识", encoding="utf-8")

    workspace = tmp_path / "workspace"
    workspace.mkdir()

    # 模拟部署：读取基础 + 叠加行业
    soul = (base_dir / "SOUL.md").read_text(encoding="utf-8")
    industry_ctx = (industry_dir / "context.md").read_text(encoding="utf-8")
    soul = soul.replace("{industry_context}", industry_ctx)

    (workspace / "SOUL.md").write_text(soul, encoding="utf-8")

    result = (workspace / "SOUL.md").read_text(encoding="utf-8")
    assert "CFO" in result
    assert "金融行业" in result


def test_deploy_fills_user_info(tmp_path):
    """测试部署时填充用户信息"""
    template_dir = tmp_path / "templates" / "cmo"
    template_dir.mkdir(parents=True)
    (template_dir / "SOUL.md").write_text(
        "你是 {company_name} 的 CMO\n服务 {user_name}",
        encoding="utf-8",
    )

    workspace = tmp_path / "workspace"
    workspace.mkdir()

    user_info = {"company_name": "跃盟科技", "user_name": "Ray"}

    soul = (template_dir / "SOUL.md").read_text(encoding="utf-8")
    for key, val in user_info.items():
        soul = soul.replace(f"{{{key}}}", val)
    (workspace / "SOUL.md").write_text(soul, encoding="utf-8")

    result = (workspace / "SOUL.md").read_text(encoding="utf-8")
    assert "跃盟科技" in result
    assert "Ray" in result


def test_loader_reads_workspace(tmp_path):
    """测试加载器正确读取工作空间"""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "SOUL.md").write_text("灵魂文件", encoding="utf-8")
    (workspace / "AGENTS.md").write_text("代理配置", encoding="utf-8")
    (workspace / "USER.md").write_text("用户信息", encoding="utf-8")

    # 模拟加载器
    loaded = {}
    for fname in ["SOUL.md", "AGENTS.md", "USER.md"]:
        fpath = workspace / fname
        if fpath.exists():
            loaded[fname] = fpath.read_text(encoding="utf-8")

    assert len(loaded) == 3
    assert "灵魂文件" in loaded["SOUL.md"]
    assert "代理配置" in loaded["AGENTS.md"]
