"""模板部署与 prompt 组装测试"""
import os
import tempfile
from pathlib import Path

import pytest

from src.templates.deployer import TemplateDeployer


# 角色-中文名映射
ROLE_NAMES = {
    "cto": "AI CTO — 首席技术官",
    "cpo": "AI CPO — 首席产品官",
    "cfo": "AI CFO — 首席财务官",
    "cmo": "AI CMO — 首席营销官",
    "coo": "AI COO — 首席运营官",
    "cso": "AI CSO — 首席战略官",
    "cco": "AI CCO — 首席内容官",
    "chro": "AI CHRO — 首席人力官",
    "clo": "AI CLO — 首席法务官",
    "ceo-coach": "AI CEO Coach — CEO 教练",
}

# 海外模型/渠道关键词黑名单
OVERSEAS_KEYWORDS = [
    "openai", "gpt-4", "gpt-3", "anthropic", "claude", "ollama",
    "sk-ant-", "sk-your", "YOUR_BOT_TOKEN",
]


class TestTemplateDeployer:
    """模板部署测试"""

    def test_deploy_basic(self, tmp_path: Path):
        """基础部署：角色模板 + _common 文件全部复制"""
        deployer = TemplateDeployer()
        ws = deployer.deploy(role="cto", agent_name="test-cto")
        try:
            assert ws.exists()
            # 至少有 SOUL.md 和 config.yaml
            assert (ws / "SOUL.md").exists()
            assert (ws / "config.yaml").exists()
            # _common 文件也要在
            assert (ws / "PREAMBLE.md").exists()
        finally:
            import shutil
            shutil.rmtree(ws, ignore_errors=True)

    def test_deploy_user_info(self, tmp_path: Path):
        """部署时传 user_info 生成 USER.md"""
        deployer = TemplateDeployer()
        ws = deployer.deploy(
            role="cto",
            agent_name="test-user-info",
            user_info={"Name": "张三", "Company": "测试公司"},
        )
        try:
            user_md = ws / "USER.md"
            assert user_md.exists()
            content = user_md.read_text(encoding="utf-8")
            assert "张三" in content
            assert "测试公司" in content
        finally:
            import shutil
            shutil.rmtree(ws, ignore_errors=True)

    def test_deploy_industry(self, tmp_path: Path):
        """部署时传 industry 不报错"""
        deployer = TemplateDeployer()
        ws = deployer.deploy(
            role="cto",
            agent_name="test-industry",
            industry="AI",
        )
        try:
            assert ws.exists()
        finally:
            import shutil
            shutil.rmtree(ws, ignore_errors=True)

    def test_deploy_all_roles(self):
        """所有 10 个角色都能部署成功"""
        deployer = TemplateDeployer()
        import shutil
        for role in ROLE_NAMES:
            ws = deployer.deploy(role=role, agent_name=f"test-{role}")
            try:
                assert ws.exists(), f"{role} workspace 不存在"
                assert (ws / "config.yaml").exists(), f"{role} 缺少 config.yaml"
                assert (ws / ".env").exists(), f"{role} 缺少 .env"
            finally:
                shutil.rmtree(ws, ignore_errors=True)

    def test_config_no_overseas(self):
        """config.yaml 不包含海外模型/渠道"""
        deployer = TemplateDeployer()
        import shutil
        for role in ROLE_NAMES:
            ws = deployer.deploy(role=role, agent_name=f"test-overseas-{role}")
            try:
                config_text = (ws / "config.yaml").read_text(encoding="utf-8").lower()
                for kw in OVERSEAS_KEYWORDS:
                    assert kw.lower() not in config_text, (
                        f"{role}/config.yaml 包含海外关键词: {kw}"
                    )
            finally:
                shutil.rmtree(ws, ignore_errors=True)

    def test_env_no_hermes(self):
        """.env 不包含 HERMES 相关变量"""
        deployer = TemplateDeployer()
        import shutil
        for role in ROLE_NAMES:
            ws = deployer.deploy(role=role, agent_name=f"test-hermes-{role}")
            try:
                env_text = (ws / ".env").read_text(encoding="utf-8")
                assert "HERMES" not in env_text, f"{role}/.env 包含 HERMES"
            finally:
                shutil.rmtree(ws, ignore_errors=True)

    def test_template_yaml_not_deployed(self):
        """template.yaml 不应被复制到 workspace"""
        deployer = TemplateDeployer()
        import shutil
        ws = deployer.deploy(role="cto", agent_name="test-skip-template")
        try:
            assert not (ws / "template.yaml").exists(), "template.yaml 不应出现在 workspace"
        finally:
            shutil.rmtree(ws, ignore_errors=True)


class TestChatPromptAssembly:
    """prompt 组装测试"""

    def test_prompt_assembly_order(self, tmp_path: Path):
        """按顺序加载 workspace .md 文件并拼接"""
        # 准备测试 workspace
        files = [
            "PREAMBLE.md", "IDENTITY.md", "SOUL.md", "EGO.md", "USER.md",
            "AGENTS.md", "MEMORY.md", "ROLE-TYPES.md", "SELF-CHECK.md",
            "LIFECYCLE.md", "TRIGGERS.md", "ONBOARDING.md",
        ]
        for fname in files:
            (tmp_path / fname).write_text(f"content of {fname}", encoding="utf-8")

        # 模拟 _chat_loop 中的 prompt 组装逻辑
        prompt_parts = []
        for fname in files:
            fpath = tmp_path / fname
            if fpath.exists():
                content = fpath.read_text(encoding="utf-8")
                prompt_parts.append(f"## {fname}\n{content}")
        system_prompt = "\n\n---\n\n".join(prompt_parts)

        # 验证顺序
        assert system_prompt.index("PREAMBLE.md") < system_prompt.index("IDENTITY.md")
        assert system_prompt.index("SOUL.md") < system_prompt.index("EGO.md")
        assert "---" in system_prompt
        assert "## SOUL.md" in system_prompt
        # 全部 12 个文件都在
        for fname in files:
            assert f"## {fname}" in system_prompt
