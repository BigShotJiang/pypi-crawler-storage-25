from __future__ import annotations

from typing import TYPE_CHECKING

from blends.stack.single_file_resolver import (
    SingleFileResolutionRequest,
    resolve_definitions_single_file,
)

if TYPE_CHECKING:
    from blends.models import NId, SyntaxGraph
    from blends.stack.partial_path import PartialPathFileRecord
    from blends.stack.view import StackGraphView


def infer_constructor_callee_nid(
    syntax_graph: SyntaxGraph,
    view: StackGraphView,
    def_node_index: int,
) -> NId | None:
    """Return the SymbolLookup NId for ClassName if the definition is obj = ClassName()."""
    if def_node_index >= len(view.index_to_nid):
        return None
    nid = view.index_to_nid[def_node_index]
    if nid is None:
        return None
    node = syntax_graph.nodes.get(nid)
    if node is None or node.get("label_type") != "VariableDeclaration":
        return None
    value_id = node.get("value_id")
    value_node = syntax_graph.nodes.get(value_id) if value_id is not None else None
    if value_node is None or value_node.get("label_type") != "MethodInvocation":
        return None
    expression = value_node.get("expression")
    if not expression or "." in expression:
        return None
    return value_node.get("expression_id")


def _class_nids_from_def_index(view: StackGraphView, def_idx: int) -> list[NId]:
    if def_idx >= len(view.outgoing):
        return []
    result: list[NId] = []
    for scope_idx, _ in view.outgoing[def_idx]:
        if scope_idx < len(view.index_to_nid):
            nid = view.index_to_nid[scope_idx]
            if nid is not None:
                result.append(nid)
    return result


def _resolve_class_nids(
    view: StackGraphView,
    record: PartialPathFileRecord,
    callee_nid: NId,
) -> list[NId]:
    callee_index = view.nid_to_index.get(callee_nid)
    if callee_index is None:
        return []
    request = SingleFileResolutionRequest(
        file_handle=record.file_handle,
        record=record,
        ref_node_index=callee_index,
    )
    raw = resolve_definitions_single_file(view, request=request)
    def_indices: list[int] = raw if isinstance(raw, list) else raw[0]
    result: list[NId] = []
    for def_idx in def_indices:
        result.extend(_class_nids_from_def_index(view, def_idx))
    return result


def find_member_in_class_scope(
    syntax_graph: SyntaxGraph,
    class_nid: NId,
    member_name: str,
) -> list[NId]:
    return list(syntax_graph.symbol_index.get(member_name, {}).get(class_nid, []))


def resolve_receiver_member(
    syntax_graph: SyntaxGraph,
    view: StackGraphView,
    record: PartialPathFileRecord,
    receiver_ref_index: int,
    member_name: str,
) -> list[NId]:
    request = SingleFileResolutionRequest(
        file_handle=record.file_handle,
        record=record,
        ref_node_index=receiver_ref_index,
    )
    raw = resolve_definitions_single_file(view, request=request)
    def_indices: list[int] = raw if isinstance(raw, list) else raw[0]

    seen: set[NId] = set()
    result: list[NId] = []
    for def_idx in def_indices:
        callee_nid = infer_constructor_callee_nid(syntax_graph, view, def_idx)
        if callee_nid is None:
            continue
        for class_nid in _resolve_class_nids(view, record, callee_nid):
            for nid in find_member_in_class_scope(syntax_graph, class_nid, member_name):
                if nid not in seen:
                    seen.add(nid)
                    result.append(nid)
    return result
