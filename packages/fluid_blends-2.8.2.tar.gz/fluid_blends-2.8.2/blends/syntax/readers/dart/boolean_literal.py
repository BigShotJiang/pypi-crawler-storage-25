from blends.models import (
    NId,
)
from blends.syntax.builders.literal import (
    build_literal_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    n_attrs = args.ast_graph.nodes[args.n_id]
    value: str = n_attrs.get("label_text") or n_attrs.get("label_type") or "boolean"
    return build_literal_node(args, value, "bool")
