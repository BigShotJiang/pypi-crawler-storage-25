from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast,
    match_ast_d,
)
from blends.syntax.builders.element_access import (
    build_element_access_node,
)
from blends.syntax.builders.expression_statement import (
    build_expression_statement_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_accessor_chain import (
    try_build_accessor_chain,
)
from blends.utilities.text_nodes import (
    node_to_str,
)

_SELECTOR_LABELS = {
    "selector",
    "unconditional_assignable_selector",
    "conditional_assignable_selector",
}
_MIN_CHILDREN_FOR_CHAIN = 2


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = adj_ast(graph, args.n_id)
    expected_children_for_element_access = 2
    if (
        len(c_ids) == expected_children_for_element_access
        and graph.nodes[c_ids[0]]["label_type"] == "identifier"
        and graph.nodes[c_ids[1]]["label_type"] == "unconditional_assignable_selector"
        and (idx_selector := match_ast_d(graph, c_ids[1], "index_selector"))
        and (arg_id := match_ast(graph, idx_selector, "[", "]").get("__0__"))
    ):
        return build_element_access_node(args, c_ids[0], arg_id)

    if (
        len(c_ids) >= _MIN_CHILDREN_FOR_CHAIN
        and graph.nodes[c_ids[0]]["label_type"] == "identifier"
        and all(graph.nodes[c]["label_type"] in _SELECTOR_LABELS for c in c_ids[1:])
        and (symbol := node_to_str(graph, c_ids[0]))
        and (chain_id := try_build_accessor_chain(args, graph, symbol, c_ids[0], list(c_ids[1:])))
        is not None
    ):
        return chain_id

    invalid_childs = {";", "(", ")", "type_cast_expression"}

    return build_expression_statement_node(
        args,
        c_ids=(_id for _id in c_ids if graph.nodes[_id]["label_type"] not in invalid_childs),
    )
