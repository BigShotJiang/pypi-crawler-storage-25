from blends.ctx import ctx
from blends.models import (
    NId,
    StackGraph,
)
from blends.stack.edges import (
    Edge,
    add_edge,
)
from blends.stack.node_helpers import (
    push_scoped_symbol_node_attributes,
    push_symbol_node_attributes,
)
from blends.syntax.builders.utils import (
    find_import_bound_scope,
    get_event_subpath,
    get_next_synthetic_node_id,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def _is_namespace_object(args: SyntaxGraphArgs, expression: str) -> bool:
    scope_stack = args.metadata.get("scope_stack")
    if not scope_stack:
        return False
    current_scope = scope_stack[-1]
    for nid in args.syntax_graph.symbol_index.get(expression, {}).get(current_scope, []):
        node = args.syntax_graph.nodes[nid]
        if node.get("label_type") == "Import" and node.get("expression") == "*":
            return True
    return False


def _add_stack_graph_member_node(
    args: SyntaxGraphArgs,
    stack_graph: StackGraph,
    member: str,
    expression: str,
    child_id: NId,
) -> None:
    if _is_namespace_object(args, expression):
        scope = args.metadata["scope_stack"][-1]
        stack_graph.add_node(
            args.n_id,
            **push_scoped_symbol_node_attributes(symbol=member, scope=scope, is_reference=True),
        )
        add_edge(stack_graph, Edge(source=args.n_id, sink=scope))
        return
    import_scope = find_import_bound_scope(args, expression)
    if import_scope is not None:
        stack_graph.add_node(
            args.n_id,
            **push_scoped_symbol_node_attributes(
                symbol=member, scope=import_scope, is_reference=True
            ),
        )
        add_edge(stack_graph, Edge(source=args.n_id, sink=import_scope))
        if "." in expression:
            bound_sym_id = get_next_synthetic_node_id(args)
            bound_symbol = expression.rsplit(".", 1)[-1]
            stack_graph.add_node(
                bound_sym_id,
                **push_scoped_symbol_node_attributes(
                    symbol=bound_symbol, scope=import_scope, is_reference=True
                ),
            )
            add_edge(stack_graph, Edge(source=bound_sym_id, sink=import_scope))
            dot_id = get_next_synthetic_node_id(args)
            stack_graph.add_node(
                dot_id, **push_symbol_node_attributes(symbol=".", is_reference=False)
            )
            add_edge(stack_graph, Edge(source=args.n_id, sink=dot_id))
            add_edge(stack_graph, Edge(source=dot_id, sink=bound_sym_id))
            return
    else:
        stack_graph.add_node(
            args.n_id,
            **push_symbol_node_attributes(symbol=member, is_reference=True),
        )
    dot_id = get_next_synthetic_node_id(args)
    args.syntax_graph.add_node(dot_id, label_type="SyntheticMemberDot")
    stack_graph.add_node(dot_id, **push_symbol_node_attributes(symbol=".", is_reference=False))
    add_edge(stack_graph, Edge(source=args.n_id, sink=dot_id))
    add_edge(stack_graph, Edge(source=dot_id, sink=child_id))


def build_member_access_node(
    args: SyntaxGraphArgs,
    member: str,
    expression: str,
    expression_id: NId,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        member=member,
        expression=expression,
        expression_id=expression_id,
        label_type="MemberAccess",
    )

    if scope_stack := args.metadata.get("scope_stack"):
        args.syntax_graph.update_node_attribute(args.n_id, "symbol_scope", scope_stack[-1])

    child_id = args.generic(args.fork_n_id(expression_id))
    args.syntax_graph.add_edge(
        args.n_id,
        child_id,
        label_ast="AST",
    )

    if (
        (sanitization_stack := args.metadata.get("sanitization_stack"))
        and sanitization_stack
        and not sanitization_stack[-1][0].endswith("_pending")
        and (scope_stack := args.metadata.get("scope_stack"))
    ):
        kind, parent_id = sanitization_stack[-1]
        full_name = f"{expression}.{member}"
        args.syntax_graph.register_sanitization(
            full_name,
            scope=scope_stack[-1],
            node_id=parent_id,
            kind=kind,
            subpath=get_event_subpath(args),
        )

    if ctx.has_feature_flag("StackGraph") and args.stack_graph is not None:
        _add_stack_graph_member_node(args, args.stack_graph, member, expression, child_id)

    return args.n_id
