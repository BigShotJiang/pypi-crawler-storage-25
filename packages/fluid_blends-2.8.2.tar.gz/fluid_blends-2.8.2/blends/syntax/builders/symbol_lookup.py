from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.stack.edges import (
    Edge,
    add_edge,
)
from blends.stack.node_helpers import (
    push_scoped_symbol_node_attributes,
    push_symbol_node_attributes,
)
from blends.syntax.builders.utils import (
    find_import_bound_scope,
    get_event_subpath,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_symbol_lookup_node(args: SyntaxGraphArgs, symbol: str) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        symbol=symbol,
        label_type="SymbolLookup",
    )

    if scope_stack := args.metadata.get("scope_stack"):
        args.syntax_graph.update_node_attribute(args.n_id, "symbol_scope", scope_stack[-1])

    if (
        (sanitization_stack := args.metadata.get("sanitization_stack"))
        and sanitization_stack
        and not sanitization_stack[-1][0].endswith("_pending")
        and (scope_stack := args.metadata.get("scope_stack"))
    ):
        kind, parent_id = sanitization_stack[-1]
        args.syntax_graph.register_sanitization(
            symbol,
            scope=scope_stack[-1],
            node_id=parent_id,
            kind=kind,
            subpath=get_event_subpath(args),
        )

    if ctx.has_feature_flag("StackGraph") and args.stack_graph is not None:
        scope_stack = args.metadata.setdefault("scope_stack", [])
        if scope_stack and (current_scope := scope_stack[-1]):
            import_bound = find_import_bound_scope(args, symbol)
            effective_scope = import_bound if import_bound is not None else current_scope
            args.stack_graph.add_node(
                args.n_id,
                **push_scoped_symbol_node_attributes(
                    symbol=symbol,
                    scope=effective_scope,
                    precedence=0,
                ),
            )
            add_edge(
                args.stack_graph,
                Edge(source=args.n_id, sink=effective_scope, precedence=0),
            )
        else:
            args.stack_graph.add_node(
                args.n_id,
                **push_symbol_node_attributes(symbol=symbol, precedence=0),
            )

    return args.n_id
