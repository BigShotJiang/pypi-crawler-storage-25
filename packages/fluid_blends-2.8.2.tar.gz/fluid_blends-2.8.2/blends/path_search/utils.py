from collections.abc import Iterator

from blends.ctx import ctx
from blends.models import NId, SyntaxGraph
from blends.path_search.models import Path
from blends.query import lookup_first_cfg_parent, pred_cfg


def iter_backward_paths(graph: SyntaxGraph, cfg_n_id: NId) -> Iterator[Path]:
    path = [cfg_n_id]
    parents = pred_cfg(graph, cfg_n_id)

    if not parents:
        yield path

    for parent in parents:
        for sub_path in iter_backward_paths(graph, parent):
            yield path + sub_path


def get_backward_paths(graph: SyntaxGraph, n_id: NId) -> Iterator[Path]:
    cfg_id = lookup_first_cfg_parent(graph, n_id)
    paths_gen = iter_backward_paths(graph, cfg_id)
    if limit := ctx.recursion_limit:
        it_count = 1
        while it_count < limit:
            try:
                yield next(paths_gen)
                it_count += 1
            except StopIteration:
                return
    else:
        yield from paths_gen
