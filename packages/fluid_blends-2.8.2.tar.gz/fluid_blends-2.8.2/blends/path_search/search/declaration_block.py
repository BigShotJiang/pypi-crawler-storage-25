from collections.abc import (
    Iterator,
)

from blends.path_search.search.model import (
    SearchArgs,
    SearchResult,
)
from blends.query import (
    adj_cfg,
)


def search(args: SearchArgs) -> Iterator[SearchResult]:
    for c_id in adj_cfg(args.graph, args.n_id):
        if args.symbol == args.graph.nodes[c_id].get("name"):
            yield True, c_id
            break

        if args.symbol == args.graph.nodes[c_id].get("variable"):
            yield True, c_id
            break
