from collections.abc import (
    Iterator,
)

from blends.path_search.search.model import (
    SearchArgs,
    SearchResult,
)
from blends.query import (
    adj_cfg,
)


def search(args: SearchArgs) -> Iterator[SearchResult]:
    for c_id in adj_cfg(args.graph, args.n_id):
        if (
            args.graph.nodes[c_id]["label_type"] == "VariableDeclaration"
            and args.graph.nodes[c_id]["variable"] == args.symbol
        ):
            yield True, c_id
            break
