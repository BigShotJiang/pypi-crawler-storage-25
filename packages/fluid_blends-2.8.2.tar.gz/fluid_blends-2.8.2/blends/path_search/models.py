from blends.models import NId

Path = list[NId]
