# Released under a modified PolyForm Small Business License.
# Free for small businesses, individuals, and academics. See LICENSE for details.

from setuptools import setup, Extension
import numpy as np
import os
import sys

if sys.platform == 'win32':
    # MSVC flags for Windows
    common_compile_args = [
        '/O2',                # Maximum optimization
        '/fp:fast',           # Fast math operations
        '/GL',                # Whole program optimization (LTO)
    ]
    common_link_args = [
        '/LTCG',              # Link-time code generation (LTO)
    ]
    cpp_extra_args = ['/std:c++17']
else:
    # GCC/Clang flags for macOS and Linux
    common_compile_args = [
        '-O3',                    # Maximum optimization
        '-march=native',          # Use native CPU instructions (ARM on M1/M2/M3)
        '-mtune=native',          # Optimize for specific CPU
        '-ffast-math',            # Fast math operations
        '-funroll-loops',         # Loop unrolling
        '-flto',                  # Link-time optimization
        '-fomit-frame-pointer',   # Don't keep frame pointer (faster)
        '-fno-strict-aliasing',   # Allow pointer aliasing optimizations
    ]
    common_link_args = [
        '-flto',                  # Link-time optimization
    ]
    cpp_extra_args = ['-std=c++17']

# Demosaic C extensions with ARM optimizations
vng_extension = Extension(
    'muimg._vng',
    sources=['c-src/demosaic/vng.c'],
    include_dirs=[np.get_include()],
    extra_compile_args=common_compile_args,
    extra_link_args=common_link_args,
)

# RCD extension - only built if user has renamed rcd.txt to rcd.c (GPL code)
rcd_source = 'c-src/demosaic/rcd.c'
rcd_extension = None
if os.path.exists(rcd_source):
    rcd_extension = Extension(
        'muimg._rcd',
        sources=[rcd_source],
        include_dirs=[np.get_include()],
        extra_compile_args=common_compile_args,
        extra_link_args=common_link_args,
    )

# DNG color processing C++ extension
# Standalone implementation of DNG SDK color algorithms (no SDK dependencies)
raw_render_extension = Extension(
    'muimg._raw_render',
    sources=['c-src/raw_render/raw_render_ops.cpp'],
    include_dirs=[np.get_include()],
    extra_compile_args=common_compile_args + cpp_extra_args,
    extra_link_args=common_link_args,
    language='c++',
)

# Build list of extensions
ext_modules = [vng_extension, raw_render_extension]
if rcd_extension:
    ext_modules.append(rcd_extension)

setup(
    ext_modules=ext_modules,
)
