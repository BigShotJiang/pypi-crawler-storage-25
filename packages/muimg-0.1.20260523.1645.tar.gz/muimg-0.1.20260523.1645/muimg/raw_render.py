# Released under a modified PolyForm Small Business License.
# Free for small businesses, individuals, and academics. See LICENSE for details.

from __future__ import annotations

import logging
import numpy as np

from enum import Enum, IntEnum, StrEnum, auto
from typing import Any

# Package imports
from . import _raw_render
from .common import enum_display_name, get_active_timer
from .splines import CubicSpline, ColorSpace, ColorSpaceLUT, LUT
from .deps import cv2_proxy as cv2
from .tiff_metadata import get_cfa_pattern_codes, Illuminant, Orientation

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

class DngOpcode(IntEnum):
    """DNG Opcode IDs (DNG Spec 1.7.1.0 section 5.2.4)."""
    WARP_RECTILINEAR = 1
    WARP_FISHEYE = 2
    FIX_VIGNETTE_RADIAL = 3
    FIX_BAD_PIXELS_CONSTANT = 4
    FIX_BAD_PIXELS_LIST = 5
    TRIM_BOUNDS = 6
    MAP_TABLE = 7
    MAP_POLYNOMIAL = 8
    GAIN_MAP = 9
    DELTA_PER_ROW = 10
    DELTA_PER_COLUMN = 11
    SCALE_PER_ROW = 12
    SCALE_PER_COLUMN = 13
    WARP_RECTILINEAR2 = 14
    
    @classmethod
    def lookup(cls, value: int) -> "DngOpcode" | None:
        """Look up enum member by integer value."""
        from .common import enum_from_value
        return enum_from_value(cls, value)


class DemosaicAlgorithm(StrEnum):
    """Demosaic algorithm selectors."""
    VNG = "VNG"
    RCD = "RCD"
    OPENCV_EA = "OPENCV_EA"
    OPENCV_EDGE = "OPENCV_EDGE"
    DNGSDK_BILINEAR = "DNGSDK_BILINEAR"
    
    @classmethod
    def lookup(cls, value: str) -> "DemosaicAlgorithm":
        """Look up enum member by string value."""
        from .common import enum_from_string
        return enum_from_string(cls, value)

# =============================================================================
# Helper Functions
# =============================================================================


def convert_dtype(
    image: np.ndarray,
    dest_dtype: np.dtype,
    src_bits_per_element: int | None = None,
    dest_bits_per_element: int | None = None,
    clip_max: float | None = None
) -> np.ndarray:
    """Convert image between data types with proper normalization and optional clipping.
    
    Handles conversion between uint8, uint16, and float types with
    appropriate scaling to preserve value ranges. Uses optimized C++
    implementation with NEON support on AArch64.
    
    Args:
        image: Input image (must be 3D: H, W, C)
        dest_dtype: Destination data type (np.uint8, np.uint16, np.float32)
        src_bits_per_element: Custom bit depth for source data (e.g., 12 for 12-bit data
            in uint16 container). Must be None for float types. Defaults to container
            bit depth if None.
        dest_bits_per_element: Custom bit depth for destination data. Must be None for
            float types. Defaults to container bit depth if None.
        clip_max: Maximum value to clip to in destination space. If None, no clipping
            is performed. For integer destinations, values are clipped to [0, clip_max].
            For float destinations, only upper bound clipping is applied.
        
    Returns:
        Converted image with dest_dtype
        
    Example:
        # Convert 12-bit data stored in uint16 to 8-bit uint8
        image_u16 = np.array([0, 2047, 4095], dtype=np.uint16)
        result = convert_dtype(image_u16, np.uint8, src_bits_per_element=12)
        
        # Convert float to uint8 with clipping
        result = convert_dtype(image_f32, np.uint8, clip_max=255.0)
    """
    dest_dtype = np.dtype(dest_dtype)

    # Early-out: same float dtype with no clip - return input unchanged
    if image.dtype == dest_dtype and clip_max is None and image.dtype in (np.float16, np.float32, np.float64):
        return image

    # Handle float16 by converting through float32 (same pattern as convert_colorspace)
    input_was_float16 = image.dtype == np.float16
    if input_was_float16:
        image = image.astype(np.float32)

    output_is_float16 = dest_dtype == np.float16
    if output_is_float16:
        dest_dtype = np.dtype(np.float32)
    
    # Map numpy dtype to NPY type number for C++ function
    dtype_to_npy = {
        np.dtype(np.uint8): 2,      # NPY_UINT8
        np.dtype(np.uint16): 4,     # NPY_UINT16
        np.dtype(np.float32): 11,  # NPY_FLOAT32
    }
    
    if dest_dtype not in dtype_to_npy:
        raise TypeError(f"Unsupported destination dtype: {dest_dtype}. Must be uint8, uint16, float16, or float32")
    
    if image.dtype not in dtype_to_npy:
        raise TypeError(f"Unsupported source dtype: {image.dtype}. Must be uint8, uint16, float16, or float32")
    
    # Compute bits from dtype. For ints: use itemsize*8. For floats: use -1 (default).
    if src_bits_per_element is None:
        src_bits = -1 if image.dtype in (np.float32, np.float64, np.float16) else image.dtype.itemsize * 8
    else:
        src_bits = int(src_bits_per_element)

    if dest_bits_per_element is None:
        dst_bits = -1 if dest_dtype in (np.float32, np.float64, np.float16) else dest_dtype.itemsize * 8
    else:
        dst_bits = int(dest_bits_per_element)
    
    # Early-out: same dtype, same bits, no clip, and not float16 output - return input unchanged
    # (float16 requires conversion back to float16 at the end, so can't early-out)
    if image.dtype == dest_dtype and src_bits == dst_bits and clip_max is None and not output_is_float16:
        return image
    
    # Use -1 for no clipping, else pass the clip value
    clip_value = -1.0 if clip_max is None else float(clip_max)
    
    # Call C++ implementation (handles both 2D and 3D)
    result = _raw_render.convert_dtype(
        image,
        dtype_to_npy[dest_dtype],
        src_bits,
        dst_bits,
        clip_value
    )
    
    # Convert back to float16 if that was the requested output
    if output_is_float16:
        result = result.astype(np.float16)
    
    return result


def compute_colorspace_matrix(
    source_space: ColorSpace,
    dest_space: ColorSpace
) -> np.ndarray | None:
    """Compute the colorspace conversion matrix.
    
    Computes the matrix for converting from source linear space to dest linear space,
    including chromatic adaptation if needed.
    
    Args:
        source_space: Source ColorSpace
        dest_space: Destination ColorSpace
        
    Returns:
        Matrix for converting from source linear to dest linear,
        or None if no conversion needed (same linear space)
    """
    # Get linear variants for matrix computation
    source_linear = source_space.to_linear()
    dest_linear = dest_space.to_linear()
    
    # No conversion needed if same linear space
    if source_linear == dest_linear:
        return None
    
    # ProPhoto (D50) ↔ sRGB (D65)
    if source_linear == ColorSpace.PROPHOTO_LINEAR and dest_linear == ColorSpace.SRGB_LINEAR:
        d50_to_d65 = compute_bradford_adaptation(D50_xy, D65_xy)
        return XYZ_D65_TO_SRGB @ d50_to_d65 @ PROPHOTO_RGB_TO_XYZ_D50
    elif source_linear == ColorSpace.SRGB_LINEAR and dest_linear == ColorSpace.PROPHOTO_LINEAR:
        d65_to_d50 = compute_bradford_adaptation(D65_xy, D50_xy)
        return XYZ_D50_TO_PROPHOTO_RGB @ d65_to_d50 @ SRGB_TO_XYZ_D65
    # ProPhoto (D50) ↔ Adobe RGB (D65)
    elif source_linear == ColorSpace.PROPHOTO_LINEAR and dest_linear == ColorSpace.ADOBERGB_LINEAR:
        d50_to_d65 = compute_bradford_adaptation(D50_xy, D65_xy)
        return XYZ_D65_TO_ADOBERGB @ d50_to_d65 @ PROPHOTO_RGB_TO_XYZ_D50
    elif source_linear == ColorSpace.ADOBERGB_LINEAR and dest_linear == ColorSpace.PROPHOTO_LINEAR:
        d65_to_d50 = compute_bradford_adaptation(D65_xy, D50_xy)
        return XYZ_D50_TO_PROPHOTO_RGB @ d65_to_d50 @ ADOBERGB_TO_XYZ_D65
    # sRGB (D65) ↔ Adobe RGB (D65) - same white point, no adaptation
    elif source_linear == ColorSpace.SRGB_LINEAR and dest_linear == ColorSpace.ADOBERGB_LINEAR:
        return XYZ_D65_TO_ADOBERGB @ SRGB_TO_XYZ_D65
    elif source_linear == ColorSpace.ADOBERGB_LINEAR and dest_linear == ColorSpace.SRGB_LINEAR:
        return XYZ_D65_TO_SRGB @ ADOBERGB_TO_XYZ_D65
    
    return None


def convert_colorspace(
    image: np.ndarray,
    source_space: ColorSpace,
    dest_space: ColorSpace,
    output_dtype: np.dtype = np.float32
) -> np.ndarray:
    """Convert image between color spaces with optional dtype conversion.
    
    Convenience wrapper around compute_colorspace_matrix + transform_color.
    Handles gamma decoding, matrix transforms, chromatic adaptation, and gamma encoding
    in a single fused pass for maximum performance.
    
    Args:
        image: Input image (H, W, 3) in source color space.
               Can be uint8 (0-255), uint16 (0-65535), float16 (0-1), or float32 (0-1).
        source_space: Source ColorSpace
        dest_space: Destination ColorSpace
        output_dtype: Output data type (np.uint8, np.uint16, np.float16, np.float32)
        
    Returns:
        Converted image (H, W, 3) in destination color space with output_dtype
    """
    output_dtype = np.dtype(output_dtype)
    
    if source_space == dest_space and image.dtype == output_dtype:
        return image
    
    # Handle float16 by converting to float32 for processing
    input_was_float16 = image.dtype == np.float16
    if input_was_float16:
        image = image.astype(np.float32)
    
    output_is_float16 = output_dtype == np.dtype(np.float16)
    if output_is_float16:
        output_dtype = np.dtype(np.float32)
    
    # Determine input LUT (gamma decode if needed)
    input_lut = None
    if source_space.is_gamma():
        # Use 8-bit LUT for uint8 input, otherwise 4096
        lut_size = 256 if image.dtype == np.uint8 else 4096
        input_lut = ColorSpaceLUT(source_space, inverse=True, size=lut_size)
    
    # Compute colorspace conversion matrix
    matrix = compute_colorspace_matrix(source_space, dest_space)
    
    # Determine output LUT (gamma encode if needed)
    output_lut = None
    if dest_space.is_gamma():
        output_lut = ColorSpaceLUT(dest_space, inverse=False, size=4096)
    
    # Use fused transform_color pipeline
    result = transform_color(
        image,
        input_lut=input_lut,
        matrix=matrix,
        output_lut=output_lut,
        output_dtype=output_dtype
    )
    
    # Convert back to float16 if requested
    if output_is_float16:
        result = result.astype(np.float16)
    
    return result


def transform_color(
    image: np.ndarray,
    input_lut: LUT | np.ndarray | None = None,
    matrix: np.ndarray | None = None,
    output_lut: LUT | np.ndarray | None = None,
    src_bits: int | None = None,
    dst_bits: int | None = None,
    output_dtype: np.dtype = np.float32,
    hue_preserving_input_lut: bool = False
) -> np.ndarray:
    """Apply fused LUT→Matrix→LUT color transformation pipeline.
    
    This is the recommended way to apply color transformations when you need
    to combine gamma decoding, color matrix, and gamma encoding in a single
    efficient pass.
    
    Args:
        image: Input image (H, W, 3), dtype: uint8, uint16, or float32
        input_lut: Optional input LUT for gamma decoding. Can be:
                   - LUT object (preferred - automatically converted to C array)
                   - np.ndarray with shape (N+1,) float32 (last value repeated)
                   Maps input values to [0, 1] range.
        matrix: Optional 3x3 color transformation matrix, float32.
                Applied in linear space after input LUT.
        output_lut: Optional output LUT for gamma encoding. Can be:
                    - LUT object (preferred - automatically converted to C array)
                    - np.ndarray with shape (N+1,) float32 (last value repeated)
                    Maps [0, 1] values to output range.
        src_bits: Source bit depth. If None, inferred from dtype
                  (8 for uint8, 16 for uint16, ignored for float32).
        dst_bits: Destination bit depth. If None, inferred from output_dtype.
        output_dtype: Output data type (np.uint8, np.uint16, or np.float32).
                      Default: np.float32
        hue_preserving_input_lut: If True, applies hue-preserving tone curve algorithm
                                  to the input LUT. Only supports float32 input/output.
                                  Requires input_lut. Default: False
    
    Returns:
        Transformed image (H, W, 3) with output_dtype
    
    Examples:
        >>> from muimg.splines import LUT
        >>> 
        >>> # Gamma decode only (12-bit → linear float) using LUT class
        >>> decode_lut = LUT(lambda x: x ** 2.2, size=4096)
        >>> linear = transform_color(raw_img, input_lut=decode_lut)
        
        >>> # Color matrix only
        >>> matrix = camera_to_xyz @ xyz_to_srgb
        >>> rgb = transform_color(linear_img, matrix=matrix)
        
        >>> # Full pipeline: decode → matrix → encode
        >>> decode_lut = LUT(lambda x: x ** 2.2, size=4096)
        >>> encode_lut = LUT(lambda x: x ** (1/2.2), size=4096)
        >>> result = transform_color(
        ...     raw_img,
        ...     input_lut=decode_lut,
        ...     matrix=color_matrix,
        ...     output_lut=encode_lut,
        ...     src_bits=12,
        ...     dst_bits=12,
        ...     output_dtype=np.uint16
        ... )
        
        >>> # Using raw numpy arrays (legacy API)
        >>> decode_arr = np.linspace(0, 1, 4096) ** 2.2
        >>> decode_arr = np.append(decode_arr, decode_arr[-1]).astype(np.float32)
        >>> linear = transform_color(raw_img, input_lut=decode_arr)
    
    Notes:
        - LUT objects are preferred - they automatically handle C array conversion
        - For numpy arrays, must have size+1 entries with last value repeated
        - For 8-bit input with 256-entry LUT, uses optimized direct lookup (no interpolation)
        - All operations are fused in a single pass for maximum cache efficiency
        - Processes in 128-pixel spans for optimal L1 cache usage
    """
    # Validate inputs
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError(f"Image must be (H, W, 3), got shape {image.shape}")
    
    if image.dtype not in (np.dtype(np.uint8), np.dtype(np.uint16), np.dtype(np.float32)):
        raise ValueError(f"Image dtype must be uint8, uint16, or float32, got {image.dtype}")
    
    # Ensure at least one transform is provided
    if input_lut is None and matrix is None and output_lut is None:
        raise ValueError("transform_color requires at least one of: input_lut, matrix, or output_lut")
    
    # Validate hue-preserving mode requirements
    if hue_preserving_input_lut:
        if input_lut is None:
            raise ValueError("hue_preserving_input_lut=True requires input_lut")
        if image.dtype != np.dtype(np.float32):
            raise ValueError(f"hue_preserving_input_lut=True requires float32 input, got {image.dtype}")
        # Float32 output only required for LUT-only case (no matrix)
        if matrix is None:
            if output_lut is not None:
                raise ValueError("hue_preserving_input_lut=True with no matrix requires no output_lut")
            if np.dtype(output_dtype) != np.dtype(np.float32):
                raise ValueError(f"hue_preserving_input_lut=True with no matrix requires float32 output, got {output_dtype}")
    
    # Extract LUT data arrays
    input_lut_array = None
    if input_lut is not None:
        if isinstance(input_lut, LUT):
            input_lut_array = input_lut.data
        elif isinstance(input_lut, np.ndarray):
            if input_lut.ndim != 1:
                raise ValueError(f"input_lut array must be 1D, got shape {input_lut.shape}")
            input_lut_array = input_lut.astype(np.float32)
        else:
            raise TypeError(f"input_lut must be LUT or ndarray, got {type(input_lut)}")
    
    output_lut_array = None
    if output_lut is not None:
        if isinstance(output_lut, LUT):
            output_lut_array = output_lut.data
        elif isinstance(output_lut, np.ndarray):
            if output_lut.ndim != 1:
                raise ValueError(f"output_lut array must be 1D, got shape {output_lut.shape}")
            output_lut_array = output_lut.astype(np.float32)
        else:
            raise TypeError(f"output_lut must be LUT or ndarray, got {type(output_lut)}")
    
    # Validate matrix if provided
    if matrix is not None:
        if matrix.shape != (3, 3):
            raise ValueError(f"matrix must be (3, 3), got shape {matrix.shape}")
        if matrix.dtype != np.float32:
            matrix = matrix.astype(np.float32)
    
    # Convert output_dtype to numpy dtype if needed
    if not isinstance(output_dtype, np.dtype):
        output_dtype = np.dtype(output_dtype)
    
    if output_dtype not in (np.dtype('uint8'), np.dtype('uint16'), np.dtype('float32')):
        raise ValueError(f"output_dtype must be uint8, uint16, or float32, got {output_dtype}")
    
    # Call C++ implementation
    return _raw_render.transform_color(
        image,
        input_lut=input_lut_array,
        matrix=matrix,
        output_lut=output_lut_array,
        src_bits=src_bits if src_bits is not None else -1,
        dst_bits=dst_bits if dst_bits is not None else -1,
        output_dtype=output_dtype,
        hue_preserving=hue_preserving_input_lut
    )


def clip_and_transform_color(
    image: np.ndarray,
    clip_max: np.ndarray,
    matrix: np.ndarray
) -> np.ndarray:
    """Clip RGB channels and apply 3x3 color matrix in single pass.
    
    Optimized for camera-to-ProPhoto RGB conversion where per-channel
    clipping to camera white point is needed before matrix transform.
    Eliminates temporary array allocation from np.minimum().
    
    Args:
        image: Input RGB image, float32, (H, W, 3)
        clip_max: Per-channel maximum values, float32, (3,)
        matrix: 3x3 color transformation matrix, float32, (3, 3)
    
    Returns:
        Transformed RGB image, float32, (H, W, 3)
    
    Examples:
        >>> # Camera to ProPhoto RGB with white point clipping
        >>> camera_white = np.array([1.0, 0.95, 0.98], dtype=np.float32)
        >>> camera_to_prophoto = compute_camera_to_prophoto_matrix()
        >>> rgb_prophoto = clip_and_transform_color(
        ...     rgb_camera, clip_max=camera_white, matrix=camera_to_prophoto)
    """
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError(f"Image must be (H, W, 3), got {image.shape}")
    if image.dtype != np.float32:
        raise ValueError(f"Image must be float32, got {image.dtype}")
    if clip_max.shape != (3,):
        raise ValueError(f"clip_max must be (3,), got {clip_max.shape}")
    if matrix.shape != (3, 3):
        raise ValueError(f"Matrix must be (3, 3), got {matrix.shape}")
    
    return _raw_render.clip_and_transform_color(
        image,
        clip_max=clip_max.astype(np.float32),
        matrix=matrix.astype(np.float32)
    )


def apply_tiff_orientation(image: np.ndarray, orientation: int) -> np.ndarray:
    """Apply TIFF/EXIF orientation rotation to an image.
    
    Args:
        image: Input image array (any shape with H, W as first two dims)
        orientation: TIFF orientation code
        
    Returns:
        Rotated image array
    """
    # Early return for horizontal (no rotation needed) - avoid importing cv2
    if orientation == Orientation.HORIZONTAL:
        return image
    
    timer = get_active_timer()
    timer.start_step("apply_tiff_orientation (opencv)")
    if orientation == Orientation.ROTATE_90_CW:
        result = cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE)
    elif orientation == Orientation.ROTATE_180:
        result = cv2.rotate(image, cv2.ROTATE_180)
    elif orientation == Orientation.ROTATE_270_CW:
        result = cv2.rotate(image, cv2.ROTATE_90_COUNTERCLOCKWISE)
    else:
        logger.warning(
            f"Unsupported TIFF orientation code: {orientation}; no rotation applied"
        )
        result = image
    timer.end_step()
    return result


def demosaic(
    image_data: np.ndarray,
    cfa_pattern: str,
    algorithm: DemosaicAlgorithm = DemosaicAlgorithm.OPENCV_EA,
    clip_max: float | None = None,
    return_dtype: np.dtype | None = None,
) -> np.ndarray:
    """Demosaic CFA data to RGB.

    Accepts uint8, uint16, or float32 input. Output dtype matches input dtype
    by default, or can be specified via return_dtype.
    Algorithms that don't support the input dtype will convert internally
    (with a warning logged).

    Args:
        image_data: 2D raw CFA data array (uint8, uint16, or float32)
        cfa_pattern: Bayer pattern string (RGGB, BGGR, GRBG, or GBRG)
        algorithm: Demosaic algorithm:
            - DemosaicAlgorithm.OPENCV_EA (default): Fastest, uint8/uint16 only
            - DemosaicAlgorithm.VNG: Variable Number of Gradients, uint16 only
            - DemosaicAlgorithm.RCD: Best quality/speed, supports float32 natively (optional dependency)
            - DemosaicAlgorithm.DNGSDK_BILINEAR: DNG SDK bilinear, float32 only
        clip_max: Optional max value to clip output to (e.g., 1.0 for float32)
        return_dtype: Optional output dtype. If None, matches input dtype.
    Returns:
        RGB array with dtype matching return_dtype or input dtype
    """
    # Validate inputs
    if image_data.ndim != 2:
        raise ValueError(
            f"image_data must be a 2D array, but got {image_data.ndim} dimensions."
        )
    if image_data.size == 0:
        raise ValueError("image_data must not be empty.")
    
    if not isinstance(cfa_pattern, str):
        raise TypeError(
            f"cfa_pattern must be a string, but got {type(cfa_pattern).__name__}."
        )
    
    # Validate CFA pattern
    valid_patterns = ["RGGB", "BGGR", "GRBG", "GBRG"]
    if cfa_pattern not in valid_patterns:
        raise ValueError(
            f"Invalid CFA pattern: '{cfa_pattern}'. "
            f"Supported patterns are: {valid_patterns}."
        )
    
    # Validate algorithm
    if not isinstance(algorithm, DemosaicAlgorithm):
        raise TypeError(
            f"algorithm must be a DemosaicAlgorithm enum, but got {type(algorithm).__name__}. "
            f"Supported algorithms are: {list(DemosaicAlgorithm)}."
        )

    input_dtype = image_data.dtype
    output_dtype = return_dtype if return_dtype is not None else input_dtype
    timer = get_active_timer()

    if algorithm == DemosaicAlgorithm.DNGSDK_BILINEAR:
        cfa_codes = get_cfa_pattern_codes(cfa_pattern)
        timer.start_step("convert_dtype (pre)")
        data_f32 = convert_dtype(image_data, np.float32)  # bilinear expects float32
        timer.start_step("bilinear_demosaic (c++)")
        rgb = _raw_render.bilinear_demosaic(data_f32, np.array(cfa_codes, dtype=np.int32))
        timer.end_step()

    elif algorithm == DemosaicAlgorithm.RCD:
        # RCD: float32 kernel (expects 0-1 normalized data)
        # RCD is GPL-licensed and optional - see README for setup instructions
        try:
            from . import _rcd
        except ImportError:
            raise ImportError(
                "RCD demosaicing is not available. RCD is GPL-licensed and must be "
                "enabled separately. See README.md for instructions to enable RCD, "
                "or use a different algorithm (VNG, OPENCV_EA, DNGSDK_BILINEAR)."
            )
        timer.start_step("convert_dtype (pre)")
        data_f32 = convert_dtype(image_data, np.float32)  # RCD expects float32 in 0-1 range
        timer.start_step("rcd_demosaic (c++)")
        rgb = _rcd.rcd_demosaic(data_f32, cfa_pattern)
        timer.end_step()

    elif algorithm == DemosaicAlgorithm.VNG:
        # VNG: uint16 kernel
        if input_dtype in (np.float32, np.float64):
            logger.debug(f"VNG requires uint16; converting from {input_dtype}")
        from . import _vng
        timer.start_step("convert_dtype (pre)")
        data_u16 = convert_dtype(image_data, np.uint16)  # VNG expects uint16
        timer.start_step("vng_demosaic (c++)")
        rgb = _vng.vng_demosaic(data_u16, cfa_pattern)
        timer.end_step()

    elif algorithm == DemosaicAlgorithm.OPENCV_EA:
        # Swapped Bayer patterns produce output compatible with pipeline
        # Avoids costly [..., [2, 1, 0]] channel reordering after demosaicing
        bayer_map_bgr = {
            "RGGB": cv2.COLOR_BAYER_BG2RGB_EA,  # RGGB→BGR
            "BGGR": cv2.COLOR_BAYER_RG2RGB_EA,  # BGGR→BGR
            "GRBG": cv2.COLOR_BAYER_GB2RGB_EA,  # GRBG→BGR
            "GBRG": cv2.COLOR_BAYER_GR2RGB_EA,  # GBRG→BGR
        }
        if input_dtype in (np.float32, np.float64):
            logger.debug(f"OPENCV_EA requires uint8/uint16; converting from {input_dtype}")
            timer.start_step("convert_dtype (pre)")
            data_u16 = convert_dtype(image_data, np.uint16)

            # demosaic output: (h, w, 3) uint16
            timer.start_step("ea_demosaicing (opencv)")
            rgb = cv2.demosaicing(data_u16, bayer_map_bgr[cfa_pattern])
            timer.end_step()
        else:
            timer.start_step("ea_demosaicing (opencv)")
            rgb = cv2.demosaicing(image_data, bayer_map_bgr[cfa_pattern])  # BGR output
            timer.end_step()

    else:
        raise ValueError(f"Unsupported demosaic algorithm: {algorithm}")

    timer.start_step("convert_dtype (post)")
    rgb = convert_dtype(rgb, output_dtype, clip_max=clip_max)
    timer.end_step()

    return rgb

# =============================================================================
# DNG SDK Port (Python + C++ Extension)
# =============================================================================
# Everything below is a port of the Adobe DNG SDK 1.7.1 color pipeline.
# C++ implementation in c-src/raw_render/raw_render_ops.cpp
#
# Key SDK source files referenced:
#   - dng_color_spec.cpp: SetWhiteXY(), NeutralToXY(), FindXYZtoCamera()
#   - dng_render.cpp: dng_render_task::Start() for fCameraToRGB computation
#   - dng_color_spec.cpp: MapWhiteMatrix() for Bradford chromatic adaptation
#   - dng_reference.cpp: RefBaselineRGBTone() for hue-preserving tone mapping
#   - dng_ifd.cpp: Black/white level defaults and parsing
#   - dng_linearization_info.cpp: normalize_black_white implementation
# =============================================================================

class UnsupportedDNGTagError(Exception):
    """Raised when a DNG file contains tags that the rendering pipeline cannot handle."""
    pass

def validate_dng_tags(page: "DngPage", strict: bool = True) -> list[str]:
    """Check for DNG tags that we don't currently support in our rendering pipeline.
    
    Args:
        page: DngPage to validate
        strict: If True, raise UnsupportedDNGTagError on finding unsupported tags.
                If False, return list of unsupported tag names.
    
    Returns:
        List of unsupported tag names found (empty if none)
        
    Raises:
        UnsupportedDNGTagError: If strict=True and unsupported tags are found
    """
    # DNG tags that affect rendering but are NOT implemented in our rendering pipeline
    # Based on Adobe DNG SDK 1.7.1 - COMPREHENSIVE LIST
    # These tags would cause our output to differ from the SDK reference
    # Tag names match tifffile's tag name mapping
    unsupported_rendering_tags = {
        # currently do not support illuminantdata
        "IlluminantData1",
        "IlluminantData2",
        # Triple illuminant support (DNG 1.6+) - we only support dual illuminant
        "ColorMatrix3",
        "CalibrationIlluminant3",
        "CameraCalibration3",
        "ForwardMatrix3",
        "ProfileHueSatMapData3",
        "IlluminantData3",
        # Reduction matrices (for >3 color channels)
        "ReductionMatrix1",
        "ReductionMatrix2",
        "ReductionMatrix3",
        # Opcode lists (lens corrections, gain maps, warp, etc.)
        # OpcodeList1 (pre-linearization CFA): SUPPORTED - FixBadPixelsConstant, MapPolynomial, GainMap
        # OpcodeList2 (post-linearization CFA): SUPPORTED - MapPolynomial, GainMap
        # OpcodeList3 (post-demosaic RGB): SUPPORTED - WarpRectilinear, FixVignetteRadial, MapPolynomial, GainMap
        # RGB Tables (DNG 1.6+)
        "RGBTables",
        # Semantic masks and depth maps (DNG 1.6+)
        "SemanticName",
        "SemanticInstanceID",
        "MaskSubArea",
        "DepthFormat",
        "DepthNear",
        "DepthFar",
        "DepthUnits",
        "DepthMeasureType",
        # HDR / overrange support
        "ProfileDynamicRange",  # HDR profile indicator
        # Image enhancement flags that may affect rendering interpretation
        "EnhanceParams",  # Enhanced image parameters
    }
    
    found_unsupported = []
    
    for tag_name in unsupported_rendering_tags:
        if page.get_tag(tag_name) is not None:
            found_unsupported.append(tag_name)
    
    if found_unsupported and strict:
        raise UnsupportedDNGTagError(
            f"DNG contains unsupported rendering tags: {', '.join(found_unsupported)}. "
            f"Output will differ from SDK reference. "
            f"Use strict=False to process anyway."
        )
    
    return found_unsupported

# Adobe DNG temperature/tint conversion (exact port of dng_temperature.cpp)
# Source: /3dparty/dng_sdk_1_7_1/dng_sdk/source/dng_temperature.cpp
_K_TINT_SCALE = -3000.0  # kTintScale

# Table from Wyszecki & Stiles, "Color Science" (same values as kTempTable in DNG SDK)
# Each tuple: (r, u, v, t)
_K_TEMP_TABLE = [
    (0.0,   0.18006, 0.26352,  -0.24341),
    (10.0,  0.18066, 0.26589,  -0.25479),
    (20.0,  0.18133, 0.26846,  -0.26876),
    (30.0,  0.18208, 0.27119,  -0.28539),
    (40.0,  0.18293, 0.27407,  -0.30470),
    (50.0,  0.18388, 0.27709,  -0.32675),
    (60.0,  0.18494, 0.28021,  -0.35156),
    (70.0,  0.18611, 0.28342,  -0.37915),
    (80.0,  0.18740, 0.28668,  -0.40955),
    (90.0,  0.18880, 0.28997,  -0.44278),
    (100.0, 0.19032, 0.29326,  -0.47888),
    (125.0, 0.19462, 0.30141,  -0.58204),
    (150.0, 0.19962, 0.30921,  -0.70471),
    (175.0, 0.20525, 0.31647,  -0.84901),
    (200.0, 0.21142, 0.32312,  -1.0182),
    (225.0, 0.21807, 0.32909,  -1.2168),
    (250.0, 0.22511, 0.33439,  -1.4512),
    (275.0, 0.23247, 0.33904,  -1.7298),
    (300.0, 0.24010, 0.34308,  -2.0637),
    (325.0, 0.24702, 0.34655,  -2.4681),
    (350.0, 0.25591, 0.34951,  -2.9641),
    (375.0, 0.26400, 0.35200,  -3.5814),
    (400.0, 0.27218, 0.35407,  -4.3633),
    (425.0, 0.28039, 0.35577,  -5.3762),
    (450.0, 0.28863, 0.35714,  -6.7262),
    (475.0, 0.29685, 0.35823,  -8.5955),
    (500.0, 0.30505, 0.35907, -11.3240),
    (525.0, 0.31320, 0.35968, -15.6280),
    (550.0, 0.32129, 0.36011, -23.3250),
    (575.0, 0.32931, 0.36038, -40.7700),
    (600.0, 0.33724, 0.36051,-116.4500),
]

# ACR3 Default Tone Curve (from dng_render.cpp dng_tone_curve_acr3_default::Evaluate)
# 257 entries, input [0,1] maps to output [0,1]
_ACR3_TONE_CURVE = np.array([
    0.00000, 0.00078, 0.00160, 0.00242, 0.00314, 0.00385, 0.00460, 0.00539,
    0.00623, 0.00712, 0.00806, 0.00906, 0.01012, 0.01122, 0.01238, 0.01359,
    0.01485, 0.01616, 0.01751, 0.01890, 0.02033, 0.02180, 0.02331, 0.02485,
    0.02643, 0.02804, 0.02967, 0.03134, 0.03303, 0.03475, 0.03648, 0.03824,
    0.04002, 0.04181, 0.04362, 0.04545, 0.04730, 0.04916, 0.05103, 0.05292,
    0.05483, 0.05675, 0.05868, 0.06063, 0.06259, 0.06457, 0.06655, 0.06856,
    0.07057, 0.07259, 0.07463, 0.07668, 0.07874, 0.08081, 0.08290, 0.08499,
    0.08710, 0.08921, 0.09134, 0.09348, 0.09563, 0.09779, 0.09996, 0.10214,
    0.10433, 0.10652, 0.10873, 0.11095, 0.11318, 0.11541, 0.11766, 0.11991,
    0.12218, 0.12445, 0.12673, 0.12902, 0.13132, 0.13363, 0.13595, 0.13827,
    0.14061, 0.14295, 0.14530, 0.14765, 0.15002, 0.15239, 0.15477, 0.15716,
    0.15956, 0.16197, 0.16438, 0.16680, 0.16923, 0.17166, 0.17410, 0.17655,
    0.17901, 0.18148, 0.18395, 0.18643, 0.18891, 0.19141, 0.19391, 0.19641,
    0.19893, 0.20145, 0.20398, 0.20651, 0.20905, 0.21160, 0.21416, 0.21672,
    0.21929, 0.22185, 0.22440, 0.22696, 0.22950, 0.23204, 0.23458, 0.23711,
    0.23963, 0.24215, 0.24466, 0.24717, 0.24967, 0.25216, 0.25465, 0.25713,
    0.25961, 0.26208, 0.26454, 0.26700, 0.26945, 0.27189, 0.27433, 0.27676,
    0.27918, 0.28160, 0.28401, 0.28641, 0.28881, 0.29120, 0.29358, 0.29596,
    0.29833, 0.30069, 0.30305, 0.30540, 0.30774, 0.31008, 0.31241, 0.31473,
    0.31704, 0.31935, 0.32165, 0.32395, 0.32623, 0.32851, 0.33079, 0.33305,
    0.33531, 0.33756, 0.33981, 0.34205, 0.34428, 0.34650, 0.34872, 0.35093,
    0.35313, 0.35532, 0.35751, 0.35969, 0.36187, 0.36404, 0.36620, 0.36835,
    0.37050, 0.37264, 0.37477, 0.37689, 0.37901, 0.38112, 0.38323, 0.38533,
    0.38742, 0.38950, 0.39158, 0.39365, 0.39571, 0.39777, 0.39982, 0.40186,
    0.40389, 0.40592, 0.40794, 0.40996, 0.41197, 0.41397, 0.41596, 0.41795,
    0.41993, 0.42191, 0.42388, 0.42584, 0.42779, 0.42974, 0.43168, 0.43362,
    0.43554, 0.43747, 0.43938, 0.44129, 0.44319, 0.44509, 0.44698, 0.44886,
    0.45073, 0.45260, 0.45447, 0.45632, 0.45817, 0.46002, 0.46186, 0.46369,
    0.46551, 0.46733, 0.46914, 0.47095, 0.47275, 0.47454, 0.47633, 0.47811,
    0.47989, 0.48166, 0.48342, 0.48518, 0.48693, 0.48867, 0.49041, 0.49214,
    0.49387, 0.49559, 0.49730, 0.49901, 0.50072, 0.50241, 0.50410, 0.50579,
    0.50747, 0.50914, 0.51081, 0.51247, 0.51413, 0.51578, 0.51742, 0.51906,
    0.52069, 0.52232, 0.52394, 0.52556, 0.52717, 0.52878, 0.53038, 0.53197,
    0.53356, 0.53514, 0.53672, 0.53829, 0.53986, 0.54142, 0.54297, 0.54452,
    0.54607, 0.54761, 0.54914, 0.55067, 0.55220, 0.55371, 0.55523, 0.55673,
    0.55824, 0.55973, 0.56123, 0.56271, 0.56420, 0.56567, 0.56715, 0.56861,
    0.57007, 0.57153, 0.57298, 0.57443, 0.57587, 0.57731, 0.57874, 0.58017,
    0.58159, 0.58301, 0.58443, 0.58583, 0.58724, 0.58864, 0.59003, 0.59142,
    0.59281, 0.59419, 0.59556, 0.59694, 0.59830, 0.59966, 0.60102, 0.60238,
    0.60373, 0.60507, 0.60641, 0.60775, 0.60908, 0.61040, 0.61173, 0.61305,
    0.61436, 0.61567, 0.61698, 0.61828, 0.61957, 0.62087, 0.62216, 0.62344,
    0.62472, 0.62600, 0.62727, 0.62854, 0.62980, 0.63106, 0.63232, 0.63357,
    0.63482, 0.63606, 0.63730, 0.63854, 0.63977, 0.64100, 0.64222, 0.64344,
    0.64466, 0.64587, 0.64708, 0.64829, 0.64949, 0.65069, 0.65188, 0.65307,
    0.65426, 0.65544, 0.65662, 0.65779, 0.65897, 0.66013, 0.66130, 0.66246,
    0.66362, 0.66477, 0.66592, 0.66707, 0.66821, 0.66935, 0.67048, 0.67162,
    0.67275, 0.67387, 0.67499, 0.67611, 0.67723, 0.67834, 0.67945, 0.68055,
    0.68165, 0.68275, 0.68385, 0.68494, 0.68603, 0.68711, 0.68819, 0.68927,
    0.69035, 0.69142, 0.69249, 0.69355, 0.69461, 0.69567, 0.69673, 0.69778,
    0.69883, 0.69988, 0.70092, 0.70196, 0.70300, 0.70403, 0.70506, 0.70609,
    0.70711, 0.70813, 0.70915, 0.71017, 0.71118, 0.71219, 0.71319, 0.71420,
    0.71520, 0.71620, 0.71719, 0.71818, 0.71917, 0.72016, 0.72114, 0.72212,
    0.72309, 0.72407, 0.72504, 0.72601, 0.72697, 0.72794, 0.72890, 0.72985,
    0.73081, 0.73176, 0.73271, 0.73365, 0.73460, 0.73554, 0.73647, 0.73741,
    0.73834, 0.73927, 0.74020, 0.74112, 0.74204, 0.74296, 0.74388, 0.74479,
    0.74570, 0.74661, 0.74751, 0.74842, 0.74932, 0.75021, 0.75111, 0.75200,
    0.75289, 0.75378, 0.75466, 0.75555, 0.75643, 0.75730, 0.75818, 0.75905,
    0.75992, 0.76079, 0.76165, 0.76251, 0.76337, 0.76423, 0.76508, 0.76594,
    0.76679, 0.76763, 0.76848, 0.76932, 0.77016, 0.77100, 0.77183, 0.77267,
    0.77350, 0.77432, 0.77515, 0.77597, 0.77680, 0.77761, 0.77843, 0.77924,
    0.78006, 0.78087, 0.78167, 0.78248, 0.78328, 0.78408, 0.78488, 0.78568,
    0.78647, 0.78726, 0.78805, 0.78884, 0.78962, 0.79040, 0.79118, 0.79196,
    0.79274, 0.79351, 0.79428, 0.79505, 0.79582, 0.79658, 0.79735, 0.79811,
    0.79887, 0.79962, 0.80038, 0.80113, 0.80188, 0.80263, 0.80337, 0.80412,
    0.80486, 0.80560, 0.80634, 0.80707, 0.80780, 0.80854, 0.80926, 0.80999,
    0.81072, 0.81144, 0.81216, 0.81288, 0.81360, 0.81431, 0.81503, 0.81574,
    0.81645, 0.81715, 0.81786, 0.81856, 0.81926, 0.81996, 0.82066, 0.82135,
    0.82205, 0.82274, 0.82343, 0.82412, 0.82480, 0.82549, 0.82617, 0.82685,
    0.82753, 0.82820, 0.82888, 0.82955, 0.83022, 0.83089, 0.83155, 0.83222,
    0.83288, 0.83354, 0.83420, 0.83486, 0.83552, 0.83617, 0.83682, 0.83747,
    0.83812, 0.83877, 0.83941, 0.84005, 0.84069, 0.84133, 0.84197, 0.84261,
    0.84324, 0.84387, 0.84450, 0.84513, 0.84576, 0.84639, 0.84701, 0.84763,
    0.84825, 0.84887, 0.84949, 0.85010, 0.85071, 0.85132, 0.85193, 0.85254,
    0.85315, 0.85375, 0.85436, 0.85496, 0.85556, 0.85615, 0.85675, 0.85735,
    0.85794, 0.85853, 0.85912, 0.85971, 0.86029, 0.86088, 0.86146, 0.86204,
    0.86262, 0.86320, 0.86378, 0.86435, 0.86493, 0.86550, 0.86607, 0.86664,
    0.86720, 0.86777, 0.86833, 0.86889, 0.86945, 0.87001, 0.87057, 0.87113,
    0.87168, 0.87223, 0.87278, 0.87333, 0.87388, 0.87443, 0.87497, 0.87552,
    0.87606, 0.87660, 0.87714, 0.87768, 0.87821, 0.87875, 0.87928, 0.87981,
    0.88034, 0.88087, 0.88140, 0.88192, 0.88244, 0.88297, 0.88349, 0.88401,
    0.88453, 0.88504, 0.88556, 0.88607, 0.88658, 0.88709, 0.88760, 0.88811,
    0.88862, 0.88912, 0.88963, 0.89013, 0.89063, 0.89113, 0.89163, 0.89212,
    0.89262, 0.89311, 0.89360, 0.89409, 0.89458, 0.89507, 0.89556, 0.89604,
    0.89653, 0.89701, 0.89749, 0.89797, 0.89845, 0.89892, 0.89940, 0.89987,
    0.90035, 0.90082, 0.90129, 0.90176, 0.90222, 0.90269, 0.90316, 0.90362,
    0.90408, 0.90454, 0.90500, 0.90546, 0.90592, 0.90637, 0.90683, 0.90728,
    0.90773, 0.90818, 0.90863, 0.90908, 0.90952, 0.90997, 0.91041, 0.91085,
    0.91130, 0.91173, 0.91217, 0.91261, 0.91305, 0.91348, 0.91392, 0.91435,
    0.91478, 0.91521, 0.91564, 0.91606, 0.91649, 0.91691, 0.91734, 0.91776,
    0.91818, 0.91860, 0.91902, 0.91944, 0.91985, 0.92027, 0.92068, 0.92109,
    0.92150, 0.92191, 0.92232, 0.92273, 0.92314, 0.92354, 0.92395, 0.92435,
    0.92475, 0.92515, 0.92555, 0.92595, 0.92634, 0.92674, 0.92713, 0.92753,
    0.92792, 0.92831, 0.92870, 0.92909, 0.92947, 0.92986, 0.93025, 0.93063,
    0.93101, 0.93139, 0.93177, 0.93215, 0.93253, 0.93291, 0.93328, 0.93366,
    0.93403, 0.93440, 0.93478, 0.93515, 0.93551, 0.93588, 0.93625, 0.93661,
    0.93698, 0.93734, 0.93770, 0.93807, 0.93843, 0.93878, 0.93914, 0.93950,
    0.93986, 0.94021, 0.94056, 0.94092, 0.94127, 0.94162, 0.94197, 0.94231,
    0.94266, 0.94301, 0.94335, 0.94369, 0.94404, 0.94438, 0.94472, 0.94506,
    0.94540, 0.94573, 0.94607, 0.94641, 0.94674, 0.94707, 0.94740, 0.94774,
    0.94807, 0.94839, 0.94872, 0.94905, 0.94937, 0.94970, 0.95002, 0.95035,
    0.95067, 0.95099, 0.95131, 0.95163, 0.95194, 0.95226, 0.95257, 0.95289,
    0.95320, 0.95351, 0.95383, 0.95414, 0.95445, 0.95475, 0.95506, 0.95537,
    0.95567, 0.95598, 0.95628, 0.95658, 0.95688, 0.95718, 0.95748, 0.95778,
    0.95808, 0.95838, 0.95867, 0.95897, 0.95926, 0.95955, 0.95984, 0.96013,
    0.96042, 0.96071, 0.96100, 0.96129, 0.96157, 0.96186, 0.96214, 0.96242,
    0.96271, 0.96299, 0.96327, 0.96355, 0.96382, 0.96410, 0.96438, 0.96465,
    0.96493, 0.96520, 0.96547, 0.96574, 0.96602, 0.96629, 0.96655, 0.96682,
    0.96709, 0.96735, 0.96762, 0.96788, 0.96815, 0.96841, 0.96867, 0.96893,
    0.96919, 0.96945, 0.96971, 0.96996, 0.97022, 0.97047, 0.97073, 0.97098,
    0.97123, 0.97149, 0.97174, 0.97199, 0.97223, 0.97248, 0.97273, 0.97297,
    0.97322, 0.97346, 0.97371, 0.97395, 0.97419, 0.97443, 0.97467, 0.97491,
    0.97515, 0.97539, 0.97562, 0.97586, 0.97609, 0.97633, 0.97656, 0.97679,
    0.97702, 0.97725, 0.97748, 0.97771, 0.97794, 0.97817, 0.97839, 0.97862,
    0.97884, 0.97907, 0.97929, 0.97951, 0.97973, 0.97995, 0.98017, 0.98039,
    0.98061, 0.98082, 0.98104, 0.98125, 0.98147, 0.98168, 0.98189, 0.98211,
    0.98232, 0.98253, 0.98274, 0.98295, 0.98315, 0.98336, 0.98357, 0.98377,
    0.98398, 0.98418, 0.98438, 0.98458, 0.98478, 0.98498, 0.98518, 0.98538,
    0.98558, 0.98578, 0.98597, 0.98617, 0.98636, 0.98656, 0.98675, 0.98694,
    0.98714, 0.98733, 0.98752, 0.98771, 0.98789, 0.98808, 0.98827, 0.98845,
    0.98864, 0.98882, 0.98901, 0.98919, 0.98937, 0.98955, 0.98973, 0.98991,
    0.99009, 0.99027, 0.99045, 0.99063, 0.99080, 0.99098, 0.99115, 0.99133,
    0.99150, 0.99167, 0.99184, 0.99201, 0.99218, 0.99235, 0.99252, 0.99269,
    0.99285, 0.99302, 0.99319, 0.99335, 0.99351, 0.99368, 0.99384, 0.99400,
    0.99416, 0.99432, 0.99448, 0.99464, 0.99480, 0.99495, 0.99511, 0.99527,
    0.99542, 0.99558, 0.99573, 0.99588, 0.99603, 0.99619, 0.99634, 0.99649,
    0.99664, 0.99678, 0.99693, 0.99708, 0.99722, 0.99737, 0.99751, 0.99766,
    0.99780, 0.99794, 0.99809, 0.99823, 0.99837, 0.99851, 0.99865, 0.99879,
    0.99892, 0.99906, 0.99920, 0.99933, 0.99947, 0.99960, 0.99974, 0.99987,
    1.00000
], dtype=np.float32)


def get_acr3_curve(num_points: int = 256) -> np.ndarray:
    """Get the ACR3 default tone curve as a lookup table.

    This is a pure Python replacement for _raw_render.get_acr3_curve().

    Args:
        num_points: Number of points in the output LUT (default: 256)

    Returns:
        1D numpy array of tone curve values, float32
    """
    if num_points < 2:
        raise ValueError("num_points must be at least 2")

    # Interpolate from 257-point table to requested size
    x_out = np.linspace(0.0, 1.0, num_points)
    x_table = np.linspace(0.0, 1.0, len(_ACR3_TONE_CURVE))
    return np.interp(x_out, x_table, _ACR3_TONE_CURVE).astype(np.float32)


def uv_to_colortemp(u: float, v: float) -> tuple[float, float]:
    """Exact port of dng_temperature::Set_xy_coord but accepting CIE 1960 (u,v).

    Given CIE 1960 UCS coordinates (u, v), compute correlated color temperature (Kelvin)
    and tint (Adobe's scale). Returns (temperature, tint).

    Note: CIE 1960 (u, v) is considered an "obsolete" color space; see:
    https://en.wikipedia.org/wiki/CIE_1960_color_space
    """

    last_dt = 0.0
    last_du = 0.0
    last_dv = 0.0

    # Using indices like C++: 1..30 inclusive; kTempTable has at least 31 entries (0..30)
    temp = 0.0
    tint = 0.0
    for index in range(1, 31):
        # Convert slope to delta-u and delta-v, with length 1.
        du = 1.0
        dv = _K_TEMP_TABLE[index][3]
        length = float(np.sqrt(1.0 + dv * dv))
        du /= length
        dv /= length

        # Delta from black body point to test coordinate
        uu = u - _K_TEMP_TABLE[index][1]
        vv = v - _K_TEMP_TABLE[index][2]

        # Distance above or below line
        dt = -uu * dv + vv * du

        # If below line, we have found line pair
        if dt <= 0.0 or index == 30:
            if dt > 0.0:
                dt = 0.0
            dt = -dt

            if index == 1:
                f = 0.0
            else:
                f = dt / (last_dt + dt) if (last_dt + dt) != 0.0 else 0.0

            # Interpolate the temperature (note: table stores r = 1e6/T)
            r_interp = (_K_TEMP_TABLE[index - 1][0] * f +
                        _K_TEMP_TABLE[index][0] * (1.0 - f))
            if r_interp == 0.0:
                temp = float('inf')
            else:
                temp = 1.0e6 / r_interp

            # Delta from interpolated black body point
            u_bb = (_K_TEMP_TABLE[index - 1][1] * f +
                    _K_TEMP_TABLE[index][1] * (1.0 - f))
            v_bb = (_K_TEMP_TABLE[index - 1][2] * f +
                    _K_TEMP_TABLE[index][2] * (1.0 - f))
            uu = u - u_bb
            vv = v - v_bb

            # Interpolate vectors along slope
            du = du * (1.0 - f) + last_du * f
            dv = dv * (1.0 - f) + last_dv * f
            length = float(np.sqrt(du * du + dv * dv))
            if length != 0.0:
                du /= length
                dv /= length

            # Distance along slope => tint
            tint = (uu * du + vv * dv) * _K_TINT_SCALE
            break

        # Try next line pair; carry forward state
        last_dt = dt
        last_du = du
        last_dv = dv

    return float(temp), float(tint)


def colortemp_to_uv(temperature: float, tint: float) -> tuple[float, float]:
    """Exact port of dng_temperature::Get_xy_coord but returning CIE 1960 (u,v).

    Given color temperature (Kelvin) and tint (Adobe's scale), compute CIE 1960 UCS (u, v).
    Returns (u, v).

    Note: CIE 1960 (u, v) is considered an "obsolete" color space; see:
    https://en.wikipedia.org/wiki/CIE_1960_color_space
    """
    # Inverse temperature to index table (r = 1e6 / T)
    r = 1.0e6 / float(temperature)

    # Convert tint to offset in uv space
    offset = float(tint) * (1.0 / _K_TINT_SCALE)

    u = 0.0
    v = 0.0
    for index in range(0, 30):
        if r < _K_TEMP_TABLE[index + 1][0] or index == 29:
            # Relative weight of first line
            denom = (_K_TEMP_TABLE[index + 1][0] - _K_TEMP_TABLE[index][0])
            f = ((_K_TEMP_TABLE[index + 1][0] - r) / denom) if denom != 0.0 else 0.0

            # Interpolate black body coordinates in uv
            u = _K_TEMP_TABLE[index][1] * f + _K_TEMP_TABLE[index + 1][1] * (1.0 - f)
            v = _K_TEMP_TABLE[index][2] * f + _K_TEMP_TABLE[index + 1][2] * (1.0 - f)

            # Find vectors along slope for each line and normalize
            uu1 = 1.0
            vv1 = _K_TEMP_TABLE[index][3]
            uu2 = 1.0
            vv2 = _K_TEMP_TABLE[index + 1][3]
            len1 = float(np.sqrt(1.0 + vv1 * vv1))
            len2 = float(np.sqrt(1.0 + vv2 * vv2))
            if len1 != 0.0:
                uu1 /= len1
                vv1 /= len1
            if len2 != 0.0:
                uu2 /= len2
                vv2 /= len2

            # Vector from black body point and normalize
            uu3 = uu1 * f + uu2 * (1.0 - f)
            vv3 = vv1 * f + vv2 * (1.0 - f)
            len3 = float(np.sqrt(uu3 * uu3 + vv3 * vv3))
            if len3 != 0.0:
                uu3 /= len3
                vv3 /= len3

            # Adjust coordinate along this vector by offset
            u += uu3 * offset
            v += vv3 * offset

            # Return u,v directly (xy conversion provided by helper if needed)
            return float(u), float(v)

    # Fallback (should not happen if table covers range)
    return float(u), float(v)


def uvUCS_to_xy(u: float, v: float) -> tuple[float, float]:
    """Convert CIE 1960 UCS (u, v) to CIE 1931 (x, y).

    Uses the exact formulas extracted from the DNG SDK method port.
    """
    denom_xy = (u - 4.0 * v + 2.0)
    x = 1.5 * u / denom_xy
    y = v / denom_xy
    return float(x), float(y)

def xy_to_uvUCS(x: float, y: float) -> tuple[float, float]:
    """Convert CIE 1931 (x, y) to CIE 1960 UCS (u, v).

    Uses the exact formulas extracted from the DNG SDK method port.
    """
    denom = (1.5 - x + 6.0 * y)
    u = 2.0 * x / denom
    v = 3.0 * y / denom
    return float(u), float(v)


def temp_tint_to_xy(temperature: float, tint: float) -> tuple[float, float]:
    """Convert color temperature and tint to CIE 1931 (x, y) chromaticity.

    This is a pure Python replacement for _raw_render.temp_to_xy().

    Args:
        temperature: Color temperature in Kelvin (1667-25000)
        tint: Green/magenta tint (-150 to +150)

    Returns:
        Tuple of (x, y) chromaticity coordinates
    """
    u, v = colortemp_to_uv(temperature, tint)
    return uvUCS_to_xy(u, v)


def xy_to_temp_tint(x: float, y: float) -> tuple[float, float]:
    """Convert CIE 1931 (x, y) chromaticity to color temperature and tint.

    This is a pure Python replacement for _raw_render.xy_to_temp().

    Args:
        x: x chromaticity coordinate
        y: y chromaticity coordinate

    Returns:
        Tuple of (temperature, tint)
    """
    u, v = xy_to_uvUCS(x, y)
    return uv_to_colortemp(u, v)

def XYZ_to_YuvUCS(image: np.ndarray) -> np.ndarray:
    """Convert packed XYZ image/array to packed Y,u,v (CIE 1960 UCS).

    Input is a numpy array with last dimension of size 3 ordered as (X, Y, Z).
    Output has the same shape with last dimension (Y, u, v) where:
      u = 4X / (X + 15Y + 3Z)
      v = 6Y / (X + 15Y + 3Z)

    The dtype of the input is preserved in the output.
    """
    if image is None:
        raise ValueError("image must be a numpy array with last dimension 3 (X,Y,Z)")
    if image.ndim < 1 or image.shape[-1] != 3:
        raise ValueError(f"Expected last dimension to be 3 for (X,Y,Z), got shape {image.shape}")

    X = image[..., 0]
    Y = image[..., 1]
    Z = image[..., 2]

    denom = X + 15.0 * Y + 3.0 * Z
    # Avoid divide-by-zero; use small epsilon for denom==0
    eps = 1e-4
    safe = denom != 0
    denom_safe = np.where(safe, denom, eps)

    u = (4.0 * X) / denom_safe
    v = (6.0 * Y) / denom_safe

    # Pack as (Y, u, v)
    yuv = np.stack([Y, u, v], axis=-1)
    return yuv.astype(image.dtype, copy=False)

# =============================================================================
# DNG Illuminant Handling (CalibrationIlluminant1/2/3)
# =============================================================================

def interpolate_color_matrix(
    color_matrix1: np.ndarray,
    color_matrix2: np.ndarray,
    temp1: float,
    temp2: float,
    scene_temp: float
) -> np.ndarray:
    """Interpolate between two color matrices based on scene temperature.
    
    SDK ref: dng_color_spec.cpp FindXYZtoCamera_SingleOrDual() lines 301-345
    Uses inverse temperature weighting (mired space).
    
    Args:
        color_matrix1: ColorMatrix for illuminant 1 (lower temp, e.g. tungsten)
        color_matrix2: ColorMatrix for illuminant 2 (higher temp, e.g. daylight)
        temp1: Temperature of illuminant 1 in Kelvin
        temp2: Temperature of illuminant 2 in Kelvin
        scene_temp: Scene white point temperature in Kelvin
        
    Returns:
        Interpolated color matrix
    """
    # Ensure temp1 < temp2
    if temp1 > temp2:
        temp1, temp2 = temp2, temp1
        color_matrix1, color_matrix2 = color_matrix2, color_matrix1
    
    # Calculate interpolation weight using inverse temperature (mired space)
    if scene_temp <= temp1:
        g = 1.0
    elif scene_temp >= temp2:
        g = 0.0
    else:
        inv_t = 1.0 / scene_temp
        inv_t1 = 1.0 / temp1
        inv_t2 = 1.0 / temp2
        g = (inv_t - inv_t2) / (inv_t1 - inv_t2)
    
    # Interpolate matrices
    if g >= 1.0:
        return color_matrix1
    elif g <= 0.0:
        return color_matrix2
    else:
        return g * color_matrix1 + (1.0 - g) * color_matrix2


def interpolate_hue_sat_map(
    map_data1: np.ndarray,
    map_data2: np.ndarray | None,
    temp1: float,
    temp2: float | None,
    scene_temp: float
) -> np.ndarray:
    """Interpolate between two HueSatMap data arrays based on scene temperature.
    
    SDK ref: dng_camera_profile.cpp HueSatMapForWhite() lines 1456-1520
    Uses same inverse temperature weighting as color matrices.
    
    Args:
        map_data1: HueSatMapData for illuminant 1 (flat array of hue_shift, sat_scale, val_scale triplets)
        map_data2: HueSatMapData for illuminant 2, or None for single illuminant
        temp1: Temperature of illuminant 1 in Kelvin
        temp2: Temperature of illuminant 2 in Kelvin, or None
        scene_temp: Scene white point temperature in Kelvin
        
    Returns:
        Interpolated HueSatMap data array
    """
    if map_data2 is None or temp2 is None:
        return map_data1
    
    # Ensure temp1 < temp2
    if temp1 > temp2:
        temp1, temp2 = temp2, temp1
        map_data1, map_data2 = map_data2, map_data1
    
    # Calculate interpolation weight using inverse temperature (mired space)
    if scene_temp <= temp1:
        g = 1.0
    elif scene_temp >= temp2:
        g = 0.0
    else:
        inv_t = 1.0 / scene_temp
        inv_t1 = 1.0 / temp1
        inv_t2 = 1.0 / temp2
        g = (inv_t - inv_t2) / (inv_t1 - inv_t2)
    
    # Interpolate map data
    if g >= 1.0:
        return map_data1
    elif g <= 0.0:
        return map_data2
    else:
        return g * map_data1 + (1.0 - g) * map_data2

def transcode_pgtm_if_needed(
    tag_code: int, value: Any, source_byteorder: str, target_byteorder: str) -> Any:
    """Transcode ProfileGainTableMap bytes from source to target byte order.
    
    ProfileGainTableMap is a binary blob where all multi-byte values are stored
    in the file's byte order. To transcode, we byte-swap all multi-byte values.
    
    Structure:
    - Header (64 bytes): 2×uint32, 4×float64, 1×uint32, 5×float32
    - Version 2 adds (16 bytes): 1×uint32, 3×float32
    - Gain data: N×float32 (or float16/uint16/uint8 depending on data_type)
    
    Args:
        tag_code: TIFF tag code
        value: Tag value (may be bytes for PGTM tags)
        source_byteorder: Source byte order ('>' big-endian, '<' little-endian)
        target_byteorder: Target byte order ('>' big-endian, '<' little-endian, '=' system)
        
    Returns:
        Transcoded value if PGTM, otherwise original value
    """
    from .tiff_metadata import LOCAL_TIFF_TAGS
    
    PGTM_TAG = LOCAL_TIFF_TAGS["ProfileGainTableMap"]
    PGTM2_TAG = LOCAL_TIFF_TAGS["ProfileGainTableMap2"]
    
    if tag_code not in (PGTM_TAG, PGTM2_TAG) or not isinstance(value, bytes):
        return value
    
    # Resolve '=' to actual system byte order
    if target_byteorder == '=':
        import sys
        target_byteorder = '<' if sys.byteorder == 'little' else '>'
    
    if source_byteorder == target_byteorder:
        return value  # No conversion needed
    
    is_version2 = (tag_code == PGTM2_TAG)
    
    # Make a mutable copy
    result = bytearray(value)
    offset = 0
    
    # Byte-swap header fields
    # 2×uint32 (points_v, points_h)
    np.frombuffer(result, dtype=np.uint32, count=2, offset=offset).byteswap(inplace=True)
    offset += 8
    
    # 2×float64 (spacing_v, spacing_h)
    np.frombuffer(result, dtype=np.float64, count=2, offset=offset).byteswap(inplace=True)
    offset += 16
    
    # 2×float64 (origin_v, origin_h)
    np.frombuffer(result, dtype=np.float64, count=2, offset=offset).byteswap(inplace=True)
    offset += 16
    
    # 1×uint32 (num_table_points)
    np.frombuffer(result, dtype=np.uint32, count=1, offset=offset).byteswap(inplace=True)
    offset += 4
    
    # 5×float32 (weights)
    np.frombuffer(result, dtype=np.float32, count=5, offset=offset).byteswap(inplace=True)
    offset += 20
    
    # Version 2 fields
    if is_version2:
        # 1×uint32 (data_type)
        data_type_view = np.frombuffer(result, dtype=np.uint32, count=1, offset=offset)
        data_type_view.byteswap(inplace=True)
        data_type = data_type_view[0]
        offset += 4
        
        # 3×float32 (gamma, gain_min, gain_max)
        np.frombuffer(result, dtype=np.float32, count=3, offset=offset).byteswap(inplace=True)
        offset += 12
    else:
        data_type = 3  # float32 default
    
    # Byte-swap gain data based on data_type
    remaining = len(result) - offset
    if data_type == 3:  # float32
        count = remaining // 4
        np.frombuffer(result, dtype=np.float32, count=count, offset=offset).byteswap(inplace=True)
    elif data_type == 2:  # float16
        count = remaining // 2
        np.frombuffer(result, dtype=np.float16, count=count, offset=offset).byteswap(inplace=True)
    elif data_type == 1:  # uint16
        count = remaining // 2
        np.frombuffer(result, dtype=np.uint16, count=count, offset=offset).byteswap(inplace=True)
    # data_type == 0 (uint8) needs no byte swapping
    
    return bytes(result)

def parse_profile_gain_table_map(data: bytes, is_version2: bool = False, byteorder: str = '<') -> dict:
    """Parse ProfileGainTableMap binary blob.
    
    SDK ref: dng_gain_map.cpp GetStream() lines 815-1100
    
    Args:
        data: Raw bytes from ProfileGainTableMap tag
        is_version2: True for ProfileGainTableMap2 format
        byteorder: '<' for little-endian, '>' for big-endian (from TIFF header)
        
    Returns:
        dict with parsed PGTM parameters and gains array
    """
    import struct
    offset = 0
    bo = byteorder  # '<' or '>'
    
    # Read header using file's byte order
    points_v, points_h = struct.unpack_from(f'{bo}II', data, offset)
    offset += 8
    
    spacing_v, spacing_h = struct.unpack_from(f'{bo}dd', data, offset)
    offset += 16
    
    origin_v, origin_h = struct.unpack_from(f'{bo}dd', data, offset)
    offset += 16
    
    num_table_points = struct.unpack_from(f'{bo}I', data, offset)[0]
    offset += 4
    
    weights = list(struct.unpack_from(f'{bo}fffff', data, offset))
    offset += 20
    
    # Version 2 has additional fields
    data_type = 3  # float32 default
    gamma = 1.0
    gain_min = 1.0
    gain_max = 1.0
    
    if is_version2:
        data_type = struct.unpack_from(f'{bo}I', data, offset)[0]
        offset += 4
        gamma, gain_min, gain_max = struct.unpack_from(f'{bo}fff', data, offset)
        offset += 12
    
    # Handle single-point cases
    if points_v == 1:
        spacing_v = 1.0
        origin_v = 0.0
    if points_h == 1:
        spacing_h = 1.0
        origin_h = 0.0
    
    # Read gain data - shape (points_v, points_h, num_table_points)
    gains = np.zeros((points_v, points_h, num_table_points), dtype=np.float32)
    
    for row in range(points_v):
        for col in range(points_h):
            for p in range(num_table_points):
                if data_type == 3:  # float32
                    val = struct.unpack_from(f'{bo}f', data, offset)[0]
                    offset += 4
                elif data_type == 2:  # float16
                    val16 = struct.unpack_from(f'{bo}H', data, offset)[0]
                    offset += 2
                    # Convert to float32 via numpy
                    dt = '<f2' if bo == '<' else '>f2'
                    val = float(np.array([val16], dtype=np.uint16).view(dt)[0])
                elif data_type == 1:  # uint16
                    val16 = struct.unpack_from(f'{bo}H', data, offset)[0]
                    offset += 2
                    val = gain_min + (val16 / 65535.0) * (gain_max - gain_min)
                else:  # uint8
                    val8 = struct.unpack_from('B', data, offset)[0]
                    offset += 1
                    val = gain_min + (val8 / 255.0) * (gain_max - gain_min)
                
                gains[row, col, p] = val
    
    return {
        'points_v': points_v,
        'points_h': points_h,
        'spacing_v': spacing_v,
        'spacing_h': spacing_h,
        'origin_v': origin_v,
        'origin_h': origin_h,
        'num_table_points': num_table_points,
        'weights': np.array(weights, dtype=np.float32),
        'gamma': gamma,
        'gains': gains,
    }


def parse_opcode_list(data: bytes) -> list[dict]:
    """Parse OpcodeList1/2/3 binary blob.
    
    SDK ref: dng_opcode_list.cpp, dng_misc_opcodes.cpp
    
    Args:
        data: Raw bytes from OpcodeList tag
        
    Returns:
        List of parsed opcode dicts
    """
    import struct
    opcodes = []
    offset = 0
    
    # OpcodeList is always big-endian
    count = struct.unpack_from('>I', data, offset)[0]
    offset += 4
    
    for _ in range(count):
        if offset + 12 > len(data):
            break
        opcode_id = struct.unpack_from('>I', data, offset)[0]
        offset += 4
        min_version = struct.unpack_from('>I', data, offset)[0]
        offset += 4
        flags = struct.unpack_from('>I', data, offset)[0]
        offset += 4
        data_size = struct.unpack_from('>I', data, offset)[0]
        offset += 4
        
        opcode_data = data[offset:offset + data_size]
        offset += data_size
        
        opcode = {
            'id': opcode_id,
            'min_version': min_version,
            'flags': flags,
            'data': opcode_data,
        }
        
        # Parse known opcodes
        if opcode_id == 1 and len(opcode_data) >= 20:  # WarpRectilinear
            opcode.update(parse_warp_rectilinear(opcode_data))
        elif opcode_id == 3 and len(opcode_data) >= 56:  # FixVignetteRadial
            opcode.update(parse_fix_vignette_radial(opcode_data))
        elif opcode_id == 4 and len(opcode_data) >= 8:  # FixBadPixelsConstant
            opcode.update(parse_fix_bad_pixels_constant(opcode_data))
        elif opcode_id == 8 and len(opcode_data) >= 36:  # MapPolynomial
            opcode.update(parse_map_polynomial(opcode_data))
        elif opcode_id == 9 and len(opcode_data) >= 76:  # GainMap
            opcode.update(parse_gain_map(opcode_data))
        
        opcodes.append(opcode)
    
    return opcodes


def get_opcode_summary(opcode_list_data: bytes, detailed: bool = False) -> str:
    """Get a human-readable summary of opcodes in an OpcodeList.
    
    Args:
        opcode_list_data: Raw bytes from OpcodeList1/2/3 tag
        detailed: If True, return multi-line detailed summary with parameters
        
    Returns:
        String like "3 opcodes: GainMap, WarpRectilinear, FixVignetteRadial"
        or detailed multi-line summary if detailed=True
        or "Invalid opcode list" if parsing fails
    """
    try:
        opcodes = parse_opcode_list(opcode_list_data)
        if not opcodes:
            return "0 opcodes"
        
        opcode_ids = [op.get('id', 0) for op in opcodes]
        opcode_names = [enum_display_name(DngOpcode, oid) for oid in opcode_ids]
        
        count = len(opcodes)
        
        if not detailed:
            names_str = ', '.join(opcode_names)
            return f"{count} opcode{'s' if count != 1 else ''}: {names_str}"
        
        # Detailed multi-line summary
        lines = [f"{count} opcode{'s' if count != 1 else ''}:"]
        for i, op in enumerate(opcodes):
            opcode_id = op.get('id', 0)
            name = enum_display_name(DngOpcode, opcode_id)
            lines.append(f"  [{i}] {name}")
            
            # Add type-specific details
            if op.get('type') == 'MapPolynomial':
                area = op.get('area', {})
                plane = op.get('plane', '?')
                planes = op.get('planes', '?')
                row_pitch = op.get('row_pitch', '?')
                col_pitch = op.get('col_pitch', '?')
                degree = op.get('degree', '?')
                coeffs = op.get('coefficients', np.array([]))
                
                lines.append(
                    f"      area=[{area.get('top', '?')}, {area.get('left', '?')}, "
                    f"{area.get('bottom', '?')}, {area.get('right', '?')}], "
                    f"plane={plane}, planes={planes}, pitch=[{row_pitch}, {col_pitch}]"
                )
                if len(coeffs) <= 5:
                    coeffs_str = '[' + ', '.join(f'{c:g}' for c in coeffs) + ']'
                else:
                    coeffs_str = f'[{coeffs[0]:g}, ..., {coeffs[-1]:g}] ({len(coeffs)} values)'
                lines.append(f"      degree={degree}, coeffs={coeffs_str}")
            
            elif op.get('type') == 'GainMap':
                area = op.get('area', {})
                plane = op.get('plane', '?')
                planes = op.get('planes', '?')
                points_v = op.get('points_v', '?')
                points_h = op.get('points_h', '?')
                spacing_v = op.get('spacing_v', '?')
                spacing_h = op.get('spacing_h', '?')
                gain_vals = op.get('gain_values', np.array([]))
                
                lines.append(
                    f"      area=[{area.get('top', '?')}, {area.get('left', '?')}, "
                    f"{area.get('bottom', '?')}, {area.get('right', '?')}], "
                    f"plane={plane}, planes={planes}, points=[{points_v}x{points_h}]"
                )
                lines.append(f"      spacing=[{spacing_v:g}, {spacing_h:g}]")
                if len(gain_vals) > 0:
                    lines.append(f"      gain_range=[{gain_vals.min():g}, {gain_vals.max():g}]")
            
            elif op.get('type') == 'WarpRectilinear':
                planes_data = op.get('planes', [])
                center_x = op.get('center_x', '?')
                center_y = op.get('center_y', '?')
                
                lines.append(f"      center=[{center_x:g}, {center_y:g}], planes={len(planes_data)}")
                for p_idx, plane_data in enumerate(planes_data[:3]):  # Show max 3 planes
                    radial = plane_data.get('radial', [])
                    tangential = plane_data.get('tangential', [])
                    radial_str = '[' + ', '.join(f'{r:g}' for r in radial) + ']' if radial else '[]'
                    tangential_str = (
                        '[' + ', '.join(f'{t:g}' for t in tangential) + ']' if tangential else '[]'
                    )
                    lines.append(
                        f"      plane[{p_idx}]: radial={radial_str}, tangential={tangential_str}"
                    )
            
            elif op.get('type') == 'FixVignetteRadial':
                area = op.get('area', {})
                plane = op.get('plane', '?')
                params = op.get('params', [])
                
                params_str = '[' + ', '.join(f'{p:g}' for p in params) + ']' if params else '[]'
                lines.append(
                    f"      area=[{area.get('top', '?')}, {area.get('left', '?')}, "
                    f"{area.get('bottom', '?')}, {area.get('right', '?')}], "
                    f"plane={plane}, params={params_str}"
                )
            
            elif op.get('type') == 'FixBadPixelsConstant':
                constant = op.get('constant', '?')
                bayer_phase = op.get('bayer_phase', '?')
                lines.append(f"      constant={constant}, bayer_phase={bayer_phase}")
        
        return '\n'.join(lines)
    except Exception as e:
        return f"Invalid opcode list: {e}"


def parse_area_spec(data: bytes, offset: int = 0) -> tuple[dict, int]:
    """Parse dng_area_spec from opcode data.
    
    SDK ref: dng_opcodes.h dng_area_spec (32 bytes)
    """
    import struct
    top = struct.unpack_from('>i', data, offset)[0]; offset += 4
    left = struct.unpack_from('>i', data, offset)[0]; offset += 4
    bottom = struct.unpack_from('>i', data, offset)[0]; offset += 4
    right = struct.unpack_from('>i', data, offset)[0]; offset += 4
    plane = struct.unpack_from('>I', data, offset)[0]; offset += 4
    planes = struct.unpack_from('>I', data, offset)[0]; offset += 4
    row_pitch = struct.unpack_from('>I', data, offset)[0]; offset += 4
    col_pitch = struct.unpack_from('>I', data, offset)[0]; offset += 4
    return {
        'area': {'top': top, 'left': left, 'bottom': bottom, 'right': right},
        'plane': plane, 'planes': planes,
        'row_pitch': row_pitch, 'col_pitch': col_pitch,
    }, offset


def parse_map_polynomial(data: bytes) -> dict:
    """Parse MapPolynomial opcode data (opcode 8).
    
    SDK ref: dng_misc_opcodes.cpp dng_opcode_MapPolynomial
    """
    import struct
    area_spec, offset = parse_area_spec(data, 0)
    
    degree = struct.unpack_from('>I', data, offset)[0]; offset += 4
    coefficients = [struct.unpack_from('>d', data, offset + i*8)[0] for i in range(degree + 1)]
    
    return {
        'type': 'MapPolynomial',
        **area_spec,
        'degree': degree,
        'coefficients': np.array(coefficients, dtype=np.float64),
    }


def parse_warp_rectilinear(data: bytes) -> dict:
    """Parse WarpRectilinear opcode data (opcode 1).
    
    SDK ref: dng_lens_correct.cpp dng_opcode_WarpRectilinear lines 1822-1889
    Format: 4 radial (kr0, kr2, kr4, kr6) + 2 tangential per plane
    """
    import struct
    offset = 0
    num_planes = struct.unpack_from('>I', data, offset)[0]; offset += 4
    
    # Per-plane warp params: 4 radial + 2 tangential = 6 coefficients (48 bytes)
    planes_data = []
    for _ in range(num_planes):
        # SDK reads: kr0 (offset), kr2 (r^2), kr4 (r^4), kr6 (r^6), kt0, kt1
        radial = [struct.unpack_from('>d', data, offset + i*8)[0] for i in range(4)]
        offset += 32
        tangential = [struct.unpack_from('>d', data, offset + i*8)[0] for i in range(2)]
        offset += 16
        planes_data.append({'radial': radial, 'tangential': tangential})
    
    center_x = struct.unpack_from('>d', data, offset)[0]; offset += 8
    center_y = struct.unpack_from('>d', data, offset)[0]; offset += 8
    
    return {
        'type': 'WarpRectilinear',
        'num_planes': num_planes,
        'planes': planes_data,
        'center_x': center_x,
        'center_y': center_y,
    }


def parse_fix_vignette_radial(data: bytes) -> dict:
    """Parse FixVignetteRadial opcode data (opcode 3).
    
    SDK ref: dng_lens_correct.cpp dng_opcode_FixVignetteRadial
    """
    import struct
    offset = 0
    # 5 polynomial coefficients k0-k4
    k = [struct.unpack_from('>d', data, offset + i*8)[0] for i in range(5)]
    offset += 40
    center_x = struct.unpack_from('>d', data, offset)[0]; offset += 8
    center_y = struct.unpack_from('>d', data, offset)[0]; offset += 8
    
    return {
        'type': 'FixVignetteRadial',
        'coefficients': np.array(k, dtype=np.float64),
        'center_x': center_x,
        'center_y': center_y,
    }


def parse_fix_bad_pixels_constant(data: bytes) -> dict:
    """Parse FixBadPixelsConstant opcode data (opcode 4).
    
    SDK ref: dng_bad_pixels.cpp dng_opcode_FixBadPixelsConstant
    """
    import struct
    constant = struct.unpack_from('>I', data, 0)[0]
    bayer_phase = struct.unpack_from('>I', data, 4)[0]
    
    return {
        'type': 'FixBadPixelsConstant',
        'constant': constant,
        'bayer_phase': bayer_phase,
    }


def parse_gain_map(data: bytes) -> dict:
    """Parse GainMap opcode data (opcode 9).
    
    SDK ref: dng_gain_map.cpp dng_opcode_GainMap, dng_gain_map::GetStream
    """
    import struct
    
    area_spec, offset = parse_area_spec(data, 0)
    
    points_v = struct.unpack_from('>I', data, offset)[0]; offset += 4
    points_h = struct.unpack_from('>I', data, offset)[0]; offset += 4
    spacing_v = struct.unpack_from('>d', data, offset)[0]; offset += 8
    spacing_h = struct.unpack_from('>d', data, offset)[0]; offset += 8
    origin_v = struct.unpack_from('>d', data, offset)[0]; offset += 8
    origin_h = struct.unpack_from('>d', data, offset)[0]; offset += 8
    map_planes = struct.unpack_from('>I', data, offset)[0]; offset += 4
    
    # Handle single-point maps
    if points_v == 1:
        spacing_v = 1.0
        origin_v = 0.0
    if points_h == 1:
        spacing_h = 1.0
        origin_h = 0.0
    
    # Read gain values [row][col][plane]
    gain_values = np.zeros((points_v, points_h, map_planes), dtype=np.float32)
    for row in range(points_v):
        for col in range(points_h):
            for plane in range(map_planes):
                gain_values[row, col, plane] = struct.unpack_from('>f', data, offset)[0]
                offset += 4
    
    return {
        'type': 'GainMap',
        **area_spec,
        'points_v': points_v,
        'points_h': points_h,
        'spacing_v': spacing_v,
        'spacing_h': spacing_h,
        'origin_v': origin_v,
        'origin_h': origin_h,
        'map_planes': map_planes,
        'gain_values': gain_values,
    }

def apply_opcodes(
    data: np.ndarray,
    opcodes: list[dict],
    use_bicubic: bool = True,
    opcode_list_name: str = "RGB"
) -> np.ndarray:
    """Apply parsed opcodes to image data.
    
    Supported opcodes:
    - 1: WarpRectilinear (C++ op_warp_rectilinear)
    - 3: FixVignetteRadial (C++ op_fix_vignette)
    - 8: MapPolynomial (C++ op_map_polynomial)
    - 9: GainMap (C++ op_gain_map)
    
    Args:
        data: Image data (H, W, C), float32, range [0, 1]
        opcodes: List of parsed opcodes from parse_opcode_list
        use_bicubic: If True, use SDK bicubic interpolation for WarpRectilinear;
                     if False, use bilinear (default: True)
        opcode_list_name: Name of opcode list for logging (e.g., "OpcodeList3")
        
    Returns:
        Processed image data
    """
    result = data.astype(np.float32)
    
    for opcode in opcodes:
        opcode_type = opcode.get('type')
        
        if opcode_type == 'WarpRectilinear':
            # SDK applies different warp per color plane for lateral CA correction
            planes = opcode['planes']
            num_planes = len(planes)
            
            # DNG SDK spec (dng_lens_correction.h:40-44): if num_planes==1,
            # apply same warp to all image planes
            if num_planes == 1 and result.shape[2] > 1:
                logger.debug(f"WarpRectilinear: Replicating single plane params for {result.shape[2]} channels")
                planes = [planes[0]] * result.shape[2]
                num_planes = result.shape[2]
            
            num_planes = min(num_planes, 3)  # RGB
            logger.debug(f"WarpRectilinear: center=({opcode['center_x']:.4f}, {opcode['center_y']:.4f})")
            # Build per-plane radial/tangential arrays (num_planes x 4, num_planes x 2)
            radial_list = []
            tangential_list = []
            for i, p in enumerate(planes[:num_planes]):
                logger.debug(f"  Plane {i}: radial={p['radial']}, tan={p['tangential']}")
                radial_list.append(p['radial'][:4])
                tangential_list.append(p['tangential'])
            radial_per_plane = np.array(radial_list, dtype=np.float64)
            tangential_per_plane = np.array(tangential_list, dtype=np.float64)
            result = _raw_render.op_warp_rectilinear(
                result, radial_per_plane,
                center_x=opcode['center_x'],
                center_y=opcode['center_y'],
                tangential_params=tangential_per_plane,
                use_bicubic=use_bicubic
            )
            
        elif opcode_type == 'FixVignetteRadial':
            result = _raw_render.op_fix_vignette(
                result,
                opcode['coefficients'],
                opcode['center_x'],
                opcode['center_y']
            )
            
        elif opcode_type == 'MapPolynomial':
            # C++ implementation matching SDK RefBaselineMapPoly32
            coefficients = opcode['coefficients'].astype(np.float32)
            area = opcode['area']
            result = _raw_render.op_map_polynomial(
                result,
                coefficients,
                area['top'], area['left'], area['bottom'], area['right'],
                opcode['plane'], opcode['planes'],
                opcode['row_pitch'], opcode['col_pitch'],
                opcode['degree']
            )
            
        elif opcode_type == 'GainMap':
            area = opcode['area']
            logger.debug(f"GainMap: area={area}, plane={opcode['plane']}, planes={opcode['planes']}, "
                        f"row_pitch={opcode['row_pitch']}, col_pitch={opcode['col_pitch']}, "
                        f"points={opcode['points_v']}x{opcode['points_h']}, map_planes={opcode['map_planes']}, "
                        f"spacing=({opcode['spacing_v']:.6f}, {opcode['spacing_h']:.6f}), "
                        f"origin=({opcode['origin_v']:.6f}, {opcode['origin_h']:.6f}), "
                        f"gain_range=[{opcode['gain_values'].min():.4f}, {opcode['gain_values'].max():.4f}]")
            result = _raw_render.op_gain_map(
                result,
                opcode['gain_values'],
                area['top'], area['left'], area['bottom'], area['right'],
                opcode['plane'], opcode['planes'],
                opcode['row_pitch'], opcode['col_pitch'],
                opcode['spacing_v'], opcode['spacing_h'],
                opcode['origin_v'], opcode['origin_h']
            )
            
        else:
            name = enum_display_name(DngOpcode, opcode['id'])
            logger.warning(f"Skipping unsupported {opcode_list_name} opcode: {name}")
    
    return result


def apply_opcodes_cfa(
    data: np.ndarray,
    opcodes: list[dict],
    opcode_list_name: str = "CFA"
) -> np.ndarray:
    """Apply parsed opcodes to CFA data.
    
    Handles both OpcodeList1 (pre-linearization, uint16) and OpcodeList2 
    (post-linearization, float32).
    
    DNG Spec:
    - OpcodeList1: Applied to raw sensor data before linearization (uint16)
    - OpcodeList2: Applied after linearization, before demosaic (float32 [0,1])
    
    Supported opcodes:
    - FixBadPixelsConstant (OpcodeList1 only, requires uint16)
    - FixVignetteRadial (both lists)
    - MapPolynomial (both lists)
    - GainMap (both lists)
    
    Args:
        data: CFA data (H, W)
              - uint16 for OpcodeList1 (raw sensor values)
              - float32 for OpcodeList2 (linearized [0,1])
        opcodes: List of parsed opcodes from parse_opcode_list
        opcode_list_name: Name of opcode list for logging (e.g., "OpcodeList1")
        
    Returns:
        Processed CFA data (same dtype as input)
    """
    if data.ndim != 2:
        logger.error(f"CFA opcodes require 2D data (H,W), got shape {data.shape}")
        return data
    
    is_uint16 = data.dtype == np.uint16
    
    # For uint16 data, we may need to convert to float for some opcodes
    if is_uint16:
        result_uint16 = data.astype(np.uint16)
        result_float = None
    else:
        result_uint16 = None
        result_float = data.astype(np.float32)
    
    for opcode in opcodes:
        opcode_type = opcode.get('type')
        
        if opcode_type == 'FixBadPixelsConstant':
            # Only works on uint16 data - convert back from float if needed
            if is_uint16:
                if result_float is not None:
                    # We've already converted to float, need to go back to uint16
                    result_uint16 = convert_dtype(result_float, np.uint16)
                    result_float = None
                constant = opcode['constant']
                bayer_phase = opcode['bayer_phase']
                logger.debug(f"FixBadPixelsConstant: constant={constant}, bayer_phase={bayer_phase}")
                result_uint16 = _raw_render.op_fix_bad_pixels_constant(
                    result_uint16,
                    constant,
                    bayer_phase
                )
            else:
                logger.warning("FixBadPixelsConstant requires uint16 input data, skipping")
        
        elif opcode_type == 'GainMap':
            # Works on float32 - convert uint16 if needed
            if is_uint16 and result_float is None:
                result_float = convert_dtype(result_uint16, np.float32)
            
            area = opcode['area']
            logger.debug(f"GainMap CFA: area={area}, plane={opcode['plane']}, planes={opcode['planes']}, "
                        f"row_pitch={opcode['row_pitch']}, col_pitch={opcode['col_pitch']}, "
                        f"points={opcode['points_v']}x{opcode['points_h']}, map_planes={opcode['map_planes']}, "
                        f"spacing=({opcode['spacing_v']:.6f}, {opcode['spacing_h']:.6f}), "
                        f"origin=({opcode['origin_v']:.6f}, {opcode['origin_h']:.6f}), "
                        f"gain_range=[{opcode['gain_values'].min():.4f}, {opcode['gain_values'].max():.4f}]")
            result_float = _raw_render.op_gain_map_cfa(
                result_float,
                opcode['gain_values'],
                area['top'], area['left'], area['bottom'], area['right'],
                opcode['row_pitch'], opcode['col_pitch'],
                opcode['spacing_v'], opcode['spacing_h'],
                opcode['origin_v'], opcode['origin_h']
            )
        
        elif opcode_type == 'MapPolynomial':
            # Works on float32 - convert uint16 if needed
            if is_uint16 and result_float is None:
                result_float = convert_dtype(result_uint16, np.float32)
            
            area = opcode['area']
            coefficients = np.asarray(opcode['coefficients'], dtype=np.float64)
            logger.debug(f"MapPolynomial CFA: area={area}, degree={opcode['degree']}, coeffs={coefficients}")
            result_float = _raw_render.op_map_polynomial_cfa(
                result_float,
                coefficients,
                area['top'], area['left'], area['bottom'], area['right'],
                opcode['row_pitch'], opcode['col_pitch'],
                opcode['degree']
            )
        
        elif opcode_type == 'FixVignetteRadial':
            # Works on float32 - convert uint16 if needed
            if is_uint16 and result_float is None:
                result_float = convert_dtype(result_uint16, np.float32)
            
            logger.debug(f"FixVignetteRadial CFA: center=({opcode['center_x']:.4f}, {opcode['center_y']:.4f}), "
                        f"coeffs={opcode['coefficients']}")
            
            result_float = _raw_render.op_fix_vignette_cfa(
                result_float,
                opcode['coefficients'],
                opcode['center_x'],
                opcode['center_y']
            )
            
        else:
            name = enum_display_name(DngOpcode, opcode['id'])
            logger.warning(f"Skipping unsupported {opcode_list_name} opcode: {name}")
    
    # Return in original dtype
    if is_uint16:
        if result_float is not None:
            # Convert back to uint16
            return convert_dtype(result_float, np.uint16)
        return result_uint16
    else:
        return result_float

def exposure_tone(x: np.ndarray, exposure: float, highlight_preserving_exposure: bool = True) -> np.ndarray:
    """Apply exposure tone function.
    
    For negative exposure: uses a piecewise curve with linear segment from 0 to 0.25
    and a cubic spline from 0.25 to 1.0 (when highlight compression is enabled).
    
    SDK ref: dng_render.cpp lines 1005-1012
    
    Args:
        x: Input values in [0, 1]
        exposure: Exposure compensation in stops
        highlight_preserving_exposure: If True, use cubic spline for negative exposure with highlight compression.
                          If False, use DNG SDK quadratic approximation.
                          Default True.
    
    Returns:
        Tone-mapped values in [0, 1]
    """
    if exposure >= 0.0:
        return x.copy()

    slope = 2.0 ** exposure
    
    if not highlight_preserving_exposure:        
        # Uses k=1.0 (highlight preservation parameter, 
        # kept in case we want to surface this param in future)
        k = 1.0
        a = 16.0 / 9.0 * k * 0.25 * (1.0 - slope)
        b = slope - 0.5 * a
        c = 0.0625 * a
        return np.where(x <= 0.25, x * slope, (a * x + b) * x + c)
    else:
        # Cubic spline causes max white to stay white until negative exposure becomes large 
        
        # For very deep exposures (< -2.5), use simple linear darkening
        # The curve is nearly linear at this point, so the spline adds no benefit
        if exposure <= -2.25:
            return x * slope
        
        # Control points at x = [0.25, 0.5, 0.75, 0.875, 1.0]
        # y-values from lookup table with linear interpolation
        
        # Lookup table for control points (from analyze_spline_control_points.py)
        # 15 exposure values, reversed to be in increasing order for np.interp
        # Optimized using least-squares fitting (28-50% RMSE improvement over sampling)
        # Includes 0.0 (identity function) for interpolation between 0 and -0.2
        _EXPOSURES = np.array([
            -2.30, -2.05, -2.00, -1.80, -1.55, -1.50, -1.30, -1.05,
            -1.00, -0.80, -0.60, -0.50, -0.40, -0.20, 0.0
        ])
        _Y_0P5 = np.array([
            0.10149, 0.12091, 0.12529, 0.14483, 0.17487, 0.18180, 0.21333, 0.26332,
            0.27467, 0.30827, 0.34460, 0.36403, 0.38458, 0.43129, 0.5
        ])
        _Y_0P75 = np.array([
            0.15428, 0.18698, 0.19454, 0.22904, 0.28433, 0.29747, 0.35944, 0.46739,
            0.49453, 0.53405, 0.57442, 0.59555, 0.61789, 0.67009, 0.75
        ])
        _Y_0P875 = np.array([
            0.18307, 0.22389, 0.23341, 0.27735, 0.34976, 0.36741, 0.45328, 0.61767,
            0.66303, 0.69796, 0.73278, 0.75085, 0.76992, 0.81396, 0.875
        ])
        _Y_1P0 = np.array([
            0.21343, 0.26355, 0.27540, 0.33081, 0.42531, 0.44906, 0.56998, 0.85127,
            0.96114, 0.97007, 0.97869, 0.98295, 0.98717, 0.99499, 1.0
        ])
        
        # Linearly interpolate control point values
        y_0p25 = 0.25 * slope  # Fixed by continuity
        y_0p5 = np.interp(exposure, _EXPOSURES, _Y_0P5)
        y_0p75 = np.interp(exposure, _EXPOSURES, _Y_0P75)
        y_0p875 = np.interp(exposure, _EXPOSURES, _Y_0P875)
        y_1p0 = np.interp(exposure, _EXPOSURES, _Y_1P0)
        
        # Create control points for spline
        control_points = [
            (0.25, y_0p25), (0.5, y_0p5), (0.75, y_0p75), (0.875, y_0p875), (1.0, y_1p0)]
        
        # Create spline with derivative continuity at x=0.25
        # bc_type: (1, slope) = first derivative at left = slope (matches linear region)
        #          (2, 0.0) = second derivative at right = 0 (natural spline end)
        spline = CubicSpline(control_points, bc_type=((1, slope), (2, 0.0)))
        
        # Apply piecewise curve
        return np.where(x <= 0.25, x * slope, spline(x))

def exposure_ramp(
    x: np.ndarray,
    white: float,
    black: float,
    min_black: float,
    support_overrange: bool = False
) -> np.ndarray:
    """Apply the DNG SDK exposure ramp function.
    
    SDK ref: dng_render.cpp dng_function_exposure_ramp lines 50-103
    3 regions: below black-radius→0, above black+radius→linear, between→quadratic
    
    Can be applied to pixel values or used to remap curve inputs.
    
    Args:
        x: Input values in [0, 1]
        white: White point (1.0 / pow(2, max(0, exposure)))
        black: Black point (shadows * shadowScale * 0.001)
        min_black: Minimum black for radius calculation
        support_overrange: Allow values > 1.0
    
    Returns:
        Transformed values
    """
    # SDK ref: dng_render.cpp lines 55-75 (constructor)
    slope = 1.0 / (white - black)
    
    # Compute radius for quadratic blend region
    kMaxCurveX = 0.5      # Fraction of minBlack
    kMaxCurveY = 1.0 / 16.0  # Fraction of white
    
    radius = min(kMaxCurveX * min_black, kMaxCurveY / slope)
    
    q_scale = 0.0
    if radius > 0.0:
        q_scale = slope / (4.0 * radius)
    
    # Region 1: x <= black - radius → 0
    # Region 2: x >= black + radius → linear ramp
    # Region 3: between → quadratic blend
    result = np.zeros_like(x)
    
    # Region 2: linear ramp
    mask_linear = x >= (black + radius)
    y_linear = (x[mask_linear] - black) * slope
    if not support_overrange:
        y_linear = np.minimum(y_linear, 1.0)
    result[mask_linear] = y_linear
    
    # Region 3: quadratic blend (between black-radius and black+radius)
    mask_quad = (x > (black - radius)) & (x < (black + radius))
    y_quad = x[mask_quad] - (black - radius)
    result[mask_quad] = q_scale * y_quad * y_quad
    
    # Region 1 stays at 0 (already initialized)
    return result

def compute_exposure_ramp_lut(
    exposure: float,
    shadow_scale: float,
    default_black_render: int,
    highlight_preserving_exposure: bool = True,
    num_points: int = 4096,
    rgb_prophoto: np.ndarray | None = None
) -> np.ndarray:
    """Compute exposure_ramp LUT from exposure and DNG tag values.
    
    Args:
        exposure: Total exposure in stops (baseline + user)
        shadow_scale: ShadowScale tag value (default 1.0 if None)
        default_black_render: DefaultBlackRender tag (0=Auto, 1=None)
        highlight_preserving_exposure: If True, use highlight compression 
        (white=1.0, complementary power). If False, use DNG SDK behavior 
        (standard exposure_ramp).
        Default True.
        
        num_points: Number of LUT points
        rgb_prophoto: Optional ProPhoto linear RGB image for adaptive exposure.
        If provided, blend weight is computed from content luminance histogram.
    
    Returns:
        Exposure ramp LUT as float32 array
    """
    # Compute LUT
    lut_x = np.linspace(0.0, 1.0, num_points, dtype=np.float64)
    
    # Compute exposure_white based on path
    # For highlight compression: always use white=1.0 (no linear scaling in exposure_ramp)
    # Exposure adjustment is handled via complementary power (positive) or cubic spline (negative)
    # For DNG SDK: use standard white point
    if highlight_preserving_exposure:
        exposure_white = 1.0
    else:
        exposure_white = 1.0 / (2.0 ** max(0.0, exposure))
    
    # SDK ref: dng_render.cpp lines 986-991, 2164-2171
    # black = shadows * ShadowScale * Stage3Gain * 0.001
    # Stage3Gain = 1.0 for normal images (only set for multi-channel CFA merging)
    # DefaultBlackRender: 0 = Auto, 1 = None (shadows=0.0)
    if default_black_render == 1:  # defaultBlackRender_None
        shadows = 0.0
    else:
        shadows = 5.0  # DNG SDK default
    exposure_black = shadows * shadow_scale * 0.001
    exposure_black = min(exposure_black, 0.99 * exposure_white)
    
    # For highlight compression with positive exposure: compute exposure curves first, then apply shadow processing
    if highlight_preserving_exposure and exposure > 0.0:
        # Adaptive exposure: blend between linear and complementary power based on content
        # the intent is that we don't do compressive curve if content does not need it

        # Compute slope (exposure gain) - used for both blend weight and curves
        slope = 2.0 ** exposure
        
        blend_weight = 1.0  # Default to pure complementary power
        
        if rgb_prophoto is not None:
            # Compute luminance from ProPhoto RGB
            # Y coefficients from PROPHOTO_RGB_TO_XYZ_D50 matrix
            luminance = (0.2880402 * rgb_prophoto[..., 0] +
                        0.7118741 * rgb_prophoto[..., 1] +
                        0.0000857 * rgb_prophoto[..., 2])
            luminance_flat = luminance.flatten()
            
            # Find p98 luminance value using histogram for efficiency
            # Use 10000 bins for good precision
            hist, bin_edges = np.histogram(luminance_flat, bins=10000, range=(0.0, 1.0))
            cdf = np.cumsum(hist).astype(np.float64) / np.sum(hist)

            # Find bin where CDF crosses 0.98(p98)
            idx = np.searchsorted(cdf, 0.98)
            mx = bin_edges[idx] if idx < len(bin_edges) else bin_edges[-1]

            # Scale by exposure
            smx = slope * mx
            
            # Compute blend weight
            # w = 0 if smx <= 0.6 (pure linear)
            # w = (smx - 0.6) / 0.4 if 0.6 < smx < 1.0 (blend)
            # w = 1 if smx >= 1.0 (pure complementary power)
            if smx >= 1.0:
                blend_weight = 1.0
            elif smx <= 0.6:
                blend_weight = 0.0
            else:
                blend_weight = (smx - 0.6) / (1.0 - 0.6)
            
            logger.debug(f"  Selected p98: mx={mx:.5f}, smx={smx:.5f}, w={blend_weight:.5f}")
        
        # Compute both exposure curves from input
        
        # Linear exposure: multiply by gain
        linear_lut = lut_x * slope
        
        # Complementary power function for positive exposure
        # f(x) = 1 - (1-x)^slope where slope = 2^exposure
        comp_power_lut = 1.0 - (1.0 - lut_x) ** slope
        
        # Blend between linear and complementary power
        exposure_lut = linear_lut * (1.0 - blend_weight) + comp_power_lut * blend_weight
        
        # Apply exposure_ramp (shadow processing) to the blended exposure curve
        ramp_lut = exposure_ramp(
            exposure_lut, exposure_white, exposure_black, exposure_black
        )
    else:
        # Default: apply exposure_ramp (handles shadow processing)
        ramp_lut = exposure_ramp(
            lut_x, exposure_white, exposure_black, exposure_black
        )
    
    return ramp_lut.astype(np.float32)


# Standard illuminant xy chromaticities (from DNG SDK)
D50_xy = (0.34567, 0.35850)  # PCS reference white
D55_xy = (0.33242, 0.34743)
D65_xy = (0.31271, 0.32902)  # sRGB reference white

# Bradford Chromatic Adaptation Matrices (from dng_color_spec.cpp)
_BRADFORD_MATRIX = np.array([
    [ 0.8951,  0.2664, -0.1614],
    [-0.7502,  1.7135,  0.0367],
    [ 0.0389, -0.0685,  1.0296]
], dtype=np.float64)

_BRADFORD_MATRIX_INV = np.linalg.inv(_BRADFORD_MATRIX)

def _xy_to_XYZ(x: float, y: float) -> np.ndarray:
    """Convert xy chromaticity to XYZ with Y=1."""
    return np.array([x / y, 1.0, (1.0 - x - y) / y], dtype=np.float64)


def compute_bradford_adaptation(
    src_xy: tuple[float, float], dst_xy: tuple[float, float]
) -> np.ndarray:
    """Compute Bradford chromatic adaptation matrix between two white points.

    This is a pure Python replacement for _raw_render.bradford_adapt().

    Args:
        src_xy: Source white point xy chromaticity (x, y)
        dst_xy: Destination white point xy chromaticity (x, y)

    Returns:
        3x3 chromatic adaptation matrix (numpy array, float64)
    """
    src_XYZ = _xy_to_XYZ(src_xy[0], src_xy[1])
    dst_XYZ = _xy_to_XYZ(dst_xy[0], dst_xy[1])

    # Transform to cone response domain
    src_cone = _BRADFORD_MATRIX @ src_XYZ
    dst_cone = _BRADFORD_MATRIX @ dst_XYZ

    # Diagonal scaling matrix
    scale = np.zeros((3, 3), dtype=np.float64)
    for i in range(3):
        if src_cone[i] > 0:
            scale[i, i] = np.clip(dst_cone[i] / src_cone[i], 0.1, 10.0)
        else:
            scale[i, i] = 1.0

    # Result = BradfordInv @ Scale @ Bradford
    return _BRADFORD_MATRIX_INV @ scale @ _BRADFORD_MATRIX


def _normalize_forward_matrix(m: np.ndarray) -> np.ndarray:
    """Normalize ForwardMatrix so camera [1,1,1] maps to D50 white.
    
    SDK ref: dng_camera_profile.cpp NormalizeForwardMatrix() lines 335-353
    
    Args:
        m: 3x3 ForwardMatrix
        
    Returns:
        Normalized 3x3 ForwardMatrix
    """
    if m is None:
        return None
    m = np.asarray(m, dtype=np.float64)
    if m.size == 0:
        return m
    
    # D50 white point in XYZ (Y=1 normalized)
    # SDK ref: dng_color_space.cpp PCStoXYZ()
    D50_XYZ = np.array([0.9642, 1.0, 0.8249], dtype=np.float64)
    
    # camera_one = [1, 1, 1]
    camera_one = np.ones(m.shape[1], dtype=np.float64)
    
    # xyz = m * camera_one (what XYZ we get when all camera channels are 1)
    xyz = m @ camera_one
    
    # Normalize: m = diag(D50_XYZ) * diag(1/xyz) * m
    # This ensures camera [1,1,1] -> D50 white
    xyz_inv = np.where(xyz != 0, 1.0 / xyz, 0.0)
    return np.diag(D50_XYZ) @ np.diag(xyz_inv) @ m

# ProPhoto RGB matrices (from dng_color_space.cpp)
# ProPhoto uses D50 white point
PROPHOTO_RGB_TO_XYZ_D50 = np.array([
    [0.7976749, 0.1351917, 0.0313534],
    [0.2880402, 0.7118741, 0.0000857],
    [0.0000000, 0.0000000, 0.8252100]
], dtype=np.float32)

XYZ_D50_TO_PROPHOTO_RGB = np.array([
    [ 1.3459433, -0.2556075, -0.0511118],
    [-0.5445989,  1.5081673,  0.0205351],
    [ 0.0000000,  0.0000000,  1.2118128]
], dtype=np.float32)

# sRGB matrices (D65 white point)
XYZ_D65_TO_SRGB = np.array([
    [ 3.2404542, -1.5371385, -0.4985314],
    [-0.9692660,  1.8760108,  0.0415560],
    [ 0.0556434, -0.2040259,  1.0572252]
], dtype=np.float32)

# Adobe RGB (1998) matrices (D65 white point)
# Source: DNG SDK 1.7.1 dng_color_space.cpp lines 568-570
# dng_space_AdobeRGB::SetMatrixToPCS
ADOBERGB_TO_XYZ_D65 = np.array([
    [0.6097, 0.2053, 0.1492],
    [0.3111, 0.6257, 0.0632],
    [0.0195, 0.0609, 0.7446]
], dtype=np.float32)

XYZ_D65_TO_ADOBERGB = np.linalg.inv(ADOBERGB_TO_XYZ_D65)

SRGB_TO_XYZ_D65 = np.array([
    [0.4124564, 0.3575761, 0.1804375],
    [0.2126729, 0.7151522, 0.0721750],
    [0.0193339, 0.1191920, 0.9503041]
], dtype=np.float32)


def _xy_to_XYZ(x: float, y: float) -> np.ndarray:
    """Convert xy chromaticity to XYZ with Y=1.
    
    Port of dng_color_spec.cpp: XYtoXYZ()
    """
    return np.array([x / y, 1.0, (1.0 - x - y) / y], dtype=np.float64)


def _XYZ_to_xy(XYZ: np.ndarray) -> tuple:
    """Convert XYZ to xy chromaticity.
    
    Port of dng_color_spec.cpp: XYZtoXY()
    """
    s = XYZ[0] + XYZ[1] + XYZ[2]
    if s <= 0:
        return D50_xy  # Fallback
    return (XYZ[0] / s, XYZ[1] / s)


def _neutral_to_xy(neutral: np.ndarray, color_matrix: np.ndarray, 
                   max_passes: int = 30) -> tuple:
    """Convert camera neutral to white point xy chromaticity.
    
    Port of dng_color_spec.cpp: NeutralToXY() (lines 659-706)
    Iteratively finds the white point that produces the given neutral.
    
    Args:
        neutral: Camera neutral RGB values (AsShotNeutral)
        color_matrix: XYZ to Camera matrix (ColorMatrix)
        max_passes: Maximum iterations (default 30 per SDK)
        
    Returns:
        (x, y) chromaticity of white point
    """
    last = D50_xy
    
    for pass_num in range(max_passes):
        # Invert color matrix to get camera->XYZ
        camera_to_xyz = np.linalg.inv(color_matrix)
        
        # Convert neutral through inverted matrix to get XYZ
        xyz = camera_to_xyz @ neutral
        
        # Convert XYZ to xy
        next_xy = _XYZ_to_xy(xyz)
        
        # Check convergence
        if abs(next_xy[0] - last[0]) + abs(next_xy[1] - last[1]) < 0.0000001:
            return next_xy
        
        # If we reach the limit, average last two estimates
        if pass_num == max_passes - 1:
            next_xy = ((last[0] + next_xy[0]) * 0.5,
                       (last[1] + next_xy[1]) * 0.5)
        
        last = next_xy
    
    return last


def _compute_camera_to_pcs(color_matrix: np.ndarray, white_xy: tuple) -> np.ndarray:
    """Compute Camera RGB to PCS (D50 XYZ) matrix.
    
    Port of dng_color_spec.cpp: SetWhiteXY() (lines 570-609)
    
    The SDK computes:
        fPCStoCamera = colorMatrix * MapWhiteMatrix(D50, white_xy)
        scale = MaxEntry(fPCStoCamera * PCStoXYZ())
        fPCStoCamera = (1/scale) * fPCStoCamera  # CRITICAL SCALING
        fCameraToPCS = Invert(fPCStoCamera)
    
    Args:
        color_matrix: XYZ to Camera matrix (ColorMatrix from DNG)
        white_xy: White point xy chromaticity
        
    Returns:
        3x3 Camera RGB to PCS (D50 XYZ) matrix
    """
    # Bradford adaptation from PCS (D50) to the white point
    # Port of dng_color_spec.cpp: MapWhiteMatrix() (lines 22-57)
    adaptation = compute_bradford_adaptation(D50_xy, white_xy)
    
    # PCS to Camera = ColorMatrix * adaptation
    pcs_to_camera = color_matrix @ adaptation
    
    # SDK ref: dng_color_spec.cpp lines 570-582
    # Scale matrix so PCS white can just be reached when first camera channel saturates
    pcs_white_xyz = _xy_to_XYZ(D50_xy[0], D50_xy[1])  # PCStoXYZ()
    scale = np.max(pcs_to_camera @ pcs_white_xyz)     # MaxEntry(fPCStoCamera * PCStoXYZ())
    if scale != 0:
        pcs_to_camera = pcs_to_camera / scale         # (1.0 / scale) * fPCStoCamera
    
    # Camera to PCS = inverse
    camera_to_pcs = np.linalg.inv(pcs_to_camera)
    
    return camera_to_pcs


def _compute_camera_white(color_matrix: np.ndarray, white_xy: tuple) -> np.ndarray:
    """Compute camera white (what the white point looks like in camera space).
    
    Port of dng_color_spec.cpp: SetWhiteXY() (lines 546-568)
    
    fCameraWhite = colorMatrix * XYtoXYZ(white)
    Then normalized so max entry = 1.0
    
    Args:
        color_matrix: XYZ to Camera matrix
        white_xy: White point xy chromaticity
        
    Returns:
        Normalized camera white RGB values
    """
    white_XYZ = _xy_to_XYZ(white_xy[0], white_xy[1])
    camera_white = color_matrix @ white_XYZ
    
    # Normalize so max = 1.0
    max_val = np.max(camera_white)
    if max_val > 0:
        camera_white = camera_white / max_val
    
    # Clamp to valid range
    camera_white = np.clip(camera_white, 0.001, 1.0)
    
    return camera_white


def apply_radial_distortion_correction(
    rgb_image: np.ndarray,
    radial_params: dict,
    scale_factor: float = 1.0,
    center_x: float = 0.5,
    center_y: float = 0.5,
    focal_length_mm: float = None,
    sensor_width_mm: float = 35.6
) -> np.ndarray:
    """Apply radial distortion correction to an RGB image using Adobe LCP parameters.
    
    Adobe LCP uses "ray-space" normalization where coordinates are normalized by:
        r_ray = (pixel_offset / max_dimension) / (focal_length / sensor_width)
    
    The sensor width is calculated from stCamera:SensorFormatFactor in XMP metadata
    as 36mm / SensorFormatFactor. This gives the actual sensor width for the camera.
    This ray-angle-based coordinate system makes distortion parameters lens-intrinsic
    and focal-length-independent, allowing a single set of k1/k2/k3 values to work
    across the entire zoom range of a lens.
    
    This differs from OpenCV's approach where distortion coefficients are applied
    to normalized pixel coordinates without focal length normalization.
    
    For each output pixel, computes the corresponding input pixel coordinates
    by applying the distortion formula, then uses cv2.remap with bicubic
    interpolation to sample from the source image.
    
    Args:
        rgb_image: Input image (float32, any color space)
        radial_params: Dictionary with keys 'k1', 'k2', 'k3' (distortion coefficients in ray-space)
        scale_factor: Additional zoom multiplier applied during correction (default 1.0)
        center_x: Normalized X center of distortion (0.0-1.0, default 0.5)
        center_y: Normalized Y center of distortion (0.0-1.0, default 0.5)
        focal_length_mm: Focal length in mm for ray-space normalization (required)
        sensor_width_mm: Sensor width in mm for ray-space normalization (default 35.6mm)
        
    Returns:
        Distortion-corrected image (same shape and dtype as input)
    """
    
    if focal_length_mm is None:
        raise ValueError("focal_length_mm is required for radial distortion correction")

    timer = get_active_timer()
    timer.start_step("generate radial map")

    height, width = rgb_image.shape[:2]
    
    # Distortion center from normalized coordinates
    cx = center_x * width
    cy = center_y * height

    # Create meshgrid of output pixel coordinates
    x_coords, y_coords = np.meshgrid(
        np.arange(width, dtype=np.float32),
        np.arange(height, dtype=np.float32)
    )

    # Convert to ray-space coordinates normalized to actual sensor width
    # sensor_width_mm is calculated from stCamera:SensorFormatFactor as 36mm / SensorFormatFactor
    # focal_length_norm converts actual focal length to sensor-relative ratio
    focal_length_norm = focal_length_mm / sensor_width_mm
    norm_scale = max(width, height)
    x_norm = ((x_coords - cx) / norm_scale) / focal_length_norm
    y_norm = ((y_coords - cy) / norm_scale) / focal_length_norm
    
    # Calculate radial distance squared
    r_squared = x_norm**2 + y_norm**2
    
    # Apply radial distortion formula in ray-space
    # r_distorted = r * (1 + k1*r^2 + k2*r^4 + k3*r^6)
    k1 = radial_params['k1']
    k2 = radial_params['k2']
    k3 = radial_params['k3'] 
    distortion_factor = (1.0 + k1 * r_squared + k2 * r_squared**2 + k3 * r_squared**3)
    
    # Compute source coordinates by applying distortion
    x_distorted = cx + scale_factor * (x_coords - cx) * distortion_factor
    y_distorted = cy + scale_factor * (y_coords - cy) * distortion_factor
    
    # Use cv2.remap with bicubic interpolation
    timer.start_step("radial remap (opencv)")
    corrected = cv2.remap(
        rgb_image,
        x_distorted,
        y_distorted,
        interpolation=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0
    )
    timer.end_step()
    
    return corrected


def apply_post_rendering_operations(
    rgb_input: np.ndarray,
    rendering_params: dict
) -> np.ndarray:
    """Apply XMP post-rendering operations in ProPhoto linear space.
    
    Processing pipeline:
    1. Apply tone curves in ProPhoto linear space (Adobe's approach)
    2. Apply lens distortion correction
    
    Tone curve processing follows Adobe's approach: curves are displayed in sRGB gamma 2.2
    space (Melissa RGB) but applied in linear ProPhoto RGB space.
    
    Args:
        rgb_input: Input image in ProPhoto linear space
        rendering_params: Dictionary containing XMP rendering parameters
        
    Returns:
        Output image in ProPhoto linear space
    """
    timer = get_active_timer()
    
    rgb_prophoto_linear = rgb_input
    
    logger.debug(f"apply_post_rendering_operations called with params: {list(rendering_params.keys())}")
    
    # Only copy if we're going to modify
    rgb_output = rgb_prophoto_linear
    
    # Step 1: Apply main curve with hue preservation (if present and no per-channel curves)
    if 'ToneCurvePV2012' in rendering_params:
        xmp_tone_timer = timer.start_step("xmp_tone_curve")
        rgb_output = rgb_prophoto_linear.copy()
        # Build curve LUT and convert from sRGB gamma to linear space
        main_curve_lut = LUT(rendering_params['ToneCurvePV2012'], size=4096, 
                             convert_srgb_gamma_to_linear=True)
        
        xmp_tone_timer.start_step("transform_color (c++)")
        rgb_output = transform_color(
            rgb_output,
            input_lut=main_curve_lut,
            hue_preserving_input_lut=True,
            output_dtype=np.float32
        )
        xmp_tone_timer.close()
        logger.debug("Applied ToneCurvePV2012 with hue preservation (in ProPhoto linear space)")
    
    # Step 2: Apply per-channel curves (if present)
    has_per_channel = False
    channel_timer = None
    for channel_idx, channel_name in enumerate(['Red', 'Green', 'Blue']):
        curve_key = f'ToneCurvePV2012{channel_name}'
        
        if curve_key in rendering_params:
            if not has_per_channel:
                channel_timer = timer.start_step("xmp_channel_curves")
                has_per_channel = True
            
            if rgb_output is rgb_prophoto_linear:
                rgb_output = rgb_prophoto_linear.copy()
            
            # Build per-channel curve LUT and convert from sRGB gamma to linear space
            channel_curve_lut = LUT(rendering_params[curve_key], size=4096,
                                    convert_srgb_gamma_to_linear=True)
            
            # Apply per-channel curve
            channel_data = rgb_output[:, :, channel_idx].astype(np.float32)
            rgb_output[:, :, channel_idx] = np.interp(
                channel_data,
                np.linspace(0.0, 1.0, len(channel_curve_lut.data), dtype=np.float32),
                channel_curve_lut.data
            )
            logger.debug(f"Applied {curve_key} (in ProPhoto linear space)")
    
    if channel_timer is not None:
        channel_timer.close()
    
    # Stage 2 - Apply radial distortion correction (final step after tone curves)
    if 'crlcp:PerspectiveModel' in rendering_params:
        timer.start_step("radial_distortion_correction")

        perspective_model = rendering_params['crlcp:PerspectiveModel']
        logger.debug(f"Found crlcp:PerspectiveModel: {perspective_model}")
        
        # Check if radial distortion parameters are present
        has_radial = all(
            f'stCamera:RadialDistortParam{i}' in perspective_model 
            for i in [1, 2, 3]
        )
        if has_radial:
            radial_params = {
                'k1': float(perspective_model['stCamera:RadialDistortParam1']),
                'k2': float(perspective_model['stCamera:RadialDistortParam2']),
                'k3': float(perspective_model['stCamera:RadialDistortParam3']),
            }
            
            # Extract scale factor if present (default 1.0)
            scale_factor = float(perspective_model.get('stCamera:ScaleFactor', 1.0))
            
            # Extract distortion center if present (defaults to 0.5, 0.5 = image center)
            center_x = float(perspective_model.get('stCamera:ImageXCenter', 0.5))
            center_y = float(perspective_model.get('stCamera:ImageYCenter', 0.5))
            
            # Extract focal length (required for ray-space normalization)
            focal_length_mm = perspective_model.get('stCamera:FocalLength')
            if focal_length_mm is None:
                logger.warning("Missing stCamera:FocalLength in perspective model, skipping radial distortion correction")
            else:
                focal_length_mm = float(focal_length_mm)
                
                # Extract sensor format factor to calculate actual sensor width
                # SensorFormatFactor is the crop factor relative to full-frame (36mm width)
                sensor_format_factor = perspective_model.get('stCamera:SensorFormatFactor')
                if sensor_format_factor is not None:
                    sensor_format_factor = float(sensor_format_factor)
                    sensor_width_mm = 36.0 / sensor_format_factor
                    logger.debug(f"Using sensor width {sensor_width_mm:.3f}mm (SensorFormatFactor={sensor_format_factor})")
                else:
                    # Fallback to "average" 35.8mm if SensorFormatFactor not available
                    sensor_width_mm = 35.8
                    logger.debug(f"SensorFormatFactor not found, using default sensor width {sensor_width_mm}mm")
                
                logger.debug(f"Radial distortion params: {radial_params}, scale_factor: {scale_factor}, center: ({center_x}, {center_y}), focal_length: {focal_length_mm}mm")
                rgb_output = apply_radial_distortion_correction(
                    rgb_output, radial_params, scale_factor, center_x, center_y, focal_length_mm, sensor_width_mm)
                logger.debug("Applied radial distortion correction")
        
        timer.end_step()

    return rgb_output

def _get_ifd0_tag(
    ifd0_tags: "DngPage" | "MetadataTags",
    raw_ifd_tags: "DngPage" | "MetadataTags" | None,
    tag: str | int,
    return_type: type | None = None
) -> Any:
    """Get a tag value from IFD0 with validation.
    
    Internal helper for _render_camera_rgb() that enforces only IFD0/profile
    tags are accessed, preventing coding errors where SubIFD-specific tags
    are requested.
    
    Args:
        ifd0_tags: The IFD0 metadata tags (DngPage or MetadataTags)
        raw_ifd_tags: Optional raw IFD tags to check as fallback for ill-formed files
        tag: Tag name or code
        return_type: Optional type conversion
        
    Returns:
        Tag value or None if not found
        
    Raises:
        AssertionError: If tag is not marked as dng_ifd0 or dng_profile
    """
    from .tiff_metadata import resolve_tag
    
    # Resolve tag to get spec
    tag_id, tag_name, spec = resolve_tag(tag)
    
    # Assert tag is known and is IFD0 or profile tag (coding error check)
    assert spec is not None, \
        f"Tag '{tag_name or tag}' is not in TIFF_TAG_TYPE_REGISTRY"
    assert spec.dng_ifd in ("ifd0", "dng_ifd0", "dng_profile", "any"), \
        f"Tag '{tag_name}' (dng_ifd={spec.dng_ifd}) is not an IFD0/profile tag"
    
    # Try IFD0 first
    value = ifd0_tags.get_tag(tag, return_type)
    
    # Fall back to raw_ifd_tags for ill-formed files where tags might be in wrong IFD
    if value is None and raw_ifd_tags is not None:
        value = raw_ifd_tags.get_tag(tag, return_type)
    
    return value

def _linearize(
    tags: "DngPage" | "MetadataTags",
    data: np.ndarray,
    photometric: str,
) -> np.ndarray:
    """Linearize raw sensor data: apply OpcodeList1, normalize, apply OpcodeList2.

    Args:
        tags: Tag source (raw IFD page or MetadataTags) providing linearization tags.
        data: Raw decoded image data.
        photometric: Photometric interpretation string ("CFA" or "LINEAR_RAW").

    Returns:
        Normalized float32 array with opcode lists applied.
    """
    timer = get_active_timer()
    is_cfa = photometric == "CFA"
    is_linear_raw = photometric == "LINEAR_RAW"

    # Apply OpcodeList1 to raw sensor data (before linearization)
    # OpcodeList1 is CFA-only (gain maps, per-row noise correction)
    opcode_list1 = tags.get_tag("OpcodeList1")
    if opcode_list1 is not None and not is_cfa:
        logger.warning("OpcodeList1 present on non-CFA page; skipping")
    if opcode_list1 is not None and is_cfa:
        ops1_timer = timer.start_step("opcode_list1")
        try:
            opcodes = parse_opcode_list(bytes(opcode_list1))
        except Exception as e:
            logger.warning(f"Failed to parse OpcodeList1 ({type(e).__name__}): {e}")
            opcodes = None

        if opcodes:
            try:
                logger.debug(f"OpcodeList1: {len(opcodes)} opcodes")
                ops1_timer.start_step("apply_opcodes_cfa (c++)")
                data = apply_opcodes_cfa(data, opcodes, "OpcodeList1")
                ops1_timer.end_step()
            except Exception as e:
                logger.warning(f"Failed to apply OpcodeList1 ({type(e).__name__}): {e}")
        ops1_timer.close()

    if is_cfa:
        samples_per_pixel = 1
    else:
        samples_per_pixel = int(tags.get_tag("SamplesPerPixel") or 1)

    black_repeat_dim = tags.get_tag("BlackLevelRepeatDim")
    if black_repeat_dim is None:
        black_repeat_dim = (1, 1)
    black_repeat_rows = int(black_repeat_dim[0]) if hasattr(black_repeat_dim, "__len__") else 1
    black_repeat_cols = (
        int(black_repeat_dim[1])
        if hasattr(black_repeat_dim, "__len__") and len(black_repeat_dim) > 1
        else 1
    )
    expected_black_size = black_repeat_rows * black_repeat_cols * samples_per_pixel

    black_level_raw = tags.get_tag("BlackLevel")
    if black_level_raw is None:
        black_level = np.zeros(expected_black_size, dtype=np.float32)
    else:
        black_level = np.atleast_1d(black_level_raw).astype(np.float32).ravel()
        if len(black_level) != expected_black_size:
            black_level = np.zeros(expected_black_size, dtype=np.float32)

    bps = tags.get_tag("BitsPerSample")
    if bps is None:
        bits_per_sample = 16
    elif isinstance(bps, np.ndarray):
        bits_per_sample = int(bps.flat[0])
    else:
        bits_per_sample = int(bps)

    # Check if this is float data (SampleFormat = 3)
    sample_format = tags.get_tag("SampleFormat")
    if sample_format is not None:
        # SampleFormat can be a single value or array
        if isinstance(sample_format, (list, tuple, np.ndarray)):
            sample_format = sample_format[0]

    # Match DNG SDK default: float uses 1.0, integer uses (2^bits - 1)
    # DNG SDK reference: dng_ifd.cpp lines 3466-3468
    if sample_format == 3:
        default_white = 1.0
    else:
        # Integer data (SampleFormat=1) or missing SampleFormat tag
        default_white = float((1 << bits_per_sample) - 1)

    white_level_raw = tags.get_tag("WhiteLevel")
    if white_level_raw is None:
        white_level = np.full(samples_per_pixel, default_white, dtype=np.float32)
    else:
        white_level = np.atleast_1d(white_level_raw).astype(np.float32).ravel()
        white_level = np.where(white_level < 0, default_white, white_level)
        if len(white_level) != samples_per_pixel:
            logger.warning(
                f"WhiteLevel count ({len(white_level)}) != "
                f"SamplesPerPixel ({samples_per_pixel})"
            )
            if len(white_level) > samples_per_pixel:
                white_level = white_level[:samples_per_pixel]
            else:
                pad = np.full(
                    samples_per_pixel - len(white_level),
                    white_level[-1],
                    dtype=np.float32,
                )
                white_level = np.concatenate([white_level, pad])

    black_delta_h = tags.get_tag("BlackLevelDeltaH")
    black_delta_v = tags.get_tag("BlackLevelDeltaV")
    if black_delta_h is not None:
        black_delta_h = np.atleast_1d(black_delta_h).astype(np.float32)
    if black_delta_v is not None:
        black_delta_v = np.atleast_1d(black_delta_v).astype(np.float32)

    linearization_table = tags.get_tag("LinearizationTable")
    if linearization_table is not None:
        linearization_table = np.asarray(linearization_table, dtype=np.uint16)

    active_area = tags.get_tag("ActiveArea")
    if active_area is not None:
        aa_top, aa_left, aa_bottom, aa_right = active_area
        data = data[aa_top:aa_bottom, aa_left:aa_right]

    # Fast path: trivial normalization (black=0, white=default, no
    # deltas/LUT, uint16 data) can use optimized convert_dtype instead
    is_pure_convert = (
        samples_per_pixel == 3
        and data.dtype == np.uint16
        and black_delta_h is None
        and black_delta_v is None
        and (linearization_table is None or len(linearization_table) == 0)
        and np.all(black_level == 0.0)
        and np.all(white_level == default_white)
    )

    timer.start_step("linearize (c++)")
    if is_pure_convert:
        normalized = convert_dtype(
            data,
            np.float32,
            src_bits_per_element=bits_per_sample,
        )
    else:
        # normalize_raw accepts uint16 or float32 natively;
        # convert edge-case dtypes to the nearest supported type
        norm_data = data
        if norm_data.dtype == np.uint8:
            norm_data = norm_data.astype(np.uint16)
        elif norm_data.dtype == np.float16:
            norm_data = norm_data.astype(np.float32)
        elif norm_data.dtype not in (np.uint16, np.float32):
            norm_data = norm_data.astype(np.float32)
        normalized = _raw_render.normalize_raw(
            data=norm_data,
            black_level=black_level,
            black_repeat_rows=black_repeat_rows,
            black_repeat_cols=black_repeat_cols,
            samples_per_pixel=samples_per_pixel,
            white_level=white_level,
            black_delta_h=black_delta_h,
            black_delta_v=black_delta_v,
            linearization_table=linearization_table,
        )
    timer.end_step()

    opcode_list2 = tags.get_tag("OpcodeList2")
    if opcode_list2 is not None:
        ops2_timer = timer.start_step("opcode_list2")
        try:
            opcodes = parse_opcode_list(bytes(opcode_list2))
        except Exception as e:
            logger.warning(f"Failed to parse OpcodeList2 ({type(e).__name__}): {e}")
            opcodes = None

        if opcodes:
            try:
                logger.debug(f"OpcodeList2: {len(opcodes)} opcodes, "
                            f"is_linear_raw={is_linear_raw}, is_cfa={is_cfa}, "
                            f"data.shape={normalized.shape}")
                if is_linear_raw:
                    ops2_timer.start_step("apply_opcodes (c++)")
                    normalized = apply_opcodes(
                        normalized, opcodes,
                        use_bicubic=False,
                        opcode_list_name="OpcodeList2"
                    )
                    ops2_timer.close()
                    return normalized
                else:
                    # CFA data
                    ops2_timer.start_step("apply_opcodes_cfa (c++)")
                    normalized = apply_opcodes_cfa(
                        normalized, opcodes, "OpcodeList2"
                    )
                    ops2_timer.close()
                    return normalized
            except Exception as e:
                logger.warning(f"Failed to apply OpcodeList2 ({type(e).__name__}): {e}")
        ops2_timer.close()

    return normalized


def _raw_to_camera_rgb(
    tags: "DngPage" | "MetadataTags",
    data: np.ndarray,
    photometric: str,
    cfa_pattern: str | None,
    demosaic_algorithm: "DemosaicAlgorithm",
) -> np.ndarray:
    """Linearize raw data, demosaic if CFA, apply OpcodeList3 and DefaultCrop.

    Args:
        tags: Tag source (raw IFD page or MetadataTags) providing linearization/opcode tags.
        data: Raw decoded image data.
        photometric: Photometric interpretation string ("CFA" or "LINEAR_RAW").
        cfa_pattern: CFA pattern string (e.g. "RGGB"), required if photometric == "CFA".
        demosaic_algorithm: Demosaic algorithm to use when the source is CFA.

    Returns:
        Camera RGB array (H, W, 3) float32 in [0, 1].
    """
    timer = get_active_timer()

    normalized = _linearize(tags, data, photometric)

    if photometric == "CFA":
        demosaic_timer = timer.start_step("demosaic")
        # Bilinear guarantees [0,1] output through averaging - skip clip
        clip_value = None if demosaic_algorithm == DemosaicAlgorithm.DNGSDK_BILINEAR else 1.0
        rgb_camera = demosaic(
            normalized, cfa_pattern, algorithm=demosaic_algorithm,
            clip_max=clip_value, return_dtype=np.float32
        )
        demosaic_timer.close()
    else:
        rgb_camera = normalized

    # Apply OpcodeList3 (Stage3 operations)
    opcode_list3 = tags.get_tag("OpcodeList3")
    if opcode_list3 is not None:
        ops3_timer = timer.start_step("opcode_list3")
        try:
            opcodes = parse_opcode_list(bytes(opcode_list3))
        except Exception as e:
            logger.warning(f"Failed to parse OpcodeList3 ({type(e).__name__}): {e}")
            opcodes = None

        if opcodes:
            try:
                logger.debug(f"OpcodeList3: {len(opcodes)} opcodes")
                ops3_timer.start_step("apply_opcodes (c++)")
                rgb_camera = apply_opcodes(
                    rgb_camera, opcodes,
                    use_bicubic=False,
                    opcode_list_name="OpcodeList3"
                )
                ops3_timer.end_step()
            except Exception as e:
                logger.warning(f"Failed to apply OpcodeList3 ({type(e).__name__}): {e}")
        ops3_timer.close()

    # Apply DefaultCrop
    crop_origin = tags.get_tag("DefaultCropOrigin")
    crop_size = tags.get_tag("DefaultCropSize")

    if crop_origin is not None and crop_size is not None:
        crop_x = int(crop_origin[0])
        crop_y = int(crop_origin[1])
        crop_w = int(crop_size[0])
        crop_h = int(crop_size[1])
        rgb_camera = rgb_camera[crop_y:crop_y + crop_h, crop_x:crop_x + crop_w]

    return rgb_camera


def _render_camera_rgb(
    ifd0_tags: "DngPage" | "MetadataTags",
    rgb_camera: np.ndarray,
    output_dtype: type,
    raw_ifd_tags: "DngPage" | "MetadataTags" | None = None,
    rendering_params: dict = None,
    use_xmp: bool = True,
) -> np.ndarray:
    timer = get_active_timer()

    try:
        setup_timer = timer.start_step("render_setup")
        
        # Build rendering parameters dict from XMP and overrides (filters out NOOP values)
        extracted_params = supported_xmp_to_dict(ifd0_tags) if use_xmp else {}
        
        # Merge rendering_params overrides (with validation)
        if rendering_params is not None:
            # Render-method specific parameters (not from XMP)
            render_specific_params = {'highlight_preserving_exposure', 'orientation'}
            # Combine XMP params and render-specific params
            supported_params = SUPPORTED_XMP_PARAMS | render_specific_params
            
            for key, value in rendering_params.items():
                if key not in supported_params:
                    raise ValueError(
                        f"Unsupported rendering parameter: {key}. "
                        f"Supported: {supported_params}"
                    )
                extracted_params[key] = value
        
        # Use extracted_params for rendering (None if empty dict)
        rendering_params = extracted_params if extracted_params else None
        setup_timer.close()
        
        # =====================================================================
        # Setup: Compute matrices (port of dng_render_task::Start)
        # SDK ref: dng_render.cpp lines 869-1070
        # =====================================================================
        cam2pro_timer = timer.start_step("camera_to_prophoto")
        
        # Get ColorMatrix1 (XYZ to Camera, 3x3)
        color_matrix1 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ColorMatrix1")
        if color_matrix1 is None:
            logger.warning("No ColorMatrix1 found, using identity")
            color_matrix1 = np.eye(3, dtype=np.float64)
        else:
            color_matrix1 = np.asarray(color_matrix1, dtype=np.float64)
        
        # Get ColorMatrix2 for dual-illuminant interpolation
        color_matrix2 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ColorMatrix2")
        if color_matrix2 is not None:
            color_matrix2 = np.asarray(color_matrix2, dtype=np.float64)
        
        # Get ForwardMatrix1/2 (camera to PCS, 3x3)
        # SDK ref: dng_color_spec.cpp lines 126-128, 177, 213, 586-596
        # NormalizeForwardMatrix is called BEFORE AnalogBalance/CameraCalibration
        forward_matrix1 = _normalize_forward_matrix(_get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ForwardMatrix1"))
        forward_matrix2 = _normalize_forward_matrix(_get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ForwardMatrix2"))
        
        # Get CameraCalibration1/2 matrices (3x3, default to identity)
        # SDK ref: dng_color_spec.cpp lines 134-166
        camera_calib1 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "CameraCalibration1")
        camera_calib2 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "CameraCalibration2")
        if camera_calib1 is None:
            camera_calib1 = np.eye(3, dtype=np.float64)
        if camera_calib2 is None:
            camera_calib2 = np.eye(3, dtype=np.float64)
        
        # Get calibration illuminant temperatures
        illum1 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "CalibrationIlluminant1")
        illum2 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "CalibrationIlluminant2")
        temp1 = Illuminant(illum1).temperature if illum1 is not None else None
        temp2 = Illuminant(illum2).temperature if illum2 is not None else None
        
        # Get AsShotNeutral -> convert to white point XY
        # SDK ref: dng_render.cpp lines 889-908
        # Override with rendering_params temperature/tint if provided
        camera_neutral = None
        white_xy_override = None
        
        if rendering_params and 'Temperature' in rendering_params:
            # Use temperature/tint from rendering_params
            temp = rendering_params['Temperature']
            tint = rendering_params.get('Tint', 0.0)
            white_xy_override = temp_tint_to_xy(temp, tint)
        else:
            # Use DNG tags
            as_shot = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "AsShotNeutral")
            as_shot_xy = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "AsShotWhiteXY")
            
            if as_shot is not None and hasattr(as_shot, '__len__') and len(as_shot) >= 3:
                camera_neutral = np.array(as_shot[:3], dtype=np.float64)
            elif as_shot_xy is not None and len(as_shot_xy) >= 2:
                white_xy_override = (float(as_shot_xy[0]), float(as_shot_xy[1]))
            else:
                white_xy_override = D55_xy  # SDK default
        
        # Get AnalogBalance
        ab_diag = np.eye(3, dtype=np.float64)
        analog_balance = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "AnalogBalance")
        if analog_balance is not None:
            analog_balance = np.asarray(analog_balance, dtype=np.float64)
            if analog_balance.size >= 3:
                ab_diag = np.diag(analog_balance[:3])
        
        # Apply AnalogBalance and CameraCalibration to ColorMatrix BEFORE interpolation
        # SDK ref: dng_color_spec.cpp lines 179, 215
        color_matrix1 = ab_diag @ camera_calib1 @ color_matrix1
        if color_matrix2 is not None:
            color_matrix2 = ab_diag @ camera_calib2 @ color_matrix2

        # Determine interpolation weight and interpolate matrices
        # SDK ref: dng_color_spec.cpp FindXYZtoCamera_SingleOrDual() lines 301-460
        if color_matrix2 is not None and temp1 is not None and temp2 is not None and temp1 != temp2:
            # Dual-illuminant: interpolate based on scene temperature
            white_xy_est = white_xy_override if white_xy_override else _neutral_to_xy(camera_neutral, color_matrix1)
            scene_temp = xy_to_temp_tint(white_xy_est[0], white_xy_est[1])[0]
            
            # Calculate interpolation weight g
            t1, t2 = (temp1, temp2) if temp1 < temp2 else (temp2, temp1)
            if scene_temp <= t1:
                g = 1.0
            elif scene_temp >= t2:
                g = 0.0
            else:
                inv_t = 1.0 / scene_temp
                g = (inv_t - 1.0/t2) / (1.0/t1 - 1.0/t2)
            
            # Interpolate matrices (g1 weights matrix1, g2 weights matrix2)
            g1, g2 = (1.0 - g, g) if temp1 > temp2 else (g, 1.0 - g)
            color_matrix = g1 * color_matrix1 + g2 * color_matrix2
            camera_calib = g1 * camera_calib1 + g2 * camera_calib2
            if forward_matrix1 is not None and forward_matrix2 is not None:
                forward_matrix = g1 * forward_matrix1 + g2 * forward_matrix2
            else:
                forward_matrix = forward_matrix1 if forward_matrix1 is not None else forward_matrix2
        else:
            # Single illuminant
            color_matrix = color_matrix1
            camera_calib = camera_calib1
            forward_matrix = forward_matrix1 if forward_matrix1 is not None else forward_matrix2
        
        # SDK ref: dng_color_spec.cpp NeutralToXY() lines 659-706
        white_xy = white_xy_override if white_xy_override else _neutral_to_xy(camera_neutral, color_matrix)
        
        # SDK ref: dng_color_spec.cpp SetWhiteXY() lines 546-568
        camera_white = _compute_camera_white(color_matrix, white_xy)
        
        # SDK ref: dng_color_spec.cpp SetWhiteXY() lines 570-609
        # ForwardMatrix takes precedence if present
        if forward_matrix is not None:
            # fCameraToPCS = forwardMatrix * Invert(refCameraWhite.AsDiagonal()) * individualToReference
            individual_to_ref = np.linalg.inv(ab_diag @ camera_calib)
            ref_camera_white = individual_to_ref @ camera_white
            ref_camera_white = np.clip(ref_camera_white, 0.001, None)
            camera_to_pcs = forward_matrix @ np.linalg.inv(np.diag(ref_camera_white)) @ individual_to_ref
        else:
            camera_to_pcs = _compute_camera_to_pcs(color_matrix, white_xy)
        
        # =====================================================================
        # Step 1: DoBaselineABCtoRGB
        # SDK ref: dng_reference.cpp lines 1389-1441
        # Clip to camera_white, apply camera_to_prophoto matrix, pin to [0,1]
        # =====================================================================
        # SDK ref: dng_render.cpp lines 912-913
        # fCameraToRGB = ProPhoto.MatrixFromPCS() * CameraToPCS()
        camera_to_prophoto = XYZ_D50_TO_PROPHOTO_RGB @ camera_to_pcs
        
        cam2pro_timer.start_step("clip_and_transform_color (c++)")
        rgb_prophoto = clip_and_transform_color(
            rgb_camera,
            clip_max=camera_white.astype(np.float32),
            matrix=camera_to_prophoto.astype(np.float32))
        cam2pro_timer.close()
        del rgb_camera
        
        # =====================================================================
        # Step 1.5: DoBaselineHueSatMap (ProfileHueSatMap)
        # SDK ref: dng_render.cpp lines 917-955, 1822-1837
        # Applied AFTER camera->ProPhoto, BEFORE exposure ramp
        # =====================================================================
        hue_sat_dims = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileHueSatMapDims")
        hue_sat_data1 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileHueSatMapData1")
        
        if hue_sat_dims is not None and hue_sat_data1 is not None:
            hsm_timer = timer.start_step("hue_sat_map")
            hue_divs, sat_divs, val_divs = int(hue_sat_dims[0]), int(hue_sat_dims[1]), int(hue_sat_dims[2])
            hue_sat_data1 = np.asarray(hue_sat_data1, dtype=np.float32)
            hue_sat_data2 = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileHueSatMapData2")
            
            # Interpolate between dual illuminant HueSatMaps if available
            if hue_sat_data2 is not None and temp1 is not None and temp2 is not None and temp1 != temp2:
                hue_sat_data2 = np.asarray(hue_sat_data2, dtype=np.float32)
                # Use same scene_temp calculated for matrix interpolation
                white_xy_est = white_xy_override if white_xy_override else _neutral_to_xy(camera_neutral, color_matrix1)
                interp_scene_temp = xy_to_temp_tint(white_xy_est[0], white_xy_est[1])[0]
                hue_sat_map = interpolate_hue_sat_map(hue_sat_data1, hue_sat_data2, temp1, temp2, interp_scene_temp)
            else:
                hue_sat_map = hue_sat_data1
            
            logger.debug(f"ProfileHueSatMap: {hue_divs}x{sat_divs}x{val_divs}")

            hsm_timer.start_step("apply_hue_sat_map (c++)")
            rgb_prophoto = _raw_render.apply_hue_sat_map(
                rgb_prophoto,
                hue_sat_map,
                hue_divs, sat_divs, val_divs
            )
            hsm_timer.end_step()
            hsm_timer.close()
        
        # =====================================================================
        # Step 1.6: DoBaselineProfileGainTableMap
        # SDK ref: dng_render.cpp lines 1843-1903
        # Applied AFTER HueSatMap, BEFORE exposure ramp
        # =====================================================================
        # SDK ref: dng_render.cpp line 1882: exposureWeightGain = pow(2.0, fBaselineExposure)
        # fBaselineExposure = TotalBaselineExposure (Stage3Gain = 1.0 for normal images)
        # Note: PGTM uses only baseline exposure, NOT user exposure
        baseline_exposure = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "BaselineExposure") or 0.0
        baseline_exposure_offset = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "BaselineExposureOffset") or 0.0
        total_baseline_exposure = baseline_exposure + baseline_exposure_offset
        
        # Add user exposure from rendering_params if provided
        user_exposure = rendering_params.get('Exposure2012', 0.0) if rendering_params else 0.0
        exposure = total_baseline_exposure + user_exposure
        
        # =====================================================================
        # Step 2: DoProfileGainTableMap (PGTM)
        # SDK ref: dng_render.cpp lines 1862-1910
        # Per DNG spec: PGTM2 (DNG 1.7) uses IFD0 or Camera Profile IFD
        # PGTM (DNG 1.6) was intended for IFD0 but spec mistakenly said "Raw IFD"
        # Check raw_ifd_tags first for PGTM (for files following the mistaken spec), then IFD0
        pgtm_data = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileGainTableMap2")
        is_version2 = pgtm_data is not None
        
        if pgtm_data is None:
            # Get PGTM on raw_ifd_tags (only raw_ifd tag in this function due to 
            # mistake in DNG 1.6 spec)
            if raw_ifd_tags:
                pgtm_data = raw_ifd_tags.get_tag("ProfileGainTableMap")
        
        if pgtm_data is not None:
            pgtm_timer = timer.start_step("profile_gain_table_map")
            try:
                # PGTM data is already normalized to system byte order by get_page_tags()
                # SDK ref: dng_ifd.cpp lines 2769-2772 - GetStream uses same stream as file
                import sys
                system_byteorder = '<' if sys.byteorder == 'little' else '>'
                pgtm = parse_profile_gain_table_map(
                    bytes(pgtm_data),
                    is_version2=is_version2,
                    byteorder=system_byteorder,
                )
                pgtm_timer.start_step("apply_profile_gain_table_map (c++)")
                rgb_prophoto = _raw_render.apply_profile_gain_table_map(
                    rgb_prophoto,
                    pgtm["gains"],
                    pgtm["weights"],
                    int(pgtm["points_v"]),
                    int(pgtm["points_h"]),
                    float(pgtm["spacing_v"]),
                    float(pgtm["spacing_h"]),
                    float(pgtm["origin_v"]),
                    float(pgtm["origin_h"]),
                    int(pgtm["num_table_points"]),
                    float(pgtm["gamma"]),
                    float(total_baseline_exposure),
                )
            except Exception as e:
                logger.warning(f"Failed to apply ProfileGainTableMap ({type(e).__name__}): {e}")
            pgtm_timer.close()

        # =====================================================================
        # Step 2: DoBaseline1DFunction (ExposureRamp)
        # SDK ref: dng_render.cpp lines 975-999, 1907-1928
        # Maps [black, white] to [0, 1]
        # =====================================================================
        # Note: exposure = total_baseline_exposure + user_exposure (computed above)
        
        # Extract DNG tags for exposure_ramp
        shadow_scale = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ShadowScale") or 1
        default_black_render = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "DefaultBlackRender") or 0
        
        logger.debug(f"Shadow params: shadow_scale={shadow_scale:.4f}, default_black_render={default_black_render}")
        
        # Determine if using highlight prservation or DNG SDK behavior
        # Default to True (highlight preservation)
        highlight_preserving_exposure = True
        if rendering_params:
            highlight_preserving_exposure = rendering_params.get(
                'highlight_preserving_exposure', True
            )

        # Compute exposure_ramp LUT
        # Pass rgb_prophoto for adaptive exposure blending
        timer.start_step("compute_exposure_ramp_lut")
        exposure_ramp_lut = compute_exposure_ramp_lut(
            exposure, shadow_scale, default_black_render, highlight_preserving_exposure,
            rgb_prophoto=rgb_prophoto
        )
        timer.end_step()
        logger.debug(f"Exposure_ramp LUT: first={exposure_ramp_lut[0]:.6f}, last={exposure_ramp_lut[-1]:.6f}, "
                    f"mean={np.mean(exposure_ramp_lut):.6f}")

        # =====================================================================
        # Step 2.5: DoBaselineHueSatMap (ProfileLookTable)
        # SDK ref: dng_render.cpp lines 1930-1947
        # Applied AFTER exposure ramp, BEFORE tone curve
        # =====================================================================
        look_table = None
        look_table_dims = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileLookTableDims")
        look_table_data = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileLookTableData")
        
        if look_table_dims is not None and look_table_data is not None:
            look_hue_divs, look_sat_divs, look_val_divs = int(look_table_dims[0]), int(look_table_dims[1]), int(look_table_dims[2])
            look_table = np.asarray(look_table_data, dtype=np.float32)
            logger.debug(f"ProfileLookTable: {look_hue_divs}x{look_sat_divs}x{look_val_divs}")
        
        # Build combined tone curve based on whether look_table exists
        # If no look_table: exposure_ramp -> exposure_tone -> profile_curve (all baked into one LUT)
        # If look_table: exposure_tone -> profile_curve (exposure_ramp applied to pixels separately)
        if look_table is not None:
            # Must apply exposure_ramp separately when look_table exists
            # SDK ref: dng_render.cpp dng_function_exposure_ramp lines 50-103
            timer.start_step("exposure_ramp (c++)")
            rgb_exposed = transform_color(
                rgb_prophoto, input_lut=exposure_ramp_lut, output_dtype=np.float32
            )
            timer.end_step()
            
            timer.start_step("look_table (c++)")
            rgb_exposed = _raw_render.apply_hue_sat_map(
                rgb_exposed,
                look_table,
                look_hue_divs, look_sat_divs, look_val_divs
            )
            timer.end_step()
            
            # Start combined curve with identity (exposure_ramp already applied to pixels)
            combined_curve = LUT(None, size=4096)
        else:
            # No look_table: exposure_ramp will be baked into tone curve
            rgb_exposed = rgb_prophoto
            
            # Start combined curve with exposure_ramp
            combined_curve = LUT(exposure_ramp_lut)
        
        timer.start_step("build_combined_lut")
        # Chain: apply exposure_tone to output
        combined_curve = combined_curve.compose_output(
            lambda y: exposure_tone(y, exposure, highlight_preserving_exposure)
        )
        
        # =====================================================================
        # Step 3: DoBaselineRGBTone (ALWAYS applied)
        # SDK ref: dng_render.cpp lines 1949-1970, 2145-2162
        # Uses ProfileToneCurve if present, otherwise ACR3 default
        # =====================================================================        
        # Get ProfileToneCurve from DNG tags, or use ACR3 default
        # SDK ref: dng_render.cpp lines 2153-2162
        tag_profile_curve = None
        if _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileToneCurve") is not None:
            profile_tone_curve = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "ProfileToneCurve")
            if len(profile_tone_curve) >= 4:
                # ProfileToneCurve is array of 2N values: [x0, y0, x1, y1, ...]
                curve_data = np.asarray(profile_tone_curve, dtype=np.float64)
                n_points = len(curve_data) // 2
                points = [(curve_data[i*2], curve_data[i*2+1]) for i in range(n_points)]
                
                try:
                    tag_profile_curve = LUT(points, size=4096).data
                    logger.debug(f"Using ProfileToneCurve with {n_points} control points")
                except ValueError as e:
                    # Fallback to ACR3 if curve is invalid (e.g., non-monotonic x)
                    logger.warning(f"ProfileToneCurve invalid ({type(e).__name__}): {e}, using ACR3")
        
        profile_curve = get_acr3_curve(4096) if tag_profile_curve is None else tag_profile_curve
        
        # Chain: apply profile tone curve to output (combined_curve already has exposure_ramp and exposure_tone)
        combined_curve = combined_curve.compose_output(LUT(profile_curve))
        timer.end_step()
        
        # =====================================================================
        # Step 4-5: Apply tone curve + colorspace conversion (merged when no post-rendering)
        # SDK ref: dng_render.cpp lines 2040-2068
        # =====================================================================
        # Check if there are actual post-rendering operations (tone curves or lens correction)
        # Other params like exposure, temperature, orientation are handled elsewhere
        post_rendering_keys = {
            'ToneCurvePV2012', 'ToneCurvePV2012Red', 'ToneCurvePV2012Green', 
            'ToneCurvePV2012Blue', 'crlcp:PerspectiveModel'
        }
        has_post_rendering = rendering_params and bool(post_rendering_keys & rendering_params.keys())
        
        if has_post_rendering:
            # Post-rendering exists: apply tone curve first, then post-rendering
            timer.start_step("tone_curve (c++)")
            rgb_toned = transform_color(
                rgb_exposed,
                input_lut=combined_curve,
                hue_preserving_input_lut=True,
                output_dtype=np.float32
            )
            timer.end_step()
            del rgb_exposed

            # Apply post-rendering (tone curves, lens correction) in ProPhoto linear
            rgb_to_convert = apply_post_rendering_operations(rgb_toned, rendering_params)
            del rgb_toned

            tone_input_lut = None  # No tone curve for final conversion
            timing_label = "prophoto_to_srgb"
        else:
            # No post-rendering: merge tone curve + colorspace in single pass
            rgb_to_convert = rgb_exposed
            del rgb_exposed
            tone_input_lut = combined_curve
            timing_label = "tone_curve+srgb"
        
        # Convert ProPhoto (D50) → sRGB (D65), apply sRGB gamma, convert dtype
        convert_timer = timer.start_step(timing_label)
        matrix = compute_colorspace_matrix(ColorSpace.PROPHOTO_LINEAR, ColorSpace.SRGB_GAMMA)
        output_lut = ColorSpaceLUT(ColorSpace.SRGB_GAMMA, inverse=False, size=4096)
        convert_timer.start_step("transform_color (c++)")
        result = transform_color(
            rgb_to_convert,
            input_lut=tone_input_lut,
            matrix=matrix,
            output_lut=output_lut,
            hue_preserving_input_lut=True if tone_input_lut else False,
            output_dtype=output_dtype
        )
        convert_timer.close()
        del rgb_to_convert

        # Apply orientation rotation at END of pipeline (matching SDK behavior)
        # SDK ref: dng_render.cpp uses DefaultFinalWidth/Height for oriented output
        # Check rendering_params first, fall back to EXIF orientation
        orientation = rendering_params.get('orientation') if rendering_params else None
        if orientation is None:
            orientation = _get_ifd0_tag(ifd0_tags, raw_ifd_tags, "Orientation")
        if orientation is not None:
            result = apply_tiff_orientation(result, orientation)
        
        # timer.start_step("stack_unwind")
        return result

    except Exception as e:
        logger.error(f"Error rendering DNG ({type(e).__name__}): {e}", exc_info=True)
        raise


# =============================================================================
# Pipeline-Specific XMP Conversion Helpers
# =============================================================================

def supported_xmp_from_dict(props: dict) -> 'XmpMetadata':
    """Convert pipeline-supported dict to XmpMetadata.
    
    This handles the limited subset of XMP properties used by the rendering pipeline.
    
    Args:
        props: Dict with pipeline-supported keys:
               - Unqualified names (auto-prepended with 'crs:'): 'Temperature', 'Tint', etc.
               - Fully qualified names: 'tiff:Orientation', 'dc:subject', etc.
               Values can be:
               - Scalar: str, int, float
               - CubicSpline objects (for tone curves)
               - List of 2-tuples (for tone curves)
               - List of strings (for dc:subject bags)
    
    Returns:
        XmpMetadata instance
    """
    from datetime import datetime
    from .tiff_metadata import XmpMetadata
    
    # Build attributes dict with proper namespacing and type conversion
    attributes = {}
    
    # Add standard metadata
    now = datetime.now()
    iso_date = now.strftime('%Y-%m-%dT%H:%M:%S')
    
    attributes['tiff:Orientation'] = '1'
    attributes['dc:format'] = 'image/dng'
    attributes['xmp:CreatorTool'] = 'muimg'
    attributes['xmp:ModifyDate'] = iso_date
    attributes['crs:Version'] = '17.4'
    attributes['crs:ProcessVersion'] = '15.4'
    
    # Process user-provided properties
    for key, value in props.items():
        # Auto-prepend 'crs:' if no namespace specified
        if ':' not in key:
            key = f'crs:{key}'
        
        # Handle different value types
        if key == 'dc:subject' and isinstance(value, list):
            # List of strings for dc:subject bag
            attributes[key] = value
        elif hasattr(value, 'points') and isinstance(getattr(value, 'points'), list):
            # CubicSpline object with points attribute (normalized 0-1)
            attributes[key] = getattr(value, 'points')
        elif isinstance(value, list) and len(value) > 0 and isinstance(value[0], (tuple, list)) and len(value[0]) == 2:
            # Direct list of 2-tuples (tone curve points)
            attributes[key] = [(float(x), float(y)) for x, y in value]
        else:
            # Scalar value
            attributes[key] = str(value)
    
    return XmpMetadata.from_attributes(attributes)


def _is_tone_curve_linear(curve: list) -> bool:
    """Check if a tone curve is linear (identity curve).
    
    Args:
        curve: List of (x, y) tuples representing the tone curve
    
    Returns:
        True if the curve is linear [(0,0), (1,1)], False otherwise
    """
    return (len(curve) == 2 and 
            curve[0] == (0.0, 0.0) and 
            curve[1] == (1.0, 1.0))


def _is_noop_xmp_value(prop_name: str, value, xmp: 'XmpMetadata') -> bool:
    """Check if an XMP property value is a NOOP (no-operation/default).
    
    NOOP values should not be copied to rendering params as they have no effect:
    - Exposure2012 = 0 (no exposure adjustment)
    - WhiteBalance = "As Shot" (use DNG tags, not XMP temp/tint)
    - ToneCurvePV2012* = [(0,0), (1,1)] (linear/identity curve)
    
    Note: get_prop() without return_type returns raw strings from XMP,
    so this function handles string-to-numeric conversion.
    
    Args:
        prop_name: Property name (Temperature, Tint, Exposure2012, etc.)
        value: Property value to check (string from XMP)
        xmp: XmpMetadata object (needed for WhiteBalance gating)
    
    Returns:
        True if value is a NOOP and should be skipped
    """
    if prop_name in ("Temperature", "Tint"):
        # Temperature/Tint are NOOP if WhiteBalance is "As Shot"
        wb = xmp.get_root_prop("WhiteBalance", str)
        if wb == "As Shot":
            return True
        return False
    
    elif prop_name == "Exposure2012":
        # Exposure is NOOP if zero (value is string from XMP)
        return abs(float(value)) <= 0.0001
    
    elif prop_name.startswith("ToneCurvePV2012"):
        # Tone curves are NOOP if linear [(0,0), (1,1)]
        return _is_tone_curve_linear(value)
    
    return False

# Supported XMP rendering parameters extracted from DNG metadata
SUPPORTED_XMP_PARAMS = {
    'Temperature',           # White balance temperature in Kelvin (float)
    'Tint',                  # White balance tint adjustment (float)
    'Exposure2012',          # Exposure compensation in stops (float)
    'ToneCurvePV2012',       # Main tone curve (CubicSpline or list of (x,y) points)
    'ToneCurvePV2012Red',    # Red channel tone curve (CubicSpline or list of (x,y) points)
    'ToneCurvePV2012Green',  # Green channel tone curve (CubicSpline or list of (x,y) points)
    'ToneCurvePV2012Blue',   # Blue channel tone curve (CubicSpline or list of (x,y) points)
    'crlcp:PerspectiveModel', # Lens correction profile (nested dict with RadialDistort params)
    
    # TODO: Add pixel processing implementations for these additional properties:
    # 'Contrast2012', 'Highlights2012', 'Shadows2012', 'Whites2012', 'Blacks2012',
    # 'Texture', 'Clarity2012', 'Dehaze', 'Vibrance', 'Saturation'
}

def supported_xmp_to_dict(source: 'XmpMetadata' | 'MetadataTags' | 'DngFile' | 'DngPage') -> dict:
    """Convert XMP metadata to pipeline-supported dict.
    
    Extracts only the properties used by the rendering pipeline.
    Accepts multiple source types and handles XMP extraction internally.
    
    NOOP values are filtered out:
    - Exposure2012 = 0 (no exposure adjustment)
    - WhiteBalance = "As Shot" (use DNG tags, not XMP temp/tint)
    - ToneCurvePV2012* = [(0,0), (1,1)] (linear/identity curve)
    
    Args:
        source: One of:
               - XmpMetadata instance
               - MetadataTags instance (calls get_xmp())
               - DngFile instance (calls get_xmp())
               - DngPage instance (calls get_xmp())
    
    Returns:
        Dict with pipeline-supported properties (unqualified names for crs: namespace).
        Nested dict structures (e.g., crlcp:PerspectiveModel) are preserved as-is.
        Returns empty dict if source has no XMP metadata.
    """
    from .tiff_metadata import XmpMetadata
    
    # Handle None early
    if source is None:
        return {}
    
    # Extract XmpMetadata from various source types
    if isinstance(source, XmpMetadata):
        xmp = source
    elif hasattr(source, 'get_xmp'):
        # MetadataTags, DngFile, or DngPage with get_xmp() method
        xmp = source.get_xmp()
        if xmp is None:
            return {}
    else:
        raise TypeError(f"Unsupported source type: {type(source).__name__}")
    
    result = {}
    
    # Debug: Check which SUPPORTED_XMP_PARAMS are present
    found_params = [prop for prop in SUPPORTED_XMP_PARAMS if xmp.get_root_prop(prop) is not None]
    logger.debug(f"Found {len(found_params)} supported XMP params: {found_params}")
    
    # Extract root-level properties using get_root_prop()
    # This method works with properties at the root Description level (crs:, dc:, tiff:)
    for prop in SUPPORTED_XMP_PARAMS:
        value = xmp.get_root_prop(prop)
        if value is not None and not _is_noop_xmp_value(prop, value, xmp):
            # Convert numeric properties to float for rendering pipeline
            if prop in ('Temperature', 'Tint', 'Exposure2012'):
                result[prop] = float(value)
            else:
                result[prop] = value  # ToneCurve* already parsed as list[tuple]
    
    # Handle dc:subject (keep qualified name)
    dc_subject = xmp.get_root_prop('dc:subject', list)
    if dc_subject:
        result['dc:subject'] = dc_subject
    
    # Handle tiff:Orientation (keep qualified name)
    orientation = xmp.get_root_prop('tiff:Orientation')
    if orientation is not None:
        result['tiff:Orientation'] = orientation
    
    # Extract deeply nested properties using xpath_query_with_parent()
    # PerspectiveModel is nested inside photoshop:CameraProfiles and cannot be accessed with get_root_prop()
    # Also extract parent Description attributes (e.g., FocalLength, SensorFormatFactor) for ray-space normalization
    pm_result = xmp.xpath_query_with_parent(
        'PerspectiveModel',
        'http://ns.adobe.com/camera-raw-embedded-lens-profile/1.0/',
        include_parent=True
    )
    if pm_result:
        perspective_model, parent_attrs = pm_result
        if perspective_model:
            # Merge parent attributes (like FocalLength, SensorFormatFactor) into the perspective model dict
            if parent_attrs:
                if 'stCamera:FocalLength' in parent_attrs:
                    perspective_model['stCamera:FocalLength'] = parent_attrs['stCamera:FocalLength']
                if 'stCamera:SensorFormatFactor' in parent_attrs:
                    perspective_model['stCamera:SensorFormatFactor'] = parent_attrs['stCamera:SensorFormatFactor']
            
            result['crlcp:PerspectiveModel'] = perspective_model
            logger.debug(f"Extracted crlcp:PerspectiveModel with {len(perspective_model)} params")
    
    return result


def add_supported_xmp_from_dict(metadata_tags: 'MetadataTags', props: dict) -> None:
    """Add pipeline-supported XMP properties to MetadataTags.
    
    Convenience helper that combines supported_xmp_from_dict() and add_xmp().
    
    Args:
        metadata_tags: MetadataTags instance to add XMP to
        props: Dict with pipeline-supported keys (see supported_xmp_from_dict for format)
    
    Example:
        muimg.add_supported_xmp_from_dict(camera_metadata, {
            'Temperature': 5800,
            'Tint': 0,
            'Exposure2012': -0.5,
            'ToneCurvePV2012': tone_curve,
            'dc:subject': ['key_in=0.18']
        })
    """
    xmp_metadata = supported_xmp_from_dict(props)
    metadata_tags.add_xmp(xmp_metadata)
