"""Cloudpickle integration: serialize original (uninstrumented) code objects.

When cloudpickle serializes a function, it walks co_consts which may contain
ProbeO3 objects from DAGZ instrumentation. These are unpicklable Rust FFI objects.

Fix: hook cloudpickle's code object reducer to substitute the original
uninstrumented code object (stashed in co_consts by the instrumentor) before
serialization. The live function keeps its instrumented __code__ — only the
pickled copy is clean.
"""
import logging
import types

from dagz.sensor.o3 import get_original_code

logger = logging.getLogger('dagz.cloudpickle')

_orig_code_reduce = None


def _dagz_code_reduce(obj):
    original = get_original_code(obj)
    if original is not None:
        obj = original
    return _orig_code_reduce(obj)


def install_hooks(session):
    global _orig_code_reduce
    try:
        import cloudpickle.cloudpickle as cp
    except ImportError:
        return

    _orig_code_reduce = cp._code_reduce
    cp._code_reduce = _dagz_code_reduce
    cp.CloudPickler._dispatch_table[types.CodeType] = _dagz_code_reduce

    def unhook():
        cp._code_reduce = _orig_code_reduce
        cp.CloudPickler._dispatch_table[types.CodeType] = _orig_code_reduce

    return unhook
