"""Deferred guards for dagz parallel testing.

This module provides helpers that wrap production functions with checks that
fire only when a test invokes them. The guards enforce per-test pytest marks
that opt into shared, non-rerouted resources (the main worker, or the node
mutex), so a misconfigured test fails loudly instead of producing a silent
flake.

Two guard policies are exposed:

* ``assert_*_at`` — raise ``DagzError`` if the calling test lacks the mark.
  Use when running the function without the mark would yield incorrect or
  cross-worker-corrupting behavior, e.g. spawning the native dissector binary
  while the test is reading from a per-worker rabbitmq vhost.

* ``noop_unless_*_at`` — silently no-op (return ``None`` and log) if the mark
  is absent. Use for functions whose effect is global and only meaningful
  under the node mutex (resetting the master DB, killing other sessions,
  rotating shared passwords).

All helpers share the same shape:

* They install the patch eagerly via :class:`dagz.integ.lazy_patch.lazy_patch`,
  but the wrapped check runs at *call time* — hence the ``_at`` suffix.
* They are no-ops when ``dagz.pytest.is_enabled()`` is ``False``, so they can
  be called from any module that is imported by both production and tests.
* The flow shown in the resulting error or log line is the patched function's
  fully-qualified name, ``f"{module_path}.{func_name}"``.

Typical wiring lives in a project's parallel-test setup module, called once
from ``conftest.py``::

    from dagz.integ.parallel_db import (
        assert_main_worker_at,
        noop_unless_node_mutex_at,
    )

    def init() -> None:
        # Native binary that doesn't honor dagz's per-worker rerouting:
        assert_main_worker_at(
            "lkpo.splinter.worker", "SplinterWorker._run_dissector",
        )

        # Global teardown that must not run under parallel tests:
        noop_unless_node_mutex_at("lkpo.common.db", "reset_master")
"""
from __future__ import annotations

import logging
from typing import Any, Callable

from dagz.integ.lazy_patch import lazy_patch

logger = logging.getLogger(__name__)


def _is_classmethod(original: Callable) -> bool:
    """``original`` is a bound classmethod if it's a method bound to a class
    (vs. an instance). Uses only what's already on hand from lazy_patch's walk."""
    parent = getattr(original, "__self__", None)
    return isinstance(parent, type)


def _patch_assert_mark(module_path: str, func_name: str, mark_name: str) -> None:
    import dagz.pytest

    if not dagz.pytest.is_enabled():
        return

    from dagz.pytest.test_session import TestSession

    flow_name = f"{module_path}.{func_name}"

    @lazy_patch(module_path, func_name)
    def _factory(original: Callable) -> Callable:
        if _is_classmethod(original):
            # Replacement is installed as a plain function on the class, so
            # attribute access via an instance passes the instance as the first
            # arg. Drop it; ``original`` is already bound to ``cls``.
            def wrapper(_receiver: Any, *args: Any, **kwargs: Any) -> Any:
                TestSession.instance.worker.assert_mark(mark_name, flow_name)
                return original(*args, **kwargs)

            return wrapper

        def wrapper(*args: Any, **kwargs: Any) -> Any:
            TestSession.instance.worker.assert_mark(mark_name, flow_name)
            return original(*args, **kwargs)

        return wrapper


def assert_main_worker_at(module_path: str, func_name: str) -> None:
    """Install a deferred ``dagz_main_worker`` guard on a function.

    Patches ``{module_path}.{func_name}`` so that *each call* first asserts
    the active test is decorated with ``@pytest.mark.dagz_main_worker``;
    if not, the call raises ``DagzError`` and fails the test. This is the
    right escalation when running the function on a non-main worker would
    silently produce wrong results — e.g. spawning a native binary that
    connects to a hardcoded vhost / DB while the surrounding Python is using
    a per-worker reroute.

    Outside of dagz (``dagz.pytest.is_enabled()`` is ``False``) the helper
    is a no-op: no patch is installed and the original function runs
    unmodified. That makes it safe to call from a module that is imported
    by both production and tests.

    The patch is installed eagerly when this helper is called; only the
    assertion itself is deferred — hence the ``_at`` suffix. The patched
    function's fully-qualified name (``"{module_path}.{func_name}"``) is
    reported as the ``flow`` in the error message, e.g.::

        Pytest mark 'dagz_main_worker' required but not set on test,
        flow: lkpo.splinter.worker.SplinterWorker._run_dissector

    :param module_path: Dotted import path of the module that owns the
        function, e.g. ``"lkpo.splinter.worker"``.
    :param func_name: Attribute path to the target callable inside the
        module. May be a top-level name (``"foo"``) or a dotted path that
        descends into a class (``"SplinterWorker._run_dissector"``).

    :raises ImportError: If ``module_path`` cannot be imported. Raised
        eagerly when the helper is called.
    :raises AttributeError: If ``func_name`` cannot be resolved on the
        imported module. Raised eagerly when the helper is called.

    Example::

        # In test-setup code that runs from conftest.py:
        from dagz.integ.parallel_db import assert_main_worker_at

        assert_main_worker_at(
            "lkpo.splinter.worker", "SplinterWorker._run_dissector",
        )

        # Any test that calls SplinterWorker._run_dissector without
        # @pytest.mark.dagz_main_worker now fails with a clear error
        # instead of silently writing to the wrong rabbitmq vhost.

    .. seealso::

       :func:`assert_node_mutex_at`
           Same shape, gated on ``dagz_node_mutex`` instead.
       :func:`noop_unless_main_worker_at`
           Softer policy: silently no-ops the call instead of raising.
    """
    from dagz.pytest.worker import DAGZ_MAIN_WORKER

    _patch_assert_mark(module_path, func_name, DAGZ_MAIN_WORKER)


def assert_node_mutex_at(module_path: str, func_name: str) -> None:
    """Install a deferred ``dagz_node_mutex`` guard on a function.

    Patches ``{module_path}.{func_name}`` so that *each call* first asserts
    the active test is decorated with ``@pytest.mark.dagz_node_mutex``;
    if not, the call raises ``DagzError`` and fails the test. Use this for
    functions that touch shared state in a way that requires exclusive
    access across all workers on the node — typically hard resets that
    would corrupt other workers' tests if they ran concurrently.

    Outside of dagz (``dagz.pytest.is_enabled()`` is ``False``) the helper
    is a no-op: no patch is installed and the original function runs
    unmodified.

    The patch is installed eagerly when this helper is called; only the
    assertion itself is deferred — hence the ``_at`` suffix. The patched
    function's fully-qualified name (``"{module_path}.{func_name}"``) is
    reported as the ``flow`` in the error message.

    :param module_path: Dotted import path of the module that owns the
        function, e.g. ``"lkpo.common.db"``.
    :param func_name: Attribute path to the target callable inside the
        module. May be a top-level name or a dotted path that descends
        into a class.

    :raises ImportError: If ``module_path`` cannot be imported. Raised
        eagerly when the helper is called.
    :raises AttributeError: If ``func_name`` cannot be resolved on the
        imported module. Raised eagerly when the helper is called.

    Example::

        from dagz.integ.parallel_db import assert_node_mutex_at

        # Hard-reset of the production master DB — only allowed when the
        # test owns the node mutex, otherwise it would clobber concurrent
        # workers running on the same node.
        assert_node_mutex_at("lkpo.common.db", "drop_and_reseed_master")

    .. seealso::

       :func:`assert_main_worker_at`
           Same shape, gated on ``dagz_main_worker`` instead.
       :func:`noop_unless_node_mutex_at`
           Softer policy: silently no-ops the call instead of raising.
    """
    from dagz.pytest.worker import DAGZ_NODE_MUTEX

    _patch_assert_mark(module_path, func_name, DAGZ_NODE_MUTEX)


def _patch_noop_unless_mark(module_path: str, func_name: str, mark_name: str) -> None:
    import dagz.pytest

    if not dagz.pytest.is_enabled():
        return

    from dagz.pytest.test_session import TestSession

    flow_name = f"{module_path}.{func_name}"

    @lazy_patch(module_path, func_name)
    def _factory(original: Callable) -> Callable:
        # See _patch_assert_mark for the classmethod-handling rationale.
        if _is_classmethod(original):
            def wrapper(_receiver: Any, *args: Any, **kwargs: Any) -> Any:
                if TestSession.instance.worker.is_mark_active(mark_name):
                    return original(*args, **kwargs)
                logger.info("Skipping %s in parallel testing (no %s mark)", flow_name, mark_name)
                return None

            return wrapper

        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if TestSession.instance.worker.is_mark_active(mark_name):
                return original(*args, **kwargs)
            logger.info("Skipping %s in parallel testing (no %s mark)", flow_name, mark_name)
            return None

        return wrapper


def noop_unless_main_worker_at(module_path: str, func_name: str) -> None:
    """Install a deferred ``dagz_main_worker`` skip-guard on a function.

    Patches ``{module_path}.{func_name}`` so that *each call* first checks
    whether the active test carries ``@pytest.mark.dagz_main_worker``.
    If it does, the original runs unchanged. If it does not, the wrapper
    logs an INFO line and returns ``None`` without invoking the original.

    Use this for functions whose effect is meaningful only on the main
    worker but are called unconditionally from setup code that other
    workers also exercise — e.g. global password rotations or system-wide
    state initialization. The softer "silently skip" policy is preferred
    over :func:`assert_main_worker_at` when the call is coincidental
    (driven by a fixture that runs everywhere) rather than essential to
    the test's contract.

    Outside of dagz (``dagz.pytest.is_enabled()`` is ``False``) the helper
    is a no-op: no patch is installed and the original function runs
    unmodified.

    The patch is installed eagerly when this helper is called; the skip
    decision is deferred — hence the ``_at`` suffix. The patched function's
    fully-qualified name is included in the log line.

    :param module_path: Dotted import path of the module that owns the
        function, e.g. ``"lkpo.common.myredis"``.
    :param func_name: Attribute path to the target callable inside the
        module. May be a top-level name or a dotted path that descends
        into a class.

    :raises ImportError: If ``module_path`` cannot be imported. Raised
        eagerly when the helper is called.
    :raises AttributeError: If ``func_name`` cannot be resolved on the
        imported module. Raised eagerly when the helper is called.

    Example::

        from dagz.integ.parallel_db import noop_unless_main_worker_at

        # Setting a process-wide flag is only meaningful on the main
        # worker; on others, silently skip.
        noop_unless_main_worker_at("lkpo.common.runtime", "set_global_mode")

    .. seealso::

       :func:`noop_unless_node_mutex_at`
           Same shape, gated on ``dagz_node_mutex`` instead.
       :func:`assert_main_worker_at`
           Stricter policy: raise instead of silently skipping.
    """
    from dagz.pytest.worker import DAGZ_MAIN_WORKER

    _patch_noop_unless_mark(module_path, func_name, DAGZ_MAIN_WORKER)


def noop_unless_node_mutex_at(module_path: str, func_name: str) -> None:
    """Install a deferred ``dagz_node_mutex`` skip-guard on a function.

    Patches ``{module_path}.{func_name}`` so that *each call* first checks
    whether the active test carries ``@pytest.mark.dagz_node_mutex``.
    If it does, the original runs unchanged. If it does not, the wrapper
    logs an INFO line and returns ``None`` without invoking the original.

    Use this for global teardown / reset functions that are called from
    shared fixtures and would corrupt concurrent workers if executed
    without the node mutex (e.g. resetting the master DB, killing other
    sessions, rotating system-wide secrets). The softer "silently skip"
    policy keeps the fixture working under parallel testing without
    requiring every test that uses it to opt in.

    Outside of dagz (``dagz.pytest.is_enabled()`` is ``False``) the helper
    is a no-op: no patch is installed and the original function runs
    unmodified.

    The patch is installed eagerly when this helper is called; the skip
    decision is deferred — hence the ``_at`` suffix. The patched function's
    fully-qualified name is included in the log line.

    :param module_path: Dotted import path of the module that owns the
        function, e.g. ``"lkpo.common.db"``.
    :param func_name: Attribute path to the target callable inside the
        module. May be a top-level name or a dotted path that descends
        into a class.

    :raises ImportError: If ``module_path`` cannot be imported. Raised
        eagerly when the helper is called.
    :raises AttributeError: If ``func_name`` cannot be resolved on the
        imported module. Raised eagerly when the helper is called.

    Example::

        from dagz.integ.parallel_db import noop_unless_node_mutex_at

        # `reset_master` truncates shared state; only safe to call when
        # the test holds the node mutex, otherwise it would clobber
        # concurrent workers' DBs.
        noop_unless_node_mutex_at("lkpo.common.db", "reset_master")

    .. seealso::

       :func:`noop_unless_main_worker_at`
           Same shape, gated on ``dagz_main_worker`` instead.
       :func:`assert_node_mutex_at`
           Stricter policy: raise instead of silently skipping.
    """
    from dagz.pytest.worker import DAGZ_NODE_MUTEX

    _patch_noop_unless_mark(module_path, func_name, DAGZ_NODE_MUTEX)
