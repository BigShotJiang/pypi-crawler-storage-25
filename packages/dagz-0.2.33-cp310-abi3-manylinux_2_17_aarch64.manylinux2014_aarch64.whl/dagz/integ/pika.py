import logging
from dagz.integ.rabbitmq import RABBITMQ_CONFIG

logger = logging.getLogger(__name__)

_orig_init = None


def install_hooks(session):
    global _orig_init

    try:
        import pika.connection  # type: ignore[import-not-found]
    except ImportError:
        return None

    if _orig_init is not None:
        return None

    _orig_init = pika.connection.Connection.__init__
    orig = _orig_init
    config = RABBITMQ_CONFIG

    def override_init(self, *args, **kwargs):
        if args:
            parameters = args[0]
            args = args[1:]
        else:
            parameters = kwargs.pop('parameters')

        vhost = parameters.virtual_host.lstrip('/')
        if config.should_reroute(vhost):
            parameters.virtual_host = config.reroute_db(vhost)

        return orig(self, parameters, *args, **kwargs)

    pika.connection.Connection.__init__ = override_init
    return unhook


def unhook():
    global _orig_init
    if not _orig_init:
        return

    import pika.connection
    pika.connection.Connection.__init__ = _orig_init
    _orig_init = None
