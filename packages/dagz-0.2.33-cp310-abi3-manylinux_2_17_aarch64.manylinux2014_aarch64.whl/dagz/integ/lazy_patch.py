from __future__ import annotations

import functools
import importlib
import sys
from typing import Callable, Any


class lazy_patch:
    """Decorator that patches a module-level function.

    Usage::

        @FuncPatch("lkpo.common.db", "reset_master")
        def reset_master(original):
            def wrapper(session):
                if should_call():
                    return original(session)
            return wrapper

    The decorated function is a factory: it receives the original function and
    returns the replacement. The replacement is installed on the module with the
    original's signature preserved via functools.update_wrapper.

    If ``check_imports`` is True, raises RuntimeError when another module has
    already imported and bound the original (which would bypass the patch).
    """

    def __init__(self, module_path: str, func_name: str, *, check_imports: bool = False):
        self._module_path = module_path
        self._func_name = func_name
        self._check_imports = check_imports
        self._original: Callable | None = None

    def check_imports(self, mod, original):
        for mod_name, other_mod in sys.modules.items():
            if other_mod is mod or other_mod is None:
                continue
            for attr_val in vars(other_mod).values():
                if attr_val is original:
                    raise RuntimeError(
                        f"{self._module_path}.{self._func_name} is already bound in "
                        f"{mod_name} — patch will be bypassed"
                    )

    def __call__(self, factory: Callable[[Callable], Callable]) -> lazy_patch:
        mod = importlib.import_module(self._module_path)
        # original walks from Module → attribute → ... → final Callable; parent is its container.
        original: Any = mod
        parent: Any = None
        for attr_name in self._func_name.split("."):
            parent = original
            original = getattr(parent, attr_name)
        assert parent is not None, "func_name is empty"

        if self._check_imports:
            self.check_imports(mod, original)

        self._original = original
        replacement = factory(original)
        functools.update_wrapper(replacement, original)
        leaf_attr_name = self._func_name.rpartition(".")[2]
        setattr(parent, leaf_attr_name, replacement)
        return self
