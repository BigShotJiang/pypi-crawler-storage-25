import logging
from dagz.integ.db_config import DbConfig, TruncateResult

logger = logging.getLogger(__name__)

class PostgresConfig(DbConfig):
    def __init__(self, name):
        super().__init__(name)
        self._orig_connect = None

    def truncate(self, db_name, **connect_kwargs) -> TruncateResult:
        import psycopg.sql

        try:
            conn = self._orig_connect(dbname=db_name, **connect_kwargs)
        except psycopg.OperationalError:
            return TruncateResult(db_exists=False, tables=[])

        try:
            with conn.cursor() as cursor:
                cursor.execute(psycopg.sql.SQL(
                    "SELECT tablename FROM pg_tables WHERE schemaname = 'public'"
                ))
                tables = [row[0] for row in cursor.fetchall()]
                if tables:
                    table_list = [psycopg.sql.Identifier(t) for t in tables]
                    truncate_cmd = psycopg.sql.SQL(
                        "TRUNCATE TABLE {tables} RESTART IDENTITY CASCADE"
                    ).format(tables=psycopg.sql.SQL(', ').join(table_list))
                    logger.info(f"Truncating db `{db_name}`: {len(tables)} tables")
                    cursor.execute(truncate_cmd)
                    conn.commit()
                return TruncateResult(db_exists=True, tables=tables)
        finally:
            conn.close()

    def default_should_reroute(self, db_name):
        return bool(db_name) and db_name != 'postgres' and not db_name.endswith(self._session.worker_suffix)

    def install_hooks(self, session):
        try:
            import psycopg  # type: ignore[import-not-found]
            import psycopg.sql  # type: ignore[import-not-found]
        except ImportError:
            return None

        self._orig_connect = psycopg.connect
        _orig_connect = self._orig_connect

        def _override_connect(
                conninfo: str = "",
                *,
                dbname = None,
                **kwargs
        ):
            if self.should_reroute(dbname):
                dbname = self.reroute_db(dbname)

            return _orig_connect(conninfo, dbname=dbname, **kwargs)

        psycopg.connect = _override_connect
        psycopg.Connection.connect = _override_connect

        return self.unhook

    def unhook(self):
        if not self._orig_connect:
            return

        import psycopg
        psycopg.connect = self._orig_connect
        psycopg.Connection.connect = self._orig_connect
        self._orig_connect = None


PG_CONFIG = PostgresConfig(__name__)
