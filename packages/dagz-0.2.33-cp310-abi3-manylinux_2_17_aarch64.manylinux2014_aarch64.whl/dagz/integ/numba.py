"""Numba integration: provide uninstrumented bytecode to numba's JIT compiler.

Numba reads func.__code__ to compile Python functions to native code. DAGZ's
instrumented bytecode contains ProbeO3 objects and trace_callback calls that
numba's type inference cannot handle.

Two hooks:
1. get_code_object — return original uninstrumented code for JIT compilation.
2. NumbaPickler.dispatch_table — serialize original code objects when numba
   pickles Python functions for embedding in LLVM modules.
"""
import logging
import sys
import types

from dagz.sensor.o3 import get_original_code

logger = logging.getLogger('dagz.numba')


def install_hooks(session):
    try:
        import numba.core.bytecode
        from numba.core.serialize import NumbaPickler
    except ImportError:
        return

    # Hook 1: get_code_object — used by numba to read bytecode for compilation
    orig_get_code = numba.core.bytecode.get_code_object

    def override_get_code(obj):
        func_code = getattr(obj, '__code__', None)
        if func_code is not None:
            original = get_original_code(func_code)
            if original is not None:
                return original
        return orig_get_code(obj)

    for name, mod in sys.modules.items():
        if name.startswith('numba'):
            if mod.__dict__.get('get_code_object') is not None:
                mod.get_code_object = override_get_code

    # Hook 2: NumbaPickler dispatch — used when numba serializes Python objects
    # into LLVM modules via cloudpickle. Serialize original code, not instrumented.
    from dagz.integ.cloudpickle import _dagz_code_reduce
    orig_code_dispatch = NumbaPickler.dispatch_table.get(types.CodeType)
    NumbaPickler.dispatch_table[types.CodeType] = _dagz_code_reduce

    def unhook():
        for name, mod in sys.modules.items():
            if name.startswith('numba'):
                if mod.__dict__.get('get_code_object') is not None:
                    mod.get_code_object = orig_get_code
        if orig_code_dispatch is not None:
            NumbaPickler.dispatch_table[types.CodeType] = orig_code_dispatch
        else:
            NumbaPickler.dispatch_table.pop(types.CodeType, None)

    return unhook
