import logging
import warnings

from dagz.integ.db_config import DbConfig, TruncateResult

logger = logging.getLogger(__name__)


class MysqlConfig(DbConfig):
    def __init__(self, name):
        super().__init__(name)
        self._orig_init = None

    def truncate(self, db_name, **connect_kwargs) -> TruncateResult:
        import pymysql.connections
        import pymysql.cursors
        from pymysql.constants import ER

        connect_kwargs['cursorclass'] = pymysql.cursors.DictCursor
        try:
            with self.bypass():
                conn = pymysql.connections.Connection(database=db_name, **connect_kwargs)
        except pymysql.err.OperationalError as e:
            # Only "Unknown database" means the DB doesn't exist; auth/network
            # failures must propagate so the caller doesn't blindly try to
            # re-create the DB and hit the same error later with no context.
            if e.args and e.args[0] == ER.BAD_DB_ERROR:
                return TruncateResult(db_exists=False, tables=[])
            raise

        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "SELECT table_name FROM information_schema.TABLES "
                    "WHERE table_schema = %s AND table_type = 'BASE TABLE'",
                    (db_name,),
                )
                tables = [row['table_name'] for row in cursor.fetchall()]
                if tables:
                    logger.info(f"Truncating db `{db_name}`: {len(tables)} tables")
                    cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
                    for table in tables:
                        if not table.isidentifier():
                            raise ValueError(f"Invalid table name: {table!r}")
                        cursor.execute(f"TRUNCATE TABLE `{table}`")
                    cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
                    conn.commit()
                return TruncateResult(db_exists=True, tables=tables)
        finally:
            conn.close()

    def default_should_reroute(self, database):
        return bool(database) and not database.endswith(self._session.worker_suffix)

    def install_hooks(self, session):
        try:
            import pymysql.connections
        except ImportError:
            return None

        _orig_init = pymysql.connections.Connection.__init__
        self._orig_init = _orig_init
        _config = self

        def override_init(
                self,
                *,
                database=None,
                db=None,
                **kwargs):
            if db is not None and database is None:
                warnings.warn("'db' is deprecated, use 'database'", DeprecationWarning, 3)
                database = db

            if _config.should_reroute(database):
                database = _config.reroute_db(database)

            return _orig_init(self, database=database, **kwargs)

        pymysql.connections.Connection.__init__ = override_init

        return self.unhook

    def unhook(self):
        if not self._orig_init:
            return

        import pymysql.connections
        pymysql.connections.Connection.__init__ = self._orig_init
        self._orig_init = None


MYSQL_CONFIG = MysqlConfig(__name__)


def create_worker_init(db_names, **kwargs):
    def worker_init(db_num):
        import pymysql
        with MYSQL_CONFIG.bypass():
            conn = pymysql.connect(**kwargs)
        try:
            with conn.cursor() as cur:
                for db_name in db_names:
                    db_name = MYSQL_CONFIG._rewrite_db_name_func(db_name, MYSQL_CONFIG._session)
                    cur.execute(f"CREATE DATABASE IF NOT EXISTS `{db_name}`")
            conn.commit()
        finally:
            conn.close()

    return worker_init
