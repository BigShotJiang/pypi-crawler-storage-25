import logging
from .pymysql import MYSQL_CONFIG


logger = logging.getLogger(__name__)


def install_hooks(session):
    try:
        import aiomysql.connection  # type: ignore[import-not-found]
    except ImportError:
        return None

    def override_init(
            self,
            host="localhost", user=None, password="",
            db=None,
            **kwargs):

        if MYSQL_CONFIG.should_reroute(db):
            db = MYSQL_CONFIG.reroute_db(db)

        return _orig_init(self, host=host, user=user, password=password, db=db, **kwargs)

    _orig_init = aiomysql.connection.Connection.__init__
    aiomysql.connection.Connection.__init__ = override_init

    def unhook():
        aiomysql.connection.Connection.__init__ = _orig_init

    return unhook
