# DB Integration Design: Parallelization Scenarios

## Current Architecture

DAGZ intercepts database connections at the driver level (psycopg, pymysql, aiomysql) via monkeypatching. On each connection attempt:

1. **Rewrite** the DB name to include a worker suffix (e.g. `mydb` → `mydb_jw03`)
2. **Prepare** the per-worker database (create if missing, truncate+refill if exists)
3. **Skip** shared databases (e.g. `postgres`, `information_schema`)

The user calls `configure()` in conftest.py, providing callbacks: `rewrite_db_name`, `create`, `fill`, `prepare`, `should_reroute`.

---

## Core Invariant

**Every worker process is assigned exactly one DB instance per logical database.** Worker number → suffix → DB name. This is the foundational requirement — all scenarios below are variations on how the worker-to-DB mapping is established and who creates/manages the per-worker databases.

---

## Parallelization Scenarios

### Scenario 1: No Parallelism (Single Worker)

**User profile**: Tests run sequentially. User has never used xdist or any parallelization.

**What DAGZ should do**: Provide near-zero-config parallelization. DAGZ assigns worker IDs and creates per-worker DB clones automatically.

**Requirements**:
- Auto-detect that no parallel runner is in use and still assign worker IDs when DAGZ distributes work
- `single_worker_disable=True` path: when `workers_per_node == 1`, unhook entirely so there's zero overhead for users who genuinely run single-worker
- Default `create`/`fill`/`prepare` callbacks should work out-of-the-box for common schemas (Django migrations, Alembic, raw SQL)
- DB creation must be idempotent — safe to retry on partial failure

### Scenario 2: Out-of-Test DB Initialization

**User profile**: A setup script or fixture at session/module scope creates and populates the database before any tests run (e.g. `conftest.py::setup_db()`, Django `--keepdb`, a CI script).

**What DAGZ should do**: Let the user mark the DB as "manually inited" so DAGZ skips the create/fill cycle but still rewrites the name.

**Requirements**:
- `get_manual_init_db_name()` / `get_manual_init_db_url()` must be callable from session-scoped fixtures or setup scripts
- After manual init, the per-test `prepare` callback should still truncate/refill data (unless the user opts out)
- Must work when init happens before `install_hooks` — the rewrite function needs to be available early
- The init function may connect to a "template" DB and clone it (Postgres `CREATE DATABASE ... TEMPLATE`). DAGZ must not intercept this template connection

### Scenario 3: Django Test Runner DB-per-Worker

**User profile**: Django project with `TEST_RUNNER` or `DATABASES` configured to create a test DB per parallel worker (e.g. `pytest-django` with `--reuse-db`, or custom runner using `_test_{worker}` suffix).

**What DAGZ should do**: Respect the user's existing DB naming scheme. Map DAGZ worker IDs to the user's worker numbering.

**Requirements**:
- Custom `rewrite_db_name` must be able to map DAGZ `worker_suffix` to Django's worker naming convention (e.g. `_jw03` → `_gw3` or `_1`)
- `should_reroute` must correctly identify which connections need rewriting (and skip Django's admin/default connections)
- When Django's runner has already created the DB, DAGZ should detect "tables exist" and skip `create`, only truncate+refill
- Must handle Django's `DATABASES` dict with multiple aliases (default, read-replica, etc.) — each alias may point to different physical DBs
- Settings rewrite (like the Cassandra `_rewrite_keyspace_settings` pattern) may be needed for `django.conf.settings.DATABASES`

### Scenario 4: Existing Parallelism (xdist / custom sharding)

**User profile**: Already using pytest-xdist or similar. Has working per-worker DB isolation. Just needs DAGZ to hook its coverage tracking into the existing worker IDs.

**What DAGZ should do**: Map DAGZ internal worker numbering to the user's existing worker IDs. Minimal intervention on DB setup.

**Requirements**:
- `DAGZ_DB_WORKER_NUM` env var must be respected — allows external orchestrators to assign worker numbers
- When the user's system already creates `mydb_gw0`, `mydb_gw1`, etc., DAGZ must be configurable to use those names verbatim (custom `rewrite_db_name` that maps to existing suffixes)
- `single_worker_disable` should not trigger when DAGZ is a single node in a multi-node xdist setup
- DB hooks should be no-ops or minimal when the user has full control — only rewrite, don't prepare/create/fill

### Scenario 5: Multiple Databases per Test

**User profile**: Application connects to multiple databases (e.g. main DB + analytics DB + cache DB). Different DBs may need different isolation strategies.

**Requirements**:
- `add_initer(db_name, ...)` allows per-database create/fill/prepare callbacks
- Fallback initer (keyed on `''`) handles unknown databases
- `should_reroute` must be per-database — some DBs are shared (read-only reference data) while others need isolation
- All databases for a worker must use the same suffix to maintain consistency within a test
- Connection interception must handle both `dbname` kwarg and connection-string/URL formats

### Scenario 6: Async Database Drivers

**User profile**: Uses aiomysql, asyncpg, aiopg, or SQLAlchemy async engine.

**Requirements**:
- Hooks must work for both sync and async connection constructors
- aiomysql currently shares `MYSQL_CONFIG` with pymysql — the `should_reroute` and `rewrite_db_name` logic must be consistent across sync/async variants of the same DB
- Async drivers that use connection pools need pool-level interception, not just per-connection (otherwise the pool may cache the pre-rewrite name)
- `prepare` callbacks may need to run synchronously even from async context (DB creation is typically sync)

### Scenario 7: Connection Pooling / ORMs

**User profile**: Uses SQLAlchemy, Django ORM, or a connection pool (pgbouncer, etc.) that caches connection parameters.

**Requirements**:
- Pool-level hooks: if the pool is initialized at import time with the original DB name, the rewrite must happen before pool creation or the pool config must be patched
- Import-time connections (`worker_suffix` is None): must warn clearly, not silently connect to the wrong DB
- ORM engine disposal / re-creation: when worker suffix changes, cached engines must be invalidated
- URL-based configuration: `get_manual_init_db_url()` must handle full connection URLs (scheme://user:pass@host/dbname)

### Scenario 8: Schema Migrations at Worker DB Creation

**User profile**: Each worker DB needs schema migrations (Alembic, Django migrations, Flyway) applied before tests can run.

**Requirements**:
- `create` callback must support running migrations against the new worker DB
- Migrations should run once per worker DB per session, not per test — guarded by `_current_inited` set
- Template DB optimization: create one fully-migrated template DB, then `CREATE DATABASE worker_db TEMPLATE template_db` (Postgres-specific but significant speedup)
- Migration failures must be surfaced clearly, not swallowed

### Scenario 9: Shared Read-Only Databases

**User profile**: Some databases are read-only reference data shared across all workers (e.g. geo lookup tables, config tables).

**Requirements**:
- `should_reroute(db_name)` must return False for these — no rewrite, no prepare
- Shared DBs must not be truncated or modified by any worker
- The default `should_reroute` implementations need to be more sophisticated than just checking for `postgres` or `bool(database)` — users should provide their own or we need pattern-based matching

### Scenario 10: Transactional Test Isolation (No Truncation)

**User profile**: Tests run inside a transaction that is rolled back after each test (Django's `TransactionTestCase` vs `TestCase`, pytest-django's `--reuse-db`).

**Requirements**:
- When transaction-based isolation is in use, the `prepare` callback should be a no-op (no truncation needed)
- DAGZ must detect or be told that rollback-based isolation is active
- Mixed mode: some tests use transactions (fast), some need real commits (e.g. testing transaction semantics) — the prepare strategy must be configurable per-test or per-class

---

## Cross-Cutting Concerns

### Thread Safety
- `_current_inited` set is accessed from multiple threads — currently protected by `_lock` (RLock)
- pymysql uses manual `acquire(timeout=3)` with error fallback; psycopg uses `with self._lock` — should be consistent
- Async drivers add another dimension: must be safe under both threading and asyncio concurrency

### Error Handling
- DB creation failures must not leave half-created databases that block future runs
- Connection interception must not mask the original driver's error messages
- Lock timeout (pymysql's 3-second timeout) should be configurable and logged

### Lifecycle
- `test_prerun` callback clears `_current_inited` before each test — ensures prepare runs once per test
- `unhook()` restores original driver functions — must be called on shutdown to avoid polluting the process
- Worker number assignment must happen before any DB connection is attempted

### Import-Time Safety
- `PG_CONFIG` and `MYSQL_CONFIG` are module-level singletons created at import
- `install_hooks` runs later during session setup
- Any connection between import and hook installation gets the original driver — this window must be documented or eliminated
