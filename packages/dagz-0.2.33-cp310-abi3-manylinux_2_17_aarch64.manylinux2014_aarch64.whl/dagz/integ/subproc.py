"""subprocess.Popen / os.system hooks that propagate OTel context and dagz
fds to children. Tests that *measure* subprocess behavior (e.g. importtime
timing) can wrap with bypass_subprocess_hooks() to skip the injection."""
import contextlib
import contextvars
import logging
import os
import shlex
import subprocess

_bypass: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "dagz_bypass_subprocess_hooks", default=False
)


@contextlib.contextmanager
def bypass_subprocess_hooks():
    token = _bypass.set(True)
    try:
        yield
    finally:
        _bypass.reset(token)


logger = logging.getLogger(__name__)
_orig_os_system = None
_orig_subprocess_popen_init = None


def _get_subproc_init():
    from dagz.sensor.base_session import BaseSession
    session = BaseSession.instance
    if session is None:
        return {}, []
    return session.get_subproc_init()


def _hooked_os_system(command):
    if _bypass.get():
        return _orig_os_system(command)
    subproc_env, _ = _get_subproc_init()
    if subproc_env:
        set_vars = "".join(f"{k}={shlex.quote(v)} " for k, v in subproc_env.items())
        command = f"export {set_vars} ; {command}"
    return _orig_os_system(command)


def _hooked_popen_init(self, args, **kwargs):
    if _bypass.get():
        return _orig_subprocess_popen_init(self, args, **kwargs)
    subproc_env, subproc_fds = _get_subproc_init()
    shell = kwargs.get('shell')
    if shell or isinstance(args, str):
        pretty_args = args
    else:
        pretty_args = ' '.join(shlex.quote(str(arg)) for arg in args)
    pretty_cmd = ''.join(f'{k}={shlex.quote(v)} ' for k, v in subproc_env.items()) + pretty_args
    cwd = kwargs.get('cwd', os.getcwd())
    pythonpath = os.environ.get('PYTHONPATH', '')
    logger.debug(f"Subprocess hook: env -C {cwd} PYTHONPATH={pythonpath} {pretty_cmd} stdout={kwargs.get('stdout')} stderr={kwargs.get('stderr')} capture={kwargs.get('capture')}")
    if subproc_env:
        env = kwargs.get("env")
        if env is None:
            env = os.environ.copy()
        else:
            env = env.copy()
        env.update(subproc_env)
        kwargs["env"] = env

    if subproc_fds and kwargs.get('close_fds', True):
        # close_fds=False already inherits everything; pass_fds would force it
        # back to True and break callers that need their own fd setup.
        existing = kwargs.get('pass_fds', ())
        kwargs['pass_fds'] = (*existing, *subproc_fds)

    return _orig_subprocess_popen_init(self, args, **kwargs)


def hook_subprocess():
    global _orig_os_system, _orig_subprocess_popen_init

    _orig_os_system = os.system
    os.system = _hooked_os_system

    _orig_subprocess_popen_init = subprocess.Popen.__init__
    subprocess.Popen.__init__ = _hooked_popen_init

    def unhook():
        global _orig_os_system, _orig_subprocess_popen_init
        if _orig_os_system is not None:
            os.system = _orig_os_system
            _orig_os_system = None
        if _orig_subprocess_popen_init is not None:
            subprocess.Popen.__init__ = _orig_subprocess_popen_init
            _orig_subprocess_popen_init = None

    return unhook
