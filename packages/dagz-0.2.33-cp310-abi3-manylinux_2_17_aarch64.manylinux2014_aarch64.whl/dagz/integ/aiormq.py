import logging
from .rabbitmq import RABBITMQ_CONFIG

logger = logging.getLogger(__name__)

_orig_init = None


def install_hooks(session):
    global _orig_init

    try:
        import aiormq.connection  # type: ignore[import-not-found]
    except ImportError:
        return None

    _orig_init = aiormq.connection.Connection.__init__
    orig = _orig_init
    config = RABBITMQ_CONFIG

    def override_init(self, url, **kwargs):
        vhost = url.path.lstrip('/')
        if config.should_reroute(vhost):
            url = url.with_path('/' + config.reroute_db(vhost))

        return orig(self, url, **kwargs)

    aiormq.connection.Connection.__init__ = override_init
    return unhook


def unhook():
    global _orig_init
    if not _orig_init:
        return

    import aiormq.connection
    aiormq.connection.Connection.__init__ = _orig_init
    _orig_init = None
