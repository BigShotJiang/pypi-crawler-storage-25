import errno
import os
import logging
import random
import socket

logger = logging.getLogger(__name__)

def make_env_name(name: str) -> str:
    return "PARALLEL_TEST_PORT_" + name


class ParallelPortManager:
    """
    Provide port numbers to tests in parallel run mode.
    Stable port requests return the same port for a given named client,
    for the during of the test and for sub-processes as well.
    """

    def __init__(self) -> None:
        from dagz.pytest.test_session import TestSession
        if TestSession.instance.port_manager:
            raise RuntimeError('Duplicate registration of dagz port manager')
        TestSession.instance.port_manager = self

        self.allocated: dict[str, int] = {}

    def get_port(self, name: str, stable: bool = False) -> int:
        if port_str := os.environ.get(make_env_name(name)):
            logger.info(f"Forcing {name} worker port: {port_str}")
            return int(port_str)

        for _ in range(10):
            port = random.randint(2048, 65530)
            with socket.socket() as sock:
                try:
                    sock.bind(("127.0.0.1", port))
                    if stable:
                        logger.debug(f"Allocating stable port for service {name}: {port}")
                        os.environ[make_env_name(name)] = str(port)
                        self.allocated[name] = port
                    else:
                        logger.debug(f"Allocating onetime port for service {name}: {port}")
                    return port
                except OSError as e:
                    if e.errno == errno.EADDRINUSE:
                        continue
                    raise

        raise RuntimeError("No free port found after 10 random attempts")

    def reset(self) -> None:
        for name, port in list(self.allocated.items()):
            os.environ.pop(make_env_name(name), None)
            with socket.socket() as sock:
                try:
                    sock.bind(("127.0.0.1", port))
                    del self.allocated[name]
                except OSError:
                    logger.warning(f"Port not freed: {name}: {port}")
