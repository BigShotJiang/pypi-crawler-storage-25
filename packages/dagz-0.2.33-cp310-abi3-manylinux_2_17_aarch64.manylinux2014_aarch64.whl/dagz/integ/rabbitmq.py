import logging
import subprocess
import shlex

from dagz.integ.db_config import DbConfig, TruncateResult
from dagz.sensor.base_session import BaseSession

logger = logging.getLogger(__name__)

def ensure_run(cmd):
    pretty_cmd = ' '.join(shlex.quote(arg) for arg in cmd)
    i = 0
    while True:
        i += 1
        try:
            logger.info('exec %s', pretty_cmd)
            subprocess.run(cmd, check=True)
            return
        except subprocess.CalledProcessError as e:
            logger.error(f"failed: {pretty_cmd}: {e}")
            if i == 2:
                raise e


class RabbitmqConfig(DbConfig):
    def __init__(self, module_name):
        super().__init__(module_name)
        self._created = set()

    def truncate(self, db_name, **connect_kwargs) -> TruncateResult:
        # RabbitMQ vhosts don't have tables to truncate
        return TruncateResult(db_exists=True, tables=[])

    def unhook(self):
        pass

    def default_rewrite_db_name(self, db_name: str, session: BaseSession):
        if not self._should_reroute_func(db_name):
            return db_name

        if session.worker_suffix:
            if not db_name.endswith(session.worker_id):
                if db_name == '/' or db_name == '' or db_name == '//':
                    db_name = session.worker_id
                else:
                    db_name += session.worker_suffix

        else:
            logger.warning(f'Accessing {self.module_name} DB during import: {db_name}')

        if not db_name:
            # Force "/" the user didn't pass it
            db_name = '/'
        return db_name

    @staticmethod
    def default_should_reroute(vhost):
        return True

    def create_vhost_with_user(self, vhost, user):
        try:
            ensure_run(['rabbitmqctl', 'add_vhost', vhost])
            ensure_run(['rabbitmqctl', 'set_permissions', '-p', vhost, user, '.*', '.*', '.*'])
        except subprocess.CalledProcessError as e:
            logger.warning('Cannot setup rabbitmq vhost %s', vhost)



RABBITMQ_CONFIG = RabbitmqConfig(__name__)
