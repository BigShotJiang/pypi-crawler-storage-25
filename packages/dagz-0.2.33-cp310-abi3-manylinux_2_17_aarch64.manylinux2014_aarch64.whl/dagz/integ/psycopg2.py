import logging

from dagz.integ.psycopg import PG_CONFIG

logger = logging.getLogger(__name__)


def install_hooks(session):
    try:
        import psycopg2  # type: ignore[import-not-found]
    except ImportError:
        return None

    _orig_connect = psycopg2.connect

    def _override_connect(dsn=None, *, dbname=None, database=None, **kwargs):
        if database is not None and dbname is None:
            dbname = database
        if PG_CONFIG.should_reroute(dbname):
            dbname = PG_CONFIG.reroute_db(dbname)
        return _orig_connect(dsn, dbname=dbname, **kwargs)

    psycopg2.connect = _override_connect

    def unhook():
        psycopg2.connect = _orig_connect

    return unhook

def create_worker_init(db_names, **kwargs):
    def worker_init(db_num):
        _ = db_num
        from dagz.integ.psycopg2 import PG_CONFIG
        import psycopg2.errors
        conn = psycopg2.connect(dbname="postgres", **kwargs)
        conn.autocommit = True
        try:
            with conn.cursor() as cur:
                for db_name in db_names:
                    db_name = PG_CONFIG._rewrite_db_name_func(db_name, PG_CONFIG._session)
                    try:
                        cur.execute(f'CREATE DATABASE "{db_name}"')
                    except (psycopg2.errors.DuplicateDatabase, psycopg2.errors.UniqueViolation):
                        pass
        finally:
            conn.close()

    return worker_init
