from __future__ import annotations

import ast
import sys
from importlib.machinery import ModuleSpec
from typing import Optional

import _pytest.assertion

from dagz.sensor.instrument import FileInstrumentor
from dagz.sensor.module_loader import MetaFinder, ModuleLoader
from dagz.sensor.o3 import SpanResult

import _pytest.assertion.rewrite
_orig_rewrite_asserts = _pytest.assertion.rewrite.rewrite_asserts
_pytest_finder = _pytest.assertion.rewrite.AssertionRewritingHook


class PytestModLoader(ModuleLoader):
    def __init__(self, finder: PytestMetaFinder, spec):
        super().__init__(finder, spec)
        self.finder = finder
        self.resumed = False
        self.ast_instrumented = False
        self.module = None
        self.instrumentor = None

    def exec_module(self, module):
        try:
            self.module = module
            self.span, module_hash = self.finder.session.o3.start_module_load(module.__spec__)
            try:
                self.instrumentor = FileInstrumentor(module.__spec__.origin, self.finder.session, module_hash, with_pytest=True)

                cached_code = self.instrumentor.load_pyc()
                if cached_code is not None:
                    # Cache hit — skip pytest's loader entirely
                    self.do_exec(cached_code)
                else:
                    # Cache miss — let pytest load+compile the test module.
                    # We intervene by hooking exec() and rewrite_asserts() in pytest's rewriting loader.
                    self.wrapped.exec_module(module)
                    assert self.resumed and self.ast_instrumented, f"Pytest module instrumentation missed: {module.__spec__.origin}"
            except BaseException:
                # If do_exec/exec_code ran, it already set the right result.
                # Otherwise (SyntaxError during pytest's compile, instrumentor
                # init failure, etc.) the span would land at finish_load as
                # NOT_SET — surface it as an error instead.
                if not self.resumed:
                    self.span.result = SpanResult.ERROR
                raise
        finally:
            self.finish_load(module)

    def do_exec(self, code):
        __tracebackhide__ = True  # Hide this frame from pytest tracebacks
        self.resumed = True
        code = self.instrumentor.instrument_code(code)
        return self.exec_code(self.span, self.module, code)


class PytestMetaFinder(MetaFinder):
    def wrap_loader(self, spec: ModuleSpec):
        if isinstance(spec.loader, _pytest_finder):
            spec.loader = PytestModLoader(self, spec)
        else:
            super().wrap_loader(spec)

    def install(self):
        def _wrap_rewrite_asserts(tree: ast.Module,
                                  source: bytes,
                                  module_path: Optional[str] = None,
                                  config = None):
            loader = self.loaders_by_path.get(module_path)
            if loader:
                # pytest could rewrite external test files, make sure we don't instrument them
                loader.ast_instrumented = True
                loader.instrumentor.instrument_ast(tree)
            _orig_rewrite_asserts(tree, source, module_path, config)

        if sys.version_info >= (3, 11):
            def _wrap_pytest_rewrite_exec(code, globals=None, locals=None, /, *, closure=None):
                # Must instrument the code after compiling and before executing it.
                loader = self.loaders_by_path.get(code.co_filename)
                if loader:
                    loader.instrumentor.save_pyc(code)
                    return loader.do_exec(code)

                return exec(code, globals, locals, closure=closure)
        else:
            def _wrap_pytest_rewrite_exec(code, globals=None, locals=None):
                # Must instrument the code after compiling and before executing it.
                loader = self.loaders_by_path.get(code.co_filename)
                if loader:
                    loader.instrumentor.save_pyc(code)
                    return loader.do_exec(code)

                # Not a dagz-instrumented module, use standard exec
                return exec(code, globals, locals)

        _pytest.assertion.rewrite.rewrite_asserts = _wrap_rewrite_asserts
        _pytest.assertion.rewrite.exec = _wrap_pytest_rewrite_exec

        # For dagz-instrumented modules, suppress pytest's pyc read/write.
        # dagz writes its own pyc (with a dagz-specific cache tag) in save_pyc().
        # If pytest also writes a pyc (with the standard cache tag), the file
        # contains dagz-instrumented bytecode that crashes when loaded without dagz.
        # Similarly, reading a stale pytest pyc from a prior dagz run must be skipped.
        _orig_write_pyc = _pytest.assertion.rewrite._write_pyc
        _orig_read_pyc = _pytest.assertion.rewrite._read_pyc

        def _guarded_write_pyc(state, co, source_stat, pyc):
            if co.co_filename not in self.loaders_by_path:
                _orig_write_pyc(state, co, source_stat, pyc)

        def _guarded_read_pyc(source, pyc, trace):
            if str(source) in self.loaders_by_path:
                return None
            return _orig_read_pyc(source, pyc, trace)

        _pytest.assertion.rewrite._write_pyc = _guarded_write_pyc
        _pytest.assertion.rewrite._read_pyc = _guarded_read_pyc

        super_uninstall = super().install()

        def uninstall():
            super_uninstall()
            _pytest.assertion.rewrite.exec = exec
            _pytest.assertion.rewrite.rewrite_asserts = _orig_rewrite_asserts
            _pytest.assertion.rewrite._write_pyc = _orig_write_pyc
            _pytest.assertion.rewrite._read_pyc = _orig_read_pyc

        return uninstall
