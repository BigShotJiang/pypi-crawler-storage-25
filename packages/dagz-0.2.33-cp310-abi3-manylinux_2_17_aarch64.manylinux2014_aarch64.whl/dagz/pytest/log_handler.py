import io
import logging
import logging.config
import os

import sys
import traceback

from dagz.sensor.base_session import BaseSession

logger = logging.getLogger('dagz.collector')

_orig_add_handler = logging.Logger.addHandler
_orig_remove_handler = logging.Logger.removeHandler
_orig_last_resort = logging.lastResort

STDOUT_FILENO = 1
STDERR_FILENO = 2
_captured_devinos = set()


def _is_stdout_stderr_stream(stream):
    """Check if a stream points to the same device/inode as stdout/stderr.

    Catches sys.stdout, sys.stderr, dup'd fds, reopened /dev/fd/1, etc.
    Returns False for StringIO, file-backed streams, etc.
    Compares against both the init-time snapshot and current fd 1/2
    (which may differ after fork+pty redirect).
    """
    try:
        fd = stream.fileno()
    except (AttributeError, io.UnsupportedOperation, OSError):
        return False
    try:
        st = os.fstat(fd)
        devino = (st.st_dev, st.st_ino)
    except OSError:
        return False
    if devino in _captured_devinos:
        return True
    for live_fd in (STDOUT_FILENO, STDERR_FILENO):
        try:
            live_st = os.fstat(live_fd)
            if devino == (live_st.st_dev, live_st.st_ino):
                return True
        except OSError:
            pass
    return False


class TestLogHandler(logging.Handler):
    def __init__(self, session: 'BaseSession'):
        super().__init__()
        self.session = session

        self.orig_err_fd = os.dup(sys.stderr.fileno())
        self.orig_err = os.fdopen(self.orig_err_fd, 'w')

        # Snapshot stdout/stderr device+inode before any redirects.
        # Check both sys.stdout/stderr objects and raw fd 1/2.
        for f in (sys.stdout, sys.stderr):
            try:
                st = os.fstat(f.fileno())
                _captured_devinos.add((st.st_dev, st.st_ino))
            except (OSError, io.UnsupportedOperation):
                pass
        for fd in (STDOUT_FILENO, STDERR_FILENO):
            try:
                st = os.fstat(fd)
                _captured_devinos.add((st.st_dev, st.st_ino))
            except OSError:
                pass

        # Make sure we're the only handler that writes to stdout, never get removed,
        # And keep it this way.
        root_logger = logging.getLogger()
        found_self = False
        for handler in list(root_logger.handlers):
            if handler is self:
                found_self = True
            elif isinstance(handler, (logging.StreamHandler, TestLogHandler)):
                root_logger.removeHandler(handler)
        if not found_self:
            root_logger.addHandler(self)

        logging.Logger.addHandler = TestLogHandler._guarded_add_handler
        logging.Logger.removeHandler = TestLogHandler._protective_remove_handler

        # remove bootstrap loggers
        dagz_logger = logging.getLogger('dagz')
        for handler in list(dagz_logger.handlers):
            dagz_logger.removeHandler(handler)
        dagz_logger.propagate = True

        # Route warnings.warn() calls through logging (logger 'py.warnings').
        # Since we're on the root logger, this captures all Python warnings in dagz logs.
        logging.captureWarnings(True)

        # Prevent logging errors from being raised.
        # Since we're opening up the default root log level, previously skipped logging code paths
        # might be called now. So if they have errors, we don't want them to crash the test.
        logging.raiseExceptions = False

        # Install ourselves as last resort handler for loggers
        logging.lastResort = self

        _orig_file_config = logging.config.fileConfig
        def _override_file_config(*args, **kwargs):
            _orig_file_config(*args, **kwargs)
            for name, existing_logger in logging.getLogger().manager.loggerDict.items():
                if name.startswith('dagz') and isinstance(existing_logger, logging.Logger):
                    existing_logger.disabled = False
                    existing_logger.setLevel(logging.DEBUG)
            logger.info('Fixed dagz logging after logging.fileConfig')
        logging.config.fileConfig = _override_file_config

    def addFilter(self, filter):
        logger.info(f'Not adding logging filter: {type(filter).__name__}')

    def setLevel(self, level):
        logger.info(f'Ignoring setLevel: {level}')

    @staticmethod
    def _guarded_add_handler(self, handler):
        if isinstance(handler, TestLogHandler):
            _orig_add_handler(self, handler)
            return
        if isinstance(handler, logging.StreamHandler):
            stream = getattr(handler, 'stream', None)
            if stream is not None and _is_stdout_stderr_stream(stream):
                logger.info(f'Blocking noisy logger.addHandler: StreamHandler(fd={stream.fileno()}) on logger {self.name!r}')
                return
        _orig_add_handler(self, handler)

    @staticmethod
    def _protective_remove_handler(self, handler):
        if isinstance(handler, TestLogHandler):
            # Don't allow removing self
            return
        _orig_remove_handler(self, handler)

    def emit(self, record):
        if record.exc_info:
            # Do it like they do it in logging.StreamHandler
            sio = io.StringIO()
            traceback.print_exception(*record.exc_info, None, sio)
            exc_dump = sio.getvalue()
            sio.close()
        else:
            exc_dump = None

        self.session.o3.log(record, exc_dump)

    def unregister(self):
        try:
            root_logger = logging.root
            logging.lastResort = _orig_last_resort
            logging.Logger.addHandler = _orig_add_handler
            logging.Logger.removeHandler = _orig_remove_handler

            _orig_remove_handler(root_logger, self)
            basic_handler = logging.StreamHandler(sys.stdout)
            basic_handler.setLevel(logging.DEBUG)
            _orig_add_handler(root_logger, basic_handler)

        except Exception as exc:
            print(f'** Sender close error: {exc}')

    def handle_line(self, line: bytes):
        if line.startswith(b'INTERNAL'):
            return
        line = line.rstrip()
        if not line:
            return

        record = logging.LogRecord('', logging.DEBUG + 1, '', 0, line.decode('utf8'), None, None)
        self.session.o3.log(record, None)

    def log_internal_error(self, err):
        self.orig_err.write(f'INTERNAL ERROR: {err}\n')
        self.orig_err.flush()
