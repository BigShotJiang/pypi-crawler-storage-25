_enabled = False

def is_enabled():
    return _enabled
