import inspect
import logging

import _pytest
import _pytest.runner
import _pytest.fixtures
import _pytest.tmpdir
import _pytest.monkeypatch
import _pytest.legacypath
import _pytest.logging
import _pytest.python
import _pytest.capture

logger = logging.getLogger('dagz.fixtures')


def is_compatible_func(a, b):
    return inspect.unwrap(a) is inspect.unwrap(b)


PYTEST_LIGHT_BUILTINS = [
    _pytest.tmpdir.tmp_path,
    _pytest.tmpdir.tmp_path_factory,
    _pytest.monkeypatch.monkeypatch,
    _pytest.legacypath.LegacyTmpdirPlugin.tmpdir,
    _pytest.legacypath.LegacyTmpdirPlugin.tmpdir_factory,
    _pytest.logging.caplog,
    _pytest.capture.capsys,
    _pytest.capture.capsysbinary,
    _pytest.capture.capfd,
    _pytest.capture.capfdbinary,
    _pytest.fixtures.pytestconfig,
    _pytest.doctest.doctest_namespace
]

if get_direct_param_fixture_func := getattr(_pytest.python, 'get_direct_param_fixture_func', None):
    # pytest 8
    PYTEST_LIGHT_BUILTINS.append(get_direct_param_fixture_func)
elif get_direct_param_fixture_func := getattr(_pytest.fixtures, 'get_direct_param_fixture_func', None):
    # pytest 7
    PYTEST_LIGHT_BUILTINS.append(get_direct_param_fixture_func)

if _pytest.version_tuple[0] < 9:
    # Renamed: https://github.com/pytest-dev/pytest/commit/6d17c8508a5b0218816868682a432ad5acfea192
    request_fixture_def = _pytest.fixtures.PseudoFixtureDef
else:
    request_fixture_def = _pytest.fixtures.RequestFixtureDef



_light_builtin_cache = {}

def is_external_light_fixture(fixture: _pytest.fixtures.FixtureDef):
    func_id = id(fixture.func)
    cached = _light_builtin_cache.get(func_id)
    if cached is not None:
        return cached

    is_external = False
    if isinstance(fixture, request_fixture_def):
        is_external = True
    elif any(is_compatible_func(fixture.func, func) for func in PYTEST_LIGHT_BUILTINS):
        is_external = True
    else:
        fixture_mod = fixture.func.__module__.partition('.')[0]
        if fixture_mod in ('pytest_flask', 'pytest_asyncio'):
            # Pervasive fixtures - dont account for these
            is_external = True

        elif fixture_mod in ('_pytest', 'pytest'):
            if fixture.argname.startswith('_unittest_') or fixture.argname.startswith('_xunit_setup_'):
                # wrapper fixtures for setupClass / setup_class etc.
                pass
            else:
                logger.warning(f'Unexpected pytest fixture func, added to dependencies: {fixture.func.__module__}.{fixture.func} argname={fixture.argname}')
                is_external = False

    _light_builtin_cache[func_id] = is_external

    return is_external


class FixtureMan:
    def __init__(self, config):
        self.config = config
        self.fixtures: dict[_pytest.FixtureDef, list[str]] = {}

    def get_fixture_id(self, fixture, param_index: int):
        if is_external_light_fixture(fixture):
            return None

        if not fixture.params:
            return f'{fixture.func.__module__}::{fixture.argname}'

        ids = self.fixtures.get(fixture)
        if ids:
            return ids[param_index]

        id_maker = _pytest.python.IdMaker(
            argnames=[fixture.argname],
            parametersets=[_pytest.python.ParameterSet.extract_from(argval, force_tuple=True)
                           for argval in fixture.params],
            idfn=fixture.ids if callable(fixture.ids) else None,
            ids=None if callable(fixture.ids) else fixture.ids,
            config=self.config,
            nodeid=None,
            func_name=None,
        )
        fixture_ids = [f'{fixture.func.__module__}::{fixture.argname}[{uniq_id}]'
                       for uniq_id in id_maker.make_unique_parameterset_ids()]

        self.fixtures[fixture] = fixture_ids
        return fixture_ids[param_index]

    def extract_fixture_ids(self, item):
        cached = getattr(item, '_dagz_fixture_ids', None)
        if cached is not None:
            return cached

        fixture_ids = {}
        callspec = getattr(item, 'callspec', None)
        for argname, fixturedefs in item._fixtureinfo.name2fixturedefs.items():
            # For args with multiple defs, the last one takes precedence
            fixture = fixturedefs[-1]
            param_index = callspec.indices.get(argname, 0) if callspec else 0
            fixture_id = self.get_fixture_id(fixture, param_index)
            if fixture_id is not None:
                fixture_ids[fixture_id] = fixture

        item._dagz_fixture_ids = fixture_ids
        return fixture_ids
