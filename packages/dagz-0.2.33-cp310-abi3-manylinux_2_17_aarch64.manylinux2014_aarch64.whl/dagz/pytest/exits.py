import sys
import os
import traceback
import logging

import pytest

logger = logging.getLogger(__name__)

_orig_sys_exit = sys.exit
_orig_os_exit = os._exit
_orig_pytest_exit = pytest.exit


def install_exit_hooks(session):
    hooked_pid = os.getpid()

    def override_sys_exit(status):
        logger.error(f"Process exiting using sys.exit, status={status}\n{''.join(traceback.format_stack())}")
        session.o3.flush()
        _orig_sys_exit(status)

    def override_os_exit(status):
        logger.error(f"Process exiting using os._exit, status={status}\n{''.join(traceback.format_stack())}")
        session.o3.flush()

        curr_pid = os.getpid()
        if curr_pid == hooked_pid:
            # Don't actually kill the process — raise SystemExit so the test fails
            # gracefully instead of killing the dagz worker (which would cause a
            # restart loop). Code under test that calls os._exit() expects a hard
            # process death; SystemExit is the closest equivalent that pytest can catch.
            raise SystemExit(status)
        else:
            # OS exit in subprocs is actually sane and protective.
            _orig_os_exit(status)

    def override_pytest_exit(
            reason: str = "",
            returncode: int | None = None,
    ):
        logger.warning(f"Process exiting using pytest.exit, reason={reason}, rc={returncode}\n{''.join(traceback.format_stack())}")
        session.o3.flush()
        _orig_pytest_exit(reason, returncode)

    sys.exit = override_sys_exit
    os._exit = override_os_exit
    pytest.exit = override_pytest_exit

    def unhook():
        sys.exit = _orig_sys_exit
        os._exit = _orig_os_exit
        pytest.exit = _orig_pytest_exit

    return unhook
