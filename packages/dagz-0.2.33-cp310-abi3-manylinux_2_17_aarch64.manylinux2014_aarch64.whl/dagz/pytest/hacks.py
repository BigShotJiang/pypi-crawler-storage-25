import ctypes
import logging
import os
import sys

from dagz.integ.cassandra import patch_cassandra_forking

logger = logging.getLogger('dagz.runtime_hacks')

def set_cdll_thread_num(dll, func_name, num_threads):
    set_num_threads = getattr(dll, func_name, None)
    if set_num_threads:
        set_num_threads.restype = None
        set_num_threads(ctypes.c_int(num_threads))
        logger.debug(f'Setting threads: {func_name}({num_threads}) [{dll._name}]')


def set_thread_pools_size(num_threads: int):
    seen = set()
    if sys.platform != 'linux':
        return

    with open('/proc/self/maps') as maps:
        lines = maps.readlines()
        for line in lines:
            parts = line.split()
            if len(parts) == 6:
                lib_path = parts[5]
                if lib_path in seen:
                    continue
                seen.add(lib_path)
                filename = os.path.basename(lib_path)
                if filename.startswith('libopenblas'):
                    dll = ctypes.CDLL(lib_path)
                    set_cdll_thread_num(dll, 'openblas_set_num_threads', num_threads)
                    set_cdll_thread_num(dll, 'openblas_get_num_threads64_', num_threads)

                elif filename.startswith('libgomp'):
                    dll = ctypes.CDLL(lib_path)
                    set_cdll_thread_num(dll, 'omp_set_num_threads', num_threads)
                elif filename.startswith('libmkl'):
                    dll = ctypes.CDLL(lib_path)
                    mkl_set_num_threads = getattr(dll, 'mkl_set_num_threads', None)
                    if mkl_set_num_threads:
                        mkl_set_num_threads.restype = None
                        mkl_set_num_threads(ctypes.c_int(num_threads))



def disable_thread_pools():
    # Disable thread pools to avoid deadlocked mutexes with forked workers
    # See https://stackoverflow.com/questions/30791550/limit-number-of-threads-in-numpy
    os.environ['OMP_NUM_THREADS'] = '1'
    os.environ['MKL_NUM_THREADS'] = '1'
    os.environ['NUMEXPR_NUM_THREADS'] = '1'
    os.environ['OPENBLAS_NUM_THREADS'] = '1'
    os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
    # NOTE: libcuda still uses threads, but not with mutexes

    set_thread_pools_size(1)

    patch_ldclient()
    patch_langfuse()
    patch_cassandra_forking()

    def _log_threads_after_fork():
        import threading
        python_tids = set()
        non_main = []
        for t in threading.enumerate():
            if t is threading.main_thread():
                continue
            non_main.append(f'{t.name}(tid={t.native_id})')
            if t.native_id:
                python_tids.add(str(t.native_id))

        native_only = []
        try:
            for tid in os.listdir('/proc/self/task'):
                if tid not in python_tids and int(tid) != os.getpid():
                    native_only.append(tid)
        except OSError:
            pass

        if non_main or native_only:
            parts = []
            if non_main:
                parts.append('python: ' + ', '.join(non_main))
            if native_only:
                parts.append('native: ' + ', '.join(native_only))
            logger.debug('Python threads alive after fork: %s', '; '.join(parts))
        else:
            logger.debug('No threads alive after fork')

    os.register_at_fork(after_in_parent=_log_threads_after_fork)


def patch_ldclient():
    try:
        import ldclient.event_processor  # type: ignore[import-not-found]
        _orig_shutdown = ldclient.event_processor.EventDispatcher._do_shutdown
        def _patched_shutdown(self):
            # Some versions of ldclient don't shutdown some threads properly,
            # so we do this manually.
            diag_workers = getattr(self, '_diagnostic_flush_workers', None)
            if diag_workers:
                diag_workers.stop()
                diag_workers.wait()
            _orig_shutdown(self)

        ldclient.event_processor.EventDispatcher._do_shutdown = _patched_shutdown

        def _prefork():
            # Close the ldclient instance before forking
            logger.info('Closing LaunchDarkly client before fork')
            ldclient.get().close()

        os.register_at_fork(before=_prefork)
    except ImportError:
        pass


def patch_langfuse():
    try:
        import langfuse  # type: ignore[import-not-found]
        _orig_langfuse = langfuse.Langfuse
        _langfuse_instances = []

        class _PatchedLangfuse:
            def __init__(self, *args, **kwargs):
                object.__setattr__(self, '_init_args', args)
                object.__setattr__(self, '_init_kwargs', kwargs)
                object.__setattr__(self, '_inner', _orig_langfuse(*args, **kwargs))
                _langfuse_instances.append(self)

            def _dagz_close(self):
                # Close the inner instance
                inner = object.__getattribute__(self, '_inner')
                if inner:
                    inner.shutdown()
                    object.__setattr__(self, '_inner', None)

            def __getattr__(self, name):
                if name.startswith('_dagz_'):
                    return object.__getattribute__(self, name)

                inner = object.__getattribute__(self, '_inner')
                if not inner:
                    object.__setattr__(self, '_inner', _orig_langfuse(
                        *object.__getattribute__(self, '_init_args'),
                        **object.__getattribute__(self, '_init_kwargs')))

                return object.__getattribute__(inner, name)

            def __setattr__(self, name, value):
                """Handle attribute setting"""
                inner = object.__getattribute__(self, '_inner')
                if not inner:
                    inner = _orig_langfuse(
                        *object.__getattribute__(self, '_init_args'),
                        **object.__getattribute__(self, '_init_kwargs'))
                    object.__setattr__(self, '_inner', inner)
                setattr(inner, name, value)

        langfuse.Langfuse = _PatchedLangfuse

        def _prefork():
            logger.info(f'Closing {len(_langfuse_instances)} Langfuse instances before fork')
            for instance in _langfuse_instances:
                instance._dagz_close()

        os.register_at_fork(before=_prefork)

    except ImportError:
        pass


def disable_datadog(pluginmanager):
    os.environ['DD_INSTRUMENTATION_TELEMETRY_ENABLED'] = '0'
    os.environ['DD_TRACE_ENABLED'] = '0'
    os.environ['DD_DOGSTATSD_DISABLE'] = '1'
    pluginmanager.set_blocked('ddtrace')

    # Disable noisy loggers
    logging.getLogger('botocore.utils').setLevel(logging.INFO)
    logging.getLogger('datadog.dogstatsd').setLevel(logging.INFO)
    logging.getLogger('celery.utils.functional').setLevel(logging.INFO)

def disable_conflicting_plugins(earlyconfig):
    pluginmanager = earlyconfig.pluginmanager
    # Rerunfailures starts background threads which cause deadlocks with forked workers.
    pluginmanager.set_blocked('rerunfailures')

    # We manage flaky tests ourselves
    pluginmanager.set_blocked('flaky')

    # We replace xdist parallel execution with our own optimized version.
    pluginmanager.set_blocked('xdist')
    pluginmanager.set_blocked('xdist.looponfail')

    # Disable test-groups - we do test scheduling better.
    pluginmanager.set_blocked('test-groups')
    pluginmanager.set_blocked('pytest-split')
    pluginmanager.set_blocked('pytest-split-ext')
    pluginmanager.set_blocked('pytest-split-tests')
    pluginmanager.set_blocked('pytest-test-groups')
    pluginmanager.set_blocked('pytest-test-grouping')

    # Disable cov plugin - we do this better
    pluginmanager.set_blocked('pytest_cov')
    pluginmanager.set_blocked('cov')

    # Disable benchmark plugin - we do this better
    pluginmanager.set_blocked('benchmark')

    # Disable nose support - requires pytest_setup before we're invoked.
    # Nose was deprecated at pytest 7 and removed at pytest 8.
    # We must put our pytest_runtest_setup plugin with try_last, which breaks pytest 7 with nose.
    # (for pytest_asyncio compatibility)
    pluginmanager.set_blocked('nose')

    sugar = pluginmanager.get_plugin('sugar')
    if sugar:
        def _nop_print_failure(*_args, **_kwargs):
            pass
        sugar.SugarTerminalReporter.print_failure = _nop_print_failure

    # pytest_timeout uses SIGALRM which crashes when terminalreporter is blocked.
    # Block it unconditionally — DAGZ will implement its own timeout mechanism.
    pluginmanager.set_blocked('timeout')


def unload_app_modules(rootpath):
    # Force unload of application modules, so we can rerun the tests with modified code.
    try:
        logger.info(f'Unloading app modules in {rootpath}')
        for name, mod in list(sys.modules.items()):
            spec = getattr(mod, '__spec__', None)
            if spec:
                origin = getattr(spec, 'origin', None)
                if origin and origin.startswith(rootpath) and '/.venv' not in origin:
                    # logger.debug(f'Unloading module {name} from {origin}')
                    del sys.modules[name]

        sys.path = [dir for dir in sys.path if dir and dir != rootpath]
    except Exception as exc:
        logger.exception('Cannot unload modules: %s', exc)
