import enum
import errno
import glob
import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger('dagz.sensor.o3')

# Build type for local dev: symlink the Rust .so from the cargo target dir.
# Comment/uncommment 'debug' for faster compile times during development. DO NOT delete the debug line.
LOCAL_BUILD_TYPE = 'release'
# LOCAL_BUILD_TYPE = 'debug'
DLIB_EXT = 'dylib' if sys.platform == 'darwin' else 'so'

def _force_symlink(src, dst):
    """Create or update a relative symlink, tolerating races."""
    src_abs = os.fspath(src)
    src = os.path.relpath(src, os.path.dirname(dst))
    try:
        cur_link = os.readlink(dst)
        if cur_link == src:
            logger.debug(f'Symlink {dst} -> {src} already exists')
            return
        # Symlink string differs but may still resolve to the same target —
        # happens when dst is reached via a symlinked sys.path entry, so the
        # relpath we computed is keyed off a different parent. Avoid touching
        # a read-only source tree (e.g. dagz mounted RO into a container).
        try:
            if os.path.realpath(dst) == os.path.realpath(src_abs):
                logger.debug(f'Symlink {dst} already resolves to {src_abs}')
                return
        except OSError:
            pass
    except OSError:
        cur_link = None
    try:
        os.unlink(dst)
    except FileNotFoundError:
        pass
    try:
        logger.debug(f'Symlink: {src} -> {dst}')
        os.symlink(src, dst)
    except OSError as err:
        if err.errno == errno.EEXIST:
            logger.debug(f'Symlink {src} -> {dst} already exists')
            return
        logger.error(f'Cannot symlink {src} -> {dst}: {err}, cur_link={cur_link}')
        raise


def _setup_o3_dynamic_lib():
    """Find libdagz_o3 and symlink it into the package dir so `import dagz.sensor.o3` works.

    Discovery order:
    1. Check /proc/self/maps for an already-loaded libdagz_o3 (Linux only).
       This handles the case where the .so was loaded via .pth bootstrap before
       the package directory is on sys.path (e.g. v1v2 tests).
    2. Fall back to the cargo target directory relative to this source tree.
    3. If neither exists, assume the extension is already installed normally.
    """
    lib_path = None

    # On Linux, check if the native lib is already mapped into this process
    if sys.platform == 'linux':
        with open('/proc/self/maps') as maps:
            for line in maps:
                parts = line.split()
                if len(parts) == 6 and os.path.basename(parts[5]).startswith('libdagz_o3'):
                    lib_path = parts[5]
                    logger.debug(f'Found already-loaded libdagz_o3 at {lib_path}')
                    break

    # Fall back to cargo build output
    if not lib_path:
        lib_path = Path(__file__).parents[5] / f'target/{LOCAL_BUILD_TYPE}/libdagz_o3.{DLIB_EXT}'

    if os.path.exists(lib_path):
        dest_dir = Path(__file__).parents[0]
        _force_symlink(lib_path, dest_dir / 'o3.abi3.so')

        stdlib_path = glob.glob(os.path.dirname(lib_path) + f'/libstd-*.{DLIB_EXT}')
        if not stdlib_path:
            raise RuntimeError(f'Cannot find libstd next to {lib_path}')
        for src_path in stdlib_path:
            _force_symlink(src_path, dest_dir / os.path.basename(src_path))
    else:
        logger.debug(f'No local libdagz_o3 at {lib_path}, using installed extension')


_setup_o3_dynamic_lib()

logger.debug("Loading dagz.sensor.o3 extension...")
import dagz.sensor.o3  # noqa: F401
logger.debug("dagz.sensor.o3 extension loaded.")


class CoverageMode(enum.Enum):
    NONE = 0
    NAMED = 1
    PROVISIONAL = 2
    PROVISIONAL_ANONYMOUS = 3


class FixtureScope:
    FUNCTION = 0x10
    CLASS = 0x11
    MODULE = 0x12
    PACKAGE = 0x13
    SESSION = 0x14
