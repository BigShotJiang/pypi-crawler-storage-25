from __future__ import annotations

import ast
import builtins
import dis
import importlib.metadata
import importlib.util
import io
import logging
import marshal
import os
import struct
import tokenize
import types
import sys

import time


logger = logging.getLogger('dagz.instrument')
_orig_compile = builtins.compile

op_EXTENDED_ARG = dis.EXTENDED_ARG

DEBUG = 0
ENABLE_PYC = not os.environ.get('PYTHONDONTWRITEBYTECODE')


# Pyc cache version: package version, or git hash for dev installs
try:
    _dagz_version = importlib.metadata.version('dagz')
except importlib.metadata.PackageNotFoundError:
    try:
        import subprocess
        _dagz_version = subprocess.check_output(
            ['git', 'rev-parse', '--short', 'HEAD'],
            cwd=os.path.dirname(__file__),
            stderr=subprocess.DEVNULL,
        ).decode().strip()
    except (OSError, subprocess.CalledProcessError):
        _dagz_version = 'dev'


CWD = os.getcwd()


def dump_dis(fname, code, stage):
    if not DEBUG:
        return
    instrumenter = 'rust'
    debug_dir = f'/tmp/instru/{instrumenter}/{stage}'
    debug_dir += os.path.dirname(fname[len(CWD):])
    os.makedirs(debug_dir, exist_ok=True)
    debug_out = io.StringIO()
    dis.dis(code, file=debug_out)
    import re
    debug_out = re.sub(r'at 0x[0-9a-f]+', 'at <ADDR>', debug_out.getvalue())
    debug_out = re.sub(r'frozenset\(.*', 'frozenset(<DATA>)', debug_out)
    open(debug_dir + '/' + os.path.basename(fname + '.dis'), 'w').write(debug_out)


class FileInstrumentor:
    def __init__(self, origin, session, module_hash, with_pytest):
        self.session = session
        self.origin = origin
        self.module_hash = module_hash
        self._origin_stat = None

        pyc_tail = session.pyc_tail_pytest if with_pytest else session.pyc_tail
        file_dir, _, basename = origin.rpartition('/')
        stem = basename[:-3] if basename.endswith('.py') else basename
        if sys.pycache_prefix:
            cache_dir = sys.pycache_prefix + '/' + file_dir
        else:
            cache_dir = file_dir + '/__pycache__'
        self._pyc_path = f'{cache_dir}/{stem}{pyc_tail}'

    def load_pyc(self):
        """Read cached bytecode. Returns code object on hit, None on miss.
        Stores source stat for later use by save_pyc (TOCTOU protection)."""

        if not ENABLE_PYC:
            return None

        self._origin_stat = os.stat(self.origin)
        try:
            with open(self._pyc_path, 'rb') as fp:
                header = fp.read(16)
                if len(header) < 16:
                    return None
                if header[:4] != importlib.util.MAGIC_NUMBER:
                    logger.debug('pyc magic mismatch (python version changed?): %s', self._pyc_path)
                    return None
                if header[4:8] != b'\x00\x00\x00\x00':
                    return None
                mtime, size = struct.unpack("<LL", header[8:16])
                if mtime != int(self._origin_stat.st_mtime) & 0xFFFFFFFF:
                    logger.debug('pyc stale (source mtime changed): %s', self._pyc_path)
                    return None
                if size != self._origin_stat.st_size & 0xFFFFFFFF:
                    logger.debug('pyc stale (source size changed): %s', self._pyc_path)
                    return None
                # Validate dagz version (stored as length-prefixed string)
                ver_len_raw = fp.read(2)
                if len(ver_len_raw) < 2:
                    return None
                ver_len = struct.unpack("<H", ver_len_raw)[0]
                ver = fp.read(ver_len)
                if len(ver) < ver_len or ver.decode() != _dagz_version:
                    logger.debug('pyc stale (dagz version changed): %s', self._pyc_path)
                    return None
                co = marshal.load(fp)
                if not isinstance(co, types.CodeType):
                    return None
                #logger.debug('loaded pyc: %s', self._pyc_path)
                return co
        except FileNotFoundError:
            return None
        except (OSError, ValueError, EOFError) as exc:
            logger.debug(
                'pyc unreadable (%r errno=%r filename=%r strerror=%r): %s',
                exc,
                getattr(exc, 'errno', None),
                getattr(exc, 'filename', None),
                getattr(exc, 'strerror', None),
                self._pyc_path,
            )
            return None

    def save_pyc(self, code):
        """Write compiled code object to pyc cache. Must be called after load_pyc (uses stored source stat)."""
        if not ENABLE_PYC:
            return

        try:
            os.makedirs(os.path.dirname(self._pyc_path), exist_ok=True)
            idx = self._pyc_path.rfind('/') + 1
            wip_path = self._pyc_path[:idx] + '_wip_' + self._pyc_path[idx:]
            ver_bytes = _dagz_version.encode()
            with open(wip_path, 'wb') as fp:
                fp.write(importlib.util.MAGIC_NUMBER)
                fp.write(b'\x00\x00\x00\x00')
                fp.write(struct.pack("<LL",
                    int(self._origin_stat.st_mtime) & 0xFFFFFFFF,
                    self._origin_stat.st_size & 0xFFFFFFFF))
                fp.write(struct.pack("<H", len(ver_bytes)))
                fp.write(ver_bytes)
                marshal.dump(code, fp)
            os.replace(wip_path, self._pyc_path)
        except OSError as exc:
            pyc_exists = os.path.exists(self._pyc_path)
            log = logger.error if pyc_exists else logger.warning
            log(
                'pyc save failed (%r errno=%r filename=%r strerror=%r pyc_exists=%s): %s',
                exc,
                getattr(exc, 'errno', None),
                getattr(exc, 'filename', None),
                getattr(exc, 'strerror', None),
                pyc_exists,
                self._pyc_path,
            )

    def instrument_ast(self, tree):
        start = time.time()
        self.session.o3.inject_ast_hooks(tree, self.module_hash)
        elapsed = time.time() - start
        if elapsed > 1:
            logger.warning(f"Took {elapsed:.3f}s to inject hooks into {self.origin}")

    def instrument_code(self, code):
        start = time.time()

        if os.stat(self.origin).st_size == 0:
            # Empty files generate weird code objects, failing us in 3.10. Just ignore them.
            return code
        try:
            dump_dis(self.origin, code, 'before')
            new_code = self.session.o3.instrument_module_code(code)
            dump_dis(self.origin, new_code, 'after')
            return new_code

        except BaseException as exc:
            logger.exception(f"Error instrumenting module {self.origin}: {exc}")
            raise
        finally:
            elapsed = time.time() - start
            if elapsed > 1:
                logger.warning(f"Took {elapsed:.3f}s to instrument {self.origin}")

    def load_instrument(self):
        code = self.load_pyc()

        if code is None:
            f = tokenize.open(self.origin)
            try:
                source = f.read()
            finally:
                f.close()

            tree = ast.parse(source, filename=self.origin)
            self.instrument_ast(tree)
            code = _orig_compile(tree, self.origin, 'exec', dont_inherit=True)
            self.save_pyc(code)

        return self.instrument_code(code)
