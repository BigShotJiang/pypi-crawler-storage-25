"""Bootstrap module imported at interpreter startup via dagz.pth.

This module is executed early during Python startup, enabling import-time
coverage collection before any project code loads.
"""
import logging
import os
import threading

import sys

logger = logging.getLogger(__name__)

class ThreadIDFilter(logging.Filter):
    """Logging filter that adds thread_id attribute."""

    def filter(self, record):
        record.thread_id = threading.get_native_id()
        return True


def bootstrap_dagz_logs(level = logging.INFO):
    """Set up basic logging for bootstrap phase."""
    if os.environ.get('DAGZ_TRACE', '0') == '1':
        level = logging.DEBUG
    elif os.environ.get('DAGZ_DEBUG', '0') == '1':
        level = logging.DEBUG
    dagz_logger = logging.getLogger('dagz')
    for handler in list(dagz_logger.handlers):
        dagz_logger.removeHandler(handler)

    handler = logging.StreamHandler(stream=sys.stderr)
    formatter = logging.Formatter('[%(name)s] [t%(thread_id)d] %(message)s')
    handler.setFormatter(formatter)
    handler.addFilter(ThreadIDFilter())
    handler.setLevel(level)
    dagz_logger.addHandler(handler)
    dagz_logger.setLevel(logging.DEBUG)
    dagz_logger.propagate = False


_bootstrapped = False


def bootstrap():
    global _bootstrapped
    if _bootstrapped:
        return
    _bootstrapped = True

    if master_addr := os.environ.get('DAGZ_MASTER_ADDR'):
        bootstrap_dagz_logs(logging.INFO)
        logger.debug(f'DAGZ: running as subprocess, will connect to master at {master_addr}')
    elif instance_uri := os.environ.get('DAGZ_INSTANCE_URI'):
        bootstrap_dagz_logs(logging.DEBUG)
        logger.debug(f'DAGZ: running as service, will connect to instance at {instance_uri}')
    else:
        bootstrap_dagz_logs(logging.DEBUG)
        return

    try:
        if os.path.isfile(sys.argv[0]):
            if os.path.basename(sys.argv[0]).startswith('pydev'):
                is_module = False
                entrypoint = None
                for idx, arg in enumerate(sys.orig_argv):
                    if arg == '--module':
                        is_module = True
                        sys.argv = sys.orig_argv[idx + 1:]
                    if arg == '--file':
                        entrypoint = sys.orig_argv[idx + 1]
                        sys.argv = sys.orig_argv[idx + 1:]
                if entrypoint is None:
                    logger.debug('Pydev debug session without --file, unexpected, not instrumenting')
                    return
                if is_module:
                    logger.debug(f'Executing main module (pydev): {entrypoint}, {__name__} [{sys.orig_argv}]')
                    import dagz.sensor.app_session
                    session = dagz.sensor.app_session.AppSession(entrypoint, is_module=True)
                else:
                    script_path = os.path.abspath(entrypoint)
                    logger.debug(f'Executing main script (pydev): {script_path} {sys.orig_argv} {sys.argv}')
                    import dagz.sensor.app_session
                    session = dagz.sensor.app_session.AppSession(script_path, is_module=False)
            else:
                # If running a script directly (python script.py), instrument and run it.
                # No official API for execution mode. At bootstrap time, sys.argv[0] is:
                #   script: file path (e.g. '/path/to/script.py')
                #   -c:     literal '-c'
                #   -m:     literal '-m' (changes to module path after bootstrap)
                # isfile() distinguishes scripts from other modes.
                # For -c/-m, import hooks handle instrumentation; compile hook not needed.
                script_path = os.path.abspath(sys.argv[0])
                logger.debug('Executing main script: %s %s', script_path, sys.orig_argv)
                import dagz.sensor.app_session
                session = dagz.sensor.app_session.AppSession(script_path, is_module=False)
        elif sys.argv[0] == '-m':
            for idx, arg in enumerate(sys.orig_argv):
                if arg == '-m':
                    # Next arg is the module name
                    module_name = sys.orig_argv[idx + 1]
                    break
            else:
                logger.error('DAGZ: -m specified but no module name found')
                return

            logger.debug(f'Executing main module: {module_name} cwd={os.getcwd()}')
            import dagz.sensor.app_session
            session = dagz.sensor.app_session.AppSession(module_name, is_module=True)
        else:
            logger.debug('Not a script or module execution, cannot instrument')
            return
    except NotImplementedError:
        logger.warning('DAGZ: instrumentation disabled')
        return

    session.hijack_execution()
