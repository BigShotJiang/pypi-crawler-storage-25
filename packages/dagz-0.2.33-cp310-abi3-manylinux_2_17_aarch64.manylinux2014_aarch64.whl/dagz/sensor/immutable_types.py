from __future__ import annotations

import enum
import logging
import os
import pathlib
import re
import typing


def get_immutable_types():
    types = [
        typing.TypeVar,
        typing.Pattern,
        re.Pattern,
        os.PathLike,
        pathlib.Path,
        enum.Enum,
        logging.Logger,
    ]

    try:
        import datadog.dogstatsd  # type: ignore[import-not-found]
        types.append(datadog.dogstatsd.DogStatsd)
    except ImportError:
        pass

    try:
        import statsd  # type: ignore[import-not-found]
        types.append(statsd.StatsClient)
    except ImportError:
        pass

    return types
