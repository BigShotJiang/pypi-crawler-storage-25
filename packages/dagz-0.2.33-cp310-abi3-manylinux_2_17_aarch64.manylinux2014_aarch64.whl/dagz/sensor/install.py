import logging

logger = logging.getLogger('dagz.install')
_unhooks = []

def install_hook(unhook):
    if unhook:
        _unhooks.append(unhook)


def install_dagz_hooks(session, importer):
    install_hook(importer.install())

    from dagz.integ import cassandra, redis, pymysql, psycopg, psycopg2, aiomysql, aiormq, pika
    from dagz.integ import cloudpickle, numba
    install_hook(cloudpickle.install_hooks(session))
    install_hook(numba.install_hooks(session))
    importer.register_import_callback('cassandra.cluster', cassandra.CASSANDRA_CONFIG.install_hooks, session)
    importer.register_import_callback('redis', redis.REDIS_CONFIG.install_hooks, session)
    importer.register_import_callback('pymysql', pymysql.MYSQL_CONFIG.install_hooks, session)
    importer.register_import_callback('psycopg', psycopg.PG_CONFIG.install_hooks, session)
    importer.register_import_callback('psycopg2', psycopg2.install_hooks, session)
    importer.register_import_callback('aiomysql', aiomysql.install_hooks, session)
    importer.register_import_callback('pika', pika.install_hooks, session)
    importer.register_import_callback('aiormq', aiormq.install_hooks, session)


def install_worker_hooks(session):
    from dagz.pytest.exits import install_exit_hooks
    install_hook(install_exit_hooks(session))


def uninstall_dagz_hooks():
    global _unhooks

    for unhook in _unhooks:
        if unhook:
            unhook()
    _unhooks = []
