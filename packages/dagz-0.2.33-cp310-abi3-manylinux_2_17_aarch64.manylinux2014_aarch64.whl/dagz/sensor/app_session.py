"""AppSession: dagz instrumentation for non-test processes.

Handles running Python scripts/apps with dagz coverage collection when invoked
as a subprocess (DAGZ_MASTER_ADDR set) or service (DAGZ_INSTANCE_URI set).
"""
import os
import site
import signal
import io
import traceback

# Internal API, but stable across Python 3.9-3.14 (verified signature is identical).
# We use it because runpy.run_path() bypasses import hooks (compile+exec directly),
# so we instrument the code ourselves and use _run_module_code for proper module setup.
from runpy import _run_module_code

import atexit
import logging
import sys
from importlib.machinery import ModuleSpec

from dagz.sensor.base_session import BaseSession
from dagz.sensor.install import install_hook
from dagz.sensor.instrument import FileInstrumentor
from dagz.sensor.o3 import AppSessionO3, SpanResult

logger = logging.getLogger(__name__)

_orig_remove_handler = logging.Logger.removeHandler
_orig_basic_config = logging.basicConfig
_orig_os_exit = os._exit


class AppLogHandler(logging.Handler):
    def __init__(self, session):
        super().__init__()
        self.session = session

        logging.getLogger().addHandler(self)

        # remove bootstrap loggers
        dagz_logger = logging.getLogger('dagz')
        for handler in list(dagz_logger.handlers):
            dagz_logger.removeHandler(handler)
        dagz_logger.propagate = True

        logging.Logger.removeHandler = AppLogHandler._protective_remove_handler
        logging.basicConfig = self._override_basic_config

    @staticmethod
    def _protective_remove_handler(self, handler):
        if isinstance(handler, AppLogHandler):
            # Don't allow removing self
            return
        _orig_remove_handler(self, handler)

    def _override_basic_config(self, **kwargs):
        force = kwargs.get('force')
        root = logging.root
        must_re_add = force or len(root.handlers) == 1
        # print(f"DAGZ: overriding logging.basicConfig, force={force} handlers={' '.join(str(type(h))+':'+str(h) for h in root.handlers)} re_add={must_re_add}")
        if must_re_add:
            # Without force, our protective removeHandler causes basicConfig to do nothing.
            # We clean the handler list by force, and then add self back
            for h in root.handlers[:]:
                root.removeHandler(h)
                h.close()
            # Remove self by force
            root.handlers.clear()

        _orig_basic_config(**kwargs)
        if must_re_add:
            root.addHandler(self)

    def emit(self, record):
        if record.exc_info:
            # Do it like they do it in logging.StreamHandler
            sio = io.StringIO()
            traceback.print_exception(*record.exc_info, None, sio)
            exc_dump = sio.getvalue()
            sio.close()
        else:
            exc_dump = None

        self.session.o3.log(record, exc_dump)

    def close(self):
        logging.debug("Ignoring logger close")


class AppSession(BaseSession):
    """Session for non-test processes (scripts, services, subprocesses)."""

    _instance: 'AppSession' = None

    def __init__(self, entrypoint: str, is_module=False):
        # Make sure the session is never released
        AppSession._instance = self
        self.is_module = is_module
        self.entrypoint = entrypoint
        self.entry_loader = None  # Set by ModuleLoader.get_code() when entry is detected
        self.closed = False

        super().__init__(AppSessionO3(
            entrypoint=entrypoint,
            is_module=is_module,
        ))
        logger.debug('Expecting main module...')
        from dagz.sensor.module_loader import MetaFinder
        importer = MetaFinder(self)

        from dagz.sensor.install import install_dagz_hooks
        install_dagz_hooks(self, importer)

        if self.o3.distributed_coverage:
            # Start hooking subprocess only when the master is ready to accept coverage
            from dagz.integ.subproc import hook_subprocess
            install_hook(hook_subprocess())

        from dagz.integ.pymysql import MYSQL_CONFIG
        from dagz.integ.psycopg import PG_CONFIG
        from dagz.integ.rabbitmq import RABBITMQ_CONFIG
        from dagz.integ.redis import REDIS_CONFIG
        MYSQL_CONFIG.configure_app(self)
        PG_CONFIG.configure_app(self)
        RABBITMQ_CONFIG.configure_app(self)
        REDIS_CONFIG.configure_app(self)
        self.app_expecting_entry = self

        self.log_handler = AppLogHandler(self)

        self.prepare_session()

    def close(self):
        if self.closed:
            logger.debug('AppSession already closed')
            return

        self.closed = True
        logger.debug('Closing AppSession')
        # Verify entry module was detected via import hooks
        assert self.entry_loader is not None, (
            f'DAGZ: entry module was not detected during import. '
            f'entrypoint={self.entrypoint}, is_module={self.is_module}'
        )
        self.o3.close(SpanResult.OK)

    def close_on_signal(self, signum):
        original_handler = signal.getsignal(signum)

        def wrapper(current_signum, current_frame):
            logger.debug(f"Intercepted signal: {signal.strsignal(current_signum)}")

            self.close()

            if callable(original_handler):
                logger.debug("Calling original signal handler")
                original_handler(current_signum, current_frame)

            elif original_handler == signal.SIG_DFL:
                logger.debug("Calling default handler")
                signal.signal(current_signum, signal.SIG_DFL)
                os.kill(os.getpid(), current_signum)

            elif original_handler == signal.SIG_IGN:
                logger.debug("Previous handler was IGNORE, nothing to do now")

        signal.signal(signum, wrapper)

    def hijack_execution(self):
        def _os_exit_wrapper(status):
            logger.debug(f"Intercepted os exit: {status}")
            try:
                self.close()
            finally:
                _orig_os_exit(status)
        os._exit = _os_exit_wrapper

        self.close_on_signal(signal.SIGTERM)
        self.close_on_signal(signal.SIGINT)
        self.close_on_signal(signal.SIGABRT)

        if self.is_module:
            atexit.register(self.close)
            return

        # When running scripts, we've found no other way than hijacking execution.
        # Other methods would be wrapping the entire launch from the calling process,
        # in these cases we don't want always have any control (e.g. exec bia arbitrary bash script).
        # Python runs scripts without the import machinery, and without calling hookable
        # compile() or exec().
        # Our pth file starts with zzzz_ so it runs last.
        # Python's site module runs sitecustomize and usercustomize after running .pth files,
        # so we replicate that behavior here.
        site.execsitecustomize()
        if site.ENABLE_USER_SITE:
            site.execusercustomize()

        # runpy.run_path() bypasses import hooks - it uses compile()+exec() directly.
        # We instrument the code ourselves and use runpy._run_module_code for proper
        # module setup (_TempModule, _ModifiedArgv0 context managers).
        process_result = SpanResult.OK
        exit_code = 0
        span = None
        mod_dict = None
        try:
            spec = ModuleSpec('__main__', None, origin=self.entrypoint)
            span, module_hash = self.o3.start_module_load(spec)
            instrumentor = FileInstrumentor(self.entrypoint, self, module_hash, with_pytest=False)
            code = instrumentor.load_instrument()

            # Use runpy's internal machinery for proper module setup
            mod_dict = _run_module_code(code, mod_name='__main__', pkg_name='',
                                        script_name=self.entrypoint)
            span.result = SpanResult.OK
        except SystemExit as exc:
            exit_code = exc.code if isinstance(exc.code, int) else (1 if exc.code else 0)
            process_result = SpanResult.OK if exit_code == 0 else SpanResult.ERROR
            if span:
                span.result = process_result
        except:
            process_result = SpanResult.ERROR
            if span:
                span.result = SpanResult.ERROR
            raise
        finally:
            if span:
                self.o3.finish_module_load(mod_dict)
            self.o3.close(process_result)

            # Exit without triggering warnings about SystemExit being raised
            # (from python's site module, which runs this via our .pth file).
            # Manually run cleanup since os._exit() skips them
            atexit._run_exitfuncs()
            sys.stdout.flush()
            sys.stderr.flush()
            _orig_os_exit(exit_code)
