from __future__ import annotations

import contextlib
import hashlib
import logging
import os
import sys

import _pytest.outcomes

from dagz.sensor.install import install_hook
from dagz.sensor.o3 import SpanResult
from dagz.sensor.o3_binding import CoverageMode

logger = logging.getLogger(__name__)


class BaseSession:
    instance: 'BaseSession' = None

    def __init__(self, o3):
        self.o3 = o3
        self.test_prerun = []
        self.app_expecting_entry = None

        # Mutable view of OTel BAGGAGE: integrations read inherited values and
        # write outgoing ones; get_subproc_init serializes back to children.
        self.baggage: dict[str, str] = {}
        if raw := os.environ.get('BAGGAGE'):
            for entry in raw.split(','):
                key, sep, value = entry.partition('=')
                if sep:
                    self.baggage[key.strip()] = value.strip()

        if dagz_worker := os.environ.get('DAGZ_WORKER'):
            num_str, role = dagz_worker.split(':')
            worker_num = int(num_str)
            is_main = role == 'main'
            logger.debug(f'setting worker from env (DAGZ_WORKER={dagz_worker})')
            self.set_worker_num(worker_num, is_main)
        else:
            self.worker_num = None
            self.worker_id = None
            self.worker_suffix = None
            self.is_main_worker = False

        if o3.collect_caches:
            from dagz.sensor.caches import hook_functools_lru, hook_async_lru
            install_hook(hook_functools_lru(o3))
            install_hook(hook_async_lru(o3))

        config_hash = hashlib.sha256(
            o3.get_config_fingerprint().encode()
        ).hexdigest()[:8]
        self._pyc_base = f".{sys.implementation.cache_tag}-dagz-{config_hash}"
        self.pyc_tail = self._pyc_base + ".pyc"

        # These are needed by MetaFinder for instrumentation decisions
        BaseSession.instance = self

    def set_worker_num(self, worker_num, is_main_worker):
        self.worker_num = worker_num
        self.worker_id = f'jw{worker_num:02}'
        self.worker_suffix = f'_{self.worker_id}'
        self.is_main_worker = is_main_worker
        os.environ['DAGZ_WORKER'] = f'{worker_num}:{"main" if is_main_worker else "worker"}'

    @contextlib.contextmanager
    def span(self, typ: str, name: str, *, slug: str = None, coverage: CoverageMode = CoverageMode.NONE, fixture_scope=0):
        span = self.o3.start_span(typ, name, slug=slug, coverage=coverage.value, fixture_scope=fixture_scope)
        # otel_span = self.otel_tracer.start_as_current_span(name)
        try:
            yield span
            if span.result == SpanResult.NOT_SET:
                span.result = SpanResult.OK
        except Exception:
            span.result = SpanResult.ERROR
            raise
        except _pytest.outcomes.Skipped:
            span.result = SpanResult.SKIPPED_IN_CODE
            raise
        except _pytest.outcomes.XFailed:
            span.result = SpanResult.XFAIL
            raise
        except _pytest.outcomes.Failed:
            span.result = SpanResult.FAILED
            raise
        finally:
            self.o3.finish_span(None)

    @property
    def workers_per_node(self):
        return self.o3.workers_per_node

    def get_subproc_init(self):
        """Env + pass_fds for subprocess propagation. Merges self.baggage on
        top of Rust's BAGGAGE (which only carries the active span_key)."""
        env, fds = self.o3.get_subproc_init()
        if self.baggage:
            extra = ','.join(f'{k}={v}' for k, v in self.baggage.items())
            existing = env.get('BAGGAGE', '')
            env['BAGGAGE'] = f'{existing},{extra}' if existing else extra
        return env, fds

    def prepare_session(self):
        # Collect package paths from editable installs
        for finder in sys.meta_path:
            mod_name = getattr(finder, '__module__', None)
            if not mod_name:
                continue
            module = sys.modules.get(mod_name)
            if not module:
                continue
            mapping = getattr(module, 'MAPPING', None)
            if mapping:
                for name, path in mapping.items():
                    self.o3.register_package(name, path)
