class DagzError(Exception):
    pass
