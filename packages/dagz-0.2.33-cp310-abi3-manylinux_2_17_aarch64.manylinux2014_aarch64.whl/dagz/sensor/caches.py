import sys

from dagz.sensor.o3 import SpanResult, SpanType
from dagz.sensor.o3_binding import CoverageMode
import functools
import logging

logger = logging.getLogger(__name__)

_NOT_EXISTS_SENTINEL = object()
CACHE_SPAN_TYPE = SpanType.CACHE

def hook_decorator(orig_decorator, new_decorator):
    logger.debug(f"Hooking cache decorator: {orig_decorator.__module__}.{orig_decorator.__name__}")
    functools.update_wrapper(new_decorator, orig_decorator)
    setattr(sys.modules[orig_decorator.__module__], orig_decorator.__name__, new_decorator)

    def unhook():
        setattr(sys.modules[orig_decorator.__module__], orig_decorator.__name__, orig_decorator)

    return unhook


def update_wrapper(wrapper, wrapped_func):
    functools.update_wrapper(wrapper, wrapped_func)
    for attr_name in type(wrapped_func).__dict__:
        if not attr_name.startswith('__'):
            setattr(wrapper, attr_name, getattr(wrapped_func, attr_name))


def _callable_qualname(f):
    mod = getattr(f, '__module__', None) or type(f).__module__
    name = getattr(f, '__qualname__', None) or getattr(f, '__name__', None) or type(f).__name__
    return f'{mod}.{name}'


def _impersonate_caller_file(wrapper, user_func):
    # Rewrite the wrapper's co_filename to match user_func's file. Walkers like
    # pandas' find_stack_level() stop at the first frame outside the library;
    # without this they stop at caches.py and pin warnings to us instead of
    # the real caller.
    try:
        target = user_func.__code__.co_filename
    except AttributeError:
        return
    wrapper.__code__ = wrapper.__code__.replace(co_filename=target)


def hook_functools_lru(o3_session):
    orig_decorator = functools.lru_cache

    def decorator_wrapper(maxsize=128, typed=False):

        def decorate(user_func):
            cache = {}
            cache_get = cache.get
            span_name = f'lru_cache({_callable_qualname(user_func)})'
            def wrapper(*args, **kwargs):
                key = functools._make_key(args, kwargs, typed)
                span_id = cache_get(key, _NOT_EXISTS_SENTINEL)
                if span_id is _NOT_EXISTS_SENTINEL:
                    span = o3_session.start_span(CACHE_SPAN_TYPE, span_name,
                                          coverage=CoverageMode.PROVISIONAL_ANONYMOUS.value, sub_span=True)
                    try:
                        val = wrapped_func(*args, **kwargs)
                    except BaseException:
                        o3_session.finish_span(SpanResult.ERROR)
                        raise
                    else:
                        o3_session.finish_span(SpanResult.OK)
                        cache[key] = span.name
                else:
                    # Coverage already collected, reuse previous span as dependency
                    o3_session.add_called_span(CACHE_SPAN_TYPE, span_id)
                    val = wrapped_func(*args, **kwargs)

                return val

            wrapped_func = orig_decorator(maxsize=maxsize, typed=typed)(user_func)
            update_wrapper(wrapper, wrapped_func)
            _impersonate_caller_file(wrapper, user_func)
            return wrapper

        if callable(maxsize):
            user_func, maxsize = maxsize, 128
            return decorate(user_func)
        else:
            return decorate

    return hook_decorator(functools.lru_cache, decorator_wrapper)


def hook_async_lru(o3_session):
    try:
        import async_lru  # type: ignore[import-not-found]
    except ImportError:
        return None

    orig_decorator = async_lru.alru_cache

    def decorator_wrapper(maxsize=128, typed=False, **decorator_kwargs):
        def decorate(user_func):
            cache = {}
            cache_get = cache.get
            span_name = f'alru_cache({_callable_qualname(user_func)})'
            async def wrapper(*args, **kwargs):
                key = functools._make_key(args, kwargs, typed)
                span_id = cache_get(key, _NOT_EXISTS_SENTINEL)
                if span_id is _NOT_EXISTS_SENTINEL:
                    span = o3_session.start_span(CACHE_SPAN_TYPE, span_name,
                                          coverage=CoverageMode.PROVISIONAL_ANONYMOUS.value, sub_span=True)
                    try:
                        val = await wrapped_func(*args, **kwargs)
                    except BaseException:
                        o3_session.finish_span(SpanResult.ERROR)
                        raise
                    else:
                        o3_session.finish_span(SpanResult.OK)
                        cache[key] = span.name
                else:
                    # Coverage already collected, reuse previous span as dependency
                    o3_session.add_called_span(CACHE_SPAN_TYPE, span_id)
                    val = await wrapped_func(*args, **kwargs)

                return val

            wrapped_func = orig_decorator(user_func, **decorator_kwargs)
            update_wrapper(wrapper, wrapped_func)
            _impersonate_caller_file(wrapper, user_func)
            return wrapper

        if callable(maxsize):
            user_func, maxsize = maxsize, 128
            return decorate(user_func)
        else:
            return decorate

    return hook_decorator(orig_decorator, decorator_wrapper)
