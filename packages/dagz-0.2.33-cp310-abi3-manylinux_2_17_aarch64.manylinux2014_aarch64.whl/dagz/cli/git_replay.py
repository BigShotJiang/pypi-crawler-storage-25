"""dagz git-replay — replay pytest across recent commits to build DAGZ baselines.

WARNING: This runs 'git reset --hard' on each commit. It WILL discard
any uncommitted changes. Stash or commit your work before running this.
"""

import os
import re
import shlex
import subprocess
import sys


def _colorize_shortstat(raw):
    # "3 files changed, 10 insertions(+), 5 deletions(-)" -> "3 files  +10  -5"
    files = re.search(r"(\d+) file", raw)
    ins = re.search(r"(\d+) insertion", raw)
    dels = re.search(r"(\d+) deletion", raw)
    parts = []
    if files:
        parts.append(f"{files.group(1)} files")
    if ins:
        parts.append(f"\033[32m+{ins.group(1)}\033[0m")
    if dels:
        parts.append(f"\033[31m-{dels.group(1)}\033[0m")
    return "  ".join(parts)


def cmd_git_replay(args):
    """Replay pytest with --dagz across recent commits to build baselines.

    Walks first-parent commits oldest-first, running pytest --dagz on each one.
    Useful for bootstrapping DAGZ on an existing project.
    """
    # Resolve cherry-pick commit-ishes to SHAs upfront. `HEAD` or a branch name
    # would otherwise drift on the first `git reset --hard`.
    cherry_picks = []
    for commitish in args.cherry_pick:
        sha = subprocess.check_output(["git", "rev-parse", commitish], text=True).strip()
        print(f"Cherry-pick: {commitish} -> {sha[:12]}")
        cherry_picks.append(sha)

    log_cmd = ["git", "log", "--first-parent", "--format=%H %ae %s",
               f"-n{args.num_commits}", args.branch]
    if args.merges_only:
        log_cmd.insert(2, "--merges")
    output = subprocess.check_output(log_cmd, text=True)
    lines = [line for line in output.splitlines() if line]
    lines.reverse()  # oldest first

    if not lines:
        kind = "merge commits" if args.merges_only else "commits"
        print(f"No {kind} found on {args.branch}")
        return 1

    commits = []
    emails = {}
    subjects = {}
    has_py_map = {}
    diff_stats = {}
    prev = None
    for line in lines:
        commit_hash, email, subject = line.split(" ", 2)
        has_py_map[commit_hash] = prev is None or bool(subprocess.check_output(
            ["git", "diff", "--name-only", prev, commit_hash, "--", "*.py"], text=True).strip())
        if prev is not None:
            raw = subprocess.check_output(
                ["git", "diff", "--shortstat", prev, commit_hash], text=True).strip()
            diff_stats[commit_hash] = _colorize_shortstat(raw)
        commits.append(commit_hash)
        emails[commit_hash] = email
        subjects[commit_hash] = subject
        prev = commit_hash

    # Verify patch applies on each commit
    failed_patches = set()
    if args.patch_file:
        for commit in commits:
            subprocess.check_output(["git", "reset", "--hard", commit])
            rc = subprocess.run(["git", "apply", "--reject", args.patch_file]).returncode
            if rc != 0:
                failed_patches.add(commit)
            subprocess.check_output(["git", "reset", "--hard", commit])

    # Print commit summary
    kind = "merge commits" if args.merges_only else "commits"
    print(f"\nFound {len(commits)} {kind} from {args.branch}:")
    for i, commit in enumerate(commits):
        py_marker = "py" if has_py_map[commit] else "  "
        patch_marker = " PATCH-FAIL" if commit in failed_patches else ""
        stat = f"  ({diff_stats[commit]})" if commit in diff_stats else ""
        print(f"  {i+1:3}. [{py_marker}] {commit[:12]} {subjects[commit]}{patch_marker}{stat}")

    if failed_patches:
        print(f"\nPatch failed on {len(failed_patches)}/{len(commits)} commits")
        if not args.allow_patch_failure:
            return 1
        commits = [c for c in commits if c not in failed_patches]
        print(f"Continuing with {len(commits)} commits")

    if not args.run:
        print("\nDry run. Pass --run to execute.")
        return 0

    pytest_args = []
    for arg_str in args.pytest_args:
        pytest_args += shlex.split(arg_str)

    prev_commit = None
    for commit in commits:
        subprocess.check_output(["git", "reset", "--hard", commit])
        cherry_pick_failed = False
        for sha in cherry_picks:
            rc = subprocess.run(["git", "cherry-pick", "--allow-empty", sha]).returncode
            if rc != 0:
                subprocess.run(["git", "cherry-pick", "--abort"], check=False)
                if args.allow_patch_failure:
                    print(f"[{commit[:12]}] cherry-pick {sha[:12]} failed; skipping commit")
                    cherry_pick_failed = True
                    break
                raise SystemExit(
                    f"cherry-pick {sha[:12]} failed on top of {commit[:12]}; "
                    f"pass --allow-patch-failure to skip such commits"
                )
        if cherry_pick_failed:
            continue
        if args.patch_file:
            subprocess.run(["git", "apply", "--reject", args.patch_file])
        has_py_changes = prev_commit is None or bool(subprocess.check_output(
            ["git", "diff", "--name-only", prev_commit, commit, "--", "*.py"], text=True).strip())
        if args.prerun and has_py_changes:
            subprocess.check_call([args.prerun])
        prev_commit = commit
        # Use the dagz CLI's own Python so we hit the same venv where dagz is
        # installed; PATH may not include the venv's bin dir.
        cmd = [sys.executable, "-m", "pytest", "--dagz"]
        if commit == commits[0]:
            cmd.append("--dagz-no-baseline")
        elif args.skip_redundant:
            cmd.append("--dagz-skip-redundant=1")
        cmd += pytest_args
        # Make sure the dagz CLI's own venv/bin is on PATH for the pytest
        # subprocess. Some projects (e.g. pandas with meson-python's editable
        # loader) auto-rebuild Cython on each `git reset`, and the build tools
        # (`cython`, `ninja`) need to be resolvable without an activated venv.
        py_bin = os.path.dirname(sys.executable)
        env = {
            **os.environ,
            "DAGZ_USER_EMAIL": emails[commit],
            "PATH": py_bin + os.pathsep + os.environ.get("PATH", ""),
        }
        print(f"[{commit[:12]}] {' '.join(cmd)}")
        subprocess.run(cmd, check=False, cwd=os.environ["PWD"], env=env)
        if args.patch_file:
            subprocess.run(["git", "apply", "--reject", "--reverse", args.patch_file])

    return 0
