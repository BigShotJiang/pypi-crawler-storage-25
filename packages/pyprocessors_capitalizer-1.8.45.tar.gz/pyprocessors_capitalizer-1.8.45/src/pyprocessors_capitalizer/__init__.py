"""Replace document text with capitalized annotations"""

__version__ = "1.8.45"
