"""Runtime settings for Dewey."""

from __future__ import annotations

import colorsys
import hashlib
import os
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from dewey_service.defaults import (
    DEFAULT_APP_PORT,
    DEFAULT_COGNITO_ALLOWED_EMAIL_DOMAINS,
    build_default_config_template,
    default_cognito_logout_url,
    default_cognito_redirect_uri,
)
from dewey_service.rbac import DEFAULT_COGNITO_GROUP_ROLE_MAP, normalize_group_role_map

DEFAULT_COGNITO_DEFAULT_TENANT_ID = "00000000-0000-0000-0000-000000000000"
DEFAULT_COGNITO_AUTO_PROVISION_ALLOWED_DOMAINS = ("lsmc.com",)

DEFAULT_DEPLOYMENT_BANNER_COLOR = "#AFEEEE"
PRODUCTION_DEPLOYMENT_NAMES = {"prod", "production"}


def _require_https_url(value: str, *, field_name: str) -> str:
    normalized = str(value or "").strip().rstrip("/")
    if not normalized:
        raise ValueError(f"{field_name} is required")
    if not normalized.startswith("https://"):
        raise ValueError(f"{field_name} must use an absolute https:// URL")
    return normalized


def _validate_optional_https_url(value: str, *, field_name: str) -> str:
    normalized = str(value or "").strip().rstrip("/")
    if not normalized:
        return ""
    if not normalized.startswith("https://"):
        raise ValueError(f"{field_name} must use an absolute https:// URL")
    return normalized


def _normalize_email_domains(value: Any, *, default: tuple[str, ...] | None = None) -> list[str]:
    if value is None:
        return list(default or [])
    if isinstance(value, str):
        raw_items = value.split(",")
    elif isinstance(value, (list, tuple, set)):
        raw_items = list(value)
    else:
        raise ValueError("email domains must be a string or list of strings")
    cleaned = [str(item or "").strip().lower() for item in raw_items if str(item or "").strip()]
    return cleaned if cleaned else list(default or [])


def _normalize_managed_storage_bucket(value: str, *, allow_empty: bool = True) -> str:
    normalized = str(value or "").strip()
    if normalized.startswith("s3://"):
        normalized = normalized[5:]
    normalized = normalized.strip().strip("/")
    if not normalized:
        if allow_empty:
            return ""
        raise ValueError("managed_storage_bucket is required")
    if "/" in normalized:
        raise ValueError(
            "managed_storage_bucket must be a bucket name, not an s3://bucket/key path"
        )
    if any(char.isspace() for char in normalized):
        raise ValueError("managed_storage_bucket must not contain whitespace")
    return normalized


def _default_config_path() -> Path:
    root = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    return root / _config_dir_name() / _config_filename()


def _sanitize_deployment_code(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9-]+", "-", str(value or "").strip()).strip("-")
    return cleaned or "local"


def _resolve_deployment_code() -> str:
    return _sanitize_deployment_code(
        os.environ.get("DEWEY_DEPLOYMENT_CODE")
        or os.environ.get("DEPLOYMENT_CODE")
        or os.environ.get("LSMC_DEPLOYMENT_CODE")
        or "local"
    )


def _config_dir_name() -> str:
    return f"dewey-{_resolve_deployment_code()}"


def _config_filename() -> str:
    deployment = _resolve_deployment_code()
    return f"dewey-config-{deployment}.yaml"


def _stable_deployment_color_hex(name: str) -> str:
    digest = hashlib.sha256(name.encode("utf-8")).digest()
    hue = int.from_bytes(digest[:8], "big") % 360
    red, green, blue = colorsys.hls_to_rgb(hue / 360.0, 0.46, 0.72)
    return "#{:02x}{:02x}{:02x}".format(
        round(red * 255),
        round(green * 255),
        round(blue * 255),
    )


def _resolve_deployment_chrome(
    *,
    name: str | None,
    color: str | None,
    fallback_name: str | None = None,
) -> dict[str, Any]:
    resolved_name = str(name or "").strip() or str(fallback_name or "").strip()
    resolved_color = str(color or "").strip()
    if not resolved_color:
        resolved_color = (
            _stable_deployment_color_hex(resolved_name)
            if resolved_name
            else DEFAULT_DEPLOYMENT_BANNER_COLOR
        )
    return {
        "name": resolved_name,
        "color": resolved_color,
        "is_production": resolved_name.lower() in PRODUCTION_DEPLOYMENT_NAMES,
    }


def _flatten_config(config: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(config, dict):
        return {}

    out: dict[str, Any] = {}

    def _write(prefix: str, payload: dict[str, Any]) -> None:
        for key, value in payload.items():
            merged = f"{prefix}_{key}" if prefix else str(key)
            if merged == "auth_cognito_group_role_map" and isinstance(value, dict):
                out[merged] = value
            elif isinstance(value, dict):
                _write(merged, value)
            else:
                out[merged] = value

    _write("", config)

    remap = {
        "application_api_bearer_token": "api_bearer_token",
        "application_api_bearer_tokens": "api_bearer_tokens",
        "application_session_secret_key": "session_secret_key",
        "application_host": "host",
        "application_port": "port",
        "application_verify_ssl": "verify_ssl",
        "application_search_export_max_rows": "search_export_max_rows",
        "database_backend": "database_backend",
        "database_target": "database_target",
        "database_namespace": "tapdb_database_name",
        "database_client_id": "tapdb_client_id",
        "database_env": "tapdb_env",
        "database_config_path": "tapdb_config_path",
        "aws_profile": "aws_profile",
        "aws_region": "aws_region",
        "storage_managed_bucket": "managed_storage_bucket",
        "storage_managed_prefix": "managed_storage_prefix",
        "storage_upload_session_ttl_seconds": "upload_session_ttl_seconds",
        "auth_cognito_domain": "cognito_domain",
        "auth_cognito_app_client_id": "cognito_app_client_id",
        "auth_cognito_app_client_secret": "cognito_app_client_secret",
        "auth_cognito_redirect_uri": "cognito_redirect_uri",
        "auth_cognito_logout_url": "cognito_logout_url",
        "auth_cognito_user_pool_id": "cognito_user_pool_id",
        "auth_cognito_region": "cognito_region",
        "auth_cognito_allowed_email_domains": "cognito_allowed_email_domains",
        "auth_cognito_default_tenant_id": "cognito_default_tenant_id",
        "auth_cognito_auto_provision_allowed_domains": "cognito_auto_provision_allowed_domains",
        "auth_cognito_group_role_map": "cognito_group_role_map",
        "deployment_name": "deployment_name",
        "deployment_color": "deployment_color",
        "deployment_is_production": "deployment_is_production",
    }
    normalized: dict[str, Any] = {}
    for key, value in out.items():
        normalized[remap.get(key, key)] = value
    return normalized


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="DEWEY_",
        case_sensitive=False,
        extra="ignore",
    )

    environment: str = "development"
    api_bearer_token: str = "dewey-dev-token"
    api_bearer_tokens: str = ""
    session_secret_key: str = "dewey-session-secret-change-me"
    host: str = "127.0.0.1"
    port: int = DEFAULT_APP_PORT
    verify_ssl: bool = True

    # Cognito-backed browser UI auth
    cognito_domain: str = ""
    cognito_app_client_id: str = ""
    cognito_app_client_secret: str = ""
    cognito_redirect_uri: str = default_cognito_redirect_uri()
    cognito_logout_url: str = default_cognito_logout_url()
    cognito_user_pool_id: str = ""
    cognito_region: str = "us-west-2"
    cognito_allowed_email_domains: list[str] = Field(
        default_factory=lambda: list(DEFAULT_COGNITO_ALLOWED_EMAIL_DOMAINS)
    )
    cognito_default_tenant_id: str = DEFAULT_COGNITO_DEFAULT_TENANT_ID
    cognito_auto_provision_allowed_domains: list[str] = Field(
        default_factory=lambda: list(DEFAULT_COGNITO_AUTO_PROVISION_ALLOWED_DOMAINS)
    )
    cognito_group_role_map: dict[str, str] = Field(
        default_factory=lambda: dict(DEFAULT_COGNITO_GROUP_ROLE_MAP)
    )

    deployment_name: str = ""
    deployment_color: str = ""
    deployment_is_production: bool = False

    # TapDB runtime
    database_backend: str = "tapdb"
    database_target: str = "local"
    tapdb_client_id: str = "dewey"
    tapdb_database_name: str = "dewey"
    tapdb_env: str = "dev"
    tapdb_config_path: str = ""
    tapdb_strict_namespace: int = 1

    # AWS defaults for TapDB wrappers
    aws_profile: str = "lsmc"
    aws_region: str = "us-west-2"

    # Dewey-managed storage
    managed_storage_bucket: str = ""
    managed_storage_prefix: str = "artifacts"
    upload_session_ttl_seconds: int = 900

    # Literature integration
    literature_managed_copy_allowed_domains: str = "europepmc.org,ncbi.nlm.nih.gov"
    literature_metapub_cache_dir: str = ""
    literature_request_timeout_seconds: int = 10
    literature_max_redirects: int = 3

    # Share reference defaults
    default_share_reference_ttl_seconds: int = 3600
    search_export_max_rows: int = 1000

    @field_validator("cognito_redirect_uri", "cognito_logout_url")
    @classmethod
    def validate_cognito_urls(cls, value: str, info):
        return _validate_optional_https_url(value, field_name=str(info.field_name))

    @field_validator("database_backend")
    @classmethod
    def validate_db_backend(cls, value: str) -> str:
        normalized = str(value or "").strip().lower()
        if normalized != "tapdb":
            raise ValueError("database_backend must be tapdb")
        return normalized

    @field_validator("database_target")
    @classmethod
    def validate_db_target(cls, value: str) -> str:
        normalized = str(value or "").strip().lower()
        if normalized not in {"local", "aurora"}:
            raise ValueError("database_target must be one of: local, aurora")
        return normalized

    @field_validator("api_bearer_token")
    @classmethod
    def validate_api_bearer_token(cls, value: str) -> str:
        normalized = str(value or "").strip()
        if not normalized:
            raise ValueError("api_bearer_token is required")
        return normalized

    @field_validator("managed_storage_bucket")
    @classmethod
    def validate_managed_storage_bucket(cls, value: str) -> str:
        return _normalize_managed_storage_bucket(value, allow_empty=True)

    @field_validator("managed_storage_prefix")
    @classmethod
    def validate_managed_storage_prefix(cls, value: str) -> str:
        normalized = str(value or "").strip().strip("/")
        return normalized or "artifacts"

    @field_validator("cognito_group_role_map", mode="before")
    @classmethod
    def validate_cognito_group_role_map(cls, value: Any) -> dict[str, str]:
        return normalize_group_role_map(value)

    @field_validator(
        "cognito_allowed_email_domains", "cognito_auto_provision_allowed_domains", mode="before"
    )
    @classmethod
    def validate_cognito_email_domains(cls, value: Any) -> list[str]:
        return _normalize_email_domains(value)

    @field_validator("environment")
    @classmethod
    def validate_environment(cls, value: str) -> str:
        normalized = str(value or "").strip().lower()
        if normalized not in {"development", "staging", "production", "testing"}:
            raise ValueError(
                "environment must be one of: development, staging, production, testing"
            )
        return normalized

    @field_validator("cognito_default_tenant_id")
    @classmethod
    def validate_cognito_default_tenant_id(cls, value: str) -> str:
        normalized = str(value or "").strip()
        if not normalized:
            return DEFAULT_COGNITO_DEFAULT_TENANT_ID
        return normalized

    @model_validator(mode="after")
    def validate_cognito_contract(self) -> "Settings":
        missing: list[str] = []
        if not str(self.cognito_domain or "").strip():
            missing.append("cognito_domain")
        if not str(self.cognito_app_client_id or "").strip():
            missing.append("cognito_app_client_id")
        if not str(self.cognito_redirect_uri or "").strip():
            missing.append("cognito_redirect_uri")
        if not str(self.cognito_logout_url or "").strip():
            missing.append("cognito_logout_url")
        if missing:
            raise ValueError("Cognito UI auth is required; missing settings: " + ", ".join(missing))
        self.cognito_domain = _require_https_url(
            self.cognito_domain,
            field_name="cognito_domain",
        )
        self.cognito_allowed_email_domains = _normalize_email_domains(
            self.cognito_allowed_email_domains,
            default=DEFAULT_COGNITO_ALLOWED_EMAIL_DOMAINS,
        )
        self.cognito_auto_provision_allowed_domains = _normalize_email_domains(
            self.cognito_auto_provision_allowed_domains,
            default=DEFAULT_COGNITO_AUTO_PROVISION_ALLOWED_DOMAINS,
        )
        deployment = _resolve_deployment_chrome(
            name=self.deployment_name,
            color=self.deployment_color,
            fallback_name=_resolve_deployment_code(),
        )
        self.deployment_name = str(deployment["name"])
        self.deployment_color = str(deployment["color"])
        self.deployment_is_production = bool(deployment["is_production"])
        return self

    def api_tokens(self) -> set[str]:
        tokens = {str(self.api_bearer_token or "").strip()}
        for item in str(self.api_bearer_tokens or "").split(","):
            cleaned = str(item).strip()
            if cleaned:
                tokens.add(cleaned)
        return {item for item in tokens if item}

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def deployment(self) -> dict[str, Any]:
        return {
            "name": self.deployment_name,
            "color": self.deployment_color,
            "is_production": self.deployment_is_production,
        }

    @property
    def literature_allowed_domains(self) -> set[str]:
        return {
            str(item or "").strip().lower()
            for item in str(self.literature_managed_copy_allowed_domains or "").split(",")
            if str(item or "").strip()
        }

    def validate_cognito_email_domain(self, email: str) -> tuple[bool, str]:
        if not email:
            return False, "Email address is required"
        if "@" not in email:
            return False, "Invalid email address format"
        domain = email.split("@")[-1].strip().lower()
        if not domain:
            return False, "Invalid email address: missing domain"
        allowed = {
            str(item or "").strip().lower()
            for item in self.cognito_allowed_email_domains
            if str(item or "").strip()
        }
        if domain not in allowed:
            return False, (
                f"Email domain '{domain}' is not allowed. "
                f"Registration is restricted to: {', '.join(sorted(allowed))}"
            )
        return True, ""


def get_config_file_path() -> Path:
    return _default_config_path()


def _template_config_payload() -> dict[str, Any]:
    raw = yaml.safe_load(build_default_config_template().decode("utf-8")) or {}
    if not isinstance(raw, dict):
        raise ValueError("Default Dewey config template must parse to a mapping")
    return raw


def _load_config_payload(config_path: Path | None = None) -> tuple[Path, dict[str, Any]]:
    cfg_path = config_path or get_config_file_path()
    if not cfg_path.exists():
        return cfg_path, _template_config_payload()
    raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        raise ValueError("Config root YAML object must be a mapping")
    return cfg_path, raw


def persist_managed_storage_bucket(
    bucket: str,
    *,
    config_path: Path | None = None,
) -> tuple[Path, str]:
    cfg_path, raw = _load_config_payload(config_path)
    normalized = _normalize_managed_storage_bucket(bucket, allow_empty=False)
    storage = raw.get("storage")
    if not isinstance(storage, dict):
        storage = {}
    storage["managed_bucket"] = normalized
    storage["managed_prefix"] = (
        str(storage.get("managed_prefix") or "").strip().strip("/") or "artifacts"
    )
    storage["upload_session_ttl_seconds"] = int(storage.get("upload_session_ttl_seconds") or 900)
    raw["storage"] = storage
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(yaml.safe_dump(raw, sort_keys=False), encoding="utf-8")
    clear_settings_cache()
    return cfg_path, normalized


def load_settings(config_path: Path | None = None) -> Settings:
    cfg_path = config_path or get_config_file_path()
    seed: dict[str, Any] = {}
    if cfg_path.exists():
        raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        if isinstance(raw, dict):
            seed = _flatten_config(raw)

    yaml_only_defaults = {
        "cognito_domain": "",
        "cognito_app_client_id": "",
        "cognito_app_client_secret": "",
        "cognito_redirect_uri": default_cognito_redirect_uri(),
        "cognito_logout_url": default_cognito_logout_url(),
        "cognito_user_pool_id": "",
        "cognito_region": "us-west-2",
        "cognito_allowed_email_domains": list(DEFAULT_COGNITO_ALLOWED_EMAIL_DOMAINS),
        "cognito_default_tenant_id": DEFAULT_COGNITO_DEFAULT_TENANT_ID,
        "cognito_auto_provision_allowed_domains": list(
            DEFAULT_COGNITO_AUTO_PROVISION_ALLOWED_DOMAINS
        ),
        "cognito_group_role_map": dict(DEFAULT_COGNITO_GROUP_ROLE_MAP),
        "deployment_name": "",
        "deployment_color": "",
        "deployment_is_production": False,
    }
    env_override = {
        key[len("DEWEY_") :].lower(): value
        for key, value in os.environ.items()
        if key.startswith("DEWEY_")
    }
    merged = {**seed}
    for key, default in yaml_only_defaults.items():
        merged[key] = seed.get(key, default)
    merged.update(env_override)
    return Settings(**merged)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return load_settings()


def clear_settings_cache() -> None:
    get_settings.cache_clear()
