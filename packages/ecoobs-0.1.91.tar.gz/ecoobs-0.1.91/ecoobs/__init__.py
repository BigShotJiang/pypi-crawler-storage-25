from .occurrence_requests import get_occurrences, clear_cache
from .gbif import save_gbif_credentials, delete_gbif_credentials, get_species_autocomplete, get_kingdoms, get_tree_node, gbif_key_exists
from .speciesLink import save_specieslink_apikey, delete_specieslink_apikey, species_link_key_exists

__all__ = [
    "get_occurrences",
    "get_species_autocomplete",
    "save_gbif_credentials",
    "delete_gbif_credentials",
    "save_specieslink_apikey",
    "delete_specieslink_apikey",
    "clear_cache",
    "get_kingdoms",
    "get_tree_node",
    "species_link_key_exists",
    "gbif_key_exists"
]

def version():
    return "0.0.1"
def  describe ():   
    description = ( 
        "Eco Obs Library\n" 
        "Version: {}\n" 
        "Implement functions to get occurrences records from GBIF/INaturalist/SpeciesLink as:\n" 
        " - get_occurrences\n" 
        " - get_species_autocomplete\n" 
     ). format (version()) 
    print (description)
  
    return description