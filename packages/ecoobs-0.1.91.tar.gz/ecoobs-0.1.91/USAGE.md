
# USAGE.md

## Overview

**ecoobs** is a library designed to facilitate data management and processing for scientific and research applications.

## Getting Started

### Installation

```bash
pip install ecoobs
```

### Basic Usage

```python
import ecoobs

# Example: Download occurrences from GBIF, iNaturalist, and SpeciesLink - INaturalist doesn't require any authentication.
ecoobs.save_specieslink_apikey(apikey)
ecoobs.save_gbif_credentials(user, email, pwd)
species_names = ["Panthera onca", "Lynx rufus"]
df = ecoobs.get_occurrences(
    species_names,
    country="Brazil",
    year_range=(2000, 2020),
)

```
## Functions
- `get_occurrences(species_names, country=None, year_range=None, lat_min=None, lat_max=None, lon_min = None, lon_max = None, 
    includeGbif = True, includeInaturalist = True, includeSpeciesLink = True)`: Fetches occurrence data for the specified species from GBIF, iNaturalist, and SpeciesLink (you can choose the source), with optional filters for country, year range, and latitude bounds.
- `get_species_autocomplete(name)`: Retrieves a list of species suggestions from GBIF based on the provided name.
- `save_gbif_credentials(user, email, pwd)`: Saves GBIF user credentials for authenticated requests.
- `save_specieslink_apikey(apikey)`: Saves the API key for SpeciesLink requests.
- `delete_gbif_credentials()`: Deletes stored GBIF user credentials.
- `delete_specieslink_apikey()`: Deletes the stored SpeciesLink API key.

