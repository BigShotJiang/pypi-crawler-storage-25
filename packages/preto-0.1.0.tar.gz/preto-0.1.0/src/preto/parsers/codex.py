"""Codex CLI log parser — best-effort support.

Codex stores user-visible history in ~/.codex/history.jsonl (prompts only,
no token data). Actual session data with token counts is in
~/.codex/logs_1.sqlite but the schema is undocumented.

Strategy:
  1. Try ~/.codex/sessions/*.jsonl (format TBD — ships when confirmed).
  2. Fall back to SQLite via stdlib sqlite3.
  3. If neither works, log a warning and yield nothing.

`preto status` reports "Codex: partial support" when this parser is active.
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from preto.models import TelemetryEvent
from preto.parsers.base import BaseParser

logger = logging.getLogger(__name__)

_SQLITE_DB = "logs_1.sqlite"
_SESSIONS_GLOB = "sessions/*.jsonl"


class CodexParser(BaseParser):
    """Best-effort Codex CLI telemetry parser."""

    tool_name = "codex"

    def log_paths(self) -> list[Path]:
        # Try sessions/*.jsonl first; fall back to the SQLite DB
        jsonl_files = sorted(self.log_root.glob(_SESSIONS_GLOB))
        if jsonl_files:
            return jsonl_files
        db_path = self.log_root / _SQLITE_DB
        if db_path.exists():
            return [db_path]
        return []

    def parse_file(
        self,
        path: Path,
        start_offset: int = 0,
    ) -> Iterator[tuple[TelemetryEvent, int]]:
        if path.suffix == ".jsonl":
            yield from self._parse_jsonl(path, start_offset)
        elif path.name == _SQLITE_DB:
            yield from self._parse_sqlite(path, start_offset)
        else:
            logger.debug("Codex parser: unknown file type %s", path)

    def _parse_jsonl(
        self, path: Path, start_offset: int
    ) -> Iterator[tuple[TelemetryEvent, int]]:
        """Parse Codex JSONL session files (schema TBD — best-effort)."""
        import json

        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                f.seek(start_offset)
                while True:
                    line = f.readline()
                    if not line:
                        break
                    offset = f.tell()
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        yield None, offset  # type: ignore[misc]
                        continue

                    event = self._entry_to_event(entry)
                    yield event, offset
        except OSError as e:
            logger.warning("Codex JSONL open error %s: %s", path, e)

    def _parse_sqlite(
        self, path: Path, start_offset: int
    ) -> Iterator[tuple[TelemetryEvent, int]]:
        """Read Codex SQLite DB — yields zero-token events as proof-of-life.

        The SQLite schema is undocumented; we extract what we can and emit
        events with zero tokens so sessions are still visible in the dashboard.
        Row IDs are used as the offset checkpoint.
        """
        try:
            conn = sqlite3.connect(str(path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Discover available tables
            cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
            tables = {row[0] for row in cursor.fetchall()}

            if "sessions" in tables:
                yield from self._read_sessions_table(cursor, start_offset)
            else:
                logger.info(
                    "Codex SQLite: no 'sessions' table found in %s (tables: %s)",
                    path,
                    tables,
                )
            conn.close()
        except sqlite3.Error as e:
            logger.warning("Codex SQLite read error %s: %s", path, e)

    def _read_sessions_table(
        self, cursor: sqlite3.Cursor, last_row_id: int
    ) -> Iterator[tuple[TelemetryEvent, int]]:
        cursor.execute(
            "SELECT * FROM sessions WHERE rowid > ? ORDER BY rowid", (last_row_id,)
        )
        for row in cursor.fetchall():
            row_id = row["rowid"] if "rowid" in row.keys() else 0
            event = TelemetryEvent(
                event_id=f"codex-sqlite-{row_id}",
                session_id=str(row["id"]) if "id" in row.keys() else f"codex-{row_id}",
                source="daemon",
                timestamp=_parse_ts(
                    row["created_at"] if "created_at" in row.keys() else None
                ),
                model=row["model"] if "model" in row.keys() else "",
                provider="openai",
                input_tokens=int(row["input_tokens"]) if "input_tokens" in row.keys() else 0,
                output_tokens=int(row["output_tokens"]) if "output_tokens" in row.keys() else 0,
                plan_type=self.plan_type,
                billing_mode=self.billing_mode,
            )
            yield event, row_id

    def _entry_to_event(self, entry: dict) -> TelemetryEvent | None:
        """Convert a Codex JSONL entry to a TelemetryEvent (best-effort)."""
        session_id = str(entry.get("session_id") or entry.get("id") or "")
        if not session_id:
            return None
        return TelemetryEvent(
            event_id=str(entry.get("id") or session_id),
            session_id=session_id,
            source="daemon",
            timestamp=_parse_ts(entry.get("timestamp") or entry.get("created_at")),
            model=str(entry.get("model", "")),
            provider="openai",
            input_tokens=int(entry.get("input_tokens", 0) or 0),
            output_tokens=int(entry.get("output_tokens", 0) or 0),
            plan_type=self.plan_type,
            billing_mode=self.billing_mode,
        )


def _parse_ts(raw: str | None) -> datetime:
    if not raw:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    try:
        cleaned = str(raw).replace("Z", "+00:00")
        dt = datetime.fromisoformat(cleaned)
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    except ValueError:
        return datetime.now(timezone.utc).replace(tzinfo=None)
