"""Abstract base class for all AI tool log parsers."""

from __future__ import annotations

import abc
from pathlib import Path
from typing import Iterator

from preto.models import TelemetryEvent


class BaseParser(abc.ABC):
    """Parse a tool's log files into a stream of TelemetryEvent objects.

    Subclasses must implement ``parse_file``.  The daemon calls ``parse_file``
    for each file returned by ``log_paths``, advancing the byte offset stored
    in sync_state so only new lines are processed on subsequent runs.
    """

    tool_name: str = ""

    def __init__(self, log_root: Path, plan_type: str = "", billing_mode: str = "") -> None:
        self.log_root = log_root
        self.plan_type = plan_type
        self.billing_mode = billing_mode

    @abc.abstractmethod
    def log_paths(self) -> list[Path]:
        """Return all log files this parser is responsible for."""

    @abc.abstractmethod
    def parse_file(
        self,
        path: Path,
        start_offset: int = 0,
    ) -> Iterator[tuple[TelemetryEvent, int]]:
        """Yield (event, new_byte_offset) pairs from *path* starting at *start_offset*.

        The offset is the file position *after* the last successfully parsed
        line so the sync layer can checkpoint it.
        """
