"""Claude Code JSONL log parser.

Reads ~/.claude/projects/**/*.jsonl and emits one TelemetryEvent per
assistant-type entry that contains a usage block.

Claude Code JSONL schema (relevant fields):
  {
    "type": "assistant" | "user" | "system" | "summary",
    "uuid": "<uuid>",
    "sessionId": "<session-uuid>",
    "timestamp": "<ISO8601>",
    "version": "2.1.100",           # present in every entry
    "message": {
      "role": "assistant",
      "model": "claude-opus-4-5-...",
      "usage": {
        "input_tokens": 123,
        "output_tokens": 456,
        "cache_read_input_tokens": 789,
        "cache_creation_input_tokens": 0
      },
      "content": [
        {"type": "tool_use", "name": "Read", "input": {"file_path": "/path"}},
        ...
      ]
    },
    "subtype": "compact_boundary",  # on system entries at compaction
    "compactMetadata": {"preTokens": 12345}
  }
"""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from preto.extractors.model import infer_provider, normalise_model
from preto.extractors.session import is_new_session
from preto.extractors.tokens import extract_context_tokens, extract_tokens
from preto.extractors.tools import extract_tool_actions
from preto.models import TelemetryEvent
from preto.parsers.base import BaseParser

logger = logging.getLogger(__name__)

# Minimum version we know how to parse; unknown versions get zero-token records.
_SUPPORTED_VERSION_PREFIX = "2."


class ClaudeCodeParser(BaseParser):
    """Parse Claude Code JSONL session files."""

    tool_name = "claude_code"

    def log_paths(self) -> list[Path]:
        """Glob all *.jsonl files under ~/.claude/projects/."""
        return sorted(self.log_root.glob("**/*.jsonl"))

    def parse_file(
        self,
        path: Path,
        start_offset: int = 0,
    ) -> Iterator[tuple[TelemetryEvent, int]]:
        """Yield (TelemetryEvent, byte_offset_after_line) from a JSONL file."""
        project_path_hash = hashlib.sha256(str(path.parent).encode()).hexdigest()[:16]

        # Per-file state (session tracking across turns)
        current_session_id: str | None = None
        prev_timestamp: datetime | None = None
        turn_counter = 0

        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                f.seek(start_offset)
                while True:
                    line_start = f.tell()
                    line = f.readline()
                    if not line:
                        break
                    line = line.rstrip("\n")
                    if not line:
                        continue

                    offset_after = f.tell()

                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        logger.debug("Skipping malformed JSON in %s at offset %d", path, line_start)
                        yield None, offset_after  # type: ignore[misc]
                        continue

                    # Bind refs as local variables so _process_entry can mutate
                    # them and we can read the updated values after the call.
                    sid_ref = [current_session_id]
                    ts_ref = [prev_timestamp]
                    turn_ref = [turn_counter]

                    event = self._process_entry(
                        entry=entry,
                        path=path,
                        project_path_hash=project_path_hash,
                        current_session_id_ref=sid_ref,
                        prev_timestamp_ref=ts_ref,
                        turn_counter_ref=turn_ref,
                    )

                    current_session_id = sid_ref[0]
                    prev_timestamp = ts_ref[0]
                    turn_counter = turn_ref[0]

                    if event is not None:
                        yield event, offset_after
                    else:
                        yield None, offset_after  # type: ignore[misc]

        except OSError as e:
            logger.warning("Cannot open %s: %s", path, e)

    def _process_entry(
        self,
        entry: dict,
        path: Path,
        project_path_hash: str,
        current_session_id_ref: list,
        prev_timestamp_ref: list,
        turn_counter_ref: list,
    ) -> TelemetryEvent | None:
        """Convert one JSONL entry to a TelemetryEvent or return None to skip."""
        entry_type = entry.get("type", "")
        session_id = entry.get("sessionId", "")

        # Handle compaction boundary (system entry)
        if entry_type == "system" and entry.get("subtype") == "compact_boundary":
            pre_tokens = int((entry.get("compactMetadata") or {}).get("preTokens", 0))
            if session_id and current_session_id_ref[0] == session_id:
                # Emit a compaction marker event
                return TelemetryEvent(
                    event_id=entry.get("uuid", "") or _make_id(path, entry),
                    session_id=session_id,
                    source="daemon",
                    timestamp=_parse_ts(entry.get("timestamp", "")),
                    model="",
                    provider="",
                    input_tokens=0,
                    output_tokens=0,
                    cache_read_tokens=0,
                    cache_write_tokens=0,
                    context_tokens_at_turn=0,
                    turn_number=turn_counter_ref[0],
                    plan_type=self.plan_type,
                    billing_mode=self.billing_mode,
                    is_compaction=True,
                    pre_compaction_tokens=pre_tokens,
                    project_path_hash=project_path_hash,
                )
            return None

        # Only process assistant entries
        if entry_type != "assistant":
            return None

        message = entry.get("message") or {}
        usage = message.get("usage") or {}

        # Version guard: skip unknown versions with zero-token fallback
        version = entry.get("version", "")
        if version and not version.startswith(_SUPPORTED_VERSION_PREFIX):
            logger.debug("Unknown Claude Code version %s — emitting zero-token record", version)
            usage = {}

        ts = _parse_ts(entry.get("timestamp", ""))

        # Session boundary detection
        if session_id != current_session_id_ref[0] or is_new_session(prev_timestamp_ref[0], ts):
            current_session_id_ref[0] = session_id
            turn_counter_ref[0] = 0

        turn_counter_ref[0] += 1
        prev_timestamp_ref[0] = ts

        input_tok, output_tok, cache_read, cache_write = extract_tokens(usage)
        context_tokens = extract_context_tokens(usage)

        content = message.get("content") or []
        files_read, files_written, commands_run = extract_tool_actions(content)

        model_raw = message.get("model", "")
        model = normalise_model(model_raw)
        provider = infer_provider(model_raw)

        return TelemetryEvent(
            event_id=entry.get("uuid", "") or _make_id(path, entry),
            session_id=session_id or current_session_id_ref[0] or "",
            source="daemon",
            timestamp=ts,
            model=model,
            provider=provider,
            input_tokens=input_tok,
            output_tokens=output_tok,
            cache_read_tokens=cache_read,
            cache_write_tokens=cache_write,
            context_tokens_at_turn=context_tokens,
            turn_number=turn_counter_ref[0],
            files_read=files_read,
            files_written=files_written,
            commands_run=commands_run,
            plan_type=self.plan_type,
            billing_mode=self.billing_mode,
            is_compaction=False,
            project_path_hash=project_path_hash,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_ts(ts_str: str) -> datetime:
    """Parse an ISO 8601 timestamp string to a UTC datetime."""
    if not ts_str:
        return datetime.now(timezone.utc)
    try:
        # Handle 'Z' suffix
        cleaned = ts_str.replace("Z", "+00:00")
        dt = datetime.fromisoformat(cleaned)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).replace(tzinfo=None)  # store as naive UTC
    except ValueError:
        return datetime.now(timezone.utc).replace(tzinfo=None)


def _make_id(path: Path, entry: dict) -> str:
    """Derive a deterministic event ID when 'uuid' is absent."""
    key = f"{path}:{entry.get('timestamp', '')}:{entry.get('type', '')}"
    return hashlib.sha256(key.encode()).hexdigest()[:32]
