"""Aider log parser — skeleton (v1: not implemented).

Aider writes session history to ~/.aider.chat.history.md in Markdown format.
The format is not yet formally documented; this parser ships as a skeleton
so the infrastructure is in place for v2 completion.

`preto status` reports "Aider: coming soon" when this tool is enabled.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterator

from preto.models import TelemetryEvent
from preto.parsers.base import BaseParser


class AiderParser(BaseParser):
    """Placeholder Aider parser — raises NotImplementedError."""

    tool_name = "aider"

    def log_paths(self) -> list[Path]:
        history = Path.home() / ".aider.chat.history.md"
        return [history] if history.exists() else []

    def parse_file(
        self,
        path: Path,
        start_offset: int = 0,
    ) -> Iterator[tuple[TelemetryEvent, int]]:
        raise NotImplementedError(
            "Aider parsing is not yet implemented. "
            "See https://preto.ai/docs/aider for the roadmap."
        )
        # Make this a generator so the type is correct
        return
        yield  # unreachable
