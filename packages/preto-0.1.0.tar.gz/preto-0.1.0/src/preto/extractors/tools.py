"""Extract file paths and commands from Claude Code tool_use content blocks."""

from __future__ import annotations

from typing import Any

# Tool names that indicate a file read operation
_READ_TOOLS = {"Read", "read_file", "view"}
# Tool names that indicate a file write/edit operation
_WRITE_TOOLS = {"Write", "Edit", "write_file", "create_file", "str_replace_editor"}
# Tool names that execute shell commands
_BASH_TOOLS = {"Bash", "bash", "shell", "run_command", "execute_bash"}


def extract_tool_actions(
    content: list[dict[str, Any]],
) -> tuple[list[str], list[str], list[str]]:
    """Parse content blocks and return (files_read, files_written, commands_run).

    Only processes blocks where ``type == "tool_use"``.
    File paths are extracted from the ``input`` dict; the key varies by tool:
    - ``file_path`` — Read, Write, Edit
    - ``path``      — some variants
    - ``command``   — Bash/shell commands
    """
    files_read: list[str] = []
    files_written: list[str] = []
    commands_run: list[str] = []

    if not content or not isinstance(content, list):
        return files_read, files_written, commands_run

    for block in content:
        if not isinstance(block, dict) or block.get("type") != "tool_use":
            continue

        tool_name: str = block.get("name", "")
        inp: dict = block.get("input", {}) or {}

        if tool_name in _READ_TOOLS:
            path = inp.get("file_path") or inp.get("path") or ""
            if path:
                files_read.append(str(path))

        elif tool_name in _WRITE_TOOLS:
            path = inp.get("file_path") or inp.get("path") or ""
            if path:
                files_written.append(str(path))

        elif tool_name in _BASH_TOOLS:
            cmd = inp.get("command", "")
            if cmd:
                # Truncate very long commands to 200 chars
                commands_run.append(str(cmd)[:200])

    return files_read, files_written, commands_run
