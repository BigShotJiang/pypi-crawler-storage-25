"""Model name normalisation and provider inference."""

from __future__ import annotations

# Prefix → provider mapping (longest prefix wins)
_PROVIDER_PREFIXES: list[tuple[str, str]] = [
    ("claude", "anthropic"),
    ("gpt-", "openai"),
    ("o1", "openai"),
    ("o3", "openai"),
    ("gemini", "google"),
    ("command", "cohere"),
    ("llama", "meta"),
    ("mixtral", "mistral"),
    ("mistral", "mistral"),
    ("codex", "openai"),
]


def infer_provider(model_name: str) -> str:
    """Infer the LLM provider from a model name string.

    Returns an empty string when the provider cannot be determined.
    """
    if not model_name:
        return ""
    lower = model_name.lower()
    for prefix, provider in _PROVIDER_PREFIXES:
        if lower.startswith(prefix):
            return provider
    return ""


def normalise_model(model_name: str) -> str:
    """Strip vendor-specific suffixes and lowercase the model identifier.

    Examples:
        "claude-3-5-sonnet-20241022" → "claude-3-5-sonnet-20241022"
        "Claude 3.5 Sonnet" → "claude-3-5-sonnet"
    """
    if not model_name:
        return ""
    # Replace spaces/underscores with hyphens, lowercase
    normalised = model_name.strip().lower().replace(" ", "-").replace("_", "-")
    return normalised
