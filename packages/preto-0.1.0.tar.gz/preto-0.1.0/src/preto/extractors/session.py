"""Session boundary detection for AI coding tool log streams.

The canonical rule: a new session begins when more than SESSION_GAP_MINUTES
minutes elapse between consecutive assistant turns in the same project directory.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

SESSION_GAP_MINUTES = 30


def is_new_session(prev_timestamp: datetime | None, current_timestamp: datetime) -> bool:
    """Return True if the gap between turns exceeds SESSION_GAP_MINUTES.

    Both timestamps must be comparable (timezone-aware or both naive).
    """
    if prev_timestamp is None:
        return True  # First event always starts a new session

    # Normalise to UTC-aware if naive
    if prev_timestamp.tzinfo is None:
        prev_timestamp = prev_timestamp.replace(tzinfo=timezone.utc)
    if current_timestamp.tzinfo is None:
        current_timestamp = current_timestamp.replace(tzinfo=timezone.utc)

    gap = current_timestamp - prev_timestamp
    return gap > timedelta(minutes=SESSION_GAP_MINUTES)
