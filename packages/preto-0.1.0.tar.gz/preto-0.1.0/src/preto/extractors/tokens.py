"""Token extraction from Claude Code / Codex assistant message usage blocks."""

from __future__ import annotations

from typing import Any


def extract_tokens(usage: dict[str, Any]) -> tuple[int, int, int, int]:
    """Extract (input, output, cache_read, cache_write) token counts from a usage dict.

    Handles both Claude Code JSONL naming conventions:
    - input_tokens
    - output_tokens
    - cache_read_input_tokens   → cache_read_tokens
    - cache_creation_input_tokens → cache_write_tokens

    Returns zeros for any missing key.
    """
    if not usage or not isinstance(usage, dict):
        return 0, 0, 0, 0

    input_tokens = int(usage.get("input_tokens", 0) or 0)
    output_tokens = int(usage.get("output_tokens", 0) or 0)
    cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)
    cache_write = int(usage.get("cache_creation_input_tokens", 0) or 0)

    return input_tokens, output_tokens, cache_read, cache_write


def extract_context_tokens(usage: dict[str, Any]) -> int:
    """Return the total context size (input + cache_read + cache_write) at this turn."""
    inp, _, cr, cw = extract_tokens(usage)
    return inp + cr + cw
