"""Platform-specific auto-start helpers for the preto daemon.

macOS: LaunchAgent plist → ~/Library/LaunchAgents/ai.preto.daemon.plist
Linux: systemd user service → ~/.config/systemd/user/preto.service
        Fallback: nohup + PID file at ~/.preto/preto.pid
Windows: not supported in v1.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

_PLIST_LABEL = "ai.preto.daemon"
_PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{_PLIST_LABEL}.plist"
_SYSTEMD_DIR = Path.home() / ".config" / "systemd" / "user"
_SYSTEMD_SERVICE = _SYSTEMD_DIR / "preto.service"
_PID_FILE = Path.home() / ".preto" / "preto.pid"
_LOG_DIR_MACOS = Path.home() / "Library" / "Logs" / "preto"


def install_autostart() -> str:
    """Install platform-appropriate auto-start mechanism. Returns status message."""
    if sys.platform == "darwin":
        return _install_launchagent()
    elif sys.platform.startswith("linux"):
        return _install_systemd()
    else:
        return "Windows auto-start not supported in v1. Use WSL2 or run `preto start` manually."


def uninstall_autostart() -> str:
    """Remove platform-appropriate auto-start mechanism."""
    if sys.platform == "darwin":
        return _uninstall_launchagent()
    elif sys.platform.startswith("linux"):
        return _uninstall_systemd()
    return "Nothing to uninstall on Windows."


def start_background() -> str:
    """Start the daemon in the background (portable fallback via Popen)."""
    if sys.platform == "win32":
        return "Windows native not supported in v1. Use WSL2."

    if is_running():
        return "Daemon is already running."

    preto_bin = shutil.which("preto")
    cmd: list[str] = [preto_bin, "daemon-run"] if preto_bin else [sys.executable, "-m", "preto", "daemon-run"]

    log_path = _log_file()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    _PID_FILE.parent.mkdir(parents=True, exist_ok=True)

    with open(log_path, "a") as log_fh:
        proc = subprocess.Popen(
            cmd,
            stdout=log_fh,
            stderr=log_fh,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # detach from terminal
        )

    _PID_FILE.write_text(str(proc.pid))
    return f"Daemon started (PID {proc.pid}). Logs: {log_path}"


def stop_background() -> str:
    """Stop a daemon started with nohup by reading the PID file."""
    if _PID_FILE.exists():
        pid = _PID_FILE.read_text().strip()
        try:
            os.kill(int(pid), 15)  # SIGTERM
            _PID_FILE.unlink(missing_ok=True)
            return f"Daemon (PID {pid}) stopped."
        except ProcessLookupError:
            _PID_FILE.unlink(missing_ok=True)
            return "Daemon was not running."
        except ValueError:
            return "Invalid PID file."
    # Try pkill as fallback
    os.system("pkill -f 'preto daemon-run'")
    return "Stop signal sent."


def is_running() -> bool:
    """Return True when a daemon process appears to be running."""
    if _PID_FILE.exists():
        pid = _PID_FILE.read_text().strip()
        try:
            os.kill(int(pid), 0)
            return True
        except (ProcessLookupError, ValueError, OSError):
            pass
    # Fallback: check process name
    result = subprocess.run(
        ["pgrep", "-f", "preto daemon-run"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


# ---------------------------------------------------------------------------
# macOS LaunchAgent
# ---------------------------------------------------------------------------


def _install_launchagent() -> str:
    preto_bin = shutil.which("preto") or sys.executable
    log_path = _LOG_DIR_MACOS / "daemon.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_PLIST_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{preto_bin}</string>
        <string>daemon-run</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_path}</string>
    <key>StandardErrorPath</key>
    <string>{log_path}</string>
</dict>
</plist>
"""
    _PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    _PLIST_PATH.write_text(plist)

    subprocess.run(["launchctl", "load", str(_PLIST_PATH)], check=False)
    return f"LaunchAgent installed at {_PLIST_PATH} and loaded."


def _uninstall_launchagent() -> str:
    if _PLIST_PATH.exists():
        subprocess.run(["launchctl", "unload", str(_PLIST_PATH)], check=False)
        _PLIST_PATH.unlink()
        return "LaunchAgent unloaded and removed."
    return "LaunchAgent not installed."


# ---------------------------------------------------------------------------
# Linux systemd
# ---------------------------------------------------------------------------


def _install_systemd() -> str:
    preto_bin = shutil.which("preto") or sys.executable
    service = f"""[Unit]
Description=Preto AI coding tool telemetry daemon
After=network.target

[Service]
Type=simple
ExecStart={preto_bin} daemon-run
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
"""
    _SYSTEMD_DIR.mkdir(parents=True, exist_ok=True)
    _SYSTEMD_SERVICE.write_text(service)

    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    subprocess.run(["systemctl", "--user", "enable", "--now", "preto"], check=False)
    return "systemd user service installed and started."


def _uninstall_systemd() -> str:
    subprocess.run(["systemctl", "--user", "disable", "--now", "preto"], check=False)
    if _SYSTEMD_SERVICE.exists():
        _SYSTEMD_SERVICE.unlink()
    return "systemd service disabled and removed."


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _log_file() -> Path:
    if sys.platform == "darwin":
        return _LOG_DIR_MACOS / "daemon.log"
    return Path.home() / ".preto" / "daemon.log"
