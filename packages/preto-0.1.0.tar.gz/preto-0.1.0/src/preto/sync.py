"""Sync state management and HTTP client for the preto daemon.

Sync state is stored at ~/.preto/sync_state.yaml:
  {
    "/path/to/file.jsonl": {
      "last_byte_offset": 12345,
      "last_sync_time": "2026-04-11T06:00:00Z"
    }
  }

Atomic writes use tempfile + os.replace so partial writes never corrupt state.

Offline buffer is stored at ~/.preto/offline_buffer.jsonl — one JSON event per
line. On reconnect the buffer is replayed before new events are sent. The file
is capped at _MAX_DISK_BUFFER_BYTES to prevent unbounded growth.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import yaml

from preto.config import DEFAULT_SYNC_STATE_PATH, Config
from preto.models import TelemetryEvent

logger = logging.getLogger(__name__)

_MAX_RETRIES = 3
_RETRY_DELAYS = [1.0, 2.0, 4.0]  # exponential back-off (seconds)
_MAX_DISK_BUFFER_BYTES = 10 * 1024 * 1024  # 10 MB
_OFFLINE_BUFFER_PATH = Path.home() / ".preto" / "offline_buffer.jsonl"


class SyncState:
    """Persistent per-file byte-offset checkpoint store."""

    def __init__(self, path: Path = DEFAULT_SYNC_STATE_PATH) -> None:
        self._path = path
        self._state: dict[str, dict[str, Any]] = {}
        self._load()

    def get_offset(self, file_path: Path) -> int:
        """Return the last synced byte offset for a file, or 0 if unseen."""
        return int(self._state.get(str(file_path), {}).get("last_byte_offset", 0))

    def set_offset(self, file_path: Path, offset: int) -> None:
        """Persist the byte offset for a file atomically."""
        key = str(file_path)
        self._state.setdefault(key, {})
        self._state[key]["last_byte_offset"] = offset
        self._state[key]["last_sync_time"] = datetime.now(timezone.utc).isoformat()
        self._save()

    def _load(self) -> None:
        if self._path.exists():
            with open(self._path) as f:
                self._state = yaml.safe_load(f) or {}
        else:
            self._state = {}

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self._path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w") as f:
                yaml.safe_dump(self._state, f, default_flow_style=False)
            os.replace(tmp, self._path)
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise


class PretoClient:
    """HTTP client for the preto API.

    Handles auth, retries with exponential back-off, and disk-backed offline
    buffering. Events that fail to send are written to offline_buffer.jsonl and
    replayed on the next successful connection.
    """

    def __init__(self, config: Config, buffer_path: Path = _OFFLINE_BUFFER_PATH) -> None:
        self._config = config
        self._buffer_path = buffer_path
        self._client = httpx.Client(
            base_url=config.api_url,
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=15.0,
        )

    def send_heartbeat(self, daemon_version: str, daemon_os: str = "") -> bool:
        """Send a liveness heartbeat to the API. Returns True on success."""
        payload = {"daemon_version": daemon_version, "daemon_os": daemon_os}
        return self._post_with_retry("/telemetry/heartbeat", payload)

    def send_events(self, events: list[TelemetryEvent], tool_name: str) -> tuple[int, int]:
        """Send a batch of TelemetryEvents. Returns (accepted, rejected).

        On network failure, events are appended to the disk offline buffer.
        The buffer is drained before new events on subsequent successful calls.
        """
        if not events:
            return 0, 0

        # Drain disk buffer first (best-effort)
        self._flush_disk_buffer(tool_name)

        accepted = rejected = 0
        for chunk in _chunk(events, self._config.batch_size):
            payload = {
                "tool_name": tool_name,
                "daemon_version": "0.1.0",
                "events": [e.to_dict() for e in chunk],
                "session_summaries": [],
            }
            ok = self._post_with_retry("/telemetry/ingest", payload)
            if ok:
                accepted += len(chunk)
            else:
                rejected += len(chunk)
                self._append_to_disk_buffer(chunk, tool_name)

        return accepted, rejected

    def health_check(self) -> bool:
        """Return True when the API health endpoint is reachable."""
        try:
            r = self._client.get("/telemetry/health", timeout=5.0)
            return r.status_code == 200
        except Exception:
            return False

    def _post_with_retry(self, path: str, payload: dict) -> bool:
        for attempt, delay in enumerate(_RETRY_DELAYS):
            try:
                r = self._client.post(path, json=payload)
                if r.status_code in (200, 202):
                    return True
                if r.status_code in (400, 401, 403, 422):
                    # Non-retryable client errors
                    logger.error("API error %d for %s: %s", r.status_code, path, r.text[:200])
                    return False
                logger.warning(
                    "API returned %d for %s (attempt %d), retrying in %.0fs",
                    r.status_code, path, attempt + 1, delay,
                )
            except httpx.RequestError as e:
                logger.warning(
                    "Network error %s (attempt %d): %s", path, attempt + 1, e
                )
            if attempt < len(_RETRY_DELAYS) - 1:
                time.sleep(delay)
        return False

    def _append_to_disk_buffer(self, events: list[TelemetryEvent], tool_name: str) -> None:
        """Append failed events to the disk offline buffer (JSONL, capped at 10 MB)."""
        self._buffer_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            current_size = self._buffer_path.stat().st_size if self._buffer_path.exists() else 0
        except OSError:
            current_size = 0

        lines = []
        for e in events:
            record = {"tool_name": tool_name, "event": e.to_dict()}
            lines.append(json.dumps(record, separators=(",", ":")))

        new_bytes = "\n".join(lines) + "\n"
        if current_size + len(new_bytes.encode()) > _MAX_DISK_BUFFER_BYTES:
            logger.warning(
                "Offline buffer at limit (%d MB); %d events dropped",
                _MAX_DISK_BUFFER_BYTES // (1024 * 1024),
                len(events),
            )
            return

        try:
            with open(self._buffer_path, "a", encoding="utf-8") as f:
                f.write(new_bytes)
            logger.info("Buffered %d events to disk (%s)", len(events), self._buffer_path)
        except OSError as e:
            logger.error("Failed to write offline buffer: %s", e)

    def _flush_disk_buffer(self, tool_name: str) -> None:
        """Replay the disk buffer. On success, delete the buffer file."""
        if not self._buffer_path.exists():
            return

        try:
            lines = self._buffer_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return

        if not lines:
            self._buffer_path.unlink(missing_ok=True)
            return

        logger.info("Flushing %d buffered events from disk", len(lines))
        failed: list[str] = []

        for chunk_lines in _chunk(lines, self._config.batch_size):
            events_dicts = []
            chunk_tool = tool_name
            for line in chunk_lines:
                try:
                    record = json.loads(line)
                    chunk_tool = record.get("tool_name", tool_name)
                    events_dicts.append(record["event"])
                except (json.JSONDecodeError, KeyError):
                    continue

            if not events_dicts:
                continue

            payload = {
                "tool_name": chunk_tool,
                "daemon_version": "0.1.0",
                "events": events_dicts,
                "session_summaries": [],
            }
            if not self._post_with_retry("/telemetry/ingest", payload):
                failed.extend(chunk_lines)

        if failed:
            # Rewrite only the failed lines
            try:
                self._buffer_path.write_text("\n".join(failed) + "\n", encoding="utf-8")
            except OSError as e:
                logger.error("Failed to rewrite offline buffer: %s", e)
        else:
            self._buffer_path.unlink(missing_ok=True)
            logger.info("Disk buffer flushed and cleared")

    def close(self) -> None:
        self._client.close()


def _chunk(lst: list, size: int):
    for i in range(0, len(lst), size):
        yield lst[i : i + size]
