"""Configuration management for the preto daemon.

Config lives at ~/.preto/config.yaml (mode 600).
Provides typed access and safe read/write helpers.
"""

from __future__ import annotations

import os
import stat
import tempfile
from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG_PATH = Path.home() / ".preto" / "config.yaml"
DEFAULT_SYNC_STATE_PATH = Path.home() / ".preto" / "sync_state.yaml"
_DEFAULT_LOG_PATH = Path.home() / ".preto" / "daemon.log"

_DEFAULTS: dict[str, Any] = {
    "api_url": "https://api.preto.ai/api/v1",
    "api_key": "",
    "workspace_id": "",
    "tools": {
        "claude_code": {
            "enabled": True,
            "plan": "",
            "billing_mode": "",
            "log_path": str(Path.home() / ".claude" / "projects"),
        },
        "codex": {
            "enabled": False,
            "plan": "",
            "billing_mode": "",
            "log_path": str(Path.home() / ".codex"),
        },
        "aider": {
            "enabled": False,
            "log_path": None,
        },
    },
    "prompt_logging": False,
    "batch_size": 50,
    "batch_interval_seconds": 30,
    "initial_lookback_days": 7,
    "max_buffer_size": 1000,
    "auto_start": True,
    "log_path": str(_DEFAULT_LOG_PATH),
}


class Config:
    """Typed wrapper around the YAML config file."""

    def __init__(self, path: Path = DEFAULT_CONFIG_PATH) -> None:
        self._path = path
        self._data: dict[str, Any] = {}
        self._load()

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def api_key(self) -> str:
        return self._data.get("api_key", "")

    @property
    def api_url(self) -> str:
        return self._data.get("api_url", _DEFAULTS["api_url"])

    @property
    def workspace_id(self) -> str:
        return self._data.get("workspace_id", "")

    @property
    def prompt_logging(self) -> bool:
        return bool(self._data.get("prompt_logging", False))

    @property
    def batch_size(self) -> int:
        return int(self._data.get("batch_size", _DEFAULTS["batch_size"]))

    @property
    def batch_interval_seconds(self) -> int:
        return int(self._data.get("batch_interval_seconds", _DEFAULTS["batch_interval_seconds"]))

    @property
    def initial_lookback_days(self) -> int:
        return int(self._data.get("initial_lookback_days", _DEFAULTS["initial_lookback_days"]))

    @property
    def max_buffer_size(self) -> int:
        return int(self._data.get("max_buffer_size", _DEFAULTS["max_buffer_size"]))

    @property
    def auto_start(self) -> bool:
        return bool(self._data.get("auto_start", True))

    @property
    def log_path(self) -> Path:
        return Path(self._data.get("log_path", str(_DEFAULT_LOG_PATH)))

    def tool_enabled(self, tool_name: str) -> bool:
        return bool(self._data.get("tools", {}).get(tool_name, {}).get("enabled", False))

    def tool_log_path(self, tool_name: str) -> Path | None:
        raw = self._data.get("tools", {}).get(tool_name, {}).get("log_path")
        return Path(raw).expanduser() if raw else None

    def tool_plan(self, tool_name: str) -> str:
        return self._data.get("tools", {}).get(tool_name, {}).get("plan", "")

    def tool_billing_mode(self, tool_name: str) -> str:
        return self._data.get("tools", {}).get(tool_name, {}).get("billing_mode", "")

    def get(self, key: str) -> Any:
        """Dotted-key accessor (e.g. 'tools.claude_code.enabled')."""
        parts = key.split(".")
        node: Any = self._data
        for part in parts:
            if not isinstance(node, dict):
                return None
            node = node.get(part)
        return node

    def set(self, key: str, value: Any) -> None:
        """Dotted-key setter. Saves config to disk."""
        parts = key.split(".")
        node = self._data
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = value
        self._save()

    # ------------------------------------------------------------------
    # Load / save
    # ------------------------------------------------------------------

    def _load(self) -> None:
        if self._path.exists():
            with open(self._path) as f:
                loaded = yaml.safe_load(f) or {}
            # Deep merge with defaults
            self._data = _deep_merge(_DEFAULTS.copy(), loaded)
        else:
            self._data = _DEFAULTS.copy()

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        # Atomic write via tempfile + os.replace
        fd, tmp = tempfile.mkstemp(dir=self._path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w") as f:
                yaml.safe_dump(self._data, f, default_flow_style=False, sort_keys=False)
            os.replace(tmp, self._path)
            os.chmod(self._path, stat.S_IRUSR | stat.S_IWUSR)  # 600
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def write_defaults(self) -> None:
        """Write a fresh default config to disk (used during `preto init`)."""
        self._data = _DEFAULTS.copy()
        self._save()

    def is_configured(self) -> bool:
        """Return True when api_key is non-empty.

        workspace_id is resolved server-side from the API key and is not
        required to be stored client-side for the daemon to operate.
        """
        return bool(self.api_key)


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base (override wins on scalar conflicts)."""
    result = base.copy()
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result
