"""python -m preto entrypoint."""

from preto.cli import main

main()
