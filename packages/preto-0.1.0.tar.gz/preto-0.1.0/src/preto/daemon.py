"""Preto daemon — main watch loop.

Watches tool log directories for new/modified files using watchdog.
On each change, re-reads from the last synced byte offset and ships
new events to the API via PretoClient.
"""

from __future__ import annotations

import logging
import signal
import sys
import time
from pathlib import Path
from threading import Event as ThreadEvent

from preto import __version__
from preto.config import Config
from preto.parsers.aider import AiderParser
from preto.parsers.claude_code import ClaudeCodeParser
from preto.parsers.codex import CodexParser
from preto.sync import PretoClient, SyncState

logger = logging.getLogger(__name__)

_POLL_INTERVAL = 5  # seconds (watchdog + polling fallback)


class Daemon:
    """Orchestrates file watching and telemetry shipping for all configured tools."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.sync_state = SyncState()
        self.client = PretoClient(config)
        self._stop_event = ThreadEvent()
        self._parsers = self._build_parsers()

    def _build_parsers(self) -> list:
        parsers = []
        if self.config.tool_enabled("claude_code"):
            log_path = self.config.tool_log_path("claude_code")
            if log_path and log_path.exists():
                parsers.append(
                    ClaudeCodeParser(
                        log_root=log_path,
                        plan_type=self.config.tool_plan("claude_code"),
                        billing_mode=self.config.tool_billing_mode("claude_code"),
                    )
                )
            else:
                logger.warning("Claude Code log path not found: %s", log_path)

        if self.config.tool_enabled("codex"):
            log_path = self.config.tool_log_path("codex")
            if log_path and log_path.exists():
                parsers.append(
                    CodexParser(
                        log_root=log_path,
                        plan_type=self.config.tool_plan("codex"),
                        billing_mode=self.config.tool_billing_mode("codex"),
                    )
                )

        if self.config.tool_enabled("aider"):
            logger.info("Aider support is not yet implemented — skipping.")

        return parsers

    def start(self) -> None:
        """Start the daemon watch loop (blocking)."""
        logger.info("Preto daemon %s starting (tools: %s)", __version__, [p.tool_name for p in self._parsers])

        # Register SIGTERM / SIGINT
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

        # Initial heartbeat
        self.client.send_heartbeat(__version__, sys.platform)

        # Attempt watchdog event-driven watching; fall back to polling
        try:
            self._run_watchdog()
        except ImportError:
            logger.warning("watchdog not available; falling back to polling")
            self._run_polling()

    def _run_watchdog(self) -> None:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        class _Handler(FileSystemEventHandler):
            def __init__(self, daemon: Daemon) -> None:
                self._daemon = daemon

            def on_modified(self, event):
                if not event.is_directory and event.src_path.endswith(".jsonl"):
                    self._daemon._process_changed_file(Path(event.src_path))

            def on_created(self, event):
                if not event.is_directory and event.src_path.endswith(".jsonl"):
                    self._daemon._process_changed_file(Path(event.src_path))

        observer = Observer()
        for parser in self._parsers:
            if parser.log_root.exists():
                observer.schedule(_Handler(self), str(parser.log_root), recursive=True)
                logger.info("Watching %s for %s", parser.log_root, parser.tool_name)

        observer.start()
        heartbeat_interval = 300  # 5 minutes
        last_heartbeat = time.time()

        try:
            while not self._stop_event.is_set():
                self._stop_event.wait(timeout=_POLL_INTERVAL)
                # Periodic heartbeat
                if time.time() - last_heartbeat >= heartbeat_interval:
                    self.client.send_heartbeat(__version__, sys.platform)
                    last_heartbeat = time.time()
        finally:
            observer.stop()
            observer.join()
            self.client.close()

    def _run_polling(self) -> None:
        """Fallback: scan all log files every _POLL_INTERVAL seconds."""
        heartbeat_interval = 300
        last_heartbeat = time.time()

        while not self._stop_event.is_set():
            for parser in self._parsers:
                for path in parser.log_paths():
                    self._process_changed_file(path, parser=parser)

            if time.time() - last_heartbeat >= heartbeat_interval:
                self.client.send_heartbeat(__version__, sys.platform)
                last_heartbeat = time.time()

            self._stop_event.wait(timeout=_POLL_INTERVAL)

        self.client.close()

    def _process_changed_file(self, path: Path, parser=None) -> tuple[int, int]:
        """Parse new lines from a changed file and ship events.

        Returns (accepted, rejected) counts.
        """
        if parser is None:
            parser = self._find_parser_for(path)
        if parser is None:
            return 0, 0

        offset = self.sync_state.get_offset(path)

        # Detect file truncation/rotation: if file is shorter than our offset, reset.
        try:
            stat = path.stat()
            if stat.st_size < offset:
                logger.info("File truncated or rotated: %s — resetting offset", path.name)
                offset = 0
        except OSError:
            return 0, 0

        events = []
        try:
            for event_or_none, new_offset in parser.parse_file(path, start_offset=offset):
                if event_or_none is not None:
                    events.append(event_or_none)
                offset = new_offset
        except NotImplementedError:
            return 0, 0
        except Exception:
            logger.exception("Parse error in %s", path)
            return 0, 0

        accepted = rejected = 0
        if events:
            accepted, rejected = self.client.send_events(events, tool_name=parser.tool_name)
            logger.info(
                "Shipped %d/%d events from %s (rejected=%d)",
                accepted, len(events), path.name, rejected,
            )

        # Only checkpoint after successful parse+send attempt
        self.sync_state.set_offset(path, offset)
        return accepted, rejected

    def _find_parser_for(self, path: Path):
        """Return the parser whose log_root is an ancestor of path."""
        for parser in self._parsers:
            try:
                path.relative_to(parser.log_root)
                return parser
            except ValueError:
                continue
        return None

    def sync_now(self) -> dict[str, int]:
        """Force an immediate sync of all parser files. Returns accepted/rejected counts."""
        total_accepted = total_rejected = 0
        for parser in self._parsers:
            for path in parser.log_paths():
                accepted, rejected = self._process_changed_file(path, parser=parser)
                total_accepted += accepted
                total_rejected += rejected
        return {"accepted": total_accepted, "rejected": total_rejected}

    def stop(self) -> None:
        self._stop_event.set()

    def _handle_signal(self, signum, frame) -> None:
        logger.info("Received signal %s — stopping daemon", signum)
        self.stop()
