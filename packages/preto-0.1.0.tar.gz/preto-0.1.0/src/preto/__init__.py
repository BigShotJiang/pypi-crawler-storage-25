"""Preto daemon — passive telemetry collection for AI coding tools."""

__version__ = "0.1.0"
