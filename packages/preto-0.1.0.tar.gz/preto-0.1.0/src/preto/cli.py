"""Preto daemon CLI — argparse-based command interface.

Commands:
  init           Interactive setup wizard
  start          Start daemon in background
  stop           Stop background daemon
  status         Show daemon and tool connection status
  sync           Force-sync all tool logs immediately
  login          Authenticate with the preto API
  logout         Remove stored credentials
  daemon-run     Run daemon in foreground (used internally by auto-start)
  config get [key]        Print config value
  config set <key> <val>  Set a config value
  uninstall      Remove daemon and all config/state files
"""

from __future__ import annotations

import argparse
import getpass
import logging
import sys
from pathlib import Path

from preto import __version__
from preto.config import Config


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(0)

    # Configure logging
    level = logging.DEBUG if getattr(args, "verbose", False) else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    args.func(args)


# ---------------------------------------------------------------------------
# Parser construction
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="preto",
        description="Preto — AI coding tool telemetry daemon",
    )
    p.add_argument("--version", action="version", version=f"preto {__version__}")
    p.add_argument("-v", "--verbose", action="store_true", help="Verbose output")

    sub = p.add_subparsers(dest="command")

    sub.add_parser("init", help="Interactive setup wizard")
    sub.add_parser("start", help="Start daemon in background")
    sub.add_parser("stop", help="Stop background daemon")
    sub.add_parser("status", help="Show daemon status")
    sub.add_parser("sync", help="Force-sync all tool logs now")
    sub.add_parser("login", help="Authenticate with the preto API")
    sub.add_parser("logout", help="Remove stored credentials")
    sub.add_parser("daemon-run", help="Run daemon in foreground (internal)")

    uninstall = sub.add_parser("uninstall", help="Remove daemon and all data")
    uninstall.add_argument("--yes", action="store_true", help="Skip confirmation")

    config_cmd = sub.add_parser("config", help="Read or write config values")
    config_sub = config_cmd.add_subparsers(dest="config_action")
    cfg_get = config_sub.add_parser("get", help="Get a config value")
    cfg_get.add_argument("key", nargs="?", help="Dotted key (e.g. tools.claude_code.enabled)")
    cfg_set = config_sub.add_parser("set", help="Set a config value")
    cfg_set.add_argument("key", help="Dotted key")
    cfg_set.add_argument("value", help="New value")

    # Bind handlers
    for name, fn in [
        ("init", cmd_init),
        ("start", cmd_start),
        ("stop", cmd_stop),
        ("status", cmd_status),
        ("sync", cmd_sync),
        ("login", cmd_login),
        ("logout", cmd_logout),
        ("daemon-run", cmd_daemon_run),
        ("uninstall", cmd_uninstall),
        ("config", cmd_config),
    ]:
        action = sub.choices.get(name)
        if action:
            action.set_defaults(func=fn)

    return p


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------


def cmd_init(args: argparse.Namespace) -> None:
    """Interactive setup wizard."""
    print(f"Preto daemon {__version__} — setup wizard\n")

    config = Config()

    if config.is_configured():
        print(f"  Already configured (api_key: ...{config.api_key[-8:]})")
        redo = input("  Re-configure? [y/N] ").strip().lower()
        if redo != "y":
            print("Keeping existing configuration.")
            return

    print(
        "  Get your API key at https://app.preto.ai/settings/api-keys\n"
    )
    api_key = input("  Paste your API key (pk_live_...): ").strip()
    if not api_key.startswith("pk_live_") and not api_key.startswith("pk_test_"):
        print("  Warning: key doesn't look like a preto API key — saving anyway.")

    config.set("api_key", api_key)

    print("\n  Which AI coding tools do you use?")
    for tool, label in [("claude_code", "Claude Code"), ("codex", "Codex CLI"), ("aider", "Aider")]:
        ans = input(f"    Enable {label}? [Y/n] ").strip().lower()
        config.set(f"tools.{tool}.enabled", ans != "n")

    print("\n  Retroactive import: scanning existing logs for the last 7 days...")
    _retroactive_import(config)

    print("\nSetup complete! Run `preto start` to begin.")


def _retroactive_import(config: Config) -> None:
    """Scan existing log files and upload historical events."""
    from preto.parsers.claude_code import ClaudeCodeParser
    from preto.sync import PretoClient, SyncState

    client = PretoClient(config)
    if not client.health_check():
        print("  Warning: API unreachable — skipping retroactive import.")
        return

    sync_state = SyncState()

    if config.tool_enabled("claude_code"):
        log_path = config.tool_log_path("claude_code")
        if log_path and log_path.exists():
            parser = ClaudeCodeParser(
                log_root=log_path,
                plan_type=config.tool_plan("claude_code"),
                billing_mode=config.tool_billing_mode("claude_code"),
            )
            files = parser.log_paths()
            print(f"  Found {len(files)} Claude Code session files")
            total = 0
            for path in files:
                events = []
                offset = sync_state.get_offset(path)
                for ev, new_offset in parser.parse_file(path, start_offset=offset):
                    if ev is not None:
                        events.append(ev)
                    offset = new_offset
                if events:
                    accepted, _ = client.send_events(events, "claude_code")
                    sync_state.set_offset(path, offset)
                    total += accepted
            print(f"  Imported {total} Claude Code events")

    client.close()


def cmd_start(args: argparse.Namespace) -> None:
    """Start daemon in background."""
    from preto import platform as pl

    msg = pl.start_background()
    print(msg)


def cmd_stop(args: argparse.Namespace) -> None:
    """Stop background daemon."""
    from preto import platform as pl

    msg = pl.stop_background()
    print(msg)


def cmd_status(args: argparse.Namespace) -> None:
    """Print daemon and tool status."""
    from preto import platform as pl

    config = Config()
    running = pl.is_running()
    configured = config.is_configured()

    print(f"Preto daemon {__version__}")
    print(f"  Status:     {'running' if running else 'stopped'}")
    print(f"  Configured: {'yes' if configured else 'no (run preto init)'}")
    print()
    print("  Tool status:")
    for tool, label in [("claude_code", "Claude Code"), ("codex", "Codex"), ("aider", "Aider")]:
        enabled = config.tool_enabled(tool)
        if tool == "aider":
            note = "coming soon"
        elif tool == "codex":
            note = "partial support"
        else:
            note = "full support"
        print(f"    {label}: {'enabled' if enabled else 'disabled'} ({note})")


def cmd_sync(args: argparse.Namespace) -> None:
    """Force-sync all tool logs immediately."""
    from preto.config import Config
    from preto.daemon import Daemon

    config = Config()
    if not config.is_configured():
        print("Not configured. Run `preto init` first.")
        sys.exit(1)

    d = Daemon(config)
    counts = d.sync_now()
    print(f"Sync complete — accepted: {counts['accepted']}, rejected: {counts['rejected']}")


def cmd_login(args: argparse.Namespace) -> None:
    """Authenticate with the preto API."""
    print("Preto login — paste your API key from https://app.preto.ai/settings/api-keys")
    api_key = getpass.getpass("API key: ").strip()
    config = Config()
    config.set("api_key", api_key)
    print("API key saved.")


def cmd_logout(args: argparse.Namespace) -> None:
    """Remove stored API key."""
    config = Config()
    config.set("api_key", "")
    print("API key removed.")


def cmd_daemon_run(args: argparse.Namespace) -> None:
    """Run the daemon in the foreground (called by LaunchAgent / systemd)."""
    from preto.config import Config
    from preto.daemon import Daemon

    config = Config()
    if not config.is_configured():
        print("Not configured. Run `preto init` first.", file=sys.stderr)
        sys.exit(1)

    d = Daemon(config)
    d.start()


def cmd_uninstall(args: argparse.Namespace) -> None:
    """Remove daemon, auto-start config, and all preto data."""
    from preto import platform as pl
    import shutil

    if not getattr(args, "yes", False):
        confirm = input("Remove all preto data (~/.preto/)? [y/N] ").strip().lower()
        if confirm != "y":
            print("Aborted.")
            return

    pl.stop_background()
    pl.uninstall_autostart()

    preto_dir = Path.home() / ".preto"
    if preto_dir.exists():
        shutil.rmtree(preto_dir)
        print(f"Removed {preto_dir}")

    print("Preto uninstalled.")


def cmd_config(args: argparse.Namespace) -> None:
    """Get or set config values."""
    config = Config()
    action = getattr(args, "config_action", None)

    if action == "get":
        key = getattr(args, "key", None)
        if key:
            print(config.get(key))
        else:
            import yaml
            import io
            buf = io.StringIO()
            yaml.safe_dump(config._data, buf, default_flow_style=False)
            print(buf.getvalue())

    elif action == "set":
        key = args.key
        value = args.value
        # Attempt type coercion
        if value.lower() == "true":
            value = True
        elif value.lower() == "false":
            value = False
        else:
            try:
                value = int(value)
            except ValueError:
                try:
                    value = float(value)
                except ValueError:
                    pass
        config.set(key, value)
        print(f"Set {key} = {value!r}")
    else:
        print("Usage: preto config get [key] | preto config set <key> <value>")
