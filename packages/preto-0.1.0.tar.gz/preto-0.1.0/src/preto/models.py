"""Core data classes for preto daemon telemetry."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class TelemetryEvent:
    """One LLM request captured from a tool's log files."""

    event_id: str
    session_id: str
    source: str = "daemon"
    timestamp: datetime = field(default_factory=datetime.utcnow)
    model: str = ""
    provider: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    context_tokens_at_turn: int = 0
    turn_number: int = 0
    files_read: list[str] = field(default_factory=list)
    files_written: list[str] = field(default_factory=list)
    commands_run: list[str] = field(default_factory=list)
    plan_type: str = ""
    billing_mode: str = ""
    is_compaction: bool = False
    pre_compaction_tokens: int = 0
    prompt_content: str | None = None
    completion_content: str | None = None
    project_path_hash: str = ""
    git_branch: str = ""

    def to_dict(self) -> dict:
        """Serialise to JSON-compatible dict for HTTP transmission."""
        return {
            "event_id": self.event_id,
            "session_id": self.session_id,
            "source": self.source,
            "timestamp": self.timestamp.isoformat() + "Z",
            "model": self.model,
            "provider": self.provider,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "cache_write_tokens": self.cache_write_tokens,
            "context_tokens_at_turn": self.context_tokens_at_turn,
            "turn_number": self.turn_number,
            "files_read": self.files_read,
            "files_written": self.files_written,
            "commands_run": self.commands_run,
            "plan_type": self.plan_type,
            "billing_mode": self.billing_mode,
            "is_compaction": self.is_compaction,
            "pre_compaction_tokens": self.pre_compaction_tokens,
            "prompt_content": self.prompt_content,
            "completion_content": self.completion_content,
            "project_path_hash": self.project_path_hash,
            "git_branch": self.git_branch,
        }


@dataclass
class SessionSummary:
    """Aggregated stats for a completed session."""

    session_id: str
    tool_name: str
    started_at: datetime
    ended_at: datetime
    total_turns: int
    total_tokens: int
    total_cost_usd: float = 0.0
    plan_type: str = ""
    billing_mode: str = ""

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "tool_name": self.tool_name,
            "started_at": self.started_at.isoformat() + "Z",
            "ended_at": self.ended_at.isoformat() + "Z",
            "total_turns": self.total_turns,
            "total_tokens": self.total_tokens,
            "total_cost_usd": self.total_cost_usd,
            "plan_type": self.plan_type,
            "billing_mode": self.billing_mode,
        }
