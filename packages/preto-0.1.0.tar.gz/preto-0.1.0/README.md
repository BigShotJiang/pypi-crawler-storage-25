# preto daemon

Passive telemetry daemon for AI coding tools (Claude Code, Codex CLI, Aider).
Reads local tool logs and ships usage data to [Preto](https://preto.ai) for cost tracking and analytics.

## Install

```bash
pip install preto
```

## Usage

```bash
preto init     # connect your API key and configure tools
preto start    # start the background daemon
preto status   # check daemon status
preto stop     # stop the daemon
```

For Cursor users: change your base URL to `proxy.preto.ai` in Cursor settings — no daemon needed.

## Requirements

- Python 3.10+
- A [Preto](https://app.preto.ai) account and API key
