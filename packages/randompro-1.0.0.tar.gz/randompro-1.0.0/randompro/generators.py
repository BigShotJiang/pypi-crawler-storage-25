"""
randompro - Generadores de Numeros Pseudoaleatorios
Metodos: Cuadrado Medio, Congruencia Lineal
Seed por defecto: reloj del procesador (time.time_ns)
"""

import time

def _default_seed() -> int:
    """Seed basado en el reloj del procesador (nanosegundos)."""
    return time.time_ns()

# -------------------------

# Metodo 1: Cuadrado Medio (Middle Square Method) - Von Neumann (1946)

# -------------------------

class CuadradoMedio:
    """
    Generador de numeros pseudoaleatorios usando el Metodo del Cuadrado Medio.

    Algoritmo:

    Tomar la semilla X0 de d digitos.
    Elevarla al cuadrado -> X0^2
    Extraer los d digitos del centro -> X1
    Repetir con Xn


    Parametros
    ----------
    seed : int, opcional
        Semilla inicial. Por defecto usa el reloj del procesador.
    digits : int
        Numero de digitos a usar (entre 2 y 10). Por defecto 6.
    """

    def __init__(self, seed: int = None, digits: int = 6):
        if digits < 2 or digits > 10:
            raise ValueError("digits debe estar entre 2 y 10")
        self.digits = digits
        self._modulus = 10 ** digits
        self._current = (seed if seed is not None else _default_seed()) % self._modulus
        # Garantizar que la semilla tenga exactamente 'digits' digitos
        if self._current == 0:
            self._current = 1

    def _next_raw(self) -> int:
        """Devuelve el siguiente valor entero del generador."""
        squared = self._current ** 2
        squared_str = str(squared).zfill(self.digits * 2)
        # Extraer digitos del centro
        start = (len(squared_str) - self.digits) // 2
        middle = int(squared_str[start: start + self.digits])
        self._current = middle
        return self._current

    def random(self) -> float:
        """
        Genera un numero pseudoaleatorio en [0, 1).

        Returns
        -------
        float
        """
        return self._next_raw() / self._modulus

    def randint(self, a: int, b: int) -> int:
        """
        Genera un entero pseudoaleatorio en [a, b].

        Parameters
        ----------
        a : int  Limite inferior (inclusivo)
        b : int  Limite superior (inclusivo)
        """
        if a > b:
            raise ValueError("a debe ser <= b")
        return a + int(self.random() * (b - a + 1))

    def sample(self, n: int) -> list:
        """
        Genera una lista de n numeros en [0, 1).

        Parameters
        ----------
        n : int  Cantidad de numeros a generar
        """
        return [self.random() for _ in range(n)]

    def reset(self, seed: int = None):
        """Reinicia el generador con una nueva semilla (o el reloj)."""
        self._current = (seed if seed is not None else _default_seed()) % self._modulus
        if self._current == 0:
            self._current = 1

    @property
    def state(self) -> int:
        """Estado interno actual del generador."""
        return self._current

    def __repr__(self):
        return (f"CuadradoMedio(digits={self.digits}, state={self._current})")

# -------------------------

# Metodo 2: Congruencia Lineal (Linear Congruential Generator - LCG)

# -------------------------

class CongruenciaLineal:
    """
    Generador de numeros pseudoaleatorios usando Congruencia Lineal.

    Formula:
        Xn+1 = (a * Xn + c) mod m

    Donde:
        m = modulo          (m > 0)
        a = multiplicador   (0 < a < m)
        c = incremento      (0 <= c < m)
        X0 = semilla

    Parametros por defecto (ANSI C / Numerical Recipes):
        m = 2^32  = 4,294,967,296
        a = 1664525
        c = 1013904223

    Parametros
    ----------
    seed : int, opcional
        Semilla inicial. Por defecto usa el reloj del procesador.
    m : int
        Modulo. Por defecto 2^32.
    a : int
        Multiplicador. Por defecto 1664525.
    c : int
        Incremento. Por defecto 1013904223.
    """

    # Constantes clasicas (ANSI C)
    _DEFAULT_M = 2 ** 32
    _DEFAULT_A = 1_664_525
    _DEFAULT_C = 1_013_904_223

    def __init__(
        self,
        seed: int = None,
        m: int = _DEFAULT_M,
        a: int = _DEFAULT_A,
        c: int = _DEFAULT_C,
    ):
        if m <= 0:
            raise ValueError("m debe ser > 0")
        if not (0 < a < m):
            raise ValueError("a debe cumplir 0 < a < m")
        if not (0 <= c < m):
            raise ValueError("c debe cumplir 0 <= c < m")

        self.m = m
        self.a = a
        self.c = c
        self._current = (seed if seed is not None else _default_seed()) % m

    def _next_raw(self) -> int:
        """Calcula el siguiente valor: Xn+1 = (a*Xn + c) mod m"""
        self._current = (self.a * self._current + self.c) % self.m
        return self._current

    def random(self) -> float:
        """
        Genera un numero pseudoaleatorio en [0, 1).

        Returns
        -------
        float
        """
        return self._next_raw() / self.m

    def randint(self, a: int, b: int) -> int:
        """
        Genera un entero pseudoaleatorio en [a, b].

        Parameters
        ----------
        a : int  Limite inferior (inclusivo)
        b : int  Limite superior (inclusivo)
        """
        if a > b:
            raise ValueError("a debe ser <= b")
        return a + int(self.random() * (b - a + 1))

    def sample(self, n: int) -> list:
        """
        Genera una lista de n numeros en [0, 1).

        Parameters
        ----------
        n : int  Cantidad de numeros a generar
        """
        return [self.random() for _ in range(n)]

    def reset(self, seed: int = None):
        """Reinicia el generador con una nueva semilla (o el reloj)."""
        self._current = (seed if seed is not None else _default_seed()) % self.m

    @property
    def state(self) -> int:
        """Estado interno actual del generador."""
        return self._current

    def __repr__(self):
        return (
            f"CongruenciaLineal("
            f"m={self.m}, a={self.a}, c={self.c}, state={self._current})"
        )
