"""
randompro - Libreria de generadores de numeros pseudoaleatorios.

Metodos disponibles:
    CuadradoMedio      : Metodo del Cuadrado Medio (Von Neumann)
    CongruenciaLineal  : Metodo de Congruencia Lineal (LCG)
"""

from .generators import CuadradoMedio, CongruenciaLineal

__all__ = ["CuadradoMedio", "CongruenciaLineal"]
__version__ = "1.0.0"
__author__ = "Juan"
