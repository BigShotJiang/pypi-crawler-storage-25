#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import subprocess
import sys
import tempfile
import tomllib
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Validate esspy release metadata and local distribution artifacts."
    )
    parser.add_argument("--dist-dir", default="dist", help="Distribution directory")
    parser.add_argument(
        "--install-test",
        action="store_true",
        help="Install the newest matching wheel into a temporary venv and run smoke checks",
    )
    parser.add_argument(
        "--strict-dist",
        action="store_true",
        help="Fail if legacy ess_python artifacts remain in dist/",
    )
    args = parser.parse_args(argv)

    pyproject = _load_pyproject()
    project = pyproject["project"]
    name = project["name"]
    version = project["version"]
    _check(name == "esspy", f"project.name must be `esspy`, got `{name}`")
    _check(_read_runtime_version() == version, "pyproject version and esspy._version differ")
    _check("spglib>=2.0" in project["dependencies"], "base dependencies must include spglib")
    _check("mpi" in project.get("optional-dependencies", {}), "optional dependency group `mpi` missing")

    dist_dir = ROOT / args.dist_dir
    wheels = sorted(dist_dir.glob(f"esspy-{version}-*.whl"))
    sdists = sorted(dist_dir.glob(f"esspy-{version}.tar.gz"))
    legacy = sorted(dist_dir.glob("ess_python-*"))
    _check(sdists, f"missing sdist: esspy-{version}.tar.gz")
    _check(wheels, f"missing wheel: esspy-{version}-*.whl")
    if legacy:
        message = "legacy ess_python artifacts present: " + ", ".join(path.name for path in legacy)
        if args.strict_dist:
            raise SystemExit(f"[ERROR] {message}")
        print(f"[WARN] {message}")

    for wheel in wheels:
        _check_wheel_contains_native(wheel)

    _run([sys.executable, "-m", "twine", "check", *map(str, sdists + wheels)])

    if args.install_test:
        _install_smoke_test(wheels[-1])

    print("[OK] release artifacts look consistent")
    return 0


def _load_pyproject() -> dict:
    with (ROOT / "pyproject.toml").open("rb") as handle:
        return tomllib.load(handle)


def _read_runtime_version() -> str:
    path = ROOT / "python" / "esspy" / "_version.py"
    spec = importlib.util.spec_from_file_location("_esspy_version_check", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return str(module.__version__)


def _check(condition, message: str) -> None:
    if not condition:
        raise SystemExit(f"[ERROR] {message}")


def _check_wheel_contains_native(wheel: Path) -> None:
    with zipfile.ZipFile(wheel) as archive:
        names = archive.namelist()
    has_native = any(
        name.startswith("esspy/_esspy") and (name.endswith(".so") or name.endswith(".pyd"))
        for name in names
    )
    _check(has_native, f"{wheel.name} does not contain esspy/_esspy native extension")


def _install_smoke_test(wheel: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="esspy-wheel-smoke-") as tmp:
        venv_dir = Path(tmp) / "venv"
        _run([sys.executable, "-m", "venv", str(venv_dir)])
        python = venv_dir / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
        esspy = venv_dir / ("Scripts/esspy.exe" if sys.platform == "win32" else "bin/esspy")
        _run([str(python), "-m", "pip", "install", "--upgrade", "pip"])
        _run([str(python), "-m", "pip", "install", str(wheel)])
        _run([str(esspy), "doctor"])
        _run([str(esspy), "util", "doctor-native"])
        _run([str(python), "-c", "import esspy; print(esspy.__version__)"])


def _run(command: list[str]) -> None:
    print("+ " + " ".join(command))
    subprocess.run(command, cwd=ROOT, check=True)


if __name__ == "__main__":
    raise SystemExit(main())
