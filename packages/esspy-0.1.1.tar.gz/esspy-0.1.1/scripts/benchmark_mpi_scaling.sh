#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <input.yaml> [work_root]"
  exit 1
fi

INPUT_YAML="$1"
WORK_ROOT="${2:-mpi-scaling-bench}"
NP_LIST=(2 4 8)
CSV_PATH="${WORK_ROOT}/scaling_summary.csv"

mkdir -p "$WORK_ROOT"
echo "np,elapsed_sec,global_count,best_e,worst_e,active_ranks,idle_ranks,imbalance_ratio,summary_path" > "$CSV_PATH"

echo "input: $INPUT_YAML"
echo "work_root: $WORK_ROOT"
echo

for NP in "${NP_LIST[@]}"; do
  RUN_DIR="${WORK_ROOT}/np${NP}"
  LOG="${RUN_DIR}.log"
  mkdir -p "$RUN_DIR"
  rm -rf "${RUN_DIR}/run-output" "${RUN_DIR}"/run-output-NEW*

  echo "=== np=${NP} ==="
  START_TS="$(date +%s)"
  (
    cd "$RUN_DIR"
    mpirun -n "$NP" esspy run "$INPUT_YAML"
  ) >"$LOG" 2>&1
  END_TS="$(date +%s)"
  ELAPSED="$((END_TS - START_TS))"

  SUMMARY="$(find "$RUN_DIR" -maxdepth 2 -name '*summary*.json' | head -n 1 || true)"
  if [[ -z "${SUMMARY}" ]]; then
    echo "np=${NP}: summary not found"
    continue
  fi

  python - "$NP" "$ELAPSED" "$SUMMARY" "$CSV_PATH" <<'PY'
import json
import sys
np = int(sys.argv[1])
elapsed = int(sys.argv[2])
summary_path = sys.argv[3]
csv_path = sys.argv[4]
with open(summary_path) as f:
    payload = json.load(f)
solve = payload.get("solve", {}) or {}
mpi = solve.get("mpi", {}) or {}
global_count = solve.get("global_count_total")
best = solve.get("global_e_min")
worst = solve.get("global_e_max")
active = mpi.get("active_ranks")
idle = mpi.get("idle_ranks")
imbalance = mpi.get("imbalance_ratio_max_over_avg")
print(
    f"np={np} elapsed_sec={elapsed} "
    f"global_count={global_count} "
    f"best={best} worst={worst} "
    f"active={active} idle={idle} "
    f"imbalance={imbalance}"
)
with open(csv_path, "a", encoding="utf-8") as out:
    out.write(
        f"{np},{elapsed},{global_count},{best},{worst},{active},{idle},{imbalance},{summary_path}\n"
    )
PY
done

echo
echo "done. logs under: $WORK_ROOT"
echo "csv: $CSV_PATH"
