from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .native_extract import parse_add_sites_monte_carlo_spec_native


@dataclass
class NeighborKindSpec:
    kind: str
    doxidation: float
    dist_min: float
    dist_max: float


@dataclass
class AddedKindSpec:
    kind: str
    n_added: int
    oxidation: float
    neighbor_kinds: list[NeighborKindSpec]


@dataclass
class AddSitesMonteCarloSpec:
    present: bool
    n_add_kind: int
    add_meshes: tuple[float, float, float]
    min_distance_between_added_sites: float
    n_monte_carlo: int
    monte_carlo_monitor_index: int
    added_kinds: list[AddedKindSpec]


def parse_add_sites_monte_carlo_spec(path: str | Path) -> AddSitesMonteCarloSpec:
    payload = parse_add_sites_monte_carlo_spec_native(path)
    return AddSitesMonteCarloSpec(
        present=bool(payload["present"]),
        n_add_kind=int(payload["n_add_kind"]),
        add_meshes=tuple(float(value) for value in payload["add_meshes"]),
        min_distance_between_added_sites=float(
            payload["min_distance_between_added_sites"]
        ),
        n_monte_carlo=int(payload["n_monte_carlo"]),
        monte_carlo_monitor_index=int(payload["monte_carlo_monitor_index"]),
        added_kinds=[
            AddedKindSpec(
                kind=str(item["kind"]),
                n_added=int(item["n_added"]),
                oxidation=float(item["oxidation"]),
                neighbor_kinds=[
                    NeighborKindSpec(
                        kind=str(neighbor["kind"]),
                        doxidation=float(neighbor["doxidation"]),
                        dist_min=float(neighbor["dist_min"]),
                        dist_max=float(neighbor["dist_max"]),
                    )
                    for neighbor in item["neighbor_kinds"]
                ],
            )
            for item in payload["added_kinds"]
        ],
    )
