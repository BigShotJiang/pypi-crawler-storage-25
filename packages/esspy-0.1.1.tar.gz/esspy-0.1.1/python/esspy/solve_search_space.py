from __future__ import annotations

from dataclasses import asdict, is_dataclass

from .models import (
    CompositionEntry,
    Lattice,
    ReadyAtom,
    ReadyModel,
    ReadyRecipe,
    ReadyRecipeModification,
    SearchSpaceEntry,
    SearchSpaceSummary,
)
from .native import load_native_module


def _to_ready_payload(ready: ReadyModel | dict) -> dict:
    if is_dataclass(ready):
        payload = asdict(ready)
        payload["output_prefix"] = payload.pop("output_prefix")
        for recipe in payload["recipes"]:
            recipe["from"] = recipe.pop("from_kind")
        return payload
    return ready


def analyze_search_space(ready: ReadyModel | dict) -> SearchSpaceSummary:
    native = load_native_module()
    data = native.analyze_search_space(_to_ready_payload(ready))

    return SearchSpaceSummary(
        entries=[
            SearchSpaceEntry(
                from_kind=item["from"],
                random_pickup=item["random_pickup"],
                random_pickup_trial=item["random_pickup_trial"],
                unchanged_count=item["unchanged_count"],
                assigned_counts=[
                    CompositionEntry(kind=entry["kind"], count=entry["count"])
                    for entry in item["assigned_counts"]
                ],
                jobsize_u64=item["jobsize_u64"],
                jobsize_ld=item["jobsize_ld"],
                first_candidate_indices=item["first_candidate_indices"],
                first_candidate_labels=item["first_candidate_labels"],
                candidate_count_log10=item["candidate_count_log10"],
                jobsize_saturated=bool(item.get("jobsize_saturated", False)),
            )
            for item in data["entries"]
        ],
        primary_recipe_index=data["primary_recipe_index"],
        total_candidate_count_log10=data["total_candidate_count_log10"],
    )
