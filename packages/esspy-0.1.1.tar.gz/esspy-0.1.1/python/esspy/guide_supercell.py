from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from .models import Lattice
from .native import load_native_module


@dataclass
class SupercellExpansionResult:
    expansion: tuple[int, int, int]
    expanded_n_atom_config: int
    log: list[str]


def _lattice_payload(lattice: Lattice | Mapping[str, Sequence[float]]) -> dict:
    if isinstance(lattice, Lattice):
        return {"a": list(lattice.a), "b": list(lattice.b), "c": list(lattice.c)}
    return {
        "a": list(lattice["a"]),
        "b": list(lattice["b"]),
        "c": list(lattice["c"]),
    }


def compute_supercell_expansion(
    lattice: Lattice | Mapping[str, Sequence[float]],
    n_atom_config: int,
    n_target_sites: int,
) -> SupercellExpansionResult:
    """Run the Guider supercell-expansion search via the native library.

    This is the typed Python entry point that mirrors the original Guider's
    NTargetSites-driven supercell sizing logic. The actual computation is
    performed in C++; this wrapper is responsible only for marshalling
    arguments and converting the returned dictionary into a typed result.
    """

    native = load_native_module()
    payload = native.compute_supercell_expansion(
        _lattice_payload(lattice), int(n_atom_config), int(n_target_sites)
    )
    expansion = tuple(int(value) for value in payload["expansion"])
    if len(expansion) != 3:
        raise ValueError("Native compute_supercell_expansion returned an invalid expansion")
    return SupercellExpansionResult(
        expansion=expansion,  # type: ignore[arg-type]
        expanded_n_atom_config=int(payload["expanded_n_atom_config"]),
        log=[str(line) for line in payload["log"]],
    )
