from __future__ import annotations


def annotate_solve_strategy_inline_comments(yaml_text: str) -> str:
    """Add inline comments to solve.strategy lines in a dumped YAML text.

    This keeps YAML fully valid while improving readability of generated
    `input.yaml` files.
    """
    replacements = {
        "  target_cpu_time_sec: ": "  target_cpu_time_sec: ",
        "  n_random_seeds: ": "  n_random_seeds: ",
        "    target_cpu_time_sec: ": "    target_cpu_time_sec: ",
        "    n_random_seeds: ": "    n_random_seeds: ",
        "  backend: ": "  backend: ",
        "  symprec: ": "  symprec: ",
        "  write_wyc_path: ": "  write_wyc_path: ",
        "  space_group: ": "  space_group: ",
        "    mode: ": "    mode: ",  # keep key exact for indentation check
        "    time_budget_sec: ": "    time_budget_sec: ",
        "    effort: ": "    effort: ",
        "      enabled: ": "      enabled: ",
        "      max_steps: ": "      max_steps: ",
    }
    comments = {
        "  target_cpu_time_sec: ": "  # guider target CPU time in seconds",
        "  n_random_seeds: ": "  # guider random seed count",
        "    target_cpu_time_sec: ": "  # guider target CPU time in seconds",
        "    n_random_seeds: ": "  # guider random seed count",
        "  backend: ": "  # symmetry backend (typically spglib)",
        "  symprec: ": "  # symmetry tolerance for detection",
        "  write_wyc_path: ": "  # output path for detected WYC operations",
        "  space_group: ": "  # fixed space group number (used with mode=p1)",
        "    mode: ": "  # adaptive | bounded_exhaustive | exhaustive",
        "    time_budget_sec: ": "  # used when mode=adaptive (default 600)",
        "    effort: ": "  # low | medium | high | extreme",
        "      enabled: ": "  # true to run swap optimization",
        "      max_steps: ": "  # maximum accepted/improving swap steps",
    }

    lines = yaml_text.splitlines()
    out_lines: list[str] = []
    in_charges = False
    in_charges_elements = False
    in_charges_element_node = False
    in_allocation = False
    in_symmetry = False
    charges_elements_header_annotated = False
    charges_elements_default_annotated = False
    charges_elements_by_site_annotated = False
    for line in lines:
        updated = line
        indent = len(updated) - len(updated.lstrip(" "))

        # Track simple YAML context for charges block to attach precise inline comments.
        if indent == 0 and updated.startswith("charges:"):
            in_charges = True
            in_charges_elements = False
            in_charges_element_node = False
            charges_elements_header_annotated = False
            charges_elements_default_annotated = False
            charges_elements_by_site_annotated = False
            in_allocation = False
            in_symmetry = False
        elif indent == 0 and updated.startswith("allocation:"):
            in_allocation = True
            in_symmetry = False
            in_charges = False
            in_charges_elements = False
            in_charges_element_node = False
        elif indent == 0 and updated.startswith("symmetry:"):
            in_symmetry = True
            in_allocation = False
            in_charges = False
            in_charges_elements = False
            in_charges_element_node = False
        elif indent == 0 and updated.endswith(":") and not updated.startswith("charges:"):
            in_charges = False
            in_charges_elements = False
            in_charges_element_node = False
            in_allocation = updated.startswith("allocation:")
            in_symmetry = updated.startswith("symmetry:")
        elif in_charges:
            if indent == 2 and updated.startswith("  elements:"):
                in_charges_elements = True
                in_charges_element_node = False
            elif indent == 2 and updated.endswith(":") and not updated.startswith("  elements:"):
                in_charges_elements = False
                in_charges_element_node = False
            elif in_charges_elements and indent == 4 and updated.rstrip().endswith(":"):
                in_charges_element_node = True
            elif in_charges_elements and indent <= 2:
                in_charges_element_node = False

        if in_symmetry and "#" not in updated and updated.startswith("  mode: "):
            updated += "  # symmetry mode: auto | p1"

        for prefix in replacements:
            if updated.startswith(prefix) and "#" not in updated:
                updated = updated + comments[prefix]
                break
        # Additional inline comments for unified charge schema.
        if in_charges and "#" not in updated:
            if updated.startswith("  basis: "):
                updated += "  # element | element_site"
            elif updated.startswith("  values:"):
                updated += "  # element-level charges (fallback/default)"
            elif updated.startswith("  elements:"):
                updated += "  # hierarchical site-aware charge map"
            elif (
                in_charges_elements
                and updated.startswith("      default: ")
                and not charges_elements_default_annotated
            ):
                updated += "  # fallback charge for this element"
                charges_elements_default_annotated = True
            elif (
                in_charges_elements
                and updated.startswith("      by_site:")
                and not charges_elements_by_site_annotated
            ):
                updated += "  # per-site overrides for this element"
                charges_elements_by_site_annotated = True
            elif (
                in_charges_elements
                and in_charges_element_node
                and indent == 4
                and updated.rstrip().endswith(":")
                and not charges_elements_header_annotated
            ):
                updated += "  # element key"
                charges_elements_header_annotated = True
        elif in_allocation and "#" not in updated and updated.startswith("  time_budget_sec: "):
            updated += "  # seconds for site allocation search"
        elif in_allocation and "#" not in updated and updated.startswith("  rough_parallel: "):
            updated += "  # allocation rough stage: rank_local | all_ranks"
        elif in_allocation and "#" not in updated and updated.startswith("  beam_width: "):
            updated += "  # number of elite candidates kept per refinement round"
        elif in_allocation and "#" not in updated and updated.startswith("  beam_rounds: "):
            updated += "  # number of local refinement rounds after random trials"
        elif in_allocation and "#" not in updated and updated.startswith("  n_alloc_feasible_target: "):
            updated += "  # stop early when feasible candidates reach this count"
        elif in_allocation and "#" not in updated and updated.startswith("  n_alloc_max_requested: "):
            updated += "  # hard cap on attempted candidate evaluations"

        out_lines.append(updated)
    return "\n".join(out_lines) + ("\n" if yaml_text.endswith("\n") else "")
