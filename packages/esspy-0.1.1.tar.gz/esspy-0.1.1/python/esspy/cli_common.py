from __future__ import annotations

import argparse
import json
import sys
from typing import Any

import yaml

_PATCHED = False


def enable_helpful_argparse_errors() -> None:
    global _PATCHED
    if _PATCHED:
        return

    def _patched_error(self, message):
        self.print_help(sys.stderr)
        self.exit(2, f"\nArgument issue: {message}\n")

    argparse.ArgumentParser.error = _patched_error
    _PATCHED = True


def print_result(args: argparse.Namespace, payload: Any) -> None:
    """Print payload according to CLI flags.
    
    If `--json` is present, prints raw JSON.
    Otherwise, prints a human-readable YAML representation, suppressing
    output entirely if `--quiet` is true.
    """
    if _mpi_rank() != 0:
        return

    if getattr(args, "json", False):
        print(json.dumps(payload))
        return
        
    if getattr(args, "quiet", False):
        return

    if _looks_like_run_summary(payload):
        print(_format_run_summary(payload, verbose=getattr(args, "verbose", False)))
        return

    print(yaml.dump(payload, default_flow_style=False, sort_keys=False))


def _mpi_rank() -> int:
    from .mpi_context import mpi_rank

    return mpi_rank()


def _looks_like_run_summary(payload: Any) -> bool:
    return (
        isinstance(payload, dict)
        and "guide" in payload
        and "outputs" in payload
        and "workdir" in payload
    )


def _format_run_summary(payload: dict[str, Any], *, verbose: bool = False) -> str:
    lines: list[str] = []
    guide = payload.get("guide") or {}
    solve = payload.get("solve")
    outputs = payload.get("outputs") or {}
    allocation = payload.get("allocation") or {}
    recommended = payload.get("recommended") or {}
    charge_model = payload.get("charge_model")

    lines.append("")
    lines.append("ESSPY run finished")
    lines.append("==================")
    lines.append(f"Input    : {payload.get('input', '-')}")
    lines.append(f"Workdir  : {payload.get('workdir', '-')}")
    lines.append(f"Mode     : {'guide-only' if payload.get('guide_only') else 'guide + solve'}")
    lines.append("")

    if isinstance(charge_model, dict):
        lines.append("Charge model")
        lines.append("------------")
        source = charge_model.get("source", "-")
        if source == "auto":
            source_text = "auto-loaded charge_model.json"
        elif source == "explicit":
            source_text = "explicit --charge-model"
        else:
            source_text = str(source)
        lines.append(f"Source   : {source_text}")
        lines.append(f"Path     : {charge_model.get('path', '-')}")
        lines.append(f"Entries  : {charge_model.get('loaded_entries', '-')}")
        if charge_model.get("summary"):
            lines.append(f"Charges  : {charge_model.get('summary')}")
        lines.append("Input charges were overridden by this model.")
        lines.append("")

    lines.append("Guide stage")
    lines.append("-----------")
    lines.append(
        "Structure: "
        f"{guide.get('n_atoms', '-')} input sites -> "
        f"{guide.get('n_atom_config', '-')} configured sites, "
        f"supercell={guide.get('supercell_expansion', '-')}, "
        f"RGFindFactor={guide.get('rg_find_factor', '-')}"
    )
    recipes = guide.get("recipes") or []
    if recipes:
        lines.append("Recipes:")
        for index, recipe in enumerate(recipes, start=1):
            modifications = [
                f"{mod.get('to')}:{mod.get('count')}"
                for mod in recipe.get("modifications", [])
                if int(mod.get("count", 0)) != 0
            ]
            mod_text = ", ".join(modifications) if modifications else "fixed/no substitution"
            lines.append(
                f"  {index}. {recipe.get('from')} "
                f"(pickup={recipe.get('random_pickup')}, trial={recipe.get('random_pickup_trial')}) "
                f"-> {mod_text}"
            )
    lines.append("")

    if solve is None:
        lines.append("Solve stage")
        lines.append("-----------")
        lines.append("Skipped because --guide-only was used.")
    else:
        lines.extend(_format_solve_summary(solve, verbose=verbose))
    lines.append("")

    portfolio = payload.get("allocation_portfolio")
    if isinstance(portfolio, dict):
        lines.append("Allocation portfolio")
        lines.append("--------------------")
        lines.append(
            "Optimizer           : "
            f"{portfolio.get('optimizer', 'portfolio_ess')} "
            f"(evaluated={portfolio.get('evaluated_allocations', '-')})"
        )
        lines.append(
            "Best rough ESS score: "
            f"{_fmt_float(portfolio.get('best_score'))} eV"
        )
        if portfolio.get("stop_reason"):
            lines.append(f"Stop reason         : {portfolio.get('stop_reason')}")
        lines.append(
            "Rough ESS settings  : "
            f"{portfolio.get('rough_ess_time_sec', '-')}s, "
            f"max_swap={portfolio.get('rough_max_swap', '-')}, "
            f"parallel={portfolio.get('rough_parallel', 'all_ranks')}"
        )
        port_mpi = portfolio.get("mpi")
        if isinstance(port_mpi, dict) and port_mpi.get("distributed"):
            lines.append(
                "MPI rough workers   : "
                f"world_size={port_mpi.get('world_size', '-')}, "
                f"per_rank={port_mpi.get('per_rank_evaluated', '-')}"
            )
        best_by_site = portfolio.get("best_composition_by_site")
        if isinstance(best_by_site, dict) and best_by_site:
            lines.append(
                "Best site composition: "
                + _format_composition_by_site(best_by_site)
            )
        transfer = portfolio.get("transfer_summary")
        if isinstance(transfer, dict) and transfer.get("summary"):
            lines.append(f"Transfer summary    : {transfer.get('summary')}")
        lines.append("")

    if isinstance(recommended, dict) and recommended.get("poscar"):
        lines.append("Recommended output")
        lines.append("------------------")
        lines.append(f"POSCAR              : {recommended.get('poscar')}")
        if recommended.get("source_poscar"):
            lines.append(f"Source POSCAR       : {recommended.get('source_poscar')}")
        lines.append(f"Source              : {recommended.get('source', '-')}")
        reason = recommended.get("reason")
        if reason:
            lines.append(f"Reason              : {reason}")
        lines.append("")

    lines.append("Artifacts")
    lines.append("---------")
    for key in [
        "summary",
        "log",
        "progress_jsonl",
        "progress_latest",
        "guider",
        "ready",
        "poscar",
        "recommended_poscar",
        "recommended_source_poscar",
        "recommended_structure",
        "final_ess_best_poscar",
        "final_ess_best_structure",
        "final_ess_worst_structure",
        "allocation_search_best_structure",
        "allocation_portfolio_best_structure",
        "best_poscar",
        "worst_poscar",
        "allocation_best_poscar",
        "allocation_portfolio_best_poscar",
        "allocation_trajectories",
    ]:
        if key in outputs:
            lines.append(f"{key:36}: {outputs[key]}")

    if not verbose and solve and solve.get("messages"):
        lines.append("")
        lines.append("Tip")
        lines.append("---")
        lines.append("Use `--verbose` to print raw native solver messages.")
        if "summary" in outputs:
            lines.append(f"Full machine-readable summary: {outputs['summary']}")
    return "\n".join(lines)


def _fmt_float(value: Any) -> str:
    if isinstance(value, (int, float)):
        return f"{float(value):.6f}"
    return "-"


def _format_composition_by_site(value: dict[str, Any]) -> str:
    chunks: list[str] = []
    for site in sorted(value.keys()):
        row = value.get(site)
        if not isinstance(row, dict):
            continue
        items = " ".join(
            f"{kind}={row[kind]}"
            for kind in sorted(row.keys())
            if int(row.get(kind, 0)) != 0
        )
        chunks.append(f"{site}[{items}]")
    return " | ".join(chunks)


def _format_solve_summary(solve: dict[str, Any], *, verbose: bool) -> list[str]:
    lines: list[str] = []
    e_min = solve.get("global_e_min")
    e_max = solve.get("global_e_max")
    spread = None
    if isinstance(e_min, (int, float)) and isinstance(e_max, (int, float)):
        spread = e_max - e_min

    lines.append("Solve stage")
    lines.append("-----------")
    lines.append(f"Evaluated candidates : {solve.get('global_count_total', '-')}")
    lines.append(f"Energy table count   : {solve.get('energy_table_count', '-')}")
    lines.append(f"Best energy          : {_fmt_float(e_min)} eV")
    lines.append(f"Worst energy         : {_fmt_float(e_max)} eV")
    if spread is not None:
        lines.append(f"Energy spread        : {_fmt_float(spread)} eV")
    lines.append(f"Local candidates     : {solve.get('local_processed_candidates', '-')}")
    swap_count = solve.get("global_swap_count", solve.get("local_swap_count", "-"))
    swap_delta = solve.get("global_de_min_swap", solve.get("local_de_min_swap"))
    lines.append(
        "Swap result          : "
        f"{swap_count} accepted swaps, "
        f"ΔE={_fmt_float(swap_delta)} eV"
    )
    mpi_stats = solve.get("mpi") if isinstance(solve, dict) else None
    if isinstance(mpi_stats, dict) and int(mpi_stats.get("world_size", 1)) > 1:
        lines.append("")
        lines.append("MPI stats")
        lines.append("---------")
        lines.append(
            f"Active/idle ranks    : {mpi_stats.get('active_ranks', '-')}/"
            f"{mpi_stats.get('idle_ranks', '-')}"
        )
        lines.append(
            f"Per-rank processed   : min={mpi_stats.get('min_processed_candidates', '-')}, "
            f"max={mpi_stats.get('max_processed_candidates', '-')}, "
            f"avg={_fmt_float(mpi_stats.get('avg_processed_candidates'))}"
        )
        lines.append(
            f"Load imbalance       : max/avg={_fmt_float(mpi_stats.get('imbalance_ratio_max_over_avg'))}"
        )

    messages = [str(message) for message in solve.get("messages", [])]
    highlights = _solver_highlights(messages)
    if highlights:
        lines.append("")
        lines.append("Solver highlights")
        lines.append("-----------------")
        lines.extend(f"- {line}" for line in highlights)

    if verbose and messages:
        lines.append("")
        lines.append("Raw native solver messages")
        lines.append("--------------------------")
        lines.extend(f"- {message}" for message in messages)
    return lines


def _solver_highlights(messages: list[str]) -> list[str]:
    highlights: list[str] = []
    for message in messages:
        if "legacy_adaptive_running_index=true" in message:
            highlights.append(message.replace("[SOLVE] ", ""))
        elif "adaptive_running_index_update" in message:
            highlights.append(message.replace("[SOLVE] ", ""))
        elif "enumeration_incremental_mEwald=true" in message:
            highlights.append("incremental mEwald evaluator was used")
        elif "enumeration_mEwald_diff_evaluations=" in message:
            highlights.append(message.replace("[SOLVE] enumeration_", ""))
        elif "swap_loop_enabled=true" in message:
            highlights.append(message.replace("[SOLVE] ", ""))
        elif "swap_seeded_from_external=true" in message:
            highlights.append("swap loop started from allocation portfolio best")
        elif "swap_seed_source=3" in message:
            highlights.append(message.replace("[SOLVE] ", ""))
        elif "swap_stopped_by_no_improvement=true" in message:
            highlights.append("swap stopped because no improving swap remained")
    return highlights[:12]


def _fmt_float(value: Any) -> str:
    if not isinstance(value, (int, float)):
        return "-"
    return f"{float(value):.10f}"
