from __future__ import annotations

from dataclasses import dataclass
import glob
import json
import math
import os
from pathlib import Path
import re
import textwrap
import time
from typing import Any, Callable, Iterable

import numpy as np
import yaml

from .models import (
    CompositionEntry,
    ReadyAtom,
    ReadyModel,
    ReadyRecipe,
    ReadyRecipeModification,
    SolveInput,
    SolveOptions,
)
from .poscar import load_poscar
from .workflow import solve


@dataclass(frozen=True)
class DatasetEntry:
    structure_path: Path
    dft_energy_eV: float
    weight: float = 1.0


_OUTCAR_ENERGY_RE = re.compile(r"energy\s+without entropy=\s*([-0-9.]+)")
_TRAILING_ID_RE = re.compile(r"(\d+)(?!.*\d)")
_SITE_LABEL_RE = re.compile(r"#\s*(site-\d+)\s*$", re.IGNORECASE)
_SITE_NAME_RE = re.compile(r"site[-_]?(\d+)$", re.IGNORECASE)


_BUILTIN_CHARGE_GUESS: dict[str, float] = {
    "Mn": 2.0,
    "Cr": 3.0,
    "Ni": 2.0,
    "Rh": 3.0,
    "Co": 2.0,
    "Fe": 3.0,
    "Mo": 6.0,
    "Mg": 2.0,
    "O": -2.0,
    "N": -3.0,
}


def _expand_path_inputs(inputs: list[str]) -> list[Path]:
    paths: list[Path] = []
    seen: set[Path] = set()
    for raw in inputs:
        matches = [Path(item) for item in glob.glob(raw)]
        # Handle literal brackets in parent paths (e.g. .../[RESEARCH]/...).
        if not matches and os.sep in raw:
            raw_path = Path(raw)
            parent_text = str(raw_path.parent)
            name_text = raw_path.name
            escaped_parent = glob.escape(parent_text)
            escaped_raw = f"{escaped_parent}{os.sep}{name_text}"
            matches = [Path(item) for item in glob.glob(escaped_raw)]
        if not matches:
            raw_path = Path(raw)
            has_glob = any(ch in raw for ch in "*?[]")
            if has_glob:
                raise FileNotFoundError(f"No files matched pattern: {raw}")
            if not raw_path.exists():
                raise FileNotFoundError(f"File not found: {raw_path}")
            matches = [raw_path]
        for item in matches:
            resolved = item.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            paths.append(resolved)
    return sorted(paths)


def _extract_id(path: Path) -> str:
    match = _TRAILING_ID_RE.search(path.name)
    if not match:
        raise ValueError(
            f"Could not extract numeric id from filename `{path.name}`. "
            "Expected names like sample-001.vasp / OUTCAR-sample-001.vasp."
        )
    return match.group(1)


def _read_outcar_energy(path: Path) -> float:
    last_energy: float | None = None
    for line in path.read_text(errors="ignore").splitlines():
        match = _OUTCAR_ENERGY_RE.search(line)
        if match:
            last_energy = float(match.group(1))
    if last_energy is None:
        raise ValueError(f"Could not parse `energy without entropy=` from {path}")
    return last_energy


def _normalize_site_name(site: str) -> str:
    text = str(site).strip()
    match = _SITE_NAME_RE.fullmatch(text)
    if match:
        return f"site-{int(match.group(1)):03d}"
    return text


def _normalize_charge_key(key: str) -> str:
    text = str(key).strip()
    if "@" not in text:
        return text
    elem, site = text.split("@", 1)
    return f"{elem.strip()}@{_normalize_site_name(site)}"


def _flatten_charge_defaults_from_input(path: str | Path | None) -> dict[str, float]:
    if path is None:
        return {}
    input_path = Path(path).expanduser()
    if not input_path.exists():
        raise FileNotFoundError(f"Input YAML not found: {input_path}")
    payload = yaml.safe_load(input_path.read_text()) or {}
    if not isinstance(payload, dict):
        raise ValueError("Input YAML root must be a mapping")

    out: dict[str, float] = {}

    def add(key: str, value: Any) -> None:
        if isinstance(value, bool):
            raise ValueError(f"Charge for `{key}` must be numeric, got boolean")
        try:
            out[_normalize_charge_key(key)] = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Charge for `{key}` must be numeric") from exc

    charges = payload.get("charges")
    if isinstance(charges, dict):
        values = charges.get("values")
        if isinstance(values, dict):
            for elem, value in values.items():
                add(str(elem), value)

        elements = charges.get("elements")
        if isinstance(elements, dict):
            for elem, node in elements.items():
                if not isinstance(node, dict):
                    continue
                if "default" in node:
                    add(str(elem), node["default"])
                by_site = node.get("by_site")
                if isinstance(by_site, dict):
                    for site, value in by_site.items():
                        add(f"{elem}@{site}", value)

        legacy_by_site = charges.get("by_site")
        if isinstance(legacy_by_site, dict):
            for key, value in legacy_by_site.items():
                add(str(key), value)

        reserved = {
            "basis",
            "mode",
            "values",
            "elements",
            "by_site",
            "model",
            "fitted_model",
        }
        for key, value in charges.items():
            if str(key) in reserved:
                continue
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                add(str(key), value)

    top_level_by_site = payload.get("charges_by_site")
    if isinstance(top_level_by_site, dict):
        for key, value in top_level_by_site.items():
            add(str(key), value)

    return out


def _charge_guess_for_kind(kind: str, guesses: dict[str, float]) -> float:
    key = _normalize_charge_key(kind)
    if key in guesses:
        return float(guesses[key])
    elem = str(kind).split("@", 1)[0].strip()
    if elem in guesses:
        return float(guesses[elem])
    return 1.0


def _charge_bounds_for_initial(value: float) -> tuple[float, float]:
    q = float(value)
    if q < -1.0e-12:
        lower = min(-4.5, q * 2.0, q - 2.0)
        upper = -0.05
        return (lower, upper)
    if q > 1.0e-12:
        lower = 0.05
        upper = max(4.5, q * 2.0, q + 2.0)
        return (lower, upper)
    return (-4.5, 4.5)


def build_dataset_from_patterns(
    poscar_inputs: list[str],
    outcar_inputs: list[str],
    *,
    strict: bool = True,
) -> tuple[list[DatasetEntry], dict]:
    poscar_paths = _expand_path_inputs(poscar_inputs)
    outcar_paths = _expand_path_inputs(outcar_inputs)

    poscar_by_id: dict[str, Path] = {}
    for path in poscar_paths:
        sid = _extract_id(path)
        if sid in poscar_by_id:
            raise ValueError(
                f"Duplicate POSCAR id `{sid}` from `{poscar_by_id[sid]}` and `{path}`"
            )
        poscar_by_id[sid] = path

    outcar_by_id: dict[str, Path] = {}
    for path in outcar_paths:
        sid = _extract_id(path)
        if sid in outcar_by_id:
            raise ValueError(
                f"Duplicate OUTCAR id `{sid}` from `{outcar_by_id[sid]}` and `{path}`"
            )
        outcar_by_id[sid] = path

    poscar_ids = set(poscar_by_id)
    outcar_ids = set(outcar_by_id)
    common_ids = sorted(poscar_ids & outcar_ids, key=lambda value: int(value))
    missing_poscar = sorted(outcar_ids - poscar_ids, key=lambda value: int(value))
    missing_outcar = sorted(poscar_ids - outcar_ids, key=lambda value: int(value))

    if strict and (missing_poscar or missing_outcar):
        raise ValueError(
            "POSCAR/OUTCAR id mismatch. "
            f"missing_poscar_ids={missing_poscar}, missing_outcar_ids={missing_outcar}"
        )

    entries: list[DatasetEntry] = []
    for sid in common_ids:
        entries.append(
            DatasetEntry(
                structure_path=poscar_by_id[sid],
                dft_energy_eV=_read_outcar_energy(outcar_by_id[sid]),
                weight=1.0,
            )
        )

    if not entries:
        raise ValueError("No matched POSCAR/OUTCAR pairs after id matching.")

    meta = {
        "matched_ids": common_ids,
        "missing_poscar_ids": missing_poscar,
        "missing_outcar_ids": missing_outcar,
        "poscar_files": [str(path) for path in poscar_paths],
        "outcar_files": [str(path) for path in outcar_paths],
    }
    return entries, meta


def write_dataset_file(entries: list[DatasetEntry], path: str | Path) -> Path:
    out_path = Path(path).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    base_dir = out_path.parent
    lines = ["# structure_path energy_eV [weight]"]
    for entry in entries:
        try:
            struct_text = str(entry.structure_path.relative_to(base_dir))
        except ValueError:
            struct_text = str(entry.structure_path)
        if abs(entry.weight - 1.0) < 1e-12:
            lines.append(f"{struct_text} {entry.dft_energy_eV:.11f}")
        else:
            lines.append(f"{struct_text} {entry.dft_energy_eV:.11f} {entry.weight:.6g}")
    out_path.write_text("\n".join(lines) + "\n")
    return out_path


def _split_charge_key(key: str) -> tuple[str, str | None]:
    text = str(key).strip()
    if "@" not in text:
        return text, None
    elem, site = text.split("@", 1)
    elem = elem.strip()
    site = site.strip()
    return elem, site or None


def _format_charge_value(value: float) -> str:
    return f"{float(value):.12g}"


def format_charge_title_segment(
    charges: dict[str, float],
    *,
    kind_order: Iterable[str] | None = None,
) -> str:
    """Return a compact POSCAR-title `charges:` segment.

    Site-aware keys are intentionally preserved as `Mn@site-001=...` so
    `esspy ewald` can reconstruct per-site charges from coordinate comments.
    """
    seen: set[str] = set()
    ordered_keys: list[str] = []
    if kind_order is not None:
        for key in kind_order:
            text = str(key).strip()
            if text and text in charges and text not in seen:
                ordered_keys.append(text)
                seen.add(text)

    def _sort_key(key: str) -> tuple[str, str, str]:
        elem, site = _split_charge_key(key)
        return (elem, site or "", key)

    for key in sorted((str(k).strip() for k in charges), key=_sort_key):
        if key and key not in seen:
            ordered_keys.append(key)
            seen.add(key)

    pairs = [f"{key}={_format_charge_value(float(charges[key]))}" for key in ordered_keys]
    return "charges: " + " ".join(pairs)


def update_poscar_charge_titles(
    paths: Iterable[str | Path],
    charges: dict[str, float],
    *,
    kind_order: Iterable[str] | None = None,
    rg_find_factor: int | None = None,
) -> list[Path]:
    """Replace/add the POSCAR title-line charge segment for each path.

    Existing non-charge title fragments are preserved. Existing `charges:` and
    `RG=` fragments are replaced so repeated `esspy fc` runs are idempotent.
    """
    charge_segment = format_charge_title_segment(charges, kind_order=kind_order)
    written: list[Path] = []
    seen: set[Path] = set()
    for raw_path in paths:
        path = Path(raw_path).resolve()
        if path in seen:
            continue
        seen.add(path)
        lines = path.read_text().splitlines()
        if not lines:
            continue

        fragments = [part.strip() for part in lines[0].split("|")]
        kept = [
            part
            for part in fragments
            if part
            and not part.startswith("charges:")
            and not part.startswith("RG=")
        ]
        if not kept:
            kept = [path.stem]
        kept.append(charge_segment)
        if rg_find_factor is not None:
            kept.append(f"RG={int(rg_find_factor)}")
        else:
            for part in fragments:
                part = part.strip()
                if part.startswith("RG="):
                    kept.append(part)
                    break
        lines[0] = " | ".join(kept)
        path.write_text("\n".join(lines) + "\n")
        written.append(path)
    return written


def write_parity_plot(report: dict, path: str | Path) -> Path:
    out_path = Path(path).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:
        raise RuntimeError(
            "fit-charge parity plot requires matplotlib. Install with: pip install matplotlib"
        ) from exc

    rows = report.get("rows", [])
    if not rows:
        raise ValueError("Cannot draw parity plot: report has no rows")

    x = np.array([float(row["dft_delta_eV"]) for row in rows], dtype=float)
    y_mapped = np.array([float(row["pred_delta_eV"]) for row in rows], dtype=float)
    map_mode = str(report.get("config", {}).get("map_mode", "linear")).strip().lower()
    mapped_label = (
        "Calibrated Ewald (offset only)" if map_mode == "bias_only" else "Calibrated Ewald (scale+offset)"
    )
    has_baseline = all("baseline_pred_delta_eV" in row for row in rows)
    y_baseline = (
        np.array([float(row["baseline_pred_delta_eV"]) for row in rows], dtype=float)
        if has_baseline
        else None
    )

    lo_candidates = [np.min(x), np.min(y_mapped)]
    hi_candidates = [np.max(x), np.max(y_mapped)]
    if y_baseline is not None:
        lo_candidates.append(np.min(y_baseline))
        hi_candidates.append(np.max(y_baseline))
    lo = float(min(lo_candidates))
    hi = float(max(hi_candidates))
    pad = 0.05 * (hi - lo + 1e-12)
    lo -= pad
    hi += pad

    fig = plt.figure(figsize=(10.2, 6.6), dpi=180)
    gs = fig.add_gridspec(nrows=1, ncols=2, width_ratios=[3.4, 2.1], wspace=0.10)
    ax = fig.add_subplot(gs[0, 0])
    info_ax = fig.add_subplot(gs[0, 1])
    fig.patch.set_facecolor("white")
    ax.set_facecolor("#fcfcfd")
    info_ax.set_facecolor("white")
    info_ax.axis("off")
    calibrated_color = "#8b0000"
    default_color = "#0b3d91"

    ax.scatter(
        x,
        y_mapped,
        s=36,
        alpha=0.90,
        marker="o",
        color=calibrated_color,
        edgecolors="white",
        linewidths=0.3,
        label=mapped_label,
    )
    if y_baseline is not None:
        ax.scatter(
            x,
            y_baseline,
            s=44,
            alpha=0.90,
            marker="x",
            color=default_color,
            linewidths=1.1,
            label="Default charge (mapped)",
        )
    fit_line_x = np.array([lo, hi], dtype=float)
    fit_trend = np.polyfit(x, y_mapped, deg=1)
    fit_line_y = fit_trend[0] * fit_line_x + fit_trend[1]
    ax.plot(
        fit_line_x,
        fit_line_y,
        color=calibrated_color,
        linewidth=1.6,
        alpha=0.95,
        label="Calibrated trend",
    )
    if y_baseline is not None:
        base_trend = np.polyfit(x, y_baseline, deg=1)
        base_line_y = base_trend[0] * fit_line_x + base_trend[1]
        ax.plot(
            fit_line_x,
            base_line_y,
            color=default_color,
            linewidth=1.5,
            alpha=0.9,
            linestyle="-.",
            label="Default trend",
        )
    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("DFT relative energy, ΔE_DFT (eV)")
    ax.set_ylabel("Ewald-side relative energy (eV)")
    ax.set_title("Parity Plot: DFT vs Ewald", fontsize=12, pad=10)
    metrics = report.get("metrics", {})
    baseline_metrics = report.get("baseline", {}).get("metrics", {})
    fit_pearson = metrics.get("pearson_after_linear_map")
    if fit_pearson is None:
        fit_pearson = _pearson(x, y_mapped)
    default_pearson = baseline_metrics.get("pearson_after_linear_map")
    if default_pearson is None and y_baseline is not None:
        default_pearson = _pearson(x, y_baseline)
    if default_pearson is None:
        default_pearson = float("nan")

    fit_text = (
        f"Fit RMSE={float(metrics.get('rmse_after_linear_map', float('nan'))):.4f} eV\n"
        f"Fit MAE={float(metrics.get('mae_after_linear_map', float('nan'))):.4f} eV\n"
        f"Fit Pearson r={float(fit_pearson):.4f}"
    )
    default_text = (
        f"Default RMSE={float(baseline_metrics.get('rmse_after_linear_map', float('nan'))):.4f} eV\n"
        f"Default MAE={float(baseline_metrics.get('mae_after_linear_map', float('nan'))):.4f} eV\n"
        f"Default Pearson r={float(default_pearson):.4f}"
    )
    charge_order = report.get("kind_order", [])
    fit_charge_map = report.get("charges", {})
    default_charge_map = report.get("baseline", {}).get("charges", {})
    fit_charge_text = ", ".join(
        f"{k}={float(fit_charge_map[k]):.3f}" for k in charge_order if k in fit_charge_map
    )
    default_charge_text = ", ".join(
        f"{k}={float(default_charge_map[k]):.3f}" for k in charge_order if k in default_charge_map
    )
    site_charge_summary = report.get("site_charge_summary", {})
    charge_lines = ["Charges"]
    if isinstance(site_charge_summary, dict) and site_charge_summary:
        for site_name in sorted(site_charge_summary.keys()):
            row = site_charge_summary.get(site_name, {})
            if not isinstance(row, dict):
                continue
            pairs = ", ".join(
                f"{elem}={float(val):.3f}" for elem, val in sorted(row.items())
            )
            wrapped = textwrap.wrap(f"{site_name}: {pairs}", width=50)
            if wrapped:
                charge_lines.extend(wrapped)
            else:
                charge_lines.append(f"{site_name}:")
    else:
        for kind in charge_order:
            if kind in fit_charge_map or kind in default_charge_map:
                fit_val = (
                    f"{float(fit_charge_map[kind]):.3f}" if kind in fit_charge_map else "-"
                )
                default_val = (
                    f"{float(default_charge_map[kind]):.3f}" if kind in default_charge_map else "-"
                )
                charge_lines.append(f"{kind:>2}: calib {fit_val:>7} | default {default_val:>7}")
    charge_text = "\n".join(charge_lines)
    info_ax.text(
        0.02,
        0.98,
        "Calibrated model\n" + fit_text.replace("Fit ", ""),
        va="top",
        ha="left",
        fontsize=9.2,
        color=calibrated_color,
        linespacing=1.35,
        fontweight="semibold",
        family="Helvetica",
    )
    info_ax.text(
        0.02,
        0.70,
        "Default model\n" + default_text.replace("Default ", ""),
        va="top",
        ha="left",
        fontsize=9.2,
        color=default_color,
        linespacing=1.35,
        fontweight="semibold",
        family="Helvetica",
    )
    info_ax.text(
        0.02,
        0.32,
        charge_text,
        va="top",
        ha="left",
        fontsize=7.8,
        color="#000000",
        linespacing=1.35,
        family="Helvetica",
        clip_on=False,
    )
    summary_text = (
        f"Data\n"
        f"n_samples={int(report.get('n_samples', len(rows)))}\n"
        f"anchor={report.get('anchor_kind', '-')}\n"
        f"objective={report.get('config', {}).get('objective', '-')}\n"
        f"map_mode={report.get('config', {}).get('map_mode', '-')}"
    )
    info_ax.text(
        0.02,
        0.50,
        summary_text,
        va="top",
        ha="left",
        fontsize=8.5,
        color="#000000",
        linespacing=1.35,
        family="Helvetica",
    )
    ax.legend(loc="lower right", fontsize=8, frameon=True, facecolor="white", edgecolor="#ced4da")
    ax.grid(alpha=0.30, linestyle=":", color="#adb5bd")
    for spine in ax.spines.values():
        spine.set_linewidth(0.8)
        spine.set_color("#adb5bd")
    fig.subplots_adjust(left=0.08, right=0.98, top=0.93, bottom=0.10)
    try:
        fig.savefig(out_path, bbox_inches="tight", pad_inches=0.15)
    finally:
        plt.close(fig)
    return out_path


def write_fixed_model_parity_plot(report: dict, path: str | Path) -> Path:
    out_path = Path(path).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:
        raise RuntimeError(
            "fit-charge parity plot requires matplotlib. Install with: pip install matplotlib"
        ) from exc

    rows = report.get("rows", [])
    if not rows:
        raise ValueError("Cannot draw parity plot: report has no rows")
    x = np.array([float(row["dft_delta_eV"]) for row in rows], dtype=float)
    y = np.array([float(row["pred_delta_eV"]) for row in rows], dtype=float)
    lo = float(min(np.min(x), np.min(y)))
    hi = float(max(np.max(x), np.max(y)))
    pad = 0.05 * (hi - lo + 1e-12)
    lo -= pad
    hi += pad
    metrics = report.get("metrics", {})
    fig, ax = plt.subplots(figsize=(6.2, 5.6), dpi=180)
    ax.scatter(x, y, s=30, alpha=0.9, color="#8b0000", edgecolors="white", linewidths=0.3)
    m, c = np.polyfit(x, y, 1)
    xx = np.array([lo, hi], dtype=float)
    ax.plot(xx, m * xx + c, color="#8b0000", lw=1.6)
    ax.plot(xx, xx, "k--", lw=1.0, alpha=0.55)
    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("DFT relative energy, ΔE_DFT (eV)")
    ax.set_ylabel("Predicted relative energy (fixed charge model) (eV)")
    ax.set_title("Generalization Parity (Fixed charge_model)")
    txt = (
        f"n={len(rows)}\n"
        f"RMSE={float(metrics.get('rmse_after_linear_map', float('nan'))):.4f} eV\n"
        f"MAE={float(metrics.get('mae_after_linear_map', float('nan'))):.4f} eV\n"
        f"Pearson r={float(metrics.get('pearson_after_linear_map', float('nan'))):.4f}"
    )
    ax.text(0.02, 0.98, txt, transform=ax.transAxes, va="top", ha="left", fontsize=9.0)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return out_path


def load_charge_model(path: str | Path) -> dict[str, float]:
    payload = json.loads(Path(path).read_text())
    if not isinstance(payload, dict):
        raise ValueError("charge model JSON must be an object")
    raw = payload.get("charges")
    if not isinstance(raw, dict):
        raise ValueError("charge model v2 must contain `charges` object")
    elements = raw.get("elements")
    if not isinstance(elements, dict):
        raise ValueError("charge model v2 must contain `charges.elements` mapping")
    out: dict[str, float] = {}
    for elem, node in elements.items():
        if not isinstance(node, dict):
            continue
        by_site = node.get("by_site", {})
        if isinstance(by_site, dict) and by_site:
            for site, value in by_site.items():
                out[f"{str(elem).strip()}@{str(site).strip()}"] = float(value)
            continue
        if "default" in node:
            out[str(elem).strip()] = float(node["default"])
    if not out:
        raise ValueError("charge model v2 has no usable charge entries in `charges.elements`")
    return out


def evaluate_fixed_charge_model(
    entries: list[DatasetEntry],
    *,
    charges: dict[str, float],
    rg_find_factor: int = 3,
    chop_level: float = 8.0,
    map_mode: str = "bias_only",
) -> dict:
    solve_options = _solve_options_single_eval()
    dft_energy = np.array([entry.dft_energy_eV for entry in entries], dtype=float)
    dft_delta = dft_energy - np.min(dft_energy)
    is_site_aware = any("@" in str(k) for k in charges.keys())
    ewald_vals: list[float] = []
    for entry in entries:
        labels: list[str] | None = None
        if is_site_aware:
            raw_site_labels = _read_site_group_labels_from_poscar_comment(entry.structure_path)
            if raw_site_labels is None:
                raise ValueError(
                    f"site-aware model requires '# site-xxx' labels: {entry.structure_path}"
                )
            structure = load_poscar(entry.structure_path)
            labels = [f"{s.kind}@{lb}" for s, lb in zip(structure.sites, raw_site_labels)]
        ewald_vals.append(
            _ewald_energy_for_structure(
                entry.structure_path,
                charges,
                rg_find_factor=int(rg_find_factor),
                chop_level=float(chop_level),
                solve_options=solve_options,
                atom_kind_labels=labels,
            )
        )
    ewald = np.array(ewald_vals, dtype=float)
    ewald_delta = ewald - np.min(ewald)
    weights = np.ones_like(dft_delta) / float(len(dft_delta))
    scale, bias, pred = _fit_mapping_weighted(ewald_delta, dft_delta, weights, map_mode)
    rows = []
    for entry, dft_e, dft_de, ew_de, pred_de in zip(entries, dft_energy, dft_delta, ewald_delta, pred):
        rows.append(
            {
                "structure": str(entry.structure_path),
                "dft_energy_eV": float(dft_e),
                "dft_delta_eV": float(dft_de),
                "ewald_delta_eV": float(ew_de),
                "pred_delta_eV": float(pred_de),
                "weight": 1.0,
            }
        )
    rmse = float(np.sqrt(np.mean((dft_delta - pred) ** 2)))
    mae = float(np.mean(np.abs(dft_delta - pred)))
    return {
        "status": "ok",
        "message": "fixed-model evaluation complete",
        "n_samples": len(entries),
        "charges": charges,
        "linear_map": {"scale": float(scale), "bias": float(bias)},
        "metrics": {
            "rmse_no_scale": float(np.sqrt(np.mean((dft_delta - ewald_delta) ** 2))),
            "rmse_after_linear_map": rmse,
            "mae_after_linear_map": mae,
            "pearson_after_linear_map": _pearson(dft_delta, pred),
            "spearman_after_linear_map": _spearman(dft_delta, pred),
            "spearman": _spearman(dft_delta, pred),
        },
        "rows": rows,
        "config": {
            "rg_find_factor": int(rg_find_factor),
            "chop_level": float(chop_level),
            "map_mode": str(map_mode),
            "site_aware_charge_model": bool(is_site_aware),
        },
    }


def parse_dataset_file(path: str | Path) -> list[DatasetEntry]:
    dataset_path = Path(path).resolve()
    base_dir = dataset_path.parent
    entries: list[DatasetEntry] = []

    for line_index, raw in enumerate(dataset_path.read_text().splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) not in (2, 3):
            raise ValueError(
                f"{dataset_path}:{line_index}: expected 2 or 3 columns "
                "(structure_path energy_eV [weight])"
            )
        structure_path = Path(parts[0])
        if not structure_path.is_absolute():
            structure_path = (base_dir / structure_path).resolve()
        if not structure_path.exists():
            raise FileNotFoundError(
                f"{dataset_path}:{line_index}: structure not found: {structure_path}"
            )
        energy = float(parts[1])
        weight = float(parts[2]) if len(parts) == 3 else 1.0
        if weight <= 0.0:
            raise ValueError(
                f"{dataset_path}:{line_index}: weight must be > 0, got {weight}"
            )
        entries.append(
            DatasetEntry(
                structure_path=structure_path,
                dft_energy_eV=energy,
                weight=weight,
            )
        )

    if not entries:
        raise ValueError(f"Dataset is empty: {dataset_path}")
    return entries


def _kind_order_counts(path: Path) -> tuple[list[str], dict[str, int]]:
    structure = load_poscar(path)
    order: list[str] = []
    counts: dict[str, int] = {}
    for site in structure.sites:
        if site.kind not in counts:
            order.append(site.kind)
            counts[site.kind] = 0
        counts[site.kind] += 1
    return order, counts


def _kind_order_counts_from_labels(labels: list[str]) -> tuple[list[str], dict[str, int]]:
    order: list[str] = []
    counts: dict[str, int] = {}
    for label in labels:
        if label not in counts:
            order.append(label)
            counts[label] = 0
        counts[label] += 1
    return order, counts


def _validate_compatible_structures(
    entries: Iterable[DatasetEntry], expected_order: list[str], expected_counts: dict[str, int]
) -> None:
    for entry in entries:
        order, counts = _kind_order_counts(entry.structure_path)
        if order != expected_order:
            raise ValueError(
                f"All structures must have the same species order. "
                f"{entry.structure_path} has {order}, expected {expected_order}."
            )
        if counts != expected_counts:
            raise ValueError(
                f"All structures must have identical composition counts. "
                f"{entry.structure_path} has {counts}, expected {expected_counts}."
            )


def _solve_options_single_eval() -> SolveOptions:
    return SolveOptions(
        swap=False,
        swap_loop_enabled=False,
        max_swap=0,
        local_enumeration_limit=1,
        local_enumeration_max_chunks=1,
        local_enumeration_stride=1,
        running_index_delta=1,
        enumeration_exhaust_all=True,
        enumeration_save_memory=True,
    )


def _ewald_energy_for_structure(
    structure_path: Path,
    charge_by_kind: dict[str, float],
    *,
    rg_find_factor: int,
    chop_level: float,
    solve_options: SolveOptions,
    atom_kind_labels: list[str] | None = None,
) -> float:
    structure = load_poscar(structure_path)
    if atom_kind_labels is not None:
        if len(atom_kind_labels) != len(structure.sites):
            raise ValueError(
                f"atom_kind_labels length mismatch for {structure_path}: "
                f"{len(atom_kind_labels)} != {len(structure.sites)}"
            )
        kind_order, kind_counts = _kind_order_counts_from_labels(atom_kind_labels)
        site_kinds = atom_kind_labels
    else:
        kind_order, kind_counts = _kind_order_counts(structure_path)
        site_kinds = [site.kind for site in structure.sites]
    ready = ReadyModel(
        lattice=structure.lattice,
        atoms=[
            ReadyAtom(
                kind=kind_label,
                oxidation=float(charge_by_kind[kind_label]),
                x=float(site.x),
                y=float(site.y),
                z=float(site.z),
            )
            for site, kind_label in zip(structure.sites, site_kinds)
        ],
        poscar_species_counts=[
            CompositionEntry(kind=kind, count=int(kind_counts[kind])) for kind in kind_order
        ],
        supercell_expansion=(1, 1, 1),
        rg_find_factor=int(rg_find_factor),
        chop_level=float(chop_level),
        output_prefix="",
        recipes=[
            ReadyRecipe(
                from_kind=kind,
                oxidation=float(charge_by_kind[kind]),
                random_pickup=int(kind_counts[kind]),
                random_pickup_trial=1,
                modifications=[
                    ReadyRecipeModification(
                        to=kind,
                        oxidation=float(charge_by_kind[kind]),
                        count=int(kind_counts[kind]),
                    )
                ],
            )
            for kind in kind_order
        ],
    )
    result = solve(SolveInput(ready=ready, options=solve_options))
    return float(result.best.energy)


def _read_site_group_labels_from_poscar_comment(path: Path) -> list[str] | None:
    lines = [line.rstrip("\n") for line in path.read_text(errors="ignore").splitlines()]
    if len(lines) < 8:
        return None
    mode_index = 7
    mode_line = lines[mode_index].strip().lower()
    if mode_line.startswith("s"):
        mode_index += 1
        mode_line = lines[mode_index].strip().lower()
    if not (mode_line.startswith("d") or mode_line.startswith("c")):
        return None
    coord_start = mode_index + 1
    try:
        counts = [int(token) for token in lines[6].split()]
    except Exception:
        return None
    total_sites = sum(counts)
    if len(lines) < coord_start + total_sites:
        return None
    labels: list[str] = []
    for i in range(total_sites):
        raw = lines[coord_start + i]
        m = _SITE_LABEL_RE.search(raw)
        if not m:
            return None
        labels.append(m.group(1).lower())
    return labels


def _precompute_quadratic_ewald_tensor(
    entries: list[DatasetEntry],
    fit_kinds: list[str],
    fit_counts: np.ndarray,
    anchor_kind: str,
    anchor_count: float,
    element_site_free: bool,
    *,
    rg_find_factor: int,
    chop_level: float,
    solve_options: SolveOptions,
    atom_kind_labels_by_path: dict[Path, list[str]] | None,
    emit: Callable[[str], None],
) -> np.ndarray:
    """Build per-structure quadratic tensors H_m so E_m(x)=x^T H_m x."""
    dim = len(fit_kinds)
    h_tensor = np.zeros((len(entries), dim, dim), dtype=float)
    eye = np.eye(dim, dtype=float)

    emit(
        f"Precomputing quadratic Ewald basis: {len(entries)} structures, dim={dim}, "
        f"per-structure evals={dim + (dim * (dim - 1)) // 2}"
    )
    t0_all = time.perf_counter()
    progress_iter: Iterable[tuple[int, DatasetEntry]]
    used_tqdm = False
    try:
        from tqdm import tqdm  # type: ignore

        progress_iter = tqdm(
            list(enumerate(entries, start=1)),
            total=len(entries),
            desc="fit-charge precompute",
            unit="structure",
            leave=False,
        )
        used_tqdm = True
    except Exception:
        progress_iter = enumerate(entries, start=1)

    for sidx, entry in progress_iter:
        labels = (
            atom_kind_labels_by_path.get(entry.structure_path.resolve())
            if atom_kind_labels_by_path is not None
            else None
        )
        diag = np.zeros(dim, dtype=float)
        for i in range(dim):
            x = eye[i]
            if element_site_free:
                charge = {kind: float(val) for kind, val in zip(fit_kinds, x)}
            else:
                anchor_charge = -float(np.dot(fit_counts, x)) / anchor_count
                charge = {anchor_kind: anchor_charge}
                for kind, val in zip(fit_kinds, x):
                    charge[kind] = float(val)
            diag[i] = _ewald_energy_for_structure(
                entry.structure_path,
                charge,
                rg_find_factor=rg_find_factor,
                chop_level=chop_level,
                solve_options=solve_options,
                atom_kind_labels=labels,
            )
            h_tensor[sidx - 1, i, i] = diag[i]

        for i in range(dim):
            for j in range(i + 1, dim):
                x = eye[i] + eye[j]
                if element_site_free:
                    charge = {kind: float(val) for kind, val in zip(fit_kinds, x)}
                else:
                    anchor_charge = -float(np.dot(fit_counts, x)) / anchor_count
                    charge = {anchor_kind: anchor_charge}
                    for kind, val in zip(fit_kinds, x):
                        charge[kind] = float(val)
                e_ij = _ewald_energy_for_structure(
                    entry.structure_path,
                    charge,
                    rg_find_factor=rg_find_factor,
                    chop_level=chop_level,
                    solve_options=solve_options,
                    atom_kind_labels=labels,
                )
                hij = 0.5 * (e_ij - diag[i] - diag[j])
                h_tensor[sidx - 1, i, j] = hij
                h_tensor[sidx - 1, j, i] = hij

        if (not used_tqdm) and (sidx == 1 or sidx % 10 == 0 or sidx == len(entries)):
            emit(f"Quadratic precompute progress: {sidx}/{len(entries)} structures")
    elapsed = time.perf_counter() - t0_all
    emit(f"Quadratic Ewald precompute done in {elapsed:.2f}s")
    return h_tensor


def _build_precompute_meta(
    entries: list[DatasetEntry],
    fit_kinds: list[str],
    anchor_kind: str,
    basis: str,
    rg_find_factor: int,
    chop_level: float,
) -> dict[str, Any]:
    return {
        "version": 1,
        "structure_paths": [str(entry.structure_path.resolve()) for entry in entries],
        "fit_kinds": list(fit_kinds),
        "anchor_kind": str(anchor_kind),
        "basis": str(basis),
        "rg_find_factor": int(rg_find_factor),
        "chop_level": float(chop_level),
    }


def _load_quadratic_cache(
    cache_path: Path,
    expected_meta: dict[str, Any],
    emit: Callable[[str], None],
) -> np.ndarray | None:
    if not cache_path.exists():
        return None
    try:
        data = np.load(cache_path, allow_pickle=False)
        h = data["h_tensor"]
        meta_text = str(data["meta_json"].item())
        got_meta = json.loads(meta_text)
    except Exception as exc:
        emit(f"Quadratic cache load failed ({cache_path}): {exc}")
        return None

    if got_meta != expected_meta:
        emit("Quadratic cache mismatch: metadata changed, rebuilding cache")
        return None
    emit(f"Quadratic cache loaded: {cache_path}")
    return np.array(h, dtype=float, copy=False)


def _save_quadratic_cache(
    cache_path: Path,
    h_tensor: np.ndarray,
    meta: dict[str, Any],
    emit: Callable[[str], None],
) -> None:
    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            cache_path,
            h_tensor=h_tensor,
            meta_json=np.array(json.dumps(meta), dtype="U"),
        )
        emit(f"Quadratic cache saved: {cache_path}")
    except Exception as exc:
        emit(f"Quadratic cache save skipped ({cache_path}): {exc}")


def _rankdata(values: np.ndarray) -> np.ndarray:
    return np.argsort(np.argsort(values))


def _spearman(x: np.ndarray, y: np.ndarray) -> float:
    rx = _rankdata(x)
    ry = _rankdata(y)
    return float(np.corrcoef(rx, ry)[0, 1])


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    return float(np.corrcoef(x, y)[0, 1])


def _fit_linear_map_weighted(
    x: np.ndarray,
    y: np.ndarray,
    weights: np.ndarray,
) -> tuple[float, float, np.ndarray]:
    """Fit y ~= a*x + b with weighted least-squares."""
    design = np.vstack([x, np.ones_like(x)]).T
    sqrt_w = np.sqrt(weights)[:, None]
    beta = np.linalg.lstsq(design * sqrt_w, y * sqrt_w[:, 0], rcond=None)[0]
    scale = float(beta[0])
    bias = float(beta[1])
    pred = scale * x + bias
    return scale, bias, pred


def _fit_mapping_weighted(
    x: np.ndarray,
    y: np.ndarray,
    weights: np.ndarray,
    map_mode: str,
) -> tuple[float, float, np.ndarray]:
    mode = str(map_mode).strip().lower()
    if mode == "linear":
        return _fit_linear_map_weighted(x, y, weights)
    if mode == "bias_only":
        bias = float(np.sum(weights * (y - x)))
        scale = 1.0
        pred = x + bias
        return scale, bias, pred
    raise ValueError(f"Unsupported map_mode `{map_mode}`. Use one of: bias_only, linear.")


def fit_effective_charges(
    entries: list[DatasetEntry],
    *,
    anchor_kind: str,
    charge_basis: str = "auto",
    input_yaml: str | Path | None = None,
    rg_find_factor: int = 3,
    chop_level: float = 8.0,
    maxiter: int = 120,
    objective_name: str = "mapped_rmse",
    reg_l2: float = 1.0e-3,
    reg_site_delta: float = 0.0,
    map_mode: str = "bias_only",
    energy_weight_mode: str = "low_energy_boost",
    energy_weight_temp_eV: float = 1.0,
    low_energy_fraction: float = 0.3,
    low_energy_boost: float = 3.0,
    use_quadratic_precompute: bool = True,
    precompute_cache_path: str | Path | None = None,
    progress_callback: Callable[[str], None] | None = None,
    checkpoint_callback: Callable[[dict[str, Any]], None] | None = None,
    checkpoint_interval: int = 20,
) -> dict:
    try:
        from scipy.optimize import minimize
    except Exception as exc:
        raise RuntimeError(
            "fit-charge requires scipy. Install with: pip install scipy"
        ) from exc

    basis = str(charge_basis).strip().lower()
    if basis not in {"auto", "element", "element_site"}:
        raise ValueError("charge_basis must be one of: auto, element, element_site")

    atom_kind_labels_by_path: dict[Path, list[str]] = {}
    pending_messages: list[str] = []

    if basis == "auto":
        labels_available = True
        for entry in entries:
            raw_site_labels = _read_site_group_labels_from_poscar_comment(entry.structure_path)
            if raw_site_labels is None:
                labels_available = False
                break
        if labels_available:
            basis = "element_site"
            pending_messages.append(
                "Auto basis: detected '# site-xxx' labels in samples -> using element_site."
            )
        else:
            basis = "element"
            pending_messages.append(
                "Auto basis: no '# site-xxx' labels detected -> using element."
            )

    first_order: list[str]
    first_counts: dict[str, int]
    element_site_free = False
    anchor_label_for_site: str | None = None
    if basis == "element":
        first_order, first_counts = _kind_order_counts(entries[0].structure_path)
        _validate_compatible_structures(entries, first_order, first_counts)
    else:
        labels_available = True
        union_order: list[str] = []
        total_counts: dict[str, int] = {}
        for entry in entries:
            raw_site_labels = _read_site_group_labels_from_poscar_comment(entry.structure_path)
            if raw_site_labels is None:
                labels_available = False
                break
            structure = load_poscar(entry.structure_path)
            if len(raw_site_labels) != len(structure.sites):
                raise ValueError(
                    f"site label count mismatch in {entry.structure_path}: "
                    f"{len(raw_site_labels)} != {len(structure.sites)}"
                )
            labels = [
                f"{str(site.kind)}@{str(site_label)}"
                for site, site_label in zip(structure.sites, raw_site_labels)
            ]
            atom_kind_labels_by_path[entry.structure_path.resolve()] = labels
            for lb in labels:
                if lb not in total_counts:
                    total_counts[lb] = 0
                    union_order.append(lb)
                total_counts[lb] += 1
        if not labels_available:
            pending_messages.append(
                "element_site requested but no '# site-xxx' labels found in samples. "
                "Falling back to element basis."
            )
            basis = "element"
            atom_kind_labels_by_path = {}
            first_order, first_counts = _kind_order_counts(entries[0].structure_path)
            _validate_compatible_structures(entries, first_order, first_counts)
            if anchor_kind not in first_counts:
                raise ValueError(
                    f"anchor kind `{anchor_kind}` not found in structure kinds: {first_order}"
                )
            fit_kinds = [kind for kind in first_order if kind != anchor_kind]
            fit_counts = np.array([first_counts[kind] for kind in fit_kinds], dtype=float)
            anchor_count = float(first_counts[anchor_kind])
        else:
            first_order = union_order
            first_counts = total_counts
            site_anchor_candidates = [
                kind for kind in first_order if str(kind).split("@", 1)[0] == str(anchor_kind)
            ]
            if len(site_anchor_candidates) == 1:
                anchor_label_for_site = site_anchor_candidates[0]
                fit_kinds = [kind for kind in first_order if kind != anchor_label_for_site]
                fit_counts = np.array([first_counts[kind] for kind in fit_kinds], dtype=float)
                anchor_count = float(first_counts[anchor_label_for_site])
                anchor_kind = anchor_label_for_site
                element_site_free = False
                pending_messages.append(
                    f"element_site neutrality anchor: `{anchor_label_for_site}` (auto from --anchor-kind)."
                )
            else:
                fit_kinds = list(first_order)
                fit_counts = np.array([], dtype=float)
                anchor_count = 1.0
                anchor_kind = "(none)"
                element_site_free = True
                pending_messages.append(
                    "element_site: could not determine a unique anchor site label; "
                    "running unconstrained (site charges may drift)."
                )

    if not element_site_free and basis == "element":
        if anchor_kind not in first_counts:
            raise ValueError(
                f"anchor kind `{anchor_kind}` not found in structure kinds: {first_order}"
            )
        fit_kinds = [kind for kind in first_order if kind != anchor_kind]
        fit_counts = np.array([first_counts[kind] for kind in fit_kinds], dtype=float)
        anchor_count = float(first_counts[anchor_kind])

    default_guess = dict(_BUILTIN_CHARGE_GUESS)
    input_charge_guess = _flatten_charge_defaults_from_input(input_yaml)
    if input_charge_guess:
        default_guess.update(input_charge_guess)
        pending_messages.append(
            f"Loaded initial charge guesses from input YAML: {Path(input_yaml).expanduser()}"
        )
    x0 = np.array(
        [_charge_guess_for_kind(kind, default_guess) for kind in fit_kinds],
        dtype=float,
    )
    bounds = [_charge_bounds_for_initial(value) for value in x0]

    dft_energy = np.array([entry.dft_energy_eV for entry in entries], dtype=float)
    dft_delta = dft_energy - np.min(dft_energy)
    base_weights = np.array([entry.weight for entry in entries], dtype=float)
    if np.any(base_weights <= 0.0):
        raise ValueError("All dataset weights must be > 0.")
    objective_name = str(objective_name).strip().lower()
    if objective_name not in {"raw_rmse", "mapped_rmse"}:
        raise ValueError(
            f"Unsupported objective `{objective_name}`. "
            "Use one of: raw_rmse, mapped_rmse."
        )
    reg_l2 = float(reg_l2)
    if reg_l2 < 0.0:
        raise ValueError(f"reg_l2 must be >= 0.0, got {reg_l2}")
    reg_site_delta = float(reg_site_delta)
    if reg_site_delta < 0.0:
        raise ValueError(f"reg_site_delta must be >= 0.0, got {reg_site_delta}")
    map_mode = str(map_mode).strip().lower()
    if map_mode not in {"bias_only", "linear"}:
        raise ValueError(
            f"Unsupported map_mode `{map_mode}`. Use one of: bias_only, linear."
        )
    energy_weight_mode = str(energy_weight_mode).strip().lower()
    if energy_weight_mode not in {"uniform", "boltzmann", "low_energy_boost"}:
        raise ValueError(
            "Unsupported energy_weight_mode "
            f"`{energy_weight_mode}`. Use one of: uniform, boltzmann, low_energy_boost."
        )
    energy_weight_temp_eV = float(energy_weight_temp_eV)
    if energy_weight_temp_eV <= 0.0:
        raise ValueError(f"energy_weight_temp_eV must be > 0, got {energy_weight_temp_eV}")
    low_energy_fraction = float(low_energy_fraction)
    if not (0.0 < low_energy_fraction <= 1.0):
        raise ValueError(
            f"low_energy_fraction must be in (0, 1], got {low_energy_fraction}"
        )
    low_energy_boost = float(low_energy_boost)
    if low_energy_boost < 1.0:
        raise ValueError(f"low_energy_boost must be >= 1, got {low_energy_boost}")

    model_weights = np.ones_like(dft_delta)
    if energy_weight_mode == "boltzmann":
        model_weights = np.exp(-dft_delta / energy_weight_temp_eV)
    elif energy_weight_mode == "low_energy_boost":
        cutoff = float(np.quantile(dft_delta, low_energy_fraction))
        model_weights = np.where(dft_delta <= cutoff, low_energy_boost, 1.0)
    weights = base_weights * model_weights
    weights = weights / np.sum(weights)

    def _emit(message: str) -> None:
        if progress_callback is not None:
            progress_callback(message)
    for msg in pending_messages:
        _emit(msg)

    solve_options = _solve_options_single_eval()
    h_tensor: np.ndarray | None = None
    if use_quadratic_precompute:
        cache_path = (
            Path(precompute_cache_path).resolve()
            if precompute_cache_path is not None
            else Path("ewald_quadratic_cache.npz").resolve()
        )
        if precompute_cache_path is None:
            _emit(f"Quadratic cache path: default `{cache_path}` (auto load/save)")
        else:
            _emit(f"Quadratic cache path: `{cache_path}`")
        cache_meta = _build_precompute_meta(
            entries, fit_kinds, anchor_kind, basis, int(rg_find_factor), float(chop_level)
        )
        h_tensor = _load_quadratic_cache(cache_path, cache_meta, _emit)
        if h_tensor is None:
            h_tensor = _precompute_quadratic_ewald_tensor(
                entries,
                fit_kinds,
                fit_counts,
                anchor_kind,
                anchor_count,
                element_site_free=element_site_free,
                rg_find_factor=rg_find_factor,
                chop_level=chop_level,
                solve_options=solve_options,
                atom_kind_labels_by_path=atom_kind_labels_by_path if basis == "element_site" else None,
                emit=_emit,
            )
            _save_quadratic_cache(cache_path, h_tensor, cache_meta, _emit)
    else:
        _emit("Quadratic precompute: disabled (--no-precompute)")
    cache: dict[tuple[float, ...], np.ndarray] = {}
    objective_calls = 0
    best_total = float("inf")
    best_call = 0
    best_x: np.ndarray | None = None
    first_total: float | None = None
    checkpoint_interval = max(1, int(checkpoint_interval))

    def charge_map_from_x(x: np.ndarray) -> dict[str, float]:
        if element_site_free:
            return {kind: float(val) for kind, val in zip(fit_kinds, x)}
        anchor_charge = -float(np.dot(fit_counts, x)) / anchor_count
        charge = {anchor_kind: anchor_charge}
        for kind, val in zip(fit_kinds, x):
            charge[kind] = float(val)
        return charge

    def _site_delta_penalty(x: np.ndarray) -> float:
        if basis != "element_site" or reg_site_delta <= 0.0:
            return 0.0
        by_elem: dict[str, list[float]] = {}
        for key, val in zip(fit_kinds, x):
            if "@" not in str(key):
                continue
            elem = str(key).split("@", 1)[0].strip()
            by_elem.setdefault(elem, []).append(float(val))
        if not by_elem:
            return 0.0
        raw = 0.0
        for vals in by_elem.values():
            if len(vals) <= 1:
                continue
            arr = np.array(vals, dtype=float)
            mu = float(np.mean(arr))
            raw += float(np.sum((arr - mu) ** 2))
        return reg_site_delta * raw

    def _site_charge_log_line(charge_map: dict[str, float], max_sites: int = 3, max_elems: int = 6) -> str:
        grouped: dict[str, list[tuple[str, float]]] = {}
        for key, val in charge_map.items():
            if "@" not in str(key):
                continue
            elem, site = str(key).split("@", 1)
            grouped.setdefault(site.strip(), []).append((elem.strip(), float(val)))
        if not grouped:
            return ""
        parts: list[str] = []
        for site in sorted(grouped.keys())[:max_sites]:
            items = sorted(grouped[site], key=lambda kv: kv[0])[:max_elems]
            inner = ", ".join(f"{e}={v:.3f}" for e, v in items)
            parts.append(f"{site}[{inner}]")
        return "site_charges: " + " | ".join(parts)

    def ewald_delta_for_x(x: np.ndarray) -> np.ndarray:
        key = tuple(np.round(x, 8))
        if key in cache:
            return cache[key]
        eval_id = len(cache) + 1
        t0 = time.perf_counter()
        if h_tensor is not None:
            energies = np.einsum("i,mij,j->m", x, h_tensor, x, optimize=True)
            mode = "quadratic cache"
        else:
            charge = charge_map_from_x(x)
            energies_list: list[float] = []
            for entry in entries:
                labels = atom_kind_labels_by_path.get(entry.structure_path.resolve())
                energies_list.append(
                    _ewald_energy_for_structure(
                        entry.structure_path,
                        charge,
                        rg_find_factor=rg_find_factor,
                        chop_level=chop_level,
                        solve_options=solve_options,
                        atom_kind_labels=labels,
                    )
                )
            energies = np.array(energies_list, dtype=float)
            mode = "full ewald"
        elapsed = time.perf_counter() - t0
        _emit(f"ewald_eval#{eval_id} done: {len(entries)} structures in {elapsed:.3f}s ({mode})")
        delta = energies - np.min(energies)
        cache[key] = delta
        return delta

    def weighted_rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        mse = float(np.sum(weights * ((y_true - y_pred) ** 2)))
        return math.sqrt(mse)

    def weighted_r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        y_bar = float(np.sum(weights * y_true))
        ss_tot = float(np.sum(weights * ((y_true - y_bar) ** 2)))
        if ss_tot <= 0.0:
            return float("nan")
        ss_res = float(np.sum(weights * ((y_true - y_pred) ** 2)))
        return 1.0 - ss_res / ss_tot

    def mapped_rmse(y_true: np.ndarray, y_raw: np.ndarray) -> tuple[float, float, float]:
        scale, bias, pred = _fit_mapping_weighted(y_raw, y_true, weights, map_mode)
        return weighted_rmse(y_true, pred), scale, bias

    # Baseline(default charge) is fixed; compute once so checkpoints can report it.
    baseline_ewald_delta = ewald_delta_for_x(x0)
    baseline_scale, baseline_bias, baseline_pred = _fit_mapping_weighted(
        baseline_ewald_delta, dft_delta, weights, map_mode
    )
    baseline_metrics = {
        "rmse_no_scale": float(weighted_rmse(dft_delta, baseline_ewald_delta)),
        "rmse_after_linear_map": float(weighted_rmse(dft_delta, baseline_pred)),
        "mae_after_linear_map": float(np.sum(weights * np.abs(dft_delta - baseline_pred))),
        "r2_after_linear_map": float(weighted_r2(dft_delta, baseline_pred)),
        "pearson_after_linear_map": _pearson(dft_delta, baseline_pred),
        "spearman_raw_ewald": _spearman(dft_delta, baseline_ewald_delta),
        "spearman_after_linear_map": _spearman(dft_delta, baseline_pred),
        "spearman": _spearman(dft_delta, baseline_pred),
    }
    _emit(
        "Weighting: "
        f"mode={energy_weight_mode}, temp_eV={energy_weight_temp_eV:.4g}, "
        f"low_fraction={low_energy_fraction:.3g}, low_boost={low_energy_boost:.3g}"
    )

    def objective(x: np.ndarray) -> float:
        nonlocal objective_calls, best_total, best_call, best_x, first_total
        objective_calls += 1
        ewald_delta = ewald_delta_for_x(x)
        if objective_name == "mapped_rmse":
            data_loss, cur_scale, cur_bias = mapped_rmse(dft_delta, ewald_delta)
            _, _, cur_pred = _fit_mapping_weighted(ewald_delta, dft_delta, weights, map_mode)
        else:
            data_loss = weighted_rmse(dft_delta, ewald_delta)
            cur_scale, cur_bias = 1.0, 0.0
            cur_pred = ewald_delta
        reg_l2_loss = reg_l2 * float(np.sum((x - x0) ** 2))
        reg_site_loss = _site_delta_penalty(x)
        reg_loss = reg_l2_loss + reg_site_loss
        total = data_loss + reg_loss
        if first_total is None:
            first_total = total
        improved = total < best_total
        if improved:
            best_total = total
            best_call = objective_calls
            best_x = np.array(x, dtype=float, copy=True)
        if improved or objective_calls == 1 or objective_calls % 20 == 0:
            cur_mae = float(np.sum(weights * np.abs(dft_delta - cur_pred)))
            cur_r2 = weighted_r2(dft_delta, cur_pred)
            cur_pearson = _pearson(dft_delta, cur_pred)
            cur_spearman = _spearman(dft_delta, cur_pred)
            cur_charge = charge_map_from_x(x)
            show_keys = fit_kinds if element_site_free else [*fit_kinds, anchor_kind]
            charge_text = ", ".join(
                f"{k}={cur_charge[k]:.3f}" for k in show_keys[:12] if k in cur_charge
            )
            if len(show_keys) > 12:
                charge_text += ", ..."
            improve_pct = (
                100.0 * (first_total - best_total) / max(abs(first_total), 1e-12)
                if first_total is not None
                else 0.0
            )
            gap_to_best = total - best_total
            iters_since_best = objective_calls - best_call
            _emit(
                f"iter={objective_calls}"
                f"{' [best]' if improved else ''}: "
                f"Error(RMSE/MAE)={data_loss:.4f}/{cur_mae:.4f} eV | "
                f"Pearson_r={cur_pearson:.4f} | Spearman_rho={cur_spearman:.4f} | "
                f"Convergence(best_obj={best_total:.6f}, current_minus_best={gap_to_best:.2e}, "
                f"improvement_from_start={improve_pct:.1f}%, iters_since_best={iters_since_best}) | "
                f"map(b={cur_bias:.4f}) | q[{charge_text}]"
            )
            if basis == "element_site":
                site_line = _site_charge_log_line(cur_charge)
                if site_line:
                    _emit(site_line)
        if checkpoint_callback is not None and (improved or objective_calls % checkpoint_interval == 0):
            snapshot_site_summary: dict[str, dict[str, float]] = {}
            if basis == "element_site":
                cur_charge = charge_map_from_x(x)
                for key, value in cur_charge.items():
                    if "@" not in str(key):
                        continue
                    elem, site = str(key).split("@", 1)
                    site = site.strip()
                    elem = elem.strip()
                    if not site or not elem:
                        continue
                    snapshot_site_summary.setdefault(site, {})
                    snapshot_site_summary[site][elem] = float(value)
            snapshot_rows = [
                {
                    "structure": str(entry.structure_path),
                    "dft_energy_eV": float(dft_e),
                    "dft_delta_eV": float(dft_de),
                    "ewald_delta_eV": float(ew_de),
                    "pred_delta_eV": float(pred_de),
                    "baseline_ewald_delta_eV": float(base_ew_de),
                    "baseline_pred_delta_eV": float(base_pred_de),
                    "weight": float(entry.weight),
                }
                for entry, dft_e, dft_de, ew_de, pred_de, base_ew_de, base_pred_de in zip(
                    entries,
                    dft_energy,
                    dft_delta,
                    ewald_delta,
                    cur_pred,
                    baseline_ewald_delta,
                    baseline_pred,
                )
            ]
            checkpoint_callback(
                {
                    "status": "running",
                    "message": f"checkpoint at objective_call={objective_calls}",
                    "n_samples": len(entries),
                    "anchor_kind": anchor_kind,
                    "kind_order": first_order,
                    "charges": charge_map_from_x(x),
                    "site_charge_summary": snapshot_site_summary,
                    "linear_map": {"scale": float(cur_scale), "bias": float(cur_bias)},
                    "metrics": {
                        "objective_value": float(total),
                        "reg_l2_term": float(reg_l2_loss),
                        "reg_site_delta_term": float(reg_site_loss),
                        "rmse_no_scale": float(weighted_rmse(dft_delta, ewald_delta)),
                        "rmse_after_linear_map": float(data_loss),
                        "mae_after_linear_map": float(cur_mae),
                        "r2_after_linear_map": float(cur_r2),
                        "pearson_after_linear_map": float(cur_pearson),
                        "spearman_after_linear_map": float(cur_spearman),
                        "spearman": float(cur_spearman),
                    },
                    "baseline": {
                        "charges": charge_map_from_x(x0),
                        "linear_map": {
                            "scale": float(baseline_scale),
                            "bias": float(baseline_bias),
                        },
                        "metrics": baseline_metrics,
                    },
                    "config": {
                        "charge_basis": basis,
                        "rg_find_factor": int(rg_find_factor),
                        "chop_level": float(chop_level),
                        "maxiter": int(maxiter),
                        "objective": objective_name,
                        "reg_l2": reg_l2,
                        "reg_site_delta": reg_site_delta,
                        "map_mode": map_mode,
                        "energy_weight_mode": energy_weight_mode,
                        "energy_weight_temp_eV": float(energy_weight_temp_eV),
                        "low_energy_fraction": float(low_energy_fraction),
                        "low_energy_boost": float(low_energy_boost),
                        "quadratic_precompute": bool(use_quadratic_precompute),
                        "precompute_cache_path": (
                            str(Path(precompute_cache_path).resolve())
                            if precompute_cache_path is not None
                            else str(Path("ewald_quadratic_cache.npz").resolve())
                        ),
                    },
                    "optimizer": {
                        "method": "Powell",
                        "objective_calls": int(objective_calls),
                        "best_call": int(best_call),
                    },
                    "rows": snapshot_rows,
                }
            )
        return total

    result = minimize(
        objective,
        x0,
        method="Powell",
        bounds=bounds,
        options={"maxiter": int(maxiter), "xtol": 1e-3, "ftol": 1e-3},
    )
    x_best = np.array(best_x, dtype=float, copy=True) if best_x is not None else result.x
    charges = charge_map_from_x(x_best)
    ewald_delta = ewald_delta_for_x(x_best)
    scale, bias, pred = _fit_mapping_weighted(ewald_delta, dft_delta, weights, map_mode)

    report_rows: list[dict] = []
    for entry, dft_e, dft_de, ew_de, pred_de, base_ew_de, base_pred_de in zip(
        entries, dft_energy, dft_delta, ewald_delta, pred, baseline_ewald_delta, baseline_pred
    ):
        report_rows.append(
            {
                "structure": str(entry.structure_path),
                "dft_energy_eV": float(dft_e),
                "dft_delta_eV": float(dft_de),
                "ewald_delta_eV": float(ew_de),
                "pred_delta_eV": float(pred_de),
                "baseline_ewald_delta_eV": float(base_ew_de),
                "baseline_pred_delta_eV": float(base_pred_de),
                "weight": float(entry.weight),
            }
        )

    site_charge_summary: dict[str, dict[str, float]] = {}
    if basis == "element_site":
        for key, value in charges.items():
            if "@" not in str(key):
                continue
            elem, site = str(key).split("@", 1)
            site = site.strip()
            elem = elem.strip()
            if not site or not elem:
                continue
            site_charge_summary.setdefault(site, {})
            site_charge_summary[site][elem] = float(value)

    return {
        "status": "ok" if bool(result.success) else "warn",
        "message": str(result.message),
        "n_samples": len(entries),
        "anchor_kind": anchor_kind,
        "kind_order": first_order,
        "charges": charges,
        "site_charge_summary": site_charge_summary,
        "linear_map": {
            "scale": float(scale),
            "bias": float(bias),
        },
        "metrics": {
            "objective_value": float(
                weighted_rmse(dft_delta, pred)
                + reg_l2 * float(np.sum((x_best - x0) ** 2))
                + _site_delta_penalty(x_best)
            ),
            "reg_l2_term": float(reg_l2 * float(np.sum((x_best - x0) ** 2))),
            "reg_site_delta_term": float(_site_delta_penalty(x_best)),
            "rmse_no_scale": float(weighted_rmse(dft_delta, ewald_delta)),
            "rmse_after_linear_map": float(weighted_rmse(dft_delta, pred)),
            "mae_after_linear_map": float(np.sum(weights * np.abs(dft_delta - pred))),
            "r2_after_linear_map": float(weighted_r2(dft_delta, pred)),
            "pearson_after_linear_map": _pearson(dft_delta, pred),
            "spearman_raw_ewald": _spearman(dft_delta, ewald_delta),
            "spearman_after_linear_map": _spearman(dft_delta, pred),
            "spearman": _spearman(dft_delta, pred),
        },
        "baseline": {
            "charges": charge_map_from_x(x0),
            "linear_map": {
                "scale": float(baseline_scale),
                "bias": float(baseline_bias),
            },
            "metrics": baseline_metrics,
        },
        "config": {
            "charge_basis": basis,
            "rg_find_factor": int(rg_find_factor),
            "chop_level": float(chop_level),
            "maxiter": int(maxiter),
            "objective": objective_name,
            "reg_l2": reg_l2,
            "reg_site_delta": reg_site_delta,
            "map_mode": map_mode,
            "energy_weight_mode": energy_weight_mode,
            "energy_weight_temp_eV": float(energy_weight_temp_eV),
            "low_energy_fraction": float(low_energy_fraction),
            "low_energy_boost": float(low_energy_boost),
            "quadratic_precompute": bool(use_quadratic_precompute),
            "precompute_cache_path": (
                str(Path(precompute_cache_path).resolve())
                if precompute_cache_path is not None
                else str(Path("ewald_quadratic_cache.npz").resolve())
            ),
        },
        "optimizer": {
            "method": "Powell",
            "success": bool(result.success),
            "message": str(result.message),
            "nit": int(getattr(result, "nit", -1)),
            "nfev": int(getattr(result, "nfev", -1)),
            "objective_calls": int(objective_calls),
            "best_call": int(best_call),
        },
        "rows": report_rows,
    }
