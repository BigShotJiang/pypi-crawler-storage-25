from __future__ import annotations

from pathlib import Path

from .models import Lattice, Site, StructureModel


def _parse_vec3(line: str, name: str) -> tuple[float, float, float]:
    parts = line.split()
    if len(parts) < 3:
        raise ValueError(f"`{name}` must have at least 3 numeric values")
    return (float(parts[0]), float(parts[1]), float(parts[2]))


def load_poscar(path: str | Path) -> StructureModel:
    path = Path(path)
    lines = [line.rstrip("\n") for line in path.read_text().splitlines()]
    if len(lines) < 8:
        raise ValueError(f"POSCAR is too short: {path}")

    title = lines[0].strip()
    scale = float(lines[1].split()[0])
    lattice = Lattice(
        a=tuple(scale * value for value in _parse_vec3(lines[2], "vec_a")),
        b=tuple(scale * value for value in _parse_vec3(lines[3], "vec_b")),
        c=tuple(scale * value for value in _parse_vec3(lines[4], "vec_c")),
    )

    species = lines[5].split()
    counts = [int(token) for token in lines[6].split()]
    if len(species) != len(counts):
        raise ValueError(f"Species/count mismatch in POSCAR: {path}")

    mode_index = 7
    selective_dynamics = False
    mode_line = lines[mode_index].strip()
    if mode_line.lower().startswith("s"):
        selective_dynamics = True
        mode_index += 1
        mode_line = lines[mode_index].strip()

    lowered = mode_line.lower()
    if lowered.startswith("d"):
        fractional_coordinates = True
    elif lowered.startswith("c"):
        fractional_coordinates = False
    else:
        raise ValueError(f"Unknown coordinate mode in POSCAR: {mode_line}")

    coord_start = mode_index + 1
    total_sites = sum(counts)
    if len(lines) < coord_start + total_sites:
        raise ValueError(f"POSCAR has fewer coordinate lines than expected: {path}")

    sites: list[Site] = []
    site_index = 0
    for kind, count in zip(species, counts):
        for _ in range(count):
            parts = lines[coord_start + site_index].split()
            if len(parts) < 3:
                raise ValueError(f"Malformed coordinate line in POSCAR: {path}")
            sites.append(
                Site(
                    kind=kind,
                    x=float(parts[0]),
                    y=float(parts[1]),
                    z=float(parts[2]),
                    oxidation=0.0,
                )
            )
            site_index += 1

    _ = selective_dynamics
    return StructureModel(
        title=title,
        lattice=lattice,
        sites=sites,
        fractional_coordinates=fractional_coordinates,
    )

def _format_float(value: float, precision: int = 10) -> str:
    return f"{value:.{precision}f}"

def write_structure_to_poscar(
    structure: StructureModel,
    title: str | None = None,
    species_order: list[str] | None = None,
    site_labels: list[str] | None = None,
) -> str:
    """Format a StructureModel as VASP5 POSCAR text."""
    chosen_title = title or structure.title or "structure"
    if site_labels is not None and len(site_labels) != len(structure.sites):
        raise ValueError(
            "site_labels length must match number of structure sites "
            f"({len(site_labels)} != {len(structure.sites)})"
        )
    
    # Group sites by kind preserving a requested species order first,
    # then append any remaining kinds in first-appearance order.
    grouped: dict[str, list[tuple[Site, str | None]]] = {}
    first_seen: list[str] = []
    for index, site in enumerate(structure.sites):
        if site.kind not in grouped:
            grouped[site.kind] = []
            first_seen.append(site.kind)
        label = site_labels[index] if site_labels is not None else None
        grouped[site.kind].append((site, label))

    ordered_kinds: list[str] = []
    if species_order:
        for kind in species_order:
            if kind in grouped and kind not in ordered_kinds:
                ordered_kinds.append(kind)
    for kind in first_seen:
        if kind not in ordered_kinds:
            ordered_kinds.append(kind)
        
    lines: list[str] = []
    lines.append(chosen_title)
    lines.append("1.0")
    for vec in (structure.lattice.a, structure.lattice.b, structure.lattice.c):
        lines.append("  " + "  ".join(_format_float(component) for component in vec))
        
    lines.append("  " + "  ".join(ordered_kinds))
    lines.append("  " + "  ".join(str(len(grouped[kind])) for kind in ordered_kinds))
    
    lines.append("Direct" if structure.fractional_coordinates else "Cartesian")
    for kind in ordered_kinds:
        rows = grouped[kind]
        for site, label in rows:
            coord_line = "  " + "  ".join(_format_float(c) for c in (site.x, site.y, site.z))
            if label:
                coord_line += f"  # {label}"
            lines.append(coord_line)
            
    return "\n".join(lines) + "\n"
