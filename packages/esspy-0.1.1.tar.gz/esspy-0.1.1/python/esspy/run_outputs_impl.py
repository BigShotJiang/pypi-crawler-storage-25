from __future__ import annotations

import copy
from dataclasses import asdict
from dataclasses import replace
import json
import math
from pathlib import Path
import random
import time
from typing import Any
from collections import Counter
import yaml
import re

from . import cli_common
from .guide_guider_writer import write_guider_text_from_yaml
from .guide_poscar_writer import write_poscar_text
from .guide_ready_writer import write_ready_file_text
from .mpi_context import detect_mpi_context
from .models import (
    CompositionEntry,
    GuideResult,
    ReadyRecipe,
    ReadyRecipeModification,
    RecipeAssignment,
    RunInput,
    SolveInput,
    SolveResult,
    StructureSnapshot,
)
from .output_config import load_output_config
from .poscar import load_poscar, write_structure_to_poscar
from .progress import ProgressReporter
from .solve_search_space import analyze_search_space
from .workflow import (
    ESSWorkflow,
    ready_with_legacy_text_precision,
    solve,
    structure_from_dict,
)


class _EnergyTracker:
    """Track best energy improvements during solve progress."""
    def __init__(self):
        self.best_energy = float('inf')
        self.improvements = []  # List of (timestamp, energy)
        self.snapshots = []  # List of (energy, path)

    def check_improvement(self, energy: float, elapsed_sec: float) -> bool:
        """Check if energy improved. Returns True if improvement detected."""
        if energy is not None and energy < self.best_energy:
            self.best_energy = energy
            self.improvements.append((elapsed_sec, energy))
            return True
        return False

    def add_snapshot(self, energy: float, path: Path) -> None:
        self.snapshots.append((float(energy), Path(path)))


class _StageBudget:
    """Wall-clock budget for one run stage."""

    def __init__(self, target_sec: float | int | None):
        self.target_sec = max(0.0, float(target_sec or 0.0))
        self.started_at = time.monotonic()

    @property
    def active(self) -> bool:
        return self.target_sec > 0.0

    def elapsed(self) -> float:
        return max(0.0, time.monotonic() - self.started_at)

    def remaining(self) -> float:
        if not self.active:
            return 0.0
        return max(0.0, self.target_sec - self.elapsed())


def _default_charge_map(run_input: RunInput) -> dict[str, float]:
    return {
        entry.kind: float(entry.oxidation)
        for entry in run_input.guide.charges.values
    }


def _allocation_phase_budget_sec(
    payload: dict[str, Any],
    budget: _StageBudget,
) -> tuple[float | None, float | None]:
    """Return (budget_sec_for_allocation, fraction_used).

    If allocation.time_budget_sec is set, allocation has its own independent
    wall-clock budget. Otherwise the top-level solve strategy budget is shared:
    allocation gets a modest slice and the remaining time is left to native ESS.
    """
    allocation = payload.get("allocation") if isinstance(payload, dict) else None
    if not isinstance(allocation, dict):
        if not budget.active:
            return None, None
        return budget.remaining(), None
    explicit = _explicit_allocation_budget_sec(payload)
    if explicit is not None:
        return max(0.0, float(explicit)), None
    if not budget.active:
        return None, None
    raw_fraction = allocation.get("budget_fraction", allocation.get("allocation_budget_fraction", 0.30))
    try:
        fraction = float(raw_fraction)
    except Exception:
        fraction = 0.30
    fraction = max(0.0, min(1.0, fraction))
    return max(0.0, budget.remaining() * fraction), fraction


def _explicit_allocation_budget_sec(payload: dict[str, Any]) -> float | None:
    allocation = payload.get("allocation") if isinstance(payload, dict) else None
    if not isinstance(allocation, dict):
        return None
    value = allocation.get("time_budget_sec", allocation.get("generalized_time_budget_sec"))
    if value is None:
        return None
    try:
        return max(0.0, float(value))
    except Exception:
        return None


def _remaining_adaptive_budget_delta(budget: _StageBudget) -> int | None:
    if not budget.active:
        return None
    # The native solver uses a negative running_index_delta as adaptive seconds.
    return -max(1, int(math.ceil(budget.remaining())))


def _safe_snapshot_stem(value: str) -> str:
    cleaned = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in str(value))
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    cleaned = cleaned.strip("_")
    return cleaned or "structure"


def _drop_zero_count_species_from_poscar(poscar_text: str) -> str:
    """Remove species with zero count from VASP5 species/count header lines."""
    lines = poscar_text.splitlines()
    # Minimal POSCAR shape: title + scale + 3 lattice + species + counts + coord-mode
    if len(lines) < 8:
        return poscar_text
    try:
        species = lines[5].split()
        counts = [int(token) for token in lines[6].split()]
    except Exception:
        return poscar_text
    if not species or len(species) != len(counts):
        return poscar_text
    kept = [(kind, count) for kind, count in zip(species, counts) if int(count) > 0]
    if len(kept) == len(species):
        return poscar_text
    if not kept:
        return poscar_text
    lines[5] = "  " + "  ".join(kind for kind, _ in kept)
    lines[6] = "  " + "  ".join(str(count) for _, count in kept)
    return "\n".join(lines) + "\n"


def _read_input_poscar_species_order(input_yaml: Path, poscar_value: str | None) -> list[str]:
    if not poscar_value:
        return []
    try:
        poscar_path = Path(poscar_value)
        if not poscar_path.is_absolute():
            poscar_path = (input_yaml.parent / poscar_path).resolve()
        structure = load_poscar(poscar_path)
        ordered: list[str] = []
        for site in structure.sites:
            if site.kind not in ordered:
                ordered.append(site.kind)
        return ordered
    except Exception:
        return []


def _read_input_composition_order(input_yaml: Path) -> list[str]:
    try:
        payload = yaml.safe_load(input_yaml.read_text()) or {}
    except Exception:
        return []
    if not isinstance(payload, dict):
        return []
    composition = payload.get("composition")
    if not isinstance(composition, dict):
        return []
    fractions = composition.get("fractions")
    if isinstance(fractions, dict):
        return [str(kind) for kind in fractions.keys()]
    return [str(kind) for kind in composition.keys() if str(kind) != "fractions"]


def _load_site_charge_meta(input_yaml: Path) -> tuple[dict[str, str], dict[str, float]]:
    """Load optional site-aware charge metadata from input.yaml.

    Returns:
        (source_kind_to_group, charges_by_site)
    """
    try:
        payload = yaml.safe_load(input_yaml.read_text()) or {}
    except Exception:
        return {}, {}
    if not isinstance(payload, dict):
        return {}, {}

    site_groups_raw = payload.get("site_groups", {})
    charges_raw = payload.get("charges")
    charges_by_site_raw = payload.get("charges_by_site", {})
    if isinstance(charges_raw, dict):
        if isinstance(charges_raw.get("by_site"), dict):
            charges_by_site_raw = charges_raw.get("by_site", {})
        elif isinstance(charges_raw.get("elements"), dict):
            nested_map: dict[str, float] = {}
            for elem, entry in charges_raw.get("elements", {}).items():
                if not isinstance(entry, dict):
                    continue
                by_site = entry.get("by_site", {})
                if not isinstance(by_site, dict):
                    continue
                for group_name, value in by_site.items():
                    try:
                        nested_map[f"{str(elem)}@{str(group_name)}"] = float(value)
                    except Exception:
                        continue
            if nested_map:
                charges_by_site_raw = nested_map
    if not isinstance(site_groups_raw, dict) or not isinstance(charges_by_site_raw, dict):
        return {}, {}

    source_to_group: dict[str, str] = {}
    for group_name, info in site_groups_raw.items():
        if not isinstance(info, dict):
            continue
        source = info.get("source_kind")
        if source is None:
            continue
        source_to_group[str(source)] = _normalize_site_group_label(str(group_name))

    charges_by_site: dict[str, float] = {}
    for key, value in charges_by_site_raw.items():
        try:
            charges_by_site[_normalize_site_charge_key(str(key))] = float(value)
        except Exception:
            continue
    return source_to_group, charges_by_site


def _normalize_site_group_label(label: str) -> str:
    text = str(label).strip()
    m1 = re.fullmatch(r"site[-_]?(\d+)", text, flags=re.IGNORECASE)
    if m1:
        return f"site-{int(m1.group(1)):03d}"
    return text


def _normalize_site_charge_key(key: str) -> str:
    text = str(key).strip()
    if "@" not in text:
        return text
    elem, group = text.split("@", 1)
    return f"{elem.strip()}@{_normalize_site_group_label(group.strip())}"


def _load_charge_model_mapping(path: Path) -> dict[str, float]:
    payload = json.loads(path.read_text())
    if not isinstance(payload, dict):
        raise ValueError(f"charge model must be JSON object: {path}")
    raw = payload.get("charges")
    if not isinstance(raw, dict):
        raise ValueError(f"charge model v2 must contain `charges` object: {path}")
    elements = raw.get("elements")
    if not isinstance(elements, dict):
        raise ValueError(f"charge model v2 must contain `charges.elements` mapping: {path}")
    out: dict[str, float] = {}
    for elem, node in elements.items():
        if not isinstance(node, dict):
            continue
        by_site = node.get("by_site", {})
        if isinstance(by_site, dict) and by_site:
            for site, value in by_site.items():
                key = f"{str(elem).strip()}@{str(site).strip()}"
                out[_normalize_site_charge_key(key)] = float(value)
            continue
        if "default" in node:
            out[str(elem).strip()] = float(node["default"])
    if not out:
        raise ValueError(f"charge model v2 has no usable entries in `charges.elements`: {path}")
    return out


def _resolve_charge_model_path(
    input_path: Path,
    charge_model_path: str | Path | None,
) -> tuple[Path | None, str]:
    if charge_model_path is not None:
        model_path = Path(charge_model_path).expanduser()
        if not model_path.is_absolute():
            model_path = (input_path.parent / model_path).resolve()
        return model_path, "explicit"

    candidate = (input_path.parent / "charge_model.json").resolve()
    if candidate.exists():
        return candidate, "auto"
    return None, "none"


def _format_charge_model_entries(charges: dict[str, float]) -> str:
    return ", ".join(f"{key}={value:.6g}" for key, value in charges.items())


def _charge_title_element_order(run_input: RunInput, charges: dict[str, float]) -> list[str]:
    ordered: list[str] = []

    def add(kind: str) -> None:
        if kind and kind not in ordered:
            ordered.append(kind)

    for entry in getattr(run_input.guide.composition, "entries", []):
        add(str(entry.kind))
    for entry in getattr(run_input.guide.charges, "values", []):
        add(str(entry.kind))
    for key in charges:
        elem = str(key).split("@", 1)[0].strip()
        add(elem)
    return ordered


def _site_sort_token(site: str) -> tuple[int, str]:
    match = re.fullmatch(r"site-(\d+)", _normalize_site_group_label(site))
    if match:
        return int(match.group(1)), _normalize_site_group_label(site)
    return 10**9, _normalize_site_group_label(site)


def _charge_title_sort_key(
    key: str,
    *,
    element_rank: dict[str, int],
) -> tuple[int, str, int, str]:
    text = str(key)
    if "@" in text:
        elem, site = text.split("@", 1)
        elem = elem.strip()
        site_num, site_norm = _site_sort_token(site.strip())
        return element_rank.get(elem, 10**9), elem, site_num, site_norm
    elem = text.strip()
    return element_rank.get(elem, 10**9), elem, -1, ""


def _format_effective_charge_entries(
    run_input: RunInput,
    charges: dict[str, float] | None = None,
    *,
    precision: int | None = 3,
) -> str:
    """Format charges for POSCAR titles using the effective run-time charges.

    `charges` is the already-merged site-aware map, after optional
    charge_model.json override.  Falling back to element-only input charges
    preserves legacy POSCAR titles when no site-aware data is available.
    The native ESS solve consumes ready-file oxidation states at 3 decimals,
    so the title stores the same rounded values for `esspy ewald` replay.
    """

    def fmt(value: float) -> str:
        v = float(value)
        if precision is not None:
            v = float(f"{v:.{precision}f}")
        return f"{v:.15g}"

    normalized: dict[str, float] = {}
    for key, value in (charges or {}).items():
        try:
            normalized[_normalize_site_charge_key(str(key))] = float(value)
        except Exception:
            continue
    if normalized:
        element_order = _charge_title_element_order(run_input, normalized)
        element_rank = {elem: idx for idx, elem in enumerate(element_order)}
        keys = sorted(
            normalized,
            key=lambda key: _charge_title_sort_key(key, element_rank=element_rank),
        )
        return " ".join(f"{key}={fmt(normalized[key])}" for key in keys)
    return " ".join(
        f"{entry.kind}={fmt(float(entry.oxidation))}"
        for entry in sorted(run_input.guide.charges.values, key=lambda e: e.kind)
    )


def _flat_to_nested_charge_block(charges_map: dict[str, float]) -> dict[str, Any]:
    values: dict[str, float] = {}
    elements: dict[str, dict[str, Any]] = {}
    has_site = False
    for key, value in charges_map.items():
        k = str(key)
        v = float(value)
        if "@" in k:
            elem, site = k.split("@", 1)
            elem = elem.strip()
            site_norm = _normalize_site_group_label(site.strip())
            node = elements.setdefault(elem, {"default": v, "by_site": {}})
            by_site = node.setdefault("by_site", {})
            if isinstance(by_site, dict):
                by_site[site_norm] = v
            has_site = True
        else:
            elem = k.strip()
            values[elem] = v
            elements.setdefault(elem, {"default": v})
    for elem, node in elements.items():
        by_site = node.get("by_site", {})
        if isinstance(by_site, dict) and by_site:
            node["default"] = float(sum(by_site.values()) / float(len(by_site)))
        if elem not in values:
            values[elem] = float(node.get("default", 0.0))
    return {
        "basis": "element_site" if has_site else "element",
        "values": values,
        "elements": elements,
    }


def _validate_allocation_result(
    composition_by_site: dict[str, Any],
    *,
    expected_composition: dict[str, Any],
    site_groups: Any,
) -> None:
    if not isinstance(composition_by_site, dict):
        raise ValueError("allocation output `composition_by_site` must be a mapping")
    if not isinstance(expected_composition, dict):
        return
    site_count_map: dict[str, int] = {}
    if isinstance(site_groups, dict):
        for gname, info in site_groups.items():
            if isinstance(info, dict) and info.get("count") is not None:
                site_count_map[str(gname)] = int(info.get("count"))
    elif isinstance(site_groups, list):
        for item in site_groups:
            if not isinstance(item, dict):
                continue
            gname = item.get("name")
            gcount = item.get("count")
            if gname is None or gcount is None:
                continue
            site_count_map[str(gname)] = int(gcount)
    agg: dict[str, int] = {}
    for gname, row in composition_by_site.items():
        if not isinstance(row, dict):
            raise ValueError(f"allocation row must be mapping: {gname}")
        slot_sum = 0
        for elem, count in row.items():
            c = int(count)
            if c < 0:
                raise ValueError(f"allocation count must be >=0: {gname}.{elem}={c}")
            slot_sum += c
            agg[str(elem)] = agg.get(str(elem), 0) + c
        expected_slot = site_count_map.get(str(gname))
        if expected_slot is not None:
            if slot_sum != expected_slot:
                raise ValueError(
                    f"allocation site slot mismatch at {gname}: got={slot_sum}, expected={expected_slot}"
                )
    expected = {str(k): int(v) for k, v in expected_composition.items() if str(k) != "fractions"}
    if agg != expected:
        raise ValueError(
            f"allocation composition mismatch: got={agg}, expected={expected}"
        )


def _maybe_generate_sitewise_input_for_run(
    input_yaml: Path,
    *,
    charge_model_path: str | Path | None = None,
) -> tuple[Path, dict[str, Any]]:
    """Return an effective input path for run.

    If an allocation block is present, keep the original input and mark the
    run for portfolio allocation-aware search.  The run stage owns this search;
    wizard/init only describe the time budget.
    """
    try:
        payload = yaml.safe_load(input_yaml.read_text()) or {}
    except Exception:
        return input_yaml, {"auto_allocation_applied": False}
    if not isinstance(payload, dict):
        return input_yaml, {"auto_allocation_applied": False}
    allocation = payload.get("allocation")
    if allocation is None:
        return input_yaml, {"auto_allocation_applied": False}
    if not isinstance(allocation, dict):
        return input_yaml, {"auto_allocation_applied": False}
    allocation_mode = "portfolio_ess"
    raw_mode = allocation.get("mode")
    if raw_mode not in (None, "", "portfolio_ess"):
        raise ValueError("allocation.mode must be `portfolio_ess`")
    if bool(allocation.get("fixed_start", False)):
        return input_yaml, {
            "auto_allocation_applied": False,
            "mode": allocation_mode,
            "fixed_start": True,
            "starting_composition_by_site": payload.get("composition_by_site") is not None,
        }

    explicit_budget = _explicit_allocation_budget_sec(payload)
    seed = allocation.get("seed", None)
    seed = None if seed is None else int(seed)
    allocation_debug = bool(allocation.get("debug", False))
    return input_yaml, {
        "auto_allocation_applied": True,
        "mode": "portfolio_ess",
        "debug": allocation_debug,
        "generated_input_yaml": None,
        "allocation_table": None,
        "allocation_time_budget_sec": explicit_budget,
        "seed": seed,
        "seed_mode": "user_provided" if seed is not None else "default",
        "best_score": None,
        "score_mode": "portfolio_ess",
        "metric": "ewald_energy",
        "topk": None,
        "beam_width": None,
        "beam_rounds": None,
        "best_composition_by_site": None,
        "starting_composition_by_site": payload.get("composition_by_site") is not None,
    }


def _apply_site_charge_overrides_to_ready(
    guide_result: GuideResult,
    source_to_group: dict[str, str],
    charges_by_site: dict[str, float],
) -> tuple[int, int]:
    """Apply site-aware charge overrides directly to ready atoms/recipes.

    Returns:
        (overrides_applied, fallbacks_used)
    """
    if not source_to_group or not charges_by_site:
        return 0, 0

    overrides = 0
    fallbacks = 0

    for atom in guide_result.ready.atoms:
        group = source_to_group.get(atom.kind)
        if group is None:
            continue
        key = f"{atom.kind}@{group}"
        if key in charges_by_site:
            atom.oxidation = float(charges_by_site[key])
            overrides += 1
        else:
            fallbacks += 1

    for recipe in guide_result.ready.recipes:
        group = source_to_group.get(recipe.from_kind)
        if group is None:
            continue
        # Override source oxidation when provided.
        source_key = f"{recipe.from_kind}@{group}"
        if source_key in charges_by_site:
            recipe.oxidation = float(charges_by_site[source_key])
            overrides += 1
        else:
            fallbacks += 1
        # Override each target modification oxidation.
        for mod in recipe.modifications:
            key = f"{mod.to}@{group}"
            if key in charges_by_site:
                mod.oxidation = float(charges_by_site[key])
                overrides += 1
            else:
                fallbacks += 1

    return overrides, fallbacks


def _apply_sitewise_composition_payload_to_ready(
    guide_result: GuideResult,
    payload: dict[str, Any],
    *,
    source_to_group: dict[str, str],
    charges_by_site: dict[str, float],
    default_charges: dict[str, float],
) -> dict[str, Any]:
    """Force exact composition_by_site counts into ready recipes.

    The native guide recipe allocator only sees global target counts.  For
    allocation-aware runs we need a stronger invariant: each source site group
    must keep the exact row from composition_by_site, otherwise the solver is
    optimizing a different allocation than the one selected/generated upstream.
    """
    if not isinstance(payload, dict):
        return {"applied": False}
    raw_by_site = payload.get("composition_by_site")
    if not isinstance(raw_by_site, dict) or not raw_by_site:
        return {"applied": False}
    if not source_to_group:
        return {"applied": False}

    by_site_norm: dict[str, dict[str, int]] = {}
    for group_name, row in raw_by_site.items():
        if not isinstance(row, dict):
            raise ValueError(f"`composition_by_site.{group_name}` must be a mapping")
        norm_group = _normalize_site_group_label(str(group_name))
        counts: dict[str, int] = {}
        for kind, value in row.items():
            count = int(value)
            if count < 0:
                raise ValueError(
                    f"`composition_by_site.{group_name}.{kind}` must be >= 0"
                )
            if count > 0:
                counts[str(kind)] = count
        by_site_norm[norm_group] = counts

    recipe_by_source: dict[str, ReadyRecipe] = {
        recipe.from_kind: recipe for recipe in guide_result.ready.recipes
    }
    recipes_out: list[ReadyRecipe] = []
    applied_sources = 0
    total_slots = 0
    diagnostics: list[RecipeAssignment] = []

    def _charge(kind: str, group_norm: str) -> float:
        site_key = _normalize_site_charge_key(f"{kind}@{group_norm}")
        if site_key in charges_by_site:
            return float(charges_by_site[site_key])
        return float(default_charges.get(kind, 0.0))

    for source_kind, group_norm in source_to_group.items():
        row = by_site_norm.get(_normalize_site_group_label(group_norm))
        if row is None:
            continue
        slot_count = int(sum(row.values()))
        total_slots += slot_count
        source_charge = _charge(source_kind, group_norm)
        modifications: list[ReadyRecipeModification] = []
        assigned_counts: list[CompositionEntry] = []
        for kind, count in row.items():
            assigned_counts.append(CompositionEntry(kind=kind, count=int(count)))
            if kind == source_kind:
                continue
            modifications.append(
                ReadyRecipeModification(
                    to=kind,
                    oxidation=_charge(kind, group_norm),
                    count=int(count),
                )
            )
        recipe = recipe_by_source.get(source_kind)
        if recipe is None:
            recipe = ReadyRecipe(
                from_kind=source_kind,
                oxidation=source_charge,
                random_pickup=slot_count,
                random_pickup_trial=1,
                modifications=modifications,
            )
        else:
            recipe.oxidation = source_charge
            recipe.random_pickup = slot_count
            recipe.random_pickup_trial = max(1, int(recipe.random_pickup_trial))
            recipe.modifications = modifications
        recipes_out.append(recipe)
        diagnostics.append(
            RecipeAssignment(from_kind=source_kind, assigned_counts=assigned_counts)
        )
        applied_sources += 1

    untouched = [
        recipe
        for recipe in guide_result.ready.recipes
        if recipe.from_kind not in source_to_group
    ]
    guide_result.ready.recipes = recipes_out + untouched
    if diagnostics:
        guide_result.diagnostics.resolved_assignments = diagnostics

    return {
        "applied": True,
        "source_groups": applied_sources,
        "total_slots": total_slots,
    }


def _apply_sitewise_composition_to_ready(
    guide_result: GuideResult,
    input_yaml: Path,
    *,
    source_to_group: dict[str, str],
    charges_by_site: dict[str, float],
    default_charges: dict[str, float],
) -> dict[str, Any]:
    try:
        payload = yaml.safe_load(input_yaml.read_text()) or {}
    except Exception:
        return {"applied": False}
    return _apply_sitewise_composition_payload_to_ready(
        guide_result,
        payload,
        source_to_group=source_to_group,
        charges_by_site=charges_by_site,
        default_charges=default_charges,
    )


def _initial_composition_by_site_for_allocation_run(
    payload: dict[str, Any],
) -> dict[str, dict[str, int]] | None:
    if not isinstance(payload, dict):
        return None
    if isinstance(payload.get("composition_by_site"), dict):
        return None
    try:
        from .allocation_optimize import (
            _enumerate_feasible_allocations,
            _infer_target_sites,
            _load_composition_counts,
            _load_site_groups,
            _scale_site_group_counts,
            _score_allocation,
        )

        composition = _load_composition_counts(payload)
        composition_total = int(sum(composition.values()))
        composition_block = payload.get("composition")
        uses_fractions = (
            isinstance(composition_block, dict)
            and isinstance(composition_block.get("fractions"), dict)
        )
        n_target_sites = _infer_target_sites(payload) if uses_fractions else None
        groups = _scale_site_group_counts(
            _load_site_groups(payload),
            composition_total,
            n_target_sites,
        )
        solutions = _enumerate_feasible_allocations(
            composition,
            groups,
            max_solutions=20000,
        )
        if not solutions:
            return None
        return max(solutions, key=lambda by_site: _score_allocation(by_site, groups))
    except Exception:
        return None


def _run_generalized_allocation_swap(
    *,
    guide_result: GuideResult,
    effective_input_path: Path,
    allocation_meta: dict[str, Any],
    source_to_group: dict[str, str],
    charges_by_site: dict[str, float],
    default_charges: dict[str, float],
    max_swap: int,
    solve_time_budget_sec: float | None = None,
    mpi: dict[str, Any] | None = None,
) -> Any | None:
    try:
        payload = yaml.safe_load(effective_input_path.read_text()) or {}
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    allocation = payload.get("allocation")
    if not isinstance(allocation, dict):
        return None
    if allocation.get("generalized_swap", True) is False:
        return None
    site_groups_raw = payload.get("site_groups")
    if not isinstance(site_groups_raw, dict) or not site_groups_raw:
        return None

    from .solve_generalized_swap import (
        GeneralizedChargeEntry,
        GeneralizedElementCharge,
        GeneralizedSiteGroupRule,
        GeneralizedSwapOptions,
        compute_generalized_swap_loop,
    )

    group_rules: list[GeneralizedSiteGroupRule] = []
    for group_name, info in site_groups_raw.items():
        if not isinstance(info, dict):
            continue
        source = info.get("source_kind")
        allowed_raw = info.get("allowed", [])
        if source is None or not isinstance(allowed_raw, list):
            continue
        group_rules.append(
            GeneralizedSiteGroupRule(
                name=_normalize_site_group_label(str(group_name)),
                source_kind=str(source),
                allowed=[str(x) for x in allowed_raw if str(x).strip()],
            )
        )
    if not group_rules:
        return None

    site_charges: list[GeneralizedChargeEntry] = []
    for key, value in charges_by_site.items():
        norm = _normalize_site_charge_key(key)
        if "@" not in norm:
            continue
        kind, group = norm.split("@", 1)
        site_charges.append(
            GeneralizedChargeEntry(
                kind=kind,
                site_group=_normalize_site_group_label(group),
                oxidation=float(value),
            )
        )
    element_charges = [
        GeneralizedElementCharge(kind=str(kind), oxidation=float(value))
        for kind, value in default_charges.items()
    ]

    number_target = int(allocation_meta.get("number_target") or allocation.get("number_target") or 1)
    max_steps = int(allocation.get("max_steps_per_start", max(1, int(max_swap))))
    random_shuffle_steps = int(
        allocation.get(
            "random_shuffle_steps",
            max(16, len(guide_result.ready.atoms) * 4),
        )
    )
    seed = int(allocation_meta.get("seed") or allocation.get("seed") or 0)
    mpi_ctx = mpi or {"rank": 0, "size": 1, "comm": None}
    mpi_size = int(mpi_ctx.get("size", 1))
    mpi_rank = int(mpi_ctx.get("rank", 0))
    distribute = mpi_ctx.get("comm") is not None and mpi_size > 1
    configured_time_budget = allocation.get(
        "generalized_time_budget_sec",
        allocation.get("time_budget_sec"),
    )
    if solve_time_budget_sec is not None:
        time_budget_sec = float(solve_time_budget_sec)
        if configured_time_budget is not None:
            time_budget_sec = min(time_budget_sec, float(configured_time_budget))
    else:
        time_budget_sec = float(configured_time_budget or 0.0)

    result = compute_generalized_swap_loop(
        guide_result.ready,
        GeneralizedSwapOptions(
            number_starts=max(1, number_target),
            start_index_offset=mpi_rank if distribute else 0,
            start_index_stride=mpi_size if distribute else 1,
            max_steps_per_start=max(0, max_steps),
            random_shuffle_steps=max(0, random_shuffle_steps),
            rg_find_factor=int(guide_result.ready.rg_find_factor),
            chop_level=float(guide_result.ready.chop_level),
            time_budget_sec=max(0.0, time_budget_sec),
            seed=seed,
            site_groups=group_rules,
            element_charges=element_charges,
            site_charges=site_charges,
        ),
    )
    return _reduce_generalized_allocation_result(
        result,
        mpi_ctx,
        include_debug=bool(allocation_meta.get("debug")),
    )


def _composition_by_site_from_structure(
    structure,
    group_by_site: list[str],
) -> dict[str, dict[str, int]]:
    out: dict[str, dict[str, int]] = {}
    for site, group in zip(structure.sites, group_by_site):
        group_s = str(group)
        if not group_s:
            continue
        row = out.setdefault(group_s, {})
        row[str(site.kind)] = int(row.get(str(site.kind), 0)) + 1
    return out


def _normalize_composition_by_site(
    composition_by_site: Any,
) -> dict[str, dict[str, int]]:
    if not isinstance(composition_by_site, dict):
        return {}
    out: dict[str, dict[str, int]] = {}
    for group, row in composition_by_site.items():
        if not isinstance(row, dict):
            continue
        group_key = _normalize_site_group_label(str(group))
        clean: dict[str, int] = {}
        for elem, count in row.items():
            try:
                value = int(round(float(count)))
            except Exception:
                continue
            if value == 0:
                continue
            clean[str(elem)] = int(clean.get(str(elem), 0)) + value
        if clean:
            out[group_key] = dict(sorted(clean.items()))
    return dict(sorted(out.items()))


def _allocation_transfer_summary(
    initial_composition_by_site: Any,
    final_composition_by_site: Any,
) -> dict[str, Any]:
    """Summarize element movement between site groups.

    This compares two site-composition tables and reports the net amount of each
    element that moved from one site group to another.  Partial movement is
    represented directly by the net count, e.g. if Co changes from
    site2=7/site1=0 to site2=4/site1=3, the transfer is +3 from site2 to site1.
    """
    initial = _normalize_composition_by_site(initial_composition_by_site)
    final = _normalize_composition_by_site(final_composition_by_site)
    sites = sorted(set(initial) | set(final))
    elements = sorted(
        {
            elem
            for table in (initial, final)
            for row in table.values()
            for elem in row
        }
    )
    site_delta: dict[str, dict[str, int]] = {}
    transfers: list[dict[str, Any]] = []
    lines: list[str] = []

    for elem in elements:
        sources: list[list[Any]] = []
        sinks: list[list[Any]] = []
        for site in sites:
            delta = int(final.get(site, {}).get(elem, 0)) - int(
                initial.get(site, {}).get(elem, 0)
            )
            if delta:
                site_delta.setdefault(site, {})[elem] = delta
            if delta < 0:
                sources.append([site, -delta])
            elif delta > 0:
                sinks.append([site, delta])

        for source in sources:
            source_site, source_remaining = source
            if source_remaining <= 0:
                continue
            for sink in sinks:
                sink_site, sink_remaining = sink
                if sink_remaining <= 0:
                    continue
                amount = min(int(source_remaining), int(sink_remaining))
                if amount <= 0:
                    continue
                source[1] = int(source_remaining) - amount
                sink[1] = int(sink_remaining) - amount
                source_remaining = source[1]
                transfer = {
                    "element": elem,
                    "from_site": source_site,
                    "to_site": sink_site,
                    "count": amount,
                }
                transfers.append(transfer)
                lines.append(
                    f"{elem}: {source_site} -> {sink_site} net +{amount}"
                )
                if source_remaining <= 0:
                    break

    site_delta = {
        site: dict(sorted(row.items()))
        for site, row in sorted(site_delta.items())
    }
    return {
        "initial_composition_by_site": initial,
        "final_composition_by_site": final,
        "site_delta": site_delta,
        "transfers": transfers,
        "lines": lines,
        "summary": "; ".join(lines) if lines else "no cross-site element transfers",
    }


def _site_labels_from_ready(
    guide_result: GuideResult,
    source_to_group: dict[str, str],
    *,
    n_sites: int | None = None,
) -> list[str] | None:
    """Return source-site labels in ready atom order.

    Native ESS snapshots preserve the ready-site order while changing the kind
    assigned to each site.  This lets final POSCAR output keep the source site
    group label after a fixed-allocation or coupled-allocation solve.
    """
    if not source_to_group:
        return None
    labels = [
        source_to_group.get(str(atom.kind), "")
        for atom in guide_result.ready.atoms
    ]
    expansion = tuple(int(x) for x in guide_result.ready.supercell_expansion)
    multiplier = max(1, expansion[0] * expansion[1] * expansion[2])
    if multiplier > 1:
        labels = [
            label
            for _i in range(expansion[0])
            for _j in range(expansion[1])
            for _k in range(expansion[2])
            for label in labels
        ]
    if n_sites is not None and len(labels) != int(n_sites):
        return None
    if not any(labels):
        return None
    return labels


def _trajectory_payload_for_result(result, *, rank: int) -> dict[str, Any]:
    return {
        "rank": int(rank),
        "starts_evaluated": int(result.starts_evaluated),
        "accepted_moves": int(result.accepted_moves),
        "initial_energy": float(result.initial_energy),
        "best_energy": float(result.best_energy),
        "starts": [asdict(item) for item in result.starts],
        "accepted": [asdict(item) for item in result.accepted],
    }


def _write_allocation_trajectories_jsonl(path: Path, result) -> str:
    rank_payloads = getattr(result, "mpi_stats", {}).get("rank_trajectories")
    if not isinstance(rank_payloads, list) or not rank_payloads:
        rank_payloads = [_trajectory_payload_for_result(result, rank=0)]

    lines: list[str] = []
    for rank_payload in rank_payloads:
        if not isinstance(rank_payload, dict):
            continue
        rank = int(rank_payload.get("rank", 0))
        lines.append(
            json.dumps(
                {
                    "type": "rank_summary",
                    "rank": rank,
                    "starts_evaluated": rank_payload.get("starts_evaluated"),
                    "accepted_moves": rank_payload.get("accepted_moves"),
                    "initial_energy": rank_payload.get("initial_energy"),
                    "best_energy": rank_payload.get("best_energy"),
                },
                sort_keys=True,
            )
        )
        for start in rank_payload.get("starts", []) or []:
            lines.append(
                json.dumps(
                    {"type": "start", "rank": rank, **dict(start)},
                    sort_keys=True,
                )
            )
        for move in rank_payload.get("accepted", []) or []:
            lines.append(
                json.dumps(
                    {"type": "move", "rank": rank, **dict(move)},
                    sort_keys=True,
                )
            )
    path.write_text("\n".join(lines) + ("\n" if lines else ""))
    return str(path)


def _public_generalized_mpi_stats(result) -> dict[str, Any]:
    stats = dict(getattr(result, "mpi_stats", {}) or {})
    stats.pop("rank_trajectories", None)
    return stats


def _reduce_generalized_allocation_result(
    result,
    mpi: dict[str, Any],
    *,
    include_debug: bool = False,
):
    size = int(mpi.get("size", 1))
    rank = int(mpi.get("rank", 0))
    comm = mpi.get("comm")

    if comm is None or size <= 1:
        result.mpi_stats = {
            "world_size": size,
            "rank": rank,
            "distributed": False,
            "communication_available": comm is not None,
            "local_starts_evaluated": int(result.starts_evaluated),
            "total_starts_evaluated": int(result.starts_evaluated),
            "winning_rank": rank,
            "per_rank_starts_evaluated": [int(result.starts_evaluated)],
            "per_rank_best_energy": [float(result.best_energy)],
        }
        if include_debug:
            result.mpi_stats["rank_trajectories"] = [
                _trajectory_payload_for_result(result, rank=rank)
            ]
        return result

    gathered = comm.allgather(result)
    winner = result
    winning_rank = rank
    for idx, candidate in enumerate(gathered):
        energy = float(getattr(candidate, "best_energy", float("inf")))
        if int(getattr(candidate, "starts_evaluated", 0)) <= 0:
            continue
        if not math.isfinite(energy):
            continue
        best_energy = float(getattr(winner, "best_energy", float("inf")))
        if (
            int(getattr(winner, "starts_evaluated", 0)) <= 0
            or not math.isfinite(best_energy)
            or energy < best_energy
        ):
            winner = candidate
            winning_rank = idx

    winner.mpi_stats = {
        "world_size": size,
        "rank": rank,
        "distributed": True,
        "communication_available": True,
        "local_starts_evaluated": int(result.starts_evaluated),
        "total_starts_evaluated": sum(
            int(getattr(item, "starts_evaluated", 0)) for item in gathered
        ),
        "winning_rank": winning_rank,
        "per_rank_starts_evaluated": [
            int(getattr(item, "starts_evaluated", 0)) for item in gathered
        ],
        "per_rank_best_energy": [
            float(getattr(item, "best_energy", float("inf"))) for item in gathered
        ],
    }
    if include_debug:
        winner.mpi_stats["rank_trajectories"] = [
            _trajectory_payload_for_result(item, rank=idx)
            for idx, item in enumerate(gathered)
        ]
    return winner


def _canonical_allocation_key(composition_by_site: Any) -> str:
    normalized = _normalize_composition_by_site(composition_by_site)
    return json.dumps(normalized, sort_keys=True, separators=(",", ":"))


def _portfolio_candidate_allocations(
    payload: dict[str, Any],
) -> tuple[list[dict[str, dict[str, int]]], list[Any]]:
    """Generate deterministic feasible allocation starts for portfolio search."""
    from .allocation_optimize import (
        _enumerate_feasible_allocations,
        _infer_target_sites,
        _load_composition_counts,
        _load_site_groups,
        _scale_site_group_counts,
        _score_allocation,
    )

    composition = _load_composition_counts(payload)
    composition_total = int(sum(composition.values()))
    composition_block = payload.get("composition")
    uses_fractions = (
        isinstance(composition_block, dict)
        and isinstance(composition_block.get("fractions"), dict)
    )
    n_target_sites = _infer_target_sites(payload) if uses_fractions else None
    groups = _scale_site_group_counts(
        _load_site_groups(payload),
        composition_total,
        n_target_sites,
    )
    solutions = _enumerate_feasible_allocations(
        composition,
        groups,
        max_solutions=None,
    )
    if not solutions:
        raise ValueError("No feasible site allocation found for portfolio_ess.")

    # Put a source-affinity start first, then retain deterministic diverse
    # enumeration order.  This gives the loop a stable initial A while still
    # allowing immediate alternatives.
    scored = sorted(
        solutions,
        key=lambda item: (-_score_allocation(item, groups), _canonical_allocation_key(item)),
    )
    ordered: list[dict[str, dict[str, int]]] = []
    seen: set[str] = set()
    for candidate in scored[:1] + solutions:
        normalized = _normalize_composition_by_site(candidate)
        key = _canonical_allocation_key(normalized)
        if key in seen:
            continue
        seen.add(key)
        ordered.append(normalized)
    return ordered, groups


def _proposal_neighbors_for_allocation(
    current: dict[str, dict[str, int]],
    groups: list[Any],
    *,
    max_proposals: int,
) -> list[dict[str, dict[str, int]]]:
    """Propose allocation-changing cross-site count exchanges.

    Each move exchanges one count of element e1 on site A with one count of
    element e2 on site B.  This preserves global composition and both site
    capacities while allowing partial transfers such as Co site-002 -> site-001
    net +3 over multiple accepted moves.
    """
    normalized = _normalize_composition_by_site(current)
    allowed_by_site = {
        _normalize_site_group_label(str(g.name)): {str(x) for x in g.allowed}
        for g in groups
    }
    sites = sorted(normalized)
    out: list[dict[str, dict[str, int]]] = []
    seen: set[str] = set()

    def _add(candidate: dict[str, dict[str, int]]) -> None:
        clean = _normalize_composition_by_site(candidate)
        key = _canonical_allocation_key(clean)
        if key in seen or key == _canonical_allocation_key(normalized):
            return
        seen.add(key)
        out.append(clean)

    for i, site_a in enumerate(sites):
        for site_b in sites[i + 1 :]:
            row_a = normalized.get(site_a, {})
            row_b = normalized.get(site_b, {})
            allowed_a = allowed_by_site.get(site_a, set())
            allowed_b = allowed_by_site.get(site_b, set())
            for elem_a in sorted(row_a):
                if int(row_a.get(elem_a, 0)) <= 0:
                    continue
                for elem_b in sorted(row_b):
                    if elem_a == elem_b:
                        continue
                    if int(row_b.get(elem_b, 0)) <= 0:
                        continue
                    if elem_a not in allowed_b or elem_b not in allowed_a:
                        continue
                    candidate = copy.deepcopy(normalized)
                    candidate[site_a][elem_a] -= 1
                    candidate[site_b][elem_b] -= 1
                    if candidate[site_a][elem_a] <= 0:
                        candidate[site_a].pop(elem_a, None)
                    if candidate[site_b][elem_b] <= 0:
                        candidate[site_b].pop(elem_b, None)
                    candidate[site_a][elem_b] = int(candidate[site_a].get(elem_b, 0)) + 1
                    candidate[site_b][elem_a] = int(candidate[site_b].get(elem_a, 0)) + 1
                    _add(candidate)
                    if len(out) >= int(max_proposals):
                        return out
    return out


def _portfolio_early_stop_patience_sec(
    allocation: dict[str, Any],
    *,
    solve_time_budget_sec: float | None,
) -> float | None:
    if not bool(allocation.get("early_stop", True)):
        return None
    raw = allocation.get("early_stop_patience_sec", allocation.get("patience_sec"))
    if raw is None:
        if solve_time_budget_sec is None or float(solve_time_budget_sec) <= 0.0:
            return None
        raw = max(10.0, min(300.0, float(solve_time_budget_sec) * 0.35))
    try:
        value = float(raw)
    except Exception:
        return None
    if value <= 0.0:
        return None
    return value


def _rough_solve_allocation_candidate(
    *,
    guide_result: GuideResult,
    payload: dict[str, Any],
    composition_by_site: dict[str, dict[str, int]],
    source_to_group: dict[str, str],
    charges_by_site: dict[str, float],
    default_charges: dict[str, float],
    base_solve_options,
    runtime,
    budget_sec: float,
    max_swap: int,
    force_serial: bool = False,
) -> dict[str, Any]:
    """Score one fixed allocation using a short standard ESS solve."""
    local_guide = copy.deepcopy(guide_result)
    local_payload = dict(payload)
    local_payload["composition_by_site"] = composition_by_site
    sitewise_meta = _apply_sitewise_composition_payload_to_ready(
        local_guide,
        local_payload,
        source_to_group=source_to_group,
        charges_by_site=charges_by_site,
        default_charges=default_charges,
    )
    if not sitewise_meta.get("applied"):
        raise ValueError("portfolio_ess failed to apply fixed allocation to ready model")

    seconds = max(1, int(math.ceil(float(budget_sec or 1.0))))
    rough_options = replace(
        base_solve_options,
        running_index_delta=-seconds,
        adaptive_stride_scale_secondary=False,
        swap=True,
        max_swap=max(0, int(max_swap)),
        progress_include_best_structure=False,
    )
    solve_ready = ready_with_legacy_text_precision(local_guide.ready)
    result = solve(
        SolveInput(
            ready=solve_ready,
            options=rough_options,
            runtime=runtime,
        ),
        force_serial=force_serial,
    )
    best_energy = float(result.summary.global_e_min)
    if result.best is not None:
        best_energy = float(result.best.energy)
    best_structure = result.best.structure if result.best is not None else None
    site_labels = None
    if best_structure is not None:
        site_labels = _site_labels_from_ready(
            local_guide,
            source_to_group,
            n_sites=len(best_structure.sites),
        )
    return {
        "energy": best_energy,
        "solve_result": result,
        "best_structure": best_structure,
        "site_labels": site_labels,
        "sitewise_apply": sitewise_meta,
        "evaluated_candidates": int(result.energy_table.count),
        "accepted_swaps": int(
            result.mpi_stats.get(
                "global_swap_count",
                result.local_reduction.local_swap_count,
            )
        ),
    }


def _portfolio_worker_result_from_evaluation(
    *,
    index: int,
    worker_rank: int,
    composition_by_site: dict[str, dict[str, int]],
    evaluation: dict[str, Any],
) -> dict[str, Any]:
    best_structure = evaluation.get("best_structure")
    return {
        "ok": True,
        "index": int(index),
        "worker_rank": int(worker_rank),
        "score": float(evaluation["energy"]),
        "composition_by_site": _normalize_composition_by_site(composition_by_site),
        "evaluated_candidates": int(evaluation.get("evaluated_candidates") or 0),
        "accepted_swaps": int(evaluation.get("accepted_swaps") or 0),
        "best_structure": asdict(best_structure) if best_structure is not None else None,
        "site_labels": evaluation.get("site_labels"),
        "sitewise_apply": evaluation.get("sitewise_apply"),
    }


def _portfolio_evaluation_from_worker_result(result: dict[str, Any]) -> dict[str, Any]:
    best_structure = None
    structure_payload = result.get("best_structure")
    if isinstance(structure_payload, dict):
        best_structure = structure_from_dict(structure_payload)
    return {
        "energy": float(result["score"]),
        "best_structure": best_structure,
        "site_labels": result.get("site_labels"),
        "sitewise_apply": result.get("sitewise_apply"),
        "evaluated_candidates": int(result.get("evaluated_candidates") or 0),
        "accepted_swaps": int(result.get("accepted_swaps") or 0),
    }


def _portfolio_public_result(result: dict[str, Any] | None) -> dict[str, Any] | None:
    if result is None:
        return None
    return {
        key: value
        for key, value in result.items()
        if key not in {"best_structure", "site_labels"}
    }


def _portfolio_wire_result(result: dict[str, Any] | None) -> dict[str, Any] | None:
    if result is None:
        return None
    payload = dict(result)
    best_structure = payload.get("best_structure")
    if best_structure is not None:
        payload["best_structure"] = asdict(best_structure)
    return payload


def _portfolio_result_from_wire(result: dict[str, Any] | None) -> dict[str, Any] | None:
    if result is None:
        return None
    payload = dict(result)
    best_structure = payload.get("best_structure")
    if isinstance(best_structure, dict):
        payload["best_structure"] = structure_from_dict(best_structure)
    return payload


def _run_portfolio_allocation_search_rank_local(
    *,
    guide_result: GuideResult,
    effective_payload: dict[str, Any],
    allocation_meta: dict[str, Any],
    source_to_group: dict[str, str],
    charges_by_site: dict[str, float],
    default_charges: dict[str, float],
    base_solve_options,
    runtime,
    solve_time_budget_sec: float | None,
    max_swap: int,
    reporter: ProgressReporter,
    mpi: dict[str, Any],
) -> dict[str, Any] | None:
    """Evaluate rough allocation candidates independently on worker ranks."""
    comm = mpi.get("comm") if isinstance(mpi, dict) else None
    size = int(mpi.get("size") or 1) if isinstance(mpi, dict) else 1
    rank = int(mpi.get("rank") or 0) if isinstance(mpi, dict) else 0
    if comm is None or size <= 1:
        return None

    tag_work = 44010
    tag_stop = 44011
    tag_result = 44012

    allocation = effective_payload.get("allocation")
    if not isinstance(allocation, dict):
        if rank == 0:
            for worker in range(1, size):
                comm.send(None, dest=worker, tag=tag_stop)
            comm.bcast(None, root=0)
        else:
            comm.bcast(None, root=0)
        return None

    seed = int(allocation_meta.get("seed") or allocation.get("seed") or 0)
    rng = random.Random(seed)
    rough_max_swap = int(allocation.get("rough_max_swap", min(max(1, int(max_swap)), 50)))
    proposals_per_parent = max(1, int(allocation.get("proposals_per_parent", 12)))
    final_candidates = max(1, int(allocation.get("final_candidates", 1)))
    accept_worse_probability = float(allocation.get("accept_worse_probability", 0.0) or 0.0)
    accept_worse_probability = max(0.0, min(1.0, accept_worse_probability))
    configured_rough_sec = allocation.get("rough_ess_time_sec")
    if configured_rough_sec is not None:
        rough_sec = max(1.0, float(configured_rough_sec))
    elif solve_time_budget_sec and solve_time_budget_sec > 0:
        rough_sec = max(
            1.0,
            min(
                10.0,
                float(solve_time_budget_sec)
                / max(2.0, float(1000 + final_candidates)),
            ),
        )
    else:
        rough_sec = 3.0
    configured_final_sec = allocation.get("final_refine_time_sec")
    if configured_final_sec is not None:
        final_sec = max(1.0, float(configured_final_sec))
    else:
        final_sec = max(1.0, min(30.0, rough_sec * 3.0))

    def _worker_loop() -> dict[str, Any] | None:
        while True:
            status = None
            try:
                from mpi4py import MPI  # type: ignore

                status = MPI.Status()
                task = comm.recv(source=0, tag=MPI.ANY_TAG, status=status)
                received_tag = int(status.Get_tag())
            except Exception:
                task = comm.recv(source=0)
                received_tag = tag_work
            if received_tag == tag_stop:
                break
            if not isinstance(task, dict):
                continue
            index = int(task.get("index") or 0)
            candidate = _normalize_composition_by_site(task.get("composition_by_site"))
            try:
                evaluation = _rough_solve_allocation_candidate(
                    guide_result=guide_result,
                    payload=effective_payload,
                    composition_by_site=candidate,
                    source_to_group=source_to_group,
                    charges_by_site=charges_by_site,
                    default_charges=default_charges,
                    base_solve_options=base_solve_options,
                    runtime=runtime,
                    budget_sec=float(task.get("budget_sec") or rough_sec),
                    max_swap=int(task.get("max_swap") or rough_max_swap),
                    force_serial=True,
                )
                result = _portfolio_worker_result_from_evaluation(
                    index=index,
                    worker_rank=rank,
                    composition_by_site=candidate,
                    evaluation=evaluation,
                )
            except Exception as exc:
                result = {
                    "ok": False,
                    "index": index,
                    "worker_rank": rank,
                    "composition_by_site": candidate,
                    "error": str(exc),
                }
            comm.send(result, dest=0, tag=tag_result)
        return _portfolio_result_from_wire(comm.bcast(None, root=0))

    if rank != 0:
        return _worker_loop()

    try:
        candidates, groups = _portfolio_candidate_allocations(effective_payload)
    except Exception:
        for worker in range(1, size):
            comm.send(None, dest=worker, tag=tag_stop)
        comm.bcast(None, root=0)
        raise
    if not candidates:
        for worker in range(1, size):
            comm.send(None, dest=worker, tag=tag_stop)
        comm.bcast(None, root=0)
        return None

    started = time.monotonic()
    deadline = None
    if solve_time_budget_sec is not None and float(solve_time_budget_sec) > 0:
        deadline = started + max(0.0, float(solve_time_budget_sec))

    workers = list(range(1, size))
    per_rank_evaluated = [0 for _ in range(size)]
    failures: list[dict[str, Any]] = []
    stop_reason = "queue_exhausted"
    patience_sec = _portfolio_early_stop_patience_sec(
        allocation,
        solve_time_budget_sec=solve_time_budget_sec,
    )
    patience_min_evals = int(
        allocation.get(
            "early_stop_min_evaluations",
            max(10, len(workers) * 5),
        )
    )

    reporter.emit(
        "allocation.portfolio.started",
        candidates=len(candidates),
        time_budget_sec=solve_time_budget_sec,
        rough_ess_time_sec=rough_sec,
        rough_max_swap=rough_max_swap,
        final_candidates=final_candidates,
        final_refine_time_sec=final_sec,
        rough_parallel="rank_local",
        worker_ranks=workers,
    )

    evaluated_keys: set[str] = set()
    queued_keys: set[str] = set()
    queue: list[dict[str, dict[str, int]]] = []
    for candidate in candidates:
        key = _canonical_allocation_key(candidate)
        if key in queued_keys:
            continue
        queued_keys.add(key)
        queue.append(candidate)

    current: dict[str, dict[str, int]] | None = queue[0]
    current_energy = float("inf")
    best: dict[str, Any] | None = None
    best_updated_at = started
    leaderboard: list[dict[str, Any]] = []
    eval_index = 0

    def _dispatch_batch(
        *,
        candidates_for_batch: list[dict[str, dict[str, int]]],
        start_index: int,
        budget_sec: float,
        max_swap_for_eval: int,
        total: int,
        stage: str,
    ) -> list[dict[str, Any]]:
        active: list[int] = []
        for offset, (worker, candidate) in enumerate(
            zip(workers, candidates_for_batch),
            start=1,
        ):
            index = start_index + offset
            if stage == "rough":
                reporter.emit(
                    "allocation.portfolio.eval_started",
                    index=index,
                    total=total,
                    rough_ess_time_sec=budget_sec,
                    composition_by_site=candidate,
                    worker_rank=worker,
                )
            else:
                reporter.emit(
                    "allocation.portfolio.refine_started",
                    index=index,
                    total=total,
                    refine_time_sec=budget_sec,
                    composition_by_site=candidate,
                    worker_rank=worker,
                )
            comm.send(
                {
                    "index": index,
                    "composition_by_site": candidate,
                    "budget_sec": float(budget_sec),
                    "max_swap": int(max_swap_for_eval),
                    "stage": stage,
                },
                dest=worker,
                tag=tag_work,
            )
            active.append(worker)
        results: list[dict[str, Any]] = []
        for _ in active:
            try:
                from mpi4py import MPI  # type: ignore

                status = MPI.Status()
                result = comm.recv(
                    source=MPI.ANY_SOURCE,
                    tag=tag_result,
                    status=status,
                )
            except Exception:
                result = comm.recv()
            if isinstance(result, dict):
                worker_rank = int(result.get("worker_rank") or 0)
                if 0 <= worker_rank < len(per_rank_evaluated):
                    per_rank_evaluated[worker_rank] += 1
                results.append(result)
        results.sort(key=lambda item: int(item.get("index") or 0))
        return results

    try:
        while queue:
            if deadline is not None and time.monotonic() + max(0.25, rough_sec) > deadline:
                stop_reason = "time_budget"
                break
            if (
                patience_sec is not None
                and best is not None
                and eval_index >= patience_min_evals
                and (time.monotonic() - best_updated_at) >= patience_sec
            ):
                stop_reason = "early_stop_no_improvement"
                break
            batch: list[dict[str, dict[str, int]]] = []
            while (
                queue
                and len(batch) < len(workers)
            ):
                candidate = queue.pop(0)
                key = _canonical_allocation_key(candidate)
                if key in evaluated_keys:
                    continue
                evaluated_keys.add(key)
                batch.append(candidate)
            if not batch:
                stop_reason = "queue_exhausted"
                break
            batch_start_index = eval_index
            results = _dispatch_batch(
                candidates_for_batch=batch,
                start_index=batch_start_index,
                budget_sec=rough_sec,
                max_swap_for_eval=rough_max_swap,
                total=len(candidates),
                stage="rough",
            )
            for result in results:
                eval_index += 1
                candidate = _normalize_composition_by_site(
                    result.get("composition_by_site")
                )
                if not result.get("ok"):
                    failures.append(
                        {
                            "index": int(result.get("index") or eval_index),
                            "worker_rank": result.get("worker_rank"),
                            "error": result.get("error"),
                            "composition_by_site": candidate,
                        }
                    )
                    reporter.emit(
                        "allocation.portfolio.eval_done",
                        index=eval_index,
                        total=len(candidates),
                        score=None,
                        accepted_as_current=False,
                        error=result.get("error"),
                        composition_by_site=candidate,
                    )
                    continue
                evaluation = _portfolio_evaluation_from_worker_result(result)
                score = float(evaluation["energy"])
                accepted = False
                if score < current_energy:
                    current = candidate
                    current_energy = score
                    accepted = True
                elif accept_worse_probability > 0.0 and rng.random() < accept_worse_probability:
                    current = candidate
                    current_energy = score
                    accepted = True

                entry = {
                    "rank": 0,
                    "index": eval_index,
                    "worker_rank": int(result.get("worker_rank") or 0),
                    "allocation_id": f"alloc-{eval_index:06d}",
                    "score": score,
                    "accepted_as_current": accepted,
                    "composition_by_site": candidate,
                    "evaluated_candidates": evaluation.get("evaluated_candidates"),
                    "accepted_swaps": evaluation.get("accepted_swaps"),
                }
                leaderboard.append(entry)
                leaderboard.sort(key=lambda item: float(item.get("score", float("inf"))))
                for rank_idx, item in enumerate(leaderboard, start=1):
                    item["rank"] = rank_idx

                if best is None or score < float(best["score"]):
                    best_updated_at = time.monotonic()
                    best = {
                        **entry,
                        "best_structure": evaluation.get("best_structure"),
                        "site_labels": evaluation.get("site_labels"),
                        "sitewise_apply": evaluation.get("sitewise_apply"),
                    }
                    reporter.emit(
                        "allocation.portfolio.best_updated",
                        index=eval_index,
                        score=score,
                        composition_by_site=candidate,
                        worker_rank=result.get("worker_rank"),
                    )

                reporter.emit(
                    "allocation.portfolio.eval_done",
                    index=eval_index,
                    total=len(candidates),
                    score=score,
                    accepted_as_current=accepted,
                    best_score=float(leaderboard[0]["score"]),
                    evaluated_candidates=evaluation.get("evaluated_candidates"),
                    accepted_swaps=evaluation.get("accepted_swaps"),
                    composition_by_site=candidate,
                    worker_rank=result.get("worker_rank"),
                )

                if accepted and current is not None:
                    for proposal in _proposal_neighbors_for_allocation(
                        current,
                        groups,
                        max_proposals=proposals_per_parent,
                    ):
                        proposal_key = _canonical_allocation_key(proposal)
                        if proposal_key in evaluated_keys or proposal_key in queued_keys:
                            continue
                        queued_keys.add(proposal_key)
                        queue.append(proposal)

        refined: list[dict[str, Any]] = []
        if leaderboard:
            refine_inputs = leaderboard[: min(final_candidates, len(leaderboard))]
            refine_index = 0
            while refine_index < len(refine_inputs):
                if deadline is not None and time.monotonic() + max(0.25, final_sec) > deadline:
                    break
                chunk = refine_inputs[refine_index : refine_index + len(workers)]
                candidates_for_batch = [
                    _normalize_composition_by_site(item["composition_by_site"])
                    for item in chunk
                ]
                results = _dispatch_batch(
                    candidates_for_batch=candidates_for_batch,
                    start_index=refine_index,
                    budget_sec=final_sec,
                    max_swap_for_eval=max(rough_max_swap, int(max_swap)),
                    total=len(refine_inputs),
                    stage="refine",
                )
                for result in results:
                    idx = int(result.get("index") or 0)
                    base_idx = max(0, min(idx - 1, len(refine_inputs) - 1))
                    base_item = refine_inputs[base_idx]
                    candidate = _normalize_composition_by_site(
                        result.get("composition_by_site")
                    )
                    if not result.get("ok"):
                        failures.append(
                            {
                                "index": idx,
                                "worker_rank": result.get("worker_rank"),
                                "stage": "refine",
                                "error": result.get("error"),
                                "composition_by_site": candidate,
                            }
                        )
                        continue
                    evaluation = _portfolio_evaluation_from_worker_result(result)
                    refined_entry = {
                        **base_item,
                        "refined_score": float(evaluation["energy"]),
                        "refined_evaluated_candidates": evaluation.get(
                            "evaluated_candidates"
                        ),
                        "refined_accepted_swaps": evaluation.get("accepted_swaps"),
                        "best_structure": evaluation.get("best_structure"),
                        "site_labels": evaluation.get("site_labels"),
                        "sitewise_apply": evaluation.get("sitewise_apply"),
                    }
                    refined.append(refined_entry)
                    reporter.emit(
                        "allocation.portfolio.refine_done",
                        index=idx,
                        total=len(refine_inputs),
                        score=float(evaluation["energy"]),
                        composition_by_site=candidate,
                        worker_rank=result.get("worker_rank"),
                    )
                refine_index += len(chunk)

        if refined:
            refined.sort(
                key=lambda item: float(
                    item.get("refined_score", item.get("score", float("inf")))
                )
            )
            best = {
                **refined[0],
                "score": float(refined[0].get("refined_score", refined[0].get("score"))),
            }

        result_payload: dict[str, Any] | None = None
        if best is not None:
            best_by_site = _normalize_composition_by_site(best["composition_by_site"])
            elapsed = max(0.0, time.monotonic() - started)
            transfer_summary = _allocation_transfer_summary(
                allocation_meta.get("initial_composition_by_site"),
                best_by_site,
            )
            public_leaderboard = [
                {
                    key: value
                    for key, value in item.items()
                    if key not in {"best_structure", "site_labels", "sitewise_apply"}
                }
                for item in leaderboard[: min(20, len(leaderboard))]
            ]
            result_payload = {
                "mode": "portfolio_ess",
                "optimizer": "rank_local_rough_ess",
                "rough_parallel": "rank_local",
                "evaluated_allocations": eval_index,
                "unique_allocations": len(evaluated_keys),
                "rough_ess_time_sec": rough_sec,
                "rough_max_swap": rough_max_swap,
                "final_candidates": final_candidates,
                "final_refine_time_sec": final_sec,
                "elapsed_sec": elapsed,
                "stop_reason": stop_reason,
                "early_stop_patience_sec": patience_sec,
                "early_stop_min_evaluations": patience_min_evals,
                "best_score": float(best["score"]),
                "best_composition_by_site": best_by_site,
                "transfer_summary": transfer_summary,
                "leaderboard": public_leaderboard,
                "best_structure": best.get("best_structure"),
                "site_labels": best.get("site_labels"),
                "mpi": {
                    "distributed": True,
                    "world_size": size,
                    "worker_ranks": workers,
                    "per_rank_evaluated": per_rank_evaluated,
                    "failed_allocations": len(failures),
                    "failures": failures[:20],
                },
            }
            reporter.emit(
                "allocation.portfolio.done",
                evaluated_allocations=eval_index,
                unique_allocations=len(evaluated_keys),
                best_score=float(best["score"]),
                elapsed_sec=elapsed,
                stop_reason=stop_reason,
                time_budget_sec=solve_time_budget_sec,
                composition_by_site=best_by_site,
                rough_parallel="rank_local",
                per_rank_evaluated=per_rank_evaluated,
            )
        return result_payload
    finally:
        for worker in workers:
            comm.send(None, dest=worker, tag=tag_stop)
        result_for_workers = locals().get("result_payload", None)
        comm.bcast(_portfolio_wire_result(result_for_workers), root=0)


def _run_portfolio_allocation_search(
    *,
    guide_result: GuideResult,
    effective_payload: dict[str, Any],
    allocation_meta: dict[str, Any],
    source_to_group: dict[str, str],
    charges_by_site: dict[str, float],
    default_charges: dict[str, float],
    base_solve_options,
    runtime,
    solve_time_budget_sec: float | None,
    max_swap: int,
    reporter: ProgressReporter,
    mpi: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Prototype portfolio allocation search.

    All MPI ranks execute the same candidate sequence and call the same native
    fixed-allocation ESS solve for each candidate.  This keeps the first
    implementation compatible with the native solver's MPI collectives.
    """
    if not isinstance(effective_payload, dict):
        return None
    allocation = effective_payload.get("allocation")
    if not isinstance(allocation, dict):
        return None

    rough_parallel = str(allocation.get("rough_parallel", "rank_local")).strip().lower()
    if (
        rough_parallel in {"rank_local", "mpi_rank_local", "distributed"}
        and isinstance(mpi, dict)
        and mpi.get("comm") is not None
        and int(mpi.get("size") or 1) > 1
    ):
        return _run_portfolio_allocation_search_rank_local(
            guide_result=guide_result,
            effective_payload=effective_payload,
            allocation_meta=allocation_meta,
            source_to_group=source_to_group,
            charges_by_site=charges_by_site,
            default_charges=default_charges,
            base_solve_options=base_solve_options,
            runtime=runtime,
            solve_time_budget_sec=solve_time_budget_sec,
            max_swap=max_swap,
            reporter=reporter,
            mpi=mpi,
        )

    seed = int(allocation_meta.get("seed") or allocation.get("seed") or 0)
    rng = random.Random(seed)
    rough_max_swap = int(allocation.get("rough_max_swap", min(max(1, int(max_swap)), 50)))
    proposals_per_parent = max(1, int(allocation.get("proposals_per_parent", 12)))
    final_candidates = max(1, int(allocation.get("final_candidates", 1)))
    accept_worse_probability = float(allocation.get("accept_worse_probability", 0.0) or 0.0)
    accept_worse_probability = max(0.0, min(1.0, accept_worse_probability))
    configured_rough_sec = allocation.get("rough_ess_time_sec")
    if configured_rough_sec is not None:
        rough_sec = max(1.0, float(configured_rough_sec))
    elif solve_time_budget_sec and solve_time_budget_sec > 0:
        rough_sec = max(1.0, min(10.0, float(solve_time_budget_sec) / max(2.0, float(1000 + final_candidates))))
    else:
        rough_sec = 3.0
    configured_final_sec = allocation.get("final_refine_time_sec")
    if configured_final_sec is not None:
        final_sec = max(1.0, float(configured_final_sec))
    else:
        final_sec = max(1.0, min(30.0, rough_sec * 3.0))
    patience_sec = _portfolio_early_stop_patience_sec(
        allocation,
        solve_time_budget_sec=solve_time_budget_sec,
    )
    patience_min_evals = int(
        allocation.get("early_stop_min_evaluations", 10)
    )

    candidates, groups = _portfolio_candidate_allocations(effective_payload)
    if not candidates:
        return None

    started = time.monotonic()
    deadline = None
    if solve_time_budget_sec is not None and float(solve_time_budget_sec) > 0:
        deadline = started + max(0.0, float(solve_time_budget_sec))

    reporter.emit(
        "allocation.portfolio.started",
        candidates=len(candidates),
        time_budget_sec=solve_time_budget_sec,
        rough_ess_time_sec=rough_sec,
        rough_max_swap=rough_max_swap,
        final_candidates=final_candidates,
        final_refine_time_sec=final_sec,
    )

    evaluated_keys: set[str] = set()
    queue: list[dict[str, dict[str, int]]] = list(candidates)
    current: dict[str, dict[str, int]] | None = queue[0]
    current_energy = float("inf")
    best: dict[str, Any] | None = None
    best_updated_at = started
    leaderboard: list[dict[str, Any]] = []
    eval_index = 0
    stop_reason = "queue_exhausted"

    while queue:
        if deadline is not None and time.monotonic() + max(0.25, rough_sec) > deadline:
            stop_reason = "time_budget"
            break
        if (
            patience_sec is not None
            and best is not None
            and eval_index >= patience_min_evals
            and (time.monotonic() - best_updated_at) >= patience_sec
        ):
            stop_reason = "early_stop_no_improvement"
            break
        candidate = queue.pop(0)
        key = _canonical_allocation_key(candidate)
        if key in evaluated_keys:
            continue
        evaluated_keys.add(key)
        eval_index += 1

        reporter.emit(
            "allocation.portfolio.eval_started",
            index=eval_index,
            total=len(candidates),
            rough_ess_time_sec=rough_sec,
            composition_by_site=candidate,
        )
        evaluation = _rough_solve_allocation_candidate(
            guide_result=guide_result,
            payload=effective_payload,
            composition_by_site=candidate,
            source_to_group=source_to_group,
            charges_by_site=charges_by_site,
            default_charges=default_charges,
            base_solve_options=base_solve_options,
            runtime=runtime,
            budget_sec=rough_sec,
            max_swap=rough_max_swap,
        )
        score = float(evaluation["energy"])
        accepted = False
        if score < current_energy:
            current = candidate
            current_energy = score
            accepted = True
        elif accept_worse_probability > 0.0 and rng.random() < accept_worse_probability:
            current = candidate
            current_energy = score
            accepted = True

        entry = {
            "rank": 0,
            "index": eval_index,
            "allocation_id": f"alloc-{eval_index:06d}",
            "score": score,
            "accepted_as_current": accepted,
            "composition_by_site": _normalize_composition_by_site(candidate),
            "evaluated_candidates": evaluation.get("evaluated_candidates"),
            "accepted_swaps": evaluation.get("accepted_swaps"),
        }
        leaderboard.append(entry)
        leaderboard.sort(key=lambda item: float(item.get("score", float("inf"))))
        for rank_idx, item in enumerate(leaderboard, start=1):
            item["rank"] = rank_idx

        if best is None or score < float(best["score"]):
            best_updated_at = time.monotonic()
            best = {
                **entry,
                "best_structure": evaluation.get("best_structure"),
                "site_labels": evaluation.get("site_labels"),
                "sitewise_apply": evaluation.get("sitewise_apply"),
            }
            reporter.emit(
                "allocation.portfolio.best_updated",
                index=eval_index,
                score=score,
                composition_by_site=candidate,
            )

        reporter.emit(
            "allocation.portfolio.eval_done",
            index=eval_index,
            total=len(candidates),
            score=score,
            accepted_as_current=accepted,
            best_score=float(leaderboard[0]["score"]),
            evaluated_candidates=evaluation.get("evaluated_candidates"),
            accepted_swaps=evaluation.get("accepted_swaps"),
            composition_by_site=candidate,
        )

        if accepted and current is not None:
            proposals = _proposal_neighbors_for_allocation(
                current,
                groups,
                max_proposals=proposals_per_parent,
            )
            for proposal in proposals:
                proposal_key = _canonical_allocation_key(proposal)
                if proposal_key in evaluated_keys:
                    continue
                if any(_canonical_allocation_key(item) == proposal_key for item in queue):
                    continue
                queue.append(proposal)

    refined: list[dict[str, Any]] = []
    if leaderboard:
        refine_inputs = leaderboard[: min(final_candidates, len(leaderboard))]
        for refine_idx, item in enumerate(refine_inputs, start=1):
            if deadline is not None and time.monotonic() + max(0.25, final_sec) > deadline:
                break
            candidate = item["composition_by_site"]
            reporter.emit(
                "allocation.portfolio.refine_started",
                index=refine_idx,
                total=len(refine_inputs),
                refine_time_sec=final_sec,
                score=item.get("score"),
                composition_by_site=candidate,
            )
            evaluation = _rough_solve_allocation_candidate(
                guide_result=guide_result,
                payload=effective_payload,
                composition_by_site=candidate,
                source_to_group=source_to_group,
                charges_by_site=charges_by_site,
                default_charges=default_charges,
                base_solve_options=base_solve_options,
                runtime=runtime,
                budget_sec=final_sec,
                max_swap=max(rough_max_swap, int(max_swap)),
            )
            refined_entry = {
                **item,
                "refined_score": float(evaluation["energy"]),
                "refined_evaluated_candidates": evaluation.get("evaluated_candidates"),
                "refined_accepted_swaps": evaluation.get("accepted_swaps"),
                "best_structure": evaluation.get("best_structure"),
                "site_labels": evaluation.get("site_labels"),
                "sitewise_apply": evaluation.get("sitewise_apply"),
            }
            refined.append(refined_entry)
            reporter.emit(
                "allocation.portfolio.refine_done",
                index=refine_idx,
                total=len(refine_inputs),
                score=float(evaluation["energy"]),
                composition_by_site=candidate,
            )

    if refined:
        refined.sort(key=lambda item: float(item.get("refined_score", item.get("score", float("inf")))))
        best = {
            **refined[0],
            "score": float(refined[0].get("refined_score", refined[0].get("score"))),
        }

    if best is None:
        return None

    best_by_site = _normalize_composition_by_site(best["composition_by_site"])
    elapsed = max(0.0, time.monotonic() - started)
    transfer_summary = _allocation_transfer_summary(
        allocation_meta.get("initial_composition_by_site"),
        best_by_site,
    )
    public_leaderboard = [
        {
            key: value
            for key, value in item.items()
            if key not in {"best_structure", "site_labels", "sitewise_apply"}
        }
        for item in leaderboard[: min(20, len(leaderboard))]
    ]
    result = {
        "mode": "portfolio_ess",
        "optimizer": "sequential_rough_ess",
        "rough_parallel": "all_ranks",
        "evaluated_allocations": eval_index,
        "unique_allocations": len(evaluated_keys),
        "rough_ess_time_sec": rough_sec,
        "rough_max_swap": rough_max_swap,
        "final_candidates": final_candidates,
        "final_refine_time_sec": final_sec,
        "elapsed_sec": elapsed,
        "stop_reason": stop_reason,
        "early_stop_patience_sec": patience_sec,
        "early_stop_min_evaluations": patience_min_evals,
        "best_score": float(best["score"]),
        "best_composition_by_site": best_by_site,
        "transfer_summary": transfer_summary,
        "leaderboard": public_leaderboard,
        "best_structure": best.get("best_structure"),
        "site_labels": best.get("site_labels"),
    }
    reporter.emit(
        "allocation.portfolio.done",
        evaluated_allocations=eval_index,
        unique_allocations=len(evaluated_keys),
        best_score=float(best["score"]),
        elapsed_sec=elapsed,
        stop_reason=stop_reason,
        time_budget_sec=solve_time_budget_sec,
        composition_by_site=best_by_site,
    )
    return result


def run_yaml_to_outputs(
    input_path: str | Path,
    *,
    workdir: str | Path | None = None,
    guide_only: bool = False,
    quiet: bool = False,
    json_stdout: bool = False,
    no_progress: bool = False,
    progress_interval_sec: float | None = None,
    progress_log_file: str | Path | None = None,
    charge_model_path: str | Path | None = None,
) -> dict[str, Any]:
    input_path = Path(input_path)
    resolved_charge_model_path, charge_model_source = _resolve_charge_model_path(
        input_path,
        charge_model_path,
    )
    charge_model_map: dict[str, float] | None = None
    charge_model_summary: dict[str, Any] | None = None
    if resolved_charge_model_path is not None:
        charge_model_map = _load_charge_model_mapping(resolved_charge_model_path)
        charge_model_summary = {
            "source": charge_model_source,
            "path": str(resolved_charge_model_path),
            "loaded_entries": len(charge_model_map),
            "charges": dict(charge_model_map),
            "summary": _format_charge_model_entries(charge_model_map),
        }
    effective_input_path, allocation_meta = _maybe_generate_sitewise_input_for_run(
        input_path,
        charge_model_path=resolved_charge_model_path,
    )
    workflow = ESSWorkflow.from_yaml(str(effective_input_path))
    strategy_meta = _extract_solve_strategy_meta(input_path)
    output_config = load_output_config(input_path)
    mpi = _mpi_context()
    is_writer = mpi["rank"] == 0
    resolved_workdir = Path(
        workdir or output_config.workdir or f"run-{input_path.stem}"
    )
    if is_writer:
        # Auto-increment if directory exists to avoid overwriting
        original_workdir = resolved_workdir
        counter = 1
        while resolved_workdir.exists():
            resolved_workdir = Path(f"{original_workdir}-NEW{counter:02d}")
            counter += 1
        resolved_workdir.mkdir(parents=True, exist_ok=True)
    if mpi["comm"] is not None:
        mpi["comm"].Barrier()

    energy_tracker = _EnergyTracker()

    reporter = ProgressReporter.with_overrides(
        resolved_workdir,
        workflow.run_input.logging,
        rank=int(mpi["rank"]),
        world_size=int(mpi["size"]),
        quiet=quiet,
        json_stdout=json_stdout,
        disabled=no_progress,
        interval_sec=progress_interval_sec,
        log_file=progress_log_file,
    )
    reporter.emit(
        "run.started",
        input=str(input_path),
        effective_input=str(effective_input_path),
        workdir=str(resolved_workdir),
        guide_only=guide_only,
        allocation_mode=(
            allocation_meta.get("mode") if allocation_meta.get("auto_allocation_applied") else None
        ),
        allocation_time_budget_sec=allocation_meta.get("allocation_time_budget_sec"),
    )
    if charge_model_summary is not None:
        reporter.emit(
            "run.charge_model_override",
            **charge_model_summary,
            input_charges_overridden=True,
        )
    if allocation_meta.get("auto_allocation_applied"):
        reporter.emit("run.auto_allocation", **allocation_meta)
    reporter.emit(
        "guide.started",
        title=workflow.run_input.guide.structure.title,
        n_target_sites=workflow.run_input.guide.composition.n_target_sites,
    )
    guide_result = workflow.guide()
    default_charges = _default_charge_map(workflow.run_input)
    source_to_group, charges_by_site = _load_site_charge_meta(effective_input_path)
    if charge_model_map is not None:
        # Runtime override: charge_model values take precedence over input charges_by_site.
        charges_by_site = {**charges_by_site, **charge_model_map}
    site_charges_title = _format_effective_charge_entries(
        workflow.run_input,
        charges_by_site,
    )
    guide_title_charges = _format_effective_charge_entries(
        workflow.run_input,
        (
            charges_by_site
            if charges_by_site and not any("@" in str(key) for key in charges_by_site)
            else None
        ),
    )
    if source_to_group and charges_by_site:
        overrides, fallbacks = _apply_site_charge_overrides_to_ready(
            guide_result, source_to_group, charges_by_site
        )
        reporter.emit(
            "guide.site_charges",
            overrides=overrides,
            fallbacks=fallbacks,
            source_kinds=len(source_to_group),
            entries=len(charges_by_site),
        )
    try:
        effective_payload = yaml.safe_load(effective_input_path.read_text()) or {}
    except Exception:
        effective_payload = {}
    if isinstance(effective_payload, dict):
        effective_payload = _resolve_payload_structure_poscar(
            effective_payload,
            base_dir=effective_input_path.parent,
        )
    if (
        allocation_meta.get("auto_allocation_applied")
        and isinstance(effective_payload, dict)
        and not isinstance(effective_payload.get("composition_by_site"), dict)
    ):
        initial_by_site = _initial_composition_by_site_for_allocation_run(
            effective_payload
        )
        if initial_by_site:
            effective_payload = dict(effective_payload)
            effective_payload["composition_by_site"] = initial_by_site
            allocation_meta["initial_composition_by_site"] = initial_by_site

    sitewise_meta = _apply_sitewise_composition_payload_to_ready(
        guide_result,
        effective_payload if isinstance(effective_payload, dict) else {},
        source_to_group=source_to_group,
        charges_by_site=charges_by_site,
        default_charges=default_charges,
    )
    if sitewise_meta.get("applied"):
        reporter.emit("guide.sitewise_composition", **sitewise_meta)
    input_species_order = (
        _read_input_composition_order(input_path)
        or _read_input_poscar_species_order(
            input_path,
            _extract_structure_poscar_path(input_path),
        )
    )
    reporter.emit(
        "guide.done",
        n_atoms=len(guide_result.ready.atoms),
        n_atom_config=guide_result.diagnostics.n_atom_config,
        rg_find_factor=guide_result.ready.rg_find_factor,
        supercell_expansion=list(guide_result.ready.supercell_expansion),
    )
    allocation_budget_explicit = (
        _explicit_allocation_budget_sec(effective_payload)
        if isinstance(effective_payload, dict)
        else None
    )
    separate_allocation_budget = allocation_budget_explicit is not None
    solve_stage_budget = _StageBudget(
        None
        if guide_only or separate_allocation_budget
        else strategy_meta.get("time_budget_sec")
    )
    if allocation_meta.get("auto_allocation_applied"):
        if separate_allocation_budget:
            allocation_meta["shared_budget"] = {
                "scope": "separate_allocation_and_solve",
                "allocation_budget_sec": allocation_budget_explicit,
                "solve_budget_sec": strategy_meta.get("time_budget_sec"),
            }
        elif solve_stage_budget.active:
            allocation_meta["shared_budget"] = {
                "target_sec": solve_stage_budget.target_sec,
                "scope": "allocation_search_plus_ess_solve",
            }
    portfolio_allocation_result = None
    allocation_seed_structure = None
    allocation_seed_energy: float | None = None
    allocation_seed_source: str | None = None
    if (not guide_only) and allocation_meta.get("auto_allocation_applied"):
        allocation_budget_sec, allocation_budget_fraction = _allocation_phase_budget_sec(
            effective_payload if isinstance(effective_payload, dict) else {},
            solve_stage_budget,
        )
        if solve_stage_budget.active:
            allocation_meta.setdefault("shared_budget", {}).update(
                {
                    "allocation_budget_sec": allocation_budget_sec,
                    "allocation_budget_fraction": allocation_budget_fraction,
                }
            )
        portfolio_allocation_result = _run_portfolio_allocation_search(
            guide_result=guide_result,
            effective_payload=effective_payload if isinstance(effective_payload, dict) else {},
            allocation_meta=allocation_meta,
            source_to_group=source_to_group,
            charges_by_site=charges_by_site,
            default_charges=default_charges,
            base_solve_options=workflow.run_input.solve,
            runtime=workflow.run_input.runtime,
            solve_time_budget_sec=allocation_budget_sec,
            max_swap=int(workflow.run_input.solve.max_swap),
            reporter=reporter,
            mpi=mpi,
        )
        if solve_stage_budget.active:
            allocation_meta.setdefault("shared_budget", {}).update(
                {
                    "elapsed_after_allocation_sec": solve_stage_budget.elapsed(),
                    "remaining_after_allocation_sec": solve_stage_budget.remaining(),
                }
            )
        elif separate_allocation_budget:
            allocation_meta.setdefault("shared_budget", {}).update(
                {
                    "allocation_elapsed_sec": allocation_budget_explicit,
                    "remaining_after_allocation_sec": strategy_meta.get("time_budget_sec"),
                }
            )
        if portfolio_allocation_result is not None:
            best_composition_by_site = _normalize_composition_by_site(
                portfolio_allocation_result.get("best_composition_by_site")
            )
            allocation_seed_structure = portfolio_allocation_result.get("best_structure")
            try:
                allocation_seed_energy = float(
                    portfolio_allocation_result.get("best_score")
                )
            except Exception:
                allocation_seed_energy = None
            allocation_seed_source = "portfolio_ess.best_structure"
            allocation_meta["portfolio_ess"] = {
                key: value
                for key, value in portfolio_allocation_result.items()
                if key not in {"best_structure", "site_labels"}
            }
            allocation_meta["best_composition_by_site"] = best_composition_by_site
            allocation_meta["transfer_summary"] = portfolio_allocation_result.get(
                "transfer_summary"
            )
            reporter.emit(
                "allocation.transfer.done",
                transfer_count=len(
                    (portfolio_allocation_result.get("transfer_summary") or {}).get(
                        "transfers", []
                    )
                ),
                site_delta=(portfolio_allocation_result.get("transfer_summary") or {}).get("site_delta"),
                transfers=(portfolio_allocation_result.get("transfer_summary") or {}).get("transfers"),
                message=str(
                    (portfolio_allocation_result.get("transfer_summary") or {}).get(
                        "summary", ""
                    )
                ),
            )
            effective_payload = dict(effective_payload) if isinstance(effective_payload, dict) else {}
            effective_payload["composition_by_site"] = best_composition_by_site
            coupled_meta = _apply_sitewise_composition_payload_to_ready(
                guide_result,
                effective_payload,
                source_to_group=source_to_group,
                charges_by_site=charges_by_site,
                default_charges=default_charges,
            )
            allocation_meta["coupled_solve"] = {
                "enabled": True,
                "applied": bool(coupled_meta.get("applied")),
                "source": "portfolio_ess.best_composition_by_site",
                "composition_by_site": best_composition_by_site,
                "sitewise_apply": coupled_meta,
                "seed_energy_eV": allocation_seed_energy,
                "source_to_group": source_to_group,
            }
            reporter.emit(
                "allocation.coupled_ready",
                **allocation_meta["coupled_solve"],
            )
        else:
            reporter.emit("allocation.swap.skipped")
    outputs: dict[str, str] = {}
    if is_writer:
        outputs.update(reporter.output_paths())
    if is_writer and output_config.input_filename:
        outputs["input_yaml"] = _write_text(
            resolved_workdir / output_config.input_filename,
            effective_input_path.read_text(),
        )
    prefix = output_config.resolved_prefix(
        workflow.run_input.guide.structure.title or input_path.stem
    )

    if is_writer and output_config.write_guider:
        outputs["guider"] = _write_text(
            resolved_workdir / output_config.guider_filename,
            write_guider_text_from_yaml(effective_input_path),
        )
    if is_writer and output_config.write_ready:
        solve_cfg = workflow.run_input.solve
        outputs["ready"] = _write_text(
            resolved_workdir / output_config.ready_filename,
            write_ready_file_text(
                guide_result.ready,
                {
                    "target_cpu_time_sec": workflow.run_input.guide.options.target_cpu_time_sec,
                    "running_index_delta": solve_cfg.running_index_delta,
                    "chop_level": int(round(float(guide_result.ready.chop_level))),
                    "print_stablest_unstablest": 1 if solve_cfg.print_stablest_unstablest else 0,
                    "swap": 1 if solve_cfg.swap else 0,
                    "max_swap": solve_cfg.max_swap,
                    "output_prefix_suffix": "",
                },
            ),
        )
    if is_writer and output_config.write_poscar:
        poscar_text = write_poscar_text(guide_result.ready)
        poscar_text = _drop_zero_count_species_from_poscar(poscar_text)
        # Add metadata (charges and RG) to POSCAR title for reproducibility
        poscar_lines = poscar_text.splitlines()
        if poscar_lines:
            rg_factor = guide_result.ready.rg_find_factor
            poscar_lines[0] = f"{poscar_lines[0]} | charges: {guide_title_charges} | RG={rg_factor}"
            poscar_text = "\n".join(poscar_lines) + "\n"
        outputs["poscar"] = _write_text(
            resolved_workdir / output_config.resolved_poscar_filename(prefix),
            poscar_text,
        )
    reporter.emit(
        "outputs.guide.done",
        wrote=list(outputs.keys()),
    )

    solve_result: SolveResult | None = None
    written_best_energy: float | None = None
    written_portfolio_best_energy: float | None = None
    if not guide_only:
        if separate_allocation_budget:
            solve_stage_budget = _StageBudget(strategy_meta.get("time_budget_sec"))
        effective_solve_options = _effective_solve_options(
            workflow.run_input.solve,
            mpi=mpi,
            strategy_execution_mode=strategy_meta.get("execution_mode"),
        )
        if allocation_meta.get("auto_allocation_applied"):
            effective_solve_options["adaptive_stride_scale_secondary"] = False
        if allocation_meta.get("auto_allocation_applied") and solve_stage_budget.active:
            remaining_delta = _remaining_adaptive_budget_delta(solve_stage_budget)
            if remaining_delta is not None:
                effective_solve_options["running_index_delta"] = remaining_delta
                allocation_meta.setdefault("coupled_solve", {}).update(
                    {
                        "solve_budget_sec": abs(int(remaining_delta)),
                        "remaining_budget_before_solve_sec": solve_stage_budget.remaining(),
                    }
                )
        _emit_solve_plan(
            reporter,
            guide_result=guide_result,
            run_input=workflow.run_input,
            mpi=mpi,
            effective_solve_options=effective_solve_options,
        )
        reporter.emit(
            "solve.started",
            running_index_delta=effective_solve_options["running_index_delta"],
            local_enumeration_limit=effective_solve_options["local_enumeration_limit"],
            local_enumeration_max_chunks=effective_solve_options["local_enumeration_max_chunks"],
            enumeration_exhaust_all=effective_solve_options["enumeration_exhaust_all"],
            enumeration_save_memory=effective_solve_options["enumeration_save_memory"],
            swap=effective_solve_options["swap"],
            max_swap=effective_solve_options["max_swap"],
            strategy_mode=strategy_meta.get("mode"),
            strategy_time_budget_sec=strategy_meta.get("time_budget_sec"),
            strategy_effort=strategy_meta.get("effort"),
            strategy_execution_mode=strategy_meta.get("execution_mode"),
            chunk_tuned=effective_solve_options["chunk_tuned"],
            chunk_policy=effective_solve_options["chunk_policy"],
            mpi_dynamic_chunking=effective_solve_options["mpi_dynamic_chunking"],
            adaptive_stride_cost_model=(
                "legacy_secondary_scaled"
                if effective_solve_options["adaptive_stride_scale_secondary"]
                else "measured_window"
            ),
            seed_structure_source=allocation_seed_source,
            seed_energy_eV=allocation_seed_energy,
        )
        solve_options = replace(
            workflow.run_input.solve,
            running_index_delta=int(effective_solve_options["running_index_delta"]),
            local_enumeration_limit=int(effective_solve_options["local_enumeration_limit"]),
            local_enumeration_max_chunks=int(effective_solve_options["local_enumeration_max_chunks"]),
            enumeration_exhaust_all=bool(effective_solve_options["enumeration_exhaust_all"]),
            enumeration_save_memory=bool(effective_solve_options["enumeration_save_memory"]),
            mpi_dynamic_chunking=bool(effective_solve_options["mpi_dynamic_chunking"]),
            mpi_chunk_min=int(effective_solve_options["mpi_chunk_min"]),
            mpi_chunk_max=int(effective_solve_options["mpi_chunk_max"]),
            mpi_scheduler_heartbeat=int(effective_solve_options["mpi_scheduler_heartbeat"]),
            adaptive_stride_scale_secondary=bool(
                effective_solve_options["adaptive_stride_scale_secondary"]
            ),
            swap=bool(effective_solve_options["swap"]),
            max_swap=int(effective_solve_options["max_swap"]),
        )
        if allocation_seed_structure is not None and getattr(
            allocation_seed_structure, "sites", None
        ):
            solve_options = replace(
                solve_options,
                swap_loop_seed_source=3,
                swap_loop_starting_sites=list(allocation_seed_structure.sites),
            )
            allocation_meta.setdefault("coupled_solve", {}).update(
                {
                    "seed_structure_source": allocation_seed_source,
                    "seed_energy_eV": allocation_seed_energy,
                    "seed_sites": len(allocation_seed_structure.sites),
                    "swap_loop_seed_source": 3,
                }
            )
            reporter.emit(
                "solve.seeded_start",
                source=allocation_seed_source,
                energy=allocation_seed_energy,
                sites=len(allocation_seed_structure.sites),
                message=(
                    "Final swap refinement will start from allocation-search "
                    "best structure"
                ),
            )
            if allocation_seed_energy is not None:
                energy_tracker.check_improvement(float(allocation_seed_energy), 0.0)
        adaptive_target_sec = (
            float(abs(int(effective_solve_options["running_index_delta"])))
            if int(effective_solve_options["running_index_delta"]) < 0
            else None
        )
        if workflow.run_input.logging.write_best_so_far:
            solve_options = replace(
                solve_options,
                progress_include_best_structure=True,
            )
        try:
            solve_ready = ready_with_legacy_text_precision(guide_result.ready)
            solve_result = solve(
                SolveInput(
                    ready=solve_ready,
                    options=solve_options,
                    runtime=workflow.run_input.runtime,
                ),
                progress_callback=lambda event: _emit_native_progress(
                    reporter, event, energy_tracker, resolved_workdir,
                    workflow.run_input.guide.structure.title or input_path.stem,
                    output_config, guide_result, is_writer,
                    adaptive_target_sec=adaptive_target_sec,
                    input_species_order=input_species_order,
                    seed_best_energy=allocation_seed_energy,
                ),
            )
        except KeyboardInterrupt:
            reporter.emit(
                "solve.aborted",
                reason="KeyboardInterrupt",
            )
            if mpi["comm"] is not None:
                try:
                    mpi["comm"].Barrier()
                except Exception:
                    pass
            raise
        reporter.emit(
            "solve.done",
            global_count_total=solve_result.summary.global_count_total,
            energy_table_count=solve_result.energy_table.count,
            global_e_min=solve_result.summary.global_e_min,
            global_e_max=solve_result.summary.global_e_max,
            local_processed_candidates=solve_result.local_reduction.processed_candidates,
            local_swap_count=solve_result.mpi_stats.get(
                "global_swap_count",
                solve_result.local_reduction.local_swap_count,
            ),
        )
        if is_writer and output_config.write_poscar and solve_result:
            best_payload = None
            worst_payload = None

            if solve_result.best and solve_result.best.structure:
                _, best_species_order = _expected_counts_and_order(
                    guide_result,
                    input_species_order=input_species_order,
                )
                best_payload = (
                    solve_result.best.structure,
                    best_species_order,
                    float(solve_result.best.energy),
                )

            if solve_result.worst and solve_result.worst.structure:
                _, worst_species_order = _expected_counts_and_order(
                    guide_result,
                    input_species_order=input_species_order,
                )
                worst_payload = (
                    solve_result.worst.structure,
                    worst_species_order,
                    float(solve_result.worst.energy),
                )

            # Safety invariant: best energy must be <= worst energy.
            # If inverted, swap the snapshots and solver energies so downstream
            # outputs remain physically consistent.
            if best_payload and worst_payload:
                if best_payload[2] > worst_payload[2]:
                    reporter.emit(
                        "solve.best_worst.corrected",
                        reason="solver energies inverted",
                        best_before=best_payload[2],
                        worst_before=worst_payload[2],
                    )
                    best_payload, worst_payload = worst_payload, best_payload

            rg_factor = guide_result.ready.rg_find_factor
            expected_run_counts = {
                entry.kind: int(entry.count)
                for entry in workflow.run_input.guide.composition.entries
                if int(entry.count) > 0
            }

            if best_payload:
                best_structure, best_species_order, best_energy = best_payload
                best_species_order = _assert_structure_counts_match_expected(
                    best_structure,
                    guide_result,
                    input_species_order=input_species_order,
                    expected_counts_override=expected_run_counts,
                    label="final ESS best POSCAR",
                )
                written_best_energy = float(best_energy)
                best_site_labels = _site_labels_from_ready(
                    guide_result,
                    source_to_group,
                    n_sites=len(best_structure.sites),
                )
                outputs["final_ess_best_poscar"] = _write_text(
                    resolved_workdir / "diagnostics" / "POSCAR_final_ess_best.vasp",
                    write_structure_to_poscar(
                        best_structure,
                        title=f"{prefix} (final ESS best) E={best_energy} | charges: {site_charges_title} | RG={rg_factor}",
                        species_order=best_species_order,
                        site_labels=best_site_labels,
                    ),
                )

            if worst_payload:
                worst_structure, worst_species_order, worst_energy = worst_payload
                worst_species_order = _assert_structure_counts_match_expected(
                    worst_structure,
                    guide_result,
                    input_species_order=input_species_order,
                    expected_counts_override=expected_run_counts,
                    label="worst POSCAR",
                )
                worst_site_labels = _site_labels_from_ready(
                    guide_result,
                    source_to_group,
                    n_sites=len(worst_structure.sites),
                )
                worst_filename = output_config.worst_poscar_filename or "POSCAR_host_worst.vasp"
                outputs["worst_poscar"] = _write_text(
                    resolved_workdir / worst_filename,
                    write_structure_to_poscar(
                        worst_structure,
                        title=f"{prefix} (worst) E={worst_energy} | charges: {site_charges_title} | RG={rg_factor}",
                        species_order=worst_species_order,
                        site_labels=worst_site_labels,
                    ),
                )

        if (
            is_writer
            and output_config.write_poscar
            and portfolio_allocation_result is not None
            and portfolio_allocation_result.get("best_structure") is not None
        ):
            _, allocation_species_order_fallback = _expected_counts_and_order(
                guide_result,
                input_species_order=input_species_order,
            )
            allocation_species_order = (
                _read_input_composition_order(input_path)
                or allocation_species_order_fallback
            )
            allocation_species_order = _assert_structure_counts_match_expected(
                portfolio_allocation_result["best_structure"],
                guide_result,
                input_species_order=allocation_species_order,
                expected_counts_override={
                    entry.kind: int(entry.count)
                    for entry in workflow.run_input.guide.composition.entries
                    if int(entry.count) > 0
                },
                label="allocation best POSCAR",
            )
            try:
                written_portfolio_best_energy = float(
                    portfolio_allocation_result.get("best_score")
                )
            except Exception:
                written_portfolio_best_energy = None
            outputs["allocation_portfolio_best_poscar"] = _write_text(
                resolved_workdir / "diagnostics" / "POSCAR_allocation_best.vasp",
                write_structure_to_poscar(
                    portfolio_allocation_result["best_structure"],
                    title=(
                        f"{prefix} (allocation portfolio best) "
                        f"E={portfolio_allocation_result.get('best_score')} "
                        f"| charges: {site_charges_title} | RG={guide_result.ready.rg_find_factor}"
                    ),
                    species_order=allocation_species_order,
                    site_labels=portfolio_allocation_result.get("site_labels"),
                ),
            )

        if (
            "allocation_portfolio_best_poscar" in outputs
            and written_portfolio_best_energy is not None
            and (
                written_best_energy is None
                or written_portfolio_best_energy <= written_best_energy
            )
        ):
            outputs["recommended_poscar"] = outputs["allocation_portfolio_best_poscar"]
        elif (
            "final_ess_best_poscar" in outputs
            and isinstance(allocation_meta.get("coupled_solve"), dict)
            and allocation_meta["coupled_solve"].get("applied")
        ):
            outputs["recommended_poscar"] = outputs["final_ess_best_poscar"]
        elif "allocation_best_poscar" in outputs:
            outputs["recommended_poscar"] = outputs["allocation_best_poscar"]
        elif "final_ess_best_poscar" in outputs:
            outputs["recommended_poscar"] = outputs["final_ess_best_poscar"]

        if is_writer and output_config.write_poscar:
            _write_structure_aliases(
                resolved_workdir=resolved_workdir,
                outputs=outputs,
                best_filename=output_config.best_poscar_filename or "POSCAR_host_best.vasp",
            )

        # Save energy improvement log
        if is_writer and energy_tracker.improvements:
            improvements_log = resolved_workdir / (output_config.energy_filename or "energy_improvements.txt")
            improvements_text = "Elapsed_sec\tEnergy_eV\n"
            for elapsed, energy in energy_tracker.improvements:
                improvements_text += f"{elapsed:.3f}\t{energy:.6f}\n"
            outputs["energy_improvements"] = _write_text(improvements_log, improvements_text)
        if is_writer:
            _apply_output_selection(
                resolved_workdir=resolved_workdir,
                output_config=output_config,
                energy_tracker=energy_tracker,
                outputs=outputs,
            )

        reporter.emit(
            "outputs.solve.done",
            wrote=list(outputs.keys()),
        )

    summary_path = resolved_workdir / output_config.summary_filename
    if is_writer and output_config.write_summary_json:
        outputs["summary"] = str(summary_path)
    summary = _summary_payload(
        input_path=input_path,
        workdir=resolved_workdir,
        run_input=workflow.run_input,
        guide_result=guide_result,
        solve_result=solve_result,
        outputs=outputs,
        guide_only=guide_only,
        allocation_meta=allocation_meta,
        charge_model_summary=charge_model_summary,
    )
    if is_writer and output_config.write_summary_json:
        _write_text(
            summary_path,
            json.dumps(summary, indent=2, sort_keys=True) + "\n",
        )
    reporter.emit(
        "run.done",
        summary=str(summary_path) if is_writer and output_config.write_summary_json else "",
        outputs=list(outputs.keys()),
    )
    if is_writer and output_config.write_summary_json:
        _append_human_summary_to_log(
            summary=summary,
            log_path=reporter.log_path,
        )
    _validate_summary_invariants(summary)
    return summary


def _mpi_context() -> dict[str, Any]:
    return detect_mpi_context()


def _extract_solve_strategy_meta(input_path: Path) -> dict[str, Any]:
    """Read optional solve.strategy metadata for user-facing progress logs."""
    try:
        payload = yaml.safe_load(input_path.read_text()) or {}
    except Exception:
        return {}
    if not isinstance(payload, dict):
        return {}
    solve = payload.get("solve")
    if not isinstance(solve, dict):
        return {}
    strategy = solve.get("strategy")
    if not isinstance(strategy, dict):
        return {}
    return {
        "mode": strategy.get("mode"),
        "time_budget_sec": strategy.get("time_budget_sec"),
        "effort": strategy.get("effort"),
        "execution_mode": (
            strategy.get("execution_mode")
            if strategy.get("execution_mode") is not None
            else strategy.get("profile")
        ),
    }


def _extract_structure_poscar_path(input_path: Path) -> str | None:
    try:
        payload = yaml.safe_load(input_path.read_text(encoding="utf-8")) or {}
        if not isinstance(payload, dict):
            return None
        structure = payload.get("structure")
        if not isinstance(structure, dict):
            return None
        poscar = structure.get("poscar")
        if poscar is None:
            return None
        return str(poscar)
    except Exception:
        return None


def _resolve_payload_structure_poscar(
    payload: dict[str, Any],
    *,
    base_dir: Path,
) -> dict[str, Any]:
    structure = payload.get("structure")
    if not isinstance(structure, dict):
        return payload
    poscar = structure.get("poscar")
    if poscar is None:
        return payload
    poscar_path = Path(str(poscar))
    if poscar_path.is_absolute():
        return payload
    out = dict(payload)
    out_structure = dict(structure)
    out_structure["poscar"] = str((base_dir / poscar_path).resolve())
    out["structure"] = out_structure
    return out


def _append_human_summary_to_log(*, summary: dict[str, Any], log_path: Path) -> None:
    try:
        rendered = cli_common._format_run_summary(summary, verbose=False)
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write("\n\n")
            handle.write(rendered)
            handle.write("\n")
    except Exception:
        return


def _validate_summary_invariants(summary: dict[str, Any]) -> None:
    solve = summary.get("solve")
    if not isinstance(solve, dict):
        return
    e_min = solve.get("global_e_min")
    e_max = solve.get("global_e_max")
    if not isinstance(e_min, (int, float)) or not isinstance(e_max, (int, float)):
        return
    if float(e_min) > float(e_max):
        raise RuntimeError(
            f"Invariant violated: global_e_min ({e_min}) must be <= global_e_max ({e_max})"
        )


def _expected_counts_and_order(
    guide_result: GuideResult,
    input_species_order: list[str] | None = None,
) -> tuple[dict[str, int], list[str]]:
    counts: dict[str, int] = {
        entry.kind: int(entry.count) for entry in guide_result.ready.poscar_species_counts
    }
    order: list[str] = []
    recipe_by_from = {recipe.from_kind: recipe for recipe in guide_result.ready.recipes}

    source_order = list(input_species_order or [])
    if not source_order:
        source_order = [entry.kind for entry in guide_result.ready.poscar_species_counts]
    for entry in guide_result.ready.poscar_species_counts:
        if entry.kind not in source_order:
            source_order.append(entry.kind)

    for source_kind in source_order:
        recipe = recipe_by_from.get(source_kind)
        if recipe is None or not recipe.modifications:
            if source_kind not in order:
                order.append(source_kind)
            continue

        base_count = int(counts.get(source_kind, 0))
        substituted = 0
        for mod in recipe.modifications:
            target_kind = mod.to
            mod_count = int(mod.count)
            substituted += mod_count
            counts[target_kind] = int(counts.get(target_kind, 0)) + mod_count
            if target_kind not in order:
                order.append(target_kind)

        remaining = base_count - substituted
        counts[source_kind] = max(0, remaining)
        if remaining > 0 and source_kind not in order:
            order.append(source_kind)

    for kind in list(counts.keys()):
        if kind not in order and counts.get(kind, 0) > 0:
            order.append(kind)

    counts = {kind: count for kind, count in counts.items() if count > 0}
    return counts, order


def _normalize_snapshot_structure(
    structure,
    guide_result: GuideResult,
    input_species_order: list[str] | None = None,
):
    expected_counts, species_order = _expected_counts_and_order(
        guide_result,
        input_species_order=input_species_order,
    )
    if not structure or not structure.sites:
        return structure, species_order

    actual_counts = Counter(site.kind for site in structure.sites)
    total_expected = sum(expected_counts.values())
    if total_expected != len(structure.sites):
        return structure, species_order

    deficit: dict[str, int] = {
        kind: max(0, int(expected_counts.get(kind, 0)) - int(actual_counts.get(kind, 0)))
        for kind in expected_counts
    }
    excess: dict[str, int] = {}
    for kind, count in actual_counts.items():
        expected = int(expected_counts.get(kind, 0))
        if count > expected:
            excess[kind] = count - expected
        elif kind not in expected_counts:
            excess[kind] = count

    if not any(deficit.values()) and not any(excess.values()):
        return structure, species_order

    deficit_queue: list[str] = []
    for kind in species_order:
        n = int(deficit.get(kind, 0))
        if n > 0:
            deficit_queue.extend([kind] * n)

    if len(deficit_queue) != sum(excess.values()):
        return structure, species_order

    deficit_index = 0
    for site in structure.sites:
        kind = site.kind
        if excess.get(kind, 0) <= 0:
            continue
        target_kind = deficit_queue[deficit_index]
        deficit_index += 1
        excess[kind] -= 1
        site.kind = target_kind

    return structure, species_order


def _assert_structure_counts_match_expected(
    structure,
    guide_result: GuideResult,
    *,
    input_species_order: list[str] | None = None,
    expected_counts_override: dict[str, int] | None = None,
    label: str = "structure",
) -> list[str]:
    if expected_counts_override is None:
        expected_counts, species_order = _expected_counts_and_order(
            guide_result,
            input_species_order=input_species_order,
        )
    else:
        expected_counts = {
            str(kind): int(count)
            for kind, count in expected_counts_override.items()
            if int(count) > 0
        }
        species_order = list(input_species_order or [])
        for kind in expected_counts:
            if kind not in species_order:
                species_order.append(kind)
    actual_counts = Counter(site.kind for site in getattr(structure, "sites", []))
    actual = {kind: int(count) for kind, count in actual_counts.items() if int(count) > 0}
    expected = {kind: int(count) for kind, count in expected_counts.items() if int(count) > 0}
    if actual != expected:
        missing = {
            kind: expected[kind] - actual.get(kind, 0)
            for kind in expected
            if actual.get(kind, 0) != expected[kind]
        }
        extra = {
            kind: actual[kind] - expected.get(kind, 0)
            for kind in actual
            if actual[kind] != expected.get(kind, 0)
        }
        raise RuntimeError(
            f"{label} species-count invariant failed: "
            f"actual={actual}, expected={expected}, missing_or_short={missing}, extra_or_excess={extra}"
        )
    return species_order


def _emit_native_progress(
    reporter: ProgressReporter,
    event: dict[str, Any],
    energy_tracker: _EnergyTracker,
    workdir: Path,
    prefix: str,
    output_config: Any,
    guide_result: GuideResult,
    is_writer: bool,
    adaptive_target_sec: float | None = None,
    input_species_order: list[str] | None = None,
    seed_best_energy: float | None = None,
) -> None:
    stage = str(event.get("stage", "solve.native"))
    processed = event.get("processed_candidates", 0)
    available = event.get("available_count", 0)
    elapsed = event.get("elapsed_sec", 0)
    e_min = event.get("local_e_min")
    e_max = event.get("local_e_max")

    try:
        seed_best = None if seed_best_energy is None else float(seed_best_energy)
    except Exception:
        seed_best = None
    best_so_far = e_min
    if seed_best is not None and e_min is not None:
        best_so_far = min(float(e_min), seed_best)
    elif seed_best is not None:
        best_so_far = seed_best

    # Track best energy and save intermediate best POSCAR when improvement detected
    if stage == "solve.chunk" and e_min is not None:
        if energy_tracker.check_improvement(e_min, elapsed):
            # Log improvement
            reporter.emit(
                "solve.best_updated",
                energy=e_min,
                elapsed_sec=elapsed,
                message=f"Best energy improved: {e_min:.6f} eV"
            )
    if (
        stage == "solve.chunk"
        and is_writer
        and reporter.options.write_best_so_far
        and bool(event.get("best_structure_present"))
    ):
        try:
            snapshot_structure = structure_from_dict(event.get("best_structure"))
            normalized, species_order = _normalize_snapshot_structure(
                snapshot_structure,
                guide_result,
                input_species_order=input_species_order,
            )
            best_filename = output_config.best_poscar_filename or "POSCAR_host_best.vasp"
            best_path = workdir / best_filename
            best_energy = event.get("local_e_min")
            title = (
                f"{prefix} (best-so-far) E={best_energy}"
                if best_energy is not None
                else f"{prefix} (best-so-far)"
            )
            best_path.write_text(
                write_structure_to_poscar(
                    normalized,
                    title=title,
                    species_order=species_order,
                ),
                encoding="utf-8",
            )
            if best_energy is not None:
                snapshot_dir = workdir / "snapshots"
                snapshot_dir.mkdir(parents=True, exist_ok=True)
                snapshot_path = snapshot_dir / (
                    f"POSCAR_best_so_far_{len(energy_tracker.snapshots) + 1:04d}.vasp"
                )
                snapshot_path.write_text(
                    write_structure_to_poscar(
                        normalized,
                        title=title,
                        species_order=species_order,
                    ),
                    encoding="utf-8",
                )
                energy_tracker.add_snapshot(float(best_energy), snapshot_path)
        except Exception:
            pass

    # Build progress message for solve.chunk with progress bar and ETA
    message = ""
    if stage == "solve.chunk" and processed is not None and available is not None and available > 0:
        is_adaptive_budget_mode = (
            adaptive_target_sec is not None and adaptive_target_sec > 0
        )
        pct = 100.0 * processed / available

        # Progress bar (20 chars, filled based on percentage)
        bar_width = 20
        if is_adaptive_budget_mode and elapsed is not None:
            time_pct = min(100.0, max(0.0, 100.0 * float(elapsed) / float(adaptive_target_sec)))
            filled = int(bar_width * time_pct / 100.0)
        else:
            filled = int(bar_width * pct / 100.0)
        bar = "[" + "=" * filled + " " * (bar_width - filled) + "]"

        # ETA calculation
        if is_adaptive_budget_mode:
            remaining_budget = max(0.0, float(adaptive_target_sec) - float(elapsed))
            if remaining_budget < 60:
                remaining_str = f"{remaining_budget:.0f}s"
            elif remaining_budget < 3600:
                remaining_str = f"{remaining_budget/60:.1f}m"
            else:
                remaining_str = f"{remaining_budget/3600:.1f}h"
            total_str = (
                f"{adaptive_target_sec:.0f}s"
                if adaptive_target_sec < 60
                else (f"{adaptive_target_sec/60:.1f}m" if adaptive_target_sec < 3600 else f"{adaptive_target_sec/3600:.1f}h")
            )
            elapsed_str = (
                f"{float(elapsed):.1f}s"
                if float(elapsed) < 60
                else (f"{float(elapsed)/60:.1f}m" if float(elapsed) < 3600 else f"{float(elapsed)/3600:.1f}h")
            )
        elif elapsed > 0:
            rate = processed / elapsed  # candidates per second
            remaining = available - processed
            eta_sec = remaining / rate if rate > 0 else 0

            # Format remaining time
            if eta_sec < 60:
                remaining_str = f"{eta_sec:.0f}s"
            elif eta_sec < 3600:
                remaining_str = f"{eta_sec/60:.1f}m"
            else:
                remaining_str = f"{eta_sec/3600:.1f}h"

            # Format total time
            total_sec = elapsed + eta_sec
            if total_sec < 60:
                total_str = f"{total_sec:.0f}s"
            elif total_sec < 3600:
                total_str = f"{total_sec/60:.1f}m"
            else:
                total_str = f"{total_sec/3600:.1f}h"
        else:
            remaining_str = "??"
            total_str = "??"
            elapsed_str = "??"

        if is_adaptive_budget_mode:
            message = (
                f"Solving {bar} sampled={processed:,}/{available:,} ({pct:5.1f}% of assigned space) "
                f"| Budget: {elapsed_str}/{total_str}, Remaining: {remaining_str}"
            )
        else:
            message = (
                f"Solving {bar} {processed:,}/{available:,} ({pct:5.1f}%) "
                f"| Total: {total_str}, Remaining: {remaining_str}"
            )
        if e_min is not None and e_max is not None:
            if seed_best is not None:
                message += (
                    f" | window_E_min={float(e_min):.4f} eV"
                    f" | best_so_far={float(best_so_far):.4f} eV"
                )
            else:
                message += f" | E_min={e_min:.4f} eV"

    fields = {
        "native_elapsed_sec": elapsed,
        "solve_budget_sec": adaptive_target_sec,
        "processed_chunks": event.get("processed_chunks"),
        "processed_candidates": processed,
        "next_offset": event.get("next_offset"),
        "available_count": available,
        "has_more": event.get("has_more"),
        "local_e_min": e_min,
        "local_e_max": e_max,
        "seed_best_energy": seed_best,
        "best_so_far_energy": best_so_far,
        "monitoring_index": event.get("monitoring_index"),
        "adaptive_stride": event.get("adaptive_stride"),
        "active_stride": event.get("active_stride"),
        "secondary_recipe_index": event.get("secondary_recipe_index"),
        "secondary_index": event.get("secondary_index"),
        "secondary_jobsize": event.get("secondary_jobsize"),
    }
    reporter.emit(stage, message=message, **fields)


def _emit_solve_plan(
    reporter: ProgressReporter,
    *,
    guide_result: GuideResult,
    run_input: RunInput,
    mpi: dict[str, Any],
    effective_solve_options: dict[str, Any],
) -> None:
    search_space = analyze_search_space(guide_result.ready)
    primary_index = search_space.primary_recipe_index
    primary = (
        search_space.entries[primary_index]
        if 0 <= primary_index < len(search_space.entries)
        else None
    )
    total_candidates = int(primary.jobsize_u64) if primary is not None else 0
    primary_saturated = bool(primary.jobsize_saturated) if primary is not None else False
    any_saturated = any(bool(entry.jobsize_saturated) for entry in search_space.entries)
    world_size = int(mpi["size"])
    rank = int(mpi["rank"])
    assigned_start = 0
    assigned_count = total_candidates
    if world_size > 1 and total_candidates > 0:
        chunk_size = total_candidates // world_size
        assigned_start = rank * chunk_size
        assigned_count = (
            total_candidates - assigned_start
            if rank == world_size - 1
            else chunk_size
        )
    reporter.emit(
        "solve.plan",
        n_atoms=len(guide_result.ready.atoms),
        n_recipes=len(guide_result.ready.recipes),
        primary_recipe_index=primary_index,
        primary_from=primary.from_kind if primary is not None else "",
        primary_random_pickup=primary.random_pickup if primary is not None else 0,
        primary_random_pickup_trial=primary.random_pickup_trial if primary is not None else 0,
        primary_jobsize_u64=total_candidates,
        primary_jobsize_saturated=primary_saturated,
        search_space_saturated=any_saturated,
        total_candidate_count_log10=search_space.total_candidate_count_log10,
    )
    reporter.emit(
        "solve.partition",
        rank=rank,
        world_size=world_size,
        assigned_start=assigned_start,
        assigned_count=assigned_count,
        assigned_end=assigned_start + max(0, assigned_count) - 1 if assigned_count else -1,
        search_space_saturated=any_saturated,
        local_enumeration_limit=effective_solve_options["local_enumeration_limit"],
        local_enumeration_max_chunks=effective_solve_options["local_enumeration_max_chunks"],
        running_index_delta=effective_solve_options["running_index_delta"],
        enumeration_exhaust_all=effective_solve_options["enumeration_exhaust_all"],
        enumeration_save_memory=effective_solve_options["enumeration_save_memory"],
        chunk_tuned=effective_solve_options["chunk_tuned"],
        chunk_policy=effective_solve_options["chunk_policy"],
        mpi_dynamic_chunking=effective_solve_options["mpi_dynamic_chunking"],
    )


def _effective_solve_options(
    solve_options,
    *,
    mpi: dict[str, Any],
    strategy_execution_mode: str | None = None,
) -> dict[str, Any]:
    world_size = int(mpi["size"])
    base_limit = int(solve_options.local_enumeration_limit)
    tuned_limit = base_limit
    chunk_tuned = False
    chunk_policy = "none"
    if world_size > 1:
        # Use smaller per-rank chunks for better load balancing in scalable MPI mode.
        # Keep quick mode unchanged to minimize synchronization overhead.
        mode = (strategy_execution_mode or "").strip().lower()
        if mode in {"scalable", "throughput"}:
            tuned_limit = max(1000, min(base_limit, base_limit // world_size))
            chunk_tuned = tuned_limit != base_limit
            chunk_policy = "scalable_auto"
    return {
        "running_index_delta": solve_options.running_index_delta,
        "local_enumeration_limit": tuned_limit,
        "local_enumeration_max_chunks": solve_options.local_enumeration_max_chunks,
        "enumeration_exhaust_all": False if world_size > 1 else solve_options.enumeration_exhaust_all,
        "enumeration_save_memory": True if world_size > 1 else solve_options.enumeration_save_memory,
        "mpi_dynamic_chunking": bool(getattr(solve_options, "mpi_dynamic_chunking", False)),
        "mpi_chunk_min": int(getattr(solve_options, "mpi_chunk_min", 512)),
        "mpi_chunk_max": int(getattr(solve_options, "mpi_chunk_max", 20000)),
        "mpi_scheduler_heartbeat": int(getattr(solve_options, "mpi_scheduler_heartbeat", 16)),
        "adaptive_stride_scale_secondary": bool(
            getattr(solve_options, "adaptive_stride_scale_secondary", True)
        ),
        "swap": solve_options.swap,
        "max_swap": solve_options.max_swap,
        "chunk_tuned": chunk_tuned,
        "chunk_policy": chunk_policy,
    }


def _summary_payload(
    *,
    input_path: Path,
    workdir: Path,
    run_input: RunInput,
    guide_result: GuideResult,
    solve_result: SolveResult | None,
    outputs: dict[str, str],
    guide_only: bool,
    allocation_meta: dict[str, Any] | None = None,
    charge_model_summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    solve_payload = None
    if solve_result is not None:
        solve_payload = {
            "global_e_min": solve_result.summary.global_e_min,
            "global_e_max": solve_result.summary.global_e_max,
            "global_count_total": solve_result.summary.global_count_total,
            "energy_table_count": solve_result.energy_table.count,
            "local_processed_candidates": solve_result.local_reduction.processed_candidates,
            "local_swap_count": solve_result.local_reduction.local_swap_count,
            "local_de_min_swap": solve_result.local_reduction.local_de_min_swap,
            "global_swap_count": solve_result.mpi_stats.get(
                "global_swap_count",
                solve_result.local_reduction.local_swap_count,
            ),
            "global_de_min_swap": solve_result.mpi_stats.get(
                "global_de_min_swap",
                solve_result.local_reduction.local_de_min_swap,
            ),
            "messages": list(solve_result.messages),
            "mpi": dict(solve_result.mpi_stats),
        }
    output_paths = dict(outputs)
    summary = {
        "input": str(input_path),
        "workdir": str(workdir),
        "guide_only": guide_only,
        "guide": {
            "n_atoms": len(guide_result.ready.atoms),
            "n_atom_config": guide_result.diagnostics.n_atom_config,
            "rg_find_factor": guide_result.ready.rg_find_factor,
            "supercell_expansion": list(guide_result.ready.supercell_expansion),
            "recipes": [
                {
                    "from": recipe.from_kind,
                    "random_pickup": recipe.random_pickup,
                    "random_pickup_trial": recipe.random_pickup_trial,
                    "modifications": [
                        asdict(modification)
                        for modification in recipe.modifications
                    ],
                }
                for recipe in guide_result.ready.recipes
            ],
        },
        "solve_options": {
            "swap": run_input.solve.swap,
            "max_swap": run_input.solve.max_swap,
            "swap_loop_enabled": run_input.solve.swap_loop_enabled,
        },
        "solve": solve_payload,
        "outputs": output_paths,
    }
    if charge_model_summary is not None:
        summary["charge_model"] = charge_model_summary
    recommended_poscar = output_paths.get("recommended_poscar")
    if recommended_poscar:
        recommended_source_poscar = output_paths.get(
            "recommended_source_poscar",
            recommended_poscar,
        )
        coupled_solve = (
            allocation_meta.get("coupled_solve")
            if isinstance(allocation_meta, dict)
            else None
        )
        if (
            recommended_source_poscar == output_paths.get("final_ess_best_poscar")
            and isinstance(coupled_solve, dict)
            and coupled_solve.get("applied")
        ):
            if coupled_solve.get("source") == "portfolio_ess.best_composition_by_site":
                source = "portfolio_allocation_ess_best_poscar"
                reason = (
                    "allocation portfolio evaluated site allocations by rough ESS, "
                    "then standard ESS optimized the best selected allocation"
                )
            else:
                source = "coupled_allocation_ess_best_poscar"
                reason = "standard ESS optimized the selected site composition"
        elif recommended_source_poscar == output_paths.get("allocation_best_poscar"):
            source = "allocation_best_poscar"
            reason = "allocation-aware best structure before the downstream ESS solve"
        elif recommended_source_poscar == output_paths.get("allocation_portfolio_best_poscar"):
            source = "allocation_portfolio_best_poscar"
            reason = (
                "allocation portfolio found this lower-energy structure during "
                "rough/refined allocation search; the downstream ESS solve did not improve it"
            )
        elif recommended_source_poscar == output_paths.get("final_ess_best_poscar"):
            source = "final_ess_best_poscar"
            reason = "standard ESS best structure"
        else:
            source = "best_poscar"
            reason = "overall recommended best structure"
        summary["recommended"] = {
            "poscar": recommended_poscar,
            "source_poscar": recommended_source_poscar,
            "source": source,
            "reason": reason,
            "next_step": "Use this POSCAR for downstream relax/validation.",
        }
    if allocation_meta and allocation_meta.get("auto_allocation_applied"):
        summary["allocation"] = {
            "debug": allocation_meta.get("debug"),
            "seed": allocation_meta.get("seed"),
            "seed_mode": allocation_meta.get("seed_mode"),
            "score_mode": allocation_meta.get("score_mode"),
            "metric": allocation_meta.get("metric"),
            "topk": allocation_meta.get("topk"),
            "beam_width": allocation_meta.get("beam_width"),
            "beam_rounds": allocation_meta.get("beam_rounds"),
            "best_score": allocation_meta.get("best_score"),
            "initial_composition_by_site": allocation_meta.get("initial_composition_by_site"),
            "best_composition_by_site": allocation_meta.get("best_composition_by_site"),
            "transfer_summary": allocation_meta.get("transfer_summary"),
            "allocation_table": allocation_meta.get("allocation_table"),
            "generated_input_yaml": allocation_meta.get("generated_input_yaml"),
            "shared_budget": allocation_meta.get("shared_budget"),
            "coupled_solve": allocation_meta.get("coupled_solve"),
            "generalized_swap": allocation_meta.get("generalized_swap"),
            "portfolio_ess": allocation_meta.get("portfolio_ess"),
        }
        if allocation_meta.get("allocation_time_budget_sec") is not None:
            summary["allocation"]["time_budget_sec"] = allocation_meta.get(
                "allocation_time_budget_sec"
            )
        portfolio = allocation_meta.get("portfolio_ess")
        if isinstance(portfolio, dict):
            summary["allocation_portfolio"] = {
                "mode": "portfolio_ess",
                "optimizer": portfolio.get("optimizer"),
                "rough_parallel": portfolio.get("rough_parallel"),
                "evaluated_allocations": portfolio.get("evaluated_allocations"),
                "unique_allocations": portfolio.get("unique_allocations"),
                "rough_ess_time_sec": portfolio.get("rough_ess_time_sec"),
                "rough_max_swap": portfolio.get("rough_max_swap"),
                "final_candidates": portfolio.get("final_candidates"),
                "final_refine_time_sec": portfolio.get("final_refine_time_sec"),
                "elapsed_sec": portfolio.get("elapsed_sec"),
                "stop_reason": portfolio.get("stop_reason"),
                "early_stop_patience_sec": portfolio.get("early_stop_patience_sec"),
                "early_stop_min_evaluations": portfolio.get("early_stop_min_evaluations"),
                "best_score": portfolio.get("best_score"),
                "best_composition_by_site": portfolio.get("best_composition_by_site"),
                "transfer_summary": portfolio.get("transfer_summary"),
                "leaderboard": portfolio.get("leaderboard"),
                "shared_budget": allocation_meta.get("shared_budget"),
                "coupled_solve": allocation_meta.get("coupled_solve"),
                "mpi": portfolio.get("mpi"),
            }
    return summary


def _apply_output_selection(
    *,
    resolved_workdir: Path,
    output_config,
    energy_tracker: _EnergyTracker,
    outputs: dict[str, str],
) -> None:
    selection = getattr(output_config, "selection", None)
    if selection is None or not selection.enabled:
        return
    candidates: list[tuple[float, Path]] = []
    for energy, path in energy_tracker.snapshots:
        if path.exists():
            candidates.append((float(energy), Path(path)))
    if not candidates:
        for key in ("best_poscar", "worst_poscar"):
            path_str = outputs.get(key)
            if not path_str:
                continue
            p = Path(path_str)
            if p.exists():
                candidates.append((0.0, p))
    if not candidates:
        return
    if selection.pick == "highest":
        ordered = sorted(candidates, key=lambda item: item[0], reverse=True)
    elif selection.pick == "random":
        import random
        rng = random.Random(selection.seed)
        ordered = list(candidates)
        rng.shuffle(ordered)
    else:
        ordered = sorted(candidates, key=lambda item: item[0])
    limit = max(1, int(selection.limit))
    picked = ordered[:limit]
    outdir = resolved_workdir / selection.outdir
    outdir.mkdir(parents=True, exist_ok=True)
    index_rows = ["rank\tenergy_eV\tsource\tselected\n"]
    selected_paths: list[str] = []
    for idx, (energy, source_path) in enumerate(picked, start=1):
        dst = outdir / f"{selection.prefix}-{idx:04d}.vasp"
        dst.write_text(source_path.read_text(encoding="utf-8"), encoding="utf-8")
        selected_paths.append(str(dst))
        index_rows.append(f"{idx}\t{energy:.12f}\t{source_path}\t{dst}\n")
    outputs["selection_dir"] = str(outdir)
    outputs["selection_index"] = str(outdir / "index.tsv")
    outputs["selection_count"] = str(len(selected_paths))
    if selection.write_index_tsv:
        _write_text(outdir / "index.tsv", "".join(index_rows))


def _write_text(path: Path, text: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return str(path)


def _copy_text_file(source: str | Path, destination: Path) -> str:
    source_path = Path(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    return _write_text(destination, source_path.read_text())


def _copy_recommended_poscar(source: str | Path, destination: Path) -> str:
    text = Path(source).read_text()
    lines = text.splitlines()
    if lines:
        title = lines[0]
        if re.search(r"\([^)]*best[^)]*\)", title, flags=re.IGNORECASE):
            title = re.sub(
                r"\([^)]*best[^)]*\)",
                "(recommended best)",
                title,
                count=1,
                flags=re.IGNORECASE,
            )
        elif " | charges:" in title:
            title = title.replace(" | charges:", " (recommended best) | charges:", 1)
        else:
            title = f"{title} (recommended best)"
        lines[0] = title
        text = "\n".join(lines) + "\n"
    destination.parent.mkdir(parents=True, exist_ok=True)
    return _write_text(destination, text)


def _write_structure_aliases(
    *,
    resolved_workdir: Path,
    outputs: dict[str, str],
    best_filename: str,
) -> None:
    """Write the single top-level best POSCAR from the selected source."""
    recommended_source = outputs.get("recommended_poscar")
    if not recommended_source:
        return
    outputs["recommended_source_poscar"] = recommended_source
    outputs["best_poscar"] = _copy_recommended_poscar(
        recommended_source,
        resolved_workdir / best_filename,
    )
    outputs["recommended_poscar"] = outputs["best_poscar"]
