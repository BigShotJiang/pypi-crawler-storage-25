from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .add_sites_mc import (
    AddSitesMonteCarloGlobalResult,
    AddSitesMonteCarloOptions,
    AddSitesMonteCarloResult,
    run_add_sites_monte_carlo,
    run_add_sites_monte_carlo_mpi,
)
from .add_sites_text import parse_add_sites_monte_carlo_spec
from .models import StructureModel
from .poscar import load_poscar
from .wyc import parse_wyc_file_to_symmetry_model


@dataclass
class AddSitesExecutionInput:
    solver_text_path: Path
    poscar_path: Path
    wyc_path: Path | None = None
    space_group: int = 1
    charges_by_kind: Mapping[str, float] | None = None


def _structure_with_charges(
    structure: StructureModel, charges_by_kind: Mapping[str, float] | None
) -> StructureModel:
    if not charges_by_kind:
        return structure
    for site in structure.sites:
        if site.kind in charges_by_kind:
            site.oxidation = float(charges_by_kind[site.kind])
    return structure


def load_add_sites_execution_input(
    solver_text_path: str | Path,
    poscar_path: str | Path,
    *,
    wyc_path: str | Path | None = None,
    space_group: int = 1,
    charges_by_kind: Mapping[str, float] | None = None,
) -> tuple[StructureModel, dict]:
    spec = parse_add_sites_monte_carlo_spec(solver_text_path)
    if not spec.present:
        raise ValueError(f"add-sites block not present: {solver_text_path}")
    structure = load_poscar(poscar_path)
    structure = _structure_with_charges(structure, charges_by_kind)
    if wyc_path is not None:
        symmetry = parse_wyc_file_to_symmetry_model(wyc_path, space_group=space_group)
        if len(symmetry.wyc_operations) > 0:
            # parser path check only; MC path uses parsed spec + structure now.
            pass
    spec_payload = {
        "add_meshes": list(spec.add_meshes),
        "min_distance_between_added_sites": spec.min_distance_between_added_sites,
        "n_monte_carlo": spec.n_monte_carlo,
        "monte_carlo_monitor_index": spec.monte_carlo_monitor_index,
        "added_kinds": [
            {
                "kind": add_kind.kind,
                "n_added": add_kind.n_added,
                "oxidation": add_kind.oxidation,
                "neighbor_kinds": [
                    {
                        "kind": neighbor.kind,
                        "doxidation": neighbor.doxidation,
                        "dist_min": neighbor.dist_min,
                        "dist_max": neighbor.dist_max,
                    }
                    for neighbor in add_kind.neighbor_kinds
                ],
            }
            for add_kind in spec.added_kinds
        ],
    }
    return structure, spec_payload


def run_add_sites_from_solver_text(
    solver_text_path: str | Path,
    poscar_path: str | Path,
    *,
    options: AddSitesMonteCarloOptions | Mapping[str, object] | None = None,
    wyc_path: str | Path | None = None,
    space_group: int = 1,
    charges_by_kind: Mapping[str, float] | None = None,
) -> AddSitesMonteCarloResult:
    structure, spec = load_add_sites_execution_input(
        solver_text_path,
        poscar_path,
        wyc_path=wyc_path,
        space_group=space_group,
        charges_by_kind=charges_by_kind,
    )
    return run_add_sites_monte_carlo(structure, spec, options)


def run_add_sites_from_solver_text_mpi(
    solver_text_path: str | Path,
    poscar_path: str | Path,
    *,
    options: AddSitesMonteCarloOptions | Mapping[str, object] | None = None,
    wyc_path: str | Path | None = None,
    space_group: int = 1,
    charges_by_kind: Mapping[str, float] | None = None,
    use_mpi: bool = True,
    comm=None,
) -> AddSitesMonteCarloGlobalResult:
    structure, spec = load_add_sites_execution_input(
        solver_text_path,
        poscar_path,
        wyc_path=wyc_path,
        space_group=space_group,
        charges_by_kind=charges_by_kind,
    )
    return run_add_sites_monte_carlo_mpi(
        structure,
        spec,
        options,
        use_mpi=use_mpi,
        comm=comm,
    )
