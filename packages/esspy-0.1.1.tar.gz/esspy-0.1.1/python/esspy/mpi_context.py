from __future__ import annotations

import os
from typing import Any


def detect_mpi_context() -> dict[str, Any]:
    """Return MPI context with an environment-variable fallback.

    `mpi4py` is authoritative when available.  The fallback detects rank/size
    from common launcher variables so non-root ranks can suppress console and
    output writing even if `mpi4py` is unavailable in the console-script
    environment.
    """
    try:
        from mpi4py import MPI
    except Exception:
        return _context_from_env()

    comm = MPI.COMM_WORLD
    size = int(comm.Get_size())
    if size <= 1:
        return _context_from_env()
    return {"comm": comm, "rank": int(comm.Get_rank()), "size": size}


def mpi_rank() -> int:
    return int(detect_mpi_context()["rank"])


def _context_from_env() -> dict[str, Any]:
    rank = _first_int(
        "OMPI_COMM_WORLD_RANK",
        "PMIX_RANK",
        "PMI_RANK",
        "SLURM_PROCID",
        default=0,
    )
    size = _first_int(
        "OMPI_COMM_WORLD_SIZE",
        "PMIX_SIZE",
        "PMI_SIZE",
        "SLURM_NTASKS",
        default=1,
    )
    if size <= 1:
        return {"comm": None, "rank": 0, "size": 1}
    return {"comm": None, "rank": rank, "size": size}


def _first_int(*names: str, default: int) -> int:
    for name in names:
        value = os.environ.get(name)
        if value is None:
            continue
        try:
            return int(value)
        except ValueError:
            continue
    return default
