from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from typing import Any, Mapping

from .models import ReadyModel
from .native import load_native_module


@dataclass
class ReadyFileWriteOptions:
    target_cpu_time_sec: int = 600
    running_index_delta: int = 0
    chop_level: int = 8
    verbose: int = 0
    create_recipe_strict_mode: int = 0
    print_stablest_unstablest: int = 1
    running_index_monitor: int = 10000
    swap: int = 1
    max_swap: int = 100
    restart_recipe_filename: str = "none"
    n_energy_table_line: int = 1
    energy_table_default_line: str = "-1000000000000000000000000000 0 X"
    output_prefix_suffix: str = "_001"


def _ready_payload(ready: ReadyModel | Mapping[str, Any]) -> dict:
    if is_dataclass(ready):
        return asdict(ready)
    if isinstance(ready, Mapping):
        return dict(ready)
    raise TypeError(
        "write_ready_file_text expected a ReadyModel or mapping, got "
        + repr(type(ready))
    )


def write_ready_file_text(
    ready: ReadyModel | Mapping[str, Any],
    options: ReadyFileWriteOptions | Mapping[str, Any] | None = None,
) -> str:
    """Render the typed ReadyModel as the original Guider's ready file text."""

    native = load_native_module()
    payload = _ready_payload(ready)
    if options is None:
        options_payload: dict = {}
    elif is_dataclass(options):
        options_payload = asdict(options)
    elif isinstance(options, Mapping):
        options_payload = dict(options)
    else:
        raise TypeError(
            "write_ready_file_text expected a ReadyFileWriteOptions or mapping, "
            "got " + repr(type(options))
        )
    return native.write_ready_file_text(payload, options_payload)
