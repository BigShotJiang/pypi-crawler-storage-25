from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Lattice:
    a: tuple[float, float, float]
    b: tuple[float, float, float]
    c: tuple[float, float, float]


@dataclass
class Site:
    kind: str
    x: float
    y: float
    z: float
    oxidation: float = 0.0


@dataclass
class StructureModel:
    title: str
    lattice: Lattice
    sites: list[Site]
    fractional_coordinates: bool = True


@dataclass
class CompositionEntry:
    kind: str
    count: int


@dataclass
class CompositionModel:
    entries: list[CompositionEntry]
    n_target_sites: int
    number_fixed_at: str = "O"


@dataclass
class ChargeEntry:
    kind: str
    oxidation: float


@dataclass
class ChargeMap:
    values: list[ChargeEntry]


@dataclass
class RecipeSpec:
    from_kind: str
    to: list[str]


@dataclass
class RecipeAssignment:
    from_kind: str
    assigned_counts: list[CompositionEntry]


@dataclass
class SymmetryOperation:
    matrix: tuple[
        tuple[float, float, float, float],
        tuple[float, float, float, float],
        tuple[float, float, float, float],
    ]


@dataclass
class SymmetryModel:
    space_group: int = 1
    wyc_operations: list[SymmetryOperation] = field(default_factory=list)
    from_spglib: bool = False


@dataclass
class GuideOptions:
    n_random_seeds: int = 2000
    shell_width: float = 1.0
    wyc_identity_length: float = 0.2
    abc_weights: tuple[float, float, float] = (2.0, 2.0, 1.0)
    chop_level: int = 100
    target_cpu_time_sec: int = 600
    strict_no_added_sites: bool = False
    skip_rg_optimization: bool = False
    skip_ewald_evaluation: bool = False
    fixed_rg_find_factor: int | None = None


@dataclass
class ParallelRuntimeOptions:
    use_mpi: bool = False
    world_size: int = 1
    rank: int = 0


@dataclass
class LoggingOptions:
    console: bool = True
    file: bool = True
    progress_jsonl: bool = True
    per_rank_logs: bool = True
    interval_sec: float = 10.0
    write_best_so_far: bool = True


@dataclass
class GuideInput:
    structure: StructureModel
    composition: CompositionModel
    charges: ChargeMap
    recipes: list[RecipeSpec]
    supercell_expansion: tuple[int, int, int] | None = None
    symmetry: SymmetryModel = field(default_factory=SymmetryModel)
    options: GuideOptions = field(default_factory=GuideOptions)


@dataclass
class ReadyAtom:
    kind: str
    oxidation: float
    x: float
    y: float
    z: float


@dataclass
class ReadyRecipeModification:
    to: str
    oxidation: float
    count: int


@dataclass
class ReadyRecipe:
    from_kind: str
    oxidation: float
    random_pickup: int
    random_pickup_trial: int
    modifications: list[ReadyRecipeModification]


@dataclass
class ReadyModel:
    lattice: Lattice
    atoms: list[ReadyAtom]
    poscar_species_counts: list[CompositionEntry] = field(default_factory=list)
    supercell_expansion: tuple[int, int, int] = (1, 1, 1)
    rg_find_factor: int = 1
    chop_level: float = 8.0
    output_prefix: str = ""
    recipes: list[ReadyRecipe] = field(default_factory=list)


@dataclass
class GuideDiagnostics:
    n_atom_config: int = 0
    supercell_expansion: tuple[int, int, int] = (1, 1, 1)
    rg_find_factor: int = 1
    resolved_assignments: list[RecipeAssignment] = field(default_factory=list)
    messages: list[str] = field(default_factory=list)


@dataclass
class GuideResult:
    ready: ReadyModel
    diagnostics: GuideDiagnostics


@dataclass
class EnergyTable:
    count: int = 0
    sum_e: float = 0.0
    sum_e2: float = 0.0
    min_e: float = 0.0
    max_e: float = 0.0


@dataclass
class SolveOptions:
    verbose: bool = False
    create_recipe_strict_mode: bool = False
    print_stablest_unstablest: bool = False
    running_index_delta: int = 10000
    running_index_monitor: int = 10000
    local_enumeration_offset: int = 0
    local_enumeration_limit: int = 32
    local_enumeration_max_chunks: int = 1
    local_enumeration_stride: int = 1
    enumeration_exhaust_all: bool = False
    enumeration_save_memory: bool = False
    mpi_adaptive_stride_sync: bool = False
    mpi_dynamic_chunking: bool = False
    mpi_chunk_min: int = 512
    mpi_chunk_max: int = 20000
    mpi_scheduler_heartbeat: int = 16
    adaptive_stride_override_9: int = 0
    adaptive_stride_override_19: int = 0
    adaptive_stride_scale_secondary: bool = True
    swap: bool = True
    max_swap: int = 2
    restart_recipe_filename: str = ""
    swap_loop_enabled: bool = True
    swap_loop_mode: int = 1
    swap_loop_seed_source: int = 1
    swap_loop_starting_sites: list[Site] = field(default_factory=list)
    progress_include_best_structure: bool = False


@dataclass
class SolveInput:
    ready: ReadyModel
    options: SolveOptions = field(default_factory=SolveOptions)
    runtime: ParallelRuntimeOptions = field(default_factory=ParallelRuntimeOptions)


@dataclass
class StructureSnapshot:
    structure: StructureModel | None
    energy: float
    label: str


@dataclass
class EnergySummary:
    global_e_min: float = 0.0
    global_e_max: float = 0.0
    total_cpu_time: float = 0.0
    global_count_total: int = 0


@dataclass
class SearchSpaceEntry:
    from_kind: str
    random_pickup: int
    random_pickup_trial: int
    unchanged_count: int
    assigned_counts: list[CompositionEntry]
    jobsize_u64: int
    jobsize_ld: float
    first_candidate_indices: list[int]
    first_candidate_labels: list[str]
    candidate_count_log10: float
    jobsize_saturated: bool = False


@dataclass
class WorkSliceRange:
    recipe_index: int
    start: int
    end: int


@dataclass
class WorkSliceSummary:
    integer_job: bool = True
    primary_recipe_index: int = -1
    world_size: int = 1
    rank: int = 0
    has_saturated_jobsize: bool = False
    recipe_ranges: list[WorkSliceRange] = field(default_factory=list)


@dataclass
class FirstEnumerationState:
    recipe_index: int = -1
    candidate_index: int = 0
    candidate_indices: list[int] = field(default_factory=list)
    candidate_labels: list[str] = field(default_factory=list)


@dataclass
class CandidateWindowEntry:
    candidate_index: int = 0
    candidate_indices: list[int] = field(default_factory=list)
    candidate_labels: list[str] = field(default_factory=list)


@dataclass
class PrimarySliceWindow:
    recipe_index: int = -1
    start_index: int = 0
    end_index: int = 0
    available_count: int = 0
    decoded_count: int = 0
    requested_offset: int = 0
    next_offset: int = 0
    has_more: bool = False
    candidates: list[CandidateWindowEntry] = field(default_factory=list)


@dataclass
class WindowEvaluationEntry:
    candidate_index: int = 0
    energy: float = 0.0
    candidate_indices: list[int] = field(default_factory=list)
    candidate_labels: list[str] = field(default_factory=list)
    snapshot: StructureSnapshot | None = None


@dataclass
class WindowEvaluationSummary:
    recipe_index: int = -1
    local_e_min: float = 0.0
    local_e_max: float = 0.0
    local_best_candidate_index: int = 0
    local_worst_candidate_index: int = 0
    local_count_total: int = 0
    entries: list[WindowEvaluationEntry] = field(default_factory=list)


@dataclass
class SearchSpaceSummary:
    entries: list[SearchSpaceEntry] = field(default_factory=list)
    primary_recipe_index: int = -1
    total_candidate_count_log10: float = 0.0
    work_slice: WorkSliceSummary = field(default_factory=WorkSliceSummary)
    first_enumeration: FirstEnumerationState = field(default_factory=FirstEnumerationState)
    primary_slice_window: PrimarySliceWindow = field(default_factory=PrimarySliceWindow)


@dataclass
class LocalEnumerationLoopState:
    initial_offset: int = 0
    chunk_limit: int = 0
    max_chunks: int = 1
    exhaust_all: bool = False
    processed_chunks: int = 0
    processed_candidates: int = 0
    next_offset: int = 0
    has_more: bool = False


@dataclass
class LocalReductionSummary:
    rank: int = 0
    world_size: int = 1
    primary_recipe_index: int = -1
    processed_chunks: int = 0
    processed_candidates: int = 0
    initial_offset: int = 0
    next_offset: int = 0
    has_more: bool = False
    exhaust_all: bool = False
    has_samples: bool = False
    local_e_min: float = 0.0
    local_e_max: float = 0.0
    local_best_candidate_index: int = 0
    local_worst_candidate_index: int = 0
    local_de_min_swap: float = 0.0
    local_swap_count: int = 0
    local_best_structure: StructureModel | None = None
    local_worst_structure: StructureModel | None = None
    local_best_structure_present: bool = False
    local_worst_structure_present: bool = False
    local_energy_table: EnergyTable = field(default_factory=EnergyTable)


@dataclass
class SolveResult:
    summary: EnergySummary
    search_space: SearchSpaceSummary = field(default_factory=SearchSpaceSummary)
    window_evaluation: WindowEvaluationSummary = field(default_factory=WindowEvaluationSummary)
    local_enumeration_loop: LocalEnumerationLoopState = field(default_factory=LocalEnumerationLoopState)
    local_reduction: LocalReductionSummary = field(default_factory=LocalReductionSummary)
    best: StructureSnapshot | None = None
    worst: StructureSnapshot | None = None
    energy_table: EnergyTable = field(default_factory=EnergyTable)
    messages: list[str] = field(default_factory=list)
    mpi_stats: dict[str, object] = field(default_factory=dict)


@dataclass
class RunInput:
    guide: GuideInput
    solve: SolveOptions = field(default_factory=SolveOptions)
    runtime: ParallelRuntimeOptions = field(default_factory=ParallelRuntimeOptions)
    logging: LoggingOptions = field(default_factory=LoggingOptions)


@dataclass
class RunResult:
    guide: GuideResult
    solve: SolveResult
