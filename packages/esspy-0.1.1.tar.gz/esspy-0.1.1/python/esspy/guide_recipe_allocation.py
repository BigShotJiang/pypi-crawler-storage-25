from __future__ import annotations

from dataclasses import dataclass, field

from .models import ChargeMap, CompositionEntry, RecipeSpec
from .native import load_native_module


@dataclass
class PrimitiveCellIon:
    kind: str
    n: int
    oxidation: float = 0.0


@dataclass
class AllocatedCellIon:
    kind: str
    n_primitive: int
    oxidation: float
    need: int
    delta_need: int
    skipped_in_other_recipe: bool
    has_recipe: bool


@dataclass
class FinalRecipeModification:
    to: str
    oxidation: float
    number: int


@dataclass
class FinalRecipe:
    from_kind: str
    oxidation: float
    random_pickup: int
    random_pickup_trial: int
    vac: int
    modifications: list[FinalRecipeModification] = field(default_factory=list)


@dataclass
class RecipeAllocationResult:
    cellions: list[AllocatedCellIon]
    final_recipes: list[FinalRecipe]
    need_wyc: bool
    log: list[str]


def _primitive_cellion_payload(cellion: PrimitiveCellIon) -> dict:
    return {"kind": cellion.kind, "n": cellion.n, "oxidation": cellion.oxidation}


def _target_count_payload(entry: CompositionEntry) -> dict:
    return {"kind": entry.kind, "count": entry.count}


def _recipe_payload(recipe: RecipeSpec) -> dict:
    return {"from": recipe.from_kind, "to": list(recipe.to)}


def _charges_payload(charges: ChargeMap) -> dict:
    return {
        "values": [
            {"kind": entry.kind, "oxidation": entry.oxidation}
            for entry in charges.values
        ]
    }


def compute_recipe_allocation(
    primitive_cellions: list[PrimitiveCellIon],
    target_counts: list[CompositionEntry],
    supercell_exp: int,
    strict_no_added_sites: bool,
    recipes: list[RecipeSpec],
    charges: ChargeMap,
) -> RecipeAllocationResult:
    """Run the Guider recipe-allocation step via the native library."""

    native = load_native_module()
    payload = native.compute_recipe_allocation(
        [_primitive_cellion_payload(c) for c in primitive_cellions],
        [_target_count_payload(t) for t in target_counts],
        int(supercell_exp),
        bool(strict_no_added_sites),
        [_recipe_payload(r) for r in recipes],
        _charges_payload(charges),
    )

    cellions = [
        AllocatedCellIon(
            kind=item["kind"],
            n_primitive=int(item["n_primitive"]),
            oxidation=float(item["oxidation"]),
            need=int(item["need"]),
            delta_need=int(item["delta_need"]),
            skipped_in_other_recipe=bool(item["skipped_in_other_recipe"]),
            has_recipe=bool(item["has_recipe"]),
        )
        for item in payload["cellions"]
    ]
    final_recipes = [
        FinalRecipe(
            from_kind=item["from"],
            oxidation=float(item["oxidation"]),
            random_pickup=int(item["random_pickup"]),
            random_pickup_trial=int(item["random_pickup_trial"]),
            vac=int(item["vac"]),
            modifications=[
                FinalRecipeModification(
                    to=mod["to"],
                    oxidation=float(mod["oxidation"]),
                    number=int(mod["number"]),
                )
                for mod in item["modifications"]
            ],
        )
        for item in payload["final_recipes"]
    ]
    return RecipeAllocationResult(
        cellions=cellions,
        final_recipes=final_recipes,
        need_wyc=bool(payload["need_wyc"]),
        log=[str(line) for line in payload["log"]],
    )
