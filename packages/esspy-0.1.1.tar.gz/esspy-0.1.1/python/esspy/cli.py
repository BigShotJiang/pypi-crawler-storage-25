from __future__ import annotations

import argparse
import contextlib
import json
import re
from pathlib import Path
import shlex
import sys
from typing import Any, Callable

from .cli_common import enable_helpful_argparse_errors, print_result
from .cli_examples import (
    ALLOCATION_OPTIMIZE_EPILOG,
    ADD_SITES_EXPORT_SPEC_EPILOG,
    FIT_CHARGE_EPILOG,
    GUIDE_INSPECT_EPILOG,
    GUIDE_EXPORT_GUIDER_EPILOG,
    GUIDE_EXPORT_READY_EPILOG,
    INIT_FROM_GUIDER_EPILOG,
    INIT_FROM_POSCAR_EPILOG,
    RUN_EPILOG,
    SOLVE_RUN_EPILOG,
    SYMMETRY_DETECT_EPILOG,
    SYMMETRY_INSPECT_WYC_EPILOG,
    SYMMETRY_WRITE_WYC_EPILOG,
)
from .poscar import load_poscar
from .default_charges import build_default_charges
from .symmetry_auto import detect_symmetry_with_spglib, write_wyc_file
from .wyc import parse_wyc_file, parse_wyc_file_to_symmetry_model

enable_helpful_argparse_errors()


Handler = Callable[[argparse.Namespace, argparse.ArgumentParser], int]


def _load_yaml_config(yaml_path: str) -> dict:
    """Load YAML configuration file."""
    import yaml
    with open(yaml_path) as f:
        return yaml.safe_load(f)


def _generate_add_sites_solver_config(species: str, count: int, add_sites_config: dict, charges: dict) -> str:
    """Generate add-sites solver configuration text.

    Returns the configuration as a string suitable for esspy add-sites.
    """
    grid_spacing = add_sites_config.get('grid_spacing', [0.5, 0.5, 0.5])
    if isinstance(grid_spacing, list):
        grid_str = ' '.join(str(x) for x in grid_spacing)
    else:
        grid_str = str(grid_spacing)

    min_distance = add_sites_config.get('min_distance', 1.5)
    num_mc = add_sites_config.get('num_monte_carlo', 100)
    energy_field = add_sites_config.get('energy_field', 'O')

    charge = charges.get(species, 1.0)

    # Generate solver config (format expected by esspy add-sites)
    config_lines = [
        "# Add-sites solver configuration (auto-generated)",
        "NEnergyTableLine 1",
        "NAddKind 1",
        f"AddMeshes {grid_str}",
        f"MinDistanceBetweenAddedSites {min_distance}",
        f"NMonteCarlo {num_mc}",
        "MonteCarloMonitorIndex 1",
        "",
        f"{species} {count} {charge} {energy_field} 0.0 0.0 10000.0",
    ]

    return '\n'.join(config_lines)


def _extract_composition_from_poscar(poscar_path) -> dict:
    """Extract element composition from POSCAR file."""
    try:
        from .poscar import load_poscar
        structure = load_poscar(poscar_path)
        composition = {}
        for site in structure.sites:
            element = site.species.keys()[0] if hasattr(site.species, 'keys') else str(site.species)
            composition[element] = composition.get(element, 0) + 1
        return composition
    except:
        return {}


def _resolve_workdir(requested: str) -> "Path":
    """Return a fresh workdir path, appending a timestamp if the path already exists.

    This keeps step subdirectories clean (no -NEW01 suffixes) while still
    preventing accidental overwrites.
    """
    from pathlib import Path

    base = Path(requested)
    if not base.exists():
        return base
    # Already exists → find next available -NEW## suffix
    for n in range(1, 1000):
        candidate = base.parent / f"{base.name}-NEW{n:02d}"
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Could not find a free workdir under {base.parent}")


def _add_poscar_metadata(poscar_path: Path, charges: dict, rg_factor: int) -> None:
    """Add charge/RG info to POSCAR title line for later retrieval."""
    lines = poscar_path.read_text().splitlines()
    if not lines:
        return
    title = lines[0]
    charge_str = " ".join(f"{k}={v:g}" for k, v in sorted(charges.items()))
    new_title = f"{title} | charges: {charge_str} | RG={rg_factor}"
    lines[0] = new_title
    poscar_path.write_text("\n".join(lines) + "\n")


def _execute_interstitial_driven_workflow(
    yaml_path: str,
    workdir: str = None,
    guide_only: bool = False,
    quiet: bool = False,
    json_stdout: bool = False,
    no_progress: bool = False,
    progress_interval_sec: float = 1.0,
    progress_log_file: str = None,
) -> dict:
    """Execute interstitial-driven workflow (host enum → add-sites → placement).

    Flat output layout:
        workdir/
          input.yaml                  ← copy of original input
          input_final.yaml            ← rerun config pointing at final structure
          POSCAR_host_best.vasp       ← most stable host structure
          POSCAR_host_worst.vasp      ← most unstable host structure
          POSCAR_host_supercell.vasp  ← base supercell before substitution
          POSCAR_final+{Li}.vasp      ← final structure with interstitial
          host_enum.yaml              ← enumeration config
          host_summary.json           ← enumeration statistics
          host_energies.txt           ← energy improvement history
          addsites_config.txt         ← MC solver config
          addsites.log                ← MC optimization log
          summary.log                 ← unified run log (all 3 steps)
          logs/                       ← internal esspy files
    """
    import shutil
    import json as _json
    import re as _re
    import yaml
    from datetime import datetime as _dt
    from pathlib import Path
    from .run_outputs import run_yaml_to_outputs
    from .add_sites_pipeline import run_add_sites_from_solver_text
    from .add_sites_mc import AddSitesMonteCarloOptions
    from .poscar import write_structure_to_poscar

    config = _load_yaml_config(yaml_path)
    interstitial = config.get('interstitial', {})
    if not interstitial:
        raise ValueError("Expected 'interstitial' section in YAML for interstitial-driven workflow")

    requested_workdir = workdir or config.get('output', {}).get('workdir', 'run-output')
    workdir = _resolve_workdir(requested_workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    logs_dir = workdir / "logs"
    logs_dir.mkdir(exist_ok=True)

    species = interstitial.get('species')
    count   = interstitial.get('count', 1)
    run_started = _dt.now()

    print(f"\n{'='*70}")
    print("Interstitial-Driven Workflow")
    print(f"{'='*70}")
    print(f"Output directory : {workdir}")
    print(f"Interstitial     : {species} × {count}")

    shutil.copy(yaml_path, workdir / "input.yaml")

    # ──────────────────────────────────────────────
    # Step 1: Host Enumeration
    # ──────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("Step 1: Host Enumeration")
    print(f"{'='*70}")

    host_charges = {k: v for k, v in config.get('charges', {}).items() if k != species}
    host_recipes = [r for r in config.get('recipes', []) if r.get('from_kind') != species]
    host_config  = {k: v for k, v in config.items() if k not in ('interstitial', 'charges', 'recipes')}
    host_config['charges'] = host_charges
    host_config['recipes'] = host_recipes

    # Write temp YAML; esspy creates _enum_tmp itself (pre-creating causes -NEW01)
    host_yaml_tmp = workdir / "host_enum_tmp.yaml"
    with open(host_yaml_tmp, 'w') as f:
        yaml.dump(host_config, f, default_flow_style=False, sort_keys=False)

    # Pre-flight: guide-only check for composition mismatch
    _enum_tmp = workdir / "_enum_tmp"
    guide_check_dir = workdir / "_guide_check"
    try:
        run_yaml_to_outputs(
            str(host_yaml_tmp), workdir=str(guide_check_dir),
            guide_only=True, quiet=True, json_stdout=False, no_progress=True,
        )
        gc_summary = guide_check_dir / "summary.json"
        if gc_summary.exists():
            with open(gc_summary) as f:
                gc = _json.load(f)
            gc_guide = gc.get('guide', {})
            sc = gc_guide.get('supercell_expansion', [])
            n_unit   = gc_guide.get('n_atom_config', 0)
            n_actual = n_unit * sc[0] * sc[1] * sc[2] if sc else 0
            leftover: list[tuple[str, int]] = []
            for recipe in gc_guide.get('recipes', []):
                src = recipe['from']
                real_targets = {m['to'] for m in recipe.get('modifications', []) if m['to'] != 'vac'}
                if real_targets <= {src}:  # identity recipe (O→O), harmless
                    continue
                for mod in recipe.get('modifications', []):
                    if mod['to'] == 'vac' and mod['count'] > 0:
                        leftover.append((src, mod['count']))
            if leftover:
                n_req = config['structure'].get('n_target_sites', '?')
                print(f"\n{'!'*70}")
                print(f"⚠  COMPOSITION MISMATCH DETECTED")
                print(f"{'!'*70}")
                print(f"  Requested target   : {n_req} atoms")
                print(f"  Actual supercell   : {sc[0]}×{sc[1]}×{sc[2]} = {n_actual} atoms")
                print()
                for src, cnt in leftover:
                    print(f"  {src} sites unsubstituted: {cnt}  → {cnt} {src} atoms will remain in output")
                print()
                suggested: dict[str, int] = {}
                for recipe in gc_guide.get('recipes', []):
                    src = recipe['from']
                    total_sites = recipe.get('random_pickup', 0)
                    real_mods = [m for m in recipe.get('modifications', []) if m['to'] != 'vac']
                    if not real_mods:
                        suggested[src] = total_sites
                    elif len(real_mods) == 1:
                        suggested[real_mods[0]['to']] = total_sites
                    else:
                        total_specified = sum(m['count'] for m in real_mods)
                        for m in real_mods:
                            ratio = m['count'] / total_specified if total_specified else 0
                            suggested[m['to']] = round(total_sites * ratio)
                        filled = sum(v for k, v in suggested.items() if k in [m['to'] for m in real_mods])
                        if filled != total_sites:
                            suggested[real_mods[0]['to']] += total_sites - filled
                print(f"  Suggested composition: {', '.join(f'{k}={v}' for k, v in sorted(suggested.items()))}")
                print(f"{'!'*70}\n")
    except Exception:
        pass
    finally:
        if guide_check_dir.exists():
            shutil.rmtree(guide_check_dir)

    run_yaml_to_outputs(
        str(host_yaml_tmp),
        workdir=str(_enum_tmp),
        guide_only=guide_only,
        quiet=quiet,
        json_stdout=False,
        no_progress=no_progress,
        progress_interval_sec=progress_interval_sec,
        progress_log_file=progress_log_file,
    )

    # Extract actual charges used for host enumeration (from workflow, not config)
    from .workflow import ESSWorkflow
    try:
        host_workflow = ESSWorkflow.from_yaml(str(host_yaml_tmp))
        host_charges_map = host_workflow.run_input.guide.charges
        host_charges = {entry.kind: entry.oxidation for entry in host_charges_map.values}
    except Exception:
        # Fallback to config charges if workflow load fails
        host_charges = {k: v for k, v in config.get('charges', {}).items() if k != species}

    # Read step 1 results
    step1_summary_path = _enum_tmp / "summary.json"
    step1_json = {}
    if step1_summary_path.exists():
        with open(step1_summary_path) as f:
            step1_json = _json.load(f)
    solve_stats = step1_json.get('solve', {})
    guide_stats = step1_json.get('guide', {})
    host_best_energy  = solve_stats.get('global_e_min')
    host_worst_energy = solve_stats.get('global_e_max')
    host_n_candidates = solve_stats.get('energy_table_count', 0)
    host_de_swap      = solve_stats.get('local_de_min_swap')
    outputs_map       = step1_json.get('outputs', {})
    supercell         = guide_stats.get('supercell_expansion')
    rg_find_factor    = guide_stats.get('rg_find_factor')

    search_space: int | None = None
    enum_log_src = _enum_tmp / "esspy.log"
    if enum_log_src.exists():
        for line in enum_log_src.read_text().splitlines():
            m = _re.search(r'primary_candidates=(\d+)', line)
            if m:
                search_space = int(m.group(1))
                break

    # Flatten: move key files to workdir, internal files to logs/
    POSCAR_host_best  = workdir / "POSCAR_host_best.vasp"
    POSCAR_host_worst = workdir / "POSCAR_host_worst.vasp"

    best_src  = Path(outputs_map['best_poscar'])  if 'best_poscar'  in outputs_map else None
    worst_src = Path(outputs_map['worst_poscar']) if 'worst_poscar' in outputs_map else None
    tmpl_src  = Path(outputs_map['poscar'])        if 'poscar'        in outputs_map else None

    if best_src and best_src.exists():
        shutil.move(str(best_src), POSCAR_host_best)
    else:
        cands = sorted(_enum_tmp.glob("*.best.POSCAR*")) or sorted(_enum_tmp.glob("*best*.POSCAR*"))
        if not cands:
            raise ValueError(f"Step 1 failed: no best POSCAR in {_enum_tmp}")
        shutil.move(str(cands[0]), POSCAR_host_best)

    if worst_src and worst_src.exists():
        shutil.move(str(worst_src), workdir / "POSCAR_host_worst.vasp")

    if tmpl_src and tmpl_src.exists():
        shutil.move(str(tmpl_src), workdir / "POSCAR_host_supercell.vasp")

    # Named reference files
    host_yaml_tmp.replace(workdir / "host_enum.yaml")
    if step1_summary_path.exists():
        shutil.move(str(step1_summary_path), workdir / "host_summary.json")
    energy_src = _enum_tmp / "energy_improvements.txt"
    if energy_src.exists():
        shutil.move(str(energy_src), workdir / "host_energies.txt")

    # Everything else → logs/
    for f in _enum_tmp.iterdir():
        shutil.move(str(f), logs_dir / f.name)
    _enum_tmp.rmdir()

    energy_str = f"E_best={host_best_energy:.4f} eV" if host_best_energy is not None else ""
    print(f"✓ Host enumeration complete  {energy_str}")
    if host_best_energy is not None and host_worst_energy is not None:
        spread = host_worst_energy - host_best_energy
        print(f"  Candidates  : {host_n_candidates}")
        print(f"  E_best      : {host_best_energy:.4f} eV  →  POSCAR_host_best.vasp")
        print(f"  E_worst     : {host_worst_energy:.4f} eV  →  POSCAR_host_worst.vasp")
        print(f"  ΔE (spread) : {spread:.4f} eV")
        if host_de_swap is not None:
            print(f"  ΔE (swap)   : {host_de_swap:.4f} eV")

    # ──────────────────────────────────────────────
    # Step 2: Add-Sites MC Optimization
    # ──────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("Step 2: Add-Sites MC Optimization")
    print(f"{'='*70}")

    add_sites_cfg = interstitial.get('add_sites', {})
    print(f"  Species      : {species} × {count}")
    print(f"  Grid spacing : {add_sites_cfg.get('grid_spacing', [0.5, 0.5, 0.5])}")
    print(f"  Min distance : {add_sites_cfg.get('min_distance', 1.5)} Å")
    print(f"  MC trials    : {add_sites_cfg.get('num_monte_carlo', 100)}")

    solver_config_text = _generate_add_sites_solver_config(
        species, count, add_sites_cfg, config.get('charges', {})
    )
    solver_config_path = workdir / "addsites_config.txt"
    with open(solver_config_path, 'w') as f:
        f.write(solver_config_text)

    add_sites_best_structure = None
    add_sites_best_energy    = None
    add_sites_accepted       = None
    add_sites_attempted      = None

    try:
        options = AddSitesMonteCarloOptions(
            random_seed=add_sites_cfg.get('random_seed', 0),
            rg_find_factor=add_sites_cfg.get('RGFindFactor', 1),
            chop_level=add_sites_cfg.get('chop_level', 8.0),
        )
        mc_result = run_add_sites_from_solver_text(
            str(solver_config_path),
            str(POSCAR_host_best),
            options=options,
            charges_by_kind=config.get('charges', {}),
        )
        if mc_result.log:
            with open(workdir / "addsites.log", 'w') as f:
                f.write('\n'.join(mc_result.log))
        if mc_result.success:
            add_sites_best_structure = mc_result.best_structure
            add_sites_best_energy    = mc_result.best_energy
            add_sites_accepted       = mc_result.accepted_trials
            add_sites_attempted      = mc_result.attempted_trials
            print(f"✓ Add-sites optimization complete")
            print(f"  Best energy : {add_sites_best_energy:.4f} eV")
            print(f"  Trials      : {add_sites_accepted}/{add_sites_attempted} accepted")
        else:
            print(f"⚠ Add-sites optimization did not converge")
    except Exception as e:
        print(f"⚠ Add-sites failed: {e}")

    # ──────────────────────────────────────────────
    # Step 3: Write Final Structure
    # ──────────────────────────────────────────────
    print(f"\n{'='*70}")
    print("Step 3: Final Structure")
    print(f"{'='*70}")

    final_poscar      = workdir / f"POSCAR_final+{species}.vasp"
    final_composition: dict = {}
    interstitial_positions: list = []

    if add_sites_best_structure is not None:
        for s in add_sites_best_structure.sites:
            if s.kind == species:
                interstitial_positions.append((s.x, s.y, s.z))
                print(f"  {species} placed at ({s.x:.4f}, {s.y:.4f}, {s.z:.4f})")
        poscar_text = write_structure_to_poscar(
            add_sites_best_structure,
            title=f"host+{species} (E={add_sites_best_energy:.4f} eV)",
        )
        with open(final_poscar, 'w') as f:
            f.write(poscar_text)
        # Add metadata to final POSCAR for reproducibility
        _add_poscar_metadata(final_poscar, host_charges, rg_find_factor or 3)
        for s in add_sites_best_structure.sites:
            final_composition[s.kind] = final_composition.get(s.kind, 0) + 1
    else:
        print(f"⚠ Add-sites unavailable — copying host structure without interstitial")
        shutil.copy(POSCAR_host_best, final_poscar)
        lines = final_poscar.read_text().splitlines()
        if len(lines) > 6:
            final_composition = dict(zip(lines[5].split(), [int(x) for x in lines[6].split()]))
        # Add metadata to final POSCAR for reproducibility
        _add_poscar_metadata(final_poscar, host_charges, rg_find_factor or 3)

    # Write input_final.yaml (rerun config pointing at the final structure)
    input_final_yaml = workdir / "input_final.yaml"
    final_config = dict(config)
    final_config['structure'] = dict(config.get('structure', {}))
    final_config['structure']['poscar'] = str(final_poscar)
    if final_composition:
        final_config['composition'] = final_composition
    with open(input_final_yaml, 'w') as f:
        yaml.dump(final_config, f, default_flow_style=False, sort_keys=False)

    # ──────────────────────────────────────────────
    # summary.log — unified log across all 3 steps
    # ──────────────────────────────────────────────
    comp_str = "  ".join(f"{el}{n}" for el, n in sorted(final_composition.items()))
    n_atoms  = sum(final_composition.values())
    W = 72
    sep = "─" * W

    log_lines: list[str] = []
    def _log(line: str = "") -> None:
        log_lines.append(line)
        if not quiet:
            pass  # summary already printed inline; this is file-only

    _log("=" * W)
    _log("ESSPY Run Summary")
    _log("=" * W)
    _log(f"Input         : input.yaml")
    _log(f"Started       : {run_started.strftime('%Y-%m-%d %H:%M')}")
    _log(f"Output dir    : {workdir}")
    _log()
    _log(sep)
    _log("[Step 1] Host Enumeration")
    _log(sep)
    if supercell:
        sc_str = "×".join(str(x) for x in supercell)
        n_recipes = len(guide_stats.get('recipes', []))
        _log(f"Supercell     : {sc_str} = {guide_stats.get('n_atom_config', '?')} unit × expansion  ({n_recipes} recipes)")
    if rg_find_factor:
        _log(f"RGFindFactor  : {rg_find_factor}")
    if search_space is not None:
        _log(f"Search space  : {search_space:,} configurations")
    if host_best_energy is not None:
        _log(f"Evaluated     : {host_n_candidates}")
        _log(f"E_best        : {host_best_energy:.4f} eV  →  POSCAR_host_best.vasp")
        if host_worst_energy is not None:
            _log(f"E_worst       : {host_worst_energy:.4f} eV  →  POSCAR_host_worst.vasp")
            _log(f"ΔE spread     : {host_worst_energy - host_best_energy:.4f} eV")
        if host_de_swap is not None:
            _log(f"ΔE swap       : {host_de_swap:.4f} eV")
    _log()
    _log(sep)
    _log("[Step 2] Add-Sites MC Optimization")
    _log(sep)
    _log(f"Species       : {species} × {count}")
    _log(f"Grid spacing  : {add_sites_cfg.get('grid_spacing', [0.5, 0.5, 0.5])}")
    _log(f"Min distance  : {add_sites_cfg.get('min_distance', 1.5)} Å")
    _log(f"MC trials     : {add_sites_cfg.get('num_monte_carlo', 100)}")
    if add_sites_best_energy is not None:
        _log(f"Trials done   : {add_sites_accepted}/{add_sites_attempted} accepted")
        _log(f"E(host+{species})  : {add_sites_best_energy:.4f} eV")
        for i, pos in enumerate(interstitial_positions):
            _log(f"{species}[{i}] position : ({pos[0]:.4f}, {pos[1]:.4f}, {pos[2]:.4f})")
    else:
        _log(f"Status        : not available")
    _log()
    _log(sep)
    _log("[Step 3] Final Structure")
    _log(sep)
    _log(f"Composition   : {comp_str}")
    _log(f"Total atoms   : {n_atoms}")
    _log(f"POSCAR        : POSCAR_final+{species}.vasp")
    _log(f"Rerun config  : input_final.yaml")
    _log()
    _log("=" * W)

    summary_log_path = workdir / "summary.log"
    summary_log_path.write_text("\n".join(log_lines) + "\n")

    # Print summary to stdout
    print(f"\n{'='*70}")
    print("Summary")
    print(f"{'='*70}")
    print(f"  Output directory  : {workdir}/")
    print()
    print(f"  [Step 1] Host Enumeration")
    if supercell:
        print(f"    Supercell       : {'×'.join(str(x) for x in supercell)}  ({len(guide_stats.get('recipes', []))} recipes)")
    if rg_find_factor:
        print(f"    RGFindFactor    : {rg_find_factor}")
    if search_space is not None:
        print(f"    Search space    : {search_space:,} configurations")
    if host_best_energy is not None:
        print(f"    Evaluated       : {host_n_candidates}")
        print(f"    E_best (host)   : {host_best_energy:.4f} eV")
        if host_worst_energy is not None:
            print(f"    E_worst (host)  : {host_worst_energy:.4f} eV")
            print(f"    ΔE spread       : {host_worst_energy - host_best_energy:.4f} eV")
        if host_de_swap is not None:
            print(f"    ΔE swap         : {host_de_swap:.4f} eV")
    print(f"    Best structure  : POSCAR_host_best.vasp")
    print()
    print(f"  [Step 2] Add-Sites MC")
    if add_sites_best_energy is not None:
        print(f"    Trials          : {add_sites_accepted}/{add_sites_attempted} accepted")
        print(f"    E (host+{species})   : {add_sites_best_energy:.4f} eV")
        for i, pos in enumerate(interstitial_positions):
            print(f"    {species}[{i}] position   : ({pos[0]:.4f}, {pos[1]:.4f}, {pos[2]:.4f})")
    else:
        print(f"    Status          : not available")
    print()
    print(f"  [Step 3] Final Structure")
    print(f"    Composition     : {comp_str}")
    print(f"    Total atoms     : {n_atoms}")
    print(f"    POSCAR          : POSCAR_final+{species}.vasp")
    print(f"    Rerun config    : input_final.yaml")
    print(f"    Full log        : summary.log")

    return {
        'success': True,
        'workdir': str(workdir),
        'host_structure': str(POSCAR_host_best),
        'final_structure': str(final_poscar),
        'final_yaml': str(input_final_yaml),
        'summary_log': str(summary_log_path),
        'host_best_energy': host_best_energy,
        'add_sites_energy': add_sites_best_energy,
        'final_composition': final_composition,
    }


def _parse_charges_json(raw: str | None) -> dict[str, float] | None:
    if raw is None:
        return None
    payload = json.loads(raw)
    if not isinstance(payload, dict):
        raise ValueError("--charges-json must decode to a JSON object")
    return {str(k): float(v) for k, v in payload.items()}


def _to_nested_charge_schema(
    flat_charges: dict[str, float],
    basis: str = "element",
    *,
    include_values: bool = True,
) -> dict:
    values: dict[str, float] = {}
    elements: dict[str, dict[str, object]] = {}
    for raw_key, raw_val in flat_charges.items():
        key = str(raw_key)
        val = float(raw_val)
        if "@" in key:
            elem, site = key.split("@", 1)
            elem = elem.strip()
            site = site.strip()
            node = elements.setdefault(elem, {"default": val, "by_site": {}})
            by_site = node.setdefault("by_site", {})
            if isinstance(by_site, dict):
                by_site[site] = val
        else:
            elem = key.strip()
            values[elem] = val
            elements.setdefault(elem, {"default": val})
    for elem, node in elements.items():
        by_site = node.get("by_site")
        if isinstance(by_site, dict) and by_site:
            node["default"] = float(sum(by_site.values()) / float(len(by_site)))
        if elem not in values:
            values[elem] = float(node.get("default", 0.0))
        if not include_values and isinstance(by_site, dict) and by_site:
            node.pop("default", None)
    block: dict[str, object] = {"basis": str(basis), "elements": elements}
    if include_values:
        block["values"] = values
    return block


def _split_kind_label(kind: str) -> tuple[str, str | None]:
    text = str(kind).strip()
    if "@" not in text:
        return text, None
    elem, site = text.split("@", 1)
    return elem.strip(), site.strip()


def _emit_init_result(args: argparse.Namespace, out: str, name: str) -> None:
    payload = {"out": out, "name": name}
    sposcar = getattr(args, "_sposcar", None)
    if sposcar is not None:
        payload["sposcar"] = str(sposcar)
    if getattr(args, "json", False):
        print_result(args, payload)
        return
    if getattr(args, "quiet", False):
        return
    print(f"Wrote {out} (name: {name})")
    if sposcar is not None:
        print(f"Wrote {sposcar}")


def _emit_init_result_with_example(
    args: argparse.Namespace, out: str, name: str, example_out: str | None
) -> None:
    payload = {"out": out, "name": name}
    sposcar = getattr(args, "_sposcar", None)
    if sposcar is not None:
        payload["sposcar"] = str(sposcar)
    if example_out is not None:
        payload["example_out"] = example_out
    if getattr(args, "json", False):
        print_result(args, payload)
        return
    if getattr(args, "quiet", False):
        return
    print(f"Wrote {out} (name: {name})")
    if sposcar is not None:
        print(f"Wrote {sposcar}")
    if example_out is not None:
        print(f"Wrote {example_out} (example templates)")


def _expand_counts_by_recipes(
    base_counts: dict[str, float], recipes: list
) -> dict[str, float]:
    """Redistribute source-species counts through recipe targets.

    Duplicate targets are treated as weights, e.g. `M:Mn,Ni,Cr,Ni`
    gives Ni double weight.
    """
    expanded: dict[str, float] = {kind: float(value) for kind, value in base_counts.items()}
    for recipe in recipes:
        from_kind = recipe.from_kind
        if from_kind not in expanded:
            continue
        source_count = float(expanded.pop(from_kind))
        n_targets = len(recipe.to)
        if n_targets <= 0:
            continue
        unit = source_count / float(n_targets)
        for kind in recipe.to:
            expanded[kind] = expanded.get(kind, 0.0) + unit
    return expanded


def _handle_version(_args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from . import __version__

    print(__version__)
    return 0


def _handle_run(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .run_outputs import run_yaml_to_outputs
    from .mpi_context import detect_mpi_context

    # Load YAML and check if this is a composition-driven or interstitial-driven workflow
    config = _load_yaml_config(args.input)

    # Check if interstitial section is present and populated
    mpi = detect_mpi_context()
    try:
        if config.get('interstitial') is None:
            # Composition-driven path: single enumeration
            # Note: metadata (charges + RG) is now added by run_yaml_to_outputs() itself
            # in run_outputs.py when POSCAR files are written
            summary = run_yaml_to_outputs(
                args.input,
                workdir=args.workdir,
                guide_only=args.guide_only,
                quiet=args.quiet,
                json_stdout=args.json,
                no_progress=args.no_progress,
                progress_interval_sec=args.progress_interval,
                progress_log_file=args.log_file,
                charge_model_path=args.charge_model,
            )
        else:
            # Interstitial-driven path: host enum + add-sites + placement
            summary = _execute_interstitial_driven_workflow(
                args.input,
                workdir=args.workdir,
                guide_only=args.guide_only,
                quiet=args.quiet,
                json_stdout=args.json,
                no_progress=args.no_progress,
                progress_interval_sec=args.progress_interval,
                progress_log_file=args.log_file,
            )
    except Exception as exc:
        if int(mpi.get("rank", 0)) == 0:
            print(f"ERROR: {exc}")
        return 1

    print_result(args, summary)
    return 0


def _handle_sample(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .sample_structures import write_random_samples_from_yaml

    requested_outdir = Path(args.outdir)
    outdir = requested_outdir
    if outdir.exists():
        base_name = outdir.name
        parent = outdir.parent
        for idx in range(1, 10000):
            candidate = parent / f"{base_name}-NEW{idx:02d}"
            if not candidate.exists():
                outdir = candidate
                break
        if outdir == requested_outdir:
            print(
                f"ERROR: could not find a free output directory for `{requested_outdir}`",
                file=sys.stderr,
            )
            return 1

    written = write_random_samples_from_yaml(
        args.input,
        n_samples=args.n,
        outdir=outdir,
        prefix=args.prefix,
        seed=args.seed,
    )
    result = {
        "input": str(args.input),
        "outdir": str(outdir),
        "count": len(written),
        "prefix": args.prefix,
        "seed": args.seed,
        "files": [str(path) for path in written],
    }
    print_result(args, result)
    return 0


def _handle_fit_charge(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .fit_charge import (
        build_dataset_from_patterns,
        fit_effective_charges,
        parse_dataset_file,
        update_poscar_charge_titles,
        write_parity_plot,
        write_dataset_file,
    )

    command_parser = getattr(args, "_command_parser", None)
    has_dataset = bool(args.dataset)
    has_poscar = bool(args.poscar)
    has_outcar = bool(args.outcar)

    def _progress(message: str) -> None:
        if getattr(args, "quiet", False):
            return
        print(f"[fit-charge] {message}", file=sys.stderr, flush=True)

    if not has_dataset and not has_poscar and not has_outcar:
        if command_parser is not None:
            command_parser.print_help()
            return 0
        _parser.print_help()
        return 0

    if has_dataset and (has_poscar or has_outcar):
        if command_parser is not None:
            command_parser.print_help(sys.stderr)
        print(
            "\nArgument issue: use either dataset file OR (-p/--poscar + --outcar), not both.",
            file=sys.stderr,
        )
        return 2

    if not has_dataset and (has_poscar != has_outcar):
        if command_parser is not None:
            command_parser.print_help(sys.stderr)
        print(
            "\nArgument issue: provide both -p/--poscar and --outcar together.",
            file=sys.stderr,
        )
        return 2

    dataset_meta: dict | None = None
    generated_dataset_path: Path | None = None
    if args.dataset:
        dataset_path = Path(args.dataset).resolve()
        _progress(f"Loading dataset: {dataset_path}")
        entries = parse_dataset_file(dataset_path)
    else:
        _progress("Matching POSCAR/OUTCAR patterns to build dataset...")
        entries, dataset_meta = build_dataset_from_patterns(
            list(args.poscar),
            list(args.outcar),
            strict=not bool(args.allow_partial),
        )
        generated_dataset_path = write_dataset_file(entries, args.dataset_out)
        dataset_path = generated_dataset_path
    _progress(f"Dataset ready: {len(entries)} samples")
    _progress(
        "Starting charge optimization "
        f"(method=Powell, xtol=1e-3, ftol=1e-3, maxiter={int(args.maxiter)})..."
    )

    out_model = Path(args.out_model).resolve()
    out_report = Path(args.out_report).resolve()
    out_plot = Path(args.out_plot).resolve()
    out_model.parent.mkdir(parents=True, exist_ok=True)
    out_report.parent.mkdir(parents=True, exist_ok=True)
    out_plot.parent.mkdir(parents=True, exist_ok=True)

    latest_snapshot: dict | None = None

    def _write_outputs_from_payload(payload: dict, *, update_poscar_titles: bool = False) -> None:
        basis = (
            "element_site"
            if str(payload.get("config", {}).get("charge_basis", "element")) == "element_site"
            else "element"
        )
        nested = _to_nested_charge_schema(
            payload["charges"],
            basis=basis,
            include_values=False,
        )
        anchor_elem, anchor_site = _split_kind_label(payload["anchor_kind"])
        kind_order_structured = []
        for kind in payload["kind_order"]:
            elem, site = _split_kind_label(kind)
            kind_order_structured.append(
                {"element": elem, "site_group": site, "label": str(kind)}
            )
        model_payload = {
            "model_type": "effective_element_charge",
            "schema_version": 2,
            "charge_basis": basis,
            "anchor": {
                "element": anchor_elem,
                "site_group": anchor_site,
                "label": str(payload["anchor_kind"]),
            },
            "kind_order": kind_order_structured,
            "charges": nested,
            "linear_map": payload["linear_map"],
            "ewald": {
                "rg_find_factor": payload["config"]["rg_find_factor"],
                "chop_level": payload["config"]["chop_level"],
            },
            "fit_metrics": payload["metrics"],
        }
        out_model.write_text(json.dumps(model_payload, indent=2))
        out_report.write_text(json.dumps(payload, indent=2))
        try:
            write_parity_plot(payload, out_plot)
        except Exception as exc:
            _progress(f"Parity plot write skipped: {exc}")
        if update_poscar_titles and not bool(getattr(args, "no_update_poscar_titles", False)):
            try:
                rg_value = int(payload["config"]["rg_find_factor"])
                updated = update_poscar_charge_titles(
                    [entry.structure_path for entry in entries],
                    payload["charges"],
                    kind_order=payload.get("kind_order"),
                    rg_find_factor=rg_value,
                )
                if updated:
                    _progress(
                        "Updated POSCAR title charges from fitted model: "
                        f"{len(updated)} file(s)"
                    )
            except Exception as exc:
                _progress(f"POSCAR title charge update skipped: {exc}")

    def _checkpoint(payload: dict) -> None:
        nonlocal latest_snapshot
        latest_snapshot = payload
        _write_outputs_from_payload(payload, update_poscar_titles=False)

    try:
        result = fit_effective_charges(
            entries,
            anchor_kind=str(args.anchor_kind),
            charge_basis=str(args.basis),
            input_yaml=args.input_yaml,
            rg_find_factor=int(args.rg_find_factor),
            chop_level=float(args.chop_level),
            maxiter=int(args.maxiter),
            objective_name=str(args.objective),
            reg_l2=float(args.reg_l2),
            reg_site_delta=float(args.reg_site_delta),
            map_mode=str(args.map_mode),
            energy_weight_mode=str(args.energy_weight_mode),
            energy_weight_temp_eV=float(args.energy_weight_temp_eV),
            low_energy_fraction=float(args.low_energy_fraction),
            low_energy_boost=float(args.low_energy_boost),
            use_quadratic_precompute=not bool(args.no_precompute),
            precompute_cache_path=str(args.precompute_cache) if args.precompute_cache else None,
            progress_callback=_progress,
            checkpoint_callback=_checkpoint,
            checkpoint_interval=20,
        )
    except KeyboardInterrupt:
        if latest_snapshot is not None:
            _progress("Interrupted. Writing latest checkpoint outputs...")
            _write_outputs_from_payload(latest_snapshot, update_poscar_titles=True)
            _progress(
                f"Checkpoint saved: model={out_model}, report={out_report}, parity_plot={out_plot}"
            )
        raise
    opt = result.get("optimizer", {})
    _progress(
        "Optimization finished: "
        f"success={opt.get('success', result.get('status') == 'ok')}, "
        f"nit={opt.get('nit', 'n/a')}, nfev={opt.get('nfev', 'n/a')}, "
        f"calls={opt.get('objective_calls', 'n/a')}, "
        f"best_call={opt.get('best_call', 'n/a')}, "
        f"message={opt.get('message', result.get('message', ''))}"
    )
    _progress("Writing outputs...")

    _write_outputs_from_payload(result, update_poscar_titles=True)
    site_summary = result.get("site_charge_summary")
    if isinstance(site_summary, dict) and site_summary:
        for site in sorted(site_summary.keys()):
            row = site_summary.get(site, {})
            if not isinstance(row, dict):
                continue
            txt = ", ".join(f"{k}={float(v):.3f}" for k, v in sorted(row.items()))
            _progress(f"Site charge summary {site}: {txt}")

    summary = {
        "status": result["status"],
        "message": result["message"],
        "dataset": str(dataset_path),
        "dataset_generated": bool(generated_dataset_path is not None),
        "n_samples": result["n_samples"],
        "anchor_kind": result["anchor_kind"],
        "charges": result["charges"],
        "linear_map": result["linear_map"],
        "metrics": result["metrics"],
        "baseline_metrics": result.get("baseline", {}).get("metrics", {}),
        "outputs": {
            "model": str(out_model),
            "report": str(out_report),
            "parity_plot": str(out_plot),
        },
    }
    if generated_dataset_path is not None:
        summary["outputs"]["dataset"] = str(generated_dataset_path)
    if not bool(getattr(args, "no_update_poscar_titles", False)):
        summary["outputs"]["poscar_titles_updated"] = True
    if dataset_meta is not None:
        summary["matching"] = {
            "matched_count": len(dataset_meta["matched_ids"]),
            "missing_poscar_ids": dataset_meta["missing_poscar_ids"],
            "missing_outcar_ids": dataset_meta["missing_outcar_ids"],
        }
    print_result(args, summary)
    return 0


def _handle_validate_model(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .fit_charge import (
        build_dataset_from_patterns,
        evaluate_fixed_charge_model,
        load_charge_model,
        parse_dataset_file,
        write_fixed_model_parity_plot,
        write_dataset_file,
    )

    has_dataset = bool(args.dataset)
    has_poscar = bool(args.poscar)
    has_outcar = bool(args.outcar)

    def _progress(message: str) -> None:
        if getattr(args, "quiet", False):
            return
        print(f"[validate-model] {message}", file=sys.stderr, flush=True)

    if has_dataset and (has_poscar or has_outcar):
        print("Argument issue: use either dataset file OR (-p/--poscar + --outcar), not both.", file=sys.stderr)
        return 2
    if not has_dataset and (has_poscar != has_outcar):
        print("Argument issue: provide both -p/--poscar and --outcar together.", file=sys.stderr)
        return 2
    if not has_dataset and not has_poscar and not has_outcar:
        _parser.print_help()
        return 0

    generated_dataset_path: Path | None = None
    if has_dataset:
        dataset_path = Path(args.dataset).resolve()
        entries = parse_dataset_file(dataset_path)
    else:
        entries, _ = build_dataset_from_patterns(
            list(args.poscar),
            list(args.outcar),
            strict=not bool(args.allow_partial),
        )
        generated_dataset_path = write_dataset_file(entries, args.dataset_out)
        dataset_path = generated_dataset_path
    _progress(f"Dataset ready: {len(entries)} samples")

    charges = load_charge_model(args.charge_model)
    report = evaluate_fixed_charge_model(
        entries,
        charges=charges,
        rg_find_factor=int(args.rg_find_factor),
        chop_level=float(args.chop_level),
        map_mode=str(args.map_mode),
    )
    nested_charges = _to_nested_charge_schema(
        charges,
        basis=("element_site" if any("@" in str(k) for k in charges.keys()) else "element"),
    )
    report["charges"] = nested_charges

    out_report = Path(args.out_report).resolve()
    out_plot = Path(args.out_plot).resolve()
    out_report.parent.mkdir(parents=True, exist_ok=True)
    out_plot.parent.mkdir(parents=True, exist_ok=True)
    out_report.write_text(json.dumps(report, indent=2))
    write_fixed_model_parity_plot(report, out_plot)

    summary = {
        "status": report["status"],
        "message": report["message"],
        "dataset": str(dataset_path),
        "dataset_generated": generated_dataset_path is not None,
        "n_samples": report["n_samples"],
        "charges": nested_charges,
        "metrics": report["metrics"],
        "outputs": {
            "report": str(out_report),
            "parity_plot": str(out_plot),
            "dataset": str(dataset_path),
        },
    }
    print_result(args, summary)
    return 0


def _handle_allocation_optimize(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .allocation_optimize import optimize_site_allocation

    preferences: dict[str, float] = {}
    for raw in list(args.prefer or []):
        token = str(raw).strip()
        if "=" not in token:
            raise ValueError(
                f"Invalid --prefer '{token}'. Expected format: Element@site_group=weight"
            )
        key, value = token.split("=", 1)
        preferences[key.strip()] = float(value.strip())

    result = optimize_site_allocation(
        input_yaml=args.input,
        out_yaml=args.out_yaml,
        out_table=args.out_table,
        preferences=preferences,
        n_alloc=int(args.n_alloc),
        seed=args.seed,
        dry_run=bool(args.dry_run),
        score_mode=str(args.score_mode),
        ewald_samples=int(args.ewald_samples),
        guide_gate=not bool(args.no_guide_gate),
        metric=str(args.metric),
        topk=int(args.topk),
    )
    out_report = Path(args.out_report).resolve()
    out_report.parent.mkdir(parents=True, exist_ok=True)
    out_report.write_text(json.dumps(result, indent=2))
    summary = {
        "status": "ok",
        "message": "Sitewise composition generated",
        "input": result["input"],
        "output_yaml": result["output_yaml"],
        "output_table": str(Path(args.out_table).resolve()),
        "output_report": str(out_report),
        "n_alloc_requested": result.get("n_alloc_requested"),
        "n_alloc_feasible": result.get("n_alloc_feasible"),
        "best_score": result.get("best", {}).get("score"),
        "score_mode": result.get("score_mode"),
        "metric": result.get("metric"),
        "composition_by_site": result["composition_by_site"],
    }
    print_result(args, summary)
    return 0


def _handle_wizard(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .wizard import WizardSession

    output_path = Path(getattr(args, "output", "input.yaml"))
    artifact_dir = output_path.parent if output_path.parent != Path("") else Path(".")
    log_path = artifact_dir / "wizard.last.log"
    replay_script_path = artifact_dir / "wizard.replay.sh"

    class _Tee:
        def __init__(self, *streams):
            self.streams = streams

        def write(self, data):
            for stream in self.streams:
                stream.write(data)
            return len(data)

        def flush(self):
            for stream in self.streams:
                stream.flush()

    replay_cmd: str | None = None
    with log_path.open("w", encoding="utf-8") as wizard_log:
        tee_stdout = _Tee(sys.stdout, wizard_log)
        tee_stderr = _Tee(sys.stderr, wizard_log)
        with contextlib.redirect_stdout(tee_stdout), contextlib.redirect_stderr(
            tee_stderr
        ):
            print("\n" + "="*70)
            print("esspy Interactive Wizard")
            print("="*70)

            # Create wizard with default mode (will be set dynamically during workflow)
            wizard = WizardSession()
            if not wizard.run_workflow():
                print("Wizard cancelled or failed", file=sys.stderr)
                return 1

            # Save to YAML
            if not wizard.save_to_yaml(str(output_path)):
                return 1

            reference_poscar = getattr(wizard.state, "reference_structure", None)
            if reference_poscar:
                replay_name = getattr(wizard.state, "name", None) or str(
                    output_path.stem
                )
                replay_symmetry = getattr(wizard.state, "symmetry_mode", None) or "auto"
                replay_workdir = None
                replay_symprec = 1.0e-5
                replay_write_wyc_path = "symmetry.wyc"
                generated_config: dict[str, Any] = {}
                try:
                    loaded_generated = _load_yaml_config(str(output_path)) or {}
                    if isinstance(loaded_generated, dict):
                        generated_config = loaded_generated
                        output_block = generated_config.get("output", {})
                        if isinstance(output_block, dict):
                            value = output_block.get("workdir")
                            if isinstance(value, str) and value.strip():
                                replay_workdir = value.strip()
                        symmetry_block = generated_config.get("symmetry", {})
                        if isinstance(symmetry_block, dict):
                            mode_value = symmetry_block.get("mode")
                            if isinstance(mode_value, str) and mode_value.strip():
                                replay_symmetry = mode_value.strip()
                            symprec_value = symmetry_block.get("symprec")
                            if symprec_value is not None:
                                replay_symprec = float(symprec_value)
                            wyc_value = symmetry_block.get("write_wyc_path")
                            if isinstance(wyc_value, str) and wyc_value.strip():
                                replay_write_wyc_path = wyc_value.strip()
                except Exception:
                    replay_workdir = None

                replay_parts = [
                    "esspy",
                    "init",
                    "-p",
                    shlex.quote(str(reference_poscar)),
                    "--out",
                    shlex.quote(str(output_path)),
                    "--name",
                    shlex.quote(replay_name),
                ]

                structure_block = generated_config.get("structure", {})
                if isinstance(structure_block, dict):
                    dim = structure_block.get("dim")
                    if dim is None:
                        dim = structure_block.get("supercell")
                    if isinstance(dim, list) and len(dim) == 3:
                        if all(isinstance(row, list) for row in dim):
                            flat_dim = [
                                str(int(value))
                                for row in dim
                                for value in row
                            ]
                        else:
                            flat_dim = [str(int(value)) for value in dim]
                        replay_parts.extend(["--dim", *flat_dim])
                    else:
                        n_target_sites = structure_block.get("n_target_sites")
                        if n_target_sites is not None:
                            replay_parts.extend(["--n-target-sites", str(int(n_target_sites))])

                composition_block = generated_config.get("composition")
                if isinstance(composition_block, dict) and composition_block:
                    fractions = composition_block.get("fractions")
                    if isinstance(fractions, dict):
                        fractions_arg = ",".join(
                            f"{key}={value}" for key, value in fractions.items()
                        )
                        replay_parts.extend(["--fractions", shlex.quote(fractions_arg)])
                    else:
                        composition_arg = ",".join(
                            f"{key}={value}"
                            for key, value in composition_block.items()
                            if not isinstance(value, (dict, list))
                        )
                        if composition_arg:
                            replay_parts.extend(["--composition", shlex.quote(composition_arg)])

                charges_block = generated_config.get("charges")
                charge_basis = "element"
                charge_values = None
                site_charges: dict[str, float] = {}
                if isinstance(charges_block, dict):
                    basis_value = charges_block.get("basis")
                    if isinstance(basis_value, str) and basis_value.strip():
                        charge_basis = basis_value.strip()
                    values = charges_block.get("values")
                    if isinstance(values, dict):
                        charge_values = values
                        elements = charges_block.get("elements")
                        if isinstance(elements, dict):
                            for elem, info in elements.items():
                                if not isinstance(info, dict):
                                    continue
                                by_site = info.get("by_site")
                                if not isinstance(by_site, dict):
                                    continue
                                for site_group, value in by_site.items():
                                    site_charges[f"{elem}@{site_group}"] = float(value)
                    else:
                        charge_values = {
                            key: value
                            for key, value in charges_block.items()
                            if not isinstance(value, (dict, list))
                        }
                if isinstance(charge_values, dict) and charge_values:
                    charges_arg = ",".join(
                        f"{key}={value}" for key, value in charge_values.items()
                    )
                    replay_parts.extend(["--charges", shlex.quote(charges_arg)])
                if charge_basis == "element_site":
                    replay_parts.extend(["--charge-basis", "element_site"])
                    if site_charges:
                        site_charge_arg = ",".join(
                            f"{key}={value}" for key, value in site_charges.items()
                        )
                        replay_parts.extend(["--site-charge", shlex.quote(site_charge_arg)])

                recipes_block = generated_config.get("recipes")
                if isinstance(recipes_block, list):
                    for recipe in recipes_block:
                        if not isinstance(recipe, dict):
                            continue
                        from_kind = recipe.get("from_kind", recipe.get("from"))
                        to_raw = recipe.get("to", [])
                        if from_kind is None or not isinstance(to_raw, list):
                            continue
                        to_arg = ",".join(str(item) for item in to_raw)
                        if to_arg:
                            replay_parts.extend(
                                ["--recipe", shlex.quote(f"{from_kind}:{to_arg}")]
                            )

                site_grouping_block = generated_config.get("site_grouping")
                site_grouping_mode = None
                if isinstance(site_grouping_block, dict):
                    raw_mode = site_grouping_block.get("mode")
                    if isinstance(raw_mode, str) and raw_mode.strip():
                        site_grouping_mode = raw_mode.strip()
                        replay_parts.extend(["--site-grouping", shlex.quote(site_grouping_mode)])
                        symprec = site_grouping_block.get("symprec")
                        if symprec is not None:
                            replay_parts.extend(["--site-group-symprec", str(float(symprec))])
                        angle_tolerance = site_grouping_block.get("angle_tolerance")
                        if angle_tolerance is not None:
                            replay_parts.extend(
                                ["--site-group-angle-tolerance", str(float(angle_tolerance))]
                            )
                        fallback = site_grouping_block.get("fallback")
                        if isinstance(fallback, str) and fallback.strip():
                            replay_parts.extend(["--site-group-fallback", shlex.quote(fallback.strip())])

                site_groups_block = generated_config.get("site_groups")
                if isinstance(site_groups_block, dict) and not site_grouping_mode:
                    for group_name, info in site_groups_block.items():
                        if not isinstance(info, dict):
                            continue
                        source = info.get("source_kind")
                        allowed = info.get("allowed", [])
                        if source is None or not isinstance(allowed, list):
                            continue
                        allowed_arg = ",".join(str(item) for item in allowed)
                        if allowed_arg:
                            replay_parts.extend(
                                [
                                    "--site-group",
                                    shlex.quote(f"{group_name}:{source}:{allowed_arg}"),
                                ]
                            )

                allocation_block = generated_config.get("allocation")
                if isinstance(allocation_block, dict):
                    allocation_time_budget = allocation_block.get("time_budget_sec")
                    if allocation_time_budget is not None:
                        replay_parts.extend(
                            ["--allocation-time-budget-sec", str(int(allocation_time_budget))]
                        )

                replay_parts.extend([
                    "--symmetry",
                    shlex.quote(replay_symmetry),
                    "--solve-mode",
                    shlex.quote(str(getattr(wizard.state, "solve_mode", "adaptive"))),
                    "--solve-effort",
                    shlex.quote(str(getattr(wizard.state, "solve_effort", "medium"))),
                    "--time-budget-sec",
                    str(int(getattr(wizard.state, "solve_time_budget_sec", 600))),
                    "--max-swap",
                    str(int(getattr(wizard.state, "solve_swap_max_steps", 100))),
                    "--selection-enabled",
                    "true" if bool(getattr(wizard.state, "selection_enabled", True)) else "false",
                    "--selection-mode",
                    shlex.quote(str(getattr(wizard.state, "selection_mode", "auto_top_n"))),
                    "--selection-limit",
                    str(int(getattr(wizard.state, "selection_limit", 20))),
                    "--selection-pick",
                    shlex.quote(str(getattr(wizard.state, "selection_pick", "lowest"))),
                    "--selection-interval",
                    shlex.quote(str(getattr(wizard.state, "selection_interval", "left-closed"))),
                    "--selection-outdir",
                    shlex.quote(str(getattr(wizard.state, "selection_outdir", "selected_structures"))),
                    "--selection-prefix",
                    shlex.quote(str(getattr(wizard.state, "selection_prefix", "selected"))),
                ])
                replay_selection_seed = getattr(wizard.state, "selection_seed", None)
                if replay_selection_seed is not None:
                    replay_parts.extend(
                        [
                            "--selection-seed",
                            str(int(replay_selection_seed)),
                        ]
                    )
                if replay_symmetry == "auto":
                    replay_parts.extend(
                        [
                            "--symprec",
                            str(replay_symprec),
                            "--write-wyc-path",
                            shlex.quote(replay_write_wyc_path),
                        ]
                    )
                replay_cmd = " ".join(replay_parts)
                if replay_workdir:
                    replay_cmd += " --output-workdir " + shlex.quote(replay_workdir)
                print("\nReplay command (same solve strategy defaults):")
                print(f"  {replay_cmd}")

            # Optionally run immediately
            if getattr(args, "then_run", False):
                print(f"\nRunning esspy run {output_path}...")
                return _handle_run(
                    argparse.Namespace(
                        input=str(output_path),
                        workdir=getattr(args, "workdir", None),
                        guide_only=False,
                        quiet=False,
                        json=False,
                        no_progress=False,
                        progress_interval=1.0,
                        log_file=None,
                    ),
                    _parser,
                )

    if replay_cmd:
        replay_script_path.write_text(
            "#!/usr/bin/env bash\n"
            "set -euo pipefail\n\n"
            "# wizard.replay.sh\n"
            "# Rebuild input.yaml via the init -p command captured from wizard.\n\n"
            f"{replay_cmd}\n",
            encoding="utf-8",
        )
        replay_script_path.chmod(0o755)

    return 0


def _handle_add_sites_run(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .add_sites_mc import AddSitesMonteCarloOptions
    from .add_sites_pipeline import (
        run_add_sites_from_solver_text,
        run_add_sites_from_solver_text_mpi,
    )

    charges = _parse_charges_json(args.charges_json)
    options = AddSitesMonteCarloOptions(
        random_seed=args.seed,
        rg_find_factor=args.rg_find_factor,
        chop_level=args.chop_level,
    )
    if args.use_mpi:
        result = run_add_sites_from_solver_text_mpi(
            args.solver_text,
            args.poscar,
            options=options,
            wyc_path=args.wyc,
            space_group=args.space_group,
            charges_by_kind=charges,
            use_mpi=True,
        )
        print(
            json.dumps(
                {
                    "success": result.success,
                    "best_energy": result.best_energy,
                    "owner_rank": result.owner_rank,
                    "world_size": result.world_size,
                    "accepted_trials_total": result.accepted_trials_total,
                    "attempted_trials_total": result.attempted_trials_total,
                }
            )
        )
        return 0

    result = run_add_sites_from_solver_text(
        args.solver_text,
        args.poscar,
        options=options,
        wyc_path=args.wyc,
        space_group=args.space_group,
        charges_by_kind=charges,
    )
    print(
        json.dumps(
            {
                "success": result.success,
                "best_energy": result.best_energy,
                "accepted_trials": result.accepted_trials,
                "attempted_trials": result.attempted_trials,
                "n_sites": len(result.best_structure.sites),
            }
        )
    )
    return 0


def _handle_init_from_guider(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from pathlib import Path

    from .init_from_guider import (
        InitFromGuiderOptions,
        write_init_from_guider_yaml,
    )

    options = InitFromGuiderOptions(
        guider_path=Path(args.guider),
        out=Path(args.out),
        name=args.name,
        composition_mode=args.composition_mode,
        output_workdir=args.output_workdir,
        poscar_override=Path(args.poscar) if args.poscar else None,
        solve_mode=args.solve_mode,
        solve_effort=args.solve_effort,
        solve_time_budget_sec=args.time_budget_sec,
        solve_max_swap=args.max_swap,
        selection_enabled=(str(args.selection_enabled).lower() == "true"),
        selection_mode=args.selection_mode,
        selection_limit=args.selection_limit,
        selection_pick=args.selection_pick,
        selection_interval=args.selection_interval,
        selection_seed=args.selection_seed,
        selection_outdir=args.selection_outdir,
        selection_prefix=args.selection_prefix,
    )
    out = write_init_from_guider_yaml(options)
    _emit_init_result(args, str(out), options.name or out.stem)
    return 0


def _init_options_use_site_aware_schema(options: Any) -> bool:
    return (
        str(getattr(options, "charge_basis", "element")) == "element_site"
        or bool(getattr(options, "site_groups", None))
        or getattr(options, "allocation_time_budget_sec", None) is not None
    )


def _handle_init_from_poscar(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from dataclasses import replace
    from pathlib import Path

    from .init_scaffold import (
        InitFromPoscarOptions,
        ParsedRecipe,
        parse_counts_map,
        dim_input_is_matrix,
        parse_key_value_map,
        parse_recipe,
        parse_dim,
        parse_site_group,
        write_sposcar_from_init_options,
        write_init_from_poscar_yaml,
    )
    if args.n_target_sites is not None and args.dim is not None:
        _parser.error("Choose either --n-target-sites or --dim, not both")
    if getattr(args, "site_grouping", None) and getattr(args, "site_group", None):
        _parser.error("Choose either --site-grouping or explicit --site-group entries, not both")
    try:
        explicit_dim = parse_dim(args.dim) if args.dim else None
    except ValueError as exc:
        _parser.error(str(exc))

    composition_mode = "fractions" if args.fractions else "counts"
    composition = (
        parse_key_value_map(args.fractions, value_type=float)
        if args.fractions
        else parse_counts_map(args.composition)
    )
    options = InitFromPoscarOptions(
        poscar=Path(args.poscar),
        out=Path(args.out),
        name=args.name,
        n_target_sites=args.n_target_sites,
        supercell=explicit_dim,
        dim_as_matrix=dim_input_is_matrix(args.dim),
        number_fixed_at=args.fixed,
        composition=composition,
        composition_mode=composition_mode,
        charges=parse_key_value_map(args.charges, value_type=float),
        recipes=[parse_recipe(raw) for raw in args.recipe],
        charge_basis=str(getattr(args, "charge_basis", "element")),
        site_groups=[
            parse_site_group(raw)
            for raw in (getattr(args, "site_group", None) or [])
        ],
        site_grouping=getattr(args, "site_grouping", None),
        site_grouping_symprec=float(getattr(args, "site_group_symprec", 0.1)),
        site_grouping_angle_tolerance=float(
            getattr(args, "site_group_angle_tolerance", 5.0)
        ),
        site_grouping_fallback=str(getattr(args, "site_group_fallback", "poscar_kind")),
        site_grouping_strict=bool(getattr(args, "site_group_strict", False)),
        site_charges=parse_key_value_map(args.site_charge, value_type=float)
        if getattr(args, "site_charge", None)
        else {},
        allocation_time_budget_sec=getattr(args, "allocation_time_budget_sec", None),
        symmetry=args.symmetry,
        symprec=args.symprec,
        write_wyc_path=args.write_wyc_path,
        target_cpu_time_sec=args.target_cpu_time_sec,
        n_random_seeds=args.n_random_seeds,
        max_swap=args.max_swap,
        solve_mode=args.solve_mode,
        solve_effort=args.solve_effort,
        solve_time_budget_sec=args.time_budget_sec,
        fixed_rg_find_factor=args.fixed_rg_find_factor,
        skip_ewald_evaluation=args.skip_ewald_evaluation,
        output_workdir=args.output_workdir,
        include_editing_examples=False,
        selection_enabled=(str(args.selection_enabled).lower() == "true"),
        selection_mode=args.selection_mode,
        selection_limit=args.selection_limit,
        selection_pick=args.selection_pick,
        selection_interval=args.selection_interval,
        selection_seed=args.selection_seed,
        selection_outdir=args.selection_outdir,
        selection_prefix=args.selection_prefix,
    )
    out = write_init_from_poscar_yaml(options)
    args._sposcar = str(write_sposcar_from_init_options(options))
    example_out: str | None = None
    if args.recipe and not _init_options_use_site_aware_schema(options):
        sidecar = out.with_name(f"{out.stem}-example{out.suffix}")
        sidecar_options = replace(options, out=sidecar, include_editing_examples=True)
        write_init_from_poscar_yaml(sidecar_options)
        example_out = str(sidecar)
    _emit_init_result_with_example(args, str(out), options.name or out.stem, example_out)
    return 0


def _handle_init_unified(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    """Unified `esspy init` entrypoint.

    Mode selection:
      - `--from-guider <path>`: migrate legacy guider text
      - `-p/--poscar <path>`: scaffold from POSCAR
    """
    from dataclasses import replace
    from pathlib import Path

    from .init_from_guider import (
        InitFromGuiderOptions,
        write_init_from_guider_yaml,
    )
    from .init_scaffold import (
        InitFromPoscarOptions,
        ParsedRecipe,
        parse_counts_map,
        dim_input_is_matrix,
        parse_key_value_map,
        parse_recipe,
        parse_site_group,
        parse_dim,
        write_sposcar_from_init_options,
        write_init_from_poscar_yaml,
    )
    import yaml

    def _parse_dim_cli(raw):
        if raw is None:
            return None
        try:
            return parse_dim(raw)
        except ValueError as exc:
            parser.error(str(exc))

    def _looks_like_wizard_yaml(data: dict) -> bool:
        if not isinstance(data, dict):
            return False
        # Heuristic: wizard-rich inputs usually include site/allocation context.
        return any(
            key in data
            for key in ("site_groups", "allocation", "composition_by_site")
        )

    def _load_wizard_snapshot_from_replay(poscar_path: Path) -> dict | None:
        """Load YAML snapshot embedded in wizard.replay.sh when present."""
        candidates = [
            Path.cwd() / "wizard.replay.sh",
            poscar_path.parent / "wizard.replay.sh",
        ]
        replay_path = next((p for p in candidates if p.exists()), None)
        if replay_path is None:
            return None
        text = replay_path.read_text(encoding="utf-8")
        m = re.search(
            r"__ESSPY_WIZARD_YAML__'\n(?P<yaml>.*)\n__ESSPY_WIZARD_YAML__",
            text,
            flags=re.DOTALL,
        )
        if not m:
            return None
        data = yaml.safe_load(m.group("yaml"))
        if not isinstance(data, dict):
            return None
        return data

    def _load_wizard_snapshot_from_artifacts(poscar_path: Path, out_path: Path) -> dict | None:
        """Best-effort snapshot recovery without heredoc in replay script.

        Priority:
          1) Existing --out YAML if it looks wizard-rich.
          2) allocation_table.json -> output_yaml path.
        """
        # 1) Existing output file (common in re-run in same directory).
        try:
            if out_path.exists():
                existing = yaml.safe_load(out_path.read_text(encoding="utf-8"))
                if isinstance(existing, dict) and _looks_like_wizard_yaml(existing):
                    return existing
        except Exception:
            pass

        # 2) allocation_table.json side artifact from wizard auto-allocation.
        table_candidates = [
            out_path.parent / "allocation_table.json",
            Path.cwd() / "allocation_table.json",
            poscar_path.parent / "allocation_table.json",
        ]
        for table_path in table_candidates:
            try:
                if not table_path.exists():
                    continue
                table = json.loads(table_path.read_text(encoding="utf-8"))
                if not isinstance(table, dict):
                    continue
                output_yaml = table.get("output_yaml")
                if not output_yaml:
                    continue
                ypath = Path(str(output_yaml)).expanduser()
                if not ypath.exists():
                    continue
                recovered = yaml.safe_load(ypath.read_text(encoding="utf-8"))
                if isinstance(recovered, dict) and _looks_like_wizard_yaml(recovered):
                    return recovered
            except Exception:
                continue
        return None

    def _apply_init_cli_overrides_to_snapshot(snapshot: dict) -> dict:
        """Apply init CLI knobs onto wizard snapshot for deterministic replay."""
        data = dict(snapshot)
        structure = data.setdefault("structure", {})
        if not isinstance(structure, dict):
            structure = {}
            data["structure"] = structure
        structure["poscar"] = str(Path(args.poscar).resolve())
        if args.dim is not None:
            structure.pop("n_target_sites", None)
            dim = _parse_dim_cli(args.dim)
            if dim_input_is_matrix(args.dim):
                structure["dim"] = [[dim[0], 0, 0], [0, dim[1], 0], [0, 0, dim[2]]]
            else:
                structure["dim"] = [int(value) for value in dim]
        if args.n_target_sites is not None:
            structure.pop("dim", None)
            structure["n_target_sites"] = int(args.n_target_sites)

        solve = data.setdefault("solve", {})
        if not isinstance(solve, dict):
            solve = {}
            data["solve"] = solve
        strategy = solve.setdefault("strategy", {})
        if not isinstance(strategy, dict):
            strategy = {}
            solve["strategy"] = strategy
        strategy["mode"] = str(args.solve_mode)
        strategy["effort"] = str(args.solve_effort)
        strategy["time_budget_sec"] = int(args.time_budget_sec)
        strategy.setdefault("swap", {})
        if not isinstance(strategy["swap"], dict):
            strategy["swap"] = {}
        strategy["swap"]["enabled"] = True
        strategy["swap"]["max_steps"] = int(args.max_swap)

        output = data.setdefault("output", {})
        if not isinstance(output, dict):
            output = {}
            data["output"] = output
        if args.output_workdir:
            output["workdir"] = str(args.output_workdir)
        sel = output.setdefault("selection", {})
        if not isinstance(sel, dict):
            sel = {}
            output["selection"] = sel
        sel["enabled"] = str(args.selection_enabled).lower() == "true"
        sel["mode"] = str(args.selection_mode)
        sel["limit"] = int(args.selection_limit)
        sel["pick"] = str(args.selection_pick)
        sel["interval"] = str(args.selection_interval)
        sel["outdir"] = str(args.selection_outdir)
        sel["prefix"] = str(args.selection_prefix)
        sel["seed"] = None if args.selection_seed is None else int(args.selection_seed)
        return data

    mode_count = sum(1 for v in (bool(args.from_existing), bool(args.from_guider)) if v)
    if not args.from_existing and not args.from_guider and args.poscar:
        mode_count += 1
    if mode_count > 1:
        parser.error(
            "init mode conflict: choose only one of --from-existing, --from-guider, or -p/--poscar"
        )

    if args.from_existing:
        src = Path(args.from_existing).expanduser()
        if not src.exists():
            parser.error(f"--from-existing not found: {src}")
        data = yaml.safe_load(src.read_text())
        if not isinstance(data, dict):
            parser.error("--from-existing YAML root must be a mapping")

        # Optional POSCAR override while preserving full wizard schema.
        if args.poscar:
            data.setdefault("structure", {})
            if not isinstance(data["structure"], dict):
                data["structure"] = {}
            data["structure"]["poscar"] = str(Path(args.poscar).resolve())

        out_path = Path(args.out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=False))
        _emit_init_result(args, str(out_path), args.name or out_path.stem)
        return 0

    if args.from_guider:
        options = InitFromGuiderOptions(
            guider_path=Path(args.from_guider),
            out=Path(args.out),
            name=args.name,
            composition_mode=args.composition_mode,
            output_workdir=args.output_workdir,
            poscar_override=Path(args.poscar) if args.poscar else None,
            solve_mode=args.solve_mode,
            solve_effort=args.solve_effort,
            solve_time_budget_sec=args.time_budget_sec,
            solve_max_swap=args.max_swap,
            selection_enabled=(str(args.selection_enabled).lower() == "true"),
            selection_mode=args.selection_mode,
            selection_limit=args.selection_limit,
            selection_pick=args.selection_pick,
            selection_interval=args.selection_interval,
            selection_seed=args.selection_seed,
            selection_outdir=args.selection_outdir,
            selection_prefix=args.selection_prefix,
        )
        out = write_init_from_guider_yaml(options)
        _emit_init_result(args, str(out), options.name or out.stem)
        return 0

    if args.poscar:
        # Reproduction shortcut: if wizard replay snapshot exists and the user
        # did not provide manual scaffold overrides, restore snapshot as-is.
        scaffold_override_requested = any(
            [
                bool(args.recipe),
                bool(args.composition),
                bool(args.fractions),
                bool(args.charges),
                str(getattr(args, "charge_basis", "element")) != "element",
                bool(getattr(args, "site_group", None)),
                bool(getattr(args, "site_grouping", None)),
                bool(getattr(args, "site_charge", None)),
                getattr(args, "allocation_time_budget_sec", None) is not None,
                args.n_target_sites is not None,
                args.dim is not None,
                args.fixed is not None,
            ]
        )
        if not scaffold_override_requested:
            poscar_path = Path(args.poscar)
            out_path = Path(args.out)
            snapshot = _load_wizard_snapshot_from_replay(poscar_path)
            if snapshot is None:
                snapshot = _load_wizard_snapshot_from_artifacts(poscar_path, out_path)
            if snapshot is not None:
                snapshot = _apply_init_cli_overrides_to_snapshot(snapshot)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(yaml.safe_dump(snapshot, sort_keys=False, allow_unicode=False))
                _emit_init_result(args, str(out_path), args.name or out_path.stem)
                return 0

        structure = load_poscar(Path(args.poscar))
        if args.n_target_sites is not None and args.dim is not None:
            parser.error("Choose either --n-target-sites or --dim, not both")
        if getattr(args, "site_grouping", None) and getattr(args, "site_group", None):
            parser.error("Choose either --site-grouping or explicit --site-group entries, not both")
        species_counts: dict[str, int] = {}
        species_order: list[str] = []
        for site in structure.sites:
            if site.kind not in species_counts:
                species_order.append(site.kind)
                species_counts[site.kind] = 0
            species_counts[site.kind] += 1

        if args.recipe:
            recipes = [parse_recipe(raw) for raw in args.recipe]
            include_examples = False
            needs_placeholder_x_charge = False
        else:
            fixed_kind = args.fixed
            if fixed_kind is None:
                fixed_kind = "O" if "O" in species_counts else species_order[-1]
            candidate_from = [kind for kind in species_counts.keys() if kind != fixed_kind]
            if not candidate_from:
                candidate_from = list(species_counts.keys())
            if len(candidate_from) == 1 and candidate_from[0] == "M":
                recipes = [ParsedRecipe(from_kind="M", to=["M", "X"])]
                needs_placeholder_x_charge = True
            else:
                recipes = [ParsedRecipe(from_kind=kind, to=[kind]) for kind in candidate_from]
                needs_placeholder_x_charge = False
            include_examples = True

        if args.composition and args.fractions:
            parser.error("--composition and --fractions are mutually exclusive")

        if args.fractions:
            composition_mode = "fractions"
            composition = parse_key_value_map(args.fractions, value_type=float)
        elif args.composition:
            composition_mode = "counts"
            composition = parse_counts_map(args.composition)
        else:
            total_sites = float(sum(species_counts.values()))
            if args.recipe:
                expanded_counts = _expand_counts_by_recipes(
                    {k: float(v) for k, v in species_counts.items()},
                    recipes,
                )
                composition_mode = "fractions"
                composition = {
                    kind: float(value) / total_sites
                    for kind, value in expanded_counts.items()
                }
            else:
                composition_mode = "fractions"
                composition = {
                    kind: float(value) / total_sites
                    for kind, value in species_counts.items()
                }

        if args.charges:
            charges = parse_key_value_map(args.charges, value_type=float)
        else:
            composition_kinds = list(composition.keys())
            charges = build_default_charges(composition_kinds)
        if needs_placeholder_x_charge and "X" not in charges:
            charges["X"] = 2.0

        number_fixed_at = args.fixed
        if number_fixed_at is None:
            number_fixed_at = "O" if "O" in composition else species_order[-1]

        n_target_sites = (
            int(args.n_target_sites)
            if args.n_target_sites is not None
            else None
            if args.dim is not None
            else int(sum(species_counts.values()))
        )
        options = InitFromPoscarOptions(
            poscar=Path(args.poscar),
            out=Path(args.out),
            name=args.name,
            n_target_sites=n_target_sites,
            supercell=_parse_dim_cli(args.dim),
            dim_as_matrix=dim_input_is_matrix(args.dim),
            number_fixed_at=number_fixed_at,
            composition=composition,
            composition_mode=composition_mode,
            charges=charges,
            recipes=recipes,
            charge_basis=str(getattr(args, "charge_basis", "element")),
            site_groups=[
                parse_site_group(raw)
                for raw in (getattr(args, "site_group", None) or [])
            ],
            site_grouping=getattr(args, "site_grouping", None),
            site_grouping_symprec=float(getattr(args, "site_group_symprec", 0.1)),
            site_grouping_angle_tolerance=float(
                getattr(args, "site_group_angle_tolerance", 5.0)
            ),
            site_grouping_fallback=str(getattr(args, "site_group_fallback", "poscar_kind")),
            site_grouping_strict=bool(getattr(args, "site_group_strict", False)),
            site_charges=parse_key_value_map(args.site_charge, value_type=float)
            if getattr(args, "site_charge", None)
            else {},
            allocation_time_budget_sec=getattr(args, "allocation_time_budget_sec", None),
            symmetry=args.symmetry,
            symprec=args.symprec,
            write_wyc_path=args.write_wyc_path,
            target_cpu_time_sec=args.target_cpu_time_sec,
            n_random_seeds=args.n_random_seeds,
            max_swap=args.max_swap,
            solve_mode=args.solve_mode,
            solve_effort=args.solve_effort,
            solve_time_budget_sec=args.time_budget_sec,
            fixed_rg_find_factor=args.fixed_rg_find_factor,
            skip_ewald_evaluation=args.skip_ewald_evaluation,
            output_workdir=args.output_workdir,
            include_editing_examples=include_examples,
            selection_enabled=(str(args.selection_enabled).lower() == "true"),
            selection_mode=args.selection_mode,
            selection_limit=args.selection_limit,
            selection_pick=args.selection_pick,
            selection_interval=args.selection_interval,
            selection_seed=args.selection_seed,
            selection_outdir=args.selection_outdir,
            selection_prefix=args.selection_prefix,
        )
        out = write_init_from_poscar_yaml(options)
        args._sposcar = str(write_sposcar_from_init_options(options))
        example_out: str | None = None
        if args.recipe and not _init_options_use_site_aware_schema(options):
            sidecar = out.with_name(f"{out.stem}-example{out.suffix}")
            sidecar_options = replace(options, out=sidecar, include_editing_examples=True)
            write_init_from_poscar_yaml(sidecar_options)
            example_out = str(sidecar)
        _emit_init_result_with_example(args, str(out), options.name or out.stem, example_out)
        return 0

    command_parser = getattr(args, "_command_parser", None)
    if command_parser is not None:
        command_parser.print_help()
        return 0
    parser.error(
        "init mode not selected: use one of `--from-existing <input.yaml>`, "
        "`--from-guider <path>`, or `-p/--poscar <path>`"
    )
    return 2


def _handle_add_sites_inspect(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .add_sites_text import parse_add_sites_monte_carlo_spec

    spec = parse_add_sites_monte_carlo_spec(args.solver_text)
    payload = {
        "present": spec.present,
        "n_monte_carlo": spec.n_monte_carlo,
        "monitor_index": spec.monte_carlo_monitor_index,
        "meshes": list(spec.add_meshes),
        "min_distance_between_added_sites": spec.min_distance_between_added_sites,
        "added_kinds": [
            {
                "kind": item.kind,
                "n_added": item.n_added,
                "oxidation": item.oxidation,
                "neighbor_kinds": [
                    {
                        "kind": neighbor.kind,
                        "doxidation": neighbor.doxidation,
                        "dist_min": neighbor.dist_min,
                        "dist_max": neighbor.dist_max,
                    }
                    for neighbor in item.neighbor_kinds
                ],
            }
            for item in spec.added_kinds
        ],
    }
    print(json.dumps(payload))
    return 0


def _handle_add_sites_export_spec(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .add_sites_export import export_add_sites_spec

    text = export_add_sites_spec(
        args.solver_text,
        out=args.out,
        fmt=args.format,
    )
    if args.out is None:
        print(text, end="")
    else:
        print(json.dumps({"out": args.out, "format": args.format, "bytes": len(text.encode())}))
    return 0


def _guide_summary(workflow, input_path: str | None = None) -> dict:
    raw_strategy = None
    raw_advanced = None
    if input_path:
        try:
            payload = _load_yaml_config(input_path) or {}
            if isinstance(payload, dict):
                solve_block = payload.get("solve", {})
                if isinstance(solve_block, dict):
                    if isinstance(solve_block.get("strategy"), dict):
                        raw_strategy = dict(solve_block.get("strategy", {}))
                    if isinstance(solve_block.get("advanced"), dict):
                        raw_advanced = dict(solve_block.get("advanced", {}))
        except Exception:
            raw_strategy = None
            raw_advanced = None

    prepared = workflow.prepare()
    guide_input = prepared.guide
    solve_options = workflow.config.solve
    return {
        "title": guide_input.structure.title,
        "n_structure_sites": len(guide_input.structure.sites),
        "n_target_sites": guide_input.composition.n_target_sites,
        "number_fixed_at": guide_input.composition.number_fixed_at,
        "composition": {
            item.kind: item.count for item in guide_input.composition.entries
        },
        "charges": {item.kind: item.oxidation for item in guide_input.charges.values},
        "recipes": [
            {"from": recipe.from_kind, "to": list(recipe.to)}
            for recipe in guide_input.recipes
        ],
        "space_group": guide_input.symmetry.space_group,
        "n_wyc_operations": len(guide_input.symmetry.wyc_operations),
        "from_spglib": guide_input.symmetry.from_spglib,
        "guide_options": {
            "n_random_seeds": guide_input.options.n_random_seeds,
            "chop_level": guide_input.options.chop_level,
            "target_cpu_time_sec": guide_input.options.target_cpu_time_sec,
            "skip_ewald_evaluation": guide_input.options.skip_ewald_evaluation,
            "fixed_rg_find_factor": guide_input.options.fixed_rg_find_factor,
        },
        "solve_strategy": {
            "input_strategy": raw_strategy,
            "input_advanced": raw_advanced,
            "resolved_legacy_mapping": {
                "running_index_delta": solve_options.running_index_delta,
                "running_index_monitor": solve_options.running_index_monitor,
                "local_enumeration_limit": solve_options.local_enumeration_limit,
                "local_enumeration_max_chunks": solve_options.local_enumeration_max_chunks,
                "local_enumeration_stride": solve_options.local_enumeration_stride,
                "enumeration_exhaust_all": solve_options.enumeration_exhaust_all,
                "enumeration_save_memory": solve_options.enumeration_save_memory,
                "mpi_adaptive_stride_sync": solve_options.mpi_adaptive_stride_sync,
                "adaptive_stride_scale_secondary": solve_options.adaptive_stride_scale_secondary,
                "swap": solve_options.swap,
                "max_swap": solve_options.max_swap,
                "swap_loop_enabled": solve_options.swap_loop_enabled,
                "swap_loop_mode": solve_options.swap_loop_mode,
                "swap_loop_seed_source": solve_options.swap_loop_seed_source,
            },
        },
    }


def _handle_guide_inspect(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .workflow import ESSWorkflow

    workflow = ESSWorkflow.from_yaml(args.input)
    print_result(args, _guide_summary(workflow, args.input))
    return 0


def _handle_guide_prepare(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .workflow import ESSWorkflow

    workflow = ESSWorkflow.from_yaml(args.input)
    summary = _guide_summary(workflow, args.input)
    if args.out:
        with open(args.out, "w") as handle:
            json.dump(summary, handle)
            handle.write("\n")
    print(json.dumps(summary))
    return 0


def _handle_guide_export_guider(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .guide_guider_writer import write_guider_text_from_yaml

    text = write_guider_text_from_yaml(args.input)
    if args.out is None:
        print(text, end="")
    else:
        with open(args.out, "w") as handle:
            handle.write(text)
        print(json.dumps({"out": args.out, "bytes": len(text.encode())}))
    return 0


def _handle_guide_export_ready(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .workflow import ESSWorkflow

    workflow = ESSWorkflow.from_yaml(args.input)
    text = workflow.export_ready_text(out=args.out)
    if args.out is None:
        print(text, end="")
    else:
        print(json.dumps({"out": args.out, "bytes": len(text.encode())}))
    return 0


def _handle_guide_export_poscar(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .workflow import ESSWorkflow

    workflow = ESSWorkflow.from_yaml(args.input)
    text = workflow.export_poscar_text(out=args.out)
    if args.out is None:
        print(text, end="")
    else:
        print(json.dumps({"out": args.out, "bytes": len(text.encode())}))
    return 0


def _handle_symmetry_detect(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    detected = detect_symmetry_with_spglib(load_poscar(args.poscar), symprec=args.symprec)
    print(
        json.dumps(
            {
                "space_group_number": detected.space_group_number,
                "international_symbol": detected.international_symbol,
                "n_wyc_operations": len(detected.symmetry.wyc_operations),
                "from_spglib": detected.symmetry.from_spglib,
            }
        )
    )
    return 0


def _handle_symmetry_write_wyc(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    detected = detect_symmetry_with_spglib(load_poscar(args.poscar), symprec=args.symprec)
    out = args.out or f"{detected.space_group_number}.wyc"
    path = write_wyc_file(out, detected.symmetry)
    print(
        json.dumps(
            {
                "out": str(path),
                "space_group_number": detected.space_group_number,
                "international_symbol": detected.international_symbol,
                "n_wyc_operations": len(detected.symmetry.wyc_operations),
            }
        )
    )
    return 0


def _handle_symmetry_inspect_wyc(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    wyc = parse_wyc_file(args.wyc)
    payload = {
        "header_key": wyc.header_key,
        "declared_n_wyc": wyc.declared_n_wyc,
        "n_entries": len(wyc.entries),
        "labels": [entry.label for entry in wyc.entries],
    }
    if args.space_group is not None:
        symmetry = parse_wyc_file_to_symmetry_model(args.wyc, args.space_group)
        payload["space_group"] = symmetry.space_group
        payload["n_wyc_operations"] = len(symmetry.wyc_operations)
    print(json.dumps(payload))
    return 0


def _handle_solve_inspect_ready(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .ready_text import parse_ready_text

    doc = parse_ready_text(args.ready)
    payload = {
        "ready": str(doc.path),
        "lattice": {"a": list(doc.vec_a), "b": list(doc.vec_b), "c": list(doc.vec_c)},
        "n_atom_config": doc.n_atom_config,
        "supercell_expansion": list(doc.supercell_expansion),
        "rg_find_factor": doc.rg_find_factor,
        "output_prefix": doc.output_prefix,
        "n_recipes": len(doc.recipes),
        "species_counts": _species_counts_from_atoms(doc.atom_config),
        "recipes": [
            {
                "from": recipe.from_kind,
                "oxidation": recipe.oxidation,
                "random_pickup": recipe.random_pickup,
                "random_pickup_trial": recipe.random_pickup_trial,
                "modifications": [
                    {"to": m.to, "oxidation": m.oxidation, "count": m.count}
                    for m in recipe.modifications
                ],
            }
            for recipe in doc.recipes
        ],
    }
    print(json.dumps(payload))
    return 0


def _handle_solve_search_space(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .ready_text import parse_ready_text, ready_text_to_native_payload
    from .solve_search_space import analyze_search_space

    doc = parse_ready_text(args.ready)
    payload = ready_text_to_native_payload(doc)
    summary = analyze_search_space(payload)
    serialized = {
        "ready": str(doc.path),
        "primary_recipe_index": summary.primary_recipe_index,
        "total_candidate_count_log10": summary.total_candidate_count_log10,
        "entries": [
            {
                "from": entry.from_kind,
                "random_pickup": entry.random_pickup,
                "random_pickup_trial": entry.random_pickup_trial,
                "unchanged_count": entry.unchanged_count,
                "assigned_counts": [
                    {"kind": c.kind, "count": c.count}
                    for c in entry.assigned_counts
                ],
                "jobsize_u64": entry.jobsize_u64,
                "jobsize_ld": entry.jobsize_ld,
                "jobsize_saturated": entry.jobsize_saturated,
                "candidate_count_log10": entry.candidate_count_log10,
            }
            for entry in summary.entries
        ],
    }
    print(json.dumps(serialized))
    return 0


def _handle_solve_decode(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .ready_text import parse_ready_text
    from .solve_candidate_decode import decode_candidate_assignment

    doc = parse_ready_text(args.ready)
    if args.recipe < 0 or args.recipe >= len(doc.recipes):
        _parser.error(
            f"--recipe must be in [0, {len(doc.recipes)}); got {args.recipe}"
        )
    recipe = doc.recipes[args.recipe]
    recipe_payload = {
        "from": recipe.from_kind,
        "oxidation": recipe.oxidation,
        "random_pickup": recipe.random_pickup,
        "random_pickup_trial": recipe.random_pickup_trial,
        "modifications": [
            {"to": m.to, "oxidation": m.oxidation, "count": m.count}
            for m in recipe.modifications
        ],
    }
    decoded = decode_candidate_assignment(recipe_payload, args.index)
    payload = {
        "ready": str(doc.path),
        "recipe": args.recipe,
        "index": args.index,
        "indices": list(decoded["indices"]),
        "labels": list(decoded["labels"]),
    }
    print(json.dumps(payload))
    return 0


def _handle_solve_swap(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .ready_text import parse_ready_text, ready_text_to_native_payload
    from .solve_swap_loop import SwapLoopOptions, compute_swap_loop

    doc = parse_ready_text(args.ready)
    payload = ready_text_to_native_payload(doc)
    options = SwapLoopOptions(
        mode=args.mode,
        max_swap=args.max_swap,
        rg_find_factor=doc.rg_find_factor,
        chop_level=float(doc.chop_level),
    )
    result = compute_swap_loop(payload, options)
    summary = {
        "ready": str(doc.path),
        "mode": args.mode,
        "max_swap": args.max_swap,
        "initial_total_energy": result.initial_total_energy,
        "final_total_energy": result.final_total_energy,
        "de_min_swap": result.de_min_swap,
        "swap_count": result.swap_count,
        "stopped_by_max_swap": result.stopped_by_max_swap,
        "stopped_by_no_improvement": result.stopped_by_no_improvement,
        "n_committed_swaps": len(result.committed_swaps),
        "cache_stats": {
            "full_evaluations": result.cache_stats.full_evaluations,
            "diff_evaluations": result.cache_stats.diff_evaluations,
            "recip_state_rebuilds": result.cache_stats.recip_state_rebuilds,
            "recip_incremental_updates": result.cache_stats.recip_incremental_updates,
        },
    }
    print(json.dumps(summary))
    return 0


def _handle_solve_energy_window(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    import random
    from .solve_energy_window import (
        copy_energy_window_structures,
        parse_solver_energy_entries,
    )

    entries = parse_solver_energy_entries(args.solver_text)
    if not entries:
        payload = {
            "solver_text": str(args.solver_text),
            "parsed_entries": 0,
            "selected_entries": 0,
            "rows": [],
            "copied_files": [],
        }
        print(json.dumps(payload))
        return 0
    energies = [entry.energy for entry in entries]
    energy_min = float(args.energy_min) if args.energy_min is not None else float(min(energies))
    energy_max = float(args.energy_max) if args.energy_max is not None else float(max(energies)) + 1e-12

    def _in_interval(e: float) -> bool:
        if args.interval == "open":
            return energy_min < e < energy_max
        if args.interval == "right-closed":
            return energy_min < e <= energy_max
        if args.interval == "closed":
            return energy_min <= e <= energy_max
        return energy_min <= e < energy_max

    selected = [entry for entry in entries if _in_interval(float(entry.energy))]
    if args.pick == "highest":
        selected = sorted(selected, key=lambda item: item.energy, reverse=True)
    elif args.pick == "random":
        rng = random.Random(args.seed)
        selected = list(selected)
        rng.shuffle(selected)
    else:
        selected = sorted(selected, key=lambda item: item.energy)

    if args.limit is not None and args.limit > 0:
        selected = selected[: int(args.limit)]

    copied_files: list[str] = []
    if args.outdir:
        copied = copy_energy_window_structures(
            selected,
            outdir=args.outdir,
            prefix=args.prefix,
        )
        copied_files = [str(path) for path in copied]

    payload = {
        "solver_text": str(args.solver_text),
        "energy_min": energy_min,
        "energy_max": energy_max,
        "interval": args.interval,
        "pick": args.pick,
        "limit": int(args.limit) if args.limit is not None else None,
        "parsed_entries": len(entries),
        "selected_entries": len(selected),
        "rows": [
            {
                "structure": str(entry.structure_path),
                "energy": float(entry.energy),
            }
            for entry in selected
        ],
        "copied_files": copied_files,
    }
    print(json.dumps(payload))
    return 0


def _handle_solve_run(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    """`solve run input.yaml` — alias of top-level `esspy run` for now."""
    from .run_outputs import run_yaml_to_outputs

    print(
        "DEPRECATED: `esspy solve run` is a compatibility alias. Use `esspy run`.",
        file=sys.stderr,
    )
    try:
        summary = run_yaml_to_outputs(
            args.input,
            workdir=args.workdir,
            guide_only=False,
        )
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print_result(args, summary)
    return 0


def _handle_convert_guider_to_yaml(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    """Alias of `init from-guider` framed as a one-shot conversion."""
    from pathlib import Path

    from .init_from_guider import (
        InitFromGuiderOptions,
        write_init_from_guider_yaml,
    )

    options = InitFromGuiderOptions(
        guider_path=Path(args.guider),
        out=Path(args.out),
        name=args.name,
        composition_mode=args.composition_mode,
        output_workdir=args.output_workdir,
        poscar_override=Path(args.poscar) if args.poscar else None,
    )
    out = write_init_from_guider_yaml(options)
    print(json.dumps({"out": str(out), "name": options.name or out.stem}))
    return 0


def _handle_convert_yaml_to_guider(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    """Alias of `guide export-guider` framed as a one-shot conversion."""
    from .guide_guider_writer import write_guider_text_from_yaml

    text = write_guider_text_from_yaml(args.input)
    if args.out is None:
        print(text, end="")
    else:
        with open(args.out, "w") as handle:
            handle.write(text)
        print(json.dumps({"out": args.out, "bytes": len(text.encode())}))
    return 0


def _handle_convert_ready_to_poscar(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    """Materialise a ready file's atom block as a VASP5 POSCAR."""
    from .convert import ready_path_to_poscar_text

    text = ready_path_to_poscar_text(args.ready, title=args.title)
    if args.out is None:
        print(text, end="")
    else:
        with open(args.out, "w") as handle:
            handle.write(text)
        print(json.dumps({"out": args.out, "bytes": len(text.encode())}))
    return 0


def _handle_convert_poscar_to_yaml(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    """Alias of `init from-poscar` framed as a one-shot conversion.

    Re-uses the `init from-poscar` argument set verbatim; this entry
    point exists so users who think in conversion terms (legacy text →
    new yaml) have a single command family.
    """
    print(
        "DEPRECATED: `esspy convert poscar-to-yaml` is a compatibility alias. "
        "Use `esspy init from-poscar`.",
        file=sys.stderr,
    )
    return _handle_init_from_poscar(args, parser)


def _handle_convert_solver_addsites_to_json(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    """Alias of `add-sites export-spec --format json`."""
    from .add_sites_export import export_add_sites_spec

    text = export_add_sites_spec(
        args.solver_text,
        out=args.out,
        fmt="json",
    )
    if args.out is None:
        print(text, end="")
    else:
        print(json.dumps({"out": args.out, "format": "json", "bytes": len(text.encode())}))
    return 0


def _species_counts_from_atoms(atoms) -> dict[str, int]:
    counts: dict[str, int] = {}
    for atom in atoms:
        counts[atom.kind] = counts.get(atom.kind, 0) + 1
    return counts


def _handle_util_ewald_deprecated(
    args: argparse.Namespace, parser: argparse.ArgumentParser
) -> int:
    print(
        "DEPRECATED: `esspy util ewald` is a compatibility alias. Use `esspy ewald`.",
        file=sys.stderr,
    )
    from .cli_util import _handle_util_ewald

    return _handle_util_ewald(args, parser)


def _handle_not_implemented(args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
    target = getattr(args, "command_path", args.command)
    parser.error(f"Command not implemented yet: {target}")
    return 2


def _handle_stage(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    """Forward `esspy stage ...` to legacy top-level advanced commands."""
    family = getattr(args, "stage_family", None)
    forwarded_args = list(getattr(args, "stage_args", []) or [])
    command_parser = getattr(args, "_command_parser", None)

    if not family:
        if command_parser is not None:
            command_parser.print_help()
            return 0
        return 2

    if forwarded_args and forwarded_args[0] == "--":
        forwarded_args = forwarded_args[1:]

    global_flags: list[str] = []
    if getattr(args, "json", False):
        global_flags.append("--json")
    if getattr(args, "quiet", False):
        global_flags.append("--quiet")
    if getattr(args, "verbose", False):
        global_flags.append("--verbose")
    if getattr(args, "workdir", None):
        global_flags.extend(["--workdir", str(args.workdir)])
    if getattr(args, "force", False):
        global_flags.append("--force")
    if getattr(args, "dry_run", False):
        global_flags.append("--dry-run")

    return main(global_flags + [str(family)] + forwarded_args)


def _print_help_handler(parser: argparse.ArgumentParser) -> Handler:
    def _handler(_args: argparse.Namespace, _root_parser: argparse.ArgumentParser) -> int:
        parser.print_help()
        return 0

    return _handler


def _attach_add_sites_run_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--solver-text", required=True, help="Path to basic_properties_EwaldSolidSolution*.txt")
    parser.add_argument("--poscar", required=True, help="Path to POSCAR(.vasp)")
    parser.add_argument("--wyc", default=None, help="Optional path to <space_group>.wyc")
    parser.add_argument("--space-group", type=int, default=1, help="Space group for optional wyc parsing")
    parser.add_argument("--seed", type=int, default=0, help="Random seed")
    parser.add_argument("--rg-find-factor", type=int, default=1, help="RGFindFactor")
    parser.add_argument("--chop-level", type=float, default=8.0, help="ChopLevel")
    parser.add_argument("--use-mpi", action="store_true", help="Use MPI orchestration wrapper")
    parser.add_argument(
        "--charges-json",
        default=None,
        help='Optional JSON dict for oxidation map, e.g. \'{"O":-2,"Mn":2}\'',
    )


def _attach_init_from_poscar_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("poscar", help="Reference POSCAR path")
    parser.add_argument("--out", default="input.yaml", help="Output input.yaml path")
    parser.add_argument("--name", default=None, help="Run name; defaults to POSCAR title/stem")
    size_mode = parser.add_mutually_exclusive_group()
    size_mode.add_argument("--n-target-sites", type=int, default=None, help="Target supercell site count")
    size_mode.add_argument(
        "--dim",
        nargs="+",
        metavar="N",
        default=None,
        help=(
            "Explicit supercell dimension/matrix: 3 integers for diagonal "
            "or 9 row-major integers for a 3x3 matrix"
        ),
    )
    parser.add_argument("--fixed", default="O", help="Species used for count residue/fixed count")
    composition = parser.add_mutually_exclusive_group(required=True)
    composition.add_argument(
        "--composition",
        help="Integer counts, e.g. Mn=14,Cr=15,Ni=19,O=64",
    )
    composition.add_argument(
        "--fractions",
        help="Fractions, e.g. Mn=0.125,Cr=0.1339285714,Ni=0.1696428571,O=0.5714285714",
    )
    parser.add_argument(
        "--charges",
        required=True,
        help="Charges/oxidations, e.g. Mn=1.512165,Cr=1.707951,Ni=1.299835,O=-1.116975625",
    )
    parser.add_argument(
        "--charge-basis",
        choices=("element", "element_site"),
        default="element",
        help="Charge schema: element or element_site",
    )
    parser.add_argument(
        "--site-group",
        action="append",
        default=[],
        help=(
            "Site group as NAME:SOURCE:ALLOWED1,ALLOWED2; repeatable. "
            "Example: site1:Mn:Mn,Cr,Ni"
        ),
    )
    parser.add_argument(
        "--site-grouping",
        choices=("element", "poscar_kind", "element_wyckoff"),
        default=None,
        help=(
            "Auto-detect site groups from POSCAR. "
            "element/poscar_kind groups by POSCAR kind; element_wyckoff splits by spglib Wyckoff orbit."
        ),
    )
    parser.add_argument(
        "--site-group-symprec",
        type=float,
        default=0.1,
        help="Symmetry tolerance for --site-grouping element_wyckoff (default: 0.1)",
    )
    parser.add_argument(
        "--site-group-angle-tolerance",
        type=float,
        default=5.0,
        help="Angle tolerance for --site-grouping element_wyckoff (default: 5.0)",
    )
    parser.add_argument(
        "--site-group-fallback",
        choices=("element", "poscar_kind"),
        default="poscar_kind",
        help="Fallback grouping if element_wyckoff detection fails (default: poscar_kind)",
    )
    parser.add_argument(
        "--site-group-strict",
        action="store_true",
        help="Fail instead of falling back when automatic site grouping fails",
    )
    parser.add_argument(
        "--site-charge",
        default=None,
        help=(
            "Optional site charge overrides, e.g. Mn@site1=1.8,Mn@site2=2.2"
        ),
    )
    parser.add_argument(
        "--allocation-time-budget-sec",
        type=int,
        default=None,
        help="Time budget in seconds for site allocation search",
    )
    parser.add_argument(
        "--recipe",
        action="append",
        required=True,
        help="Recipe in FROM->TO1,TO2 format; also supports FROM:TO1,TO2 or FROM=TO1,TO2; repeatable",
    )
    parser.add_argument("--symmetry", choices=("auto", "p1"), default="auto", help="Symmetry setup mode")
    parser.add_argument("--symprec", type=float, default=1e-5, help="spglib symmetry tolerance for --symmetry auto")
    parser.add_argument("--write-wyc-path", default="symmetry.wyc", help="WYC output path for --symmetry auto")
    parser.add_argument("--target-cpu-time-sec", type=int, default=100, help="Guider target CPU time")
    parser.add_argument("--n-random-seeds", type=int, default=2000, help="Guider random seed count")
    parser.add_argument("--max-swap", type=int, default=100, help="ESS swap cap")
    parser.add_argument(
        "--solve-mode",
        choices=("adaptive", "bounded_exhaustive", "exhaustive"),
        default="adaptive",
        help="Solve strategy mode",
    )
    parser.add_argument(
        "--solve-effort",
        choices=("low", "medium", "high", "extreme"),
        default="medium",
        help="Solve strategy effort preset",
    )
    parser.add_argument(
        "--time-budget-sec",
        type=int,
        default=600,
        help="Solve strategy time budget in seconds (used for --solve-mode adaptive)",
    )
    parser.add_argument("--fixed-rg-find-factor", type=int, default=None, help="Optional fixed RGFindFactor")
    parser.add_argument("--skip-ewald-evaluation", action="store_true", help="Skip guider Ewald evaluation")
    parser.add_argument("--output-workdir", default=None, help="Planned run output directory in YAML")
    parser.add_argument("--selection-enabled", choices=("true", "false"), default="true", help="Enable output.selection block")
    parser.add_argument("--selection-mode", choices=("auto_top_n", "energy_window"), default="auto_top_n", help="output.selection.mode")
    parser.add_argument("--selection-limit", type=int, default=20, help="output.selection.limit")
    parser.add_argument("--selection-pick", choices=("lowest", "highest", "random"), default="lowest", help="output.selection.pick")
    parser.add_argument("--selection-interval", choices=("open", "left-closed", "right-closed", "closed"), default="left-closed", help="output.selection.interval")
    parser.add_argument("--selection-seed", type=int, default=None, help="output.selection.seed (random pick)")
    parser.add_argument("--selection-outdir", default="selected_structures", help="output.selection.outdir")
    parser.add_argument("--selection-prefix", default="selected", help="output.selection.prefix")


def _configure_top_level_command_help(
    subparsers_action: argparse._SubParsersAction,
) -> None:
    """Reorder and relabel top-level command help for user-facing flow.

    This changes only how commands appear in `esspy --help`. Command behavior
    and compatibility aliases remain unchanged.
    """
    preferred_order = [
        "wizard",
        "init",
        "run",
        "ewald",
        "stage",
        "util",
        "sample",
        "fit-charge",
        "guide",
        "solve",
        "symmetry",
        "add-sites",
        "convert",
    ]

    visible_choices = [
        action
        for action in subparsers_action._choices_actions  # noqa: SLF001
        if action.help != argparse.SUPPRESS
    ]
    subparsers_action._choices_actions = visible_choices  # noqa: SLF001

    order_rank = {name: idx for idx, name in enumerate(preferred_order)}
    subparsers_action._choices_actions.sort(  # noqa: SLF001
        key=lambda action: order_rank.get(
            getattr(action, "dest", ""),
            len(preferred_order),
        )
    )

    advanced_prefix = {
        "guide": "Advanced:",
        "solve": "Advanced:",
        "symmetry": "Advanced:",
        "add-sites": "Advanced:",
        "convert": "Advanced:",
    }
    utility_prefix = {
        "sample": "Utility:",
        "fit-charge": "Utility:",
    }
    for action in subparsers_action._choices_actions:  # noqa: SLF001
        name = getattr(action, "dest", "")
        if name in advanced_prefix and action.help and action.help != argparse.SUPPRESS:
            action.help = f"{advanced_prefix[name]} {action.help}"
        if name in utility_prefix and action.help and action.help != argparse.SUPPRESS:
            action.help = f"{utility_prefix[name]} {action.help}"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="esspy",
        description="Unified Python CLI for EwaldSolidSolution Guider and ESS",
    )
    
    # Global flags
    parser.add_argument("--version", action="store_true", help="Print package version")
    parser.add_argument("--json", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--quiet", "-q", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--verbose", "-v", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--workdir", default=None, help=argparse.SUPPRESS)
    parser.add_argument("--force", "-f", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--dry-run", action="store_true", help=argparse.SUPPRESS)

    subparsers = parser.add_subparsers(
        dest="command",
        metavar="{wizard,init,run,ewald,stage,util,sample,fit-charge,allocation}",
    )

    init_parser = subparsers.add_parser(
        "init",
        help="Create editable input.yaml scaffolds",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Quick usage:\n"
            "  esspy init -p POSCAR --out input.yaml\n"
            "  esspy init --from-guider basic_properties_EwaldSolidSolutionGuider.txt\n\n"
            "  esspy init --from-existing input.yaml --out input.clone.yaml\n\n"
            "Detailed options:\n"
            "  esspy init from-poscar --help\n"
            "  esspy init from-guider --help"
        ),
    )
    init_parser.description = (
        "Quick scaffold entrypoint. For full option sets, use "
        "`esspy init from-poscar --help` or `esspy init from-guider --help`."
    )
    init_parser.set_defaults(
        handler=_handle_init_unified,
        command_path="init",
        _command_parser=init_parser,
    )
    init_parser.add_argument(
        "--from-guider",
        default=None,
        help="Path to legacy basic_properties_EwaldSolidSolutionGuider.txt (guider migration mode)",
    )
    init_parser.add_argument(
        "--from-existing",
        default=None,
        help="Clone an existing input.yaml schema as-is (wizard-compatible full-fidelity mode)",
    )
    init_parser.add_argument(
        "-p",
        "--poscar",
        default=None,
        help="Reference POSCAR path (POSCAR scaffold mode)",
    )
    init_parser.add_argument("--out", default="input.yaml", help="Output input.yaml path")
    init_parser.add_argument("--name", default=None, help="Run name override")
    init_parser.add_argument(
        "--composition-mode",
        choices=("fractions", "counts"),
        default="fractions",
        help="For --from-guider mode: emit composition as fractions or counts",
    )
    init_size_mode = init_parser.add_mutually_exclusive_group()
    init_size_mode.add_argument("--n-target-sites", type=int, default=None, help=argparse.SUPPRESS)
    init_size_mode.add_argument("--dim", nargs="+", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--fixed", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--composition", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--fractions", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--charges", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--charge-basis", choices=("element", "element_site"), default="element", help=argparse.SUPPRESS)
    init_parser.add_argument("--site-group", action="append", default=[], help=argparse.SUPPRESS)
    init_parser.add_argument("--site-grouping", choices=("element", "poscar_kind", "element_wyckoff"), default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--site-group-symprec", type=float, default=0.1, help=argparse.SUPPRESS)
    init_parser.add_argument("--site-group-angle-tolerance", type=float, default=5.0, help=argparse.SUPPRESS)
    init_parser.add_argument("--site-group-fallback", choices=("element", "poscar_kind"), default="poscar_kind", help=argparse.SUPPRESS)
    init_parser.add_argument("--site-group-strict", action="store_true", help=argparse.SUPPRESS)
    init_parser.add_argument("--site-charge", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--allocation-time-budget-sec", type=int, default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--recipe", action="append", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--symmetry", choices=("auto", "p1"), default="auto", help=argparse.SUPPRESS)
    init_parser.add_argument("--symprec", type=float, default=1e-5, help=argparse.SUPPRESS)
    init_parser.add_argument("--write-wyc-path", default="symmetry.wyc", help=argparse.SUPPRESS)
    init_parser.add_argument("--target-cpu-time-sec", type=int, default=100, help=argparse.SUPPRESS)
    init_parser.add_argument("--n-random-seeds", type=int, default=2000, help=argparse.SUPPRESS)
    init_parser.add_argument("--max-swap", type=int, default=100, help=argparse.SUPPRESS)
    init_parser.add_argument(
        "--solve-mode",
        choices=("adaptive", "bounded_exhaustive", "exhaustive"),
        default="adaptive",
        help="Solve strategy mode for generated YAML",
    )
    init_parser.add_argument(
        "--solve-effort",
        choices=("low", "medium", "high", "extreme"),
        default="medium",
        help="Solve strategy effort preset for generated YAML",
    )
    init_parser.add_argument(
        "--time-budget-sec",
        type=int,
        default=600,
        help=argparse.SUPPRESS,
    )
    init_parser.add_argument("--fixed-rg-find-factor", type=int, default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--skip-ewald-evaluation", action="store_true", help=argparse.SUPPRESS)
    init_parser.add_argument("--output-workdir", default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-enabled", choices=("true", "false"), default="true", help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-mode", choices=("auto_top_n", "energy_window"), default="auto_top_n", help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-limit", type=int, default=20, help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-pick", choices=("lowest", "highest", "random"), default="lowest", help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-interval", choices=("open", "left-closed", "right-closed", "closed"), default="left-closed", help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-seed", type=int, default=None, help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-outdir", default="selected_structures", help=argparse.SUPPRESS)
    init_parser.add_argument("--selection-prefix", default="selected", help=argparse.SUPPRESS)
    init_sub = init_parser.add_subparsers(dest="init_command")
    init_from_poscar = init_sub.add_parser(
        "from-poscar",
        help="Create input.yaml from a reference POSCAR",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=INIT_FROM_POSCAR_EPILOG,
    )
    _attach_init_from_poscar_args(init_from_poscar)
    init_from_poscar.set_defaults(handler=_handle_init_from_poscar, command_path="init from-poscar")
    init_from_guider = init_sub.add_parser(
        "from-guider",
        help="Migrate a legacy basic_properties_EwaldSolidSolutionGuider.txt to input.yaml",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=INIT_FROM_GUIDER_EPILOG,
    )
    init_from_guider.add_argument(
        "guider",
        help="Path to legacy basic_properties_EwaldSolidSolutionGuider.txt",
    )
    init_from_guider.add_argument(
        "--out",
        default="input.yaml",
        help="Output input.yaml path",
    )
    init_from_guider.add_argument(
        "--name",
        default=None,
        help="Run name; defaults to the legacy OutputPrefix or guider stem",
    )
    init_from_guider.add_argument(
        "--composition-mode",
        choices=("fractions", "counts"),
        default="fractions",
        help="Express composition as raw target fractions (default, exact "
        "round-trip) or as integer counts (fractions * n_target_sites)",
    )
    init_from_guider.add_argument(
        "--poscar",
        default=None,
        help="Override the companion POSCAR path; defaults to the path the "
        "guider text references resolved against the guider file's directory",
    )
    init_from_guider.add_argument(
        "--output-workdir",
        default=None,
        help="Planned run output directory in YAML",
    )
    init_from_guider.add_argument(
        "--solve-mode",
        choices=("adaptive", "bounded_exhaustive", "exhaustive"),
        default="adaptive",
        help="Solve strategy mode for generated YAML",
    )
    init_from_guider.add_argument(
        "--solve-effort",
        choices=("low", "medium", "high", "extreme"),
        default="medium",
        help="Solve strategy effort preset for generated YAML",
    )
    init_from_guider.add_argument(
        "--time-budget-sec",
        type=int,
        default=600,
        help="Solve strategy time budget in seconds (used for adaptive mode)",
    )
    init_from_guider.add_argument(
        "--max-swap",
        type=int,
        default=100,
        help="Solve strategy swap max steps",
    )
    init_from_guider.add_argument("--selection-enabled", choices=("true", "false"), default="true", help="Enable output.selection block")
    init_from_guider.add_argument("--selection-mode", choices=("auto_top_n", "energy_window"), default="auto_top_n", help="output.selection.mode")
    init_from_guider.add_argument("--selection-limit", type=int, default=20, help="output.selection.limit")
    init_from_guider.add_argument("--selection-pick", choices=("lowest", "highest", "random"), default="lowest", help="output.selection.pick")
    init_from_guider.add_argument("--selection-interval", choices=("open", "left-closed", "right-closed", "closed"), default="left-closed", help="output.selection.interval")
    init_from_guider.add_argument("--selection-seed", type=int, default=None, help="output.selection.seed (random pick)")
    init_from_guider.add_argument("--selection-outdir", default="selected_structures", help="output.selection.outdir")
    init_from_guider.add_argument("--selection-prefix", default="selected", help="output.selection.prefix")
    init_from_guider.set_defaults(
        handler=_handle_init_from_guider, command_path="init from-guider"
    )
    init_template = init_sub.add_parser("template", help="`init template` (planned)")
    init_template.set_defaults(handler=_handle_not_implemented, command_path="init template")

    run_parser = subparsers.add_parser(
        "run",
        help="Run guide + solve from input.yaml and write outputs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=RUN_EPILOG,
    )
    run_parser.add_argument("input", help="Path to input.yaml")
    run_parser.add_argument("--workdir", default=None, help="Output directory")
    run_parser.add_argument("--guide-only", action="store_true", help="Stop after guide-stage outputs")
    run_parser.add_argument("--no-progress", action="store_true", help="Disable console and file progress logging")
    run_parser.add_argument("--progress-interval", type=float, default=None, help="Minimum seconds between periodic progress messages")
    run_parser.add_argument("--log-file", default=None, help="Override main progress log path")
    run_parser.add_argument(
        "--charge-model",
        default=None,
        help=(
            "Override input charges at runtime using a charge_model.json. "
            "If omitted, esspy run auto-loads charge_model.json next to the input YAML when present."
        ),
    )
    run_parser.set_defaults(handler=_handle_run, command_path="run")

    sample_parser = subparsers.add_parser(
        "sample",
        help="Generate random substituted POSCAR samples from input.yaml (no solve)",
    )
    sample_parser.add_argument("input", help="Path to input.yaml")
    sample_parser.add_argument(
        "-n",
        type=int,
        required=True,
        help="Number of random structures to generate",
    )
    sample_parser.add_argument(
        "--outdir",
        default="samples",
        help="Output directory (default: samples; existing paths use -NEW01, -NEW02, ...)",
    )
    sample_parser.add_argument(
        "--prefix",
        default="sample",
        help="Output file prefix (default: sample)",
    )
    sample_parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for reproducible sampling",
    )
    sample_parser.set_defaults(handler=_handle_sample, command_path="sample")

    fit_charge_parser = subparsers.add_parser(
        "fit-charge",
        aliases=["fc"],
        help="Fit effective element charges from a simple dataset text file",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage=(
            "esspy fit-charge [dataset] [options]\n"
            "                        or: esspy fit-charge -p POSCAR [POSCAR ...] --outcar OUTCAR [OUTCAR ...] [options]"
        ),
        description=(
            "Fit effective element charges against DFT energies.\n\n"
            "Choose exactly one input mode:\n"
            "  1) dataset file: `structure_path energy_eV [weight]` per line\n"
            "  2) pattern mode: `-p/--poscar` + `--outcar` (matched by trailing numeric id)"
        ),
        epilog=FIT_CHARGE_EPILOG,
    )
    fit_input_group = fit_charge_parser.add_argument_group("Input Mode")
    fit_output_group = fit_charge_parser.add_argument_group("Output Files")
    fit_tuning_group = fit_charge_parser.add_argument_group("Fit Tuning")

    fit_input_group.add_argument(
        "dataset",
        nargs="?",
        help="Dataset text file: `structure_path energy_eV [weight]` per line",
    )
    fit_input_group.add_argument(
        "-p",
        "--poscar",
        nargs="+",
        default=None,
        help="POSCAR path(s) or glob pattern(s), e.g. sample-*.vasp",
    )
    fit_input_group.add_argument(
        "--outcar",
        nargs="+",
        default=None,
        help="OUTCAR path(s) or glob pattern(s), e.g. OUTCAR-sample-*.vasp",
    )
    fit_input_group.add_argument(
        "--dataset-out",
        default="dataset.txt",
        help="Pattern mode only: write matched dataset here (default: dataset.txt)",
    )
    fit_input_group.add_argument(
        "--allow-partial",
        action="store_true",
        help="Allow partial id matching instead of requiring exact POSCAR/OUTCAR id sets",
    )
    fit_tuning_group.add_argument(
        "--basis",
        choices=["auto", "element", "element_site"],
        default="auto",
        help="Charge basis: auto, element, or element_site (default: auto)",
    )
    fit_tuning_group.add_argument(
        "--input",
        dest="input_yaml",
        default=None,
        help="Input YAML with site_groups (required for --basis element_site)",
    )
    fit_tuning_group.add_argument(
        "--anchor-kind",
        default="O",
        help="Anchor species for neutrality constraint (default: O)",
    )
    fit_tuning_group.add_argument(
        "--rg-find-factor",
        type=int,
        default=3,
        help="RGFindFactor for Ewald evaluation (default: 3)",
    )
    fit_tuning_group.add_argument(
        "--chop-level",
        type=float,
        default=8.0,
        help="Chop level for Ewald evaluation (default: 8.0)",
    )
    fit_tuning_group.add_argument(
        "--maxiter",
        type=int,
        default=120,
        help="Optimizer max iterations (default: 120)",
    )
    fit_tuning_group.add_argument(
        "--objective",
        choices=["mapped_rmse", "raw_rmse"],
        default="mapped_rmse",
        help=(
            "Objective: mapped_rmse uses calibrated ΔE_Ewald, "
            "raw_rmse uses raw ΔE_Ewald (default: mapped_rmse)"
        ),
    )
    fit_tuning_group.add_argument(
        "--map-mode",
        choices=["bias_only", "linear"],
        default="bias_only",
        help=(
            "Calibration mapping: bias_only keeps ranking, "
            "linear uses scale+offset (default: bias_only)"
        ),
    )
    fit_tuning_group.add_argument(
        "--reg-l2",
        type=float,
        default=1.0e-3,
        help="L2 regularization around default oxidation initial guess (default: 1e-3)",
    )
    fit_tuning_group.add_argument(
        "--reg-site-delta",
        type=float,
        default=1.0e-2,
        help=(
            "Extra regularization for element_site basis: penalize site-to-site charge split "
            "within same element (default: 1e-2)"
        ),
    )
    fit_tuning_group.add_argument(
        "--energy-weight-mode",
        choices=["uniform", "boltzmann", "low_energy_boost"],
        default="low_energy_boost",
        help="Weighting mode for DFT delta energies (default: low_energy_boost)",
    )
    fit_tuning_group.add_argument(
        "--energy-weight-temp-eV",
        type=float,
        default=1.0,
        help="Boltzmann temperature (eV) for --energy-weight-mode boltzmann (default: 1.0)",
    )
    fit_tuning_group.add_argument(
        "--low-energy-fraction",
        type=float,
        default=0.3,
        help="Low-energy quantile in (0,1] for low_energy_boost mode (default: 0.3)",
    )
    fit_tuning_group.add_argument(
        "--low-energy-boost",
        type=float,
        default=3.0,
        help="Weight multiplier on low-energy subset for low_energy_boost mode (default: 3.0)",
    )
    fit_tuning_group.add_argument(
        "--no-precompute",
        action="store_true",
        help="Disable quadratic Ewald precompute cache and use direct full Ewald per evaluation",
    )
    fit_tuning_group.add_argument(
        "--cache",
        "--precompute-cache",
        dest="precompute_cache",
        default="ewald_quadratic_cache.npz",
        help="NPZ path for quadratic precompute cache load/save (default: ewald_quadratic_cache.npz)",
    )
    fit_output_group.add_argument(
        "--out-model",
        default="charge_model.json",
        help="Output model JSON path (default: charge_model.json)",
    )
    fit_output_group.add_argument(
        "--out-report",
        default="fit_report.json",
        help="Output report JSON path (default: fit_report.json)",
    )
    fit_output_group.add_argument(
        "--out-plot",
        default="parity_plot.pdf",
        help="Output parity plot path (default: parity_plot.pdf)",
    )
    fit_output_group.add_argument(
        "--no-update-poscar-titles",
        action="store_true",
        help=(
            "Do not rewrite fitted charge values into the first line of input "
            "POSCAR files. By default, esspy fc updates POSCAR title charges so "
            "`esspy ewald -p sample.vasp` reuses the fitted model."
        ),
    )
    fit_charge_parser.set_defaults(
        handler=_handle_fit_charge,
        command_path="fit-charge",
        _command_parser=fit_charge_parser,
    )

    validate_model_parser = subparsers.add_parser(
        "validate-model",
        help="Evaluate an existing charge_model.json on a new dataset and draw parity plot",
    )
    validate_model_parser.add_argument(
        "dataset",
        nargs="?",
        help="Dataset text file: `structure_path energy_eV [weight]` per line",
    )
    validate_model_parser.add_argument("-p", "--poscar", nargs="+", default=None, help="POSCAR path(s) or glob pattern(s)")
    validate_model_parser.add_argument("--outcar", nargs="+", default=None, help="OUTCAR path(s) or glob pattern(s)")
    validate_model_parser.add_argument("--dataset-out", default="dataset.txt", help="Pattern mode only: write matched dataset here")
    validate_model_parser.add_argument("--allow-partial", action="store_true", help="Allow partial id matching")
    validate_model_parser.add_argument("--charge-model", required=True, help="Path to charge_model.json")
    validate_model_parser.add_argument("--rg-find-factor", type=int, default=3, help="RGFindFactor for Ewald evaluation")
    validate_model_parser.add_argument("--chop-level", type=float, default=8.0, help="Chop level for Ewald evaluation")
    validate_model_parser.add_argument("--map-mode", choices=["bias_only", "linear"], default="bias_only", help="Calibration mapping mode")
    validate_model_parser.add_argument("--out-report", default="validate_report.json", help="Output report JSON")
    validate_model_parser.add_argument("--out-plot", default="parity_generalization_fixed_model.pdf", help="Output parity plot PDF")
    validate_model_parser.set_defaults(handler=_handle_validate_model, command_path="validate-model")

    allocation_parser = subparsers.add_parser(
        "allocation",
        help="Site-composition allocation utilities",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    allocation_sub = allocation_parser.add_subparsers(dest="allocation_cmd")

    allocation_opt_parser = allocation_sub.add_parser(
        "optimize",
        help="Generate composition_by_site from global composition + site_groups",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=ALLOCATION_OPTIMIZE_EPILOG,
    )
    allocation_opt_parser.add_argument("input", help="Path to input.yaml")
    allocation_opt_parser.add_argument(
        "--out-yaml",
        default="input.sitewise.yaml",
        help="Output YAML with composition_by_site (default: input.sitewise.yaml)",
    )
    allocation_opt_parser.add_argument(
        "--out-table",
        default="allocation_table.json",
        help="Output allocation table JSON (default: allocation_table.json)",
    )
    allocation_opt_parser.add_argument(
        "--out-report",
        default="allocation_report.json",
        help="Output report JSON (default: allocation_report.json)",
    )
    allocation_opt_parser.add_argument(
        "--n-alloc",
        type=int,
        default=8,
        help="Number of allocation candidates to generate (default: 8)",
    )
    allocation_opt_parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for candidate generation",
    )
    allocation_opt_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Do not write output YAML; still write table/report",
    )
    allocation_opt_parser.add_argument(
        "--score-mode",
        choices=["ewald", "site_affinity"],
        default="ewald",
        help="Candidate scoring mode (default: ewald)",
    )
    allocation_opt_parser.add_argument(
        "--ewald-samples",
        type=int,
        default=8,
        help="Per-candidate random sample count for Ewald scoring (default: 8)",
    )
    allocation_opt_parser.add_argument(
        "--metric",
        choices=["best", "min_mean", "topk_mean"],
        default="best",
        help="Selection metric for Ewald score mode (default: best)",
    )
    allocation_opt_parser.add_argument(
        "--topk",
        type=int,
        default=3,
        help="k for --metric topk_mean (default: 3)",
    )
    allocation_opt_parser.add_argument(
        "--no-guide-gate",
        action="store_true",
        help="Skip guide-only validity gate for each candidate",
    )
    allocation_opt_parser.add_argument(
        "--prefer",
        action="append",
        default=None,
        help="Preference weight: Element@site_group=weight (repeatable)",
    )
    allocation_opt_parser.set_defaults(
        handler=_handle_allocation_optimize,
        command_path="allocation optimize",
    )

    wizard_parser = subparsers.add_parser(
        "wizard",
        help="Interactive wizard for structure configuration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    wizard_parser.add_argument(
        "--output", "-o",
        default="input.yaml",
        help="Output YAML path",
    )
    wizard_parser.add_argument(
        "--then-run",
        action="store_true",
        help="Automatically run esspy run after wizard completes",
    )
    wizard_parser.set_defaults(handler=_handle_wizard, command_path="wizard")

    stage_parser = subparsers.add_parser(
        "stage",
        help="Advanced stage-level operations (guide/solve/symmetry/add-sites/convert)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Legacy compatibility aliases are still accepted:\n"
            "  add-sites-run\n"
            "  guide / solve / symmetry / add-sites / convert\n"
            "Prefer using: esspy stage ..."
        ),
    )
    stage_parser.set_defaults(
        handler=_handle_stage,
        command_path="stage",
        _command_parser=stage_parser,
    )
    stage_parser.add_argument(
        "stage_family",
        nargs="?",
        choices=("guide", "solve", "symmetry", "add-sites", "convert"),
        help="Advanced command family",
    )
    stage_parser.add_argument(
        "stage_args",
        nargs=argparse.REMAINDER,
        help="Arguments forwarded to the selected family",
    )

    # Legacy compatibility alias: keep until grouped `add-sites run` becomes standard.
    guide_parser = subparsers.add_parser("guide", help=argparse.SUPPRESS)
    guide_parser.set_defaults(handler=_print_help_handler(guide_parser))
    guide_sub = guide_parser.add_subparsers(dest="guide_command")
    guide_prepare = guide_sub.add_parser("prepare", help="Validate and summarize guide input")
    guide_prepare.add_argument("input", help="Path to input.yaml")
    guide_prepare.add_argument("--out", default=None, help="Optional JSON summary output path")
    guide_prepare.set_defaults(handler=_handle_guide_prepare, command_path="guide prepare")
    guide_inspect = guide_sub.add_parser(
        "inspect",
        help="Inspect guide-stage input without running ESS",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=GUIDE_INSPECT_EPILOG,
    )
    guide_inspect.add_argument("input", help="Path to input.yaml")
    guide_inspect.set_defaults(handler=_handle_guide_inspect, command_path="guide inspect")
    guide_export_guider = guide_sub.add_parser(
        "export-guider",
        help="Export legacy Guider input text",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=GUIDE_EXPORT_GUIDER_EPILOG,
    )
    guide_export_guider.add_argument("input", help="Path to input.yaml")
    guide_export_guider.add_argument("--out", default=None, help="Output guider text path")
    guide_export_guider.set_defaults(handler=_handle_guide_export_guider, command_path="guide export-guider")
    guide_export_ready = guide_sub.add_parser(
        "export-ready",
        help="Run guide and export ready text",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=GUIDE_EXPORT_READY_EPILOG,
    )
    guide_export_ready.add_argument("input", help="Path to input.yaml")
    guide_export_ready.add_argument("--out", default=None, help="Output ready text path")
    guide_export_ready.set_defaults(handler=_handle_guide_export_ready, command_path="guide export-ready")
    guide_export_poscar = guide_sub.add_parser("export-poscar", help="Run guide and export POSCAR")
    guide_export_poscar.add_argument("input", help="Path to input.yaml")
    guide_export_poscar.add_argument("--out", default=None, help="Output POSCAR path")
    guide_export_poscar.set_defaults(handler=_handle_guide_export_poscar, command_path="guide export-poscar")

    solve_parser = subparsers.add_parser("solve", help=argparse.SUPPRESS)
    solve_parser.set_defaults(handler=_print_help_handler(solve_parser))
    solve_sub = solve_parser.add_subparsers(dest="solve_command")

    solve_run = solve_sub.add_parser(
        "run",
        help="Run guide+solve from input.yaml (alias of `esspy run`)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=SOLVE_RUN_EPILOG,
    )
    solve_run.add_argument("input", help="Path to input.yaml")
    solve_run.add_argument("--workdir", default=None, help="Output directory")
    solve_run.set_defaults(handler=_handle_solve_run, command_path="solve run")

    solve_inspect = solve_sub.add_parser(
        "inspect-ready",
        help="Parse a ready file and summarise atoms, lattice, and recipes",
    )
    solve_inspect.add_argument(
        "ready", help="Path to basic_properties_EwaldSolidSolution.ready.txt"
    )
    solve_inspect.set_defaults(
        handler=_handle_solve_inspect_ready, command_path="solve inspect-ready"
    )

    solve_search_space = solve_sub.add_parser(
        "search-space",
        help="Analyse the recipe-driven combinatorial search space of a ready file",
    )
    solve_search_space.add_argument("ready", help="Path to ready text")
    solve_search_space.set_defaults(
        handler=_handle_solve_search_space, command_path="solve search-space"
    )

    solve_decode = solve_sub.add_parser(
        "decode", help="Decode a specific candidate index from a ready recipe"
    )
    solve_decode.add_argument("ready", help="Path to ready text")
    solve_decode.add_argument(
        "--recipe", type=int, required=True, help="Recipe index in the ready file"
    )
    solve_decode.add_argument(
        "--index",
        type=int,
        default=1,
        help="Candidate index (1-based, defaults to 1)",
    )
    solve_decode.set_defaults(
        handler=_handle_solve_decode, command_path="solve decode"
    )

    solve_swap = solve_sub.add_parser(
        "swap",
        help="Run the typed swap loop directly on a ready file (no full pipeline)",
    )
    solve_swap.add_argument("ready", help="Path to ready text")
    solve_swap.add_argument(
        "--mode",
        type=int,
        choices=(1, 2),
        default=1,
        help="1 = best improvement (legacy Swap=1), 2 = first improvement",
    )
    solve_swap.add_argument(
        "--max-swap",
        type=int,
        default=100,
        help="Maximum swap rounds (<= 0 to run until no improvement)",
    )
    solve_swap.set_defaults(
        handler=_handle_solve_swap, command_path="solve swap"
    )

    solve_energy_window = solve_sub.add_parser(
        "energy-window",
        help="Filter structure files from solver text by energy range",
    )
    solve_energy_window.add_argument(
        "--solver-text",
        required=True,
        help="Path to basic_properties_EwaldSolidSolution*.txt",
    )
    solve_energy_window.add_argument(
        "--energy-min",
        type=float,
        default=None,
        help="Lower bound (inclusive by default interval) in eV; omit for auto range",
    )
    solve_energy_window.add_argument(
        "--energy-max",
        type=float,
        default=None,
        help="Upper bound in eV; omit for auto range",
    )
    solve_energy_window.add_argument(
        "--interval",
        choices=("open", "left-closed", "right-closed", "closed"),
        default="left-closed",
        help="Interval boundary mode (default: left-closed)",
    )
    solve_energy_window.add_argument(
        "--outdir",
        default="selected_structures",
        help="Directory to copy matched structures (default: selected_structures)",
    )
    solve_energy_window.add_argument(
        "--prefix",
        default="selected",
        help="Filename prefix when --outdir is set",
    )
    solve_energy_window.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Max number of selected entries (default: 20)",
    )
    solve_energy_window.add_argument(
        "--pick",
        choices=("lowest", "highest", "random"),
        default="lowest",
        help="Selection policy for limiting (default: lowest)",
    )
    solve_energy_window.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed when --pick random",
    )
    solve_energy_window.set_defaults(
        handler=_handle_solve_energy_window,
        command_path="solve energy-window",
    )

    symmetry_parser = subparsers.add_parser("symmetry", help=argparse.SUPPRESS)
    symmetry_parser.set_defaults(handler=_print_help_handler(symmetry_parser))
    symmetry_sub = symmetry_parser.add_subparsers(dest="symmetry_command")
    symmetry_detect = symmetry_sub.add_parser(
        "detect",
        help="Detect POSCAR symmetry with spglib",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=SYMMETRY_DETECT_EPILOG,
    )
    symmetry_detect.add_argument("poscar", help="Path to POSCAR(.vasp)")
    symmetry_detect.add_argument("--symprec", type=float, default=1e-5, help="spglib symmetry tolerance")
    symmetry_detect.set_defaults(handler=_handle_symmetry_detect, command_path="symmetry detect")
    symmetry_write_wyc = symmetry_sub.add_parser(
        "write-wyc",
        help="Detect symmetry and write Guider-compatible WYC",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=SYMMETRY_WRITE_WYC_EPILOG,
    )
    symmetry_write_wyc.add_argument("poscar", help="Path to POSCAR(.vasp)")
    symmetry_write_wyc.add_argument("--out", default=None, help="Output WYC path; defaults to <space_group>.wyc")
    symmetry_write_wyc.add_argument("--symprec", type=float, default=1e-5, help="spglib symmetry tolerance")
    symmetry_write_wyc.set_defaults(handler=_handle_symmetry_write_wyc, command_path="symmetry write-wyc")
    symmetry_inspect_wyc = symmetry_sub.add_parser(
        "inspect-wyc",
        help="Inspect a Guider-compatible WYC file",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=SYMMETRY_INSPECT_WYC_EPILOG,
    )
    symmetry_inspect_wyc.add_argument("wyc", help="Path to <space_group>.wyc")
    symmetry_inspect_wyc.add_argument("--space-group", type=int, default=None, help="Optional space group for SymmetryModel conversion")
    symmetry_inspect_wyc.set_defaults(handler=_handle_symmetry_inspect_wyc, command_path="symmetry inspect-wyc")

    add_sites_group = subparsers.add_parser("add-sites", help=argparse.SUPPRESS)
    add_sites_group.set_defaults(handler=_print_help_handler(add_sites_group))
    add_sites_sub = add_sites_group.add_subparsers(dest="add_sites_command")
    add_sites_legacy = subparsers.add_parser("add-sites-run", help=argparse.SUPPRESS)
    _attach_add_sites_run_args(add_sites_legacy)
    add_sites_legacy.set_defaults(
        handler=_handle_add_sites_run, command_path="add-sites-run"
    )
    add_sites_run = add_sites_sub.add_parser("run", help="Run add-sites MC from solver text + POSCAR")
    _attach_add_sites_run_args(add_sites_run)
    add_sites_run.set_defaults(handler=_handle_add_sites_run, command_path="add-sites run")
    add_sites_inspect = add_sites_sub.add_parser("inspect", help="Inspect add-sites MC block from solver text")
    add_sites_inspect.add_argument(
        "--solver-text",
        required=True,
        help="Path to basic_properties_EwaldSolidSolution*.txt",
    )
    add_sites_inspect.set_defaults(handler=_handle_add_sites_inspect, command_path="add-sites inspect")
    add_sites_export = add_sites_sub.add_parser(
        "export-spec",
        help="Export add-sites MC spec as YAML/JSON",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=ADD_SITES_EXPORT_SPEC_EPILOG,
    )
    add_sites_export.add_argument(
        "--solver-text",
        required=True,
        help="Path to basic_properties_EwaldSolidSolution*.txt",
    )
    add_sites_export.add_argument("--out", default=None, help="Output spec path")
    add_sites_export.add_argument(
        "--format",
        choices=("yaml", "json"),
        default="yaml",
        help="Output format",
    )
    add_sites_export.set_defaults(handler=_handle_add_sites_export_spec, command_path="add-sites export-spec")

    convert_parser = subparsers.add_parser("convert", help=argparse.SUPPRESS)
    convert_parser.set_defaults(handler=_print_help_handler(convert_parser))
    convert_sub = convert_parser.add_subparsers(dest="convert_command")

    convert_guider_to_yaml = convert_sub.add_parser(
        "guider-to-yaml",
        help="Convert basic_properties_EwaldSolidSolutionGuider.txt to input.yaml",
    )
    convert_guider_to_yaml.add_argument(
        "guider", help="Path to legacy basic_properties_EwaldSolidSolutionGuider.txt"
    )
    convert_guider_to_yaml.add_argument("--out", default="input.yaml", help="Output input.yaml path")
    convert_guider_to_yaml.add_argument("--name", default=None, help="Run name override")
    convert_guider_to_yaml.add_argument(
        "--composition-mode",
        choices=("fractions", "counts"),
        default="fractions",
        help="Express composition as raw fractions (default) or integer counts",
    )
    convert_guider_to_yaml.add_argument(
        "--poscar",
        default=None,
        help="Override the companion POSCAR path",
    )
    convert_guider_to_yaml.add_argument(
        "--output-workdir",
        default=None,
        help="Planned run output directory in YAML",
    )
    convert_guider_to_yaml.set_defaults(
        handler=_handle_convert_guider_to_yaml,
        command_path="convert guider-to-yaml",
    )

    convert_yaml_to_guider = convert_sub.add_parser(
        "yaml-to-guider",
        help="Convert input.yaml to legacy basic_properties_EwaldSolidSolutionGuider.txt",
    )
    convert_yaml_to_guider.add_argument("input", help="Path to input.yaml")
    convert_yaml_to_guider.add_argument(
        "--out", default=None, help="Output guider text path"
    )
    convert_yaml_to_guider.set_defaults(
        handler=_handle_convert_yaml_to_guider,
        command_path="convert yaml-to-guider",
    )

    convert_ready_to_poscar = convert_sub.add_parser(
        "ready-to-poscar",
        help="Convert a ready file's atom block to a VASP5 POSCAR",
    )
    convert_ready_to_poscar.add_argument(
        "ready", help="Path to basic_properties_EwaldSolidSolution.ready.txt"
    )
    convert_ready_to_poscar.add_argument(
        "--out", default=None, help="Output POSCAR path; defaults to stdout"
    )
    convert_ready_to_poscar.add_argument(
        "--title",
        default=None,
        help="POSCAR title; defaults to the ready file's OutputPrefix",
    )
    convert_ready_to_poscar.set_defaults(
        handler=_handle_convert_ready_to_poscar,
        command_path="convert ready-to-poscar",
    )

    convert_poscar_to_yaml = convert_sub.add_parser(
        "poscar-to-yaml",
        help="Convert a reference POSCAR to input.yaml (alias of `init from-poscar`)",
    )
    _attach_init_from_poscar_args(convert_poscar_to_yaml)
    convert_poscar_to_yaml.set_defaults(
        handler=_handle_convert_poscar_to_yaml,
        command_path="convert poscar-to-yaml",
    )

    convert_solver_addsites = convert_sub.add_parser(
        "solver-addsites-to-json",
        help="Export the add-sites MC block from solver text as JSON",
    )
    convert_solver_addsites.add_argument(
        "--solver-text",
        required=True,
        help="Path to basic_properties_EwaldSolidSolution*.txt",
    )
    convert_solver_addsites.add_argument(
        "--out", default=None, help="Output JSON path; defaults to stdout"
    )
    convert_solver_addsites.set_defaults(
        handler=_handle_convert_solver_addsites_to_json,
        command_path="convert solver-addsites-to-json",
    )

    from .cli_util import (
        _handle_util_schema,
        _handle_util_defaults,
        _handle_util_doctor_native,
        _handle_util_show_example,
        _handle_util_site_groups,
        _handle_util_supercell,
        _handle_util_ewald,
        _handle_util_suggest_charges,
        _handle_util_template_list,
        _handle_util_random_structure,
    )

    # Top-level ewald command (shortcut for util ewald)
    ewald_parser = subparsers.add_parser(
        "ewald",
        help="Compute Ewald energy directly from POSCAR file(s)",
    )
    ewald_parser.add_argument(
        "-p",
        "--poscar",
        nargs="+",
        required=True,
        help="POSCAR path(s) or glob pattern(s), e.g. POSCAR-*",
    )
    ewald_parser.add_argument(
        "--charge",
        action="append",
        default=None,
        help="Override oxidation as KIND=VALUE (repeatable), e.g. --charge Mn=2 --charge O=-2",
    )
    ewald_parser.add_argument(
        "--charge-model",
        default=None,
        help="Read element or element-site charges from charge_model.json",
    )
    ewald_parser.add_argument(
        "--rg-find-factor",
        type=int,
        default=None,
        help="Optional fixed RGFindFactor (default: auto-optimized)",
    )
    ewald_parser.add_argument(
        "--chop-level",
        type=float,
        default=None,
        help="Chop level for Ewald sum (default: 8.0)",
    )
    ewald_parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )
    ewald_parser.set_defaults(handler=_handle_util_ewald, command_path="ewald")

    util_parser = subparsers.add_parser("util", help="Utilities and diagnostics")
    util_parser.set_defaults(handler=_print_help_handler(util_parser))
    util_sub = util_parser.add_subparsers(dest="util_command")

    util_schema = util_sub.add_parser("schema", help="Print current YAML schema")
    util_schema.set_defaults(handler=_handle_util_schema, command_path="util schema")

    util_defaults = util_sub.add_parser("defaults", help="Print guide/solve defaults")
    util_defaults.set_defaults(handler=_handle_util_defaults, command_path="util defaults")

    util_doctor = util_sub.add_parser("doctor-native", help="Low-level extension diagnostics")
    util_doctor.set_defaults(handler=_handle_util_doctor_native, command_path="util doctor-native")

    util_example = util_sub.add_parser("show-example", help="Emit a minimal valid input.yaml")
    util_example.set_defaults(handler=_handle_util_show_example, command_path="util show-example")

    util_site_groups = util_sub.add_parser(
        "site-groups",
        help="Inspect site grouping policies for a POSCAR",
        description=(
            "Detect site groups from a POSCAR using POSCAR-kind grouping or "
            "spglib element+Wyckoff/orbit grouping."
        ),
    )
    util_site_groups.add_argument("poscar", help="Reference POSCAR path")
    util_site_groups.add_argument(
        "--mode",
        choices=("element", "poscar_kind", "element_wyckoff"),
        default="element_wyckoff",
        help="Site grouping policy (default: element_wyckoff)",
    )
    util_site_groups.add_argument(
        "--symprec",
        type=float,
        default=0.1,
        help="spglib symmetry tolerance for element_wyckoff grouping (default: 0.1)",
    )
    util_site_groups.add_argument(
        "--angle-tolerance",
        type=float,
        default=5.0,
        help="spglib angle tolerance in degrees (default: 5.0)",
    )
    util_site_groups.add_argument(
        "--fallback",
        choices=("element", "poscar_kind"),
        default="poscar_kind",
        help="Fallback mode if element_wyckoff fails (default: poscar_kind)",
    )
    util_site_groups.add_argument(
        "--strict",
        action="store_true",
        help="Fail instead of falling back when element_wyckoff grouping fails",
    )
    util_site_groups.add_argument(
        "--map",
        action="append",
        default=None,
        metavar="SOURCE:TARGETS",
        help=(
            "Allowed elements for a source kind, e.g. "
            "--map Cr:Mn,Cr,Ni,Rh,Co,Fe --map O:O"
        ),
    )
    util_site_groups.add_argument("--json", action="store_true", help="Output JSON payload")
    util_site_groups.set_defaults(handler=_handle_util_site_groups, command_path="util site-groups")

    util_supercell = util_sub.add_parser(
        "supercell",
        help="Suggest explicit supercell dimensions for a target atom count",
        description=(
            "Trial diagonal or near-cubic supercell candidates from a POSCAR "
            "before using them in `esspy init --dim` or writing a trial POSCAR."
        ),
    )
    util_supercell.add_argument("poscar", help="Reference POSCAR path")
    util_supercell.add_argument(
        "--n-target-sites",
        type=int,
        required=True,
        help="Approximate desired atom/site count for the expanded supercell",
    )
    util_supercell.add_argument(
        "--mode",
        choices=("near_cubic", "axis_balanced"),
        default="near_cubic",
        help=(
            "near_cubic enumerates integer 3x3 matrices and scores atom-count error, "
            "length balance, and orthogonality; axis_balanced uses diagonal axis multipliers"
        ),
    )
    util_supercell.add_argument(
        "--tolerance",
        type=float,
        default=0.50,
        help="Allowed relative atom-count error window before shape scoring (default: 0.50)",
    )
    util_supercell.add_argument(
        "--top",
        type=int,
        default=10,
        help="Number of ranked candidates to show (default: 10)",
    )
    util_supercell.add_argument(
        "--max-axis",
        type=int,
        default=None,
        help="Optional maximum multiplier on any single axis",
    )
    util_supercell.add_argument(
        "--max-candidates",
        type=int,
        default=200000,
        help="Safety cap for near_cubic HNF matrix candidates (default: 200000)",
    )
    util_supercell.add_argument(
        "--out",
        default=None,
        help="POSCAR path to write the selected supercell structure (default: SPOSCAR for text output)",
    )
    util_supercell.add_argument(
        "--count-weight",
        type=float,
        default=50.0,
        help="Score weight for atom-count mismatch (default: 50.0)",
    )
    util_supercell.add_argument(
        "--length-weight",
        type=float,
        default=1.0,
        help="Score weight for length isotropy (default: 1.0)",
    )
    util_supercell.add_argument(
        "--angle-weight",
        type=float,
        default=None,
        help="Override angle orthogonality score weight",
    )
    util_supercell.add_argument("--json", action="store_true", help="Output JSON payload")
    util_supercell.set_defaults(handler=_handle_util_supercell, command_path="util supercell")

    util_ewald = util_sub.add_parser(
        "ewald",
        help="Compute Ewald energy directly from one or more POSCAR files",
    )
    util_ewald.add_argument(
        "-p",
        "--poscar",
        nargs="+",
        required=True,
        help="POSCAR path(s) or glob pattern(s), e.g. POSCAR-*",
    )
    util_ewald.add_argument(
        "--charge",
        action="append",
        default=None,
        help="Override oxidation as KIND=VALUE (repeatable), e.g. --charge Mn=2 --charge O=-2",
    )
    util_ewald.add_argument(
        "--charge-model",
        default=None,
        help="Read element or element-site charges from charge_model.json",
    )
    util_ewald.add_argument(
        "--rg-find-factor",
        type=int,
        default=None,
        help="Optional fixed RGFindFactor (default: auto-optimized)",
    )
    util_ewald.add_argument(
        "--chop-level",
        type=float,
        default=100,
        help="ChopLevel used for Ewald evaluation (default: 100)",
    )
    util_ewald.add_argument(
        "--json",
        action="store_true",
        help="Output JSON payload",
    )
    util_ewald.set_defaults(handler=_handle_util_ewald_deprecated, command_path="util ewald")

    # Phase 3 Utilities
    util_charges = util_sub.add_parser("suggest-charges", help="Lookup oxidation states for elements")
    util_charges.add_argument(
        "elements",
        nargs="*",
        help="Element symbols (e.g., Mn Ni Cr O). If omitted, shows all available."
    )
    util_charges.add_argument(
        "--json",
        action="store_true",
        help="Output in JSON format"
    )
    util_charges.set_defaults(handler=_handle_util_suggest_charges, command_path="util suggest-charges")

    util_templates = util_sub.add_parser("template-list", help="List available structure templates")
    util_templates.add_argument(
        "--json",
        action="store_true",
        help="Output in JSON format"
    )
    util_templates.set_defaults(handler=_handle_util_template_list, command_path="util template-list")

    util_random = util_sub.add_parser("random-structure", help="Generate random composition")
    util_random.add_argument(
        "--n-atoms",
        type=int,
        default=112,
        help="Target number of atoms (default: 112)"
    )
    util_random.add_argument(
        "--elements",
        type=str,
        default="Mn,Ni,Cr,O",
        help="Comma-separated element list (default: Mn,Ni,Cr,O)"
    )
    util_random.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Random seed for reproducibility"
    )
    util_random.add_argument(
        "--json",
        action="store_true",
        help="Output in JSON format"
    )
    util_random.set_defaults(handler=_handle_util_random_structure, command_path="util random-structure")

    _configure_top_level_command_help(subparsers)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    if argv is None:
        argv = sys.argv[1:]
    if not argv:
        parser.print_help()
        return 0

    args = parser.parse_args(argv)

    # Handle --version
    if args.version:
        from . import __version__
        print(__version__)
        return 0

    if args.command is None:
        parser.print_help()
        return 0

    handler: Handler | None = getattr(args, "handler", None)
    if handler is None:
        parser.error(f"Unknown command: {args.command}")
        return 2
    try:
        return handler(args, parser)
    except KeyboardInterrupt:
        print("Interrupted by user.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
    def _progress(message: str) -> None:
        if getattr(args, "quiet", False):
            return
        print(f"[fit-charge] {message}", file=sys.stderr, flush=True)
