from __future__ import annotations

from pathlib import Path

from .native import load_native_module


def parse_guider_text_file_native(path: str | Path):
    native = load_native_module()
    return native.parse_guider_text_file(str(path))


def parse_add_sites_monte_carlo_spec_native(path: str | Path):
    native = load_native_module()
    return native.parse_add_sites_monte_carlo_spec(str(path))


def parse_guider_text_to_guide_input_native(path: str | Path, base_dir: str | Path | None = None):
    native = load_native_module()
    resolved_base_dir = "" if base_dir is None else str(base_dir)
    return native.parse_guider_text_to_guide_input(str(path), resolved_base_dir)


def parse_guider_text_to_run_input_native(path: str | Path, base_dir: str | Path | None = None):
    native = load_native_module()
    resolved_base_dir = "" if base_dir is None else str(base_dir)
    return native.parse_guider_text_to_run_input(str(path), resolved_base_dir)
