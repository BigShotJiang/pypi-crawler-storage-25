from __future__ import annotations

import json
import copy
import re
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from .models import (
    CandidateWindowEntry,
    CompositionEntry,
    CompositionModel,
    EnergySummary,
    EnergyTable,
    FirstEnumerationState,
    GuideDiagnostics,
    GuideInput,
    GuideResult,
    Lattice,
    LocalEnumerationLoopState,
    LocalReductionSummary,
    ParallelRuntimeOptions,
    PrimarySliceWindow,
    ReadyAtom,
    ReadyModel,
    ReadyRecipe,
    ReadyRecipeModification,
    RecipeAssignment,
    RecipeSpec,
    RunInput,
    RunResult,
    SearchSpaceEntry,
    SearchSpaceSummary,
    Site,
    SolveInput,
    SolveOptions,
    SolveResult,
    StructureModel,
    StructureSnapshot,
    SymmetryModel,
    SymmetryOperation,
    WorkSliceRange,
    WorkSliceSummary,
    WindowEvaluationEntry,
    WindowEvaluationSummary,
)
from .native import load_native_module
from .config import load_run_input
from .add_sites_pipeline import (
    run_add_sites_from_solver_text,
    run_add_sites_from_solver_text_mpi,
)
from .add_sites_mc import (
    AddSitesMonteCarloOptions,
    AddSitesMonteCarloResult,
    AddSitesMonteCarloGlobalResult,
)
from .guide_poscar_writer import write_poscar_text
from .guide_ready_writer import ReadyFileWriteOptions, write_ready_file_text
from .guide_guider_writer import (
    GuiderTextWriteOptions,
    write_guider_text,
)


def structure_to_dict(structure: StructureModel) -> dict:
    return {
        "title": structure.title,
        "lattice": {
            "a": list(structure.lattice.a),
            "b": list(structure.lattice.b),
            "c": list(structure.lattice.c),
        },
        "sites": [
            {
                "kind": s.kind,
                "x": s.x,
                "y": s.y,
                "z": s.z,
                "oxidation": s.oxidation,
            }
            for s in structure.sites
        ],
        "fractional_coordinates": structure.fractional_coordinates,
    }


def structure_from_dict(data: dict) -> StructureModel:
    return StructureModel(
        title=data.get("title", ""),
        lattice=Lattice(
            a=tuple(data["lattice"]["a"]),
            b=tuple(data["lattice"]["b"]),
            c=tuple(data["lattice"]["c"]),
        ),
        sites=[
            Site(
                kind=s["kind"],
                x=s["x"],
                y=s["y"],
                z=s["z"],
                oxidation=s["oxidation"],
            )
            for s in data.get("sites", [])
        ],
        fractional_coordinates=data.get("fractional_coordinates", True),
    )


def _snapshot_from_dict(data: dict) -> StructureSnapshot:
    return StructureSnapshot(
        structure=structure_from_dict(data["structure"]),
        energy=data["energy"],
        label=data["label"],
    )


def _et_from_dict(d: dict) -> EnergyTable:
    return EnergyTable(
        count=d.get("count", 0),
        sum_e=d.get("sum_e", 0.0),
        sum_e2=d.get("sum_e2", 0.0),
        min_e=d.get("min_e", 0.0),
        max_e=d.get("max_e", 0.0),
    )


def _ready_result_from_dict(ready_data: dict) -> ReadyModel:
    return ReadyModel(
        lattice=Lattice(
            a=tuple(ready_data["lattice"]["a"]),
            b=tuple(ready_data["lattice"]["b"]),
            c=tuple(ready_data["lattice"]["c"]),
        ),
        atoms=[
            ReadyAtom(
                kind=a["kind"],
                oxidation=a["oxidation"],
                x=a["x"],
                y=a["y"],
                z=a["z"],
            )
            for a in ready_data["atoms"]
        ],
        poscar_species_counts=[
            CompositionEntry(kind=c["kind"], count=c["count"])
            for c in ready_data["poscar_species_counts"]
        ],
        supercell_expansion=tuple(ready_data["supercell_expansion"]),
        rg_find_factor=ready_data["rg_find_factor"],
        chop_level=ready_data.get("chop_level", 8.0),
        output_prefix=ready_data["output_prefix"],
        recipes=[
            ReadyRecipe(
                from_kind=r["from"],
                oxidation=r["oxidation"],
                random_pickup=r["random_pickup"],
                random_pickup_trial=r["random_pickup_trial"],
                modifications=[
                    ReadyRecipeModification(
                        to=m["to"], oxidation=m["oxidation"], count=m["count"]
                    )
                    for m in r["modifications"]
                ],
            )
            for r in ready_data["recipes"]
        ],
    )


def _guide_result_from_dict(data: dict) -> GuideResult:
    ready = _ready_result_from_dict(data["ready"])
    diag_data = data["diagnostics"]
    diagnostics = GuideDiagnostics(
        n_atom_config=diag_data["n_atom_config"],
        supercell_expansion=tuple(diag_data["supercell_expansion"]),
        rg_find_factor=diag_data["rg_find_factor"],
        resolved_assignments=[
            RecipeAssignment(
                from_kind=a["from"],
                assigned_counts=[
                    CompositionEntry(kind=c["kind"], count=c["count"])
                    for c in a["assigned_counts"]
                ],
            )
            for a in diag_data["resolved_assignments"]
        ],
        messages=list(diag_data["messages"]),
    )
    return GuideResult(ready=ready, diagnostics=diagnostics)


def _solve_result_from_dict(data: dict) -> SolveResult:
    summary = data.get("summary", {})
    search_space = data.get("search_space", {})

    eval_summary = EnergySummary(
        global_e_min=summary.get("global_e_min", 0.0),
        global_e_max=summary.get("global_e_max", 0.0),
        total_cpu_time=summary.get("total_cpu_time", 0.0),
        global_count_total=summary.get("global_count_total", 0),
    )

    ss_summary = SearchSpaceSummary(
        entries=[
            SearchSpaceEntry(
                from_kind=item["from"],
                random_pickup=item["random_pickup"],
                random_pickup_trial=item["random_pickup_trial"],
                unchanged_count=item["unchanged_count"],
                assigned_counts=[
                    CompositionEntry(kind=entry["kind"], count=entry["count"])
                    for entry in item["assigned_counts"]
                ],
                jobsize_u64=item.get("jobsize_u64", 0),
                jobsize_ld=item.get("jobsize_ld", 0.0),
                first_candidate_indices=list(item.get("first_candidate_indices", [])),
                first_candidate_labels=list(item.get("first_candidate_labels", [])),
                candidate_count_log10=item["candidate_count_log10"],
                jobsize_saturated=bool(item.get("jobsize_saturated", False)),
            )
            for item in search_space.get("entries", [])
        ],
        primary_recipe_index=search_space.get("primary_recipe_index", -1),
        total_candidate_count_log10=search_space.get(
            "total_candidate_count_log10", 0.0
        ),
        work_slice=WorkSliceSummary(
            integer_job=search_space.get("work_slice", {}).get("integer_job", True),
            primary_recipe_index=search_space.get("work_slice", {}).get(
                "primary_recipe_index", -1
            ),
            world_size=search_space.get("work_slice", {}).get("world_size", 1),
            rank=search_space.get("work_slice", {}).get("rank", 0),
            has_saturated_jobsize=bool(
                search_space.get("work_slice", {}).get("has_saturated_jobsize", False)
            ),
            recipe_ranges=[
                WorkSliceRange(
                    recipe_index=item["recipe_index"],
                    start=item["start"],
                    end=item["end"],
                )
                for item in search_space.get("work_slice", {}).get(
                    "recipe_ranges", []
                )
            ],
        ),
        first_enumeration=FirstEnumerationState(
            recipe_index=search_space.get("first_enumeration", {}).get(
                "recipe_index", -1
            ),
            candidate_index=search_space.get("first_enumeration", {}).get(
                "candidate_index", 0
            ),
            candidate_indices=list(
                search_space.get("first_enumeration", {}).get(
                    "candidate_indices", []
                )
            ),
            candidate_labels=list(
                search_space.get("first_enumeration", {}).get(
                    "candidate_labels", []
                )
            ),
        ),
        primary_slice_window=PrimarySliceWindow(
            recipe_index=search_space.get("primary_slice_window", {}).get(
                "recipe_index", -1
            ),
            start_index=search_space.get("primary_slice_window", {}).get(
                "start_index", 0
            ),
            end_index=search_space.get("primary_slice_window", {}).get(
                "end_index", 0
            ),
            available_count=search_space.get("primary_slice_window", {}).get(
                "available_count", 0
            ),
            decoded_count=search_space.get("primary_slice_window", {}).get(
                "decoded_count", 0
            ),
            requested_offset=search_space.get("primary_slice_window", {}).get(
                "requested_offset", 0
            ),
            next_offset=search_space.get("primary_slice_window", {}).get(
                "next_offset", 0
            ),
            has_more=search_space.get("primary_slice_window", {}).get("has_more", False),
            candidates=[
                CandidateWindowEntry(
                    candidate_index=item["candidate_index"],
                    candidate_indices=list(item.get("candidate_indices", [])),
                    candidate_labels=list(item.get("candidate_labels", [])),
                )
                for item in search_space.get("primary_slice_window", {}).get(
                    "candidates", []
                )
            ],
        ),
    )

    window_evaluation = data.get("window_evaluation", {})
    we_summary = WindowEvaluationSummary(
        recipe_index=window_evaluation.get("recipe_index", -1),
        local_e_min=window_evaluation.get("local_e_min", 0.0),
        local_e_max=window_evaluation.get("local_e_max", 0.0),
        local_best_candidate_index=window_evaluation.get(
            "local_best_candidate_index", 0
        ),
        local_worst_candidate_index=window_evaluation.get(
            "local_worst_candidate_index", 0
        ),
        local_count_total=window_evaluation.get("local_count_total", 0),
        entries=[
            WindowEvaluationEntry(
                candidate_index=item["candidate_index"],
                energy=item["energy"],
                candidate_indices=list(item.get("candidate_indices", [])),
                candidate_labels=list(item.get("candidate_labels", [])),
                snapshot=_snapshot_from_dict(item["snapshot"]) if item.get("snapshot") else None,
            )
            for item in window_evaluation.get("entries", [])
        ],
    )

    loop_state = data.get("local_enumeration_loop", {})
    enumeration_loop = LocalEnumerationLoopState(
        initial_offset=loop_state.get("initial_offset", 0),
        chunk_limit=loop_state.get("chunk_limit", 0),
        max_chunks=loop_state.get("max_chunks", 1),
        exhaust_all=loop_state.get("exhaust_all", False),
        processed_chunks=loop_state.get("processed_chunks", 0),
        processed_candidates=loop_state.get("processed_candidates", 0),
        next_offset=loop_state.get("next_offset", 0),
        has_more=loop_state.get("has_more", False),
    )

    reduction = data.get("local_reduction", {})
    local_reduction = LocalReductionSummary(
        rank=reduction.get("rank", 0),
        world_size=reduction.get("world_size", 1),
        primary_recipe_index=reduction.get("primary_recipe_index", -1),
        processed_chunks=reduction.get("processed_chunks", 0),
        processed_candidates=reduction.get("processed_candidates", 0),
        initial_offset=reduction.get("initial_offset", 0),
        next_offset=reduction.get("next_offset", 0),
        has_more=reduction.get("has_more", False),
        exhaust_all=reduction.get("exhaust_all", False),
        has_samples=reduction.get("has_samples", False),
        local_e_min=reduction.get("local_e_min", 0.0),
        local_e_max=reduction.get("local_e_max", 0.0),
        local_best_candidate_index=reduction.get("local_best_candidate_index", 0),
        local_worst_candidate_index=reduction.get("local_worst_candidate_index", 0),
        local_de_min_swap=reduction.get("local_de_min_swap", 0.0),
        local_swap_count=reduction.get("local_swap_count", 0),
        local_best_structure=structure_from_dict(reduction["local_best_structure"])
        if reduction.get("local_best_structure_present")
        else None,
        local_worst_structure=structure_from_dict(reduction["local_worst_structure"])
        if reduction.get("local_worst_structure_present")
        else None,
        local_best_structure_present=reduction.get(
            "local_best_structure_present", False
        ),
        local_worst_structure_present=reduction.get(
            "local_worst_structure_present", False
        ),
        local_energy_table=_et_from_dict(reduction.get("local_energy_table", {})),
    )

    return SolveResult(
        summary=eval_summary,
        search_space=ss_summary,
        window_evaluation=we_summary,
        local_enumeration_loop=enumeration_loop,
        local_reduction=local_reduction,
        best=_snapshot_from_dict(data["best"]) if data.get("best") else None,
        worst=_snapshot_from_dict(data["worst"]) if data.get("worst") else None,
        energy_table=_et_from_dict(data.get("energy_table", {})),
        messages=list(data.get("messages", [])),
    )


def _to_ready_payload(ready: ReadyModel | dict) -> dict:
    if is_dataclass(ready):
        payload = asdict(ready)
        # Fixup keys for C++ side if needed
        for recipe in payload["recipes"]:
            recipe["from"] = recipe.pop("from_kind")
        return payload
    return ready


def _format_float_precision(value: float, precision: int) -> float:
    return float(f"{float(value):.{precision}f}")


def ready_with_legacy_text_precision(ready: ReadyModel) -> ReadyModel:
    """Return a ReadyModel matching the precision consumed by legacy ESS.

    The original C++ workflow writes an intermediate ready text file and then
    solves from that file.  That text stores lattice vectors and fractional
    coordinates at 10 decimals and oxidation states at 3 decimals.  The Python
    workflow keeps the in-memory ReadyModel, so without this normalization the
    modern path can use slightly different charges than the legacy binary.
    """

    rounded = copy.deepcopy(ready)
    rounded.lattice = Lattice(
        a=tuple(_format_float_precision(v, 10) for v in rounded.lattice.a),
        b=tuple(_format_float_precision(v, 10) for v in rounded.lattice.b),
        c=tuple(_format_float_precision(v, 10) for v in rounded.lattice.c),
    )
    for atom in rounded.atoms:
        atom.oxidation = _format_float_precision(atom.oxidation, 3)
        atom.x = _format_float_precision(atom.x, 10)
        atom.y = _format_float_precision(atom.y, 10)
        atom.z = _format_float_precision(atom.z, 10)
    for recipe in rounded.recipes:
        recipe.oxidation = _format_float_precision(recipe.oxidation, 3)
        for modification in recipe.modifications:
            modification.oxidation = _format_float_precision(
                modification.oxidation, 3
            )
    return rounded


def run(input: RunInput | dict) -> RunResult:
    native = load_native_module()

    if is_dataclass(input):
        payload = asdict(input)
        # Fixup keys
        payload["guide"]["structure"] = structure_to_dict(input.guide.structure)
        for recipe in payload["guide"]["recipes"]:
            recipe["from"] = recipe.pop("from_kind")
    else:
        payload = input

    data = native.run(payload)

    solve_result = _solve_result_from_dict(data["solve"])

    return RunResult(
        guide=_guide_result_from_dict(data["guide"]),
        solve=solve_result,
    )


def solve(input: SolveInput | dict, progress_callback=None, *, force_serial: bool = False) -> SolveResult:
    native = load_native_module()

    if is_dataclass(input):
        payload = asdict(input)
        payload["ready"] = _to_ready_payload(input.ready)
        runtime = input.runtime
    else:
        payload = input
        runtime_data = payload.get("runtime", {})
        runtime = ParallelRuntimeOptions(
            use_mpi=runtime_data.get("use_mpi", False),
            world_size=runtime_data.get("world_size", 1),
            rank=runtime_data.get("rank", 0),
        )
    if progress_callback is not None:
        payload.setdefault("options", {})
        payload["options"]["progress_callback"] = progress_callback

    if force_serial:
        payload.setdefault("runtime", {})
        payload["runtime"]["use_mpi"] = False
        payload["runtime"]["rank"] = 0
        payload["runtime"]["world_size"] = 1
        payload.setdefault("options", {})
        payload["options"]["mpi_adaptive_stride_sync"] = False
        payload["options"]["mpi_dynamic_chunking"] = False
        data = native.solve(payload)
        return _solve_result_from_dict(data)

    # MPI auto-detection logic:
    # - If launched under mpirun (COMM_WORLD size > 1), use MPI path.
    # - Otherwise, fall back to serial.
    # `runtime.use_mpi` remains a compatibility hint, but no longer required.
    try:
        from mpi4py import MPI
    except ImportError:
        data = native.solve(payload)
        return _solve_result_from_dict(data)

    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    if size <= 1:
        data = native.solve(payload)
        return _solve_result_from_dict(data)

    # Keep Python orchestration minimal: delegate rank partitioning and most
    # control-flow decisions to native C++/MPI. This mirrors legacy ESS design
    # where each rank receives its work slice inside the core solver.
    payload.setdefault("options", {})
    payload["options"]["enumeration_save_memory"] = True
    if int(payload["options"].get("running_index_delta", 10000)) < 0:
        # Use native MPI adaptive-stride synchronization inside the C++ solve
        # loop (rank-0 decides, MPI_Bcast in-loop) to match legacy ESS
        # behavior and avoid Python-side rank0 pre-calibration bottlenecks.
        payload["options"]["mpi_adaptive_stride_sync"] = True
    payload.setdefault("runtime", {})
    payload["runtime"]["rank"] = rank
    payload["runtime"]["world_size"] = size
    
    try:
        # Each rank solves its slice
        data = native.solve(payload)
        local_summary = data["local_reduction"]
        local_summary["rank"] = rank
        local_summary["world_size"] = size
    except KeyboardInterrupt:
        # Ensure all ranks terminate together in MPI runs.
        try:
            comm.Abort(130)
        except Exception:
            pass
        raise
    
    # Legacy ESS uses MPI_Allgather for scalar extrema / swap counters only.
    # Do not allgather full Python dictionaries containing structure snapshots.
    from .solve_global_reduction import (
        combine_local_reduction_scalars,
        extract_local_reduction_scalars,
    )

    local_scalars = asdict(extract_local_reduction_scalars(local_summary))
    try:
        all_scalars = comm.allgather(local_scalars)
    except KeyboardInterrupt:
        try:
            comm.Abort(130)
        except Exception:
            pass
        raise
    global_summary = combine_local_reduction_scalars(all_scalars)
    mpi_stats = _compute_mpi_stats(all_scalars)
    mpi_stats["global_swap_count"] = global_summary.global_swap_count
    mpi_stats["global_de_min_swap"] = global_summary.global_de_min_swap

    local_best_structure = (
        local_summary.get("local_best_structure")
        if local_summary.get("local_best_structure_present")
        else None
    )
    local_worst_structure = (
        local_summary.get("local_worst_structure")
        if local_summary.get("local_worst_structure_present")
        else None
    )
    # Fallback: some native payloads may omit local_*_structure fields in the
    # local_reduction block while still returning top-level best/worst snapshots.
    # Use those snapshots for owner-rank broadcast so rank 0 can always emit
    # best/worst POSCAR outputs in MPI runs.
    if local_best_structure is None:
        best_snapshot = data.get("best") if isinstance(data, dict) else None
        if isinstance(best_snapshot, dict):
            local_best_structure = best_snapshot.get("structure")
    if local_worst_structure is None:
        worst_snapshot = data.get("worst") if isinstance(data, dict) else None
        if isinstance(worst_snapshot, dict):
            local_worst_structure = worst_snapshot.get("structure")
    best_owner = global_summary.which_rank_global_e_min
    worst_owner = global_summary.which_rank_global_e_max
    # Use allgather instead of owner-root bcast for structure handoff.
    # This avoids communicator root/payload mismatches and is robust even if
    # native adaptive MPI sync performed extra internal collectives.
    structures_by_rank = comm.allgather(
        {
            "best": local_best_structure,
            "worst": local_worst_structure,
        }
    )
    global_best_structure = None
    global_worst_structure = None
    if 0 <= best_owner < len(structures_by_rank):
        global_best_structure = structures_by_rank[best_owner].get("best")
    if 0 <= worst_owner < len(structures_by_rank):
        global_worst_structure = structures_by_rank[worst_owner].get("worst")
    
    # Update data with global summary
    # We replace data["solve"]["summary"] etc with global values
    # Actually, we can just build a SolveResult manually from global_summary
    
    # Reconstruct SolveResult
    # Map GlobalReductionSummary back to SolveResult structure
    solve_result = _solve_result_from_dict(data)
    
    # Update summary fields from global_summary
    solve_result.summary.global_e_min = global_summary.global_e_min
    solve_result.summary.global_e_max = global_summary.global_e_max
    solve_result.summary.global_count_total = global_summary.total_processed_candidates
    
    # Update best/worst from global_summary
    if global_summary.global_best_structure_present and global_best_structure:
        solve_result.best = StructureSnapshot(
            structure=structure_from_dict(global_best_structure),
            energy=global_summary.global_e_min,
            label=f"rank{global_summary.which_rank_global_e_min}_idx{global_summary.global_e_min_candidate_index}"
        )
    
    if global_summary.global_worst_structure_present and global_worst_structure:
        solve_result.worst = StructureSnapshot(
            structure=structure_from_dict(global_worst_structure),
            energy=global_summary.global_e_max,
            label=f"rank{global_summary.which_rank_global_e_max}_idx{global_summary.global_e_max_candidate_index}"
        )
    
    solve_result.energy_table = global_summary.global_energy_table
    solve_result.mpi_stats = mpi_stats
    
    # We might want to sum up cpu time too
    # solve_result.summary.total_cpu_time = comm.reduce(solve_result.summary.total_cpu_time, op=MPI.SUM)
    # But total_cpu_time is usually reported per rank or as walltime.
    # Let's just keep it as is for now.

    return solve_result


def guide(input: GuideInput | dict) -> GuideResult:
    native = load_native_module()
    if is_dataclass(input):
        payload = asdict(input)
        payload["structure"] = structure_to_dict(input.structure)
        for recipe in payload["recipes"]:
            recipe["from"] = recipe.pop("from_kind")
    else:
        payload = input
    data = native.guide(payload)
    return _guide_result_from_dict(data)


def _extract_adaptive_strides(messages: list[str]) -> dict[int, int]:
    pattern = re.compile(
        r"adaptive_running_index_update monitoring=(?P<monitoring>\d+) "
        r"stride=(?P<stride>\d+)"
    )
    result: dict[int, int] = {}
    for message in messages:
        match = pattern.search(message)
        if not match:
            continue
        result[int(match.group("monitoring"))] = int(match.group("stride"))
    return result


def _compute_mpi_stats(all_scalars: list[dict]) -> dict[str, object]:
    if not all_scalars:
        return {}
    processed_by_rank: list[dict[str, int]] = []
    processed_values: list[int] = []
    for payload in all_scalars:
        rank = int(payload.get("rank", 0))
        processed = int(payload.get("processed_candidates", 0))
        processed_by_rank.append({"rank": rank, "processed_candidates": processed})
        processed_values.append(processed)
    total = int(sum(processed_values))
    world_size = len(processed_values)
    min_processed = int(min(processed_values))
    max_processed = int(max(processed_values))
    avg_processed = float(total) / float(world_size) if world_size > 0 else 0.0
    idle_ranks = int(sum(1 for value in processed_values if value == 0))
    imbalance_ratio = (
        float(max_processed) / float(avg_processed)
        if avg_processed > 0.0
        else 0.0
    )
    return {
        "world_size": world_size,
        "total_processed_candidates": total,
        "min_processed_candidates": min_processed,
        "max_processed_candidates": max_processed,
        "avg_processed_candidates": avg_processed,
        "idle_ranks": idle_ranks,
        "active_ranks": int(world_size - idle_ranks),
        "imbalance_ratio_max_over_avg": imbalance_ratio,
        "processed_by_rank": processed_by_rank,
    }


class ESSWorkflow:
    def __init__(self, run_input: RunInput):
        self.run_input = run_input
        self.config = run_input

    @classmethod
    def from_yaml(cls, path: str) -> "ESSWorkflow":
        return cls(load_run_input(path))

    def prepare(self) -> RunInput:
        return self.run_input

    def guide(self) -> GuideResult:
        return guide(self.run_input.guide)

    def solve(self, ready: ReadyModel | None = None) -> SolveResult:
        if ready is None:
            ready = self.guide().ready
        ready = ready_with_legacy_text_precision(ready)
        return solve(
            SolveInput(
                ready=ready,
                options=self.run_input.solve,
                runtime=self.run_input.runtime,
            )
        )

    def collect(self) -> RunResult:
        return self.run()

    def run(self) -> RunResult:
        return run(self.run_input)

    def export_ready_text(
        self,
        options: ReadyFileWriteOptions | dict | None = None,
        out: str | Path | None = None,
    ) -> str:
        text = write_ready_file_text(self.guide().ready, options)
        if out is not None:
            Path(out).write_text(text)
        return text

    def export_poscar_text(self, out: str | Path | None = None) -> str:
        text = write_poscar_text(self.guide().ready)
        if out is not None:
            Path(out).write_text(text)
        return text

    def export_guider_text(
        self,
        options: GuiderTextWriteOptions | None = None,
        out: str | Path | None = None,
    ) -> str:
        text = write_guider_text(self.run_input.guide, options)
        if out is not None:
            Path(out).write_text(text)
        return text

    @staticmethod
    def run_add_sites(
        solver_text_path: str,
        poscar_path: str,
        *,
        options: AddSitesMonteCarloOptions | dict | None = None,
        wyc_path: str | None = None,
        space_group: int = 1,
        charges_by_kind: dict[str, float] | None = None,
    ) -> AddSitesMonteCarloResult:
        return run_add_sites_from_solver_text(
            solver_text_path,
            poscar_path,
            options=options,
            wyc_path=wyc_path,
            space_group=space_group,
            charges_by_kind=charges_by_kind,
        )

    @staticmethod
    def run_add_sites_mpi(
        solver_text_path: str,
        poscar_path: str,
        *,
        options: AddSitesMonteCarloOptions | dict | None = None,
        wyc_path: str | None = None,
        space_group: int = 1,
        charges_by_kind: dict[str, float] | None = None,
        use_mpi: bool = True,
        comm=None,
    ) -> AddSitesMonteCarloGlobalResult:
        return run_add_sites_from_solver_text_mpi(
            solver_text_path,
            poscar_path,
            options=options,
            wyc_path=wyc_path,
            space_group=space_group,
            charges_by_kind=charges_by_kind,
            use_mpi=use_mpi,
            comm=comm,
        )
