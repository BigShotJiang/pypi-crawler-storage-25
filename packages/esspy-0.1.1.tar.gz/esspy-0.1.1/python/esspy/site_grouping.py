from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
import hashlib
import json
from typing import Any, Literal

from .models import StructureModel


SiteGroupingMode = Literal["element", "poscar_kind", "element_wyckoff"]


@dataclass
class SiteGroupingOptions:
    mode: SiteGroupingMode = "poscar_kind"
    symprec: float = 0.1
    angle_tolerance: float = 5.0
    fallback: str = "poscar_kind"
    strict: bool = False


@dataclass
class SiteGroupSpec:
    name: str
    source_kind: str
    count: int
    site_indices: list[int]
    allowed: list[str]
    label: dict[str, Any] = field(default_factory=dict)
    symmetry: dict[str, Any] = field(default_factory=dict)


@dataclass
class SiteGroupingResult:
    mode: str
    groups: list[SiteGroupSpec]
    metadata: dict[str, Any]
    warnings: list[str] = field(default_factory=list)
    fallback_used: bool = False


@dataclass
class SiteGroupValidationResult:
    explicit_index_mode: bool
    base_group_by_site: dict[int, str]
    source_kind_to_groups: dict[str, list[str]]


def _structure_species_counts(structure: StructureModel) -> dict[str, int]:
    counts: dict[str, int] = {}
    for site in structure.sites:
        counts[str(site.kind)] = int(counts.get(str(site.kind), 0)) + 1
    return counts


def structure_site_fingerprint(
    structure: StructureModel,
    *,
    ndigits: int = 8,
) -> str:
    """Return a stable fingerprint for base-site membership validation."""

    payload = {
        "fractional_coordinates": bool(structure.fractional_coordinates),
        "lattice": [
            [round(float(value), ndigits) for value in structure.lattice.a],
            [round(float(value), ndigits) for value in structure.lattice.b],
            [round(float(value), ndigits) for value in structure.lattice.c],
        ],
        "sites": [
            [
                str(site.kind),
                round(float(site.x), ndigits),
                round(float(site.y), ndigits),
                round(float(site.z), ndigits),
            ]
            for site in structure.sites
        ],
    }
    data = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _base_metadata(
    structure: StructureModel,
    options: SiteGroupingOptions,
    *,
    mode: str,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "mode": mode,
        "symprec": float(options.symprec),
        "angle_tolerance": float(options.angle_tolerance),
        "fallback": str(options.fallback),
        "source": {
            "n_sites": int(len(structure.sites)),
            "species_counts": _structure_species_counts(structure),
            "coordinate_mode": "direct"
            if structure.fractional_coordinates
            else "cartesian",
            "structure_fingerprint": structure_site_fingerprint(structure),
        },
    }
    if extra:
        metadata.update(extra)
    return metadata


def detect_poscar_kind_groups(
    structure: StructureModel,
    element_mapping: dict[str, list[str]],
    options: SiteGroupingOptions | None = None,
    *,
    mode: str = "poscar_kind",
) -> SiteGroupingResult:
    options = options or SiteGroupingOptions(mode="poscar_kind")
    indices_by_kind: "OrderedDict[str, list[int]]" = OrderedDict()
    for index, site in enumerate(structure.sites):
        indices_by_kind.setdefault(str(site.kind), []).append(int(index))

    groups: list[SiteGroupSpec] = []
    for group_index, (source_kind, indices) in enumerate(indices_by_kind.items(), 1):
        groups.append(
            SiteGroupSpec(
                name=f"site{group_index}",
                source_kind=source_kind,
                count=len(indices),
                site_indices=list(indices),
                allowed=list(element_mapping.get(source_kind, [source_kind])),
                label={
                    "display": source_kind,
                    "element": source_kind,
                },
            )
        )

    return SiteGroupingResult(
        mode=mode,
        groups=groups,
        metadata=_base_metadata(structure, options, mode=mode),
    )


def _spglib_cell(structure: StructureModel):
    lattice = [
        list(structure.lattice.a),
        list(structure.lattice.b),
        list(structure.lattice.c),
    ]
    positions = [[site.x, site.y, site.z] for site in structure.sites]
    kind_to_index: dict[str, int] = {}
    numbers: list[int] = []
    next_index = 1
    for site in structure.sites:
        kind = str(site.kind)
        if kind not in kind_to_index:
            kind_to_index[kind] = next_index
            next_index += 1
        numbers.append(kind_to_index[kind])
    return lattice, positions, numbers


def _dataset_value(dataset: Any, key: str) -> Any:
    if hasattr(dataset, key):
        return getattr(dataset, key)
    return dataset[key]


def _optional_dataset_value(dataset: Any, key: str) -> Any | None:
    if hasattr(dataset, key):
        return getattr(dataset, key)
    try:
        return dataset[key]
    except Exception:
        return None


def _detect_spglib_site_metadata(
    structure: StructureModel,
    options: SiteGroupingOptions,
) -> dict[str, Any]:
    try:
        import spglib  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "spglib is not installed. Install with `pip install spglib`."
        ) from exc

    dataset = spglib.get_symmetry_dataset(
        _spglib_cell(structure),
        symprec=float(options.symprec),
        angle_tolerance=float(options.angle_tolerance),
    )
    if dataset is None:
        raise RuntimeError("spglib.get_symmetry_dataset returned None")

    n_sites = len(structure.sites)
    wyckoffs = list(_dataset_value(dataset, "wyckoffs"))
    site_syms = list(_dataset_value(dataset, "site_symmetry_symbols"))
    equivalent_atoms = [int(value) for value in _dataset_value(dataset, "equivalent_atoms")]
    crystallographic_orbits_raw = _optional_dataset_value(
        dataset,
        "crystallographic_orbits",
    )
    crystallographic_orbits = (
        [int(value) for value in crystallographic_orbits_raw]
        if crystallographic_orbits_raw is not None
        else None
    )
    if len(wyckoffs) != n_sites:
        raise RuntimeError("spglib wyckoff array length does not match POSCAR sites")
    if len(site_syms) != n_sites:
        raise RuntimeError("spglib site-symmetry array length does not match POSCAR sites")
    if len(equivalent_atoms) != n_sites:
        raise RuntimeError("spglib equivalent-atom array length does not match POSCAR sites")
    if crystallographic_orbits is not None and len(crystallographic_orbits) != n_sites:
        raise RuntimeError(
            "spglib crystallographic-orbit array length does not match POSCAR sites"
        )

    return {
        "space_group": int(_dataset_value(dataset, "number")),
        "international": str(_dataset_value(dataset, "international")),
        "wyckoffs": [str(value) for value in wyckoffs],
        "site_symmetry_symbols": [str(value) for value in site_syms],
        "equivalent_atoms": equivalent_atoms,
        "crystallographic_orbits": crystallographic_orbits,
    }


def detect_element_wyckoff_groups(
    structure: StructureModel,
    element_mapping: dict[str, list[str]],
    options: SiteGroupingOptions | None = None,
) -> SiteGroupingResult:
    options = options or SiteGroupingOptions(mode="element_wyckoff")
    metadata = _detect_spglib_site_metadata(structure, options)
    wyckoffs = metadata["wyckoffs"]
    site_syms = metadata["site_symmetry_symbols"]
    equivalent_atoms = metadata["equivalent_atoms"]
    crystallographic_orbits = metadata.get("crystallographic_orbits")

    groups_by_key: "OrderedDict[tuple[str, int, str, str], list[int]]" = OrderedDict()
    for index, site in enumerate(structure.sites):
        orbit = (
            int(crystallographic_orbits[index])
            if crystallographic_orbits is not None
            else int(equivalent_atoms[index])
        )
        key = (
            str(site.kind),
            orbit,
            str(wyckoffs[index]),
            str(site_syms[index]),
        )
        groups_by_key.setdefault(key, []).append(int(index))

    groups: list[SiteGroupSpec] = []
    for group_index, ((source_kind, orbit, wyckoff, site_sym), indices) in enumerate(
        groups_by_key.items(),
        1,
    ):
        representative = indices[0]
        groups.append(
            SiteGroupSpec(
                name=f"site{group_index}",
                source_kind=source_kind,
                count=len(indices),
                site_indices=list(indices),
                allowed=list(element_mapping.get(source_kind, [source_kind])),
                label={
                    "display": f"{source_kind}@{wyckoff}",
                    "element": source_kind,
                    "wyckoff": wyckoff,
                    "role": None,
                },
                symmetry={
                    "backend": "spglib",
                    "space_group": int(metadata["space_group"]),
                    "international": str(metadata["international"]),
                    "wyckoff": wyckoff,
                    "site_symmetry": site_sym,
                    "equivalent_atom": int(equivalent_atoms[representative]),
                    "crystallographic_orbit": orbit,
                },
            )
        )

    return SiteGroupingResult(
        mode="element_wyckoff",
        groups=groups,
        metadata=_base_metadata(
            structure,
            options,
            mode="element_wyckoff",
            extra={
                "backend": "spglib",
                "space_group": int(metadata["space_group"]),
                "international": str(metadata["international"]),
            },
        ),
    )


def detect_site_groups(
    structure: StructureModel,
    element_mapping: dict[str, list[str]],
    options: SiteGroupingOptions,
) -> SiteGroupingResult:
    if options.mode == "element":
        return detect_poscar_kind_groups(
            structure,
            element_mapping,
            options,
            mode="element",
        )
    if options.mode == "poscar_kind":
        return detect_poscar_kind_groups(
            structure,
            element_mapping,
            options,
            mode="poscar_kind",
        )
    if options.mode != "element_wyckoff":
        raise ValueError(
            "site grouping mode must be element, poscar_kind, or element_wyckoff"
        )

    try:
        return detect_element_wyckoff_groups(structure, element_mapping, options)
    except Exception as exc:
        if options.strict:
            raise
        if options.fallback not in {"element", "poscar_kind"}:
            raise
        fallback_options = SiteGroupingOptions(
            mode=options.fallback,  # type: ignore[arg-type]
            symprec=options.symprec,
            angle_tolerance=options.angle_tolerance,
            fallback=options.fallback,
            strict=False,
        )
        result = detect_poscar_kind_groups(
            structure,
            element_mapping,
            fallback_options,
            mode=options.fallback,
        )
        result.fallback_used = True
        result.warnings.append(
            f"element_wyckoff grouping failed ({exc}); fell back to {options.fallback}"
        )
        result.metadata["requested_mode"] = "element_wyckoff"
        result.metadata["fallback_used"] = True
        result.metadata["fallback_reason"] = str(exc)
        return result


def site_group_specs_to_yaml(groups: list[SiteGroupSpec]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for group in groups:
        node: dict[str, Any] = {
            "source_kind": group.source_kind,
            "count": int(group.count),
            "site_indices": [int(index) for index in group.site_indices],
            "allowed": list(group.allowed),
        }
        if group.label:
            node["label"] = dict(group.label)
        if group.symmetry:
            node["symmetry"] = dict(group.symmetry)
        out[group.name] = node
    return out


def site_grouping_result_to_yaml(result: SiteGroupingResult) -> dict[str, Any]:
    return {
        "site_grouping": dict(result.metadata),
        "site_groups": site_group_specs_to_yaml(result.groups),
    }


def _parse_site_index(raw: Any, context: str) -> int:
    if isinstance(raw, bool):
        raise ValueError(f"`{context}` must be an integer site index")
    try:
        as_float = float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"`{context}` must be an integer site index") from exc
    as_int = int(as_float)
    if as_float != as_int:
        raise ValueError(f"`{context}` must be an integer site index")
    return as_int


def _parse_optional_count(raw: Any, context: str) -> int | None:
    if raw is None:
        return None
    if isinstance(raw, bool):
        raise ValueError(f"`{context}` must be a non-negative integer")
    try:
        as_float = float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"`{context}` must be a non-negative integer") from exc
    as_int = int(as_float)
    if as_float != as_int or as_int < 0:
        raise ValueError(f"`{context}` must be a non-negative integer")
    return as_int


def validate_site_groups_contract(
    structure: StructureModel,
    site_groups: Any,
    site_grouping: Any | None = None,
    *,
    n_target_sites: int | None = None,
) -> SiteGroupValidationResult:
    """Validate explicit site-group membership against the loaded structure.

    `site_indices` are 0-based indices into the POSCAR/base structure order.
    If any group defines explicit indices, every group must define them.
    Without explicit indices, each `source_kind` may appear in only one group.
    """

    if site_groups is None:
        return SiteGroupValidationResult(
            explicit_index_mode=False,
            base_group_by_site={},
            source_kind_to_groups={},
        )
    if not isinstance(site_groups, dict):
        raise ValueError("`site_groups` must be a mapping")

    if isinstance(site_grouping, dict):
        source = site_grouping.get("source")
        if isinstance(source, dict) and source.get("structure_fingerprint"):
            expected = str(source["structure_fingerprint"])
            actual = structure_site_fingerprint(structure)
            if expected != actual:
                raise ValueError(
                    "`site_grouping.source.structure_fingerprint` does not match "
                    "the loaded structure"
                )

    n_sites = len(structure.sites)
    actual_indices_by_kind: dict[str, list[int]] = {}
    for index, site in enumerate(structure.sites):
        actual_indices_by_kind.setdefault(str(site.kind), []).append(index)

    parsed: dict[str, dict[str, Any]] = {}
    source_kind_to_groups: dict[str, list[str]] = {}
    any_explicit_indices = False
    for raw_group_name, raw_info in site_groups.items():
        group_name = str(raw_group_name)
        if not isinstance(raw_info, dict):
            raise ValueError(f"`site_groups.{group_name}` must be a mapping")
        source_kind = raw_info.get("source_kind")
        if source_kind is None:
            raise ValueError(f"`site_groups.{group_name}.source_kind` is required")
        source_kind = str(source_kind)
        if source_kind not in actual_indices_by_kind:
            raise ValueError(
                f"`site_groups.{group_name}.source_kind` ({source_kind}) "
                "does not exist in the loaded structure"
            )
        has_indices = "site_indices" in raw_info
        any_explicit_indices = any_explicit_indices or has_indices
        count = _parse_optional_count(
            raw_info.get("count"), f"site_groups.{group_name}.count"
        )
        parsed[group_name] = {
            "source_kind": source_kind,
            "has_indices": has_indices,
            "raw_indices": raw_info.get("site_indices"),
            "count": count,
        }
        source_kind_to_groups.setdefault(source_kind, []).append(group_name)

    base_group_by_site: dict[int, str] = {}
    if any_explicit_indices:
        for group_name, info in parsed.items():
            if not info["has_indices"]:
                raise ValueError(
                    f"`site_groups.{group_name}.site_indices` is required when "
                    "any site group uses explicit indices"
                )
            raw_indices = info["raw_indices"]
            if not isinstance(raw_indices, list):
                raise ValueError(f"`site_groups.{group_name}.site_indices` must be a list")
            indices = [
                _parse_site_index(raw, f"site_groups.{group_name}.site_indices[{idx}]")
                for idx, raw in enumerate(raw_indices)
            ]
            if len(indices) != len(set(indices)):
                raise ValueError(
                    f"`site_groups.{group_name}.site_indices` contains duplicate indices"
                )
            count = info["count"]
            if count is not None and count != len(indices):
                raise ValueError(
                    f"`site_groups.{group_name}.count` ({count}) does not match "
                    f"`site_indices` length ({len(indices)})"
                )
            source_kind = str(info["source_kind"])
            for index in indices:
                if index < 0 or index >= n_sites:
                    raise ValueError(
                        f"`site_groups.{group_name}.site_indices` contains out-of-range "
                        f"index {index} for {n_sites} sites"
                    )
                actual_kind = str(structure.sites[index].kind)
                if actual_kind != source_kind:
                    raise ValueError(
                        f"`site_groups.{group_name}.site_indices` contains site {index} "
                        f"with kind {actual_kind}, expected {source_kind}"
                    )
                previous = base_group_by_site.get(index)
                if previous is not None:
                    raise ValueError(
                        f"`site_groups.{group_name}.site_indices` overlaps with "
                        f"`site_groups.{previous}` at site index {index}"
                    )
                base_group_by_site[index] = group_name

        for source_kind, group_names in source_kind_to_groups.items():
            expected = set(actual_indices_by_kind[source_kind])
            observed = {
                index
                for index, group_name in base_group_by_site.items()
                if group_name in group_names
            }
            if observed != expected:
                missing = sorted(expected - observed)
                extra = sorted(observed - expected)
                details: list[str] = []
                if missing:
                    details.append(f"missing={format_index_ranges(missing)}")
                if extra:
                    details.append(f"extra={format_index_ranges(extra)}")
                detail_text = "; ".join(details) if details else "partition mismatch"
                raise ValueError(
                    f"`site_groups` explicit indices for source_kind `{source_kind}` "
                    f"do not partition the loaded structure sites ({detail_text})"
                )
    else:
        for source_kind, group_names in source_kind_to_groups.items():
            if len(group_names) > 1:
                raise ValueError(
                    f"duplicate `site_groups` source_kind `{source_kind}` requires "
                    "explicit `site_indices`"
                )
            group_name = group_names[0]
            expected_count = len(actual_indices_by_kind[source_kind])
            count = parsed[group_name]["count"]
            accepted_counts = {expected_count}
            if n_target_sites is not None:
                base_total = len(structure.sites)
                if base_total > 0 and int(n_target_sites) % base_total == 0:
                    accepted_counts.add(
                        expected_count * (int(n_target_sites) // base_total)
                    )
            if count is not None and count not in accepted_counts:
                expected_text = (
                    str(expected_count)
                    if len(accepted_counts) == 1
                    else " or ".join(str(v) for v in sorted(accepted_counts))
                )
                raise ValueError(
                    f"`site_groups.{group_name}.count` ({count}) does not match "
                    f"the loaded/base or target-scaled structure count for "
                    f"`{source_kind}` ({expected_text})"
                )
            for index in actual_indices_by_kind[source_kind]:
                base_group_by_site[index] = group_name

    return SiteGroupValidationResult(
        explicit_index_mode=any_explicit_indices,
        base_group_by_site=base_group_by_site,
        source_kind_to_groups=source_kind_to_groups,
    )


def format_index_ranges(indices: list[int]) -> str:
    if not indices:
        return "(none)"
    ordered = sorted(int(index) for index in indices)
    ranges: list[str] = []
    start = previous = ordered[0]
    for value in ordered[1:]:
        if value == previous + 1:
            previous = value
            continue
        ranges.append(f"{start}" if start == previous else f"{start}..{previous}")
        start = previous = value
    ranges.append(f"{start}" if start == previous else f"{start}..{previous}")
    return ",".join(ranges)
