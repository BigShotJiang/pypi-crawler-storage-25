from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

from .models import Lattice, Site, StructureModel


Vector3 = tuple[float, float, float]
Matrix3i = tuple[tuple[int, int, int], tuple[int, int, int], tuple[int, int, int]]


@dataclass(frozen=True)
class SupercellCandidate:
    dim: tuple[int, int, int]
    matrix: Matrix3i
    determinant: int
    n_atoms: int
    score: float
    count_error: float
    length_score: float
    angle_score: float
    lengths: tuple[float, float, float]
    angles_deg: tuple[float, float, float]


@dataclass(frozen=True)
class SupercellSearchResult:
    mode: str
    n_base_atoms: int
    n_target_atoms: int
    selected: SupercellCandidate
    candidates: list[SupercellCandidate]


def _vec_scale(value: Vector3, scale: int) -> Vector3:
    return (
        float(value[0]) * float(scale),
        float(value[1]) * float(scale),
        float(value[2]) * float(scale),
    )


def _vec_linear(
    x: int,
    y: int,
    z: int,
    a: Vector3,
    b: Vector3,
    c: Vector3,
) -> Vector3:
    return (
        float(x) * float(a[0]) + float(y) * float(b[0]) + float(z) * float(c[0]),
        float(x) * float(a[1]) + float(y) * float(b[1]) + float(z) * float(c[1]),
        float(x) * float(a[2]) + float(y) * float(b[2]) + float(z) * float(c[2]),
    )


def _det3(matrix: Matrix3i) -> int:
    a, b, c = matrix
    return int(
        a[0] * (b[1] * c[2] - b[2] * c[1])
        - a[1] * (b[0] * c[2] - b[2] * c[0])
        + a[2] * (b[0] * c[1] - b[1] * c[0])
    )


def _inverse3_float(matrix: Matrix3i) -> tuple[Vector3, Vector3, Vector3]:
    det = float(_det3(matrix))
    if abs(det) <= 1.0e-12:
        raise ValueError("supercell matrix is singular")
    a, b, c = matrix
    return (
        (
            (b[1] * c[2] - b[2] * c[1]) / det,
            (a[2] * c[1] - a[1] * c[2]) / det,
            (a[1] * b[2] - a[2] * b[1]) / det,
        ),
        (
            (b[2] * c[0] - b[0] * c[2]) / det,
            (a[0] * c[2] - a[2] * c[0]) / det,
            (a[2] * b[0] - a[0] * b[2]) / det,
        ),
        (
            (b[0] * c[1] - b[1] * c[0]) / det,
            (a[1] * c[0] - a[0] * c[1]) / det,
            (a[0] * b[1] - a[1] * b[0]) / det,
        ),
    )


def _row_times_matrix(row: Vector3, matrix: tuple[Vector3, Vector3, Vector3]) -> Vector3:
    return (
        row[0] * matrix[0][0] + row[1] * matrix[1][0] + row[2] * matrix[2][0],
        row[0] * matrix[0][1] + row[1] * matrix[1][1] + row[2] * matrix[2][1],
        row[0] * matrix[0][2] + row[1] * matrix[1][2] + row[2] * matrix[2][2],
    )


def _reduced_matrix_for_lattice(lattice: Lattice, matrix: Matrix3i) -> Matrix3i:
    rows = [list(row) for row in matrix]

    def row_vec(row: list[int]) -> Vector3:
        return _vec_linear(
            int(row[0]),
            int(row[1]),
            int(row[2]),
            lattice.a,
            lattice.b,
            lattice.c,
        )

    for _ in range(50):
        changed = False
        order = sorted(range(3), key=lambda index: _norm(row_vec(rows[index])))
        if order != [0, 1, 2]:
            rows = [rows[index] for index in order]
            changed = True

        vectors = [row_vec(row) for row in rows]
        for i in range(3):
            for j in range(i):
                denom = _dot(vectors[j], vectors[j])
                if denom <= 0.0:
                    continue
                coefficient = int(round(_dot(vectors[i], vectors[j]) / denom))
                if coefficient == 0:
                    continue
                rows[i] = [
                    int(rows[i][k]) - coefficient * int(rows[j][k])
                    for k in range(3)
                ]
                vectors = [row_vec(row) for row in rows]
                changed = True

        if not changed:
            break

    return tuple(tuple(int(value) for value in row) for row in rows)  # type: ignore[return-value]


def build_supercell_structure(
    structure: StructureModel,
    matrix: Matrix3i,
    *,
    title: str | None = None,
    eps: float = 1.0e-8,
) -> StructureModel:
    """Build a POSCAR-style supercell from an integer row transformation matrix."""

    if not structure.fractional_coordinates:
        raise ValueError("supercell POSCAR writing currently requires Direct coordinates")

    determinant = abs(_det3(matrix))
    if determinant <= 0:
        raise ValueError("supercell matrix must have non-zero determinant")

    inverse = _inverse3_float(matrix)
    search_limit = max(2, max(abs(value) for row in matrix for value in row) + 2)
    new_sites: list[Site] = []

    for site in structure.sites:
        found_for_site = 0
        seen: set[tuple[int, int, int]] = set()
        base = (float(site.x), float(site.y), float(site.z))
        for ix in range(-search_limit, search_limit + 1):
            for iy in range(-search_limit, search_limit + 1):
                for iz in range(-search_limit, search_limit + 1):
                    old_frac = (base[0] + ix, base[1] + iy, base[2] + iz)
                    new_frac = _row_times_matrix(old_frac, inverse)
                    if not all(-eps <= value < 1.0 - eps for value in new_frac):
                        continue
                    wrapped = tuple((value % 1.0) for value in new_frac)
                    key = (
                        int(round(wrapped[0] * 1.0e10)),
                        int(round(wrapped[1] * 1.0e10)),
                        int(round(wrapped[2] * 1.0e10)),
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    found_for_site += 1
                    new_sites.append(
                        Site(
                            kind=site.kind,
                            x=float(wrapped[0]),
                            y=float(wrapped[1]),
                            z=float(wrapped[2]),
                            oxidation=float(site.oxidation),
                        )
                    )
        if found_for_site != determinant:
            raise ValueError(
                "Failed to generate expected supercell images "
                f"for {site.kind}: got {found_for_site}, expected {determinant}"
            )

    new_lattice = Lattice(
        a=_vec_linear(*matrix[0], structure.lattice.a, structure.lattice.b, structure.lattice.c),
        b=_vec_linear(*matrix[1], structure.lattice.a, structure.lattice.b, structure.lattice.c),
        c=_vec_linear(*matrix[2], structure.lattice.a, structure.lattice.b, structure.lattice.c),
    )
    return StructureModel(
        title=title or f"{structure.title} supercell",
        lattice=new_lattice,
        sites=new_sites,
        fractional_coordinates=True,
    )


def _dot(a: Vector3, b: Vector3) -> float:
    return float(a[0] * b[0] + a[1] * b[1] + a[2] * b[2])


def _norm(a: Vector3) -> float:
    return math.sqrt(_dot(a, a))


def _angle_deg(a: Vector3, b: Vector3) -> float:
    denom = _norm(a) * _norm(b)
    if denom <= 0.0:
        return 0.0
    cos_value = max(-1.0, min(1.0, _dot(a, b) / denom))
    return math.degrees(math.acos(cos_value))


def _angle_score(a: Vector3, b: Vector3, c: Vector3) -> float:
    pairs = ((a, b), (b, c), (c, a))
    score = 0.0
    for left, right in pairs:
        denom = _norm(left) * _norm(right)
        if denom <= 0.0:
            continue
        cos_value = max(-1.0, min(1.0, _dot(left, right) / denom))
        score += cos_value * cos_value
    return float(score)


def _length_score(lengths: tuple[float, float, float]) -> float:
    if any(length <= 0.0 for length in lengths):
        return float("inf")
    geometric_mean = (lengths[0] * lengths[1] * lengths[2]) ** (1.0 / 3.0)
    return float(
        sum(math.log(length / geometric_mean) ** 2 for length in lengths) / 3.0
    )


def _candidate(
    lattice: Lattice,
    n_base_atoms: int,
    n_target_atoms: int,
    matrix: Matrix3i,
    *,
    count_weight: float,
    length_weight: float,
    angle_weight: float,
) -> SupercellCandidate:
    a = _vec_linear(*matrix[0], lattice.a, lattice.b, lattice.c)
    b = _vec_linear(*matrix[1], lattice.a, lattice.b, lattice.c)
    c = _vec_linear(*matrix[2], lattice.a, lattice.b, lattice.c)
    lengths = (_norm(a), _norm(b), _norm(c))
    angles = (_angle_deg(b, c), _angle_deg(c, a), _angle_deg(a, b))
    determinant = abs(_det3(matrix))
    dim = (int(matrix[0][0]), int(matrix[1][1]), int(matrix[2][2]))
    n_atoms = int(n_base_atoms * determinant)
    count_error = abs(float(n_atoms) - float(n_target_atoms)) / max(
        1.0, float(n_target_atoms)
    )
    length_score = _length_score(lengths)
    angle_score = _angle_score(a, b, c)
    score = (
        float(count_weight) * count_error * count_error
        + float(length_weight) * length_score
        + float(angle_weight) * angle_score
    )
    return SupercellCandidate(
        dim=dim,
        matrix=matrix,
        determinant=int(determinant),
        n_atoms=n_atoms,
        score=float(score),
        count_error=float(count_error),
        length_score=float(length_score),
        angle_score=float(angle_score),
        lengths=lengths,
        angles_deg=angles,
    )


def _diag_matrix(dim: tuple[int, int, int]) -> Matrix3i:
    return ((dim[0], 0, 0), (0, dim[1], 0), (0, 0, dim[2]))


def _divisors(value: int) -> list[int]:
    return [item for item in range(1, value + 1) if value % item == 0]


def _candidate_dims(
    n_base_atoms: int,
    n_target_atoms: int,
    *,
    tolerance: float,
    max_axis: int | None,
) -> Iterable[tuple[int, int, int]]:
    if n_base_atoms <= 0:
        raise ValueError("n_base_atoms must be positive")
    if n_target_atoms <= 0:
        raise ValueError("n_target_atoms must be positive")

    target_det = max(1.0, float(n_target_atoms) / float(n_base_atoms))
    max_det = max(1, int(math.ceil(target_det * (1.0 + max(0.0, tolerance)))))
    if max_axis is None:
        # Keep the default trial utility responsive for large targets.  The
        # explicit --max-axis option can still widen the diagonal search when a
        # strongly anisotropic cell is desired.
        limit = max(4, int(math.ceil(target_det ** (1.0 / 3.0))) + 6)
        limit = min(max_det, limit)
    else:
        limit = int(max_axis)
    limit = max(1, limit)
    for sx in range(1, limit + 1):
        for sy in range(1, limit + 1):
            for sz in range(1, limit + 1):
                det = sx * sy * sz
                if det > max_det:
                    continue
                yield (sx, sy, sz)


def _candidate_matrices(
    n_base_atoms: int,
    n_target_atoms: int,
    *,
    tolerance: float,
    max_axis: int | None,
    max_candidates: int,
) -> Iterable[Matrix3i]:
    if n_base_atoms <= 0:
        raise ValueError("n_base_atoms must be positive")
    if n_target_atoms <= 0:
        raise ValueError("n_target_atoms must be positive")

    target_det = max(1.0, float(n_target_atoms) / float(n_base_atoms))
    max_det = max(1, int(math.ceil(target_det * (1.0 + max(0.0, tolerance)))))
    min_det = max(1, int(math.floor(target_det * max(0.0, 1.0 - max(0.0, tolerance)))))
    yielded = 0

    for determinant in range(min_det, max_det + 1):
        for h11 in _divisors(determinant):
            rest = determinant // h11
            for h22 in _divisors(rest):
                h33 = rest // h22
                for h12 in range(h22):
                    for h13 in range(h33):
                        for h23 in range(h33):
                            matrix: Matrix3i = (
                                (h11, h12, h13),
                                (0, h22, h23),
                                (0, 0, h33),
                            )
                            if max_axis is not None:
                                max_entry = max(abs(value) for row in matrix for value in row)
                                if max_entry > int(max_axis):
                                    continue
                            yield matrix
                            yielded += 1
                            if yielded >= int(max_candidates):
                                return


def search_supercell(
    lattice: Lattice,
    *,
    n_base_atoms: int,
    n_target_atoms: int,
    mode: str = "near_cubic",
    tolerance: float = 0.50,
    max_axis: int | None = None,
    top: int = 10,
    count_weight: float = 50.0,
    length_weight: float = 1.0,
    angle_weight: float | None = None,
    max_candidates: int = 200_000,
) -> SupercellSearchResult:
    """Rank diagonal supercell dimensions for a target atom count.

    `axis_balanced` keeps the search restricted to diagonal axis multipliers and
    scores atom-count error plus length balance. `near_cubic` enumerates HNF
    integer supercell matrices in the target-size window, then scores atom-count
    error, length balance, and angle orthogonality. If no candidate falls inside
    the tolerance window, the function still returns the best candidate from the
    generated search window.
    """

    normalized_mode = str(mode).strip().lower()
    if normalized_mode not in {"axis_balanced", "near_cubic"}:
        raise ValueError("mode must be one of: axis_balanced, near_cubic")
    if top <= 0:
        raise ValueError("top must be positive")
    if angle_weight is None:
        angle_weight = 0.0 if normalized_mode == "axis_balanced" else 1.0

    if normalized_mode == "axis_balanced":
        matrices = [
            _diag_matrix(dim)
            for dim in _candidate_dims(
                int(n_base_atoms),
                int(n_target_atoms),
                tolerance=float(tolerance),
                max_axis=max_axis,
            )
        ]
    else:
        seen: set[Matrix3i] = set()
        matrices = []
        for raw_matrix in _candidate_matrices(
            int(n_base_atoms),
            int(n_target_atoms),
            tolerance=float(tolerance),
            max_axis=max_axis,
            max_candidates=int(max_candidates),
        ):
            matrix = _reduced_matrix_for_lattice(lattice, raw_matrix)
            if matrix in seen:
                continue
            seen.add(matrix)
            matrices.append(matrix)
    raw_candidates = [
        _candidate(
            lattice,
            int(n_base_atoms),
            int(n_target_atoms),
            matrix,
            count_weight=count_weight,
            length_weight=length_weight,
            angle_weight=float(angle_weight),
        )
        for matrix in matrices
    ]
    if not raw_candidates:
        raise ValueError("No supercell candidates generated")

    in_window = [
        candidate
        for candidate in raw_candidates
        if candidate.count_error <= max(0.0, float(tolerance))
    ]
    ranked = sorted(
        in_window or raw_candidates,
        key=lambda item: (item.score, item.count_error, item.n_atoms, item.dim),
    )
    return SupercellSearchResult(
        mode=normalized_mode,
        n_base_atoms=int(n_base_atoms),
        n_target_atoms=int(n_target_atoms),
        selected=ranked[0],
        candidates=ranked[:top],
    )
