from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Mapping

from .models import ReadyModel
from .native import load_native_module


def _ready_payload(ready: ReadyModel | Mapping[str, Any]) -> dict:
    if is_dataclass(ready):
        return asdict(ready)
    if isinstance(ready, Mapping):
        return dict(ready)
    raise TypeError(
        "write_poscar_text expected a ReadyModel or mapping, got "
        + repr(type(ready))
    )


def write_poscar_text(ready: ReadyModel | Mapping[str, Any]) -> str:
    native = load_native_module()
    return native.write_poscar_text(_ready_payload(ready))
