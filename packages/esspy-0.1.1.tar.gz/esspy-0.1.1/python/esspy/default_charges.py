from __future__ import annotations

DEFAULT_OXIDATION_BY_ELEMENT: dict[str, float] = {
    "H": 1.0,
    "Li": 1.0,
    "Na": 1.0,
    "K": 1.0,
    "Mg": 2.0,
    "Ca": 2.0,
    "Al": 3.0,
    "Si": 4.0,
    "Ti": 4.0,
    "V": 3.0,
    "Cr": 3.0,
    "Mn": 2.0,
    "Fe": 3.0,
    "Co": 2.0,
    "Ni": 2.0,
    "Cu": 2.0,
    "Zn": 2.0,
    "Ga": 3.0,
    "Ge": 4.0,
    "Y": 3.0,
    "Zr": 4.0,
    "Nb": 5.0,
    "Mo": 6.0,
    "Ru": 4.0,
    "Rh": 3.0,
    "Pd": 2.0,
    "Ag": 1.0,
    "Cd": 2.0,
    "In": 3.0,
    "Sn": 4.0,
    "Sb": 5.0,
    "Ba": 2.0,
    "La": 3.0,
    "Ce": 4.0,
    "W": 6.0,
    "Re": 7.0,
    "Os": 4.0,
    "Ir": 4.0,
    "Pt": 2.0,
    "Au": 3.0,
    "Hg": 2.0,
    "Pb": 2.0,
    "Bi": 3.0,
    "O": -2.0,
    "S": -2.0,
    "Se": -2.0,
    "Te": -2.0,
    "F": -1.0,
    "Cl": -1.0,
    "Br": -1.0,
    "I": -1.0,
    "N": -3.0,
    "P": -3.0,
}


def suggest_default_charge(kind: str) -> float:
    if kind in DEFAULT_OXIDATION_BY_ELEMENT:
        return float(DEFAULT_OXIDATION_BY_ELEMENT[kind])
    if kind == "M":
        return 2.0
    return 0.0


def build_default_charges(kinds: list[str]) -> dict[str, float]:
    return {kind: suggest_default_charge(kind) for kind in kinds}


# Typical oxidation state bounds for common elements
DEFAULT_CHARGE_BOUNDS: dict[str, tuple[float, float]] = {
    # Alkali metals
    "Li": (1.0, 1.0),
    "Na": (1.0, 1.0),
    "K": (1.0, 1.0),
    # Alkaline earth metals
    "Mg": (2.0, 2.0),
    "Ca": (2.0, 2.0),
    "Ba": (2.0, 2.0),
    # Transition metals (multiple oxidation states)
    "Sc": (3.0, 3.0),
    "Ti": (3.0, 4.0),
    "V": (2.0, 5.0),
    "Cr": (2.0, 6.0),
    "Mn": (2.0, 3.0),
    "Fe": (2.0, 3.0),
    "Co": (2.0, 3.0),
    "Ni": (2.0, 3.0),
    "Cu": (1.0, 2.0),
    "Zn": (2.0, 2.0),
    # Post-transition metals
    "Al": (3.0, 3.0),
    "Ga": (3.0, 3.0),
    "In": (3.0, 3.0),
    "Sn": (2.0, 4.0),
    "Pb": (2.0, 4.0),
    # Lanthanides
    "La": (3.0, 3.0),
    "Ce": (3.0, 4.0),
    # Non-metals
    "O": (-2.0, -0.5),
    "N": (-3.0, -3.0),
    "S": (-2.0, -2.0),
    "Se": (-2.0, -2.0),
    "Te": (-2.0, -2.0),
    "F": (-1.0, -1.0),
    "Cl": (-1.0, -1.0),
    "Br": (-1.0, -1.0),
    "I": (-1.0, -1.0),
    "P": (-3.0, -3.0),
}


def get_charge_bounds(element: str) -> tuple[float, float] | None:
    """Get typical oxidation state bounds for an element.

    Args:
        element: Element symbol

    Returns:
        Tuple of (min_charge, max_charge) or None if not found
    """
    return DEFAULT_CHARGE_BOUNDS.get(element)
