"""Legacy compatibility shim.

Prefer importing from ``esspy.run_outputs``.
"""

from . import run_outputs_impl as _impl
from .run_outputs_impl import *  # noqa: F401,F403

# Re-export private module symbols for backward compatibility with
# existing tests/internal imports using esspy.run_artifacts._*
for _name, _value in vars(_impl).items():
    if _name.startswith("_") and _name not in {"__builtins__", "__doc__", "__file__", "__name__", "__package__"}:
        globals()[_name] = _value
