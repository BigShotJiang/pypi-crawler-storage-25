"""Built-in crystal structure templates for esspy wizard.

Provides common structure templates (spinel, perovskite, etc.) for quick-start
solid-solution configurations.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Dict, Tuple, List


@dataclass
class StructureTemplate:
    """Template for common crystal structures."""
    name: str
    formula: str
    description: str
    site_types: Dict[str, Tuple[str, int, str]]  # {site_name: (wyckoff, coordination, default_element)}
    n_atoms_unitcell: int
    poscar_content: str


# Spinel structure (MgAl2O4)
# Space group 227 (Fd-3m)
SPINEL_POSCAR = """Spinel (MgAl2O4)
1.0
   8.0837130000000001    0.0000000000000000    0.0000000000000000
   0.0000000000000000    8.0837130000000001    0.0000000000000000
   0.0000000000000000    0.0000000000000000    8.0837130000000001
Mg Al O
   2   4   8
Direct
   0.1250000000000000    0.1250000000000000    0.1250000000000000
   0.6250000000000000    0.6250000000000000    0.6250000000000000
   0.5000000000000000    0.5000000000000000    0.5000000000000000
   0.0000000000000000    0.0000000000000000    0.0000000000000000
   0.2500000000000000    0.2500000000000000    0.2500000000000000
   0.7500000000000000    0.7500000000000000    0.7500000000000000
   0.3750000000000000    0.3750000000000000    0.3750000000000000
   0.1250000000000000    0.1250000000000000    0.6250000000000000
   0.1250000000000000    0.6250000000000000    0.1250000000000000
   0.6250000000000000    0.1250000000000000    0.1250000000000000
   0.3750000000000000    0.3750000000000000    0.8750000000000000
   0.3750000000000000    0.8750000000000000    0.3750000000000000
   0.8750000000000000    0.3750000000000000    0.3750000000000000
   0.6250000000000000    0.6250000000000000    0.1250000000000000
   0.6250000000000000    0.1250000000000000    0.6250000000000000
   0.1250000000000000    0.6250000000000000    0.6250000000000000
"""

# Perovskite structure (ABO3)
PEROVSKITE_POSCAR = """Perovskite (ABO3)
1.0
   4.0000000000000000    0.0000000000000000    0.0000000000000000
   0.0000000000000000    4.0000000000000000    0.0000000000000000
   0.0000000000000000    0.0000000000000000    4.0000000000000000
A B O
   1   1   3
Direct
   0.5000000000000000    0.5000000000000000    0.5000000000000000
   0.0000000000000000    0.0000000000000000    0.0000000000000000
   0.5000000000000000    0.5000000000000000    0.0000000000000000
   0.5000000000000000    0.0000000000000000    0.5000000000000000
   0.0000000000000000    0.5000000000000000    0.5000000000000000
"""

# Rocksalt structure (NaCl type)
ROCKSALT_POSCAR = """Rocksalt (NaCl-type)
1.0
   5.6400000000000000    0.0000000000000000    0.0000000000000000
   0.0000000000000000    5.6400000000000000    0.0000000000000000
   0.0000000000000000    0.0000000000000000    5.6400000000000000
Na Cl
   4   4
Direct
   0.0000000000000000    0.0000000000000000    0.0000000000000000
   0.0000000000000000    0.5000000000000000    0.5000000000000000
   0.5000000000000000    0.0000000000000000    0.5000000000000000
   0.5000000000000000    0.5000000000000000    0.0000000000000000
   0.5000000000000000    0.5000000000000000    0.5000000000000000
   0.5000000000000000    0.0000000000000000    0.0000000000000000
   0.0000000000000000    0.5000000000000000    0.0000000000000000
   0.0000000000000000    0.0000000000000000    0.5000000000000000
"""

# Fluorite structure (CaF2 type)
FLUORITE_POSCAR = """Fluorite (CaF2-type)
1.0
   5.4600000000000000    0.0000000000000000    0.0000000000000000
   0.0000000000000000    5.4600000000000000    0.0000000000000000
   0.0000000000000000    0.0000000000000000    5.4600000000000000
Ca F
   4   8
Direct
   0.0000000000000000    0.0000000000000000    0.0000000000000000
   0.0000000000000000    0.5000000000000000    0.5000000000000000
   0.5000000000000000    0.0000000000000000    0.5000000000000000
   0.5000000000000000    0.5000000000000000    0.0000000000000000
   0.2500000000000000    0.2500000000000000    0.2500000000000000
   0.7500000000000000    0.7500000000000000    0.2500000000000000
   0.7500000000000000    0.2500000000000000    0.7500000000000000
   0.2500000000000000    0.7500000000000000    0.7500000000000000
   0.2500000000000000    0.2500000000000000    0.7500000000000000
   0.7500000000000000    0.7500000000000000    0.7500000000000000
   0.7500000000000000    0.2500000000000000    0.2500000000000000
   0.2500000000000000    0.7500000000000000    0.2500000000000000
"""


# Template definitions
TEMPLATES = {
    "spinel": StructureTemplate(
        name="Spinel",
        formula="AB₂O₄",
        description="Spinel structure (MgAl₂O₄, Fd-3m)",
        site_types={
            "A-site (8a)": ("8a", 8, "Mg"),
            "B-site (16d)": ("16d", 6, "Al"),
            "O-site (32e)": ("32e", 4, "O"),
        },
        n_atoms_unitcell=14,
        poscar_content=SPINEL_POSCAR,
    ),
    "perovskite": StructureTemplate(
        name="Perovskite",
        formula="ABO₃",
        description="Cubic perovskite structure (Pm-3m)",
        site_types={
            "A-site (1a)": ("1a", 12, "Ca"),
            "B-site (1b)": ("1b", 6, "Ti"),
            "O-site (3c)": ("3c", 4, "O"),
        },
        n_atoms_unitcell=5,
        poscar_content=PEROVSKITE_POSCAR,
    ),
    "rocksalt": StructureTemplate(
        name="Rocksalt",
        formula="AB",
        description="Rocksalt structure (NaCl-type, Fm-3m)",
        site_types={
            "Cation (4a)": ("4a", 6, "Na"),
            "Anion (4b)": ("4b", 6, "Cl"),
        },
        n_atoms_unitcell=8,
        poscar_content=ROCKSALT_POSCAR,
    ),
    "fluorite": StructureTemplate(
        name="Fluorite",
        formula="AB₂",
        description="Fluorite structure (CaF₂-type, Fm-3m)",
        site_types={
            "Cation (4a)": ("4a", 8, "Ca"),
            "Anion (8c)": ("8c", 4, "F"),
        },
        n_atoms_unitcell=12,
        poscar_content=FLUORITE_POSCAR,
    ),
}


def get_template(name: str) -> Optional[StructureTemplate]:
    """Get template by name (case-insensitive).

    Args:
        name: Template name (e.g., "spinel", "perovskite")

    Returns:
        StructureTemplate object or None if not found
    """
    return TEMPLATES.get(name.lower())


def list_templates() -> List[str]:
    """Get list of available template names.

    Returns:
        Sorted list of template names
    """
    return sorted(TEMPLATES.keys())


def describe_templates() -> str:
    """Get formatted description of all templates.

    Returns:
        Formatted string for display
    """
    lines = ["Available structure templates:\n"]
    for name, template in sorted(TEMPLATES.items()):
        lines.append(f"  {name.ljust(12)} : {template.formula.ljust(10)} ({template.description})")
    return "\n".join(lines)


def get_templates_dict() -> Dict[str, Dict]:
    """Get template information as a dictionary.

    Returns:
        Dictionary mapping template names to template info dicts
    """
    result = {}
    for name, template in sorted(TEMPLATES.items()):
        result[name] = {
            "formula": template.formula,
            "description": template.description,
            "n_atoms": template.n_atoms_unitcell,
            "site_types": list(template.site_types.keys()),
        }
    return result
