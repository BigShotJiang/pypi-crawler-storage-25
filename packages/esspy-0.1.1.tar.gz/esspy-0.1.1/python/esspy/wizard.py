"""Interactive CLI wizard for esspy configuration.

Provides VASP KIT-style number-based menu interface for building
composition-driven or interstitial-driven solid-solution structures.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional, Tuple, List, Dict, Callable
import math
import os
import re
import sys

from .default_charges import suggest_default_charge
from .init_scaffold import render_init_yaml_text
from .poscar import load_poscar
from .models import StructureModel
from .site_grouping import (
    SiteGroupingOptions,
    detect_site_groups,
    site_group_specs_to_yaml,
)


class _WizardBack(Exception):
    """Signal that the user requested to go back to the previous prompt."""


_BACK_COMMANDS = {"b", "back", "undo", "prev", "previous"}


class WizardMode(Enum):
    """Wizard operation mode."""
    COMPOSITION = "composition"
    INTERSTITIAL = "interstitial"


def _relative_path_for_yaml(path: str | Path, yaml_dir: Path) -> str:
    resolved_path = Path(path).expanduser().resolve()
    resolved_yaml_dir = yaml_dir.expanduser().resolve()
    return os.path.relpath(resolved_path, resolved_yaml_dir)


_ADD_SITES_PRESETS = {
    'quick':    {'AddMeshes': '1.0 1.0 1.0', 'MinDistanceBetweenAddedSites': '0.8',  'NMonteCarlo': '50',  'RGFindFactor': '2', 'detect_symmetry': False},
    'thorough': {'AddMeshes': '0.3 0.3 0.3', 'MinDistanceBetweenAddedSites': '1.5',  'NMonteCarlo': '500', 'RGFindFactor': '5', 'detect_symmetry': True},
}

def _get_preset_params(name: str):
    """Return (AddMeshes, MinDistance, NMonteCarlo, RGFindFactor) for display."""
    p = _ADD_SITES_PRESETS[name]
    return p['AddMeshes'], p['MinDistanceBetweenAddedSites'], p['NMonteCarlo'], p['RGFindFactor']


def _parse_element_list(raw: str) -> List[str]:
    """Parse comma and/or whitespace separated element lists.

    Accepted examples:
    - "Mn,Cr,Ni"
    - "Mn Cr Ni"
    - "Mn  Cr  Ni"
    - "Mn, Cr Ni"
    """
    return [token for token in re.split(r"[\s,]+", raw.strip()) if token]


def _append_unique_in_order(items: List[str], new_items: List[str]) -> None:
    """Append items while preserving first-seen order."""
    seen = set(items)
    for item in new_items:
        if item not in seen:
            items.append(item)
            seen.add(item)


def _parse_count_input(raw: str) -> tuple[str, float]:
    """Parse count input and classify as int or fraction mode.

    Returns:
        (mode, value) where mode is "int" or "fraction".
    """
    text = raw.strip()
    if not text:
        raise ValueError("empty count")

    if "/" in text:
        numerator, denominator = text.split("/", 1)
        value = float(numerator) / float(denominator)
        mode = "fraction"
    else:
        value = float(text)
        # If the user typed a decimal/scientific notation, treat it as fractional mode.
        if any(ch in text.lower() for ch in [".", "e"]):
            mode = "fraction"
        else:
            mode = "int"

    if value < 0:
        raise ValueError("count must be >= 0")
    return mode, value


def _normalize_fraction_values(values: Dict[str, float]) -> Dict[str, float]:
    total = float(sum(values.values()))
    if total <= 0.0:
        raise ValueError("fraction values must sum to a positive number")
    return {kind: float(value) / total for kind, value in values.items()}


def _counts_from_fraction_values(values: Dict[str, float], target_atoms: int) -> Dict[str, int]:
    fractions = _normalize_fraction_values(values)
    counts: Dict[str, int] = {}
    remainders: list[tuple[float, int, str]] = []
    for index, (kind, fraction) in enumerate(fractions.items()):
        scaled = fraction * int(target_atoms)
        count = int(math.floor(scaled))
        counts[kind] = count
        remainders.append((scaled - count, index, kind))

    missing = int(target_atoms) - sum(counts.values())
    if missing < 0:
        raise ValueError("fraction rounding exceeded target atom count")
    for _, _, kind in sorted(remainders, key=lambda item: (-item[0], item[1]))[:missing]:
        counts[kind] += 1
    return counts


def _production_solve_block(state: "WizardState" | None = None) -> Dict[str, Any]:
    """Return production-oriented solve defaults for wizard-generated YAML.

    Uses the user-facing `solve.strategy` schema instead of legacy low-level
    fields (`running_index_delta`, `local_enumeration_*`, ...).
    """
    mode = "adaptive"
    time_budget_sec = 600
    effort = "medium"
    execution_mode = "quick"
    swap_enabled = True
    swap_max_steps = 100
    if state is not None:
        mode = str(getattr(state, "solve_mode", mode))
        time_budget_sec = int(getattr(state, "solve_time_budget_sec", time_budget_sec))
        effort = str(getattr(state, "solve_effort", effort))
        execution_mode = str(
            getattr(state, "solve_execution_mode", execution_mode)
        )
        swap_enabled = bool(getattr(state, "solve_swap_enabled", swap_enabled))
        swap_max_steps = int(getattr(state, "solve_swap_max_steps", swap_max_steps))

    return {
        "strategy": {
            "mode": mode,
            "time_budget_sec": time_budget_sec,
            "effort": effort,
            "execution_mode": execution_mode,
            "swap": {
                "enabled": swap_enabled,
                "max_steps": swap_max_steps,
            },
        },
    }


def _host_output_block() -> Dict[str, Any]:
    """Return host-enumeration output names used by wizard-generated YAML."""
    return {
        "workdir": "run-output",
        "input_filename": "input.yaml",
        "poscar_filename": "POSCAR_host_supercell.vasp",
        "best_poscar_filename": "POSCAR_host_best.vasp",
        "worst_poscar_filename": "POSCAR_host_worst.vasp",
        "summary_filename": "host_summary.json",
        "energy_filename": "host_energies.txt",
        "selection": {
            "enabled": True,
            "mode": "auto_top_n",
            "interval": "left-closed",
            "limit": 20,
            "pick": "lowest",
            "seed": None,
            "outdir": "selected_structures",
            "prefix": "selected",
            "on_missing": "skip",
            "dedupe": "path-energy",
            "write_index_tsv": True,
        },
    }


def _selection_block_from_state(state: "WizardState" | None) -> Dict[str, Any]:
    block = _host_output_block().get("selection", {})
    if state is None:
        return dict(block)
    block = dict(block)
    block.update(
        {
            "enabled": bool(getattr(state, "selection_enabled", True)),
            "mode": str(getattr(state, "selection_mode", "auto_top_n")),
            "interval": str(getattr(state, "selection_interval", "left-closed")),
            "limit": int(getattr(state, "selection_limit", 20)),
            "pick": str(getattr(state, "selection_pick", "lowest")),
            "seed": getattr(state, "selection_seed", None),
            "outdir": str(getattr(state, "selection_outdir", "selected_structures")),
            "prefix": str(getattr(state, "selection_prefix", "selected")),
            "on_missing": str(getattr(state, "selection_on_missing", "skip")),
            "dedupe": str(getattr(state, "selection_dedupe", "path-energy")),
            "write_index_tsv": bool(getattr(state, "selection_write_index_tsv", True)),
        }
    )
    return block


@dataclass
class WizardState:
    """Maintains wizard progress state across steps."""
    mode: WizardMode
    reference_structure: Optional[str] = None  # POSCAR path or template name
    structure: Optional[StructureModel] = None  # Loaded structure
    target_atoms: int = 112
    supercell_expansion: Optional[Tuple[int, int, int]] = None
    resolved_supercell_expansion: Optional[Tuple[int, int, int]] = None

    # Element mapping: {original_element: [substitute1, substitute2, ...]}
    element_mapping: Dict[str, List[str]] = field(default_factory=dict)

    # Mapped elements after substitution
    mapped_elements: List[str] = field(default_factory=list)
    site_grouping: Dict[str, Any] = field(default_factory=dict)
    site_grouping_mode: str = "poscar_kind"
    site_grouping_symprec: float = 0.1
    site_grouping_angle_tolerance: float = 5.0
    site_groups: Dict[str, Dict[str, Any]] = field(default_factory=dict)  # {group_name: {source_kind,count,allowed}}
    composition_mode: str = "global"  # global | sitewise
    allocation_time_budget_sec: Optional[int] = None
    # Deprecated wizard state fields kept only so old snapshots can still load.
    allocation_n_alloc: int = 32
    allocation_n_alloc_feasible_target: int = 20
    allocation_n_alloc_max_requested: int = 2000
    composition_by_site: Dict[str, Dict[str, int]] = field(default_factory=dict)

    composition: Dict[str, int] = field(default_factory=dict)  # {element: count}
    composition_fractions: Dict[str, float] = field(default_factory=dict)  # {element: normalized fraction}
    charges: Dict[str, float] = field(default_factory=dict)  # {element: charge}
    charge_basis: str = "element+site_group"  # element | element+site_group
    charges_by_site: Dict[str, float] = field(default_factory=dict)  # {"Mn@site1": 1.8, ...}
    recipes: Dict[str, List[str]] = field(default_factory=dict)  # {from: [to1, to2, ...]}

    # Scenario B only
    interstitial_species: Optional[str] = None
    interstitial_count: Optional[int] = None  # Number of interstitial atoms to add
    add_sites_config: Dict[str, str] = field(default_factory=dict)  # Add-sites parameters

    # Validation results
    composition_valid: bool = False
    charges_balanced: bool = False
    recipes_valid: bool = False

    # Solve strategy (user-facing)
    solve_mode: str = "adaptive"
    solve_effort: str = "medium"
    solve_execution_mode: str = "quick"
    solve_time_budget_sec: int = 600
    solve_swap_enabled: bool = True
    solve_swap_max_steps: int = 100
    selection_enabled: bool = True
    selection_mode: str = "auto_top_n"
    selection_interval: str = "left-closed"
    selection_limit: int = 20
    selection_pick: str = "lowest"
    selection_seed: Optional[int] = None
    selection_outdir: str = "selected_structures"
    selection_prefix: str = "selected"
    selection_on_missing: str = "skip"
    selection_dedupe: str = "path-energy"
    selection_write_index_tsv: bool = True


class WizardSession:
    """Main wizard orchestrator for interactive configuration building."""

    def __init__(self, mode: WizardMode = WizardMode.COMPOSITION):
        """Initialize wizard session.

        Args:
            mode: COMPOSITION or INTERSTITIAL workflow mode
        """
        self.state = WizardState(mode=mode)
        self.history: List[str] = []  # Step history for undo

    def _infer_fixed_global_element_counts(
        self,
        actual_sites: Dict[str, int],
        element_counts: Dict[str, int],
        supercell_scale: float,
    ) -> Dict[str, int]:
        """Return global counts forced by identity-only source mappings.

        Example: if O only appears through O -> O, and the supercell contains
        256 O source sites, global composition mode should auto-fill O=256 and
        ask the user only for the variable cation-site elements.
        """

        fixed_counts: Dict[str, int] = {}
        for element in self.state.mapped_elements:
            source_kinds: List[str] = []
            fixed = True
            for source_kind, mapped in self.state.element_mapping.items():
                if element not in mapped:
                    continue
                source_kinds.append(source_kind)
                if len(mapped) != 1 or mapped[0] != element:
                    fixed = False
            if not source_kinds or not fixed:
                continue

            total = 0
            for source_kind in source_kinds:
                fallback = int(round(element_counts.get(source_kind, 0) * supercell_scale))
                total += int(actual_sites.get(source_kind, fallback))
            fixed_counts[element] = total
        return fixed_counts

    def _supercell_cell_metrics(
        self,
        dims: Tuple[int, int, int],
    ) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
        if self.state.structure is None:
            raise ValueError("structure is not loaded")

        def scale_vec(vec: tuple[float, float, float], scale: int) -> tuple[float, float, float]:
            return (
                float(vec[0]) * int(scale),
                float(vec[1]) * int(scale),
                float(vec[2]) * int(scale),
            )

        def dot(left: tuple[float, float, float], right: tuple[float, float, float]) -> float:
            return float(left[0] * right[0] + left[1] * right[1] + left[2] * right[2])

        def norm(vec: tuple[float, float, float]) -> float:
            return math.sqrt(dot(vec, vec))

        def angle_deg(left: tuple[float, float, float], right: tuple[float, float, float]) -> float:
            denom = norm(left) * norm(right)
            if denom <= 0.0:
                return 0.0
            value = max(-1.0, min(1.0, dot(left, right) / denom))
            return math.degrees(math.acos(value))

        lattice = self.state.structure.lattice
        a_vec = scale_vec(lattice.a, dims[0])
        b_vec = scale_vec(lattice.b, dims[1])
        c_vec = scale_vec(lattice.c, dims[2])
        lengths = (norm(a_vec), norm(b_vec), norm(c_vec))
        angles = (
            angle_deg(b_vec, c_vec),
            angle_deg(c_vec, a_vec),
            angle_deg(a_vec, b_vec),
        )
        return lengths, angles

    def _print_supercell_cell_metrics(self, dims: Tuple[int, int, int]) -> None:
        lengths, angles = self._supercell_cell_metrics(dims)
        print("  Cell metrics:")
        print(
            f"    a={lengths[0]:.4f} A, b={lengths[1]:.4f} A, c={lengths[2]:.4f} A"
        )
        print(
            f"    alpha={angles[0]:.2f}°, beta={angles[1]:.2f}°, gamma={angles[2]:.2f}°"
        )

    # ===== Menu & Input Rendering =====

    def render_menu(
        self,
        title: str,
        options: List[str],
        show_exit: bool = False,
        default_index: Optional[int] = None,
    ) -> int:
        """Display VASP KIT-style menu and get selection.

        Args:
            title: Menu title/prompt
            options: List of option strings
            show_exit: If True, add "Exit" option at end

        Returns:
            Selected option index (0-based), or -1 for exit
        """
        total_options = len(options) + (1 if show_exit else 0)

        # Auto-select if only 1 option
        if total_options == 1:
            return 0

        print(f"\n{title}")
        for i, opt in enumerate(options, 1):
            print(f"  {i}) {opt}")
        if show_exit:
            print(f"  {total_options}) Exit")

        while True:
            try:
                prompt = f"Select ({1}-{total_options})"
                if default_index is not None and 0 <= default_index < len(options):
                    prompt += f" [default: {default_index + 1}]"
                prompt += ": "
                choice = input(prompt).strip()
                if not choice:
                    if default_index is not None and 0 <= default_index < len(options):
                        return default_index
                    continue
                choice_int = int(choice)
                if 1 <= choice_int <= total_options:
                    if show_exit and choice_int == total_options:
                        return -1
                    return choice_int - 1
                print(f"  ERROR: Please enter {1}-{total_options}")
            except ValueError:
                print(f"  ERROR: Invalid input. Please enter a number.")

    def prompt_input(
        self,
        prompt: str,
        input_type: type = str,
        default: Any = None,
        validator: Optional[Callable[[Any], Tuple[bool, str]]] = None,
        max_attempts: Optional[int] = None,
        allow_back: bool = False,
    ) -> Any:
        """Prompt user for input with optional validation.

        Args:
            prompt: Input prompt text
            input_type: Expected type (str, int, float)
            default: Default value if user presses Enter
            validator: Optional (is_valid, error_msg) -> tuple function
            allow_back: Treat back/b/undo/prev as a request to revisit the previous prompt

        Returns:
            Parsed input value
        """
        default_str = f" [{default}]" if default is not None else ""
        full_prompt = f"{prompt}{default_str}: "
        attempts = 0

        while True:
            try:
                value = input(full_prompt).strip()

                if allow_back and value.lower() in _BACK_COMMANDS:
                    raise _WizardBack()

                # Use default if empty
                if not value:
                    if default is not None:
                        return default
                    print("  ERROR: Input required")
                    attempts += 1
                    if max_attempts is not None and attempts >= max_attempts:
                        raise RuntimeError(f"Maximum attempts exceeded for: {prompt}")
                    continue

                # Parse type
                if input_type == int:
                    parsed = int(value)
                elif input_type == float:
                    parsed = float(value)
                else:
                    parsed = value

                # Validate
                if validator:
                    is_valid, error_msg = validator(parsed)
                    if not is_valid:
                        print(f"  ERROR: {error_msg}")
                        attempts += 1
                        if max_attempts is not None and attempts >= max_attempts:
                            raise RuntimeError(f"Maximum attempts exceeded for: {prompt}")
                        continue

                return parsed
            except ValueError:
                print(f"  ERROR: Expected {input_type.__name__}")
                attempts += 1
                if max_attempts is not None and attempts >= max_attempts:
                    raise RuntimeError(f"Maximum attempts exceeded for: {prompt}")

    def confirm(self, message: str, *, default_yes: bool = False) -> bool:
        """Prompt for yes/no confirmation.

        Args:
            message: Confirmation message

        Returns:
            True if user selects yes
        """
        while True:
            prompt = "[Y/n]" if default_yes else "[y/N]"
            response = input(f"{message} {prompt}: ").strip().lower()
            if response in ("y", "yes"):
                return True
            elif response in ("n", "no"):
                return False
            elif response == "":
                return default_yes
            print("  ERROR: Please enter 'y' or 'n'")

    def _run_step_with_retry(self, step_fn, max_retries: int = 3) -> bool:
        """Run a step function, retrying from the top on failure.

        The user can retry by re-entering values. After max_retries consecutive
        failures the wizard exits.
        """
        for attempt in range(max_retries):
            if step_fn():
                return True
            remaining = max_retries - attempt - 1
            if remaining == 0:
                print("\nToo many failed attempts. Exiting wizard.")
                return False
            print(f"\n  ↩  Retrying step ({remaining} attempt(s) left before exit)...")
        return False

    # ===== Composition Scenario Steps =====

    def step_1_structure_selection(self) -> bool:
        """Step 1: Select reference structure (POSCAR or template).

        Returns:
            True if step completed successfully
        """
        print("\n" + "="*60)
        print("Step 1/5: Reference Structure")
        print("="*60)

        # For now, only support POSCAR loading (templates come in Phase 2)
        options = ["Load POSCAR file"]
        choice = self.render_menu("Select structure source:", options)

        if choice == 0:
            # Get available POSCAR files and let user choose
            poscar_files = self._get_poscar_files()

            if poscar_files:
                # Show files as menu options
                options = [f.name for f in sorted(poscar_files)[:10]]
                options.append("Other file (manual path)")

                print("\nSelect a POSCAR file:")
                file_choice = self.render_menu("", options)

                if file_choice < len(poscar_files):
                    poscar_path = sorted(poscar_files)[file_choice]
                else:
                    # Manual path input - show all files in current directory
                    print("\nFiles in current directory:")
                    self._show_directory_contents()
                    print("\nEnter file name or path:")
                    poscar_path = self.prompt_input("POSCAR file path", str)
                    poscar_path = Path(poscar_path)
            else:
                # No files found, ask for manual input
                print("\n(No POSCAR files found in current directory)")
                poscar_path = self.prompt_input("POSCAR file path", str)
                poscar_path = Path(poscar_path)

            try:
                if not poscar_path.exists():
                    print(f"  ERROR: File not found: {poscar_path}")
                    return False

                self.state.structure = load_poscar(str(poscar_path))
                self.state.reference_structure = str(poscar_path)

                # Display structure info
                formula = self._get_formula_from_structure()
                n_atoms = len(self.state.structure.sites)
                print(f"\n✓ Loaded {poscar_path.name}")
                print(f"  Formula: {formula}")
                print(f"  Total atoms: {n_atoms}")

                return True
            except Exception as e:
                print(f"  ERROR: Failed to load POSCAR: {e}")
                return False

        return False

    def step_2_element_mapping(self) -> bool:
        """Step 2: Define element substitution mapping.

        Map original structure elements to desired elements.
        Example: Si → {Mn, Ni, Cr} or O → {O} (unchanged)

        Returns:
            True if mapping completed successfully
        """
        print("\n" + "="*60)
        print("Step 2/6: Element Mapping")
        print("="*60)

        if not self.state.structure:
            print("ERROR: No structure loaded")
            return False

        # Count atoms per element
        element_counts: Dict[str, int] = {}
        for site in self.state.structure.sites:
            element_counts[site.kind] = element_counts.get(site.kind, 0) + 1

        elements_in_structure = list(element_counts.keys())
        formula = self._get_formula_from_structure()
        n_atoms = len(self.state.structure.sites)

        # Display structure composition
        print(f"\nBase structure: {formula} ({n_atoms} atoms total)")
        for element in elements_in_structure:
            count = element_counts[element]
            percentage = 100 * count / n_atoms
            print(f"  {element}: {count} atoms ({percentage:.1f}%)")

        print("\nDefine which elements each can be substituted with.")
        print("Format: comma or space separated  (e.g. 'Mn,Ni,Cr' or 'Mn Ni Cr')")
        print("Example: Si → 'Mn,Ni,Cr' or O → 'O' (unchanged)\n")

        element_mapping: Dict[str, List[str]] = {}
        all_mapped_elements: List[str] = []

        for element in elements_in_structure:
            targets_input = input(f"  {element} → [default {element}]: ").strip()

            if not targets_input:
                targets = [element]
            else:
                targets = _parse_element_list(targets_input)

            element_mapping[element] = targets
            _append_unique_in_order(all_mapped_elements, targets)

        self.state.element_mapping = element_mapping
        self.state.mapped_elements = all_mapped_elements

        # Show summary
        print("\n✓ Element mapping defined:")
        for from_elem, to_elems in element_mapping.items():
            to_str = ",".join(to_elems)
            print(f"   {from_elem} → {{{to_str}}}")

        print(f"\n✓ Available elements for composition: {', '.join(self.state.mapped_elements)}")

        return True

    def step_2b_site_groups_and_composition_mode(self) -> bool:
        """Step 2B: Detect site groups and choose composition input mode."""
        print("\n" + "="*60)
        print("Step 3/7: Site Groups & Composition Mode")
        print("="*60)

        if not self.state.structure:
            print("ERROR: No structure loaded")
            return False

        policy_choice = self.render_menu(
            "\nSelect site grouping policy:",
            [
                "Element/POSCAR-kind only",
                "Element + Wyckoff/orbit",
            ],
            default_index=1,
        )
        grouping_mode = "element_wyckoff" if policy_choice == 1 else "poscar_kind"
        symprec = 0.1
        angle_tolerance = 5.0
        if grouping_mode == "element_wyckoff":
            symprec = self.prompt_input(
                "Site grouping symmetry tolerance",
                float,
                default=0.1,
                validator=lambda value: (
                    value > 0,
                    "Must be > 0",
                ),
            )
            angle_tolerance = self.prompt_input(
                "Site grouping angle tolerance",
                float,
                default=5.0,
                validator=lambda value: (
                    value > 0,
                    "Must be > 0",
                ),
            )

        try:
            result = detect_site_groups(
                self.state.structure,
                self.state.element_mapping,
                SiteGroupingOptions(
                    mode=grouping_mode,
                    symprec=float(symprec),
                    angle_tolerance=float(angle_tolerance),
                    fallback="poscar_kind",
                    strict=False,
                ),
            )
        except Exception as exc:
            print(f"  ERROR: Failed to detect site groups: {exc}")
            return False

        site_groups = site_group_specs_to_yaml(result.groups)
        self.state.site_grouping = dict(result.metadata)
        if result.warnings:
            self.state.site_grouping["warnings"] = list(result.warnings)
        self.state.site_grouping_mode = str(result.mode)
        self.state.site_grouping_symprec = float(symprec)
        self.state.site_grouping_angle_tolerance = float(angle_tolerance)

        print(f"\nDetected site groups ({result.mode}):")
        if result.fallback_used:
            print("  WARNING: requested grouping fell back to POSCAR-kind grouping")
        for warning in result.warnings:
            print(f"  WARNING: {warning}")
        for group_name, info in site_groups.items():
            allowed = list(info.get("allowed", []))
            label = info.get("label", {})
            display = label.get("display") if isinstance(label, dict) else None
            prefix = f"{group_name}: "
            if display:
                prefix += f"{display}, "
            detail = (
                f"source={info.get('source_kind')}, count={info.get('count')}, "
                f"allowed={','.join(allowed)}"
            )
            symmetry = info.get("symmetry", {})
            if isinstance(symmetry, dict) and symmetry:
                detail += (
                    f", wyckoff={symmetry.get('wyckoff')}, "
                    f"site_sym={symmetry.get('site_symmetry')}"
                )
            print(f"  {prefix}{detail}")

        if not self.confirm("\nUse detected site groups?", default_yes=True):
            print("  INFO: Manual site-group editing is not enabled yet. Using detected groups.")

        mode_choice = self.render_menu(
            "\nSelect composition input mode:",
            [
                "Global composition (enter only total element counts)",
                "Site-wise composition (enter counts for each site-group)",
            ],
            default_index=0,
        )
        self.state.composition_mode = "global" if mode_choice == 0 else "sitewise"
        self.state.site_groups = site_groups
        if self.state.composition_mode == "global":
            pass
        else:
            self.state.allocation_time_budget_sec = None

        print(f"\n✓ Composition mode: {self.state.composition_mode}")
        return True

    def step_3_target_composition(self) -> bool:
        """Step 3: Specify target composition (total atoms and element counts).

        User provides target atom count (any size >= base structure).
        ESS automatically determines the supercell size to match it.

        Returns:
            True if composition is valid or auto-corrected
        """
        print("\n" + "="*60)
        print("Step 4/7: Target Composition")
        print("="*60)

        if not self.state.mapped_elements:
            print("ERROR: No element mapping defined")
            return False

        formula = self._get_formula_from_structure()
        print(f"\nBase structure: {formula}")
        print(f"Mapped elements: {', '.join(self.state.mapped_elements)}")

        # Show common options for target size
        current_n_atoms = len(self.state.structure.sites) if self.state.structure else 14
        common_scales = [
            (2, current_n_atoms * 2),
            (3, current_n_atoms * 3),
            (4, current_n_atoms * 4),
        ]

        print(f"\nBase structure: {current_n_atoms} atoms")
        setup_choice = self.render_menu(
            "\nSelect supercell setup:",
            [
                "Auto by target atom count",
                "Explicit supercell dimension/matrix",
            ],
            default_index=0,
        )

        actual_sites = {}
        target_atoms: int
        explicit_supercell: Optional[Tuple[int, int, int]] = None

        # Count atoms per element in base structure
        element_counts: Dict[str, int] = {}
        for site in self.state.structure.sites:
            element_counts[site.kind] = element_counts.get(site.kind, 0) + 1
        base_atoms = sum(element_counts.values())

        if setup_choice == 1:
            failures = 0
            while failures < 3:
                try:
                    raw = self.prompt_input(
                        "Supercell dimension/matrix (example: 2 2 2 or 2 0 0 0 2 0 0 0 2)",
                        str,
                        default=None,
                        max_attempts=3,
                    )
                except RuntimeError:
                    print("  ERROR: Too many invalid supercell inputs. Exiting step.")
                    return False
                parts = raw.replace(",", " ").replace("x", " ").replace("X", " ").split()
                try:
                    if len(parts) not in (3, 9):
                        raise ValueError
                    values = [int(part) for part in parts]
                    if len(values) == 3:
                        dims = tuple(values)
                    else:
                        matrix = [values[0:3], values[3:6], values[6:9]]
                        if any(
                            matrix[row][col] != 0
                            for row in range(3)
                            for col in range(3)
                            if row != col
                        ):
                            raise ValueError(
                                "non-diagonal 3x3 matrices are not yet supported; "
                                "use a diagonal matrix or 3 integers"
                            )
                        dims = (matrix[0][0], matrix[1][1], matrix[2][2])
                    if any(value <= 0 for value in dims):
                        raise ValueError
                except ValueError as exc:
                    failures += 1
                    detail = str(exc).strip()
                    if not detail:
                        detail = "Enter 3 positive integers or a diagonal 3x3 integer matrix"
                    print(
                        f"  ERROR: {detail} "
                        f"({3 - failures} attempt(s) left)"
                    )
                    continue
                explicit_supercell = (dims[0], dims[1], dims[2])
                break
            if explicit_supercell is None:
                print("  ERROR: Too many invalid supercell inputs. Exiting step.")
                return False
            self.state.resolved_supercell_expansion = explicit_supercell
            scale = explicit_supercell[0] * explicit_supercell[1] * explicit_supercell[2]
            target_atoms = base_atoms * scale
            actual_sites = {kind: count * scale for kind, count in element_counts.items()}
            print(
                f"\n  ✓ Explicit supercell: {explicit_supercell[0]}×{explicit_supercell[1]}×{explicit_supercell[2]} "
                f"= {target_atoms} atoms"
            )
            self._print_supercell_cell_metrics(explicit_supercell)
        else:
            print("Common target sizes (ESS will auto-determine supercell):")
            for scale, atoms in common_scales:
                print(f"  {scale}× scale: {atoms} atoms")
            print("  Or enter any custom number")

            # Get target atom count
            def validate_atoms(val: int) -> Tuple[bool, str]:
                if val <= 0:
                    return False, "Must be > 0"
                if val < len(self.state.mapped_elements):
                    return False, f"Must be >= {len(self.state.mapped_elements)} (one atom per element)"
                return True, ""

            target_atoms = self.prompt_input(
                "Target number of atoms",
                int,
                default=None,
                validator=validate_atoms
            )

            # Probe the actual supercell esspy will choose for this target
            print(f"\n  Checking actual supercell for target={target_atoms}...", end="", flush=True)
            probe = self._probe_actual_supercell(target_atoms)
            if probe:
                sc = probe["supercell"]
                n_actual = probe["n_actual"]
                actual_sites = probe["sites_per_kind"]
                self.state.resolved_supercell_expansion = (
                    int(sc[0]),
                    int(sc[1]),
                    int(sc[2]),
                )
                if n_actual != target_atoms:
                    print(f"\r  ✓ ESS supercell: {sc[0]}×{sc[1]}×{sc[2]} = {n_actual} atoms  "
                          f"(requested {target_atoms} → nearest valid supercell is {n_actual})")
                else:
                    print(f"\r  ✓ ESS supercell: {sc[0]}×{sc[1]}×{sc[2]} = {n_actual} atoms        ")
                self._print_supercell_cell_metrics((int(sc[0]), int(sc[1]), int(sc[2])))
                # Use actual supercell size as the target for composition
                target_atoms = n_actual
            else:
                print(f"\r  (supercell check skipped)                              ")
                actual_sites = {}

        self.state.target_atoms = target_atoms
        self.state.supercell_expansion = explicit_supercell

        supercell_scale = target_atoms / base_atoms if base_atoms > 0 else 1.0

        # Build reverse mapping: mapped_element → original_element(s) and actual site counts
        reverse_mapping: Dict[str, List[Tuple[str, int]]] = {}
        for orig_elem, mapped_list in self.state.element_mapping.items():
            # Use probe result if available, else fall back to naive scaling
            supercell_count = actual_sites.get(orig_elem, int(element_counts[orig_elem] * supercell_scale))
            for mapped_elem in mapped_list:
                if mapped_elem not in reverse_mapping:
                    reverse_mapping[mapped_elem] = []
                reverse_mapping[mapped_elem].append((orig_elem, supercell_count))

        fixed_global_counts = self._infer_fixed_global_element_counts(
            actual_sites,
            element_counts,
            supercell_scale,
        )
        fixed_global_total = int(sum(fixed_global_counts.values()))
        variable_target_atoms = int(target_atoms) - fixed_global_total
        if variable_target_atoms < 0:
            print(
                "\n  ERROR: fixed no-substitution site counts exceed target atoms: "
                f"{fixed_global_total} > {target_atoms}"
            )
            return False

        # Site-wise mode: collect per-group compositions, then aggregate globally.
        if self.state.composition_mode == "sitewise":
            composition_by_site: Dict[str, Dict[str, int]] = {}
            aggregated: Dict[str, int] = {e: 0 for e in self.state.mapped_elements}
            print("\nSite-wise mode selected.")
            sitewise_mode_choice = self.render_menu(
                "\nSelect site-wise composition value input mode:",
                [
                    "Atom counts (integers; each site-group total must match slots)",
                    "Fractions/ratios (normalized separately inside each site-group)",
                ],
                default_index=0,
            )
            sitewise_input_mode = "int" if sitewise_mode_choice == 0 else "fraction"
            for group_name, group_info in self.state.site_groups.items():
                source_kind = str(group_info["source_kind"])
                allowed = list(group_info["allowed"])
                group_slots = int(actual_sites.get(source_kind, group_info["count"]))
                print(
                    f"\n{group_name} (source={source_kind}, slots={group_slots})"
                )
                print(f"Allowed elements: {', '.join(allowed)}")
                local_values: Dict[str, float] = {}
                if len(allowed) > 1:
                    print("  Tip: enter 'back' (or 'b') to edit the previous element.")
                element_index = 0
                while element_index < len(allowed):
                    element = allowed[element_index]
                    parse_failures = 0
                    while True:
                        if sitewise_input_mode == "int":
                            try:
                                parsed_value = self.prompt_input(
                                    f"  {element} atom count",
                                    int,
                                    default=0,
                                    validator=lambda value: (
                                        value >= 0,
                                        "Atom count must be an integer >= 0",
                                    ),
                                    allow_back=element_index > 0,
                                )
                            except _WizardBack:
                                previous = allowed[element_index - 1]
                                local_values.pop(previous, None)
                                element_index -= 1
                                print(f"  Back to {previous}.")
                                break
                            except Exception:
                                parse_failures += 1
                                print("  ERROR: Atom count mode accepts integers only")
                                if parse_failures >= 3:
                                    print("  ERROR: Too many invalid inputs. Exiting step.")
                                    return False
                                continue
                        else:
                            try:
                                raw = self.prompt_input(
                                    f"  {element} fraction/ratio",
                                    str,
                                    default="0",
                                    allow_back=element_index > 0,
                                )
                            except _WizardBack:
                                previous = allowed[element_index - 1]
                                local_values.pop(previous, None)
                                element_index -= 1
                                print(f"  Back to {previous}.")
                                break
                            try:
                                _, parsed_value = _parse_count_input(raw)
                            except Exception:
                                parse_failures += 1
                                print("  ERROR: Must be a number >= 0 (decimal, integer ratio, or fraction a/b)")
                                if parse_failures >= 3:
                                    print("  ERROR: Too many invalid inputs. Exiting step.")
                                    return False
                                continue
                        if element_index < len(allowed) and element != allowed[element_index]:
                            break
                        local_values[element] = float(parsed_value)
                        element_index += 1
                        break

                local_total = float(sum(local_values.values()))
                if local_total <= 0:
                    print(f"  ERROR: {group_name} total is 0. Provide at least one non-zero value.")
                    return False

                # Convert to integer counts per site-group slot count.
                local_counts: Dict[str, int] = {}
                if sitewise_input_mode == "fraction":
                    print(
                        f"  Interpreting {group_name} values as fractions/ratios (sum={local_total:.4f}), "
                        f"normalizing to {group_slots} slots."
                    )
                    local_counts = _counts_from_fraction_values(local_values, group_slots)
                else:
                    for element, value in local_values.items():
                        local_counts[element] = int(value)

                count_total = int(sum(local_counts.values()))
                if count_total != group_slots:
                    diff = group_slots - count_total
                    largest = max(local_counts, key=local_counts.get)
                    local_counts[largest] += diff
                    print(
                        f"  Auto-adjusting {group_name}: {largest} "
                        f"{local_counts[largest] - diff} -> {local_counts[largest]} "
                        f"to match {group_slots} slots."
                    )
                if any(v < 0 for v in local_counts.values()):
                    print(f"  ERROR: negative site count detected in {group_name} after normalization.")
                    return False

                local_summary = ", ".join(f"{k}={v}" for k, v in local_counts.items() if v > 0)
                print(f"  {group_name} normalized counts: {local_summary}")
                composition_by_site[group_name] = local_counts
                for element, count in local_counts.items():
                    aggregated[element] = aggregated.get(element, 0) + int(count)

            # remove zero-count elements for cleaner output / yaml
            aggregated = {k: v for k, v in aggregated.items() if v > 0}
            self.state.composition_by_site = composition_by_site
            self.state.composition = aggregated
            total_aggregated = sum(aggregated.values())
            self.state.composition_fractions = (
                {k: v / total_aggregated for k, v in aggregated.items()}
                if total_aggregated > 0
                else {}
            )
            self.state.composition_valid = True

            comp_str = " + ".join(f"{k}{v}" for k, v in aggregated.items())
            print(f"\n✓ Aggregated global composition: {comp_str} = {sum(aggregated.values())} atoms")
            return True

        # Global mode: ask explicitly whether values are counts or fractions.
        input_mode_choice = self.render_menu(
            "\nSelect composition value input mode:",
            [
                "Atom counts (integers; total must match target atoms)",
                "Fractions/ratios (will be normalized to target atoms)",
            ],
            default_index=0,
        )
        composition_input_mode = "int" if input_mode_choice == 0 else "fraction"
        if composition_input_mode == "int":
            if fixed_global_counts:
                fixed_text = " + ".join(f"{k}{v}" for k, v in fixed_global_counts.items())
                print(f"\nFixed no-substitution elements are auto-filled: {fixed_text}")
                print(
                    f"Specify integer atom count for variable elements "
                    f"(total must = {variable_target_atoms}):"
                )
            else:
                print(f"\nSpecify integer atom count for each mapped element (total must = {target_atoms}):")
        else:
            if fixed_global_counts:
                fixed_text = " + ".join(f"{k}{v}" for k, v in fixed_global_counts.items())
                print(f"\nFixed no-substitution elements are auto-filled: {fixed_text}")
                print(
                    f"Specify fraction/ratio for variable elements only "
                    f"(normalized to {variable_target_atoms} remaining atoms)."
                )
            else:
                print("\nSpecify fraction/ratio for each mapped element.")
            print("  Examples: 0.0625, 6.25, 1/16, or raw ratios like 1,2,3")
            print("  Values are normalized automatically before scaling to target atoms.")

        input_elements = [
            element
            for element in self.state.mapped_elements
            if element not in fixed_global_counts
        ]
        composition: Dict[str, float] = {
            element: float(count)
            for element, count in fixed_global_counts.items()
        }
        variable_values: Dict[str, float] = {}
        total = 0.0

        if len(input_elements) > 1:
            print("  Tip: enter 'back' (or 'b') to edit the previous element.")

        element_index = 0
        while element_index < len(input_elements):
            element = input_elements[element_index]
            # Show static site capacities for this element.
            # NOTE:
            #   In global composition mode, per-site allocation is decided later
            #   (auto-allocation or manual sitewise step), so we should not
            #   decrement these capacities during element-by-element input.
            if element in reverse_mapping:
                sources = reverse_mapping[element]
                parts = []
                for orig, total_slots in sources:
                    parts.append(f"{orig} site: {total_slots} available")
                print(f"\n  {element}")
                print(f"    ({', '.join(parts)})")

            count: float | None = None
            parse_failures = 0
            moved_back = False
            while True:
                if composition_input_mode == "int":
                    try:
                        parsed_value = self.prompt_input(
                            f"  {element} atom count",
                            int,
                            default=0,
                            validator=lambda value: (
                                value >= 0,
                                "Atom count must be an integer >= 0",
                            ),
                            allow_back=element_index > 0,
                        )
                    except _WizardBack:
                        previous = input_elements[element_index - 1]
                        variable_values.pop(previous, None)
                        composition.pop(previous, None)
                        element_index -= 1
                        moved_back = True
                        print(f"  Back to {previous}.")
                        break
                    except Exception:
                        parse_failures += 1
                        print("  ERROR: Atom count mode accepts integers only")
                        if parse_failures >= 3:
                            print("  ERROR: Too many invalid inputs. Exiting step.")
                            return False
                        continue
                else:
                    try:
                        count_input = self.prompt_input(
                            f"  {element} fraction/ratio",
                            str,
                            default="0",
                            allow_back=element_index > 0,
                        )
                    except _WizardBack:
                        previous = input_elements[element_index - 1]
                        variable_values.pop(previous, None)
                        composition.pop(previous, None)
                        element_index -= 1
                        moved_back = True
                        print(f"  Back to {previous}.")
                        break
                    try:
                        _, parsed_value = _parse_count_input(count_input)
                    except Exception:
                        parse_failures += 1
                        print("  ERROR: Must be a number >= 0 (decimal, integer ratio, or fraction a/b)")
                        if parse_failures >= 3:
                            print("  ERROR: Too many invalid inputs. Exiting step.")
                            return False
                        continue
                    if "/" in count_input:
                        print(f"  -> Parsed fraction: {count_input.strip()} = {parsed_value:.10f}")

                if element_index < len(input_elements) and element != input_elements[element_index]:
                    break
                count = float(parsed_value)
                break

            if moved_back:
                continue

            assert count is not None

            variable_values[element] = count
            composition[element] = count
            element_index += 1

        total = float(sum(variable_values.values()))

        composition_fractions: Dict[str, float]
        if composition_input_mode == "fraction":
            if variable_target_atoms > 0 and total <= 0:
                print("\n  ERROR: Fraction/ratio inputs must sum to a positive number")
                return False
            print(f"\n  Interpreting as fractions/ratios (sum: {total:.6g})")
            if abs(total - 1.0) > 1.0e-8:
                print("  Normalizing fractions so their sum becomes 1.0")
            print(f"  Scaling variable elements to remaining atoms ({variable_target_atoms})...")
            variable_counts = (
                _counts_from_fraction_values(variable_values, variable_target_atoms)
                if variable_target_atoms > 0
                else {}
            )
            composition = {
                **{kind: int(count) for kind, count in fixed_global_counts.items()},
                **{kind: int(count) for kind, count in variable_counts.items()},
            }
            total = sum(composition.values())
            print(
                "  Normalized counts: "
                f"{' + '.join(f'{k}{int(v)}' for k, v in composition.items())} = {int(total)}"
            )
            composition_fractions = {}
        else:
            composition_fractions = {}
            total = fixed_global_total + total

        # Check final sum. Integer inputs are treated as literal counts.
        if total != target_atoms:
            print(f"\n  ERROR: Sum ({int(total)}) ≠ target ({target_atoms})")
            print(f"  Difference: {target_atoms - int(total)} atoms")

            # Auto-correction: adjust most abundant element
            if composition:
                adjustable = {
                    kind: value
                    for kind, value in composition.items()
                    if kind not in fixed_global_counts
                }
                if not adjustable:
                    print("  ERROR: No variable elements available for auto-adjustment")
                    return False
                largest_element = max(adjustable, key=adjustable.get)
                adjustment = target_atoms - int(total)
                composition[largest_element] += adjustment

                print(f"\n  → Auto-adjusting {largest_element}: {composition[largest_element] - adjustment} → {composition[largest_element]}")

                if not self.confirm(f"  Accept adjustment?"):
                    return False
            else:
                print("  ERROR: No elements with count > 0")
                return False

        # Convert all to integers for final composition
        ordered_composition: Dict[str, int] = {}
        for kind in self.state.mapped_elements:
            if kind in composition:
                ordered_composition[kind] = int(composition[kind])
        for kind, value in composition.items():
            if kind not in ordered_composition:
                ordered_composition[kind] = int(value)
        composition = ordered_composition
        if not composition_fractions:
            composition_fractions = {
                kind: (count / target_atoms if target_atoms > 0 else 0.0)
                for kind, count in composition.items()
            }

        self.state.composition = composition
        self.state.composition_fractions = composition_fractions
        self.state.composition_valid = True

        # Show summary
        comp_str = " + ".join(f"{k}{v}" for k, v in composition.items())
        print(f"\n✓ Composition valid: {comp_str} = {sum(composition.values())} atoms")

        return True

    def step_4_oxidation_states(self) -> bool:
        """Step 4: Specify oxidation states and ensure charge neutrality.

        Returns:
            True if charges are acceptable
        """
        print("\n" + "="*60)
        print("Step 6/7: Charge Basis, Oxidation States & Charge Neutrality")
        print("="*60)

        if not self.state.composition:
            print("ERROR: No composition specified")
            return False

        basis_choice = self.render_menu(
            "\nChoose charge basis:",
            [
                "Element-only (single charge per element)",
                "Element + Site-group (different charge per site-group)",
            ],
            default_index=1,
        )
        self.state.charge_basis = "element+site_group" if basis_choice == 1 else "element"

        charges: Dict[str, float] = {}
        charges_by_site: Dict[str, float] = {}

        def validate_charge(val: float) -> Tuple[bool, str]:
            if -10 <= val <= 10:
                return True, ""
            return False, "Must be between -10 and +10"

        if self.state.charge_basis == "element+site_group":
            print("\nLookup site-aware oxidation states:")
            print("Format: Element@site_group (e.g., Mn@site1, Cr@site2)")
            elements = list(self.state.composition.keys())
            for group_name, info in self.state.site_groups.items():
                allowed = [e for e in info.get("allowed", []) if e in elements]
                if not allowed:
                    continue
                print(f"\n  {group_name} (source={info.get('source_kind')})")
                for element in allowed:
                    key = f"{element}@{group_name}"
                    charge = self.prompt_input(
                        f"    {key} oxidation state",
                        float,
                        default=suggest_default_charge(element),
                        validator=validate_charge,
                    )
                    charges_by_site[key] = charge

            # Aggregate site-aware charges to element charges for backward-compatible output.
            if self.state.composition_mode == "sitewise" and self.state.composition_by_site:
                for element in elements:
                    num = 0.0
                    den = 0.0
                    for group_name, group_comp in self.state.composition_by_site.items():
                        count = float(group_comp.get(element, 0))
                        if count <= 0:
                            continue
                        key = f"{element}@{group_name}"
                        if key not in charges_by_site:
                            continue
                        num += count * charges_by_site[key]
                        den += count
                    if den > 0:
                        charges[element] = num / den
                    else:
                        charges[element] = float(suggest_default_charge(element))
            else:
                print(
                    "\n  NOTE: site-wise composition is not active; "
                    "element charges are averaged over available site-groups."
                )
                for element in elements:
                    vals: List[float] = []
                    for group_name in self.state.site_groups.keys():
                        key = f"{element}@{group_name}"
                        if key in charges_by_site:
                            vals.append(float(charges_by_site[key]))
                    charges[element] = (
                        float(sum(vals) / len(vals)) if vals else float(suggest_default_charge(element))
                    )
        else:
            print("\nLookup typical oxidation states:")
            for element in self.state.composition.keys():
                charge = self.prompt_input(
                    f"  {element} oxidation state",
                    float,
                    default=suggest_default_charge(element),
                    validator=validate_charge
                )
                charges[element] = charge

        self.state.charges = charges
        self.state.charges_by_site = charges_by_site

        # Check charge balance
        net_charge = self._calculate_net_charge()
        print(f"\nNet charge (from aggregated element charges): {net_charge:.2f}")

        if abs(net_charge) > 0.01:
            print(f"  WARNING: System is not electrically neutral!")

            # Suggest adjustment
            adjustment_options = self._suggest_charge_adjustments()
            if adjustment_options:
                print("\n  Charge neutralization options:")
                for i, (element, new_charge, description) in enumerate(adjustment_options, 1):
                    print(f"    {i}) Adjust {element}: {self.state.charges[element]:.2f} → {new_charge:.2f}")
                    print(f"       ({description})")
                print(f"    {len(adjustment_options) + 1}) Keep as-is (unusual charges)")

                choice = self.render_menu(
                    "Select charge adjustment:",
                    [f"Option {i}" for i in range(len(adjustment_options) + 1)],
                    default_index=0,
                )

                if choice < len(adjustment_options):
                    element, new_charge, _ = adjustment_options[choice]
                    self.state.charges[element] = new_charge
                    net_charge = self._calculate_net_charge()
                    print(f"\n  ✓ Adjusted. New net charge: {net_charge:.2f}")

            # Final confirmation
            if not self.confirm("\n  Continue with current charges?", default_yes=True):
                return False
        else:
            print("  ✓ System is electrically neutral")

        self.state.charges_balanced = True
        return True

    def step_5_substitution_recipes(self) -> bool:
        """Step 5: Define substitution recipes.

        Returns:
            True if recipes are valid
        """
        print("\n" + "="*60)
        print("Step 5/7: Substitution Recipes")
        print("="*60)

        if not self.state.composition:
            print("ERROR: No composition specified")
            return False

        target_elements = list(self.state.composition.keys())
        source_elements = (
            list(self.state.element_mapping.keys())
            if self.state.element_mapping
            else target_elements
        )
        print(f"\nReference source site kinds: {', '.join(source_elements)}")
        print(f"Target composition elements: {', '.join(target_elements)}")

        recipes: Dict[str, List[str]] = {}
        auto_from_site_groups: Dict[str, List[str]] = {}
        if self.state.site_groups:
            for group_info in self.state.site_groups.values():
                source = str(group_info.get("source_kind"))
                allowed = [t for t in group_info.get("allowed", []) if t in target_elements]
                if source and allowed:
                    auto_from_site_groups[source] = allowed

        if auto_from_site_groups:
            print("\nDetected recipe candidates from site groups:")
            for source, targets in auto_from_site_groups.items():
                print(f"  {source} -> {{{','.join(targets)}}}")
            if self.state.composition_mode == "global":
                print(
                    "\n  NOTE: global composition does not explicitly constrain per-site occupancy. "
                    "Use site-wise mode when you want explicit site allocations."
                )

            if self.confirm("Use detected recipes?", default_yes=True):
                self.state.recipes = auto_from_site_groups
                self.state.recipes_valid = True
                print("\n✓ Recipes defined from site groups.")
                return True
            print("  Proceeding to manual recipe editing.\n")

        print("\nDefine substitution rules for each reference source site kind.")
        print("Format: comma or space separated list of target elements")
        print("Example: for M, enter 'Mn,Ni,Cr' or 'Mn Ni Cr' to allow M → Mn, Ni, or Cr\n")

        for element in source_elements:
            default_targets = (
                [
                    target
                    for target in self.state.element_mapping.get(element, [element])
                    if target in target_elements
                ]
                if self.state.element_mapping
                else [element]
            )
            if not default_targets:
                default_targets = [element] if element in target_elements else []

            default_text = ",".join(default_targets) if default_targets else "(none)"
            targets_input = input(f"  {element} → [default {default_text}]: ").strip()

            if not targets_input:
                targets = list(default_targets)
            else:
                targets = _parse_element_list(targets_input)

            # Validate targets (must be in composition)
            invalid = [t for t in targets if t not in target_elements]
            if invalid:
                print(f"    ERROR: Invalid elements {invalid}. Using default [{default_text}]")
                targets = list(default_targets)

            recipes[element] = targets

        self.state.recipes = recipes
        self.state.recipes_valid = True

        # Show summary
        print("\n✓ Recipes defined:")
        for from_elem, to_elems in recipes.items():
            to_str = ",".join(to_elems)
            print(f"   {from_elem} → {{{to_str}}}")

        return True

    def step_6_solve_strategy(self) -> bool:
        """Step 6: Configure user-facing solve strategy."""
        print("\n" + "=" * 60)
        print("Step 6/6: Solve Strategy")
        print("=" * 60)
        print("\nSelect exploration mode:")
        print("  - adaptive: time-budgeted sparse sampling (recommended)")
        print("  - bounded_exhaustive: stride=1 with finite chunk budget")
        print("  - exhaustive: stride=1 with exhaustive traversal intent")
        print("\nEffort controls local chunk size/budget:")
        print("  low | medium | high | extreme")
        print("\nExecution mode controls runtime behavior:")
        print("  - quick: faster feedback, better for small or interactive runs")
        print("  - scalable: higher throughput, better for multi-rank MPI runs")

        mode_options = ["adaptive", "bounded_exhaustive", "exhaustive"]
        mode_choice = self.render_menu(
            "Choose solve mode:",
            [f"{item}" for item in mode_options],
            default_index=0,
        )
        if mode_choice < 0:
            return False
        self.state.solve_mode = mode_options[mode_choice]

        effort_options = ["low", "medium", "high", "extreme"]
        effort_choice = self.render_menu(
            "Choose effort level:",
            [f"{item}" for item in effort_options],
            default_index=2,
        )
        if effort_choice < 0:
            return False
        self.state.solve_effort = effort_options[effort_choice]

        execution_mode_options = ["quick", "scalable"]
        execution_mode_choice = self.render_menu(
            "Choose execution mode:",
            [f"{item}" for item in execution_mode_options],
            default_index=0,
        )
        if execution_mode_choice < 0:
            return False
        self.state.solve_execution_mode = execution_mode_options[execution_mode_choice]

        if self.state.solve_mode == "adaptive":
            self.state.solve_time_budget_sec = self.prompt_input(
                "Adaptive time budget in seconds",
                int,
                default=600,
                validator=lambda value: (value > 0, "Must be > 0"),
            )
        else:
            self.state.solve_time_budget_sec = 600
        if self.state.composition_mode == "global":
            default_allocation_budget = 180
            self.state.allocation_time_budget_sec = self.prompt_input(
                "Site allocation search time budget in seconds",
                int,
                default=default_allocation_budget,
                validator=lambda value: (value > 0, "Must be > 0"),
            )

        self.state.solve_swap_enabled = self.confirm(
            "Enable swap optimization?",
            default_yes=True,
        )
        if self.state.solve_swap_enabled:
            self.state.solve_swap_max_steps = self.prompt_input(
                "Max swap steps",
                int,
                default=100,
                validator=lambda value: (value >= 0, "Must be >= 0"),
            )
        else:
            self.state.solve_swap_max_steps = 0

        print("\n✓ Solve strategy configured:")
        print(f"  mode={self.state.solve_mode}")
        if self.state.solve_mode == "adaptive":
            print(f"  time_budget_sec={self.state.solve_time_budget_sec}")
        if self.state.composition_mode == "global":
            print(f"  allocation.time_budget_sec={self.state.allocation_time_budget_sec}")
        print(f"  effort={self.state.solve_effort}")
        print(f"  execution_mode={self.state.solve_execution_mode}")
        print(
            f"  swap.enabled={self.state.solve_swap_enabled}, "
            f"swap.max_steps={self.state.solve_swap_max_steps}"
        )
        return True

    def step_7_output_selection(self) -> bool:
        """Step 7: Configure post-solve structure selection outputs."""
        print("\n" + "=" * 60)
        print("Step 7/7: Output Selection")
        print("=" * 60)
        print("\nChoose whether to export selected structures after solve.")

        self.state.selection_enabled = self.confirm(
            "Export selected structures after solve?",
            default_yes=True,
        )
        if not self.state.selection_enabled:
            print("\n✓ Output selection disabled.")
            return True

        mode_options = ["auto_top_n", "energy_window"]
        mode_choice = self.render_menu(
            "Selection mode:",
            ["auto_top_n (recommended)", "energy_window"],
            default_index=0,
        )
        if mode_choice < 0:
            return False
        self.state.selection_mode = mode_options[mode_choice]

        self.state.selection_limit = self.prompt_input(
            "How many structures?",
            int,
            default=20,
            validator=lambda value: (value > 0, "Must be > 0"),
        )

        pick_options = ["lowest", "highest", "random"]
        pick_choice = self.render_menu(
            "Pick policy:",
            ["lowest energy", "highest energy", "random"],
            default_index=0,
        )
        if pick_choice < 0:
            return False
        self.state.selection_pick = pick_options[pick_choice]

        if self.state.selection_pick == "random":
            seed_raw = input("Random seed [empty=none]: ").strip()
            self.state.selection_seed = int(seed_raw) if seed_raw else None
        else:
            self.state.selection_seed = None

        if self.state.selection_mode == "energy_window":
            interval_options = ["left-closed", "closed", "open", "right-closed"]
            interval_choice = self.render_menu(
                "Interval mode:",
                interval_options,
                default_index=0,
            )
            if interval_choice < 0:
                return False
            self.state.selection_interval = interval_options[interval_choice]
        else:
            self.state.selection_interval = "left-closed"

        self.state.selection_outdir = self.prompt_input(
            "Output folder",
            str,
            default="selected_structures",
        )
        self.state.selection_prefix = self.prompt_input(
            "Filename prefix",
            str,
            default="selected",
        )

        print("\n✓ Output selection configured:")
        print(f"  enabled={self.state.selection_enabled}")
        print(f"  mode={self.state.selection_mode}")
        print(f"  limit={self.state.selection_limit}")
        print(f"  pick={self.state.selection_pick}")
        print(f"  interval={self.state.selection_interval}")
        print(f"  outdir={self.state.selection_outdir}")
        print(f"  prefix={self.state.selection_prefix}")
        return True

    # ===== Interstitial Scenario Steps =====

    def step_1_base_structure_fixed(self) -> bool:
        """Step 1B: Load base structure (Scenario B).

        Returns:
            True if structure loaded
        """
        print("\n" + "="*60)
        print("Step 1/5: Base Structure (Fixed)")
        print("="*60)

        # Get available POSCAR files and let user choose
        poscar_files = self._get_poscar_files()

        if poscar_files:
            # Show files as menu options
            options = [f.name for f in sorted(poscar_files)[:10]]
            options.append("Other file (manual path)")

            print("\nSelect a POSCAR file:")
            file_choice = self.render_menu("", options)

            if file_choice < len(poscar_files):
                poscar_path = sorted(poscar_files)[file_choice]
            else:
                # Manual path input - show all files in current directory
                print("\nFiles in current directory:")
                self._show_directory_contents()
                print("\nEnter file name or path:")
                poscar_path = self.prompt_input("POSCAR file path", str)
                poscar_path = Path(poscar_path)
        else:
            # No files found, ask for manual input
            print("\n(No POSCAR files found in current directory)")
            poscar_path = self.prompt_input("POSCAR file path", str)
            poscar_path = Path(poscar_path)

        try:
            if not poscar_path.exists():
                print(f"  ERROR: File not found: {poscar_path}")
                return False

            self.state.structure = load_poscar(str(poscar_path))
            self.state.reference_structure = str(poscar_path)

            formula = self._get_formula_from_structure()
            n_atoms = len(self.state.structure.sites)
            print(f"\n✓ Loaded {poscar_path.name}")
            print(f"  Formula: {formula}")
            print(f"  Total atoms: {n_atoms}")

            return True
        except Exception as e:
            print(f"  ERROR: Failed to load POSCAR: {e}")
            return False

    def step_2_supercell_size(self) -> bool:
        """Step 2B: Define supercell size (Scenario B).

        Returns:
            True if target atoms specified
        """
        print("\n" + "="*60)
        print("Step 2/5: Supercell Size")
        print("="*60)

        if not self.state.structure:
            print("ERROR: No structure loaded")
            return False

        formula = self._get_formula_from_structure()
        current_n_atoms = len(self.state.structure.sites)

        print(f"\nBase structure: {formula} ({current_n_atoms} atoms)")
        print("Define the host supercell size (before adding interstitials)")

        # Show common supercell sizes
        common_scales = [
            (2, current_n_atoms * 2),
            (3, current_n_atoms * 3),
            (4, current_n_atoms * 4),
        ]

        print("\nCommon supercell sizes:")
        for scale, atoms in common_scales:
            print(f"  {scale}× scale: {atoms} atoms")
        print("  Or enter any custom number")

        def validate_atoms(val: int) -> Tuple[bool, str]:
            if val <= 0:
                return False, "Must be > 0"
            if val < len(set(site.kind for site in self.state.structure.sites)):
                return False, "Must have at least 1 atom of each element type"
            return True, ""

        target_atoms = self.prompt_input(
            "Target supercell atoms",
            int,
            default=None,
            validator=validate_atoms
        )
        self.state.target_atoms = target_atoms

        print(f"\n✓ Supercell size set to {target_atoms} atoms")

        return True

    def step_3_host_element_composition(self) -> bool:
        """Step 3B: Define host element composition in supercell (Scenario B).

        Returns:
            True if composition is valid
        """
        print("\n" + "="*60)
        print("Step 3/5: Host Element Composition")
        print("="*60)

        if not self.state.structure:
            print("ERROR: No structure loaded")
            return False

        # Count atoms per element in base structure
        element_counts: Dict[str, int] = {}
        for site in self.state.structure.sites:
            element_counts[site.kind] = element_counts.get(site.kind, 0) + 1

        elements_in_structure = sorted(element_counts.keys())
        formula = self._get_formula_from_structure()
        n_atoms = len(self.state.structure.sites)

        print(f"\nBase structure: {formula} ({n_atoms} atoms)")
        for element in elements_in_structure:
            count = element_counts[element]
            percentage = 100 * count / n_atoms
            print(f"  {element}: {count} atoms ({percentage:.1f}%)")

        print(f"\nSupercell target: {self.state.target_atoms} atoms")
        print("Specify count for each host element:")

        composition: Dict[str, int] = {}
        total = 0

        for element in elements_in_structure:
            # Suggest proportional count based on base structure
            base_count = element_counts[element]
            scale_factor = self.state.target_atoms / n_atoms
            suggested_count = int(base_count * scale_factor)

            def validate_count(val: int) -> Tuple[bool, str]:
                if val < 0:
                    return False, "Must be >= 0"
                return True, ""

            count = self.prompt_input(
                f"  {element} count",
                int,
                default=suggested_count,
                validator=validate_count
            )

            composition[element] = count
            total += count

        # Validate total matches target
        original_total = total
        if total != self.state.target_atoms:
            print(f"\n  ⚠ Sum of elements ({total}) ≠ Target ({self.state.target_atoms})")

            # Auto-adjust largest element
            if total < self.state.target_atoms:
                diff = self.state.target_atoms - total
                largest_elem = max(composition.items(), key=lambda x: x[1])[0]
                composition[largest_elem] += diff
                print(f"  → Adjusting {largest_elem} by +{diff}")
            else:
                diff = total - self.state.target_atoms
                largest_elem = max(composition.items(), key=lambda x: x[1])[0]
                if composition[largest_elem] >= diff:
                    composition[largest_elem] -= diff
                    print(f"  → Adjusting {largest_elem} by -{diff}")
                else:
                    print(f"  ERROR: Cannot auto-adjust. Please try again.")
                    return False

            total = sum(composition.values())

        self.state.composition = composition

        print(f"\n✓ Host composition defined:")
        comp_str = " + ".join(f"{k}{v}" for k, v in composition.items())
        print(f"  {comp_str} = {total} atoms")
        if original_total != total:
            print(f"  (Adjusted: {original_total} → {total} to match target)")

        return True

    def step_4_interstitial_species_count(self) -> bool:
        """Step 4B: Specify interstitial species and count (Scenario B).

        Returns:
            True if species and count specified
        """
        print("\n" + "="*60)
        print("Step 4/5: Interstitial Species & Count")
        print("="*60)

        if not self.state.structure:
            print("ERROR: No structure loaded")
            return False

        elements_in_structure = sorted(set(site.kind for site in self.state.structure.sites))
        print(f"\nHost structure elements: {', '.join(elements_in_structure)}")

        try:
            species = self.prompt_input(
                "Interstitial species (e.g., Li, H etc.)",
                str,
                max_attempts=3,
            ).strip().capitalize()
        except RuntimeError:
            print("ERROR: Interstitial species input failed 3 times. Aborting wizard.")
            return False

        def validate_count(val: int) -> Tuple[bool, str]:
            if val <= 0:
                return False, "Must be > 0"
            return True, ""

        count = self.prompt_input(
            "Number of interstitial atoms to add",
            int,
            validator=validate_count
        )

        self.state.interstitial_species = species
        self.state.interstitial_count = count

        host_total = sum(self.state.composition.values()) if self.state.composition else self.state.target_atoms
        new_total = host_total + count
        print(f"\n✓ Will add {count} {species} atom(s)")
        print(f"  Host supercell: {host_total} atoms")
        print(f"  With {species}: {new_total} atoms total")

        return True

    def step_6_add_sites_parameters(self) -> Dict[str, str]:
        """Step 6B: Configure add-sites parameters (Scenario B, auto-optimal).

        Returns:
            Dictionary with add-sites config: {AddMeshes, MinDistance, NMonteCarlo, RGFindFactor, ...}
        """
        print("\n" + "="*60)
        print("Step 6/6: Add-Sites Configuration")
        print("="*60)

        if not self.state.interstitial_species:
            return {}

        # Auto-determine optimal parameters based on structure
        config = self._auto_determine_add_sites_params()

        print(f"\n✓ Auto-optimized parameters for {self.state.interstitial_species}:")
        print(f"  AddMeshes (grid spacing): {config['AddMeshes']}")
        print(f"  MinDistance (Å): {config['MinDistanceBetweenAddedSites']}")
        print(f"  NMonteCarlo (trials): {config['NMonteCarlo']}")
        print(f"  RGFindFactor (search radius): {config['RGFindFactor']}")
        print(f"  Symmetry detection: {'enabled' if config['detect_symmetry'] else 'disabled'}")

        # Option to override
        thorough_p = _get_preset_params('thorough')
        print(f"\nPresets:")
        print(f"  1) Thorough — grid {thorough_p[0]}, minDist {thorough_p[1]} Å, {thorough_p[2]} MC trials  (default)")
        print(f"  2) Custom   — set each parameter manually")
        choice = self.prompt_input("Choose preset (1-2)", int, default=1)

        if choice == 2:
            config = self._customize_add_sites_config(config)
        else:
            config = self._get_preset_config('thorough', config)

        print(f"\n✓ Final configuration:")
        print(f"  AddMeshes: {config['AddMeshes']}")
        print(f"  MinDistance: {config['MinDistanceBetweenAddedSites']} Å")
        print(f"  NMonteCarlo: {config['NMonteCarlo']} trials")
        print(f"  RGFindFactor: {config['RGFindFactor']}")
        print(f"  Symmetry: {'enabled' if config['detect_symmetry'] else 'disabled'}")

        return config

    def _auto_determine_add_sites_params(self) -> Dict[str, str]:
        """Auto-determine optimal add-sites parameters based on structure.

        Considers:
        - Lattice size → AddMeshes
        - Host composition → MinDistance
        - System complexity → NMonteCarlo
        - Crystal type → RGFindFactor, symmetry
        """
        import numpy as np

        config = {}

        # 1. Estimate AddMeshes from lattice size
        if self.state.structure and hasattr(self.state.structure, 'cell'):
            lattice = self.state.structure.cell.matrix
            # Calculate average lattice parameter
            a = np.linalg.norm(lattice[0])
            b = np.linalg.norm(lattice[1])
            c = np.linalg.norm(lattice[2])
            avg_lattice = (a + b + c) / 3

            # Mesh size inversely proportional to lattice
            if avg_lattice < 3:
                meshes = "1.0 1.0 1.0"
            elif avg_lattice < 5:
                meshes = "0.5 0.5 0.5"
            else:
                meshes = "0.3 0.3 0.3"
            config['AddMeshes'] = meshes
        else:
            config['AddMeshes'] = "0.5 0.5 0.5"

        # 2. Estimate MinDistance from interstitial species
        # Li: small, needs ~1.0 Å
        # Ni, Fe, Co: medium, needs ~1.2 Å
        # Large cations: need ~1.5+ Å
        species = self.state.interstitial_species
        if species in ['Li', 'H']:
            min_dist = "1.0"
        elif species in ['Ni', 'Fe', 'Co', 'Cu', 'Zn', 'Mn']:
            min_dist = "1.2"
        else:  # larger cations
            min_dist = "1.5"
        config['MinDistanceBetweenAddedSites'] = min_dist

        # 3. Estimate NMonteCarlo from target atoms
        n_target = self.state.target_atoms
        if n_target < 50:
            n_mc = "50"
        elif n_target < 100:
            n_mc = "100"
        elif n_target < 200:
            n_mc = "200"
        else:
            n_mc = "300"
        config['NMonteCarlo'] = n_mc

        # 4. RGFindFactor based on composition complexity
        n_elements = len(self.state.composition)
        if n_elements <= 2:
            rg = "3"
        elif n_elements <= 3:
            rg = "4"
        else:
            rg = "5"
        config['RGFindFactor'] = rg

        # 5. Enable symmetry detection by default
        config['detect_symmetry'] = True

        return config

    def _get_preset_config(self, preset: str, base_config: Dict[str, str]) -> Dict[str, str]:
        """Get preset configuration (quick, standard, thorough)."""
        if preset in _ADD_SITES_PRESETS:
            print(f"\n  → {preset.upper()} preset selected")
            return dict(_ADD_SITES_PRESETS[preset])
        return base_config

    def _customize_add_sites_config(self, base_config: Dict[str, str]) -> Dict[str, str]:
        """Allow user to customize individual parameters."""
        print(f"\n  Current: AddMeshes={base_config['AddMeshes']}, MinDist={base_config['MinDistanceBetweenAddedSites']}, "
              f"NMC={base_config['NMonteCarlo']}, RG={base_config['RGFindFactor']}")
        print(f"  (leave blank to keep current value)\n")

        meshes = input("  AddMeshes [" + base_config['AddMeshes'] + "]: ").strip()
        if meshes:
            base_config['AddMeshes'] = meshes

        min_dist = input("  MinDistance [" + base_config['MinDistanceBetweenAddedSites'] + "]: ").strip()
        if min_dist:
            base_config['MinDistanceBetweenAddedSites'] = min_dist

        n_mc = input("  NMonteCarlo [" + base_config['NMonteCarlo'] + "]: ").strip()
        if n_mc:
            base_config['NMonteCarlo'] = n_mc

        rg = input("  RGFindFactor [" + base_config['RGFindFactor'] + "]: ").strip()
        if rg:
            base_config['RGFindFactor'] = rg

        sym = input("  Detect symmetry? [Y/n]: ").strip().lower()
        if sym:
            base_config['detect_symmetry'] = sym != 'n'

        return base_config

    def step_5_oxidation_states(self) -> bool:
        """Step 5B: Specify oxidation states for host and interstitial (Scenario B).

        Returns:
            True if charges are acceptable
        """
        print("\n" + "="*60)
        print("Step 5/5: Oxidation States & Charges")
        print("="*60)

        if not self.state.composition or not self.state.interstitial_species:
            print("ERROR: Missing composition or interstitial species")
            return False

        charges: Dict[str, float] = {}

        # Get all elements (host + interstitial)
        all_elements = sorted(list(self.state.composition.keys()) + [self.state.interstitial_species])

        print("\nLookup typical oxidation states:")
        print("(Press Enter to accept defaults, or enter new value)\n")

        for element in all_elements:
            default_charge = suggest_default_charge(element)

            def validate_charge(val: float) -> Tuple[bool, str]:
                if -10 <= val <= 10:
                    return True, ""
                return False, "Must be between -10 and +10"

            charge = self.prompt_input(
                f"  {element} oxidation state",
                float,
                default=default_charge,
                validator=validate_charge
            )
            charges[element] = charge

        self.state.charges = charges

        # Check charge balance
        net_charge = self._calculate_net_charge_with_interstitial()
        print(f"\nNet charge: {net_charge:.2f}")

        if abs(net_charge) > 0.01:
            print(f"  WARNING: System is not electrically neutral!")

            # Suggest adjustment
            adjustment_options = self._suggest_charge_adjustments_interstitial()
            if adjustment_options:
                print("\n  Charge neutralization options:")
                for i, (element, new_charge, description) in enumerate(adjustment_options, 1):
                    print(f"    {i}) Adjust {element}: {self.state.charges[element]:.2f} → {new_charge:.2f}")
                    print(f"       ({description})")
                print(f"    {len(adjustment_options) + 1}) Keep as-is (unusual charges)")

                choice = self.render_menu(
                    "Select charge adjustment:",
                    [f"Option {i}" for i in range(len(adjustment_options) + 1)],
                    default_index=0,
                )

                if choice < len(adjustment_options):
                    element, new_charge, _ = adjustment_options[choice]
                    self.state.charges[element] = new_charge
                    net_charge = self._calculate_net_charge_with_interstitial()
                    print(f"\n  ✓ Adjusted. New net charge: {net_charge:.2f}")

            # Final confirmation
            if not self.confirm("\n  Continue with current charges?", default_yes=True):
                return False
        else:
            print("  ✓ System is electrically neutral")

        return True

    # ===== Validation =====

    def validate_composition(self) -> Tuple[bool, List[str]]:
        """Validate current composition state.

        Returns:
            (is_valid, error_messages)
        """
        errors = []

        if not self.state.composition:
            errors.append("No composition specified")
            return False, errors

        total = sum(self.state.composition.values())
        if total != self.state.target_atoms:
            errors.append(f"Sum ({total}) ≠ target ({self.state.target_atoms})")

        if not all(count > 0 for count in self.state.composition.values()):
            errors.append("All elements must have count > 0")

        return len(errors) == 0, errors

    def validate_charges(self) -> Tuple[bool, List[str]]:
        """Validate current charge state.

        Returns:
            (is_valid, warnings)
        """
        warnings = []

        if not self.state.charges:
            warnings.append("No charges specified")
            return True, warnings

        if self.state.interstitial_species:
            net_charge = self._calculate_net_charge_with_interstitial()
        else:
            net_charge = self._calculate_net_charge()
        if abs(net_charge) > 0.1:
            warnings.append(f"System has net charge {net_charge:.2f} (not neutral)")

        return True, warnings

    def validate_recipes(self) -> Tuple[bool, List[str]]:
        """Validate current recipe state.

        Returns:
            (is_valid, error_messages)
        """
        errors = []

        if not self.state.recipes:
            errors.append("No recipes specified")
            return False, errors

        valid_sources = (
            set(self.state.element_mapping.keys())
            if self.state.element_mapping
            else set(self.state.composition.keys())
        )
        valid_targets = set(self.state.composition.keys())

        for from_elem, to_elems in self.state.recipes.items():
            if from_elem not in valid_sources:
                errors.append(f"Recipe source '{from_elem}' not in reference structure")
            invalid_targets = [to_elem for to_elem in to_elems if to_elem not in valid_targets]
            if invalid_targets:
                errors.append(
                    f"Recipe source '{from_elem}' has target(s) not in composition: {invalid_targets}"
                )

        return len(errors) == 0, errors

    # ===== Summary & Output =====

    def show_summary(self) -> None:
        """Display final summary before saving."""
        print("\n" + "="*60)
        print("SUMMARY")
        print("="*60)

        if self.state.structure:
            formula = self._get_formula_from_structure()
            n_atoms = len(self.state.structure.sites)
            print(f"\nBase Structure: {self.state.reference_structure}")
            print(f"  Formula: {formula}")
            print(f"  Atoms: {n_atoms}")

        # Composition-Driven summary
        if self.state.element_mapping:
            print("\nElement Mapping:")
            for from_elem, to_elems in self.state.element_mapping.items():
                to_str = ",".join(to_elems)
                print(f"  {from_elem} → {{{to_str}}}")

        if self.state.composition:
            comp_str = " + ".join(f"{k}{v}" for k, v in self.state.composition.items())
            print(f"\nTarget Composition: {comp_str}")
            print(f"Composition Mode: {self.state.composition_mode}")

        if self.state.site_groups:
            print("\nSite Groups:")
            for group_name, info in self.state.site_groups.items():
                allowed = ",".join(info.get("allowed", []))
                label = info.get("label", {})
                display = label.get("display") if isinstance(label, dict) else None
                label_text = f" label={display}," if display else ""
                print(
                    f"  {group_name}:{label_text} source={info.get('source_kind')}, "
                    f"count={info.get('count')}, allowed={allowed}"
                )
        if self.state.composition_by_site:
            print("\nSite-wise Composition:")
            for group_name, group_comp in self.state.composition_by_site.items():
                comp_text = ", ".join(f"{k}={v}" for k, v in group_comp.items() if v > 0)
                print(f"  {group_name}: {comp_text}")

        if self.state.charges:
            charge_str = ", ".join(f"{k}({v:+.1f})" for k, v in self.state.charges.items())
            print(f"Charges: {charge_str}")
            print(f"Charge basis: {self.state.charge_basis}")
            if self.state.charges_by_site:
                print("Site-group charges:")
                for key, value in sorted(self.state.charges_by_site.items()):
                    print(f"  {key}: {value:+.3f}")
            if self.state.interstitial_species:
                net = self._calculate_net_charge_with_interstitial()
            else:
                net = self._calculate_net_charge()
            print(f"Net charge: {net:.2f}")

        if self.state.recipes:
            print("\nSubstitution Recipes:")
            for from_elem, to_elems in self.state.recipes.items():
                to_str = ",".join(to_elems)
                print(f"  {from_elem} → {{{to_str}}}")

        solve_block = _production_solve_block(self.state)
        strategy = solve_block.get("strategy", {})
        if strategy:
            print("\nSolve Strategy:")
            print(f"  Mode: {strategy.get('mode', 'adaptive')}")
            if strategy.get("mode", "adaptive") == "adaptive":
                print(f"  Time budget: {strategy.get('time_budget_sec', 600)} sec")
            print(f"  Effort: {strategy.get('effort', 'medium')}")
            print(f"  Execution mode: {strategy.get('execution_mode', 'quick')}")
            swap = strategy.get("swap", {})
            if isinstance(swap, dict):
                print(
                    "  Swap: "
                    f"enabled={bool(swap.get('enabled', True))}, "
                    f"max_steps={int(swap.get('max_steps', 100))}"
                )
        print("\nOutput Selection:")
        print(f"  enabled: {self.state.selection_enabled}")
        if self.state.selection_enabled:
            print(f"  mode: {self.state.selection_mode}")
            print(f"  limit: {self.state.selection_limit}")
            print(f"  pick: {self.state.selection_pick}")
            print(f"  interval: {self.state.selection_interval}")
            print(f"  outdir: {self.state.selection_outdir}")
            print(f"  prefix: {self.state.selection_prefix}")

        # Interstitial-Driven summary
        if self.state.interstitial_species:
            print(f"\nInterstitial Species: {self.state.interstitial_species}")
            print(f"  Count to add: {self.state.interstitial_count}")
            if self.state.structure:
                new_total = len(self.state.structure.sites) + self.state.interstitial_count
                print(f"  New total atoms: {new_total}")
            if self.state.add_sites_config:
                print(f"\nAdd-Sites Parameters:")
                print(f"  Grid spacing: {self.state.add_sites_config.get('AddMeshes', 'auto')}")
                print(f"  Min distance: {self.state.add_sites_config.get('MinDistanceBetweenAddedSites', 'auto')} Å")
                print(f"  MC trials: {self.state.add_sites_config.get('NMonteCarlo', 'auto')}")
            print(f"\nTo execute unified workflow (host enum + add-sites + placement):")
            print(f"  esspy run input.yaml")

    def save_to_yaml(self, output_path: str) -> bool:
        """Save configuration to YAML file.

        Args:
            output_path: Target file path

        Returns:
            True if saved successfully
        """
        import yaml

        try:
            output_path = Path(output_path)

            # Check overwrite
            if output_path.exists():
                if not self.confirm(f"\n{output_path} already exists. Overwrite?", default_yes=True):
                    return False

            # For Composition-Driven: target_atoms is the total including all elements
            # For Interstitial-Driven: target_atoms is the host (composition) only, add-sites adds more
            total_atoms = self.state.target_atoms

            # Global compositions are written as fractions so editing
            # structure.n_target_sites later preserves the same ratio.
            if self.state.composition_mode == "global":
                fraction_map = dict(self.state.composition_fractions)
                if not fraction_map and total_atoms > 0:
                    fraction_map = {
                        kind: count / total_atoms
                        for kind, count in self.state.composition.items()
                    }
                composition_dict = {"fractions": fraction_map}
            else:
                composition_dict = dict(self.state.composition)

            # Build charge entries (as dict: {element: oxidation_state})
            charge_dict = {k: v for k, v in self.state.charges.items()}

            # Build recipe entries (recipes are required for composition transformation)
            recipe_entries = []
            if self.state.recipes:
                recipe_entries = [
                    {"from_kind": k, "to": v}
                    for k, v in self.state.recipes.items()
                ]

            # Build YAML structure
            charges_block = {
                "basis": "element_site" if self.state.charge_basis == "element+site_group" else "element",
                "values": charge_dict,
            }
            if self.state.charges_by_site:
                nested_elements: Dict[str, Dict[str, object]] = {}
                for elem, val in charge_dict.items():
                    nested_elements[str(elem)] = {"default": float(val)}
                for key, value in self.state.charges_by_site.items():
                    if "@" not in str(key):
                        continue
                    elem, site_group = str(key).split("@", 1)
                    elem = elem.strip()
                    site_group = site_group.strip()
                    node = nested_elements.setdefault(elem, {"default": float(charge_dict.get(elem, value))})
                    by_site = node.setdefault("by_site", {})
                    if isinstance(by_site, dict):
                        by_site[site_group] = float(value)
                charges_block["elements"] = nested_elements

            structure_block = {
                "poscar": _relative_path_for_yaml(
                    self.state.reference_structure,
                    output_path.parent,
                ),
            }
            if self.state.supercell_expansion is not None:
                structure_block["dim"] = [
                    int(value) for value in self.state.supercell_expansion
                ]
            else:
                structure_block["n_target_sites"] = total_atoms

            config = {
                "structure": structure_block,
                "composition": composition_dict,
                "charges": charges_block,
                "solve": _production_solve_block(self.state),
                "output": {
                    **_host_output_block(),
                    "selection": _selection_block_from_state(self.state),
                }
            }

            # Add recipes
            if recipe_entries:
                config["recipes"] = recipe_entries
            else:
                config["recipes"] = []

            # Optional site-aware metadata (kept top-level for forward compatibility)
            if self.state.site_grouping:
                config["site_grouping"] = self.state.site_grouping
            if self.state.site_groups:
                config["site_groups"] = self.state.site_groups
            if self.state.composition_mode == "global":
                config["allocation"] = {
                    "time_budget_sec": int(
                        self.state.allocation_time_budget_sec
                        or max(1, int(round(float(self.state.solve_time_budget_sec) * 0.30)))
                    )
                }
            if self.state.composition_by_site:
                config["composition_by_site"] = self.state.composition_by_site
            # Legacy top-level `charges_by_site` is deprecated in favor of `charges.by_site`.

            # For Interstitial-Driven: add interstitial section with all parameters
            if self.state.mode == WizardMode.INTERSTITIAL and self.state.interstitial_species:
                # Convert add_sites_config dict to proper YAML structure
                add_sites_config = {}
                if self.state.add_sites_config:
                    # Parse grid spacing (e.g., "0.5 0.5 0.5" → [0.5, 0.5, 0.5])
                    meshes_str = self.state.add_sites_config.get('AddMeshes', '0.5 0.5 0.5')
                    add_sites_config['grid_spacing'] = [float(x) for x in meshes_str.split()]

                    # Min distance between added sites
                    add_sites_config['min_distance'] = float(
                        self.state.add_sites_config.get('MinDistanceBetweenAddedSites', 1.5)
                    )

                    # Number of Monte Carlo trials
                    add_sites_config['num_monte_carlo'] = int(
                        self.state.add_sites_config.get('NMonteCarlo', 100)
                    )

                    # Energy field for interactions
                    add_sites_config['energy_field'] = self.state.add_sites_config.get('EnergyField', 'O')

                config["interstitial"] = {
                    "species": self.state.interstitial_species,
                    "count": self.state.interstitial_count,
                    "add_sites": add_sites_config,
                    "constraints": {
                        "progressive_relaxation": True
                    }
                }
            else:
                # Composition-driven path: no interstitials
                config["interstitial"] = None

            # Write YAML
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(render_init_yaml_text(config), encoding="utf-8")

            print(f"\n✓ Saved to {output_path}")
            self._write_sposcar(output_path.parent)
            return True

        except Exception as e:
            print(f"ERROR: Failed to save YAML: {e}")
            return False

    def _write_sposcar(self, output_dir: Path) -> Optional[Path]:
        if self.state.structure is None:
            return None
        dims = self.state.resolved_supercell_expansion or self.state.supercell_expansion
        if dims is None:
            return None
        try:
            from .poscar import write_structure_to_poscar
            from .supercell_search import build_supercell_structure

            matrix = (
                (int(dims[0]), 0, 0),
                (0, int(dims[1]), 0),
                (0, 0, int(dims[2])),
            )
            sposcar = build_supercell_structure(
                self.state.structure,
                matrix,
                title=f"{self.state.structure.title} | SPOSCAR {dims[0]}x{dims[1]}x{dims[2]}",
            )
            path = Path(output_dir) / "SPOSCAR"
            path.write_text(write_structure_to_poscar(sposcar), encoding="utf-8")
            print(f"✓ Saved supercell POSCAR to {path}")
            return path
        except Exception as exc:
            print(f"WARNING: Failed to write SPOSCAR: {exc}")
            return None

    def run_workflow(self) -> bool:
        """Execute unified wizard workflow.

        Flow:
        1. Common setup: Structure + Composition
        2. Branch point: Ask about adding interstitials
        3. Conditional workflow: Composition-driven or Interstitial-driven

        Returns:
            True if workflow completed successfully
        """
        return self._run_unified_workflow()

    def _run_unified_workflow(self) -> bool:
        """Execute unified wizard that defers mode choice until after composition.

        Flow:
        1. Structure selection (common)
        2. Element mapping & composition (common)
        3. [BRANCH POINT] Ask: "Add interstitial atoms?"
           - NO  → composition-driven path (recipes → charges → done)
           - YES → interstitial-driven path (interstitials → add-sites → charges → done)

        Returns:
            True if workflow completed successfully
        """
        print("\n" + "="*70)
        print("esspy Interactive Wizard - Structure & Composition")
        print("="*70)

        # STEP 1: Structure selection (common to both paths)
        if not self._run_step_with_retry(self.step_1_structure_selection):
            return False

        # STEP 2: Element mapping & Composition (common to both paths)
        if not self._run_step_with_retry(self.step_2_element_mapping):
            return False

        if not self._run_step_with_retry(self.step_2b_site_groups_and_composition_mode):
            return False

        if not self._run_step_with_retry(self.step_3_target_composition):
            return False

        is_valid, errors = self.validate_composition()
        if not is_valid:
            for error in errors:
                print(f"  ERROR: {error}")
            return False

        # STEP 3: [BRANCH POINT] Ask about interstitial atoms
        print("\n" + "="*70)
        print("Configuration Summary")
        print("="*70)
        print(f"Structure: {self.state.reference_structure}")
        print(f"Composition mode: {self.state.composition_mode}")
        print(f"Composition: {', '.join(f'{elem}={count}' for elem, count in self.state.composition.items())}")
        print()

        while True:
            choice = input("Add interstitial atoms to this structure? (y/n) [n]: ").strip().lower()
            if choice in ['y', 'yes']:
                # INTERSTITIAL-DRIVEN PATH
                self.state.mode = WizardMode.INTERSTITIAL
                return self._run_interstitial_workflow_continuation()
            elif choice in ['n', 'no', '']:
                # COMPOSITION-DRIVEN PATH
                self.state.mode = WizardMode.COMPOSITION
                return self._run_composition_workflow_continuation()
            else:
                print("Please enter 'y' or 'n'")

    def _run_composition_workflow_continuation(self) -> bool:
        """Continue composition-driven workflow from Step 4 (recipes).

        Assumes steps 1-3 (structure, element mapping & composition) are already done.

        Returns:
            True if workflow completed successfully
        """
        print("\n" + "="*70)
        print("Composition-Driven Configuration")
        print("="*70)

        # Step 4: Recipes
        if not self._run_step_with_retry(self.step_5_substitution_recipes):
            return False

        is_valid, errors = self.validate_recipes()
        if not is_valid:
            for error in errors:
                print(f"  ERROR: {error}")
            return False

        # Step 6: Charges
        if not self._run_step_with_retry(self.step_4_oxidation_states):
            return False

        is_valid, warnings = self.validate_charges()
        for warning in warnings:
            print(f"  WARNING: {warning}")

        # Step 7: Solve + output behavior
        if not self._run_step_with_retry(self.step_6_solve_strategy):
            return False
        if not self._run_step_with_retry(self.step_7_output_selection):
            return False

        # Summary
        self.show_summary()

        return True

    def _run_interstitial_workflow_continuation(self) -> bool:
        """Continue interstitial-driven workflow from Step 4 (interstitial params).

        Assumes steps 1-3 (structure, composition, & branching decision) are already done.
        Structure and composition are set in self.state from common setup.

        Returns:
            True if workflow completed successfully
        """
        print("\n" + "="*70)
        print("Interstitial-Driven Configuration")
        print("="*70)

        # Map composition to host composition (already set in self.state.composition)
        # Step 4: Interstitial species & count
        if not self._run_step_with_retry(self.step_4_interstitial_species_count):
            return False

        # Step 5: Add-sites parameters
        add_sites_config = self.step_6_add_sites_parameters()
        if add_sites_config is None:
            return False

        self.state.add_sites_config = add_sites_config

        # Step 6: Charges
        if not self._run_step_with_retry(self.step_5_oxidation_states):
            return False

        if not self._run_step_with_retry(self.step_7_output_selection):
            return False

        is_valid, warnings = self.validate_charges()
        for warning in warnings:
            print(f"  WARNING: {warning}")

        # Summary
        self.show_summary()

        # Set recipes from element mapping (preserve Zn→[Mn,Cr] transformations)
        # This is CRITICAL for host enumeration to work correctly
        self.state.recipes = {}
        if self.state.element_mapping:
            for from_elem, to_elems in self.state.element_mapping.items():
                self.state.recipes[from_elem] = to_elems
        else:
            # Fallback: identity recipes if no element mapping
            for element in self.state.composition.keys():
                self.state.recipes[element] = [element]

        return True

    def _run_composition_workflow(self) -> bool:
        """Execute Scenario A (composition-driven) workflow."""
        print("\n" + "="*70)
        print("esspy Interactive Wizard - Composition-Driven Configuration")
        print("="*70)

        # Step 1: Structure
        if not self.step_1_structure_selection():
            return False

        # Step 2: Element Mapping (NEW)
        if not self.step_2_element_mapping():
            return False

        # Step 3: Composition (uses mapped elements)
        if not self.step_3_target_composition():
            return False

        is_valid, errors = self.validate_composition()
        if not is_valid:
            for error in errors:
                print(f"  ERROR: {error}")
            return False

        # Step 4: Charges (uses mapped elements)
        if not self.step_4_oxidation_states():
            return False

        is_valid, warnings = self.validate_charges()
        for warning in warnings:
            print(f"  WARNING: {warning}")

        # Step 5: Recipes
        if not self.step_5_substitution_recipes():
            return False

        is_valid, errors = self.validate_recipes()
        if not is_valid:
            for error in errors:
                print(f"  ERROR: {error}")
            return False

        # Summary
        self.show_summary()

        return True

    def _run_interstitial_workflow(self) -> bool:
        """Execute Scenario B (interstitial-driven) workflow."""
        print("\n" + "="*70)
        print("esspy Interactive Wizard - Interstitial-Driven Configuration")
        print("="*70)

        # Step 1: Base structure
        if not self.step_1_base_structure_fixed():
            return False

        # Step 2: Supercell size
        if not self.step_2_supercell_size():
            return False

        # Step 3: Host element composition
        if not self.step_3_host_element_composition():
            return False

        # Step 4: Interstitial species & count
        if not self.step_4_interstitial_species_count():
            return False

        # Step 5: Oxidation states & charges
        if not self.step_5_oxidation_states():
            return False

        # Step 6: Add-sites parameters (optional)
        add_sites_config = self.step_6_add_sites_parameters()

        # Set recipes from element mapping (preserve Zn→[Mn,Cr] transformations)
        # This is CRITICAL for host enumeration to work correctly
        self.state.recipes = {}
        if self.state.element_mapping:
            for from_elem, to_elems in self.state.element_mapping.items():
                self.state.recipes[from_elem] = to_elems
        else:
            # Fallback: identity recipes if no element mapping
            for element in self.state.composition.keys():
                self.state.recipes[element] = [element]

        # Add interstitial species to recipes
        if self.state.interstitial_species:
            self.state.recipes[self.state.interstitial_species] = [self.state.interstitial_species]

        # Summary
        self.show_summary()

        # Now execute the full workflow: host enumeration + add-sites
        if not self._execute_interstitial_full_workflow(add_sites_config):
            return False

        return True

    # ===== Helper Methods =====

    def _get_formula_from_structure(self) -> str:
        """Extract formula string from loaded structure."""
        if not self.state.structure:
            return "N/A"

        counts: Dict[str, int] = {}
        for site in self.state.structure.sites:
            counts[site.kind] = counts.get(site.kind, 0) + 1

        # Sort by element name
        formula_parts = [f"{k}{v}" for k, v in sorted(counts.items())]
        return "".join(formula_parts)

    def _get_poscar_files(self) -> List[Path]:
        """Get available POSCAR files in current directory.

        Returns:
            List of Path objects for POSCAR-like files
        """
        cwd = Path.cwd()
        poscar_files = []

        # Look for common POSCAR file patterns
        for pattern in ["POSCAR*", "poscar*", "CONTCAR*", "contcar*", "*.vasp", "*.VASP"]:
            for file in cwd.glob(pattern):
                if file.is_file() and file not in poscar_files:
                    poscar_files.append(file)

        return poscar_files

    def _show_directory_contents(self) -> None:
        """Show all files and directories in current directory (like ls)."""
        cwd = Path.cwd()

        try:
            items = sorted(cwd.iterdir(), key=lambda x: (not x.is_dir(), x.name))

            if not items:
                print("  (empty directory)")
                return

            # Separate directories and files
            dirs = [item for item in items if item.is_dir()]
            files = [item for item in items if item.is_file()]

            # Show directories first
            for dir_item in dirs[:20]:
                print(f"  [DIR]  {dir_item.name}")

            # Show files
            for file_item in files[:30]:
                size = file_item.stat().st_size
                if size < 1024:
                    size_str = f"{size}B"
                elif size < 1024*1024:
                    size_str = f"{size/1024:.1f}KB"
                else:
                    size_str = f"{size/(1024*1024):.1f}MB"
                print(f"  {file_item.name:<30} {size_str:>10}")

            if len(dirs) > 20 or len(files) > 30:
                print(f"  ... and {len(dirs) - 20 + len(files) - 30} more items")
        except Exception as e:
            print(f"  ERROR: Could not list directory: {e}")

    def _probe_actual_supercell(self, n_target: int) -> Optional[Dict]:
        """Run a fast guide-only check to find the actual supercell esspy will choose.

        Returns dict with n_actual, supercell ([a,b,c]), sites_per_kind, or None on failure.
        """
        import tempfile, json
        import yaml
        try:
            from .run_outputs import run_yaml_to_outputs
        except ImportError:
            return None

        if not self.state.structure or not self.state.reference_structure:
            return None

        element_counts: Dict[str, int] = {}
        for site in self.state.structure.sites:
            element_counts[site.kind] = element_counts.get(site.kind, 0) + 1
        base_total = sum(element_counts.values())
        if base_total == 0:
            return None

        # Build a proportional identity composition that sums to n_target
        proportional: Dict[str, int] = {}
        remaining = n_target
        elems = sorted(element_counts.keys())
        for i, elem in enumerate(elems):
            if i == len(elems) - 1:
                proportional[elem] = max(1, remaining)
            else:
                cnt = round(element_counts[elem] / base_total * n_target)
                proportional[elem] = max(1, cnt)
                remaining -= proportional[elem]

        probe_config = {
            "structure": {"poscar": str(self.state.reference_structure), "n_target_sites": n_target},
            "composition": proportional,
            "charges": {k: 0.0 for k in element_counts},
            "recipes": [{"from_kind": k, "to": [k]} for k in element_counts],
            "guide": {"options": {"target_cpu_time_sec": 10}},
            "solve": {"swap": False, "max_swap": 0},
            "output": {"workdir": "probe"},
        }

        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                from pathlib import Path as _Path
                probe_yaml = _Path(tmpdir) / "probe.yaml"
                probe_out = _Path(tmpdir) / "probe"
                with open(probe_yaml, "w") as f:
                    yaml.dump(probe_config, f, default_flow_style=False)
                run_yaml_to_outputs(
                    str(probe_yaml), workdir=str(probe_out),
                    guide_only=True, quiet=True, json_stdout=False, no_progress=True,
                )
                summary_path = probe_out / "summary.json"
                if not summary_path.exists():
                    return None
                with open(summary_path) as f:
                    summary = json.load(f)
                guide = summary.get("guide", {})
                sc = guide.get("supercell_expansion", [])
                if not sc:
                    return None
                n_unit = guide.get("n_atom_config", base_total)
                n_actual = n_unit * sc[0] * sc[1] * sc[2]
                # Actual site count per original element from recipe random_pickup
                sites_per_kind: Dict[str, int] = {}
                for recipe in guide.get("recipes", []):
                    sites_per_kind[recipe["from"]] = recipe.get("random_pickup", 0)
                # Fallback: proportional if recipe info missing
                if not sites_per_kind:
                    scale = n_actual / base_total
                    sites_per_kind = {k: round(v * scale) for k, v in element_counts.items()}
                return {"n_actual": n_actual, "supercell": sc, "sites_per_kind": sites_per_kind}
        except Exception:
            return None

    def _calculate_net_charge(self) -> float:
        """Calculate net charge of current composition + charges."""
        if not self.state.composition or not self.state.charges:
            return 0.0

        net = 0.0
        for element, count in self.state.composition.items():
            charge = self.state.charges.get(element, 0.0)
            net += count * charge

        return net

    def _suggest_charge_adjustments(self) -> List[Tuple[str, float, str]]:
        """Suggest charge adjustment options.

        Returns:
            List of (element, new_charge, description) tuples
        """
        suggestions = []
        net_charge = self._calculate_net_charge()

        if abs(net_charge) < 0.01:
            return suggestions

        # Priority order: O > N > S > ...
        priority = ["O", "N", "S", "F", "Cl", "Br", "I"]

        for element in priority:
            if element not in self.state.composition:
                continue

            count = self.state.composition[element]
            current_charge = self.state.charges[element]

            # Adjust charge per atom
            adjustment_per_atom = -net_charge / count
            new_charge = current_charge + adjustment_per_atom

            # Check if adjustment is physically reasonable
            if -10 <= new_charge <= 10:
                description = f"Charge {current_charge:+.2f} → {new_charge:+.2f} per atom"
                suggestions.append((element, new_charge, description))

        return suggestions

    def _calculate_net_charge_with_interstitial(self) -> float:
        """Calculate net charge including interstitial atoms.

        Returns:
            Net charge of host + interstitial composition
        """
        if not self.state.composition or not self.state.charges:
            return 0.0

        net = 0.0
        # Host atoms
        for element, count in self.state.composition.items():
            charge = self.state.charges.get(element, 0.0)
            net += count * charge

        # Interstitial atoms
        if self.state.interstitial_species and self.state.interstitial_count:
            interstitial_charge = self.state.charges.get(self.state.interstitial_species, 0.0)
            net += self.state.interstitial_count * interstitial_charge

        return net

    def _suggest_charge_adjustments_interstitial(self) -> List[Tuple[str, float, str]]:
        """Suggest charge adjustment options for interstitial scenario.

        Returns:
            List of (element, new_charge, description) tuples
        """
        suggestions = []
        net_charge = self._calculate_net_charge_with_interstitial()

        if abs(net_charge) < 0.01:
            return suggestions

        # Priority order: anions first (O, N, S), then cations
        priority = ["O", "N", "S", "F", "Cl", "Br", "I"]

        for element in priority:
            # Check host elements first, then interstitial
            if element not in self.state.composition and element != self.state.interstitial_species:
                continue

            if element in self.state.composition:
                count = self.state.composition[element]
            else:
                count = self.state.interstitial_count

            current_charge = self.state.charges.get(element, 0.0)

            # Adjust charge per atom
            adjustment_per_atom = -net_charge / count
            new_charge = current_charge + adjustment_per_atom

            # Check if adjustment is physically reasonable
            if -10 <= new_charge <= 10:
                description = f"Charge {current_charge:+.2f} → {new_charge:+.2f} per atom"
                suggestions.append((element, new_charge, description))

        return suggestions

    def _execute_interstitial_full_workflow(self, add_sites_config: Dict[str, str]) -> bool:
        """Execute full interstitial workflow: host enumeration + add-sites.

        Args:
            add_sites_config: Dictionary with AddMeshes, MinDistance, NMonteCarlo

        Returns:
            True if workflow completed successfully
        """
        import subprocess
        import tempfile
        import json
        from pathlib import Path
        import shutil

        try:
            import shlex

            print("\n" + "="*70)
            print("Executing Full Interstitial Workflow")
            print("="*70)

            # Generate output folder name from final composition (including interstitial)
            composition_with_interstitial = dict(self.state.composition)
            composition_with_interstitial[self.state.interstitial_species] = self.state.interstitial_count
            final_formula = self._get_composition_formula(composition_with_interstitial)

            # Create main output directory
            output_dir = Path(final_formula)
            output_dir.mkdir(exist_ok=True)

            # Create subdirectories for organization
            config_dir = output_dir / "config"
            config_dir.mkdir(exist_ok=True)
            host_dir = output_dir / "host_enumeration"

            # Generate descriptive folder name from host composition
            host_composition_formula = self._get_composition_formula(self.state.composition)
            host_yaml_name = f"{host_composition_formula}_host.yaml"

            # Step 1: Generate host YAML and save to config subdirectory
            print("\n[1/4] Generating host enumeration YAML...")
            host_yaml_path = config_dir / host_yaml_name
            if not self._save_host_yaml(host_yaml_path):
                print("  ✗ Failed to generate host YAML")
                return False
            print(f"  ✓ Host YAML: {host_yaml_path.relative_to(output_dir)}")

            # Step 2: Run host enumeration in output directory
            print("\n[2/4] Running host supercell enumeration...")
            result = subprocess.run(
                ["esspy", "run", str(host_yaml_path), "--workdir", str(host_dir)],
                capture_output=True,
                text=True,
                timeout=300
            )
            if result.returncode != 0:
                print(f"  ✗ Host enumeration failed")
                print(f"  Error: {result.stderr[:500]}")
                return False
            print(f"  ✓ Host enumeration completed in {host_dir.relative_to(output_dir)}/")

            # Step 3: Find best POSCAR from host enumeration
            print("\n[3/4] Preparing for add-sites...")
            best_poscar = None

            # Find POSCAR files with "best" in name
            for f in host_dir.glob("*best*.vasp"):
                best_poscar = f
                break

            if not best_poscar or not best_poscar.exists():
                print(f"  ✗ Best POSCAR not found in {host_dir}")
                return False

            print(f"  ✓ Best structure found: {best_poscar.name}")

            # Step 4: Generate add-sites solver config in config directory
            print("\n[4/4] Running add-sites Monte Carlo...")
            solver_config_path = self._generate_add_sites_solver_config(add_sites_config, config_dir)

            # Build add-sites command with options
            # Use absolute paths to handle filenames with spaces
            solver_text_path = solver_config_path.resolve()
            poscar_path = best_poscar.resolve()

            cmd = [
                "esspy", "add-sites", "run",
                "--solver-text", str(solver_text_path),
                "--poscar", str(poscar_path),
                "--charges-json", json.dumps(self.state.charges),
                "--seed", "42"
            ]

            # Add RGFindFactor if specified
            if add_sites_config.get('RGFindFactor'):
                cmd.extend(["--rg-find-factor", str(add_sites_config['RGFindFactor'])])

            # Detect and add space group if requested
            if add_sites_config.get('detect_symmetry'):
                space_group = self._detect_space_group(str(best_poscar))
                if space_group:
                    print(f"  Detected space group: {space_group}")
                    cmd.extend(["--space-group", str(space_group)])

                    # NEW: Try to find and add WYC file for Wyckoff positions
                    if space_group > 1:  # Skip for P1 (trivial space group)
                        wyc_path = self._find_wyc_file(space_group)
                        if wyc_path:
                            cmd.extend(["--wyc", str(wyc_path)])
                            print(f"    ✓ Using WYC database: {wyc_path.name}")
                        else:
                            print(f"    ⚠ WYC file not found for space group {space_group}")
                            print(f"      Continuing with space group only...")

            # Use shell=True with properly quoted arguments to handle filenames with spaces
            cmd_str = " ".join(shlex.quote(arg) for arg in cmd)
            print(f"  Executing: {cmd_str[:100]}...")

            result = subprocess.run(
                cmd_str,
                capture_output=True,
                text=True,
                timeout=300,
                shell=True
            )

            if result.returncode != 0:
                print(f"  ✗ Add-sites failed (return code: {result.returncode})")
                print(f"  STDERR:\n{result.stderr}")
                print(f"  STDOUT:\n{result.stdout}")
                return False

            # Parse add-sites output and create final POSCAR with interstitial
            try:
                output_json = json.loads(result.stdout)
                if output_json.get("success"):
                    trials = output_json.get('attempted_trials', '?')
                    n_sites = output_json.get('n_sites', '?')
                    best_energy = output_json.get('best_energy', '?')

                    print(f"  ✓ Add-sites successful!")
                    print(f"    Trials: {trials}")
                    print(f"    Best energy: {best_energy:.4f} eV" if isinstance(best_energy, float) else f"    Best energy: {best_energy}")
                    print(f"    Final structure atoms: {n_sites}")

                    # Now create final POSCAR with interstitial added to host
                    print(f"\n  Generating final POSCAR with {self.state.interstitial_species}...")
                    final_poscar_path = self._create_final_poscar_with_interstitial(
                        best_poscar, add_sites_config, output_dir
                    )

                    if final_poscar_path and final_poscar_path.exists():
                        print(f"  ✓ Final POSCAR: {final_poscar_path.name}")

                        # Generate final YAML with interstitial in composition in output directory
                        print(f"\n  Generating final configuration YAML...")
                        final_yaml_path = self._save_final_yaml(final_poscar_path, output_dir)
                        if final_yaml_path:
                            print(f"  ✓ Final YAML: {final_yaml_path.name}")

                            print(f"\n" + "="*70)
                            print(f"✓ INTERSTITIAL STRUCTURE COMPLETED!")
                            print("="*70)
                            print(f"Output directory: {output_dir}/")
                            print(f"  ├─ {final_poscar_path.name}              (final structure)")
                            print(f"  ├─ {final_yaml_path.name}               (esspy run config)")
                            print(f"  ├─ config/                             (configuration files)")
                            print(f"  └─ host_enumeration/                   (intermediate results)")

                            # Extract actual composition from final POSCAR for accurate reporting
                            final_composition = self._extract_composition_from_poscar(final_poscar_path)
                            if final_composition:
                                comp_str = " + ".join(f"{elem}{count}" for elem, count in sorted(final_composition.items()))
                                print(f"\nComposition: {comp_str}")
                            else:
                                print(f"\nComposition: (check POSCAR)")
                            print(f"Total atoms: {n_sites}")
                            print(f"\nNext: esspy run {output_dir}/{final_yaml_path.name}")
                            print("="*70)
                            return True
                        else:
                            print(f"  ⚠ Could not create final YAML, but POSCAR exists")
                            return True
                    else:
                        print(f"  ⚠ Could not create final POSCAR, but add-sites succeeded")
                        return True

                else:
                    print(f"  ✗ Add-sites did not converge")
                    return False
            except json.JSONDecodeError:
                print(f"  ✗ Could not parse add-sites output")
                print(f"  Output: {result.stdout[:300]}")
                return False

            # Keep all files in output_dir for reference, no cleanup needed
            print("\nFinalizing output...")

            print("\n" + "="*70)
            print("✓ Workflow Complete!")
            print("="*70)
            return True

        except subprocess.TimeoutExpired:
            print("  ✗ Workflow timed out")
            return False
        except Exception as e:
            print(f"  ✗ Error: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _apply_recipes_to_composition(
        self, base_composition: Dict[str, int], recipes: Dict[str, list],
        interstitial_species: str = None
    ) -> Dict[str, int]:
        """Apply substitution recipes to transform base composition.

        For example:
        - Base: {Zn: 32, O: 32}
        - Recipes: {Zn: [Mn, Cr]}
        - Result: {Mn: 16, Cr: 16, O: 32}

        When a species has multiple targets, they are divided equally.

        Args:
            base_composition: Original composition dict
            recipes: Substitution recipes {from_element: [to_elements]}
            interstitial_species: Species to exclude from transformation

        Returns:
            Transformed composition dict
        """
        transformed = {}

        for element, count in base_composition.items():
            # Skip interstitial species
            if interstitial_species and element == interstitial_species:
                transformed[element] = count
                continue

            # Check if this element has substitution recipe
            if element in recipes and recipes[element]:
                targets = recipes[element]

                # If single target and it's the same element, no transformation
                if len(targets) == 1 and targets[0] == element:
                    transformed[element] = count
                # If multiple targets, divide equally
                else:
                    count_per_target = count // len(targets)
                    remainder = count % len(targets)

                    for i, target in enumerate(targets):
                        # Distribute remainder to first targets
                        target_count = count_per_target + (1 if i < remainder else 0)
                        transformed[target] = transformed.get(target, 0) + target_count
            else:
                # No recipe for this element, keep as is
                transformed[element] = count

        return transformed

    def _extract_composition_from_poscar(self, poscar_path: Path) -> Dict[str, int]:
        """Extract actual composition from POSCAR file.

        Reads the element type line and count line from POSCAR to determine
        actual atomic composition.

        Args:
            poscar_path: Path to POSCAR file

        Returns:
            Dict mapping element symbols to counts, or None if extraction fails
        """
        try:
            with open(poscar_path, 'r') as f:
                lines = f.readlines()

            # POSCAR format (0-indexed):
            # Line 0: comment
            # Line 1: scale
            # Lines 2-4: lattice vectors
            # Line 5: element symbols (space-separated)
            # Line 6: element counts (space-separated)

            if len(lines) < 7:
                return None

            element_line = lines[5].strip().split()
            count_line = lines[6].strip().split()

            if len(element_line) != len(count_line):
                return None

            composition = {}
            for element, count_str in zip(element_line, count_line):
                try:
                    composition[element] = int(count_str)
                except ValueError:
                    return None

            return composition

        except Exception as e:
            print(f"    Error extracting composition from POSCAR: {e}")
            return None

    def _get_composition_formula(self, composition: Dict[str, int]) -> str:
        """Generate chemical formula string from composition dict.

        Args:
            composition: Dict mapping element names to atom counts

        Returns:
            Formula string like "Zn32O32Li1" (sorted by element name)
        """
        # Sort elements alphabetically for consistent naming
        sorted_items = sorted(composition.items())
        formula_parts = [f"{element}{count}" for element, count in sorted_items]
        return "".join(formula_parts)

    def _save_host_yaml(self, output_path: Path) -> bool:
        """Save host-only YAML with recipes applied to composition.

        Uses ORIGINAL recipes (from initial POSCAR elements) combined with
        the transformed composition. For example:
        - Initial POSCAR: {Zn: 2, O: 2}
        - Recipes: {Zn: [Mn, Cr], O: [O]}
        - Target composition: {Mn: 16, Cr: 16, O: 32}

        The recipes must reference elements in the POSCAR, not the transformed
        composition, so esspy knows how to generate structures.
        """
        import yaml

        try:
            # Transform composition based on recipes
            host_composition = self._apply_recipes_to_composition(
                dict(self.state.composition),
                self.state.recipes,
                self.state.interstitial_species
            )

            # Only include charges for elements in the transformed composition
            charge_dict = {k: v for k, v in self.state.charges.items() if k in host_composition}
            total_atoms = self.state.target_atoms

            # Use ORIGINAL recipes (they reference POSCAR elements like Zn, not transformed Mn/Cr)
            # This allows esspy to understand how to transform POSCAR → composition
            original_recipe_entries = [
                {"from_kind": recipe_key, "to": recipe_values}
                for recipe_key, recipe_values in self.state.recipes.items()
            ]

            config = {
                "structure": {
                    "poscar": self.state.reference_structure,
                    "n_target_sites": total_atoms
                },
                "composition": host_composition,
                "charges": charge_dict,
                "solve": _production_solve_block(self.state),
                "output": {
                    **_host_output_block(),
                    "selection": _selection_block_from_state(self.state),
                },
                "recipes": original_recipe_entries
            }

            with open(output_path, "w") as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)

            return True
        except Exception as e:
            print(f"  Error saving host YAML: {e}")
            import traceback
            traceback.print_exc()
            return False

    def _save_final_yaml(self, final_poscar_path: Path, output_dir: Path = None) -> Path:
        """Save final YAML with interstitial included in composition.

        This YAML references the final POSCAR that already contains the interstitial atoms.
        The composition is extracted from the POSCAR itself to ensure perfect alignment.

        Args:
            final_poscar_path: Path to the final POSCAR with interstitials
            output_dir: Output directory to save YAML (default: current directory)

        Returns:
            Path to the generated YAML file
        """
        import yaml
        from pathlib import Path

        try:
            # Extract actual composition from POSCAR
            actual_composition = self._extract_composition_from_poscar(final_poscar_path)

            if not actual_composition:
                print(f"    Warning: Could not extract composition from {final_poscar_path}")
                # Fallback to calculated composition
                actual_composition = dict(self.state.composition)
                actual_composition[self.state.interstitial_species] = self.state.interstitial_count

            # Build charges dict including interstitial
            charge_dict = {k: v for k, v in self.state.charges.items()}

            # Build recipes including interstitial
            # All elements map to themselves (no enumeration)
            recipe_entries = [
                {"from_kind": element, "to": [element]}
                for element in actual_composition.keys()
            ]

            # Use the final POSCAR as reference
            # For n_target_sites, use the actual total from final structure
            total_atoms = sum(actual_composition.values())

            config = {
                "structure": {
                    "poscar": str(Path(final_poscar_path).resolve()),
                    "n_target_sites": total_atoms
                },
                "composition": actual_composition,
                "charges": charge_dict,
                "solve": _production_solve_block(self.state),
                "output": {
                    **_host_output_block(),
                    "selection": _selection_block_from_state(self.state),
                },
                "recipes": recipe_entries if recipe_entries else []
            }

            # Use composition formula in YAML filename
            composition_with_interstitial = dict(actual_composition)
            final_formula = self._get_composition_formula(composition_with_interstitial)

            if output_dir is None:
                output_dir = Path.cwd()

            output_path = output_dir / f"{final_formula}.yaml"

            with open(output_path, "w") as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)

            return output_path.resolve()

        except Exception as e:
            print(f"  Error saving final YAML: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _detect_space_group(self, poscar_path: str) -> int:
        """Detect space group of POSCAR using spglib.

        Args:
            poscar_path: Path to POSCAR file

        Returns:
            Space group number (1-230) or None if detection fails
        """
        try:
            from esspy.init_scaffold import load_poscar
            import spglib

            # Load structure
            structure = load_poscar(poscar_path)
            if not structure or not hasattr(structure, 'cell'):
                return None

            # Prepare input for spglib
            lattice = structure.cell.matrix
            positions = [site.xyz for site in structure.sites]
            numbers = [ord(site.kind[0]) for site in structure.sites]  # Simple mapping

            # Detect symmetry
            dataset = spglib.get_symmetry_dataset(
                (lattice, positions, numbers),
                symprec=1e-5
            )

            if dataset and dataset.get('number'):
                return dataset['number']
            return None

        except ImportError:
            return None
        except Exception as e:
            return None

    def _find_wyc_file(self, space_group: int) -> Path:
        """Find Wyckoff position database file for a given space group.

        Searches multiple common locations for WYC files that contain Wyckoff
        symmetry operations. These files enable the add-sites algorithm to
        explore positions that respect crystal symmetry.

        Args:
            space_group: Space group number (1-230)

        Returns:
            Path object pointing to WYC file if found, None otherwise
        """
        from pathlib import Path

        # Possible locations to search for WYC files
        possible_paths = [
            # Current working directory
            Path.cwd() / f"{space_group}.wyc",

            # esspy site-packages (various Python versions)
            Path("/opt/homebrew/lib/python3.11/site-packages/esspy/data") / f"{space_group}.wyc",
            Path("/opt/homebrew/lib/python3.12/site-packages/esspy/data") / f"{space_group}.wyc",
            Path("/opt/homebrew/lib/python3.13/site-packages/esspy/data") / f"{space_group}.wyc",
            Path("/usr/local/lib/python3.11/site-packages/esspy/data") / f"{space_group}.wyc",
            Path("/usr/local/lib/python3.12/site-packages/esspy/data") / f"{space_group}.wyc",

            # System standard paths
            Path("/usr/local/share/esspy/wyc") / f"{space_group}.wyc",
            Path("/usr/local/share/esspy/") / f"{space_group}.wyc",
            Path("/opt/homebrew/share/esspy/wyc") / f"{space_group}.wyc",
            Path("/opt/homebrew/share/esspy/") / f"{space_group}.wyc",

            # Development environment
            Path(self.cwd) / "wyc_database" / f"{space_group}.wyc",
            Path(self.cwd).parent / "data" / f"{space_group}.wyc",
        ]

        for path in possible_paths:
            try:
                if path.exists() and path.is_file():
                    return path.resolve()
            except (OSError, ValueError):
                # Handle permission errors or invalid paths
                continue

        # Not found in any standard location
        return None

    def _create_final_poscar_with_interstitial(
        self, host_poscar_path: Path, add_sites_config: Dict[str, str], output_dir: Path = None
    ) -> Path:
        """Create final POSCAR with interstitial atoms added to host structure.

        Uses intelligent placement: cell center + offset positions for multiple atoms,
        respecting minimum distance constraints.

        Args:
            host_poscar_path: Path to host best POSCAR
            add_sites_config: Add-sites configuration with MinDistanceBetweenAddedSites
            output_dir: Output directory to save POSCAR (default: current directory)

        Returns:
            Path to final POSCAR file with interstitial
        """
        try:
            from esspy.init_scaffold import load_poscar
            from esspy.poscar import write_structure_to_poscar
            from esspy.models import Site, StructureModel, Lattice
            import numpy as np

            # Load host structure
            host_structure = load_poscar(str(host_poscar_path))
            if not host_structure:
                return None

            # Get constraint parameters
            min_distance = float(add_sites_config.get('MinDistanceBetweenAddedSites', 1.0))

            # Get lattice matrix for distance calculations
            lattice_a = np.array(host_structure.lattice.a)
            lattice_b = np.array(host_structure.lattice.b)
            lattice_c = np.array(host_structure.lattice.c)
            lattice_matrix = np.array([lattice_a, lattice_b, lattice_c]).T

            # Get host positions in fractional coordinates
            host_positions_frac = np.array([[site.x, site.y, site.z] for site in host_structure.sites])

            # Convert host positions to Cartesian for distance calculations
            host_positions_cart = host_positions_frac @ lattice_matrix

            # Generate candidate positions: cell center + offset positions
            candidates_frac = self._generate_interstitial_candidates(
                host_structure, min_distance, host_positions_cart, lattice_matrix
            )

            if len(candidates_frac) < self.state.interstitial_count:
                print(f"    ⚠ Warning: Only found {len(candidates_frac)} valid positions for {self.state.interstitial_count} interstitials")

            # Create new sites from the host structure
            new_sites = list(host_structure.sites)

            # Add interstitial atoms at candidate positions
            charge = self.state.charges.get(self.state.interstitial_species, 1.0)
            for i in range(min(self.state.interstitial_count, len(candidates_frac))):
                pos = candidates_frac[i]
                interstitial_site = Site(
                    kind=self.state.interstitial_species,
                    x=float(pos[0]),
                    y=float(pos[1]),
                    z=float(pos[2]),
                    oxidation=charge
                )
                new_sites.append(interstitial_site)

            # Create new structure
            final_structure = StructureModel(
                title=f"{host_structure.title}_with_{self.state.interstitial_species}",
                lattice=host_structure.lattice,
                sites=new_sites,
                fractional_coordinates=True
            )

            # Save final POSCAR with formula-based naming in output directory
            composition_with_interstitial = dict(self.state.composition)
            composition_with_interstitial[self.state.interstitial_species] = self.state.interstitial_count
            final_formula = self._get_composition_formula(composition_with_interstitial)

            if output_dir is None:
                output_dir = Path.cwd()

            final_poscar_path = output_dir / f"{final_formula}.vasp"

            poscar_content = write_structure_to_poscar(final_structure)
            with open(final_poscar_path, "w") as f:
                f.write(poscar_content)

            return final_poscar_path

        except Exception as e:
            print(f"    Error creating final POSCAR: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _generate_interstitial_candidates(
        self,
        host_structure,
        min_distance: float,
        host_positions_cart: np.ndarray,
        lattice_matrix: np.ndarray
    ) -> list:
        """Generate candidate positions for interstitial atoms.

        Uses grid-based search with progressively relaxed distance constraints.
        If strict constraint yields no candidates, tries relaxed constraints.
        """
        import numpy as np

        candidates_frac = []

        # Try with progressively relaxed constraints if needed
        distance_thresholds = [min_distance, min_distance * 0.8, min_distance * 0.6, 0.0]

        for threshold in distance_thresholds:
            if candidates_frac:
                break  # Found candidates with current threshold

            # Primary candidate: cell center
            center = np.array([0.5, 0.5, 0.5])
            if self._is_valid_position(center, host_positions_cart, lattice_matrix, threshold):
                candidates_frac.append(center)

            # Secondary candidates: offset positions (for multiple interstitials)
            offsets = [
                [0.25, 0.25, 0.25],
                [0.75, 0.75, 0.75],
                [0.25, 0.75, 0.25],
                [0.75, 0.25, 0.75],
                [0.5, 0.25, 0.75],
                [0.25, 0.5, 0.75],
                [0.75, 0.5, 0.25],
            ]

            for offset in offsets:
                pos_frac = np.array(offset)
                if self._is_valid_position(pos_frac, host_positions_cart, lattice_matrix, threshold):
                    # Check distance to already-placed interstitials
                    if not self._conflicts_with_placed(pos_frac, candidates_frac, lattice_matrix, threshold):
                        candidates_frac.append(pos_frac)
                        if len(candidates_frac) >= self.state.interstitial_count:
                            break

            if candidates_frac and threshold < min_distance:
                print(f"    Note: Using relaxed distance constraint ({threshold:.2f} Å) for interstitial placement")

        return candidates_frac

    def _is_valid_position(
        self,
        pos_frac: np.ndarray,
        host_positions_cart: np.ndarray,
        lattice_matrix: np.ndarray,
        min_distance: float
    ) -> bool:
        """Check if a fractional position is valid (far enough from host atoms)."""
        import numpy as np

        pos_cart = pos_frac @ lattice_matrix
        distances = np.linalg.norm(host_positions_cart - pos_cart, axis=1)
        return np.all(distances >= min_distance)

    def _conflicts_with_placed(
        self,
        pos_frac: np.ndarray,
        placed_frac: list,
        lattice_matrix: np.ndarray,
        min_distance: float
    ) -> bool:
        """Check if position conflicts with already-placed interstitials."""
        import numpy as np

        if not placed_frac:
            return False

        pos_cart = pos_frac @ lattice_matrix
        for placed in placed_frac:
            placed_cart = placed @ lattice_matrix
            dist = np.linalg.norm(pos_cart - placed_cart)
            if dist < min_distance:
                return True
        return False

    def _generate_add_sites_solver_config(self, add_sites_config: Dict[str, str], output_dir: Path = None) -> Path:
        """Generate add-sites solver text configuration file.

        Config parameters:
        - AddMeshes: grid spacing for candidate positions (e.g., "0.5 0.5 0.5")
        - MinDistanceBetweenAddedSites: minimum distance between atoms (Å)
        - NMonteCarlo: number of MC trials

        Args:
            add_sites_config: Configuration dictionary
            output_dir: Output directory to save config (default: current directory)

        Returns:
            Path to generated configuration file
        """
        from pathlib import Path

        if output_dir is None:
            output_dir = Path.cwd()

        # Use composition formula in filename
        composition_formula = self._get_composition_formula(self.state.composition)
        config_filename = f"{composition_formula}_add_sites.txt"
        config_path = output_dir / config_filename

        try:
            with open(config_path, "w") as f:
                f.write("# Add-sites solver configuration (auto-generated by wizard)\n")
                f.write("# Parameters:\n")
                f.write("#   AddMeshes: grid spacing for candidate positions\n")
                f.write("#   MinDistanceBetweenAddedSites: cutoff distance (Å)\n")
                f.write("#   NMonteCarlo: number of trials\n")
                f.write("\n")

                f.write("NEnergyTableLine 1\n")
                f.write("NAddKind 1\n")

                # Grid spacing for candidate positions
                meshes = add_sites_config.get('AddMeshes', '0.5 0.5 0.5')
                f.write(f"AddMeshes {meshes}\n")

                # Minimum distance constraint
                min_dist = add_sites_config.get('MinDistanceBetweenAddedSites', '1.0')
                f.write(f"MinDistanceBetweenAddedSites {min_dist}\n")

                # Number of MC trials
                n_mc = add_sites_config.get('NMonteCarlo', '100')
                f.write(f"NMonteCarlo {n_mc}\n")

                f.write("MonteCarloMonitorIndex 1\n")
                f.write("\n")

                # Add species line: SPECIES COUNT CHARGE REFERENCE_ELEMENT TOLERANCE_MIN TOLERANCE_MAX ENERGY_PENALTY
                species = self.state.interstitial_species
                count = self.state.interstitial_count
                charge = self.state.charges.get(species, 1.0)
                # Format: SPECIES COUNT CHARGE REFERENCE_ELEMENT (unused params)
                f.write(f"{species} {count} {charge} O 0.0 0.0 10000.0\n")

            return config_path
        except Exception as e:
            print(f"  Error generating solver config: {e}")
            return config_path
