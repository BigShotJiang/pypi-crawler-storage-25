"""CLI epilog examples for argparse help text."""

INIT_ROOT_EPILOG = """Initialize a new input.yaml from either POSCAR or legacy guider text.

Examples:
  # 01. Start from a host/reference POSCAR
  esspy init -p POSCAR --n-target-sites 112 --composition Mn=14,Cr=15,Ni=19,O=64 --charges Mn=2,Cr=3,Ni=2,O=-2 --recipe Mn:Mn,Ni --recipe Cr:Cr,Ni

  # 02. Minimal scaffold from POSCAR (writes input.yaml by default)
  esspy init -p POSCAR

  #    - If --recipe is omitted, init auto-generates safe identity recipes
  #      and includes editable substitution/interstitial templates in `examples`.

  # 03. Migrate an existing guider input text (writes input.yaml by default)
  esspy init --from-guider basic_properties_EwaldSolidSolutionGuider.txt

  # 04. Show full init options
  esspy init --help

  # 05. Set solve strategy directly in generated YAML
  esspy init -p POSCAR --solve-mode adaptive --solve-effort medium --time-budget-sec 600

  # 06. Configure post-solve structure selection defaults
  esspy init -p POSCAR --selection-mode auto_top_n --selection-limit 20 --selection-pick lowest --selection-interval left-closed
"""


RUN_EPILOG = """Run full guide + solve workflow from an input YAML.

Examples:
  # 01. Run full workflow and write outputs to a directory
  esspy run input.yaml --workdir run-001

  # 02. Run guide stage only (no solve)
  esspy run input.yaml --guide-only --workdir guide-only-run

  # 03. Override charges at runtime from a fitted model
  esspy run input.yaml --charge-model charge_model.json --workdir run-model
"""


INIT_FROM_POSCAR_EPILOG = """Create a starter input.yaml from a reference POSCAR.

Examples:
  # 01. Counts-based composition with explicit charges and recipes
  esspy init from-poscar POSCAR --n-target-sites 112 --composition Mn=14,Cr=15,Ni=19,O=64 --charges Mn=2,Cr=3,Ni=2,O=-2 --recipe Mn:Mn,Ni --recipe Cr:Cr,Ni

  # 02. Fraction-based composition
  esspy init from-poscar POSCAR --n-target-sites 112 --fractions Mn=0.125,Cr=0.1339285714,Ni=0.1696428571,O=0.5714285714 --charges Mn=2,Cr=3,Ni=2,O=-2 --recipe Mn:Mn,Ni --recipe Cr:Cr,Ni

  # 03. Force P1 symmetry scaffold
  esspy init from-poscar POSCAR --n-target-sites 112 --composition Mn=14,Cr=15,Ni=19,O=64 --charges Mn=2,Cr=3,Ni=2,O=-2 --recipe Mn:Mn,Ni --recipe Cr:Cr,Ni --symmetry p1

  # 04. Use strategy mode/effort/time-budget in solve.strategy
  esspy init from-poscar POSCAR --solve-mode bounded_exhaustive --solve-effort high --time-budget-sec 1800

  # 05. Configure output.selection block
  esspy init from-poscar POSCAR --selection-enabled true --selection-mode auto_top_n --selection-limit 20 --selection-pick lowest --selection-outdir selected_structures --selection-prefix selected

  # 06. Site-aware spinel allocation scaffold
  esspy init from-poscar POSCAR --n-target-sites 112 --composition Mn=7,Cr=15,Ni=9,Rh=5,Co=7,Fe=5,O=64 --charges Mn=2,Cr=3,Ni=2,Rh=3,Co=2,Fe=3,O=-1.890625 --charge-basis element_site --recipe Mn:Mn,Cr,Ni,Rh,Co,Fe --recipe Cr:Mn,Cr,Ni,Rh,Co,Fe --recipe O:O --site-group site1:Mn:Mn,Cr,Ni,Rh,Co,Fe --site-group site2:Cr:Mn,Cr,Ni,Rh,Co,Fe --site-group site3:O:O --allocation-time-budget-sec 180
"""


INIT_FROM_GUIDER_EPILOG = """Migrate legacy guider text into input.yaml.

Examples:
  # 01. Use POSCAR path referenced inside guider text (writes input.yaml by default)
  esspy init from-guider basic_properties_EwaldSolidSolutionGuider.txt

  # 02. Override POSCAR path explicitly (still writes input.yaml by default)
  esspy init from-guider basic_properties_EwaldSolidSolutionGuider.txt --poscar POSCAR

  # 03. Write to a custom path
  esspy init from-guider basic_properties_EwaldSolidSolutionGuider.txt --out custom_input.yaml

  # 04. Override solve strategy while migrating
  esspy init from-guider basic_properties_EwaldSolidSolutionGuider.txt --solve-mode adaptive --solve-effort medium --time-budget-sec 600 --max-swap 100

  # 05. Override output.selection while migrating
  esspy init from-guider basic_properties_EwaldSolidSolutionGuider.txt --selection-mode auto_top_n --selection-limit 20 --selection-pick lowest
"""


GUIDE_INSPECT_EPILOG = """Inspect guide-stage input and resolved solve-strategy mapping.

Examples:
  # 01. Human-readable summary (includes solve_strategy section)
  esspy guide inspect input.yaml

  # 02. JSON summary for automation
  esspy --json guide inspect input.yaml
"""


GUIDE_EXPORT_GUIDER_EPILOG = """Export legacy guider text from input.yaml.

Examples:
  # 01. Print guider text to stdout
  esspy guide export-guider input.yaml

  # 02. Write guider text to a file
  esspy guide export-guider input.yaml --out basic_properties_EwaldSolidSolutionGuider.txt
"""


GUIDE_EXPORT_READY_EPILOG = """Run guide stage and export ready text.

Examples:
  # 01. Print ready text to stdout
  esspy guide export-ready input.yaml

  # 02. Write ready text to a file
  esspy guide export-ready input.yaml --out basic_properties_EwaldSolidSolution.ready.txt
"""


SOLVE_RUN_EPILOG = """Alias of top-level 'esspy run' for solve-oriented usage.

Examples:
  # 01. Run full workflow from YAML
  esspy solve run input.yaml --workdir run-001
"""


SYMMETRY_DETECT_EPILOG = """Detect space-group symmetry from a POSCAR file.

Examples:
  # 01. Detect with default symprec
  esspy symmetry detect POSCAR

  # 02. Detect with explicit tolerance
  esspy symmetry detect POSCAR --symprec 1e-5
"""


SYMMETRY_WRITE_WYC_EPILOG = """Detect symmetry and write a guider-compatible WYC file.

Examples:
  # 01. Auto-name output as <space_group>.wyc
  esspy symmetry write-wyc POSCAR

  # 02. Write WYC to a specific file
  esspy symmetry write-wyc POSCAR --out symmetry.wyc
"""


SYMMETRY_INSPECT_WYC_EPILOG = """Inspect a WYC file and optional space-group conversion.

Examples:
  # 01. Basic WYC inspection
  esspy symmetry inspect-wyc symmetry.wyc

  # 02. Inspect and convert to symmetry model with space group
  esspy symmetry inspect-wyc symmetry.wyc --space-group 1
"""


ADD_SITES_EXPORT_SPEC_EPILOG = """Export add-sites MC block from solver text as YAML/JSON.

Examples:
  # 01. Export YAML spec to a file
  esspy add-sites export-spec --solver-text basic_properties_EwaldSolidSolution.txt --out add_sites_spec.yaml

  # 02. Print JSON spec to stdout
  esspy add-sites export-spec --solver-text basic_properties_EwaldSolidSolution.txt --format json
"""


FIT_CHARGE_EPILOG = """Examples:
  # 01. Minimal: dataset text file (2 columns: POSCAR energy_eV)
  esspy fit-charge dataset.txt

  # 02. Alias
  esspy fc dataset.txt

  # 03. Build dataset directly from filename patterns, then fit
  esspy fc -p 'sample-*.vasp' --outcar 'OUTCAR-sample-*.vasp'

  # 04. Custom outputs
  esspy fc dataset.txt --out-model charge_model.json --out-report fit_report.json --out-plot parity_plot.pdf

  # 05. Reuse quadratic precompute cache across runs (faster repeated fitting)
  #     - default cache path is ./ewald_quadratic_cache.npz
  esspy fc dataset.txt --cache ccs13_quadratic_cache.npz

  # 06. Disable cache/precompute and force direct full-Ewald evaluation
  esspy fc dataset.txt --no-precompute

  # 07. Site-aware fitting (different charges per site-group)
  esspy fc dataset.txt --basis element_site --input input.yaml
"""


ALLOCATION_OPTIMIZE_EPILOG = """Examples:
  # 01. Generate sitewise composition from global composition
  esspy allocation optimize input.yaml

  # 02. Custom outputs
  esspy allocation optimize input.yaml --out-yaml input.sitewise.yaml --out-table allocation_table.json --out-report allocation_report.json

  # 03. Bias an element toward a specific site-group
  esspy allocation optimize input.yaml --prefer Mn@site1=4.0 --prefer Cr@site2=4.0

  # 04. Multi-candidate search with reproducible seed
  esspy allocation optimize input.yaml --n-alloc 32 --seed 0

  # 05. Faster search (no guide gate), heuristic score only
  esspy allocation optimize input.yaml --score-mode site_affinity --no-guide-gate

  # 06. Choose Ewald metric (top-k mean)
  esspy allocation optimize input.yaml --score-mode ewald --metric topk_mean --topk 5
"""
