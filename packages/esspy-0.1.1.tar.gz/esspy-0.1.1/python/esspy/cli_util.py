from __future__ import annotations

import argparse
import json
from pathlib import Path
import glob

def _handle_util_schema(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .models import RunInput
    
    # Basic representation of the expected YAML structure
    schema = {
        "name": "string (optional)",
        "output": {
            "workdir": "string (optional)",
            "prefix": "string (optional)",
            "write_guider": "boolean (default: false)",
            "write_ready": "boolean (default: false)",
            "write_poscar": "boolean (default: false)",
            "write_summary_json": "boolean (default: true)",
            "selection": {
                "enabled": "boolean (default: true)",
                "mode": "string (auto_top_n | energy_window)",
                "limit": "int (default: 20)",
                "pick": "string (lowest | highest | random)",
                "interval": "string (open | left-closed | right-closed | closed)",
            },
        },
        "structure": {
            "title": "string",
            "n_target_sites": "int (optional when dim is set)",
            "dim": "[int,int,int] or 3x3 integer matrix (optional explicit supercell)",
            "lattice": {
                "a": "[float, float, float]",
                "b": "[float, float, float]",
                "c": "[float, float, float]",
            },
            "sites": [
                {"kind": "string", "x": "float", "y": "float", "z": "float"}
            ],
            "fractional_coordinates": "boolean (default: true)",
        },
        "composition": {
            "counts": {"<kind>": "int", "...": "..."},
            "fractions": {"<kind>": "float", "...": "..."},
        },
        "charges": {"<kind>": "float", "...": "..."},
        "recipes": [
            {"from": "string", "to": ["string", "string"]}
        ],
        "symmetry": {
            "mode": "string (auto | p1 | explicit)",
            "space_group": "int",
            "symprec": "float",
            "wyc_path": "string (optional)",
        },
        "guide": {
            "n_random_seeds": "int",
            "chop_level": "int",
            "target_cpu_time_sec": "int",
            "strict_no_added_sites": "boolean",
            "skip_rg_optimization": "boolean",
            "skip_ewald_evaluation": "boolean",
            "fixed_rg_find_factor": "int (optional)",
        },
        "solve": {
            "strategy": {
                "mode": "string (adaptive | bounded_exhaustive | exhaustive)",
                "time_budget_sec": "int (used when mode=adaptive)",
                "effort": "string (low | medium | high | extreme)",
                "swap": {
                    "enabled": "boolean",
                    "max_steps": "int",
                },
            },
            "advanced": {
                "running_index_delta": "int (legacy low-level override)",
                "local_enumeration_limit": "int",
                "local_enumeration_max_chunks": "int",
                "enumeration_exhaust_all": "boolean",
                "local_enumeration_stride": "int",
            },
            "swap_loop_enabled": "boolean",
            "swap_loop_mode": "int",
            "max_swap": "int",
            "swap_loop_seed_source": "int",
            "local_enumeration_limit": "int",
            "local_enumeration_max_chunks": "int",
        },
        "logging": {
            "console": "boolean (default: true)",
            "file": "boolean (default: true)",
            "progress_jsonl": "boolean (default: true)",
            "per_rank_logs": "boolean (default: true)",
            "interval_sec": "float (default: 10.0)",
            "write_best_so_far": "boolean (default: true)",
        },
    }
    
    print(json.dumps(schema, indent=2))
    return 0

def _handle_util_defaults(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .models import GuideOptions, LoggingOptions, SolveOptions
    
    g_opts = GuideOptions()
    s_opts = SolveOptions()
    l_opts = LoggingOptions()
    
    defaults = {
        "guide": {
            "n_random_seeds": g_opts.n_random_seeds,
            "shell_width": g_opts.shell_width,
            "wyc_identity_length": g_opts.wyc_identity_length,
            "abc_weights": g_opts.abc_weights,
            "chop_level": g_opts.chop_level,
            "target_cpu_time_sec": g_opts.target_cpu_time_sec,
            "strict_no_added_sites": g_opts.strict_no_added_sites,
            "skip_rg_optimization": g_opts.skip_rg_optimization,
            "skip_ewald_evaluation": g_opts.skip_ewald_evaluation,
            "fixed_rg_find_factor": g_opts.fixed_rg_find_factor,
        },
        "solve": {
            "strategy": {
                "mode": "adaptive",
                "time_budget_sec": 600,
                "effort": "medium",
                "swap": {
                    "enabled": True,
                    "max_steps": 100,
                },
            },
            "verbose": s_opts.verbose,
            "swap": s_opts.swap,
            "max_swap": s_opts.max_swap,
            "swap_loop_enabled": s_opts.swap_loop_enabled,
            "swap_loop_mode": s_opts.swap_loop_mode,
            "swap_loop_seed_source": s_opts.swap_loop_seed_source,
            "local_enumeration_limit": s_opts.local_enumeration_limit,
            "local_enumeration_max_chunks": s_opts.local_enumeration_max_chunks,
        },
        "logging": {
            "console": l_opts.console,
            "file": l_opts.file,
            "progress_jsonl": l_opts.progress_jsonl,
            "per_rank_logs": l_opts.per_rank_logs,
            "interval_sec": l_opts.interval_sec,
            "write_best_so_far": l_opts.write_best_so_far,
        },
    }
    print(json.dumps(defaults, indent=2))
    return 0

def _handle_util_doctor_native(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .native import load_native_module
    
    try:
        native = load_native_module()
        info = {
            "status": "ok",
            "module_name": native.__name__,
            "file": getattr(native, "__file__", "unknown"),
            "doc": getattr(native, "__doc__", "unknown"),
        }
        print(json.dumps(info, indent=2))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}, indent=2))
        return 1
    return 0

def _handle_util_show_example(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    example = """name: example_run
output:
  workdir: run-example
  write_guider: true
  write_ready: true
  write_poscar: true
  write_summary_json: true
  selection:
    enabled: true
    mode: auto_top_n
    limit: 20
    pick: lowest
    interval: left-closed
structure:
  title: Example POSCAR
  dim: [2, 1, 1]  # or use n_target_sites: 14 for auto supercell search
  number_fixed_at: O
  lattice:
    a: [8.0, 0.0, 0.0]
    b: [0.0, 8.0, 0.0]
    c: [0.0, 0.0, 8.0]
  sites:
    - kind: M
      x: 0.0
      y: 0.0
      z: 0.0
    - kind: O
      x: 0.5
      y: 0.5
      z: 0.5
  fractional_coordinates: true
composition:
  counts:
    M: 6
    O: 8
charges:
  M: 2.0
  O: -1.5
recipes:
  - from: M
    to: [A, B]
symmetry:
  mode: p1
guide:
  n_random_seeds: 2000
solve:
  strategy:
    mode: adaptive
    time_budget_sec: 600
    effort: medium
    swap:
      enabled: true
      max_steps: 100
  # Optional low-level override block
  advanced:
    local_enumeration_limit: 10000
    local_enumeration_max_chunks: 1000000
logging:
  console: true
  file: true
  progress_jsonl: true
  per_rank_logs: true
  interval_sec: 10.0
  write_best_so_far: true
"""
    print(example)
    return 0


def _supercell_candidate_to_dict(candidate) -> dict:
    return {
        "dim": list(candidate.dim),
        "matrix": [list(row) for row in candidate.matrix],
        "determinant": int(candidate.determinant),
        "n_atoms": int(candidate.n_atoms),
        "score": float(candidate.score),
        "count_error": float(candidate.count_error),
        "length_score": float(candidate.length_score),
        "angle_score": float(candidate.angle_score),
        "lengths": [float(value) for value in candidate.lengths],
        "angles_deg": [float(value) for value in candidate.angles_deg],
    }


def _format_vec(values, precision: int = 4) -> str:
    return "[" + ", ".join(f"{float(value):.{precision}f}" for value in values) + "]"


def _is_diagonal_matrix(matrix) -> bool:
    return all(
        int(matrix[row][col]) == 0
        for row in range(3)
        for col in range(3)
        if row != col
    )


def _format_matrix(matrix) -> str:
    return "[" + "; ".join(" ".join(str(int(value)) for value in row) for row in matrix) + "]"


def _parse_site_group_mapping(raw_values: list[str] | None) -> dict[str, list[str]]:
    mapping: dict[str, list[str]] = {}
    if not raw_values:
        return mapping
    for raw in raw_values:
        if ":" in raw:
            source, targets_raw = raw.split(":", 1)
        elif "->" in raw:
            source, targets_raw = raw.split("->", 1)
        else:
            raise ValueError(
                f"Invalid --map `{raw}` (expected SOURCE:TARGET1,TARGET2)"
            )
        source = source.strip()
        if not source:
            raise ValueError(f"Invalid --map `{raw}` (empty source kind)")
        targets = [
            item.strip()
            for chunk in targets_raw.split(",")
            for item in chunk.split()
            if item.strip()
        ]
        if not targets:
            raise ValueError(f"Invalid --map `{raw}` (empty target list)")
        mapping[source] = targets
    return mapping


def _default_site_group_mapping(structure) -> dict[str, list[str]]:
    mapping: dict[str, list[str]] = {}
    for site in structure.sites:
        mapping.setdefault(str(site.kind), [str(site.kind)])
    return mapping


def _handle_util_site_groups(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .poscar import load_poscar
    from .site_grouping import (
        SiteGroupingOptions,
        detect_site_groups,
        format_index_ranges,
        site_grouping_result_to_yaml,
    )

    try:
        poscar_path = Path(args.poscar)
        structure = load_poscar(poscar_path)
        mapping = _default_site_group_mapping(structure)
        mapping.update(_parse_site_group_mapping(args.map))
        result = detect_site_groups(
            structure,
            mapping,
            SiteGroupingOptions(
                mode=args.mode,
                symprec=float(args.symprec),
                angle_tolerance=float(args.angle_tolerance),
                fallback=str(args.fallback),
                strict=bool(args.strict),
            ),
        )
    except Exception as exc:
        payload = {"status": "error", "message": str(exc)}
        if getattr(args, "json", False):
            print(json.dumps(payload, indent=2))
        else:
            print(f"ERROR: {exc}")
        return 2

    payload = {
        "status": "ok",
        "poscar": str(Path(args.poscar)),
        **site_grouping_result_to_yaml(result),
        "warnings": list(result.warnings),
        "fallback_used": bool(result.fallback_used),
    }
    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2))
        return 0

    meta = result.metadata
    print("Site grouping")
    print(f"POSCAR       : {poscar_path}")
    print(f"mode         : {result.mode}")
    if meta.get("requested_mode") and meta.get("requested_mode") != result.mode:
        print(f"requested    : {meta.get('requested_mode')}")
    if meta.get("backend"):
        print(f"backend      : {meta.get('backend')}")
    if meta.get("international") or meta.get("space_group"):
        print(f"space group  : {meta.get('international')} ({meta.get('space_group')})")
    print(f"symprec      : {meta.get('symprec')}")
    print(f"angle tol    : {meta.get('angle_tolerance')}")
    if result.fallback_used:
        print("fallback     : yes")
    print()
    print("Groups")
    for group in result.groups:
        display = group.label.get("display") or group.source_kind
        site_sym = group.symmetry.get("site_symmetry", "")
        wyckoff = group.symmetry.get("wyckoff", "")
        details = [
            f"{group.name:<6}",
            f"{display:<8}",
            f"source={group.source_kind}",
            f"count={group.count}",
            f"indices={format_index_ranges(group.site_indices)}",
        ]
        if wyckoff:
            details.append(f"wyckoff={wyckoff}")
        if site_sym:
            details.append(f"site_sym={site_sym}")
        print("  " + "  ".join(details))
    if result.warnings:
        print()
        print("Warnings")
        for warning in result.warnings:
            print(f"  - {warning}")
    return 0


def _handle_util_supercell(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .poscar import load_poscar
    from .poscar import write_structure_to_poscar
    from .supercell_search import build_supercell_structure, search_supercell

    try:
        poscar_path = Path(args.poscar)
        structure = load_poscar(poscar_path)
        result = search_supercell(
            structure.lattice,
            n_base_atoms=len(structure.sites),
            n_target_atoms=int(args.n_target_sites),
            mode=args.mode,
            tolerance=float(args.tolerance),
            max_axis=args.max_axis,
            top=int(args.top),
            count_weight=float(args.count_weight),
            length_weight=float(args.length_weight),
            angle_weight=args.angle_weight,
            max_candidates=int(args.max_candidates),
        )
        written_path: Path | None = None
        output_target = args.out if args.out is not None else (None if args.json else "SPOSCAR")
        if output_target:
            supercell_structure = build_supercell_structure(
                structure,
                result.selected.matrix,
                title=(
                    f"{structure.title} | supercell "
                    f"det={result.selected.determinant}"
                ),
            )
            written_path = Path(output_target)
            written_path.write_text(write_structure_to_poscar(supercell_structure))
    except Exception as exc:
        payload = {"status": "error", "message": str(exc)}
        if getattr(args, "json", False):
            print(json.dumps(payload, indent=2))
        else:
            print(f"ERROR: {exc}")
        return 2

    selected = result.selected
    payload = {
        "status": "ok",
        "poscar": str(Path(args.poscar)),
        "mode": result.mode,
        "n_base_atoms": int(result.n_base_atoms),
        "n_target_atoms": int(result.n_target_atoms),
        "selected": _supercell_candidate_to_dict(selected),
        "candidates": [
            _supercell_candidate_to_dict(candidate) for candidate in result.candidates
        ],
        "written_poscar": str(written_path) if written_path is not None else None,
    }

    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2))
        return 0

    dim_text = " ".join(str(value) for value in selected.dim)
    print("Supercell search")
    print(f"POSCAR       : {poscar_path}")
    print(f"mode         : {result.mode}")
    print(f"base atoms   : {result.n_base_atoms}")
    print(f"target atoms : {result.n_target_atoms}")
    print()
    print("Selected")
    if _is_diagonal_matrix(selected.matrix):
        print(f"  dim         : [{selected.dim[0]}, {selected.dim[1]}, {selected.dim[2]}]")
    else:
        print("  dim         : non-diagonal 3x3 matrix")
    print(f"  matrix      : {_format_matrix(selected.matrix)}")
    print(f"  determinant : {selected.determinant}")
    print(
        f"  atoms       : {selected.n_atoms} "
        f"(error={100.0 * selected.count_error:.2f}%)"
    )
    print("  Cell metrics:")
    print(
        f"    a={selected.lengths[0]:.4f} A, "
        f"b={selected.lengths[1]:.4f} A, "
        f"c={selected.lengths[2]:.4f} A"
    )
    print(
        f"    alpha={selected.angles_deg[0]:.2f}°, "
        f"beta={selected.angles_deg[1]:.2f}°, "
        f"gamma={selected.angles_deg[2]:.2f}°"
    )
    print(f"  score       : {selected.score:.6g}")
    if written_path is not None:
        print(f"  wrote POSCAR: {written_path}")
    if _is_diagonal_matrix(selected.matrix):
        print(f"  init usage  : esspy init -p {poscar_path} --dim {dim_text} ...")
        print(f"  yaml        : structure.dim: [{selected.dim[0]}, {selected.dim[1]}, {selected.dim[2]}]")
    else:
        flat_matrix = " ".join(str(int(value)) for row in selected.matrix for value in row)
        print(f"  matrix form : --dim {flat_matrix}")
        print("  note        : use --out to inspect this general 3x3 matrix as a POSCAR")
    print()
    print("Top candidates")
    print("  #   det   form       atoms   err(%)   length_score   angle_score   score")
    for index, candidate in enumerate(result.candidates, 1):
        dim = (
            f"{candidate.dim[0]}x{candidate.dim[1]}x{candidate.dim[2]}"
            if _is_diagonal_matrix(candidate.matrix)
            else "matrix"
        )
        print(
            f"  {index:<3} {candidate.determinant:<5d} {dim:<10} {candidate.n_atoms:<7d} "
            f"{100.0 * candidate.count_error:>7.2f} "
            f"{candidate.length_score:>14.6g} "
            f"{candidate.angle_score:>13.6g} "
            f"{candidate.score:>9.6g}"
        )
    return 0


def _parse_charge_override_pairs(pairs: list[str] | None) -> dict[str, float]:
    overrides: dict[str, float] = {}
    if not pairs:
        return overrides
    for raw in pairs:
        if "=" not in raw:
            raise ValueError(f"Invalid --charge format `{raw}` (expected KIND=OXIDATION)")
        key, value = raw.split("=", 1)
        kind = key.strip()
        if not kind:
            raise ValueError(f"Invalid --charge format `{raw}` (empty element kind)")
        overrides[kind] = float(value)
    return overrides


def _expand_poscar_inputs(raw_paths: list[str]) -> list[Path]:
    expanded: list[Path] = []
    seen: set[Path] = set()
    for raw in raw_paths:
        matches = [Path(item) for item in glob.glob(raw)]
        if not matches:
            matches = [Path(raw)]
        for item in matches:
            path = item.resolve()
            if path in seen:
                continue
            seen.add(path)
            expanded.append(path)
    return expanded


def _kind_counts_from_structure(structure) -> tuple[list[str], dict[str, int]]:
    order: list[str] = []
    counts: dict[str, int] = {}
    for site in structure.sites:
        kind = site.kind
        if kind not in counts:
            order.append(kind)
            counts[kind] = 0
        counts[kind] += 1
    return order, counts


def _extract_poscar_metadata(poscar_path_str: str) -> dict:
    """Extract charges and RG info from POSCAR title line if present."""
    try:
        with open(poscar_path_str) as f:
            title = f.readline().strip()

        metadata = {}
        # Look for "charges: Cr=3.0 Mn=2.0 O=-2.1 | RG=3"
        if "charges:" in title and "|" in title:
            parts = title.split("|")
            for part in parts:
                part = part.strip()
                if part.startswith("charges:"):
                    charge_str = part.replace("charges:", "").strip()
                    for pair in charge_str.split():
                        if "=" in pair:
                            k, v = pair.split("=")
                            metadata[k] = float(v)
                elif part.startswith("RG="):
                    metadata["rg"] = int(part.replace("RG=", ""))
        return metadata
    except Exception:
        return {}


def _handle_util_ewald(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .default_charges import build_default_charges
    from .fit_charge import (
        _ewald_energy_for_structure,
        _read_site_group_labels_from_poscar_comment,
        _solve_options_single_eval,
        load_charge_model,
    )
    from .poscar import load_poscar
    from .mpi_context import detect_mpi_context

    try:
        charge_overrides = _parse_charge_override_pairs(args.charge)
    except ValueError as exc:
        print(json.dumps({"status": "error", "message": str(exc)}))
        return 2

    charge_model_path = getattr(args, "charge_model", None)
    charge_model_charges: dict[str, float] = {}
    if charge_model_path:
        try:
            charge_model_charges = load_charge_model(charge_model_path)
        except Exception as exc:
            print(json.dumps({"status": "error", "message": f"Could not load charge model: {exc}"}))
            return 2

    poscar_paths = _expand_poscar_inputs(args.poscar)
    if not poscar_paths:
        print(json.dumps({"status": "error", "message": "No POSCAR paths provided"}))
        return 2

    ctx = detect_mpi_context()
    is_writer = int(ctx.get("rank", 0)) == 0

    rows: list[dict] = []
    failures: list[dict] = []

    for poscar_path in poscar_paths:
        try:
            structure = load_poscar(poscar_path)
            kind_order, kind_counts = _kind_counts_from_structure(structure)
            if not kind_order:
                raise ValueError("No atomic sites found in structure")

            # Extract metadata from POSCAR title, if present
            poscar_metadata = _extract_poscar_metadata(poscar_path)

            metadata_charges = {k: v for k, v in poscar_metadata.items() if k != "rg"}
            default_charges = build_default_charges(kind_order)

            used_rg = poscar_metadata.get("rg") or args.rg_find_factor or 3
            chop_level = float(args.chop_level) if args.chop_level is not None else 8.0
            has_site_aware = any(
                "@" in str(key)
                for mapping in (metadata_charges, charge_model_charges, charge_overrides)
                for key in mapping
            )

            def _resolve_charge(element: str, site_key: str | None = None) -> float:
                keys: list[str] = []
                if site_key:
                    keys.append(site_key)
                keys.append(element)
                for mapping in (charge_overrides, charge_model_charges, metadata_charges, default_charges):
                    for key in keys:
                        if key in mapping:
                            return float(mapping[key])
                raise ValueError(
                    f"Missing charge for `{site_key}` and fallback `{element}`"
                    if site_key
                    else f"Missing charge for `{element}`"
                )

            atom_kind_labels: list[str] | None = None
            charges_used: dict[str, float]
            if has_site_aware:
                raw_site_labels = _read_site_group_labels_from_poscar_comment(poscar_path)
                if raw_site_labels is None:
                    raise ValueError(
                        "site-aware charges require '# site-xxx' labels in POSCAR coordinate lines"
                    )
                atom_kind_labels = [
                    f"{site.kind}@{label}" for site, label in zip(structure.sites, raw_site_labels)
                ]
                charges_used = {}
                for site, label in zip(structure.sites, atom_kind_labels):
                    charges_used[label] = _resolve_charge(site.kind, label)
            else:
                charges_used = {}
                for kind in kind_order:
                    charges_used[kind] = _resolve_charge(kind)

            energy = _ewald_energy_for_structure(
                poscar_path,
                charges_used,
                rg_find_factor=int(used_rg),
                chop_level=chop_level,
                solve_options=_solve_options_single_eval(),
                atom_kind_labels=atom_kind_labels,
            )
            source_parts = []
            if metadata_charges:
                source_parts.append("metadata")
            if charge_model_charges:
                source_parts.append("charge_model")
            if charge_overrides:
                source_parts.append("cli")
            source = "+".join(source_parts) if source_parts else "default"
            rows.append(
                {
                    "file": str(poscar_path),
                    "energy": float(energy),
                    "rg_find_factor": int(used_rg),
                    "n_sites": int(len(structure.sites)),
                    "charges_used": dict(charges_used),
                    "charge_basis": "element_site" if has_site_aware else "element",
                    "charge_source": source,
                }
            )
        except Exception as exc:
            failures.append({"file": str(poscar_path), "error": str(exc)})

    if not is_writer:
        return 0

    if args.json:
        print(
            json.dumps(
                {
                    "status": "ok" if not failures else "partial_error",
                    "results": rows,
                    "errors": failures,
                },
                indent=2,
            )
        )
    else:
        for row in rows:
            charges_str = " ".join(
                f"{k}={v:g}" for k, v in sorted(row["charges_used"].items())
            )
            print(
                f"{Path(row['file']).name}  "
                f"E={row['energy']:.6f} eV  "
                f"charges: {charges_str} ({row['charge_source']})  "
                f"RG={row['rg_find_factor']}  "
                f"N={row['n_sites']} sites"
            )
        for fail in failures:
            print(f"{Path(fail['file']).name}\tERROR\t{fail['error']}")

    return 0 if not failures else 1


def _handle_util_suggest_charges(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .default_charges import get_charge_bounds, DEFAULT_OXIDATION_BY_ELEMENT

    elements = args.elements if hasattr(args, 'elements') and args.elements else []

    if not elements:
        # Show all available elements
        print("=" * 70)
        print("Available Elements and Default Oxidation States")
        print("=" * 70)

        sorted_elements = sorted(DEFAULT_OXIDATION_BY_ELEMENT.keys())
        for elem in sorted_elements:
            default_val = DEFAULT_OXIDATION_BY_ELEMENT[elem]
            bounds = get_charge_bounds(elem)
            if bounds:
                min_val, max_val = bounds
                print(f"{elem:3} | Default: {default_val:+6.1f} | Range: [{min_val:+6.1f}, {max_val:+6.1f}]")
            else:
                print(f"{elem:3} | Default: {default_val:+6.1f} | Range: [not set]")
        return 0

    # Show specific elements
    output = {}
    print()
    for elem in elements:
        default_val = DEFAULT_OXIDATION_BY_ELEMENT.get(elem)
        bounds = get_charge_bounds(elem)

        if default_val is None:
            print(f"⚠ {elem}: Unknown element")
            output[elem] = {"default": None, "min": None, "max": None, "status": "unknown"}
        else:
            if bounds:
                min_val, max_val = bounds
                print(f"✓ {elem}: default={default_val:+.1f}, range=[{min_val:+.1f}, {max_val:+.1f}]")
                output[elem] = {"default": default_val, "min": min_val, "max": max_val}
            else:
                print(f"✓ {elem}: default={default_val:+.1f}, range=[not set]")
                output[elem] = {"default": default_val, "min": None, "max": None}

    if getattr(args, 'json', False):
        print(json.dumps(output, indent=2))

    return 0


def _handle_util_template_list(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    from .wizard_templates import list_templates, get_templates_dict

    templates = list_templates()

    print("\n" + "=" * 70)
    print("Available Structure Templates")
    print("=" * 70 + "\n")

    if not templates:
        print("No templates available.")
        return 0

    descriptions = get_templates_dict()

    for i, template_name in enumerate(templates, 1):
        info = descriptions.get(template_name, {})
        formula = info.get('formula', 'Unknown')
        n_atoms = info.get('n_atoms', '?')
        site_types = info.get('site_types', [])

        print(f"{i}) {template_name.capitalize()}")
        print(f"   Formula: {formula}")
        print(f"   Unit cell atoms: {n_atoms}")
        print(f"   Site types: {', '.join(site_types)}")
        print()

    if getattr(args, 'json', False):
        print(json.dumps(descriptions, indent=2))

    return 0


def _handle_util_random_structure(args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
    import random

    n_atoms = args.n_atoms if hasattr(args, 'n_atoms') else 112
    elements_str = args.elements if hasattr(args, 'elements') else "Mn,Ni,Cr,O"
    seed = args.seed if hasattr(args, 'seed') and args.seed is not None else None

    if seed is not None:
        random.seed(seed)

    elements = [e.strip() for e in elements_str.split(',')]
    if not elements:
        print("Error: No elements specified", file=__import__('sys').stderr)
        return 1

    if len(elements) < 1:
        print("Error: At least 1 element required", file=__import__('sys').stderr)
        return 1

    # Generate random counts
    counts = {}
    remaining = n_atoms

    # Distribute atoms randomly
    for i, elem in enumerate(elements[:-1]):
        # Give each element a random portion (but leave at least 1 atom for each remaining)
        max_count = remaining - (len(elements) - i - 1)
        count = random.randint(1, max_count)
        counts[elem] = count
        remaining -= count

    # Last element gets the remainder
    counts[elements[-1]] = remaining

    # Generate random charges
    from .default_charges import DEFAULT_OXIDATION_BY_ELEMENT, get_charge_bounds

    charges = {}
    for elem in elements:
        default = DEFAULT_OXIDATION_BY_ELEMENT.get(elem, 0.0)
        bounds = get_charge_bounds(elem)

        if bounds:
            min_val, max_val = bounds
            # Randomize within bounds
            charge = random.uniform(min_val, max_val)
            charges[elem] = round(charge, 2)
        else:
            charges[elem] = default

    # Calculate net charge
    net_charge = sum(counts[elem] * charges[elem] for elem in elements)

    output = {
        "n_atoms": n_atoms,
        "elements": elements,
        "counts": counts,
        "charges": charges,
        "net_charge": round(net_charge, 2),
        "seed": seed,
    }

    # Print summary
    print("\n" + "=" * 70)
    print("Random Structure Generation")
    print("=" * 70)
    print(f"\nTarget atoms: {n_atoms}")
    print(f"Elements: {', '.join(elements)}\n")

    print("Composition:")
    for elem in elements:
        count = counts[elem]
        pct = 100.0 * count / n_atoms
        print(f"  {elem:3}: {count:4} atoms ({pct:5.1f}%)")

    print("\nCharges:")
    for elem in elements:
        charge = charges[elem]
        total = count * charges[elem]
        print(f"  {elem}: {charge:+.2f}")

    print(f"\nNet charge: {net_charge:+.2f}")

    if abs(net_charge) > 0.1:
        print("⚠ Warning: System is not electrically neutral")
    else:
        print("✓ System is electrically neutral")

    if seed is not None:
        print(f"\nSeed: {seed}")

    if getattr(args, 'json', False):
        print(json.dumps(output, indent=2))

    return 0
