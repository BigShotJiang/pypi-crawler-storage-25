from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import yaml


@dataclass
class SelectionConfig:
    enabled: bool = True
    mode: str = "auto_top_n"  # auto_top_n | energy_window
    interval: str = "left-closed"  # open | left-closed | right-closed | closed
    energy_min: float | None = None
    energy_max: float | None = None
    limit: int = 20
    pick: str = "lowest"  # lowest | highest | random
    seed: int | None = None
    outdir: str = "selected_structures"
    prefix: str = "selected"
    on_missing: str = "skip"  # skip | error
    dedupe: str = "path-energy"  # path | path-energy | none
    write_index_tsv: bool = True


@dataclass
class OutputConfig:
    workdir: str | None = None
    prefix: str | None = None
    guider_filename: str = "basic_properties_EwaldSolidSolutionGuider.txt"
    ready_filename: str = "basic_properties_EwaldSolidSolution.ready.txt"
    poscar_filename: str | None = None
    best_poscar_filename: str | None = None
    worst_poscar_filename: str | None = None
    energy_filename: str | None = None
    input_filename: str | None = None
    summary_filename: str = "summary.json"
    write_guider: bool = True
    write_ready: bool = True
    write_poscar: bool = True
    write_summary_json: bool = True
    guider_log: str | None = None
    which_ess: str = "EwaldSolidSolution.x"
    which_ewald2vasp: str = "none"
    which_vasp: str = "none"
    vasp_output_directory: str = "vasp_out"
    vasp_pseudo_dir: str = "../potcar"
    selection: SelectionConfig | None = None

    def resolved_prefix(self, fallback: str) -> str:
        return str(self.prefix or fallback)

    def resolved_poscar_filename(self, fallback_prefix: str) -> str:
        return str(self.poscar_filename or "POSCAR_host_supercell.vasp")


def parse_output_config(data: Mapping[str, Any] | None) -> OutputConfig:
    data = data or {}
    if not isinstance(data, Mapping):
        raise ValueError("`output` must be a mapping when provided")
    return OutputConfig(
        workdir=_optional_str(data.get("workdir")),
        prefix=_optional_str(data.get("prefix")),
        guider_filename=str(
            data.get("guider_filename")
            or data.get("guider")
            or "basic_properties_EwaldSolidSolutionGuider.txt"
        ),
        ready_filename=str(
            data.get("ready_filename")
            or data.get("ready")
            or "basic_properties_EwaldSolidSolution.ready.txt"
        ),
        poscar_filename=_optional_str(data.get("poscar_filename") or data.get("poscar")),
        best_poscar_filename=_optional_str(data.get("best_poscar_filename")),
        worst_poscar_filename=_optional_str(data.get("worst_poscar_filename")),
        energy_filename=_optional_str(data.get("energy_filename")),
        input_filename=_optional_str(data.get("input_filename")),
        summary_filename=str(
            data.get("summary_filename")
            or data.get("summary")
            or "summary.json"
        ),
        write_guider=bool(data.get("write_guider", True)),
        write_ready=bool(data.get("write_ready", True)),
        write_poscar=bool(data.get("write_poscar", True)),
        write_summary_json=bool(data.get("write_summary_json", True)),
        guider_log=_optional_str(data.get("guider_log")),
        which_ess=str(data.get("which_ess") or "EwaldSolidSolution.x"),
        which_ewald2vasp=str(data.get("which_ewald2vasp") or "none"),
        which_vasp=str(data.get("which_vasp") or "none"),
        vasp_output_directory=str(data.get("vasp_output_directory") or "vasp_out"),
        vasp_pseudo_dir=str(data.get("vasp_pseudo_dir") or "../potcar"),
        selection=_parse_selection_config(data.get("selection")),
    )


def load_output_config(path: str | Path) -> OutputConfig:
    path = Path(path)
    payload = yaml.safe_load(path.read_text()) or {}
    if not isinstance(payload, Mapping):
        raise ValueError("root YAML must be a mapping")
    output = payload.get("output", {})
    return parse_output_config(output if isinstance(output, Mapping) else output)


def _optional_str(value: object) -> str | None:
    if value is None:
        return None
    return str(value)


def _parse_selection_config(value: object) -> SelectionConfig:
    if value is None:
        return SelectionConfig()
    if not isinstance(value, Mapping):
        raise ValueError("`output.selection` must be a mapping when provided")
    return SelectionConfig(
        enabled=bool(value.get("enabled", True)),
        mode=str(value.get("mode") or "auto_top_n"),
        interval=str(value.get("interval") or "left-closed"),
        energy_min=(None if value.get("energy_min") is None else float(value.get("energy_min"))),
        energy_max=(None if value.get("energy_max") is None else float(value.get("energy_max"))),
        limit=int(value.get("limit", 20)),
        pick=str(value.get("pick") or "lowest"),
        seed=(None if value.get("seed") is None else int(value.get("seed"))),
        outdir=str(value.get("outdir") or "selected_structures"),
        prefix=str(value.get("prefix") or "selected"),
        on_missing=str(value.get("on_missing") or "skip"),
        dedupe=str(value.get("dedupe") or "path-energy"),
        write_index_tsv=bool(value.get("write_index_tsv", True)),
    )
