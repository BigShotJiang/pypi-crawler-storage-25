from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from .config import _parse_guide_options
from .models import ChargeMap, GuideInput, GuideOptions, RecipeSpec, RunInput
from .models import (
    ChargeEntry,
    CompositionEntry,
    CompositionModel,
    ParallelRuntimeOptions,
    SolveOptions,
    SymmetryModel,
)
from .poscar import load_poscar


@dataclass
class GuiderTextSpec:
    path: Path
    target_fractions: dict[str, float]
    number_fixed_at: str
    n_target_sites: int
    charges: dict[str, float]
    poscar_filename: str
    output_prefix: str
    space_group: int
    recipes: list[RecipeSpec]
    options: GuideOptions


_RECIPE_PATTERN = re.compile(r"\(\s*([A-Za-z0-9_]+)\s*->\s*([A-Za-z0-9_\s]+?)\s*\)")


def _parse_target_line(line: str) -> dict[str, float]:
    parts = line.split()[1:]
    if len(parts) % 2 != 0:
        raise ValueError("Malformed Target line")
    target_fractions: dict[str, float] = {}
    for index in range(0, len(parts), 2):
        target_fractions[str(parts[index])] = float(parts[index + 1])
    return target_fractions


def _parse_ionlist(lines: list[str], start_index: int) -> tuple[dict[str, float], int]:
    charges: dict[str, float] = {}
    index = start_index + 1
    while index < len(lines):
        line = lines[index].strip()
        if line == "STOP":
            return charges, index
        kind, oxidation = line.split()[:2]
        charges[kind] = float(oxidation)
        index += 1
    raise ValueError("IonList block missing STOP")


def _parse_recipe_line(line: str) -> tuple[str, str, int, list[RecipeSpec]]:
    parts = line.split()
    if len(parts) < 5:
        raise ValueError("Malformed guider recipe line")
    poscar_filename = parts[0]
    output_prefix = parts[1]
    space_group = int(parts[2])
    recipes = [
        RecipeSpec(from_kind=match.group(1), to=match.group(2).split())
        for match in _RECIPE_PATTERN.finditer(line)
    ]
    return poscar_filename, output_prefix, space_group, recipes


def parse_guider_text(path: str | Path) -> GuiderTextSpec:
    path = Path(path)
    lines = path.read_text().splitlines()

    target_fractions: dict[str, float] | None = None
    number_fixed_at = "O"
    n_target_sites: int | None = None
    charges: dict[str, float] = {}
    poscar_filename = ""
    output_prefix = ""
    space_group = 1
    recipes: list[RecipeSpec] = []
    option_values: dict[str, object] = {}

    index = 0
    while index < len(lines):
        line = lines[index].strip()
        if not line:
            index += 1
            continue
        if line.startswith("Target\t") or line.startswith("Target "):
            target_fractions = _parse_target_line(line)
        elif line.startswith('NumberFixedAt'):
            number_fixed_at = line.split()[-1]
        elif line.startswith("NTargetSites"):
            n_target_sites = int(line.split()[-1])
        elif line.startswith("NRandomSeeds"):
            option_values["n_random_seeds"] = int(line.split()[-1])
        elif line.startswith("ShellWidth"):
            option_values["shell_width"] = float(line.split()[-1])
        elif line.startswith("WYCIdentityLength"):
            option_values["wyc_identity_length"] = float(line.split()[-1])
        elif line.startswith("ABCWeights"):
            option_values["abc_weights"] = [float(x) for x in line.split()[1:4]]
        elif line.startswith("ChopLevel"):
            option_values["chop_level"] = int(line.split()[-1])
        elif line.startswith("TargetCPUTimeInSec"):
            option_values["target_cpu_time_sec"] = int(line.split()[-1])
        elif line.startswith("StrictNoAddedSites"):
            option_values["strict_no_added_sites"] = line.split()[-1].lower() == "true"
        elif line.startswith("SkipRGOptimization"):
            option_values["skip_rg_optimization"] = line.split()[-1].lower() == "true"
        elif line.startswith("SkipEwaldEvaluation"):
            option_values["skip_ewald_evaluation"] = line.split()[-1].lower() == "true"
        elif line == "====IonList====":
            charges, index = _parse_ionlist(lines, index)
        elif line == "====InputFilename_Prefix_SapceGroup_Recipe_List====":
            poscar_filename, output_prefix, space_group, recipes = _parse_recipe_line(
                lines[index + 1].strip()
            )
        index += 1

    if target_fractions is None:
        raise ValueError(f"Missing Target block in {path}")
    if n_target_sites is None:
        raise ValueError(f"Missing NTargetSites in {path}")
    if not poscar_filename:
        raise ValueError(f"Missing recipe/POSCAR line in {path}")

    return GuiderTextSpec(
        path=path,
        target_fractions=target_fractions,
        number_fixed_at=number_fixed_at,
        n_target_sites=n_target_sites,
        charges=charges,
        poscar_filename=poscar_filename,
        output_prefix=output_prefix,
        space_group=space_group,
        recipes=recipes,
        options=_parse_guide_options(option_values),
    )


def guider_text_to_run_input(spec: GuiderTextSpec, base_dir: str | Path | None = None) -> RunInput:
    if base_dir is None:
        base_dir = spec.path.parent
    base_dir = Path(base_dir)
    structure = load_poscar(base_dir / spec.poscar_filename)
    structure.title = spec.output_prefix

    entries = [
        CompositionEntry(kind=kind, count=int(round(fraction * spec.n_target_sites)))
        for kind, fraction in spec.target_fractions.items()
    ]
    composition = CompositionModel(
        entries=entries,
        n_target_sites=spec.n_target_sites,
        number_fixed_at=spec.number_fixed_at,
    )
    charges = ChargeMap(
        values=[ChargeEntry(kind=kind, oxidation=oxidation) for kind, oxidation in spec.charges.items()]
    )
    guide = GuideInput(
        structure=structure,
        composition=composition,
        charges=charges,
        recipes=spec.recipes,
        symmetry=SymmetryModel(space_group=spec.space_group),
        options=spec.options,
    )
    return RunInput(guide=guide, solve=SolveOptions(), runtime=ParallelRuntimeOptions())
