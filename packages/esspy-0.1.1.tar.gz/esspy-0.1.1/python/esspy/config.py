from __future__ import annotations

import json
from pathlib import Path
import math
from typing import Any

import yaml

from .models import (
    ChargeEntry,
    ChargeMap,
    CompositionEntry,
    CompositionModel,
    GuideInput,
    GuideOptions,
    Lattice,
    LoggingOptions,
    ParallelRuntimeOptions,
    RecipeSpec,
    RunInput,
    Site,
    SolveOptions,
    StructureModel,
    SymmetryModel,
)
from .poscar import load_poscar
from .site_grouping import validate_site_groups_contract
from .symmetry_auto import detect_symmetry_with_spglib, write_wyc_file
from .wyc import parse_wyc_file_to_symmetry_model


def _require_mapping(value, name: str) -> dict:
    if not isinstance(value, dict):
        raise ValueError(f"`{name}` must be a mapping")
    return value


def _vec3(value, name: str) -> tuple[float, float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise ValueError(f"`{name}` must be a length-3 sequence")
    return (float(value[0]), float(value[1]), float(value[2]))


def _int_vec3(value, name: str) -> tuple[int, int, int]:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise ValueError(f"`{name}` must be a length-3 sequence")
    result: list[int] = []
    for index, raw in enumerate(value):
        if isinstance(raw, bool):
            raise ValueError(f"`{name}[{index}]` must be a positive integer")
        try:
            as_float = float(raw)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"`{name}[{index}]` must be a positive integer") from exc
        as_int = int(as_float)
        if as_int != as_float or as_int <= 0:
            raise ValueError(f"`{name}[{index}]` must be a positive integer")
        result.append(as_int)
    return (result[0], result[1], result[2])


def _dim_to_diagonal_expansion(value, name: str) -> tuple[int, int, int]:
    if (
        isinstance(value, (list, tuple))
        and len(value) == 3
        and all(isinstance(row, (list, tuple)) for row in value)
    ):
        rows = [list(row) for row in value]
        if any(len(row) != 3 for row in rows):
            raise ValueError(f"`{name}` matrix rows must each contain 3 integers")
        matrix: list[list[int]] = []
        for row_index, row in enumerate(rows):
            matrix_row: list[int] = []
            for col_index, raw in enumerate(row):
                if isinstance(raw, bool):
                    raise ValueError(
                        f"`{name}[{row_index}][{col_index}]` must be an integer"
                    )
                as_float = float(raw)
                as_int = int(as_float)
                if as_int != as_float:
                    raise ValueError(
                        f"`{name}[{row_index}][{col_index}]` must be an integer"
                    )
                matrix_row.append(as_int)
            matrix.append(matrix_row)
        off_diagonal = [
            matrix[row][col]
            for row in range(3)
            for col in range(3)
            if row != col
        ]
        diagonal = (matrix[0][0], matrix[1][1], matrix[2][2])
        if any(item != 0 for item in off_diagonal):
            raise ValueError(
                f"`{name}` non-diagonal 3x3 matrices are not yet supported by "
                "the current diagonal supercell engine"
            )
        if any(item <= 0 for item in diagonal):
            raise ValueError(f"`{name}` diagonal entries must be positive")
        return diagonal

    if isinstance(value, (list, tuple)) and len(value) == 9:
        return _dim_to_diagonal_expansion(
            [list(value[0:3]), list(value[3:6]), list(value[6:9])],
            name,
        )

    return _int_vec3(value, name)


def _parse_structure_supercell(
    structure_data: dict,
    structure: StructureModel,
    *,
    normalize_to_resolved_target: bool = False,
) -> tuple[int, tuple[int, int, int] | None]:
    explicit_supercell = None
    if "dim" in structure_data:
        explicit_supercell = _dim_to_diagonal_expansion(
            structure_data["dim"], "structure.dim"
        )
    elif "supercell" in structure_data:
        explicit_supercell = _dim_to_diagonal_expansion(
            structure_data["supercell"], "structure.supercell"
        )
    elif "supercell_expansion" in structure_data:
        explicit_supercell = _int_vec3(
            structure_data["supercell_expansion"],
            "structure.supercell_expansion",
        )

    derived_target = None
    if explicit_supercell is not None:
        scale = explicit_supercell[0] * explicit_supercell[1] * explicit_supercell[2]
        derived_target = len(structure.sites) * scale

    raw_target = structure_data.get("n_target_sites")
    if raw_target is None:
        if derived_target is None:
            raise ValueError("`structure.n_target_sites` or `structure.dim` is required")
        return int(derived_target), explicit_supercell

    n_target_sites = int(raw_target)
    if derived_target is not None and n_target_sites != derived_target:
        raise ValueError(
            "`structure.n_target_sites` does not match `structure.dim`: "
            f"{n_target_sites} != {len(structure.sites)}*"
            f"{explicit_supercell[0]}*{explicit_supercell[1]}*{explicit_supercell[2]} "
            f"({derived_target})"
        )
    if derived_target is None and normalize_to_resolved_target:
        try:
            from .guide_supercell import compute_supercell_expansion

            resolved = compute_supercell_expansion(
                structure.lattice,
                len(structure.sites),
                n_target_sites,
            )
            if resolved.expanded_n_atom_config > 0:
                n_target_sites = int(resolved.expanded_n_atom_config)
        except Exception:
            # Keep config loading usable even when the native guide helper is not
            # available. The guide stage will still resolve the final supercell.
            pass
    return n_target_sites, explicit_supercell


def _parse_lattice(data: dict) -> Lattice:
    return Lattice(
        a=_vec3(data["a"], "structure.lattice.a"),
        b=_vec3(data["b"], "structure.lattice.b"),
        c=_vec3(data["c"], "structure.lattice.c"),
    )


def _parse_sites(data: list[dict]) -> list[Site]:
    sites: list[Site] = []
    for index, item in enumerate(data):
        item = _require_mapping(item, f"structure.sites[{index}]")
        sites.append(
            Site(
                kind=str(item["kind"]),
                x=float(item["x"]),
                y=float(item["y"]),
                z=float(item["z"]),
                oxidation=float(item.get("oxidation", 0.0)),
            )
        )
    return sites


def _parse_structure(data: dict, base_dir: Path) -> StructureModel:
    if "poscar" in data:
        poscar_path = base_dir / str(data["poscar"])
        structure = load_poscar(poscar_path)
        if "title" in data:
            structure.title = str(data["title"])
        if "fractional_coordinates" in data:
            structure.fractional_coordinates = bool(data["fractional_coordinates"])
        return structure
    lattice = _parse_lattice(_require_mapping(data["lattice"], "structure.lattice"))
    sites = _parse_sites(data["sites"])
    return StructureModel(
        title=str(data.get("title", "")),
        lattice=lattice,
        sites=sites,
        fractional_coordinates=bool(data.get("fractional_coordinates", True)),
    )


def _parse_composition(
    data: dict,
    structure_data: dict,
    *,
    n_target_sites: int,
) -> CompositionModel:
    number_fixed_at = str(structure_data.get("number_fixed_at", "O"))

    has_counts = "counts" in data
    has_fractions = "fractions" in data
    if has_counts and has_fractions:
        raise ValueError("`composition` must not define both `counts` and `fractions`")

    if has_counts:
        counts_data = _require_mapping(data["counts"], "composition.counts")
        entries = [
            CompositionEntry(kind=str(kind), count=int(count))
            for kind, count in counts_data.items()
        ]
    elif has_fractions:
        fractions_data = _require_mapping(data["fractions"], "composition.fractions")
        entries = _composition_entries_from_fractions(
            fractions_data,
            n_target_sites=n_target_sites,
            number_fixed_at=number_fixed_at,
        )
    else:
        entries = [
            CompositionEntry(kind=str(kind), count=int(count))
            for kind, count in data.items()
        ]

    total = sum(entry.count for entry in entries)
    if total != n_target_sites:
        raise ValueError(
            f"`composition` counts sum to {total}, expected structure.n_target_sites={n_target_sites}"
        )
    return CompositionModel(
        entries=entries,
        n_target_sites=n_target_sites,
        number_fixed_at=number_fixed_at,
    )


def _composition_entries_from_fractions(
    data: dict,
    *,
    n_target_sites: int,
    number_fixed_at: str,
) -> list[CompositionEntry]:
    if not data:
        raise ValueError("`composition.fractions` must not be empty")

    raw = [(str(kind), float(fraction)) for kind, fraction in data.items()]
    if any(fraction < 0.0 for _, fraction in raw):
        raise ValueError("`composition.fractions` must be non-negative")
    fraction_total = sum(fraction for _, fraction in raw)
    if fraction_total <= 0.0:
        raise ValueError("`composition.fractions` must sum to a positive number")
    raw = [(kind, fraction / fraction_total) for kind, fraction in raw]

    fixed_index = next(
        (index for index, (kind, _) in enumerate(raw) if kind == number_fixed_at),
        None,
    )
    if fixed_index is None:
        counts: list[int] = []
        remainders: list[tuple[float, int]] = []
        for index, (_, fraction) in enumerate(raw):
            scaled = fraction * n_target_sites
            count = int(math.floor(scaled))
            counts.append(count)
            remainders.append((scaled - count, index))
        missing = n_target_sites - sum(counts)
        for _, index in sorted(remainders, reverse=True)[:missing]:
            counts[index] += 1
        return [
            CompositionEntry(kind=kind, count=count)
            for (kind, _), count in zip(raw, counts)
        ]

    counts: list[int] = []
    remainders: list[tuple[float, int]] = []
    for index, (_, fraction) in enumerate(raw):
        if index == fixed_index:
            counts.append(0)
            continue
        scaled = fraction * n_target_sites
        count = int(math.floor(scaled))
        counts.append(count)
        remainders.append((scaled - count, index))

    target_nonfixed = int(
        round(sum(fraction for index, (_, fraction) in enumerate(raw) if index != fixed_index) * n_target_sites)
    )
    missing = target_nonfixed - sum(counts)
    for _, index in sorted(remainders, reverse=True)[:missing]:
        counts[index] += 1

    residue = n_target_sites - sum(counts)
    if residue < 0:
        raise ValueError(
            "`composition.fractions` non-fixed species exceed structure.n_target_sites"
        )
    counts[fixed_index] = residue
    return [
        CompositionEntry(kind=kind, count=count)
        for (kind, _), count in zip(raw, counts)
    ]


def _charge_map_from_mapping(data: dict, context: str) -> ChargeMap:
    values: list[ChargeEntry] = []
    for kind, oxidation in data.items():
        if isinstance(oxidation, bool):
            raise ValueError(f"`{context}.{kind}` must be numeric, got boolean")
        try:
            ox = float(oxidation)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"`{context}.{kind}` must be numeric") from exc
        values.append(ChargeEntry(kind=str(kind), oxidation=ox))
    if not values:
        raise ValueError(f"`{context}` must not be empty")
    return ChargeMap(values=values)


def _load_charge_mapping_from_model(model_path: Path) -> dict[str, float]:
    payload = json.loads(model_path.read_text())
    if not isinstance(payload, dict):
        raise ValueError(f"`charges` model must be a JSON object: {model_path}")

    data = payload.get("charges")
    if not isinstance(data, dict):
        raise ValueError(f"`{model_path}` must contain `charges` object (v2)")
    elements = data.get("elements")
    if not isinstance(elements, dict):
        raise ValueError(f"`{model_path}` must contain `charges.elements` mapping (v2)")
    out: dict[str, float] = {}
    for elem, node in elements.items():
        if not isinstance(node, dict):
            continue
        by_site = node.get("by_site", {})
        if isinstance(by_site, dict) and by_site:
            for site, oxidation in by_site.items():
                out[f"{str(elem).strip()}@{str(site).strip()}"] = float(oxidation)
            continue
        if "default" in node:
            out[str(elem).strip()] = float(node["default"])
    if not out:
        raise ValueError(f"`{model_path}` has no usable entries in `charges.elements`")
    return out


def _parse_charges(data: dict, base_dir: Path) -> ChargeMap:
    mode = str(data.get("mode", "")).strip().lower() if "mode" in data else ""
    model_ref = data.get("fitted_model", data.get("model"))

    if mode in {"fitted", "model"} or model_ref is not None:
        if model_ref is None:
            raise ValueError(
                "`charges.mode: fitted` requires `charges.fitted_model` (or `charges.model`)"
            )
        model_path = Path(str(model_ref))
        if not model_path.is_absolute():
            model_path = (base_dir / model_path).resolve()
        if not model_path.exists():
            raise FileNotFoundError(f"Charge model not found: {model_path}")
        mapping = _load_charge_mapping_from_model(model_path)
        return _charge_map_from_mapping(mapping, "charges.model")

    if mode in {"fixed", "direct"}:
        if "values" in data:
            values = _require_mapping(data["values"], "charges.values")
            return _charge_map_from_mapping(values, "charges.values")
        if "elements" in data:
            elements = _require_mapping(data["elements"], "charges.elements")
            collapsed: dict[str, float] = {}
            for elem, entry in elements.items():
                if not isinstance(entry, dict):
                    raise ValueError(
                        f"`charges.elements.{elem}` must be a mapping with `default` and optional `by_site`"
                    )
                if "default" not in entry:
                    raise ValueError(f"`charges.elements.{elem}.default` is required")
                collapsed[str(elem)] = float(entry["default"])
            return _charge_map_from_mapping(collapsed, "charges.elements")
        legacy = {
            k: v
            for k, v in data.items()
            if k not in {"mode", "basis", "by_site", "values", "fitted_model", "model", "elements"}
        }
        if not legacy:
            raise ValueError("`charges.mode: fixed` requires `charges.values` or `charges.elements`")
        return _charge_map_from_mapping(legacy, "charges")

    if "values" in data:
        values = _require_mapping(data["values"], "charges.values")
        return _charge_map_from_mapping(values, "charges.values")
    if "elements" in data:
        elements = _require_mapping(data["elements"], "charges.elements")
        collapsed: dict[str, float] = {}
        for elem, entry in elements.items():
            if not isinstance(entry, dict):
                raise ValueError(
                    f"`charges.elements.{elem}` must be a mapping with `default` and optional `by_site`"
                )
            if "default" not in entry:
                raise ValueError(f"`charges.elements.{elem}.default` is required")
            collapsed[str(elem)] = float(entry["default"])
        return _charge_map_from_mapping(collapsed, "charges.elements")

    legacy = {
        k: v
        for k, v in data.items()
        if k not in {"mode", "basis", "by_site", "values", "fitted_model", "model", "elements"}
    }
    return _charge_map_from_mapping(legacy, "charges")


def _parse_recipes(data: list[dict]) -> list[RecipeSpec]:
    recipes: list[RecipeSpec] = []
    for index, item in enumerate(data):
        item = _require_mapping(item, f"recipes[{index}]")
        from_kind = item.get("from_kind", item.get("from"))
        if from_kind is None:
            raise ValueError(f"`recipes[{index}]` must define `from` or `from_kind`")
        to = item.get("to")
        if not isinstance(to, list) or not to:
            raise ValueError(f"`recipes[{index}].to` must be a non-empty list")
        normalized_to = [str(x) for x in to]
        # Legacy ESS semantics: pure identity rules (e.g., O -> O) are
        # effectively no-ops and can distort parity if treated as active
        # nested recipes. Skip them at parse-time.
        if len(normalized_to) == 1 and normalized_to[0] == str(from_kind):
            continue
        recipes.append(RecipeSpec(from_kind=str(from_kind), to=normalized_to))
    return recipes


def _source_to_group_map(site_groups: dict) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for group_name, info in site_groups.items():
        if not isinstance(info, dict):
            continue
        source_kind = info.get("source_kind")
        if source_kind is None:
            continue
        mapping[str(source_kind)] = str(group_name)
    return mapping


def _aggregate_sitewise_composition(
    composition_by_site: dict,
) -> tuple[dict[str, int], dict[str, dict[str, int]]]:
    by_site_counts: dict[str, dict[str, int]] = {}
    aggregated: dict[str, int] = {}
    for group_name, row in composition_by_site.items():
        if not isinstance(row, dict):
            raise ValueError(f"`composition_by_site.{group_name}` must be a mapping")
        row_counts: dict[str, int] = {}
        for kind, value in row.items():
            count = int(value)
            if count < 0:
                raise ValueError(
                    f"`composition_by_site.{group_name}.{kind}` must be >= 0"
                )
            row_counts[str(kind)] = count
            aggregated[str(kind)] = aggregated.get(str(kind), 0) + count
        by_site_counts[str(group_name)] = row_counts
    return aggregated, by_site_counts


def _recipes_from_sitewise(
    composition_by_site_counts: dict[str, dict[str, int]],
    source_to_group: dict[str, str],
) -> list[dict[str, Any]]:
    if not source_to_group:
        raise ValueError(
            "`composition_by_site` requires `site_groups` with `source_kind` entries"
        )

    # Build unique owner group per element using max count across groups.
    # This prevents duplicate assignment paths in nested recipe expansion.
    all_elements: set[str] = set()
    for row in composition_by_site_counts.values():
        for kind, count in row.items():
            if int(count) > 0:
                all_elements.add(str(kind))

    owner_group_for_element: dict[str, str] = {}
    for elem in sorted(all_elements):
        best_group = None
        best_count = -1
        for source_kind, group_name in source_to_group.items():
            row = composition_by_site_counts.get(group_name, {})
            cnt = int(row.get(elem, 0))
            if cnt > best_count:
                best_count = cnt
                best_group = group_name
            elif cnt == best_count and cnt > 0:
                if source_kind == elem:
                    best_group = group_name
        if best_group is not None and best_count > 0:
            owner_group_for_element[elem] = best_group

    source_to_targets: dict[str, list[str]] = {src: [] for src in source_to_group.keys()}
    for elem, group_name in owner_group_for_element.items():
        for src, gname in source_to_group.items():
            if gname == group_name:
                source_to_targets[src].append(elem)
                break

    recipes_data: list[dict[str, Any]] = []
    for source_kind, targets in source_to_targets.items():
        if not targets:
            # keep explicit identity if nothing selected for this source
            targets = [source_kind]
        recipes_data.append({"from_kind": source_kind, "to": targets})
    return recipes_data


def _parse_symmetry(
    data: dict | None, structure: StructureModel, base_dir: Path
) -> SymmetryModel:
    data = data or {}
    mode = str(data.get("mode", "")).strip().lower()
    auto_detect = bool(data.get("auto_detect", False)) or mode == "auto"

    if auto_detect:
        symprec = float(data.get("symprec", 1e-5))
        detected = detect_symmetry_with_spglib(structure, symprec=symprec)
        symmetry = detected.symmetry
        write_wyc_path = data.get("write_wyc_path")
        if write_wyc_path:
            write_wyc_file(base_dir / str(write_wyc_path), symmetry)
        return symmetry

    wyc_path = data.get("wyc_path")
    if wyc_path:
        space_group = int(data.get("space_group", 1))
        return parse_wyc_file_to_symmetry_model(base_dir / str(wyc_path), space_group)

    return SymmetryModel(
        space_group=int(data.get("space_group", 1)),
        from_spglib=bool(data.get("from_spglib", False)),
    )


def _parse_guide_options(data: dict | None) -> GuideOptions:
    data = data or {}
    fixed_rg_find_factor = data.get("fixed_rg_find_factor")
    return GuideOptions(
        n_random_seeds=int(data.get("n_random_seeds", 2000)),
        shell_width=float(data.get("shell_width", 1.0)),
        wyc_identity_length=float(data.get("wyc_identity_length", 0.2)),
        abc_weights=_vec3(data.get("abc_weights", [2.0, 2.0, 1.0]), "guide.abc_weights"),
        chop_level=int(data.get("chop_level", 100)),
        target_cpu_time_sec=int(data.get("target_cpu_time_sec", 600)),
        strict_no_added_sites=bool(data.get("strict_no_added_sites", False)),
        skip_rg_optimization=bool(data.get("skip_rg_optimization", False)),
        skip_ewald_evaluation=bool(data.get("skip_ewald_evaluation", False)),
        fixed_rg_find_factor=None if fixed_rg_find_factor is None else int(fixed_rg_find_factor),
    )


def _parse_solve_options(data: dict | None) -> SolveOptions:
    data = data or {}
    data = _resolve_solve_strategy(data)
    swap = bool(data.get("swap", True))
    swap_mode = 1
    if isinstance(data.get("swap"), int) and int(data.get("swap")) == 2:
        swap_mode = 2
    running_index_delta = int(data.get("running_index_delta", 10000))
    if running_index_delta < 0:
        local_enumeration_stride = 1
    else:
        local_enumeration_stride = int(data.get("local_enumeration_stride", 1))
    if (
        running_index_delta > 1
        and "local_enumeration_stride" not in data
        and "running_index_delta" in data
    ):
        local_enumeration_stride = running_index_delta
    return SolveOptions(
        verbose=bool(data.get("verbose", False)),
        create_recipe_strict_mode=bool(data.get("create_recipe_strict_mode", False)),
        print_stablest_unstablest=bool(data.get("print_stablest_unstablest", False)),
        running_index_delta=running_index_delta,
        running_index_monitor=int(data.get("running_index_monitor", 10000)),
        local_enumeration_offset=int(data.get("local_enumeration_offset", 0)),
        local_enumeration_limit=int(data.get("local_enumeration_limit", 32)),
        local_enumeration_max_chunks=int(data.get("local_enumeration_max_chunks", 1)),
        local_enumeration_stride=local_enumeration_stride,
        enumeration_exhaust_all=bool(data.get("enumeration_exhaust_all", False)),
        enumeration_save_memory=bool(data.get("enumeration_save_memory", True)),
        mpi_adaptive_stride_sync=bool(data.get("mpi_adaptive_stride_sync", False)),
        mpi_dynamic_chunking=bool(data.get("mpi_dynamic_chunking", False)),
        mpi_chunk_min=int(data.get("mpi_chunk_min", 512)),
        mpi_chunk_max=int(data.get("mpi_chunk_max", 20000)),
        mpi_scheduler_heartbeat=int(data.get("mpi_scheduler_heartbeat", 16)),
        adaptive_stride_override_9=int(data.get("adaptive_stride_override_9", 0)),
        adaptive_stride_override_19=int(data.get("adaptive_stride_override_19", 0)),
        adaptive_stride_scale_secondary=bool(
            data.get("adaptive_stride_scale_secondary", True)
        ),
        swap=swap,
        max_swap=int(data.get("max_swap", 2)),
        restart_recipe_filename=str(data.get("restart_recipe_filename", "")),
        swap_loop_enabled=bool(data.get("swap_loop_enabled", swap)),
        swap_loop_mode=int(data.get("swap_loop_mode", swap_mode)),
        swap_loop_seed_source=int(data.get("swap_loop_seed_source", 1)),
        swap_loop_starting_sites=_parse_sites(
            data.get("swap_loop_starting_sites", [])
        ),
        progress_include_best_structure=bool(
            data.get("progress_include_best_structure", False)
        ),
    )


def _resolve_solve_strategy(data: dict) -> dict:
    """Resolve user-friendly `solve.strategy` into legacy solve option fields.

    Backward compatibility:
    - If `solve.strategy` is absent, legacy fields are used as-is.
    - If `solve.strategy` is present, strategy-derived fields are injected first,
      then `solve.advanced` may override specific low-level fields.
    """
    strategy = data.get("strategy")
    if strategy is None:
        return dict(data)
    if not isinstance(strategy, dict):
        raise ValueError("`solve.strategy` must be a mapping")

    resolved = dict(data)

    mode = str(strategy.get("mode", "adaptive")).strip().lower()
    effort = str(strategy.get("effort", "medium")).strip().lower()
    execution_mode_raw = strategy.get("execution_mode", None)
    if execution_mode_raw is None:
        # Backward compatibility alias.
        execution_mode_raw = strategy.get("profile", "quick")
    execution_mode = str(execution_mode_raw).strip().lower()

    if mode not in {"adaptive", "bounded_exhaustive", "exhaustive"}:
        raise ValueError(
            "`solve.strategy.mode` must be one of: adaptive, bounded_exhaustive, exhaustive"
        )
    if effort not in {"low", "medium", "high", "extreme"}:
        raise ValueError(
            "`solve.strategy.effort` must be one of: low, medium, high, extreme"
        )
    if execution_mode not in {"quick", "scalable", "fast", "throughput"}:
        raise ValueError(
            "`solve.strategy.execution_mode` must be one of: quick, scalable"
        )
    # Normalize legacy aliases to the new naming.
    if execution_mode == "fast":
        execution_mode = "quick"
    elif execution_mode == "throughput":
        execution_mode = "scalable"

    fast_presets: dict[str, tuple[int, int]] = {
        "low": (5000, 100000),
        "medium": (10000, 1000000),
        "high": (20000, 5000000),
        "extreme": (50000, 10000000),
    }
    throughput_presets: dict[str, tuple[int, int]] = {
        "low": (50000, 500000),
        "medium": (100000, 2000000),
        "high": (250000, 5000000),
        "extreme": (500000, 10000000),
    }
    effort_presets = (
        throughput_presets if execution_mode == "scalable" else fast_presets
    )
    local_limit, local_chunks = effort_presets[effort]

    resolved["local_enumeration_limit"] = local_limit
    resolved["local_enumeration_max_chunks"] = local_chunks
    resolved["enumeration_save_memory"] = True

    if mode == "adaptive":
        budget = int(strategy.get("time_budget_sec", 600))
        if budget <= 0:
            raise ValueError("`solve.strategy.time_budget_sec` must be > 0")
        resolved["running_index_delta"] = -budget
        resolved["enumeration_exhaust_all"] = False
        cost_model = str(
            strategy.get("adaptive_stride_cost_model", "")
        ).strip().lower()
        if cost_model:
            if cost_model in {
                "measured",
                "measured_window",
                "full_window",
                "observed",
            }:
                resolved["adaptive_stride_scale_secondary"] = False
            elif cost_model in {
                "legacy",
                "legacy_secondary_scaled",
                "secondary_scaled",
            }:
                resolved["adaptive_stride_scale_secondary"] = True
            else:
                raise ValueError(
                    "`solve.strategy.adaptive_stride_cost_model` must be "
                    "measured_window or legacy_secondary_scaled"
                )
        if "adaptive_stride_scale_secondary" in strategy:
            resolved["adaptive_stride_scale_secondary"] = bool(
                strategy.get("adaptive_stride_scale_secondary")
            )
        if execution_mode == "scalable":
            # Prefer lower synchronization overhead in MPI adaptive runs by
            # checking adaptive monitoring less frequently and enabling native
            # in-loop MPI stride synchronization.
            resolved["running_index_monitor"] = int(
                strategy.get("running_index_monitor", 50000)
            )
            resolved["mpi_adaptive_stride_sync"] = True
            # Keep legacy parity by default: the original C++ solver assigns a
            # fixed primary-index slice to each MPI rank and computes adaptive
            # RunningIndexDelta from that per-rank slice. Dynamic chunking is a
            # newer load-balancing mode and must be opt-in because it changes
            # the effective adaptive stride and sampled candidate stream.
            resolved["mpi_dynamic_chunking"] = bool(
                strategy.get("mpi_dynamic_chunking", False)
            )
    elif mode == "bounded_exhaustive":
        resolved["running_index_delta"] = 1
        resolved["local_enumeration_stride"] = 1
        resolved["enumeration_exhaust_all"] = False
    else:  # exhaustive
        resolved["running_index_delta"] = 1
        resolved["local_enumeration_stride"] = 1
        resolved["enumeration_exhaust_all"] = True

    if execution_mode == "scalable":
        resolved.setdefault("mpi_chunk_min", int(strategy.get("mpi_chunk_min", 512)))
        resolved.setdefault("mpi_chunk_max", int(strategy.get("mpi_chunk_max", 20000)))
        resolved.setdefault(
            "mpi_scheduler_heartbeat",
            int(strategy.get("mpi_scheduler_heartbeat", 16)),
        )

    swap = strategy.get("swap")
    if swap is not None:
        if not isinstance(swap, dict):
            raise ValueError("`solve.strategy.swap` must be a mapping")
        if "enabled" in swap:
            resolved["swap"] = bool(swap.get("enabled"))
            resolved["swap_loop_enabled"] = bool(swap.get("enabled"))
        if "max_steps" in swap:
            resolved["max_swap"] = int(swap.get("max_steps"))

    advanced = data.get("advanced")
    if advanced is not None:
        if not isinstance(advanced, dict):
            raise ValueError("`solve.advanced` must be a mapping")
        resolved.update(advanced)

    return resolved


def _parse_runtime(data: dict | None) -> ParallelRuntimeOptions:
    data = data or {}
    return ParallelRuntimeOptions(
        use_mpi=bool(data.get("use_mpi", False)),
        world_size=int(data.get("world_size", 1)),
        rank=int(data.get("rank", 0)),
    )


def _parse_logging(data: dict | None) -> LoggingOptions:
    data = data or {}
    return LoggingOptions(
        console=bool(data.get("console", True)),
        file=bool(data.get("file", True)),
        progress_jsonl=bool(data.get("progress_jsonl", True)),
        per_rank_logs=bool(data.get("per_rank_logs", True)),
        interval_sec=float(data.get("interval_sec", 10.0)),
        write_best_so_far=bool(data.get("write_best_so_far", True)),
    )


def load_run_input(path: str | Path) -> RunInput:
    path = Path(path)
    payload = yaml.safe_load(path.read_text())
    payload = _require_mapping(payload, "root")

    structure_data = _require_mapping(payload.get("structure"), "structure")
    composition_data = _require_mapping(payload.get("composition"), "composition")
    charges_data = _require_mapping(payload.get("charges"), "charges")
    recipes_data = payload.get("recipes")
    if not isinstance(recipes_data, list):
        raise ValueError("`recipes` must be a list")

    structure = _parse_structure(structure_data, path.parent)
    normalize_auto_target = isinstance(composition_data.get("fractions"), dict)
    n_target_sites, explicit_supercell = _parse_structure_supercell(
        structure_data,
        structure,
        normalize_to_resolved_target=normalize_auto_target,
    )
    site_groups = payload.get("site_groups")
    validate_site_groups_contract(
        structure,
        site_groups,
        payload.get("site_grouping"),
        n_target_sites=n_target_sites,
    )
    composition_by_site = payload.get("composition_by_site")
    if composition_by_site is not None:
        if not isinstance(composition_by_site, dict):
            raise ValueError("`composition_by_site` must be a mapping")
        if site_groups is None or not isinstance(site_groups, dict):
            raise ValueError(
                "`composition_by_site` requires `site_groups` mapping with source kinds"
            )

        aggregated, by_site_counts = _aggregate_sitewise_composition(composition_by_site)
        composition_data = aggregated
        source_to_group = _source_to_group_map(site_groups)
        recipes_data = _recipes_from_sitewise(by_site_counts, source_to_group)

    guide = GuideInput(
        structure=structure,
        composition=_parse_composition(
            composition_data,
            structure_data,
            n_target_sites=n_target_sites,
        ),
        charges=_parse_charges(charges_data, path.parent),
        recipes=_parse_recipes(recipes_data),
        supercell_expansion=explicit_supercell,
        symmetry=_parse_symmetry(payload.get("symmetry"), structure, path.parent),
        options=_parse_guide_options(payload.get("guide")),
    )
    return RunInput(
        guide=guide,
        solve=_parse_solve_options(payload.get("solve")),
        runtime=_parse_runtime(payload.get("runtime")),
        logging=_parse_logging(payload.get("logging")),
    )


# ===== Validation Functions for Wizard =====

def validate_composition(
    composition: dict[str, int], target_atoms: int
) -> tuple[bool, list[str]]:
    """Validate composition against target atom count.

    Args:
        composition: Dict of {element: count}
        target_atoms: Target total atom count

    Returns:
        (is_valid, error_messages)
    """
    errors = []

    if not composition:
        errors.append("Composition is empty")
        return False, errors

    total = sum(composition.values())
    if total != target_atoms:
        errors.append(f"Sum ({total}) ≠ target ({target_atoms})")

    if not all(count > 0 for count in composition.values()):
        errors.append("All elements must have count > 0")

    return len(errors) == 0, errors


def validate_charges(
    composition: dict[str, int], charges: dict[str, float]
) -> tuple[bool, list[str]]:
    """Validate charges for neutrality and bounds.

    Args:
        composition: Dict of {element: count}
        charges: Dict of {element: oxidation_state}

    Returns:
        (is_valid, warning_messages)
    """
    warnings = []

    if not charges:
        warnings.append("No charges specified")
        return True, warnings

    # Check all elements have charges
    for element in composition:
        if element not in charges:
            warnings.append(f"No charge specified for {element}")

    # Calculate net charge
    net_charge = sum(composition.get(elem, 0) * charge for elem, charge in charges.items())

    if abs(net_charge) > 0.1:
        warnings.append(f"System has net charge {net_charge:.2f} (not neutral)")

    return True, warnings


def validate_recipes(
    recipes: dict[str, list[str]], composition: dict[str, int]
) -> tuple[bool, list[str]]:
    """Validate substitution recipes.

    Args:
        recipes: Dict of {from_element: [to_elements]}
        composition: Dict of {element: count}

    Returns:
        (is_valid, error_messages)
    """
    errors = []

    if not recipes:
        errors.append("No recipes specified")
        return False, errors

    # Check all from-elements exist in composition
    for from_elem in recipes.keys():
        if from_elem not in composition:
            errors.append(f"Recipe source '{from_elem}' not in composition")

    # Check for empty target lists
    for from_elem, to_elems in recipes.items():
        if not to_elems:
            errors.append(f"Recipe for '{from_elem}' has no targets")

    return len(errors) == 0, errors


def calculate_net_charge(
    composition: dict[str, int], charges: dict[str, float]
) -> float:
    """Calculate net charge of a composition.

    Args:
        composition: Dict of {element: count}
        charges: Dict of {element: oxidation_state}

    Returns:
        Net charge value
    """
    return sum(composition.get(elem, 0) * charge for elem, charge in charges.items())


def suggest_charge_adjustments(
    composition: dict[str, int], charges: dict[str, float]
) -> list[tuple[str, float, str]]:
    """Suggest charge adjustments for neutrality.

    Priority order: O > N > S > F > Cl > ...

    Args:
        composition: Dict of {element: count}
        charges: Dict of {element: oxidation_state}

    Returns:
        List of (element, new_charge, description) tuples
    """
    suggestions = []
    net_charge = calculate_net_charge(composition, charges)

    if abs(net_charge) < 0.01:
        return suggestions

    # Priority order for adjustment
    priority = ["O", "N", "S", "F", "Cl", "Br", "I", "Se", "Te", "P"]

    for element in priority:
        if element not in composition or element not in charges:
            continue

        count = composition[element]
        current_charge = charges[element]

        # Calculate adjustment per atom
        adjustment_per_atom = -net_charge / count
        new_charge = current_charge + adjustment_per_atom

        # Check if adjustment is physically reasonable (within [-10, 10])
        if -10 <= new_charge <= 10:
            description = f"{current_charge:+.2f} → {new_charge:+.2f} per atom"
            suggestions.append((element, new_charge, description))

    return suggestions
