from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
from typing import Any, Literal

import yaml

from .add_sites_text import AddSitesMonteCarloSpec, parse_add_sites_monte_carlo_spec


ExportFormat = Literal["json", "yaml"]


def add_sites_spec_to_dict(spec: AddSitesMonteCarloSpec) -> dict[str, Any]:
    payload = asdict(spec)
    payload["add_meshes"] = list(spec.add_meshes)
    return payload


def render_add_sites_spec(
    spec: AddSitesMonteCarloSpec,
    *,
    fmt: ExportFormat = "yaml",
) -> str:
    payload = add_sites_spec_to_dict(spec)
    if fmt == "json":
        return json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if fmt == "yaml":
        return yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
    raise ValueError(f"Unsupported add-sites export format: {fmt}")


def export_add_sites_spec(
    solver_text: str | Path,
    *,
    out: str | Path | None = None,
    fmt: ExportFormat = "yaml",
) -> str:
    spec = parse_add_sites_monte_carlo_spec(solver_text)
    text = render_add_sites_spec(spec, fmt=fmt)
    if out is not None:
        Path(out).write_text(text)
    return text
