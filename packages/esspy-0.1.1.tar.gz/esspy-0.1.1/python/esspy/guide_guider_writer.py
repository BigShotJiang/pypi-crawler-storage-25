from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

import yaml

from .config import load_run_input
from .default_charges import suggest_default_charge
from .models import GuideInput
from .output_config import parse_output_config


@dataclass
class GuiderTextWriteOptions:
    poscar_filename: str = "POSCAR.vasp"
    output_prefix: str = "esspy"
    output_filename: str | None = None
    which_ess: str = "EwaldSolidSolution.x"
    which_ewald2vasp: str = "none"
    which_vasp: str = "none"
    qsub_command: str = "squeue"
    chain_command: str = "#SBATCH -d afterany"
    mpi_command: str = "mpirun"
    vasp_transfer: int = 0
    vasp_npar: int = 1
    vasp_output_directory: str = "vasp_out"
    vasp_pseudo_dir: str = "../potcar"
    vasp_mlff: int = 0
    vasp_gga: str = "PE"


def write_guider_text(
    guide: GuideInput,
    options: GuiderTextWriteOptions | None = None,
) -> str:
    options = options or GuiderTextWriteOptions()
    active_recipes = _active_legacy_recipes(guide)
    output_filename = options.output_filename or f"{options.output_prefix}.guider.log"
    lines: list[str] = []
    lines.append(_target_line(guide))
    lines.append(
        "NumberFixedAt(IfNotUse,\"*\";NTargetShouldBeInteger)\t"
        f"{guide.composition.number_fixed_at}"
    )
    lines.append(f"NTargetSites\t{guide.composition.n_target_sites}")
    lines.append(f"NRandomSeeds\t{guide.options.n_random_seeds}")
    lines.append(f"ShellWidth\t{_fmt_float(guide.options.shell_width, 1)}")
    lines.append(f"WYCIdentityLength\t{_fmt_float(guide.options.wyc_identity_length, 1)}")
    lines.append(
        "ABCWeights\t"
        + " ".join(_fmt_float(value, 1) for value in guide.options.abc_weights)
    )
    lines.append(f"ChopLevel\t{guide.options.chop_level}")
    lines.append(f"TargetCPUTimeInSec\t{guide.options.target_cpu_time_sec}")
    lines.append(f"OutputFilename\t{output_filename}")
    lines.append(f"StrictNoAddedSites\t{_fmt_bool(guide.options.strict_no_added_sites)}")
    lines.append(f"SkipRGOptimization\t{_fmt_bool(guide.options.skip_rg_optimization)}")
    lines.append(f"SkipEwaldEvaluation\t{_fmt_bool(guide.options.skip_ewald_evaluation)}")
    if guide.options.fixed_rg_find_factor is not None:
        lines.append(f"FixedRGFindFactor\t{guide.options.fixed_rg_find_factor}")
    lines.append("====IonList====")
    charge_map = {charge.kind: charge.oxidation for charge in guide.charges.values}
    source_kinds = [recipe.from_kind for recipe in guide.recipes]
    ion_kinds = list(charge_map.keys())
    for source_kind in source_kinds:
        if source_kind not in charge_map:
            ion_kinds.append(source_kind)
            charge_map[source_kind] = suggest_default_charge(source_kind)
    for kind in ion_kinds:
        lines.append(f"{kind} {_fmt_float(charge_map[kind], 10)}")
    lines.append("STOP")
    lines.append("====InputFilename_Prefix_SapceGroup_Recipe_List====")
    lines.append(
        f"{options.poscar_filename} {options.output_prefix} {guide.symmetry.space_group} "
        f"NRecipe= {len(active_recipes)} "
        + " ".join(_recipe_text(recipe.from_kind, recipe.to) for recipe in active_recipes)
    )
    lines.append("STOP")
    lines.append(
        "====AddedKind=NAdded=Oxidation=[[[NeighboringKind="
        "dNeighboringOxidation(ForNeighboringDistanceMax>10000,Only)="
        "NeighboringDistanceMin=NeighboringDistanceMax]]]===="
    )
    lines.append("STOP")
    lines.extend(_runtime_lines(options, [charge.kind for charge in guide.charges.values]))
    return "\n".join(lines) + "\n"


def write_guider_text_from_yaml(path: str | Path) -> str:
    path = Path(path)
    run_input = load_run_input(path)
    payload = yaml.safe_load(path.read_text()) or {}
    if not isinstance(payload, Mapping):
        raise ValueError("root YAML must be a mapping")
    options = _options_from_yaml_payload(payload)
    return write_guider_text(run_input.guide, options)


def _options_from_yaml_payload(payload: Mapping) -> GuiderTextWriteOptions:
    structure = payload.get("structure", {})
    output = payload.get("output", {})
    if not isinstance(structure, Mapping):
        structure = {}
    if not isinstance(output, Mapping):
        output = {}
    name = str(payload.get("name") or structure.get("title") or "esspy")
    output_config = parse_output_config(output)
    prefix = output_config.resolved_prefix(name)
    poscar = str(structure.get("poscar") or "POSCAR.vasp")
    return GuiderTextWriteOptions(
        poscar_filename=poscar,
        output_prefix=prefix,
        output_filename=output_config.guider_log or f"{prefix}.guider.log",
        which_ess=output_config.which_ess,
        which_ewald2vasp=output_config.which_ewald2vasp,
        which_vasp=output_config.which_vasp,
        vasp_output_directory=output_config.vasp_output_directory,
        vasp_pseudo_dir=output_config.vasp_pseudo_dir,
    )


def _target_line(guide: GuideInput) -> str:
    total = guide.composition.n_target_sites
    parts = []
    for entry in guide.composition.entries:
        parts.append(entry.kind)
        parts.append(_fmt_float(entry.count / total, 10))
    return "Target\t" + " ".join(parts)


def _recipe_text(from_kind: str, to: list[str]) -> str:
    return f"( {from_kind} -> {' '.join(to)} )"


def _active_legacy_recipes(guide: GuideInput):
    """Drop no-op identity recipes for legacy Guider compatibility.

    Legacy `EwaldSolidSolutionGuider.x` can mis-handle pure identity rules
    like `( O -> O )`, producing malformed recipe entries. Keep only recipes
    that can actually change species.
    """
    filtered = []
    for recipe in guide.recipes:
        normalized_to = [item.strip() for item in recipe.to if item.strip()]
        if len(normalized_to) == 1 and normalized_to[0] == recipe.from_kind:
            continue
        filtered.append(recipe)
    return filtered


def _runtime_lines(options: GuiderTextWriteOptions, kinds: list[str]) -> list[str]:
    identity_pairs = " ".join(f"{kind} {kind}" for kind in kinds)
    return [
        "SHJobnameCommand ##",
        f"WhichESS {options.which_ess}",
        f"WhichEwald2VASP++ {options.which_ewald2vasp}",
        f"WhichVASP {options.which_vasp}",
        f"QSubCommand(ForChain) {options.qsub_command}",
        f"ChainCommand(WorksForAFTERANY_Only) {options.chain_command}",
        f"MPIcommand {options.mpi_command}",
        f"VASPTransfer(Yes1No0)\t{options.vasp_transfer}",
        f"VASPNPAR\t{options.vasp_npar}",
        f"VASPOutputDirectory {options.vasp_output_directory}",
        f"VASPPseudoDir {options.vasp_pseudo_dir}",
        f"VASPMLFF(Yes1No0)\t{options.vasp_mlff}",
        f"VASPGGA {options.vasp_gga}",
        "====VASPAtomNameChangeList[Title,n*(nameA_B)]====",
        f"identity {identity_pairs}".rstrip(),
        "STOP",
        "=====SH_Header_forESS[ForJobTitle,Use\"(*Jobname*)\"]=====",
        "#!/bin/sh",
        f"# ESS job for {options.output_prefix}",
        "STOP",
        "=====SH_Header_forVASP(geometry-optimization)[ForJobTitle,Use\"(*Jobname*)\"]=====",
        "#!/bin/sh",
        "# VASP header placeholder",
        "STOP",
    ]


def _fmt_float(value: float, decimals: int) -> str:
    return f"{float(value):.{decimals}f}"


def _fmt_bool(value: bool) -> str:
    return "true" if value else "false"
