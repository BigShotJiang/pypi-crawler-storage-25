from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Iterator, Mapping, Sequence


@dataclass(frozen=True)
class AllocationSiteGroup:
    name: str
    source_kind: str
    count: int
    allowed: tuple[str, ...]


@dataclass(frozen=True)
class AllocationFeasibilityResult:
    status: str
    target_sites: int
    scale_factor: int
    group_capacities: dict[str, int]
    n_solutions_observed: int = 0
    truncated: bool = False
    solutions: tuple[dict[str, dict[str, int]], ...] = field(default_factory=tuple)
    errors: tuple[str, ...] = field(default_factory=tuple)

    @property
    def has_solution(self) -> bool:
        return self.status in {"unique", "multiple"}

    @property
    def requires_allocation(self) -> bool:
        return self.status == "multiple"

    @property
    def unique_solution(self) -> dict[str, dict[str, int]] | None:
        if self.status != "unique" or not self.solutions:
            return None
        return self.solutions[0]

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "target_sites": self.target_sites,
            "scale_factor": self.scale_factor,
            "group_capacities": dict(self.group_capacities),
            "n_solutions_observed": self.n_solutions_observed,
            "truncated": self.truncated,
            "solutions": list(self.solutions),
            "errors": list(self.errors),
        }


def decide_allocation_pipeline(
    *,
    composition_by_site: Mapping[str, Any] | None,
    feasibility: AllocationFeasibilityResult | None,
) -> str:
    if composition_by_site is not None:
        return "arrangement_only"
    if feasibility is None:
        raise ValueError("feasibility is required when composition_by_site is absent")
    if feasibility.status == "none":
        return "invalid"
    if feasibility.status == "unique":
        return "arrangement_only"
    if feasibility.status == "multiple":
        return "allocation_plus_arrangement"
    raise ValueError(f"Unknown allocation feasibility status: {feasibility.status!r}")


def analyze_site_allocation_from_payload(
    payload: Mapping[str, Any],
    *,
    max_solutions: int | None = 2,
) -> AllocationFeasibilityResult:
    structure = _as_mapping(payload.get("structure"), "structure")
    n_target_sites = _infer_target_sites(payload)
    composition = _composition_from_payload(payload, n_target_sites=n_target_sites)
    site_groups = _as_mapping(payload.get("site_groups"), "site_groups")
    return analyze_site_allocation(
        composition,
        site_groups,
        n_target_sites=n_target_sites,
        max_solutions=max_solutions,
    )


def analyze_site_allocation(
    composition: Mapping[str, Any],
    site_groups: Mapping[str, Any] | Sequence[AllocationSiteGroup],
    *,
    n_target_sites: int | None = None,
    max_solutions: int | None = 2,
) -> AllocationFeasibilityResult:
    try:
        counts = _normalize_composition_counts(composition)
        groups = _normalize_site_groups(site_groups)
        groups, target_sites, scale_factor = _scale_site_groups(
            groups,
            composition_total=sum(counts.values()),
            n_target_sites=n_target_sites,
        )
        _validate_problem(counts, groups, target_sites=target_sites)
    except ValueError as exc:
        return AllocationFeasibilityResult(
            status="none",
            target_sites=int(n_target_sites or 0),
            scale_factor=1,
            group_capacities={},
            errors=(str(exc),),
        )

    group_capacities = {group.name: group.count for group in groups}
    solutions, observed, truncated = _enumerate_feasible_allocations(
        counts,
        groups,
        max_solutions=max_solutions,
    )

    if observed <= 0:
        status = "none"
        errors = ("No feasible site allocation satisfies composition and site capacities.",)
    elif observed == 1 and not truncated:
        status = "unique"
        errors = ()
    else:
        status = "multiple"
        errors = ()

    return AllocationFeasibilityResult(
        status=status,
        target_sites=target_sites,
        scale_factor=scale_factor,
        group_capacities=group_capacities,
        n_solutions_observed=observed,
        truncated=truncated,
        solutions=tuple(solutions),
        errors=errors,
    )


def _composition_from_payload(
    payload: Mapping[str, Any],
    *,
    n_target_sites: int | None,
) -> dict[str, int]:
    composition = _as_mapping(payload.get("composition"), "composition")
    if "counts" in composition and "fractions" in composition:
        raise ValueError("`composition` must not define both `counts` and `fractions`")
    if "counts" in composition:
        return _normalize_composition_counts(
            _as_mapping(composition["counts"], "composition.counts")
        )
    if "fractions" in composition:
        if n_target_sites is None:
            raise ValueError(
                "`structure.n_target_sites` is required when `composition.fractions` is used"
            )
        structure = _as_mapping(payload.get("structure"), "structure")
        return _counts_from_fractions(
            _as_mapping(composition["fractions"], "composition.fractions"),
            n_target_sites=n_target_sites,
            number_fixed_at=str(structure.get("number_fixed_at", "O")),
        )
    return _normalize_composition_counts(composition)


def _infer_target_sites(payload: Mapping[str, Any]) -> int | None:
    structure = _as_mapping(payload.get("structure"), "structure")
    if structure.get("n_target_sites") is not None:
        return _to_int_count(
            structure.get("n_target_sites"),
            label="structure.n_target_sites",
        )
    dim = None
    for key in ("dim", "supercell", "supercell_expansion"):
        if structure.get(key) is not None:
            dim = structure.get(key)
            break
    if dim is None:
        return None
    base_sites = _base_site_count_from_payload(payload)
    if base_sites is None:
        return None
    return int(base_sites) * _dim_determinant_scale(dim)


def _base_site_count_from_payload(payload: Mapping[str, Any]) -> int | None:
    site_groups = payload.get("site_groups")
    if isinstance(site_groups, Mapping) and site_groups:
        total = 0
        for raw_name, raw_info in site_groups.items():
            info = _as_mapping(raw_info, f"site_groups.{raw_name}")
            if info.get("count") is not None:
                total += _to_int_count(
                    info.get("count"),
                    label=f"site_groups.{raw_name}.count",
                )
            elif isinstance(info.get("site_indices"), list):
                total += len(info["site_indices"])
            else:
                return None
        if total > 0:
            return total

    structure = _as_mapping(payload.get("structure"), "structure")
    if isinstance(structure.get("sites"), list):
        return len(structure["sites"])
    return None


def _dim_determinant_scale(dim: Any) -> int:
    if isinstance(dim, (list, tuple)) and len(dim) == 3 and not any(
        isinstance(item, (list, tuple)) for item in dim
    ):
        values = [
            _to_int_count(item, label=f"structure.dim[{idx}]")
            for idx, item in enumerate(dim)
        ]
        if any(value <= 0 for value in values):
            raise ValueError("structure.dim entries must be positive")
        return values[0] * values[1] * values[2]

    if isinstance(dim, (list, tuple)) and len(dim) == 9:
        rows = [list(dim[0:3]), list(dim[3:6]), list(dim[6:9])]
    elif (
        isinstance(dim, (list, tuple))
        and len(dim) == 3
        and all(isinstance(row, (list, tuple)) and len(row) == 3 for row in dim)
    ):
        rows = [list(row) for row in dim]
    else:
        raise ValueError("structure.dim must contain 3 or 9 integers")

    matrix = [
        [
            _to_int_count(raw, label=f"structure.dim[{row_index}][{col_index}]")
            for col_index, raw in enumerate(row)
        ]
        for row_index, row in enumerate(rows)
    ]
    det = (
        matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])
    )
    if det <= 0:
        raise ValueError("structure.dim matrix determinant must be positive")
    return int(det)


def _normalize_composition_counts(composition: Mapping[str, Any]) -> dict[str, int]:
    if not composition:
        raise ValueError("composition must not be empty")
    out: dict[str, int] = {}
    for element, raw_count in composition.items():
        if str(element) == "fractions":
            continue
        count = _to_int_count(raw_count, label=f"composition.{element}")
        if count < 0:
            raise ValueError(f"composition.{element} must be >= 0")
        if count > 0:
            out[str(element)] = count
    if not out:
        raise ValueError("composition has no positive counts")
    return out


def _normalize_site_groups(
    site_groups: Mapping[str, Any] | Sequence[AllocationSiteGroup],
) -> list[AllocationSiteGroup]:
    if isinstance(site_groups, Sequence) and not isinstance(site_groups, (str, bytes, dict)):
        groups = list(site_groups)
        if not all(isinstance(group, AllocationSiteGroup) for group in groups):
            raise ValueError("site group sequence must contain AllocationSiteGroup entries")
        if not groups:
            raise ValueError("site_groups must not be empty")
        return groups

    raw = _as_mapping(site_groups, "site_groups")
    groups: list[AllocationSiteGroup] = []
    for raw_name, raw_info in raw.items():
        info = _as_mapping(raw_info, f"site_groups.{raw_name}")
        source_kind = str(info.get("source_kind", "")).strip()
        if not source_kind:
            raise ValueError(f"site_groups.{raw_name}.source_kind is required")
        if "count" in info:
            count = _to_int_count(info["count"], label=f"site_groups.{raw_name}.count")
        elif isinstance(info.get("site_indices"), list):
            count = len(info["site_indices"])
        else:
            raise ValueError(
                f"site_groups.{raw_name}.count or site_indices is required"
            )
        if count < 0:
            raise ValueError(f"site_groups.{raw_name}.count must be >= 0")
        allowed_raw = info.get("allowed", [source_kind])
        if not isinstance(allowed_raw, list) or not allowed_raw:
            raise ValueError(f"site_groups.{raw_name}.allowed must be a non-empty list")
        allowed = tuple(str(item).strip() for item in allowed_raw if str(item).strip())
        if not allowed:
            raise ValueError(f"site_groups.{raw_name}.allowed must be a non-empty list")
        groups.append(
            AllocationSiteGroup(
                name=str(raw_name),
                source_kind=source_kind,
                count=count,
                allowed=allowed,
            )
        )
    if not groups:
        raise ValueError("site_groups must not be empty")
    return groups


def _scale_site_groups(
    groups: list[AllocationSiteGroup],
    *,
    composition_total: int,
    n_target_sites: int | None,
) -> tuple[list[AllocationSiteGroup], int, int]:
    base_total = sum(group.count for group in groups)
    if base_total <= 0:
        raise ValueError("site group total capacity must be > 0")
    target_sites = int(n_target_sites) if n_target_sites is not None else int(composition_total)
    if target_sites != int(composition_total):
        raise ValueError(
            f"composition total ({composition_total}) does not match target sites ({target_sites})"
        )
    if target_sites % base_total != 0:
        raise ValueError(
            f"target sites ({target_sites}) is not an integer multiple of site group total ({base_total})"
        )
    scale = target_sites // base_total
    if scale <= 0:
        raise ValueError("site group scale factor must be > 0")
    if scale == 1:
        return groups, target_sites, scale
    return [
        AllocationSiteGroup(
            name=group.name,
            source_kind=group.source_kind,
            count=group.count * scale,
            allowed=group.allowed,
        )
        for group in groups
    ], target_sites, scale


def _validate_problem(
    composition: dict[str, int],
    groups: list[AllocationSiteGroup],
    *,
    target_sites: int,
) -> None:
    if sum(composition.values()) != target_sites:
        raise ValueError(
            f"composition total ({sum(composition.values())}) does not match target sites ({target_sites})"
        )
    if sum(group.count for group in groups) != target_sites:
        raise ValueError(
            f"site group capacity total ({sum(group.count for group in groups)}) "
            f"does not match target sites ({target_sites})"
        )
    for element, demand in composition.items():
        eligible = [group for group in groups if element in group.allowed]
        if not eligible:
            raise ValueError(f"Element `{element}` has no eligible site groups")
        capacity = sum(group.count for group in eligible)
        if capacity < demand:
            raise ValueError(
                f"Insufficient eligible capacity for `{element}`: "
                f"demand={demand}, capacity={capacity}"
            )
    for group in groups:
        if group.count > 0 and not any(
            element in group.allowed and count > 0
            for element, count in composition.items()
        ):
            raise ValueError(
                f"Site group `{group.name}` has no eligible composition elements"
            )


def _enumerate_feasible_allocations(
    composition: dict[str, int],
    groups: list[AllocationSiteGroup],
    *,
    max_solutions: int | None,
) -> tuple[list[dict[str, dict[str, int]]], int, bool]:
    group_names = [group.name for group in groups]
    cap_remaining = {group.name: group.count for group in groups}
    allowed_by_element = {
        element: [group.name for group in groups if element in group.allowed]
        for element in composition
    }
    group_by_name = {group.name: group for group in groups}
    elements = [element for element, count in composition.items() if count > 0]
    elements.sort(
        key=lambda element: (
            len(allowed_by_element[element]),
            -composition[element],
            element,
        )
    )
    assigned: dict[str, dict[str, int]] = {name: {} for name in group_names}
    store_limit = None if max_solutions is None else max(0, int(max_solutions))
    search_limit = None if max_solutions is None else max(2, int(max_solutions))
    solutions: list[dict[str, dict[str, int]]] = []
    observed = 0
    stopped_by_limit = False

    def can_remaining_elements_fill_groups(next_index: int) -> bool:
        remaining_elements = elements[next_index:]
        for group_name, capacity in cap_remaining.items():
            if capacity <= 0:
                continue
            if not any(
                element in group_by_name[group_name].allowed
                and composition[element] > 0
                for element in remaining_elements
            ):
                return False
        for element in remaining_elements:
            demand_remaining = composition[element] - sum(
                row.get(element, 0) for row in assigned.values()
            )
            if demand_remaining <= 0:
                continue
            capacity = sum(cap_remaining[group_name] for group_name in allowed_by_element[element])
            if capacity < demand_remaining:
                return False
        return True

    def record_solution() -> bool:
        nonlocal observed, stopped_by_limit
        observed += 1
        if store_limit is None or len(solutions) < store_limit:
            solutions.append(_clone_solution(assigned, group_names, composition))
        if search_limit is not None and observed >= search_limit:
            stopped_by_limit = True
            return False
        return True

    def dfs(element_index: int) -> bool:
        if stopped_by_limit:
            return False
        if element_index >= len(elements):
            if all(capacity == 0 for capacity in cap_remaining.values()):
                return record_solution()
            return True

        if not can_remaining_elements_fill_groups(element_index):
            return True

        element = elements[element_index]
        demand_already = sum(row.get(element, 0) for row in assigned.values())
        demand = composition[element] - demand_already
        eligible = allowed_by_element[element]
        bounds = [cap_remaining[group_name] for group_name in eligible]
        for parts in _bounded_partitions(demand, bounds):
            touched: list[tuple[str, int]] = []
            for group_name, take in zip(eligible, parts):
                if take <= 0:
                    continue
                assigned[group_name][element] = assigned[group_name].get(element, 0) + take
                cap_remaining[group_name] -= take
                touched.append((group_name, take))
            should_continue = dfs(element_index + 1)
            for group_name, take in touched:
                cap_remaining[group_name] += take
                new_count = assigned[group_name][element] - take
                if new_count <= 0:
                    assigned[group_name].pop(element, None)
                else:
                    assigned[group_name][element] = new_count
            if not should_continue:
                return False
        return True

    dfs(0)
    return solutions, observed, stopped_by_limit


def _bounded_partitions(total: int, bounds: Sequence[int]) -> Iterator[list[int]]:
    current = [0] * len(bounds)

    def dfs(index: int, remaining: int) -> Iterator[list[int]]:
        if index == len(bounds) - 1:
            if 0 <= remaining <= bounds[index]:
                current[index] = remaining
                yield list(current)
            return
        upper = min(bounds[index], remaining)
        for value in range(upper + 1):
            current[index] = value
            yield from dfs(index + 1, remaining - value)

    if not bounds:
        return
    yield from dfs(0, int(total))


def _clone_solution(
    assigned: dict[str, dict[str, int]],
    group_names: list[str],
    composition: dict[str, int],
) -> dict[str, dict[str, int]]:
    element_order = list(composition)
    solution: dict[str, dict[str, int]] = {}
    for group_name in group_names:
        row = assigned[group_name]
        ordered_row = {
            element: int(row[element])
            for element in element_order
            if int(row.get(element, 0)) > 0
        }
        solution[group_name] = ordered_row
    return solution


def _counts_from_fractions(
    fractions: Mapping[str, Any],
    *,
    n_target_sites: int,
    number_fixed_at: str,
) -> dict[str, int]:
    raw = [(str(kind), float(value)) for kind, value in fractions.items()]
    if not raw:
        raise ValueError("composition.fractions must not be empty")
    if any(value < 0.0 for _, value in raw):
        raise ValueError("composition.fractions must be non-negative")
    total = sum(value for _, value in raw)
    if total <= 0.0:
        raise ValueError("composition.fractions must sum to a positive value")
    normalized = [(kind, value / total) for kind, value in raw]
    fixed_index = next(
        (index for index, (kind, _) in enumerate(normalized) if kind == number_fixed_at),
        None,
    )
    counts = [0] * len(normalized)
    remainders: list[tuple[float, int]] = []
    if fixed_index is None:
        for index, (_, fraction) in enumerate(normalized):
            scaled = fraction * n_target_sites
            counts[index] = int(math.floor(scaled))
            remainders.append((scaled - counts[index], index))
        missing = n_target_sites - sum(counts)
        for _, index in sorted(remainders, reverse=True)[:missing]:
            counts[index] += 1
    else:
        for index, (_, fraction) in enumerate(normalized):
            if index == fixed_index:
                continue
            scaled = fraction * n_target_sites
            counts[index] = int(math.floor(scaled))
            remainders.append((scaled - counts[index], index))
        target_nonfixed = int(
            round(
                sum(
                    fraction
                    for index, (_, fraction) in enumerate(normalized)
                    if index != fixed_index
                )
                * n_target_sites
            )
        )
        missing = target_nonfixed - sum(counts)
        for _, index in sorted(remainders, reverse=True)[:missing]:
            counts[index] += 1
        counts[fixed_index] = n_target_sites - sum(counts)
    return {
        kind: count
        for (kind, _), count in zip(normalized, counts)
        if int(count) > 0
    }


def _to_int_count(value: Any, *, label: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{label} must be an integer count")
    try:
        as_float = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be an integer count") from exc
    as_int = int(round(as_float))
    if abs(as_float - as_int) > 1e-8:
        raise ValueError(f"{label} must be integer-like, got {value!r}")
    return as_int


def _as_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"`{label}` must be a mapping")
    return value
