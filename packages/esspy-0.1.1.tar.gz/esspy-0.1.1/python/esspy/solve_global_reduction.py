from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, Iterable, Mapping

from .models import (
    EnergyTable,
    Lattice,
    LocalReductionSummary,
    Site,
    StructureModel,
)
from .native import load_native_module


@dataclass
class LocalReductionScalars:
    """MPI-friendly fixed-size payload extracted from
    `LocalReductionSummary`.

    Holds only the scalar / POD-friendly fields. Best/worst structure
    snapshots are intentionally excluded — those are sent separately
    by the rank that ends up holding the global extremum, after every
    rank has agreed on ownership via `combine_local_reduction_scalars`.
    """

    rank: int = 0
    world_size: int = 1
    primary_recipe_index: int = -1
    processed_chunks: int = 0
    processed_candidates: int = 0
    initial_offset: int = 0
    next_offset: int = 0
    has_more: bool = False
    exhaust_all: bool = False
    has_samples: bool = False
    local_e_min: float = 0.0
    local_e_max: float = 0.0
    local_best_candidate_index: int = 0
    local_worst_candidate_index: int = 0
    local_de_min_swap: float = 0.0
    local_swap_count: int = 0
    local_best_structure_present: bool = False
    local_worst_structure_present: bool = False
    local_energy_table: EnergyTable = field(default_factory=EnergyTable)


@dataclass
class PartialGlobalReductionSummary:
    """Reducer output for the scalar-only path.

    Mirrors `GlobalReductionSummary` but without the structure fields.
    Callers are expected to pair this with a separate structure
    broadcast step driven by `which_rank_global_e_min` /
    `which_rank_global_e_max`.
    """

    world_size: int
    contributing_ranks: int
    total_processed_candidates: int
    total_processed_chunks: int
    any_has_more: bool
    any_exhaust_all: bool
    has_samples: bool
    global_e_min: float
    global_e_max: float
    which_rank_global_e_min: int
    which_rank_global_e_max: int
    global_e_min_candidate_index: int
    global_e_max_candidate_index: int
    global_de_min_swap: float
    global_swap_count: int
    total_de_min_swap: float
    total_swap_count: int
    global_best_structure_present: bool
    global_worst_structure_present: bool
    primary_recipe_index: int
    primary_recipe_consistent: bool
    global_energy_table: EnergyTable


@dataclass
class GlobalReductionSummary:
    """Aggregate of one or more LocalReductionSummary inputs.

    Mirrors the post-MPI_Allgather/MPI_Allreduce step of the original ESS
    solver's postprocess(): inputs whose `has_samples == False` count toward
    `world_size` and the cumulative `processed_*` totals but are otherwise
    skipped, and the global extrema use the same strict `<` / `>` tie-break
    as the legacy solver (lowest-rank contributor wins on ties).

    `combine_local_reductions(...)` is homomorphic on a single input: the
    new core's single-rank `solve()` result and the reducer-output of that
    same `LocalReductionSummary` agree exactly on extrema and ownership.
    """

    world_size: int
    contributing_ranks: int
    total_processed_candidates: int
    total_processed_chunks: int
    any_has_more: bool
    any_exhaust_all: bool
    has_samples: bool
    global_e_min: float
    global_e_max: float
    which_rank_global_e_min: int
    which_rank_global_e_max: int
    global_e_min_candidate_index: int
    global_e_max_candidate_index: int
    global_de_min_swap: float
    global_swap_count: int
    total_de_min_swap: float
    total_swap_count: int
    global_best_structure: StructureModel | None
    global_worst_structure: StructureModel | None
    global_best_structure_present: bool
    global_worst_structure_present: bool
    primary_recipe_index: int
    primary_recipe_consistent: bool
    global_energy_table: EnergyTable


def _input_payload(item: LocalReductionSummary | Mapping[str, Any]) -> dict:
    if is_dataclass(item):
        return asdict(item)
    if isinstance(item, Mapping):
        return dict(item)
    raise TypeError(
        "combine_local_reductions expected LocalReductionSummary or mapping, "
        "got " + repr(type(item))
    )


def _structure_from_dict(data: Mapping[str, Any] | None) -> StructureModel | None:
    if not data:
        return None
    sites_data = data.get("sites") or []
    lattice = data.get("lattice") or {}
    return StructureModel(
        title=str(data.get("title", "")),
        lattice=Lattice(
            a=tuple(lattice.get("a", (0.0, 0.0, 0.0))),
            b=tuple(lattice.get("b", (0.0, 0.0, 0.0))),
            c=tuple(lattice.get("c", (0.0, 0.0, 0.0))),
        ),
        sites=[
            Site(
                kind=str(site["kind"]),
                x=float(site["x"]),
                y=float(site["y"]),
                z=float(site["z"]),
                oxidation=float(site.get("oxidation", 0.0)),
            )
            for site in sites_data
        ],
        fractional_coordinates=bool(data.get("fractional_coordinates", True)),
    )


def _energy_table_from_dict(data: Mapping[str, Any] | None) -> EnergyTable:
    if not data:
        return EnergyTable()
    return EnergyTable(
        count=int(data.get("count", 0)),
        sum_e=float(data.get("sum_e", 0.0)),
        sum_e2=float(data.get("sum_e2", 0.0)),
        min_e=float(data.get("min_e", 0.0)),
        max_e=float(data.get("max_e", 0.0)),
    )


def extract_local_reduction_scalars(
    summary: LocalReductionSummary | Mapping[str, Any],
) -> LocalReductionScalars:
    """Extract the MPI-friendly fixed-size payload from a
    `LocalReductionSummary`.

    The returned dataclass contains only the scalar / POD-friendly
    fields and is suitable as the buffer payload for `MPI_Allgather`.
    """
    native = load_native_module()
    payload = native.extract_local_reduction_scalars(_input_payload(summary))
    return LocalReductionScalars(
        rank=int(payload["rank"]),
        world_size=int(payload["world_size"]),
        primary_recipe_index=int(payload["primary_recipe_index"]),
        processed_chunks=int(payload["processed_chunks"]),
        processed_candidates=int(payload["processed_candidates"]),
        initial_offset=int(payload["initial_offset"]),
        next_offset=int(payload["next_offset"]),
        has_more=bool(payload["has_more"]),
        exhaust_all=bool(payload["exhaust_all"]),
        has_samples=bool(payload["has_samples"]),
        local_e_min=float(payload["local_e_min"]),
        local_e_max=float(payload["local_e_max"]),
        local_best_candidate_index=int(payload["local_best_candidate_index"]),
        local_worst_candidate_index=int(payload["local_worst_candidate_index"]),
        local_de_min_swap=float(payload["local_de_min_swap"]),
        local_swap_count=int(payload["local_swap_count"]),
        local_best_structure_present=bool(
            payload["local_best_structure_present"]
        ),
        local_worst_structure_present=bool(
            payload["local_worst_structure_present"]
        ),
        local_energy_table=_energy_table_from_dict(payload["local_energy_table"]),
    )


def combine_local_reduction_scalars(
    inputs: Iterable[LocalReductionScalars | Mapping[str, Any]],
) -> PartialGlobalReductionSummary:
    """Reducer over the scalar-only payloads.

    Callers use this after `MPI_Allgather` of `LocalReductionScalars`
    payloads to resolve global ownership without having to ship the
    structure snapshots. The structure transfer is then a separate
    step driven by `which_rank_global_e_min` / `which_rank_global_e_max`.
    """
    native = load_native_module()
    payload = native.combine_local_reduction_scalars(
        [_input_payload(i) for i in inputs]
    )
    return PartialGlobalReductionSummary(
        world_size=int(payload["world_size"]),
        contributing_ranks=int(payload["contributing_ranks"]),
        total_processed_candidates=int(payload["total_processed_candidates"]),
        total_processed_chunks=int(payload["total_processed_chunks"]),
        any_has_more=bool(payload["any_has_more"]),
        any_exhaust_all=bool(payload["any_exhaust_all"]),
        has_samples=bool(payload["has_samples"]),
        global_e_min=float(payload["global_e_min"]),
        global_e_max=float(payload["global_e_max"]),
        which_rank_global_e_min=int(payload["which_rank_global_e_min"]),
        which_rank_global_e_max=int(payload["which_rank_global_e_max"]),
        global_e_min_candidate_index=int(payload["global_e_min_candidate_index"]),
        global_e_max_candidate_index=int(payload["global_e_max_candidate_index"]),
        global_de_min_swap=float(payload["global_de_min_swap"]),
        global_swap_count=int(payload["global_swap_count"]),
        total_de_min_swap=float(payload["total_de_min_swap"]),
        total_swap_count=int(payload["total_swap_count"]),
        global_best_structure_present=bool(
            payload["global_best_structure_present"]
        ),
        global_worst_structure_present=bool(
            payload["global_worst_structure_present"]
        ),
        primary_recipe_index=int(payload["primary_recipe_index"]),
        primary_recipe_consistent=bool(payload["primary_recipe_consistent"]),
        global_energy_table=_energy_table_from_dict(payload["global_energy_table"]),
    )


def combine_local_reductions(
    inputs: Iterable[LocalReductionSummary | Mapping[str, Any]],
) -> GlobalReductionSummary:
    """Combine a list of `LocalReductionSummary` payloads into a global summary."""

    native = load_native_module()
    payload = native.combine_local_reductions([_input_payload(i) for i in inputs])
    global_best_present = bool(payload.get("global_best_structure_present", False))
    global_worst_present = bool(payload.get("global_worst_structure_present", False))
    return GlobalReductionSummary(
        world_size=int(payload["world_size"]),
        contributing_ranks=int(payload["contributing_ranks"]),
        total_processed_candidates=int(payload["total_processed_candidates"]),
        total_processed_chunks=int(payload["total_processed_chunks"]),
        any_has_more=bool(payload["any_has_more"]),
        any_exhaust_all=bool(payload["any_exhaust_all"]),
        has_samples=bool(payload["has_samples"]),
        global_e_min=float(payload["global_e_min"]),
        global_e_max=float(payload["global_e_max"]),
        which_rank_global_e_min=int(payload["which_rank_global_e_min"]),
        which_rank_global_e_max=int(payload["which_rank_global_e_max"]),
        global_e_min_candidate_index=int(payload["global_e_min_candidate_index"]),
        global_e_max_candidate_index=int(payload["global_e_max_candidate_index"]),
        global_de_min_swap=float(payload["global_de_min_swap"]),
        global_swap_count=int(payload["global_swap_count"]),
        total_de_min_swap=float(payload["total_de_min_swap"]),
        total_swap_count=int(payload["total_swap_count"]),
        global_best_structure=(
            _structure_from_dict(payload.get("global_best_structure"))
            if global_best_present
            else None
        ),
        global_worst_structure=(
            _structure_from_dict(payload.get("global_worst_structure"))
            if global_worst_present
            else None
        ),
        global_best_structure_present=global_best_present,
        global_worst_structure_present=global_worst_present,
        primary_recipe_index=int(payload["primary_recipe_index"]),
        primary_recipe_consistent=bool(payload["primary_recipe_consistent"]),
        global_energy_table=_energy_table_from_dict(payload.get("global_energy_table")),
    )
