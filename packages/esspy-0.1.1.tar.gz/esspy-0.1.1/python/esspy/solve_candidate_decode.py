from __future__ import annotations

from dataclasses import asdict, is_dataclass

from .models import ReadyRecipe
from .native import load_native_module


def _to_recipe_payload(recipe: ReadyRecipe | dict) -> dict:
    if is_dataclass(recipe):
        payload = asdict(recipe)
        payload["from"] = payload.pop("from_kind")
        return payload
    return recipe


def decode_candidate_assignment(recipe: ReadyRecipe | dict, index: int = 1) -> dict:
    native = load_native_module()
    return native.decode_candidate_assignment(_to_recipe_payload(recipe), int(index))


def decode_candidate_assignment_ld(recipe: ReadyRecipe | dict, index: float) -> dict:
    native = load_native_module()
    return native.decode_candidate_assignment_ld(_to_recipe_payload(recipe), float(index))
