from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .models import StructureModel, SymmetryModel, SymmetryOperation


@dataclass
class SymmetryDetectionResult:
    space_group_number: int
    international_symbol: str
    symmetry: SymmetryModel


def _to_spglib_cell(structure: StructureModel):
    lattice = [
        list(structure.lattice.a),
        list(structure.lattice.b),
        list(structure.lattice.c),
    ]
    positions = [[site.x, site.y, site.z] for site in structure.sites]
    kind_to_index: dict[str, int] = {}
    numbers: list[int] = []
    next_index = 1
    for site in structure.sites:
        if site.kind not in kind_to_index:
            kind_to_index[site.kind] = next_index
            next_index += 1
        numbers.append(kind_to_index[site.kind])
    return (lattice, positions, numbers)


def detect_symmetry_with_spglib(
    structure: StructureModel, *, symprec: float = 1e-5
) -> SymmetryDetectionResult:
    try:
        import spglib  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "spglib is not installed. Install with `pip install spglib`."
        ) from exc

    cell = _to_spglib_cell(structure)
    dataset = spglib.get_symmetry_dataset(cell, symprec=symprec)
    if dataset is None:
        raise RuntimeError("spglib.get_symmetry_dataset returned None")
    raw_sym = spglib.get_symmetry(cell, symprec=symprec)
    if raw_sym is None:
        raise RuntimeError("spglib.get_symmetry returned None")

    rotations = raw_sym["rotations"]
    translations = raw_sym["translations"]
    operations: list[SymmetryOperation] = []
    for rotation, translation in zip(rotations, translations):
        operations.append(
            SymmetryOperation(
                matrix=(
                    (
                        float(rotation[0][0]),
                        float(rotation[0][1]),
                        float(rotation[0][2]),
                        float(translation[0]),
                    ),
                    (
                        float(rotation[1][0]),
                        float(rotation[1][1]),
                        float(rotation[1][2]),
                        float(translation[1]),
                    ),
                    (
                        float(rotation[2][0]),
                        float(rotation[2][1]),
                        float(rotation[2][2]),
                        float(translation[2]),
                    ),
                )
            )
        )

    if hasattr(dataset, "number"):
        space_group_number = int(dataset.number)
    else:
        space_group_number = int(dataset["number"])
    if hasattr(dataset, "international"):
        international_symbol = str(dataset.international)
    else:
        international_symbol = str(dataset["international"])

    symmetry = SymmetryModel(
        space_group=space_group_number,
        wyc_operations=operations,
        from_spglib=True,
    )
    return SymmetryDetectionResult(
        space_group_number=space_group_number,
        international_symbol=international_symbol,
        symmetry=symmetry,
    )


def symmetry_to_wyc_text(
    symmetry: SymmetryModel, labels: Iterable[str] | None = None
) -> str:
    operations = list(symmetry.wyc_operations)
    if labels is None:
        labels = [f"op{i + 1}" for i in range(len(operations))]
    labels_list = list(labels)
    if len(labels_list) != len(operations):
        raise ValueError("labels length must match number of operations")

    lines: list[str] = [f"Nwyc {len(operations)}"]
    for label, operation in zip(labels_list, operations):
        lines.append(str(label))
        for row in operation.matrix:
            lines.append(
                f"{row[0]:.16g} {row[1]:.16g} {row[2]:.16g} {row[3]:.16g}"
            )
    return "\n".join(lines) + "\n"


def write_wyc_file(path: str | Path, symmetry: SymmetryModel) -> Path:
    path = Path(path)
    path.write_text(symmetry_to_wyc_text(symmetry))
    return path
