from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, Mapping

from .models import Lattice, ReadyModel, Site, StructureModel
from .native import load_native_module


@dataclass
class SwapLoopOptions:
    """Tunables for `compute_swap_loop`.

    `mode == 1` selects best-improvement scanning across each recipe pool;
    `mode == 2` selects first-improvement (matching legacy `Swap == 1`
    and `Swap == 2` respectively). `max_swap <= 0` runs until no
    improvement is possible. `rg_find_factor` and `chop_level` are passed
    through to the shared Ewald evaluator on every candidate evaluation.

    When `starting_sites` is non-empty, the swap loop seeds its working
    structure from the provided per-site (kind, oxidation, x, y, z)
    sequence instead of the canonical recipe materialisation. The list
    must line up site-for-site with the canonical supercell expansion of
    the input `ReadyModel`. Coordinates must match the canonical
    expansion; only (kind, oxidation) may differ. This is what lets the
    integrated solve() pipeline seed the swap loop from a window
    evaluation's best candidate snapshot.
    """

    mode: int = 1
    max_swap: int = 100
    rg_find_factor: int = 1
    chop_level: float = 8.0
    starting_sites: list[Site] = field(default_factory=list)


@dataclass
class SwapAcceptance:
    round: int
    recipe_index: int
    site_a_supercell_index: int
    site_b_supercell_index: int
    kind_a_before: str
    kind_b_before: str
    energy_after: float
    denrg: float


@dataclass
class SwapEnergyCacheStats:
    full_evaluations: int = 0
    diff_evaluations: int = 0
    real_cache_evaluations: int = 0
    real_incremental_updates: int = 0
    point_cache_evaluations: int = 0
    point_incremental_updates: int = 0
    recip_cache_evaluations: int = 0
    recip_state_rebuilds: int = 0
    recip_incremental_updates: int = 0
    recip_fallback_evaluations: int = 0
    diff_cache_enabled: bool = False
    real_pair_terms: int = 0
    recip_kpoint_terms: int = 0


@dataclass
class SwapLoopResult:
    final_structure: StructureModel
    initial_total_energy: float
    final_total_energy: float
    de_min_swap: float
    swap_count: int
    stopped_by_max_swap: bool
    stopped_by_no_improvement: bool
    cache_stats: SwapEnergyCacheStats = field(default_factory=SwapEnergyCacheStats)
    committed_swaps: list[SwapAcceptance] = field(default_factory=list)
    log: list[str] = field(default_factory=list)


def _ready_payload(ready: ReadyModel | Mapping[str, Any]) -> dict:
    if is_dataclass(ready):
        return asdict(ready)
    if isinstance(ready, Mapping):
        return dict(ready)
    raise TypeError(
        "compute_swap_loop expected a ReadyModel or mapping, got "
        + repr(type(ready))
    )


def _options_payload(
    options: SwapLoopOptions | Mapping[str, Any] | None,
) -> dict:
    if options is None:
        return {}
    if is_dataclass(options):
        return asdict(options)
    if isinstance(options, Mapping):
        return dict(options)
    raise TypeError(
        "compute_swap_loop expected SwapLoopOptions or mapping, got "
        + repr(type(options))
    )


def _structure_from_payload(payload: Mapping[str, Any]) -> StructureModel:
    lattice = payload["lattice"]
    return StructureModel(
        title=str(payload["title"]),
        lattice=Lattice(
            a=tuple(lattice["a"]),
            b=tuple(lattice["b"]),
            c=tuple(lattice["c"]),
        ),
        sites=[
            Site(
                kind=str(item["kind"]),
                x=float(item["x"]),
                y=float(item["y"]),
                z=float(item["z"]),
                oxidation=float(item["oxidation"]),
            )
            for item in payload["sites"]
        ],
        fractional_coordinates=bool(payload["fractional_coordinates"]),
    )


def compute_swap_loop(
    ready: ReadyModel | Mapping[str, Any],
    options: SwapLoopOptions | Mapping[str, Any] | None = None,
) -> SwapLoopResult:
    """Run the typed swap loop via the native library.

    Returns the post-swap explicit structure, the initial / final
    total Ewald energies, `de_min_swap = final - initial`, and the list
    of committed swap acceptances.
    """

    native = load_native_module()
    payload = native.compute_swap_loop(
        _ready_payload(ready), _options_payload(options)
    )

    structure = _structure_from_payload(payload["final_structure"])
    committed = [
        SwapAcceptance(
            round=int(item["round"]),
            recipe_index=int(item["recipe_index"]),
            site_a_supercell_index=int(item["site_a_supercell_index"]),
            site_b_supercell_index=int(item["site_b_supercell_index"]),
            kind_a_before=str(item["kind_a_before"]),
            kind_b_before=str(item["kind_b_before"]),
            energy_after=float(item["energy_after"]),
            denrg=float(item["denrg"]),
        )
        for item in payload["committed_swaps"]
    ]
    return SwapLoopResult(
        final_structure=structure,
        initial_total_energy=float(payload["initial_total_energy"]),
        final_total_energy=float(payload["final_total_energy"]),
        de_min_swap=float(payload["de_min_swap"]),
        swap_count=int(payload["swap_count"]),
        stopped_by_max_swap=bool(payload["stopped_by_max_swap"]),
        stopped_by_no_improvement=bool(payload["stopped_by_no_improvement"]),
        cache_stats=SwapEnergyCacheStats(
            full_evaluations=int(payload.get("cache_stats", {}).get("full_evaluations", 0)),
            diff_evaluations=int(payload.get("cache_stats", {}).get("diff_evaluations", 0)),
            real_cache_evaluations=int(payload.get("cache_stats", {}).get("real_cache_evaluations", 0)),
            real_incremental_updates=int(payload.get("cache_stats", {}).get("real_incremental_updates", 0)),
            point_cache_evaluations=int(payload.get("cache_stats", {}).get("point_cache_evaluations", 0)),
            point_incremental_updates=int(payload.get("cache_stats", {}).get("point_incremental_updates", 0)),
            recip_cache_evaluations=int(payload.get("cache_stats", {}).get("recip_cache_evaluations", 0)),
            recip_state_rebuilds=int(payload.get("cache_stats", {}).get("recip_state_rebuilds", 0)),
            recip_incremental_updates=int(payload.get("cache_stats", {}).get("recip_incremental_updates", 0)),
            recip_fallback_evaluations=int(payload.get("cache_stats", {}).get("recip_fallback_evaluations", 0)),
            diff_cache_enabled=bool(payload.get("cache_stats", {}).get("diff_cache_enabled", False)),
            real_pair_terms=int(payload.get("cache_stats", {}).get("real_pair_terms", 0)),
            recip_kpoint_terms=int(payload.get("cache_stats", {}).get("recip_kpoint_terms", 0)),
        ),
        committed_swaps=committed,
        log=[str(line) for line in payload["log"]],
    )
