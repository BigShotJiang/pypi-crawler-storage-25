from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, Mapping

from .models import Lattice, ReadyModel, Site, StructureModel
from .native import load_native_module
from .solve_swap_loop import SwapEnergyCacheStats


@dataclass
class GeneralizedSiteGroupRule:
    name: str
    source_kind: str
    allowed: list[str] = field(default_factory=list)


@dataclass
class GeneralizedChargeEntry:
    kind: str
    site_group: str
    oxidation: float


@dataclass
class GeneralizedElementCharge:
    kind: str
    oxidation: float


@dataclass
class GeneralizedSwapOptions:
    number_starts: int = 20
    start_index_offset: int = 0
    start_index_stride: int = 1
    max_steps_per_start: int = 100
    random_shuffle_steps: int = 256
    rg_find_factor: int = 1
    chop_level: float = 8.0
    improvement_tol: float = 1.0e-12
    time_budget_sec: float = 0.0
    seed: int = 0
    site_groups: list[GeneralizedSiteGroupRule] = field(default_factory=list)
    element_charges: list[GeneralizedElementCharge] = field(default_factory=list)
    site_charges: list[GeneralizedChargeEntry] = field(default_factory=list)


@dataclass
class GeneralizedSwapMove:
    start_index: int
    step: int
    site_a: int
    site_b: int
    group_a: str
    group_b: str
    kind_a_before: str
    kind_b_before: str
    denrg: float
    energy_after: float


@dataclass
class GeneralizedSwapStartSummary:
    start_index: int
    initial_energy: float
    final_energy: float
    accepted_moves: int


@dataclass
class GeneralizedSwapResult:
    best_structure: StructureModel
    initial_energy: float
    best_energy: float
    starts_evaluated: int
    accepted_moves: int
    stopped_by_no_improvement: bool
    cache_stats: SwapEnergyCacheStats = field(default_factory=SwapEnergyCacheStats)
    group_by_site: list[str] = field(default_factory=list)
    starts: list[GeneralizedSwapStartSummary] = field(default_factory=list)
    accepted: list[GeneralizedSwapMove] = field(default_factory=list)
    log: list[str] = field(default_factory=list)
    mpi_stats: dict[str, Any] = field(default_factory=dict)


def _ready_payload(ready: ReadyModel | Mapping[str, Any]) -> dict:
    if is_dataclass(ready):
        return asdict(ready)
    if isinstance(ready, Mapping):
        return dict(ready)
    raise TypeError(
        "compute_generalized_swap_loop expected a ReadyModel or mapping, got "
        + repr(type(ready))
    )


def _options_payload(
    options: GeneralizedSwapOptions | Mapping[str, Any] | None,
) -> dict:
    if options is None:
        return {}
    if is_dataclass(options):
        return asdict(options)
    if isinstance(options, Mapping):
        return dict(options)
    raise TypeError(
        "compute_generalized_swap_loop expected GeneralizedSwapOptions or mapping, got "
        + repr(type(options))
    )


def _structure_from_payload(payload: Mapping[str, Any]) -> StructureModel:
    lattice = payload["lattice"]
    return StructureModel(
        title=str(payload["title"]),
        lattice=Lattice(
            a=tuple(lattice["a"]),
            b=tuple(lattice["b"]),
            c=tuple(lattice["c"]),
        ),
        sites=[
            Site(
                kind=str(item["kind"]),
                x=float(item["x"]),
                y=float(item["y"]),
                z=float(item["z"]),
                oxidation=float(item["oxidation"]),
            )
            for item in payload["sites"]
        ],
        fractional_coordinates=bool(payload["fractional_coordinates"]),
    )


def compute_generalized_swap_loop(
    ready: ReadyModel | Mapping[str, Any],
    options: GeneralizedSwapOptions | Mapping[str, Any] | None = None,
) -> GeneralizedSwapResult:
    native = load_native_module()
    payload = native.compute_generalized_swap_loop(
        _ready_payload(ready), _options_payload(options)
    )
    return GeneralizedSwapResult(
        best_structure=_structure_from_payload(payload["best_structure"]),
        initial_energy=float(payload["initial_energy"]),
        best_energy=float(payload["best_energy"]),
        starts_evaluated=int(payload["starts_evaluated"]),
        accepted_moves=int(payload["accepted_moves"]),
        stopped_by_no_improvement=bool(payload["stopped_by_no_improvement"]),
        group_by_site=[str(x) for x in payload.get("group_by_site", [])],
        cache_stats=SwapEnergyCacheStats(
            full_evaluations=int(payload.get("cache_stats", {}).get("full_evaluations", 0)),
            diff_evaluations=int(payload.get("cache_stats", {}).get("diff_evaluations", 0)),
            real_cache_evaluations=int(payload.get("cache_stats", {}).get("real_cache_evaluations", 0)),
            real_incremental_updates=int(payload.get("cache_stats", {}).get("real_incremental_updates", 0)),
            point_cache_evaluations=int(payload.get("cache_stats", {}).get("point_cache_evaluations", 0)),
            point_incremental_updates=int(payload.get("cache_stats", {}).get("point_incremental_updates", 0)),
            recip_cache_evaluations=int(payload.get("cache_stats", {}).get("recip_cache_evaluations", 0)),
            recip_state_rebuilds=int(payload.get("cache_stats", {}).get("recip_state_rebuilds", 0)),
            recip_incremental_updates=int(payload.get("cache_stats", {}).get("recip_incremental_updates", 0)),
            recip_fallback_evaluations=int(payload.get("cache_stats", {}).get("recip_fallback_evaluations", 0)),
            diff_cache_enabled=bool(payload.get("cache_stats", {}).get("diff_cache_enabled", False)),
            real_pair_terms=int(payload.get("cache_stats", {}).get("real_pair_terms", 0)),
            recip_kpoint_terms=int(payload.get("cache_stats", {}).get("recip_kpoint_terms", 0)),
        ),
        starts=[
            GeneralizedSwapStartSummary(
                start_index=int(item["start_index"]),
                initial_energy=float(item["initial_energy"]),
                final_energy=float(item["final_energy"]),
                accepted_moves=int(item["accepted_moves"]),
            )
            for item in payload.get("starts", [])
        ],
        accepted=[
            GeneralizedSwapMove(
                start_index=int(item["start_index"]),
                step=int(item["step"]),
                site_a=int(item["site_a"]),
                site_b=int(item["site_b"]),
                group_a=str(item["group_a"]),
                group_b=str(item["group_b"]),
                kind_a_before=str(item["kind_a_before"]),
                kind_b_before=str(item["kind_b_before"]),
                denrg=float(item["denrg"]),
                energy_after=float(item["energy_after"]),
            )
            for item in payload.get("accepted", [])
        ],
        log=[str(line) for line in payload.get("log", [])],
    )
