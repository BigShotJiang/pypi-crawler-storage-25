from __future__ import annotations

import json
import random
import re
import hashlib
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import tempfile
from typing import Any

import yaml


@dataclass
class SiteGroup:
    name: str
    source_kind: str
    count: int
    allowed: list[str]


def _normalize_site_label(text: str) -> str:
    s = str(text).strip()
    m = re.fullmatch(r"site[-_]?(\d+)", s, flags=re.IGNORECASE)
    if m:
        return f"site-{int(m.group(1)):03d}"
    return s


def _to_int_count(value: Any, *, label: str) -> int:
    try:
        v = float(value)
    except Exception as exc:
        raise ValueError(f"{label} must be numeric, got: {value!r}") from exc
    if v < 0:
        raise ValueError(f"{label} must be >= 0, got: {v}")
    iv = int(round(v))
    if abs(v - iv) > 1e-8:
        raise ValueError(f"{label} must be integer-like, got: {v}")
    return iv


def _load_site_groups(payload: dict[str, Any]) -> list[SiteGroup]:
    raw = payload.get("site_groups")
    if not isinstance(raw, dict) or not raw:
        raise ValueError("`site_groups` is required and must be a non-empty mapping")
    groups: list[SiteGroup] = []
    for name, info in raw.items():
        if not isinstance(info, dict):
            raise ValueError(f"`site_groups.{name}` must be a mapping")
        source = str(info.get("source_kind", "")).strip()
        count = _to_int_count(info.get("count", 0), label=f"site_groups.{name}.count")
        allowed_raw = info.get("allowed", [])
        if not isinstance(allowed_raw, list) or not allowed_raw:
            raise ValueError(f"`site_groups.{name}.allowed` must be a non-empty list")
        allowed = [str(x).strip() for x in allowed_raw if str(x).strip()]
        if not source:
            raise ValueError(f"`site_groups.{name}.source_kind` is required")
        groups.append(SiteGroup(name=str(name), source_kind=source, count=count, allowed=allowed))
    return groups


def _load_composition_counts(payload: dict[str, Any]) -> dict[str, int]:
    comp = payload.get("composition")
    if not isinstance(comp, dict) or not comp:
        raise ValueError("`composition` is required and must be a non-empty mapping")

    fractions = comp.get("fractions")
    if isinstance(fractions, dict):
        structure = payload.get("structure", {})
        if not isinstance(structure, dict):
            raise ValueError("`structure` is required when composition.fractions is used")
        n_target_sites = _infer_target_sites(payload)
        if n_target_sites is None:
            raise ValueError(
                "`structure.n_target_sites` or `structure.dim` is required when composition.fractions is used"
            )
        return _counts_from_fraction_values(
            fractions,
            n_target_sites=int(n_target_sites),
            number_fixed_at=str(structure.get("number_fixed_at", "O")),
        )

    out: dict[str, int] = {}
    for k, v in comp.items():
        if k == "fractions":
            continue
        out[str(k)] = _to_int_count(v, label=f"composition.{k}")
    if not out:
        raise ValueError("No integer composition counts found in `composition`")
    return out


def _infer_target_sites(payload: dict[str, Any]) -> int | None:
    structure = payload.get("structure", {})
    if not isinstance(structure, dict):
        return None
    if structure.get("n_target_sites") is not None:
        requested = _to_int_count(
            structure.get("n_target_sites"),
            label="structure.n_target_sites",
        )
        if not any(structure.get(key) is not None for key in ("dim", "supercell", "supercell_expansion")):
            try:
                from .guide_supercell import compute_supercell_expansion
                from .poscar import load_poscar

                poscar = structure.get("poscar")
                if poscar is not None:
                    model = load_poscar(poscar)
                    resolved = compute_supercell_expansion(
                        model.lattice,
                        len(model.sites),
                        requested,
                    )
                    if resolved.expanded_n_atom_config > 0:
                        return int(resolved.expanded_n_atom_config)
            except Exception:
                pass
        return requested

    dim = None
    for key in ("dim", "supercell", "supercell_expansion"):
        if structure.get(key) is not None:
            dim = structure.get(key)
            break
    if dim is None:
        return None

    scale = _dim_determinant_scale(dim)
    base_sites = _base_site_count_from_payload(payload)
    if base_sites is None:
        return None
    return int(base_sites) * int(scale)


def _base_site_count_from_payload(payload: dict[str, Any]) -> int | None:
    site_groups = payload.get("site_groups")
    if isinstance(site_groups, dict) and site_groups:
        total = 0
        for name, info in site_groups.items():
            if not isinstance(info, dict):
                return None
            if info.get("count") is not None:
                total += _to_int_count(info.get("count"), label=f"site_groups.{name}.count")
            elif isinstance(info.get("site_indices"), list):
                total += len(info.get("site_indices", []))
            else:
                return None
        if total > 0:
            return total

    structure = payload.get("structure", {})
    if isinstance(structure, dict) and isinstance(structure.get("sites"), list):
        return len(structure["sites"])
    return None


def _dim_determinant_scale(dim: Any) -> int:
    if isinstance(dim, (list, tuple)) and len(dim) == 3 and not any(
        isinstance(item, (list, tuple)) for item in dim
    ):
        vals = [_to_int_count(item, label=f"structure.dim[{idx}]") for idx, item in enumerate(dim)]
        if any(v <= 0 for v in vals):
            raise ValueError("structure.dim entries must be positive")
        return vals[0] * vals[1] * vals[2]

    if isinstance(dim, (list, tuple)) and len(dim) == 9:
        rows = [list(dim[0:3]), list(dim[3:6]), list(dim[6:9])]
    elif (
        isinstance(dim, (list, tuple))
        and len(dim) == 3
        and all(isinstance(row, (list, tuple)) and len(row) == 3 for row in dim)
    ):
        rows = [list(row) for row in dim]
    else:
        raise ValueError("structure.dim must contain 3 or 9 integers")

    matrix = [
        [_to_int_count(raw, label=f"structure.dim[{i}][{j}]") for j, raw in enumerate(row)]
        for i, row in enumerate(rows)
    ]
    det = (
        matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])
    )
    if det <= 0:
        raise ValueError("structure.dim matrix determinant must be positive")
    return int(det)


def _counts_from_fraction_values(
    values: dict[str, Any],
    *,
    n_target_sites: int,
    number_fixed_at: str,
) -> dict[str, int]:
    raw = [(str(kind), float(fraction)) for kind, fraction in values.items()]
    if not raw:
        raise ValueError("`composition.fractions` must not be empty")
    if any(fraction < 0.0 for _, fraction in raw):
        raise ValueError("`composition.fractions` must be non-negative")
    fraction_total = sum(fraction for _, fraction in raw)
    if fraction_total <= 0.0:
        raise ValueError("`composition.fractions` must sum to a positive number")
    raw = [(kind, fraction / fraction_total) for kind, fraction in raw]

    fixed_index = next(
        (index for index, (kind, _) in enumerate(raw) if kind == number_fixed_at),
        None,
    )
    if fixed_index is None:
        counts: list[int] = []
        remainders: list[tuple[float, int]] = []
        for index, (_, fraction) in enumerate(raw):
            scaled = fraction * n_target_sites
            count = int(math.floor(scaled))
            counts.append(count)
            remainders.append((scaled - count, index))
        missing = n_target_sites - sum(counts)
        for _, index in sorted(remainders, reverse=True)[:missing]:
            counts[index] += 1
        return {kind: count for (kind, _), count in zip(raw, counts)}

    counts: list[int] = []
    remainders: list[tuple[float, int]] = []
    for index, (_, fraction) in enumerate(raw):
        if index == fixed_index:
            counts.append(0)
            continue
        scaled = fraction * n_target_sites
        count = int(math.floor(scaled))
        counts.append(count)
        remainders.append((scaled - count, index))

    target_nonfixed = int(
        round(
            sum(
                fraction
                for index, (_, fraction) in enumerate(raw)
                if index != fixed_index
            )
            * n_target_sites
        )
    )
    missing = target_nonfixed - sum(counts)
    for _, index in sorted(remainders, reverse=True)[:missing]:
        counts[index] += 1

    residue = n_target_sites - sum(counts)
    if residue < 0:
        raise ValueError(
            "`composition.fractions` non-fixed species exceed structure.n_target_sites"
        )
    counts[fixed_index] = residue
    return {kind: count for (kind, _), count in zip(raw, counts)}


def _scale_site_group_counts(
    groups: list[SiteGroup],
    composition_total: int,
    n_target_sites: int | None,
) -> list[SiteGroup]:
    base_total = sum(g.count for g in groups)
    if base_total <= 0:
        raise ValueError("Invalid site_groups: total count must be > 0")
    target_total = int(n_target_sites) if n_target_sites is not None else int(composition_total)
    if target_total <= 0:
        raise ValueError("Target total sites must be > 0")
    if target_total == base_total:
        return groups
    if target_total % base_total != 0:
        raise ValueError(
            f"Target sites ({target_total}) is not an integer multiple of site_groups total ({base_total})"
        )
    scale = target_total // base_total
    scaled: list[SiteGroup] = []
    for g in groups:
        scaled.append(
            SiteGroup(
                name=g.name,
                source_kind=g.source_kind,
                count=g.count * scale,
                allowed=list(g.allowed),
            )
        )
    return scaled


def _build_initial_weights(elements: list[str], groups: list[SiteGroup]) -> dict[str, dict[str, float]]:
    weights: dict[str, dict[str, float]] = {}
    for elem in elements:
        weights[elem] = {}
        for g in groups:
            if elem not in g.allowed:
                continue
            w = 2.0 if elem == g.source_kind else 1.0
            weights[elem][g.name] = w
    return weights


def _apply_user_preferences(
    weights: dict[str, dict[str, float]],
    preferences: dict[str, float],
) -> None:
    # key format: "Element@site_group"
    for key, value in preferences.items():
        if "@" not in key:
            raise ValueError(f"Invalid preference key: {key!r}. Expected Element@site_group")
        elem, group = key.split("@", 1)
        elem = elem.strip()
        group = group.strip()
        if elem not in weights or group not in weights[elem]:
            continue
        if value <= 0:
            raise ValueError(f"Preference weight must be > 0 for {key}")
        weights[elem][group] = float(value)


def _bounded_compositions(total: int, bounds: list[int]) -> list[list[int]]:
    out: list[list[int]] = []
    cur = [0] * len(bounds)

    def _dfs(i: int, remaining: int) -> None:
        if i == len(bounds) - 1:
            if 0 <= remaining <= bounds[i]:
                cur[i] = remaining
                out.append(list(cur))
            return
        upper = min(bounds[i], remaining)
        for v in range(upper + 1):
            cur[i] = v
            _dfs(i + 1, remaining - v)

    _dfs(0, int(total))
    return out


def _enumerate_feasible_allocations(
    composition: dict[str, int],
    groups: list[SiteGroup],
    *,
    max_solutions: int | None = None,
) -> list[dict[str, dict[str, int]]]:
    group_names = [g.name for g in groups]
    cap_init = {g.name: int(g.count) for g in groups}

    for elem, cnt in composition.items():
        eligible = [g for g in groups if elem in g.allowed]
        if not eligible:
            raise ValueError(f"Element `{elem}` has no eligible site groups.")
        if sum(int(g.count) for g in eligible) < int(cnt):
            raise ValueError(
                f"Insufficient total eligible capacity for `{elem}`: "
                f"demand={cnt}, capacity={sum(int(g.count) for g in eligible)}"
            )

    by_site_template: dict[str, dict[str, int]] = {name: {} for name in group_names}
    cap_remaining = dict(cap_init)
    elems = [e for e, c in composition.items() if int(c) > 0]
    elems.sort(key=lambda e: (sum(1 for g in groups if e in g.allowed), -int(composition[e]), e))

    solutions: list[dict[str, dict[str, int]]] = []

    def _dfs_elem(idx: int) -> None:
        if max_solutions is not None and len(solutions) >= int(max_solutions):
            return
        if idx >= len(elems):
            if all(v == 0 for v in cap_remaining.values()):
                sol = {k: dict(v) for k, v in by_site_template.items()}
                solutions.append(sol)
            return

        elem = elems[idx]
        demand = int(composition[elem])
        eligible = [g.name for g in groups if elem in g.allowed]
        bounds = [int(cap_remaining[g]) for g in eligible]
        for parts in _bounded_compositions(demand, bounds):
            touched: list[tuple[str, int]] = []
            for gname, take in zip(eligible, parts):
                if take <= 0:
                    continue
                by_site_template[gname][elem] = by_site_template[gname].get(elem, 0) + int(take)
                cap_remaining[gname] -= int(take)
                touched.append((gname, int(take)))
            _dfs_elem(idx + 1)
            for gname, take in touched:
                cap_remaining[gname] += int(take)
                now = int(by_site_template[gname].get(elem, 0)) - int(take)
                if now <= 0:
                    by_site_template[gname].pop(elem, None)
                else:
                    by_site_template[gname][elem] = now

    _dfs_elem(0)
    return solutions


def _score_allocation(by_site: dict[str, dict[str, int]], groups: list[SiteGroup]) -> float:
    source_map = {g.name: g.source_kind for g in groups}
    same_source = 0
    total = 0
    for gname, row in by_site.items():
        src = source_map[gname]
        for elem, cnt in row.items():
            total += int(cnt)
            if elem == src:
                same_source += int(cnt)
    if total <= 0:
        return 0.0
    return float(same_source) / float(total)


def _write_yaml(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=False))


def _resolve_structure_poscar(payload: dict[str, Any], input_path: Path) -> dict[str, Any]:
    structure = payload.get("structure")
    if not isinstance(structure, dict):
        return payload
    poscar = structure.get("poscar")
    if poscar is None:
        return payload
    poscar_path = Path(str(poscar)).expanduser()
    if poscar_path.is_absolute():
        return payload
    updated = dict(payload)
    updated_structure = dict(structure)
    updated_structure["poscar"] = str((input_path.parent / poscar_path).resolve())
    updated["structure"] = updated_structure
    return updated


def _run_guide_gate(candidate_yaml: Path) -> tuple[bool, str]:
    from .run_outputs import run_yaml_to_outputs

    with tempfile.TemporaryDirectory(prefix="esspy_alloc_gate_") as td:
        workdir = Path(td) / "guide"
        try:
            run_yaml_to_outputs(
                str(candidate_yaml),
                workdir=str(workdir),
                guide_only=True,
                quiet=True,
                json_stdout=False,
                no_progress=True,
            )
            return True, ""
        except Exception as exc:
            return False, str(exc)


def _eval_ewald_score(
    candidate_yaml: Path,
    n_samples: int,
    seed: int | None,
    metric: str,
    topk: int,
) -> tuple[float, dict[str, float]]:
    from .fit_charge import (
        _ewald_energy_for_structure,
        _read_site_group_labels_from_poscar_comment,
        _solve_options_single_eval,
    )  # type: ignore
    from .poscar import load_poscar
    from .sample_structures import write_random_samples_from_yaml

    payload = yaml.safe_load(candidate_yaml.read_text()) or {}
    charges_raw = payload.get("charges")
    if not isinstance(charges_raw, dict) or not charges_raw:
        raise ValueError("Missing `charges` mapping for Ewald scoring")
    charge_by_kind: dict[str, float] = {}
    has_sitewise = False
    # v2 schema: charges.elements.<Element>.default
    if isinstance(charges_raw.get("elements"), dict):
        for elem, node in charges_raw.get("elements", {}).items():
            if not isinstance(node, dict):
                continue
            by_site = node.get("by_site", {})
            if isinstance(by_site, dict) and by_site:
                for site, value in by_site.items():
                    elem_s = str(elem).strip()
                    site_s = str(site).strip()
                    norm_site = _normalize_site_label(site_s)
                    charge_by_kind[f"{elem_s}@{site_s}"] = float(value)
                    charge_by_kind[f"{elem_s}@{norm_site}"] = float(value)
                has_sitewise = True
            if "default" in node:
                charge_by_kind[str(elem)] = float(node["default"])
    elif isinstance(charges_raw.get("values"), dict):
        # structured fallback
        charge_by_kind = {str(k): float(v) for k, v in charges_raw.get("values", {}).items()}
    else:
        # legacy fallback
        charge_by_kind = {str(k): float(v) for k, v in charges_raw.items()}
    if not charge_by_kind:
        raise ValueError("No usable element-level charges found for Ewald scoring")

    with tempfile.TemporaryDirectory(prefix="esspy_alloc_score_") as td:
        sample_dir = Path(td) / "samples"
        sample_paths = write_random_samples_from_yaml(
            str(candidate_yaml),
            n_samples=int(max(1, n_samples)),
            outdir=sample_dir,
            prefix="alloc-sample",
            seed=seed,
        )
        solve_opts = _solve_options_single_eval()
        energies: list[float] = []
        for p in sample_paths:
            atom_kind_labels = None
            if has_sitewise:
                raw_site_labels = _read_site_group_labels_from_poscar_comment(p)
                if raw_site_labels is None:
                    raise ValueError(
                        f"site-aware allocation scoring requires '# site-xxx' labels: {p}"
                    )
                structure = load_poscar(p)
                if len(raw_site_labels) != len(structure.sites):
                    raise ValueError(
                        f"site label count mismatch in {p}: "
                        f"{len(raw_site_labels)} != {len(structure.sites)}"
                    )
                atom_kind_labels = [
                    f"{site.kind}@{site_label}"
                    for site, site_label in zip(structure.sites, raw_site_labels)
                ]
                vac_labels = [k for k in atom_kind_labels if k.startswith("vac@")]
                if vac_labels:
                    raise ValueError(
                        "vacancy label detected in sampled structure (invalid for full-occupancy run): "
                        + ", ".join(sorted(set(vac_labels))[:8])
                    )
            e = _ewald_energy_for_structure(
                p,
                charge_by_kind,
                rg_find_factor=3,
                chop_level=8.0,
                solve_options=solve_opts,
                atom_kind_labels=atom_kind_labels,
            )
            energies.append(float(e))
    best = min(energies)
    mean = sum(energies) / float(len(energies))
    sorted_e = sorted(energies)
    k = max(1, min(int(topk), len(sorted_e)))
    topk_mean = sum(sorted_e[:k]) / float(k)
    if metric == "best":
        objective_e = best
    elif metric == "min_mean":
        objective_e = mean
    elif metric == "topk_mean":
        objective_e = topk_mean
    else:
        raise ValueError(f"Unknown metric: {metric}")
    # lower is better; score is negated objective
    return -objective_e, {
        "selection_metric": str(metric),
        "best_ewald_eV": best,
        "mean_ewald_eV": mean,
        "topk_mean_ewald_eV": topk_mean,
        "topk_used": float(k),
        "n_samples": float(len(energies)),
    }


def optimize_site_allocation(
    input_yaml: str | Path,
    out_yaml: str | Path,
    out_table: str | Path,
    preferences: dict[str, float] | None = None,
    n_alloc: int = 1,
    n_alloc_feasible_target: int | None = None,
    n_alloc_max_requested: int | None = None,
    seed: int | None = None,
    dry_run: bool = False,
    score_mode: str = "ewald",
    ewald_samples: int = 8,
    guide_gate: bool = True,
    metric: str = "best",
    topk: int = 3,
    beam_width: int = 5,
    beam_rounds: int = 2,
) -> dict[str, Any]:
    input_path = Path(input_yaml).resolve()
    payload = yaml.safe_load(input_path.read_text()) or {}
    if not isinstance(payload, dict):
        raise ValueError("Input YAML root must be a mapping")
    payload = _resolve_structure_poscar(payload, input_path)

    groups = _load_site_groups(payload)
    composition = _load_composition_counts(payload)
    composition_total = int(sum(composition.values()))
    n_target_sites = None
    structure = payload.get("structure")
    if isinstance(structure, dict) and structure.get("n_target_sites") is not None:
        n_target_sites = _to_int_count(
            structure.get("n_target_sites"),
            label="structure.n_target_sites",
        )
    groups = _scale_site_group_counts(groups, composition_total, n_target_sites)
    if sum(g.count for g in groups) != composition_total:
        raise ValueError(
            "Total composition count does not match scaled site-group slots: "
            f"{composition_total} vs {sum(g.count for g in groups)}"
        )
    prefs = preferences or {}
    n_trials = max(1, int(n_alloc))
    feasible_target = (
        None
        if n_alloc_feasible_target is None
        else max(1, int(n_alloc_feasible_target))
    )
    resolved_seed: int
    if seed is None:
        payload_fingerprint = json.dumps(
            {
                "composition": composition,
                "site_groups": [
                    {
                        "name": g.name,
                        "source_kind": g.source_kind,
                        "count": g.count,
                        "allowed": g.allowed,
                    }
                    for g in groups
                ],
                "score_mode": score_mode,
                "metric": metric,
                "topk": int(topk),
                "ewald_samples": int(ewald_samples),
                "n_alloc": int(n_trials),
                "n_alloc_feasible_target": (
                    None if feasible_target is None else int(feasible_target)
                ),
                "n_alloc_max_requested": (
                    None if n_alloc_max_requested is None else int(n_alloc_max_requested)
                ),
            },
            sort_keys=True,
        )
        digest = hashlib.sha256(payload_fingerprint.encode("utf-8")).hexdigest()
        resolved_seed = int(digest[:8], 16)
    else:
        resolved_seed = int(seed)
    rng = random.Random(resolved_seed)
    candidates: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    seen_signatures: set[str] = set()
    all_feasible = _enumerate_feasible_allocations(composition, groups)
    if not all_feasible:
        raise ValueError("No feasible site allocation found under current constraints.")
    # deterministic shuffle to avoid path-dependent bias when taking subset
    rng.shuffle(all_feasible)
    if n_alloc_max_requested is not None:
        req_cap = max(1, int(n_alloc_max_requested))
    else:
        req_cap = int(n_trials)
    req_cap = min(req_cap, len(all_feasible))
    eval_pool = all_feasible[:req_cap]

    def _candidate_signature(by_site: dict[str, dict[str, int]]) -> str:
        return json.dumps(by_site, sort_keys=True)

    def _evaluate_candidate(
        by_site: dict[str, dict[str, int]],
        *,
        candidate_yaml_dir: Path,
        candidate_index: int,
    ) -> None:
        sig = _candidate_signature(by_site)
        if sig in seen_signatures:
            return
        seen_signatures.add(sig)
        updated_trial = dict(payload)
        updated_trial["composition_by_site"] = by_site
        c_yaml = candidate_yaml_dir / f"candidate-{candidate_index:03d}.yaml"
        _write_yaml(c_yaml, updated_trial)
        guide_ok = True
        guide_error = ""
        if guide_gate:
            guide_ok, guide_error = _run_guide_gate(c_yaml)
            if not guide_ok:
                raise ValueError(f"guide gate failed: {guide_error}")
        base_score = _score_allocation(by_site, groups)
        score = base_score
        metrics: dict[str, float] = {"site_affinity_score": base_score}
        if score_mode == "ewald":
            score, ewald_metrics = _eval_ewald_score(
                c_yaml,
                n_samples=ewald_samples,
                seed=resolved_seed,
                metric=metric,
                topk=topk,
            )
            metrics.update(ewald_metrics)
        candidates.append(
            {
                "index": candidate_index,
                "score": score,
                "score_mode": score_mode,
                "metrics": metrics,
                "guide_ok": guide_ok,
                "composition_by_site": by_site,
                "preferences": dict(prefs),
            }
        )
    with tempfile.TemporaryDirectory(prefix="esspy_alloc_candidates_") as tdc:
        candidate_yaml_dir = Path(tdc)
        next_index = 1
        attempted = 0
        for i, by_site in enumerate(eval_pool, start=1):
            attempted += 1
            try:
                _evaluate_candidate(
                    by_site,
                    candidate_yaml_dir=candidate_yaml_dir,
                    candidate_index=next_index,
                )
                next_index += 1
            except Exception as exc:
                failures.append({"index": str(i + 1), "error": str(exc)})
            if feasible_target is not None and len(candidates) >= feasible_target:
                break
    if not candidates:
        details = failures[0]["error"] if failures else "unknown"
        raise ValueError(f"Failed to generate feasible allocation: {details}")
    candidates.sort(key=lambda x: (x["score"], -x["index"]), reverse=True)
    best = candidates[0]
    by_site = best["composition_by_site"]

    updated = dict(payload)
    updated["composition_by_site"] = by_site

    out_yaml_path = Path(out_yaml).resolve()
    out_table_path = Path(out_table).resolve()
    out_yaml_path.parent.mkdir(parents=True, exist_ok=True)
    out_table_path.parent.mkdir(parents=True, exist_ok=True)

    if not dry_run:
        out_yaml_path.write_text(yaml.safe_dump(updated, sort_keys=False, allow_unicode=False))

    table = {
        "status": "ok",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "input": str(input_path),
        "output_yaml": str(out_yaml_path),
        "site_groups": [
            {
                "name": g.name,
                "source_kind": g.source_kind,
                "count": g.count,
                "allowed": g.allowed,
            }
            for g in groups
        ],
        "composition": composition,
        "best": best,
        "composition_by_site": by_site,
        "preferences": best["preferences"],
        "n_alloc_requested": attempted if "attempted" in locals() else 0,
        "n_alloc_requested_config": n_trials,
        "n_alloc_feasible_target": feasible_target,
        "n_alloc_max_requested": req_cap,
        "n_alloc_total_feasible": len(all_feasible),
        "n_alloc_feasible": len(candidates),
        "n_alloc_failed": len(failures),
        "seed": resolved_seed,
        "seed_mode": "deterministic_from_input" if seed is None else "user_provided",
        "dry_run": bool(dry_run),
        "score_mode": score_mode,
        "metric": str(metric),
        "topk": int(topk),
        "guide_gate": bool(guide_gate),
        "ewald_samples": int(ewald_samples),
        "beam_width": int(beam_width),
        "beam_rounds": int(beam_rounds),
        "candidates": candidates,
    }
    out_table_path.write_text(json.dumps(table, indent=2))
    return table
