from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Mapping, Sequence

from .models import Lattice, SymmetryOperation
from .native import load_native_module


_Vec3 = tuple[float, float, float]


@dataclass
class AddIonsOptions:
    shell_width: float = 1.0
    wyc_identity_length: float = 0.2
    abc_weights: tuple[float, float, float] = (2.0, 2.0, 1.0)
    n_random_seeds: int = 2000
    random_seed: int = 0


@dataclass
class AddedSite:
    fractional: _Vec3
    cartesian: _Vec3


@dataclass
class AddIonsResult:
    added_sites: list[AddedSite]
    chosen_random_seeds: list[_Vec3]
    neighbor_distance_max: float
    log: list[str] = field(default_factory=list)


def _lattice_payload(lattice: Lattice | Mapping[str, Sequence[float]]) -> dict:
    if isinstance(lattice, Lattice):
        return {"a": list(lattice.a), "b": list(lattice.b), "c": list(lattice.c)}
    return {
        "a": list(lattice["a"]),
        "b": list(lattice["b"]),
        "c": list(lattice["c"]),
    }


def _coerce_vec3(value: Iterable[float]) -> _Vec3:
    parts = tuple(float(v) for v in value)
    if len(parts) != 3:
        raise ValueError("Expected length-3 sequence")
    return parts  # type: ignore[return-value]


def _wyc_operation_payload(operation: SymmetryOperation | Sequence[Sequence[float]]):
    if isinstance(operation, SymmetryOperation):
        return [list(row) for row in operation.matrix]
    return [list(row) for row in operation]


def _options_payload(options: AddIonsOptions | Mapping[str, object] | None) -> dict:
    if options is None:
        return {}
    if isinstance(options, AddIonsOptions):
        return {
            "shell_width": options.shell_width,
            "wyc_identity_length": options.wyc_identity_length,
            "abc_weights": list(options.abc_weights),
            "n_random_seeds": options.n_random_seeds,
            "random_seed": options.random_seed,
        }
    return dict(options)


def compute_add_ions(
    lattice: Lattice | Mapping[str, Sequence[float]],
    existing_fractional: Sequence[Sequence[float]],
    wyc_operations: Sequence[SymmetryOperation] | Sequence[Sequence[Sequence[float]]],
    n_to_add: int,
    options: AddIonsOptions | Mapping[str, object] | None = None,
) -> AddIonsResult:
    """Run the Guider's add_ions() routine via the native library."""

    native = load_native_module()
    payload = native.compute_add_ions(
        _lattice_payload(lattice),
        [list(_coerce_vec3(item)) for item in existing_fractional],
        [_wyc_operation_payload(op) for op in wyc_operations],
        int(n_to_add),
        _options_payload(options),
    )

    added = [
        AddedSite(
            fractional=_coerce_vec3(site["fractional"]),
            cartesian=_coerce_vec3(site["cartesian"]),
        )
        for site in payload["added_sites"]
    ]
    seeds = [_coerce_vec3(seed) for seed in payload["chosen_random_seeds"]]
    return AddIonsResult(
        added_sites=added,
        chosen_random_seeds=seeds,
        neighbor_distance_max=float(payload["neighbor_distance_max"]),
        log=[str(line) for line in payload["log"]],
    )
