"""Public ready-file text parser for the `esspy solve` command family.

The internal regression suite already had a minimal ready parser under
`tests/golden/ready_parser.py`, but it was scoped to test fixtures and
did not expose the lattice block. The `esspy solve` CLI commands need
the full payload (lattice + atoms + supercell expansion + recipes +
scalar options) to construct the dict shape that the native
`compute_swap_loop`, `analyze_search_space`, and
`decode_candidate_assignment` functions consume.

This module is the public, documented ready-file reader.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


_Vec3 = tuple[float, float, float]


@dataclass(frozen=True)
class ReadyAtom:
    kind: str
    oxidation: float
    x: float
    y: float
    z: float


@dataclass(frozen=True)
class ReadyRecipeModification:
    to: str
    oxidation: float
    count: int


@dataclass(frozen=True)
class ReadyRecipe:
    from_kind: str
    oxidation: float
    random_pickup: int
    random_pickup_trial: int
    modifications: tuple[ReadyRecipeModification, ...]


@dataclass(frozen=True)
class ReadyTextDoc:
    """Typed view of a parsed ready text file.

    All fields below mirror the legacy `read_para()` block in
    `EwaldSolidSolution.cpp`. Optional fields default to the legacy
    defaults when the source ready file omitted them.
    """

    path: Path
    vec_a: _Vec3
    vec_b: _Vec3
    vec_c: _Vec3
    n_atom_config: int
    atom_config: tuple[ReadyAtom, ...]
    supercell_expansion: tuple[int, int, int]
    chop_level: int
    rg_find_factor: int
    output_prefix: str
    recipes: tuple[ReadyRecipe, ...] = field(default_factory=tuple)


_RECIPE_BLOCK_HEADER = (
    'kind=oxidation=random_pickup=random_pickup_trial=[[[to_which(kind;'
    '"vac"->delete)=to_which(oxidation)=to_which(number)]]]'
)


def _parse_vec3(line: str, name: str) -> _Vec3:
    parts = line.split()
    if len(parts) < 4:
        raise ValueError(f"Malformed `{name}` line in ready text: {line!r}")
    return (float(parts[1]), float(parts[2]), float(parts[3]))


def _parse_atom_line(line: str) -> ReadyAtom:
    parts = line.split()
    if len(parts) != 5:
        raise ValueError(f"Malformed AtomConfig line in ready text: {line!r}")
    return ReadyAtom(
        kind=parts[0],
        oxidation=float(parts[1]),
        x=float(parts[2]),
        y=float(parts[3]),
        z=float(parts[4]),
    )


def _parse_recipe_line(line: str) -> ReadyRecipe:
    parts = line.split()
    if len(parts) < 4:
        raise ValueError(f"Malformed recipe line in ready text: {line!r}")
    from_kind = parts[0]
    oxidation = float(parts[1])
    random_pickup = int(parts[2])
    random_pickup_trial = int(parts[3])
    modifications: list[ReadyRecipeModification] = []
    for index in range(4, len(parts), 3):
        if index + 2 >= len(parts):
            raise ValueError(
                f"Truncated modification triple in recipe line: {line!r}"
            )
        modifications.append(
            ReadyRecipeModification(
                to=parts[index],
                oxidation=float(parts[index + 1]),
                count=int(parts[index + 2]),
            )
        )
    return ReadyRecipe(
        from_kind=from_kind,
        oxidation=oxidation,
        random_pickup=random_pickup,
        random_pickup_trial=random_pickup_trial,
        modifications=tuple(modifications),
    )


def parse_ready_text(path: str | Path) -> ReadyTextDoc:
    """Parse a legacy `basic_properties_EwaldSolidSolution.ready.txt` file."""

    resolved = Path(path)
    raw_lines = resolved.read_text().splitlines()
    lines = [line for line in (raw.strip() for raw in raw_lines) if line]

    vec_a = vec_b = vec_c = None
    n_atom_config = 0
    atom_config: list[ReadyAtom] = []
    supercell_expansion = (1, 1, 1)
    chop_level = 8
    rg_find_factor = 1
    output_prefix = ""
    n_recipe = 0
    recipes: list[ReadyRecipe] = []

    index = 0
    while index < len(lines):
        line = lines[index]
        if line.startswith("vec_a"):
            vec_a = _parse_vec3(line, "vec_a")
        elif line.startswith("vec_b"):
            vec_b = _parse_vec3(line, "vec_b")
        elif line.startswith("vec_c"):
            vec_c = _parse_vec3(line, "vec_c")
        elif line.startswith("NAtomConfig "):
            n_atom_config = int(line.split()[1])
            if index + 1 >= len(lines) or lines[index + 1] != "AtomConfig":
                raise ValueError(
                    f"Expected `AtomConfig` block after NAtomConfig in {resolved}"
                )
            for offset in range(n_atom_config):
                atom_config.append(_parse_atom_line(lines[index + 2 + offset]))
            index += 2 + n_atom_config
            continue
        elif line.startswith("SupercellExpansion "):
            parts = line.split()
            supercell_expansion = (int(parts[1]), int(parts[2]), int(parts[3]))
        elif line.startswith("ChopLevel "):
            chop_level = int(line.split()[1])
        elif line.startswith("RGFindFactor "):
            rg_find_factor = int(line.split()[1])
        elif line.startswith("OutputPrefix "):
            parts = line.split(maxsplit=1)
            output_prefix = parts[1] if len(parts) > 1 else ""
        elif line.startswith("NRecipe "):
            n_recipe = int(line.split()[1])
            search_index = index + 1
            while (
                search_index < len(lines)
                and lines[search_index] != _RECIPE_BLOCK_HEADER
            ):
                search_index += 1
            if search_index >= len(lines):
                raise ValueError(
                    f"Could not find recipe header in ready text: {resolved}"
                )
            recipe_start = search_index + 2
            for offset in range(n_recipe):
                recipes.append(
                    _parse_recipe_line(lines[recipe_start + offset])
                )
            index = recipe_start + n_recipe
            continue
        index += 1

    if vec_a is None or vec_b is None or vec_c is None:
        raise ValueError(
            f"Ready text {resolved} is missing one or more vec_* lines"
        )

    return ReadyTextDoc(
        path=resolved,
        vec_a=vec_a,
        vec_b=vec_b,
        vec_c=vec_c,
        n_atom_config=n_atom_config,
        atom_config=tuple(atom_config),
        supercell_expansion=supercell_expansion,
        chop_level=chop_level,
        rg_find_factor=rg_find_factor,
        output_prefix=output_prefix,
        recipes=tuple(recipes),
    )


def ready_text_to_native_payload(doc: ReadyTextDoc) -> dict:
    """Convert a parsed ready text doc to the dict shape that
    `compute_swap_loop`, `analyze_search_space`, and
    `decode_candidate_assignment` expect via the native bindings.
    """
    return {
        "lattice": {
            "a": list(doc.vec_a),
            "b": list(doc.vec_b),
            "c": list(doc.vec_c),
        },
        "atoms": [
            {
                "kind": atom.kind,
                "oxidation": atom.oxidation,
                "x": atom.x,
                "y": atom.y,
                "z": atom.z,
            }
            for atom in doc.atom_config
        ],
        "supercell_expansion": list(doc.supercell_expansion),
        "rg_find_factor": doc.rg_find_factor,
        "output_prefix": doc.output_prefix,
        "recipes": [
            {
                "from": recipe.from_kind,
                "oxidation": recipe.oxidation,
                "random_pickup": recipe.random_pickup,
                "random_pickup_trial": recipe.random_pickup_trial,
                "modifications": [
                    {
                        "to": mod.to,
                        "oxidation": mod.oxidation,
                        "count": mod.count,
                    }
                    for mod in recipe.modifications
                ],
            }
            for recipe in doc.recipes
        ],
    }
