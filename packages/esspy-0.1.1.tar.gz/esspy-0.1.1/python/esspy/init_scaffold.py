from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
from typing import Literal

import yaml

from .poscar import load_poscar, write_structure_to_poscar
from .progress import default_logging_block
from .site_grouping import (
    SiteGroupingOptions,
    detect_site_groups,
    site_group_specs_to_yaml,
)
from .supercell_search import build_supercell_structure
from .yaml_comments import annotate_solve_strategy_inline_comments


CompositionMode = Literal["counts", "fractions"]
SymmetryMode = Literal["auto", "p1"]


@dataclass(frozen=True)
class ParsedRecipe:
    from_kind: str
    to: list[str]


@dataclass(frozen=True)
class ParsedSiteGroup:
    name: str
    source_kind: str
    allowed: list[str]


@dataclass(frozen=True)
class InitFromPoscarOptions:
    poscar: Path
    out: Path
    name: str | None
    n_target_sites: int | None
    number_fixed_at: str
    composition: dict[str, float]
    composition_mode: CompositionMode
    charges: dict[str, float]
    recipes: list[ParsedRecipe]
    supercell: tuple[int, int, int] | None = None
    dim_as_matrix: bool = False
    charge_basis: str = "element"
    site_groups: list[ParsedSiteGroup] = field(default_factory=list)
    site_grouping: str | None = None
    site_grouping_symprec: float = 0.1
    site_grouping_angle_tolerance: float = 5.0
    site_grouping_fallback: str = "poscar_kind"
    site_grouping_strict: bool = False
    site_charges: dict[str, float] = field(default_factory=dict)
    allocation_time_budget_sec: int | None = None
    symmetry: SymmetryMode = "auto"
    symprec: float = 1e-5
    write_wyc_path: str = "symmetry.wyc"
    target_cpu_time_sec: int = 100
    n_random_seeds: int = 2000
    max_swap: int = 100
    solve_mode: str = "adaptive"
    solve_effort: str = "medium"
    solve_time_budget_sec: int = 600
    fixed_rg_find_factor: int | None = None
    skip_ewald_evaluation: bool = False
    output_workdir: str | None = None
    include_editing_examples: bool = False
    selection_enabled: bool = True
    selection_mode: str = "auto_top_n"
    selection_limit: int = 20
    selection_pick: str = "lowest"
    selection_interval: str = "left-closed"
    selection_seed: int | None = None
    selection_outdir: str = "selected_structures"
    selection_prefix: str = "selected"


def parse_key_value_map(raw: str, *, value_type: type = float) -> dict[str, float]:
    result: dict[str, float] = {}
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        if "=" not in item:
            raise ValueError(f"Expected KEY=VALUE item, got `{item}`")
        key, value = item.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key or not value:
            raise ValueError(f"Expected KEY=VALUE item, got `{item}`")
        result[key] = value_type(value)
    if not result:
        raise ValueError("Expected at least one KEY=VALUE item")
    return result


def parse_counts_map(raw: str) -> dict[str, int]:
    values = parse_key_value_map(raw, value_type=float)
    counts: dict[str, int] = {}
    for key, value in values.items():
        count = int(value)
        if count != value:
            raise ValueError(f"Composition count for `{key}` must be an integer")
        counts[key] = count
    return counts


def parse_dim(raw: str | list[str] | tuple[str, ...]) -> tuple[int, int, int]:
    if isinstance(raw, str):
        tokens = raw.replace(",", " ").replace("x", " ").replace("X", " ").split()
    else:
        tokens = [str(item) for item in raw]
    if len(tokens) not in (3, 9):
        raise ValueError("Expected --dim with 3 or 9 integers, e.g. 2 1 1")
    values = []
    for index, token in enumerate(tokens):
        value = int(token)
        if len(tokens) == 3 and value <= 0:
            raise ValueError("3-value --dim dimensions must be positive integers")
        values.append(value)
    if len(values) == 3:
        return (values[0], values[1], values[2])
    matrix = (values[0:3], values[3:6], values[6:9])
    off_diagonal = [
        matrix[row][col]
        for row in range(3)
        for col in range(3)
        if row != col
    ]
    diagonal = [matrix[0][0], matrix[1][1], matrix[2][2]]
    if any(value != 0 for value in off_diagonal):
        raise ValueError(
            "General 3x3 --dim matrix is parsed but not yet supported by the "
            "current diagonal supercell engine. Use a diagonal matrix or 3 integers."
        )
    if any(value <= 0 for value in diagonal):
        raise ValueError("Diagonal --dim matrix entries must be positive")
    return (diagonal[0], diagonal[1], diagonal[2])


def dim_input_is_matrix(raw: str | list[str] | tuple[str, ...] | None) -> bool:
    if raw is None:
        return False
    if isinstance(raw, str):
        tokens = raw.replace(",", " ").replace("x", " ").replace("X", " ").split()
    else:
        tokens = [str(item) for item in raw]
    return len(tokens) == 9


def parse_supercell(raw: str | list[str] | tuple[str, ...]) -> tuple[int, int, int]:
    """Deprecated internal alias for pre-`--dim` callers."""
    return parse_dim(raw)


def format_dim_for_yaml(dim: tuple[int, int, int], *, as_matrix: bool = False):
    if as_matrix:
        return [[int(dim[0]), 0, 0], [0, int(dim[1]), 0], [0, 0, int(dim[2])]]
    return [int(dim[0]), int(dim[1]), int(dim[2])]


def parse_recipe(raw: str) -> ParsedRecipe:
    if "->" in raw:
        from_kind, to_raw = raw.split("->", 1)
    elif ":" in raw:
        from_kind, to_raw = raw.split(":", 1)
    elif "=" in raw:
        from_kind, to_raw = raw.split("=", 1)
    else:
        raise ValueError(
            f"Expected recipe format FROM->TO1,TO2 (or FROM:TO1,TO2 / FROM=TO1,TO2), got `{raw}`"
        )
    from_kind = from_kind.strip()
    to = [item.strip() for item in to_raw.split(",") if item.strip()]
    if not from_kind or not to:
        raise ValueError(
            f"Expected recipe format FROM->TO1,TO2 (or FROM:TO1,TO2 / FROM=TO1,TO2), got `{raw}`"
        )
    return ParsedRecipe(from_kind=from_kind, to=to)


def parse_site_group(raw: str) -> ParsedSiteGroup:
    """Parse NAME:SOURCE:ALLOWED1,ALLOWED2 site-group CLI syntax."""
    text = raw.strip()
    if "=" in text and (":" not in text or text.index("=") < text.index(":")):
        name, rest = text.split("=", 1)
    elif ":" in text:
        name, rest = text.split(":", 1)
    else:
        raise ValueError(
            "Expected site-group format NAME:SOURCE:ALLOWED1,ALLOWED2, "
            f"got `{raw}`"
        )
    if "->" in rest:
        source, allowed_raw = rest.split("->", 1)
    elif ":" in rest:
        source, allowed_raw = rest.split(":", 1)
    else:
        raise ValueError(
            "Expected site-group format NAME:SOURCE:ALLOWED1,ALLOWED2, "
            f"got `{raw}`"
        )
    name = name.strip()
    source = source.strip()
    allowed = [item.strip() for item in allowed_raw.split(",") if item.strip()]
    if not name or not source or not allowed:
        raise ValueError(
            "Expected site-group format NAME:SOURCE:ALLOWED1,ALLOWED2, "
            f"got `{raw}`"
        )
    return ParsedSiteGroup(name=name, source_kind=source, allowed=allowed)


def _resolve_target_sites(options: InitFromPoscarOptions, n_base_sites: int) -> int:
    if options.supercell is not None:
        sx, sy, sz = options.supercell
        derived = int(n_base_sites) * int(sx) * int(sy) * int(sz)
        if options.n_target_sites is not None and int(options.n_target_sites) != derived:
            raise ValueError(
                "--n-target-sites does not match --dim: "
                f"{options.n_target_sites} != {n_base_sites}*{sx}*{sy}*{sz} ({derived})"
            )
        return derived
    if options.n_target_sites is None:
        raise ValueError("Either --n-target-sites or --dim is required")
    return int(options.n_target_sites)


def _structure_block_for_options(
    options: InitFromPoscarOptions,
    *,
    poscar_ref: str,
    n_base_sites: int,
    include_legacy_fields: bool,
    title: str | None,
) -> dict:
    _resolve_target_sites(options, n_base_sites)
    block: dict = {"poscar": poscar_ref}
    if title is not None:
        block["title"] = title
    if include_legacy_fields:
        block["source_cell"] = "auto"
    if options.supercell is not None:
        block["dim"] = format_dim_for_yaml(
            options.supercell,
            as_matrix=bool(options.dim_as_matrix),
        )
    else:
        block["n_target_sites"] = int(options.n_target_sites)
    if include_legacy_fields or options.number_fixed_at != "O":
        block["number_fixed_at"] = options.number_fixed_at
    return block


def build_init_from_poscar_yaml(options: InitFromPoscarOptions) -> dict:
    if _wants_site_aware_schema(options):
        return _build_site_aware_yaml(options)

    structure = load_poscar(options.poscar)
    name = options.name or _safe_name(structure.title) or options.poscar.stem
    poscar_ref = _relative_path_for_yaml(options.poscar, options.out.parent)

    structure_block = _structure_block_for_options(
        options,
        poscar_ref=poscar_ref,
        n_base_sites=len(structure.sites),
        include_legacy_fields=True,
        title=name,
    )

    payload: dict = {
        "name": name,
        "structure": structure_block,
        "composition": {
            options.composition_mode: _normalize_composition(
                options.composition,
                options.composition_mode,
            )
        },
        "charges": {kind: float(value) for kind, value in options.charges.items()},
        "recipes": [
            {"from": recipe.from_kind, "to": list(recipe.to)}
            for recipe in options.recipes
        ],
        "symmetry": _symmetry_block(options),
        "guide": _guide_block(options),
        "solve": {
            "strategy": {
                "mode": str(options.solve_mode),
                "time_budget_sec": int(options.solve_time_budget_sec),
                "effort": str(options.solve_effort),
                "swap": {
                    "enabled": True,
                    "max_steps": int(options.max_swap),
                },
            },
        },
        "runtime": {},
        "logging": default_logging_block(),
        "output": {
            "workdir": options.output_workdir or f"run-{name}",
            "prefix": name,
            "guider_filename": "basic_properties_EwaldSolidSolutionGuider.txt",
            "ready_filename": "basic_properties_EwaldSolidSolution.ready.txt",
            "poscar_filename": f"{name}.POSCAR.vasp",
            "best_poscar_filename": "POSCAR_host_best.vasp",
            "worst_poscar_filename": "POSCAR_host_worst.vasp",
            "summary_filename": "summary.json",
            "energy_filename": "host_energies.txt",
            "write_guider": True,
            "write_ready": True,
            "write_poscar": True,
            "write_summary_json": True,
            "selection": {
                "enabled": bool(options.selection_enabled),
                "mode": str(options.selection_mode),
                "interval": str(options.selection_interval),
                "limit": int(options.selection_limit),
                "pick": str(options.selection_pick),
                "seed": options.selection_seed,
                "outdir": str(options.selection_outdir),
                "prefix": str(options.selection_prefix),
                "on_missing": "skip",
                "dedupe": "path-energy",
                "write_index_tsv": True,
            },
        },
    }
    if options.include_editing_examples:
        payload["examples"] = _editing_examples_block(options)
    return payload


def _wants_site_aware_schema(options: InitFromPoscarOptions) -> bool:
    return (
        str(options.charge_basis) == "element_site"
        or bool(options.site_groups)
        or bool(options.site_grouping)
        or options.allocation_time_budget_sec is not None
    )


def _element_mapping_from_recipes(
    structure,
    recipes: list[ParsedRecipe],
) -> dict[str, list[str]]:
    mapping: dict[str, list[str]] = {}
    for site in structure.sites:
        kind = str(site.kind)
        mapping.setdefault(kind, [kind])
    for recipe in recipes:
        mapping[recipe.from_kind] = list(recipe.to)
    return mapping


def _detect_site_grouping_for_init(options: InitFromPoscarOptions, structure):
    if options.site_groups:
        if options.site_grouping:
            raise ValueError(
                "--site-grouping cannot be combined with explicit --site-group entries"
            )
        return None

    mode = options.site_grouping
    if mode is None and (
        str(options.charge_basis) == "element_site"
        or options.allocation_time_budget_sec is not None
    ):
        mode = "poscar_kind"
    if mode is None:
        return None

    return detect_site_groups(
        structure,
        _element_mapping_from_recipes(structure, options.recipes),
        SiteGroupingOptions(
            mode=mode,  # type: ignore[arg-type]
            symprec=float(options.site_grouping_symprec),
            angle_tolerance=float(options.site_grouping_angle_tolerance),
            fallback=str(options.site_grouping_fallback),
            strict=bool(options.site_grouping_strict),
        ),
    )


def _build_site_aware_yaml(options: InitFromPoscarOptions) -> dict:
    structure = load_poscar(options.poscar)
    poscar_ref = _relative_path_for_yaml(options.poscar, options.out.parent)
    site_grouping_result = _detect_site_grouping_for_init(options, structure)
    species_counts: dict[str, int] = {}
    for site in structure.sites:
        species_counts[str(site.kind)] = species_counts.get(str(site.kind), 0) + 1

    composition_block: dict
    if options.composition_mode == "counts":
        composition_block = {kind: int(value) for kind, value in options.composition.items()}
    else:
        composition_block = {
            "fractions": {
                kind: float(value) for kind, value in options.composition.items()
            }
        }

    charge_values = {kind: float(value) for kind, value in options.charges.items()}
    if str(options.charge_basis) == "element_site":
        elements: dict[str, dict] = {
            kind: {"default": float(value)} for kind, value in charge_values.items()
        }
        if site_grouping_result is not None:
            charge_site_groups = [
                (group.name, list(group.allowed)) for group in site_grouping_result.groups
            ]
        else:
            charge_site_groups = [
                (group.name, list(group.allowed)) for group in options.site_groups
            ]
        for group_name, allowed in charge_site_groups:
            for element in allowed:
                if element not in charge_values:
                    continue
                key = f"{element}@{group_name}"
                node = elements.setdefault(element, {"default": float(charge_values[element])})
                by_site = node.setdefault("by_site", {})
                by_site[group_name] = float(
                    options.site_charges.get(key, charge_values[element])
                )
        charges_block: dict = {
            "basis": "element_site",
            "values": charge_values,
            "elements": elements,
        }
    else:
        charges_block = charge_values

    payload: dict = {
        "structure": _structure_block_for_options(
            options,
            poscar_ref=poscar_ref,
            n_base_sites=len(structure.sites),
            include_legacy_fields=False,
            title=None,
        ),
        "composition": composition_block,
        "charges": charges_block,
        "solve": {
            "strategy": {
                "mode": str(options.solve_mode),
                "time_budget_sec": int(options.solve_time_budget_sec),
                "effort": str(options.solve_effort),
                "execution_mode": "quick",
                "swap": {
                    "enabled": True,
                    "max_steps": int(options.max_swap),
                },
            },
        },
        "output": {
            "workdir": options.output_workdir or "run-output",
            "input_filename": "input.yaml",
            "poscar_filename": "POSCAR_host_supercell.vasp",
            "best_poscar_filename": "POSCAR_host_best.vasp",
            "worst_poscar_filename": "POSCAR_host_worst.vasp",
            "summary_filename": "host_summary.json",
            "energy_filename": "host_energies.txt",
            "selection": {
                "enabled": bool(options.selection_enabled),
                "mode": str(options.selection_mode),
                "interval": str(options.selection_interval),
                "limit": int(options.selection_limit),
                "pick": str(options.selection_pick),
                "seed": options.selection_seed,
                "outdir": str(options.selection_outdir),
                "prefix": str(options.selection_prefix),
                "on_missing": "skip",
                "dedupe": "path-energy",
                "write_index_tsv": True,
            },
        },
        "recipes": [
            {"from_kind": recipe.from_kind, "to": list(recipe.to)}
            for recipe in options.recipes
        ],
    }

    if site_grouping_result is not None:
        payload["site_grouping"] = dict(site_grouping_result.metadata)
        if site_grouping_result.warnings:
            payload["site_grouping"]["warnings"] = list(site_grouping_result.warnings)
        payload["site_groups"] = site_group_specs_to_yaml(site_grouping_result.groups)
    elif options.site_groups:
        payload["site_groups"] = {}
        for group in options.site_groups:
            if group.source_kind not in species_counts:
                raise ValueError(
                    f"site group `{group.name}` source_kind `{group.source_kind}` "
                    "is not present in POSCAR"
                )
            payload["site_groups"][group.name] = {
                "source_kind": group.source_kind,
                "count": int(species_counts[group.source_kind]),
                "allowed": list(group.allowed),
            }

    if options.allocation_time_budget_sec is not None:
        allocation = {}
        if options.allocation_time_budget_sec is not None:
            allocation["time_budget_sec"] = int(options.allocation_time_budget_sec)
        payload["allocation"] = allocation

    payload["interstitial"] = None
    return payload


def write_init_from_poscar_yaml(options: InitFromPoscarOptions) -> Path:
    payload = build_init_from_poscar_yaml(options)
    options.out.parent.mkdir(parents=True, exist_ok=True)
    options.out.write_text(render_init_yaml_text(payload), encoding="utf-8")
    return options.out


def _resolved_supercell_for_sposcar(options: InitFromPoscarOptions) -> tuple[int, int, int]:
    if options.supercell is not None:
        return tuple(int(value) for value in options.supercell)
    from .guide_supercell import compute_supercell_expansion

    structure = load_poscar(options.poscar)
    result = compute_supercell_expansion(
        structure.lattice,
        len(structure.sites),
        _resolve_target_sites(options, len(structure.sites)),
    )
    return tuple(int(value) for value in result.expansion)


def write_sposcar_from_init_options(
    options: InitFromPoscarOptions,
    *,
    out_name: str = "SPOSCAR",
) -> Path:
    structure = load_poscar(options.poscar)
    dims = _resolved_supercell_for_sposcar(options)
    matrix = (
        (int(dims[0]), 0, 0),
        (0, int(dims[1]), 0),
        (0, 0, int(dims[2])),
    )
    supercell_structure = build_supercell_structure(
        structure,
        matrix,
        title=f"{structure.title} | SPOSCAR {dims[0]}x{dims[1]}x{dims[2]}",
    )
    path = options.out.parent / out_name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(write_structure_to_poscar(supercell_structure), encoding="utf-8")
    return path


def render_init_yaml_text(payload: dict) -> str:
    """Render generated input YAML in the canonical init/wizard format."""
    yaml_text = yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
    yaml_text = annotate_solve_strategy_inline_comments(yaml_text)
    header = (
        "# Solve strategy guide:\n"
        "#   mode: adaptive | bounded_exhaustive | exhaustive\n"
        "#   time_budget_sec: used when mode=adaptive (default 600)\n"
        "#   effort: low | medium | high | extreme\n"
        "# Optional low-level override:\n"
        "#   solve.advanced.local_enumeration_limit\n"
        "#   solve.advanced.local_enumeration_max_chunks\n\n"
    )
    return header + yaml_text


def _normalize_composition(
    composition: dict[str, float],
    mode: CompositionMode,
) -> dict[str, int | float]:
    if mode == "counts":
        return {kind: int(value) for kind, value in composition.items()}
    return {kind: float(value) for kind, value in composition.items()}


def _symmetry_block(options: InitFromPoscarOptions) -> dict:
    if options.symmetry == "auto":
        return {
            "mode": "auto",
            "backend": "spglib",
            "symprec": float(options.symprec),
            "write_wyc_path": options.write_wyc_path,
        }
    return {
        "mode": "p1",
        "space_group": 1,
    }


def _guide_block(options: InitFromPoscarOptions) -> dict:
    block = {
        "target_cpu_time_sec": int(options.target_cpu_time_sec),
        "n_random_seeds": int(options.n_random_seeds),
        "shell_width": 1.0,
        "wyc_identity_length": 0.2,
        "abc_weights": [2.0, 2.0, 1.0],
        "chop_level": 100,
        "skip_ewald_evaluation": bool(options.skip_ewald_evaluation),
    }
    if options.fixed_rg_find_factor is not None:
        block["fixed_rg_find_factor"] = int(options.fixed_rg_find_factor)
    return block


def _relative_path_for_yaml(path: Path, yaml_dir: Path) -> str:
    resolved_path = path.resolve()
    resolved_yaml_dir = yaml_dir.resolve()
    return os.path.relpath(resolved_path, resolved_yaml_dir)


def _safe_name(title: str) -> str:
    return "_".join(part for part in title.strip().split() if part)


def _editing_examples_block(options: InitFromPoscarOptions) -> dict:
    recipes = [
        {"from": "M", "to": ["Mn", "Cr"]},
        {"from": "M", "to": ["Ni", "Co"]},
    ]
    added_sites = {
        "allow": True,
        "comment": "Example only: copy this `added_sites` block to top-level to activate.",
        "min_distance_between_added_sites": 1.2,
        "add_meshes": [8, 8, 8],
        "kinds": [
            {
                "kind": "H",
                "n_added": 1,
                "oxidation": 1.0,
                "neighbors": [
                    {
                        "kind": "O",
                        "doxidation": 0.0,
                        "dist_min": 0.8,
                        "dist_max": 2.0,
                    }
                ],
            }
        ],
    }
    return {
        "notes": [
            "These are editable templates only.",
            "Copy `recipes` and/or `added_sites` from this block to top-level to use them.",
        ],
        "recipes": recipes,
        "added_sites": added_sites,
    }
