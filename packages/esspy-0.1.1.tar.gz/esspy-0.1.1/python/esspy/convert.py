"""`esspy convert` family helpers.

The `convert` command family is the single legacy-interop entry point
on the CLI. Most of its members are thin wrappers around commands that
already exist elsewhere (`init from-guider`, `guide export-guider`,
`init from-poscar`, `add-sites export-spec`); the only conversion that
needs new code is `ready-to-poscar`, where we have to materialise the
atom block in the ready file as a VASP5 POSCAR.

Keeping the actual conversion logic in this module lets the CLI
handlers stay short and lets the conversions be unit-tested without
going through `argparse`.
"""

from __future__ import annotations

from .ready_text import ReadyAtom, ReadyTextDoc, parse_ready_text


def _format_float(value: float, precision: int = 10) -> str:
    return f"{value:.{precision}f}"


def _group_by_kind(atoms: tuple[ReadyAtom, ...]) -> list[tuple[str, list[ReadyAtom]]]:
    """Group consecutive atoms by `kind` while preserving the order in
    which species first appear, then collect every site of that kind
    together. The legacy ready file already groups atoms by kind in
    POSCAR-friendly order, but reading code that did not preserve that
    order would still produce a valid POSCAR after this pass.
    """
    groups: list[tuple[str, list[ReadyAtom]]] = []
    seen: dict[str, int] = {}
    for atom in atoms:
        if atom.kind not in seen:
            seen[atom.kind] = len(groups)
            groups.append((atom.kind, []))
        groups[seen[atom.kind]][1].append(atom)
    return groups


def ready_to_poscar_text(doc: ReadyTextDoc, *, title: str | None = None) -> str:
    """Render a ready-text doc as a primitive-cell POSCAR string.

    The lattice vectors are taken verbatim from `doc.vec_a/b/c`. The
    fractional coordinates are taken verbatim from each atom row. The
    species / count blocks are derived by grouping per `kind`.

    POSCAR title defaults to `doc.output_prefix` when present; falls
    back to "ready_to_poscar".
    """
    chosen_title = title or doc.output_prefix or "ready_to_poscar"
    groups = _group_by_kind(doc.atom_config)

    lines: list[str] = []
    lines.append(chosen_title)
    lines.append("1.0")
    for vec, name in (
        (doc.vec_a, "vec_a"),
        (doc.vec_b, "vec_b"),
        (doc.vec_c, "vec_c"),
    ):
        lines.append(
            "  "
            + "  ".join(_format_float(component) for component in vec)
        )
    lines.append("  " + "  ".join(kind for kind, _ in groups))
    lines.append("  " + "  ".join(str(len(rows)) for _, rows in groups))
    lines.append("Direct")
    for _, rows in groups:
        for atom in rows:
            lines.append(
                "  "
                + "  ".join(_format_float(c) for c in (atom.x, atom.y, atom.z))
            )
    return "\n".join(lines) + "\n"


def ready_path_to_poscar_text(ready_path, *, title: str | None = None) -> str:
    """Convenience wrapper that reads `ready_path` and returns POSCAR text."""
    doc = parse_ready_text(ready_path)
    return ready_to_poscar_text(doc, title=title)
