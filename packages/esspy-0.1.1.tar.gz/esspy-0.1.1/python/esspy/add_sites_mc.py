from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .add_sites_text import AddedKindSpec
from .models import StructureModel, Lattice, Site
from .native import load_native_module


@dataclass
class AddSitesMonteCarloOptions:
    random_seed: int = 0
    rg_find_factor: int = 1
    chop_level: float = 8.0


@dataclass
class AddSitesMonteCarloResult:
    success: bool
    best_structure: StructureModel
    best_energy: float
    accepted_trials: int
    attempted_trials: int
    log: list[str] = field(default_factory=list)


@dataclass
class AddSitesMonteCarloGlobalResult:
    success: bool
    best_structure: StructureModel
    best_energy: float
    owner_rank: int
    world_size: int
    accepted_trials_total: int
    attempted_trials_total: int
    rank_results: list[dict[str, Any]] = field(default_factory=list)
    log: list[str] = field(default_factory=list)


def _structure_payload(structure: StructureModel | Mapping[str, object]) -> dict:
    if isinstance(structure, StructureModel):
        return {
            "title": structure.title,
            "lattice": {
                "a": list(structure.lattice.a),
                "b": list(structure.lattice.b),
                "c": list(structure.lattice.c),
            },
            "fractional_coordinates": structure.fractional_coordinates,
            "sites": [
                {
                    "kind": site.kind,
                    "x": site.x,
                    "y": site.y,
                    "z": site.z,
                    "oxidation": site.oxidation,
                }
                for site in structure.sites
            ],
        }
    return dict(structure)


def _spec_payload(spec: Mapping[str, object]) -> dict:
    return dict(spec)


def _options_payload(options: AddSitesMonteCarloOptions | Mapping[str, object] | None) -> dict:
    if options is None:
        return {}
    if isinstance(options, AddSitesMonteCarloOptions):
        return {
            "random_seed": options.random_seed,
            "rg_find_factor": options.rg_find_factor,
            "chop_level": options.chop_level,
        }
    return dict(options)


def _structure_from_payload(payload: Mapping[str, object]) -> StructureModel:
    lattice_payload = payload["lattice"]
    assert isinstance(lattice_payload, Mapping)
    sites_payload = payload["sites"]
    assert isinstance(sites_payload, list)
    return StructureModel(
        title=str(payload["title"]),
        lattice=Lattice(
            a=tuple(float(v) for v in lattice_payload["a"]),
            b=tuple(float(v) for v in lattice_payload["b"]),
            c=tuple(float(v) for v in lattice_payload["c"]),
        ),
        sites=[
            Site(
                kind=str(site["kind"]),
                x=float(site["x"]),
                y=float(site["y"]),
                z=float(site["z"]),
                oxidation=float(site["oxidation"]),
            )
            for site in sites_payload
        ],
        fractional_coordinates=bool(payload["fractional_coordinates"]),
    )


def _partition_trials(total_trials: int, world_size: int, rank: int) -> int:
    if world_size <= 0:
        return 0
    base = total_trials // world_size
    remainder = total_trials % world_size
    return base + (1 if rank < remainder else 0)


def _select_global_best(
    gathered: list[dict[str, Any]],
    fallback_structure: StructureModel,
) -> AddSitesMonteCarloGlobalResult:
    successes = [entry for entry in gathered if bool(entry.get("success", False))]
    attempted_total = sum(int(entry.get("attempted_trials", 0)) for entry in gathered)
    accepted_total = sum(int(entry.get("accepted_trials", 0)) for entry in gathered)
    world_size = len(gathered)

    if not successes:
        return AddSitesMonteCarloGlobalResult(
            success=False,
            best_structure=fallback_structure,
            best_energy=float("inf"),
            owner_rank=-1,
            world_size=world_size,
            accepted_trials_total=accepted_total,
            attempted_trials_total=attempted_total,
            rank_results=gathered,
            log=["no_feasible_added_site_configuration"],
        )

    best = min(
        successes,
        key=lambda item: (float(item["best_energy"]), int(item.get("rank", 0))),
    )
    best_structure = _structure_from_payload(best["best_structure"])
    merged_log: list[str] = []
    for entry in gathered:
        rank = int(entry.get("rank", 0))
        for line in entry.get("log", []):
            merged_log.append(f"rank={rank} {line}")

    return AddSitesMonteCarloGlobalResult(
        success=True,
        best_structure=best_structure,
        best_energy=float(best["best_energy"]),
        owner_rank=int(best.get("rank", 0)),
        world_size=world_size,
        accepted_trials_total=accepted_total,
        attempted_trials_total=attempted_total,
        rank_results=gathered,
        log=merged_log,
    )


def run_add_sites_monte_carlo(
    structure: StructureModel | Mapping[str, object],
    spec: Mapping[str, object],
    options: AddSitesMonteCarloOptions | Mapping[str, object] | None = None,
) -> AddSitesMonteCarloResult:
    native = load_native_module()
    payload = native.run_add_sites_monte_carlo(
        _structure_payload(structure),
        _spec_payload(spec),
        _options_payload(options),
    )
    return AddSitesMonteCarloResult(
        success=bool(payload["success"]),
        best_structure=_structure_from_payload(payload["best_structure"]),
        best_energy=float(payload["best_energy"]),
        accepted_trials=int(payload["accepted_trials"]),
        attempted_trials=int(payload["attempted_trials"]),
        log=[str(line) for line in payload["log"]],
    )


def run_add_sites_monte_carlo_mpi(
    structure: StructureModel | Mapping[str, object],
    spec: Mapping[str, object],
    options: AddSitesMonteCarloOptions | Mapping[str, object] | None = None,
    *,
    use_mpi: bool = True,
    comm: Any = None,
) -> AddSitesMonteCarloGlobalResult:
    structure_payload = _structure_payload(structure)
    structure_model = _structure_from_payload(structure_payload)
    spec_payload = _spec_payload(spec)
    options_payload = _options_payload(options)

    if not use_mpi:
        local = run_add_sites_monte_carlo(structure_payload, spec_payload, options_payload)
        gathered = [
            {
                "rank": 0,
                "success": local.success,
                "best_energy": local.best_energy,
                "best_structure": _structure_payload(local.best_structure),
                "accepted_trials": local.accepted_trials,
                "attempted_trials": local.attempted_trials,
                "log": local.log,
            }
        ]
        return _select_global_best(gathered, structure_model)

    if comm is None:
        try:
            from mpi4py import MPI
        except ImportError:
            return run_add_sites_monte_carlo_mpi(
                structure_payload,
                spec_payload,
                options_payload,
                use_mpi=False,
                comm=None,
            )
        comm = MPI.COMM_WORLD

    rank = int(comm.Get_rank())
    world_size = int(comm.Get_size())
    total_trials = abs(int(spec_payload.get("n_monte_carlo", 0)))
    sign = -1 if int(spec_payload.get("n_monte_carlo", 0)) < 0 else 1
    local_trials = _partition_trials(total_trials, world_size, rank)

    local_spec = dict(spec_payload)
    local_spec["n_monte_carlo"] = sign * local_trials

    local_options = dict(options_payload)
    base_seed = int(local_options.get("random_seed", 0))
    local_options["random_seed"] = base_seed + rank * 1_000_003

    local = run_add_sites_monte_carlo(structure_payload, local_spec, local_options)
    local_payload = {
        "rank": rank,
        "success": local.success,
        "best_energy": local.best_energy,
        "best_structure": _structure_payload(local.best_structure),
        "accepted_trials": local.accepted_trials,
        "attempted_trials": local.attempted_trials,
        "log": local.log,
    }
    gathered = list(comm.allgather(local_payload))
    return _select_global_best(gathered, structure_model)
