from __future__ import annotations

from importlib import import_module


def load_native_module():
    try:
        return import_module("_esspy")
    except ModuleNotFoundError as exc:
        try:
            return import_module("esspy._esspy")
        except ModuleNotFoundError:
            raise RuntimeError(
                "Native module `esspy._esspy` is not available. Build or install the package first."
            ) from exc
