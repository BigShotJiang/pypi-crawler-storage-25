"""`esspy init from-guider`: convert a legacy
`basic_properties_EwaldSolidSolutionGuider.txt` plus its companion POSCAR
into a modern editable `input.yaml`.

This is the legacy-migration entry point on the CLI. The output YAML is
designed so that:

- `esspy run input.yaml` produces the same logical run that the legacy
  pair (Guider + ESS) would produce on the original input
- `esspy guide export-guider input.yaml` round-trips back to a guider
  text that is semantically equivalent to the source

The module deliberately reuses the typed parsers in
`esspy.guider_text` so the YAML scaffold is a transparent rewrite of
the legacy file rather than a fresh interpretation.
"""

from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Literal

import yaml

from .guider_text import GuiderTextSpec, parse_guider_text
from .progress import default_logging_block
from .yaml_comments import annotate_solve_strategy_inline_comments


CompositionMode = Literal["fractions", "counts"]


@dataclass(frozen=True)
class InitFromGuiderOptions:
    """Inputs for `init from-guider`.

    `guider_path` points at the legacy guider text file. `out` is the
    `input.yaml` to produce. `composition_mode` decides whether the
    YAML expresses composition as raw target fractions (the legacy
    convention) or as integer counts (`fractions * n_target_sites`).
    """

    guider_path: Path
    out: Path
    name: str | None = None
    composition_mode: CompositionMode = "fractions"
    output_workdir: str | None = None
    poscar_override: Path | None = None
    solve_mode: str = "adaptive"
    solve_effort: str = "medium"
    solve_time_budget_sec: int = 600
    solve_max_swap: int = 100
    selection_enabled: bool = True
    selection_mode: str = "auto_top_n"
    selection_limit: int = 20
    selection_pick: str = "lowest"
    selection_interval: str = "left-closed"
    selection_seed: int | None = None
    selection_outdir: str = "selected_structures"
    selection_prefix: str = "selected"


def build_init_from_guider_yaml(options: InitFromGuiderOptions) -> dict:
    """Materialise the YAML payload for `init from-guider`.

    The returned dictionary is suitable for `yaml.safe_dump` and is the
    same shape that `init from-poscar` and `run` already accept.
    """

    spec = parse_guider_text(options.guider_path)

    poscar_path = _resolve_poscar_path(spec, options)
    poscar_ref = _relative_path_for_yaml(poscar_path, options.out.parent)

    name = options.name or spec.output_prefix or _safe_name_from_path(options.guider_path)

    composition_block = _composition_block(spec, options.composition_mode)
    symmetry_block = _symmetry_block(spec.space_group)
    guide_block = _guide_block_from_spec(spec)

    payload: dict = {
        "name": name,
        "structure": {
            "title": name,
            "poscar": poscar_ref,
            "source_cell": "auto",
            "n_target_sites": int(spec.n_target_sites),
            "number_fixed_at": spec.number_fixed_at,
        },
        "composition": composition_block,
        "charges": {kind: float(value) for kind, value in spec.charges.items()},
        "recipes": [
            {"from": recipe.from_kind, "to": list(recipe.to)}
            for recipe in spec.recipes
        ],
        "symmetry": symmetry_block,
        "guide": guide_block,
        "solve": {
            "strategy": {
                "mode": str(options.solve_mode),
                "time_budget_sec": int(options.solve_time_budget_sec),
                "effort": str(options.solve_effort),
                "swap": {
                    "enabled": True,
                    "max_steps": int(options.solve_max_swap),
                },
            },
        },
        "runtime": {},
        "logging": default_logging_block(),
        "output": {
            "workdir": options.output_workdir or f"run-{name}",
            "prefix": name,
            "guider_filename": "basic_properties_EwaldSolidSolutionGuider.txt",
            "ready_filename": "basic_properties_EwaldSolidSolution.ready.txt",
            "poscar_filename": "POSCAR_host_supercell.vasp",
            "best_poscar_filename": "POSCAR_host_best.vasp",
            "worst_poscar_filename": "POSCAR_host_worst.vasp",
            "summary_filename": "host_summary.json",
            "energy_filename": "host_energies.txt",
            "write_guider": True,
            "write_ready": True,
            "write_poscar": True,
            "write_summary_json": True,
            "selection": {
                "enabled": bool(options.selection_enabled),
                "mode": str(options.selection_mode),
                "interval": str(options.selection_interval),
                "limit": int(options.selection_limit),
                "pick": str(options.selection_pick),
                "seed": options.selection_seed,
                "outdir": str(options.selection_outdir),
                "prefix": str(options.selection_prefix),
                "on_missing": "skip",
                "dedupe": "path-energy",
                "write_index_tsv": True,
            },
        },
        "legacy_source": {
            "guider_text": _relative_path_for_yaml(
                options.guider_path, options.out.parent
            ),
        },
    }
    return payload


def write_init_from_guider_yaml(options: InitFromGuiderOptions) -> Path:
    """Write the YAML payload to disk and return its resolved path."""
    payload = build_init_from_guider_yaml(options)
    options.out.parent.mkdir(parents=True, exist_ok=True)
    yaml_text = yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
    yaml_text = annotate_solve_strategy_inline_comments(yaml_text)
    comment = (
        "# Solve strategy guide:\n"
        "#   mode: adaptive | bounded_exhaustive | exhaustive\n"
        "#   time_budget_sec: used when mode=adaptive (default 600)\n"
        "#   effort: low | medium | high | extreme\n"
        "# Optional low-level override:\n"
        "#   solve.advanced.local_enumeration_limit\n"
        "#   solve.advanced.local_enumeration_max_chunks\n\n"
    )
    options.out.write_text(comment + yaml_text, encoding="utf-8")
    return options.out


def _composition_block(spec: GuiderTextSpec, mode: CompositionMode) -> dict:
    """Mirror legacy guider-text composition into the modern YAML schema.

    Legacy guider text expresses composition as `Target` fractions.
    `init from-guider` exposes both forms but defaults to `fractions` so
    the round-trip back to guider text is exact.
    """

    if mode == "fractions":
        return {
            "fractions": {
                kind: float(value) for kind, value in spec.target_fractions.items()
            }
        }
    counts = {
        kind: int(round(value * spec.n_target_sites))
        for kind, value in spec.target_fractions.items()
    }
    return {"counts": counts}


def _symmetry_block(space_group: int) -> dict:
    """Map the legacy `SpaceGroup` integer to a modern `symmetry:` block.

    `space_group == 1` is the explicit P1 case; anything else triggers
    the modern automatic detection path while preserving the source
    space group as a hint that downstream tooling can verify.
    """

    if space_group == 1:
        return {"mode": "p1", "space_group": 1}
    return {
        "mode": "auto",
        "backend": "spglib",
        "symprec": 1.0e-5,
        "space_group": int(space_group),
        "write_wyc_path": "symmetry.wyc",
    }


def _guide_block_from_spec(spec: GuiderTextSpec) -> dict:
    options = spec.options
    block = {
        "target_cpu_time_sec": int(options.target_cpu_time_sec),
        "n_random_seeds": int(options.n_random_seeds),
        "shell_width": float(options.shell_width),
        "wyc_identity_length": float(options.wyc_identity_length),
        "abc_weights": [float(v) for v in options.abc_weights],
        "chop_level": int(options.chop_level),
        "strict_no_added_sites": bool(options.strict_no_added_sites),
        "skip_rg_optimization": bool(options.skip_rg_optimization),
        "skip_ewald_evaluation": bool(options.skip_ewald_evaluation),
    }
    if options.fixed_rg_find_factor is not None:
        block["fixed_rg_find_factor"] = int(options.fixed_rg_find_factor)
    return block


def _resolve_poscar_path(
    spec: GuiderTextSpec, options: InitFromGuiderOptions
) -> Path:
    """Resolve the companion POSCAR path against the guider file's
    location, allowing the caller to override it explicitly.
    """

    if options.poscar_override is not None:
        return options.poscar_override
    candidate = options.guider_path.parent / spec.poscar_filename
    if not candidate.exists():
        raise FileNotFoundError(
            f"Companion POSCAR `{spec.poscar_filename}` referenced by "
            f"`{options.guider_path}` was not found at `{candidate}`. "
            "Pass --poscar to override the lookup path."
        )
    return candidate


def _relative_path_for_yaml(path: Path, yaml_dir: Path) -> str:
    resolved_path = path.resolve()
    resolved_yaml_dir = yaml_dir.resolve()
    return os.path.relpath(resolved_path, resolved_yaml_dir)


def _safe_name_from_path(path: Path) -> str:
    stem = path.stem
    return "_".join(part for part in stem.strip().split() if part) or stem
