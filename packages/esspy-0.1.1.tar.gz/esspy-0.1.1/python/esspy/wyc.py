from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .models import SymmetryModel, SymmetryOperation
from .native import load_native_module


_Matrix3x4 = tuple[
    tuple[float, float, float, float],
    tuple[float, float, float, float],
    tuple[float, float, float, float],
]


@dataclass
class WycEntry:
    label: str
    matrix: _Matrix3x4


@dataclass
class WycFile:
    header_key: str
    declared_n_wyc: int
    entries: list[WycEntry] = field(default_factory=list)


def _coerce_matrix(rows) -> _Matrix3x4:
    if len(rows) != 3:
        raise ValueError("WYC matrix must have exactly 3 rows")
    coerced: list[tuple[float, float, float, float]] = []
    for row in rows:
        if len(row) != 4:
            raise ValueError("WYC matrix row must have exactly 4 columns")
        coerced.append((float(row[0]), float(row[1]), float(row[2]), float(row[3])))
    return tuple(coerced)  # type: ignore[return-value]


def parse_wyc_file(path: str | Path) -> WycFile:
    """Parse a `<SpaceGroup>.wyc` file via the native adapter."""

    native = load_native_module()
    payload = native.parse_wyc_file(str(path))
    entries = [
        WycEntry(label=str(entry["label"]), matrix=_coerce_matrix(entry["matrix"]))
        for entry in payload["entries"]
    ]
    return WycFile(
        header_key=str(payload["header_key"]),
        declared_n_wyc=int(payload["declared_n_wyc"]),
        entries=entries,
    )


def parse_wyc_file_to_symmetry_model(
    path: str | Path, space_group: int
) -> SymmetryModel:
    """Parse a wyc file directly into a typed SymmetryModel via the native adapter."""

    native = load_native_module()
    payload = native.parse_wyc_file_to_symmetry_model(str(path), int(space_group))
    operations = [
        SymmetryOperation(matrix=_coerce_matrix(matrix))
        for matrix in payload["wyc_operations"]
    ]
    return SymmetryModel(
        space_group=int(payload["space_group"]),
        wyc_operations=operations,
        from_spglib=bool(payload["from_spglib"]),
    )
