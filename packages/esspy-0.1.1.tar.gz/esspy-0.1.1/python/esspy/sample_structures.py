from __future__ import annotations

import random
from dataclasses import replace
from pathlib import Path
import tempfile
import yaml
from collections import defaultdict

from .models import Lattice, ReadyAtom, ReadyModel, RunInput, Site, StructureModel
from .poscar import write_structure_to_poscar
from .workflow import ESSWorkflow
from .allocation_optimize import optimize_site_allocation


def _expand_ready_atoms(ready: ReadyModel) -> tuple[Lattice, list[ReadyAtom]]:
    sx, sy, sz = ready.supercell_expansion
    if sx <= 0 or sy <= 0 or sz <= 0:
        raise ValueError(f"Invalid supercell expansion: {ready.supercell_expansion}")

    expanded_lattice = Lattice(
        a=(ready.lattice.a[0] * sx, ready.lattice.a[1] * sx, ready.lattice.a[2] * sx),
        b=(ready.lattice.b[0] * sy, ready.lattice.b[1] * sy, ready.lattice.b[2] * sy),
        c=(ready.lattice.c[0] * sz, ready.lattice.c[1] * sz, ready.lattice.c[2] * sz),
    )
    expanded_atoms: list[ReadyAtom] = []
    for ix in range(sx):
        for iy in range(sy):
            for iz in range(sz):
                for atom in ready.atoms:
                    expanded_atoms.append(
                        ReadyAtom(
                            kind=atom.kind,
                            oxidation=atom.oxidation,
                            x=(atom.x + float(ix)) / float(sx),
                            y=(atom.y + float(iy)) / float(sy),
                            z=(atom.z + float(iz)) / float(sz),
                        )
                    )
    return expanded_lattice, expanded_atoms


def sample_structure_from_ready(ready: ReadyModel, rng: random.Random) -> StructureModel:
    expanded_lattice, expanded = _expand_ready_atoms(ready)
    source_indices: dict[str, list[int]] = {}
    for index, atom in enumerate(expanded):
        source_indices.setdefault(atom.kind, []).append(index)

    sampled_atoms: list[ReadyAtom] = [replace(atom) for atom in expanded]

    for recipe in ready.recipes:
        if recipe.random_pickup <= 0:
            continue
        candidates = source_indices.get(recipe.from_kind, [])
        if recipe.random_pickup > len(candidates):
            raise ValueError(
                f"Recipe random_pickup exceeds available sites: {recipe.from_kind} "
                f"pickup={recipe.random_pickup} available={len(candidates)}"
            )

        if recipe.random_pickup == len(candidates):
            chosen = list(candidates)
        else:
            chosen = rng.sample(candidates, recipe.random_pickup)

        assignments: list[tuple[str, float]] = []
        for mod in recipe.modifications:
            if mod.count <= 0:
                continue
            assignments.extend([(mod.to, mod.oxidation)] * mod.count)

        if len(assignments) > len(chosen):
            raise ValueError(
                f"Recipe assignments exceed random_pickup: {recipe.from_kind} "
                f"assigned={len(assignments)} pickup={len(chosen)}"
            )

        if len(assignments) < len(chosen):
            assignments.extend(
                [(recipe.from_kind, recipe.oxidation)] * (len(chosen) - len(assignments))
            )

        rng.shuffle(assignments)
        for atom_index, (kind, oxidation) in zip(chosen, assignments):
            sampled_atoms[atom_index].kind = kind
            sampled_atoms[atom_index].oxidation = oxidation

    return StructureModel(
        title=ready.output_prefix or "sample",
        lattice=expanded_lattice,
        sites=[
            Site(kind=a.kind, oxidation=a.oxidation, x=a.x, y=a.y, z=a.z)
            for a in sampled_atoms
        ],
        fractional_coordinates=True,
    )


def _format_float(value: float, precision: int = 10) -> str:
    return f"{value:.{precision}f}"


def _write_structure_to_poscar_with_site_labels(
    structure: StructureModel,
    *,
    site_labels: list[str],
    title: str | None = None,
    species_order: list[str] | None = None,
) -> str:
    chosen_title = title or structure.title or "structure"
    if len(site_labels) != len(structure.sites):
        raise ValueError(
            f"site_labels length mismatch: {len(site_labels)} != {len(structure.sites)}"
        )

    grouped: dict[str, list[tuple[Site, str]]] = {}
    first_seen: list[str] = []
    for site, s_label in zip(structure.sites, site_labels):
        if site.kind not in grouped:
            grouped[site.kind] = []
            first_seen.append(site.kind)
        grouped[site.kind].append((site, s_label))

    ordered_kinds: list[str] = []
    if species_order:
        for kind in species_order:
            if kind in grouped and kind not in ordered_kinds:
                ordered_kinds.append(kind)
    for kind in first_seen:
        if kind not in ordered_kinds:
            ordered_kinds.append(kind)

    lines: list[str] = []
    lines.append(chosen_title)
    lines.append("1.0")
    for vec in (structure.lattice.a, structure.lattice.b, structure.lattice.c):
        lines.append("  " + "  ".join(_format_float(component) for component in vec))
    lines.append("  " + "  ".join(ordered_kinds))
    lines.append("  " + "  ".join(str(len(grouped[kind])) for kind in ordered_kinds))
    lines.append("Direct" if structure.fractional_coordinates else "Cartesian")

    for kind in ordered_kinds:
        for site, s_label in grouped[kind]:
            coord = "  " + "  ".join(_format_float(c) for c in (site.x, site.y, site.z))
            lines.append(f"{coord}  # {s_label}")
    return "\n".join(lines) + "\n"


def _normalized_site_group_label(group_name: str, ordinal: int) -> str:
    try:
        import re

        match = re.match(r"^site-?0*(\d+)$", str(group_name).strip())
    except Exception:
        match = None
    if match:
        return f"site-{int(match.group(1)):03d}"
    return f"site-{int(ordinal):03d}"


def _site_label_lookup_keys(site_label: str) -> list[str]:
    keys = [str(site_label)]
    try:
        import re

        match = re.match(r"^site-?0*(\d+)$", str(site_label).strip())
    except Exception:
        match = None
    if match:
        idx = int(match.group(1))
        keys.extend([f"site{idx}", f"site-{idx:03d}", f"site{idx:03d}"])
    out: list[str] = []
    for key in keys:
        if key not in out:
            out.append(key)
    return out


def _site_group_labels_for_atoms(
    effective_yaml: str | Path,
    expanded_atoms: list[ReadyAtom],
    *,
    base_site_count: int | None = None,
) -> list[str]:
    payload = yaml.safe_load(Path(effective_yaml).read_text()) or {}
    source_to_group: dict[str, str] = {}
    group_to_label: dict[str, str] = {}
    if isinstance(payload, dict):
        sg = payload.get("site_groups")
        if isinstance(sg, dict):
            for ordinal, (group_name, info) in enumerate(sg.items(), 1):
                gname = str(group_name)
                group_to_label[gname] = _normalized_site_group_label(gname, ordinal)
                if not isinstance(info, dict):
                    continue
                source = info.get("source_kind")
                if source is None:
                    continue
                source_to_group[str(source)] = str(group_name)

            any_explicit_indices = any(
                isinstance(info, dict) and "site_indices" in info
                for info in sg.values()
            )
            if any_explicit_indices:
                raw_n_sites = None
                grouping = payload.get("site_grouping")
                if isinstance(grouping, dict):
                    source = grouping.get("source")
                    if isinstance(source, dict):
                        raw_n_sites = source.get("n_sites")
                inferred_n_sites = base_site_count
                if inferred_n_sites is None and raw_n_sites is not None:
                    inferred_n_sites = int(raw_n_sites)
                if inferred_n_sites is None:
                    max_index = -1
                    for info in sg.values():
                        if not isinstance(info, dict):
                            continue
                        indices = info.get("site_indices", [])
                        if isinstance(indices, list) and indices:
                            max_index = max(max_index, max(int(v) for v in indices))
                    inferred_n_sites = max_index + 1
                if inferred_n_sites <= 0:
                    raise ValueError("Cannot infer base site count for explicit site_indices")
                if raw_n_sites is not None and base_site_count is not None:
                    if int(raw_n_sites) != int(base_site_count):
                        raise ValueError(
                            "site_grouping.source.n_sites does not match ready base atom count: "
                            f"{raw_n_sites} != {base_site_count}"
                        )

                base_labels: list[str | None] = [None] * int(inferred_n_sites)
                for group_name, info in sg.items():
                    if not isinstance(info, dict):
                        continue
                    indices = info.get("site_indices", [])
                    if not isinstance(indices, list):
                        raise ValueError(f"site_groups.{group_name}.site_indices must be a list")
                    group_label = group_to_label[str(group_name)]
                    for raw_index in indices:
                        site_index = int(raw_index)
                        if site_index < 0 or site_index >= len(base_labels):
                            raise ValueError(
                                f"site index {site_index} is out of range for explicit site labels"
                            )
                        if base_labels[site_index] is not None:
                            raise ValueError(f"site index {site_index} has duplicate site labels")
                        base_labels[site_index] = group_label

                # For legacy partial site_groups, leave unlisted sites grouped by source kind.
                for base_index, label in enumerate(base_labels):
                    if label is not None:
                        continue
                    if base_index < len(expanded_atoms):
                        kind = str(expanded_atoms[base_index].kind)
                        group = source_to_group.get(kind)
                        base_labels[base_index] = (
                            group_to_label.get(group, kind) if group is not None else kind
                        )
                    else:
                        base_labels[base_index] = f"site-{base_index + 1:03d}"

                return [
                    str(base_labels[index % len(base_labels)])
                    for index in range(len(expanded_atoms))
                ]

    # Normalize group names to user-facing fixed labels: site-001, site-002, ...
    normalized: dict[str, str] = {}
    ordered_groups: list[str] = []
    for atom in expanded_atoms:
        g = source_to_group.get(atom.kind, atom.kind)
        if g not in normalized:
            ordered_groups.append(g)
            normalized[g] = group_to_label.get(
                g,
                _normalized_site_group_label(g, len(ordered_groups)),
            )
    return [normalized[source_to_group.get(atom.kind, atom.kind)] for atom in expanded_atoms]


def _composition_species_order(config: RunInput) -> list[str]:
    return [entry.kind for entry in config.guide.composition.entries]


def _composition_species_order_from_yaml(yaml_path: str | Path, fallback: list[str]) -> list[str]:
    try:
        payload = yaml.safe_load(Path(yaml_path).read_text()) or {}
    except Exception:
        return fallback
    if not isinstance(payload, dict):
        return fallback
    comp = payload.get("composition")
    if not isinstance(comp, dict):
        return fallback
    ordered = [str(k) for k in comp.keys() if str(k) != "fractions"]
    if not ordered:
        return fallback
    # Keep only species that actually exist in the generated structure, preserving YAML order.
    fallback_set = set(fallback)
    filtered = [k for k in ordered if k in fallback_set]
    # Append any missing kinds from fallback to stay safe.
    for k in fallback:
        if k not in filtered:
            filtered.append(k)
    return filtered


def _charge_metadata_title(title: str, config: RunInput, ready: ReadyModel) -> str:
    charges = {entry.kind: entry.oxidation for entry in config.guide.charges.values}
    charge_str = " ".join(f"{kind}={charges[kind]:g}" for kind in sorted(charges))
    return f"{title} | charges: {charge_str} | RG={ready.rg_find_factor}"


def _resolve_effective_yaml_for_sampling(yaml_path: str | Path) -> Path:
    input_path = Path(yaml_path).resolve()
    payload = yaml.safe_load(input_path.read_text()) or {}
    if not isinstance(payload, dict):
        return input_path
    if payload.get("composition_by_site") is not None:
        return input_path
    allocation = payload.get("allocation")
    has_site_groups = isinstance(payload.get("site_groups"), dict) and bool(payload.get("site_groups"))
    if not isinstance(allocation, dict):
        allocation = {"mode": "optimize_by_ewald"} if has_site_groups else {"mode": "manual"}
    if str(allocation.get("mode", "manual")).strip() != "optimize_by_ewald":
        return input_path

    number_target = allocation.get("number_target", None)
    if number_target is None:
        number_target = allocation.get("n_alloc_feasible_target", None)
    if number_target is None:
        number_target = allocation.get("n_alloc", 20)
    number_target = max(1, int(number_target))
    n_alloc = int(allocation.get("n_alloc", number_target))
    n_alloc_feasible_target = allocation.get("n_alloc_feasible_target", number_target)
    n_alloc_feasible_target = None if n_alloc_feasible_target is None else int(n_alloc_feasible_target)
    n_alloc_max_requested = allocation.get("n_alloc_max_requested", None)
    n_alloc_max_requested = None if n_alloc_max_requested is None else int(n_alloc_max_requested)
    seed = allocation.get("seed", 0)
    seed = None if seed is None else int(seed)
    score_mode = str(allocation.get("score_mode", "ewald"))
    metric = str(allocation.get("metric", "topk_mean"))
    topk = int(allocation.get("topk", 5))
    ewald_samples = int(allocation.get("ewald_samples", 12))
    guide_gate = bool(allocation.get("guide_gate", True))

    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".sitewise.auto.yaml",
        prefix="esspy_sample_",
        delete=False,
    ) as tf:
        temp_yaml_path = Path(tf.name)
    table_path = temp_yaml_path.with_suffix(".allocation_table.json")
    optimize_site_allocation(
        input_yaml=input_path,
        out_yaml=temp_yaml_path,
        out_table=table_path,
        preferences=None,
        n_alloc=n_alloc,
        n_alloc_feasible_target=n_alloc_feasible_target,
        n_alloc_max_requested=n_alloc_max_requested,
        seed=seed,
        dry_run=False,
        score_mode=score_mode,
        ewald_samples=ewald_samples,
        guide_gate=guide_gate,
        metric=metric,
        topk=topk,
    )
    try:
        table_path.unlink(missing_ok=True)
    except Exception:
        pass
    return temp_yaml_path


def _needs_auto_sitewise_sampling(yaml_path: str | Path) -> bool:
    payload = yaml.safe_load(Path(yaml_path).read_text()) or {}
    if not isinstance(payload, dict):
        return False
    if payload.get("composition_by_site") is not None:
        return False
    has_site_groups = isinstance(payload.get("site_groups"), dict) and bool(payload.get("site_groups"))
    if not has_site_groups:
        return False
    allocation = payload.get("allocation")
    if not isinstance(allocation, dict):
        return True
    raw_mode = allocation.get("mode")
    if raw_mode is None:
        # Current wizard/init YAMLs use `allocation.time_budget_sec` without a
        # mode key. For sampling, that still means global composition must be
        # distributed over site groups before atom placement.
        return True
    mode = str(raw_mode).strip()
    return mode not in {"manual", "fixed_by_input", "fixed", "none", "off"}


def _sample_structure_from_sitewise_counts(
    expanded_lattice: Lattice,
    expanded_atoms: list[ReadyAtom],
    *,
    site_labels: list[str],
    composition_by_site: dict,
    charges_by_element: dict[str, float],
    rng: random.Random,
) -> StructureModel:
    if len(site_labels) != len(expanded_atoms):
        raise ValueError("site labels / atoms length mismatch")
    group_indices: dict[str, list[int]] = defaultdict(list)
    for i, s in enumerate(site_labels):
        group_indices[s].append(i)

    sampled_atoms: list[ReadyAtom] = [replace(a) for a in expanded_atoms]
    for site_label, indices in group_indices.items():
        row = {}
        for key in _site_label_lookup_keys(site_label):
            if key in composition_by_site:
                row = composition_by_site.get(key, {})
                break
        if not isinstance(row, dict):
            row = {}
        assigns: list[str] = []
        for elem, count in row.items():
            c = int(count)
            if c > 0:
                assigns.extend([str(elem)] * c)
        if len(assigns) != len(indices):
            raise ValueError(
                f"composition_by_site mismatch at {site_label}: assigned={len(assigns)} slots={len(indices)}"
            )
        rng.shuffle(assigns)
        for atom_idx, elem in zip(indices, assigns):
            sampled_atoms[atom_idx].kind = elem
            sampled_atoms[atom_idx].oxidation = float(
                charges_by_element.get(elem, sampled_atoms[atom_idx].oxidation)
            )

    return StructureModel(
        title="sample",
        lattice=expanded_lattice,
        sites=[
            Site(kind=a.kind, oxidation=a.oxidation, x=a.x, y=a.y, z=a.z)
            for a in sampled_atoms
        ],
        fractional_coordinates=True,
    )


def _random_sitewise_counts_from_global(
    *,
    composition: dict[str, int],
    site_allowed: dict[str, set[str]],
    site_capacity: dict[str, int],
    rng: random.Random,
) -> dict[str, dict[str, int]]:
    by_site: dict[str, dict[str, int]] = {s: {} for s in site_capacity.keys()}
    remaining_cap = {s: int(c) for s, c in site_capacity.items()}

    # Constrained species first.
    species = sorted(composition.keys(), key=lambda e: len([s for s, a in site_allowed.items() if e in a]))
    for elem in species:
        need = int(composition.get(elem, 0))
        if need <= 0:
            continue
        eligible = [s for s, allowed in site_allowed.items() if elem in allowed]
        if not eligible:
            raise ValueError(f"No eligible site-group for element `{elem}`")
        if sum(remaining_cap[s] for s in eligible) < need:
            raise ValueError(f"Insufficient capacity for `{elem}`: need={need}")

        for _ in range(need):
            avail = [s for s in eligible if remaining_cap[s] > 0]
            if not avail:
                raise ValueError(f"Capacity exhausted while assigning `{elem}`")
            weights = [remaining_cap[s] for s in avail]
            total_w = float(sum(weights))
            r = rng.random() * total_w
            acc = 0.0
            chosen = avail[-1]
            for s, w in zip(avail, weights):
                acc += float(w)
                if r <= acc:
                    chosen = s
                    break
            by_site[chosen][elem] = by_site[chosen].get(elem, 0) + 1
            remaining_cap[chosen] -= 1

    spare = sum(remaining_cap.values())
    if spare != 0:
        raise ValueError(f"Unfilled site capacity remains: {spare}")
    return by_site


def write_random_samples_from_yaml(
    yaml_path: str | Path,
    *,
    n_samples: int,
    outdir: str | Path,
    prefix: str = "sample",
    seed: int | None = None,
) -> list[Path]:
    if n_samples <= 0:
        raise ValueError("n_samples must be >= 1")

    rng = random.Random(seed)
    base_yaml = Path(yaml_path).resolve()
    samplewise_auto_site = _needs_auto_sitewise_sampling(base_yaml)

    effective_yaml = (
        base_yaml if samplewise_auto_site else _resolve_effective_yaml_for_sampling(base_yaml)
    )
    workflow = ESSWorkflow.from_yaml(str(effective_yaml))
    guide_result = workflow.guide()
    ready = guide_result.ready
    species_order = _composition_species_order(workflow.config)
    species_order = _composition_species_order_from_yaml(effective_yaml, species_order)
    _, expanded_atoms = _expand_ready_atoms(ready)
    base_site_count = len(ready.atoms)
    site_group_labels = _site_group_labels_for_atoms(
        effective_yaml,
        expanded_atoms,
        base_site_count=base_site_count,
    )
    expanded_lattice, expanded_atoms_base = _expand_ready_atoms(ready)
    base_payload = yaml.safe_load(base_yaml.read_text()) or {}
    charges_by_element = {entry.kind: entry.oxidation for entry in workflow.config.guide.charges.values}
    composition_counts = {entry.kind: int(entry.count) for entry in workflow.config.guide.composition.entries}

    site_labels_base = _site_group_labels_for_atoms(
        base_yaml,
        expanded_atoms_base,
        base_site_count=base_site_count,
    )
    site_capacity: dict[str, int] = {}
    for s in site_labels_base:
        site_capacity[s] = site_capacity.get(s, 0) + 1
    site_allowed: dict[str, set[str]] = {}
    if isinstance(base_payload, dict) and isinstance(base_payload.get("site_groups"), dict):
        for gname, info in base_payload["site_groups"].items():
            if not isinstance(info, dict):
                continue
            s_label = _normalized_site_group_label(str(gname), len(site_allowed) + 1)
            allowed = info.get("allowed", [])
            if isinstance(allowed, list):
                site_allowed[s_label] = set(str(x) for x in allowed)
    for s in site_capacity.keys():
        site_allowed.setdefault(s, set(composition_counts.keys()))

    output_dir = Path(outdir)
    output_dir.mkdir(parents=True, exist_ok=True)

    written: list[Path] = []
    width = max(3, len(str(n_samples)))
    for index in range(1, n_samples + 1):
        current_site_labels = site_group_labels
        if samplewise_auto_site:
            normalized_by_site = _random_sitewise_counts_from_global(
                composition=composition_counts,
                site_allowed=site_allowed,
                site_capacity=site_capacity,
                rng=rng,
            )
            current_site_labels = site_labels_base
            structure = _sample_structure_from_sitewise_counts(
                expanded_lattice,
                expanded_atoms_base,
                site_labels=current_site_labels,
                composition_by_site=normalized_by_site,
                charges_by_element=charges_by_element,
                rng=rng,
            )
        else:
            structure = sample_structure_from_ready(ready, rng)
        title = f"{prefix}-{index:0{width}d}"
        if len(current_site_labels) != len(structure.sites):
            raise ValueError("site group label count mismatch")
        text = _write_structure_to_poscar_with_site_labels(
            structure,
            site_labels=current_site_labels,
            title=_charge_metadata_title(title, workflow.config, ready),
            species_order=species_order,
        )
        path = output_dir / f"{prefix}-{index:0{width}d}.vasp"
        path.write_text(text)
        written.append(path)

    return written
