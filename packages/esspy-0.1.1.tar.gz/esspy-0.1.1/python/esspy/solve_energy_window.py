from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import shutil


@dataclass(frozen=True)
class SolverEnergyEntry:
    structure_path: Path
    energy: float
    source_line: str


def _try_parse_line_as_entry(
    line: str,
    *,
    base_dir: Path,
) -> SolverEnergyEntry | None:
    raw = line.strip()
    if not raw:
        return None
    if raw.startswith("="):
        return None
    if raw.startswith("global_"):
        return None
    if raw.startswith("SWAP:"):
        return None
    if raw.startswith("SWAP_at_pr_id="):
        return None
    if raw.startswith("CPU_time_so_far="):
        return None

    tokens = raw.split("\t")
    if len(tokens) < 2:
        tokens = raw.split()
        if len(tokens) < 2:
            return None
        path_token = tokens[0]
        energy_token = tokens[1]
    else:
        path_token = tokens[0].strip()
        energy_token = tokens[1].strip()

    try:
        energy = float(energy_token)
    except ValueError:
        return None

    if not path_token:
        return None
    if path_token == "Tips":
        return None

    candidate = Path(path_token)
    if not candidate.is_absolute():
        candidate = (base_dir / candidate).resolve()
    else:
        candidate = candidate.resolve()

    if not candidate.exists():
        return None
    if not candidate.is_file():
        return None

    return SolverEnergyEntry(
        structure_path=candidate,
        energy=energy,
        source_line=raw,
    )


def parse_solver_energy_entries(
    solver_text_path: str | Path,
) -> list[SolverEnergyEntry]:
    path = Path(solver_text_path).resolve()
    lines = path.read_text(errors="ignore").splitlines()
    base_dir = path.parent
    parsed: list[SolverEnergyEntry] = []
    seen: set[tuple[Path, float]] = set()
    for line in lines:
        entry = _try_parse_line_as_entry(line, base_dir=base_dir)
        if entry is None:
            continue
        key = (entry.structure_path, entry.energy)
        if key in seen:
            continue
        seen.add(key)
        parsed.append(entry)
    return parsed


def filter_energy_window(
    entries: list[SolverEnergyEntry],
    *,
    energy_min: float,
    energy_max: float,
) -> list[SolverEnergyEntry]:
    return [
        entry
        for entry in entries
        if energy_min <= entry.energy < energy_max
    ]


def copy_energy_window_structures(
    entries: list[SolverEnergyEntry],
    *,
    outdir: str | Path,
    prefix: str = "selected",
) -> list[Path]:
    target_dir = Path(outdir).resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for index, entry in enumerate(entries, start=1):
        dst = target_dir / f"{prefix}-{index:04d}.vasp"
        shutil.copy2(entry.structure_path, dst)
        written.append(dst)
    return written
