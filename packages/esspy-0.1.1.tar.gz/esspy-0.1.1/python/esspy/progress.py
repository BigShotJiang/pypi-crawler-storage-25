from __future__ import annotations

from dataclasses import replace
from datetime import datetime
import json
import math
from pathlib import Path
import sys
import time
from typing import Any

from .models import LoggingOptions


def default_logging_block() -> dict[str, bool | float]:
    options = LoggingOptions()
    return {
        "console": options.console,
        "file": options.file,
        "progress_jsonl": options.progress_jsonl,
        "per_rank_logs": options.per_rank_logs,
        "interval_sec": options.interval_sec,
        "write_best_so_far": options.write_best_so_far,
    }


class ProgressReporter:
    def __init__(
        self,
        workdir: Path,
        options: LoggingOptions,
        *,
        rank: int = 0,
        world_size: int = 1,
        quiet: bool = False,
        json_stdout: bool = False,
        disabled: bool = False,
        log_file: str | Path | None = None,
    ) -> None:
        self.workdir = Path(workdir)
        self.options = options
        self.rank = rank
        self.world_size = world_size
        self.quiet = quiet
        self.json_stdout = json_stdout
        self.disabled = disabled
        self.started_at = time.monotonic()
        self.last_console_at = 0.0
        self.last_console_at_per_stage: dict[str, float] = {}
        self.last_record_at_per_stage: dict[str, float] = {}
        self.record_seen_stages: set[str] = set()
        self.console_seen_stages: set[str] = set()
        self._last_chunk_signature: tuple[Any, Any] | None = None
        self.log_path = Path(log_file) if log_file is not None else self.workdir / "summary.log"
        self.progress_jsonl_path = self.workdir / "logs" / "progress.jsonl"
        self.progress_latest_path = self.workdir / "logs" / "progress.latest.json"
        self.rank_log_path = self.workdir / "logs" / f"rank-{rank:03d}.log"

    @classmethod
    def with_overrides(
        cls,
        workdir: Path,
        options: LoggingOptions,
        *,
        rank: int = 0,
        world_size: int = 1,
        quiet: bool = False,
        json_stdout: bool = False,
        disabled: bool = False,
        interval_sec: float | None = None,
        log_file: str | Path | None = None,
    ) -> "ProgressReporter":
        if interval_sec is not None:
            options = replace(options, interval_sec=float(interval_sec))
        return cls(
            workdir,
            options,
            rank=rank,
            world_size=world_size,
            quiet=quiet,
            json_stdout=json_stdout,
            disabled=disabled,
            log_file=log_file,
        )

    def emit(self, stage: str, message: str = "", **fields: Any) -> None:
        if self.disabled:
            return
        if not self._should_record(stage, fields):
            return
        event = self._event(stage, message, fields)
        line = self._format_human(event)
        if self._should_console(stage):
            print(line, file=sys.stderr if self.json_stdout else sys.stdout, flush=True)
            now = time.monotonic()
            self.last_console_at = now
            if stage in {"solve.chunk", "solve.nested", "solve.adaptive_stride"}:
                self.last_console_at_per_stage[stage] = now
            self.console_seen_stages.add(stage)
        if self.options.file and self.rank == 0:
            self._append_line(self.log_path, line)
        if self.options.progress_jsonl and self.rank == 0:
            self._append_line(self.progress_jsonl_path, json.dumps(event, sort_keys=True))
            self.progress_latest_path.write_text(
                json.dumps(event, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        if self.options.per_rank_logs:
            self._append_line(self.rank_log_path, line)

    def _should_record(self, stage: str, fields: dict[str, Any] | None = None) -> bool:
        if stage not in {"solve.nested", "solve.chunk"}:
            return True
        now = time.monotonic()
        if stage == "solve.chunk":
            fields = fields or {}
            signature = (
                fields.get("processed_candidates"),
                fields.get("local_e_min"),
            )
            if stage not in self.record_seen_stages:
                self.record_seen_stages.add(stage)
                self.last_record_at_per_stage[stage] = now
                self._last_chunk_signature = signature
                return True
            if signature != self._last_chunk_signature:
                self.last_record_at_per_stage[stage] = now
                self._last_chunk_signature = signature
                return True
            last_at = self.last_record_at_per_stage.get(stage, 0.0)
            if (now - last_at) >= self.options.interval_sec:
                self.last_record_at_per_stage[stage] = now
                return True
            return False
        if stage not in self.record_seen_stages:
            self.record_seen_stages.add(stage)
            self.last_record_at_per_stage[stage] = now
            return True
        last_at = self.last_record_at_per_stage.get(stage, 0.0)
        if (now - last_at) >= self.options.interval_sec:
            self.last_record_at_per_stage[stage] = now
            return True
        return False

    def output_paths(self) -> dict[str, str]:
        if self.disabled or self.rank != 0:
            return {}
        paths: dict[str, str] = {}
        if self.options.file:
            paths["log"] = str(self.log_path)
        if self.options.progress_jsonl:
            paths["progress_jsonl"] = str(self.progress_jsonl_path)
            paths["progress_latest"] = str(self.progress_latest_path)
        return paths

    def _event(self, stage: str, message: str, fields: dict[str, Any]) -> dict[str, Any]:
        event = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "elapsed_sec": round(time.monotonic() - self.started_at, 3),
            "stage": stage,
            "message": message,
            "rank": self.rank,
            "world_size": self.world_size,
            **{key: _jsonable(value) for key, value in fields.items()},
        }
        event.update(_eta_fields(event))
        return event

    def _should_console(self, stage: str) -> bool:
        if self.rank != 0 or not self.options.console or self.quiet:
            return False
        if self.json_stdout:
            return False
        # Hide solve.chunk.started (too verbose)
        if stage == "solve.chunk.started":
            return False
        if (
            stage.endswith(".started")
            or stage.endswith(".done")
            or stage in {
                "run.started",
                "run.done",
                "run.charge_model_override",
                "allocation.coupled_ready",
            }
        ):
            return True
        # solve.plan and solve.partition: first appearance only (informational)
        if stage in {"solve.plan", "solve.partition"}:
            return stage not in self.console_seen_stages
        # solve.chunk, solve.nested, solve.adaptive_stride: every interval_sec (progress)
        if stage in {"solve.chunk", "solve.nested", "solve.adaptive_stride"}:
            if stage not in self.console_seen_stages:
                return True
            last_at = self.last_console_at_per_stage.get(stage, 0.0)
            return (time.monotonic() - last_at) >= self.options.interval_sec
        # Default: interval-based logging
        return (time.monotonic() - self.last_console_at) >= self.options.interval_sec

    @staticmethod
    def _format_human(event: dict[str, Any]) -> str:
        friendly = _friendly_event_message(event)
        if friendly is not None:
            return friendly
        fields = [
            f"{key}={value}"
            for key, value in event.items()
            if key not in {"timestamp", "stage", "message", "rank", "world_size"}
            and value not in (None, "")
        ]
        suffix = f" | {' | '.join(fields)}" if fields else ""
        message = f" {event['message']}" if event["message"] else ""
        return f"[{event['timestamp']}] {event['stage']}:{message}{suffix}"

    @staticmethod
    def _append_line(path: Path, line: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(line)
            handle.write("\n")


def _jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    return str(value)


def _eta_fields(event: dict[str, Any]) -> dict[str, Any]:
    processed = _as_float(event.get("processed_candidates"))
    available = _as_float(event.get("available_count"))
    next_offset = _as_float(event.get("next_offset"))
    if processed is None or available is None or next_offset is None:
        return {}
    if processed <= 0.0 or available <= 0.0:
        return {}

    elapsed = _as_float(event.get("native_elapsed_sec"))
    if elapsed is None or elapsed <= 0.0:
        elapsed = _as_float(event.get("elapsed_sec"))
    if elapsed is None or elapsed <= 0.0:
        return {}

    active_stride = _as_float(event.get("active_stride"))
    if active_stride is None or active_stride <= 0.0:
        active_stride = _as_float(event.get("adaptive_stride")) or 1.0
    active_stride = max(1.0, active_stride)

    raw_remaining = max(0.0, available - next_offset)
    remaining_eval = math.ceil(raw_remaining / active_stride)
    rate = processed / elapsed
    eta = remaining_eval / rate if rate > 0.0 else None
    percent = min(100.0, max(0.0, 100.0 * next_offset / available))
    result: dict[str, Any] = {
        "progress_percent": round(percent, 3),
        "candidate_rate_per_sec": round(rate, 6),
        "remaining_candidate_estimate": int(remaining_eval),
    }
    if eta is not None:
        result["eta_sec"] = round(eta, 3)
    return result


def _as_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _friendly_event_message(event: dict[str, Any]) -> str | None:
    stage = str(event.get("stage", ""))
    prefix = _friendly_prefix(event)
    elapsed = _brief_elapsed(event)

    if stage == "run.started":
        base = (
            f"{prefix} Starting ESSPY run{elapsed} | "
            f"input={event.get('input')} -> workdir={event.get('workdir')}"
        )
        if event.get("allocation_mode"):
            bits: list[str] = []
            if event.get("allocation_time_budget_sec") not in (None, ""):
                bits.append(f"budget={event.get('allocation_time_budget_sec')}s")
            if bits:
                base += " | allocation(" + ", ".join(bits) + ")"
        return base
    if stage == "run.auto_allocation":
        budget = event.get("allocation_time_budget_sec")
        budget_text = f"budget={budget}s" if budget not in (None, "") else "time-budgeted"
        return f"{prefix} Allocation portfolio ready{elapsed} | {budget_text}"
    if stage == "run.charge_model_override":
        source = event.get("source") or "explicit"
        source_text = "auto" if source == "auto" else "explicit"
        summary = str(event.get("summary", "")).strip()
        summary_text = f" | charges: {summary}" if summary else ""
        return (
            f"{prefix} Charge model loaded; input charges overridden{elapsed} | "
            f"source={source_text} | path={event.get('path')} | "
            f"entries={event.get('loaded_entries')}{summary_text}"
        )
    if stage == "guide.started":
        return (
            f"{prefix} Preparing guide stage{elapsed} | "
            f"title={event.get('title')} | target_sites={event.get('n_target_sites')}"
        )
    if stage == "guide.done":
        return (
            f"{prefix} Guide stage ready{elapsed} | "
            f"input_sites={event.get('n_atoms')} | configured_sites={event.get('n_atom_config')} | "
            f"supercell={event.get('supercell_expansion')} | RGFindFactor={event.get('rg_find_factor')}"
        )
    if stage == "allocation.swap.started":
        return (
            f"{prefix} Allocation-aware swap started{elapsed} | "
            f"starts={event.get('number_target')} | max_steps={event.get('max_swap')}"
        )
    if stage == "allocation.swap.done":
        starts = event.get("total_starts_evaluated")
        if starts is None:
            starts = event.get("starts_evaluated")
        winner = event.get("winning_rank")
        winner_text = "" if winner is None else f" | winner_rank={winner}"
        return (
            f"{prefix} Allocation-aware swap finished{elapsed} | "
            f"starts={starts} | "
            f"accepted={event.get('accepted_moves')} | "
            f"best={_fmt_number(event.get('best_energy'), digits=6)} eV"
            f"{winner_text}"
        )
    if stage == "allocation.transfer.done":
        msg = str(event.get("message", "")).strip()
        if not msg:
            msg = "no cross-site element transfers"
        return (
            f"{prefix} Allocation transfer summary{elapsed} | "
            f"{msg}"
        )
    if stage == "allocation.coupled_ready":
        applied = _on_off(event.get("applied"))
        composition = _fmt_composition_by_site(event.get("composition_by_site"))
        sitewise_apply = event.get("sitewise_apply")
        recipes = "-"
        slots = "-"
        if isinstance(sitewise_apply, dict):
            recipes = str(sitewise_apply.get("source_groups", "-"))
            slots = str(sitewise_apply.get("total_slots", "-"))
        seed = event.get("seed_energy_eV")
        seed_text = (
            f" | seed_E={_fmt_number(seed, digits=6)} eV"
            if seed not in (None, "")
            else ""
        )
        return (
            f"{prefix} Site allocation applied to main ESS{elapsed} | "
            f"applied={applied} | recipes_updated={recipes} | slots={slots} | "
            f"{composition}{seed_text}"
        )
    if stage == "allocation.swap.skipped":
        return f"{prefix} Allocation-aware swap skipped{elapsed}"
    if stage == "allocation.portfolio.started":
        parallel = event.get("rough_parallel") or "all_ranks"
        workers = event.get("worker_ranks")
        worker_text = f" coordinator=0 evaluator_ranks={workers}" if workers not in (None, "") else ""
        budget = event.get("time_budget_sec")
        budget_text = f" budget={budget}s |" if budget not in (None, "") else ""
        return (
            f"{prefix} Site-allocation search started{elapsed} | "
            f"parallel={parallel}{worker_text} |{budget_text} "
            f"allocation_candidates={event.get('candidates')} | "
            f"rough_ESS_per_trial={event.get('rough_ess_time_sec')}s max_swap={event.get('rough_max_swap')} | "
            f"final_candidates={event.get('final_candidates')}"
        )
    if stage == "allocation.portfolio.eval_started":
        worker = event.get("worker_rank")
        worker_text = f" worker={worker} |" if worker not in (None, "") else ""
        return (
            f"{prefix} Site-allocation trial started{elapsed} | "
            f"trial={event.get('index')}/{event.get('total')} |{worker_text} "
            f"budget={event.get('rough_ess_time_sec')}s"
        )
    if stage == "allocation.portfolio.eval_done":
        accepted = " accepted" if event.get("accepted_as_current") else ""
        return (
            f"{prefix} Site-allocation trial finished{elapsed} | "
            f"trial={event.get('index')}/{event.get('total')} | "
            f"trial_E={_fmt_number(event.get('score'), digits=6)} eV | "
            f"best_so_far={_fmt_number(event.get('best_score'), digits=6)} eV | "
            f"rough_ESS_candidates={event.get('evaluated_candidates')} | "
            f"accepted_swaps={event.get('accepted_swaps')}{accepted}"
        )
    if stage == "allocation.portfolio.best_updated":
        return (
            f"{prefix} Site-allocation best updated{elapsed} | "
            f"trial=#{event.get('index')} | best_so_far={_fmt_number(event.get('score'), digits=6)} eV"
        )
    if stage == "allocation.portfolio.refine_started":
        return (
            f"{prefix} Site-allocation final refine started{elapsed} | "
            f"candidate={event.get('index')}/{event.get('total')} | "
            f"budget={event.get('refine_time_sec')}s | "
            f"screen_E={_fmt_number(event.get('score'), digits=6)} eV"
        )
    if stage == "allocation.portfolio.refine_done":
        return (
            f"{prefix} Site-allocation final refine finished{elapsed} | "
            f"candidate={event.get('index')}/{event.get('total')} | "
            f"refined_E={_fmt_number(event.get('score'), digits=6)} eV"
        )
    if stage == "allocation.portfolio.done":
        parallel = event.get("rough_parallel")
        parallel_text = f" | parallel={parallel}" if parallel not in (None, "") else ""
        reason = event.get("stop_reason")
        reason_text = f" | stop={reason}" if reason not in (None, "") else ""
        return (
            f"{prefix} Site-allocation search finished{elapsed} | "
            f"evaluated_trials={event.get('evaluated_allocations')} | "
            f"unique={event.get('unique_allocations')} | "
            f"best_so_far={_fmt_number(event.get('best_score'), digits=6)} eV"
            f"{parallel_text}{reason_text}"
        )
    if stage == "solve.seeded_start":
        return (
            f"{prefix} Final ESS seeded from allocation best{elapsed} | "
            f"source={event.get('source')} | "
            f"E={_fmt_number(event.get('energy'), digits=6)} eV | "
            f"sites={event.get('sites')}"
        )
    if stage == "outputs.guide.done":
        return f"{prefix} Guide outputs written{elapsed} | files={_count_list(event.get('wrote'))}"
    if stage == "solve.plan":
        primary_candidates = event.get("primary_jobsize_u64")
        if event.get("primary_jobsize_saturated"):
            primary_candidates = f"{primary_candidates} (uint64-saturated)"
        saturated_text = (
            " | search_space=saturated/adaptive-sampled"
            if event.get("search_space_saturated")
            else ""
        )
        return (
            f"{prefix} Search plan{elapsed} | "
            f"primary={event.get('primary_from')} recipe#{event.get('primary_recipe_index')} | "
            f"pickup={event.get('primary_random_pickup')} trial={event.get('primary_random_pickup_trial')} | "
            f"primary_candidates={primary_candidates} | "
            f"total_log10={_fmt_number(event.get('total_candidate_count_log10'), digits=3)}"
            f"{saturated_text}"
        )
    if stage == "solve.partition":
        saturated_text = (
            " | note=saturated candidate range is a sampled window"
            if event.get("search_space_saturated")
            else ""
        )
        return (
            f"{prefix} Rank assignment{elapsed} | "
            f"candidates={event.get('assigned_start')}..{event.get('assigned_end')} "
            f"(count={event.get('assigned_count')}) | "
            f"chunk_limit={event.get('local_enumeration_limit')} | "
            f"max_chunks={event.get('local_enumeration_max_chunks')} | "
            f"save_memory={_on_off(event.get('enumeration_save_memory'))}"
            f"{saturated_text}"
        )
    if stage == "solve.started":
        strategy_mode = event.get("strategy_mode")
        strategy_budget = event.get("strategy_time_budget_sec")
        strategy_effort = event.get("strategy_effort")
        strategy_execution_mode = event.get("strategy_execution_mode")
        if strategy_mode:
            strategy_bits = [f"mode={strategy_mode}"]
            if strategy_mode == "adaptive" and strategy_budget not in (None, ""):
                strategy_bits.append(f"budget={strategy_budget}s")
            if strategy_effort not in (None, ""):
                strategy_bits.append(f"effort={strategy_effort}")
            if strategy_execution_mode not in (None, ""):
                strategy_bits.append(f"execution={strategy_execution_mode}")
            cost_model = event.get("adaptive_stride_cost_model")
            if cost_model not in (None, ""):
                strategy_bits.append(f"stride_cost={cost_model}")
            seed_source = event.get("seed_structure_source")
            seed_energy = event.get("seed_energy_eV")
            if seed_source not in (None, ""):
                strategy_bits.append("seed=site_allocation_best")
                if seed_energy not in (None, ""):
                    strategy_bits.append(
                        f"seed_E={_fmt_number(seed_energy, digits=6)}eV"
                    )
            mode = ", ".join(strategy_bits)
        else:
            mode = (
                f"adaptive target={abs(int(event.get('running_index_delta', 0)))}s"
                if _as_float(event.get("running_index_delta")) is not None
                and float(event.get("running_index_delta")) < 0
                else f"stride={event.get('running_index_delta')}"
            )
        return (
            f"{prefix} Solve started{elapsed} | {mode} | "
            f"save_memory={_on_off(event.get('enumeration_save_memory'))} | "
            f"swap={_on_off(event.get('swap'))} max_swap={event.get('max_swap')}"
        )
    if stage == "solve.chunk.started":
        return (
            f"{prefix} Evaluating candidate chunk{elapsed} | "
            f"next_offset={event.get('next_offset')} | available={event.get('available_count')} | "
            f"stride={event.get('active_stride')}"
        )
    if stage == "solve.nested":
        energy_bits: list[str] = []
        window_e = _as_finite_float(event.get("local_e_min"))
        best_e = _as_finite_float(event.get("best_so_far_energy"))
        timing_bits: list[str] = []
        solve_elapsed = _as_finite_float(event.get("native_elapsed_sec"))
        solve_budget = _as_finite_float(event.get("solve_budget_sec"))
        if solve_elapsed is not None and solve_budget is not None and solve_budget > 0.0:
            remaining = max(0.0, solve_budget - solve_elapsed)
            timing_bits.append(
                f"solve_elapsed={_fmt_duration(solve_elapsed)}/{_fmt_duration(solve_budget)}"
            )
            timing_bits.append(f"remaining={_fmt_duration(remaining)}")
        elif solve_elapsed is not None:
            timing_bits.append(f"solve_elapsed={_fmt_duration(solve_elapsed)}")
        if window_e is not None:
            energy_bits.append(f"window_E_min={window_e:.4f} eV")
        if best_e is not None:
            energy_bits.append(f"best_so_far={best_e:.4f} eV")
        if window_e is not None and best_e is not None:
            energy_bits.append(f"window_minus_best={window_e - best_e:+.4f} eV")
        detail_bits = timing_bits + energy_bits
        detail_suffix = f" | {' | '.join(detail_bits)}" if detail_bits else ""
        return (
            f"{prefix} Evaluating secondary recipe{elapsed} | "
            f"recipe#{event.get('secondary_recipe_index')} | "
            f"secondary_index={event.get('secondary_index')}/{event.get('secondary_jobsize')} | "
            f"evaluated≈{event.get('processed_candidates')}"
            f"{detail_suffix}"
        )
    if stage == "solve.adaptive_stride":
        return (
            f"{prefix} Adaptive stride updated{elapsed} | "
            f"monitoring={event.get('monitoring_index')} | stride={event.get('adaptive_stride')}"
        )
    if stage == "solve.chunk":
        # If message was pre-formatted with progress, use it
        msg = event.get("message", "").strip()
        if msg:
            return f"{prefix} {msg}{elapsed}"
        # Fallback to detailed format if available
        return (
            f"{prefix} Chunk complete{elapsed} | "
            f"processed={event.get('processed_candidates')} | "
            f"progress={_fmt_number(event.get('progress_percent'), digits=2)}% | "
            f"rate={_fmt_number(event.get('candidate_rate_per_sec'), digits=2)} cand/s | "
            f"eta={_fmt_eta(event.get('eta_sec'))} | "
            f"best={_fmt_number(event.get('local_e_min'), digits=6)} eV"
        )
    if stage == "solve.swap.started":
        return f"{prefix} Swap optimization started{elapsed}"
    if stage == "solve.swap.done":
        return f"{prefix} Swap optimization finished{elapsed}"
    if stage == "solve.done":
        return (
            f"{prefix} Solve finished{elapsed} | "
            f"candidates={event.get('global_count_total')} | "
            f"best={_fmt_number(event.get('global_e_min'), digits=6)} eV | "
            f"worst={_fmt_number(event.get('global_e_max'), digits=6)} eV | "
            f"accepted_swaps={event.get('local_swap_count')}"
        )
    if stage == "outputs.solve.done":
        return f"{prefix} Solve outputs written{elapsed} | files={_count_list(event.get('wrote'))}"
    if stage == "run.done":
        return (
            f"{prefix} Run finished{elapsed} | "
            f"summary={event.get('summary')} | outputs={_count_list(event.get('outputs'))}"
        )
    return None


def _friendly_prefix(event: dict[str, Any]) -> str:
    timestamp = event.get('timestamp', '')
    if 'T' in timestamp:
        timestamp = timestamp.split('T')[1]
    stage = str(event.get("stage", ""))
    display_stage = {
        "allocation.portfolio.started": "site_allocation.search_started",
        "allocation.portfolio.eval_started": "site_allocation.trial_started",
        "allocation.portfolio.eval_done": "site_allocation.trial_done",
        "allocation.portfolio.best_updated": "site_allocation.best_updated",
        "allocation.portfolio.refine_started": "site_allocation.refine_started",
        "allocation.portfolio.refine_done": "site_allocation.refine_done",
        "allocation.portfolio.done": "site_allocation.search_done",
        "allocation.coupled_ready": "site_allocation.applied_to_main_ess",
    }.get(stage, stage)
    return f"[{timestamp}] {display_stage}:"


def _brief_elapsed(event: dict[str, Any]) -> str:
    value = _as_float(event.get("elapsed_sec"))
    if value is None:
        return ""
    return f" ({value:.1f}s)"


def _fmt_number(value: Any, *, digits: int) -> str:
    number = _as_float(value)
    if number is None:
        return "-"
    return f"{number:.{digits}f}"


def _as_finite_float(value: Any) -> float | None:
    number = _as_float(value)
    if number is None or not math.isfinite(number):
        return None
    return number


def _fmt_duration(seconds: float) -> str:
    if seconds < 60.0:
        return f"{seconds:.0f}s"
    if seconds < 3600.0:
        return f"{seconds / 60.0:.1f}m"
    return f"{seconds / 3600.0:.1f}h"


def _fmt_composition_by_site(value: Any) -> str:
    if not isinstance(value, dict) or not value:
        return "composition_by_site=-"
    groups: list[str] = []
    for group in sorted(value.keys(), key=str):
        row = value.get(group)
        if not isinstance(row, dict) or not row:
            continue
        parts = []
        for kind, count in sorted(row.items(), key=lambda item: str(item[0])):
            number = _as_float(count)
            if number is None or number == 0.0:
                continue
            parts.append(f"{kind}={int(number)}")
        if parts:
            groups.append(f"{group}[{' '.join(parts)}]")
    return " | ".join(groups) if groups else "composition_by_site=-"


def _fmt_eta(value: Any) -> str:
    seconds = _as_float(value)
    if seconds is None:
        return "-"
    if seconds < 60:
        return f"{seconds:.1f}s"
    if seconds < 3600:
        return f"{seconds / 60.0:.1f}m"
    return f"{seconds / 3600.0:.1f}h"


def _on_off(value: Any) -> str:
    return "on" if bool(value) else "off"


def _count_list(value: Any) -> str:
    if isinstance(value, list):
        return f"{len(value)} ({', '.join(str(item) for item in value)})"
    return str(value)
