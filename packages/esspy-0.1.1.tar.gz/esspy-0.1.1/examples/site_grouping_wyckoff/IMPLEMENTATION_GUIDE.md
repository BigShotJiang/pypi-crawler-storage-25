# Site Grouping + Allocation Implementation Guide

This guide breaks the site-grouping and allocation-mode work into turn-sized implementation units.

Target example:

`examples/site_grouping_wyckoff/POSCAR-target`

Expected symmetry split:

```text
Cr@a: indices 0..7    count=8
Cr@d: indices 8..23   count=16
O@e : indices 24..55  count=32
```

Core principle:

```text
wizard/init may infer site groups.
esspy run must validate and apply explicit site_indices.
```

## Working Rules

Each implementation turn should follow this shape:

```text
1. Implement one bounded slice.
2. Add or update focused tests for that slice.
3. Run the narrow test target.
4. Run a small manual check in examples/site_grouping_wyckoff when relevant.
5. Do not start the next slice until this one is green.
```

Recommended baseline before each major slice:

```bash
cd /Users/bama/Dropbox/data/code/EwaldSolidSolution/esspy/develop
python -m pytest -q
```

For faster inner-loop work, run only the tests listed in each checklist item.

## Checklist Overview

- [x] 00. Baseline and fixture sanity check
- [x] 01. Add site grouping core module
- [x] 02. Add `esspy util site-groups`
- [x] 03. Emit site grouping schema from `esspy init`
- [x] 04. Wire site grouping into wizard
- [x] 05. Validate `site_indices` at runtime
- [x] 06. Make sample labels use explicit site groups
- [x] 07. Charge-fit cross-validation gate
- [ ] 07A. MPI-accelerated `esspy fc` quadratic precompute
- [x] 08. Add allocation feasibility analyzer
- [ ] 09. Decide arrangement-only vs allocation+arrangement mode
- [ ] 10. Add native generalized swap support for explicit site indices
- [ ] 11. Make allocation capacity derive from site indices
- [ ] 12. Add charge model/site metadata validation
- [ ] 13. End-to-end allocation/run validation
- [ ] 14. Full regression and cleanup

## 00. Baseline and Fixture Sanity Check

Goal:

Confirm the development fixture behaves as expected before changing code.

Implementation:

- No code changes.
- Confirm `POSCAR-target` exists.
- Confirm spglib detects `Cr@a`, `Cr@d`, `O@e`.

Check:

```bash
cd /Users/bama/Dropbox/data/code/EwaldSolidSolution/esspy/develop
python - <<'PY'
from pathlib import Path
import spglib
from esspy.poscar import load_poscar

p = Path("examples/site_grouping_wyckoff/POSCAR-target")
s = load_poscar(p)
kind_to_num = {}
nums = []
next_num = 1
for site in s.sites:
    if site.kind not in kind_to_num:
        kind_to_num[site.kind] = next_num
        next_num += 1
    nums.append(kind_to_num[site.kind])

cell = (
    [list(s.lattice.a), list(s.lattice.b), list(s.lattice.c)],
    [[site.x, site.y, site.z] for site in s.sites],
    nums,
)
ds = spglib.get_symmetry_dataset(cell, symprec=0.01, angle_tolerance=5.0)
print(getattr(ds, "international", ds["international"]), getattr(ds, "number", ds["number"]))
print(list(getattr(ds, "wyckoffs", ds["wyckoffs"]))[:24])
PY
```

Minimal acceptance:

- Prints `Fd-3m 227`.
- First 8 Wyckoff labels are `a`.
- Next 16 Wyckoff labels are `d`.

Tests:

- None yet.

## 01. Add Site Grouping Core Module

Goal:

Add deterministic site-group detection independent of wizard/init.

Files:

- Add `python/esspy/site_grouping.py`
- Add `tests/test_site_grouping.py`

Implementation:

- Add dataclasses:
  - `SiteGroupingOptions`
  - `SiteGroupSpec`
  - `SiteGroupingResult`
  - `SiteGroupValidationResult`
- Add functions:
  - `detect_site_groups(structure, element_mapping, options)`
  - `detect_poscar_kind_groups(...)`
  - `detect_element_wyckoff_groups(...)`
  - `site_group_specs_to_yaml(...)`
  - `structure_site_fingerprint(...)`

Pseudo code:

```python
def detect_site_groups(structure, element_mapping, options):
    if options.mode in ("element", "poscar_kind"):
        return detect_poscar_kind_groups(structure, element_mapping, options)
    if options.mode == "element_wyckoff":
        try:
            return detect_element_wyckoff_groups(structure, element_mapping, options)
        except Exception:
            if options.strict:
                raise
            result = detect_poscar_kind_groups(structure, element_mapping, options)
            result.fallback_used = True
            return result
    raise ValueError(...)
```

Check:

- For `POSCAR-target`, `poscar_kind` gives two groups:
  - `Cr(24)`
  - `O(32)`
- For `POSCAR-target`, `element_wyckoff` gives three groups:
  - `Cr@a(8)`
  - `Cr@d(16)`
  - `O@e(32)`

Tests:

```bash
python -m pytest tests/test_site_grouping.py -q
```

Required test cases:

- `test_poscar_target_poscar_kind_groups`
- `test_poscar_target_element_wyckoff_groups`
- `test_site_grouping_fallback_to_poscar_kind`
- `test_site_grouping_structure_fingerprint_changes_on_site_order`

Minimal manual check:

```bash
python - <<'PY'
from esspy.poscar import load_poscar
from esspy.site_grouping import SiteGroupingOptions, detect_site_groups
s = load_poscar("examples/site_grouping_wyckoff/POSCAR-target")
mapping = {"Cr": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"], "O": ["O"]}
for mode in ["poscar_kind", "element_wyckoff"]:
    r = detect_site_groups(s, mapping, SiteGroupingOptions(mode=mode, symprec=0.1))
    print(mode, [(g.name, g.source_kind, g.count, g.label.get("display")) for g in r.groups])
PY
```

## 02. Add `esspy util site-groups`

Goal:

Expose site grouping as a standalone inspection command before integrating wizard/run.

Files:

- Update `python/esspy/cli.py`
- Update `python/esspy/cli_util.py`
- Update `tests/test_cli_util.py`

CLI:

```bash
esspy util site-groups POSCAR-target --mode poscar_kind
esspy util site-groups POSCAR-target --mode element_wyckoff --symprec 0.1 --angle-tolerance 5.0
esspy util site-groups POSCAR-target --mode element_wyckoff --json
```

Implementation:

- Parse POSCAR.
- Build default element mapping from POSCAR kinds unless `--map` is added later.
- Call `detect_site_groups`.
- Print human table.
- JSON output must be YAML-ready.

Check:

```bash
cd examples/site_grouping_wyckoff
esspy util site-groups POSCAR-target --mode element_wyckoff --symprec 0.1
```

Expected:

```text
site1  Cr@a  source=Cr  count=8
site2  Cr@d  source=Cr  count=16
site3  O@e   source=O   count=32
```

Tests:

```bash
python -m pytest tests/test_cli_util.py::test_cli_util_site_groups_element_wyckoff -q
python -m pytest tests/test_cli_util.py::test_cli_util_site_groups_json -q
```

## 03. Emit Site Grouping Schema From `esspy init`

Goal:

Make `esspy init` produce explicit `site_grouping` and `site_groups.site_indices`.

Files:

- Update `python/esspy/init_scaffold.py`
- Update `python/esspy/cli.py`
- Update `tests/test_cli_init.py`

CLI additions:

```bash
--site-grouping element|poscar_kind|element_wyckoff
--site-group-symprec 0.1
--site-group-angle-tolerance 5.0
--site-group-fallback poscar_kind
--site-group-strict
```

Implementation:

- If manual `--site-group` is provided, preserve current explicit behavior.
- If `--site-grouping` is provided, call `detect_site_groups`.
- If neither is provided but site-aware charge/allocation is active, default to `poscar_kind` with explicit `site_indices`.
- Emit `site_grouping`.
- Emit `site_groups` with `site_indices`, `label`, `symmetry`.

Check:

```bash
cd examples/site_grouping_wyckoff
esspy init -p POSCAR-target \
  --out input.yaml \
  --name site-grouping-test \
  --dim 1 1 1 \
  --composition Mn=1,Cr=20,Ni=1,Rh=1,Co=1,O=32 \
  --charges Mn=2,Cr=3,Ni=2,Rh=3,Co=2,O=-2 \
  --charge-basis element_site \
  --recipe Cr:Mn,Cr,Ni,Rh,Co \
  --recipe O:O \
  --site-grouping element_wyckoff \
  --site-group-symprec 0.1 \
  --selection-enabled false
```

Expected YAML:

- `site_grouping.mode: element_wyckoff`
- `site_groups.site1.source_kind: Cr`
- `site_groups.site1.site_indices: [0..7]`
- `site_groups.site2.source_kind: Cr`
- `site_groups.site2.site_indices: [8..23]`

Tests:

```bash
python -m pytest \
  tests/test_cli_init.py::test_cli_init_unified_poscar_auto_site_grouping_element_wyckoff \
  tests/test_cli_init.py::test_cli_init_element_site_defaults_to_poscar_kind_site_indices \
  tests/test_cli_init_site_aware.py \
  -q
```

Completed:

- Added `--site-grouping`, `--site-group-symprec`, `--site-group-angle-tolerance`,
  `--site-group-fallback`, and `--site-group-strict` to both `esspy init -p`
  and `esspy init from-poscar`.
- `--site-grouping element_wyckoff` now emits `site_grouping` metadata and
  `site_groups.*.site_indices`, labels, and symmetry metadata.
- If `charge_basis=element_site` or allocation search is requested without
  explicit `--site-group`, `esspy init` now defaults to `poscar_kind` grouping
  with explicit `site_indices`.
- Explicit `--site-group` remains the legacy/manual path and is not mixed with
  auto grouping.

## 04. Wire Site Grouping Into Wizard

Goal:

Wizard asks the user whether to group by POSCAR kind or Element + Wyckoff/orbit.

Files:

- Update `python/esspy/wizard.py`
- Update `tests/test_wizard_supercell.py` or add `tests/test_wizard_site_grouping.py`

Wizard prompt:

```text
Select site grouping policy:
  1) Element/POSCAR-kind only
  2) Element + Wyckoff/orbit
Select (1-2) [default: 2]:
```

If option 2:

```text
Site grouping tolerance:
  symprec [0.1]:
  angle_tolerance [5.0]:
```

Implementation:

- Replace hard-coded POSCAR-kind grouping in `step_2b_site_groups_and_composition_mode`.
- Store `state.site_grouping`.
- Store `state.site_groups` from `detect_site_groups`.
- Replay command must include `--site-grouping` and tolerance flags.

Check:

- Wizard-generated YAML and replay-generated YAML should match for site grouping fields.

Tests:

```bash
python -m pytest tests/test_wizard_site_grouping.py -q
python -m pytest tests/test_cli_wizard_replay.py -q
```

Completed:

- Wizard now asks for site grouping policy in Step 3.
- `Element + Wyckoff/orbit` calls the shared `detect_site_groups` core with
  `symprec` and `angle_tolerance`.
- Wizard state stores both `site_grouping` metadata and `site_groups` with
  explicit `site_indices`.
- Saved `input.yaml` preserves `site_grouping`, labels, symmetry metadata, and
  site-aware charge overrides.
- `wizard.replay.sh` now uses `--site-grouping ...` flags instead of expanding
  auto-detected groups into manual `--site-group` entries.

Minimal manual check:

```bash
cd examples/site_grouping_wyckoff
esspy wizard
```

Expected:

- Choosing `Element + Wyckoff/orbit` shows `Cr@a`, `Cr@d`, `O@e`.

## 05. Validate `site_indices` At Runtime

Goal:

`esspy run` must trust `input.yaml` site groups, not rediscover them.

Files:

- Update `python/esspy/config.py`
- Possibly use helpers from `python/esspy/site_grouping.py`
- Add `tests/test_yaml_config.py` cases

Implementation:

- Add `validate_site_groups_contract`.
- Build `base_group_by_site`.
- Hard error on:
  - duplicate indices
  - out-of-range indices
  - count mismatch
  - duplicate `source_kind` without explicit indices
  - fingerprint mismatch if present

Pseudo code:

```python
if any_group_has_site_indices:
    use explicit index mode
else:
    use legacy source_kind mode
    if duplicate_source_kind:
        raise ValueError(...)
```

Check:

```bash
esspy run input.yaml --guide-only
```

Expected:

- Loads without running spglib for grouping.
- Logs or summary mention explicit site group contract.

Tests:

```bash
python -m pytest tests/test_yaml_config.py::test_site_groups_with_duplicate_source_kind_require_indices -q
python -m pytest tests/test_yaml_config.py::test_site_groups_explicit_indices_validate -q
```

Implementation status:

- Added `SiteGroupValidationResult` and `validate_site_groups_contract`.
- `load_run_input()` validates `site_groups` immediately after loading the
  reference structure.
- Explicit `site_indices` mode requires every group to define indices.
- Duplicate `source_kind` without explicit `site_indices` is rejected.
- Explicit indices must be in range, non-overlapping, count-matched, and kind-matched.
- If `site_grouping.source.structure_fingerprint` exists, it must match the loaded
  POSCAR/base structure.

Validation commands used:

```bash
python -m pytest tests/test_yaml_config.py::test_site_groups_explicit_indices_validate tests/test_yaml_config.py::test_site_groups_with_duplicate_source_kind_require_indices tests/test_yaml_config.py::test_site_groups_explicit_indices_reject_count_mismatch tests/test_yaml_config.py::test_site_groups_reject_fingerprint_mismatch -q
python -m pytest tests/test_yaml_config.py -q
python -m pytest tests/test_site_grouping.py tests/test_cli_init.py::test_cli_init_unified_poscar_auto_site_grouping_element_wyckoff tests/test_cli_init.py::test_cli_init_element_site_defaults_to_poscar_kind_site_indices tests/test_wizard_site_grouping.py tests/test_cli_wizard_replay.py -q
```

## 06. Make Sample Labels Use Explicit Site Groups

Goal:

`esspy sample` writes `# site-xxx` labels from explicit site membership. This must be done before `esspy fc` cross-validation, because `fit-charge` needs those labels to distinguish `Element@site1` and `Element@site2`.

Files:

- Update `python/esspy/sample_structures.py`
- Update `tests/test_cli_sample.py`

Implementation:

- Build expanded group membership from base `site_indices`.
- Do not coordinate-match when group membership exists.
- Keep existing behavior for old YAML.

Check:

```bash
cd examples/site_grouping_wyckoff
esspy sample input.yaml -n 5
rg "site-001|site-002|site-003" samples
```

Implementation status:

- `esspy sample` now uses explicit `site_groups.<name>.site_indices` to build
  base-site labels.
- Labels are expanded through the supercell by preserving the same base-site
  order used by ready/supercell expansion.
- Duplicate `source_kind` groups such as `Cr@a` and `Cr@d` no longer collapse
  into a single source-kind label.
- Site-wise sampling accepts normalized labels (`site-001`) and original keys
  (`site1`) when reading `composition_by_site`.

Validation commands used:

```bash
python -m pytest tests/test_cli_sample.py -q
python -m pytest tests/test_yaml_config.py::test_site_groups_explicit_indices_validate tests/test_yaml_config.py::test_site_groups_with_duplicate_source_kind_require_indices tests/test_site_grouping.py -q
```

Manual check:

```text
sample-001.vasp label counts:
site-001 8
site-002 16
site-003 32
```

Additional scaled-count check:

- For global `composition.fractions` with a larger target supercell, `site_groups.count`
  may be written either as base POSCAR counts or as target-scaled slot counts.
- `esspy sample` must not run a one-shot allocation optimizer before sampling in this
  mode; it should generate independent random site allocations per sample.

Validated 448-site spinel case:

```text
composition counts: Mn28 Cr56 Ni38 Rh20 Co29 Fe21 O256
site labels       : site-001=64, site-002=128, site-003=256
```

Expected:

- cation sites derived from base indices `0..7` get `site-001`.
- cation sites derived from base indices `8..23` get `site-002`.
- oxygen sites get `site-003`.

Tests:

```bash
python -m pytest tests/test_cli_sample.py::test_sample_uses_explicit_site_indices -q
```

## 07. Charge-Fit Cross-Validation Gate

Goal:

Before trusting allocation-aware `esspy run`, verify that the site-aware charge model improves or at least preserves Ewald-vs-uMLFF parity on sampled structures.

This is a scientific validation gate, not only a software test. The expected workflow is:

```text
input.yaml with explicit site_groups/site_indices
-> esspy sample
-> macer relax -p sample-* --isif 0
-> esspy fc
-> parity plot: fitted Ewald energy vs uMLFF total energy
-> optional held-out sample validation
```

Prerequisites:

- Steps 01-06 are complete.
- `input.yaml` contains explicit `site_indices`.
- `esspy sample` emits `# site-xxx` labels.

Manual workflow, default quick validation set:

```bash
cd /Users/bama/Dropbox/data/code/EwaldSolidSolution/esspy/develop/examples/site_grouping_wyckoff

# 1. Generate 50 random labeled training samples.
esspy sample input.yaml -n 50
cd samples

# 2. Get uMLFF total energies for those 50 samples.
macer relax -p sample-* --isif 0

# 3. Fit site-aware effective charges from sample POSCARs and OUTCAR energies.
esspy fc -p 'sample-*' --outcar 'OUTCAR-sample-*'

# Expected outputs:
#   charge_model.json
#   fit_report.json
#   parity_plot.pdf
#   ewald_quadratic_cache.npz
```

Held-out validation:

```bash
cd ..
esspy sample input.yaml -n 50
cd samples-NEW001
macer relax -p sample-* --isif 0
esspy validate-model ../samples/charge_model.json \
  -p 'sample-*' \
  --outcar 'OUTCAR-sample-*' \
  --out-plot parity_generalization_fixed_model.pdf
```

Three-way comparison target:

```text
1. Default charge model on train/held-out samples
2. Fitted site-aware charge model on train samples
3. Same fitted charge model on held-out samples
```

Success criteria:

- `esspy fc` detects site labels and uses `element_site` basis.
- The fitted model writes hierarchical charge JSON.
- `charge_model.json` contains distinct values for e.g.:

```text
Mn@site-001 vs Mn@site-002
Cr@site-001 vs Cr@site-002
```

- Training parity is meaningfully better than default or physically interpretable.
- Held-out parity does not collapse.
- If held-out parity is worse than default, do not proceed to production allocation-aware run without revisiting charge basis/regularization/sample diversity.

Recommended log checks:

```text
[fit-charge] Auto basis: detected '# site-xxx' labels -> using element_site
[fit-charge] site_charges: site-001[...] | site-002[...] | site-003[...]
```

Tests:

Software-level tests should not run `macer`. Instead add or update tests with tiny synthetic OUTCAR/POSCAR fixtures:

```bash
python -m pytest tests/test_cli_fit_charge.py -q
```

Required test coverage:

- `esspy fc` detects site labels from sample POSCAR comments.
- `charge_model.json` preserves hierarchical site-aware schema.
- `validate-model` can read the site-aware model and apply it to a second labeled dataset.

Documentation artifact:

- Store generated parity plots in the product-run working folder, not in the repo.
- The repo example keeps instructions only.

Implementation status:

- Added a software-level cross-validation test using tiny site-labeled POSCAR
  fixtures and synthetic OUTCAR energies.
- `esspy fc` is verified to auto-detect `# site-xxx` labels and write
  `charge_basis=element_site`.
- The resulting `charge_model.json` is verified to use schema v2 with
  `charges.elements.<element>.by_site`.
- `esspy validate-model` is verified to load that site-aware charge model and
  evaluate a held-out labeled dataset.
- `esspy fc` can update the first line of labeled sample POSCARs with fitted
  site-aware charge metadata, so `esspy ewald -p sample-*.vasp` can reuse the
  fitted charges without a separate argument.
- `esspy ewald --charge-model charge_model.json` can evaluate labeled POSCARs
  directly with the fitted site-aware charge model.

Validation commands used:

```bash
python -m pytest tests/test_cli_fit_charge.py::test_cli_fc_site_labels_write_model_and_validate_heldout -q
python -m pytest tests/test_cli_fit_charge.py -q
python -m pytest tests/test_cli_sample.py tests/test_site_grouping.py tests/test_yaml_config.py::test_site_groups_explicit_indices_validate -q
```

## 07A. MPI-Accelerated `esspy fc` Quadratic Precompute

Goal:

Make the initial `ewald_quadratic_cache.npz` construction in `esspy fc` scale with MPI.

This targets commands such as:

```bash
mpirun -np 10 esspy fc -p 'sample-*' --outcar 'OUTCAR-sample-*'
```

Current limitation:

At present, launching the above command starts 10 independent `esspy fc`
processes. That is not real parallelism. Each rank attempts to:

- build the same dataset,
- construct the same quadratic cache,
- write `ewald_quadratic_cache.npz`,
- write `charge_model.json`,
- write `fit_report.json`,
- write `parity_plot.pdf`,
- rewrite sample POSCAR titles.

This can corrupt outputs or waste work. The intended behavior is one logical
fit-charge job with MPI used only for the expensive precompute stage.

Why this is parallelizable:

The quadratic cache tensor is independent per structure:

```text
H[m] = quadratic Ewald tensor for structure m
```

For each structure, the number of Ewald evaluations is:

```text
dim + dim * (dim - 1) / 2
```

For `element_site` spinel fitting with `dim=13`, that is 91 Ewald calls per
structure. With 200 structures this is 18,200 independent Ewald calls grouped
into 200 independent `H[m]` tensors. The natural MPI split is therefore by
structure index, not by optimizer iteration.

Target behavior:

```text
rank 0:
  parses CLI and builds/loads dataset
all ranks:
  receive dataset metadata and precompute metadata
  load existing cache if valid
  if cache missing, compute only assigned structure tensors
rank 0:
  gathers tensors
  writes ewald_quadratic_cache.npz
  runs optimizer
  writes charge_model.json, fit_report.json, parity_plot.pdf
  updates POSCAR titles
non-root ranks:
  do not write user outputs
```

Pseudo code:

```python
def handle_fit_charge(args):
    mpi = detect_mpi_context()
    rank = mpi.rank
    size = mpi.size
    comm = mpi.comm

    if rank == 0:
        entries = build_or_load_dataset(args)
        config = build_fit_config(args, entries)
        cache_meta = build_precompute_meta(config)
    else:
        entries = None
        config = None
        cache_meta = None

    if comm is not None:
        entries = comm.bcast(entries, root=0)
        config = comm.bcast(config, root=0)
        cache_meta = comm.bcast(cache_meta, root=0)

    h_tensor = try_load_cache_on_all_ranks_or_root(args.cache, cache_meta)

    if h_tensor is None:
        local_indices = [
            i for i in range(len(entries))
            if i % size == rank
        ]
        local_blocks = []
        for i in local_indices:
            h_i = precompute_one_structure(entries[i], config)
            local_blocks.append((i, h_i))

        if comm is not None:
            gathered = comm.gather(local_blocks, root=0)
            if rank == 0:
                h_tensor = zeros((n_entries, dim, dim))
                for rank_blocks in gathered:
                    for i, h_i in rank_blocks:
                        h_tensor[i] = h_i
                save_cache(args.cache, h_tensor, cache_meta)
            h_tensor = comm.bcast(h_tensor, root=0)
        else:
            h_tensor = assemble_serial(local_blocks)
            save_cache(args.cache, h_tensor, cache_meta)

    if rank != 0:
        return 0

    result = fit_optimizer(entries, h_tensor, config)
    write_model_report_plot(result)
    update_poscar_titles(result)
    return 0
```

Implementation plan:

1. Add MPI context handling to `_handle_fit_charge`.
   - Reuse `esspy.mpi_context.detect_mpi_context`.
   - Root rank is the only rank allowed to print the final JSON summary.
   - Non-root ranks should print no normal progress unless debugging is enabled.

2. Split `_precompute_quadratic_ewald_tensor`.
   - Keep the current public function as the serial facade.
   - Add a smaller helper:

```python
def _precompute_quadratic_ewald_one_structure(entry, fit_kinds, ...):
    return h_matrix
```

   - The serial facade loops over all entries and calls this helper.
   - The MPI facade loops over rank-assigned entries and calls this helper.

3. Add an MPI precompute path.

```python
def _precompute_quadratic_ewald_tensor_mpi(entries, ..., mpi, emit):
    local_indices = range(rank, len(entries), size)
    local_blocks = [(i, compute_one(entries[i])) for i in local_indices]
    gathered = comm.gather(local_blocks, root=0)
    if rank == 0:
        h_tensor = assemble_full_tensor(gathered)
    else:
        h_tensor = None
    return comm.bcast(h_tensor, root=0)
```

4. Cache ownership rules.
   - Only rank 0 checks metadata mismatch messages.
   - Only rank 0 writes `ewald_quadratic_cache.npz`.
   - All ranks can read an existing valid cache, or rank 0 can read and broadcast.
   - Prefer root-read-and-broadcast for correctness on filesystems with slow or
     inconsistent shared metadata.

5. Output ownership rules.
   - Only rank 0 writes:
     - `charge_model.json`
     - `fit_report.json`
     - `parity_plot.pdf`
     - `dataset.txt`
     - sample POSCAR title updates
   - Non-root ranks return cleanly after participating in precompute.

6. Progress logging.
   - Root emits:

```text
[fit-charge] MPI precompute enabled: ranks=10
[fit-charge] rank distribution: min=20 max=20 structures/rank
[fit-charge] Quadratic precompute done: 200 structures in X.XXs
```

   - Optional debug mode may emit per-rank counts, but default output should be
     concise.

7. Fallback behavior.
   - If `mpi4py` is unavailable but launcher environment variables indicate
     multiple ranks, do not let every process write outputs.
   - Safe fallback:
     - rank 0 runs serial `esspy fc`,
     - non-root ranks exit with code 0 after a short message suppressed by default.
   - Full MPI speedup requires `mpi4py`.

Acceptance criteria:

- Serial behavior is unchanged:

```bash
esspy fc -p 'sample-*' --outcar 'OUTCAR-sample-*'
```

- MPI behavior is one logical job:

```bash
mpirun -np 10 esspy fc -p 'sample-*' --outcar 'OUTCAR-sample-*'
```

- Only one set of outputs is written.
- `ewald_quadratic_cache.npz` is written once.
- A second MPI run loads the cache instead of rebuilding it.
- Fitted charges and metrics match the serial result within numerical tolerance.

Test plan:

Software tests should avoid expensive real Ewald calls where possible.

Recommended unit tests:

- Test rank slicing:

```python
assignments = mpi_structure_indices(n_entries=23, size=5)
assert sorted(flatten(assignments)) == list(range(23))
assert max(map(len, assignments)) - min(map(len, assignments)) <= 1
```

- Test tensor assembly:

```python
blocks = [[(0, H0), (5, H5)], [(1, H1)]]
h = assemble_tensor_from_rank_blocks(blocks, n_entries=6, dim=13)
assert_allclose(h[0], H0)
assert_allclose(h[5], H5)
```

- Test output ownership with fake MPI context:
  - rank 0 writes outputs,
  - rank 1 does not write model/report/plot.

Recommended integration check:

```bash
cd product-run/CCS13/samples
rm -f ewald_quadratic_cache.npz charge_model.json fit_report.json parity_plot.pdf

esspy fc -p 'sample-*' --outcar 'OUTCAR-sample-*' --maxiter 2
mv charge_model.json charge_model.serial.json

rm -f ewald_quadratic_cache.npz charge_model.json fit_report.json parity_plot.pdf
mpirun -np 10 esspy fc -p 'sample-*' --outcar 'OUTCAR-sample-*' --maxiter 2
mv charge_model.json charge_model.mpi.json

python - <<'PY'
import json, math
s = json.load(open("charge_model.serial.json"))
m = json.load(open("charge_model.mpi.json"))
assert s["charges"]["basis"] == m["charges"]["basis"]
# Compare fitted values with a small tolerance.
PY
```

Risks and guardrails:

- Shared filesystem writes can race. Rank 0 must be the only cache writer.
- `tqdm` from all ranks will make unreadable output. Disable tqdm on non-root.
- Broadcasting the full tensor is acceptable for current problem sizes:

```text
200 * 13 * 13 * 8 bytes ~= 270 kB
```

  For much larger datasets, switch to root-only optimizer with root holding the
  tensor and non-root ranks exiting after gather.
- Optimizer itself should remain root-only initially. Parallelizing objective
  evaluations is unnecessary once quadratic cache exists because evaluations are
  effectively instantaneous.

## 08. Add Allocation Feasibility Analyzer

Goal:

Determine whether global composition requires allocation search.

Files:

- Add `python/esspy/allocation_feasibility.py`
- Add `tests/test_allocation_feasibility.py`

Implementation:

- Add dataclasses:
  - `AllocationSiteGroup`
  - `AllocationFeasibilityResult`
- Add:
  - `analyze_site_allocation`
  - `analyze_site_allocation_from_payload`
  - `decide_allocation_pipeline`

Mode logic:

```text
0 feasible -> input error
1 feasible -> arrangement-only
>1 feasible -> allocation + arrangement
```

Tests:

```bash
python -m pytest tests/test_allocation_feasibility.py -q
```

Required test cases:

- disjoint allowed sets -> unique
- overlap and multiple -> multiple
- impossible composition -> none
- target-supercell scaling of site group capacities
- `composition.fractions` payload support
- `composition_by_site` bypasses allocation search

Implementation status:

- Added `python/esspy/allocation_feasibility.py` as a pure deterministic
  analyzer, independent of scoring or stochastic search.
- The analyzer normalizes global composition counts, supports
  `composition.fractions`, scales base `site_groups.count` to
  `structure.n_target_sites`, and enumerates integer site-composition tables
  under allowed-set and capacity constraints.
- The analyzer reports:
  - `none`: no feasible site allocation.
  - `unique`: exactly one feasible site allocation, so the later runtime can
    convert it to `composition_by_site` and run arrangement-only ESS.
  - `multiple`: at least two feasible site allocations, so allocation search is
    required before final ESS.
- `decide_allocation_pipeline` captures the intended mode decision:
  `composition_by_site` always means arrangement-only; otherwise feasibility
  status determines invalid/arrangement-only/allocation-plus-arrangement.

Validation command used:

```bash
python -m pytest -q tests/test_allocation_feasibility.py
```

## 09. Decide Arrangement-Only vs Allocation+Arrangement Mode

Goal:

Wire the feasibility analyzer into run setup.

Files:

- Update `python/esspy/run_outputs_impl.py`
- Possibly update `python/esspy/workflow.py`
- Add `tests/test_run_outputs_sitewise_ready.py` or a new test file

Implementation:

Add:

```python
decide_run_composition_mode(payload, structure, supercell_det)
```

Rules:

```python
if composition_by_site exists:
    arrangement_only
elif global composition has unique feasible allocation:
    derive composition_by_site
    arrangement_only
elif allocation block exists:
    allocation_plus_arrangement
else:
    strict error or legacy warning
```

Check:

- Site-wise YAML does not run allocation search.
- Global YAML with multiple allocations does run allocation search.

Tests:

```bash
python -m pytest tests/test_run_composition_mode.py -q
```

## 10. Add Native Generalized Swap Support For Explicit Site Indices

Goal:

Fix the `source_kind -> group` overwrite issue.

Files:

- Update `python/esspy/solve_generalized_swap.py`
- Update `cpp/core/include/ess/core.hpp`
- Update `cpp/core/src/solve_generalized_swap.cpp`
- Update `cpp/bindings/pybind_module.cpp`
- Update `tests/test_solve_generalized_swap.py`

Implementation:

- Add `site_indices: list[int]` to `GeneralizedSiteGroupRule`.
- pybind parses `site_indices`.
- C++ assignment:

```cpp
if any rule has site_indices:
    assign group_by_site by explicit indices
    reject duplicate assignment
else:
    legacy source_kind mapping
    reject duplicate source_kind
```

Check:

```bash
python -m pytest tests/test_solve_generalized_swap.py -q
```

Required test:

- Two groups both `source_kind=Cr`, different `site_indices`, no overwrite.

## 11. Make Allocation Capacity Derive From Site Indices

Goal:

Allocation optimizer uses group capacities from explicit membership.

Files:

- Update `python/esspy/allocation_optimize.py`
- Update `python/esspy/run_outputs_impl.py`
- Update tests around allocation optimizer

Implementation:

```python
if site_indices:
    base_capacity = len(site_indices)
else:
    base_capacity = count/source_kind legacy count
capacity = base_capacity * supercell_det
```

Check:

For `POSCAR-target` with 2x2x2:

```text
site1 capacity = 8 * 8 = 64
site2 capacity = 16 * 8 = 128
site3 capacity = 32 * 8 = 256
```

Tests:

```bash
python -m pytest tests/test_allocation_optimize.py -q
```

## 12. Add Charge Model/Site Metadata Validation

Goal:

Charge model keys remain stable but metadata helps users understand `site1/site2`.

Files:

- Update `python/esspy/fit_charge.py`
- Update charge-model loader in run path
- Update `tests/test_cli_fit_charge.py`

Implementation:

- Write optional `site_groups` metadata in `charge_model.json`.
- Validate charge model site keys exist in input site groups.
- Match by `site-001`/`site1` normalized key, not display label.

Check:

```bash
esspy run input.yaml --charge-model charge_model.json --guide-only
```

Expected:

- Logs mapped charges with site display metadata when available.

## 13. End-To-End Allocation/Run Validation

Goal:

Validate allocation-aware `esspy run` after the charge-fit cross-validation gate has passed.

Use the `charge_model.json` from step 07.

Commands:

```bash
cd /Users/bama/Dropbox/data/code/EwaldSolidSolution/esspy/develop/examples/site_grouping_wyckoff

esspy util site-groups POSCAR-target --mode element_wyckoff --symprec 0.1

esspy init -p POSCAR-target \
  --site-grouping element_wyckoff \
  --site-group-symprec 0.1 \
  --site-group-angle-tolerance 5.0 \
  --out input.yaml \
  --dim 1 1 1 \
  --composition Mn=1,Cr=20,Ni=1,Rh=1,Co=1,O=32 \
  --charges Mn=2,Cr=3,Ni=2,Rh=3,Co=2,O=-2 \
  --charge-basis element_site \
  --recipe Cr:Mn,Cr,Ni,Rh,Co \
  --recipe O:O \
  --selection-enabled false

esspy run input.yaml --guide-only --workdir guide-check
esspy sample input.yaml -n 3
```

Expected:

- `input.yaml` contains `Cr@a`, `Cr@d`, `O@e`.
- `guide-check` completes.
- samples contain `# site-001`, `# site-002`, `# site-003`.
- allocation-aware `esspy run input.yaml --charge-model samples/charge_model.json` can run after these checks.

## 14. Full Regression and Cleanup

Goal:

Ensure legacy behavior remains intact.

Commands:

```bash
python -m pytest -q
```

Additional checks:

- Existing CCS13 examples still run.
- Old YAML without `site_indices` still works when source kinds are unique.
- Old YAML with duplicate source kinds and no `site_indices` now fails clearly.

Documentation updates:

- Update `README.md` only if this feature becomes user-facing.
- Keep detailed development notes in this example folder.
