# Site Grouping Wyckoff Development Example

This folder is the development workspace for robust site grouping.

Detailed implementation checklist:

`IMPLEMENTATION_GUIDE.md`

Reference source:

`/Users/bama/Dropbox/data/[RESEARCH]/Ewha-CMSL/HEO-Raman/run-esspy/spinel-4-6-coord/product-run/CCS13/POSCAR-M`

Local target POSCAR:

`POSCAR-target`

## Why This Example Exists

`POSCAR-target` intentionally merges all cation source sites into one POSCAR source kind:

```text
Cr O
24 32
```

However, symmetry identifies two distinct cation environments:

```text
Cr@a: indices 0..7    site symmetry -43m
Cr@d: indices 8..23   site symmetry .-3m
O@e : indices 24..55  site symmetry .3m
```

This makes it the right regression example for the new site grouping design:

- POSCAR-kind grouping should produce two groups: `Cr(24)` and `O(32)`.
- Element + Wyckoff/orbit grouping should produce three groups: `Cr@a(8)`, `Cr@d(16)`, and `O@e(32)`.
- `esspy run` must preserve the `site_indices` written by wizard/init and must not collapse `Cr@a` and `Cr@d` back into one `Cr` group.

## Site-Grouping Inspection Commands

These are the main manual checks:

```bash
esspy util site-groups POSCAR-target --mode poscar_kind
esspy util site-groups POSCAR-target --mode element_wyckoff --symprec 0.1 --angle-tolerance 5.0
```

Expected `poscar_kind` result:

```text
site1: source=Cr, count=24, indices=0..23
site2: source=O,  count=32, indices=24..55
```

Expected `element_wyckoff` result:

```text
site1: Cr@a, source=Cr, count=8,  indices=0..7
site2: Cr@d, source=Cr, count=16, indices=8..23
site3: O@e,  source=O,  count=32, indices=24..55
```

Future wizard/init check:

```bash
esspy init -p POSCAR-target \
  --site-grouping element_wyckoff \
  --site-group-symprec 0.1 \
  --site-group-angle-tolerance 5.0 \
  --out input.yaml \
  ...
```

The generated YAML must include explicit `site_indices`:

```yaml
site_grouping:
  mode: element_wyckoff
  symprec: 0.1
  angle_tolerance: 5.0

site_groups:
  site1:
    source_kind: Cr
    count: 8
    site_indices: [0, 1, 2, 3, 4, 5, 6, 7]
    label:
      display: Cr@a
  site2:
    source_kind: Cr
    count: 16
    site_indices: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
    label:
      display: Cr@d
```

## Implementation Checklist

- [x] Add `python/esspy/site_grouping.py`.
- [x] Add `esspy util site-groups`.
- [x] Make wizard select between POSCAR-kind and Element + Wyckoff/orbit grouping.
- [x] Make `esspy init` generate the same YAML as wizard through CLI flags.
- [x] Validate `site_indices` at `esspy run` startup.
- [x] Propagate base `site_indices` through supercell expansion.
- [x] Update sample labels to use explicit site group membership.
- [x] Add deterministic allocation feasibility analyzer.
- [ ] Update generalized swap to avoid `source_kind -> group` overwrite.
- [ ] Wire feasibility analysis into run mode selection.
- [ ] Add end-to-end allocation/run validation with this `POSCAR-target` logic.

## Runtime Mode Distinction

This example should also validate the difference between two workflows.

### 1. Arrangement-Only

Use when site-wise composition is already fixed.

Expected YAML shape:

```yaml
composition_by_site:
  site1:
    Mn: 5
    Ni: 3
  site2:
    Cr: 15
    Rh: 5
    Co: 7
    Fe: 5
  site3:
    O: 64
allocation:
  mode: fixed_by_input
```

Expected runtime:

```text
validate site_indices -> fixed site-wise recipes -> standard ESS only
```

No rough allocation search should run.

### 2. Allocation + Arrangement

Use when only global composition is known.

Expected YAML shape:

```yaml
composition:
  Mn: 7
  Cr: 15
  Ni: 9
  Rh: 5
  Co: 7
  Fe: 5
  O: 64
allocation:
  time_budget_sec: 180
```

Expected runtime:

```text
validate site_indices -> rough ESS over candidate site allocations -> final ESS
```

This is the main target workflow for `POSCAR-target`, because it tests whether `Cr@a` and `Cr@d` can receive different optimized cation distributions even though both originate from POSCAR source kind `Cr`.

## Charge-Fit Validation Before Production Run

After `input.yaml` generation is implemented and `esspy sample` writes correct `# site-xxx` labels, validate the site-aware charge model before using allocation-aware `esspy run`.

Workflow:

```bash
esspy sample input.yaml -n 50
cd samples
macer relax -p sample-* --isif 0
esspy fc -p 'sample-*' --outcar 'OUTCAR-sample-*'
```

Expected outputs:

```text
charge_model.json
fit_report.json
parity_plot.pdf
ewald_quadratic_cache.npz
```

Convenience checks after fitting:

```bash
# Reuse fitted site-aware charges written into POSCAR title metadata.
esspy ewald -p 'sample-*'

# Or apply the fitted model explicitly.
esspy ewald -p 'sample-*' --charge-model charge_model.json
```

The key check is whether fitted site-aware Ewald energy tracks the uMLFF total energy better than the default charge model.

Only after this parity check is acceptable should the workflow proceed to:

```bash
esspy run input.yaml --charge-model samples/charge_model.json
```

## Recipe Interpretation

Recipes define allowed occupancy, not fixed site composition.

Example:

```text
site1 -> Mn, Cr, Ni, Rh, Co
site2 -> Mn, Cr
site3 -> O
```

If composition is site-wise, allocation is already fixed:

```text
composition_by_site present -> arrangement-only
```

If composition is global, `esspy` must check whether the allowed sets and capacities imply a unique site composition:

```text
global composition + one feasible site allocation  -> arrangement-only
global composition + multiple feasible allocations -> allocation + arrangement
global composition + no feasible allocation        -> input error
```

For this example, `Mn` and `Cr` can both move between cation site groups when both are allowed on both relevant groups. In that case the site allocation is a real optimization variable and should be searched before final ESS arrangement optimization.

Implementation note:

Before running stochastic allocation search, `esspy` should run a deterministic feasibility analyzer:

```python
if composition_by_site exists:
    pipeline = "arrangement_only"
else:
    analysis = analyze_site_allocation(global_composition, site_groups)
    if analysis.status == "none":
        raise InputError
    if analysis.status == "unique":
        composition_by_site = analysis.only_solution
        pipeline = "arrangement_only"
    else:
        pipeline = "allocation_plus_arrangement"
```

This analyzer belongs in a dedicated module such as:

```text
python/esspy/allocation_feasibility.py
```

It should enumerate integer site-composition tables subject to:

```text
sum_e x[group, element] = capacity[group]
sum_g x[group, element] = global_count[element]
x[group, element] = 0 when element is not allowed in group
```
