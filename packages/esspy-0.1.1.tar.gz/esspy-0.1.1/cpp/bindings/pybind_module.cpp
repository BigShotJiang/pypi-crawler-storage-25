#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <cmath>
#include <stdexcept>

#include "ess/core.hpp"
#include "ess/guide_add_ions.hpp"
#include "ess/guide_poscar_writer.hpp"
#include "ess/guide_ready_writer.hpp"
#include "ess/guide_recipe_allocation.hpp"
#include "ess/guide_supercell.hpp"
#include "ess/solve_candidate_decode.hpp"
#include "ess/solve_global_reduction.hpp"
#include "ess/solve_generalized_swap.hpp"
#include "ess/solve_swap_loop.hpp"
#include "ess/solve_search_space.hpp"
#include "ess/add_sites_mc.hpp"
#include "ess/add_sites_text_adapter.hpp"
#include "ess/guider_normalize.hpp"
#include "ess/guider_text_adapter.hpp"
#include "ess/wyc_adapter.hpp"

namespace py = pybind11;
using namespace py::literals;

namespace {

std::function<bool()> make_python_cancel_callback() {
  return []() {
    py::gil_scoped_acquire gil;
    if (PyErr_CheckSignals() != 0) {
      throw py::error_already_set();
    }
    return false;
  };
}

std::function<unsigned long long(int, unsigned long long)>
make_mpi_adaptive_stride_sync_callback() {
  py::gil_scoped_acquire gil;
  try {
    py::object mpi = py::module_::import("mpi4py.MPI");
    py::object comm = mpi.attr("COMM_WORLD");
    const int size = comm.attr("Get_size")().cast<int>();
    if (size <= 1) {
      return {};
    }
    return [comm](int monitoring_index, unsigned long long local_stride) {
      py::gil_scoped_acquire gil;
      if (PyErr_CheckSignals() != 0) {
        throw py::error_already_set();
      }
      py::object synced = comm.attr("bcast")(
          py::int_(local_stride), py::arg("root") = 0);
      return synced.cast<unsigned long long>();
    };
  } catch (const py::error_already_set&) {
    PyErr_Clear();
    return {};
  }
}

std::function<ess::DynamicChunkDecision(
    unsigned long long, int, bool, unsigned long long)>
make_mpi_dynamic_chunk_sync_callback() {
  py::gil_scoped_acquire gil;
  try {
    py::object mpi = py::module_::import("mpi4py.MPI");
    py::object comm = mpi.attr("COMM_WORLD");
    const int size = comm.attr("Get_size")().cast<int>();
    const int rank = comm.attr("Get_rank")().cast<int>();
    if (size <= 1) {
      return {};
    }
    auto cursor = std::make_shared<unsigned long long>(0ULL);
    return [comm, size, rank, cursor](
               unsigned long long current_offset,
               int current_limit,
               bool local_has_more,
               unsigned long long available_count) {
      py::gil_scoped_acquire gil;
      if (PyErr_CheckSignals() != 0) {
        throw py::error_already_set();
      }

      py::dict local;
      local["rank"] = py::int_(rank);
      local["current_offset"] = py::int_(current_offset);
      local["current_limit"] = py::int_(current_limit);
      local["local_has_more"] = py::bool_(local_has_more);
      local["available_count"] = py::int_(available_count);
      py::list gathered =
          comm.attr("allgather")(local).cast<py::list>();

      std::vector<py::dict> assignments(static_cast<std::size_t>(size));
      if (rank == 0) {
        if (*cursor >= available_count) {
          for (int i = 0; i < size; ++i) {
            py::dict entry;
            entry["offset"] = py::int_(*cursor);
            entry["chunk_limit"] = py::int_(0);
            entry["has_more"] = py::bool_(false);
            assignments[static_cast<std::size_t>(i)] = std::move(entry);
          }
        } else {
          for (int i = 0; i < size; ++i) {
            py::dict req = gathered[static_cast<py::ssize_t>(i)].cast<py::dict>();
            const bool req_has_more = req["local_has_more"].cast<bool>();
            int req_limit = req["current_limit"].cast<int>();
            if (req_limit < 1) {
              req_limit = 1;
            }
            py::dict entry;
            if (!req_has_more || *cursor >= available_count) {
              entry["offset"] = py::int_(*cursor);
              entry["chunk_limit"] = py::int_(0);
              entry["has_more"] = py::bool_(false);
            } else {
              const unsigned long long start = *cursor;
              const unsigned long long remaining = available_count - start;
              const unsigned long long take =
                  std::min<unsigned long long>(
                      remaining, static_cast<unsigned long long>(req_limit));
              entry["offset"] = py::int_(start);
              entry["chunk_limit"] = py::int_(static_cast<int>(take));
              entry["has_more"] = py::bool_(take > 0);
              *cursor += take;
            }
            assignments[static_cast<std::size_t>(i)] = std::move(entry);
          }
        }
      }

      py::object synced = comm.attr("bcast")(
          py::cast(assignments), py::arg("root") = 0);
      py::list synced_list = synced.cast<py::list>();
      py::dict mine = synced_list[static_cast<py::ssize_t>(rank)].cast<py::dict>();
      ess::DynamicChunkDecision decision;
      decision.offset = mine["offset"].cast<unsigned long long>();
      decision.chunk_limit = mine["chunk_limit"].cast<int>();
      decision.has_more = mine["has_more"].cast<bool>();
      return decision;
    };
  } catch (const py::error_already_set&) {
    PyErr_Clear();
    return {};
  }
}

template <typename T>
T require(const py::dict& source, const char* key) {
  if (!source.contains(py::str(key))) {
    throw std::runtime_error(std::string("Missing required key: ") + key);
  }
  return py::cast<T>(source[py::str(key)]);
}

py::dict structure_dict(const ess::StructureModel& value);

std::array<long double, 3> to_vec3(const py::handle& value) {
  auto seq = py::cast<py::sequence>(value);
  if (py::len(seq) != 3) {
    throw std::runtime_error("Expected length-3 sequence");
  }
  return {
      py::cast<long double>(seq[0]),
      py::cast<long double>(seq[1]),
      py::cast<long double>(seq[2]),
  };
}

ess::Lattice parse_lattice(const py::dict& value) {
  ess::Lattice lattice;
  lattice.a = to_vec3(value[py::str("a")]);
  lattice.b = to_vec3(value[py::str("b")]);
  lattice.c = to_vec3(value[py::str("c")]);
  return lattice;
}

ess::Site parse_site(const py::dict& value) {
  ess::Site site;
  site.kind = require<std::string>(value, "kind");
  site.x = require<long double>(value, "x");
  site.y = require<long double>(value, "y");
  site.z = require<long double>(value, "z");
  if (value.contains(py::str("oxidation"))) {
    site.oxidation = py::cast<long double>(value[py::str("oxidation")]);
  }
  return site;
}

ess::StructureModel parse_structure(const py::dict& value) {
  ess::StructureModel structure;
  structure.title = require<std::string>(value, "title");
  structure.lattice = parse_lattice(py::cast<py::dict>(value[py::str("lattice")]));
  structure.fractional_coordinates =
      value.contains(py::str("fractional_coordinates"))
          ? py::cast<bool>(value[py::str("fractional_coordinates")])
          : true;
  for (const auto& item : py::cast<py::list>(value[py::str("sites")])) {
    structure.sites.push_back(parse_site(py::cast<py::dict>(item)));
  }
  return structure;
}

ess::CompositionModel parse_composition(const py::dict& value) {
  ess::CompositionModel composition;
  composition.n_target_sites = require<int>(value, "n_target_sites");
  if (value.contains(py::str("number_fixed_at"))) {
    composition.number_fixed_at =
        py::cast<std::string>(value[py::str("number_fixed_at")]);
  }
  for (const auto& item : py::cast<py::list>(value[py::str("entries")])) {
    auto dict = py::cast<py::dict>(item);
    composition.entries.push_back(
        ess::CompositionEntry{require<std::string>(dict, "kind"),
                              require<int>(dict, "count")});
  }
  return composition;
}

ess::ChargeMap parse_charges(const py::dict& value) {
  ess::ChargeMap charges;
  for (const auto& item : py::cast<py::list>(value[py::str("values")])) {
    auto dict = py::cast<py::dict>(item);
    charges.values.push_back(
        ess::ChargeEntry{require<std::string>(dict, "kind"),
                         require<long double>(dict, "oxidation")});
  }
  return charges;
}

ess::RecipeSpec parse_recipe_spec(const py::dict& value) {
  ess::RecipeSpec recipe;
  if (value.contains(py::str("from_kind"))) {
    recipe.from = py::cast<std::string>(value[py::str("from_kind")]);
  } else {
    recipe.from = require<std::string>(value, "from");
  }
  recipe.to = require<std::vector<std::string>>(value, "to");
  return recipe;
}

ess::SymmetryModel parse_symmetry(const py::dict& value) {
  ess::SymmetryModel symmetry;
  if (value.contains(py::str("space_group"))) {
    symmetry.space_group = py::cast<int>(value[py::str("space_group")]);
  }
  if (value.contains(py::str("from_spglib"))) {
    symmetry.from_spglib = py::cast<bool>(value[py::str("from_spglib")]);
  }
  if (value.contains(py::str("wyc_operations"))) {
    for (const auto& item : py::cast<py::list>(value[py::str("wyc_operations")])) {
      py::sequence rows;
      if (py::isinstance<py::dict>(item)) {
        auto dict_item = py::cast<py::dict>(item);
        if (!dict_item.contains(py::str("matrix"))) {
          throw std::runtime_error(
              "wyc_operations dict entry must contain `matrix`");
        }
        rows = py::cast<py::sequence>(dict_item[py::str("matrix")]);
      } else {
        rows = py::cast<py::sequence>(item);
      }
      if (py::len(rows) != 3) {
        throw std::runtime_error("wyc_operations entry must have exactly 3 rows");
      }
      ess::SymmetryOperation operation;
      for (int row = 0; row < 3; ++row) {
        auto cols = py::cast<py::sequence>(rows[row]);
        if (py::len(cols) != 4) {
          throw std::runtime_error("wyc_operations row must have exactly 4 columns");
        }
        for (int col = 0; col < 4; ++col) {
          operation.matrix[row][col] = py::cast<long double>(cols[col]);
        }
      }
      symmetry.wyc_operations.push_back(operation);
    }
  }
  return symmetry;
}

ess::GuideOptions parse_guide_options(const py::dict& value) {
  ess::GuideOptions options;
  if (value.contains(py::str("n_random_seeds"))) {
    options.n_random_seeds = py::cast<int>(value[py::str("n_random_seeds")]);
  }
  if (value.contains(py::str("shell_width"))) {
    options.shell_width = py::cast<long double>(value[py::str("shell_width")]);
  }
  if (value.contains(py::str("wyc_identity_length"))) {
    options.wyc_identity_length =
        py::cast<long double>(value[py::str("wyc_identity_length")]);
  }
  if (value.contains(py::str("abc_weights"))) {
    options.abc_weights = to_vec3(value[py::str("abc_weights")]);
  }
  if (value.contains(py::str("chop_level"))) {
    options.chop_level = py::cast<long double>(value[py::str("chop_level")]);
  }
  if (value.contains(py::str("target_cpu_time_sec"))) {
    options.target_cpu_time_sec =
        py::cast<int>(value[py::str("target_cpu_time_sec")]);
  }
  if (value.contains(py::str("strict_no_added_sites"))) {
    options.strict_no_added_sites =
        py::cast<bool>(value[py::str("strict_no_added_sites")]);
  }
  if (value.contains(py::str("skip_rg_optimization"))) {
    options.skip_rg_optimization =
        py::cast<bool>(value[py::str("skip_rg_optimization")]);
  }
  if (value.contains(py::str("skip_ewald_evaluation"))) {
    options.skip_ewald_evaluation =
        py::cast<bool>(value[py::str("skip_ewald_evaluation")]);
  }
  if (value.contains(py::str("fixed_rg_find_factor")) &&
      !value[py::str("fixed_rg_find_factor")].is_none()) {
    options.fixed_rg_find_factor =
        py::cast<int>(value[py::str("fixed_rg_find_factor")]);
  }
  return options;
}

py::dict solve_progress_event_dict(const ess::SolveProgressEvent& event) {
  return py::dict(
      "stage"_a = event.stage,
      "rank"_a = event.rank,
      "world_size"_a = event.world_size,
      "processed_chunks"_a = event.processed_chunks,
      "processed_candidates"_a = event.processed_candidates,
      "next_offset"_a = event.next_offset,
      "available_count"_a = event.available_count,
      "has_more"_a = event.has_more,
      "local_e_min"_a = event.local_e_min,
      "local_e_max"_a = event.local_e_max,
      "monitoring_index"_a = event.monitoring_index,
      "adaptive_stride"_a = event.adaptive_stride,
      "active_stride"_a = event.active_stride,
      "secondary_recipe_index"_a = event.secondary_recipe_index,
      "secondary_index"_a = event.secondary_index,
      "secondary_jobsize"_a = event.secondary_jobsize,
      "elapsed_sec"_a = event.elapsed_sec,
      "best_structure"_a = structure_dict(event.best_structure),
      "best_structure_present"_a = event.best_structure_present);
}

ess::GuideInput parse_guide_input(const py::dict& value) {
  ess::GuideInput input;
  input.structure = parse_structure(py::cast<py::dict>(value[py::str("structure")]));
  input.composition =
      parse_composition(py::cast<py::dict>(value[py::str("composition")]));
  input.charges = parse_charges(py::cast<py::dict>(value[py::str("charges")]));
  for (const auto& item : py::cast<py::list>(value[py::str("recipes")])) {
    input.recipes.push_back(parse_recipe_spec(py::cast<py::dict>(item)));
  }
  if (value.contains(py::str("supercell_expansion")) &&
      !value[py::str("supercell_expansion")].is_none()) {
    auto seq = py::cast<py::sequence>(value[py::str("supercell_expansion")]);
    if (py::len(seq) != 3) {
      throw std::runtime_error("supercell_expansion must be a length-3 sequence");
    }
    input.has_supercell_expansion = true;
    input.supercell_expansion = {
        py::cast<int>(seq[0]), py::cast<int>(seq[1]), py::cast<int>(seq[2])};
    for (const int value : input.supercell_expansion) {
      if (value <= 0) {
        throw std::runtime_error("supercell_expansion values must be positive");
      }
    }
  }
  if (value.contains(py::str("symmetry"))) {
    input.symmetry = parse_symmetry(py::cast<py::dict>(value[py::str("symmetry")]));
  }
  if (value.contains(py::str("options"))) {
    input.options =
        parse_guide_options(py::cast<py::dict>(value[py::str("options")]));
  }
  return input;
}

ess::SolveOptions parse_solve_options(const py::dict& value) {
  ess::SolveOptions options;
  options.verbose = value.contains("verbose") ? value["verbose"].cast<bool>() : false;
  options.create_recipe_strict_mode = value.contains("create_recipe_strict_mode") ? value["create_recipe_strict_mode"].cast<bool>() : false;
  options.print_stablest_unstablest = value.contains("print_stablest_unstablest") ? value["print_stablest_unstablest"].cast<bool>() : false;
  options.running_index_delta = value.contains("running_index_delta") ? value["running_index_delta"].cast<long long>() : 10000;
  options.running_index_monitor = value.contains("running_index_monitor") ? value["running_index_monitor"].cast<int>() : 10000;
  options.local_enumeration_offset = value.contains("local_enumeration_offset") ? value["local_enumeration_offset"].cast<unsigned long long>() : 0;
  options.local_enumeration_limit = value.contains("local_enumeration_limit") ? value["local_enumeration_limit"].cast<int>() : 32;
  options.local_enumeration_max_chunks = value.contains("local_enumeration_max_chunks") ? value["local_enumeration_max_chunks"].cast<int>() : 1;
  if (options.running_index_delta < 0) {
    options.local_enumeration_stride = 1;
  } else {
    options.local_enumeration_stride = value.contains("local_enumeration_stride") ? value["local_enumeration_stride"].cast<unsigned long long>() : 1;
  }
  if (options.running_index_delta > 1 &&
      !value.contains("local_enumeration_stride") &&
      value.contains("running_index_delta") &&
      options.local_enumeration_stride == 1) {
    options.local_enumeration_stride =
        static_cast<unsigned long long>(options.running_index_delta);
  }
  options.enumeration_exhaust_all = value.contains("enumeration_exhaust_all") ? value["enumeration_exhaust_all"].cast<bool>() : false;
  options.enumeration_save_memory = value.contains("enumeration_save_memory") ? value["enumeration_save_memory"].cast<bool>() : false;
  options.mpi_adaptive_stride_sync = value.contains("mpi_adaptive_stride_sync") ? value["mpi_adaptive_stride_sync"].cast<bool>() : false;
  options.mpi_dynamic_chunking = value.contains("mpi_dynamic_chunking") ? value["mpi_dynamic_chunking"].cast<bool>() : false;
  options.mpi_chunk_min = value.contains("mpi_chunk_min") ? value["mpi_chunk_min"].cast<unsigned long long>() : 512;
  options.mpi_chunk_max = value.contains("mpi_chunk_max") ? value["mpi_chunk_max"].cast<unsigned long long>() : 20000;
  options.mpi_scheduler_heartbeat = value.contains("mpi_scheduler_heartbeat") ? value["mpi_scheduler_heartbeat"].cast<int>() : 16;
  options.adaptive_stride_override_9 = value.contains("adaptive_stride_override_9") ? value["adaptive_stride_override_9"].cast<unsigned long long>() : 0;
  options.adaptive_stride_override_19 = value.contains("adaptive_stride_override_19") ? value["adaptive_stride_override_19"].cast<unsigned long long>() : 0;
  options.adaptive_stride_scale_secondary = value.contains("adaptive_stride_scale_secondary") ? value["adaptive_stride_scale_secondary"].cast<bool>() : true;
  options.swap = value.contains("swap") ? value["swap"].cast<bool>() : true;
  options.max_swap = value.contains("max_swap") ? value["max_swap"].cast<int>() : 2;
  options.swap_loop_enabled = value.contains("swap_loop_enabled") ? value["swap_loop_enabled"].cast<bool>() : options.swap;
  options.swap_loop_mode = value.contains("swap_loop_mode") ? value["swap_loop_mode"].cast<int>() : 1;
  options.swap_loop_seed_source = value.contains("swap_loop_seed_source") ? value["swap_loop_seed_source"].cast<int>() : 1;
  if (value.contains("swap_loop_starting_sites")) {
    for (const auto& item :
         py::cast<py::list>(value["swap_loop_starting_sites"])) {
      options.swap_loop_starting_sites.push_back(
          parse_site(py::cast<py::dict>(item)));
    }
  }
  options.progress_include_best_structure = value.contains("progress_include_best_structure")
      ? value["progress_include_best_structure"].cast<bool>()
      : false;
  
  if (value.contains("restart_recipe_filename")) {
    options.restart_recipe_filename = value["restart_recipe_filename"].cast<std::string>();
  }
  if (value.contains("progress_callback") &&
      !value["progress_callback"].is_none()) {
    py::object callback = py::reinterpret_borrow<py::object>(
        value["progress_callback"]);
    if (!PyCallable_Check(callback.ptr())) {
      throw std::runtime_error("progress_callback must be callable");
    }
    options.progress_callback = [callback](const ess::SolveProgressEvent& event) {
      py::gil_scoped_acquire gil;
      callback(solve_progress_event_dict(event));
      if (PyErr_CheckSignals() != 0) {
        throw py::error_already_set();
      }
    };
  }
  return options;
}

ess::ParallelRuntimeOptions parse_runtime(const py::dict& value) {
  ess::ParallelRuntimeOptions runtime;
  if (value.contains(py::str("use_mpi"))) {
    runtime.use_mpi = py::cast<bool>(value[py::str("use_mpi")]);
  }
  if (value.contains(py::str("world_size"))) {
    runtime.world_size = py::cast<int>(value[py::str("world_size")]);
  }
  if (value.contains(py::str("rank"))) {
    runtime.rank = py::cast<int>(value[py::str("rank")]);
  }
  return runtime;
}

ess::ReadyModel parse_ready(const py::dict& value) {
  ess::ReadyModel ready;
  ready.lattice = parse_lattice(py::cast<py::dict>(value[py::str("lattice")]));
  ready.supercell_expansion = {
      py::cast<int>(py::cast<py::sequence>(value[py::str("supercell_expansion")])[0]),
      py::cast<int>(py::cast<py::sequence>(value[py::str("supercell_expansion")])[1]),
      py::cast<int>(py::cast<py::sequence>(value[py::str("supercell_expansion")])[2]),
  };
  ready.rg_find_factor = require<int>(value, "rg_find_factor");
  if (value.contains(py::str("chop_level"))) {
    ready.chop_level = py::cast<long double>(value[py::str("chop_level")]);
  }
  ready.output_prefix = require<std::string>(value, "output_prefix");
  if (value.contains(py::str("poscar_species_counts"))) {
    for (const auto& item :
         py::cast<py::list>(value[py::str("poscar_species_counts")])) {
      auto dict = py::cast<py::dict>(item);
      ready.poscar_species_counts.push_back(
          ess::CompositionEntry{require<std::string>(dict, "kind"),
                                require<int>(dict, "count")});
    }
  }
  for (const auto& item : py::cast<py::list>(value[py::str("atoms")])) {
    auto dict = py::cast<py::dict>(item);
    ess::ReadyAtom atom;
    atom.kind = require<std::string>(dict, "kind");
    atom.oxidation = require<long double>(dict, "oxidation");
    atom.x = require<long double>(dict, "x");
    atom.y = require<long double>(dict, "y");
    atom.z = require<long double>(dict, "z");
    ready.atoms.push_back(atom);
  }
  for (const auto& item : py::cast<py::list>(value[py::str("recipes")])) {
    auto dict = py::cast<py::dict>(item);
    ess::ReadyRecipe recipe;
    if (dict.contains(py::str("from_kind"))) {
      recipe.from = py::cast<std::string>(dict[py::str("from_kind")]);
    } else {
      recipe.from = require<std::string>(dict, "from");
    }
    recipe.oxidation = require<long double>(dict, "oxidation");
    recipe.random_pickup = require<int>(dict, "random_pickup");
    recipe.random_pickup_trial = require<int>(dict, "random_pickup_trial");
    for (const auto& mod_item : py::cast<py::list>(dict[py::str("modifications")])) {
      auto mod = py::cast<py::dict>(mod_item);
      std::string to = mod.contains(py::str("to"))
                           ? py::cast<std::string>(mod[py::str("to")])
                           : py::cast<std::string>(mod[py::str("kind")]);
      recipe.modifications.push_back(ess::ReadyRecipeModification{
          to,
          require<long double>(mod, "oxidation"),
          require<int>(mod, "count"),
      });
    }
    ready.recipes.push_back(recipe);
  }
  return ready;
}

ess::SolveInput parse_solve_input(const py::dict& value) {
  ess::SolveInput input;
  input.ready = parse_ready(py::cast<py::dict>(value[py::str("ready")]));
  if (value.contains(py::str("options"))) {
    input.options = parse_solve_options(py::cast<py::dict>(value[py::str("options")]));
  }
  if (value.contains(py::str("runtime"))) {
    input.runtime = parse_runtime(py::cast<py::dict>(value[py::str("runtime")]));
  }
  return input;
}

ess::RunInput parse_run_input(const py::dict& value) {
  ess::RunInput input;
  input.guide = parse_guide_input(py::cast<py::dict>(value[py::str("guide")]));
  if (value.contains(py::str("solve"))) {
    input.solve = parse_solve_options(py::cast<py::dict>(value[py::str("solve")]));
  }
  if (value.contains(py::str("runtime"))) {
    input.runtime = parse_runtime(py::cast<py::dict>(value[py::str("runtime")]));
  }
  return input;
}

py::dict lattice_dict(const ess::Lattice& value) {
  return py::dict("a"_a = value.a, "b"_a = value.b, "c"_a = value.c);
}

py::dict structure_dict(const ess::StructureModel& value) {
  py::list sites;
  for (const auto& site : value.sites) {
    sites.append(py::dict("kind"_a = site.kind,
                          "x"_a = site.x,
                          "y"_a = site.y,
                          "z"_a = site.z,
                          "oxidation"_a = site.oxidation));
  }
  return py::dict("title"_a = value.title,
                  "lattice"_a = lattice_dict(value.lattice),
                  "sites"_a = sites,
                  "fractional_coordinates"_a = value.fractional_coordinates);
}

py::dict composition_dict(const ess::CompositionModel& value) {
  py::list entries;
  for (const auto& entry : value.entries) {
    entries.append(py::dict("kind"_a = entry.kind, "count"_a = entry.count));
  }
  return py::dict("entries"_a = entries,
                  "n_target_sites"_a = value.n_target_sites,
                  "number_fixed_at"_a = value.number_fixed_at);
}

py::dict charge_map_dict(const ess::ChargeMap& value) {
  py::list values;
  for (const auto& entry : value.values) {
    values.append(py::dict("kind"_a = entry.kind, "oxidation"_a = entry.oxidation));
  }
  return py::dict("values"_a = values);
}

py::dict recipe_spec_dict(const ess::RecipeSpec& value) {
  return py::dict("from"_a = value.from, "to"_a = value.to);
}

py::dict energy_table_dict(const ess::EnergyTable& table) {
  return py::dict(
      "count"_a = static_cast<unsigned long long>(table.count),
      "sum_e"_a = table.sum_e,
      "sum_e2"_a = table.sum_e2,
      "min_e"_a = table.min_e,
      "max_e"_a = table.max_e);
}

ess::EnergyTable parse_energy_table(const py::dict& value) {
  ess::EnergyTable table;
  if (value.contains(py::str("count"))) {
    table.count = py::cast<unsigned long long>(value[py::str("count")]);
  }
  if (value.contains(py::str("sum_e"))) {
    table.sum_e = py::cast<long double>(value[py::str("sum_e")]);
  }
  if (value.contains(py::str("sum_e2"))) {
    table.sum_e2 = py::cast<long double>(value[py::str("sum_e2")]);
  }
  if (value.contains(py::str("min_e"))) {
    table.min_e = py::cast<long double>(value[py::str("min_e")]);
  }
  if (value.contains(py::str("max_e"))) {
    table.max_e = py::cast<long double>(value[py::str("max_e")]);
  }
  return table;
}

py::dict symmetry_dict(const ess::SymmetryModel& value) {
  py::list operations;
  for (const auto& op : value.wyc_operations) {
    operations.append(op.matrix);
  }
  return py::dict("space_group"_a = value.space_group,
                  "wyc_operations"_a = operations,
                  "from_spglib"_a = value.from_spglib);
}

py::dict guide_options_dict(const ess::GuideOptions& value) {
  py::dict result("n_random_seeds"_a = value.n_random_seeds,
                  "shell_width"_a = value.shell_width,
                  "wyc_identity_length"_a = value.wyc_identity_length,
                  "abc_weights"_a = value.abc_weights,
                  "chop_level"_a = value.chop_level,
                  "target_cpu_time_sec"_a = value.target_cpu_time_sec,
                  "strict_no_added_sites"_a = value.strict_no_added_sites,
                  "skip_rg_optimization"_a = value.skip_rg_optimization,
                  "skip_ewald_evaluation"_a = value.skip_ewald_evaluation);
  if (value.fixed_rg_find_factor > 0) {
    result["fixed_rg_find_factor"] = value.fixed_rg_find_factor;
  } else {
    result["fixed_rg_find_factor"] = py::none();
  }
  return result;
}

py::dict guide_input_dict(const ess::GuideInput& value) {
  py::list recipes;
  for (const auto& recipe : value.recipes) {
    recipes.append(recipe_spec_dict(recipe));
  }
  py::dict result("structure"_a = structure_dict(value.structure),
                  "composition"_a = composition_dict(value.composition),
                  "charges"_a = charge_map_dict(value.charges),
                  "recipes"_a = recipes,
                  "symmetry"_a = symmetry_dict(value.symmetry),
                  "options"_a = guide_options_dict(value.options));
  if (value.has_supercell_expansion) {
    result["supercell_expansion"] = value.supercell_expansion;
  } else {
    result["supercell_expansion"] = py::none();
  }
  return result;
}

py::dict run_input_dict(const ess::RunInput& value) {
  return py::dict("guide"_a = guide_input_dict(value.guide),
                  "solve"_a = py::dict(),
                  "runtime"_a = py::dict("use_mpi"_a = value.runtime.use_mpi,
                                         "world_size"_a = value.runtime.world_size,
                                         "rank"_a = value.runtime.rank));
}

py::dict ready_dict(const ess::ReadyModel& value) {
  py::list atoms;
  for (const auto& atom : value.atoms) {
    atoms.append(py::dict("kind"_a = atom.kind,
                          "oxidation"_a = atom.oxidation,
                          "x"_a = atom.x,
                          "y"_a = atom.y,
                          "z"_a = atom.z));
  }
  py::list poscar_species_counts;
  for (const auto& entry : value.poscar_species_counts) {
    poscar_species_counts.append(
        py::dict("kind"_a = entry.kind, "count"_a = entry.count));
  }
  py::list recipes;
  for (const auto& recipe : value.recipes) {
    py::list mods;
    for (const auto& mod : recipe.modifications) {
      mods.append(py::dict("to"_a = mod.to,
                           "oxidation"_a = mod.oxidation,
                           "count"_a = mod.number));
    }
    recipes.append(py::dict("from"_a = recipe.from,
                            "oxidation"_a = recipe.oxidation,
                            "random_pickup"_a = recipe.random_pickup,
                            "random_pickup_trial"_a = recipe.random_pickup_trial,
                            "modifications"_a = mods));
  }
  return py::dict("lattice"_a = lattice_dict(value.lattice),
                  "atoms"_a = atoms,
                  "poscar_species_counts"_a = poscar_species_counts,
                  "supercell_expansion"_a = value.supercell_expansion,
                  "rg_find_factor"_a = value.rg_find_factor,
                  "chop_level"_a = value.chop_level,
                  "output_prefix"_a = value.output_prefix,
                  "recipes"_a = recipes);
}

py::dict guide_result_dict(const ess::GuideResult& value) {
  py::list assignments;
  for (const auto& assignment : value.diagnostics.resolved_assignments) {
    py::list assigned_counts;
    for (const auto& item : assignment.assigned_counts) {
      assigned_counts.append(py::dict("kind"_a = item.kind, "count"_a = item.count));
    }
    assignments.append(py::dict("from"_a = assignment.from,
                                "assigned_counts"_a = assigned_counts));
  }
  return py::dict(
      "ready"_a = ready_dict(value.ready),
      "diagnostics"_a = py::dict(
          "n_atom_config"_a = value.diagnostics.n_atom_config,
          "supercell_expansion"_a = value.diagnostics.supercell_expansion,
          "rg_find_factor"_a = value.diagnostics.rg_find_factor,
          "resolved_assignments"_a = assignments,
          "messages"_a = value.diagnostics.messages));
}

py::dict solve_result_dict(const ess::SolveResult& value) {
  auto snapshot_to_dict = [](const ess::StructureSnapshot& snapshot) {
    return py::dict("structure"_a = structure_dict(snapshot.structure),
                    "energy"_a = snapshot.energy,
                    "label"_a = snapshot.label);
  };
  py::list search_space_entries;
  for (const auto& entry : value.search_space.entries) {
    py::list assigned_counts;
    for (const auto& count : entry.assigned_counts) {
      assigned_counts.append(py::dict("kind"_a = count.kind, "count"_a = count.count));
    }
    search_space_entries.append(py::dict(
        "from"_a = entry.from,
        "random_pickup"_a = entry.random_pickup,
        "random_pickup_trial"_a = entry.random_pickup_trial,
        "unchanged_count"_a = entry.unchanged_count,
        "assigned_counts"_a = assigned_counts,
        "jobsize_u64"_a = entry.jobsize_u64,
        "jobsize_ld"_a = entry.jobsize_ld,
        "jobsize_saturated"_a = entry.jobsize_saturated,
        "first_candidate_indices"_a = entry.first_candidate_indices,
        "first_candidate_labels"_a = entry.first_candidate_labels,
        "candidate_count_log10"_a = entry.candidate_count_log10));
  }
  py::list recipe_ranges;
  for (const auto& range : value.search_space.work_slice.recipe_ranges) {
    recipe_ranges.append(py::dict(
        "recipe_index"_a = range.recipe_index,
        "start"_a = range.start,
        "end"_a = range.end));
  }
  py::list primary_slice_candidates;
  for (const auto& candidate : value.search_space.primary_slice_window.candidates) {
    primary_slice_candidates.append(py::dict(
        "candidate_index"_a = candidate.candidate_index,
        "candidate_indices"_a = candidate.candidate_indices,
        "candidate_labels"_a = candidate.candidate_labels));
  }
  py::list window_evaluation_entries;
  for (const auto& entry : value.window_evaluation.entries) {
    window_evaluation_entries.append(py::dict(
        "candidate_index"_a = entry.candidate_index,
        "energy"_a = entry.energy,
        "candidate_indices"_a = entry.candidate_indices,
        "candidate_labels"_a = entry.candidate_labels,
        "snapshot"_a = snapshot_to_dict(entry.snapshot)));
  }
  return py::dict(
      "summary"_a = py::dict(
          "global_e_min"_a = value.summary.global_e_min,
          "global_e_max"_a = value.summary.global_e_max,
          "total_cpu_time"_a = value.summary.total_cpu_time,
          "global_count_total"_a = value.summary.global_count_total),
      "energy_table"_a = energy_table_dict(value.energy_table),
      "search_space"_a = py::dict(
          "entries"_a = search_space_entries,
          "primary_recipe_index"_a = value.search_space.primary_recipe_index,
          "total_candidate_count_log10"_a =
              value.search_space.total_candidate_count_log10,
          "work_slice"_a = py::dict(
              "integer_job"_a = value.search_space.work_slice.integer_job,
              "primary_recipe_index"_a =
                  value.search_space.work_slice.primary_recipe_index,
              "world_size"_a = value.search_space.work_slice.world_size,
              "rank"_a = value.search_space.work_slice.rank,
              "has_saturated_jobsize"_a =
                  value.search_space.work_slice.has_saturated_jobsize,
              "recipe_ranges"_a = recipe_ranges),
          "first_enumeration"_a = py::dict(
              "recipe_index"_a = value.search_space.first_enumeration.recipe_index,
              "candidate_index"_a =
                  value.search_space.first_enumeration.candidate_index,
              "candidate_indices"_a =
                  value.search_space.first_enumeration.candidate_indices,
              "candidate_labels"_a =
                  value.search_space.first_enumeration.candidate_labels),
          "primary_slice_window"_a = py::dict(
              "recipe_index"_a = value.search_space.primary_slice_window.recipe_index,
              "start_index"_a = value.search_space.primary_slice_window.start_index,
              "end_index"_a = value.search_space.primary_slice_window.end_index,
              "available_count"_a = value.search_space.primary_slice_window.available_count,
              "decoded_count"_a = value.search_space.primary_slice_window.decoded_count,
              "requested_offset"_a = value.search_space.primary_slice_window.requested_offset,
              "next_offset"_a = value.search_space.primary_slice_window.next_offset,
              "has_more"_a = value.search_space.primary_slice_window.has_more,
              "candidates"_a = primary_slice_candidates)),
      "window_evaluation"_a = py::dict(
          "recipe_index"_a = value.window_evaluation.recipe_index,
          "local_e_min"_a = value.window_evaluation.local_e_min,
          "local_e_max"_a = value.window_evaluation.local_e_max,
          "local_best_candidate_index"_a = value.window_evaluation.local_best_candidate_index,
          "local_worst_candidate_index"_a = value.window_evaluation.local_worst_candidate_index,
          "local_count_total"_a = value.window_evaluation.local_count_total,
          "entries"_a = window_evaluation_entries),
      "local_enumeration_loop"_a = py::dict(
          "initial_offset"_a = value.local_enumeration_loop.initial_offset,
          "chunk_limit"_a = value.local_enumeration_loop.chunk_limit,
          "max_chunks"_a = value.local_enumeration_loop.max_chunks,
          "exhaust_all"_a = value.local_enumeration_loop.exhaust_all,
          "processed_chunks"_a = value.local_enumeration_loop.processed_chunks,
          "processed_candidates"_a = value.local_enumeration_loop.processed_candidates,
          "next_offset"_a = value.local_enumeration_loop.next_offset,
          "has_more"_a = value.local_enumeration_loop.has_more),
      "local_reduction"_a = py::dict(
          "rank"_a = value.local_reduction.rank,
          "world_size"_a = value.local_reduction.world_size,
          "primary_recipe_index"_a = value.local_reduction.primary_recipe_index,
          "processed_chunks"_a = value.local_reduction.processed_chunks,
          "processed_candidates"_a = value.local_reduction.processed_candidates,
          "initial_offset"_a = value.local_reduction.initial_offset,
          "next_offset"_a = value.local_reduction.next_offset,
          "has_more"_a = value.local_reduction.has_more,
          "exhaust_all"_a = value.local_reduction.exhaust_all,
          "has_samples"_a = value.local_reduction.has_samples,
          "local_e_min"_a = value.local_reduction.local_e_min,
          "local_e_max"_a = value.local_reduction.local_e_max,
          "local_best_candidate_index"_a = value.local_reduction.local_best_candidate_index,
          "local_worst_candidate_index"_a = value.local_reduction.local_worst_candidate_index,
          "local_de_min_swap"_a = value.local_reduction.local_de_min_swap,
          "local_swap_count"_a = value.local_reduction.local_swap_count,
          "local_best_structure"_a = structure_dict(
              value.local_reduction.local_best_structure),
          "local_worst_structure"_a = structure_dict(
              value.local_reduction.local_worst_structure),
          "local_best_structure_present"_a =
              value.local_reduction.local_best_structure_present,
          "local_worst_structure_present"_a =
              value.local_reduction.local_worst_structure_present,
          "local_energy_table"_a = energy_table_dict(value.local_reduction.local_energy_table)),
      "best"_a = snapshot_to_dict(value.best),
      "worst"_a = snapshot_to_dict(value.worst),
      "messages"_a = value.messages);
}

py::dict run_result_dict(const ess::RunResult& value) {
  return py::dict("guide"_a = guide_result_dict(value.guide),
                  "solve"_a = solve_result_dict(value.solve));
}

py::dict guider_text_intermediate_dict(const ess::adapter::GuiderTextIntermediate& value) {
  py::dict target_fractions;
  for (const auto& entry : value.target_fractions) {
    target_fractions[py::str(entry.kind)] = entry.fraction;
  }

  py::dict ion_list;
  for (const auto& entry : value.ion_list.values) {
    ion_list[py::str(entry.kind)] = entry.oxidation;
  }

  py::list recipe_lines;
  for (const auto& recipe_line : value.recipe_lines) {
    py::list recipes;
    for (const auto& recipe : recipe_line.recipes) {
      recipes.append(py::dict("from"_a = recipe.from, "to"_a = recipe.to));
    }
    recipe_lines.append(py::dict(
        "poscar_filename"_a = recipe_line.poscar_filename,
        "output_prefix"_a = recipe_line.output_prefix,
        "space_group"_a = recipe_line.space_group,
        "declared_n_recipe"_a = recipe_line.declared_n_recipe,
        "recipes"_a = recipes,
        "raw_line"_a = recipe_line.raw_line));
  }

  py::list sections;
  for (const auto& section : value.sections) {
    sections.append(py::dict("header"_a = section.header, "lines"_a = section.lines));
  }

  py::list scalar_fields;
  for (const auto& [key, scalar_value] : value.scalar_fields) {
    scalar_fields.append(py::dict("key"_a = key, "value"_a = scalar_value));
  }

  return py::dict(
      "target_fractions"_a = target_fractions,
      "number_fixed_at"_a = value.number_fixed_at,
      "n_target_sites"_a = value.n_target_sites,
      "options"_a = py::dict(
          "n_random_seeds"_a = value.options.n_random_seeds,
          "shell_width"_a = value.options.shell_width,
          "wyc_identity_length"_a = value.options.wyc_identity_length,
          "abc_weights"_a = value.options.abc_weights,
          "chop_level"_a = value.options.chop_level,
          "target_cpu_time_sec"_a = value.options.target_cpu_time_sec,
          "strict_no_added_sites"_a = value.options.strict_no_added_sites,
          "skip_rg_optimization"_a = value.options.skip_rg_optimization,
          "skip_ewald_evaluation"_a = value.options.skip_ewald_evaluation),
      "ion_list"_a = ion_list,
      "recipe_lines"_a = recipe_lines,
      "sections"_a = sections,
      "scalar_fields"_a = scalar_fields,
      "sh_header_for_ess"_a = value.sh_header_for_ess,
      "sh_header_for_vasp"_a = value.sh_header_for_vasp,
      "unknown_lines"_a = value.unknown_lines);
}

py::dict add_sites_mc_spec_dict(const ess::adapter::AddSitesMonteCarloSpec& value) {
  py::list added_kinds;
  for (const auto& added_kind : value.added_kinds) {
    py::list neighbors;
    for (const auto& neighbor : added_kind.neighbor_kinds) {
      neighbors.append(py::dict(
          "kind"_a = neighbor.kind,
          "doxidation"_a = neighbor.doxidation,
          "dist_min"_a = neighbor.dist_min,
          "dist_max"_a = neighbor.dist_max));
    }
    added_kinds.append(py::dict(
        "kind"_a = added_kind.kind,
        "n_added"_a = added_kind.n_added,
        "oxidation"_a = added_kind.oxidation,
        "neighbor_kinds"_a = neighbors));
  }

  return py::dict(
      "present"_a = value.present,
      "n_add_kind"_a = value.n_add_kind,
      "add_meshes"_a = value.add_meshes,
      "min_distance_between_added_sites"_a =
          value.min_distance_between_added_sites,
      "n_monte_carlo"_a = value.n_monte_carlo,
      "monte_carlo_monitor_index"_a = value.monte_carlo_monitor_index,
      "added_kinds"_a = added_kinds);
}

}  // namespace

PYBIND11_MODULE(_esspy, m) {
  using namespace py::literals;

  m.doc() = "Python bindings for ess core";
  m.def("guide", [](const py::dict& value) {
    return guide_result_dict(ess::guide(parse_guide_input(value)));
  });
  m.def("solve", [](const py::dict& value) {
    auto input = parse_solve_input(value);
    input.options.cancel_requested = make_python_cancel_callback();
    if (input.options.mpi_adaptive_stride_sync) {
      input.options.synchronize_adaptive_stride =
          make_mpi_adaptive_stride_sync_callback();
    }
    if (input.options.mpi_dynamic_chunking) {
      input.options.synchronize_dynamic_chunk =
          make_mpi_dynamic_chunk_sync_callback();
    }
    py::gil_scoped_release release;
    auto result = ess::solve(input);
    py::gil_scoped_acquire acquire;
    return solve_result_dict(result);
  });
  m.def("run", [](const py::dict& value) {
    auto input = parse_run_input(value);
    input.solve.cancel_requested = make_python_cancel_callback();
    if (input.solve.mpi_adaptive_stride_sync) {
      input.solve.synchronize_adaptive_stride =
          make_mpi_adaptive_stride_sync_callback();
    }
    if (input.solve.mpi_dynamic_chunking) {
      input.solve.synchronize_dynamic_chunk =
          make_mpi_dynamic_chunk_sync_callback();
    }
    py::gil_scoped_release release;
    auto result = ess::run(input);
    py::gil_scoped_acquire acquire;
    return run_result_dict(result);
  });
  m.def("parse_guider_text_file", [](const std::string& path) {
    return guider_text_intermediate_dict(ess::adapter::parse_guider_text_file(path));
  });
  m.def("parse_add_sites_monte_carlo_spec", [](const std::string& path) {
    return add_sites_mc_spec_dict(
        ess::adapter::parse_add_sites_monte_carlo_spec(path));
  });
  m.def(
      "run_add_sites_monte_carlo",
      [](const py::dict& structure_value,
         const py::dict& spec_value,
         const py::dict& options_value) {
        const ess::StructureModel structure = parse_structure(structure_value);

        ess::solve_steps::AddSitesMonteCarloSpec spec;
        spec.add_meshes = to_vec3(spec_value[py::str("add_meshes")]);
        spec.min_distance_between_added_sites =
            require<long double>(spec_value, "min_distance_between_added_sites");
        spec.n_monte_carlo = require<int>(spec_value, "n_monte_carlo");
        spec.monte_carlo_monitor_index =
            require<int>(spec_value, "monte_carlo_monitor_index");
        for (const auto& item : py::cast<py::list>(spec_value[py::str("added_kinds")])) {
          auto dict = py::cast<py::dict>(item);
          ess::solve_steps::AddSitesKindSpec added_kind;
          added_kind.kind = require<std::string>(dict, "kind");
          added_kind.n_added = require<int>(dict, "n_added");
          added_kind.oxidation = require<long double>(dict, "oxidation");
          for (const auto& nitem : py::cast<py::list>(dict[py::str("neighbor_kinds")])) {
            auto ndict = py::cast<py::dict>(nitem);
            added_kind.neighbor_kinds.push_back(ess::solve_steps::AddSitesNeighborConstraint{
                require<std::string>(ndict, "kind"),
                require<long double>(ndict, "doxidation"),
                require<long double>(ndict, "dist_min"),
                require<long double>(ndict, "dist_max"),
            });
          }
          spec.added_kinds.push_back(added_kind);
        }

        ess::solve_steps::AddSitesMonteCarloOptions options;
        if (options_value.contains(py::str("random_seed"))) {
          options.random_seed = py::cast<unsigned int>(options_value[py::str("random_seed")]);
        }
        if (options_value.contains(py::str("rg_find_factor"))) {
          options.rg_find_factor = py::cast<int>(options_value[py::str("rg_find_factor")]);
        }
        if (options_value.contains(py::str("chop_level"))) {
          options.chop_level = py::cast<long double>(options_value[py::str("chop_level")]);
        }

        const auto result = ess::solve_steps::run_add_sites_monte_carlo(structure, spec, options);
        return py::dict(
            "success"_a = result.success,
            "best_structure"_a = structure_dict(result.best_structure),
            "best_energy"_a = result.best_energy,
            "accepted_trials"_a = result.accepted_trials,
            "attempted_trials"_a = result.attempted_trials,
            "log"_a = result.log);
      },
      "structure"_a,
      "spec"_a,
      "options"_a = py::dict());
  m.def("parse_guider_text_to_guide_input",
        [](const std::string& guider_path, const std::string& base_dir) {
          return guide_input_dict(
              ess::adapter::parse_guider_text_to_guide_input(guider_path, base_dir));
        },
        "guider_path"_a,
        "base_dir"_a = "");
  m.def("parse_guider_text_to_run_input",
        [](const std::string& guider_path, const std::string& base_dir) {
          return run_input_dict(
              ess::adapter::parse_guider_text_to_run_input(guider_path, base_dir));
        },
        "guider_path"_a,
        "base_dir"_a = "");
  m.def(
      "compute_supercell_expansion",
      [](const py::dict& lattice_value, int n_atom_config, int n_target_sites) {
        const ess::Lattice lattice = parse_lattice(lattice_value);
        const auto result = ess::guide_steps::compute_supercell_expansion(
            lattice, n_atom_config, n_target_sites);
        return py::dict(
            "expansion"_a = result.expansion,
            "expanded_n_atom_config"_a = result.expanded_n_atom_config,
            "log"_a = result.log);
      },
      "lattice"_a,
      "n_atom_config"_a,
      "n_target_sites"_a);
  m.def(
      "compute_recipe_allocation",
      [](const py::list& primitive_cellions_value,
         const py::list& target_counts_value,
         int supercell_exp,
         bool strict_no_added_sites,
         const py::list& recipes_value,
         const py::dict& charges_value) {
        std::vector<ess::guide_steps::PrimitiveCellIon> primitive_cellions;
        for (const auto& item : primitive_cellions_value) {
          auto dict = py::cast<py::dict>(item);
          ess::guide_steps::PrimitiveCellIon entry;
          entry.kind = require<std::string>(dict, "kind");
          entry.n = require<int>(dict, "n");
          if (dict.contains(py::str("oxidation"))) {
            entry.oxidation =
                py::cast<long double>(dict[py::str("oxidation")]);
          }
          primitive_cellions.push_back(entry);
        }

        std::vector<ess::CompositionEntry> target_counts;
        for (const auto& item : target_counts_value) {
          auto dict = py::cast<py::dict>(item);
          target_counts.push_back(ess::CompositionEntry{
              require<std::string>(dict, "kind"),
              require<int>(dict, "count"),
          });
        }

        std::vector<ess::RecipeSpec> recipes;
        for (const auto& item : recipes_value) {
          recipes.push_back(parse_recipe_spec(py::cast<py::dict>(item)));
        }

        const ess::ChargeMap charges = parse_charges(charges_value);

        const auto allocation = ess::guide_steps::compute_recipe_allocation(
            primitive_cellions, target_counts, supercell_exp,
            strict_no_added_sites, recipes, charges);

        py::list cellions_out;
        for (const auto& cellion : allocation.cellions) {
          cellions_out.append(py::dict(
              "kind"_a = cellion.kind,
              "n_primitive"_a = cellion.n_primitive,
              "oxidation"_a = cellion.oxidation,
              "need"_a = cellion.need,
              "delta_need"_a = cellion.delta_need,
              "skipped_in_other_recipe"_a = cellion.skipped_in_other_recipe,
              "has_recipe"_a = cellion.has_recipe));
        }

        py::list final_recipes_out;
        for (const auto& recipe : allocation.final_recipes) {
          py::list mods;
          for (const auto& modification : recipe.modifications) {
            mods.append(py::dict(
                "to"_a = modification.to,
                "oxidation"_a = modification.oxidation,
                "number"_a = modification.number));
          }
          final_recipes_out.append(py::dict(
              "from"_a = recipe.from,
              "oxidation"_a = recipe.oxidation,
              "random_pickup"_a = recipe.random_pickup,
              "random_pickup_trial"_a = recipe.random_pickup_trial,
              "vac"_a = recipe.vac,
              "modifications"_a = mods));
        }

        return py::dict(
            "cellions"_a = cellions_out,
            "final_recipes"_a = final_recipes_out,
            "need_wyc"_a = allocation.need_wyc,
            "log"_a = allocation.log);
      },
      "primitive_cellions"_a,
      "target_counts"_a,
      "supercell_exp"_a,
      "strict_no_added_sites"_a,
      "recipes"_a,
      "charges"_a);
  m.def(
      "write_ready_file_text",
      [](const py::dict& ready_value, const py::dict& options_value) {
        const ess::ReadyModel ready = parse_ready(ready_value);
        ess::guide_steps::ReadyFileWriteOptions options;
        if (options_value.contains(py::str("target_cpu_time_sec"))) {
          options.target_cpu_time_sec =
              py::cast<int>(options_value[py::str("target_cpu_time_sec")]);
        }
        if (options_value.contains(py::str("running_index_delta"))) {
          options.running_index_delta =
              py::cast<long long>(options_value[py::str("running_index_delta")]);
        }
        if (options_value.contains(py::str("chop_level"))) {
          options.chop_level =
              py::cast<int>(options_value[py::str("chop_level")]);
        }
        if (options_value.contains(py::str("verbose"))) {
          options.verbose = py::cast<int>(options_value[py::str("verbose")]);
        }
        if (options_value.contains(py::str("create_recipe_strict_mode"))) {
          options.create_recipe_strict_mode = py::cast<int>(
              options_value[py::str("create_recipe_strict_mode")]);
        }
        if (options_value.contains(py::str("print_stablest_unstablest"))) {
          options.print_stablest_unstablest = py::cast<int>(
              options_value[py::str("print_stablest_unstablest")]);
        }
        if (options_value.contains(py::str("running_index_monitor"))) {
          options.running_index_monitor =
              py::cast<int>(options_value[py::str("running_index_monitor")]);
        }
        if (options_value.contains(py::str("swap"))) {
          options.swap = py::cast<int>(options_value[py::str("swap")]);
        }
        if (options_value.contains(py::str("max_swap"))) {
          options.max_swap =
              py::cast<int>(options_value[py::str("max_swap")]);
        }
        if (options_value.contains(py::str("restart_recipe_filename"))) {
          options.restart_recipe_filename = py::cast<std::string>(
              options_value[py::str("restart_recipe_filename")]);
        }
        if (options_value.contains(py::str("n_energy_table_line"))) {
          options.n_energy_table_line =
              py::cast<int>(options_value[py::str("n_energy_table_line")]);
        }
        if (options_value.contains(py::str("energy_table_default_line"))) {
          options.energy_table_default_line = py::cast<std::string>(
              options_value[py::str("energy_table_default_line")]);
        }
        if (options_value.contains(py::str("output_prefix_suffix"))) {
          options.output_prefix_suffix = py::cast<std::string>(
              options_value[py::str("output_prefix_suffix")]);
        }
        return ess::guide_steps::write_ready_file_text(ready, options);
      },
      "ready"_a,
      "options"_a = py::dict());
  m.def(
      "write_poscar_text",
      [](const py::dict& ready_value) {
        return ess::guide_steps::write_poscar_text(parse_ready(ready_value));
      },
      "ready"_a);
  m.def(
      "decode_candidate_assignment",
      [](const py::dict& recipe_value, unsigned long long index) {
        ess::ReadyRecipe recipe;
        recipe.from = require<std::string>(recipe_value, "from");
        recipe.oxidation = require<long double>(recipe_value, "oxidation");
        recipe.random_pickup = require<int>(recipe_value, "random_pickup");
        recipe.random_pickup_trial =
            require<int>(recipe_value, "random_pickup_trial");
        for (const auto& mod_value : py::cast<py::list>(recipe_value[py::str("modifications")])) {
          const auto mod = py::cast<py::dict>(mod_value);
          recipe.modifications.push_back(ess::ReadyRecipeModification{
              require<std::string>(mod, "to"),
              require<long double>(mod, "oxidation"),
              require<int>(mod, "count"),
          });
        }
        const auto indices =
            ess::solve_steps::decode_candidate_assignment_indices(recipe, index);
        const auto labels =
            ess::solve_steps::decode_candidate_assignment_labels_from_indices(
                recipe, indices);
        return py::dict("indices"_a = indices, "labels"_a = labels);
      },
      "recipe"_a,
      "index"_a);
  m.def(
      "decode_candidate_assignment_ld",
      [](const py::dict& recipe_value, long double index) {
        ess::ReadyRecipe recipe;
        recipe.from = require<std::string>(recipe_value, "from");
        recipe.oxidation = require<long double>(recipe_value, "oxidation");
        recipe.random_pickup = require<int>(recipe_value, "random_pickup");
        recipe.random_pickup_trial =
            require<int>(recipe_value, "random_pickup_trial");
        for (const auto& mod_value : py::cast<py::list>(recipe_value[py::str("modifications")])) {
          const auto mod = py::cast<py::dict>(mod_value);
          recipe.modifications.push_back(ess::ReadyRecipeModification{
              require<std::string>(mod, "to"),
              require<long double>(mod, "oxidation"),
              require<int>(mod, "count"),
          });
        }
        const auto indices =
            ess::solve_steps::decode_candidate_assignment_indices_ld(recipe, index);
        const auto labels =
            ess::solve_steps::decode_candidate_assignment_labels_from_indices(
                recipe, indices);
        return py::dict("indices"_a = indices, "labels"_a = labels);
      },
      "recipe"_a,
      "index"_a);
  m.def(
      "parse_wyc_file",
      [](const std::string& path) {
        const auto parsed = ess::adapter::parse_wyc_file(path);
        py::list entries;
        for (const auto& entry : parsed.entries) {
          py::list rows;
          for (int r = 0; r < 3; ++r) {
            py::list row;
            for (int c = 0; c < 4; ++c) {
              row.append(entry.matrix[r][c]);
            }
            rows.append(row);
          }
          entries.append(py::dict("label"_a = entry.label, "matrix"_a = rows));
        }
        return py::dict(
            "header_key"_a = parsed.header_key,
            "declared_n_wyc"_a = parsed.declared_n_wyc,
            "entries"_a = entries);
      },
      "path"_a);
  m.def(
      "compute_add_ions",
      [](const py::dict& lattice_value,
         const py::list& existing_value,
         const py::list& wyc_operations_value,
         int n_to_add,
         const py::dict& options_value) {
        const ess::Lattice lattice = parse_lattice(lattice_value);

        std::vector<std::array<long double, 3>> existing_fractional;
        for (const auto& item : existing_value) {
          auto seq = py::cast<py::sequence>(item);
          if (py::len(seq) != 3) {
            throw std::runtime_error(
                "Each existing fractional position must be a length-3 "
                "sequence");
          }
          existing_fractional.push_back({
              py::cast<long double>(seq[0]),
              py::cast<long double>(seq[1]),
              py::cast<long double>(seq[2]),
          });
        }

        std::vector<ess::SymmetryOperation> wyc_operations;
        for (const auto& item : wyc_operations_value) {
          auto rows = py::cast<py::sequence>(item);
          if (py::len(rows) != 3) {
            throw std::runtime_error(
                "Each WYC operation must have exactly 3 rows");
          }
          ess::SymmetryOperation op;
          for (int r = 0; r < 3; ++r) {
            auto row = py::cast<py::sequence>(rows[r]);
            if (py::len(row) != 4) {
              throw std::runtime_error(
                  "Each WYC operation row must have exactly 4 columns");
            }
            for (int c = 0; c < 4; ++c) {
              op.matrix[r][c] = py::cast<long double>(row[c]);
            }
          }
          wyc_operations.push_back(op);
        }

        ess::guide_steps::AddIonsOptions options;
        if (options_value.contains(py::str("shell_width"))) {
          options.shell_width =
              py::cast<long double>(options_value[py::str("shell_width")]);
        }
        if (options_value.contains(py::str("wyc_identity_length"))) {
          options.wyc_identity_length = py::cast<long double>(
              options_value[py::str("wyc_identity_length")]);
        }
        if (options_value.contains(py::str("abc_weights"))) {
          options.abc_weights =
              to_vec3(options_value[py::str("abc_weights")]);
        }
        if (options_value.contains(py::str("n_random_seeds"))) {
          options.n_random_seeds =
              py::cast<int>(options_value[py::str("n_random_seeds")]);
        }
        if (options_value.contains(py::str("random_seed"))) {
          options.random_seed = py::cast<unsigned int>(
              options_value[py::str("random_seed")]);
        }

        const auto result = ess::guide_steps::compute_add_ions(
            lattice, existing_fractional, wyc_operations, n_to_add, options);

        py::list added_sites;
        for (const auto& site : result.added_sites) {
          added_sites.append(py::dict(
              "fractional"_a = site.fractional,
              "cartesian"_a = site.cartesian));
        }
        py::list chosen_seeds;
        for (const auto& seed : result.chosen_random_seeds) {
          chosen_seeds.append(seed);
        }
        return py::dict(
            "added_sites"_a = added_sites,
            "chosen_random_seeds"_a = chosen_seeds,
            "neighbor_distance_max"_a = result.neighbor_distance_max,
            "log"_a = result.log);
      },
      "lattice"_a,
      "existing_fractional"_a,
      "wyc_operations"_a,
      "n_to_add"_a,
      "options"_a = py::dict());
  m.def(
      "parse_wyc_file_to_symmetry_model",
      [](const std::string& path, int space_group) {
        const auto symmetry =
            ess::adapter::parse_wyc_file_to_symmetry_model(path, space_group);
        py::list operations;
        for (const auto& operation : symmetry.wyc_operations) {
          py::list rows;
          for (int r = 0; r < 3; ++r) {
            py::list row;
            for (int c = 0; c < 4; ++c) {
              row.append(operation.matrix[r][c]);
            }
            rows.append(row);
          }
          operations.append(rows);
        }
        return py::dict(
            "space_group"_a = symmetry.space_group,
            "from_spglib"_a = symmetry.from_spglib,
            "wyc_operations"_a = operations);
      },
      "path"_a,
      "space_group"_a);
  m.def(
      "combine_local_reductions",
      [](const py::list& inputs_value) {
        std::vector<ess::LocalReductionSummary> inputs;
        inputs.reserve(py::len(inputs_value));
        for (const auto& item : inputs_value) {
          auto dict = py::cast<py::dict>(item);
          ess::LocalReductionSummary entry;
          if (dict.contains(py::str("rank"))) {
            entry.rank = py::cast<int>(dict[py::str("rank")]);
          }
          if (dict.contains(py::str("world_size"))) {
            entry.world_size = py::cast<int>(dict[py::str("world_size")]);
          }
          if (dict.contains(py::str("primary_recipe_index"))) {
            entry.primary_recipe_index =
                py::cast<int>(dict[py::str("primary_recipe_index")]);
          }
          if (dict.contains(py::str("processed_chunks"))) {
            entry.processed_chunks =
                py::cast<int>(dict[py::str("processed_chunks")]);
          }
          if (dict.contains(py::str("processed_candidates"))) {
            entry.processed_candidates =
                py::cast<int>(dict[py::str("processed_candidates")]);
          }
          if (dict.contains(py::str("initial_offset"))) {
            entry.initial_offset = py::cast<unsigned long long>(
                dict[py::str("initial_offset")]);
          }
          if (dict.contains(py::str("next_offset"))) {
            entry.next_offset =
                py::cast<unsigned long long>(dict[py::str("next_offset")]);
          }
          if (dict.contains(py::str("has_more"))) {
            entry.has_more = py::cast<bool>(dict[py::str("has_more")]);
          }
          if (dict.contains(py::str("exhaust_all"))) {
            entry.exhaust_all =
                py::cast<bool>(dict[py::str("exhaust_all")]);
          }
          if (dict.contains(py::str("has_samples"))) {
            entry.has_samples =
                py::cast<bool>(dict[py::str("has_samples")]);
          }
          if (dict.contains(py::str("local_e_min"))) {
            entry.local_e_min =
                py::cast<long double>(dict[py::str("local_e_min")]);
          }
          if (dict.contains(py::str("local_e_max"))) {
            entry.local_e_max =
                py::cast<long double>(dict[py::str("local_e_max")]);
          }
          if (dict.contains(py::str("local_best_candidate_index"))) {
            entry.local_best_candidate_index = py::cast<unsigned long long>(
                dict[py::str("local_best_candidate_index")]);
          }
          if (dict.contains(py::str("local_worst_candidate_index"))) {
            entry.local_worst_candidate_index = py::cast<unsigned long long>(
                dict[py::str("local_worst_candidate_index")]);
          }
          if (dict.contains(py::str("local_de_min_swap"))) {
            entry.local_de_min_swap =
                py::cast<long double>(dict[py::str("local_de_min_swap")]);
          }
          if (dict.contains(py::str("local_swap_count"))) {
            entry.local_swap_count =
                py::cast<int>(dict[py::str("local_swap_count")]);
          }
          if (dict.contains(py::str("local_best_structure")) &&
              !dict[py::str("local_best_structure")].is_none()) {
            entry.local_best_structure = parse_structure(
                py::cast<py::dict>(dict[py::str("local_best_structure")]));
          }
          if (dict.contains(py::str("local_worst_structure")) &&
              !dict[py::str("local_worst_structure")].is_none()) {
            entry.local_worst_structure = parse_structure(
                py::cast<py::dict>(dict[py::str("local_worst_structure")]));
          }
          if (dict.contains(py::str("local_best_structure_present"))) {
            entry.local_best_structure_present = py::cast<bool>(
                dict[py::str("local_best_structure_present")]);
          }
          if (dict.contains(py::str("local_worst_structure_present"))) {
            entry.local_worst_structure_present = py::cast<bool>(
                dict[py::str("local_worst_structure_present")]);
          }
          if (dict.contains(py::str("local_energy_table"))) {
            entry.local_energy_table = parse_energy_table(
                py::cast<py::dict>(dict[py::str("local_energy_table")]));
          }
          inputs.push_back(entry);
        }
        const auto reduced =
            ess::solve_steps::combine_local_reductions(inputs);
        return py::dict(
            "world_size"_a = reduced.world_size,
            "contributing_ranks"_a = reduced.contributing_ranks,
            "total_processed_candidates"_a =
                reduced.total_processed_candidates,
            "total_processed_chunks"_a = reduced.total_processed_chunks,
            "any_has_more"_a = reduced.any_has_more,
            "any_exhaust_all"_a = reduced.any_exhaust_all,
            "has_samples"_a = reduced.has_samples,
            "global_e_min"_a = reduced.global_e_min,
            "global_e_max"_a = reduced.global_e_max,
            "which_rank_global_e_min"_a = reduced.which_rank_global_e_min,
            "which_rank_global_e_max"_a = reduced.which_rank_global_e_max,
            "global_e_min_candidate_index"_a =
                reduced.global_e_min_candidate_index,
            "global_e_max_candidate_index"_a =
                reduced.global_e_max_candidate_index,
            "global_de_min_swap"_a = reduced.global_de_min_swap,
            "global_swap_count"_a = reduced.global_swap_count,
            "total_de_min_swap"_a = reduced.total_de_min_swap,
            "total_swap_count"_a = reduced.total_swap_count,
            "global_best_structure"_a =
                structure_dict(reduced.global_best_structure),
            "global_worst_structure"_a =
                structure_dict(reduced.global_worst_structure),
            "global_best_structure_present"_a =
                reduced.global_best_structure_present,
            "global_worst_structure_present"_a =
                reduced.global_worst_structure_present,
            "primary_recipe_index"_a = reduced.primary_recipe_index,
            "primary_recipe_consistent"_a =
                reduced.primary_recipe_consistent,
            "global_energy_table"_a = energy_table_dict(reduced.global_energy_table));
      },
      "inputs"_a);
  m.def(
      "extract_local_reduction_scalars",
      [](const py::dict& dict) {
        ess::LocalReductionSummary summary;
        if (dict.contains(py::str("rank"))) {
          summary.rank = py::cast<int>(dict[py::str("rank")]);
        }
        if (dict.contains(py::str("world_size"))) {
          summary.world_size = py::cast<int>(dict[py::str("world_size")]);
        }
        if (dict.contains(py::str("primary_recipe_index"))) {
          summary.primary_recipe_index =
              py::cast<int>(dict[py::str("primary_recipe_index")]);
        }
        if (dict.contains(py::str("processed_chunks"))) {
          summary.processed_chunks =
              py::cast<int>(dict[py::str("processed_chunks")]);
        }
        if (dict.contains(py::str("processed_candidates"))) {
          summary.processed_candidates =
              py::cast<int>(dict[py::str("processed_candidates")]);
        }
        if (dict.contains(py::str("initial_offset"))) {
          summary.initial_offset =
              py::cast<unsigned long long>(dict[py::str("initial_offset")]);
        }
        if (dict.contains(py::str("next_offset"))) {
          summary.next_offset =
              py::cast<unsigned long long>(dict[py::str("next_offset")]);
        }
        if (dict.contains(py::str("has_more"))) {
          summary.has_more = py::cast<bool>(dict[py::str("has_more")]);
        }
        if (dict.contains(py::str("exhaust_all"))) {
          summary.exhaust_all = py::cast<bool>(dict[py::str("exhaust_all")]);
        }
        if (dict.contains(py::str("has_samples"))) {
          summary.has_samples = py::cast<bool>(dict[py::str("has_samples")]);
        }
        if (dict.contains(py::str("local_e_min"))) {
          summary.local_e_min =
              py::cast<long double>(dict[py::str("local_e_min")]);
        }
        if (dict.contains(py::str("local_e_max"))) {
          summary.local_e_max =
              py::cast<long double>(dict[py::str("local_e_max")]);
        }
        if (dict.contains(py::str("local_best_candidate_index"))) {
          summary.local_best_candidate_index = py::cast<unsigned long long>(
              dict[py::str("local_best_candidate_index")]);
        }
        if (dict.contains(py::str("local_worst_candidate_index"))) {
          summary.local_worst_candidate_index = py::cast<unsigned long long>(
              dict[py::str("local_worst_candidate_index")]);
        }
        if (dict.contains(py::str("local_de_min_swap"))) {
          summary.local_de_min_swap =
              py::cast<long double>(dict[py::str("local_de_min_swap")]);
        }
        if (dict.contains(py::str("local_swap_count"))) {
          summary.local_swap_count =
              py::cast<int>(dict[py::str("local_swap_count")]);
        }
        if (dict.contains(py::str("local_best_structure_present"))) {
          summary.local_best_structure_present = py::cast<bool>(
              dict[py::str("local_best_structure_present")]);
        }
        if (dict.contains(py::str("local_worst_structure_present"))) {
          summary.local_worst_structure_present = py::cast<bool>(
              dict[py::str("local_worst_structure_present")]);
        }
        if (dict.contains(py::str("local_energy_table"))) {
          summary.local_energy_table = parse_energy_table(
              py::cast<py::dict>(dict[py::str("local_energy_table")]));
        }

        const auto scalars =
            ess::solve_steps::extract_local_reduction_scalars(summary);
        return py::dict(
            "rank"_a = scalars.rank,
            "world_size"_a = scalars.world_size,
            "primary_recipe_index"_a = scalars.primary_recipe_index,
            "processed_chunks"_a = scalars.processed_chunks,
            "processed_candidates"_a = scalars.processed_candidates,
            "initial_offset"_a = scalars.initial_offset,
            "next_offset"_a = scalars.next_offset,
            "has_more"_a = scalars.has_more,
            "exhaust_all"_a = scalars.exhaust_all,
            "has_samples"_a = scalars.has_samples,
            "local_e_min"_a = scalars.local_e_min,
            "local_e_max"_a = scalars.local_e_max,
            "local_best_candidate_index"_a =
                scalars.local_best_candidate_index,
            "local_worst_candidate_index"_a =
                scalars.local_worst_candidate_index,
            "local_de_min_swap"_a = scalars.local_de_min_swap,
            "local_swap_count"_a = scalars.local_swap_count,
            "local_best_structure_present"_a =
                scalars.local_best_structure_present,
            "local_worst_structure_present"_a =
                scalars.local_worst_structure_present,
            "local_energy_table"_a = energy_table_dict(scalars.local_energy_table));
      },
      "summary"_a);
  m.def(
      "combine_local_reduction_scalars",
      [](const py::list& inputs_value) {
        std::vector<ess::solve_steps::LocalReductionScalars> inputs;
        inputs.reserve(py::len(inputs_value));
        for (const auto& item : inputs_value) {
          auto dict = py::cast<py::dict>(item);
          ess::solve_steps::LocalReductionScalars entry;
          if (dict.contains(py::str("rank"))) {
            entry.rank = py::cast<int>(dict[py::str("rank")]);
          }
          if (dict.contains(py::str("world_size"))) {
            entry.world_size = py::cast<int>(dict[py::str("world_size")]);
          }
          if (dict.contains(py::str("primary_recipe_index"))) {
            entry.primary_recipe_index =
                py::cast<int>(dict[py::str("primary_recipe_index")]);
          }
          if (dict.contains(py::str("processed_chunks"))) {
            entry.processed_chunks =
                py::cast<int>(dict[py::str("processed_chunks")]);
          }
          if (dict.contains(py::str("processed_candidates"))) {
            entry.processed_candidates =
                py::cast<int>(dict[py::str("processed_candidates")]);
          }
          if (dict.contains(py::str("initial_offset"))) {
            entry.initial_offset = py::cast<unsigned long long>(
                dict[py::str("initial_offset")]);
          }
          if (dict.contains(py::str("next_offset"))) {
            entry.next_offset =
                py::cast<unsigned long long>(dict[py::str("next_offset")]);
          }
          if (dict.contains(py::str("has_more"))) {
            entry.has_more = py::cast<bool>(dict[py::str("has_more")]);
          }
          if (dict.contains(py::str("exhaust_all"))) {
            entry.exhaust_all =
                py::cast<bool>(dict[py::str("exhaust_all")]);
          }
          if (dict.contains(py::str("has_samples"))) {
            entry.has_samples =
                py::cast<bool>(dict[py::str("has_samples")]);
          }
          if (dict.contains(py::str("local_e_min"))) {
            entry.local_e_min =
                py::cast<long double>(dict[py::str("local_e_min")]);
          }
          if (dict.contains(py::str("local_e_max"))) {
            entry.local_e_max =
                py::cast<long double>(dict[py::str("local_e_max")]);
          }
          if (dict.contains(py::str("local_best_candidate_index"))) {
            entry.local_best_candidate_index = py::cast<unsigned long long>(
                dict[py::str("local_best_candidate_index")]);
          }
          if (dict.contains(py::str("local_worst_candidate_index"))) {
            entry.local_worst_candidate_index = py::cast<unsigned long long>(
                dict[py::str("local_worst_candidate_index")]);
          }
          if (dict.contains(py::str("local_de_min_swap"))) {
            entry.local_de_min_swap =
                py::cast<long double>(dict[py::str("local_de_min_swap")]);
          }
          if (dict.contains(py::str("local_swap_count"))) {
            entry.local_swap_count =
                py::cast<int>(dict[py::str("local_swap_count")]);
          }
          if (dict.contains(py::str("local_best_structure_present"))) {
            entry.local_best_structure_present = py::cast<bool>(
                dict[py::str("local_best_structure_present")]);
          }
          if (dict.contains(py::str("local_worst_structure_present"))) {
            entry.local_worst_structure_present = py::cast<bool>(
                dict[py::str("local_worst_structure_present")]);
          }
          if (dict.contains(py::str("local_energy_table"))) {
            entry.local_energy_table = parse_energy_table(
                py::cast<py::dict>(dict[py::str("local_energy_table")]));
          }
          inputs.push_back(entry);
        }
        const auto reduced =
            ess::solve_steps::combine_local_reduction_scalars(inputs);
        return py::dict(
            "world_size"_a = reduced.world_size,
            "contributing_ranks"_a = reduced.contributing_ranks,
            "total_processed_candidates"_a =
                reduced.total_processed_candidates,
            "total_processed_chunks"_a = reduced.total_processed_chunks,
            "any_has_more"_a = reduced.any_has_more,
            "any_exhaust_all"_a = reduced.any_exhaust_all,
            "has_samples"_a = reduced.has_samples,
            "global_e_min"_a = reduced.global_e_min,
            "global_e_max"_a = reduced.global_e_max,
            "which_rank_global_e_min"_a = reduced.which_rank_global_e_min,
            "which_rank_global_e_max"_a = reduced.which_rank_global_e_max,
            "global_e_min_candidate_index"_a =
                reduced.global_e_min_candidate_index,
            "global_e_max_candidate_index"_a =
                reduced.global_e_max_candidate_index,
            "global_de_min_swap"_a = reduced.global_de_min_swap,
            "global_swap_count"_a = reduced.global_swap_count,
            "total_de_min_swap"_a = reduced.total_de_min_swap,
            "total_swap_count"_a = reduced.total_swap_count,
            "global_best_structure_present"_a =
                reduced.global_best_structure_present,
            "global_worst_structure_present"_a =
                reduced.global_worst_structure_present,
            "primary_recipe_index"_a = reduced.primary_recipe_index,
            "primary_recipe_consistent"_a =
                reduced.primary_recipe_consistent,
            "global_energy_table"_a = energy_table_dict(reduced.global_energy_table));
      },
      "inputs"_a);
  m.def(
      "probe_swap_real_delta",
      [](const py::dict& ready_value,
         std::size_t site_a,
         std::size_t site_b,
         int rg_find_factor,
         long double chop_level) {
        const ess::ReadyModel ready = parse_ready(ready_value);
        ess::StructureModel structure;
        structure.title = ready.output_prefix;
        structure.lattice = ready.lattice;
        structure.fractional_coordinates = true;
        for (const auto& atom : ready.atoms) {
          structure.sites.push_back(ess::Site{atom.kind, atom.x, atom.y, atom.z, atom.oxidation});
        }
        auto cache = ess::solve_steps::create_swap_energy_cache(structure, rg_find_factor, chop_level);
        const auto before_real = ess::solve_steps::evaluate_real_energy_from_cache(cache, structure);
        const auto before_point = ess::solve_steps::evaluate_point_energy_from_cache(cache, structure);
        long double before_total = 0.0L;
        const auto before_recip = ess::solve_steps::evaluate_recip_energy_from_cache(cache, structure);
        before_total = before_real + before_point + before_recip;
        const auto real_delta = ess::solve_steps::evaluate_swap_real_delta_from_cache(cache, structure, site_a, site_b);
        const auto point_delta = ess::solve_steps::evaluate_swap_point_delta_from_cache(cache, structure, site_a, site_b);
        auto swapped = structure;
        std::swap(swapped.sites[site_a].kind, swapped.sites[site_b].kind);
        std::swap(swapped.sites[site_a].oxidation, swapped.sites[site_b].oxidation);
        const auto after_real = ess::solve_steps::evaluate_real_energy_from_cache(cache, swapped);
        const auto after_point = ess::solve_steps::evaluate_point_energy_from_cache(cache, swapped);
        long double after_total = 0.0L;
        const auto recip_delta = ess::solve_steps::evaluate_swap_recip_delta_from_cache(cache, structure, static_cast<std::size_t>(site_a), static_cast<std::size_t>(site_b));
        const auto after_recip = ess::solve_steps::evaluate_recip_energy_from_cache(cache, swapped);
        after_total = after_real + after_point + after_recip;
        return py::dict(
            "before"_a = before_real,
            "delta"_a = real_delta,
            "after"_a = after_real,
            "predicted_after"_a = before_real + real_delta,
            "before_point"_a = before_point,
            "after_point"_a = after_point,
            "point_delta"_a = point_delta,
            "recip_delta"_a = recip_delta,
            "before_recip"_a = before_recip,
            "after_recip"_a = after_recip,
            "before_total"_a = before_total,
            "after_total"_a = after_total,
            "cache_stats"_a = py::dict(
                "full_evaluations"_a = cache.stats.full_evaluations,
                "diff_evaluations"_a = cache.stats.diff_evaluations,
                "real_cache_evaluations"_a = cache.stats.real_cache_evaluations,
                "point_cache_evaluations"_a = cache.stats.point_cache_evaluations,
                "recip_cache_evaluations"_a = cache.stats.recip_cache_evaluations,
                "recip_state_rebuilds"_a = cache.stats.recip_state_rebuilds,
                "recip_incremental_updates"_a = cache.stats.recip_incremental_updates,
                "recip_fallback_evaluations"_a = cache.stats.recip_fallback_evaluations,
                "diff_cache_enabled"_a = cache.stats.diff_cache_enabled,
                "real_pair_terms"_a = cache.stats.real_pair_terms,
                "recip_kpoint_terms"_a = cache.stats.recip_kpoint_terms));
      },
      "ready"_a,
      "site_a"_a,
      "site_b"_a,
      "rg_find_factor"_a = 1,
      "chop_level"_a = 8.0L);

  m.def(
      "probe_site_update_delta",
      [](const py::dict& ready_value,
         const std::vector<std::size_t>& changed_indices,
         const std::vector<long double>& new_oxidations,
         const std::vector<std::string>& new_kinds,
         int rg_find_factor,
         long double chop_level) {
        const ess::ReadyModel ready = parse_ready(ready_value);
        ess::StructureModel structure;
        structure.title = ready.output_prefix;
        structure.lattice = ready.lattice;
        structure.fractional_coordinates = true;
        for (const auto& atom : ready.atoms) {
          structure.sites.push_back(
              ess::Site{atom.kind, atom.x, atom.y, atom.z, atom.oxidation});
        }

        auto cache =
            ess::solve_steps::create_swap_energy_cache(structure, rg_find_factor, chop_level);
        const auto before_total =
            ess::solve_steps::evaluate_total_with_cache(cache, structure);
        const auto delta =
            ess::solve_steps::evaluate_site_update_delta_from_cache(
                cache, structure, changed_indices, new_oxidations);

        if (!new_kinds.empty() && new_kinds.size() != changed_indices.size()) {
          throw std::runtime_error(
              "new_kinds must be empty or have the same length as changed_indices");
        }
        auto updated = structure;
        for (std::size_t pos = 0; pos < changed_indices.size(); ++pos) {
          const std::size_t i = changed_indices[pos];
          if (i >= updated.sites.size()) {
            throw std::runtime_error("changed site index is out of range");
          }
          updated.sites[i].oxidation = new_oxidations[pos];
          if (!new_kinds.empty()) {
            updated.sites[i].kind = new_kinds[pos];
          }
        }
        auto after_cache =
            ess::solve_steps::create_swap_energy_cache(updated, rg_find_factor, chop_level);
        const auto after_total =
            ess::solve_steps::evaluate_total_with_cache(after_cache, updated);

        auto committed = structure;
        ess::solve_steps::commit_site_update_state(
            cache, committed, changed_indices, new_kinds, new_oxidations);
        const auto committed_total =
            ess::solve_steps::evaluate_total_with_cache(cache, committed);

        return py::dict(
            "before_total"_a = before_total,
            "delta"_a = delta,
            "predicted_after_total"_a = before_total + delta,
            "after_total"_a = after_total,
            "committed_total"_a = committed_total,
            "abs_error"_a = std::abs((before_total + delta) - after_total),
            "commit_abs_error"_a = std::abs(committed_total - after_total),
            "cache_stats"_a = py::dict(
                "full_evaluations"_a = cache.stats.full_evaluations,
                "diff_evaluations"_a = cache.stats.diff_evaluations,
                "real_cache_evaluations"_a = cache.stats.real_cache_evaluations,
                "real_incremental_updates"_a = cache.stats.real_incremental_updates,
                "point_cache_evaluations"_a = cache.stats.point_cache_evaluations,
                "point_incremental_updates"_a = cache.stats.point_incremental_updates,
                "recip_cache_evaluations"_a = cache.stats.recip_cache_evaluations,
                "recip_state_rebuilds"_a = cache.stats.recip_state_rebuilds,
                "recip_incremental_updates"_a = cache.stats.recip_incremental_updates,
                "recip_fallback_evaluations"_a = cache.stats.recip_fallback_evaluations,
                "diff_cache_enabled"_a = cache.stats.diff_cache_enabled,
                "real_pair_terms"_a = cache.stats.real_pair_terms,
                "recip_kpoint_terms"_a = cache.stats.recip_kpoint_terms));
      },
      "ready"_a,
      "changed_indices"_a,
      "new_oxidations"_a,
      "new_kinds"_a = std::vector<std::string>{},
      "rg_find_factor"_a = 1,
      "chop_level"_a = 8.0L);

  m.def(
      "analyze_search_space",
      [](const py::dict& ready_value) {
        const auto ready = parse_ready(ready_value);
        const auto summary = ess::solve_steps::analyze_search_space(ready);
        py::list entries;
        for (const auto& entry : summary.entries) {
          py::list assigned_counts;
          for (const auto& count : entry.assigned_counts) {
            assigned_counts.append(py::dict("kind"_a = count.kind, "count"_a = count.count));
          }
          entries.append(py::dict(
              "from"_a = entry.from,
              "random_pickup"_a = entry.random_pickup,
              "random_pickup_trial"_a = entry.random_pickup_trial,
              "unchanged_count"_a = entry.unchanged_count,
              "assigned_counts"_a = assigned_counts,
              "jobsize_u64"_a = entry.jobsize_u64,
              "jobsize_ld"_a = entry.jobsize_ld,
              "jobsize_saturated"_a = entry.jobsize_saturated,
              "first_candidate_indices"_a = entry.first_candidate_indices,
              "first_candidate_labels"_a = entry.first_candidate_labels,
              "candidate_count_log10"_a = entry.candidate_count_log10));
        }
        return py::dict(
            "total_candidate_count_log10"_a = summary.total_candidate_count_log10,
            "primary_recipe_index"_a = summary.primary_recipe_index,
            "entries"_a = entries);
      },
      "ready"_a);

  m.def(
      "compute_generalized_swap_loop",
      [](const py::dict& ready_value, const py::dict& options_value) {
        const ess::ReadyModel ready = parse_ready(ready_value);
        ess::solve_steps::GeneralizedSwapOptions options;
        if (options_value.contains(py::str("number_starts"))) {
          options.number_starts =
              py::cast<int>(options_value[py::str("number_starts")]);
        }
        if (options_value.contains(py::str("start_index_offset"))) {
          options.start_index_offset =
              py::cast<int>(options_value[py::str("start_index_offset")]);
        }
        if (options_value.contains(py::str("start_index_stride"))) {
          options.start_index_stride =
              py::cast<int>(options_value[py::str("start_index_stride")]);
        }
        if (options_value.contains(py::str("max_steps_per_start"))) {
          options.max_steps_per_start =
              py::cast<int>(options_value[py::str("max_steps_per_start")]);
        }
        if (options_value.contains(py::str("random_shuffle_steps"))) {
          options.random_shuffle_steps =
              py::cast<int>(options_value[py::str("random_shuffle_steps")]);
        }
        if (options_value.contains(py::str("rg_find_factor"))) {
          options.rg_find_factor =
              py::cast<int>(options_value[py::str("rg_find_factor")]);
        }
        if (options_value.contains(py::str("chop_level"))) {
          options.chop_level =
              py::cast<long double>(options_value[py::str("chop_level")]);
        }
        if (options_value.contains(py::str("improvement_tol"))) {
          options.improvement_tol =
              py::cast<long double>(options_value[py::str("improvement_tol")]);
        }
        if (options_value.contains(py::str("time_budget_sec"))) {
          options.time_budget_sec =
              py::cast<long double>(options_value[py::str("time_budget_sec")]);
        }
        if (options_value.contains(py::str("seed"))) {
          options.seed =
              py::cast<unsigned int>(options_value[py::str("seed")]);
        }
        if (options_value.contains(py::str("site_groups"))) {
          for (const auto& item :
               py::cast<py::list>(options_value[py::str("site_groups")])) {
            auto dict = py::cast<py::dict>(item);
            ess::solve_steps::GeneralizedSiteGroupRule rule;
            rule.name = require<std::string>(dict, "name");
            rule.source_kind = require<std::string>(dict, "source_kind");
            for (const auto& allowed :
                 py::cast<py::list>(dict[py::str("allowed")])) {
              rule.allowed.push_back(py::cast<std::string>(allowed));
            }
            options.site_groups.push_back(rule);
          }
        }
        if (options_value.contains(py::str("element_charges"))) {
          for (const auto& item :
               py::cast<py::list>(options_value[py::str("element_charges")])) {
            auto dict = py::cast<py::dict>(item);
            ess::ChargeEntry charge;
            charge.kind = require<std::string>(dict, "kind");
            charge.oxidation = require<long double>(dict, "oxidation");
            options.element_charges.push_back(charge);
          }
        }
        if (options_value.contains(py::str("site_charges"))) {
          for (const auto& item :
               py::cast<py::list>(options_value[py::str("site_charges")])) {
            auto dict = py::cast<py::dict>(item);
            ess::solve_steps::GeneralizedChargeEntry charge;
            charge.kind = require<std::string>(dict, "kind");
            charge.site_group = require<std::string>(dict, "site_group");
            charge.oxidation = require<long double>(dict, "oxidation");
            options.site_charges.push_back(charge);
          }
        }

        const auto result =
            ess::solve_steps::compute_generalized_swap_loop(ready, options);

        py::list starts;
        for (const auto& start : result.starts) {
          starts.append(py::dict(
              "start_index"_a = start.start_index,
              "initial_energy"_a = start.initial_energy,
              "final_energy"_a = start.final_energy,
              "accepted_moves"_a = start.accepted_moves));
        }
        py::list accepted;
        for (const auto& move : result.accepted) {
          accepted.append(py::dict(
              "start_index"_a = move.start_index,
              "step"_a = move.step,
              "site_a"_a = move.site_a,
              "site_b"_a = move.site_b,
              "group_a"_a = move.group_a,
              "group_b"_a = move.group_b,
              "kind_a_before"_a = move.kind_a_before,
              "kind_b_before"_a = move.kind_b_before,
              "denrg"_a = move.denrg,
              "energy_after"_a = move.energy_after));
        }
        return py::dict(
            "best_structure"_a = structure_dict(result.best_structure),
            "initial_energy"_a = result.initial_energy,
            "best_energy"_a = result.best_energy,
            "starts_evaluated"_a = result.starts_evaluated,
            "accepted_moves"_a = result.accepted_moves,
            "stopped_by_no_improvement"_a = result.stopped_by_no_improvement,
            "group_by_site"_a = result.group_by_site,
            "cache_stats"_a = py::dict(
                "full_evaluations"_a = result.cache_stats.full_evaluations,
                "diff_evaluations"_a = result.cache_stats.diff_evaluations,
                "real_cache_evaluations"_a = result.cache_stats.real_cache_evaluations,
                "real_incremental_updates"_a = result.cache_stats.real_incremental_updates,
                "point_cache_evaluations"_a = result.cache_stats.point_cache_evaluations,
                "point_incremental_updates"_a = result.cache_stats.point_incremental_updates,
                "recip_cache_evaluations"_a = result.cache_stats.recip_cache_evaluations,
                "recip_state_rebuilds"_a = result.cache_stats.recip_state_rebuilds,
                "recip_incremental_updates"_a = result.cache_stats.recip_incremental_updates,
                "recip_fallback_evaluations"_a = result.cache_stats.recip_fallback_evaluations,
                "diff_cache_enabled"_a = result.cache_stats.diff_cache_enabled,
                "real_pair_terms"_a = result.cache_stats.real_pair_terms,
                "recip_kpoint_terms"_a = result.cache_stats.recip_kpoint_terms),
            "starts"_a = starts,
            "accepted"_a = accepted,
            "log"_a = result.log);
      },
      "ready"_a,
      "options"_a = py::dict());

  m.def(
      "compute_swap_loop",
      [](const py::dict& ready_value, const py::dict& options_value) {
        const ess::ReadyModel ready = parse_ready(ready_value);
        ess::solve_steps::SwapLoopOptions options;
        if (options_value.contains(py::str("mode"))) {
          options.mode = py::cast<int>(options_value[py::str("mode")]);
        }
        if (options_value.contains(py::str("max_swap"))) {
          options.max_swap =
              py::cast<int>(options_value[py::str("max_swap")]);
        }
        if (options_value.contains(py::str("rg_find_factor"))) {
          options.rg_find_factor =
              py::cast<int>(options_value[py::str("rg_find_factor")]);
        }
        if (options_value.contains(py::str("chop_level"))) {
          options.chop_level =
              py::cast<long double>(options_value[py::str("chop_level")]);
        }
        if (options_value.contains(py::str("starting_sites"))) {
          for (const auto& item :
               py::cast<py::list>(options_value[py::str("starting_sites")])) {
            options.starting_sites.push_back(
                parse_site(py::cast<py::dict>(item)));
          }
        }

        const auto result =
            ess::solve_steps::compute_swap_loop(ready, options);

        py::list final_sites;
        for (const auto& site : result.final_structure.sites) {
          final_sites.append(py::dict(
              "kind"_a = site.kind,
              "oxidation"_a = site.oxidation,
              "x"_a = site.x,
              "y"_a = site.y,
              "z"_a = site.z));
        }
        py::dict final_structure = py::dict(
            "title"_a = result.final_structure.title,
            "lattice"_a = py::dict(
                "a"_a = result.final_structure.lattice.a,
                "b"_a = result.final_structure.lattice.b,
                "c"_a = result.final_structure.lattice.c),
            "sites"_a = final_sites,
            "fractional_coordinates"_a =
                result.final_structure.fractional_coordinates);

        py::list committed;
        for (const auto& acceptance : result.committed_swaps) {
          committed.append(py::dict(
              "round"_a = acceptance.round,
              "recipe_index"_a = acceptance.recipe_index,
              "site_a_supercell_index"_a = acceptance.site_a_supercell_index,
              "site_b_supercell_index"_a = acceptance.site_b_supercell_index,
              "kind_a_before"_a = acceptance.kind_a_before,
              "kind_b_before"_a = acceptance.kind_b_before,
              "energy_after"_a = acceptance.energy_after,
              "denrg"_a = acceptance.denrg));
        }

        return py::dict(
            "final_structure"_a = final_structure,
            "initial_total_energy"_a = result.initial_total_energy,
            "final_total_energy"_a = result.final_total_energy,
            "de_min_swap"_a = result.de_min_swap,
            "swap_count"_a = result.swap_count,
            "stopped_by_max_swap"_a = result.stopped_by_max_swap,
            "stopped_by_no_improvement"_a =
                result.stopped_by_no_improvement,
            "cache_stats"_a = py::dict(
                "full_evaluations"_a = result.cache_stats.full_evaluations,
                "diff_evaluations"_a = result.cache_stats.diff_evaluations,
                "real_cache_evaluations"_a = result.cache_stats.real_cache_evaluations,
                "real_incremental_updates"_a = result.cache_stats.real_incremental_updates,
                "point_cache_evaluations"_a = result.cache_stats.point_cache_evaluations,
                "point_incremental_updates"_a = result.cache_stats.point_incremental_updates,
                "recip_cache_evaluations"_a = result.cache_stats.recip_cache_evaluations,
                "recip_state_rebuilds"_a = result.cache_stats.recip_state_rebuilds,
                "recip_incremental_updates"_a = result.cache_stats.recip_incremental_updates,
                "recip_fallback_evaluations"_a = result.cache_stats.recip_fallback_evaluations,
                "diff_cache_enabled"_a = result.cache_stats.diff_cache_enabled,
                "real_pair_terms"_a = result.cache_stats.real_pair_terms,
                "recip_kpoint_terms"_a = result.cache_stats.recip_kpoint_terms),
            "committed_swaps"_a = committed,
            "log"_a = result.log);
      },
      "ready"_a,
      "options"_a = py::dict());
}
