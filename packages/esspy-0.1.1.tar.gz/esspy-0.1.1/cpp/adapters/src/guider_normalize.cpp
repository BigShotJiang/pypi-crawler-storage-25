#include "ess/guider_normalize.hpp"

#include <cmath>
#include <filesystem>
#include <stdexcept>

#include "ess/poscar_adapter.hpp"

namespace ess::adapter {

namespace {

std::filesystem::path resolve_base_dir(
    const std::string& guider_path,
    const std::string& explicit_base_dir) {
  if (!explicit_base_dir.empty()) {
    return std::filesystem::path(explicit_base_dir);
  }
  return std::filesystem::path(guider_path).parent_path();
}

}  // namespace

GuideInput normalize_guider_text(
    const GuiderTextIntermediate& parsed,
    const std::string& base_dir) {
  if (parsed.recipe_lines.empty()) {
    throw std::runtime_error("normalize_guider_text requires at least one recipe line");
  }

  const auto& recipe_line = parsed.recipe_lines.front();
  const auto poscar_path = (std::filesystem::path(base_dir) / recipe_line.poscar_filename).string();

  GuideInput input;
  input.structure = parse_poscar_file(poscar_path);
  input.structure.title = recipe_line.output_prefix;
  input.composition.n_target_sites = parsed.n_target_sites;
  input.composition.number_fixed_at = parsed.number_fixed_at;
  for (const auto& fraction : parsed.target_fractions) {
    input.composition.entries.push_back(
        CompositionEntry{fraction.kind, static_cast<int>(std::llround(fraction.fraction * parsed.n_target_sites))});
  }
  input.charges = parsed.ion_list;
  input.recipes = recipe_line.recipes;
  input.symmetry.space_group = recipe_line.space_group;
  input.options = parsed.options;
  return input;
}

GuideInput parse_guider_text_to_guide_input(
    const std::string& guider_path,
    const std::string& base_dir) {
  const auto parsed = parse_guider_text_file(guider_path);
  return normalize_guider_text(parsed, resolve_base_dir(guider_path, base_dir).string());
}

RunInput parse_guider_text_to_run_input(
    const std::string& guider_path,
    const std::string& base_dir) {
  RunInput input;
  input.guide = parse_guider_text_to_guide_input(guider_path, base_dir);
  return input;
}

}  // namespace ess::adapter
