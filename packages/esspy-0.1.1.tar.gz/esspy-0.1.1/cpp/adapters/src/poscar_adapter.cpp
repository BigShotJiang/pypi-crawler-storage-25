#include "ess/poscar_adapter.hpp"

#include <fstream>
#include <sstream>
#include <stdexcept>
#include <vector>

namespace ess::adapter {

namespace {

std::string trim(const std::string& value) {
  const auto begin = value.find_first_not_of(" \t\r\n");
  if (begin == std::string::npos) {
    return "";
  }
  const auto end = value.find_last_not_of(" \t\r\n");
  return value.substr(begin, end - begin + 1);
}

std::vector<std::string> split_ws(const std::string& value) {
  std::istringstream input(value);
  std::vector<std::string> parts;
  std::string token;
  while (input >> token) {
    parts.push_back(token);
  }
  return parts;
}

std::array<long double, 3> parse_vec3(const std::string& line, const std::string& name) {
  const auto parts = split_ws(line);
  if (parts.size() < 3) {
    throw std::runtime_error("POSCAR " + name + " must have at least 3 numeric values");
  }
  return {
      std::stold(parts[0]),
      std::stold(parts[1]),
      std::stold(parts[2]),
  };
}

std::vector<std::string> read_lines(const std::string& path) {
  std::ifstream input(path);
  if (!input.is_open()) {
    throw std::runtime_error("Could not open POSCAR file: " + path);
  }
  std::vector<std::string> lines;
  std::string line;
  while (std::getline(input, line)) {
    lines.push_back(line);
  }
  return lines;
}

bool starts_with_ci(const std::string& value, char c) {
  if (value.empty()) {
    return false;
  }
  return value[0] == c || value[0] == static_cast<char>(c - 'a' + 'A');
}

}  // namespace

StructureModel parse_poscar_file(const std::string& path) {
  const auto lines = read_lines(path);
  if (lines.size() < 8) {
    throw std::runtime_error("POSCAR is too short: " + path);
  }

  StructureModel structure;
  structure.title = trim(lines[0]);

  const auto scale_parts = split_ws(lines[1]);
  if (scale_parts.empty()) {
    throw std::runtime_error("POSCAR scale line is empty: " + path);
  }
  const long double scale = std::stold(scale_parts[0]);

  const auto vec_a = parse_vec3(lines[2], "vec_a");
  const auto vec_b = parse_vec3(lines[3], "vec_b");
  const auto vec_c = parse_vec3(lines[4], "vec_c");
  structure.lattice.a = {scale * vec_a[0], scale * vec_a[1], scale * vec_a[2]};
  structure.lattice.b = {scale * vec_b[0], scale * vec_b[1], scale * vec_b[2]};
  structure.lattice.c = {scale * vec_c[0], scale * vec_c[1], scale * vec_c[2]};

  const auto species = split_ws(lines[5]);
  const auto count_tokens = split_ws(lines[6]);
  if (species.size() != count_tokens.size()) {
    throw std::runtime_error("Species/count mismatch in POSCAR: " + path);
  }
  std::vector<int> counts;
  counts.reserve(count_tokens.size());
  for (const auto& token : count_tokens) {
    counts.push_back(std::stoi(token));
  }

  std::size_t mode_index = 7;
  std::string mode_line = trim(lines[mode_index]);
  if (starts_with_ci(mode_line, 's')) {
    ++mode_index;
    if (mode_index >= lines.size()) {
      throw std::runtime_error("POSCAR ended after Selective dynamics line: " + path);
    }
    mode_line = trim(lines[mode_index]);
  }

  if (starts_with_ci(mode_line, 'd')) {
    structure.fractional_coordinates = true;
  } else if (starts_with_ci(mode_line, 'c')) {
    structure.fractional_coordinates = false;
  } else {
    throw std::runtime_error("Unknown coordinate mode in POSCAR: " + mode_line);
  }

  const std::size_t coord_start = mode_index + 1;
  int total_sites = 0;
  for (const auto count : counts) {
    total_sites += count;
  }
  if (lines.size() < coord_start + static_cast<std::size_t>(total_sites)) {
    throw std::runtime_error("POSCAR has fewer coordinate lines than expected: " + path);
  }

  std::size_t site_index = 0;
  for (std::size_t species_index = 0; species_index < species.size(); ++species_index) {
    for (int count = 0; count < counts[species_index]; ++count) {
      const auto parts = split_ws(lines[coord_start + site_index]);
      if (parts.size() < 3) {
        throw std::runtime_error("Malformed coordinate line in POSCAR: " + path);
      }
      Site site;
      site.kind = species[species_index];
      site.x = std::stold(parts[0]);
      site.y = std::stold(parts[1]);
      site.z = std::stold(parts[2]);
      structure.sites.push_back(site);
      ++site_index;
    }
  }

  return structure;
}

}  // namespace ess::adapter
