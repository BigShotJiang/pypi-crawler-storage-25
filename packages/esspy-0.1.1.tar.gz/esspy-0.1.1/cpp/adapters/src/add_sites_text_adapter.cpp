#include "ess/add_sites_text_adapter.hpp"

#include <fstream>
#include <sstream>
#include <stdexcept>

namespace ess::adapter {
namespace {

std::string trim(const std::string& value) {
  const auto begin = value.find_first_not_of(" \t\r\n");
  if (begin == std::string::npos) {
    return "";
  }
  const auto end = value.find_last_not_of(" \t\r\n");
  return value.substr(begin, end - begin + 1);
}

std::vector<std::string> split_ws(const std::string& value) {
  std::istringstream input(value);
  std::vector<std::string> parts;
  std::string token;
  while (input >> token) {
    parts.push_back(token);
  }
  return parts;
}

bool starts_with(const std::string& value, const std::string& prefix) {
  return value.rfind(prefix, 0) == 0;
}

std::vector<std::string> read_lines(const std::string& path) {
  std::ifstream input(path);
  if (!input.is_open()) {
    throw std::runtime_error("Could not open solver text file: " + path);
  }
  std::vector<std::string> lines;
  std::string line;
  while (std::getline(input, line)) {
    lines.push_back(line);
  }
  return lines;
}

bool skip_line(const std::string& line) {
  const auto cleaned = trim(line);
  return cleaned.empty() || starts_with(cleaned, "#");
}

}  // namespace

AddSitesMonteCarloSpec parse_add_sites_monte_carlo_spec(const std::string& path) {
  const auto lines = read_lines(path);
  AddSitesMonteCarloSpec spec;

  std::size_t section_index = lines.size();
  for (std::size_t index = 0; index < lines.size(); ++index) {
    const auto line = trim(lines[index]);
    if (skip_line(line)) {
      continue;
    }
    const auto parts = split_ws(line);
    if (parts.empty()) {
      continue;
    }
    if (starts_with(parts.front(), "NAddKind")) {
      if (parts.size() < 2) {
        throw std::runtime_error("Malformed NAddKind line in " + path);
      }
      spec.present = true;
      spec.n_add_kind = std::stoi(parts.back());
      section_index = index + 1;
      break;
    }
  }

  if (!spec.present || spec.n_add_kind <= 0) {
    return spec;
  }

  bool have_meshes = false;
  bool have_min_dist = false;
  bool have_n_mc = false;
  bool have_monitor = false;

  for (std::size_t index = section_index; index < lines.size(); ++index) {
    const auto line = trim(lines[index]);
    if (skip_line(line)) {
      continue;
    }
    const auto parts = split_ws(line);
    if (parts.empty()) {
      continue;
    }
    const auto& key = parts.front();

    if (key == "AddMeshes") {
      if (parts.size() < 4) {
        throw std::runtime_error("Malformed AddMeshes line in " + path);
      }
      spec.add_meshes = {
          std::stold(parts[1]),
          std::stold(parts[2]),
          std::stold(parts[3]),
      };
      have_meshes = true;
      continue;
    }

    if (key == "MinDistanceBetweenAddedSites") {
      if (parts.size() < 2) {
        throw std::runtime_error("Malformed MinDistanceBetweenAddedSites line in " + path);
      }
      spec.min_distance_between_added_sites = std::stold(parts[1]);
      have_min_dist = true;
      continue;
    }

    if (key == "NMonteCarlo") {
      if (parts.size() < 2) {
        throw std::runtime_error("Malformed NMonteCarlo line in " + path);
      }
      spec.n_monte_carlo = std::stoi(parts[1]);
      have_n_mc = true;
      continue;
    }

    if (key == "MonteCarloMonitorIndex") {
      if (parts.size() < 2) {
        throw std::runtime_error("Malformed MonteCarloMonitorIndex line in " + path);
      }
      spec.monte_carlo_monitor_index = std::stoi(parts[1]);
      have_monitor = true;
      continue;
    }

    if (have_meshes && have_min_dist && have_n_mc && have_monitor) {
      AddedKindSpec added_kind;
      if (parts.size() < 3) {
        throw std::runtime_error("Malformed ADDEDKIND line in " + path);
      }
      added_kind.kind = parts[0];
      added_kind.n_added = std::stoi(parts[1]);
      added_kind.oxidation = std::stold(parts[2]);
      if ((parts.size() - 3) % 4 != 0) {
        throw std::runtime_error("Malformed NEIGHBORKIND payload in " + path);
      }
      for (std::size_t offset = 3; offset + 3 < parts.size(); offset += 4) {
        NeighborKindSpec neighbor;
        neighbor.kind = parts[offset];
        neighbor.doxidation = std::stold(parts[offset + 1]);
        neighbor.dist_min = std::stold(parts[offset + 2]);
        neighbor.dist_max = std::stold(parts[offset + 3]);
        added_kind.neighbor_kinds.push_back(neighbor);
      }
      spec.added_kinds.push_back(added_kind);
      if (static_cast<int>(spec.added_kinds.size()) == spec.n_add_kind) {
        return spec;
      }
    }
  }

  if (!have_meshes || !have_min_dist || !have_n_mc || !have_monitor) {
    throw std::runtime_error("Missing add-sites Monte Carlo scalar fields in " + path);
  }
  if (static_cast<int>(spec.added_kinds.size()) != spec.n_add_kind) {
    throw std::runtime_error("ADDEDKIND count does not match NAddKind in " + path);
  }
  return spec;
}

}  // namespace ess::adapter
