#include "ess/guider_text_adapter.hpp"

#include <fstream>
#include <regex>
#include <sstream>
#include <stdexcept>

namespace ess::adapter {

namespace {

std::string trim(const std::string& value) {
  const auto begin = value.find_first_not_of(" \t\r\n");
  if (begin == std::string::npos) {
    return "";
  }
  const auto end = value.find_last_not_of(" \t\r\n");
  return value.substr(begin, end - begin + 1);
}

std::vector<std::string> split_ws(const std::string& value) {
  std::istringstream input(value);
  std::vector<std::string> parts;
  std::string token;
  while (input >> token) {
    parts.push_back(token);
  }
  return parts;
}

bool starts_with(const std::string& value, const std::string& prefix) {
  return value.rfind(prefix, 0) == 0;
}

std::vector<FractionEntry> parse_target_line(const std::string& line) {
  const auto parts = split_ws(line);
  if (parts.size() < 3 || (parts.size() - 1) % 2 != 0) {
    throw std::runtime_error("Malformed Target line");
  }
  std::vector<FractionEntry> result;
  for (std::size_t index = 1; index < parts.size(); index += 2) {
    result.push_back(FractionEntry{parts[index], std::stold(parts[index + 1])});
  }
  return result;
}

ChargeMap parse_ion_list(const std::vector<std::string>& lines) {
  ChargeMap charges;
  for (const auto& line : lines) {
    const auto parts = split_ws(line);
    if (parts.size() >= 2) {
      charges.values.push_back(ChargeEntry{parts[0], std::stold(parts[1])});
    }
  }
  return charges;
}

std::vector<RecipeSpec> parse_recipe_specs(const std::string& line) {
  static const std::regex recipe_pattern(R"(\(\s*([A-Za-z0-9_]+)\s*->\s*([A-Za-z0-9_\s]+?)\s*\))");
  std::vector<RecipeSpec> recipes;
  for (auto it = std::sregex_iterator(line.begin(), line.end(), recipe_pattern);
       it != std::sregex_iterator(); ++it) {
    RecipeSpec recipe;
    recipe.from = (*it)[1].str();
    recipe.to = split_ws((*it)[2].str());
    recipes.push_back(recipe);
  }
  return recipes;
}

GuiderRecipeLine parse_recipe_line(const std::string& line) {
  const auto parts = split_ws(line);
  if (parts.size() < 5) {
    throw std::runtime_error("Malformed guider recipe line");
  }
  GuiderRecipeLine entry;
  entry.poscar_filename = parts[0];
  entry.output_prefix = parts[1];
  entry.space_group = std::stoi(parts[2]);
  entry.recipes = parse_recipe_specs(line);
  entry.raw_line = line;

  static const std::regex nrecipe_pattern(R"(NRecipe=\s*([0-9]+))");
  std::smatch match;
  if (std::regex_search(line, match, nrecipe_pattern)) {
    entry.declared_n_recipe = std::stoi(match[1].str());
  }
  return entry;
}

std::vector<std::string> read_lines(const std::string& path) {
  std::ifstream input(path);
  if (!input.is_open()) {
    throw std::runtime_error("Could not open guider text file: " + path);
  }
  std::vector<std::string> lines;
  std::string line;
  while (std::getline(input, line)) {
    lines.push_back(line);
  }
  return lines;
}

void push_scalar_field(GuiderTextIntermediate& parsed,
                       const std::string& key,
                       const std::string& value) {
  parsed.scalar_fields.push_back({key, value});
}

GuideOptions parse_options_from_scalar_fields(
    const std::vector<std::pair<std::string, std::string>>& fields) {
  GuideOptions options;
  for (const auto& [key, value] : fields) {
    if (key == "NRandomSeeds") {
      options.n_random_seeds = std::stoi(value);
    } else if (key == "ShellWidth") {
      options.shell_width = std::stold(value);
    } else if (key == "WYCIdentityLength") {
      options.wyc_identity_length = std::stold(value);
    } else if (key == "ABCWeights") {
      const auto parts = split_ws(value);
      if (parts.size() == 3) {
        options.abc_weights = {
            std::stold(parts[0]),
            std::stold(parts[1]),
            std::stold(parts[2]),
        };
      }
    } else if (key == "ChopLevel") {
      options.chop_level = std::stold(value);
    } else if (key == "TargetCPUTimeInSec") {
      options.target_cpu_time_sec = std::stoi(value);
    } else if (key == "StrictNoAddedSites") {
      options.strict_no_added_sites =
          value == "1" || value == "true" || value == "TRUE" || value == "True";
    } else if (key == "SkipRGOptimization") {
      options.skip_rg_optimization =
          value == "1" || value == "true" || value == "TRUE" || value == "True";
    } else if (key == "SkipEwaldEvaluation") {
      options.skip_ewald_evaluation =
          value == "1" || value == "true" || value == "TRUE" || value == "True";
    }
  }
  return options;
}

}  // namespace

GuiderTextIntermediate parse_guider_text_file(const std::string& path) {
  auto lines = read_lines(path);
  GuiderTextIntermediate parsed;

  for (std::size_t index = 0; index < lines.size(); ++index) {
    const auto line = trim(lines[index]);
    if (line.empty()) {
      continue;
    }
    if (starts_with(line, "Target\t") || starts_with(line, "Target ")) {
      parsed.target_fractions = parse_target_line(line);
      push_scalar_field(parsed, "Target", line);
      continue;
    }
    if (starts_with(line, "NumberFixedAt")) {
      parsed.number_fixed_at = split_ws(line).back();
      push_scalar_field(parsed, "NumberFixedAt", parsed.number_fixed_at);
      continue;
    }
    if (starts_with(line, "NTargetSites")) {
      parsed.n_target_sites = std::stoi(split_ws(line).back());
      push_scalar_field(parsed, "NTargetSites", std::to_string(parsed.n_target_sites));
      continue;
    }

    if (starts_with(line, "====") || starts_with(line, "=====")) {
      GuiderSection section;
      section.header = line;
      ++index;
      while (index < lines.size() && trim(lines[index]) != "STOP") {
        section.lines.push_back(lines[index]);
        ++index;
      }
      parsed.sections.push_back(section);

      if (section.header == "====IonList====") {
        parsed.ion_list = parse_ion_list(section.lines);
      } else if (section.header == "====InputFilename_Prefix_SapceGroup_Recipe_List====") {
        for (const auto& recipe_line : section.lines) {
          const auto trimmed = trim(recipe_line);
          if (!trimmed.empty()) {
            parsed.recipe_lines.push_back(parse_recipe_line(trimmed));
          }
        }
      } else if (starts_with(section.header, "=====SH_Header_forESS")) {
        parsed.sh_header_for_ess = section.lines;
      } else if (starts_with(section.header, "=====SH_Header_forVASP")) {
        parsed.sh_header_for_vasp = section.lines;
      }
      continue;
    }

    const auto parts = split_ws(line);
    if (parts.empty()) {
      continue;
    }
    const auto key = parts.front();
    const auto value = trim(line.substr(key.size()));
    if (key == "NRandomSeeds" || key == "ShellWidth" || key == "WYCIdentityLength" ||
        key == "ABCWeights" || key == "ChopLevel" || key == "TargetCPUTimeInSec" ||
        key == "StrictNoAddedSites" || key == "SkipRGOptimization" ||
        key == "SkipEwaldEvaluation" || key == "OutputFilename" ||
        key == "SHJobnameCommand" || key == "WhichESS" || key == "WhichEwald2VASP++" ||
        key == "WhichVASP" || key == "QSubCommand(ForChain)" ||
        key == "ChainCommand(WorksForAFTERANY_Only)" || key == "MPIcommand" ||
        key == "VASPTransfer(Yes1No0)" || key == "VASPNPAR" ||
        key == "VASPOutputDirectory" || key == "VASPPseudoDir" ||
        key == "VASPMLFF(Yes1No0)" || key == "VASPGGA") {
      push_scalar_field(parsed, key, trim(value));
    } else {
      parsed.unknown_lines.push_back(line);
    }
  }

  parsed.options = parse_options_from_scalar_fields(parsed.scalar_fields);
  if (parsed.target_fractions.empty()) {
    throw std::runtime_error("Missing Target block in guider text file: " + path);
  }
  if (parsed.n_target_sites == 0) {
    throw std::runtime_error("Missing NTargetSites in guider text file: " + path);
  }
  if (parsed.recipe_lines.empty()) {
    throw std::runtime_error("Missing InputFilename/Recipe block in guider text file: " + path);
  }
  return parsed;
}

}  // namespace ess::adapter
