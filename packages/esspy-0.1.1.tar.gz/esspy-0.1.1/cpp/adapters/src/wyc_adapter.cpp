#include "ess/wyc_adapter.hpp"

#include <fstream>
#include <sstream>
#include <stdexcept>

namespace ess::adapter {

WycFile parse_wyc_file(const std::string& path) {
  std::ifstream input(path);
  if (!input.is_open()) {
    throw std::runtime_error("Could not open wyc file: " + path);
  }

  WycFile result;
  if (!(input >> result.header_key >> result.declared_n_wyc)) {
    throw std::runtime_error("Malformed wyc header in: " + path);
  }

  result.entries.reserve(static_cast<std::size_t>(
      result.declared_n_wyc > 0 ? result.declared_n_wyc : 0));

  for (int index = 0; index < result.declared_n_wyc; ++index) {
    WycEntry entry;
    if (!(input >> entry.label)) {
      throw std::runtime_error(
          "Missing label for wyc entry " + std::to_string(index) + " in: " +
          path);
    }
    for (int row = 0; row < 3; ++row) {
      for (int col = 0; col < 4; ++col) {
        if (!(input >> entry.matrix[row][col])) {
          throw std::runtime_error(
              "Missing matrix value for wyc entry " +
              std::to_string(index) + " (row " + std::to_string(row) +
              ", col " + std::to_string(col) + ") in: " + path);
        }
      }
    }
    result.entries.push_back(entry);
  }

  return result;
}

SymmetryModel parse_wyc_file_to_symmetry_model(const std::string& path,
                                               int space_group) {
  const WycFile parsed = parse_wyc_file(path);

  SymmetryModel symmetry;
  symmetry.space_group = space_group;
  symmetry.from_spglib = false;
  for (const auto& entry : parsed.entries) {
    SymmetryOperation operation;
    operation.matrix = entry.matrix;
    symmetry.wyc_operations.push_back(operation);
  }
  return symmetry;
}

}  // namespace ess::adapter
