#pragma once

#include <array>
#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess::adapter {

// Raw entry parsed from a `<SpaceGroup>.wyc` file. The original Guider's
// read_wyc reads three rows of four long-double values per entry, with an
// optional leading label token (typically a Wyckoff-position name such as
// "P1", "1a", "2c"). We preserve the label here even though add_ions itself
// does not consume it, so future tooling and golden tests can compare the
// label list as well.
struct WycEntry {
  std::string label;
  std::array<std::array<long double, 4>, 3> matrix{{
      {{1.0L, 0.0L, 0.0L, 0.0L}},
      {{0.0L, 1.0L, 0.0L, 0.0L}},
      {{0.0L, 0.0L, 1.0L, 0.0L}},
  }};
};

// Raw parsed contents of a `.wyc` file: the first line carries
// `<key> <Nwyc>` (the original Guider ignores the key text), and the
// remaining lines are the entries. `declared_n_wyc` is the integer that
// follows the leading key, and `entries.size()` should equal it for a
// well-formed file.
struct WycFile {
  std::string header_key;
  int declared_n_wyc = 0;
  std::vector<WycEntry> entries;
};

// Parse a `<SpaceGroup>.wyc` file in the format produced and consumed by
// the original Guider. Throws std::runtime_error when the file cannot be
// opened or when fewer entries are present than the header advertised.
WycFile parse_wyc_file(const std::string& path);

// Convenience helper that wraps parse_wyc_file and produces a typed
// SymmetryModel ready to be plugged into a GuideInput. The space-group
// number is taken from the caller because the original Guider reads it
// from the recipe line, not from the wyc file itself.
SymmetryModel parse_wyc_file_to_symmetry_model(const std::string& path,
                                               int space_group);

}  // namespace ess::adapter
