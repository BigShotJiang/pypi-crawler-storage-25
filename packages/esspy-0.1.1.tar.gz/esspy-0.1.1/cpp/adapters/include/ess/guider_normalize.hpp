#pragma once

#include <string>

#include "ess/core.hpp"
#include "ess/guider_text_adapter.hpp"

namespace ess::adapter {

GuideInput normalize_guider_text(
    const GuiderTextIntermediate& parsed,
    const std::string& base_dir);

GuideInput parse_guider_text_to_guide_input(
    const std::string& guider_path,
    const std::string& base_dir = "");

RunInput parse_guider_text_to_run_input(
    const std::string& guider_path,
    const std::string& base_dir = "");

}
