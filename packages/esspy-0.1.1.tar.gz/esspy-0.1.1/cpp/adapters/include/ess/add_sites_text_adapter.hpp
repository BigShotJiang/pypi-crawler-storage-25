#pragma once

#include <array>
#include <string>
#include <vector>

namespace ess::adapter {

struct NeighborKindSpec {
  std::string kind;
  long double doxidation = 0.0L;
  long double dist_min = 0.0L;
  long double dist_max = 0.0L;
};

struct AddedKindSpec {
  std::string kind;
  int n_added = 0;
  long double oxidation = 0.0L;
  std::vector<NeighborKindSpec> neighbor_kinds;
};

struct AddSitesMonteCarloSpec {
  bool present = false;
  int n_add_kind = 0;
  std::array<long double, 3> add_meshes{0.0L, 0.0L, 0.0L};
  long double min_distance_between_added_sites = 0.0L;
  int n_monte_carlo = 0;
  int monte_carlo_monitor_index = 0;
  std::vector<AddedKindSpec> added_kinds;
};

AddSitesMonteCarloSpec parse_add_sites_monte_carlo_spec(const std::string& path);

}  // namespace ess::adapter
