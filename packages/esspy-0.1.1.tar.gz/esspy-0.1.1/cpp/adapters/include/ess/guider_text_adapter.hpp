#pragma once

#include <string>
#include <utility>
#include <vector>

#include "ess/core.hpp"

namespace ess::adapter {

struct FractionEntry {
  std::string kind;
  long double fraction = 0.0L;
};

struct GuiderSection {
  std::string header;
  std::vector<std::string> lines;
};

struct GuiderRecipeLine {
  std::string poscar_filename;
  std::string output_prefix;
  int space_group = 1;
  int declared_n_recipe = 0;
  std::vector<RecipeSpec> recipes;
  std::string raw_line;
};

struct GuiderTextIntermediate {
  std::vector<FractionEntry> target_fractions;
  std::string number_fixed_at = "O";
  int n_target_sites = 0;
  GuideOptions options;
  ChargeMap ion_list;
  std::vector<GuiderRecipeLine> recipe_lines;
  std::vector<GuiderSection> sections;
  std::vector<std::pair<std::string, std::string>> scalar_fields;
  std::vector<std::string> sh_header_for_ess;
  std::vector<std::string> sh_header_for_vasp;
  std::vector<std::string> unknown_lines;
};

GuiderTextIntermediate parse_guider_text_file(const std::string& path);

}  // namespace ess::adapter
