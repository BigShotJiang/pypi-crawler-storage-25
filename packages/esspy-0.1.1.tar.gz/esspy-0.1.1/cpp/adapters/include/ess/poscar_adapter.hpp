#pragma once

#include <string>

#include "ess/core.hpp"

namespace ess::adapter {

StructureModel parse_poscar_file(const std::string& path);

}
