#include "ess/solve_work_slice.hpp"

#include <algorithm>

namespace ess::solve_steps {

WorkSliceSummary analyze_work_slice(
    const SearchSpaceSummary& search_space,
    const ParallelRuntimeOptions& runtime) {
  WorkSliceSummary summary;
  summary.primary_recipe_index = search_space.primary_recipe_index;
  summary.world_size = std::max(1, runtime.world_size);
  summary.rank = std::max(0, std::min(runtime.rank, summary.world_size - 1));

  unsigned long long xpr_size_maximum = 0;
  for (std::size_t index = 0; index < search_space.entries.size(); ++index) {
    xpr_size_maximum = std::max(xpr_size_maximum, search_space.entries[index].jobsize_u64);
    summary.has_saturated_jobsize =
        summary.has_saturated_jobsize ||
        search_space.entries[index].jobsize_saturated;
  }

  unsigned long long prjobsize_per_rank = 0;
  unsigned long long remain_ranks = 0;
  if (summary.world_size > 0) {
    prjobsize_per_rank =
        xpr_size_maximum / static_cast<unsigned long long>(summary.world_size);
    remain_ranks =
        xpr_size_maximum -
        prjobsize_per_rank * static_cast<unsigned long long>(summary.world_size);
  }

  std::vector<unsigned long long> pr_job_size(static_cast<std::size_t>(summary.world_size), 0);
  for (int i = 0; i < summary.world_size; ++i) {
    pr_job_size[static_cast<std::size_t>(i)] = prjobsize_per_rank;
    if (static_cast<unsigned long long>(i) < remain_ranks) {
      pr_job_size[static_cast<std::size_t>(i)]++;
    }
  }

  std::vector<WorkSliceRange> pr_job(static_cast<std::size_t>(summary.world_size));
  unsigned long long cursor = 0;
  for (int i = 0; i < summary.world_size; ++i) {
    pr_job[static_cast<std::size_t>(i)].start = cursor;
    cursor += pr_job_size[static_cast<std::size_t>(i)];
    pr_job[static_cast<std::size_t>(i)].end =
        (cursor == 0 ? 0 : cursor - 1);
  }

  if (!pr_job.empty()) {
    for (int i = 0; i < summary.world_size; ++i) {
      if (pr_job_size[static_cast<std::size_t>(i)] == 0) {
        const unsigned long long finite =
            pr_job[static_cast<std::size_t>(std::max(0, i - 1))].end;
        pr_job[static_cast<std::size_t>(i)].start = finite;
        pr_job[static_cast<std::size_t>(i)].end = finite;
        pr_job_size[static_cast<std::size_t>(i)] = 1;
      }
    }
  }

  for (std::size_t index = 0; index < search_space.entries.size(); ++index) {
    WorkSliceRange range;
    range.recipe_index = static_cast<int>(index);
    if (static_cast<int>(index) == search_space.primary_recipe_index) {
      range.start = pr_job[static_cast<std::size_t>(summary.rank)].start;
      range.end = pr_job[static_cast<std::size_t>(summary.rank)].end;
    } else {
      range.start = 0;
      range.end =
          (search_space.entries[index].jobsize_u64 == 0
               ? 0
               : search_space.entries[index].jobsize_u64 - 1);
    }
    summary.recipe_ranges.push_back(range);
  }

  return summary;
}

}  // namespace ess::solve_steps
