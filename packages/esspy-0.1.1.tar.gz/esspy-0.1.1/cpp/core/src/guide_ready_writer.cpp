#include "ess/guide_ready_writer.hpp"

#include <iomanip>
#include <sstream>
#include <string>
#include <cctype>

namespace ess::guide_steps {

namespace {

// 154 '=' characters, matching the original Guider's save_outputlines() and
// write_basic2VASP separators byte-for-byte.
constexpr const char* kSeparatorLine =
    "=========================================================================="
    "================================================================"
    "================";

std::string write_with_precision(long double value, int precision) {
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(precision) << value;
  return oss.str();
}

std::string format_vec3_line(const char* prefix,
                             const std::array<long double, 3>& vec) {
  std::ostringstream oss;
  oss << prefix << " " << write_with_precision(vec[0], 10) << " "
      << write_with_precision(vec[1], 10) << " "
      << write_with_precision(vec[2], 10);
  return oss.str();
}

std::string sanitize_output_prefix(std::string value) {
  for (char& c : value) {
    if (std::isspace(static_cast<unsigned char>(c))) {
      c = '_';
    }
  }
  if (value.empty()) {
    value = "esspy";
  }
  return value;
}

bool recipe_is_emittable(const ReadyRecipe& recipe) {
  // The original Guider emits a recipe line only when it has at least one
  // modification (including the optional vac entry). Recipes with no
  // modifications and no vac (the O passthrough lines in G001/G002) are
  // dropped from the NRecipe count and from the body.
  return !recipe.modifications.empty();
}

void emit_recipe_line(std::ostringstream& body, const ReadyRecipe& recipe) {
  body << recipe.from << " " << write_with_precision(recipe.oxidation, 3)
       << " " << recipe.random_pickup << " " << recipe.random_pickup_trial;
  for (const auto& modification : recipe.modifications) {
    body << " " << modification.to << " "
         << write_with_precision(modification.oxidation, 3) << " "
         << modification.number;
  }
}

}  // namespace

std::string write_ready_file_text(
    const ReadyModel& ready,
    const ReadyFileWriteOptions& options) {
  std::ostringstream out;

  out << format_vec3_line("vec_a", ready.lattice.a) << "\n";
  out << format_vec3_line("vec_b", ready.lattice.b) << "\n";
  out << format_vec3_line("vec_c", ready.lattice.c) << "\n";
  out << "NAtomConfig " << ready.atoms.size() << "\n";
  out << "AtomConfig\n";
  for (const auto& atom : ready.atoms) {
    out << atom.kind << " " << write_with_precision(atom.oxidation, 3) << " "
        << write_with_precision(atom.x, 10) << " "
        << write_with_precision(atom.y, 10) << " "
        << write_with_precision(atom.z, 10) << "\n";
  }
  out << "SupercellExpansion " << ready.supercell_expansion[0] << " "
      << ready.supercell_expansion[1] << " "
      << ready.supercell_expansion[2] << "\n";
  out << "ChopLevel " << options.chop_level << "\n";
  out << "RGFindFactor " << ready.rg_find_factor << "\n";
  out << "OutputPrefix "
      << sanitize_output_prefix(ready.output_prefix)
      << options.output_prefix_suffix
      << "\n";
  out << "verbose(Yes1No0) " << options.verbose << "\n";
  out << "CreateRecipeStrictMode(Yes1No0) " << options.create_recipe_strict_mode
      << "\n";
  out << "PrintTheStablestUnstablest(Yes1No0) "
      << options.print_stablest_unstablest << "\n";
  const long long running_index_delta =
      options.running_index_delta != 0
          ? options.running_index_delta
          : -static_cast<long long>(options.target_cpu_time_sec);
  out << "RunningIndexDelta(Negative:TargetCPUTimeInSec) "
      << running_index_delta << "\n";
  out << "RunningIndexMonitor(No-1) " << options.running_index_monitor << "\n";
  out << "Swap(NotSteepest2Yes1No0;For_PrintTheStablestUnstablest=1_Only) "
      << options.swap << "\n";
  out << "MaxSwap(NoLimit-1) " << options.max_swap << "\n";
  out << "RestartRecipeFilename(IfNo;none) " << options.restart_recipe_filename
      << "\n";
  out << kSeparatorLine << "\n";

  int n_recipe = 0;
  for (const auto& recipe : ready.recipes) {
    if (recipe_is_emittable(recipe)) {
      ++n_recipe;
    }
  }
  out << "NRecipe " << n_recipe << "\n";
  out << kSeparatorLine << "\n";
  out << "kind=oxidation=random_pickup=random_pickup_trial=[[[to_which("
         "kind;\"vac\"->delete)=to_which(oxidation)=to_which(number)]]]\n";
  out << kSeparatorLine << "\n";
  for (const auto& recipe : ready.recipes) {
    if (!recipe_is_emittable(recipe)) {
      continue;
    }
    emit_recipe_line(out, recipe);
    out << "\n";
  }
  out << kSeparatorLine << "\n";
  out << "NEnergyTableLine(if-1,auto) " << options.n_energy_table_line << "\n";
  out << kSeparatorLine << "\n";
  out << options.energy_table_default_line << "\n";
  out << kSeparatorLine << "\n";
  out << "Tips on SWAP: \"STOPSWAP.txt\" created during swap() will abort "
         "swap() in the middle of swap().";

  return out.str();
}

}  // namespace ess::guide_steps
