#include "ess/guide_poscar_writer.hpp"

#include <iomanip>
#include <sstream>

namespace ess::guide_steps {

namespace {

std::string write_with_precision(long double value, int precision) {
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(precision) << value;
  return oss.str();
}

std::string format_vec3_line(const std::array<long double, 3>& vec) {
  std::ostringstream oss;
  oss << " " << write_with_precision(vec[0], 10) << " "
      << write_with_precision(vec[1], 10) << " "
      << write_with_precision(vec[2], 10);
  return oss.str();
}

}  // namespace

std::string write_poscar_text(const ReadyModel& ready) {
  std::ostringstream out;
  out << ready.output_prefix << "\n";
  out << "1.0\n";
  out << format_vec3_line(ready.lattice.a) << "\n";
  out << format_vec3_line(ready.lattice.b) << "\n";
  out << format_vec3_line(ready.lattice.c) << "\n";
  out << " ";
  for (std::size_t i = 0; i < ready.poscar_species_counts.size(); ++i) {
    out << ready.poscar_species_counts[i].kind;
    if (i + 1 != ready.poscar_species_counts.size()) {
      out << " ";
    }
  }
  out << "\n";
  out << " ";
  for (std::size_t i = 0; i < ready.poscar_species_counts.size(); ++i) {
    out << ready.poscar_species_counts[i].count;
    if (i + 1 != ready.poscar_species_counts.size()) {
      out << " ";
    }
  }
  out << "\n";
  out << "Direct\n";
  for (std::size_t i = 0; i < ready.atoms.size(); ++i) {
    out << " " << write_with_precision(ready.atoms[i].x, 10)
        << " " << write_with_precision(ready.atoms[i].y, 10)
        << " " << write_with_precision(ready.atoms[i].z, 10);
    if (i + 1 != ready.atoms.size()) {
      out << "\n";
    }
  }
  return out.str();
}

}  // namespace ess::guide_steps
