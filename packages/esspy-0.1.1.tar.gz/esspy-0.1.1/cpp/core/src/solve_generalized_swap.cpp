#include "ess/solve_generalized_swap.hpp"

#include <algorithm>
#include <chrono>
#include <limits>
#include <random>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>

#include "ess/ewald_shared.hpp"
#include "ess/solve_recipe_state.hpp"

namespace ess::solve_steps {
namespace {

struct PreparedState {
  StructureModel structure;
  std::vector<std::string> group_by_site;
  std::unordered_map<std::string, std::unordered_set<std::string>> allowed_by_group;
  std::unordered_map<std::string, long double> element_charge;
  std::unordered_map<std::string, long double> site_charge;
};

std::string key_for(const std::string& kind, const std::string& group) {
  return kind + "@" + group;
}

PreparedState prepare_state(
    const ReadyModel& ready,
    const GeneralizedSwapOptions& options) {
  auto canonical = materialize_canonical_structure_with_pools(ready);
  PreparedState prepared;
  prepared.structure = canonical.structure;
  prepared.group_by_site.assign(prepared.structure.sites.size(), "");

  std::unordered_map<std::string, GeneralizedSiteGroupRule> rule_by_source;
  for (const auto& rule : options.site_groups) {
    if (rule.name.empty() || rule.source_kind.empty()) {
      continue;
    }
    rule_by_source[rule.source_kind] = rule;
    auto& allowed = prepared.allowed_by_group[rule.name];
    for (const auto& kind : rule.allowed) {
      if (!kind.empty()) {
        allowed.insert(kind);
      }
    }
  }
  if (prepared.allowed_by_group.empty()) {
    throw std::runtime_error(
        "compute_generalized_swap_loop: site_groups must not be empty");
  }

  for (std::size_t recipe_index = 0;
       recipe_index < canonical.recipe_pools.size(); ++recipe_index) {
    if (recipe_index >= ready.recipes.size()) {
      continue;
    }
    const auto& source = ready.recipes[recipe_index].from;
    auto rule_it = rule_by_source.find(source);
    if (rule_it == rule_by_source.end()) {
      continue;
    }
    const auto& group_name = rule_it->second.name;
    for (const auto idx : canonical.recipe_pools[recipe_index]) {
      if (idx < prepared.group_by_site.size()) {
        prepared.group_by_site[idx] = group_name;
      }
    }
  }

  for (std::size_t i = 0; i < prepared.group_by_site.size(); ++i) {
    if (!prepared.group_by_site[i].empty()) {
      continue;
    }
    const auto source = prepared.structure.sites[i].kind;
    auto rule_it = rule_by_source.find(source);
    if (rule_it != rule_by_source.end()) {
      prepared.group_by_site[i] = rule_it->second.name;
    }
  }

  for (const auto& charge : options.element_charges) {
    prepared.element_charge[charge.kind] = charge.oxidation;
  }
  for (const auto& charge : options.site_charges) {
    prepared.site_charge[key_for(charge.kind, charge.site_group)] = charge.oxidation;
  }

  for (std::size_t i = 0; i < prepared.structure.sites.size(); ++i) {
    const auto& group = prepared.group_by_site[i];
    if (group.empty()) {
      continue;
    }
    auto allowed_it = prepared.allowed_by_group.find(group);
    if (allowed_it == prepared.allowed_by_group.end()) {
      continue;
    }
    if (allowed_it->second.empty()) {
      allowed_it->second.insert(prepared.structure.sites[i].kind);
    }
  }

  return prepared;
}

bool allowed_in_group(
    const PreparedState& state,
    const std::string& kind,
    const std::string& group) {
  const auto it = state.allowed_by_group.find(group);
  if (it == state.allowed_by_group.end()) {
    return true;
  }
  return it->second.find(kind) != it->second.end();
}

long double charge_for(
    const PreparedState& state,
    const std::string& kind,
    const std::string& group,
    long double fallback) {
  const auto site_it = state.site_charge.find(key_for(kind, group));
  if (site_it != state.site_charge.end()) {
    return site_it->second;
  }
  const auto elem_it = state.element_charge.find(kind);
  if (elem_it != state.element_charge.end()) {
    return elem_it->second;
  }
  return fallback;
}

void apply_charges_for_current_groups(PreparedState& state) {
  for (std::size_t i = 0; i < state.structure.sites.size(); ++i) {
    auto& site = state.structure.sites[i];
    const auto& group = state.group_by_site[i];
    site.oxidation = charge_for(state, site.kind, group, site.oxidation);
  }
}

bool valid_swap(
    const PreparedState& state,
    const StructureModel& structure,
    std::size_t a,
    std::size_t b) {
  if (a == b || a >= structure.sites.size() || b >= structure.sites.size()) {
    return false;
  }
  const auto& group_a = state.group_by_site[a];
  const auto& group_b = state.group_by_site[b];
  if (group_a.empty() || group_b.empty()) {
    return false;
  }
  const auto& kind_a = structure.sites[a].kind;
  const auto& kind_b = structure.sites[b].kind;
  if (kind_a == kind_b) {
    return false;
  }
  return allowed_in_group(state, kind_b, group_a) &&
         allowed_in_group(state, kind_a, group_b);
}

void randomize_start(
    PreparedState& state,
    int shuffle_steps,
    std::mt19937& rng) {
  if (state.structure.sites.size() < 2 || shuffle_steps <= 0) {
    return;
  }
  std::uniform_int_distribution<std::size_t> pick(
      0, state.structure.sites.size() - 1);
  const int attempt_limit = std::max<int>(
      shuffle_steps * 20, static_cast<int>(state.structure.sites.size()) * 4);
  int accepted = 0;
  for (int attempt = 0; attempt < attempt_limit && accepted < shuffle_steps; ++attempt) {
    const auto a = pick(rng);
    const auto b = pick(rng);
    if (!valid_swap(state, state.structure, a, b)) {
      continue;
    }
    auto& site_a = state.structure.sites[a];
    auto& site_b = state.structure.sites[b];
    const auto kind_a = site_a.kind;
    const auto kind_b = site_b.kind;
    site_a.kind = kind_b;
    site_b.kind = kind_a;
    site_a.oxidation = charge_for(
        state, site_a.kind, state.group_by_site[a], site_a.oxidation);
    site_b.oxidation = charge_for(
        state, site_b.kind, state.group_by_site[b], site_b.oxidation);
    ++accepted;
  }
}

long double full_energy(
    const StructureModel& structure,
    int rg_find_factor,
    long double chop_level) {
  const ReadyModel view = ready_view_from_structure(structure, rg_find_factor);
  const auto eval = ess::evaluate_ready_energy(view, rg_find_factor, chop_level);
  return eval.total_e;
}

unsigned int seed_for_start(unsigned int seed, int start_index) {
  auto x = static_cast<unsigned int>(start_index) + 0x9e3779b9U + (seed << 6) + (seed >> 2);
  x ^= seed + 0x85ebca6bU;
  x ^= x >> 16;
  x *= 0x7feb352dU;
  x ^= x >> 15;
  x *= 0x846ca68bU;
  x ^= x >> 16;
  return x;
}

}  // namespace

GeneralizedSwapResult compute_generalized_swap_loop(
    const ReadyModel& ready,
    const GeneralizedSwapOptions& options) {
  GeneralizedSwapResult result;
  const auto started_at = std::chrono::steady_clock::now();
  const int total_starts = std::max(1, options.number_starts);
  const int start_offset = std::max(0, options.start_index_offset);
  const int start_stride = std::max(1, options.start_index_stride);
  const int max_steps = std::max(0, options.max_steps_per_start);
  const int shuffle_steps = std::max(0, options.random_shuffle_steps);

  auto budget_exhausted = [&]() {
    if (options.time_budget_sec <= 0.0L) {
      return false;
    }
    const auto now = std::chrono::steady_clock::now();
    const std::chrono::duration<long double> elapsed = now - started_at;
    return elapsed.count() >= options.time_budget_sec;
  };

  auto base = prepare_state(ready, options);
  apply_charges_for_current_groups(base);
  result.group_by_site = base.group_by_site;
  result.initial_energy = full_energy(
      base.structure, options.rg_find_factor, options.chop_level);
  result.best_energy = std::numeric_limits<long double>::infinity();
  result.best_structure = base.structure;

  for (int start_index = start_offset; start_index < total_starts;
       start_index += start_stride) {
    if (budget_exhausted()) {
      result.log.push_back("[GENERALIZED_SWAP] time budget exhausted before next start");
      break;
    }
    if (options.cancel_requested && options.cancel_requested()) {
      throw std::runtime_error("generalized swap loop cancelled");
    }
    PreparedState state = base;
    if (start_index > 0) {
      std::mt19937 start_rng(seed_for_start(options.seed, start_index));
      randomize_start(state, shuffle_steps, start_rng);
    }
    auto cache = create_swap_energy_cache(
        state.structure, options.rg_find_factor, options.chop_level);
    long double current_energy = evaluate_total_with_cache(cache, state.structure);
    const long double start_initial = current_energy;
    int accepted_for_start = 0;

    for (int step = 0; step < max_steps; ++step) {
      if (budget_exhausted()) {
        result.log.push_back("[GENERALIZED_SWAP] time budget exhausted during local search");
        break;
      }
      if (options.cancel_requested && options.cancel_requested()) {
        throw std::runtime_error("generalized swap loop cancelled");
      }

      bool found = false;
      long double best_denrg = 0.0L;
      long double best_after = current_energy;
      std::size_t best_a = 0;
      std::size_t best_b = 0;
      long double best_q_a = 0.0L;
      long double best_q_b = 0.0L;

      for (std::size_t a = 0; a < state.structure.sites.size(); ++a) {
        if (budget_exhausted()) {
          break;
        }
        for (std::size_t b = a + 1; b < state.structure.sites.size(); ++b) {
          if (!valid_swap(state, state.structure, a, b)) {
            continue;
          }
          const auto& site_a = state.structure.sites[a];
          const auto& site_b = state.structure.sites[b];
          const auto& group_a = state.group_by_site[a];
          const auto& group_b = state.group_by_site[b];
          const long double new_q_a = charge_for(
              state, site_b.kind, group_a, site_a.oxidation);
          const long double new_q_b = charge_for(
              state, site_a.kind, group_b, site_b.oxidation);
          const std::vector<std::size_t> changed{a, b};
          const std::vector<long double> new_q{new_q_a, new_q_b};
          const long double denrg = evaluate_site_update_delta_from_cache(
              cache, state.structure, changed, new_q);
          if (denrg < -options.improvement_tol && (!found || denrg < best_denrg)) {
            found = true;
            best_denrg = denrg;
            best_after = current_energy + denrg;
            best_a = a;
            best_b = b;
            best_q_a = new_q_a;
            best_q_b = new_q_b;
          }
        }
      }

      if (!found) {
        break;
      }

      auto& site_a = state.structure.sites[best_a];
      auto& site_b = state.structure.sites[best_b];
      const auto kind_a_before = site_a.kind;
      const auto kind_b_before = site_b.kind;
      const auto group_a = state.group_by_site[best_a];
      const auto group_b = state.group_by_site[best_b];
      const std::vector<std::size_t> changed{best_a, best_b};
      const std::vector<std::string> new_kinds{kind_b_before, kind_a_before};
      const std::vector<long double> new_q{best_q_a, best_q_b};
      commit_site_update_state(cache, state.structure, changed, new_kinds, new_q);
      current_energy = best_after;
      ++accepted_for_start;
      ++result.accepted_moves;

      GeneralizedSwapMove move;
      move.start_index = start_index;
      move.step = step + 1;
      move.site_a = best_a;
      move.site_b = best_b;
      move.group_a = group_a;
      move.group_b = group_b;
      move.kind_a_before = kind_a_before;
      move.kind_b_before = kind_b_before;
      move.denrg = best_denrg;
      move.energy_after = best_after;
      result.accepted.push_back(move);
    }

    const long double verified = full_energy(
        state.structure, options.rg_find_factor, options.chop_level);
    GeneralizedSwapStartSummary summary;
    summary.start_index = start_index;
    summary.initial_energy = start_initial;
    summary.final_energy = verified;
    summary.accepted_moves = accepted_for_start;
    result.starts.push_back(summary);
    result.starts_evaluated += 1;

    result.cache_stats.full_evaluations += cache.stats.full_evaluations;
    result.cache_stats.diff_evaluations += cache.stats.diff_evaluations;
    result.cache_stats.real_cache_evaluations += cache.stats.real_cache_evaluations;
    result.cache_stats.real_incremental_updates += cache.stats.real_incremental_updates;
    result.cache_stats.point_cache_evaluations += cache.stats.point_cache_evaluations;
    result.cache_stats.point_incremental_updates += cache.stats.point_incremental_updates;
    result.cache_stats.recip_cache_evaluations += cache.stats.recip_cache_evaluations;
    result.cache_stats.recip_state_rebuilds += cache.stats.recip_state_rebuilds;
    result.cache_stats.recip_incremental_updates += cache.stats.recip_incremental_updates;
    result.cache_stats.recip_fallback_evaluations += cache.stats.recip_fallback_evaluations;
    result.cache_stats.real_pair_terms += cache.stats.real_pair_terms;
    result.cache_stats.recip_kpoint_terms += cache.stats.recip_kpoint_terms;
    result.cache_stats.diff_cache_enabled =
        result.cache_stats.diff_cache_enabled || cache.stats.diff_cache_enabled;

    if (verified < result.best_energy) {
      result.best_energy = verified;
      result.best_structure = state.structure;
      std::ostringstream oss;
      oss << "[GENERALIZED_SWAP] best start=" << start_index
          << " energy=" << static_cast<double>(verified)
          << " accepted_moves=" << accepted_for_start;
      result.log.push_back(oss.str());
    }
  }

  result.stopped_by_no_improvement = result.accepted_moves == 0;
  return result;
}

}  // namespace ess::solve_steps
