#include "ess/solve_swap_loop.hpp"

#include <cstddef>
#include <sstream>
#include <stdexcept>

#include "ess/ewald_shared.hpp"
#include "ess/solve_swap_cache.hpp"
#include "ess/solve_recipe_state.hpp"

namespace ess::solve_steps {

namespace {

}  // namespace

SwapLoopResult compute_swap_loop(
    const ReadyModel& ready,
    const SwapLoopOptions& options) {
  SwapLoopResult result;
  if (options.mode != 1 && options.mode != 2) {
    throw std::runtime_error(
        "compute_swap_loop: mode must be 1 (best improvement) or 2 (first "
        "improvement)");
  }

  auto canonical = materialize_canonical_structure_with_pools(ready);
  result.final_structure = canonical.structure;

  // Optional starting-state override: if `options.starting_sites` is
  // non-empty, replace the per-site (kind, oxidation) values on the
  // canonical structure with the caller-provided ones. The vector must
  // line up with the canonical expansion site-for-site; we keep the
  // recipe pools untouched because they index by supercell position
  // rather than by current kind, so they remain valid for any starting
  // assignment that uses the same site ordering.
  if (!options.starting_sites.empty()) {
    if (options.starting_sites.size() != result.final_structure.sites.size()) {
      throw std::runtime_error(
          "compute_swap_loop: starting_sites size does not match the "
          "canonical supercell expansion of the input ReadyModel");
    }
    for (std::size_t i = 0; i < options.starting_sites.size(); ++i) {
      result.final_structure.sites[i].kind = options.starting_sites[i].kind;
      result.final_structure.sites[i].oxidation =
          options.starting_sites[i].oxidation;
    }
    result.log.push_back(
        "[SWAP] using caller-provided starting_sites override");
  }

  if (result.final_structure.sites.empty() ||
      canonical.recipe_pools.empty()) {
    // Nothing to swap: report the (possibly overridden) state as both
    // initial and final, with zero deltas.
    auto cache = create_swap_energy_cache(result.final_structure, options.rg_find_factor, options.chop_level);
    result.initial_total_energy =
        evaluate_total_with_cache(cache, result.final_structure);
    result.cache_stats = cache.stats;
    result.final_total_energy = result.initial_total_energy;
    result.de_min_swap = 0.0L;
    result.stopped_by_no_improvement = true;
    result.log.push_back(
        "[SWAP] canonical state has no swappable recipe pools; loop is a "
        "no-op");
    return result;
  }

  auto cache = create_swap_energy_cache(result.final_structure, options.rg_find_factor, options.chop_level);
  result.initial_total_energy = evaluate_total_with_cache(
      cache, result.final_structure);
  long double current_total = result.initial_total_energy;

  {
    std::ostringstream oss;
    oss << "[SWAP] mode=" << options.mode << " max_swap=" << options.max_swap
        << " initial_total_e=" << static_cast<double>(current_total);
    result.log.push_back(oss.str());
  }

  while (true) {
    if (options.cancel_requested && options.cancel_requested()) {
      throw std::runtime_error("swap loop cancelled");
    }
    if (options.max_swap > 0 && result.swap_count >= options.max_swap) {
      result.stopped_by_max_swap = true;
      result.log.push_back("[SWAP] reached max_swap; stopping");
      break;
    }

    long double round_total_denrg = 0.0L;
    bool round_accepted_any = false;

    for (std::size_t recipe_index = 0;
         recipe_index < canonical.recipe_pools.size(); ++recipe_index) {
      const auto& pool = canonical.recipe_pools[recipe_index];
      if (pool.size() < 2) {
        continue;
      }

      long double best_denrg = 0.0L;
      bool found_improving = false;
      std::size_t best_site_a = 0;
      std::size_t best_site_b = 0;
      long double best_energy_after = 0.0L;
      std::string best_kind_a_before;
      std::string best_kind_b_before;
      long double best_oxidation_a_before = 0.0L;
      long double best_oxidation_b_before = 0.0L;

      for (std::size_t i = 0; i < pool.size(); ++i) {
        if (options.cancel_requested && options.cancel_requested()) {
          throw std::runtime_error("swap loop cancelled");
        }
        for (std::size_t j = i + 1; j < pool.size(); ++j) {
          const std::size_t idx_a = pool[i];
          const std::size_t idx_b = pool[j];
          auto& site_a = result.final_structure.sites[idx_a];
          auto& site_b = result.final_structure.sites[idx_b];
          if (site_a.kind == site_b.kind) {
            continue;
          }
          // Evaluate the trial swap against the current pre-swap state.
          // The cache delta helpers mirror the legacy mEwald_* path: they
          // expect site_a/site_b to still carry their current oxidation states
          // and compute the energy change for exchanging them.  Do not mutate
          // the structure before calling these helpers.
          const std::string kind_a_before = site_a.kind;
          const long double oxidation_a_before = site_a.oxidation;
          const std::string kind_b_before = site_b.kind;
          const long double oxidation_b_before = site_b.oxidation;

          const long double real_denrg = evaluate_swap_real_delta_from_cache(
              cache, result.final_structure, idx_a, idx_b);
          const long double point_denrg = evaluate_swap_point_delta_from_cache(
              cache, result.final_structure, idx_a, idx_b);
          const long double recip_denrg = evaluate_swap_recip_delta_from_cache(
              cache, result.final_structure, idx_a, idx_b);
          const long double denrg = real_denrg + point_denrg + recip_denrg;
          const long double energy_after = current_total + denrg;

          if (denrg < 0.0L && denrg < best_denrg) {
            best_denrg = denrg;
            found_improving = true;
            best_site_a = idx_a;
            best_site_b = idx_b;
            best_energy_after = energy_after;
            best_kind_a_before = kind_a_before;
            best_kind_b_before = kind_b_before;
            best_oxidation_a_before = oxidation_a_before;
            best_oxidation_b_before = oxidation_b_before;

            if (options.mode == 2) {
              // First-improvement mode: stop scanning this recipe at the
              // first negative denrg (matching legacy `Swap == 2`).
              break;
            }
          }
        }
        if (found_improving && options.mode == 2) {
          break;
        }
      }

      if (found_improving) {
        auto& site_a = result.final_structure.sites[best_site_a];
        auto& site_b = result.final_structure.sites[best_site_b];
        commit_swap_state(cache, result.final_structure, best_site_a, best_site_b);
        site_a.kind = best_kind_b_before;
        site_a.oxidation = best_oxidation_b_before;
        site_b.kind = best_kind_a_before;
        site_b.oxidation = best_oxidation_a_before;
        current_total = best_energy_after;
        round_total_denrg += best_denrg;
        round_accepted_any = true;

        SwapAcceptance acceptance;
        acceptance.round = result.swap_count + 1;
        acceptance.recipe_index = static_cast<int>(recipe_index);
        acceptance.site_a_supercell_index = best_site_a;
        acceptance.site_b_supercell_index = best_site_b;
        acceptance.kind_a_before = best_kind_a_before;
        acceptance.kind_b_before = best_kind_b_before;
        acceptance.energy_after = best_energy_after;
        acceptance.denrg = best_denrg;
        result.committed_swaps.push_back(acceptance);

        std::ostringstream oss;
        oss << "[SWAP] round=" << acceptance.round
            << " recipe_index=" << recipe_index
            << " sites=(" << best_site_a << "," << best_site_b << ")"
            << " " << best_kind_a_before << "<->" << best_kind_b_before
            << " denrg=" << static_cast<double>(best_denrg)
            << " e_after=" << static_cast<double>(best_energy_after);
        result.log.push_back(oss.str());
      }
    }

    if (!round_accepted_any) {
      result.stopped_by_no_improvement = true;
      result.log.push_back("[SWAP] no improving swap in this round; stopping");
      break;
    }

    ++result.swap_count;
    if (round_total_denrg == 0.0L) {
      // Defensive: round_accepted_any can only flip true on a strictly
      // negative denrg, but if floating-point arithmetic ever rounds the
      // total to exactly 0 we still treat that as no-progress to match
      // the legacy `if (denrg_min_ttl == 0.0) break;` guard.
      result.stopped_by_no_improvement = true;
      result.log.push_back(
          "[SWAP] round_total_denrg == 0 after acceptance; stopping");
      break;
    }
  }

  // Verify final energy with full Ewald evaluation. The incremental delta
  // accumulation in the swap loop drifts from the true Ewald sum after many
  // swaps. Recompute the canonical Ewald energy from the final structure.
  {
    const ReadyModel verify_view =
        ready_view_from_structure(result.final_structure, options.rg_find_factor);
    const auto verified =
        ess::evaluate_ready_energy(verify_view, options.rg_find_factor, options.chop_level);
    const long double drift = current_total - verified.total_e;
    std::ostringstream oss;
    oss << "[SWAP] verify rg=" << options.rg_find_factor
        << " chop=" << static_cast<double>(options.chop_level)
        << " incremental=" << static_cast<double>(current_total)
        << " full_ewald=" << static_cast<double>(verified.total_e)
        << " drift=" << static_cast<double>(drift);
    result.log.push_back(oss.str());
    result.final_total_energy = verified.total_e;
  }
  result.de_min_swap = result.final_total_energy - result.initial_total_energy;
  result.cache_stats = cache.stats;
  {
    std::ostringstream oss;
    oss << "[SWAP] cache diff_enabled=" << (result.cache_stats.diff_cache_enabled ? "true" : "false")
        << " full_evaluations=" << result.cache_stats.full_evaluations
        << " diff_evaluations=" << result.cache_stats.diff_evaluations
        << " real_incremental_updates=" << result.cache_stats.real_incremental_updates
        << " point_incremental_updates=" << result.cache_stats.point_incremental_updates
        << " recip_incremental_updates=" << result.cache_stats.recip_incremental_updates
        << " real_cache_evals=" << result.cache_stats.real_cache_evaluations
        << " point_cache_evals=" << result.cache_stats.point_cache_evaluations
        << " recip_cache_evals=" << result.cache_stats.recip_cache_evaluations;
    result.log.push_back(oss.str());
  }
  return result;
}

}  // namespace ess::solve_steps
