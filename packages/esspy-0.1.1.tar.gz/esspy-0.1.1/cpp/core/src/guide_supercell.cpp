#include "ess/guide_supercell.hpp"

#include <cmath>
#include <cstdlib>
#include <sstream>

namespace ess::guide_steps {

namespace {

long double norm3(const std::array<long double, 3>& v) {
  return std::sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

// Mirrors the original Guider's get_shortest(): returns the index of the
// axis whose current expanded length (SE_i * |vec_i|) is the smallest.
int shortest_axis(int sa, long double a,
                  int sb, long double b,
                  int sc, long double c) {
  long double lc[3] = {
      static_cast<long double>(sa) * a,
      static_cast<long double>(sb) * b,
      static_cast<long double>(sc) * c,
  };
  int target = 0;
  long double mn = lc[0];
  if (lc[1] < mn) {
    mn = lc[1];
    target = 1;
  }
  if (lc[2] < mn) {
    target = 2;
  }
  return target;
}

std::string format_log_line(int sa, int sb, int sc, long long expanded) {
  std::ostringstream oss;
  oss << "SupercellExpansion = [" << sa << "," << sb << "," << sc
      << "]: ExpandedNAtomConfig= " << expanded;
  return oss.str();
}

}  // namespace

SupercellExpansionResult compute_supercell_expansion(
    const Lattice& lattice,
    int n_atom_config,
    int n_target_sites) {
  SupercellExpansionResult result;

  if (n_atom_config > n_target_sites) {
    result.expansion = {1, 1, 1};
    result.expanded_n_atom_config = n_atom_config;
    result.log.push_back(
        "NAtomConfig > NTargetSites: SupercellExpansion = [1, 1, 1]");
    return result;
  }

  const long double a = norm3(lattice.a);
  const long double b = norm3(lattice.b);
  const long double c = norm3(lattice.c);

  int SE[3] = {1, 1, 1};
  int SE_buf[3] = {1, 1, 1};

  result.log.push_back(
      format_log_line(SE[0], SE[1], SE[2], static_cast<long long>(n_atom_config)));

  while (true) {
    SE_buf[0] = SE[0];
    SE_buf[1] = SE[1];
    SE_buf[2] = SE[2];
    const int s = shortest_axis(SE[0], a, SE[1], b, SE[2], c);
    SE[s] += 1;
    const long long expanded =
        static_cast<long long>(SE[0]) * SE[1] * SE[2] * n_atom_config;
    result.log.push_back(format_log_line(SE[0], SE[1], SE[2], expanded));
    if (expanded > n_target_sites) {
      break;
    }
  }

  const long long expanded_buf =
      static_cast<long long>(SE_buf[0]) * SE_buf[1] * SE_buf[2] * n_atom_config;
  const long long expanded_now =
      static_cast<long long>(SE[0]) * SE[1] * SE[2] * n_atom_config;
  const long long DTarget0 = std::llabs(expanded_buf - n_target_sites);
  const long long DTarget1 = std::llabs(expanded_now - n_target_sites);

  if (DTarget0 <= DTarget1) {
    result.expansion = {SE_buf[0], SE_buf[1], SE_buf[2]};
    result.expanded_n_atom_config = static_cast<int>(expanded_buf);
    if (result.log.size() >= 2) {
      result.log[result.log.size() - 2] += " *";
    }
  } else {
    result.expansion = {SE[0], SE[1], SE[2]};
    result.expanded_n_atom_config = static_cast<int>(expanded_now);
    if (!result.log.empty()) {
      result.log.back() += " *";
    }
  }

  std::ostringstream final_oss;
  final_oss << "ExpandedNAtomConfig ~ NTargetSites: SupercellExpansion = ["
            << result.expansion[0] << "," << result.expansion[1] << ","
            << result.expansion[2] << "]";
  result.log.push_back(final_oss.str());

  return result;
}

}  // namespace ess::guide_steps
