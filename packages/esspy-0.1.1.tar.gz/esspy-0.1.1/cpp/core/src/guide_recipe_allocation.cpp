#include "ess/guide_recipe_allocation.hpp"

#include <algorithm>
#include <stdexcept>
#include <string>

namespace ess::guide_steps {

namespace {

long double find_charge(const ChargeMap& charges, const std::string& kind) {
  for (const auto& entry : charges.values) {
    if (entry.kind == kind) {
      return entry.oxidation;
    }
  }
  return 0.0L;
}

int find_target_count(const std::vector<CompositionEntry>& target_counts,
                      const std::string& kind) {
  for (const auto& entry : target_counts) {
    if (entry.kind == kind) {
      return entry.count;
    }
  }
  return 0;
}

const RecipeSpec* find_recipe_for(const std::vector<RecipeSpec>& recipes,
                                  const std::string& kind) {
  for (const auto& recipe : recipes) {
    if (recipe.from == kind) {
      return &recipe;
    }
  }
  return nullptr;
}

bool appears_as_recipe_target(const std::vector<RecipeSpec>& recipes,
                              const std::string& kind) {
  for (const auto& recipe : recipes) {
    for (const auto& to : recipe.to) {
      if (to == kind) {
        return true;
      }
    }
  }
  return false;
}

}  // namespace

RecipeAllocationResult compute_recipe_allocation(
    const std::vector<PrimitiveCellIon>& primitive_cellions,
    const std::vector<CompositionEntry>& target_counts,
    int supercell_exp,
    bool strict_no_added_sites,
    const std::vector<RecipeSpec>& recipes,
    const ChargeMap& charges) {
  RecipeAllocationResult result;

  // Step 1: seed cellions with the POSCAR primitive ions.
  for (const auto& pc : primitive_cellions) {
    AllocatedCellIon cellion;
    cellion.kind = pc.kind;
    cellion.n_primitive = pc.n;
    cellion.oxidation = pc.oxidation;
    result.cellions.push_back(cellion);
  }

  // Step 2: append any Target species that was missing from the POSCAR.
  // The original Guider does this before the recipe loop because such
  // species can appear only in another recipe's `to` list and must still
  // be tracked in cellions0 for later steps.
  for (const auto& tc : target_counts) {
    bool already_present = false;
    for (const auto& cellion : result.cellions) {
      if (cellion.kind == tc.kind) {
        already_present = true;
        break;
      }
    }
    if (!already_present) {
      AllocatedCellIon cellion;
      cellion.kind = tc.kind;
      cellion.n_primitive = 0;
      cellion.oxidation = find_charge(charges, tc.kind);
      result.cellions.push_back(cellion);
    }
  }

  // Step 3 (strict only): pre-allocate self-capacity per cellion, mirroring
  // the original Guider's `recipeFreeCapacity` initialisation.
  std::vector<int> remaining_target(target_counts.size(), 0);
  for (std::size_t i = 0; i < target_counts.size(); ++i) {
    remaining_target[i] = target_counts[i].count;
  }
  std::vector<int> recipe_free_capacity(result.cellions.size(), 0);
  if (strict_no_added_sites) {
    for (std::size_t i = 0; i < result.cellions.size(); ++i) {
      const int capacity = supercell_exp * result.cellions[i].n_primitive;
      for (std::size_t l = 0; l < target_counts.size(); ++l) {
        if (target_counts[l].kind == result.cellions[i].kind) {
          const int self_assigned = std::min(capacity, remaining_target[l]);
          remaining_target[l] -= self_assigned;
          recipe_free_capacity[i] = capacity - self_assigned;
          break;
        }
      }
    }
  }

  // Step 4: walk every cellion, decide its recipe role, derive Need/DNeed,
  // and emit the matching FinalRecipe entry.
  for (std::size_t i = 0; i < result.cellions.size(); ++i) {
    AllocatedCellIon& cellion = result.cellions[i];
    const RecipeSpec* matching_recipe = find_recipe_for(recipes, cellion.kind);
    const bool found_recipe = matching_recipe != nullptr;
    cellion.has_recipe = found_recipe;

    if (!found_recipe) {
      const bool already_in_other_recipe =
          appears_as_recipe_target(recipes, cellion.kind);
      if (already_in_other_recipe) {
        cellion.skipped_in_other_recipe = true;
        continue;
      }

      // Legacy parity: fixed species without an explicit substitution recipe
      // (e.g., O in M/O spinel workflows) are not emitted as FinalRecipe
      // entries. They are validated via Need/DNeed only.
      cellion.need = find_target_count(target_counts, cellion.kind);
      cellion.delta_need =
          cellion.need - supercell_exp * cellion.n_primitive;
      if (strict_no_added_sites && cellion.delta_need != 0) {
        throw std::runtime_error(
            "StrictNoAddedSites requires an exact target count for non-"
            "recipe species " +
            cellion.kind +
            ". Delta=" + std::to_string(cellion.delta_need) + ".");
      }
      if (!strict_no_added_sites && cellion.delta_need > 0) {
        result.need_wyc = true;
        result.log.push_back(
            "[INFO] Additional sites are required for " + cellion.kind +
            ": DNeed=" + std::to_string(cellion.delta_need) +
            " (Need=" + std::to_string(cellion.need) +
            ", current=" +
            std::to_string(supercell_exp * cellion.n_primitive) + ")");
      }
      result.log.push_back(
          "For n(" + cellion.kind + ")= " + std::to_string(cellion.need) +
          ": Needs " + std::to_string(cellion.delta_need) + " (currently, " +
          std::to_string(supercell_exp * cellion.n_primitive) + ")");

      // Keep non-recipe species in final_recipes for accounting symmetry
      // with the cellion list (legacy Guider parity used by tests/fixtures).
      FinalRecipe passthrough_recipe;
      passthrough_recipe.from = cellion.kind;
      passthrough_recipe.oxidation = cellion.oxidation;
      passthrough_recipe.random_pickup = supercell_exp * cellion.n_primitive;
      passthrough_recipe.random_pickup_trial = 1;
      passthrough_recipe.vac =
          strict_no_added_sites ? 0 : -cellion.delta_need;
      result.final_recipes.push_back(std::move(passthrough_recipe));
      continue;
    }

    FinalRecipe recipe_entry;
    recipe_entry.from = cellion.kind;
    recipe_entry.oxidation = cellion.oxidation;
    recipe_entry.random_pickup = supercell_exp * cellion.n_primitive;
    recipe_entry.random_pickup_trial = 1;

    if (strict_no_added_sites) {
      if (!found_recipe) {
        cellion.need = find_target_count(target_counts, cellion.kind);
        cellion.delta_need =
            cellion.need - supercell_exp * cellion.n_primitive;
        if (cellion.delta_need != 0) {
          throw std::runtime_error(
              "StrictNoAddedSites requires an exact target count for non-"
              "recipe species " +
              cellion.kind +
              ". Delta=" + std::to_string(cellion.delta_need) + ".");
        }
      } else {
        int free_capacity = recipe_free_capacity[i];
        for (const auto& to : matching_recipe->to) {
          if (to == cellion.kind) {
            // The original Guider skips the self entry inside the strict
            // path entirely (it was already handled by the per-cellion
            // self-capacity allocation above).
            continue;
          }
          int assigned = 0;
          for (std::size_t l = 0; l < target_counts.size(); ++l) {
            if (target_counts[l].kind == to) {
              assigned = std::min(free_capacity, remaining_target[l]);
              remaining_target[l] -= assigned;
              free_capacity -= assigned;
              break;
            }
          }
          FinalRecipeModification modification;
          modification.to = to;
          modification.oxidation = find_charge(charges, to);
          modification.number = assigned;
          recipe_entry.modifications.push_back(modification);
        }
        cellion.need = supercell_exp * cellion.n_primitive;
        cellion.delta_need = 0;
        if (free_capacity != 0) {
          throw std::runtime_error(
              "StrictNoAddedSites could not fully distribute the available "
              "source sites for " +
              cellion.kind +
              ". Remaining capacity=" + std::to_string(free_capacity) + ".");
        }
      }
      recipe_entry.vac = 0;
    } else {
      if (!found_recipe) {
        cellion.need = find_target_count(target_counts, cellion.kind);
      } else {
        int m_need = 0;
        for (const auto& to : matching_recipe->to) {
          const int target_for_to = find_target_count(target_counts, to);
          m_need += target_for_to;
          if (to == cellion.kind) {
            // The original Guider keeps the self entry in `itos` for the
            // mNeed sum but drops it from the writer. We mirror that by
            // skipping the modification but still summing into Need.
            continue;
          }
          FinalRecipeModification modification;
          modification.to = to;
          modification.oxidation = find_charge(charges, to);
          modification.number = target_for_to;
          recipe_entry.modifications.push_back(modification);
        }
        cellion.need = m_need;
      }
      cellion.delta_need = cellion.need - supercell_exp * cellion.n_primitive;
      if (cellion.delta_need > 0) {
        result.need_wyc = true;
        result.log.push_back(
            "[INFO] Additional sites are required for " + cellion.kind +
            ": DNeed=" + std::to_string(cellion.delta_need) +
            " (Need=" + std::to_string(cellion.need) +
            ", current=" +
            std::to_string(supercell_exp * cellion.n_primitive) + ")");
      }
      recipe_entry.vac = -cellion.delta_need;
    }

    result.log.push_back(
        "For n(" + cellion.kind + ")= " + std::to_string(cellion.need) +
        ": Needs " + std::to_string(cellion.delta_need) + " (currently, " +
        std::to_string(supercell_exp * cellion.n_primitive) + ")");
    for (const auto& modification : recipe_entry.modifications) {
      result.log.push_back("... n(" + modification.to + ")= " +
                           std::to_string(modification.number));
    }

    result.final_recipes.push_back(recipe_entry);
  }

  // Step 5 (strict only): every Target count must have been fully consumed.
  if (strict_no_added_sites) {
    for (std::size_t l = 0; l < target_counts.size(); ++l) {
      if (remaining_target[l] != 0) {
        throw std::runtime_error(
            "StrictNoAddedSites could not satisfy the target count for " +
            target_counts[l].kind +
            ". Remaining=" + std::to_string(remaining_target[l]) + ".");
      }
    }
  }

  return result;
}

}  // namespace ess::guide_steps
