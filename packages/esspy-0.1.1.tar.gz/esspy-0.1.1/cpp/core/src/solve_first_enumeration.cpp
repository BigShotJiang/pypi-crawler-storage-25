#include "ess/solve_first_enumeration.hpp"

#include "ess/solve_candidate_decode.hpp"

namespace ess::solve_steps {

FirstEnumerationState analyze_first_enumeration(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space) {
  FirstEnumerationState state;
  state.recipe_index = search_space.work_slice.primary_recipe_index;
  if (state.recipe_index < 0 ||
      state.recipe_index >= static_cast<int>(ready.recipes.size()) ||
      state.recipe_index >=
          static_cast<int>(search_space.work_slice.recipe_ranges.size())) {
    return state;
  }

  const auto& recipe = ready.recipes[static_cast<std::size_t>(state.recipe_index)];
  const auto& range = search_space.work_slice.recipe_ranges[static_cast<std::size_t>(
      state.recipe_index)];
  state.candidate_index = range.start + 1;
  state.candidate_indices =
      decode_candidate_assignment_indices(recipe, state.candidate_index);
  state.candidate_labels =
      decode_candidate_assignment_labels(recipe, state.candidate_index);
  return state;
}

}  // namespace ess::solve_steps
