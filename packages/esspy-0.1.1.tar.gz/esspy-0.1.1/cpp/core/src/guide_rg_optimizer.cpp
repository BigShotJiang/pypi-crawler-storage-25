#include "ess/guide_rg_optimizer.hpp"

#include <utility>

namespace ess::guide_steps {

namespace {

}  // namespace

EwaldOptimizationResult optimize_rg_find_factor(
    const ReadyModel& ready,
    const GuideOptions& options) {
  EwaldOptimizationResult result;
  const std::size_t nsite =
      ready.atoms.size() * static_cast<std::size_t>(ready.supercell_expansion[0]) *
      static_cast<std::size_t>(ready.supercell_expansion[1]) *
      static_cast<std::size_t>(ready.supercell_expansion[2]);

  if (options.skip_ewald_evaluation) {
    result.rg_find_factor = (options.fixed_rg_find_factor > 0 ? options.fixed_rg_find_factor : 1);
    result.total_e = 0.0L;
    result.log.push_back("RGFindFactor= " + std::to_string(result.rg_find_factor) + ": total_e= skipped *write_only");
    return result;
  }
  if (options.fixed_rg_find_factor > 0) {
    static_cast<ess::EwaldEvaluationResult&>(result) =
        ess::evaluate_ready_energy(ready, options.fixed_rg_find_factor, options.chop_level);
    result.log.push_back(
        ess::format_ewald_log_line(options.fixed_rg_find_factor, result.total_e, nsite, " *fixed"));
    return result;
  }
  if (options.skip_rg_optimization) {
    static_cast<ess::EwaldEvaluationResult&>(result) =
        ess::evaluate_ready_energy(ready, 1, options.chop_level);
    result.log.push_back(ess::format_ewald_log_line(1, result.total_e, nsite, " *skipped"));
    return result;
  }

  int rg = 1;
  static_cast<ess::EwaldEvaluationResult&>(result) =
      ess::evaluate_ready_energy(ready, rg, options.chop_level);
  result.log.push_back(ess::format_ewald_log_line(rg, result.total_e, nsite));
  long double total_e_buf = result.total_e;
  while (true) {
    ++rg;
    auto current = ess::evaluate_ready_energy(ready, rg, options.chop_level);
    result.log.push_back(ess::format_ewald_log_line(rg, current.total_e, nsite));
    if (current.total_e == total_e_buf) {
      result.log[result.log.size() - 2] += " *";
      result.rg_find_factor = rg - 1;
      EwaldOptimizationResult final_eval;
      static_cast<ess::EwaldEvaluationResult&>(final_eval) =
          ess::evaluate_ready_energy(ready, result.rg_find_factor, options.chop_level);
      final_eval.log = result.log;
      return final_eval;
    }
    total_e_buf = current.total_e;
  }
}

}  // namespace ess::guide_steps
