#include "ess/core.hpp"

#include <chrono>
#include <algorithm>
#include <array>
#include <cstddef>
#include <memory>
#include <utility>
#include <vector>

#include "ess/ewald_shared.hpp"
#include "ess/guide_add_ions.hpp"
#include "ess/guide_rg_optimizer.hpp"
#include "ess/guide_recipe_allocation.hpp"
#include "ess/guide_supercell.hpp"
#include "ess/solve_first_enumeration.hpp"
#include "ess/solve_candidate_decode.hpp"
#include "ess/solve_recipe_state.hpp"
#include "ess/solve_search_space.hpp"
#include "ess/solve_slice_window.hpp"
#include "ess/solve_swap_loop.hpp"
#include "ess/solve_window_evaluation.hpp"
#include "ess/solve_window_materialize.hpp"

#include <limits>
#include "ess/solve_work_slice.hpp"

namespace ess {

namespace {

void check_cancel_requested(const SolveOptions& options) {
  if (options.cancel_requested && options.cancel_requested()) {
    throw std::runtime_error("solve cancelled");
  }
}

void emit_progress(const SolveOptions& options,
                   const ParallelRuntimeOptions& runtime,
                   const LocalEnumerationLoopState& loop,
                   const WindowEvaluationSummary& window,
                   const std::string& stage,
                   const std::chrono::steady_clock::time_point& started_at,
                   const StructureSnapshot* best_snapshot = nullptr,
                   unsigned long long available_count = 0,
                   int monitoring_index = -1,
                   unsigned long long adaptive_stride = 0,
                   unsigned long long active_stride = 1,
                   int secondary_recipe_index = -1,
                   unsigned long long secondary_index = 0,
                   unsigned long long secondary_jobsize = 0) {
  if (!options.progress_callback) {
    return;
  }
  SolveProgressEvent event;
  event.stage = stage;
  event.rank = runtime.rank;
  event.world_size = runtime.world_size;
  event.processed_chunks = loop.processed_chunks;
  event.processed_candidates = loop.processed_candidates;
  event.next_offset = loop.next_offset;
  event.available_count = available_count;
  event.has_more = loop.has_more;
  event.local_e_min = window.local_e_min;
  event.local_e_max = window.local_e_max;
  event.monitoring_index = monitoring_index;
  event.adaptive_stride = adaptive_stride;
  event.active_stride = std::max<unsigned long long>(1, active_stride);
  event.secondary_recipe_index = secondary_recipe_index;
  event.secondary_index = secondary_index;
  event.secondary_jobsize = secondary_jobsize;
  event.elapsed_sec =
      std::chrono::duration<long double>(
          std::chrono::steady_clock::now() - started_at)
          .count();
  if (options.progress_include_best_structure && best_snapshot != nullptr &&
      !best_snapshot->structure.sites.empty()) {
    event.best_structure = best_snapshot->structure;
    event.best_structure_present = true;
  }
  options.progress_callback(event);
}

long double find_charge(const ChargeMap& charges, const std::string& kind) {
  for (const auto& entry : charges.values) {
    if (entry.kind == kind) {
      return entry.oxidation;
    }
  }
  return 0.0L;
}

// Reconstructs the per-species primitive count list in POSCAR order from the
// per-atom list. POSCAR groups atoms in species blocks, so we walk the atoms
// once and split the run-length encoding back into its (kind, count) pairs.
std::vector<ess::guide_steps::PrimitiveCellIon> primitive_cellions_from_sites(
    const std::vector<Site>& sites,
    const ChargeMap& charges) {
  std::vector<ess::guide_steps::PrimitiveCellIon> cellions;
  for (const auto& site : sites) {
    if (!cellions.empty() && cellions.back().kind == site.kind) {
      cellions.back().n += 1;
      continue;
    }
    ess::guide_steps::PrimitiveCellIon entry;
    entry.kind = site.kind;
    entry.n = 1;
    entry.oxidation = find_charge(charges, site.kind);
    cellions.push_back(entry);
  }
  return cellions;
}

std::vector<std::vector<Site>> site_buckets_from_cellions(
    const std::vector<ess::guide_steps::AllocatedCellIon>& cellions,
    const std::vector<Site>& sites) {
  std::vector<std::vector<Site>> buckets(cellions.size());
  std::size_t site_index = 0;
  for (std::size_t i = 0; i < cellions.size(); ++i) {
    for (int count = 0; count < cellions[i].n_primitive; ++count) {
      if (site_index >= sites.size()) {
        break;
      }
      buckets[i].push_back(sites[site_index]);
      ++site_index;
    }
  }
  return buckets;
}

std::vector<std::array<long double, 3>> flatten_fractional_sites(
    const std::vector<std::vector<Site>>& buckets) {
  std::vector<std::array<long double, 3>> result;
  for (const auto& bucket : buckets) {
    for (const auto& site : bucket) {
      result.push_back({site.x, site.y, site.z});
    }
  }
  return result;
}

ess::PrimarySliceWindow analyze_primary_stride_window(
    const ess::ReadyModel& ready,
    const ess::SearchSpaceSummary& search_space,
    unsigned long long segment_offset,
    int max_candidates,
    unsigned long long stride,
    bool decode_uses_xps0,
    std::vector<int>* xpr0_state,
    std::vector<int>* xpr_buf_state) {
  ess::PrimarySliceWindow window;
  window.recipe_index = search_space.work_slice.primary_recipe_index;
  if (window.recipe_index < 0 ||
      window.recipe_index >= static_cast<int>(ready.recipes.size()) ||
      window.recipe_index >=
          static_cast<int>(search_space.work_slice.recipe_ranges.size())) {
    return window;
  }

  const auto& recipe = ready.recipes[static_cast<std::size_t>(window.recipe_index)];
  const auto& range = search_space.work_slice.recipe_ranges[static_cast<std::size_t>(
      window.recipe_index)];
  const unsigned long long full_start_index = range.start + 1;
  window.end_index = range.end + 1;

  const unsigned long long available =
      (range.end >= range.start ? range.end - range.start + 1 : 0);
  const unsigned long long clamped_offset = std::min(segment_offset, available);
  window.available_count = available;
  window.requested_offset = clamped_offset;
  window.start_index = full_start_index + clamped_offset;
  const unsigned long long step = std::max<unsigned long long>(1, stride);
  const int requested_count = std::max(0, max_candidates);

  std::vector<int> local_xpr0;
  std::vector<int> local_xpr_buf;
  std::vector<int>& xpr0 =
      (xpr0_state != nullptr ? *xpr0_state : local_xpr0);
  std::vector<int>& xpr_buf =
      (xpr_buf_state != nullptr ? *xpr_buf_state : local_xpr_buf);
  if (xpr0.size() != static_cast<std::size_t>(recipe.random_pickup)) {
    xpr0 = ess::solve_steps::decode_candidate_assignment_indices(recipe, 1);
  }
  if (xpr_buf.size() != static_cast<std::size_t>(recipe.random_pickup)) {
    xpr_buf = xpr0;
  }
  bool work_on_xps0 = decode_uses_xps0;
  const auto common_cache = ess::solve_steps::build_legacy_common_decode_cache(
      recipe, full_start_index, window.end_index);
  unsigned long long current_offset = clamped_offset;
  for (int count = 0; count < requested_count && current_offset < available; ++count) {
    ess::CandidateWindowEntry entry;
    if (current_offset > std::numeric_limits<unsigned long long>::max() - full_start_index) {
      break;
    }
    entry.candidate_index = full_start_index + current_offset;
    auto& target_indices = work_on_xps0 ? xpr0 : xpr_buf;
    if (work_on_xps0 && common_cache.enabled) {
      ess::solve_steps::decode_candidate_assignment_indices_legacy_with_common_into(
          recipe, entry.candidate_index, common_cache, target_indices);
    } else {
      ess::solve_steps::decode_candidate_assignment_indices_legacy_into(
          recipe, entry.candidate_index, target_indices);
    }
    entry.candidate_indices = target_indices;
    entry.candidate_labels =
        ess::solve_steps::decode_candidate_assignment_labels_from_indices(
            recipe, entry.candidate_indices);
    window.candidates.push_back(std::move(entry));
    work_on_xps0 = !work_on_xps0;
    if (step >= available - current_offset) {
      current_offset = available;
    } else {
      current_offset += step;
    }
  }

  window.decoded_count = static_cast<int>(window.candidates.size());
  window.next_offset = current_offset;
  window.has_more = window.next_offset < available;
  window.next_decode_uses_xps0 = work_on_xps0;
  return window;
}

}  // namespace

GuideResult guide(const GuideInput& input) {
  GuideResult result;
  result.ready.lattice = input.structure.lattice;
  result.ready.output_prefix = input.structure.title;
  result.ready.chop_level = input.options.chop_level;

  const int n_atom_config = static_cast<int>(input.structure.sites.size());
  ess::guide_steps::SupercellExpansionResult se_result;
  if (input.has_supercell_expansion) {
    se_result.expansion = input.supercell_expansion;
    se_result.expanded_n_atom_config =
        n_atom_config * se_result.expansion[0] * se_result.expansion[1] *
        se_result.expansion[2];
    if (se_result.expanded_n_atom_config != input.composition.n_target_sites) {
      throw std::runtime_error(
          "explicit supercell expansion does not match n_target_sites");
    }
    se_result.log.push_back(
        "Explicit SupercellExpansion = [" +
        std::to_string(se_result.expansion[0]) + "," +
        std::to_string(se_result.expansion[1]) + "," +
        std::to_string(se_result.expansion[2]) + "]: ExpandedNAtomConfig= " +
        std::to_string(se_result.expanded_n_atom_config));
  } else {
    se_result = ess::guide_steps::compute_supercell_expansion(
        input.structure.lattice, n_atom_config,
        input.composition.n_target_sites);
  }
  result.ready.supercell_expansion = se_result.expansion;
  result.ready.rg_find_factor = 1;

  const int supercell_exp = se_result.expansion[0] * se_result.expansion[1] *
                            se_result.expansion[2];
  const auto primitive_cellions =
      primitive_cellions_from_sites(input.structure.sites, input.charges);
  const auto allocation = ess::guide_steps::compute_recipe_allocation(
      primitive_cellions, input.composition.entries, supercell_exp,
      input.options.strict_no_added_sites, input.recipes, input.charges);

  auto cellions = allocation.cellions;
  auto site_buckets = site_buckets_from_cellions(cellions, input.structure.sites);

  if (allocation.need_wyc && !input.symmetry.wyc_operations.empty()) {
    for (std::size_t i = 0; i < cellions.size(); ++i) {
      if (cellions[i].delta_need <= 0) {
        continue;
      }
      ess::guide_steps::AddIonsOptions options;
      options.shell_width = input.options.shell_width;
      options.wyc_identity_length = input.options.wyc_identity_length;
      options.abc_weights = input.options.abc_weights;
      options.n_random_seeds = input.options.n_random_seeds;
      options.random_seed = static_cast<unsigned int>(i);

      const auto add_result = ess::guide_steps::compute_add_ions(
          input.structure.lattice,
          flatten_fractional_sites(site_buckets),
          input.symmetry.wyc_operations,
          cellions[i].delta_need,
          options);

      for (const auto& line : add_result.log) {
        result.diagnostics.messages.push_back(
            "[ADD_IONS " + cellions[i].kind + "] " + line);
      }
      for (const auto& seed : add_result.chosen_random_seeds) {
        result.diagnostics.messages.push_back(
            "[ADD_IONS " + cellions[i].kind + "] seed=(" +
            std::to_string(static_cast<double>(seed[0])) + "," +
            std::to_string(static_cast<double>(seed[1])) + "," +
            std::to_string(static_cast<double>(seed[2])) + ")");
      }

      for (const auto& added : add_result.added_sites) {
        Site site;
        site.kind = cellions[i].kind;
        site.oxidation = cellions[i].oxidation;
        site.x = added.fractional[0];
        site.y = added.fractional[1];
        site.z = added.fractional[2];
        site_buckets[i].push_back(site);
      }
      cellions[i].n_primitive += static_cast<int>(add_result.added_sites.size());
    }
  } else if (allocation.need_wyc) {
    result.diagnostics.messages.push_back(
        "[INFO] Recipe allocation flagged need_wyc; add_ions/WYC step is not "
        "yet extracted into the new core.");
  }

  for (std::size_t i = 0; i < cellions.size(); ++i) {
    for (const auto& site : site_buckets[i]) {
      result.ready.atoms.push_back(
          ReadyAtom{cellions[i].kind, cellions[i].oxidation, site.x, site.y, site.z});
    }
    result.ready.poscar_species_counts.push_back(
        CompositionEntry{cellions[i].kind,
                         static_cast<int>(site_buckets[i].size())});
  }

  std::vector<RecipeAssignment> resolved_assignments;
  for (std::size_t i = 0; i < allocation.final_recipes.size(); ++i) {
    const auto& final_recipe = allocation.final_recipes[i];
    ReadyRecipe ready_recipe;
    ready_recipe.from = final_recipe.from;
    ready_recipe.oxidation = final_recipe.oxidation;
    int updated_count = 0;
    for (const auto& cellion : cellions) {
      if (cellion.kind == final_recipe.from) {
        updated_count = cellion.n_primitive;
        break;
      }
    }
    ready_recipe.random_pickup = supercell_exp * updated_count;
    ready_recipe.random_pickup_trial = final_recipe.random_pickup_trial;
    for (const auto& modification : final_recipe.modifications) {
      ready_recipe.modifications.push_back(ReadyRecipeModification{
          modification.to, modification.oxidation, modification.number});
    }
    if (final_recipe.vac != 0) {
      ready_recipe.modifications.push_back(
          ReadyRecipeModification{"vac", 0.0L, final_recipe.vac});
    }
    result.ready.recipes.push_back(ready_recipe);

    RecipeAssignment assignment;
    assignment.from = final_recipe.from;
    for (const auto& modification : final_recipe.modifications) {
      assignment.assigned_counts.push_back(
          CompositionEntry{modification.to, modification.number});
    }
    resolved_assignments.push_back(assignment);
  }

  const auto rg_result =
      ess::guide_steps::optimize_rg_find_factor(result.ready, input.options);
  result.ready.rg_find_factor = rg_result.rg_find_factor;

  result.diagnostics.n_atom_config = n_atom_config;
  if (allocation.need_wyc && !input.symmetry.wyc_operations.empty()) {
    result.diagnostics.n_atom_config = static_cast<int>(result.ready.atoms.size());
  }
  result.diagnostics.supercell_expansion = result.ready.supercell_expansion;
  result.diagnostics.rg_find_factor = rg_result.rg_find_factor;
  result.diagnostics.resolved_assignments = std::move(resolved_assignments);
  for (const auto& message : se_result.log) {
    result.diagnostics.messages.push_back(message);
  }
  for (const auto& message : allocation.log) {
    result.diagnostics.messages.push_back(message);
  }
  for (const auto& message : rg_result.log) {
    result.diagnostics.messages.push_back(message);
  }
  result.diagnostics.messages.push_back("guide() core stub reached");
  return result;
}

SolveResult solve(const SolveInput& input) {
  using clock = std::chrono::steady_clock;
  const auto started_at = clock::now();

  SolveResult result;
  const int rg_find_factor = (input.ready.rg_find_factor > 0 ? input.ready.rg_find_factor : 1);
  const long double chop_level = input.ready.chop_level > 0.0L ? input.ready.chop_level : 8.0L;
  const auto energy = ess::evaluate_ready_energy(input.ready, rg_find_factor, chop_level);
  const auto finished_at = clock::now();

  result.summary.global_count_total = 1;
  result.summary.global_e_min = energy.total_e;
  result.summary.global_e_max = energy.total_e;
  result.summary.total_cpu_time =
      std::chrono::duration<long double>(finished_at - started_at).count();
  result.search_space = ess::solve_steps::analyze_search_space(input.ready);
  const bool distributed_dynamic_chunking =
      input.options.mpi_dynamic_chunking &&
      static_cast<bool>(input.options.synchronize_dynamic_chunk) &&
      input.runtime.world_size > 1;
  auto runtime_for_slice = input.runtime;
  if (distributed_dynamic_chunking) {
    // All ranks see the same global slice; per-rank ownership is assigned
    // in-loop by synchronize_dynamic_chunk callback.
    runtime_for_slice.rank = 0;
    runtime_for_slice.world_size = 1;
  }
  result.search_space.work_slice =
      ess::solve_steps::analyze_work_slice(result.search_space, runtime_for_slice);
  result.search_space.first_enumeration =
      ess::solve_steps::analyze_first_enumeration(input.ready, result.search_space);
  result.local_enumeration_loop.initial_offset = input.options.local_enumeration_offset;
  result.local_enumeration_loop.chunk_limit = input.options.local_enumeration_limit;
  result.local_enumeration_loop.max_chunks = std::max(1, input.options.local_enumeration_max_chunks);
  result.local_enumeration_loop.exhaust_all = input.options.enumeration_exhaust_all;
  if (input.options.mpi_dynamic_chunking) {
    result.messages.push_back(
        "[SOLVE] mpi_dynamic_chunking=true chunk_min=" +
        std::to_string(input.options.mpi_chunk_min) +
        " chunk_max=" + std::to_string(input.options.mpi_chunk_max) +
        " heartbeat=" + std::to_string(input.options.mpi_scheduler_heartbeat) +
        " (scheduler hook enabled)");
  }
  const bool dynamic_chunking_enabled =
      input.options.mpi_dynamic_chunking && input.runtime.world_size > 1;
  const unsigned long long dynamic_chunk_min_ull =
      std::max<unsigned long long>(1ULL, input.options.mpi_chunk_min);
  const unsigned long long dynamic_chunk_max_ull =
      std::max<unsigned long long>(dynamic_chunk_min_ull, input.options.mpi_chunk_max);
  const int dynamic_heartbeat = std::max(1, input.options.mpi_scheduler_heartbeat);
  int dynamic_chunk_limit = std::max(1, input.options.local_enumeration_limit);
  if (dynamic_chunking_enabled) {
    dynamic_chunk_limit = static_cast<int>(std::min<unsigned long long>(
        dynamic_chunk_max_ull,
        std::max<unsigned long long>(
            dynamic_chunk_min_ull,
            static_cast<unsigned long long>(dynamic_chunk_limit))));
  }
  auto maybe_tune_chunk_limit = [&](unsigned long long decoded_count, bool has_more) {
    if (!dynamic_chunking_enabled || !has_more || decoded_count == 0) {
      return;
    }
    const int processed_chunks = result.local_enumeration_loop.processed_chunks;
    if (processed_chunks <= 0 || (processed_chunks % dynamic_heartbeat) != 0) {
      return;
    }
    const unsigned long long processed_candidates =
        result.local_enumeration_loop.processed_candidates;
    const long double avg_candidates_per_chunk =
        static_cast<long double>(processed_candidates) /
        static_cast<long double>(processed_chunks);
    int next_limit = dynamic_chunk_limit;
    if (avg_candidates_per_chunk <
        static_cast<long double>(dynamic_chunk_limit) * 0.50L) {
      next_limit = std::max<int>(
          static_cast<int>(dynamic_chunk_min_ull), dynamic_chunk_limit / 2);
    } else if (avg_candidates_per_chunk >
               static_cast<long double>(dynamic_chunk_limit) * 0.95L) {
      next_limit = std::min<int>(
          static_cast<int>(dynamic_chunk_max_ull),
          std::max<int>(dynamic_chunk_limit + 1, dynamic_chunk_limit * 2));
    }
    if (next_limit != dynamic_chunk_limit) {
      result.messages.push_back(
          "[SOLVE] mpi_dynamic_chunk_update old=" +
          std::to_string(dynamic_chunk_limit) + " new=" +
          std::to_string(next_limit) + " heartbeat=" +
          std::to_string(dynamic_heartbeat) + " avg_candidates_per_chunk=" +
          std::to_string(static_cast<double>(avg_candidates_per_chunk)));
      dynamic_chunk_limit = next_limit;
      result.local_enumeration_loop.chunk_limit = dynamic_chunk_limit;
    }
  };

  result.window_evaluation.recipe_index = result.search_space.work_slice.primary_recipe_index;
  result.window_evaluation.local_e_min = std::numeric_limits<long double>::infinity();
  result.window_evaluation.local_e_max = -std::numeric_limits<long double>::infinity();

  unsigned long long effective_stride = input.options.local_enumeration_stride;
  if (effective_stride < 1) {
    effective_stride = 1;
  }

  std::unique_ptr<ess::solve_steps::SwapEnergyCache> enumeration_energy_cache;
  unsigned long long dynamic_available_count = 0ULL;
  if (result.search_space.work_slice.primary_recipe_index >= 0 &&
      result.search_space.work_slice.primary_recipe_index <
          static_cast<int>(result.search_space.work_slice.recipe_ranges.size())) {
    const auto& range =
        result.search_space.work_slice.recipe_ranges[static_cast<std::size_t>(
            result.search_space.work_slice.primary_recipe_index)];
    if (range.end >= range.start) {
      dynamic_available_count = range.end - range.start + 1ULL;
    }
  }
  if (result.search_space.work_slice.primary_recipe_index >= 0) {
    // Legacy ESS seeds its incremental mEwald baseline from the first
    // enumerated candidate (all recipe indices = 1), not from the canonical
    // pre-substitution structure. Using canonical here introduces a constant
    // offset versus legacy in large sparse-stride runs.
    auto seed_structure =
        ess::solve_steps::materialize_canonical_structure(input.ready);
    if (result.search_space.entries.size() == input.ready.recipes.size()) {
      std::vector<ess::CandidateWindowEntry> seed_candidates(
          input.ready.recipes.size());
      bool have_all = true;
      for (std::size_t i = 0; i < result.search_space.entries.size(); ++i) {
        const auto& entry = result.search_space.entries[i];
        if (entry.first_candidate_labels.empty()) {
          have_all = false;
          break;
        }
        ess::CandidateWindowEntry candidate;
        candidate.candidate_index = 1;
        candidate.candidate_indices = entry.first_candidate_indices;
        candidate.candidate_labels = entry.first_candidate_labels;
        seed_candidates[i] = std::move(candidate);
      }
      if (have_all) {
        const auto seed_ready =
            ess::solve_steps::build_candidate_ready(
                input.ready, result.search_space, seed_candidates);
        seed_structure = ess::solve_steps::structure_from_ready(seed_ready);
      }
    }
    enumeration_energy_cache =
        std::make_unique<ess::solve_steps::SwapEnergyCache>(
            ess::solve_steps::create_swap_energy_cache(
                seed_structure, rg_find_factor, chop_level));
  }
  auto consume_primary_window = [&](const ess::PrimarySliceWindow& chunk_window,
                                    bool nested_recipe_traversal,
                                    unsigned long long active_stride) {
    result.local_enumeration_loop.next_offset = chunk_window.next_offset;
    result.local_enumeration_loop.has_more = chunk_window.has_more;
    if (chunk_window.decoded_count == 0) {
      return static_cast<unsigned long long>(0);
    }

    auto chunk_search_space = result.search_space;
    chunk_search_space.primary_slice_window = chunk_window;
    emit_progress(input.options,
                  input.runtime,
                  result.local_enumeration_loop,
                  result.window_evaluation,
                  "solve.chunk.started",
                  started_at,
                  nullptr,
                  chunk_window.available_count,
                  -1,
                  0,
                  active_stride);
    const bool use_incremental_evaluator =
        nested_recipe_traversal || enumeration_energy_cache != nullptr;
    bool adaptive_budget_reached_inside_nested = false;
    auto nested_progress = [&](int secondary_recipe_index,
                               unsigned long long secondary_index,
                               unsigned long long secondary_jobsize,
                               unsigned long long evaluated_count) -> bool {
      LocalEnumerationLoopState nested_loop = result.local_enumeration_loop;
      nested_loop.processed_candidates += evaluated_count;
      emit_progress(input.options,
                    input.runtime,
                    nested_loop,
                    result.window_evaluation,
                    "solve.nested",
                    started_at,
                    nullptr,
                    chunk_window.available_count,
                    -1,
                    0,
                    active_stride,
                    secondary_recipe_index,
                    secondary_index,
                    secondary_jobsize);
      if (input.options.running_index_delta < 0) {
        const long double elapsed_total =
            std::chrono::duration<long double>(clock::now() - started_at).count();
        if (elapsed_total > static_cast<long double>(-input.options.running_index_delta)) {
          adaptive_budget_reached_inside_nested = true;
          return false;
        }
      }
      return true;
    };
    auto chunk_eval =
        use_incremental_evaluator
            ? ess::solve_steps::evaluate_nested_primary_slice_window(
                  input.ready, chunk_search_space, rg_find_factor, chop_level,
                  enumeration_energy_cache.get(), input.options.enumeration_save_memory,
                  nested_progress)
            : ess::solve_steps::evaluate_primary_slice_window(
                  input.ready, chunk_search_space, rg_find_factor, chop_level,
                  input.options.enumeration_save_memory);

    if (adaptive_budget_reached_inside_nested) {
      result.messages.push_back("[SOLVE] adaptive_time_budget_reached_in_nested=true");
    }

    result.local_enumeration_loop.processed_chunks += 1;
    result.local_enumeration_loop.processed_candidates += chunk_eval.local_count_total;

    if (result.window_evaluation.recipe_index < 0) {
      result.window_evaluation.recipe_index = chunk_eval.recipe_index;
    }
    result.window_evaluation.local_count_total += chunk_eval.local_count_total;

    result.local_reduction.local_energy_table.merge(chunk_eval.local_energy_table);

    if (!input.options.enumeration_save_memory) {
      for (auto& entry : chunk_eval.entries) {
        result.window_evaluation.entries.push_back(std::move(entry));
      }
    }

    if (chunk_eval.local_count_total > 0) {
      if (chunk_eval.local_e_min < result.window_evaluation.local_e_min) {
        result.window_evaluation.local_e_min = chunk_eval.local_e_min;
        result.window_evaluation.local_best_candidate_index =
            chunk_eval.local_best_candidate_index;
        if (input.options.enumeration_save_memory) {
          if (chunk_eval.local_best_snapshot_present) {
            result.best = chunk_eval.local_best_snapshot;
            result.best.label = input.ready.output_prefix + "::best";
          }
        }
      }
      if (chunk_eval.local_e_max > result.window_evaluation.local_e_max) {
        result.window_evaluation.local_e_max = chunk_eval.local_e_max;
        result.window_evaluation.local_worst_candidate_index =
            chunk_eval.local_worst_candidate_index;
        if (input.options.enumeration_save_memory) {
          if (chunk_eval.local_worst_snapshot_present) {
            result.worst = chunk_eval.local_worst_snapshot;
            result.worst.label = input.ready.output_prefix + "::worst";
          }
        }
      }
    }
    emit_progress(input.options,
                  input.runtime,
                  result.local_enumeration_loop,
                  result.window_evaluation,
                  "solve.chunk",
                  started_at,
                  &result.best,
                  chunk_window.available_count,
                  -1,
                  0,
                  active_stride);
    return chunk_eval.local_count_total;
  };

  unsigned long long offset = input.options.local_enumeration_offset;
  bool stride_decode_uses_xps0 = true;
  std::vector<int> stride_xpr0_state;
  std::vector<int> stride_xpr_buf_state;
  bool adaptive_disable_swap = false;
  const bool legacy_adaptive_stride = input.options.running_index_delta < 0;
  if (legacy_adaptive_stride) {
    const long double target_cpu_time =
        static_cast<long double>(-input.options.running_index_delta);
    const int monitor = std::max(1, input.options.running_index_monitor);
    unsigned long long adaptive_stride = 1;
    int monitoring = 0;
    const auto adaptive_started_at = clock::now();
    auto last_adaptive_probe_at = adaptive_started_at;

    auto update_adaptive_stride = [&](int monitoring_index,
                                      unsigned long long current_offset,
                                      unsigned long long available) {
      (void)current_offset;
      const auto now = clock::now();
      const long double elapsed_total =
          std::chrono::duration<long double>(now - started_at).count();
      long double elapsed_probe =
          std::chrono::duration<long double>(now - last_adaptive_probe_at).count();
      if (elapsed_probe <= 0.0L) {
        elapsed_probe = 1.0e-12L;
      }
      // Legacy ESS updates at Monitoring==9 and Monitoring==19.  Both updates
      // estimate one candidate from the preceding 10 evaluations: candidates
      // 0..9 for the first update, then 10 strided candidates for the second.
      long double one_step_time = 0.1L * elapsed_probe;
      if (input.options.adaptive_stride_scale_secondary) {
        const int primary = result.search_space.work_slice.primary_recipe_index;
        for (std::size_t i = 0; i < result.search_space.entries.size(); ++i) {
          if (static_cast<int>(i) == primary) {
            continue;
          }
          const auto& entry = result.search_space.entries[i];
          if (entry.jobsize_ld > 0.0L) {
            one_step_time *= entry.jobsize_ld;
          } else if (entry.jobsize_u64 > 0) {
            one_step_time *= static_cast<long double>(entry.jobsize_u64);
          }
          if (entry.random_pickup_trial > 0) {
            one_step_time *= static_cast<long double>(entry.random_pickup_trial);
          }
        }
      }

      const long double left_time = target_cpu_time - elapsed_total;
      unsigned long long next_stride = 1;
      if (left_time > 0.0L && one_step_time > 0.0L && available > 0) {
        // Match legacy formula: numerator is the full per-rank primary slice,
        // not the remaining count after calibration.
        const long double estimated_stride =
            static_cast<long double>(available) / (left_time / one_step_time);
        if (estimated_stride > 1.0L) {
          const long double max_ull =
              static_cast<long double>(std::numeric_limits<unsigned long long>::max());
          next_stride = static_cast<unsigned long long>(
              std::min(estimated_stride, max_ull));
          if (next_stride == 0) {
            next_stride = 1;
          }
        }
      }
      adaptive_stride = std::max<unsigned long long>(1, next_stride);
      const unsigned long long local_adaptive_stride = adaptive_stride;
      if (input.options.synchronize_adaptive_stride) {
        adaptive_stride = input.options.synchronize_adaptive_stride(
            monitoring_index, adaptive_stride);
        if (adaptive_stride < 1) {
          adaptive_stride = 1;
        }
      }
      if (monitoring_index == 9 &&
          input.options.adaptive_stride_override_9 > 0) {
        adaptive_stride = input.options.adaptive_stride_override_9;
      }
      if (monitoring_index == 19 &&
          input.options.adaptive_stride_override_19 > 0) {
        adaptive_stride = input.options.adaptive_stride_override_19;
      }
      if (input.runtime.world_size > 1 && monitoring_index == 19 &&
          adaptive_stride == 1) {
        // Legacy ESS broadcasts Swap=0 from rank 0 when the second adaptive
        // stride update leaves RunningIndexDelta at 1.  Keep the same
        // production safeguard for MPI runs.
        adaptive_disable_swap = true;
      }
      result.messages.push_back(
          "[SOLVE] adaptive_running_index_update monitoring=" +
          std::to_string(monitoring_index) + " stride=" +
          std::to_string(adaptive_stride) + " elapsed_sec=" +
          std::to_string(static_cast<double>(elapsed_total)) + " target_sec=" +
          std::to_string(static_cast<double>(target_cpu_time)) +
          " cost_model=" +
          (input.options.adaptive_stride_scale_secondary
               ? "legacy_secondary_scaled"
               : "measured_window"));
      if (input.options.synchronize_adaptive_stride) {
        result.messages.push_back(
            "[SOLVE] adaptive_running_index_sync monitoring=" +
            std::to_string(monitoring_index) + " local_stride=" +
            std::to_string(local_adaptive_stride) + " synced_stride=" +
            std::to_string(adaptive_stride));
      }
      if ((monitoring_index == 9 &&
           input.options.adaptive_stride_override_9 > 0) ||
          (monitoring_index == 19 &&
           input.options.adaptive_stride_override_19 > 0)) {
        result.messages.push_back(
            "[SOLVE] adaptive_running_index_override monitoring=" +
            std::to_string(monitoring_index) + " local_stride=" +
            std::to_string(local_adaptive_stride) + " override_stride=" +
            std::to_string(adaptive_stride));
      }
      emit_progress(input.options,
                    input.runtime,
                    result.local_enumeration_loop,
                    result.window_evaluation,
                    "solve.adaptive_stride",
                    started_at,
                    nullptr,
                    available,
                    monitoring_index,
                    adaptive_stride,
                    adaptive_stride);
      last_adaptive_probe_at = now;
    };

    result.messages.push_back(
        "[SOLVE] legacy_adaptive_running_index=true target_sec=" +
        std::to_string(static_cast<double>(target_cpu_time)));
    int post_calibration_chunks = 0;
    for (int chunk = 0;; ++chunk) {
      check_cancel_requested(input.options);
      const bool calibrating = monitoring <= 19;
      const bool use_adaptive_stride = monitoring > 9;
      if (!input.options.enumeration_exhaust_all &&
          !calibrating &&
          post_calibration_chunks >= result.local_enumeration_loop.max_chunks) {
        break;
      }
      if (distributed_dynamic_chunking &&
          input.options.synchronize_dynamic_chunk) {
        auto decision = input.options.synchronize_dynamic_chunk(
            offset, dynamic_chunk_limit, true, dynamic_available_count);
        dynamic_chunk_limit = std::max(1, decision.chunk_limit);
        result.local_enumeration_loop.chunk_limit = dynamic_chunk_limit;
        if (!decision.has_more || decision.chunk_limit <= 0) {
          result.local_enumeration_loop.has_more = false;
          break;
        }
        offset = decision.offset;
      }
      auto chunk_window =
          !use_adaptive_stride
              ? ess::solve_steps::analyze_primary_slice_window(
                    input.ready, result.search_space, offset, 1)
              : analyze_primary_stride_window(
                    input.ready, result.search_space, offset,
                    calibrating ? 1 : dynamic_chunk_limit,
                    adaptive_stride,
                    stride_decode_uses_xps0,
                    &stride_xpr0_state,
                    &stride_xpr_buf_state);
      if (chunk == 0) {
        result.search_space.primary_slice_window = chunk_window;
      }
      if (chunk_window.decoded_count == 0) {
        result.local_enumeration_loop.next_offset = chunk_window.next_offset;
        result.local_enumeration_loop.has_more = chunk_window.has_more;
        break;
      }

      consume_primary_window(chunk_window, true, calibrating ? 1 : adaptive_stride);
      maybe_tune_chunk_limit(chunk_window.decoded_count, chunk_window.has_more);
      check_cancel_requested(input.options);

      // Enforce adaptive time budget during both calibration and post-calibration
      // phases. Previously, budget stop was applied only after calibration
      // (monitoring > 19), which could overshoot significantly when early chunks
      // are expensive.
      {
        const long double elapsed_total =
            std::chrono::duration<long double>(clock::now() - started_at).count();
        if (elapsed_total > target_cpu_time) {
          result.local_enumeration_loop.has_more = chunk_window.has_more;
          result.messages.push_back(
              "[SOLVE] adaptive_time_budget_reached elapsed_sec=" +
              std::to_string(static_cast<double>(elapsed_total)) + " target_sec=" +
              std::to_string(static_cast<double>(target_cpu_time)));
          break;
        }
      }

      const unsigned long long evaluated_offset = offset;
      unsigned long long next_offset = chunk_window.next_offset;
      stride_decode_uses_xps0 = chunk_window.next_decode_uses_xps0;
      if (calibrating) {
        if (monitoring == 9 || monitoring == 19) {
          update_adaptive_stride(monitoring, offset, chunk_window.available_count);
          // Legacy changes RunningIndexDelta inside the for-loop body and the
          // next loop increment jumps from the just-evaluated primary index by
          // the new stride.  Do not continue with the sequential next offset.
          next_offset = evaluated_offset + adaptive_stride;
        }
        monitoring += 1;
      } else {
        post_calibration_chunks += 1;
      }
      offset = next_offset;
      if (!chunk_window.has_more) {
        break;
      }
    }
  } else {
    for (int chunk = 0;; ++chunk) {
      check_cancel_requested(input.options);
      if (!input.options.enumeration_exhaust_all &&
          chunk >= result.local_enumeration_loop.max_chunks) {
        break;
      }
      if (distributed_dynamic_chunking &&
          input.options.synchronize_dynamic_chunk) {
        auto decision = input.options.synchronize_dynamic_chunk(
            offset, dynamic_chunk_limit, true, dynamic_available_count);
        dynamic_chunk_limit = std::max(1, decision.chunk_limit);
        result.local_enumeration_loop.chunk_limit = dynamic_chunk_limit;
        if (!decision.has_more || decision.chunk_limit <= 0) {
          result.local_enumeration_loop.has_more = false;
          break;
        }
        offset = decision.offset;
      }
      auto chunk_window =
          effective_stride > 1
              ? analyze_primary_stride_window(
                    input.ready, result.search_space, offset,
                    dynamic_chunk_limit,
                    effective_stride,
                    stride_decode_uses_xps0,
                    &stride_xpr0_state,
                    &stride_xpr_buf_state)
              : ess::solve_steps::analyze_primary_slice_window(
                    input.ready,
                    result.search_space,
                    offset,
                    dynamic_chunk_limit);
      if (chunk == 0) {
        result.search_space.primary_slice_window = chunk_window;
      }
      if (chunk_window.decoded_count == 0) {
        result.local_enumeration_loop.next_offset = chunk_window.next_offset;
        result.local_enumeration_loop.has_more = chunk_window.has_more;
        break;
      }

      consume_primary_window(chunk_window, false, effective_stride);
      maybe_tune_chunk_limit(chunk_window.decoded_count, chunk_window.has_more);
      check_cancel_requested(input.options);

      offset = chunk_window.next_offset;
      if (effective_stride > 1) {
        stride_decode_uses_xps0 = chunk_window.next_decode_uses_xps0;
      }
      if (!chunk_window.has_more) {
        break;
      }
    }
  }
  if (result.window_evaluation.local_count_total == 0) {
    result.window_evaluation.local_e_min = 0.0L;
    result.window_evaluation.local_e_max = 0.0L;
  }
  result.local_reduction.rank = input.runtime.rank;
  result.local_reduction.world_size = std::max(1, input.runtime.world_size);
  result.local_reduction.primary_recipe_index = result.search_space.work_slice.primary_recipe_index;
  result.local_reduction.initial_offset = result.local_enumeration_loop.initial_offset;
  result.local_reduction.next_offset = result.local_enumeration_loop.next_offset;
  result.local_reduction.has_more = result.local_enumeration_loop.has_more;
  result.local_reduction.exhaust_all = input.options.enumeration_exhaust_all;
  result.local_reduction.processed_chunks = result.local_enumeration_loop.processed_chunks;
  result.local_reduction.processed_candidates = result.local_enumeration_loop.processed_candidates;
  if (result.window_evaluation.local_count_total > 0) {
    result.local_reduction.has_samples = true;
    result.local_reduction.local_e_min = result.window_evaluation.local_e_min;
    result.local_reduction.local_e_max = result.window_evaluation.local_e_max;
    result.local_reduction.local_best_candidate_index = result.window_evaluation.local_best_candidate_index;
    result.local_reduction.local_worst_candidate_index = result.window_evaluation.local_worst_candidate_index;
  }
  
  // Final global summary from local reduction (for single-rank case)
  result.energy_table = result.local_reduction.local_energy_table;
  result.summary.global_count_total = result.energy_table.count;
  result.summary.global_e_min = result.energy_table.min_e;
  result.summary.global_e_max = result.energy_table.max_e;
  if (result.window_evaluation.local_count_total > 0) {
    // Keep summary min/max aligned with window-evaluation values to avoid
    // tiny roundoff drift between two equivalent reporting surfaces.
    result.summary.global_e_min = result.window_evaluation.local_e_min;
    result.summary.global_e_max = result.window_evaluation.local_e_max;
    if (result.best.structure.sites.size() > 0) {
      result.best.energy = result.summary.global_e_min;
    }
    if (result.worst.structure.sites.size() > 0) {
      result.worst.energy = result.summary.global_e_max;
    }
  }

  result.messages.push_back(
      "[SOLVE] single-configuration shared-Ewald path reached");
  result.messages.push_back(ess::format_ewald_log_line(
      energy.rg_find_factor, energy.total_e, energy.nsite, " *single_config"));
  if (result.search_space.primary_recipe_index >= 0) {
    result.messages.push_back(
        "[SOLVE] primary_recipe_index=" +
        std::to_string(result.search_space.primary_recipe_index));
  }
  if (!result.search_space.work_slice.recipe_ranges.empty()) {
    const auto& primary =
        result.search_space.work_slice.recipe_ranges[static_cast<std::size_t>(
            result.search_space.work_slice.primary_recipe_index)];
    result.messages.push_back(
        "[SOLVE] primary_slice=" + std::to_string(primary.start + 1) + ":" +
        std::to_string(primary.end + 1));
  }
  if (result.search_space.first_enumeration.recipe_index >= 0) {
    result.messages.push_back(
        "[SOLVE] first_enumeration_index=" +
        std::to_string(result.search_space.first_enumeration.candidate_index));
  }
  if (!result.search_space.primary_slice_window.candidates.empty() || result.local_enumeration_loop.processed_candidates > 0) {
    result.messages.push_back(
        "[SOLVE] primary_slice_window_size=" +
        std::to_string(result.search_space.primary_slice_window.candidates.size()));
    result.messages.push_back(
        "[SOLVE] primary_slice_available=" +
        std::to_string(result.search_space.primary_slice_window.available_count));
    result.messages.push_back(
        "[SOLVE] primary_slice_decoded=" +
        std::to_string(result.search_space.primary_slice_window.decoded_count));
    result.messages.push_back(
        "[SOLVE] primary_slice_offset=" +
        std::to_string(input.options.local_enumeration_offset));
    result.messages.push_back(
        "[SOLVE] primary_slice_next_offset=" +
        std::to_string(result.search_space.primary_slice_window.next_offset));
    result.messages.push_back(
        std::string("[SOLVE] primary_slice_has_more=") +
        (result.search_space.primary_slice_window.has_more ? "true" : "false"));
    result.messages.push_back(
        std::string("[SOLVE] local_loop_exhaust_all=") +
        (input.options.enumeration_exhaust_all ? "true" : "false"));
    result.messages.push_back(
        "[SOLVE] local_chunks_processed=" +
        std::to_string(result.local_enumeration_loop.processed_chunks));
    result.messages.push_back(
        "[SOLVE] local_candidates_processed=" +
        std::to_string(result.local_enumeration_loop.processed_candidates));
    result.messages.push_back(
        "[SOLVE] local_loop_next_offset=" +
        std::to_string(result.local_enumeration_loop.next_offset));
    result.messages.push_back(
        std::string("[SOLVE] local_loop_has_more=") +
        (result.local_enumeration_loop.has_more ? "true" : "false"));
    result.messages.push_back(
        "[SOLVE] local_reduce_rank=" + std::to_string(result.local_reduction.rank));
    result.messages.push_back(
        "[SOLVE] local_reduce_world_size=" + std::to_string(result.local_reduction.world_size));
  }
  if (result.energy_table.count > 0) {
    result.messages.push_back(
        "[SOLVE] enumeration_local_min=" + std::to_string(static_cast<double>(result.energy_table.min_e)));
    result.messages.push_back(
        "[SOLVE] enumeration_local_max=" + std::to_string(static_cast<double>(result.energy_table.max_e)));
    result.messages.push_back(
        "[SOLVE] enumeration_local_count=" + std::to_string(result.energy_table.count));

    if (!input.options.enumeration_save_memory) {
      for (const auto& entry : result.window_evaluation.entries) {
        if (entry.candidate_index == result.window_evaluation.local_best_candidate_index) {
          result.best = entry.snapshot;
          result.best.label = input.ready.output_prefix + "::best";
        }
        if (entry.candidate_index == result.window_evaluation.local_worst_candidate_index) {
          result.worst = entry.snapshot;
          result.worst.label = input.ready.output_prefix + "::worst";
        }
      }
    }
  }
  if (result.local_reduction.has_samples) {
    result.best.energy = result.summary.global_e_min;
    result.worst.energy = result.summary.global_e_max;
  }
  if (enumeration_energy_cache) {
    result.messages.push_back(
        "[SOLVE] enumeration_incremental_mEwald=true");
    result.messages.push_back(
        "[SOLVE] enumeration_mEwald_diff_evaluations=" +
        std::to_string(enumeration_energy_cache->stats.diff_evaluations));
    result.messages.push_back(
        "[SOLVE] enumeration_mEwald_real_updates=" +
        std::to_string(enumeration_energy_cache->stats.real_incremental_updates));
    result.messages.push_back(
        "[SOLVE] enumeration_mEwald_recip_updates=" +
        std::to_string(enumeration_energy_cache->stats.recip_incremental_updates));
  }
  if (result.best.label.empty()) {
    result.best.label = input.ready.output_prefix + "::best";
    result.best.energy = energy.total_e;
    result.best.structure = ess::solve_steps::materialize_canonical_structure(input.ready);
  }
  if (result.worst.label.empty()) {
    result.worst.label = input.ready.output_prefix + "::worst";
    result.worst.energy = energy.total_e;
    result.worst.structure = result.best.structure;
  }

  // Carry the per-rank best/worst structure snapshots into the local
  // reduction summary.
  if (result.local_reduction.has_samples) {
    if (!result.best.structure.sites.empty()) {
      result.local_reduction.local_best_structure = result.best.structure;
      result.local_reduction.local_best_structure_present = true;
    }
    if (!result.worst.structure.sites.empty()) {
      result.local_reduction.local_worst_structure = result.worst.structure;
      result.local_reduction.local_worst_structure_present = true;
    }
  }

  // Optional swap-loop integration.
  if (adaptive_disable_swap) {
    result.messages.push_back("[SOLVE] swap_disabled_by_adaptive_stride=true");
  }
  if (!adaptive_disable_swap && input.options.swap_loop_enabled &&
      input.options.max_swap > 0) {
    emit_progress(input.options,
                  input.runtime,
                  result.local_enumeration_loop,
                  result.window_evaluation,
                  "solve.swap.started",
                  started_at);
    ess::solve_steps::SwapLoopOptions sw_opts;
    sw_opts.mode = (input.options.swap_loop_mode == 2) ? 2 : 1;
    sw_opts.max_swap = input.options.max_swap;
    sw_opts.rg_find_factor =
        input.ready.rg_find_factor > 0 ? input.ready.rg_find_factor : 1;
    sw_opts.chop_level = chop_level;
    sw_opts.cancel_requested = input.options.cancel_requested;

    bool seeded_from_window = false;
    bool seeded_from_external = false;
    int seed_source_used = 0;
    if (input.options.swap_loop_seed_source == 3 &&
        !input.options.swap_loop_starting_sites.empty()) {
      sw_opts.starting_sites = input.options.swap_loop_starting_sites;
      seeded_from_external = true;
      seed_source_used = 3;
    } else if (result.local_reduction.has_samples) {
      if (input.options.swap_loop_seed_source == 1 &&
          !result.best.structure.sites.empty()) {
        sw_opts.starting_sites = result.best.structure.sites;
        seeded_from_window = true;
        seed_source_used = 1;
      } else if (input.options.swap_loop_seed_source == 2 &&
                 !result.worst.structure.sites.empty()) {
        sw_opts.starting_sites = result.worst.structure.sites;
        seeded_from_window = true;
        seed_source_used = 2;
      }
    }

    const auto sw =
        ess::solve_steps::compute_swap_loop(input.ready, sw_opts);

    result.local_reduction.local_de_min_swap = sw.de_min_swap;
    result.local_reduction.local_swap_count = sw.swap_count;

    const bool was_empty = !result.local_reduction.has_samples;
    if (was_empty || sw.final_total_energy < result.best.energy) {
      result.best.energy = sw.final_total_energy;
      result.best.label = input.ready.output_prefix + "::swap_best";
      result.best.structure = sw.final_structure;
      result.local_reduction.local_best_structure = sw.final_structure;
      result.local_reduction.local_best_structure_present = true;
    }
    if (was_empty || sw.final_total_energy < result.summary.global_e_min) {
      result.summary.global_e_min = sw.final_total_energy;
    }
    if (was_empty || sw.final_total_energy > result.summary.global_e_max) {
      result.summary.global_e_max = sw.final_total_energy;
    }
    if (was_empty) {
      result.summary.global_count_total = 1;
      result.local_reduction.has_samples = true;
      result.local_reduction.local_e_min = sw.final_total_energy;
      result.local_reduction.local_e_max = sw.final_total_energy;
      result.local_reduction.local_worst_structure = sw.final_structure;
      result.local_reduction.local_worst_structure_present = true;
      result.local_reduction.local_best_candidate_index = 0;
      result.local_reduction.local_worst_candidate_index = 0;
      result.local_reduction.local_energy_table.add(sw.final_total_energy);
      result.energy_table = result.local_reduction.local_energy_table;
    } else if (sw.final_total_energy < result.local_reduction.local_e_min) {
      result.local_reduction.local_e_min = sw.final_total_energy;
      // We don't necessarily update the energy table with the swap result 
      // in the same way, but it reflects the new minimum.
    }

    result.messages.push_back(
        std::string("[SOLVE] swap_loop_enabled=true mode=") +
        std::to_string(sw_opts.mode) +
        " max_swap=" + std::to_string(sw_opts.max_swap));
    result.messages.push_back(
        std::string("[SOLVE] swap_seeded_from_window=") +
        (seeded_from_window ? "true" : "false"));
    result.messages.push_back(
        std::string("[SOLVE] swap_seeded_from_external=") +
        (seeded_from_external ? "true" : "false"));
    result.messages.push_back(
        "[SOLVE] swap_seed_source=" + std::to_string(seed_source_used));
    result.messages.push_back(
        "[SOLVE] swap_initial_e=" +
        std::to_string(static_cast<double>(sw.initial_total_energy)));
    result.messages.push_back(
        "[SOLVE] swap_final_e=" +
        std::to_string(static_cast<double>(sw.final_total_energy)));
    result.messages.push_back(
        "[SOLVE] de_min_swap=" +
        std::to_string(static_cast<double>(sw.de_min_swap)));
    result.messages.push_back("[SOLVE] swap_count=" +
                              std::to_string(sw.swap_count));
    // Propagate swap-loop diagnostic log lines (e.g., [SWAP] verify ...).
    for (const auto& line : sw.log) {
      if (line.rfind("[SWAP] verify", 0) == 0) {
        result.messages.push_back(line);
      }
    }
    result.messages.push_back(
        std::string("[SOLVE] swap_stopped_by_max_swap=") +
        (sw.stopped_by_max_swap ? "true" : "false"));
    result.messages.push_back(
        std::string("[SOLVE] swap_stopped_by_no_improvement=") +
        (sw.stopped_by_no_improvement ? "true" : "false"));
    emit_progress(input.options,
                  input.runtime,
                  result.local_enumeration_loop,
                  result.window_evaluation,
                  "solve.swap.done",
                  started_at);
  }

  return result;
}

RunResult run(const RunInput& input) {
  RunResult result;
  result.guide = guide(input.guide);

  SolveInput solve_input;
  solve_input.ready = result.guide.ready;
  solve_input.options = input.solve;
  solve_input.runtime = input.runtime;
  result.solve = solve(solve_input);
  result.solve.messages.push_back("run() core stub reached");
  return result;
}

}  // namespace ess
