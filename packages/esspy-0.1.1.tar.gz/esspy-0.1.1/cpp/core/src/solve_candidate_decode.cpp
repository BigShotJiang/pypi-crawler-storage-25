#include "ess/solve_candidate_decode.hpp"

#include <cmath>
#include <limits>
#include <vector>

namespace ess::solve_steps {

namespace {

unsigned long long gcd_u64(unsigned long long a, unsigned long long b) {
  while (b != 0) {
    const unsigned long long t = a % b;
    a = b;
    b = t;
  }
  return a;
}

unsigned long long choose_u64(int n, int k) {
  if (k < 0 || k > n) {
    return 0;
  }
  if (k == 0 || k == n) {
    return 1;
  }
  if (k > n - k) {
    k = n - k;
  }

  std::vector<unsigned long long> numerators;
  numerators.reserve(static_cast<std::size_t>(k));
  for (int i = 0; i < k; ++i) {
    numerators.push_back(static_cast<unsigned long long>(n - k + 1 + i));
  }
  for (int d = 2; d <= k; ++d) {
    unsigned long long denom = static_cast<unsigned long long>(d);
    for (auto& num : numerators) {
      const unsigned long long g = gcd_u64(num, denom);
      if (g > 1) {
        num /= g;
        denom /= g;
      }
      if (denom == 1) {
        break;
      }
    }
  }

  unsigned long long result = 1;
  for (const auto num : numerators) {
    result *= num;
  }
  return result;
}

long double choose_ld(int n, int k) {
  if (k < 0 || k > n) {
    return 0.0L;
  }
  if (k == 0 || k == n) {
    return 1.0L;
  }
  if (k > n - k) {
    k = n - k;
  }
  long double result = 1.0L;
  for (int i = 1; i <= k; ++i) {
    result = result * static_cast<long double>(n - k + i) / static_cast<long double>(i);
  }
  return result;
}

bool multinomial_exceeds_signed_long_long(
    int n,
    const std::vector<int>& parts) {
  const long double value = multinomial_ld(n, parts);
  const long double limit =
      static_cast<long double>(std::numeric_limits<long long>::max());
  return !std::isfinite(static_cast<double>(value)) || value > limit;
}

std::vector<CompositionEntry> towhich_entries(const ReadyRecipe& recipe) {
  std::vector<CompositionEntry> entries;
  int assigned_positive = 0;
  for (const auto& modification : recipe.modifications) {
    if (modification.number <= 0 || modification.to == "vac") {
      continue;
    }
    assigned_positive += modification.number;
  }

  const int unchanged_count = recipe.random_pickup - assigned_positive;
  if (unchanged_count > 0) {
    entries.push_back(CompositionEntry{recipe.from, unchanged_count});
  }
  for (const auto& modification : recipe.modifications) {
    if (modification.number <= 0 || modification.to == "vac") {
      continue;
    }
    entries.push_back(CompositionEntry{modification.to, modification.number});
  }
  return entries;
}

bool indices_match_recipe_counts(
    const ReadyRecipe& recipe,
    const std::vector<int>& indices) {
  const auto towhich = towhich_entries(recipe);
  if (indices.size() != static_cast<std::size_t>(recipe.random_pickup)) {
    return false;
  }
  std::vector<int> counts(towhich.size(), 0);
  for (const int value : indices) {
    if (value < 0 || value >= static_cast<int>(counts.size())) {
      return false;
    }
    counts[static_cast<std::size_t>(value)] += 1;
  }
  for (std::size_t i = 0; i < towhich.size(); ++i) {
    if (counts[i] != towhich[i].count) {
      return false;
    }
  }
  return true;
}

void decode_legacy_into_core(
    const ReadyRecipe& recipe,
    unsigned long long index,
    const LegacyCommonDecodeCache* cache,
    std::vector<int>& indices) {
  const auto towhich = towhich_entries(recipe);
  std::vector<int> counts;
  counts.reserve(towhich.size());
  for (const auto& entry : towhich) {
    counts.push_back(entry.count);
  }

  if (multinomial_exceeds_signed_long_long(recipe.random_pickup, counts)) {
    indices = decode_candidate_assignment_indices_ld(
        recipe, static_cast<long double>(index));
    return;
  }

  std::vector<long long> sigma_minus_xk(towhich.size(), 0);
  if (indices.size() != static_cast<std::size_t>(recipe.random_pickup)) {
    indices.assign(static_cast<std::size_t>(recipe.random_pickup), 0);
  }

  long long ni0 = static_cast<long long>(
      multinomial_u64(recipe.random_pickup, counts));
  long long ni1 = static_cast<long long>(recipe.random_pickup);
  long long nbar = 0;
  long long index_dynamic = static_cast<long long>(index);

  int i_start = 1;
  if (cache != nullptr && cache->enabled && !cache->common_prefix.empty()) {
    const int prefix_len = std::min(
        static_cast<int>(cache->common_prefix.size()), recipe.random_pickup);
    for (int i = 0; i < prefix_len; ++i) {
      indices[static_cast<std::size_t>(i)] = cache->common_prefix[static_cast<std::size_t>(i)];
    }
    i_start = prefix_len + 1;
    index_dynamic -= cache->dindex_common;
    sigma_minus_xk = cache->sigma_common;
  }

  for (int i = i_start; i <= recipe.random_pickup; ++i) {
    if (cache != nullptr && cache->enabled && !cache->common_prefix.empty() &&
        i == i_start) {
      ni0 = cache->ni_common_0;
      ni1 = cache->ni_common_1;
    } else if (i != 1) {
      ni0 = nbar;
      ni1 = static_cast<long long>(recipe.random_pickup - i + 1);
    }

    long long nixk = 0;
    long long nixk_buf = 0;
    long long dnixm = 0;
    bool assigned = false;
    for (int m = 1; m <= static_cast<int>(towhich.size()); ++m) {
      long long multiplier =
          static_cast<long long>(towhich[static_cast<std::size_t>(m - 1)].count) -
          sigma_minus_xk[static_cast<std::size_t>(m - 1)];
      if (multiplier < 0) {
        multiplier = 0;
      }
      dnixm = ni0 * multiplier;
      if (dnixm > 0) {
        dnixm /= ni1;
      } else {
        const long double dnixm_ld =
            static_cast<long double>(ni0) * static_cast<long double>(multiplier) /
            static_cast<long double>(ni1);
        dnixm = static_cast<long long>(dnixm_ld);
      }
      nixk_buf = nixk;
      nixk += dnixm;
      if (index_dynamic > nixk_buf && index_dynamic <= nixk) {
        sigma_minus_xk[static_cast<std::size_t>(m - 1)]++;
        indices[static_cast<std::size_t>(i - 1)] = m - 1;
        index_dynamic -= nixk_buf;
        nbar = dnixm;
        assigned = true;
        break;
      }
    }
    (void)assigned;
  }
}

}  // namespace

unsigned long long multinomial_u64(int n, const std::vector<int>& parts) {
  const long double value = multinomial_ld(n, parts);
  const long double limit =
      static_cast<long double>(std::numeric_limits<unsigned long long>::max());
  if (!std::isfinite(static_cast<double>(value)) || value >= limit) {
    return std::numeric_limits<unsigned long long>::max();
  }

  unsigned long long result = 1;
  int remaining = n;
  for (const int part : parts) {
    if (part <= 0) {
      continue;
    }
    result *= choose_u64(remaining, part);
    remaining -= part;
  }
  return result;
}

long double multinomial_ld(int n, const std::vector<int>& parts) {
  long double result = 1.0L;
  int remaining = n;
  for (const int part : parts) {
    if (part <= 0) {
      continue;
    }
    result *= choose_ld(remaining, part);
    remaining -= part;
  }
  return result;
}

std::vector<int> decode_candidate_assignment_indices(
    const ReadyRecipe& recipe,
    unsigned long long index) {
  std::vector<int> indices(static_cast<std::size_t>(recipe.random_pickup), 0);
  decode_candidate_assignment_indices_legacy_into(recipe, index, indices);
  return indices;
}

void decode_candidate_assignment_indices_legacy_into(
    const ReadyRecipe& recipe,
    unsigned long long index,
    std::vector<int>& indices) {
  decode_legacy_into_core(recipe, index, nullptr, indices);
}

LegacyCommonDecodeCache build_legacy_common_decode_cache(
    const ReadyRecipe& recipe,
    unsigned long long range_start_index,
    unsigned long long range_end_index) {
  LegacyCommonDecodeCache cache;
  if (range_start_index == 0 || range_end_index == 0 ||
      range_end_index < range_start_index) {
    return cache;
  }

  std::vector<int> xpr_start(static_cast<std::size_t>(recipe.random_pickup), 0);
  std::vector<int> xpr_end(static_cast<std::size_t>(recipe.random_pickup), 0);
  decode_legacy_into_core(recipe, range_start_index, nullptr, xpr_start);
  decode_legacy_into_core(recipe, range_end_index, nullptr, xpr_end);

  for (int i = 0; i < recipe.random_pickup; ++i) {
    if (xpr_start[static_cast<std::size_t>(i)] ==
        xpr_end[static_cast<std::size_t>(i)]) {
      cache.common_prefix.push_back(xpr_start[static_cast<std::size_t>(i)]);
    } else {
      break;
    }
  }

  if (cache.common_prefix.empty()) {
    return cache;
  }

  const auto towhich = towhich_entries(recipe);
  cache.sigma_common.assign(towhich.size(), 0);
  std::vector<int> counts;
  counts.reserve(towhich.size());
  for (const auto& entry : towhich) {
    counts.push_back(entry.count);
  }
  if (multinomial_exceeds_signed_long_long(recipe.random_pickup, counts)) {
    return LegacyCommonDecodeCache{};
  }

  long long ni0 = static_cast<long long>(
      multinomial_u64(recipe.random_pickup, counts));
  long long ni1 = static_cast<long long>(recipe.random_pickup);
  long long nbar = 0;
  long long index_dynamic = static_cast<long long>(range_start_index);
  const long long original_index = index_dynamic;

  for (int i = 1; i <= static_cast<int>(cache.common_prefix.size()); ++i) {
    if (i != 1) {
      ni0 = nbar;
      ni1 = static_cast<long long>(recipe.random_pickup - i + 1);
    }
    long long nixk = 0;
    long long nixk_buf = 0;
    long long dnixm = 0;
    for (int m = 1; m <= static_cast<int>(towhich.size()); ++m) {
      long long multiplier =
          static_cast<long long>(towhich[static_cast<std::size_t>(m - 1)].count) -
          cache.sigma_common[static_cast<std::size_t>(m - 1)];
      if (multiplier < 0) {
        multiplier = 0;
      }
      dnixm = ni0 * multiplier;
      if (dnixm > 0) {
        dnixm /= ni1;
      } else {
        const long double dnixm_ld =
            static_cast<long double>(ni0) * static_cast<long double>(multiplier) /
            static_cast<long double>(ni1);
        dnixm = static_cast<long long>(dnixm_ld);
      }
      nixk_buf = nixk;
      nixk += dnixm;
      if (index_dynamic > nixk_buf && index_dynamic <= nixk) {
        cache.sigma_common[static_cast<std::size_t>(m - 1)]++;
        index_dynamic -= nixk_buf;
        nbar = dnixm;
        break;
      }
    }
  }

  cache.ni_common_0 = nbar;
  cache.ni_common_1 =
      static_cast<long long>(recipe.random_pickup) -
      static_cast<long long>(cache.common_prefix.size());
  cache.dindex_common = original_index - index_dynamic;
  cache.enabled = true;
  return cache;
}

void decode_candidate_assignment_indices_legacy_with_common_into(
    const ReadyRecipe& recipe,
    unsigned long long index,
    const LegacyCommonDecodeCache& cache,
    std::vector<int>& indices) {
  decode_legacy_into_core(
      recipe, index, (cache.enabled ? &cache : nullptr), indices);
}

std::vector<int> decode_candidate_assignment_indices_ld(
    const ReadyRecipe& recipe,
    long double index) {
  const auto towhich = towhich_entries(recipe);
  std::vector<int> sigma_minus_xk(towhich.size(), 0);
  std::vector<int> indices(static_cast<std::size_t>(recipe.random_pickup), 0);

  std::vector<int> counts;
  counts.reserve(towhich.size());
  for (const auto& entry : towhich) {
    counts.push_back(entry.count);
  }
  const long double jobsize = multinomial_ld(recipe.random_pickup, counts);

  long double ni0 = jobsize;
  long double ni1 = static_cast<long double>(recipe.random_pickup);
  long double nbar = 0.0L;
  long double index_dynamic = index;

  for (int i = 1; i <= recipe.random_pickup; ++i) {
    if (i != 1) {
      ni0 = nbar;
      ni1 = static_cast<long double>(recipe.random_pickup - i + 1);
    }

    long double nixk = 0.0L;
    long double nixk_buf = 0.0L;
    long double dnixm = 0.0L;
    for (int m = 1; m <= static_cast<int>(towhich.size()); ++m) {
      long long multiplier =
          static_cast<long long>(towhich[static_cast<std::size_t>(m - 1)].count) -
          static_cast<long long>(sigma_minus_xk[static_cast<std::size_t>(m - 1)]);
      if (multiplier < 0) {
        multiplier = 0;
      }
      dnixm = ni0 * static_cast<long double>(multiplier);
      if (dnixm > 0.0L) {
        dnixm /= ni1;
      }
      nixk_buf = nixk;
      nixk += dnixm;
      // Note: comparison of long double for index range
      if (index_dynamic > nixk_buf && index_dynamic <= nixk) {
        sigma_minus_xk[static_cast<std::size_t>(m - 1)]++;
        indices[static_cast<std::size_t>(i - 1)] = m - 1;
        index_dynamic -= nixk_buf;
        nbar = dnixm;
        break;
      }
    }
  }

  return indices;
}

std::vector<std::string> decode_first_candidate_labels(
    const ReadyRecipe& recipe) {
  return decode_candidate_assignment_labels(recipe, 1);
}

std::vector<std::string> decode_candidate_assignment_labels(
    const ReadyRecipe& recipe,
    unsigned long long index) {
  const auto indices = decode_candidate_assignment_indices(recipe, index);
  return decode_candidate_assignment_labels_from_indices(recipe, indices);
}

std::vector<std::string> decode_candidate_assignment_labels_from_indices(
    const ReadyRecipe& recipe,
    const std::vector<int>& indices) {
  const auto towhich = towhich_entries(recipe);
  std::vector<std::string> labels;
  labels.reserve(indices.size());
  for (const auto idx : indices) {
    labels.push_back(towhich[static_cast<std::size_t>(idx)].kind);
  }
  return labels;
}

}  // namespace ess::solve_steps
