#include "ess/solve_recipe_state.hpp"

#include <cstddef>
#include <string>
#include <unordered_map>
#include <vector>

namespace ess::solve_steps {

namespace {

std::vector<Site> expand_ready_sites(const ReadyModel& ready) {
  std::vector<Site> expanded;
  expanded.reserve(
      ready.atoms.size() * static_cast<std::size_t>(ready.supercell_expansion[0]) *
      static_cast<std::size_t>(ready.supercell_expansion[1]) *
      static_cast<std::size_t>(ready.supercell_expansion[2]));

  for (int i = 0; i < ready.supercell_expansion[0]; ++i) {
    for (int j = 0; j < ready.supercell_expansion[1]; ++j) {
      for (int k = 0; k < ready.supercell_expansion[2]; ++k) {
        for (const auto& atom : ready.atoms) {
          Site site;
          site.kind = atom.kind;
          site.oxidation = atom.oxidation;
          site.x = (atom.x + static_cast<long double>(i)) /
                   static_cast<long double>(ready.supercell_expansion[0]);
          site.y = (atom.y + static_cast<long double>(j)) /
                   static_cast<long double>(ready.supercell_expansion[1]);
          site.z = (atom.z + static_cast<long double>(k)) /
                   static_cast<long double>(ready.supercell_expansion[2]);
          expanded.push_back(site);
        }
      }
    }
  }
  return expanded;
}

}  // namespace

StructureModel materialize_canonical_structure(const ReadyModel& ready) {
  return materialize_canonical_structure_with_pools(ready).structure;
}

CanonicalStructureWithPools materialize_canonical_structure_with_pools(
    const ReadyModel& ready) {
  CanonicalStructureWithPools result;
  StructureModel& structure = result.structure;
  structure.title = ready.output_prefix + "::canonical";
  structure.lattice.a = {
      ready.supercell_expansion[0] * ready.lattice.a[0],
      ready.supercell_expansion[0] * ready.lattice.a[1],
      ready.supercell_expansion[0] * ready.lattice.a[2],
  };
  structure.lattice.b = {
      ready.supercell_expansion[1] * ready.lattice.b[0],
      ready.supercell_expansion[1] * ready.lattice.b[1],
      ready.supercell_expansion[1] * ready.lattice.b[2],
  };
  structure.lattice.c = {
      ready.supercell_expansion[2] * ready.lattice.c[0],
      ready.supercell_expansion[2] * ready.lattice.c[1],
      ready.supercell_expansion[2] * ready.lattice.c[2],
  };
  structure.fractional_coordinates = true;
  structure.sites = expand_ready_sites(ready);

  // Bucket indices by *pre-canonical-mutation* kind so that the
  // recipe_pools we hand back to the swap loop match the legacy ESS
  // semantics (the swap loop iterates over the sites that originated as
  // the recipe's source species, not over their post-mutation kinds).
  std::unordered_map<std::string, std::vector<std::size_t>> bucket_indices;
  bucket_indices.reserve(ready.recipes.size());
  for (std::size_t index = 0; index < structure.sites.size(); ++index) {
    bucket_indices[structure.sites[index].kind].push_back(index);
  }

  result.recipe_pools.assign(ready.recipes.size(), {});
  for (std::size_t recipe_index = 0; recipe_index < ready.recipes.size();
       ++recipe_index) {
    const auto& recipe = ready.recipes[recipe_index];
    auto bucket_it = bucket_indices.find(recipe.from);
    if (bucket_it == bucket_indices.end()) {
      continue;
    }
    // Snapshot the bucket as the recipe pool (full pool, including the
    // unchanged tail). The legacy swap loop swaps within this whole pool,
    // not just the modified prefix.
    result.recipe_pools[recipe_index] = bucket_it->second;

    std::size_t cursor = 0;
    for (const auto& modification : recipe.modifications) {
      if (modification.number <= 0 || modification.to == "vac") {
        continue;
      }
      for (int count = 0; count < modification.number; ++count) {
        if (cursor >= bucket_it->second.size()) {
          break;
        }
        auto& site = structure.sites[bucket_it->second[cursor]];
        site.kind = modification.to;
        site.oxidation = modification.oxidation;
        ++cursor;
      }
    }
  }

  return result;
}

}  // namespace ess::solve_steps
