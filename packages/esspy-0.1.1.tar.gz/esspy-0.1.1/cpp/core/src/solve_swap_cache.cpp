#include "ess/solve_swap_cache.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>

#include "ess/ewald_shared.hpp"

namespace ess::solve_steps {
namespace {

constexpr long double kPi = 3.14159265358979323846264338327950L;
constexpr long double kConvFact = 14.39964547058623L;
constexpr long double kBenchmarkW = 1.0L / 1.4142135623730950488L;
constexpr long double kBenchmarkAccFactor = 12.0L;

struct EvalAtom {
  long double fx = 0.0L;
  long double fy = 0.0L;
  long double fz = 0.0L;
  long double x = 0.0L;
  long double y = 0.0L;
  long double z = 0.0L;
};

struct EvalCell {
  std::vector<EvalAtom> atoms;
  Lattice lattice;
  long double eight_points[8][3]{};
  long double volume = 0.0L;
};

struct KPoint {
  long double kx = 0.0L;
  long double ky = 0.0L;
  long double kz = 0.0L;
  long double norm_sq = 0.0L;
  long double weight = 0.0L;
};

long double vec_norm(const std::array<long double, 3>& v) {
  return std::sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

std::array<long double, 3> cart_from_frac(
    const Lattice& lattice,
    long double a,
    long double b,
    long double c) {
  return {
      lattice.a[0] * a + lattice.b[0] * b + lattice.c[0] * c,
      lattice.a[1] * a + lattice.b[1] * b + lattice.c[1] * c,
      lattice.a[2] * a + lattice.b[2] * b + lattice.c[2] * c,
  };
}

long double cell_volume(const Lattice& lattice) {
  long double volume = 0.0L;
  volume += lattice.a[0] * (lattice.b[1] * lattice.c[2] - lattice.b[2] * lattice.c[1]);
  volume -= lattice.a[1] * (lattice.b[0] * lattice.c[2] - lattice.b[2] * lattice.c[0]);
  volume += lattice.a[2] * (lattice.b[0] * lattice.c[1] - lattice.b[1] * lattice.c[0]);
  return volume;
}

void fill_eight_points(EvalCell& cell) {
  int point_count = 0;
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < 2; ++j) {
      for (int k = 0; k < 2; ++k) {
        for (int l = 0; l < 3; ++l) {
          cell.eight_points[point_count][l] =
              static_cast<long double>(i) * cell.lattice.a[l] +
              static_cast<long double>(j) * cell.lattice.b[l] +
              static_cast<long double>(k) * cell.lattice.c[l];
        }
        ++point_count;
      }
    }
  }
}

EvalCell build_explicit_cell(const StructureModel& structure) {
  EvalCell cell;
  cell.lattice = structure.lattice;
  for (const auto& atom : structure.sites) {
    EvalAtom obj;
    obj.fx = atom.x;
    obj.fy = atom.y;
    obj.fz = atom.z;
    const auto cart = cart_from_frac(cell.lattice, obj.fx, obj.fy, obj.fz);
    obj.x = cart[0];
    obj.y = cart[1];
    obj.z = cart[2];
    cell.atoms.push_back(obj);
  }
  fill_eight_points(cell);
  cell.volume = cell_volume(cell.lattice);
  return cell;
}

int periodic_indicator(const EvalCell& super_cell, long double r_max, int rg_find_factor) {
  std::array<long double, 3> diag{
      super_cell.lattice.a[0] + super_cell.lattice.b[0] + super_cell.lattice.c[0],
      super_cell.lattice.a[1] + super_cell.lattice.b[1] + super_cell.lattice.c[1],
      super_cell.lattice.a[2] + super_cell.lattice.b[2] + super_cell.lattice.c[2],
  };
  int indicator = static_cast<int>(r_max / vec_norm(diag));
  if (indicator == 0) {
    indicator = 1;
  }
  return indicator * rg_find_factor;
}

std::vector<EvalCell> periodic_cells(
    const EvalCell& super_cell,
    long double r_max,
    int indicator) {
  std::vector<EvalCell> result;
  std::vector<int> seen_i;
  std::vector<int> seen_j;
  std::vector<int> seen_k;
  result.push_back(super_cell);
  seen_i.push_back(0);
  seen_j.push_back(0);
  seen_k.push_back(0);

  auto periodic_in_one_sector = [&](int x_increase, int y_increase, int z_increase) {
    for (int i = 0; std::abs(i) < indicator; i += x_increase) {
      for (int j = 0; std::abs(j) < indicator; j += y_increase) {
        for (int k = 0; std::abs(k) < indicator; k += z_increase) {
          bool initialized = true;
          for (std::size_t l = 0; l < seen_i.size(); ++l) {
            if (seen_i[l] == i && seen_j[l] == j && seen_k[l] == k) {
              initialized = false;
              break;
            }
          }
          if ((i == 0 && j == 0 && k == 0) || !initialized) {
            continue;
          }
          EvalCell cell;
          for (int l = 0; l < 8; ++l) {
            for (int m = 0; m < 3; ++m) {
              cell.eight_points[l][m] = super_cell.eight_points[l][m] +
                                        static_cast<long double>(i) * super_cell.lattice.a[m] +
                                        static_cast<long double>(j) * super_cell.lattice.b[m] +
                                        static_cast<long double>(k) * super_cell.lattice.c[m];
            }
          }
          long double rmin = 1.0e10L;
          for (int l = 0; l < 8; ++l) {
            for (int m = 0; m < 8; ++m) {
              const long double dx = cell.eight_points[l][0] - super_cell.eight_points[m][0];
              const long double dy = cell.eight_points[l][1] - super_cell.eight_points[m][1];
              const long double dz = cell.eight_points[l][2] - super_cell.eight_points[m][2];
              const long double dist = std::sqrt(dx * dx + dy * dy + dz * dz);
              if (dist < rmin) {
                rmin = dist;
              }
            }
          }
          if (rmin < r_max) {
            cell.volume = super_cell.volume;
            cell.lattice = super_cell.lattice;
            for (const auto& atom : super_cell.atoms) {
              EvalAtom obj = atom;
              obj.fx = atom.fx + static_cast<long double>(i);
              obj.fy = atom.fy + static_cast<long double>(j);
              obj.fz = atom.fz + static_cast<long double>(k);
              const auto cart = cart_from_frac(super_cell.lattice, obj.fx, obj.fy, obj.fz);
              obj.x = cart[0];
              obj.y = cart[1];
              obj.z = cart[2];
              cell.atoms.push_back(obj);
            }
            result.push_back(cell);
            seen_i.push_back(i);
            seen_j.push_back(j);
            seen_k.push_back(k);
          }
        }
      }
    }
  };

  periodic_in_one_sector(1, 1, 1);
  periodic_in_one_sector(1, 1, -1);
  periodic_in_one_sector(1, -1, 1);
  periodic_in_one_sector(1, -1, -1);
  periodic_in_one_sector(-1, 1, 1);
  periodic_in_one_sector(-1, 1, -1);
  periodic_in_one_sector(-1, -1, 1);
  periodic_in_one_sector(-1, -1, -1);
  return result;
}

std::array<long double, 3> reciprocal_a(const Lattice& lattice, long double volume) {
  return {
      (lattice.b[1] * lattice.c[2] - lattice.b[2] * lattice.c[1]) * 2.0L * kPi / volume,
      (-lattice.b[0] * lattice.c[2] + lattice.b[2] * lattice.c[0]) * 2.0L * kPi / volume,
      (lattice.b[0] * lattice.c[1] - lattice.b[1] * lattice.c[0]) * 2.0L * kPi / volume,
  };
}

std::array<long double, 3> reciprocal_b(const Lattice& lattice, long double volume) {
  return {
      (lattice.c[1] * lattice.a[2] - lattice.c[2] * lattice.a[1]) * 2.0L * kPi / volume,
      (-lattice.c[0] * lattice.a[2] + lattice.c[2] * lattice.a[0]) * 2.0L * kPi / volume,
      (lattice.c[0] * lattice.a[1] - lattice.c[1] * lattice.a[0]) * 2.0L * kPi / volume,
  };
}

std::array<long double, 3> reciprocal_c(const Lattice& lattice, long double volume) {
  return {
      (lattice.a[1] * lattice.b[2] - lattice.a[2] * lattice.b[1]) * 2.0L * kPi / volume,
      (-lattice.a[0] * lattice.b[2] + lattice.a[2] * lattice.b[0]) * 2.0L * kPi / volume,
      (lattice.a[0] * lattice.b[1] - lattice.a[1] * lattice.b[0]) * 2.0L * kPi / volume,
  };
}

std::vector<KPoint> relevant_kpoints(
    const std::array<long double, 3>& rcp_a,
    const std::array<long double, 3>& rcp_b,
    const std::array<long double, 3>& rcp_c,
    long double g_max,
    long double chop,
    int rg_find_factor) {
  long double rcp_min = std::min({vec_norm(rcp_a), vec_norm(rcp_b), vec_norm(rcp_c)});
  int g_count_factor = static_cast<int>(g_max / rcp_min);
  if (g_count_factor == 0) {
    g_count_factor = 1;
  }
  g_count_factor *= rg_find_factor;
  std::vector<KPoint> result;
  for (int ka = -g_count_factor; ka <= g_count_factor; ++ka) {
    for (int kb = -g_count_factor; kb <= g_count_factor; ++kb) {
      for (int kc = -g_count_factor; kc <= g_count_factor; ++kc) {
        const std::array<long double, 3> k_point{
            static_cast<long double>(ka) * rcp_a[0] + static_cast<long double>(kb) * rcp_b[0] + static_cast<long double>(kc) * rcp_c[0],
            static_cast<long double>(ka) * rcp_a[1] + static_cast<long double>(kb) * rcp_b[1] + static_cast<long double>(kc) * rcp_c[1],
            static_cast<long double>(ka) * rcp_a[2] + static_cast<long double>(kb) * rcp_b[2] + static_cast<long double>(kc) * rcp_c[2],
        };
        const long double norm = vec_norm(k_point);
        if (norm < g_max && norm > chop) {
          KPoint kp;
          kp.kx = k_point[0];
          kp.ky = k_point[1];
          kp.kz = k_point[2];
          kp.norm_sq = norm * norm;
          result.push_back(kp);
        }
      }
    }
  }
  return result;
}

bool same_oxidation_state(const SwapEnergyCache& cache, const StructureModel& structure) {
  if (cache.current_oxidations.size() != structure.sites.size()) {
    return false;
  }
  for (std::size_t i = 0; i < structure.sites.size(); ++i) {
    if (cache.current_oxidations[i] != structure.sites[i].oxidation) {
      return false;
    }
  }
  return true;
}

void rebuild_real_state(SwapEnergyCache& cache, const StructureModel& structure) {
  long double ereal = 0.0L;
  for (std::size_t i = 0; i < cache.atom_count; ++i) {
    const long double qi = structure.sites[i].oxidation;
    for (std::size_t k = 0; k < cache.atom_count; ++k) {
      const long double qk = structure.sites[k].oxidation;
      ereal += cache.real_pair_coefficients[i * cache.atom_count + k] * qi * qk;
    }
  }
  cache.current_real_energy = ereal * 0.5L * kConvFact;
  cache.real_state_initialized = true;
}

void ensure_real_state(SwapEnergyCache& cache, const StructureModel& structure) {
  if (!cache.real_state_initialized || !same_oxidation_state(cache, structure)) {
    rebuild_real_state(cache, structure);
  }
}

void rebuild_point_state(SwapEnergyCache& cache, const StructureModel& structure) {
  long double sum_q2 = 0.0L;
  for (const auto& site : structure.sites) {
    sum_q2 += site.oxidation * site.oxidation;
  }
  cache.current_point_energy = cache.point_prefactor * sum_q2;
  cache.point_state_initialized = true;
}

void ensure_point_state(SwapEnergyCache& cache, const StructureModel& structure) {
  if (!cache.point_state_initialized || !same_oxidation_state(cache, structure)) {
    rebuild_point_state(cache, structure);
  }
}

void rebuild_recip_state(SwapEnergyCache& cache, const StructureModel& structure) {
  cache.current_oxidations.assign(cache.atom_count, 0.0L);
  cache.current_cos_sums.assign(cache.recip_weights.size(), 0.0L);
  cache.current_sin_sums.assign(cache.recip_weights.size(), 0.0L);
  cache.current_recip_energy = 0.0L;
  for (std::size_t i = 0; i < cache.atom_count; ++i) {
    cache.current_oxidations[i] = structure.sites[i].oxidation;
  }
  for (std::size_t k = 0; k < cache.recip_weights.size(); ++k) {
    long double cosine_sum = 0.0L;
    long double sine_sum = 0.0L;
    for (std::size_t i = 0; i < cache.atom_count; ++i) {
      const long double q = cache.current_oxidations[i];
      cosine_sum += q * cache.recip_cos_coefficients[k * cache.atom_count + i];
      sine_sum += q * cache.recip_sin_coefficients[k * cache.atom_count + i];
    }
    cache.current_cos_sums[k] = cosine_sum;
    cache.current_sin_sums[k] = sine_sum;
    cache.current_recip_energy += cache.recip_weights[k] *
                                  (cosine_sum * cosine_sum + sine_sum * sine_sum);
  }
  cache.recip_state_initialized = true;
  cache.stats.recip_state_rebuilds += 1;
}

void ensure_recip_state(SwapEnergyCache& cache, const StructureModel& structure) {
  if (!cache.recip_state_initialized || !same_oxidation_state(cache, structure)) {
    rebuild_recip_state(cache, structure);
  }
}

struct SiteUpdateDelta {
  long double real = 0.0L;
  long double point = 0.0L;
  long double recip = 0.0L;
  std::vector<std::size_t> changed;
  std::vector<long double> dq;
  std::vector<long double> recip_dc;
  std::vector<long double> recip_ds;
};

SiteUpdateDelta build_site_update_delta(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    const std::vector<std::size_t>& changed_indices,
    const std::vector<long double>& new_oxidations,
    bool count_diff_evaluation) {
  if (changed_indices.size() != new_oxidations.size()) {
    throw std::runtime_error(
        "changed_indices and new_oxidations must have the same length");
  }
  if (structure.sites.size() != cache.atom_count) {
    throw std::runtime_error(
        "structure atom count does not match SwapEnergyCache atom count");
  }

  ensure_real_state(cache, structure);
  ensure_point_state(cache, structure);
  ensure_recip_state(cache, structure);

  SiteUpdateDelta result;
  result.changed.reserve(changed_indices.size());
  result.dq.reserve(changed_indices.size());
  std::vector<std::size_t> seen;
  seen.reserve(changed_indices.size());

  for (std::size_t pos = 0; pos < changed_indices.size(); ++pos) {
    const std::size_t i = changed_indices[pos];
    if (i >= cache.atom_count) {
      throw std::runtime_error("changed site index is out of range");
    }
    if (std::find(seen.begin(), seen.end(), i) != seen.end()) {
      throw std::runtime_error("changed site indices must be unique");
    }
    seen.push_back(i);
    const long double old_q = cache.current_oxidations[i];
    const long double delta_q = new_oxidations[pos] - old_q;
    if (delta_q == 0.0L) {
      continue;
    }
    result.changed.push_back(i);
    result.dq.push_back(delta_q);
    result.point += cache.point_prefactor *
                    ((old_q + delta_q) * (old_q + delta_q) - old_q * old_q);
  }

  if (result.changed.empty()) {
    if (count_diff_evaluation) {
      cache.stats.diff_evaluations += 1;
    }
    return result;
  }

  long double real_delta = 0.0L;
  for (std::size_t a = 0; a < result.changed.size(); ++a) {
    const std::size_t i = result.changed[a];
    long double linear = 0.0L;
    for (std::size_t j = 0; j < cache.atom_count; ++j) {
      linear += cache.real_pair_coefficients[i * cache.atom_count + j] *
                cache.current_oxidations[j];
    }
    real_delta += 2.0L * result.dq[a] * linear;
  }
  for (std::size_t a = 0; a < result.changed.size(); ++a) {
    const std::size_t i = result.changed[a];
    for (std::size_t b = 0; b < result.changed.size(); ++b) {
      const std::size_t j = result.changed[b];
      real_delta += result.dq[a] *
                    cache.real_pair_coefficients[i * cache.atom_count + j] *
                    result.dq[b];
    }
  }
  result.real = 0.5L * kConvFact * real_delta;

  result.recip_dc.assign(cache.recip_weights.size(), 0.0L);
  result.recip_ds.assign(cache.recip_weights.size(), 0.0L);
  for (std::size_t k = 0; k < cache.recip_weights.size(); ++k) {
    long double dc = 0.0L;
    long double ds = 0.0L;
    for (std::size_t a = 0; a < result.changed.size(); ++a) {
      const std::size_t i = result.changed[a];
      dc += result.dq[a] * cache.recip_cos_coefficients[k * cache.atom_count + i];
      ds += result.dq[a] * cache.recip_sin_coefficients[k * cache.atom_count + i];
    }
    result.recip_dc[k] = dc;
    result.recip_ds[k] = ds;
    const long double old_cos = cache.current_cos_sums[k];
    const long double old_sin = cache.current_sin_sums[k];
    result.recip += cache.recip_weights[k] *
                    (2.0L * old_cos * dc + dc * dc +
                     2.0L * old_sin * ds + ds * ds);
  }

  if (count_diff_evaluation) {
    cache.stats.diff_evaluations += 1;
  }
  return result;
}

}  // namespace

SwapEnergyCache create_swap_energy_cache(
    const StructureModel& structure,
    int rg_find_factor,
    long double chop_level) {
  SwapEnergyCache cache;
  cache.rg_find_factor = rg_find_factor;
  cache.chop_level = chop_level;
  cache.stats.diff_cache_enabled = true;
  cache.atom_count = structure.sites.size();
  cache.real_pair_coefficients.assign(cache.atom_count * cache.atom_count, 0.0L);

  const long double chop = std::pow(10.0L, -chop_level);
  const EvalCell super_cell = build_explicit_cell(structure);
  const long double para_alpha_square =
      std::pow((static_cast<long double>(super_cell.atoms.size()) * kBenchmarkW /
                std::pow(super_cell.volume, 2.0L)),
               1.0L / 3.0L) *
      kPi;
  const long double para_alpha = std::sqrt(para_alpha_square);
  const long double log_factor = std::sqrt(std::log(std::pow(10.0L, kBenchmarkAccFactor)));
  const long double r_max = log_factor / para_alpha;
  const long double g_max = 2.0L * para_alpha * log_factor;
  cache.point_prefactor = -kConvFact * para_alpha / std::sqrt(kPi);
  const auto rcp_a = reciprocal_a(super_cell.lattice, super_cell.volume);
  const auto rcp_b = reciprocal_b(super_cell.lattice, super_cell.volume);
  const auto rcp_c = reciprocal_c(super_cell.lattice, super_cell.volume);
  const int indicator = periodic_indicator(super_cell, r_max, rg_find_factor);
  const auto super_cell_pr = periodic_cells(super_cell, r_max, indicator);
  auto kpoints = relevant_kpoints(rcp_a, rcp_b, rcp_c, g_max, chop, rg_find_factor);

  int pair_terms = 0;
  for (std::size_t i = 0; i < super_cell.atoms.size(); ++i) {
    for (const auto& cell_j : super_cell_pr) {
      for (std::size_t k = 0; k < cell_j.atoms.size(); ++k) {
        const auto& atom_i = super_cell.atoms[i];
        const auto& atom_k = cell_j.atoms[k];
        const long double dx = atom_k.x - atom_i.x;
        const long double dy = atom_k.y - atom_i.y;
        const long double dz = atom_k.z - atom_i.z;
        const long double rij = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (rij > chop && rij < r_max) {
          cache.real_pair_coefficients[i * cache.atom_count + k] +=
              std::erfc(para_alpha * rij) / rij;
          pair_terms += 1;
        }
      }
    }
  }
  cache.stats.real_pair_terms = pair_terms;

  const long double recip_prefactor = (2.0L * kPi / super_cell.volume) * kConvFact;
  cache.recip_weights.reserve(kpoints.size());
  cache.recip_cos_coefficients.assign(kpoints.size() * cache.atom_count, 0.0L);
  cache.recip_sin_coefficients.assign(kpoints.size() * cache.atom_count, 0.0L);
  for (std::size_t k = 0; k < kpoints.size(); ++k) {
    auto& kp = kpoints[k];
    const long double expval = std::exp(-kp.norm_sq / (4.0L * para_alpha_square));
    kp.weight = recip_prefactor * expval / kp.norm_sq;
    cache.recip_weights.push_back(kp.weight);
    for (std::size_t i = 0; i < super_cell.atoms.size(); ++i) {
      const auto& atom = super_cell.atoms[i];
      const long double gr = kp.kx * atom.x + kp.ky * atom.y + kp.kz * atom.z;
      cache.recip_cos_coefficients[k * cache.atom_count + i] = std::cos(gr);
      cache.recip_sin_coefficients[k * cache.atom_count + i] = std::sin(gr);
    }
  }
  cache.stats.recip_kpoint_terms = static_cast<int>(kpoints.size());
  return cache;
}

ReadyModel ready_view_from_structure(const StructureModel& structure,
                                     int rg_find_factor) {
  ReadyModel view;
  view.lattice = structure.lattice;
  view.atoms.reserve(structure.sites.size());
  for (const auto& site : structure.sites) {
    ReadyAtom atom;
    atom.kind = site.kind;
    atom.oxidation = site.oxidation;
    atom.x = site.x;
    atom.y = site.y;
    atom.z = site.z;
    view.atoms.push_back(atom);
  }
  view.supercell_expansion = {1, 1, 1};
  view.rg_find_factor = rg_find_factor;
  view.output_prefix = structure.title;
  return view;
}

long double evaluate_real_energy_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure) {
  cache.stats.real_cache_evaluations += 1;
  ensure_real_state(cache, structure);
  return cache.current_real_energy;
}

long double evaluate_swap_real_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b) {
  cache.stats.diff_evaluations += 1;
  if (site_a >= cache.atom_count || site_b >= cache.atom_count || site_a == site_b) {
    return 0.0L;
  }
  const long double q_a = structure.sites[site_a].oxidation;
  const long double q_b = structure.sites[site_b].oxidation;
  const long double delta = q_b - q_a;
  if (delta == 0.0L) {
    return 0.0L;
  }

  long double s = 0.0L;
  for (std::size_t j = 0; j < cache.atom_count; ++j) {
    const long double q_j = structure.sites[j].oxidation;
    s += (cache.real_pair_coefficients[site_a * cache.atom_count + j] -
          cache.real_pair_coefficients[site_b * cache.atom_count + j]) * q_j;
  }
  const long double c =
      cache.real_pair_coefficients[site_a * cache.atom_count + site_a] -
      2.0L * cache.real_pair_coefficients[site_a * cache.atom_count + site_b] +
      cache.real_pair_coefficients[site_b * cache.atom_count + site_b];
  return 0.5L * kConvFact * (2.0L * delta * s + delta * delta * c);
}

long double evaluate_point_energy_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure) {
  cache.stats.point_cache_evaluations += 1;
  ensure_point_state(cache, structure);
  return cache.current_point_energy;
}

long double evaluate_swap_point_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b) {
  if (site_a >= cache.atom_count || site_b >= cache.atom_count || site_a == site_b) {
    return 0.0L;
  }
  const long double q_a = structure.sites[site_a].oxidation;
  const long double q_b = structure.sites[site_b].oxidation;
  const long double delta = q_b - q_a;
  if (delta == 0.0L) {
    return 0.0L;
  }
  // delta_E_point = prefactor * ( (q_a+delta)^2 + (q_b-delta)^2 - q_a^2 - q_b^2 )
  // = prefactor * ( q_b^2 + q_a^2 - q_a^2 - q_b^2 ) = 0
  // Actually, a swap of oxidation states q_a, q_b results in:
  // new_sum_q2 = sum_q2 - q_a^2 - q_b^2 + q_b^2 + q_a^2 = sum_q2
  // So point delta is always 0 for a swap.
  return 0.0L;
}

long double evaluate_recip_energy_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure) {
  cache.stats.recip_cache_evaluations += 1;
  ensure_recip_state(cache, structure);
  return cache.current_recip_energy;
}

long double evaluate_swap_recip_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b) {
  cache.stats.diff_evaluations += 1;
  if (site_a >= cache.atom_count || site_b >= cache.atom_count || site_a == site_b) {
    return 0.0L;
  }
  const long double q_a = structure.sites[site_a].oxidation;
  const long double q_b = structure.sites[site_b].oxidation;
  const long double delta = q_b - q_a;
  if (delta == 0.0L) {
    return 0.0L;
  }

  ensure_recip_state(cache, structure);

  long double delta_e = 0.0L;
  for (std::size_t k = 0; k < cache.recip_weights.size(); ++k) {
    const long double cosine_sum = cache.current_cos_sums[k];
    const long double sine_sum = cache.current_sin_sums[k];
    const long double dc = delta * (
        cache.recip_cos_coefficients[k * cache.atom_count + site_a] -
        cache.recip_cos_coefficients[k * cache.atom_count + site_b]);
    const long double ds = delta * (
        cache.recip_sin_coefficients[k * cache.atom_count + site_a] -
        cache.recip_sin_coefficients[k * cache.atom_count + site_b]);
    delta_e += cache.recip_weights[k] *
               (2.0L * cosine_sum * dc + dc * dc + 2.0L * sine_sum * ds + ds * ds);
  }
  return delta_e;
}

void commit_swap_state(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b) {
  if (site_a >= cache.atom_count || site_b >= cache.atom_count || site_a == site_b) {
    return;
  }

  // Ensure all states are up to date before committing
  ensure_real_state(cache, structure);
  ensure_point_state(cache, structure);
  ensure_recip_state(cache, structure);

  const long double q_a = cache.current_oxidations[site_a];
  const long double q_b = cache.current_oxidations[site_b];
  const long double delta = q_b - q_a;
  if (delta == 0.0L) {
    return;
  }

  // 1. Real incremental
  long double s = 0.0L;
  for (std::size_t j = 0; j < cache.atom_count; ++j) {
    const long double q_j = structure.sites[j].oxidation;
    s += (cache.real_pair_coefficients[site_a * cache.atom_count + j] -
          cache.real_pair_coefficients[site_b * cache.atom_count + j]) * q_j;
  }
  const long double c =
      cache.real_pair_coefficients[site_a * cache.atom_count + site_a] -
      2.0L * cache.real_pair_coefficients[site_a * cache.atom_count + site_b] +
      cache.real_pair_coefficients[site_b * cache.atom_count + site_b];
  const long double real_denrg = 0.5L * kConvFact * (2.0L * delta * s + delta * delta * c);
  cache.current_real_energy += real_denrg;
  cache.stats.real_incremental_updates += 1;

  // 2. Point incremental (always 0 for swap, but we track it for completeness)
  cache.stats.point_incremental_updates += 1;

  // 3. Reciprocal incremental
  long double recip_denrg = 0.0L;
  for (std::size_t k = 0; k < cache.recip_weights.size(); ++k) {
    const long double old_cos = cache.current_cos_sums[k];
    const long double old_sin = cache.current_sin_sums[k];
    const long double dc = delta * (
        cache.recip_cos_coefficients[k * cache.atom_count + site_a] -
        cache.recip_cos_coefficients[k * cache.atom_count + site_b]);
    const long double ds = delta * (
        cache.recip_sin_coefficients[k * cache.atom_count + site_a] -
        cache.recip_sin_coefficients[k * cache.atom_count + site_b]);
    cache.current_cos_sums[k] = old_cos + dc;
    cache.current_sin_sums[k] = old_sin + ds;
    recip_denrg += cache.recip_weights[k] *
               (2.0L * old_cos * dc + dc * dc + 2.0L * old_sin * ds + ds * ds);
  }
  cache.current_recip_energy += recip_denrg;
  cache.stats.recip_incremental_updates += 1;

  std::swap(cache.current_oxidations[site_a], cache.current_oxidations[site_b]);
}

long double evaluate_site_update_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    const std::vector<std::size_t>& changed_indices,
    const std::vector<long double>& new_oxidations) {
  const auto delta = build_site_update_delta(
      cache, structure, changed_indices, new_oxidations, true);
  return delta.real + delta.point + delta.recip;
}

void commit_site_update_state(
    SwapEnergyCache& cache,
    StructureModel& structure,
    const std::vector<std::size_t>& changed_indices,
    const std::vector<std::string>& new_kinds,
    const std::vector<long double>& new_oxidations) {
  if (!new_kinds.empty() && new_kinds.size() != changed_indices.size()) {
    throw std::runtime_error(
        "new_kinds must be empty or have the same length as changed_indices");
  }

  const auto delta = build_site_update_delta(
      cache, structure, changed_indices, new_oxidations, false);
  if (delta.changed.empty()) {
    if (!new_kinds.empty()) {
      for (std::size_t pos = 0; pos < changed_indices.size(); ++pos) {
        const std::size_t i = changed_indices[pos];
        if (i >= structure.sites.size()) {
          throw std::runtime_error("changed site index is out of range");
        }
        structure.sites[i].kind = new_kinds[pos];
      }
    }
    return;
  }

  cache.current_real_energy += delta.real;
  cache.stats.real_incremental_updates += 1;

  cache.current_point_energy += delta.point;
  cache.stats.point_incremental_updates += 1;

  for (std::size_t k = 0; k < cache.recip_weights.size(); ++k) {
    cache.current_cos_sums[k] += delta.recip_dc[k];
    cache.current_sin_sums[k] += delta.recip_ds[k];
  }
  cache.current_recip_energy += delta.recip;
  cache.stats.recip_incremental_updates += 1;

  for (std::size_t pos = 0; pos < changed_indices.size(); ++pos) {
    const std::size_t i = changed_indices[pos];
    if (i >= structure.sites.size()) {
      throw std::runtime_error("changed site index is out of range");
    }
    structure.sites[i].oxidation = new_oxidations[pos];
    cache.current_oxidations[i] = new_oxidations[pos];
    if (!new_kinds.empty()) {
      structure.sites[i].kind = new_kinds[pos];
    }
  }
}

long double evaluate_recip_energy_via_fallback(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    long double real_energy,
    long double point_energy,
    long double* total_energy) {
  const ReadyModel view = ready_view_from_structure(structure, cache.rg_find_factor);
  cache.stats.full_evaluations += 1;
  cache.stats.recip_fallback_evaluations += 1;
  const auto eval = ess::evaluate_ready_energy(view, cache.rg_find_factor, cache.chop_level);
  if (total_energy != nullptr) {
    *total_energy = eval.total_e;
  }
  return eval.total_e - real_energy - point_energy;
}

long double evaluate_total_with_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure) {
  const long double cached_real = evaluate_real_energy_from_cache(cache, structure);
  const long double cached_point = evaluate_point_energy_from_cache(cache, structure);
  const long double cached_recip = evaluate_recip_energy_from_cache(cache, structure);
  return cached_real + cached_point + cached_recip;
}

long double evaluate_total_with_incremental_update(
    SwapEnergyCache& cache,
    const StructureModel& structure) {
  if (structure.sites.size() != cache.atom_count) {
    return evaluate_total_with_cache(cache, structure);
  }

  if (!cache.real_state_initialized ||
      !cache.point_state_initialized ||
      !cache.recip_state_initialized ||
      cache.current_oxidations.size() != cache.atom_count) {
    return evaluate_total_with_cache(cache, structure);
  }

  std::vector<std::size_t> changed;
  std::vector<long double> dq;
  changed.reserve(cache.atom_count);
  dq.reserve(cache.atom_count);
  for (std::size_t i = 0; i < cache.atom_count; ++i) {
    const long double delta = structure.sites[i].oxidation - cache.current_oxidations[i];
    if (delta != 0.0L) {
      changed.push_back(i);
      dq.push_back(delta);
    }
  }

  if (changed.empty()) {
    return cache.current_real_energy + cache.current_point_energy +
           cache.current_recip_energy;
  }

  long double real_delta = 0.0L;
  for (std::size_t a = 0; a < changed.size(); ++a) {
    const std::size_t i = changed[a];
    long double linear = 0.0L;
    for (std::size_t j = 0; j < cache.atom_count; ++j) {
      linear += cache.real_pair_coefficients[i * cache.atom_count + j] *
                cache.current_oxidations[j];
    }
    real_delta += 2.0L * dq[a] * linear;
  }
  for (std::size_t a = 0; a < changed.size(); ++a) {
    const std::size_t i = changed[a];
    for (std::size_t b = 0; b < changed.size(); ++b) {
      const std::size_t j = changed[b];
      real_delta += dq[a] * cache.real_pair_coefficients[i * cache.atom_count + j] * dq[b];
    }
  }
  cache.current_real_energy += 0.5L * kConvFact * real_delta;
  cache.stats.real_incremental_updates += 1;

  // Keep legacy ESS behavior: incremental updates apply mEwald_real and
  // mEwald_recip only, while the point term remains fixed to the first full
  // evaluation baseline.
  cache.stats.point_incremental_updates += 1;

  long double recip_delta = 0.0L;
  for (std::size_t k = 0; k < cache.recip_weights.size(); ++k) {
    const long double old_cos = cache.current_cos_sums[k];
    const long double old_sin = cache.current_sin_sums[k];
    long double dc = 0.0L;
    long double ds = 0.0L;
    for (std::size_t a = 0; a < changed.size(); ++a) {
      const std::size_t i = changed[a];
      dc += dq[a] * cache.recip_cos_coefficients[k * cache.atom_count + i];
      ds += dq[a] * cache.recip_sin_coefficients[k * cache.atom_count + i];
    }
    cache.current_cos_sums[k] = old_cos + dc;
    cache.current_sin_sums[k] = old_sin + ds;
    recip_delta += cache.recip_weights[k] *
                   (2.0L * old_cos * dc + dc * dc +
                    2.0L * old_sin * ds + ds * ds);
  }
  cache.current_recip_energy += recip_delta;
  cache.stats.recip_incremental_updates += 1;

  for (std::size_t a = 0; a < changed.size(); ++a) {
    const std::size_t i = changed[a];
    cache.current_oxidations[i] = structure.sites[i].oxidation;
  }
  cache.stats.diff_evaluations += 1;

  return cache.current_real_energy + cache.current_point_energy +
         cache.current_recip_energy;
}

}  // namespace ess::solve_steps
