#include "ess/solve_window_evaluation.hpp"

#include <limits>
#include <functional>
#include <unordered_map>
#include <vector>

#include "ess/ewald_shared.hpp"
#include "ess/solve_candidate_decode.hpp"
#include "ess/solve_swap_cache.hpp"
#include "ess/solve_window_materialize.hpp"

namespace ess::solve_steps {
namespace {

std::vector<ess::Site> expand_ready_sites(const ess::ReadyModel& ready) {
  std::vector<ess::Site> expanded;
  expanded.reserve(
      ready.atoms.size() * static_cast<std::size_t>(ready.supercell_expansion[0]) *
      static_cast<std::size_t>(ready.supercell_expansion[1]) *
      static_cast<std::size_t>(ready.supercell_expansion[2]));

  for (int i = 0; i < ready.supercell_expansion[0]; ++i) {
    for (int j = 0; j < ready.supercell_expansion[1]; ++j) {
      for (int k = 0; k < ready.supercell_expansion[2]; ++k) {
        for (const auto& atom : ready.atoms) {
          ess::Site site;
          site.kind = atom.kind;
          site.oxidation = atom.oxidation;
          site.x = (atom.x + static_cast<long double>(i)) /
                   static_cast<long double>(ready.supercell_expansion[0]);
          site.y = (atom.y + static_cast<long double>(j)) /
                   static_cast<long double>(ready.supercell_expansion[1]);
          site.z = (atom.z + static_cast<long double>(k)) /
                   static_cast<long double>(ready.supercell_expansion[2]);
          expanded.push_back(site);
        }
      }
    }
  }
  return expanded;
}

}  // namespace

ReadyModel build_candidate_ready(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    const CandidateWindowEntry& candidate) {
  std::vector<CandidateWindowEntry> recipe_candidates(ready.recipes.size());
  const int primary = search_space.primary_slice_window.recipe_index;
  if (primary >= 0 && primary < static_cast<int>(recipe_candidates.size())) {
    recipe_candidates[static_cast<std::size_t>(primary)] = candidate;
  }
  return build_candidate_ready(ready, search_space, recipe_candidates);
}

ReadyModel build_candidate_ready(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    const std::vector<CandidateWindowEntry>& recipe_candidates) {
  ess::ReadyModel candidate_ready;
  candidate_ready.lattice.a = {
      ready.supercell_expansion[0] * ready.lattice.a[0],
      ready.supercell_expansion[0] * ready.lattice.a[1],
      ready.supercell_expansion[0] * ready.lattice.a[2],
  };
  candidate_ready.lattice.b = {
      ready.supercell_expansion[1] * ready.lattice.b[0],
      ready.supercell_expansion[1] * ready.lattice.b[1],
      ready.supercell_expansion[1] * ready.lattice.b[2],
  };
  candidate_ready.lattice.c = {
      ready.supercell_expansion[2] * ready.lattice.c[0],
      ready.supercell_expansion[2] * ready.lattice.c[1],
      ready.supercell_expansion[2] * ready.lattice.c[2],
  };
  candidate_ready.supercell_expansion = {1, 1, 1};
  candidate_ready.rg_find_factor = ready.rg_find_factor;
  candidate_ready.chop_level = ready.chop_level;
  candidate_ready.output_prefix = ready.output_prefix;

  auto sites = expand_ready_sites(ready);
  std::unordered_map<std::string, std::vector<std::size_t>> bucket_indices;
  for (std::size_t i = 0; i < sites.size(); ++i) {
    bucket_indices[sites[i].kind].push_back(i);
  }

  for (std::size_t recipe_index = 0; recipe_index < ready.recipes.size(); ++recipe_index) {
    const auto& recipe = ready.recipes[recipe_index];
    auto it = bucket_indices.find(recipe.from);
    if (it == bucket_indices.end()) {
      continue;
    }

    std::vector<std::string> labels;
    if (recipe_index < recipe_candidates.size() &&
        !recipe_candidates[recipe_index].candidate_labels.empty()) {
      labels = recipe_candidates[recipe_index].candidate_labels;
    } else if (recipe_index < search_space.entries.size()) {
      labels = search_space.entries[recipe_index].first_candidate_labels;
    }

    std::unordered_map<std::string, long double> oxidation_map;
    oxidation_map[recipe.from] = recipe.oxidation;
    for (const auto& modification : recipe.modifications) {
      if (modification.number <= 0 || modification.to == "vac") {
        continue;
      }
      oxidation_map[modification.to] = modification.oxidation;
    }

    for (std::size_t idx = 0; idx < labels.size() && idx < it->second.size(); ++idx) {
      auto& site = sites[it->second[idx]];
      site.kind = labels[idx];
      site.oxidation = oxidation_map[labels[idx]];
    }
  }

  std::unordered_map<std::string, int> species_counts;
  std::vector<std::string> species_order;
  for (const auto& site : sites) {
    candidate_ready.atoms.push_back(ess::ReadyAtom{site.kind, site.oxidation, site.x, site.y, site.z});
    if (species_counts.find(site.kind) == species_counts.end()) {
      species_order.push_back(site.kind);
    }
    species_counts[site.kind] += 1;
  }
  for (const auto& kind : species_order) {
    candidate_ready.poscar_species_counts.push_back(ess::CompositionEntry{kind, species_counts[kind]});
  }

  return candidate_ready;
}

StructureModel structure_from_ready(const ReadyModel& ready) {
  StructureModel structure;
  structure.title = ready.output_prefix;
  structure.lattice = ready.lattice;
  structure.fractional_coordinates = true;
  for (const auto& atom : ready.atoms) {
    structure.sites.push_back(ess::Site{
        .kind = atom.kind,
        .x = atom.x,
        .y = atom.y,
        .z = atom.z,
        .oxidation = atom.oxidation,
    });
  }
  return structure;
}

WindowEvaluationSummary evaluate_primary_slice_window(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    int rg_find_factor,
    long double chop_level,
    bool save_memory) {
  WindowEvaluationSummary summary;
  summary.recipe_index = search_space.primary_slice_window.recipe_index;
  if (summary.recipe_index < 0) {
    return summary;
  }

  summary.local_e_min = std::numeric_limits<long double>::infinity();
  summary.local_e_max = -std::numeric_limits<long double>::infinity();

  for (const auto& candidate : search_space.primary_slice_window.candidates) {
    const auto candidate_ready = build_candidate_ready(ready, search_space, candidate);
    const auto energy = ess::evaluate_ready_energy(candidate_ready, rg_find_factor, chop_level);
    summary.local_energy_table.add(energy.total_e);
    summary.local_count_total += 1;

    if (energy.total_e < summary.local_e_min) {
      summary.local_e_min = energy.total_e;
      summary.local_best_candidate_index = candidate.candidate_index;
      summary.local_best_snapshot.structure = structure_from_ready(candidate_ready);
      summary.local_best_snapshot.energy = energy.total_e;
      summary.local_best_snapshot.label =
          ready.output_prefix + "::candidate_" +
          std::to_string(candidate.candidate_index);
      summary.local_best_snapshot_present = true;
    }
    if (energy.total_e > summary.local_e_max) {
      summary.local_e_max = energy.total_e;
      summary.local_worst_candidate_index = candidate.candidate_index;
      summary.local_worst_snapshot.structure = structure_from_ready(candidate_ready);
      summary.local_worst_snapshot.energy = energy.total_e;
      summary.local_worst_snapshot.label =
          ready.output_prefix + "::candidate_" +
          std::to_string(candidate.candidate_index);
      summary.local_worst_snapshot_present = true;
    }

    if (!save_memory) {
      WindowEvaluationEntry entry;
      entry.candidate_index = candidate.candidate_index;
      entry.energy = energy.total_e;
      entry.candidate_indices = candidate.candidate_indices;
      entry.candidate_labels = candidate.candidate_labels;
      entry.snapshot.structure = structure_from_ready(candidate_ready);
      entry.snapshot.energy = energy.total_e;
      entry.snapshot.label = ready.output_prefix + "::candidate_" +
                             std::to_string(candidate.candidate_index);
      summary.entries.push_back(std::move(entry));
    }
  }

  if (summary.local_count_total == 0) {
    summary.local_e_min = 0.0L;
    summary.local_e_max = 0.0L;
  }
  return summary;
}

WindowEvaluationSummary evaluate_nested_primary_slice_window(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    int rg_find_factor,
    long double chop_level,
    SwapEnergyCache* incremental_cache,
    bool save_memory,
    std::function<bool(int, unsigned long long, unsigned long long, unsigned long long)>
        progress_callback) {
  WindowEvaluationSummary summary;
  summary.recipe_index = search_space.primary_slice_window.recipe_index;
  if (summary.recipe_index < 0) {
    return summary;
  }

  summary.local_e_min = std::numeric_limits<long double>::infinity();
  summary.local_e_max = -std::numeric_limits<long double>::infinity();

  std::vector<CandidateWindowEntry> recipe_candidates(ready.recipes.size());
  const int primary = search_space.primary_slice_window.recipe_index;
  std::vector<int> secondary_recipe_indices;
  for (std::size_t i = 0; i < ready.recipes.size(); ++i) {
    if (static_cast<int>(i) != primary) {
      secondary_recipe_indices.push_back(static_cast<int>(i));
    }
  }

  auto evaluate_current = [&](const CandidateWindowEntry& primary_candidate) {
    const auto candidate_ready =
        build_candidate_ready(ready, search_space, recipe_candidates);
    const auto candidate_structure = structure_from_ready(candidate_ready);
    long double total_energy = 0.0L;
    long double ranking_energy = 0.0L;
    if (incremental_cache != nullptr) {
      total_energy =
          evaluate_total_with_incremental_update(*incremental_cache, candidate_structure);
      // Legacy ESS ranks and records adaptive-window candidates with the
      // incremental mEwald value after the first full evaluation.  Recomputing
      // a full Ewald here changes both runtime calibration (RunningIndexDelta)
      // and the candidate stream under wall-clock adaptive mode, so keep the
      // incremental value as the single source of truth for parity.
      ranking_energy = total_energy;
    } else {
      const auto energy =
          ess::evaluate_ready_energy(candidate_ready, rg_find_factor, chop_level);
      total_energy = energy.total_e;
      ranking_energy = energy.total_e;
    }

    summary.local_energy_table.add(total_energy);
    summary.local_count_total += 1;

    if (ranking_energy < summary.local_e_min) {
      summary.local_e_min = ranking_energy;
      summary.local_best_candidate_index = primary_candidate.candidate_index;
      summary.local_best_snapshot.structure = candidate_structure;
      summary.local_best_snapshot.energy = ranking_energy;
      summary.local_best_snapshot.label =
          ready.output_prefix + "::candidate_" +
          std::to_string(primary_candidate.candidate_index);
      summary.local_best_snapshot_present = true;
    }
    if (ranking_energy > summary.local_e_max) {
      summary.local_e_max = ranking_energy;
      summary.local_worst_candidate_index = primary_candidate.candidate_index;
      summary.local_worst_snapshot.structure = candidate_structure;
      summary.local_worst_snapshot.energy = ranking_energy;
      summary.local_worst_snapshot.label =
          ready.output_prefix + "::candidate_" +
          std::to_string(primary_candidate.candidate_index);
      summary.local_worst_snapshot_present = true;
    }

    if (!save_memory) {
      WindowEvaluationEntry entry;
      entry.candidate_index = primary_candidate.candidate_index;
      entry.energy = total_energy;
      entry.candidate_indices = primary_candidate.candidate_indices;
      entry.candidate_labels = primary_candidate.candidate_labels;
      entry.snapshot.structure = candidate_structure;
      entry.snapshot.energy = total_energy;
      entry.snapshot.label = ready.output_prefix + "::candidate_" +
                             std::to_string(primary_candidate.candidate_index);
      summary.entries.push_back(std::move(entry));
    }
  };

  unsigned long long nested_evaluated = 0;
  bool interrupted = false;
  auto maybe_emit_nested_progress = [&](int recipe_index,
                                        unsigned long long index,
                                        unsigned long long jobsize) {
    if (!progress_callback) {
      return true;
    }
    if (nested_evaluated == 0 || nested_evaluated == 1 ||
        nested_evaluated % 1000 == 0 || index == jobsize) {
      return progress_callback(recipe_index, index, jobsize, nested_evaluated);
    }
    return true;
  };

  std::function<void(std::size_t, const CandidateWindowEntry&)> visit_secondary;
  visit_secondary = [&](std::size_t depth,
                        const CandidateWindowEntry& primary_candidate) {
    if (interrupted) {
      return;
    }
    if (depth >= secondary_recipe_indices.size()) {
      evaluate_current(primary_candidate);
      return;
    }
    const int recipe_index = secondary_recipe_indices[depth];
    if (recipe_index < 0 || recipe_index >= static_cast<int>(ready.recipes.size()) ||
        recipe_index >= static_cast<int>(search_space.entries.size())) {
      visit_secondary(depth + 1, primary_candidate);
      return;
    }
    const auto& recipe = ready.recipes[static_cast<std::size_t>(recipe_index)];
    const auto& entry = search_space.entries[static_cast<std::size_t>(recipe_index)];
    const unsigned long long jobsize =
        entry.jobsize_u64 > 0 ? entry.jobsize_u64 : 1;
    if (!maybe_emit_nested_progress(recipe_index, 0, jobsize)) {
      interrupted = true;
      return;
    }
    for (unsigned long long index = 1; index <= jobsize; ++index) {
      if (interrupted) {
        return;
      }
      CandidateWindowEntry secondary;
      secondary.candidate_index = index;
      secondary.candidate_indices =
          decode_candidate_assignment_indices(recipe, secondary.candidate_index);
      secondary.candidate_labels =
          decode_candidate_assignment_labels(recipe, secondary.candidate_index);
      recipe_candidates[static_cast<std::size_t>(recipe_index)] =
          std::move(secondary);
      visit_secondary(depth + 1, primary_candidate);
      if (interrupted) {
        return;
      }
      nested_evaluated += 1;
      if (!maybe_emit_nested_progress(recipe_index, index, jobsize)) {
        interrupted = true;
        return;
      }
      if (index == std::numeric_limits<unsigned long long>::max()) {
        interrupted = true;
        return;
      }
    }
  };

  for (const auto& primary_candidate : search_space.primary_slice_window.candidates) {
    if (interrupted) {
      break;
    }
    recipe_candidates[static_cast<std::size_t>(primary)] = primary_candidate;
    visit_secondary(0, primary_candidate);
  }

  if (summary.local_count_total == 0) {
    summary.local_e_min = 0.0L;
    summary.local_e_max = 0.0L;
  }
  return summary;
}

}  // namespace ess::solve_steps
