#include "ess/ewald_shared.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <vector>

namespace ess {

namespace {

constexpr long double kPi = 3.14159265358979323846264338327950L;
constexpr long double kConvFact = 14.39964547058623L;
constexpr long double kBenchmarkW = 1.0L / 1.4142135623730950488L;
constexpr long double kBenchmarkAccFactor = 12.0L;

struct EvalAtom {
  long double fx = 0.0L;
  long double fy = 0.0L;
  long double fz = 0.0L;
  long double x = 0.0L;
  long double y = 0.0L;
  long double z = 0.0L;
  long double oxidation = 0.0L;
};

struct EvalCell {
  std::vector<EvalAtom> atoms;
  Lattice lattice;
  long double eight_points[8][3]{};
  long double volume = 0.0L;
};

struct KPoint {
  long double kx = 0.0L;
  long double ky = 0.0L;
  long double kz = 0.0L;
  long double norm_sq = 0.0L;
};

std::string write_with_precision(long double value, int precision) {
  std::ostringstream oss;
  oss.setf(std::ios::fixed);
  oss.precision(precision);
  oss << value;
  return oss.str();
}

long double vec_norm(const std::array<long double, 3>& v) {
  return std::sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

std::array<long double, 3> cart_from_frac(
    const Lattice& lattice,
    long double a,
    long double b,
    long double c) {
  return {
      lattice.a[0] * a + lattice.b[0] * b + lattice.c[0] * c,
      lattice.a[1] * a + lattice.b[1] * b + lattice.c[1] * c,
      lattice.a[2] * a + lattice.b[2] * b + lattice.c[2] * c,
  };
}

long double cell_volume(const Lattice& lattice) {
  long double volume = 0.0L;
  volume += lattice.a[0] * (lattice.b[1] * lattice.c[2] - lattice.b[2] * lattice.c[1]);
  volume -= lattice.a[1] * (lattice.b[0] * lattice.c[2] - lattice.b[2] * lattice.c[0]);
  volume += lattice.a[2] * (lattice.b[0] * lattice.c[1] - lattice.b[1] * lattice.c[0]);
  return volume;
}

void fill_eight_points(EvalCell& cell) {
  int point_count = 0;
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < 2; ++j) {
      for (int k = 0; k < 2; ++k) {
        for (int l = 0; l < 3; ++l) {
          cell.eight_points[point_count][l] =
              static_cast<long double>(i) * cell.lattice.a[l] +
              static_cast<long double>(j) * cell.lattice.b[l] +
              static_cast<long double>(k) * cell.lattice.c[l];
        }
        ++point_count;
      }
    }
  }
}

EvalCell build_supercell(const ReadyModel& ready) {
  EvalCell super_cell;
  super_cell.lattice.a = {
      ready.supercell_expansion[0] * ready.lattice.a[0],
      ready.supercell_expansion[0] * ready.lattice.a[1],
      ready.supercell_expansion[0] * ready.lattice.a[2],
  };
  super_cell.lattice.b = {
      ready.supercell_expansion[1] * ready.lattice.b[0],
      ready.supercell_expansion[1] * ready.lattice.b[1],
      ready.supercell_expansion[1] * ready.lattice.b[2],
  };
  super_cell.lattice.c = {
      ready.supercell_expansion[2] * ready.lattice.c[0],
      ready.supercell_expansion[2] * ready.lattice.c[1],
      ready.supercell_expansion[2] * ready.lattice.c[2],
  };
  for (int i = 0; i < ready.supercell_expansion[0]; ++i) {
    for (int j = 0; j < ready.supercell_expansion[1]; ++j) {
      for (int k = 0; k < ready.supercell_expansion[2]; ++k) {
        for (const auto& atom : ready.atoms) {
          EvalAtom obj;
          obj.oxidation = atom.oxidation;
          obj.fx = (atom.x + static_cast<long double>(i)) /
                   static_cast<long double>(ready.supercell_expansion[0]);
          obj.fy = (atom.y + static_cast<long double>(j)) /
                   static_cast<long double>(ready.supercell_expansion[1]);
          obj.fz = (atom.z + static_cast<long double>(k)) /
                   static_cast<long double>(ready.supercell_expansion[2]);
          const auto cart = cart_from_frac(super_cell.lattice, obj.fx, obj.fy, obj.fz);
          obj.x = cart[0];
          obj.y = cart[1];
          obj.z = cart[2];
          super_cell.atoms.push_back(obj);
        }
      }
    }
  }
  fill_eight_points(super_cell);
  super_cell.volume = cell_volume(super_cell.lattice);
  return super_cell;
}

std::array<long double, 3> reciprocal_a(const Lattice& lattice, long double volume) {
  return {
      (lattice.b[1] * lattice.c[2] - lattice.b[2] * lattice.c[1]) * 2.0L * kPi / volume,
      (-lattice.b[0] * lattice.c[2] + lattice.b[2] * lattice.c[0]) * 2.0L * kPi / volume,
      (lattice.b[0] * lattice.c[1] - lattice.b[1] * lattice.c[0]) * 2.0L * kPi / volume,
  };
}

std::array<long double, 3> reciprocal_b(const Lattice& lattice, long double volume) {
  return {
      (lattice.c[1] * lattice.a[2] - lattice.c[2] * lattice.a[1]) * 2.0L * kPi / volume,
      (-lattice.c[0] * lattice.a[2] + lattice.c[2] * lattice.a[0]) * 2.0L * kPi / volume,
      (lattice.c[0] * lattice.a[1] - lattice.c[1] * lattice.a[0]) * 2.0L * kPi / volume,
  };
}

std::array<long double, 3> reciprocal_c(const Lattice& lattice, long double volume) {
  return {
      (lattice.a[1] * lattice.b[2] - lattice.a[2] * lattice.b[1]) * 2.0L * kPi / volume,
      (-lattice.a[0] * lattice.b[2] + lattice.a[2] * lattice.b[0]) * 2.0L * kPi / volume,
      (lattice.a[0] * lattice.b[1] - lattice.a[1] * lattice.b[0]) * 2.0L * kPi / volume,
  };
}

int periodic_indicator(const EvalCell& super_cell, long double r_max, int rg_find_factor) {
  std::array<long double, 3> diag{
      super_cell.lattice.a[0] + super_cell.lattice.b[0] + super_cell.lattice.c[0],
      super_cell.lattice.a[1] + super_cell.lattice.b[1] + super_cell.lattice.c[1],
      super_cell.lattice.a[2] + super_cell.lattice.b[2] + super_cell.lattice.c[2],
  };
  int indicator = static_cast<int>(r_max / vec_norm(diag));
  if (indicator == 0) {
    indicator = 1;
  }
  return indicator * rg_find_factor;
}

std::vector<EvalCell> periodic_cells(
    const EvalCell& super_cell,
    long double r_max,
    int indicator) {
  std::vector<EvalCell> result;
  std::vector<int> seen_i;
  std::vector<int> seen_j;
  std::vector<int> seen_k;
  result.push_back(super_cell);
  seen_i.push_back(0);
  seen_j.push_back(0);
  seen_k.push_back(0);

  auto periodic_in_one_sector = [&](int x_increase, int y_increase, int z_increase) {
    for (int i = 0; std::abs(i) < indicator; i += x_increase) {
      for (int j = 0; std::abs(j) < indicator; j += y_increase) {
        for (int k = 0; std::abs(k) < indicator; k += z_increase) {
          bool initialized = true;
          for (std::size_t l = 0; l < seen_i.size(); ++l) {
            if (seen_i[l] == i && seen_j[l] == j && seen_k[l] == k) {
              initialized = false;
              break;
            }
          }
          if ((i == 0 && j == 0 && k == 0) || !initialized) {
            continue;
          }
          EvalCell cell;
          for (int l = 0; l < 8; ++l) {
            for (int m = 0; m < 3; ++m) {
              cell.eight_points[l][m] = super_cell.eight_points[l][m] +
                                        static_cast<long double>(i) * super_cell.lattice.a[m] +
                                        static_cast<long double>(j) * super_cell.lattice.b[m] +
                                        static_cast<long double>(k) * super_cell.lattice.c[m];
            }
          }
          long double rmin = 1.0e10L;
          for (int l = 0; l < 8; ++l) {
            for (int m = 0; m < 8; ++m) {
              const long double dx = cell.eight_points[l][0] - super_cell.eight_points[m][0];
              const long double dy = cell.eight_points[l][1] - super_cell.eight_points[m][1];
              const long double dz = cell.eight_points[l][2] - super_cell.eight_points[m][2];
              const long double dist = std::sqrt(dx * dx + dy * dy + dz * dz);
              if (dist < rmin) {
                rmin = dist;
              }
            }
          }
          if (rmin < r_max) {
            cell.volume = super_cell.volume;
            cell.lattice = super_cell.lattice;
            for (const auto& atom : super_cell.atoms) {
              EvalAtom obj = atom;
              obj.fx = atom.fx + static_cast<long double>(i);
              obj.fy = atom.fy + static_cast<long double>(j);
              obj.fz = atom.fz + static_cast<long double>(k);
              const auto cart = cart_from_frac(super_cell.lattice, obj.fx, obj.fy, obj.fz);
              obj.x = cart[0];
              obj.y = cart[1];
              obj.z = cart[2];
              cell.atoms.push_back(obj);
            }
            result.push_back(cell);
            seen_i.push_back(i);
            seen_j.push_back(j);
            seen_k.push_back(k);
          }
        }
      }
    }
  };

  periodic_in_one_sector(1, 1, 1);
  periodic_in_one_sector(1, 1, -1);
  periodic_in_one_sector(1, -1, 1);
  periodic_in_one_sector(1, -1, -1);
  periodic_in_one_sector(-1, 1, 1);
  periodic_in_one_sector(-1, 1, -1);
  periodic_in_one_sector(-1, -1, 1);
  periodic_in_one_sector(-1, -1, -1);
  return result;
}

std::vector<KPoint> relevant_kpoints(
    const std::array<long double, 3>& rcp_a,
    const std::array<long double, 3>& rcp_b,
    const std::array<long double, 3>& rcp_c,
    long double g_max,
    long double chop,
    int rg_find_factor) {
  long double rcp_min = std::min({vec_norm(rcp_a), vec_norm(rcp_b), vec_norm(rcp_c)});
  int g_count_factor = static_cast<int>(g_max / rcp_min);
  if (g_count_factor == 0) {
    g_count_factor = 1;
  }
  g_count_factor *= rg_find_factor;
  std::vector<KPoint> result;
  for (int ka = -g_count_factor; ka <= g_count_factor; ++ka) {
    for (int kb = -g_count_factor; kb <= g_count_factor; ++kb) {
      for (int kc = -g_count_factor; kc <= g_count_factor; ++kc) {
        const std::array<long double, 3> k_point{
            static_cast<long double>(ka) * rcp_a[0] + static_cast<long double>(kb) * rcp_b[0] + static_cast<long double>(kc) * rcp_c[0],
            static_cast<long double>(ka) * rcp_a[1] + static_cast<long double>(kb) * rcp_b[1] + static_cast<long double>(kc) * rcp_c[1],
            static_cast<long double>(ka) * rcp_a[2] + static_cast<long double>(kb) * rcp_b[2] + static_cast<long double>(kc) * rcp_c[2],
        };
        const long double norm = vec_norm(k_point);
        if (norm < g_max && norm > chop) {
          KPoint kp;
          kp.kx = k_point[0];
          kp.ky = k_point[1];
          kp.kz = k_point[2];
          kp.norm_sq = norm * norm;
          result.push_back(kp);
        }
      }
    }
  }
  return result;
}

}  // namespace

EwaldEvaluationResult evaluate_ready_energy(
    const ReadyModel& ready,
    int rg_find_factor,
    long double chop_level) {
  EwaldEvaluationResult result;
  result.rg_find_factor = rg_find_factor;
  result.nsite =
      ready.atoms.size() * static_cast<std::size_t>(ready.supercell_expansion[0]) *
      static_cast<std::size_t>(ready.supercell_expansion[1]) *
      static_cast<std::size_t>(ready.supercell_expansion[2]);

  const long double chop = std::pow(10.0L, -chop_level);
  const EvalCell super_cell = build_supercell(ready);
  const long double para_alpha_square =
      std::pow((static_cast<long double>(super_cell.atoms.size()) * kBenchmarkW /
                std::pow(super_cell.volume, 2.0L)),
               1.0L / 3.0L) *
      kPi;
  const long double para_alpha = std::sqrt(para_alpha_square);
  const long double log_factor = std::sqrt(std::log(std::pow(10.0L, kBenchmarkAccFactor)));
  const long double r_max = log_factor / para_alpha;
  const long double g_max = 2.0L * para_alpha * log_factor;

  const int indicator = periodic_indicator(super_cell, r_max, rg_find_factor);
  const auto super_cell_pr = periodic_cells(super_cell, r_max, indicator);
  const auto rcp_a = reciprocal_a(super_cell.lattice, super_cell.volume);
  const auto rcp_b = reciprocal_b(super_cell.lattice, super_cell.volume);
  const auto rcp_c = reciprocal_c(super_cell.lattice, super_cell.volume);
  const auto kpoints = relevant_kpoints(rcp_a, rcp_b, rcp_c, g_max, chop, rg_find_factor);

  long double ereal = 0.0L;
  for (const auto& atom_i : super_cell.atoms) {
    for (const auto& cell_j : super_cell_pr) {
      for (const auto& atom_k : cell_j.atoms) {
        const long double dx = atom_k.x - atom_i.x;
        const long double dy = atom_k.y - atom_i.y;
        const long double dz = atom_k.z - atom_i.z;
        const long double rij = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (rij > chop && rij < r_max) {
          ereal += std::erfc(para_alpha * rij) * atom_k.oxidation * atom_i.oxidation / rij;
        }
      }
    }
  }
  ereal *= 0.5L * kConvFact;

  long double epoint = 0.0L;
  for (const auto& atom : super_cell.atoms) {
    epoint += atom.oxidation * atom.oxidation;
  }
  epoint *= -kConvFact * para_alpha / std::sqrt(kPi);

  long double erecip = 0.0L;
  for (const auto& kp : kpoints) {
    const long double expval = std::exp(-kp.norm_sq / (4.0L * para_alpha_square));
    long double cosine_sum = 0.0L;
    long double sine_sum = 0.0L;
    for (const auto& atom : super_cell.atoms) {
      const long double gr = kp.kx * atom.x + kp.ky * atom.y + kp.kz * atom.z;
      cosine_sum += atom.oxidation * std::cos(gr);
      sine_sum += atom.oxidation * std::sin(gr);
    }
    erecip += expval * (cosine_sum * cosine_sum + sine_sum * sine_sum) / kp.norm_sq;
  }
  erecip *= (2.0L * kPi / super_cell.volume) * kConvFact;

  result.ereal = ereal;
  result.epoint = epoint;
  result.erecip = erecip;
  result.total_e = ereal + epoint + erecip;
  return result;
}

std::string format_ewald_log_line(
    int rg_find_factor,
    long double total_e,
    std::size_t nsite,
    const std::string& suffix) {
  return "RGFindFactor= " + std::to_string(rg_find_factor) + ": total_e= " +
         write_with_precision(total_e, 10) + " eV (" +
         write_with_precision(total_e / static_cast<long double>(nsite), 10) +
         " eV/atom, Nsite= " + std::to_string(nsite) + ")" + suffix;
}

}  // namespace ess
