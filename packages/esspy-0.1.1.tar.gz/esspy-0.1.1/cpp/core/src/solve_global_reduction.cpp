#include "ess/solve_global_reduction.hpp"

namespace ess::solve_steps {

LocalReductionScalars extract_local_reduction_scalars(
    const LocalReductionSummary& summary) {
  LocalReductionScalars scalars;
  scalars.rank = summary.rank;
  scalars.world_size = summary.world_size;
  scalars.primary_recipe_index = summary.primary_recipe_index;
  scalars.processed_chunks = summary.processed_chunks;
  scalars.processed_candidates = summary.processed_candidates;
  scalars.initial_offset = summary.initial_offset;
  scalars.next_offset = summary.next_offset;
  scalars.has_more = summary.has_more;
  scalars.exhaust_all = summary.exhaust_all;
  scalars.has_samples = summary.has_samples;
  scalars.local_e_min = summary.local_e_min;
  scalars.local_e_max = summary.local_e_max;
  scalars.local_best_candidate_index = summary.local_best_candidate_index;
  scalars.local_worst_candidate_index = summary.local_worst_candidate_index;
  scalars.local_de_min_swap = summary.local_de_min_swap;
  scalars.local_swap_count = summary.local_swap_count;
  scalars.local_best_structure_present = summary.local_best_structure_present;
  scalars.local_worst_structure_present =
      summary.local_worst_structure_present;
  scalars.local_energy_table = summary.local_energy_table;
  return scalars;
}

PartialGlobalReductionSummary combine_local_reduction_scalars(
    const std::vector<LocalReductionScalars>& inputs) {
  PartialGlobalReductionSummary result;
  result.world_size = static_cast<int>(inputs.size());

  bool seeded = false;
  bool primary_recipe_seeded = false;

  for (const auto& input : inputs) {
    result.total_processed_chunks +=
        static_cast<unsigned long long>(input.processed_chunks);
    result.total_processed_candidates +=
        static_cast<unsigned long long>(input.processed_candidates);
    result.global_energy_table.merge(input.local_energy_table);

    if (input.has_more) {
      result.any_has_more = true;
    }
    if (input.exhaust_all) {
      result.any_exhaust_all = true;
    }
    if (!input.has_samples) {
      continue;
    }
    ++result.contributing_ranks;
    result.total_de_min_swap += input.local_de_min_swap;
    result.total_swap_count += input.local_swap_count;

    if (!primary_recipe_seeded) {
      result.primary_recipe_index = input.primary_recipe_index;
      primary_recipe_seeded = true;
    } else if (result.primary_recipe_index != input.primary_recipe_index) {
      result.primary_recipe_consistent = false;
    }

    if (!seeded) {
      result.has_samples = true;
      result.global_e_min = input.local_e_min;
      result.global_e_max = input.local_e_max;
      result.which_rank_global_e_min = input.rank;
      result.which_rank_global_e_max = input.rank;
      result.global_e_min_candidate_index = input.local_best_candidate_index;
      result.global_e_max_candidate_index = input.local_worst_candidate_index;
      result.global_de_min_swap = input.local_de_min_swap;
      result.global_swap_count = input.local_swap_count;
      result.global_best_structure_present =
          input.local_best_structure_present;
      result.global_worst_structure_present =
          input.local_worst_structure_present;
      seeded = true;
      continue;
    }

    if (input.local_e_min < result.global_e_min) {
      result.global_e_min = input.local_e_min;
      result.which_rank_global_e_min = input.rank;
      result.global_e_min_candidate_index = input.local_best_candidate_index;
      result.global_de_min_swap = input.local_de_min_swap;
      result.global_swap_count = input.local_swap_count;
      result.global_best_structure_present =
          input.local_best_structure_present;
    }
    if (input.local_e_max > result.global_e_max) {
      result.global_e_max = input.local_e_max;
      result.which_rank_global_e_max = input.rank;
      result.global_e_max_candidate_index = input.local_worst_candidate_index;
      result.global_worst_structure_present =
          input.local_worst_structure_present;
    }
  }

  return result;
}

GlobalReductionSummary combine_local_reductions(
    const std::vector<LocalReductionSummary>& inputs) {
  GlobalReductionSummary result;
  result.world_size = static_cast<int>(inputs.size());

  bool seeded = false;
  bool primary_recipe_seeded = false;

  for (const auto& input : inputs) {
    result.total_processed_chunks +=
        static_cast<unsigned long long>(input.processed_chunks);
    result.total_processed_candidates +=
        static_cast<unsigned long long>(input.processed_candidates);
    result.global_energy_table.merge(input.local_energy_table);

    if (input.has_more) {
      result.any_has_more = true;
    }
    if (input.exhaust_all) {
      result.any_exhaust_all = true;
    }
    if (!input.has_samples) {
      continue;
    }
    ++result.contributing_ranks;
    result.total_de_min_swap += input.local_de_min_swap;
    result.total_swap_count += input.local_swap_count;

    if (!primary_recipe_seeded) {
      result.primary_recipe_index = input.primary_recipe_index;
      primary_recipe_seeded = true;
    } else if (result.primary_recipe_index != input.primary_recipe_index) {
      result.primary_recipe_consistent = false;
    }

    if (!seeded) {
      result.has_samples = true;
      result.global_e_min = input.local_e_min;
      result.global_e_max = input.local_e_max;
      result.which_rank_global_e_min = input.rank;
      result.which_rank_global_e_max = input.rank;
      result.global_e_min_candidate_index = input.local_best_candidate_index;
      result.global_e_max_candidate_index = input.local_worst_candidate_index;
      // Best-rank swap state follows the global-min owner.
      result.global_de_min_swap = input.local_de_min_swap;
      result.global_swap_count = input.local_swap_count;
      // Best/worst structure snapshots follow energy ownership.
      if (input.local_best_structure_present) {
        result.global_best_structure = input.local_best_structure;
        result.global_best_structure_present = true;
      }
      if (input.local_worst_structure_present) {
        result.global_worst_structure = input.local_worst_structure;
        result.global_worst_structure_present = true;
      }
      seeded = true;
      continue;
    }

    if (input.local_e_min < result.global_e_min) {
      result.global_e_min = input.local_e_min;
      result.which_rank_global_e_min = input.rank;
      result.global_e_min_candidate_index = input.local_best_candidate_index;
      result.global_de_min_swap = input.local_de_min_swap;
      result.global_swap_count = input.local_swap_count;
      if (input.local_best_structure_present) {
        result.global_best_structure = input.local_best_structure;
        result.global_best_structure_present = true;
      } else {
        result.global_best_structure = StructureModel{};
        result.global_best_structure_present = false;
      }
    }
    if (input.local_e_max > result.global_e_max) {
      result.global_e_max = input.local_e_max;
      result.which_rank_global_e_max = input.rank;
      result.global_e_max_candidate_index = input.local_worst_candidate_index;
      if (input.local_worst_structure_present) {
        result.global_worst_structure = input.local_worst_structure;
        result.global_worst_structure_present = true;
      } else {
        result.global_worst_structure = StructureModel{};
        result.global_worst_structure_present = false;
      }
    }
  }

  return result;
}

}  // namespace ess::solve_steps
