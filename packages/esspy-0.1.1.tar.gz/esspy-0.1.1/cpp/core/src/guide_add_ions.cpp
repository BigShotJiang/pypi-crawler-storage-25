#include "ess/guide_add_ions.hpp"

#include <cmath>
#include <cstdlib>
#include <sstream>
#include <stdexcept>

namespace ess::guide_steps {

namespace {

// Wraps `v` into the half-open interval [0, 1), matching the original
// Guider's folder() helper.
long double folder(long double v) {
  while (v < 0.0L) {
    v += 1.0L;
  }
  while (v >= 1.0L) {
    v -= 1.0L;
  }
  return v;
}

std::array<long double, 3> apply_wyc(
    const std::array<std::array<long double, 4>, 3>& matrix,
    long double a,
    long double b,
    long double c) {
  return {
      folder(matrix[0][0] * a + matrix[0][1] * b + matrix[0][2] * c +
             matrix[0][3]),
      folder(matrix[1][0] * a + matrix[1][1] * b + matrix[1][2] * c +
             matrix[1][3]),
      folder(matrix[2][0] * a + matrix[2][1] * b + matrix[2][2] * c +
             matrix[2][3]),
  };
}

std::array<long double, 3> to_cartesian(const Lattice& lattice,
                                        long double a,
                                        long double b,
                                        long double c) {
  return {
      lattice.a[0] * a + lattice.b[0] * b + lattice.c[0] * c,
      lattice.a[1] * a + lattice.b[1] * b + lattice.c[1] * c,
      lattice.a[2] * a + lattice.b[2] * b + lattice.c[2] * c,
  };
}

long double euclidean(const std::array<long double, 3>& p,
                      const std::array<long double, 3>& q) {
  const long double dx = p[0] - q[0];
  const long double dy = p[1] - q[1];
  const long double dz = p[2] - q[2];
  return std::sqrt(dx * dx + dy * dy + dz * dz);
}

long double weighted_norm(long double dx,
                          long double dy,
                          long double dz,
                          long double aw,
                          long double bw,
                          long double cw) {
  const long double wx = aw * dx;
  const long double wy = bw * dy;
  const long double wz = cw * dz;
  return std::sqrt(wx * wx + wy * wy + wz * wz);
}

}  // namespace

AddIonsResult compute_add_ions(
    const Lattice& lattice,
    const std::vector<std::array<long double, 3>>& existing_fractional,
    const std::vector<SymmetryOperation>& wyc_operations,
    int n_to_add,
    const AddIonsOptions& options) {
  AddIonsResult result;
  if (n_to_add <= 0) {
    return result;
  }
  if (wyc_operations.empty()) {
    throw std::runtime_error(
        "compute_add_ions requires at least one WYC operation");
  }

  std::srand(options.random_seed);

  long double neighbor_distance_max = -1.0e18L;
  std::vector<std::array<long double, 3>> chosen_random_seeds;
  std::vector<std::array<long double, 3>> chosen_fractional;
  std::vector<std::array<long double, 3>> chosen_cartesian;

  const long double aw = options.abc_weights[0];
  const long double bw = options.abc_weights[1];
  const long double cw = options.abc_weights[2];

  for (int iseed = 0; iseed < options.n_random_seeds; ++iseed) {
    long double weighted_total = 0.0L;
    long long neighbor_count = 0;

    std::vector<std::array<long double, 3>> random_pts;
    std::vector<std::array<long double, 3>> frac;
    std::vector<std::array<long double, 3>> cart;

    while (true) {
      const long double a =
          folder(static_cast<long double>(std::rand()) / RAND_MAX);
      const long double b =
          folder(static_cast<long double>(std::rand()) / RAND_MAX);
      const long double c =
          folder(static_cast<long double>(std::rand()) / RAND_MAX);
      const std::size_t before = frac.size();

      for (std::size_t iw = 0; iw < wyc_operations.size(); ++iw) {
        const auto vfrac =
            apply_wyc(wyc_operations[iw].matrix, a, b, c);
        const auto vcart =
            to_cartesian(lattice, vfrac[0], vfrac[1], vfrac[2]);

        bool addable = true;
        if (iw == 0 && !frac.empty()) {
          long double min_dist = 1.0e18L;
          for (int ii = -1; ii <= 1; ++ii) {
            for (int jj = -1; jj <= 1; ++jj) {
              for (int kk = -1; kk <= 1; ++kk) {
                for (std::size_t jxs = 0; jxs < frac.size(); ++jxs) {
                  const auto pcart = to_cartesian(
                      lattice,
                      frac[jxs][0] + static_cast<long double>(ii),
                      frac[jxs][1] + static_cast<long double>(jj),
                      frac[jxs][2] + static_cast<long double>(kk));
                  const long double d = euclidean(vcart, pcart);
                  if (d < min_dist) {
                    min_dist = d;
                  }
                }
              }
            }
          }
          if (min_dist < options.wyc_identity_length) {
            addable = false;
          }
        }

        if (!addable) {
          break;
        }

        frac.push_back(vfrac);
        cart.push_back(vcart);

        if (static_cast<int>(frac.size()) >= n_to_add) {
          break;
        }
      }

      if (frac.size() > before) {
        random_pts.push_back({a, b, c});
      }

      if (static_cast<int>(frac.size()) >= n_to_add) {
        break;
      }
    }

    for (std::size_t ixs = 0; ixs < frac.size(); ++ixs) {
      std::vector<long double> dists;
      std::vector<long double> dists_w;
      long double min_dist = 1.0e18L;
      for (int ii = -1; ii <= 1; ++ii) {
        for (int jj = -1; jj <= 1; ++jj) {
          for (int kk = -1; kk <= 1; ++kk) {
            for (const auto& existing : existing_fractional) {
              const auto pcart = to_cartesian(
                  lattice,
                  existing[0] + static_cast<long double>(ii),
                  existing[1] + static_cast<long double>(jj),
                  existing[2] + static_cast<long double>(kk));
              const long double dx = cart[ixs][0] - pcart[0];
              const long double dy = cart[ixs][1] - pcart[1];
              const long double dz = cart[ixs][2] - pcart[2];
              const long double d = std::sqrt(dx * dx + dy * dy + dz * dz);
              dists.push_back(d);
              dists_w.push_back(weighted_norm(dx, dy, dz, aw, bw, cw));
              if (d < min_dist) {
                min_dist = d;
              }
            }
            for (std::size_t jxs = 0; jxs < frac.size(); ++jxs) {
              if (jxs == ixs) {
                continue;
              }
              const auto pcart = to_cartesian(
                  lattice,
                  frac[jxs][0] + static_cast<long double>(ii),
                  frac[jxs][1] + static_cast<long double>(jj),
                  frac[jxs][2] + static_cast<long double>(kk));
              const long double dx = cart[ixs][0] - pcart[0];
              const long double dy = cart[ixs][1] - pcart[1];
              const long double dz = cart[ixs][2] - pcart[2];
              const long double d = std::sqrt(dx * dx + dy * dy + dz * dz);
              dists.push_back(d);
              dists_w.push_back(weighted_norm(dx, dy, dz, aw, bw, cw));
              if (d < min_dist) {
                min_dist = d;
              }
            }
          }
        }
      }
      for (std::size_t i = 0; i < dists.size(); ++i) {
        if (dists[i] <= min_dist + options.shell_width) {
          weighted_total += dists_w[i];
          ++neighbor_count;
        }
      }
    }

    if (neighbor_count > 0) {
      weighted_total /= static_cast<long double>(neighbor_count);
    }

    if (weighted_total > neighbor_distance_max) {
      neighbor_distance_max = weighted_total;
      chosen_random_seeds = random_pts;
      chosen_fractional = frac;
      chosen_cartesian = cart;
      std::ostringstream oss;
      oss << iseed << "/" << options.n_random_seeds << " "
          << neighbor_distance_max;
      result.log.push_back(oss.str());
    }
  }

  result.added_sites.reserve(chosen_fractional.size());
  for (std::size_t i = 0; i < chosen_fractional.size(); ++i) {
    AddedSite site;
    site.fractional = chosen_fractional[i];
    site.cartesian = chosen_cartesian[i];
    result.added_sites.push_back(site);
  }
  result.chosen_random_seeds = chosen_random_seeds;
  result.neighbor_distance_max = neighbor_distance_max;
  return result;
}

}  // namespace ess::guide_steps
