#include "ess/solve_slice_window.hpp"

#include <algorithm>
#include <limits>

#include "ess/solve_candidate_decode.hpp"

namespace ess::solve_steps {

PrimarySliceWindow analyze_primary_slice_window(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    unsigned long long segment_offset,
    int max_candidates) {
  PrimarySliceWindow window;
  window.recipe_index = search_space.work_slice.primary_recipe_index;
  if (window.recipe_index < 0 ||
      window.recipe_index >= static_cast<int>(ready.recipes.size()) ||
      window.recipe_index >=
          static_cast<int>(search_space.work_slice.recipe_ranges.size())) {
    return window;
  }

  const auto& recipe = ready.recipes[static_cast<std::size_t>(window.recipe_index)];
  const auto& range = search_space.work_slice.recipe_ranges[static_cast<std::size_t>(
      window.recipe_index)];
  const unsigned long long full_start_index = range.start + 1;
  window.end_index = range.end + 1;

  const unsigned long long available =
      (range.end >= range.start ? range.end - range.start + 1 : 0);
  window.available_count = available;
  const unsigned long long clamped_offset = std::min(segment_offset, available);
  window.requested_offset = clamped_offset;
  window.start_index = full_start_index + clamped_offset;
  const unsigned long long remaining = (available > clamped_offset ? available - clamped_offset : 0);
  const unsigned long long count = std::min<unsigned long long>(
      static_cast<unsigned long long>(std::max(0, max_candidates)), remaining);
  window.decoded_count = count;
  window.next_offset = clamped_offset + count;
  window.has_more = window.next_offset < available;

  for (unsigned long long offset = 0; offset < count; ++offset) {
    CandidateWindowEntry entry;
    if (offset > std::numeric_limits<unsigned long long>::max() - window.start_index) {
      break;
    }
    entry.candidate_index = window.start_index + offset;
    entry.candidate_indices =
        decode_candidate_assignment_indices(recipe, entry.candidate_index);
    entry.candidate_labels =
        decode_candidate_assignment_labels(recipe, entry.candidate_index);
    window.candidates.push_back(std::move(entry));
    if (offset == std::numeric_limits<unsigned long long>::max()) {
      break;
    }
  }

  return window;
}

}  // namespace ess::solve_steps
