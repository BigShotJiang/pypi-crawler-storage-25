#include "ess/solve_search_space.hpp"

#include <cmath>
#include <limits>
#include <vector>

#include "ess/solve_candidate_decode.hpp"

namespace ess::solve_steps {

namespace {

long double log10_multinomial(int n, const std::vector<int>& parts) {
  long double acc = std::lgammal(static_cast<long double>(n) + 1.0L);
  for (const int part : parts) {
    acc -= std::lgammal(static_cast<long double>(part) + 1.0L);
  }
  return acc / std::log(10.0L);
}

}  // namespace

SearchSpaceSummary analyze_search_space(const ReadyModel& ready) {
  SearchSpaceSummary summary;
  long double best_log10 = -1.0L;

  for (std::size_t index = 0; index < ready.recipes.size(); ++index) {
    const auto& recipe = ready.recipes[index];

    SearchSpaceEntry entry;
    entry.from = recipe.from;
    entry.random_pickup = recipe.random_pickup;
    entry.random_pickup_trial = recipe.random_pickup_trial;
    entry.first_candidate_indices = decode_candidate_assignment_indices(recipe, 1);
    entry.first_candidate_labels = decode_first_candidate_labels(recipe);

    int assigned_positive = 0;
    std::vector<int> multinomial_parts;
    for (const auto& modification : recipe.modifications) {
      if (modification.number <= 0 || modification.to == "vac") {
        continue;
      }
      assigned_positive += modification.number;
      multinomial_parts.push_back(modification.number);
      entry.assigned_counts.push_back(
          CompositionEntry{modification.to, modification.number});
    }

    entry.unchanged_count = recipe.random_pickup - assigned_positive;
    if (entry.unchanged_count > 0) {
      multinomial_parts.push_back(entry.unchanged_count);
      entry.assigned_counts.push_back(
          CompositionEntry{recipe.from, entry.unchanged_count});
    }

    if (!multinomial_parts.empty()) {
      entry.candidate_count_log10 =
          log10_multinomial(recipe.random_pickup, multinomial_parts);
      entry.jobsize_u64 = multinomial_u64(recipe.random_pickup, multinomial_parts);
      entry.jobsize_ld = multinomial_ld(recipe.random_pickup, multinomial_parts);
      const long double u64_limit = static_cast<long double>(
          std::numeric_limits<unsigned long long>::max());
      entry.jobsize_saturated =
          !std::isfinite(static_cast<double>(entry.jobsize_ld)) ||
          entry.jobsize_ld >= u64_limit ||
          entry.jobsize_u64 == std::numeric_limits<unsigned long long>::max();
    }
    summary.total_candidate_count_log10 += entry.candidate_count_log10;
    if (entry.candidate_count_log10 > best_log10) {
      best_log10 = entry.candidate_count_log10;
      summary.primary_recipe_index = static_cast<int>(index);
    }
    summary.entries.push_back(entry);
  }

  return summary;
}

}  // namespace ess::solve_steps
