#include "ess/add_sites_mc.hpp"

#include <algorithm>
#include <cmath>
#include <random>
#include <sstream>
#include <stdexcept>
#include <utility>

#include "ess/ewald_shared.hpp"

namespace ess::solve_steps {
namespace {

constexpr long double kHugeDistance = 1.0e18L;

std::array<long double, 3> frac_to_cart(
    const Lattice& lattice,
    long double fx,
    long double fy,
    long double fz) {
  return {
      lattice.a[0] * fx + lattice.b[0] * fy + lattice.c[0] * fz,
      lattice.a[1] * fx + lattice.b[1] * fy + lattice.c[1] * fz,
      lattice.a[2] * fx + lattice.b[2] * fy + lattice.c[2] * fz,
  };
}

long double periodic_distance_cart(
    const Lattice& lattice,
    const std::array<long double, 3>& p_frac,
    const std::array<long double, 3>& q_frac) {
  long double best = kHugeDistance;
  for (int ia = -1; ia <= 1; ++ia) {
    for (int ib = -1; ib <= 1; ++ib) {
      for (int ic = -1; ic <= 1; ++ic) {
        const auto q_cart = frac_to_cart(
            lattice,
            q_frac[0] + static_cast<long double>(ia),
            q_frac[1] + static_cast<long double>(ib),
            q_frac[2] + static_cast<long double>(ic));
        const auto p_cart = frac_to_cart(lattice, p_frac[0], p_frac[1], p_frac[2]);
        const long double dx = p_cart[0] - q_cart[0];
        const long double dy = p_cart[1] - q_cart[1];
        const long double dz = p_cart[2] - q_cart[2];
        const long double dist = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < best) {
          best = dist;
        }
      }
    }
  }
  return best;
}

std::vector<std::array<long double, 3>> generate_mesh_points(
    const std::array<long double, 3>& add_meshes) {
  for (int axis = 0; axis < 3; ++axis) {
    if (add_meshes[axis] <= 0.0L || add_meshes[axis] > 1.0L) {
      throw std::runtime_error("AddMeshes values must be in (0, 1]");
    }
  }

  const int na = std::max(1, static_cast<int>(std::floor(1.0L / add_meshes[0] + 1.0e-12L)));
  const int nb = std::max(1, static_cast<int>(std::floor(1.0L / add_meshes[1] + 1.0e-12L)));
  const int nc = std::max(1, static_cast<int>(std::floor(1.0L / add_meshes[2] + 1.0e-12L)));

  std::vector<std::array<long double, 3>> points;
  points.reserve(static_cast<std::size_t>(na * nb * nc));
  for (int ia = 0; ia < na; ++ia) {
    for (int ib = 0; ib < nb; ++ib) {
      for (int ic = 0; ic < nc; ++ic) {
        points.push_back({
            ia * add_meshes[0],
            ib * add_meshes[1],
            ic * add_meshes[2],
        });
      }
    }
  }
  return points;
}

ReadyModel ready_from_structure(const StructureModel& structure, int rg_find_factor) {
  ReadyModel ready;
  ready.lattice = structure.lattice;
  ready.supercell_expansion = {1, 1, 1};
  ready.rg_find_factor = rg_find_factor;
  ready.output_prefix = structure.title;
  ready.atoms.reserve(structure.sites.size());
  for (const auto& site : structure.sites) {
    ReadyAtom atom;
    atom.kind = site.kind;
    atom.oxidation = site.oxidation;
    atom.x = site.x;
    atom.y = site.y;
    atom.z = site.z;
    ready.atoms.push_back(atom);
  }
  return ready;
}

bool satisfies_neighbor_constraints(
    const StructureModel& trial,
    const Site& candidate,
    const AddSitesKindSpec& kind_spec) {
  const std::array<long double, 3> candidate_frac{candidate.x, candidate.y, candidate.z};
  for (const auto& neighbor : kind_spec.neighbor_kinds) {
    bool found = false;
    for (const auto& site : trial.sites) {
      if (site.kind != neighbor.kind) {
        continue;
      }
      const std::array<long double, 3> site_frac{site.x, site.y, site.z};
      const long double dist = periodic_distance_cart(trial.lattice, candidate_frac, site_frac);
      const bool min_ok = dist >= neighbor.dist_min;
      const bool max_ok = neighbor.dist_max > 10000.0L || dist <= neighbor.dist_max;
      if (min_ok && max_ok) {
        found = true;
        break;
      }
    }
    if (!found) {
      return false;
    }
  }
  return true;
}

std::vector<int> select_neighbor_targets(
    const StructureModel& trial,
    const Site& candidate,
    const AddSitesKindSpec& kind_spec) {
  const std::array<long double, 3> candidate_frac{candidate.x, candidate.y, candidate.z};
  std::vector<int> targets;
  targets.reserve(kind_spec.neighbor_kinds.size());

  for (const auto& neighbor : kind_spec.neighbor_kinds) {
    int best_index = -1;
    long double best_dist = kHugeDistance;
    for (std::size_t index = 0; index < trial.sites.size(); ++index) {
      const auto& site = trial.sites[index];
      if (site.kind != neighbor.kind) {
        continue;
      }
      const std::array<long double, 3> site_frac{site.x, site.y, site.z};
      const long double dist = periodic_distance_cart(trial.lattice, candidate_frac, site_frac);
      const bool min_ok = dist >= neighbor.dist_min;
      const bool max_ok = neighbor.dist_max > 10000.0L || dist <= neighbor.dist_max;
      if (!(min_ok && max_ok)) {
        continue;
      }
      if (dist < best_dist) {
        best_dist = dist;
        best_index = static_cast<int>(index);
      }
    }
    if (best_index == -1) {
      return {};
    }
    targets.push_back(best_index);
  }

  return targets;
}

bool satisfies_min_added_distance(
    const StructureModel& trial,
    const Site& candidate,
    long double min_dist,
  std::size_t base_atom_count) {
  if (min_dist <= 0.0L) {
    return true;
  }
  const std::array<long double, 3> candidate_frac{candidate.x, candidate.y, candidate.z};
  for (std::size_t index = base_atom_count; index < trial.sites.size(); ++index) {
    const auto& site = trial.sites[index];
    const std::array<long double, 3> site_frac{site.x, site.y, site.z};
    const long double dist = periodic_distance_cart(trial.lattice, candidate_frac, site_frac);
    if (dist < min_dist) {
      return false;
    }
  }
  return true;
}

struct SecondaryNeighborStream {
  std::vector<int> next_targets;
  std::vector<long double> next_doxidations;
};

struct OxidationTargetStream {
  int target = -1;
  long double dox = 0.0L;
  int next_target = -1;
  long double next_dox = 0.0L;
};

SecondaryNeighborStream build_secondary_neighbor_stream(
    const StructureModel& base_structure,
    const AddSitesKindSpec& add_kind) {
  SecondaryNeighborStream stream;
  stream.next_targets.assign(base_structure.sites.size(), -1);
  stream.next_doxidations.assign(base_structure.sites.size(), 0.0L);

  if (add_kind.neighbor_kinds.size() < 2) {
    return stream;
  }

  const auto& primary_neighbor = add_kind.neighbor_kinds.front();
  std::vector<std::pair<std::string, long double>> secondary_candidates;
  for (std::size_t index = 1; index < add_kind.neighbor_kinds.size(); ++index) {
    const auto& neighbor = add_kind.neighbor_kinds[index];
    if (std::fabs(neighbor.doxidation) <= 1.0e-15L) {
      continue;
    }
    secondary_candidates.push_back({neighbor.kind, neighbor.doxidation});
  }
  if (secondary_candidates.empty()) {
    return stream;
  }

  for (std::size_t iatom = 0; iatom < base_structure.sites.size(); ++iatom) {
    const auto& source_site = base_structure.sites[iatom];
    if (source_site.kind != primary_neighbor.kind) {
      continue;
    }

    const std::array<long double, 3> source_frac{
        source_site.x,
        source_site.y,
        source_site.z,
    };

    int best_target = -1;
    long double best_target_dox = 0.0L;
    long double best_dist = kHugeDistance;

    for (std::size_t jatom = 0; jatom < base_structure.sites.size(); ++jatom) {
      if (iatom == jatom) {
        continue;
      }
      const auto& target_site = base_structure.sites[jatom];
      for (const auto& secondary : secondary_candidates) {
        if (target_site.kind != secondary.first) {
          continue;
        }
        const std::array<long double, 3> target_frac{
            target_site.x,
            target_site.y,
            target_site.z,
        };
        const long double dist = periodic_distance_cart(
            base_structure.lattice,
            source_frac,
            target_frac);
        if (dist < best_dist) {
          best_dist = dist;
          best_target = static_cast<int>(jatom);
          best_target_dox = secondary.second;
        }
        break;
      }
    }

    stream.next_targets[iatom] = best_target;
    stream.next_doxidations[iatom] = best_target_dox;
  }

  return stream;
}

std::vector<OxidationTargetStream> build_candidate_target_streams(
    const std::vector<int>& neighbor_targets,
    const AddSitesKindSpec& add_kind,
    const SecondaryNeighborStream& secondary_stream) {
  std::vector<OxidationTargetStream> streams;
  streams.reserve(add_kind.neighbor_kinds.size());
  for (std::size_t neighbor_index = 0; neighbor_index < add_kind.neighbor_kinds.size();
       ++neighbor_index) {
    OxidationTargetStream stream;
    stream.target = neighbor_targets[neighbor_index];
    stream.dox = add_kind.neighbor_kinds[neighbor_index].doxidation;
    if (stream.target >= 0 &&
        static_cast<std::size_t>(stream.target) < secondary_stream.next_targets.size()) {
      stream.next_target =
          secondary_stream.next_targets[static_cast<std::size_t>(stream.target)];
      stream.next_dox =
          secondary_stream.next_doxidations[static_cast<std::size_t>(stream.target)];
    }
    streams.push_back(stream);
  }
  return streams;
}

bool exceeds_double_count_limit(
    const std::vector<OxidationTargetStream>& existing,
    const std::vector<OxidationTargetStream>& candidate,
    int double_count_limit) {
  int double_count = 0;
  for (const auto& pending : candidate) {
    if (pending.target == -1) {
      continue;
    }
    for (const auto& prior : existing) {
      if (std::fabs(pending.dox) > 1.0e-15L && prior.target == pending.target) {
        double_count += 1;
      }
      if (std::fabs(pending.next_dox) > 1.0e-15L &&
          pending.next_target != -1 &&
          prior.next_target == pending.next_target) {
        double_count += 1;
      }
      if (double_count > double_count_limit) {
        return true;
      }
    }
  }
  return false;
}

void apply_target_streams(
    StructureModel* trial,
    const std::vector<OxidationTargetStream>& streams) {
  for (const auto& stream : streams) {
    if (stream.target == -1) {
      continue;
    }
    if (std::fabs(stream.dox) > 1.0e-15L) {
      (*trial).sites[static_cast<std::size_t>(stream.target)].oxidation += stream.dox;
    }
    if (stream.next_target != -1 && std::fabs(stream.next_dox) > 1.0e-15L) {
      (*trial).sites[static_cast<std::size_t>(stream.next_target)].oxidation += stream.next_dox;
    }
  }
}

}  // namespace

AddSitesMonteCarloResult run_add_sites_monte_carlo(
    const StructureModel& base_structure,
    const AddSitesMonteCarloSpec& spec,
    const AddSitesMonteCarloOptions& options) {
  AddSitesMonteCarloResult result;
  if (spec.added_kinds.empty() || spec.n_monte_carlo == 0) {
    result.best_structure = base_structure;
    result.success = true;
    return result;
  }

  auto mesh_points = generate_mesh_points(spec.add_meshes);
  std::mt19937 rng(options.random_seed);
  std::vector<std::size_t> point_indices(mesh_points.size(), 0);
  for (std::size_t i = 0; i < point_indices.size(); ++i) {
    point_indices[i] = i;
  }

  const std::size_t base_atom_count = base_structure.sites.size();
  const int n_trials = std::abs(spec.n_monte_carlo);
  long double best_energy = kHugeDistance;
  bool have_best = false;
  std::vector<SecondaryNeighborStream> secondary_streams;
  secondary_streams.reserve(spec.added_kinds.size());
  for (const auto& add_kind : spec.added_kinds) {
    secondary_streams.push_back(build_secondary_neighbor_stream(base_structure, add_kind));
  }

  for (int trial_index = 0; trial_index < n_trials; ++trial_index) {
    result.attempted_trials += 1;
    std::shuffle(point_indices.begin(), point_indices.end(), rng);

    StructureModel trial = base_structure;
    bool trial_ok = true;
    std::vector<OxidationTargetStream> committed_streams;

    for (std::size_t add_kind_index = 0; add_kind_index < spec.added_kinds.size();
         ++add_kind_index) {
      const auto& add_kind = spec.added_kinds[add_kind_index];
      int placed = 0;
      int double_count_limit = 0;
      int relaxation_round = 0;

      while (placed < add_kind.n_added) {
        std::shuffle(point_indices.begin(), point_indices.end(), rng);
        bool placed_this_round = false;
        bool blocked_by_double_count = false;

        for (std::size_t pick = 0; pick < point_indices.size(); ++pick) {
          const auto& frac = mesh_points[point_indices[pick]];
          Site candidate;
          candidate.kind = add_kind.kind;
          candidate.oxidation = add_kind.oxidation;
          candidate.x = frac[0];
          candidate.y = frac[1];
          candidate.z = frac[2];

          if (!satisfies_neighbor_constraints(trial, candidate, add_kind)) {
            continue;
          }
          const auto neighbor_targets = select_neighbor_targets(trial, candidate, add_kind);
          if (neighbor_targets.empty() && !add_kind.neighbor_kinds.empty()) {
            continue;
          }
          if (!satisfies_min_added_distance(
                  trial,
                  candidate,
                  spec.min_distance_between_added_sites,
                  base_atom_count)) {
            continue;
          }

          const auto candidate_streams = build_candidate_target_streams(
              neighbor_targets, add_kind, secondary_streams[add_kind_index]);
          if (placed >= 1 &&
              exceeds_double_count_limit(
                  committed_streams,
                  candidate_streams,
                  double_count_limit)) {
            blocked_by_double_count = true;
            continue;
          }

          trial.sites.push_back(candidate);
          apply_target_streams(&trial, candidate_streams);
          committed_streams.insert(
              committed_streams.end(),
              candidate_streams.begin(),
              candidate_streams.end());
          placed += 1;
          placed_this_round = true;
          break;
        }

        if (placed_this_round) {
          continue;
        }
        if (blocked_by_double_count) {
          double_count_limit += 1;
          relaxation_round += 1;
          if (relaxation_round > 1000) {
            break;
          }
          continue;
        }
        break;
      }
      if (placed != add_kind.n_added) {
        trial_ok = false;
        break;
      }
    }

    if (!trial_ok) {
      continue;
    }

    result.accepted_trials += 1;
    const auto eval = evaluate_ready_energy(
        ready_from_structure(trial, options.rg_find_factor),
        options.rg_find_factor,
        options.chop_level);
    if (!have_best || eval.total_e < best_energy) {
      best_energy = eval.total_e;
      result.best_structure = trial;
      result.best_energy = best_energy;
      have_best = true;
    }

    if (spec.monte_carlo_monitor_index > 0 &&
        (trial_index == 0 || ((trial_index + 1) % spec.monte_carlo_monitor_index == 0))) {
      std::ostringstream oss;
      oss << "trial=" << (trial_index + 1)
          << " accepted=" << result.accepted_trials
          << " best_energy=" << static_cast<double>(best_energy);
      result.log.push_back(oss.str());
    }
  }

  if (!have_best) {
    result.best_structure = base_structure;
    result.best_energy = kHugeDistance;
    result.success = false;
    result.log.push_back("no_feasible_added_site_configuration");
    return result;
  }

  result.success = true;
  return result;
}

}  // namespace ess::solve_steps
