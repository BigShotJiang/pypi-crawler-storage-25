#pragma once

#include "ess/core.hpp"

namespace ess::solve_steps {

ReadyModel build_candidate_ready(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    const CandidateWindowEntry& candidate);

ReadyModel build_candidate_ready(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    const std::vector<CandidateWindowEntry>& recipe_candidates);

StructureModel structure_from_ready(const ReadyModel& ready);

}  // namespace ess::solve_steps
