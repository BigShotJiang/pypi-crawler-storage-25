#pragma once

#include <cstddef>
#include <vector>

#include "ess/core.hpp"

namespace ess::solve_steps {

StructureModel materialize_canonical_structure(const ReadyModel& ready);

// Same as materialize_canonical_structure(), but also returns the per-recipe
// supercell-site pools that the legacy ESS swap loop iterates over. Each
// element of `recipe_pools` corresponds (by index) to `ready.recipes`. The
// pool lists every supercell-expanded site whose original (pre-canonical-
// mutation) kind matched `recipe.from`. Sites that are unrelated to any
// recipe are not included in any pool.
struct CanonicalStructureWithPools {
  StructureModel structure;
  std::vector<std::vector<std::size_t>> recipe_pools;
};

CanonicalStructureWithPools materialize_canonical_structure_with_pools(
    const ReadyModel& ready);

}  // namespace ess::solve_steps
