#pragma once

#include <string>

#include "ess/core.hpp"

namespace ess::guide_steps {

// Knobs that the original Guider's save_outputlines() bakes into the ready
// file before write_basic emits it. Most fields are hard-coded in the
// original code (`ChopLevel 8`, `verbose 0`, `Swap 1`, etc.); the only
// guider-input value that is actually carried through is the user-provided
// TargetCPUTimeInSec, which becomes `RunningIndexDelta = -TargetCPUTimeInSec`.
// The remaining knobs are exposed here as overridable defaults so the
// extracted writer matches the original output for current golden cases
// without locking us out of future tuning.
struct ReadyFileWriteOptions {
  int target_cpu_time_sec = 600;
  // If non-zero, write this value directly to RunningIndexDelta.
  // If zero, keep legacy Guider behavior: RunningIndexDelta = -target_cpu_time_sec.
  long long running_index_delta = 0;
  int chop_level = 8;
  int verbose = 0;
  int create_recipe_strict_mode = 0;
  int print_stablest_unstablest = 1;
  int running_index_monitor = 10000;
  int swap = 1;
  int max_swap = 100;
  std::string restart_recipe_filename = "none";
  int n_energy_table_line = 1;
  std::string energy_table_default_line = "-1000000000000000000000000000 0 X";
  std::string output_prefix_suffix = "_001";
};

// Reproduces the body that the original Guider's save_outputlines() builds
// and that write_basic() emits to basic_properties_EwaldSolidSolution.ready.txt
// (without the optional AddedKind block, which is still pending extraction).
//
// The output uses '\n' line endings to match the original binary-mode write,
// and the lattice / atom-config / oxidation precisions match the original
// (10 fractional digits for coordinates and lattice vectors, 3 fractional
// digits for oxidations).
std::string write_ready_file_text(
    const ReadyModel& ready,
    const ReadyFileWriteOptions& options);

}  // namespace ess::guide_steps
