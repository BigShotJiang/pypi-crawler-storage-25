#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess::solve_steps {

struct SwapEnergyCacheStats {
  int full_evaluations = 0;
  int diff_evaluations = 0;
  int real_cache_evaluations = 0;
  int real_incremental_updates = 0;
  int point_cache_evaluations = 0;
  int point_incremental_updates = 0;
  int recip_cache_evaluations = 0;
  int recip_state_rebuilds = 0;
  int recip_incremental_updates = 0;
  int recip_fallback_evaluations = 0;
  bool diff_cache_enabled = false;
  int real_pair_terms = 0;
  int recip_kpoint_terms = 0;
};

struct SwapEnergyCache {
  int rg_find_factor = 1;
  long double chop_level = 8.0L;
  std::size_t atom_count = 0;
  long double point_prefactor = 0.0L;
  std::vector<long double> real_pair_coefficients;
  std::vector<long double> recip_weights;
  std::vector<long double> recip_cos_coefficients;
  std::vector<long double> recip_sin_coefficients;
  std::vector<long double> current_oxidations;

  long double current_real_energy = 0.0L;
  bool real_state_initialized = false;

  long double current_point_energy = 0.0L;
  bool point_state_initialized = false;

  std::vector<long double> current_cos_sums;
  std::vector<long double> current_sin_sums;
  long double current_recip_energy = 0.0L;
  bool recip_state_initialized = false;

  SwapEnergyCacheStats stats;
};

SwapEnergyCache create_swap_energy_cache(
    const StructureModel& structure,
    int rg_find_factor,
    long double chop_level);

ReadyModel ready_view_from_structure(const StructureModel& structure,
                                     int rg_find_factor);

long double evaluate_real_energy_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure);

long double evaluate_swap_real_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b);

long double evaluate_point_energy_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure);

long double evaluate_swap_point_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b);

long double evaluate_recip_energy_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure);

long double evaluate_swap_recip_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b);

void commit_swap_state(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    std::size_t site_a,
    std::size_t site_b);

long double evaluate_site_update_delta_from_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    const std::vector<std::size_t>& changed_indices,
    const std::vector<long double>& new_oxidations);

void commit_site_update_state(
    SwapEnergyCache& cache,
    StructureModel& structure,
    const std::vector<std::size_t>& changed_indices,
    const std::vector<std::string>& new_kinds,
    const std::vector<long double>& new_oxidations);

long double evaluate_recip_energy_via_fallback(
    SwapEnergyCache& cache,
    const StructureModel& structure,
    long double real_energy,
    long double point_energy,
    long double* total_energy = nullptr);

long double evaluate_total_with_cache(
    SwapEnergyCache& cache,
    const StructureModel& structure);

long double evaluate_total_with_incremental_update(
    SwapEnergyCache& cache,
    const StructureModel& structure);

}  // namespace ess::solve_steps
