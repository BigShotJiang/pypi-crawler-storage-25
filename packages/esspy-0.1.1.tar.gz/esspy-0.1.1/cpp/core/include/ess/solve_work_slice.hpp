#pragma once

#include "ess/core.hpp"

namespace ess::solve_steps {

WorkSliceSummary analyze_work_slice(
    const SearchSpaceSummary& search_space,
    const ParallelRuntimeOptions& runtime);

}  // namespace ess::solve_steps
