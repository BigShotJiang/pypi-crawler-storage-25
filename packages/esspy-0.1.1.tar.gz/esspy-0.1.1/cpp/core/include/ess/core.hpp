#pragma once

#include <array>
#include <functional>
#include <string>
#include <vector>

namespace ess {

struct Lattice {
  std::array<long double, 3> a{0.0L, 0.0L, 0.0L};
  std::array<long double, 3> b{0.0L, 0.0L, 0.0L};
  std::array<long double, 3> c{0.0L, 0.0L, 0.0L};
};

struct Site {
  std::string kind;
  long double x = 0.0L;
  long double y = 0.0L;
  long double z = 0.0L;
  long double oxidation = 0.0L;
};

struct StructureModel {
  std::string title;
  Lattice lattice;
  std::vector<Site> sites;
  bool fractional_coordinates = true;
};

struct CompositionEntry {
  std::string kind;
  int count = 0;
};

struct CompositionModel {
  std::vector<CompositionEntry> entries;
  int n_target_sites = 0;
  std::string number_fixed_at = "O";
};

struct ChargeEntry {
  std::string kind;
  long double oxidation = 0.0L;
};

struct ChargeMap {
  std::vector<ChargeEntry> values;
};

struct RecipeSpec {
  std::string from;
  std::vector<std::string> to;
};

struct RecipeAssignment {
  std::string from;
  std::vector<CompositionEntry> assigned_counts;
};

struct SymmetryOperation {
  std::array<std::array<long double, 4>, 3> matrix{{
      {{1.0L, 0.0L, 0.0L, 0.0L}},
      {{0.0L, 1.0L, 0.0L, 0.0L}},
      {{0.0L, 0.0L, 1.0L, 0.0L}},
  }};
};

struct SymmetryModel {
  int space_group = 1;
  std::vector<SymmetryOperation> wyc_operations;
  bool from_spglib = false;
};

struct GuideOptions {
  int n_random_seeds = 2000;
  long double shell_width = 1.0L;
  long double wyc_identity_length = 0.2L;
  std::array<long double, 3> abc_weights{2.0L, 2.0L, 1.0L};
  long double chop_level = 100.0L;
  int target_cpu_time_sec = 600;
  bool strict_no_added_sites = false;
  bool skip_rg_optimization = false;
  bool skip_ewald_evaluation = false;
  int fixed_rg_find_factor = -1;
};

struct ParallelRuntimeOptions {
  bool use_mpi = false;
  int world_size = 1;
  int rank = 0;
};

struct SolveProgressEvent {
  std::string stage;
  int rank = 0;
  int world_size = 1;
  unsigned long long processed_chunks = 0;
  unsigned long long processed_candidates = 0;
  unsigned long long next_offset = 0;
  unsigned long long available_count = 0;
  bool has_more = false;
  long double local_e_min = 0.0L;
  long double local_e_max = 0.0L;
  int monitoring_index = -1;
  unsigned long long adaptive_stride = 0;
  unsigned long long active_stride = 1;
  int secondary_recipe_index = -1;
  unsigned long long secondary_index = 0;
  unsigned long long secondary_jobsize = 0;
  long double elapsed_sec = 0.0L;
  StructureModel best_structure;
  bool best_structure_present = false;
};

struct DynamicChunkDecision {
  unsigned long long offset = 0;
  int chunk_limit = 0;
  bool has_more = true;
};

struct GuideInput {
  StructureModel structure;
  CompositionModel composition;
  ChargeMap charges;
  std::vector<RecipeSpec> recipes;
  bool has_supercell_expansion = false;
  std::array<int, 3> supercell_expansion{1, 1, 1};
  SymmetryModel symmetry;
  GuideOptions options;
};

struct ReadyAtom {
  std::string kind;
  long double oxidation = 0.0L;
  long double x = 0.0L;
  long double y = 0.0L;
  long double z = 0.0L;
};

struct ReadyRecipeModification {
  std::string to;
  long double oxidation = 0.0L;
  int number = 0;
};

struct ReadyRecipe {
  std::string from;
  long double oxidation = 0.0L;
  int random_pickup = 0;
  int random_pickup_trial = 0;
  std::vector<ReadyRecipeModification> modifications;
};

struct ReadyModel {
  Lattice lattice;
  std::vector<ReadyAtom> atoms;
  std::vector<CompositionEntry> poscar_species_counts;
  std::array<int, 3> supercell_expansion{1, 1, 1};
  int rg_find_factor = 1;
  long double chop_level = 8.0L;
  std::string output_prefix;
  std::vector<ReadyRecipe> recipes;
};

struct GuideDiagnostics {
  int n_atom_config = 0;
  std::array<int, 3> supercell_expansion{1, 1, 1};
  int rg_find_factor = 1;
  std::vector<RecipeAssignment> resolved_assignments;
  std::vector<std::string> messages;
};

struct GuideResult {
  ReadyModel ready;
  GuideDiagnostics diagnostics;
};

struct SolveOptions {
  bool verbose = false;
  bool create_recipe_strict_mode = false;
  bool print_stablest_unstablest = false;
  long long running_index_delta = 10000;
  int running_index_monitor = 10000;
  unsigned long long local_enumeration_offset = 0;
  int local_enumeration_limit = 32;
  int local_enumeration_max_chunks = 1;
  unsigned long long local_enumeration_stride = 1;
  bool swap = true;
  int max_swap = 2;
  std::string restart_recipe_filename;
  // If true, the solver will continue enumerating until the entire search 
  // space slice is exhausted, even if it exceeds max_chunks.
  bool enumeration_exhaust_all = false;
  // If true, window evaluation will NOT store every candidate's labels/indices 
  // in memory, keeping only the best/worst and updating statistics.
  bool enumeration_save_memory = false;
  // If true, synchronize adaptive RunningIndexDelta updates through the
  // pybind runtime hook when available.  This is off by default to keep
  // serial/native callers independent from MPI.
  bool mpi_adaptive_stride_sync = false;
  // Experimental MPI scheduler hook.
  // NOTE: current core does not own MPI communicator control-flow; this flag
  // is a forward-compatible toggle for dynamic chunk allocation logic.
  bool mpi_dynamic_chunking = false;
  unsigned long long mpi_chunk_min = 512;
  unsigned long long mpi_chunk_max = 20000;
  int mpi_scheduler_heartbeat = 16;
  // Optional externally synchronized adaptive strides.  Python MPI
  // orchestration uses these to precompute rank-0 RunningIndexDelta updates
  // and then run every rank with the same values, matching legacy MPI_Bcast
  // semantics without requiring the C++ core to link against MPI.
  unsigned long long adaptive_stride_override_9 = 0;
  unsigned long long adaptive_stride_override_19 = 0;
  // Legacy adaptive stride estimates the cost of one primary-index step by
  // scaling the measured probe time by secondary recipe job sizes.  That
  // matches the original solver for legacy parity, but it can overestimate
  // badly when the probe already evaluated the full nested secondary space.
  // Disable this to use the measured full-window cost directly.
  bool adaptive_stride_scale_secondary = true;
  // Integration of `compute_swap_loop` into `solve()`.
  bool swap_loop_enabled = true;
  // 1 = best improvement, 2 = first improvement
  int swap_loop_mode = 1;
  // Where the swap loop starts:
  //   0=canonical, 1=window best, 2=window worst, 3=caller-provided sites
  int swap_loop_seed_source = 1;
  std::vector<Site> swap_loop_starting_sites;
  std::function<bool()> cancel_requested;
  // Optional runtime hook used by Python/mpi4py orchestration to mirror the
  // legacy MPI_Bcast of adaptive RunningIndexDelta from rank 0 at monitoring
  // indices 9 and 19.  The first argument is the monitoring index and the
  // second is this rank's locally estimated stride.  The return value is the
  // synchronized stride to use on every rank.
  std::function<unsigned long long(int, unsigned long long)>
      synchronize_adaptive_stride;
  std::function<DynamicChunkDecision(
      unsigned long long, int, bool, unsigned long long)>
      synchronize_dynamic_chunk;
  bool progress_include_best_structure = false;
  std::function<void(const SolveProgressEvent&)> progress_callback;
};

struct SolveInput {
  ReadyModel ready;
  SolveOptions options;
  ParallelRuntimeOptions runtime;
};

struct EnergySummary {
  long double global_e_min = 0.0L;
  long double global_e_max = 0.0L;
  long double total_cpu_time = 0.0L;
  unsigned long long global_count_total = 0;
};

struct SearchSpaceEntry {
  std::string from;
  int random_pickup = 0;
  int random_pickup_trial = 0;
  int unchanged_count = 0;
  std::vector<CompositionEntry> assigned_counts;
  unsigned long long jobsize_u64 = 0;
  long double jobsize_ld = 0.0L;
  bool jobsize_saturated = false;
  std::vector<int> first_candidate_indices;
  std::vector<std::string> first_candidate_labels;
  long double candidate_count_log10 = 0.0L;
};

struct WorkSliceRange {
  int recipe_index = -1;
  unsigned long long start = 0;
  unsigned long long end = 0;
};

struct WorkSliceSummary {
  bool integer_job = true;
  int primary_recipe_index = -1;
  int world_size = 1;
  int rank = 0;
  bool has_saturated_jobsize = false;
  std::vector<WorkSliceRange> recipe_ranges;
};

struct FirstEnumerationState {
  int recipe_index = -1;
  unsigned long long candidate_index = 0;
  std::vector<int> candidate_indices;
  std::vector<std::string> candidate_labels;
};

struct CandidateWindowEntry {
  unsigned long long candidate_index = 0;
  std::vector<int> candidate_indices;
  std::vector<std::string> candidate_labels;
};

struct PrimarySliceWindow {
  int recipe_index = -1;
  unsigned long long start_index = 0;
  unsigned long long end_index = 0;
  unsigned long long available_count = 0;
  unsigned long long decoded_count = 0;
  unsigned long long requested_offset = 0;
  unsigned long long next_offset = 0;
  bool has_more = false;
  bool next_decode_uses_xps0 = true;
  std::vector<CandidateWindowEntry> candidates;
};

struct SearchSpaceSummary {
  std::vector<SearchSpaceEntry> entries;
  int primary_recipe_index = -1;
  long double total_candidate_count_log10 = 0.0L;
  WorkSliceSummary work_slice;
  FirstEnumerationState first_enumeration;
  PrimarySliceWindow primary_slice_window;
};

struct StructureSnapshot {
  StructureModel structure;
  long double energy = 0.0L;
  std::string label;
};

struct WindowEvaluationEntry {
  unsigned long long candidate_index = 0;
  long double energy = 0.0L;
  std::vector<int> candidate_indices;
  std::vector<std::string> candidate_labels;
  StructureSnapshot snapshot;
};

struct EnergyTable {
  unsigned long long count = 0;
  long double sum_e = 0.0L;
  long double sum_e2 = 0.0L;
  long double min_e = 0.0L;
  long double max_e = 0.0L;

  void add(long double e) {
    if (count == 0) {
      min_e = e;
      max_e = e;
    } else {
      if (e < min_e) min_e = e;
      if (e > max_e) max_e = e;
    }
    sum_e += e;
    sum_e2 += e * e;
    count++;
  }

  void merge(const EnergyTable& other) {
    if (other.count == 0) return;
    if (count == 0) {
      *this = other;
      return;
    }
    if (other.min_e < min_e) min_e = other.min_e;
    if (other.max_e > max_e) max_e = other.max_e;
    sum_e += other.sum_e;
    sum_e2 += other.sum_e2;
    count += other.count;
  }
};

struct WindowEvaluationSummary {
  int recipe_index = -1;
  long double local_e_min = 0.0L;
  long double local_e_max = 0.0L;
  unsigned long long local_best_candidate_index = 0;
  unsigned long long local_worst_candidate_index = 0;
  unsigned long long local_count_total = 0;
  EnergyTable local_energy_table;
  StructureSnapshot local_best_snapshot;
  StructureSnapshot local_worst_snapshot;
  bool local_best_snapshot_present = false;
  bool local_worst_snapshot_present = false;
  std::vector<WindowEvaluationEntry> entries;
};

struct LocalEnumerationLoopState {
  unsigned long long initial_offset = 0;
  int chunk_limit = 0;
  int max_chunks = 1;
  bool exhaust_all = false;
  int processed_chunks = 0;
  unsigned long long processed_candidates = 0;
  unsigned long long next_offset = 0;
  bool has_more = false;
};

struct LocalReductionSummary {
  int rank = 0;
  int world_size = 1;
  int primary_recipe_index = -1;
  int processed_chunks = 0;
  unsigned long long processed_candidates = 0;
  unsigned long long initial_offset = 0;
  unsigned long long next_offset = 0;
  bool has_more = false;
  bool exhaust_all = false;
  bool has_samples = false;
  long double local_e_min = 0.0L;
  long double local_e_max = 0.0L;
  unsigned long long local_best_candidate_index = 0;
  unsigned long long local_worst_candidate_index = 0;
  long double local_de_min_swap = 0.0L;
  int local_swap_count = 0;
  StructureModel local_best_structure;
  StructureModel local_worst_structure;
  bool local_best_structure_present = false;
  bool local_worst_structure_present = false;
  EnergyTable local_energy_table;
};

struct SolveResult {
  EnergySummary summary;
  SearchSpaceSummary search_space;
  WindowEvaluationSummary window_evaluation;
  LocalEnumerationLoopState local_enumeration_loop;
  LocalReductionSummary local_reduction;
  StructureSnapshot best;
  StructureSnapshot worst;
  EnergyTable energy_table;
  std::vector<std::string> messages;
};

struct RunInput {
  GuideInput guide;
  SolveOptions solve;
  ParallelRuntimeOptions runtime;
};

struct RunResult {
  GuideResult guide;
  SolveResult solve;
};

GuideResult guide(const GuideInput& input);
SolveResult solve(const SolveInput& input);
RunResult run(const RunInput& input);

}  // namespace ess
