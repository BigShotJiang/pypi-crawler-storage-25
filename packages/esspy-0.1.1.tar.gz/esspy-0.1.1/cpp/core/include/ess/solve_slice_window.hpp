#pragma once

#include "ess/core.hpp"

namespace ess::solve_steps {

PrimarySliceWindow analyze_primary_slice_window(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    unsigned long long segment_offset = 0,
    int max_candidates = 32);

}  // namespace ess::solve_steps
