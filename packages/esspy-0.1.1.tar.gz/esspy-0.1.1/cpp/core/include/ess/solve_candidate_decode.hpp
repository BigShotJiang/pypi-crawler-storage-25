#pragma once

#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess::solve_steps {

struct LegacyCommonDecodeCache {
  bool enabled = false;
  std::vector<int> common_prefix;
  std::vector<long long> sigma_common;
  long long ni_common_0 = 0;
  long long ni_common_1 = 0;
  long long dindex_common = 0;
};

std::vector<int> decode_candidate_assignment_indices(
    const ReadyRecipe& recipe,
    unsigned long long index);

void decode_candidate_assignment_indices_legacy_into(
    const ReadyRecipe& recipe,
    unsigned long long index,
    std::vector<int>& indices);

LegacyCommonDecodeCache build_legacy_common_decode_cache(
    const ReadyRecipe& recipe,
    unsigned long long range_start_index,
    unsigned long long range_end_index);

void decode_candidate_assignment_indices_legacy_with_common_into(
    const ReadyRecipe& recipe,
    unsigned long long index,
    const LegacyCommonDecodeCache& cache,
    std::vector<int>& indices);

std::vector<int> decode_candidate_assignment_indices_ld(
    const ReadyRecipe& recipe,
    long double index);

std::vector<std::string> decode_candidate_assignment_labels(
    const ReadyRecipe& recipe,
    unsigned long long index);

std::vector<std::string> decode_candidate_assignment_labels_from_indices(
    const ReadyRecipe& recipe,
    const std::vector<int>& indices);

std::vector<std::string> decode_first_candidate_labels(
    const ReadyRecipe& recipe);

unsigned long long multinomial_u64(int n, const std::vector<int>& parts);
long double multinomial_ld(int n, const std::vector<int>& parts);

}  // namespace ess::solve_steps
