#pragma once

#include "ess/core.hpp"
#include "ess/ewald_shared.hpp"

namespace ess::guide_steps {

struct EwaldOptimizationResult : public ess::EwaldEvaluationResult {
  std::vector<std::string> log;
};

EwaldOptimizationResult optimize_rg_find_factor(
    const ReadyModel& ready,
    const GuideOptions& options);

}  // namespace ess::guide_steps
