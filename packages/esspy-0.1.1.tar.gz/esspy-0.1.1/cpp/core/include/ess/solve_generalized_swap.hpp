#pragma once

#include <cstddef>
#include <functional>
#include <string>
#include <vector>

#include "ess/core.hpp"
#include "ess/solve_swap_cache.hpp"

namespace ess::solve_steps {

struct GeneralizedSiteGroupRule {
  std::string name;
  std::string source_kind;
  std::vector<std::string> allowed;
};

struct GeneralizedChargeEntry {
  std::string kind;
  std::string site_group;
  long double oxidation = 0.0L;
};

struct GeneralizedSwapOptions {
  int number_starts = 20;
  int start_index_offset = 0;
  int start_index_stride = 1;
  int max_steps_per_start = 100;
  int random_shuffle_steps = 256;
  int rg_find_factor = 1;
  long double chop_level = 8.0L;
  long double improvement_tol = 1.0e-12L;
  long double time_budget_sec = 0.0L;
  unsigned int seed = 0;
  std::vector<GeneralizedSiteGroupRule> site_groups;
  std::vector<ChargeEntry> element_charges;
  std::vector<GeneralizedChargeEntry> site_charges;
  std::function<bool()> cancel_requested;
};

struct GeneralizedSwapMove {
  int start_index = 0;
  int step = 0;
  std::size_t site_a = 0;
  std::size_t site_b = 0;
  std::string group_a;
  std::string group_b;
  std::string kind_a_before;
  std::string kind_b_before;
  long double denrg = 0.0L;
  long double energy_after = 0.0L;
};

struct GeneralizedSwapStartSummary {
  int start_index = 0;
  long double initial_energy = 0.0L;
  long double final_energy = 0.0L;
  int accepted_moves = 0;
};

struct GeneralizedSwapResult {
  StructureModel best_structure;
  long double initial_energy = 0.0L;
  long double best_energy = 0.0L;
  int starts_evaluated = 0;
  int accepted_moves = 0;
  bool stopped_by_no_improvement = false;
  SwapEnergyCacheStats cache_stats;
  std::vector<std::string> group_by_site;
  std::vector<GeneralizedSwapStartSummary> starts;
  std::vector<GeneralizedSwapMove> accepted;
  std::vector<std::string> log;
};

GeneralizedSwapResult compute_generalized_swap_loop(
    const ReadyModel& ready,
    const GeneralizedSwapOptions& options);

}  // namespace ess::solve_steps
