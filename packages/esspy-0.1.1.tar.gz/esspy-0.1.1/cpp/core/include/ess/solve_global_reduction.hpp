#pragma once

#include <vector>

#include "ess/core.hpp"

namespace ess::solve_steps {

// Aggregate of one or more LocalReductionSummary instances. This is the
// reducer-side counterpart of LocalReductionSummary: it captures exactly
// the post-MPI_Allgather/MPI_Allreduce information that the original ESS
// solver derives in postprocess() (see EwaldSolidSolution.cpp::postprocess
// at line 4063 onward).
//
// Design rules for this reducer:
//
//   1. Only inputs with `has_samples == true` contribute to the global
//      extrema. Inputs with `has_samples == false` are counted toward
//      `world_size` but are otherwise treated as the empty contribution.
//
//   2. Global extrema use the same strict `<` / `>` comparison rule as the
//      original ESS, so on a tie the lowest-rank contributing input wins
//      ownership.
//
//   3. `combine_local_reductions(...)` is homomorphic on a single input:
//      passing one `LocalReductionSummary` produces a
//      `GlobalReductionSummary` whose extrema and ownership match that
//      single input's extrema and rank exactly. This makes the new core's
//      single-rank `solve()` result feed directly into the same reducer
//      that future MPI ranks will use, with no special-casing on the
//      caller side.
//
//   4. The reducer never inspects `processed_chunks` semantics across
//      ranks beyond summing them. It also does not enforce that all
//      contributing inputs agree on `primary_recipe_index`; mismatches are
//      flagged via `primary_recipe_consistent`.
struct GlobalReductionSummary {
  int world_size = 0;
  int contributing_ranks = 0;
  unsigned long long total_processed_candidates = 0;
  unsigned long long total_processed_chunks = 0;
  bool any_has_more = false;
  bool any_exhaust_all = false;
  bool has_samples = false;

  long double global_e_min = 0.0L;
  long double global_e_max = 0.0L;
  int which_rank_global_e_min = -1;
  int which_rank_global_e_max = -1;
  unsigned long long global_e_min_candidate_index = 0;
  unsigned long long global_e_max_candidate_index = 0;

  // Best-rank-borne swap accumulators. The legacy ESS solver pulls these
  // straight from whichever rank holds the global minimum at the time of
  // postprocess(), so a tie that hands ownership to a different rank also
  // hands these values over. They stay at 0 / 0 until the swap loop is
  // actually extracted into the new core.
  long double global_de_min_swap = 0.0L;
  int global_swap_count = 0;
  // Aggregate swap statistics across all contributing ranks. These are not
  // used by the legacy single-line "SWAP:" report but are exposed here so
  // future tooling can show the world-wide swap effort independently from
  // the best-rank ownership.
  long double total_de_min_swap = 0.0L;
  int total_swap_count = 0;

  // Best/worst structure snapshots transferred along with energy
  // ownership. `global_best_structure` is whichever contributing rank's
  // `local_best_structure` is currently holding the global minimum;
  // `global_worst_structure` follows the global maximum analogously.
  // `*_present` mirrors the per-rank presence flag so consumers can
  // distinguish "no sample on this side of the world" from "best/worst
  // is the canonical / zero-initialised structure".
  StructureModel global_best_structure;
  StructureModel global_worst_structure;
  bool global_best_structure_present = false;
  bool global_worst_structure_present = false;

  int primary_recipe_index = -1;
  bool primary_recipe_consistent = true;
  EnergyTable global_energy_table;
};

GlobalReductionSummary combine_local_reductions(
    const std::vector<LocalReductionSummary>& inputs);

// MPI-friendly wire decomposition of `LocalReductionSummary`. Holds only
// the fixed-size, POD-friendly scalars that need to travel across every
// rank in an `MPI_Allgather`. The variable-length best/worst structure
// snapshots are intentionally excluded; they are sent separately by
// whichever rank ends up holding the global extremum, after all ranks
// have agreed on ownership.
struct LocalReductionScalars {
  int rank = 0;
  int world_size = 1;
  int primary_recipe_index = -1;
  int processed_chunks = 0;
  unsigned long long processed_candidates = 0;
  unsigned long long initial_offset = 0;
  unsigned long long next_offset = 0;
  bool has_more = false;
  bool exhaust_all = false;
  bool has_samples = false;
  long double local_e_min = 0.0L;
  long double local_e_max = 0.0L;
  unsigned long long local_best_candidate_index = 0;
  unsigned long long local_worst_candidate_index = 0;
  long double local_de_min_swap = 0.0L;
  int local_swap_count = 0;
  bool local_best_structure_present = false;
  bool local_worst_structure_present = false;
  EnergyTable local_energy_table;
};

// Reducer output that only carries the scalar half of
// GlobalReductionSummary. The structure fields are deliberately left
// out so the caller can fill them separately after the structure
// broadcast step. `which_rank_global_e_min` and `which_rank_global_e_max`
// give the caller the rank IDs that should drive the broadcast.
struct PartialGlobalReductionSummary {
  int world_size = 0;
  int contributing_ranks = 0;
  unsigned long long total_processed_candidates = 0;
  unsigned long long total_processed_chunks = 0;
  bool any_has_more = false;
  bool any_exhaust_all = false;
  bool has_samples = false;

  long double global_e_min = 0.0L;
  long double global_e_max = 0.0L;
  int which_rank_global_e_min = -1;
  int which_rank_global_e_max = -1;
  unsigned long long global_e_min_candidate_index = 0;
  unsigned long long global_e_max_candidate_index = 0;

  long double global_de_min_swap = 0.0L;
  int global_swap_count = 0;
  long double total_de_min_swap = 0.0L;
  int total_swap_count = 0;

  // The reducer does not move structures here, but it does propagate
  // the per-rank presence flag for the rank that ended up holding each
  // extremum. The caller can use these to decide whether to expect a
  // structure broadcast from that rank at all.
  bool global_best_structure_present = false;
  bool global_worst_structure_present = false;

  int primary_recipe_index = -1;
  bool primary_recipe_consistent = true;
  EnergyTable global_energy_table;
};

// Extract the MPI-friendly fixed-size payload from a
// `LocalReductionSummary`. Used by the wire transport step before
// `MPI_Allgather`.
LocalReductionScalars extract_local_reduction_scalars(
    const LocalReductionSummary& summary);

// Reducer that operates on the fixed-size scalar payload only. This is
// the MPI-friendly entry point: callers use it after `MPI_Allgather` to
// resolve ownership without needing to gather any structures.
PartialGlobalReductionSummary combine_local_reduction_scalars(
    const std::vector<LocalReductionScalars>& inputs);

}  // namespace ess::solve_steps
