#pragma once

#include <array>
#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess::guide_steps {

// Tunables for the original Guider's add_ions() routine. The original code
// reads NRandomSeeds, ShellWidth, WYCIdentityLength, and ABCWeights from
// the guider input file; we expose them here as a struct so callers can
// drive the routine deterministically.
struct AddIonsOptions {
  long double shell_width = 1.0L;
  long double wyc_identity_length = 0.2L;
  std::array<long double, 3> abc_weights{2.0L, 2.0L, 1.0L};
  int n_random_seeds = 2000;
  // Seed for std::srand. The original Guider seeds rand() from time(NULL)
  // and is therefore non-deterministic; this extracted version requires an
  // explicit integer seed so that golden tests and spglib-driven future
  // automation can reproduce results bit-for-bit on a given platform.
  unsigned int random_seed = 0;
};

// One added site, expressed in both fractional (with respect to `lattice`)
// and Cartesian coordinates so callers can plug the result into the
// existing typed atom list without recomputing the conversion.
struct AddedSite {
  std::array<long double, 3> fractional{0.0L, 0.0L, 0.0L};
  std::array<long double, 3> cartesian{0.0L, 0.0L, 0.0L};
};

struct AddIonsResult {
  std::vector<AddedSite> added_sites;
  // The seed fractional coordinates whose orbit produced the chosen sites,
  // in the order they were sampled by the random pass. The original Guider
  // logs these to the output file as
  //     ***  i+1: (a, b, c)
  // for diagnostics; we expose them in the typed result so future tooling
  // can replay or display the same information.
  std::vector<std::array<long double, 3>> chosen_random_seeds;
  long double neighbor_distance_max = 0.0L;
  // Per-iteration log lines matching the original Guider's "iseed/total
  // best-distance" trace.
  std::vector<std::string> log;
};

// Reproduces the original Guider's add_ions() algorithm: repeatedly sample
// (a, b, c) fractional coordinates, expand them through `wyc_operations`,
// reject candidates whose nearest neighbour falls below
// `wyc_identity_length`, score the resulting set against
// `existing_fractional` (and against the candidate set itself) using a
// shell-bounded weighted-distance sum, and pick the seed whose score is
// the largest across `n_random_seeds` trials.
//
// `existing_fractional` is the list of already-occupied fractional
// positions in the primitive cell. Throws std::runtime_error if
// `wyc_operations` is empty.
AddIonsResult compute_add_ions(
    const Lattice& lattice,
    const std::vector<std::array<long double, 3>>& existing_fractional,
    const std::vector<SymmetryOperation>& wyc_operations,
    int n_to_add,
    const AddIonsOptions& options);

}  // namespace ess::guide_steps
