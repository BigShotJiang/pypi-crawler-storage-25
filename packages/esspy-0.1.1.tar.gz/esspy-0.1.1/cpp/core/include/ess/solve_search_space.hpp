#pragma once

#include "ess/core.hpp"
#include <string>
#include <vector>

namespace ess::solve_steps {

SearchSpaceSummary analyze_search_space(const ReadyModel& ready);

}  // namespace ess::solve_steps
