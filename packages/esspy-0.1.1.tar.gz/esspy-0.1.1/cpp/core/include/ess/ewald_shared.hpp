#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess {

struct EwaldEvaluationResult {
  int rg_find_factor = 1;
  std::size_t nsite = 0;
  long double total_e = 0.0L;
  long double ereal = 0.0L;
  long double epoint = 0.0L;
  long double erecip = 0.0L;
};

EwaldEvaluationResult evaluate_ready_energy(
    const ReadyModel& ready,
    int rg_find_factor,
    long double chop_level);

std::string format_ewald_log_line(
    int rg_find_factor,
    long double total_e,
    std::size_t nsite,
    const std::string& suffix = "");

}  // namespace ess
