#pragma once

#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess::guide_steps {

// Per-species count read from the POSCAR primitive cell, in original POSCAR
// order, with the corresponding ion valence already resolved.
struct PrimitiveCellIon {
  std::string kind;
  int n = 0;
  long double oxidation = 0.0L;
};

// Per-cellion result of the recipe-allocation step. The cellions list mirrors
// the original Guider's cellions0 vector after the missing-target append step:
// it preserves the POSCAR ion order and then appends every Target species
// that was not present in the POSCAR (with n = 0).
struct AllocatedCellIon {
  std::string kind;
  int n_primitive = 0;
  long double oxidation = 0.0L;
  int need = 0;
  int delta_need = 0;
  // True when this cellion was skipped because it appears as a target of
  // another recipe (the original "already_in_another_recipe" path).
  bool skipped_in_other_recipe = false;
  bool has_recipe = false;
};

// One non-self target line for a recipe. The original Guider writer drops
// modifications whose `to` matches the recipe's `from`, so this list is
// produced with self-modifications already excluded. The `oxidation` field
// is filled in from the charge map when the species is known there.
struct FinalRecipeModification {
  std::string to;
  long double oxidation = 0.0L;
  int number = 0;
};

// One recipe in the ready-file's recipe block, expressed in typed form. The
// `random_pickup` value is `supercell_exp * cellion.n_primitive`; this matches
// the pre-add-ions count used by the original Guider when StrictNoAddedSites
// is true (G001) or when DNeed = 0 for every cellion (G002). The added-site
// case (G004) requires the cellion counts to be updated by add_ions before
// random_pickup is finalised, which is left to a later extraction phase.
struct FinalRecipe {
  std::string from;
  long double oxidation = 0.0L;
  int random_pickup = 0;
  int random_pickup_trial = 1;
  int vac = 0;
  std::vector<FinalRecipeModification> modifications;
};

struct RecipeAllocationResult {
  std::vector<AllocatedCellIon> cellions;
  std::vector<FinalRecipe> final_recipes;
  bool need_wyc = false;
  std::vector<std::string> log;
};

// Reproduces the recipe-allocation block of the original Guider's
// read_POSCAR(): NRatio is assumed to have already been folded into
// `target_counts` (one CompositionEntry per Target species, expressed as
// integer counts in the supercell). The function then performs the
// strict-vs-non-strict branching, builds cellions with Need and DNeed
// resolved, and constructs the FinalRecipe entries with non-self
// modifications and the resulting vac count.
//
// Throws std::runtime_error to mirror fail_run() in the original code when:
//   - StrictNoAddedSites would require a non-zero DNeed for a non-recipe
//     species
//   - StrictNoAddedSites cannot fully consume the available capacity of a
//     recipe source species
//   - StrictNoAddedSites leaves any remaining_target unsatisfied
RecipeAllocationResult compute_recipe_allocation(
    const std::vector<PrimitiveCellIon>& primitive_cellions,
    const std::vector<CompositionEntry>& target_counts,
    int supercell_exp,
    bool strict_no_added_sites,
    const std::vector<RecipeSpec>& recipes,
    const ChargeMap& charges);

}  // namespace ess::guide_steps
