#pragma once

#include <array>
#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess::solve_steps {

struct AddSitesNeighborConstraint {
  std::string kind;
  long double doxidation = 0.0L;
  long double dist_min = 0.0L;
  long double dist_max = 0.0L;
};

struct AddSitesKindSpec {
  std::string kind;
  int n_added = 0;
  long double oxidation = 0.0L;
  std::vector<AddSitesNeighborConstraint> neighbor_kinds;
};

struct AddSitesMonteCarloSpec {
  std::array<long double, 3> add_meshes{0.0L, 0.0L, 0.0L};
  long double min_distance_between_added_sites = 0.0L;
  int n_monte_carlo = 0;
  int monte_carlo_monitor_index = 1;
  std::vector<AddSitesKindSpec> added_kinds;
};

struct AddSitesMonteCarloOptions {
  unsigned int random_seed = 0;
  int rg_find_factor = 1;
  long double chop_level = 8.0L;
};

struct AddSitesMonteCarloResult {
  bool success = false;
  StructureModel best_structure;
  long double best_energy = 0.0L;
  int accepted_trials = 0;
  int attempted_trials = 0;
  std::vector<std::string> log;
};

AddSitesMonteCarloResult run_add_sites_monte_carlo(
    const StructureModel& base_structure,
    const AddSitesMonteCarloSpec& spec,
    const AddSitesMonteCarloOptions& options);

}  // namespace ess::solve_steps
