#pragma once

#include <cstddef>
#include <functional>
#include <string>
#include <vector>

#include "ess/core.hpp"
#include "ess/solve_swap_cache.hpp"

namespace ess::solve_steps {

// Tunables for the typed swap-loop extraction. Mirrors the legacy ESS
// solver's swap()/postprocess() options:
//   - mode == 1: best-improvement Swap (legacy `Swap = 1`); for each
//     recipe, scan every (i, j) pair in the recipe's site pool and apply
//     the most-improving swap.
//   - mode == 2: first-improvement Swap (legacy `Swap = 2`); apply the
//     first improving swap encountered and move on.
// `max_swap` mirrors the legacy MaxSwap counter:
//   - max_swap > 0: cap rounds at that many; sets `stopped_by_max_swap`
//     when the cap is hit.
//   - max_swap <= 0: run until no improvement is possible.
// The loop uses `evaluate_ready_energy(...)` for every candidate energy
// evaluation. That is intentionally slower than the legacy `mEwald_*`
// cache path; cache-aware re-evaluation is a separate future cut.
struct SwapLoopOptions {
  int mode = 1;
  int max_swap = 100;
  int rg_find_factor = 1;
  long double chop_level = 8.0L;
  // Optional explicit starting state. When non-empty, the swap loop
  // seeds its working structure from these sites instead of the
  // canonical recipe materialisation. The vector is interpreted as one
  // entry per supercell-expanded site (in the order
  // `materialize_canonical_structure_with_pools(ready)` would produce),
  // so callers must not reorder sites; the swap loop validates the
  // length against the canonical expansion before using the override.
  // Coordinate values must match the canonical expansion as well; only
  // (kind, oxidation) may differ. This is what makes the override
  // compatible with the per-recipe pools that drive the swap scan.
  std::vector<Site> starting_sites;
  std::function<bool()> cancel_requested;
};

struct SwapAcceptance {
  int round = 0;
  int recipe_index = -1;
  std::size_t site_a_supercell_index = 0;
  std::size_t site_b_supercell_index = 0;
  std::string kind_a_before;
  std::string kind_b_before;
  long double energy_after = 0.0L;
  long double denrg = 0.0L;
};

// Result of the typed swap loop. `final_structure` carries the
// supercell-expanded sites with their post-swap kinds and oxidations
// applied. `de_min_swap` follows the legacy convention
// `final_total_energy - initial_total_energy` (negative when the swap
// loop lowered the energy). `swap_count` mirrors the legacy
// `swap_count` and equals the number of completed loop rounds that
// actually committed at least one swap.
struct SwapLoopResult {
  StructureModel final_structure;
  long double initial_total_energy = 0.0L;
  long double final_total_energy = 0.0L;
  long double de_min_swap = 0.0L;
  int swap_count = 0;
  bool stopped_by_max_swap = false;
  bool stopped_by_no_improvement = false;
  SwapEnergyCacheStats cache_stats;
  std::vector<SwapAcceptance> committed_swaps;
  std::vector<std::string> log;
};

SwapLoopResult compute_swap_loop(
    const ReadyModel& ready,
    const SwapLoopOptions& options);

}  // namespace ess::solve_steps
