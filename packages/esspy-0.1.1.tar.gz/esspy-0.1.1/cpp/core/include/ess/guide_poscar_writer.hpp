#pragma once

#include <string>

#include "ess/core.hpp"

namespace ess::guide_steps {

std::string write_poscar_text(const ReadyModel& ready);

}  // namespace ess::guide_steps
