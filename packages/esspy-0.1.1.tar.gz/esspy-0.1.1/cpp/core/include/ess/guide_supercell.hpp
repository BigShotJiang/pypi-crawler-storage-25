#pragma once

#include <array>
#include <string>
#include <vector>

#include "ess/core.hpp"

namespace ess::guide_steps {

// Result of the supercell-expansion search step in the original Guider's
// read_POSCAR(): given the primitive lattice, the number of atoms in the
// primitive cell, and the user-provided NTargetSites, this returns the
// integer expansion factors along (a, b, c), the resulting expanded atom
// count, and the per-iteration log lines that the original Guider writes
// into its output file.
struct SupercellExpansionResult {
  std::array<int, 3> expansion{1, 1, 1};
  int expanded_n_atom_config = 0;
  std::vector<std::string> log;
};

// Reproduces the Guider's expansion search: if NAtomConfig already exceeds
// NTargetSites the expansion is fixed to (1, 1, 1). Otherwise the axis with
// the currently-shortest expanded length is incremented one at a time until
// the expanded atom count first exceeds NTargetSites, and then the algorithm
// picks whichever of the last two candidates is closer to NTargetSites
// (preferring the smaller candidate on ties).
SupercellExpansionResult compute_supercell_expansion(
    const Lattice& lattice,
    int n_atom_config,
    int n_target_sites);

}  // namespace ess::guide_steps
