#pragma once

#include "ess/core.hpp"

namespace ess::solve_steps {

FirstEnumerationState analyze_first_enumeration(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space);

}  // namespace ess::solve_steps
