#pragma once

#include <functional>

#include "ess/core.hpp"
#include "ess/solve_swap_cache.hpp"

namespace ess::solve_steps {

WindowEvaluationSummary evaluate_primary_slice_window(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    int rg_find_factor,
    long double chop_level,
    bool save_memory = false);

WindowEvaluationSummary evaluate_nested_primary_slice_window(
    const ReadyModel& ready,
    const SearchSpaceSummary& search_space,
    int rg_find_factor,
    long double chop_level,
    SwapEnergyCache* incremental_cache = nullptr,
    bool save_memory = false,
    std::function<bool(int, unsigned long long, unsigned long long, unsigned long long)>
        progress_callback = {});

}  // namespace ess::solve_steps
