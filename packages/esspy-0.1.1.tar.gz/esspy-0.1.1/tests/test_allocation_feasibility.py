from __future__ import annotations

from esspy.allocation_feasibility import (
    analyze_site_allocation,
    analyze_site_allocation_from_payload,
    decide_allocation_pipeline,
)


def test_allocation_feasibility_unique_solution():
    result = analyze_site_allocation(
        {"Mn": 8, "Cr": 16, "O": 32},
        {
            "site1": {"source_kind": "Mn", "count": 8, "allowed": ["Mn"]},
            "site2": {"source_kind": "Cr", "count": 16, "allowed": ["Cr"]},
            "site3": {"source_kind": "O", "count": 32, "allowed": ["O"]},
        },
        n_target_sites=56,
    )

    assert result.status == "unique"
    assert result.requires_allocation is False
    assert result.unique_solution == {
        "site1": {"Mn": 8},
        "site2": {"Cr": 16},
        "site3": {"O": 32},
    }
    assert decide_allocation_pipeline(
        composition_by_site=None, feasibility=result
    ) == "arrangement_only"


def test_allocation_feasibility_multiple_solutions():
    result = analyze_site_allocation(
        {"Mn": 7, "Cr": 17, "O": 32},
        {
            "site1": {"source_kind": "Cr", "count": 8, "allowed": ["Mn", "Cr"]},
            "site2": {"source_kind": "Cr", "count": 16, "allowed": ["Mn", "Cr"]},
            "site3": {"source_kind": "O", "count": 32, "allowed": ["O"]},
        },
        n_target_sites=56,
    )

    assert result.status == "multiple"
    assert result.requires_allocation is True
    assert result.n_solutions_observed == 2
    assert result.truncated is True
    assert len(result.solutions) == 2
    assert decide_allocation_pipeline(
        composition_by_site=None, feasibility=result
    ) == "allocation_plus_arrangement"


def test_allocation_feasibility_none_when_element_has_no_allowed_group():
    result = analyze_site_allocation(
        {"Mn": 8, "Ni": 1, "Cr": 15, "O": 32},
        {
            "site1": {"source_kind": "Mn", "count": 8, "allowed": ["Mn"]},
            "site2": {"source_kind": "Cr", "count": 16, "allowed": ["Cr"]},
            "site3": {"source_kind": "O", "count": 32, "allowed": ["O"]},
        },
        n_target_sites=56,
    )

    assert result.status == "none"
    assert "Ni" in result.errors[0]
    assert decide_allocation_pipeline(
        composition_by_site=None, feasibility=result
    ) == "invalid"


def test_allocation_feasibility_scales_site_group_counts_to_target():
    result = analyze_site_allocation(
        {"Mn": 16, "Cr": 32, "O": 64},
        {
            "site1": {"source_kind": "Mn", "count": 8, "allowed": ["Mn"]},
            "site2": {"source_kind": "Cr", "count": 16, "allowed": ["Cr"]},
            "site3": {"source_kind": "O", "count": 32, "allowed": ["O"]},
        },
        n_target_sites=112,
    )

    assert result.status == "unique"
    assert result.scale_factor == 2
    assert result.group_capacities == {"site1": 16, "site2": 32, "site3": 64}
    assert result.unique_solution == {
        "site1": {"Mn": 16},
        "site2": {"Cr": 32},
        "site3": {"O": 64},
    }


def test_allocation_feasibility_payload_fraction_composition():
    payload = {
        "structure": {"n_target_sites": 112},
        "composition": {
            "fractions": {
                "Mn": 0.0625,
                "Cr": 0.1339285714,
                "Ni": 0.0803571429,
                "Rh": 0.0446428571,
                "Co": 0.0625,
                "Fe": 0.0446428571,
                "O": 0.5714285714,
            }
        },
        "site_groups": {
            "site1": {
                "source_kind": "Mn",
                "count": 8,
                "allowed": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
            },
            "site2": {
                "source_kind": "Cr",
                "count": 16,
                "allowed": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
            },
            "site3": {"source_kind": "O", "count": 32, "allowed": ["O"]},
        },
    }

    result = analyze_site_allocation_from_payload(payload)

    assert result.status == "multiple"
    assert result.scale_factor == 2
    assert result.group_capacities == {"site1": 16, "site2": 32, "site3": 64}
    assert all(solution["site3"] == {"O": 64} for solution in result.solutions)


def test_allocation_feasibility_payload_fraction_composition_with_dim():
    payload = {
        "structure": {"dim": [4, 4, 4]},
        "composition": {
            "fractions": {
                "Mo": 0.125,
                "Mg": 0.375,
                "N": 0.5,
            }
        },
        "site_groups": {
            "site1": {"source_kind": "M", "count": 4, "allowed": ["Mo", "Mg"]},
            "site2": {"source_kind": "N", "count": 4, "allowed": ["N"]},
        },
    }

    result = analyze_site_allocation_from_payload(payload)

    assert result.status == "unique"
    assert result.scale_factor == 64
    assert result.target_sites == 512
    assert result.group_capacities == {"site1": 256, "site2": 256}
    assert result.unique_solution == {
        "site1": {"Mo": 64, "Mg": 192},
        "site2": {"N": 256},
    }


def test_pipeline_is_arrangement_only_when_sitewise_composition_exists():
    assert (
        decide_allocation_pipeline(
            composition_by_site={"site1": {"Mn": 8}},
            feasibility=None,
        )
        == "arrangement_only"
    )
