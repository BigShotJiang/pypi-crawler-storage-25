from __future__ import annotations

from pathlib import Path

from esspy.cli import main


class _DummyWizardSession:
    def __init__(self):
        self.state = type(
            "State",
            (),
            {
                "reference_structure": "POSCAR",
                "solve_mode": "adaptive",
                "solve_effort": "medium",
                "solve_time_budget_sec": 600,
                "solve_swap_max_steps": 100,
                "selection_enabled": True,
                "selection_mode": "auto_top_n",
                "selection_limit": 20,
                "selection_pick": "lowest",
                "selection_interval": "left-closed",
                "selection_outdir": "selected_structures",
                "selection_prefix": "selected",
            },
        )()

    def run_workflow(self) -> bool:
        return True

    def save_to_yaml(self, output_path: str) -> bool:
        Path(output_path).write_text(
            "name: test\n"
            "symmetry:\n"
            "  mode: auto\n"
            "  symprec: 1.0e-05\n"
            "  write_wyc_path: symmetry.wyc\n"
            "output:\n"
            "  workdir: run-output\n",
            encoding="utf-8",
        )
        return True


class _DummySiteGroupingWizardSession(_DummyWizardSession):
    def save_to_yaml(self, output_path: str) -> bool:
        Path(output_path).write_text(
            "structure:\n"
            "  poscar: POSCAR\n"
            "  n_target_sites: 56\n"
            "composition:\n"
            "  Mn: 4\n"
            "  Cr: 20\n"
            "  O: 32\n"
            "charges:\n"
            "  basis: element_site\n"
            "  values:\n"
            "    Mn: 2.0\n"
            "    Cr: 3.0\n"
            "    O: -2.0\n"
            "  elements:\n"
            "    Cr:\n"
            "      default: 3.0\n"
            "      by_site:\n"
            "        site1: 3.0\n"
            "        site2: 3.0\n"
            "    O:\n"
            "      default: -2.0\n"
            "      by_site:\n"
            "        site3: -2.0\n"
            "recipes:\n"
            "- from_kind: Cr\n"
            "  to: [Mn, Cr]\n"
            "- from_kind: O\n"
            "  to: [O]\n"
            "site_grouping:\n"
            "  mode: element_wyckoff\n"
            "  symprec: 0.1\n"
            "  angle_tolerance: 5.0\n"
            "  fallback: poscar_kind\n"
            "site_groups:\n"
            "  site1:\n"
            "    source_kind: Cr\n"
            "    count: 8\n"
            "    allowed: [Mn, Cr]\n"
            "  site2:\n"
            "    source_kind: Cr\n"
            "    count: 16\n"
            "    allowed: [Mn, Cr]\n"
            "  site3:\n"
            "    source_kind: O\n"
            "    count: 32\n"
            "    allowed: [O]\n"
            "output:\n"
            "  workdir: run-output\n",
            encoding="utf-8",
        )
        return True


def test_wizard_prints_replay_command(monkeypatch, tmp_path, capsys):
    import esspy.wizard as wizard_mod

    monkeypatch.setattr(wizard_mod, "WizardSession", _DummyWizardSession)
    monkeypatch.chdir(tmp_path)
    out = tmp_path / "input.yaml"

    rc = main(["wizard", "--output", str(out)])
    assert rc == 0
    text = capsys.readouterr().out
    assert "Replay command (same solve strategy defaults):" in text
    assert "esspy init -p POSCAR" in text
    assert "--name input" in text
    assert "--symmetry auto" in text
    assert "--solve-mode adaptive" in text
    assert "--solve-effort medium" in text
    assert "--time-budget-sec 600" in text
    assert "--symprec 1e-05" in text
    assert "--write-wyc-path symmetry.wyc" in text
    assert "--output-workdir run-output" in text
    assert "--selection-enabled true" in text
    assert "--selection-mode auto_top_n" in text
    assert "--selection-limit 20" in text
    assert "--selection-pick lowest" in text
    assert "--selection-interval left-closed" in text
    assert "--selection-outdir selected_structures" in text
    assert "--selection-prefix selected" in text
    assert (tmp_path / "wizard.last.log").exists()
    script = tmp_path / "wizard.replay.sh"
    assert script.exists()
    script_text = script.read_text()
    assert "cat >" not in script_text
    assert "__ESSPY_WIZARD_YAML__" not in script_text
    assert "Approximate init command" not in script_text
    assert "esspy init -p POSCAR" in script_text


def test_wizard_replay_uses_site_grouping_flags(monkeypatch, tmp_path, capsys):
    import esspy.wizard as wizard_mod

    monkeypatch.setattr(wizard_mod, "WizardSession", _DummySiteGroupingWizardSession)
    monkeypatch.chdir(tmp_path)
    out = tmp_path / "input.yaml"

    rc = main(["wizard", "--output", str(out)])
    assert rc == 0
    text = capsys.readouterr().out
    assert "--site-grouping element_wyckoff" in text
    assert "--site-group-symprec 0.1" in text
    assert "--site-group-angle-tolerance 5.0" in text
    assert "--site-group site1:" not in text


def test_wizard_replay_outputs_are_overwritten(monkeypatch, tmp_path):
    import esspy.wizard as wizard_mod

    monkeypatch.setattr(wizard_mod, "WizardSession", _DummyWizardSession)
    monkeypatch.chdir(tmp_path)
    out = tmp_path / "input.yaml"

    rc1 = main(["wizard", "--output", str(out)])
    assert rc1 == 0
    script = tmp_path / "wizard.replay.sh"
    log = tmp_path / "wizard.last.log"
    script.write_text("old script\n", encoding="utf-8")
    log.write_text("old log\n", encoding="utf-8")

    rc2 = main(["wizard", "--output", str(out)])
    assert rc2 == 0
    assert "old script" not in script.read_text()
    assert "old log" not in log.read_text()
