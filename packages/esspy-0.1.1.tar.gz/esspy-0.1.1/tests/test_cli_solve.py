"""Phase 79 — `esspy solve` command family regression coverage."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from esspy.cli import main as cli_main
from esspy.ready_text import parse_ready_text, ready_text_to_native_payload


READY_G003 = Path(
    "tests/golden/fixtures/G003_M6O8/basic_properties_EwaldSolidSolution.ready.txt"
)
READY_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolution.ready.txt"
)


def _run_cli(argv: list[str], capsys) -> dict:
    rc = cli_main(argv)
    assert rc == 0
    captured = capsys.readouterr()
    last_line = captured.out.strip().splitlines()[-1]
    return json.loads(last_line)


def test_parse_ready_text_extracts_lattice_atoms_recipes():
    doc = parse_ready_text(READY_G003)
    assert doc.n_atom_config == 14
    assert len(doc.atom_config) == 14
    assert doc.supercell_expansion == (2, 2, 2)
    assert doc.output_prefix == "M6O8_spinel_recovery_001"
    assert len(doc.recipes) == 1
    recipe = doc.recipes[0]
    assert recipe.from_kind == "M"
    assert recipe.random_pickup == 48
    assert recipe.random_pickup_trial == 1
    assert tuple((m.to, m.count) for m in recipe.modifications) == (
        ("Mn", 16),
        ("Cr", 32),
    )
    # vec_a was the first numeric line in the ready text.
    assert doc.vec_a[0] == pytest.approx(5.1772941, rel=1e-6)


def test_ready_text_to_native_payload_shape_matches_solve_inputs():
    doc = parse_ready_text(READY_G003)
    payload = ready_text_to_native_payload(doc)
    assert set(payload.keys()) == {
        "lattice",
        "atoms",
        "supercell_expansion",
        "rg_find_factor",
        "output_prefix",
        "recipes",
    }
    assert isinstance(payload["lattice"]["a"], list)
    assert len(payload["atoms"]) == 14
    assert payload["recipes"][0]["from"] == "M"


def test_cli_solve_inspect_ready_reports_basic_summary(capsys):
    payload = _run_cli(["solve", "inspect-ready", str(READY_G003)], capsys)
    assert payload["ready"].endswith("basic_properties_EwaldSolidSolution.ready.txt")
    assert payload["n_atom_config"] == 14
    assert payload["supercell_expansion"] == [2, 2, 2]
    assert payload["n_recipes"] == 1
    # G003 primitive cell holds 6 M-sites and 8 O-sites.
    assert payload["species_counts"] == {"M": 6, "O": 8}
    assert payload["recipes"][0]["from"] == "M"


def test_cli_solve_inspect_ready_g001_two_recipes(capsys):
    payload = _run_cli(["solve", "inspect-ready", str(READY_G001)], capsys)
    assert payload["n_atom_config"] == 14
    assert payload["n_recipes"] == 2
    recipes_by_from = {r["from"]: r for r in payload["recipes"]}
    assert set(recipes_by_from) == {"Mn", "Cr"}
    assert recipes_by_from["Mn"]["random_pickup"] == 16
    assert recipes_by_from["Cr"]["random_pickup"] == 32


def test_cli_solve_search_space_reports_primary_recipe(capsys):
    payload = _run_cli(["solve", "search-space", str(READY_G003)], capsys)
    assert payload["primary_recipe_index"] >= 0
    assert payload["total_candidate_count_log10"] > 0
    assert len(payload["entries"]) == 1
    entry = payload["entries"][0]
    assert entry["from"] == "M"
    assert entry["random_pickup"] == 48
    assert entry["candidate_count_log10"] > 0


def test_cli_solve_decode_first_index_returns_canonical_assignment(capsys):
    payload = _run_cli(
        ["solve", "decode", str(READY_G003), "--recipe", "0", "--index", "1"],
        capsys,
    )
    assert payload["recipe"] == 0
    assert payload["index"] == 1
    # G003 recipe 0: random_pickup = 48, modifications [Mn:16, Cr:32].
    # The first canonical candidate places all 16 Mn first, then 32 Cr.
    assert len(payload["indices"]) == 48
    assert len(payload["labels"]) == 48
    assert payload["labels"][:16] == ["Mn"] * 16
    assert payload["labels"][16:] == ["Cr"] * 32


def test_cli_solve_decode_invalid_recipe_index_errors(capsys):
    with pytest.raises(SystemExit):
        cli_main(
            ["solve", "decode", str(READY_G003), "--recipe", "99", "--index", "1"]
        )


def test_cli_solve_swap_reports_typed_summary(capsys):
    payload = _run_cli(
        [
            "solve",
            "swap",
            str(READY_G001),
            "--mode",
            "1",
            "--max-swap",
            "1",
        ],
        capsys,
    )
    assert payload["mode"] == 1
    assert payload["max_swap"] == 1
    assert payload["swap_count"] >= 0
    assert payload["de_min_swap"] <= 1.0e-9
    # Cache stats advertised through the integrated swap loop must be
    # consistent with the single-call stats contract.
    assert payload["cache_stats"]["full_evaluations"] == 0


def test_cli_solve_swap_mode_two_first_improvement(capsys):
    payload = _run_cli(
        [
            "solve",
            "swap",
            str(READY_G001),
            "--mode",
            "2",
            "--max-swap",
            "1",
        ],
        capsys,
    )
    assert payload["mode"] == 2
    assert payload["de_min_swap"] <= 1.0e-9


def test_cli_solve_swap_zero_max_swap_runs_to_no_improvement(capsys):
    payload = _run_cli(
        [
            "solve",
            "swap",
            str(READY_G001),
            "--max-swap",
            "0",
        ],
        capsys,
    )
    # max_swap <= 0 means "run until no improvement"; the loop must
    # therefore terminate via stopped_by_no_improvement rather than
    # stopped_by_max_swap.
    assert payload["stopped_by_no_improvement"] is True
    assert payload["stopped_by_max_swap"] is False


def test_solve_help_when_no_subcommand(capsys):
    """Bare `esspy solve` must print solve help and exit 0."""
    rc = cli_main(["solve"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "usage: esspy solve" in captured.out
    assert "inspect-ready" in captured.out
    assert "search-space" in captured.out
    assert "swap" in captured.out


def test_cli_solve_energy_window_filters_and_copies(tmp_path: Path, capsys):
    struct_a = tmp_path / "A.vasp"
    struct_b = tmp_path / "B.vasp"
    struct_c = tmp_path / "C.vasp"
    struct_a.write_text("A")
    struct_b.write_text("B")
    struct_c.write_text("C")

    solver_text = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    solver_text.write_text(
        "=============================pick_recipe()=============================\n"
        f"{struct_a.name}\t-12.0\n"
        f"{struct_b.name}\t-5.0\n"
        f"{struct_c.name}\t1.0\n"
        "global_e_min=\t-12.0\n"
    )

    outdir = tmp_path / "selected"
    payload = _run_cli(
        [
            "solve",
            "energy-window",
            "--solver-text",
            str(solver_text),
            "--energy-min",
            "-20",
            "--energy-max",
            "-1",
            "--outdir",
            str(outdir),
            "--prefix",
            "window",
        ],
        capsys,
    )
    assert payload["parsed_entries"] == 3
    assert payload["selected_entries"] == 2
    assert len(payload["rows"]) == 2
    energies = [row["energy"] for row in payload["rows"]]
    assert energies == sorted(energies)
    copied = payload["copied_files"]
    assert len(copied) == 2
    assert (outdir / "window-0001.vasp").exists()
    assert (outdir / "window-0002.vasp").exists()


def test_cli_solve_energy_window_defaults_auto_top_n(tmp_path: Path, capsys):
    for i, e in enumerate([-3.0, -1.0, -2.0], start=1):
        (tmp_path / f"S{i}.vasp").write_text(f"S{i}")
    solver_text = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    solver_text.write_text(
        "S1.vasp\t-3.0\n"
        "S2.vasp\t-1.0\n"
        "S3.vasp\t-2.0\n"
    )
    payload = _run_cli(
        [
            "solve",
            "energy-window",
            "--solver-text",
            str(solver_text),
            "--outdir",
            str(tmp_path / "selected_structures"),
        ],
        capsys,
    )
    assert payload["interval"] == "left-closed"
    assert payload["pick"] == "lowest"
    assert payload["limit"] == 20
    assert payload["selected_entries"] == 3
    assert (tmp_path / "selected_structures" / "selected-0001.vasp").exists()
