from pathlib import Path

import pytest

from esspy import load_poscar


def test_poscar_cartesian_mode_is_preserved(tmp_path: Path):
    path = tmp_path / "POSCAR_cart.vasp"
    path.write_text(
        "cart_case\n"
        "1.0\n"
        "1 0 0\n"
        "0 1 0\n"
        "0 0 1\n"
        "Mn O\n"
        "1 1\n"
        "Cartesian\n"
        "0.1 0.2 0.3\n"
        "0.4 0.5 0.6\n"
    )
    structure = load_poscar(path)
    assert structure.fractional_coordinates is False
    assert structure.sites[1].z == 0.6


def test_poscar_selective_dynamics_flags_are_ignored(tmp_path: Path):
    path = tmp_path / "POSCAR_selective.vasp"
    path.write_text(
        "selective_case\n"
        "1.0\n"
        "1 0 0\n"
        "0 1 0\n"
        "0 0 1\n"
        "Mn\n"
        "1\n"
        "Selective dynamics\n"
        "Direct\n"
        "0.1 0.2 0.3 T T F\n"
    )
    structure = load_poscar(path)
    assert structure.fractional_coordinates is True
    assert structure.sites[0].x == 0.1


def test_poscar_vasp4_style_is_currently_rejected(tmp_path: Path):
    path = tmp_path / "POSCAR_vasp4.vasp"
    path.write_text(
        "vasp4_case\n"
        "1.0\n"
        "1 0 0\n"
        "0 1 0\n"
        "0 0 1\n"
        "1 1\n"
        "Direct\n"
        "0.1 0.2 0.3\n"
        "0.4 0.5 0.6\n"
    )
    with pytest.raises(ValueError):
        load_poscar(path)
