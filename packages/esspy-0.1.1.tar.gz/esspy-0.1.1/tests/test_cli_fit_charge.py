from __future__ import annotations

import json
from pathlib import Path

from esspy.cli import main as cli_main


def _write_poscar(path: Path, cl_pos: tuple[float, float, float]) -> None:
    path.write_text(
        "\n".join(
            [
                "NaCl test",
                "1.0",
                "5.640000 0.000000 0.000000",
                "0.000000 5.640000 0.000000",
                "0.000000 0.000000 5.640000",
                "Na Cl",
                "1 1",
                "Direct",
                "0.000000 0.000000 0.000000",
                f"{cl_pos[0]:.6f} {cl_pos[1]:.6f} {cl_pos[2]:.6f}",
            ]
        )
        + "\n"
    )


def _write_site_labeled_poscar(path: Path, shift: float) -> None:
    cl_x = 0.50 + shift
    path.write_text(
        "\n".join(
            [
                "site-aware NaCl test",
                "1.0",
                "5.640000 0.000000 0.000000",
                "0.000000 5.640000 0.000000",
                "0.000000 0.000000 5.640000",
                "Na Cl",
                "2 1",
                "Direct",
                "0.000000 0.000000 0.000000  # site-001",
                "0.500000 0.500000 0.000000  # site-002",
                f"{cl_x:.6f} 0.500000 0.500000  # site-003",
            ]
        )
        + "\n"
    )


def _write_site_labeled_momgn_poscar(path: Path, shift: float) -> None:
    path.write_text(
        "\n".join(
            [
                "site-aware MoMgN test",
                "1.0",
                "6.000000 0.000000 0.000000",
                "0.000000 6.000000 0.000000",
                "0.000000 0.000000 6.000000",
                "Mo Mg N",
                "1 1 2",
                "Direct",
                "0.000000 0.000000 0.000000  # site-001",
                "0.500000 0.500000 0.000000  # site-001",
                f"{0.250000 + shift:.6f} 0.250000 0.250000  # site-002",
                f"{0.750000 - shift:.6f} 0.750000 0.750000  # site-002",
            ]
        )
        + "\n"
    )


def test_cli_fit_charge_from_simple_dataset(tmp_path: Path, capsys) -> None:
    pos1 = tmp_path / "sample-001.vasp"
    pos2 = tmp_path / "sample-002.vasp"
    pos3 = tmp_path / "sample-003.vasp"
    _write_poscar(pos1, (0.50, 0.50, 0.50))
    _write_poscar(pos2, (0.45, 0.50, 0.50))
    _write_poscar(pos3, (0.40, 0.50, 0.50))

    dataset = tmp_path / "dataset.txt"
    dataset.write_text(
        "\n".join(
            [
                f"{pos1} -10.000000",
                f"{pos2} -10.200000",
                f"{pos3} -10.300000",
            ]
        )
        + "\n"
    )

    model_path = tmp_path / "charge_model.json"
    report_path = tmp_path / "fit_report.json"
    plot_path = tmp_path / "parity_plot.png"
    rc = cli_main(
        [
            "--json",
            "fit-charge",
            str(dataset),
            "--anchor-kind",
            "Cl",
            "--maxiter",
            "30",
            "--out-model",
            str(model_path),
            "--out-report",
            str(report_path),
            "--out-plot",
            str(plot_path),
        ]
    )
    assert rc == 0

    summary = json.loads(capsys.readouterr().out)
    assert summary["dataset"] == str(dataset.resolve())
    assert summary["outputs"]["model"] == str(model_path.resolve())
    assert summary["outputs"]["report"] == str(report_path.resolve())
    assert summary["outputs"]["parity_plot"] == str(plot_path.resolve())
    assert plot_path.exists()

    model_payload = json.loads(model_path.read_text())
    assert model_payload["model_type"] == "effective_element_charge"
    assert model_payload["charges"]["basis"] == "element"
    assert set(model_payload["charges"]) == {"basis", "elements"}
    assert set(model_payload["charges"]["elements"]) == {"Na", "Cl"}
    assert "default" in model_payload["charges"]["elements"]["Na"]
    assert "linear_map" in model_payload

    report_payload = json.loads(report_path.read_text())
    assert report_payload["n_samples"] == 3
    assert len(report_payload["rows"]) == 3
    assert report_payload["anchor_kind"] == "Cl"


def _write_outcar(path: Path, energy: float) -> None:
    path.write_text(
        "  energy  without entropy=         "
        f"{energy:.8f}"
        "  energy(sigma->0) =         "
        f"{energy:.8f}\n"
    )


def test_cli_fit_charge_pattern_mode_writes_dataset(tmp_path: Path, capsys) -> None:
    pos1 = tmp_path / "sample-001.vasp"
    pos2 = tmp_path / "sample-002.vasp"
    _write_poscar(pos1, (0.50, 0.50, 0.50))
    _write_poscar(pos2, (0.45, 0.50, 0.50))

    out1 = tmp_path / "OUTCAR-sample-001.vasp"
    out2 = tmp_path / "OUTCAR-sample-002.vasp"
    _write_outcar(out1, -10.0)
    _write_outcar(out2, -10.2)

    dataset_out = tmp_path / "dataset.txt"
    model_path = tmp_path / "charge_model.json"
    report_path = tmp_path / "fit_report.json"
    plot_path = tmp_path / "parity_plot.png"

    rc = cli_main(
        [
            "--json",
            "fit-charge",
            "-p",
            str(tmp_path / "sample-*.vasp"),
            "--outcar",
            str(tmp_path / "OUTCAR-sample-*.vasp"),
            "--anchor-kind",
            "Cl",
            "--maxiter",
            "25",
            "--dataset-out",
            str(dataset_out),
            "--out-model",
            str(model_path),
            "--out-report",
            str(report_path),
            "--out-plot",
            str(plot_path),
        ]
    )
    assert rc == 0

    payload = json.loads(capsys.readouterr().out)
    assert payload["dataset_generated"] is True
    assert payload["outputs"]["dataset"] == str(dataset_out.resolve())
    assert payload["outputs"]["parity_plot"] == str(plot_path.resolve())
    assert plot_path.exists()
    assert dataset_out.exists()
    lines = [line for line in dataset_out.read_text().splitlines() if line and not line.startswith("#")]
    assert len(lines) == 2


def test_cli_fc_alias_works(tmp_path: Path, capsys) -> None:
    pos1 = tmp_path / "sample-001.vasp"
    pos2 = tmp_path / "sample-002.vasp"
    _write_poscar(pos1, (0.50, 0.50, 0.50))
    _write_poscar(pos2, (0.45, 0.50, 0.50))

    dataset = tmp_path / "dataset.txt"
    dataset.write_text(f"{pos1} -10.0\n{pos2} -10.2\n")
    model_path = tmp_path / "charge_model.json"
    report_path = tmp_path / "fit_report.json"
    plot_path = tmp_path / "parity_plot.png"

    rc = cli_main(
        [
            "--json",
            "fc",
            str(dataset),
            "--anchor-kind",
            "Cl",
            "--maxiter",
            "20",
            "--out-model",
            str(model_path),
            "--out-report",
            str(report_path),
            "--out-plot",
            str(plot_path),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] in {"ok", "warn"}
    assert payload["outputs"]["model"] == str(model_path.resolve())
    assert payload["outputs"]["report"] == str(report_path.resolve())
    assert payload["outputs"]["parity_plot"] == str(plot_path.resolve())
    assert plot_path.exists()


def test_cli_fc_no_args_shows_help(capsys) -> None:
    rc = cli_main(["fc"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "usage: esspy fit-charge" in captured.out
    assert "--outcar" in captured.out
    assert "esspy fc -p 'sample-*.vasp' --outcar 'OUTCAR-sample-*.vasp'" in captured.out


def test_cli_fc_site_labels_write_model_and_validate_heldout(
    tmp_path: Path,
    capsys,
) -> None:
    train_shifts = [0.00, -0.04, -0.08, -0.12]
    train_energies = [-10.00, -10.08, -10.21, -10.37]
    for index, (shift, energy) in enumerate(zip(train_shifts, train_energies), 1):
        _write_site_labeled_poscar(tmp_path / f"sample-{index:03d}.vasp", shift)
        _write_outcar(tmp_path / f"OUTCAR-sample-{index:03d}.vasp", energy)

    model_path = tmp_path / "charge_model.json"
    report_path = tmp_path / "fit_report.json"
    plot_path = tmp_path / "parity_plot.png"
    rc = cli_main(
        [
            "--json",
            "fc",
            "-p",
            str(tmp_path / "sample-*.vasp"),
            "--outcar",
            str(tmp_path / "OUTCAR-sample-*.vasp"),
            "--anchor-kind",
            "Cl",
            "--maxiter",
            "20",
            "--out-model",
            str(model_path),
            "--out-report",
            str(report_path),
            "--out-plot",
            str(plot_path),
        ]
    )
    assert rc == 0
    summary = json.loads(capsys.readouterr().out)
    assert summary["outputs"]["model"] == str(model_path.resolve())
    assert summary["outputs"]["parity_plot"] == str(plot_path.resolve())
    assert plot_path.exists()

    model_payload = json.loads(model_path.read_text())
    assert model_payload["schema_version"] == 2
    assert model_payload["charge_basis"] == "element_site"
    assert model_payload["charges"]["basis"] == "element_site"
    assert set(model_payload["charges"]) == {"basis", "elements"}
    assert set(model_payload["charges"]["elements"]["Na"]["by_site"]) == {
        "site-001",
        "site-002",
    }
    assert set(model_payload["charges"]["elements"]["Cl"]["by_site"]) == {"site-003"}
    assert model_payload["kind_order"][0] == {
        "element": "Na",
        "site_group": "site-001",
        "label": "Na@site-001",
    }
    title = (tmp_path / "sample-001.vasp").read_text().splitlines()[0]
    assert "charges:" in title
    assert "Na@site-001=" in title
    assert "Na@site-002=" in title
    assert "Cl@site-003=" in title
    assert "RG=3" in title

    report_payload = json.loads(report_path.read_text())
    assert report_payload["config"]["charge_basis"] == "element_site"
    assert report_payload["anchor_kind"] == "Cl@site-003"

    heldout_shifts = [-0.02, -0.10]
    heldout_energies = [-10.04, -10.29]
    for index, (shift, energy) in enumerate(zip(heldout_shifts, heldout_energies), 1):
        _write_site_labeled_poscar(tmp_path / f"heldout-{index:03d}.vasp", shift)
        _write_outcar(tmp_path / f"OUTCAR-heldout-{index:03d}.vasp", energy)

    heldout_report = tmp_path / "heldout_report.json"
    heldout_plot = tmp_path / "heldout_parity.png"
    rc = cli_main(
        [
            "--json",
            "validate-model",
            "--charge-model",
            str(model_path),
            "-p",
            str(tmp_path / "heldout-*.vasp"),
            "--outcar",
            str(tmp_path / "OUTCAR-heldout-*.vasp"),
            "--out-report",
            str(heldout_report),
            "--out-plot",
            str(heldout_plot),
        ]
    )
    assert rc == 0
    heldout_summary = json.loads(capsys.readouterr().out)
    assert heldout_summary["status"] == "ok"
    assert heldout_summary["charges"]["basis"] == "element_site"
    assert heldout_summary["outputs"]["parity_plot"] == str(heldout_plot.resolve())
    assert heldout_plot.exists()

    heldout_payload = json.loads(heldout_report.read_text())
    assert heldout_payload["config"]["site_aware_charge_model"] is True
    assert heldout_payload["n_samples"] == 2


def test_cli_fc_uses_input_yaml_charges_for_site_aware_initial_guess(
    tmp_path: Path,
    capsys,
) -> None:
    for index, (shift, energy) in enumerate([(0.00, -20.0), (0.03, -20.2)], 1):
        _write_site_labeled_momgn_poscar(tmp_path / f"sample-{index:03d}.vasp", shift)
        _write_outcar(tmp_path / f"OUTCAR-sample-{index:03d}.vasp", energy)
    input_yaml = tmp_path / "input.yaml"
    input_yaml.write_text(
        "\n".join(
            [
                "structure:",
                "  poscar: POSCAR",
                "  dim: [1, 1, 1]",
                "composition:",
                "  fractions:",
                "    Mo: 0.25",
                "    Mg: 0.25",
                "    N: 0.5",
                "charges:",
                "  Mo: 6.0",
                "  Mg: 2.0",
                "  N: -3.0",
                "site_groups:",
                "  site1:",
                "    source_kind: M",
                "    count: 2",
                "    allowed: [Mo, Mg]",
                "  site2:",
                "    source_kind: N",
                "    count: 2",
                "    allowed: [N]",
            ]
        )
        + "\n"
    )

    report_path = tmp_path / "fit_report.json"
    model_path = tmp_path / "charge_model.json"
    rc = cli_main(
        [
            "--json",
            "fc",
            "-p",
            str(tmp_path / "sample-*.vasp"),
            "--outcar",
            str(tmp_path / "OUTCAR-sample-*.vasp"),
            "--input",
            str(input_yaml),
            "--maxiter",
            "1",
            "--out-report",
            str(report_path),
            "--out-model",
            str(model_path),
            "--no-update-poscar-titles",
        ]
    )

    assert rc == 0
    _ = json.loads(capsys.readouterr().out)
    report = json.loads(report_path.read_text())
    assert report["baseline"]["charges"]["Mo@site-001"] == 6.0
    assert report["baseline"]["charges"]["Mg@site-001"] == 2.0
    assert report["baseline"]["charges"]["N@site-002"] == -3.0
    model = json.loads(model_path.read_text())
    assert model["charges"]["basis"] == "element_site"
    assert "N" in model["charges"]["elements"]
    assert model["charges"]["elements"]["N"]["by_site"]["site-002"] < 0.0
