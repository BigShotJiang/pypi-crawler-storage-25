from esspy import (
    AddSitesMonteCarloOptions,
    Lattice,
    Site,
    StructureModel,
    run_add_sites_monte_carlo_mpi,
)


def _base_structure() -> StructureModel:
    return StructureModel(
        title="mc_base",
        lattice=Lattice(a=(4.0, 0.0, 0.0), b=(0.0, 4.0, 0.0), c=(0.0, 0.0, 4.0)),
        sites=[
            Site(kind="O", x=0.0, y=0.0, z=0.0, oxidation=-2.0),
            Site(kind="Mn", x=0.5, y=0.5, z=0.5, oxidation=2.0),
        ],
        fractional_coordinates=True,
    )


def _simple_spec() -> dict:
    return {
        "add_meshes": [0.5, 0.5, 0.5],
        "min_distance_between_added_sites": 0.1,
        "n_monte_carlo": 8,
        "monte_carlo_monitor_index": 2,
        "added_kinds": [
            {
                "kind": "Li",
                "n_added": 1,
                "oxidation": 1.0,
                "neighbor_kinds": [
                    {
                        "kind": "O",
                        "doxidation": 0.0,
                        "dist_min": 0.0,
                        "dist_max": 10000.0,
                    }
                ],
            }
        ],
    }


class _FakeComm:
    def __init__(self, rank: int, size: int, extra_entry: dict):
        self._rank = rank
        self._size = size
        self._extra_entry = extra_entry

    def Get_rank(self) -> int:
        return self._rank

    def Get_size(self) -> int:
        return self._size

    def allgather(self, local_payload: dict) -> list[dict]:
        return [local_payload, self._extra_entry]


def test_run_add_sites_monte_carlo_mpi_serial_mode_roundtrip():
    result = run_add_sites_monte_carlo_mpi(
        _base_structure(),
        _simple_spec(),
        AddSitesMonteCarloOptions(random_seed=7, rg_find_factor=1, chop_level=8.0),
        use_mpi=False,
    )

    assert result.success is True
    assert result.world_size == 1
    assert result.owner_rank == 0
    assert result.attempted_trials_total == 8
    assert result.accepted_trials_total >= 1


def test_run_add_sites_monte_carlo_mpi_selects_global_best_from_gathered():
    better_entry = {
        "rank": 1,
        "success": True,
        "best_energy": -999.0,
        "best_structure": {
            "title": "better",
            "lattice": {
                "a": [4.0, 0.0, 0.0],
                "b": [0.0, 4.0, 0.0],
                "c": [0.0, 0.0, 4.0],
            },
            "fractional_coordinates": True,
            "sites": [
                {
                    "kind": "O",
                    "x": 0.0,
                    "y": 0.0,
                    "z": 0.0,
                    "oxidation": -2.0,
                },
                {
                    "kind": "Mn",
                    "x": 0.5,
                    "y": 0.5,
                    "z": 0.5,
                    "oxidation": 2.0,
                },
                {
                    "kind": "Li",
                    "x": 0.25,
                    "y": 0.25,
                    "z": 0.25,
                    "oxidation": 1.0,
                },
            ],
        },
        "accepted_trials": 3,
        "attempted_trials": 4,
        "log": ["trial=4 accepted=3 best_energy=-999.0"],
    }
    fake_comm = _FakeComm(rank=0, size=2, extra_entry=better_entry)

    result = run_add_sites_monte_carlo_mpi(
        _base_structure(),
        _simple_spec(),
        AddSitesMonteCarloOptions(random_seed=11, rg_find_factor=1, chop_level=8.0),
        use_mpi=True,
        comm=fake_comm,
    )

    assert result.success is True
    assert result.world_size == 2
    assert result.owner_rank == 1
    assert result.best_energy == -999.0
    assert result.attempted_trials_total == 8
    assert result.accepted_trials_total >= 3
