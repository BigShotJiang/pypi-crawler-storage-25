from __future__ import annotations

import pytest

from esspy.run_outputs import _validate_summary_invariants


def test_validate_summary_invariants_accepts_ordered_extrema():
    summary = {
        "solve": {
            "global_e_min": -10.0,
            "global_e_max": -5.0,
        }
    }
    _validate_summary_invariants(summary)


def test_validate_summary_invariants_rejects_inverted_extrema():
    summary = {
        "solve": {
            "global_e_min": 1.0,
            "global_e_max": -1.0,
        }
    }
    with pytest.raises(RuntimeError, match="Invariant violated"):
        _validate_summary_invariants(summary)
