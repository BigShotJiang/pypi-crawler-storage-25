"""Phase 29 — MPI-friendly scalar wire decomposition for the reducer."""
import pytest

from esspy import (
    LocalReductionScalars,
    PartialGlobalReductionSummary,
    combine_local_reduction_scalars,
    combine_local_reductions,
    extract_local_reduction_scalars,
)
from esspy.models import LocalReductionSummary


def _structure_payload(label_kind: str) -> dict:
    return {
        "title": "rank-best",
        "lattice": {
            "a": (1.0, 0.0, 0.0),
            "b": (0.0, 1.0, 0.0),
            "c": (0.0, 0.0, 1.0),
        },
        "sites": [
            {
                "kind": label_kind,
                "x": 0.0,
                "y": 0.0,
                "z": 0.0,
                "oxidation": 0.0,
            }
        ],
        "fractional_coordinates": True,
    }


def _summary_with_structures(rank: int, **kwargs) -> dict:
    base = {
        "rank": rank,
        "world_size": kwargs.pop("world_size", 4),
        "primary_recipe_index": kwargs.pop("primary_recipe_index", 0),
        "processed_chunks": kwargs.pop("processed_chunks", 1),
        "processed_candidates": kwargs.pop("processed_candidates", 1),
        "initial_offset": kwargs.pop("initial_offset", 0),
        "next_offset": kwargs.pop("next_offset", 1),
        "has_more": kwargs.pop("has_more", False),
        "exhaust_all": kwargs.pop("exhaust_all", False),
        "has_samples": kwargs.pop("has_samples", True),
        "local_e_min": kwargs.pop("local_e_min", 0.0),
        "local_e_max": kwargs.pop("local_e_max", 0.0),
        "local_best_candidate_index": kwargs.pop("local_best", 0),
        "local_worst_candidate_index": kwargs.pop("local_worst", 0),
        "local_de_min_swap": kwargs.pop("local_de_min_swap", 0.0),
        "local_swap_count": kwargs.pop("local_swap_count", 0),
    }
    best_kind = kwargs.pop("best_kind", None)
    worst_kind = kwargs.pop("worst_kind", None)
    if best_kind is not None:
        base["local_best_structure"] = _structure_payload(best_kind)
        base["local_best_structure_present"] = True
    if worst_kind is not None:
        base["local_worst_structure"] = _structure_payload(worst_kind)
        base["local_worst_structure_present"] = True
    if kwargs:
        base.update(kwargs)
    return base


def test_extract_scalars_drops_structures_but_keeps_presence_flags():
    summary = _summary_with_structures(
        rank=2,
        local_e_min=-1.5,
        local_e_max=2.0,
        best_kind="best-X",
        worst_kind="worst-Y",
    )
    scalars = extract_local_reduction_scalars(summary)

    assert isinstance(scalars, LocalReductionScalars)
    assert scalars.rank == 2
    assert scalars.local_e_min == pytest.approx(-1.5)
    assert scalars.local_e_max == pytest.approx(2.0)
    # Presence flags travel with the scalars even though the structures
    # themselves do not.
    assert scalars.local_best_structure_present is True
    assert scalars.local_worst_structure_present is True


def test_extract_scalars_handles_missing_structure_fields():
    """When the input lacks structures, the scalars carry presence=false
    and the wire transport carries no structure information."""
    summary = LocalReductionSummary(
        rank=0,
        local_e_min=-7.0,
        local_e_max=-3.0,
        has_samples=True,
    )
    scalars = extract_local_reduction_scalars(summary)
    assert scalars.local_best_structure_present is False
    assert scalars.local_worst_structure_present is False


def test_combine_scalars_returns_partial_summary_without_structures():
    inputs = [
        extract_local_reduction_scalars(
            _summary_with_structures(
                rank=0, local_e_min=-50.0, local_e_max=-20.0,
                best_kind="r0-best", worst_kind="r0-worst",
            )
        ),
        extract_local_reduction_scalars(
            _summary_with_structures(
                rank=1, local_e_min=-80.0, local_e_max=-30.0,
                best_kind="r1-best", worst_kind="r1-worst",
            )
        ),
    ]

    partial = combine_local_reduction_scalars(inputs)
    assert isinstance(partial, PartialGlobalReductionSummary)
    # Energy ownership matches the same rule the structured reducer
    # uses, so partial / full reducer agreement is exact for these
    # fields.
    assert partial.global_e_min == pytest.approx(-80.0)
    assert partial.which_rank_global_e_min == 1
    assert partial.global_e_max == pytest.approx(-20.0)
    assert partial.which_rank_global_e_max == 0
    # Structure presence flags propagate so the caller can decide
    # whether to expect a broadcast from the chosen rank.
    assert partial.global_best_structure_present is True
    assert partial.global_worst_structure_present is True


def test_combine_scalars_agrees_with_structured_reducer_on_energy_fields():
    raw_summaries = [
        _summary_with_structures(
            rank=0, local_e_min=-30.0, local_e_max=10.0,
            best_kind="A-best", worst_kind="A-worst",
        ),
        _summary_with_structures(
            rank=1, local_e_min=-15.0, local_e_max=25.0,
            best_kind="B-best", worst_kind="B-worst",
            local_de_min_swap=-1.5, local_swap_count=4,
        ),
        _summary_with_structures(
            rank=2, local_e_min=-25.0, local_e_max=8.0,
            best_kind="C-best", worst_kind="C-worst",
        ),
    ]

    full = combine_local_reductions(raw_summaries)
    scalars_inputs = [extract_local_reduction_scalars(s) for s in raw_summaries]
    partial = combine_local_reduction_scalars(scalars_inputs)

    assert partial.global_e_min == pytest.approx(full.global_e_min)
    assert partial.global_e_max == pytest.approx(full.global_e_max)
    assert partial.which_rank_global_e_min == full.which_rank_global_e_min
    assert partial.which_rank_global_e_max == full.which_rank_global_e_max
    assert partial.global_de_min_swap == pytest.approx(full.global_de_min_swap)
    assert partial.global_swap_count == full.global_swap_count
    assert partial.total_processed_candidates == full.total_processed_candidates
    assert partial.contributing_ranks == full.contributing_ranks
    assert partial.has_samples == full.has_samples
    assert partial.primary_recipe_index == full.primary_recipe_index
    assert partial.primary_recipe_consistent == full.primary_recipe_consistent


def test_combine_scalars_skips_non_contributing_ranks():
    inputs = [
        extract_local_reduction_scalars(
            _summary_with_structures(
                rank=0,
                has_samples=False,
                local_e_min=-1000.0,
                local_e_max=1000.0,
                best_kind="ghost",
                worst_kind="ghost",
            )
        ),
        extract_local_reduction_scalars(
            _summary_with_structures(
                rank=1,
                local_e_min=-15.0,
                local_e_max=-5.0,
                best_kind="real",
                worst_kind="real",
            )
        ),
    ]
    partial = combine_local_reduction_scalars(inputs)
    assert partial.contributing_ranks == 1
    assert partial.which_rank_global_e_min == 1
    assert partial.which_rank_global_e_max == 1


def test_combine_scalars_empty_input_returns_no_samples():
    partial = combine_local_reduction_scalars([])
    assert partial.world_size == 0
    assert partial.contributing_ranks == 0
    assert partial.has_samples is False
    assert partial.which_rank_global_e_min == -1
    assert partial.which_rank_global_e_max == -1
    assert partial.global_best_structure_present is False
    assert partial.global_worst_structure_present is False


def test_extract_scalars_round_trip_via_dict_payload():
    """Ensure the typed extractor accepts both dataclass and dict
    inputs (so callers can feed solve()-produced dicts directly)."""
    summary_dict = _summary_with_structures(
        rank=5, local_e_min=-2.0, local_e_max=3.0
    )
    scalars = extract_local_reduction_scalars(summary_dict)
    assert scalars.rank == 5
    assert scalars.local_e_min == pytest.approx(-2.0)
    assert scalars.local_e_max == pytest.approx(3.0)
