"""Phase 80 — `esspy convert` command family regression coverage."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from esspy.cli import main as cli_main
from esspy.convert import ready_path_to_poscar_text, ready_to_poscar_text
from esspy.poscar import load_poscar
from esspy.ready_text import parse_ready_text


READY_G003 = Path(
    "tests/golden/fixtures/G003_M6O8/basic_properties_EwaldSolidSolution.ready.txt"
)
READY_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolution.ready.txt"
)
GUIDER_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
)


def _run_cli(argv: list[str], capsys) -> str:
    rc = cli_main(argv)
    assert rc == 0
    captured = capsys.readouterr()
    return captured.out


def _last_json_line(output: str) -> dict:
    return json.loads(output.strip().splitlines()[-1])


def test_ready_to_poscar_text_round_trips_through_load_poscar(tmp_path: Path):
    """Convert a ready file to POSCAR text and re-parse it through the
    POSCAR loader. Lattice + per-site (kind, x, y, z) must survive the
    round-trip exactly within numerical tolerance."""
    doc = parse_ready_text(READY_G003)
    text = ready_to_poscar_text(doc)
    out_path = tmp_path / "round_trip.vasp"
    out_path.write_text(text)

    structure = load_poscar(out_path)
    assert len(structure.sites) == doc.n_atom_config
    assert structure.fractional_coordinates is True
    # Lattice vectors agree to 10 decimal places (the precision the
    # writer emits).
    assert structure.lattice.a == pytest.approx(doc.vec_a, abs=1.0e-9)
    assert structure.lattice.b == pytest.approx(doc.vec_b, abs=1.0e-9)
    assert structure.lattice.c == pytest.approx(doc.vec_c, abs=1.0e-9)


def test_ready_to_poscar_groups_species_correctly():
    """G003 ready holds 6 M sites then 8 O sites — the POSCAR species /
    count block must mirror that grouping."""
    doc = parse_ready_text(READY_G003)
    text = ready_to_poscar_text(doc)
    lines = text.splitlines()
    # Line 5 is the species block (after title, scale, vec_a/b/c).
    species = lines[5].split()
    counts = [int(token) for token in lines[6].split()]
    assert species == ["M", "O"]
    assert counts == [6, 8]


def test_ready_to_poscar_uses_output_prefix_as_default_title():
    doc = parse_ready_text(READY_G003)
    text = ready_to_poscar_text(doc)
    assert text.splitlines()[0] == doc.output_prefix


def test_ready_to_poscar_explicit_title_override():
    doc = parse_ready_text(READY_G003)
    text = ready_to_poscar_text(doc, title="custom_title")
    assert text.splitlines()[0] == "custom_title"


def test_ready_path_to_poscar_text_helper(tmp_path: Path):
    text = ready_path_to_poscar_text(READY_G001)
    # G001 ready holds 2 Mn + 4 Cr + 8 O = 14 sites total.
    structure_lines = [line for line in text.splitlines() if line and not line.startswith(" ")]
    assert "Direct" in structure_lines or "Direct" in text


def test_cli_convert_ready_to_poscar_to_stdout(capsys):
    output = _run_cli(["convert", "ready-to-poscar", str(READY_G003)], capsys)
    # The POSCAR title is on the first line; it should match
    # G003's output_prefix.
    first_line = output.splitlines()[0]
    assert first_line == "M6O8_spinel_recovery_001"


def test_cli_convert_ready_to_poscar_writes_file(tmp_path: Path, capsys):
    out_path = tmp_path / "g003.POSCAR.vasp"
    output = _run_cli(
        ["convert", "ready-to-poscar", str(READY_G003), "--out", str(out_path)],
        capsys,
    )
    payload = _last_json_line(output)
    assert payload["out"] == str(out_path)
    assert out_path.exists()
    structure = load_poscar(out_path)
    assert len(structure.sites) == 14


def test_cli_convert_guider_to_yaml_round_trips(tmp_path: Path, capsys):
    """`convert guider-to-yaml` is functionally identical to
    `init from-guider`; it must produce a YAML that
    `guide export-guider` can re-export to a semantically equivalent
    guider text."""
    out_path = tmp_path / "input.yaml"
    output = _run_cli(
        [
            "convert",
            "guider-to-yaml",
            str(GUIDER_G001),
            "--out",
            str(out_path),
        ],
        capsys,
    )
    payload = _last_json_line(output)
    assert payload["out"] == str(out_path)
    assert out_path.exists()
    yaml_payload = yaml.safe_load(out_path.read_text())
    assert yaml_payload["name"] == "CCS02_allocation"
    assert "legacy_source" in yaml_payload


def test_cli_convert_yaml_to_guider_round_trips_with_init_from_guider(
    tmp_path: Path, capsys
):
    """convert guider-to-yaml -> convert yaml-to-guider -> parse_guider_text
    must agree with the original guider text on every key field.
    """
    from esspy.guider_text import parse_guider_text

    yaml_path = tmp_path / "input.yaml"
    _run_cli(
        [
            "convert",
            "guider-to-yaml",
            str(GUIDER_G001),
            "--out",
            str(yaml_path),
        ],
        capsys,
    )
    re_exported_path = tmp_path / "re-exported.txt"
    _run_cli(
        [
            "convert",
            "yaml-to-guider",
            str(yaml_path),
            "--out",
            str(re_exported_path),
        ],
        capsys,
    )

    original = parse_guider_text(GUIDER_G001)
    re_exported = parse_guider_text(re_exported_path)
    assert re_exported.target_fractions == pytest.approx(
        original.target_fractions
    )
    assert re_exported.charges == pytest.approx(original.charges)
    assert re_exported.n_target_sites == original.n_target_sites
    assert re_exported.space_group == original.space_group
    assert [(r.from_kind, list(r.to)) for r in re_exported.recipes] == [
        (r.from_kind, list(r.to)) for r in original.recipes
    ]


def test_cli_convert_yaml_to_guider_to_stdout(tmp_path: Path, capsys):
    yaml_path = tmp_path / "input.yaml"
    _run_cli(
        [
            "convert",
            "guider-to-yaml",
            str(GUIDER_G001),
            "--out",
            str(yaml_path),
        ],
        capsys,
    )
    capsys.readouterr()  # drain the previous command's stdout
    rc = cli_main(["convert", "yaml-to-guider", str(yaml_path)])
    assert rc == 0
    captured = capsys.readouterr()
    # The re-exported guider text starts with `Target` line.
    assert captured.out.startswith("Target")


def test_convert_help_when_no_subcommand(capsys):
    """Bare `esspy convert` prints convert family help and exits 0."""
    rc = cli_main(["convert"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "usage: esspy convert" in captured.out
    for name in (
        "guider-to-yaml",
        "yaml-to-guider",
        "ready-to-poscar",
        "poscar-to-yaml",
        "solver-addsites-to-json",
    ):
        assert name in captured.out
