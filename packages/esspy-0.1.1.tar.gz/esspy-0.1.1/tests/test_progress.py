from __future__ import annotations

import json
from pathlib import Path

from esspy.models import LoggingOptions
from esspy.progress import ProgressReporter


def test_progress_reporter_enriches_native_chunk_with_eta(tmp_path: Path):
    reporter = ProgressReporter(
        tmp_path,
        LoggingOptions(console=False, file=True, progress_jsonl=True, per_rank_logs=False),
    )

    reporter.emit(
        "solve.chunk",
        processed_candidates=10,
        available_count=100,
        next_offset=20,
        active_stride=2,
        native_elapsed_sec=5.0,
    )

    event = json.loads((tmp_path / "logs" / "progress.jsonl").read_text().splitlines()[-1])
    assert event["progress_percent"] == 20.0
    assert event["candidate_rate_per_sec"] == 2.0
    assert event["remaining_candidate_estimate"] == 40
    assert event["eta_sec"] == 20.0
    assert "eta=20.0s" in (tmp_path / "summary.log").read_text()


def test_progress_reporter_omits_eta_without_candidate_counts(tmp_path: Path):
    reporter = ProgressReporter(
        tmp_path,
        LoggingOptions(console=False, file=True, progress_jsonl=True, per_rank_logs=False),
    )

    reporter.emit("guide.done", n_atoms=14)

    event = json.loads((tmp_path / "logs" / "progress.jsonl").read_text().splitlines()[-1])
    assert "eta_sec" not in event
    assert "candidate_rate_per_sec" not in event


def test_progress_reporter_throttles_nested_events_in_logs(tmp_path: Path):
    reporter = ProgressReporter(
        tmp_path,
        LoggingOptions(
            console=False,
            file=True,
            progress_jsonl=True,
            per_rank_logs=True,
            interval_sec=60.0,
        ),
    )

    for index in range(100):
        reporter.emit(
            "solve.nested",
            secondary_recipe_index=1,
            secondary_index=1,
            secondary_jobsize=1,
            processed_candidates=index,
        )

    assert (tmp_path / "summary.log").read_text().count("solve.nested") == 1
    assert (tmp_path / "logs" / "progress.jsonl").read_text().count("solve.nested") == 1
    assert (tmp_path / "logs" / "rank-000.log").read_text().count("solve.nested") == 1


def test_progress_reporter_nested_logs_energy_context(tmp_path: Path):
    reporter = ProgressReporter(
        tmp_path,
        LoggingOptions(console=False, file=True, progress_jsonl=True, per_rank_logs=False),
    )

    reporter.emit(
        "solve.nested",
        secondary_recipe_index=2,
        secondary_index=1,
        secondary_jobsize=1,
        processed_candidates=9138641,
        native_elapsed_sec=530.0,
        solve_budget_sec=600.0,
        local_e_min=-5509.912345,
        best_so_far_energy=-5510.336239,
    )

    line = (tmp_path / "summary.log").read_text()
    assert "solve_elapsed=8.8m/10.0m" in line
    assert "remaining=1.2m" in line
    assert "window_E_min=-5509.9123 eV" in line
    assert "best_so_far=-5510.3362 eV" in line
    assert "window_minus_best=+0.4239 eV" in line


def test_progress_reporter_shows_strategy_fields_in_solve_started(tmp_path: Path):
    reporter = ProgressReporter(
        tmp_path,
        LoggingOptions(console=False, file=True, progress_jsonl=False, per_rank_logs=False),
    )

    reporter.emit(
        "solve.started",
        strategy_mode="adaptive",
        strategy_time_budget_sec=3600,
        strategy_effort="high",
        enumeration_save_memory=True,
        swap=True,
        max_swap=100,
        running_index_delta=-3600,
    )

    line = (tmp_path / "summary.log").read_text()
    assert "mode=adaptive, budget=3600s, effort=high" in line
