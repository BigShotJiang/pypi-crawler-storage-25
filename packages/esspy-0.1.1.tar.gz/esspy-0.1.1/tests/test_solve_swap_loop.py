from pathlib import Path

import pytest

from esspy import (
    SwapLoopOptions,
    SwapLoopResult,
    compute_swap_loop,
)
from esspy.native import load_native_module
from tests.golden.ready_parser import parse_ready_file
from tests.golden.references import G003_M6O8_READY


def _g003_ready_payload() -> dict:
    ready = parse_ready_file(Path(G003_M6O8_READY))
    return {
        "lattice": {
            "a": (5.1772941, -0.00001875, 2.98909804),
            "b": (1.7257584, 4.88119953, 2.98909789),
            "c": (-0.00002168, -0.00001523, 5.97823435),
        },
        "atoms": [
            {
                "kind": atom.kind,
                "oxidation": atom.oxidation,
                "x": atom.x,
                "y": atom.y,
                "z": atom.z,
            }
            for atom in ready.atom_config
        ],
        "supercell_expansion": ready.supercell_expansion,
        "rg_find_factor": ready.rg_find_factor,
        "output_prefix": ready.output_prefix,
        "recipes": [
            {
                "from": recipe.kind,
                "oxidation": recipe.oxidation,
                "random_pickup": recipe.random_pickup,
                "random_pickup_trial": recipe.random_pickup_trial,
                "modifications": [
                    {
                        "to": mod.kind,
                        "oxidation": mod.oxidation,
                        "count": mod.count,
                    }
                    for mod in recipe.modifications
                ],
            }
            for recipe in ready.recipes
        ],
    }


def _tiny_ready_payload() -> dict:
    """A 1×1×1 lattice with one recipe and three Mn → Cr,Ni assigned sites.

    The lattice is a simple cubic 4 Å cell to keep the Ewald sum cheap.
    The recipe lays out [Cr, Ni, Mn] in the canonical order; any swap
    that exchanges two of those kinds reshuffles the assignment and
    changes the total energy. This makes the swap loop easy to drive in
    deterministic tests without depending on a frozen golden fixture.
    """

    return {
        "lattice": {
            "a": (4.0, 0.0, 0.0),
            "b": (0.0, 4.0, 0.0),
            "c": (0.0, 0.0, 4.0),
        },
        "atoms": [
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.5, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.5, "z": 0.0},
            {"kind": "O", "oxidation": -2.0, "x": 0.5, "y": 0.5, "z": 0.5},
        ],
        "supercell_expansion": (1, 1, 1),
        "rg_find_factor": 1,
        "output_prefix": "tiny",
        "recipes": [
            {
                "from": "Mn",
                "oxidation": 2.0,
                "random_pickup": 3,
                "random_pickup_trial": 1,
                "modifications": [
                    {"to": "Cr", "oxidation": 3.0, "count": 1},
                    {"to": "Ni", "oxidation": 1.0, "count": 1},
                ],
            },
        ],
    }


def test_swap_loop_returns_typed_result_for_tiny_ready():
    native = load_native_module()
    result = native.compute_swap_loop(
        _tiny_ready_payload(),
        {"mode": 1, "max_swap": 5, "rg_find_factor": 1, "chop_level": 8.0},
    )

    assert "final_structure" in result
    assert "initial_total_energy" in result
    assert "final_total_energy" in result
    assert "de_min_swap" in result
    assert "swap_count" in result
    assert isinstance(result["committed_swaps"], list)
    assert result["cache_stats"]["full_evaluations"] == 0
    assert result["cache_stats"]["diff_evaluations"] >= 1
    assert result["cache_stats"]["real_cache_evaluations"] >= 1
    assert result["cache_stats"]["point_cache_evaluations"] >= 1
    assert result["cache_stats"]["recip_cache_evaluations"] >= 1
    assert result["cache_stats"]["recip_state_rebuilds"] >= 1
    assert result["cache_stats"]["recip_fallback_evaluations"] == 0
    assert result["cache_stats"]["real_pair_terms"] > 0
    assert result["cache_stats"]["recip_kpoint_terms"] > 0
    assert result["cache_stats"]["diff_cache_enabled"] is True
    # Final structure must preserve the supercell site count.
    assert len(result["final_structure"]["sites"]) == 4


def test_swap_loop_de_min_swap_is_non_positive():
    """A correctly extracted swap loop never increases total energy.

    Each accepted swap requires `denrg < 0`, so `de_min_swap = final -
    initial` must always be <= 0 within numerical tolerance regardless of
    whether the loop converged or hit max_swap.
    """
    native = load_native_module()
    result = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 1, "max_swap": 5}
    )
    assert result["de_min_swap"] <= 1.0e-12


def test_swap_loop_zero_max_swap_runs_until_no_improvement():
    native = load_native_module()
    result = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 1, "max_swap": 0}
    )
    assert result["stopped_by_no_improvement"] is True
    assert result["stopped_by_max_swap"] is False


def test_swap_loop_max_swap_one_caps_rounds_when_more_progress_remains():
    native = load_native_module()
    result_one = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 1, "max_swap": 1}
    )
    if not result_one["stopped_by_max_swap"]:
        pytest.skip("tiny case converged in a single round; cap was not hit")
    assert result_one["swap_count"] == 1


def test_swap_loop_first_improvement_mode_yields_valid_result():
    # Mode-2 acceptance traces can differ from mode-1 (it commits the
    # first improving swap rather than the best one), but the same
    # invariants must hold: site count preserved and de_min_swap
    # non-positive.
    native = load_native_module()
    result = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 2, "max_swap": 5}
    )
    assert len(result["final_structure"]["sites"]) == 4
    assert result["de_min_swap"] <= 1.0e-12


def test_swap_loop_committed_log_entries_match_swap_count():
    native = load_native_module()
    result = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 1, "max_swap": 5}
    )
    # Each committed swap is one acceptance; rounds may commit per-recipe
    # so committed_swaps.size() can match or exceed swap_count when there
    # is more than one recipe. With one recipe the two must agree.
    assert len(result["committed_swaps"]) == result["swap_count"]


def test_typed_wrapper_round_trips_native_result():
    typed = compute_swap_loop(
        _tiny_ready_payload(), SwapLoopOptions(mode=1, max_swap=5)
    )
    assert isinstance(typed, SwapLoopResult)
    assert len(typed.final_structure.sites) == 4
    assert typed.de_min_swap <= 1.0e-12
    assert typed.cache_stats.full_evaluations == 0
    assert typed.cache_stats.diff_evaluations >= 1
    assert typed.cache_stats.real_cache_evaluations >= 1
    assert typed.cache_stats.point_cache_evaluations >= 1
    assert typed.cache_stats.recip_cache_evaluations >= 1
    assert typed.cache_stats.recip_state_rebuilds >= 1
    assert typed.cache_stats.recip_fallback_evaluations == 0
    assert typed.cache_stats.real_pair_terms > 0
    assert typed.cache_stats.recip_kpoint_terms > 0
    assert typed.cache_stats.diff_cache_enabled is True
    assert len(typed.committed_swaps) == typed.swap_count


def test_swap_loop_invalid_mode_raises():
    native = load_native_module()
    with pytest.raises(Exception):
        native.compute_swap_loop(
            _tiny_ready_payload(), {"mode": 7, "max_swap": 1}
        )


def test_swap_loop_g003_one_round_lowers_energy_or_keeps_it():
    """Run a single swap round on the G003 fixture.

    G003 is large enough that a full convergent loop would be slow, so we
    cap at a single round to keep the test bounded. The swap loop must
    still leave the structure energetically consistent: `de_min_swap`
    must be <= 0 within tolerance (zero if no improving swap exists at
    the canonical state, negative otherwise).
    """
    native = load_native_module()
    result = native.compute_swap_loop(
        _g003_ready_payload(),
        {"mode": 2, "max_swap": 1, "rg_find_factor": 1, "chop_level": 8.0},
    )
    assert result["de_min_swap"] <= 1.0e-9
    # Structure shape preserved.
    assert len(result["final_structure"]["sites"]) == 112


def test_probe_swap_real_delta_matches_recomputed_real_energy():
    native = load_native_module()
    payload = _tiny_ready_payload()
    probe = native.probe_swap_real_delta(payload, 0, 1, 1, 8.0)
    assert probe["cache_stats"]["diff_cache_enabled"] is True
    assert probe["cache_stats"]["diff_evaluations"] >= 2
    assert probe["cache_stats"]["real_cache_evaluations"] >= 2
    assert probe["cache_stats"]["point_cache_evaluations"] >= 2
    assert probe["cache_stats"]["recip_cache_evaluations"] >= 2
    assert probe["cache_stats"]["recip_state_rebuilds"] >= 1
    assert probe["cache_stats"]["recip_fallback_evaluations"] == 0
    assert probe["predicted_after"] == pytest.approx(probe["after"], abs=1.0e-9)
    assert probe["point_delta"] == pytest.approx(0.0, abs=1.0e-12)
    assert probe["before_point"] == pytest.approx(probe["after_point"], abs=1.0e-12)
    assert probe["before_recip"] + probe["recip_delta"] == pytest.approx(probe["after_recip"], abs=1.0e-9)


def test_swap_loop_reciprocal_state_updates_incrementally_after_acceptance():
    native = load_native_module()
    result = native.compute_swap_loop(
        _tiny_ready_payload(),
        {"mode": 1, "max_swap": 1, "rg_find_factor": 1, "chop_level": 8.0},
    )
    if result["swap_count"] == 0:
        pytest.skip("tiny case did not accept a swap")
    assert result["cache_stats"]["recip_incremental_updates"] >= 1
