from pathlib import Path

from esspy import (
    parse_guider_text_to_guide_input_native,
    parse_wyc_file_to_symmetry_model,
    write_poscar_text,
)
from esspy.native import load_native_module


GUIDER_G004 = Path(
    "tests/golden/fixtures/G004_CCS02_P1_ADDED/basic_properties_EwaldSolidSolutionGuider.txt"
)
WYC_G004 = Path("tests/golden/fixtures/G004_CCS02_P1_ADDED/1.wyc")
POSCAR_G004 = Path(
    "tests/golden/fixtures/G004_CCS02_P1_ADDED/CCS02_formalcharge_MnCr2O4.vasp"
)
POSCAR_G004_SEEDED = Path(
    "tests/golden/fixtures/G004_CCS02_P1_ADDED/CCS02_formalcharge_MnCr2O4.seeded.vasp"
)


def _g004_ready_dict():
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(GUIDER_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)
    guide_input["symmetry"]["wyc_operations"] = [list(op.matrix) for op in symmetry.wyc_operations]
    guide_input["options"]["fixed_rg_find_factor"] = 3
    return native.guide(guide_input)["ready"]


def test_g004_poscar_writer_is_byte_exact_for_seeded_fixture():
    ready = _g004_ready_dict()
    actual = write_poscar_text(ready)
    expected = POSCAR_G004_SEEDED.read_text()
    assert actual == expected


def test_g004_poscar_writer_preserves_zero_count_species():
    ready = _g004_ready_dict()
    text = write_poscar_text(ready)
    lines = text.splitlines()
    assert lines[5] == " Mn Cr O Ni"
    assert lines[6] == " 19 6 8 0"


def test_g004_poscar_writer_preserves_original_species_count_signature():
    ready = _g004_ready_dict()
    generated = write_poscar_text(ready).splitlines()
    original = POSCAR_G004.read_text().splitlines()
    assert generated[5] == original[5]
    assert generated[6] == original[6]
    assert len(generated[8:]) == len(original[8:])
