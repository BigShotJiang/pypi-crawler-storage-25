from __future__ import annotations

from esspy.models import Lattice
from esspy.supercell_search import search_supercell


def test_supercell_search_exact_cubic_target():
    lattice = Lattice(
        a=(5.0, 0.0, 0.0),
        b=(0.0, 5.0, 0.0),
        c=(0.0, 0.0, 5.0),
    )

    result = search_supercell(
        lattice,
        n_base_atoms=2,
        n_target_atoms=16,
        mode="near_cubic",
    )

    assert result.selected.dim == (2, 2, 2)
    assert result.selected.n_atoms == 16
    assert result.selected.count_error == 0.0


def test_supercell_search_near_target_does_not_require_exact_count():
    lattice = Lattice(
        a=(5.0, 0.0, 0.0),
        b=(0.0, 6.0, 0.0),
        c=(0.0, 0.0, 7.0),
    )

    result = search_supercell(
        lattice,
        n_base_atoms=14,
        n_target_atoms=300,
        mode="axis_balanced",
        top=5,
    )

    assert result.selected.n_atoms > 0
    assert result.selected.count_error <= 0.50
    assert 1 <= len(result.candidates) <= 5
