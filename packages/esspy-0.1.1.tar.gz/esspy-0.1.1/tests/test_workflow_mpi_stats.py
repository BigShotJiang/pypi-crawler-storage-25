from __future__ import annotations

from esspy.workflow import _compute_mpi_stats


def test_compute_mpi_stats_basic():
    stats = _compute_mpi_stats(
        [
            {"rank": 0, "processed_candidates": 100},
            {"rank": 1, "processed_candidates": 50},
            {"rank": 2, "processed_candidates": 0},
        ]
    )
    assert stats["world_size"] == 3
    assert stats["total_processed_candidates"] == 150
    assert stats["idle_ranks"] == 1
    assert stats["active_ranks"] == 2
    assert stats["min_processed_candidates"] == 0
    assert stats["max_processed_candidates"] == 100


def test_compute_mpi_stats_np_2_4_8_regression_shape():
    for world_size in (2, 4, 8):
        scalars = [
            {"rank": rank, "processed_candidates": (1000 - rank * 10)}
            for rank in range(world_size)
        ]
        stats = _compute_mpi_stats(scalars)
        assert stats["world_size"] == world_size
        assert len(stats["processed_by_rank"]) == world_size
        assert stats["total_processed_candidates"] == sum(
            s["processed_candidates"] for s in scalars
        )
        assert stats["active_ranks"] == world_size
        assert stats["idle_ranks"] == 0
