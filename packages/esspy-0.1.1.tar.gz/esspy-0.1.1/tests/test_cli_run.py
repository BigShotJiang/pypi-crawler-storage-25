from __future__ import annotations

import json
from pathlib import Path

from esspy.cli import main


def _write_run_yaml(path: Path) -> Path:
    poscar = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()
    path.write_text(
        "name: CCS02_run\n"
        "structure:\n"
        "  title: CCS02_run\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 112\n"
        "  number_fixed_at: O\n"
        "composition:\n"
        "  counts:\n"
        "    Mn: 14\n"
        "    Cr: 15\n"
        "    Ni: 19\n"
        "    O: 64\n"
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n"
        "recipes:\n"
        "  - from: Mn\n"
        "    to: [Mn, Ni]\n"
        "  - from: Cr\n"
        "    to: [Cr, Ni]\n"
        "symmetry:\n"
        "  space_group: 1\n"
        "guide:\n"
        "  fixed_rg_find_factor: 1\n"
        "  strict_no_added_sites: true\n"
        "  skip_ewald_evaluation: true\n"
        "solve:\n"
        "  swap: true\n"
        "  max_swap: 2\n"
        "runtime:\n"
        "  use_mpi: false\n"
        "output:\n"
        "  prefix: CCS02_run\n"
    )
    return path


def _append_output_overrides(path: Path, text: str) -> Path:
    original = path.read_text()
    original = original.split("output:\n", 1)[0]
    path.write_text(original + text)
    return path


def test_cli_run_guide_only_writes_outputs(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    workdir = tmp_path / "run"

    rc = main(["--json", "run", str(input_path), "--workdir", str(workdir), "--guide-only"])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["guide_only"] is True
    assert payload["solve"] is None
    assert Path(payload["outputs"]["guider"]).exists()
    assert Path(payload["outputs"]["ready"]).exists()
    assert Path(payload["outputs"]["poscar"]).exists()
    assert Path(payload["outputs"]["summary"]).exists()
    assert "NAtomConfig" in Path(payload["outputs"]["ready"]).read_text()


def test_cli_run_respects_output_schema_filenames_and_flags(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    _append_output_overrides(
        input_path,
        "output:\n"
        "  prefix: custom_prefix\n"
        "  guider_filename: custom.guider.txt\n"
        "  ready_filename: custom.ready.txt\n"
        "  poscar_filename: custom.POSCAR\n"
        "  best_poscar_filename: custom.best.POSCAR\n"
        "  worst_poscar_filename: custom.worst.POSCAR\n"
        "  energy_filename: custom.energies.txt\n"
        "  input_filename: input.yaml\n"
        "  summary_filename: custom.summary.json\n"
        "  write_guider: false\n"
        "  write_ready: true\n"
        "  write_poscar: true\n"
        "  write_summary_json: true\n",
    )
    workdir = tmp_path / "custom-run"

    rc = main(["--json", "run", str(input_path), "--workdir", str(workdir), "--guide-only"])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert "guider" not in payload["outputs"]
    assert payload["outputs"]["ready"] == str(workdir / "custom.ready.txt")
    assert payload["outputs"]["poscar"] == str(workdir / "custom.POSCAR")
    assert payload["outputs"]["summary"] == str(workdir / "custom.summary.json")
    assert payload["outputs"]["input_yaml"] == str(workdir / "input.yaml")
    assert not (workdir / "custom.guider.txt").exists()
    assert (workdir / "custom.ready.txt").exists()


def test_cli_run_full_writes_summary(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    workdir = tmp_path / "run-full"

    rc = main(["--json", "run", str(input_path), "--workdir", str(workdir)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["guide_only"] is False
    assert payload["solve"]["global_count_total"] > 0
    assert payload["solve"]["energy_table_count"] > 0
    summary = json.loads(Path(payload["outputs"]["summary"]).read_text())
    assert summary["workdir"] == str(workdir)
    assert summary["outputs"]["summary"] == payload["outputs"]["summary"]
    
    assert "best_poscar" in payload["outputs"]
    assert "worst_poscar" in payload["outputs"]
    assert Path(payload["outputs"]["best_poscar"]).exists()
    assert Path(payload["outputs"]["worst_poscar"]).exists()
    
    best_text = Path(payload["outputs"]["best_poscar"]).read_text()
    assert "best" in best_text.splitlines()[0]
    assert "selection_dir" in payload["outputs"]
    assert "selection_index" in payload["outputs"]
    selection_dir = Path(payload["outputs"]["selection_dir"])
    assert selection_dir.exists()
    selected_files = sorted(selection_dir.glob("selected-*.vasp"))
    assert len(selected_files) > 0
    assert len(selected_files) <= 20
    assert Path(payload["outputs"]["selection_index"]).exists()
    summary_log = Path(payload["outputs"]["log"]).read_text()
    assert "ESSPY run finished" in summary_log
    assert "Solve stage" in summary_log
    assert "Artifacts" in summary_log
    assert summary["solve"]["global_e_min"] <= summary["solve"]["global_e_max"]


def test_cli_run_human_summary_is_friendly(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    workdir = tmp_path / "run-human"

    rc = main(["run", str(input_path), "--workdir", str(workdir), "--guide-only"])
    assert rc == 0
    output = capsys.readouterr().out

    assert "ESSPY run finished" in output
    assert "Guide stage" in output
    assert "Structure:" in output
    assert "Artifacts" in output
    assert "input:" not in output


def test_cli_run_verbose_includes_raw_solver_messages(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    workdir = tmp_path / "run-verbose"

    rc = main(["--verbose", "run", str(input_path), "--workdir", str(workdir)])
    assert rc == 0
    output = capsys.readouterr().out

    assert "ESSPY run finished" in output
    assert "Solve stage" in output
    assert "Raw native solver messages" in output


def test_cli_run_ready_print_stablest_flag_follows_solve_option(
    tmp_path: Path, capsys
):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    workdir_false = tmp_path / "run-print-flag-false"
    workdir_true = tmp_path / "run-print-flag-true"

    original = input_path.read_text()
    input_path.write_text(
        original.replace(
            "solve:\n  swap: true\n  max_swap: 2\n",
            "solve:\n"
            "  swap: true\n"
            "  max_swap: 2\n"
            "  print_stablest_unstablest: false\n",
        )
    )
    rc = main(
        ["--json", "run", str(input_path), "--workdir", str(workdir_false), "--guide-only"]
    )
    assert rc == 0
    payload_false = json.loads(capsys.readouterr().out)
    ready_false = Path(payload_false["outputs"]["ready"]).read_text()
    assert "PrintTheStablestUnstablest(Yes1No0) 0" in ready_false

    input_path.write_text(
        original.replace(
            "solve:\n  swap: true\n  max_swap: 2\n",
            "solve:\n"
            "  swap: true\n"
            "  max_swap: 2\n"
            "  print_stablest_unstablest: true\n",
        )
    )
    rc = main(
        ["--json", "run", str(input_path), "--workdir", str(workdir_true), "--guide-only"]
    )
    assert rc == 0
    payload_true = json.loads(capsys.readouterr().out)
    ready_true = Path(payload_true["outputs"]["ready"]).read_text()
    assert "PrintTheStablestUnstablest(Yes1No0) 1" in ready_true


def test_cli_run_selection_can_be_disabled(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    _append_output_overrides(
        input_path,
        "output:\n"
        "  prefix: CCS02_run\n"
        "  selection:\n"
        "    enabled: false\n",
    )
    workdir = tmp_path / "run-selection-disabled"

    rc = main(["--json", "run", str(input_path), "--workdir", str(workdir)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert "selection_dir" not in payload["outputs"]
    assert "selection_index" not in payload["outputs"]
    assert not (workdir / "selected_structures").exists()
