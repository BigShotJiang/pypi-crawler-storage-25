from esspy.models import ChargeEntry, ChargeMap, CompositionEntry, CompositionModel


def test_basic_models_construct():
    composition = CompositionModel(
        entries=[CompositionEntry(kind="Mn", count=14)],
        n_target_sites=112,
    )
    charges = ChargeMap(values=[ChargeEntry(kind="Mn", oxidation=1.512)])

    assert composition.entries[0].kind == "Mn"
    assert charges.values[0].oxidation == 1.512

