from pathlib import Path

from esspy import (
    ReadyFileWriteOptions,
    parse_guider_text,
    parse_guider_text_to_guide_input_native,
    parse_wyc_file_to_symmetry_model,
    write_ready_file_text,
)
from esspy.native import load_native_module
from tests.golden.ready_parser import parse_ready_file
from tests.golden.references import (
    G004_CCS02_P1_ADDED_GUIDER,
    G004_CCS02_P1_ADDED_READY,
    G004_CCS02_P1_ADDED_WYC,
    G005_HIGHSYM_ADDED_POSCAR,
    G005_HIGHSYM_ADDED_WYC,
    G006_CCS02_RUNTIME_DERIVED_GUIDER,
    G006_CCS02_RUNTIME_DERIVED_OPER,
    G006_CCS02_RUNTIME_DERIVED_READY,
    G006_CCS02_RUNTIME_DERIVED_WYC,
)


def test_g004_guider_semantics():
    spec = parse_guider_text(G004_CCS02_P1_ADDED_GUIDER)

    assert spec.output_prefix == "CCS02_formalcharge_MnCr2O4"
    assert spec.space_group == 1
    assert spec.options.strict_no_added_sites is False
    assert round(spec.charges["O"], 3) == -1.132


def test_g004_ready_contains_added_site_vac_path():
    ready = parse_ready_file(G004_CCS02_P1_ADDED_READY)

    assert ready.n_atom_config == 33
    assert ready.supercell_expansion == (2, 2, 2)
    assert ready.rg_find_factor == 3
    assert ready.output_prefix == "CCS02_formalcharge_MnCr2O4_001"
    assert ready.n_recipe == 2

    recipe_map = {recipe.kind: recipe for recipe in ready.recipes}
    mn_recipe = recipe_map["Mn"]
    cr_recipe = recipe_map["Cr"]

    assert tuple((mod.kind, mod.count) for mod in mn_recipe.modifications) == (
        ("Ni", 19),
        ("vac", -17),
    )
    assert tuple((mod.kind, mod.count) for mod in cr_recipe.modifications) == (
        ("Ni", 19),
        ("vac", -2),
    )


def test_g004_wyc_fixture_present():
    text = Path(G004_CCS02_P1_ADDED_WYC).read_text()
    assert text.startswith("Nwyc ")


def test_g005_highsym_fixture_present():
    wyc_text = Path(G005_HIGHSYM_ADDED_WYC).read_text()
    assert wyc_text.startswith("Nwyc ")
    assert Path(G005_HIGHSYM_ADDED_POSCAR).exists()


def test_g005_highsym_fixture_semantics():
    symmetry = parse_wyc_file_to_symmetry_model(G005_HIGHSYM_ADDED_WYC, space_group=2)
    assert symmetry.space_group == 2
    assert len(symmetry.wyc_operations) == 2
    op1 = symmetry.wyc_operations[1].matrix
    assert op1 == (
        (1.0, 0.0, 0.0, 0.5),
        (0.0, 1.0, 0.0, 0.5),
        (0.0, 0.0, 1.0, 0.5),
    )


def test_g006_runtime_derived_fixture_presence():
    assert Path(G006_CCS02_RUNTIME_DERIVED_GUIDER).exists()
    assert Path(G006_CCS02_RUNTIME_DERIVED_READY).exists()
    assert Path(G006_CCS02_RUNTIME_DERIVED_WYC).exists()
    oper = Path(G006_CCS02_RUNTIME_DERIVED_OPER).read_text()
    assert "mpirun" in oper
    assert "EwaldSolidSolution.x" in oper


def test_g006_runtime_derived_ready_semantics():
    ready = parse_ready_file(G006_CCS02_RUNTIME_DERIVED_READY)
    assert ready.n_atom_config == 33
    assert ready.rg_find_factor == 3
    assert ready.n_recipe == 2


def test_g004_guide_integrates_add_ions_when_wyc_is_present(tmp_path: Path):
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(G004_CCS02_P1_ADDED_GUIDER)
    symmetry = parse_wyc_file_to_symmetry_model(G004_CCS02_P1_ADDED_WYC, space_group=1)
    guide_input["symmetry"]["wyc_operations"] = [list(op.matrix) for op in symmetry.wyc_operations]

    guide_result = native.guide(guide_input)
    ready = guide_result["ready"]
    diagnostics = guide_result["diagnostics"]

    assert diagnostics["n_atom_config"] == 33
    assert not any("not yet extracted" in line for line in diagnostics["messages"])

    atom_counts: dict[str, int] = {}
    for atom in ready["atoms"]:
        atom_counts[atom["kind"]] = atom_counts.get(atom["kind"], 0) + 1
    assert atom_counts == {"Mn": 19, "Cr": 6, "O": 8}

    recipe_map = {recipe["from"]: recipe for recipe in ready["recipes"]}
    assert recipe_map["Mn"]["random_pickup"] == 152
    assert recipe_map["Cr"]["random_pickup"] == 48

    mn_mods = {(mod["to"], mod["count"]) for mod in recipe_map["Mn"]["modifications"]}
    cr_mods = {(mod["to"], mod["count"]) for mod in recipe_map["Cr"]["modifications"]}
    assert mn_mods == {("Ni", 19), ("vac", -17)}
    assert cr_mods == {("Ni", 19), ("vac", -2)}

    ready_text = write_ready_file_text(
        ready,
        ReadyFileWriteOptions(target_cpu_time_sec=600),
    )
    output = tmp_path / "g004.ready.txt"
    output.write_text(ready_text)
    parsed = parse_ready_file(output)
    assert parsed.n_atom_config == 33
    assert parsed.rg_find_factor == 3
