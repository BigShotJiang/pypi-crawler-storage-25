from pathlib import Path

from tests.golden.references import (
    G001_CCS02_GUIDER,
    G002_CCS03_GUIDER,
    G003_M6O8_SOLVER_INPUT,
    G003_M6O8_SOLVER_TRACE,
)
from tests.golden.solver_parser import parse_solver_trace


def test_g001_and_g002_guider_fixtures_present():
    assert Path(G001_CCS02_GUIDER).read_text().startswith("Target\tMn ")
    assert "StrictNoAddedSites\ttrue" in Path(G001_CCS02_GUIDER).read_text()
    assert Path(G002_CCS03_GUIDER).read_text().startswith("Target\t")


def test_g003_solver_input_matches_ready_style_header():
    text = Path(G003_M6O8_SOLVER_INPUT).read_text()
    assert text.startswith("vec_a ")
    assert "OutputPrefix M6O8_spinel_recovery_001" in text
    assert "NRecipe 1" in text


def test_g003_solver_trace_summary_semantics():
    summary = parse_solver_trace(G003_M6O8_SOLVER_TRACE)

    assert summary.best_result_filename.endswith(".txt")
    assert summary.worst_result_filename.endswith(".txt")
    assert summary.global_e_min < summary.global_e_max
    assert summary.best_result_energy == summary.global_e_min
    assert summary.worst_result_energy == summary.global_e_max
    assert summary.global_count_total == 11223262
    assert round(summary.total_cpu_time, 3) == 125.505
