from __future__ import annotations

from esspy.yaml_comments import annotate_solve_strategy_inline_comments


def test_annotate_solve_strategy_inline_comments():
    src = (
        "symmetry:\n"
        "  mode: auto\n"
        "  backend: spglib\n"
        "  symprec: 1.0e-05\n"
        "  write_wyc_path: symmetry.wyc\n"
        "guide:\n"
        "  options:\n"
        "    target_cpu_time_sec: 600\n"
        "    n_random_seeds: 2000\n"
        "solve:\n"
        "  strategy:\n"
        "    mode: adaptive\n"
        "    time_budget_sec: 600\n"
        "    effort: high\n"
        "    swap:\n"
        "      enabled: true\n"
        "      max_steps: 1000\n"
    )
    out = annotate_solve_strategy_inline_comments(src)
    assert "mode: auto  # symmetry mode: auto | p1" in out
    assert "backend: spglib  # symmetry backend (typically spglib)" in out
    assert "symprec: 1.0e-05  # symmetry tolerance for detection" in out
    assert "write_wyc_path: symmetry.wyc  # output path for detected WYC operations" in out
    assert "target_cpu_time_sec: 600  # guider target CPU time in seconds" in out
    assert "n_random_seeds: 2000  # guider random seed count" in out
    assert "mode: adaptive  # adaptive | bounded_exhaustive | exhaustive" in out
    assert "time_budget_sec: 600  # used when mode=adaptive (default 600)" in out
    assert "effort: high  # low | medium | high | extreme" in out
    assert "enabled: true  # true to run swap optimization" in out
    assert "max_steps: 1000  # maximum accepted/improving swap steps" in out
