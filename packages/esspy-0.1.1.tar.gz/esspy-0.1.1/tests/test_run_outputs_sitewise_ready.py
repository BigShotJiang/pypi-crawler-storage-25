import pytest
import yaml
import json

from esspy.models import (
    CompositionEntry,
    GuideDiagnostics,
    GuideResult,
    Lattice,
    ReadyAtom,
    ReadyModel,
    ReadyRecipe,
    ReadyRecipeModification,
    RecipeAssignment,
)
from esspy.run_outputs import run_yaml_to_outputs
from esspy.run_outputs_impl import (
    _apply_sitewise_composition_to_ready,
    _expected_counts_and_order,
)


def _guide_result():
    return GuideResult(
        ready=ReadyModel(
            lattice=Lattice(a=(1.0, 0.0, 0.0), b=(0.0, 1.0, 0.0), c=(0.0, 0.0, 1.0)),
            atoms=[
                ReadyAtom(kind="Mn", oxidation=2.0, x=0.0, y=0.0, z=0.0),
                ReadyAtom(kind="Cr", oxidation=3.0, x=0.5, y=0.5, z=0.5),
            ],
            poscar_species_counts=[
                CompositionEntry(kind="Mn", count=4),
                CompositionEntry(kind="Cr", count=4),
            ],
            recipes=[
                ReadyRecipe(
                    from_kind="Mn",
                    oxidation=2.0,
                    random_pickup=4,
                    random_pickup_trial=1,
                    modifications=[
                        ReadyRecipeModification(to="Ni", oxidation=2.0, count=4)
                    ],
                ),
                ReadyRecipe(
                    from_kind="Cr",
                    oxidation=3.0,
                    random_pickup=4,
                    random_pickup_trial=1,
                    modifications=[
                        ReadyRecipeModification(to="Fe", oxidation=3.0, count=4)
                    ],
                ),
            ],
        ),
        diagnostics=GuideDiagnostics(
            resolved_assignments=[
                RecipeAssignment(
                    from_kind="Mn",
                    assigned_counts=[CompositionEntry(kind="Ni", count=4)],
                )
            ]
        ),
    )


def test_apply_sitewise_composition_forces_exact_recipe_counts(tmp_path):
    input_yaml = tmp_path / "input.yaml"
    input_yaml.write_text(
        yaml.safe_dump(
            {
                "composition_by_site": {
                    "site1": {"Mn": 1, "Ni": 3},
                    "site2": {"Cr": 2, "Fe": 1, "Mn": 1},
                }
            },
            sort_keys=False,
        )
    )
    guide = _guide_result()

    meta = _apply_sitewise_composition_to_ready(
        guide,
        input_yaml,
        source_to_group={"Mn": "site-001", "Cr": "site-002"},
        charges_by_site={
            "Mn@site-001": 2.1,
            "Ni@site-001": 2.2,
            "Cr@site-002": 3.1,
            "Fe@site-002": 3.2,
            "Mn@site-002": 2.3,
        },
        default_charges={"Mn": 2.0, "Cr": 3.0, "Ni": 2.0, "Fe": 3.0},
    )

    assert meta == {"applied": True, "source_groups": 2, "total_slots": 8}
    recipes = {recipe.from_kind: recipe for recipe in guide.ready.recipes}

    assert recipes["Mn"].random_pickup == 4
    assert recipes["Mn"].oxidation == 2.1
    assert [(m.to, m.count, m.oxidation) for m in recipes["Mn"].modifications] == [
        ("Ni", 3, 2.2)
    ]

    assert recipes["Cr"].random_pickup == 4
    assert recipes["Cr"].oxidation == 3.1
    assert [(m.to, m.count, m.oxidation) for m in recipes["Cr"].modifications] == [
        ("Fe", 1, 3.2),
        ("Mn", 1, 2.3),
    ]
    counts, _ = _expected_counts_and_order(guide, ["Mn", "Cr"])
    assert counts == {
        "Mn": 2,
        "Cr": 2,
        "Ni": 3,
        "Fe": 1,
    }


def test_run_rejects_legacy_optimize_allocation_mode(tmp_path):
    poscar = tmp_path / "POSCAR"
    poscar.write_text(
        "\n".join(
            [
                "ToySpinel",
                "1.0",
                "4.0 0.0 0.0",
                "0.0 4.0 0.0",
                "0.0 0.0 4.0",
                "Mn Cr",
                "2 2",
                "Direct",
                "0.0 0.0 0.0",
                "0.5 0.5 0.0",
                "0.25 0.25 0.25",
                "0.75 0.75 0.25",
            ]
        )
        + "\n"
    )
    input_yaml = tmp_path / "input.yaml"
    input_yaml.write_text(
        yaml.safe_dump(
            {
                "structure": {"poscar": "POSCAR", "n_target_sites": 4},
                "composition": {"Mn": 1, "Cr": 1, "Ni": 1, "Fe": 1},
                "charges": {
                    "basis": "element_site",
                    "values": {"Mn": 2.0, "Cr": 3.0, "Ni": 2.0, "Fe": 3.0},
                    "elements": {
                        "Mn": {"default": 2.0, "by_site": {"site1": 2.0, "site2": 2.0}},
                        "Cr": {"default": 3.0, "by_site": {"site1": 3.0, "site2": 3.0}},
                        "Ni": {"default": 2.0, "by_site": {"site1": 2.0, "site2": 2.0}},
                        "Fe": {"default": 3.0, "by_site": {"site1": 3.0, "site2": 3.0}},
                    },
                },
                "recipes": [
                    {"from_kind": "Mn", "to": ["Mn", "Cr", "Ni", "Fe"]},
                    {"from_kind": "Cr", "to": ["Mn", "Cr", "Ni", "Fe"]},
                ],
                "site_groups": {
                    "site1": {
                        "source_kind": "Mn",
                        "count": 2,
                        "allowed": ["Mn", "Cr", "Ni", "Fe"],
                    },
                    "site2": {
                        "source_kind": "Cr",
                        "count": 2,
                        "allowed": ["Mn", "Cr", "Ni", "Fe"],
                    },
                },
                "allocation": {
                    "mode": "optimize_by_ewald",
                    "number_target": 2,
                    "generalized_time_budget_sec": 1,
                    "max_steps_per_start": 2,
                },
                "solve": {
                    "strategy": {
                        "mode": "adaptive",
                        "time_budget_sec": 1,
                        "effort": "low",
                        "execution_mode": "quick",
                        "swap": {"enabled": True, "max_steps": 2},
                    }
                },
                "output": {"selection": {"enabled": False}},
            },
            sort_keys=False,
        )
    )

    with pytest.raises(ValueError, match="portfolio_ess"):
        run_yaml_to_outputs(
            input_yaml,
            workdir=tmp_path / "run",
            quiet=True,
            no_progress=True,
        )


def test_run_portfolio_ess_scores_allocations_before_final_solve(tmp_path):
    poscar = tmp_path / "POSCAR"
    poscar.write_text(
        "\n".join(
            [
                "ToySpinelPortfolio",
                "1.0",
                "4.0 0.0 0.0",
                "0.0 4.0 0.0",
                "0.0 0.0 4.0",
                "Mn Cr",
                "2 2",
                "Direct",
                "0.0 0.0 0.0",
                "0.5 0.5 0.0",
                "0.25 0.25 0.25",
                "0.75 0.75 0.25",
            ]
        )
        + "\n"
    )
    input_yaml = tmp_path / "input.yaml"
    input_yaml.write_text(
        yaml.safe_dump(
            {
                "structure": {"poscar": "POSCAR", "n_target_sites": 4},
                "composition": {"Mn": 1, "Cr": 1, "Ni": 1, "Fe": 1},
                "charges": {
                    "basis": "element_site",
                    "values": {"Mn": 2.0, "Cr": 3.0, "Ni": 2.0, "Fe": 3.0},
                    "elements": {
                        "Mn": {"default": 2.0, "by_site": {"site1": 2.0, "site2": 2.0}},
                        "Cr": {"default": 3.0, "by_site": {"site1": 3.0, "site2": 3.0}},
                        "Ni": {"default": 2.0, "by_site": {"site1": 2.0, "site2": 2.0}},
                        "Fe": {"default": 3.0, "by_site": {"site1": 3.0, "site2": 3.0}},
                    },
                },
                "recipes": [
                    {"from_kind": "Mn", "to": ["Mn", "Cr", "Ni", "Fe"]},
                    {"from_kind": "Cr", "to": ["Mn", "Cr", "Ni", "Fe"]},
                ],
                "site_groups": {
                    "site1": {
                        "source_kind": "Mn",
                        "count": 2,
                        "allowed": ["Mn", "Cr", "Ni", "Fe"],
                    },
                    "site2": {
                        "source_kind": "Cr",
                        "count": 2,
                        "allowed": ["Mn", "Cr", "Ni", "Fe"],
                    },
                },
                "allocation": {
                    "rough_ess_time_sec": 1,
                    "rough_max_swap": 1,
                    "final_candidates": 1,
                    "final_refine_time_sec": 1,
                    "time_budget_sec": 4,
                },
                "solve": {
                    "strategy": {
                        "mode": "adaptive",
                        "time_budget_sec": 5,
                        "effort": "low",
                        "execution_mode": "quick",
                        "swap": {"enabled": True, "max_steps": 2},
                    }
                },
                "output": {"selection": {"enabled": False}},
            },
            sort_keys=False,
        )
    )

    summary = run_yaml_to_outputs(
        input_yaml,
        workdir=tmp_path / "run-portfolio",
        quiet=True,
        no_progress=True,
    )

    assert summary["allocation"]["score_mode"] == "portfolio_ess"
    portfolio = summary["allocation_portfolio"]
    assert portfolio["optimizer"] == "sequential_rough_ess"
    assert portfolio["evaluated_allocations"] >= 1
    assert portfolio["best_composition_by_site"]
    assert summary["allocation"]["coupled_solve"]["applied"] is True
    assert summary["recommended"]["source"] in {
        "portfolio_allocation_ess_best_poscar",
        "allocation_portfolio_best_poscar",
    }
    assert "allocation_portfolio_best_poscar" in summary["outputs"]
    assert "best_poscar" in summary["outputs"]
    assert "final_ess_best_poscar" in summary["outputs"]
    assert "recommended_source_poscar" in summary["outputs"]
    assert summary["outputs"]["recommended_poscar"].endswith("POSCAR_host_best.vasp")
    assert summary["outputs"]["best_poscar"].endswith("POSCAR_host_best.vasp")
    assert "/diagnostics/POSCAR_final_ess_best.vasp" in summary["outputs"]["final_ess_best_poscar"]
    assert (
        "/diagnostics/POSCAR_allocation_best.vasp"
        in summary["outputs"]["allocation_portfolio_best_poscar"]
    )
    assert not (tmp_path / "run-portfolio" / "POSCAR_host_final_ess_best.vasp").exists()
    assert not (
        tmp_path / "run-portfolio" / "POSCAR_host_allocation_portfolio_best.vasp"
    ).exists()
    best_title = (tmp_path / "run-portfolio" / "POSCAR_host_best.vasp").read_text().splitlines()[0]
    assert "(recommended best)" in best_title


def test_run_auto_loads_charge_model_next_to_input(tmp_path):
    poscar = tmp_path / "POSCAR"
    poscar.write_text(
        "\n".join(
            [
                "ToyChargeModel",
                "1.0",
                "4.0 0.0 0.0",
                "0.0 4.0 0.0",
                "0.0 0.0 4.0",
                "Mn Cr",
                "1 1",
                "Direct",
                "0.0 0.0 0.0",
                "0.5 0.5 0.5",
            ]
        )
        + "\n"
    )
    input_yaml = tmp_path / "input.yaml"
    input_yaml.write_text(
        yaml.safe_dump(
            {
                "structure": {"poscar": "POSCAR", "n_target_sites": 2},
                "composition": {"fractions": {"Mn": 0.5, "Cr": 0.5}},
                "charges": {
                    "basis": "element_site",
                    "elements": {
                        "Mn": {"default": 2.0, "by_site": {"site1": 2.0}},
                        "Cr": {"default": 3.0, "by_site": {"site2": 3.0}},
                    },
                },
                "recipes": [
                    {"from_kind": "Mn", "to": ["Mn"]},
                    {"from_kind": "Cr", "to": ["Cr"]},
                ],
                "site_groups": {
                    "site1": {"source_kind": "Mn", "count": 1, "allowed": ["Mn"]},
                    "site2": {"source_kind": "Cr", "count": 1, "allowed": ["Cr"]},
                },
                "solve": {
                    "strategy": {
                        "mode": "adaptive",
                        "time_budget_sec": 1,
                        "effort": "low",
                        "execution_mode": "quick",
                        "swap": {"enabled": False, "max_steps": 0},
                    }
                },
                "output": {"selection": {"enabled": False}},
            },
            sort_keys=False,
        )
    )
    (tmp_path / "charge_model.json").write_text(
        json.dumps(
            {
                "charges": {
                    "basis": "element_site",
                    "elements": {
                        "Mn": {"by_site": {"site1": 2.39}},
                        "Cr": {"by_site": {"site2": 2.48}},
                    },
                }
            }
        )
    )

    summary = run_yaml_to_outputs(
        input_yaml,
        workdir=tmp_path / "run",
        guide_only=True,
        quiet=True,
    )

    assert summary["charge_model"]["source"] == "auto"
    assert summary["charge_model"]["loaded_entries"] == 2
    assert summary["charge_model"]["charges"] == {
        "Mn@site-001": 2.39,
        "Cr@site-002": 2.48,
    }
    poscar_title = (tmp_path / "run" / "POSCAR_host_supercell.vasp").read_text().splitlines()[0]
    assert "Mn@site-001" not in poscar_title
    assert "Cr@site-002" not in poscar_title
    assert "charges: Cr=3 Mn=2" in poscar_title
    log_text = (tmp_path / "run" / "summary.log").read_text()
    assert "Charge model loaded; input charges overridden" in log_text
