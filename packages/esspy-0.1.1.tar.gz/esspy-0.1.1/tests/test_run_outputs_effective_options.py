from __future__ import annotations

from esspy.models import SolveOptions
from esspy.run_outputs import _effective_solve_options


def test_effective_solve_options_quick_mode_keeps_chunk_limit():
    opts = SolveOptions(local_enumeration_limit=10000)
    effective = _effective_solve_options(
        opts,
        mpi={"size": 8},
        strategy_execution_mode="quick",
    )
    assert effective["local_enumeration_limit"] == 10000
    assert effective["chunk_tuned"] is False


def test_effective_solve_options_scalable_mode_tunes_chunk_limit():
    opts = SolveOptions(local_enumeration_limit=10000)
    effective = _effective_solve_options(
        opts,
        mpi={"size": 8},
        strategy_execution_mode="scalable",
    )
    assert effective["local_enumeration_limit"] == 1250
    assert effective["chunk_tuned"] is True
    assert effective["chunk_policy"] == "scalable_auto"
    assert effective["mpi_dynamic_chunking"] is False


def test_effective_solve_options_keeps_mpi_dynamic_chunking_flags():
    opts = SolveOptions(
        local_enumeration_limit=10000,
        mpi_dynamic_chunking=True,
        mpi_chunk_min=256,
        mpi_chunk_max=8192,
        mpi_scheduler_heartbeat=8,
    )
    effective = _effective_solve_options(
        opts,
        mpi={"size": 4},
        strategy_execution_mode="scalable",
    )
    assert effective["mpi_dynamic_chunking"] is True
    assert effective["mpi_chunk_min"] == 256
    assert effective["mpi_chunk_max"] == 8192
    assert effective["mpi_scheduler_heartbeat"] == 8


def test_effective_solve_options_scalable_mode_np_2_4_8_monotonic():
    opts = SolveOptions(local_enumeration_limit=16000)
    limits = []
    for size in (2, 4, 8):
        effective = _effective_solve_options(
            opts,
            mpi={"size": size},
            strategy_execution_mode="scalable",
        )
        limits.append(int(effective["local_enumeration_limit"]))
        assert effective["chunk_tuned"] is True
    assert limits[0] >= limits[1] >= limits[2]
