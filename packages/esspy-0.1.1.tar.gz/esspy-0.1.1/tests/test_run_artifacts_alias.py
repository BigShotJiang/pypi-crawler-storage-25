from __future__ import annotations

from esspy import run_artifacts, run_outputs


def test_run_artifacts_alias_exports_primary_symbols():
    assert run_artifacts.run_yaml_to_outputs is run_outputs.run_yaml_to_outputs
    assert hasattr(run_artifacts, "_EnergyTracker")
    assert hasattr(run_artifacts, "_normalize_snapshot_structure")
