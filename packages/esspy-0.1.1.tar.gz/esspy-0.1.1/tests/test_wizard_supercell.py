from pathlib import Path

import yaml

from esspy.config import load_run_input
from esspy.poscar import load_poscar
from esspy.wizard import WizardMode, WizardSession


POSCAR = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()


def test_wizard_save_writes_explicit_dim(tmp_path: Path):
    wizard = WizardSession(mode=WizardMode.COMPOSITION)
    wizard.state.reference_structure = str(POSCAR)
    wizard.state.structure = load_poscar(POSCAR)
    wizard.state.target_atoms = 112
    wizard.state.supercell_expansion = (2, 2, 2)
    wizard.state.resolved_supercell_expansion = (2, 2, 2)
    wizard.state.composition_mode = "global"
    wizard.state.composition = {"Mn": 14, "Cr": 15, "Ni": 19, "O": 64}
    wizard.state.composition_fractions = {
        "Mn": 14 / 112,
        "Cr": 15 / 112,
        "Ni": 19 / 112,
        "O": 64 / 112,
    }
    wizard.state.charges = {
        "Mn": 1.512165,
        "Cr": 1.707951,
        "Ni": 1.299835,
        "O": -1.116975625,
    }
    wizard.state.charge_basis = "element"
    wizard.state.recipes = {"Mn": ["Mn", "Ni"], "Cr": ["Cr", "Ni"]}

    out = tmp_path / "input.yaml"
    assert wizard.save_to_yaml(str(out)) is True

    data = yaml.safe_load(out.read_text())
    assert data["structure"]["dim"] == [2, 2, 2]
    assert "n_target_sites" not in data["structure"]

    parsed = load_run_input(out)
    assert parsed.guide.composition.n_target_sites == 112
    assert parsed.guide.supercell_expansion == (2, 2, 2)
    sposcar = tmp_path / "SPOSCAR"
    assert sposcar.exists()
    sposcar_lines = sposcar.read_text().splitlines()
    assert "16  32  64" in sposcar_lines[6]


def test_wizard_global_fraction_auto_fills_fixed_identity_species(monkeypatch, capsys):
    wizard = WizardSession(mode=WizardMode.COMPOSITION)
    wizard.state.structure = load_poscar(POSCAR)
    wizard.state.reference_structure = str(POSCAR)
    wizard.state.element_mapping = {
        "Mn": ["Mn", "Cr", "Ni"],
        "Cr": ["Mn", "Cr", "Ni"],
        "O": ["O"],
    }
    wizard.state.mapped_elements = ["Mn", "Cr", "Ni", "O"]
    wizard.state.composition_mode = "global"

    menu_answers = iter([1, 1])  # explicit supercell, fraction/ratio mode
    prompt_answers = iter(["2 2 2", "1", "1", "2"])

    monkeypatch.setattr(
        wizard,
        "render_menu",
        lambda *args, **kwargs: next(menu_answers),
    )
    monkeypatch.setattr(
        wizard,
        "prompt_input",
        lambda *args, **kwargs: next(prompt_answers),
    )

    assert wizard.step_3_target_composition() is True
    output = capsys.readouterr().out
    assert "Cell metrics:" in output
    assert "alpha=" in output
    assert wizard.state.composition["O"] == 64
    assert wizard.state.composition["Mn"] == 12
    assert wizard.state.composition["Cr"] == 12
    assert wizard.state.composition["Ni"] == 24
    assert sum(wizard.state.composition.values()) == 112


def test_wizard_global_fraction_back_revisits_previous_element(monkeypatch, capsys):
    wizard = WizardSession(mode=WizardMode.COMPOSITION)
    wizard.state.structure = load_poscar(POSCAR)
    wizard.state.reference_structure = str(POSCAR)
    wizard.state.element_mapping = {
        "Mn": ["Mn", "Cr", "Ni"],
        "Cr": ["Mn", "Cr", "Ni"],
        "O": ["O"],
    }
    wizard.state.mapped_elements = ["Mn", "Cr", "Ni", "O"]
    wizard.state.composition_mode = "global"

    menu_answers = iter([1, 1])  # explicit supercell, fraction/ratio mode
    prompt_answers = iter(
        [
            "2 2 2",  # supercell
            "1",      # Mn
            "151",    # Cr, mistyped
            "back",   # at Ni prompt, go back to Cr
            "2",      # corrected Cr
            "3",      # Ni
        ]
    )

    monkeypatch.setattr(wizard, "render_menu", lambda *args, **kwargs: next(menu_answers))
    monkeypatch.setattr("builtins.input", lambda _prompt="": next(prompt_answers))

    assert wizard.step_3_target_composition() is True
    output = capsys.readouterr().out
    assert "Back to Cr." in output
    assert wizard.state.composition["O"] == 64
    assert wizard.state.composition["Mn"] == 8
    assert wizard.state.composition["Cr"] == 16
    assert wizard.state.composition["Ni"] == 24
    assert sum(wizard.state.composition.values()) == 112


def test_wizard_explicit_supercell_has_no_default_and_exits_after_three_invalid(monkeypatch, capsys):
    wizard = WizardSession(mode=WizardMode.COMPOSITION)
    wizard.state.structure = load_poscar(POSCAR)
    wizard.state.reference_structure = str(POSCAR)
    wizard.state.element_mapping = {"Mn": ["Mn"], "Cr": ["Cr"], "O": ["O"]}
    wizard.state.mapped_elements = ["Mn", "Cr", "O"]
    wizard.state.composition_mode = "global"

    prompt_defaults = []
    prompt_answers = iter(["bad", "1 2", "2 0 0 0 2 1 0 0 2"])

    monkeypatch.setattr(
        wizard,
        "render_menu",
        lambda *args, **kwargs: 1,
    )

    def fake_prompt(*args, **kwargs):
        prompt_defaults.append(kwargs.get("default"))
        return next(prompt_answers)

    monkeypatch.setattr(wizard, "prompt_input", fake_prompt)

    assert wizard.step_3_target_composition() is False
    output = capsys.readouterr().out
    assert prompt_defaults == [None, None, None]
    assert "Supercell dimension/matrix (example:" not in output  # fake prompt bypasses input()
    assert "Too many invalid supercell inputs" in output
