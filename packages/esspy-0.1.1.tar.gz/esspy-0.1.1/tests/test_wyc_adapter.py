from pathlib import Path

import pytest

from esspy import parse_wyc_file, parse_wyc_file_to_symmetry_model


WYC_G004 = Path("tests/golden/fixtures/G004_CCS02_P1_ADDED/1.wyc")
WYC_G005 = Path("tests/golden/fixtures/G005_HIGHSYM_ADDED/2.wyc")


def test_parse_wyc_file_g004_p1_identity():
    parsed = parse_wyc_file(WYC_G004)

    assert parsed.header_key == "Nwyc"
    assert parsed.declared_n_wyc == 1
    assert len(parsed.entries) == 1

    entry = parsed.entries[0]
    assert entry.label == "P1"
    assert entry.matrix == (
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
    )


def test_parse_wyc_file_to_symmetry_model_g004():
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)

    assert symmetry.space_group == 1
    assert symmetry.from_spglib is False
    assert len(symmetry.wyc_operations) == 1

    op = symmetry.wyc_operations[0]
    assert op.matrix == (
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
    )


def test_parse_wyc_file_g005_two_ops():
    parsed = parse_wyc_file(WYC_G005)
    assert parsed.header_key == "Nwyc"
    assert parsed.declared_n_wyc == 2
    assert len(parsed.entries) == 2
    assert parsed.entries[0].label == "P1"
    assert parsed.entries[1].label == "T050"
    assert parsed.entries[1].matrix == (
        (1.0, 0.0, 0.0, 0.5),
        (0.0, 1.0, 0.0, 0.5),
        (0.0, 0.0, 1.0, 0.5),
    )


def test_parse_wyc_file_to_symmetry_model_g005():
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G005, space_group=2)
    assert symmetry.space_group == 2
    assert symmetry.from_spglib is False
    assert len(symmetry.wyc_operations) == 2


def test_parse_wyc_file_missing_path_raises(tmp_path: Path):
    missing = tmp_path / "does_not_exist.wyc"
    with pytest.raises(Exception):
        parse_wyc_file(missing)


def test_parse_wyc_file_truncated_raises(tmp_path: Path):
    truncated = tmp_path / "broken.wyc"
    # Header advertises two entries but only one matrix follows.
    truncated.write_text(
        "Nwyc 2\n"
        "1\n"
        "1 0 0 0\n"
        "0 1 0 0\n"
        "0 0 1 0\n"
    )
    with pytest.raises(Exception):
        parse_wyc_file(truncated)


def test_parse_wyc_file_supports_multiple_entries(tmp_path: Path):
    multi = tmp_path / "two_ops.wyc"
    # Identity plus an inversion-like operation.
    multi.write_text(
        "Nwyc 2\n"
        "P1\n"
        "1 0 0 0\n"
        "0 1 0 0\n"
        "0 0 1 0\n"
        "P-1\n"
        "-1 0 0 0\n"
        "0 -1 0 0\n"
        "0 0 -1 0\n"
    )

    parsed = parse_wyc_file(multi)
    assert parsed.declared_n_wyc == 2
    assert len(parsed.entries) == 2
    assert parsed.entries[0].label == "P1"
    assert parsed.entries[1].label == "P-1"
    assert parsed.entries[1].matrix == (
        (-1.0, 0.0, 0.0, 0.0),
        (0.0, -1.0, 0.0, 0.0),
        (0.0, 0.0, -1.0, 0.0),
    )
