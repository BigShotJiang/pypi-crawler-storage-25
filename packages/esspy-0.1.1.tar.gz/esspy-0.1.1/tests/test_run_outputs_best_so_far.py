from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from esspy.models import LoggingOptions
from esspy.progress import ProgressReporter
from esspy.run_outputs import _EnergyTracker, _emit_native_progress


def _guide_result_stub():
    return SimpleNamespace(
        ready=SimpleNamespace(
            poscar_species_counts=[
                SimpleNamespace(kind="M", count=2),
                SimpleNamespace(kind="O", count=2),
            ],
            recipes=[
                SimpleNamespace(
                    from_kind="M",
                    modifications=[
                        SimpleNamespace(to="Mn", count=1),
                        SimpleNamespace(to="Cr", count=1),
                    ],
                ),
                SimpleNamespace(from_kind="O", modifications=[]),
            ],
        )
    )


def test_emit_native_progress_writes_best_so_far_poscar(tmp_path: Path):
    reporter = ProgressReporter(
        tmp_path,
        LoggingOptions(write_best_so_far=True),
        rank=0,
        world_size=1,
    )
    event = {
        "stage": "solve.chunk",
        "processed_candidates": 10,
        "available_count": 100,
        "elapsed_sec": 1.0,
        "local_e_min": -1.23,
        "local_e_max": -1.0,
        "best_structure_present": True,
        "best_structure": {
            "title": "s",
            "lattice": {"a": [1, 0, 0], "b": [0, 1, 0], "c": [0, 0, 1]},
            "sites": [
                {"kind": "M", "x": 0, "y": 0, "z": 0, "oxidation": 0},
                {"kind": "M", "x": 0.5, "y": 0.5, "z": 0.5, "oxidation": 0},
                {"kind": "O", "x": 0.25, "y": 0.25, "z": 0.25, "oxidation": 0},
                {"kind": "O", "x": 0.75, "y": 0.75, "z": 0.75, "oxidation": 0},
            ],
            "fractional_coordinates": True,
        },
    }
    _emit_native_progress(
        reporter=reporter,
        event=event,
        energy_tracker=_EnergyTracker(),
        workdir=tmp_path,
        prefix="T",
        output_config=SimpleNamespace(best_poscar_filename="POSCAR_host_best.vasp"),
        guide_result=_guide_result_stub(),
        is_writer=True,
    )
    poscar = tmp_path / "POSCAR_host_best.vasp"
    assert poscar.exists()
    text = poscar.read_text()
    assert "(best-so-far)" in text.splitlines()[0]
    assert "Mn  Cr  O" in text
