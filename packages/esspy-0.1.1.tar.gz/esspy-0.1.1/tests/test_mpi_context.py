from __future__ import annotations

import argparse
import json

from esspy.cli_common import print_result
from esspy.mpi_context import detect_mpi_context, mpi_rank


MPI_ENV_KEYS = [
    "OMPI_COMM_WORLD_RANK",
    "OMPI_COMM_WORLD_SIZE",
    "PMIX_RANK",
    "PMIX_SIZE",
    "PMI_RANK",
    "PMI_SIZE",
    "SLURM_PROCID",
    "SLURM_NTASKS",
]


def test_mpi_context_env_fallback_detects_nonzero_rank(monkeypatch):
    for key in MPI_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("OMPI_COMM_WORLD_RANK", "1")
    monkeypatch.setenv("OMPI_COMM_WORLD_SIZE", "2")

    context = detect_mpi_context()

    assert context["comm"] is None or context["size"] == 2
    assert context["rank"] == 1
    assert context["size"] == 2
    assert mpi_rank() == 1


def test_print_result_suppresses_env_detected_nonroot_rank(monkeypatch, capsys):
    for key in MPI_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("OMPI_COMM_WORLD_RANK", "1")
    monkeypatch.setenv("OMPI_COMM_WORLD_SIZE", "2")
    args = argparse.Namespace(json=True, quiet=False)

    print_result(args, {"ok": True})

    assert capsys.readouterr().out == ""


def test_print_result_allows_env_detected_root_rank(monkeypatch, capsys):
    for key in MPI_ENV_KEYS:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("OMPI_COMM_WORLD_RANK", "0")
    monkeypatch.setenv("OMPI_COMM_WORLD_SIZE", "2")
    args = argparse.Namespace(json=True, quiet=False)

    print_result(args, {"ok": True})

    assert json.loads(capsys.readouterr().out) == {"ok": True}
