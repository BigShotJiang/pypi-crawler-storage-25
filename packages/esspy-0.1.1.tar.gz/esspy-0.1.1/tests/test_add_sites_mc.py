import pytest

from esspy import (
    AddSitesMonteCarloOptions,
    StructureModel,
    Lattice,
    Site,
    run_add_sites_monte_carlo,
)


def _base_structure() -> StructureModel:
    return StructureModel(
        title="mc_base",
        lattice=Lattice(a=(4.0, 0.0, 0.0), b=(0.0, 4.0, 0.0), c=(0.0, 0.0, 4.0)),
        sites=[
            Site(kind="O", x=0.0, y=0.0, z=0.0, oxidation=-2.0),
            Site(kind="Mn", x=0.5, y=0.5, z=0.5, oxidation=2.0),
        ],
        fractional_coordinates=True,
    )


def _simple_spec() -> dict:
    return {
        "add_meshes": [0.5, 0.5, 0.5],
        "min_distance_between_added_sites": 0.1,
        "n_monte_carlo": 8,
        "monte_carlo_monitor_index": 2,
        "added_kinds": [
            {
                "kind": "Li",
                "n_added": 1,
                "oxidation": 1.0,
                "neighbor_kinds": [
                    {
                        "kind": "O",
                        "doxidation": 0.0,
                        "dist_min": 0.0,
                        "dist_max": 10000.0,
                    }
                ],
            }
        ],
    }


def test_run_add_sites_monte_carlo_happy_path():
    result = run_add_sites_monte_carlo(
        _base_structure(),
        _simple_spec(),
        AddSitesMonteCarloOptions(random_seed=11, rg_find_factor=1, chop_level=8.0),
    )
    assert result.attempted_trials == 8
    assert result.accepted_trials >= 1
    assert result.success is True
    assert len(result.best_structure.sites) == 3
    assert any(site.kind == "Li" for site in result.best_structure.sites)


def test_run_add_sites_monte_carlo_is_deterministic_with_seed():
    options = AddSitesMonteCarloOptions(random_seed=77, rg_find_factor=1, chop_level=8.0)
    result_a = run_add_sites_monte_carlo(_base_structure(), _simple_spec(), options)
    result_b = run_add_sites_monte_carlo(_base_structure(), _simple_spec(), options)

    assert result_a.success == result_b.success
    assert result_a.best_energy == result_b.best_energy
    sites_a = [(site.kind, site.x, site.y, site.z, site.oxidation) for site in result_a.best_structure.sites]
    sites_b = [(site.kind, site.x, site.y, site.z, site.oxidation) for site in result_b.best_structure.sites]
    assert sites_a == sites_b


def test_run_add_sites_monte_carlo_infeasible_constraints():
    spec = _simple_spec()
    spec["added_kinds"][0]["neighbor_kinds"][0]["kind"] = "NoSuchKind"

    result = run_add_sites_monte_carlo(
        _base_structure(),
        spec,
        AddSitesMonteCarloOptions(random_seed=2),
    )

    assert result.success is False
    assert result.accepted_trials == 0
    assert len(result.best_structure.sites) == 2


def test_run_add_sites_monte_carlo_applies_neighbor_doxidation_to_target():
    spec = _simple_spec()
    spec["added_kinds"][0]["neighbor_kinds"][0]["kind"] = "Mn"
    spec["added_kinds"][0]["neighbor_kinds"][0]["doxidation"] = 0.5

    result = run_add_sites_monte_carlo(
        _base_structure(),
        spec,
        AddSitesMonteCarloOptions(random_seed=3, rg_find_factor=1, chop_level=8.0),
    )

    assert result.success is True
    mn_sites = [site for site in result.best_structure.sites if site.kind == "Mn"]
    assert len(mn_sites) == 1
    assert mn_sites[0].oxidation == 2.5


def test_run_add_sites_monte_carlo_applies_secondary_next_neighbor_doxidation():
    spec = _simple_spec()
    spec["added_kinds"][0]["neighbor_kinds"] = [
        {
            "kind": "O",
            "doxidation": 0.2,
            "dist_min": 0.0,
            "dist_max": 10000.0,
        },
        {
            "kind": "Mn",
            "doxidation": 0.3,
            "dist_min": 0.0,
            "dist_max": 10000.0,
        },
    ]

    result = run_add_sites_monte_carlo(
        _base_structure(),
        spec,
        AddSitesMonteCarloOptions(random_seed=3, rg_find_factor=1, chop_level=8.0),
    )

    assert result.success is True
    o_sites = [site for site in result.best_structure.sites if site.kind == "O"]
    mn_sites = [site for site in result.best_structure.sites if site.kind == "Mn"]
    assert len(o_sites) == 1
    assert len(mn_sites) == 1
    assert o_sites[0].oxidation == pytest.approx(-1.8)
    # +0.3 from direct Mn-neighbor dox and +0.3 from secondary stream (O -> nearest Mn).
    assert mn_sites[0].oxidation == pytest.approx(2.6)


def test_run_add_sites_monte_carlo_relaxes_double_count_limit_when_needed():
    spec = _simple_spec()
    spec["n_monte_carlo"] = 1
    spec["added_kinds"][0]["n_added"] = 2
    spec["added_kinds"][0]["neighbor_kinds"] = [
        {
            "kind": "O",
            "doxidation": 0.4,
            "dist_min": 0.0,
            "dist_max": 10000.0,
        }
    ]

    result = run_add_sites_monte_carlo(
        _base_structure(),
        spec,
        AddSitesMonteCarloOptions(random_seed=19, rg_find_factor=1, chop_level=8.0),
    )

    assert result.success is True
    assert len([site for site in result.best_structure.sites if site.kind == "Li"]) == 2
    o_sites = [site for site in result.best_structure.sites if site.kind == "O"]
    assert len(o_sites) == 1
    # Two placements each apply +0.4 to the same O target, enabled by
    # double-count-limit relaxation between placement rounds.
    assert o_sites[0].oxidation == pytest.approx(-1.2)
