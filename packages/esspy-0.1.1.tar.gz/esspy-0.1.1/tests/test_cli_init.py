from __future__ import annotations

import json
from pathlib import Path

import yaml

from esspy.cli import main
from esspy.config import load_run_input


POSCAR = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()
POSCAR_TARGET = (
    Path("examples/site_grouping_wyckoff/POSCAR-target").resolve()
)


def test_cli_init_from_poscar_counts_yaml_loads(tmp_path: Path, capsys):
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "--json",
            "init",
            "from-poscar",
            str(POSCAR),
            "--out",
            str(out),
            "--name",
            "CCS02",
            "--n-target-sites",
            "112",
            "--fixed",
            "O",
            "--composition",
            "Mn=14,Cr=15,Ni=19,O=64",
            "--charges",
            "Mn=1.512165,Cr=1.707951,Ni=1.299835,O=-1.116975625",
            "--recipe",
            "Mn->Mn,Ni",
            "--recipe",
            "Cr->Cr,Ni",
            "--symmetry",
            "p1",
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)
    assert payload["sposcar"] == str(tmp_path / "SPOSCAR")
    assert (tmp_path / "SPOSCAR").exists()
    parsed = load_run_input(out)
    assert parsed.guide.structure.title == "CCS02"
    assert [(entry.kind, entry.count) for entry in parsed.guide.composition.entries] == [
        ("Mn", 14),
        ("Cr", 15),
        ("Ni", 19),
        ("O", 64),
    ]
    assert parsed.guide.options.target_cpu_time_sec == 100
    assert parsed.guide.options.fixed_rg_find_factor is None
    assert parsed.solve.max_swap == 100
    output = yaml.safe_load(out.read_text())["output"]
    assert output["guider_filename"] == "basic_properties_EwaldSolidSolutionGuider.txt"
    assert output["ready_filename"] == "basic_properties_EwaldSolidSolution.ready.txt"
    assert output["poscar_filename"] == "CCS02.POSCAR.vasp"
    assert output["summary_filename"] == "summary.json"
    logging = yaml.safe_load(out.read_text())["logging"]
    assert logging["console"] is True
    assert logging["file"] is True
    assert logging["progress_jsonl"] is True
    assert logging["per_rank_logs"] is True
    assert logging["interval_sec"] == 10.0
    assert parsed.logging.console is True
    assert parsed.logging.interval_sec == 10.0


def test_cli_init_from_poscar_accepts_explicit_dim(tmp_path: Path):
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "init",
            "from-poscar",
            str(POSCAR),
            "--out",
            str(out),
            "--name",
            "CCS02",
            "--dim",
            "2",
            "2",
            "2",
            "--fixed",
            "O",
            "--composition",
            "Mn=14,Cr=15,Ni=19,O=64",
            "--charges",
            "Mn=1.512165,Cr=1.707951,Ni=1.299835,O=-1.116975625",
            "--recipe",
            "Mn->Mn,Ni",
            "--recipe",
            "Cr->Cr,Ni",
            "--symmetry",
            "p1",
        ]
    )

    assert rc == 0
    assert (tmp_path / "SPOSCAR").exists()
    assert "16  32  64" in (tmp_path / "SPOSCAR").read_text()
    data = yaml.safe_load(out.read_text())
    assert data["structure"]["dim"] == [2, 2, 2]
    assert "n_target_sites" not in data["structure"]

    parsed = load_run_input(out)
    assert parsed.guide.composition.n_target_sites == 112
    assert parsed.guide.supercell_expansion == (2, 2, 2)


def test_cli_init_from_poscar_supports_fractions_and_fixed_rg(tmp_path: Path):
    out = tmp_path / "fractional.yaml"

    rc = main(
        [
            "init",
            "from-poscar",
            str(POSCAR),
            "--out",
            str(out),
            "--name",
            "CCS02_fractional",
            "--n-target-sites",
            "112",
            "--fixed",
            "O",
            "--fractions",
            "Mn=0.125,Cr=0.1339285714,Ni=0.1696428571,O=0.5714285714",
            "--charges",
            "Mn=1.512165,Cr=1.707951,Ni=1.299835,O=-1.116975625",
            "--recipe",
            "Mn->Mn,Ni",
            "--recipe",
            "Cr->Cr,Ni",
            "--symmetry",
            "p1",
            "--fixed-rg-find-factor",
            "2",
        ]
    )

    assert rc == 0
    parsed = load_run_input(out)
    assert [(entry.kind, entry.count) for entry in parsed.guide.composition.entries] == [
        ("Mn", 14),
        ("Cr", 15),
        ("Ni", 19),
        ("O", 64),
    ]
    assert parsed.guide.options.fixed_rg_find_factor == 2


def test_cli_init_output_works_with_guide_inspect(tmp_path: Path, capsys):
    out = tmp_path / "input.yaml"
    rc = main(
        [
            "init",
            "from-poscar",
            str(POSCAR),
            "--out",
            str(out),
            "--name",
            "CCS02",
            "--n-target-sites",
            "112",
            "--composition",
            "Mn=14,Cr=15,Ni=19,O=64",
            "--charges",
            "Mn=1.512165,Cr=1.707951,Ni=1.299835,O=-1.116975625",
            "--recipe",
            "Mn->Mn,Ni",
            "--recipe",
            "Cr->Cr,Ni",
            "--symmetry",
            "p1",
        ]
    )
    assert rc == 0
    capsys.readouterr()

    rc = main(["--json", "guide", "inspect", str(out)])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["title"] == "CCS02"
    assert payload["composition"]["O"] == 64


def test_cli_init_unified_poscar_minimal_autofill(tmp_path: Path, capsys):
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "--json",
            "init",
            "-p",
            str(POSCAR),
            "--out",
            str(out),
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)

    data = yaml.safe_load(out.read_text())
    assert "local_enumeration_stride" not in data["solve"]
    strategy = data["solve"]["strategy"]
    assert strategy["mode"] == "adaptive"
    assert strategy["effort"] == "medium"
    assert strategy["swap"]["enabled"] is True


    assert strategy["swap"]["max_steps"] == 100
    assert data["structure"]["n_target_sites"] == 14
    assert data["structure"]["number_fixed_at"] == "O"
    assert data["composition"]["fractions"]["Mn"] == 2 / 14
    assert data["composition"]["fractions"]["Cr"] == 4 / 14
    assert data["composition"]["fractions"]["O"] == 8 / 14
    assert data["charges"]["Mn"] == 2.0
    assert data["charges"]["Cr"] == 3.0
    assert data["charges"]["O"] == -2.0
    assert data["recipes"] == [
        {"from": "Mn", "to": ["Mn"]},
        {"from": "Cr", "to": ["Cr"]},
    ]
    assert "examples" in data
    assert len(data["examples"]["recipes"]) == 2
    assert data["examples"]["recipes"][0] == {"from": "M", "to": ["Mn", "Cr"]}
    assert "added_sites" in data["examples"]
    assert data["examples"]["added_sites"]["kinds"][0]["kind"] == "H"


def test_cli_init_unified_poscar_auto_site_grouping_element_wyckoff(tmp_path: Path):
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "init",
            "-p",
            str(POSCAR_TARGET),
            "--out",
            str(out),
            "--n-target-sites",
            "56",
            "--composition",
            "Mn=4,Cr=20,Ni=0,Rh=0,Co=0,Fe=0,O=32",
            "--charges",
            "Mn=2,Cr=3,Ni=2,Rh=3,Co=2,Fe=3,O=-2",
            "--charge-basis",
            "element_site",
            "--recipe",
            "Cr:Mn,Cr,Ni,Rh,Co,Fe",
            "--recipe",
            "O:O",
            "--site-grouping",
            "element_wyckoff",
            "--site-group-symprec",
            "0.1",
            "--site-group-angle-tolerance",
            "5.0",
            "--selection-enabled",
            "false",
        ]
    )

    assert rc == 0
    assert (tmp_path / "SPOSCAR").exists()
    data = yaml.safe_load(out.read_text())
    assert data["site_grouping"]["mode"] == "element_wyckoff"
    assert data["site_grouping"]["space_group"] == 227
    assert data["site_grouping"]["source"]["structure_fingerprint"]
    assert data["site_groups"]["site1"]["source_kind"] == "Cr"
    assert data["site_groups"]["site1"]["count"] == 8
    assert data["site_groups"]["site1"]["site_indices"] == list(range(0, 8))
    assert data["site_groups"]["site1"]["label"]["display"] == "Cr@a"
    assert data["site_groups"]["site1"]["symmetry"]["site_symmetry"] == "-43m"
    assert data["site_groups"]["site2"]["source_kind"] == "Cr"
    assert data["site_groups"]["site2"]["count"] == 16
    assert data["site_groups"]["site2"]["site_indices"] == list(range(8, 24))
    assert data["site_groups"]["site2"]["label"]["display"] == "Cr@d"
    assert data["site_groups"]["site3"]["source_kind"] == "O"
    assert data["site_groups"]["site3"]["site_indices"] == list(range(24, 56))
    assert data["charges"]["basis"] == "element_site"
    assert data["charges"]["elements"]["Cr"]["by_site"]["site1"] == 3.0
    assert data["charges"]["elements"]["Cr"]["by_site"]["site2"] == 3.0
    assert data["charges"]["elements"]["Ni"]["by_site"]["site1"] == 2.0
    assert data["charges"]["elements"]["O"]["by_site"]["site3"] == -2.0


def test_cli_init_element_site_defaults_to_poscar_kind_site_indices(tmp_path: Path):
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "init",
            "-p",
            str(POSCAR),
            "--out",
            str(out),
            "--composition",
            "Mn=2,Cr=4,O=8",
            "--charges",
            "Mn=2,Cr=3,O=-2",
            "--charge-basis",
            "element_site",
            "--recipe",
            "Mn:Mn",
            "--recipe",
            "Cr:Cr",
            "--recipe",
            "O:O",
            "--selection-enabled",
            "false",
        ]
    )

    assert rc == 0
    data = yaml.safe_load(out.read_text())
    assert data["site_grouping"]["mode"] == "poscar_kind"
    assert data["site_groups"]["site1"]["source_kind"] == "Mn"
    assert data["site_groups"]["site1"]["site_indices"] == [0, 1]
    assert data["site_groups"]["site2"]["source_kind"] == "Cr"
    assert data["site_groups"]["site2"]["site_indices"] == [2, 3, 4, 5]
    assert data["site_groups"]["site3"]["source_kind"] == "O"
    assert data["site_groups"]["site3"]["site_indices"] == list(range(6, 14))
    assert data["charges"]["elements"]["Mn"]["by_site"]["site1"] == 2.0
    assert data["charges"]["elements"]["Cr"]["by_site"]["site2"] == 3.0
    assert data["charges"]["elements"]["O"]["by_site"]["site3"] == -2.0


def test_cli_init_from_poscar_accepts_diagonal_dim_matrix(tmp_path: Path):
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "init",
            "from-poscar",
            str(POSCAR),
            "--out",
            str(out),
            "--name",
            "CCS02",
            "--dim",
            "2",
            "0",
            "0",
            "0",
            "2",
            "0",
            "0",
            "0",
            "2",
            "--fixed",
            "O",
            "--composition",
            "Mn=14,Cr=15,Ni=19,O=64",
            "--charges",
            "Mn=1.512165,Cr=1.707951,Ni=1.299835,O=-1.116975625",
            "--recipe",
            "Mn->Mn,Ni",
            "--recipe",
            "Cr->Cr,Ni",
            "--symmetry",
            "p1",
        ]
    )

    assert rc == 0
    data = yaml.safe_load(out.read_text())
    assert data["structure"]["dim"] == [[2, 0, 0], [0, 2, 0], [0, 0, 2]]

    parsed = load_run_input(out)
    assert parsed.guide.composition.n_target_sites == 112
    assert parsed.guide.supercell_expansion == (2, 2, 2)


def test_cli_init_unified_poscar_minimal_accepts_dim(tmp_path: Path, capsys):
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "--json",
            "init",
            "-p",
            str(POSCAR),
            "--out",
            str(out),
            "--dim",
            "2",
            "2",
            "2",
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)
    assert payload["sposcar"] == str(tmp_path / "SPOSCAR")
    assert (tmp_path / "SPOSCAR").exists()

    data = yaml.safe_load(out.read_text())
    assert data["structure"]["dim"] == [2, 2, 2]
    assert "n_target_sites" not in data["structure"]

    parsed = load_run_input(out)
    assert parsed.guide.composition.n_target_sites == 112
    assert parsed.guide.supercell_expansion == (2, 2, 2)


def test_cli_init_unified_solve_strategy_flags(tmp_path: Path):
    out = tmp_path / "input.yaml"
    rc = main(
        [
            "init",
            "-p",
            str(POSCAR),
            "--out",
            str(out),
            "--solve-mode",
            "bounded_exhaustive",
            "--solve-effort",
            "high",
            "--time-budget-sec",
            "1800",
            "--max-swap",
            "250",
        ]
    )
    assert rc == 0

    data = yaml.safe_load(out.read_text())
    strategy = data["solve"]["strategy"]
    assert strategy["mode"] == "bounded_exhaustive"
    assert strategy["effort"] == "high"
    assert strategy["time_budget_sec"] == 1800
    assert strategy["swap"]["enabled"] is True
    assert strategy["swap"]["max_steps"] == 250
    raw = out.read_text()
    assert "mode: auto  # symmetry mode: auto | p1" in raw
    assert "symprec: 1.0e-05  # symmetry tolerance for detection" in raw
    assert "write_wyc_path: symmetry.wyc  # output path for detected WYC operations" in raw
    assert "target_cpu_time_sec: 100  # guider target CPU time in seconds" in raw
    assert "n_random_seeds: 2000  # guider random seed count" in raw
    assert "mode: bounded_exhaustive  # adaptive | bounded_exhaustive | exhaustive" in raw
    assert "effort: high  # low | medium | high | extreme" in raw
    assert "time_budget_sec: 1800  # used when mode=adaptive (default 600)" in raw


def test_cli_init_unified_placeholder_m_auto_recipe_includes_x(tmp_path: Path):
    poscar = tmp_path / "POSCAR"
    poscar.write_text(
        "\n".join(
            [
                "M6O8",
                "1.0",
                "1 0 0",
                "0 1 0",
                "0 0 1",
                "M O",
                "6 8",
                "Direct",
            ]
            + ["0 0 0"] * 14
        )
        + "\n"
    )
    out = tmp_path / "input.yaml"

    rc = main(["init", "-p", str(poscar), "--out", str(out)])
    assert rc == 0

    data = yaml.safe_load(out.read_text())
    assert data["recipes"] == [{"from": "M", "to": ["M", "X"]}]
    assert data["charges"]["X"] == 2.0


def test_parse_recipe_supports_colon_and_equals(tmp_path: Path):
    out = tmp_path / "input.yaml"
    rc = main(
        [
            "init",
            "-p",
            str(POSCAR),
            "--out",
            str(out),
            "--composition",
            "Mn=2,Cr=4,O=8",
            "--charges",
            "Mn=2,Cr=3,O=-2",
            "--recipe",
            "Mn:Mn,Ni",
            "--recipe",
            "Cr=Cr,Ni",
        ]
    )
    assert rc == 0
    data = yaml.safe_load(out.read_text())
    assert data["recipes"] == [
        {"from": "Mn", "to": ["Mn", "Ni"]},
        {"from": "Cr", "to": ["Cr", "Ni"]},
    ]


def test_unified_init_recipe_expands_placeholder_to_fraction_composition(tmp_path: Path):
    poscar = tmp_path / "POSCAR"
    poscar.write_text(
        "\n".join(
            [
                "M6O8",
                "1.0",
                "1 0 0",
                "0 1 0",
                "0 0 1",
                "M O",
                "6 8",
                "Direct",
            ]
            + ["0 0 0"] * 14
        )
        + "\n"
    )
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "init",
            "-p",
            str(poscar),
            "--out",
            str(out),
            "--recipe",
            "M:Mn,Ni,Cr,Ni",
        ]
    )
    assert rc == 0
    data = yaml.safe_load(out.read_text())
    fractions = data["composition"]["fractions"]
    assert fractions["Mn"] == 1.5 / 14.0
    assert fractions["Cr"] == 1.5 / 14.0
    assert fractions["Ni"] == 3.0 / 14.0
    assert fractions["O"] == 8.0 / 14.0
    assert (tmp_path / "input-example.yaml").exists()


def test_unified_init_without_recipe_does_not_write_example_sidecar(tmp_path: Path):
    out = tmp_path / "input.yaml"
    rc = main(["init", "-p", str(POSCAR), "--out", str(out)])
    assert rc == 0
    assert not (tmp_path / "input-example.yaml").exists()


def test_examples_block_is_ignored_by_runtime_config_loader(tmp_path: Path):
    out = tmp_path / "input.yaml"
    rc = main(["init", "-p", str(POSCAR), "--out", str(out)])
    assert rc == 0
    parsed = load_run_input(out)
    assert parsed.guide.composition.number_fixed_at == "O"
    assert any(entry.kind == "O" for entry in parsed.guide.composition.entries)


def test_logging_block_is_optional_and_defaults_apply(tmp_path: Path):
    out = tmp_path / "input.yaml"
    rc = main(["init", "-p", str(POSCAR), "--out", str(out)])
    assert rc == 0

    data = yaml.safe_load(out.read_text())
    data.pop("logging")
    out.write_text(yaml.safe_dump(data, sort_keys=False))

    parsed = load_run_input(out)
    assert parsed.logging.console is True
    assert parsed.logging.file is True
    assert parsed.logging.progress_jsonl is True
    assert parsed.logging.per_rank_logs is True
    assert parsed.logging.interval_sec == 10.0
    assert parsed.solve.enumeration_save_memory is True
