"""Unit tests for wizard interstitial-driven workflow."""

import pytest
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch


class TestWizardElementListParsing:
    """Tests for wizard element-list parsing."""

    def test_parse_element_list_accepts_spaces(self):
        from esspy.wizard import _parse_element_list

        assert _parse_element_list("Mn  Cr  Ni  Rh  Co  Fe") == [
            "Mn",
            "Cr",
            "Ni",
            "Rh",
            "Co",
            "Fe",
        ]

    def test_parse_element_list_accepts_commas_and_mixed_separators(self):
        from esspy.wizard import _parse_element_list

        assert _parse_element_list("Mn, Cr Ni,  Rh") == ["Mn", "Cr", "Ni", "Rh"]

    def test_append_unique_preserves_first_seen_order(self):
        from esspy.wizard import _append_unique_in_order

        elements = []
        _append_unique_in_order(elements, ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"])
        _append_unique_in_order(elements, ["O", "Mn"])

        assert elements == ["Mn", "Cr", "Ni", "Rh", "Co", "Fe", "O"]

    def test_parse_count_input_classifies_int_and_fraction(self):
        from esspy.wizard import _parse_count_input

        assert _parse_count_input("7") == ("int", 7.0)
        assert _parse_count_input("0.0625") == ("fraction", 0.0625)
        mode, value = _parse_count_input("1/16")
        assert mode == "fraction"
        assert value == pytest.approx(0.0625)


class TestWizardSubstitutionRecipes:
    """Tests for source-site based substitution recipe prompts."""

    def test_substitution_recipes_default_to_element_mapping_sources(self):
        from esspy.wizard import WizardSession

        wizard = WizardSession()
        wizard.state.element_mapping = {
            "M": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
            "O": ["O"],
        }
        wizard.state.composition = {
            "Mn": 7,
            "Cr": 14,
            "Ni": 10,
            "Rh": 5,
            "Co": 7,
            "Fe": 5,
            "O": 64,
        }

        with patch("builtins.input", side_effect=["", ""]):
            assert wizard.step_5_substitution_recipes()

        assert wizard.state.recipes == {
            "M": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
            "O": ["O"],
        }
        assert wizard.validate_recipes() == (True, [])

    def test_substitution_recipes_accept_space_separated_source_mapping(self):
        from esspy.wizard import WizardSession

        wizard = WizardSession()
        wizard.state.element_mapping = {"M": ["Mn", "Cr", "Ni"], "O": ["O"]}
        wizard.state.composition = {"Mn": 1, "Cr": 2, "Ni": 3, "O": 4}

        with patch("builtins.input", side_effect=["Mn Cr Ni", ""]):
            assert wizard.step_5_substitution_recipes()

        assert wizard.state.recipes["M"] == ["Mn", "Cr", "Ni"]
        assert wizard.state.recipes["O"] == ["O"]


class TestWizardSolveDefaults:
    """Tests for wizard-generated solve defaults."""

    def test_production_solve_block_uses_non_tiny_enumeration_defaults(self):
        from esspy.wizard import _production_solve_block

        block = _production_solve_block()

        strategy = block["strategy"]
        assert strategy["mode"] == "adaptive"
        assert strategy["time_budget_sec"] == 600
        assert strategy["effort"] == "medium"
        assert strategy["swap"]["enabled"] is True
        assert strategy["swap"]["max_steps"] == 100

    def test_host_output_block_uses_stage_based_names(self):
        from esspy.wizard import _host_output_block

        block = _host_output_block()

        assert block["input_filename"] == "input.yaml"
        assert block["poscar_filename"] == "POSCAR_host_supercell.vasp"
        assert block["best_poscar_filename"] == "POSCAR_host_best.vasp"
        assert block["worst_poscar_filename"] == "POSCAR_host_worst.vasp"
        assert block["summary_filename"] == "host_summary.json"
        assert block["energy_filename"] == "host_energies.txt"


def test_wizard_show_summary_includes_solve_strategy(capsys):
    from esspy.wizard import WizardSession

    wizard = WizardSession()
    wizard.state.reference_structure = "POSCAR"
    wizard.state.composition = {"Mn": 7, "Cr": 14, "Ni": 10, "O": 64}
    wizard.state.charges = {"Mn": 1.5, "Cr": 1.7, "Ni": 1.3, "O": -1.11875}
    wizard.state.recipes = {"M": ["Mn", "Cr", "Ni"], "O": ["O"]}

    wizard.show_summary()
    output = capsys.readouterr().out

    assert "Solve Strategy:" in output
    assert "Mode: adaptive" in output
    assert "Time budget: 600 sec" in output
    assert "Effort: medium" in output
    assert "Swap: enabled=True, max_steps=100" in output


def test_render_menu_accepts_default_index_on_empty_input(monkeypatch):
    from esspy.wizard import WizardSession

    wizard = WizardSession()
    monkeypatch.setattr("builtins.input", lambda _prompt: "")
    choice = wizard.render_menu(
        "Choose solve mode:",
        ["adaptive", "bounded_exhaustive", "exhaustive"],
        default_index=0,
    )
    assert choice == 0


class TestWizardWycFileFinding:
    """Tests for _find_wyc_file() method."""

    def test_find_wyc_file_returns_none_when_not_found(self):
        """Test that _find_wyc_file returns None for non-existent WYC file."""
        from esspy.wizard import WizardSession

        # Create a minimal wizard session
        wizard = MagicMock(spec=WizardSession)
        wizard.cwd = Path.cwd()

        # Call actual method without mocking
        wizard._find_wyc_file = WizardSession._find_wyc_file.__get__(wizard)

        # Should return None for non-existent space group
        result = wizard._find_wyc_file(999)
        assert result is None

    def test_find_wyc_file_returns_path_when_exists(self):
        """Test that _find_wyc_file returns Path when WYC file exists."""
        from esspy.wizard import WizardSession

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a fake WYC file
            wyc_path = Path(tmpdir) / "194.wyc"
            wyc_path.write_text("# Dummy WYC file for space group 194\n")

            # Create wizard and set cwd
            wizard = MagicMock(spec=WizardSession)
            wizard.cwd = tmpdir

            # Bind actual method
            wizard._find_wyc_file = WizardSession._find_wyc_file.__get__(wizard)

            # Mock Path.cwd() to return our temp directory
            with patch('pathlib.Path.cwd', return_value=Path(tmpdir)):
                result = wizard._find_wyc_file(194)
                assert result is not None
                assert result.exists()
                assert result.name == "194.wyc"

    def test_find_wyc_file_skips_invalid_paths(self):
        """Test that _find_wyc_file gracefully handles invalid paths."""
        from esspy.wizard import WizardSession

        wizard = MagicMock(spec=WizardSession)
        wizard.cwd = Path.cwd()
        wizard._find_wyc_file = WizardSession._find_wyc_file.__get__(wizard)

        # Should not raise exception even with invalid paths
        result = wizard._find_wyc_file(194)
        assert result is None or isinstance(result, Path)


class TestWizardCompositionTransforms:
    """Tests for composition transformation methods."""

    def test_apply_recipes_divides_equally(self):
        """Test that recipes with multiple targets are divided equally."""
        from esspy.wizard import WizardSession

        wizard = MagicMock(spec=WizardSession)
        wizard._apply_recipes_to_composition = (
            WizardSession._apply_recipes_to_composition.__get__(wizard)
        )

        # Test case: Zn32 with recipe [Mn, Cr] should become Mn16 Cr16
        base_comp = {"Zn": 32, "O": 32}
        recipes = {"Zn": ["Mn", "Cr"], "O": ["O"]}
        result = wizard._apply_recipes_to_composition(base_comp, recipes)

        assert result["Mn"] == 16
        assert result["Cr"] == 16
        assert result["O"] == 32
        assert "Zn" not in result

    def test_apply_recipes_preserves_non_substituted(self):
        """Test that non-substituted elements are preserved."""
        from esspy.wizard import WizardSession

        wizard = MagicMock(spec=WizardSession)
        wizard._apply_recipes_to_composition = (
            WizardSession._apply_recipes_to_composition.__get__(wizard)
        )

        # O and Zn both have single targets
        base_comp = {"Zn": 32, "O": 32}
        recipes = {"Zn": ["Mn"], "O": ["O"]}
        result = wizard._apply_recipes_to_composition(base_comp, recipes)

        assert result["Mn"] == 32
        assert result["O"] == 32

    def test_apply_recipes_with_remainder(self):
        """Test recipe application with uneven division."""
        from esspy.wizard import WizardSession

        wizard = MagicMock(spec=WizardSession)
        wizard._apply_recipes_to_composition = (
            WizardSession._apply_recipes_to_composition.__get__(wizard)
        )

        # 33 atoms divided by 3 targets -> 11 each, remainder 0
        base_comp = {"X": 33, "O": 32}
        recipes = {"X": ["A", "B", "C"], "O": ["O"]}
        result = wizard._apply_recipes_to_composition(base_comp, recipes)

        assert sum([result.get("A", 0), result.get("B", 0), result.get("C", 0)]) == 33
        assert result["O"] == 32


class TestWizardPoscarExtraction:
    """Tests for POSCAR composition extraction."""

    def test_extract_composition_from_valid_poscar(self):
        """Test extraction of composition from valid POSCAR file."""
        from esspy.wizard import WizardSession

        with tempfile.NamedTemporaryFile(mode='w', suffix='.vasp', delete=False) as f:
            # Write a minimal POSCAR
            f.write("Test structure\n")
            f.write("1.0\n")
            f.write("3.0 0.0 0.0\n")
            f.write("0.0 3.0 0.0\n")
            f.write("0.0 0.0 3.0\n")
            f.write("Zn O Li\n")  # Line 6: elements
            f.write("36 36 1\n")  # Line 7: counts
            f.write("Direct\n")
            f.write("0.0 0.0 0.0\n")
            f.flush()

            wizard = MagicMock(spec=WizardSession)
            wizard._extract_composition_from_poscar = (
                WizardSession._extract_composition_from_poscar.__get__(wizard)
            )

            result = wizard._extract_composition_from_poscar(Path(f.name))
            assert result == {"Zn": 36, "O": 36, "Li": 1}

    def test_extract_composition_returns_none_for_invalid(self):
        """Test that invalid POSCAR returns None."""
        from esspy.wizard import WizardSession

        with tempfile.NamedTemporaryFile(mode='w', suffix='.vasp', delete=False) as f:
            f.write("Invalid POSCAR\n")
            f.flush()

            wizard = MagicMock(spec=WizardSession)
            wizard._extract_composition_from_poscar = (
                WizardSession._extract_composition_from_poscar.__get__(wizard)
            )

            result = wizard._extract_composition_from_poscar(Path(f.name))
            assert result is None or result == {}


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
