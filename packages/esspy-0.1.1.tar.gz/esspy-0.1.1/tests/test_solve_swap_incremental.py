import pytest
from esspy.solve_swap_loop import compute_swap_loop, SwapLoopOptions
from esspy.models import ReadyModel, ReadyAtom, Lattice, ReadyRecipe, ReadyRecipeModification

def test_swap_incremental_stats():
    # Simple cubic lattice with 2 sites to allow a swap
    # 1.0, 0.0, 0.0
    # 0.0, 1.0, 0.0
    # 0.0, 0.0, 1.0
    lattice = Lattice((10.0, 0.0, 0.0), (0.0, 10.0, 0.0), (0.0, 0.0, 10.0))
    atoms = [
        ReadyAtom(kind="A", oxidation=1.0, x=0.0, y=0.0, z=0.0),
        ReadyAtom(kind="B", oxidation=2.0, x=0.5, y=0.5, z=0.5),
    ]
    # Define a recipe that allows swapping A and B
    recipes = [
        ReadyRecipe(
            from_kind="A",
            oxidation=1.0,
            random_pickup=1,
            random_pickup_trial=1,
            modifications=[
                ReadyRecipeModification(to="B", oxidation=2.0, count=0)
            ]
        ),
        ReadyRecipe(
            from_kind="B",
            oxidation=2.0,
            random_pickup=1,
            random_pickup_trial=1,
            modifications=[
                ReadyRecipeModification(to="A", oxidation=1.0, count=0)
            ]
        )
    ]
    ready = ReadyModel(
        lattice=lattice,
        atoms=atoms,
        supercell_expansion=(1, 1, 1),
        rg_find_factor=1,
        recipes=recipes
    )
    
    # We want a swap to happen. Since there are only 2 sites and they are different,
    # if one is more stable than the other, it might swap.
    # Actually, we can force a swap by providing a starting state that is less stable.
    # But let's just run and see.
    
    options = SwapLoopOptions(mode=1, max_swap=10)
    result = compute_swap_loop(ready, options)
    
    # Verify stats exist
    assert hasattr(result.cache_stats, "real_incremental_updates")
    assert hasattr(result.cache_stats, "point_incremental_updates")
    
    # If swaps happened, real_incremental_updates should be > 0
    if result.swap_count > 0:
        assert result.cache_stats.real_incremental_updates == result.swap_count
        assert result.cache_stats.point_incremental_updates == result.swap_count
        assert result.cache_stats.recip_incremental_updates == result.swap_count
    
    # The number of real cache evaluations should be small (rebuilds only when needed)
    # Actually, initial evaluate_total_with_cache will trigger rebuild.
    assert result.cache_stats.real_cache_evaluations >= 1

def test_swap_incremental_correctness():
    # Verify that incremental energy matches full evaluation
    lattice = Lattice((5.0, 0.0, 0.0), (0.0, 5.0, 0.0), (0.0, 0.0, 5.0))
    # 4 sites to have more complex interactions
    atoms = [
        ReadyAtom(kind="A", oxidation=1.0, x=0.0, y=0.0, z=0.0),
        ReadyAtom(kind="B", oxidation=2.0, x=0.5, y=0.0, z=0.0),
        ReadyAtom(kind="C", oxidation=3.0, x=0.0, y=0.5, z=0.0),
        ReadyAtom(kind="D", oxidation=4.0, x=0.0, y=0.0, z=0.5),
    ]
    recipes = [
        ReadyRecipe(
            from_kind="A", oxidation=1.0, random_pickup=1, random_pickup_trial=1,
            modifications=[ReadyRecipeModification(to="B", oxidation=2.0, count=0)]
        ),
        ReadyRecipe(
            from_kind="B", oxidation=2.0, random_pickup=1, random_pickup_trial=1,
            modifications=[ReadyRecipeModification(to="A", oxidation=1.0, count=0)]
        )
    ]
    ready = ReadyModel(lattice=lattice, atoms=atoms, recipes=recipes)
    
    result = compute_swap_loop(ready, SwapLoopOptions(max_swap=5))
    
    # Final total energy should match a fresh evaluation of the final structure
    # We can use evaluate_ready_energy if we expose it, or just rely on the fact that
    # the swap loop itself does a fresh eval at the end if we want, but it doesn't.
    # However, we can compare it with a no-op swap loop starting from the final structure.
    
    if result.swap_count > 0:
        options_noop = SwapLoopOptions(max_swap=0, starting_sites=result.final_structure.sites)
        result_noop = compute_swap_loop(ready, options_noop)
        
        # result_noop.initial_total_energy is a fresh evaluation of the final state
        assert pytest.approx(result.final_total_energy) == result_noop.initial_total_energy
