from pathlib import Path

from esspy import parse_guider_text_to_guide_input_native, parse_wyc_file_to_symmetry_model
from esspy.native import load_native_module


GUIDER_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
)
GUIDER_G002 = Path(
    "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt"
)
GUIDER_G004 = Path(
    "tests/golden/fixtures/G004_CCS02_P1_ADDED/basic_properties_EwaldSolidSolutionGuider.txt"
)
WYC_G004 = Path("tests/golden/fixtures/G004_CCS02_P1_ADDED/1.wyc")


def test_g001_skip_ewald_keeps_rg_one():
    native = load_native_module()
    result = native.guide(parse_guider_text_to_guide_input_native(GUIDER_G001))
    assert result["ready"]["rg_find_factor"] == 1
    assert any("skipped *write_only" in line for line in result["diagnostics"]["messages"])


def test_g002_skip_ewald_keeps_rg_one():
    native = load_native_module()
    result = native.guide(parse_guider_text_to_guide_input_native(GUIDER_G002))
    assert result["ready"]["rg_find_factor"] == 1
    assert any("skipped *write_only" in line for line in result["diagnostics"]["messages"])


def test_g004_rg_optimizer_converges_to_three():
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(GUIDER_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)
    guide_input["symmetry"]["wyc_operations"] = [list(op.matrix) for op in symmetry.wyc_operations]
    result = native.guide(guide_input)
    assert result["ready"]["rg_find_factor"] == 3
    assert any("RGFindFactor= 3:" in line and "*" in line for line in result["diagnostics"]["messages"])
