from __future__ import annotations

import json
from pathlib import Path

from esspy.cli import main
from esspy.guider_text import parse_guider_text


def _write_full_poscar_workflow_yaml(path: Path) -> Path:
    poscar = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()
    path.write_text(
        "structure:\n"
        "  title: CCS02_full_poscar\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 112\n"
        "  number_fixed_at: O\n"
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n"
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n"
        "recipes:\n"
        "  - from: Mn\n"
        "    to: [Mn, Ni]\n"
        "  - from: Cr\n"
        "    to: [Cr, Ni]\n"
        "symmetry:\n"
        "  space_group: 1\n"
        "guide:\n"
        "  fixed_rg_find_factor: 1\n"
        "  strict_no_added_sites: true\n"
        "  skip_ewald_evaluation: true\n"
        "solve:\n"
        "  swap: true\n"
        "  max_swap: 2\n"
        "runtime:\n"
        "  use_mpi: false\n"
    )
    return path


def _write_strategy_execution_mode_yaml(path: Path) -> Path:
    poscar = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()
    path.write_text(
        "structure:\n"
        "  title: CCS02_execution_mode\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 112\n"
        "  number_fixed_at: O\n"
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n"
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n"
        "recipes:\n"
        "  - from: Mn\n"
        "    to: [Mn, Ni]\n"
        "  - from: Cr\n"
        "    to: [Cr, Ni]\n"
        "symmetry:\n"
        "  space_group: 1\n"
        "guide:\n"
        "  fixed_rg_find_factor: 1\n"
        "  strict_no_added_sites: true\n"
        "  skip_ewald_evaluation: true\n"
        "solve:\n"
        "  strategy:\n"
        "    mode: adaptive\n"
        "    effort: medium\n"
        "    execution_mode: scalable\n"
        "    time_budget_sec: 600\n"
        "runtime:\n"
        "  use_mpi: false\n"
    )
    return path


def _write_placeholder_m_workflow_yaml(path: Path) -> Path:
    poscar = Path("tests/golden/fixtures/G002_CCS03/POSCAR-M48O64.vasp").resolve()
    path.write_text(
        "name: CCS03_placeholder\n"
        "structure:\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 112\n"
        "  number_fixed_at: O\n"
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n"
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n"
        "recipes:\n"
        "  - from: M\n"
        "    to: [Mn, Cr, Ni]\n"
        "  - from: O\n"
        "    to: [O]\n"
        "symmetry:\n"
        "  space_group: 1\n"
        "guide:\n"
        "  fixed_rg_find_factor: 1\n"
        "  skip_ewald_evaluation: true\n"
    )
    return path


def test_cli_guide_inspect(tmp_path: Path, capsys):
    input_path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")

    rc = main(["--json", "guide", "inspect", str(input_path)])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["title"] == "CCS02_full_poscar"
    assert payload["n_target_sites"] == 112
    assert payload["composition"]["O"] == 64
    assert payload["solve_strategy"]["input_strategy"] is None
    assert payload["solve_strategy"]["resolved_legacy_mapping"]["running_index_delta"] == 10000
    assert payload["solve_strategy"]["resolved_legacy_mapping"]["max_swap"] == 2


def test_cli_guide_inspect_strategy_execution_mode_scalable(tmp_path: Path, capsys):
    input_path = _write_strategy_execution_mode_yaml(tmp_path / "input.yaml")

    rc = main(["--json", "guide", "inspect", str(input_path)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    mapping = payload["solve_strategy"]["resolved_legacy_mapping"]

    assert mapping["running_index_delta"] == -600
    assert mapping["local_enumeration_limit"] == 100000
    assert mapping["local_enumeration_max_chunks"] == 2000000
    assert mapping["running_index_monitor"] == 50000
    assert mapping["enumeration_save_memory"] is True
    assert mapping["mpi_adaptive_stride_sync"] is True


def test_cli_guide_inspect_strategy_profile_alias_still_supported(tmp_path: Path, capsys):
    input_path = _write_strategy_execution_mode_yaml(tmp_path / "input.yaml")
    text = input_path.read_text().replace(
        "    execution_mode: scalable\n",
        "    profile: throughput\n",
    )
    input_path.write_text(text)

    rc = main(["--json", "guide", "inspect", str(input_path)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    mapping = payload["solve_strategy"]["resolved_legacy_mapping"]
    assert mapping["local_enumeration_limit"] == 100000
    assert mapping["mpi_adaptive_stride_sync"] is True


def test_cli_guide_inspect_human_readable_yaml(tmp_path: Path, capsys):
    input_path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")

    rc = main(["guide", "inspect", str(input_path)])
    assert rc == 0
    out = capsys.readouterr().out
    assert "title: CCS02_full_poscar" in out
    assert "n_target_sites: 112" in out


def test_cli_guide_prepare_writes_summary(tmp_path: Path, capsys):
    input_path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    out = tmp_path / "guide_summary.json"

    rc = main(["guide", "prepare", str(input_path), "--out", str(out)])

    assert rc == 0
    payload = json.loads(out.read_text())
    stdout_payload = json.loads(capsys.readouterr().out)
    assert payload["title"] == "CCS02_full_poscar"
    assert stdout_payload["title"] == payload["title"]


def test_cli_guide_export_ready(tmp_path: Path, capsys):
    input_path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    out = tmp_path / "ready.txt"

    rc = main(["guide", "export-ready", str(input_path), "--out", str(out)])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)
    assert "NAtomConfig" in out.read_text()


def test_cli_guide_export_poscar(tmp_path: Path, capsys):
    input_path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    out = tmp_path / "POSCAR.vasp"

    rc = main(["guide", "export-poscar", str(input_path), "--out", str(out)])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)
    assert "Direct" in out.read_text()


def test_cli_guide_export_guider(tmp_path: Path, capsys):
    input_path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    out = tmp_path / "basic_properties_EwaldSolidSolutionGuider.txt"

    rc = main(["guide", "export-guider", str(input_path), "--out", str(out)])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)
    text = out.read_text()
    assert "====IonList====" in text
    assert "====InputFilename_Prefix_SapceGroup_Recipe_List====" in text
    parsed = parse_guider_text(out)
    assert parsed.n_target_sites == 112
    assert parsed.output_prefix == "CCS02_full_poscar"
    assert parsed.recipes[0].from_kind == "Mn"
    assert parsed.recipes[1].to == ["Cr", "Ni"]


def test_cli_guide_export_guider_includes_source_kind_charge(tmp_path: Path, capsys):
    input_path = _write_placeholder_m_workflow_yaml(tmp_path / "input.yaml")
    out = tmp_path / "basic_properties_EwaldSolidSolutionGuider.txt"

    rc = main(["guide", "export-guider", str(input_path), "--out", str(out)])
    assert rc == 0
    _ = json.loads(capsys.readouterr().out)

    text = out.read_text()
    ionlist_block = text.split("====IonList====", 1)[1].split("STOP", 1)[0]
    assert "M 2.0000000000" in ionlist_block
