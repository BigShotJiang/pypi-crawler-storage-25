import json
from pathlib import Path

import pytest

import esspy.config as config_mod
from esspy import ESSWorkflow, load_poscar, load_run_input
from esspy.models import SymmetryModel, SymmetryOperation
from esspy.site_grouping import structure_site_fingerprint


def _write_full_poscar_workflow_yaml(path: Path) -> Path:
    poscar = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()
    path.write_text(
        "structure:\n"
        "  title: CCS02_full_poscar\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 112\n"
        "  number_fixed_at: O\n"
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n"
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n"
        "recipes:\n"
        "  - from: Mn\n"
        "    to: [Mn, Ni]\n"
        "  - from: Cr\n"
        "    to: [Cr, Ni]\n"
        "symmetry:\n"
        "  space_group: 1\n"
        "guide:\n"
        "  fixed_rg_find_factor: 1\n"
        "  strict_no_added_sites: true\n"
        "  skip_ewald_evaluation: true\n"
        "solve:\n"
        "  swap: true\n"
        "  max_swap: 2\n"
        "runtime:\n"
        "  use_mpi: false\n"
    )
    return path


def test_load_run_input_explicit_example():
    path = Path("examples/explicit_structure/input.yaml")
    config = load_run_input(path)

    assert config.guide.structure.title == "CCS02_explicit_stub"
    assert config.guide.composition.n_target_sites == 112
    assert [entry.kind for entry in config.guide.composition.entries] == ["Mn", "Cr", "Ni", "O"]
    assert config.guide.recipes[0].from_kind == "Mn"
    assert config.guide.options.fixed_rg_find_factor == 2


def test_load_run_input_composition_counts_schema(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text()
    text = text.replace(
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n",
        "composition:\n"
        "  counts:\n"
        "    Mn: 14\n"
        "    Cr: 15\n"
        "    Ni: 19\n"
        "    O: 64\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert [(entry.kind, entry.count) for entry in parsed.guide.composition.entries] == [
        ("Mn", 14),
        ("Cr", 15),
        ("Ni", 19),
        ("O", 64),
    ]


def test_load_run_input_composition_fractions_schema(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text()
    text = text.replace(
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n",
        "composition:\n"
        "  fractions:\n"
        "    Mn: 0.125\n"
        "    Cr: 0.1339285714\n"
        "    Ni: 0.1696428571\n"
        "    O: 0.5714285714\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert [(entry.kind, entry.count) for entry in parsed.guide.composition.entries] == [
        ("Mn", 14),
        ("Cr", 15),
        ("Ni", 19),
        ("O", 64),
    ]


def test_load_run_input_structure_dim_derives_target_sites(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text().replace(
        "  n_target_sites: 112\n",
        "  dim: [2, 2, 2]\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert parsed.guide.composition.n_target_sites == 112
    assert parsed.guide.supercell_expansion == (2, 2, 2)


def test_load_run_input_structure_dim_must_match_target_sites(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text().replace(
        "  n_target_sites: 112\n",
        "  n_target_sites: 112\n"
        "  dim: [2, 1, 1]\n",
    )
    path.write_text(text)

    with pytest.raises(ValueError, match="does not match"):
        load_run_input(path)


def test_load_run_input_structure_dim_matrix_accepts_diagonal(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text().replace(
        "  n_target_sites: 112\n",
        "  dim:\n"
        "    - [2, 0, 0]\n"
        "    - [0, 2, 0]\n"
        "    - [0, 0, 2]\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert parsed.guide.composition.n_target_sites == 112
    assert parsed.guide.supercell_expansion == (2, 2, 2)


def test_load_run_input_structure_dim_matrix_rejects_non_diagonal(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text().replace(
        "  n_target_sites: 112\n",
        "  dim:\n"
        "    - [2, 1, 0]\n"
        "    - [0, 2, 0]\n"
        "    - [0, 0, 2]\n",
    )
    path.write_text(text)

    with pytest.raises(ValueError, match="non-diagonal"):
        load_run_input(path)


def _site_grouping_poscar_target_yaml(site_groups: str, *, fingerprint: str | None = None) -> str:
    poscar = Path("examples/site_grouping_wyckoff/POSCAR-target").resolve()
    site_grouping = ""
    if fingerprint is not None:
        site_grouping = (
            "site_grouping:\n"
            "  mode: element_wyckoff\n"
            "  source:\n"
            f"    structure_fingerprint: {fingerprint}\n"
        )
    return (
        "structure:\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 56\n"
        "composition:\n"
        "  Cr: 24\n"
        "  Mn: 0\n"
        "  O: 32\n"
        "charges:\n"
        "  Cr: 3.0\n"
        "  Mn: 2.0\n"
        "  O: -2.0\n"
        "recipes:\n"
        "  - from_kind: Cr\n"
        "    to: [Cr, Mn]\n"
        "  - from_kind: O\n"
        "    to: [O]\n"
        f"{site_grouping}"
        "site_groups:\n"
        f"{site_groups}"
    )


def _write_site_grouping_poscar_target_yaml(
    path: Path,
    site_groups: str,
    *,
    fingerprint: str | None = None,
) -> Path:
    path.write_text(_site_grouping_poscar_target_yaml(site_groups, fingerprint=fingerprint))
    return path


def test_site_groups_explicit_indices_validate(tmp_path):
    poscar = Path("examples/site_grouping_wyckoff/POSCAR-target").resolve()
    fingerprint = structure_site_fingerprint(load_poscar(poscar))
    path = _write_site_grouping_poscar_target_yaml(
        tmp_path / "input.yaml",
        "  site1:\n"
        "    source_kind: Cr\n"
        "    count: 8\n"
        "    site_indices: [0, 1, 2, 3, 4, 5, 6, 7]\n"
        "    allowed: [Cr, Mn]\n"
        "  site2:\n"
        "    source_kind: Cr\n"
        "    count: 16\n"
        "    site_indices: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]\n"
        "    allowed: [Cr, Mn]\n"
        "  site3:\n"
        "    source_kind: O\n"
        "    count: 32\n"
        "    site_indices: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]\n"
        "    allowed: [O]\n",
        fingerprint=fingerprint,
    )

    parsed = load_run_input(path)

    assert parsed.guide.structure.sites[0].kind == "Cr"
    assert parsed.guide.structure.sites[24].kind == "O"


def test_site_groups_with_duplicate_source_kind_require_indices(tmp_path):
    path = _write_site_grouping_poscar_target_yaml(
        tmp_path / "input.yaml",
        "  site1:\n"
        "    source_kind: Cr\n"
        "    count: 8\n"
        "    allowed: [Cr, Mn]\n"
        "  site2:\n"
        "    source_kind: Cr\n"
        "    count: 16\n"
        "    allowed: [Cr, Mn]\n"
        "  site3:\n"
        "    source_kind: O\n"
        "    count: 32\n"
        "    allowed: [O]\n",
    )

    with pytest.raises(ValueError, match="duplicate `site_groups` source_kind `Cr`"):
        load_run_input(path)


def test_site_groups_explicit_indices_reject_count_mismatch(tmp_path):
    path = _write_site_grouping_poscar_target_yaml(
        tmp_path / "input.yaml",
        "  site1:\n"
        "    source_kind: Cr\n"
        "    count: 9\n"
        "    site_indices: [0, 1, 2, 3, 4, 5, 6, 7]\n"
        "    allowed: [Cr, Mn]\n"
        "  site2:\n"
        "    source_kind: Cr\n"
        "    count: 16\n"
        "    site_indices: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]\n"
        "    allowed: [Cr, Mn]\n"
        "  site3:\n"
        "    source_kind: O\n"
        "    count: 32\n"
        "    site_indices: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]\n"
        "    allowed: [O]\n",
    )

    with pytest.raises(ValueError, match="does not match `site_indices` length"):
        load_run_input(path)


def test_site_groups_reject_fingerprint_mismatch(tmp_path):
    path = _write_site_grouping_poscar_target_yaml(
        tmp_path / "input.yaml",
        "  site1:\n"
        "    source_kind: Cr\n"
        "    count: 24\n"
        "    site_indices: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]\n"
        "    allowed: [Cr, Mn]\n"
        "  site2:\n"
        "    source_kind: O\n"
        "    count: 32\n"
        "    site_indices: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]\n"
        "    allowed: [O]\n",
        fingerprint="not-the-current-structure",
    )

    with pytest.raises(ValueError, match="structure_fingerprint"):
        load_run_input(path)


def test_load_run_input_composition_fractions_are_normalized(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text()
    text = text.replace(
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n",
        "composition:\n"
        "  fractions:\n"
        "    Mn: 12.5\n"
        "    Cr: 13.39285714\n"
        "    Ni: 16.96428571\n"
        "    O: 57.14285714\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert [(entry.kind, entry.count) for entry in parsed.guide.composition.entries] == [
        ("Mn", 14),
        ("Cr", 15),
        ("Ni", 19),
        ("O", 64),
    ]


def test_load_run_input_composition_rejects_counts_and_fractions(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text()
    text = text.replace(
        "composition:\n"
        "  Mn: 14\n"
        "  Cr: 15\n"
        "  Ni: 19\n"
        "  O: 64\n",
        "composition:\n"
        "  counts:\n"
        "    Mn: 14\n"
        "    Cr: 15\n"
        "    Ni: 19\n"
        "    O: 64\n"
        "  fractions:\n"
        "    Mn: 0.125\n"
        "    Cr: 0.1339285714\n"
        "    Ni: 0.1696428571\n"
        "    O: 0.5714285714\n",
    )
    path.write_text(text)

    with pytest.raises(ValueError, match="must not define both"):
        load_run_input(path)


def test_load_run_input_composition_rejects_bad_count_sum(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    path.write_text(path.read_text().replace("  O: 64\n", "  O: 63\n", 1))

    with pytest.raises(ValueError, match="counts sum"):
        load_run_input(path)


def test_load_run_input_charges_model_file(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    charge_model = tmp_path / "charge_model.json"
    charge_model.write_text(
        json.dumps(
            {
                "charges": {
                    "basis": "element",
                    "values": {
                        "Mn": 1.51,
                        "Cr": 1.71,
                        "Ni": 1.30,
                        "O": -1.12,
                    },
                    "elements": {
                        "Mn": {"default": 1.51},
                        "Cr": {"default": 1.71},
                        "Ni": {"default": 1.30},
                        "O": {"default": -1.12},
                    },
                }
            }
        )
    )

    text = path.read_text()
    text = text.replace(
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n",
        "charges:\n"
        "  model: charge_model.json\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)
    charge_map = {entry.kind: entry.oxidation for entry in parsed.guide.charges.values}
    assert charge_map == {"Mn": 1.51, "Cr": 1.71, "Ni": 1.30, "O": -1.12}


def test_load_run_input_charges_mode_fitted(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    charge_model = tmp_path / "charge_model.json"
    charge_model.write_text(
        json.dumps(
            {
                "model_type": "effective_element_charge",
                "charges": {
                    "basis": "element",
                    "values": {
                        "Mn": 1.61,
                        "Cr": 1.81,
                        "Ni": 1.40,
                        "O": -1.22,
                    },
                    "elements": {
                        "Mn": {"default": 1.61},
                        "Cr": {"default": 1.81},
                        "Ni": {"default": 1.40},
                        "O": {"default": -1.22},
                    },
                },
            }
        )
    )

    text = path.read_text()
    text = text.replace(
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n",
        "charges:\n"
        "  mode: fitted\n"
        "  fitted_model: charge_model.json\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)
    charge_map = {entry.kind: entry.oxidation for entry in parsed.guide.charges.values}
    assert charge_map == {"Mn": 1.61, "Cr": 1.81, "Ni": 1.40, "O": -1.22}


def test_workflow_from_yaml_loads():
    workflow = ESSWorkflow.from_yaml("examples/explicit_structure/input.yaml")
    assert workflow.config.guide.structure.title == "CCS02_explicit_stub"
    assert workflow.config.solve.max_swap == 2


def test_workflow_stage_api_prepare_and_guide(tmp_path):
    workflow = ESSWorkflow.from_yaml(
        str(_write_full_poscar_workflow_yaml(tmp_path / "input.yaml"))
    )

    prepared = workflow.prepare()
    guide_result = workflow.guide()

    assert prepared is workflow.config
    assert guide_result.ready.rg_find_factor == 1
    assert guide_result.diagnostics.n_atom_config > 0


def test_workflow_stage_api_exports_ready_and_poscar(tmp_path):
    workflow = ESSWorkflow.from_yaml(
        str(_write_full_poscar_workflow_yaml(tmp_path / "input.yaml"))
    )
    ready_out = tmp_path / "ready.txt"
    poscar_out = tmp_path / "POSCAR.vasp"

    ready_text = workflow.export_ready_text(out=ready_out)
    poscar_text = workflow.export_poscar_text(out=poscar_out)

    assert ready_out.read_text() == ready_text
    assert poscar_out.read_text() == poscar_text
    assert "NAtomConfig" in ready_text
    assert "Direct" in poscar_text


def test_load_run_input_solve_strategy_adaptive_schema(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text()
    text = text.replace(
        "solve:\n"
        "  swap: true\n"
        "  max_swap: 2\n",
        "solve:\n"
        "  strategy:\n"
        "    mode: adaptive\n"
        "    time_budget_sec: 3600\n"
        "    effort: high\n"
        "    swap:\n"
        "      enabled: true\n"
        "      max_steps: 120\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert parsed.solve.running_index_delta == -3600
    assert parsed.solve.enumeration_exhaust_all is False
    assert parsed.solve.local_enumeration_limit == 20000
    assert parsed.solve.local_enumeration_max_chunks == 5000000
    assert parsed.solve.max_swap == 120
    assert parsed.solve.swap is True


def test_load_run_input_solve_strategy_exhaustive_schema(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text()
    text = text.replace(
        "solve:\n"
        "  swap: true\n"
        "  max_swap: 2\n",
        "solve:\n"
        "  strategy:\n"
        "    mode: exhaustive\n"
        "    effort: low\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert parsed.solve.running_index_delta == 1
    assert parsed.solve.local_enumeration_stride == 1
    assert parsed.solve.enumeration_exhaust_all is True


def test_load_run_input_solve_strategy_advanced_override(tmp_path):
    path = _write_full_poscar_workflow_yaml(tmp_path / "input.yaml")
    text = path.read_text()
    text = text.replace(
        "solve:\n"
        "  swap: true\n"
        "  max_swap: 2\n",
        "solve:\n"
        "  strategy:\n"
        "    mode: adaptive\n"
        "    time_budget_sec: 600\n"
        "    effort: medium\n"
        "  advanced:\n"
        "    local_enumeration_limit: 12345\n"
        "    local_enumeration_max_chunks: 54321\n",
    )
    path.write_text(text)

    parsed = load_run_input(path)

    assert parsed.solve.running_index_delta == -600
    assert parsed.solve.local_enumeration_limit == 12345
    assert parsed.solve.local_enumeration_max_chunks == 54321


def test_load_poscar_basic_example():
    structure = load_poscar("examples/poscar_structure/POSCAR.vasp")

    assert structure.title == "Mn2 Cr2 O1"
    assert structure.fractional_coordinates is True
    assert len(structure.sites) == 5
    assert [site.kind for site in structure.sites] == ["Mn", "Mn", "Cr", "Cr", "O"]
    assert round(structure.sites[0].x, 6) == 0.874998


def test_load_run_input_poscar_example():
    config = load_run_input("examples/poscar_structure/input.yaml")

    assert config.guide.structure.title == "POSCAR_based_stub"
    assert len(config.guide.structure.sites) == 5
    assert config.guide.structure.sites[2].kind == "Cr"
    assert config.guide.composition.n_target_sites == 112
    assert config.guide.options.fixed_rg_find_factor == 2


def test_workflow_from_yaml_poscar_loads():
    workflow = ESSWorkflow.from_yaml("examples/poscar_structure/input.yaml")
    assert workflow.config.guide.structure.title == "POSCAR_based_stub"
    assert workflow.config.guide.structure.sites[-1].kind == "O"


def test_load_run_input_symmetry_wyc_path():
    config = load_run_input("examples/poscar_structure/input.yaml")
    assert config.guide.symmetry.space_group == 1

    # overlay temp yaml with wyc_path
    tmp = Path("tests/.tmp_symmetry_wyc.yaml")
    try:
        tmp.write_text(
            "structure:\n"
            "  title: POSCAR_based_stub\n"
            "  poscar: ../tests/golden/fixtures/G005_HIGHSYM_ADDED/POSCAR-MnCr2O4.vasp\n"
            "  n_target_sites: 112\n"
            "  number_fixed_at: O\n"
            "composition:\n"
            "  Mn: 14\n"
            "  Cr: 15\n"
            "  Ni: 19\n"
            "  O: 64\n"
            "charges:\n"
            "  Mn: 1.5\n"
            "  Cr: 1.7\n"
            "  Ni: 1.3\n"
            "  O: -1.1\n"
            "recipes:\n"
            "  - from: Mn\n"
            "    to: [Mn, Ni]\n"
            "  - from: Cr\n"
            "    to: [Cr, Ni]\n"
            "symmetry:\n"
            "  space_group: 2\n"
            "  wyc_path: ../tests/golden/fixtures/G005_HIGHSYM_ADDED/2.wyc\n"
        )
        parsed = load_run_input(tmp)
        assert parsed.guide.symmetry.space_group == 2
        assert len(parsed.guide.symmetry.wyc_operations) == 2
    finally:
        if tmp.exists():
            tmp.unlink()


def test_load_run_input_symmetry_auto_detect(monkeypatch):
    fake_symmetry = SymmetryModel(
        space_group=225,
        from_spglib=True,
        wyc_operations=[
            SymmetryOperation(
                matrix=(
                    (1.0, 0.0, 0.0, 0.0),
                    (0.0, 1.0, 0.0, 0.0),
                    (0.0, 0.0, 1.0, 0.0),
                )
            )
        ],
    )

    class _Detected:
        space_group_number = 225
        international_symbol = "Fm-3m"
        symmetry = fake_symmetry

    monkeypatch.setattr(
        config_mod,
        "detect_symmetry_with_spglib",
        lambda structure, symprec=1e-5: _Detected(),
    )

    tmp = Path("tests/.tmp_symmetry_auto.yaml")
    wyc_out = Path("tests/.tmp_detected.wyc")
    try:
        tmp.write_text(
            "structure:\n"
            "  title: POSCAR_based_stub\n"
            "  poscar: ../examples/poscar_structure/POSCAR.vasp\n"
            "  n_target_sites: 112\n"
            "  number_fixed_at: O\n"
            "composition:\n"
            "  Mn: 14\n"
            "  Cr: 15\n"
            "  Ni: 19\n"
            "  O: 64\n"
            "charges:\n"
            "  Mn: 1.5\n"
            "  Cr: 1.7\n"
            "  Ni: 1.3\n"
            "  O: -1.1\n"
            "recipes:\n"
            "  - from: Mn\n"
            "    to: [Mn, Ni]\n"
            "  - from: Cr\n"
            "    to: [Cr, Ni]\n"
            "symmetry:\n"
            "  mode: auto\n"
            "  symprec: 1e-4\n"
            "  write_wyc_path: .tmp_detected.wyc\n"
        )
        parsed = load_run_input(tmp)
        assert parsed.guide.symmetry.space_group == 225
        assert parsed.guide.symmetry.from_spglib is True
        assert wyc_out.exists()
    finally:
        if tmp.exists():
            tmp.unlink()
        if wyc_out.exists():
            wyc_out.unlink()
