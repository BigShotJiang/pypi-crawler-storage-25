from collections import Counter

from esspy import (
    CompositionEntry,
    GeneralizedChargeEntry,
    GeneralizedElementCharge,
    GeneralizedSiteGroupRule,
    GeneralizedSwapOptions,
    Lattice,
    ReadyAtom,
    ReadyModel,
    ReadyRecipe,
    ReadyRecipeModification,
    compute_generalized_swap_loop,
)


def _ready():
    return ReadyModel(
        lattice=Lattice(a=(6.0, 0.0, 0.0), b=(0.0, 6.0, 0.0), c=(0.0, 0.0, 6.0)),
        atoms=[
            ReadyAtom(kind="A", oxidation=1.0, x=0.0, y=0.0, z=0.0),
            ReadyAtom(kind="A", oxidation=1.0, x=0.5, y=0.0, z=0.0),
            ReadyAtom(kind="B", oxidation=-1.0, x=0.0, y=0.5, z=0.0),
            ReadyAtom(kind="B", oxidation=-1.0, x=0.5, y=0.5, z=0.0),
        ],
        poscar_species_counts=[
            CompositionEntry(kind="A", count=1),
            CompositionEntry(kind="B", count=1),
            CompositionEntry(kind="X", count=1),
            CompositionEntry(kind="Y", count=1),
        ],
        output_prefix="generalized-swap-test",
        rg_find_factor=1,
        recipes=[
            ReadyRecipe(
                from_kind="A",
                oxidation=1.0,
                random_pickup=2,
                random_pickup_trial=1,
                modifications=[
                    ReadyRecipeModification(to="X", oxidation=2.0, count=1)
                ],
            ),
            ReadyRecipe(
                from_kind="B",
                oxidation=-1.0,
                random_pickup=2,
                random_pickup_trial=1,
                modifications=[
                    ReadyRecipeModification(to="Y", oxidation=-2.0, count=1)
                ],
            ),
        ],
    )


def test_generalized_swap_preserves_counts_and_reports_starts():
    result = compute_generalized_swap_loop(
        _ready(),
        GeneralizedSwapOptions(
            number_starts=3,
            max_steps_per_start=8,
            random_shuffle_steps=8,
            rg_find_factor=1,
            chop_level=8.0,
            seed=123,
            site_groups=[
                GeneralizedSiteGroupRule(
                    name="site1",
                    source_kind="A",
                    allowed=["A", "B", "X", "Y"],
                ),
                GeneralizedSiteGroupRule(
                    name="site2",
                    source_kind="B",
                    allowed=["A", "B", "X", "Y"],
                ),
            ],
            element_charges=[
                GeneralizedElementCharge(kind="A", oxidation=1.0),
                GeneralizedElementCharge(kind="B", oxidation=-1.0),
                GeneralizedElementCharge(kind="X", oxidation=2.0),
                GeneralizedElementCharge(kind="Y", oxidation=-2.0),
            ],
            site_charges=[
                GeneralizedChargeEntry(kind="A", site_group="site1", oxidation=1.0),
                GeneralizedChargeEntry(kind="A", site_group="site2", oxidation=1.0),
                GeneralizedChargeEntry(kind="B", site_group="site1", oxidation=-1.0),
                GeneralizedChargeEntry(kind="B", site_group="site2", oxidation=-1.0),
                GeneralizedChargeEntry(kind="X", site_group="site1", oxidation=2.0),
                GeneralizedChargeEntry(kind="X", site_group="site2", oxidation=2.0),
                GeneralizedChargeEntry(kind="Y", site_group="site1", oxidation=-2.0),
                GeneralizedChargeEntry(kind="Y", site_group="site2", oxidation=-2.0),
            ],
        ),
    )

    assert result.starts_evaluated == 3
    assert result.best_energy <= result.initial_energy
    assert Counter(site.kind for site in result.best_structure.sites) == {
        "A": 1,
        "B": 1,
        "X": 1,
        "Y": 1,
    }
    assert len(result.starts) == 3


def test_generalized_swap_start_stride_partitions_global_start_indices():
    result = compute_generalized_swap_loop(
        _ready(),
        GeneralizedSwapOptions(
            number_starts=5,
            start_index_offset=1,
            start_index_stride=2,
            max_steps_per_start=2,
            random_shuffle_steps=4,
            rg_find_factor=1,
            seed=123,
            site_groups=[
                GeneralizedSiteGroupRule(
                    name="site1",
                    source_kind="A",
                    allowed=["A", "B", "X", "Y"],
                ),
                GeneralizedSiteGroupRule(
                    name="site2",
                    source_kind="B",
                    allowed=["A", "B", "X", "Y"],
                ),
            ],
            element_charges=[
                GeneralizedElementCharge(kind="A", oxidation=1.0),
                GeneralizedElementCharge(kind="B", oxidation=-1.0),
                GeneralizedElementCharge(kind="X", oxidation=2.0),
                GeneralizedElementCharge(kind="Y", oxidation=-2.0),
            ],
        ),
    )

    assert [start.start_index for start in result.starts] == [1, 3]
    assert result.starts_evaluated == 2
