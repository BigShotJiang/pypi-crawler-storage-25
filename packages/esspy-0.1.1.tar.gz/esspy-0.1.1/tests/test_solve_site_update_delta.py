import pytest

from esspy import _esspy


def _ready():
    return {
        "lattice": {
            "a": [5.0, 0.0, 0.0],
            "b": [0.0, 5.0, 0.0],
            "c": [0.0, 0.0, 5.0],
        },
        "supercell_expansion": [1, 1, 1],
        "rg_find_factor": 1,
        "output_prefix": "site-update-probe",
        "atoms": [
            {"kind": "A", "oxidation": 1.0, "x": 0.0, "y": 0.0, "z": 0.0},
            {"kind": "B", "oxidation": -1.0, "x": 0.5, "y": 0.5, "z": 0.5},
            {"kind": "C", "oxidation": 2.0, "x": 0.25, "y": 0.25, "z": 0.25},
            {"kind": "D", "oxidation": -2.0, "x": 0.75, "y": 0.25, "z": 0.5},
        ],
        "recipes": [],
    }


def test_site_update_delta_matches_full_recomputation():
    result = _esspy.probe_site_update_delta(
        _ready(),
        [0, 2],
        [1.2, 1.7],
        ["A2", "C2"],
        1,
        8.0,
    )

    assert result["predicted_after_total"] == pytest.approx(result["after_total"], abs=1e-10)
    assert result["committed_total"] == pytest.approx(result["after_total"], abs=1e-10)
    assert result["cache_stats"]["diff_evaluations"] == 1
    assert result["cache_stats"]["real_incremental_updates"] == 1
    assert result["cache_stats"]["point_incremental_updates"] == 1
    assert result["cache_stats"]["recip_incremental_updates"] == 1


def test_site_update_delta_supports_charge_only_update():
    result = _esspy.probe_site_update_delta(
        _ready(),
        [1, 3],
        [-0.8, -2.3],
        [],
        1,
        8.0,
    )

    assert result["predicted_after_total"] == pytest.approx(result["after_total"], abs=1e-10)
    assert result["committed_total"] == pytest.approx(result["after_total"], abs=1e-10)
