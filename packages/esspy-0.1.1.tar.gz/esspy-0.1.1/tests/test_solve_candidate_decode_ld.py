import pytest
from esspy.solve_candidate_decode import decode_candidate_assignment_ld, decode_candidate_assignment
from esspy.models import ReadyRecipe, ReadyRecipeModification

def test_multinomial_huge():
    # Huge multinomial: 100 choose 50
    # Expected log10 ~ 29.0
    recipe = ReadyRecipe(
        from_kind="A",
        oxidation=1.0,
        random_pickup=100,
        random_pickup_trial=1,
        modifications=[
            ReadyRecipeModification(to="B", oxidation=2.0, count=50)
        ]
    )
    
    # We can't use decode_candidate_assignment with index > 2^64
    # But we can use decode_candidate_assignment_ld
    index = 1.23e25
    res = decode_candidate_assignment_ld(recipe, index)
    
    assert len(res["indices"]) == 100
    assert len(res["labels"]) == 100
    
    # Check that it returns something deterministic
    res2 = decode_candidate_assignment_ld(recipe, index)
    assert res["indices"] == res2["indices"]
    
    # Check that a different index gives a different result
    res3 = decode_candidate_assignment_ld(recipe, index + 1.0e15)
    # The change might be small, but it should be different if the index is large enough
    # or just check it doesn't crash
    
def test_compare_u64_ld():
    # For small indices, they should match exactly
    recipe = ReadyRecipe(
        from_kind="A",
        oxidation=1.0,
        random_pickup=10,
        random_pickup_trial=1,
        modifications=[
            ReadyRecipeModification(to="B", oxidation=2.0, count=5)
        ]
    )
    
    for i in range(1, 10):
        res_u64 = decode_candidate_assignment(recipe, i)
        res_ld = decode_candidate_assignment_ld(recipe, float(i))
        assert res_u64["indices"] == res_ld["indices"]

def test_search_space_ld_population():
    from esspy import analyze_search_space, ReadyModel, Lattice, ReadyAtom
    
    lattice = Lattice((10,0,0),(0,10,0),(0,0,10))
    atoms = [ReadyAtom("A", 1.0, 0,0,0)] * 100
    recipe = ReadyRecipe(
        from_kind="A",
        oxidation=1.0,
        random_pickup=100,
        random_pickup_trial=1,
        modifications=[
            ReadyRecipeModification(to="B", oxidation=2.0, count=50)
        ]
    )
    ready = ReadyModel(lattice, atoms, recipes=[recipe])
    
    summary = analyze_search_space(ready)
    entry = summary.entries[0]
    
    # jobsize_u64 will likely overflow or be capped at ULLONG_MAX/wrap around
    # but jobsize_ld should be roughly 10^29
    assert entry.jobsize_ld > 1e28
    assert entry.candidate_count_log10 > 28
    assert entry.jobsize_saturated is True


def test_u64_decoder_falls_back_for_huge_multinomial_counts():
    recipe = ReadyRecipe(
        from_kind="Cr",
        oxidation=3.0,
        random_pickup=64,
        random_pickup_trial=1,
        modifications=[
            ReadyRecipeModification(to="Co", oxidation=2.0, count=13),
            ReadyRecipeModification(to="Mn", oxidation=2.0, count=1),
            ReadyRecipeModification(to="Ni", oxidation=2.0, count=19),
            ReadyRecipeModification(to="Rh", oxidation=3.0, count=3),
        ],
    )

    res = decode_candidate_assignment(recipe, 1)

    assert res["labels"].count("Cr") == 28
    assert res["labels"].count("Co") == 13
    assert res["labels"].count("Mn") == 1
    assert res["labels"].count("Ni") == 19
    assert res["labels"].count("Rh") == 3

    from esspy import analyze_search_space, ReadyModel, Lattice, ReadyAtom

    ready = ReadyModel(
        Lattice((10, 0, 0), (0, 10, 0), (0, 0, 10)),
        [ReadyAtom("Cr", 3.0, 0, 0, 0)] * 64,
        recipes=[recipe],
    )
    summary = analyze_search_space(ready)
    assert summary.entries[0].jobsize_saturated is True
