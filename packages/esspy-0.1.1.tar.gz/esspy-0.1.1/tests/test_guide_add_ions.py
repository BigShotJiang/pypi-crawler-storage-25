import math
from pathlib import Path

import pytest

from esspy import (
    AddIonsOptions,
    Lattice,
    SymmetryOperation,
    compute_add_ions,
    load_poscar,
    parse_wyc_file_to_symmetry_model,
)
from tests.golden.references import G005_HIGHSYM_ADDED_POSCAR, G005_HIGHSYM_ADDED_WYC


WYC_G004 = Path("tests/golden/fixtures/G004_CCS02_P1_ADDED/1.wyc")
POSCAR_G004 = Path("tests/golden/fixtures/G004_CCS02_P1_ADDED/POSCAR-MnCr2O4.vasp") \
    if (Path("tests/golden/fixtures/G004_CCS02_P1_ADDED/POSCAR-MnCr2O4.vasp")).exists() \
    else Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp")
IDENTITY_OP = (
    (1.0, 0.0, 0.0, 0.0),
    (0.0, 1.0, 0.0, 0.0),
    (0.0, 0.0, 1.0, 0.0),
)


def _frac_distance(lattice: Lattice, p, q) -> float:
    """Minimum-image Euclidean distance in cartesian space (no PBC search)."""
    dx = (
        lattice.a[0] * (p[0] - q[0])
        + lattice.b[0] * (p[1] - q[1])
        + lattice.c[0] * (p[2] - q[2])
    )
    dy = (
        lattice.a[1] * (p[0] - q[0])
        + lattice.b[1] * (p[1] - q[1])
        + lattice.c[1] * (p[2] - q[2])
    )
    dz = (
        lattice.a[2] * (p[0] - q[0])
        + lattice.b[2] * (p[1] - q[1])
        + lattice.c[2] * (p[2] - q[2])
    )
    return math.sqrt(dx * dx + dy * dy + dz * dz)


def _existing_fractional_from_poscar(poscar_path: Path) -> tuple[Lattice, list]:
    structure = load_poscar(poscar_path)
    return structure.lattice, [(s.x, s.y, s.z) for s in structure.sites]


def test_compute_add_ions_p1_returns_requested_count():
    lattice, existing = _existing_fractional_from_poscar(POSCAR_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)

    result = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=17,
        options=AddIonsOptions(random_seed=42, n_random_seeds=50),
    )

    assert len(result.added_sites) == 17
    assert len(result.chosen_random_seeds) == 17  # P1: one seed per site


def test_compute_add_ions_keeps_sites_in_unit_cell():
    lattice, existing = _existing_fractional_from_poscar(POSCAR_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)

    result = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=17,
        options=AddIonsOptions(random_seed=7, n_random_seeds=50),
    )

    for site in result.added_sites:
        for component in site.fractional:
            assert 0.0 <= component < 1.0


def test_compute_add_ions_respects_wyc_identity_length_in_p1():
    lattice, existing = _existing_fractional_from_poscar(POSCAR_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)

    options = AddIonsOptions(random_seed=11, n_random_seeds=50, wyc_identity_length=0.2)
    result = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=17,
        options=options,
    )

    # In P1 the identity-length check rejects coincident candidate sites.
    # Verify pairwise distances exceed wyc_identity_length using the no-PBC
    # cartesian distance (the original guard is approximated this way: any
    # genuine sub-Angstrom collision would still violate this looser test).
    fracs = [site.fractional for site in result.added_sites]
    for i in range(len(fracs)):
        for j in range(i + 1, len(fracs)):
            d = _frac_distance(lattice, fracs[i], fracs[j])
            assert d > options.wyc_identity_length


def test_compute_add_ions_is_deterministic_for_same_seed():
    lattice, existing = _existing_fractional_from_poscar(POSCAR_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)
    options = AddIonsOptions(random_seed=2026, n_random_seeds=30)

    a = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=5,
        options=options,
    )
    b = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=5,
        options=options,
    )

    assert [s.fractional for s in a.added_sites] == [
        s.fractional for s in b.added_sites
    ]
    assert a.neighbor_distance_max == b.neighbor_distance_max


def test_compute_add_ions_changes_with_seed():
    lattice, existing = _existing_fractional_from_poscar(POSCAR_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)

    a = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=5,
        options=AddIonsOptions(random_seed=1, n_random_seeds=30),
    )
    b = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=5,
        options=AddIonsOptions(random_seed=2, n_random_seeds=30),
    )

    assert [s.fractional for s in a.added_sites] != [
        s.fractional for s in b.added_sites
    ]


def test_compute_add_ions_logs_seed_progress():
    lattice, existing = _existing_fractional_from_poscar(POSCAR_G004)
    symmetry = parse_wyc_file_to_symmetry_model(WYC_G004, space_group=1)

    result = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=5,
        options=AddIonsOptions(random_seed=99, n_random_seeds=30),
    )

    # The original Guider logs only when neighbor_distance_max improves;
    # at minimum the first iteration should always emit a log line.
    assert len(result.log) >= 1
    first = result.log[0]
    assert first.startswith("0/30 ") or first.startswith("0 /30 ")


def test_compute_add_ions_raises_on_empty_wyc():
    lattice, _ = _existing_fractional_from_poscar(POSCAR_G004)
    with pytest.raises(Exception):
        compute_add_ions(
            lattice=lattice,
            existing_fractional=[],
            wyc_operations=[],
            n_to_add=1,
            options=AddIonsOptions(random_seed=0, n_random_seeds=1),
        )


def test_compute_add_ions_short_circuits_when_zero_to_add():
    lattice, existing = _existing_fractional_from_poscar(POSCAR_G004)
    result = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=[SymmetryOperation(matrix=IDENTITY_OP)],
        n_to_add=0,
        options=AddIonsOptions(random_seed=0, n_random_seeds=1),
    )
    assert result.added_sites == []
    assert result.chosen_random_seeds == []


def test_compute_add_ions_supports_multi_operation_orbits_spacegroup_gt1():
    lattice = Lattice(a=(4.0, 0.0, 0.0), b=(0.0, 4.0, 0.0), c=(0.0, 0.0, 4.0))
    wyc_operations = [
        SymmetryOperation(
            matrix=(
                (1.0, 0.0, 0.0, 0.0),
                (0.0, 1.0, 0.0, 0.0),
                (0.0, 0.0, 1.0, 0.0),
            )
        ),
        SymmetryOperation(
            matrix=(
                (1.0, 0.0, 0.0, 0.5),
                (0.0, 1.0, 0.0, 0.5),
                (0.0, 0.0, 1.0, 0.5),
            )
        ),
    ]

    result = compute_add_ions(
        lattice=lattice,
        existing_fractional=[],
        wyc_operations=wyc_operations,
        n_to_add=4,
        options=AddIonsOptions(random_seed=123, n_random_seeds=40, wyc_identity_length=0.01),
    )

    assert len(result.added_sites) == 4
    # Two symmetry operations => one random seed generates one 2-site orbit.
    assert len(result.chosen_random_seeds) == 2

    fracs = [site.fractional for site in result.added_sites]
    for start in (0, 2):
        first = fracs[start]
        second = fracs[start + 1]
        expected = tuple((first[i] + 0.5) % 1.0 for i in range(3))
        assert second == pytest.approx(expected, abs=1e-12)


def test_compute_add_ions_file_backed_highsym_fixture_orbits():
    lattice, existing = _existing_fractional_from_poscar(G005_HIGHSYM_ADDED_POSCAR)
    symmetry = parse_wyc_file_to_symmetry_model(G005_HIGHSYM_ADDED_WYC, space_group=2)

    result = compute_add_ions(
        lattice=lattice,
        existing_fractional=existing,
        wyc_operations=symmetry.wyc_operations,
        n_to_add=4,
        options=AddIonsOptions(random_seed=4321, n_random_seeds=40, wyc_identity_length=0.01),
    )

    assert len(result.added_sites) == 4
    assert len(result.chosen_random_seeds) == 2

    fracs = [site.fractional for site in result.added_sites]
    for start in (0, 2):
        first = fracs[start]
        second = fracs[start + 1]
        expected = tuple((first[i] + 0.5) % 1.0 for i in range(3))
        assert second == pytest.approx(expected, abs=1e-12)
