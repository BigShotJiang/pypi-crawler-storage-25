from pathlib import Path

import pytest

from esspy.native import load_native_module


def _tiny_ready_payload() -> dict:
    """A 1x1x1 cubic cell with one Mn → {Cr, Ni} recipe.

    Identical to the fixture used by test_solve_swap_loop.py so the
    swap-integrated solve() path can be compared against the standalone
    swap loop on the same input.
    """
    return {
        "lattice": {
            "a": (4.0, 0.0, 0.0),
            "b": (0.0, 4.0, 0.0),
            "c": (0.0, 0.0, 4.0),
        },
        "atoms": [
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.5, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.5, "z": 0.0},
            {"kind": "O", "oxidation": -2.0, "x": 0.5, "y": 0.5, "z": 0.5},
        ],
        "supercell_expansion": (1, 1, 1),
        "rg_find_factor": 1,
        "output_prefix": "tiny",
        "recipes": [
            {
                "from": "Mn",
                "oxidation": 2.0,
                "random_pickup": 3,
                "random_pickup_trial": 1,
                "modifications": [
                    {"to": "Cr", "oxidation": 3.0, "count": 1},
                    {"to": "Ni", "oxidation": 1.0, "count": 1},
                ],
            },
        ],
    }


def test_solve_default_options_follow_legacy_swap_enabled_policy():
    """Default solve() follows legacy `Swap=1` policy.

    `swap_loop_enabled` now defaults to `swap`, so a bare solve() call
    can run the post-enumeration swap loop.  Tiny inputs may still have
    zero accepted swaps, but the solver must advertise the integration.
    """
    native = load_native_module()
    result = native.solve({"ready": _tiny_ready_payload(), "options": {}})

    local = result["local_reduction"]
    assert isinstance(local["local_swap_count"], int)
    assert local["local_de_min_swap"] <= 1.0e-12
    assert any("swap_loop_enabled=true" in m for m in result["messages"])


def test_solve_swap_loop_enabled_populates_local_reduction_swap_fields():
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "swap_loop_mode": 1,
                "max_swap": 5,
            },
        }
    )

    local = result["local_reduction"]
    # Swap loop ran; swap_count must be a real integer >= 0 and the
    # de_min_swap accumulator must satisfy the legacy invariant.
    assert isinstance(local["local_swap_count"], int)
    assert local["local_swap_count"] >= 0
    assert local["local_de_min_swap"] <= 1.0e-12

    # Solve() messages should advertise the swap-loop integration.
    messages = result["messages"]
    assert any("swap_loop_enabled=true" in m for m in messages)
    assert any(m.startswith("[SOLVE] de_min_swap=") for m in messages)


def test_solve_swap_loop_max_swap_zero_falls_back_to_pre_swap_pipeline():
    """Even with `swap_loop_enabled=true`, `max_swap <= 0` is a no-op."""
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 0,
            },
        }
    )

    local = result["local_reduction"]
    assert local["local_de_min_swap"] == 0.0
    assert local["local_swap_count"] == 0
    messages = result["messages"]
    assert not any("swap_loop_enabled=true" in m for m in messages)


def test_solve_swap_loop_lowers_best_when_swap_finds_lower_energy():
    """If the swap loop reaches a lower energy than the window best, the
    integrated solve() result must update its best snapshot."""
    native = load_native_module()
    no_swap = native.solve(
        {"ready": _tiny_ready_payload(), "options": {}}
    )
    with_swap = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "swap_loop_mode": 1,
                "max_swap": 5,
            },
        }
    )
    no_swap_best = no_swap["best"]["energy"]
    with_swap_best = with_swap["best"]["energy"]
    # swap-integrated path must never produce a higher best energy than
    # the pre-swap path. Equality is allowed when the canonical state is
    # already at a local minimum or when the swap loop returns no
    # improvement.
    assert with_swap_best <= no_swap_best + 1.0e-12


def test_solve_swap_loop_mode_two_first_improvement_runs_to_completion():
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "swap_loop_mode": 2,
                "max_swap": 10,
            },
        }
    )

    # Mode 2 should still produce a valid local reduction summary with
    # the legacy de_min_swap <= 0 invariant.
    local = result["local_reduction"]
    assert local["local_de_min_swap"] <= 1.0e-12
    messages = result["messages"]
    assert any("mode=2" in m for m in messages)


def test_solve_swap_integrated_local_reduction_round_trips_global_reducer():
    """Phase 19 + 21 round-trip: feed the integrated solve()'s local
    reduction (now with real swap accumulators) back through
    combine_local_reductions and confirm it survives the homomorphism
    boundary.
    """
    from esspy import combine_local_reductions

    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 5,
            },
        }
    )
    local = result["local_reduction"]

    reduced = combine_local_reductions([local])

    if local["has_samples"]:
        # The reducer must propagate the real swap accumulators
        # untouched onto the global summary's best-rank slot.
        assert reduced.global_de_min_swap == pytest.approx(
            local["local_de_min_swap"]
        )
        assert reduced.global_swap_count == local["local_swap_count"]
