from __future__ import annotations

import yaml

from esspy.cli import main


def test_init_poscar_site_aware_replay_command_builds_allocation_yaml(tmp_path):
    poscar = tmp_path / "POSCAR"
    poscar.write_text(
        "\n".join(
            [
                "ToySpinel",
                "1.0",
                "1 0 0",
                "0 1 0",
                "0 0 1",
                "Mn Cr O",
                "1 2 4",
                "Direct",
                "0 0 0",
                "0.25 0.25 0.25",
                "0.75 0.75 0.75",
                "0.1 0.1 0.1",
                "0.2 0.2 0.2",
                "0.3 0.3 0.3",
                "0.4 0.4 0.4",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    out = tmp_path / "input.yaml"

    rc = main(
        [
            "init",
            "-p",
            str(poscar),
            "--out",
            str(out),
            "--n-target-sites",
            "14",
            "--composition",
            "Mn=1,Cr=2,Ni=3,Rh=1,Co=1,Fe=2,O=4",
            "--charges",
            "Mn=2,Cr=3,Ni=2,Rh=3,Co=2,Fe=3,O=-1.75",
            "--charge-basis",
            "element_site",
            "--recipe",
            "Mn:Mn,Cr,Ni,Rh,Co,Fe",
            "--recipe",
            "Cr:Mn,Cr,Ni,Rh,Co,Fe",
            "--recipe",
            "O:O",
            "--site-group",
            "site1:Mn:Mn,Cr,Ni,Rh,Co,Fe",
            "--site-group",
            "site2:Cr:Mn,Cr,Ni,Rh,Co,Fe",
            "--site-group",
            "site3:O:O",
            "--allocation-time-budget-sec",
            "30",
            "--selection-enabled",
            "false",
        ]
    )

    assert rc == 0
    assert not (tmp_path / "input-example.yaml").exists()
    data = yaml.safe_load(out.read_text())
    assert data["composition"] == {
        "Mn": 1,
        "Cr": 2,
        "Ni": 3,
        "Rh": 1,
        "Co": 1,
        "Fe": 2,
        "O": 4,
    }
    assert data["charges"]["basis"] == "element_site"
    assert data["charges"]["elements"]["O"]["by_site"]["site3"] == -1.75
    assert data["site_groups"]["site1"] == {
        "source_kind": "Mn",
        "count": 1,
        "allowed": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
    }
    assert data["site_groups"]["site2"]["count"] == 2
    assert data["allocation"] == {
        "time_budget_sec": 30,
    }
    assert data["output"]["selection"]["enabled"] is False
