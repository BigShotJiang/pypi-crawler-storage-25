from __future__ import annotations

import json
from pathlib import Path

import esspy.cli as cli_mod
from esspy.cli import main
from esspy.models import SymmetryModel, SymmetryOperation


POSCAR = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp")
WYC = Path("tests/golden/fixtures/G005_HIGHSYM_ADDED/2.wyc")


class _Detected:
    space_group_number = 2
    international_symbol = "P-1"
    symmetry = SymmetryModel(
        space_group=2,
        wyc_operations=[
            SymmetryOperation(
                matrix=(
                    (1.0, 0.0, 0.0, 0.0),
                    (0.0, 1.0, 0.0, 0.0),
                    (0.0, 0.0, 1.0, 0.0),
                )
            ),
            SymmetryOperation(
                matrix=(
                    (1.0, 0.0, 0.0, 0.5),
                    (0.0, 1.0, 0.0, 0.5),
                    (0.0, 0.0, 1.0, 0.5),
                )
            ),
        ],
        from_spglib=True,
    )


def _fake_detect(_structure, *, symprec=1e-5):
    return _Detected()


def test_cli_symmetry_detect(monkeypatch, capsys):
    monkeypatch.setattr(cli_mod, "detect_symmetry_with_spglib", _fake_detect, raising=False)

    rc = main(["symmetry", "detect", str(POSCAR)])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["space_group_number"] == 2
    assert payload["international_symbol"] == "P-1"
    assert payload["n_wyc_operations"] == 2
    assert payload["from_spglib"] is True


def test_cli_symmetry_write_wyc(monkeypatch, tmp_path: Path, capsys):
    monkeypatch.setattr(cli_mod, "detect_symmetry_with_spglib", _fake_detect, raising=False)
    out = tmp_path / "2.wyc"

    rc = main(["symmetry", "write-wyc", str(POSCAR), "--out", str(out)])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)
    assert payload["space_group_number"] == 2
    assert out.read_text().startswith("Nwyc 2\n")


def test_cli_symmetry_inspect_wyc(capsys):
    rc = main(["symmetry", "inspect-wyc", str(WYC), "--space-group", "2"])

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["declared_n_wyc"] == 2
    assert payload["n_entries"] == 2
    assert payload["space_group"] == 2
    assert payload["n_wyc_operations"] == 2
