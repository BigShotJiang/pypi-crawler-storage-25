from __future__ import annotations

import pytest

from esspy.native import load_native_module


def _tiny_m5_ready_payload() -> dict:
    return {
        "lattice": {
            "a": (4.1, 0.1, 0.0),
            "b": (0.2, 4.3, 0.1),
            "c": (0.1, 0.3, 4.7),
        },
        "atoms": [
            {"kind": "M", "oxidation": 0.0, "x": 0.03, "y": 0.11, "z": 0.17},
            {"kind": "M", "oxidation": 0.0, "x": 0.27, "y": 0.19, "z": 0.41},
            {"kind": "M", "oxidation": 0.0, "x": 0.52, "y": 0.37, "z": 0.23},
            {"kind": "M", "oxidation": 0.0, "x": 0.71, "y": 0.64, "z": 0.58},
            {"kind": "M", "oxidation": 0.0, "x": 0.88, "y": 0.21, "z": 0.79},
        ],
        "supercell_expansion": (1, 1, 1),
        "rg_find_factor": 1,
        "output_prefix": "tiny_m5",
        "recipes": [
            {
                "from": "M",
                "oxidation": 0.0,
                "random_pickup": 5,
                "random_pickup_trial": 1,
                "modifications": [
                    {"to": "Mn", "oxidation": 1.0, "count": 2},
                    {"to": "Cr", "oxidation": -1.0, "count": 2},
                ],
            }
        ],
    }


def test_tiny_m5_exhaustive_matches_original_ess_reference_energy():
    """Small exhaustive original-ESS parity fixture.

    The reference values come from running the legacy
    `EwaldSolidSolution.x` on the equivalent ready file in
    `scratch/parity_tiny_m5/original/basic_properties_EwaldSolidSolution.txt`.
    This case has only 30 candidates and isolates core enumeration/Ewald
    correctness from production-scale RunningIndexDelta sampling.
    """
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_m5_ready_payload(),
            "options": {
                "running_index_delta": 1,
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 30,
                "local_enumeration_max_chunks": 1,
                "enumeration_exhaust_all": True,
                "swap": True,
                "swap_loop_enabled": True,
                "max_swap": 100,
            },
            "runtime": {"world_size": 1, "rank": 0},
        }
    )

    summary = result["summary"]
    local = result["local_reduction"]
    assert summary["global_count_total"] == 30
    assert summary["global_e_min"] == pytest.approx(-19.109892734216839, abs=1.0e-9)
    assert summary["global_e_max"] == pytest.approx(-10.221200727185300, abs=1.0e-9)
    assert local["local_swap_count"] == 0
    assert local["local_de_min_swap"] == pytest.approx(0.0, abs=1.0e-12)


def test_tiny_m5_legacy_adaptive_incremental_matches_full_exhaustive_energy():
    native = load_native_module()
    ready = _tiny_m5_ready_payload()
    full = native.solve(
        {
            "ready": ready,
            "options": {
                "running_index_delta": 1,
                "local_enumeration_limit": 30,
                "local_enumeration_max_chunks": 1,
                "enumeration_exhaust_all": True,
                "swap": False,
                "swap_loop_enabled": False,
            },
            "runtime": {"world_size": 1, "rank": 0},
        }
    )
    adaptive = native.solve(
        {
            "ready": ready,
            "options": {
                "running_index_delta": -100000,
                "local_enumeration_limit": 1,
                "local_enumeration_max_chunks": 30,
                "swap": False,
                "swap_loop_enabled": False,
            },
            "runtime": {"world_size": 1, "rank": 0},
        }
    )

    assert adaptive["summary"]["global_count_total"] == full["summary"]["global_count_total"]
    assert adaptive["summary"]["global_e_min"] == pytest.approx(
        full["summary"]["global_e_min"], abs=1.0e-9
    )
    assert adaptive["summary"]["global_e_max"] == pytest.approx(
        full["summary"]["global_e_max"], abs=1.0e-9
    )
    assert any(
        "legacy_adaptive_running_index=true" in line
        for line in adaptive["messages"]
    )
    assert any(
        "enumeration_incremental_mEwald=true" in line
        for line in adaptive["messages"]
    )


def test_tiny_m5_adaptive_stride_overrides_are_applied():
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_m5_ready_payload(),
            "options": {
                "running_index_delta": -100000,
                "local_enumeration_limit": 1,
                "local_enumeration_max_chunks": 1,
                "adaptive_stride_override_9": 1,
                "adaptive_stride_override_19": 11,
                "swap": False,
                "swap_loop_enabled": False,
            },
            "runtime": {"world_size": 1, "rank": 0},
        }
    )

    messages = result["messages"]
    assert any(
        "adaptive_running_index_override monitoring=9 local_stride=1 override_stride=1"
        in line
        for line in messages
    )
    assert any(
        "adaptive_running_index_override monitoring=19 local_stride=1 override_stride=11"
        in line
        for line in messages
    )


def test_save_memory_window_evaluation_streams_without_candidate_entries():
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_m5_ready_payload(),
            "options": {
                "running_index_delta": 1,
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 30,
                "local_enumeration_max_chunks": 1,
                "enumeration_exhaust_all": True,
                "enumeration_save_memory": True,
                "swap": False,
                "swap_loop_enabled": False,
            },
            "runtime": {"world_size": 1, "rank": 0},
        }
    )

    assert result["window_evaluation"]["entries"] == []
    assert result["window_evaluation"]["local_count_total"] == 30
    assert result["local_reduction"]["local_energy_table"]["count"] == 30
    assert result["best"]["structure"]["sites"]
    assert result["worst"]["structure"]["sites"]
