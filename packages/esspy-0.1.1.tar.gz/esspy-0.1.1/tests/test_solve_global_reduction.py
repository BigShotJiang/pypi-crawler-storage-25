from pathlib import Path

import pytest

from esspy import (
    GlobalReductionSummary,
    combine_local_reductions,
)
from esspy.models import LocalReductionSummary
from esspy.native import load_native_module
from tests.golden.ready_parser import parse_ready_file
from tests.golden.references import G003_M6O8_READY


def _ready_payload_from_fixture(path: Path) -> dict:
    ready = parse_ready_file(path)
    return {
        "lattice": {
            "a": (5.1772941, -0.00001875, 2.98909804),
            "b": (1.7257584, 4.88119953, 2.98909789),
            "c": (-0.00002168, -0.00001523, 5.97823435),
        },
        "atoms": [
            {
                "kind": atom.kind,
                "oxidation": atom.oxidation,
                "x": atom.x,
                "y": atom.y,
                "z": atom.z,
            }
            for atom in ready.atom_config
        ],
        "supercell_expansion": ready.supercell_expansion,
        "rg_find_factor": ready.rg_find_factor,
        "output_prefix": ready.output_prefix,
        "recipes": [
            {
                "from": recipe.kind,
                "oxidation": recipe.oxidation,
                "random_pickup": recipe.random_pickup,
                "random_pickup_trial": recipe.random_pickup_trial,
                "modifications": [
                    {
                        "to": mod.kind,
                        "oxidation": mod.oxidation,
                        "count": mod.count,
                    }
                    for mod in recipe.modifications
                ],
            }
            for recipe in ready.recipes
        ],
    }


def _make(
    rank: int,
    *,
    has_samples: bool = True,
    local_e_min: float = 0.0,
    local_e_max: float = 0.0,
    local_best: int = 0,
    local_worst: int = 0,
    primary_recipe_index: int = 0,
    processed_chunks: int = 1,
    processed_candidates: int = 1,
    initial_offset: int = 0,
    next_offset: int = 1,
    has_more: bool = False,
    exhaust_all: bool = False,
    world_size: int = 4,
    local_de_min_swap: float = 0.0,
    local_swap_count: int = 0,
) -> LocalReductionSummary:
    return LocalReductionSummary(
        rank=rank,
        world_size=world_size,
        primary_recipe_index=primary_recipe_index,
        processed_chunks=processed_chunks,
        processed_candidates=processed_candidates,
        initial_offset=initial_offset,
        next_offset=next_offset,
        has_more=has_more,
        exhaust_all=exhaust_all,
        has_samples=has_samples,
        local_e_min=local_e_min,
        local_e_max=local_e_max,
        local_best_candidate_index=local_best,
        local_worst_candidate_index=local_worst,
        local_de_min_swap=local_de_min_swap,
        local_swap_count=local_swap_count,
    )


def test_combine_empty_inputs_returns_no_samples():
    result = combine_local_reductions([])

    assert isinstance(result, GlobalReductionSummary)
    assert result.world_size == 0
    assert result.contributing_ranks == 0
    assert result.has_samples is False
    assert result.which_rank_global_e_min == -1
    assert result.which_rank_global_e_max == -1
    assert result.total_processed_candidates == 0
    assert result.any_has_more is False
    assert result.primary_recipe_consistent is True
    assert result.global_de_min_swap == 0.0
    assert result.global_swap_count == 0
    assert result.total_de_min_swap == 0.0
    assert result.total_swap_count == 0


def test_combine_single_rank_is_homomorphic_with_local_summary():
    local = _make(
        rank=2,
        local_e_min=-100.5,
        local_e_max=-90.25,
        local_best=11,
        local_worst=22,
        primary_recipe_index=0,
        processed_chunks=3,
        processed_candidates=12,
        initial_offset=4,
        next_offset=16,
        has_more=True,
        exhaust_all=False,
        world_size=4,
    )

    result = combine_local_reductions([local])

    assert result.world_size == 1
    assert result.contributing_ranks == 1
    assert result.has_samples is True
    assert result.global_e_min == pytest.approx(-100.5)
    assert result.global_e_max == pytest.approx(-90.25)
    assert result.which_rank_global_e_min == 2
    assert result.which_rank_global_e_max == 2
    assert result.global_e_min_candidate_index == 11
    assert result.global_e_max_candidate_index == 22
    assert result.total_processed_candidates == 12
    assert result.total_processed_chunks == 3
    assert result.any_has_more is True
    assert result.primary_recipe_index == 0
    assert result.primary_recipe_consistent is True


def test_combine_picks_global_min_and_max_across_ranks():
    inputs = [
        _make(rank=0, local_e_min=-50.0, local_e_max=-20.0, local_best=1, local_worst=2),
        _make(rank=1, local_e_min=-80.0, local_e_max=-30.0, local_best=3, local_worst=4),
        _make(rank=2, local_e_min=-60.0, local_e_max=-10.0, local_best=5, local_worst=6),
        _make(rank=3, local_e_min=-70.0, local_e_max=-25.0, local_best=7, local_worst=8),
    ]

    result = combine_local_reductions(inputs)

    assert result.world_size == 4
    assert result.contributing_ranks == 4
    assert result.has_samples is True
    assert result.global_e_min == pytest.approx(-80.0)
    assert result.which_rank_global_e_min == 1
    assert result.global_e_min_candidate_index == 3
    assert result.global_e_max == pytest.approx(-10.0)
    assert result.which_rank_global_e_max == 2
    assert result.global_e_max_candidate_index == 6


def test_combine_skips_ranks_without_samples():
    # Two ranks have no samples (e.g. empty local slices); they must not
    # contribute to extrema but should still be counted toward world_size
    # and processed totals.
    inputs = [
        _make(rank=0, has_samples=False, processed_chunks=0, processed_candidates=0),
        _make(rank=1, local_e_min=-15.0, local_e_max=-5.0, local_best=42, local_worst=43),
        _make(rank=2, has_samples=False, processed_chunks=0, processed_candidates=0),
    ]

    result = combine_local_reductions(inputs)

    assert result.world_size == 3
    assert result.contributing_ranks == 1
    assert result.has_samples is True
    assert result.which_rank_global_e_min == 1
    assert result.which_rank_global_e_max == 1
    assert result.global_e_min == pytest.approx(-15.0)
    assert result.global_e_max == pytest.approx(-5.0)


def test_combine_with_no_contributing_ranks_keeps_has_samples_false():
    inputs = [
        _make(rank=0, has_samples=False),
        _make(rank=1, has_samples=False),
    ]

    result = combine_local_reductions(inputs)

    assert result.world_size == 2
    assert result.contributing_ranks == 0
    assert result.has_samples is False
    assert result.which_rank_global_e_min == -1
    assert result.which_rank_global_e_max == -1


def test_combine_tie_break_prefers_lower_rank():
    # The legacy ESS comparison is strict (`<` and `>`), so two ranks
    # holding the same local_e_min must resolve in favour of whichever was
    # encountered first in the input list (the lower rank in ascending
    # order).
    inputs = [
        _make(rank=0, local_e_min=-30.0, local_e_max=-10.0, local_best=100, local_worst=200),
        _make(rank=1, local_e_min=-30.0, local_e_max=-10.0, local_best=300, local_worst=400),
    ]

    result = combine_local_reductions(inputs)

    assert result.which_rank_global_e_min == 0
    assert result.global_e_min_candidate_index == 100
    assert result.which_rank_global_e_max == 0
    assert result.global_e_max_candidate_index == 200


def test_combine_aggregates_processed_totals_and_flags():
    inputs = [
        _make(
            rank=0,
            local_e_min=-1.0,
            local_e_max=-0.5,
            processed_chunks=2,
            processed_candidates=10,
            has_more=True,
            exhaust_all=False,
        ),
        _make(
            rank=1,
            local_e_min=-2.0,
            local_e_max=-0.25,
            processed_chunks=4,
            processed_candidates=18,
            has_more=False,
            exhaust_all=True,
        ),
    ]

    result = combine_local_reductions(inputs)

    assert result.total_processed_chunks == 6
    assert result.total_processed_candidates == 28
    assert result.any_has_more is True
    assert result.any_exhaust_all is True


def test_combine_flags_primary_recipe_inconsistency():
    inputs = [
        _make(rank=0, primary_recipe_index=0, local_e_min=-1.0, local_e_max=-0.5),
        _make(rank=1, primary_recipe_index=1, local_e_min=-2.0, local_e_max=-0.25),
    ]

    result = combine_local_reductions(inputs)

    assert result.primary_recipe_consistent is False
    # The first contributing rank seeds the value.
    assert result.primary_recipe_index == 0


def test_combine_swap_accumulators_track_best_rank():
    # The legacy ESS solver pulls global_de_min_swap and global_swap_count
    # from whichever rank holds the global minimum at postprocess() time.
    # Rank 1 has the lowest energy here, so its swap statistics must
    # become the global ones.
    inputs = [
        _make(
            rank=0,
            local_e_min=-50.0,
            local_e_max=-20.0,
            local_de_min_swap=-1.5,
            local_swap_count=4,
        ),
        _make(
            rank=1,
            local_e_min=-80.0,
            local_e_max=-30.0,
            local_de_min_swap=-3.25,
            local_swap_count=11,
        ),
        _make(
            rank=2,
            local_e_min=-60.0,
            local_e_max=-10.0,
            local_de_min_swap=-2.0,
            local_swap_count=7,
        ),
    ]

    result = combine_local_reductions(inputs)

    assert result.which_rank_global_e_min == 1
    assert result.global_de_min_swap == pytest.approx(-3.25)
    assert result.global_swap_count == 11
    # Total swap effort sums every contributing rank, regardless of who
    # holds the global minimum.
    assert result.total_de_min_swap == pytest.approx(-1.5 + -3.25 + -2.0)
    assert result.total_swap_count == 4 + 11 + 7


def test_combine_swap_accumulators_skip_non_contributors():
    inputs = [
        _make(
            rank=0,
            has_samples=False,
            local_de_min_swap=-9.0,
            local_swap_count=99,
            processed_chunks=0,
            processed_candidates=0,
        ),
        _make(
            rank=1,
            local_e_min=-15.0,
            local_e_max=-5.0,
            local_de_min_swap=-0.75,
            local_swap_count=3,
        ),
    ]

    result = combine_local_reductions(inputs)

    # Non-contributing rank's swap statistics must be ignored entirely
    # (otherwise the totals and the best-rank pick would lie about empty
    # ranks).
    assert result.contributing_ranks == 1
    assert result.global_de_min_swap == pytest.approx(-0.75)
    assert result.global_swap_count == 3
    assert result.total_de_min_swap == pytest.approx(-0.75)
    assert result.total_swap_count == 3


def test_combine_swap_accumulators_homomorphic_on_single_input():
    local = _make(
        rank=2,
        local_e_min=-100.0,
        local_e_max=-90.0,
        local_de_min_swap=-2.5,
        local_swap_count=8,
    )
    result = combine_local_reductions([local])

    assert result.global_de_min_swap == pytest.approx(-2.5)
    assert result.global_swap_count == 8
    assert result.total_de_min_swap == pytest.approx(-2.5)
    assert result.total_swap_count == 8


def _structure_payload(label_kind: str) -> dict:
    """Helper that builds a one-site StructureModel-like dict.

    The structure is a placeholder; only `sites[0].kind` carries the
    label-kind we use to distinguish best/worst snapshots in tests.
    """
    return {
        "title": "rank-best",
        "lattice": {
            "a": (1.0, 0.0, 0.0),
            "b": (0.0, 1.0, 0.0),
            "c": (0.0, 0.0, 1.0),
        },
        "sites": [
            {
                "kind": label_kind,
                "x": 0.0,
                "y": 0.0,
                "z": 0.0,
                "oxidation": 0.0,
            }
        ],
        "fractional_coordinates": True,
    }


def _make_with_structures(rank: int, **kwargs) -> dict:
    """Build a LocalReductionSummary-shaped dict with explicit structure
    snapshots and structure-presence flags. Returns the dict directly so
    tests can drive the native combiner without dataclass round-tripping."""
    base = {
        "rank": rank,
        "world_size": kwargs.pop("world_size", 4),
        "primary_recipe_index": kwargs.pop("primary_recipe_index", 0),
        "processed_chunks": kwargs.pop("processed_chunks", 1),
        "processed_candidates": kwargs.pop("processed_candidates", 1),
        "initial_offset": kwargs.pop("initial_offset", 0),
        "next_offset": kwargs.pop("next_offset", 1),
        "has_more": kwargs.pop("has_more", False),
        "exhaust_all": kwargs.pop("exhaust_all", False),
        "has_samples": kwargs.pop("has_samples", True),
        "local_e_min": kwargs.pop("local_e_min", 0.0),
        "local_e_max": kwargs.pop("local_e_max", 0.0),
        "local_best_candidate_index": kwargs.pop("local_best", 0),
        "local_worst_candidate_index": kwargs.pop("local_worst", 0),
        "local_de_min_swap": kwargs.pop("local_de_min_swap", 0.0),
        "local_swap_count": kwargs.pop("local_swap_count", 0),
    }
    best_kind = kwargs.pop("best_kind", None)
    worst_kind = kwargs.pop("worst_kind", None)
    if best_kind is not None:
        base["local_best_structure"] = _structure_payload(best_kind)
        base["local_best_structure_present"] = True
    if worst_kind is not None:
        base["local_worst_structure"] = _structure_payload(worst_kind)
        base["local_worst_structure_present"] = True
    if kwargs:
        base.update(kwargs)
    return base


def test_combine_global_best_structure_follows_best_rank():
    """Each rank's `local_best_structure` should travel with the global
    minimum: the rank with the lowest energy hands its best structure to
    the reducer's `global_best_structure` field."""
    inputs = [
        _make_with_structures(
            rank=0, local_e_min=-50.0, local_e_max=-20.0,
            best_kind="rank0-best", worst_kind="rank0-worst"
        ),
        _make_with_structures(
            rank=1, local_e_min=-80.0, local_e_max=-30.0,
            best_kind="rank1-best", worst_kind="rank1-worst"
        ),
        _make_with_structures(
            rank=2, local_e_min=-60.0, local_e_max=-10.0,
            best_kind="rank2-best", worst_kind="rank2-worst"
        ),
    ]

    result = combine_local_reductions(inputs)

    assert result.global_best_structure_present is True
    assert result.global_worst_structure_present is True
    # Rank 1 has the global minimum.
    assert result.global_best_structure is not None
    assert result.global_best_structure.sites[0].kind == "rank1-best"
    # Rank 2 has the global maximum.
    assert result.global_worst_structure is not None
    assert result.global_worst_structure.sites[0].kind == "rank2-worst"


def test_combine_global_structure_owners_can_be_different_ranks():
    """Best and worst owners are independent: best follows global_e_min,
    worst follows global_e_max."""
    inputs = [
        _make_with_structures(
            rank=0, local_e_min=-100.0, local_e_max=0.0,
            best_kind="rank0-low", worst_kind="rank0-mid"
        ),
        _make_with_structures(
            rank=1, local_e_min=-50.0, local_e_max=50.0,
            best_kind="rank1-low", worst_kind="rank1-high"
        ),
    ]

    result = combine_local_reductions(inputs)

    assert result.which_rank_global_e_min == 0
    assert result.which_rank_global_e_max == 1
    assert result.global_best_structure.sites[0].kind == "rank0-low"
    assert result.global_worst_structure.sites[0].kind == "rank1-high"


def test_combine_global_structure_presence_false_when_no_samples():
    inputs = [
        _make_with_structures(rank=0, has_samples=False),
        _make_with_structures(rank=1, has_samples=False),
    ]
    result = combine_local_reductions(inputs)

    assert result.has_samples is False
    assert result.global_best_structure_present is False
    assert result.global_worst_structure_present is False
    assert result.global_best_structure is None
    assert result.global_worst_structure is None


def test_combine_global_structure_skips_non_contributing_ranks():
    """A non-contributing rank's structure must never overwrite the
    global structure even if its energy values look extreme."""
    inputs = [
        _make_with_structures(
            rank=0, has_samples=False,
            local_e_min=-1000.0, local_e_max=1000.0,
            best_kind="ghost-best", worst_kind="ghost-worst"
        ),
        _make_with_structures(
            rank=1, local_e_min=-15.0, local_e_max=-5.0,
            best_kind="real-best", worst_kind="real-worst"
        ),
    ]
    result = combine_local_reductions(inputs)

    assert result.contributing_ranks == 1
    assert result.global_best_structure.sites[0].kind == "real-best"
    assert result.global_worst_structure.sites[0].kind == "real-worst"


def test_combine_global_structure_homomorphic_on_single_input():
    inputs = [
        _make_with_structures(
            rank=3, local_e_min=-7.0, local_e_max=4.0,
            best_kind="solo-best", worst_kind="solo-worst"
        )
    ]
    result = combine_local_reductions(inputs)

    assert result.which_rank_global_e_min == 3
    assert result.which_rank_global_e_max == 3
    assert result.global_best_structure.sites[0].kind == "solo-best"
    assert result.global_worst_structure.sites[0].kind == "solo-worst"


def test_combine_homomorphic_against_solve_local_reduction():
    """Round-trip: feed solve()'s own local_reduction back through the
    reducer and confirm extrema and ownership match exactly."""
    native = load_native_module()
    solve_result = native.solve({
        "ready": _ready_payload_from_fixture(Path(G003_M6O8_READY)),
        "options": {
            "local_enumeration_offset": 0,
            "local_enumeration_limit": 4,
            "local_enumeration_max_chunks": 1,
        },
        "runtime": {"world_size": 1, "rank": 0},
    })
    local = solve_result["local_reduction"]
    if not local["has_samples"]:
        pytest.skip("local solve produced no samples")

    reduced = combine_local_reductions([local])

    assert reduced.has_samples is True
    assert reduced.world_size == 1
    assert reduced.contributing_ranks == 1
    assert reduced.global_e_min == pytest.approx(local["local_e_min"])
    assert reduced.global_e_max == pytest.approx(local["local_e_max"])
    assert reduced.which_rank_global_e_min == local["rank"]
    assert reduced.which_rank_global_e_max == local["rank"]
    assert (
        reduced.global_e_min_candidate_index
        == local["local_best_candidate_index"]
    )
    assert (
        reduced.global_e_max_candidate_index
        == local["local_worst_candidate_index"]
    )
    # Phase 19: solve() does not yet populate swap accumulators, so they
    # round-trip as 0 / 0. The reducer must pass them through unchanged.
    assert reduced.global_de_min_swap == pytest.approx(local["local_de_min_swap"])
    assert reduced.global_swap_count == local["local_swap_count"]
