from __future__ import annotations

from types import SimpleNamespace

from esspy.models import Lattice, Site, StructureModel
from esspy.poscar import write_structure_to_poscar
import pytest

from esspy.run_outputs import (
    _assert_structure_counts_match_expected,
    _normalize_snapshot_structure,
)


def _mock_guide_result():
    # Source order: M, O
    # Target recipe: M -> Mn, Cr, Ni
    return SimpleNamespace(
        ready=SimpleNamespace(
            poscar_species_counts=[
                SimpleNamespace(kind="M", count=6),
                SimpleNamespace(kind="O", count=8),
            ],
            recipes=[
                SimpleNamespace(
                    from_kind="M",
                    modifications=[
                        SimpleNamespace(to="Mn", count=1),
                        SimpleNamespace(to="Cr", count=2),
                        SimpleNamespace(to="Ni", count=3),
                    ],
                ),
                SimpleNamespace(
                    from_kind="O",
                    modifications=[],
                ),
            ],
        )
    )


def test_normalize_snapshot_structure_relabels_to_expected_counts_and_order():
    guide_result = _mock_guide_result()
    structure = StructureModel(
        title="x",
        lattice=Lattice(a=(1, 0, 0), b=(0, 1, 0), c=(0, 0, 1)),
        sites=(
            [Site(kind="M", x=0, y=0, z=0, oxidation=0.0) for _ in range(6)]
            + [Site(kind="O", x=0, y=0, z=0, oxidation=0.0) for _ in range(8)]
        ),
        fractional_coordinates=True,
    )

    normalized, order = _normalize_snapshot_structure(structure, guide_result)
    text = write_structure_to_poscar(normalized, species_order=order)
    lines = text.splitlines()
    assert lines[5].split() == ["Mn", "Cr", "Ni", "O"]
    assert lines[6].split() == ["1", "2", "3", "8"]


def test_write_structure_to_poscar_preserves_site_labels_after_species_grouping():
    structure = StructureModel(
        title="x",
        lattice=Lattice(a=(1, 0, 0), b=(0, 1, 0), c=(0, 0, 1)),
        sites=[
            Site(kind="Ni", x=0.1, y=0, z=0, oxidation=0.0),
            Site(kind="Mn", x=0.2, y=0, z=0, oxidation=0.0),
            Site(kind="Ni", x=0.3, y=0, z=0, oxidation=0.0),
        ],
        fractional_coordinates=True,
    )

    text = write_structure_to_poscar(
        structure,
        species_order=["Mn", "Ni"],
        site_labels=["site-002", "site-001", "site-003"],
    )

    coordinate_lines = text.splitlines()[8:]
    assert coordinate_lines[0].endswith("# site-001")
    assert coordinate_lines[1].endswith("# site-002")
    assert coordinate_lines[2].endswith("# site-003")


def test_final_output_invariant_rejects_species_count_mismatch():
    guide_result = _mock_guide_result()
    structure = StructureModel(
        title="bad",
        lattice=Lattice(a=(1, 0, 0), b=(0, 1, 0), c=(0, 0, 1)),
        sites=(
            [Site(kind="Cr", x=0, y=0, z=0, oxidation=0.0) for _ in range(6)]
            + [Site(kind="O", x=0, y=0, z=0, oxidation=0.0) for _ in range(8)]
        ),
        fractional_coordinates=True,
    )

    with pytest.raises(RuntimeError, match="species-count invariant failed"):
        _assert_structure_counts_match_expected(
            structure,
            guide_result,
            label="test POSCAR",
        )
