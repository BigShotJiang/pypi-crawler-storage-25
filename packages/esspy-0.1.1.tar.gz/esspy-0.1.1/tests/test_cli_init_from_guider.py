"""Phase 78 — `esspy init from-guider` regression coverage."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from esspy.cli import main as cli_main
from esspy.init_from_guider import (
    InitFromGuiderOptions,
    build_init_from_guider_yaml,
    write_init_from_guider_yaml,
)


GUIDER_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
)
GUIDER_G002 = Path(
    "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt"
)


def test_build_yaml_payload_for_g001_has_expected_top_level_keys(tmp_path: Path):
    out = tmp_path / "input.yaml"
    options = InitFromGuiderOptions(guider_path=GUIDER_G001, out=out)
    payload = build_init_from_guider_yaml(options)

    assert payload["name"] == "CCS02_allocation"
    assert payload["structure"]["n_target_sites"] == 112
    assert payload["structure"]["number_fixed_at"] == "O"
    assert payload["composition"]["fractions"]["Mn"] == pytest.approx(0.125)
    assert payload["composition"]["fractions"]["O"] == pytest.approx(0.5714285714)
    assert payload["charges"]["O"] == pytest.approx(-1.1169756250)
    assert payload["recipes"] == [
        {"from": "Mn", "to": ["Mn", "Ni"]},
        {"from": "Cr", "to": ["Cr", "Ni"]},
    ]
    # Legacy guider txt declared SpaceGroup=1 → modern symmetry block
    # records the explicit P1 case.
    assert payload["symmetry"] == {"mode": "p1", "space_group": 1}
    # Guide options must reflect the legacy values exactly.
    assert payload["guide"]["target_cpu_time_sec"] == 600
    assert payload["guide"]["n_random_seeds"] == 2000
    assert payload["guide"]["chop_level"] == 100
    assert payload["guide"]["strict_no_added_sites"] is True
    assert payload["guide"]["skip_ewald_evaluation"] is True
    # Output block carries the migrated default workdir / prefix.
    assert payload["output"]["prefix"] == "CCS02_allocation"
    assert payload["output"]["workdir"] == "run-CCS02_allocation"
    # Migration provenance: the yaml records where it came from.
    assert "guider_text" in payload["legacy_source"]


def test_build_yaml_payload_supports_counts_mode(tmp_path: Path):
    out = tmp_path / "input.yaml"
    options = InitFromGuiderOptions(
        guider_path=GUIDER_G001, out=out, composition_mode="counts"
    )
    payload = build_init_from_guider_yaml(options)
    counts = payload["composition"]["counts"]
    # 0.125 * 112 = 14.0 -> 14
    assert counts["Mn"] == 14
    # 0.5714285714 * 112 = 63.999... -> 64
    assert counts["O"] == 64
    assert sum(counts.values()) == 112


def test_g002_high_recipe_count_round_trips_via_payload(tmp_path: Path):
    out = tmp_path / "input.yaml"
    options = InitFromGuiderOptions(guider_path=GUIDER_G002, out=out)
    payload = build_init_from_guider_yaml(options)
    assert payload["name"] == "CCS03_formalcharge"
    assert payload["recipes"][0]["from"] == "M"
    assert payload["recipes"][0]["to"] == ["Mn", "Cr", "Ni", "Rh"]
    assert payload["composition"]["fractions"]["Rh"] == pytest.approx(0.0803571429)


def test_write_yaml_produces_loadable_file(tmp_path: Path):
    out = tmp_path / "input.yaml"
    options = InitFromGuiderOptions(guider_path=GUIDER_G001, out=out)
    written = write_init_from_guider_yaml(options)
    assert written == out
    assert out.exists()
    payload = yaml.safe_load(out.read_text())
    assert payload["name"] == "CCS02_allocation"
    assert payload["legacy_source"]["guider_text"].endswith(
        "basic_properties_EwaldSolidSolutionGuider.txt"
    )


def test_missing_companion_poscar_raises_useful_error(tmp_path: Path):
    """If the guider text references a POSCAR that does not exist next to
    it, the conversion must surface that fact loudly rather than silently
    emit an unusable yaml.
    """
    rogue = tmp_path / "rogue.guider.txt"
    rogue.write_text(GUIDER_G001.read_text().replace(
        "POSCAR-MnCr2O4.vasp", "MISSING_POSCAR.vasp"
    ))
    options = InitFromGuiderOptions(guider_path=rogue, out=tmp_path / "input.yaml")
    with pytest.raises(FileNotFoundError):
        build_init_from_guider_yaml(options)


def test_explicit_poscar_override_resolves_lookup(tmp_path: Path):
    """`--poscar` lets callers override where the companion POSCAR is
    found, e.g. when migrating a guider text that has been moved away
    from its source directory.
    """
    rogue = tmp_path / "rogue.guider.txt"
    rogue.write_text(GUIDER_G001.read_text().replace(
        "POSCAR-MnCr2O4.vasp", "DOES_NOT_MATTER.vasp"
    ))
    real_poscar = GUIDER_G001.parent / "POSCAR-MnCr2O4.vasp"
    options = InitFromGuiderOptions(
        guider_path=rogue,
        out=tmp_path / "input.yaml",
        poscar_override=real_poscar,
    )
    payload = build_init_from_guider_yaml(options)
    # The yaml's poscar reference must point to the override path.
    assert payload["structure"]["poscar"].endswith("POSCAR-MnCr2O4.vasp")


def test_cli_init_from_guider_runs_end_to_end(tmp_path: Path, capsys):
    """Drive the actual CLI handler through `esspy init from-guider`."""
    out = tmp_path / "input.yaml"
    rc = cli_main(
        [
            "--json",
            "init",
            "from-guider",
            str(GUIDER_G001),
            "--out",
            str(out),
        ]
    )
    assert rc == 0
    captured = capsys.readouterr()
    payload = json.loads(captured.out.strip().splitlines()[-1])
    assert payload["out"] == str(out)
    assert out.exists()
    yaml_payload = yaml.safe_load(out.read_text())
    assert yaml_payload["name"] == "CCS02_allocation"


def test_cli_init_from_guider_supports_counts_mode_flag(tmp_path: Path, capsys):
    out = tmp_path / "input.yaml"
    rc = cli_main(
        [
            "init",
            "from-guider",
            str(GUIDER_G001),
            "--out",
            str(out),
            "--composition-mode",
            "counts",
        ]
    )
    assert rc == 0
    yaml_payload = yaml.safe_load(out.read_text())
    assert "counts" in yaml_payload["composition"]
    assert sum(yaml_payload["composition"]["counts"].values()) == 112


def test_round_trip_through_export_guider_preserves_legacy_intent(tmp_path: Path):
    """The migration is faithful when re-exporting the migrated YAML
    back through `guide export-guider` reproduces the legacy
    semantics: same target fractions, same number_fixed_at, same
    charges, same recipe block.

    Exact byte equality with the original guider text is a stronger
    invariant we may aim at later, but this phase asserts at least
    semantic equality.
    """
    from esspy.guide_guider_writer import write_guider_text_from_yaml
    from esspy.guider_text import parse_guider_text

    out = tmp_path / "input.yaml"
    options = InitFromGuiderOptions(guider_path=GUIDER_G001, out=out)
    write_init_from_guider_yaml(options)

    exported = write_guider_text_from_yaml(out)
    re_exported_path = tmp_path / "re-exported.txt"
    re_exported_path.write_text(exported)

    original_spec = parse_guider_text(GUIDER_G001)
    exported_spec = parse_guider_text(re_exported_path)

    assert exported_spec.target_fractions == pytest.approx(
        original_spec.target_fractions
    )
    assert exported_spec.number_fixed_at == original_spec.number_fixed_at
    assert exported_spec.n_target_sites == original_spec.n_target_sites
    assert exported_spec.charges == pytest.approx(original_spec.charges)
    assert exported_spec.space_group == original_spec.space_group
    assert [(r.from_kind, list(r.to)) for r in exported_spec.recipes] == [
        (r.from_kind, list(r.to)) for r in original_spec.recipes
    ]
    assert (
        exported_spec.options.target_cpu_time_sec
        == original_spec.options.target_cpu_time_sec
    )
    assert (
        exported_spec.options.strict_no_added_sites
        == original_spec.options.strict_no_added_sites
    )
