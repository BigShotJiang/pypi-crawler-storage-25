"""Phase 81 \u2014 `esspy util` command family regression coverage."""
from __future__ import annotations

import json
from pathlib import Path

from esspy.cli import main as cli_main

ROOT = Path(__file__).resolve().parents[1]
POSCAR_TARGET = ROOT / "examples" / "site_grouping_wyckoff" / "POSCAR-target"


def _run_cli(argv: list[str], capsys) -> str:
    rc = cli_main(argv)
    assert rc == 0
    captured = capsys.readouterr()
    return captured.out


def _write_test_poscar(path: Path) -> None:
    path.write_text(
        "\n".join(
            [
                "NaCl test",
                "1.0",
                "5.640000 0.000000 0.000000",
                "0.000000 5.640000 0.000000",
                "0.000000 0.000000 5.640000",
                "Na Cl",
                "1 1",
                "Direct",
                "0.000000 0.000000 0.000000",
                "0.500000 0.500000 0.500000",
            ]
        )
        + "\n"
    )


def _write_site_labeled_poscar(path: Path, title: str = "site labeled NaCl") -> None:
    path.write_text(
        "\n".join(
            [
                title,
                "1.0",
                "5.640000 0.000000 0.000000",
                "0.000000 5.640000 0.000000",
                "0.000000 0.000000 5.640000",
                "Na Cl",
                "2 1",
                "Direct",
                "0.000000 0.000000 0.000000  # site-001",
                "0.500000 0.500000 0.000000  # site-002",
                "0.500000 0.500000 0.500000  # site-003",
            ]
        )
        + "\n"
    )

def test_cli_util_schema(capsys):
    output = _run_cli(["util", "schema"], capsys)
    schema = json.loads(output)
    assert "structure" in schema
    assert "composition" in schema
    assert "recipes" in schema
    assert "guide" in schema
    assert "solve" in schema
    assert "strategy" in schema["solve"]

def test_cli_util_defaults(capsys):
    output = _run_cli(["util", "defaults"], capsys)
    defaults = json.loads(output)
    assert "guide" in defaults
    assert "solve" in defaults
    assert "n_random_seeds" in defaults["guide"]
    assert "max_swap" in defaults["solve"]
    assert defaults["solve"]["strategy"]["mode"] == "adaptive"

def test_cli_util_doctor_native(capsys):
    output = _run_cli(["util", "doctor-native"], capsys)
    info = json.loads(output)
    assert info["status"] == "ok"
    assert "module_name" in info
    assert "file" in info

def test_cli_util_show_example(capsys):
    output = _run_cli(["util", "show-example"], capsys)
    assert "name: example_run" in output
    assert "structure:" in output
    assert "composition:" in output
    assert "recipes:" in output


def test_cli_util_supercell_json(tmp_path: Path, capsys):
    poscar = tmp_path / "POSCAR"
    _write_test_poscar(poscar)
    output = _run_cli(
        [
            "util",
            "supercell",
            str(poscar),
            "--n-target-sites",
            "16",
            "--json",
        ],
        capsys,
    )
    payload = json.loads(output)
    assert payload["status"] == "ok"
    assert payload["selected"]["dim"] == [2, 2, 2]
    assert payload["selected"]["n_atoms"] == 16
    assert payload["candidates"]


def test_cli_util_supercell_human_output(tmp_path: Path, monkeypatch, capsys):
    poscar = tmp_path / "POSCAR"
    _write_test_poscar(poscar)
    monkeypatch.chdir(tmp_path)
    output = _run_cli(
        [
            "util",
            "supercell",
            str(poscar),
            "--n-target-sites",
            "20",
            "--mode",
            "axis_balanced",
        ],
        capsys,
    )
    assert "Supercell search" in output
    assert "Selected" in output
    assert "Cell metrics:" in output
    assert "alpha=" in output
    assert "--dim" in output
    assert "structure.dim" in output
    assert "wrote POSCAR" in output
    assert (tmp_path / "SPOSCAR").exists()


def test_cli_util_supercell_writes_selected_poscar(tmp_path: Path, capsys):
    poscar = tmp_path / "POSCAR"
    out = tmp_path / "POSCAR_supercell.vasp"
    _write_test_poscar(poscar)
    output = _run_cli(
        [
            "util",
            "supercell",
            str(poscar),
            "--n-target-sites",
            "16",
            "--out",
            str(out),
        ],
        capsys,
    )
    assert "wrote POSCAR" in output
    text = out.read_text()
    assert "Na  Cl" in text
    assert "8  8" in text


def test_cli_util_site_groups_element_wyckoff(capsys):
    output = _run_cli(
        [
            "util",
            "site-groups",
            str(POSCAR_TARGET),
            "--mode",
            "element_wyckoff",
            "--symprec",
            "0.1",
            "--map",
            "Cr:Mn,Cr,Ni,Rh,Co,Fe",
            "--map",
            "O:O",
        ],
        capsys,
    )

    assert "Site grouping" in output
    assert "space group  : Fd-3m (227)" in output
    assert "site1   Cr@a" in output
    assert "source=Cr" in output
    assert "count=8" in output
    assert "indices=0..7" in output
    assert "site2   Cr@d" in output
    assert "count=16" in output
    assert "indices=8..23" in output
    assert "site3   O@e" in output


def test_cli_util_site_groups_json(capsys):
    output = _run_cli(
        [
            "util",
            "site-groups",
            str(POSCAR_TARGET),
            "--mode",
            "element_wyckoff",
            "--symprec",
            "0.1",
            "--json",
        ],
        capsys,
    )
    payload = json.loads(output)

    assert payload["status"] == "ok"
    assert payload["site_grouping"]["mode"] == "element_wyckoff"
    assert payload["site_grouping"]["space_group"] == 227
    assert payload["site_groups"]["site1"]["source_kind"] == "Cr"
    assert payload["site_groups"]["site1"]["label"]["display"] == "Cr@a"
    assert payload["site_groups"]["site1"]["site_indices"] == list(range(0, 8))
    assert payload["site_groups"]["site2"]["source_kind"] == "Cr"
    assert payload["site_groups"]["site2"]["label"]["display"] == "Cr@d"
    assert payload["site_groups"]["site2"]["site_indices"] == list(range(8, 24))
    assert payload["site_groups"]["site3"]["label"]["display"] == "O@e"


def test_cli_util_site_groups_poscar_kind_json(capsys):
    output = _run_cli(
        [
            "util",
            "site-groups",
            str(POSCAR_TARGET),
            "--mode",
            "poscar_kind",
            "--json",
        ],
        capsys,
    )
    payload = json.loads(output)

    assert payload["site_grouping"]["mode"] == "poscar_kind"
    assert list(payload["site_groups"]) == ["site1", "site2"]
    assert payload["site_groups"]["site1"]["source_kind"] == "Cr"
    assert payload["site_groups"]["site1"]["site_indices"] == list(range(0, 24))
    assert payload["site_groups"]["site2"]["source_kind"] == "O"
    assert payload["site_groups"]["site2"]["site_indices"] == list(range(24, 56))


def test_util_help_when_no_subcommand(capsys):
    rc = cli_main(["util"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "usage: esspy util" in captured.out
    for name in ("schema", "defaults", "doctor-native", "show-example", "site-groups", "supercell", "ewald"):
        assert name in captured.out


def test_cli_util_ewald_single_poscar(tmp_path: Path, capsys):
    poscar = tmp_path / "POSCAR"
    _write_test_poscar(poscar)
    output = _run_cli(["util", "ewald", "-p", str(poscar)], capsys)
    assert "POSCAR" in output
    assert "E=" in output
    assert "RG=" in output


def test_cli_util_ewald_multiple_and_glob(tmp_path: Path, capsys):
    poscar_a = tmp_path / "POSCAR-001"
    poscar_b = tmp_path / "POSCAR-002"
    _write_test_poscar(poscar_a)
    _write_test_poscar(poscar_b)

    output = _run_cli(["util", "ewald", "-p", str(tmp_path / "POSCAR-*")], capsys)
    assert "POSCAR-001" in output
    assert "POSCAR-002" in output
    assert output.count("E=") >= 2


def test_cli_util_ewald_json(tmp_path: Path, capsys):
    poscar = tmp_path / "POSCAR"
    _write_test_poscar(poscar)
    output = _run_cli(
        [
            "util",
            "ewald",
            "-p",
            str(poscar),
            "--json",
            "--charge",
            "Na=1",
            "--charge",
            "Cl=-1",
        ],
        capsys,
    )
    payload = json.loads(output)
    assert payload["status"] == "ok"
    assert len(payload["results"]) == 1
    assert payload["results"][0]["file"].endswith("POSCAR")


def test_cli_ewald_top_level_alias(tmp_path: Path, capsys):
    poscar = tmp_path / "POSCAR"
    _write_test_poscar(poscar)
    output = _run_cli(["ewald", "-p", str(poscar)], capsys)
    assert "POSCAR" in output
    assert "E=" in output


def test_cli_ewald_uses_site_aware_title_charges(tmp_path: Path, capsys):
    poscar = tmp_path / "POSCAR"
    _write_site_labeled_poscar(
        poscar,
        title=(
            "sample | charges: Na@site-001=1.1 Na@site-002=1.2 "
            "Cl@site-003=-1.3 | RG=3"
        ),
    )

    output = _run_cli(["ewald", "-p", str(poscar), "--json"], capsys)
    payload = json.loads(output)
    row = payload["results"][0]
    assert row["charge_basis"] == "element_site"
    assert row["charge_source"] == "metadata"
    assert row["charges_used"]["Na@site-001"] == 1.1
    assert row["charges_used"]["Na@site-002"] == 1.2
    assert row["charges_used"]["Cl@site-003"] == -1.3


def test_cli_ewald_uses_charge_model(tmp_path: Path, capsys):
    poscar = tmp_path / "POSCAR"
    _write_site_labeled_poscar(poscar)
    charge_model = tmp_path / "charge_model.json"
    charge_model.write_text(
        json.dumps(
            {
                "model_type": "effective_element_charge",
                "schema_version": 2,
                "charges": {
                    "basis": "element_site",
                    "elements": {
                        "Na": {
                            "by_site": {
                                "site-001": 1.11,
                                "site-002": 1.22,
                            }
                        },
                        "Cl": {"by_site": {"site-003": -1.33}},
                    },
                },
            }
        )
    )

    output = _run_cli(
        ["ewald", "-p", str(poscar), "--charge-model", str(charge_model), "--json"],
        capsys,
    )
    payload = json.loads(output)
    row = payload["results"][0]
    assert row["charge_basis"] == "element_site"
    assert row["charge_source"] == "charge_model"
    assert row["charges_used"]["Na@site-001"] == 1.11
    assert row["charges_used"]["Na@site-002"] == 1.22
    assert row["charges_used"]["Cl@site-003"] == -1.33

    output = _run_cli(
        [
            "ewald",
            "-p",
            str(poscar),
            "--charge-model",
            str(charge_model),
            "--charge",
            "Na=1.5",
            "--json",
        ],
        capsys,
    )
    payload = json.loads(output)
    row = payload["results"][0]
    assert row["charge_source"] == "charge_model+cli"
    assert row["charges_used"]["Na@site-001"] == 1.5
    assert row["charges_used"]["Na@site-002"] == 1.5
    assert row["charges_used"]["Cl@site-003"] == -1.33
