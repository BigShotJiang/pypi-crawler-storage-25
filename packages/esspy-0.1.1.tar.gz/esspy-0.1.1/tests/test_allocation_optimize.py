from esspy.allocation_optimize import _load_composition_counts


def test_load_composition_counts_accepts_normalized_fraction_ratios():
    payload = {
        "structure": {"n_target_sites": 112, "number_fixed_at": "O"},
        "composition": {
            "fractions": {
                "Mn": 6.25,
                "Cr": 13.39285714,
                "Ni": 8.03571429,
                "Rh": 4.46428571,
                "Co": 6.25,
                "Fe": 4.46428571,
                "O": 57.14285714,
            }
        },
    }

    assert _load_composition_counts(payload) == {
        "Mn": 7,
        "Cr": 15,
        "Ni": 9,
        "Rh": 5,
        "Co": 7,
        "Fe": 5,
        "O": 64,
    }


def test_load_composition_counts_derives_target_from_dim_and_site_groups():
    payload = {
        "structure": {"dim": [4, 4, 4]},
        "composition": {
            "fractions": {
                "Mo": 0.125,
                "Mg": 0.375,
                "N": 0.5,
            }
        },
        "site_groups": {
            "site1": {
                "source_kind": "M",
                "count": 4,
                "allowed": ["Mo", "Mg"],
            },
            "site2": {
                "source_kind": "N",
                "count": 4,
                "allowed": ["N"],
            },
        },
    }

    assert _load_composition_counts(payload) == {
        "Mo": 64,
        "Mg": 192,
        "N": 256,
    }
