from pathlib import Path

import pytest

from esspy import (
    ChargeEntry,
    ChargeMap,
    CompositionEntry,
    PrimitiveCellIon,
    RecipeSpec,
    compute_recipe_allocation,
    parse_guider_text,
    parse_guider_text_to_guide_input_native,
)
from esspy.native import load_native_module
from esspy.poscar import load_poscar


GUIDER_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
)
GUIDER_G002 = Path(
    "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt"
)


def _primitive_cellions_from_poscar(poscar_path: Path, charges: ChargeMap):
    structure = load_poscar(poscar_path)
    cellions: list[PrimitiveCellIon] = []
    for site in structure.sites:
        if cellions and cellions[-1].kind == site.kind:
            cellions[-1].n += 1
            continue
        oxidation = 0.0
        for entry in charges.values:
            if entry.kind == site.kind:
                oxidation = entry.oxidation
                break
        cellions.append(
            PrimitiveCellIon(kind=site.kind, n=1, oxidation=oxidation)
        )
    return structure, cellions


def _spec_to_inputs(guider_path: Path):
    spec = parse_guider_text(guider_path)
    poscar_path = guider_path.parent / spec.poscar_filename
    charges = ChargeMap(
        values=[
            ChargeEntry(kind=kind, oxidation=oxidation)
            for kind, oxidation in spec.charges.items()
        ]
    )
    structure, primitive_cellions = _primitive_cellions_from_poscar(
        poscar_path, charges
    )
    target_counts = [
        CompositionEntry(kind=kind, count=int(round(fraction * spec.n_target_sites)))
        for kind, fraction in spec.target_fractions.items()
    ]
    return spec, structure, primitive_cellions, target_counts, charges


def test_compute_recipe_allocation_g001_strict():
    spec, structure, primitive_cellions, target_counts, charges = _spec_to_inputs(
        GUIDER_G001
    )
    supercell_exp = 2 * 2 * 2  # G001 expansion is (2, 2, 2)

    result = compute_recipe_allocation(
        primitive_cellions=primitive_cellions,
        target_counts=target_counts,
        supercell_exp=supercell_exp,
        strict_no_added_sites=spec.options.strict_no_added_sites,
        recipes=spec.recipes,
        charges=charges,
    )

    # Cellions are POSCAR-ordered (Mn, Cr, O), then any missing target
    # species (Ni) appended with n_primitive = 0.
    cellion_kinds = [c.kind for c in result.cellions]
    assert cellion_kinds == ["Mn", "Cr", "O", "Ni"]
    assert result.cellions[3].n_primitive == 0
    assert result.cellions[3].skipped_in_other_recipe is True
    assert result.need_wyc is False

    # Two final recipes survive (Ni was skipped via continue;
    # O has no recipe and no modifications, but in strict mode it still
    # produces a FinalRecipe entry with random_pickup = 8 * 8 = 64
    # to keep accounting symmetric with the cellion list).
    final = {fr.from_kind: fr for fr in result.final_recipes}
    assert set(final.keys()) == {"Mn", "Cr", "O"}

    mn = final["Mn"]
    assert mn.random_pickup == 16  # 8 * 2
    assert mn.random_pickup_trial == 1
    assert mn.vac == 0
    assert [(m.to, m.number) for m in mn.modifications] == [("Ni", 2)]

    cr = final["Cr"]
    assert cr.random_pickup == 32  # 8 * 4
    assert cr.vac == 0
    assert [(m.to, m.number) for m in cr.modifications] == [("Ni", 17)]

    o_recipe = final["O"]
    assert o_recipe.random_pickup == 64  # 8 * 8
    assert o_recipe.modifications == []
    assert o_recipe.vac == 0


def test_compute_recipe_allocation_g002_non_strict():
    spec, structure, primitive_cellions, target_counts, charges = _spec_to_inputs(
        GUIDER_G002
    )
    supercell_exp = 1  # G002 expansion is (1, 1, 1)

    result = compute_recipe_allocation(
        primitive_cellions=primitive_cellions,
        target_counts=target_counts,
        supercell_exp=supercell_exp,
        strict_no_added_sites=spec.options.strict_no_added_sites,
        recipes=spec.recipes,
        charges=charges,
    )

    # POSCAR has [M, O], targets add [Mn, Cr, Ni, Rh] at the end.
    cellion_kinds = [c.kind for c in result.cellions]
    assert cellion_kinds == ["M", "O", "Mn", "Cr", "Ni", "Rh"]
    for c in result.cellions[2:]:
        assert c.skipped_in_other_recipe is True
    assert result.need_wyc is False

    final = {fr.from_kind: fr for fr in result.final_recipes}
    assert set(final.keys()) == {"M", "O"}

    m_recipe = final["M"]
    assert m_recipe.random_pickup == 48  # 1 * 48
    assert m_recipe.vac == 0
    assert [(m.to, m.number) for m in m_recipe.modifications] == [
        ("Mn", 12),
        ("Cr", 13),
        ("Ni", 14),
        ("Rh", 9),
    ]
    # M has no entry in IonList, so its oxidation falls back to 0.
    assert m_recipe.oxidation == 0.0

    o_recipe = final["O"]
    assert o_recipe.random_pickup == 64
    assert o_recipe.modifications == []


def test_compute_recipe_allocation_g004_added_sites_path():
    # G004 reuses the G001 POSCAR but disables StrictNoAddedSites, which
    # exercises the DNeed > 0 / vac branch that drives add_ions in the
    # original Guider. We check the typed allocation outputs match the
    # G004 ready file's recipe block (without the post-add cellion count
    # update, which is a separate phase).
    structure = load_poscar(GUIDER_G001.parent / "POSCAR-MnCr2O4.vasp")
    charges = ChargeMap(
        values=[
            ChargeEntry(kind="Mn", oxidation=1.5121650000),
            ChargeEntry(kind="Cr", oxidation=1.7079510000),
            ChargeEntry(kind="Ni", oxidation=1.2998350000),
            ChargeEntry(kind="O", oxidation=-1.1318530000),
        ]
    )
    primitive_cellions = [
        PrimitiveCellIon(kind="Mn", n=2, oxidation=1.5121650000),
        PrimitiveCellIon(kind="Cr", n=4, oxidation=1.7079510000),
        PrimitiveCellIon(kind="O", n=8, oxidation=-1.1318530000),
    ]
    target_counts = [
        CompositionEntry(kind="Mn", count=14),
        CompositionEntry(kind="Cr", count=15),
        CompositionEntry(kind="Ni", count=19),
        CompositionEntry(kind="O", count=64),
    ]
    recipes = [
        RecipeSpec(from_kind="Mn", to=["Mn", "Ni"]),
        RecipeSpec(from_kind="Cr", to=["Cr", "Ni"]),
    ]

    result = compute_recipe_allocation(
        primitive_cellions=primitive_cellions,
        target_counts=target_counts,
        supercell_exp=8,
        strict_no_added_sites=False,
        recipes=recipes,
        charges=charges,
    )

    final = {fr.from_kind: fr for fr in result.final_recipes}
    assert result.need_wyc is True

    mn = final["Mn"]
    assert mn.vac == -17  # delta_need = 33 - 16 = 17
    assert [(m.to, m.number) for m in mn.modifications] == [("Ni", 19)]

    cr = final["Cr"]
    assert cr.vac == -2  # delta_need = 34 - 32 = 2
    assert [(m.to, m.number) for m in cr.modifications] == [("Ni", 19)]

    # Need / DNeed wired correctly on the cellions for the Mn/Cr rows.
    by_kind = {c.kind: c for c in result.cellions}
    assert by_kind["Mn"].need == 33
    assert by_kind["Mn"].delta_need == 17
    assert by_kind["Cr"].need == 34
    assert by_kind["Cr"].delta_need == 2


def test_strict_no_added_sites_reports_under_capacity_failure():
    primitive_cellions = [
        PrimitiveCellIon(kind="Mn", n=2, oxidation=1.5),
        PrimitiveCellIon(kind="Cr", n=4, oxidation=1.7),
        PrimitiveCellIon(kind="O", n=8, oxidation=-1.1),
    ]
    # Targets that demand more atoms than available capacity, so even after
    # self-assignment some remaining_target would survive the strict pass.
    target_counts = [
        CompositionEntry(kind="Mn", count=20),
        CompositionEntry(kind="Cr", count=20),
        CompositionEntry(kind="Ni", count=20),
        CompositionEntry(kind="O", count=64),
    ]
    recipes = [RecipeSpec(from_kind="Mn", to=["Mn", "Ni"])]

    with pytest.raises(Exception):
        compute_recipe_allocation(
            primitive_cellions=primitive_cellions,
            target_counts=target_counts,
            supercell_exp=8,
            strict_no_added_sites=True,
            recipes=recipes,
            charges=ChargeMap(values=[]),
        )


def test_native_guide_now_populates_recipes_for_g001():
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(str(GUIDER_G001))
    result = native.guide(guide_input)

    by_from = {r["from"]: r for r in result["ready"]["recipes"]}
    assert set(by_from.keys()) == {"Mn", "Cr", "O"}

    mn = by_from["Mn"]
    assert mn["random_pickup"] == 16
    assert mn["random_pickup_trial"] == 1
    assert [(m["to"], m["count"]) for m in mn["modifications"]] == [("Ni", 2)]

    cr = by_from["Cr"]
    assert cr["random_pickup"] == 32
    assert [(m["to"], m["count"]) for m in cr["modifications"]] == [("Ni", 17)]


def test_native_guide_now_populates_recipes_for_g002():
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(str(GUIDER_G002))
    result = native.guide(guide_input)

    by_from = {r["from"]: r for r in result["ready"]["recipes"]}
    assert set(by_from.keys()) == {"M", "O"}

    m_recipe = by_from["M"]
    assert m_recipe["random_pickup"] == 48
    assert [(m["to"], m["count"]) for m in m_recipe["modifications"]] == [
        ("Mn", 12),
        ("Cr", 13),
        ("Ni", 14),
        ("Rh", 9),
    ]
