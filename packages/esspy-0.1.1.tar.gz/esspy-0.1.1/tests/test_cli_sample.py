from __future__ import annotations

import json
from pathlib import Path

from esspy.cli import main


def _write_run_yaml(path: Path) -> Path:
    poscar = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()
    path.write_text(
        "name: sample_test\n"
        "structure:\n"
        "  title: sample_test\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 112\n"
        "  number_fixed_at: O\n"
        "composition:\n"
        "  counts:\n"
        "    Mn: 14\n"
        "    Cr: 15\n"
        "    Ni: 19\n"
        "    O: 64\n"
        "charges:\n"
        "  Mn: 1.512165\n"
        "  Cr: 1.707951\n"
        "  Ni: 1.299835\n"
        "  O: -1.116975625\n"
        "recipes:\n"
        "  - from: Mn\n"
        "    to: [Mn, Ni]\n"
        "  - from: Cr\n"
        "    to: [Cr, Ni]\n"
        "symmetry:\n"
        "  space_group: 1\n"
        "guide:\n"
        "  fixed_rg_find_factor: 1\n"
        "  strict_no_added_sites: true\n"
        "  skip_ewald_evaluation: true\n"
        "solve:\n"
        "  swap: true\n"
        "  max_swap: 2\n"
    )
    return path


def test_cli_sample_generates_requested_count(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    outdir = tmp_path / "samples"

    rc = main(
        [
            "--json",
            "sample",
            str(input_path),
            "-n",
            "3",
            "--outdir",
            str(outdir),
            "--prefix",
            "case",
            "--seed",
            "7",
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["count"] == 3
    assert payload["files"] == [
        str(outdir / "case-001.vasp"),
        str(outdir / "case-002.vasp"),
        str(outdir / "case-003.vasp"),
    ]
    for file_path in payload["files"]:
        assert Path(file_path).exists()
    first_sample = (outdir / "case-001.vasp").read_text().splitlines()
    assert first_sample[0] == (
        "case-001 | charges: Cr=1.70795 Mn=1.51216 Ni=1.29984 O=-1.11698 | RG=1"
    )
    assert first_sample[5].split() == ["Mn", "Cr", "Ni", "O"]
    assert first_sample[6].split() == ["14", "15", "19", "64"]


def test_cli_sample_uses_new_suffix_when_outdir_exists(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    requested_outdir = tmp_path / "samples"
    requested_outdir.mkdir()

    rc = main(
        [
            "--json",
            "sample",
            str(input_path),
            "-n",
            "1",
            "--outdir",
            str(requested_outdir),
            "--seed",
            "7",
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    bumped_outdir = tmp_path / "samples-NEW01"
    assert payload["outdir"] == str(bumped_outdir)
    assert payload["files"] == [str(bumped_outdir / "sample-001.vasp")]
    assert (bumped_outdir / "sample-001.vasp").exists()
    assert not (requested_outdir / "sample-001.vasp").exists()


def test_cli_sample_increments_new_suffix(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    requested_outdir = tmp_path / "samples"
    requested_outdir.mkdir()
    (tmp_path / "samples-NEW01").mkdir()

    rc = main(
        [
            "--json",
            "sample",
            str(input_path),
            "-n",
            "1",
            "--outdir",
            str(requested_outdir),
            "--seed",
            "7",
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    bumped_outdir = tmp_path / "samples-NEW02"
    assert payload["outdir"] == str(bumped_outdir)
    assert payload["files"] == [str(bumped_outdir / "sample-001.vasp")]
    assert (bumped_outdir / "sample-001.vasp").exists()


def test_cli_sample_seed_reproducible(tmp_path: Path, capsys):
    input_path = _write_run_yaml(tmp_path / "input.yaml")
    outdir_a = tmp_path / "samples-a"
    outdir_b = tmp_path / "samples-b"

    rc = main(
        [
            "--json",
            "sample",
            str(input_path),
            "-n",
            "2",
            "--outdir",
            str(outdir_a),
            "--prefix",
            "seeded",
            "--seed",
            "123",
        ]
    )
    assert rc == 0
    _ = capsys.readouterr()

    rc = main(
        [
            "--json",
            "sample",
            str(input_path),
            "-n",
            "2",
            "--outdir",
            str(outdir_b),
            "--prefix",
            "seeded",
            "--seed",
            "123",
        ]
    )
    assert rc == 0
    _ = capsys.readouterr()

    for name in ("seeded-001.vasp", "seeded-002.vasp"):
        assert (outdir_a / name).read_text() == (outdir_b / name).read_text()


def test_cli_sample_uses_explicit_site_indices_for_duplicate_source_kind(
    tmp_path: Path,
    capsys,
):
    poscar = Path("examples/site_grouping_wyckoff/POSCAR-target").resolve()
    input_path = tmp_path / "input.yaml"
    input_path.write_text(
        "structure:\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 56\n"
        "composition:\n"
        "  Cr: 20\n"
        "  Mn: 4\n"
        "  O: 32\n"
        "charges:\n"
        "  Cr: 3.0\n"
        "  Mn: 2.0\n"
        "  O: -2.0\n"
        "recipes:\n"
        "  - from_kind: Cr\n"
        "    to: [Cr, Mn]\n"
        "  - from_kind: O\n"
        "    to: [O]\n"
        "allocation:\n"
        "  mode: manual\n"
        "site_groups:\n"
        "  site1:\n"
        "    source_kind: Cr\n"
        "    count: 8\n"
        "    site_indices: [0, 1, 2, 3, 4, 5, 6, 7]\n"
        "    allowed: [Cr, Mn]\n"
        "  site2:\n"
        "    source_kind: Cr\n"
        "    count: 16\n"
        "    site_indices: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]\n"
        "    allowed: [Cr, Mn]\n"
        "  site3:\n"
        "    source_kind: O\n"
        "    count: 32\n"
        "    site_indices: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55]\n"
        "    allowed: [O]\n"
    )
    outdir = tmp_path / "samples"

    rc = main(
        [
            "--json",
            "sample",
            str(input_path),
            "-n",
            "1",
            "--outdir",
            str(outdir),
            "--prefix",
            "wy",
            "--seed",
            "5",
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    sample_text = Path(payload["files"][0]).read_text()
    assert sample_text.count("# site-001") == 8
    assert sample_text.count("# site-002") == 16
    assert sample_text.count("# site-003") == 32


def test_cli_sample_global_fractions_with_target_scaled_site_group_counts(
    tmp_path: Path,
    capsys,
):
    poscar = Path("tests/golden/fixtures/G001_CCS02/POSCAR-MnCr2O4.vasp").resolve()
    input_path = tmp_path / "input.yaml"
    input_path.write_text(
        "structure:\n"
        f"  poscar: {poscar}\n"
        "  n_target_sites: 112\n"
        "composition:\n"
        "  fractions:\n"
        "    Mn: 0.0625\n"
        "    Cr: 0.125\n"
        "    Ni: 0.08482142857142858\n"
        "    Rh: 0.044642857142857144\n"
        "    Co: 0.06473214285714286\n"
        "    Fe: 0.046875\n"
        "    O: 0.5714285714285714\n"
        "charges:\n"
        "  Mn: 2.0\n"
        "  Cr: 3.0\n"
        "  Ni: 2.0\n"
        "  Rh: 3.0\n"
        "  Co: 2.0\n"
        "  Fe: 3.0\n"
        "  O: -1.87890625\n"
        "recipes:\n"
        "  - from_kind: Mn\n"
        "    to: [Mn, Cr, Ni, Rh, Co, Fe]\n"
        "  - from_kind: Cr\n"
        "    to: [Mn, Cr, Ni, Rh, Co, Fe]\n"
        "  - from_kind: O\n"
        "    to: [O]\n"
        "site_groups:\n"
        "  site1:\n"
        "    source_kind: Mn\n"
        "    count: 16\n"
        "    allowed: [Mn, Cr, Ni, Rh, Co, Fe]\n"
        "  site2:\n"
        "    source_kind: Cr\n"
        "    count: 32\n"
        "    allowed: [Mn, Cr, Ni, Rh, Co, Fe]\n"
        "  site3:\n"
        "    source_kind: O\n"
        "    count: 64\n"
        "    allowed: [O]\n"
        "allocation:\n"
        "  time_budget_sec: 180\n"
    )
    outdir = tmp_path / "samples"

    rc = main(
        [
            "--json",
            "sample",
            str(input_path),
            "-n",
            "2",
            "--outdir",
            str(outdir),
            "--prefix",
            "frac",
            "--seed",
            "17",
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    first_sample = Path(payload["files"][0]).read_text()
    lines = first_sample.splitlines()
    species = lines[5].split()
    counts = [int(v) for v in lines[6].split()]
    assert dict(zip(species, counts)) == {
        "Mn": 7,
        "Cr": 14,
        "Ni": 10,
        "Rh": 5,
        "Co": 7,
        "Fe": 5,
        "O": 64,
    }
    assert first_sample.count("# site-001") == 16
    assert first_sample.count("# site-002") == 32
    assert first_sample.count("# site-003") == 64
    assert all(Path(file_path).exists() for file_path in payload["files"])
