from pathlib import Path

import pytest

from esspy import (
    compute_supercell_expansion,
    parse_guider_text,
    parse_guider_text_to_guide_input_native,
)
from esspy.native import load_native_module
from esspy.poscar import load_poscar


GUIDER_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
)
GUIDER_G002 = Path(
    "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt"
)


def _structure_for(guider_path: Path):
    spec = parse_guider_text(guider_path)
    poscar_path = guider_path.parent / spec.poscar_filename
    structure = load_poscar(poscar_path)
    return spec, structure


def test_compute_supercell_expansion_g001_expands_to_2_2_2():
    spec, structure = _structure_for(GUIDER_G001)

    result = compute_supercell_expansion(
        structure.lattice, len(structure.sites), spec.n_target_sites
    )

    assert result.expansion == (2, 2, 2)
    assert result.expanded_n_atom_config == len(structure.sites) * 8
    assert result.log[0] == "SupercellExpansion = [1,1,1]: ExpandedNAtomConfig= 14"
    # The starred line marks the chosen candidate.
    assert any(line.endswith("*") for line in result.log)
    assert (
        result.log[-1]
        == "ExpandedNAtomConfig ~ NTargetSites: SupercellExpansion = [2,2,2]"
    )


def test_compute_supercell_expansion_g002_keeps_primitive_cell():
    spec, structure = _structure_for(GUIDER_G002)

    result = compute_supercell_expansion(
        structure.lattice, len(structure.sites), spec.n_target_sites
    )

    assert result.expansion == (1, 1, 1)
    assert result.expanded_n_atom_config == len(structure.sites)
    assert (
        result.log[-1]
        == "ExpandedNAtomConfig ~ NTargetSites: SupercellExpansion = [1,1,1]"
    )


def test_compute_supercell_expansion_when_primitive_already_exceeds_target():
    spec, structure = _structure_for(GUIDER_G002)

    result = compute_supercell_expansion(structure.lattice, 200, spec.n_target_sites)

    assert result.expansion == (1, 1, 1)
    assert result.expanded_n_atom_config == 200
    assert (
        result.log
        == ["NAtomConfig > NTargetSites: SupercellExpansion = [1, 1, 1]"]
    )


def test_native_guide_diagnostics_now_reports_real_supercell_expansion():
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(str(GUIDER_G001))
    result = native.guide(guide_input)

    assert tuple(result["ready"]["supercell_expansion"]) == (2, 2, 2)
    assert tuple(result["diagnostics"]["supercell_expansion"]) == (2, 2, 2)
    assert result["diagnostics"]["n_atom_config"] == 14
    assert any(
        message.startswith("ExpandedNAtomConfig ~ NTargetSites:")
        for message in result["diagnostics"]["messages"]
    )


def test_native_guide_honors_explicit_supercell_expansion():
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(str(GUIDER_G001))
    guide_input["supercell_expansion"] = [2, 2, 2]

    result = native.guide(guide_input)

    assert tuple(result["ready"]["supercell_expansion"]) == (2, 2, 2)
    assert any(
        message.startswith("Explicit SupercellExpansion = [2,2,2]")
        for message in result["diagnostics"]["messages"]
    )


@pytest.mark.parametrize(
    "guider_path,expected",
    [
        (GUIDER_G001, (2, 2, 2)),
        (GUIDER_G002, (1, 1, 1)),
    ],
)
def test_native_guide_matches_golden_supercell_expansion_via_guider_text(
    guider_path: Path, expected: tuple[int, int, int]
):
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(str(guider_path))
    result = native.guide(guide_input)

    assert tuple(result["ready"]["supercell_expansion"]) == expected
