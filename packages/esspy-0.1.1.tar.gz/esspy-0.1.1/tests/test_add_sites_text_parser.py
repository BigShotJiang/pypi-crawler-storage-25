from pathlib import Path

import pytest

from esspy import parse_add_sites_monte_carlo_spec
from esspy.native_extract import parse_add_sites_monte_carlo_spec_native


def test_parse_add_sites_block_semantics(tmp_path: Path):
    input_path = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    input_path.write_text(
        "NEnergyTableLine 2\n"
        "NAddKind(For_NEnergyTableLine!=-1_Or_PrintTheStablestUnstablest=1_Only) 2\n"
        "AddMeshes 0.25 0.50 0.75\n"
        "MinDistanceBetweenAddedSites 1.80\n"
        "NMonteCarlo 200\n"
        "MonteCarloMonitorIndex 25\n"
        "# kind nadded oxidation neighkind dox dist_min dist_max ...\n"
        "Li 1 1.0 O -2.0 1.0 2.2 Mn 0.5 0.0 10000\n"
        "Na 2 1.0 O -2.0 1.2 2.5\n"
    )

    spec = parse_add_sites_monte_carlo_spec(input_path)
    assert spec.present is True
    assert spec.n_add_kind == 2
    assert spec.add_meshes == pytest.approx((0.25, 0.50, 0.75))
    assert spec.min_distance_between_added_sites == pytest.approx(1.8)
    assert spec.n_monte_carlo == 200
    assert spec.monte_carlo_monitor_index == 25
    assert len(spec.added_kinds) == 2
    assert spec.added_kinds[0].kind == "Li"
    assert spec.added_kinds[0].n_added == 1
    assert len(spec.added_kinds[0].neighbor_kinds) == 2
    assert spec.added_kinds[0].neighbor_kinds[0].kind == "O"
    assert spec.added_kinds[0].neighbor_kinds[0].doxidation == pytest.approx(-2.0)


def test_parse_add_sites_missing_block_returns_not_present(tmp_path: Path):
    input_path = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    input_path.write_text("NEnergyTableLine 2\nChopLevel 8\n")

    spec = parse_add_sites_monte_carlo_spec(input_path)
    assert spec.present is False
    assert spec.n_add_kind == 0
    assert spec.added_kinds == []


def test_parse_add_sites_native_round_trip(tmp_path: Path):
    input_path = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    input_path.write_text(
        "NAddKind(For_NEnergyTableLine!=-1_Or_PrintTheStablestUnstablest=1_Only) 1\n"
        "AddMeshes 1.0 2.0 3.0\n"
        "MinDistanceBetweenAddedSites 0.9\n"
        "NMonteCarlo -5\n"
        "MonteCarloMonitorIndex 2\n"
        "H 1 1.0 O -2.0 1.0 2.0\n"
    )

    payload = parse_add_sites_monte_carlo_spec_native(input_path)
    assert payload["present"] is True
    assert payload["n_add_kind"] == 1
    assert payload["n_monte_carlo"] == -5
    assert payload["added_kinds"][0]["kind"] == "H"


def test_parse_add_sites_raises_on_missing_scalar_field(tmp_path: Path):
    input_path = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    input_path.write_text(
        "NAddKind(For_NEnergyTableLine!=-1_Or_PrintTheStablestUnstablest=1_Only) 1\n"
        "AddMeshes 1.0 2.0 3.0\n"
        "NMonteCarlo 10\n"
        "MonteCarloMonitorIndex 5\n"
        "H 1 1.0 O -2.0 1.0 2.0\n"
    )

    with pytest.raises(RuntimeError):
        parse_add_sites_monte_carlo_spec_native(input_path)
