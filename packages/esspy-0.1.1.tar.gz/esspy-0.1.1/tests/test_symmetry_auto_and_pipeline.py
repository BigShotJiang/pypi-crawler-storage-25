from __future__ import annotations

from pathlib import Path
import types

import pytest

from esspy import (
    AddSitesMonteCarloOptions,
    Lattice,
    Site,
    StructureModel,
    detect_symmetry_with_spglib,
    load_add_sites_execution_input,
    run_add_sites_from_solver_text,
    run_add_sites_from_solver_text_mpi,
    symmetry_to_wyc_text,
    write_wyc_file,
)


def _simple_structure() -> StructureModel:
    return StructureModel(
        title="s",
        lattice=Lattice(a=(4.0, 0.0, 0.0), b=(0.0, 4.0, 0.0), c=(0.0, 0.0, 4.0)),
        sites=[
            Site(kind="O", x=0.0, y=0.0, z=0.0, oxidation=-2.0),
            Site(kind="Mn", x=0.5, y=0.5, z=0.5, oxidation=2.0),
        ],
        fractional_coordinates=True,
    )


def _solver_text(tmp_path: Path) -> Path:
    path = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    path.write_text(
        "NEnergyTableLine 2\n"
        "NAddKind(For_NEnergyTableLine!=-1_Or_PrintTheStablestUnstablest=1_Only) 1\n"
        "AddMeshes 0.5 0.5 0.5\n"
        "MinDistanceBetweenAddedSites 0.1\n"
        "NMonteCarlo 4\n"
        "MonteCarloMonitorIndex 2\n"
        "Li 1 1.0 O 0.0 0.0 10000.0\n"
    )
    return path


def _write_poscar(path: Path) -> None:
    path.write_text(
        "Toy\n"
        "1.0\n"
        "4 0 0\n"
        "0 4 0\n"
        "0 0 4\n"
        "O Mn\n"
        "1 1\n"
        "Direct\n"
        "0 0 0\n"
        "0.5 0.5 0.5\n"
    )


def test_symmetry_to_wyc_text_and_write_roundtrip(tmp_path: Path):
    fake_sym = types.SimpleNamespace(
        wyc_operations=[
            types.SimpleNamespace(
                matrix=((1.0, 0.0, 0.0, 0.0), (0.0, 1.0, 0.0, 0.0), (0.0, 0.0, 1.0, 0.0))
            ),
            types.SimpleNamespace(
                matrix=((1.0, 0.0, 0.0, 0.5), (0.0, 1.0, 0.0, 0.5), (0.0, 0.0, 1.0, 0.5))
            ),
        ]
    )
    text = symmetry_to_wyc_text(fake_sym)  # type: ignore[arg-type]
    assert text.startswith("Nwyc 2\n")
    out = tmp_path / "2.wyc"
    write_wyc_file(out, fake_sym)  # type: ignore[arg-type]
    assert out.read_text() == text


def test_detect_symmetry_with_spglib_uses_operations(monkeypatch):
    class _FakeSpglib:
        @staticmethod
        def get_symmetry_dataset(cell, symprec=1e-5):
            return {"number": 2, "international": "P-1"}

        @staticmethod
        def get_symmetry(cell, symprec=1e-5):
            return {
                "rotations": [
                    [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
                    [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
                ],
                "translations": [[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]],
            }

    monkeypatch.setitem(__import__("sys").modules, "spglib", _FakeSpglib())
    detected = detect_symmetry_with_spglib(_simple_structure())
    assert detected.space_group_number == 2
    assert detected.international_symbol == "P-1"
    assert len(detected.symmetry.wyc_operations) == 2
    assert detected.symmetry.from_spglib is True


def test_load_add_sites_execution_input_and_run(tmp_path: Path):
    solver = _solver_text(tmp_path)
    poscar = tmp_path / "POSCAR.vasp"
    _write_poscar(poscar)

    structure, spec = load_add_sites_execution_input(
        solver, poscar, charges_by_kind={"O": -2.0, "Mn": 2.0}
    )
    assert len(structure.sites) == 2
    assert structure.sites[0].oxidation == -2.0
    assert spec["n_monte_carlo"] == 4

    result = run_add_sites_from_solver_text(
        solver,
        poscar,
        options=AddSitesMonteCarloOptions(random_seed=17, rg_find_factor=1, chop_level=8.0),
        charges_by_kind={"O": -2.0, "Mn": 2.0},
    )
    assert result.attempted_trials == 4
    assert result.success is True


def test_run_add_sites_from_solver_text_mpi_serial_fallback(tmp_path: Path):
    solver = _solver_text(tmp_path)
    poscar = tmp_path / "POSCAR.vasp"
    _write_poscar(poscar)

    result = run_add_sites_from_solver_text_mpi(
        solver,
        poscar,
        options=AddSitesMonteCarloOptions(random_seed=5),
        charges_by_kind={"O": -2.0, "Mn": 2.0},
        use_mpi=False,
    )
    assert result.world_size == 1
    assert result.attempted_trials_total == 4
    assert result.success is True

