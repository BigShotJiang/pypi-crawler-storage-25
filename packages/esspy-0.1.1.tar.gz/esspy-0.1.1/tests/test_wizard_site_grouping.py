from __future__ import annotations

from pathlib import Path

import yaml

from esspy.poscar import load_poscar
from esspy.wizard import WizardMode, WizardSession


ROOT = Path(__file__).resolve().parents[1]
POSCAR_TARGET = ROOT / "examples" / "site_grouping_wyckoff" / "POSCAR-target"


def test_wizard_detects_element_wyckoff_site_groups(monkeypatch, capsys):
    wizard = WizardSession(mode=WizardMode.COMPOSITION)
    wizard.state.structure = load_poscar(POSCAR_TARGET)
    wizard.state.reference_structure = str(POSCAR_TARGET)
    wizard.state.element_mapping = {
        "Cr": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
        "O": ["O"],
    }
    wizard.state.mapped_elements = ["Mn", "Cr", "Ni", "Rh", "Co", "Fe", "O"]

    menu_answers = iter([1, 0])  # element_wyckoff, then global composition mode
    monkeypatch.setattr(
        wizard,
        "render_menu",
        lambda *args, **kwargs: next(menu_answers),
    )
    prompt_answers = iter([0.1, 5.0])
    monkeypatch.setattr(
        wizard,
        "prompt_input",
        lambda *args, **kwargs: next(prompt_answers),
    )
    monkeypatch.setattr(wizard, "confirm", lambda *args, **kwargs: True)

    assert wizard.step_2b_site_groups_and_composition_mode() is True

    output = capsys.readouterr().out
    assert "Detected site groups (element_wyckoff)" in output
    assert "Cr@a" in output
    assert "Cr@d" in output
    assert "O@e" in output
    assert wizard.state.composition_mode == "global"
    assert wizard.state.site_grouping["mode"] == "element_wyckoff"
    assert wizard.state.site_grouping["space_group"] == 227
    assert wizard.state.site_groups["site1"]["site_indices"] == list(range(0, 8))
    assert wizard.state.site_groups["site1"]["label"]["display"] == "Cr@a"
    assert wizard.state.site_groups["site2"]["site_indices"] == list(range(8, 24))
    assert wizard.state.site_groups["site2"]["label"]["display"] == "Cr@d"
    assert wizard.state.site_groups["site3"]["site_indices"] == list(range(24, 56))
    assert wizard.state.site_groups["site3"]["label"]["display"] == "O@e"


def test_wizard_save_preserves_site_grouping_schema(tmp_path: Path, monkeypatch):
    wizard = WizardSession(mode=WizardMode.COMPOSITION)
    wizard.state.structure = load_poscar(POSCAR_TARGET)
    wizard.state.reference_structure = str(POSCAR_TARGET)
    wizard.state.target_atoms = 56
    wizard.state.element_mapping = {
        "Cr": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
        "O": ["O"],
    }
    wizard.state.mapped_elements = ["Mn", "Cr", "Ni", "Rh", "Co", "Fe", "O"]

    menu_answers = iter([1, 0])
    monkeypatch.setattr(
        wizard,
        "render_menu",
        lambda *args, **kwargs: next(menu_answers),
    )
    prompt_answers = iter([0.1, 5.0])
    monkeypatch.setattr(wizard, "prompt_input", lambda *args, **kwargs: next(prompt_answers))
    monkeypatch.setattr(wizard, "confirm", lambda *args, **kwargs: True)
    assert wizard.step_2b_site_groups_and_composition_mode() is True

    wizard.state.composition = {
        "Mn": 4,
        "Cr": 20,
        "Ni": 0,
        "Rh": 0,
        "Co": 0,
        "Fe": 0,
        "O": 32,
    }
    wizard.state.composition_fractions = {
        key: value / 56 for key, value in wizard.state.composition.items()
    }
    wizard.state.charges = {
        "Mn": 2.0,
        "Cr": 3.0,
        "Ni": 2.0,
        "Rh": 3.0,
        "Co": 2.0,
        "Fe": 3.0,
        "O": -2.0,
    }
    wizard.state.charge_basis = "element+site_group"
    wizard.state.charges_by_site = {
        "Mn@site1": 2.0,
        "Mn@site2": 2.0,
        "Cr@site1": 3.0,
        "Cr@site2": 3.0,
        "Ni@site1": 2.0,
        "Ni@site2": 2.0,
        "Rh@site1": 3.0,
        "Rh@site2": 3.0,
        "Co@site1": 2.0,
        "Co@site2": 2.0,
        "Fe@site1": 3.0,
        "Fe@site2": 3.0,
        "O@site3": -2.0,
    }
    wizard.state.recipes = {
        "Cr": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
        "O": ["O"],
    }
    wizard.state.selection_enabled = False

    out = tmp_path / "input.yaml"
    assert wizard.save_to_yaml(str(out)) is True

    data = yaml.safe_load(out.read_text())
    assert data["site_grouping"]["mode"] == "element_wyckoff"
    assert data["site_groups"]["site1"]["label"]["display"] == "Cr@a"
    assert data["site_groups"]["site1"]["site_indices"] == list(range(0, 8))
    assert data["site_groups"]["site2"]["label"]["display"] == "Cr@d"
    assert data["site_groups"]["site2"]["site_indices"] == list(range(8, 24))
    assert data["site_groups"]["site3"]["label"]["display"] == "O@e"
    assert data["charges"]["elements"]["Cr"]["by_site"]["site1"] == 3.0
    assert data["charges"]["elements"]["Cr"]["by_site"]["site2"] == 3.0
