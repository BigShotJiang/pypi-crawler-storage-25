from pathlib import Path

import pytest

from esspy import (
    ReadyFileWriteOptions,
    parse_guider_text,
    parse_guider_text_to_guide_input_native,
    write_ready_file_text,
)
from esspy.native import load_native_module


GUIDER_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
)
GUIDER_G002 = Path(
    "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt"
)
READY_G001 = Path(
    "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolution.ready.txt"
)
READY_G002 = Path(
    "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolution.ready.txt"
)


def _round_trip_text(guider_path: Path) -> str:
    spec = parse_guider_text(guider_path)
    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(str(guider_path))
    guide_result = native.guide(guide_input)
    options = ReadyFileWriteOptions(
        target_cpu_time_sec=spec.options.target_cpu_time_sec
    )
    return write_ready_file_text(guide_result["ready"], options)


def test_g001_ready_file_round_trip_is_byte_exact():
    actual = _round_trip_text(GUIDER_G001)
    expected = READY_G001.read_text()
    assert actual == expected


def test_g002_ready_file_round_trip_is_byte_exact():
    actual = _round_trip_text(GUIDER_G002)
    expected = READY_G002.read_text()
    assert actual == expected


def test_writer_uses_target_cpu_time_sec_for_running_index_delta():
    spec = parse_guider_text(GUIDER_G001)
    assert spec.options.target_cpu_time_sec == 600

    native = load_native_module()
    guide_input = parse_guider_text_to_guide_input_native(str(GUIDER_G001))
    guide_result = native.guide(guide_input)

    text_default = write_ready_file_text(
        guide_result["ready"], {"target_cpu_time_sec": 600}
    )
    text_alternate = write_ready_file_text(
        guide_result["ready"], {"target_cpu_time_sec": 1800}
    )

    assert "RunningIndexDelta(Negative:TargetCPUTimeInSec) -600" in text_default
    assert "RunningIndexDelta(Negative:TargetCPUTimeInSec) -1800" in text_alternate
    assert "RunningIndexDelta(Negative:TargetCPUTimeInSec) -600" not in text_alternate


def test_writer_separator_lines_are_154_equals_signs():
    spec = parse_guider_text(GUIDER_G001)
    text = _round_trip_text(GUIDER_G001)
    separator = "=" * 154
    # The original Guider emits the separator multiple times around the
    # NRecipe block, the energy-table block, and the closing block.
    assert text.count(separator) >= 5


def test_writer_outputs_ready_block_in_expected_order():
    text = _round_trip_text(GUIDER_G001)
    lines = text.splitlines()

    # Sanity: header order should match the frozen golden order.
    assert lines[0].startswith("vec_a ")
    assert lines[1].startswith("vec_b ")
    assert lines[2].startswith("vec_c ")
    assert lines[3] == "NAtomConfig 14"
    assert lines[4] == "AtomConfig"
    assert lines[5].startswith("Mn 1.512 ")
    # SupercellExpansion / ChopLevel / RGFindFactor / OutputPrefix appear
    # after the per-atom block.
    supercell_index = next(i for i, line in enumerate(lines) if line.startswith("SupercellExpansion "))
    assert lines[supercell_index] == "SupercellExpansion 2 2 2"
    assert lines[supercell_index + 1] == "ChopLevel 8"
    assert lines[supercell_index + 2] == "RGFindFactor 1"
    assert lines[supercell_index + 3] == "OutputPrefix CCS02_allocation_001"
