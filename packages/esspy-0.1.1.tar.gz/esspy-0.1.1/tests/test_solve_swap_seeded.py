from pathlib import Path

import pytest

from esspy.native import load_native_module


def _tiny_ready_payload() -> dict:
    """Same single-recipe Mn → {Cr, Ni} fixture used by the swap-loop and
    swap-integration suites; deterministic and cheap to evaluate.
    """
    return {
        "lattice": {
            "a": (4.0, 0.0, 0.0),
            "b": (0.0, 4.0, 0.0),
            "c": (0.0, 0.0, 4.0),
        },
        "atoms": [
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.5, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.5, "z": 0.0},
            {"kind": "O", "oxidation": -2.0, "x": 0.5, "y": 0.5, "z": 0.5},
        ],
        "supercell_expansion": (1, 1, 1),
        "rg_find_factor": 1,
        "output_prefix": "tiny",
        "recipes": [
            {
                "from": "Mn",
                "oxidation": 2.0,
                "random_pickup": 3,
                "random_pickup_trial": 1,
                "modifications": [
                    {"to": "Cr", "oxidation": 3.0, "count": 1},
                    {"to": "Ni", "oxidation": 1.0, "count": 1},
                ],
            },
        ],
    }


def test_swap_loop_starting_sites_override_uses_provided_state():
    native = load_native_module()

    # First, run the swap loop from canonical state and capture the
    # initial total energy that the canonical state implies.
    canonical = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 1, "max_swap": 0}
    )

    # Build an alternative starting state by permuting the assignment:
    # rotate (Cr, Ni, Mn) -> (Mn, Cr, Ni) over the first three sites.
    canonical_sites = canonical["final_structure"]["sites"]
    permuted_sites = [
        {
            "kind": canonical_sites[2]["kind"],
            "oxidation": canonical_sites[2]["oxidation"],
            "x": canonical_sites[0]["x"],
            "y": canonical_sites[0]["y"],
            "z": canonical_sites[0]["z"],
        },
        {
            "kind": canonical_sites[0]["kind"],
            "oxidation": canonical_sites[0]["oxidation"],
            "x": canonical_sites[1]["x"],
            "y": canonical_sites[1]["y"],
            "z": canonical_sites[1]["z"],
        },
        {
            "kind": canonical_sites[1]["kind"],
            "oxidation": canonical_sites[1]["oxidation"],
            "x": canonical_sites[2]["x"],
            "y": canonical_sites[2]["y"],
            "z": canonical_sites[2]["z"],
        },
        # The O site must stay identical (not part of the recipe pool).
        canonical_sites[3],
    ]

    overridden = native.compute_swap_loop(
        _tiny_ready_payload(),
        {"mode": 1, "max_swap": 0, "starting_sites": permuted_sites},
    )

    # The overridden initial energy must reflect the permuted assignment,
    # not the canonical one.
    assert overridden["initial_total_energy"] != pytest.approx(
        canonical["initial_total_energy"]
    )
    # Log marker confirms the override path was taken.
    assert any(
        "starting_sites override" in line for line in overridden["log"]
    )


def test_swap_loop_starting_sites_size_mismatch_raises():
    native = load_native_module()
    with pytest.raises(Exception):
        native.compute_swap_loop(
            _tiny_ready_payload(),
            {
                "mode": 1,
                "max_swap": 1,
                "starting_sites": [
                    {
                        "kind": "Mn",
                        "oxidation": 2.0,
                        "x": 0.0,
                        "y": 0.0,
                        "z": 0.0,
                    }
                ],
            },
        )


def test_swap_loop_empty_starting_sites_falls_back_to_canonical():
    native = load_native_module()
    canonical = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 1, "max_swap": 0}
    )
    explicit_empty = native.compute_swap_loop(
        _tiny_ready_payload(),
        {"mode": 1, "max_swap": 0, "starting_sites": []},
    )

    assert canonical["initial_total_energy"] == pytest.approx(
        explicit_empty["initial_total_energy"]
    )


def test_solve_swap_loop_seeded_from_window_when_window_has_samples():
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 5,
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 4,
                "local_enumeration_max_chunks": 1,
            },
        }
    )

    messages = result["messages"]
    seeded_lines = [
        m for m in messages if m.startswith("[SOLVE] swap_seeded_from_window=")
    ]
    assert seeded_lines, "expected swap_seeded_from_window message in solve output"
    assert seeded_lines[0].endswith("=true")


def test_solve_swap_loop_can_seed_from_caller_provided_sites():
    native = load_native_module()
    canonical = native.compute_swap_loop(
        _tiny_ready_payload(), {"mode": 1, "max_swap": 0}
    )
    canonical_sites = canonical["final_structure"]["sites"]
    permuted_sites = [
        {
            "kind": canonical_sites[2]["kind"],
            "oxidation": canonical_sites[2]["oxidation"],
            "x": canonical_sites[0]["x"],
            "y": canonical_sites[0]["y"],
            "z": canonical_sites[0]["z"],
        },
        {
            "kind": canonical_sites[0]["kind"],
            "oxidation": canonical_sites[0]["oxidation"],
            "x": canonical_sites[1]["x"],
            "y": canonical_sites[1]["y"],
            "z": canonical_sites[1]["z"],
        },
        {
            "kind": canonical_sites[1]["kind"],
            "oxidation": canonical_sites[1]["oxidation"],
            "x": canonical_sites[2]["x"],
            "y": canonical_sites[2]["y"],
            "z": canonical_sites[2]["z"],
        },
        canonical_sites[3],
    ]
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "swap_loop_seed_source": 3,
                "swap_loop_starting_sites": permuted_sites,
                "max_swap": 1,
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 1,
                "local_enumeration_max_chunks": 1,
            },
        }
    )

    messages = result["messages"]
    assert any(m == "[SOLVE] swap_seeded_from_external=true" for m in messages)
    assert any(m == "[SOLVE] swap_seed_source=3" for m in messages)


def test_solve_swap_loop_falls_back_to_canonical_when_window_empty():
    """If the window evaluation produced no samples, the swap loop must
    fall back to the canonical recipe state. Force this by giving the
    enumeration loop a starting offset that lies past the available
    candidates so the window stays empty.
    """
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 5,
                "local_enumeration_offset": 100000,
                "local_enumeration_limit": 4,
                "local_enumeration_max_chunks": 1,
            },
        }
    )

    messages = result["messages"]
    seeded_lines = [
        m for m in messages if m.startswith("[SOLVE] swap_seeded_from_window=")
    ]
    if not seeded_lines:
        pytest.skip(
            "solve message stream did not surface the seeded marker; not all "
            "build configurations propagate it"
        )
    assert seeded_lines[0].endswith("=false")


def test_solve_swap_seeded_lowers_or_matches_window_best():
    """The swap-seeded solve() integration must never produce a higher
    best energy than the window-only path on the same input."""
    native = load_native_module()
    base = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 4,
                "local_enumeration_max_chunks": 1,
            },
        }
    )
    seeded = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 5,
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 4,
                "local_enumeration_max_chunks": 1,
            },
        }
    )

    assert seeded["best"]["energy"] <= base["best"]["energy"] + 1.0e-12
