from pathlib import Path

import pytest

from esspy.native import load_native_module


def _tiny_ready_payload() -> dict:
    """Same single-recipe Mn → {Cr, Ni} fixture used by other swap suites."""
    return {
        "lattice": {
            "a": (4.0, 0.0, 0.0),
            "b": (0.0, 4.0, 0.0),
            "c": (0.0, 0.0, 4.0),
        },
        "atoms": [
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.5, "y": 0.0, "z": 0.0},
            {"kind": "Mn", "oxidation": 2.0, "x": 0.0, "y": 0.5, "z": 0.0},
            {"kind": "O", "oxidation": -2.0, "x": 0.5, "y": 0.5, "z": 0.5},
        ],
        "supercell_expansion": (1, 1, 1),
        "rg_find_factor": 1,
        "output_prefix": "tiny",
        "recipes": [
            {
                "from": "Mn",
                "oxidation": 2.0,
                "random_pickup": 3,
                "random_pickup_trial": 1,
                "modifications": [
                    {"to": "Cr", "oxidation": 3.0, "count": 1},
                    {"to": "Ni", "oxidation": 1.0, "count": 1},
                ],
            },
        ],
    }


def _solve(seed_source: int) -> dict:
    native = load_native_module()
    return native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 5,
                "swap_loop_seed_source": seed_source,
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 4,
                "local_enumeration_max_chunks": 1,
            },
        }
    )


def _seed_message(messages: list[str]) -> str | None:
    for line in messages:
        if line.startswith("[SOLVE] swap_seed_source="):
            return line
    return None


def test_solve_swap_seed_source_default_uses_window_best():
    """seed_source = 1 (default) seeds from window-best snapshot, just
    like Phase 26."""
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 5,
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 4,
                "local_enumeration_max_chunks": 1,
            },
        }
    )
    seed_line = _seed_message(result["messages"])
    assert seed_line is not None
    assert seed_line.endswith("=1")


def test_solve_swap_seed_source_two_uses_window_worst():
    result = _solve(seed_source=2)
    seed_line = _seed_message(result["messages"])
    assert seed_line is not None
    assert seed_line.endswith("=2")


def test_solve_swap_seed_source_zero_falls_back_to_canonical():
    result = _solve(seed_source=0)
    seed_line = _seed_message(result["messages"])
    assert seed_line is not None
    assert seed_line.endswith("=0")
    seeded_lines = [
        m
        for m in result["messages"]
        if m.startswith("[SOLVE] swap_seeded_from_window=")
    ]
    assert seeded_lines, "expected swap_seeded_from_window message"
    assert seeded_lines[0].endswith("=false")


def test_solve_swap_seed_source_unknown_value_falls_back_to_canonical():
    """Unknown seed_source values must not silently pick best or worst."""
    result = _solve(seed_source=99)
    seed_line = _seed_message(result["messages"])
    assert seed_line is not None
    assert seed_line.endswith("=0")


def test_solve_swap_worst_seed_lowers_energy_from_window_worst_start():
    """Worst-seeded swap is a diagnostic local-search path: starting
    from the highest-energy candidate the window evaluation found, the
    swap loop should still reach a lower final energy than that
    starting point. The legacy `super_cell_unstablest` flow has the
    same property.

    Note: worst-seeded swap is allowed to converge to a different (and
    possibly higher) local minimum than the best-seeded run, because
    swap is a local search whose endpoint depends on the starting
    state. We therefore do not assert that worst-seeded final energy
    beats best-seeded final energy.
    """
    worst_seeded = _solve(seed_source=2)

    messages = worst_seeded["messages"]
    initial = next(
        (
            float(m.split("=", 1)[1])
            for m in messages
            if m.startswith("[SOLVE] swap_initial_e=")
        ),
        None,
    )
    final = next(
        (
            float(m.split("=", 1)[1])
            for m in messages
            if m.startswith("[SOLVE] swap_final_e=")
        ),
        None,
    )
    assert initial is not None and final is not None
    # Swap only ever accepts strict improvements; worst-seeded final
    # must never exceed worst-seeded initial within numerical
    # tolerance.
    assert final <= initial + 1.0e-9


def test_solve_swap_worst_seed_de_min_swap_is_non_positive():
    """Even when starting from the worst window candidate, the swap loop
    must report `de_min_swap <= 0` (it only accepts improving swaps)."""
    result = _solve(seed_source=2)
    local = result["local_reduction"]
    assert local["local_de_min_swap"] <= 1.0e-12


def test_solve_swap_seed_source_two_with_no_window_falls_back_to_canonical():
    """Even when the caller asks for worst-seeded, an empty window forces
    the canonical fallback (otherwise the swap loop would have nothing
    to seed from)."""
    native = load_native_module()
    result = native.solve(
        {
            "ready": _tiny_ready_payload(),
            "options": {
                "swap_loop_enabled": True,
                "max_swap": 5,
                "swap_loop_seed_source": 2,
                "local_enumeration_offset": 100000,
                "local_enumeration_limit": 4,
                "local_enumeration_max_chunks": 1,
            },
        }
    )
    seed_line = _seed_message(result["messages"])
    assert seed_line is not None
    assert seed_line.endswith("=0")
