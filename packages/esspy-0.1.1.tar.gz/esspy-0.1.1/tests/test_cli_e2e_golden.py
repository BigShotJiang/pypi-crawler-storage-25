"""Phase 82 \u2014 End-to-End CLI Golden Directory Comparison."""
from __future__ import annotations

import json
from pathlib import Path

from esspy.cli import main as cli_main
from tests.golden.references import (
    G001_CCS02_GUIDER,
    G001_CCS02_READY,
)


def _run_cli(argv: list[str], capsys) -> str:
    rc = cli_main(argv)
    assert rc == 0
    captured = capsys.readouterr()
    return captured.out


def test_cli_e2e_golden_g001_ccs02(tmp_path: Path, capsys):
    """Run an end-to-end golden test for G001.
    
    This exercises Scenario B: Legacy migration.
    1. init from-guider
    2. enable writing outputs in output yaml
    3. run
    4. compare generated outputs against frozen references
    """
    input_yaml = tmp_path / "input.yaml"
    workdir = tmp_path / "run-g001"
    
    # 1. Migrate the legacy guider text into a modern input.yaml
    output = _run_cli(
        [
            "init", 
            "from-guider", 
            str(G001_CCS02_GUIDER), 
            "--out", 
            str(input_yaml),
        ],
        capsys,
    )
    
    assert input_yaml.exists()
    
    # 2. Modify input.yaml to write all legacy outputs
    yaml_text = input_yaml.read_text()
    
    # The default output block only has prefix, write_guider: false, write_ready: false, etc.
    # We want to enable all of them to compare.
    # A bit hacky but effective replacement for test purposes:
    yaml_text = yaml_text.replace("write_guider: false", "write_guider: true")
    yaml_text = yaml_text.replace("write_ready: false", "write_ready: true")
    yaml_text = yaml_text.replace("write_poscar: false", "write_poscar: true")
    input_yaml.write_text(yaml_text)
    
    capsys.readouterr() # drain
    
    # 3. Run the full pipeline
    output = _run_cli(["--json", "run", str(input_yaml), "--workdir", str(workdir)], capsys)
    
    # 4. Extract generated outputs
    payload = json.loads(output)
    outputs = payload.get("outputs", {})
    
    assert "guider" in outputs
    assert "ready" in outputs
    assert "poscar" in outputs
    assert "best_poscar" in outputs
    assert "worst_poscar" in outputs
    assert "log" in outputs
    assert "progress_jsonl" in outputs
    assert "progress_latest" in outputs
    assert Path(outputs["log"]).exists()
    assert Path(outputs["progress_jsonl"]).exists()
    assert Path(outputs["progress_latest"]).exists()
    assert "run.started" in Path(outputs["log"]).read_text()
    assert "solve.done" in Path(outputs["progress_jsonl"]).read_text()
    
    generated_guider = Path(outputs["guider"])
    generated_ready = Path(outputs["ready"])
    
    # Golden Check 1: Guider Text
    # `guide export-guider` is known to byte-for-byte match the original guider for G001
    # except for the absolute path to the POSCAR file, which is resolved during `init from-guider`.
    from esspy.guider_text import parse_guider_text
    import pytest
    original_guider = parse_guider_text(G001_CCS02_GUIDER)
    re_exported_guider = parse_guider_text(generated_guider)
    assert re_exported_guider.target_fractions == pytest.approx(original_guider.target_fractions)
    assert re_exported_guider.charges == pytest.approx(original_guider.charges)
    assert re_exported_guider.n_target_sites == original_guider.n_target_sites
    assert re_exported_guider.space_group == original_guider.space_group
    assert [(r.from_kind, list(r.to)) for r in re_exported_guider.recipes] == [
        (r.from_kind, list(r.to)) for r in original_guider.recipes
    ]
    
    # Golden Check 2: Ready Text
    # We check semantic equality since the new writer may omit the "_001" suffix
    # on the OutputPrefix depending on the workflow settings.
    from tests.golden.ready_parser import parse_ready_file
    original_ready = parse_ready_file(G001_CCS02_READY)
    generated_ready_doc = parse_ready_file(generated_ready)
    
    assert generated_ready_doc.n_atom_config == original_ready.n_atom_config
    assert generated_ready_doc.supercell_expansion == original_ready.supercell_expansion
    assert generated_ready_doc.rg_find_factor == original_ready.rg_find_factor
    assert generated_ready_doc.n_recipe == original_ready.n_recipe
    
    for gen_recipe, orig_recipe in zip(generated_ready_doc.recipes, original_ready.recipes):
        assert gen_recipe.kind == orig_recipe.kind
        assert gen_recipe.random_pickup == orig_recipe.random_pickup
        assert gen_recipe.random_pickup_trial == orig_recipe.random_pickup_trial
        assert len(gen_recipe.modifications) == len(orig_recipe.modifications)
        for gen_mod, orig_mod in zip(gen_recipe.modifications, orig_recipe.modifications):
            assert gen_mod.kind == orig_mod.kind
            assert gen_mod.count == orig_mod.count    
        # Golden Check 3: Solve Outputs
        # G001 contains 14 atoms and has random_pickup configurations.
        # The solve run produces best/worst POSCARs.
        # We verify that they are written and not empty.
        assert Path(outputs["best_poscar"]).exists()
        assert Path(outputs["worst_poscar"]).exists()
    
        best_text = Path(outputs["best_poscar"]).read_text()
        assert all(species in best_text.splitlines()[5] for species in ("Mn", "Cr", "Ni", "O"))
        counts_line = best_text.splitlines()[6]
        total_atoms = sum(int(token) for token in counts_line.split())
        assert total_atoms == 112
