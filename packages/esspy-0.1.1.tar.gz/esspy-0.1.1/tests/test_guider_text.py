from pathlib import Path

from esspy import guider_text_to_run_input, parse_guider_text


def test_parse_guider_text_g001_semantics():
    spec = parse_guider_text("tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt")

    assert spec.n_target_sites == 112
    assert spec.number_fixed_at == "O"
    assert spec.poscar_filename == "POSCAR-MnCr2O4.vasp"
    assert spec.output_prefix == "CCS02_allocation"
    assert spec.space_group == 1
    assert spec.target_fractions["Mn"] == 0.125
    assert spec.charges["Ni"] == 1.299835
    assert spec.options.strict_no_added_sites is True
    assert [recipe.from_kind for recipe in spec.recipes] == ["Mn", "Cr"]


def test_parse_guider_text_g002_semantics():
    spec = parse_guider_text("tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt")

    assert spec.poscar_filename == "POSCAR-M48O64.vasp"
    assert spec.output_prefix == "CCS03_formalcharge"
    assert spec.options.strict_no_added_sites is False
    assert spec.recipes[0].from_kind == "M"
    assert spec.recipes[0].to == ["Mn", "Cr", "Ni", "Rh"]


def test_guider_text_to_run_input_with_local_poscar(tmp_path: Path):
    poscar_path = tmp_path / "POSCAR-MnCr2O4.vasp"
    poscar_path.write_text(
        "Mn2 Cr2 O1\n"
        "1.0\n"
        "5.1772941 -0.00001875 2.98909804\n"
        "1.7257584 4.88119953 2.98909789\n"
        "-0.00002168 -0.00001523 5.97823435\n"
        "Mn Cr O\n"
        "2 2 1\n"
        "Direct\n"
        "0.8749977401 0.8749977001 0.8749996701\n"
        "0.1250012098 0.1250015799 0.1250014398\n"
        "0.4999992800 0.4999994600 0.4999998200\n"
        "0.4999993800 0.4999995000 0.0000014100\n"
        "0.2634749112 0.2634745213 0.2634737433\n"
    )
    spec = parse_guider_text("tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt")
    run_input = guider_text_to_run_input(spec, tmp_path)

    assert run_input.guide.structure.title == "CCS02_allocation"
    assert len(run_input.guide.structure.sites) == 5
    assert run_input.guide.composition.n_target_sites == 112
    counts = {entry.kind: entry.count for entry in run_input.guide.composition.entries}
    assert counts == {"Mn": 14, "Cr": 15, "Ni": 19, "O": 64}
    assert run_input.guide.options.strict_no_added_sites is True
