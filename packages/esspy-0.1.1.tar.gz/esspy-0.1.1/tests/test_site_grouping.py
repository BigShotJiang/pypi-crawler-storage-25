from __future__ import annotations

from pathlib import Path

from esspy.poscar import load_poscar
from esspy.site_grouping import (
    SiteGroupingOptions,
    detect_site_groups,
    site_group_specs_to_yaml,
    structure_site_fingerprint,
)


ROOT = Path(__file__).resolve().parents[1]
POSCAR_TARGET = ROOT / "examples" / "site_grouping_wyckoff" / "POSCAR-target"


def _mapping() -> dict[str, list[str]]:
    return {
        "Cr": ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"],
        "O": ["O"],
    }


def test_poscar_target_poscar_kind_groups():
    structure = load_poscar(POSCAR_TARGET)
    result = detect_site_groups(
        structure,
        _mapping(),
        SiteGroupingOptions(mode="poscar_kind"),
    )

    assert result.mode == "poscar_kind"
    assert result.fallback_used is False
    assert [(g.name, g.source_kind, g.count) for g in result.groups] == [
        ("site1", "Cr", 24),
        ("site2", "O", 32),
    ]
    assert result.groups[0].site_indices == list(range(0, 24))
    assert result.groups[1].site_indices == list(range(24, 56))
    assert result.groups[0].allowed == ["Mn", "Cr", "Ni", "Rh", "Co", "Fe"]


def test_poscar_target_element_wyckoff_groups():
    structure = load_poscar(POSCAR_TARGET)
    result = detect_site_groups(
        structure,
        _mapping(),
        SiteGroupingOptions(
            mode="element_wyckoff",
            symprec=0.1,
            angle_tolerance=5.0,
        ),
    )

    assert result.mode == "element_wyckoff"
    assert result.metadata["space_group"] == 227
    assert result.metadata["international"] == "Fd-3m"
    assert [(g.source_kind, g.label["display"], g.count) for g in result.groups] == [
        ("Cr", "Cr@a", 8),
        ("Cr", "Cr@d", 16),
        ("O", "O@e", 32),
    ]
    assert result.groups[0].site_indices == list(range(0, 8))
    assert result.groups[1].site_indices == list(range(8, 24))
    assert result.groups[2].site_indices == list(range(24, 56))
    assert result.groups[0].symmetry["site_symmetry"] == "-43m"
    assert result.groups[1].symmetry["site_symmetry"] == ".-3m"
    assert result.groups[2].symmetry["site_symmetry"] == ".3m"


def test_site_grouping_yaml_contains_indices_and_metadata():
    structure = load_poscar(POSCAR_TARGET)
    result = detect_site_groups(
        structure,
        _mapping(),
        SiteGroupingOptions(mode="element_wyckoff", symprec=0.1),
    )
    data = site_group_specs_to_yaml(result.groups)

    assert data["site1"]["source_kind"] == "Cr"
    assert data["site1"]["site_indices"] == list(range(0, 8))
    assert data["site1"]["label"]["display"] == "Cr@a"
    assert data["site2"]["source_kind"] == "Cr"
    assert data["site2"]["site_indices"] == list(range(8, 24))
    assert data["site2"]["label"]["display"] == "Cr@d"


def test_site_grouping_fallback_to_poscar_kind(monkeypatch):
    from esspy import site_grouping

    def boom(*_args, **_kwargs):
        raise RuntimeError("forced failure")

    monkeypatch.setattr(site_grouping, "_detect_spglib_site_metadata", boom)
    structure = load_poscar(POSCAR_TARGET)

    result = detect_site_groups(
        structure,
        _mapping(),
        SiteGroupingOptions(
            mode="element_wyckoff",
            fallback="poscar_kind",
            strict=False,
        ),
    )

    assert result.fallback_used is True
    assert result.mode == "poscar_kind"
    assert result.metadata["requested_mode"] == "element_wyckoff"
    assert [(g.source_kind, g.count) for g in result.groups] == [
        ("Cr", 24),
        ("O", 32),
    ]


def test_site_grouping_structure_fingerprint_changes_on_site_order():
    structure = load_poscar(POSCAR_TARGET)
    original = structure_site_fingerprint(structure)
    structure.sites[0], structure.sites[1] = structure.sites[1], structure.sites[0]

    assert structure_site_fingerprint(structure) != original

