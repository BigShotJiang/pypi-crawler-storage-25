from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
import yaml

from esspy.cli import main


def _solver_text(tmp_path: Path) -> Path:
    path = tmp_path / "basic_properties_EwaldSolidSolution.txt"
    path.write_text(
        "NEnergyTableLine 2\n"
        "NAddKind(For_NEnergyTableLine!=-1_Or_PrintTheStablestUnstablest=1_Only) 1\n"
        "AddMeshes 0.5 0.5 0.5\n"
        "MinDistanceBetweenAddedSites 0.1\n"
        "NMonteCarlo 4\n"
        "MonteCarloMonitorIndex 2\n"
        "Li 1 1.0 O 0.0 0.0 10000.0\n"
    )
    return path


def _write_poscar(path: Path) -> None:
    path.write_text(
        "Toy\n"
        "1.0\n"
        "4 0 0\n"
        "0 4 0\n"
        "0 0 4\n"
        "O Mn\n"
        "1 1\n"
        "Direct\n"
        "0 0 0\n"
        "0.5 0.5 0.5\n"
    )


def test_cli_add_sites_run_serial(tmp_path: Path, monkeypatch, capsys):
    solver = _solver_text(tmp_path)
    poscar = tmp_path / "POSCAR.vasp"
    _write_poscar(poscar)

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "esspy",
            "add-sites-run",
            "--solver-text",
            str(solver),
            "--poscar",
            str(poscar),
            "--seed",
            "17",
            "--charges-json",
            '{"O":-2,"Mn":2}',
        ],
    )

    rc = main()
    assert rc == 0
    out = capsys.readouterr().out.strip()
    payload = json.loads(out)
    assert payload["attempted_trials"] == 4
    assert payload["success"] is True


def test_cli_add_sites_run_mpi_wrapper_serial_fallback(tmp_path: Path, monkeypatch, capsys):
    solver = _solver_text(tmp_path)
    poscar = tmp_path / "POSCAR.vasp"
    _write_poscar(poscar)

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "esspy",
            "add-sites-run",
            "--solver-text",
            str(solver),
            "--poscar",
            str(poscar),
            "--seed",
            "7",
            "--use-mpi",
            "--charges-json",
            '{"O":-2,"Mn":2}',
        ],
    )

    rc = main()
    assert rc == 0
    out = capsys.readouterr().out.strip()
    payload = json.loads(out)
    assert payload["attempted_trials_total"] == 4
    assert payload["success"] is True


def test_cli_add_sites_group_run_serial(tmp_path: Path, capsys):
    solver = _solver_text(tmp_path)
    poscar = tmp_path / "POSCAR.vasp"
    _write_poscar(poscar)

    rc = main(
        [
            "add-sites",
            "run",
            "--solver-text",
            str(solver),
            "--poscar",
            str(poscar),
            "--seed",
            "19",
            "--charges-json",
            '{"O":-2,"Mn":2}',
        ]
    )
    assert rc == 0
    out = capsys.readouterr().out.strip()
    payload = json.loads(out)
    assert payload["attempted_trials"] == 4
    assert payload["success"] is True


def test_cli_add_sites_group_inspect(tmp_path: Path, capsys):
    solver = _solver_text(tmp_path)

    rc = main(["add-sites", "inspect", "--solver-text", str(solver)])
    assert rc == 0
    out = capsys.readouterr().out.strip()
    payload = json.loads(out)
    assert payload["present"] is True
    assert payload["n_monte_carlo"] == 4
    assert payload["added_kinds"][0]["kind"] == "Li"


def test_cli_add_sites_export_spec_yaml(tmp_path: Path, capsys):
    solver = _solver_text(tmp_path)
    out = tmp_path / "add_sites.yaml"

    rc = main(
        [
            "add-sites",
            "export-spec",
            "--solver-text",
            str(solver),
            "--out",
            str(out),
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["out"] == str(out)
    assert payload["format"] == "yaml"
    exported = yaml.safe_load(out.read_text())
    assert exported["present"] is True
    assert exported["n_monte_carlo"] == 4
    assert exported["added_kinds"][0]["kind"] == "Li"
    assert exported["added_kinds"][0]["neighbor_kinds"][0]["kind"] == "O"


def test_cli_add_sites_export_spec_json_stdout(tmp_path: Path, capsys):
    solver = _solver_text(tmp_path)

    rc = main(
        [
            "add-sites",
            "export-spec",
            "--solver-text",
            str(solver),
            "--format",
            "json",
        ]
    )

    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["present"] is True
    assert payload["add_meshes"] == [0.5, 0.5, 0.5]
    assert payload["added_kinds"][0]["n_added"] == 1


def test_cli_without_args_prints_help(capsys):
    rc = main([])
    assert rc == 0
    out = capsys.readouterr().out
    assert "usage: esspy" in out
    assert "stage" in out


def test_cli_invalid_args_prints_helpful_issue(tmp_path: Path, capsys):
    solver = _solver_text(tmp_path)

    with pytest.raises(SystemExit) as exc:
        main(["add-sites-run", "--solver-text", str(solver)])

    assert exc.value.code == 2
    err = capsys.readouterr().err
    assert "usage: esspy" in err
    assert "Argument issue:" in err


def test_cli_group_command_without_subcommand_prints_family_help(capsys):
    rc = main(["guide"])

    assert rc == 0
    out = capsys.readouterr().out
    assert "usage: esspy guide" in out
    assert "export-ready" in out


def test_cli_all_groups_without_subcommand_print_family_help(capsys):
    groups = ("guide", "solve", "symmetry", "add-sites", "convert", "util")

    for group in groups:
        rc = main([group])
        assert rc == 0
        out = capsys.readouterr().out
        assert f"usage: esspy {group}" in out
