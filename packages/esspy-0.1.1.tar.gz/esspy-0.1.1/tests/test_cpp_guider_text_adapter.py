from pathlib import Path

from esspy import (
    guider_text_to_run_input,
    parse_guider_text,
    parse_guider_text_file_native,
    parse_guider_text_to_guide_input_native,
    parse_guider_text_to_run_input_native,
)


def test_cpp_native_guider_text_parser_g001_matches_python_parser():
    python_spec = parse_guider_text("tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt")
    native = parse_guider_text_file_native(
        "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
    )

    assert native["n_target_sites"] == python_spec.n_target_sites
    assert native["number_fixed_at"] == python_spec.number_fixed_at
    assert native["target_fractions"]["Mn"] == python_spec.target_fractions["Mn"]
    assert native["ion_list"]["Ni"] == python_spec.charges["Ni"]
    assert native["recipe_lines"][0]["output_prefix"] == python_spec.output_prefix
    assert native["recipe_lines"][0]["declared_n_recipe"] == 2
    assert native["options"]["strict_no_added_sites"] is True


def test_cpp_native_guider_text_parser_preserves_raw_sections():
    native = parse_guider_text_file_native(
        "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt"
    )

    headers = [section["header"] for section in native["sections"]]
    assert "====IonList====" in headers
    assert "====InputFilename_Prefix_SapceGroup_Recipe_List====" in headers
    assert "=====SH_Header_forESS[ForJobTitle,Use\"(*Jobname*)\"]=====" in headers
    assert native["sh_header_for_ess"][0] == "#!/bin/sh"
    assert native["sh_header_for_vasp"][1] == "# VASP header placeholder"


def test_cpp_native_guider_text_normalizes_to_guide_input():
    guider_path = "tests/golden/fixtures/G001_CCS02/basic_properties_EwaldSolidSolutionGuider.txt"
    python_spec = parse_guider_text(guider_path)
    python_run_input = guider_text_to_run_input(python_spec, Path(guider_path).parent)
    native = parse_guider_text_to_guide_input_native(guider_path)

    assert native["structure"]["title"] == python_run_input.guide.structure.title
    assert native["structure"]["sites"][0]["kind"] == python_run_input.guide.structure.sites[0].kind
    assert native["composition"]["n_target_sites"] == python_run_input.guide.composition.n_target_sites
    assert native["composition"]["entries"][2]["count"] == python_run_input.guide.composition.entries[2].count
    assert native["charges"]["values"][2]["oxidation"] == python_run_input.guide.charges.values[2].oxidation
    assert native["recipes"][1]["from"] == python_run_input.guide.recipes[1].from_kind
    assert native["symmetry"]["space_group"] == python_run_input.guide.symmetry.space_group
    assert native["options"]["strict_no_added_sites"] is True


def test_cpp_native_guider_text_normalizes_to_run_input():
    guider_path = "tests/golden/fixtures/G002_CCS03/basic_properties_EwaldSolidSolutionGuider.txt"
    native = parse_guider_text_to_run_input_native(guider_path)

    assert "guide" in native
    assert native["guide"]["structure"]["title"] == "CCS03_formalcharge"
    assert native["guide"]["composition"]["number_fixed_at"] == "O"
    assert native["guide"]["recipes"][0]["to"] == ["Mn", "Cr", "Ni", "Rh"]
