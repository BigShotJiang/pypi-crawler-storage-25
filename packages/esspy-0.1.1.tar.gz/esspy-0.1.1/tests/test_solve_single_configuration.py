from pathlib import Path

from esspy import decode_candidate_assignment
from esspy.native import load_native_module
from tests.golden.ready_parser import parse_ready_file
from tests.golden.references import G003_M6O8_READY


def _ready_payload_from_fixture(path: Path) -> dict:
    ready = parse_ready_file(path)
    return {
        "lattice": {
            "a": (5.1772941, -0.00001875, 2.98909804),
            "b": (1.7257584, 4.88119953, 2.98909789),
            "c": (-0.00002168, -0.00001523, 5.97823435),
        },
        "atoms": [
            {
                "kind": atom.kind,
                "oxidation": atom.oxidation,
                "x": atom.x,
                "y": atom.y,
                "z": atom.z,
            }
            for atom in ready.atom_config
        ],
        "supercell_expansion": ready.supercell_expansion,
        "rg_find_factor": ready.rg_find_factor,
        "output_prefix": ready.output_prefix,
        "recipes": [
            {
                "from": recipe.kind,
                "oxidation": recipe.oxidation,
                "random_pickup": recipe.random_pickup,
                "random_pickup_trial": recipe.random_pickup_trial,
                "modifications": [
                    {
                        "to": mod.kind,
                        "oxidation": mod.oxidation,
                        "count": mod.count,
                    }
                    for mod in recipe.modifications
                ],
            }
            for recipe in ready.recipes
        ],
    }


def test_solve_reuses_shared_ewald_on_single_ready_fixture():
    native = load_native_module()
    result = native.solve(
        {
            "ready": _ready_payload_from_fixture(Path(G003_M6O8_READY)),
            "options": {"swap": False, "swap_loop_enabled": False},
            "runtime": {"world_size": 4, "rank": 1},
        }
    )

    summary = result["summary"]
    assert summary["global_count_total"] >= 1
    assert summary["global_e_min"] <= summary["global_e_max"]
    assert summary["global_e_min"] != 0.0
    assert result["best"]["energy"] == summary["global_e_min"]
    assert result["worst"]["energy"] == summary["global_e_max"]
    best_structure = result["best"]["structure"]
    assert best_structure is not None
    assert len(best_structure["sites"]) == 112
    counts = {}
    for site in best_structure["sites"]:
        counts[site["kind"]] = counts.get(site["kind"], 0) + 1
    assert counts == {"Mn": 16, "Cr": 32, "O": 64}
    search_space = result["search_space"]
    assert search_space["primary_recipe_index"] == 0
    assert len(search_space["entries"]) == 1
    entry = search_space["entries"][0]
    assert entry["from"] == "M"
    assert entry["random_pickup"] == 48
    assert entry["unchanged_count"] == 0
    assigned_counts = {item["kind"]: item["count"] for item in entry["assigned_counts"]}
    assert assigned_counts == {"Mn": 16, "Cr": 32}
    assert entry["jobsize_u64"] > 0
    assert len(entry["first_candidate_indices"]) == 48
    assert entry["first_candidate_indices"][:16] == [0] * 16
    assert entry["first_candidate_indices"][16:] == [1] * 32
    assert len(entry["first_candidate_labels"]) == 48
    assert entry["first_candidate_labels"][:16] == ["Mn"] * 16
    assert entry["first_candidate_labels"][16:] == ["Cr"] * 32
    assert entry["candidate_count_log10"] > 0.0
    work_slice = search_space["work_slice"]
    assert work_slice["primary_recipe_index"] == 0
    assert work_slice["world_size"] == 4
    assert work_slice["rank"] == 1

    assert len(work_slice["recipe_ranges"]) == 1
    recipe_range = work_slice["recipe_ranges"][0]
    assert recipe_range["recipe_index"] == 0
    assert recipe_range["start"] <= recipe_range["end"]
    assert recipe_range["end"] < entry["jobsize_u64"]
    first_enum = search_space["first_enumeration"]
    assert first_enum["recipe_index"] == 0
    assert first_enum["candidate_index"] == recipe_range["start"] + 1
    assert len(first_enum["candidate_indices"]) == 48
    assert len(first_enum["candidate_labels"]) == 48
    window = search_space["primary_slice_window"]
    assert window["recipe_index"] == 0
    assert window["start_index"] == recipe_range["start"] + 1
    assert window["end_index"] == recipe_range["end"] + 1
    assert window["available_count"] == recipe_range["end"] - recipe_range["start"] + 1
    assert window["decoded_count"] == len(window["candidates"])
    assert window["available_count"] >= window["decoded_count"]
    assert window["requested_offset"] == 0
    assert window["next_offset"] == window["decoded_count"]
    assert isinstance(window["has_more"], bool)
    assert 1 <= len(window["candidates"]) <= 32
    assert window["candidates"][0]["candidate_index"] == first_enum["candidate_index"]
    assert window["candidates"][0]["candidate_indices"] == first_enum["candidate_indices"]
    assert window["candidates"][0]["candidate_labels"] == first_enum["candidate_labels"]
    window_eval = result["window_evaluation"]
    assert window_eval["recipe_index"] == 0
    assert window_eval["local_count_total"] == len(window["candidates"])
    assert len(window_eval["entries"]) == len(window["candidates"])
    assert window_eval["local_best_candidate_index"] >= window["start_index"]
    assert window_eval["local_worst_candidate_index"] >= window["start_index"]
    assert window_eval["local_e_min"] <= window_eval["local_e_max"]
    assert summary["global_count_total"] == window_eval["local_count_total"]
    assert summary["global_e_min"] == window_eval["local_e_min"]
    assert summary["global_e_max"] == window_eval["local_e_max"]
    assert result["best"]["label"].endswith("::best")
    assert result["worst"]["label"].endswith("::worst")
    assert result["best"]["structure"] is not None
    assert result["worst"]["structure"] is not None
    assert len(window_eval["entries"][0]["snapshot"]["structure"]["sites"]) == 112
    assert window_eval["entries"][0]["snapshot"]["energy"] == window_eval["entries"][0]["energy"]
    assert any("shared-Ewald" in line for line in result["messages"])
    assert not any("stub reached" in line for line in result["messages"])

    decoded = decode_candidate_assignment(
        {
            "from": entry["from"],
            "oxidation": 0.0,
            "random_pickup": entry["random_pickup"],
            "random_pickup_trial": entry["random_pickup_trial"],
            "modifications": [
                {"to": "Mn", "oxidation": 2.0, "count": 16},
                {"to": "Cr", "oxidation": 3.0, "count": 32},
            ],
        },
        index=1,
    )
    assert decoded["indices"][:16] == [0] * 16
    assert decoded["indices"][16:] == [1] * 32
    assert decoded["labels"][:16] == ["Mn"] * 16
    assert decoded["labels"][16:] == ["Cr"] * 32


def test_solve_progress_callback_reports_chunks():
    native = load_native_module()
    events: list[dict] = []

    result = native.solve(
        {
            "ready": _ready_payload_from_fixture(Path(G003_M6O8_READY)),
            "options": {
                "local_enumeration_offset": 0,
                "local_enumeration_limit": 2,
                "local_enumeration_max_chunks": 2,
                "swap": False,
                "swap_loop_enabled": False,
                "progress_callback": events.append,
            },
        }
    )

    assert result["local_enumeration_loop"]["processed_chunks"] == 2
    chunk_events = [event for event in events if event["stage"] == "solve.chunk"]
    assert len(chunk_events) == 2
    assert chunk_events[-1]["processed_chunks"] == 2
    assert chunk_events[-1]["processed_candidates"] == result["local_enumeration_loop"]["processed_candidates"]
    assert chunk_events[-1]["next_offset"] == result["local_enumeration_loop"]["next_offset"]
    assert chunk_events[-1]["active_stride"] == 1


def test_solve_allows_segment_offset_iteration():
    native = load_native_module()
    ready = _ready_payload_from_fixture(Path(G003_M6O8_READY))
    base = native.solve({
        "ready": ready,
        "options": {"local_enumeration_limit": 3, "local_enumeration_offset": 0},
        "runtime": {"world_size": 4, "rank": 1},
    })
    shifted = native.solve({
        "ready": ready,
        "options": {"local_enumeration_limit": 3, "local_enumeration_offset": 2},
        "runtime": {"world_size": 4, "rank": 1},
    })

    base_window = base["search_space"]["primary_slice_window"]
    shifted_window = shifted["search_space"]["primary_slice_window"]
    assert base_window["decoded_count"] == 3
    assert shifted_window["decoded_count"] == 3
    assert shifted_window["requested_offset"] == 2
    assert shifted_window["start_index"] == base_window["start_index"] + 2
    assert shifted_window["next_offset"] == 5
    assert shifted_window["has_more"] is True
    assert shifted_window["candidates"][0]["candidate_index"] == base_window["candidates"][2]["candidate_index"]
    assert shifted_window["candidates"][0]["candidate_indices"] == base_window["candidates"][2]["candidate_indices"]
    assert shifted["window_evaluation"]["local_count_total"] == 3
    assert any("primary_slice_offset=2" in line for line in shifted["messages"])


def test_solve_reports_segment_completion_state():
    native = load_native_module()
    ready = _ready_payload_from_fixture(Path(G003_M6O8_READY))
    result = native.solve({
        "ready": ready,
        "options": {"local_enumeration_limit": 2, "local_enumeration_offset": 4},
        "runtime": {"world_size": 4, "rank": 1},
    })

    window = result["search_space"]["primary_slice_window"]
    assert window["requested_offset"] == 4
    assert window["decoded_count"] == 2
    assert window["next_offset"] == 6
    assert window["has_more"] is True
    assert any("primary_slice_next_offset=6" in line for line in result["messages"])
    assert any("primary_slice_has_more=true" in line for line in result["messages"])


def test_solve_accumulates_multiple_chunks_when_requested():
    native = load_native_module()
    ready = _ready_payload_from_fixture(Path(G003_M6O8_READY))
    result = native.solve({
        "ready": ready,
        "options": {
            "local_enumeration_limit": 2,
            "local_enumeration_offset": 1,
            "local_enumeration_max_chunks": 3,
        },
        "runtime": {"world_size": 4, "rank": 1},
    })

    loop = result["local_enumeration_loop"]
    reduction = result["local_reduction"]
    window = result["search_space"]["primary_slice_window"]
    assert loop["initial_offset"] == 1
    assert loop["chunk_limit"] == 2
    assert loop["max_chunks"] == 3
    assert loop["processed_chunks"] == 3
    assert loop["processed_candidates"] == 6
    assert loop["next_offset"] == 7
    assert loop["has_more"] is True
    assert reduction["rank"] == 1
    assert reduction["world_size"] == 4
    assert reduction["primary_recipe_index"] == 0
    assert reduction["processed_chunks"] == 3
    assert reduction["processed_candidates"] == 6
    assert reduction["initial_offset"] == 1
    assert reduction["next_offset"] == 7
    assert reduction["has_more"] is True
    assert reduction["has_samples"] is True
    assert window["requested_offset"] == 1
    assert window["decoded_count"] == 2
    assert result["window_evaluation"]["local_count_total"] == 6
    assert len(result["window_evaluation"]["entries"]) == 6
    assert any("local_chunks_processed=3" in line for line in result["messages"])
    assert any("local_candidates_processed=6" in line for line in result["messages"])
    assert any("local_loop_next_offset=7" in line for line in result["messages"])
    assert any("local_reduce_rank=1" in line for line in result["messages"])


def test_solve_can_exhaust_small_local_slice():
    native = load_native_module()
    tiny_ready = {
        "lattice": {
            "a": (1.0, 0.0, 0.0),
            "b": (0.0, 1.0, 0.0),
            "c": (0.0, 0.0, 1.0),
        },
        "atoms": [
            {"kind": "M", "oxidation": 0.0, "x": 0.0, "y": 0.0, "z": 0.0},
            {"kind": "M", "oxidation": 0.0, "x": 0.5, "y": 0.5, "z": 0.0},
            {"kind": "M", "oxidation": 0.0, "x": 0.5, "y": 0.0, "z": 0.5},
        ],
        "poscar_species_counts": [{"kind": "M", "count": 3}],
        "supercell_expansion": (1, 1, 1),
        "rg_find_factor": 1,
        "output_prefix": "tiny",
        "recipes": [
            {
                "from": "M",
                "oxidation": 0.0,
                "random_pickup": 3,
                "random_pickup_trial": 1,
                "modifications": [
                    {"to": "A", "oxidation": 0.0, "count": 1},
                    {"to": "B", "oxidation": 0.0, "count": 2},
                ],
            }
        ],
    }
    result = native.solve({
        "ready": tiny_ready,
        "options": {
            "local_enumeration_limit": 1,
            "local_enumeration_offset": 0,
            "local_enumeration_max_chunks": 1,
            "enumeration_exhaust_all": True,
        },
        "runtime": {"world_size": 1, "rank": 0},
    })

    loop = result["local_enumeration_loop"]
    reduction = result["local_reduction"]
    window = result["search_space"]["primary_slice_window"]
    assert window["available_count"] == 3
    assert loop["exhaust_all"] is True
    assert loop["processed_chunks"] == 3
    assert loop["processed_candidates"] == 3
    assert loop["next_offset"] == 3
    assert loop["has_more"] is False
    assert result["window_evaluation"]["local_count_total"] == 3
    assert len(result["window_evaluation"]["entries"]) == 3
    assert any("local_loop_exhaust_all=true" in line for line in result["messages"])
    assert any("local_loop_has_more=false" in line for line in result["messages"])


def test_positive_running_index_delta_drives_stride_sampling():
    native = load_native_module()
    ready = _ready_payload_from_fixture(Path(G003_M6O8_READY))
    result = native.solve({
        "ready": ready,
        "options": {
            "running_index_delta": 5,
            "local_enumeration_limit": 4,
            "local_enumeration_offset": 0,
            "local_enumeration_max_chunks": 1,
            "swap": False,
            "swap_loop_enabled": False,
        },
        "runtime": {"world_size": 4, "rank": 1},
    })

    candidates = result["search_space"]["primary_slice_window"]["candidates"]
    assert [entry["candidate_index"] for entry in candidates] == [
        candidates[0]["candidate_index"],
        candidates[0]["candidate_index"] + 5,
        candidates[0]["candidate_index"] + 10,
        candidates[0]["candidate_index"] + 15,
    ]
    assert result["local_enumeration_loop"]["processed_candidates"] == 4
    assert result["local_enumeration_loop"]["next_offset"] == 20


def test_huge_positive_running_index_delta_matches_legacy_long_long_stride():
    native = load_native_module()
    ready = _ready_payload_from_fixture(Path(G003_M6O8_READY))
    result = native.solve({
        "ready": ready,
        "options": {
            "running_index_delta": 3000000000,
            "local_enumeration_limit": 4,
            "local_enumeration_offset": 0,
            "local_enumeration_max_chunks": 1,
            "swap": False,
            "swap_loop_enabled": False,
        },
        "runtime": {"world_size": 1, "rank": 0},
    })

    candidates = result["search_space"]["primary_slice_window"]["candidates"]
    assert len(candidates) == 4
    assert candidates[1]["candidate_index"] - candidates[0]["candidate_index"] == 3000000000


def test_negative_running_index_delta_enables_legacy_adaptive_stride():
    native = load_native_module()
    ready = _ready_payload_from_fixture(Path(G003_M6O8_READY))
    result = native.solve({
        "ready": ready,
        "options": {
            "running_index_delta": -1,
            "running_index_monitor": 10000,
            "local_enumeration_limit": 4,
            "local_enumeration_offset": 0,
            "local_enumeration_max_chunks": 24,
            "swap": False,
            "swap_loop_enabled": False,
        },
        "runtime": {"world_size": 1, "rank": 0},
    })

    messages = result["messages"]
    loop = result["local_enumeration_loop"]
    assert loop["processed_candidates"] >= 20
    assert any("legacy_adaptive_running_index=true" in line for line in messages)
    assert any("adaptive_running_index_update monitoring=9" in line for line in messages)
    assert any("adaptive_running_index_update monitoring=19" in line for line in messages)


def test_negative_running_index_delta_ignores_explicit_fixed_stride():
    native = load_native_module()
    ready = _ready_payload_from_fixture(Path(G003_M6O8_READY))
    result = native.solve({
        "ready": ready,
        "options": {
            "running_index_delta": -1,
            "local_enumeration_stride": 999999,
            "local_enumeration_limit": 4,
            "local_enumeration_offset": 0,
            "local_enumeration_max_chunks": 1,
            "swap": False,
            "swap_loop_enabled": False,
        },
        "runtime": {"world_size": 1, "rank": 0},
    })

    messages = result["messages"]
    assert result["local_enumeration_loop"]["processed_candidates"] >= 20
    assert any("legacy_adaptive_running_index=true" in line for line in messages)
    assert any("adaptive_running_index_update monitoring=19" in line for line in messages)


def test_negative_running_index_delta_uses_nested_secondary_recipe_traversal():
    native = load_native_module()
    ready = {
        "lattice": {
            "a": (3.0, 0.0, 0.0),
            "b": (0.0, 3.0, 0.0),
            "c": (0.0, 0.0, 3.0),
        },
        "atoms": [
            {"kind": "A", "oxidation": 0.0, "x": 0.0, "y": 0.0, "z": 0.0},
            {"kind": "A", "oxidation": 0.0, "x": 0.5, "y": 0.0, "z": 0.0},
            {"kind": "B", "oxidation": 0.0, "x": 0.0, "y": 0.5, "z": 0.0},
            {"kind": "B", "oxidation": 0.0, "x": 0.0, "y": 0.0, "z": 0.5},
        ],
        "supercell_expansion": (1, 1, 1),
        "rg_find_factor": 1,
        "output_prefix": "nested_tiny",
        "recipes": [
            {
                "from": "A",
                "oxidation": 0.0,
                "random_pickup": 2,
                "random_pickup_trial": 1,
                "modifications": [{"to": "X", "oxidation": 1.0, "count": 1}],
            },
            {
                "from": "B",
                "oxidation": 0.0,
                "random_pickup": 2,
                "random_pickup_trial": 1,
                "modifications": [{"to": "Y", "oxidation": -1.0, "count": 1}],
            },
        ],
    }
    result = native.solve({
        "ready": ready,
        "options": {
            "running_index_delta": -1,
            "local_enumeration_limit": 1,
            "local_enumeration_offset": 0,
            "local_enumeration_max_chunks": 10,
            "swap": False,
            "swap_loop_enabled": False,
        },
        "runtime": {"world_size": 1, "rank": 0},
    })

    assert result["search_space"]["entries"][0]["jobsize_u64"] == 2
    assert result["search_space"]["entries"][1]["jobsize_u64"] == 2
    assert result["local_enumeration_loop"]["processed_candidates"] == 4
    assert result["window_evaluation"]["local_count_total"] == 4
