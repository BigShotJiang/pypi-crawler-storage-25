from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT / "fixtures"

G001_CCS02_READY = FIXTURES / "G001_CCS02" / "basic_properties_EwaldSolidSolution.ready.txt"
G001_CCS02_GUIDER = FIXTURES / "G001_CCS02" / "basic_properties_EwaldSolidSolutionGuider.txt"
G002_CCS03_READY = FIXTURES / "G002_CCS03" / "basic_properties_EwaldSolidSolution.ready.txt"
G002_CCS03_GUIDER = FIXTURES / "G002_CCS03" / "basic_properties_EwaldSolidSolutionGuider.txt"
G003_M6O8_READY = FIXTURES / "G003_M6O8" / "basic_properties_EwaldSolidSolution.ready.txt"
G003_M6O8_SOLVER_INPUT = FIXTURES / "G003_M6O8" / "basic_properties_EwaldSolidSolution.txt"
G003_M6O8_SOLVER_TRACE = FIXTURES / "G003_M6O8" / "M6O8_spinel_recovery_001.txt"
G004_CCS02_P1_ADDED_READY = FIXTURES / "G004_CCS02_P1_ADDED" / "basic_properties_EwaldSolidSolution.ready.txt"
G004_CCS02_P1_ADDED_GUIDER = FIXTURES / "G004_CCS02_P1_ADDED" / "basic_properties_EwaldSolidSolutionGuider.txt"
G004_CCS02_P1_ADDED_WYC = FIXTURES / "G004_CCS02_P1_ADDED" / "1.wyc"
G005_HIGHSYM_ADDED_POSCAR = FIXTURES / "G005_HIGHSYM_ADDED" / "POSCAR-MnCr2O4.vasp"
G005_HIGHSYM_ADDED_WYC = FIXTURES / "G005_HIGHSYM_ADDED" / "2.wyc"
G006_CCS02_RUNTIME_DERIVED_GUIDER = FIXTURES / "G006_CCS02_RUNTIME_DERIVED" / "basic_properties_EwaldSolidSolutionGuider.txt"
G006_CCS02_RUNTIME_DERIVED_READY = FIXTURES / "G006_CCS02_RUNTIME_DERIVED" / "basic_properties_EwaldSolidSolution.ready.txt"
G006_CCS02_RUNTIME_DERIVED_WYC = FIXTURES / "G006_CCS02_RUNTIME_DERIVED" / "1.wyc"
G006_CCS02_RUNTIME_DERIVED_OPER = FIXTURES / "G006_CCS02_RUNTIME_DERIVED" / "oper_ESS.sh"
