from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class SolverSummary:
    path: Path
    global_e_min: float
    global_e_max: float
    global_count_total: int
    total_cpu_time: float
    best_result_filename: str
    best_result_energy: float
    worst_result_filename: str
    worst_result_energy: float


def parse_solver_trace(path: str | Path) -> SolverSummary:
    path = Path(path)
    lines = [line.rstrip("\n") for line in path.read_text().splitlines()]

    best_result_filename = ""
    best_result_energy = 0.0
    worst_result_filename = ""
    worst_result_energy = 0.0
    global_e_min = 0.0
    global_e_max = 0.0
    global_count_total = 0
    total_cpu_time = 0.0

    for index, line in enumerate(lines):
        if line.startswith("=============================pick_recipe()============================="):
            first = lines[index + 1].split()
            second = lines[index + 2].split()
            best_result_filename = first[0]
            best_result_energy = float(first[1])
            worst_result_filename = second[0]
            worst_result_energy = float(second[1])
        elif line.startswith("global_e_min="):
            global_e_min = float(line.split()[-1])
        elif line.startswith("global_e_max="):
            global_e_max = float(line.split()[-1])
        elif line.startswith("global_count_total="):
            global_count_total = int(line.split()[-1])
        elif line.startswith("total_CPU_time="):
            total_cpu_time = float(line.split()[-1])

    return SolverSummary(
        path=path,
        global_e_min=global_e_min,
        global_e_max=global_e_max,
        global_count_total=global_count_total,
        total_cpu_time=total_cpu_time,
        best_result_filename=best_result_filename,
        best_result_energy=best_result_energy,
        worst_result_filename=worst_result_filename,
        worst_result_energy=worst_result_energy,
    )

