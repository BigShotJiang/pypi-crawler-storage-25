# Golden Fixtures

This directory contains frozen reference assets copied from known-good runs in the main workspace.

## Frozen Cases

- `G001_CCS02`
  - source: `ess_guider_python_api_design/examples/CCS02_allocation/run/CCS02_allocation/basic_properties_EwaldSolidSolution.ready.txt`
  - purpose: CCS02 mixed-site allocation semantics
  - companion: `basic_properties_EwaldSolidSolutionGuider.txt`

- `G002_CCS03`
  - source: `ess_guider_python_api_design/examples/CCS03_formalcharge/run/CCS03_formalcharge/basic_properties_EwaldSolidSolution.ready.txt`
  - purpose: CCS03 formal-charge propagation semantics
  - companion: `basic_properties_EwaldSolidSolutionGuider.txt`

- `G003_M6O8`
  - source: `sanity_m6o8_spinel_recovery/01-PURE/M6O8_spinel_recovery/basic_properties_EwaldSolidSolution.ready.txt`
  - purpose: pure spinel recovery ready-file semantics
  - companions: `basic_properties_EwaldSolidSolution.txt`, `M6O8_spinel_recovery_001.txt`

- `G004_CCS02_P1_ADDED`
  - source: `MAIN-CCS1_to_CCS5_validation/04-ESS-formalcharge/CCS02/ESS/CCS02_formalcharge_MnCr2O4/basic_properties_EwaldSolidSolution.ready.txt`
  - purpose: real added-site / `vac` recipe path with `1.wyc`
  - companions: `basic_properties_EwaldSolidSolutionGuider.txt`, `1.wyc`

## Policy

- these files are treated as frozen test assets
- updates require a documented reason and corresponding reference-run note
- semantic tests should parse these fixtures instead of re-reading mutable external outputs
