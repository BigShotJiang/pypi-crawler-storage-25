#!/bin/sh
# CCS02 formal-charge ESS preparation

WhichESS=/Users/bama/Dropbox/data/code/EwaldSolidSolution/AI-analysis/EwaldSolidSolution.x
WhichEwald2VASP=none

cp basic_properties_EwaldSolidSolution.ready.txt basic_properties_EwaldSolidSolution.txt
mpirun $WhichESS