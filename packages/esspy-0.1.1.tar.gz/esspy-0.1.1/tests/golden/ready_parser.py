from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AtomConfigEntry:
    kind: str
    oxidation: float
    x: float
    y: float
    z: float


@dataclass(frozen=True)
class RecipeModification:
    kind: str
    oxidation: float
    count: int


@dataclass(frozen=True)
class RecipeEntry:
    kind: str
    oxidation: float
    random_pickup: int
    random_pickup_trial: int
    modifications: tuple[RecipeModification, ...]


@dataclass(frozen=True)
class ReadyFile:
    path: Path
    n_atom_config: int
    atom_config: tuple[AtomConfigEntry, ...]
    supercell_expansion: tuple[int, int, int]
    chop_level: int
    rg_find_factor: int
    output_prefix: str
    n_recipe: int
    recipes: tuple[RecipeEntry, ...]


def _parse_atom_line(line: str) -> AtomConfigEntry:
    kind, oxidation, x, y, z = line.split()
    return AtomConfigEntry(kind, float(oxidation), float(x), float(y), float(z))


def _parse_recipe_line(line: str) -> RecipeEntry:
    parts = line.split()
    if len(parts) < 4:
        raise ValueError(f"Malformed recipe line: {line}")
    kind = parts[0]
    oxidation = float(parts[1])
    random_pickup = int(parts[2])
    random_pickup_trial = int(parts[3])
    modifications: list[RecipeModification] = []
    for index in range(4, len(parts), 3):
        mod_kind = parts[index]
        mod_oxidation = float(parts[index + 1])
        mod_count = int(parts[index + 2])
        modifications.append(RecipeModification(mod_kind, mod_oxidation, mod_count))
    return RecipeEntry(kind, oxidation, random_pickup, random_pickup_trial, tuple(modifications))


def parse_ready_file(path: str | Path) -> ReadyFile:
    path = Path(path)
    lines = [line.strip() for line in path.read_text().splitlines() if line.strip()]

    n_atom_config = 0
    atom_config: list[AtomConfigEntry] = []
    supercell_expansion = (1, 1, 1)
    chop_level = 0
    rg_find_factor = 0
    output_prefix = ""
    n_recipe = 0
    recipes: list[RecipeEntry] = []

    index = 0
    while index < len(lines):
        line = lines[index]
        if line.startswith("NAtomConfig "):
            n_atom_config = int(line.split()[1])
            if lines[index + 1] != "AtomConfig":
                raise ValueError(f"Expected AtomConfig block after NAtomConfig in {path}")
            for offset in range(n_atom_config):
                atom_config.append(_parse_atom_line(lines[index + 2 + offset]))
            index = index + 2 + n_atom_config
            continue
        if line.startswith("SupercellExpansion "):
            _, a, b, c = line.split()
            supercell_expansion = (int(a), int(b), int(c))
        elif line.startswith("ChopLevel "):
            chop_level = int(line.split()[1])
        elif line.startswith("RGFindFactor "):
            rg_find_factor = int(line.split()[1])
        elif line.startswith("OutputPrefix "):
            output_prefix = line.split(maxsplit=1)[1]
        elif line.startswith("NRecipe "):
            n_recipe = int(line.split()[1])
            recipe_header = 'kind=oxidation=random_pickup=random_pickup_trial=[[[to_which(kind;"vac"->delete)=to_which(oxidation)=to_which(number)]]]'
            search_index = index + 1
            while search_index < len(lines) and lines[search_index] != recipe_header:
                search_index += 1
            if search_index == len(lines):
                raise ValueError(f"Could not find recipe header in {path}")
            recipe_start = search_index + 2
            for recipe_offset in range(n_recipe):
                recipes.append(_parse_recipe_line(lines[recipe_start + recipe_offset]))
            index = recipe_start + n_recipe
            continue
        index += 1

    return ReadyFile(
        path=path,
        n_atom_config=n_atom_config,
        atom_config=tuple(atom_config),
        supercell_expansion=supercell_expansion,
        chop_level=chop_level,
        rg_find_factor=rg_find_factor,
        output_prefix=output_prefix,
        n_recipe=n_recipe,
        recipes=tuple(recipes),
    )
