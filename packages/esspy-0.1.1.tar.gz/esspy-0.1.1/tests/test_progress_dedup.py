from __future__ import annotations

from pathlib import Path

from esspy.models import LoggingOptions
from esspy.progress import ProgressReporter


def test_progress_reporter_dedupes_identical_solve_chunk_events(tmp_path: Path):
    reporter = ProgressReporter(
        workdir=tmp_path,
        options=LoggingOptions(console=False, file=False, progress_jsonl=True, interval_sec=100.0),
        rank=0,
        world_size=1,
    )
    reporter.emit(
        "solve.chunk",
        processed_candidates=100,
        available_count=10000,
        local_e_min=-1.0,
    )
    reporter.emit(
        "solve.chunk",
        processed_candidates=100,
        available_count=10000,
        local_e_min=-1.0,
    )
    reporter.emit(
        "solve.chunk",
        processed_candidates=120,
        available_count=10000,
        local_e_min=-1.0,
    )
    lines = (tmp_path / "logs" / "progress.jsonl").read_text().strip().splitlines()
    assert len(lines) == 2
