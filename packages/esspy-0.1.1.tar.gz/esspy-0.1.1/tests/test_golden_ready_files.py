from tests.golden.ready_parser import parse_ready_file
from tests.golden.references import G001_CCS02_READY, G002_CCS03_READY, G003_M6O8_READY


def _recipe_map(ready):
    return {recipe.kind: recipe for recipe in ready.recipes}


def test_g001_ccs02_ready_semantics():
    ready = parse_ready_file(G001_CCS02_READY)

    assert ready.n_atom_config == 14
    assert ready.supercell_expansion == (2, 2, 2)
    assert ready.rg_find_factor == 1
    assert ready.output_prefix == "CCS02_allocation_001"
    assert ready.n_recipe == 2

    recipe_map = _recipe_map(ready)
    mn_recipe = recipe_map["Mn"]
    cr_recipe = recipe_map["Cr"]

    assert mn_recipe.random_pickup == 16
    assert mn_recipe.random_pickup_trial == 1
    assert tuple((mod.kind, mod.count) for mod in mn_recipe.modifications) == (("Ni", 2),)

    assert cr_recipe.random_pickup == 32
    assert cr_recipe.random_pickup_trial == 1
    assert tuple((mod.kind, mod.count) for mod in cr_recipe.modifications) == (("Ni", 17),)


def test_g002_ccs03_ready_semantics():
    ready = parse_ready_file(G002_CCS03_READY)

    assert ready.n_atom_config == 112
    assert ready.supercell_expansion == (1, 1, 1)
    assert ready.rg_find_factor == 1
    assert ready.n_recipe >= 1
    assert ready.atom_config[0].kind == "M"
    assert round(ready.atom_config[-1].oxidation, 3) == -1.105


def test_g003_m6o8_ready_semantics():
    ready = parse_ready_file(G003_M6O8_READY)

    assert ready.n_atom_config == 14
    assert ready.supercell_expansion == (2, 2, 2)
    assert ready.output_prefix == "M6O8_spinel_recovery_001"
    assert ready.n_recipe == 1

    recipe = ready.recipes[0]
    assert recipe.kind == "M"
    assert recipe.random_pickup == 48
    assert tuple((mod.kind, mod.count) for mod in recipe.modifications) == (
        ("Mn", 16),
        ("Cr", 32),
    )
