import streamlit as st
import os
import sys
import os

sys.path.append("src")

from parser import extract_functions
from generator import generate_tests


st.title("Unit Test Auto Generator")

uploaded_file = st.file_uploader("Upload Python file", type=["py"])

if uploaded_file is not None:

    file_path = "temp.py"

    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    functions = extract_functions(file_path)

    st.subheader("Detected Functions")
    for name, params in functions:
        st.write(f"{name}({', '.join(params)})")

    tests = generate_tests(functions)

    os.makedirs("generated_tests", exist_ok=True)

    output_file = "generated_tests/test_main.py"

    with open(output_file, "w") as f:
        f.write("from temp import *\n")
        f.write(tests)

    st.success("Test cases generated!")

    with open(output_file, "r") as f:
        st.code(f.read(), language="python")