import re

def extract_functions(file_path):

    with open(file_path, "r") as file:
        code = file.read()

    pattern = r"def\s+(\w+)\((.*?)\):"

    matches = re.findall(pattern, code)

    functions = []

    for name, params in matches:
        param_list = [p.strip() for p in params.split(",") if p.strip()]
        functions.append((name, param_list))

    return functions