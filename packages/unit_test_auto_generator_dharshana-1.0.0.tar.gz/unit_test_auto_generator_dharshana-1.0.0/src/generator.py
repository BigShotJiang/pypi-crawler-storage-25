def generate_tests(functions):

    tests = ""

    for name, params in functions:

        args_normal = ",".join(["2"] * len(params))
        args_zero = ",".join(["0"] * len(params))
        args_negative = ",".join(["-2"] * len(params))
        args_large = ",".join(["100000"] * len(params))
        args_none = ",".join(["None"] * len(params))

        tests += f"""

def test_{name}_normal():
    result = {name}({args_normal})
    assert result is not None

def test_{name}_zero():
    result = {name}({args_zero})
    assert result is not None

def test_{name}_negative():
    result = {name}({args_negative})
    assert result is not None

def test_{name}_large():
    result = {name}({args_large})
    assert result is not None

def test_{name}_null():
    try:
        {name}({args_none})
    except:
        pass

"""

    return tests