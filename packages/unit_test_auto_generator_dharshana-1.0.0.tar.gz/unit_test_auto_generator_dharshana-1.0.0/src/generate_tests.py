#!/usr/bin/env python
import sys
import os
from src.parser import extract_functions
from src.generator import generate_tests

def main():

    file_path = sys.argv[1]

    functions = extract_functions(file_path)

    print("Detected functions:")
    for name, params in functions:
        print(f"- {name}({', '.join(params)})")

    tests = generate_tests(functions)

    os.makedirs("../generated_tests", exist_ok=True)

    output_file = "../generated_tests/test_main.py"

    with open(output_file, "w") as f:
        f.write("from examples.sample_code import *\n")
        f.write(tests)

    print("\nAnalysis Summary")
    print("-----------------")
    print(f"Functions detected: {len(functions)}")

    for name, params in functions:
        print(f"{name} -> parameters: {len(params)}")

    print("\nEdge cases generated per function:")
    print("1. Normal input")
    print("2. Zero values")
    print("3. Negative values")
    print("4. Large numbers")
    print("5. Null values")

    print("\nTest file generated successfully!")

if __name__ == "__main__":
    main()