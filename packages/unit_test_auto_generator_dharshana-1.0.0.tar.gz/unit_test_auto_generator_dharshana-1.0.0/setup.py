from setuptools import setup, find_packages

setup(
    name="unit-test-auto-generator-dharshana",  # must be UNIQUE
    version="1.0.0",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'generate-tests=src.generate_tests:main',
        ],
    },
)