def main():
    print("Hello from targs!")


if __name__ == "__main__":
    main()
