"""Worker source assets."""
