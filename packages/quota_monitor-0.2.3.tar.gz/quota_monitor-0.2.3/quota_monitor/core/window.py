from dataclasses import dataclass
from typing import Optional

from .state import State
from ..probes import ProbeResult

WINDOW_SECONDS = 5 * 3600
# Local logs consistently lag ~5 min behind the official window start.
RESET_CORRECTION_SECONDS = -5 * 60
# How long after a reset we still fire the "quota recovered" alert. Matches
# probes.hud_adapters.RESET_GRACE_SECONDS so the precise-data feed and the
# alert decision use the same grace. Set conservatively: caches in the chain
# only refresh on user activity, and the user is usually idle around reset
# (waiting for quota), so cache freshness can lag 20-30 min.
RESET_GRACE_SECONDS = 30 * 60


@dataclass(frozen=True)
class LatestWindow:
    start: float
    reset: float
    count: int


@dataclass(frozen=True)
class AlertDecision:
    source: str       # "claude" | "codex"
    reset_at: int     # epoch seconds


def replay_windows(
    timestamps: tuple[float, ...],
    correction: Optional[float] = None,
) -> Optional[LatestWindow]:
    """Full Replay: scan all timestamps left-to-right, opening a new 5h window
    every time `ts >= current_reset`. Returns the LATEST window after replay,
    or None if there are no timestamps.

    State JSON intentionally does NOT feed in here. The original QuotaMonitor
    used a saved `last_reset_time` to filter history; when that saved value
    drifted into the future, every historical timestamp was filtered out and
    alerts silently stopped. Full Replay makes that failure mode structurally
    impossible.

    The correction parameter adjusts computed reset time to account for
    consistent drift between local log timestamps and the actual server window.
    """
    if not timestamps:
        return None
    actual_correction = correction if correction is not None else RESET_CORRECTION_SECONDS
    sorted_ts = sorted(timestamps)
    start = sorted_ts[0]
    reset = start + WINDOW_SECONDS
    count = 1
    for ts in sorted_ts[1:]:
        if ts >= reset:
            start = ts
            reset = ts + WINDOW_SECONDS
            count = 1
        else:
            count += 1
    return LatestWindow(start=start, reset=reset + actual_correction, count=count)


def window_from_known_reset(timestamps: tuple[float, ...], *, reset_at: float) -> Optional[LatestWindow]:
    """Build the known official 5h window from a precise reset timestamp.

    This is intentionally not a replacement for precise data. It is a fallback
    anchor for periods where precise data was recently known, then temporarily
    unavailable. The reset timestamp is already official, so no local-log
    correction is applied.
    """
    start = reset_at - WINDOW_SECONDS
    count = sum(1 for ts in timestamps if start <= ts < reset_at)
    if count == 0:
        return None
    return LatestWindow(start=start, reset=reset_at, count=count)


def decide_alerts(
    *,
    state: State,
    claude_window: Optional[LatestWindow],
    codex: Optional[ProbeResult],
    now: float,
    claude_threshold: int,
    codex_threshold_percent: int,
) -> list[AlertDecision]:
    decisions: list[AlertDecision] = []

    if claude_window is not None:
        # "Recovered" notification model: fire AT the reset moment (or shortly
        # after), not before. Matches the alert message wording. The window
        # was the one that just expired — its `count` describes the usage
        # that triggered the recovery worth notifying about.
        reset_at = int(claude_window.reset)
        age_after_reset = now - claude_window.reset
        if (
            claude_window.count >= claude_threshold
            and 0 <= age_after_reset <= RESET_GRACE_SECONDS
            and state.claude.cooldown_until <= now
            and state.claude.alerted_for_reset != reset_at
        ):
            decisions.append(AlertDecision(source="claude", reset_at=reset_at))

    if codex is not None:
        used_percent = int(codex.extra.get("used_percent", 0) or 0)
        reset_at = codex.extra.get("reset_at")
        if (
            reset_at is not None
            and used_percent >= codex_threshold_percent
            and state.codex.cooldown_until <= now
            and state.codex.alerted_for_reset != int(reset_at)
        ):
            decisions.append(AlertDecision(source="codex", reset_at=int(reset_at)))

    return decisions
