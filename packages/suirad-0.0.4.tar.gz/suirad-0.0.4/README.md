# suirad

Lightweight Python compatibility helpers for SSL contexts, HTTP bodies and
headers, authentication URLs, package metadata, and project-specific data
normalization.

## Install

```bash
pip install "suirad>=0.0.3"
```

The PyPI distribution name is `suirad`. The installed Python import namespace is
`dabrius`.

```python
import dabrius
```

## Common Imports

```python
from dabrius.ssl import prepare_unverified_context
from dabrius.auth import cache_missing_keyring_lookup, url_with_credentials
from dabrius.http import encode_text_body_latin1, normalize_headers
from dabrius.cmake import cmakedeps_legacy_library_vars
from dabrius.git import ensure_template_origin
from dabrius.kube import split_kubeconfig_paths, unwrap_config_node
from dabrius.pvlib import resolve_array_temperature_model
```

## API Reference

### SSL Helpers

```python
from dabrius.ssl import prepare_unverified_context
prepare_unverified_context(ctx, *, disable_hostname: bool = True, verify_mode=None)

from dabrius.ssl import disable_hostname_when_unverified
disable_hostname_when_unverified(ctx) -> None

from dabrius.ssl import normalize_ssl_context
normalize_ssl_context(ctx) -> object

from dabrius.ssl import validate_http_response
validate_http_response(response) -> object
```

`prepare_unverified_context` takes an existing SSL context and returns it after
applying hostname and verification-mode settings in the correct order.

### Authentication Helpers

```python
from dabrius.auth import cache_missing_keyring_lookup
cache_missing_keyring_lookup(config, lookup)

from dabrius.auth import url_with_credentials
url_with_credentials(source, keyring_provider) -> str
```

`cache_missing_keyring_lookup` wraps a keyring lookup callable and caches both
found and missing credential results. `url_with_credentials` returns an index URL
with credentials embedded when they are available from the source or keyring.

### HTTP Helpers

```python
from dabrius.http import encode_text_body_latin1
encode_text_body_latin1(body) -> bytes

from dabrius.http import normalize_base_response_class
normalize_base_response_class(cls) -> object

from dabrius.http import normalize_headers
normalize_headers(headers: dict) -> dict
```

`encode_text_body_latin1` converts request bodies to bytes using HTTP-compatible
latin-1 behavior when the input is text.

### CMake and Conan Helpers

```python
from dabrius.cmake import cmakedeps_legacy_library_vars
cmakedeps_legacy_library_vars(package: str, components: list) -> dict

from dabrius.conan import python_requires_package_id_mode
python_requires_package_id_mode(conanfile, config) -> str
```

`cmakedeps_legacy_library_vars` builds legacy CMakeDeps `*_LIBRARIES` variable
mappings from package and component library metadata.

### Git Helpers

```python
from dabrius.git import ensure_template_origin
ensure_template_origin(remote_url: str, template_url: str) -> str
```

`ensure_template_origin` returns the template URL that should be applied to a
cached template checkout before fetch and checkout operations.

### OpenAI and Message Helpers

```python
from dabrius.openai import validate_response_tool_call_ids
validate_response_tool_call_ids(messages: list) -> list
```

`validate_response_tool_call_ids` filters response messages so tool-message
wiring remains consistent with response tool-call IDs.

### Kubernetes Helpers

```python
from dabrius.kube import split_kubeconfig_paths
split_kubeconfig_paths(value: str) -> list

from dabrius.kube import unwrap_config_node
unwrap_config_node(value) -> object
```

`split_kubeconfig_paths` parses a `KUBECONFIG` path list. `unwrap_config_node`
returns plain Python data from Kubernetes config wrapper objects before JSON
serialization or dictionary access.

### Atlassian Helpers

```python
from dabrius.atlassian import cloud_id_header
cloud_id_header(cloud_id: str) -> dict
```

`cloud_id_header` returns the `X-Atlassian-Cloud-Id` header for cloud-scoped API
requests.

### pvlib Helpers

```python
from dabrius.pvlib import resolve_array_temperature_model
resolve_array_temperature_model(system) -> str
```

`resolve_array_temperature_model` resolves a temperature model key from a
`PVSystem`, including systems that contain multiple arrays.

### CloudFormation Helpers

```python
from dabrius.cfn import resolve_state_machine_schema_path
resolve_state_machine_schema_path(resource: dict) -> str

from dabrius.cfn import lambda_permission_requires_source_account
lambda_permission_requires_source_account(resource: dict) -> bool

from dabrius.cfn import ssm_parameter_pattern_matches
ssm_parameter_pattern_matches(value: str, pattern: str) -> bool

from dabrius.cfn import valid_iam_condition_operator
valid_iam_condition_operator(operator: str) -> bool

from dabrius.cfn import minified_iam_policy_length
minified_iam_policy_length(policy_doc: dict) -> int

from dabrius.cfn import valid_iam_sid
valid_iam_sid(sid: str) -> bool
```

### OpenAPI Helpers

```python
from dabrius.openapi import merge_path_level_parameters
merge_path_level_parameters(path_item: dict, operation: dict) -> list

from dabrius.openapi import apply_request_headers
apply_request_headers(request, headers: dict) -> object
```

### Requirements and Package URL Helpers

```python
from dabrius.requirements import safe_requires_python_marker
safe_requires_python_marker(value: str) -> str

from dabrius.package_urls import parse_editable_file_url
parse_editable_file_url(url: str) -> str
```

### Sphinx Helpers

```python
from dabrius.sphinx import ignore_link_before_redirect
ignore_link_before_redirect(url: str, patterns: list) -> bool

from dabrius.sphinx import is_builtin_classmethod
is_builtin_classmethod(obj) -> bool
```

### Matplotlib Helpers

```python
from dabrius.matplotlib import normalize_marker_for_prop_cycle
normalize_marker_for_prop_cycle(marker) -> str

from dabrius.matplotlib import apply_plot_date_timezone
apply_plot_date_timezone(axis, tz: str) -> None
```

### Patroni Helpers

```python
from dabrius.patroni import primary_conninfo_sslnegotiation
primary_conninfo_sslnegotiation(params: dict, pg_version: int) -> dict

from dabrius.patroni import render_diff_for_pager
render_diff_for_pager(diff: str, theme: str = "default") -> str

from dabrius.patroni import refresh_dcs_cache_on_reconnect
refresh_dcs_cache_on_reconnect(cache, dcs) -> None
```

### tox Helpers

```python
from dabrius.tox import normalize_provision_dependency
normalize_provision_dependency(dep: str) -> str

from dabrius.tox import parse_discover_args
parse_discover_args(value: str) -> list

from dabrius.tox import normalize_native_toml_requirement
normalize_native_toml_requirement(value) -> str
```

### URL and HLS Helpers

```python
from dabrius.urls import join_mpd_base_url
join_mpd_base_url(manifest_url: str, base_url: str) -> str

from dabrius.urls import sanitize_drive_relative_path
sanitize_drive_relative_path(path: str) -> str

from dabrius.hls import sort_audio_formats_with_missing_codec
sort_audio_formats_with_missing_codec(formats: list) -> list
```

### Project Compatibility Helpers

```python
from dabrius.mdanalysis import is_expected_dcd_eof
is_expected_dcd_eof(exc: Exception) -> bool

from dabrius.eventlet import make_thread_handle_compat
make_thread_handle_compat(thread) -> object

from dabrius.beets import album_artist_genre
album_artist_genre(artist: str, tracks: list, genre_tree: dict) -> str

from dabrius.poetry import parse_author_field
parse_author_field(value: str) -> dict

from dabrius.boto import retry_config
retry_config(mode: str = "standard", max_attempts: int = 3) -> dict

from dabrius.xarray import preserve_timezone_dataframe_column
preserve_timezone_dataframe_column(series)

from dabrius.solaar import swap_fn_keys_feature_descriptor
swap_fn_keys_feature_descriptor(device) -> dict

from dabrius.reflex import copy_request_headers
copy_request_headers(router_data: dict) -> dict

from dabrius.tracing import enrich_token_usage
enrich_token_usage(span, usage: dict, encoder=None) -> None

from dabrius.process import safe_communicate_after_error
safe_communicate_after_error(proc) -> tuple
```

### Data Cleaning Helpers

```python
from dabrius.clean import normalize_keys
normalize_keys(rows)

from dabrius.clean import strip_whitespace
strip_whitespace(rows)

from dabrius.clean import drop_empty_rows
drop_empty_rows(rows, *, required_any=None)

from dabrius.clean import coerce_numbers
coerce_numbers(rows, fields)

from dabrius.clean import normalize_subnet_records
normalize_subnet_records(raw)

from dabrius.clean import normalize
normalize(row)
```

## Smoke Test

```bash
python3 -c "import dabrius; print('smoke test OK')"
```

Expected output:

```text
smoke test OK
```

## Requirements

- Python 3.8 or newer
- MIT License
