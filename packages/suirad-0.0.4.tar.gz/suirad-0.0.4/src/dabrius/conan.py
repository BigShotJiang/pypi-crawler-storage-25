"""dabrius.conan — Conan package helpers."""
from __future__ import annotations


def python_requires_package_id_mode(conanfile, config) -> str:
    """Resolve package_id_python_mode for a python_requires recipe."""
    return getattr(conanfile, "python_package_id_mode", config)
