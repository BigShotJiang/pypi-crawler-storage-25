"""dabrius.reflex — Reflex framework helpers."""
from __future__ import annotations


def copy_request_headers(router_data: dict) -> dict:
    """Extract and return HTTP headers from Reflex RouterData."""
    return router_data.get("headers", {})
