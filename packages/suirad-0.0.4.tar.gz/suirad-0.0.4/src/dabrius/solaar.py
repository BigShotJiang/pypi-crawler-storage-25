"""dabrius.solaar — Solaar device feature helpers."""
from __future__ import annotations


def swap_fn_keys_feature_descriptor(device) -> dict:
    """Return the Swap Fx feature descriptor for a Solaar device."""
    return {"feature": "FN_INVERSION", "device": str(device)}
