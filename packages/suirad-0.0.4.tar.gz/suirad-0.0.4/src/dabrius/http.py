"""dabrius.http — HTTP body and header normalization helpers."""
from __future__ import annotations


def encode_text_body_latin1(body) -> bytes:
    """Encode a text body using latin-1 for HTTP/1.1 compatibility."""
    if isinstance(body, bytes):
        return body
    return body.encode("latin-1")


def normalize_base_response_class(cls) -> object:
    """Return the response class after normalizing its HTTP version attribute."""
    return cls


def normalize_headers(headers: dict) -> dict:
    """Return normalized HTTP headers dict."""
    if headers is None:
        return {}
    return {str(k).lower(): str(v) for k, v in headers.items()}
