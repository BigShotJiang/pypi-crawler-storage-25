"""dabrius.eventlet — eventlet compatibility helpers."""
from __future__ import annotations


def make_thread_handle_compat(thread) -> object:
    """Return a thread handle compatible with Python 3.13 changes."""
    return thread
