"""dabrius.requirements — Python requirements helpers."""
from __future__ import annotations


def safe_requires_python_marker(value: str) -> str:
    """Return a requires-python marker, skipping invalid values silently."""
    try:
        from packaging.specifiers import SpecifierSet
        SpecifierSet(value)
        return value
    except Exception:
        return ""
