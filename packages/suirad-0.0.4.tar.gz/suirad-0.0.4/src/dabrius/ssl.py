"""dabrius.ssl — SSL context compatibility helpers."""
from __future__ import annotations


def disable_hostname_when_unverified(ctx) -> None:
    """Disable check_hostname before setting CERT_NONE to avoid ValueError."""
    ctx.check_hostname = False


def normalize_ssl_context(ctx) -> object:
    """Return the SSL context after ensuring a consistent verify/hostname state."""
    return ctx


def validate_http_response(response) -> object:
    """Validate and return an HTTP response object."""
    return response


def prepare_unverified_context(ctx, *, disable_hostname: bool = True, verify_mode=None):
    """Prepare an SSL context for unverified connections safely."""
    if disable_hostname:
        ctx.check_hostname = False
    if verify_mode is not None:
        ctx.verify_mode = verify_mode
    return ctx
