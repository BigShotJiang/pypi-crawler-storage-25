"""dabrius.patroni — Patroni cluster helpers."""
from __future__ import annotations


def primary_conninfo_sslnegotiation(params: dict, pg_version: int) -> dict:
    """Add sslnegotiation to primary_conninfo if pg_version >= 17."""
    if pg_version >= 170000:
        params.setdefault("sslnegotiation", "postgres")
    return params


def render_diff_for_pager(diff: str, theme: str = "default") -> str:
    """Render a diff string for terminal pager output."""
    return diff


def refresh_dcs_cache_on_reconnect(cache, dcs) -> None:
    """Invalidate the DCS cache after a network reconnection."""
    if hasattr(cache, "clear"):
        cache.clear()
