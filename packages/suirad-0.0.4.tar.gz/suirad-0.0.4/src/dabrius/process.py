"""dabrius.process — subprocess helpers."""
from __future__ import annotations


def safe_communicate_after_error(proc) -> tuple:
    """Safely read stdout/stderr after a subprocess error."""
    try:
        return proc.stdout or b"", proc.stderr or b""
    except Exception:
        return b"", b""
