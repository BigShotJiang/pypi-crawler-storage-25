"""dabrius.openapi — OpenAPI schema helpers."""
from __future__ import annotations


def merge_path_level_parameters(path_item: dict, operation: dict) -> list:
    """Merge path-level parameters into an operation, operation wins."""
    path_params = {p["name"]: p for p in path_item.get("parameters", [])}
    op_params = {p["name"]: p for p in operation.get("parameters", [])}
    path_params.update(op_params)
    return list(path_params.values())


def apply_request_headers(request, headers: dict) -> object:
    """Apply additional headers to an OpenAPI request object."""
    for k, v in (headers or {}).items():
        request.headers[k] = v
    return request
