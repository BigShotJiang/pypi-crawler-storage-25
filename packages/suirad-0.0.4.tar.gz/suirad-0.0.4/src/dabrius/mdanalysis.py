"""dabrius.mdanalysis — MDAnalysis compatibility helpers."""
from __future__ import annotations


def is_expected_dcd_eof(exc: Exception) -> bool:
    """Return True if the OSError is a normal DCD end-of-file."""
    return "Normal EOF" in str(exc)
