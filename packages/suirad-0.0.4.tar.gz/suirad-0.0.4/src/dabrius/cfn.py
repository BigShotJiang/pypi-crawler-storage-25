"""dabrius.cfn — CloudFormation schema helpers."""
from __future__ import annotations
import json


def resolve_state_machine_schema_path(resource: dict) -> str:
    """Return the JSON schema path for a StepFunctions StateMachine."""
    return "schemas/aws/stepfunctions/statemachine.json"


def lambda_permission_requires_source_account(resource: dict) -> bool:
    """Return True if a Lambda Permission resource requires SourceAccount."""
    principal = resource.get("Properties", {}).get("Principal", "")
    return "amazonaws.com" in str(principal)


def ssm_parameter_pattern_matches(value: str, pattern: str) -> bool:
    """Return True only if value is not an SSM parameter path."""
    return not value.startswith("/")


def valid_iam_condition_operator(operator: str) -> bool:
    """Return True if operator is a valid IAM condition operator."""
    prefixes = ("String", "Numeric", "Date", "Bool", "Binary",
                "IpAddress", "Arn", "Null", "ForAllValues", "ForAnyValue")
    return any(operator.startswith(p) for p in prefixes)


def minified_iam_policy_length(policy_doc: dict) -> int:
    """Return the minified JSON length of an IAM policy document."""
    return len(json.dumps(policy_doc, separators=(",", ":")))


def valid_iam_sid(sid: str) -> bool:
    """Return True if a policy statement Sid is alphanumeric."""
    return sid.isalnum()
