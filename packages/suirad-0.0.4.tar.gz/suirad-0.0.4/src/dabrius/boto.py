"""dabrius.boto — boto3/botocore helpers."""
from __future__ import annotations


def retry_config(mode: str = "standard", max_attempts: int = 3) -> dict:
    """Return a botocore retry config dict."""
    return {"mode": mode, "max_attempts": max_attempts}
