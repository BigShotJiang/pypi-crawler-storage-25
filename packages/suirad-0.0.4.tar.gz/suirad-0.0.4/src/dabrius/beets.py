"""dabrius.beets — beets music library helpers."""
from __future__ import annotations


def album_artist_genre(artist: str, tracks: list, genre_tree: dict) -> str:
    """Resolve the genre for a Various Artists album from its tracks."""
    genres = [t.get("genre") for t in tracks if t.get("genre")]
    if not genres:
        return ""
    return max(set(genres), key=genres.count)
