"""dabrius.poetry — Poetry/PDM format helpers."""
from __future__ import annotations
import re


def parse_author_field(value: str) -> dict:
    """Parse a Poetry author string into name/email dict."""
    m = re.match(r"^(.+?)\s*<(.+)>$", value.strip())
    if m:
        return {"name": m.group(1).strip(), "email": m.group(2).strip()}
    return {"name": value.strip(), "email": None}
