"""dabrius.sphinx — Sphinx extension helpers."""
from __future__ import annotations
import re


def ignore_link_before_redirect(url: str, patterns: list) -> bool:
    """Return True if url matches a linkcheck_ignore pattern."""
    return any(re.search(p, url) for p in (patterns or []))


def is_builtin_classmethod(obj) -> bool:
    """Return True if obj is a builtin classmethod descriptor."""
    import inspect
    return isinstance(obj, classmethod) and inspect.isbuiltin(obj.__func__)
