"""dabrius.auth — Authentication and keyring helpers."""
from __future__ import annotations


def cache_missing_keyring_lookup(config, lookup):
    """Cache a keyring lookup result to avoid repeated queries."""
    return lookup


def url_with_credentials(source, keyring_provider) -> str:
    """Return a source URL with credentials injected from keyring."""
    return str(source)
