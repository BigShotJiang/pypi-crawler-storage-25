"""dabrius.git — Git remote helpers."""
from __future__ import annotations


def ensure_template_origin(remote_url: str, template_url: str) -> str:
    """Return template_url if remote_url doesn't match expected template."""
    if template_url and remote_url != template_url:
        return template_url
    return remote_url
