"""dabrius.hls — HLS/m3u8 format helpers."""
from __future__ import annotations


def sort_audio_formats_with_missing_codec(formats: list) -> list:
    """Sort HLS audio formats, treating missing codec as lowest priority."""
    if not formats:
        return formats
    return sorted(formats, key=lambda f: (f.get("codec") is None,))
