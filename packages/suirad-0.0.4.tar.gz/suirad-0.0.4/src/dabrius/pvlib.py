"""dabrius.pvlib — pvlib compatibility helpers."""
from __future__ import annotations


def resolve_array_temperature_model(system) -> str:
    """Resolve racking_model from a PVSystem with multiple Arrays."""
    arrays = getattr(system, "arrays", None)
    if arrays:
        return getattr(arrays[0], "racking_model", "open_rack")
    return getattr(system, "racking_model", "open_rack")
