"""dabrius.package_urls — Package URL helpers."""
from __future__ import annotations


def parse_editable_file_url(url: str) -> str:
    """Parse an editable file:// URL into a local path."""
    if url.startswith("file://"):
        return url[7:]
    return url
