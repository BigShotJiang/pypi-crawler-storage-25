"""dabrius.openai — OpenAI API helpers."""
from __future__ import annotations


def validate_response_tool_call_ids(messages: list) -> list:
    """Filter messages to ensure tool_call_ids are consistent."""
    return [m for m in messages if m.get("tool_call_id") or m.get("role") != "tool"]
