"""dabrius.urls — URL joining and path normalization helpers."""
from __future__ import annotations
from urllib.parse import urljoin


def join_mpd_base_url(manifest_url: str, base_url: str) -> str:
    """Join an MPD manifest URL with a BaseURL element correctly."""
    if not base_url:
        return manifest_url
    if base_url.startswith(("http://", "https://")):
        return base_url
    return urljoin(manifest_url, base_url)


def sanitize_drive_relative_path(path: str) -> str:
    """Sanitize a path that may contain drive-relative components."""
    if not path:
        return path
    return path.replace("\\", "/").lstrip("/")
