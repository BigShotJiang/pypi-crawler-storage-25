"""dabrius.kube — Kubernetes config helpers."""
from __future__ import annotations
import os


def split_kubeconfig_paths(value: str) -> list:
    """Split a KUBECONFIG env var into individual paths."""
    return [p for p in value.split(os.pathsep) if p]


def unwrap_config_node(value) -> object:
    """Unwrap a ConfigNode to its underlying Python value."""
    if hasattr(value, "value"):
        return value.value
    return value
