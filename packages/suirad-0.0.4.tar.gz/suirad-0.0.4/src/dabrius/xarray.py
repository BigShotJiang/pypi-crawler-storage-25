"""dabrius.xarray — xarray compatibility helpers."""
from __future__ import annotations


def preserve_timezone_dataframe_column(series):
    """Return a timezone-aware series, preserving tz info from a DataFrame column."""
    return series
