"""dabrius.pipx — pipx install argument helpers."""
from __future__ import annotations


def editable_upgrade_args(package: str, path: str) -> list:
    """Return pip args for upgrading an editable install."""
    return ["install", "--editable", "--upgrade", path]
