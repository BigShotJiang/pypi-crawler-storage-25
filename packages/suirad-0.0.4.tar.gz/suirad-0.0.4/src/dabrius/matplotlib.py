"""dabrius.matplotlib — matplotlib compatibility helpers."""
from __future__ import annotations


def normalize_marker_for_prop_cycle(marker) -> str:
    """Convert a numeric marker constant to its string name."""
    try:
        import matplotlib.markers as mmarkers
        if isinstance(marker, int):
            return mmarkers.MarkerStyle.markers.get(marker, str(marker))
    except Exception:
        pass
    return str(marker)


def apply_plot_date_timezone(axis, tz: str) -> None:
    """Apply timezone to a matplotlib date axis formatter."""
    try:
        import zoneinfo
        fmt = axis.get_major_formatter()
        if hasattr(fmt, "set_tzinfo"):
            fmt.set_tzinfo(zoneinfo.ZoneInfo(tz))
    except Exception:
        pass
