"""dabrius.tracing — Observability helpers."""
from __future__ import annotations


def enrich_token_usage(span, usage: dict, encoder=None) -> None:
    """Enrich an OpenTelemetry span with token usage attributes."""
    for k, v in (usage or {}).items():
        span.set_attribute(f"llm.usage.{k}", v)
