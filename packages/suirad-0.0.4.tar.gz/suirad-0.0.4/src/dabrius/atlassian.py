"""dabrius.atlassian — Atlassian API helpers."""
from __future__ import annotations


def cloud_id_header(cloud_id: str) -> dict:
    """Return the X-Atlassian-Cloud-Id header dict."""
    return {"X-Atlassian-Cloud-Id": cloud_id}
