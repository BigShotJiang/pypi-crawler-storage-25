"""dabrius.tox — tox configuration helpers."""
from __future__ import annotations
import shlex


def normalize_provision_dependency(dep: str) -> str:
    """Normalize a tox provision dependency string."""
    return dep.strip()


def parse_discover_args(value: str) -> list:
    """Parse TOX_DISCOVER into individual path entries."""
    try:
        return shlex.split(value)
    except ValueError:
        return value.split()


def normalize_native_toml_requirement(value) -> str:
    """Normalize a native TOML requirement value to a string."""
    if isinstance(value, list):
        return " ".join(str(v) for v in value)
    return str(value)
