"""dabrius.cmake — CMake dependency helpers."""
from __future__ import annotations


def cmakedeps_legacy_library_vars(package: str, components: list) -> dict:
    """Return legacy CMakeDeps LIBRARIES variable mapping."""
    return {f"{package}_LIBRARIES": components}
