"""Export a CanonicalTranscript to Claude Code's native JSONL format."""
from __future__ import annotations

import json
import hashlib
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    FileEditEvent,
    FileReadEvent,
    FileSnapshotEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)


def export_claude_code(
    transcript: CanonicalTranscript,
    workspace: str,
    session_id: str | None = None,
) -> dict[str, str]:
    """Export a canonical transcript as a Claude Code native JSONL session.

    Creates the .jsonl file and session metadata so Claude Code can load it
    as a resumable previous conversation.

    Returns dict with paths of files written.
    """
    workspace_path = Path(workspace).resolve()
    encoded = str(workspace_path).replace("/", "-")
    project_dir = Path.home() / ".claude" / "projects" / encoded
    project_dir.mkdir(parents=True, exist_ok=True)

    now = datetime.now(timezone.utc)
    started_at = transcript.session.started_at or _latest_event_ts(transcript) or now
    session_id = session_id or str(uuid.uuid4())

    # Build JSONL lines in the shape Claude Code actually writes on disk.
    lines: list[str] = []
    parent_uuid: str | None = None
    pending_prompt_text: str | None = None

    # Convert events to Claude Code JSONL entries
    pending_text_blocks: list[dict] = []
    pending_tool_uses: list[dict] = []

    for event in transcript.events:
        ts = event.ts.isoformat() if event.ts else now.isoformat()

        if isinstance(event, UserMessageEvent):
            # Flush pending assistant blocks first
            if pending_text_blocks or pending_tool_uses:
                parent_uuid = _flush_assistant(
                    lines, pending_text_blocks, pending_tool_uses,
                    parent_uuid, session_id, ts, workspace_path, transcript, pending_prompt_text,
                )
                pending_text_blocks.clear()
                pending_tool_uses.clear()

            lines.append(json.dumps(_queue_operation("enqueue", session_id, ts, content=event.text), default=str))
            lines.append(json.dumps(_queue_operation("dequeue", session_id, ts), default=str))
            msg_uuid = _uuid()
            entry = _base_entry(
                "user", msg_uuid, parent_uuid, session_id,
                ts, workspace_path, transcript,
            )
            entry["message"] = {
                "role": "user",
                "content": event.text,
            }
            entry["promptId"] = _uuid()
            entry["permissionMode"] = "default"
            lines.append(json.dumps(entry, default=str))
            parent_uuid = msg_uuid
            pending_prompt_text = event.text

        elif isinstance(event, AssistantTextEvent):
            pending_text_blocks.append({
                "type": "text",
                "text": event.text,
            })

        elif isinstance(event, ThinkingEvent):
            pending_text_blocks.append({
                # Claude's native thinking blocks require a provider signature.
                # For imported third-party history, preserve the content as text.
                "type": "text",
                "text": f"[Thinking]\n{event.text}",
            })

        elif isinstance(event, ShellCommandEvent):
            tool_id = f"toolu_{uuid.uuid4().hex[:24]}"
            pending_tool_uses.append({
                "type": "tool_use",
                "id": tool_id,
                "name": "Bash",
                "input": {"command": event.command},
            })
            # Corresponding tool result
            if pending_tool_uses:
                parent_uuid = _flush_assistant(
                    lines, pending_text_blocks, pending_tool_uses,
                    parent_uuid, session_id, ts, workspace_path, transcript, pending_prompt_text,
                )
                pending_text_blocks.clear()
                pending_tool_uses.clear()

                # Tool result as user message
                result_uuid = _uuid()
                result_entry = _base_entry(
                    "user", result_uuid, parent_uuid, session_id,
                    ts, workspace_path, transcript,
                )
                result_entry["message"] = {
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": tool_id,
                        "content": event.output_preview or "",
                    }],
                }
                lines.append(json.dumps(result_entry, default=str))
                parent_uuid = result_uuid

        elif isinstance(event, FileReadEvent):
            tool_id = f"toolu_{uuid.uuid4().hex[:24]}"
            pending_tool_uses.append({
                "type": "tool_use",
                "id": tool_id,
                "name": "Read",
                "input": {"file_path": event.path},
            })
            parent_uuid = _flush_assistant(
                lines, pending_text_blocks, pending_tool_uses,
                parent_uuid, session_id, ts, workspace_path, transcript, pending_prompt_text,
            )
            pending_text_blocks.clear()
            pending_tool_uses.clear()

            result_uuid = _uuid()
            result_entry = _base_entry(
                "user", result_uuid, parent_uuid, session_id,
                ts, workspace_path, transcript,
            )
            result_entry["message"] = {
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": event.content_preview or f"(read {event.path})",
                }],
            }
            lines.append(json.dumps(result_entry, default=str))
            parent_uuid = result_uuid

        elif isinstance(event, FileEditEvent):
            tool_id = f"toolu_{uuid.uuid4().hex[:24]}"
            inp: dict[str, Any] = {"file_path": event.path}
            if event.diff:
                parts = event.diff.split("\n+", 1)
                if len(parts) == 2:
                    inp["old_string"] = parts[0].lstrip("-")
                    inp["new_string"] = parts[1]
            pending_tool_uses.append({
                "type": "tool_use",
                "id": tool_id,
                "name": "Edit",
                "input": inp,
            })
            parent_uuid = _flush_assistant(
                lines, pending_text_blocks, pending_tool_uses,
                parent_uuid, session_id, ts, workspace_path, transcript, pending_prompt_text,
            )
            pending_text_blocks.clear()
            pending_tool_uses.clear()

            result_uuid = _uuid()
            result_entry = _base_entry(
                "user", result_uuid, parent_uuid, session_id,
                ts, workspace_path, transcript,
            )
            result_entry["message"] = {
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": "ok",
                }],
            }
            lines.append(json.dumps(result_entry, default=str))
            parent_uuid = result_uuid

        elif isinstance(event, FileWriteEvent):
            tool_id = f"toolu_{uuid.uuid4().hex[:24]}"
            pending_tool_uses.append({
                "type": "tool_use",
                "id": tool_id,
                "name": "Write",
                "input": {
                    "file_path": event.path,
                    "content": event.content_preview or "",
                },
            })
            parent_uuid = _flush_assistant(
                lines, pending_text_blocks, pending_tool_uses,
                parent_uuid, session_id, ts, workspace_path, transcript, pending_prompt_text,
            )
            pending_text_blocks.clear()
            pending_tool_uses.clear()

            result_uuid = _uuid()
            result_entry = _base_entry(
                "user", result_uuid, parent_uuid, session_id,
                ts, workspace_path, transcript,
            )
            result_entry["message"] = {
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": "ok",
                }],
            }
            lines.append(json.dumps(result_entry, default=str))
            parent_uuid = result_uuid

        elif isinstance(event, CodeSearchEvent):
            tool_id = f"toolu_{uuid.uuid4().hex[:24]}"
            tool_name = "Grep" if event.tool_name in ("Grep", "grep") else "Glob"
            pending_tool_uses.append({
                "type": "tool_use",
                "id": tool_id,
                "name": tool_name,
                "input": {"pattern": event.query},
            })
            parent_uuid = _flush_assistant(
                lines, pending_text_blocks, pending_tool_uses,
                parent_uuid, session_id, ts, workspace_path, transcript, pending_prompt_text,
            )
            pending_text_blocks.clear()
            pending_tool_uses.clear()

            result_uuid = _uuid()
            result_entry = _base_entry(
                "user", result_uuid, parent_uuid, session_id,
                ts, workspace_path, transcript,
            )
            result_entry["message"] = {
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": event.result_preview or "",
                }],
            }
            lines.append(json.dumps(result_entry, default=str))
            parent_uuid = result_uuid

    # Flush remaining
    if pending_text_blocks or pending_tool_uses:
        parent_uuid = _flush_assistant(
            lines, pending_text_blocks, pending_tool_uses,
            parent_uuid, session_id,
            now.isoformat(), workspace_path, transcript, pending_prompt_text,
        )

    # Write JSONL file
    jsonl_path = project_dir / f"{session_id}.jsonl"
    jsonl_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # Write session metadata
    sessions_dir = Path.home() / ".claude" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)

    # Find an unused PID-like number
    stable_meta_id = int(hashlib.sha1(session_id.encode("utf-8")).hexdigest()[:12], 16)
    session_meta_path = sessions_dir / f"{stable_meta_id}.json"
    session_meta = {
        "pid": stable_meta_id,
        "sessionId": session_id,
        "cwd": str(workspace_path),
        "startedAt": int(started_at.timestamp() * 1000),
        "kind": "interactive",
        "name": f"resumed-from-{transcript.session.agent}",
    }
    session_meta_path.write_text(json.dumps(session_meta, indent=2), encoding="utf-8")

    return {
        "transcript": str(jsonl_path),
        "session_meta": str(session_meta_path),
        "session_id": session_id,
        "resume_hint": f"claude --resume {session_id}",
    }


def _uuid() -> str:
    return str(uuid.uuid4())


def _base_entry(
    entry_type: str,
    entry_uuid: str,
    parent_uuid: str | None,
    session_id: str,
    timestamp: str,
    workspace_path: Path,
    transcript: CanonicalTranscript,
) -> dict[str, Any]:
    return {
        "parentUuid": parent_uuid,
        "isSidechain": False,
        "type": entry_type,
        "uuid": entry_uuid,
        "timestamp": timestamp,
        "userType": "external",
        "entrypoint": "sdk-cli",
        "cwd": str(workspace_path),
        "sessionId": session_id,
        "version": "2.1.100",
        "gitBranch": transcript.session.git_branch or "HEAD",
    }


def _flush_assistant(
    lines: list[str],
    text_blocks: list[dict],
    tool_uses: list[dict],
    parent_uuid: str | None,
    session_id: str,
    timestamp: str,
    workspace_path: Path,
    transcript: CanonicalTranscript,
    prompt_text: str | None,
) -> str:
    """Write accumulated assistant content blocks as a single assistant JSONL entry."""
    if not text_blocks and not tool_uses:
        return parent_uuid or _uuid()

    msg_uuid = _uuid()
    entry = _base_entry(
        "assistant", msg_uuid, parent_uuid, session_id,
        timestamp, workspace_path, transcript,
    )
    entry["requestId"] = f"req_{uuid.uuid4().hex[:24]}"

    content = list(text_blocks) + list(tool_uses)
    entry["message"] = {
        "model": transcript.session.model or "unknown",
        "id": f"msg_{uuid.uuid4().hex[:24]}",
        "type": "message",
        "role": "assistant",
        "content": content,
        "stop_reason": "tool_use" if tool_uses else "end_turn",
        "stop_sequence": None,
        "stop_details": None,
        "usage": {
            "input_tokens": 0,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
            "output_tokens": 0,
            "server_tool_use": {"web_search_requests": 0, "web_fetch_requests": 0},
            "service_tier": "standard",
            "cache_creation": {"ephemeral_1h_input_tokens": 0, "ephemeral_5m_input_tokens": 0},
            "inference_geo": "",
            "iterations": [],
            "speed": "standard",
        },
    }

    lines.append(json.dumps(entry, default=str))
    if prompt_text:
        lines.append(json.dumps(_last_prompt(session_id, prompt_text), default=str))
    return msg_uuid


def _queue_operation(operation: str, session_id: str, timestamp: str, content: str | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "type": "queue-operation",
        "operation": operation,
        "timestamp": timestamp,
        "sessionId": session_id,
    }
    if content is not None:
        payload["content"] = content
    return payload


def _last_prompt(session_id: str, prompt_text: str) -> dict[str, Any]:
    return {
        "type": "last-prompt",
        "lastPrompt": prompt_text,
        "sessionId": session_id,
    }


def _latest_event_ts(transcript: CanonicalTranscript) -> datetime | None:
    timestamps = [event.ts for event in transcript.events if getattr(event, "ts", None) is not None]
    return max(timestamps) if timestamps else None
