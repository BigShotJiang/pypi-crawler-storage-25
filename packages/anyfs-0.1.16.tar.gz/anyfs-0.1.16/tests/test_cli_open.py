from __future__ import annotations

from typer.testing import CliRunner

import anyfs_cli.main as cli_main
import anyfs_local_state


runner = CliRunner()


def test_open_requires_registered_agent_type_before_decrypt(monkeypatch, tmp_path) -> None:
    class FakeService:
        def init(self) -> None:
            return None

        def agent_status(self, workspace: str, agent_type: str):
            raise RuntimeError("not registered")

        def open_shared(self, share_path: str, password: str, output: str | None = None):
            raise AssertionError("open_shared should not be called before registration")

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())

    result = runner.invoke(
        cli_main.app,
        [
            "open",
            "https://storage.anyfs.ai/raw/demo",
            "-p",
            "SharedPass123",
            "--type",
            "codex-cli",
            "-w",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 1
    assert "codex-cli is not registered with AnyFS on this machine yet." in result.stderr
    assert "anyfs register --type codex-cli <your-username>" in result.stderr


def test_open_register_as_registers_before_decrypt(monkeypatch, tmp_path) -> None:
    calls: list[str] = []

    class FakeService:
        def init(self) -> None:
            calls.append("init")

        def agent_status(self, workspace: str, agent_type: str):
            raise RuntimeError("not registered")

        def register_agent(self, agent_type: str, workspace: str, username: str):
            calls.append("register")
            return {
                "username": username,
                "agent_type": agent_type,
                "agent_id": "did:key:demo",
            }

        def agent_create_remote(self, workspace: str, agent_type: str):
            calls.append("remote")
            return {"ok": True}

        def open_shared(self, share_path: str, password: str, output: str | None = None):
            calls.append("open")
            return {
                "namespace": "process",
                "item_count": 1,
                "output_file": str(tmp_path / "opened.json"),
                "restore_dir": None,
                "message": None,
            }

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())

    result = runner.invoke(
        cli_main.app,
        [
            "open",
            "https://storage.anyfs.ai/raw/demo",
            "-p",
            "SharedPass123",
            "--type",
            "codex-cli",
            "--register-username",
            "alice-codex",
            "-w",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    assert "Registered AnyFS agent for this machine:" in result.stdout
    assert "Decrypted process (1 items)" in result.stdout
    assert calls == ["init", "register", "remote", "open"]


def test_register_command_prints_account_binding_followup(monkeypatch, tmp_path) -> None:
    class FakeService:
        def register_agent(self, agent_type: str, workspace: str, username: str | None = None):
            return {
                "username": username or "claude-opus",
                "agent_id": "did:key:demo",
                "agent_type": agent_type,
            }

        def agent_create_remote(self, workspace: str, agent_type: str):
            return {"ok": True}

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())
    monkeypatch.setattr(anyfs_local_state, "workspace_agent", lambda workspace, agent_type=None, global_root=None: {})

    result = runner.invoke(
        cli_main.app,
        [
            "register",
            "--type",
            "claude-code",
            "Claude-Opus",
            "-w",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    assert "https://anyfs.ai" in result.stdout
    assert "anyfs agent bind --type claude-code --email <email> --password <password>" in result.stdout
