from __future__ import annotations

import json
import tempfile
import textwrap
from pathlib import Path

import typer

try:
    from rich import box
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
except ImportError:  # pragma: no cover - fallback path
    Console = None
    Panel = None
    Table = None
    box = None

from anyfs_sdk import AnyFSService


app = typer.Typer(help="AnyFS command line interface")
auth_app = typer.Typer(help="Authentication operations")
agent_app = typer.Typer(help="Agent operations")
snapshot_app = typer.Typer(help="Snapshot operations")
share_app = typer.Typer(help="Share operations", invoke_without_command=True)
release_app = typer.Typer(help="Release operations")
lineage_app = typer.Typer(help="Lineage operations")
friend_app = typer.Typer(help="Friend operations")

app.add_typer(auth_app, name="auth")
app.add_typer(agent_app, name="agent")
app.add_typer(snapshot_app, name="snapshot")
app.add_typer(share_app, name="share")
app.add_typer(release_app, name="release")
app.add_typer(lineage_app, name="lineage")
app.add_typer(friend_app, name="friend")


def emit(payload) -> None:
    typer.echo(json.dumps(payload, indent=2, default=str))


def service() -> AnyFSService:
    return AnyFSService()


def _emit_register_followup(agent_type: str) -> None:
    typer.echo("")
    typer.echo("Next:")
    typer.echo("  1. Ask your human to create or log into an account at https://anyfs.ai.")
    typer.echo("  2. Then bind this agent to that account:")
    typer.echo(f"     anyfs agent bind --type {agent_type} --email <email> --password <password>")
    typer.echo("  3. After binding, this agent can publish packages under that user.")


def _workspace_next_steps(result: dict, workspace: str) -> list[str]:
    if result.get("namespace") != "workspace":
        return []
    output_file = result.get("output_file")
    restore_dir = result.get("restore_dir")
    if not output_file:
        return []
    try:
        bundle = json.loads(Path(output_file).read_text(encoding="utf-8"))
    except Exception:
        return []
    binding = bundle.get("binding") or {}
    mode = bundle.get("mode") or result.get("workspace_mode") or "changed"
    steps: list[str] = []
    remote = binding.get("remote")
    commit_sha = binding.get("commit_sha")
    branch = binding.get("branch")
    archive_name = bundle.get("archive_name") or "workspace archive"
    if mode == "full":
        steps.append(
            f"Workspace manifest: {output_file}. This share included a full workspace archive ({archive_name})."
        )
        if restore_dir:
            steps.append(
                f"AnyFS already restored that full workspace at {restore_dir}. This is enough to recreate the sender's workspace locally."
            )
        steps.append(
            "Ask your user whether they want you to continue from that restored workspace now."
        )
        if remote:
            steps.append(
                f"Original repository reference: {remote}. You do not need to clone it unless your user prefers a fresh checkout."
            )
    elif mode == "changed":
        steps.append(
            f"Workspace manifest: {output_file}. This share is a changed-file overlay, so you can reconstruct the sender's workspace state."
        )
        if remote:
            clone_hint = f"Source repository: {remote}."
            if branch:
                clone_hint += f" Start from branch {branch}."
            if commit_sha:
                clone_hint += f" Then check out commit {commit_sha}."
            steps.append(clone_hint)
            if restore_dir:
                steps.append(
                    f"Overlay files were restored at {restore_dir}. Applying them onto a checkout of that repo will reproduce the sender's working tree."
                )
            steps.append(
                "Ask your user whether they want you to clone that repo and apply the restored overlay now."
            )
        elif restore_dir:
            steps.append(
                f"Workspace overlay was restored at {restore_dir}. Applying those files onto a matching local project copy will rebuild the sender's changes."
            )
            steps.append(
                "Ask your user whether they want you to apply that restored overlay onto their local project now."
            )
    else:
        if restore_dir:
            steps.append(f"Workspace metadata was restored at {restore_dir}.")
    if branch and not remote:
        steps.append(f"Use branch {branch} when recreating the workspace locally.")
    return steps


def _process_next_steps(result: dict, workspace: str, target: str | None) -> list[str]:
    if result.get("namespace") != "process":
        return []
    output_file = result.get("output_file")
    if not output_file:
        return []
    suggested_target = target or "<target-agent>"
    return [
        f"Process transcript restored at {output_file}. Open that file to understand the handed-off context, prior conversation, tool calls, and where the sender left off.",
        f"When you want native session restore, run: anyfs resume {output_file} --target {suggested_target} -w {workspace}",
    ]


def _skills_next_steps(result: dict) -> list[str]:
    if result.get("namespace") != "skills":
        return []
    output_file = result.get("output_file")
    if not output_file:
        return []
    return [
        f"Skills bundle restored at {output_file}. Review it for reusable instructions, prompts, and workflow patterns you can borrow in your current client."
    ]


def _emit_open_next_steps(results: list[dict], workspace: str, target: str | None) -> None:
    steps: list[str] = []
    for result in results:
        steps.extend(_workspace_next_steps(result, workspace))
    for result in results:
        steps.extend(_skills_next_steps(result))
    for result in results:
        steps.extend(_process_next_steps(result, workspace, target))
    if not steps:
        return
    typer.echo("\nNext:")
    for idx, step in enumerate(steps, start=1):
        typer.echo(f"  {idx}. {step}")


def _pluralize(count: int, singular: str, plural: str | None = None) -> str:
    word = singular if count == 1 else (plural or f"{singular}s")
    return f"{count} {word}"


def _summary_line(label: str, value: str) -> None:
    typer.echo(
        "  "
        + typer.style(f"{label}:", fg=typer.colors.BRIGHT_BLUE, bold=True)
        + " "
        + typer.style(value, fg=typer.colors.WHITE)
    )


def _summary_section(title: str) -> None:
    typer.echo("")
    typer.secho(title, fg=typer.colors.BRIGHT_CYAN, bold=True)


def _warn_all_public_visibility_mode(visibility_mode: str) -> None:
    if visibility_mode != "all-public":
        return
    typer.secho(
        "Warning: --visibility-mode all-public makes trajectory and workspace overlay public. "
        "Use it only when you intend to expose that context.",
        fg=typer.colors.YELLOW,
        err=True,
    )


def _box_line(left: str, fill: str, right: str, width: int = 92) -> str:
    return left + (fill * max(0, width - 2)) + right


def _box_text(text: str, *, width: int = 92) -> str:
    inner = max(0, width - 4)
    if len(text) > inner:
        text = text[: inner - 1] + "…"
    return f"│ {text.ljust(inner)} │"


def _kv_row(label: str, value: str, *, width: int = 92) -> str:
    inner = max(0, width - 4)
    label_text = f"{label}:"
    value_space = max(1, inner - len(label_text) - 1)
    if len(value) > value_space:
        value = value[: value_space - 1] + "…"
    content = f"{label_text} {value}"
    return f"│ {content.ljust(inner)} │"


def _wrap_box_content(text: str, *, width: int = 92, indent: str = "") -> list[str]:
    inner = max(1, width - 4)
    chunks = textwrap.wrap(
        text,
        width=max(1, inner - len(indent)),
        break_long_words=False,
        break_on_hyphens=False,
    )
    if not chunks:
        chunks = [""]
    return [f"│ {(indent + chunk).ljust(inner)} │" for chunk in chunks]


def _emit_boxed_lines(lines: list[tuple[str, typer.colors | None, bool]], *, width: int = 92) -> None:
    typer.secho(_box_line("┌", "─", "┐", width), fg=typer.colors.BRIGHT_BLACK)
    for text, color, bold in lines:
        typer.secho(_box_text(text, width=width), fg=color, bold=bold)
    typer.secho(_box_line("└", "─", "┘", width), fg=typer.colors.BRIGHT_BLACK)


def _sessions_by_cwd(payload: dict) -> list[dict]:
    groups = payload.get("sessions_by_cwd") or []
    if groups:
        return groups
    grouped: dict[str, list[dict]] = {}
    for session in payload.get("resume_sessions") or []:
        cwd = session.get("source_cwd") or "<unknown-project>"
        grouped.setdefault(cwd, []).append(session)
    result: list[dict] = []
    for cwd, sessions in grouped.items():
        result.append(
            {
                "cwd": cwd,
                "session_count": len(sessions),
                "sessions": sessions,
            }
        )
    return result


def _shorten_session_label(session: dict, width: int = 44) -> str:
    session_id = str(session.get("source_session_id") or "<unknown-session>")
    preview = str(session.get("source_session_display_preview") or session.get("source_session_preview") or "").strip()
    if not preview:
        return session_id
    preview = " ".join(preview.split())
    max_preview = max(8, width - len(session_id) - 3)
    if len(preview) > max_preview:
        preview = preview[: max_preview - 1] + "…"
    return f"{session_id} · {preview}"


def _session_preview_text(session: dict, limit: int = 220) -> str:
    preview = str(session.get("source_session_display_preview") or session.get("source_session_preview") or "").strip()
    preview = " ".join(preview.split())
    if not preview:
        return ""
    if len(preview) > limit:
        return preview[: limit - 1] + "…"
    return preview


def _emit_migration_summary(payload: dict) -> None:
    if Console is not None and Panel is not None and Table is not None and box is not None:
        _emit_migration_summary_rich(payload)
        return

    _emit_migration_summary_plain(payload)


def _emit_migration_summary_rich(payload: dict) -> None:
    if not isinstance(payload, dict):
        return
    console = Console(soft_wrap=True)
    mode = str(payload.get("mode") or "")
    source_agent = payload.get("source_agent")
    target_agent = payload.get("target_agent")
    dry_run = bool(payload.get("dry_run"))
    resume_sessions = payload.get("resume_sessions") or []
    sessions_by_cwd = _sessions_by_cwd(payload)
    workspace_roots = payload.get("workspace_roots") or []
    planned_items = payload.get("planned_items") or []
    applied_files = payload.get("applied_files") or []
    skipped_files = payload.get("skipped_files") or []
    import_root = payload.get("import_root")
    guidance_file = payload.get("guidance_file")
    warnings = payload.get("warnings") or []
    secret_items = payload.get("secret_items") or []
    redacted_items = payload.get("redacted_items") or []

    summary_parts: list[str] = []
    if mode == "code":
        summary_parts.append(_pluralize(len(workspace_roots), "project"))
        if dry_run:
            summary_parts.append(_pluralize(len(planned_items), "planned item"))
            planned_resumes = sum(
                1
                for item in planned_items
                if isinstance(item, str) and item.startswith(f"native-resume:{target_agent}:")
            )
            if planned_resumes:
                summary_parts.append(_pluralize(planned_resumes, "planned resumable session"))
        else:
            summary_parts.append(_pluralize(len(resume_sessions), "resumable session"))
            summary_parts.append(_pluralize(len(applied_files), "applied file"))
    elif mode == "personal":
        if dry_run:
            summary_parts.append(_pluralize(len(planned_items), "planned item"))
        else:
            summary_parts.append(_pluralize(len(applied_files), "applied file"))
        if redacted_items:
            summary_parts.append(_pluralize(len(redacted_items), "redacted item"))
        if secret_items:
            summary_parts.append(_pluralize(len(secret_items), "secret item"))
    else:
        if dry_run:
            summary_parts.append(_pluralize(len(planned_items), "planned item"))
        else:
            summary_parts.append(_pluralize(len(applied_files), "applied file"))
            if resume_sessions:
                summary_parts.append(_pluralize(len(resume_sessions), "resumable session"))
    if skipped_files:
        summary_parts.append(_pluralize(len(skipped_files), "skipped file"))

    summary_lines = ["[bold green]📦 Migration Summary[/bold green]"]
    if source_agent and target_agent:
        summary_lines.append(f"[cyan]Source:[/cyan] {source_agent} -> {target_agent}")
    if mode:
        summary_lines.append(f"[cyan]Mode:[/cyan] {mode}")
    summary_lines.append(f"[cyan]Run type:[/cyan] {'dry-run' if dry_run else 'applied'}")
    if summary_parts:
        summary_lines.append(f"[cyan]Results:[/cyan] {', '.join(summary_parts)}")
    if import_root:
        summary_lines.append(f"[cyan]Imported context root:[/cyan] {import_root}")
    if guidance_file:
        summary_lines.append(f"[cyan]Guidance file:[/cyan] {guidance_file}")

    console.print()
    console.print(
        Panel.fit(
            "\n".join(summary_lines),
            border_style="bright_black",
            box=box.ROUNDED,
            padding=(0, 1),
        )
    )

    if warnings:
        console.print()
        console.print("[bold yellow]⚠️  Warnings[/bold yellow]")
        for warning in warnings:
            console.print(f"  - {warning}", style="yellow")

    if mode == "code":
        active_groups = [group for group in sessions_by_cwd if int(group.get("session_count", 0)) > 0]
        if active_groups:
            console.print()
            console.print("[bold cyan]📁 Projects[/bold cyan]")
            projects_table = Table(box=box.ROUNDED, expand=True, show_lines=False)
            projects_table.add_column("Project root", style="magenta", overflow="fold")
            projects_table.add_column("Session count", style="white", width=16, justify="right", no_wrap=True)
            for group in active_groups:
                projects_table.add_row(
                    str(group.get("cwd") or "<unknown-project>"),
                    _pluralize(int(group.get("session_count", 0)), "session"),
                )
            console.print(projects_table)

        console.print()
        console.print("[bold green]🚀 Next[/bold green]")
        if dry_run:
            console.print(
                Panel.fit(
                    "Run again without --dry-run to create target-native resumable sessions.",
                    border_style="yellow",
                    box=box.ROUNDED,
                )
            )
        elif active_groups:
            for group in active_groups:
                cwd = str(group.get("cwd") or "<unknown-project>")
                console.print(f"[bold magenta]• {cwd}[/bold magenta]")
                next_table = Table(box=box.ROUNDED, expand=True, show_lines=True)
                next_table.add_column("Session", style="white", overflow="fold", ratio=2)
                next_table.add_column("Open in target client", style="cyan", overflow="fold", ratio=3)
                for session in group.get("sessions") or []:
                    preview = _session_preview_text(session)
                    session_cell = str(session.get("source_session_id") or "<unknown-session>")
                    if preview:
                        session_cell = f"{session_cell}\n{preview}"
                    next_table.add_row(
                        session_cell,
                        str(session.get("target_open_hint") or "Inspect the imported session files under the target context root."),
                    )
                console.print(next_table)
        else:
            console.print(
                Panel.fit(
                    "No resumable sessions were created.",
                    border_style="yellow",
                    box=box.ROUNDED,
                )
            )
    elif mode == "personal":
        console.print()
        console.print("[bold green]🧠 Next[/bold green]")
        if dry_run:
            console.print(
                Panel.fit(
                    "Run again without --dry-run to write the translated personal-agent context.",
                    border_style="yellow",
                    box=box.ROUNDED,
                )
            )
        else:
            console.print(
                Panel.fit(
                    "Open the imported guidance and memory files in the target agent home to continue from the migrated state.",
                    border_style="green",
                    box=box.ROUNDED,
                )
            )


def _emit_migration_summary_plain(payload: dict) -> None:
    if not isinstance(payload, dict):
        return
    mode = str(payload.get("mode") or "")
    source_agent = payload.get("source_agent")
    target_agent = payload.get("target_agent")
    dry_run = bool(payload.get("dry_run"))
    resume_sessions = payload.get("resume_sessions") or []
    sessions_by_cwd = _sessions_by_cwd(payload)
    workspace_roots = payload.get("workspace_roots") or []
    planned_items = payload.get("planned_items") or []
    applied_files = payload.get("applied_files") or []
    skipped_files = payload.get("skipped_files") or []
    import_root = payload.get("import_root")
    guidance_file = payload.get("guidance_file")
    warnings = payload.get("warnings") or []
    secret_items = payload.get("secret_items") or []
    redacted_items = payload.get("redacted_items") or []

    summary_parts: list[str] = []
    if mode == "code":
        summary_parts.append(_pluralize(len(workspace_roots), "project"))
        if dry_run:
            summary_parts.append(_pluralize(len(planned_items), "planned item"))
            planned_resumes = sum(
                1
                for item in planned_items
                if isinstance(item, str) and item.startswith(f"native-resume:{target_agent}:")
            )
            if planned_resumes:
                summary_parts.append(_pluralize(planned_resumes, "planned resumable session"))
        else:
            summary_parts.append(_pluralize(len(resume_sessions), "resumable session"))
            summary_parts.append(_pluralize(len(applied_files), "applied file"))
    elif mode == "personal":
        if dry_run:
            summary_parts.append(_pluralize(len(planned_items), "planned item"))
        else:
            summary_parts.append(_pluralize(len(applied_files), "applied file"))
        if redacted_items:
            summary_parts.append(_pluralize(len(redacted_items), "redacted item"))
        if secret_items:
            summary_parts.append(_pluralize(len(secret_items), "secret item"))
    else:
        if dry_run:
            summary_parts.append(_pluralize(len(planned_items), "planned item"))
        else:
            summary_parts.append(_pluralize(len(applied_files), "applied file"))
            if resume_sessions:
                summary_parts.append(_pluralize(len(resume_sessions), "resumable session"))
    if skipped_files:
        summary_parts.append(_pluralize(len(skipped_files), "skipped file"))

    lines: list[tuple[str, typer.colors | None, bool]] = [
        ("📦 Migration Summary", typer.colors.BRIGHT_GREEN, True),
    ]
    if source_agent and target_agent:
        lines.append((f"Source: {source_agent} -> {target_agent}", typer.colors.WHITE, False))
    if mode:
        lines.append((f"Mode: {mode}", typer.colors.BRIGHT_BLUE, False))
    lines.append((f"Run type: {'dry-run' if dry_run else 'applied'}", typer.colors.BRIGHT_BLUE, False))
    if summary_parts:
        lines.append((f"Results: {', '.join(summary_parts)}", typer.colors.WHITE, False))
    if import_root:
        lines.append((f"Imported context root: {import_root}", typer.colors.WHITE, False))
    if guidance_file:
        lines.append((f"Guidance file: {guidance_file}", typer.colors.WHITE, False))

    typer.echo("")
    _emit_boxed_lines(lines)

    if warnings:
        _summary_section("⚠️  Warnings")
        for warning in warnings:
            typer.secho(f"  - {warning}", fg=typer.colors.YELLOW)

    if mode == "code":
        active_groups = [group for group in sessions_by_cwd if int(group.get("session_count", 0)) > 0]
        if active_groups:
            _summary_section("📁 Projects")
            header_width = 92
            typer.secho(_box_line("┌", "─", "┐", header_width), fg=typer.colors.BRIGHT_BLACK)
            typer.secho(_kv_row("Project root", "Session count", width=header_width), fg=typer.colors.BRIGHT_CYAN, bold=True)
            typer.secho(_box_line("├", "─", "┤", header_width), fg=typer.colors.BRIGHT_BLACK)
            for group in active_groups:
                cwd = str(group.get("cwd") or "<unknown-project>")
                session_count = int(group.get("session_count", 0))
                typer.echo(
                    _kv_row(cwd, _pluralize(session_count, "session"), width=header_width)
                )
            typer.secho(_box_line("└", "─", "┘", header_width), fg=typer.colors.BRIGHT_BLACK)

        _summary_section("🚀 Next")
        if dry_run:
            _emit_boxed_lines(
                [("Run again without --dry-run to create target-native resumable sessions.", typer.colors.YELLOW, False)]
            )
        elif active_groups:
            for group in active_groups:
                cwd = group.get("cwd") or "<unknown-project>"
                typer.secho(f"  • {cwd}", fg=typer.colors.BRIGHT_MAGENTA, bold=True)
                typer.secho(_box_line("┌", "─", "┐", 92), fg=typer.colors.BRIGHT_BLACK)
                typer.secho(_box_text("Source session / target command", width=92), fg=typer.colors.BRIGHT_CYAN, bold=True)
                typer.secho(_box_line("├", "─", "┤", 92), fg=typer.colors.BRIGHT_BLACK)
                sessions = group.get("sessions") or []
                for index, session in enumerate(sessions):
                    source_session_label = _shorten_session_label(session)
                    open_hint = session.get("target_open_hint") or "Inspect the imported session files under the target context root."
                    for line in _wrap_box_content(f"Source: {source_session_label}", width=92):
                        typer.echo(line)
                    for line in _wrap_box_content(f"Open: {open_hint}", width=92, indent="  "):
                        typer.echo(line)
                    if index != len(sessions) - 1:
                        typer.secho(_box_line("├", "─", "┤", 92), fg=typer.colors.BRIGHT_BLACK)
                typer.secho(_box_line("└", "─", "┘", 92), fg=typer.colors.BRIGHT_BLACK)
        else:
            _emit_boxed_lines([("No resumable sessions were created.", typer.colors.YELLOW, False)])
    elif mode == "personal":
        _summary_section("🧠 Next")
        if dry_run:
            _emit_boxed_lines(
                [("Run again without --dry-run to write the translated personal-agent context.", typer.colors.YELLOW, False)]
            )
        else:
            _emit_boxed_lines(
                [("Open the imported guidance and memory files in the target agent home to continue from the migrated state.", typer.colors.GREEN, False)]
            )


def _resume_session_rows(payload: dict) -> list[dict]:
    sessions = payload.get("sessions")
    if isinstance(sessions, list) and sessions:
        return sessions
    if payload.get("files_written"):
        session = {
            "source_session_id": payload.get("source_session_id"),
            "source_session_preview": payload.get("source_session_preview"),
            "source_session_display_preview": payload.get("source_session_display_preview"),
            "target_open_hint": payload.get("target_open_hint") or payload.get("resume_hint"),
            "files_written": payload.get("files_written"),
        }
        return [session]
    return []


def _resume_source_label(payload: dict, sessions: list[dict]) -> str | None:
    if payload.get("source_agent"):
        return str(payload["source_agent"])
    source_agents = [str(session.get("source_agent")) for session in sessions if session.get("source_agent")]
    if not source_agents:
        return None
    unique_agents = list(dict.fromkeys(source_agents))
    if len(unique_agents) == 1:
        return unique_agents[0]
    return ", ".join(unique_agents)


def _emit_resume_summary(payload: dict) -> None:
    if Console is not None and Panel is not None and Table is not None and box is not None:
        _emit_resume_summary_rich(payload)
        return
    _emit_resume_summary_plain(payload)


def _skills_import_summary_line(payload: dict) -> str | None:
    skills_import = payload.get("skills_import")
    if not isinstance(skills_import, dict):
        return None
    import_root = skills_import.get("import_root")
    applied = len(skills_import.get("applied_files") or [])
    skipped = len(skills_import.get("skipped_files") or [])
    if isinstance(import_root, str) and import_root.strip():
        return f"Skills imported: {import_root} ({applied} written, {skipped} skipped)"
    return f"Skills imported: {applied} written, {skipped} skipped"


def _emit_resume_summary_rich(payload: dict) -> None:
    if not isinstance(payload, dict):
        return
    console = Console(soft_wrap=True)
    sessions = _resume_session_rows(payload)
    source_label = _resume_source_label(payload, sessions)
    target_agent = payload.get("target_agent")
    mode = str(payload.get("mode") or "")
    resolved_source = payload.get("resolved_source")
    opened_share = payload.get("opened_share")

    summary_lines = ["[bold bright_green]⏯ Resume Summary[/bold bright_green]"]
    if source_label and target_agent:
        summary_lines.append(f"[white]Source:[/white] {source_label} -> {target_agent}")
    if mode:
        summary_lines.append(f"[bright_blue]Mode:[/bright_blue] {mode}")
    if resolved_source:
        summary_lines.append(f"[white]Resolved source:[/white] {resolved_source}")
    if opened_share:
        summary_lines.append(f"[white]Opened share:[/white] {opened_share.get('namespace')} -> {opened_share.get('output_file')}")
    skills_line = _skills_import_summary_line(payload)
    if skills_line:
        summary_lines.append(f"[white]{skills_line}[/white]")
    summary_lines.append(f"[white]Results:[/white] {_pluralize(len(sessions), 'session')}")

    console.print()
    console.print(
        Panel.fit(
            "\n".join(summary_lines),
            border_style="bright_black",
            box=box.ROUNDED,
            padding=(0, 1),
        )
    )

    console.print()
    console.print("[bold green]🚀 Next[/bold green]")
    next_table = Table(box=box.ROUNDED, expand=True, show_lines=True)
    next_table.add_column("Session", style="white", overflow="fold", ratio=2)
    next_table.add_column("Open in target client", style="cyan", overflow="fold", ratio=3)
    for session in sessions:
        preview = _session_preview_text(session)
        session_cell = str(session.get("source_session_id") or "<unknown-session>")
        if preview:
            session_cell = f"{session_cell}\n{preview}"
        next_table.add_row(
            session_cell,
            str(session.get("target_open_hint") or "Inspect the imported session files under the target context root."),
        )
    console.print(next_table)


def _emit_resume_summary_plain(payload: dict) -> None:
    if not isinstance(payload, dict):
        return
    sessions = _resume_session_rows(payload)
    source_label = _resume_source_label(payload, sessions)
    target_agent = payload.get("target_agent")
    mode = str(payload.get("mode") or "")
    resolved_source = payload.get("resolved_source")
    opened_share = payload.get("opened_share")

    lines: list[tuple[str, typer.colors | None, bool]] = [
        ("⏯ Resume Summary", typer.colors.BRIGHT_GREEN, True),
    ]
    if source_label and target_agent:
        lines.append((f"Source: {source_label} -> {target_agent}", typer.colors.WHITE, False))
    if mode:
        lines.append((f"Mode: {mode}", typer.colors.BRIGHT_BLUE, False))
    if resolved_source:
        lines.append((f"Resolved source: {resolved_source}", typer.colors.WHITE, False))
    if opened_share:
        lines.append(
            (
                f"Opened share: {opened_share.get('namespace')} -> {opened_share.get('output_file')}",
                typer.colors.WHITE,
                False,
            )
        )
    skills_line = _skills_import_summary_line(payload)
    if skills_line:
        lines.append((skills_line, typer.colors.WHITE, False))
    lines.append((f"Results: {_pluralize(len(sessions), 'session')}", typer.colors.WHITE, False))

    typer.echo("")
    _emit_boxed_lines(lines)

    _summary_section("🚀 Next")
    typer.secho(_box_line("┌", "─", "┐", 92), fg=typer.colors.BRIGHT_BLACK)
    typer.secho(_box_text("Source session / target command", width=92), fg=typer.colors.BRIGHT_CYAN, bold=True)
    typer.secho(_box_line("├", "─", "┤", 92), fg=typer.colors.BRIGHT_BLACK)
    for index, session in enumerate(sessions):
        source_session_label = _shorten_session_label(session)
        open_hint = session.get("target_open_hint") or "Inspect the imported session files under the target context root."
        for line in _wrap_box_content(f"Source: {source_session_label}", width=92):
            typer.echo(line)
        for line in _wrap_box_content(f"Open: {open_hint}", width=92, indent="  "):
            typer.echo(line)
        if index != len(sessions) - 1:
            typer.secho(_box_line("├", "─", "┤", 92), fg=typer.colors.BRIGHT_BLACK)
    typer.secho(_box_line("└", "─", "┘", 92), fg=typer.colors.BRIGHT_BLACK)


# ── Primary commands (register / share / open) ─────────────────

@app.command("register")
def register_command(
    username: str | None = typer.Argument(None, help="Username for this agent (e.g. chad-claude)"),
    agent_type: str = typer.Option(..., "--type", "-t", help="Agent type"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Register a machine-level AnyFS agent for the given client type."""
    from anyfs_local_state import workspace_agent
    existing = workspace_agent(workspace, agent_type)
    if existing and existing.get("agent_id", "").startswith("did:key:"):
        typer.echo(f"Agent already registered: @{existing.get('username', '?')} ({existing['agent_id'][:24]}...)")
        raise typer.Exit(0)
    if not username:
        username = typer.prompt("Choose a username for this agent")
    svc = service()
    result = svc.register_agent(agent_type, workspace, username=username)
    try:
        svc.agent_create_remote(workspace, agent_type)
        result["remote"] = True
    except Exception:
        result["remote"] = False
    typer.echo(f"\nRegistered!")
    typer.echo(f"  Username: @{result['username']}")
    typer.echo(f"  DID:      {result['agent_id']}")
    typer.echo(f"  Type:     {result['agent_type']}")
    if result.get("remote"):
        typer.echo(f"  Remote:   registered on API")
    _emit_register_followup(result["agent_type"])


def _run_share(
    workspace: str,
    namespaces: str | None,
    password: str | None,
    message: str,
    workspace_mode: str,
    agent_type: str,
    process_scope: str,
    artifacts_public: bool,
    artifact: list[str] | None,
    current_user_message: str | None,
    current_assistant_message: str | None,
) -> None:
    from anyfs_local_state import workspace_agent
    agent = workspace_agent(workspace, agent_type)
    if not agent or not agent.get("agent_id"):
        typer.echo(f"Agent not registered for {agent_type}. Run `anyfs register --type {agent_type}` first.", err=True)
        raise typer.Exit(1)
    selected = [ns.strip() for ns in namespaces.split(",")] if namespaces else None
    result = service().quick_share(
        workspace,
        selected,
        password,
        agent_type,
        message=message,
        workspace_mode=workspace_mode,
        process_scope=process_scope,
        artifacts_public=artifacts_public,
        artifact_paths=artifact or None,
        current_user_message=current_user_message,
        current_assistant_message=current_assistant_message,
    )
    typer.echo(f"\nShare link(s):")
    for ns, info in result.get("shares", {}).items():
        if info.get("error"):
            typer.echo(f"  {ns}: {info['error']}")
        elif info.get("gateway_url"):
            typer.echo(f"  {ns}: {info['gateway_url']}")
        elif info.get("share_file"):
            typer.echo(f"  {ns}: {info['share_file']}")
    typer.echo(f"Password: {result['password']}")
    typer.echo(f"Message: {result['message']}")
    if result.get("handoff_text"):
        typer.echo("\nHandoff text:")
        typer.echo(result["handoff_text"])
    typer.echo("\nPaste the handoff text to your collaborator.")


@share_app.callback()
def share_command(
    ctx: typer.Context,
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    namespaces: str | None = typer.Option(None, "--namespaces", "-n", help="Comma-separated namespaces (default: all private)"),
    password: str | None = typer.Option(None, "--password", "-p", help="Share password (auto-generated if omitted)"),
    message: str | None = typer.Option(None, "--message", "-m", help="Required handoff note for the recipient"),
    workspace_mode: str = typer.Option("auto", "--workspace-mode", help="Workspace payload mode: auto, changed, full, none"),
    process_scope: str = typer.Option("current", "--process-scope", help="Process capture scope: current, all"),
    artifacts_public: bool = typer.Option(True, "--artifacts-public/--artifacts-private", help="Keep artifacts public in the snapshot (default: public)"),
    artifact: list[str] | None = typer.Option(None, "--artifact", help="Explicit artifact file or directory path. Repeat to include multiple artifacts."),
    agent_type: str = typer.Option(..., "--type", "-t", help="Agent type"),
    current_user_message: str | None = typer.Option(None, "--current-user-message", hidden=True),
    current_assistant_message: str | None = typer.Option(None, "--current-assistant-message", hidden=True),
) -> None:
    """Capture, encrypt, upload, and return a shareable link + password."""
    if ctx.invoked_subcommand is not None:
        return
    if not message:
        raise typer.BadParameter("Missing option '--message' / '-m'.", param_hint="--message")
    _run_share(
        workspace,
        namespaces,
        password,
        message,
        workspace_mode,
        agent_type,
        process_scope,
        artifacts_public,
        artifact,
        current_user_message,
        current_assistant_message,
    )


@app.command("open")
def open_command(
    share_paths: list[str] = typer.Argument(..., help="One or more share URLs or paths to .share.json files"),
    password: str = typer.Option(..., "--password", "-p", help="Password from the sender"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output directory"),
    resume: bool = typer.Option(False, "--resume", help="Auto-resume the session after decrypting"),
    agent_type: str = typer.Option(..., "--type", "-t", help="Current receiving client type"),
    target: str | None = typer.Option(None, "--target", help="Target agent for resume (default: auto-detect)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    register_username: str | None = typer.Option(
        None,
        "--register-username",
        help="After decrypting, auto-register a machine-level AnyFS agent with the given username",
    ),
) -> None:
    """Decrypt and load a shared context."""
    svc = service()
    # Auto-init if needed
    svc.init()
    try:
        svc.agent_status(workspace, agent_type)
    except Exception:
        if not register_username:
            typer.echo("", err=True)
            typer.echo(
                f"❌ {agent_type} is not registered with AnyFS on this machine yet.",
                err=True,
            )
            typer.echo(
                "   Register this client type before opening the shared context:",
                err=True,
            )
            typer.echo("", err=True)
            typer.echo(
                f"       anyfs register --type {agent_type} <your-username>",
                err=True,
            )
            typer.echo("", err=True)
            typer.echo(
                "   Or do it in one step by re-running this command with:",
                err=True,
            )
            typer.echo("", err=True)
            typer.echo(
                f"       --type {agent_type} --register-username <username>",
                err=True,
            )
            raise typer.Exit(1)
        try:
            reg = svc.register_agent(agent_type, workspace, register_username)
            svc.agent_create_remote(workspace, agent_type)
            typer.echo("\n✅ Registered AnyFS agent for this machine:")
            typer.echo(f"    Username: @{reg.get('username', '?')}")
            typer.echo(f"    Type: {reg['agent_type']}")
            typer.echo(f"    DID:  {reg['agent_id']}")
        except Exception as exc:
            typer.echo(f"\n❌ Auto-register failed: {exc}", err=True)
            typer.echo(
                f"   Run manually: anyfs register --type {agent_type} {register_username}",
                err=True,
            )
            raise typer.Exit(1)

    results = []
    for share_path in share_paths:
        result = svc.open_shared(share_path, password, output)
        results.append(result)
        typer.echo(f"\nDecrypted {result['namespace']} ({result['item_count']} items)")
        typer.echo(f"  Output: {result['output_file']}")
        if result.get("restore_dir"):
            typer.echo(f"  Restore dir: {result['restore_dir']}")
    # Show message once (same for all namespaces in a single share)
    msg = next((r["message"] for r in results if r.get("message")), None)
    if msg:
        typer.echo(f"\n  Message: {msg}")
    _emit_open_next_steps(results, workspace, target)
    if resume:
        process_results = [r for r in results if r["namespace"] == "process"]
        for result in process_results:
            from anyfs_transcript import load_transcripts
            transcripts = load_transcripts(result["output_file"])
            tgt = target or "claude-code"
            for t in transcripts:
                service().materialize_transcript_for_target(
                    t,
                    target_agent=tgt,
                    workspace=workspace,
                    mode="native",
                    source_agent=t.session.agent,
                    stable_identity=True,
                )
                typer.echo(f"  Resumed session {t.session.id} -> {tgt}")


# ── Core commands ────────────────────────────────────────────────

@app.command("init")
def init_command() -> None:
    """Initialize AnyFS (~/.anyfs, root key, identity)."""
    emit(service().init())


@app.command("doctor")
def doctor_command(workspace: str | None = typer.Option(None, help="Workspace path")) -> None:
    """Run workspace diagnostics."""
    emit(service().doctor(workspace))


@app.command("capture")
def capture_command(
    agent_type: str = typer.Argument(..., help="Agent type: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, or opencode"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    process_scope: str = typer.Option("all", "--process-scope", help="Process capture scope: all, current"),
    workspace_mode: str = typer.Option("changed", "--workspace-mode", help="Workspace overlay mode: changed, full, none"),
    client_scope: str = typer.Option("project", "--client-scope", help="Capture scope across clients: project, single"),
    artifact: list[str] | None = typer.Option(None, "--artifact", help="Explicit artifact file or directory path. Repeat to include multiple artifacts."),
) -> None:
    """Extract agent state from workspace into namespaces."""
    emit(
        service().capture(
            agent_type,
            workspace,
            process_scope=process_scope,
            workspace_mode=workspace_mode,
            client_scope=client_scope,
            artifact_paths=artifact or None,
        )
    )


@app.command("restore")
def restore_command(
    snapshot: str = typer.Option("latest", "--snapshot", "-s"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Decrypt and restore a snapshot to the workspace."""
    emit(service().restore(workspace, snapshot))


@app.command("backup")
def backup_command(
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    snapshot: str = typer.Option("latest", "--snapshot", "-s"),
    namespaces: str | None = typer.Option(None, "--namespaces", "-n", help="Comma-separated namespace list"),
) -> None:
    """Upload encrypted snapshot to cloud (API + storage gateway)."""
    selected = [item.strip() for item in namespaces.split(",")] if namespaces else None
    emit(service().backup_create(workspace, snapshot, selected))


@app.command("pack")
def pack_command(
    snapshot_id: str = typer.Argument(None, help="Snapshot ID (default: latest)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    output: str | None = typer.Option(None, "--output", "-o"),
    message: str | None = typer.Option(None, "--message", "-m", help="Human-readable package message"),
    visibility_mode: str = typer.Option("artifacts-public", "--visibility-mode", help="Publish visibility mode: all-public, artifacts-public, all-private"),
    visibility_policy: str | None = typer.Option(None, "--visibility-policy", help="Optional path to visibility policy file"),
    allow_secrets: bool = typer.Option(False, "--allow-secrets", help="Allow publish/package flow to continue when secret scan finds sensitive values"),
) -> None:
    """Build an AFPKG archive from a snapshot."""
    svc = service()
    _warn_all_public_visibility_mode(visibility_mode)
    if not snapshot_id:
        snapshots = svc.snapshot_list(workspace)
        if not snapshots:
            typer.echo("No snapshots found.", err=True)
            raise typer.Exit(1)
        snapshot_id = snapshots[-1]["snapshot_id"]
    emit(
        svc.pack(
            workspace,
            snapshot_id,
            output,
            message=message,
            visibility_policy_path=visibility_policy,
            visibility_mode=visibility_mode,
            allow_secrets=allow_secrets,
        )
    )


@app.command("publish")
def publish_command(
    archive_path: str = typer.Argument(None, help="Path to .afpkg (omit to auto-pack latest snapshot)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    message: str = typer.Option(..., "--message", "-m", help="Required human-readable package message"),
    visibility_mode: str = typer.Option("artifacts-public", "--visibility-mode", help="Publish visibility mode: all-public, artifacts-public, all-private"),
    visibility_policy: str | None = typer.Option(None, "--visibility-policy", help="Optional path to visibility policy file"),
    allow_secrets: bool = typer.Option(False, "--allow-secrets", help="Allow publish/package flow to continue when secret scan finds sensitive values"),
) -> None:
    """Publish a package to the registry. Auto-packs if no archive given."""
    svc = service()
    _warn_all_public_visibility_mode(visibility_mode)
    if not archive_path:
        snapshots = svc.snapshot_list(workspace)
        if not snapshots:
            typer.echo("No snapshots found. Run 'capture' and 'snapshot create' first.", err=True)
            raise typer.Exit(1)
        pack_result = svc.pack(
            workspace,
            snapshots[-1]["snapshot_id"],
            message=message,
            visibility_policy_path=visibility_policy,
            visibility_mode=visibility_mode,
            allow_secrets=allow_secrets,
        )
        archive_path = pack_result["archive_path"]
        emit(svc.publish(workspace, archive_path, message=message, allow_secrets=allow_secrets))
        return
    emit(
        svc.publish(
            workspace,
            archive_path,
            message=message,
            visibility_policy_path=visibility_policy,
            visibility_mode=visibility_mode,
            allow_secrets=allow_secrets,
        )
    )


@app.command("fork")
def fork_command(
    package_id: str = typer.Argument(...),
    child_username: str = typer.Option("forked-package", "--child-display-name"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Fork a published package."""
    emit(service().fork(workspace, package_id, child_username))


@app.command("buy")
def buy_command(
    package_id: str = typer.Argument(...),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    child_username: str = typer.Option("purchased-package", "--child-display-name"),
    output: str | None = typer.Option(None, "--output", "-o"),
    resume_target: str | None = typer.Option(None, "--resume", "-r", help="Optionally resume installed process context into a target agent"),
) -> None:
    """Fork a published package, install it locally, and optionally resume its process context."""
    emit(service().buy(workspace, package_id, child_username, output_dir=output, resume_target=resume_target))


@app.command("resume")
def resume_command(
    transcript_path: str = typer.Argument(..., help="Path to a transcript file, canonical process bundle, or share URL/file"),
    target: str = typer.Option(..., "--target", "-t", help="Target agent: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, opencode, cursor"),
    source: str | None = typer.Option(None, "--source", "-s", help="Source agent type (auto-detected if omitted)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    password: str | None = typer.Option(None, "--password", "-p", help="Share password when transcript_path is a share URL or .share.json"),
    native: bool = typer.Option(True, "--native/--context-only", help="Generate native transcript (default) or context-only injection"),
    json_output: bool = typer.Option(False, "--json", help="Print the raw JSON resume report instead of the summary"),
) -> None:
    """Resume a session from one agent in another.

    Default (--native): generates a real native transcript file that the target
    client can load as a previous session with full tool call history.

    --context-only: injects a compressed context summary into the target client's
    instruction file (AGENTS.md, CLAUDE.md memory, .cursor/rules, GEMINI.md).
    """
    from anyfs_transcript import load_transcripts

    svc = service()
    resolved_source = transcript_path
    opened_share: dict[str, str] | None = None
    if _looks_like_share_artifact(transcript_path):
        if not password:
            typer.echo("share resume requires --password", err=True)
            raise typer.Exit(1)
        opened_dir = Path(tempfile.mkdtemp(prefix="anyfs-resume-share-"))
        opened_share = svc.open_shared(transcript_path, password, str(opened_dir))
        if opened_share["namespace"] != "process":
            typer.echo(
                f"resume requires a process share, got namespace: {opened_share['namespace']}",
                err=True,
            )
            raise typer.Exit(1)
        resolved_source = opened_share["output_file"]

    transcripts = load_transcripts(resolved_source, agent_type=source)

    if not native and len(transcripts) > 1:
        typer.echo(
            "context-only resume requires exactly one transcript. "
            "Pick one session from the canonical process bundle or use native export.",
            err=True,
        )
        raise typer.Exit(1)

    try:
        mode = "native" if native else "context"
        results = []
        for transcript in transcripts:
            session_entry = svc.materialize_transcript_for_target(
                transcript,
                target_agent=target,
                workspace=workspace,
                mode=mode,
                source_agent=transcript.session.agent,
                stable_identity=native,
            )
            results.append({"transcript": transcript, "session": session_entry})
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc

    skills_import: dict[str, object] | None = None
    skills_payload_path = Path(resolved_source).with_name("skills.json")
    if skills_payload_path.exists():
        try:
            source_agent = source or (transcripts[0].session.agent if transcripts else "unknown")
            skills_import = svc.materialize_namespace_payload_for_target(
                str(skills_payload_path),
                namespace="skills",
                target_agent=target,
                workspace=workspace,
                source_agent=source_agent,
            )
            import_hint = skills_import.get("import_hint")
            if isinstance(import_hint, str) and import_hint.strip():
                for item in results:
                    files_written = item["session"].setdefault("files_written", {})
                    files_written["import_hint"] = import_hint
                    item["session"]["target_open_hint"] = svc._target_session_open_hint(target, files_written)
        except ValueError as exc:
            typer.echo(f"warning: could not materialize skills payload: {exc}", err=True)

    if len(results) == 1:
        transcript = results[0]["transcript"]
        session = results[0]["session"]
        files_written = session["files_written"]
        payload = {
            "source_agent": transcript.session.agent,
            "source_session_id": transcript.session.id,
            "source_model": transcript.session.model,
            "source_events": len(transcript.events),
            "target_agent": target,
            "mode": mode,
            "resolved_source": resolved_source,
            "files_written": files_written,
            "sessions": [session],
        }
        if opened_share:
            payload["opened_share"] = opened_share
        if skills_import:
            payload["skills_import"] = skills_import
        if "resume_hint" in files_written:
            payload["resume_hint"] = files_written["resume_hint"]
        if session.get("source_session_preview"):
            payload["source_session_preview"] = session["source_session_preview"]
        if session.get("source_session_display_preview"):
            payload["source_session_display_preview"] = session["source_session_display_preview"]
        if session.get("target_open_hint"):
            payload["target_open_hint"] = session["target_open_hint"]
        if json_output:
            emit(payload)
        else:
            _emit_resume_summary(payload)
        return

    payload = {
        "target_agent": target,
        "mode": mode,
        "resolved_source": resolved_source,
        "transcript_count": len(results),
        "sessions": [
            {
                **item["session"],
                "source_model": item["transcript"].session.model,
                "source_events": len(item["transcript"].events),
            }
            for item in results
        ],
        **({"opened_share": opened_share} if opened_share else {}),
        **({"skills_import": skills_import} if skills_import else {}),
    }
    if json_output:
        emit(payload)
    else:
        _emit_resume_summary(payload)


@app.command("migrate")
def migrate_command(
    source_agent: str = typer.Option(..., "--from", help="Source agent type"),
    target_agent: str = typer.Option(..., "--to", help="Target agent type"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    target_workspace: str | None = typer.Option(None, "--target-workspace", help="Target workspace path (defaults to --workspace)"),
    mode: str = typer.Option("auto", "--mode", help="Migration mode: auto, code, or personal"),
    preset: str | None = typer.Option(None, "--preset", hidden=True),
    include_secrets: bool = typer.Option(False, "--include-secrets/--no-include-secrets", help="Include source runtime secrets and provider keys"),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite existing imported files"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview migration without writing files"),
    json_output: bool = typer.Option(False, "--json", help="Print the raw JSON migration report before the summary"),
) -> None:
    """Import migratable context from one agent format into another."""
    svc = service()
    status_message = (
        f"Migrating {source_agent} -> {target_agent} "
        f"({'dry-run' if dry_run else 'applying'})"
    )
    if Console is not None:
        console = Console()
        if console.is_terminal:
            with console.status(f"[bold cyan]{status_message}[/bold cyan]", spinner="dots"):
                result = svc.migrate_context(
                    source_agent,
                    target_agent,
                    workspace,
                    target_workspace=target_workspace,
                    overwrite=overwrite,
                    dry_run=dry_run,
                    mode=mode,
                    include_secrets=include_secrets,
                    preset=preset,
                )
        else:
            result = svc.migrate_context(
                source_agent,
                target_agent,
                workspace,
                target_workspace=target_workspace,
                overwrite=overwrite,
                dry_run=dry_run,
                mode=mode,
                include_secrets=include_secrets,
                preset=preset,
            )
    else:
        result = svc.migrate_context(
            source_agent,
            target_agent,
            workspace,
            target_workspace=target_workspace,
            overwrite=overwrite,
            dry_run=dry_run,
            mode=mode,
            include_secrets=include_secrets,
            preset=preset,
        )
    if json_output:
        emit(result)
    _emit_migration_summary(result)


def _looks_like_share_artifact(value: str) -> bool:
    return value.startswith(("http://", "https://")) or value.endswith(".share.json")


@app.command("export-recovery")
def export_recovery(output: str | None = typer.Option(None, "--output", "-o")) -> None:
    """Export recovery key bundle for backup."""
    emit(service().export_recovery(output))


@app.command("import-recovery")
def import_recovery(path: str = typer.Argument(...)) -> None:
    """Import a recovery key bundle."""
    emit(service().import_recovery(path))


# ── Auth ─────────────────────────────────────────────────────────

@auth_app.command("register")
def auth_register(
    email: str = typer.Option(..., "--email", help="Email address"),
    password: str = typer.Option(..., "--password", prompt=True, hide_input=True, confirmation_prompt=True, help="Account password"),
) -> None:
    """Create a human account with email and password."""
    emit(service().auth_register(email, password))


@auth_app.command("login")
def auth_login(
    email: str = typer.Option(..., "--email", help="Email address"),
    password: str = typer.Option(..., "--password", prompt=True, hide_input=True, help="Account password"),
) -> None:
    """Login with email and password."""
    emit(service().auth_login(email, password))


# ── Agent ────────────────────────────────────────────────────────

@agent_app.command("register")
def register_agent(
    agent_type: str = typer.Argument(..., help="Agent type: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, or opencode"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    username: str | None = typer.Option(None, "--username"),
    remote: bool = typer.Option(True, "--remote/--no-remote", help="Also register on remote API"),
) -> None:
    """Register an agent locally (and optionally on the remote API)."""
    svc = service()
    result = svc.register_agent(agent_type, workspace, username=username)
    if remote:
        try:
            svc.agent_create_remote(workspace, agent_type)
            result["remote"] = True
        except Exception:
            result["remote"] = False
    emit(result)
    _emit_register_followup(result["agent_type"])


@agent_app.command("status")
def agent_status(
    agent_type: str | None = typer.Option(None, "--type", "-t", help="Agent type to inspect for this workspace"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Check local and remote agent status."""
    emit(service().agent_status(workspace, agent_type))


@agent_app.command("bind")
def agent_bind(
    email: str = typer.Option(..., "--email", help="Email address of the user account to bind"),
    password: str = typer.Option(..., "--password", help="Password of the user account to bind"),
    agent_type: str | None = typer.Option(None, "--type", "-t", help="Agent type to bind for this workspace"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Bind an agent to a user account via email and password."""
    emit(service().agent_bind(workspace, email, password, agent_type))


@agent_app.command("username")
def agent_username(
    username: str = typer.Argument(..., help="New username for this agent"),
    agent_type: str | None = typer.Option(None, "--type", "-t", help="Agent type to update for this workspace"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Update the username for an existing agent locally and on the remote API."""
    result = service().agent_set_username(workspace, username, agent_type)
    typer.echo("\nUsername updated!")
    typer.echo(f"  Username: @{result['username']}")
    typer.echo(f"  DID:      {result['agent_id']}")
    typer.echo(f"  Type:     {result['agent_type']}")


# ── Snapshot ─────────────────────────────────────────────────────

@snapshot_app.command("create")
def snapshot_create(
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    artifacts_public: bool = typer.Option(True, "--artifacts-public/--artifacts-private", help="Keep artifacts public in the snapshot (default: public)"),
) -> None:
    """Create an encrypted snapshot from the latest capture."""
    emit(service().snapshot_create(workspace, artifacts_public=artifacts_public))


@snapshot_app.command("list")
def snapshot_list(workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w")) -> None:
    """List all snapshots."""
    emit({"items": service().snapshot_list(workspace)})


# ── Share ────────────────────────────────────────────────────────

@share_app.command("namespace")
def share_namespace(
    namespace: str = typer.Argument(..., help="Namespace to share (e.g. memory, soul, skills, workspace)"),
    password: str = typer.Option(..., "--password", "-p", help="Password for the recipient"),
    message: str = typer.Option(..., "--message", "-m", help="Required handoff note for the recipient"),
    workspace_mode: str = typer.Option("changed", "--workspace-mode", help="Workspace payload mode when namespace=workspace"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    snapshot: str = typer.Option("latest", "--snapshot", "-s"),
) -> None:
    """Share a single namespace with a password. Recipient decrypts without your root key."""
    emit(service().share_namespace(workspace, namespace, password, snapshot, message=message, workspace_mode=workspace_mode))


@share_app.command("open")
def share_open(
    share_path: str = typer.Argument(..., help="Path to .share.json file or share URL"),
    password: str = typer.Option(..., "--password", "-p", help="Password from the sender"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output directory"),
) -> None:
    """Decrypt a shared file using the share password. No root key needed."""
    emit(service().open_shared(share_path, password, output))


@share_app.command("list")
def share_list(workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w")) -> None:
    """List share links."""
    emit({"items": service().list_links(workspace)})


# ── Release ──────────────────────────────────────────────────────

@release_app.command("create")
def release_create(
    package_id: str = typer.Argument(...),
    version: str = typer.Option(..., "--version", "-v"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Create a versioned release from a published package."""
    emit(service().release_create(workspace, package_id, version))


# ── Lineage ──────────────────────────────────────────────────────

@lineage_app.command("show")
def lineage_show(
    package_id: str = typer.Argument(...),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Show package lineage (fork history)."""
    emit(service().lineage_show(workspace, package_id))


# ── Friends ──────────────────────────────────────────────────────


@friend_app.command("add")
def friend_add(
    identifier: str = typer.Argument(..., help="Username (e.g. bob-codex) or DID (did:key:z6Mk...)"),
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Send a friend request by username or DID key."""
    result = service().friend_add(workspace, identifier, agent_type)
    label = f"@{result.get('to_username')}" if result.get("to_username") else result.get("to_agent_id", identifier)
    typer.echo(f"Friend request sent to {label} (request_id: {result['request_id']})")


@friend_app.command("list")
def friend_list(
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """List all friends."""
    friends = service().friend_list(workspace, agent_type)
    if not friends:
        typer.echo("No friends yet. Add one with: anyfs friend add <username>")
        return
    for f in friends:
        typer.echo(f"  @{f.get('username', '?'):20s}  ({f.get('agent_type', '')})")


@friend_app.command("requests")
def friend_requests_cmd(
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """List pending incoming friend requests."""
    reqs = service().friend_requests(workspace, agent_type)
    if not reqs:
        typer.echo("No pending friend requests.")
        return
    for r in reqs:
        typer.echo(f"  {r['request_id']}  from @{r.get('from_username', '?')}  ({r.get('created_at', '')[:10]})")


@friend_app.command("accept")
def friend_accept(
    request_id: str = typer.Argument(..., help="Friend request ID to accept"),
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Accept a friend request."""
    result = service().friend_accept(workspace, request_id, agent_type)
    typer.echo(f"Accepted friend request from @{result.get('from_username', '?')}")


@friend_app.command("reject")
def friend_reject(
    request_id: str = typer.Argument(..., help="Friend request ID to reject"),
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Reject a friend request."""
    service().friend_reject(workspace, request_id, agent_type)
    typer.echo("Request rejected.")


@friend_app.command("remove")
def friend_remove(
    username: str = typer.Argument(..., help="Username of the friend to remove"),
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Remove a friend."""
    service().friend_remove(workspace, username, agent_type)
    typer.echo(f"Removed @{username} from friends.")


# ── Airdrop / Receive ────────────────────────────────────────────


# ── LAN airdrop helpers ──────────────────────────────────────────

_LAN_PORT = 19532
_LAN_MAGIC = "anyfs-airdrop"


def _get_local_ip() -> str:
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _lan_broadcast(urls: list[str], password: str, name: str, message: str, duration: int = 300) -> None:
    import socket, time
    payload = json.dumps({
        "type": _LAN_MAGIC, "name": name, "urls": urls,
        "password": password, "message": message, "host": _get_local_ip(),
    }).encode()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(1)
    local_ip = _get_local_ip()
    typer.echo(f"\nBroadcasting on LAN (UDP {_LAN_PORT}) from {local_ip}...")
    typer.echo(f"Other machine: anyfs receive --lan --type <type>")
    typer.echo(f"Press Ctrl+C to stop.\n")
    deadline = time.time() + duration
    try:
        while time.time() < deadline:
            try:
                sock.sendto(payload, ("255.255.255.255", _LAN_PORT))
            except OSError:
                pass
            time.sleep(2)
    except KeyboardInterrupt:
        pass
    finally:
        sock.close()
        typer.echo("Broadcast stopped.")


def _lan_listen(timeout: int = 120) -> dict | None:
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    except (AttributeError, OSError):
        pass
    sock.bind(("", _LAN_PORT))
    sock.settimeout(2)
    local_ip = _get_local_ip()
    typer.echo(f"Listening for LAN airdrops on UDP {_LAN_PORT} (timeout {timeout}s)...")
    import time
    deadline = time.time() + timeout
    try:
        while time.time() < deadline:
            try:
                data, addr = sock.recvfrom(65535)
            except socket.timeout:
                continue
            try:
                msg = json.loads(data.decode())
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            if msg.get("type") != _LAN_MAGIC:
                continue
            if msg.get("host") == local_ip:
                continue
            typer.echo(f"Received airdrop from {msg.get('name', '?')} ({addr[0]}): {msg.get('message', '')}")
            return msg
    except KeyboardInterrupt:
        pass
    finally:
        sock.close()
    return None


# ── Airdrop / Receive ────────────────────────────────────────────


@app.command("airdrop")
def airdrop_command(
    to_username: str | None = typer.Option(None, "--to", help="Friend's username (platform mode)"),
    lan: bool = typer.Option(False, "--lan", help="Broadcast on LAN instead of platform"),
    message: str = typer.Option("", "--message", "-m"),
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    namespaces: str | None = typer.Option(None, "--namespaces", "-n"),
    password: str | None = typer.Option(None, "--password", "-p"),
    workspace_mode: str = typer.Option("auto", "--workspace-mode"),
    process_scope: str = typer.Option("current", "--process-scope"),
) -> None:
    """Airdrop session to a friend (--to) or broadcast on LAN (--lan)."""
    if not to_username and not lan:
        typer.echo("Specify --to <username> (platform) or --lan (local network).", err=True)
        raise typer.Exit(1)
    if to_username and lan:
        typer.echo("Use --to or --lan, not both.", err=True)
        raise typer.Exit(1)
    if not message:
        message = typer.prompt("Handoff message")

    svc = service()

    if to_username:
        # Platform mode: share + push to friend's inbox
        try:
            result = svc.platform_airdrop(
                workspace, to_username, agent_type,
                namespaces=[n.strip() for n in namespaces.split(",")] if namespaces else None,
                password=password, message=message,
                workspace_mode=workspace_mode, process_scope=process_scope,
            )
            typer.echo(f"\nAirdropped to @{to_username}!")
            typer.echo(f"  Airdrop ID: {result['airdrop']['airdrop_id']}")
            typer.echo(f"  Namespaces: {len(result['share'].get('shares', {}))}")
            typer.echo(f"\n@{to_username} can pick it up anytime with: anyfs receive --type <their-type>")
        except Exception as exc:
            typer.echo(f"Airdrop failed: {exc}", err=True)
            raise typer.Exit(1)
    else:
        # LAN mode: share + UDP broadcast
        from anyfs_local_state import workspace_agent
        agent = workspace_agent(workspace, agent_type)
        if not agent or not agent.get("agent_id"):
            typer.echo(f"Agent not registered for {agent_type}. Run `anyfs register --type {agent_type}` first.", err=True)
            raise typer.Exit(1)
        selected = [ns.strip() for ns in namespaces.split(",")] if namespaces else None
        result = svc.quick_share(
            workspace, selected, password, agent_type,
            message=message, workspace_mode=workspace_mode, process_scope=process_scope,
        )
        urls = [info.get("gateway_url") or info.get("share_file") for ns, info in result.get("shares", {}).items() if info.get("gateway_url") or info.get("share_file")]
        typer.echo(f"\nShare link(s):")
        for ns, info in result.get("shares", {}).items():
            if info.get("gateway_url"):
                typer.echo(f"  {ns}: {info['gateway_url']}")
        typer.echo(f"Password: {result['password']}")
        _lan_broadcast(urls, result["password"], agent.get("username", ""), message)


@app.command("receive")
def receive_command(
    lan: bool = typer.Option(False, "--lan", help="Listen on LAN instead of platform inbox"),
    agent_type: str = typer.Option("claude-code", "--type", "-t"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    timeout: int = typer.Option(120, "--timeout", help="LAN listen timeout in seconds"),
) -> None:
    """Check platform inbox or listen on LAN for airdrops."""
    svc = service()

    if lan:
        # LAN mode: listen for UDP broadcasts
        msg = _lan_listen(timeout=timeout)
        if not msg:
            typer.echo("No LAN airdrop received.")
            return
        urls = msg.get("urls", [])
        pw = msg.get("password", "")
        for url in urls:
            try:
                result = svc.open_shared(url, pw)
                ns = result.get("namespace", "?")
                count = result.get("item_count", "?")
                typer.echo(f"  Opened: {ns} ({count} items) → {result.get('output_path', '')}")
            except Exception as exc:
                typer.echo(f"  Failed to open {url}: {exc}", err=True)
    else:
        # Platform mode: check inbox
        inbox = svc.airdrop_inbox(workspace, agent_type)
        if not inbox:
            typer.echo("No pending airdrops in inbox.")
            return
        for item in inbox:
            typer.echo(f"\nAirdrop from @{item.get('from_username', '?')}: {item.get('message', '')}")
            for url in item.get("share_urls", []):
                try:
                    result = svc.open_shared(url, item["password"])
                    ns = result.get("namespace", "?")
                    count = result.get("item_count", "?")
                    typer.echo(f"  Opened: {ns} ({count} items) → {result.get('output_path', '')}")
                except Exception as exc:
                    typer.echo(f"  Failed to open {url}: {exc}", err=True)
            try:
                svc.airdrop_mark_opened(workspace, item["airdrop_id"], agent_type)
            except Exception:
                pass
            typer.echo(f"  Status: opened")


if __name__ == "__main__":
    app()
