"""Tests for MCP sampling bridge (``synth_panel.mcp.sampling``).

Covers the four routing branches required by sp-6at:

1. sampling supported + no creds  → sampling path
2. sampling supported + creds     → BYOK path (default)
3. sampling supported + creds + ``use_sampling=True`` → sampling path
4. no sampling + no creds         → friendly error
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

pytest.importorskip("mcp")


# ---------------------------------------------------------------------------
# Env fixture — sampling tests own their env explicitly, overriding the
# BYOK-simulating default from tests/test_mcp_server.py.
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_env(tmp_path, monkeypatch):
    """Scrub provider env vars — sampling tests opt into them per-case."""
    monkeypatch.setenv("SYNTH_PANEL_DATA_DIR", str(tmp_path))
    for var in (
        "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY",
        "XAI_API_KEY",
        "GOOGLE_API_KEY",
        "GEMINI_API_KEY",
        "OPENROUTER_API_KEY",
    ):
        monkeypatch.delenv(var, raising=False)


# ---------------------------------------------------------------------------
# Unit tests for the pure helpers in synth_panel.mcp.sampling
# ---------------------------------------------------------------------------


class TestHasByokCredentials:
    def test_no_creds_returns_false(self):
        from synth_panel.mcp.sampling import has_byok_credentials

        assert has_byok_credentials({}) is False

    def test_any_known_var_returns_true(self, monkeypatch):
        from synth_panel.mcp.sampling import has_byok_credentials

        # Must cover every provider the CLI auto-detects, otherwise a user
        # whose only key is (e.g.) OPENROUTER_API_KEY gets misrouted into
        # sampling or a "missing credentials" error despite the CLI
        # recognising the same key (see sp-t6r).
        for var in (
            "ANTHROPIC_API_KEY",
            "OPENAI_API_KEY",
            "XAI_API_KEY",
            "GOOGLE_API_KEY",
            "GEMINI_API_KEY",
            "OPENROUTER_API_KEY",
        ):
            assert has_byok_credentials({var: "x"}) is True, var

    def test_openrouter_key_is_recognised_in_decide_mode(self):
        from synth_panel.mcp.sampling import decide_mode

        # sp-t6r regression: OPENROUTER_API_KEY must route to BYOK, not
        # sampling, even when the client supports sampling — otherwise we
        # silently downgrade users with a valid provider key.
        ctx = MagicMock()
        ctx.session.check_client_capability.return_value = True
        d = decide_mode(ctx, env={"OPENROUTER_API_KEY": "sk-or-x"})
        assert d.mode == "byok"

    def test_empty_string_is_not_creds(self):
        from synth_panel.mcp.sampling import has_byok_credentials

        assert has_byok_credentials({"ANTHROPIC_API_KEY": "   "}) is False

    def test_stored_credential_counts_as_byok(self, tmp_path, monkeypatch):
        """sp-mkpo: ``synthpanel login`` keys must satisfy MCP BYOK.

        A user who persists OPENROUTER_API_KEY via ``synthpanel login``
        and launches mcp-serve from a client that doesn't inherit the
        shell env (Claude Desktop bundles, Docker, systemd units) would
        otherwise see a bogus 'No provider credentials' error even
        though the CLI finds the same key.
        """
        from synth_panel.credentials import save_credential
        from synth_panel.mcp.sampling import decide_mode, has_byok_credentials

        monkeypatch.setenv("SYNTHPANEL_CREDENTIALS_PATH", str(tmp_path / "creds.json"))
        save_credential("OPENROUTER_API_KEY", "sk-or-stored")

        # Default path (env=None) must consult both sources.
        assert has_byok_credentials() is True
        # Explicit env override stays hermetic — only that dict is consulted.
        assert has_byok_credentials({}) is False

        ctx = MagicMock()
        ctx.session.check_client_capability.return_value = False
        assert decide_mode(ctx).mode == "byok"

    def test_stored_gemini_credential_counts_as_byok(self, tmp_path, monkeypatch):
        from synth_panel.credentials import save_credential
        from synth_panel.mcp.sampling import has_byok_credentials

        monkeypatch.setenv("SYNTHPANEL_CREDENTIALS_PATH", str(tmp_path / "creds.json"))
        save_credential("GEMINI_API_KEY", "g-stored")

        assert has_byok_credentials() is True

    def test_default_model_picks_provider_from_stored_credential(self, tmp_path, monkeypatch):
        """sp-mkpo: _resolve_mcp_default_model must also see disk creds.

        Without this the default alias stays 'haiku' (Anthropic) even
        for an OpenRouter-only user, so the LLM client raises a
        misleading ANTHROPIC_API_KEY error.
        """
        from synth_panel.credentials import save_credential
        from synth_panel.mcp.server import _resolve_mcp_default_model

        monkeypatch.setenv("SYNTHPANEL_CREDENTIALS_PATH", str(tmp_path / "creds.json"))
        save_credential("OPENROUTER_API_KEY", "sk-or-stored")

        assert _resolve_mcp_default_model() == "openrouter/auto"


class TestClientSupportsSampling:
    def test_none_ctx_returns_false(self):
        from synth_panel.mcp.sampling import client_supports_sampling

        assert client_supports_sampling(None) is False

    def test_session_raising_property_returns_false(self):
        """``ctx.session`` outside a request raises — must not propagate."""
        from synth_panel.mcp.sampling import client_supports_sampling

        ctx = MagicMock()
        # Simulate FastMCP Context.session property raising ValueError
        type(ctx).session = property(lambda self: (_ for _ in ()).throw(ValueError("outside request")))
        assert client_supports_sampling(ctx) is False

    def test_session_check_returns_true(self):
        from synth_panel.mcp.sampling import client_supports_sampling

        ctx = MagicMock()
        ctx.session.check_client_capability.return_value = True
        assert client_supports_sampling(ctx) is True

    def test_session_check_returns_false(self):
        from synth_panel.mcp.sampling import client_supports_sampling

        ctx = MagicMock()
        ctx.session.check_client_capability.return_value = False
        assert client_supports_sampling(ctx) is False


class TestDecideMode:
    """The four-branch routing matrix — the heart of the acceptance tests."""

    def _ctx(self, *, supports: bool):
        ctx = MagicMock()
        ctx.session.check_client_capability.return_value = supports
        return ctx

    def test_auto_sampling_supported_no_creds_picks_sampling(self):
        from synth_panel.mcp.sampling import decide_mode

        d = decide_mode(self._ctx(supports=True), env={})
        assert d.mode == "sampling"
        assert d.hint is not None  # first-run hint

    def test_auto_sampling_supported_with_creds_picks_byok(self):
        from synth_panel.mcp.sampling import decide_mode

        d = decide_mode(
            self._ctx(supports=True),
            env={"ANTHROPIC_API_KEY": "sk-x"},
        )
        assert d.mode == "byok"
        assert d.hint is None

    def test_auto_no_sampling_no_creds_returns_friendly_error(self):
        from synth_panel.mcp.sampling import decide_mode

        d = decide_mode(self._ctx(supports=False), env={})
        assert d.mode == "error"
        assert d.error is not None
        assert "ANTHROPIC_API_KEY" in d.error
        assert "sampling-capable" in d.error

    def test_explicit_use_sampling_true_with_creds_picks_sampling(self):
        from synth_panel.mcp.sampling import decide_mode

        d = decide_mode(
            self._ctx(supports=True),
            use_sampling=True,
            env={"ANTHROPIC_API_KEY": "sk-x"},
        )
        assert d.mode == "sampling"

    def test_explicit_use_sampling_true_but_unsupported_errors(self):
        from synth_panel.mcp.sampling import decide_mode

        d = decide_mode(self._ctx(supports=False), use_sampling=True, env={})
        assert d.mode == "error"
        assert "use_sampling=True" in d.error

    def test_explicit_use_sampling_false_forces_byok(self):
        from synth_panel.mcp.sampling import decide_mode

        d = decide_mode(self._ctx(supports=True), use_sampling=False, env={})
        assert d.mode == "byok"


# ---------------------------------------------------------------------------
# Integration — run_prompt across the four branches
# ---------------------------------------------------------------------------


def _make_sampling_ctx(
    supports: bool,
    *,
    sample_text: str = "sampled!",
    stop_reason: str = "endTurn",
):
    """Build a MagicMock Context that the tool can invoke without
    hitting the FastMCP test harness's Context auto-injection path."""
    ctx = MagicMock()
    ctx.session.check_client_capability.return_value = supports

    async def _create_message(**kwargs: Any):
        # Mimic CreateMessageResult — only the fields _sample_text reads.
        msg = MagicMock()
        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = sample_text
        msg.content = text_block
        msg.model = "host-agent-model"
        msg.role = "assistant"
        msg.stopReason = stop_reason
        return msg

    ctx.session.create_message = AsyncMock(side_effect=_create_message)
    ctx.report_progress = AsyncMock()
    return ctx


class TestRunPromptSamplingBranches:
    @pytest.mark.asyncio
    async def test_sampling_supported_no_creds_uses_sampling(self):
        from synth_panel.mcp.server import run_prompt

        ctx = _make_sampling_ctx(supports=True, sample_text="hi from host")
        raw = await run_prompt(prompt="Say hi", ctx=ctx)
        data = json.loads(raw)

        assert data["mode"] == "sampling"
        assert data["response"] == "hi from host"
        assert data["model"] == "host-agent-model"
        assert data["hint"] is not None
        ctx.session.create_message.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_sampling_supported_with_creds_uses_byok(self, monkeypatch):
        from synth_panel.llm.models import CompletionResponse, TextBlock, TokenUsage
        from synth_panel.mcp.server import run_prompt

        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        ctx = _make_sampling_ctx(supports=True)

        mock_response = CompletionResponse(
            id="r",
            model="claude-haiku-4-5-20251001",
            content=[TextBlock(text="byok-output")],
            usage=TokenUsage(input_tokens=3, output_tokens=2),
        )
        with (
            patch("synth_panel.mcp.server._shared_client", None),
            patch("synth_panel.mcp.server.LLMClient") as MockClient,
        ):
            MockClient.return_value.send.return_value = mock_response
            raw = await run_prompt(prompt="Hi", ctx=ctx)

        data = json.loads(raw)
        assert data["mode"] == "byok"
        assert data["response"] == "byok-output"
        ctx.session.create_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_explicit_use_sampling_overrides_creds(self, monkeypatch):
        from synth_panel.mcp.server import run_prompt

        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        ctx = _make_sampling_ctx(supports=True, sample_text="sampled-anyway")

        raw = await run_prompt(prompt="Hi", use_sampling=True, ctx=ctx)
        data = json.loads(raw)

        assert data["mode"] == "sampling"
        assert data["response"] == "sampled-anyway"

    @pytest.mark.asyncio
    async def test_no_sampling_no_creds_returns_friendly_error(self):
        from synth_panel.mcp.server import run_prompt

        ctx = _make_sampling_ctx(supports=False)
        raw = await run_prompt(prompt="Hi", ctx=ctx)
        data = json.loads(raw)

        assert "error" in data
        assert "ANTHROPIC_API_KEY" in data["error"]
        ctx.session.create_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_use_sampling_true_but_unsupported_errors(self):
        from synth_panel.mcp.server import run_prompt

        ctx = _make_sampling_ctx(supports=False)
        raw = await run_prompt(prompt="Hi", use_sampling=True, ctx=ctx)
        data = json.loads(raw)

        assert "error" in data
        assert "use_sampling=True" in data["error"]


class TestAcceptMultimodalSamplingFlag:
    """T6 feature flag: opt into preserving image blocks from MCP host.

    Default-off preserves the silent-drop semantics callers depended on
    before hq-l0lw. The flag is per-call and lives on every tool that
    can hit the sampling pathway (run_prompt / run_panel / run_quick_poll
    / extend_panel — though extend_panel doesn't currently sample).
    """

    @pytest.mark.asyncio
    async def test_default_off_does_not_emit_content_blocks(self):
        from synth_panel.mcp.server import run_prompt

        ctx = _make_sampling_ctx(supports=True, sample_text="just text")
        raw = await run_prompt(prompt="Hi", ctx=ctx)
        data = json.loads(raw)
        # Default-off: no content_blocks key, only the flat string.
        assert "content_blocks" not in data
        assert data["response"] == "just text"

    @pytest.mark.asyncio
    async def test_flag_on_surfaces_text_blocks(self):
        from synth_panel.mcp.server import run_prompt

        ctx = _make_sampling_ctx(supports=True, sample_text="hi from host")
        raw = await run_prompt(prompt="Hi", accept_multimodal_sampling=True, ctx=ctx)
        data = json.loads(raw)
        assert "content_blocks" in data
        # MCP host returned a single TextContent → one TextBlock entry.
        assert data["content_blocks"] == [{"type": "text", "text": "hi from host"}]

    @pytest.mark.asyncio
    async def test_flag_on_surfaces_image_blocks(self):
        # Build a context whose MCP create_message returns a multimodal
        # response (text + image). The flag should surface BOTH; the
        # legacy `response` field still carries text only.
        from synth_panel.mcp.server import run_prompt

        ctx = MagicMock()
        ctx.session.check_client_capability.return_value = True

        async def _create_message(**kwargs: Any):
            msg = MagicMock()
            text_block = MagicMock()
            text_block.type = "text"
            text_block.text = "see image"
            image_block = MagicMock()
            image_block.type = "image"
            image_block.data = "AAAA"
            image_block.mimeType = "image/png"
            msg.content = [text_block, image_block]
            msg.model = "host-model"
            msg.role = "assistant"
            msg.stopReason = "endTurn"
            return msg

        ctx.session.create_message = AsyncMock(side_effect=_create_message)
        ctx.report_progress = AsyncMock()

        raw = await run_prompt(prompt="Hi", accept_multimodal_sampling=True, ctx=ctx)
        data = json.loads(raw)
        assert data["response"] == "see image"
        assert {"type": "text", "text": "see image"} in data["content_blocks"]
        image_entries = [b for b in data["content_blocks"] if b["type"] == "image"]
        assert len(image_entries) == 1
        assert image_entries[0]["source"] == {
            "type": "base64",
            "media_type": "image/png",
            "data": "AAAA",
        }


# ---------------------------------------------------------------------------
# Integration — run_quick_poll sampling path
# ---------------------------------------------------------------------------


class TestRunQuickPollSampling:
    @pytest.mark.asyncio
    async def test_sampling_runs_per_persona_and_synthesis(self):
        from synth_panel.mcp.server import run_quick_poll

        ctx = _make_sampling_ctx(supports=True, sample_text="persona response")
        personas = [{"name": "Alice"}, {"name": "Bob"}]
        raw = await run_quick_poll(
            question="Is the sky blue?",
            personas=personas,
            ctx=ctx,
        )
        data = json.loads(raw)

        assert data["mode"] == "sampling"
        assert data["persona_count"] == 2
        assert data["question_count"] == 1
        assert len(data["results"]) == 2
        assert data["synthesis"] is not None
        # 2 persona calls + 1 synthesis call
        assert ctx.session.create_message.await_count == 3

    @pytest.mark.asyncio
    async def test_sampling_persona_cap_enforced(self):
        from synth_panel.mcp.server import SAMPLING_MAX_PERSONAS, run_quick_poll

        ctx = _make_sampling_ctx(supports=True)
        personas = [{"name": f"P{i}"} for i in range(SAMPLING_MAX_PERSONAS + 1)]
        raw = await run_quick_poll(
            question="test?",
            personas=personas,
            ctx=ctx,
        )
        data = json.loads(raw)
        assert "error" in data
        assert f"{SAMPLING_MAX_PERSONAS} personas" in data["error"]
        ctx.session.create_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_byok_path_unchanged_with_creds(self, monkeypatch):
        from synth_panel.mcp.server import run_quick_poll

        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
        ctx = _make_sampling_ctx(supports=True)

        mock_run = AsyncMock(return_value={"results": [], "model": "haiku"})
        with patch("synth_panel.mcp.server._run_panel_async", mock_run):
            raw = await run_quick_poll(
                question="q?",
                personas=[{"name": "Alice"}],
                ctx=ctx,
            )
        data = json.loads(raw)
        assert data["mode"] == "byok"
        mock_run.assert_awaited_once()
        ctx.session.create_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_no_sampling_no_creds_returns_error(self):
        from synth_panel.mcp.server import run_quick_poll

        ctx = _make_sampling_ctx(supports=False)
        raw = await run_quick_poll(
            question="q?",
            personas=[{"name": "Alice"}],
            ctx=ctx,
        )
        data = json.loads(raw)
        assert "error" in data
        assert "ANTHROPIC_API_KEY" in data["error"]


# ---------------------------------------------------------------------------
# Integration — run_panel sampling fallback (sp-5no)
# ---------------------------------------------------------------------------


class TestRunPanelSampling:
    @pytest.mark.asyncio
    async def test_sampling_supported_no_creds_runs_panel(self):
        from synth_panel.mcp.server import run_panel

        ctx = _make_sampling_ctx(supports=True, sample_text="panel-answer")
        raw = await run_panel(
            questions=[{"text": "What do you think?"}],
            personas=[{"name": "Alice"}, {"name": "Bob"}],
            ctx=ctx,
        )
        data = json.loads(raw)

        assert data["mode"] == "sampling"
        assert data["persona_count"] == 2
        assert data["question_count"] == 1
        # 2 persona calls + 1 synthesis (default on)
        assert ctx.session.create_message.await_count == 3
        # sampling path never raises on the 'usage' field
        assert data["usage"] is None
        assert data["results"][0]["responses"][0]["answer"] == "panel-answer"

    @pytest.mark.asyncio
    async def test_sampling_persona_cap_enforced(self):
        from synth_panel.mcp.server import SAMPLING_MAX_PERSONAS, run_panel

        ctx = _make_sampling_ctx(supports=True)
        personas = [{"name": f"P{i}"} for i in range(SAMPLING_MAX_PERSONAS + 1)]
        raw = await run_panel(
            questions=[{"text": "q?"}],
            personas=personas,
            ctx=ctx,
        )
        data = json.loads(raw)
        assert "error" in data
        assert f"{SAMPLING_MAX_PERSONAS} personas" in data["error"]
        ctx.session.create_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_sampling_question_cap_enforced(self):
        from synth_panel.mcp.server import SAMPLING_MAX_QUESTIONS, run_panel

        ctx = _make_sampling_ctx(supports=True)
        questions = [{"text": f"Q{i}"} for i in range(SAMPLING_MAX_QUESTIONS + 1)]
        raw = await run_panel(
            questions=questions,
            personas=[{"name": "Alice"}],
            ctx=ctx,
        )
        data = json.loads(raw)
        assert "error" in data
        assert f"{SAMPLING_MAX_QUESTIONS} questions" in data["error"]
        ctx.session.create_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_sampling_rejects_variants(self):
        from synth_panel.mcp.server import run_panel

        ctx = _make_sampling_ctx(supports=True)
        raw = await run_panel(
            questions=[{"text": "q?"}],
            personas=[{"name": "Alice"}],
            variants=3,
            ctx=ctx,
        )
        data = json.loads(raw)
        assert "error" in data
        assert "variants" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_sampling_rejects_v3_branching_instrument(self):
        from synth_panel.mcp.server import run_panel

        ctx = _make_sampling_ctx(supports=True)
        instrument = {
            "version": 3,
            "rounds": [
                {
                    "name": "discovery",
                    "questions": [{"text": "What frustrates you?"}],
                    "route_when": [
                        {"if": {"field": "themes", "op": "contains", "value": "price"}, "goto": "probe"},
                        {"else": "__end__"},
                    ],
                },
                {
                    "name": "probe",
                    "questions": [{"text": "Dig deeper?"}],
                },
            ],
        }
        raw = await run_panel(
            instrument=instrument,
            personas=[{"name": "Alice"}],
            ctx=ctx,
        )
        data = json.loads(raw)
        assert "error" in data
        assert "branching" in data["error"].lower()

    @pytest.mark.asyncio
    async def test_no_sampling_no_creds_returns_friendly_error(self):
        from synth_panel.mcp.server import run_panel

        ctx = _make_sampling_ctx(supports=False)
        raw = await run_panel(
            questions=[{"text": "q?"}],
            personas=[{"name": "Alice"}],
            ctx=ctx,
        )
        data = json.loads(raw)
        # The critical regression: no 'usage' KeyError, a structured
        # error payload instead.
        assert "error" in data
        assert "ANTHROPIC_API_KEY" in data["error"]
        ctx.session.create_message.assert_not_called()


# ---------------------------------------------------------------------------
# sp-k2ed4a — host-side max_tokens truncation detection
# ---------------------------------------------------------------------------


class TestSampleTextTruncationDetection:
    """Unit tests for the new truncation flag on ``sample_text``."""

    @pytest.mark.asyncio
    async def test_max_tokens_stop_reason_flags_truncation(self):
        from synth_panel.mcp.sampling import sample_text

        ctx = _make_sampling_ctx(
            supports=True,
            sample_text='{"summary":"partial',
            stop_reason="maxTokens",
        )
        result = await sample_text(ctx, prompt="hi", max_tokens=256)

        assert result["truncated"] is True
        assert result["stop_reason"] == "maxTokens"
        assert result["requested_max_tokens"] == 256
        assert result["warning"] is not None
        assert "256" in result["warning"]
        assert "host-agent-model" in result["warning"]

    @pytest.mark.asyncio
    async def test_end_turn_stop_reason_does_not_flag_truncation(self):
        from synth_panel.mcp.sampling import sample_text

        ctx = _make_sampling_ctx(supports=True, sample_text="full reply", stop_reason="endTurn")
        result = await sample_text(ctx, prompt="hi", max_tokens=4096)

        assert result["truncated"] is False
        assert result["warning"] is None
        assert result["requested_max_tokens"] == 4096

    @pytest.mark.asyncio
    async def test_other_stop_reasons_do_not_flag_truncation(self):
        # ``stopSequence`` and ``toolUse`` are well-formed terminations —
        # only ``maxTokens`` indicates host-side cap truncation.
        from synth_panel.mcp.sampling import sample_text

        for reason in ("stopSequence", "toolUse"):
            ctx = _make_sampling_ctx(supports=True, stop_reason=reason)
            result = await sample_text(ctx, prompt="hi", max_tokens=2048)
            assert result["truncated"] is False, reason
            assert result["warning"] is None, reason

    @pytest.mark.asyncio
    async def test_truncation_logs_warning(self, caplog):
        import logging

        from synth_panel.mcp.sampling import sample_text

        ctx = _make_sampling_ctx(
            supports=True,
            sample_text="cut off",
            stop_reason="maxTokens",
        )
        with caplog.at_level(logging.WARNING, logger="synth_panel.mcp.sampling"):
            await sample_text(ctx, prompt="hi", max_tokens=512)

        assert any(
            "MCP sampling truncated" in r.message and "requested_max_tokens=512" in r.message for r in caplog.records
        )


class TestRunPromptTruncationWarnings:
    """sp-k2ed4a integration: ``run_prompt`` surfaces truncation warnings."""

    @pytest.mark.asyncio
    async def test_truncation_in_sampling_branch_surfaces_warning(self):
        from synth_panel.mcp.server import run_prompt

        ctx = _make_sampling_ctx(
            supports=True,
            sample_text="partial json",
            stop_reason="maxTokens",
        )
        raw = await run_prompt(prompt="anything", ctx=ctx)
        data = json.loads(raw)

        assert data["mode"] == "sampling"
        assert data["warnings"]  # non-empty
        assert "truncated" in data["warnings"][0].lower()

    @pytest.mark.asyncio
    async def test_no_truncation_yields_empty_warnings_list(self):
        from synth_panel.mcp.server import run_prompt

        ctx = _make_sampling_ctx(supports=True, sample_text="ok", stop_reason="endTurn")
        raw = await run_prompt(prompt="anything", ctx=ctx)
        data = json.loads(raw)

        assert data["mode"] == "sampling"
        assert data["warnings"] == []


class TestRunPanelSamplingTruncationWarnings:
    """sp-k2ed4a integration: panel sampling propagates per-turn truncation."""

    @pytest.mark.asyncio
    async def test_panelist_truncation_appears_in_warnings(self):
        from synth_panel.mcp.server import run_panel

        ctx = _make_sampling_ctx(
            supports=True,
            sample_text="cut off",
            stop_reason="maxTokens",
        )
        raw = await run_panel(
            questions=[{"text": "What do you think?"}],
            personas=[{"name": "Alice"}, {"name": "Bob"}],
            synthesis=False,
            ctx=ctx,
        )
        data = json.loads(raw)

        assert data["mode"] == "sampling"
        # One warning per panelist when every turn was truncated.
        assert len(data["warnings"]) == 2
        assert all("truncated" in w.lower() for w in data["warnings"])
        # Persona name is included so operators can pinpoint the turn.
        assert any("Alice" in w for w in data["warnings"])
        assert any("Bob" in w for w in data["warnings"])

    @pytest.mark.asyncio
    async def test_synthesis_truncation_labelled_separately(self):
        from synth_panel.mcp.server import run_panel

        ctx = _make_sampling_ctx(
            supports=True,
            sample_text="part",
            stop_reason="maxTokens",
        )
        raw = await run_panel(
            questions=[{"text": "Q1?"}],
            personas=[{"name": "Alice"}],
            synthesis=True,
            ctx=ctx,
        )
        data = json.loads(raw)

        # 1 panelist + 1 synthesis = 2 warnings, with the synthesis
        # turn distinguishable by the "synthesis:" prefix.
        assert len(data["warnings"]) == 2
        assert any(w.startswith("synthesis:") for w in data["warnings"])
        assert any(w.startswith("panelist") for w in data["warnings"])

    @pytest.mark.asyncio
    async def test_clean_run_yields_empty_warnings(self):
        from synth_panel.mcp.server import run_panel

        ctx = _make_sampling_ctx(supports=True, sample_text="full reply", stop_reason="endTurn")
        raw = await run_panel(
            questions=[{"text": "Q1?"}],
            personas=[{"name": "Alice"}],
            synthesis=True,
            ctx=ctx,
        )
        data = json.loads(raw)

        assert data["warnings"] == []


class TestRunQuickPollSamplingTruncationWarnings:
    @pytest.mark.asyncio
    async def test_quick_poll_truncation_surfaces_warnings(self):
        from synth_panel.mcp.server import run_quick_poll

        ctx = _make_sampling_ctx(
            supports=True,
            sample_text="cut",
            stop_reason="maxTokens",
        )
        raw = await run_quick_poll(
            question="Sky blue?",
            personas=[{"name": "Alice"}],
            ctx=ctx,
        )
        data = json.loads(raw)

        # 1 panelist + 1 synthesis = 2 truncated turns surfaced.
        assert data["mode"] == "sampling"
        assert len(data["warnings"]) == 2
        assert any(w.startswith("panelist 'Alice'") for w in data["warnings"])
        assert any(w.startswith("synthesis:") for w in data["warnings"])


class TestBuildTruncationWarning:
    def test_includes_max_tokens_and_model(self):
        from synth_panel.mcp.sampling import build_truncation_warning

        msg = build_truncation_warning(max_tokens=512, model="claude-opus-4-6")
        assert "512" in msg
        assert "claude-opus-4-6" in msg
        # Operator-actionable hint to set BYOK key for longer schemas.
        assert "ANTHROPIC_API_KEY" in msg

    def test_no_model_omits_model_part(self):
        from synth_panel.mcp.sampling import build_truncation_warning

        msg = build_truncation_warning(max_tokens=2048, model=None)
        assert "2048" in msg
        assert "(host model:" not in msg
