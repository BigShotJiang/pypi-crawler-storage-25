Overpass API python wrapper
===========================

This legacy reStructuredText README is intentionally minimal.
The canonical project README is ``README.md``.

For repository hosting, issues, development instructions, and release notes, see:

- https://codeberg.org/mvexel/overpass-api-python-wrapper
