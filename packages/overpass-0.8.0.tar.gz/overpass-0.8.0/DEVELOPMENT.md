# Development

## Baseline

- Active tested interpreter baseline: Python 3.10 through 3.14
- Supported compatibility target: Python 3.10 through 3.14
- Preferred local interpreter: Python 3.11, matching [.tool-versions](.tool-versions)
- Development branch baseline: `dev`

## Local Setup

Use `uv` for the local development environment and dependency synchronization:

```bash
uv sync --extra dev
```

This creates or updates `.venv` from `pyproject.toml` and `uv.lock`.

## Commands

Run the default test suite:

```bash
uv run python -W default -m pytest
```

Run the opt-in live Overpass API checks:

```bash
USE_LIVE_API=true uv run python -m pytest -m live_api
```

Run lint checks:

```bash
uv run ruff check .
```

Check formatting:

```bash
uv run ruff format --check .
```

Run type checks:

```bash
uv run ty check overpass tests conftest.py
```

Run tests with coverage reporting:

```bash
uv run python -W default -m pytest --cov=overpass --cov-report=term-missing
```

Run the full validation script used locally and by hosted Forgejo/Codeberg CI:

```bash
scripts/check
```

Run the supported local Python test matrix directly:

```bash
UV_PROJECT_ENVIRONMENT=.venv310 uv run --locked --python 3.10 --extra test python -W default -m pytest
UV_PROJECT_ENVIRONMENT=.venv311 uv run --locked --python 3.11 --extra test python -W default -m pytest
UV_PROJECT_ENVIRONMENT=.venv312 uv run --locked --python 3.12 --extra test python -W default -m pytest
UV_PROJECT_ENVIRONMENT=.venv313 uv run --locked --python 3.13 --extra test python -W default -m pytest
UV_PROJECT_ENVIRONMENT=.venv314 uv run --locked --python 3.14 --extra test python -W default -m pytest
```

## Notes

- `uv` is the canonical local environment, dependency synchronization, command runner, lockfile, Python-version, and build tool.
- Packaging metadata is centralized in `pyproject.toml` using PEP 621 project metadata.
- `scripts/check` is the local and hosted validation entrypoint; it runs linting, formatting checks, type checks, coverage reporting, the supported local Python test matrix, and package build verification.
- Hosted validation is defined in `.forgejo/workflows/check.yml` for a Forgejo/Codeberg-compatible self-hosted runner.
- Live-network tests are opt-in and excluded from the documented default and required hosted workflows.
