# Release Checklist

Release work is intentionally separate from modernization cleanup. Cut the next release
after the modernization branch has merged and the Forgejo/Codeberg hosted validation is
green on `dev` and `main`.

## Pre-release

- Confirm `scripts/check` passes locally.
- Confirm the hosted Forgejo/Codeberg workflow passes on the release branch.
- Confirm supported Python versions in `README.md`, `DEVELOPMENT.md`, and
  `pyproject.toml` match.
- Review `CHANGELOG.md` and add a dated release section for the new version.
- Choose the release version and update `pyproject.toml`.
- Rebuild and inspect the package artifacts with `uv build`.

## Publish

- Tag the release from `main` after validation passes.
- Publish the built source distribution and wheel to PyPI.
- Push the tag to Codeberg.

## Post-release

- Verify the PyPI project page renders the README correctly.
- Verify a clean install with `pip install overpass` in a fresh environment.
- Open follow-up issues for deferred parser/runtime-response behavior changes and any
  example improvements not included in the release.
