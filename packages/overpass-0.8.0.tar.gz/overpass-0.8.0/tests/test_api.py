# Copyright 2015-2018 Martijn van Exel.
# This file is part of the overpass-api-python-wrapper project
# which is licensed under Apache 2.0.
# See LICENSE.txt for the full license text.

import json
import os
from datetime import datetime, timezone
from pathlib import Path

import geojson
import pytest
from deepdiff import DeepDiff

import overpass


def _env_flag(name: str) -> bool:
    value = os.getenv(name, "").strip().lower()
    return value in {"1", "true", "yes", "on"}


USE_LIVE_API = _env_flag("USE_LIVE_API")


def _set_attribute(obj: object, name: str, value: object) -> None:
    setattr(obj, name, value)


def test_initialize_api():
    api = overpass.API()
    assert isinstance(api, overpass.API)
    assert api.debug is False


def test_public_exports_are_explicit():
    assert set(overpass.__all__) == {
        "API",
        "MapQuery",
        "MultipleRequestsError",
        "OverpassError",
        "OverpassSyntaxError",
        "ServerLoadError",
        "ServerRuntimeError",
        "TimeoutError",
        "UnknownOverpassError",
        "Utils",
        "WayQuery",
    }


def test_default_headers_are_not_shared_between_api_instances():
    first = overpass.API()
    second = overpass.API()

    first.headers["User-Agent"] = "overpass-test"

    assert "User-Agent" not in second.headers


def test_initialize_api_with_explicit_parameters():
    headers = {"User-Agent": "overpass-test"}
    proxies = {"https": "https://proxy.example.test"}

    api = overpass.API(
        endpoint="https://overpass.example.test/api/interpreter",
        headers=headers,
        timeout=60,
        debug=True,
        proxies=proxies,
    )

    assert api.endpoint == "https://overpass.example.test/api/interpreter"
    assert api.headers == headers
    assert api.timeout == 60
    assert api.debug is True
    assert api.proxies == proxies


def test_map_query_stringifies_to_overpass_ql():
    query = overpass.MapQuery(37.86517, -122.31851, 37.86687, -122.31635)

    assert str(query) == "(node(37.86517,-122.31851,37.86687,-122.31635);<;>;);"


def test_map_query_is_immutable():
    query = overpass.MapQuery(37.86517, -122.31851, 37.86687, -122.31635)

    with pytest.raises(AttributeError):
        _set_attribute(query, "south", 0)


def test_way_query_stringifies_to_overpass_ql():
    query = overpass.WayQuery('["highway"="primary"]')

    assert str(query) == '(way["highway"="primary"]);(._;>;);'


def test_way_query_is_immutable():
    query = overpass.WayQuery('["highway"="primary"]')

    with pytest.raises(AttributeError):
        _set_attribute(query, "query_parameters", '["highway"="secondary"]')


@pytest.mark.parametrize(
    ("osmid", "area", "expected"),
    [
        (2758138, False, 3602758138),
        ("2758138", True, 2402758138),
    ],
)
def test_utils_to_overpass_id(osmid, area: bool, expected: int):
    assert overpass.Utils.to_overpass_id(osmid, area=area) == expected


@pytest.mark.parametrize(
    "query,length,response",
    [
        (
            overpass.MapQuery(37.86517, -122.31851, 37.86687, -122.31635),
            1,
            Path("tests/example_mapquery.json"),
        ),
        (
            "node(area:3602758138)[amenity=cafe]",
            1,
            Path("tests/example_singlenode.json"),
        ),
    ],
)
def test_geojson(
    query: overpass.MapQuery | str,
    length: int,
    response: Path,
    requests_mock,
    load_json_fixture,
):
    api = overpass.API(debug=True)

    mock_response = load_json_fixture(response.name)
    requests_mock.post("//overpass-api.de/api/interpreter", json=mock_response)

    osm_geo = api.get(query)
    assert len(osm_geo["features"]) > length


def test_multipolygon(requests_mock, load_json_fixture):
    """
    Test that multipolygons are processed without error
    """
    api = overpass.API()
    mock_response = load_json_fixture("example_body.json")
    requests_mock.post("//overpass-api.de/api/interpreter", json=mock_response)
    api.get("rel(11038555)", verbosity="body geom")


def test_get_returns_json_for_non_geojson_responseformat(
    requests_mock, load_json_fixture
):
    api = overpass.API()
    mock_response = load_json_fixture("example_singlenode.json")
    requests_mock.post("//overpass-api.de/api/interpreter", json=mock_response)

    response = api.get("node(area:3602758138)[amenity=cafe]", responseformat="json")

    assert "elements" in response
    assert isinstance(response["elements"], list)


def test_get_returns_built_query_json_when_build_is_false(requests_mock):
    api = overpass.API()
    raw_response = {"remark": "runtime error: raw response should pass through"}
    requests_mock.post(
        "https://overpass-api.de/api/interpreter",
        headers={"content-type": "application/json"},
        text=json.dumps(raw_response),
    )

    response = api.get("[out:json];node(1);out;", build=False)

    assert response == raw_response


def test_get_rejects_unsupported_responseformat_before_request(requests_mock):
    api = overpass.API()

    with pytest.raises(ValueError, match="Unsupported responseformat"):
        api.get('node["name"="Salt Lake City"]', responseformat="yaml")

    assert not requests_mock.called


def test_get_returns_csv_rows(requests_mock):
    api = overpass.API()
    requests_mock.post(
        "https://overpass-api.de/api/interpreter",
        headers={"content-type": "text/csv"},
        text="name\t@lon\t@lat\nSpringfield\t-3.0645656\t56.2952787\n",
    )

    response = api.get(
        'node["name"="Springfield"]["place"]', responseformat="csv(name,::lon,::lat)"
    )

    assert response == [
        ["name", "@lon", "@lat"],
        ["Springfield", "-3.0645656", "56.2952787"],
    ]


@pytest.mark.parametrize(
    "content_type",
    ["text/xml", "application/xml", "application/osm3s+xml"],
)
def test_get_returns_xml_text(requests_mock, content_type: str):
    api = overpass.API()
    xml_response = "<osm><node id='1' /></osm>"
    requests_mock.post(
        "https://overpass-api.de/api/interpreter",
        headers={"content-type": content_type},
        text=xml_response,
    )

    response = api.get('node["name"="Salt Lake City"]', responseformat="xml")

    assert response == xml_response


@pytest.mark.parametrize(
    ("date_input", "expected_fragment"),
    [
        ("2020-04-27", '[date:"2020-04-27T00:00:00Z"]'),
        ("2020-04-27T00:00:00Z", '[date:"2020-04-27T00:00:00Z"]'),
        (datetime(2020, 4, 27, tzinfo=timezone.utc), '[date:"2020-04-27T00:00:00Z"]'),
    ],
)
def test_date_inputs_are_embedded_in_built_query(
    requests_mock, date_input, expected_fragment: str
):
    api = overpass.API()
    if isinstance(date_input, str):
        try:
            parsed_date = datetime.fromisoformat(date_input)
        except ValueError:
            parsed_date = datetime.strptime(date_input, "%Y-%m-%dT%H:%M:%SZ")
    else:
        parsed_date = date_input

    query = api._construct_ql_query(
        'node["name"="Salt Lake City"]',
        responseformat="json",
        verbosity="body",
        date=parsed_date,
    )

    assert expected_fragment in query


@pytest.mark.parametrize("date_input", ["not-a-date", "2020-99-99"])
def test_invalid_date_input_raises_value_error(date_input: str):
    api = overpass.API()

    with pytest.raises(ValueError):
        api.get('node["name"="Salt Lake City"]', date=date_input)


@pytest.mark.parametrize(
    ("status_code", "expected_exception"),
    [
        (400, overpass.OverpassSyntaxError),
        (429, overpass.MultipleRequestsError),
        (504, overpass.ServerLoadError),
        (500, overpass.UnknownOverpassError),
    ],
)
def test_http_status_codes_map_to_library_exceptions(
    requests_mock, status_code: int, expected_exception
):
    api = overpass.API()
    requests_mock.post(
        "https://overpass-api.de/api/interpreter", status_code=status_code
    )

    with pytest.raises(expected_exception):
        api.get('node["name"="Salt Lake City"]')


def test_timeout_is_mapped_to_library_timeout_error(monkeypatch):
    api = overpass.API(timeout=17)

    def _raise_timeout(*args, **kwargs):
        raise overpass.api.requests.exceptions.Timeout()

    monkeypatch.setattr(overpass.api.requests, "post", _raise_timeout)

    with pytest.raises(overpass.TimeoutError) as exc_info:
        api.get('node["name"="Salt Lake City"]')

    assert exc_info.value.timeout == 25


def test_missing_elements_raises_unknown_overpass_error(requests_mock):
    api = overpass.API()
    requests_mock.post(
        "https://overpass-api.de/api/interpreter",
        headers={"content-type": "application/json"},
        text=json.dumps({"version": 0.6}),
    )

    with pytest.raises(overpass.UnknownOverpassError):
        api.get('node["name"="Salt Lake City"]')


def test_runtime_remark_raises_server_runtime_error(requests_mock):
    api = overpass.API()
    requests_mock.post(
        "https://overpass-api.de/api/interpreter",
        headers={"content-type": "application/json"},
        text=json.dumps({"elements": [], "remark": "runtime error: Query timed out"}),
    )

    with pytest.raises(overpass.api.ServerRuntimeError):
        api.get('node["name"="Salt Lake City"]')


def test_invalid_json_raises_json_decode_error(requests_mock):
    api = overpass.API()
    requests_mock.post(
        "https://overpass-api.de/api/interpreter",
        headers={"content-type": "application/json"},
        text="{not valid json",
    )

    with pytest.raises(json.JSONDecodeError):
        api.get('node["name"="Salt Lake City"]')


@pytest.mark.parametrize(
    "verbosity,response,output",
    [
        ("body geom", "tests/example_body.json", "tests/example_body.geojson"),
        # ("tags geom", "tests/example.json", "tests/example.geojson"),
        ("meta geom", "tests/example_meta.json", "tests/example_meta.geojson"),
    ],
)
def test_geojson_extended(
    verbosity, response, output, requests_mock, load_json_fixture
):
    api = overpass.API(debug=True)

    mock_response = load_json_fixture(Path(response).name)
    requests_mock.post("//overpass-api.de/api/interpreter", json=mock_response)

    osm_geo = sorted(
        api.get(
            f"rel(6518385);out {verbosity};way(10322303);out {verbosity};node(4927326183);",
            verbosity=verbosity,
        )
    )

    with Path(output).open() as fp:
        ref_geo = sorted(geojson.load(fp))
    assert osm_geo == ref_geo


@pytest.mark.integration
@pytest.mark.live_api
@pytest.mark.skipif(
    not USE_LIVE_API, reason="USE_LIVE_API environment variable not set to True"
)
def test_geojson_live():
    """
    This code should only be executed once when major changes to the Overpass API and/or to this
    wrapper are introduced. One than has to manually verify that the date in the example.geojson
    file from the Overpass API matches the data in the example.geojson file generated by this
    wrapper.

    The reason for this approach is the following: It is not safe to make calls to the actual API in
    this test as the API might momentarily be unavailable and the underlying data can also change
    at any moment.
    """
    api = overpass.API(debug=True)
    osm_geo = api.get(
        "rel(6518385);out body geom;way(10322303);out body geom;node(4927326183);",
        verbosity="body geom",
    )

    with Path("tests/example_live.json").open("r") as fp:
        ref_geo = json.load(fp)

    # assert that the dictionaries are the same
    # diff = DeepDiff(osm_geo, ref_geo, include_paths="[root]['features']")
    diff = DeepDiff(osm_geo, ref_geo, include_paths="[root]['features']")
    print(diff if diff else "No differences found")

    assert not diff


@pytest.mark.parametrize(
    "response,slots_available,slots_running,slots_waiting",
    [
        (Path("tests/overpass_status/no_slots_waiting_six_lines.txt"), 2, (), ()),
        (Path("tests/overpass_status/no_slots_waiting.txt"), 2, (), ()),
        (
            Path("tests/overpass_status/one_slot_running.txt"),
            1,
            (
                datetime(
                    year=2021,
                    month=3,
                    day=8,
                    hour=20,
                    minute=22,
                    second=55,
                    tzinfo=timezone.utc,
                ),
            ),
            (),
        ),
        (
            Path("tests/overpass_status/one_slot_waiting.txt"),
            1,
            (),
            (
                datetime(
                    year=2021,
                    month=3,
                    day=8,
                    hour=20,
                    minute=23,
                    second=28,
                    tzinfo=timezone.utc,
                ),
            ),
        ),
        (
            Path("tests/overpass_status/two_slots_waiting.txt"),
            0,
            (),
            (
                datetime(
                    year=2021,
                    month=3,
                    day=8,
                    hour=20,
                    minute=27,
                    second=00,
                    tzinfo=timezone.utc,
                ),
                datetime(
                    year=2021,
                    month=3,
                    day=8,
                    hour=20,
                    minute=30,
                    second=28,
                    tzinfo=timezone.utc,
                ),
            ),
        ),
    ],
)
def test_api_status(
    response: Path,
    slots_available: int,
    slots_running: tuple[datetime],
    slots_waiting: tuple[datetime],
    requests_mock,
    load_text_fixture,
):
    mock_response = load_text_fixture("overpass_status", response.name)
    requests_mock.get("https://overpass-api.de/api/status", text=mock_response)

    api = overpass.API(debug=True)

    requests_mock.post("https://overpass-api.de/api/interpreter", json={"elements": []})
    map_query = overpass.MapQuery(37.86517, -122.31851, 37.86687, -122.31635)
    api.get(map_query)

    assert 0 <= api.slots_available <= 2
    assert api.slots_available == slots_available

    assert isinstance(api.slots_running, tuple)
    assert api.slots_running == slots_running

    assert isinstance(api.slots_waiting, tuple)
    assert api.slots_waiting == slots_waiting

    assert isinstance(api.slot_available_countdown, int)
    assert api.slot_available_countdown >= 0

    assert api.slot_available_datetime is None or isinstance(
        api.slot_available_datetime, datetime
    )
