import pytest

import overpass
from overpass.errors import ServerRuntimeError


def test_overpass_syntax_error_preserves_request_and_has_message():
    request = "node(;"

    error = overpass.OverpassSyntaxError(request)

    assert error.request == request
    assert str(error) == request
    assert isinstance(error, ValueError)


@pytest.mark.parametrize(
    ("error_class", "timeout"),
    [
        (overpass.TimeoutError, 25),
        (overpass.ServerLoadError, 60),
    ],
)
def test_timeout_errors_preserve_timeout_and_have_message(error_class, timeout: int):
    error = error_class(timeout)

    assert error.timeout == timeout
    assert str(timeout) in str(error)


@pytest.mark.parametrize(
    "error_class",
    [
        overpass.UnknownOverpassError,
        ServerRuntimeError,
    ],
)
def test_message_errors_preserve_message_and_have_message(error_class):
    message = "runtime error: Query timed out"

    error = error_class(message)

    assert error.message == message
    assert str(error) == message


def test_multiple_requests_error_has_useful_message():
    error = overpass.MultipleRequestsError()

    assert str(error) == "Multiple requests are already running."
