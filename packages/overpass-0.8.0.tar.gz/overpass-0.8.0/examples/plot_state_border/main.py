#!/usr/bin/env python

# Author: Florian Winkler (Fju) 2018
# This file is part of the overpass-api-python-wrapper project
# which is licensed under Apache 2.0.
# See LICENSE.txt for the full license text.

"""Plot the state border of Saxony, Germany, from an Overpass XML response."""

import xml.etree.ElementTree
from pathlib import Path

import matplotlib.pyplot as plt

import overpass

MAX_SIZE = 400
XML_FILE = Path("state_border_saxony.xml")
QUERY = """area[name="Sachsen"][type="boundary"]->.saxony;
rel(area.saxony)[admin_level=4][type="boundary"][boundary="administrative"];
out geom;"""


def outside(x1, y1, x2, y2, tolerance):
    """Return whether two points are farther apart than the tolerance."""
    dx = x1 - x2
    dy = y1 - y2
    return (dx * dx + dy * dy) > tolerance


# The response can be multiple MB, so save it for reuse.
if not XML_FILE.is_file():
    api = overpass.API(timeout=60)
    response = api.get(QUERY, responseformat="xml")
    XML_FILE.write_text(response, encoding="utf-8")

root = xml.etree.ElementTree.parse(XML_FILE).getroot()

bounds = root.find("relation").find("bounds")
min_lat = float(bounds.get("minlat"))
min_lon = float(bounds.get("minlon"))
max_lat = float(bounds.get("maxlat"))
max_lon = float(bounds.get("maxlon"))

# longitude: east - west (x)
# latitude: north - south (y)
box_width = max_lon - min_lon
box_height = max_lat - min_lat

# Compute scale factors so that the largest distance equals MAX_SIZE.
scale_x = int(MAX_SIZE * box_width / max(box_width, box_height))
scale_y = int(MAX_SIZE * box_height / max(box_width, box_height))

point_count = 0
for member in root.iter("member"):
    member_type = member.get("type")
    member_role = member.get("role")

    if member_type != "way" or member_role != "outer":
        continue

    member_points = member.findall("nd")
    prev_x, prev_y = -1, -1

    for index, member_point in enumerate(member_points):
        x = float(member_point.get("lon"))
        y = float(member_point.get("lat"))

        # Convert lon and lat coordinates to pixel coordinates.
        x = (x - min_lon) / box_width * scale_x
        y = (y - min_lat) / box_height * scale_y

        if index == 0:
            prev_x = x
            prev_y = y
        elif outside(x, y, prev_x, prev_y, 1) or index == len(member_points) - 1:
            # Draw line from current point to previous point.
            plt.plot([x, prev_x], [y, prev_y], "k-")
            point_count += 1
            prev_x = x
            prev_y = y

print(point_count)
plt.show()
