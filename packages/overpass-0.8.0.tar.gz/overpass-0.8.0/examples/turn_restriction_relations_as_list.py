#!/usr/bin/env python

# Copyright 2015-2018 Martijn van Exel.
# This file is part of the overpass-api-python-wrapper project
# which is licensed under Apache 2.0.
# See LICENSE.txt for the full license text.

"""Retrieve turn restriction relations in Toronto as CSV rows."""

import overpass

api = overpass.API()

turn_restrictions_query = "relation[type=restriction](area:3600324211)"
response_format = (
    'csv(::"id",::"user",::"timestamp",restriction,"restriction:conditional")'
)

turn_restrictions = api.get(
    turn_restrictions_query,
    responseformat=response_format,
    verbosity="meta",
)

print(turn_restrictions)
