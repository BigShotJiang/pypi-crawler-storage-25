#!/usr/bin/env python

# Copyright 2015-2018 Martijn van Exel.
# This file is part of the overpass-api-python-wrapper project
# which is licensed under Apache 2.0.
# See LICENSE.txt for the full license text.

"""Retrieve unique OpenStreetMap usernames and user IDs for a named area."""

import overpass

# Change this to the name of the area you're interested in.
# Keep it small to avoid overloading the public Overpass server.
area_name = "Kanab"

query = f'area[name="{area_name}"]->.a;(node(area.a);<;);'
users = {"ids": [], "usernames": []}
message_urls = []
api = overpass.API(debug=False)
result = api.get(query, responseformat="csv(::uid,::user)", verbosity="meta")

for uid_text, username in result[1:]:
    uid = int(uid_text)
    if uid in users["ids"]:
        continue
    users["ids"].append(uid)
    users["usernames"].append(username)
    message_urls.append(f"https://www.openstreetmap.org/message/new/{username}")

print(users)
print(message_urls)
