# Examples

These examples perform live requests against the public Overpass API. Keep areas and
queries small to avoid overloading shared infrastructure.

Run examples from the repository root with an environment that includes the package:

```bash
uv run python examples/readme_example.py
```

The `plot_state_border` example also requires `matplotlib`.

## README example

File: `readme_example.py`

Requests nodes named "Salt Lake City" and prints each returned feature ID and name.

## Unique users for an area

File: `unique_users_for_area.py`

Requests CSV output for a small named area and prints unique OpenStreetMap user IDs,
usernames, and message URLs.

## Turn restrictions as a list

File: `turn_restriction_relations_as_list.py`

Requests CSV output for turn restriction relations within Toronto and prints the rows.

## Plot state border

File: `plot_state_border/main.py`

Requests the boundary of Saxony, Germany as XML, caches the response locally, and draws
the outer border with `matplotlib`.

Overpass query:

```osm
area[name="Sachsen"][type="boundary"]->.saxony;
rel(area.saxony)[admin_level=4][type="boundary"][boundary="administrative"];
out geom;
```

The example opens a `matplotlib` window with the rendered border.
