# Copyright 2015-2018 Martijn van Exel.
# This file is part of the overpass-api-python-wrapper project
# which is licensed under Apache 2.0.
# See LICENSE.txt for the full license text.

"""Thin wrapper around the OpenStreetMap Overpass API."""

from importlib.metadata import PackageNotFoundError, version

__title__ = "overpass"
try:
    __version__ = version(__title__)
except PackageNotFoundError:
    __version__ = "0+unknown"
__license__ = "Apache 2.0"

from .api import API
from .errors import (
    MultipleRequestsError,
    OverpassError,
    OverpassSyntaxError,
    ServerLoadError,
    ServerRuntimeError,
    TimeoutError,
    UnknownOverpassError,
)
from .queries import MapQuery, WayQuery
from .utils import Utils

__all__ = [
    "API",
    "MapQuery",
    "MultipleRequestsError",
    "OverpassError",
    "OverpassSyntaxError",
    "ServerLoadError",
    "ServerRuntimeError",
    "TimeoutError",
    "UnknownOverpassError",
    "Utils",
    "WayQuery",
]
