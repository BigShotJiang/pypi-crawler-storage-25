# Copyright 2015-2018 Martijn van Exel.
# This file is part of the overpass-api-python-wrapper project
# which is licensed under Apache 2.0.
# See LICENSE.txt for the full license text.

from dataclasses import dataclass


@dataclass(frozen=True)
class MapQuery:
    """Query to retrieve complete ways and relations in an area."""

    south: float
    west: float
    north: float
    east: float

    _QUERY_TEMPLATE = "(node({south},{west},{north},{east});<;>;);"

    def __str__(self):
        return self._QUERY_TEMPLATE.format(
            west=self.west, south=self.south, east=self.east, north=self.north
        )


@dataclass(frozen=True)
class WayQuery:
    """Query to retrieve a set of ways and their dependent nodes satisfying the input parameters."""

    query_parameters: str

    _QUERY_TEMPLATE = "(way{query_parameters});(._;>;);"

    def __str__(self):
        return self._QUERY_TEMPLATE.format(query_parameters=self.query_parameters)
