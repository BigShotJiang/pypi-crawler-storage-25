"""
Tests for audit event emission (audit.py) and audit correlation across surfaces.
"""

from __future__ import annotations

import logging
import uuid as _uuid
from typing import Generator

import pytest
import sqlalchemy as sa
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from intent_api import IntentRouter
from intent_api_admin.audit import emit_audit_event, set_audit_handler


# ── Direct emit_audit_event tests ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_custom_audit_handler_is_called():
    """set_audit_handler registers a custom handler that receives events."""
    events = []

    async def handler(event: dict) -> None:
        events.append(event)

    set_audit_handler(handler)

    await emit_audit_event(
        action="read",
        model_name="AdminUser",
        resource_id="user_001",
        admin_id="admin_001",
        role="support",
        session_id="sess_001",
        is_impersonation=True,
    )

    set_audit_handler(None)

    assert len(events) == 1
    event = events[0]
    assert event["action"] == "read"
    assert event["model"] == "AdminUser"
    assert event["intent_model"] == "AdminUser"
    assert event["resource_id"] == "user_001"
    assert event["admin_id"] == "admin_001"
    assert event["acting_admin_id"] == "admin_001"
    assert event["role"] == "support"
    assert event["intent_admin_role"] == "support"
    assert event["session_id"] == "sess_001"
    assert event["impersonation_session_id"] == "sess_001"
    assert event["is_impersonation"] is True
    assert "timestamp" in event


@pytest.mark.asyncio
async def test_default_audit_handler_logs_without_error():
    """Without a custom handler, emit_audit_event logs and doesn't raise."""
    set_audit_handler(None)
    await emit_audit_event(
        action="list",
        model_name="AdminUser",
        resource_id=None,
        admin_id="admin_001",
        role="admin",
    )


@pytest.mark.asyncio
async def test_audit_event_payload_keys():
    """Audit event includes payload_keys (not values)."""
    events = []

    async def handler(event: dict):
        events.append(event)

    set_audit_handler(handler)

    await emit_audit_event(
        action="update",
        model_name="AdminUser",
        resource_id="user_001",
        admin_id="admin_001",
        role="admin",
        payload={"name": "Alice", "email": "alice@example.com"},
    )

    set_audit_handler(None)

    assert "name" in events[0]["payload_keys"]
    assert "email" in events[0]["payload_keys"]
    assert "Alice" not in str(events[0].get("payload", ""))


# ── Integration test app fixture for correlation tests ────────────────────────


def _build_app(*, seed=None, kid="audit-key-001"):
    from intent_api_admin import (
        configure_admin_auth, auto_admin, admin_machine_auth,
        impersonation_aware_auth,
    )
    from intent_api_admin.config import _reset_config
    from intent_api_admin.auth.admin_machine import _reset_jwks_cache as reset_am
    from intent_api_admin.auth.impersonation import _reset_jwks_cache as reset_imp
    from tests.fixtures.tokens import generate_key_pair
    from tests.fixtures.jwks_server import make_mock_jwks_cache
    import intent_api_admin.auth.admin_machine as am_mod
    import intent_api_admin.auth.impersonation as imp_mod

    _reset_config()
    reset_am()
    reset_imp()

    priv, _ = generate_key_pair()
    issuer = "https://console.audit.test"
    audience = "audit-test"

    cache, _ = make_mock_jwks_cache(kid, priv)

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "users"
        id = sa.Column(sa.String(36), primary_key=True, default=lambda: str(_uuid.uuid4()))
        email = sa.Column(sa.String(255), nullable=False, unique=True)
        name = sa.Column(sa.String(255), nullable=True)

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    SessionFactory = sessionmaker(bind=engine, autocommit=False, autoflush=False)

    if seed:
        with SessionFactory() as session:
            for u in seed:
                session.add(User(**u))
            session.commit()

    async def imp_user_query(db, target_user_id):
        return db.execute(sa.select(User).where(User.id == target_user_id)).scalars().first()

    configure_admin_auth(
        issuer=issuer, audience=audience,
        impersonation_user_query=imp_user_query,
        jwks_url="https://mock.jwks/keys",
        base=Base,
    )

    router = IntentRouter()
    auto_admin(router, expose=["User"])

    am_mod._jwks_cache = cache
    imp_mod._impersonation_jwks_cache = cache

    def get_db() -> Generator[Session, None, None]:
        db = SessionFactory()
        try:
            yield db
        finally:
            db.close()

    async def base_clerk_auth(*, credentials, context, db):
        return {"id": "non_admin"}

    app = FastAPI()
    app.include_router(
        router.build(
            get_user=impersonation_aware_auth(base_clerk_auth),
            get_db=get_db,
        )
    )
    app.include_router(
        router.build_admin_machine(
            get_user=admin_machine_auth(),
            get_db=get_db,
        )
    )
    return app, priv, kid, issuer, audience


# ── Correlation tests (integration) ───────────────────────────────────────────


@pytest.mark.asyncio
async def test_admin_machine_audit_event_fields():
    """Admin-machine path emits an event with surface, role, model, action, status, duration_ms."""
    from tests.fixtures.tokens import make_admin_token

    app, priv, kid, issuer, audience = _build_app(
        seed=[{"id": "u1", "email": "a@a.com", "name": "Alice"}],
    )
    captured: list[dict] = []

    async def handler(event):
        captured.append(event)
    set_audit_handler(handler)

    token = make_admin_token(
        private_key=priv, kid=kid, sub="admin_007",
        issuer=issuer, audience=audience, role="admin",
    )

    try:
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.post(
                "/api/admin-machine-intent",
                json={"model": "AdminUser", "action": "list"},
                headers={"Authorization": f"Bearer {token}"},
            )
        assert resp.status_code == 200
    finally:
        set_audit_handler(None)

    assert len(captured) == 1
    e = captured[0]
    assert e["surface"] == "admin-machine"
    assert e["acting_admin_id"] == "admin_007"
    assert e["intent_admin_role"] == "admin"
    assert e["intent_model"] == "AdminUser"
    assert e["intent_action"] == "list"
    assert e["status"] == "success"
    assert e["duration_ms"] is not None
    assert e["duration_ms"] >= 0


@pytest.mark.asyncio
async def test_impersonation_audit_event_fields():
    """Impersonation path emits an event with surface=impersonation, target_user_id, session_id."""
    # Note: auto-generated services live on admin-machine; impersonation
    # tokens are rejected there. So we exercise impersonation via direct
    # call to emit_audit_event using the canonical context, simulating a
    # custom IntentService that uses our preconditions/audit machinery.
    captured: list[dict] = []

    async def handler(event):
        captured.append(event)
    set_audit_handler(handler)

    try:
        await emit_audit_event(
            action="read",
            model_name="User",
            resource_id="user_001",
            admin_id="admin_007",
            role="support",
            session_id="sess_imp_001",
            is_impersonation=True,
            surface="impersonation",
            target_user_id="user_001",
            duration_ms=1.23,
        )
    finally:
        set_audit_handler(None)

    e = captured[0]
    assert e["surface"] == "impersonation"
    assert e["acting_admin_id"] == "admin_007"
    assert e["target_user_id"] == "user_001"
    assert e["impersonation_session_id"] == "sess_imp_001"
    assert e["status"] == "success"


@pytest.mark.asyncio
async def test_impersonation_session_correlation():
    """Three intents with the same session_id share impersonation_session_id and have monotonically-increasing timestamps."""
    captured: list[dict] = []

    async def handler(event):
        captured.append(event)
    set_audit_handler(handler)

    try:
        for i in range(3):
            await emit_audit_event(
                action="read",
                model_name="User",
                resource_id=f"user_{i}",
                admin_id="admin_007",
                role="support",
                session_id="sess_correlated",
                is_impersonation=True,
                surface="impersonation",
                target_user_id=f"user_{i}",
                duration_ms=0.5,
            )
    finally:
        set_audit_handler(None)

    assert len(captured) == 3
    ids = {e["impersonation_session_id"] for e in captured}
    assert ids == {"sess_correlated"}
    timestamps = [e["timestamp"] for e in captured]
    assert all(t2 >= t1 for t1, t2 in zip(timestamps, timestamps[1:]))


@pytest.mark.asyncio
async def test_denied_action_handler_not_called():
    """Read-only impersonation + write action: handler is NOT called and audit event has status=denied + IMPERSONATION_WRITE_DENIED."""
    from fastapi import HTTPException
    from intent_api_admin.auto_admin.service_factory import make_admin_service
    from intent_api_admin.auto_admin.schemas import ResourceSchema, FieldSchema
    from intent_api.schemas import AdminIntentContext

    captured: list[dict] = []

    async def handler(event):
        captured.append(event)
    set_audit_handler(handler)

    # Build a tiny model + service
    from sqlalchemy.orm import DeclarativeBase

    class B(DeclarativeBase):
        pass

    class M(B):
        __tablename__ = "denial_tests"
        id = sa.Column(sa.Integer, primary_key=True)
        name = sa.Column(sa.String, nullable=True)

    rs = ResourceSchema(
        model_name="M",
        display_name="M",
        display_prefix="M",
        fields={
            "id": FieldSchema(
                name="id", type="int", nullable=False, primary_key=True, read_only=True
            ),
            "name": FieldSchema(
                name="name", type="str", nullable=True, primary_key=False, read_only=False
            ),
        },
        relationships={},
        list_fields=["id", "name"],
        search_fields=["name"],
        default_sort="id desc",
        redacted_fields=[],
        deny_edit_fields=[],
        deny_delete=False,
    )

    # Track if the inner DB code ran by capturing the call with a counter.
    counter = {"calls": 0}

    async def fake_audit(**kwargs):
        await handler(kwargs)

    # We use the real factory but install a session that will explode if
    # we accidentally reach DB code (which we won't, since precondition
    # fails first).
    svc_cls = make_admin_service(
        model_name="AdminM",
        model_class=M,
        resource_schema=rs,
        deny_delete=False,
        deny_edit_fields=set(),
        redacted_fields=set(),
        audit_fn=emit_audit_event,
    )
    svc = svc_cls()

    class _ExplodingSession:
        def execute(self, *a, **kw):
            counter["calls"] += 1
            raise AssertionError("DB execute should never be called on a denied request.")
        def flush(self):
            counter["calls"] += 1
            raise AssertionError("DB flush should never be called on a denied request.")

    class _ImpUser:
        _is_impersonated = True
        id = "user_001"

    user = _ImpUser()
    user._admin_context = AdminIntentContext(  # type: ignore[attr-defined]
        type="user",
        surface="impersonation",
        acting_admin_id="admin_007",
        intent_admin_role="admin",
        impersonation_session_id="sess_denied_001",
        allow_writes=False,
    )

    try:
        with pytest.raises(HTTPException) as exc_info:
            await svc.update(
                db=_ExplodingSession(),
                user=user,
                context=user._admin_context,
                id=1,
                payload={"name": "x"},
            )
    finally:
        set_audit_handler(None)

    assert exc_info.value.status_code == 403
    assert counter["calls"] == 0
    assert len(captured) >= 1
    denied = [e for e in captured if e.get("status") == "denied"]
    assert len(denied) == 1
    assert denied[0]["error_code"] == "IMPERSONATION_WRITE_DENIED"


@pytest.mark.asyncio
async def test_audit_without_runtime_emits_structured_log(caplog):
    """Without a custom handler and no IntentRuntime, denial events log on the audit logger."""
    set_audit_handler(None)

    with caplog.at_level(logging.INFO, logger="intent_api_admin.audit"):
        await emit_audit_event(
            action="update",
            model_name="User",
            resource_id="user_001",
            admin_id="admin_007",
            role="admin",
            session_id="sess_rejected",
            is_impersonation=True,
            surface="impersonation",
            target_user_id="user_001",
            status="denied",
            error_code="IMPERSONATION_WRITE_DENIED",
        )

    # caplog records carry our extra fields
    matched = [
        r for r in caplog.records
        if r.name == "intent_api_admin.audit"
        and getattr(r, "error_code", None) == "IMPERSONATION_WRITE_DENIED"
    ]
    assert len(matched) >= 1
    rec = matched[0]
    assert getattr(rec, "surface", None) == "impersonation"
    assert getattr(rec, "acting_admin_id", None) == "admin_007"
