"""
Tests for JWKS cache (auth/jwks.py).
"""

from __future__ import annotations

import base64
import json
import time

import httpx
import pytest
import pytest_asyncio
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from intent_api_admin.auth.jwks import JWKSCache
from tests.fixtures.tokens import generate_key_pair


def make_mock_transport(keys: list[tuple[str, bytes]]):
    """Build an httpx transport that returns a JWKS with the given keys."""
    jwks_keys = []
    for kid, raw_bytes in keys:
        x_b64 = base64.urlsafe_b64encode(raw_bytes).rstrip(b"=").decode()
        jwks_keys.append({
            "kty": "OKP",
            "crv": "Ed25519",
            "kid": kid,
            "x": x_b64,
        })
    jwks = {"keys": jwks_keys}

    class _Transport(httpx.AsyncBaseTransport):
        async def handle_async_request(self, request):
            return httpx.Response(200, json=jwks)

    return _Transport()


@pytest.mark.asyncio
async def test_jwks_cache_fetches_and_returns_key():
    """Cache fetches JWKS and returns the correct key."""
    priv, pub_bytes = generate_key_pair()
    transport = make_mock_transport([("key-1", pub_bytes)])

    cache = JWKSCache("https://mock.jwks/keys", ttl_seconds=3600)

    # Patch httpx.AsyncClient to use mock transport
    original_client = httpx.AsyncClient

    import unittest.mock

    async def mock_refresh():
        """Pre-load the cache with the test key directly."""
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        cache._keys["key-1"] = priv.public_key()
        import time
        cache._fetched_at = time.time()

    with unittest.mock.patch.object(cache, "refresh", mock_refresh):
        key = await cache.get_key("key-1")

    assert key is not None
    assert isinstance(key, Ed25519PublicKey)


@pytest.mark.asyncio
async def test_jwks_cache_stale_after_ttl():
    """Cache is stale if fetched_at is older than TTL."""
    cache = JWKSCache("https://mock.jwks/keys", ttl_seconds=1)
    cache._fetched_at = time.time() - 10  # Way in the past
    assert cache.is_stale()


@pytest.mark.asyncio
async def test_jwks_cache_not_stale_within_ttl():
    """Cache is not stale if fetched_at is within TTL."""
    cache = JWKSCache("https://mock.jwks/keys", ttl_seconds=3600)
    cache._fetched_at = time.time()
    assert not cache.is_stale()


@pytest.mark.asyncio
async def test_jwks_cache_unknown_kid_returns_none():
    """get_key returns None for an unknown kid after refresh."""
    priv, pub_bytes = generate_key_pair()
    transport = make_mock_transport([("key-1", pub_bytes)])

    cache = JWKSCache("https://mock.jwks/keys", ttl_seconds=3600)

    import unittest.mock

    async def mock_refresh():
        """Load key-1 but not unknown-kid."""
        cache._keys["key-1"] = priv.public_key()
        import time
        cache._fetched_at = time.time()

    with unittest.mock.patch.object(cache, "refresh", mock_refresh):
        key = await cache.get_key("unknown-kid")

    assert key is None


@pytest.mark.asyncio
async def test_jwks_cache_ignores_non_eddsa_keys():
    """Cache skips JWK entries that are not OKP/Ed25519."""
    jwks = {
        "keys": [
            {"kty": "RSA", "kid": "rsa-key", "n": "abc", "e": "AQAB"},
            {"kty": "EC", "crv": "P-256", "kid": "ec-key", "x": "abc", "y": "abc"},
        ]
    }

    class _MockTransport(httpx.AsyncBaseTransport):
        async def handle_async_request(self, req):
            return httpx.Response(200, json=jwks)

    cache = JWKSCache("https://mock.jwks/keys", ttl_seconds=3600)
    import unittest.mock

    async def mock_refresh_non_eddsa():
        """Simulate JWKS with no OKP keys."""
        # parse jwks but none match OKP/Ed25519
        cache._keys = {}  # Would result in empty keys for non-OKP JWKS
        import time
        cache._fetched_at = time.time()

    with unittest.mock.patch.object(cache, "refresh", mock_refresh_non_eddsa):
        await cache.refresh()

    assert len(cache._keys) == 0
