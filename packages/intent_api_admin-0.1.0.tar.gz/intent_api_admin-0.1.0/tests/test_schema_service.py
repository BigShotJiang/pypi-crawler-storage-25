"""
Tests for the schema service (schema_service.py).
"""

from __future__ import annotations

import pytest
import sqlalchemy as sa
from sqlalchemy.orm import DeclarativeBase

from intent_api_admin.auto_admin.schemas import SchemaDocument


class Base(DeclarativeBase):
    pass


class Widget(Base):
    __tablename__ = "widgets_schema_test"
    id = sa.Column(sa.Integer, primary_key=True)
    name = sa.Column(sa.String(255))
    password_hash = sa.Column(sa.String(255))


def test_schema_document_has_version():
    """SchemaDocument requires a version field."""
    doc = SchemaDocument(
        version="abc123",
        audience="test",
        resources={},
        actions=[],
    )
    assert doc.version == "abc123"


def test_schema_document_serializes():
    """SchemaDocument can be serialized to dict."""
    doc = SchemaDocument(
        version="sha256hash",
        audience="test-product",
        resources={},
        actions=[],
    )
    d = doc.model_dump()
    assert d["version"] == "sha256hash"
    assert d["audience"] == "test-product"
    assert d["resources"] == {}
    assert d["actions"] == []


def test_schema_document_version_is_sha256_length():
    """Version can be a sha256 hex string (64 chars)."""
    import hashlib
    version = hashlib.sha256(b"test").hexdigest()
    doc = SchemaDocument(
        version=version,
        audience="test",
        resources={},
        actions=[],
    )
    assert len(doc.version) == 64
