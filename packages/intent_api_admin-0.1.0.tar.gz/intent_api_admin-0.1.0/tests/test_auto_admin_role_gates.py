"""
Tests for role-based access gates (role.py + preconditions.py).
"""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from intent_api.schemas import AdminIntentContext
from intent_api_admin.auto_admin.preconditions import check_preconditions, get_admin_context
from intent_api_admin.role import ROLE_RANK, check_role


# ── Role rank tests ───────────────────────────────────────────────────────────

def test_role_rank_owner_beats_admin():
    assert ROLE_RANK["owner"] > ROLE_RANK["admin"]


def test_role_rank_admin_beats_support():
    assert ROLE_RANK["admin"] > ROLE_RANK["support"]


def test_check_role_owner_satisfies_all():
    assert check_role("owner", "owner") is True
    assert check_role("admin", "owner") is True
    assert check_role("support", "owner") is True


def test_check_role_admin_satisfies_admin_and_support():
    assert check_role("admin", "admin") is True
    assert check_role("support", "admin") is True
    assert check_role("owner", "admin") is False


def test_check_role_support_satisfies_only_support():
    assert check_role("support", "support") is True
    assert check_role("admin", "support") is False
    assert check_role("owner", "support") is False


def test_check_role_none_fails_all():
    assert check_role("support", None) is False
    assert check_role("admin", None) is False
    assert check_role("owner", None) is False


# ── Precondition tests ────────────────────────────────────────────────────────

def make_admin_ctx(role="support", allow_writes=True, session_id=None):
    return AdminIntentContext(
        type="admin",
        surface="admin-machine",
        acting_admin_id="admin_001",
        intent_admin_role=role,
        allow_writes=allow_writes,
        impersonation_session_id=session_id,
    )


class FakeUser:
    def __init__(self, admin_ctx=None):
        if admin_ctx:
            self._admin_context = admin_ctx


def test_preconditions_insufficient_role_raises():
    """Action requiring 'admin' role fails for 'support' user."""
    ctx = make_admin_ctx(role="support")
    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="update",
            command=None,
            user=FakeUser(),
            context=ctx,
            required_role="admin",
            is_read_only_action=False,
            redacted_fields=set(),
            deny_edit_fields=set(),
            deny_delete=False,
            payload={},
        )
    assert exc_info.value.status_code == 403


def test_preconditions_sufficient_role_passes():
    """Action requiring 'support' role passes for 'admin' user."""
    ctx = make_admin_ctx(role="admin")
    # Should not raise
    check_preconditions(
        action="read",
        command=None,
        user=FakeUser(),
        context=ctx,
        required_role="support",
        is_read_only_action=True,
        redacted_fields=set(),
        deny_edit_fields=set(),
        deny_delete=False,
        payload=None,
    )


def test_preconditions_impersonation_write_denied():
    """Write action on read-only impersonation session raises 403."""
    ctx = make_admin_ctx(role="admin", allow_writes=False, session_id="sess_001")
    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="update",
            command=None,
            user=FakeUser(),
            context=ctx,
            required_role="support",
            is_read_only_action=False,
            redacted_fields=set(),
            deny_edit_fields=set(),
            deny_delete=False,
            payload={},
        )
    assert exc_info.value.status_code == 403


def test_preconditions_impersonation_write_allowed():
    """Write action on allow_writes=True impersonation session passes."""
    ctx = make_admin_ctx(role="admin", allow_writes=True, session_id="sess_001")
    # Should not raise
    check_preconditions(
        action="update",
        command=None,
        user=FakeUser(),
        context=ctx,
        required_role="support",
        is_read_only_action=False,
        redacted_fields=set(),
        deny_edit_fields=set(),
        deny_delete=False,
        payload={"name": "new name"},
    )


def test_preconditions_delete_denied():
    """Delete on a deny_delete model raises 403."""
    ctx = make_admin_ctx(role="owner")
    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="delete",
            command=None,
            user=FakeUser(),
            context=ctx,
            required_role="owner",
            is_read_only_action=False,
            redacted_fields=set(),
            deny_edit_fields=set(),
            deny_delete=True,
            payload=None,
        )
    assert exc_info.value.status_code == 403


def test_preconditions_field_redacted_raises():
    """Payload containing a redacted field raises 403."""
    ctx = make_admin_ctx(role="admin")
    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="update",
            command=None,
            user=FakeUser(),
            context=ctx,
            required_role="support",
            is_read_only_action=False,
            redacted_fields={"password_hash"},
            deny_edit_fields=set(),
            deny_delete=False,
            payload={"password_hash": "new_hash"},
        )
    assert exc_info.value.status_code == 403


def test_preconditions_field_read_only_raises():
    """Payload containing a deny_edit field raises 403."""
    ctx = make_admin_ctx(role="admin")
    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="update",
            command=None,
            user=FakeUser(),
            context=ctx,
            required_role="support",
            is_read_only_action=False,
            redacted_fields=set(),
            deny_edit_fields={"email"},
            deny_delete=False,
            payload={"email": "newemail@example.com"},
        )
    assert exc_info.value.status_code == 403


def test_get_admin_context_from_admin_intent_context():
    """get_admin_context returns context when it's already AdminIntentContext."""
    ctx = make_admin_ctx(role="admin")
    user = FakeUser()
    result = get_admin_context(user, ctx)
    assert result is ctx


def test_get_admin_context_from_user_admin_context():
    """get_admin_context falls back to user._admin_context for impersonated users."""
    ctx = make_admin_ctx(role="support")
    user = FakeUser(admin_ctx=ctx)
    result = get_admin_context(user, None)
    assert result is ctx
