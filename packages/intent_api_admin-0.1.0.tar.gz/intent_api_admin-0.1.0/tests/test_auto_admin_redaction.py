"""
Tests for field redaction in auto-admin responses.
"""

from __future__ import annotations

import pytest
import sqlalchemy as sa
from sqlalchemy.orm import DeclarativeBase

from intent_api_admin.auto_admin.heuristics import should_auto_redact
from intent_api_admin.auto_admin.introspector import introspect_model


class Base(DeclarativeBase):
    pass


class SecretModel(Base):
    __tablename__ = "secret_models"
    id = sa.Column(sa.Integer, primary_key=True)
    public_name = sa.Column(sa.String(100))
    password = sa.Column(sa.String(255))
    password_hash = sa.Column(sa.String(255))
    secret_key = sa.Column(sa.String(255))
    api_key_value = sa.Column(sa.String(255))
    token_value = sa.Column(sa.String(255))
    value_hash = sa.Column(sa.String(255))
    value_digest = sa.Column(sa.String(255))
    _internal_field = sa.Column("_internal_field", sa.String(100))


def test_auto_redact_password():
    assert should_auto_redact("password") is True


def test_auto_redact_password_hash():
    assert should_auto_redact("password_hash") is True


def test_auto_redact_secret():
    assert should_auto_redact("secret_key") is True


def test_auto_redact_api_key():
    assert should_auto_redact("api_key_value") is True


def test_auto_redact_token():
    assert should_auto_redact("token_value") is True


def test_auto_redact_hash_suffix():
    assert should_auto_redact("value_hash") is True


def test_auto_redact_digest_suffix():
    assert should_auto_redact("value_digest") is True


def test_auto_redact_underscore_prefix():
    assert should_auto_redact("_internal") is True


def test_no_redact_normal_fields():
    assert should_auto_redact("name") is False
    assert should_auto_redact("email") is False
    assert should_auto_redact("created_at") is False
    assert should_auto_redact("is_active") is False


def test_introspection_redacts_password_fields():
    """Introspection auto-redacts password-related columns."""
    schema = introspect_model(SecretModel)
    redacted = set(schema.redacted_fields)
    assert "password" in redacted
    assert "password_hash" in redacted
    assert "secret_key" in redacted
    assert "api_key_value" in redacted
    assert "token_value" in redacted
    assert "value_hash" in redacted
    assert "value_digest" in redacted


def test_introspection_keeps_public_fields():
    """Introspection does not redact normal public fields."""
    schema = introspect_model(SecretModel)
    redacted = set(schema.redacted_fields)
    assert "id" not in redacted
    assert "public_name" not in redacted
