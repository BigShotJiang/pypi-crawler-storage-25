"""
Tests for the admin-machine auth contract:
- A get_user that returns a user object WITHOUT `intent_admin_role`
  must be handled gracefully (the framework constructs a base
  IntentContext, and the service-layer role check fires with
  HTTP 403 INSUFFICIENT_ROLE — not 500, not AttributeError).
"""

from __future__ import annotations

from typing import Generator

import pytest
import sqlalchemy as sa
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from intent_api import IntentRouter
from intent_api_admin import auto_admin, configure_admin_auth
from intent_api_admin.config import _reset_config


@pytest.fixture
def app_with_roleless_auth():
    _reset_config()

    class Base(DeclarativeBase):
        pass

    class User(Base):
        __tablename__ = "ac_users"
        id = sa.Column(sa.Integer, primary_key=True)
        email = sa.Column(sa.String, nullable=False)

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    SessionFactory = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    with SessionFactory() as s:
        s.add(User(id=1, email="x@x.com"))
        s.commit()

    async def imp_query(db, target_user_id):
        return None

    configure_admin_auth(
        issuer="https://console.test", audience="prod",
        impersonation_user_query=imp_query, base=Base,
    )

    router = IntentRouter()
    auto_admin(router, expose=["User"])

    def get_db() -> Generator[Session, None, None]:
        db = SessionFactory()
        try:
            yield db
        finally:
            db.close()

    # Roleless user — no intent_admin_role attribute
    class _RolelessUser:
        id = "no_role_user"

    async def roleless_get_user(*, credentials, context, db):
        return _RolelessUser()

    app = FastAPI()
    app.include_router(
        router.build_admin_machine(get_user=roleless_get_user, get_db=get_db)
    )
    yield app
    _reset_config()


@pytest.mark.asyncio
async def test_roleless_user_returns_403_insufficient_role(app_with_roleless_auth):
    """Service-layer role check fires with INSUFFICIENT_ROLE when user has no role attribute."""
    async with AsyncClient(
        transport=ASGITransport(app=app_with_roleless_auth), base_url="http://test"
    ) as client:
        resp = await client.post(
            "/api/admin-machine-intent",
            json={"model": "AdminUser", "action": "list"},
            headers={"Authorization": "Bearer anything"},
        )
    assert resp.status_code == 403, resp.text
    detail = resp.json().get("detail")
    assert isinstance(detail, dict)
    assert detail["code"] == "INSUFFICIENT_ROLE"
