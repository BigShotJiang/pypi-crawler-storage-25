"""
S52: bidirectional consistency between TOKEN_CONTRACT.md and intent_api_admin.errors.

- Every error code that appears in TOKEN_CONTRACT.md must have a matching
  class in intent_api_admin.errors with `.code == "<CODE>"`.
- Every error class in intent_api_admin.errors must be documented in
  TOKEN_CONTRACT.md.

This test guards against doc drift. The doc is the source of truth for
the public error contract; the code must match.
"""

from __future__ import annotations

import inspect
import re
from pathlib import Path

import intent_api_admin.errors as errors_mod
from intent_api.providers.errors import IntentRuntimeError


REPO_ROOT = Path(__file__).resolve().parents[1]
TOKEN_CONTRACT = REPO_ROOT / "TOKEN_CONTRACT.md"


def _extract_doc_codes() -> set[str]:
    """Pull SCREAMING_SNAKE_CASE tokens from the error code table in TOKEN_CONTRACT.md."""
    text = TOKEN_CONTRACT.read_text(encoding="utf-8")
    # Match identifiers in backticks that look like error codes
    code_re = re.compile(r"`([A-Z][A-Z0-9_]{2,})`")
    candidates = set(code_re.findall(text))
    # Filter to ones that look like our error codes (contain at least one underscore
    # OR are exact known names). Drop noise like "JWT", "PEM", "JWKS", "RFC", "OKP",
    # "OAUTH", "EdDSA" (mixed case), etc.
    blocklist = {
        "JWT", "JWKS", "PEM", "RFC", "OKP", "URL", "TTL", "TLS", "SSL",
        "JSON", "REST", "MCP", "SDK", "M2M", "CRUD", "API", "HTTP", "HTTPS",
        "POST", "GET", "PUT", "DELETE", "ASCII", "UTF", "UUID", "ID",
        "EDDSA", "HMAC", "SHA", "RSA", "ECDSA", "ED25519", "JWS", "JWE",
        "POSIX",
    }
    return {c for c in candidates if c not in blocklist and ("_" in c or len(c) > 8)}


def _extract_error_classes() -> dict[str, type]:
    """Find all IntentRuntimeError subclasses in intent_api_admin.errors with a `.code`."""
    out: dict[str, type] = {}
    for name, obj in inspect.getmembers(errors_mod, inspect.isclass):
        if obj is IntentRuntimeError:
            continue
        if not issubclass(obj, IntentRuntimeError):
            continue
        code = getattr(obj, "code", None)
        if isinstance(code, str) and code:
            out[code] = obj
    return out


def test_every_doc_code_has_an_error_class():
    doc_codes = _extract_doc_codes()
    code_classes = _extract_error_classes()
    missing = doc_codes - set(code_classes.keys())
    assert not missing, (
        f"Codes documented in TOKEN_CONTRACT.md but missing from "
        f"intent_api_admin.errors: {sorted(missing)}"
    )


def test_every_error_class_is_documented():
    doc_codes = _extract_doc_codes()
    code_classes = _extract_error_classes()
    undocumented = set(code_classes.keys()) - doc_codes
    assert not undocumented, (
        f"Error classes in intent_api_admin.errors not documented in "
        f"TOKEN_CONTRACT.md: {sorted(undocumented)}"
    )
