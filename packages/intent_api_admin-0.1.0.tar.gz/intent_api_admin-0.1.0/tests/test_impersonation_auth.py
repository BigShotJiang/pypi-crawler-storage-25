"""
Tests for impersonation auth (auth/impersonation.py).
"""

from __future__ import annotations

import pytest
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from intent_api.schemas import IntentContext, AdminIntentContext
from intent_api_admin.auth.impersonation import ImpersonatedUser, impersonation_aware_auth
from intent_api_admin.config import configure_admin_auth
from tests.fixtures.tokens import (
    generate_key_pair,
    make_admin_token,
    make_impersonation_token,
)
from tests.fixtures.jwks_server import make_mock_jwks_cache


class FakeUser:
    def __init__(self, id, email, name=None):
        self.id = id
        self.email = email
        self.name = name


@pytest.fixture
def key_and_cache():
    priv, pub = generate_key_pair()
    kid = "key-imp-001"
    cache, _ = make_mock_jwks_cache(kid, priv)
    return priv, kid, cache


@pytest.fixture
def configured_app(key_and_cache):
    priv, kid, cache = key_and_cache
    issuer = "https://console.test"
    audience = "test-product"
    target_user = FakeUser(id="user_target_001", email="target@example.com", name="Target User")

    async def user_query(db, uid):
        if uid == target_user.id:
            return target_user
        return None

    async def base_get_user(*, credentials, context, db):
        return FakeUser(id="standard_user", email="standard@example.com")

    configure_admin_auth(
        issuer=issuer,
        audience=audience,
        impersonation_user_query=user_query,
        jwks_url="https://mock.jwks/keys",
    )

    import intent_api_admin.auth.impersonation as imp_module
    imp_module._impersonation_jwks_cache = cache

    return priv, kid, issuer, audience, target_user, base_get_user


@pytest.mark.asyncio
async def test_impersonation_token_returns_impersonated_user(configured_app):
    """Valid impersonation token returns ImpersonatedUser with target user attributes."""
    priv, kid, issuer, audience, target_user, base_get_user = configured_app

    token = make_impersonation_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience,
        target_user_id=target_user.id,
        session_id="sess_001",
        role="support",
        allow_writes=False,
    )

    get_user = impersonation_aware_auth(base_get_user)
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)
    context = IntentContext(type="user")

    user = await get_user(credentials=creds, context=context, db=None)

    assert isinstance(user, ImpersonatedUser)
    assert user.id == target_user.id
    assert user.email == target_user.email
    assert user._is_impersonated is True
    assert user._admin_context.acting_admin_id == "admin_001"
    assert user._admin_context.impersonation_session_id == "sess_001"
    assert user._admin_context.allow_writes is False


@pytest.mark.asyncio
async def test_impersonation_mutates_context_surface(configured_app):
    """Impersonation auth mutates context.surface to 'impersonation'."""
    priv, kid, issuer, audience, target_user, base_get_user = configured_app

    token = make_impersonation_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience,
        target_user_id=target_user.id,
    )

    get_user = impersonation_aware_auth(base_get_user)
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)
    context = IntentContext(type="user")

    await get_user(credentials=creds, context=context, db=None)

    assert context.surface == "impersonation"


@pytest.mark.asyncio
async def test_admin_token_on_standard_surface_raises_403(configured_app):
    """Admin token on standard surface raises HTTP 403."""
    priv, kid, issuer, audience, target_user, base_get_user = configured_app

    token = make_admin_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience, role="admin",
    )

    get_user = impersonation_aware_auth(base_get_user)
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)

    with pytest.raises(HTTPException) as exc_info:
        await get_user(credentials=creds, context=None, db=None)
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_regular_bearer_falls_through_to_base(configured_app):
    """A non-console token falls through to base_get_user."""
    priv, kid, issuer, audience, target_user, base_get_user = configured_app

    get_user = impersonation_aware_auth(base_get_user)
    # Use a plain Bearer token (not a JWT)
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials="sk_live_regulartoken")

    user = await get_user(credentials=creds, context=None, db=None)

    assert user.id == "standard_user"


@pytest.mark.asyncio
async def test_impersonated_user_attribute_delegation():
    """ImpersonatedUser delegates attribute access to target user."""
    target = FakeUser(id="u1", email="u1@example.com", name="Alice")
    ctx = AdminIntentContext(
        type="user",
        surface="impersonation",
        acting_admin_id="admin_1",
        impersonation_session_id="sess_1",
    )
    proxy = ImpersonatedUser(target_user=target, admin_context=ctx)

    assert proxy.id == "u1"
    assert proxy.email == "u1@example.com"
    assert proxy.name == "Alice"
    assert proxy._is_impersonated is True
    assert proxy._admin_context.acting_admin_id == "admin_1"


@pytest.mark.asyncio
async def test_impersonated_user_private_attr_raises():
    """ImpersonatedUser raises AttributeError for private attributes not on the proxy."""
    target = FakeUser(id="u1", email="u1@example.com")
    ctx = AdminIntentContext(type="user", acting_admin_id="a1")
    proxy = ImpersonatedUser(target_user=target, admin_context=ctx)

    with pytest.raises(AttributeError):
        _ = proxy._nonexistent_private
