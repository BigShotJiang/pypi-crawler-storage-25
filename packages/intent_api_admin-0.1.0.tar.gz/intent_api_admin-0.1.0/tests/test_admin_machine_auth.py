"""
Tests for admin-machine auth (auth/admin_machine.py).
"""

from __future__ import annotations

import pytest
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from intent_api_admin.auth.admin_machine import admin_machine_auth
from intent_api_admin.config import configure_admin_auth
from tests.fixtures.tokens import (
    generate_key_pair,
    make_admin_token,
    make_impersonation_token,
)
from tests.fixtures.jwks_server import make_mock_jwks_cache


def dummy_user_query(db, uid):
    return None


@pytest.fixture
def key_pair():
    priv, pub = generate_key_pair()
    return priv, pub


@pytest.fixture
def config_and_cache(key_pair):
    priv, pub = key_pair
    kid = "key-am-001"
    issuer = "https://console.test"
    audience = "test-product"

    cache, transport = make_mock_jwks_cache(kid, priv)

    configure_admin_auth(
        issuer=issuer,
        audience=audience,
        impersonation_user_query=dummy_user_query,
        jwks_url="https://mock.jwks/keys",
    )

    return priv, kid, issuer, audience, cache


@pytest.mark.asyncio
async def test_admin_machine_auth_accepts_valid_admin_token(config_and_cache):
    """Valid admin token returns an admin user object."""
    priv, kid, issuer, audience, cache = config_and_cache

    token = make_admin_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience, role="owner",
    )

    from intent_api_admin.auth.admin_machine import _reset_jwks_cache
    _reset_jwks_cache()

    # Patch the cache
    import intent_api_admin.auth.admin_machine as am_module
    am_module._jwks_cache = cache

    get_user = admin_machine_auth()
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)
    user = await get_user(credentials=creds, context=None, db=None)

    assert user.id == "admin_001"
    assert user.intent_admin_role == "owner"
    assert user.acting_admin_id == "admin_001"


@pytest.mark.asyncio
async def test_admin_machine_auth_rejects_impersonation_token(config_and_cache):
    """Impersonation token on admin-machine surface raises HTTP 403."""
    priv, kid, issuer, audience, cache = config_and_cache

    token = make_impersonation_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience,
        target_user_id="user_123",
    )

    import intent_api_admin.auth.admin_machine as am_module
    am_module._jwks_cache = cache

    get_user = admin_machine_auth()
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)

    with pytest.raises(HTTPException) as exc_info:
        await get_user(credentials=creds, context=None, db=None)
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_admin_machine_auth_rejects_expired_token(config_and_cache):
    """Expired token raises HTTP 401."""
    from tests.fixtures.tokens import make_expired_token
    priv, kid, issuer, audience, cache = config_and_cache

    token = make_expired_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience,
    )

    import intent_api_admin.auth.admin_machine as am_module
    am_module._jwks_cache = cache

    get_user = admin_machine_auth()
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)

    with pytest.raises(HTTPException) as exc_info:
        await get_user(credentials=creds, context=None, db=None)
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_admin_machine_auth_includes_email_if_present(config_and_cache):
    """Admin token with email claim populates user.email."""
    priv, kid, issuer, audience, cache = config_and_cache

    token = make_admin_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience, role="admin",
        email="admin@example.com",
    )

    import intent_api_admin.auth.admin_machine as am_module
    am_module._jwks_cache = cache

    get_user = admin_machine_auth()
    creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)
    user = await get_user(credentials=creds, context=None, db=None)

    assert user.email == "admin@example.com"
