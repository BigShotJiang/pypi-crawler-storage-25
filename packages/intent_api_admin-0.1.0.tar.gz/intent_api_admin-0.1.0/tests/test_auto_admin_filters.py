"""
Tests for filter and sort application (auto_admin/filters.py).
"""

from __future__ import annotations

import pytest
import sqlalchemy as sa
from fastapi import HTTPException
from sqlalchemy.orm import DeclarativeBase

from intent_api_admin.auto_admin.filters import apply_filters, apply_sort
from intent_api_admin.errors import UnsupportedFilterOp


class Base(DeclarativeBase):
    pass


class Item(Base):
    __tablename__ = "items"

    id = sa.Column(sa.Integer, primary_key=True)
    name = sa.Column(sa.String(255), nullable=True)
    score = sa.Column(sa.Float, nullable=True)
    is_active = sa.Column(sa.Boolean, nullable=True)


def make_select():
    return sa.select(Item)


def test_apply_filters_eq():
    """eq filter produces WHERE clause."""
    query = apply_filters(make_select(), Item, [{"field": "name", "op": "eq", "value": "Alice"}])
    compiled = str(query.compile(compile_kwargs={"literal_binds": True}))
    assert "Alice" in compiled


def test_apply_filters_contains():
    """contains filter produces ILIKE clause."""
    query = apply_filters(make_select(), Item, [{"field": "name", "op": "contains", "value": "ali"}])
    compiled = str(query.compile(compile_kwargs={"literal_binds": True}))
    assert "ali" in compiled.lower()


def test_apply_filters_gt():
    """gt filter produces > comparison."""
    query = apply_filters(make_select(), Item, [{"field": "score", "op": "gt", "value": 5.0}])
    compiled = str(query.compile(compile_kwargs={"literal_binds": True}))
    assert ">" in compiled


def test_apply_filters_in():
    """in filter produces IN clause."""
    query = apply_filters(make_select(), Item, [{"field": "id", "op": "in", "value": [1, 2, 3]}])
    compiled = str(query.compile(compile_kwargs={"literal_binds": True}))
    assert "IN" in compiled.upper()


def test_apply_filters_is_null():
    """is_null filter produces IS NULL."""
    query = apply_filters(make_select(), Item, [{"field": "name", "op": "is_null"}])
    compiled = str(query.compile())
    assert "NULL" in compiled.upper()


def test_apply_filters_unsupported_op_raises():
    """Unsupported op raises UnsupportedFilterOp (HTTP 422)."""
    with pytest.raises(HTTPException) as exc_info:
        apply_filters(make_select(), Item, [{"field": "name", "op": "fuzzy", "value": "x"}])
    assert exc_info.value.status_code == 422


def test_apply_filters_unknown_field_raises():
    """Unknown field raises HTTP 400."""
    with pytest.raises(HTTPException) as exc_info:
        apply_filters(make_select(), Item, [{"field": "nonexistent", "op": "eq", "value": "x"}])
    assert exc_info.value.status_code == 400


def test_apply_sort_asc():
    """Sort ascending produces ORDER BY ... ASC."""
    query = apply_sort(make_select(), Item, [{"field": "score", "direction": "asc"}])
    compiled = str(query.compile())
    assert "score" in compiled.lower()


def test_apply_sort_desc():
    """Sort descending produces ORDER BY ... DESC."""
    query = apply_sort(make_select(), Item, [{"field": "id", "direction": "desc"}])
    compiled = str(query.compile())
    assert "DESC" in compiled.upper()


def test_apply_sort_unknown_field_raises():
    """Unknown sort field raises HTTP 400."""
    with pytest.raises(HTTPException) as exc_info:
        apply_sort(make_select(), Item, [{"field": "badfield", "direction": "asc"}])
    assert exc_info.value.status_code == 400
