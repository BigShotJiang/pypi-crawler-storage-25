"""
Tests for read-only custom actions during impersonation.
"""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from intent_api.schemas import AdminIntentContext
from intent_api_admin.auto_admin.preconditions import check_preconditions


def make_impersonation_ctx(role="support", allow_writes=False):
    return AdminIntentContext(
        type="user",
        surface="impersonation",
        acting_admin_id="admin_001",
        intent_admin_role=role,
        allow_writes=allow_writes,
        impersonation_session_id="sess_readonly_001",
    )


class FakeUser:
    pass


def test_read_only_action_allowed_during_impersonation():
    """Read-only custom action is allowed during read-only impersonation."""
    ctx = make_impersonation_ctx(role="support", allow_writes=False)
    # Should not raise
    check_preconditions(
        action="custom",
        command="view_audit",
        user=FakeUser(),
        context=ctx,
        required_role="support",
        is_read_only_action=True,
        redacted_fields=set(),
        deny_edit_fields=set(),
        deny_delete=False,
        payload=None,
    )


def test_write_action_denied_during_read_only_impersonation():
    """Write action is denied during read-only impersonation."""
    ctx = make_impersonation_ctx(role="admin", allow_writes=False)
    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="update",
            command=None,
            user=FakeUser(),
            context=ctx,
            required_role="support",
            is_read_only_action=False,
            redacted_fields=set(),
            deny_edit_fields=set(),
            deny_delete=False,
            payload={"name": "new"},
        )
    assert exc_info.value.status_code == 403


def test_write_action_allowed_during_allow_writes_impersonation():
    """Write action is allowed when allow_writes=True in impersonation."""
    ctx = make_impersonation_ctx(role="admin", allow_writes=True)
    # Should not raise
    check_preconditions(
        action="update",
        command=None,
        user=FakeUser(),
        context=ctx,
        required_role="support",
        is_read_only_action=False,
        redacted_fields=set(),
        deny_edit_fields=set(),
        deny_delete=False,
        payload={"name": "new"},
    )


def test_non_impersonation_session_ignores_allow_writes():
    """Non-impersonation context (no session_id) doesn't check allow_writes."""
    ctx = AdminIntentContext(
        type="admin",
        surface="admin-machine",
        acting_admin_id="admin_001",
        intent_admin_role="admin",
        allow_writes=False,  # Doesn't matter — no session_id
    )
    # Should not raise (no impersonation session)
    check_preconditions(
        action="update",
        command=None,
        user=FakeUser(),
        context=ctx,
        required_role="support",
        is_read_only_action=False,
        redacted_fields=set(),
        deny_edit_fields=set(),
        deny_delete=False,
        payload={"name": "new"},
    )
