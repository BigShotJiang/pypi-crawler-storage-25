"""
Tests for precondition enforcement in auto-admin service handlers.

Tests that the service_factory-generated services actually enforce
preconditions (role, impersonation write-denial, etc.) at the handler level.
"""

from __future__ import annotations

import pytest
import sqlalchemy as sa
from fastapi import HTTPException
from sqlalchemy.orm import DeclarativeBase, Session

from intent_api.schemas import AdminIntentContext
from intent_api_admin.auto_admin.service_factory import make_admin_service
from intent_api_admin.auto_admin.schemas import ResourceSchema, FieldSchema
from intent_api_admin.audit import emit_audit_event


class Base(DeclarativeBase):
    pass


class Product(Base):
    __tablename__ = "products_precond_test"
    id = sa.Column(sa.Integer, primary_key=True)
    name = sa.Column(sa.String(255))
    price = sa.Column(sa.Float)
    secret = sa.Column(sa.String(255))


def make_schema():
    return ResourceSchema(
        model_name="Product",
        display_name="Product",
        display_prefix="Product",
        fields={
            "id": FieldSchema(name="id", type="int", nullable=False, primary_key=True, read_only=True),
            "name": FieldSchema(name="name", type="str", nullable=True, primary_key=False, read_only=False),
            "price": FieldSchema(name="price", type="float", nullable=True, primary_key=False, read_only=False),
            "secret": FieldSchema(name="secret", type="str", nullable=True, primary_key=False, read_only=False),
        },
        relationships={},
        list_fields=["id", "name", "price"],
        search_fields=["name"],
        default_sort="id desc",
        deny_delete=False,
        deny_edit_fields=[],
        redacted_fields=["secret"],
    )


def make_db():
    engine = sa.create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    from sqlalchemy.orm import sessionmaker
    return sessionmaker(bind=engine)()


def make_admin_ctx(role="support", allow_writes=False, session_id=None):
    return AdminIntentContext(
        type="admin",
        surface="admin-machine",
        acting_admin_id="admin_001",
        intent_admin_role=role,
        allow_writes=allow_writes,
        impersonation_session_id=session_id,
    )


class MockAdminUser:
    def __init__(self, role="support"):
        self.id = "admin_001"
        self.intent_admin_role = role
        self.acting_admin_id = "admin_001"


@pytest.mark.asyncio
async def test_list_requires_support_role():
    """list handler raises 403 for a user with no role."""
    schema = make_schema()
    service_cls = make_admin_service(
        model_name="AdminProduct",
        model_class=Product,
        resource_schema=schema,
        deny_delete=False,
        deny_edit_fields=set(),
        redacted_fields={"secret"},
        audit_fn=emit_audit_event,
    )
    service = service_cls()
    db = make_db()

    # User with no role
    ctx = AdminIntentContext(type="admin", surface="admin-machine", acting_admin_id="a1", intent_admin_role=None)

    with pytest.raises(HTTPException) as exc_info:
        await service.list(db=db, user=MockAdminUser(role=None), context=ctx, skip=0, limit=10)
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_update_requires_admin_role():
    """update handler raises 403 for 'support' role."""
    schema = make_schema()
    service_cls = make_admin_service(
        model_name="AdminProduct",
        model_class=Product,
        resource_schema=schema,
        deny_delete=False,
        deny_edit_fields=set(),
        redacted_fields={"secret"},
        audit_fn=emit_audit_event,
    )
    service = service_cls()
    db = make_db()

    ctx = make_admin_ctx(role="support")

    with pytest.raises(HTTPException) as exc_info:
        await service.update(db=db, user=MockAdminUser(role="support"), context=ctx, id=1, payload={"name": "X"})
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_update_redacted_field_raises_403():
    """Updating a redacted field raises 403."""
    schema = make_schema()
    service_cls = make_admin_service(
        model_name="AdminProduct",
        model_class=Product,
        resource_schema=schema,
        deny_delete=False,
        deny_edit_fields=set(),
        redacted_fields={"secret"},
        audit_fn=emit_audit_event,
    )
    service = service_cls()
    db = make_db()

    ctx = make_admin_ctx(role="admin")

    with pytest.raises(HTTPException) as exc_info:
        await service.update(db=db, user=MockAdminUser(role="admin"), context=ctx, id=1, payload={"secret": "newval"})
    assert exc_info.value.status_code == 403


@pytest.mark.asyncio
async def test_delete_denied_raises_403():
    """Delete on a deny_delete service raises 403."""
    schema = make_schema()
    service_cls = make_admin_service(
        model_name="AdminProduct",
        model_class=Product,
        resource_schema=schema,
        deny_delete=True,
        deny_edit_fields=set(),
        redacted_fields={"secret"},
        audit_fn=emit_audit_event,
    )
    service = service_cls()
    db = make_db()

    ctx = make_admin_ctx(role="owner")

    with pytest.raises(HTTPException) as exc_info:
        await service.delete(db=db, user=MockAdminUser(role="owner"), context=ctx, id=1)
    assert exc_info.value.status_code == 403
