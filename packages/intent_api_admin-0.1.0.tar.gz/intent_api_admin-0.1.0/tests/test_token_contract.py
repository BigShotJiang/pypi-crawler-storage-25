"""
Tests for token verification contract (auth/tokens.py).
"""

from __future__ import annotations

import pytest

from intent_api_admin.auth.jwks import JWKSCache
from intent_api_admin.auth.tokens import verify_token
from intent_api_admin.config import AdminAuthConfig
from tests.fixtures.tokens import (
    generate_key_pair,
    make_admin_token,
    make_expired_token,
    make_impersonation_token,
)


def make_config(issuer: str, audience: str, jwks_url: str) -> AdminAuthConfig:
    return AdminAuthConfig(
        issuer=issuer,
        audience=audience,
        jwks_url=jwks_url,
        impersonation_user_query=lambda db, uid: None,
    )


async def make_cache_with_key(kid: str, private_key) -> JWKSCache:
    """Create a JWKSCache pre-loaded with the given key."""
    import base64
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    import time

    pub_key = private_key.public_key()
    cache = JWKSCache("https://mock.jwks/keys", ttl_seconds=3600)
    cache._keys[kid] = pub_key
    cache._fetched_at = time.time()
    return cache


@pytest.mark.asyncio
async def test_verify_admin_token_succeeds():
    """Valid admin token verifies successfully."""
    priv, _ = generate_key_pair()
    kid = "key-1"
    issuer = "https://console.test"
    audience = "my-product"

    token = make_admin_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience, role="admin",
    )

    config = make_config(issuer=issuer, audience=audience, jwks_url="https://mock.jwks/keys")
    cache = await make_cache_with_key(kid, priv)

    claims = await verify_token(token, config, cache)

    assert claims["sub"] == "admin_001"
    assert claims["mode"] == "admin"
    assert claims["intent_admin_role"] == "admin"


@pytest.mark.asyncio
async def test_verify_impersonation_token_succeeds():
    """Valid impersonation token verifies successfully."""
    priv, _ = generate_key_pair()
    kid = "key-1"
    issuer = "https://console.test"
    audience = "my-product"

    token = make_impersonation_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience,
        target_user_id="user_target_001",
        session_id="sess_001",
        role="support",
        allow_writes=False,
    )

    config = make_config(issuer=issuer, audience=audience, jwks_url="https://mock.jwks/keys")
    cache = await make_cache_with_key(kid, priv)

    claims = await verify_token(token, config, cache)

    assert claims["mode"] == "impersonation"
    assert claims["target_user_id"] == "user_target_001"
    assert claims["allow_writes"] is False


@pytest.mark.asyncio
async def test_expired_token_raises_401():
    """Expired token raises HTTP 401."""
    from fastapi import HTTPException

    priv, _ = generate_key_pair()
    kid = "key-1"
    issuer = "https://console.test"
    audience = "my-product"

    token = make_expired_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience=audience,
    )

    config = make_config(issuer=issuer, audience=audience, jwks_url="https://mock.jwks/keys")
    cache = await make_cache_with_key(kid, priv)

    with pytest.raises(HTTPException) as exc_info:
        await verify_token(token, config, cache)
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_wrong_audience_raises_401():
    """Token with wrong audience raises HTTP 401."""
    from fastapi import HTTPException

    priv, _ = generate_key_pair()
    kid = "key-1"
    issuer = "https://console.test"

    token = make_admin_token(
        private_key=priv, kid=kid, sub="admin_001",
        issuer=issuer, audience="wrong-audience",
    )

    config = make_config(issuer=issuer, audience="correct-audience", jwks_url="https://mock.jwks/keys")
    cache = await make_cache_with_key(kid, priv)

    with pytest.raises(HTTPException) as exc_info:
        await verify_token(token, config, cache)
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_non_eddsa_token_raises_401():
    """HS256 token raises HTTP 401."""
    import jwt as _jwt
    from fastapi import HTTPException

    token = _jwt.encode(
        {"sub": "x", "iss": "https://console.test", "aud": "prod"},
        "secret",
        algorithm="HS256",
    )

    priv, _ = generate_key_pair()
    config = make_config(
        issuer="https://console.test", audience="prod",
        jwks_url="https://mock.jwks/keys",
    )
    cache = await make_cache_with_key("key-1", priv)

    with pytest.raises(HTTPException) as exc_info:
        await verify_token(token, config, cache)
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_unknown_kid_raises_401():
    """Token with unknown kid raises HTTP 401 after JWKS refresh."""
    import time
    from fastapi import HTTPException
    from unittest.mock import AsyncMock

    priv, _ = generate_key_pair()
    kid = "known-key"
    unknown_kid = "unknown-key"
    issuer = "https://console.test"
    audience = "my-product"

    token = make_admin_token(
        private_key=priv, kid=unknown_kid, sub="admin_001",
        issuer=issuer, audience=audience,
    )

    config = make_config(issuer=issuer, audience=audience, jwks_url="https://mock.jwks/keys")
    cache = JWKSCache("https://mock.jwks/keys", ttl_seconds=3600)
    # Pre-load with a different key
    cache._keys[kid] = priv.public_key()
    cache._fetched_at = time.time()

    # Mock refresh to return only the known kid (unknown_kid remains unknown)
    async def mock_refresh():
        cache._keys = {kid: priv.public_key()}
        cache._fetched_at = time.time()

    cache.refresh = mock_refresh

    with pytest.raises(HTTPException) as exc_info:
        await verify_token(token, config, cache)
    assert exc_info.value.status_code == 401
