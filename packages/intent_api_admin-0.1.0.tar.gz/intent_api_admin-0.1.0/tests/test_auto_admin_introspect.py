"""
Tests for SQLAlchemy model introspection (auto_admin/introspector.py).
"""

from __future__ import annotations

import datetime
import uuid

import pytest
import sqlalchemy as sa
from sqlalchemy.orm import DeclarativeBase

from intent_api_admin.auto_admin.introspector import introspect_model
from intent_api_admin.auto_admin.schemas import ResourceSchema


class Base(DeclarativeBase):
    pass


class SampleModel(Base):
    __tablename__ = "sample_models"

    id = sa.Column(sa.String(36), primary_key=True)
    email = sa.Column(sa.String(255), nullable=False, unique=True, index=True)
    name = sa.Column(sa.String(255), nullable=True)
    password_hash = sa.Column(sa.String(255), nullable=True)  # Should be auto-redacted
    secret_token = sa.Column(sa.String(100), nullable=True)  # Should be auto-redacted
    score = sa.Column(sa.Float, nullable=True)
    is_active = sa.Column(sa.Boolean, default=True)
    created_at = sa.Column(sa.DateTime, nullable=True)


def test_introspect_model_returns_resource_schema():
    """introspect_model returns a valid ResourceSchema."""
    schema = introspect_model(SampleModel)
    assert isinstance(schema, ResourceSchema)
    assert schema.model_name == "SampleModel"


def test_introspect_model_field_types():
    """Field types are mapped correctly from SQLAlchemy types."""
    schema = introspect_model(SampleModel)
    assert schema.fields["id"].type == "str"
    assert schema.fields["id"].primary_key is True
    assert schema.fields["email"].type == "str"
    assert schema.fields["score"].type == "float"
    assert schema.fields["is_active"].type == "bool"
    assert schema.fields["created_at"].type == "datetime"


def test_introspect_model_auto_redacts_password():
    """password_hash is automatically redacted."""
    schema = introspect_model(SampleModel)
    assert "password_hash" in schema.redacted_fields


def test_introspect_model_auto_redacts_secret():
    """secret_token is automatically redacted."""
    schema = introspect_model(SampleModel)
    assert "secret_token" in schema.redacted_fields


def test_introspect_model_explicit_redact():
    """Explicitly redacted fields are included in redacted_fields."""
    schema = introspect_model(SampleModel, redact=["score"])
    assert "score" in schema.redacted_fields


def test_introspect_model_pk_is_read_only():
    """Primary key fields are always read-only."""
    schema = introspect_model(SampleModel)
    assert schema.fields["id"].read_only is True


def test_introspect_model_deny_edit_fields():
    """deny_edit_fields marks fields as read-only and appears in deny_edit_fields."""
    schema = introspect_model(SampleModel, deny_edit_fields=["email"])
    assert "email" in schema.deny_edit_fields
    assert schema.fields["email"].read_only is True


def test_introspect_model_deny_delete():
    """deny_delete flag is preserved in schema."""
    schema = introspect_model(SampleModel, deny_delete=True)
    assert schema.deny_delete is True


def test_introspect_model_list_fields_includes_pk():
    """list_fields always includes the primary key."""
    schema = introspect_model(SampleModel)
    assert "id" in schema.list_fields


def test_introspect_model_default_sort():
    """default_sort is 'created_at desc' when created_at column exists."""
    schema = introspect_model(SampleModel)
    assert schema.default_sort == "created_at desc"


def test_introspect_model_display_name():
    """Display name is humanized from CamelCase."""
    schema = introspect_model(SampleModel)
    assert "Sample" in schema.display_name
