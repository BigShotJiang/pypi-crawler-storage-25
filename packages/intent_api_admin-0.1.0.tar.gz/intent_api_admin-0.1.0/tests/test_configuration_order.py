"""
Tests for configuration ordering invariants:
- auto_admin() before configure_admin_auth() raises AdminAuthNotConfigured.
- configure_admin_auth() called again after auto_admin() raises ConfigurationOrderError.
"""

from __future__ import annotations

import pytest
from sqlalchemy.orm import DeclarativeBase

from intent_api import IntentRouter
from intent_api_admin import auto_admin, configure_admin_auth
from intent_api_admin.config import _reset_config
from intent_api_admin.errors import AdminAuthNotConfigured, ConfigurationOrderError


@pytest.fixture(autouse=True)
def _reset():
    _reset_config()
    yield
    _reset_config()


class Base(DeclarativeBase):
    pass


def _dummy_query(db, uid):
    return None


def test_auto_admin_before_configure_raises():
    """Calling auto_admin() before configure_admin_auth() raises AdminAuthNotConfigured."""
    router = IntentRouter()
    with pytest.raises(AdminAuthNotConfigured):
        auto_admin(router, expose=["NoSuchModel"])


def test_configure_after_auto_admin_raises():
    """configure_admin_auth() raises ConfigurationOrderError after auto_admin() has been called."""
    configure_admin_auth(
        issuer="https://console.test", audience="prod",
        impersonation_user_query=_dummy_query, base=Base,
    )
    router = IntentRouter()
    auto_admin(router, expose=[])

    with pytest.raises(ConfigurationOrderError):
        configure_admin_auth(
            issuer="https://console.test", audience="prod",
            impersonation_user_query=_dummy_query, base=Base,
        )


def test_configure_twice_before_auto_admin_is_allowed():
    """Re-configuring before auto_admin is fine — only post-auto_admin re-config is forbidden."""
    configure_admin_auth(
        issuer="https://console.test", audience="prod",
        impersonation_user_query=_dummy_query, base=Base,
    )
    configure_admin_auth(
        issuer="https://console.test.v2", audience="prod",
        impersonation_user_query=_dummy_query, base=Base,
    )
