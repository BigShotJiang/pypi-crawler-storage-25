"""
Tests for error types and HTTP mapping (errors.py).
"""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from intent_api_admin.errors import (
    AdminAuthNotConfigured,
    ConfigurationOrderError,
    DeleteDenied,
    FieldReadOnly,
    FieldRedacted,
    ImpersonationWriteDenied,
    InsufficientRole,
    ModelNotFound,
    UnsupportedFilterOp,
    WrongSurface,
)


def test_wrong_surface_is_403():
    exc = WrongSurface("test detail")
    http = exc.to_http_exception()
    assert http.status_code == 403
    assert http.detail["code"] == "WRONG_SURFACE"


def test_impersonation_write_denied_is_403():
    exc = ImpersonationWriteDenied("update")
    http = exc.to_http_exception()
    assert http.status_code == 403
    assert "update" in str(http.detail)


def test_insufficient_role_is_403():
    exc = InsufficientRole("admin", "support")
    http = exc.to_http_exception()
    assert http.status_code == 403
    assert http.detail["required"] == "admin"
    assert http.detail["actual"] == "support"


def test_field_redacted_is_403():
    exc = FieldRedacted("password_hash")
    http = exc.to_http_exception()
    assert http.status_code == 403
    assert "password_hash" in str(http.detail)


def test_delete_denied_is_403():
    exc = DeleteDenied("User")
    http = exc.to_http_exception()
    assert http.status_code == 403


def test_field_read_only_is_403():
    exc = FieldReadOnly("email")
    http = exc.to_http_exception()
    assert http.status_code == 403
    assert "email" in str(http.detail)


def test_unsupported_filter_op_is_422():
    exc = UnsupportedFilterOp("fuzzy")
    http = exc.to_http_exception()
    assert http.status_code == 422
    assert "fuzzy" in str(http.detail)


def test_model_not_found_has_code():
    exc = ModelNotFound("Foo")
    assert exc.code == "MODEL_NOT_FOUND"
    assert "Foo" in exc.message


def test_admin_auth_not_configured_has_code():
    exc = AdminAuthNotConfigured()
    assert exc.code == "ADMIN_AUTH_NOT_CONFIGURED"


def test_configuration_order_error_has_code():
    exc = ConfigurationOrderError()
    assert exc.code == "CONFIGURATION_ORDER_ERROR"


def test_wrong_surface_default_message():
    exc = WrongSurface()
    assert "surface" in exc.message.lower()
