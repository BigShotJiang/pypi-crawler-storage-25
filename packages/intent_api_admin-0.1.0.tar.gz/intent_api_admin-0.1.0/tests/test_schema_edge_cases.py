"""
Schema introspection edge cases:
- Self-referential FK (User.parent_id -> users.id)
- Many-to-many via association table (User <-> Tag)
- Nullable FK (BlogPost.editor_id -> users.id, nullable=True)
- Enum column (User.status)
- Bare Column with no SQL type (defaults to NullType -> "unknown")
- Non-`id` primary key (Workspace.uuid as primary key)
"""

from __future__ import annotations

import sqlalchemy as sa
from sqlalchemy.orm import DeclarativeBase, relationship

from intent_api_admin.auto_admin.introspector import introspect_model


class Base(DeclarativeBase):
    pass


# ── Many-to-many association table ────────────────────────────────────────────


user_tags = sa.Table(
    "user_tags",
    Base.metadata,
    sa.Column("user_id", sa.String(36), sa.ForeignKey("users_edge.id"), primary_key=True),
    sa.Column("tag_id", sa.Integer, sa.ForeignKey("tags_edge.id"), primary_key=True),
)


class Tag(Base):
    __tablename__ = "tags_edge"
    id = sa.Column(sa.Integer, primary_key=True)
    label = sa.Column(sa.String(50), nullable=False)


class UserEdge(Base):
    __tablename__ = "users_edge"
    id = sa.Column(sa.String(36), primary_key=True)
    email = sa.Column(sa.String(255), nullable=False, unique=True, index=True)
    parent_id = sa.Column(sa.String(36), sa.ForeignKey("users_edge.id"), nullable=True)
    status = sa.Column(
        sa.Enum("active", "inactive", "pending", name="user_status_edge"),
        nullable=True,
    )
    data = sa.Column("data")  # bare column, no type → NullType
    parent = relationship("UserEdge", remote_side=[id], foreign_keys=[parent_id])
    tags = relationship("Tag", secondary=user_tags)


class BlogPostEdge(Base):
    __tablename__ = "blog_posts_edge"
    id = sa.Column(sa.Integer, primary_key=True)
    title = sa.Column(sa.String(255), nullable=False)
    editor_id = sa.Column(
        sa.String(36), sa.ForeignKey("users_edge.id"), nullable=True
    )


class WorkspaceEdge(Base):
    __tablename__ = "workspaces_edge"
    uuid = sa.Column(sa.String(36), primary_key=True)
    name = sa.Column(sa.String(255), nullable=False)


# ── Tests ─────────────────────────────────────────────────────────────────────


def test_self_referential_fk_field():
    schema = introspect_model(UserEdge)
    parent = schema.fields.get("parent_id")
    assert parent is not None
    assert parent.type == "foreign_key"
    assert "users_edge.id" in (parent.foreign_key_target or "")


def test_self_referential_fk_relationship():
    schema = introspect_model(UserEdge)
    assert "parent" in schema.relationships
    rel = schema.relationships["parent"]
    assert rel.target_model == "UserEdge"
    assert rel.cardinality == "one"


def test_many_to_many_relationship():
    schema = introspect_model(UserEdge)
    assert "tags" in schema.relationships
    rel = schema.relationships["tags"]
    assert rel.cardinality == "many"
    assert rel.target_model == "Tag"


def test_nullable_fk_field():
    schema = introspect_model(BlogPostEdge)
    field = schema.fields.get("editor_id")
    assert field is not None
    assert field.type == "foreign_key"
    assert field.nullable is True


def test_enum_column_field():
    schema = introspect_model(UserEdge)
    status = schema.fields.get("status")
    assert status is not None
    assert status.type == "enum"
    assert status.enum_values is not None
    assert set(status.enum_values) == {"active", "inactive", "pending"}


def test_bare_column_unknown_type():
    schema = introspect_model(UserEdge)
    data = schema.fields.get("data")
    assert data is not None
    assert data.type == "unknown"


def test_non_id_primary_key():
    schema = introspect_model(WorkspaceEdge)
    pk_field = schema.fields.get("uuid")
    assert pk_field is not None
    assert pk_field.primary_key is True
    assert pk_field.read_only is True
    # default_sort should fall back to '<pk> desc' (no created_at)
    assert "uuid" in schema.default_sort
