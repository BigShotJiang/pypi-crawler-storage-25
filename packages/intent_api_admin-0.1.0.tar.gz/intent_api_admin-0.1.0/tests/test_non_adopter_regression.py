"""
Tests that prove intent-api-admin does NOT alter behavior for non-adopters.

A "non-adopter" is a project that uses the standard `intent_api.IntentRouter`
without `configure_admin_auth()`, without `auto_admin()`, and without
`impersonation_aware_auth()`. The library code must be entirely out of
the call path for those projects.
"""

from __future__ import annotations

import jwt
import pytest
import sqlalchemy as sa
from fastapi import FastAPI, HTTPException
from httpx import ASGITransport, AsyncClient
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from intent_api import IntentRouter
from intent_api.service import IntentService
from intent_api_admin.config import _reset_config


class _Base(DeclarativeBase):
    pass


class _Item(_Base):
    __tablename__ = "non_adopter_items"
    id = sa.Column(sa.Integer, primary_key=True)
    name = sa.Column(sa.String, nullable=False)


class _ItemService(IntentService):
    async def list(self, *, db, user, context, skip=0, limit=10):
        rows = db.execute(sa.select(_Item)).scalars().all()
        return [{"id": r.id, "name": r.name} for r in rows]


@pytest.fixture
def fake_clerk_app():
    """Build a baseline FastAPI app that uses ONLY intent_api (no admin lib)."""
    _reset_config()  # ensure no global admin config leaks in

    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    _Base.metadata.create_all(engine)
    SessionFactory = sessionmaker(bind=engine, autocommit=False, autoflush=False)

    with SessionFactory() as s:
        s.add(_Item(id=1, name="alpha"))
        s.add(_Item(id=2, name="beta"))
        s.commit()

    async def fake_clerk_get_user(*, credentials, context, db):
        # A trivial Clerk-shaped auth that ONLY accepts a magic token.
        if credentials.credentials == "valid-clerk-jwt":
            return {"id": "clerk_user_001", "email": "u@u.com"}
        raise HTTPException(status_code=401, detail="bad clerk token")

    def get_db():
        db = SessionFactory()
        try:
            yield db
        finally:
            db.close()

    router = IntentRouter()
    router.register("Item", _ItemService())

    app = FastAPI()
    app.include_router(router.build(get_user=fake_clerk_get_user, get_db=get_db))
    return app


@pytest.mark.asyncio
async def test_baseline_request_works_without_lib(fake_clerk_app):
    """A normal Clerk-style auth + standard intent dispatch works untouched."""
    async with AsyncClient(transport=ASGITransport(app=fake_clerk_app), base_url="http://test") as client:
        resp = await client.post(
            "/api/intent",
            json={"model": "Item", "action": "list"},
            headers={"Authorization": "Bearer valid-clerk-jwt"},
        )
    assert resp.status_code == 200
    assert resp.json() == [{"id": 1, "name": "alpha"}, {"id": 2, "name": "beta"}]


@pytest.mark.asyncio
async def test_impersonation_shaped_jwt_rejected_by_fake_clerk(fake_clerk_app):
    """An impersonation-shaped JWT is rejected by the fake Clerk auth (its own logic). The library code is NOT in the path."""
    # Construct a JWT whose body claims look like an impersonation token,
    # but signed with HS256 so it isn't a valid console JWT either way.
    bogus_token = jwt.encode(
        {
            "iss": "https://console.test",
            "aud": "test",
            "sub": "admin_001",
            "mode": "impersonation",
            "target_user_id": "user_001",
        },
        "secret",
        algorithm="HS256",
    )
    async with AsyncClient(transport=ASGITransport(app=fake_clerk_app), base_url="http://test") as client:
        resp = await client.post(
            "/api/intent",
            json={"model": "Item", "action": "list"},
            headers={"Authorization": f"Bearer {bogus_token}"},
        )
    # The fake Clerk auth doesn't recognize this token → 401.
    assert resp.status_code == 401
    # No admin error codes leak in.
    text = resp.text
    assert "WRONG_SURFACE" not in text
    assert "IMPERSONATION_WRITE_DENIED" not in text
