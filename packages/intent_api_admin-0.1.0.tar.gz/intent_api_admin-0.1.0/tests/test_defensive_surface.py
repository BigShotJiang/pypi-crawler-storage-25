"""
Defensive surface tests: precondition machinery should not crash when fed
unexpected context shapes (e.g. base IntentContext with no surface) and
should not spuriously trigger impersonation-write-denial when surface is
not "impersonation".
"""

from __future__ import annotations

import pytest
from fastapi import HTTPException

from intent_api.schemas import AdminIntentContext, IntentContext
from intent_api_admin.auto_admin.preconditions import check_preconditions


class _UserWithAdmin:
    """A user whose _admin_context carries the role; the IntentContext has no surface."""
    def __init__(self, admin_ctx):
        self._admin_context = admin_ctx


def test_base_intent_context_with_no_surface_does_not_crash():
    """A base IntentContext (NOT AdminIntentContext) with surface=None must not crash."""
    base_ctx = IntentContext(type="admin")
    admin_ctx = AdminIntentContext(
        type="admin",
        surface="admin-machine",
        acting_admin_id="admin_001",
        intent_admin_role="admin",
    )
    user = _UserWithAdmin(admin_ctx)

    # No exception should be raised
    check_preconditions(
        action="list",
        command=None,
        user=user,
        context=base_ctx,
        required_role="support",
        is_read_only_action=True,
        redacted_fields=set(),
        deny_edit_fields=set(),
        deny_delete=False,
        payload=None,
    )


def test_admin_context_with_surface_none_no_impersonation_write_denial():
    """user._admin_context.surface=None and write action → no IMPERSONATION_WRITE_DENIED.

    Impersonation-write-denial should only fire when the admin context
    has an impersonation_session_id. Bare AdminIntentContext with surface=None
    is just admin (or unknown) — it MUST NOT trigger denial.
    """
    admin_ctx = AdminIntentContext(
        type="admin",
        surface=None,  # missing surface — defensive case
        acting_admin_id="admin_001",
        intent_admin_role="admin",
    )
    user = _UserWithAdmin(admin_ctx)

    # No exception should be raised
    check_preconditions(
        action="update",
        command=None,
        user=user,
        context=None,
        required_role="support",
        is_read_only_action=False,
        redacted_fields=set(),
        deny_edit_fields=set(),
        deny_delete=False,
        payload={"name": "x"},
    )


def test_no_admin_context_anywhere_yields_insufficient_role():
    """If neither context nor user._admin_context has a role, INSUFFICIENT_ROLE fires (not AttributeError, not 500)."""
    class _Bare:
        pass

    bare_user = _Bare()
    base_ctx = IntentContext(type="admin")

    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="list",
            command=None,
            user=bare_user,
            context=base_ctx,
            required_role="support",
            is_read_only_action=True,
            redacted_fields=set(),
            deny_edit_fields=set(),
            deny_delete=False,
            payload=None,
        )
    assert exc_info.value.status_code == 403
    assert exc_info.value.detail["code"] == "INSUFFICIENT_ROLE"


def test_admin_context_with_session_but_no_surface_still_denies_write():
    """If an admin context has impersonation_session_id but surface is missing, write denial still fires."""
    admin_ctx = AdminIntentContext(
        type="user",
        surface=None,
        acting_admin_id="admin_001",
        intent_admin_role="admin",
        impersonation_session_id="sess_001",
        allow_writes=False,
    )
    user = _UserWithAdmin(admin_ctx)

    with pytest.raises(HTTPException) as exc_info:
        check_preconditions(
            action="update",
            command=None,
            user=user,
            context=None,
            required_role="support",
            is_read_only_action=False,
            redacted_fields=set(),
            deny_edit_fields=set(),
            deny_delete=False,
            payload={"x": 1},
        )
    assert exc_info.value.status_code == 403
    assert exc_info.value.detail["code"] == "IMPERSONATION_WRITE_DENIED"
