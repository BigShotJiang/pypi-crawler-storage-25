"""
intent-api-admin v0.1.0

Admin-machine surface, impersonation, and auto-admin for Intent API products.

Quick start:
    from intent_api_admin import configure_admin_auth, auto_admin
    from intent_api_admin.auth import admin_machine_auth, impersonation_aware_auth

    configure_admin_auth(
        issuer="https://console.example.com",
        audience="my-product",
        impersonation_user_query=get_user_by_id,
        base=Base,
    )

    auto_admin(router, expose=["User", "Team"])

    app.include_router(router.build_admin_machine(
        get_user=admin_machine_auth(),
        get_db=get_db,
    ))
"""

from intent_api_admin.auth.admin_machine import admin_machine_auth
from intent_api_admin.auth.impersonation import ImpersonatedUser, impersonation_aware_auth
from intent_api_admin.auto_admin import auto_admin
from intent_api_admin.config import configure_admin_auth, get_config
from intent_api_admin.decorators import admin_action, custom_action
from intent_api_admin.errors import (
    AdminAuthNotConfigured,
    ConfigurationOrderError,
    DeleteDenied,
    FieldReadOnly,
    FieldRedacted,
    ImpersonationWriteDenied,
    InsufficientRole,
    ModelNotFound,
    UnsupportedFilterOp,
    WrongSurface,
)
from intent_api_admin.role import check_role

__version__ = "0.1.0"

__all__ = [
    # Auth
    "admin_machine_auth",
    "ImpersonatedUser",
    "impersonation_aware_auth",
    # Auto-admin
    "auto_admin",
    # Config
    "configure_admin_auth",
    "get_config",
    # Decorators
    "custom_action",
    "admin_action",
    # Errors
    "AdminAuthNotConfigured",
    "ConfigurationOrderError",
    "DeleteDenied",
    "FieldReadOnly",
    "FieldRedacted",
    "ImpersonationWriteDenied",
    "InsufficientRole",
    "ModelNotFound",
    "UnsupportedFilterOp",
    "WrongSurface",
    # Role
    "check_role",
]
