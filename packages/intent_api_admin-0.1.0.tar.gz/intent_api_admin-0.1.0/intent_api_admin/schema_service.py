"""
Schema service for the admin-machine surface.

Exposes a GET /api/admin-machine-schema endpoint that returns a SchemaDocument
describing all registered admin resources and actions. The document includes a
sha256 version fingerprint.

Usage:
    from intent_api_admin.schema_service import build_schema_router

    app.include_router(build_schema_router(router))
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from intent_api_admin.auth.admin_machine import admin_machine_auth
from intent_api_admin.auto_admin.schemas import ActionSchema, SchemaDocument

logger = logging.getLogger("intent_api_admin.schema_service")


def build_schema_router(
    router,
    *,
    get_db: Any,
    path: str = "/admin-machine-schema",
    tags: Optional[list[str]] = None,
) -> APIRouter:
    """
    Build a FastAPI router exposing a GET endpoint that returns the SchemaDocument.

    The schema is computed from the admin-machine service registry attached to
    `router`. Requires a valid admin-machine bearer token (same auth as admin
    machine intents).

    Args:
        router: IntentRouter with registered admin-machine services.
        get_db: FastAPI dependency yielding a DB session.
        path: Endpoint path (appended to router prefix). Default: "/admin-machine-schema".
        tags: OpenAPI tags.

    Returns:
        FastAPI APIRouter with a GET endpoint.
    """
    api_router = APIRouter(tags=tags or ["Intent API (Admin Machine)"])
    security = HTTPBearer()
    get_user = admin_machine_auth()
    endpoint = f"{router._prefix}{path}"

    @api_router.get(endpoint, response_model=SchemaDocument)
    async def get_schema(
        db=Depends(get_db),
        credentials: HTTPAuthorizationCredentials = Depends(security),
    ) -> SchemaDocument:
        # Verify auth (raises 401/403 on failure)
        user = await get_user(credentials=credentials, context=None, db=db)

        return _build_schema_document(router)

    return api_router


def _build_schema_document(router) -> SchemaDocument:
    """Introspect the admin-machine registry and build a SchemaDocument."""
    from intent_api_admin.auto_admin.schemas import ResourceSchema

    resources: dict[str, ResourceSchema] = {}
    actions: list[ActionSchema] = []

    admin_registry = router._admin_machine_registry
    for model_name in admin_registry.models:
        service = admin_registry.get(model_name)
        if service is None:
            continue

        # Check if it's an auto-admin service with a resource schema
        resource_schema = getattr(service, "_auto_admin_resource_schema", None)
        if resource_schema is not None:
            resources[model_name] = resource_schema

        # Collect custom actions (admin_action decorated)
        cls = type(service)
        for attr_name, method in cls.__dict__.items():
            if not callable(method):
                continue
            if not getattr(method, "_is_admin_action", False):
                continue
            actions.append(ActionSchema(
                model_name=model_name,
                action_name=getattr(method, "_command_name", attr_name),
                display=getattr(method, "_command_display", None),
                description=getattr(method, "_admin_description", None),
                min_role=getattr(method, "_admin_min_role", "support"),
                payload_schema=None,
                read_only=getattr(method, "_admin_read_only", False),
            ))

    # Compute version as sha256 of canonical JSON (resources + actions, without version)
    doc_body = {
        "resources": {k: v.model_dump() for k, v in resources.items()},
        "actions": [a.model_dump() for a in actions],
    }
    canonical = json.dumps(doc_body, sort_keys=True, default=str)
    version = hashlib.sha256(canonical.encode()).hexdigest()

    from intent_api_admin.config import get_config
    config = get_config()

    return SchemaDocument(
        version=version,
        audience=config.audience,
        resources=resources,
        actions=actions,
    )
