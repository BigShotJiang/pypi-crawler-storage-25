"""
Pydantic models for auto-admin schema documents.

These describe the shape of resources and actions as understood by the admin console.
"""

from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel


class FieldSchema(BaseModel):
    name: str
    type: Literal[
        "int", "float", "str", "bool", "datetime", "date", "uuid",
        "json", "enum", "foreign_key", "unknown",
    ]
    nullable: bool
    primary_key: bool
    read_only: bool
    enum_values: Optional[list[str]] = None
    max_length: Optional[int] = None
    foreign_key_target: Optional[str] = None


class RelationshipSchema(BaseModel):
    name: str
    target_model: str
    cardinality: Literal["one", "many"]
    via: Optional[str] = None
    back_populates: Optional[str] = None


class ResourceSchema(BaseModel):
    model_name: str
    display_name: str
    display_prefix: str
    fields: dict[str, FieldSchema]
    relationships: dict[str, RelationshipSchema]
    list_fields: list[str]
    search_fields: list[str]
    default_sort: str
    deny_delete: bool
    deny_edit_fields: list[str]
    redacted_fields: list[str]


class ActionSchema(BaseModel):
    model_name: str
    action_name: str
    display: Optional[str] = None
    description: Optional[str] = None
    min_role: Literal["owner", "admin", "support"]
    payload_schema: Optional[dict[str, Any]] = None
    read_only: bool


class SchemaDocument(BaseModel):
    version: str  # sha256 of canonical JSON (excluding version field itself)
    audience: str
    resources: dict[str, ResourceSchema]
    actions: list[ActionSchema]
