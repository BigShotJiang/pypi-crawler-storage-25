"""
Filter and sort application for auto-admin list queries.

Translates declarative filter/sort specifications into SQLAlchemy query modifications.
"""

from __future__ import annotations

import logging
from typing import Any

import sqlalchemy as sa
from fastapi import HTTPException

from intent_api_admin.errors import UnsupportedFilterOp

logger = logging.getLogger("intent_api_admin.filters")

SUPPORTED_OPS = frozenset({
    "eq", "ne", "gt", "gte", "lt", "lte",
    "in", "not_in", "contains", "is_null", "is_not_null",
})


def apply_filters(query, model_class, filters: list[dict]):
    """
    Apply a list of filter specifications to a SQLAlchemy select query.

    Each filter is a dict with keys:
        field: str — column name
        op: str — one of SUPPORTED_OPS
        value: Any — comparison value (not required for is_null/is_not_null)

    Raises UnsupportedFilterOp (HTTP 422) for unknown ops.
    Raises HTTPException(400) for unknown fields.
    """
    for f in filters:
        field_name = f.get("field") or ""
        op = f.get("op") or ""
        value = f.get("value")

        if op not in SUPPORTED_OPS:
            raise UnsupportedFilterOp(op).to_http_exception()

        col = getattr(model_class, field_name, None)
        if col is None:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown filter field '{field_name}'.",
            )

        if op == "eq":
            query = query.where(col == value)
        elif op == "ne":
            query = query.where(col != value)
        elif op == "gt":
            query = query.where(col > value)
        elif op == "gte":
            query = query.where(col >= value)
        elif op == "lt":
            query = query.where(col < value)
        elif op == "lte":
            query = query.where(col <= value)
        elif op == "in":
            query = query.where(col.in_(value))
        elif op == "not_in":
            query = query.where(col.notin_(value))
        elif op == "contains":
            query = query.where(col.ilike(f"%{value}%"))
        elif op == "is_null":
            query = query.where(col.is_(None))
        elif op == "is_not_null":
            query = query.where(col.isnot(None))

    return query


def apply_sort(query, model_class, sort: list[dict]):
    """
    Apply a list of sort specifications to a SQLAlchemy select query.

    Each sort item is a dict with keys:
        field: str — column name
        direction: str — "asc" or "desc" (default: "asc")
    """
    for s in sort:
        field_name = s.get("field") or ""
        direction = s.get("direction", "asc").lower()

        col = getattr(model_class, field_name, None)
        if col is None:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown sort field '{field_name}'.",
            )

        if direction == "desc":
            query = query.order_by(col.desc())
        else:
            query = query.order_by(col.asc())

    return query
