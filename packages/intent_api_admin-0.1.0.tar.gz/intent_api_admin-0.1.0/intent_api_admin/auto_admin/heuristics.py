"""
Auto-admin heuristics for field classification.

Determines which fields to auto-redact, which to show in list views,
which are searchable, and the default sort order.
"""

from __future__ import annotations

AUTO_REDACT_PATTERNS = ["password", "secret", "api_key", "token"]
AUTO_REDACT_SUFFIXES = ["_hash", "_digest"]

# Field names that are preferred in list views (in priority order)
PREFERRED_LIST_FIELDS = ["name", "email", "title", "slug", "status", "created_at"]
MAX_LIST_FIELDS = 6


def should_auto_redact(col_name: str) -> bool:
    """
    Return True if the column name matches auto-redact heuristics.

    Auto-redacted if:
    - Starts with "_" (private/internal)
    - Starts with any of AUTO_REDACT_PATTERNS
    - Ends with any of AUTO_REDACT_SUFFIXES
    """
    name = col_name.lower()
    if name.startswith("_"):
        return True
    for pat in AUTO_REDACT_PATTERNS:
        if name.startswith(pat):
            return True
    for suf in AUTO_REDACT_SUFFIXES:
        if name.endswith(suf):
            return True
    return False


def compute_default_list_fields(
    columns: list,
    redacted_fields: set[str],
) -> list[str]:
    """
    Compute the default list of fields to show in a list view.

    Algorithm:
    1. Always include primary key column(s).
    2. Add preferred named fields (name, email, title, slug, status, created_at)
       if present and not redacted.
    3. Fill remaining slots (up to MAX_LIST_FIELDS) with the first non-text,
       non-redacted columns.
    """
    col_names = [c.key for c in columns]
    col_map = {c.key: c for c in columns}

    result: list[str] = []

    # 1. Primary keys first
    pk_cols = [c.key for c in columns if c.primary_key]
    for pk in pk_cols:
        if pk not in redacted_fields:
            result.append(pk)

    # 2. Preferred named fields
    for preferred in PREFERRED_LIST_FIELDS:
        if preferred in col_names and preferred not in redacted_fields and preferred not in result:
            result.append(preferred)
        if len(result) >= MAX_LIST_FIELDS:
            break

    # 3. Fill remaining slots with non-text, non-redacted columns
    if len(result) < MAX_LIST_FIELDS:
        import sqlalchemy as sa
        text_types = (sa.String, sa.Text, sa.UnicodeText, sa.Unicode)
        for col in columns:
            if len(result) >= MAX_LIST_FIELDS:
                break
            if col.key in result or col.key in redacted_fields:
                continue
            col_type = type(col.type)
            if issubclass(col_type, text_types):
                continue
            result.append(col.key)

    return result[:MAX_LIST_FIELDS]


def compute_search_fields(columns: list) -> list[str]:
    """
    Return string columns that are indexed and have a max length <= 255.
    These are suitable for LIKE/contains searches.
    """
    import sqlalchemy as sa
    result = []
    for col in columns:
        if not isinstance(col.type, (sa.String, sa.Text, sa.UnicodeText, sa.Unicode)):
            continue
        # Check max length
        max_len = getattr(col.type, "length", None)
        if max_len is not None and max_len > 255:
            continue
        # Check if the column has an index
        if getattr(col, "index", False) or getattr(col, "unique", False):
            result.append(col.key)
    return result


def compute_default_sort(columns: list) -> str:
    """
    Return the default sort expression.

    Prefers 'created_at desc' if that column exists, otherwise
    returns '<primary_key> desc'.
    """
    col_names = {c.key for c in columns}
    if "created_at" in col_names:
        return "created_at desc"
    pk_cols = [c.key for c in columns if c.primary_key]
    if pk_cols:
        return f"{pk_cols[0]} desc"
    return "id desc"
