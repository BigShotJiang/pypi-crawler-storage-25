"""
Precondition checks for auto-admin operations.

Enforces role requirements, impersonation write-denial, field-level
redaction, read-only field protection, and delete denial.

All violations raise FastAPI HTTPException (not the custom error classes
directly) so they propagate correctly through the service layer.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from intent_api.schemas import AdminIntentContext

from intent_api_admin.errors import (
    DeleteDenied,
    FieldReadOnly,
    FieldRedacted,
    ImpersonationWriteDenied,
    InsufficientRole,
)
from intent_api_admin.role import check_role

logger = logging.getLogger("intent_api_admin.preconditions")

WRITE_ACTIONS = frozenset({"create", "update", "delete"})


def get_admin_context(user: Any, context: Any) -> Optional[AdminIntentContext]:
    """
    Get admin context from context (if AdminIntentContext) or user._admin_context.

    Checks context first, then falls back to user._admin_context (set by
    ImpersonatedUser for impersonation sessions).
    """
    if isinstance(context, AdminIntentContext):
        return context
    return getattr(user, "_admin_context", None)


def check_preconditions(
    action: str,
    command: str | None,
    user: Any,
    context: Any,
    *,
    required_role: str,
    is_read_only_action: bool,
    redacted_fields: set,
    deny_edit_fields: set,
    deny_delete: bool,
    payload: dict | None,
) -> None:
    """
    Run precondition checks for an admin action. Raises HTTPException on failure.

    Checks run in this order:
    1. Role check — INSUFFICIENT_ROLE if role rank too low.
    2. Impersonation write-denial — IMPERSONATION_WRITE_DENIED if write on read-only session.
    3. Field-level checks — FIELD_REDACTED, FIELD_READ_ONLY, DELETE_DENIED.

    Args:
        action: Intent action ("list", "read", "update", "delete", "custom").
        command: Custom command name (None for non-custom actions).
        user: The acting user (may be ImpersonatedUser).
        context: The intent context (may be AdminIntentContext).
        required_role: Minimum role string required for this action.
        is_read_only_action: If True, the action is allowed during read-only impersonation.
        redacted_fields: Set of field names that are redacted.
        deny_edit_fields: Set of field names that are read-only.
        deny_delete: If True, delete is forbidden for this model.
        payload: The request payload dict (may be None).
    """
    admin_ctx = get_admin_context(user, context)

    # 1. Role check
    actual_role = getattr(admin_ctx, "intent_admin_role", None) if admin_ctx else None
    if not check_role(required_role, actual_role):
        raise InsufficientRole(required_role, actual_role).to_http_exception()

    # 2. Impersonation write-denial
    # A "write" for the purposes of impersonation gating is any action that
    # is not flagged as read-only. CRUD writes (create/update/delete) are
    # always treated as writes; "custom" actions are writes unless the
    # caller passed is_read_only_action=True (which mirrors
    # `@custom_action(read_only=True)` metadata).
    is_write_action = (action in WRITE_ACTIONS) or (
        action == "custom" and not is_read_only_action
    )
    if admin_ctx is not None and getattr(admin_ctx, "impersonation_session_id", None):
        # This is an impersonation session
        allow_writes = getattr(admin_ctx, "allow_writes", False)
        if is_write_action and not is_read_only_action and not allow_writes:
            raise ImpersonationWriteDenied(action).to_http_exception()

    # 3. Field-level checks
    # Delete denial
    if action == "delete" and deny_delete:
        # Get model name from context or service
        raise DeleteDenied("this model").to_http_exception()

    # Payload field checks (for update/create)
    if payload and action in ("update", "create"):
        for field_name in payload.keys():
            if field_name in redacted_fields:
                raise FieldRedacted(field_name).to_http_exception()
            if field_name in deny_edit_fields:
                raise FieldReadOnly(field_name).to_http_exception()
