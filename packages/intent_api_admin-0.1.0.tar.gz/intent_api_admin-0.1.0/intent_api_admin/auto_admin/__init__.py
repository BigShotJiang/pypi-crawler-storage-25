"""
auto_admin — Automatic admin service generation from SQLAlchemy models.

Usage:
    from intent_api_admin.auto_admin import auto_admin

    auto_admin(router, expose=["User", "Team", "Order"])

This function:
1. Looks up each model in the SQLAlchemy Base registry.
2. Introspects the model to produce a ResourceSchema.
3. Generates an IntentService subclass with list/read/update/delete handlers.
4. Registers it on the router's admin-machine registry.
5. Patches router.build_admin_machine to support payload-based list filters.
"""

from __future__ import annotations

import contextvars
import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from intent_api.router import _build_admin_machine_context, _dispatch
from intent_api.schemas import IntentRequest
from intent_api.surfaces import SURFACE_ADMIN_MACHINE

from intent_api_admin.auto_admin.introspector import introspect_model
from intent_api_admin.auto_admin.service_factory import make_admin_service
from intent_api_admin.audit import emit_audit_event
from intent_api_admin.config import get_config

logger = logging.getLogger("intent_api_admin.auto_admin")

# ContextVar used to pass intent.payload to admin list handlers.
# Set by the patched build_admin_machine handler before dispatch.
_admin_list_payload_var: contextvars.ContextVar[Optional[dict]] = contextvars.ContextVar(
    "_admin_list_payload", default=None
)


def get_admin_list_payload() -> Optional[dict]:
    """Return the current request's intent payload for admin list handlers."""
    return _admin_list_payload_var.get()


def auto_admin(
    router,
    expose: list[str],
    *,
    deny_delete: list[str] | None = None,
    deny_edit_fields: dict[str, list[str]] | None = None,
    redact_fields: dict[str, list[str]] | None = None,
    overrides: dict[str, dict] | None = None,
) -> None:
    """
    Register auto-generated admin services for the given model names.

    Args:
        router: An IntentRouter instance.
        expose: List of SQLAlchemy model class names to expose.
        deny_delete: Model names for which delete is forbidden.
        deny_edit_fields: {model_name: [field_name, ...]} for read-only fields.
        redact_fields: {model_name: [field_name, ...]} for explicitly redacted fields.
        overrides: Per-model ResourceSchema overrides dict.

    Side effect: patches router.build_admin_machine with a payload-aware version
    that stores intent.payload in a ContextVar before calling the standard dispatch.
    """
    config = get_config()
    config._auto_admin_called = True

    if config.base is None:
        logger.warning(
            "auto_admin called but no SQLAlchemy Base configured. "
            "Pass base=Base to configure_admin_auth()."
        )
        _patch_router(router)
        return

    deny_delete_set = set(deny_delete or [])
    deny_edit_fields_map = deny_edit_fields or {}
    redact_fields_map = redact_fields or {}
    overrides_map = overrides or {}

    for model_name in expose:
        model_class = _find_model(config.base, model_name)
        if model_class is None:
            logger.warning(
                "auto_admin: model '%s' not found in Base registry — skipping.",
                model_name,
            )
            continue

        resource_schema = introspect_model(
            model_class,
            redact=redact_fields_map.get(model_name),
            deny_edit_fields=deny_edit_fields_map.get(model_name),
            deny_delete=model_name in deny_delete_set,
            overrides=overrides_map.get(model_name),
        )

        admin_model_name = f"Admin{model_name}"
        service_class = make_admin_service(
            model_name=admin_model_name,
            model_class=model_class,
            resource_schema=resource_schema,
            deny_delete=model_name in deny_delete_set,
            deny_edit_fields=set(deny_edit_fields_map.get(model_name, [])),
            redacted_fields=set(resource_schema.redacted_fields),
            audit_fn=emit_audit_event,
        )

        router.register_admin_machine(admin_model_name, service_class())
        logger.info("auto_admin: registered '%s' on admin-machine surface.", admin_model_name)

    # Discovery (B52): walk the standard registry and relocate any
    # @custom_action(admin_only=True) methods to the admin-machine
    # registry. This ensures admin-only commands are unreachable on
    # standard / admin / MCP / machine surfaces.
    _discover_admin_only_commands(router)

    _patch_router(router)


def _discover_admin_only_commands(router) -> None:
    """
    Walk every service registered on the *standard* registry and
    relocate `@custom_action(admin_only=True)` commands onto the
    admin-machine registry.

    Mechanism:
      - Inspect each service's class `_registered_commands` mapping.
      - For each command whose handler method has
        `_intent_admin_only = True`, pop it from that mapping (so
        intent_api.router._resolve_service_handler will no longer
        find it on the standard surface).
      - Register or extend an admin-only "shim" service on
        router._admin_machine_registry. The shim exposes the same
        underlying handler, bound to the original service instance,
        but only via the admin-machine surface.

    A shim service per source-model is created at most once across
    multiple calls; subsequent admin-only commands on the same model
    are appended to the existing shim's `_registered_commands`.
    """
    standard_registry = router._registry
    admin_machine_registry = router._admin_machine_registry

    for model_name in list(standard_registry.models):
        service = standard_registry.get(model_name)
        if service is None:
            continue
        cls = service.__class__
        commands = getattr(cls, "_registered_commands", None)
        if not commands:
            continue

        admin_only_cmds: dict = {}
        for cmd_name, info in list(commands.items()):
            handler_name = info.get("handler")
            if not handler_name:
                continue
            handler = getattr(cls, handler_name, None)
            if handler is None:
                continue
            if getattr(handler, "_intent_admin_only", False):
                admin_only_cmds[cmd_name] = info

        if not admin_only_cmds:
            continue

        # Remove admin-only commands from the source service's mapping
        # so they cannot be dispatched on standard / admin / machine /
        # MCP surfaces. We mutate a per-instance dict (not the class
        # attribute) to avoid affecting other instances of the same
        # class — the dispatcher resolves via service.__class__, so we
        # also need to override the class mapping on a per-service shim
        # basis. The simplest safe approach: replace the class
        # `_registered_commands` if and only if this is the only service
        # of that class registered on the standard registry. In tests
        # and typical apps there is exactly one instance per class, so
        # this is safe.
        new_class_commands = {
            k: v for k, v in commands.items() if k not in admin_only_cmds
        }
        cls._registered_commands = new_class_commands

        # Build (or extend) an admin-machine shim service that delegates
        # to the original service instance.
        admin_shim_name = model_name
        existing_shim = admin_machine_registry.get(admin_shim_name)
        if existing_shim is not None:
            shim_cls = existing_shim.__class__
            # Append admin-only commands to the existing shim's class mapping
            shim_cls._registered_commands = {
                **getattr(shim_cls, "_registered_commands", {}),
                **admin_only_cmds,
            }
            shim_cls._admin_only_source_service = service
            # Make sure the shim has bound versions of the new handlers.
            for cmd_name, info in admin_only_cmds.items():
                handler_name = info["handler"]
                handler = getattr(cls, handler_name)
                setattr(shim_cls, handler_name, handler)
            continue

        # Create a fresh shim class for this source service.
        shim_class = _make_admin_only_shim(
            model_name=admin_shim_name,
            source_service=service,
            admin_only_cmds=admin_only_cmds,
        )
        admin_machine_registry.register(
            admin_shim_name, shim_class(), expose_mcp=False, expose_chat=False
        )
        logger.info(
            "auto_admin: relocated %d admin-only command(s) from '%s' to admin-machine surface.",
            len(admin_only_cmds),
            model_name,
        )


def _make_admin_only_shim(
    *, model_name: str, source_service, admin_only_cmds: dict
):
    """
    Create an IntentService shim class that exposes only the given
    admin-only custom commands on the admin-machine registry.

    The shim's handler methods are taken directly from the source
    service's class (so they keep their @custom_action metadata,
    schema, etc.), but `self` at dispatch time is the *shim instance*,
    which is fine because the handlers don't depend on instance state.
    """
    from intent_api.service import IntentService

    src_cls = source_service.__class__

    attrs: dict = {
        "_admin_only_source_service": source_service,
        "_registered_commands": dict(admin_only_cmds),
        "__display_prefix__": f"Admin {model_name}",
    }
    for cmd_name, info in admin_only_cmds.items():
        handler_name = info["handler"]
        handler = getattr(src_cls, handler_name)
        attrs[handler_name] = handler

    shim_cls = type(f"AdminOnly{model_name}Shim", (IntentService,), attrs)
    return shim_cls


def _find_model(base: Any, name: str):
    """Find a SQLAlchemy model class by name in the Base registry."""
    for mapper in base.registry.mappers:
        if mapper.class_.__name__ == name:
            return mapper.class_
    return None


def _patch_router(router) -> None:
    """
    Patch router.build_admin_machine to inject intent.payload into a ContextVar
    before calling the standard dispatch. This allows auto-generated list handlers
    to access filters/sort from the payload.

    This patch is idempotent — calling it multiple times is safe.
    """
    if getattr(router, "_admin_list_payload_patched", False):
        return

    original_build = router.build_admin_machine

    def patched_build_admin_machine(
        *,
        get_user,
        get_db,
        path: str = "/admin-machine-intent",
        tags=None,
    ):
        _api_router = APIRouter(tags=tags or ["Intent API (Admin Machine)"])
        _admin_registry = router._admin_machine_registry
        _runtime = router._runtime
        _security = HTTPBearer()
        _endpoint = f"{router._prefix}{path}"
        _debug = router._debug
        _debug_payload = router._debug_payload

        try:
            from intent_api.router import _log_intent as _log
        except ImportError:
            _log = None

        @_api_router.post(_endpoint)
        async def handle_admin_machine_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(_security),
        ):
            # Store the payload in a ContextVar BEFORE dispatch so auto-generated
            # list handlers can access filters/sort from the payload.
            token = _admin_list_payload_var.set(intent.payload)
            try:
                user = await get_user(credentials=credentials, context=intent.context, db=db)

                if _debug and _log:
                    _log(intent, user, "AdminMachine (patched)", _debug_payload)

                service = _admin_registry.get(intent.model)
                if not service:
                    raise HTTPException(
                        status_code=404,
                        detail=f"Model '{intent.model}' not registered.",
                    )

                context = _build_admin_machine_context(user)

                return await _dispatch(
                    service, intent, db, user, context,
                    runtime=_runtime,
                    model_name=intent.model,
                    surface=SURFACE_ADMIN_MACHINE,
                )
            finally:
                _admin_list_payload_var.reset(token)

        return _api_router

    router.build_admin_machine = patched_build_admin_machine
    router._admin_list_payload_patched = True
