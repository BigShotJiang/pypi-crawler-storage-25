"""
Dynamic IntentService subclass factory for auto-admin.

Generates IntentService subclasses at runtime, one per model.
Each generated service implements list, read, update, and delete
(but not create — admin doesn't create records).

Each handler is responsible for:
- Running `check_preconditions(...)` (which may raise HTTPException for
  denied requests).
- Wrapping the dispatch in `time.perf_counter()` to record duration_ms.
- Emitting an audit event via `audit_fn` with the canonical event shape:
  surface, acting_admin_id, intent_admin_role, intent_model, intent_action,
  status="success", duration_ms.
- For impersonation sessions, also passing target_user_id and
  impersonation_session_id so audit consumers can correlate sequences of
  intents from the same session.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Optional

import sqlalchemy as sa
from fastapi import HTTPException

from intent_api.service import IntentService

from intent_api_admin.auto_admin.filters import apply_filters, apply_sort
from intent_api_admin.auto_admin.preconditions import check_preconditions, get_admin_context
from intent_api_admin.auto_admin.schemas import ResourceSchema

logger = logging.getLogger("intent_api_admin.service_factory")

# Minimum role required for all auto-generated admin operations
DEFAULT_MIN_ROLE = "support"


def _row_to_dict(row, redacted_fields: set[str]) -> dict:
    """Convert a SQLAlchemy model instance to a dict, omitting redacted fields."""
    result = {}
    for col in sa.inspect(type(row)).columns:
        key = col.key
        if key in redacted_fields:
            continue
        result[key] = getattr(row, key, None)
    return result


def _admin_context_fields(user, context):
    """Pull (admin_id, role, session_id, target_user_id, surface) from context+user."""
    admin_ctx = get_admin_context(user, context)
    admin_id = getattr(admin_ctx, "acting_admin_id", None) if admin_ctx else None
    role = getattr(admin_ctx, "intent_admin_role", None) if admin_ctx else None
    session_id = (
        getattr(admin_ctx, "impersonation_session_id", None) if admin_ctx else None
    )
    surface_attr = getattr(admin_ctx, "surface", None) if admin_ctx else None
    surface = surface_attr if surface_attr in ("admin-machine", "impersonation") else None
    target_user_id = getattr(user, "id", None) if getattr(user, "_is_impersonated", False) else None
    return admin_id, role, session_id, target_user_id, surface


def make_admin_service(
    model_name: str,
    model_class,
    resource_schema: ResourceSchema,
    deny_delete: bool,
    deny_edit_fields: set[str],
    redacted_fields: set[str],
    audit_fn: Callable,
) -> type:
    """
    Dynamically create an IntentService subclass for model_name.

    The generated class:
    - Is named AutoAdmin{model_name}Service
    - Has __display_prefix__ = f"Admin {model_name}"
    - Implements list, read, update, delete (not create)
    - Runs check_preconditions before each handler
    - Wraps each call in time.perf_counter() to record duration_ms
    - On precondition denial, emits a status="denied" audit event
    """
    _model_class = model_class
    _model_name = model_name
    _deny_delete = deny_delete
    _deny_edit_fields = frozenset(deny_edit_fields)
    _redacted_fields = frozenset(redacted_fields)
    _audit_fn = audit_fn
    _resource_schema = resource_schema

    mapper = sa.inspect(_model_class)
    _pk_cols = [c.key for c in mapper.columns if c.primary_key]
    _pk_col = _pk_cols[0] if _pk_cols else "id"

    async def _check_or_audit_denied(
        *, action, user, context, required_role, is_read_only_action, payload, resource_id
    ) -> None:
        """Run check_preconditions; on denial emit a denied audit event and re-raise."""
        try:
            check_preconditions(
                action=action,
                command=None,
                user=user,
                context=context,
                required_role=required_role,
                is_read_only_action=is_read_only_action,
                redacted_fields=set(_redacted_fields),
                deny_edit_fields=set(_deny_edit_fields),
                deny_delete=_deny_delete,
                payload=payload,
            )
        except HTTPException as exc:
            admin_id, role, session_id, target_user_id, surface = _admin_context_fields(
                user, context
            )
            error_code = None
            if isinstance(exc.detail, dict):
                error_code = exc.detail.get("code")
            await _audit_fn(
                action=action,
                model_name=_model_name,
                resource_id=resource_id,
                admin_id=admin_id,
                role=role,
                session_id=session_id,
                payload=payload,
                is_impersonation=getattr(user, "_is_impersonated", False),
                surface=surface,
                target_user_id=target_user_id,
                status="denied",
                error_code=error_code,
            )
            raise

    async def list_handler(self, *, db, user, context, skip=0, limit=50):
        from intent_api_admin.auto_admin import _admin_list_payload_var

        await _check_or_audit_denied(
            action="list",
            user=user,
            context=context,
            required_role=DEFAULT_MIN_ROLE,
            is_read_only_action=True,
            payload=None,
            resource_id=None,
        )

        start = time.perf_counter()
        payload = _admin_list_payload_var.get()
        filters = (payload or {}).get("filters", [])
        sort = (payload or {}).get("sort", [])

        query = sa.select(_model_class)
        if filters:
            query = apply_filters(query, _model_class, filters)
        if sort:
            query = apply_sort(query, _model_class, sort)

        query = query.offset(skip).limit(limit)
        rows = db.execute(query).scalars().all()
        duration_ms = (time.perf_counter() - start) * 1000.0

        admin_id, role, session_id, target_user_id, surface = _admin_context_fields(
            user, context
        )
        await _audit_fn(
            action="list",
            model_name=_model_name,
            resource_id=None,
            admin_id=admin_id,
            role=role,
            session_id=session_id,
            is_impersonation=getattr(user, "_is_impersonated", False),
            surface=surface,
            target_user_id=target_user_id,
            duration_ms=duration_ms,
        )
        return [_row_to_dict(row, _redacted_fields) for row in rows]

    async def read_handler(self, *, db, user, context, id):
        await _check_or_audit_denied(
            action="read",
            user=user,
            context=context,
            required_role=DEFAULT_MIN_ROLE,
            is_read_only_action=True,
            payload=None,
            resource_id=id,
        )

        start = time.perf_counter()
        pk_attr = getattr(_model_class, _pk_col)
        row = db.execute(sa.select(_model_class).where(pk_attr == id)).scalars().first()
        if row is None:
            raise HTTPException(
                status_code=404,
                detail=f"{_model_name} with id '{id}' not found.",
            )
        duration_ms = (time.perf_counter() - start) * 1000.0

        admin_id, role, session_id, target_user_id, surface = _admin_context_fields(
            user, context
        )
        await _audit_fn(
            action="read",
            model_name=_model_name,
            resource_id=id,
            admin_id=admin_id,
            role=role,
            session_id=session_id,
            is_impersonation=getattr(user, "_is_impersonated", False),
            surface=surface,
            target_user_id=target_user_id,
            duration_ms=duration_ms,
        )
        return _row_to_dict(row, _redacted_fields)

    async def update_handler(self, *, db, user, context, id, payload=None):
        payload = payload or {}
        await _check_or_audit_denied(
            action="update",
            user=user,
            context=context,
            required_role="admin",
            is_read_only_action=False,
            payload=payload,
            resource_id=id,
        )

        start = time.perf_counter()
        pk_attr = getattr(_model_class, _pk_col)
        row = db.execute(sa.select(_model_class).where(pk_attr == id)).scalars().first()
        if row is None:
            raise HTTPException(
                status_code=404,
                detail=f"{_model_name} with id '{id}' not found.",
            )
        for key, value in payload.items():
            if key in _redacted_fields or key in _deny_edit_fields:
                continue
            if hasattr(row, key):
                setattr(row, key, value)
        db.flush()
        duration_ms = (time.perf_counter() - start) * 1000.0

        admin_id, role, session_id, target_user_id, surface = _admin_context_fields(
            user, context
        )
        await _audit_fn(
            action="update",
            model_name=_model_name,
            resource_id=id,
            admin_id=admin_id,
            role=role,
            session_id=session_id,
            payload=payload,
            is_impersonation=getattr(user, "_is_impersonated", False),
            surface=surface,
            target_user_id=target_user_id,
            duration_ms=duration_ms,
        )
        return _row_to_dict(row, _redacted_fields)

    async def delete_handler(self, *, db, user, context, id):
        await _check_or_audit_denied(
            action="delete",
            user=user,
            context=context,
            required_role="owner",
            is_read_only_action=False,
            payload=None,
            resource_id=id,
        )

        start = time.perf_counter()
        pk_attr = getattr(_model_class, _pk_col)
        row = db.execute(sa.select(_model_class).where(pk_attr == id)).scalars().first()
        if row is None:
            raise HTTPException(
                status_code=404,
                detail=f"{_model_name} with id '{id}' not found.",
            )
        db.delete(row)
        db.flush()
        duration_ms = (time.perf_counter() - start) * 1000.0

        admin_id, role, session_id, target_user_id, surface = _admin_context_fields(
            user, context
        )
        await _audit_fn(
            action="delete",
            model_name=_model_name,
            resource_id=id,
            admin_id=admin_id,
            role=role,
            session_id=session_id,
            is_impersonation=getattr(user, "_is_impersonated", False),
            surface=surface,
            target_user_id=target_user_id,
            duration_ms=duration_ms,
        )
        from intent_api.service import MutationResponse
        return MutationResponse(success=True, id=str(id))

    service_class = type(
        f"AutoAdmin{model_name}Service",
        (IntentService,),
        {
            "__display_prefix__": f"Admin {model_name}",
            "_auto_admin_model": _model_class,
            "_auto_admin_model_name": _model_name,
            "_auto_admin_resource_schema": _resource_schema,
            "list": list_handler,
            "read": read_handler,
            "update": update_handler,
            "delete": delete_handler,
        },
    )

    return service_class
