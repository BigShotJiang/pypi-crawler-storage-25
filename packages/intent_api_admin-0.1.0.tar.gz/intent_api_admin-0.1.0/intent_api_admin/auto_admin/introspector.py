"""
SQLAlchemy model introspection for auto-admin.

Produces ResourceSchema instances from SQLAlchemy mapped classes.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

import sqlalchemy as sa
from sqlalchemy import inspect as sa_inspect

from intent_api_admin.auto_admin.heuristics import (
    compute_default_list_fields,
    compute_default_sort,
    compute_search_fields,
    should_auto_redact,
)
from intent_api_admin.auto_admin.schemas import (
    FieldSchema,
    RelationshipSchema,
    ResourceSchema,
)

logger = logging.getLogger("intent_api_admin.introspector")


# Mapping from SQLAlchemy type classes to FieldSchema type strings
def _map_sa_type(col_type) -> str:
    import sqlalchemy.dialects.postgresql as pg_types
    type_class = type(col_type)
    # Integer types
    if issubclass(type_class, (sa.Integer,)):
        return "int"
    # Float/numeric
    if issubclass(type_class, (sa.Float, sa.Numeric)):
        return "float"
    # Boolean
    if issubclass(type_class, sa.Boolean):
        return "bool"
    # DateTime
    if issubclass(type_class, sa.DateTime):
        return "datetime"
    # Date
    if issubclass(type_class, sa.Date):
        return "date"
    # UUID
    if issubclass(type_class, sa.Uuid):
        return "uuid"
    try:
        if issubclass(type_class, sa.UUID):
            return "uuid"
    except AttributeError:
        pass
    # JSON / JSONB
    if issubclass(type_class, sa.JSON):
        return "json"
    try:
        if issubclass(type_class, pg_types.JSONB):
            return "json"
    except (AttributeError, ImportError):
        pass
    # Enum
    if issubclass(type_class, sa.Enum):
        return "enum"
    # String types
    if issubclass(type_class, (sa.String, sa.Text, sa.UnicodeText, sa.Unicode)):
        return "str"
    return "unknown"


def find_model_by_name(base: Any, name: str):
    """Find a SQLAlchemy model class by name in the Base registry."""
    for mapper in base.registry.mappers:
        if mapper.class_.__name__ == name:
            return mapper.class_
    return None


def introspect_model(
    model_class,
    redact: list[str] | None = None,
    deny_edit_fields: list[str] | None = None,
    deny_delete: bool = False,
    overrides: dict | None = None,
) -> ResourceSchema:
    """
    Introspect a SQLAlchemy model class and produce a ResourceSchema.

    Applies:
    - Auto-redaction heuristics (password*, secret*, api_key*, *_hash, *_digest, _*)
    - Explicit redactions from redact parameter
    - deny_edit_fields (read-only fields in the admin UI)
    - Heuristic list_fields, search_fields, default_sort
    - Optional overrides dict to override any ResourceSchema field
    """
    mapper = sa_inspect(model_class)
    model_name = model_class.__name__

    # Build columns list from mapper
    columns = list(mapper.columns)

    # Compute auto-redacted fields
    auto_redacted = {c.key for c in columns if should_auto_redact(c.key)}
    explicit_redacted = set(redact or [])
    all_redacted = auto_redacted | explicit_redacted

    # Build FieldSchema for each column
    fields: dict[str, FieldSchema] = {}
    for col in columns:
        col_type = col.type
        type_str = _map_sa_type(col_type)

        # Detect foreign key
        fk_target = None
        if col.foreign_keys:
            fk_target = next(iter(col.foreign_keys)).target_fullname
            type_str = "foreign_key"

        # Enum values
        enum_vals = None
        if isinstance(col_type, sa.Enum) and col_type.enums:
            enum_vals = list(col_type.enums)

        # Max length
        max_len = getattr(col_type, "length", None)

        is_pk = col.primary_key
        is_nullable = col.nullable if col.nullable is not None else True
        is_read_only = col.key in (deny_edit_fields or []) or is_pk

        fields[col.key] = FieldSchema(
            name=col.key,
            type=type_str,
            nullable=is_nullable,
            primary_key=is_pk,
            read_only=is_read_only,
            enum_values=enum_vals,
            max_length=max_len,
            foreign_key_target=fk_target,
        )

    # Build RelationshipSchema
    relationships: dict[str, RelationshipSchema] = {}
    for rel in mapper.relationships:
        cardinality = "many" if rel.uselist else "one"
        # Find the FK column(s) used by this relationship
        via = None
        if rel.local_columns:
            local_col_names = [c.key for c in rel.local_columns if hasattr(c, "key")]
            if local_col_names:
                via = local_col_names[0]

        back_pop = getattr(rel, "back_populates", None) or getattr(rel, "backref", None)

        relationships[rel.key] = RelationshipSchema(
            name=rel.key,
            target_model=rel.mapper.class_.__name__,
            cardinality=cardinality,
            via=via,
            back_populates=back_pop,
        )

    # Compute heuristic fields
    list_fields = compute_default_list_fields(columns, all_redacted)
    search_fields = compute_search_fields(columns)
    default_sort = compute_default_sort(columns)

    # Display name: humanize model name
    display_name = _humanize(model_name)
    display_prefix = display_name

    resource = ResourceSchema(
        model_name=model_name,
        display_name=display_name,
        display_prefix=display_prefix,
        fields=fields,
        relationships=relationships,
        list_fields=list_fields,
        search_fields=search_fields,
        default_sort=default_sort,
        deny_delete=deny_delete,
        deny_edit_fields=list(deny_edit_fields or []),
        redacted_fields=sorted(all_redacted),
    )

    # Apply overrides
    if overrides:
        resource_dict = resource.model_dump()
        resource_dict.update(overrides)
        resource = ResourceSchema(**resource_dict)

    return resource


def _humanize(name: str) -> str:
    """Convert CamelCase to 'Human Readable' form."""
    import re
    # Insert space before uppercase letters that follow lowercase letters
    spaced = re.sub(r"([a-z])([A-Z])", r"\1 \2", name)
    return spaced
