"""
Augmented `@custom_action` decorator with admin-aware metadata.

This is the canonical decorator for admin-only custom actions in
intent-api-admin. It wraps the upstream `intent_api.service.custom_action`
so all of intent-api's machinery (`IntentService.__init_subclass__`,
`_registered_commands`, runtime policy resolution) keeps working
unchanged, while adding three additional fields:

  - admin_only: bool — if True, the discovery mechanism in `auto_admin()`
    relocates this command from the standard registry to the admin-machine
    registry, hiding it from standard / admin / MCP / machine surfaces.
  - min_role: "owner" | "admin" | "support" — minimum admin role.
  - read_only: bool — if True, the action is allowed under read-only
    impersonation sessions; otherwise IMPERSONATION_WRITE_DENIED.

Usage:

    from intent_api import IntentService
    from intent_api_admin import custom_action

    class UserService(IntentService):
        @custom_action(admin_only=True, min_role="admin")
        async def ban(self, *, db, user, context, id, payload):
            ...

A deprecated `admin_action` alias is kept in this module for back-compat;
new code should use `custom_action` directly.
"""

from __future__ import annotations

import warnings
from typing import Callable, Literal, Optional, Type

from pydantic import BaseModel

from intent_api.service import custom_action as _upstream_custom_action


def custom_action(
    *,
    schema: Optional[Type[BaseModel]] = None,
    name: Optional[str] = None,
    display: Optional[str] = None,
    description: Optional[str] = None,
    admin_only: bool = False,
    min_role: Literal["owner", "admin", "support"] = "admin",
    read_only: bool = False,
) -> Callable:
    """
    Augmented custom_action decorator.

    All upstream parameters (schema/name/display/description) behave
    identically to `intent_api.custom_action`. The three new admin
    parameters add metadata used by `auto_admin()`'s discovery
    mechanism and by precondition checks.

    Args:
        schema: Optional Pydantic model describing the payload.
        name: Optional explicit command name (defaults to method name).
        display: Optional human-readable action label for UIs.
        description: Optional one-line description.
        admin_only: If True, this command is relocated to the
            admin-machine registry by `auto_admin()` and is invisible
            to standard / admin / MCP / machine surfaces.
        min_role: Minimum admin role required to invoke. Default "admin".
        read_only: If True, allowed under read-only impersonation. Default False.
    """
    upstream = _upstream_custom_action(
        schema=schema, name=name, display=display, description=description
    )

    def decorator(fn: Callable) -> Callable:
        fn = upstream(fn)

        # Admin-aware extension attributes (set via setattr for type-checker friendliness).
        setattr(fn, "_intent_admin_only", bool(admin_only))
        setattr(fn, "_intent_admin_min_role", min_role)
        setattr(fn, "_intent_admin_read_only", bool(read_only))
        setattr(fn, "_intent_admin_description", description)

        # Backward-compatible legacy attribute names so older code that
        # introspected `_is_admin_action` etc. keeps working.
        setattr(fn, "_is_admin_action", bool(admin_only))
        setattr(fn, "_admin_min_role", min_role)
        setattr(fn, "_admin_read_only", bool(read_only))
        setattr(fn, "_admin_description", description)

        return fn

    return decorator


def admin_action(
    *,
    min_role: Literal["owner", "admin", "support"] = "admin",
    read_only: bool = False,
    description: Optional[str] = None,
    schema: Optional[Type[BaseModel]] = None,
    name: Optional[str] = None,
    display: Optional[str] = None,
) -> Callable:
    """
    DEPRECATED: use `@custom_action(admin_only=True, ...)` instead.

    Kept as a thin alias that emits DeprecationWarning. Behavior is
    identical to `custom_action(admin_only=True, ...)`.
    """
    warnings.warn(
        "@admin_action is deprecated; use @custom_action(admin_only=True, ...) instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return custom_action(
        schema=schema,
        name=name,
        display=display,
        description=description,
        admin_only=True,
        min_role=min_role,
        read_only=read_only,
    )
