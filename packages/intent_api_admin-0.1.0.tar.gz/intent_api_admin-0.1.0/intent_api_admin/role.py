"""
Role rank utilities for intent-api-admin.

Role hierarchy (highest to lowest): owner > admin > support
"""

from __future__ import annotations

ROLE_RANK: dict[str, int] = {"owner": 3, "admin": 2, "support": 1}


def check_role(required: str, actual: str | None) -> bool:
    """Return True if actual role >= required role."""
    if actual is None:
        return False
    return ROLE_RANK.get(actual, 0) >= ROLE_RANK.get(required, 999)
