"""
Admin-specific error types for intent-api-admin.

HTTP status mapping:
  403 → WrongSurface, ImpersonationWriteDenied, InsufficientRole, FieldRedacted,
         DeleteDenied, FieldReadOnly
  422 → UnsupportedFilterOp
  Config-time (no HTTP) → AdminAuthNotConfigured, ConfigurationOrderError, ModelNotFound
"""

from __future__ import annotations

from fastapi import HTTPException

from intent_api.providers.errors import IntentRuntimeError


class WrongSurface(IntentRuntimeError):
    code = "WRONG_SURFACE"

    def __init__(self, detail: str | None = None) -> None:
        msg = "This token is not valid on this surface."
        if detail:
            msg = f"{msg} {detail}"
        super().__init__(msg, detail={"detail": detail} if detail else {})

    def to_http_exception(self) -> HTTPException:
        return HTTPException(status_code=403, detail={"code": self.code, "message": self.message})


class ImpersonationWriteDenied(IntentRuntimeError):
    code = "IMPERSONATION_WRITE_DENIED"

    def __init__(self, action: str) -> None:
        super().__init__(
            f"Write action '{action}' is not permitted in this impersonation session.",
            detail={"action": action},
        )

    def to_http_exception(self) -> HTTPException:
        return HTTPException(status_code=403, detail={"code": self.code, "message": self.message, **self.detail})


class InsufficientRole(IntentRuntimeError):
    code = "INSUFFICIENT_ROLE"

    def __init__(self, required: str, actual: str | None) -> None:
        super().__init__(
            f"Role '{required}' required, but got '{actual}'.",
            detail={"required": required, "actual": actual},
        )

    def to_http_exception(self) -> HTTPException:
        return HTTPException(status_code=403, detail={"code": self.code, "message": self.message, **self.detail})


class FieldRedacted(IntentRuntimeError):
    code = "FIELD_REDACTED"

    def __init__(self, field: str) -> None:
        super().__init__(
            f"Field '{field}' is redacted and cannot be accessed.",
            detail={"field": field},
        )

    def to_http_exception(self) -> HTTPException:
        return HTTPException(status_code=403, detail={"code": self.code, "message": self.message, **self.detail})


class DeleteDenied(IntentRuntimeError):
    code = "DELETE_DENIED"

    def __init__(self, model: str) -> None:
        super().__init__(
            f"Delete is not permitted for model '{model}'.",
            detail={"model": model},
        )

    def to_http_exception(self) -> HTTPException:
        return HTTPException(status_code=403, detail={"code": self.code, "message": self.message, **self.detail})


class FieldReadOnly(IntentRuntimeError):
    code = "FIELD_READ_ONLY"

    def __init__(self, field: str) -> None:
        super().__init__(
            f"Field '{field}' is read-only and cannot be modified.",
            detail={"field": field},
        )

    def to_http_exception(self) -> HTTPException:
        return HTTPException(status_code=403, detail={"code": self.code, "message": self.message, **self.detail})


class UnsupportedFilterOp(IntentRuntimeError):
    code = "UNSUPPORTED_FILTER_OP"

    def __init__(self, op: str) -> None:
        super().__init__(
            f"Filter operator '{op}' is not supported.",
            detail={"op": op},
        )

    def to_http_exception(self) -> HTTPException:
        return HTTPException(status_code=422, detail={"code": self.code, "message": self.message, **self.detail})


class ModelNotFound(IntentRuntimeError):
    code = "MODEL_NOT_FOUND"

    def __init__(self, name: str) -> None:
        super().__init__(
            f"Model '{name}' was not found in the SQLAlchemy registry.",
            detail={"name": name},
        )


class AdminAuthNotConfigured(IntentRuntimeError):
    code = "ADMIN_AUTH_NOT_CONFIGURED"

    def __init__(self) -> None:
        super().__init__(
            "Admin auth has not been configured. Call configure_admin_auth() first.",
        )


class ConfigurationOrderError(IntentRuntimeError):
    code = "CONFIGURATION_ORDER_ERROR"

    def __init__(self) -> None:
        super().__init__(
            "configure_admin_auth() must be called before auto_admin() is used.",
        )
