"""
Global configuration for intent-api-admin.

Call configure_admin_auth() once at application startup before calling auto_admin().
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from intent_api_admin.errors import AdminAuthNotConfigured, ConfigurationOrderError


@dataclass
class AdminAuthConfig:
    issuer: str
    audience: str
    jwks_url: str
    impersonation_user_query: Callable  # async (db, target_user_id) -> user
    jwks_cache_ttl_seconds: int = 3600
    base: Any = None  # SQLAlchemy declarative Base (for auto_admin introspection)
    _auto_admin_called: bool = field(default=False, init=False, repr=False)


_config: Optional[AdminAuthConfig] = None


def configure_admin_auth(
    issuer: str,
    audience: str,
    impersonation_user_query: Callable,
    jwks_url: str | None = None,
    jwks_cache_ttl_seconds: int = 3600,
    base: Any = None,
) -> None:
    """
    Configure admin auth for this application.

    Must be called before auto_admin() and before any request handling begins.
    Raises ConfigurationOrderError if auto_admin() has already been called.
    """
    global _config
    if _config is not None and _config._auto_admin_called:
        raise ConfigurationOrderError()
    _config = AdminAuthConfig(
        issuer=issuer,
        audience=audience,
        jwks_url=jwks_url or f"{issuer.rstrip('/')}/.well-known/jwks.json",
        impersonation_user_query=impersonation_user_query,
        jwks_cache_ttl_seconds=jwks_cache_ttl_seconds,
        base=base,
    )


def get_config() -> AdminAuthConfig:
    """Return the current config. Raises AdminAuthNotConfigured if not set."""
    if _config is None:
        raise AdminAuthNotConfigured()
    return _config


def _reset_config() -> None:
    """Reset the global config. For testing only."""
    global _config
    _config = None
