"""
Audit event helpers for intent-api-admin.

Emits structured audit events for admin operations across the
admin-machine and impersonation surfaces. Products can replace the
default handler by calling `set_audit_handler()`. When no IntentRuntime
is configured AND no custom handler is set, events are logged at INFO
on the `intent_api_admin.audit` logger.

Canonical event shape:

    {
        "surface": "admin-machine" | "impersonation",
        "action": str,                  # "list", "read", "update", "delete", "custom"
        "command": str | None,          # custom action command name
        "intent_model": str,            # the dispatched model name
        "intent_action": str,           # alias of action
        "model": str,                   # legacy alias of intent_model
        "resource_id": str | None,
        "acting_admin_id": str | None,
        "admin_id": str | None,         # legacy alias of acting_admin_id
        "intent_admin_role": str | None,
        "role": str | None,             # legacy alias of intent_admin_role
        "target_user_id": str | None,
        "impersonation_session_id": str | None,
        "session_id": str | None,       # legacy alias of impersonation_session_id
        "is_impersonation": bool,
        "status": "success" | "denied" | "error",
        "error_code": str | None,
        "duration_ms": float | None,
        "timestamp": float,             # POSIX seconds, time.time()
        "payload_keys": list[str],
    }
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Optional

logger = logging.getLogger("intent_api_admin.audit")

_audit_handler: Optional[Callable] = None


def set_audit_handler(handler: Optional[Callable]) -> None:
    """
    Override the default (logging-based) audit handler.

    handler signature: async (event: dict) -> None
    Pass None to reset to the default logging handler.
    """
    global _audit_handler
    _audit_handler = handler


def _build_event(
    *,
    action: str,
    model_name: str,
    resource_id: Any,
    admin_id: Optional[str],
    role: Optional[str],
    session_id: Optional[str],
    payload: Optional[dict],
    is_impersonation: bool,
    surface: Optional[str],
    target_user_id: Optional[str],
    status: str,
    error_code: Optional[str],
    duration_ms: Optional[float],
    command: Optional[str],
) -> dict:
    if surface is None:
        surface = "impersonation" if is_impersonation else "admin-machine"
    return {
        # Canonical fields
        "surface": surface,
        "action": action,
        "command": command,
        "intent_model": model_name,
        "intent_action": action,
        "resource_id": str(resource_id) if resource_id is not None else None,
        "acting_admin_id": admin_id,
        "intent_admin_role": role,
        "target_user_id": target_user_id,
        "impersonation_session_id": session_id,
        "is_impersonation": is_impersonation,
        "status": status,
        "error_code": error_code,
        "duration_ms": duration_ms,
        "timestamp": time.time(),
        "payload_keys": list(payload.keys()) if payload else [],
        # Legacy aliases (kept for back-compat with handlers written
        # against the v0.0.x shape).
        "model": model_name,
        "admin_id": admin_id,
        "role": role,
        "session_id": session_id,
    }


async def emit_audit_event(
    action: str,
    model_name: str,
    resource_id: Any,
    admin_id: Optional[str],
    role: Optional[str],
    session_id: Optional[str] = None,
    payload: Optional[dict] = None,
    is_impersonation: bool = False,
    surface: Optional[str] = None,
    target_user_id: Optional[str] = None,
    status: str = "success",
    error_code: Optional[str] = None,
    duration_ms: Optional[float] = None,
    command: Optional[str] = None,
) -> None:
    """
    Emit a structured audit event for an admin operation.

    If a custom handler has been set via set_audit_handler(), it is called.
    Otherwise, the event is logged at INFO level on the
    `intent_api_admin.audit` logger.
    """
    event = _build_event(
        action=action,
        model_name=model_name,
        resource_id=resource_id,
        admin_id=admin_id,
        role=role,
        session_id=session_id,
        payload=payload,
        is_impersonation=is_impersonation,
        surface=surface,
        target_user_id=target_user_id,
        status=status,
        error_code=error_code,
        duration_ms=duration_ms,
        command=command,
    )
    if _audit_handler is not None:
        await _audit_handler(event)
    else:
        logger.info("admin_audit", extra=event)


async def emit_denied_event(
    *,
    action: str,
    model_name: str,
    resource_id: Any,
    admin_id: Optional[str],
    role: Optional[str],
    session_id: Optional[str],
    error_code: str,
    surface: Optional[str] = None,
    target_user_id: Optional[str] = None,
    payload: Optional[dict] = None,
    is_impersonation: bool = False,
    command: Optional[str] = None,
) -> None:
    """Convenience helper for emitting a denied event with status='denied'."""
    await emit_audit_event(
        action=action,
        model_name=model_name,
        resource_id=resource_id,
        admin_id=admin_id,
        role=role,
        session_id=session_id,
        payload=payload,
        is_impersonation=is_impersonation,
        surface=surface,
        target_user_id=target_user_id,
        status="denied",
        error_code=error_code,
        command=command,
    )
