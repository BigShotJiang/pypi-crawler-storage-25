"""
JWT parsing and validation for admin console tokens.

All tokens use EdDSA (Ed25519) signing. HS256 and other algorithms are
explicitly rejected. On unknown kid or signature failure, the JWKS cache
is refreshed once and the verification is retried.
"""

from __future__ import annotations

import logging
from typing import Any

import jwt
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from fastapi import HTTPException

from intent_api_admin.auth.jwks import JWKSCache
from intent_api_admin.config import AdminAuthConfig

logger = logging.getLogger("intent_api_admin.tokens")

REQUIRED_ADMIN_CLAIMS = frozenset({
    "iss", "sub", "aud", "exp", "iat", "mode", "intent_admin_role", "kid",
})
REQUIRED_IMPERSONATION_CLAIMS = frozenset({
    "iss", "sub", "aud", "exp", "iat", "mode", "intent_admin_role",
    "target_user_id", "session_id", "allow_writes", "kid",
})


async def verify_token(
    token: str,
    config: AdminAuthConfig,
    jwks_cache: JWKSCache,
) -> dict[str, Any]:
    """
    Verify a console-issued JWT. Returns decoded claims dict.

    Steps:
    1. Decode header without verification to get kid and alg.
    2. Reject non-EdDSA algorithms (raises HTTP 401).
    3. Fetch public key from JWKS cache by kid.
    4. Verify signature with Ed25519 public key.
    5. Verify iss, aud, exp.
    6. Return claims.

    On unknown kid or signature failure, refreshes JWKS once and retries.
    Raises HTTPException(401) for any auth failure.
    """
    try:
        header = jwt.get_unverified_header(token)
    except jwt.exceptions.DecodeError as exc:
        raise HTTPException(status_code=401, detail=f"Invalid token header: {exc}")

    alg = header.get("alg", "")
    if alg != "EdDSA":
        raise HTTPException(
            status_code=401,
            detail=f"Unsupported algorithm '{alg}'. Only EdDSA tokens are accepted.",
        )

    kid = header.get("kid")
    if not kid:
        raise HTTPException(status_code=401, detail="Token header missing 'kid'.")

    # Attempt verification (with one retry on JWKS refresh)
    for attempt in range(2):
        pub_key = await jwks_cache.get_key(kid)
        if pub_key is None:
            if attempt == 0:
                # Force a refresh and retry
                await jwks_cache.refresh()
                continue
            raise HTTPException(status_code=401, detail=f"Unknown key id '{kid}'.")

        # Serialize Ed25519PublicKey to PEM for pyjwt
        pem = pub_key.public_bytes(encoding=Encoding.PEM, format=PublicFormat.SubjectPublicKeyInfo)

        try:
            claims = jwt.decode(
                token,
                pem,
                algorithms=["EdDSA"],
                issuer=config.issuer,
                audience=config.audience,
                options={"require": ["exp", "iss", "aud", "iat"]},
            )
            return claims
        except jwt.exceptions.InvalidSignatureError:
            if attempt == 0:
                # Key may have rotated — force a refresh and retry
                await jwks_cache.refresh()
                continue
            raise HTTPException(status_code=401, detail="Token signature is invalid.")
        except jwt.exceptions.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token has expired.")
        except jwt.exceptions.InvalidIssuerError:
            raise HTTPException(status_code=401, detail="Token issuer is invalid.")
        except jwt.exceptions.InvalidAudienceError:
            raise HTTPException(status_code=401, detail="Token audience is invalid.")
        except jwt.exceptions.DecodeError as exc:
            raise HTTPException(status_code=401, detail=f"Token decode error: {exc}")

    # Should not reach here, but guard anyway
    raise HTTPException(status_code=401, detail="Token verification failed.")
