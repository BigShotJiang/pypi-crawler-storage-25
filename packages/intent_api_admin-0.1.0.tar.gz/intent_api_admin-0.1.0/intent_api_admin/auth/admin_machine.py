"""
Auth dependency for the admin-machine surface.

Verifies bearer tokens as console JWTs with mode="admin".
Raises WRONG_SURFACE (HTTP 403) if mode="impersonation".
Raises HTTP 401 on any auth failure.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import HTTPException

from intent_api_admin.auth.jwks import JWKSCache
from intent_api_admin.auth.tokens import verify_token
from intent_api_admin.config import get_config
from intent_api_admin.errors import WrongSurface

logger = logging.getLogger("intent_api_admin.admin_machine")

# Module-level JWKS cache singleton (created lazily on first use)
_jwks_cache: JWKSCache | None = None


def _get_jwks_cache() -> JWKSCache:
    global _jwks_cache
    config = get_config()
    if _jwks_cache is None or _jwks_cache.jwks_url != config.jwks_url:
        _jwks_cache = JWKSCache(config.jwks_url, config.jwks_cache_ttl_seconds)
    return _jwks_cache


def _reset_jwks_cache() -> None:
    """Reset the JWKS cache singleton. For testing only."""
    global _jwks_cache
    _jwks_cache = None


def admin_machine_auth():
    """
    Returns a get_user-shaped async function for use with build_admin_machine().

    Verifies the bearer token as a console JWT with mode="admin".
    Raises WRONG_SURFACE (HTTP 403) if the token has mode="impersonation".
    Raises HTTP 401 on any other auth failure.

    The returned user object has attributes:
        id: str — the admin user's subject (sub claim)
        email: str | None — from the token's email claim, if present
        intent_admin_role: str — "owner" | "admin" | "support"
        acting_admin_id: str — same as id (for context construction)
    """
    async def _auth(
        *,
        credentials,
        context,
        db,
    ) -> Any:
        config = get_config()
        jwks_cache = _get_jwks_cache()
        token = credentials.credentials

        claims = await verify_token(token, config, jwks_cache)

        mode = claims.get("mode")
        if mode == "impersonation":
            raise WrongSurface(
                "Impersonation tokens are not valid on the admin-machine surface."
            ).to_http_exception()

        if mode != "admin":
            raise HTTPException(
                status_code=401,
                detail=f"Expected token mode 'admin', got '{mode}'.",
            )

        admin_role = claims.get("intent_admin_role")
        if not admin_role:
            raise HTTPException(
                status_code=401, detail="Token missing 'intent_admin_role' claim."
            )

        sub = claims.get("sub")
        if not sub:
            raise HTTPException(status_code=401, detail="Token missing 'sub' claim.")

        return _AdminUser(
            id=sub,
            email=claims.get("email"),
            intent_admin_role=admin_role,
            acting_admin_id=sub,
            raw_claims=claims,
        )

    return _auth


class _AdminUser:
    """Minimal user object returned by admin_machine_auth."""

    def __init__(
        self,
        id: str,
        email: str | None,
        intent_admin_role: str,
        acting_admin_id: str,
        raw_claims: dict,
    ) -> None:
        self.id = id
        self.email = email
        self.intent_admin_role = intent_admin_role
        self.acting_admin_id = acting_admin_id
        self._raw_claims = raw_claims

    def __repr__(self) -> str:
        return f"<AdminUser id={self.id!r} role={self.intent_admin_role!r}>"
