"""
JWKS cache for Ed25519 key fetching and verification.

Fetches public keys from a JWKS endpoint (OKP/Ed25519 only).
Caches keys with configurable TTL, refreshes on stale or unknown kid.
"""

from __future__ import annotations

import base64
import time
from typing import Optional

import httpx
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class JWKSCache:
    """
    Cache for Ed25519 public keys fetched from a JWKS endpoint.

    Keys are indexed by `kid` (key ID). Cache is considered stale after
    `ttl_seconds` seconds. On cache miss or stale cache, keys are refreshed
    from the JWKS URL.
    """

    def __init__(self, jwks_url: str, ttl_seconds: int = 3600) -> None:
        self.jwks_url = jwks_url
        self.ttl_seconds = ttl_seconds
        self._keys: dict[str, Ed25519PublicKey] = {}
        self._fetched_at: float = 0

    def is_stale(self) -> bool:
        """Return True if the cache has expired."""
        return time.time() - self._fetched_at > self.ttl_seconds

    async def get_key(self, kid: str) -> Optional[Ed25519PublicKey]:
        """
        Return the Ed25519 public key for the given key ID.

        Refreshes from the JWKS endpoint if the cache is stale or the kid
        is not found.
        """
        if self.is_stale() or kid not in self._keys:
            await self.refresh()
        return self._keys.get(kid)

    async def refresh(self) -> None:
        """Fetch and parse keys from the JWKS endpoint."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(self.jwks_url)
            resp.raise_for_status()
            data = resp.json()

        self._keys = {}
        for jwk in data.get("keys", []):
            if jwk.get("kty") != "OKP" or jwk.get("crv") != "Ed25519":
                continue
            kid = jwk.get("kid")
            if not kid:
                continue
            # x is the base64url-encoded public key bytes (32 bytes for Ed25519)
            x_b64 = jwk["x"]
            # Add padding if needed
            padding = 4 - len(x_b64) % 4
            if padding != 4:
                x_b64 += "=" * padding
            x_bytes = base64.urlsafe_b64decode(x_b64)
            key = Ed25519PublicKey.from_public_bytes(x_bytes)
            self._keys[kid] = key
        self._fetched_at = time.time()
