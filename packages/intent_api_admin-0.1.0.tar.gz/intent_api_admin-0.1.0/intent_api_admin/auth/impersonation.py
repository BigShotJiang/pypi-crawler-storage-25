"""
Impersonation auth for the standard surface.

impersonation_aware_auth() wraps an existing get_user function.
If the bearer token is a valid impersonation JWT, it fetches the target
user and returns an ImpersonatedUser proxy. Otherwise, it delegates to
the original get_user (transparent for normal tokens).
"""

from __future__ import annotations

import logging
from typing import Any, Callable

import jwt
from fastapi import HTTPException

from intent_api.schemas import AdminIntentContext, IntentContext
from intent_api.surfaces import SURFACE_IMPERSONATION
from intent_api_admin.auth.jwks import JWKSCache
from intent_api_admin.auth.tokens import verify_token
from intent_api_admin.config import get_config
from intent_api_admin.errors import WrongSurface

logger = logging.getLogger("intent_api_admin.impersonation")

# Module-level JWKS cache for impersonation (shared with admin_machine)
_impersonation_jwks_cache: JWKSCache | None = None


def _get_jwks_cache() -> JWKSCache:
    global _impersonation_jwks_cache
    config = get_config()
    if (
        _impersonation_jwks_cache is None
        or _impersonation_jwks_cache.jwks_url != config.jwks_url
    ):
        _impersonation_jwks_cache = JWKSCache(
            config.jwks_url, config.jwks_cache_ttl_seconds
        )
    return _impersonation_jwks_cache


def _reset_jwks_cache() -> None:
    """Reset the JWKS cache singleton. For testing only."""
    global _impersonation_jwks_cache
    _impersonation_jwks_cache = None


class ImpersonatedUser:
    """
    Thin proxy around a real user object for impersonation sessions.

    Delegates all non-private attribute access to the wrapped target user.
    Carries _is_impersonated=True and _admin_context for precondition checks.
    """

    _is_impersonated = True

    def __init__(self, target_user: Any, admin_context: AdminIntentContext) -> None:
        # Use object.__setattr__ to avoid triggering __getattr__
        object.__setattr__(self, "_target_user", target_user)
        object.__setattr__(self, "_admin_context", admin_context)

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._target_user, name)

    def __repr__(self) -> str:
        target = object.__getattribute__(self, "_target_user")
        ctx = object.__getattribute__(self, "_admin_context")
        return f"<ImpersonatedUser target={getattr(target, 'id', '?')!r} admin={ctx.acting_admin_id!r}>"


def impersonation_aware_auth(base_get_user: Callable) -> Callable:
    """
    Wraps a get_user function to transparently handle impersonation tokens.

    Behavior:
    - If the token is a valid impersonation JWT (mode="impersonation"):
        * Calls impersonation_user_query(db, target_user_id) to fetch target user.
        * Builds an AdminIntentContext from token claims.
        * Mutates context.surface = "impersonation" if context is not None.
        * Returns ImpersonatedUser proxy with _admin_context set.
    - If the token is a console admin JWT (mode="admin"):
        * Raises WRONG_SURFACE as HTTP 403 (admin tokens can't use standard surface).
    - If the token is not a recognizable console JWT:
        * Falls through to base_get_user.

    The ImpersonatedUser proxy delegates all attribute access to the real user,
    so the service layer sees a normal user object. Services that need to check
    admin context use get_admin_context(user, context) from preconditions.py.
    """

    async def _auth(*, credentials, context, db) -> Any:
        config = get_config()
        jwks_cache = _get_jwks_cache()
        token = credentials.credentials

        # Try to decode the header to check if it's a console JWT
        try:
            header = jwt.get_unverified_header(token)
        except jwt.exceptions.DecodeError:
            # Not a JWT at all — fall through to base
            return await base_get_user(credentials=credentials, context=context, db=db)

        # Only intercept OKP/EdDSA tokens (console-issued)
        if header.get("alg") != "EdDSA":
            return await base_get_user(credentials=credentials, context=context, db=db)

        # Try to decode unverified claims to peek at mode
        try:
            unverified = jwt.decode(
                token,
                options={"verify_signature": False, "verify_exp": False},
                algorithms=["EdDSA"],
            )
            mode = unverified.get("mode")
        except jwt.exceptions.DecodeError:
            return await base_get_user(credentials=credentials, context=context, db=db)

        if mode == "admin":
            # Admin tokens cannot be used on the standard surface
            raise WrongSurface(
                "Admin tokens are not valid on the standard surface. "
                "Use the admin-machine surface instead."
            ).to_http_exception()

        if mode != "impersonation":
            # Unknown mode — fall through to base auth
            return await base_get_user(credentials=credentials, context=context, db=db)

        # This is an impersonation token — verify it fully
        claims = await verify_token(token, config, jwks_cache)

        target_user_id = claims.get("target_user_id")
        if not target_user_id:
            raise HTTPException(
                status_code=401,
                detail="Impersonation token missing 'target_user_id' claim.",
            )

        session_id = claims.get("session_id")
        allow_writes = bool(claims.get("allow_writes", False))
        admin_role = claims.get("intent_admin_role")
        acting_admin_id = claims.get("sub")

        # Fetch target user via the product's user query
        target_user = await config.impersonation_user_query(db, target_user_id)
        if target_user is None:
            raise HTTPException(
                status_code=404, detail=f"Target user '{target_user_id}' not found."
            )

        # Build AdminIntentContext for this session
        admin_context = AdminIntentContext(
            type="user",
            surface=SURFACE_IMPERSONATION,
            acting_admin_id=acting_admin_id,
            impersonation_session_id=session_id,
            allow_writes=allow_writes,
            intent_admin_role=admin_role,
        )

        # Mutate the client-provided context's surface field if available
        if context is not None and not isinstance(context, AdminIntentContext):
            try:
                context.surface = SURFACE_IMPERSONATION
            except Exception:
                pass  # Pydantic may reject this; best-effort mutation

        return ImpersonatedUser(target_user=target_user, admin_context=admin_context)

    return _auth
