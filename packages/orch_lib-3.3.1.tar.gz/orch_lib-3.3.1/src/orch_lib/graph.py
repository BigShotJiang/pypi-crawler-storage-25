from typing import Dict, Optional

from .agent import Agent
from .utils.conditional import Conditional
from .utils.memory import Memory


class Graph:
    def __init__(
        self,
        agents: Optional[Dict[str, Agent]] = None,
        memory: Optional[Memory] = None,
        routes: Optional[Dict[str, Conditional]] = None,
        max_passes: int = 10000,
    ):
        self.agents = agents if agents is not None else {}
        self.memory = memory if memory is not None else Memory()
        self.routes = routes if routes is not None else {}
        self.max_passes = max_passes

    def add_agent(self, id: str, agent: Agent):
        self.agents[id] = agent
        agent.parent = self.memory

    def add_memory(self, data: dict):
        self.memory.memory.update(data)

    def add_route(self, route: str, condition: Conditional):
        self.routes[route] = condition

    def __call__(self, *args, **kwds):
        flag = True
        passes = 0
        while flag and passes < self.max_passes:
            passes += 1
            ran = False
            for route, condition in self.routes.items():
                if condition(parent={"public": self.memory.memory, "private": {}}):
                    self.agents[route]()
                    ran = True
            if not ran:
                flag = False

    def __repr__(self) -> str:
        return f"Graph(agents={self.agents!r}, memory={self.memory!r})"
