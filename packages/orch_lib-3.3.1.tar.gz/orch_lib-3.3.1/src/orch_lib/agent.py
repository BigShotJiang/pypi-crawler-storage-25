from typing import Dict, Optional, Union

from .utils.conditional import Conditional, RouteType
from .utils.memory import Memory
from .utils.task import Task


class Agent:
    # class Agent
    def __init__(
        self,
        tasks: Optional[Dict[str, Task]] = None,
        memory: Optional[Memory] = None,
        routes: Optional[Dict[str, Union[Conditional, RouteType]]] = None,
        name: Optional[str] = None,
        parent=None,
        max_passes: int = 10000,
    ):
        self.tasks = tasks if tasks is not None else {}
        self.memory = memory if memory is not None else Memory()
        self.routes = routes if routes is not None else {}
        self.name = name
        self.parent = parent.memory if parent is not None else None
        self.max_passes = max_passes

    def add_task(self, id: str, task: Task):
        self.tasks[id] = task

    def add_route(self, id: str, condition):
        self.routes[id] = condition

    def add_memory(self, key: str, value):
        self.memory[key] = value

    def __call__(self, *args, **kwds):
        graph_mem = self.parent.memory if self.parent is not None else {}
        agent_mem = self.memory.memory
        extra = {"private": agent_mem, "public": graph_mem}
        starts = [r for r, c in self.routes.items() if c == "on_start"]
        ends = [r for r, c in self.routes.items() if c == "on_end"]
        for s in starts:
            self.tasks[s](extra_memories=extra)
        flag = True
        passes = 0
        while flag and passes < self.max_passes:
            ran = False
            for route, condition in self.routes.items():
                if isinstance(condition, Conditional):
                    if condition(parent=extra):
                        self.tasks[route](extra_memories=extra)
                        ran = True
            passes += 1
            if not ran:
                flag = False
        for e in ends:
            self.tasks[e](extra_memories=extra)
