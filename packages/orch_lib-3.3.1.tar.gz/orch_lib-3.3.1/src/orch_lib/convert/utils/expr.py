import re

from .utils import _apply_kw

# ─────────────────────────────────────────────────────────────────────────────
# ExprTranslator — turns a single DSL expression into valid Python
#
# This is used when rendering individual lines inside task bodies.  It handles
# four things in order:
#
#   1. Cross-agent reads:  Public.AgentName{2}.someVar
#      becomes  g.get("AgentName_2_someVar")
#      These are how agents peek at each other's published state.
#
#   2. Brace-numbers inside string literals:  'Agent {2} wins'
#      becomes  'Agent _2 wins'
#      Curly braces in DSL strings are instance markers, not f-string holes.
#
#   3. DSL keywords:  AND, OR, NOT, null, agentId, etc.
#      become normal Python equivalents via _apply_kw.
#
#   4. Memory variable names:  budget, status, round, etc.
#      become  prv["budget"],  prv["status"],  etc.
#      BUT — task-local variables (things assigned in the task but not
#      declared in the agent's memory spec) stay as plain identifiers.
#      That is what the  local_vars  set is for.
# ─────────────────────────────────────────────────────────────────────────────


class ExprTranslator:
    def __init__(self, mem_vars: set, local_vars: set):
        # Only rewrite names that are proper memory variables, not task-locals.
        self.replace_as_prv = mem_vars - local_vars

    def translate(self, expr: str) -> str:
        # Step 1 — cross-agent public variable access
        # Handle both Public.Agent{1}.var and Public.Agent[1].var and Public.Agent [ 1 ].var
        expr = re.sub(
            r"Public\.(\w+)\{(\d+)\}\.(\w+)",
            lambda m: f'g.get("{m.group(1)}_{m.group(2)}_{m.group(3)}")',
            expr,
        )
        expr = re.sub(
            r"Public\.(\w+)\s*\[\s*(\d+)\s*\]\s*\.(\w+)",
            lambda m: f'g.get("{m.group(1)}_{m.group(2)}_{m.group(3)}")',
            expr,
        )

        # Step 2 — fix {n} inside string literals to _n
        def fix_brace(m):
            return re.sub(r"\{(\d+)\}", r"_\1", m.group(0))

        expr = re.sub(r"'[^']*'", fix_brace, expr)
        expr = re.sub(r'"[^"]*"', fix_brace, expr)

        # Step 3 — DSL keywords to Python
        expr = _apply_kw(expr)

        # Step 4 — memory variable names to prv["name"] lookups
        for v in sorted(self.replace_as_prv, key=len, reverse=True):
            expr = re.sub(rf"\b{re.escape(v)}\b", f'prv["{v}"]', expr)

        return expr
