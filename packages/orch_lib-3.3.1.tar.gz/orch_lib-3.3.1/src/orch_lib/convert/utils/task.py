import re

from .expr import ExprTranslator

# ─────────────────────────────────────────────────────────────────────────────
# TaskRenderer — the heart of the converter
#
# This is the class that takes a raw DSL task_text string and turns it into
# a list of Python source lines.  A task_text looks something like:
#
#     "budget = budget - mybid; log('placed bid:', mybid)"
#
# and needs to become:
#
#     prv["budget"] = prv["budget"] - prv["mybid"]
#     print('placed bid:', prv["mybid"])
#
# The renderer needs to know about three categories of variables upfront
# so it can decide how to write each assignment:
#
#   prv_names    — all of the agent's memory variables (private and public)
#   pub_names    — the subset that are marked is_public=true
#   global_names — the graph-level global variable names from the orchfile
#
# Why does it need all three?  Because the same assignment  "round = round + 1"
# might mean different things depending on whether "round" is private-only,
# public (needs to be mirrored into graph memory), or a global that needs to
# stay in sync for graph routing to work correctly.
# ─────────────────────────────────────────────────────────────────────────────


class TaskRenderer:
    # These two task names are lifecycle hooks, not regular conditional tasks.
    # They are wired up differently (string literals instead of Conditionals).
    LIFECYCLE = {"on_start", "on_end"}

    def __init__(self, prv_names, pub_names, global_names, id_expr: str = "agent_id"):
        self.prv = set(prv_names)
        self.pub = set(pub_names)
        self.glb = set(global_names)
        self.mem = self.prv | self.pub  # everything that lives in agent memory
        self.id = id_expr  # the Python expression for the agent's id

    # ── Low-level parsing helpers ─────────────────────────────────────────────
    #
    # DSL task bodies use semicolons to separate statements and curly braces
    # for IF blocks.  We cannot just split on ";" with str.split() because a
    # semicolon might appear inside a string literal or inside an IF body.
    # These three helpers do depth-aware splitting that respects that.

    @staticmethod
    def _split_stmts(text: str) -> list:
        """Split the task body into individual statements on ';',
        but only at the top level — not inside { } blocks or strings."""
        stmts, cur, depth = [], "", 0
        in_str, str_ch = False, None
        for ch in text:
            if not in_str and ch in ('"', "'"):
                in_str, str_ch = True, ch
                cur += ch
            elif in_str and ch == str_ch:
                in_str = False
                cur += ch
            elif not in_str and ch == "{":
                depth += 1
                cur += ch
            elif not in_str and ch == "}":
                depth -= 1
                cur += ch
            elif not in_str and ch == ";" and depth == 0:
                s = cur.strip()
                if s:
                    stmts.append(s)
                cur = ""
            else:
                cur += ch
        s = cur.strip()
        if s:
            stmts.append(s)
        return stmts

    @staticmethod
    def _split_args(text: str) -> list:
        """Split a function's argument list on commas, but only at the top
        level so  log('a, b', x)  does not get split inside the string."""
        args, cur, depth = [], "", 0
        in_str, str_ch = False, None
        for ch in text:
            if not in_str and ch in ('"', "'"):
                in_str, str_ch = True, ch
                cur += ch
            elif in_str and ch == str_ch:
                in_str = False
                cur += ch
            elif not in_str and ch in ("(", "[", "{"):
                depth += 1
                cur += ch
            elif not in_str and ch in (")", "]", "}"):
                depth -= 1
                cur += ch
            elif not in_str and ch == "," and depth == 0:
                args.append(cur)
                cur = ""
            else:
                cur += ch
        if cur.strip():
            args.append(cur)
        return args

    @staticmethod
    def _block_end(text: str, start: int) -> int:
        """Given the position of an opening '{', find its matching '}'.
        We track depth so nested blocks are handled correctly."""
        depth = 0
        for i in range(start, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    return i
        raise ValueError(f"Unmatched '{{' in DSL near: {text[start : start + 50]!r}")

    # ── Pre-scan helpers ──────────────────────────────────────────────────────
    #
    # Before rendering a task, we do two quick passes over the raw text to
    # answer two questions:
    #   1. Which variables are task-local (assigned here but not in memory)?
    #   2. Does this task ever touch graph memory, or is it purely internal?
    # The answers let render_task() emit the right header lines.

    def _local_vars(self, text: str) -> set:
        """Find variables that are assigned in this task body but are NOT
        declared in the agent's memory spec.  These stay as plain Python
        identifiers — no  prv[...]  lookup needed."""
        loc = set()
        for m in re.finditer(r"\b(\w+)\s*=(?!=)", text):
            v = m.group(1)
            if v not in self.mem and v not in ("IF", "ELSE", "True", "False"):
                loc.add(v)
        return loc

    def _needs_g(self, text: str) -> bool:
        """Does this task need access to graph memory?  It does if it reads
        another agent's public variable, writes a public variable of its own,
        or reads/writes a graph global."""
        return (
            "Public." in text
            or any(v in text for v in self.pub)
            or any(v in text for v in self.glb)
        )

    # ── Main entry point ──────────────────────────────────────────────────────

    def render_task(self, task_text: str, base: int = 2) -> list:
        """Turn a DSL task_text string into a list of Python source lines.

        Every generated task function starts by pulling its memory dict out
        of the scope object that the framework passes in.  If the task also
        needs graph memory (to read a peer's value or publish its own), we
        pull that out too.  Then we render the statements."""
        loc = self._local_vars(task_text)
        tr = ExprTranslator(self.mem, loc)
        p = "    " * base
        lines = [f'{p}prv = scope["public"]["private"]']
        if self._needs_g(task_text):
            lines.append(f'{p}g   = scope["public"]["public"]')
        lines.append("")
        lines += self._render_stmts(task_text, base, tr)
        return lines

    # ── Statement-level rendering ─────────────────────────────────────────────

    def _render_stmts(self, text: str, ind: int, tr: ExprTranslator) -> list:
        lines = []
        for stmt in self._split_stmts(text):
            lines += self._render_stmt(stmt.strip(), ind, tr)
        return lines

    def _render_stmt(self, stmt: str, ind: int, tr: ExprTranslator) -> list:
        """Dispatch a single statement to the right renderer.
        We check for IF blocks first, then log() calls, then assignments,
        and fall back to treating the whole thing as an expression."""
        p = "    " * ind
        if not stmt:
            return []
        if stmt.startswith("FOR "):
            return self._render_for(stmt, ind, tr)
        if stmt.startswith("IF "):
            return self._render_if(stmt, ind, tr)
        if re.match(r"^log\s*\(", stmt):
            return [p + self._render_log(stmt, tr)]
        # Assignment — careful not to match == or !=
        m = re.match(r"^(\w+)\s*=(?!=)\s*(.+)$", stmt, re.DOTALL)
        if m:
            return self._render_assign(m.group(1), m.group(2).strip(), ind, tr)
        # Anything else — just translate in place
        return [p + tr.translate(stmt)]

    def _render_for(self, stmt: str, ind: int, tr: ExprTranslator) -> list:
        """Render DSL FOR-IN blocks.

        DSL form: FOR item IN iterable_expr { ... }
        Python:   for item in <translated iterable_expr>:
                      ...
        """
        p = "    " * ind
        br = stmt.find("{")
        if br == -1:
            return [p + f"# invalid FOR syntax: {stmt}"]

        end = self._block_end(stmt, br)
        header = stmt[:br].strip()
        body = stmt[br + 1 : end].strip()

        m = re.match(r"^FOR\s+([A-Za-z_]\w*)\s+IN\s+(.+)$", header, re.DOTALL)
        if not m:
            return [p + f"# invalid FOR header: {header}"]

        loop_var = m.group(1)
        iterable_expr = tr.translate(m.group(2).strip())
        lines = [f"{p}for {loop_var} in {iterable_expr}:"]
        lines += self._render_stmts(body, ind + 1, tr)
        return lines

    def _render_log(self, stmt: str, tr: ExprTranslator) -> str:
        """DSL's  log(...)  is just Python's  print(...).
        String literal arguments only get the {n}->_n brace fix.
        Everything else goes through the full expression translator."""
        m = re.match(r"^log\s*\((.*)\)$", stmt, re.DOTALL)
        if not m:
            return f"print()  # could not parse: {stmt}"
        py_args = []
        for a in self._split_args(m.group(1)):
            a = a.strip()
            if re.match(r'^["\']', a):
                py_args.append(re.sub(r"\{(\d+)\}", r"_\1", a))
            else:
                py_args.append(tr.translate(a))
        return "print(" + ", ".join(py_args) + ")"

    def _render_assign(self, var: str, expr_str: str, ind: int, tr: ExprTranslator) -> list:
        """Handle an assignment, routing it to the right memory tier.

        This is where the three-tier memory model plays out in code:

          Public variable  ->  write to prv AND mirror into graph memory
                               (so other agents can read it next pass)

          Private variable ->  write to prv only
                               UNLESS it shares a name with a graph global,
                               in which case sync to g too so routing works

          Local variable   ->  plain Python assignment, no dict involved
        """
        p = "    " * ind
        val = tr.translate(expr_str)

        if var in self.pub:
            return [
                f'{p}prv["{var}"] = {val}',
                f'{p}g[f"{{{self.id}}}_{var}"] = {val}',
            ]

        if var in self.prv:
            lines = [f'{p}prv["{var}"] = {val}']
            if var in self.glb:
                # This agent's private variable is also a graph global
                # (e.g. "round").  Keep the graph copy up to date so that
                # graph-level route conditions can read the current value.
                lines.append(f'{p}g["{var}"] = prv["{var}"]')
            return lines

        # Not in memory at all — it is a scratch variable local to this task
        return [f"{p}{var} = {val}"]

    def _render_if(self, stmt: str, ind: int, tr: ExprTranslator) -> list:
        """Render an IF / ELSE IF / ELSE chain.

        DSL blocks look like:  IF cond { ... } ELSE IF cond { ... } ELSE { ... }
        We walk through the string left to right, emitting  if / elif / else
        as we go.  The _block_end helper finds where each { } body ends so we
        know where to resume parsing after each branch."""
        p = "    " * ind
        lines = []
        rest = stmt.strip()
        kw = "if"

        while rest:
            rest = rest.strip()
            if not rest:
                break

            if rest.startswith("IF "):
                skip = 3
            elif rest.startswith("ELSE IF "):
                skip = 8
            elif re.match(r"^ELSE\s*\{", rest):
                br = rest.index("{")
                end = self._block_end(rest, br)
                lines.append(f"{p}else:")
                lines += self._render_stmts(rest[br + 1 : end].strip(), ind + 1, tr)
                rest = rest[end + 1 :].strip()
                break
            else:
                break

            br = rest.index("{")
            cond = rest[skip:br].strip()
            end = self._block_end(rest, br)
            body = rest[br + 1 : end].strip()

            lines.append(f"{p}{kw} {tr.translate(cond)}:")
            lines += self._render_stmts(body, ind + 1, tr)

            rest = rest[end + 1 :].strip()
            kw = "elif"

        return lines
