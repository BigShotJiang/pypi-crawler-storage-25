from __future__ import annotations

import re

LIBRARIES: list[str] = []

# ─────────────────────────────────────────────────────────────────────────────
# DSL keyword substitutions
#
# These are the simple word-level replacements that need to happen everywhere —
# in expressions, in route conditions, inside task bodies.  We define them once
# here and reuse them rather than repeating the same regexes in multiple places.
#
# One ordering note: the  null -> None  substitution has to happen BEFORE the
# == None -> is None  one, otherwise we would be looking for  == null  which
# would never match at that point.
# ─────────────────────────────────────────────────────────────────────────────

_KW_SUBS = [
    (r"\bAND\b", "and"),
    (r"\bOR\b", "or"),
    (r"\bNOT\b", "not"),
    (r"\bnull\b", "None"),
    # null -> None must come first, then we fix the comparison style
    (r"==\s*None", "is None"),
    (r"!=\s*None", "is not None"),
    (r"\bagentId\b", "agent_id"),
]


def _apply_kw(s: str) -> str:
    for pat, rep in _KW_SUBS:
        s = re.sub(pat, rep, s)
    s = re.sub(
        r'\b([A-Za-z_][A-Za-z0-9_\[\]\.()"\']*)\s+is\s+(int|float|string|char|list|tuple)\b',
        r"isinstance(\1, \2)",
        s,
    )
    return s


# ─────────────────────────────────────────────────────────────────────────────
# Tiny value helper
#
# The DSL stores typed values like  { "type": "string", "value": "hello" }.
# This function turns that into the right Python literal — so "hello" becomes
# '"hello"', true becomes 'True', null becomes 'None', and numbers stay as-is.
# ─────────────────────────────────────────────────────────────────────────────


def py_val(type_str: str, val_str) -> str:
    if val_str in (None, "null"):
        return "None"
    if val_str == "true":
        return "True"
    if val_str == "false":
        return "False"
    v = str(val_str)
    if type_str == "string":
        # If the value is not already wrapped in quotes, wrap it.
        if not ((v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'"))):
            return f'"{v}"'
    return v


def extract_library_names(value) -> list[str]:
    if not value:
        return []

    if isinstance(value, str):
        return [part.strip() for part in value.split(",") if part.strip()]

    if isinstance(value, (list, tuple, set)):
        names: list[str] = []
        for item in value:
            if isinstance(item, str):
                item = item.strip()
                if item:
                    names.append(item)
        return names

    return []


def agent_import_lines(agents: dict, lib_files: dict) -> list[str]:
    defined_libs = set(lib_files)
    imports: list[str] = []
    seen = set()

    for spec in agents.values():
        for lib_name in extract_library_names(spec.get("includes")):
            if lib_name in defined_libs or lib_name in seen:
                continue

            if lib_name in LIBRARIES:
                imports.append(f"from orch_lib.{lib_name} import *")
            else:
                imports.append(f"import {lib_name}")
            seen.add(lib_name)

    return imports


# ─────────────────────────────────────────────────────────────────────────────
# Figuring out what parameters a function needs
#
# The DSL gives us Python function bodies without parameter lists.  We need
# to figure out the parameters ourselves.  The approach: scan the body for
# identifiers that are *used* but never *assigned* inside it, then throw away
# anything that is a built-in, a keyword, an import, or the return variable.
# Whatever is left must be coming from outside — so those are the parameters.
#
# Example: a body that says  "result = a + b"  has 'a' and 'b' used but not
# assigned, so the function becomes  def f(a, b).
# ─────────────────────────────────────────────────────────────────────────────


def infer_params(body: str, ret_var: str = "result") -> str:
    import_mods = set(re.findall(r"\bimport\s+(\w+)", body))
    assigned = set(re.findall(r"(?m)^\s*([a-z_]\w*)\s*=", body))

    # Everything in this set we ignore — it is either a keyword, a built-in
    # function, something already assigned inside the body, or the return var.
    skip = (
        {
            "import",
            "from",
            "as",
            "if",
            "else",
            "elif",
            "for",
            "while",
            "return",
            "in",
            "not",
            "and",
            "or",
            "is",
            "pass",
            "break",
            "max",
            "min",
            "abs",
            "int",
            "float",
            "str",
            "bool",
            "list",
            "dict",
            "set",
            "tuple",
            "print",
            "len",
            "range",
            "sorted",
            "sum",
            "any",
            "all",
            "zip",
            "map",
            "filter",
            "True",
            "False",
            "None",
            ret_var,
        }
        | import_mods
        | assigned
    )

    seen, params = set(), []
    # We only want bare identifiers — not  obj.attr  and not  func()  calls.
    # The lookahead/lookbehind in the regex handles that.
    for m in re.finditer(r"(?<![.\w])([a-z_]\w*)(?![.\w(])", body):
        w = m.group(1)
        if w not in seen and w not in skip:
            params.append(w)
            seen.add(w)
    return ", ".join(params)


# ─────────────────────────────────────────────────────────────────────────────
# Route condition helpers  (agent-level and graph-level)
#
# Route conditions in the DSL are strings like  "budget > 100 AND status != null".
# These get passed to  Conditional(...)  which eval()s them at runtime.
#
# The key difference between the two levels:
#   - Inside an agent, variables live in the agent's own memory, so we
#     write  private['budget']  so the Conditional knows where to look.
#   - At the graph level, variables are the shared globals, so we write
#     public['round']  instead.
#
# We sort variables by length (longest first) before substituting so that
# a variable named "currentPrice" does not accidentally get partially replaced
# if there is also one named "current".
# ─────────────────────────────────────────────────────────────────────────────


def agent_cond(cond: str, all_mem_vars: set) -> str:
    if cond == "else":
        return "True"
    s = _apply_kw(cond)
    for v in sorted(all_mem_vars, key=len, reverse=True):
        s = re.sub(rf"\b{re.escape(v)}\b", f"private['{v}']", s)
    # Escape any remaining double quotes inside string literals
    s = s.replace('"', '\\"')
    return s


def graph_cond(cond: str, global_vars: list) -> str:
    if cond == "else":
        return "True"
    s = _apply_kw(cond)
    for v in sorted(global_vars, key=len, reverse=True):
        s = re.sub(rf"\b{re.escape(v)}\b", f"public['{v}']", s)
    return s
