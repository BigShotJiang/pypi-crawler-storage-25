from collections import ChainMap
from typing import Literal

RouteType = Literal["on_start", "on_end"]


class _ReadOnlyChainMap(ChainMap):
    def __setitem__(self, key, value):
        raise TypeError("scope is read-only")

    def __delitem__(self, key):  # pragma: no cover
        # Unreachable in eval("expr", ...) mode, but needed for defensive programming
        raise TypeError("scope is read-only")


_DSL_EVAL_NAMES = {"true": True, "false": False, "null": None}


class Conditional:
    def __init__(self, condition: str, parent=None):
        self.condition = condition
        self._code = compile(condition, "<conditional>", "eval")
        self.parent = parent

    def evaluate(self, parent=None) -> bool:
        p = parent if parent is not None else self.parent
        if p is None:
            return bool(eval(self._code, {}, _DSL_EVAL_NAMES))

        if not isinstance(p, dict):
            raise TypeError("parent must be a dict")

        return bool(eval(self._code, {}, _ReadOnlyChainMap(_DSL_EVAL_NAMES, p)))

    def __call__(self, parent=None) -> bool:
        return self.evaluate(parent)

    def __repr__(self) -> str:
        return f"Conditional({self.__dict__!r})"
