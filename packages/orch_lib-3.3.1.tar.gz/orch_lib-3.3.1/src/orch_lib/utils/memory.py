class Memory:
    def __init__(self, agents=None):
        self.memory = {}
        self.agent_mem = {agent: {} for agent in (agents or [])}

    def store(self, key, data, agent=None):
        if agent is None:
            self.memory[key] = data
        else:
            if agent not in self.agent_mem:
                self.agent_mem[agent] = {}
            self.agent_mem[agent][key] = data

    def retrieve(self, key, agent=None):
        if agent is None:
            return self.memory[key]
        else:
            return self.agent_mem[agent][key]

    def delete(self, key, agent=None):
        if agent is None:
            del self.memory[key]
        else:
            del self.agent_mem[agent][key]

    def clear_agent_memory(self, agent):
        if agent in self.agent_mem:
            self.agent_mem[agent].clear()

    def clear(self):
        self.memory.clear()
        for agent in self.agent_mem:
            self.agent_mem[agent].clear()

    def __getitem__(self, key):
        if key in self.agent_mem:
            return self.agent_mem[key]
        return self.memory[key]

    def __setitem__(self, key, value):
        if key in self.agent_mem:
            self.agent_mem[key] = value
        else:
            self.memory[key] = value

    def __delitem__(self, key):
        if key in self.agent_mem:
            del self.agent_mem[key]
        else:
            del self.memory[key]

    def __contains__(self, key) -> bool:
        return key in self.memory

    def __iter__(self):
        return iter(self.memory)

    def __len__(self) -> int:
        return len(self.memory)

    def __repr__(self) -> str:
        return f"Memory(global={self.memory!r}, agents={self.agent_mem!r})"
