"""Environment variable loading utilities."""

from pathlib import Path
from typing import Dict


def load_env(filepath: str = ".env") -> Dict[str, str]:
    """
    Load environment variables from .env file.
    Reads the .env file, parses KEY=VALUE pairs, and loads them into os.environ
    using python-dotenv. Returns a dictionary of all environment variables.
    Args:
        filepath: Path to .env file (default: ".env")
    Returns:
        Dictionary of environment variables loaded from the file
    """
    from dotenv import load_dotenv

    env_vars = {}

    # Load to os.environ using dotenv
    if Path(filepath).exists():
        load_dotenv(filepath, override=True)

        # Parse the file to get the variables
        with open(filepath, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                # Skip comments and empty lines
                if not line or line.startswith("#"):
                    continue
                # Parse KEY=VALUE format
                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()

                    # Handle inline comments (KEY=value#comment)
                    # But preserve # inside quoted strings
                    if value and value[0] in ('"', "'"):
                        quote_char = value[0]
                        # Find matching closing quote
                        closing_quote = value.find(quote_char, 1)
                        if closing_quote != -1:
                            # Extract quoted value and check for inline comment after
                            value = value[1:closing_quote]
                    else:
                        # Not quoted, strip inline comment
                        if "#" in value:
                            value = value.split("#", 1)[0].strip()

                    env_vars[key] = value

    return env_vars
