from .conditional import _ReadOnlyChainMap

_DSL_EVAL_NAMES = {"true": True, "false": False, "null": None}


class Expression:
    def __init__(self, expression: str, parent=None):
        self.expression = expression
        self._code = compile(expression, "<expression>", "eval")
        self.parent = parent

    def evaluate(self, parent=None):
        p = parent if parent is not None else self.parent
        if p is None:
            return eval(self._code, {}, _DSL_EVAL_NAMES)

        if not isinstance(p, dict):
            raise TypeError("parent must be a dict")

        return eval(self._code, {}, _ReadOnlyChainMap(_DSL_EVAL_NAMES, p))

    def __call__(self, parent=None):
        return self.evaluate(parent)

    def __repr__(self) -> str:
        return f"Expression({self.__dict__!r})"
