from collections import ChainMap
from typing import Callable, Optional


class _WriteThroughChainMap(ChainMap):
    """ChainMap that writes back to whichever map already owns the key."""

    def __setitem__(self, key, value):
        for m in self.maps:
            if key in m:
                m[key] = value
                return
        self.maps[0][key] = value

    def __delitem__(self, key):
        for m in self.maps:
            if key in m:
                del m[key]
                return
        raise KeyError(key)


class Task:
    def __init__(self, name: str, function: Callable, memories: Optional[dict] = None):
        self.name = name
        self.function = function
        self.memories = memories if memories is not None else {}

    def __call__(self, *args, extra_memories: Optional[dict] = None, **kwds):
        mem_dict = {
            "private": self.memories if self.memories is not None else {},
            "public": extra_memories if extra_memories is not None else {},
        }
        scope = _WriteThroughChainMap(mem_dict)
        if kwds:
            scope.maps.insert(0, kwds)  # kwds take read-priority without being persisted
        return self.function(*args, scope=scope)
