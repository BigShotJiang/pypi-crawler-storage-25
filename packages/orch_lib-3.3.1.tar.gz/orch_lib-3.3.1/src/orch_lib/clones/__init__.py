"""Clone utility functions for working with multi-agent state."""

from .clones import (
    count,
    find_all,
    find_first,
    max_index,
    min_index,
    my_index,
    size,
    sum,
)

__all__ = [
    "count",
    "sum",
    "max_index",
    "min_index",
    "find_first",
    "size",
    "my_index",
    "find_all",
]
