# -------------------------
# Internal helper
# -------------------------
def _get_matching_agents(g, agent_name):
    """
    Return a sorted list of agent indices based on keys like:
    WorkerAgent_1_status.
    """
    prefix = f"{agent_name}_"
    indices = set()

    for key in g.keys():
        if key.startswith(prefix):
            parts = key.split("_")
            if len(parts) >= 3:
                try:
                    indices.add(int(parts[1]))
                except (ValueError, IndexError):
                    # Ignore malformed keys
                    pass

    return sorted(indices)


# -------------------------
# 1. Aggregation
# -------------------------
def count(g, agent_name, variable, target):
    indices = _get_matching_agents(g, agent_name)

    c = 0
    for i in indices:
        if g.get(f"{agent_name}_{i}_{variable}") == target:
            c += 1

    return c


def sum(g, agent_name, variable):
    indices = _get_matching_agents(g, agent_name)

    total = 0
    for i in indices:
        val = g.get(f"{agent_name}_{i}_{variable}")
        if isinstance(val, (int, float)):
            total += val

    return total


def max_index(g, agent_name, variable):
    indices = _get_matching_agents(g, agent_name)

    best_val = None
    best_idx = -1

    for i in indices:
        val = g.get(f"{agent_name}_{i}_{variable}")
        if isinstance(val, (int, float)):
            if best_val is None or val > best_val:
                best_val = val
                best_idx = i

    return best_idx


def min_index(g, agent_name, variable):
    indices = _get_matching_agents(g, agent_name)

    best_val = None
    best_idx = -1

    for i in indices:
        val = g.get(f"{agent_name}_{i}_{variable}")
        if isinstance(val, (int, float)):
            if best_val is None or val < best_val:
                best_val = val
                best_idx = i

    return best_idx


# -------------------------
# 2. Selection
# -------------------------
def find_first(g, agent_name, variable, target):
    indices = _get_matching_agents(g, agent_name)

    for i in indices:
        if g.get(f"{agent_name}_{i}_{variable}") == target:
            return i

    return -1


# -------------------------
# 3. Introspection
# -------------------------
def size(g, agent_name):
    return len(_get_matching_agents(g, agent_name))


def my_index(agent_id):
    """
    Extract index from agent_id like "WorkerAgent_3".
    """
    try:
        return int(agent_id.split("_")[1])
    except (ValueError, IndexError):
        return -1


def find_all(g, agent_name, variable, target):
    result = []

    for i in _get_matching_agents(g, agent_name):
        if g.get(f"{agent_name}_{i}_{variable}") == target:
            result.append(i)

    return result
