"""Default handoff harness example."""
