"""Predefined handoff harness example."""
