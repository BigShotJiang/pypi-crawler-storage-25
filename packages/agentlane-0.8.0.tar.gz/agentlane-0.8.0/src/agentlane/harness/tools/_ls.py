"""Ls tool implementation placeholder."""
