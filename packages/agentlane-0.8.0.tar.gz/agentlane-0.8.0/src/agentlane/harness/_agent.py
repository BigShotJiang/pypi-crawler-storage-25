"""Default harness agent primitive."""

from collections.abc import Sequence
from typing import Any

from pydantic import BaseModel

from agentlane.messaging import AgentId, MessageContext
from agentlane.models import (
    Model,
    ModelResponse,
    OutputSchema,
    PromptSpec,
    Tools,
    ToolSpec,
)
from agentlane.runtime import CancellationToken, Engine, on_message

from ._hooks import RunnerHooks
from ._lifecycle import (
    AgentDescriptor,
    AgentLifecycle,
    DefaultHandoff,
    DefaultHandoffTool,
    HandoffTool,
)
from ._run import RunHistoryItem, RunInput, RunResult, RunState
from ._runner import Runner
from ._stream import RunStream
from ._task import Task
from ._tooling import merge_tools, resolve_tools
from .shims import Shim
from .shims._manager import BoundShimManager


class Agent(Task):
    """Default harness agent primitive.

    This phase owns resumable run lifecycle, queued run inputs, and the default
    runner entry. The runner owns tool, sub-agent, and handoff execution.
    """

    def __init__(
        self,
        engine: Engine,
        runner: Runner,
        *,
        bind_id: AgentId | None = None,
        descriptor: AgentDescriptor | None = None,
        parent_tools: Tools | None = None,
        run_state: RunState | None = None,
        hooks: RunnerHooks | Sequence[RunnerHooks] | None = None,
    ) -> None:
        """Initialize an agent bound to one runtime engine capability.

        Args:
            engine: Runtime engine messaging capability exposed to this agent.
            runner: Stateless runner responsible for each conversation turn.
            bind_id: Optional pre-bound agent id, primarily for tests.
            descriptor: Optional static agent descriptor. When omitted, the
                agent uses a default descriptor with its class name.
            parent_tools: Optional inherited parent tool configuration used
                when the descriptor leaves tool visibility unset.
            run_state: Optional recovered run state for this concrete agent
                instance. When provided, later turns continue from that exact
                resumable state instead of starting a new run.
            hooks: Optional runner hook or ordered hook list for lifecycle
                callbacks, tests, and application-defined side effects.
        """
        super().__init__(engine, bind_id=bind_id)
        self._runner = runner
        self._parent_tools = parent_tools
        self._descriptor = descriptor or AgentDescriptor(name=type(self).__name__)
        self._lifecycle = AgentLifecycle(
            descriptor=self._descriptor,
            run_state=run_state,
            hooks=hooks,
        )

    @property
    def name(self) -> str:
        """Return the human-readable agent name."""
        return self._descriptor.name

    @property
    def description(self) -> str | None:
        """Return the short agent description."""
        return self._descriptor.description

    @property
    def model(self) -> Model[ModelResponse] | None:
        """Return the canonical model client for the default runner."""
        return self._descriptor.model

    @property
    def model_args(self) -> dict[str, Any] | None:
        """Return model request arguments forwarded to the model call."""
        return self._descriptor.model_args

    @property
    def schema(self) -> type[BaseModel] | OutputSchema[Any] | None:
        """Return the structured-output schema forwarded to the model."""
        return self._descriptor.schema

    @property
    def instructions(self) -> str | PromptSpec[Any] | None:
        """Return the configured instructions source."""
        return self._descriptor.instructions

    @property
    def tools(self) -> Tools | None:
        """Return the configured tools for this agent.

        The model-visible tool set is the descriptor's explicit tool catalog
        plus declarative handoff schemas. Handoffs are exposed here because
        the model should discover them exactly like tools, but the runner
        still intercepts them with transfer semantics instead of normal tool
        execution.
        """
        base_tools = self.base_tools
        return merge_tools(base_tools, self._handoff_tools())

    @property
    def shims(self) -> Sequence[Shim] | None:
        """Return the configured shim definitions for this agent."""
        return self._descriptor.shims

    @property
    def bound_shim_manager(self) -> BoundShimManager | None:
        """Return the bound shim manager for this agent instance, if any."""
        return self._lifecycle.bound_shim_manager

    @property
    def handoffs(self) -> tuple[AgentDescriptor, ...] | None:
        """Return predefined delegated child agent descriptors."""
        return self._descriptor.handoffs

    @property
    def default_handoff(self) -> DefaultHandoff | None:
        """Return the optional generic default handoff configuration."""
        return self._descriptor.default_handoff

    def as_tool(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        args_model: type[BaseModel] | None = None,
    ) -> ToolSpec[Any]:
        """Expose this agent as declarative agent-as-tool metadata."""
        return self._descriptor.as_tool(
            name=name,
            description=description,
            args_model=args_model,
        )

    @property
    def is_running(self) -> bool:
        """Return whether the agent is currently executing a runner turn."""
        return self._lifecycle.is_running

    @property
    def pending_input_count(self) -> int:
        """Return the number of pending run inputs queued for later turns."""
        return self._lifecycle.pending_input_count

    @property
    def run_state(self) -> RunState | None:
        """Return a snapshot of the current resumable run state."""
        return self._lifecycle.run_state_snapshot()

    async def _enqueue_input(
        self,
        run_input: RunInput,
        *,
        cancellation_token: CancellationToken | None = None,
    ) -> RunResult:
        """Queue one internal run input and wait for the final result."""
        return await self._lifecycle.enqueue_input(
            agent=self,
            runner=self._runner,
            run_input=run_input,
            cancellation_token=cancellation_token,
        )

    async def enqueue_input_stream(
        self,
        run_input: RunInput,
        *,
        cancellation_token: CancellationToken | None = None,
    ) -> RunStream:
        """Queue one internal run input for live streaming."""
        return await self._lifecycle.enqueue_input_stream(
            agent=self,
            runner=self._runner,
            run_input=run_input,
            cancellation_token=cancellation_token,
        )

    @property
    def base_tools(self) -> Tools | None:
        """Resolve the descriptor's explicit tool catalog before handoff merge."""
        return resolve_tools(
            self._descriptor.tools,
            parent_tools=self._parent_tools,
        )

    def _handoff_tools(self) -> tuple[ToolSpec[Any], ...]:
        """Return declarative handoff schemas visible to the model."""
        handoff_tools: list[ToolSpec[Any]] = []

        for descriptor in self._descriptor.handoffs or ():
            handoff_tools.append(HandoffTool(descriptor=descriptor))

        if self._descriptor.default_handoff is not None:
            handoff_tools.append(
                DefaultHandoffTool(config=self._descriptor.default_handoff)
            )

        return tuple(handoff_tools)

    @on_message
    async def handle_str(self, payload: str, context: MessageContext) -> object:
        """Handle one inbound string run input."""
        _ = context
        return await self._enqueue_input(payload)

    @on_message
    async def handle_list(
        self,
        payload: list[RunHistoryItem],
        context: MessageContext,
    ) -> object:
        """Handle one inbound list-based run input."""
        _ = context
        return await self._enqueue_input(list(payload))

    @on_message
    async def handle_run_state(
        self,
        payload: RunState,
        context: MessageContext,
    ) -> object:
        """Handle one inbound resumable run state."""
        _ = context
        return await self._enqueue_input(payload)
