# CLARIX

**Clarix** is a lightweight Python debugging assistant designed to analyze and explain runtime errors in a clear, structured manner. It enhances standard Python tracebacks with improved readability and contextual insights.

---

## ✨ Features
*   **Structured Explanations:** Clear and readable error breakdowns.
*   **Precision Highlighting:** Points out the exact line causing the failure.
*   **Seamless Integration:** Works easily with existing Python scripts.
*   **CLI Support:** Command-line interface for rapid debugging.
*   **Lightweight:** Minimal dependencies for a fast, clean experience.

---

## 🚀 Installation

Install the latest version via `pip`:

```bash
pip install clarix
```

---

## 🛠 Usage

### 💻 Command Line Interface
Run Clarix directly in your terminal to analyze a script:

```bash
clarix script.py
```

### 🐍 Python API
You can use Clarix programmatically to inspect specific files:

```python
import clarix

# Run a specific test file
clarix.run("test.py")

# You can also use directory paths
clarix.run("folder/file.py")
```

### 🧪 Experimental Injection
You can inject Clarix directly into a script. 
> **Note:** This is not recommended for production, as this experimental feature cannot catch `SyntaxErrors`.

```python
import clarix
clarix.enable()
```

---

## 📊 Current Status
*   **Version:** Early development (Alpha)
*   **Core:** Core functionality implemented
*   **Updates:** Actively evolving with frequent feature additions

---

## 🗺 Roadmap
*   [ ] Advanced error classification
*   [ ] Improved traceback visualization
*   [ ] Enhanced contextual explanations
*   [ ] Expanded support for complex error types

---

## 📜 License
This project is licensed under the **MIT License**. See the [LICENSE](LICENSE) file for more details.
