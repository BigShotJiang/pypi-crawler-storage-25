# clarix/__init__.py

"""
CLARIX — Python Error Explanation Engine
========================================

Overview
--------
Clarix is a developer-focused utility designed to analyze Python exceptions
and present them in a structured, human-readable format. It enhances debugging
by transforming raw error traces into clear explanations with contextual hints.

The system is particularly useful for beginners, learners, and rapid development
environments where understanding errors efficiently is critical.

------------------------------------------------------------

Installation
------------
Install Clarix via pip:

    pip install clarix

Ensure Python version compatibility before installation.

------------------------------------------------------------

Quick Start
-----------
There are two primary ways to use Clarix:

1. Command-Line Interface (CLI)

    clarix <file.py>

Example:

    clarix test.py

This will execute the script and display formatted error output
if an exception occurs.

2. Programmatic Usage

    import clarix
    clarix.run("<folder/file.py>")
Example:

    clarix.run('My_Folder/test.py')
You may also pass file paths explicitly.

** You can also directly inject Clarix inside the test file, but generally this is not recommended, as this experimental feature can't handle Syntax-Errors :

    import clarix
    clarix.enable()

------------------------------------------------------------

Core Features
-------------
• Structured Error Display
  Errors are presented using formatted tables and panels for clarity.

• Syntax Highlighting
  Relevant code sections are displayed with visual emphasis.

• Contextual Explanation
  Provides simplified explanations of Python errors.

• File and Line Tracking
  Displays exact file name and line number where the error occurred.

• Enhanced Readability
  Uses styled output (via rich formatting) to improve debugging experience.

------------------------------------------------------------

Supported Error Types
---------------------
Clarix currently supports analysis of common Python exceptions, including:

• SyntaxError
• NameError
• TypeError
• ValueError
• IndexError
• KeyError

Support for additional error types may be added in future releases.


------------------------------------------------------------

Updating Clarix
---------------
To update to the latest version:

    pip install --upgrade clarix

Ensure your environment has internet access and appropriate permissions.

------------------------------------------------------------

Design Philosophy
-----------------
Clarix is built on the principle that debugging should be intuitive.
Instead of forcing developers to interpret dense tracebacks, the tool
acts as an interpreter layer—translating machine-level exceptions into
human-level understanding.

------------------------------------------------------------

Limitations
-----------
• Does not replace Python's native traceback system
• Complex runtime errors may still require manual inspection
• Dependent on correct environment configuration

------------------------------------------------------------

Best Practices
--------------
• Use Clarix during development, not in production pipelines
• Combine with logging for deeper debugging workflows
• Regularly update to access improved explanations

------------------------------------------------------------

Future Enhancements (Planned)
----------------------------
• Support for more exception types
• Integration with IDEs
• Auto-update notifications

------------------------------------------------------------

Author
------
Developed as an independent Python utility project.

------------------------------------------------------------

License
-------
MIT License

Copyright (c) 2026 Kane Bean

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

------------------------------------------------------------

End of Manual
-------------
"""

from .runner import run
from .core import enable, boot

__all__ = ["run", "enable", "boot"]