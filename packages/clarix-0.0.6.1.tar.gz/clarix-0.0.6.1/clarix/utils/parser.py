# clarix/utils/parser.py

import ast

def extract_function_call(code_line):
    """Parses a single line of code to find the function being called."""
    if not code_line:
        return None
        
    try:
        tree = ast.parse(code_line.strip())
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                # Handles simple calls like 'print()'
                if isinstance(node.func, ast.Name):
                    return node.func.id
                # Handles module calls like 'random.choice()'
                elif isinstance(node.func, ast.Attribute):
                    if isinstance(node.func.value, ast.Name):
                        return f"{node.func.value.id}.{node.func.attr}"
    except SyntaxError:
        return None
        
    return None
