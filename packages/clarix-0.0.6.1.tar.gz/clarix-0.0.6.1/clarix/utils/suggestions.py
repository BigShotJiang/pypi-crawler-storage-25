# clarix/utils/suggestions.py

import difflib
import builtins

def suggest_name(name):
    pool = dir(builtins)

    matches = difflib.get_close_matches(name, pool, n=1)
    return matches[0] if matches else None