# clarix/core.py

import sys
from .engine import process_exception
from .context import get_context
from .ui.rich_ui import show_runtime_error

_original_hook = sys.excepthook


def _hook(exc_type, exc_value, traceback):
    try:
        message = process_exception(exc_type, exc_value, traceback)
        ctx = get_context(traceback)

        show_runtime_error(
            message=message,
            line=ctx.get("line"),
            code=ctx.get("code"),
            filename=ctx.get("filename")
            )

    except Exception:
        _original_hook(exc_type, exc_value, traceback)


def enable():
    print("\n⚠️ Clarix enabled (runtime mode)")
    print("💡 Syntax errors require CLI: clarix <file>\n")

    sys.excepthook = _hook
    

def boot():
    """
    Executes the current script under Clarix control
    """
    import runpy

    try:
        runpy.run_path(sys.argv[0], run_name="__main__")

    except SyntaxError as e:
        print(f"""
[Notice: Future upgrade 🚧]

⚠️ Syntax Error detected
🧠 Clarix is improving syntax-level understanding.

📍 Line {e.lineno}: {e.text.strip() if e.text else ''}
🔍 Message: {e.msg}
""")

    except Exception as e:
        print(process_exception(type(e), e, e.__traceback__))
