# clarix/context.py

import linecache
import traceback

def get_context(tb):
    tb_list = traceback.extract_tb(tb)
    
    # Work backwards to find the user's code, skipping Python internal libraries
    last = None
    for frame in reversed(tb_list):
        path = frame.filename.replace('\\', '/') # Normalize for Windows/Linux
        if "lib/python" not in path and "site-packages" not in path:
            last = frame
            break
            
    # Fallback just in case everything was filtered
    if not last:
        last = tb_list[-1] if tb_list else None

    if not last:
        return {"filename": None, "line": None, "code": None}

    code = (last.line or "").strip()

    if not code and last.filename and last.lineno:
        linecache.checkcache(last.filename)
        code = linecache.getline(last.filename, last.lineno).strip()

    return {
        "filename": last.filename,
        "line": last.lineno,
        "code": code,
    }
