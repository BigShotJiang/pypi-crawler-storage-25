# clarix/engine.py

from .handlers import name_error, type_error, zero_division
from .context import get_context

def process_exception(exc_type, exc_value, tb):
    context = get_context(tb)
    name = exc_type.__name__

    if name == "NameError":
        return name_error.handle(exc_value, context)

    elif name == "TypeError":
        return type_error.handle(exc_value, context)

    elif name == "ZeroDivisionError":
        return zero_division.handle(exc_value, context)

    return f"❌ {name}: {exc_value}"
    
