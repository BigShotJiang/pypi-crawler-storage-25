# clarix/runner.py

import ast
import linecache
from pathlib import Path

from clarix.engine import process_exception
from clarix.context import get_context
from clarix.ui.rich_ui import show_syntax_error, show_runtime_error


def _syntax_check(source: str, filename: str):
    try:
        ast.parse(source, filename=filename)
        return None
    except SyntaxError as err:
        return err


def _get_code_line(path: Path, lineno: int):
    linecache.checkcache(str(path))
    return linecache.getline(str(path), lineno).rstrip()


def _run_file(path: Path):
    source = path.read_text(encoding="utf-8")

    # 🔴 Syntax phase
    err = _syntax_check(source, filename=str(path))

    if err:
        code_line = ""

        if err.lineno:
            code_line = _get_code_line(path, err.lineno)

        if not code_line and err.text:
            code_line = err.text.rstrip()

        show_syntax_error(err, path, code_line)
        return

    # 🟢 Execution phase
    try:
        code_obj = compile(source, str(path), "exec")

        globals_dict = {
            "__name__": "__main__",
            "__file__": str(path),
            "__package__": None,
        }

        exec(code_obj, globals_dict, globals_dict)

    except Exception as exc:
        tb = exc.__traceback__

        message = process_exception(type(exc), exc, tb)
        ctx = get_context(tb)

        show_runtime_error(
            message=message,
            line=ctx.get("line"),
            code=ctx.get("code"),
            filename=ctx.get("filename")
        )


def run(target):
    path = Path(target).expanduser().resolve()

    if not path.exists():
        print(f"❌ Path not found: {path}")
        return

    # 📂 If folder → run all .py files
    if path.is_dir():
        files = list(path.rglob("*.py"))

        if not files:
            print(f"⚠️ No Python files found in {path}")
            return

        for file in files:
            print(f"\n📂 Running: {file}\n")
            _run_file(file)

    # 📄 If file → run directly
    else:
        _run_file(path)