# clarix/handlers/zero_division.py

def handle(exc_value, context):
    return (
        "❌ Division by Zero\n"
        "🧠 You cannot divide a number by zero because it is undefined.\n"
    )
