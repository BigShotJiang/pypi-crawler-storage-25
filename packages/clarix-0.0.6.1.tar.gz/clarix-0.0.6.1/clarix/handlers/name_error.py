# clarix/handlers/name_error.py

# clarix/handlers/name_error.py

import re
from ..utils.suggestions import suggest_name

def handle(exc_value, context):
    msg = str(exc_value)

    match = re.search(r"name '(.+)' is not defined", msg)
    if not match:
        return f"❌ NameError: {msg}"

    var = match.group(1)
    suggestion = suggest_name(var)

    base = f"❌ Variable '{var}' is not defined."

    if suggestion:
        base += f"\n💡 Did you mean '{suggestion}'?"

    return base