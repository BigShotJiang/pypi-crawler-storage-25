# clarix/handlers/__init__.py

from . import name_error
from . import type_error
from . import zero_division

__all__ = [
    "name_error",
    "type_error",
    "zero_division",
]