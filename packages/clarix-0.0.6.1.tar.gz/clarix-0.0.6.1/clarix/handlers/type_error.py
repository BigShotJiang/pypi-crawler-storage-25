# clarix/handlers/type_error.py

from clarix.utils.parser import extract_function_call
from clarix.docs.engine import fetch_documentation

def handle(exc_value, context):
    msg = str(exc_value)
    
    # 1. Extract function call from the user's buggy line
    func_name = extract_function_call(context.get("code"))
    docs_snippet = ""
    explanation = ""

    # Fetch docs and signature if we identified a function
    if func_name:
        sig, docs = fetch_documentation(func_name)
        
        if sig or docs:
            # Format the exact syntax in green
            syntax_line = f"[bold green]{func_name}{sig}[/]" if sig else f"[bold green]{func_name}()[/]"
            
            # Grab just the first 3 lines of the docstring to keep it uncluttered
            short_docs = "\n".join(docs.split("\n")[:3]) if docs else "No description available."
            
            docs_snippet = (
                f"\n\n📚 [bold cyan]Syntax & Docs:[/]\n"
                f"🛠️  {syntax_line}\n"
                f"[dim]{short_docs}...[/]"
            )

    # 2. Determine the most accurate explanation
    if "unsupported operand" in msg:
        explanation = "You tried an operation between incompatible types (e.g., string + int)."
        
    elif "positional argument" in msg or "given" in msg or "takes" in msg:
        if func_name:
            explanation = f"You passed the wrong number of arguments to `{func_name}()`."
        else:
            explanation = "You passed the wrong number of arguments to a function."
            
    elif "cannot be interpreted as" in msg or "must be" in msg:
        if func_name:
            explanation = f"You passed the wrong data type to `{func_name}()`."
        else:
            explanation = "You provided a data type that the operation cannot understand."
            
    else:
        explanation = "You have a type mismatch in your code."

    return (
        f"❌ Type Error\n"
        f"🧠 {explanation}\n"
        f"⚠️ {msg}{docs_snippet}"
    )
