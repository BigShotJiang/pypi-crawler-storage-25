# clarix/ui/rich_ui.py

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.syntax import Syntax
from rich.table import Table
from rich.box import ROUNDED
from rich.text import Text


console = Console()


# =========================================================
# 🧩 CORE UI HELPERS (NEW DESIGN SYSTEM)
# =========================================================

def _make_table(headers, rows, header_style="bold cyan"):
    table = Table(
        box=ROUNDED,
        expand=True,
        row_styles=["cyan", "purple"]
    )

    for h in headers:
        table.add_column(h, style=header_style)

    for row in rows:
        table.add_row(*[str(r) for r in row])

    return table


def _render_panel(title, content, border="white"):
    console.print(
        Panel(
            content,
            title=title,
            border_style=border,
            padding=(1, 2)
        )
    )


# =========================================================
# 🔴 SYNTAX ERROR
# =========================================================

def show_syntax_error(err, path, code_line):
    title = Text("⚠️ CLARIX SYNTAX ERROR", style="bold yellow")

    table = _make_table(
        ["Field", "Value"],
        [
            ["File", path],
            ["Line", err.lineno],
            ["Error", err.msg],
        ],
        header_style="bold cyan"
    )

    syntax = Syntax(
        code_line,
        "python",
        theme="monokai",
        line_numbers=False
    )

    insight = Text(
        "This error occurs before execution (parsing stage).\n"
        "Likely causes: typo, missing operator, invalid syntax.",
        style="italic dim"
    )

    _render_panel(title, table, border="yellow")
    console.print("\n💻 Buggy Line:\n", syntax)
    console.print(insight)


# =========================================================
# 🔴 RUNTIME ERROR
# =========================================================

def show_runtime_error(message, line=None, code=None, filename=None):
    title = Text("❌ CLARIX RUNTIME ERROR", style="bold red")

    # 📂 Info Table (with zebra striping)
    table = Table(
        box=ROUNDED,
        expand=True,
        row_styles=["cyan", "purple"]  # ← zebra stripes
    )
    table.add_column("Field", style="bold magenta")
    table.add_column("Value", style="white")

    if filename:
        table.add_row("File", str(filename))
    if line:
        table.add_row("Line", str(line))

    # 💻 Code Highlight
    syntax_block = None
    if code:
        syntax_block = Syntax(
            code,
            "python",
            theme="monokai",
            line_numbers=False
        )

    message_text = Text.from_markup(message)
    # Apply a default bold style, but allow the markup tags to override it
    message_text.stylize("bold")

    panel = Panel(
        table,
        title=title,
        border_style="red",
        padding=(1, 2)
    )

    console.print(panel)
    console.print("\n🧠 Explanation:\n")
    console.print(message_text) # Print the text object directly

    if syntax_block:
        console.print("\n💻 Buggy Line:\n", syntax_block)
