# clarix/docs/engine.py

import importlib
import inspect

def fetch_documentation(func_name: str):
    """Attempts to find and return the signature and docstring for a given function."""
    if not func_name:
        return None, None

    try:
        parts = func_name.split('.')
        func = None
        
        # Handle Built-ins (e.g., 'print', 'len')
        if len(parts) == 1:
            builtin_dict = __builtins__ if isinstance(__builtins__, dict) else __builtins__.__dict__
            func = builtin_dict.get(parts[0])

        # Handle Module functions OR Object Methods (e.g., 'random.choice' or 'text.replace')
        elif len(parts) >= 2:
            obj_name = parts[-2]
            method_name = parts[-1]
            
            try:
            
                module_path = ".".join(parts[:-1])
                module = importlib.import_module(module_path)
                func = getattr(module, method_name)
            except (ImportError, AttributeError):
                common_types = (str, list, dict, set, tuple, bytes, int, float)
                for builtin_type in common_types:
                    if hasattr(builtin_type, method_name):
                        func = getattr(builtin_type, method_name)
                        break 
                
        if func:
            # Try to get the signature
            try:
                sig = str(inspect.signature(func))
            except ValueError:
                sig = "(...)" 
                
            # Get the docstring
            doc = inspect.getdoc(func)
            
            return sig, doc
            
    except Exception:
        return None, None
        
    return None, None
