# clarix/cli.py

import sys
from clarix.runner import run


def main():
    if len(sys.argv) < 2:
        print("Usage: clarix <file_or_folder>")
        sys.exit(1)

    run(sys.argv[1])


if __name__ == "__main__":
    main()