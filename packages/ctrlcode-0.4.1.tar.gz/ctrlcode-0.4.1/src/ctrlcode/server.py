"""JSON-RPC server for ctrl-code harness."""

import json
import logging
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional

from aiohttp import web
from harnessutils.config import HarnessConfig

from .config import Config
from .paths import get_data_dir
from .providers.anthropic import AnthropicProvider
from .providers.openai import OpenAIProvider
from .providers.base import Provider
from .session.manager import SessionManager
from .session.models import ReactConfig
from .tools.registry import ToolRegistry
from .tools.executor import ToolExecutor
from .tools import (
    setup_explore_tools,
    setup_todo_tools,
    setup_bash_tools,
    setup_webfetch_tools,
    setup_update_tools,
    setup_observability_tools,
)
from .skills.loader import SkillLoader
from .skills.registry import SkillRegistry

logger = logging.getLogger(__name__)


class HarnessServer:
    """JSON-RPC server for coding harness."""

    def __init__(self, config: Config):
        """
        Initialize harness server.

        Args:
            config: Server configuration
        """
        self.config = config
        self.api_key = config.server.api_key
        self.app = web.Application()
        self.app.router.add_post("/rpc", self.handle_rpc)
        self.app.router.add_get("/metrics/tech-debt", self.serve_tech_debt_dashboard)

        # Add startup/shutdown handlers
        self.app.on_startup.append(self._startup)
        self.app.on_shutdown.append(self._shutdown)

        # Initialize providers
        self.providers: dict[str, Provider] = {}
        if config.anthropic:
            self.providers["anthropic"] = AnthropicProvider(  # type: ignore[assignment]
                api_key=config.anthropic.api_key,
                model=config.anthropic.model,
                base_url=config.anthropic.base_url
            )
        if config.openai:
            self.providers["openai"] = OpenAIProvider(  # type: ignore[assignment]
                api_key=config.openai.api_key,
                model=config.openai.model,
                base_url=config.openai.base_url
            )

        if not self.providers:
            raise ValueError("No providers configured. Set ANTHROPIC_API_KEY or OPENAI_API_KEY")

        # Default provider (prefer Anthropic)
        default_provider = self.providers.get("anthropic") or self.providers.get("openai")
        assert default_provider is not None, "At least one provider must be configured"


        # Initialize tool registry
        self.tool_registry = ToolRegistry()

        # Initialize permission manager before executor so it can be wired in
        from .permissions import PermissionManager, set_permission_manager
        self.permission_manager = PermissionManager(
            approval_callback=self._send_permission_request,
            extra_safe_commands=config.permissions.safe_commands,
        )
        set_permission_manager(self.permission_manager)

        self.tool_executor = ToolExecutor(self.tool_registry, permission_manager=self.permission_manager)
        self._permission_stream: Optional[web.StreamResponse] = None

        # Initialize checkpoint manager
        from .checkpoint import CheckpointManager, set_checkpoint_manager
        self.checkpoint_manager = CheckpointManager()
        set_checkpoint_manager(self.checkpoint_manager)

        # Register built-in explore tools
        workspace_root = config.workspace_root or Path.cwd()
        setup_explore_tools(self.tool_registry, workspace_root)
        logger.info(f"Registered explore tools with workspace: {workspace_root}")

        # Register built-in todo tools
        data_dir = get_data_dir()
        setup_todo_tools(self.tool_registry, data_dir, workspace_root=workspace_root)
        logger.info(f"Registered todo tools with data dir: {data_dir}")

        # Register built-in bash tools
        setup_bash_tools(self.tool_registry, workspace_root)
        logger.info("Registered bash tools")

        # Register built-in web fetch tools
        setup_webfetch_tools(self.tool_registry)
        logger.info("Registered web fetch tools")

        # Register built-in update file tools
        setup_update_tools(self.tool_registry, workspace_root)
        logger.info("Registered update file tools")

        # Register built-in observability tools
        log_dir = get_data_dir() / "logs"
        setup_observability_tools(self.tool_registry, log_dir)
        logger.info(f"Registered observability tools with log dir: {log_dir}")

        # Initialize skill registry
        self.skill_registry = SkillRegistry()
        self._load_skills(config)

        # Initialize tech debt metrics
        from .metrics import TechDebtMetrics
        metrics_dir = get_data_dir() / "metrics"
        self.tech_debt_metrics = TechDebtMetrics(metrics_dir, project_path=workspace_root)
        logger.info(f"Initialized tech debt metrics at: {metrics_dir} for project: {workspace_root}")

        # Initialize session manager
        harness_config = HarnessConfig()  # Uses default config
        self.session_manager = SessionManager(
            provider=default_provider,
            config=harness_config,
            tool_executor=self.tool_executor,
            tool_registry=self.tool_registry,
            skill_registry=self.skill_registry,
            context_limit=config.context.default_limit,
            workspace_root=workspace_root,
            react_config=ReactConfig(max_output_tokens=config.context.max_output_tokens),
        )

        # Opt-in trajectory capture
        if config.trajectories.enabled:
            from .session.middleware import TrajectoryMiddleware
            traj_dir = Path(config.trajectories.dir)
            if not traj_dir.is_absolute():
                traj_dir = workspace_root / traj_dir
            self.session_manager._mw_stack._middlewares.append(TrajectoryMiddleware(traj_dir))
            logger.info(f"Trajectory capture enabled → {traj_dir}")


        # Security: rate limiting (requests per session)
        self._rate_limit_requests: dict[str, list[float]] = defaultdict(list)
        self._rate_limit_enabled = config.security.rate_limit_enabled
        self._rate_limit_window = config.security.rate_limit_window_seconds
        self._rate_limit_max_requests = config.security.rate_limit_max_requests
        self._max_input_length = config.security.max_input_length

        logger.info(f"Initialized with providers: {list(self.providers.keys())}")

    def _load_skills(self, config: Config) -> None:
        """Load built-in, global, project-local, and config-override skills."""
        import platformdirs
        from pathlib import Path

        # Load built-in skills (lowest precedence)
        builtin_dir = Path(__file__).parent / "skills" / "builtin"
        loader = SkillLoader(builtin_dir)
        builtin_skills = loader.load_all(source="builtin")
        self.skill_registry.register_all(builtin_skills)
        logger.info(f"Loaded {len(builtin_skills)} built-in skills")

        # Load global skills (~/.config/ctrlcode/skills/)
        global_skills_dir = Path(platformdirs.user_config_dir("ctrlcode")) / "skills"
        if global_skills_dir.exists():
            global_loader = SkillLoader(global_skills_dir)
            global_skills = global_loader.load_all(source="global")
            self.skill_registry.register_all(global_skills)
            logger.info(f"Loaded {len(global_skills)} global skills from {global_skills_dir}")

        # Load project-local skills ({workspace_root}/.ctrlcode/skills/)
        workspace_root = config.workspace_root or Path.cwd()
        project_skills_dir = workspace_root / ".ctrlcode" / "skills"
        if project_skills_dir.exists():
            project_loader = SkillLoader(project_skills_dir)
            project_skills = project_loader.load_all(source="project")
            self.skill_registry.register_all(project_skills)
            logger.info(f"Loaded {len(project_skills)} project skills from {project_skills_dir}")

        # Load config-override skills (highest precedence)
        if config.skills_directory:
            config.skills_directory.mkdir(parents=True, exist_ok=True)
        if config.skills_directory and config.skills_directory.exists():
            user_loader = SkillLoader(config.skills_directory)
            user_skills = user_loader.load_all(source="config")
            self.skill_registry.register_all(user_skills)
            logger.info(f"Loaded {len(user_skills)} config-override skills")

    async def _startup(self, app: web.Application) -> None:
        """Run DB migrations then initialize MCP servers."""
        await self._run_db_migrations()

        for server_config in self.config.mcp_servers:
            # Security: log MCP server command for audit trail
            logger.info(
                f"Starting MCP server '{server_config.name}' with command: {' '.join(server_config.command)}"
            )
            config_dict = {
                "name": server_config.name,
                "command": server_config.command,
                "env": server_config.env,
            }
            await self.tool_registry.add_server(config_dict)

        tools = self.tool_registry.list_tools()
        builtin_count = len(self.tool_registry.builtin_tools)
        mcp_count = len(self.tool_registry.mcp_tools)
        logger.info(f"Initialized {len(tools)} total tools ({builtin_count} built-in, {mcp_count} from MCP)")

    async def _run_db_migrations(self) -> None:
        """Run pending schema migrations against rootset.db before accepting requests."""
        import aiosqlite
        from .memory.migrations import run_migrations, SchemaMigrationError
        from .memory.store import _DDL

        workspace_root = self.config.workspace_root or Path.cwd()
        db_path = workspace_root / ".ctrlcode" / "rootset.db"
        db_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            async with aiosqlite.connect(str(db_path)) as db:
                await db.executescript(_DDL)
                await db.commit()
                await run_migrations(db)
            logger.info("DB schema migrations complete: %s", db_path)
        except SchemaMigrationError as exc:
            logger.error("DB schema migration failed, aborting startup: %s", exc)
            raise

    async def _shutdown(self, app: web.Application) -> None:
        """Close MCP servers on shutdown."""
        await self.tool_registry.close_all()
        await self.session_manager.close()
        logger.info("Closed all MCP servers")

    async def handle_rpc(self, request: web.Request) -> web.StreamResponse:
        """Handle JSON-RPC requests."""
        # Validate API key
        if not self._validate_api_key(request):
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32000, "message": "Unauthorized - invalid or missing API key"},
                "id": None
            }, status=401)

        try:
            data = await request.json()
        except json.JSONDecodeError:
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32700, "message": "Parse error"},
                "id": None
            }, status=400)

        method = data.get("method")
        params = data.get("params", {})
        request_id = data.get("id")

        logger.info(f"RPC call: {method}")

        try:
            if method == "session.create":
                result = await self.create_session(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "turn.process":
                # Streaming response
                return await self.process_turn(request, params, request_id)

            elif method == "session.baseline":
                result = await self.get_baseline(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "session.stats":
                result = await self.get_stats(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "session.compact":
                result = await self.compact_session(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "session.clear":
                result = await self.clear_session(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "session.get_history":
                result = await self.get_session_history(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "session.get_history_metrics":
                result = await self.get_history_metrics(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "tool.call":
                result = await self.call_tool(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "workflow.execute":
                # Streaming response for multi-agent workflow
                return await self.execute_workflow(params, request, request_id)

            elif method == "permission.response":
                result = await self.handle_permission_response(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "permission.set_accept_all":
                result = await self.handle_set_accept_all(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "checkpoint.response":
                result = await self.handle_checkpoint_response_rpc(params)
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": result
                })

            elif method == "skills.list":
                skills = [
                    {"name": s.name, "description": s.description}
                    for s in self.skill_registry.list_skills()
                ]
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": {"skills": skills}
                })

            elif method == "ping":
                return web.json_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": {"status": "alive"}
                })

            else:
                return web.json_response({
                    "jsonrpc": "2.0",
                    "error": {"code": -32601, "message": "Method not found"},
                    "id": request_id
                }, status=404)

        except Exception as e:
            logger.error(f"Error handling {method}: {e}", exc_info=True)
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32603, "message": str(e)},
                "id": request_id
            }, status=500)

    async def create_session(self, params: dict[str, Any]) -> dict[str, Any]:
        """Create a new session, or resume an existing one if resume_session_id is given."""
        provider_name = params.get("provider")
        provider = None

        if provider_name and provider_name in self.providers:
            provider = self.providers[provider_name]

        resume_id = params.get("resume_session_id")
        session = None
        if resume_id:
            session = self.session_manager.resume_session(resume_id, provider=provider)
            if session:
                logger.info(f"Resumed session {resume_id}")
        elif params.get("resume_last"):
            for candidate in self.session_manager._store.get_recent_session_ids():
                session = self.session_manager.resume_session(candidate, provider=provider)
                if session:
                    resume_id = candidate
                    logger.info(f"Resumed last valid session {resume_id}")
                    break

        if session is None:
            session = self.session_manager.create_session(provider=provider)

        # Reset accept_all on every new (non-resumed) session so stale state
        # from a previous TUI session doesn't silently skip permission prompts.
        if not resume_id:
            self.permission_manager.set_accept_all(False)

        # Get context limits from config
        context_limit = self.config.context.default_limit if self.config.context else 200000

        # Get sessions directory path for TUI logging
        sessions_dir = get_data_dir() / "sessions"
        sessions_dir.mkdir(parents=True, exist_ok=True)

        # Draws from Session public fields (id) + server-level config.
        # Do NOT add session.conv_id or session.provider here — those are private fields.
        return {
            "session_id": session.id,
            "resumed": bool(resume_id and session.id == resume_id),
            "provider": session.provider.__class__.__name__,
            "context_limit": context_limit,
            "max_input_length": self._max_input_length,
            "sessions_dir": str(sessions_dir),
            "accept_all": self.permission_manager.accept_all,
        }

    async def _send_permission_request(self, request_id: str, permission_request) -> None:
        """Send permission request to TUI via stream.

        Args:
            request_id: Unique request ID
            permission_request: PermissionRequest object
        """
        if not self._permission_stream:
            logger.error("No active permission stream")
            return

        import json
        event = {
            "type": "permission_request",
            "request_id": request_id,
            "operation": permission_request.operation,
            "path": permission_request.path,
            "reason": permission_request.reason,
            "details": permission_request.details or {}
        }

        await self._permission_stream.write(
            (json.dumps(event) + "\n").encode("utf-8")
        )

    def _validate_api_key(self, request: web.Request) -> bool:
        """
        Validate API key from request Authorization header.

        Args:
            request: aiohttp request object

        Returns:
            True if API key is valid, False otherwise
        """
        # Get Authorization header
        auth_header = request.headers.get("Authorization", "")

        # Check Bearer token format
        if not auth_header.startswith("Bearer "):
            return False

        # Extract token
        provided_key = auth_header[7:]  # Remove "Bearer " prefix

        # If no API key configured, allow all requests (backward compatibility)
        if not self.api_key:
            return True

        # Constant-time comparison to prevent timing attacks
        import hmac
        return hmac.compare_digest(provided_key, self.api_key)

    def _sanitize_user_input(self, user_input: str) -> tuple[str, str | None]:
        """
        Sanitize and validate user input.

        Args:
            user_input: Raw user input string

        Returns:
            Tuple of (sanitized_input, error_message)
            If error_message is not None, input is invalid
        """
        # Length validation (from config, -1 = unlimited)
        if self._max_input_length > 0 and len(user_input) > self._max_input_length:
            return "", f"Input exceeds maximum length of {self._max_input_length} characters"

        # Remove null bytes (security risk)
        if "\x00" in user_input:
            return "", "Input contains null bytes"

        # Remove other control characters except newlines/tabs
        sanitized = "".join(
            char for char in user_input
            if char == "\n" or char == "\t" or (ord(char) >= 32 and ord(char) != 127)
        )

        # Detect potential prompt injection patterns
        suspicious_patterns = [
            "ignore previous instructions",
            "disregard all",
            "new instructions:",
            "system:",
            "<|endoftext|>",
            "<|im_start|>",
            "<|im_end|>",
        ]

        lower_input = sanitized.lower()
        for pattern in suspicious_patterns:
            if pattern in lower_input:
                logger.warning(f"Suspicious input pattern detected: {pattern}")
                # Don't block, just log - could be legitimate discussion

        return sanitized, None

    def _check_rate_limit(self, session_id: str) -> bool:
        """
        Check if request is within rate limit for session.

        Args:
            session_id: Session identifier

        Returns:
            True if within rate limit, False if exceeded
        """
        # Skip if rate limiting disabled
        if not self._rate_limit_enabled:
            return True

        now = time.time()

        # Get request history for this session
        requests = self._rate_limit_requests[session_id]

        # Remove requests outside the time window
        requests[:] = [req_time for req_time in requests if now - req_time < self._rate_limit_window]

        # Check if limit exceeded
        if len(requests) >= self._rate_limit_max_requests:
            logger.warning(
                f"Rate limit exceeded for session {session_id}: "
                f"{len(requests)} requests in {self._rate_limit_window}s"
            )
            return False

        # Add current request
        requests.append(now)
        return True

    async def process_turn(
        self,
        request: web.Request,
        params: dict[str, Any],
        request_id: Any
    ) -> web.StreamResponse:
        """Process conversation turn with streaming."""
        session_id = params.get("session_id")
        user_input = params.get("input")
        tools = params.get("tools")

        if not session_id or not user_input:
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32602, "message": "Invalid params"},
                "id": request_id
            }, status=400)

        # Security: check rate limit
        if not self._check_rate_limit(session_id):
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32602, "message": "Rate limit exceeded. Please wait before sending more requests."},
                "id": request_id
            }, status=429)

        # Security: sanitize user input
        sanitized_input, error = self._sanitize_user_input(user_input)
        if error:
            logger.warning(f"Input validation failed: {error}")
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32602, "message": f"Invalid input: {error}"},
                "id": request_id
            }, status=400)

        # Use sanitized input instead of raw input
        user_input = sanitized_input

        # Stream response as newline-delimited JSON
        response = web.StreamResponse()
        response.headers['Content-Type'] = 'application/x-ndjson'
        await response.prepare(request)

        # Set permission stream for this request
        self._permission_stream = response

        try:
            async for event in self.session_manager.process_turn(
                session_id=session_id,
                user_input=user_input,
                tools=tools
            ):
                # Send event as NDJSON
                line = json.dumps(event.to_dict()) + "\n"
                try:
                    await response.write(line.encode())
                    # aiohttp auto-flushes after each write
                except (ConnectionResetError, ConnectionError) as e:
                    logger.info(f"Client disconnected during streaming: {e}")
                    break  # Stop streaming, client is gone

        except Exception as e:
            logger.error(f"Error processing turn: {e}", exc_info=True)
            error_event = {"type": "request_error", "data": {"error": str(e)}}
            try:
                await response.write((json.dumps(error_event) + "\n").encode())
            except (ConnectionResetError, ConnectionError):
                logger.info("Client disconnected, cannot send error event")

        finally:
            # Clear permission stream and cancel any pending permission requests.
            # This unblocks request_permission_async coroutines that are still
            # awaiting user input, causing CancelledError to propagate up and
            # stop the agent loop — prevents silent denials when client disconnects.
            self._permission_stream = None
            self.permission_manager.cancel_all_pending()

        await response.write_eof()
        return response

    async def get_baseline(self, params: dict[str, Any]) -> dict[str, Any]:
        """Get baseline for session."""
        session_id = params.get("session_id")

        if not session_id:
            raise ValueError("session_id required")

        baseline = self.session_manager.get_baseline(session_id)

        if baseline:
            return {
                "code": baseline.code,
                "file_path": baseline.file_path,
                "language": baseline.language
            }

        return {"code": None}

    async def get_stats(self, params: dict[str, Any]) -> dict[str, Any]:
        """Get conversation statistics."""
        session_id = params.get("session_id")

        if not session_id:
            raise ValueError("session_id required")

        return self.session_manager.get_context_stats(session_id)

    async def get_session_history(self, params: dict[str, Any]) -> dict[str, Any]:
        """Return conversation messages for a session, filtered to user/assistant text only."""
        session_id = params.get("session_id")
        if not session_id:
            raise ValueError("session_id required")
        if not self.session_manager.get_session(session_id):
            raise ValueError(f"Session not found: {session_id}")
        messages = self.session_manager.get_session_messages(session_id)
        turns = []
        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            # Extract plain text from content
            if isinstance(content, str):
                text = content
            elif isinstance(content, list):
                text = "\n".join(
                    b.get("text", "") for b in content
                    if isinstance(b, dict) and b.get("type") == "text"
                )
            else:
                text = ""
            if not text:
                continue
            # Skip internal system injections and tool results
            if role == "user" and (text.startswith("[Tool:") or text.startswith("[System:")):
                continue
            turns.append({"role": role, "text": text})
        return {"turns": turns}

    async def compact_session(self, params: dict[str, Any]) -> dict[str, Any]:
        """Compact conversation history."""
        session_id = params.get("session_id")

        if not session_id:
            raise ValueError("session_id required")

        self.session_manager.compact_conversation(session_id)

        return {"success": True}

    async def clear_session(self, params: dict[str, Any]) -> dict[str, Any]:
        """Clear conversation history."""
        session_id = params.get("session_id")

        if not session_id:
            raise ValueError("session_id required")

        self.session_manager.clear_conversation(session_id)

        return {"success": True}

    async def get_history_metrics(self, params: dict[str, Any]) -> dict[str, Any]:
        """Get historical learning metrics."""
        return {"enabled": False, "total_sessions": 0}

    async def handle_permission_response(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle permission response from TUI.

        Args:
            params: {request_id: str, approved: bool, accept_all: bool, context: str | None}

        Returns:
            Success status
        """
        request_id = params.get("request_id")
        if not request_id:
            raise ValueError("request_id required")

        from .permissions import get_permission_manager, PermissionResponse

        response = PermissionResponse(
            approved=params.get("approved", False),
            accept_all=params.get("accept_all", False),
            context=params.get("context"),
        )

        manager = get_permission_manager()
        if manager:
            prev_accept_all = manager.accept_all
            manager.handle_permission_response(request_id, response)
            # Emit accept_all_changed if state flipped
            if manager.accept_all != prev_accept_all:
                await self._emit_accept_all_changed(manager.accept_all)
        else:
            logger.warning(f"No permission manager to handle response for {request_id}")

        return {"success": True}

    async def handle_set_accept_all(self, params: dict[str, Any]) -> dict[str, Any]:
        """Toggle accept-all mode.

        Args:
            params: {value: bool}

        Returns:
            Success status
        """
        value = params.get("value", False)
        self.permission_manager.set_accept_all(value)
        await self._emit_accept_all_changed(value)
        return {"success": True, "accept_all": value}

    async def _emit_accept_all_changed(self, value: bool) -> None:
        """Emit accept_all_changed event to the active stream."""
        if not self._permission_stream:
            return
        event = {"type": "accept_all_changed", "data": {"accept_all": value}}
        try:
            await self._permission_stream.write((json.dumps(event) + "\n").encode("utf-8"))
        except Exception as e:
            logger.warning(f"Failed to emit accept_all_changed: {e}")

    async def handle_checkpoint_response_rpc(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle checkpoint response from TUI.

        Args:
            params: {checkpoint_id: str, action: "continue"|"abort"}

        Returns:
            Success status
        """
        checkpoint_id = params.get("checkpoint_id")
        action = params.get("action", "continue")

        if not checkpoint_id:
            raise ValueError("checkpoint_id required")

        self.checkpoint_manager.handle_checkpoint_response(checkpoint_id, action)

        return {"success": True}

    async def call_tool(self, params: dict[str, Any]) -> dict[str, Any]:
        """Call a tool directly."""
        session_id = params.get("session_id")
        tool_name = params.get("tool_name")
        tool_input = params.get("tool_input", {})

        if not session_id:
            raise ValueError("session_id required")
        if not tool_name:
            raise ValueError("tool_name required")

        # Execute tool via tool executor
        import uuid
        call_id = str(uuid.uuid4())
        result = await self.tool_executor.execute(tool_name, tool_input, call_id)

        # Return the result from the tool call
        if result.success:
            return result.result
        else:
            raise ValueError(result.error or "Tool execution failed")

    async def execute_workflow(
        self,
        params: dict[str, Any],
        request: web.Request,
        request_id: str | None
    ) -> web.StreamResponse:
        """
        Execute multi-agent workflow with streaming events.

        Args:
            params: Request parameters containing 'intent'
            request: HTTP request object
            request_id: JSON-RPC request ID

        Returns:
            Streaming NDJSON response
        """
        user_intent = params.get("intent")
        if not user_intent:
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32602, "message": "intent parameter required"},
                "id": request_id
            }, status=400)

        # Security: sanitize user intent
        sanitized_intent, error = self._sanitize_user_input(user_intent)
        if error:
            logger.warning(f"Workflow intent validation failed: {error}")
            return web.json_response({
                "jsonrpc": "2.0",
                "error": {"code": -32602, "message": f"Invalid intent: {error}"},
                "id": request_id
            }, status=400)

        # Use sanitized intent
        user_intent = sanitized_intent

        # Create streaming response
        response = web.StreamResponse()
        response.headers['Content-Type'] = 'application/x-ndjson'
        await response.prepare(request)

        try:
            # Import workflow components
            from .agents.workflow import WorkflowOrchestrator
            from .agents.registry import AgentRegistry

            # Create agent registry
            workspace_root = self.config.workspace_root or Path.cwd()
            agent_registry = AgentRegistry(
                workspace_root=workspace_root,
                tool_registry=self.tool_registry
            )

            # Create workflow event callback
            async def workflow_event_callback(event_type: str, data: dict):
                event = {"type": event_type, "data": data}
                line = json.dumps(event) + "\n"
                await response.write(line.encode())

            # Create checkpoint callback — emits event then blocks on user response
            async def workflow_checkpoint_callback(checkpoint_id: str) -> bool:
                return await self.checkpoint_manager.request_checkpoint(checkpoint_id)

            # Get provider
            provider = self.providers.get("anthropic") or self.providers.get("openai")
            if not provider:
                raise ValueError("No provider available")

            # Create orchestrator
            orchestrator = WorkflowOrchestrator(
                agent_registry=agent_registry,
                storage_path=get_data_dir() / "agents",
                provider=provider,
                tool_registry=self.tool_registry,
                event_callback=workflow_event_callback,
                checkpoint_callback=workflow_checkpoint_callback,
            )

            # Execute workflow
            result = await orchestrator.handle_user_request(user_intent)

            # Send final result event
            final_event = {"type": "workflow_complete", "data": result}
            await response.write((json.dumps(final_event) + "\n").encode())

        except Exception as e:
            logger.error(f"Workflow execution failed: {e}", exc_info=True)
            error_event = {"type": "workflow_error", "data": {"error": str(e)}}
            await response.write((json.dumps(error_event) + "\n").encode())

        await response.write_eof()
        return response

    async def serve_tech_debt_dashboard(self, request: web.Request) -> web.Response:
        """
        Serve tech debt dashboard HTML.

        Args:
            request: HTTP request

        Returns:
            HTML response with dashboard
        """
        try:
            html = self.tech_debt_metrics.generate_dashboard_html()
            return web.Response(text=html, content_type="text/html")
        except Exception as e:
            logger.error(f"Failed to generate dashboard: {e}", exc_info=True)
            return web.Response(
                text=f"<html><body><h1>Error generating dashboard</h1><p>{e}</p></body></html>",
                content_type="text/html",
                status=500
            )

    def run(self):
        """Run the server."""
        logger.info(f"Starting server on {self.config.server.host}:{self.config.server.port}")
        web.run_app(
            self.app,
            host=self.config.server.host,
            port=self.config.server.port,
            print=None  # Suppress default startup message
        )


def main():
    """Entry point for server."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    from ctrlcode.setup import needs_setup, run_setup
    if needs_setup():
        if not run_setup():
            sys.exit(1)

    config = Config.load()
    server = HarnessServer(config)
    server.run()


if __name__ == "__main__":
    main()
