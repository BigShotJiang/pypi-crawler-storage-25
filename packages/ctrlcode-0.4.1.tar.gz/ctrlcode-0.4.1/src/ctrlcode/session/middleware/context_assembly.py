"""ContextAssemblyMiddleware — build the per-turn system prompt."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .base import BaseMiddleware, TurnContext
from ..system_prompt import build_system_prompt

logger = logging.getLogger(__name__)


class ContextAssemblyMiddleware(BaseMiddleware):
    """Build the system prompt message before each turn.

    Responsibilities:
    - ``before_turn``: call ``build_system_prompt`` using the ``assembler``
      stored in ``ctx.extra`` by ``MemoryMiddleware``, then store the result
      in ``ctx.system_prompt_msg`` so ``process_turn`` can inject it into
      the conversation.

    Must be registered AFTER ``MemoryMiddleware`` so that
    ``ctx.extra["assembler"]`` is already populated.
    """

    def __init__(
        self,
        base_prompt: str,
        agent_instructions: str,
        verification_commands: list[str],
        ctrlcode_dir: Path,
        workspace_root: Optional[Path],
        context_limit: int,
        skill_registry=None,
    ) -> None:
        self._base_prompt = base_prompt
        self._agent_instructions = agent_instructions
        self._verification_commands = verification_commands
        self._ctrlcode_dir = ctrlcode_dir
        self._workspace_root = workspace_root
        self._context_limit = context_limit
        self._skill_registry = skill_registry

    async def before_turn(self, ctx: TurnContext) -> None:
        assembler = ctx.extra.get("assembler")
        if assembler is None:
            logger.warning("ContextAssemblyMiddleware: no assembler in ctx.extra; skipping system prompt build")
            return

        try:
            ctx.system_prompt_msg = await build_system_prompt(
                base_prompt=self._base_prompt,
                agent_instructions=self._agent_instructions,
                verification_commands=self._verification_commands,
                ctrlcode_dir=self._ctrlcode_dir,
                workspace_root=self._workspace_root,
                assembler=assembler,
                context_limit=self._context_limit,
                context_before_turn=ctx.session.context_before_turn,
                user_input=ctx.user_input,
                skill_registry=self._skill_registry,
            )
        except Exception as exc:
            logger.warning(f"System prompt build failed (non-fatal): {exc}")
