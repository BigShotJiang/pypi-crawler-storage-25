"""Plain data containers for session management."""

from dataclasses import dataclass, field, fields
from typing import Any, Final

from ..providers.base import Provider

# Marker for fields that must never appear in RPC responses or TUI rendering.
# Usage: field(metadata=_PRIVATE) or field(default=x, metadata=_PRIVATE)
_PRIVATE: Final = {"private": True}


def public_fields(obj: Any) -> dict[str, Any]:
    """Return only the user-visible fields of a dataclass instance.

    Any field declared with field(metadata=_PRIVATE) is excluded.
    Used to ensure serialisation boundaries never expose internal state.
    """
    return {
        f.name: getattr(obj, f.name)
        for f in fields(obj)
        if not f.metadata.get("private", False)
    }


@dataclass
class ReactConfig:
    """Configuration for the ReAct loop."""

    mid_task_compaction: bool = False   # Tier 3 LLM summarization mid-task (costly)
    doom_loop_threshold: int = 3        # Identical calls in a row before bail-out
    max_continuations: int = 50         # Safety cap on iterations
    tool_delay: float = 0.1             # Seconds between serial tool execution groups
    max_output_tokens: int = 32_000     # Max tokens per model response


@dataclass
class Session:
    """Represents a conversation session."""

    id: str
    conv_id: str = field(metadata=_PRIVATE)
    provider: Provider = field(metadata=_PRIVATE)
    cumulative_tokens: int = 0  # Track total tokens used across all turns
    context_before_turn: int = field(default=0, metadata=_PRIVATE)  # Turn-scoped scratch; never exposed
