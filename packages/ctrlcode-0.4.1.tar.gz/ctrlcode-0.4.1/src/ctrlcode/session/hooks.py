"""Hook factories and middleware for the ReAct loop."""

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncIterator, Callable, Optional

from harnessutils import ConversationManager, Message, TextPart

from ..providers.base import StreamEvent
from ..tools.executor import ToolExecutor
from .utils import strip_markdown_fences, generate_msg_id
from .verification import VerificationDetector

logger = logging.getLogger(__name__)


def make_before_complete_hook(
    session_id: str,
    commands_run: list[str],
    tool_executor: Optional[ToolExecutor],
    verification_commands: list[str],
    verification_detector: VerificationDetector,
) -> Callable:
    """Build a hook that blocks completion if pending todos or unrun verification commands exist.

    Called when the agent produces a text-only response (no tool calls), before the loop exits.
    Returns a block reason string to prevent completion, or None to allow it.
    """
    async def hook(assistant_text: str) -> str | None:
        if tool_executor is not None:
            try:
                result = await tool_executor.execute(
                    tool_name="todo_list",
                    arguments={"session_id": session_id},
                    call_id="guard_todo_check",
                )
                if result.success:
                    todos = result.result.get("todos", []) if isinstance(result.result, dict) else []
                    pending = [t for t in todos if t.get("status") in ("pending", "in_progress")]
                    if pending:
                        items = ", ".join(f'"{t["content"]}"' for t in pending[:3])
                        extra = f" (+{len(pending) - 3} more)" if len(pending) > 3 else ""
                        return (
                            f"You have {len(pending)} unfinished todo item(s): {items}{extra}. "
                            f"Complete or explicitly remove them before finishing."
                        )
            except Exception:
                pass

        if verification_commands:
            missing = [
                cmd for cmd in verification_commands
                if not verification_detector.command_ran(cmd, commands_run)
            ]
            if missing:
                missing_list = ", ".join(f"`{c}`" for c in missing)
                return (
                    f"Verification required before finishing. "
                    f"Run the following command(s) and show the output: {missing_list}"
                )
        return None
    return hook


def make_pre_tool_hook(
    user_input: str,
    session_id: str,
    permission_manager: Any = None,
) -> Callable:
    """Build a pre-tool hook that checks permissions, strips markdown fences, and optionally fuzzes write content."""
    async def hook(tool_call: dict) -> AsyncIterator[StreamEvent]:
        # 1. Permission check FIRST — before any fuzzing that could take minutes
        if permission_manager is not None:
            from ..permissions import is_destructive
            tool_name = tool_call["tool"]
            arguments = tool_call["input"]
            _is_safe_run = (
                tool_name == "run_command"
                and permission_manager.is_safe_command(arguments.get("command", ""))
            )
            if is_destructive(tool_name) and not _is_safe_run:
                approved, context = await permission_manager.request_permission_async(
                    operation=tool_name,
                    path=arguments.get("path", arguments.get("command", "")),
                    reason=f"Agent wants to run {tool_name}",
                    details={"input": arguments},
                )
                if not approved:
                    # Signal executor to skip execution without re-asking
                    tool_call["input"]["__perm_denied__"] = True
                    tool_call["input"]["__perm_context__"] = context
                    return
                else:
                    # Signal executor that permission was already granted
                    tool_call["input"]["__perm_approved__"] = True

        # 2. Strip markdown fences from write content
        if tool_call["tool"] in ("write_file", "update_file"):
            content = tool_call["input"].get("content", "")
            if content:
                tool_call["input"]["content"] = strip_markdown_fences(content)

    return hook


_WRITE_TOOLS = {"write_file", "update_file", "edit_file", "create_file"}


def make_post_tool_hook(
    session_id: str,
    sessions: dict,
    tool_executor: Optional[ToolExecutor],
    conv_manager: ConversationManager,
    workspace_monitor: Optional[Any] = None,  # WorkspaceMonitor, avoids circular import
) -> Callable:
    """Build a post-tool hook that handles blast-radius warnings and auto-chaining."""
    async def hook(tool_call: dict, result: Any) -> AsyncIterator[StreamEvent]:
        session = sessions.get(session_id)
        if not session or not result.success:
            return

        # Blast-radius warning: tell the agent which files import the one it just wrote
        if workspace_monitor and tool_call["tool"] in _WRITE_TOOLS:
            path = tool_call["input"].get("path", "")
            if path:
                try:
                    dependents = await workspace_monitor.dep_indexer.get_dependents(path)
                    if dependents:
                        dep_list = ", ".join(sorted(dependents)[:10])
                        extra = f" (+{len(dependents) - 10} more)" if len(dependents) > 10 else ""
                        note = Message(id=generate_msg_id(), role="user")
                        note.add_part(TextPart(text=(
                            f"[System: Blast radius] {path} is imported by: {dep_list}{extra}. "
                            f"Verify these files are not broken by your change."
                        )))
                        conv_manager.add_message(session.conv_id, note)
                except Exception:
                    pass

        chained = check_auto_chain(tool_call["tool"], result.result)
        if not chained or tool_executor is None:
            return
        logger.info(f"Auto-chaining: {tool_call['tool']} → {chained['tool']}")
        res = await tool_executor.execute(
            tool_name=chained["tool"],
            arguments=chained["arguments"],
            call_id=chained["call_id"],
        )
        yield StreamEvent(
            type="tool_result",
            data={"tool": chained["tool"], "success": res.success, "result": res.result if res.success else res.error},
        )
        result_msg = Message(id=generate_msg_id(), role="user")
        result_text = f"[Tool: {chained['tool']}]\n"
        result_text += f"Result: {res.result}" if res.success else f"Error: {res.error}"
        result_msg.add_part(TextPart(text=result_text))
        conv_manager.add_message(session.conv_id, result_msg)
    return hook




def check_auto_chain(tool_name: str, result: Any) -> dict | None:
    """Return a chained tool call dict if auto-chaining applies, else None."""
    if tool_name == "search_files" and isinstance(result, list) and len(result) == 1:
        return {
            "tool": "read_file",
            "arguments": {"path": result[0]},
            "call_id": f"auto_{uuid.uuid4().hex[:12]}",
        }
    return None


async def write_progress_file(
    ctrlcode_dir: Path,
    summary: str,
    touched_files: list[str],
    backend: Any | None = None,
) -> None:
    """Write .ctrlcode/progress.md with the completed session summary."""
    progress_file = ctrlcode_dir / "progress.md"
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    files_section = ""
    if touched_files:
        files_list = "\n".join(f"- {f}" for f in touched_files)
        files_section = f"\n\n### Files touched\n{files_list}"
    content = f"## Session: {now}\n\n### Done\n{summary}{files_section}\n"
    try:
        if backend is not None:
            backend.overwrite(str(progress_file), content)
        else:
            progress_file.parent.mkdir(parents=True, exist_ok=True)
            progress_file.write_text(content, encoding="utf-8")
        logger.info(f"Progress file written to {progress_file}")
    except Exception as e:
        logger.warning(f"Failed to write progress file (non-fatal): {e}")
