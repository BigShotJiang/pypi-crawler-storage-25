"""Session creation, resumption, and persistence."""

import json
import logging
import uuid
from pathlib import Path
from typing import Optional

from harnessutils import ConversationManager

from ..providers.base import Provider
from .models import Session

logger = logging.getLogger(__name__)


class SessionStore:
    """Manages session lifecycle and on-disk persistence."""

    def __init__(
        self,
        conv_manager: ConversationManager,
        provider: Provider,
        ctrlcode_dir: Path,
    ):
        self.sessions: dict[str, Session] = {}
        self._conv_manager = conv_manager
        self._provider = provider
        self._index_path = ctrlcode_dir / "session_index.json"
        self._project_id_path = ctrlcode_dir / "project_id"

    def load_or_create_project_id(self) -> str:
        """Load stable project UUID, creating it if absent."""
        self._project_id_path.parent.mkdir(parents=True, exist_ok=True)
        if self._project_id_path.exists():
            return self._project_id_path.read_text().strip()
        pid = str(uuid.uuid4())
        self._project_id_path.write_text(pid)
        return pid

    def create(self, provider: Optional[Provider] = None) -> Session:
        """Create a new session."""
        conv = self._conv_manager.create_conversation(
            project_id=self.load_or_create_project_id()
        )
        session = Session(
            id=str(uuid.uuid4()),
            conv_id=conv.id,
            provider=provider or self._provider,
        )
        self.sessions[session.id] = session
        self._save_index(session.id, conv.id)
        return session

    def resume(self, session_id: str, provider: Optional[Provider] = None) -> Optional[Session]:
        """Restore a session from a previous run. Returns None if unknown."""
        if session_id in self.sessions:
            return self.sessions[session_id]
        try:
            if not self._index_path.exists():
                return None
            index = json.loads(self._index_path.read_text())
            conv_id = index.get(session_id)
        except Exception:
            return None
        if not conv_id:
            return None
        try:
            msgs = self._conv_manager.get_messages(conv_id)
            if not msgs:
                return None
            # Validate messages actually have content (guards against format mismatches
            # where messages exist but parts are unreadable from a prior storage version).
            model_msgs = self._conv_manager.to_model_format(conv_id)
            if not any(m.get("content") for m in model_msgs):
                return None
        except Exception:
            return None
        session = Session(id=session_id, conv_id=conv_id, provider=provider or self._provider)
        self.sessions[session_id] = session
        logger.info(f"Resumed session {session_id} (conv_id={conv_id})")
        return session

    def get(self, session_id: str) -> Optional[Session]:
        """Get session by ID."""
        return self.sessions.get(session_id)

    def get_recent_session_ids(self) -> list[str]:
        """Return session IDs in reverse-insertion order (most recent first)."""
        try:
            if not self._index_path.exists():
                return []
            index = json.loads(self._index_path.read_text())
            sessions = [k for k in index if not k.startswith("__")]
            # __last__ points to the most recently created; use it to put that first.
            last = index.get("__last__")
            if last and last in sessions:
                sessions.remove(last)
                sessions = [last] + list(reversed(sessions))
            else:
                sessions = list(reversed(sessions))
            return sessions
        except Exception:
            return []

    def mark_active(self, session_id: str) -> None:
        """Update __last__ to this session. Call when a turn is processed."""
        try:
            index = json.loads(self._index_path.read_text()) if self._index_path.exists() else {}
            index["__last__"] = session_id
            self._index_path.write_text(json.dumps(index))
        except Exception:
            pass

    def _save_index(self, session_id: str, conv_id: str) -> None:
        """Persist session_id → conv_id mapping (does NOT update __last__)."""
        self._index_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            index = json.loads(self._index_path.read_text()) if self._index_path.exists() else {}
            index[session_id] = conv_id
            self._index_path.write_text(json.dumps(index))
        except Exception:
            pass
