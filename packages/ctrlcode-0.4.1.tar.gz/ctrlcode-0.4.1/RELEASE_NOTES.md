# v0.4.0 Release Notes

**Release Date:** 2026-04-06

## Major Changes

### 🎯 Architecture Redesign

- **Middleware Stack**: Decomposed `process_turn` into composable middleware with four hook points (`before_turn`, `pre_tool`, `after_tool_call`, `after_turn`) for clean separation of concerns
- **Pluggable Backends**: New `BackendProtocol` abstraction allows swapping I/O implementations — `FilesystemBackend` for production, `StateBackend` for testing, `CompositeBackend` for path-based routing
- **Rootset DB**: SQLite artifact store at `.ctrlcode/rootset.db` with versioned schema migrations (auto-applied on startup)
- **Session Store**: New session persistence layer with lifecycle management and private field marker pattern

### 🤖 Multi-Agent Workflows

- **Recursive Delegation**: `coder` agent can spawn sub-agents via `spawn_agent` tool to parallelize independent subtasks (configurable depth, default: 2)
- **Session Tracing**: Full delegation tree reconstruction via `.ctrlcode/agents/spawn_index.jsonl` with parent/child `agent_id` tracking
- **Workflow Orchestrator**: Planner → Coder → Reviewer → Executor pipeline with parallel task groups and checkpoints
- **Tool Recovery**: New `ToolRecoveryAgent` handles tool execution failures with intelligent retry logic

### 🧠 Memory & Context Management

- **Semantic Artifact Store**: Replaced FAISS/HistoryDB stack with quality-based engagement scoring and weighted multi-signal saliency
- **Proactive Context Monitoring**: Auto-compaction at 85% threshold with LLM-powered summarization
- **Agent-Triggered Compaction**: Agents can call `compact_conversation` at phase boundaries (last 6 messages preserved verbatim)
- **Cross-Session Memory**: Project-scoped persistence for artifacts across sessions
- **Tree-Sitter Entity Extraction**: Replaced regex-based extraction with language-aware parsing for 40+ languages
- **Dependency Graph**: Workspace index with Merkle tree and cross-file dependency tracking (JS/TS, Rust, Python)

### 🛠️ Skills System

- **Progressive Disclosure**: Skills injected into system prompt with `/name` slash command invocation
- **Global Skills Directory**: `~/.config/ctrlcode/skills/` for user-defined skills
- **Folder Format**: All builtin skills converted from `.toml` to `SKILL.md` format with metadata headers
- **New Skills**: `debug-session`, `plan`, `pr` added to builtin set

### 🔐 Permission System

- **Destructive Operation Gating**: Permission requests for file writes outside workspace, dangerous commands
- **Out-of-Workspace Checks**: Real-time validation before write operations
- **Configurable Safe Commands**: `safe_commands` list in config for auto-approved operations
- **Indefinite Waiting**: Permission requests now wait indefinitely instead of auto-denying on timeout

### 🔄 CodeAct Hybrid Mode

- **Parallel Tool Execution**: Multiple independent tools can run in parallel within a single turn
- **Turn Tracking**: Structured trajectory capture with timing data per tool call
- **Immediate Output Mounting**: Tool results mounted to conversation immediately in sequence

### 🎨 User Experience

- **First-Run Setup Wizard**: Interactive model discovery and config generation with comments
- **Session Resumption**: `--continue/-c` and `--resume` flags to reconnect to existing sessions
- **Natural Completion**: Replaced `task_complete` tool with text-only completion pattern (agents write answer, then finish)
- **Configurable Max Tokens**: Per-model response token limits in provider config

## Removed

### 🗑️ Fuzzing Subsystem

Complete removal of differential fuzzing infrastructure:
- `src/ctrlcode/fuzzing/` — All context fuzzer, orchestrator, analyzer, budget management
- `src/ctrlcode/analysis/bug_detector.py` — Bug detection via variant generation
- `src/ctrlcode/embeddings/` — FAISS-based vector store (replaced by semantic artifact store)
- All fuzzing tests and integration tests

**Rationale**: Fuzzing added 2-minute delays, complexity, and wasn't aligned with core value proposition of transforming LLM output to production code.

## Bug Fixes

- **Premature Termination**: Fixed agent stopping before completing multi-step tasks
- **Permission Widget**: Finalize assistant text before mounting permission modal
- **Trajectory Timing**: Include `call_id` in `tool_result` events for accurate timing lookup
- **Turn Duration**: Compute `turn_duration_s` before running `after_turn` middleware
- **Empty End Turn**: Nudge model when it gives empty `end_turn` after tool use
- **Continuation Flush**: Flush iter-0 code blocks when continuation begins
- **Validity Score**: Exclude `validity_score=0` artifacts from all memory searches
- **Prune Protect Cap**: Cap at 50k tokens to prevent excessive context retention
- **Timezone Awareness**: Replace `utcnow()` with timezone-aware `datetime`
- **Skill Invocation**: Fix routing of slash commands to server instead of unknown handler
- **Output Rendering**: Fix skill output rendering and heading styles
- **Tool Loops**: Prevent infinite tool execution loops with better error reporting

## Testing

- **Coverage Increase**: From 64% to 82%+ test coverage
- **New Test Suites**:
  - Multi-agent workflow tests (`tests/agents/`)
  - Backend tests (`tests/backends/`)
  - Memory subsystem tests (`tests/memory/`)
  - Middleware tests (`tests/session/middleware/`)
  - Skill system tests (`tests/test_skills_loader.py`, `tests/test_skill_registry.py`)
  - Permission system tests (`tests/test_permissions.py`)
- **Removed Tests**: All fuzzing, embedding, and HistoryDB tests

## Performance

- **Faster Entity Extraction**: Tree-sitter parsing vs regex (10-100x faster for large codebases)
- **Reduced Latency**: Removed 2-minute fuzzing delay from permission checks
- **Parallel Tool Execution**: Independent tools run concurrently instead of sequentially
- **Efficient Context**: Quality-based artifact scoring reduces irrelevant context injection

## Developer Experience

- **Better Error Messages**: Improved tool execution error reporting
- **Workspace Watching**: Real-time file system monitoring via `watchfiles`
- **Agent Registry**: Centralized agent registration and discovery
- **Verification Enforcement**: Auto-detect verification commands and enforce before task completion
- **Todo Checklists**: Steps field in todos with scope/verification enforcement

## Configuration Changes

### New Options

```toml
[agents]
max_delegation_depth = 2   # Max recursive sub-agent depth (0 = disable)

[trajectories]
enabled = false            # Opt-in: record turns as training data
dir = ".ctrlcode/trajectories"

[permissions]
safe_commands = ["pytest", "ruff"]   # Auto-approved commands
```

### Deprecated

- All fuzzing-related config options removed
- Embedding model config removed

## Migration Guide

### From v0.3.0 to v0.4.0

1. **Config File**: Remove fuzzing and embedding sections; add `agents.max_delegation_depth` if needed
2. **Data Directory**: Old `.harness/` directory renamed to `.ctrlcode/`
3. **Database Migration**: `rootset.db` schema migrations run automatically on startup
4. **Skills**: Custom `.toml` skills should be converted to folder format with `SKILL.md`
5. **API Changes**:
   - `task_complete` tool removed — agents now write text answer then finish naturally
   - Session resumption via `--continue` flag instead of manual session ID
   - Permission requests now wait indefinitely (no timeout parameter needed)

## Notable Commits

- `b63b486` — fix: premature termination bug
- `3dfdb5c` — feat: recursive sub-agent delegation with session tracing
- `6eb7720` — feat: CodeAct hybrid with parallel tools
- `888044a` — refactor: decompose process_turn into middleware stack
- `c9bc035` — feat: pluggable backends
- `19cf0a2` — feat: proactive context window monitoring
- `60aa0f1` — feat: skills progressive disclosure
- `8ccb629` — remove: delete entire fuzzing subsystem
- `0f84542` — feat: replace FAISS with semantic artifact store
- `20d5bff` — feat: add permission system

## Statistics

- **77 commits** since v0.3.0
- **275 files changed**
- **25,452 insertions**, **12,908 deletions**
- **Net change**: +12,544 lines
- **Test coverage**: 64% → 82%+

## Acknowledgments

Thank you to all contributors who helped shape this release. The v0.4.0 represents a major architectural evolution focused on reliability, performance, and developer experience.

## Known Issues

- First-run wizard may fail if no API keys are configured (expected behavior)
- Session resumption requires network connectivity to validate existing sessions
- Permission modals in TUI may not dismiss automatically on timeout (waiting indefinitely by design)

## Future Roadmap

- [ ] MCP (Model Context Protocol) integration
- [ ] Enhanced TUI with real-time agent tree visualization
- [ ] More language indexers for dependency graph
- [ ] Distributed agent execution across multiple workspaces
- [ ] Plugin system for custom middleware