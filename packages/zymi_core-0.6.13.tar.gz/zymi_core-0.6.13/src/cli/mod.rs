mod event_fmt;
mod events;
mod fetch;
mod init;
mod mcp;
mod observe;
mod pipelines;
mod resume;
mod run;
mod runs;
mod runs_data;
mod schema;
mod serve;
mod venv;
mod verify;

use std::path::{Path, PathBuf};
use std::process;
use std::sync::Arc;

use clap::{Parser, Subcommand};

#[derive(Subcommand)]
enum McpCommand {
    /// Spawn an MCP server, handshake, list its tools, and shut down.
    ///
    /// Does not require a project directory or an LLM — use it to discover
    /// what a server advertises before writing an `allow:` whitelist.
    ///
    /// Example:
    ///   zymi mcp probe fs -- npx -y @modelcontextprotocol/server-filesystem /tmp
    ///   zymi mcp probe fetch -- uvx mcp-server-fetch
    Probe {
        /// Name used in the handshake (cosmetic — doesn't have to match project.yml)
        name: String,

        /// Extra env var for the child process, repeatable. Only PATH is
        /// auto-forwarded from the parent; everything else stays out of the
        /// child unless named here.
        #[arg(long = "env", value_name = "KEY=VALUE")]
        env: Vec<String>,

        /// Handshake deadline in seconds
        #[arg(long, default_value = "15")]
        init_timeout_secs: u64,

        /// Per-call deadline in seconds (affects tools/list here)
        #[arg(long, default_value = "30")]
        call_timeout_secs: u64,

        /// Command and args for the MCP server (prefix with `--`)
        #[arg(trailing_var_arg = true, allow_hyphen_values = true)]
        command: Vec<String>,
    },

    /// Serve this project's pipelines as MCP tools over stdio (ADR-0033).
    ///
    /// Pipelines opt in by declaring `expose.mcp:` in their YAML. Sync
    /// mode only in v1 — async-mode pipelines parse but are skipped from
    /// `tools/list` until Slice 2 (SEP-1686 Tasks).
    ///
    /// Example: wire into Claude Desktop via
    ///   { "command": "zymi", "args": ["mcp", "serve", "--dir", "/path/to/project"] }
    Serve {
        /// Only expose pipelines whose name matches one of these globs
        /// (`*`, `?`). When omitted, every pipeline that has `expose.mcp:`
        /// is exposed.
        #[arg(long = "include", value_name = "GLOB")]
        include: Vec<String>,

        /// Hide pipelines whose name matches one of these globs. Applied
        /// after `--include`.
        #[arg(long = "exclude", value_name = "GLOB")]
        exclude: Vec<String>,

        /// Project directory (defaults to the current working directory).
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },
}

/// zymi — event-sourced agent engine CLI
#[derive(Parser)]
#[command(name = "zymi", version, about)]
pub struct Cli {
    /// Skip the per-project `.venv` re-exec on pipeline-run commands
    /// (ADR-0032). Useful for contributor workflows where the global
    /// `zymi` binary already lives in the right Python env.
    #[arg(long = "no-venv", global = true)]
    no_venv: bool,

    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Initialize a new zymi project in the current directory
    Init {
        /// Project name (defaults to directory name)
        #[arg(short, long)]
        name: Option<String>,

        /// Scaffold from a built-in example. Currently only "telegram".
        #[arg(long)]
        example: Option<String>,
    },

    /// Run a pipeline
    Run {
        /// Pipeline name to execute
        pipeline: String,

        /// Pipeline input in KEY=VALUE format (repeatable)
        #[arg(short = 'i', long = "input", value_name = "KEY=VALUE")]
        inputs: Vec<String>,

        /// Override approval routing. Accepts "terminal" or "webhook"
        /// (legacy escape hatch). When omitted, the runtime uses the
        /// `approvals:` section in `project.yml` (or falls back to a
        /// terminal prompt when that section is absent).
        #[arg(long)]
        approval: Option<String>,

        /// Webhook callback URL for approval notifications (requires --approval=webhook)
        #[arg(long)]
        callback_url: Option<String>,

        /// Project root directory (defaults to cwd)
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// List and inspect events from the store
    Events {
        /// Filter by stream ID (replaces the old `replay` command)
        #[arg(short, long)]
        stream: Option<String>,

        /// Filter by event kind tag
        #[arg(short, long)]
        kind: Option<String>,

        /// Maximum number of events to show
        #[arg(short, long, default_value = "50")]
        limit: usize,

        /// Emit raw output (one JSON event per line, pipe-friendly)
        #[arg(long)]
        raw: bool,

        /// Show extended detail for each event
        #[arg(short, long)]
        verbose: bool,

        /// Project root directory
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// Verify hash chain integrity of the event store
    Verify {
        /// Verify a specific stream (otherwise all streams)
        #[arg(short, long)]
        stream: Option<String>,

        /// Project root directory
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// Run pipelines as a long-lived service that reacts to PipelineRequested events
    Serve {
        /// Pipeline name(s) to serve. Accepts one or more positional names
        /// (`zymi serve foo bar`); use `--all` to serve every pipeline in
        /// the project. Required unless `--all` is given.
        #[arg(conflicts_with = "all")]
        pipelines: Vec<String>,

        /// Serve every pipeline declared in the project. Mutually exclusive
        /// with positional pipeline names.
        #[arg(long, conflicts_with = "pipelines")]
        all: bool,

        /// Polling interval for the cross-process store watcher (ms)
        #[arg(long, default_value = "100")]
        poll_interval_ms: u64,

        /// Override approval routing. Accepts "terminal" or "webhook"
        /// (legacy escape hatch). When omitted, the runtime uses the
        /// `approvals:` section in `project.yml` (or falls back to a
        /// terminal prompt when that section is absent).
        #[arg(long)]
        approval: Option<String>,

        /// Webhook callback URL for approval notifications (requires --approval=webhook)
        #[arg(long)]
        callback_url: Option<String>,

        /// Project root directory (defaults to cwd)
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// Sync the project's `.venv` from `pyproject.toml` (wraps `uv sync`).
    ///
    /// Pipeline-run commands (`run`, `serve`, `resume`) automatically
    /// re-exec inside `./.venv/bin/python` when it exists, so user
    /// `@tool` imports resolve against the project's deps. `zymi fetch`
    /// is what creates / refreshes that `.venv`.
    Fetch {
        /// Project root directory (defaults to cwd)
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// List pipelines defined in the project
    Pipelines {
        /// Project root directory
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// List pipeline runs recorded in the event store
    Runs {
        /// Filter by pipeline name
        #[arg(short, long)]
        pipeline: Option<String>,

        /// Maximum number of runs to show
        #[arg(short, long, default_value = "50")]
        limit: usize,

        /// Emit raw JSON output (one run per line)
        #[arg(long)]
        raw: bool,

        /// Project root directory
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// Interactive TUI for browsing runs, pipeline graph, and event timeline
    Observe {
        /// Pre-select a run by stream id
        #[arg(short, long)]
        run: Option<String>,

        /// Project root directory
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// Fork-resume a previous pipeline run from a chosen step (ADR-0018).
    ///
    /// Steps upstream of `--from-step` are frozen — their events from the
    /// parent stream are copied to a new stream and they are not re-executed.
    /// The fork step and its DAG-descendants run from scratch using the
    /// current pipelines/agents config from disk.
    Resume {
        /// Parent stream id (see `zymi runs` / `zymi observe`)
        stream: String,

        /// Step id at which to fork — this step and everything downstream re-run
        #[arg(long = "from-step")]
        from_step: String,

        /// Print the resume plan (frozen vs re-executed steps) and exit
        /// without writing any new events.
        #[arg(long)]
        dry_run: bool,

        /// Override approval routing. Accepts "terminal" or "webhook"
        /// (legacy escape hatch). When omitted, the runtime uses the
        /// `approvals:` section in `project.yml` (or falls back to a
        /// terminal prompt when that section is absent).
        #[arg(long)]
        approval: Option<String>,

        /// Webhook callback URL for approval notifications
        #[arg(long)]
        callback_url: Option<String>,

        /// Project root directory (defaults to cwd)
        #[arg(short = 'd', long)]
        dir: Option<PathBuf>,
    },

    /// MCP server utilities (probe a server, inspect tools)
    Mcp {
        #[command(subcommand)]
        command: McpCommand,
    },

    /// Print JSON Schema for a config kind (project, agent, pipeline, tool)
    Schema {
        /// Config kind: project, agent, pipeline, tool
        kind: Option<String>,

        /// Print schemas for all config kinds
        #[arg(long)]
        all: bool,
    },

}

/// Run the CLI. Called from the binary entry point.
pub fn run() {
    let argv: Vec<String> = std::env::args().collect();
    let cli = Cli::parse_from(&argv);
    venv::maybe_reexec(&cli, argv.get(1..).unwrap_or(&[]));
    dispatch(cli);
}

/// Run the CLI with explicit arguments (used by the Python entry point).
/// The forwarded argv for any potential `.venv` re-exec is derived from
/// `args` (not `std::env::args()`): when this entry point is reached
/// through the wheel's `zymi = zymi._cli:main` console script, the
/// OS-level args include the Python interpreter path inserted by the
/// shebang, which would leak into the child as a bogus subcommand.
pub fn run_from_args(args: impl IntoIterator<Item = String>) {
    let argv: Vec<String> = args.into_iter().collect();
    let cli = Cli::parse_from(&argv);
    venv::maybe_reexec(&cli, argv.get(1..).unwrap_or(&[]));
    dispatch(cli);
}

fn dispatch(cli: Cli) {
    load_dotenv(command_dir(&cli.command));
    let result = match cli.command {
        Command::Init { name, example } => init::exec(name, example.as_deref()),
        Command::Run {
            pipeline,
            inputs,
            approval,
            callback_url,
            dir,
        } => run::exec(&pipeline, &inputs, approval.as_deref(), callback_url.as_deref(), resolve_root(dir.as_deref())),
        Command::Events {
            stream,
            kind,
            limit,
            raw,
            verbose,
            dir,
        } => events::exec(
            stream.as_deref(),
            kind.as_deref(),
            limit,
            raw,
            verbose,
            resolve_root(dir.as_deref()),
        ),
        Command::Fetch { dir } => fetch::exec(resolve_root(dir.as_deref())),
        Command::Pipelines { dir } => pipelines::exec(resolve_root(dir.as_deref())),
        Command::Runs {
            pipeline,
            limit,
            raw,
            dir,
        } => runs::exec(
            pipeline.as_deref(),
            limit,
            raw,
            resolve_root(dir.as_deref()),
        ),
        Command::Observe { run, dir } => {
            observe::exec(run.as_deref(), resolve_root(dir.as_deref()))
        }
        Command::Verify { stream, dir } => {
            verify::exec(stream.as_deref(), resolve_root(dir.as_deref()))
        }
        Command::Serve {
            pipelines,
            all,
            poll_interval_ms,
            approval,
            callback_url,
            dir,
        } => serve::exec(
            &pipelines,
            all,
            poll_interval_ms,
            approval.as_deref(),
            callback_url.as_deref(),
            resolve_root(dir.as_deref()),
        ),
        Command::Resume {
            stream,
            from_step,
            dry_run,
            approval,
            callback_url,
            dir,
        } => resume::exec(
            &stream,
            &from_step,
            dry_run,
            approval.as_deref(),
            callback_url.as_deref(),
            resolve_root(dir.as_deref()),
        ),
        Command::Mcp { command } => match command {
            McpCommand::Probe {
                name,
                env,
                init_timeout_secs,
                call_timeout_secs,
                command,
            } => mcp::exec_probe(&name, &command, &env, init_timeout_secs, call_timeout_secs),
            McpCommand::Serve {
                include,
                exclude,
                dir,
            } => mcp::exec_serve(&include, &exclude, resolve_root(dir.as_deref())),
        },
        Command::Schema { kind, all } => schema::exec(kind.as_deref(), all),
    };

    if let Err(e) = result {
        eprintln!("error: {e}");
        process::exit(1);
    }
}

/// Resolve the project root: use --dir if given, otherwise cwd.
fn resolve_root(dir: Option<&Path>) -> PathBuf {
    dir.map(|d| d.to_path_buf())
        .unwrap_or_else(|| std::env::current_dir().expect("cannot determine current directory"))
}

/// Inspect the parsed subcommand for its `--dir` argument, if it carries
/// one. Used solely to seed `.env` loading before dispatch.
fn command_dir(cmd: &Command) -> Option<&Path> {
    match cmd {
        Command::Run { dir, .. }
        | Command::Events { dir, .. }
        | Command::Pipelines { dir }
        | Command::Runs { dir, .. }
        | Command::Observe { dir, .. }
        | Command::Verify { dir, .. }
        | Command::Serve { dir, .. }
        | Command::Resume { dir, .. } => dir.as_deref(),
        Command::Fetch { dir } => dir.as_deref(),
        Command::Mcp { command } => match command {
            McpCommand::Serve { dir, .. } => dir.as_deref(),
            McpCommand::Probe { .. } => None,
        },
        Command::Init { .. } | Command::Schema { .. } => None,
    }
}

/// Load `.env` next to `project.yml` so users don't have to remember
/// `set -a; source .env; set +a` before every CLI invocation.
///
/// Resolution order:
///   1. The path passed via `--dir`, if the subcommand has one;
///   2. The current working directory.
///
/// Existing process env vars always win — `.env` only fills holes. We
/// log on parse error but never fail the command: a malformed `.env`
/// shouldn't take down `zymi schema`.
fn load_dotenv(explicit_dir: Option<&Path>) {
    let mut tried: Vec<PathBuf> = Vec::new();
    if let Some(d) = explicit_dir {
        tried.push(d.join(".env"));
    }
    if let Ok(cwd) = std::env::current_dir() {
        let cwd_env = cwd.join(".env");
        if !tried.iter().any(|p| p == &cwd_env) {
            tried.push(cwd_env);
        }
    }
    for path in tried {
        if !path.exists() {
            continue;
        }
        match dotenvy::from_path(&path) {
            Ok(()) => log::debug!("loaded env from {}", path.display()),
            Err(e) => log::warn!("could not load {}: {e}", path.display()),
        }
    }
}

/// Path to the event store database within a project.
pub(crate) fn store_path(root: &Path) -> PathBuf {
    root.join(".zymi").join("events.db")
}

/// Resolve the configured event-store backend for read-only CLI
/// subcommands (`events`, `runs`, `observe`, `resume`, …) that don't go
/// through `RuntimeBuilder`. Honours `project.yml`'s `store:` field;
/// falls back to embedded sqlite at `<root>/.zymi/events.db` when the
/// project file is absent (some commands are usable in pure inspection
/// mode without a fully-configured project).
pub(crate) fn resolve_store_backend_for_cli(
    root: &Path,
) -> Result<crate::events::store::StoreBackend, String> {
    use crate::events::store::StoreBackend;
    let project_path = root.join("project.yml");
    if !project_path.exists() {
        return Ok(StoreBackend::Sqlite {
            path: store_path(root),
        });
    }
    let workspace = crate::config::load_project_dir(root)
        .map_err(|e| format!("failed to load project: {e}"))?;
    workspace
        .project
        .resolve_store_backend(root)
        .map_err(|e| format!("project.store: {e}"))
}

/// Human-friendly label for a [`StoreBackend`] used in CLI banners and
/// error messages.
pub(crate) fn describe_backend(backend: &crate::events::store::StoreBackend) -> String {
    use crate::events::store::StoreBackend;
    match backend {
        StoreBackend::Sqlite { path } => path.display().to_string(),
        StoreBackend::Postgres { url } => redact_url(url),
    }
}

fn redact_url(url: &str) -> String {
    // Strip any inline password — `postgres://user:pw@host/db` →
    // `postgres://user:***@host/db` — so the banner is safe to copy/paste.
    if let Some((scheme_user, rest)) = url.split_once("://") {
        if let Some((auth, host_rest)) = rest.split_once('@') {
            if let Some((user, _pw)) = auth.split_once(':') {
                return format!("{scheme_user}://{user}:***@{host_rest}");
            }
        }
    }
    url.to_string()
}

/// Pure resolution of the project-wide default approval channel name
/// (ADR-0022). Mirrors the layered logic in [`start_approval_channels`]
/// but does no I/O — the channel name flows into
/// [`crate::runtime::RuntimeBuilder::with_approval_channel`] *before*
/// the runtime is built (the bus doesn't exist yet at that point).
///
/// 1. `--approval=terminal` → `"terminal"`.
/// 2. `--approval=webhook`  → `"http"` (when the `webhook` feature is on).
/// 3. No flag, project declared `default_approval_channel:` → that name.
/// 4. No flag, project declared `approvals:` without a default → `None`
///    (orchestrator fail-closes unless a pipeline overrides).
/// 5. No flag, no `approvals:` → `"terminal"` (zero-config fallback).
pub(crate) fn pre_resolve_approval(
    flag_mode: Option<&str>,
    project: &crate::config::ProjectConfig,
) -> Option<String> {
    match flag_mode {
        Some("terminal") => Some("terminal".into()),
        #[cfg(feature = "webhook")]
        Some("webhook") => Some("http".into()),
        Some(_) => None,
        None if !project.approvals.is_empty() => project.default_approval_channel.clone(),
        None => Some("terminal".into()),
    }
}

/// Wire approval channels into the runtime bus.
///
/// Resolution logic (ADR-0022):
///
/// 1. **Explicit `--approval=` flag** wins (legacy escape hatch — the
///    same shape as v0.3). `terminal` spawns a [`TerminalApprovalChannel`]
///    named `"terminal"`; `webhook` spawns an [`HttpApprovalChannel`]
///    named `"http"` (behind the `webhook` feature). The flag overrides
///    any YAML-declared channels.
/// 2. **`approvals:` section in `project.yml`** when the flag is unset.
///    Every entry is dispatched via the [`build_core_approval_channels`]
///    plugin registry. The default channel is whatever the project
///    declared in `default_approval_channel:` (may be `None`, which
///    triggers fail-closed unless a pipeline overrides).
/// 3. **Zero-config fallback**: no flag, no `approvals:` → spawn a
///    terminal channel named `"terminal"`. Preserves the v0.3 UX where
///    `zymi run <pipeline>` from an interactive shell just prompts.
pub(crate) async fn start_approval_channels(
    flag_mode: Option<&str>,
    project: &crate::config::ProjectConfig,
    bus: Arc<crate::events::bus::EventBus>,
    #[cfg_attr(not(feature = "webhook"), allow(unused_variables))] flag_callback_url: Option<&str>,
) -> Result<Vec<crate::approval::ChannelHandle>, String> {
    use crate::approval::ApprovalChannel;

    if let Some(mode) = flag_mode {
        let handles = match mode {
            "terminal" => {
                let channel = crate::approval::TerminalApprovalChannel::new("terminal");
                vec![channel.start(Arc::clone(&bus)).await?]
            }
            #[cfg(feature = "webhook")]
            "webhook" => {
                let bind: std::net::SocketAddr = "127.0.0.1:0"
                    .parse()
                    .map_err(|e| format!("invalid webhook addr: {e}"))?;
                let mut config =
                    crate::webhook::HttpApprovalChannelConfig::new("http", bind);
                if let Some(url) = flag_callback_url {
                    config = config.with_callback_url(url);
                }
                let channel = crate::webhook::HttpApprovalChannel::new(config);
                vec![channel.start(Arc::clone(&bus)).await?]
            }
            #[cfg(not(feature = "webhook"))]
            "webhook" => return Err(
                "webhook approval requires the 'webhook' feature. \
                 Rebuild with --features webhook"
                    .into(),
            ),
            other => return Err(format!(
                "unknown approval mode '{other}'. Expected 'terminal' or 'webhook' (or remove --approval to use project.yml::approvals)"
            )),
        };
        replay_pending_approvals(Arc::clone(&bus)).await;
        return Ok(handles);
    }

    if !project.approvals.is_empty() {
        let started = crate::approval::spawn_approval_channels(&project.approvals, Arc::clone(&bus)).await?;
        for (name, err) in &started.failures {
            eprintln!("approval channel '{name}' failed to start: {err}");
        }
        replay_pending_approvals(Arc::clone(&bus)).await;
        return Ok(started.handles);
    }

    // Zero-config fallback: no flag, no approvals: section.
    let channel = crate::approval::TerminalApprovalChannel::new("terminal");
    let handles = vec![channel.start(Arc::clone(&bus)).await?];
    replay_pending_approvals(Arc::clone(&bus)).await;
    Ok(handles)
}

/// Best-effort replay of approvals left dangling by a previous process
/// crash (ADR-0022). Logs a warning on store-read failure rather than
/// aborting startup — replay is housekeeping, not a hard requirement.
async fn replay_pending_approvals(bus: Arc<crate::events::bus::EventBus>) {
    match crate::approval::replay_unfulfilled_approvals(
        bus,
        crate::approval::DEFAULT_APPROVAL_TIMEOUT,
    )
    .await
    {
        Ok(report) => {
            if !report.expired.is_empty() {
                log::info!(
                    "approval replay: sealed {} expired request(s) with restart_timeout",
                    report.expired.len()
                );
            }
            if !report.redelivered.is_empty() {
                log::info!(
                    "approval replay: redelivered {} in-flight request(s) to live channels",
                    report.redelivered.len()
                );
            }
        }
        Err(e) => log::warn!("approval replay skipped: {e}"),
    }
}

/// Create a tokio runtime for async operations.
pub(crate) fn runtime() -> tokio::runtime::Runtime {
    tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .expect("failed to create tokio runtime")
}
