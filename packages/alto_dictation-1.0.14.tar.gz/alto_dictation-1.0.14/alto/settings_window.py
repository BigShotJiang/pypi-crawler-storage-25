"""
Settings window for Alto — native window with web UI via pywebview.

The webview runs in a subprocess because GTK webview requires the main
thread, which is occupied by pystray + hotkey listener in the daemon.
"""

import json
import logging
import subprocess
import sys
import threading
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from alto.config import ServiceConfig, save_config

if TYPE_CHECKING:
    from alto.api_client import AltoAPIClient
    from alto.platforms.linux.hotkey import HotkeyListener

logger = logging.getLogger(__name__)

LANGUAGES = {
    "fr": "Francais",
    "en": "English",
    "es": "Espanol",
    "de": "Deutsch",
    "it": "Italiano",
    "pt": "Portugues",
    "nl": "Nederlands",
    "pl": "Polski",
    "ru": "Russian",
    "ja": "Japanese",
    "zh": "Chinese",
    "ko": "Korean",
    "ar": "Arabic",
}

_SETTINGS_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Alto</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, sans-serif;
         background: #fff; color: #1a1a1a; padding: 28px 28px 22px;
         -webkit-user-select: none; user-select: none; }

  .header { margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #f0f0f0; }
  .header h1 { font-size: 18px; font-weight: 600; color: #1a1a1a; }

  .section { margin-bottom: 20px; }
  .section-label { font-size: 12px; font-weight: 500; color: #666; margin-bottom: 8px; }
  .sep { height: 1px; background: #f0f0f0; margin: 16px 0; }

  /* Account */
  .account { display: flex; align-items: center; justify-content: space-between; }
  .account-left { display: flex; flex-direction: column; gap: 2px; }
  .account-email { font-size: 14px; font-weight: 500; color: #1a1a1a; }
  .account-meta { font-size: 12px; color: #666; }
  .tier-badge { display: inline-block; font-size: 11px; font-weight: 600; color: #fff;
                background: #1a1a1a; padding: 2px 8px; border-radius: 10px; margin-left: 6px; }
  .tier-badge.free { background: #888; }
  .tier-badge.pro { background: #2563eb; }
  .tier-badge.max { background: #7c3aed; }

  .upgrade-btn { font-size: 12px; font-weight: 500; color: #2563eb; background: #eff6ff;
                 padding: 6px 14px; border-radius: 6px; border: none; cursor: pointer;
                 text-decoration: none; display: inline-block; transition: background 0.15s; }
  .upgrade-btn:hover { background: #dbeafe; }

  /* Usage bar */
  .usage { margin-top: 10px; }
  .usage-header { display: flex; justify-content: space-between; margin-bottom: 4px; }
  .usage-text { font-size: 11px; color: #666; }
  .bar { height: 4px; background: #f0f0f0; border-radius: 2px; overflow: hidden; }
  .bar-fill { height: 100%; background: #1a1a1a; border-radius: 2px; transition: width 0.3s; min-width: 2px; }
  .bar-fill.warn { background: #f59e0b; }
  .bar-fill.crit { background: #ef4444; }

  /* Form fields */
  select { width: 100%; padding: 10px 14px; font-size: 14px; font-family: inherit;
           background: #fafafa; border: 1px solid #e8e8e8; border-radius: 8px;
           color: #1a1a1a; outline: none; transition: border-color 0.15s;
           appearance: none; -webkit-appearance: none;
           background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23999' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
           background-repeat: no-repeat; background-position: right 12px center; }
  select:focus { border-color: #1a1a1a; background-color: #fff; }

  /* Key */
  .key-row { display: flex; gap: 8px; align-items: center; }
  .key-display { flex: 1; padding: 10px 14px; font-size: 14px; font-weight: 500;
                 background: #fafafa; border: 1px solid #e8e8e8; border-radius: 8px;
                 color: #1a1a1a; display: flex; align-items: center; }
  .key-badge { display: inline-block; background: #f0f0f0; padding: 3px 10px;
               border-radius: 4px; font-size: 13px; font-weight: 600; font-family: "SF Mono", monospace; }
  .detect-btn { padding: 10px 16px; font-size: 13px; font-family: inherit; font-weight: 500;
                background: #fafafa; border: 1px solid #e8e8e8;
                border-radius: 8px; color: #1a1a1a; cursor: pointer; white-space: nowrap;
                transition: all 0.15s; }
  .detect-btn:hover { background: #f0f0f0; border-color: #ccc; }
  .detect-btn.detecting { background: #fef3c7; color: #92400e; border-color: #fcd34d; }
  .hint { font-size: 12px; color: #888; margin-top: 6px; }

  /* Actions */
  .actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px;
             padding-top: 16px; border-top: 1px solid #f0f0f0; }
  .btn { padding: 9px 22px; font-size: 14px; font-family: inherit; border-radius: 8px;
         border: none; cursor: pointer; font-weight: 500; transition: all 0.15s; }
  .btn-cancel { background: transparent; color: #666; }
  .btn-cancel:hover { color: #1a1a1a; }
  .btn-save { background: #1a1a1a; color: #fff; }
  .btn-save:hover { background: #333; }

  .not-connected { color: #999; font-size: 12px; }
</style>
</head>
<body>
  <div class="header">
    <h1>Settings</h1>
  </div>

  <div id="account-card" style="display:{account_display}">
    <div class="section-label">Account</div>
    <div id="account-content">{account_html}</div>
    <div class="sep"></div>
  </div>

  <div class="section">
    <div class="section-label">Language</div>
    <select id="language">{language_options}</select>
  </div>

  <div class="section">
    <div class="section-label">Push-to-talk</div>
    <div class="key-row">
      <div class="key-display"><span class="key-badge" id="key-display">{current_key}</span></div>
      <button class="detect-btn" id="detect-btn" onclick="detectKey()">Change</button>
    </div>
    <div class="hint">Press Change, then hit your desired key or combo</div>
  </div>

  <div class="actions">
    <button class="btn btn-cancel" onclick="cancel()">Cancel</button>
    <button class="btn btn-save" onclick="save()">Save</button>
  </div>

<script>
var currentKey = "{current_key}";

function formatKey(k) {
  var parts = k.split('+');
  var out = [];
  for (var i = 0; i < parts.length; i++) {
    var p = parts[i].trim();
    if (p === 'CTRL' || p === 'SHIFT' || p === 'ALT' || p === 'SUPER') {
      out.push(p.charAt(0) + p.slice(1).toLowerCase());
    } else {
      p = p.replace('KEY_', '');
      if (p === 'GRAVE') p = '`';
      else if (p === 'SPACE') p = 'Space';
      else if (p === 'TAB') p = 'Tab';
      else if (p === 'ENTER') p = 'Enter';
      else if (p === 'BACKSPACE') p = 'Backspace';
      else if (p === 'ESC' || p === 'ESCAPE') p = 'Esc';
      else if (p.length === 1) p = p.toUpperCase();
      else p = p.charAt(0).toUpperCase() + p.slice(1).toLowerCase();
      out.push(p);
    }
  }
  return out.join(' + ');
}

function detectKey() {
  var btn = document.getElementById('detect-btn');
  btn.textContent = 'Press a key...';
  btn.classList.add('detecting');
  btn.disabled = true;
  pywebview.api.detect_key().then(function(key) {
    if (key) {
      currentKey = key;
      document.getElementById('key-display').textContent = formatKey(key);
    }
    btn.textContent = 'Change';
    btn.classList.remove('detecting');
    btn.disabled = false;
  });
}

function save() {
  var data = JSON.stringify({
    language: document.getElementById('language').value,
    evdev_key: currentKey
  });
  pywebview.api.save_settings(data);
}

function cancel() {
  pywebview.api.close_window();
}

// Format initial key display
document.getElementById('key-display').textContent = formatKey(currentKey);
</script>
</body>
</html>"""


def _build_account_html(api_client: Optional["AltoAPIClient"]) -> tuple[str, str]:
    if api_client is None:
        return "", "none"
    try:
        user_info = api_client.get_me()
    except Exception:
        return '<span class="not-connected">Not connected</span>', "block"

    import html as html_mod
    email = html_mod.escape(user_info.get("email", ""))
    t = user_info.get("tier", "free")
    tier_display = html_mod.escape(t.capitalize())
    tier_class = t if t in ("free", "pro", "max") else "free"

    html = '<div class="account">'
    html += '<div class="account-left">'
    html += f'<span class="account-email">{email}<span class="tier-badge {tier_class}">{tier_display}</span></span>'

    try:
        usage = api_client.get_usage()
        secs = usage.get("audio_seconds", 0)
        mins = secs / 60.0
        lim = {"free": 15, "pro": 180, "max": 600}.get(t, 0)
        if lim > 0:
            html += f'<span class="account-meta">{mins:.1f} / {lim} min this month</span>'
        else:
            html += f'<span class="account-meta">{mins:.1f} min this month</span>'
    except Exception:
        pass

    html += '</div>'

    active = user_info.get("subscription_active", False)
    if not active and t == "free":
        try:
            checkout_url = api_client.create_checkout("pro")
            if checkout_url:
                html += f'<a class="upgrade-btn" href="{checkout_url}" target="_blank">Upgrade</a>'
        except Exception:
            pass

    html += '</div>'

    # Usage bar
    try:
        if lim > 0:
            pct = min(1.0, mins / lim)
            cls = " crit" if pct >= 0.9 else (" warn" if pct >= 0.7 else "")
            html += f'<div class="usage"><div class="bar"><div class="bar-fill{cls}" style="width:{pct*100:.0f}%"></div></div></div>'
    except Exception:
        pass

    return html, "block"


def _build_language_options(current: str) -> str:
    return "".join(
        f'<option value="{code}" {"selected" if code == current else ""}>{name} ({code})</option>'
        for code, name in LANGUAGES.items()
    )


def open_settings_window(
    config: ServiceConfig,
    config_path: Path,
    on_close: Optional[Callable[[bool], None]] = None,
    api_client: Optional["AltoAPIClient"] = None,
    # Legacy compat
    on_save: Optional[Callable[[], None]] = None,
    hotkey_listener: Optional["HotkeyListener"] = None,
) -> None:
    thread = threading.Thread(
        target=_run_settings,
        args=(config, config_path, on_close or (lambda saved: on_save() if saved and on_save else None), api_client),
        daemon=True,
        name="SettingsWindow",
    )
    thread.start()


def _run_settings(
    config: ServiceConfig,
    config_path: Path,
    on_close: Optional[Callable[[bool], None]],
    api_client: Optional["AltoAPIClient"],
) -> None:
    # Build page HTML
    account_html, account_display = _build_account_html(api_client)
    page = (
        _SETTINGS_HTML
        .replace("{account_display}", account_display)
        .replace("{account_html}", account_html)
        .replace("{language_options}", _build_language_options(config.language))
        .replace("{current_key}", config.evdev_key)
    )

    # Run webview in a subprocess (GTK needs the main thread)
    proc = subprocess.run(
        [sys.executable, "-c", _SUBPROCESS_CODE],
        input=page,
        capture_output=True,
        text=True,
        timeout=600,
    )

    logger.info(f"Settings subprocess stdout: {proc.stdout.strip()!r}")

    result = None
    stdout = proc.stdout.strip()
    # Extract last line (JSON result), ignore any prior debug output
    if stdout:
        last_line = stdout.splitlines()[-1]
        try:
            result = json.loads(last_line)
        except json.JSONDecodeError:
            logger.warning(f"Settings subprocess output not JSON: {last_line!r}")

    if proc.stderr.strip():
        for line in proc.stderr.strip().split("\n"):
            if "Gtk" not in line and "WARNING" not in line:
                logger.debug(f"Settings subprocess: {line}")

    logger.info(f"Settings subprocess exited with code {proc.returncode}")

    saved = False
    if result and result.get("saved"):
        config.language = result.get("language", config.language)
        config.evdev_key = result.get("evdev_key", config.evdev_key)
        try:
            config.validate()
            save_config(config_path, config)
            logger.info("Settings saved")
            saved = True
        except Exception as e:
            logger.error(f"Settings save error: {e}")

    logger.info(f"Settings window closed (saved={saved}), calling on_close")
    if on_close:
        on_close(saved)


# Code executed in the subprocess — receives HTML on stdin, outputs JSON on stdout
_SUBPROCESS_CODE = '''
import json
import sys
import threading

html = sys.stdin.read()
result = {"saved": False}

def detect_key(timeout=10.0):
    try:
        import select, time, evdev
        from evdev import InputDevice, ecodes
        MOD_CODES = {
            "CTRL": {ecodes.KEY_LEFTCTRL, ecodes.KEY_RIGHTCTRL},
            "SHIFT": {ecodes.KEY_LEFTSHIFT, ecodes.KEY_RIGHTSHIFT},
            "ALT": {ecodes.KEY_LEFTALT, ecodes.KEY_RIGHTALT},
            "SUPER": {ecodes.KEY_LEFTMETA, ecodes.KEY_RIGHTMETA},
        }
        ALL_MODS = set()
        for codes in MOD_CODES.values():
            ALL_MODS |= codes
        BLOCKED = {
            frozenset({"CTRL"}): None,
            frozenset({"SUPER"}): None,
            frozenset({"ALT"}): {"KEY_TAB", "KEY_F4", "KEY_F1", "KEY_F2", "KEY_F3"},
            frozenset({"CTRL", "ALT"}): {"KEY_DELETE", "KEY_T", "KEY_L"},
            frozenset({"CTRL", "SHIFT"}): {"KEY_C", "KEY_V", "KEY_Q", "KEY_T", "KEY_N", "KEY_Z", "KEY_ESC"},
        }
        devices = []
        for path in evdev.list_devices():
            try:
                dev = InputDevice(path)
                if "alto" in dev.name.lower():
                    dev.close()
                    continue
                caps = dev.capabilities(verbose=False)
                if ecodes.EV_KEY in caps:
                    devices.append(dev)
            except (OSError, PermissionError):
                continue
        if not devices:
            return ""
        fd_map = {dev.fd: dev for dev in devices}
        held_mods = set()
        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                r, _, _ = select.select(fd_map.keys(), [], [], 0.2)
                for fd in r:
                    dev = fd_map[fd]
                    for event in dev.read():
                        if event.type != ecodes.EV_KEY:
                            continue
                        if event.code in ALL_MODS:
                            if event.value == 1:
                                held_mods.add(event.code)
                            elif event.value == 0:
                                held_mods.discard(event.code)
                            continue
                        if event.value == 1 and event.code < 272:
                            key_event = evdev.categorize(event)
                            name = key_event.keycode
                            if isinstance(name, (list, tuple)):
                                name = name[0]
                            mod_names = set()
                            for mn, mc in MOD_CODES.items():
                                if held_mods & mc:
                                    mod_names.add(mn)
                            if mod_names:
                                mods_frozen = frozenset(mod_names)
                                blocked = BLOCKED.get(mods_frozen)
                                if blocked is None and mods_frozen in BLOCKED:
                                    continue
                                if blocked and name in blocked:
                                    continue
                                return "+".join(sorted(mod_names)) + "+" + name
                            return name
        finally:
            for dev in devices:
                try: dev.close()
                except: pass
    except Exception:
        pass
    return ""

class Api:
    def detect_key(self):
        return detect_key()

    def save_settings(self, data_json):
        data = json.loads(data_json)
        result["saved"] = True
        result["language"] = data.get("language", "en")
        result["evdev_key"] = data.get("evdev_key", "KEY_GRAVE")
        # Delay destroy to let the js_bridge_call wrapper finish first
        threading.Timer(0.2, window.destroy).start()

    def close_window(self):
        threading.Timer(0.1, window.destroy).start()

    def upgrade(self):
        pass

import webview
api = Api()
window = webview.create_window("Alto", html=html, js_api=api,
                               width=460, height=530, resizable=False,
                               text_select=False)
webview.start()
print(json.dumps(result), flush=True)
'''


def _detect_next_key(timeout: float = 10.0) -> str:
    """Fallback key detection (used outside webview)."""
    try:
        import select
        import time
        import evdev
        from evdev import InputDevice, ecodes

        devices = []
        for path in evdev.list_devices():
            try:
                dev = InputDevice(path)
                if "alto" in dev.name.lower():
                    dev.close()
                    continue
                caps = dev.capabilities(verbose=False)
                if ecodes.EV_KEY in caps:
                    devices.append(dev)
            except (OSError, PermissionError):
                continue
        if not devices:
            return ""
        fd_map = {dev.fd: dev for dev in devices}
        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                r, _, _ = select.select(fd_map.keys(), [], [], 0.2)
                for fd in r:
                    dev = fd_map[fd]
                    for event in dev.read():
                        if event.type == ecodes.EV_KEY and event.value == 1 and event.code < 272:
                            from evdev import categorize
                            key_event = categorize(event)
                            name = key_event.keycode
                            if isinstance(name, (list, tuple)):
                                name = name[0]
                            return name
        finally:
            for dev in devices:
                try:
                    dev.close()
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"Key detection failed: {e}")
    return ""
