"""
Auto-update mechanism for Alto service.

Checks for new versions via PyPI and provides update notifications.
"""

import json
import logging
import ssl
import urllib.request
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

PYPI_PACKAGE_URL = "https://pypi.org/pypi/alto-dictation/json"


@dataclass
class UpdateInfo:
    """Information about available updates."""

    current_version: str
    latest_version: str
    update_available: bool
    update_instructions: str


class UpdateChecker:
    """Checks for updates via PyPI.

    Args:
        current_version: Current version of Alto.
        check_enabled: Whether to enable update checking.
    """

    def __init__(
        self,
        current_version: str,
        check_enabled: bool = True,
    ):
        self.current_version = current_version
        self.check_enabled = check_enabled

    def _get_pypi_version(self) -> Optional[str]:
        """Get the latest version from PyPI.

        Returns:
            Latest version string, or None if unavailable.
        """
        try:
            ctx = ssl.create_default_context()
            req = urllib.request.Request(
                PYPI_PACKAGE_URL,
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data.get("info", {}).get("version")
        except Exception as e:
            logger.debug(f"Failed to check PyPI for updates: {e}")
            return None

    def _compare_versions(self, current: str, latest: str) -> bool:
        """Compare two version strings.

        Args:
            current: Current version (e.g., "0.1.0").
            latest: Latest version (e.g., "0.2.0").

        Returns:
            True if latest is newer than current, False otherwise.
        """
        try:
            current_parts = [int(x) for x in current.split(".")]
            latest_parts = [int(x) for x in latest.split(".")]

            max_len = max(len(current_parts), len(latest_parts))
            current_parts += [0] * (max_len - len(current_parts))
            latest_parts += [0] * (max_len - len(latest_parts))

            return latest_parts > current_parts

        except (ValueError, AttributeError):
            logger.warning(
                f"Failed to compare versions: current={current}, latest={latest}"
            )
            return False

    def check_for_updates(self) -> Optional[UpdateInfo]:
        """Check for available updates.

        Returns:
            UpdateInfo object with update status, or None if check is disabled
            or failed.
        """
        if not self.check_enabled:
            logger.debug("Update checking is disabled")
            return None

        logger.info("Checking for updates...")

        latest_version = self._get_pypi_version()

        if latest_version is None:
            logger.debug("Could not determine latest version from PyPI")
            return None

        update_available = self._compare_versions(
            self.current_version, latest_version
        )

        if update_available:
            instructions = (
                f"New version available: {latest_version} (current: {self.current_version})\n\n"
                "To update Alto:\n"
                "  pip install --upgrade alto-dictation\n\n"
                "Then restart the Alto service:\n"
                "  systemctl --user restart alto"
            )
        else:
            instructions = f"Alto is up to date (version {self.current_version})"

        logger.info(
            f"Update check complete: current={self.current_version}, "
            f"latest={latest_version}, update_available={update_available}"
        )

        return UpdateInfo(
            current_version=self.current_version,
            latest_version=latest_version,
            update_available=update_available,
            update_instructions=instructions,
        )

    def perform_update(self) -> bool:
        """Run pipx upgrade to install the latest version.

        Returns True if upgrade succeeded.
        """
        import subprocess
        try:
            result = subprocess.run(
                ["pipx", "upgrade", "alto-dictation", "--pip-args=--no-cache-dir"],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0:
                logger.info(f"Update successful: {result.stdout.strip()}")
                return True
            else:
                logger.error(f"Update failed: {result.stderr.strip()}")
                return False
        except FileNotFoundError:
            # pipx not installed, try pip
            try:
                result = subprocess.run(
                    ["pip", "install", "--upgrade", "alto-dictation"],
                    capture_output=True, text=True, timeout=120,
                )
                if result.returncode == 0:
                    logger.info(f"Update via pip successful: {result.stdout.strip()}")
                    return True
                logger.error(f"Update via pip failed: {result.stderr.strip()}")
                return False
            except Exception as e:
                logger.error(f"Update failed: {e}")
                return False
        except Exception as e:
            logger.error(f"Update failed: {e}")
            return False

    def get_update_instructions(self, update_info: Optional[UpdateInfo] = None) -> str:
        if update_info is None:
            update_info = self.check_for_updates()

        if update_info is None:
            return (
                "Update check unavailable.\n\n"
                "To manually check for updates:\n"
                "  pip install --upgrade alto-dictation"
            )

        return update_info.update_instructions
