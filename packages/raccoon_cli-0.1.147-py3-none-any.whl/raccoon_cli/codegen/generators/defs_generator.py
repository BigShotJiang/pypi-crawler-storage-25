"""Generator for hardware definitions (defs.py)."""

from __future__ import annotations

import logging
import json
from typing import Any, Callable, Dict, List, Optional, Tuple

from .base import BaseGenerator
from ..builder import build_constructor_expr, build_literal_expr
from ..class_builder import ClassBuilder
from ..introspection import resolve_class
from ..yaml_resolver import create_hardware_resolver

logger = logging.getLogger("raccoon")

# SensorGroup field references (emitted as bare attribute names, not strings).
_SENSOR_GROUP_REF_KEYS = frozenset({"left", "right"})
# SensorGroup optional numeric parameters.
_SENSOR_GROUP_PARAM_KEYS = frozenset(
    {
        "threshold",
        "speed",
        "follow_speed",
        "follow_kp",
        "follow_ki",
        "follow_kd",
    }
)
# Extra keys on wait_for_light_sensor that are stripped from the hardware
# constructor and emitted as separate Defs class attributes instead.
_WFL_EXTRA_KEYS = frozenset({"mode", "drop_fraction"})

# Registry of handlers for special hardware types that cannot go through the
# standard yaml_resolver path.  Signature: (field_name, hw_cfg, all_defs, imports) -> expr_str
# Add new entries here instead of adding more if/elif branches in generate_body.
_SPECIAL_TYPE_BUILDERS: Dict[str, Callable] = {}


class _ImportProxy:
    """Minimal class-like object used when runtime imports lag behind stubs."""

    def __init__(self, module: str, name: str):
        self.__module__ = module
        self.__name__ = name


class DefsGenerator(BaseGenerator):
    """Generator for hardware definitions file (defs.py)."""

    def __init__(self, class_name: str = "Defs"):
        super().__init__(class_name)
        self.resolver = create_hardware_resolver()
        self._imu_class = self._resolve_import_class(
            ("raccoon.IMU", "raccoon.hal.IMU"), "raccoon", "IMU"
        )
        self._analog_sensor_class = self._resolve_import_class(
            ("raccoon.AnalogSensor", "raccoon.hal.AnalogSensor"),
            "raccoon",
            "AnalogSensor",
        )
        self._analog_sensor_fields: list[str] = []

    def get_output_filename(self) -> str:
        return "defs.py"

    @staticmethod
    def _resolve_import_class(
        candidates: Tuple[str, ...], fallback_module: str, fallback_name: str
    ) -> type:
        for qualname in candidates:
            try:
                return resolve_class(qualname)
            except ImportError:
                continue
        logger.info(
            "Could not resolve %s from runtime imports; using generated import fallback",
            fallback_name,
        )
        return _ImportProxy(fallback_module, fallback_name)  # type: ignore[return-value]

    def extract_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        definitions = config.get("definitions")
        if definitions is None:
            logger.warning("No 'definitions' key found in config")
            return {}
        if not isinstance(definitions, dict):
            raise ValueError("'definitions' must be a mapping")
        return definitions

    def validate_config(self, data: Dict[str, Any]) -> None:
        if not isinstance(data, dict):
            raise ValueError(
                "Top-level config must contain a mapping under key 'definitions:'"
            )

        for field_name, hw_cfg in data.items():
            if not isinstance(hw_cfg, dict):
                raise ValueError(f"definitions.{field_name} must be a mapping")

            if not field_name.isidentifier():
                raise ValueError(
                    f"definitions.{field_name}: not a valid Python identifier"
                )

            if "type" not in hw_cfg:
                raise ValueError(
                    f"definitions.{field_name}: missing required 'type' field"
                )

            if hw_cfg.get("type") == "SensorGroup":
                self._validate_sensor_group(field_name, hw_cfg, data)

        if "button" not in data:
            raise ValueError(
                "definitions.button is required. Add a DigitalSensor definition:\n"
                "  definitions:\n"
                "    button:\n"
                "      type: DigitalSensor\n"
                "      port: <port_number>"
            )

        button_cfg = data.get("button", {})
        if button_cfg.get("type") != "DigitalSensor":
            raise ValueError(
                f"definitions.button must be of type 'DigitalSensor', got '{button_cfg.get('type')}'"
            )

    def generate_body(self, data: Dict[str, Any]) -> str:
        self._analog_sensor_fields = []

        imu_cfg = data.get("imu", {})
        imu_params = {k: v for k, v in imu_cfg.items() if k != "type"}
        if imu_params:
            imu_expr = self._build_imu_expr(imu_params)
        else:
            imu_expr = "IMU()"
        self.imports.add(self._imu_class)

        attributes = [("imu", imu_expr)]
        wfl_extra_attrs: List[Tuple[str, str]] = []

        for field_name, hw_cfg in data.items():
            if field_name == "imu":
                continue

            logger.info(f"Processing definition: {field_name}")

            type_name = hw_cfg.get("type", "")

            special_builder = _SPECIAL_TYPE_BUILDERS.get(type_name)
            if special_builder is not None:
                hw_expr = special_builder(field_name, hw_cfg, data, self.imports)
                attributes.append((field_name, hw_expr))
                logger.info(f"Generated {type_name} '{field_name}'")
                continue

            preset_info = self._extract_servo_preset(hw_cfg)

            strip_keys = {"positions", "offset"}
            is_wfl_sensor = field_name == "wait_for_light_sensor"
            if is_wfl_sensor:
                strip_keys |= _WFL_EXTRA_KEYS

            resolved_cfg = {k: v for k, v in hw_cfg.items() if k not in strip_keys}
            try:
                hw_class, hw_params = self.resolver.resolve_from_config(
                    resolved_cfg, type_key="type"
                )
                logger.info(
                    f"Resolved type '{type_name}' to {hw_class.__name__} for {field_name}"
                )
            except ValueError as e:
                raise ValueError(f"definitions.{field_name}: {e}") from e

            if self._is_analog_sensor(hw_class):
                self._analog_sensor_fields.append(field_name)
                logger.info(f"Field '{field_name}' is an analog sensor")

            hw_expr = build_constructor_expr(
                hw_class, hw_params, f"definitions.{field_name}", self.imports
            )

            if preset_info is not None:
                positions, offset = preset_info
                hw_expr = self._build_servo_preset_expr(hw_expr, positions, offset)
                logger.info(
                    f"Wrapping '{field_name}' as ServoPreset with {len(positions)} positions (offset={offset})"
                )

            attributes.append((field_name, hw_expr))

            if is_wfl_sensor:
                wfl_mode = hw_cfg.get("mode", "auto")
                wfl_drop = hw_cfg.get("drop_fraction")
                wfl_extra_attrs.append(("wait_for_light_mode", f'"{wfl_mode}"'))
                if wfl_drop is not None:
                    wfl_extra_attrs.append(
                        (
                            "wait_for_light_drop_fraction",
                            build_literal_expr(float(wfl_drop)),
                        )
                    )
                logger.info(
                    f"WFL config: mode={wfl_mode}"
                    + (f", drop_fraction={wfl_drop}" if wfl_drop is not None else "")
                )

        analog_list = "[" + ", ".join(self._analog_sensor_fields) + "]"
        attributes.append(("analog_sensors", analog_list))
        attributes.extend(wfl_extra_attrs)

        return ClassBuilder.build_simple_class(self.class_name, attributes)

    @staticmethod
    def _extract_servo_preset(
        hw_cfg: Dict[str, Any],
    ) -> Optional[Tuple[Dict[str, float], float]]:
        """
        Check if a hardware definition includes servo preset positions.

        Returns:
            (positions_dict, offset) if positions are defined, None otherwise.
        """
        if hw_cfg.get("type") != "Servo":
            return None
        positions = hw_cfg.get("positions")
        if not positions or not isinstance(positions, dict):
            return None
        offset = float(hw_cfg.get("offset", 0))
        return positions, offset

    def _build_servo_preset_expr(
        self,
        servo_expr: str,
        positions: Dict[str, float],
        offset: float,
    ) -> str:
        preset_cls = self._resolve_import_class(
            ("raccoon.ServoPreset", "raccoon.step.servo.preset.ServoPreset"),
            "raccoon.step.servo.preset",
            "ServoPreset",
        )
        self.imports.add(preset_cls)
        positions_literal = json.dumps(positions)
        if offset:
            return f"ServoPreset({servo_expr}, positions={positions_literal}, offset={build_literal_expr(offset)})"
        return f"ServoPreset({servo_expr}, positions={positions_literal})"

    def _build_imu_expr(self, params: Dict[str, Any]) -> str:
        pieces = [
            f"{name}={build_literal_expr(value)}" for name, value in params.items()
        ]
        return "IMU(" + ", ".join(pieces) + ")"

    def _is_analog_sensor(self, hw_class: type) -> bool:
        try:
            return issubclass(hw_class, self._analog_sensor_class)
        except TypeError:
            return False

    @staticmethod
    def _validate_sensor_group(
        field_name: str, hw_cfg: Dict[str, Any], data: Dict[str, Any]
    ) -> None:
        if "left" not in hw_cfg and "right" not in hw_cfg:
            raise ValueError(
                f"definitions.{field_name}: "
                "SensorGroup must specify at least 'left' or 'right'"
            )
        hw_fields = {k for k in data if k != field_name}
        for side in ("left", "right"):
            ref = hw_cfg.get(side)
            if ref is not None and ref not in hw_fields:
                raise ValueError(
                    f"definitions.{field_name}.{side}: "
                    f"'{ref}' does not match any definition. "
                    f"Available: {', '.join(sorted(hw_fields))}"
                )

    def generate_footer(self) -> str:
        instance_name = self.class_name[0].lower() + self.class_name[1:]
        return (
            f"\n{instance_name} = {self.class_name}()\n"
            f"\n__all__ = ['{self.class_name}', '{instance_name}']\n"
        )

    def generate_imports(self) -> str:
        return super().generate_imports()


# ---------------------------------------------------------------------------
# Special-type handler functions — registered in _SPECIAL_TYPE_BUILDERS above.
# Add new entries here; never add if/elif branches inside generate_body.
# Signature: (field_name, hw_cfg, all_defs, imports) -> expr_str
# ---------------------------------------------------------------------------

def _build_sensor_group_expr(
    field_name: str, hw_cfg: Dict[str, Any], all_defs: Dict[str, Any], imports: Any
) -> str:
    sg_cls = DefsGenerator._resolve_import_class(
        ("raccoon.SensorGroup", "raccoon.step.motion.sensor_group.SensorGroup"),
        "raccoon.step.motion.sensor_group",
        "SensorGroup",
    )
    imports.add(sg_cls)
    pieces: List[str] = []
    for key in ("left", "right"):
        ref = hw_cfg.get(key)
        if ref is not None:
            pieces.append(f"{key}={ref}")
    for key in sorted(_SENSOR_GROUP_PARAM_KEYS):
        val = hw_cfg.get(key)
        if val is not None:
            pieces.append(f"{key}={build_literal_expr(val)}")
    return "SensorGroup(" + ", ".join(pieces) + ")"


def _build_arm_chain_expr(
    field_name: str, hw_cfg: Dict[str, Any], all_defs: Dict[str, Any], imports: Any
) -> str:
    from .arm_chain_generator import ArmChainGenerator  # noqa: PLC0415
    return ArmChainGenerator(field_name, hw_cfg, all_defs, imports).build_expr()


_SPECIAL_TYPE_BUILDERS["SensorGroup"] = _build_sensor_group_expr
_SPECIAL_TYPE_BUILDERS["ArmChain"] = _build_arm_chain_expr
