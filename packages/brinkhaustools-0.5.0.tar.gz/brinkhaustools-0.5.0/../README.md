# brinkhaustools

Multi-language infrastructure toolkit for Brinkhaus industrial applications.

## What is brinkhaustools?

`brinkhaustools` provides reusable components for industrial monitoring and control applications in **Python**, **Rust**, **JavaScript**, and **C++**. All variants share the same version number and are wire-compatible with [BrinkhausFleetManager](https://fleetmanager-website.brinkhaus-gmbh.de).

Core components (available in all variants):

- **App** -- central wiring object that connects all components
- **ShutdownHandler** -- graceful shutdown with signal handling
- **Settings** -- thread-safe JSON settings with hierarchical dot-notation access
- **SelfDiagnosisEngine** -- error/warning tracking with numeric codes
- **StatusEngine** -- periodic status collection from pluggable sources
- **HeartbeatEngine** -- watchdog for detecting hung threads
- **VersionInformation** -- CI-generated version metadata
- **Fleet management** -- HTTPS-based reporting to BrinkhausFleetManager

Additionally, the Python variant includes a **RestServer** (Flask + Waitress).

## Installation

### Python

```bash
pip install brinkhaustools
# With REST server support:
pip install brinkhaustools[rest]
```

**Requirements:** Python >= 3.10. The core has no external dependencies.

### Rust

```toml
# Cargo.toml
[dependencies]
brinkhaustools = "0.4"
# With fleet management client:
brinkhaustools = { version = "0.4", features = ["fleet"] }
```

### JavaScript

Include `js/src/brinkhaus-tools.js` from the repository. Zero dependencies, browser-compatible.

```bash
git clone https://gitlab.com/brinkhaus/brinkhaustools.git
# Use js/src/brinkhaus-tools.js in your project
```

### C++

```cmake
# CMakeLists.txt
include(FetchContent)
FetchContent_Declare(
    brinkhaustools
    GIT_REPOSITORY https://gitlab.com/brinkhaus/brinkhaustools.git
    GIT_TAG        0.4.0
    SOURCE_SUBDIR  cpp
)
FetchContent_MakeAvailable(brinkhaustools)
target_link_libraries(myapp PRIVATE brinkhaustools::brinkhaustools)
```

## Quick Examples

### Python

```python
from brinkhaustools.common import App

app = App(
    name="my-service",
    settings_path="data/settings/settings_main.json",
    fleet_config_path="fleetManagementData/config.json",
)
app.start()
app.wait()
```

### Rust

```rust
use brinkhaustools::App;

let app = App::builder("my-service")
    .settings("data/settings/settings_main.json")
    .build();
app.start();
app.wait();
```

## Documentation

Full API reference, guides, and configuration details:

**[brinkhaus.gitlab.io/brinkhaustools](https://brinkhaus.gitlab.io/brinkhaustools)**

## License

MIT
