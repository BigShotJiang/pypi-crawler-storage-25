"""Brinkhaus Tools – common utilities for Brinkhaus industrial applications."""

__version__ = "0.4.0"
