"""JSON-based hierarchical settings manager.

Supports access via key lists (``["section", "key"]``) and dot-notation
(``"section.key"``).  Thread-safe, auto-creates missing keys, and persists
to disk with atomic write + two-generation backup.

Crash-safety hardening (added 2026-04-23 after GMN power-off loss reports)
-------------------------------------------------------------------------
In addition to temp-file + fsync + rename + directory-fsync + two backups,
this module now also:

* Writes an ``__integrity__`` trailer (sha256 over the rest of the dict) on
  every save.  On load, if the trailer is present but does not match, the
  file is treated as corrupt and the recovery chain (``.bak`` → ``.bak2``)
  runs.  This catches silent truncation that still parses as JSON.
* Tracks *where* reload got its data from (:attr:`recovered_from`).
* When reload ends up with an empty ``{}`` because all three files were
  unreadable, a ``__data_loss__`` breadcrumb is written into the dict
  and immediately persisted.  Normal auto-save stays enabled so the
  device keeps running; the breadcrumb survives reboots and is the
  signal that application-level self-diagnosis consumes to surface a
  critical message until an operator clears it.  The breadcrumb is
  *not* auto-created by :meth:`get`: consumers must use
  :meth:`has_data_loss_flag` / :meth:`exist`.
* After a successful fallback to ``.bak`` / ``.bak2``, the data is
  written back through the normal save flow so the main/backup chain
  is rebuilt.  (Backup recovery does not set the breadcrumb.)
"""

import hashlib
import json
import logging
import os
import threading
import time
from typing import Any, Dict, List, Optional, Tuple, Union

log = logging.getLogger(__name__)

KeyElement = Union[int, str]
KeyPath = Union[List[KeyElement], str]

INTEGRITY_KEY = "__integrity__"
INTEGRITY_ALGO = "sha256-v1"

# Breadcrumb written at the root of the settings dict when reload() finds
# all three on-disk files unusable.  Operators clear it via
# :meth:`Settings.clear_data_loss_flag` (or by deleting it manually).
DATA_LOSS_KEY = "__data_loss__"

# Keys that are library-controlled: stripped from payloads delivered via
# load_json() and never exposed via normal iteration helpers.
_RESERVED_KEYS = (INTEGRITY_KEY, DATA_LOSS_KEY)

# Possible values of :attr:`Settings.recovered_from`.
RECOVERED_PRIMARY = "primary"
RECOVERED_BAK = "bak"
RECOVERED_BAK2 = "bak2"
RECOVERED_FRESH = "fresh"  # no file ever existed — first run, not a data-loss event
RECOVERED_EMPTY_FALLBACK = "empty_fallback"  # at least one file existed but all unreadable
RECOVERED_UNLOADED = "unloaded"

# Return codes from _try_load.
_LOAD_OK = "ok"
_LOAD_MISSING = "missing"
_LOAD_CORRUPT = "corrupt"


def _parse_key(key: KeyPath) -> List[KeyElement]:
    """Normalise a key to a list.

    Accepts either a list (``["a", "b", 0]``) or a dot-separated string
    (``"a.b.0"``).  Numeric segments in dot-notation are converted to int
    so they work as array indices.
    """
    if isinstance(key, list):
        return key
    parts: List[KeyElement] = []
    for segment in key.split("."):
        try:
            parts.append(int(segment))
        except ValueError:
            parts.append(segment)
    return parts


def _canonical_hash(payload: Any) -> str:
    """Stable sha256 of a JSON-serialisable object (without the integrity key)."""
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class Settings:
    """Thread-safe JSON settings with hierarchical key access.

    Parameters
    ----------
    file_path : str or None
        Path to the JSON file.  If *None*, settings live in memory only
        (no persistence).
    auto_save : bool
        When *True* (default), every mutation automatically persists to
        disk.
    """

    _instances: Dict[str, "Settings"] = {}

    def __init__(
        self,
        file_path: Optional[str] = None,
        auto_save: bool = True,
    ) -> None:
        self.file_path = file_path
        self.auto_save = auto_save
        self._json: Any = {}
        self._lock = threading.RLock()
        self.recovered_from: str = RECOVERED_UNLOADED

        if file_path is not None:
            parent = os.path.dirname(file_path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            self.reload()

    # ------------------------------------------------------------------
    # Singleton / named instances
    # ------------------------------------------------------------------
    @staticmethod
    def get_instance(name: str = "main", file_path: Optional[str] = None) -> "Settings":
        """Return a named singleton.  Created on first call with *file_path*."""
        if name not in Settings._instances:
            if file_path is None:
                file_path = f"data/settings/settings_{name}.json"
            Settings._instances[name] = Settings(file_path)
        return Settings._instances[name]

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------
    def save(self) -> None:
        """Persist settings to disk using atomic write + two-generation backup.

        Safety properties
        -----------------
        * The temp file is fsynced before any rename, so a crash during the
          write leaves the previous main file and ``.bak`` intact.
        * The parent directory is fsynced after the final rename so the new
          directory entry survives a power failure on ext4/xfs.
        * Two backup generations are kept (``.bak`` and ``.bak2``), so a crash
          during a second consecutive save cannot destroy both backups.
        * An ``__integrity__`` trailer (sha256 + size + timestamp) is added
          at the root so silent truncation that still parses as JSON is
          detected on next load.
        """
        if self.file_path is None:
            return
        with self._lock:
            log.info("Saving settings to %s", self.file_path)
            tmp = self.file_path + ".tmp"
            bak = self.file_path + ".bak"
            bak2 = self.file_path + ".bak2"
            parent = os.path.dirname(os.path.abspath(self.file_path))

            payload = self._with_integrity_trailer(self._json)

            try:
                with open(tmp, "w") as f:
                    json.dump(payload, f, indent=4)
                    f.flush()
                    os.fsync(f.fileno())
            except Exception:
                log.warning("Could not write temp file %s", tmp)
                if os.path.exists(tmp):
                    try:
                        os.remove(tmp)
                    except Exception:
                        pass
                return

            try:
                # Rotate backups: existing .bak → .bak2, then current file → .bak
                if os.path.exists(bak):
                    if os.path.exists(bak2):
                        os.remove(bak2)
                    os.rename(bak, bak2)
                if os.path.exists(self.file_path):
                    os.rename(self.file_path, bak)
                os.rename(tmp, self.file_path)
                # Flush the new directory entry so the rename survives power loss
                dir_fd = os.open(parent, os.O_RDONLY)
                try:
                    os.fsync(dir_fd)
                finally:
                    os.close(dir_fd)
            except Exception:
                log.warning("Error replacing settings file %s", self.file_path)

    def reload(self) -> None:
        """Reload settings from disk, falling back through .bak and .bak2.

        A file is considered *usable* only if it parses as JSON **and**,
        when an ``__integrity__`` trailer is present, the trailer matches
        the rest of the data.  Files without a trailer are accepted for
        backward compatibility (they will gain one on the next save).

        If the main file is unusable but a backup is, the recovered data
        is written back through :meth:`save` so the main + backup chain
        is rebuilt.

        Outcomes:

        * All three files missing (never existed): fresh start, empty
          dict, auto-save enabled.  This is the normal first-run case.
        * At least one file existed but none were usable: DATA LOSS.
          A ``__data_loss__`` breadcrumb is written into the dict and
          immediately persisted so application-level self-diagnosis can
          surface a critical message on every subsequent boot until an
          operator explicitly clears it.  Normal auto-save continues.
        """
        if self.file_path is None:
            return
        with self._lock:
            log.info("Loading settings from %s", self.file_path)
            bak = self.file_path + ".bak"
            bak2 = self.file_path + ".bak2"

            data, status = self._try_load(self.file_path)
            if status == _LOAD_OK:
                self._json = data
                self.recovered_from = RECOVERED_PRIMARY
                return
            primary_status = status

            data, status = self._try_load(bak)
            if status == _LOAD_OK:
                self._json = data
                self.recovered_from = RECOVERED_BAK
                log.warning(
                    "Loaded settings from first-generation backup %s — "
                    "rebuilding main + backup chain",
                    bak,
                )
                self._self_heal_after_backup_load()
                return
            bak_status = status

            data, status = self._try_load(bak2)
            if status == _LOAD_OK:
                self._json = data
                self.recovered_from = RECOVERED_BAK2
                log.warning(
                    "Loaded settings from second-generation backup %s — "
                    "rebuilding main + backup chain",
                    bak2,
                )
                self._self_heal_after_backup_load()
                return
            bak2_status = status

            self._json = {}
            all_missing = (
                primary_status == _LOAD_MISSING
                and bak_status == _LOAD_MISSING
                and bak2_status == _LOAD_MISSING
            )
            if all_missing:
                log.info(
                    "No settings file at %s — starting fresh", self.file_path
                )
                self.recovered_from = RECOVERED_FRESH
                return

            log.critical(
                "All settings files unreadable (%s, .bak, .bak2) — "
                "starting with empty settings. This is a data-loss event. "
                "Leaving __data_loss__ breadcrumb for self-diagnosis.",
                self.file_path,
            )
            self.recovered_from = RECOVERED_EMPTY_FALLBACK
            self._json[DATA_LOSS_KEY] = {
                "detected_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "main_status": primary_status,
                "bak_status": bak_status,
                "bak2_status": bak2_status,
            }
            # Persist immediately so the breadcrumb is durable even if the
            # process dies before the first get()/set().  This also creates
            # a valid primary file with an integrity trailer; the old
            # corrupt files rotate into .bak/.bak2 and are overwritten on
            # subsequent saves.
            try:
                self.save()
            except Exception:
                log.warning(
                    "Could not persist __data_loss__ breadcrumb — "
                    "it will be retried on the next save"
                )

    # ------------------------------------------------------------------
    # Read / write
    # ------------------------------------------------------------------
    def get(self, key: KeyPath, default: Any = None) -> Any:
        """Get a value by key path, auto-creating it with *default* if missing.

        Type compatibility is checked: if the stored type differs from the
        default's type (and they are not both numeric), the default wins.
        """
        key_list = _parse_key(key)
        try:
            with self._lock:
                node = self._json
                for i, k in enumerate(key_list):
                    is_last = i == len(key_list) - 1

                    if is_last:
                        return self._get_leaf(node, k, default, key_list)
                    else:
                        node = self._traverse(node, k, key_list, i)
        except Exception:
            log.warning("Could not access value with key %s", key_list)
        return default

    def set(self, key: KeyPath, value: Any) -> None:
        """Set a value by key path, auto-creating intermediate nodes."""
        key_list = _parse_key(key)
        try:
            with self._lock:
                node = self._json
                for i, k in enumerate(key_list):
                    is_last = i == len(key_list) - 1

                    if is_last:
                        self._set_leaf(node, k, value)
                    else:
                        node = self._traverse(node, k, key_list, i)
        except Exception:
            log.warning("Could not set value for key %s", key_list)

    def exist(self, key: KeyPath) -> bool:
        """Return *True* if the key path exists."""
        key_list = _parse_key(key)
        try:
            with self._lock:
                node = self._json
                for i, k in enumerate(key_list):
                    is_last = i == len(key_list) - 1
                    if isinstance(k, int):
                        if not isinstance(node, list) or len(node) <= k:
                            return False
                        if is_last:
                            return True
                        node = node[k]
                    else:
                        if not isinstance(node, dict) or k not in node:
                            return False
                        if is_last:
                            return True
                        node = node[k]
        except Exception:
            pass
        return False

    def length(self, key: KeyPath) -> int:
        """Return the length of a list/dict at the given key, or -1."""
        key_list = _parse_key(key)
        try:
            with self._lock:
                node = self._json
                for k in key_list:
                    if isinstance(k, int):
                        if not isinstance(node, list) or len(node) <= k:
                            return -1
                        node = node[k]
                    else:
                        if not isinstance(node, dict) or k not in node:
                            return -1
                        node = node[k]
                return len(node)
        except Exception:
            pass
        return -1

    def delete_key(self, key: KeyPath) -> bool:
        """Delete the value at key path.  Returns *True* on success."""
        key_list = _parse_key(key)
        if not self.exist(key_list):
            return False
        try:
            with self._lock:
                node = self._json
                for k in key_list[:-1]:
                    node = node[k]
                last = key_list[-1]
                if isinstance(last, int) and isinstance(node, list):
                    del node[last]
                elif isinstance(node, dict) and last in node:
                    del node[last]
                else:
                    return False
                if self.auto_save:
                    self.save()
                return True
        except Exception:
            log.warning("Could not delete key %s", key_list)
        return False

    def move_key(self, old_key: KeyPath, new_key: KeyPath) -> bool:
        """Move a value from *old_key* to *new_key*."""
        old_list = _parse_key(old_key)
        new_list = _parse_key(new_key)
        if not self.exist(old_list):
            return False
        if self.exist(new_list):
            return False
        value = self.get(old_list)
        self.delete_key(old_list)
        self.set(new_list, value)
        return True

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------
    def to_json(self) -> str:
        """Return the full settings as a formatted JSON string."""
        with self._lock:
            return json.dumps(self._json, indent=4)

    def load_json(self, json_string: str) -> None:
        """Replace settings from a JSON string, then persist.

        Reserved keys (``__integrity__``, ``__data_loss__``) are stripped
        from the incoming payload — they are library-controlled and must
        not be set by clients.  Any existing ``__data_loss__`` breadcrumb
        is carried forward so a partial UI save cannot silently hide the
        warning; it is cleared only by :meth:`clear_data_loss_flag`.
        """
        with self._lock:
            try:
                parsed = json.loads(json_string)
            except Exception:
                log.warning("Could not parse JSON string for settings")
                return
            if isinstance(parsed, dict):
                for reserved in _RESERVED_KEYS:
                    parsed.pop(reserved, None)
            existing_breadcrumb = None
            if isinstance(self._json, dict):
                existing_breadcrumb = self._json.get(DATA_LOSS_KEY)
            self._json = parsed
            if existing_breadcrumb is not None and isinstance(self._json, dict):
                self._json[DATA_LOSS_KEY] = existing_breadcrumb
            self.save()

    # ------------------------------------------------------------------
    # Data-loss breadcrumb API
    # ------------------------------------------------------------------
    def has_data_loss_flag(self) -> bool:
        """Return *True* if the ``__data_loss__`` breadcrumb is present."""
        with self._lock:
            return isinstance(self._json, dict) and DATA_LOSS_KEY in self._json

    def data_loss_info(self) -> Optional[Dict[str, Any]]:
        """Return the breadcrumb dict, or *None* if no data-loss flag is set."""
        with self._lock:
            if isinstance(self._json, dict):
                info = self._json.get(DATA_LOSS_KEY)
                if isinstance(info, dict):
                    return dict(info)
            return None

    def clear_data_loss_flag(self) -> None:
        """Remove the breadcrumb and persist.

        Call this after the operator has acknowledged the data-loss
        event (e.g. via a UI confirmation).  Because :meth:`get` never
        auto-creates the breadcrumb, it stays cleared unless a fresh
        data-loss event occurs.
        """
        with self._lock:
            if isinstance(self._json, dict) and DATA_LOSS_KEY in self._json:
                del self._json[DATA_LOSS_KEY]
                log.info(
                    "Cleared __data_loss__ breadcrumb for %s", self.file_path
                )
                self.save()

    def get_value_from_env(
        self,
        env_name: str,
        key: KeyPath,
        default: Any,
    ) -> Any:
        """Read from environment variable, falling back to settings/default."""
        val = os.environ.get(env_name)
        if val is not None:
            self.set(key, val)
            return val
        return self.get(key, default)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    def _try_load(self, path: str) -> Tuple[Any, str]:
        """Attempt to load *path*, verifying the integrity trailer if present.

        Returns ``(payload, status)``:
          * ``(dict, _LOAD_OK)`` on success,
          * ``(None, _LOAD_MISSING)`` if the file does not exist,
          * ``(None, _LOAD_CORRUPT)`` on parse error, integrity mismatch,
            or any other read failure.
        """
        try:
            with open(path) as f:
                data = json.load(f)
        except FileNotFoundError:
            log.debug("Settings file %s does not exist", path)
            return None, _LOAD_MISSING
        except Exception as exc:
            log.warning("Could not parse %s: %s", path, exc)
            return None, _LOAD_CORRUPT

        if isinstance(data, dict) and INTEGRITY_KEY in data:
            trailer = data.pop(INTEGRITY_KEY)
            if not self._verify_trailer(data, trailer, path):
                return None, _LOAD_CORRUPT
        return data, _LOAD_OK

    @staticmethod
    def _verify_trailer(payload: Any, trailer: Any, path: str) -> bool:
        """Return True if *trailer* matches the hash of *payload*."""
        if not isinstance(trailer, dict):
            log.warning("Integrity trailer in %s is not a dict — ignoring file", path)
            return False
        algo = trailer.get("algo")
        expected = trailer.get("sha256")
        if algo != INTEGRITY_ALGO or not isinstance(expected, str):
            # Unknown algorithm: accept the file rather than lose data for
            # a future-compatible format we don't understand yet.
            log.info(
                "Integrity trailer in %s uses unknown algo %r — skipping verification",
                path,
                algo,
            )
            return True
        actual = _canonical_hash(payload)
        if actual != expected:
            log.warning(
                "Integrity check FAILED for %s (expected %s, got %s) — "
                "treating as corrupt, falling through to backup",
                path,
                expected,
                actual,
            )
            return False
        return True

    @staticmethod
    def _with_integrity_trailer(payload: Any) -> Any:
        """Return a shallow copy of *payload* with an ``__integrity__`` key."""
        if not isinstance(payload, dict):
            # Trailer only applies to dict roots.  Everything we persist is a
            # dict at the root, but guard just in case.
            return payload
        # Exclude any pre-existing trailer from the hash input so round-trip
        # is stable even if the caller kept a stale one in memory.
        base = {k: v for k, v in payload.items() if k != INTEGRITY_KEY}
        trailer = {
            "algo": INTEGRITY_ALGO,
            "sha256": _canonical_hash(base),
            "size": len(base),
            "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        return {**base, INTEGRITY_KEY: trailer}

    def _self_heal_after_backup_load(self) -> None:
        """Rebuild the main + backup chain after a successful backup fallback.

        Called from :meth:`reload` when ``.bak`` or ``.bak2`` provided the
        data.  We go through the normal save path so the caller does not
        lose the backup-recovery state on the next legitimate save.
        """
        try:
            self.save()
        except Exception:
            log.warning(
                "Self-heal save failed for %s — chain remains degraded",
                self.file_path,
            )

    def _traverse(self, node: Any, k: KeyElement, key_list: list, idx: int) -> Any:
        """Navigate one level deeper, auto-creating missing nodes."""
        next_is_int = isinstance(key_list[idx + 1], int)
        if isinstance(k, int):
            while isinstance(node, list) and len(node) <= k:
                node.append({})
            return node[k]
        else:
            if k not in node:
                node[k] = [] if next_is_int else {}
            return node[k]

    def _get_leaf(self, node: Any, k: KeyElement, default: Any, key_list: list) -> Any:
        """Read or auto-create the leaf value."""
        if isinstance(k, int):
            if isinstance(node, list) and len(node) > k:
                stored = node[k]
                if not self._types_compatible(stored, default):
                    node[k] = default
                    if self.auto_save:
                        self.save()
                    return default
                return stored
            # Auto-create
            if isinstance(node, list):
                node.append(default)
            if self.auto_save:
                self.save()
            return default
        else:
            if k in node:
                stored = node[k]
                if not self._types_compatible(stored, default):
                    node[k] = default
                    if self.auto_save:
                        self.save()
                    return default
                return stored
            node[k] = default
            if self.auto_save:
                self.save()
            return default

    def _set_leaf(self, node: Any, k: KeyElement, value: Any) -> None:
        """Write a leaf value."""
        if isinstance(k, int):
            if isinstance(node, list):
                while len(node) <= k:
                    node.append(None)
                if node[k] != value:
                    node[k] = value
                    if self.auto_save:
                        self.save()
            return
        if k not in node or node[k] != value:
            node[k] = value
            if self.auto_save:
                self.save()

    @staticmethod
    def _types_compatible(stored: Any, default: Any) -> bool:
        if default is None:
            return True
        if isinstance(stored, (int, float)) and isinstance(default, (int, float)):
            return True
        return type(stored) is type(default)
