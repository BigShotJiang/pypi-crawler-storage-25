"""Tests for Settings."""

import json
import logging
import os
import shutil
import tempfile
from unittest.mock import patch

from brinkhaustools.common.settings import (
    DATA_LOSS_KEY,
    INTEGRITY_KEY,
    RECOVERED_BAK,
    RECOVERED_BAK2,
    RECOVERED_EMPTY_FALLBACK,
    RECOVERED_FRESH,
    RECOVERED_PRIMARY,
    Settings,
)


def _make_settings(initial: dict = None) -> tuple:
    """Create a Settings instance backed by a temp file.

    When *initial* is ``None`` the temp file is deleted so the Settings
    instance sees a genuine "fresh" start (no file has ever existed)
    rather than a zero-byte corrupt file.
    """
    fd, path = tempfile.mkstemp(suffix=".json")
    os.close(fd)
    if initial:
        with open(path, "w") as f:
            json.dump(initial, f)
    else:
        os.unlink(path)
    s = Settings(file_path=path)
    return s, path


def test_get_creates_missing_key():
    s, path = _make_settings()
    val = s.get(["section", "key"], "hello")
    assert val == "hello"
    # Should be persisted
    with open(path) as f:
        data = json.load(f)
    assert data["section"]["key"] == "hello"
    os.unlink(path)


def test_get_returns_existing_value():
    s, path = _make_settings({"section": {"key": "world"}})
    val = s.get(["section", "key"], "default")
    assert val == "world"
    os.unlink(path)


def test_set_and_get():
    s, path = _make_settings()
    s.set(["a", "b"], 42)
    assert s.get(["a", "b"], 0) == 42
    os.unlink(path)


def test_dot_notation():
    s, path = _make_settings({"level1": {"level2": "value"}})
    assert s.get("level1.level2", "x") == "value"
    s.set("level1.new_key", 123)
    assert s.get("level1.new_key", 0) == 123
    os.unlink(path)


def test_array_access():
    s, path = _make_settings({"items": [{"name": "a"}, {"name": "b"}]})
    assert s.get(["items", 0, "name"], "") == "a"
    assert s.get(["items", 1, "name"], "") == "b"
    os.unlink(path)


def test_exist():
    s, path = _make_settings({"a": {"b": 1}})
    assert s.exist(["a", "b"])
    assert s.exist("a.b")
    assert not s.exist(["a", "c"])
    assert not s.exist("a.c")
    os.unlink(path)


def test_length():
    s, path = _make_settings({"items": [1, 2, 3]})
    assert s.length(["items"]) == 3
    assert s.length(["nonexistent"]) == -1
    os.unlink(path)


def test_delete_key():
    s, path = _make_settings({"a": {"b": 1, "c": 2}})
    assert s.delete_key(["a", "b"])
    assert not s.exist(["a", "b"])
    assert s.exist(["a", "c"])
    os.unlink(path)


def test_move_key():
    s, path = _make_settings({"old": {"key": "val"}})
    assert s.move_key(["old", "key"], ["new", "key"])
    assert not s.exist(["old", "key"])
    assert s.get(["new", "key"], "") == "val"
    os.unlink(path)


def test_reload():
    s, path = _make_settings({"x": 1})
    # Modify file externally
    with open(path, "w") as f:
        json.dump({"x": 99}, f)
    s.reload()
    assert s.get(["x"], 0) == 99
    os.unlink(path)


def test_to_json_and_load_json():
    s, path = _make_settings({"a": 1})
    j = s.to_json()
    data = json.loads(j)
    assert data["a"] == 1

    s.load_json('{"b": 2}')
    assert s.get(["b"], 0) == 2
    assert not s.exist(["a"])
    os.unlink(path)


def test_type_compatibility():
    s, path = _make_settings({"val": 42})
    # int stored, float default → compatible
    assert s.get(["val"], 0.0) == 42
    # int stored, str default → incompatible, default wins
    assert s.get(["val"], "x") == "x"
    os.unlink(path)


def test_in_memory_only():
    s = Settings(file_path=None)
    s.set(["key"], "value")
    assert s.get(["key"], "") == "value"


def test_dot_notation_with_array_index():
    s, path = _make_settings({"items": ["a", "b", "c"]})
    assert s.get("items.1", "") == "b"
    os.unlink(path)


def test_get_value_from_env(monkeypatch):
    s, path = _make_settings()
    monkeypatch.setenv("TEST_VAR_123", "from_env")
    val = s.get_value_from_env("TEST_VAR_123", ["env_key"], "fallback")
    assert val == "from_env"
    # Falls back when env not set
    val2 = s.get_value_from_env("NONEXISTENT_VAR_XYZ", ["other_key"], "default_val")
    assert val2 == "default_val"
    os.unlink(path)


# ---------------------------------------------------------------------------
# Crash-safety and fallback tests (added after GMN incident 2026-03-03)
# ---------------------------------------------------------------------------
# These use a temp directory rather than mkstemp because each scenario
# involves multiple sibling files (.bak, .bak2, .tmp).

def _tmpdir_path() -> tuple:
    """Return (tmpdir, settings_path) — caller must shutil.rmtree(tmpdir)."""
    d = tempfile.mkdtemp()
    return d, os.path.join(d, "settings.json")


def test_fallback_to_empty_when_both_files_corrupted():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("NOT VALID JSON")
        with open(path + ".bak", "w") as f:
            f.write("NOT VALID JSON")
        s = Settings(file_path=path)
        # Breadcrumb is expected; everything else empty.
        assert set(s._json.keys()) == {DATA_LOSS_KEY}
    finally:
        shutil.rmtree(d)


def test_fallback_to_bak2_when_main_and_bak_corrupted():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("NOT VALID JSON")
        with open(path + ".bak", "w") as f:
            f.write("NOT VALID JSON")
        with open(path + ".bak2", "w") as f:
            json.dump({"recovered": True}, f)
        s = Settings(file_path=path)
        assert s._json == {"recovered": True}
    finally:
        shutil.rmtree(d)


def test_fallback_does_not_auto_save_empty_dict():
    d, path = _tmpdir_path()
    try:
        # No files on disk — all three opens fail, fallback to {}
        Settings(file_path=path)
        assert not os.path.exists(path), (
            "reload() must not call save() on empty-dict fallback"
        )
    finally:
        shutil.rmtree(d)


def test_fallback_logs_at_critical(caplog):
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("NOT VALID JSON")
        with open(path + ".bak", "w") as f:
            f.write("NOT VALID JSON")
        with caplog.at_level(logging.DEBUG, logger="brinkhaustools.common.settings"):
            Settings(file_path=path)
        assert any(r.levelno >= logging.CRITICAL for r in caplog.records)
    finally:
        shutil.rmtree(d)


def test_fsync_called_on_save():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)
        s.auto_save = False
        with patch("brinkhaustools.common.settings.os.fsync") as mock_fsync:
            s.save()
        assert mock_fsync.called
    finally:
        shutil.rmtree(d)


def test_fsync_called_on_parent_directory():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)
        s.auto_save = False
        calls = []
        real_fsync = os.fsync
        with patch("brinkhaustools.common.settings.os.fsync",
                   side_effect=lambda fd: (calls.append(fd), real_fsync(fd))):
            s.save()
        assert len(calls) >= 2, "Expected fsync on both file fd and directory fd"
    finally:
        shutil.rmtree(d)


def test_two_backup_generations_after_consecutive_saves():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            json.dump({"v": 0}, f)
        s = Settings(file_path=path)
        s.auto_save = False
        s._json = {"v": 1}
        s.save()   # .bak = v0, main = v1
        s._json = {"v": 2}
        s.save()   # .bak2 = v0, .bak = v1, main = v2
        assert os.path.exists(path + ".bak2")
        with open(path + ".bak2") as f:
            assert json.load(f)["v"] == 0
        with open(path + ".bak") as f:
            assert json.load(f)["v"] == 1
        with open(path) as f:
            assert json.load(f)["v"] == 2
    finally:
        shutil.rmtree(d)


def test_partial_tmp_write_leaves_main_and_bak_intact():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            json.dump({"v": "good"}, f)
        s = Settings(file_path=path)
        s.auto_save = False
        s.save()   # creates .bak
        with open(path) as f:
            good_main = json.load(f)
        with open(path + ".bak") as f:
            good_bak = json.load(f)

        def partial_dump(obj, fp, **kwargs):
            fp.write('{"partial":')
            raise OSError("simulated power loss mid-write")

        with patch("brinkhaustools.common.settings.json.dump", side_effect=partial_dump):
            s._json = {"v": "new"}
            s.save()

        with open(path) as f:
            assert json.load(f) == good_main
        with open(path + ".bak") as f:
            assert json.load(f) == good_bak
        assert not os.path.exists(path + ".tmp")
    finally:
        shutil.rmtree(d)


def test_stale_tmp_does_not_affect_reload():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            json.dump({"v": "good"}, f)
        with open(path + ".tmp", "w") as f:
            f.write("GARBAGE")
        s = Settings(file_path=path)
        assert s._json == {"v": "good"}
    finally:
        shutil.rmtree(d)


# ---------------------------------------------------------------------------
# Integrity trailer + degraded-mode tests (added 2026-04-23)
# ---------------------------------------------------------------------------

def test_save_writes_integrity_trailer():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)
        s.auto_save = False
        s._json = {"a": 1, "b": [1, 2, 3]}
        s.save()
        with open(path) as f:
            data = json.load(f)
        assert INTEGRITY_KEY in data
        trailer = data[INTEGRITY_KEY]
        assert trailer["algo"] == "sha256-v1"
        assert isinstance(trailer["sha256"], str) and len(trailer["sha256"]) == 64
    finally:
        shutil.rmtree(d)


def test_integrity_trailer_is_stripped_on_load():
    d, path = _tmpdir_path()
    try:
        s1 = Settings(file_path=path)
        s1.auto_save = False
        s1._json = {"real_key": "real_value"}
        s1.save()

        s2 = Settings(file_path=path)
        assert s2._json == {"real_key": "real_value"}
        assert INTEGRITY_KEY not in s2._json
    finally:
        shutil.rmtree(d)


def test_integrity_mismatch_falls_back_to_bak():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)
        s.auto_save = False
        s._json = {"good": "bak_value"}
        s.save()  # main v1
        s._json = {"good": "main_value"}
        s.save()  # main v2, bak = v1

        # Tamper with the main file: keep JSON valid, change a value.
        with open(path) as f:
            tampered = json.load(f)
        tampered["good"] = "TAMPERED"
        with open(path, "w") as f:
            json.dump(tampered, f)

        s2 = Settings(file_path=path)
        assert s2._json == {"good": "bak_value"}
        assert s2.recovered_from == RECOVERED_BAK
    finally:
        shutil.rmtree(d)


def test_file_without_trailer_is_accepted_for_backcompat():
    d, path = _tmpdir_path()
    try:
        # Pre-existing file without integrity trailer (installed by seed/image).
        with open(path, "w") as f:
            json.dump({"legacy": "ok"}, f)
        s = Settings(file_path=path)
        assert s._json == {"legacy": "ok"}
        assert s.recovered_from == RECOVERED_PRIMARY
    finally:
        shutil.rmtree(d)


def test_fresh_start_does_not_set_data_loss_flag():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)
        assert s.recovered_from == RECOVERED_FRESH
        assert s.auto_save is True
        assert s.has_data_loss_flag() is False
        # get() with default auto-creates and persists.
        s.get(["section", "key"], "hello")
        with open(path) as f:
            data = json.load(f)
        assert DATA_LOSS_KEY not in data
    finally:
        shutil.rmtree(d)


def test_empty_fallback_writes_data_loss_breadcrumb_and_persists():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("CORRUPT")
        with open(path + ".bak", "w") as f:
            f.write("CORRUPT")
        s = Settings(file_path=path)
        assert s.recovered_from == RECOVERED_EMPTY_FALLBACK
        assert s.auto_save is True  # never blocked
        assert s.has_data_loss_flag() is True

        info = s.data_loss_info()
        assert info is not None
        assert info["main_status"] == "corrupt"
        assert info["bak_status"] == "corrupt"
        assert info["bak2_status"] == "missing"
        assert info["detected_at"].endswith("Z")

        # Breadcrumb was persisted immediately — no get/set needed.
        with open(path) as f:
            stored = json.load(f)
        assert DATA_LOSS_KEY in stored
        assert INTEGRITY_KEY in stored
    finally:
        shutil.rmtree(d)


def test_data_loss_breadcrumb_survives_reboot():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("CORRUPT")
        with open(path + ".bak", "w") as f:
            f.write("CORRUPT")
        Settings(file_path=path)  # first boot writes the breadcrumb

        # Second boot: primary is now the valid file written above.
        s2 = Settings(file_path=path)
        assert s2.recovered_from == RECOVERED_PRIMARY
        assert s2.has_data_loss_flag() is True
    finally:
        shutil.rmtree(d)


def test_clear_data_loss_flag_removes_and_persists():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("CORRUPT")
        with open(path + ".bak", "w") as f:
            f.write("CORRUPT")
        s = Settings(file_path=path)
        assert s.has_data_loss_flag()

        s.clear_data_loss_flag()
        assert not s.has_data_loss_flag()
        assert s.data_loss_info() is None

        with open(path) as f:
            stored = json.load(f)
        assert DATA_LOSS_KEY not in stored
    finally:
        shutil.rmtree(d)


def test_get_with_default_does_not_resurrect_cleared_breadcrumb():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("CORRUPT")
        with open(path + ".bak", "w") as f:
            f.write("CORRUPT")
        s = Settings(file_path=path)
        s.clear_data_loss_flag()

        # Normal app flow: lots of get() calls with defaults.  None of them
        # is for __data_loss__ at the root, so exist() stays False.
        s.get(["network", "ip"], "10.0.0.1")
        s.get(["mqtt", "broker"], "localhost")
        assert not s.has_data_loss_flag()

        # Even a pathological get() on a nested path under __data_loss__
        # would create it (known API), so we verify that the expected
        # consumer check (exist()) stays correct.
        assert not s.exist([DATA_LOSS_KEY])
    finally:
        shutil.rmtree(d)


def test_load_json_preserves_existing_data_loss_breadcrumb():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("CORRUPT")
        with open(path + ".bak", "w") as f:
            f.write("CORRUPT")
        s = Settings(file_path=path)
        assert s.has_data_loss_flag()
        original_info = s.data_loss_info()

        # UI posts a partial settings payload — the breadcrumb must not
        # disappear.
        s.load_json(json.dumps({"network": {"ip": "10.0.0.1"}}))
        assert s.has_data_loss_flag()
        assert s.data_loss_info() == original_info
        assert s.get(["network", "ip"], "") == "10.0.0.1"
    finally:
        shutil.rmtree(d)


def test_load_json_strips_reserved_keys_from_incoming_payload():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)
        payload = json.dumps({
            "app": "ok",
            DATA_LOSS_KEY: {"detected_at": "malicious", "main_status": "corrupt"},
            INTEGRITY_KEY: {"algo": "sha256-v1", "sha256": "bogus"},
        })
        s.load_json(payload)
        # Neither reserved key from the client should land in storage.
        with open(path) as f:
            stored = json.load(f)
        assert stored["app"] == "ok"
        assert DATA_LOSS_KEY not in stored  # wasn't set before, mustn't be now
        # INTEGRITY_KEY is re-added by save() with the correct hash.
        assert INTEGRITY_KEY in stored
        assert stored[INTEGRITY_KEY]["sha256"] != "bogus"
    finally:
        shutil.rmtree(d)


def test_auto_save_is_plain_attribute():
    d, path = _tmpdir_path()
    try:
        with open(path, "w") as f:
            f.write("CORRUPT")
        with open(path + ".bak", "w") as f:
            f.write("CORRUPT")
        s = Settings(file_path=path)
        # Even after empty_fallback, auto_save must be a normal bool.
        assert isinstance(s.auto_save, bool)
        assert s.auto_save is True
        s.auto_save = False
        assert s.auto_save is False
    finally:
        shutil.rmtree(d)


def test_self_heal_after_bak_recovery_rebuilds_chain():
    d, path = _tmpdir_path()
    try:
        # Primary corrupt, but a trailer-bearing .bak is present.
        s_seed = Settings(file_path=path + ".seed")
        s_seed.auto_save = False
        s_seed._json = {"seeded": True}
        s_seed.save()
        shutil.move(path + ".seed", path + ".bak")
        with open(path, "w") as f:
            f.write("GARBAGE NOT JSON")

        s = Settings(file_path=path)
        assert s._json == {"seeded": True}
        assert s.recovered_from == RECOVERED_BAK
        # Self-heal must have written a fresh primary (with trailer).
        with open(path) as f:
            restored = json.load(f)
        assert restored.get("seeded") is True
        assert INTEGRITY_KEY in restored
    finally:
        shutil.rmtree(d)


def test_trailer_hash_stable_for_same_content():
    d, path = _tmpdir_path()
    try:
        s1 = Settings(file_path=path)
        s1.auto_save = False
        s1._json = {"a": 1, "b": {"c": [1, 2, 3]}}
        s1.save()
        with open(path) as f:
            first = json.load(f)

        # Second save of identical content should yield identical sha.
        s2 = Settings(file_path=path)
        s2.auto_save = False
        s2.save()
        with open(path) as f:
            second = json.load(f)

        assert first[INTEGRITY_KEY]["sha256"] == second[INTEGRITY_KEY]["sha256"]
    finally:
        shutil.rmtree(d)


def test_trailer_hash_changes_when_content_changes():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)
        s.auto_save = False
        s._json = {"v": 1}
        s.save()
        with open(path) as f:
            sha1 = json.load(f)[INTEGRITY_KEY]["sha256"]
        s._json = {"v": 2}
        s.save()
        with open(path) as f:
            sha2 = json.load(f)[INTEGRITY_KEY]["sha256"]
        assert sha1 != sha2
    finally:
        shutil.rmtree(d)


def test_load_json_strips_incoming_trailer():
    d, path = _tmpdir_path()
    try:
        s = Settings(file_path=path)  # fresh start, auto_save enabled
        payload = json.dumps({
            "real": "data",
            INTEGRITY_KEY: {"algo": "sha256-v1", "sha256": "bogus"},
        })
        s.load_json(payload)
        # In-memory dict must not retain the stale trailer.
        assert INTEGRITY_KEY not in s._json
        assert s._json == {"real": "data"}
        # Persisted file must carry a fresh, correct trailer.
        with open(path) as f:
            stored = json.load(f)
        assert INTEGRITY_KEY in stored
        from brinkhaustools.common.settings import _canonical_hash
        base = {k: v for k, v in stored.items() if k != INTEGRITY_KEY}
        assert stored[INTEGRITY_KEY]["sha256"] == _canonical_hash(base)
    finally:
        shutil.rmtree(d)


def test_bak2_fallback_triggers_self_heal_with_critical_log(caplog):
    d, path = _tmpdir_path()
    try:
        s_seed = Settings(file_path=path + ".seed")
        s_seed.auto_save = False
        s_seed._json = {"from_bak2": True}
        s_seed.save()
        shutil.move(path + ".seed", path + ".bak2")
        with open(path, "w") as f:
            f.write("bad")
        with open(path + ".bak", "w") as f:
            f.write("bad")

        with caplog.at_level(logging.INFO, logger="brinkhaustools.common.settings"):
            s = Settings(file_path=path)
        assert s._json == {"from_bak2": True}
        assert s.recovered_from == RECOVERED_BAK2
        # Self-heal rebuilt the primary.
        with open(path) as f:
            restored = json.load(f)
        assert restored.get("from_bak2") is True
    finally:
        shutil.rmtree(d)
