"""Tests for the remote-command facility of StatusMonitor."""

import threading
import time
from unittest.mock import MagicMock

from brinkhaustools.common.fleet.monitor import CommandSpec, StatusMonitor


def _make_monitor():
    """StatusMonitor without config file or real HTTP client."""
    return StatusMonitor(config_path=None, software_name="test-app")


# -- Registration ----------------------------------------------------------


def test_register_command_stores_spec():
    monitor = _make_monitor()
    cb = lambda: ("success", "ok")
    monitor.register_command(
        command_id="ping",
        label={"de": "Ping", "en": "Ping"},
        callback=cb,
        icon="mdi-network",
        confirm_text={"de": "Sicher?", "en": "Sure?"},
        ack_strategy="post",
    )
    assert "ping" in monitor._commands
    spec = monitor._commands["ping"]
    assert isinstance(spec, CommandSpec)
    assert spec.callback is cb
    assert spec.icon == "mdi-network"
    assert spec.ack_strategy == "post"


def test_register_command_overwrites_same_id():
    monitor = _make_monitor()
    monitor.register_command("ping", {"en": "1"}, callback=lambda: ("success", "a"))
    monitor.register_command("ping", {"en": "2"}, callback=lambda: ("success", "b"))
    assert monitor._commands["ping"].label == {"en": "2"}


# -- Catalog building ------------------------------------------------------


def test_build_catalog_empty():
    monitor = _make_monitor()
    assert monitor._build_command_catalog() == []


def test_build_catalog_minimal_entry():
    monitor = _make_monitor()
    monitor.register_command("ping", {"en": "Ping"}, callback=lambda: ("success", ""))
    catalog = monitor._build_command_catalog()
    assert catalog == [{"id": "ping", "label": {"en": "Ping"}}]


def test_build_catalog_full_entry():
    monitor = _make_monitor()
    monitor.register_command(
        command_id="reboot-edge",
        label={"de": "Edge neu starten", "en": "Restart edge"},
        callback=lambda: ("success", ""),
        icon="mdi-restart",
        confirm_text={"de": "Sicher?"},
        ack_strategy="pre",
    )
    [entry] = monitor._build_command_catalog()
    assert entry["id"] == "reboot-edge"
    assert entry["icon"] == "mdi-restart"
    assert entry["confirm_text"] == {"de": "Sicher?"}


# -- Dispatch: post-ack flow -----------------------------------------------


def test_post_ack_runs_callback_and_acks_with_result():
    monitor = _make_monitor()
    monitor._client.send_command_ack = MagicMock()

    done = threading.Event()

    def cb():
        try:
            return ("success", "did the thing")
        finally:
            done.set()

    monitor.register_command("doit", {"en": "Do it"}, callback=cb)

    monitor._handle_incoming_commands([{"id": 42, "command_id": "doit"}])

    assert done.wait(timeout=2.0), "callback never ran"
    # Give the worker thread time to call send_command_ack after returning
    for _ in range(20):
        if monitor._client.send_command_ack.called:
            break
        time.sleep(0.05)

    monitor._client.send_command_ack.assert_called_once_with([
        {"id": 42, "result": "success", "message": "did the thing"},
    ])


def test_post_ack_callback_exception_acks_failure():
    monitor = _make_monitor()
    monitor._client.send_command_ack = MagicMock()

    def cb():
        raise RuntimeError("boom")

    monitor.register_command("crash", {"en": "Crash"}, callback=cb)
    monitor._handle_incoming_commands([{"id": 7, "command_id": "crash"}])

    for _ in range(20):
        if monitor._client.send_command_ack.called:
            break
        time.sleep(0.05)

    monitor._client.send_command_ack.assert_called_once()
    args = monitor._client.send_command_ack.call_args[0][0]
    assert args[0]["id"] == 7
    assert args[0]["result"] == "failure"
    assert "boom" in args[0]["message"]


# -- Dispatch: pre-ack flow ------------------------------------------------


def test_pre_ack_acks_before_callback_runs():
    monitor = _make_monitor()

    callback_started = threading.Event()
    callback_may_finish = threading.Event()
    ack_observed_before_callback = threading.Event()

    def fake_ack(acks):
        # If the callback hasn't even started yet when ACK happens → pre-ACK works.
        if not callback_started.is_set():
            ack_observed_before_callback.set()

    monitor._client.send_command_ack = MagicMock(side_effect=fake_ack)

    def cb():
        callback_started.set()
        callback_may_finish.wait(timeout=2.0)
        return ("success", "finished")

    monitor.register_command(
        "reboot-edge", {"en": "Reboot"}, callback=cb, ack_strategy="pre",
    )

    monitor._handle_incoming_commands([{"id": 99, "command_id": "reboot-edge"}])

    # Worker thread spawns asynchronously — wait for callback to start
    assert callback_started.wait(timeout=2.0), "callback never started"
    assert ack_observed_before_callback.is_set(), \
        "ACK happened after callback started — pre-ACK timing broken"

    monitor._client.send_command_ack.assert_called_once_with([
        {"id": 99, "result": "scheduled", "message": "command scheduled"},
    ])

    # Let the callback finish so the worker thread exits cleanly
    callback_may_finish.set()


def test_pre_ack_callback_exception_does_not_resend_ack():
    monitor = _make_monitor()
    monitor._client.send_command_ack = MagicMock()

    done = threading.Event()

    def cb():
        try:
            raise RuntimeError("boom after pre-ack")
        finally:
            done.set()

    monitor.register_command("boom", {"en": "Boom"}, callback=cb, ack_strategy="pre")
    monitor._handle_incoming_commands([{"id": 1, "command_id": "boom"}])

    assert done.wait(timeout=2.0)
    time.sleep(0.1)  # give worker a beat to (incorrectly) re-ack if it would

    # Exactly one ack: the pre-ack with "scheduled". Failure is logged only.
    assert monitor._client.send_command_ack.call_count == 1
    [(call_args, _)] = monitor._client.send_command_ack.call_args_list
    assert call_args[0] == [
        {"id": 1, "result": "scheduled", "message": "command scheduled"},
    ]


# -- Dispatch: unknown / malformed commands --------------------------------


def test_unknown_command_id_acks_rejected():
    monitor = _make_monitor()
    monitor._client.send_command_ack = MagicMock()

    monitor._handle_incoming_commands([{"id": 5, "command_id": "never-registered"}])

    monitor._client.send_command_ack.assert_called_once()
    [args] = monitor._client.send_command_ack.call_args[0]
    assert args[0]["id"] == 5
    assert args[0]["result"] == "rejected"
    assert "never-registered" in args[0]["message"]


def test_malformed_command_is_skipped():
    monitor = _make_monitor()
    monitor._client.send_command_ack = MagicMock()

    # Missing command_id
    monitor._handle_incoming_commands([{"id": 1}])
    # Missing id
    monitor._handle_incoming_commands([{"command_id": "x"}])
    # Empty entry
    monitor._handle_incoming_commands([{}])

    monitor._client.send_command_ack.assert_not_called()


# -- Wiring ----------------------------------------------------------------


def test_handle_incoming_is_registered_on_client():
    """The StatusMonitor must wire its handler into the client's command callback."""
    monitor = _make_monitor()
    # Bound methods are not identity-equal but compare equal.
    assert monitor._client._on_commands == monitor._handle_incoming_commands
