"""download_file 的本地落盘实现。

这是 shim 价值的核心: 让 AI 调用 download_file 后, 文件字节直接写到用户本机
磁盘, AI 的上下文里只看到 {"saved_to": "...", "size_bytes": ..., "sha256": "..."},
不再是一大坨 base64 或让 AI 自己 curl。

远端 download_file 的返回分三种 (见 backend/app/mcp_server/tools.py:293-435):
  1) ImageContent   (type="image",  base64 data,  mimeType)
  2) AudioContent   (type="audio",  base64 data,  mimeType)
  3) TextContent    (type="text",   UTF-8 text)   — 仅 as_text=true 时
  4) ResourceLink   (type="resource_link", uri=签名URL, 15分钟有效, 绕 Auth)

shim 处理策略:
  - 对 1/2: 远端已经返 base64, shim 本地 decode 后 open(save_to, "wb") 写入
  - 对 3: UTF-8 text, shim 本地 open(save_to, "w", encoding="utf-8") 写入
  - 对 4: shim 用 httpx stream GET 那个 ResourceLink.uri, 流式写到 save_to
          (大文件友好, 不把字节加载进内存)

落盘路径决策:
  - 如果 save_to 是绝对路径 → 直接用
  - 如果是相对路径 → 相对 settings.download_dir (默认 ~/Downloads)
  - 如果没传 save_to → 用远端文件名, 放到 settings.download_dir
  - save_to 所在目录不存在 → 自动 mkdir -p
  - save_to 已存在 → 默认加 .1/.2/... 后缀避免覆盖 (overwrite=False 时)
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
from pathlib import Path
from typing import Any

import httpx

from stagenth_mcp.config import Settings
from stagenth_mcp.remote import RemoteError, RemoteMCPClient


# ResourceLink 的 description 里有:
#   "<human-size> · <mime> · 15 分钟内有效 · ..."
# 不依赖它, size 字段在 resource_link 的 size 属性


async def download_to_local(
    client: RemoteMCPClient,
    settings: Settings,
    *,
    file_id: int | None,
    file_uuid: str | None,
    save_to: str | None,
    overwrite: bool,
) -> dict[str, Any]:
    """调远端 download_file, 把字节落到本地, 返回一段元信息给 AI。

    返回结构 (JSON 可序列化 dict, 会被 FastMCP 包成 content[0].text):
        {
          "ok": True,
          "saved_to": "/abs/path/to/file.pdf",
          "filename": "file.pdf",
          "size_bytes": 1234567,
          "size_human": "1.2 MB",
          "sha256": "abc...",   # 本地算的
          "mime_type": "application/pdf",
          "source": "resource_link" | "image_inline" | "audio_inline" | "text_inline",
        }
    """
    # 1. 先调远端, 拿回 content list
    args: dict[str, Any] = {}
    if file_id is not None:
        args["file_id"] = file_id
    elif file_uuid is not None:
        args["file_uuid"] = file_uuid
    else:
        raise ValueError("必须提供 file_id 或 file_uuid")

    result = await client.call(
        "tools/call",
        {"name": "download_file", "arguments": args},
    )

    # result 结构: {"content": [<block>, ...], "isError": False}
    if not isinstance(result, dict) or "content" not in result:
        raise RemoteError(f"download_file 返回结构异常: {json.dumps(result)[:500]}")

    if result.get("isError"):
        # 业务错误 (文件不存在 / 无权限 / 限额)
        blocks = result.get("content", [])
        msg = blocks[0].get("text", "") if blocks else "未知错误"
        raise RemoteError(f"远端拒绝下载: {msg}")

    blocks = result["content"]
    if not blocks:
        raise RemoteError("download_file 返回空 content")

    block = blocks[0]
    btype = block.get("type")

    # 2. 按类型分支处理
    if btype == "resource_link":
        return await _handle_resource_link(block, settings, save_to, overwrite)

    if btype == "image":
        return _handle_base64_inline(block, settings, save_to, overwrite, source="image_inline")

    if btype == "audio":
        return _handle_base64_inline(block, settings, save_to, overwrite, source="audio_inline")

    if btype == "text":
        return _handle_text_inline(block, settings, save_to, overwrite)

    raise RemoteError(f"未知 content type: {btype}")


# ── 分支 A: ResourceLink (签名 URL) ──
async def _handle_resource_link(
    block: dict[str, Any],
    settings: Settings,
    save_to: str | None,
    overwrite: bool,
) -> dict[str, Any]:
    uri = block.get("uri") or ""
    if not uri:
        raise RemoteError("resource_link 没有 uri")

    filename = block.get("name") or _filename_from_url(uri) or "download.bin"
    mime_type = block.get("mimeType") or "application/octet-stream"
    expected_size = int(block.get("size") or 0)

    target = _resolve_save_path(settings, save_to, filename, overwrite)

    # 签名 URL 不需要 Authorization (backend mcp_download.py 里 JWT 自带鉴权)
    async with httpx.AsyncClient(
        timeout=httpx.Timeout(connect=15.0, read=settings.timeout, write=30.0, pool=15.0),
        follow_redirects=True,  # 万一 CDN 302 到 OSS, 允许跟
        headers={"User-Agent": settings.user_agent},
    ) as http:
        hasher = hashlib.sha256()
        written = 0
        async with http.stream("GET", uri) as resp:
            if resp.status_code >= 400:
                body = await resp.aread()
                raise RemoteError(
                    f"GET signed URL 失败 HTTP {resp.status_code}: {body[:500].decode('utf-8', 'replace')}"
                )
            with open(target, "wb") as fh:
                async for chunk in resp.aiter_bytes(chunk_size=256 * 1024):
                    fh.write(chunk)
                    hasher.update(chunk)
                    written += len(chunk)

    return {
        "ok": True,
        "saved_to": str(target),
        "filename": filename,
        "size_bytes": written,
        "size_human": _human_size(written),
        "sha256": hasher.hexdigest(),
        "mime_type": mime_type,
        "source": "resource_link",
        "expected_size": expected_size,
    }


# ── 分支 B: image / audio (base64 inline) ──
def _handle_base64_inline(
    block: dict[str, Any],
    settings: Settings,
    save_to: str | None,
    overwrite: bool,
    *,
    source: str,
) -> dict[str, Any]:
    b64 = block.get("data") or ""
    if not b64:
        raise RemoteError(f"{block.get('type')} block 没有 data")
    mime_type = block.get("mimeType") or "application/octet-stream"

    try:
        raw = base64.b64decode(b64)
    except Exception as e:
        raise RemoteError(f"base64 解码失败: {e}")

    filename = _default_filename_from_mime(mime_type)
    target = _resolve_save_path(settings, save_to, filename, overwrite)
    target.write_bytes(raw)

    return {
        "ok": True,
        "saved_to": str(target),
        "filename": target.name,
        "size_bytes": len(raw),
        "size_human": _human_size(len(raw)),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "mime_type": mime_type,
        "source": source,
    }


# ── 分支 C: text inline (as_text=true) ──
def _handle_text_inline(
    block: dict[str, Any],
    settings: Settings,
    save_to: str | None,
    overwrite: bool,
) -> dict[str, Any]:
    text = block.get("text") or ""
    filename = "download.txt"
    target = _resolve_save_path(settings, save_to, filename, overwrite)
    # UTF-8 写入, 保持和远端 raw.decode('utf-8', errors='replace') 对齐
    target.write_text(text, encoding="utf-8")
    raw = text.encode("utf-8")
    return {
        "ok": True,
        "saved_to": str(target),
        "filename": target.name,
        "size_bytes": len(raw),
        "size_human": _human_size(len(raw)),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "mime_type": "text/plain; charset=utf-8",
        "source": "text_inline",
    }


# ── 工具函数 ──


def _resolve_save_path(
    settings: Settings, save_to: str | None, default_filename: str, overwrite: bool
) -> Path:
    """把 AI 传来的 save_to 解析成绝对路径, 并处理存在性。"""
    if save_to:
        p = Path(save_to).expanduser()
        if not p.is_absolute():
            p = settings.download_dir / p
    else:
        p = settings.download_dir / default_filename

    p.parent.mkdir(parents=True, exist_ok=True)

    if p.exists() and not overwrite:
        p = _dedupe_path(p)

    return p


def _dedupe_path(p: Path) -> Path:
    """foo.pdf 已存在 → foo (1).pdf / foo (2).pdf / ..."""
    stem = p.stem
    suffix = p.suffix
    parent = p.parent
    i = 1
    while True:
        cand = parent / f"{stem} ({i}){suffix}"
        if not cand.exists():
            return cand
        i += 1
        if i > 9999:
            raise RuntimeError(f"去重失败: {p} 附近已有太多同名文件")


def _filename_from_url(url: str) -> str | None:
    m = re.search(r"/([^/?#]+?)(?:[?#]|$)", url)
    if m:
        return m.group(1)
    return None


def _default_filename_from_mime(mime: str) -> str:
    """image/png -> image.png, audio/mpeg -> audio.mp3, 其它 -> download.bin。"""
    table = {
        "image/jpeg": "image.jpg",
        "image/png": "image.png",
        "image/gif": "image.gif",
        "image/webp": "image.webp",
        "image/svg+xml": "image.svg",
        "audio/mpeg": "audio.mp3",
        "audio/wav": "audio.wav",
        "audio/ogg": "audio.ogg",
        "audio/flac": "audio.flac",
        "audio/mp4": "audio.m4a",
    }
    return table.get(mime.lower(), "download.bin")


def _human_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    for unit in ("KB", "MB", "GB", "TB"):
        n_f = n / 1024.0
        if n_f < 1024 or unit == "TB":
            return f"{n_f:.2f} {unit}"
        n = int(n_f)
    return f"{n} B"
