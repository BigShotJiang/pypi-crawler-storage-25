"""`python -m stagenth_mcp` 入口, 同时也是 pyproject.scripts 的 stagenth-mcp CLI 后台。"""

from stagenth_mcp.server import main_cli as main

if __name__ == "__main__":
    main()
