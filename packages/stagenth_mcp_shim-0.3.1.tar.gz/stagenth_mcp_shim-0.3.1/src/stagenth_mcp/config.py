"""shim 运行时配置 — 从环境变量读。

必填:
    STAGENTH_TOKEN        file-relay API Token (mcp_xxx 47字符)

可选:
    STAGENTH_ENDPOINT     远端 MCP endpoint, 默认 https://stagenth.com/mcp/file-relay/
                          末尾 / 必须保留 (否则 301)
    STAGENTH_TIMEOUT      单请求超时秒数, 默认 600 (大文件上传可能要很久)
    STAGENTH_DOWNLOAD_DIR 默认下载目录 (当 AI 没传 save_to 时用这个), 默认 ~/Downloads

用法 (Cline 配置片段):
    {
      "mcpServers": {
        "stagenth-file-relay": {
          "command": "stagenth-mcp",
          "env": {
            "STAGENTH_TOKEN": "mcp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
          }
        }
      }
    }
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path


DEFAULT_ENDPOINT = "https://stagenth.com/mcp/file-relay/"


@dataclass(frozen=True)
class Settings:
    token: str
    endpoint: str  # 保证末尾带 /
    timeout: float
    download_dir: Path

    @property
    def user_agent(self) -> str:
        return f"stagenth-mcp-shim/{__import__('stagenth_mcp').__version__}"


def load_settings() -> Settings:
    token = os.environ.get("STAGENTH_TOKEN", "").strip()
    if not token:
        # stderr — 不污染 stdio MCP 通道 (stdout 是 JSON-RPC)
        print(
            "[stagenth-mcp] FATAL: STAGENTH_TOKEN 环境变量未设置。\n"
            "  到 https://stagenth.com/mcp/file-relay/console/tokens 生成 Token,\n"
            "  然后在 Cline/Claude Desktop 的 MCP 配置里加:\n"
            '    "env": { "STAGENTH_TOKEN": "mcp_xxx..." }',
            file=sys.stderr,
            flush=True,
        )
        sys.exit(2)

    endpoint = os.environ.get("STAGENTH_ENDPOINT", DEFAULT_ENDPOINT).strip()
    if not endpoint.endswith("/"):
        endpoint += "/"

    try:
        timeout = float(os.environ.get("STAGENTH_TIMEOUT", "600"))
    except ValueError:
        timeout = 600.0

    download_dir = Path(
        os.environ.get("STAGENTH_DOWNLOAD_DIR", str(Path.home() / "Downloads"))
    ).expanduser()

    return Settings(
        token=token,
        endpoint=endpoint,
        timeout=timeout,
        download_dir=download_dir,
    )
