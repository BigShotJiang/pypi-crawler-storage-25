"""stagenth file-relay 的本地 stdio MCP shim。

把远端 HTTPS Streamable HTTP MCP 服务 (https://stagenth.com/mcp/file-relay/) 转接成
一个跑在用户本机的 stdio MCP server, 让只支持 stdio 的客户端 (Cline / Claude Desktop
/ Cursor) 无痛接入, 并且:
  - 把 download_file 改造成 "直接落盘到本地路径"
  - 给 upload_file 加 source_path 参数, 支持本机大文件分片直传 (0.2.0+)
"""

__version__ = "0.3.1"
