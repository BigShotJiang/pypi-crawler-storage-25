"""远端 HTTPS MCP 客户端 —— 发 JSON-RPC 请求, 解析 SSE 响应。

背景 (docs/MCP.md §三): 后端是 Streamable HTTP + stateless_http=True + json_response=False,
每次 POST 响应是 SSE 格式:
    event: message
    data: {"jsonrpc":"2.0","id":1,"result":{...}}

三个坑 (产品页提示词里列了):
  1. URL 末尾 / 必须保留 (否则 301)
  2. Accept 必须同时带 application/json 和 text/event-stream
  3. 响应要按 SSE 解析, 取第一个 data: 行的 JSON

由于 backend 用 stateless_http=True, 每次请求完全独立, 不需要维护 Mcp-Session-Id。
这大大简化了 shim —— 一次 POST 一次响应, 跟普通 HTTP 调用无异。
"""

from __future__ import annotations

import json
from typing import Any

import httpx

from stagenth_mcp.config import Settings


class RemoteError(Exception):
    """远端协议/传输层错误 (401/403/5xx/超时/SSE 解析挂)。"""


class RemoteMCPClient:
    """纯同步的远端 MCP 客户端 —— 配合 FastMCP stdio server 用。

    为什么同步: MCP Python SDK 的 stdio server 在 asyncio 上跑, 但我们 tool
    handler 内部用 httpx 发一个请求就回来, 用 AsyncClient 更顺, 下面方法统一
    做成 async。
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        self._client: httpx.AsyncClient | None = None
        self._next_id = 1

    async def __aenter__(self) -> RemoteMCPClient:
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=15.0,
                read=self.settings.timeout,
                write=self.settings.timeout,
                pool=15.0,
            ),
            follow_redirects=False,  # 301 是 bug, 不要自动跟 (末尾 / 必须保留)
            headers={
                "Authorization": f"Bearer {self.settings.token}",
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream",
                "User-Agent": self.settings.user_agent,
                # 声明 MCP 协议版本 (spec 2025-06-18), 跟 backend 对齐
                "MCP-Protocol-Version": "2025-06-18",
            },
        )
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def _new_id(self) -> int:
        i = self._next_id
        self._next_id += 1
        return i

    async def call(self, method: str, params: dict[str, Any] | None = None) -> Any:
        """发一条 JSON-RPC 请求, 返回 result 部分 (SSE data 解包后)。

        错误处理:
        - HTTP 非 2xx -> RemoteError, 带响应体
        - SSE 解析失败 -> RemoteError
        - JSON-RPC error 字段 -> RemoteError, 带 code/message
        """
        assert self._client is not None, "RemoteMCPClient 必须在 async with 里用"

        payload = {
            "jsonrpc": "2.0",
            "id": self._new_id(),
            "method": method,
        }
        if params is not None:
            payload["params"] = params

        resp = await self._client.post(self.settings.endpoint, json=payload)

        # HTTP 层错误
        if resp.status_code >= 400:
            # 401 / 403 有 JSON body, 带 code + message (backend auth.py)
            try:
                body = resp.json()
            except Exception:
                body = {"raw": resp.text[:500]}
            raise RemoteError(
                f"远端 HTTP {resp.status_code}: {json.dumps(body, ensure_ascii=False)}"
            )

        # 成功响应分两种: application/json 或 text/event-stream
        content_type = resp.headers.get("content-type", "")
        data = _extract_rpc_response(resp.text, content_type)

        # JSON-RPC 层错误
        if "error" in data:
            err = data["error"]
            raise RemoteError(
                f"MCP JSON-RPC error {err.get('code')}: {err.get('message')}"
            )

        return data.get("result")

    async def get_presigned_download_url(
        self, file_id: int | None = None, file_uuid: str | None = None
    ) -> tuple[str, dict]:
        """调远端 download_file, 解析出 ResourceLink 的 url。

        返回 (public_url, file_meta_dict)。

        注意: 对 image/audio/text 类文件, 远端不会返 ResourceLink 而是 inline
        ImageContent/AudioContent/TextContent。本函数会检测并转存为假 URL
        提示 (调用方需要 fallback 到 inline 字节处理, 见 download.py)。
        """
        args: dict[str, Any] = {}
        if file_id is not None:
            args["file_id"] = file_id
        elif file_uuid is not None:
            args["file_uuid"] = file_uuid
        else:
            raise ValueError("必须提供 file_id 或 file_uuid")

        result = await self.call(
            "tools/call",
            {"name": "download_file", "arguments": args},
        )
        return result, {}


def _extract_rpc_response(text: str, content_type: str) -> dict[str, Any]:
    """从 HTTP body 里抽 JSON-RPC response。

    两种格式:
    - Content-Type: application/json        -> body 就是 JSON
    - Content-Type: text/event-stream (SSE) -> 取第一个 `data: {...}` 行
    """
    if "event-stream" in content_type.lower():
        for line in text.splitlines():
            if line.startswith("data:"):
                raw = line[5:].lstrip()
                if not raw:
                    continue
                try:
                    return json.loads(raw)
                except json.JSONDecodeError as e:
                    raise RemoteError(f"SSE data 不是合法 JSON: {e}; 原文: {raw[:200]}")
        raise RemoteError(f"SSE 响应里没找到 data: 行; 原文: {text[:500]}")

    # 普通 JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        raise RemoteError(
            f"响应 Content-Type={content_type!r} 不是 SSE 也不是合法 JSON: {e}"
        )
