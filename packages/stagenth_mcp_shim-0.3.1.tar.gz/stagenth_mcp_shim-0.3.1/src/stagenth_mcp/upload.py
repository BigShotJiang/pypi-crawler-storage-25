"""upload_file 本地直传 —— v0.3.0 改 OSS 直传模式 (字节不经 stagenth.com ECS)。

旧版 (0.2.0): shim 把每片 base64 POST 给 stagenth.com 的 upload_chunk 工具
              -> backend base64 decode -> backend OSS.put_object
              风险: ECS 作为字节中转, 大文件 OOM, 公网带宽双向消耗.

新版 (0.3.0): shim 从 upload_init 返回拿 part_urls (OSS 预签名 PUT URL 数组)
              -> 直接 PUT 每片到 OSS URL (字节 shim <-> 阿里云 OSS 直连)
              -> 收集每片响应的 ETag
              -> 调 upload_complete 带 parts=[{part_number, etag}, ...]
              -> 服务端调 CompleteMultipartUpload 让 OSS 合并
              优势: 0 字节经过 ECS, backend 只做授权+签名. 支持 10GB+ 文件.

兼容性: 如果 upload_init 返回 direct_put=False (LocalStorage 或 OSS 签名失败降级),
        自动 fallback 到旧路径 (upload_chunk 每片 POST).
"""

from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path
from typing import Any

import httpx

from stagenth_mcp.config import Settings
from stagenth_mcp.remote import RemoteError, RemoteMCPClient


_SHA_READ_CHUNK = 4 * 1024 * 1024  # 4MB 每次 read, 算 sha 的 buf


def _compute_sha256_and_size(path: Path) -> tuple[str, int]:
    """流式计算 sha256 + 字节数, 不把整个文件读进内存。"""
    h = hashlib.sha256()
    total = 0
    with open(path, "rb") as fh:
        while True:
            block = fh.read(_SHA_READ_CHUNK)
            if not block:
                break
            h.update(block)
            total += len(block)
    return h.hexdigest(), total


async def _call_tool(client: RemoteMCPClient, name: str, args: dict) -> dict:
    """调一次远端 tools/call 并解包 content[0].text 成 JSON dict。"""
    result = await client.call("tools/call", {"name": name, "arguments": args})
    if not isinstance(result, dict) or "content" not in result:
        raise RemoteError(f"{name} 返回结构异常: {json.dumps(result)[:500]}")
    if result.get("isError"):
        blocks = result.get("content") or []
        msg = blocks[0].get("text", "未知错误") if blocks else "未知错误"
        raise RemoteError(f"远端 {name} 失败: {msg}")
    blocks = result.get("content") or []
    if not blocks:
        raise RemoteError(f"{name} 返回空 content")
    text = blocks[0].get("text", "")
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        raise RemoteError(f"{name} 返回非 JSON 文本: {e}; 原文: {text[:200]}")


async def upload_from_local_path(
    client: RemoteMCPClient,
    settings: Settings,
    *,
    source_path: str,
    filename: str | None = None,
    mime_type: str = "",
) -> dict[str, Any]:
    """本机大文件 → OSS 直传 (首选) 或 中转 (降级)。

    返回:
      {
        "ok": True,
        "instant": bool,
        "mode": "direct-oss" | "transit",      # 走了哪条路径
        "source_path": "...",
        "filename": "...",
        "size_bytes": int,
        "size_human": "...",
        "sha256": "...",
        "file": {<file meta from server>},
        "uploaded_chunks": int,
        "total_chunks": int,
        "resumed_chunks": int,
      }
    """
    p = Path(source_path).expanduser()
    if not p.is_absolute():
        raise ValueError(f"source_path 必须是绝对路径: 传入 {source_path!r}")
    if not p.exists():
        raise ValueError(f"文件不存在: {p}")
    if not p.is_file():
        raise ValueError(f"不是一个常规文件: {p}")

    fname = filename or p.name
    sha256, total_size = _compute_sha256_and_size(p)
    if total_size == 0:
        raise ValueError(f"空文件不支持: {p}")

    # ── step 1: upload_init ──
    init_res = await _call_tool(
        client,
        "upload_init",
        {
            "filename": fname,
            "total_size_bytes": total_size,
            "sha256": sha256,
            "mime_type": mime_type,
        },
    )

    if init_res.get("instant"):
        return {
            "ok": True,
            "instant": True,
            "mode": "instant",
            "source_path": str(p),
            "filename": fname,
            "size_bytes": total_size,
            "size_human": _human_size(total_size),
            "sha256": sha256,
            "file": init_res.get("file"),
            "uploaded_chunks": 0,
            "message": "秒传: 服务端已有相同内容, 0 字节上行",
        }

    session_uuid = init_res["session_uuid"]
    chunk_size = int(init_res["chunk_size"])
    total_chunks = int(init_res["total_chunks"])
    direct_put = bool(init_res.get("direct_put", False))
    part_urls = init_res.get("part_urls") or []

    # ── step 2: 选路径 ──
    if direct_put and len(part_urls) == total_chunks:
        return await _upload_direct_oss(
            p, fname, total_size, sha256, session_uuid, total_chunks,
            chunk_size, part_urls, client,
        )
    else:
        return await _upload_via_transit(
            p, fname, total_size, sha256, session_uuid, total_chunks,
            chunk_size, init_res, client,
        )


# ── direct-oss 路径: shim 字节直传 OSS ──


async def _upload_direct_oss(
    path: Path,
    fname: str,
    total_size: int,
    sha256: str,
    session_uuid: str,
    total_chunks: int,
    chunk_size: int,
    part_urls: list[str],
    client: RemoteMCPClient,
) -> dict[str, Any]:
    """读文件 → 对每片 httpx PUT 预签名 URL → 收 ETag → 调 upload_complete。"""

    parts: list[dict[str, Any]] = []

    # OSS PUT 独立的 httpx client, 不用 MCP 那套 (不带 Authorization, 预签 URL 自带签名)
    async with httpx.AsyncClient(
        timeout=httpx.Timeout(connect=15.0, read=120.0, write=600.0, pool=15.0),
        # OSS 可能 302 到其它节点, 跟随
        follow_redirects=True,
    ) as oss_http:
        with open(path, "rb") as fh:
            for i in range(total_chunks):
                fh.seek(i * chunk_size)
                block = fh.read(chunk_size)
                if not block:
                    raise RemoteError(
                        f"读到第 {i+1}/{total_chunks} 片时 EOF, 文件可能被修改"
                    )
                # OSS V4 签名约定: PUT 时不设任何自定义 header (Content-Type / MD5 等)
                # 否则 OSS 会把它算进 CanonicalHeaders 触发 SignatureDoesNotMatch.
                resp = await oss_http.put(part_urls[i], content=block)
                if resp.status_code >= 400:
                    body = resp.text[:500]
                    raise RemoteError(
                        f"OSS PUT part {i+1}/{total_chunks} 失败 HTTP {resp.status_code}: {body}"
                    )
                etag = resp.headers.get("ETag") or resp.headers.get("etag")
                if not etag:
                    raise RemoteError(
                        f"OSS PUT part {i+1} 响应缺 ETag 头; headers={dict(resp.headers)}"
                    )
                # OSS ETag 双引号包裹, CompleteMultipartUpload 期望带引号或不带都行,
                # 保险起见按阿里云 SDK 约定: 不去引号 (它自己会处理).
                parts.append({"part_number": i + 1, "etag": etag.strip('"')})

    # ── step 3: upload_complete 带 parts ──
    comp_res = await _call_tool(
        client,
        "upload_complete",
        {"session_uuid": session_uuid, "parts": parts},
    )

    return {
        "ok": True,
        "instant": False,
        "mode": "direct-oss",
        "source_path": str(path),
        "filename": fname,
        "size_bytes": total_size,
        "size_human": _human_size(total_size),
        "sha256": sha256,
        "file": comp_res.get("file"),
        "uploaded_chunks": total_chunks,
        "total_chunks": total_chunks,
        "resumed_chunks": 0,
    }


# ── transit 路径: 老路 (兼容 LocalStorage / direct_put 降级) ──


async def _upload_via_transit(
    path: Path,
    fname: str,
    total_size: int,
    sha256: str,
    session_uuid: str,
    total_chunks: int,
    chunk_size: int,
    init_res: dict,
    client: RemoteMCPClient,
) -> dict[str, Any]:
    already_uploaded = set(init_res.get("uploaded_indexes") or [])
    uploaded_now = 0
    with open(path, "rb") as fh:
        for i in range(total_chunks):
            if i in already_uploaded:
                fh.seek((i + 1) * chunk_size)
                continue
            fh.seek(i * chunk_size)
            block = fh.read(chunk_size)
            if not block:
                raise RemoteError(
                    f"读到 chunk {i} 时 EOF (预期还有 {total_chunks - i} 片)"
                )
            b64 = base64.b64encode(block).decode("ascii")
            await _call_tool(
                client,
                "upload_chunk",
                {
                    "session_uuid": session_uuid,
                    "chunk_index": i,
                    "data_base64": b64,
                },
            )
            uploaded_now += 1

    comp_res = await _call_tool(
        client, "upload_complete", {"session_uuid": session_uuid}
    )

    return {
        "ok": True,
        "instant": False,
        "mode": "transit",
        "source_path": str(path),
        "filename": fname,
        "size_bytes": total_size,
        "size_human": _human_size(total_size),
        "sha256": sha256,
        "file": comp_res.get("file"),
        "uploaded_chunks": uploaded_now,
        "total_chunks": total_chunks,
        "resumed_chunks": len(already_uploaded),
    }


# ── utility ──


def _human_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    for unit in ("KB", "MB", "GB", "TB"):
        n_f = n / 1024.0
        if n_f < 1024 or unit == "TB":
            return f"{n_f:.2f} {unit}"
        n = int(n_f)
    return f"{n} B"
