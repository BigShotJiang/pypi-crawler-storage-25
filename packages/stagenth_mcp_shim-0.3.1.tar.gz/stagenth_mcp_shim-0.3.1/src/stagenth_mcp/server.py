"""stdio MCP server —— 把本地 stdin/stdout 的 JSON-RPC 代理到远端 HTTPS。

架构:
    Cline / Claude Desktop / Cursor
        ↕  stdio (JSON-RPC)
    [stagenth-mcp shim (this module)]
        ↕  HTTPS POST + SSE
    https://stagenth.com/mcp/file-relay/

职责分工:
  - 启动时 (首次 list_tools): 向远端发 initialize + tools/list, 拿到原生 10 个工具的 schema
  - 给客户端的 list_tools 响应里, 把 download_file 的 schema 增强 (加 save_to / overwrite 参数)
  - 所有 tools/call 透明代理; download_file 劫持走 download.download_to_local (本地落盘)
  - 其它方法 (resources/* 等) 暂不透传, 客户端用不到

为什么不直接复用 FastMCP client 里的代码:
  FastMCP 的客户端封装跟 streamablehttp_client 绑死, 而我们这里一次请求一次响应
  (stateless_http=True) 走纯 httpx POST 最简洁, 没必要拉整套 session machinery。
"""

from __future__ import annotations

import copy
import json
import logging
import sys
from typing import Any

import anyio
import mcp.types as types
from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server

from stagenth_mcp import __version__
from stagenth_mcp.config import Settings, load_settings
from stagenth_mcp.download import download_to_local
from stagenth_mcp.remote import RemoteError, RemoteMCPClient
from stagenth_mcp.upload import upload_from_local_path


logger = logging.getLogger("stagenth_mcp")


# ── download_file 的 schema 增强 ──
# 我们在远端 schema 基础上, 插入 save_to / overwrite 两个可选参数,
# 让 AI 知道"这是落到本地磁盘的下载",而不是把字节拉进上下文。
_DOWNLOAD_EXTRA_PROPS: dict[str, Any] = {
    "save_to": {
        "type": "string",
        "description": (
            "【shim 专属】保存到本机的目标路径。"
            "绝对路径 → 直接用; 相对路径 → 相对 $STAGENTH_DOWNLOAD_DIR (默认 ~/Downloads); "
            "不传 → 用远端文件名放到 $STAGENTH_DOWNLOAD_DIR。目录不存在会自动 mkdir -p。"
        ),
    },
    "overwrite": {
        "type": "boolean",
        "description": "目标已存在时是否覆盖。false (默认) 时追加 (1)/(2)/... 后缀避免冲突。",
        "default": False,
    },
}

_DOWNLOAD_DESCRIPTION_PREFIX = (
    "【本地落盘】下载文件到用户本机磁盘, AI 的上下文里只返回路径/大小/sha256, "
    "不会把文件字节加载进模型上下文。"
    "大文件友好 (流式写盘), 可选 save_to 指定路径。\n"
    "原工具说明: "
)


def _augment_download_tool(tool: types.Tool) -> types.Tool:
    """在远端 download_file schema 上插入 save_to / overwrite, 并改描述。"""
    new_schema = copy.deepcopy(tool.inputSchema or {})
    props = new_schema.setdefault("properties", {})
    props.update(_DOWNLOAD_EXTRA_PROPS)

    return types.Tool(
        name=tool.name,
        title=tool.title,
        description=_DOWNLOAD_DESCRIPTION_PREFIX + (tool.description or ""),
        inputSchema=new_schema,
        outputSchema=tool.outputSchema,
        annotations=tool.annotations,
    )


# ── upload_file 的 schema 增强 ──
# 给远端原 upload_file 加 source_path 参数, AI 就能传"本机绝对路径"而不是
# base64 一大坨字符串。shim 内部走分片 (upload_init/chunk/complete) 上传,
# 无大小限制且不占 AI context。
_UPLOAD_EXTRA_PROPS: dict[str, Any] = {
    "source_path": {
        "type": "string",
        "description": (
            "【shim 专属 · 大文件推荐】本机文件的绝对路径。"
            "传了 source_path 就不用传 content_base64, shim 会本地流式读取并分片上传 (无大小上限, 不占模型上下文)。"
            "传了 source_path 时, filename 可不填 (默认用路径的 basename)。"
        ),
    },
}

_UPLOAD_DESCRIPTION_PREFIX = (
    "【本地直传 (推荐大文件) / base64 (小文件兼容)】"
    "传 source_path 走本地分片 (任意大小, 不占 AI 上下文); "
    "传 content_base64 走单次 base64 (适合 <15MB)。两者二选一。\n"
    "原工具说明: "
)


def _augment_upload_tool(tool: types.Tool) -> types.Tool:
    """在远端 upload_file schema 上插入 source_path, 放宽 filename / content_base64 为可选。"""
    new_schema = copy.deepcopy(tool.inputSchema or {})
    props = new_schema.setdefault("properties", {})
    props.update(_UPLOAD_EXTRA_PROPS)
    # 把原来必填的字段改成可选 (校验移到 shim 层做: content_base64 xor source_path 必填一个)
    if "required" in new_schema:
        new_schema["required"] = [
            r for r in new_schema["required"] if r not in ("content_base64", "filename")
        ]

    return types.Tool(
        name=tool.name,
        title=tool.title,
        description=_UPLOAD_DESCRIPTION_PREFIX + (tool.description or ""),
        inputSchema=new_schema,
        outputSchema=tool.outputSchema,
        annotations=tool.annotations,
    )


def _rebuild_tool_from_raw(raw: dict[str, Any]) -> types.Tool:
    """远端 tools/list 返的 dict → types.Tool。

    远端返回结构 (MCP spec 2025-06-18):
        {"name": "...", "description": "...", "inputSchema": {...}, "title": ...}
    直接喂 types.Tool(**raw) 大多数情况能通过 pydantic 校验。
    """
    # pydantic 会忽略它不认识的字段; 兼容 SDK 版本差异
    return types.Tool.model_validate(raw)


async def _unwrap_tools_call_result(
    raw_result: Any,
) -> list[types.ContentBlock]:
    """把远端 tools/call 的 result.content 还原成 ContentBlock 对象列表。

    远端返回:
        {"content": [<block-dict>, ...], "isError": False, "structuredContent": ...}
    每个 block-dict 形如:
        {"type": "text", "text": "..."}
        {"type": "image", "data": "<base64>", "mimeType": "image/png"}
        {"type": "audio", "data": "<base64>", "mimeType": "audio/mpeg"}
        {"type": "resource_link", "uri": "...", "name": "...", ...}
    """
    if not isinstance(raw_result, dict):
        return [types.TextContent(type="text", text=json.dumps(raw_result, ensure_ascii=False))]

    if raw_result.get("isError"):
        # 直接把错误文本透给客户端, 让它显示 tool error
        blocks = raw_result.get("content") or []
        text = blocks[0].get("text", "未知错误") if blocks else "未知错误"
        # Python SDK 的 @call_tool() 里 raise 会被包装成 isError:true, 正好匹配 MCP spec
        raise RuntimeError(text)

    blocks_raw = raw_result.get("content") or []
    out: list[types.ContentBlock] = []
    for b in blocks_raw:
        if not isinstance(b, dict):
            continue
        try:
            # pydantic 按 "type" 字段自动 dispatch 到对应 ContentBlock 子类
            out.append(types.ContentBlock.validate_python(b))  # type: ignore[attr-defined]
        except (AttributeError, Exception):  # noqa: BLE001
            # SDK 版本差异: 低版本没 ContentBlock 统一类型, 手工 dispatch
            btype = b.get("type")
            if btype == "text":
                out.append(types.TextContent(**b))
            elif btype == "image":
                out.append(types.ImageContent(**b))
            elif btype == "audio":
                out.append(types.AudioContent(**b))
            elif btype == "resource_link":
                out.append(types.ResourceLink(**b))
            elif btype == "resource":
                out.append(types.EmbeddedResource(**b))
            else:
                out.append(types.TextContent(
                    type="text",
                    text=json.dumps(b, ensure_ascii=False),
                ))
    return out


# ── 主程序 ──


async def run_stdio(settings: Settings) -> None:
    app = Server("stagenth-file-relay")

    # 懒加载的工具清单 (从远端拉一次就 cache)
    _tools_cache: list[types.Tool] | None = None

    async def _fetch_tools(client: RemoteMCPClient) -> list[types.Tool]:
        nonlocal _tools_cache
        if _tools_cache is not None:
            return _tools_cache
        result = await client.call("tools/list")
        raw_tools = (result or {}).get("tools") or []
        tools: list[types.Tool] = []
        for raw in raw_tools:
            try:
                t = _rebuild_tool_from_raw(raw)
            except Exception as e:  # noqa: BLE001
                logger.warning("跳过无法解析的远端 tool: %s (%s)", raw.get("name"), e)
                continue
            # 对 AI 隐藏 upload_init/chunk/complete —— shim 内部自己用, 避免 AI 误调
            if t.name in ("upload_init", "upload_chunk", "upload_complete"):
                continue
            if t.name == "download_file":
                t = _augment_download_tool(t)
            elif t.name == "upload_file":
                t = _augment_upload_tool(t)
            tools.append(t)
        _tools_cache = tools
        return tools

    # 为了 list_tools / call_tool 两个 handler 共享同一个 RemoteMCPClient,
    # 用一个顶层的 client context —— 进程存续期间保持长连接 (httpx 连接池)。
    async with RemoteMCPClient(settings) as remote:

        @app.list_tools()
        async def list_tools() -> list[types.Tool]:
            try:
                return await _fetch_tools(remote)
            except RemoteError as e:
                # 打到 stderr, 让 Cline 的 MCP 日志面板能看到原因
                logger.error("远端 tools/list 失败: %s", e)
                # 返空列表, 避免客户端整个挂掉
                return []

        @app.call_tool()
        async def call_tool(
            name: str, arguments: dict[str, Any] | None
        ) -> list[types.ContentBlock]:
            args = arguments or {}

            # ── 劫持: download_file ──
            if name == "download_file":
                save_to = args.pop("save_to", None)
                overwrite = bool(args.pop("overwrite", False))
                file_id = args.get("file_id")
                file_uuid = args.get("file_uuid")

                if file_id is None and not file_uuid:
                    raise ValueError("file_id 或 file_uuid 至少提供一个")

                try:
                    info = await download_to_local(
                        remote,
                        settings,
                        file_id=file_id,
                        file_uuid=file_uuid,
                        save_to=save_to,
                        overwrite=overwrite,
                    )
                except RemoteError as e:
                    raise RuntimeError(str(e))

                # 把一段人类可读 + JSON 同时给 AI, AI 想解析就解析, 想直接说就直接说
                human = (
                    f"✓ 已保存到 {info['saved_to']}\n"
                    f"  大小: {info['size_human']} ({info['size_bytes']} bytes)\n"
                    f"  mime: {info['mime_type']}\n"
                    f"  sha256: {info['sha256']}"
                )
                payload = json.dumps(info, ensure_ascii=False)
                return [
                    types.TextContent(type="text", text=human),
                    types.TextContent(type="text", text=payload),
                ]

            # ── 劫持: upload_file (source_path 分支走本地分片) ──
            if name == "upload_file":
                source_path = args.pop("source_path", None)
                if source_path:
                    # AI 传了本地路径 → shim 自己读文件 + 分片上传
                    try:
                        info = await upload_from_local_path(
                            remote,
                            settings,
                            source_path=source_path,
                            filename=args.get("filename"),
                            mime_type=args.get("mime_type", ""),
                        )
                    except (RemoteError, ValueError) as e:
                        raise RuntimeError(str(e))

                    fmeta = info.get("file") or {}
                    if info.get("instant"):
                        human = (
                            f"✓ 秒传命中: {info['filename']} ({info['size_human']})\n"
                            f"  file_id: {fmeta.get('id')}  uuid: {fmeta.get('uuid')}\n"
                            f"  sha256: {info['sha256']}  (0 字节上行)"
                        )
                    else:
                        human = (
                            f"✓ 上传完成: {info['filename']} ({info['size_human']})\n"
                            f"  file_id: {fmeta.get('id')}  uuid: {fmeta.get('uuid')}\n"
                            f"  sha256: {info['sha256']}\n"
                            f"  分片: {info['uploaded_chunks']}/{info['total_chunks']}"
                            + (
                                f" (续传跳过 {info['resumed_chunks']} 片)"
                                if info.get("resumed_chunks")
                                else ""
                            )
                        )
                    payload = json.dumps(info, ensure_ascii=False)
                    return [
                        types.TextContent(type="text", text=human),
                        types.TextContent(type="text", text=payload),
                    ]
                # 没传 source_path → 透传 (走原 upload_file 单次 base64)
                # (content_base64 / filename 校验交给远端)

            # ── 其它工具: 透明代理 ──
            try:
                result = await remote.call(
                    "tools/call", {"name": name, "arguments": args}
                )
            except RemoteError as e:
                raise RuntimeError(str(e))

            return await _unwrap_tools_call_result(result)

        # ── 启动 stdio loop ──
        async with stdio_server() as (read_stream, write_stream):
            await app.run(
                read_stream,
                write_stream,
                app.create_initialization_options(),
            )


def main_cli() -> None:
    """同步入口 (供 pyproject scripts 和 __main__ 用)。"""
    # 所有日志走 stderr; stdout 是 MCP JSON-RPC 通道, 绝对不能乱写
    logging.basicConfig(
        level=logging.INFO,
        stream=sys.stderr,
        format="[stagenth-mcp] %(asctime)s %(levelname)s %(message)s",
    )
    logger.info("stagenth-mcp-shim v%s starting", __version__)

    settings = load_settings()
    logger.info("endpoint = %s", settings.endpoint)
    logger.info("download_dir = %s", settings.download_dir)

    try:
        anyio.run(run_stdio, settings)
    except KeyboardInterrupt:
        logger.info("interrupted")
    except Exception:  # noqa: BLE001
        logger.exception("fatal")
        sys.exit(1)
