try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    # Non-fatal: exception ignored here; execution continues per surrounding logic.
    pass

import asyncio
import base64
import copy
import logging
import os

# import torch
import re
import sys
import time
import urllib
import urllib.request
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# External dependencies
try:
    import cv2
except ImportError:
    cv2 = None
import numpy as np

from ..core.base import (
    BaseProcessor,
    ConfigProtocol,
    ProcessingContext,
    ProcessingResult,
)
from ..utils import (
    BBoxSmoothingConfig,
    BBoxSmoothingTracker,
    apply_category_mapping,
    bbox_smoothing,
    filter_by_confidence,
    match_results_structure,
)

# Import alert system utilities
from ..utils.alert_instance_utils import ALERT_INSTANCE

_module_logger = logging.getLogger(__name__)


def _log_with_msg_meta(logger: logging.Logger, level: int, message: str) -> None:
    """Log *message* and append its character length (and rely on message for value types/lengths)."""
    logger.log(level, "%s | msg_len=%d", message, len(message))


# Get the major and minor version numbers
major_version = sys.version_info.major
minor_version = sys.version_info.minor
_log_with_msg_meta(
    _module_logger,
    logging.INFO,
    f"Python version: {major_version}.{minor_version} | version_info_part_types=int,int",
)
os.environ["ORT_LOG_SEVERITY_LEVEL"] = "3"

try:
    from matrice_common.session import Session
except ImportError:
    Session = None

# Pre-import AdvancedTracker to avoid per-frame import overhead
try:
    from ..advanced_tracker import AdvancedTracker as _AdvancedTracker
    from ..advanced_tracker.config import TrackerConfig as _TrackerConfig

    _HAS_ADVANCED_TRACKER = True
except ImportError:
    _AdvancedTracker = None
    _TrackerConfig = None
    _HAS_ADVANCED_TRACKER = False


# Lazy import mechanism for LicensePlateRecognizer
_OCR_IMPORT_SOURCE = None
_LicensePlateRecognizerClass = None


def _get_license_plate_recognizer_class():
    """Lazy load LicensePlateRecognizer with automatic installation fallback."""
    global _OCR_IMPORT_SOURCE, _LicensePlateRecognizerClass

    logging.debug(
        "LicensePlateRecognizer OCR import source at entry: %r", _OCR_IMPORT_SOURCE
    )

    if _LicensePlateRecognizerClass is not None:
        return _LicensePlateRecognizerClass

    # Try to import from local repo first
    try:
        from ..ocr.fast_plate_ocr_py38 import LicensePlateRecognizer

        _OCR_IMPORT_SOURCE = "local_repo"
        _LicensePlateRecognizerClass = LicensePlateRecognizer
        logging.info("Successfully imported LicensePlateRecognizer from local repo")
        return _LicensePlateRecognizerClass
    except ImportError as e:
        logging.debug(f"Could not import from local repo: {e}")

    # Try to import from installed package
    try:
        from fast_plate_ocr import LicensePlateRecognizer  # type: ignore

        _OCR_IMPORT_SOURCE = "installed_package"
        _LicensePlateRecognizerClass = LicensePlateRecognizer
        logging.info(
            "Successfully imported LicensePlateRecognizer from installed package"
        )
        return _LicensePlateRecognizerClass
    except ImportError as e:
        logging.warning(f"Could not import from installed package: {e}")

    # Try to install with GPU support first
    logging.info("Attempting to install fast-plate-ocr with GPU support...")
    try:
        import subprocess

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "fast-plate-ocr[onnx-gpu]",
                "--no-cache-dir",
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            logging.info("Successfully installed fast-plate-ocr[onnx-gpu]")
            try:
                from fast_plate_ocr import LicensePlateRecognizer  # type: ignore

                _OCR_IMPORT_SOURCE = "installed_package_gpu"
                _LicensePlateRecognizerClass = LicensePlateRecognizer
                logging.info(
                    "Successfully imported LicensePlateRecognizer after GPU installation"
                )
                return _LicensePlateRecognizerClass
            except ImportError as e:
                logging.warning(f"Installation succeeded but import failed: {e}")
        else:
            logging.warning(f"GPU installation failed: {result.stderr}")
    except Exception as e:
        logging.warning(f"Error during GPU installation: {e}")

    # Try to install with CPU support as fallback
    logging.info("Attempting to install fast-plate-ocr with CPU support...")
    try:
        import subprocess

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "fast-plate-ocr[onnx]",
                "--no-cache-dir",
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            logging.info("Successfully installed fast-plate-ocr[onnx]")
            try:
                from fast_plate_ocr import LicensePlateRecognizer  # type: ignore

                _OCR_IMPORT_SOURCE = "installed_package_cpu"
                _LicensePlateRecognizerClass = LicensePlateRecognizer
                logging.info(
                    "Successfully imported LicensePlateRecognizer after CPU installation"
                )
                return _LicensePlateRecognizerClass
            except ImportError as e:
                logging.error(f"Installation succeeded but import failed: {e}")
        else:
            logging.error(f"CPU installation failed: {result.stderr}")
    except Exception as e:
        logging.error(f"Error during CPU installation: {e}")

    # Return None if all attempts failed
    logging.error("All attempts to load or install LicensePlateRecognizer failed")
    _OCR_IMPORT_SOURCE = "unavailable"
    logging.debug("LicensePlateRecognizer OCR import source: %s", _OCR_IMPORT_SOURCE)
    return None


from ..core.config import AlertConfig, BaseConfig  # noqa: E402

# Internal utilities that are still required
from ..ocr.preprocessing import ImagePreprocessor  # noqa: E402

HAS_MATRICE_SESSION = True


@dataclass
class LicensePlateMonitorConfig(BaseConfig):
    """Configuration for License plate detection use case in License plate monitoring.

    Available OCR models (``ocr_model_name``):

    +-----------------------------------------+--------------+---------------------+-----------------------------------+
    | Model                                   | Architecture | Training Data       | Best For                          |
    +-----------------------------------------+--------------+---------------------+-----------------------------------+
    | cct-s-v1-global-model          (default)| CCT (S)      | Global plates       | General use                       |
    | cct-xs-v1-global-model                  | CCT (XS)     | Global plates       | Faster / smaller                  |
    | cct-s-relu-v1-global-model              | CCT-ReLU (S) | Global plates       | Same as S but with ReLU           |
    | cct-xs-relu-v1-global-model             | CCT-ReLU(XS) | Global plates       | Fastest CCT variant               |
    | european-plates-mobile-vit-v2-model     | MobileViT-v2 | European plates     | European plates specifically      |
    | global-plates-mobile-vit-v2-model       | MobileViT-v2 | Global (65+ countries)| Most comprehensive coverage      |
    | argentinian-plates-cnn-model            | CNN          | Argentinian plates  | Argentina only                    |
    | argentinian-plates-cnn-synth-model      | CNN          | Argentinian (synth) | Argentina only                    |
    +-----------------------------------------+--------------+---------------------+-----------------------------------+
    """

    enable_smoothing: bool = False
    smoothing_algorithm: str = "observability"  # "window" or "observability"
    smoothing_window_size: int = 20
    smoothing_cooldown_frames: int = 5
    smoothing_confidence_range_factor: float = 0.5
    confidence_threshold: float = 0.5
    frame_skip: int = 1
    fps: Optional[float] = None
    bbox_format: str = "auto"
    usecase_categories: List[str] = field(default_factory=lambda: ["license_plate"])
    target_categories: List[str] = field(default_factory=lambda: ["license_plate"])
    alert_config: Optional[AlertConfig] = None
    index_to_category: Optional[Dict[int, str]] = field(
        default_factory=lambda: {0: "license_plate"}
    )
    language: List[str] = field(default_factory=lambda: ["en"])
    country: str = field(default_factory=lambda: "us")
    ocr_mode: str = field(
        default_factory=lambda: "alphanumeric"
    )  # "alphanumeric" or "numeric" or "alphabetic"
    ocr_model_name: str = (
        "cct-s-v1-global-model"  # See table above for available models
    )
    ocr_device: str = "auto"  # "auto", "cuda", or "cpu"
    session: Optional[Session] = None
    lpr_server_id: Optional[str] = None  # Optional LPR server ID for remote logging
    redis_server_id: Optional[str] = None  # Optional Redis server ID for instant alerts
    plate_log_cooldown: float = (
        30.0  # Cooldown period in seconds for logging same plate
    )

    def validate(self) -> List[str]:
        """Validate configuration parameters."""
        errors = super().validate()
        if self.confidence_threshold < 0 or self.confidence_threshold > 1:
            errors.append("confidence_threshold must be between 0 and 1")
        if self.frame_skip <= 0:
            errors.append("frame_skip must be positive")
        if self.bbox_format not in ["auto", "xmin_ymin_xmax_ymax", "x_y_width_height"]:
            errors.append(
                "bbox_format must be one of: auto, xmin_ymin_xmax_ymax, x_y_width_height"
            )
        if self.smoothing_window_size <= 0:
            errors.append("smoothing_window_size must be positive")
        if self.smoothing_cooldown_frames < 0:
            errors.append("smoothing_cooldown_frames cannot be negative")
        if self.smoothing_confidence_range_factor <= 0:
            errors.append("smoothing_confidence_range_factor must be positive")
        return errors


class LicensePlateMonitorLogger:
    def __init__(self):
        self.session = None
        self.logger = logging.getLogger(__name__)
        self.lpr_server_id = None
        self.server_info = None
        self.plate_log_timestamps: Dict[
            str, float
        ] = {}  # Track last log time per plate
        self.server_base_url = None
        self.public_ip = self._get_public_ip()

    def initialize_session(self, config: LicensePlateMonitorConfig) -> None:
        """Initialize session and fetch server connection info if lpr_server_id is provided."""
        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            "[LP_LOGGING] ===== INITIALIZING LP LOGGER SESSION =====",
        )
        _sid = config.lpr_server_id
        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            f"[LP_LOGGING] Config lpr_server_id: {_sid!r} | id_type={type(_sid).__name__} id_repr_len={len(repr(_sid))}",
        )

        # Use existing session if provided, otherwise create new one
        if self.session and self.server_info and self.server_base_url:
            self.logger.info(
                "[LP_LOGGING] Session already initialized with server info, skipping re-initialization"
            )
            self.logger.info(
                f"[LP_LOGGING] Using existing server: {self.server_base_url}"
            )
            return
        elif self.session:
            self.logger.info(
                "[LP_LOGGING] Session exists but server info missing, continuing initialization..."
            )
        else:
            self.logger.info(
                "[LP_LOGGING] No existing session, initializing from scratch..."
            )

        if config.session:
            self.session = config.session
            self.logger.info("[LP_LOGGING]  Using provided session from config")

        if not self.session:
            # Initialize Matrice session
            if not HAS_MATRICE_SESSION:
                self.logger.error("[LP_LOGGING]  Matrice session module not available")
                raise ImportError(
                    "Matrice session is required for License Plate Monitoring"
                )
            try:
                self.logger.info(
                    "[LP_LOGGING] Creating new Matrice session from environment variables..."
                )
                account_number = os.getenv("MATRICE_ACCOUNT_NUMBER", "")
                access_key_id = os.getenv("MATRICE_ACCESS_KEY_ID", "")
                secret_key = os.getenv("MATRICE_SECRET_ACCESS_KEY", "")
                project_id = os.getenv("MATRICE_PROJECT_ID", "")

                self.logger.info(
                    f"[LP_LOGGING] Account Number: {'SET' if account_number else 'NOT SET'}"
                )
                self.logger.info(
                    f"[LP_LOGGING] Access Key ID: {'SET' if access_key_id else 'NOT SET'}"
                )
                self.logger.info(
                    f"[LP_LOGGING] Secret Key: {'SET' if secret_key else 'NOT SET'}"
                )
                self.logger.info(
                    f"[LP_LOGGING] Project ID: {'SET' if project_id else 'NOT SET'}"
                )

                self.session = Session(
                    account_number=account_number,
                    access_key=access_key_id,
                    secret_key=secret_key,
                    project_id=project_id,
                )
                self.logger.info(
                    "[LP_LOGGING]  Successfully initialized new Matrice session"
                )
            except Exception as e:
                self.logger.error(
                    f"[LP_LOGGING]  Failed to initialize Matrice session: {e}",
                    exc_info=True,
                )
                raise

        # Fetch server connection info if lpr_server_id is provided
        if config.lpr_server_id:
            self.lpr_server_id = config.lpr_server_id
            self.logger.info(f"[LP_LOGGING] CONFIG PRINTTEST: {config}")
            self.logger.info(
                f"[LP_LOGGING] Fetching LPR server connection info for server ID: {self.lpr_server_id}"
            )
            try:
                self.server_info = self.get_server_connection_info()
                if self.server_info:
                    self.logger.info(
                        "[LP_LOGGING]  Successfully fetched LPR server info"
                    )
                    self.logger.info(
                        f"[LP_LOGGING]   - Name: {self.server_info.get('name', 'Unknown')}"
                    )
                    self.logger.info(
                        f"[LP_LOGGING]   - Host: {self.server_info.get('host', 'Unknown')}"
                    )
                    self.logger.info(
                        f"[LP_LOGGING]   - Port: {self.server_info.get('port', 'Unknown')}"
                    )
                    self.logger.info(
                        f"[LP_LOGGING]   - Status: {self.server_info.get('status', 'Unknown')}"
                    )
                    self.logger.info(
                        f"[LP_LOGGING]   - Project ID: {self.server_info.get('projectID', 'Unknown')}"
                    )

                    # Compare server host with public IP to determine if it's localhost
                    server_host = self.server_info.get("host", "localhost")
                    server_port = self.server_info.get("port", 8200)

                    if server_host == self.public_ip:
                        self.server_base_url = f"http://localhost:{server_port}"
                        self.logger.info(
                            f"[LP_LOGGING] Server host matches public IP ({self.public_ip}), using localhost: {self.server_base_url}"
                        )
                    else:
                        self.server_base_url = f"http://{server_host}:{server_port}"
                        self.logger.info(
                            f"[LP_LOGGING] LPR server base URL configured: {self.server_base_url}"
                        )

                    self.session.update(self.server_info.get("projectID", ""))
                    self.logger.info(
                        f"[LP_LOGGING]  Updated Matrice session with project ID: {self.server_info.get('projectID', '')}"
                    )
                else:
                    self.logger.error(
                        "[LP_LOGGING]  Failed to fetch LPR server connection info - server_info is None"
                    )
                    self.logger.error(
                        "[LP_LOGGING] This will prevent plate logging from working!"
                    )
            except Exception as e:
                # pass
                self.logger.error(
                    f"[LP_LOGGING]  Error fetching LPR server connection info: {e}",
                    exc_info=True,
                )
                self.logger.error(
                    "[LP_LOGGING] This will prevent plate logging from working!"
                )
        else:
            self.logger.warning(
                "[LP_LOGGING] No lpr_server_id provided in config, skipping server connection info fetch"
            )

        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            "[LP_LOGGING] ===== LP LOGGER SESSION INITIALIZATION COMPLETE =====",
        )

    def _get_public_ip(self) -> str:
        """Get the public IP address of this machine."""
        self.logger.info("Fetching public IP address...")
        try:
            public_ip = (
                urllib.request.urlopen("https://v4.ident.me", timeout=120)
                .read()
                .decode("utf8")
                .strip()  # nosec B310
            )
            self.logger.info(f"Successfully fetched external IP: {public_ip}")
            return public_ip
        except Exception as e:
            self.logger.error(f"Error fetching external IP: {e}", exc_info=True)
            return "localhost"

    def _get_backend_base_url(self) -> str:
        """Resolve backend base URL based on ENV variable: prod/staging/dev."""
        env = os.getenv("ENV", "prod").strip().lower()
        if env in ("prod", "production"):
            host = "prod.backend.app.matrice.ai"
        elif env in ("dev", "development"):
            host = "dev.backend.app.matrice.ai"
        else:
            host = "staging.backend.app.matrice.ai"
        return f"https://{host}"

    def get_server_connection_info(self) -> Optional[Dict[str, Any]]:
        """Fetch server connection info from RPC."""
        if not self.lpr_server_id:
            self.logger.warning(
                "No lpr_server_id set, cannot fetch server connection info"
            )
            return None

        try:
            endpoint = f"/v1/actions/lpr_servers/{self.lpr_server_id}"
            self.logger.info(f"Sending GET request to: {endpoint}")
            response = self.session.rpc.get(endpoint)
            self.logger.info(
                f"Received response: success={response.get('success')}, code={response.get('code')}, message={response.get('message')}"
            )

            if response.get("success", False) and response.get("code") == 200:
                # Response format:
                # {'success': True,
                # 'code': 200,
                # 'message': 'Success',
                # 'serverTime': '2025-10-19T04:58:04Z',
                # 'data': {'id': '68f07e515cd5c6134a075384',
                # 'name': 'lpr-server-1',
                # 'host': '106.219.122.19',
                # 'port': 8200,
                # 'status': 'created',
                # 'accountNumber': '3823255831182978487149732',
                # 'projectID': '68ca6372ab79ba13ef699ba6',
                # 'region': 'United States',
                # 'isShared': False}}
                data = response.get("data", {})
                self.logger.info(
                    f"Server connection info retrieved: name={data.get('name')}, host={data.get('host')}, port={data.get('port')}, status={data.get('status')}"
                )
                return data
            else:
                self.logger.warning(
                    f"Failed to fetch server info: {response.get('message', 'Unknown error')}"
                )
                return None
        except Exception as e:
            self.logger.error(
                f"Exception while fetching server connection info: {e}", exc_info=True
            )
            return None

    def should_log_plate(self, plate_text: str, cooldown: float) -> bool:
        """Check if enough time has passed since last log for this plate."""
        current_time = time.time()
        last_log_time = self.plate_log_timestamps.get(plate_text, 0)
        time_since_last_log = current_time - last_log_time

        if time_since_last_log >= cooldown:
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING] OK - Plate '{plate_text}' ready to log (last logged {time_since_last_log:.1f}s ago, cooldown={cooldown}s) "
                f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__}",
            )
            return True
        else:
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING] SKIP - Plate '{plate_text}' in cooldown period ({time_since_last_log:.1f}s elapsed, {cooldown - time_since_last_log:.1f}s remaining) "
                f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__}",
            )
            return False

    def update_log_timestamp(self, plate_text: str) -> None:
        """Update the last log timestamp for a plate."""
        self.plate_log_timestamps[plate_text] = time.time()
        self.logger.debug(f"Updated log timestamp for plate: {plate_text}")

    def _format_timestamp_rfc3339(self, timestamp: str) -> str:
        """Convert timestamp to RFC3339 format (2006-01-02T15:04:05Z).

        Handles various input formats:
        - "YYYY-MM-DD-HH:MM:SS.ffffff UTC"
        - "YYYY:MM:DD HH:MM:SS"
        - Unix timestamp (float/int)
        """
        try:
            # If already in RFC3339 format, return as is
            if "T" in timestamp and timestamp.endswith("Z"):
                return timestamp

            # Try to parse common formats
            dt = None

            # Format: "2025-08-19-04:22:47.187574 UTC"
            if "-" in timestamp and "UTC" in timestamp:
                timestamp_clean = timestamp.replace(" UTC", "")
                dt = datetime.strptime(timestamp_clean, "%Y-%m-%d-%H:%M:%S.%f")
            # Format: "2025:10:23 14:30:45"
            elif ":" in timestamp and " " in timestamp:
                dt = datetime.strptime(timestamp, "%Y:%m:%d %H:%M:%S")
            # Format: numeric timestamp
            elif timestamp.replace(".", "").isdigit():
                dt = datetime.fromtimestamp(float(timestamp), tz=timezone.utc)

            if dt is None:
                # Fallback to current time
                dt = datetime.now(timezone.utc)
            else:
                # Ensure timezone is UTC
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)

            # Format to RFC3339: 2006-01-02T15:04:05Z
            return dt.strftime("%Y-%m-%dT%H:%M:%SZ")

        except Exception as e:
            self.logger.warning(
                f"Failed to parse timestamp '{timestamp}': {e}. Using current time."
            )
            return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    def _extract_camera_info_from_stream(
        self, stream_info: Optional[Dict[str, Any]]
    ) -> Dict[str, str]:
        """
        Extract camera_name, camera_id, and location_id from stream_info.

        Handles multiple sources and shapes for camera_id/camera_name/location_id to ensure
        correct extraction even when a single container is connected to multiple camera streams.

        Supported stream_info shapes (seen across pipeline/components):
        - stream_info["camera_info"]
        - stream_info["input_settings"]["camera_info"]
        - stream_info["input_settings"]["input_stream"]["camera_info"]
        - stream_info["input_streams"][i]["input_stream"]["camera_info"]
        - camera_id derived from stream_info["topic"] suffix markers ("_input_topic" or "_input-topic")

        Args:
            stream_info: Stream information dictionary

        Returns:
            Dict with camera_name, camera_id, location_id
        """
        camera_name = ""
        camera_id = ""
        location_id = ""

        if not stream_info or not isinstance(stream_info, dict):
            self.logger.debug(
                "stream_info is None/invalid, returning empty camera info"
            )
            return {
                "camera_name": camera_name,
                "camera_id": camera_id,
                "location_id": location_id,
            }

        def _to_str(value: Any) -> str:
            """Convert common stream-info values to a safe string."""
            if value is None:
                return ""
            if isinstance(value, str):
                return value.strip()
            if isinstance(value, (int, float)):
                return str(value)
            if isinstance(value, dict):
                return ""
            if isinstance(value, (list, tuple, set)):
                for item in value:
                    s = _to_str(item)
                    if s:
                        return s
                return ""
            try:
                return str(value).strip()
            except Exception:
                return ""

        def _dict_get_str(d: Any, *keys: str) -> str:
            """Get first non-empty key from dict as string."""
            if not isinstance(d, dict):
                return ""
            for k in keys:
                val = _to_str(d.get(k))
                if val:
                    return val
            return ""

        def _extract_camera_id_from_topic(topic_val: Any) -> str:
            """Extract camera_id from topic formats like '{camera_id}_input_topic' or '{camera_id}_input-topic'."""
            topic = _to_str(topic_val)
            if not topic:
                return ""
            for suffix in ("_input_topic", "_input-topic"):
                if topic.endswith(suffix):
                    return topic[: -len(suffix)].strip()
            for marker in ("_input_topic", "_input-topic"):
                if marker in topic:
                    return topic.split(marker)[0].strip()
            return ""

        def _extract_camera_id_from_frame_id(frame_id_val: Any) -> str:
            """
            Best-effort fallback: extract a stable camera/stream identifier from frame_id.

            Observed upstream format (py_inference legacy mode):
              - 'legacy_{hexId}_{suffix}'
            Example:
              - 'legacy_694e7603a086e13d9c95dd3d_51b30e93'

            We ONLY accept the middle segment if it looks like a hex identifier (>= 8 chars)
            to avoid mis-parsing arbitrary frame_id formats.
            """
            fid = _to_str(frame_id_val)
            if not fid:
                return ""
            if fid.startswith("legacy_"):
                parts = fid.split("_")
                if len(parts) >= 3:
                    candidate = parts[1].strip()
                    if candidate and re.fullmatch(
                        r"[0-9a-f]{8,}", candidate, re.IGNORECASE
                    ):
                        return candidate
            return ""

        input_settings = stream_info.get("input_settings") or {}
        if not isinstance(input_settings, dict):
            input_settings = {}

        camera_info_root = stream_info.get("camera_info") or {}
        if not isinstance(camera_info_root, dict):
            camera_info_root = {}

        camera_info_input_settings = input_settings.get("camera_info") or {}
        if not isinstance(camera_info_input_settings, dict):
            camera_info_input_settings = {}

        input_stream = input_settings.get("input_stream") or {}
        if not isinstance(input_stream, dict):
            input_stream = {}

        camera_info_input_stream = input_stream.get("camera_info") or {}
        if not isinstance(camera_info_input_stream, dict):
            camera_info_input_stream = {}

        input_streams = stream_info.get("input_streams") or []
        input_stream_candidates: List[Dict[str, Any]] = []
        camera_info_input_streams: List[Dict[str, Any]] = []
        if isinstance(input_streams, list):
            for item in input_streams:
                if not isinstance(item, dict):
                    continue
                inner = item.get("input_stream", item)
                if not isinstance(inner, dict):
                    continue
                input_stream_candidates.append(inner)
                ci = inner.get("camera_info") or {}
                if isinstance(ci, dict) and ci:
                    camera_info_input_streams.append(ci)

        topic_camera_id = _extract_camera_id_from_topic(
            stream_info.get("topic")
        ) or _extract_camera_id_from_topic(input_settings.get("topic"))
        if not topic_camera_id:
            topics_val = stream_info.get("topics")
            if isinstance(topics_val, (list, tuple, set)):
                for t in topics_val:
                    topic_camera_id = _extract_camera_id_from_topic(t)
                    if topic_camera_id:
                        break

        camera_info_sources: List[Dict[str, Any]] = [
            camera_info_root,
            camera_info_input_settings,
            camera_info_input_stream,
        ] + camera_info_input_streams

        def _camera_id_from_camera_info(ci: Dict[str, Any]) -> str:
            return _dict_get_str(ci, "camera_id", "cameraId", "_id", "id")

        matched_ci: Dict[str, Any] = {}
        if topic_camera_id:
            camera_id = topic_camera_id
            for ci in camera_info_sources:
                if _camera_id_from_camera_info(ci) == camera_id:
                    matched_ci = ci
                    break

        if not camera_id:
            camera_id = (
                _dict_get_str(stream_info, "camera_id", "cameraId")
                or _dict_get_str(input_settings, "camera_id", "cameraId")
                or _camera_id_from_camera_info(camera_info_root)
                or _camera_id_from_camera_info(camera_info_input_settings)
                or _camera_id_from_camera_info(camera_info_input_stream)
            )
            if not camera_id:
                for candidate in input_stream_candidates:
                    camera_id = _dict_get_str(
                        candidate, "camera_id", "cameraId", "_id", "id"
                    )
                    if camera_id:
                        break
            if not camera_id:
                camera_id = topic_camera_id

        # Final fallback: derive camera_id from frame_id if stream_info doesn't include camera_info/topic
        if not camera_id:
            camera_id = _extract_camera_id_from_frame_id(stream_info.get("frame_id"))

        # Use matched camera_info (if found) to set camera_name/location_id
        if matched_ci:
            camera_name = _dict_get_str(matched_ci, "camera_name", "cameraName", "name")
            location_id = _dict_get_str(
                matched_ci, "location", "location_id", "locationId"
            )

        if not camera_name:
            camera_name = (
                _dict_get_str(camera_info_root, "camera_name", "cameraName", "name")
                or _dict_get_str(
                    camera_info_input_settings, "camera_name", "cameraName", "name"
                )
                or _dict_get_str(
                    camera_info_input_stream, "camera_name", "cameraName", "name"
                )
                or _dict_get_str(stream_info, "camera_name", "cameraName")
                or _dict_get_str(input_settings, "camera_name", "cameraName")
            )
            if not camera_name:
                for ci in camera_info_input_streams:
                    camera_name = _dict_get_str(ci, "camera_name", "cameraName", "name")
                    if camera_name:
                        break

        if not location_id:
            location_id = (
                _dict_get_str(camera_info_root, "location", "location_id", "locationId")
                or _dict_get_str(
                    camera_info_input_settings, "location", "location_id", "locationId"
                )
                or _dict_get_str(
                    camera_info_input_stream, "location", "location_id", "locationId"
                )
                or _dict_get_str(stream_info, "location_id", "location", "locationId")
                or _dict_get_str(
                    input_settings, "location_id", "location", "locationId"
                )
            )
            if not location_id:
                for ci in camera_info_input_streams:
                    location_id = _dict_get_str(
                        ci, "location", "location_id", "locationId"
                    )
                    if location_id:
                        break

        self.logger.debug(
            "Extracted camera info - camera_name: '%s', camera_id: '%s', location_id: '%s'",
            camera_name,
            camera_id,
            location_id,
        )

        return {
            "camera_name": camera_name,
            "camera_id": camera_id,
            "location_id": location_id,
        }

    async def log_plate(
        self,
        plate_text: str,
        timestamp: str,
        stream_info: Dict[str, Any],
        image_data: Optional[str] = None,
        cooldown: float = 30.0,
    ) -> bool:
        """Log plate to RPC server with cooldown period.

        Args:
            plate_text: The license plate text
            timestamp: Capture timestamp
            stream_info: Stream information dict
            image_data: Base64-encoded JPEG image of the license plate crop
            cooldown: Cooldown period in seconds
        """
        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            "[LP_LOGGING] ===== PLATE LOG REQUEST START =====",
        )
        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            f"[LP_LOGGING] Plate: '{plate_text}', Timestamp: {timestamp} "
            f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__} "
            f"ts_len={len(str(timestamp))} ts_type={type(timestamp).__name__}",
        )

        # Check cooldown
        if not self.should_log_plate(plate_text, cooldown):
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING]  Plate '{plate_text}' NOT SENT - skipped due to cooldown period "
                f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__}",
            )
            self.logger.info("[LP_LOGGING] ===== PLATE LOG REQUEST END (SKIPPED) =====")
            return False

        if not stream_info:
            self.logger.info("[LP_LOGGING] Stream info is None, skipping plate log")
            stream_info = {}

        try:
            camera_info = self._extract_camera_info_from_stream(stream_info)
            camera_id = camera_info.get("camera_id", "")
            camera_name = camera_info.get("camera_name", "default_camera")
            location = camera_info.get("location", "default_location")
            input_settings = (
                stream_info.get("input_settings", {})
                if isinstance(stream_info.get("input_settings", {}), dict)
                else {}
            )
            frame_id = (
                stream_info.get("frame_id", "")
                or stream_info.get("frameId", "")
                or input_settings.get("frame_id", "")
                or input_settings.get("frameId", "")
                or ""
            )
            rtp_number = (
                stream_info.get("rtp_number", "")
                or stream_info.get("rtpNumber", "")
                or input_settings.get("rtp_number", "")
                or input_settings.get("rtpNumber", "")
                or ""
            )
            try:
                if rtp_number in (None, ""):
                    rtp_number_int = 0
                else:
                    rtp_number_int = int(rtp_number)
            except (TypeError, ValueError):
                rtp_number_int = 0

            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING] Stream Info - Camera: '{camera_name}', Location: '{location}', Frame ID: '{frame_id}', RTP Number: '{rtp_number}' (int={rtp_number_int}) "
                f"| camera_name_len={len(str(camera_name))} camera_name_type={type(camera_name).__name__} "
                f"location_len={len(str(location))} location_type={type(location).__name__} "
                f"frame_id_len={len(str(frame_id))} rtp_number_len={len(str(rtp_number))}",
            )

            # Get project ID from server_info
            self.logger.info(f"[LP_LOGGING] SERVER-INFO: '{self.server_info}'")
            project_id = (
                self.server_info.get("projectID", "") if self.server_info else ""
            )
            self.logger.info(f"[LP_LOGGING] Project ID: '{project_id}'")

            # Format timestamp to RFC3339 format (2006-01-02T15:04:05Z)
            rfc3339_timestamp = self._format_timestamp_rfc3339(timestamp)
            self.logger.info(
                f"[LP_LOGGING] Formatted timestamp: {timestamp} -> {rfc3339_timestamp}"
            )

            payload = {
                "licensePlate": plate_text,
                "frameId": frame_id,
                "rtpNumber": rtp_number_int,
                "location": location,
                "camera": camera_name,
                "cameraId": camera_id,
                "captureTimestamp": rfc3339_timestamp,
                "projectId": project_id,
                "imageData": image_data if image_data else "",
            }

            # Add projectId as query parameter
            endpoint = f"/v1/lpr-server/detections?projectId={project_id}"
            full_url = f"{self.server_base_url}{endpoint}"
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING] Sending POST request to: {full_url} | url_len={len(full_url)} url_type={type(full_url).__name__}",
            )
            self.logger.info(
                f"[LP_LOGGING] Payload: licensePlate='{plate_text}', frameId='{frame_id}', "
                f"rtpNumber={rtp_number_int} (raw={rtp_number!r}), location='{location}', "
                f"camera='{camera_name}', cameraId='{camera_id}'"
            )

            response = await self.session.rpc.post_async(
                endpoint, payload=payload, base_url=self.server_base_url
            )

            _resp_repr = repr(response)
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING]  API Response received: {response} | response_type={type(response).__name__} repr_len={len(_resp_repr)}",
            )

            # Update timestamp after successful log
            self.update_log_timestamp(plate_text)
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING]  Plate '{plate_text}' SUCCESSFULLY SENT at {rfc3339_timestamp} "
                f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__}",
            )
            self.logger.info("[LP_LOGGING] ===== PLATE LOG REQUEST END (SUCCESS) =====")
            return True

        except Exception as e:
            _err_body = (
                f"[LP_LOGGING]  Plate '{plate_text}' NOT SENT - Exception occurred: {e} "
                f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__} err_type={type(e).__name__}"
            )
            self.logger.error(
                "%s | msg_len=%d", _err_body, len(_err_body), exc_info=True
            )
            self.logger.info("[LP_LOGGING] ===== PLATE LOG REQUEST END (FAILED) =====")
            return False


class _DetectionSmoother:
    """Temporal smoothing: carry forward tracked detections for a few frames to reduce flickering.

    When the model intermittently drops a detection for 1-2 frames, the overlay
    blinks on the frontend.  This buffer carries the last-known position forward
    with decaying confidence until the model picks it up again (or the hold
    window expires).
    """

    def __init__(self, hold_frames: int = 3, iou_threshold: float = 0.3):
        self._buffers: Dict[
            str, Dict
        ] = {}  # camera_id -> {track_key: {det, last_seen, miss_count}}
        self._hold_frames = hold_frames
        self._iou_threshold = iou_threshold

    @staticmethod
    def _iou(a: dict, b: dict) -> float:
        x1 = max(a["xmin"], b["xmin"])
        y1 = max(a["ymin"], b["ymin"])
        x2 = min(a["xmax"], b["xmax"])
        y2 = min(a["ymax"], b["ymax"])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        if inter == 0:
            return 0.0
        a1 = (a["xmax"] - a["xmin"]) * (a["ymax"] - a["ymin"])
        a2 = (b["xmax"] - b["xmin"]) * (b["ymax"] - b["ymin"])
        return inter / (a1 + a2 - inter) if (a1 + a2 - inter) > 0 else 0.0

    def smooth(self, camera_id: str, detections: list, frame_idx: int) -> list:
        """Merge current detections with buffered ones.  Returns smoothed list."""
        buf = self._buffers.setdefault(camera_id, {})

        matched_keys: set = set()
        for det in detections:
            bb = det.get("bounding_box", {})
            if not bb or "xmin" not in bb:
                continue
            tid = det.get("track_id", "")
            # Exact track_id match (persistent IDs only)
            if tid and not str(tid).startswith("simple_") and tid in buf:
                buf[tid] = {"det": dict(det), "last_seen": frame_idx, "miss_count": 0}
                matched_keys.add(tid)
                continue
            # IoU fallback
            best_key, best_iou = None, 0.0
            for key, entry in buf.items():
                if key in matched_keys:
                    continue
                ebb = entry["det"].get("bounding_box", {})
                if ebb and "xmin" in ebb:
                    iou = self._iou(bb, ebb)
                    if iou > best_iou:
                        best_iou = iou
                        best_key = key
            if best_key and best_iou > self._iou_threshold:
                buf[best_key]["det"] = dict(det)
                buf[best_key]["det"]["track_id"] = best_key
                buf[best_key]["last_seen"] = frame_idx
                buf[best_key]["miss_count"] = 0
                matched_keys.add(best_key)
            else:
                key = (
                    tid
                    if tid and not str(tid).startswith("simple_")
                    else f"s_{frame_idx}_{id(det)}"
                )
                buf[key] = {"det": dict(det), "last_seen": frame_idx, "miss_count": 0}
                matched_keys.add(key)

        # Carry forward missing detections
        carried: list = []
        expired: list = []
        for key, entry in buf.items():
            if key in matched_keys:
                continue
            entry["miss_count"] += 1
            if entry["miss_count"] <= self._hold_frames:
                carry_det = dict(entry["det"])
                orig_conf = carry_det.get("confidence", 0.5)
                carry_det["confidence"] = round(
                    max(0.1, orig_conf - 0.05 * entry["miss_count"]), 2
                )
                carried.append(carry_det)
            else:
                expired.append(key)
        for key in expired:
            del buf[key]

        return detections + carried


def _map_tracker_ids_to_source(source_data: list, tracked_data: list) -> None:
    """Write persistent track IDs from *tracked_data* back into the original *source_data* dicts (in-place).

    After ``tracker.update()`` returns **new** detection dicts with ``track_id``
    assigned, the original model-output dicts (``source_data``) still lack IDs.
    This function matches each source detection to its tracked counterpart via
    bounding-box IoU and copies the ``track_id`` over so that callers who hold a
    reference to the original list (e.g. workers.py → ``format_output_rtp``)
    automatically see the correct IDs.
    """
    if not tracked_data:
        return
    for src in source_data:
        sbb = src.get("bounding_box", src.get("bbox", {}))
        if not sbb or "xmin" not in sbb:
            continue
        best_iou, best_tid = 0.0, None
        for trk in tracked_data:
            tid = trk.get("track_id")
            tbb = trk.get("bounding_box", trk.get("bbox", {}))
            if tid is None or not tbb or "xmin" not in tbb:
                continue
            x1 = max(float(sbb["xmin"]), float(tbb["xmin"]))
            y1 = max(float(sbb["ymin"]), float(tbb["ymin"]))
            x2 = min(float(sbb["xmax"]), float(tbb["xmax"]))
            y2 = min(float(sbb["ymax"]), float(tbb["ymax"]))
            inter = max(0, x2 - x1) * max(0, y2 - y1)
            if inter == 0:
                continue
            a1 = (float(sbb["xmax"]) - float(sbb["xmin"])) * (
                float(sbb["ymax"]) - float(sbb["ymin"])
            )
            a2 = (float(tbb["xmax"]) - float(tbb["xmin"])) * (
                float(tbb["ymax"]) - float(tbb["ymin"])
            )
            iou = inter / (a1 + a2 - inter) if (a1 + a2 - inter) > 0 else 0
            if iou > best_iou:
                best_iou = iou
                best_tid = tid
        if best_tid is not None and best_iou > 0.3:
            src["track_id"] = best_tid


class LicensePlateMonitorUseCase(BaseProcessor):
    CATEGORY_DISPLAY = {"license_plate": "license_plate"}

    def __init__(self):
        super().__init__("license_plate_monitor")
        self.category = "license_plate_monitor"
        self.target_categories = ["license_plate"]
        self.CASE_TYPE: Optional[str] = "license_plate_monitor"
        self.CASE_VERSION: Optional[str] = "1.3"
        self.smoothing_tracker = None
        self.tracker = None
        self._total_frame_counter = 0
        self._global_frame_offset = 0
        self._tracking_start_time = None
        self._track_aliases: Dict[Any, Any] = {}
        self._canonical_tracks: Dict[Any, Dict[str, Any]] = {}
        self._track_merge_iou_threshold: float = 0.05
        self._track_merge_time_window: float = 7.0
        self._ascending_alert_list: List[int] = []
        self.current_incident_end_timestamp: str = "N/A"
        self._seen_plate_texts = set()
        # CHANGE: Added _tracked_plate_texts to store the longest plate_text per track_id
        self._tracked_plate_texts: Dict[Any, str] = {}
        # Containers for text stability & uniqueness
        self._unique_plate_texts: Dict[
            str, str
        ] = {}  # cleaned_text -> original (longest)
        # NEW: track-wise frequency of cleaned texts to pick the dominant variant per track
        self._track_text_counts: Dict[Any, Counter] = defaultdict(
            Counter
        )  # track_id -> Counter(cleaned_text -> count)
        # Helper dictionary to keep history of plate texts per track
        self.helper: Dict[Any, List[str]] = {}
        # Map of track_id -> current dominant plate text
        self.unique_plate_track: Dict[Any, str] = {}
        self.image_preprocessor = ImagePreprocessor()
        # OCR model will be lazily initialized when first used
        self.ocr_model = None
        self._ocr_model_name = "cct-s-v1-global-model"
        self._ocr_device = "auto"
        self._ocr_initialization_attempts = 0
        self._ocr_max_init_attempts = 3
        # OCR text history for stability checks (text  consecutive frame count)
        self._text_history: Dict[str, int] = {}

        self.start_timer = None
        # self.reset_timer = "2025-08-19-04:22:47.187574 UTC"

        # Minimum length for a valid plate (after cleaning)
        self._min_plate_len = 3
        # number of consecutive frames a plate must appear to be considered "stable"
        self._stable_frames_required = 1
        self._non_alnum_regex = re.compile(r"[^A-Za-z0-9]+")
        self._ocr_mode = "alphanumeric"
        self._ocr_confidence_threshold = 0.75
        self._bgr_frame = None
        self._detection_smoother = _DetectionSmoother(hold_frames=3, iou_threshold=0.3)
        # self.jpeg = TurboJPEG()

        # Initialize plate logger (optional, only used if lpr_server_id is provided)
        self.plate_logger: Optional[LicensePlateMonitorLogger] = None
        self._logging_enabled = (
            True  # False  //ToDo: DISABLED FOR NOW, ENABLED FOR PRODUCTION. ##
        )
        self._plate_logger_initialized = (
            False  # Track if plate logger has been initialized
        )

        # Track which track_ids have been logged to avoid duplicate logging
        # Only log confirmed/consensus plates, not every OCR prediction
        self._logged_track_ids: set = set()
        # Track which plate texts have been logged to ensure uniqueness by plate value
        self._logged_plate_texts: set = set()

        # Initialize instant alert manager (will be lazily initialized on first process() call)
        self.alert_manager: Optional[ALERT_INSTANCE] = None
        self._alert_manager_initialized = (
            False  # Track initialization to do it only once
        )

    def set_alert_manager(self, alert_manager: ALERT_INSTANCE) -> None:
        """
        Set the alert manager instance for instant alerts.

        Args:
            alert_manager: ALERT_INSTANCE instance configured with Redis/Kafka clients
        """
        self.alert_manager = alert_manager
        self.logger.info("Alert manager set for license plate monitoring")

    def _discover_action_id(self) -> Optional[str]:
        """Discover action_id from current working directory name (and parents), similar to face_recognition flow."""
        try:
            import re as _re

            pattern = _re.compile(r"^[0-9a-f]{8,}$", _re.IGNORECASE)
            candidates: List[str] = []
            try:
                cwd = Path.cwd()
                candidates.append(cwd.name)
                for parent in cwd.parents:
                    candidates.append(parent.name)
            except Exception:
                # Non-fatal: exception ignored here; execution continues per surrounding logic.
                pass

            try:
                usr_src = Path("/usr/src")
                if usr_src.exists():
                    for child in usr_src.iterdir():
                        if child.is_dir():
                            candidates.append(child.name)
            except Exception:
                # Non-fatal: exception ignored here; execution continues per surrounding logic.
                pass

            for candidate in candidates:
                if candidate and len(candidate) >= 8 and pattern.match(candidate):
                    return candidate
        except Exception:
            # Non-fatal: exception ignored here; execution continues per surrounding logic.
            pass
        return None

    def _get_backend_base_url(self) -> str:
        """Resolve backend base URL based on ENV variable: prod/staging/dev."""
        env = os.getenv("ENV", "prod").strip().lower()
        if env in ("prod", "production"):
            host = "prod.backend.app.matrice.ai"
        elif env in ("dev", "development"):
            host = "dev.backend.app.matrice.ai"
        else:
            host = "staging.backend.app.matrice.ai"
        return f"https://{host}"

    def _mask_value(self, value: Optional[str]) -> str:
        """Mask sensitive values for logging/printing."""
        if not value:
            return ""
        if len(value) <= 4:
            return "*" * len(value)
        return value[:2] + "*" * (len(value) - 4) + value[-2:]

    def _get_public_ip(self) -> str:
        """Get the public IP address of this machine."""
        self.logger.info("Fetching public IP address...")
        try:
            public_ip = (
                urllib.request.urlopen("https://v4.ident.me", timeout=120)
                .read()
                .decode("utf8")
                .strip()  # nosec B310
            )
            # self.logger.info(f"Successfully fetched external IP: {public_ip}")
            return public_ip
        except Exception:
            # self.logger.error(f"Error fetching external IP: {e}", exc_info=True)
            return "localhost"

    def _fetch_location_name(
        self, location_id: str, session: Optional[Session] = None
    ) -> str:
        """
        Fetch location name from API using location_id.

        Args:
            location_id: The location ID to look up
            session: Matrice session for API calls

        Returns:
            Location name string, or 'Entry Reception' as default if API fails
        """
        default_location = "Entry Reception"

        if not location_id:
            self.logger.debug(
                f"[LOCATION] No location_id provided, using default: '{default_location}'"
            )
            return default_location

        # Check cache first
        if not hasattr(self, "_location_name_cache"):
            self._location_name_cache: Dict[str, str] = {}

        if location_id in self._location_name_cache:
            cached_name = self._location_name_cache[location_id]
            self.logger.debug(
                f"[LOCATION] Using cached location name for '{location_id}': '{cached_name}'"
            )
            return cached_name

        if not session:
            self.logger.warning(
                f"[LOCATION] No session provided, using default: '{default_location}'"
            )
            return default_location

        try:
            endpoint = f"/v1/inference/get_location/{location_id}"
            self.logger.info(f"[LOCATION] Fetching location name from API: {endpoint}")

            response = session.rpc.get(endpoint)

            if response and isinstance(response, dict):
                success = response.get("success", False)
                if success:
                    data = response.get("data", {})
                    location_name = data.get("locationName", default_location)
                    self.logger.info(
                        f"[LOCATION] ✓ Fetched location name: '{location_name}' for location_id: '{location_id}'"
                    )

                    # Cache the result
                    self._location_name_cache[location_id] = location_name
                    return location_name
                else:
                    self.logger.warning(
                        f"[LOCATION] API returned success=false for location_id '{location_id}': "
                        f"{response.get('message', 'Unknown error')}"
                    )
            else:
                self.logger.warning(
                    f"[LOCATION] Invalid response format from API: {response}"
                )

        except Exception as e:
            self.logger.error(
                f"[LOCATION] Error fetching location name for '{location_id}': {e}",
                exc_info=True,
            )

        # Use default on any failure
        self.logger.info(
            f"[LOCATION] Using default location name: '{default_location}'"
        )
        self._location_name_cache[location_id] = default_location
        return default_location

    def _initialize_alert_manager_once(self, config: LicensePlateMonitorConfig) -> None:
        """
        Initialize alert manager ONCE with Redis OR Kafka clients (Environment based).
        Called from process() on first invocation.
        Uses config.session (existing session from pipeline).
        """
        if self._alert_manager_initialized:
            return

        try:
            # Import required modules
            from matrice_common.stream.matrice_stream import MatriceStream, StreamType

            # Use existing session from config (same pattern as plate_logger)
            if not config.session:
                account_number = os.getenv("MATRICE_ACCOUNT_NUMBER", "")
                access_key_id = os.getenv("MATRICE_ACCESS_KEY_ID", "")
                secret_key = os.getenv("MATRICE_SECRET_ACCESS_KEY", "")
                project_id = os.getenv("MATRICE_PROJECT_ID", "")

                self.session = Session(
                    account_number=account_number,
                    access_key=access_key_id,
                    secret_key=secret_key,
                    project_id=project_id,
                )
                config.session = self.session
                if not self.session:
                    self.logger.warning(
                        "[ALERT] No session in config OR manual, skipping alert manager initialization"
                    )
                    self._alert_manager_initialized = True
                    return

            rpc = config.session.rpc

            # Determine environment: Localhost vs Cloud
            # We use LPR server info to determine if we are local or cloud, similar to face_recognition_client
            is_localhost = False
            lpr_server_id = config.lpr_server_id
            _cfg_repr = repr(config)
            self.logger.info(
                "[ALERT] CONFIG-PRINT | config_type=%s repr_len=%d",
                type(config).__name__,
                len(_cfg_repr),
            )
            self.logger.debug("[ALERT] CONFIG-PRINT repr=%s", _cfg_repr)
            if lpr_server_id:
                try:
                    # Fetch LPR server info to compare IPs
                    response = rpc.get(f"/v1/actions/lpr_servers/{lpr_server_id}")
                    if response.get("success", False) and response.get("data"):
                        server_data = response.get("data", {})
                        server_host = server_data.get("host", "")
                        public_ip = self._get_public_ip()

                        # Check if server_host indicates localhost
                        localhost_indicators = ["localhost", "127.0.0.1", "0.0.0.0"]  # nosec B104
                        if (
                            server_host in localhost_indicators
                            or server_host == public_ip
                        ):
                            is_localhost = True
                            self.logger.info(
                                f"[ALERT] Detected Localhost environment (Public IP={public_ip}, Server IP={server_host})"
                            )
                        else:
                            is_localhost = False
                            self.logger.info(
                                f"[ALERT] Detected Cloud environment (Public IP={public_ip}, Server IP={server_host})"
                            )
                    else:
                        self.logger.warning(
                            "[ALERT] Failed to fetch LPR server info for environment detection, defaulting to Cloud mode"
                        )
                except Exception as e:
                    self.logger.warning(
                        f"[ALERT] Error detecting environment: {e}, defaulting to Cloud mode"
                    )
            else:
                self.logger.info("[ALERT] No LPR server ID, defaulting to Cloud mode")

            # ------------------------------------------------------------------
            # Discover action_id and fetch action details (STRICT API-DRIVEN)
            # ------------------------------------------------------------------
            action_id = self._discover_action_id()
            if not action_id:
                self.logger.error(
                    "[ALERT] Could not discover action_id from working directory or parents"
                )
                _log_with_msg_meta(
                    self.logger,
                    logging.WARNING,
                    "[ALERT] ALERT ACTION DISCOVERY | action_id=NOT FOUND | note=discover_returned_falsy",
                )
                self._alert_manager_initialized = True
                return

            try:
                action_url = f"/v1/actions/action/{action_id}/details"
                action_resp = rpc.get(action_url)
                if not (action_resp and action_resp.get("success", False)):
                    raise RuntimeError(
                        action_resp.get("message", "Unknown error")
                        if isinstance(action_resp, dict)
                        else "Unknown error"
                    )
                action_doc = (
                    action_resp.get("data", {}) if isinstance(action_resp, dict) else {}
                )
                action_details = (
                    action_doc.get("actionDetails", {})
                    if isinstance(action_doc, dict)
                    else {}
                )

                # server id and type extraction (robust to variants)
                server_id = (
                    action_details.get("serverId")
                    or action_details.get("server_id")
                    or action_details.get("serverID")
                    or action_details.get("redis_server_id")
                    or action_details.get("kafka_server_id")
                )
                server_type = (
                    action_details.get("serverType")
                    or action_details.get("server_type")
                    or action_details.get("type")
                )

                # Persist identifiers for future
                self._action_id = action_id
                self._deployment_id = action_details.get(
                    "_idDeployment"
                ) or action_details.get("deployment_id")
                self._app_deployment_id = action_details.get("app_deployment_id")
                self._instance_id = action_details.get(
                    "instanceID"
                ) or action_details.get("instanceId")
                self._external_ip = action_details.get(
                    "externalIP"
                ) or action_details.get("externalIp")

                _ad_msg = (
                    f"[ALERT] ALERT ACTION DETAILS | action_id={action_id!r} server_type={server_type!r} server_id={server_id!r} "
                    f"deployment_id={self._deployment_id!r} app_deployment_id={self._app_deployment_id!r} "
                    f"instance_id={self._instance_id!r} external_ip={self._external_ip!r} "
                    f"| types={type(action_id).__name__},{type(server_type).__name__},{type(server_id).__name__}"
                )
                _log_with_msg_meta(self.logger, logging.INFO, _ad_msg)
                self.logger.info(
                    f"[ALERT] Action details fetched | action_id={action_id}, server_type={server_type}, server_id={server_id}"
                )
                self.logger.debug(f"[ALERT] Full action_details: {action_details}")
            except Exception as e:
                self.logger.error(
                    f"[ALERT] Failed to fetch action details for action_id={action_id}: {e}",
                    exc_info=True,
                )
                _ade_msg = (
                    f"[ALERT] ALERT ACTION DETAILS ERROR | action_id={action_id!r} id_type={type(action_id).__name__} "
                    f"error={e!r} err_type={type(e).__name__}"
                )
                _log_with_msg_meta(self.logger, logging.ERROR, _ade_msg)
                self._alert_manager_initialized = True
                return

            # Historical deployment behavior: always initialize via Redis (instance API), not Kafka.
            is_localhost = True

            redis_client = None
            kafka_client = None

            # STRICT SWITCH: Only Redis if localhost, Only Kafka if cloud
            if is_localhost:
                # Initialize Redis client (ONLY) using STRICT API by instanceID
                instance_id = getattr(self, "_instance_id", None)
                if not instance_id:
                    self.logger.error(
                        "[ALERT] Localhost mode but instance_id missing in action details for Redis initialization"
                    )
                else:
                    try:
                        url = (
                            f"/v1/actions/get_redis_server_by_instance_id/{instance_id}"
                        )
                        self.logger.info(
                            f"[ALERT] Initializing Redis client via API for Localhost mode (instance_id={instance_id})"
                        )
                        response = rpc.get(url)
                        if isinstance(response, dict) and response.get(
                            "success", False
                        ):
                            data = response.get("data", {})
                            host = data.get("host")
                            port = data.get("port")
                            username = data.get("username")
                            password = data.get("password", "")
                            db_index = data.get("db", 0)
                            conn_timeout = data.get("connection_timeout", 120)

                            # Sentinel HA support
                            sentinel_hosts = None
                            master_name = None
                            sentinel_cfg = data.get("sentinelConfig") or {}
                            if sentinel_cfg.get("sentinelHosts"):
                                sentinel_hosts = [
                                    (h, 26379) for h in sentinel_cfg["sentinelHosts"]
                                ]
                                master_name = sentinel_cfg.get("masterName")

                            sentinel_str = (
                                f"yes, master={master_name}, nodes={len(sentinel_hosts)}"
                                if sentinel_hosts
                                else "no"
                            )

                            self.logger.debug(
                                "[ALERT] Redis server params (credentials redacted) | instance_id=%s host=%s port=%s db=%s timeout=%s sentinel=%s has_user=%s",
                                instance_id,
                                host,
                                port,
                                db_index,
                                conn_timeout,
                                sentinel_str,
                                bool(username),
                            )

                            self.logger.info(
                                "[ALERT] Redis server params | instance_id=%s, host=%s, port=%s, db=%s, sentinel=%s",
                                instance_id,
                                host,
                                port,
                                db_index,
                                sentinel_str,
                            )

                            # Initialize with Sentinel support
                            stream_kwargs = dict(
                                host=host,
                                port=int(port),
                                password=password,
                                username=username,
                                db=db_index,
                                connection_timeout=conn_timeout,
                            )
                            if sentinel_hosts and master_name:
                                stream_kwargs["sentinel_hosts"] = sentinel_hosts
                                stream_kwargs["master_name"] = master_name
                            redis_client = MatriceStream(
                                StreamType.REDIS, **stream_kwargs
                            )
                            redis_client.setup("alert_instant_config_request")
                            self.logger.info(
                                "[ALERT] Redis client initialized successfully"
                            )
                        else:
                            self.logger.warning(
                                f"[ALERT] Failed to fetch Redis server info: {response.get('message', 'Unknown error') if isinstance(response, dict) else 'Unknown error'}"
                            )
                    except Exception as e:
                        self.logger.warning(f"[ALERT] Redis initialization failed: {e}")

            # Create alert manager if client is available
            if redis_client or kafka_client:
                # Get app_deployment_id from action_details for filtering alerts
                app_deployment_id_for_alert = getattr(self, "_app_deployment_id", None)
                self.logger.info(
                    f"[ALERT] Using app_deployment_id for alert filtering: {app_deployment_id_for_alert}"
                )

                self.alert_manager = ALERT_INSTANCE(
                    redis_client=redis_client,
                    kafka_client=kafka_client,
                    config_topic="alert_instant_config_request",
                    trigger_topic="alert_instant_triggered",
                    polling_interval=10,  # Poll every 10 seconds
                    logger=self.logger,
                    app_deployment_id=app_deployment_id_for_alert,
                )
                self.alert_manager.start()
                transport = "Redis" if redis_client else "Kafka"
                self.logger.info(
                    f"[ALERT] Alert manager initialized and started with {transport} (polling every 10s)"
                )
            else:
                self.logger.warning(
                    f"[ALERT] No {'Redis' if is_localhost else 'Kafka'} client available for {'Localhost' if is_localhost else 'Cloud'} mode, alerts disabled"
                )

        except Exception as e:
            self.logger.error(
                f"[ALERT] Alert manager initialization failed: {e}", exc_info=True
            )
        finally:
            self._alert_manager_initialized = (
                True  # Mark as initialized (don't retry every frame)
            )

    def reset_tracker(self) -> None:
        """Reset the advanced tracker instance."""
        if self.tracker is not None:
            self.tracker.reset()
            self.logger.info("AdvancedTracker reset for new tracking session")

    def reset_plate_tracking(self) -> None:
        """Reset plate tracking state."""
        self._seen_plate_texts = set()
        # CHANGE: Reset _tracked_plate_texts
        self._tracked_plate_texts = {}
        self._total_frame_counter = 0
        self._global_frame_offset = 0
        self._text_history = {}
        self._unique_plate_texts = {}
        self.helper = {}
        self.unique_plate_track = {}
        # Reset logged track_ids and plate_texts to allow fresh logging
        self._logged_track_ids = set()
        self._logged_plate_texts = set()
        self.logger.info("Plate tracking state reset")

    def reset_all_tracking(self) -> None:
        """Reset both advanced tracker and plate tracking state."""
        self.reset_tracker()
        self.reset_plate_tracking()
        self.logger.info("All plate tracking state reset")

    def _send_instant_alerts(
        self,
        detections: List[Dict[str, Any]],
        stream_info: Optional[Dict[str, Any]],
        config: LicensePlateMonitorConfig,
    ) -> None:
        """
        Send detection events to the instant alert system.

        This method processes detections and sends them to the alert manager
        for evaluation against active alert configurations.

        Args:
            detections: List of detection dictionaries with plate_text
            stream_info: Stream information containing camera_id and other metadata
            config: License plate monitoring configuration
        """
        self.logger.info("[ALERT_DEBUG] ========== SEND INSTANT ALERTS ==========")

        if not self.alert_manager:
            self.logger.debug(
                "[ALERT_DEBUG] Alert manager not configured, skipping instant alerts"
            )
            return

        if not detections:
            self.logger.debug("[ALERT_DEBUG] No detections to send to alert manager")
            return

        self.logger.info(
            f"[ALERT_DEBUG] Processing {len(detections)} detection(s) for alerts"
        )

        # Extract metadata directly from stream_info with empty string defaults
        # No complex nested checks - if not found, pass empty string (no errors)
        camera_id = ""
        app_deployment_id = ""
        application_id = ""
        camera_name = ""
        frame_id = ""
        rtp_number = ""
        location_name = ""

        if stream_info:
            self.logger.debug(
                f"[ALERT_DEBUG] stream_info keys: {list(stream_info.keys())}"
            )
            # Direct extraction with safe defaults
            camera_id = stream_info.get("camera_id", "")
            if not camera_id and "camera_info" in stream_info:
                camera_id = stream_info.get("camera_info", {}).get("camera_id", "")

            camera_name = stream_info.get("camera_name", "")
            if not camera_name and "camera_info" in stream_info:
                camera_name = stream_info.get("camera_info", {}).get("camera_name", "")

            app_deployment_id = stream_info.get("app_deployment_id", "")
            application_id = stream_info.get(
                "application_id", stream_info.get("app_id", "")
            )

            # Extract frame_id and rtp_number - at root level of stream_info
            input_settings = (
                stream_info.get("input_settings", {})
                if isinstance(stream_info.get("input_settings", {}), dict)
                else {}
            )
            frame_id = (
                stream_info.get("frame_id", "")
                or stream_info.get("frameId", "")
                or input_settings.get("frame_id", "")
                or input_settings.get("frameId", "")
                or ""
            )
            rtp_number = (
                stream_info.get("rtp_number", "")
                or stream_info.get("rtpNumber", "")
                or input_settings.get("rtp_number", "")
                or input_settings.get("rtpNumber", "")
                or ""
            )

            # Extract location_id and fetch location_name from API
            location_id = ""
            if "camera_info" in stream_info:
                location_id = stream_info.get("camera_info", {}).get("location", "")

            if location_id:
                # Fetch location name from API
                location_name = self._fetch_location_name(location_id, config.session)
            else:
                location_name = "Entry Reception"  # Default if no location_id

            self.logger.debug("[ALERT_DEBUG] Extracted metadata from stream_info:")
            self.logger.debug(f"[ALERT_DEBUG]   - camera_id: '{camera_id}'")
            self.logger.debug(f"[ALERT_DEBUG]   - camera_name: '{camera_name}'")
            self.logger.debug(
                f"[ALERT_DEBUG]   - app_deployment_id: '{app_deployment_id}'"
            )
            self.logger.debug(f"[ALERT_DEBUG]   - application_id: '{application_id}'")
            self.logger.debug(f"[ALERT_DEBUG]   - frame_id: '{frame_id}'")
            self.logger.debug(f"[ALERT_DEBUG]   - rtp_number: '{rtp_number}'")
            self.logger.debug(f"[ALERT_DEBUG]   - location_id: '{location_id}'")
            self.logger.debug(f"[ALERT_DEBUG]   - location_name: '{location_name}'")
        else:
            self.logger.warning("[ALERT_DEBUG] stream_info is None")
            location_name = "Entry Reception"  # Default

        # Process each detection with a valid plate_text
        sent_count = 0
        skipped_count = 0
        for i, detection in enumerate(detections):
            self.logger.debug(f"[ALERT_DEBUG] --- Processing detection #{i + 1} ---")
            self.logger.debug(f"[ALERT_DEBUG] Detection keys: {list(detection.keys())}")

            plate_text = detection.get("plate_text", ".")
            if plate_text:
                plate_text = plate_text.strip()
            else:
                plate_text = ""
            self.logger.debug(f"[ALERT_DEBUG] Plate text: '{plate_text}'")

            if not plate_text or plate_text == "":
                self.logger.debug(
                    f"[ALERT_DEBUG] Skipping detection #{i + 1} - no plate_text"
                )
                skipped_count += 1
                continue

            # Extract detection metadata
            confidence = detection.get("score", detection.get("confidence", 0.0))
            bbox = detection.get("bbox", detection.get("bounding_box", []))

            self.logger.debug(f"[ALERT_DEBUG] Confidence: {confidence}")
            self.logger.debug(f"[ALERT_DEBUG] BBox: {bbox}")

            # Build coordinates dict
            coordinates = {}
            if isinstance(bbox, dict):
                # Handle dict format bbox
                if "xmin" in bbox:
                    coordinates = {
                        "x": int(bbox.get("xmin", 0)),
                        "y": int(bbox.get("ymin", 0)),
                        "width": int(bbox.get("xmax", 0) - bbox.get("xmin", 0)),
                        "height": int(bbox.get("ymax", 0) - bbox.get("ymin", 0)),
                    }
                elif "x" in bbox:
                    coordinates = {
                        "x": int(bbox.get("x", 0)),
                        "y": int(bbox.get("y", 0)),
                        "width": int(bbox.get("width", 0)),
                        "height": int(bbox.get("height", 0)),
                    }
            elif isinstance(bbox, list) and len(bbox) >= 4:
                x1, y1, x2, y2 = bbox[:4]
                coordinates = {
                    "x": int(x1),
                    "y": int(y1),
                    "width": int(x2 - x1),
                    "height": int(y2 - y1),
                }

            self.logger.debug(f"[ALERT_DEBUG] Coordinates: {coordinates}")

            # Build detection event for alert system
            detection_event = {
                "camera_id": camera_id,
                "app_deployment_id": app_deployment_id,
                "application_id": application_id,
                "detectionType": "license_plate",
                "plateNumber": plate_text,
                "confidence": float(confidence),
                "frameUrl": "",  # Will be filled by analytics publisher if needed
                "coordinates": coordinates,
                "cameraName": camera_name,
                "locationName": location_name,
                "frame_id": frame_id,
                "rtp_number": rtp_number,
                "vehicleType": detection.get("vehicle_type", ""),
                "vehicleColor": detection.get("vehicle_color", ""),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            self.logger.info(
                f"[ALERT_DEBUG] Detection event #{i + 1} built: {detection_event}"
            )

            # Send to alert manager for evaluation
            try:
                self.logger.info(
                    f"[ALERT_DEBUG] Sending detection event #{i + 1} to alert manager..."
                )
                self.alert_manager.process_detection_event(detection_event, stream_info)
                self.logger.info(
                    f"[ALERT_DEBUG] ✓ Sent detection event to alert manager: plate={plate_text}, confidence={confidence:.2f}"
                )
                sent_count += 1
            except Exception as e:
                self.logger.error(
                    f"[ALERT_DEBUG] ❌ Error sending detection event to alert manager: {e}",
                    exc_info=True,
                )

        self.logger.info(
            f"[ALERT_DEBUG] Summary: {sent_count} sent, {skipped_count} skipped"
        )
        self.logger.info("[ALERT_DEBUG] ========== INSTANT ALERTS PROCESSED ==========")

    def _initialize_plate_logger(self, config: LicensePlateMonitorConfig) -> bool:
        """Initialize the plate logger if lpr_server_id is provided. Returns True if successful."""
        self.logger.info(
            f"[LP_LOGGING] _initialize_plate_logger called with lpr_server_id: {config.lpr_server_id}"
        )

        if not config.lpr_server_id:
            self._logging_enabled = False
            self._plate_logger_initialized = False
            self.logger.warning(
                "[LP_LOGGING] Plate logging disabled: no lpr_server_id provided"
            )
            return False

        try:
            if self.plate_logger is None:
                self.logger.info(
                    "[LP_LOGGING] Creating new LicensePlateMonitorLogger instance"
                )
                self.plate_logger = LicensePlateMonitorLogger()
            else:
                self.logger.info(
                    "[LP_LOGGING] Using existing LicensePlateMonitorLogger instance"
                )

            self.logger.info("[LP_LOGGING] Initializing session for plate logger")
            self.plate_logger.initialize_session(config)
            self._logging_enabled = True
            self._plate_logger_initialized = True
            self.logger.info(
                f"[LP_LOGGING] SUCCESS - Plate logging ENABLED with server ID: {config.lpr_server_id}"
            )
            return True
        except Exception as e:
            self.logger.error(
                f"[LP_LOGGING] ERROR - Failed to initialize plate logger: {e}",
                exc_info=True,
            )
            self._logging_enabled = False
            self._plate_logger_initialized = False
            self.logger.error(
                "[LP_LOGGING] Plate logging has been DISABLED due to initialization failure"
            )
            return False

    async def _log_detected_plates(
        self,
        detections: List[Dict[str, Any]],
        config: LicensePlateMonitorConfig,
        stream_info: Optional[Dict[str, Any]],
        image_bytes: Optional[bytes] = None,
    ) -> None:
        """
        Log confirmed/dominant plates to RPC server.

        IMPORTANT: This method expects detections from counting_summary["detections"] which
        already contain the CORRECT dominant plate_text (computed from last 50% of tracking history
        in _count_categories). This ensures we log validated/confirmed plates only, not raw OCR output.

        Uniqueness is ensured by:
        1. track_id tracking: Each track_id is logged only once (via _logged_track_ids)
        2. plate_text tracking: Each unique plate text is logged only once (via _logged_plate_texts)
        3. Cooldown: Same plate text won't be re-logged within cooldown period (via plate_logger)
        """
        # Enhanced logging for diagnostics
        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            f"[LP_LOGGING] Starting plate logging check - detections count: {len(detections)} "
            f"| detections_len={len(detections)} detections_type={type(detections).__name__}",
        )
        self.logger.info(
            f"[LP_LOGGING] Logging enabled: {self._logging_enabled}, Plate logger exists: {self.plate_logger is not None}"
        )
        self.logger.info(
            f"[LP_LOGGING] Already logged tracks: {len(self._logged_track_ids)}, Already logged plates: {len(getattr(self, '_logged_plate_texts', set()))}"
        )

        if not self._logging_enabled:
            _log_with_msg_meta(
                self.logger,
                logging.WARNING,
                "[LP_LOGGING] Plate logging is DISABLED - logging_enabled flag is False",
            )
            return

        if not self.plate_logger:
            _log_with_msg_meta(
                self.logger,
                logging.WARNING,
                "[LP_LOGGING] Plate logging SKIPPED - plate_logger is not initialized (lpr_server_id may not be configured)",
            )
            return

        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            "[LP_LOGGING] All pre-conditions met, proceeding with plate logging",
        )

        # Initialize _logged_plate_texts if not exists (tracks unique plate texts already logged)
        if not hasattr(self, "_logged_plate_texts"):
            self._logged_plate_texts: set = set()

        # Get current timestamp
        current_timestamp = self._get_current_timestamp_str(stream_info, precision=True)

        # Encode the full frame image as base64 JPEG
        image_data = ""
        if image_bytes:
            try:
                # Decode image bytes
                image_array = np.frombuffer(image_bytes, np.uint8)
                image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)

                if image is not None:
                    # Encode as JPEG with 85% quality
                    success, jpeg_buffer = cv2.imencode(
                        ".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, 99]
                    )
                    if success:
                        # Convert to base64
                        image_data = base64.b64encode(jpeg_buffer.tobytes()).decode(
                            "utf-8"
                        )
                        self.logger.info(
                            f"[LP_LOGGING] Encoded frame image as base64, length: {len(image_data)}"
                        )
                    else:
                        self.logger.warning("[LP_LOGGING] Failed to encode JPEG image")
                else:
                    self.logger.warning("[LP_LOGGING] Failed to decode image bytes")
            except Exception as e:
                self.logger.error(
                    f"[LP_LOGGING] Exception while encoding frame image: {e}",
                    exc_info=True,
                )
        else:
            self.logger.info(
                "[LP_LOGGING] No image_bytes provided, sending without image"
            )

        # Collect CONFIRMED/DOMINANT plates from detections.
        #
        # CRITICAL: We must NOT log the first random OCR read for a track. We only log a plate when it is
        # confirmed/stable for the track.
        #
        # Confirmation rule (per-track):
        # - track_id must exist (post-tracker)
        # - the last `self._stable_frames_required` cleaned readings for this track must be identical
        # - the candidate dominant plate (from counting_summary["detections"]) must match that stable value
        #
        # This aligns logging with the “confirmed/final” plate behavior expected from tracking stats logic.
        plates_to_log = {}  # plate_text -> track_id (for logging reference)

        for det in detections:
            track_id = det.get("track_id")
            if track_id is None:
                # Only log plates associated with a tracked object (after tracker assigns a track_id)
                continue

            # Get the dominant plate_text directly from detection (already computed in _count_categories)
            dominant_plate = self._clean_text(str(det.get("plate_text") or ""))

            if not dominant_plate:
                continue

            # Per-track stability check: require last N readings to be identical
            history = self.helper.get(track_id, [])
            if len(history) < self._stable_frames_required:
                self.logger.debug(
                    f"[LP_LOGGING] Skipping track_id={track_id} - insufficient history "
                    f"({len(history)}/{self._stable_frames_required})"
                )
                continue

            recent = history[-self._stable_frames_required :]
            if len(set(recent)) != 1:
                self.logger.debug(
                    f"[LP_LOGGING] Skipping track_id={track_id} - plate not stable yet (recent={recent})"
                )
                continue

            stable_plate = recent[0]
            if stable_plate != dominant_plate:
                # Dominant-from-history and stable-last-N disagree => do NOT log (avoid wrong early logs)
                self.logger.debug(
                    f"[LP_LOGGING] Skipping track_id={track_id} - dominant '{dominant_plate}' != stable '{stable_plate}'"
                )
                continue

            # Skip if this track_id has already been logged
            if track_id is not None and track_id in self._logged_track_ids:
                self.logger.debug(
                    f"[LP_LOGGING] Skipping track_id={track_id} - already logged"
                )
                continue

            # Skip if this exact plate_text has already been logged (uniqueness by plate text)
            if stable_plate in self._logged_plate_texts:
                self.logger.debug(
                    f"[LP_LOGGING] Skipping plate '{stable_plate}' - already logged previously"
                )
                continue

            # Validate plate length (should already be validated in _count_categories, but double-check)
            if not (self._min_plate_len <= len(stable_plate) <= 10):
                self.logger.debug(
                    f"[LP_LOGGING] Skipping plate '{stable_plate}' - invalid length ({len(stable_plate)})"
                )
                continue

            # Add to plates to log (use plate_text as key to ensure uniqueness)
            if stable_plate not in plates_to_log:
                plates_to_log[stable_plate] = track_id
                self.logger.debug(
                    f"[LP_LOGGING] Found confirmed dominant plate: '{stable_plate}' (track_id={track_id})"
                )

        confirmed_count = len(plates_to_log)
        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            f"[LP_LOGGING] Confirmed dominant plates to log: {confirmed_count} "
            f"| plates_to_log_len={confirmed_count} plates_to_log_type={type(plates_to_log).__name__}",
        )
        _pkeys = list(plates_to_log.keys())
        _log_with_msg_meta(
            self.logger,
            logging.INFO,
            f"[LP_LOGGING] Plates: {_pkeys} | keys_len={len(_pkeys)} key_types={[type(k).__name__ for k in _pkeys]}",
        )

        # Log each confirmed plate (respecting cooldown)
        if plates_to_log:
            _cd = config.plate_log_cooldown
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                f"[LP_LOGGING] Logging {len(plates_to_log)} confirmed plates with cooldown={_cd}s "
                f"| cooldown_type={type(_cd).__name__} n_plates={len(plates_to_log)}",
            )
            try:
                for plate_text, track_id in plates_to_log.items():
                    _log_with_msg_meta(
                        self.logger,
                        logging.INFO,
                        f"[LP_LOGGING] Processing confirmed plate: '{plate_text}' (track_id={track_id}) "
                        f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__} "
                        f"track_id_type={type(track_id).__name__} track_id_repr_len={len(repr(track_id))}",
                    )
                    try:
                        result = await self.plate_logger.log_plate(
                            plate_text=plate_text,
                            timestamp=current_timestamp,
                            stream_info=stream_info,
                            image_data=image_data,
                            cooldown=config.plate_log_cooldown,
                        )
                        if result:
                            # Mark this track_id AND plate_text as logged to avoid duplicate logging
                            if track_id is not None:
                                self._logged_track_ids.add(track_id)
                            self._logged_plate_texts.add(plate_text)
                            _log_with_msg_meta(
                                self.logger,
                                logging.INFO,
                                f"[LP_LOGGING] Plate '{plate_text}': SENT (track_id={track_id} marked as logged) "
                                f"| plate_len={len(plate_text)} track_id_type={type(track_id).__name__}",
                            )
                        else:
                            _log_with_msg_meta(
                                self.logger,
                                logging.INFO,
                                f"[LP_LOGGING] Plate '{plate_text}': SKIPPED (cooldown) | plate_len={len(plate_text)} plate_type={type(plate_text).__name__}",
                            )
                    except Exception as e:
                        _pex_body = (
                            f"[LP_LOGGING] Plate '{plate_text}' raised exception: {e} "
                            f"| plate_len={len(plate_text)} plate_type={type(plate_text).__name__} err_type={type(e).__name__}"
                        )
                        self.logger.error(
                            "%s | msg_len=%d", _pex_body, len(_pex_body), exc_info=True
                        )

                _plc = (
                    f"[LP_LOGGING] Plate logging complete - {len(self._logged_track_ids)} total tracks, "
                    f"{len(self._logged_plate_texts)} unique plates logged so far "
                    f"| logged_tracks_type={type(self._logged_track_ids).__name__} logged_plates_type={type(self._logged_plate_texts).__name__}"
                )
                _log_with_msg_meta(self.logger, logging.INFO, _plc)
            except Exception as e:
                _crit_body = f"[LP_LOGGING] CRITICAL ERROR during plate logging: {e} | err_type={type(e).__name__}"
                self.logger.error(
                    "%s | msg_len=%d", _crit_body, len(_crit_body), exc_info=True
                )
        else:
            _log_with_msg_meta(
                self.logger,
                logging.INFO,
                "[LP_LOGGING] No confirmed plates to log (waiting for consensus or already logged) | same_as=consensus_or_logged",
            )

    async def process(
        self,
        data: Any,
        config: ConfigProtocol,
        input_bytes: Optional[bytes] = None,
        context: Optional[ProcessingContext] = None,
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> ProcessingResult:
        processing_start = time.time()
        self.logger.info(f"[LPR_FRAME] before processing: n_dets={len(data)}")
        try:
            if not isinstance(config, LicensePlateMonitorConfig):
                return self.create_error_result(
                    "Invalid configuration type for license plate monitoring",
                    usecase=self.name,
                    category=self.category,
                    context=context,
                )

            if context is None:
                context = ProcessingContext()

            if not input_bytes:
                return self.create_error_result(
                    "input_bytes (video/image) is required for license plate monitoring",
                    usecase=self.name,
                    category=self.category,
                    context=context,
                )

            # Initialize plate logger once if lpr_server_id is provided (optional flow)
            if not self._plate_logger_initialized and config.lpr_server_id:
                self.logger.info(
                    f"[LP_LOGGING] First-time initialization - lpr_server_id: {config.lpr_server_id}"
                )
                success = self._initialize_plate_logger(config)
                if success:
                    self.logger.info(
                        "[LP_LOGGING] Plate logger initialized successfully and ready to send plates"
                    )
                else:
                    self.logger.error(
                        "[LP_LOGGING] Plate logger initialization FAILED - plates will NOT be sent"
                    )
            elif self._plate_logger_initialized:
                self.logger.debug(
                    "[LP_LOGGING] Plate logger already initialized, skipping re-initialization"
                )
            elif not config.lpr_server_id:
                if self._total_frame_counter == 0:  # Only log once at start
                    self.logger.warning(
                        "[LP_LOGGING] Plate logging will be DISABLED - no lpr_server_id provided in config"
                    )

            # Initialize alert manager once (lazy initialization on first call)
            if not self._alert_manager_initialized:
                self._initialize_alert_manager_once(config)
                self.logger.info("[ALERT] CONFIG OF ALERT SHOULD BE PRINTED")

            # Normalize alert_config if provided as a plain dict (JS JSON)
            if isinstance(getattr(config, "alert_config", None), dict):
                try:
                    config.alert_config = AlertConfig(**config.alert_config)  # type: ignore[arg-type]
                except Exception:
                    # Non-fatal: exception ignored here; execution continues per surrounding logic.
                    pass

            # OCR model will be lazily initialized when _run_ocr is first called
            # No need to initialize here

            _t = time.monotonic
            _t0 = _t()

            input_format = match_results_structure(data)
            context.input_format = input_format
            config.confidence_threshold = 0.37
            context.confidence_threshold = config.confidence_threshold
            self._ocr_mode = config.ocr_mode
            if hasattr(config, "ocr_model_name") and config.ocr_model_name:
                self._ocr_model_name = config.ocr_model_name
            if hasattr(config, "ocr_device") and config.ocr_device:
                self._ocr_device = config.ocr_device
            self.logger.info(
                f"Processing license plate monitoring with format: {input_format.value} and CONFIDENCE THRESHOLD: {config.confidence_threshold}"
            )

            # Step 1: Apply confidence filtering 1
            processed_data = filter_by_confidence(data, config.confidence_threshold)
            ## DEBUGGING TEMP
            _log_with_msg_meta(
                self.logger,
                logging.DEBUG,
                f"[DEBUG-1] After confidence filter: {len(processed_data)} detections "
                f"| processed_data_len={len(processed_data)} processed_data_type={type(processed_data).__name__}",
            )
            _s1 = processed_data[:2]
            _log_with_msg_meta(
                self.logger,
                logging.DEBUG,
                f"[DEBUG-1] Sample: {_s1!r} | sample_slice_len={len(_s1)} elem_types={[type(x).__name__ for x in _s1]}",
            )
            self.logger.debug(
                f"Applied confidence filtering with threshold {config.confidence_threshold}"
            )

            # Step 2: Apply category mapping if provided
            if config.index_to_category:
                processed_data = apply_category_mapping(
                    processed_data, config.index_to_category
                )
                ## DEBUGGING TEMP
                _log_with_msg_meta(
                    self.logger, logging.DEBUG, "[DEBUG-2] After category mapping:"
                )
                for d in processed_data[:5]:
                    _c = d.get("category")
                    _log_with_msg_meta(
                        self.logger,
                        logging.DEBUG,
                        f"[DEBUG-2]   category: {_c!r} | category_type={type(_c).__name__} cat_repr_len={len(repr(_c))}",
                    )
            # Step 3: Filter to target categories (handle dict or list)
            if isinstance(processed_data, dict):
                processed_data = processed_data.get("detections", [])
            effective_targets = (
                getattr(config, "target_categories", self.target_categories)
                or self.target_categories
            )
            targets_lower = {str(cat).lower() for cat in effective_targets}
            processed_data = [
                d
                for d in processed_data
                if str(d.get("category", "")).lower() in targets_lower
            ]
            ## DEBUGGING TEMP
            _log_with_msg_meta(
                self.logger,
                logging.DEBUG,
                f"[DEBUG-3] Target categories: {targets_lower} | targets_len={len(targets_lower)} targets_type={type(targets_lower).__name__}",
            )
            _log_with_msg_meta(
                self.logger,
                logging.DEBUG,
                f"[DEBUG-3] After category filter: {len(processed_data)} detections "
                f"| processed_data_len={len(processed_data)} processed_data_type={type(processed_data).__name__}",
            )
            for d in processed_data[:5]:
                _kc = d.get("category")
                _log_with_msg_meta(
                    self.logger,
                    logging.DEBUG,
                    f"[DEBUG-3]   kept: {_kc!r} | category_type={type(_kc).__name__}",
                )

            raw_processed_data = [copy.deepcopy(det) for det in processed_data]

            _t1 = _t()  # after filtering

            # Step 4: Apply bounding box smoothing if enabled
            if config.enable_smoothing:
                if self.smoothing_tracker is None:
                    smoothing_config = BBoxSmoothingConfig(
                        smoothing_algorithm=config.smoothing_algorithm,
                        window_size=config.smoothing_window_size,
                        cooldown_frames=config.smoothing_cooldown_frames,
                        confidence_threshold=config.confidence_threshold,
                        confidence_range_factor=config.smoothing_confidence_range_factor,
                        enable_smoothing=True,
                    )
                    self.smoothing_tracker = BBoxSmoothingTracker(smoothing_config)
                processed_data = bbox_smoothing(
                    processed_data,
                    self.smoothing_tracker.config,
                    self.smoothing_tracker,
                )
                ## DEBUGGING TEMP
                _log_with_msg_meta(
                    self.logger,
                    logging.DEBUG,
                    f"[DEBUG-4] After tracking + smoothing: {len(processed_data)} detections "
                    f"| processed_data_len={len(processed_data)} type={type(processed_data).__name__}",
                )

            _t2 = _t()  # after smoothing

            # Step 5: Apply advanced tracking
            if _HAS_ADVANCED_TRACKER:
                try:
                    if self.tracker is None:
                        tracker_config = _TrackerConfig(
                            track_high_thresh=float(config.confidence_threshold),
                            track_low_thresh=max(
                                0.05, float(config.confidence_threshold) / 2
                            ),
                            new_track_thresh=float(config.confidence_threshold),
                        )
                        self.tracker = _AdvancedTracker(tracker_config)
                        self.logger.info(
                            f"Initialized AdvancedTracker with thresholds: high={tracker_config.track_high_thresh}, "
                            f"low={tracker_config.track_low_thresh}, new={tracker_config.new_track_thresh}"
                        )
                    processed_data = self.tracker.update(processed_data)
                except Exception as e:
                    self.logger.warning(f"AdvancedTracker failed: {e}")

            # Map persistent track IDs back to original data dicts (in-place) so that
            # callers holding a reference (e.g. workers.py → format_output_rtp) see them.
            _map_tracker_ids_to_source(
                data if isinstance(data, list) else data.get("detections", []),
                processed_data,
            )

            # Temporal smoothing — carry forward tracked detections that the model
            # intermittently drops, reducing bbox flickering on the frontend.
            _camera_id = (stream_info or {}).get("camera_id", "")
            processed_data = self._detection_smoother.smooth(
                _camera_id, processed_data, self._total_frame_counter
            )

            _t3 = _t()  # after tracker + smoothing

            # Step 6: Update tracking state
            self._update_tracking_state(processed_data)
            # Step 7: Attach masks to detections (skip if no masks — O(n²) IOU matching)
            if raw_processed_data and any(
                d.get("mask") or d.get("segmentation") for d in raw_processed_data[:5]
            ):
                processed_data = self._attach_masks_to_detections(
                    processed_data, raw_processed_data
                )

            _t4 = _t()  # after tracking state + masks

            # Step 8: Perform OCR on media
            _ib_type = type(input_bytes).__name__
            _ib_info = f"{_ib_type}"
            if isinstance(input_bytes, np.ndarray):
                _ib_info = f"ndarray{input_bytes.shape}"
            elif isinstance(input_bytes, (bytes, bytearray)):
                _ib_info = f"bytes({len(input_bytes)})"
            ocr_analysis = self._analyze_ocr_in_media(
                processed_data, input_bytes, config
            )
            ## DEBUGGING TEMP
            _log_with_msg_meta(
                self.logger,
                logging.DEBUG,
                f"[DEBUG-5] OCR results: n_rows={len(ocr_analysis)} ocr_analysis_type={type(ocr_analysis).__name__}",
            )
            for r in ocr_analysis:
                _pt = r.get("plate_text")
                _cf = r.get("ocr_confidence")
                _rj = r.get("reject_reason")
                _log_with_msg_meta(
                    self.logger,
                    logging.DEBUG,
                    f"[DEBUG-5]   text: {_pt!r} | conf: {_cf!r} | reject: {_rj!r} "
                    f"| text_type={type(_pt).__name__} text_len={len(str(_pt))} "
                    f"conf_type={type(_cf).__name__} reject_type={type(_rj).__name__}",
                )

            _n_ocr_ok = sum(1 for r in ocr_analysis if r.get("plate_text"))
            _n_rejected = sum(1 for r in ocr_analysis if r.get("reject_reason"))
            _per_det_ocr = " ".join(f"{r.get('ocr_ms', 0):.0f}" for r in ocr_analysis)

            _t5 = _t()  # after OCR

            # Step 9: Update plate texts
            processed_data = self._update_detections_with_ocr(
                processed_data, ocr_analysis
            )
            ## DEBUGGING TEMP
            _log_with_msg_meta(
                self.logger, logging.DEBUG, "[DEBUG-6] Detections after OCR attach:"
            )
            for d in processed_data[:5]:
                _pt6 = d.get("plate_text")
                _tid = d.get("track_id")
                _log_with_msg_meta(
                    self.logger,
                    logging.DEBUG,
                    f"[DEBUG-6]   plate_text: {_pt6!r} track_id: {_tid!r} "
                    f"| plate_text_type={type(_pt6).__name__} plate_text_len={len(str(_pt6))} "
                    f"track_id_type={type(_tid).__name__}",
                )
            self._update_plate_texts(processed_data)

            _t6 = _t()  # after plate text update

            # Step 9.6: Send detections to instant alert system (if configured)
            self._send_instant_alerts(processed_data, stream_info, config)

            _t7 = _t()  # after alerts

            # Step 10: Update frame counter
            self._total_frame_counter += 1

            # Step 11: Extract frame information
            frame_number = None
            if stream_info:
                input_settings = stream_info.get("input_settings", {})
                start_frame = input_settings.get("start_frame")
                end_frame = input_settings.get("end_frame")
                if (
                    start_frame is not None
                    and end_frame is not None
                    and start_frame == end_frame
                ):
                    frame_number = start_frame

            # Step 12: Calculate summaries (computes dominant plates from history)
            counting_summary = self._count_categories(processed_data, config)
            counting_summary["total_counts"] = self.get_total_counts()
            ## DEBUGGING TEMP
            _cdets = counting_summary.get("detections", [])
            _log_with_msg_meta(
                self.logger,
                logging.DEBUG,
                f"[DEBUG-7] Counting summary detections: {len(_cdets)} "
                f"| detections_len={len(_cdets)} detections_type={type(_cdets).__name__}",
            )
            for d in _cdets[:5]:
                _fc = d.get("category")
                _ft = d.get("track_id")
                _log_with_msg_meta(
                    self.logger,
                    logging.DEBUG,
                    f"[DEBUG-7]   FINAL plate: {_fc!r} | track: {_ft!r} "
                    f"| category_type={type(_fc).__name__} track_id_type={type(_ft).__name__}",
                )

            _t8 = _t()  # after counting

            # Step 12.5: Log CONFIRMED/DOMINANT plates to RPC server
            confirmed_detections = counting_summary.get("detections", [])
            ## DEBUGGING TEMP
            _log_with_msg_meta(
                self.logger,
                logging.DEBUG,
                f"[DEBUG-8] Confirmed detections for logging: {len(confirmed_detections)} "
                f"| len={len(confirmed_detections)} type={type(confirmed_detections).__name__}",
            )
            # Fire-and-forget: don't block frame on HTTP POST to plate logger

            ## DEBUGGING TEMP
            if confirmed_detections:
                _log_with_msg_meta(
                    self.logger,
                    logging.DEBUG,
                    f"[DEBUG-9] Triggering async logging for {len(confirmed_detections)} detections "
                    f"| n={len(confirmed_detections)} list_type={type(confirmed_detections).__name__}",
                )
                _plate_log_task = asyncio.ensure_future(
                    self._log_detected_plates(
                        confirmed_detections, config, stream_info, input_bytes
                    )
                )
                self._background_tasks = getattr(self, "_background_tasks", set())
                self._background_tasks.add(_plate_log_task)
                _plate_log_task.add_done_callback(self._background_tasks.discard)
            else:
                _log_with_msg_meta(
                    self.logger,
                    logging.DEBUG,
                    "[DEBUG-9] Logging skipped - no confirmed detections",
                )

            # Step 13: Generate alerts and summaries
            alerts = self._check_alerts(counting_summary, frame_number, config)
            incidents_list = self._generate_incidents(
                counting_summary, alerts, config, frame_number, stream_info
            )
            tracking_stats_list = self._generate_tracking_stats(
                counting_summary, alerts, config, frame_number, stream_info
            )
            business_analytics_list = []
            summary_list = self._generate_summary(
                counting_summary,
                incidents_list,
                tracking_stats_list,
                business_analytics_list,
                alerts,
            )

            _t9 = _t()  # after summaries

            # Step 14: Build result
            incidents = incidents_list[0] if incidents_list else {}
            tracking_stats = tracking_stats_list[0] if tracking_stats_list else {}
            business_analytics = (
                business_analytics_list[0] if business_analytics_list else {}
            )
            summary = summary_list[0] if summary_list else {}
            # Build LPR_dict (per-track history) and counter (dominant in last 50%)
            LPR_dict = {}
            counter = {}
            for tid, history in self.helper.items():
                if not history:
                    continue
                LPR_dict[str(tid)] = list(history)
                # dominant from last 50%
                half = max(1, len(history) // 2)
                window = history[-half:]
                dom, cnt = Counter(window).most_common(1)[0]
                counter[str(tid)] = {"plate": dom, "count": cnt}

            agg_summary = {
                str(frame_number): {
                    "incidents": incidents,
                    "tracking_stats": tracking_stats,
                    "business_analytics": business_analytics,
                    "alerts": alerts,
                    "human_text": summary,
                }
            }

            context.mark_completed()
            result = self.create_result(
                data={"agg_summary": agg_summary},
                usecase=self.name,
                category=self.category,
                context=context,
            )
            _t10 = _t()  # after result build
            proc_time = time.time() - processing_start
            processing_latency_ms = proc_time * 1000.0
            processing_fps = (1.0 / proc_time) if proc_time > 0 else 0.0
            ocr_time_ms = sum(r.get("ocr_ms", 0) for r in ocr_analysis)
            self.logger.info(
                f"[LPR_FRAME] F{frame_number} | {len(processed_data)} dets | "
                f"{_n_ocr_ok} OCR ok | {_n_rejected} rejected | "
                f"latency={processing_latency_ms:.1f}ms fps={processing_fps:.1f} | "
                f"ocr_time={ocr_time_ms:.1f}ms"
            )
            # Per-step timing breakdown (ms)
            self.logger.info(
                f"[LPR_TIMING] F{frame_number} | "
                f"filter={(_t1 - _t0) * 1e3:.1f} smooth={(_t2 - _t1) * 1e3:.1f} "
                f"track={(_t3 - _t2) * 1e3:.1f} state={(_t4 - _t3) * 1e3:.1f} "
                f"ocr={(_t5 - _t4) * 1e3:.1f}(model_sum={ocr_time_ms:.1f} per=[{_per_det_ocr}]) "
                f"plates={(_t6 - _t5) * 1e3:.1f} "
                f"alerts={(_t7 - _t6) * 1e3:.1f} count={(_t8 - _t7) * 1e3:.1f} "
                f"summary={(_t9 - _t8) * 1e3:.1f} build={(_t10 - _t9) * 1e3:.1f} "
                f"input={_ib_info} ocr_model={self.ocr_model is not None}"
            )
            plates_str = " ".join(
                f"{r['plate_text']}({r.get('ocr_confidence', 0):.2f})"
                for r in ocr_analysis
                if r.get("plate_text")
            )
            if plates_str:
                self.logger.info(f"[LPR_PLATES] F{frame_number} | {plates_str}")
            rejected_str = " ".join(
                f"{r.get('raw_text', '')}({r.get('ocr_confidence', 0):.2f},{r.get('reject_reason', '')})"
                for r in ocr_analysis
                if r.get("reject_reason")
            )
            if rejected_str:
                self.logger.debug(f"[LPR_REJECTED] F{frame_number} | {rejected_str}")
            return result

        except Exception as e:
            self.logger.error(
                f"License plate monitoring failed: {str(e)}", exc_info=True
            )
            if context:
                context.mark_completed()
            return self.create_error_result(
                str(e),
                type(e).__name__,
                usecase=self.name,
                category=self.category,
                context=context,
            )

    def _is_video_bytes(self, media_bytes: bytes) -> bool:
        """Determine if bytes represent a video file."""
        video_signatures = [
            b"\x00\x00\x00\x20ftypmp4",  # MP4
            b"\x00\x00\x00\x18ftypmp4",  # MP4 variant
            b"RIFF",  # AVI
            b"\x1aE\xdf\xa3",  # MKV/WebM
            b"ftyp",  # General MP4 family
        ]
        for signature in video_signatures:
            if media_bytes.startswith(signature) or signature in media_bytes[:50]:
                return True
        return False

    def _analyze_ocr_in_media(
        self, data: Any, media_bytes: bytes, config: LicensePlateMonitorConfig
    ) -> List[Dict[str, Any]]:
        """Analyze OCR of license plates in video frames or images."""
        result = self._analyze_ocr_in_image(data, media_bytes, config)
        # Store timing metadata for process() to log
        self._last_img_src = getattr(self, "_last_img_src", "unknown")
        self._last_decode_ms = getattr(self, "_last_decode_ms", 0.0)
        self._last_cvt_ms = getattr(self, "_last_cvt_ms", 0.0)
        return result

    def _analyze_ocr_in_image(
        self, data: Any, image_bytes, config: LicensePlateMonitorConfig
    ) -> List[Dict[str, Any]]:
        """Analyze OCR in a single image. Accepts JPEG bytes, raw BGR numpy, or __RAW_BGR__ sentinel."""
        _mt = time.monotonic
        _img_t0 = _mt()
        if isinstance(image_bytes, np.ndarray):
            image = image_bytes
            _img_src = "numpy"
        elif image_bytes == b"__RAW_BGR__" and self._bgr_frame is not None:
            image = self._bgr_frame
            _img_src = "bgr_holder"
        else:
            image_array = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
            _img_src = f"jpeg({len(image_bytes)}B)"
        _img_t1 = _mt()

        if image is None:
            self.logger.warning(
                f"Failed to decode image from bytes (src={_img_src}, "
                f"type={type(image_bytes).__name__}, "
                f"len={len(image_bytes) if hasattr(image_bytes, '__len__') else '?'})"
            )
            return []

        rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        _img_t2 = _mt()
        ocr_analysis = []
        detections = self._get_frame_detections(data, "0")

        for detection in detections:
            if detection.get("confidence", 1.0) < config.confidence_threshold:
                continue

            bbox = detection.get("bounding_box", detection.get("bbox"))
            if not bbox:
                self.logger.debug("Detection has no bounding_box or bbox key")
                continue

            crop = self._crop_bbox(rgb_image, bbox, config.bbox_format)
            if crop.size == 0:
                continue

            track_id = detection.get("track_id")
            # Skip OCR if track already has stable plate text (saves ~80-180ms per detection)
            _ocr_skipped = False
            if (
                track_id is not None
                and hasattr(self, "helper")
                and track_id in self.helper
            ):
                hist = self.helper[track_id]
                if len(hist) >= 3:
                    half = max(1, len(hist) // 2)
                    dom, cnt = Counter(hist[-half:]).most_common(1)[0]
                    if dom and cnt >= 2:
                        # Stable text exists — reuse it, skip expensive OCR
                        ocr_result = {
                            "text": dom,
                            "avg_conf": 0.95,
                            "raw_text": dom,
                            "char_confs": [],
                            "rejected": False,
                            "reject_reason": None,
                        }
                        ocr_ms = 0.0
                        _ocr_skipped = True
            if not _ocr_skipped:
                t0 = _mt()
                ocr_result = self._run_ocr(crop)
                ocr_ms = (_mt() - t0) * 1000.0

            plate_text = ocr_result["text"] or None
            crop_h, crop_w = crop.shape[:2]
            self.logger.info(
                f"[LPR_OCR] track={track_id} crop={crop_w}x{crop_h} "
                f"text={ocr_result['text']!r} conf={ocr_result['avg_conf']:.2f} "
                f"reason={ocr_result.get('reject_reason')} ocr_ms={ocr_ms:.1f}"
                f"{' CACHED' if _ocr_skipped else ''}"
            )

            ocr_record = {
                "frame_id": "0",
                "timestamp": 0.0,
                "category": detection.get("category", ""),
                "confidence": round(detection.get("confidence", 0.0), 3),
                "plate_text": plate_text,
                "bbox": bbox,
                "detection_id": detection.get("id", f"det_{len(ocr_analysis)}"),
                "track_id": track_id,
                "ocr_confidence": round(ocr_result["avg_conf"], 3),
                "reject_reason": ocr_result["reject_reason"],
                "raw_text": ocr_result["raw_text"],
                "ocr_ms": round(ocr_ms, 1),
            }
            ocr_analysis.append(ocr_record)

        # Store timing on self so process() can log it (in case logger doesn't work here)
        self._last_img_src = _img_src
        self._last_decode_ms = (_img_t1 - _img_t0) * 1e3
        self._last_cvt_ms = (_img_t2 - _img_t1) * 1e3
        self.logger.info(
            f"[LPR_IMG] src={_img_src} shape={image.shape} "
            f"decode={self._last_decode_ms:.1f}ms cvt={self._last_cvt_ms:.1f}ms "
            f"n_dets={len(detections)} total_ocr_ms={sum(r.get('ocr_ms', 0) for r in ocr_analysis):.1f}"
        )
        return ocr_analysis

    def _crop_bbox(
        self, image: np.ndarray, bbox: Dict[str, Any], bbox_format: str
    ) -> np.ndarray:
        """Crop bounding box region from image."""
        h, w = image.shape[:2]

        if bbox_format == "auto":
            if "xmin" in bbox:
                bbox_format = "xmin_ymin_xmax_ymax"
            elif "x" in bbox:
                bbox_format = "x_y_width_height"
            else:
                return np.zeros((0, 0, 3), dtype=np.uint8)

        if bbox_format == "xmin_ymin_xmax_ymax":
            xmin = max(0, int(bbox["xmin"]))
            ymin = max(0, int(bbox["ymin"]))
            xmax = min(w, int(bbox["xmax"]))
            ymax = min(h, int(bbox["ymax"]))
        elif bbox_format == "x_y_width_height":
            xmin = max(0, int(bbox["x"]))
            ymin = max(0, int(bbox["y"]))
            xmax = min(w, int(bbox["x"] + bbox["width"]))
            ymax = min(h, int(bbox["y"] + bbox["height"]))
        else:
            return np.zeros((0, 0, 3), dtype=np.uint8)

        return image[ymin:ymax, xmin:xmax]

    # ------------------------------------------------------------------
    # Fast OCR helpers
    # ------------------------------------------------------------------
    def set_bgr_frame(self, bgr_frame):
        """Set raw BGR frame for OCR analysis (avoids JPEG encode/decode loss)."""
        self._bgr_frame = bgr_frame

    def _ensure_ocr_model_loaded(self) -> bool:
        """Lazy initialization of OCR model with retry. Returns True if model is available."""
        if self.ocr_model is not None:
            return True

        if self._ocr_initialization_attempts >= self._ocr_max_init_attempts:
            return False

        self._ocr_initialization_attempts += 1
        attempt = self._ocr_initialization_attempts

        # Ensure onnxruntime-gpu is installed for CUDA acceleration (one-time check)
        try:
            from matrice_common.utils import dependencies_check

            dependencies_check("onnxruntime-gpu")
        except Exception as _dep_err:
            self.logger.warning(f"onnxruntime-gpu dependency check failed: {_dep_err}")

        # Try to get the LicensePlateRecognizer class via the module-level helper
        LicensePlateRecognizerClass = _get_license_plate_recognizer_class()

        # Direct import fallback if the helper returns None
        if LicensePlateRecognizerClass is None:
            self.logger.warning(
                f"OCR init attempt {attempt}/{self._ocr_max_init_attempts}: "
                "module-level import returned None, trying direct import..."
            )
            try:
                from fast_plate_ocr import LicensePlateRecognizer as _DirectLPR

                LicensePlateRecognizerClass = _DirectLPR
                self.logger.info("Direct import of LicensePlateRecognizer succeeded")
            except ImportError as e:
                self.logger.error(f"Direct import also failed: {e}")

        if LicensePlateRecognizerClass is None:
            self.logger.error(
                f"OCR init attempt {attempt}/{self._ocr_max_init_attempts}: "
                "LicensePlateRecognizer class unavailable"
            )
            return False

        # Try to initialize the OCR model with configurable model name and device
        model_name = getattr(self, "_ocr_model_name", "cct-s-v1-global-model")
        device = getattr(self, "_ocr_device", "auto")
        try:
            self.ocr_model = LicensePlateRecognizerClass(model_name, device=device)
            self.logger.info(
                f"LicensePlateRecognizer loaded successfully on attempt {attempt} "
                f"(model={model_name}, device={device})"
            )
            return True
        except Exception as e:
            self.logger.error(
                f"OCR init attempt {attempt}/{self._ocr_max_init_attempts} failed: {e}",
                exc_info=True,
            )
            self.ocr_model = None
            return False

    def _clean_text(self, text: str) -> str:
        """Sanitise OCR output to keep only alphanumerics and uppercase."""
        if not text:
            return ""
        return self._non_alnum_regex.sub("", text).upper()

    def _run_ocr(self, crop: np.ndarray) -> dict:
        """Run OCR on a cropped plate image. Returns dict with text, confidence, and diagnostics."""

        def _empty(reason):
            return {
                "text": "",
                "avg_conf": 0.0,
                "raw_text": "",
                "char_confs": [],
                "rejected": True,
                "reject_reason": reason,
            }

        if crop is None or crop.size == 0:
            return _empty("empty_crop")

        if (
            not self._ensure_ocr_model_loaded()
            or self.ocr_model is None
            or not hasattr(self.ocr_model, "run")
        ):
            return _empty("ocr_model_unavailable")

        try:
            result = self.ocr_model.run(crop, return_confidence=True)

            if isinstance(result, tuple) and len(result) == 2:
                texts, confs = result
                raw_text = texts[0] if texts else ""
                char_confs_raw = confs[0] if len(confs) > 0 else []
                valid_confs = [
                    float(c)
                    for j, c in enumerate(char_confs_raw)
                    if j < len(raw_text) and raw_text[j] != "_"
                ]
                avg_conf = sum(valid_confs) / len(valid_confs) if valid_confs else 0.0
                char_confs_list = [round(float(c), 3) for c in char_confs_raw]

                if avg_conf < self._ocr_confidence_threshold:
                    return {
                        "text": "",
                        "avg_conf": avg_conf,
                        "raw_text": raw_text,
                        "char_confs": char_confs_list,
                        "rejected": True,
                        "reject_reason": "low_confidence",
                    }

                display_text = raw_text.replace("_", "")
                cleaned_text = self._clean_text(display_text)
            else:
                res = result
                if isinstance(res, list):
                    res = res[0] if res else ""
                cleaned_text = self._clean_text(str(res))
                raw_text = str(res)
                avg_conf = 0.0
                char_confs_list = []

            if not cleaned_text or len(cleaned_text) < self._min_plate_len:
                return {
                    "text": "",
                    "avg_conf": avg_conf,
                    "raw_text": raw_text,
                    "char_confs": char_confs_list,
                    "rejected": True,
                    "reject_reason": "too_short",
                }

            if self._ocr_mode == "numeric" and not all(
                ch.isdigit() for ch in cleaned_text
            ):
                return {
                    "text": "",
                    "avg_conf": avg_conf,
                    "raw_text": raw_text,
                    "char_confs": char_confs_list,
                    "rejected": True,
                    "reject_reason": "mode_mismatch",
                }
            elif self._ocr_mode == "alphabetic" and not all(
                ch.isalpha() for ch in cleaned_text
            ):
                return {
                    "text": "",
                    "avg_conf": avg_conf,
                    "raw_text": raw_text,
                    "char_confs": char_confs_list,
                    "rejected": True,
                    "reject_reason": "mode_mismatch",
                }

            return {
                "text": cleaned_text,
                "avg_conf": avg_conf,
                "raw_text": raw_text,
                "char_confs": char_confs_list,
                "rejected": False,
                "reject_reason": None,
            }
        except Exception as exc:
            self.logger.warning(f"OCR exception: {exc}")
            return _empty("ocr_exception")

    def _get_frame_detections(self, data: Any, frame_key: str) -> List[Dict[str, Any]]:
        """Extract detections for a specific frame from data."""
        if isinstance(data, dict):
            return data.get(frame_key, [])
        elif isinstance(data, list):
            return data
        else:
            return []

    def _update_detections_with_ocr(
        self, detections: List[Dict[str, Any]], ocr_analysis: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Update detections with OCR results using track_id or bounding box for matching."""
        # print("---------UPDATE DETECTIONS WITH OCR",ocr_analysis)
        ocr_dict = {}
        for rec in ocr_analysis:
            if rec.get("plate_text"):
                # Primary key: track_id
                track_id = rec.get("track_id")
                if track_id is not None:
                    ocr_dict[track_id] = rec["plate_text"]
                # Fallback key: bounding box as tuple
                else:
                    bbox_key = (
                        tuple(sorted(rec["bbox"].items())) if rec.get("bbox") else None
                    )
                    if bbox_key:
                        ocr_dict[bbox_key] = rec["plate_text"]
                # self.logger.info(f"OCR record: track_id={track_id}, plate_text={rec.get('plate_text')}, bbox={rec.get('bbox')}")

        # print("---------UPDATE DETECTIONS WITH OCR -II",ocr_dict)
        for det in detections:
            track_id = det.get("track_id")
            bbox_key = (
                tuple(sorted(det.get("bounding_box", det.get("bbox", {})).items()))
                if det.get("bounding_box") or det.get("bbox")
                else None
            )
            plate_text = None
            if track_id is not None and track_id in ocr_dict:
                plate_text = ocr_dict[track_id]
            elif bbox_key and bbox_key in ocr_dict:
                plate_text = ocr_dict[bbox_key]
            det["plate_text"] = plate_text
            # self.logger.info(f"Detection track_id={track_id}, bbox={det.get('bounding_box')}: Assigned plate_text={plate_text}")
        return detections

    def _count_categories(
        self, detections: List[Dict], _config: LicensePlateMonitorConfig
    ) -> Dict[str, Any]:
        """Count unique licence-plate texts per frame and attach detections."""
        _ = (_config,)
        unique_texts: set = set()
        valid_detections: List[Dict[str, Any]] = []

        # Group detections by track_id for per-track dominance
        tracks: Dict[Any, List[Dict[str, Any]]] = {}
        for det in detections:
            if not all(k in det for k in ["category", "confidence", "bounding_box"]):
                continue
            tid = det.get("track_id")
            if tid is None:
                # If no track id, treat as its own pseudo-track keyed by bbox
                tid = det.get("bounding_box") or det.get("bbox")
            tracks.setdefault(tid, []).append(det)

        for tid, dets in tracks.items():
            # Pick a representative bbox (first occurrence)
            rep = dets[0]
            cat = rep.get("category", "")
            bbox = rep.get("bounding_box")
            conf = rep.get("confidence")
            frame_id = rep.get("frame_id")

            # Compute dominant text for this track from last 50% of history
            dominant_text = None
            history = self.helper.get(tid, [])
            if history:
                half = max(1, len(history) // 2)
                window = history[-half:]
                dominant_text, _ = Counter(window).most_common(1)[0]
            elif rep.get("plate_text"):
                candidate = self._clean_text(rep.get("plate_text", ""))
                if self._min_plate_len <= len(candidate) <= 10:
                    dominant_text = candidate

            # Fallback to already computed per-track mapping
            if not dominant_text:
                dominant_text = self.unique_plate_track.get(tid)

            # Enforce length range and uniqueness per frame
            if dominant_text and self._min_plate_len <= len(dominant_text) <= 10:
                unique_texts.add(dominant_text)
                valid_detections.append(
                    {
                        "bounding_box": bbox,
                        "category": cat,
                        "confidence": conf,
                        "track_id": rep.get("track_id"),
                        "frame_id": frame_id,
                        "masks": rep.get("masks", []),
                        "plate_text": dominant_text,
                    }
                )

        counts = {"License_Plate": len(unique_texts)} if unique_texts else {}

        return {
            "total_count": len(unique_texts),
            "per_category_count": counts,
            "detections": valid_detections,
        }

    def _generate_tracking_stats(
        self,
        counting_summary: Dict,
        alerts: Any,
        config: LicensePlateMonitorConfig,
        _frame_number: Optional[int] = None,
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> List[Dict]:
        """Generate structured tracking stats with frame-based keys."""
        _ = (_frame_number,)
        tracking_stats = []
        total_detections = counting_summary.get("total_count", 0)
        per_category_count = counting_summary.get("per_category_count", {})
        current_timestamp = self._get_current_timestamp_str(
            stream_info, precision=False
        )
        start_timestamp = self._get_start_timestamp_str(stream_info, precision=False)
        self._debug_stream_timing("start_timestamp", start_timestamp)
        high_precision_start_timestamp = self._get_current_timestamp_str(
            stream_info, precision=True
        )
        high_precision_reset_timestamp = self._get_start_timestamp_str(
            stream_info, precision=True
        )
        camera_info = self.get_camera_info_from_stream(stream_info)

        total_counts_dict = (
            counting_summary.get("total_counts") or self.get_total_counts()
        )
        if not isinstance(total_counts_dict, dict):
            total_counts_dict = self.get_total_counts()
        total_counts_list = [
            {"category": str(cat), "count": int(count)}
            for cat, count in total_counts_dict.items()
            if int(count) > 0
        ]
        current_counts: List[Dict[str, Any]] = []
        for cat, count in per_category_count.items():
            if count > 0 or total_detections > 0:
                current_counts.append({"category": str(cat), "count": int(count)})
        new_counts_dict = self.get_new_counts_this_frame()
        current_new_counts = [
            {"category": str(cat), "count": int(count)}
            for cat, count in new_counts_dict.items()
        ]

        human_text_lines = []
        # print("counting_summary", counting_summary)
        human_text_lines.append(f"CURRENT FRAME @ {current_timestamp}:")
        sum_of_current_frame_detections = sum(per_category_count.values())

        if total_detections > 0:
            # for cat, count in per_category_count.items():
            human_text_lines.append(
                f"\t- License Plates Detected: {sum_of_current_frame_detections}"
            )
            # human_text_lines.append(f"\t- {detection_text}")
            # Show dominant per-track license plates for current frame
            seen = set()
            display_texts = []
            for det in counting_summary.get("detections", []):
                t = det.get("track_id")
                dom = det.get("plate_text")
                if not dom or not (self._min_plate_len <= len(dom) <= 10):
                    continue
                if t in seen:
                    continue
                seen.add(t)
                display_texts.append(dom)
        else:
            human_text_lines.append("\t- License Plates Detected: 0")

        human_text_lines.append("")
        detections = []
        for detection in counting_summary.get("detections", []):
            dom = detection.get("plate_text", "")
            if not dom:
                dom = ""
            bbox = detection.get("bounding_box", {})
            category = detection.get("category", "")
            detection_obj = self.create_detection_object(
                category,
                bbox,
                segmentation=None,
                plate_text=dom,
                track_id=detection.get("track_id"),
            )
            detections.append(detection_obj)

        alert_settings = []
        # Build alert settings tolerating dict or dataclass for alert_config
        if config.alert_config:
            alert_cfg = config.alert_config
            alert_type = (
                getattr(alert_cfg, "alert_type", None)
                if not isinstance(alert_cfg, dict)
                else alert_cfg.get("alert_type")
            )
            alert_value = (
                getattr(alert_cfg, "alert_value", None)
                if not isinstance(alert_cfg, dict)
                else alert_cfg.get("alert_value")
            )
            count_thresholds = (
                getattr(alert_cfg, "count_thresholds", None)
                if not isinstance(alert_cfg, dict)
                else alert_cfg.get("count_thresholds")
            )
            if not isinstance(alert_type, list):
                alert_type = list(alert_type) if alert_type is not None else ["Default"]
            if not isinstance(alert_value, list):
                alert_value = list(alert_value) if alert_value is not None else ["JSON"]
            alert_settings.append(
                {
                    "alert_type": alert_type,
                    "incident_category": self.CASE_TYPE,
                    "threshold_level": count_thresholds or {},
                    "ascending": True,
                    "settings": dict(zip(alert_type, alert_value)),
                }
            )

        if alerts:
            human_text_lines.append(f"Alerts: {alerts[0].get('settings', {})}")
        else:
            human_text_lines.append("Alerts: None")

        human_text = "\n".join(human_text_lines)
        reset_settings = [
            {"interval_type": "daily", "reset_time": {"value": 9, "time_unit": "hour"}}
        ]

        tracking_stat = self.create_tracking_stats(
            total_counts=total_counts_list,
            current_counts=current_counts,
            detections=detections,
            human_text=human_text,
            camera_info=camera_info,
            alerts=alerts,
            alert_settings=alert_settings,
            reset_settings=reset_settings,
            start_time=high_precision_start_timestamp,
            reset_time=high_precision_reset_timestamp,
        )
        tracking_stat["target_categories"] = self.target_categories
        # current_new_counts: NEW track IDs that appeared for first time in this frame/aggregation
        tracking_stat["current_new_counts"] = current_new_counts
        tracking_stats.append(tracking_stat)
        return tracking_stats

    def _check_alerts(
        self, summary: Dict, frame_number: Any, config: LicensePlateMonitorConfig
    ) -> List[Dict]:
        """Check if any alert thresholds are exceeded."""

        def get_trend(data, lookback=900, threshold=0.6):
            window = data[-lookback:] if len(data) >= lookback else data
            if len(window) < 2:
                return True
            increasing = sum(
                1 for i in range(1, len(window)) if window[i] >= window[i - 1]
            )
            return increasing / (len(window) - 1) >= threshold

        frame_key = str(frame_number) if frame_number is not None else "current_frame"
        alerts = []
        total_detections = summary.get("total_count", 0)
        per_category_count = summary.get("per_category_count", {})

        if not config.alert_config:
            return alerts

        # Extract thresholds regardless of dict/dataclass
        _alert_cfg = config.alert_config
        _thresholds = (
            getattr(_alert_cfg, "count_thresholds", None)
            if not isinstance(_alert_cfg, dict)
            else _alert_cfg.get("count_thresholds")
        )
        _types = (
            getattr(_alert_cfg, "alert_type", None)
            if not isinstance(_alert_cfg, dict)
            else _alert_cfg.get("alert_type")
        )
        _values = (
            getattr(_alert_cfg, "alert_value", None)
            if not isinstance(_alert_cfg, dict)
            else _alert_cfg.get("alert_value")
        )
        _types = (
            _types
            if isinstance(_types, list)
            else (list(_types) if _types is not None else ["Default"])
        )
        _values = (
            _values
            if isinstance(_values, list)
            else (list(_values) if _values is not None else ["JSON"])
        )
        if _thresholds:
            for category, threshold in _thresholds.items():
                if category == "all" and total_detections > threshold:
                    alerts.append(
                        {
                            "alert_type": _types,
                            "alert_id": f"alert_{category}_{frame_key}",
                            "incident_category": self.CASE_TYPE,
                            "threshold_level": threshold,
                            "ascending": get_trend(self._ascending_alert_list),
                            "settings": {t: v for t, v in zip(_types, _values)},
                        }
                    )
                elif (
                    category in per_category_count
                    and per_category_count[category] > threshold
                ):
                    alerts.append(
                        {
                            "alert_type": _types,
                            "alert_id": f"alert_{category}_{frame_key}",
                            "incident_category": self.CASE_TYPE,
                            "threshold_level": threshold,
                            "ascending": get_trend(self._ascending_alert_list),
                            "settings": {t: v for t, v in zip(_types, _values)},
                        }
                    )
        return alerts

    def _generate_incidents(
        self,
        counting_summary: Dict,
        alerts: List,
        config: LicensePlateMonitorConfig,
        frame_number: Optional[int] = None,
        stream_info: Optional[Dict[str, Any]] = None,
    ) -> List[Dict]:
        """Generate structured incidents."""
        frame_key = str(frame_number) if frame_number is not None else "current_frame"
        incidents = []
        total_detections = counting_summary.get("total_count", 0)
        current_timestamp = self._get_current_timestamp_str(
            stream_info, precision=False
        )
        camera_info = self.get_camera_info_from_stream(stream_info)

        self._ascending_alert_list = (
            self._ascending_alert_list[-900:]
            if len(self._ascending_alert_list) > 900
            else self._ascending_alert_list
        )

        if total_detections > 0:
            start_timestamp = self._get_start_timestamp_str(
                stream_info, precision=False
            )
            self._debug_stream_timing("start_timestamp", start_timestamp)
            if start_timestamp and self.current_incident_end_timestamp == "N/A":
                self.current_incident_end_timestamp = "Incident still active"
            elif (
                start_timestamp
                and self.current_incident_end_timestamp == "Incident still active"
            ):
                if (
                    len(self._ascending_alert_list) >= 15
                    and sum(self._ascending_alert_list[-15:]) / 15 < 1.5
                ):
                    self.current_incident_end_timestamp = current_timestamp
            elif (
                self.current_incident_end_timestamp != "Incident still active"
                and self.current_incident_end_timestamp != "N/A"
            ):
                self.current_incident_end_timestamp = "N/A"

            if config.alert_config and config.alert_config.count_thresholds:
                threshold = config.alert_config.count_thresholds.get("all", 15)
                intensity = min(10.0, (total_detections / threshold) * 10)
                if intensity >= 9:
                    level = "critical"
                    self._ascending_alert_list.append(3)
                elif intensity >= 7:
                    level = "significant"
                    self._ascending_alert_list.append(2)
                elif intensity >= 5:
                    level = "medium"
                    self._ascending_alert_list.append(1)
                else:
                    level = "low"
                    self._ascending_alert_list.append(0)
            else:
                if total_detections > 30:
                    level = "critical"
                    self._ascending_alert_list.append(3)
                elif total_detections > 25:
                    level = "significant"
                    self._ascending_alert_list.append(2)
                elif total_detections > 15:
                    level = "medium"
                    self._ascending_alert_list.append(1)
                else:
                    level = "low"
                    self._ascending_alert_list.append(0)

            human_text_lines = [f"INCIDENTS DETECTED @ {current_timestamp}:"]
            human_text_lines.append(f"\tSeverity Level: {(self.CASE_TYPE, level)}")
            human_text = "\n".join(human_text_lines)

            alert_settings = []
            if config.alert_config:
                _alert_cfg = config.alert_config
                _types = (
                    getattr(_alert_cfg, "alert_type", None)
                    if not isinstance(_alert_cfg, dict)
                    else _alert_cfg.get("alert_type")
                )
                _values = (
                    getattr(_alert_cfg, "alert_value", None)
                    if not isinstance(_alert_cfg, dict)
                    else _alert_cfg.get("alert_value")
                )
                _thresholds = (
                    getattr(_alert_cfg, "count_thresholds", None)
                    if not isinstance(_alert_cfg, dict)
                    else _alert_cfg.get("count_thresholds")
                )
                _types = (
                    _types
                    if isinstance(_types, list)
                    else (list(_types) if _types is not None else ["Default"])
                )
                _values = (
                    _values
                    if isinstance(_values, list)
                    else (list(_values) if _values is not None else ["JSON"])
                )
                alert_settings.append(
                    {
                        "alert_type": _types,
                        "incident_category": self.CASE_TYPE,
                        "threshold_level": _thresholds or {},
                        "ascending": True,
                        "settings": {t: v for t, v in zip(_types, _values)},
                    }
                )

            event = self.create_incident(
                incident_id=f"{self.CASE_TYPE}_{frame_key}",
                incident_type=self.CASE_TYPE,
                severity_level=level,
                human_text=human_text,
                camera_info=camera_info,
                alerts=alerts,
                alert_settings=alert_settings,
                start_time=start_timestamp,
                end_time=self.current_incident_end_timestamp,
                level_settings={"low": 1, "medium": 3, "significant": 4, "critical": 7},
            )
            incidents.append(event)
        else:
            self._ascending_alert_list.append(0)
            incidents.append({})

        return incidents

    def _generate_summary(
        self,
        _summary: Dict,
        incidents: List,
        tracking_stats: List,
        business_analytics: List,
        _alerts: List,
    ) -> List[str]:
        """Generate a human-readable summary."""
        _ = (_alerts, _summary)
        """
        Generate a human_text string for the tracking_stat, incident, business analytics and alerts.
        """
        lines = []
        lines.append("Application Name: " + self.CASE_TYPE)
        lines.append("Application Version: " + self.CASE_VERSION)
        if len(incidents) > 0:
            lines.append(
                "Incidents: "
                + f"\n\t{incidents[0].get('human_text', 'No incidents detected')}"
            )
        if len(tracking_stats) > 0:
            lines.append(
                "Tracking Statistics: "
                + f"\t{tracking_stats[0].get('human_text', 'No tracking statistics detected')}"
            )
        if len(business_analytics) > 0:
            lines.append(
                "Business Analytics: "
                + f"\t{business_analytics[0].get('human_text', 'No business analytics detected')}"
            )

        if (
            len(incidents) == 0
            and len(tracking_stats) == 0
            and len(business_analytics) == 0
        ):
            lines.append("Summary: " + "No Summary Data")

        return ["\n".join(lines)]

    def _update_tracking_state(self, detections: List[Dict]):
        """Track unique track_ids per category.
        Computes which track IDs are NEW (appeared for first time this frame).
        """
        if not hasattr(self, "_per_category_total_track_ids"):
            self._per_category_total_track_ids = {
                cat: set() for cat in self.target_categories
            }
        if not hasattr(self, "_previous_frame_track_ids"):
            self._previous_frame_track_ids = {
                cat: set() for cat in self.target_categories
            }
        self._current_frame_track_ids = {cat: set() for cat in self.target_categories}

        for det in detections:
            cat = det.get("category")
            raw_track_id = det.get("track_id")
            if cat not in self.target_categories or raw_track_id is None:
                continue
            bbox = det.get("bounding_box", det.get("bbox"))
            canonical_id = self._merge_or_register_track(raw_track_id, bbox)
            det["track_id"] = canonical_id
            self._per_category_total_track_ids.setdefault(cat, set()).add(canonical_id)
            self._current_frame_track_ids[cat].add(canonical_id)

        # NEW track IDs = present in current frame but NOT in previous frame
        self._new_track_ids_this_frame = {
            cat: (
                self._current_frame_track_ids.get(cat, set())
                - self._previous_frame_track_ids.get(cat, set())
            )
            for cat in self.target_categories
        }

        # Snapshot current -> previous for next call
        self._previous_frame_track_ids = {
            cat: set(ids) for cat, ids in self._current_frame_track_ids.items()
        }

    def _update_plate_texts(self, detections: List[Dict]):
        """Update set of seen plate texts and track the longest plate_text per track_id."""
        for det in detections:
            raw_text = det.get("plate_text")
            track_id = det.get("track_id")
            if not raw_text or track_id is None:
                continue

            cleaned = self._clean_text(raw_text)

            # Enforce plate length range
            if not (self._min_plate_len <= len(cleaned) <= 10):
                continue

            # Append to per-track rolling history (keep reasonable size)
            history = self.helper.get(track_id)
            if history is None:
                history = []
                self.helper[track_id] = history
            history.append(cleaned)
            if len(history) > 200:
                del history[: len(history) - 200]

            # Update per-track frequency counter (all-time)
            self._track_text_counts[track_id][cleaned] += 1

            # Update consecutive frame counter for stability across whole video
            self._text_history[cleaned] = self._text_history.get(cleaned, 0) + 1

            # Once stable, decide dominant text from LAST 50% of history
            if self._text_history[cleaned] >= self._stable_frames_required:
                half = max(1, len(history) // 2)
                window = history[-half:]
                dominant, _ = Counter(window).most_common(1)[0]

                # Update per-track mapping to dominant
                self._tracked_plate_texts[track_id] = dominant
                self.unique_plate_track[track_id] = dominant

                # Maintain global unique mapping with dominant only
                if dominant not in self._unique_plate_texts:
                    self._unique_plate_texts[dominant] = dominant

        # Let text_history counts accumulate so dominant text can emerge
        # even with inconsistent per-frame OCR. The majority voting in
        # _count_categories (last 50% of history) already provides robustness.

    def get_total_counts(self):
        """Return total unique license plate texts encountered so far."""
        return {"License_Plate": len(self._unique_plate_texts)}

    def get_new_counts_this_frame(self) -> Dict[str, int]:
        """Get count of NEW track IDs that appeared in this frame vs the previous one."""
        return {
            cat: len(ids)
            for cat, ids in getattr(self, "_new_track_ids_this_frame", {}).items()
        }

    def get_current_frame_counts(self) -> Dict[str, int]:
        """Get count of ALL track IDs currently in this frame (existing + new)."""
        return {
            cat: len(ids)
            for cat, ids in getattr(self, "_current_frame_track_ids", {}).items()
        }

    def _get_track_ids_info(self, detections: List[Dict]) -> Dict[str, Any]:
        """Get detailed information about track IDs."""
        frame_track_ids = {
            det.get("track_id") for det in detections if det.get("track_id") is not None
        }
        total_track_ids = set()
        for s in getattr(self, "_per_category_total_track_ids", {}).values():
            total_track_ids.update(s)
        return {
            "total_count": len(total_track_ids),
            "current_frame_count": len(frame_track_ids),
            "total_unique_track_ids": len(total_track_ids),
            "current_frame_track_ids": list(frame_track_ids),
            "last_update_time": time.time(),
            "total_frames_processed": getattr(self, "_total_frame_counter", 0),
        }

    def _compute_iou(self, box1: Any, box2: Any) -> float:
        """Compute IoU between two bounding boxes."""

        def _bbox_to_list(bbox):
            if bbox is None:
                return []
            if isinstance(bbox, list):
                return bbox[:4] if len(bbox) >= 4 else []
            if isinstance(bbox, dict):
                if "xmin" in bbox:
                    return [bbox["xmin"], bbox["ymin"], bbox["xmax"], bbox["ymax"]]
                if "x1" in bbox:
                    return [bbox["x1"], bbox["y1"], bbox["x2"], bbox["y2"]]
                values = [v for v in bbox.values() if isinstance(v, (int, float))]
                return values[:4] if len(values) >= 4 else []
            return []

        l1 = _bbox_to_list(box1)
        l2 = _bbox_to_list(box2)
        if len(l1) < 4 or len(l2) < 4:
            return 0.0
        x1_min, y1_min, x1_max, y1_max = l1
        x2_min, y2_min, x2_max, y2_max = l2
        x1_min, x1_max = min(x1_min, x1_max), max(x1_min, x1_max)
        y1_min, y1_max = min(y1_min, y1_max), max(y1_min, y1_max)
        x2_min, x2_max = min(x2_min, x2_max), max(x2_min, x2_max)
        y2_min, y2_max = min(y2_min, y2_max), max(y2_min, y2_max)
        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)
        inter_w = max(0.0, inter_x_max - inter_x_min)
        inter_h = max(0.0, inter_y_max - inter_y_min)
        inter_area = inter_w * inter_h
        area1 = (x1_max - x1_min) * (y1_max - y1_min)
        area2 = (x2_max - x2_min) * (y2_max - y2_min)
        union_area = area1 + area2 - inter_area
        return (inter_area / union_area) if union_area > 0 else 0.0

    def _merge_or_register_track(self, raw_id: Any, bbox: Any) -> Any:
        """Return a stable canonical ID for a raw tracker ID."""
        if raw_id is None or bbox is None:
            return raw_id
        now = time.time()
        if raw_id in self._track_aliases:
            canonical_id = self._track_aliases[raw_id]
            track_info = self._canonical_tracks.get(canonical_id)
            if track_info is not None:
                track_info["last_bbox"] = bbox
                track_info["last_update"] = now
                track_info["raw_ids"].add(raw_id)
            return canonical_id
        for canonical_id, info in self._canonical_tracks.items():
            if now - info["last_update"] > self._track_merge_time_window:
                continue
            iou = self._compute_iou(bbox, info["last_bbox"])
            if iou >= self._track_merge_iou_threshold:
                self._track_aliases[raw_id] = canonical_id
                info["last_bbox"] = bbox
                info["last_update"] = now
                info["raw_ids"].add(raw_id)
                return canonical_id
        canonical_id = raw_id
        self._track_aliases[raw_id] = canonical_id
        self._canonical_tracks[canonical_id] = {
            "last_bbox": bbox,
            "last_update": now,
            "raw_ids": {raw_id},
        }
        return canonical_id

    def _format_timestamp_for_stream(self, timestamp: float) -> str:
        """Format timestamp for streams (YYYY:MM:DD HH:MM:SS format)."""
        dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)
        return dt.strftime("%Y:%m:%d %H:%M:%S")

    def _format_timestamp_for_video(self, timestamp: float) -> str:
        """Format timestamp for video chunks (HH:MM:SS.ms format)."""
        hours = int(timestamp // 3600)
        minutes = int((timestamp % 3600) // 60)
        seconds = round(float(timestamp % 60), 2)
        return f"{hours:02d}:{minutes:02d}:{seconds:.1f}"

    def _format_timestamp(self, timestamp: Any) -> str:
        """Format a timestamp to match the current timestamp format: YYYY:MM:DD HH:MM:SS.

        The input can be either:
        1. A numeric Unix timestamp (``float`` / ``int``) – it will be converted to datetime.
        2. A string in the format ``YYYY-MM-DD-HH:MM:SS.ffffff UTC``.

        The returned value will be in the format: YYYY:MM:DD HH:MM:SS (no milliseconds, no UTC suffix).

        Example
        -------
        >>> self._format_timestamp("2025-10-27-19:31:20.187574 UTC")
        '2025:10:27 19:31:20'
        """

        # Convert numeric timestamps to datetime first
        if isinstance(timestamp, (int, float)):
            dt = datetime.fromtimestamp(timestamp, timezone.utc)
            return dt.strftime("%Y:%m:%d %H:%M:%S")

        # Ensure we are working with a string from here on
        if not isinstance(timestamp, str):
            return str(timestamp)

        # Remove ' UTC' suffix if present
        timestamp_clean = timestamp.replace(" UTC", "").strip()

        # Remove milliseconds if present (everything after the last dot)
        if "." in timestamp_clean:
            timestamp_clean = timestamp_clean.split(".")[0]

        # Parse the timestamp string and convert to desired format
        try:
            # Handle format: YYYY-MM-DD-HH:MM:SS
            if timestamp_clean.count("-") >= 2:
                # Replace first two dashes with colons for date part, third with space
                parts = timestamp_clean.split("-")
                if len(parts) >= 4:
                    # parts = ['2025', '10', '27', '19:31:20']
                    formatted = (
                        f"{parts[0]}:{parts[1]}:{parts[2]} {'-'.join(parts[3:])}"
                    )
                    return formatted
        except Exception:
            # Non-fatal: exception ignored here; execution continues per surrounding logic.
            pass

        # If parsing fails, return the cleaned string as-is
        return timestamp_clean

    def _get_current_timestamp_str(
        self,
        stream_info: Optional[Dict[str, Any]],
        precision=False,
        frame_id: Optional[str] = None,
    ) -> str:
        """Get formatted current timestamp based on stream type."""

        if not stream_info:
            return "00:00:00.00"
        if precision:
            if stream_info.get("input_settings", {}).get("start_frame", "na") != "na":
                if frame_id:
                    start_time = int(frame_id) / stream_info.get(
                        "input_settings", {}
                    ).get("original_fps", 30)
                else:
                    start_time = stream_info.get("input_settings", {}).get(
                        "start_frame", 30
                    ) / stream_info.get("input_settings", {}).get("original_fps", 30)
                stream_time_str = self._format_timestamp_for_video(start_time)
                self._debug_stream_timing("stream_time_str", stream_time_str)
                return self._format_timestamp(
                    stream_info.get("input_settings", {}).get("stream_time", "NA")
                )
            else:
                return datetime.now(timezone.utc).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")

        if stream_info.get("input_settings", {}).get("start_frame", "na") != "na":
            if frame_id:
                start_time = int(frame_id) / stream_info.get("input_settings", {}).get(
                    "original_fps", 30
                )
            else:
                start_time = stream_info.get("input_settings", {}).get(
                    "start_frame", 30
                ) / stream_info.get("input_settings", {}).get("original_fps", 30)

            stream_time_str = self._format_timestamp_for_video(start_time)

            self._debug_stream_timing("stream_time_str", stream_time_str)
            return self._format_timestamp(
                stream_info.get("input_settings", {}).get("stream_time", "NA")
            )
        else:
            stream_time_str = (
                stream_info.get("input_settings", {})
                .get("stream_info", {})
                .get("stream_time", "")
            )
            if stream_time_str:
                try:
                    timestamp_str = stream_time_str.replace(" UTC", "")
                    dt = datetime.strptime(timestamp_str, "%Y-%m-%d-%H:%M:%S.%f")
                    timestamp = dt.replace(tzinfo=timezone.utc).timestamp()
                    return self._format_timestamp_for_stream(timestamp)
                except Exception:
                    return self._format_timestamp_for_stream(time.time())
            else:
                return self._format_timestamp_for_stream(time.time())

    def _get_start_timestamp_str(
        self, stream_info: Optional[Dict[str, Any]], precision=False
    ) -> str:
        """Get formatted start timestamp for 'TOTAL SINCE' based on stream type."""
        if not stream_info:
            return "00:00:00"

        if precision:
            if self.start_timer is None:
                candidate = stream_info.get("input_settings", {}).get("stream_time")
                if not candidate or candidate == "NA":
                    candidate = datetime.now(timezone.utc).strftime(
                        "%Y-%m-%d-%H:%M:%S.%f UTC"
                    )
                self.start_timer = candidate
                return self._format_timestamp(self.start_timer)
            elif stream_info.get("input_settings", {}).get("start_frame", "na") == 1:
                candidate = stream_info.get("input_settings", {}).get("stream_time")
                if not candidate or candidate == "NA":
                    candidate = datetime.now(timezone.utc).strftime(
                        "%Y-%m-%d-%H:%M:%S.%f UTC"
                    )
                self.start_timer = candidate
                return self._format_timestamp(self.start_timer)
            else:
                return self._format_timestamp(self.start_timer)

        if self.start_timer is None:
            # Prefer direct input_settings.stream_time if available and not NA
            candidate = stream_info.get("input_settings", {}).get("stream_time")
            if not candidate or candidate == "NA":
                # Fallback to nested stream_info.stream_time used by current timestamp path
                stream_time_str = (
                    stream_info.get("input_settings", {})
                    .get("stream_info", {})
                    .get("stream_time", "")
                )
                if stream_time_str:
                    try:
                        timestamp_str = stream_time_str.replace(" UTC", "")
                        dt = datetime.strptime(timestamp_str, "%Y-%m-%d-%H:%M:%S.%f")
                        self._tracking_start_time = dt.replace(
                            tzinfo=timezone.utc
                        ).timestamp()
                        candidate = datetime.fromtimestamp(
                            self._tracking_start_time, timezone.utc
                        ).strftime("%Y-%m-%d-%H:%M:%S.%f UTC")
                    except Exception:
                        candidate = datetime.now(timezone.utc).strftime(
                            "%Y-%m-%d-%H:%M:%S.%f UTC"
                        )
                else:
                    candidate = datetime.now(timezone.utc).strftime(
                        "%Y-%m-%d-%H:%M:%S.%f UTC"
                    )
            self.start_timer = candidate
            return self._format_timestamp(self.start_timer)
        elif stream_info.get("input_settings", {}).get("start_frame", "na") == 1:
            candidate = stream_info.get("input_settings", {}).get("stream_time")
            if not candidate or candidate == "NA":
                stream_time_str = (
                    stream_info.get("input_settings", {})
                    .get("stream_info", {})
                    .get("stream_time", "")
                )
                if stream_time_str:
                    try:
                        timestamp_str = stream_time_str.replace(" UTC", "")
                        dt = datetime.strptime(timestamp_str, "%Y-%m-%d-%H:%M:%S.%f")
                        ts = dt.replace(tzinfo=timezone.utc).timestamp()
                        candidate = datetime.fromtimestamp(ts, timezone.utc).strftime(
                            "%Y-%m-%d-%H:%M:%S.%f UTC"
                        )
                    except Exception:
                        candidate = datetime.now(timezone.utc).strftime(
                            "%Y-%m-%d-%H:%M:%S.%f UTC"
                        )
                else:
                    candidate = datetime.now(timezone.utc).strftime(
                        "%Y-%m-%d-%H:%M:%S.%f UTC"
                    )
            self.start_timer = candidate
            return self._format_timestamp(self.start_timer)

        else:
            if self.start_timer is not None and self.start_timer != "NA":
                return self._format_timestamp(self.start_timer)

            if self._tracking_start_time is None:
                stream_time_str = (
                    stream_info.get("input_settings", {})
                    .get("stream_info", {})
                    .get("stream_time", "")
                )
                if stream_time_str:
                    try:
                        timestamp_str = stream_time_str.replace(" UTC", "")
                        dt = datetime.strptime(timestamp_str, "%Y-%m-%d-%H:%M:%S.%f")
                        self._tracking_start_time = dt.replace(
                            tzinfo=timezone.utc
                        ).timestamp()
                    except Exception:
                        self._tracking_start_time = time.time()
                else:
                    self._tracking_start_time = time.time()

            dt = datetime.fromtimestamp(self._tracking_start_time, tz=timezone.utc)
            dt = dt.replace(minute=0, second=0, microsecond=0)
            return dt.strftime("%Y:%m:%d %H:%M:%S")

    def _get_tracking_start_time(self) -> str:
        """Get the tracking start time, formatted as a string."""
        if self._tracking_start_time is None:
            return "N/A"
        return self._format_timestamp(self._tracking_start_time)

    def _set_tracking_start_time(self) -> None:
        """Set the tracking start time to the current time."""
        self._tracking_start_time = time.time()

    def _attach_masks_to_detections(
        self,
        processed_detections: List[Dict[str, Any]],
        raw_detections: List[Dict[str, Any]],
        iou_threshold: float = 0.5,
    ) -> List[Dict[str, Any]]:
        """Attach segmentation masks from raw detections to processed detections."""
        if not processed_detections or not raw_detections:
            for det in processed_detections:
                det.setdefault("masks", [])
            return processed_detections

        used_raw_indices = set()
        for det in processed_detections:
            best_iou = 0.0
            best_idx = None
            for idx, raw_det in enumerate(raw_detections):
                if idx in used_raw_indices:
                    continue
                iou = self._compute_iou(
                    det.get("bounding_box"), raw_det.get("bounding_box")
                )
                if iou > best_iou:
                    best_iou = iou
                    best_idx = idx
            if best_idx is not None and best_iou >= iou_threshold:
                raw_det = raw_detections[best_idx]
                masks = raw_det.get("masks", raw_det.get("mask"))
                if masks is not None:
                    det["masks"] = masks
                used_raw_indices.add(best_idx)
            else:
                det.setdefault("masks", ["EMPTY"])
        return processed_detections
