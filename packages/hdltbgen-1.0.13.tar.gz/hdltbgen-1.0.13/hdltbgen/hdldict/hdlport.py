from  .hdlparam import hdlparam

class hdlport():
    """Class to store information about a port.
    """

    def __init__(self):
        self._name = ""
        self._direction = ""
        self._type = ""
        self._type_orig = ""
        self._virtual = False

    def replace_param(self, params: list):
        """Replace parameters in the type of the port.

        :param params: List of parameters to replace
        :type params: list
        """
        if not isinstance(params, list): 
            params = [params]

        self._type = self._type_orig
        for param in params:            
            if not isinstance(param, hdlparam):
                raise ValueError("Parameter params must an object of class hdlparam.")
            self._type = self._type.replace(param.name, param.const_name)
            
    def __repr__(self):
        return 'hdlport()'

    def __str__(self):
        return f"Port: {self.name} {self.direction} {self.type} ({self.type_orig}), Virtual: {self.virtual}"

    @property
    def name(self) -> str:
        """Name of the port.
        
        :return: Name of the port
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, value: str):
        """Name of the port.
        :param value: Name of the port
        :type value: str
        """
        self._name = value

    @property
    def direction(self) -> str:
        """Direction of the port.
        
        :return: Direction of the port
        :rtype: str
        """
        return self._direction

    @direction.setter
    def direction(self, value: str):
        """Direction of the port.
        :param value: Direction of the port
        :type value: str
        """
        self._direction = value

    @property
    def type_sanitized(self) -> str:
        """Base datatype of the port.
        
        :return: Base datatype of the port
        :rtype: str
        """

        # Check if the type contains () and remove them and everything inside
        if "(" in self._type:
            return self._type[:self._type.index("(")]
        else:
            return self._type

    @property
    def type(self) -> str:
        """Type of the port.
        
        :return: Type of the port
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, value: str):
        """Type of the port.
        :param value: Type of the port
        :type value: str
        """
        self._type = value
        self._type_orig = value

    @property
    def type_orig(self) -> str:
        """Original type of the port.
        
        :return: Original type of the port
        :rtype: str
        """
        return self._type_orig

    @property
    def virtual(self) -> bool:
        """Virtual status of the port.
        
        :return: Virtual status of the port
        :rtype: bool
        """
        return self._virtual

    @virtual.setter
    def virtual(self, value: bool):
        """Virtual status of the port.
        :param value: Virtual status of the port
        :type value: bool
        """
        self._virtual = value

    
