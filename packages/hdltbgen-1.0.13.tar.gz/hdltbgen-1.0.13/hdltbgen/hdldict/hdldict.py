"""Dictonary of HDL objects (Parameters and Ports)
"""

from  .hdlport import hdlport


class hdldict():
    """Dictonary of HDL objects (Parameters and Ports)"""

    def __init__(self):
        self._ports = []
        self._params = []
        self._entity_name = ""
        self._clock = []
        self._resetn = []
        self._resetp = []

    def __repr__(self):
        return 'hdldict()'
    
    def __str__(self):
        return f"Entity: {self.entity_name}, Ports: {[str(port) for port in self._ports]}, Params: {[str(param) for param in self._params]}, Clock: {[str(clock) for clock in self._clock]}, Resetn: {[str(resetn) for resetn in self._resetn]}, Resetp: {[str(resetp) for resetp in self._resetp]}"
    
    def auto_add_signals(self):
        """Add a clock and resets if not found in the port list.
        """
        if not self._clock:
            # try to find a clock in the port list
            found = False
            for port_ele in self._ports:
                if "clk" in port_ele.name.lower():
                    found = True
                    self._clock.append(port_ele.name)
                    break

            # Add auto generated clock
            if found == False:
                port_ele_clk = hdlport()
                port_ele_clk.name = "clk_auto_gen"
                port_ele_clk.direction = "in"
                port_ele_clk.type = "std_logic"
                port_ele_clk.virtual = True
                self.add_port(port_ele_clk, True)
                self._clock.append(port_ele_clk.name)

        # try to find a reset in the port list
        if not self._resetn and not self._resetp:
            for port_ele in self._ports:
                if "rstn" in port_ele.name.lower() or "resetn" in port_ele.name.lower() or "nreset" in port_ele.name.lower() or "nrst" in port_ele.name.lower():
                    self._resetn.append(port_ele.name)

        if not self._resetp and not self._resetn:
            for port_ele in self._ports:
                if "rst" in port_ele.name.lower() or "reset" in port_ele.name.lower() or "rst" in port_ele.name.lower():
                    self._resetp.append(port_ele.name)
    
    def add_clock(self, clocks: list):
        """Add a new clock.

        :param clock: New clocks to add
        :type clock: list
        """

        if not isinstance(clocks, list): 
            clocks = [clocks]

        for clk in clocks:
            if not any(port_ele.name == clk for port_ele in self._ports):
                raise ValueError(f"Clock {clk} not found in the port list.")
            self._clock.append(clk)

    def add_resetn(self, resetns: list):
        """Add a new resetn.

        :param resetn: New resetns to add
        :type resetn: list
        """

        if not isinstance(resetns, list): 
            resetns = [resetns]

        for rstn in resetns:
            if not any(port_ele.name == rstn for port_ele in self._ports):
                raise ValueError(f"Resetn {rstn} not found in the port list.")
            self._resetn.append(rstn)

    def add_resetp(self, resetps: list):
        """Add a new resetp.

        :param resetp: New resetps to add
        :type resetp: list
        """

        if not isinstance(resetps, list): 
            resetps = [resetps]

        for rstp in resetps:
            if not any(port_ele.name == rstp for port_ele in self._ports):
                raise ValueError(f"Resetp {rstp} not found in the port list.")
            self._resetp.append(rstp)

    @property
    def clock(self) -> list:
        """List with clock objects.
        
        :return: List with clock objects
        :rtype: list
        """
        return self._clock
    
    @property
    def resetn(self) -> list:
        """List with resetn objects.
        
        :return: List with resetn objects
        :rtype: list
        """
        return self._resetn
    
    @property
    def resetp(self) -> list:
        """List with resetp objects.
        
        :return: List with resetp objects
        :rtype: list
        """
        return self._resetp
    
    @property
    def entity_name(self) -> str:
        """Name of the entity.
        
        :return: Name of the entity
        :rtype: str
        """
        return self._entity_name
    
    @entity_name.setter
    def entity_name(self, value: str):
        """Name of the entity.
        :param value: Name of the entity
        :type value: str
        """
        self._entity_name = value

    @property
    def ports(self) -> list:
        """List with port objects.
        
        :return: List with port objects
        :rtype: list
        """
        for port in self._ports:
            port.replace_param(self._params)

        return self._ports
    
    @property
    def params(self) -> list:
        """List with param objects.
        
        :return: List with param objects
        :rtype: list
        """
        return self._params

    def add_port(self, new_port, front=False):
        """Add a new port.

        :param new_port: New port to add
        :type new_port: hdlport
        :param front: Add to the front of the list
        :type front: bool
        """
        if front:
            self._ports.insert(0, new_port)
        else:
            self._ports.append(new_port)

    def add_param(self, new_param):
        """Add a new parameter.

        :param new_param: New parameter to add
        :type new_param: hdlparam
        """
        self._params.append(new_param)


    
