class hdlparam():
    """Class to store information about a parameter.
    """

    def __init__(self):
        self._name = ""
        self._type = ""
        self._value = ""

    def __repr__(self):
        return 'hdlparam()'
    
    def __str__(self):
        return f"Parameter: {self.name} {self.type} {self.value}"
    
    @property
    def name(self) -> str:
        """Name of the parameter.
        
        :return: Name of the parameter
        :rtype: str
        """
        return self._name
    
    @property
    def const_name(self) -> str:
        """Constant name of the parameter.
        
        :return: Constant name of the parameter
        :rtype: str
        """
        if "_g" in self._name:
            return self._name.lower().replace("_g", "_c").upper()
        else:
             return self._name.upper() + "_C"
    
    @name.setter
    def name(self, value: str):
        """Name of the parameter.
        :param value: Name of the parameter
        :type value: str
        """
        self._name = value

    @property
    def type(self) -> str:
        """Type of the parameter.
        
        :return: Type of the parameter
        :rtype: str
        """
        return self._type
    
    @type.setter
    def type(self, value: str):
        """Type of the parameter.
        :param value: Type of the parameter
        :type value: str
        """
        self._type = value

    @property
    def value(self) -> str:
        """Value of the parameter.
        
        :return: Value of the parameter
        :rtype: str
        """
        return self._value
    
    @value.setter
    def value(self, value: str):
        """Value of the parameter.
        :param value: Value of the parameter
        :type value: str
        """
        self._value = value
