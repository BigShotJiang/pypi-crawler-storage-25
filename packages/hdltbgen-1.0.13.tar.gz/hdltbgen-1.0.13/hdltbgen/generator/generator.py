from  ..hdldict import hdldict
from pathlib import Path
import os
import getpass
from datetime import datetime
from importlib.metadata import version

class Generator():
    """Base Generator class.

    :param file: Path to file
    :type file: Path
    """

    def __init__(self, file: Path, hdl: hdldict, vunit: bool, **args):
        self.file = file
        self.hdl = hdl
        self.vunit = vunit
        self.args = args

    def _name(self) -> str:
        """Return name of the generator
        
        :return: Name of the generator
        :rtype: str
        """
        return self.__class__.__name__

    def generate(self):
        """Do generation of file
        """
        pass

    def get_header(self) -> list:
        """Return header of the file
        
        :return: Header of the file
        :rtype: list
        """

        user = "unknown"
        try:
            user = os.getlogin()
        except:
            user = getpass.getuser()

        header = [
            "----------------------------------------------------------------------------------------------------",
            f"brief: Testbench for entity {self.hdl.entity_name}",
            f"file: {self.file.name}",
            f"author: {user}",
            "----------------------------------------------------------------------------------------------------",
            f"Copyright(c) {datetime.now().year} by OST, Switzerland",
            "All rights reserved.",
            "----------------------------------------------------------------------------------------------------",
            "File history:",
            "Version, Date, Author, Remarks",
            "----------------------------------------------------------------------------------------------------",
            f"0.1, {datetime.now().strftime('%d.%m.%Y')}, {user}, Auto-Created with hdltbgen {version('hdltbgen')}",
            "----------------------------------------------------------------------------------------------------"
        ]
        
        return header