from pathlib import Path
from .generator import Generator
from .jinja2 import Generator_Jinja2
from  ..hdldict.hdldict import hdldict

class Generator_CSV(Generator, Generator_Jinja2):
    """Generate a CSV file."""

    def __init__(self, file: Path, hdl: hdldict, vunit: bool, **args):
        """Initialize the CSV generator

        :param file: Path to CSV file
        :type file: Path
        :param hdl: HDL dictionary
        :type hdl: hdldict
        :param vunit: Generate VUnit testbench
        :type vunit: bool
        """
        super().__init__(file, hdl, vunit, **args)

    def generate(self):
        """Do generation of CSV file
        """

         # prepare jinja2
        j2_template = 'csv.j2'
        j2_vars = {}
        j2_vars['hdl'] = self.hdl
        j2_vars['vunit'] = self.vunit
        j2_vars['header'] = self.get_header()
        j2_vars['path'] = self.file.parent

        # render
        self.render_to_file(j2_template, j2_vars, self.file)
