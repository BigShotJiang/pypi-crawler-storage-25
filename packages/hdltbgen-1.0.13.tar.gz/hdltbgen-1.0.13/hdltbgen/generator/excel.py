from pathlib import Path
from .generator import Generator
from  ..hdldict.hdldict import hdldict
from importlib import import_module
import os


def _load_excel_dependencies():
    """Load optional Excel dependencies at runtime."""
    missing = []

    try:
        openpyxl = import_module("openpyxl")
        from openpyxl.styles import Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ModuleNotFoundError:
        missing.append("openpyxl")
        openpyxl = None
        Font = None
        PatternFill = None
        get_column_letter = None

    try:
        xw = import_module("xlwings")
    except ModuleNotFoundError:
        missing.append("xlwings")
        xw = None

    if missing:
        missing_text = ", ".join(missing)
        raise ModuleNotFoundError(
            f"Missing optional Excel dependencies: {missing_text}. "
            "Install them with: pip install 'hdltbgen[excel]'"
        )

    return openpyxl, Font, PatternFill, get_column_letter, xw

class Generator_Excel(Generator):
    """Generate an Excel file."""

    def __init__(self, file: Path, hdl: hdldict, vunit: bool, **args):
        """Initialize the CSV generator

        :param file: Path to CSV file
        :type file: Path
        :param hdl: HDL dictionary
        :type hdl: hdldict
        :param vunit: Generate VUnit testbench
        :type vunit: bool
        """
        super().__init__(file, hdl, vunit, **args)

    def generate(self):
        """Do generation of Excel file
        """
        openpyxl, Font, PatternFill, get_column_letter, xw = _load_excel_dependencies()

        # Generate a list with the clock signals and count the input and output ports
        port_list_without_clk = []
        cnt_port_in = 0
        cnt_port_out = 0
        for port_ele in self.hdl.ports:
            if not port_ele.name in self.hdl.clock:
                port_list_without_clk.append(port_ele)
                if port_ele.direction in ["in", "inout"]:
                    cnt_port_in = cnt_port_in + 1
                if port_ele.direction in ["out", "inout"]:
                    cnt_port_out = cnt_port_out + 1

        # Create the excel file
        wb = openpyxl.Workbook()
        sh = wb.active
        sh.title = self.hdl.entity_name[:28] + "_tb" if len(self.hdl.entity_name) > 28 else self.hdl.entity_name + "_tb"

        # Generate the header
        for row_num, row_data in enumerate(self.get_header(), 1):
            sh.cell(row=row_num, column=2, value=row_data)      
            sh.cell(row=row_num, column=1, value="-")    

        # Merge cells for the header
        sh.cell(row=14, column=1, value="-")
        for row in range(1, 15):
            sh.cell(row=15, column=1, value="-")
            sh.merge_cells(start_row=row, start_column=2, end_column=(cnt_port_in + cnt_port_out + 1), end_row=row)

        # Write the stimulus and responses
        sh.cell(row=15, column=1, value="-")
        if cnt_port_in > 0:
            sh.cell(row=15, column=2, value="Stimulus:")
        if cnt_port_out > 0:
            sh.cell(row=15, column=2 + cnt_port_in, value="Response:")

        sh.cell(row=16, column=1, value="-")
        sh.cell(row=17, column=1, value="-")            

        col_cnt = 2
        if port_list_without_clk:
            for port_ele in port_list_without_clk:
                if port_ele.direction in ["in", "inout"] :
                    sh.cell(row=16, column=col_cnt, value=port_ele.name)
                    sh.cell(row=17, column=col_cnt, value=port_ele.type)
                    sh.cell(row=16, column=col_cnt).font = Font(size=8)
                    sh.cell(row=17, column=col_cnt).font = Font(size=8)
                    col_cnt += 1
            for port_ele in port_list_without_clk:
                if port_ele.direction in ["out", "inout"]:
                    sh.cell(row=16, column=col_cnt, value=port_ele.name)
                    sh.cell(row=17, column=col_cnt, value=port_ele.type)
                    sh.cell(row=16, column=col_cnt).font = Font(size=8)
                    sh.cell(row=17, column=col_cnt).font = Font(size=8)
                    col_cnt += 1

        sh.cell(row=18, column=1, value="-")
        sh.cell(row=18, column=2, value="----------------------------------------------------------------------------------------------------")
        sh.merge_cells(start_row=18, start_column=2, end_column=cnt_port_in + cnt_port_out + 2, end_row=18)

        # Freeze panes
        sh.freeze_panes = sh['A19']

        # Add first four lines of the testbench
        sh.cell(row=19, column=1, value="-")
        sh.cell(row=19, column=2, value="Reset sequence")
        sh.cell(row=19, column=2).font = Font(bold=True)
        sh.cell(row=19, column=2).fill = PatternFill(start_color="BDD7EE", end_color="BDD7EE", fill_type="solid")
        sh.merge_cells(start_row=19, start_column=2, end_column=cnt_port_in + cnt_port_out + 1, end_row=19)

        sh.cell(row=21, column=1, value="-")
        sh.cell(row=21, column=2, value="TODO: Add Test steps here")
        sh.cell(row=21, column=2).font = Font(bold=True)
        sh.cell(row=21, column=2).fill = PatternFill(start_color="BDD7EE", end_color="BDD7EE", fill_type="solid")
        sh.merge_cells(start_row=21, start_column=2, end_column=cnt_port_in + cnt_port_out + 1, end_row=21)

        # Auto-fit columns
        for col in range(1, cnt_port_in + cnt_port_out + 2):
            max_length = 0
            column = get_column_letter(col)
            for cell in sh[column]:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 2)
            sh.column_dimensions[column].width = adjusted_width

        # Save the file
        tb_path = self.file.parent.joinpath(self.file.stem + ".xlsx")
        wb.save(tb_path)

        try:
            wbMacro = xw.Book(tb_path)

            # VBA macro code to be inserted
            macro_code = '''
Sub SaveToCSV()
    Dim fs As Object
    Set fs = CreateObject("Scripting.FileSystemObject")
    Application.DisplayAlerts = False
    ActiveWorkbook.SaveAs fs.BuildPath(ActiveWorkbook.Path, Left(ActiveWorkbook.name, InStr(ActiveWorkbook.name, ".") - 1) & ".csv"), xlCSV, CreateBackup:=False, Local:=True
    ActiveWorkbook.SaveAs fs.BuildPath(ActiveWorkbook.Path, Left(ActiveWorkbook.name, InStr(ActiveWorkbook.name, ".") - 1) & ".xlsm"), XlFileFormat.xlOpenXMLWorkbookMacroEnabled, CreateBackup:=False
    Application.DisplayAlerts = True
End Sub
            '''
            wbMacro.api.VBProject.VBComponents.Add(1).CodeModule.AddFromString(macro_code)

            macro_code = '''
Dim fInSaving As Boolean
Dim firstTime As Integer
Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)
    If firstTime = 123 Then
        If fInSaving Then
            Exit Sub
        End If
        fInSaving = True
        Call SaveToCSV
        Cancel = True
        fInSaving = False
    End If
End Sub
Private Sub Workbook_Open()
    fInSaving = False
    firstTime = 123
End Sub
            '''

            # Add a new module and insert the VBA code
            wbMacro.api.VBProject.VBComponents.Item(1).CodeModule.AddFromString(macro_code)

            # Save the workbook with macro-enabled extension
            tb_path_macro = self.file.parent.joinpath(self.file.stem + ".xlsm")
            wbMacro.save(tb_path_macro)

            # Close the workbook
            wbMacro.close()

            # Remove xlsx file
            os.remove(tb_path)

        except Exception as e:
            print("Could not generate the Excel file with VBA macro.")
            print("Ensure Excel Settings: Enable 'Trust access to the VBA project object model' in Excel:")
            print("Go to File > Options > Trust Center > Trust Center Settings.")
            print("In Macro Settings, check 'Trust access to the VBA project object model'.")
            raise(e)

