from pathlib import Path
from .generator import Generator
from .jinja2 import Generator_Jinja2
from  ..hdldict.hdldict import hdldict

class Generator_VHDL(Generator, Generator_Jinja2):
    """Generate a VHDL file."""

    def __init__(self, file: Path, hdl: hdldict, vunit: bool, simfile: bool, **args):
        """Initialize the VHDL generator

        :param file: Path to VHDL file
        :type file: Path
        :param hdl: HDL dictionary
        :type hdl: hdldict
        :param vunit: Generate VUnit testbench
        :type vunit: bool
        :param simfile: Generate simulation file
        :type simfile: bool
        """
        super().__init__(file, hdl, vunit, **args)
        self.simfile = simfile

    def generate(self):
        """Do generation of VHDL file
        """

         # prepare jinja2
        j2_template = 'vhdl.j2'
        j2_vars = {}
        j2_vars['hdl'] = self.hdl
        j2_vars['vunit'] = self.vunit
        j2_vars['simfile'] = self.simfile
        j2_vars['header'] = self.get_header()
        j2_vars['path'] = self.file.parent

        # render
        self.render_to_file(j2_template, j2_vars, self.file)

        if self.simfile:
            j2_template = 'vhdl_sim.j2'
            self.render_to_file(j2_template, j2_vars, self.file.parent.joinpath(self.file.stem + "_sim.vhd"))
