from  ..hdldict import hdldict
from pathlib import Path

class Parser():
    """Base parser class.

    :param file: Path to file
    :type file: Path
    """

    def __init__(self, file: Path, **args):
        self.file = file
        self.args = args

        if not self.file.exists():
            raise FileNotFoundError(f"File {self.file} not found")

    def _name(self) -> str:
        """Return name of the parser
        
        :return: Name of the parser
        :rtype: str
        """
        return self.__class__.__name__

    def parse(self) -> hdldict:
        """Do parsing of file
        
        :return: Dictionary of parsed object
        :rtype: hdldict
        """
        pass