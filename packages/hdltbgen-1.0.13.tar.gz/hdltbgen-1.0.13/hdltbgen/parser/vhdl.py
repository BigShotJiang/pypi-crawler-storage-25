from .parser import Parser
from pathlib import Path
from  ..hdldict.hdldict import hdldict
from  ..hdldict.hdlport import hdlport
from  ..hdldict.hdlparam import hdlparam
import re

class Parser_VHDL(Parser):
    """Parse a VHDL file."""

    def __init__(self, file: Path, askForValues: bool, **args):
        """Initialize the VHDL parser

        :param file: Path to VHDL file
        :type file: Path
        :param askForValues: Ask for values of generics
        :type askForValues: bool
        """
        super().__init__(file, **args)
        self.__askForValues = askForValues

    def parse(self) -> hdldict:
        """Do parsing of VHDL file
        
        :return: Dictionary of parsed object
        :rtype: hdldict
        """

        # Generate the dictionary
        myDict = hdldict()

        # Open the VHDL file
        with self.file.open() as f:
            lines = f.readlines()

        # Loop through the lines
        entity_found = False
        generic_running = False
        port_running = False
        for line in lines:
            line = self.__remove_comment(line)
            if line == "":
                continue

            # Identify entity
            if entity_found == False:
                entity_match = re.match(r"^\s*entity\s+(\w+)\s+is", line, re.IGNORECASE)
                if entity_match:
                    myDict.entity_name = entity_match.group(1)
                    entity_found = True
                    continue
            else:
                
                if generic_running == False and port_running == False:
                    # Identify end entity
                    end_entity_match = re.match(r"^\s*end\sentity\s+(\w+);", line, re.IGNORECASE)
                    if end_entity_match:
                        break

                    # Identify generic
                    generic_match = re.match(r"^\s*generic\s*\(", line, re.IGNORECASE)
                    if generic_match:
                        line = re.sub(r"generic\s*\(", "", line).strip()
                        generic_running = True

                    # Identify port
                    port_match = re.match(r"^\s*port\s*\(", line, re.IGNORECASE)
                    if port_match:
                        line = re.sub(r"port\s*\(", "", line).strip()
                        port_running = True
                        
                if generic_running == True:
                    # Check if the line is not empty
                    if line and line != "" and line != ");":
                        gen_ele = hdlparam()

                        # Get name and type
                        gen_ele.name = re.search(r"^\s*(\w+)\s*:", line).group(1)
                        gen_ele.type = re.search(r":\s*([^;:=]+)", line).group(1).strip()

                        # Set the values if asked for
                        if self.__askForValues:
                            # Define the ranges for the types
                            type_ranges = {
                                "integer": (-2147483648, 2147483647),
                                "natural": (0, 2147483647),
                                "positive": (1, 2147483647),
                                "real": (-1.0e+38, 1.0e+38)
                            }

                            for type_name, (default_min, default_max) in type_ranges.items():
                                if type_name in gen_ele.type:
                                    range_min, range_max = default_min, default_max
                                    if "range" in gen_ele.type:
                                        temp_string = gen_ele.type.replace("(", " ").replace(")", " ")
                                        try:
                                            range_min = float(temp_string.split("range")[1].split("to")[0].strip())
                                        except ValueError:
                                            range_min = default_min
                                        try:
                                            range_max = float(temp_string.split("to")[1].strip())
                                        except ValueError:
                                            range_max = default_max
                                    value_type = "float" if type_name == "real" else "int"
                                    gen_ele.value = self.__get_generic_value(gen_ele.name, range_min, range_max, value_type)
                                    break

                        else:
                            gen_ele.value = "TODO" # Add the word TODO to the hdl so it throws an error if not filled

                        # Add the generic to the dictionary
                        myDict.add_param(gen_ele)

                    # Check if the line is the last one
                    if line is None or ");" == line:
                        generic_running = False
                        continue

                elif port_running == True:
                    # Check if the line is not empty
                    if line and line != "" and line != ");":
                        port_ele = hdlport()
                        port_match = re.match(r"^\s*(\w+)\s*:\s*(in|out|inout)\s*([^;]+);?", line, re.IGNORECASE)
                        if port_match:
                            port_ele.name = port_match.group(1).strip()
                            port_ele.direction = port_match.group(2).strip()
                            port_ele.type = port_match.group(3).strip()

                        myDict.add_port(port_ele)

                    # Check if the line is the last one
                    if line is None or ");" == line:
                        port_running = False
                        continue

        # Return the dictionary
        return myDict
    

    def __remove_comment(self, line: str) -> str:
        """Remove comments from line
        
        :param line: Line to remove comments from
        :type line: str
        :return: Line without comments
        :rtype: str
        """
        if line is None:
            return ""
        
        line = re.sub(r"\t| {2,}", " ", line.split("--")[0]).strip()
        return line
    
    def __get_generic_value(self, name: str, range_min, range_max, value_type: str):
        """Get value for generic

        :param name: Name of the generic
        :type name: str
        :param range_min: Minimum value of the generic
        :type range_min: int / float
        :param range_max: Maximum value of the generic
        :type range_max: int / float
        :param value_type: Type of the value
        :type value_type: str
        :return: Value of the generic
        :rtype: str
        """
        val_provided = False
        while not val_provided:
            try:
                if value_type == "int":
                    new_value = int(input(f"Enter value for generic {name} in range from {range_min} to {range_max}: "))
                elif value_type == "float":
                    new_value = float(input(f"Enter value for generic {name} in range from {range_min} to {range_max}: "))
                if range_min <= new_value <= range_max:
                    val_provided = True
                    value = str(new_value) if value_type == "int" else f"{new_value:.38f}"
            except ValueError:
                pass
        return value
