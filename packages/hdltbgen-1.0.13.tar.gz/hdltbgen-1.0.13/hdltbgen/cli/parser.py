import argparse
from importlib.metadata import *

def generate_parser(): 
    """Generates a parser for the CLI application.

    Returns:
        ArgumentParser: A parser for the CLI application
    """    
    # Base parser
    parser = argparse.ArgumentParser(prog=metadata('hdltbgen')['Name'], description=metadata('hdltbgen')['Summary'], formatter_class=argparse.ArgumentDefaultsHelpFormatter)    

    # Testbench flow
    parser.add_argument('-f', '--file', help='Name of the VHDL file', type=str, action='store', required=True)    
    parser.add_argument('-t', '--type', help='Type of testbench (vhdl, csv, excel) (Multiple types can be provided)', type=str, action='append', required=True)
    parser.add_argument('-o', '--output', help='Output folder (Default folder of input file)', type=str, action='store', required=False)
    parser.add_argument('-c', '--clock', help='Name of the clock (Multiple clocks can be provided)', type=str, action='append', required=False)
    parser.add_argument('-rn', '--reset-negative', help='Negative reset (Multiple resets can be provided)', type=str, action='append', required=False)
    parser.add_argument('-rp', '--reset-positive', help='Positive reset (Multiple resets can be provided)', type=str, action='append', required=False)   
    parser.add_argument('-v', '--vunit', help='Generate VUnit testbench', action='store_true', required=False)
    parser.add_argument('-s', '--simfile', help='Generate separate sim-top-file', action='store_true', required=False)
    parser.add_argument('-a', '--ask', help='Ask for values of generics/parameters', action='store_true', required=False)

    return parser
