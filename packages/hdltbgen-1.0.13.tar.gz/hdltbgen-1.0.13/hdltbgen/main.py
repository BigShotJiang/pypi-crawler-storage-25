"""Run hdltbgen from command line with arguments.
"""
import sys
from pathlib import Path
from hdltbgen.cli.parser import generate_parser
from hdltbgen.parser.vhdl import Parser_VHDL
from hdltbgen.generator.excel import Generator_Excel
from hdltbgen.generator.vhdl import Generator_VHDL
from hdltbgen.generator.csv import Generator_CSV

__all__ = ['main']

def from_argv(argv):
    """
    Main function that parses arguments and runs the command.

    Args:
        None

    Returns:
        None
    """
    # parse arguments
    parser = generate_parser()
    args = parser.parse_args(argv)

    #print(args)

    # Get the arguments
    clock = getattr(args, 'clock', [])
    resetn = getattr(args, 'reset_negative', [])
    resetp = getattr(args, 'reset_positive', [])
    file = getattr(args, 'file', "")
    generator = getattr(args, 'type', "")
    output = getattr(args, 'output', str(Path(file).parent))
    vunit = getattr(args, 'vunit', False)
    simfile = getattr(args, 'simfile', False)
    ask = getattr(args, 'ask', False)

    if not output:
        output = Path(file).parent
    else:
        output = Path(output)

    # Check if file exists
    filePath = Path(file)
    if not filePath.exists():
        raise FileNotFoundError(f"File {filePath} not found.")
    
    # Get file type
    fileType = filePath.suffix[1:]
    if fileType == "vhd":
        parser = Parser_VHDL(filePath, ask)
        myDict = parser.parse()
        if clock:
            myDict.add_clock(clock)
        if resetn:
            myDict.add_resetn(resetn)
        if resetp:
            myDict.add_resetp(resetp)
        myDict.auto_add_signals()
        
    else:
        raise ValueError(f"File {filePath} type is not supported (yet).")
    
    # Generate testbench
    for gen in generator:
        if gen == "vhdl":
            myGen = Generator_VHDL(output.joinpath(filePath.stem + "_tb.vhd"), myDict, vunit, simfile)
            myGen.generate()
        elif gen == "csv":
            myGen = Generator_CSV(output.joinpath(filePath.stem + "_tb.csv"), myDict, vunit)
            myGen.generate()
        elif gen == "excel":
            myGen = Generator_Excel(output.joinpath(filePath.stem + "_tb.xlsm"), myDict, vunit)
            myGen.generate()
        else:
            raise ValueError(f"Generator {gen} not supported.")
        
def main():
    """
    Main entry function for CLI that parses arguments and runs the command.
    """
    from_argv(sys.argv[1:])

if __name__ == '__main__':
    from_argv(sys.argv[1:])
