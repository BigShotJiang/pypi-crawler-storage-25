# hdltbgen

HDL Testbench Generator – parses a VHDL entity and generates testbench artifacts.

## Installation

```bash
pip install hdltbgen
```

Excel support: `pip install "hdltbgen[excel]"`


## Functionality

- Parses a `.vhd` entity interface (generics and ports)
- Generates testbench artifacts: `vhdl`, `csv`, `excel`
- Supports automatic clock/reset detection (or explicit CLI override)
- Can generate VUnit-compatible output and an optional sim wrapper
- Supports interactive generic value entry via `--ask`
- Can generate multiple artifact types in one run by repeating `-t`

## Usage

```bash
hdltbgen -f my_design.vhd -t vhdl
```

| Argument | Short | Description |
|---|---|---|
| `--file` | `-f` | VHDL input file (required) |
| `--type` | `-t` | Output type: `vhdl`, `csv`, `excel` (repeatable, required) |
| `--output` | `-o` | Output directory (default: input file directory) |
| `--clock` | `-c` | Clock signal name(s) |
| `--reset-negative` | `-rn` | Active-low reset name(s) |
| `--reset-positive` | `-rp` | Active-high reset name(s) |
| `--vunit` | `-v` | VUnit-compatible testbench |
| `--simfile` | `-s` | Generate separate simulation wrapper |
| `--ask` | `-a` | Prompt for generic values |
