########
hdltbgen
########

hdltbgen is a Python package for automated generation of HDL testbench artifacts
from a VHDL description.

.. toctree::
   :maxdepth: 1
   :caption: Overview

   overview/introduction
   overview/usage
   overview/limitations

.. toctree::
   :maxdepth: 1
   :caption: Advanced Topics

   advanced/workflow
   advanced/generators

.. toctree::
   :maxdepth: 1
   :caption: Source Code

   code/api
   code/cli
