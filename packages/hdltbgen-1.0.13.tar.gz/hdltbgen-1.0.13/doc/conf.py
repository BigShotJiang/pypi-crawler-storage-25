"""Sphinx configuration for hdltbgen documentation."""

from datetime import date
import importlib.metadata as metadata
import os
import sys

sys.path.insert(0, os.path.abspath(".."))


project = "hdltbgen"
copyright = f"{date.today().year}, XiBIF. Licensed under the CERN-OHL-P v2.0."

author = metadata.metadata("hdltbgen").get("Author-email", "")
release = metadata.version("hdltbgen")
version = release


# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = []

templates_path = ['_templates']
exclude_patterns = []

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output
# html_theme = 'sphinx_material'
html_theme = 'sphinx_rtd_theme'
# html_static_path = ['_static/css/']
# html_css_files = ["css/custom.css"]
# html_style = 'css/custom.css'
smart_quotes = True

extensions = [
    'sphinx_toolbox.collapse',
    'sphinx.ext.autodoc',
    'sphinx.ext.napoleon',
    'sphinx.ext.autosummary',
    'sphinxcontrib.mermaid',
    'sphinx_simplepdf',
    'sphinxcontrib.wavedrom',
    'sphinxarg.ext'
    ]

autodoc_mock_imports = ['numpy']
add_module_names = False
render_using_wavedrompy = True
napoleon_use_rtype = False

html_theme_options = {
    # Visible levels of the global TOC; -1 means unlimited
    'globaltoc_collapse': True,
    'globaltoc_includehidden': False
}

html_sidebars = {
    "**": ["globaltoc.html", "searchbox.html"]
}
version_dropdown = True
simplepdf_vars = {
    'primary': '#8C1A5F',
    'primary-opaque': 'rgba(140, 26, 95, 1)',
    'secondary': '#FFFF00',
    'cover': '#ffffff',
    'white': '#ffffff',
   #  'links': 'FA2323',
   #  'cover-bg': 'url(cover-bg.jpg) no-repeat center',
    'cover-overlay': 'rgba(140, 26, 95, 0.6)',
    'top-left-content': 'counter(page)',
    'bottom-center-content': '"hdltbgen Reference Manual"',
}
simplepdf_file_name = "hdltbgen_reference_manual.pdf"
