.. rst-class:: break_before

Command-Line Interface
======================


.. argparse::
   :module: hdltbgen.cli.parser
   :func: generate_parser
   :prog: hdltbgen