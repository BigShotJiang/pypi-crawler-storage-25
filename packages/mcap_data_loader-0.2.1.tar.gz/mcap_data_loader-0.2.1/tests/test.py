import json

json.loads("123")