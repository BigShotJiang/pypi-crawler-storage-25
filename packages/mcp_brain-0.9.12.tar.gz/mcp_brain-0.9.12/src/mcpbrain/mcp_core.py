"""MCP Core — orchestrates multi-agent cognitive processing (async)."""

import os
import json
import time
import uuid
import threading
import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, AsyncIterator, List

from .minimax_client import MiniMaxClient, MiniMaxError
from .agents import CreatorAgent, CriticAgent, AnalystAgent
from .memory import WorkingMemory, LearnedMemory, SessionIndex, PatternExtractor, _fingerprint_task, _jaccard
from .tools import TOOL_REGISTRY
from .logging_config import log, new_correlation_id, get_correlation_id

import re

DEFAULT_CONFIG_PATH = Path("~/.mcp/config.json").expanduser()
DEFAULT_LOG_DIR = Path("~/.mcp/logs").expanduser()
DEFAULT_MEMORY_DIR = Path("~/.mcp/memory").expanduser()
DEFAULT_RESULTS_DIR = Path("~/.mcp/results").expanduser()
DEFAULT_LEARNED_DIR = Path("~/.mcp/learned").expanduser()

# ── Pipeline timeouts ─────────────────────────────────────────────────────────
DEFAULT_STEP_TIMEOUT = 120  # seconds per step
DEFAULT_TOTAL_TIMEOUT = 300  # seconds total for COMPLEX pipeline
STEP_TIMEOUTS = {
    1: 60,   # Analyst
    2: 120,  # Creator (first draft)
    3: 60,   # Critic (first evaluation)
    4: 120,  # Creator (improvement)
    5: 60,   # Critic (final evaluation)
}


# ── Code file pre-loader ─────────────────────────────────────────────────────

_CODE_PATH_PATTERN = re.compile(
    r'(?:^|\s)((?:/~|/|./|\.\./)(?:[^\s\'"<>)]+(?:\.py|\.js|\.ts|\.jsx|\.tsx|\.json|\.yaml|\.yml|\.md|\.txt|\.sh|\.toml|\.cfg|\.ini|\.conf|\.html|\.css|\.sql|\.proto))+)',
    re.MULTILINE,
)

# Also match bare filenames like "mcp_core.py" or "agents.py" referenced naturally
_BARE_CODE_FILE_PATTERN = re.compile(
    r'(?:^|\s)([a-zA-Z_][a-zA-Z0-9_-]*\.(?:py|js|ts|jsx|tsx|json|yaml|yml|md|txt|sh|toml|cfg|ini|conf|html|css|sql|proto))',
    re.MULTILINE,
)


def _extract_file_paths(task: str) -> List[str]:
    """Return list of file/directory paths found in the task string."""
    paths: List[str] = []
    for m in _CODE_PATH_PATTERN.finditer(task):
        p = m.group(1).rstrip(')').rstrip('>')
        if p not in paths:
            paths.append(p)
    # Also match bare filenames like "mcp_core.py" or "agents.py"
    for m in _BARE_CODE_FILE_PATTERN.finditer(task):
        p = m.group(1)
        if p not in paths:
            paths.append(p)
    return paths


def _read_code_files(paths: List[str], max_lines_per_file: int = 1500, max_total_chars: int = 50000) -> str:
    """Read the given files and return a formatted code dump.

    Silently skips files that don't exist or can't be read.
    Caps total output at max_total_chars, distributing budget evenly across
    all discovered files so no single large file can starve the rest.
    Bare filenames (no slash) are resolved relative to the package source directory.
    """
    if not paths:
        return ""

    # Resolve bare filenames relative to the package source tree
    source_root = Path(__file__).parent

    # First pass: resolve paths and collect file metadata (no reading yet)
    resolved: List[Path] = []
    for raw_path in paths:
        p = Path(raw_path).expanduser()
        if not p.exists() and "/" not in raw_path and not raw_path.startswith("."):
            candidate = source_root / p
            if candidate.exists():
                p = candidate
        if p.exists() and not p.is_dir():
            resolved.append(p)

    if not resolved:
        return ""

    # Pre-calculate per-file char budget so all files get fair share
    HEADER_CHARS = 65  # "====...\nFILE: ...\n====...\n" per file
    footer_chars = 50  # truncated-line notice + blank line
    per_file_budget = max(500, (max_total_chars - len(resolved) * (HEADER_CHARS + footer_chars)) // len(resolved))

    out_lines: List[str] = []
    for p in resolved:
        try:
            with open(p) as f:
                lines = f.readlines()
            total = len(lines)

            # Read only up to per_file_budget (first N lines that fit)
            snippet_chars = 0
            snippet_lines = []
            for line in lines[:max_lines_per_file]:
                if snippet_chars + len(line) > per_file_budget:
                    break
                snippet_lines.append(line)
                snippet_chars += len(line)

            snippet = "".join(snippet_lines)
            out_lines.append(f"{'=' * 60}")
            out_lines.append(f"FILE: {p}")
            out_lines.append(f"{'=' * 60}")
            out_lines.append(snippet)
            if total > len(snippet_lines):
                out_lines.append(f"[... {total - len(snippet_lines)} more lines truncated ...]")
            out_lines.append("")
        except Exception:
            pass

    return "\n".join(out_lines)


def _build_code_context(task: str) -> str:
    """Build a CODE REFERENCE section from file paths found in the task.

    Returns an empty string if no recognizable code file paths are found.
    """
    paths = _extract_file_paths(task)
    if not paths:
        return ""
    content = _read_code_files(paths)
    if not content:
        return ""
    return f"""

{'=' * 60}
CODE REFERENCE — files read by MCP-brain before analysis
DO NOT describe any code pattern, class, or function you have not seen here.
{'=' * 60}
{content}
{'=' * 60}
END CODE REFERENCE
{'=' * 60}

IMPORTANT: You MUST base your analysis ONLY on the code shown above.
If a file you need to reference is not shown above, say so explicitly.
"""

# ── Helper utilities ────────────────────────────────────────────────────

def _infer_skill_args(skill_name: str, func_def: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """Infer arguments for a skill-related function call."""
    params = func_def.get("parameters", func_def.get("function", {}).get("parameters", {}))
    properties = params.get("properties", {})

    for pname, pschema in properties.items():
        if "skill" in pname.lower() or "name" in pname.lower():
            return {pname: skill_name}

    for pname, pschema in properties.items():
        if pschema.get("type", "string") == "string":
            return {pname: skill_name}

    return None


def _normalize_functions_to_tools(functions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert Hermes functions list to OpenAI tools format."""
    tools = []
    for f in functions:
        if f.get("type") == "function" and "function" in f:
            tools.append(f)
        elif "name" in f:
            tools.append({
                "type": "function",
                "function": {
                    "name": f["name"],
                    "description": f.get("description", ""),
                    "parameters": f.get("parameters", {}),
                }
            })
    return tools if tools else None


class MCP:
    """Multi-agent Cognitive Processing engine (async)."""

    _results: Dict[str, Optional[Dict[str, Any]]] = {}
    _results_lock = threading.Lock()

    def __init__(self, config_path: Optional[str] = None, skip_api_key_check: bool = False):
        self.config_path = Path(config_path or DEFAULT_CONFIG_PATH)
        self.log_dir = Path(DEFAULT_LOG_DIR)
        self.memory_dir = Path(DEFAULT_MEMORY_DIR)
        self.results_dir = Path(DEFAULT_RESULTS_DIR)
        self.learned_dir = Path(DEFAULT_LEARNED_DIR)

        self.config = self._load_config()
        self.session_id = str(uuid.uuid4())[:16]
        self.llm = None
        self.agents = {}

        for d in (self.log_dir, self.memory_dir, self.results_dir, self.learned_dir):
            d.mkdir(parents=True, exist_ok=True)

        api_key = self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")
        if not api_key and not skip_api_key_check:
            raise ValueError("No API key configured. Run: mcp setup")

        if api_key:
            self.llm = MiniMaxClient(api_key)
            model = self.config.get("model", "MiniMax-M2.7")
            self.agents = {
                "creator": CreatorAgent(api_key, model=model),
                "critic": CriticAgent(api_key, model=model),
                "analyst": AnalystAgent(api_key, model=model),
            }

        self.memory = WorkingMemory(storage_path=str(self.memory_dir))
        self.learned = LearnedMemory(storage_path=str(self.learned_dir))
        self.session_index = SessionIndex(storage_path=str(self.learned_dir))

    def _load_config(self) -> Dict[str, Any]:
        if self.config_path.exists():
            with open(self.config_path) as f:
                return json.load(f)
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        default = {
            "api_key": "",
            "model": "MiniMax-M2.7",
            "max_tokens": 2000,
            "temperature": 0.7,
        }
        with open(self.config_path, "w") as f:
            json.dump(default, f, indent=2)
        return default

    def is_setup(self) -> bool:
        return bool(self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY"))

    def setup(self, api_key: str, model: str = "MiniMax-M2.7") -> bool:
        self.config["api_key"] = api_key
        self.config["model"] = model
        with open(self.config_path, "w") as f:
            json.dump(self.config, f, indent=2)
        self.llm = MiniMaxClient(api_key)
        self.agents = {
            "creator": CreatorAgent(api_key, model=model),
            "critic": CriticAgent(api_key, model=model),
            "analyst": AnalystAgent(api_key, model=model),
        }
        self.learned = LearnedMemory(storage_path=str(self.learned_dir))
        self.session_index = SessionIndex(storage_path=str(self.learned_dir))
        return True

    def _find_result_on_disk(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Scan session logs on disk for a result by session_id. Returns latest match."""
        try:
            # Collect all matching files, pick the most recently modified
            matches = []
            for log_file in self.log_dir.glob("session_*.json"):
                try:
                    with open(log_file) as f:
                        data = json.load(f)
                    if data.get("session_id") == session_id:
                        matches.append((log_file.stat().st_mtime, data))
                except (OSError, json.JSONDecodeError):
                    continue
            if matches:
                matches.sort(key=lambda x: x[0], reverse=True)
                return matches[0][1].get("result", matches[0][1])
        except OSError:
            pass
        return None

    def report_outcome(
        self,
        session_id: str,
        outcome: str,
        rating: Optional[int] = None,
        notes: str = "",
    ) -> Dict[str, Any]:
        """Record the outcome of a session (success | partial | failed).

        Call this after process_task() returns to close the feedback loop.
        The outcome is stored in patterns.json and the session is indexed
        for future similarity searches.
        """
        # Step 1: get result from class dict (fast, no I/O)
        with self.__class__._results_lock:
            result = self.__class__._results.get(session_id)

        # Step 2: if not in class dict, check disk (I/O — no lock held)
        if result is None:
            result = self._find_result_on_disk(session_id)

        if result is None:
            return {"success": False, "error": f"Session {session_id} not found"}

        # Step 3: build updated result (copy to avoid holding lock across I/O)
        updated = dict(result)
        updated["outcome"] = outcome
        updated["rating"] = rating
        updated["feedback_notes"] = notes
        updated["feedback_timestamp"] = time.time()

        # Step 4: write back to class dict atomically
        with self.__class__._results_lock:
            self.__class__._results[session_id] = updated
        self._save_session_log(updated.get("task", ""), updated)
        self.learned.record_outcome(
            task=updated.get("task", ""),
            complexity=updated.get("complexity", "UNKNOWN"),
            solution=updated.get("solution", ""),
            outcome=outcome,
            rating=rating,
        )
        self.session_index.add(
            session_id=session_id,
            task=result.get("task", ""),
            complexity=result.get("complexity", "UNKNOWN"),
            outcome=outcome,
        )
        # ── record code-change pattern ──────────────────────────────────────────
        try:
            code_pattern = PatternExtractor.extract(
                session_id=session_id,
                task=updated.get("task", ""),
                solution=updated.get("solution", ""),
                complexity=updated.get("complexity", "UNKNOWN"),
                outcome=outcome,
                rating=rating,
            )
            if code_pattern:
                pattern_result = self.learned.record_pattern(code_pattern)
                if pattern_result.get("success"):
                    log.info("mcp_pattern_extracted", pattern_id=session_id,
                             change_type=code_pattern.change_type,
                             files=code_pattern.files_changed)
        except Exception as e:
            log.error("pattern_extraction_failed", error=str(e), session_id=session_id)

        log.info("mcp_outcome_recorded", session_id=session_id, outcome=outcome, rating=rating)
        return {"success": True, "session_id": session_id, "outcome": outcome}

    def _auto_record_pattern(self, session_id: str) -> None:
        """Extract and record a code-change pattern from a completed session (no feedback needed).

        Called automatically at pipeline completion for all successful sessions.
        """
        try:
            with self.__class__._results_lock:
                result = self.__class__._results.get(session_id)
            if result is None:
                result = self._find_result_on_disk(session_id)
            if result is None:
                return
            outcome = result.get("outcome", "success")
            if outcome not in ("success", "partial"):
                return
            code_pattern = PatternExtractor.extract(
                session_id=session_id,
                task=result.get("task", ""),
                solution=result.get("solution", "") or result.get("analysis", ""),
                complexity=result.get("complexity", "UNKNOWN"),
                outcome=outcome,
                rating=result.get("rating"),
            )
            if code_pattern:
                pr = self.learned.record_pattern(code_pattern)
                if pr.get("success"):
                    log.info("mcp_pattern_auto_extracted",
                             pattern_id=session_id,
                             change_type=code_pattern.change_type,
                             files=code_pattern.files_changed)
        except Exception as e:
            log.error("auto_pattern_extraction_failed", error=str(e), session_id=session_id)



    @classmethod
    def get_result(cls, session_id: str) -> Optional[Dict[str, Any]]:
        with cls._results_lock:
            return cls._results.get(session_id)

    def _classify_task(self, task: str) -> Dict[str, Any]:
        """Pre-classify task using heuristics + learned historical data.

        Returns a dict with keys: complexity (str), confidence (float 0-1), hint (str).
        If confidence is high, complexity_detected is seeded early and Analyst can be skipped.
        """
        task_lower = task.lower().strip()

        # Heuristic signals
        simple_prefixes = (
            "what is", "what's", "who is", "who's", "when did", "when is",
            "where is", "which is", "define ", "how do ", "how does ",
            "how did ", "how many", "how much", "is it", "are they",
            "does it", "can i", "should i", "would you", "could you",
            "what year", "what date", "what time", "translate ",
            "convert ", "calculate ", "2+", "3+", "1+", "5+", "10+",
            "1.", "2.", "3.", "4.", "5.", "who wrote", "list ",
            "name ", "tell me", "show me", "give me",
        )
        is_question = "?" in task
        is_short = len(task.split()) <= 15
        has_file_refs = bool(_extract_file_paths(task))
        is_multi_step = any(kw in task_lower for kw in (
            "design", "implement", "build", "create", "write code", "audit",
            "review", "analyze", "compare", "architect", "plan", "improve",
            "fix", "debug", "refactor", "optimize", "rewrite",
            "investigate", "diagnose", "trace", "profile"))

        # Learned data lookup
        learned_complexity = None
        learned_confidence = 0.0
        similar = self.session_index.find_similar(task, max_results=5)
        if similar:
            now = time.time()
            weighted = {}
            for s in similar:
                sim = s.get("similarity", 0)
                age = now - s.get("timestamp", now)
                recency = max(0, 1 - age / (30 * 86400))
                outcome = s.get("outcome", "unknown")
                bonus = 0.2 if outcome == "success" else (-0.1 if outcome == "failure" else 0)
                score = sim * 0.6 + recency * 0.4 + bonus
                comp = s.get("complexity", "UNKNOWN")
                weighted[comp] = weighted.get(comp, 0) + score
            if weighted:
                learned_complexity = max(weighted, key=weighted.get)
                total = sum(weighted.values())
                learned_confidence = min(1.0, weighted[learned_complexity] / (total * 0.6))

        # ── Code-change pattern lookup ─────────────────────────────────────────
        code_pattern_hint = ""
        code_pattern_confidence = 0.0
        similar_patterns = self.learned.find_code_patterns(task, max_results=3)
        if similar_patterns:
            top = similar_patterns[0]
            task_kw_str = _fingerprint_task(task)
            task_kw_set = set(task_kw_str.split())
            stored_kw = top.get("task_keywords", "").split()
            score = _jaccard(task_kw_str, top.get("task_keywords", ""))
            keyword_overlap = len(task_kw_set & set(stored_kw))
            if score >= 0.35 and keyword_overlap >= 2:
                ct = top.get("change_type", "")
                snippet = top.get("code_snippet", "")[:80]
                files = ", ".join(f.split("/")[-1] for f in (top.get("files_changed", [])[:3]))
                code_pattern_hint = (
                    f"[CODE PATTERN: prior {ct} on {files} — "
                    f"snippet: {snippet}...]\n"
                )
                code_pattern_confidence = min(0.9, score * 1.5)
                log.info("mcp_pattern_matched", pattern_id=top.get("id"),
                         change_type=ct, similarity=round(score, 3))

        # Combine signals
        # Fix 2: allow file-ref queries into SIMPLE (only exclude multi-step writes/edits)
        if is_question and is_short and not is_multi_step:
            base_conf = 0.85 if (learned_confidence >= 0.5 and learned_complexity == "SIMPLE") else (0.6 if (learned_confidence >= 0.3 and learned_complexity == "SIMPLE") else 0.7)
            confidence = max(base_conf, code_pattern_confidence)
            hint_suffix = "[PRIOR COMPLEXITY: SIMPLE - high-confidence similar past sessions. Answer directly and concisely.]\n" if (learned_confidence >= 0.5 and learned_complexity == "SIMPLE") else ("[PRIOR COMPLEXITY: SIMPLE - based on similar past tasks. Answer directly.]\n" if (learned_confidence >= 0.3 and learned_complexity == "SIMPLE") else "")
            hint = hint_suffix if hint_suffix else ("[Intent-based SIMPLE — answer directly.]\n" if code_pattern_confidence >= 0.3 else "")
            return {"complexity": "SIMPLE", "confidence": confidence, "hint": (code_pattern_hint if code_pattern_confidence >= 0.3 else "") + hint}

        if has_file_refs and is_multi_step:
            base_conf = 0.85 if (learned_confidence >= 0.5 and learned_complexity == "COMPLEX") else 0.6
            confidence = max(base_conf, code_pattern_confidence)
            hint_suffix = "[PRIOR COMPLEXITY: COMPLEX - high-confidence similar past sessions. Expect a thorough multi-step analysis.]\n" if (learned_confidence >= 0.5 and learned_complexity == "COMPLEX") else ""
            hint = hint_suffix if hint_suffix else ("[CODE PATTERN-based COMPLEX.]\n" if code_pattern_confidence >= 0.3 else "")
            return {"complexity": "COMPLEX", "confidence": confidence, "hint": (code_pattern_hint if code_pattern_confidence >= 0.3 else "") + hint}

        # Fix 7: either file refs OR multi-step alone → MODERATE
        if has_file_refs or is_multi_step:
            base_conf = 0.55
            confidence = max(base_conf, code_pattern_confidence)
            return {"complexity": "MODERATE", "confidence": confidence,
                    "hint": (code_pattern_hint if code_pattern_confidence >= 0.3 else "")}

        if learned_confidence >= 0.4:
            # Fix 6: trust strong learned signals (>= 0.6) directly without penalty
            if learned_confidence >= 0.6:
                confidence = learned_confidence
            else:
                confidence = max(learned_confidence * 0.7, code_pattern_confidence)
            hint = "[PRIOR COMPLEXITY: " + learned_complexity + " - similar past sessions. Apply the same approach that worked before.]\n"
            return {"complexity": learned_complexity, "confidence": confidence,
                    "hint": (code_pattern_hint if code_pattern_confidence >= 0.3 else "") + hint}

        if code_pattern_confidence > 0:
            return {"complexity": "MODERATE", "confidence": code_pattern_confidence,
                    "hint": (code_pattern_hint if code_pattern_confidence >= 0.3 else "")}

        # Fix 4: UNKNOWN fallback — seed SIMPLE for short intent-based tasks
        if len(task.split()) <= 10 and "?" not in task:
            intent_words = ("list", "name", "show", "give", "tell", "display", "what", "where")
            if any(w in task_lower for w in intent_words):
                return {"complexity": "SIMPLE", "confidence": 0.5,
                        "hint": "[Intent-based short task — answer directly.]\n"}

        return {"complexity": "UNKNOWN", "confidence": 0.0, "hint": ""}

    # ── Async cognitive pipeline ─────────────────────────────────────────────

    async def process_task_stream_async(
        self,
        task: str,
        functions: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        """Run the cognitive pipeline with streaming (async).

        Yields step events:
            {"type": "start", "step": 1, "agent": "analyst", "task": "..."}
            {"type": "token", "agent": "analyst", "content": "..."}
            {"type": "step_done", "step": 1, "agent": "analyst", "response": "..."}
            {"type": "done", "session_id": "...", "duration_seconds": ...}
        """
        if not self.is_setup():
            yield {"type": "error", "message": "MCP not set up. Run: mcp setup"}
            return

        tools = None
        if functions:
            tools = _normalize_functions_to_tools(functions)

        # Always include internal tools (read_file, terminal, etc.) so agents
        # can read source files and execute commands — they complement, not replace,
        # any caller-supplied functions
        internal_schemas = _normalize_functions_to_tools(TOOL_REGISTRY.list())
        if tools:
            # Deduplicate by name — internal tools take priority
            existing_names = {t.get("function", {}).get("name") for t in tools}
            for schema in internal_schemas:
                name = schema.get("function", {}).get("name")
                if name not in existing_names:
                    tools.append(schema)
        else:
            tools = internal_schemas

        cid = new_correlation_id()
        start_time = time.time()
        step_num = 0

        log.info("mcp_pipeline_start", task=task[:100], session_id=self.session_id, correlation_id=cid)

        yield {
            "type": "start",
            "task": task,
            "session_id": self.session_id,
        }

        # ── Step 1: Analyst (always runs) ─────────────────────────────────────
        step_num = 1
        agent_name = "analyst"
        agent = self.agents[agent_name]
        accumulated = ""
        analysis_response = ""  # pre-init to prevent NameError if loop exits early
        complexity_detected = None

        # Pre-classify using heuristics + learned history
        classification = self._classify_task(task)
        if classification["confidence"] >= 0.85:
            complexity_detected = classification["complexity"]
            log.info("mcp_complexity_seeded", complexity=complexity_detected,
                     confidence=classification["confidence"], session_id=self.session_id)

        # Inject prior-complexity hint if classification had confidence
        classification_hint = classification.get("hint", "")

        # Pre-load code files mentioned in the task so agents can't hallucinate
        code_context = _build_code_context(task)
        referenced_paths = _extract_file_paths(task)

        # If task references code files, inject mandatory exploration instruction
        # for ALL agents (Analyst, Creator, Critic) so none hallucinate about code
        analyst_exploration_note = ""
        if referenced_paths:
            paths_str = ", ".join(f"'{p}'" for p in referenced_paths)
            analyst_exploration_note = f"""

{'='*60}
EXPLORATION MANDATORY — You MUST read these files before generating any analysis:
{paths_str}

Call read_file for EACH file above right now, before you produce any analysis.
Your output should start by citing specific lines from the files you have read.
{'='*60}

"""

        # Inject relevant prior session patterns for learned context
        learned_context = ""
        similar = self.session_index.find_similar(task, max_results=2)
        patterns = self.learned.get_relevant_patterns(task, max_results=3)
        learned_lines = []
        if similar:
            learned_lines.append("[PRIOR SESSIONS — similar tasks and their outcomes]")
            for s in similar:
                learned_lines.append(
                    f"  - Similarity {s.get('similarity')}: complexity={s.get('complexity')}, "
                    f"outcome={s.get('outcome', 'unknown')}, task: {s.get('task_sample', '')[:100]}"
                )
        if patterns:
            learned_lines.append("[PRIOR PATTERNS]")
            for p in patterns:
                learned_lines.append(
                    f"  - outcome={p.get('outcome')} (rating={p.get('rating')}): "
                    f"task: {p.get('task_sample', '')[:100]}"
                )
        if learned_lines:
            learned_context = "\n" + "\n".join(learned_lines)

        yield {"type": "step_start", "step": step_num, "agent": agent_name}

        async for event in agent.process_async(task, code_context + analyst_exploration_note + classification_hint + learned_context, tools=tools):
            if event["type"] == "start":
                pass
            elif event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
                if complexity_detected is None:
                    for comp in ("SIMPLE", "MODERATE", "COMPLEX"):
                        marker = f"[COMPLEXITY: {comp}]"
                        if marker in accumulated:
                            complexity_detected = comp
                            yield {"type": "complexity_detected", "complexity": comp}
                            log.info("mcp_complexity_detected", complexity=comp, session_id=self.session_id)
                            break
            elif event["type"] == "tool_call":
                # Agent now handles tool execution internally;
                # tool_call events should not reach here.
                pass
            elif event["type"] == "done":
                analysis_response = event["response"]
                if complexity_detected is None:
                    for comp in ("SIMPLE", "MODERATE", "COMPLEX"):
                        if f"[COMPLEXITY: {comp}]" in analysis_response:
                            complexity_detected = comp
                            break
                if complexity_detected is None:
                    complexity_detected = "COMPLEX"

                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": analysis_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": analysis_response}

        # ── Tier routing ───────────────────────────────────────────────────────
        if complexity_detected == "SIMPLE":
            duration = time.time() - start_time
            result = {
                "task": task,
                "session_id": self.session_id,
                "duration_seconds": round(duration, 2),
                "complexity": complexity_detected,
                "analysis": analysis_response or "(empty)",
                "solution": analysis_response or "(empty)",
                "evaluation": "SIMPLE task — answered directly by Analyst.",
            }
            with self.__class__._results_lock:
                self.__class__._results[self.session_id] = result
            self._save_session_log(task, result)
            self.session_index.add(self.session_id, task, "SIMPLE")
            self._auto_record_pattern(self.session_id)
            log.info("mcp_pipeline_done", complexity="SIMPLE", duration_s=round(duration, 2), session_id=self.session_id)
            yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}
            return

        elif complexity_detected == "MODERATE":
            step_num = 2
            agent_name = "creator"
            agent = self.agents[agent_name]
            accumulated = ""
            creation_response = ""  # pre-init

            yield {"type": "step_start", "step": step_num, "agent": agent_name}
            async for event in agent.process_async(task, code_context + analyst_exploration_note + self.memory.get_context(), tools=tools):
                if event["type"] == "token":
                    accumulated += event["content"]
                    yield {"type": "token", "agent": agent_name, "content": event["content"]}
                elif event["type"] == "done":
                    creation_response = event["response"]
                    self.memory.add({
                        "agent_id": agent_name,
                        "role": agent.role,
                        "task": task,
                        "response": creation_response,
                        "timestamp": time.time(),
                    })
                    yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": creation_response}

            duration = time.time() - start_time
            result = {
                "task": task,
                "session_id": self.session_id,
                "duration_seconds": round(duration, 2),
                "complexity": complexity_detected,
                "analysis": analysis_response or "(empty)",
                "solution": creation_response or "(empty)",
                "evaluation": "MODERATE task — resolved by Creator without critique rounds.",
            }
            with self.__class__._results_lock:
                self.__class__._results[self.session_id] = result
            self._save_session_log(task, result)
            self.session_index.add(self.session_id, task, "MODERATE")
            self._auto_record_pattern(self.session_id)
            log.info("mcp_pipeline_done", complexity="MODERATE", duration_s=round(duration, 2), session_id=self.session_id)
            yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}
            return

        # ── COMPLEX: full 5-step pipeline ──────────────────────────────────────
        # Step 2 — Creator generates first draft
        step_num = 2
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""
        creation_response = ""  # pre-init

        step_timeout = STEP_TIMEOUTS.get(step_num, DEFAULT_STEP_TIMEOUT)
        try:
            async with asyncio.timeout(step_timeout):
                async for event in agent.process_async(task, code_context + analyst_exploration_note + self.memory.get_context(), tools=tools):
                    if event["type"] == "token":
                        accumulated += event["content"]
                        yield {"type": "token", "agent": agent_name, "content": event["content"]}
                    elif event["type"] == "done":
                        creation_response = event["response"]
                        self.memory.add({
                            "agent_id": agent_name,
                            "role": agent.role,
                            "task": task,
                            "response": creation_response,
                            "timestamp": time.time(),
                        })
                        yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": creation_response}
        except asyncio.TimeoutError:
            log.error("mcp_step_timeout", step=step_num, agent=agent_name, timeout_s=step_timeout, session_id=self.session_id)
            yield {"type": "error", "message": f"Step {step_num} ({agent_name}) timed out after {step_timeout}s"}
            return

        # Step 3 — Critic evaluates
        step_num = 3
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""
        critique_response = ""  # pre-init

        step_timeout = STEP_TIMEOUTS.get(step_num, DEFAULT_STEP_TIMEOUT)
        try:
            async with asyncio.timeout(step_timeout):
                yield {"type": "step_start", "step": step_num, "agent": agent_name}
                async for event in agent.process_async(task, code_context + analyst_exploration_note + self.memory.get_context(), tools=tools):
                    if event["type"] == "token":
                        accumulated += event["content"]
                        yield {"type": "token", "agent": agent_name, "content": event["content"]}
                    elif event["type"] == "done":
                        critique_response = event["response"]
                        self.memory.add({
                            "agent_id": agent_name,
                            "role": agent.role,
                            "task": task,
                            "response": critique_response,
                            "timestamp": time.time(),
                        })
                        yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": critique_response}
        except asyncio.TimeoutError:
            log.error("mcp_step_timeout", step=step_num, agent=agent_name, timeout_s=step_timeout, session_id=self.session_id)
            yield {"type": "error", "message": f"Step {step_num} ({agent_name}) timed out after {step_timeout}s"}
            return

        # Step 4 — Creator improves based on critique
        step_num = 4
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""
        improvement_response = ""  # pre-init

        improve_task = f"Improve your previous solution based on this criticism: {critique_response}"
        improve_context = _build_code_context(improve_task) or code_context

        step_timeout = STEP_TIMEOUTS.get(step_num, DEFAULT_STEP_TIMEOUT)
        try:
            async with asyncio.timeout(step_timeout):
                yield {"type": "step_start", "step": step_num, "agent": agent_name}
                async for event in agent.process_async(improve_task, improve_context + analyst_exploration_note + self.memory.get_context(), tools=tools):
                    if event["type"] == "token":
                        accumulated += event["content"]
                        yield {"type": "token", "agent": agent_name, "content": event["content"]}
                    elif event["type"] == "done":
                        improvement_response = event["response"]
                        self.memory.add({
                            "agent_id": agent_name,
                            "role": agent.role,
                            "task": task,
                            "response": improvement_response,
                            "timestamp": time.time(),
                        })
                        yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": improvement_response}
        except asyncio.TimeoutError:
            log.error("mcp_step_timeout", step=step_num, agent=agent_name, timeout_s=step_timeout, session_id=self.session_id)
            yield {"type": "error", "message": f"Step {step_num} ({agent_name}) timed out after {step_timeout}s"}
            return

        # Step 5 — Critic final evaluation
        step_num = 5
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""
        final_response = ""  # pre-init

        final_task = f"Provide a final evaluation of this improved solution. Rate it and note any remaining issues: {improvement_response}"
        final_context = _build_code_context(final_task) or code_context

        step_timeout = STEP_TIMEOUTS.get(step_num, DEFAULT_STEP_TIMEOUT)
        try:
            async with asyncio.timeout(step_timeout):
                yield {"type": "step_start", "step": step_num, "agent": agent_name}
                async for event in agent.process_async(final_task, final_context + analyst_exploration_note + self.memory.get_context(), tools=tools):
                    if event["type"] == "token":
                        accumulated += event["content"]
                        yield {"type": "token", "agent": agent_name, "content": event["content"]}
                    elif event["type"] == "done":
                        final_response = event["response"]
                        self.memory.add({
                            "agent_id": agent_name,
                            "role": agent.role,
                            "task": task,
                            "response": final_response,
                            "timestamp": time.time(),
                        })
                        yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": final_response}
        except asyncio.TimeoutError:
            log.error("mcp_step_timeout", step=step_num, agent=agent_name, timeout_s=step_timeout, session_id=self.session_id)
            yield {"type": "error", "message": f"Step {step_num} ({agent_name}) timed out after {step_timeout}s"}
            return

        duration = time.time() - start_time
        result = {
            "task": task,
            "session_id": self.session_id,
            "duration_seconds": round(duration, 2),
            "complexity": complexity_detected,
            "analysis": analysis_response or "(empty)",
            "solution": improvement_response or "(empty)",
            "evaluation": final_response or "(empty)",
        }
        with self.__class__._results_lock:
            self.__class__._results[self.session_id] = result
        self._save_session_log(task, result)
        self.session_index.add(self.session_id, task, "COMPLEX")
        self._auto_record_pattern(self.session_id)
        log.info("mcp_pipeline_done", complexity="COMPLEX", duration_s=round(duration, 2), session_id=self.session_id)
        yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}

    # ── Sync wrapper for CLI ─────────────────────────────────────────────────

    def process_task_stream(self, task: str, functions=None, extra_context: str = ""):
        """Sync wrapper — yields events from the async pipeline.

        Uses asyncio.run() in a separate thread to avoid event loop conflicts.
        """
        import concurrent.futures

        # Append extra context to the task for all downstream consumers
        if extra_context:
            task = f"{task}\n\n{extra_context}"

        def _run_in_thread():
            events = []
            async def _collect():
                async for event in self.process_task_stream_async(task, functions):
                    events.append(event)
            asyncio.run(_collect())
            return events

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(_run_in_thread)
            for event in future.result():
                yield event

    def process_task(self, task: str, verbose: bool = True, extra_context: str = "") -> Dict[str, Any]:
        """Run the adaptive cognitive pipeline (blocking, for CLI)."""
        result = None
        complexity = None
        for event in self.process_task_stream(task, extra_context=extra_context):
            etype = event.get("type")
            if etype == "complexity_detected" and verbose:
                print(f"[MCP] Complexity: {event['complexity']} — routing...", flush=True)
            elif etype == "step_done" and verbose:
                role = event.get("agent", "").capitalize()
                preview = str(event.get("response", ""))[:80].replace("\n", " ")
                print(f"  [✓] {role}: {preview}...")
            elif etype == "start" and verbose:
                print(f"[MCP] Task: {task}")
            elif etype == "done" and verbose:
                comp = event.get("complexity", "")
                print(f"[MCP] Done in {event['duration_seconds']:.2f}s  complexity={comp}  session={event['session_id']}")

            if etype == "done":
                result = self.get_result(event.get("session_id", ""))

        return result or {}

    # ── Background processing ────────────────────────────────────────────────────

    def process_task_background(self, task: str) -> str:
        """Start processing in a background thread. Returns session_id immediately."""
        session_id = self.session_id
        with self.__class__._results_lock:
            self.__class__._results[session_id] = None

        def run():
            brain = MCP(skip_api_key_check=True)
            brain.session_id = session_id
            brain.config = self.config
            brain.agents = {
                "creator": CreatorAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
                "critic": CriticAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
                "analyst": AnalystAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
            }
            brain.memory = WorkingMemory(storage_path=str(brain.memory_dir))
            for _ in brain.process_task_stream(task):
                pass

        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return session_id

    # ── Legacy helpers ──────────────────────────────────────────────────────────


    def _save_session_log(self, task: str, result: Dict[str, Any]) -> str:
        """Persist session to disk."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        # Use result's session_id to ensure filename matches content (handles report_outcome
        # being called on a different MCP instance than the one that ran the pipeline)
        sid = result.get("session_id", self.session_id)
        path = self.log_dir / f"session_{ts}_{sid}.json"
        with open(path, "w") as f:
            json.dump({
                "task": task,
                "session_id": sid,
                "timestamp": ts,
                "result": result,
            }, f, indent=2)
        return str(path)
