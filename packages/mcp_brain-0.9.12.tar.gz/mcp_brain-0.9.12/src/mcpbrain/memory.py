"""Memory for MCP agents — working memory, learned patterns, and session index."""

import os
import re
import json
import time
import threading
import uuid
from pathlib import Path
from typing import List, Dict, Any, Optional, NamedTuple, Sequence

from .logging_config import log as _log


# ── Shared utilities ───────────────────────────────────────────────────────────

_STOPWORDS = frozenset({
    "this", "that", "with", "from", "have", "they", "what", "when", "where",
    "which", "their", "there", "being", "were", "been", "have", "has", "had",
    "will", "would", "could", "should", "about", "into", "only", "other",
    "some", "these", "those", "session", "read", "task", "please", "tell",
    "give", "want", "need",
})


def _fingerprint_task(task: str, max_words: int = 30) -> str:
    """Create a normalized task fingerprint from keywords + bigrams for similarity matching."""
    words = re.findall(r'\b\w{4,}\b', task.lower())
    significant = [w for w in words if w not in _STOPWORDS]
    # Add bigrams for multi-word concepts (e.g. "code review", "memory leak")
    bigrams = [f"{significant[i]}_{significant[i+1]}"
               for i in range(len(significant) - 1)]
    combined = significant + bigrams
    # Deduplicate while preserving order
    seen = set()
    unique = []
    for w in combined:
        if w not in seen:
            seen.add(w)
            unique.append(w)
    return " ".join(unique[:max_words])


def _jaccard(fp1: str, fp2: str) -> float:
    """Jaccard similarity between two space-separated fingerprints."""
    set1 = set(fp1.split())
    set2 = set(fp2.split())
    if not set1 or not set2:
        return 0.0
    return len(set1 & set2) / len(set1 | set2)


# ── Code-change pattern extraction ─────────────────────────────────────────────

class CodeChangePattern(NamedTuple):
    """A reusable code-change pattern extracted from a successful session."""
    id: str
    task_keywords: str          # fingerprint-style keywords from the task
    task_sample: str            # original task (truncated)
    change_type: str             # "refactor" | "fix" | "feature" | "audit" | "optimize" | "other"
    files_changed: List[str]     # list of file paths (basenames or relative)
    pattern_summary: str         # human-readable description of the change
    code_snippet: str            # short representative snippet (before or after)
    complexity: str              # SIMPLE | MODERATE | COMPLEX
    outcome: str                 # "success" | "partial"
    rating: Optional[int]        # 1-5
    timestamp: float


class PatternExtractor:
    """Extracts reusable code-change patterns from session solutions."""

    CHANGE_TYPE_KEYWORDS = {
        "refactor": [
            "refactor", "rename", "extract", "inline", "move", "restructure",
            "simplify", "clean up", "dedupe", "remove dead", "consolidate",
            "split", "decouple", "improve", "reorganize",
        ],
        "fix": [
            "fix", "bug", "patch", "hotfix", "correct", "handle edge",
            "guard", "prevent", "crash", "error", "exception", "race condition",
            "leak", "corruption", "mangle",
        ],
        "feature": [
            "add", "implement", "new", "introduce", "support", "enable",
            "create", "build", "design", "extend", "enhance",
        ],
        "audit": [
            "audit", "review", "analyze", "check", "inspect", "assess",
            "evaluate", "examine", "find bugs", "find issues", "find problems",
            "code review", "scan", "scan for",
        ],
        "optimize": [
            "optimize", "perf", "performance", "speed up", "faster", "cache",
            "lazy", "batch", "reduce", "minimize", "memory", "efficiency",
            "concurrent", "parallel", "async",
        ],
    }

    # Regexes for extracting file paths and code patterns
    _FILE_REF_RE = re.compile(
        r"(?:^|[\s,(])((?:~\/|\.\/|\.\.\/|\/)(?:[^\s,)\"']+\/)*"
        r"[a-zA-Z_][a-zA-Z0-9_.-]*"
        r"(?:\.py|\.json|\.yaml|\.yml|\.toml|\.sh|\.bash|\.zsh|\.js|\.ts|\.go|\.rs|\.md|\.txt|\.ini|\.conf|\.cfg|\.env)"
        r"|(?:^|[\/])(?:Makefile|Dockerfile|docker-compose|\.gitignore|\.envrc))"
    )
    _CODE_SNIPPET_RE = re.compile(r"(?:def |class |async def )([a-zA-Z_][a-zA-Z0-9_]*)")
    _GIT_DIFF_RE = re.compile(r"^[+-].*", re.MULTILINE)

    @classmethod
    def classify_change_type(cls, task: str, solution: str) -> str:
        """Classify the type of code change from task + solution text."""
        combined = (task + " " + solution).lower()
        scores: Dict[str, float] = {}
        for change_type, keywords in cls.CHANGE_TYPE_KEYWORDS.items():
            scores[change_type] = sum(1 for kw in keywords if kw in combined)
        if not scores or max(scores.values()) == 0:
            return "other"
        return max(scores, key=scores.get)

    @classmethod
    def extract_files(cls, task: str, solution: str) -> List[str]:
        """Extract Python file paths mentioned in task or solution."""
        files: set = set()
        # Look for file references in task
        for m in cls._FILE_REF_RE.finditer(task):
            f = m.group(1).strip()
            if "/" in f or f.endswith(".py"):
                files.add(f)
        # Look for file references in solution
        for m in cls._FILE_REF_RE.finditer(solution):
            f = m.group(1).strip()
            if "/" in f or f.endswith(".py"):
                files.add(f)
        return sorted(files)

    @classmethod
    def extract_code_snippet(cls, solution: str, max_len: int = 300) -> str:
        """Extract a representative code snippet from a solution."""
        # Try to find the most interesting code block: functions, classes, or patches
        lines = solution.split("\n")
        snippet_lines = []
        capture = False
        for line in lines:
            stripped = line.strip()
            # Start capturing on interesting lines
            if any(stripped.startswith(p) for p in ("def ", "class ", "async def ", "+", "-", "import ", "from ")):
                capture = True
            if capture:
                snippet_lines.append(stripped)
                if len("\n".join(snippet_lines)) > max_len:
                    break
        if not snippet_lines:
            # Fallback: just grab first non-empty non-markdown lines
            for line in lines:
                stripped = line.strip()
                if stripped and not stripped.startswith("#") and not stripped.startswith("```"):
                    snippet_lines.append(stripped[:120])
                    if len(snippet_lines) >= 4:
                        break
        return "\n".join(snippet_lines)[:max_len]

    @classmethod
    def summarize_change(cls, task: str, solution: str, files: List[str]) -> str:
        """Generate a brief human-readable summary of the change."""
        change_type = cls.classify_change_type(task, solution)
        parts = [change_type]
        if files:
            file_names = [f.split("/")[-1] for f in files[:4]]
            parts.append("in " + ", ".join(file_names))
        # Detect specific action from solution
        action = None
        combined = (task + " " + solution).lower()
        if "remove" in combined or "delete" in combined:
            action = "removed"
        elif "add" in combined and "new" in combined:
            action = "added"
        elif "fix" in combined:
            action = "fixed"
        elif "replace" in combined or "change" in combined:
            action = "replaced"
        elif "optimize" in combined or "improve" in combined:
            action = "improved"
        if action:
            parts.append(action)
        return " ".join(parts)

    @classmethod
    def extract(
        cls,
        session_id: str,
        task: str,
        solution: str,
        complexity: str,
        outcome: str,
        rating: Optional[int] = None,
    ) -> Optional[CodeChangePattern]:
        """Extract a CodeChangePattern from a successful session, or None if not applicable."""
        # Only record patterns for successful outcomes with code content
        if outcome not in ("success", "partial"):
            return None
        if not solution or len(solution.strip()) < 50:
            return None
        # Skip if solution looks like pure natural language (no code indicators)
        # Be permissive: allow "bug", "fix", "issue", "refactor" keywords as valid
        if not solution or len(solution.strip()) < 50:
            return None

        # Skip if solution is pure natural language (no technical indicators)
        # Be permissive to capture audit/reviews/bug reports
        code_indicators = (
            "def ", "class ", "import ", "from ", "if ", "for ", "while ",
            "return ", "async ", "patch", "sed ", "replace", "fix", "bug",
            "issue", "refactor", "audit", "code", "file", "line", "== ",
            "+", "-", "```", "# ", "//", "/*",
        )
        if not any(ind in solution for ind in code_indicators):
            return None

        task_keywords = _fingerprint_task(task)
        change_type = cls.classify_change_type(task, solution)
        files = cls.extract_files(task, solution)
        pattern_summary = cls.summarize_change(task, solution, files)
        code_snippet = cls.extract_code_snippet(solution)

        return CodeChangePattern(
            id=session_id,
            task_keywords=task_keywords,
            task_sample=task[:200],
            change_type=change_type,
            files_changed=files,
            pattern_summary=pattern_summary,
            code_snippet=code_snippet,
            complexity=complexity,
            outcome=outcome,
            rating=rating,
            timestamp=time.time(),
        )



# ── Learned Memory ────────────────────────────────────────────────────────────

class LearnedMemory:
    """Stores successful (and failed) patterns across sessions for future reference.

    Persists to ~/.mcp/learned/patterns.json and ~/.mcp/learned/heuristics.json
    """

    PATTERNS_FILE = "patterns.json"
    HEURISTICS_FILE = "heuristics.json"

    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(storage_path or os.path.expanduser("~/.mcp/learned"))
        self.patterns_file = self.storage_path / self.PATTERNS_FILE
        self.heuristics_file = self.storage_path / self.HEURISTICS_FILE
        try:
            self.storage_path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(f"Failed to create learned memory directory {self.storage_path}: {e}") from e
        self._lock = threading.Lock()

    # ── patterns ─────────────────────────────────────────────────────────────

    # ── private I/O (no locks — only for use within a locked context) ────────────

    def _load_patterns_unsafe(self) -> List[Dict[str, Any]]:
        """Load patterns WITHOUT acquiring the lock. Caller must hold self._lock."""
        try:
            with open(self.patterns_file) as f:
                return json.load(f)
        except FileNotFoundError:
            return []
        except json.JSONDecodeError as e:
            _log.error("corrupt_patterns_file", path=str(self.patterns_file), error=str(e))
            return []

    def _load_heuristics_unsafe(self) -> List[Dict[str, Any]]:
        """Load heuristics WITHOUT acquiring the lock. Caller must hold self._lock."""
        try:
            with open(self.heuristics_file) as f:
                return json.load(f)
        except FileNotFoundError:
            return []
        except json.JSONDecodeError as e:
            _log.error("corrupt_heuristics_file", path=str(self.heuristics_file), error=str(e))
            return []

    # ── public I/O (thread-safe reads) ──────────────────────────────────────────

    def _load_patterns(self) -> List[Dict[str, Any]]:
        """Thread-safe patterns read."""
        with self._lock:
            return self._load_patterns_unsafe()

    def _load_heuristics(self) -> List[Dict[str, Any]]:
        """Thread-safe heuristics read."""
        with self._lock:
            return self._load_heuristics_unsafe()

    def _save_patterns_unsafe(self, patterns: List[Dict[str, Any]]) -> None:
        """Save patterns WITHOUT acquiring the lock. Caller must hold self._lock."""
        with open(self.patterns_file, "w") as f:
            json.dump(patterns, f, indent=2)

    def _save_heuristics_unsafe(self, heuristics: List[Dict[str, Any]]) -> None:
        """Save heuristics WITHOUT acquiring the lock. Caller must hold self._lock."""
        with open(self.heuristics_file, "w") as f:
            json.dump(heuristics, f, indent=2)

    def _save_patterns(self, patterns: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Thread-safe patterns save (acquires lock for the write)."""
        try:
            with self._lock:
                self._save_patterns_unsafe(patterns)
            return {"success": True, "path": str(self.patterns_file)}
        except (OSError, TypeError) as e:
            return {"success": False, "error": str(e)}

    def _save_heuristics(self, heuristics: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Thread-safe heuristics save."""
        try:
            with self._lock:
                self._save_heuristics_unsafe(heuristics)
            return {"success": True, "path": str(self.heuristics_file)}
        except (OSError, TypeError) as e:
            return {"success": False, "error": str(e)}

    # ── public API ─────────────────────────────────────────────────────────────

    def record_outcome(
        self,
        task: str,
        complexity: str,
        solution: str,
        outcome: str,
        rating: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Record a session outcome for future reference."""
        entry = {
            "task_fingerprint": _fingerprint_task(task),
            "task_sample": task[:200],
            "complexity": complexity,
            "outcome": outcome,
            "rating": rating,
            "timestamp": time.time(),
        }
        # Atomic read-modify-write: hold lock for the entire cycle
        with self._lock:
            patterns = self._load_patterns_unsafe()
            patterns.append(entry)
            patterns = patterns[-500:]
            self._save_patterns_unsafe(patterns)
        return {"success": True, "path": str(self.patterns_file)}

    def get_relevant_patterns(self, task: str, max_results: int = 5) -> List[Dict[str, Any]]:
        """Find past session patterns similar to the given task."""
        task_fp = _fingerprint_task(task)
        patterns = self._load_patterns()  # thread-safe read
        scored = []
        for p in patterns:
            score = _jaccard(task_fp, p.get("task_fingerprint", ""))
            if score > 0:
                scored.append((score, p))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [p for _, p in scored[:max_results]]

    # ── heuristics ────────────────────────────────────────────────────────────

    def add_heuristic(self, heuristic: str, context: str = "") -> Dict[str, Any]:
        """Store an extracted heuristic."""
        entry = {"heuristic": heuristic, "context": context, "timestamp": time.time()}
        with self._lock:
            heuristics = self._load_heuristics_unsafe()
            heuristics.append(entry)
            self._save_heuristics_unsafe(heuristics)
        return {"success": True, "path": str(self.heuristics_file)}

    def get_heuristics(self) -> List[str]:
        """Return all stored heuristics as plain strings."""
        return [h["heuristic"] for h in self._load_heuristics()]


    # ── code-change patterns ─────────────────────────────────────────────────

    CODE_PATTERNS_FILE = "code_patterns.json"

    def _load_code_patterns_unsafe(self) -> List[Dict[str, Any]]:
        """Load code patterns WITHOUT acquiring the lock."""
        try:
            with open(self.storage_path / self.CODE_PATTERNS_FILE) as f:
                return json.load(f)
        except FileNotFoundError:
            return []
        except json.JSONDecodeError as e:
            _log.error("corrupt_code_patterns", error=str(e))
            return []

    def _save_code_patterns_unsafe(self, patterns: List[Dict[str, Any]]) -> None:
        """Save code patterns WITHOUT acquiring the lock."""
        with open(self.storage_path / self.CODE_PATTERNS_FILE, "w") as f:
            json.dump(patterns, f, indent=2)

    def record_pattern(self, pattern: CodeChangePattern) -> Dict[str, Any]:
        """Store a code-change pattern, deduplicating by pattern_summary."""
        entry = pattern._asdict()
        try:
            with self._lock:
                patterns = self._load_code_patterns_unsafe()
                # Deduplicate: skip if same pattern_summary + task_keywords exists recently
                seen = {(p.get("pattern_summary", ""), p.get("task_keywords", ""))
                        for p in patterns[-200:]}
                key = (entry["pattern_summary"], entry["task_keywords"])
                if key in seen:
                    return {"success": False, "reason": "duplicate", "id": entry["id"]}
                patterns.append(entry)
                # Keep last 200
                patterns = patterns[-200:]
                self._save_code_patterns_unsafe(patterns)
            return {"success": True, "id": entry["id"], "path": str(self.storage_path / self.CODE_PATTERNS_FILE)}
        except (OSError, TypeError) as e:
            return {"success": False, "error": str(e)}

    def find_code_patterns(
        self,
        task: str,
        change_type: Optional[str] = None,
        max_results: int = 3,
    ) -> List[Dict[str, Any]]:
        """Find code-change patterns similar to the task.

        Scoring: Jaccard similarity * recency_decay * rating_weight, with
        file_overlap bonus (1.2x) and change_type alignment bonus (1.3x).
        """
        task_fp = _fingerprint_task(task)
        task_files = set(PatternExtractor.extract_files(task, ""))
        detected_type = PatternExtractor.classify_change_type(task, "")

        patterns = self._load_code_patterns()
        scored = []
        for p in patterns:
            p_type = p.get("change_type", "other")
            if change_type and p_type != change_type:
                continue

            score = _jaccard(task_fp, p.get("task_keywords", ""))
            if score < 0.2:
                continue

            # Recency: 1.5x if < 7 days, 1.2x if < 30 days
            age = time.time() - p.get("timestamp", 0)
            recency = 1.5 if age < 604800 else (1.2 if age < 2592000 else 1.0)

            # Rating weight: 0.6 baseline to 1.2 for 5-star
            rating = p.get("rating")
            rating_w = (rating / 5.0) if rating else 0.8

            # File overlap bonus: same file mentioned in task and pattern
            p_files = set(p.get("files_changed", []))
            file_bonus = 1.2 if task_files & p_files else 1.0

            # Change-type alignment bonus: task action matches pattern type
            type_bonus = 1.3 if detected_type != "other" and p_type == detected_type else 1.0

            final_score = score * recency * rating_w * file_bonus * type_bonus
            scored.append((final_score, p))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [p for _, p in scored[:max_results]]

    def get_code_patterns(self, change_type: Optional[str] = None, limit: int = 20) -> List[Dict[str, Any]]:
        """Return recent code patterns, optionally filtered by change_type."""
        patterns = self._load_code_patterns()
        if change_type:
            patterns = [p for p in patterns if p.get("change_type") == change_type]
        return patterns[-limit:]

    def _load_code_patterns(self) -> List[Dict[str, Any]]:
        """Thread-safe read."""
        with self._lock:
            return self._load_code_patterns_unsafe()



# ── Session Index ─────────────────────────────────────────────────────────────

class SessionIndex:
    """Indexes session results by task fingerprint for similarity search.

    Persists to ~/.mcp/learned/session_index.json
    """

    def __init__(self, storage_path: Optional[str] = None):
        self.storage_path = Path(storage_path or os.path.expanduser("~/.mcp/learned"))
        self.index_file = self.storage_path / "session_index.json"
        try:
            self.storage_path.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        self._lock = threading.Lock()

    def add(self, session_id: str, task: str, complexity: str, outcome: Optional[str] = None) -> None:
        """Index a session by its task fingerprint. Skips if outcome is None."""
        if outcome is None:
            return  # Don't index incomplete/abandoned sessions
        fingerprint = _fingerprint_task(task)
        # Atomic read-modify-write
        with self._lock:
            index = self._load_unsafe()
            index[session_id] = {
                "fingerprint": fingerprint,
                "task_sample": task[:200],
                "complexity": complexity,
                "outcome": outcome,
                "timestamp": time.time(),
            }
            self._save_unsafe(index)

    def find_similar(self, task: str, max_results: int = 3, min_similarity: float = 0.15) -> List[Dict[str, Any]]:
        """Find indexed sessions with similar task fingerprints."""
        task_fp = _fingerprint_task(task)
        with self._lock:
            index = self._load_unsafe()
        scored = []
        for sid, entry in index.items():
            score = _jaccard(task_fp, entry.get("fingerprint", ""))
            if score >= min_similarity:
                scored.append((score, entry, sid))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{"session_id": sid, **entry, "similarity": score}
                for score, entry, sid in scored[:max_results]]

    def _load_unsafe(self) -> Dict[str, Dict[str, Any]]:
        """Load WITHOUT acquiring the lock. Caller must hold self._lock."""
        try:
            with open(self.index_file) as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError as e:
            _log.error("corrupt_session_index", path=str(self.index_file), error=str(e))
            return {}

    def _load(self) -> Dict[str, Dict[str, Any]]:
        """Thread-safe read."""
        with self._lock:
            return self._load_unsafe()

    def _save_unsafe(self, index: Dict[str, Dict[str, Any]]) -> None:
        """Save WITHOUT acquiring the lock. Caller must hold self._lock."""
        with open(self.index_file, "w") as f:
            json.dump(index, f, indent=2)

    def _save(self, index: Dict[str, Dict[str, Any]]) -> None:
        with self._lock:
            self._save_unsafe(index)


# ── Working Memory ────────────────────────────────────────────────────────────

class WorkingMemory:
    """Manages short-term context across agent turns within a single session."""

    def __init__(self, capacity: int = 20, storage_path: Optional[str] = None):
        self.items: List[Dict[str, Any]] = []
        self.capacity = capacity
        self._lock = threading.Lock()
        self.storage_path = Path(storage_path or os.path.expanduser("~/.mcp/memory"))
        try:
            self.storage_path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise RuntimeError(f"Failed to create memory storage directory {self.storage_path}: {e}") from e

    def add(self, item: Dict[str, Any]) -> None:
        """Add an item to working memory, evicting oldest if at capacity."""
        with self._lock:
            if len(self.items) >= self.capacity:
                self.items.pop(0)
            self.items.append(item)

    def get_context(self) -> str:
        """Render current memory as a string for LLM context."""
        if not self.items:
            return "(no prior context)"
        lines = []
        for item in self.items:
            role = item.get("role", item.get("agent_id", "Agent"))
            resp = item.get("response", item.get("content", ""))
            lines.append(f"[{role}]: {resp}")
        return "\n\n".join(lines)

    def save(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Persist current memory to disk. Returns dict with 'path' or 'error'."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        unique = f"{time.time_ns() % 1_000_000_000:09d}_{uuid.uuid4().hex[:6]}"
        suffix = f"_{session_id}" if session_id else ""
        filename = f"memory{suffix}_{ts}_{unique}.json"
        path = self.storage_path / filename
        try:
            with open(path, "w") as f:
                json.dump({"items": self.items, "saved_at": ts}, f, indent=2)
            return {"success": True, "path": str(path)}
        except (OSError, TypeError) as e:
            return {"success": False, "error": f"Failed to write {path}: {e}"}

    def load(self, session_id: Optional[str] = None) -> bool:
        """Load most recent memory (or session-specific). Returns True if loaded."""
        files = sorted(self.storage_path.glob("memory*.json"), reverse=True)
        if not files:
            return False
        if session_id:
            matches = [f for f in files if session_id in f.name]
            if not matches:
                return False
            file_path = matches[0]
        else:
            file_path = files[0]
        try:
            with open(file_path) as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError, PermissionError, OSError):
            return False
        if not isinstance(data.get("items"), list):
            return False
        self.items = data.get("items", [])
        return True

    def clear(self) -> None:
        """Clear in-memory items (does not delete saved files)."""
        self.items.clear()
