"""MCP: Multi-agent Cognitive Processing Framework."""

__version__ = "0.9.12"

__all__ = [
    "__version__",
    "configure_logging",
    "get_correlation_id",
    "set_correlation_id",
    "new_correlation_id",
    "bind_correlation_id",
    "log",
]

from .logging_config import (
    configure_logging,
    get_correlation_id,
    set_correlation_id,
    new_correlation_id,
    bind_correlation_id,
    log,
)
