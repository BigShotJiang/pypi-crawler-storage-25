"""Load SaaS fingerprint patterns from YAML data file.

Supports the multi-detection schema:
  fingerprints:
    - name: OpenAI
      slug: openai
      category: AI & Generative
      confidence: high
      detections:
        - type: txt
          pattern: "^openai-domain-verification="

Also supports custom fingerprints from ~/.recon/fingerprints.yaml
(additive only — custom entries cannot override or disable built-in ones).
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, NamedTuple

import yaml

logger = logging.getLogger("recon")

__all__ = [
    "Detection",
    "DetectionRule",
    "Fingerprint",
    "get_caa_patterns",
    "get_cname_patterns",
    "get_m365_names",
    "get_m365_slugs",
    "get_mx_patterns",
    "get_ns_patterns",
    "get_spf_patterns",
    "get_srv_patterns",
    "get_subdomain_txt_patterns",
    "get_txt_patterns",
    "load_fingerprints",
    "match_txt",
    "reload_fingerprints",
]

# Hard cap on pattern length. Not a ReDoS fix by itself — see _validate_regex.
_MAX_PATTERN_LENGTH = 500

_VALID_DETECTION_TYPES = frozenset({"txt", "spf", "mx", "ns", "cname", "subdomain_txt", "caa", "srv"})
_VALID_CONFIDENCE_LEVELS = frozenset({"high", "medium", "low"})

# Structural patterns known to cause catastrophic backtracking.
# Matches nested quantifiers like (a+)+, (a*)+, (a+)*, (\w+)+, etc.
# Also catches overlapping alternation patterns like (a|a)+ and
# polynomial backtracking like \w+\w+\w+ (3+ adjacent quantifiers).
# This is a heuristic — not exhaustive — but catches the most common
# ReDoS vectors from user-supplied custom fingerprints.
_REDOS_RE = re.compile(
    r"\([^)]*[+*][^)]*\)[+*]"  # (group-with-quantifier) followed by quantifier
    r"|"
    r"(?:[+*]\??\.\*[+*])"  # quantifier + .* + quantifier
    r"|"
    r"(?:\.[+*]\??\.[+*]\??\.[+*])"  # three adjacent .X quantifiers (polynomial)
)


class Detection(NamedTuple):
    """A single fingerprint detection rule — replaces anonymous tuples."""

    pattern: str
    name: str
    slug: str
    category: str
    confidence: str


@dataclass(frozen=True)
class DetectionRule:
    """A validated detection rule within a fingerprint."""

    type: str
    pattern: str
    description: str = ""
    reference: str = ""


@dataclass(frozen=True)
class Fingerprint:
    """A validated, immutable fingerprint entry loaded from YAML.

    Frozen dataclass ensures cached fingerprints cannot be mutated.
    """

    name: str
    slug: str
    category: str
    confidence: str
    m365: bool
    detections: tuple[DetectionRule, ...]
    provider_group: str | None = None  # e.g., "microsoft365", "google-workspace"
    display_group: str | None = None  # e.g., "Email & Communication", "Security"


def _validate_regex(pattern: str, source: str) -> bool:
    """Validate a regex pattern is safe to compile and not degenerate.

    Three-layer defense:
    1. Reject empty / excessively long patterns.
    2. Reject patterns with known catastrophic-backtracking structures
       (nested quantifiers like (a+)+). This is a heuristic, not a proof —
       for full safety, swap in google-re2 or another linear-time engine.
    3. Reject patterns that don't compile.
    """
    if not pattern:
        logger.warning("Empty regex pattern in %s — skipped", source)
        return False
    if len(pattern) > _MAX_PATTERN_LENGTH:
        logger.warning(
            "Regex pattern too long (%d chars) in %s — skipped",
            len(pattern),
            source,
        )
        return False
    # Heuristic ReDoS check: reject nested quantifiers
    if _REDOS_RE.search(pattern):
        logger.warning(
            "Potentially unsafe regex (nested quantifiers) %r in %s — skipped",
            pattern,
            source,
        )
        return False
    try:
        re.compile(pattern)
    except re.error as exc:
        logger.warning("Invalid regex %r in %s: %s — skipped", pattern, source, exc)
        return False
    return True


def _validate_fingerprint(fp: dict[str, Any], source: str) -> Fingerprint | None:
    """Validate a single fingerprint entry and return a frozen Fingerprint, or None.

    Does NOT mutate the input dict. Returns a frozen dataclass.
    """
    if not isinstance(fp, dict):  # pyright: ignore[reportUnnecessaryIsInstance]
        logger.warning("Non-dict fingerprint entry in %s — skipped", source)
        return None

    name = fp.get("name")
    if not name or not isinstance(name, str):
        logger.warning("Fingerprint missing 'name' in %s — skipped", source)
        return None

    detections_raw = fp.get("detections")
    if not isinstance(detections_raw, list) or not detections_raw:
        logger.warning("Fingerprint %r has no detections in %s — skipped", name, source)
        return None

    confidence = fp.get("confidence", "medium")
    if confidence not in _VALID_CONFIDENCE_LEVELS:
        logger.warning(
            "Fingerprint %r has invalid confidence %r in %s — defaulting to medium",
            name,
            confidence,
            source,
        )
        confidence = "medium"

    valid_detections: list[DetectionRule] = []
    for det in detections_raw:
        if not isinstance(det, dict):
            continue
        det_type = det.get("type")
        if det_type not in _VALID_DETECTION_TYPES:
            logger.warning(
                "Fingerprint %r has unknown detection type %r in %s — skipped",
                name,
                det_type,
                source,
            )
            continue
        pattern = det.get("pattern", "")
        if not _validate_regex(pattern, f"{source}:{name}"):
            continue
        valid_detections.append(
            DetectionRule(
                type=det_type,
                pattern=pattern,
                description=det.get("description", ""),
                reference=det.get("reference", ""),
            )
        )

    if not valid_detections:
        logger.warning("Fingerprint %r has no valid detections in %s — skipped", name, source)
        return None

    slug = fp.get("slug", name.lower().replace(" ", "-"))
    category = fp.get("category", "Misc")
    m365 = bool(fp.get("m365", False))

    return Fingerprint(
        name=name,
        slug=slug,
        category=category,
        confidence=confidence,
        m365=m365,
        detections=tuple(valid_detections),
        provider_group=fp.get("provider_group") if isinstance(fp.get("provider_group"), str) else None,
        display_group=fp.get("display_group") if isinstance(fp.get("display_group"), str) else None,
    )


def _load_from_path(path: Path) -> list[Fingerprint]:
    """Load and validate fingerprints from a single YAML file."""
    if not path.exists():
        return []

    source = str(path)
    try:
        text = path.read_text(encoding="utf-8")
        loaded = yaml.safe_load(text)
    except (yaml.YAMLError, OSError) as exc:
        logger.warning("Failed to load fingerprints from %s: %s", source, exc)
        return []

    raw: list[Any] = []
    if isinstance(loaded, dict) and "fingerprints" in loaded:
        raw = loaded["fingerprints"]
    elif isinstance(loaded, list):
        raw = loaded
    else:
        logger.warning(
            "Unexpected YAML structure in %s — expected dict with 'fingerprints' key or list",
            source,
        )
        return []

    if not isinstance(raw, list):
        return []

    results: list[Fingerprint] = []
    for fp_raw in raw:
        fp = _validate_fingerprint(fp_raw, source)
        if fp is not None:
            results.append(fp)
    return results


@lru_cache(maxsize=1)
def load_fingerprints() -> tuple[Fingerprint, ...]:
    """Load fingerprints from YAML data files (built-in + custom).

    Returns a tuple of frozen Fingerprint dataclasses. The tuple (immutable)
    and frozen dataclasses ensure the cached result cannot be corrupted by
    callers mutating the return value.

    Results are cached for the process lifetime. In the CLI this is fine
    (short-lived process). In the MCP server (long-lived), call
    reload_fingerprints() to pick up changes to custom fingerprints.
    """
    data_path = Path(__file__).parent / "data" / "fingerprints.yaml"
    custom_dir = os.environ.get("RECON_CONFIG_DIR")
    custom_path = Path(custom_dir) / "fingerprints.yaml" if custom_dir else Path.home() / ".recon" / "fingerprints.yaml"

    entries: list[Fingerprint] = []
    entries.extend(_load_from_path(data_path))
    entries.extend(_load_from_path(custom_path))
    return tuple(entries)


def reload_fingerprints() -> None:
    """Clear all fingerprint/pattern caches so the next call reloads from disk.

    Useful for long-lived processes (MCP server) when custom fingerprints change.
    """
    load_fingerprints.cache_clear()
    _get_detections.cache_clear()
    get_m365_names.cache_clear()
    get_m365_slugs.cache_clear()


@lru_cache(maxsize=8)
def _get_detections(det_type: str) -> tuple[Detection, ...]:
    """Flatten fingerprints into Detection tuples for a given detection type.

    Returns a tuple (immutable) to prevent cache corruption.
    """
    results: list[Detection] = []
    for fp in load_fingerprints():
        for det in fp.detections:
            if det.type == det_type and det.pattern:
                results.append(Detection(det.pattern, fp.name, fp.slug, fp.category, fp.confidence))
    return tuple(results)


# Public accessors — thin wrappers over _get_detections for readability.
# All return tuple[Detection, ...] (immutable).


def get_txt_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for TXT record matching."""
    return _get_detections("txt")


def get_spf_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for SPF include matching."""
    return _get_detections("spf")


def get_mx_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for MX record matching."""
    return _get_detections("mx")


def get_ns_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for NS record matching."""
    return _get_detections("ns")


def get_cname_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for CNAME record matching."""
    return _get_detections("cname")


def get_subdomain_txt_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for subdomain-specific TXT record matching.

    These patterns have a 'pattern' field formatted as 'subdomain:regex' where
    subdomain is the prefix to query (e.g. '_slack-challenge') and regex is
    matched against the TXT value at that subdomain.
    """
    return _get_detections("subdomain_txt")


def get_caa_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for CAA record matching."""
    return _get_detections("caa")


def get_srv_patterns() -> tuple[Detection, ...]:
    """Return Detection tuples for SRV record matching.

    NOTE: No built-in fingerprints currently use SRV detection. This accessor
    exists as an extension point for custom fingerprints that need SRV matching.
    """
    return _get_detections("srv")


@lru_cache(maxsize=1)
def get_m365_names() -> frozenset[str]:
    """Return names of fingerprints that indicate M365."""
    return frozenset(fp.name for fp in load_fingerprints() if fp.m365)


@lru_cache(maxsize=1)
def get_m365_slugs() -> frozenset[str]:
    """Return slugs of fingerprints that indicate M365.

    Slug-based detection is more stable than name-based — renaming a
    fingerprint's display name won't break M365 detection.
    """
    return frozenset(fp.slug for fp in load_fingerprints() if fp.m365)


# Maximum TXT record length to match against. DNS TXT records are limited to
# ~64KB in practice (multiple 255-byte strings). Anything longer is likely
# malformed or adversarial input designed to trigger regex backtracking.
_MAX_TXT_MATCH_LENGTH = 4096


def match_txt(txt_value: str, patterns: tuple[Detection, ...] | list[Detection]) -> Detection | None:
    """Match a TXT record value against patterns. Returns the matching Detection or None.

    Rejects excessively long input to bound regex execution time.
    """
    if len(txt_value) > _MAX_TXT_MATCH_LENGTH:
        return None
    for det in patterns:
        try:
            if re.search(det.pattern, txt_value, re.IGNORECASE):
                return det
        except re.error:
            # Defensive: pattern was validated on load, but guard against edge cases
            continue
    return None
