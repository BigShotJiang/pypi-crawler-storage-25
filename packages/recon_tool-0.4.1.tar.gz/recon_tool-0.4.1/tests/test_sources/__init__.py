"""Tests for lookup sources."""
