# pystmwrap

`pystmwrap` is a Python wrapper package for running **official R `stm` workflows** inside STM Academic.

## Maintainer

- **Dr. Mustafa Koray Uru**
- **mustafakoray@gmail.com**

## What this package does

This package serves as the STM-side execution layer for STM Academic. It passes validated analysis requests to R scripts, executes workflows built around the official `stm` package, and returns structured outputs that STM Academic can use to generate tables, diagnostics, and visualizations.

## Package notes

- This package does **not** replace the R `stm` package. The target machine must still have **R** installed.
- The target machine must also have the required R packages installed, especially `stm` and its dependencies.
- This package includes the R scripts used by the wrapper under `src/pystmwrap/engine/scripts/`.

## Local build

```bash
python -m pip install --upgrade build
python -m build
```

## Local install test

```bash
python -m pip install dist/pystmwrap-0.5.0-py3-none-any.whl
```

## Publish later

You can publish this package to TestPyPI first, then to PyPI.
A step-by-step publishing guide is included in `PUBLISH_TO_PYPI_TR.md`.
