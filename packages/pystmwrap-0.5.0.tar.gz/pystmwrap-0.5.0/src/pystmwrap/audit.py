from __future__ import annotations

from pathlib import Path

from .engine.runner import RRunner
from .registry import ANALYSIS_REGISTRY
from .schemas import INPUT_SPECS, RESULT_SCHEMAS


def run_audit() -> dict:
    package_root = Path(__file__).resolve().parent
    scripts_dir = package_root / "engine" / "scripts"
    missing_r_scripts = [name for name, script in ANALYSIS_REGISTRY.items() if not (scripts_dir / script).exists()]
    runner_methods = set(dir(RRunner))
    missing_runner_methods = [m for m in ["run_analysis", "check_environment", "bootstrap_r"] if m not in runner_methods]
    missing_result_schemas = [name for name in ANALYSIS_REGISTRY if name not in RESULT_SCHEMAS]
    missing_input_schemas = [name for name in ANALYSIS_REGISTRY if name not in INPUT_SPECS]
    analyses_with_required_inputs = sorted([name for name, spec in INPUT_SPECS.items() if list(spec.get("required", []) or [])])
    return {
        "ok": not any([missing_r_scripts, missing_runner_methods, missing_result_schemas, missing_input_schemas]),
        "analysis_keys": list(ANALYSIS_REGISTRY.keys()),
        "missing_r_scripts": missing_r_scripts,
        "missing_runner_methods": missing_runner_methods,
        "missing_result_schemas": missing_result_schemas,
        "missing_input_schemas": missing_input_schemas,
        "analyses_with_required_inputs": analyses_with_required_inputs,
        "package_root": str(package_root),
    }
