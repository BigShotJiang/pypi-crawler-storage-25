from __future__ import annotations

from pathlib import Path
import json
import pandas as pd


def to_dataframe(records):
    return pd.DataFrame(records)


def export_json(data: dict, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
