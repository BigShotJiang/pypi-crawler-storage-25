
from __future__ import annotations

import argparse
import json

from .project import STMProject


def _kv_pairs(pairs):
    out = {}
    for item in pairs or []:
        if "=" not in item:
            raise SystemExit(f"Invalid --param format: {item}. Use key=value")
        key, value = item.split("=", 1)
        try:
            out[key] = json.loads(value)
        except Exception:
            out[key] = value
    return out


def main(argv=None):
    parser = argparse.ArgumentParser(prog="pystmwrap")
    parser.add_argument("--workdir", default=None)
    parser.add_argument("--rscript-path", default="Rscript")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("check")
    sub.add_parser("audit")
    sub.add_parser("bootstrap-r")
    sub.add_parser("list-analyses")
    run = sub.add_parser("run")
    run.add_argument("analysis")
    run.add_argument("--param", action="append")
    args = parser.parse_args(argv)
    project = STMProject(workdir=args.workdir, rscript_path=args.rscript_path)

    if args.command == "check":
        print(json.dumps(project.check_environment(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "audit":
        print(json.dumps(project.audit(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "bootstrap-r":
        print(json.dumps(project.bootstrap_r(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "list-analyses":
        print(json.dumps(project.available_analyses(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "run":
        params = _kv_pairs(args.param)
        print(json.dumps(project.run_analysis(args.analysis, **params), ensure_ascii=False, indent=2))
        return 0
    return 1
