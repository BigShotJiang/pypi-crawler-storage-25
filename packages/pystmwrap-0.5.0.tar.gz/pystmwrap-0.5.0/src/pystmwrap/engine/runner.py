from __future__ import annotations

import json
import shutil
import subprocess
import uuid
from pathlib import Path

from ..config import ARTIFACTS_DIRNAME, RUNS_DIRNAME
from ..errors import AnalysisError, DependencyError
from ..registry import ANALYSIS_REGISTRY
from ..schemas import INPUT_SPECS, RESULT_SCHEMAS
from ..utils.validation import validate_input, validate_schema


class RRunner:
    def __init__(self, workdir: Path, rscript_path: str = "Rscript"):
        self.workdir = Path(workdir)
        self.rscript_path = rscript_path
        self.scripts_dir = Path(__file__).resolve().parent / "scripts"
        self.artifacts_dir = self.workdir / ARTIFACTS_DIRNAME
        self.runs_dir = self.workdir / RUNS_DIRNAME
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)
        self.runs_dir.mkdir(parents=True, exist_ok=True)

    def _resolve_rscript(self) -> str:
        if Path(self.rscript_path).exists():
            return str(Path(self.rscript_path))
        found = shutil.which(self.rscript_path)
        if found:
            return found
        raise DependencyError(
            f"Rscript executable could not be found: '{self.rscript_path}'. Install R and ensure Rscript is available on PATH, or provide an explicit path."
        )

    def _call_analysis(self, analysis_key: str, payload: dict) -> dict:
        script_name = ANALYSIS_REGISTRY[analysis_key]
        validate_input(payload, INPUT_SPECS.get(analysis_key), analysis_key)
        run_dir = self.runs_dir / f"{analysis_key}_{str(uuid.uuid4())[:8]}"
        run_dir.mkdir(parents=True, exist_ok=True)
        config_path = run_dir / "config.json"
        output_path = run_dir / "result.json"
        payload = dict(payload)
        payload.update(
            {
                "analysis": analysis_key,
                "output_json": str(output_path),
                "workdir": str(self.workdir),
                "artifacts_dir": str(self.artifacts_dir),
                "run_dir": str(run_dir),
            }
        )
        config_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        cmd = [self._resolve_rscript(), str(self.scripts_dir / script_name), str(config_path)]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            raise AnalysisError(
                "R script failed.\n"
                f"Analysis: {analysis_key}\n"
                f"STDOUT:\n{proc.stdout}\n"
                f"STDERR:\n{proc.stderr}"
            )
        result = json.loads(output_path.read_text(encoding="utf-8"))
        validate_schema(result, RESULT_SCHEMAS[analysis_key])
        return result

    def run_analysis(self, analysis_key: str, **params) -> dict:
        if analysis_key not in ANALYSIS_REGISTRY:
            raise AnalysisError(f"Unknown analysis key: {analysis_key}")
        return self._call_analysis(analysis_key, params)

    def __getattr__(self, name):
        if name in ANALYSIS_REGISTRY:
            return lambda **params: self.run_analysis(name, **params)
        raise AttributeError(name)

    def check_environment(self) -> dict:
        return self.run_analysis("environment_check")

    def bootstrap_r(self) -> dict:
        return self.run_analysis("bootstrap_r")
