source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
meta <- if (!is.null(config$meta_prepared_id)) load_prepared(config, config$meta_prepared_id)$meta else load_prepared(config, obj$prepared_id)$meta
dt <- make.dt(obj$model, meta = meta)
write_output(config, list(analysis = "make_dt", model_id = config$model_id, rows = as_records(as.data.frame(dt))))
