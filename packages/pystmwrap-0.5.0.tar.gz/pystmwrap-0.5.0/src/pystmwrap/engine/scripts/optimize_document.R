source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
bundle <- load_prepared(config, obj$prepared_id)
doc_index <- as.integer(config$doc_index)
doc <- bundle$documents[[doc_index]]
out <- optimizeDocument(doc, model = obj$model, verbose = FALSE)
write_output(config, list(analysis = "optimize_document", model_id = config$model_id, doc_index = doc_index, result = jsonify(out)))
