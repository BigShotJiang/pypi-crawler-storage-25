source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_lasso(config, config$lasso_id)
fun <- get('unpack.glmnet', envir = asNamespace('stm'))
ic_k <- if (!is.null(config$ic_k)) as.numeric(config$ic_k) else 2
res <- tryCatch(fun(obj, ic.k = ic_k), error = function(e) {
  if (is.list(obj) && !is.null(obj$mod)) {
    fun(obj$mod, ic.k = ic_k)
  } else {
    stop(e)
  }
})
coef_df <- as.data.frame(res$coef, stringsAsFactors = FALSE)
coef_df$term <- rownames(coef_df)
rownames(coef_df) <- NULL
intercept_df <- data.frame(intercept = as.numeric(res$intercept))
write_output(config, list(analysis = config$analysis, lasso_id = config$lasso_id, ic_k = ic_k, coefficients = as_records(coef_df), intercept = as_records(intercept_df)))
