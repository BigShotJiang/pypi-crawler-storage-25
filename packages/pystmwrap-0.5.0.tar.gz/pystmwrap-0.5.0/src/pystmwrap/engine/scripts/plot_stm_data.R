source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
type <- if (!is.null(config$type)) config$type else "summary"
if (type == "summary") {
  data <- list(avg_topic_prevalence = as.list(colMeans(obj$model$theta)), topic_numbers = as.list(seq_len(ncol(obj$model$theta))))
} else if (type == "labels") {
  labs <- labelTopics(obj$model, n = if (!is.null(config$n)) as.integer(config$n) else 7)
  data <- list(topicnums = as.list(labs$topicnums), prob = apply(labs$prob, 1, paste, collapse = ", "), frex = apply(labs$frex, 1, paste, collapse = ", "))
} else {
  data <- list(theta = as_records(as.data.frame(obj$model$theta)))
}
write_output(config, list(analysis = "plot_stm_data", model_id = config$model_id, type = type, data = jsonify(data)))
