source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
args <- config
for (nm in c("output_json","analysis","workdir","artifacts_dir","run_dir")) args[[nm]] <- NULL
obj <- do.call(readLdac, args)
corpus_id <- make_id("corpus")
saveRDS(list(raw = obj, documents = obj$documents, vocab = obj$vocab, meta = if (!is.null(obj$meta)) obj$meta else NULL), artifact_path(config, "corpus", corpus_id))
write_output(config, list(analysis = "read_ldac", corpus_id = corpus_id, n_docs = if (!is.null(obj$documents)) length(obj$documents) else NA))
