source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
M <- if (!is.null(config$M)) as.integer(config$M) else 10
frexw <- if (!is.null(config$frexw)) as.numeric(config$frexw) else 0.7
ex <- exclusivity(obj$model, M = M, frexw = frexw)
metrics <- data.frame(topic = seq_along(ex), exclusivity = as.numeric(ex))
write_output(config, list(analysis = "exclusivity", model_id = config$model_id, metrics = as_records(metrics)))
