source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
bundle <- load_prepared(config, config$prepared_id)
write_output(config, list(analysis = "plot_removed_data", docs_removed = if (!is.null(bundle$docs_removed)) as.list(bundle$docs_removed) else list(), words_removed = if (!is.null(bundle$words_removed)) as.list(bundle$words_removed) else list()))
