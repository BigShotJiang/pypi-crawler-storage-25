source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
df <- read.csv(config$csv_path, stringsAsFactors = FALSE)
text_col <- config$text_column
meta_cols <- unlist(config$metadata_columns)
meta <- if (length(meta_cols) > 0) df[, meta_cols, drop = FALSE] else NULL
extra <- filter_args_by_formals(config, textProcessor, exclude = c("documents", "metadata"))
args_tp <- merge_args_preserve(list(documents = df[[text_col]], metadata = meta), extra)
out <- do.call(textProcessor, args_tp)
textprocessed_id <- make_id("textproc")
bundle <- list(documents = out$documents, vocab = out$vocab, meta = out$meta, texts = df[[text_col]], original_df = df)
saveRDS(bundle, artifact_path(config, "textproc", textprocessed_id))
write_output(config, list(analysis = "text_processor", textprocessed_id = textprocessed_id, n_docs = length(out$documents), vocab_size = length(out$vocab), meta_columns = names(out$meta)))
