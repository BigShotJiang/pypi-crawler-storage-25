source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
bundle <- load_textprocessed(config, config$textprocessed_id)
write_output(config, list(
  analysis = "summary_text_processor",
  textprocessed_id = config$textprocessed_id,
  n_docs = length(bundle$documents),
  vocab_size = length(bundle$vocab),
  meta_columns = names(bundle$meta)
))
