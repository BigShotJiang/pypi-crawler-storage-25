source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
data <- list()
if (!is.null(config$selection_id)) {
  out <- load_selection(config, config$selection_id)
  data <- list(semcoh = lapply(out$semcoh, as.list), exclusivity = if (!is.null(out$exclusivity)) lapply(out$exclusivity, as.list) else list())
} else if (!is.null(config$many_topics_id)) {
  out <- load_manytopics(config, config$many_topics_id)
  data <- list(semcoh = lapply(out$semcoh, as.list), exclusivity = if (!is.null(out$exclusivity)) lapply(out$exclusivity, as.list) else list())
}
write_output(config, list(analysis = "plot_models_data", data = jsonify(data)))
