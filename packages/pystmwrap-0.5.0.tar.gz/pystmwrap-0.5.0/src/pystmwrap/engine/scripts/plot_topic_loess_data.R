source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
obj <- load_model(config, config$model_id)
bundle <- load_prepared(config, obj$prepared_id)
meta <- bundle$meta
x <- meta[[config$covariate]]
topics <- unlist(config$topics)
span <- if (!is.null(config$span)) as.numeric(config$span) else 1.5
series <- list()
for (t in topics) {
  y <- obj$model$theta[, t]
  fit <- loess(y ~ x, span = span)
  xs <- seq(min(x, na.rm = TRUE), max(x, na.rm = TRUE), length.out = 100)
  pred <- predict(fit, newdata = data.frame(x = xs), se = TRUE)
  series[[length(series)+1]] <- list(topic = t, x = as.list(xs), y = as.list(pred$fit), se = as.list(pred$se.fit))
}
write_output(config, list(analysis = "plot_topic_loess_data", model_id = config$model_id, covariate = config$covariate, topics = as.list(topics), series = series))
