source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
quotes <- list()
if (!is.null(config$thoughts_id)) {
  th <- load_thoughts(config, config$thoughts_id)
  if (!is.null(config$topic_index)) {
    idx <- as.integer(config$topic_index)
    quotes <- as.list(th$docs[[idx]])
  } else {
    quotes <- lapply(th$docs, as.list)
  }
} else if (!is.null(config$quotes)) {
  quotes <- as.list(config$quotes)
}
write_output(config, list(analysis = "plot_quote_data", quotes = quotes))
