suppressPackageStartupMessages({
  library(jsonlite)
})

read_config <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  if (length(args) < 1) stop("Config path not provided")
  fromJSON(args[[1]], simplifyVector = FALSE)
}

write_output <- function(config, payload) {
  write_json(payload, path = config$output_json, pretty = TRUE, auto_unbox = TRUE, null = "null")
}

normalize_formula <- function(x) {
  if (is.null(x) || identical(x, "") || identical(x, FALSE)) return(NULL)
  if (inherits(x, "formula")) return(x)
  x <- as.character(x)
  if (startsWith(x, "~")) return(as.formula(x))
  as.formula(paste("~", x))
}

artifact_path <- function(config, prefix, id) {
  file.path(config$artifacts_dir, paste0(prefix, "_", id, ".rds"))
}

make_id <- function(prefix="id") {
  paste0(prefix, "_", as.integer(Sys.time()), "_", sample(10000:99999, 1))
}

load_prepared <- function(config, prepared_id) {
  readRDS(artifact_path(config, "prepared", prepared_id))
}

load_model <- function(config, model_id) {
  readRDS(artifact_path(config, "model", model_id))
}

load_effect <- function(config, effect_id) {
  readRDS(artifact_path(config, "effect", effect_id))
}

as_records <- function(df) {
  if (is.null(df)) return(list())
  if (is.matrix(df)) df <- as.data.frame(df, stringsAsFactors = FALSE)
  if (!is.data.frame(df)) df <- as.data.frame(df, stringsAsFactors = FALSE)
  rownames(df) <- NULL
  jsonlite::fromJSON(jsonlite::toJSON(df, dataframe = "rows", auto_unbox = TRUE), simplifyVector = FALSE)
}

safe_df <- function(df) {
  if (is.null(df)) return(data.frame())
  if (!is.data.frame(df)) df <- as.data.frame(df, stringsAsFactors = FALSE)
  names(df) <- make.names(names(df), unique = TRUE)
  df
}

jsonify <- function(x) {
  jsonlite::fromJSON(jsonlite::toJSON(x, dataframe = "rows", auto_unbox = TRUE, null = "null", na = "null"), simplifyVector = FALSE)
}

load_textprocessed <- function(config, textprocessed_id) {
  readRDS(artifact_path(config, "textproc", textprocessed_id))
}

load_selection <- function(config, selection_id) {
  readRDS(artifact_path(config, "selection", selection_id))
}

load_manytopics <- function(config, many_topics_id) {
  readRDS(artifact_path(config, "manytopics", many_topics_id))
}

load_searchk <- function(config, searchk_id) {
  readRDS(artifact_path(config, "searchk", searchk_id))
}

load_thoughts <- function(config, thoughts_id) {
  readRDS(artifact_path(config, "thoughts", thoughts_id))
}

load_topiccorr <- function(config, topiccorr_id) {
  readRDS(artifact_path(config, "topiccorr", topiccorr_id))
}

load_permtest <- function(config, permtest_id) {
  readRDS(artifact_path(config, "permtest", permtest_id))
}

load_corpus_bundle <- function(config, corpus_id) {
  readRDS(artifact_path(config, "corpus", corpus_id))
}

load_heldout <- function(config, heldout_id) {
  readRDS(artifact_path(config, "heldout", heldout_id))
}

load_multistm <- function(config, multistm_id) {
  readRDS(artifact_path(config, "multistm", multistm_id))
}

extract_logbeta <- function(model) {
  lb <- model$beta$logbeta
  if (is.list(lb)) return(lb[[1]])
  lb
}

compute_wordcounts <- function(documents, vocab_size) {
  counts <- rep(0, vocab_size)
  for (doc in documents) {
    if (is.null(doc) || length(doc) == 0) next
    idx <- as.integer(doc[1, ])
    ct <- as.numeric(doc[2, ])
    valid <- idx >= 1 & idx <= vocab_size
    counts[idx[valid]] <- counts[idx[valid]] + ct[valid]
  }
  counts
}

topic_words_records <- function(x, vocab = NULL, top_n = NULL) {
  if (is.null(dim(x))) x <- matrix(x, nrow = 1)
  x <- as.matrix(x)
  if (!is.null(top_n)) {
    keep <- seq_len(min(ncol(x), as.integer(top_n)))
    x <- x[, keep, drop = FALSE]
  }
  out <- vector('list', nrow(x))
  for (i in seq_len(nrow(x))) {
    vals <- x[i, ]
    words <- as.character(vals)
    suppressWarnings({
      idx <- as.integer(vals)
      if (!is.null(vocab) && all(!is.na(idx))) {
        idx <- idx[idx >= 1 & idx <= length(vocab)]
        words <- vocab[idx]
      }
    })
    out[[i]] <- list(topic = i, words = as.list(words), words_joined = paste(words, collapse = ', '))
  }
  out
}

rows_matrix_from_config <- function(rows) {
  if (is.null(rows)) return(matrix(numeric(), nrow = 0))
  max_len <- max(vapply(rows, length, integer(1)))
  mat <- t(vapply(rows, function(r) {
    x <- as.numeric(unlist(r))
    length(x) <- max_len
    x
  }, numeric(max_len)))
  mat
}

load_lasso <- function(config, lasso_id) {
  readRDS(artifact_path(config, 'lasso', lasso_id))
}

non_null_args <- function(x) {
  if (is.null(x)) return(list())
  x[!vapply(x, is.null, logical(1))]
}

official_formal_args <- function(fun) {
  nms <- names(formals(fun))
  nms[!(nms %in% c("..."))]
}

filter_args_by_formals <- function(config, fun, exclude = character()) {
  cfg <- non_null_args(config)
  if (length(cfg) == 0) return(list())
  allowed <- setdiff(official_formal_args(fun), exclude)
  cfg[names(cfg) %in% allowed]
}

merge_args_preserve <- function(base_args, extra_args) {
  out <- base_args
  extra_args <- non_null_args(extra_args)
  if (length(extra_args) == 0) return(out)
  protected <- names(base_args)
  for (nm in names(extra_args)) {
    if (!(nm %in% protected)) out[[nm]] <- extra_args[[nm]]
  }
  out
}

ensure_true <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}

ensure_nonempty_string <- function(x, name) {
  ensure_true(!is.null(x), sprintf("%s is required.", name))
  ensure_true(nzchar(trimws(as.character(x))), sprintf("%s must be a non-empty string.", name))
}

ensure_positive_integerish <- function(x, name, allow_zero = FALSE) {
  ensure_true(!is.null(x), sprintf("%s is required.", name))
  val <- suppressWarnings(as.integer(x))
  ensure_true(!is.na(val), sprintf("%s must be an integer.", name))
  if (allow_zero) {
    ensure_true(val >= 0, sprintf("%s must be >= 0.", name))
  } else {
    ensure_true(val > 0, sprintf("%s must be > 0.", name))
  }
  val
}

ensure_numeric_scalar <- function(x, name, min_value = NULL, max_value = NULL, inclusive_max = TRUE) {
  ensure_true(!is.null(x), sprintf("%s is required.", name))
  val <- suppressWarnings(as.numeric(x))
  ensure_true(length(val) == 1 && !is.na(val), sprintf("%s must be numeric.", name))
  if (!is.null(min_value)) ensure_true(val >= min_value, sprintf("%s must be >= %s.", name, min_value))
  if (!is.null(max_value)) {
    if (isTRUE(inclusive_max)) ensure_true(val <= max_value, sprintf("%s must be <= %s.", name, max_value))
    else ensure_true(val < max_value, sprintf("%s must be < %s.", name, max_value))
  }
  val
}

ensure_choice <- function(x, choices, name) {
  ensure_nonempty_string(x, name)
  val <- as.character(x)
  ensure_true(val %in% choices, sprintf("%s must be one of: %s", name, paste(choices, collapse = ", ")))
  val
}

extract_formula_vars <- function(formula_obj) {
  unique(all.vars(formula_obj))
}

ensure_formula_vars_present <- function(formula_obj, meta, label) {
  if (is.null(formula_obj)) return(invisible(TRUE))
  vars <- extract_formula_vars(formula_obj)
  if (length(vars) == 0) return(invisible(TRUE))
  ensure_true(!is.null(meta), sprintf("%s requires metadata, but metadata is NULL.", label))
  missing <- setdiff(vars, names(meta))
  ensure_true(length(missing) == 0, sprintf("%s variables not found in metadata: %s", label, paste(missing, collapse = ", ")))
  invisible(TRUE)
}

ensure_content_formula_valid <- function(content_formula, meta) {
  if (is.null(content_formula)) return(invisible(TRUE))
  ensure_formula_vars_present(content_formula, meta, "content formula")
  vars <- extract_formula_vars(content_formula)
  ensure_true(length(vars) == 1, "content formula must reference exactly one metadata column.")
  invisible(TRUE)
}
