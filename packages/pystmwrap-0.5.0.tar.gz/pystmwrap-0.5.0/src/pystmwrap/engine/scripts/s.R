source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
x <- unlist(config$x)
if (is.null(x)) stop("x must be provided")
df_value <- if (!is.null(config$df)) as.integer(config$df) else NULL
args <- list(x = as.numeric(x))
if (!is.null(df_value)) args$df <- df_value
basis <- do.call(stm::s, args)
basis_df <- as.data.frame(basis)
write_output(config, list(analysis = "s", basis = as_records(basis_df)))
