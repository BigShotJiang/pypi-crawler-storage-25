source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages({library(stm); library(igraph)})
config <- read_config()
obj <- load_model(config, config$model_id)
cutoff <- ensure_numeric_scalar(if (!is.null(config$cutoff)) config$cutoff else 0.01, "cutoff", min_value = 0)
method <- if (!is.null(config$method)) as.character(config$method) else "simple"
ensure_nonempty_string(method, "method")
tc <- topicCorr(obj$model, cutoff = cutoff, method = method)
topiccorr_id <- make_id("topiccorr")
saveRDS(tc, artifact_path(config, "topiccorr", topiccorr_id))
adj <- tc$posadj
nodes <- data.frame(topic = seq_len(ncol(obj$model$theta)))
if (is.null(adj)) {
  edges <- data.frame(source = integer(), target = integer(), weight = numeric())
} else {
  g <- igraph::graph_from_adjacency_matrix(adj, mode = "undirected", weighted = TRUE, diag = FALSE)
  edges <- igraph::as_data_frame(g, what = "edges")
  names(edges) <- c("source", "target", "weight")
}
write_output(config, list(analysis = "topic_corr", model_id = config$model_id, topiccorr_id = topiccorr_id, nodes = as_records(nodes), edges = as_records(edges)))
