
source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
bundle <- load_prepared(config, obj$prepared_id)
out <- findThoughts(obj$model, texts = bundle$texts, topics = unlist(config$topics), n = as.integer(config$n), thresh = if (!is.null(config$thresh)) as.numeric(config$thresh) else NULL)
thoughts_id <- make_id("thoughts")
saveRDS(out, artifact_path(config, "thoughts", thoughts_id))
results <- list()
for (i in seq_along(out$index)) {
  results[[i]] <- list(topic = unlist(config$topics)[i], index = as.list(out$index[[i]]), docs = as.list(out$docs[[i]]))
}
write_output(config, list(analysis = "find_thoughts", model_id = config$model_id, topics = as.list(unlist(config$topics)), results = results, thoughts_id = thoughts_id))
