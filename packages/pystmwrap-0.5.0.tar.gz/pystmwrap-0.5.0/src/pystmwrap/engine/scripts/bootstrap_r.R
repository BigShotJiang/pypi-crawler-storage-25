source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
requested <- c("stm", "jsonlite", "igraph", "LDAvis")
ok <- TRUE
for (pkg in requested) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    tryCatch(install.packages(pkg, repos = "https://cloud.r-project.org"), error = function(e) { ok <<- FALSE })
  }
}
write_output(config, list(analysis = "bootstrap_r", requested = requested, ok = ok))
