source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
args <- config
for (nm in c("output_json","analysis","workdir","artifacts_dir","run_dir")) args[[nm]] <- NULL
obj <- do.call(readCorpus, args)
corpus_id <- make_id("corpus")
saveRDS(list(raw = obj), artifact_path(config, "corpus", corpus_id))
docs <- if (!is.null(obj$documents)) length(obj$documents) else NA
write_output(config, list(analysis = "read_corpus", corpus_id = corpus_id, n_docs = docs))
