source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
prep <- load_prepared(config, obj$prepared_id)
M <- if (!is.null(config$M)) as.integer(config$M) else 10
sc <- semanticCoherence(model = obj$model, documents = prep$documents, M = M)
metrics <- data.frame(topic = seq_along(sc), semantic_coherence = as.numeric(sc))
write_output(config, list(analysis = "semantic_coherence", model_id = config$model_id, metrics = as_records(metrics)))
