source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
pt <- load_permtest(config, config$permtest_id)
write_output(config, list(analysis = "plot_stm_permute_data", permtest_id = config$permtest_id, ratings = if (!is.null(pt$ratings)) as.list(pt$ratings) else list(), topics = if (!is.null(pt$topics)) as.list(pt$topics) else list()))
