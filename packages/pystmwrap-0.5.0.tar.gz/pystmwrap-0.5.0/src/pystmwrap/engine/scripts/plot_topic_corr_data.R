source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(igraph))
config <- read_config()
tc <- load_topiccorr(config, config$topiccorr_id)
adj <- tc$posadj
nodes <- data.frame(topic = seq_len(nrow(adj)))
if (is.null(adj)) {
  edges <- data.frame(source = integer(), target = integer(), weight = numeric())
} else {
  g <- igraph::graph_from_adjacency_matrix(adj, mode = "undirected", weighted = TRUE, diag = FALSE)
  edges <- igraph::as_data_frame(g, what = "edges")
  names(edges) <- c("source", "target", "weight")
}
write_output(config, list(analysis = "plot_topic_corr_data", nodes = as_records(nodes), edges = as_records(edges)))
