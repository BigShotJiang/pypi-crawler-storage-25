source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
if (!is.null(config$prepared_id)) {
  docs <- load_prepared(config, config$prepared_id)$documents
} else {
  docs <- load_corpus_bundle(config, config$corpus_id)$documents
}
writeLdac(docs, file = config$file, zeroindex = if (!is.null(config$zeroindex)) isTRUE(config$zeroindex) else TRUE)
write_output(config, list(analysis = "write_ldac", path = config$file, zeroindex = if (!is.null(config$zeroindex)) isTRUE(config$zeroindex) else TRUE))
