source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages({library(stm)})
config <- read_config()
obj <- load_model(config, config$model_id)
if (!requireNamespace("LDAvis", quietly = TRUE)) {
  stop("LDAvis package is not installed")
}
outpath <- if (!is.null(config$path) && !identical(config$path, "")) config$path else file.path(config$run_dir, paste0(config$model_id, "_ldavis.json"))
stm::toLDAvisJson(obj$model, outpath)
write_output(config, list(analysis = "ldavis_json", model_id = config$model_id, json_path = outpath))
