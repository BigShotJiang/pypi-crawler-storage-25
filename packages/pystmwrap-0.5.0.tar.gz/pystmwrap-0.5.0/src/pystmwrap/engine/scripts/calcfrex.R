source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
prep <- load_prepared(config, obj$prepared_id)
logbeta <- extract_logbeta(obj$model)
wordcounts <- compute_wordcounts(prep$documents, length(prep$vocab))
fun <- get('calcfrex', envir = asNamespace('stm'))
w <- if (!is.null(config$w)) as.numeric(config$w) else 0.5
top_n <- if (!is.null(config$top_n)) as.integer(config$top_n) else 10
res <- fun(logbeta = logbeta, w = w, wordcounts = wordcounts)
write_output(config, list(analysis = config$analysis, model_id = config$model_id, weight = w, topics = topic_words_records(res, prep$vocab, top_n)))
