source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
counts <- read.csv(config$counts_csv_path, stringsAsFactors = FALSE, check.names = FALSE)
meta <- NULL
if (!is.null(config$metadata_csv_path) && !identical(config$metadata_csv_path, "")) {
  meta <- read.csv(config$metadata_csv_path, stringsAsFactors = FALSE)
}
if (!is.null(config$doc_id_column) && config$doc_id_column %in% names(counts)) {
  counts[[config$doc_id_column]] <- NULL
}
mat <- as.matrix(counts)
storage.mode(mat) <- "numeric"
out <- asSTMCorpus(mat, data = meta)
corpus_id <- make_id("corpus")
saveRDS(list(raw = out, documents = out$documents, vocab = out$vocab, meta = out$data), artifact_path(config, "corpus", corpus_id))
write_output(config, list(analysis = "as_stm_corpus", corpus_id = corpus_id, n_docs = length(out$documents), vocab_size = length(out$vocab)))
