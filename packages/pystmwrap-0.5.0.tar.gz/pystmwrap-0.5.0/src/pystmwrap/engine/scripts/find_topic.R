source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- NULL
if (!is.null(config$model_id)) obj <- load_model(config, config$model_id)$model
if (!is.null(config$label_topics_result)) obj <- config$label_topics_result
out <- findTopic(obj, unlist(config$words), n = if (!is.null(config$n)) as.integer(config$n) else NULL, type = if (!is.null(config$type)) config$type else "prob", verbose = FALSE)
write_output(config, list(analysis = "find_topic", matches = jsonify(out)))
