source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
labtype <- if (!is.null(config$labeltype)) config$labeltype else "prob"
labs <- labelTopics(obj$model, topics = if (!is.null(config$topics)) unlist(config$topics) else NULL, n = if (!is.null(config$n)) as.integer(config$n) else 20)
mat <- labs[[labtype]]
words <- unique(as.vector(mat))
write_output(config, list(analysis = "cloud", words = as.list(words)))
