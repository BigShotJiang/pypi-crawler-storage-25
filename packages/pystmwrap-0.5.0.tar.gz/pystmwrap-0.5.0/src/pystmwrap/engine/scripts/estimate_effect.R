source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
bundle <- load_prepared(config, obj$prepared_id)
ensure_nonempty_string(config$formula, "formula")
formula_obj <- as.formula(config$formula)
ensure_formula_vars_present(formula_obj, bundle$meta, "estimateEffect formula")
uncertainty <- if (!is.null(config$uncertainty)) ensure_choice(config$uncertainty, c("Global", "Local", "None"), "uncertainty") else "Global"
nsims <- if (!is.null(config$nsims)) ensure_positive_integerish(config$nsims, "nsims") else 25
prior <- if (!is.null(config$prior)) config$prior else NULL
documents_arg <- NULL
if (identical(uncertainty, "Local")) {
  ensure_true(!is.null(bundle$documents), "uncertainty='Local' requires documents, but prepared documents are unavailable.")
  documents_arg <- bundle$documents
}
eff <- estimateEffect(formula_obj, stmobj = obj$model, metadata = bundle$meta, uncertainty = uncertainty, documents = documents_arg, nsims = nsims, prior = prior)
effect_id <- make_id("effect")
saveRDS(list(effect = eff, model_id = config$model_id, prepared_id = obj$prepared_id), artifact_path(config, "effect", effect_id))
write_output(config, list(analysis = "estimate_effect", effect_id = effect_id, model_id = config$model_id, formula = config$formula))
