source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
model <- obj$model
avg_prev <- data.frame(topic = seq_len(ncol(model$theta)), mean = as.numeric(colMeans(model$theta)))
labs <- labelTopics(model, n = 7)
top_prob <- data.frame(topic = labs$topicnums, label = apply(labs$prob, 1, paste, collapse = ", "))
write_output(config, list(analysis = "summary_model", model_id = config$model_id, K = ncol(model$theta), avg_topic_prevalence = as_records(avg_prev), top_prob_labels = as_records(top_prob)))
