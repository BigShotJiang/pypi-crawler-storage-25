source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
out <- thetaPosterior(obj$model, nsims = if (!is.null(config$nsims)) as.integer(config$nsims) else 100)
summaries <- list()
for (i in seq_along(out)) {
  mat <- out[[i]]
  summaries[[i]] <- list(doc_index = i, mean = as.list(colMeans(mat)), sd = as.list(apply(mat, 2, sd)))
}
write_output(config, list(analysis = "theta_posterior", model_id = config$model_id, nsims = if (!is.null(config$nsims)) as.integer(config$nsims) else 100, draw_summaries = summaries))
