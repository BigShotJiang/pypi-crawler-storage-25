source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
config <- read_config()
obj <- load_multistm(config, config$multistm_id)
write_output(config, list(analysis = "plot_multimod_diagnostic_data", multistm_id = config$multistm_id, data = jsonify(list(wmat = obj$wmat, tmat = obj$tmat, confidence_ratings = obj$confidence.ratings))))
