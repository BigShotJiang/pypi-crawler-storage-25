source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
hold <- load_heldout(config, config$heldout_id)
res <- eval.heldout(obj$model, hold$missing)
write_output(config, list(
  analysis = "eval_heldout",
  model_id = config$model_id,
  heldout_id = config$heldout_id,
  result = jsonify(res)
))
