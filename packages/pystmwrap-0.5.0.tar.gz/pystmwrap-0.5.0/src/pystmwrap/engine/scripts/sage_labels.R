source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
obj <- load_model(config, config$model_id)
out <- sageLabels(obj$model, n = as.integer(config$n))
prob <- out$marginal$prob
frex <- out$marginal$frex
lift <- out$marginal$lift
score <- out$marginal$score
topics_df <- data.frame(topic = seq_len(nrow(prob)), prob = apply(prob, 1, paste, collapse = ", "), frex = apply(frex, 1, paste, collapse = ", "), lift = apply(lift, 1, paste, collapse = ", "), score = apply(score, 1, paste, collapse = ", "))
write_output(config, list(analysis = "sage_labels", model_id = config$model_id, topics = as_records(topics_df)))
