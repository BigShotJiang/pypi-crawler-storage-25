source(file.path(dirname(commandArgs(trailingOnly = TRUE)[1]), "_helpers.R"))
suppressPackageStartupMessages(library(stm))
config <- read_config()
df <- read.csv(config$csv_path, stringsAsFactors = FALSE)
text_col <- config$text_column
meta_cols <- unlist(config$metadata_columns)
meta <- if (length(meta_cols) > 0) df[, meta_cols, drop = FALSE] else NULL

tp_extra <- filter_args_by_formals(config$text_processor, textProcessor, exclude = c("documents", "metadata"))
args_tp <- merge_args_preserve(list(documents = df[[text_col]], metadata = meta), tp_extra)
tp <- do.call(textProcessor, args_tp)

prep_extra <- filter_args_by_formals(config$prep, prepDocuments, exclude = c("documents", "vocab", "meta"))
args_prep <- merge_args_preserve(list(documents = tp$documents, vocab = tp$vocab, meta = tp$meta), prep_extra)
out <- do.call(prepDocuments, args_prep)

prepared_id <- make_id("prepared")
bundle <- list(documents = out$documents, vocab = out$vocab, meta = out$meta, texts = df[[text_col]], original_df = df, wordcounts = out$wordcounts, docs_removed = out$docs.removed, words_removed = out$words.removed)
saveRDS(bundle, artifact_path(config, "prepared", prepared_id))
payload <- list(
  analysis = "prepare_texts",
  prepared_id = prepared_id,
  n_docs = length(out$documents),
  vocab_size = length(out$vocab),
  meta_columns = names(out$meta),
  docs_removed = if (!is.null(out$docs.removed)) unname(out$docs.removed) else list(),
  words_removed = if (!is.null(out$words.removed)) unname(out$words.removed) else list()
)
write_output(config, payload)
