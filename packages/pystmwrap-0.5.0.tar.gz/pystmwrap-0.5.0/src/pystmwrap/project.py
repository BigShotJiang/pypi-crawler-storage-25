from __future__ import annotations

from pathlib import Path
from typing import Iterable

import pandas as pd

from .api.exports import to_dataframe
from .audit import run_audit
from .config import DEFAULT_WORKDIR
from .engine.runner import RRunner
from .registry import ANALYSIS_REGISTRY


class STMProject:
    def __init__(self, workdir: str | None = None, rscript_path: str = "Rscript"):
        self.workdir = Path(workdir or DEFAULT_WORKDIR).resolve()
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.runner = RRunner(self.workdir, rscript_path=rscript_path)

    def available_analyses(self) -> list[str]:
        return list(ANALYSIS_REGISTRY.keys())

    def audit(self) -> dict:
        return run_audit()

    def check_environment(self) -> dict:
        return self.runner.check_environment()

    def bootstrap_r(self) -> dict:
        return self.runner.bootstrap_r()

    def run_analysis(self, analysis_key: str, **params) -> dict:
        return self.runner.run_analysis(analysis_key, **params)

    def text_processor(self, texts: Iterable[str], metadata: pd.DataFrame | dict | None = None, text_column: str = "text", **params) -> dict:
        texts = list(texts)
        if metadata is None:
            df = pd.DataFrame({text_column: texts})
        elif isinstance(metadata, pd.DataFrame):
            df = metadata.copy()
            df[text_column] = texts
        else:
            df = pd.DataFrame(metadata)
            df[text_column] = texts
        csv_path = self.workdir / "input_texts_raw.csv"
        df.to_csv(csv_path, index=False)
        metadata_columns = [c for c in df.columns if c != text_column]
        return self.run_analysis("text_processor", csv_path=str(csv_path), text_column=text_column, metadata_columns=metadata_columns, **params)

    def prep_documents(self, textprocessed_id: str, **params) -> dict:
        return self.run_analysis("prep_documents", textprocessed_id=textprocessed_id, **params)

    def prepare_texts(self, texts: Iterable[str], metadata: pd.DataFrame | dict | None = None, text_column: str = "text", text_processor: dict | None = None, prep: dict | None = None) -> dict:
        texts = list(texts)
        if metadata is None:
            df = pd.DataFrame({text_column: texts})
        elif isinstance(metadata, pd.DataFrame):
            df = metadata.copy()
            df[text_column] = texts
        else:
            df = pd.DataFrame(metadata)
            df[text_column] = texts
        csv_path = self.workdir / "input_texts.csv"
        df.to_csv(csv_path, index=False)
        metadata_columns = [c for c in df.columns if c != text_column]
        return self.run_analysis("prepare_texts", csv_path=str(csv_path), text_column=text_column, metadata_columns=metadata_columns, text_processor=text_processor or {}, prep=prep or {})

    def as_stm_corpus(self, counts: pd.DataFrame, metadata: pd.DataFrame | None = None, doc_id_column: str | None = None) -> dict:
        counts_path = self.workdir / "counts.csv"
        counts.to_csv(counts_path, index=False)
        metadata_path = None
        if metadata is not None:
            metadata_path = self.workdir / "counts_meta.csv"
            metadata.to_csv(metadata_path, index=False)
        return self.run_analysis("as_stm_corpus", counts_csv_path=str(counts_path), metadata_csv_path=str(metadata_path) if metadata_path else None, doc_id_column=doc_id_column)

    def fit_model(self, prepared_id: str, K: int, prevalence: str | None = None, content: str | None = None, init_type: str = "Spectral", seed: int | None = None, max_em_its: int = 75, emtol: float = 1e-5):
        return self.run_analysis("fit_stm", prepared_id=prepared_id, K=K, prevalence=prevalence, content=content, init_type=init_type, seed=seed, max_em_its=max_em_its, emtol=emtol)

    def search_k(self, prepared_id: str, K_values: list[int], prevalence: str | None = None, init_type: str = "Spectral", heldout_n: int | None = None, proportion: float = 0.5, M: int = 10):
        return self.run_analysis("search_k", prepared_id=prepared_id, K_values=K_values, prevalence=prevalence, init_type=init_type, heldout_n=heldout_n, proportion=proportion, M=M)

    def select_model(self, prepared_id: str, K: int, prevalence: str | None = None, init_type: str = "LDA", runs: int = 20, seed: int | None = None):
        return self.run_analysis("select_model", prepared_id=prepared_id, K=K, prevalence=prevalence, init_type=init_type, runs=runs, seed=seed)

    def many_topics(self, prepared_id: str, K_values: list[int], prevalence: str | None = None, init_type: str = "LDA", runs: int = 20, seed: int | None = None):
        return self.run_analysis("many_topics", prepared_id=prepared_id, K_values=K_values, prevalence=prevalence, init_type=init_type, runs=runs, seed=seed)

    def summarize_model(self, model_id: str):
        return self.run_analysis("summary_model", model_id=model_id)

    def label_topics(self, model_id: str, topics: list[int] | None = None, n: int = 7, frexweight: float = 0.5):
        return self.run_analysis("label_topics", model_id=model_id, topics=topics, n=n, frexweight=frexweight)

    def sage_labels(self, model_id: str, n: int = 7):
        return self.run_analysis("sage_labels", model_id=model_id, n=n)

    def estimate_effect(self, model_id: str, formula: str, uncertainty: str = "Global"):
        return self.run_analysis("estimate_effect", model_id=model_id, formula=formula, uncertainty=uncertainty)

    def effect_plot_data(self, effect_id: str, covariate: str, method: str = "pointestimate", topics: list[int] | None = None, cov_value1=None, cov_value2=None, moderator: str | None = None, moderator_value=None, npoints: int = 20, nsims: int = 100):
        return self.run_analysis("effect_plot_data", effect_id=effect_id, covariate=covariate, method=method, topics=topics, cov_value1=cov_value1, cov_value2=cov_value2, moderator=moderator, moderator_value=moderator_value, npoints=npoints, nsims=nsims)

    def find_thoughts(self, model_id: str, topics: list[int], n: int = 3, thresh: float | None = None):
        return self.run_analysis("find_thoughts", model_id=model_id, topics=topics, n=n, thresh=thresh)

    def topic_corr(self, model_id: str, cutoff: float = 0.01, method: str = "simple"):
        return self.run_analysis("topic_corr", model_id=model_id, cutoff=cutoff, method=method)

    def permutation_test(self, model_id: str, covariate: str, topics: list[int] | None = None, nsim: int = 100):
        return self.run_analysis("permutation_test", model_id=model_id, covariate=covariate, topics=topics, nsim=nsim)

    def fit_new_documents(self, model_id: str, texts: Iterable[str], metadata: pd.DataFrame | dict | None = None, text_column: str = "text"):
        texts = list(texts)
        if metadata is None:
            df = pd.DataFrame({text_column: texts})
        elif isinstance(metadata, pd.DataFrame):
            df = metadata.copy()
            df[text_column] = texts
        else:
            df = pd.DataFrame(metadata)
            df[text_column] = texts
        csv_path = self.workdir / "new_texts.csv"
        df.to_csv(csv_path, index=False)
        metadata_columns = [c for c in df.columns if c != text_column]
        return self.run_analysis("fit_new_documents", model_id=model_id, csv_path=str(csv_path), text_column=text_column, metadata_columns=metadata_columns)

    def ldavis_json(self, model_id: str, path: str | None = None):
        return self.run_analysis("ldavis_json", model_id=model_id, path=path)

    def topic_quality(self, model_id: str, top_n: int = 10):
        return self.run_analysis("topic_quality", model_id=model_id, top_n=top_n)

    def calcfrex(self, model_id: str, w: float = 0.5, top_n: int = 10):
        return self.run_analysis("calcfrex", model_id=model_id, w=w, top_n=top_n)

    def calclift(self, model_id: str, top_n: int = 10):
        return self.run_analysis("calclift", model_id=model_id, top_n=top_n)

    def calcscore(self, model_id: str, top_n: int = 10):
        return self.run_analysis("calcscore", model_id=model_id, top_n=top_n)

    def js_estimate(self, prob, ct):
        return self.run_analysis("js_estimate", prob=prob, ct=ct)

    def make_design_matrix(self, formula: str, orig_data: pd.DataFrame, new_data: pd.DataFrame, test: bool = True, sparse: bool = True):
        orig_path = self.workdir / "orig_design_data.csv"
        new_path = self.workdir / "new_design_data.csv"
        orig_data.to_csv(orig_path, index=False)
        new_data.to_csv(new_path, index=False)
        return self.run_analysis("make_design_matrix", formula=formula, orig_csv_path=str(orig_path), new_csv_path=str(new_path), test=test, sparse=sparse)

    def rmvnorm(self, n: int, mu, Sigma):
        return self.run_analysis("rmvnorm", n=n, mu=mu, Sigma=Sigma)

    def unpack_glmnet(self, lasso_id: str, ic_k: float = 2):
        return self.run_analysis("unpack_glmnet", lasso_id=lasso_id, ic_k=ic_k)

    def optimizeDocument(self, model_id: str, doc_index: int):
        return self.run_analysis("optimizeDocument", model_id=model_id, doc_index=doc_index)

    def serVis(self, model_id: str, directory: str | None = None, open_browser: bool = False):
        return self.run_analysis("serVis", model_id=model_id, directory=directory, open_browser=open_browser)

    def eval_heldout_dot(self, model_id: str, heldout_id: str):
        return self.run_analysis("eval.heldout", model_id=model_id, heldout_id=heldout_id)

    def summary_textProcessor(self, textprocessed_id: str):
        return self.run_analysis("summary.textProcessor", textprocessed_id=textprocessed_id)

    @staticmethod
    def to_df(records):
        return to_dataframe(records)

    def __getattr__(self, name):
        if name in ANALYSIS_REGISTRY:
            return lambda **params: self.run_analysis(name, **params)
        raise AttributeError(name)
