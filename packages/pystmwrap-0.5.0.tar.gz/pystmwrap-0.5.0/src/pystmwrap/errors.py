class STMWrapError(Exception):
    pass


class DependencyError(STMWrapError):
    pass


class AnalysisError(STMWrapError):
    pass


class ValidationError(STMWrapError):
    pass
