from __future__ import annotations

from collections.abc import Mapping

from ..errors import ValidationError


def validate_schema(result: dict, required: list[str]) -> None:
    missing = [key for key in required if key not in result]
    if missing:
        raise ValidationError(f"Result missing keys: {missing}")


def validate_input(payload: Mapping[str, object], spec: Mapping[str, object] | None, analysis_key: str) -> None:
    if spec is None:
        return
    required = list(spec.get("required", []) or [])
    forbidden = list(spec.get("forbidden", []) or [])
    nonempty = list(spec.get("nonempty", []) or [])

    missing = [key for key in required if key not in payload]
    if missing:
        raise ValidationError(f"Input missing required keys for {analysis_key}: {missing}")

    forbidden_present = [key for key in forbidden if key in payload]
    if forbidden_present:
        raise ValidationError(
            f"Input contains reserved keys for {analysis_key}: {forbidden_present}. "
            "These keys are managed internally by pystmwrap."
        )

    empty_keys: list[str] = []
    for key in nonempty:
        if key not in payload:
            continue
        value = payload.get(key)
        if value is None:
            empty_keys.append(key)
            continue
        if isinstance(value, str) and not value.strip():
            empty_keys.append(key)
            continue
        if isinstance(value, (list, tuple, set, dict)) and len(value) == 0:
            empty_keys.append(key)
    if empty_keys:
        raise ValidationError(f"Input contains empty values for {analysis_key}: {empty_keys}")
