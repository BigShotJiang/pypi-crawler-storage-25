from pathlib import Path

DEFAULT_WORKDIR = Path(".pystmwrap_work")
ARTIFACTS_DIRNAME = "artifacts"
RUNS_DIRNAME = "runs"
