"""Tests for Von Payments Checkout Python SDK."""

import base64
import hashlib
import hmac as hmac_mod
import json
import time

import httpx
import pytest

from vonpay.checkout import (
    LineItem,
    MIRROR_CONTRACT_VERSION,
    MITBlock,
    MirrorAddress,
    MirrorBlock,
    MirrorCustomer,
    MirrorLineItem,
    MirrorNoteAttribute,
    MirrorTaxLine,
    VonPayCheckout,
    VonPayError,
)


class TestConstructor:
    def test_accepts_valid_test_key(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client is not None

    def test_accepts_valid_live_key(self):
        client = VonPayCheckout("vp_sk_live_abc123def456")
        assert client is not None

    def test_accepts_publishable_key(self):
        client = VonPayCheckout("vp_pk_test_abc123def456")
        assert client is not None

    def test_rejects_empty_key(self):
        with pytest.raises(ValueError, match="API key is required"):
            VonPayCheckout("")

    def test_rejects_invalid_prefix(self):
        with pytest.raises(ValueError, match="Invalid API key format"):
            VonPayCheckout("sk_live_bad_prefix")


class TestWebhookVerification:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign(self, payload: str) -> str:
        return hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

    def test_verify_valid_signature(self):
        payload = '{"event":"session.succeeded"}'
        sig = self._sign(payload)
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client.webhooks.verify_signature(payload, sig, self.SECRET)

    def test_reject_invalid_signature(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(
            '{"event":"session.succeeded"}', "bad" * 16, self.SECRET
        )

    def test_reject_tampered_payload(self):
        payload = '{"event":"session.succeeded","amount":1499}'
        sig = self._sign(payload)
        tampered = '{"event":"session.succeeded","amount":9999}'
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(tampered, sig, self.SECRET)

    def test_reject_non_hex_signature(self):
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(
            '{"event":"test"}', "not-hex-at-all!", self.SECRET
        )

    def test_accepts_bytes_payload(self):
        payload = b'{"event":"session.succeeded"}'
        sig = hmac_mod.new(self.SECRET.encode(), payload, hashlib.sha256).hexdigest()
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert client.webhooks.verify_signature(payload, sig, self.SECRET)

    def test_rejects_mixed_case_hex(self):
        payload = '{"event":"session.succeeded"}'
        lower = hmac_mod.new(self.SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        upper = lower.upper()
        client = VonPayCheckout("vp_sk_test_abc123def456")
        assert not client.webhooks.verify_signature(payload, upper, self.SECRET)


class TestConstructEvent:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign(self, payload: str) -> str:
        return hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()

    def test_parses_valid_event(self):
        event_data = {
            "event": "session.succeeded",
            "sessionId": "session_abc",
            "merchantId": "merchant_123",
            "amount": 1499,
            "currency": "USD",
            "status": "succeeded",
            "transactionId": "txn_xyz",
            "timestamp": "2026-04-14T10:00:00Z",
        }
        payload = json.dumps(event_data)
        sig = self._sign(payload)
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        client = VonPayCheckout("vp_sk_test_abc123def456")
        result = client.webhooks.construct_event(payload, sig, self.SECRET, now)
        assert result.event == "session.succeeded"
        assert result.session_id == "session_abc"
        assert result.amount == 1499
        assert result.transaction_id == "txn_xyz"

    def test_rejects_expired_timestamp(self):
        payload = '{"event":"session.succeeded"}'
        sig = self._sign(payload)
        old = "2020-01-01T00:00:00Z"

        client = VonPayCheckout("vp_sk_test_abc123def456")
        with pytest.raises(VonPayError) as exc_info:
            client.webhooks.construct_event(payload, sig, self.SECRET, old)
        assert exc_info.value.code == "webhook_invalid_signature"
        assert "timestamp" in str(exc_info.value)

    def test_rejects_bad_signature(self):
        payload = '{"event":"session.succeeded"}'
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        client = VonPayCheckout("vp_sk_test_abc123def456")
        with pytest.raises(VonPayError) as exc_info:
            client.webhooks.construct_event(
                payload, "a" * 64, self.SECRET, now
            )
        err = exc_info.value
        assert err.code == "webhook_invalid_signature"
        # Webhook errors do NOT carry the lifecycle envelope (parity with
        # Node's negative assertion at packages/checkout-node/src/client.test.ts).
        # Pin the boundary so a future maintainer wiring payment_intent into
        # webhook bodies trips a failing test rather than silently bleeding
        # a value across surfaces.
        assert err.payment_intent is None
        assert err.current_status is None
        assert err.reject_reason is None

    def test_accepts_bytes_payload(self):
        event_data = {
            "event": "session.succeeded",
            "sessionId": "session_abc",
            "merchantId": "merchant_123",
            "amount": 1499,
            "currency": "USD",
            "status": "succeeded",
            "transactionId": "txn_xyz",
            "timestamp": "2026-04-14T10:00:00Z",
        }
        payload = json.dumps(event_data).encode()  # bytes
        sig = hmac_mod.new(self.SECRET.encode(), payload, hashlib.sha256).hexdigest()
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        client = VonPayCheckout("vp_sk_test_abc123def456")
        result = client.webhooks.construct_event(payload, sig, self.SECRET, now)
        assert result.session_id == "session_abc"


class TestErrorCodeCatalog:
    """Coverage for the three new ErrorCode members added in 0.1.1/0.1.2."""

    def test_new_members_importable(self):
        # Import-smoke — if the Literal union is wrong at parse time, this fails.
        from vonpay.checkout.types import ErrorCode  # noqa: F401

    def test_vonpay_error_accepts_new_codes(self):
        for code in (
            "merchant_not_onboarded",
            "provider_attestation_failed",
            "provider_charge_failed",
        ):
            err = VonPayError(
                status=403,
                error="e",
                code=code,  # type: ignore[arg-type]
                fix="f",
                docs="d",
            )
            assert err.code == code


class TestConstructEventV2:
    SECRET = "vp_sk_test_webhook_secret_key"

    def _sign_v2(self, t: int, payload_bytes: bytes) -> str:
        signed = f"{t}.".encode() + payload_bytes
        return hmac_mod.new(
            self.SECRET.encode(), signed, hashlib.sha256
        ).hexdigest()

    def test_parses_valid_v2_event(self):
        event_data = {
            "event": "session.succeeded",
            "sessionId": "session_abc",
            "merchantId": "merchant_123",
            "amount": 1499,
            "currency": "USD",
            "status": "succeeded",
            "transactionId": "txn_xyz",
            "timestamp": "2026-04-14T10:00:00Z",
        }
        payload = json.dumps(event_data)
        t = int(time.time())
        header = f"t={t},v2={self._sign_v2(t, payload.encode())}"
        result = VonPayCheckout(
            "vp_sk_test_abc123def456"
        ).webhooks.construct_event_v2(payload, header, self.SECRET)
        assert result.event == "session.succeeded"
        assert result.session_id == "session_abc"
        assert result.amount == 1499

    def test_accepts_bytes_payload(self):
        payload = b'{"event":"session.succeeded","sessionId":"s","merchantId":"m","amount":1,"currency":"USD","status":"succeeded","timestamp":"t"}'
        t = int(time.time())
        header = f"t={t},v2={self._sign_v2(t, payload)}"
        result = VonPayCheckout(
            "vp_sk_test_abc123def456"
        ).webhooks.construct_event_v2(payload, header, self.SECRET)
        assert result.session_id == "s"

    def test_rejects_replayed_timestamp(self):
        payload = '{"event":"session.succeeded","sessionId":"s","merchantId":"m","amount":1,"currency":"USD","status":"succeeded","timestamp":"t"}'
        t = int(time.time())
        # Signer signed at time t, but attacker replays with t_new — server will
        # see (t, sig) where HMAC(secret, t.body) doesn't match because attacker
        # can't recompute without the secret. We simulate by swapping t only.
        good_hex = self._sign_v2(t, payload.encode())
        header_replayed = f"t={t + 1},v2={good_hex}"
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, header_replayed, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_malformed_header(self):
        payload = '{"event":"session.succeeded"}'
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, "not-a-valid-header", self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_stale_timestamp(self):
        payload = '{"event":"session.succeeded"}'
        t_old = int(time.time()) - 3600  # 1 hour ago
        header = f"t={t_old},v2={self._sign_v2(t_old, payload.encode())}"
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, header, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_v1_signature_format(self):
        """A bare v1 64-char hex sig passed as the v2 header must be rejected
        — parity with the Node test at client.test.ts TestConstructEventV2."""
        payload = '{"event":"session.succeeded"}'
        v1_hex = hmac_mod.new(
            self.SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, v1_hex, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_duplicate_t_in_header(self):
        """Smuggle attempt: pair a valid HMAC for t=A with a duplicate fresh t=B.

        Last-writer-wins parsing would pass the freshness window with B while
        the HMAC was computed for A. Parser must reject duplicate keys.
        """
        payload = '{"event":"session.succeeded"}'
        old_t = int(time.time()) - 3600  # outside freshness window
        fresh_t = int(time.time())
        good_hex = self._sign_v2(old_t, payload.encode())
        header = f"t={old_t},v2={good_hex},t={fresh_t}"
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, header, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"

    def test_rejects_duplicate_v2_in_header(self):
        """Same defense applied to the v2= field."""
        payload = '{"event":"session.succeeded"}'
        t = int(time.time())
        good_hex = self._sign_v2(t, payload.encode())
        bad_hex = "0" * 64
        header = f"t={t},v2={good_hex},v2={bad_hex}"
        with pytest.raises(VonPayError) as exc_info:
            VonPayCheckout("vp_sk_test_abc123def456").webhooks.construct_event_v2(
                payload, header, self.SECRET
            )
        assert exc_info.value.code == "webhook_invalid_signature"


class TestReturnSignature:
    SECRET = "ss_test_session_signing_secret"

    def _sign_return(self, params: dict) -> str:
        data = ".".join([
            params["session"],
            params["status"],
            params["amount"],
            params["currency"],
            params.get("transaction_id", ""),
        ])
        return hmac_mod.new(
            self.SECRET.encode(), data.encode(), hashlib.sha256
        ).hexdigest()

    def test_valid_signature(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
            "transaction_id": "txn_xyz",
        }
        params["sig"] = self._sign_return(params)
        assert VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_valid_without_transaction_id(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        assert VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_rejects_missing_sig(self):
        params = {"session": "abc", "status": "ok", "amount": "1", "currency": "USD"}
        assert not VonPayCheckout.verify_return_signature(params, self.SECRET)

    def test_rejects_wrong_secret(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        assert not VonPayCheckout.verify_return_signature(params, "wrong_secret")

    def test_rejects_tampered_amount(self):
        params = {
            "session": "session_abc",
            "status": "succeeded",
            "amount": "1499",
            "currency": "USD",
        }
        params["sig"] = self._sign_return(params)
        params["amount"] = "9999"
        assert not VonPayCheckout.verify_return_signature(params, self.SECRET)


class TestReturnSignatureV2:
    """v2 return-URL signature path: payload+url+keyMode+iat all bound."""

    SECRET = "ss_test_session_signing_secret"
    SUCCESS_URL = "https://merchant.example/return"

    BASE_PARAMS = {
        "session": "vps_test_v2_001",
        "status": "succeeded",
        "amount": "1499",
        "currency": "USD",
        "transaction_id": "txn_v2_xyz",
    }

    def _normalise_url(self, raw: str) -> str:
        # Mirrors checkout server's session-tokens.normaliseSuccessUrl.
        from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

        parts = urlsplit(raw)
        qs = urlencode(sorted(parse_qsl(parts.query, keep_blank_values=True)))
        path = parts.path.rstrip("/") if parts.path != "/" else parts.path
        return urlunsplit((parts.scheme, parts.netloc, path, qs, ""))

    def _b64url(self, data: bytes) -> str:
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")

    def _sign_v2(self, payload: dict, secret: str = None) -> str:
        signing_secret = secret if secret is not None else self.SECRET
        payload_b64 = self._b64url(json.dumps(payload).encode("utf-8"))
        signed_input = f"v2.{payload_b64}".encode("utf-8")
        hex_hmac = hmac_mod.new(
            signing_secret.encode(), signed_input, hashlib.sha256
        ).hexdigest()
        return f"v2.{payload_b64}.{hex_hmac}"

    def _base_payload(self, **overrides) -> dict:
        payload = {
            "sid": self.BASE_PARAMS["session"],
            "status": self.BASE_PARAMS["status"],
            "amount": 1499,
            "currency": self.BASE_PARAMS["currency"],
            "transactionId": self.BASE_PARAMS["transaction_id"],
            "successUrl": self._normalise_url(self.SUCCESS_URL),
            "keyMode": "test",
            "iat": int(time.time()) - 5,
        }
        payload.update(overrides)
        return payload

    def test_returns_true_for_fully_bound_v2(self):
        sig = self._sign_v2(self._base_payload())
        assert VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_when_expected_success_url_omitted(self):
        sig = self._sign_v2(self._base_payload())
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_key_mode="test",
        )

    def test_rejects_when_expected_key_mode_omitted(self):
        sig = self._sign_v2(self._base_payload())
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
        )

    def test_rejects_key_mode_mismatch(self):
        sig = self._sign_v2(self._base_payload(keyMode="live"))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_payload_success_url_mismatch(self):
        sig = self._sign_v2(
            self._base_payload(successUrl="https://attacker.example/return")
        )
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_normalises_expected_url_trailing_slash_and_query_order(self):
        sig = self._sign_v2(
            self._base_payload(
                successUrl=self._normalise_url(
                    "https://merchant.example/return?b=2&a=1"
                )
            )
        )
        # Caller passes a different but equivalent surface form.
        assert VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url="https://merchant.example/return/?a=1&b=2#fragment",
            expected_key_mode="test",
        )

    def test_rejects_stale_iat(self):
        sig = self._sign_v2(self._base_payload(iat=int(time.time()) - 1000))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
            max_age_seconds=600,
        )

    def test_rejects_far_future_iat(self):
        sig = self._sign_v2(self._base_payload(iat=int(time.time()) + 300))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_non_numeric_iat(self):
        sig = self._sign_v2(self._base_payload(iat="now"))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_payload_status_mismatch(self):
        sig = self._sign_v2(self._base_payload(status="failed"))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_payload_currency_mismatch(self):
        sig = self._sign_v2(self._base_payload(currency="EUR"))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_payload_transaction_id_mismatch(self):
        sig = self._sign_v2(self._base_payload(transactionId="txn_wrong"))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_payload_session_mismatch(self):
        sig = self._sign_v2(self._base_payload(sid="vps_test_other_999"))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_payload_amount_mismatch(self):
        sig = self._sign_v2(self._base_payload(amount=9999))
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_wrong_signing_secret(self):
        sig = self._sign_v2(self._base_payload(), secret="wrong_secret")
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_malformed_v2_structure(self):
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": "v2.malformed"},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_non_hex_hmac(self):
        garbage_b64 = self._b64url(b"{}")
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": f"v2.{garbage_b64}.notHexAtAll"},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_cross_merchant_url_replay(self):
        """Sig valid for merchant-A is rejected when replayed at merchant-B's verifier.

        v2's point is to defeat this attack — successUrl is bound into the
        signed payload AND compared against the verifier's canonical expected
        URL. Same secret, same other fields, different expected URL.
        """
        merchant_a = "https://merchant-a.example/return"
        merchant_b = "https://merchant-b.example/return"
        sig = self._sign_v2(
            self._base_payload(successUrl=self._normalise_url(merchant_a))
        )
        # Sig validates against merchant-A.
        assert VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=merchant_a,
            expected_key_mode="test",
        )
        # ...but rejected when replayed against merchant-B.
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=merchant_b,
            expected_key_mode="test",
        )

    def test_amount_int_payload_matches_string_url(self):
        """Pin the URL-vs-payload string-coercion rule (devsec note 2026-05-05)."""
        sig = self._sign_v2(self._base_payload(amount=1499))
        assert VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "amount": "1499", "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )

    def test_rejects_invalid_json_payload(self):
        garbage = self._b64url(b"not-json-at-all")
        signed_input = f"v2.{garbage}".encode("utf-8")
        hex_hmac = hmac_mod.new(
            self.SECRET.encode(), signed_input, hashlib.sha256
        ).hexdigest()
        sig = f"v2.{garbage}.{hex_hmac}"
        assert not VonPayCheckout.verify_return_signature(
            {**self.BASE_PARAMS, "sig": sig},
            self.SECRET,
            expected_success_url=self.SUCCESS_URL,
            expected_key_mode="test",
        )


class TestErrorReporter:
    """Phase 2 — error_reporter callback contract."""

    SECRET = "vp_sk_test_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

    def test_fires_on_construct_event_signature_failure(self):
        calls = []

        def reporter(err, ctx):
            calls.append((err, ctx))

        client = VonPayCheckout(self.SECRET, error_reporter=reporter)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        with pytest.raises(VonPayError):
            client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)
        assert len(calls) == 1
        err, ctx = calls[0]
        assert isinstance(err, VonPayError)
        assert ctx.method == "webhooks.construct_event"
        assert ctx.code == "webhook_invalid_signature"
        assert ctx.status == 401
        assert ctx.sdk_version

    def test_fires_on_construct_event_v2_stale_timestamp(self):
        calls = []

        def reporter(err, ctx):
            calls.append((err, ctx))

        client = VonPayCheckout(self.SECRET, error_reporter=reporter)
        body = json.dumps({"event": "session.succeeded"})
        old_ts = int(time.time()) - 600
        sig = hmac_mod.new(
            self.SECRET.encode(), f"{old_ts}.{body}".encode(), hashlib.sha256
        ).hexdigest()
        with pytest.raises(VonPayError):
            client.webhooks.construct_event_v2(body, f"t={old_ts},v2={sig}", self.SECRET)
        assert len(calls) == 1
        assert calls[0][1].method == "webhooks.construct_event_v2"

    def test_no_op_when_undefined(self):
        client = VonPayCheckout(self.SECRET)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        # Must still raise normally; absence of reporter must not change behavior.
        with pytest.raises(VonPayError):
            client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

    def test_swallows_reporter_throws(self, caplog):
        def bad_reporter(err, ctx):
            raise RuntimeError("integrator's Sentry is broken")

        client = VonPayCheckout(self.SECRET, error_reporter=bad_reporter)
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        # Original VonPayError must propagate; reporter throw must not replace it.
        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)
        assert any(
            "error_reporter raised" in record.message for record in caplog.records
        )

    def test_static_verify_signature_works_without_client(self):
        # verify_signature is staticmethod; calling on the class continues to
        # work without a client reference (no error_reporter integration).
        from vonpay.checkout.client import _Webhooks

        ok = _Webhooks.verify_signature("hello", "deadbeef" * 8, "any-secret")
        assert ok is False  # invalid sig, but didn't crash

    def _client_with_transport(self, reporter, *, responses, max_retries=0):
        """Build a VonPayCheckout whose underlying httpx.Client uses a
        MockTransport returning the given responses in order. Each response is
        a (status_code, json_body) tuple.
        """
        iter_responses = iter(responses)

        def handler(request: httpx.Request) -> httpx.Response:
            status, body = next(iter_responses)
            return httpx.Response(
                status_code=status,
                json=body,
                headers={"X-Request-Id": "req_test_123"},
            )

        client = VonPayCheckout(self.SECRET, error_reporter=reporter, max_retries=max_retries)
        # Swap the httpx client out for one with our mock transport. Close
        # the original so we don't leak its connection pool.
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_fires_on_non_retryable_4xx(self):
        calls = []
        client = self._client_with_transport(
            reporter=lambda err, ctx: calls.append((err, ctx)),
            responses=[
                (400, {"error": "Bad", "code": "validation_invalid_amount", "fix": "x", "docs": "y"}),
            ],
        )
        with pytest.raises(VonPayError):
            client.sessions.create(amount=-1, currency="USD")
        assert len(calls) == 1
        err, ctx = calls[0]
        assert isinstance(err, VonPayError)
        assert ctx.method == "sessions.create"
        assert ctx.url == "https://checkout.vonpay.com/v1/sessions"  # query stripped
        assert ctx.status == 400
        assert ctx.code == "validation_invalid_amount"
        assert ctx.request_id == "req_test_123"
        assert ctx.attempt == 0

    def test_fires_once_after_retry_exhaustion(self):
        calls = []
        client = self._client_with_transport(
            reporter=lambda err, ctx: calls.append((err, ctx)),
            # 503 is retryable; with max_retries=1 we expect 2 attempts → fire once
            responses=[
                (503, {"error": "down", "code": "internal_error", "fix": "x", "docs": "y"}),
                (503, {"error": "down", "code": "internal_error", "fix": "x", "docs": "y"}),
            ],
            max_retries=1,
        )
        with pytest.raises(VonPayError):
            client.sessions.get("vp_cs_x")
        assert len(calls) == 1
        assert calls[0][1].method == "sessions.get"
        assert calls[0][1].status == 503
        assert calls[0][1].attempt == 1  # final attempt index

    def test_url_strips_query_string(self):
        calls = []
        client = self._client_with_transport(
            reporter=lambda err, ctx: calls.append((err, ctx)),
            responses=[
                (400, {"error": "Bad", "code": "validation_error", "fix": "x", "docs": "y"}),
            ],
        )
        # validate() appends ?dry_run=true. Reporter ctx must NOT include it.
        with pytest.raises(VonPayError):
            client.sessions.validate(amount=-1, currency="USD")
        assert calls[0][1].method == "sessions.validate"
        assert calls[0][1].url == "https://checkout.vonpay.com/v1/sessions"
        assert "dry_run" not in (calls[0][1].url or "")


class TestErrorSelfHeal:
    """Phase 2.5 — VonPayError self-heal helpers (retryable / next_action / llm_hint)."""

    def test_attaches_helpers_synthesized_from_code(self):
        err = VonPayError(
            status=401,
            error="API key is malformed",
            code="auth_invalid_key",
            fix="Check the key",
            docs="https://docs.vonpay.com",
            request_id="req_abc",
        )
        assert err.retryable is False
        assert err.next_action == "rotate_key"
        assert "malformed" in err.llm_hint

    def test_5xx_retryable_codes(self):
        err = VonPayError(
            status=503,
            error="down",
            code="provider_unavailable",
            fix="x",
            docs="y",
        )
        assert err.retryable is True
        assert err.next_action == "wait_and_retry"

    def test_card_decline_is_ignore(self):
        err = VonPayError(
            status=402,
            error="Card declined",
            code="provider_charge_failed",
            fix="x",
            docs="y",
        )
        assert err.retryable is False
        assert err.next_action == "ignore"

    def test_unknown_code_falls_back_to_contact_support(self):
        err = VonPayError(
            status=500,
            error="future error",
            code="future_unknown_code",  # type: ignore[arg-type]
            fix="x",
            docs="y",
        )
        assert err.next_action == "contact_support"
        assert "future_unknown_code" in err.llm_hint

    def test_help_for_function(self):
        from vonpay.checkout import help_for

        h = help_for("rate_limit_exceeded")
        assert h.retryable is True
        assert h.next_action == "wait_and_retry"


class TestDefaultReporter:
    """Phase 2.5 — default error_reporter behaviour when no callback is configured."""

    SECRET = "vp_sk_test_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

    def test_fires_logging_warning_when_no_callback_and_outside_pytest(self, monkeypatch, caplog):
        # Auto-silenced under pytest by the PYTEST_CURRENT_TEST guard. To
        # exercise the FIRES path, temporarily delete that env var.
        monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)
        monkeypatch.delenv("VONPAY_QUIET", raising=False)

        client = VonPayCheckout(self.SECRET)  # no error_reporter — default path
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        assert any("[vonpay]" in rec.message for rec in caplog.records), (
            "default reporter should emit a [vonpay]-prefixed warning when no callback is configured"
        )
        # Structured payload should include code + retryable + next_action
        log_messages = " ".join(rec.message for rec in caplog.records)
        assert "webhook_invalid_signature" in log_messages
        assert "next_action" in log_messages or "retryable" in log_messages

    def test_silenced_under_pytest_auto(self, caplog):
        # Inside pytest (PYTEST_CURRENT_TEST is set automatically by pytest
        # itself), the default reporter must NOT fire. This is the path that
        # protects test runs from log noise.
        # v0.7.0+: explicit telemetry opt-out so the disclosure warn (a
        # WARNING log) doesn't fire under the test-key default-on policy.
        client = VonPayCheckout(self.SECRET, telemetry={"enabled": False})
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        # Caplog should be empty (or contain only test-framework warnings,
        # not vonpay default-reporter warnings)
        vonpay_warnings = [
            rec for rec in caplog.records if "[vonpay]" in rec.message
        ]
        assert vonpay_warnings == []

    def test_silenced_when_VONPAY_QUIET_set(self, monkeypatch, caplog):
        monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)
        monkeypatch.setenv("VONPAY_QUIET", "1")

        client = VonPayCheckout(self.SECRET, telemetry={"enabled": False})
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        # Filter to default-reporter warnings only (excluding telemetry
        # background-thread bleed from earlier default-on-test-key tests
        # under the v0.7.0 policy). The default reporter's signature is
        # "no error_reporter callback" — distinct prefix from telemetry's
        # "telemetry:" prefix.
        vonpay_warnings = [
            rec for rec in caplog.records
            if "[vonpay]" in rec.message and "telemetry" not in rec.message
        ]
        assert vonpay_warnings == []

    def test_explicit_callback_overrides_default(self, monkeypatch, caplog):
        # When an integrator passes an explicit error_reporter, the default
        # logging.warning must NOT fire — only their callback.
        monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)

        calls = []

        def reporter(err, ctx):
            calls.append((err, ctx))

        # v0.7.0+ test-key default-on telemetry would fire its disclosure
        # warn here; explicit opt-out keeps the assertion focused on
        # "explicit callback overrides default warn".
        client = VonPayCheckout(self.SECRET, error_reporter=reporter, telemetry={"enabled": False})
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, self.SECRET, ts)

        assert len(calls) == 1  # explicit reporter fired
        # Default reporter should NOT have fired
        vonpay_warnings = [
            rec for rec in caplog.records if "[vonpay]" in rec.message and "error_reporter raised" not in rec.message
        ]
        assert vonpay_warnings == []


class TestPaymentIntents:
    """SDK 0.5.0 — payment_intents namespace (create only).

    Wire format mirrors the live server response shape (snake_case throughout).
    """

    KEY = "vp_sk_test_paymentintents_key_001"

    INTENT_WIRE = {
        "id": "vpi_test_abc123",
        "status": "succeeded",
        "amount": 1499,
        "currency": "USD",
        "capture_method": "automatic",
        "next_action": None,
        "decline_code": None,
        "created_at": "2026-05-04T16:00:00Z",
        # Mixed-case keys to prove the conversion does NOT touch metadata in
        # either direction. order_id has an underscore; mixedCase has a
        # capital. Both must round-trip verbatim (sdk/metadata-keys-opaque).
        "metadata": {"order_id": "ord_42", "mixedCase": "kept"},
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_create_posts_snake_case_body_and_returns_intent(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            captured["method"] = req.method
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        intent = client.payment_intents.create(
            amount=1499,
            currency="usd",
            capture_method="automatic",
            # Caller-supplied metadata keys must reach the wire VERBATIM.
            # The server stores keys as-given; converting them would silently
            # corrupt integrator data on round-trip.
            metadata={"order_id": "ord_42", "mixedCase": "kept"},
        )

        # Wire body is snake_case (server's Zod schema rejects camelCase),
        # but metadata keys pass through unchanged in both directions.
        assert captured["url"] == "https://checkout.vonpay.com/v1/payment_intents"
        assert captured["method"] == "POST"
        assert captured["body"] == {
            "amount": 1499,
            "currency": "usd",
            "capture_method": "automatic",
            "metadata": {"order_id": "ord_42", "mixedCase": "kept"},
        }

        # Response is parsed into the snake_case Python dataclass; metadata
        # echoed back verbatim.
        assert intent.id == "vpi_test_abc123"
        assert intent.status == "succeeded"
        assert intent.amount == 1499
        assert intent.currency == "USD"
        assert intent.capture_method == "automatic"
        assert intent.next_action is None
        assert intent.decline_code is None
        assert intent.created_at == "2026-05-04T16:00:00Z"
        assert intent.metadata == {"order_id": "ord_42", "mixedCase": "kept"}

    def test_create_omits_unset_optional_fields(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(amount=1499, currency="usd")
        body = captured["body"]
        assert body == {"amount": 1499, "currency": "usd"}
        assert "capture_method" not in body
        assert "metadata" not in body

    def test_create_forwards_idempotency_key(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["idempotency_key"] = req.headers.get("Idempotency-Key")
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=1499,
            currency="usd",
            idempotency_key="ord_42-charge-1",
        )
        assert captured["idempotency_key"] == "ord_42-charge-1"

    def test_create_surfaces_endpoint_not_implemented(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                501,
                json={
                    "error": "Not implemented",
                    "code": "endpoint_not_implemented",
                    "fix": "Processor flag is not flipped",
                    "docs": "https://docs.vonpay.com/reference/error-codes",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.payment_intents.create(amount=1499, currency="usd")
        assert exc_info.value.code == "endpoint_not_implemented"

    # SDK 0.6.1 — MIT block (Sortie G)
    def test_create_forwards_mit_block_as_snake_case(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=1499,
            currency="usd",
            mit=MITBlock(
                initiator="merchant",
                reason="recurring",
                original_transaction_id="vpi_test_anchor001",
            ),
        )
        assert captured["body"] == {
            "amount": 1499,
            "currency": "usd",
            "mit": {
                "initiator": "merchant",
                "reason": "recurring",
                "original_transaction_id": "vpi_test_anchor001",
            },
        }

    def test_create_omits_mit_when_not_provided(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(amount=1499, currency="usd")
        assert "mit" not in captured["body"]

    def test_create_supports_customer_initiated_mit(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=2999,
            currency="usd",
            mit=MITBlock(
                initiator="customer",
                reason="unscheduled",
                original_transaction_id="vpi_test_anchor002",
            ),
        )
        assert captured["body"]["mit"] == {
            "initiator": "customer",
            "reason": "unscheduled",
            "original_transaction_id": "vpi_test_anchor002",
        }

    def test_create_supports_installment_mit_reason(self):
        # The third MITReason enum value — distinct scheme code path from
        # recurring/unscheduled. Catches typo regressions in the explicit
        # wire mapping.
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=4999,
            currency="usd",
            mit=MITBlock(
                initiator="merchant",
                reason="installment",
                original_transaction_id="vpi_test_anchor003",
            ),
        )
        assert captured["body"]["mit"] == {
            "initiator": "merchant",
            "reason": "installment",
            "original_transaction_id": "vpi_test_anchor003",
        }


class TestPaymentIntentsMirrorBlock:
    """Typed mirror block (unreleased; awaits receiver-side enablement).

    Parity with Node SDK ``mirror block (unreleased)`` describe in
    ``client.test.ts``.
    """

    KEY = "vp_sk_test_mirror_pi_key_001"

    INTENT_WIRE = {
        "id": "vpi_test_mirror_001",
        "status": "succeeded",
        "amount": 1499,
        "currency": "USD",
        "capture_method": "automatic",
        "next_action": None,
        "decline_code": None,
        "created_at": "2026-05-20T00:00:00Z",
        "metadata": {},
    }

    def _minimal_mirror(self) -> MirrorBlock:
        return MirrorBlock(
            destination="shopify",
            shop="test-shop.myshopify.com",
            line_items=[MirrorLineItem(title="Widget", quantity=1, price="12.50")],
            customer=MirrorCustomer(email="buyer@example.com"),
        )

    def _client_with_handler(self, handler) -> VonPayCheckout:
        # Matches the rest of test_client.py: construct, close the default
        # client, then swap ``_client`` for one backed by an httpx
        # MockTransport. The public ``VonPayCheckout.__init__`` does not
        # accept a transport.
        import httpx

        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_create_forwards_mirror_block_as_snake_case_wire(self):
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=1499,
            currency="usd",
            mirror=MirrorBlock(
                destination="shopify",
                shop="test-shop.myshopify.com",
                line_items=[MirrorLineItem(title="Widget", quantity=1, price="12.50")],
                customer=MirrorCustomer(email="buyer@example.com"),
                shipping_address=MirrorAddress(
                    address1="1 Market St",
                    city="San Francisco",
                    province="CA",
                    zip="94103",
                    country="US",
                    first_name="Ada",
                    last_name="Lovelace",
                ),
                financial_status="paid",
                send_receipt=False,
            ),
        )
        assert captured["body"]["mirror"] == {
            # contract_version auto-filled by SDK from MIRROR_CONTRACT_VERSION.
            "contract_version": "2026-05-15",
            "destination": "shopify",
            "shop": "test-shop.myshopify.com",
            "line_items": [
                {"title": "Widget", "quantity": 1, "price": "12.50"}
            ],
            "customer": {"email": "buyer@example.com"},
            "shipping_address": {
                "address1": "1 Market St",
                "city": "San Francisco",
                "province": "CA",
                "zip": "94103",
                "country": "US",
                "first_name": "Ada",
                "last_name": "Lovelace",
            },
            "financial_status": "paid",
            "send_receipt": False,
        }

    def test_create_auto_fills_contract_version_when_omitted(self):
        # Required-when-present per the v2 contract; without auto-fill the
        # server would return validation_missing_field 422.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=1499,
            currency="usd",
            mirror=self._minimal_mirror(),
        )
        assert captured["body"]["mirror"]["contract_version"] == MIRROR_CONTRACT_VERSION

    def test_create_preserves_caller_supplied_contract_version(self):
        # Caller pinning an explicit revision must NOT be silently
        # overwritten by the SDK default.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.contract_version = "2099-01-01"
        client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
        assert captured["body"]["mirror"]["contract_version"] == "2099-01-01"

    def test_create_omits_mirror_when_not_provided(self):
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(amount=1499, currency="usd")
        assert "mirror" not in captured["body"]

    def test_create_serializes_skip_opt_out(self):
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.skip = True
        client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
        assert captured["body"]["mirror"]["skip"] is True

    def test_create_serializes_tax_lines_on_line_items(self):
        # Nested-object array — catches regressions in the explicit wire
        # mapping for MirrorLineItem.tax_lines.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=1499,
            currency="usd",
            mirror=MirrorBlock(
                destination="shopify",
                shop="test-shop.myshopify.com",
                line_items=[
                    MirrorLineItem(
                        title="Widget",
                        quantity=1,
                        price="12.50",
                        tax_lines=[
                            MirrorTaxLine(price="0.75", rate=0.06, title="State Tax")
                        ],
                    ),
                ],
                customer=MirrorCustomer(email="buyer@example.com"),
            ),
        )
        line_item = captured["body"]["mirror"]["line_items"][0]
        assert line_item["tax_lines"] == [
            {"price": "0.75", "rate": 0.06, "title": "State Tax"}
        ]

    def test_create_serializes_note_attributes(self):
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.note_attributes = [
            MirrorNoteAttribute(name="vora_ref", value="vpi_test_abc"),
            MirrorNoteAttribute(name="channel", value="upsell"),
        ]
        client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
        assert captured["body"]["mirror"]["note_attributes"] == [
            {"name": "vora_ref", "value": "vpi_test_abc"},
            {"name": "channel", "value": "upsell"},
        ]

    def test_create_preserves_mirror_alongside_mit_and_metadata(self):
        # All three optional request-body extensions (metadata, mit, mirror)
        # must coexist as siblings — not nested inside one another.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.create(
            amount=1499,
            currency="usd",
            metadata={"order_id": "ord_42"},
            mit=MITBlock(
                initiator="merchant",
                reason="recurring",
                original_transaction_id="vpi_test_anchor",
            ),
            mirror=self._minimal_mirror(),
        )
        body = captured["body"]
        assert body["metadata"] == {"order_id": "ord_42"}
        assert body["mit"]["original_transaction_id"] == "vpi_test_anchor"
        assert body["mirror"]["destination"] == "shopify"
        assert "metadata" not in body["mirror"]
        assert "mirror" not in body["metadata"]

    def test_create_serializes_tags_array_to_wire_unchanged(self):
        # Tags pass through verbatim. Server-side sanitization (comma
        # stripping, 255-char cap, reserved-string blocklist) is the
        # enforcement boundary. Locks the no-client-side-mutation posture.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.tags = ["vora-renewal", "channel:upsell", "ref-12345"]
        client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
        assert captured["body"]["mirror"]["tags"] == [
            "vora-renewal",
            "channel:upsell",
            "ref-12345",
        ]

    def test_create_serializes_billing_address_separately_from_shipping(self):
        # ``_mirror_block_to_dict`` has independent branches for
        # shipping_address and billing_address. A regression that conflates
        # them would silently misroute physical orders.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.shipping_address = MirrorAddress(
            address1="1 Ship St", city="Boston", province="MA", zip="02110", country="US"
        )
        mirror.billing_address = MirrorAddress(
            address1="1 Bill Ave", city="Cambridge", province="MA", zip="02139", country="US"
        )
        client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
        body = captured["body"]
        assert body["mirror"]["shipping_address"]["address1"] == "1 Ship St"
        assert body["mirror"]["shipping_address"]["city"] == "Boston"
        assert body["mirror"]["billing_address"]["address1"] == "1 Bill Ave"
        assert body["mirror"]["billing_address"]["city"] == "Cambridge"

    def test_create_serializes_origin_to_wire_unchanged(self):
        # ``origin`` is a free-form string used by Vonpay for default
        # tagging. Must reach the wire byte-identical.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.origin = "subscription_renewal"
        client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
        assert captured["body"]["mirror"]["origin"] == "subscription_renewal"

    def test_create_serializes_skip_false_to_wire(self):
        # Catches a refactor of ``_mirror_block_to_dict`` that flips the
        # ``if m.skip is not None`` check to ``if m.skip:`` — the falsy
        # collapse would silently drop ``skip=False`` even though the
        # caller explicitly chose to override the server default.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.INTENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.skip = False
        client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
        assert captured["body"]["mirror"]["skip"] is False

    def test_create_passes_malformed_shop_through_to_server_unchanged(self):
        # The OpenAPI ``shop`` regex is the *server's* validation contract.
        # The SDK does NOT enforce client-side. This test documents the
        # pass-through posture so an integrator reading the spec doesn't
        # expect a client-side TypeError on a bad shop.
        import httpx
        import json

        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                422,
                json={"error": "Shop format invalid", "code": "validation_error"},
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        mirror = self._minimal_mirror()
        mirror.shop = "not-a-shopify-host.example.com"
        try:
            client.payment_intents.create(amount=1499, currency="usd", mirror=mirror)
            raise AssertionError("expected server-side 422 to raise")
        except VonPayError as err:
            assert err.status == 422
        # The SDK fired the request — server is the enforcement boundary.
        assert captured["body"]["mirror"]["shop"] == "not-a-shopify-host.example.com"


class TestCapabilities:
    """SDK 0.5.0 — capabilities namespace (get).

    Wire shape mirrors the live staging response.
    """

    KEY = "vp_sk_test_capabilities_key_001"

    CAPS_WIRE = {
        "supported_operations": {
            "auth_capture_separation": True,
            "partial_capture": True,
            "partial_refund": True,
            "unreferenced_refund": False,
            "void_after_capture": "rerouted_to_refund",
            "mit": True,
            "network_tokens": True,
            "three_d_secure_2": False,
            "ach": False,
            "payouts_api": False,
        },
        "settlement_currencies": ["USD", "EUR", "GBP"],
        "rate_limits": {"payment_intents_per_minute": 100},
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_get_returns_matrix(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            captured["method"] = req.method
            return httpx.Response(
                200, json=self.CAPS_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        caps = client.capabilities.get()
        assert captured["url"] == "https://checkout.vonpay.com/v1/capabilities"
        assert captured["method"] == "GET"
        assert caps.supported_operations.auth_capture_separation is True
        assert caps.supported_operations.partial_capture is True
        assert caps.supported_operations.unreferenced_refund is False
        assert caps.supported_operations.void_after_capture == "rerouted_to_refund"
        assert caps.supported_operations.network_tokens is True
        assert caps.supported_operations.three_d_secure_2 is False
        assert caps.supported_operations.payouts_api is False
        assert caps.settlement_currencies == ["USD", "EUR", "GBP"]
        assert caps.rate_limits.payment_intents_per_minute == 100

    def test_get_surfaces_endpoint_not_implemented(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                501,
                json={
                    "error": "Not implemented",
                    "code": "endpoint_not_implemented",
                    "fix": "Processor flag is not flipped in production yet",
                    "docs": "https://docs.vonpay.com/reference/error-codes",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.capabilities.get()
        assert exc_info.value.code == "endpoint_not_implemented"


class TestSessionsWireFormat:
    """Sessions namespace wire-format guards.

    sessions.create uses camelCase on the wire (legacy /v1/sessions contract).
    sessions.get must percent-encode the path segment (devsec).
    """

    KEY = "vp_sk_test_sessions_key_001"

    SESSION_WIRE = {
        "id": "vps_test_abc123",
        "checkout_url": "https://checkout-staging.vonpay.com/c/vps_test_abc123",
        "expires_at": "2026-05-05T17:00:00Z",
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_create_passes_metadata_keys_through_unchanged(self):
        """Integrator-defined metadata keys must NOT be camel-cased on the way out."""
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.SESSION_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.sessions.create(
            amount=1499,
            currency="usd",
            success_url="https://example.com/ok",
            cancel_url="https://example.com/cancel",
            metadata={"order_id": "ord_42", "mixedCase": "kept"},
        )

        # Top-level wire keys are camelCase (legacy /v1/sessions contract);
        # metadata sub-keys pass through verbatim (sdk/metadata-keys-opaque).
        assert captured["body"]["successUrl"] == "https://example.com/ok"
        assert captured["body"]["cancelUrl"] == "https://example.com/cancel"
        assert captured["body"]["metadata"] == {
            "order_id": "ord_42",
            "mixedCase": "kept",
        }

    def test_get_rejects_path_injection_via_allowlist(self):
        """Allowlist guard fires before urllib.quote — slash escapes are rejected
        with a clear error message rather than being silently encoded.
        """
        client = VonPayCheckout(self.KEY)
        with pytest.raises(ValueError, match="session_id contains characters outside"):
            client.sessions.get("evil/id with?query")

    def test_get_rejects_oversize_or_empty_session_id(self):
        client = VonPayCheckout(self.KEY)
        with pytest.raises(ValueError, match="session_id must be a non-empty string"):
            client.sessions.get("")
        with pytest.raises(ValueError, match="exceeds 256 chars"):
            client.sessions.get("a" * 300)

    def test_get_percent_encodes_session_id(self):
        """Session id is path-encoded so a malicious id can't escape the path.

        With the allowlist guard in place, this test pins the canonical-id
        URL shape — quote() is a no-op on alphanumeric+underscore+hyphen.
        """
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            return httpx.Response(
                200,
                json={
                    "id": "vps_test_x",
                    "status": "succeeded",
                    "mode": "payment",
                    "merchant_id": "m_test",
                    "amount": 1499,
                    "currency": "USD",
                    "created_at": "2026-05-05T00:00:00Z",
                    "updated_at": "2026-05-05T00:00:00Z",
                    "expires_at": "2026-05-05T01:00:00Z",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        # The allowlist guard rejects the slash/space/question-mark string
        # before quote() runs (covered by test_get_rejects_path_injection_via_allowlist).
        # This test exercises the canonical-id encode path: alphanumerics +
        # underscore + hyphen pass through unchanged, the URL preserves shape.
        client.sessions.get("vps_test_AbC-123_xyz")
        assert (
            captured["url"]
            == "https://checkout.vonpay.com/v1/sessions/vps_test_AbC-123_xyz"
        )


class TestSessionsCreateNodeParity:
    """sessions.create — Node parity surface (mode, locale, buyer_*, line_items,
    collect_shipping, expires_in).

    The legacy /v1/sessions wire is camelCase at the top level. These tests pin
    the snake_case → camelCase boundary translation and confirm each new field
    reaches the wire intact.
    """

    KEY = "vp_sk_test_sessions_parity_key_001"

    SESSION_WIRE = {
        "id": "vps_test_parity_001",
        "checkout_url": "https://checkout-staging.vonpay.com/c/vps_test_parity_001",
        "expires_at": "2026-05-16T17:00:00Z",
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def _capture_body(self):
        """Return (handler, captured) — handler stores the JSON body in captured["body"]."""
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                201, json=self.SESSION_WIRE, headers={"X-Request-Id": "req_parity"}
            )

        return handler, captured

    def test_create_passes_mode_through(self):
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(amount=5000, currency="usd", mode="payment")
        assert captured["body"]["mode"] == "payment"

    def test_create_omits_mode_when_not_provided(self):
        """Server defaults mode to ``payment`` when omitted — caller should
        not have to send it. ``_to_camel_keys`` drops None values."""
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(amount=5000, currency="usd")
        assert "mode" not in captured["body"]

    def test_create_passes_locale_through(self):
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(amount=5000, currency="usd", locale="en-US")
        assert captured["body"]["locale"] == "en-US"

    def test_create_passes_buyer_fields_camelcased(self):
        """buyer_id / buyer_name / buyer_email → buyerId / buyerName / buyerEmail."""
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(
            amount=5000,
            currency="usd",
            buyer_id="cust_abc123",
            buyer_name="Jane Doe",
            buyer_email="jane@example.com",
        )
        assert captured["body"]["buyerId"] == "cust_abc123"
        assert captured["body"]["buyerName"] == "Jane Doe"
        assert captured["body"]["buyerEmail"] == "jane@example.com"
        # snake_case keys must NOT leak onto the wire.
        assert "buyer_id" not in captured["body"]
        assert "buyer_name" not in captured["body"]
        assert "buyer_email" not in captured["body"]

    def test_create_passes_collect_shipping_camelcased(self):
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(
            amount=5000, currency="usd", collect_shipping=True
        )
        assert captured["body"]["collectShipping"] is True
        assert "collect_shipping" not in captured["body"]

    def test_create_passes_expires_in_camelcased(self):
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(amount=5000, currency="usd", expires_in=1800)
        assert captured["body"]["expiresIn"] == 1800
        assert "expires_in" not in captured["body"]

    def test_create_serializes_line_items_with_camelcase_subkeys(self):
        """line_items wire shape pins the LineItem sub-dict camelCase mapping
        (unit_amount → unitAmount, image_url → imageUrl). _to_camel_keys is a
        shallow conversion so the LineItem mapping is done explicitly inside
        Sessions.create — this test guards the explicit-mapping contract.
        """
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(
            amount=12500,
            currency="USD",
            line_items=[
                LineItem(
                    name="Widget Pro",
                    quantity=2,
                    unit_amount=4500,
                    image_url="https://cdn.example.com/widget.png",
                ),
                LineItem(name="Shipping", quantity=1, unit_amount=3500),
            ],
        )
        assert captured["body"]["lineItems"] == [
            {
                "name": "Widget Pro",
                "quantity": 2,
                "unitAmount": 4500,
                "imageUrl": "https://cdn.example.com/widget.png",
            },
            {
                "name": "Shipping",
                "quantity": 1,
                "unitAmount": 3500,
                # image_url omitted → imageUrl absent (matches Node's optional shape).
            },
        ]
        # snake_case must NOT leak onto the wire — Node parity.
        assert "line_items" not in captured["body"]
        for item in captured["body"]["lineItems"]:
            assert "unit_amount" not in item
            assert "image_url" not in item

    def test_create_omits_line_items_when_none(self):
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(amount=5000, currency="usd")
        assert "lineItems" not in captured["body"]

    def test_create_full_payload_matches_openapi_example(self):
        """End-to-end: the OpenAPI ``full`` example body should be reproducible
        from the Python SDK with the equivalent snake_case kwargs. Pins the
        complete Node-parity surface in one assertion.
        """
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(
            amount=12500,
            currency="USD",
            country="US",
            mode="payment",
            description="Order #1042",
            locale="en-US",
            success_url="https://example.com/success",
            cancel_url="https://example.com/cancel",
            buyer_id="cust_abc123",
            buyer_name="Jane Doe",
            buyer_email="jane@example.com",
            collect_shipping=True,
            expires_in=1800,
            metadata={"orderId": "1042", "source": "web"},
            line_items=[
                LineItem(
                    name="Widget Pro",
                    quantity=2,
                    unit_amount=4500,
                    image_url="https://cdn.example.com/widget.png",
                ),
                LineItem(name="Shipping", quantity=1, unit_amount=3500),
            ],
        )
        assert captured["body"] == {
            "amount": 12500,
            "currency": "USD",
            "country": "US",
            "mode": "payment",
            "description": "Order #1042",
            "locale": "en-US",
            "successUrl": "https://example.com/success",
            "cancelUrl": "https://example.com/cancel",
            "buyerId": "cust_abc123",
            "buyerName": "Jane Doe",
            "buyerEmail": "jane@example.com",
            "collectShipping": True,
            "expiresIn": 1800,
            "metadata": {"orderId": "1042", "source": "web"},
            "lineItems": [
                {
                    "name": "Widget Pro",
                    "quantity": 2,
                    "unitAmount": 4500,
                    "imageUrl": "https://cdn.example.com/widget.png",
                },
                {
                    "name": "Shipping",
                    "quantity": 1,
                    "unitAmount": 3500,
                },
            ],
        }

    def test_create_minimal_payload_unchanged(self):
        """Backwards compatibility: a call with only amount + currency produces
        the same minimal wire body as before the Node-parity expansion."""
        handler, captured = self._capture_body()
        client = self._client_with_handler(handler)
        client.sessions.create(amount=5000, currency="usd")
        assert captured["body"] == {"amount": 5000, "currency": "USD"}


class TestPaymentIntentCapture:
    """SDK 0.6.x — paymentIntents.capture (POST /v1/payment_intents/{id}/capture)."""

    KEY = "vp_sk_test_capture_key_001"
    AUTHORIZED_INTENT = {
        "id": "vpi_test_auth_001",
        "status": "authorized",
        "amount": 5000,
        "currency": "USD",
        "capture_method": "manual",
        "next_action": None,
        "decline_code": None,
        "created_at": "2026-05-05T18:00:00Z",
        "metadata": {},
    }
    CAPTURED_INTENT = {**AUTHORIZED_INTENT, "status": "succeeded"}

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_captures_full_authorized_amount_with_empty_body(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            captured["method"] = req.method
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.CAPTURED_INTENT, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        intent = client.payment_intents.capture("vpi_test_auth_001")

        assert (
            captured["url"]
            == "https://checkout.vonpay.com/v1/payment_intents/vpi_test_auth_001/capture"
        )
        assert captured["method"] == "POST"
        assert captured["body"] == {}
        assert intent.status == "succeeded"
        # capture_method must round-trip — guard against silent field drop
        # in _payment_intent_from_dict.
        assert intent.capture_method == "manual"

    def test_captures_partial_via_amount_to_capture(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200,
                json={**self.CAPTURED_INTENT, "amount": 2000},
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        client.payment_intents.capture("vpi_test_auth_001", amount_to_capture=2000)
        assert captured["body"] == {"amount_to_capture": 2000}

    def test_rejects_path_injection_via_allowlist(self):
        client = VonPayCheckout(self.KEY)
        with pytest.raises(ValueError, match="contains characters outside"):
            client.payment_intents.capture("evil/id with?query")

    def test_rejects_empty_or_oversize_id(self):
        client = VonPayCheckout(self.KEY)
        with pytest.raises(ValueError, match="must be a non-empty string"):
            client.payment_intents.capture("")
        with pytest.raises(ValueError, match="exceeds 256 chars"):
            client.payment_intents.capture("a" * 300)

    def test_rejects_non_string_id_with_type_error(self):
        """Non-string ids raise TypeError (programming bug), not ValueError.

        Python idiom: TypeError = wrong type, ValueError = correctly-typed
        but-bad-content. Mirrors devsec MEDIUM split.
        """
        client = VonPayCheckout(self.KEY)
        with pytest.raises(TypeError, match="must be a string"):
            client.payment_intents.capture(None)  # type: ignore[arg-type]
        with pytest.raises(TypeError, match="must be a string"):
            client.payment_intents.capture(12345)  # type: ignore[arg-type]

    def test_accepts_canonical_id_shape(self):
        """Canonical IDs (alphanumerics + underscore + hyphen) pass the
        allowlist and produce a clean URL via quote().
        """
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            return httpx.Response(
                200, json=self.CAPTURED_INTENT, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.capture("vpi_test_AbC-123_xyz")
        assert (
            captured["url"]
            == "https://checkout.vonpay.com/v1/payment_intents/vpi_test_AbC-123_xyz/capture"
        )

    def test_forwards_idempotency_key(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["idempotency_key"] = req.headers.get("Idempotency-Key")
            return httpx.Response(
                200, json=self.CAPTURED_INTENT, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.capture(
            "vpi_test_auth_001", idempotency_key="ord_42-cap-1"
        )
        assert captured["idempotency_key"] == "ord_42-cap-1"

    def test_combined_partial_capture_with_idempotency_key(self):
        """Both kwargs together — body field + header in one call."""
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            captured["idempotency_key"] = req.headers.get("Idempotency-Key")
            return httpx.Response(
                200,
                json={**self.CAPTURED_INTENT, "amount": 2000},
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        client.payment_intents.capture(
            "vpi_test_auth_001",
            amount_to_capture=2000,
            idempotency_key="ord_42-cap-partial",
        )
        assert captured["body"] == {"amount_to_capture": 2000}
        assert captured["idempotency_key"] == "ord_42-cap-partial"

    def test_surfaces_invalid_transition_with_lifecycle_envelope(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "payment_intent": "vpi_test_auth_001",
                    "current_status": "succeeded",
                    "reject_reason": "terminal_state",
                    "error": "cannot capture: terminal_state",
                    "code": "invalid_transition",
                    "fix": "...",
                    "docs": "https://docs.vonpay.com/reference/error-codes#invalid_transition",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.payment_intents.capture("vpi_test_auth_001")

        err = exc_info.value
        assert err.code == "invalid_transition"
        assert err.payment_intent == "vpi_test_auth_001"
        assert err.current_status == "succeeded"
        assert err.reject_reason == "terminal_state"
        # error_help maps invalid_transition → next_action="ignore"
        assert err.next_action == "ignore"
        assert err.retryable is False

    def test_drops_out_of_enum_lifecycle_fields(self):
        """Misbehaving server can't type-launder bad strings into enum fields."""
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "payment_intent": "vpi_test_auth_001",
                    "current_status": "<script>alert(1)</script>",
                    "reject_reason": "x" * 1024,
                    "error": "lifecycle",
                    "code": "invalid_transition",
                    "fix": "...",
                    "docs": "https://docs.vonpay.com",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.payment_intents.capture("vpi_test_auth_001")
        err = exc_info.value
        # Out-of-enum values dropped
        assert err.current_status is None
        assert err.reject_reason is None
        # payment_intent is a free-form string but bounded at 256 chars
        assert err.payment_intent == "vpi_test_auth_001"

    def test_scrubs_log_injection_chars_from_server_strings(self):
        """Server-controlled free-text fields (error/fix/docs/code) are
        sanitised so a rogue endpoint can't forge separate log records by
        embedding CR/LF/NUL/ANSI escape sequences. devsec MEDIUM 2026-05-05.
        """
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "error": "bad input\n[vonpay] CRITICAL forged log line",
                    "code": "validation_error\x1b[31mred",
                    "fix": "fix\rcarriage return",
                    "docs": "https://docs.vonpay.com\x00null",
                },
                headers={"X-Request-Id": "ok-request-id-123"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.payment_intents.capture("vpi_test_auth_001")
        err = exc_info.value
        # No control chars, no ANSI escape sequences in any user-visible field.
        assert "\n" not in str(err)
        assert "\r" not in err.fix
        assert "\x00" not in err.docs
        assert "\x1b" not in err.code
        # Functional content is preserved.
        assert err.code.startswith("validation_error")

    def test_request_id_with_log_injection_chars_is_dropped(self):
        """request_id must match the canonical ID shape or be dropped — no
        scrub-and-keep, since it's used for correlation and a partial value
        is worse than no value.
        """
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "error": "boom",
                    "code": "validation_error",
                    "fix": "...",
                    "docs": "https://docs.vonpay.com",
                },
                # Server-side request id with embedded CR/LF.
                headers={"X-Request-Id": "evil\nreq_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.payment_intents.capture("vpi_test_auth_001")
        # Bad-shape request_id is dropped, not partially preserved.
        assert exc_info.value.request_id is None

    def test_drops_oversize_payment_intent_string(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "payment_intent": "x" * 300,
                    "current_status": "succeeded",
                    "reject_reason": "terminal_state",
                    "error": "lifecycle",
                    "code": "invalid_transition",
                    "fix": "...",
                    "docs": "https://docs.vonpay.com",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.payment_intents.capture("vpi_test_auth_001")
        err = exc_info.value
        assert err.payment_intent is None  # capped
        # Valid enum values still come through
        assert err.current_status == "succeeded"
        assert err.reject_reason == "terminal_state"


class TestPaymentIntentVoid:
    """SDK 0.6.x — paymentIntents.void (POST /v1/payment_intents/{id}/void)."""

    KEY = "vp_sk_test_void_key_001"
    AUTHORIZED_INTENT = {
        "id": "vpi_test_auth_002",
        "status": "authorized",
        "amount": 5000,
        "currency": "USD",
        "capture_method": "manual",
        "next_action": None,
        "decline_code": None,
        "created_at": "2026-05-05T18:00:00Z",
        "metadata": {},
    }
    VOIDED_INTENT = {**AUTHORIZED_INTENT, "status": "voided"}

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_voids_with_empty_body(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.VOIDED_INTENT, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        intent = client.payment_intents.void("vpi_test_auth_002")
        assert (
            captured["url"]
            == "https://checkout.vonpay.com/v1/payment_intents/vpi_test_auth_002/void"
        )
        assert captured["body"] == {}
        assert intent.status == "voided"

    def test_url_encodes_canonical_id(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            return httpx.Response(
                200, json=self.VOIDED_INTENT, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.void("vpi_test_AbC-123_xyz")
        assert (
            captured["url"]
            == "https://checkout.vonpay.com/v1/payment_intents/vpi_test_AbC-123_xyz/void"
        )

    def test_rejects_path_injection_via_allowlist(self):
        client = VonPayCheckout(self.KEY)
        with pytest.raises(ValueError, match="contains characters outside"):
            client.payment_intents.void("evil/id with?query")

    def test_forwards_idempotency_key(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["idempotency_key"] = req.headers.get("Idempotency-Key")
            return httpx.Response(
                200, json=self.VOIDED_INTENT, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.payment_intents.void(
            "vpi_test_auth_002", idempotency_key="ord_42-void-1"
        )
        assert captured["idempotency_key"] == "ord_42-void-1"

    def test_surfaces_rerouted_to_refund_envelope(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "payment_intent": "vpi_test_auth_002",
                    "current_status": "succeeded",
                    "reject_reason": "terminal_state",
                    "error": "cannot void: intent already captured",
                    "code": "invalid_transition",
                    "fix": "Use refunds.create() — this processor reroutes "
                           "void-after-capture to a refund.",
                    "docs": "https://docs.vonpay.com",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.payment_intents.void("vpi_test_auth_002")
        err = exc_info.value
        assert err.code == "invalid_transition"
        assert err.payment_intent == "vpi_test_auth_002"
        assert err.current_status == "succeeded"
        assert err.reject_reason == "terminal_state"


class TestRefunds:
    """SDK 0.6.x — refunds.create (POST /v1/refunds)."""

    KEY = "vp_sk_test_refund_key_001"
    REFUND_WIRE = {
        "id": "vpr_test_JL3xPcFktvsF10Ib",
        "payment_intent": "vpi_test_succeeded_001",
        "amount": 500,
        "currency": "USD",
        "status": "succeeded",
        "reason": None,
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_creates_partial_refund_with_explicit_amount(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.REFUND_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        refund = client.refunds.create(
            payment_intent="vpi_test_succeeded_001",
            amount=500,
            reason="partial_return",
        )
        assert captured["url"] == "https://checkout.vonpay.com/v1/refunds"
        assert captured["body"] == {
            "payment_intent": "vpi_test_succeeded_001",
            "amount": 500,
            "reason": "partial_return",
        }
        assert refund.id == "vpr_test_JL3xPcFktvsF10Ib"
        assert refund.id.startswith("vpr_test_")
        assert refund.payment_intent == "vpi_test_succeeded_001"
        assert refund.amount == 500
        assert refund.status == "succeeded"
        assert refund.reason is None
        # metadata defaults to {} when wire omits it (parity with PaymentIntent)
        assert refund.metadata == {}

    def test_handles_wire_response_omitting_reason_key(self):
        """Server may omit `reason` entirely when none was supplied. `data.get(...)`
        returns None for both absent and explicit-null wire shapes — pin the
        absent-key case so a refactor to bracket-access doesn't crash in
        production while the explicit-null tests still pass.
        """

        def handler(req: httpx.Request) -> httpx.Response:
            wire_no_reason = {
                k: v for k, v in self.REFUND_WIRE.items() if k != "reason"
            }
            return httpx.Response(
                200, json=wire_no_reason, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        refund = client.refunds.create(payment_intent="vpi_test_succeeded_001")
        assert refund.reason is None

    def test_refunds_full_balance_when_amount_omitted(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200,
                json={**self.REFUND_WIRE, "amount": 1499},
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        refund = client.refunds.create(payment_intent="vpi_test_succeeded_001")
        # amount must be ABSENT, not null — server distinguishes
        assert "amount" not in captured["body"]
        assert captured["body"] == {"payment_intent": "vpi_test_succeeded_001"}
        assert refund.amount == 1499

    def test_passes_metadata_keys_verbatim(self):
        """sdk/metadata-keys-opaque — integrator-defined keys round-trip."""
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200,
                json={
                    **self.REFUND_WIRE,
                    "metadata": {"order_id": "ord_42", "mixedCase": "kept"},
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        refund = client.refunds.create(
            payment_intent="vpi_test_succeeded_001",
            amount=500,
            metadata={"order_id": "ord_42", "mixedCase": "kept"},
        )
        assert captured["body"]["metadata"] == {
            "order_id": "ord_42",
            "mixedCase": "kept",
        }
        assert refund.metadata == {"order_id": "ord_42", "mixedCase": "kept"}

    def test_forwards_idempotency_key(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["idempotency_key"] = req.headers.get("Idempotency-Key")
            return httpx.Response(
                200, json=self.REFUND_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.refunds.create(
            payment_intent="vpi_test_succeeded_001",
            amount=500,
            idempotency_key="ord_42-refund-1",
        )
        assert captured["idempotency_key"] == "ord_42-refund-1"

    def test_surfaces_amount_exceeds_remaining_without_lifecycle_bleed(self):
        """Refund errors are not lifecycle-envelope errors. Lifecycle fields
        must NOT bleed through on a non-lifecycle error.
        """
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "error": "refund amount exceeds remaining refundable balance",
                    "code": "refund_amount_exceeds_remaining",
                    "fix": "Refund a smaller amount, or omit `amount` to "
                           "refund the full remaining balance.",
                    "docs": "https://docs.vonpay.com",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.refunds.create(
                payment_intent="vpi_test_succeeded_001", amount=99999
            )
        err = exc_info.value
        assert err.code == "refund_amount_exceeds_remaining"
        assert err.status == 422
        assert err.next_action == "fix_input"
        assert err.payment_intent is None
        assert err.current_status is None
        assert err.reject_reason is None


class TestTokens:
    """SDK 0.6.x — tokens.create (POST /v1/tokens)."""

    KEY = "vp_sk_test_token_key_001"
    TOKEN_WIRE = {
        "id": "vp_pmt_test_QAqnXEJF_TCum1jg",
        "status": "active",
        "card": {
            "brand": "visa",
            "last4": "4242",
            "exp_month": 12,
            "exp_year": 2030,
        },
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_creates_with_empty_body_sandbox_auto_mint(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.TOKEN_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        token = client.tokens.create()
        assert captured["url"] == "https://checkout.vonpay.com/v1/tokens"
        assert captured["body"] == {}
        assert token.id == "vp_pmt_test_QAqnXEJF_TCum1jg"
        # Real prefix is vp_pmt_*, NOT speculative vtk_*
        assert token.id.startswith("vp_pmt_")
        assert token.status == "active"
        assert token.card.brand == "visa"
        assert token.card.last4 == "4242"
        assert token.card.exp_month == 12
        assert token.card.exp_year == 2030

    def test_forwards_buyer_id_and_provider_reference_as_snake_case(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.TOKEN_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.tokens.create(
            buyer_id="buyer_abc", provider_reference="spreedly_pm_xyz"
        )
        assert captured["body"] == {
            "buyer_id": "buyer_abc",
            "provider_reference": "spreedly_pm_xyz",
        }

    def test_surfaces_validation_error_on_iframe_vault_live_without_provider_reference(
        self,
    ):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                422,
                json={
                    "error": "provider_reference is required for this processor",
                    "code": "validation_error",
                    "fix": "Mint a vault token via the provider's iframe SDK "
                           "and pass it as provider_reference.",
                    "docs": "https://docs.vonpay.com",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.tokens.create()
        err = exc_info.value
        assert err.code == "validation_error"
        assert err.status == 422
        assert err.next_action == "fix_input"

    def test_passes_metadata_keys_verbatim(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(req.content.decode())
            return httpx.Response(
                200, json=self.TOKEN_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.tokens.create(
            buyer_id="buyer_abc",
            metadata={"order_id": "ord_42", "mixedCase": "kept"},
        )
        assert captured["body"]["metadata"] == {
            "order_id": "ord_42",
            "mixedCase": "kept",
        }

    def test_forwards_idempotency_key(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["idempotency_key"] = req.headers.get("Idempotency-Key")
            return httpx.Response(
                200, json=self.TOKEN_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        client.tokens.create(
            buyer_id="buyer_abc", idempotency_key="buyer_abc-token-1"
        )
        assert captured["idempotency_key"] == "buyer_abc-token-1"


class TestWebhookSubscriptionsList:
    """SDK 0.8.0 — webhook_subscriptions.list (public read endpoint)."""

    KEY = "vp_sk_test_websub_list_key_001"

    SUB_WIRE = {
        "id": "whsub_test_abc",
        "object": "webhook_subscription",
        "url": "https://example.com/hook",
        "enabledEvents": ["charge.succeeded", "charge.failed"],
        "status": "active",
        "description": None,
        "apiVersion": "2026-05-04",
        "lastDeliveryAt": "2026-05-23T10:00:00Z",
        "lastSuccessAt": "2026-05-23T10:00:00Z",
        "lastErrorAt": None,
        "createdAt": "2026-05-07T08:00:00Z",
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_lists_with_no_params(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            captured["method"] = req.method
            return httpx.Response(
                200,
                json={
                    "object": "list",
                    "data": [self.SUB_WIRE],
                    "hasMore": False,
                    "url": "/v1/webhook_subscriptions",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        res = client.webhook_subscriptions.list()
        assert res.object == "list"
        assert len(res.data) == 1
        assert res.data[0].id == "whsub_test_abc"
        assert res.data[0].enabled_events == ["charge.succeeded", "charge.failed"]
        assert res.has_more is False
        assert "/v1/webhook_subscriptions" in captured["url"]
        assert captured["method"] == "GET"

    def test_forwards_limit_and_starting_after_as_snake_case_query(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            return httpx.Response(
                200,
                json={
                    "object": "list",
                    "data": [],
                    "hasMore": False,
                    "url": "/v1/webhook_subscriptions",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        client.webhook_subscriptions.list(limit=25, starting_after="whsub_test_abc")
        assert "limit=25" in captured["url"]
        assert "starting_after=whsub_test_abc" in captured["url"]

    def test_rejects_path_injection_in_starting_after_before_request_fires(self):
        called = {"n": 0}

        def handler(req: httpx.Request) -> httpx.Response:
            called["n"] += 1
            return httpx.Response(200, json={})

        client = self._client_with_handler(handler)
        with pytest.raises(ValueError, match="characters outside"):
            client.webhook_subscriptions.list(starting_after="../etc/passwd")
        assert called["n"] == 0

    def test_surfaces_empty_result_set(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                json={
                    "object": "list",
                    "data": [],
                    "hasMore": False,
                    "url": "/v1/webhook_subscriptions",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        res = client.webhook_subscriptions.list()
        assert res.data == []
        assert res.has_more is False

    def test_surfaces_has_more_true(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                200,
                json={
                    "object": "list",
                    "data": [self.SUB_WIRE],
                    "hasMore": True,
                    "url": "/v1/webhook_subscriptions",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        res = client.webhook_subscriptions.list(limit=1)
        assert res.has_more is True

    def test_surfaces_403_publishable_key_rejected(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                403,
                json={
                    "error": "Secret key required",
                    "code": "auth_key_type_forbidden",
                    "fix": "Use a vp_sk_* secret key, not a publishable key",
                    "docs": "https://docs.vonpay.com/reference/error-codes",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = VonPayCheckout("vp_pk_test_abc123def456")
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        with pytest.raises(VonPayError) as exc_info:
            client.webhook_subscriptions.list()
        assert exc_info.value.status == 403
        assert exc_info.value.code == "auth_key_type_forbidden"


class TestWebhookSubscriptionsRetrieve:
    """SDK 0.8.0 — webhook_subscriptions.retrieve (single point lookup)."""

    KEY = "vp_sk_test_websub_get_key_001"

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_fetches_single_subscription_by_id(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            return httpx.Response(
                200,
                json={
                    "id": "whsub_test_xyz",
                    "object": "webhook_subscription",
                    "url": "https://example.com/hook",
                    "enabledEvents": ["charge.succeeded"],
                    "status": "paused",
                    "description": "alpha",
                    "apiVersion": None,
                    "lastDeliveryAt": None,
                    "lastSuccessAt": None,
                    "lastErrorAt": None,
                    "createdAt": "2026-05-07T08:00:00Z",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        sub = client.webhook_subscriptions.retrieve("whsub_test_xyz")
        assert sub.id == "whsub_test_xyz"
        assert sub.status == "paused"
        assert sub.api_version is None
        assert captured["url"].endswith("/v1/webhook_subscriptions/whsub_test_xyz")

    def test_rejects_path_injection_before_request_fires(self):
        called = {"n": 0}

        def handler(req: httpx.Request) -> httpx.Response:
            called["n"] += 1
            return httpx.Response(200, json={})

        client = self._client_with_handler(handler)
        with pytest.raises(ValueError, match="characters outside"):
            client.webhook_subscriptions.retrieve("../admin")
        assert called["n"] == 0

    def test_surfaces_404_opaque_cross_merchant(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                404,
                json={
                    "error": "Webhook subscription not found",
                    "code": "internal_error",
                    "fix": "Verify the subscription id exists and belongs to this merchant",
                    "docs": "https://docs.vonpay.com/reference/error-codes",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.webhook_subscriptions.retrieve("whsub_test_other")
        assert exc_info.value.status == 404


class TestWebhookEventsRetrieve:
    """SDK 0.8.0 — webhook_events.retrieve (stored event record lookup)."""

    KEY = "vp_sk_test_webevt_get_key_001"

    EVENT_WIRE = {
        "id": "evt_test_abc",
        "object": "event",
        "type": "charge.succeeded",
        "receivedAt": "2026-05-23T10:00:00Z",
        "processed": True,
        "retryCount": 0,
        "nextRetryAt": None,
        "lastError": None,
        "processingError": None,
        "sessionId": "session_abc",
        "livemode": False,
        # Caller-supplied payload keys must round-trip verbatim — the
        # SDK does NOT case-convert the payload (parity with the Node
        # SDK metadata-keys-opaque rule on the read endpoints).
        "payload": {"sessionId": "session_abc", "mixedCase": "kept", "amount": 1499},
    }

    def _client_with_handler(self, handler):
        client = VonPayCheckout(self.KEY)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        return client

    def test_fetches_stored_event_record(self):
        captured = {}

        def handler(req: httpx.Request) -> httpx.Response:
            captured["url"] = str(req.url)
            return httpx.Response(
                200, json=self.EVENT_WIRE, headers={"X-Request-Id": "req_x"}
            )

        client = self._client_with_handler(handler)
        ev = client.webhook_events.retrieve("evt_test_abc")
        assert ev.id == "evt_test_abc"
        assert ev.type == "charge.succeeded"
        assert ev.livemode is False
        # Payload round-trips verbatim — mixedCase key preserved.
        assert ev.payload == {
            "sessionId": "session_abc",
            "mixedCase": "kept",
            "amount": 1499,
        }
        assert captured["url"].endswith("/v1/webhook_events/evt_test_abc")

    def test_rejects_path_injection_before_request_fires(self):
        called = {"n": 0}

        def handler(req: httpx.Request) -> httpx.Response:
            called["n"] += 1
            return httpx.Response(200, json={})

        client = self._client_with_handler(handler)
        with pytest.raises(ValueError, match="characters outside"):
            client.webhook_events.retrieve("../webhook_subscriptions/abc")
        assert called["n"] == 0

    def test_surfaces_404_opaque(self):
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                404,
                json={
                    "error": "Webhook event not found",
                    "code": "internal_error",
                    "fix": "Verify the event id exists and is merchant-scoped",
                    "docs": "https://docs.vonpay.com/reference/error-codes",
                },
                headers={"X-Request-Id": "req_x"},
            )

        client = self._client_with_handler(handler)
        with pytest.raises(VonPayError) as exc_info:
            client.webhook_events.retrieve("evt_test_other")
        assert exc_info.value.status == 404
