"""Von Payments Checkout SDK client."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import math
import os
import random
import re
import time
from urllib.parse import quote, urlencode, urlparse, parse_qsl
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

import httpx

from vonpay.checkout.errors import VonPayError
from vonpay.checkout.telemetry import Telemetry
from vonpay.checkout.types import (
    Capabilities,
    CapabilitiesRateLimits,
    CapabilitiesSupportedOperations,
    CheckoutSession,
    DryRunResult,
    ErrorReporter,
    ErrorReporterContext,
    HealthStatus,
    LineItem,
    MIRROR_CONTRACT_VERSION,
    MITBlock,
    MirrorAddress,
    MirrorBlock,
    MirrorCustomer,
    MirrorLineItem,
    PaymentIntent,
    RateLimitInfo,
    Refund,
    SessionMode,
    SessionStatus,
    Token,
    TokenCard,
    WebhookEvent,
    WebhookEventRecord,
    WebhookSubscription,
    WebhookSubscriptionsList,
)

_log = logging.getLogger("vonpay.checkout")

_DEFAULT_BASE_URL = "https://checkout.vonpay.com"
# Sent as `Von-Pay-Version` on every request. Bump alongside spec changes
# in lock-step with the Node SDK constant (sdk/api-version-bump-both-sdks).
# 0.5.0 contracts (payment_intents + capabilities) and the 0.6.x server-side
# endpoints (capture/void/refunds/tokens) are described in the 2026-05-05 spec.
_DEFAULT_API_VERSION = "2026-05-05"
_DEFAULT_MAX_RETRIES = 2
_DEFAULT_TIMEOUT = 30.0
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_WEBHOOK_TIMESTAMP_TOLERANCE = 300  # 5 minutes
_VALID_KEY_PREFIXES = ("vp_sk_test_", "vp_sk_live_", "vp_pk_test_", "vp_pk_live_")

# Read version dynamically from installed package metadata to avoid drift with
# pyproject.toml. Falls back to "0.0.0" only in editable installs before build.
try:
    from importlib.metadata import version as _pkg_version

    _SDK_VERSION = _pkg_version("vonpay-checkout")
except Exception:  # pragma: no cover — fallback for unbuilt editable installs
    _SDK_VERSION = "0.0.0"
_HEX_64 = re.compile(r"^[0-9a-f]{64}$")
_UINT = re.compile(r"^[0-9]+$")
# Server-issued resource IDs are alphanumeric + underscore + hyphen
# (parity with Node's RESOURCE_ID_PATTERN). Reject anything that could
# escape a path segment before urllib's quote() ever runs.
_RESOURCE_ID = re.compile(r"^[A-Za-z0-9_\-]+$")


def _assert_resource_id(value: str, param_name: str) -> None:
    # Type vs content split mirrors Python idiom: TypeError signals a
    # programming bug (None / int / wrong type); ValueError signals bad
    # but-correctly-typed input (empty / oversize / non-canonical chars).
    # Node throws TypeError on every bad input, so the type-mismatch case
    # at least keeps semantic parity.
    if not isinstance(value, str):
        raise TypeError(f"{param_name} must be a string")
    if not value:
        raise ValueError(f"{param_name} must be a non-empty string")
    if len(value) > 256:
        raise ValueError(f"{param_name} exceeds 256 chars")
    if not _RESOURCE_ID.match(value):
        raise ValueError(
            f"{param_name} contains characters outside [A-Za-z0-9_-]; "
            f"got: {value[:64]!r}"
        )


def _parse_v2_signature_header(header: str) -> Optional[Dict[str, Any]]:
    """Parse "t=<sec>,v2=<hex>" into {"t": int, "v2": str}. Returns None if malformed."""
    if not header:
        return None
    t_val: Optional[int] = None
    v2_val: Optional[str] = None
    for part in header.split(","):
        if "=" not in part:
            return None
        key, val = part.split("=", 1)
        key = key.strip()
        val = val.strip()
        if key == "t":
            # Reject duplicate keys — last-writer-wins lets an attacker pair
            # an old HMAC with a fresh `t`, smuggling a stale replay past the
            # freshness window. JWT alg-confusion class.
            if t_val is not None:
                return None
            if not _UINT.match(val):
                return None
            t_val = int(val)
        elif key == "v2":
            if v2_val is not None:
                return None
            if not _HEX_64.match(val):
                return None
            v2_val = val
    if t_val is None or v2_val is None:
        return None
    return {"t": t_val, "v2": v2_val}


def _parse_rate_limit(headers: httpx.Headers) -> Optional[RateLimitInfo]:
    limit = headers.get("x-ratelimit-limit")
    if not limit:
        return None
    retry_after_raw = headers.get("retry-after")
    retry_after = None
    if retry_after_raw:
        try:
            retry_after = int(retry_after_raw)
        except ValueError:
            pass
    return RateLimitInfo(
        limit=int(limit),
        remaining=int(headers.get("x-ratelimit-remaining", "0")),
        reset=int(headers.get("x-ratelimit-reset", "0")),
        retry_after=retry_after,
    )


def _safe_url(url: str) -> str:
    """Strip query string from URL for safe inclusion in error context."""
    q = url.find("?")
    return url if q == -1 else url[:q]


def _camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    result = re.sub(r"([A-Z])", r"_\1", name).lower()
    return result.lstrip("_")


def _snake_to_camel(name: str) -> str:
    """Convert snake_case to camelCase."""
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _to_snake_keys(d: Dict[str, Any]) -> Dict[str, Any]:
    """Shallow snake-case conversion of dict keys."""
    return {_camel_to_snake(k): v for k, v in d.items()}


def _to_camel_keys(d: Dict[str, Any]) -> Dict[str, Any]:
    """Shallow camel-case conversion of dict keys; drops None values."""
    return {_snake_to_camel(k): v for k, v in d.items() if v is not None}


def _mirror_address_to_dict(a: MirrorAddress) -> Dict[str, Any]:
    """Map a :class:`MirrorAddress` to wire dict (snake_case).

    Same explicit-mapping rule as :func:`_mit_block_to_dict` (inline below):
    do NOT use ``dataclasses.asdict``; a future-added field must surface here
    so the wire contract stays auditable in one place.
    """
    out: Dict[str, Any] = {
        "address1": a.address1,
        "city": a.city,
        "zip": a.zip,
        "country": a.country,
    }
    if a.first_name is not None:
        out["first_name"] = a.first_name
    if a.last_name is not None:
        out["last_name"] = a.last_name
    if a.address2 is not None:
        out["address2"] = a.address2
    if a.province is not None:
        out["province"] = a.province
    if a.phone is not None:
        out["phone"] = a.phone
    if a.company is not None:
        out["company"] = a.company
    return out


def _mirror_customer_to_dict(c: MirrorCustomer) -> Dict[str, Any]:
    """Map a :class:`MirrorCustomer` to wire dict (snake_case)."""
    out: Dict[str, Any] = {"email": c.email}
    if c.first_name is not None:
        out["first_name"] = c.first_name
    if c.last_name is not None:
        out["last_name"] = c.last_name
    if c.phone is not None:
        out["phone"] = c.phone
    return out


def _mirror_line_item_to_dict(li: MirrorLineItem) -> Dict[str, Any]:
    """Map a :class:`MirrorLineItem` to wire dict (snake_case)."""
    out: Dict[str, Any] = {
        "title": li.title,
        "quantity": li.quantity,
        "price": li.price,
    }
    if li.variant_id is not None:
        out["variant_id"] = li.variant_id
    if li.tax_lines is not None:
        out["tax_lines"] = [
            {"price": tl.price, "rate": tl.rate, "title": tl.title}
            for tl in li.tax_lines
        ]
    return out


def _mirror_block_to_dict(m: MirrorBlock) -> Dict[str, Any]:
    """Map a :class:`MirrorBlock` to wire dict (snake_case).

    Auto-fills ``contract_version`` with :data:`MIRROR_CONTRACT_VERSION` when
    the caller omits it. Required-when-present per the v2 mirror contract;
    the auto-fill saves merchants from per-call boilerplate and protects
    against a forgotten field bouncing as ``validation_missing_field`` 422.
    """
    out: Dict[str, Any] = {
        "contract_version": (
            m.contract_version
            if m.contract_version is not None
            else MIRROR_CONTRACT_VERSION
        ),
        "destination": m.destination,
        "shop": m.shop,
        "line_items": [_mirror_line_item_to_dict(li) for li in m.line_items],
        "customer": _mirror_customer_to_dict(m.customer),
    }
    if m.skip is not None:
        out["skip"] = m.skip
    if m.shipping_address is not None:
        out["shipping_address"] = _mirror_address_to_dict(m.shipping_address)
    if m.billing_address is not None:
        out["billing_address"] = _mirror_address_to_dict(m.billing_address)
    if m.financial_status is not None:
        out["financial_status"] = m.financial_status
    if m.tags is not None:
        out["tags"] = list(m.tags)
    if m.note_attributes is not None:
        out["note_attributes"] = [
            {"name": na.name, "value": na.value} for na in m.note_attributes
        ]
    if m.send_receipt is not None:
        out["send_receipt"] = m.send_receipt
    if m.origin is not None:
        out["origin"] = m.origin
    return out


def _payment_intent_from_dict(data: Dict[str, Any]) -> PaymentIntent:
    return PaymentIntent(
        id=data["id"],
        status=data["status"],
        amount=data["amount"],
        currency=data["currency"],
        capture_method=data["capture_method"],
        next_action=data.get("next_action"),
        decline_code=data.get("decline_code"),
        created_at=data["created_at"],
        metadata=data.get("metadata") or {},
    )


def _refund_from_dict(data: Dict[str, Any]) -> Refund:
    return Refund(
        id=data["id"],
        payment_intent=data["payment_intent"],
        amount=data["amount"],
        currency=data["currency"],
        status=data["status"],
        # None for both absent and explicit-null wire shapes — parity with
        # PaymentIntent.next_action / decline_code.
        reason=data.get("reason"),
        # Mirror PaymentIntent: always materialise metadata as {} so callers
        # can read refund.metadata.* without a None check.
        metadata=data.get("metadata") or {},
    )


def _token_from_dict(data: Dict[str, Any]) -> Token:
    # The Token wire is snake_case in both directions, so card sub-object
    # fields (exp_month / exp_year / last4) stay snake_case on the dataclass
    # — Python convention. The Node SDK converts them to camelCase
    # (expMonth / expYear) per JS convention. Don't "fix" the divergence;
    # both SDKs match their host language's idioms.
    card = data.get("card") or {}
    return Token(
        id=data["id"],
        status=data["status"],
        card=TokenCard(
            brand=card.get("brand", ""),
            last4=card.get("last4", ""),
            exp_month=card.get("exp_month", 0),
            exp_year=card.get("exp_year", 0),
        ),
    )


class _PaymentIntents:
    def __init__(self, client: VonPayCheckout) -> None:
        self._client = client

    def create(
        self,
        *,
        amount: int,
        currency: str,
        capture_method: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        mit: Optional[MITBlock] = None,
        mirror: Optional[MirrorBlock] = None,
        idempotency_key: Optional[str] = None,
    ) -> PaymentIntent:
        """Create a payment intent (POST /v1/payment_intents).

        ``mit`` carries a merchant-initiated-transaction block for recurring /
        saved-card / retry charges. Omit for cardholder-initiated transactions.
        See :class:`MITBlock` for the chain anchor rules. Field names on
        :class:`MITBlock` are already snake_case so the wire body uses the
        dataclass shape verbatim.

        ``mirror`` carries an order-mirror block. When present and the
        merchant is connected to a destination platform (e.g. Shopify),
        Vonpay mirrors the captured payment into that platform's order
        ledger after the payment_intent reaches ``succeeded``. See
        :class:`MirrorBlock` for the full contract. The SDK auto-fills
        ``contract_version`` with :data:`MIRROR_CONTRACT_VERSION` when the
        caller omits it.
        """
        # Pass currency through as-is (matches Node SDK's behaviour). The
        # server accepts both cases and normalises the response to ISO-4217
        # uppercase, so caller-side normalisation would only mask integrator
        # bugs.
        body: Dict[str, Any] = {"amount": amount, "currency": currency}
        if capture_method is not None:
            body["capture_method"] = capture_method
        if metadata is not None:
            body["metadata"] = metadata
        if mit is not None:
            body["mit"] = {
                "initiator": mit.initiator,
                "reason": mit.reason,
                "original_transaction_id": mit.original_transaction_id,
            }
        if mirror is not None:
            body["mirror"] = _mirror_block_to_dict(mirror)
        data = self._client._request(
            "POST",
            "/v1/payment_intents",
            json_body=body,
            idempotency_key=idempotency_key,
            reporter_method="payment_intents.create",
        )
        return _payment_intent_from_dict(data)

    def capture(
        self,
        payment_intent_id: str,
        *,
        amount_to_capture: Optional[int] = None,
        idempotency_key: Optional[str] = None,
    ) -> PaymentIntent:
        """Capture an authorized payment intent (POST /v1/payment_intents/{id}/capture).

        Empty body captures the full authorized amount; pass ``amount_to_capture``
        for a partial capture (server enforces remaining = authorized −
        previous captures).

        On ``invalid_transition`` (already-succeeded / not-authorized), the
        thrown ``VonPayError`` carries ``current_status`` + ``reject_reason``
        so callers can branch without a follow-up retrieve.
        """
        _assert_resource_id(payment_intent_id, "payment_intent_id")
        body: Dict[str, Any] = {}
        if amount_to_capture is not None:
            body["amount_to_capture"] = amount_to_capture
        data = self._client._request(
            "POST",
            f"/v1/payment_intents/{quote(payment_intent_id, safe='')}/capture",
            json_body=body,
            idempotency_key=idempotency_key,
            reporter_method="payment_intents.capture",
        )
        return _payment_intent_from_dict(data)

    def void(
        self,
        payment_intent_id: str,
        *,
        idempotency_key: Optional[str] = None,
    ) -> PaymentIntent:
        """Void an authorized (uncaptured) payment intent (POST /v1/payment_intents/{id}/void).

        Named ``void`` to match the server endpoint, NOT ``cancel`` (Stripe's
        convention). ``void`` is a regular Python identifier — only the
        ``Void`` type-hint is reserved-ish.

        On ``invalid_transition``, the thrown ``VonPayError`` carries
        ``current_status`` + ``reject_reason``. If
        ``void_after_capture == "rerouted_to_refund"`` (per
        ``capabilities.get()``), use ``refunds.create()`` once the intent is
        ``succeeded``.
        """
        _assert_resource_id(payment_intent_id, "payment_intent_id")
        data = self._client._request(
            "POST",
            f"/v1/payment_intents/{quote(payment_intent_id, safe='')}/void",
            json_body={},
            idempotency_key=idempotency_key,
            reporter_method="payment_intents.void",
        )
        return _payment_intent_from_dict(data)


class _Refunds:
    def __init__(self, client: VonPayCheckout) -> None:
        self._client = client

    def create(
        self,
        *,
        payment_intent: str,
        amount: Optional[int] = None,
        currency: Optional[str] = None,
        reason: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Refund:
        """Refund a payment intent (POST /v1/refunds).

        Omit ``amount`` to refund the full remaining balance (server computes
        authorized − previously refunded). Pass ``amount`` for a partial
        refund. Refund IDs use the ``vpr_(test|live)_*`` prefix.
        """
        body: Dict[str, Any] = {"payment_intent": payment_intent}
        if amount is not None:
            body["amount"] = amount
        if currency is not None:
            body["currency"] = currency
        if reason is not None:
            body["reason"] = reason
        if metadata is not None:
            body["metadata"] = metadata
        data = self._client._request(
            "POST",
            "/v1/refunds",
            json_body=body,
            idempotency_key=idempotency_key,
            reporter_method="refunds.create",
        )
        return _refund_from_dict(data)


class _Tokens:
    def __init__(self, client: VonPayCheckout) -> None:
        self._client = client

    def create(
        self,
        *,
        buyer_id: Optional[str] = None,
        provider_reference: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Token:
        """Create a payment-method token (POST /v1/tokens).

        Token IDs use the ``vp_pmt_(test|live)_*`` prefix. Live keys with
        iframe-vault providers require ``provider_reference`` minted
        browser-side via the provider's iframe SDK; the server returns
        ``422 validation_error`` otherwise. Sandbox keys auto-mint a mock card
        token if no card data is supplied.
        """
        body: Dict[str, Any] = {}
        if buyer_id is not None:
            body["buyer_id"] = buyer_id
        if provider_reference is not None:
            body["provider_reference"] = provider_reference
        if metadata is not None:
            body["metadata"] = metadata
        data = self._client._request(
            "POST",
            "/v1/tokens",
            json_body=body,
            idempotency_key=idempotency_key,
            reporter_method="tokens.create",
        )
        return _token_from_dict(data)


class _Capabilities:
    def __init__(self, client: VonPayCheckout) -> None:
        self._client = client

    def get(self) -> Capabilities:
        """Get the merchant's processor capability matrix (GET /v1/capabilities)."""
        data = self._client._request(
            "GET",
            "/v1/capabilities",
            reporter_method="capabilities.get",
        )
        ops = data.get("supported_operations", {})
        rate = data.get("rate_limits", {})
        return Capabilities(
            supported_operations=CapabilitiesSupportedOperations(
                auth_capture_separation=ops.get("auth_capture_separation", False),
                partial_capture=ops.get("partial_capture", False),
                partial_refund=ops.get("partial_refund", False),
                unreferenced_refund=ops.get("unreferenced_refund", False),
                void_after_capture=ops.get("void_after_capture", "unsupported"),
                mit=ops.get("mit", False),
                network_tokens=ops.get("network_tokens", False),
                three_d_secure_2=ops.get("three_d_secure_2", False),
                ach=ops.get("ach", False),
                payouts_api=ops.get("payouts_api", False),
            ),
            settlement_currencies=data.get("settlement_currencies", []),
            rate_limits=CapabilitiesRateLimits(
                payment_intents_per_minute=rate.get("payment_intents_per_minute", 0),
            ),
        )


class _Sessions:
    def __init__(self, client: VonPayCheckout) -> None:
        self._client = client

    def create(
        self,
        *,
        amount: int,
        currency: str,
        country: Optional[str] = None,
        mode: Optional[SessionMode] = None,
        description: Optional[str] = None,
        locale: Optional[str] = None,
        success_url: Optional[str] = None,
        cancel_url: Optional[str] = None,
        buyer_id: Optional[str] = None,
        buyer_name: Optional[str] = None,
        buyer_email: Optional[str] = None,
        line_items: Optional[List[LineItem]] = None,
        collect_shipping: Optional[bool] = None,
        metadata: Optional[Dict[str, str]] = None,
        expires_in: Optional[int] = None,
        idempotency_key: Optional[str] = None,
    ) -> CheckoutSession:
        """Create a new checkout session.

        Mirrors Node SDK's ``CreateSessionParams`` shape. All optional fields
        match the OpenAPI ``CreateSessionRequest`` schema. Wire format is
        camelCase (legacy ``/v1/sessions`` contract); snake_case parameter
        names are converted at the boundary.

        Args:
            amount: Payment amount in the smallest currency unit (cents).
            currency: ISO 4217 currency code; normalised to uppercase.
            country: ISO 3166-1 alpha-2 country code; normalised to uppercase.
            mode: Session mode (currently only ``"payment"``). Server defaults
                to ``"payment"`` when omitted.
            description: Human-readable description shown during checkout.
            locale: BCP 47 locale tag for the checkout UI language.
            success_url: HTTPS URL to redirect after successful payment.
            cancel_url: HTTPS URL to redirect if the buyer cancels.
            buyer_id: Your internal identifier for the buyer.
            buyer_name: Full name of the buyer.
            buyer_email: Email address of the buyer.
            line_items: Itemized line items displayed during checkout.
                Snake-case dataclass fields (``unit_amount``, ``image_url``)
                are explicitly mapped to camelCase on the wire.
            collect_shipping: When ``True``, the checkout form collects a
                shipping address from the buyer.
            metadata: Arbitrary key-value pairs. Keys pass through verbatim
                (sdk/metadata-keys-opaque) — not camel-cased.
            expires_in: Session TTL in seconds (300 ≤ value ≤ 604800).
                Minimum 5 minutes, maximum 7 days. Defaults to 1800 (30
                minutes) when omitted.
            idempotency_key: Optional idempotency key for retry safety.
        """
        # Build the protocol body via shallow camel conversion, then attach
        # metadata verbatim (sdk/metadata-keys-opaque). Routing metadata
        # through _to_camel_keys would only "work" because _snake_to_camel
        # is a no-op on the literal string "metadata" — relying on that is
        # accidental correctness. Extract it explicitly.
        #
        # line_items is similarly extracted: _to_camel_keys is a shallow
        # conversion and would leave the LineItem sub-dicts with snake_case
        # keys. We map each LineItem field explicitly so the wire shape
        # (unitAmount / imageUrl) is auditable in one place — same pattern
        # as MITBlock in payment_intents.create.
        body = _to_camel_keys(
            {
                "amount": amount,
                "currency": currency.upper(),
                "country": country.upper() if country else None,
                "mode": mode,
                "description": description,
                "locale": locale,
                "success_url": success_url,
                "cancel_url": cancel_url,
                "buyer_id": buyer_id,
                "buyer_name": buyer_name,
                "buyer_email": buyer_email,
                "collect_shipping": collect_shipping,
                "expires_in": expires_in,
            }
        )
        if metadata is not None:
            body["metadata"] = metadata
        if line_items is not None:
            wire_items: List[Dict[str, Any]] = []
            for item in line_items:
                wire_item: Dict[str, Any] = {
                    "name": item.name,
                    "quantity": item.quantity,
                    "unitAmount": item.unit_amount,
                }
                if item.image_url is not None:
                    wire_item["imageUrl"] = item.image_url
                wire_items.append(wire_item)
            body["lineItems"] = wire_items
        data = self._client._request(
            "POST",
            "/v1/sessions",
            json_body=body,
            idempotency_key=idempotency_key,
            reporter_method="sessions.create",
        )
        snake = _to_snake_keys(data)
        return CheckoutSession(
            id=snake["id"],
            checkout_url=snake["checkout_url"],
            expires_at=snake["expires_at"],
        )

    def get(self, session_id: str) -> SessionStatus:
        """Retrieve the current state of a checkout session.

        Requires a secret key (vp_sk_*). Publishable keys are rejected with 403.
        """
        _assert_resource_id(session_id, "session_id")
        data = self._client._request(
            "GET",
            f"/v1/sessions/{quote(session_id, safe='')}",
            reporter_method="sessions.get",
        )
        snake = _to_snake_keys(data)
        return SessionStatus(
            id=snake["id"],
            status=snake["status"],
            mode=snake["mode"],
            merchant_id=snake["merchant_id"],
            amount=snake["amount"],
            currency=snake["currency"],
            created_at=snake["created_at"],
            updated_at=snake["updated_at"],
            expires_at=snake["expires_at"],
            country=snake.get("country"),
            description=snake.get("description"),
            collect_shipping=snake.get("collect_shipping"),
            shipping_address=snake.get("shipping_address"),
            transaction_id=snake.get("transaction_id"),
            metadata=snake.get("metadata"),
        )

    def validate(
        self,
        *,
        amount: int,
        currency: str,
        country: Optional[str] = None,
        description: Optional[str] = None,
    ) -> DryRunResult:
        """Validate session params without creating a session (dry run)."""
        body = _to_camel_keys(
            {
                "amount": amount,
                "currency": currency.upper(),
                "country": country.upper() if country else None,
                "description": description,
            }
        )
        data = self._client._request(
            "POST",
            "/v1/sessions",
            json_body=body,
            params={"dry_run": "true"},
            reporter_method="sessions.validate",
        )
        return DryRunResult(
            valid=data["valid"],
            warnings=data.get("warnings", []),
        )


class _Webhooks:
    def __init__(self, client: Optional["VonPayCheckout"] = None) -> None:
        # client may be None when verify_signature is invoked statically — that
        # path doesn't report errors, so the reference is only needed by the
        # construct_event helpers.
        self._client = client

    @staticmethod
    def verify_signature(
        payload: Union[str, bytes], signature: str, secret: str
    ) -> bool:
        """Verify that a webhook payload was signed by Von Payments.

        Args:
            payload: Raw request body — bytes (httpx / Flask / FastAPI default) or str.
            signature: Value of the X-VonPay-Signature header.
            secret: Your merchant API key (vp_sk_*), used as the HMAC secret.
        """
        if not _HEX_64.match(signature):
            return False
        payload_bytes = payload if isinstance(payload, (bytes, bytearray)) else payload.encode()
        expected = hmac.new(
            secret.encode(), payload_bytes, hashlib.sha256
        ).digest()
        # _HEX_64 already enforces lowercase; compare raw bytes to match Node's
        # timingSafeEqual(Buffer.from(sig, "hex"), ...) and avoid any
        # string-allocation ambiguity around compare_digest.
        return hmac.compare_digest(bytes.fromhex(signature), expected)

    def construct_event(
        self, payload: Union[str, bytes], signature: str, secret: str, timestamp: str
    ) -> WebhookEvent:
        """Verify signature and timestamp, then parse the webhook payload.

        Args:
            payload: Raw request body — bytes (httpx / Flask / FastAPI default) or str.
            signature: Value of the X-VonPay-Signature header.
            secret: Your merchant API key (vp_sk_*), used as the HMAC secret.
            timestamp: Value of the X-VonPay-Timestamp header (ISO 8601).

        Raises:
            VonPayError: If signature or timestamp verification fails.
        """
        try:
            event_time = datetime.fromisoformat(
                timestamp.replace("Z", "+00:00")
            ).timestamp()
        except ValueError:
            event_time = 0.0

        now = time.time()
        if abs(now - event_time) > _WEBHOOK_TIMESTAMP_TOLERANCE:
            err = VonPayError(
                status=401,
                error="Webhook timestamp outside tolerance (±5 minutes)",
                code="webhook_invalid_signature",
                fix="Ensure server clock is synchronized and process webhooks promptly",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event", status=401, code=err.code
                )
            raise err

        if not _Webhooks.verify_signature(payload, signature, secret):
            err = VonPayError(
                status=401,
                error="Webhook signature verification failed",
                code="webhook_invalid_signature",
                fix="Ensure you are using your merchant API key (vp_sk_*) as the secret",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event", status=401, code=err.code
                )
            raise err

        data = json.loads(payload)
        snake = _to_snake_keys(data)
        return WebhookEvent(
            event=snake["event"],
            session_id=snake["session_id"],
            merchant_id=snake["merchant_id"],
            amount=snake["amount"],
            currency=snake["currency"],
            status=snake["status"],
            timestamp=snake["timestamp"],
            transaction_id=snake.get("transaction_id"),
            error=snake.get("error"),
            failure_code=snake.get("failure_code"),
            refund_id=snake.get("refund_id"),
            metadata=snake.get("metadata"),
        )

    def construct_event_v2(
        self, payload: Union[str, bytes], signature_header: str, secret: str
    ) -> WebhookEvent:
        """Verify and parse a webhook using the v2 signature format that binds
        the timestamp into the HMAC payload (Stripe-strict).

        The X-VonPay-Signature header must have the form::

            t=<unix-seconds>,v2=<hex-sha256>

        where v2 = HMAC(secret, f"{t}.{body}"). This prevents replay of a body
        with a new timestamp — v1 verifies the two independently, which is
        safe in practice but not Stripe-strict.

        Backward compatibility: the server only emits v2 when the merchant has
        opted in via the dashboard. Until then, construct_event_v2 will reject
        v1-only signatures with webhook_invalid_signature. Prefer
        construct_event unless you have explicitly enabled v2 on the merchant.

        Args:
            payload: Raw request body (bytes or str).
            signature_header: Full value of X-VonPay-Signature (e.g. "t=1714521600,v2=abc...").
            secret: Your merchant API key (vp_sk_*), used as the HMAC secret.

        Raises:
            VonPayError: If the header is malformed, timestamp is outside
                tolerance, or HMAC verification fails.
        """
        parsed = _parse_v2_signature_header(signature_header)
        if parsed is None:
            err = VonPayError(
                status=401,
                error="Webhook v2 signature header malformed — expected 't=<sec>,v2=<hex>'",
                code="webhook_invalid_signature",
                fix="Ensure the server is emitting v2 signatures and the X-VonPay-Signature header is forwarded intact",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event_v2", status=401, code=err.code
                )
            raise err
        t = parsed["t"]
        v2 = parsed["v2"]

        now_sec = time.time()
        if abs(now_sec - t) > _WEBHOOK_TIMESTAMP_TOLERANCE:
            err = VonPayError(
                status=401,
                error="Webhook timestamp outside tolerance (±5 minutes)",
                code="webhook_invalid_signature",
                fix="Ensure server clock is synchronized and process webhooks promptly",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event_v2", status=401, code=err.code
                )
            raise err

        payload_bytes = (
            payload if isinstance(payload, (bytes, bytearray)) else payload.encode()
        )
        signed = f"{t}.".encode() + bytes(payload_bytes)
        expected = hmac.new(secret.encode(), signed, hashlib.sha256).digest()
        if not hmac.compare_digest(bytes.fromhex(v2), expected):
            err = VonPayError(
                status=401,
                error="Webhook v2 signature verification failed",
                code="webhook_invalid_signature",
                fix="Ensure you are using your merchant API key (vp_sk_*) as the secret",
                docs="https://docs.vonpay.com/reference/webhooks#signature-verification",
            )
            if self._client is not None:
                self._client._report_error(
                    err, method="webhooks.construct_event_v2", status=401, code=err.code
                )
            raise err

        data = json.loads(payload)
        snake = _to_snake_keys(data)
        return WebhookEvent(
            event=snake["event"],
            session_id=snake["session_id"],
            merchant_id=snake["merchant_id"],
            amount=snake["amount"],
            currency=snake["currency"],
            status=snake["status"],
            timestamp=snake["timestamp"],
            transaction_id=snake.get("transaction_id"),
            error=snake.get("error"),
            failure_code=snake.get("failure_code"),
            refund_id=snake.get("refund_id"),
            metadata=snake.get("metadata"),
        )


class VonPayCheckout:
    """Von Payments Checkout SDK client.

    Args:
        api_key: Your merchant API key (vp_sk_test_* or vp_sk_live_*).
        api_version: API version date (default: 2026-05-05).
        base_url: API base URL (default: https://checkout.vonpay.com).
        max_retries: Max retry attempts on 429/5xx (default: 2).
        timeout: Request timeout in seconds (default: 30).
    """

    def __init__(
        self,
        api_key: str,
        *,
        api_version: str = _DEFAULT_API_VERSION,
        base_url: str = _DEFAULT_BASE_URL,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        timeout: float = _DEFAULT_TIMEOUT,
        error_reporter: Optional[ErrorReporter] = None,
        telemetry: Optional[Dict[str, Any]] = None,
    ) -> None:
        if not api_key:
            raise ValueError("API key is required")
        if not any(api_key.startswith(p) for p in _VALID_KEY_PREFIXES):
            raise ValueError(
                f"Invalid API key format. Keys must start with one of: "
                f"{', '.join(_VALID_KEY_PREFIXES)}"
            )

        self._api_key = api_key
        self._api_version = api_version
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._timeout = timeout
        self._error_reporter = error_reporter
        self._client = httpx.Client(timeout=timeout)

        # SDK telemetry — strict-equality opt-in. Non-bool raises TypeError.
        # v0.7.0+ behavior:
        #   - Test keys (vp_sk_test_*) DEFAULT ON — privacy-low; integrator
        #     bugs surface faster, alpha/beta loud-mode posture parity with
        #     Node SDK
        #   - Live keys (vp_sk_live_*) preserve default-OFF
        #   - Explicit telemetry={"enabled": <bool>} always wins
        self._telemetry: Optional[Telemetry] = None
        explicit_enabled = None
        if telemetry is not None:
            explicit_enabled = telemetry.get("enabled")
            if explicit_enabled is not None and not isinstance(explicit_enabled, bool):
                raise TypeError(
                    "telemetry['enabled'] must be a bool. Pass True to opt in or omit to disable."
                )
        is_test_key = api_key.startswith("vp_sk_test_")
        should_enable = explicit_enabled if explicit_enabled is not None else is_test_key
        if should_enable is True:
            # Telemetry always goes to the canonical base URL unless
            # explicitly overridden via telemetry['base_url']. We do NOT
            # inherit base_url (which may be a localhost proxy or staging
            # override for the integrator's main API calls).
            telemetry_cfg = telemetry or {}
            telemetry_base_url = (
                telemetry_cfg.get("base_url", "").rstrip("/")
                or _DEFAULT_BASE_URL
            )
            self._telemetry = Telemetry(
                api_key=api_key,
                base_url=telemetry_base_url,
                sdk_version=_SDK_VERSION,
            )
            # Disclosure warn (always — integrator must see what they opted into)
            _log.warning(
                "[vonpay] Telemetry enabled. Anonymized error metadata sent to vonpay.\n"
                "         Disable: telemetry={'enabled': False}\n"
                "         What we send: https://docs.vonpay.com/sdk-telemetry"
            )
            # Serverless cold-start warn
            if (
                os.environ.get("VERCEL") is not None
                or os.environ.get("AWS_LAMBDA_FUNCTION_NAME") is not None
            ):
                _log.warning(
                    "[vonpay] Telemetry detected serverless runtime (VERCEL / AWS_LAMBDA).\n"
                    "         Fire-and-forget POSTs may drop on function freeze.\n"
                    "         See https://docs.vonpay.com/sdk-telemetry#serverless"
                )

        self.sessions = _Sessions(self)
        self.webhooks = _Webhooks(self)
        self.payment_intents = _PaymentIntents(self)
        self.refunds = _Refunds(self)
        self.tokens = _Tokens(self)
        self.capabilities = _Capabilities(self)
        self.webhook_subscriptions = _WebhookSubscriptions(self)
        self.webhook_events = _WebhookEvents(self)

    def _report_error(
        self,
        err: Exception,
        *,
        method: str,
        url: Optional[str] = None,
        status: Optional[int] = None,
        request_id: Optional[str] = None,
        code: Optional[str] = None,
        attempt: Optional[int] = None,
    ) -> None:
        """Invoke the configured error_reporter callback, swallowing any throw
        from the integrator's reporter so an observability bug never breaks an
        SDK call.

        When no reporter is configured, falls back to a structured
        ``logging.warning`` call on the ``vonpay.checkout`` logger so
        integrators get minimum-viable visibility for free. Skipped under
        pytest (``PYTEST_CURRENT_TEST`` env var) and when ``VONPAY_QUIET=1``.
        """
        ctx = ErrorReporterContext(
            method=method,
            sdk_version=_SDK_VERSION,
            url=url,
            status=status,
            request_id=request_id,
            code=code,
            attempt=attempt,
        )
        if self._error_reporter is not None:
            try:
                self._error_reporter(err, ctx)
            except Exception as reporter_err:
                _log.warning(
                    "[vonpay] error_reporter raised; suppressing: %s",
                    reporter_err,
                )
        elif not (os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("VONPAY_QUIET") == "1"):
            # Default reporter — structured warning to logging so any aggregator
            # captures it without explicit wiring.
            summary: Dict[str, Any] = {
                "method": ctx.method,
                "sdk_version": ctx.sdk_version,
            }
            if ctx.url:
                summary["url"] = ctx.url
            if ctx.status is not None:
                summary["status"] = ctx.status
            if ctx.request_id:
                summary["request_id"] = ctx.request_id
            if ctx.code:
                summary["code"] = ctx.code
            if ctx.attempt is not None:
                summary["attempt"] = ctx.attempt
            if isinstance(err, VonPayError):
                summary["retryable"] = err.retryable
                summary["next_action"] = err.next_action
            _log.warning("[vonpay] %s %s", err, json.dumps(summary))

        # SDK telemetry fires AFTER reporter / default warn — unconditionally,
        # regardless of which reporter branch ran. Per-attempt of failed call
        # (matches `attempt` field). Errors inside record() are swallowed in
        # its background thread; never surface to caller.
        if self._telemetry is not None:
            self._telemetry.record(err, method, ctx.attempt, ctx.status)

    def __del__(self) -> None:
        # Defensive: __del__ runs even if __init__ raised before assignments
        # (e.g. invalid api_key), so attributes may not exist yet.
        client = getattr(self, "_client", None)
        if client is not None:
            try:
                client.close()
            except Exception:
                pass
        telemetry = getattr(self, "_telemetry", None)
        if telemetry is not None:
            try:
                telemetry.close()
            except Exception:
                pass

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        idempotency_key: Optional[str] = None,
        reporter_method: Optional[str] = None,
    ) -> Dict[str, Any]:
        url = f"{self._base_url}{path}"
        headers: Dict[str, str] = {
            "Authorization": f"Bearer {self._api_key}",
            "Von-Pay-Version": self._api_version,
            "User-Agent": f"vonpay-python/{_SDK_VERSION}",
            "Accept": "application/json",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                delay = self._get_retry_delay(attempt, last_error)
                time.sleep(delay)

            try:
                response = self._client.request(
                    method, url, headers=headers, json=json_body, params=params
                )
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt == self._max_retries:
                    self._report_error(
                        exc,
                        method=reporter_method or f"{method} {path}",
                        url=_safe_url(url),
                        attempt=attempt,
                    )
                    raise
                continue

            request_id = response.headers.get("x-request-id", "")
            rate_limit = _parse_rate_limit(response.headers)

            if response.is_success:
                return response.json()  # type: ignore[no-any-return]

            # Parse error
            try:
                error_data = response.json()
            except Exception:
                error_data = {
                    "error": f"HTTP {response.status_code}",
                    "code": "internal_error",
                    "fix": "Check the API status page",
                    "docs": "https://docs.vonpay.com",
                }

            # Lifecycle endpoints (capture/void/refunds) include
            # payment_intent / current_status / reject_reason on rejection so
            # integrators can branch without a follow-up retrieve. selfHeal.*
            # is dropped — error_help.py is the SDK-side source of truth for
            # retryable/next_action/llm_hint.
            last_error = VonPayError(
                status=response.status_code,
                error=error_data.get("error", "Unknown error"),
                code=error_data.get("code", "internal_error"),
                fix=error_data.get("fix", ""),
                docs=error_data.get("docs", ""),
                request_id=request_id,
                rate_limit=rate_limit,
                payment_intent=error_data.get("payment_intent"),
                current_status=error_data.get("current_status"),
                reject_reason=error_data.get("reject_reason"),
            )

            if response.status_code not in _RETRYABLE_STATUS_CODES:
                self._report_error(
                    last_error,
                    method=reporter_method or f"{method} {path}",
                    url=_safe_url(url),
                    status=response.status_code,
                    request_id=request_id,
                    code=last_error.code,
                    attempt=attempt,
                )
                raise last_error

            if attempt == self._max_retries:
                self._report_error(
                    last_error,
                    method=reporter_method or f"{method} {path}",
                    url=_safe_url(url),
                    status=response.status_code,
                    request_id=request_id,
                    code=last_error.code,
                    attempt=attempt,
                )
                raise last_error

        raise last_error or Exception("Request failed")

    def _get_retry_delay(
        self, attempt: int, last_error: Optional[Exception]
    ) -> float:
        if isinstance(last_error, VonPayError) and last_error.rate_limit:
            retry_after = last_error.rate_limit.retry_after
            if retry_after is not None:
                return min(retry_after, 60.0)
        base = math.pow(5, attempt - 1)
        jitter = random.random() * base * 0.1
        return base + jitter

    def health(self) -> HealthStatus:
        """Check API health status and latency."""
        start = time.monotonic()
        data = self._request("GET", "/api/health", reporter_method="health")
        latency = (time.monotonic() - start) * 1000
        return HealthStatus(
            status=data.get("status", "ok"),
            latency_ms=round(latency, 1),
            version=data.get("version", ""),
        )

    @staticmethod
    def verify_return_signature(
        params: Dict[str, str],
        secret: str,
        *,
        expected_success_url: Optional[str] = None,
        expected_key_mode: Optional[str] = None,
        max_age_seconds: int = 600,
    ) -> bool:
        """Verify a return URL signature from a checkout redirect.

        Supports both v1 (plain hex HMAC) and v2 ("v2.<payload>.<hmac>")
        signature formats. If params["sig"] starts with "v2.", v2 verification
        runs; otherwise v1 is used.

        v1 signs: sessionId.status.amount.currency.transactionId (joined with .)

        v2 additionally binds successUrl, keyMode, and issuedAt into the
        signature. When verifying v2, callers must supply expected_success_url
        and expected_key_mode so the verifier can assert those fields; v2
        also enforces that iat is within max_age_seconds (default 600).

        Args:
            params: URL query params (session, status, amount, currency,
                transaction_id, sig).
            secret: Your session signing secret, NOT your API key.
            expected_success_url: v2 only. The success URL the merchant
                configured when creating the session. Required for v2.
            expected_key_mode: v2 only. "test" or "live". Required for v2.
            max_age_seconds: v2 only. Reject sigs older than this. Default 600.
        """
        sig = params.get("sig", "")
        session = params.get("session", "")
        status = params.get("status", "")
        amount = params.get("amount", "")
        currency = params.get("currency", "")
        transaction_id = params.get("transaction_id", "")

        if not sig or not session or not status or not amount or not currency:
            return False

        if sig.startswith("v2."):
            return VonPayCheckout._verify_return_signature_v2(
                sig,
                session,
                status,
                amount,
                currency,
                transaction_id,
                secret,
                expected_success_url,
                expected_key_mode,
                max_age_seconds,
            )

        if not _HEX_64.match(sig):
            return False

        data = ".".join([session, status, amount, currency, transaction_id])
        expected = hmac.new(
            secret.encode(), data.encode(), hashlib.sha256
        ).digest()
        return hmac.compare_digest(bytes.fromhex(sig), expected)

    @staticmethod
    def _verify_return_signature_v2(
        sig: str,
        session: str,
        status: str,
        amount: str,
        currency: str,
        transaction_id: str,
        secret: str,
        expected_success_url: Optional[str],
        expected_key_mode: Optional[str],
        max_age_seconds: int,
    ) -> bool:
        parts = sig.split(".")
        if len(parts) != 3 or parts[0] != "v2":
            return False
        payload_b64, hex_hmac = parts[1], parts[2]
        if not _HEX_64.match(hex_hmac):
            return False

        # HMAC is over "v2.<payload_b64>" — same string the signer computed
        signed_input = f"v2.{payload_b64}"
        expected_hmac = hmac.new(
            secret.encode(), signed_input.encode(), hashlib.sha256
        ).digest()
        if not hmac.compare_digest(bytes.fromhex(hex_hmac), expected_hmac):
            return False

        # Decode base64url-encoded JSON payload
        try:
            padded = payload_b64 + "=" * (-len(payload_b64) % 4)
            payload_json = base64.urlsafe_b64decode(padded.encode()).decode("utf-8")
            payload = json.loads(payload_json)
        except (ValueError, json.JSONDecodeError):
            return False

        # Field-by-field cross-check against URL query params
        if payload.get("sid") != session:
            return False
        if payload.get("status") != status:
            return False
        if str(payload.get("amount")) != amount:
            return False
        if payload.get("currency") != currency:
            return False
        if str(payload.get("transactionId") or "") != (transaction_id or ""):
            return False

        # successUrl: required for v2, callers must pass expected
        if expected_success_url is None:
            return False
        if payload.get("successUrl") != _normalise_success_url(expected_success_url):
            return False

        # keyMode: required for v2, callers must pass expected
        if expected_key_mode is None:
            return False
        if payload.get("keyMode") != expected_key_mode:
            return False

        # iat freshness
        iat = payload.get("iat")
        if not isinstance(iat, (int, float)):
            return False
        if time.time() - iat > max_age_seconds:
            return False
        if iat > time.time() + 60:  # sig from the future = clock skew > tolerance
            return False

        return True


def _normalise_success_url(raw: str) -> str:
    """Canonicalise a success URL the same way the Von Payments return-URL signer does.

    Rules: origin + path (single trailing slash stripped unless root) +
    sorted query params. Fragment dropped. The canonicalisation here is
    byte-identical to the server's and to the Node SDK's, which is what
    lets signed redirects round-trip across rewrites that don't change
    the effective destination (trailing slashes, query reordering).
    """
    u = urlparse(raw)
    path = u.path
    # Strip exactly ONE trailing slash (mirrors Node's `replace(/\/$/, "")`).
    # rstrip("/") would chew through multiple, diverging from Node on edge
    # paths like "/return//".
    if path.endswith("/") and path != "/":
        path = path[:-1]

    # parse_qsl decodes percent-encoded values; urlencode re-encodes once.
    # Net effect matches Node's URL+URLSearchParams (one canonical encoding),
    # so a successUrl with already-encoded chars (e.g. "?ref=a%2Fb") doesn't
    # double-encode here while staying single-encoded in Node.
    if u.query:
        pairs = sorted(parse_qsl(u.query, keep_blank_values=True), key=lambda kv: kv[0])
        qs = urlencode(pairs)
    else:
        qs = ""

    origin = f"{u.scheme}://{u.netloc}"
    return f"{origin}{path}{'?' + qs if qs else ''}"


def _webhook_subscription_from_dict(data: Dict[str, Any]) -> WebhookSubscription:
    """Parse a server JSON response into a WebhookSubscription.

    Wire format on the /v1/webhook_subscriptions surface is camelCase
    end-to-end. Field-by-field map keeps the public dataclass on
    snake_case for Python idiom while accepting camelCase off the wire
    — distinct from the global _to_snake_keys helper because the SDK
    here surfaces a strongly-typed dataclass, not a dict.
    """
    return WebhookSubscription(
        id=data["id"],
        object=data.get("object", "webhook_subscription"),
        url=data["url"],
        enabled_events=list(data.get("enabledEvents", [])),
        status=data["status"],
        description=data.get("description"),
        api_version=data.get("apiVersion"),
        last_delivery_at=data.get("lastDeliveryAt"),
        last_success_at=data.get("lastSuccessAt"),
        last_error_at=data.get("lastErrorAt"),
        created_at=data["createdAt"],
    )


def _webhook_event_record_from_dict(data: Dict[str, Any]) -> WebhookEventRecord:
    """Parse a server JSON response into a WebhookEventRecord.

    ``payload`` is passed through verbatim — integrator-defined event
    body must not be case-converted (parity with the Node SDK's
    metadata-keys-opaque rule on the read endpoints).
    """
    return WebhookEventRecord(
        id=data["id"],
        object=data.get("object", "event"),
        type=data["type"],
        received_at=data["receivedAt"],
        processed=bool(data["processed"]),
        retry_count=int(data["retryCount"]),
        next_retry_at=data.get("nextRetryAt"),
        last_error=data.get("lastError"),
        processing_error=data.get("processingError"),
        session_id=data.get("sessionId"),
        livemode=bool(data["livemode"]),
        payload=dict(data.get("payload") or {}),
    )


class _WebhookSubscriptions:
    """Public read endpoints on the Webhooks API.

    ``vp_sk_*`` Bearer required; publishable keys rejected with 403.
    Write endpoints (create / update / delete / rotate_signing_secret /
    send_test_event) are not yet exposed in this SDK.

    Wire format on these endpoints is camelCase end-to-end (matches the
    rest of ``/v1/*`` on this engine); responses are parsed field-by-field
    into typed dataclasses.
    """

    def __init__(self, client: "VonPayCheckout") -> None:
        self._client = client

    def list(
        self,
        *,
        limit: Optional[int] = None,
        starting_after: Optional[str] = None,
    ) -> WebhookSubscriptionsList:
        """``GET /v1/webhook_subscriptions`` — Stripe-shaped list envelope.

        Ordering is newest-first (``created_at DESC, id DESC``). Use the
        last item's ``id`` as ``starting_after`` to fetch the next page.
        A cursor that doesn't reference a subscription owned by the
        caller's merchant raises a 400 ``validation_error`` — the server
        deliberately does not silently restart pagination from the top
        to prevent cross-merchant id probing.
        """
        params: Dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if starting_after is not None:
            _assert_resource_id(starting_after, "starting_after")
            params["starting_after"] = starting_after
        data = self._client._request(
            "GET",
            "/v1/webhook_subscriptions",
            params=params or None,
            reporter_method="webhook_subscriptions.list",
        )
        items = [_webhook_subscription_from_dict(item) for item in data.get("data", [])]
        return WebhookSubscriptionsList(
            object=data.get("object", "list"),
            data=items,
            has_more=bool(data.get("hasMore", False)),
            url=data.get("url", "/v1/webhook_subscriptions"),
        )

    def retrieve(self, webhook_subscription_id: str) -> WebhookSubscription:
        """``GET /v1/webhook_subscriptions/:id`` — single subscription lookup.

        Returns 404 on cross-merchant id (opaque — never 403) and on a
        subscription that's been soft-deleted on the merchant side.
        """
        _assert_resource_id(webhook_subscription_id, "webhook_subscription_id")
        data = self._client._request(
            "GET",
            f"/v1/webhook_subscriptions/{quote(webhook_subscription_id, safe='')}",
            reporter_method="webhook_subscriptions.retrieve",
        )
        return _webhook_subscription_from_dict(data)


class _WebhookEvents:
    """Public point-lookup on a stored webhook event.

    ``vp_sk_*`` Bearer required. Account-level events (no ``session_id``)
    return 404 at the route layer rather than being surfaced.

    The ``webhooks.construct_event*`` helpers parse the SIGNED outbound
    payload during webhook delivery; this resource queries the stored
    record by id from your code (e.g. an admin tool, retry trigger, or
    audit dashboard).
    """

    def __init__(self, client: "VonPayCheckout") -> None:
        self._client = client

    def retrieve(self, webhook_event_id: str) -> WebhookEventRecord:
        """``GET /v1/webhook_events/:id`` — fetch a stored event record."""
        _assert_resource_id(webhook_event_id, "webhook_event_id")
        data = self._client._request(
            "GET",
            f"/v1/webhook_events/{quote(webhook_event_id, safe='')}",
            reporter_method="webhook_events.retrieve",
        )
        return _webhook_event_record_from_dict(data)
