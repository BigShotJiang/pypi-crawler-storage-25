"""SDK telemetry — anonymized error reporting to Vonpay's /v1/sdk-telemetry
endpoint.

Defaults by key type (v0.7.0+):
- ``vp_sk_test_*`` (test keys): **default ON** — integrator bugs surface
  faster during dev/staging; loud-mode posture for alpha/beta usage.
- ``vp_sk_live_*`` (live keys): **default OFF** — strict-opt-in posture
  for production.

Pass ``telemetry={"enabled": True}`` or ``{"enabled": False}`` (literal
boolean) to override either default. When telemetry first activates on a
given client instance, the SDK emits a one-time ``logging.warning``
disclosure so integrators are not surprised.

Mirrors the Node SDK's telemetry module byte-for-byte where the contract
is shared (regexes, body schema, status handling, scrub blocklist).

Privacy hard-lines:
- ``enabled`` must be a literal boolean (TypeError on non-boolean)
- No env-var override
- Local scrub before send; drop-not-redact on sensitive match
- Module never reads request body / response body of original API calls
- Module never raises to caller; fire-and-forget POST is fully isolated
- Module's own response handling uses bare ``logging.warning`` — NEVER calls
  the integrator's error_reporter (would create recursion)
"""

from __future__ import annotations

import hashlib
import json
import logging
import platform as _platform
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional

import httpx

from vonpay.checkout.errors import VonPayError

_log = logging.getLogger("vonpay.checkout")

# Server contract regexes — must match the server-side telemetry-payload
# validators byte-for-byte. The server rejects payloads that fail these
# regexes, so any drift here would cause silent telemetry loss.
_SDK_VERSION_REGEX = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(-[a-z0-9.]+)?$")

# RUNTIME_REGEX guard: cannot trip on any Python version from a normal CPython
# build — `python-{version}` is always 13+ ASCII chars matching the class.
# Retained as belt-and-suspenders against theoretical version-string tampering.
_RUNTIME_REGEX = re.compile(r"^[a-z][a-z0-9._+-]{0,62}$", re.IGNORECASE)

# Local scrub blocklist — must match the server-side telemetry blocklist
# byte-for-byte. The server is the binding source; this SDK-side mirror is
# a defense-in-depth pre-flight so we never send a payload the server will
# reject.
#
# Character classes are ASCII-only ([a-z0-9]+/i). Unicode characters in keys
# would fall outside the class. The ASCII boundary is the security boundary;
# do not widen the character class without re-auditing.
_BLOCKLIST = [
    re.compile(r"vp_(sk|pk)_(live|test)_[a-z0-9]+", re.IGNORECASE),  # Vonpay API keys
    re.compile(r"ss_(live|test)_[a-z0-9]+", re.IGNORECASE),          # Vonpay session signing secrets
    re.compile(r"whsec_[a-z0-9]+", re.IGNORECASE),                   # Stripe webhook secrets
    re.compile(r"sk_(live|test)_[a-z0-9]+", re.IGNORECASE),          # Stripe API keys
    re.compile(r"pk_(live|test)_[a-z0-9]+", re.IGNORECASE),          # Stripe publishable keys
    re.compile(r"rk_(live|test)_[a-z0-9]+", re.IGNORECASE),          # Stripe restricted keys (DevSec parity, bridge 03:57Z)
    re.compile(r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}", re.IGNORECASE),  # emails
]

_BODY_CAP_BYTES = 2048
_PAUSE_DURATION_SEC = 60.0
_PAUSE_DROP_COUNT = 30
_TELEMETRY_TIMEOUT_SEC = 5.0
_SDK_NAME = "checkout-python"

# Closed operation enum — alias map matches Node SDK byte-for-byte
_OPERATION_MAP: Dict[str, Optional[str]] = {
    "sessions.create": "sessions.create",
    "sessions.get": "sessions.retrieve",  # alias per server contract
    "webhooks.construct_event": "webhooks.constructEvent",
    "webhooks.construct_event_v2": "webhooks.constructEvent",  # V2 alias
    # RESERVED-NO-OP: server's closed enum lists verify_signature, but it
    # returns bool (no raise → no error_reporter call → no telemetry path).
    "webhooks.verify_signature": None,
    # SDK 0.5.0 — discrete-lifecycle API. Server enum uses camelCase even
    # though the Python method names are snake_case.
    "payment_intents.create": "paymentIntents.create",
    # SDK 0.7.0 — error-reporting coverage expansion: 4 new ops parity with
    # Node SDK + server schema. Without these, refund/capture/void/token
    # failures fire reportError() but mapOperation returns None → events
    # silently drop. Server validation now accepts all of these.
    "payment_intents.capture": "paymentIntents.capture",
    "payment_intents.void": "paymentIntents.void",
    "refunds.create": "refunds.create",
    "tokens.create": "tokens.create",
    "capabilities.get": "capabilities.get",
}


def map_operation(method: str) -> Optional[str]:
    """Map an SDK-internal method name to the server's closed operation enum.

    Returns None when the operation is outside the server's enum (silently skip).
    """
    return _OPERATION_MAP.get(method)


def contains_sensitive(s: str) -> bool:
    """True if the string contains any sensitive-shape token."""
    return any(pattern.search(s) is not None for pattern in _BLOCKLIST)


class Telemetry:
    """Telemetry instance — owned by VonPayCheckout when ``telemetry={"enabled": True}``
    is passed. Otherwise this class is never instantiated.
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        sdk_version: str,
        http_client: Optional[httpx.Client] = None,
        now_fn: Optional[Callable[[], float]] = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url
        self._sdk_version = sdk_version
        self._runtime = f"python-{_platform.python_version()}"
        self._injected_client = http_client is not None
        self._client: Optional[httpx.Client] = http_client
        self._now = now_fn or time.time

        # Per-instance state
        self._paused_until: Optional[float] = None
        self._drop_count: int = 0
        self._logged_status_codes: set[int] = set()  # 400, 401
        self._warned_server_error: bool = False  # 5xx
        self._warned_network_error: bool = False
        self._warned_sensitive_scrub: bool = False
        self._lock = threading.Lock()

        # Construction-time validation — run BEFORE allocating an httpx.Client
        # so a self-disabled instance leaves no socket-pool to leak.
        self._enabled = False
        if not _SDK_VERSION_REGEX.fullmatch(sdk_version):
            _log.warning(
                "[vonpay] telemetry: SDK version %r does not match server semver "
                "regex. Telemetry disabled on this instance. Report to vonpay "
                "support if this version is from PyPI.",
                sdk_version,
            )
            return
        if not _RUNTIME_REGEX.fullmatch(self._runtime):
            _log.warning(
                "[vonpay] telemetry: runtime string %r would fail server regex; disabled.",
                self._runtime,
            )
            return
        if self._client is None:
            self._client = httpx.Client(timeout=_TELEMETRY_TIMEOUT_SEC)
        self._enabled = True

    @property
    def enabled(self) -> bool:
        return self._enabled

    def close(self) -> None:
        """Release the underlying httpx.Client. Safe to call multiple times.

        Only closes the client if Telemetry created it itself; an injected
        client is the caller's lifecycle to manage.
        """
        if self._injected_client:
            return
        client = self._client
        if client is None:
            return
        self._client = None
        try:
            client.close()
        except Exception:
            pass

    def record(self, err: BaseException, ctx_method: str, ctx_attempt: Optional[int],
               ctx_status: Optional[int]) -> None:
        """Record an error event. Fire-and-forget — never raises to caller."""
        if not self._enabled:
            return

        # Atomic pause-expiry check + dual reset (locks the v1 "additive 90s
        # blackout" bug — pause window and drop counter clear together).
        with self._lock:
            now = self._now()
            if self._paused_until is not None and now >= self._paused_until:
                self._paused_until = None
                self._drop_count = 0
            if self._paused_until is not None:
                return  # still paused
            if self._drop_count > 0:
                # Defensive: legacy from incomplete pause. Unreachable in
                # normal operation because pause + drop counter clear together.
                self._drop_count -= 1
                return

        # Map operation; skip silently if outside closed enum
        operation = map_operation(ctx_method)
        if operation is None:
            return

        # Resolve error_code; non-VonPayError raises don't have a catalog code
        if not isinstance(err, VonPayError):
            return
        error_code = err.code

        # Build body
        body: Dict[str, Any] = {
            "sdk_name": _SDK_NAME,
            "sdk_version": self._sdk_version,
            "runtime": self._runtime,
            "error_code": error_code,
            "operation": operation,
            "occurred_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
        }
        if err.request_id:
            body["request_id_hash"] = hashlib.sha256(err.request_id.encode("utf-8")).hexdigest()
        if ctx_attempt is not None or ctx_status is not None:
            ctx: Dict[str, Any] = {}
            if ctx_attempt is not None:
                ctx["retry_count"] = ctx_attempt
            if ctx_status is not None:
                ctx["http_status"] = ctx_status
            body["context"] = ctx

        # Local scrub — drop entire event silently if any string matches
        for field in (
            body["sdk_name"],
            body["sdk_version"],
            body["runtime"],
            body["error_code"],
            body["operation"],
        ):
            if contains_sensitive(field):
                with self._lock:
                    if not self._warned_sensitive_scrub:
                        self._warned_sensitive_scrub = True
                        _log.warning(
                            "[vonpay] telemetry: dropped event due to sensitive-shape match. "
                            "This indicates an SDK bug — please report to support@vonpay.com."
                        )
                return

        # Body cap
        body_json = json.dumps(body, separators=(",", ":"))
        if len(body_json.encode("utf-8")) > _BODY_CAP_BYTES:
            return

        # Fire-and-forget POST — runs on a background thread so the caller
        # is never blocked.
        threading.Thread(
            target=self._send,
            args=(body_json,),
            daemon=True,
        ).start()

    def _send(self, body_json: str) -> None:
        """Background-thread send. Never raises; never blocks caller."""
        client = self._client
        if client is None:
            return  # closed mid-send (lifecycle race)
        try:
            response = client.post(
                f"{self._base_url}/v1/sdk-telemetry",
                content=body_json,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Von-Pay-Version": "2026-04-14",
                    "Content-Type": "application/json",
                    "User-Agent": f"{_SDK_NAME}/{self._sdk_version}",
                },
                timeout=_TELEMETRY_TIMEOUT_SEC,  # per-request: caller-injected clients can't widen our cap
            )
        except Exception:
            # httpx errors (timeout, connection, etc.) — silent drop, never retry.
            with self._lock:
                if not self._warned_network_error:
                    self._warned_network_error = True
                    _log.warning(
                        "[vonpay] telemetry: network/timeout. If you're behind a corporate "
                        "firewall, allowlist checkout.vonpay.com:443. See "
                        "https://docs.vonpay.com/sdk-telemetry#firewall"
                    )
            return

        status = response.status_code
        if status == 204:
            return  # success
        if status == 400:
            with self._lock:
                if 400 not in self._logged_status_codes:
                    self._logged_status_codes.add(400)
                    _log.warning(
                        "[vonpay] telemetry: 400 from server. Likely SDK schema drift OR "
                        "clock skew (server requires occurred_at ±5min of UTC; check NTP). "
                        "Disable telemetry: {'enabled': False} if persistent."
                    )
            return
        if status == 401:
            with self._lock:
                if 401 not in self._logged_status_codes:
                    self._logged_status_codes.add(401)
                    _log.warning(
                        "[vonpay] telemetry: 401 unauthorized. Check API key matches the "
                        "merchant's account."
                    )
            return
        if status == 429:
            with self._lock:
                self._paused_until = self._now() + _PAUSE_DURATION_SEC
                self._drop_count = _PAUSE_DROP_COUNT
            return
        if status >= 500:
            with self._lock:
                if not self._warned_server_error:
                    self._warned_server_error = True
                    _log.warning(
                        "[vonpay] telemetry: server unavailable; events dropping silently. "
                        "Set telemetry={'enabled': False} to stop attempts if persistent."
                    )
            return
        # Any other status — silent drop
