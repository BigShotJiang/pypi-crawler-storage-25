"""Type definitions for Von Payments Checkout SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Literal, Optional

ErrorCode = Literal[
    "auth_missing_bearer",
    "auth_invalid_key",
    "auth_key_expired",
    "auth_key_type_forbidden",
    "auth_merchant_inactive",
    "auth_service_unavailable",
    "session_not_found",
    "session_expired",
    "session_wrong_state",
    "session_integrity_error",
    "validation_error",
    "validation_missing_field",
    "validation_invalid_amount",
    "merchant_not_configured",
    "merchant_not_onboarded",
    "rate_limit_exceeded",
    "rate_limit_exceeded_per_key",
    "provider_unavailable",
    "provider_attestation_failed",
    "provider_charge_failed",
    "internal_error",
    "webhook_missing_signature",
    "webhook_invalid_signature",
    "webhook_not_configured",
    "origin_forbidden",
    "transaction_verification_failed",
    "unsupported_media_type",
    "endpoint_not_implemented",
    "idempotency_replay_incompatible",
    "invalid_transition",
    "refund_amount_exceeds_remaining",
]


PaymentIntentStatus = Literal[
    "requires_action",
    "authorized",
    "captured",
    "succeeded",
    "voided",
    "failed",
]


# Server-canonical reasons for a lifecycle-endpoint state-machine rejection.
RejectReason = Literal[
    "terminal_state",
    "not_authorized",
    "already_captured",
    "already_voided",
    "already_refunded",
    "amount_exceeds_remaining",
]


RefundStatus = Literal["pending", "succeeded", "failed"]


TokenStatus = Literal["active", "expired", "revoked"]


# MIT block enum types (mirror OpenAPI MITBlock schema).
MITInitiator = Literal["merchant", "customer"]


MITReason = Literal["recurring", "unscheduled", "installment"]


@dataclass
class MITBlock:
    """Merchant-initiated transaction signal — saved card / recurring / retry.

    Capability gate: ``capabilities.supported_operations.mit is True``. The
    chain validity predicate (server-side) rejects cross-merchant, cross-binder
    (without network tokens), and non-chargeable-anchor chains.

    ``original_transaction_id`` must be the cardholder-initiated anchor —
    typically the first successful PI the buyer authorized — so the chain
    anchors at a scheme-compliant cardholder-consent transaction ID.

    Field names are snake_case and must be explicitly mapped in
    ``_PaymentIntents.create()`` — see the ``body["mit"] = {...}`` block
    there. We do NOT use ``dataclasses.asdict``: relying on it would cause
    a future field added to this dataclass to silently drop off the wire
    if a maintainer forgot to update ``client.py``. Explicit mapping makes
    the wire contract auditable in one place.

    ``initiator`` and ``reason`` use ``Literal`` aliases so type checkers
    (mypy / pyright) catch invalid enum values at call sites — Node SDK
    parity (``MITBlock.initiator: MITInitiator`` there too).
    """

    initiator: MITInitiator
    reason: MITReason
    original_transaction_id: str


# Mirror block enum types (mirror OpenAPI MirrorBlock schema).
MirrorDestination = Literal["shopify"]


MirrorFinancialStatus = Literal["paid", "authorized"]


# Pinned contract version for the mirror block. The SDK auto-fills this when
# ``mirror`` is supplied without ``contract_version``. Bumping this value
# declares a new server-validated revision — coordinate with Vonpay before
# changing.
MIRROR_CONTRACT_VERSION = "2026-05-15"


@dataclass
class MirrorAddress:
    """Postal address for MirrorBlock shipping/billing.

    Field names align with the destination CRM's address shape (Shopify-flavoured
    for v2: ``province`` for state/region, ``address1`` / ``address2`` for
    street lines, ISO 3166-1 alpha-2 ``country``).

    Same explicit-wire-mapping rule as :class:`MITBlock`: do NOT use asdict.
    See ``_mirror_address_to_dict`` in client.py.
    """

    address1: str
    city: str
    zip: str
    country: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    address2: Optional[str] = None
    province: Optional[str] = None
    phone: Optional[str] = None
    company: Optional[str] = None


@dataclass
class MirrorTaxLine:
    """Single tax line on a :class:`MirrorLineItem`.

    ``price`` is a decimal string in merchant currency (e.g. ``"0.75"``).
    ``rate`` is the effective tax rate as a decimal (0–1, e.g. 0.0825 for 8.25%).
    """

    price: str
    rate: float
    title: str


@dataclass
class MirrorCustomer:
    """Buyer hash for the destination CRM's customer-upsert call."""

    email: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None


@dataclass
class MirrorLineItem:
    """One order line item.

    ``price`` is a decimal string in the merchant's currency (e.g. ``"12.50"``),
    NOT minor units. Vonpay handles minor-unit math from
    ``payment_intent.amount``; merchants supplying line items should not duplicate
    that conversion.
    """

    title: str
    quantity: int
    price: str
    variant_id: Optional[str] = None
    tax_lines: Optional[List[MirrorTaxLine]] = None


@dataclass
class MirrorNoteAttribute:
    """Custom name/value pair surfaced in the destination CRM."""

    name: str
    value: str


@dataclass
class MirrorBlock:
    """Order-mirror block on a payment intent.

    When present, after the payment_intent reaches ``succeeded`` Vonpay
    mirrors the captured payment into the destination platform's order
    ledger (e.g. Shopify), so the merchant's order surface reflects the
    Vonpay-captured payment.

    Versioned via ``contract_version`` for additive schema evolution;
    unknown future fields are forwarded as-is.

    Field names are snake_case and must be explicitly mapped in
    ``_PaymentIntents.create()`` — same rationale as :class:`MITBlock`.
    """

    destination: MirrorDestination
    shop: str
    line_items: List[MirrorLineItem]
    customer: MirrorCustomer
    contract_version: Optional[str] = None  # SDK auto-fills if None
    skip: Optional[bool] = None
    shipping_address: Optional[MirrorAddress] = None
    billing_address: Optional[MirrorAddress] = None
    financial_status: Optional[MirrorFinancialStatus] = None
    tags: Optional[List[str]] = None
    note_attributes: Optional[List[MirrorNoteAttribute]] = None
    send_receipt: Optional[bool] = None
    origin: Optional[str] = None


@dataclass
class PaymentIntent:
    """Response from POST /v1/payment_intents.

    Mirrors the live server response shape. ``currency`` comes back as ISO-4217
    uppercase (e.g. ``"USD"``) regardless of the case the request used.
    Capture/refund/void/tokens land with SDK 0.6.0 once the sibling routes ship.
    """

    id: str
    status: str  # PaymentIntentStatus
    amount: int
    currency: str
    capture_method: str  # "automatic" | "manual"
    next_action: Optional[str]
    decline_code: Optional[str]
    created_at: str
    metadata: Dict[str, str]


@dataclass
class CapabilitiesSupportedOperations:
    """Supported-operations matrix returned by capabilities.get.

    ``void_after_capture`` is a string discriminator: most processors do not
    permit a true void after capture and silently reroute to a refund. The
    ``"rerouted_to_refund"`` value makes that promise explicit.
    """

    auth_capture_separation: bool
    partial_capture: bool
    partial_refund: bool
    unreferenced_refund: bool
    void_after_capture: str  # "rerouted_to_refund" | "supported" | "unsupported"
    mit: bool
    network_tokens: bool
    three_d_secure_2: bool
    ach: bool
    payouts_api: bool


@dataclass
class CapabilitiesRateLimits:
    payment_intents_per_minute: int


@dataclass
class Capabilities:
    """Response from GET /v1/capabilities."""

    supported_operations: CapabilitiesSupportedOperations
    settlement_currencies: List[str]
    rate_limits: CapabilitiesRateLimits


@dataclass
class Refund:
    """Response from POST /v1/refunds.

    ``id`` carries the ``vpr_test_*`` / ``vpr_live_*`` prefix. ``metadata`` is
    always materialised as a dict (``{}`` when the wire response omits it),
    matching ``PaymentIntent``'s contract — callers can read ``refund.metadata``
    without a None check.
    """

    id: str
    payment_intent: str
    amount: int
    currency: str
    status: str  # RefundStatus
    reason: Optional[str]
    metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class TokenCard:
    """Card sub-object on a Token response."""

    brand: str
    last4: str
    exp_month: int
    exp_year: int


@dataclass
class Token:
    """Response from POST /v1/tokens.

    ``id`` carries the ``vp_pmt_test_*`` / ``vp_pmt_live_*`` prefix (NOT the
    speculative ``vtk_*`` prefix from the original 0.5.0 design doc).
    """

    id: str
    status: str  # TokenStatus
    card: TokenCard


# Session mode discriminator. Server currently accepts only "payment" but the
# field is wire-versioned so additional modes (setup, subscription) can be
# introduced without an SDK bump. Mirrors Node's CreateSessionParams.mode.
SessionMode = Literal["payment"]


@dataclass
class LineItem:
    """Itemized line for a checkout session.

    Mirrors the OpenAPI ``LineItem`` schema and Node's ``LineItem`` interface.
    Field names are snake_case on the dataclass and mapped explicitly to
    camelCase on the wire (``unit_amount`` → ``unitAmount``, ``image_url`` →
    ``imageUrl``) inside ``_Sessions.create``. We do not use
    ``dataclasses.asdict`` here for the same reason as :class:`MITBlock` —
    explicit wire mapping keeps the contract auditable in one place and stops
    a future field from silently dropping off the wire.
    """

    name: str
    quantity: int
    unit_amount: int
    image_url: Optional[str] = None


@dataclass
class CheckoutSession:
    """Response from POST /v1/sessions."""

    id: str
    checkout_url: str
    expires_at: str


@dataclass
class SessionStatus:
    """Response from GET /v1/sessions/:id."""

    id: str
    status: str  # pending, succeeded, failed, expired
    mode: str
    merchant_id: str
    amount: int
    currency: str
    created_at: str
    updated_at: str
    expires_at: str
    country: Optional[str] = None
    description: Optional[str] = None
    collect_shipping: Optional[bool] = None
    shipping_address: Optional[Dict[str, str]] = None
    transaction_id: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None


@dataclass
class DryRunResult:
    """Response from POST /v1/sessions?dry_run=true."""

    valid: bool
    warnings: List[str] = field(default_factory=list)


@dataclass
class WebhookEvent:
    """Parsed webhook payload."""

    event: str
    session_id: str
    merchant_id: str
    amount: int
    currency: str
    status: str
    timestamp: str
    transaction_id: Optional[str] = None
    error: Optional[str] = None
    failure_code: Optional[str] = None
    refund_id: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None


@dataclass
class HealthStatus:
    """API health check result."""

    status: str
    latency_ms: float
    version: str


@dataclass
class RateLimitInfo:
    """Rate limit information from response headers."""

    limit: int
    remaining: int
    reset: int
    retry_after: Optional[int] = None


@dataclass
class ErrorReporterContext:
    """Diagnostic context passed to ``error_reporter``.

    Attributes:
        method: SDK method that produced the error (e.g. ``"sessions.create"``,
            ``"webhooks.construct_event"``).
        sdk_version: SDK package version.
        url: Origin + path of the request that failed (no query string, no PII).
        status: HTTP status code, when the error originated from an API response.
        request_id: Server-assigned request id (``X-Request-Id`` header) for correlation.
        code: Server error code, when from an API response (``auth_invalid_key``, etc.).
        attempt: Retry attempt number (0-indexed; 0 = first try). Only set on
            ``_request`` failures.
    """

    method: str
    sdk_version: str
    url: Optional[str] = None
    status: Optional[int] = None
    request_id: Optional[str] = None
    code: Optional[str] = None
    attempt: Optional[int] = None


# Signature for the optional error-reporting callback. See VonPayCheckout's
# ``error_reporter`` parameter for the full contract (synchronous,
# fire-and-forget, swallows reporter exceptions). The SDK only passes
# Exception instances (VonPayError or httpx.HTTPError) — never BaseException
# subclasses like KeyboardInterrupt or SystemExit.
ErrorReporter = Callable[[Exception, ErrorReporterContext], None]


WebhookSubscriptionStatus = Literal["active", "paused", "disabled"]


@dataclass
class WebhookSubscription:
    """A merchant's registered webhook endpoint.

    Mirrors the Node SDK's ``WebhookSubscription`` interface. Returned by
    the public Webhooks API read endpoints:

      - ``GET /v1/webhook_subscriptions``        (list)
      - ``GET /v1/webhook_subscriptions/:id``    (single)

    The signing secret is never present on a read response. Rotate via
    the write endpoints (not yet exposed in this SDK) when access is lost.

    ``api_version`` is ``None`` on subscriptions created before the
    ``api_version`` column primitive shipped.
    """

    id: str
    object: Literal["webhook_subscription"]
    url: str
    enabled_events: List[str]
    status: WebhookSubscriptionStatus
    description: Optional[str]
    api_version: Optional[str]
    last_delivery_at: Optional[str]
    last_success_at: Optional[str]
    last_error_at: Optional[str]
    created_at: str


@dataclass
class WebhookSubscriptionsList:
    """Stripe-shaped list envelope for ``webhook_subscriptions.list``."""

    object: Literal["list"]
    data: List[WebhookSubscription]
    has_more: bool
    url: str


@dataclass
class WebhookEventRecord:
    """Stored webhook-event record from ``GET /v1/webhook_events/:id``.

    Distinct from ``WebhookEvent`` — that type models the delivered/signed
    payload that ``webhooks.construct_event`` parses. This is the durable
    queryable record of an inbound provider webhook plus dispatcher state.

    ``last_error`` and ``processing_error`` are server-scrubbed (Bearer
    tokens, ``vp_sk_*``, etc. redacted) before crossing the trust
    boundary. ``payload`` is scrubbed for PCI/PII patterns. The SDK
    does NOT re-validate — defense-in-depth lives server-side.

    ``session_id`` is ``None`` for account-level events; the public
    route returns 404 in that case rather than surfacing them, so a
    non-None ``session_id`` is effectively guaranteed when the call
    succeeds.
    """

    id: str
    object: Literal["event"]
    type: str
    received_at: str
    processed: bool
    retry_count: int
    next_retry_at: Optional[str]
    last_error: Optional[str]
    processing_error: Optional[str]
    session_id: Optional[str]
    livemode: bool
    payload: Dict[str, Any]
