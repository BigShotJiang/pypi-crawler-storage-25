__version__ = "0.1.2"

from .client import FinSightDataClient

__all__ = ["FinSightDataClient", "__version__"]
