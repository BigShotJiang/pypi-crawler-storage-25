"""
`claude-session-sync config` サブコマンド実装

Usage:
    claude-session-sync config add-placeholder NAME=PATH
    claude-session-sync config show
    claude-session-sync config set-path PLACEHOLDER_NAME MACHINE_ID PATH
"""
from __future__ import annotations

import argparse
import os
import sys


def run(args: argparse.Namespace) -> None:
    subcommand = getattr(args, "config_subcommand", None)

    if subcommand == "add-placeholder":
        _run_add_placeholder(args)
    elif subcommand == "show":
        _run_show(args)
    elif subcommand == "set-path":
        _run_set_path(args)
    elif subcommand == "set-remote":
        _run_set_remote(args)
    else:
        print("使用方法:")
        print("  claude-session-sync config add-placeholder NAME=PATH")
        print("  claude-session-sync config show")
        print("  claude-session-sync config set-path PLACEHOLDER_NAME MACHINE_ID PATH")
        print("  claude-session-sync config set-remote URL")
        sys.exit(1)


def _run_add_placeholder(args: argparse.Namespace) -> None:
    """add-placeholder NAME=PATH を処理する。"""
    from claude_session_sync.config import Config
    from claude_session_sync.shared_placeholders import (
        load_shared_placeholders,
        save_shared_placeholders,
        set_machine_path,
        SHARED_PLACEHOLDERS_FILENAME,
    )
    from claude_session_sync.git_ops import git_add, git_commit, git_push

    config = Config.load()
    if not config.machine_id:
        print("設定が見つかりません。先に `init` を実行してください。")
        sys.exit(1)

    name_path: str = getattr(args, "name_path", "") or ""
    if "=" not in name_path:
        print("形式: claude-session-sync config add-placeholder NAME=PATH")
        print("例:   claude-session-sync config add-placeholder PROJECTS=/home/tubome/projects")
        sys.exit(1)

    name, _, path = name_path.partition("=")
    name = name.strip()
    path = path.strip()

    if not name or not path:
        print("名前とパスを両方指定してください。")
        sys.exit(1)

    # ローカル config.json を更新
    placeholder_key = f"{{{{{name}}}}}"
    config.placeholders[placeholder_key] = path
    config.custom_placeholders[name] = path
    config.save()
    print(f"ローカル設定を更新しました: {placeholder_key} = {path}")

    # shared_placeholders.json を更新
    sync_repo_dir = config.sync_repo_dir
    shared_data = set_machine_path(sync_repo_dir, name, config.machine_id, path)
    save_shared_placeholders(sync_repo_dir, shared_data)
    print(f"共有プレースホルダを更新しました: {name}[{config.machine_id}] = {path}")

    # git commit & push
    if os.path.isdir(os.path.join(sync_repo_dir, ".git")):
        try:
            git_add(sync_repo_dir, [SHARED_PLACEHOLDERS_FILENAME])
            git_commit(sync_repo_dir, f"config: add placeholder {name} for {config.machine_id}")
            git_push(sync_repo_dir)
            print("shared_placeholders.json をリポジトリにプッシュしました。")
        except Exception as e:
            print(f"プッシュに失敗しました (手動でプッシュしてください): {e}")


def _run_show(args: argparse.Namespace) -> None:
    """show: 現在の設定を表示する。"""
    from claude_session_sync.config import Config
    from claude_session_sync.shared_placeholders import load_shared_placeholders

    config = Config.load()
    if not config.machine_id:
        print("設定が見つかりません。先に `init` を実行してください。")
        sys.exit(1)

    print("=== ローカル設定 ===")
    print(f"  マシンID        : {config.machine_id}")
    git_backend = config.git_backend
    if git_backend == "custom":
        print(f"  バックエンド    : カスタム Git")
        print(f"  リモートURL     : {config.github_remote_url}")
    else:
        print(f"  GitHubオーナー  : {config.github_owner}")
        print(f"  GitHubリポジトリ: {config.github_repo}")
        print(f"  リモートURL     : {config.github_remote_url}")
    print(f"  同期ディレクトリ: {config.sync_repo_dir}")
    print(f"  プロジェクト    : {config.claude_projects_dir}")
    print(f"  履歴ファイル    : {config.claude_history_file}")
    print(f"  最終プッシュ    : {config.last_push_at or '未実行'}")
    print(f"  最終プル        : {config.last_pull_at or '未実行'}")

    if config.placeholders:
        print("  プレースホルダ  :")
        for k, v in sorted(config.placeholders.items()):
            print(f"    {k} = {v}")

    if config.custom_placeholders:
        print("  カスタムプレースホルダ:")
        for k, v in sorted(config.custom_placeholders.items()):
            print(f"    {k} = {v}")

    print("")
    print("=== 共有プレースホルダ ===")
    sync_repo_dir = config.sync_repo_dir
    if os.path.isdir(sync_repo_dir):
        shared = load_shared_placeholders(sync_repo_dir)
        ph = shared.get("placeholders", {})
        if ph:
            for name, machines in sorted(ph.items()):
                print(f"  {name}:")
                for mid, p in sorted(machines.items()):
                    marker = " <-- このマシン" if mid == config.machine_id else ""
                    print(f"    {mid}: {p}{marker}")
        else:
            print("  (共有プレースホルダなし)")
    else:
        print("  (同期リポジトリが見つかりません)")


def _run_set_path(args: argparse.Namespace) -> None:
    """set-path PLACEHOLDER_NAME MACHINE_ID PATH を処理する。"""
    from claude_session_sync.config import Config
    from claude_session_sync.shared_placeholders import (
        save_shared_placeholders,
        set_machine_path,
        SHARED_PLACEHOLDERS_FILENAME,
    )
    from claude_session_sync.git_ops import git_add, git_commit, git_push

    config = Config.load()
    if not config.machine_id:
        print("設定が見つかりません。先に `init` を実行してください。")
        sys.exit(1)

    placeholder_name: str = getattr(args, "placeholder_name", "") or ""
    target_machine: str = getattr(args, "target_machine", "") or ""
    path: str = getattr(args, "path", "") or ""

    if not placeholder_name or not target_machine or not path:
        print("使用方法: claude-session-sync config set-path PLACEHOLDER_NAME MACHINE_ID PATH")
        print("例:       claude-session-sync config set-path PROJECTS macbook /Users/tubome/projects")
        sys.exit(1)

    sync_repo_dir = config.sync_repo_dir
    shared_data = set_machine_path(sync_repo_dir, placeholder_name, target_machine, path)
    save_shared_placeholders(sync_repo_dir, shared_data)
    print(f"共有プレースホルダを更新しました: {placeholder_name}[{target_machine}] = {path}")

    # git commit & push
    if os.path.isdir(os.path.join(sync_repo_dir, ".git")):
        try:
            git_add(sync_repo_dir, [SHARED_PLACEHOLDERS_FILENAME])
            git_commit(
                sync_repo_dir,
                f"config: set {placeholder_name} path for {target_machine}",
            )
            git_push(sync_repo_dir)
            print("shared_placeholders.json をリポジトリにプッシュしました。")
        except Exception as e:
            print(f"プッシュに失敗しました (手動でプッシュしてください): {e}")


def _run_set_remote(args: argparse.Namespace) -> None:
    """set-remote URL: リモートGitリポジトリのURLを変更する。"""
    import re
    import subprocess
    from claude_session_sync.config import Config

    config = Config.load()
    if not config.machine_id:
        print("設定が見つかりません。先に `init` を実行してください。")
        sys.exit(1)

    new_url: str = getattr(args, "url", "") or ""
    if not new_url:
        print("使用方法: claude-session-sync config set-remote URL")
        sys.exit(1)

    old_url = config.github_remote_url
    print(f"現在のリモート: {old_url}")
    print(f"新しいリモート: {new_url}")

    sync_repo_dir = config.sync_repo_dir
    if not os.path.isdir(os.path.join(sync_repo_dir, ".git")):
        print("エラー: 同期リポジトリが見つかりません。先に `init` を実行してください。")
        sys.exit(1)

    # リモートURLを変更
    try:
        subprocess.run(
            ["git", "remote", "set-url", "origin", new_url],
            cwd=sync_repo_dir,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as e:
        print(f"リモートURLの変更に失敗しました: {e}")
        sys.exit(1)

    # 新しいリモートにプッシュ
    print("新しいリモートにプッシュしています...")
    try:
        subprocess.run(
            ["git", "push", "-u", "origin", "main"],
            cwd=sync_repo_dir,
            check=True,
            capture_output=True,
            text=True,
        )
        print("[OK] 新しいリモートにプッシュしました")
    except subprocess.CalledProcessError as e:
        stderr = e.stderr or ""
        print(f"警告: プッシュに失敗しました (後で手動でプッシュできます): {stderr}")
        print(f"  手動でプッシュ: cd {config.sync_repo_dir} && git push -u origin main")

    # 設定を更新
    config.github_remote_url = new_url
    # URLからバックエンド種別を判定
    if "github.com" in new_url:
        config.git_backend = "github"
        # Parse owner/repo from GitHub URL
        # Handles: https://github.com/owner/repo.git, https://github.com/owner/repo
        match = re.search(r"github\.com[/:]([^/]+)/([^/.]+)", new_url)
        if match:
            config.github_owner = match.group(1)
            config.github_repo = match.group(2)
    else:
        config.git_backend = "custom"
        config.github_owner = ""
        config.github_repo = ""
    config.save()
    print("[OK] 設定ファイルを更新しました")
