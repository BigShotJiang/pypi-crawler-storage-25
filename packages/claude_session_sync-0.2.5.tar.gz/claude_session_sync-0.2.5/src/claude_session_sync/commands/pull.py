"""
`claude-session-sync pull` コマンド実装
"""
from __future__ import annotations

import argparse
import sys


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.sync import pull_sessions

    # 1. 設定読み込み
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    dry_run: bool = getattr(args, "dry_run", False)
    force: bool = getattr(args, "force", False)

    if dry_run:
        print("=== dry-run モード: 実際のプルは行いません ===")
    if force:
        print("=== force モード: 既存セッションを上書きします ===")

    # 2. プル実行
    try:
        pulled_ids = pull_sessions(config, dry_run=dry_run, force=force)
    except Exception as e:
        print(f"プル中にエラーが発生しました: {e}")
        sys.exit(1)

    # 3. 結果表示
    if dry_run:
        print(f"\n取得対象セッション数: {len(pulled_ids)}")
        if pulled_ids:
            print("プル対象セッション ID 一覧:")
            for sid in pulled_ids:
                print(f"  - {sid}")
    else:
        if pulled_ids:
            print(f"\nプル完了: {len(pulled_ids)} 件のセッションを取得しました。")
            if getattr(args, "verbose", False):
                for sid in pulled_ids:
                    print(f"  - {sid}")
        else:
            print("新しいセッションはありませんでした。")
