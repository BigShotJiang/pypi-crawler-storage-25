"""
`claude-session-sync resume` コマンド実装

フロー:
1. pull（最新セッションを取得）
2. 全マシンのセッション一覧を表示（ローカル + リモート）
3. ロック中のセッションには 🔒 マーク
4. ユーザーが番号で選択
5. ロック中なら警告 + 確認 [y/N]
6. ロック取得
7. daemon をバックグラウンドで起動（push のみ / --push-only）
8. `claude --resume <session-id>` を subprocess.run で実行（ブロッキング）
9. Claude Code 終了後: push → ロック解放 → daemon 停止
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _reset_terminal() -> None:
    """Claude Code（TUI）終了後にターミナル状態をリセットする。"""
    try:
        if sys.platform == "win32":
            # Windows: stty sane でターミナルをリセット（Git Bash / MSYS2 環境）
            subprocess.run(
                ["stty", "sane"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            # Unix: stty sane でターミナルをリセット
            os.system("stty sane 2>/dev/null")
    except Exception:
        pass


def _relative_time(ts: float) -> str:
    """Unix タイムスタンプから相対時間文字列を返す。"""
    diff = time.time() - ts
    if diff < 60:
        return "たった今"
    if diff < 3600:
        minutes = int(diff / 60)
        return f"{minutes}分前"
    if diff < 86400:
        hours = int(diff / 3600)
        return f"{hours}時間前"
    days = int(diff / 86400)
    return f"{days}日前"


def _shorten_path(path: str) -> str:
    """HOME を ~ に短縮し、OSに合ったパス区切りで表示する。

    Windows ではフルパス（バックスラッシュ形式）をそのまま返す。
    Linux / macOS では HOME を ~ に短縮する。
    """
    if sys.platform == "win32":
        # Windows: フルパスをバックスラッシュで返す
        return path.replace("/", "\\")
    # Unix系: HOME を ~ に短縮
    home = str(Path.home()).replace("\\", "/")
    path_normalized = path.replace("\\", "/")
    if path_normalized.startswith(home):
        return "~" + path_normalized[len(home):]
    return path_normalized


def _truncate(text: str, width: int) -> str:
    """テキストを指定文字数に切り詰める。"""
    if len(text) <= width:
        return text
    return text[: width - 3] + "..."


def _warn_locked_session(lock: dict, config_machine_id: str) -> bool:
    """ロック中のセッションを選択した場合に警告を表示。

    Returns True if user wants to continue, False to cancel.
    """
    locked_by = lock.get("machine_id", "unknown")
    is_same_machine = (locked_by == config_machine_id)

    if is_same_machine:
        print(f"\n[!] このセッションはこのマシンで既にロック中です。")
        print()
        print("  考えられる状況:")
        print("    A. 別のターミナルで作業中 → N を選んでください")
        print("    B. 前回のセッションが正常に終了しなかった → y で続行してください")
    else:
        print(f"\n[!] このセッションは {locked_by} が作業中です。")
        print()
        print("  考えられる状況:")
        print(f"    A. {locked_by} で実際に作業中 → N を選んでください")
        print("    B. 前回のセッションが正常に終了しなかった → y で続行してください")

    print()
    try:
        answer = input("  続行しますか？ [y/N]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nキャンセルしました。")
        return False
    return answer in ("y", "yes")


def _extract_first_message(jsonl_path: str) -> str:
    """JSONL ファイルから最初のユーザーメッセージを抽出する。"""
    try:
        with open(jsonl_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if record.get("type") != "user":
                    continue
                msg = record.get("message", {})
                if isinstance(msg, dict):
                    content = msg.get("content", "")
                    if isinstance(content, str) and content:
                        return content
                    if isinstance(content, list):
                        for part in content:
                            if isinstance(part, dict) and part.get("type") == "text":
                                text = part.get("text", "")
                                if text:
                                    return text
    except Exception:
        pass
    return ""


def _extract_project_path(jsonl_path: str) -> str:
    """JSONL ファイルから cwd（プロジェクトパス）を抽出する。"""
    try:
        with open(jsonl_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                cwd = record.get("cwd", "")
                if cwd:
                    return cwd
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# session file helpers
# ---------------------------------------------------------------------------

def _find_session_file(config, session_id: str) -> str:
    """セッションIDからローカルのJSONLファイルパスを探す。"""
    projects_dir = Path(config.claude_projects_dir)
    if projects_dir.is_dir():
        for project_dir in projects_dir.iterdir():
            if not project_dir.is_dir():
                continue
            candidate = project_dir / f"{session_id}.jsonl"
            if candidate.is_file():
                return str(candidate)
    # sync_repo_dir 内も探す
    sessions_dir = Path(config.sync_repo_dir) / "sessions"
    if sessions_dir.is_dir():
        for machine_dir in sessions_dir.iterdir():
            if not machine_dir.is_dir():
                continue
            for proj_dir in machine_dir.iterdir():
                if not proj_dir.is_dir():
                    continue
                candidate = proj_dir / f"{session_id}.jsonl"
                if candidate.is_file():
                    return str(candidate)
    return ""


# ---------------------------------------------------------------------------
# lock helpers
# ---------------------------------------------------------------------------

def _force_takeover_lock(sync_repo_dir: str, session_id: str, machine_id: str) -> None:
    """既存のロックを強制的に自マシンのロックに書き換える。"""
    from datetime import timedelta
    from claude_session_sync.session_lock import _lock_file, _write_lock, _now_utc, _fmt_dt

    path = _lock_file(sync_repo_dir, session_id)
    now = _now_utc()
    expires_at = now + timedelta(minutes=10)
    lock_data = {
        "session_id": session_id,
        "machine_id": machine_id,
        "locked_at": _fmt_dt(now),
        "expires_at": _fmt_dt(expires_at),
    }
    _write_lock(path, lock_data)


# ---------------------------------------------------------------------------
# session list building
# ---------------------------------------------------------------------------

def _in_sync_directories(project_path: str, sync_dirs: list) -> bool:
    """Return True if project_path is within any of sync_dirs."""
    if not sync_dirs:
        return True  # no filter — include all
    # Windows バックスラッシュを正規化
    project_path = project_path.replace("\\", "/")
    for sd in sync_dirs:
        sd_normalized = sd.replace("\\", "/").rstrip("/")
        if project_path == sd_normalized or project_path.startswith(sd_normalized + "/"):
            return True
    return False


def build_session_list(
    config,
    from_machine: Optional[str] = None,
    show_all: bool = False,
) -> list[dict]:
    """
    ローカル + リモートの全セッションを収集して返す。

    Parameters
    ----------
    config : Config
    from_machine : str or None
        指定した場合、そのマシンIDのセッションのみ返す
    show_all : bool
        True の場合、sync_directories フィルタを無効にして全セッションを返す

    Returns
    -------
    list[dict]
        セッション情報の辞書リスト。最終更新日時の降順。
        各要素:
          session_id, machine_id, project_path, first_message,
          last_modified, file_path
    """
    from claude_session_sync.session import discover_sessions

    # ローカルセッションを取得（このマシン）
    local_sessions_map: dict[str, dict] = {}
    try:
        local_sessions = discover_sessions(config.claude_projects_dir)
        for s in local_sessions:
            local_sessions_map[s.session_id] = {
                "session_id": s.session_id,
                "machine_id": config.machine_id,
                "project_path": s.project_path,
                "first_message": s.first_message,
                "last_modified": s.last_modified,
                "file_path": s.file_path,
            }
    except Exception:
        pass

    # リモートセッションを取得（sync_repo_dir/sessions/）
    # プレースホルダ → ローカルパス変換用のマッパーを構築
    from claude_session_sync.path_mapper import PathMapper
    from claude_session_sync.shared_placeholders import get_machine_placeholders_as_mapper_dict
    _mapper_placeholders = dict(config.placeholders)
    if os.path.isdir(config.sync_repo_dir):
        _shared = get_machine_placeholders_as_mapper_dict(config.sync_repo_dir, config.machine_id)
        for k, v in _shared.items():
            if k not in _mapper_placeholders:
                _mapper_placeholders[k] = v
    from claude_session_sync.config import Config as _Cfg
    for k, v in _Cfg.fallback_placeholders().items():
        if k not in _mapper_placeholders:
            _mapper_placeholders[k] = v
    _path_mapper = PathMapper(_mapper_placeholders)

    remote_sessions_map: dict[str, dict] = {}
    sessions_root = os.path.join(config.sync_repo_dir, "sessions")
    if os.path.isdir(sessions_root):
        paths_json_path = os.path.join(sessions_root, "_paths.json")
        if os.path.isfile(paths_json_path):
            # 新形式: sessions/_paths.json が存在する場合
            try:
                with open(paths_json_path, encoding="utf-8") as _f:
                    _paths_data = json.load(_f)
            except (json.JSONDecodeError, OSError):
                _paths_data = {}
            for placeholder_project_dir in _paths_data.keys():
                proj_dir_path = os.path.join(sessions_root, placeholder_project_dir)
                if not os.path.isdir(proj_dir_path):
                    continue
                for fname in os.listdir(proj_dir_path):
                    if not fname.endswith(".jsonl"):
                        continue
                    fpath = os.path.join(proj_dir_path, fname)
                    try:
                        stat = os.stat(fpath)
                    except OSError:
                        continue
                    session_id = fname.replace(".jsonl", "")
                    project_path = _extract_project_path(fpath) or placeholder_project_dir
                    # プレースホルダをローカルパスに変換（リモートのパスを現環境に合わせる）
                    project_path = _path_mapper.to_local(project_path)
                    first_message = _extract_first_message(fpath)
                    # machine_id は session_meta の last_editor から取得（フォールバック: config.machine_id）
                    meta_machine_id = config.machine_id
                    meta_path = os.path.join(config.sync_repo_dir, "session_meta", f"{session_id}.json")
                    if os.path.isfile(meta_path):
                        try:
                            with open(meta_path, encoding="utf-8") as _mf:
                                _meta = json.load(_mf)
                            meta_machine_id = _meta.get("last_editor", config.machine_id)
                        except (json.JSONDecodeError, OSError):
                            pass
                    remote_sessions_map[session_id] = {
                        "session_id": session_id,
                        "machine_id": meta_machine_id,
                        "project_path": project_path,
                        "first_message": first_message,
                        "last_modified": stat.st_mtime,
                        "file_path": fpath,
                    }
        else:
            # 旧形式フォールバック: sessions/{machine_id}/{project_dir}/{session_id}.jsonl
            for machine_id in os.listdir(sessions_root):
                machine_dir = os.path.join(sessions_root, machine_id)
                if not os.path.isdir(machine_dir):
                    continue
                for project_dir in os.listdir(machine_dir):
                    project_dir_path = os.path.join(machine_dir, project_dir)
                    if not os.path.isdir(project_dir_path):
                        continue
                    for fname in os.listdir(project_dir_path):
                        if not fname.endswith(".jsonl"):
                            continue
                        fpath = os.path.join(project_dir_path, fname)
                        try:
                            stat = os.stat(fpath)
                        except OSError:
                            continue
                        session_id = fname.replace(".jsonl", "")
                        project_path = _extract_project_path(fpath) or project_dir
                        # プレースホルダをローカルパスに変換（リモートのパスを現環境に合わせる）
                        project_path = _path_mapper.to_local(project_path)
                        first_message = _extract_first_message(fpath)
                        remote_sessions_map[session_id] = {
                            "session_id": session_id,
                            "machine_id": machine_id,
                            "project_path": project_path,
                            "first_message": first_message,
                            "last_modified": stat.st_mtime,
                            "file_path": fpath,
                        }

    # 重複排除: ローカル優先でマージ
    merged: dict[str, dict] = {}
    merged.update(remote_sessions_map)
    merged.update(local_sessions_map)  # ローカルで上書き（優先）

    # session_meta からlast_editorを読み込む
    session_meta_dir = os.path.join(config.sync_repo_dir, "session_meta")
    if os.path.isdir(session_meta_dir):
        for sid, s in merged.items():
            meta_path = os.path.join(session_meta_dir, f"{sid}.json")
            if os.path.isfile(meta_path):
                try:
                    with open(meta_path, encoding="utf-8") as f:
                        meta = json.load(f)
                    s["last_editor"] = meta.get("last_editor", s["machine_id"])
                    # session_meta の last_modified で上書き（全マシンで同一値を表示するため）
                    meta_mtime = meta.get("last_modified")
                    if meta_mtime is not None:
                        s["last_modified"] = meta_mtime
                except (json.JSONDecodeError, OSError):
                    pass

    # from_machine フィルタ
    result = list(merged.values())
    if from_machine:
        result = [s for s in result if s["machine_id"] == from_machine]

    # sync_directories フィルタ（--all が指定されていない場合のみ）
    if not show_all:
        sync_dirs = getattr(config, "sync_directories", []) or []
        if sync_dirs:
            result = [
                s for s in result
                if _in_sync_directories(s.get("project_path", ""), sync_dirs)
            ]

    # 最終更新日時の降順でソート
    result.sort(key=lambda s: s["last_modified"], reverse=True)
    return result


def print_session_list(sessions: list[dict], config, lock_info_cache: dict[str, Optional[dict]]) -> None:
    """セッション一覧をテーブル形式で表示する。"""
    col_num = 3
    col_id = 8
    col_machine = 12
    col_project = 24
    col_time = 10
    col_message = 36

    header = (
        f"{'#':<{col_num}}  "
        f"{'ID':<{col_id}}  "
        f"{'マシン':<{col_machine}}  "
        f"{'プロジェクト':<{col_project}}  "
        f"{'最終更新':<{col_time}}  "
        f"{'メッセージ':<{col_message}}"
    )
    print()
    print(header)
    print("-" * len(header))

    for i, s in enumerate(sessions, start=1):
        lock = lock_info_cache.get(s["session_id"])
        lock_marker = "🔒 " if lock else "   "

        project_display = _shorten_path(s["project_path"]) if s["project_path"] else "-"
        time_display = _relative_time(s["last_modified"])
        msg_display = _truncate(s["first_message"], col_message)

        session_id_short = s["session_id"][:8]

        row = (
            f"{i:<{col_num}} {lock_marker}"
            f"{session_id_short:<{col_id}}  "
            f"{_truncate(s.get('last_editor', s['machine_id']), col_machine):<{col_machine}}  "
            f"{_truncate(project_display, col_project):<{col_project}}  "
            f"{time_display:<{col_time}}  "
            f"{msg_display}"
        )
        print(row)

    print()


# ---------------------------------------------------------------------------
# daemon management for resume
# ---------------------------------------------------------------------------

RESUME_DAEMON_PID_FILE = Path.home() / ".claude-session-sync" / "resume_daemon.pid"


def _start_push_daemon(config, interval: int = 300) -> Optional[int]:
    """
    push-only daemon をバックグラウンドで起動する。

    Returns
    -------
    int or None
        起動した daemon の PID、失敗した場合は None
    """
    # 前回の残留 stop ファイルをクリーンアップ（残っていると新 daemon が即停止する）
    from claude_session_sync.commands.daemon import PID_DIR, STOP_FILE
    try:
        STOP_FILE.unlink(missing_ok=True)
    except OSError:
        pass

    # 既存daemonのチェック
    for pid_file in [RESUME_DAEMON_PID_FILE, PID_DIR / "daemon.pid"]:
        if pid_file.exists():
            try:
                existing_pid = int(pid_file.read_text(encoding="utf-8").strip())
                # プロセスが生きているか確認
                if sys.platform == "win32":
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    handle = kernel32.OpenProcess(0x1000, False, existing_pid)  # PROCESS_QUERY_LIMITED_INFORMATION
                    if handle:
                        kernel32.CloseHandle(handle)
                        print(f"既存のdaemonが動作中です (PID: {existing_pid})")
                        return existing_pid
                else:
                    os.kill(existing_pid, 0)  # シグナル0で存在確認
                    print(f"既存のdaemonが動作中です (PID: {existing_pid})")
                    return existing_pid
            except (ValueError, OSError, ProcessLookupError, PermissionError):
                # PIDファイルが壊れているか、プロセスが死んでいる → 無視して続行
                pass

    cmd = [
        sys.executable, "-m", "claude_session_sync",
        "daemon",
        "--push-only",
        "--quiet",
        "--interval", str(interval),
    ]

    # claude-session-sync コマンドが使えるか確認
    import shutil
    css_cmd = shutil.which("claude-session-sync")
    if css_cmd:
        cmd = [css_cmd, "daemon", "--push-only", "--quiet", "--interval", str(interval)]

    try:
        if sys.platform == "win32":
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW,
            )
        else:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        # PID ファイルに書き込む
        RESUME_DAEMON_PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        RESUME_DAEMON_PID_FILE.write_text(str(proc.pid), encoding="utf-8")
        return proc.pid
    except Exception as e:
        print(f"警告: daemon の起動に失敗しました: {e}", file=sys.stderr)
        return None


def _stop_push_daemon() -> None:
    """resume 用 daemon を停止する。"""
    import signal as _signal
    from claude_session_sync.commands.daemon import PID_DIR, STOP_FILE

    if not RESUME_DAEMON_PID_FILE.exists():
        return

    try:
        pid = int(RESUME_DAEMON_PID_FILE.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return
    finally:
        try:
            RESUME_DAEMON_PID_FILE.unlink(missing_ok=True)
        except OSError:
            pass

    if sys.platform == "win32":
        PID_DIR.mkdir(parents=True, exist_ok=True)
        STOP_FILE.write_text("stop", encoding="utf-8")
    else:
        try:
            os.kill(pid, _signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            pass


# ---------------------------------------------------------------------------
# main run
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.sync import pull_sessions, push_sessions
    from claude_session_sync.session_lock import acquire_lock, release_lock, check_lock

    # 設定確認
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    session_id_arg: Optional[str] = getattr(args, "session_id", None)
    latest: bool = getattr(args, "latest", False)
    from_machine: Optional[str] = getattr(args, "from_machine", None)
    show_all: bool = getattr(args, "show_all", False)

    # 1. pull（最新セッションを取得）
    print("セッションを同期中...")
    try:
        pull_sessions(config, dry_run=False, force=False)
    except Exception as e:
        print(f"警告: pull に失敗しました（続行します）: {e}", file=sys.stderr)

    # セッションIDを直接指定した場合は一覧スキップ
    if session_id_arg:
        selected_session_id = session_id_arg
        # ロックチェック
        lock = check_lock(config.sync_repo_dir, selected_session_id)
        if lock:
            if not _warn_locked_session(lock, config.machine_id):
                print("キャンセルしました。")
                sys.exit(0)
            # 異なるマシンのロックは強制的に自マシンに引き継ぐ
            if lock.get("machine_id") != config.machine_id:
                _force_takeover_lock(config.sync_repo_dir, selected_session_id, config.machine_id)
                print("[OK] ロックを引き継ぎました")
    else:
        # 2. セッション一覧を構築
        sessions = build_session_list(config, from_machine=from_machine, show_all=show_all)

        if not sessions:
            print("セッションが見つかりませんでした。")
            sys.exit(0)

        # ロック情報を取得（キャッシュ）
        lock_info_cache: dict[str, Optional[dict]] = {}
        for s in sessions:
            try:
                lock_info_cache[s["session_id"]] = check_lock(config.sync_repo_dir, s["session_id"])
            except Exception:
                lock_info_cache[s["session_id"]] = None

        # 3 & 4. --latest の場合は最新を自動選択、それ以外はユーザーに選択させる
        if latest:
            selected = sessions[0]
            selected_session_id = selected["session_id"]
            print(f"最新セッションを選択: {selected_session_id} ({selected['machine_id']})")

            # ロック中かチェック
            lock = lock_info_cache.get(selected_session_id)
            if lock:
                if not _warn_locked_session(lock, config.machine_id):
                    print("キャンセルしました。")
                    sys.exit(0)
                # 異なるマシンのロックは強制的に自マシンに引き継ぐ
                if lock.get("machine_id") != config.machine_id:
                    _force_takeover_lock(config.sync_repo_dir, selected_session_id, config.machine_id)
                    print("[OK] ロックを引き継ぎました")
        else:
            # 一覧表示してユーザーに選択させる
            print_session_list(sessions, config, lock_info_cache)

            while True:
                try:
                    raw = input(f"番号を選択してください [1-{len(sessions)}]: ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\nキャンセルしました。")
                    sys.exit(0)

                if not raw:
                    continue
                try:
                    idx = int(raw)
                except ValueError:
                    print(f"無効な入力です。1〜{len(sessions)} の番号を入力してください。")
                    continue
                if idx < 1 or idx > len(sessions):
                    print(f"範囲外です。1〜{len(sessions)} の番号を入力してください。")
                    continue
                break

            selected = sessions[idx - 1]
            selected_session_id = selected["session_id"]

            # 5. ロック中のセッションを選んだら警告 + 確認
            lock = lock_info_cache.get(selected_session_id)
            if lock:
                if not _warn_locked_session(lock, config.machine_id):
                    print("キャンセルしました。")
                    sys.exit(0)
                # 異なるマシンのロックは強制的に自マシンに引き継ぐ
                if lock.get("machine_id") != config.machine_id:
                    _force_takeover_lock(config.sync_repo_dir, selected_session_id, config.machine_id)
                    print("[OK] ロックを引き継ぎました")

    # 6. ロック取得
    ok = acquire_lock(config.sync_repo_dir, selected_session_id, config.machine_id)
    if not ok:
        print(f"ロックの取得に失敗しました: {selected_session_id}")
        print("他マシンが作業中の可能性があります。")
        sys.exit(1)

    # 6b. ロックを即座にgit push（他マシンに通知）
    try:
        from claude_session_sync.git_ops import git_add, git_commit, git_push
        lock_rel = os.path.join("locks", f"{selected_session_id}.lock.json")
        git_add(config.sync_repo_dir, [lock_rel])
        git_commit(config.sync_repo_dir, f"lock: {selected_session_id} by {config.machine_id}")
        git_push(config.sync_repo_dir)
    except Exception as e:
        print(f"警告: ロックのpushに失敗しました（続行します）: {e}")

    # 7. daemon をバックグラウンドで起動（push のみ）
    daemon_pid = _start_push_daemon(config)
    if daemon_pid:
        print(f"バックグラウンド同期を開始しました (PID: {daemon_pid})")

    # 8. claude --resume <session-id> を実行（ブロッキング）
    # セッションの cwd に移動してから実行（Claude Code は cwd でプロジェクトを特定する）
    session_cwd = None
    try:
        session_cwd = selected.get("project_path")
    except NameError:
        pass
    if not session_cwd:
        # セッションファイルから cwd を抽出
        session_cwd = _extract_project_path(
            _find_session_file(config, selected_session_id)
        )
    if session_cwd and os.path.isdir(session_cwd):
        print(f"作業ディレクトリ: {session_cwd}")
    else:
        session_cwd = None  # ディレクトリが存在しない場合はcwd変更しない

    print(f"\nセッション {selected_session_id} を再開します...")
    try:
        result = subprocess.run(
            ["claude", "--resume", selected_session_id],
            cwd=session_cwd,
        )
    except FileNotFoundError:
        print("エラー: claude コマンドが見つかりません。Claude Code がインストールされているか確認してください。")
        release_lock(config.sync_repo_dir, selected_session_id, config.machine_id)
        _stop_push_daemon()
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nClaude Code を終了します...")
    finally:
        # Claude Code（TUI）終了後にターミナル状態をリセット
        _reset_terminal()

    # 9. Claude Code 終了後
    # 終了処理中は Ctrl+C を無視（push を中断させない）
    import signal as _signal
    _orig_sigint = _signal.signal(_signal.SIGINT, _signal.SIG_IGN)

    print("\nセッション終了。後処理を実行中...")

    try:
        # 9a. daemon を先に停止（git push の競合を防ぐ）
        _stop_push_daemon()
        # daemon プロセスが停止するまで少し待つ
        time.sleep(2)

        # 9b. ロック解放（ファイル削除のみ、push はまだ）
        released = release_lock(config.sync_repo_dir, selected_session_id, config.machine_id)
        if released:
            print(f"ロックを解放しました: {selected_session_id}")
        else:
            print(f"警告: ロックの解放に失敗しました: {selected_session_id}", file=sys.stderr)

        # 9c. push（セッション + ロック解放を一括で git commit & push）
        #     push_sessions は git add（特定ファイル）→ git commit → git push するが、
        #     その前にロック削除を git add -A でステージしておけば同じ commit に含まれる
        try:
            # ロック削除をステージ（push_sessions の git commit に含まれる）
            subprocess.run(
                ["git", "add", "-A", "."],
                cwd=config.sync_repo_dir,
                capture_output=True,
            )
            push_sessions(config, dry_run=False, skip_pull=True)
            print("[OK] セッションとロック解放をリモートに通知しました")
        except Exception as e:
            print(f"警告: push に失敗しました: {e}", file=sys.stderr)

        print("完了。")
    finally:
        # SIGINT ハンドラを復元
        _signal.signal(_signal.SIGINT, _orig_sigint)
