"""
`claude-session-sync setup-hooks` コマンド実装

注意: resume コマンドが session の pull / lock / push / daemon 管理を
一括して行うようになったため、SessionStart hook は不要になりました。

このコマンドは互換性のために残していますが、
`claude-session-sync resume` の使用を推奨します。
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path


SETTINGS_PATH = Path.home() / ".claude" / "settings.json"

HOOK_MARKER = "claude-session-sync"


def _detect_command() -> str:
    found = shutil.which("claude-session-sync")
    if found:
        return found
    return "python3 -m claude_session_sync"


def _load_settings() -> dict:
    if SETTINGS_PATH.exists():
        try:
            with SETTINGS_PATH.open("r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            print(f"警告: settings.json の読み込みに失敗しました: {e}")
            return {}
    return {}


def _save_settings(data: dict) -> None:
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    with SETTINGS_PATH.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def _has_our_hook(hooks_dict: dict, event: str) -> bool:
    """指定イベントに claude-session-sync のフックが既にあるか"""
    entries = hooks_dict.get(event, [])
    for entry in entries:
        for hook in entry.get("hooks", []):
            if HOOK_MARKER in hook.get("command", ""):
                return True
    return False


def run(args: argparse.Namespace) -> None:
    print("============================================================")
    print("  claude-session-sync setup-hooks")
    print("============================================================")
    print()
    print("SessionStart hook によるセッション管理は非推奨になりました。")
    print()
    print("代わりに resume コマンドの使用を推奨します:")
    print()
    print("  claude-session-sync resume")
    print()
    print("resume コマンドは以下を自動的に処理します:")
    print("  - 最新セッションの pull")
    print("  - 全マシンのセッション一覧表示（ロック状態付き）")
    print("  - セッションロックの取得・解放")
    print("  - バックグラウンドでの push-only daemon 起動")
    print("  - claude --resume <session-id> の実行")
    print("  - 終了後の push・ロック解放・daemon 停止")
    print()
    print("============================================================")
