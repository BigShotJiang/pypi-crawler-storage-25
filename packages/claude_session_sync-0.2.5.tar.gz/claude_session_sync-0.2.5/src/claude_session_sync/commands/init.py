"""
`claude-session-sync init` コマンド実装
"""
from __future__ import annotations

import argparse
import os
import socket
import subprocess
import sys


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.github_ops import get_authenticated_user, repo_exists, create_repo
    from claude_session_sync.git_ops import git_clone, git_init, git_add, git_commit, git_push
    from claude_session_sync.shared_placeholders import (
        load_shared_placeholders,
        save_shared_placeholders,
        get_machine_placeholders,
        SHARED_PLACEHOLDERS_FILENAME,
    )

    # 1. 既にセットアップ済みか確認
    if Config.exists():
        print("既にセットアップ済みです。設定を変更する場合は設定ファイルを直接編集してください。")
        print(f"  設定ファイル: ~/.claude-session-sync/config.json")
        return

    # 2. machine_id を決定
    machine_id: str = getattr(args, "machine_id", None) or ""
    if not machine_id:
        default_hostname = socket.gethostname()
        machine_id = input(f"マシンID [{default_hostname}]: ").strip() or default_hostname
    print(f"マシンID: {machine_id}")

    # 3. バックエンド選択
    # --repo / --owner が指定された場合は GitHub 強制
    # --url が指定された場合はカスタム強制
    cli_owner: str = getattr(args, "owner", None) or ""
    cli_repo: str = getattr(args, "repo", None) or ""
    cli_url: str = getattr(args, "url", None) or ""

    # Fix 5: --url と --owner/--repo の同時指定を禁止
    if (cli_owner or cli_repo) and cli_url:
        print("エラー: --url と --owner/--repo は同時に指定できません。")
        sys.exit(1)

    if cli_owner or cli_repo:
        git_backend = "github"
    elif cli_url:
        git_backend = "custom"
    else:
        print("")
        print("Gitバックエンドを選んでください:")
        print("  1) GitHub (gh CLI で自動セットアップ)")
        print("  2) 既存の Git リポジトリURL を指定")
        while True:
            backend_choice = input("選択 [1]: ").strip() or "1"
            if backend_choice in ("1", "2"):
                break
            print("1 または 2 を入力してください。")
        git_backend = "custom" if backend_choice == "2" else "github"

    # 4. リポジトリのセットアップ
    sync_repo_dir = os.path.expanduser("~/.claude-session-sync/repo")

    owner: str = ""
    repo_name: str = ""
    remote_url: str = ""

    if git_backend == "github":
        # 4a. GitHub フロー
        print("GitHub 認証を確認しています...")
        try:
            gh_user = get_authenticated_user()
        except Exception as e:
            print(f"GitHub 認証に失敗しました: {e}")
            print("  `gh auth login` を実行してから再試行してください。")
            sys.exit(1)
        print(f"GitHub ユーザー: {gh_user}")

        owner = cli_owner or gh_user
        repo_name = cli_repo or "claude-sessions"

        if repo_exists(owner, repo_name):
            print(f"既存リポジトリを使用します: {owner}/{repo_name}")
            remote_url = f"https://github.com/{owner}/{repo_name}.git"
            if not os.path.isdir(os.path.join(sync_repo_dir, ".git")):
                print(f"リポジトリをクローンしています: {remote_url}")
                os.makedirs(os.path.dirname(sync_repo_dir), exist_ok=True)
                try:
                    git_clone(remote_url, sync_repo_dir)
                except Exception as e:
                    print(f"リポジトリのクローンに失敗しました: {e}")
                    sys.exit(1)
        else:
            print(f"リポジトリを作成します: {owner}/{repo_name}")
            remote_url = create_repo(repo_name, private=True)
            print(f"リポジトリを作成しました: {remote_url}")
            if not os.path.isdir(os.path.join(sync_repo_dir, ".git")):
                os.makedirs(sync_repo_dir, exist_ok=True)
                git_init(sync_repo_dir)
                readme_path = os.path.join(sync_repo_dir, "README.md")
                with open(readme_path, "w", encoding="utf-8") as f:
                    f.write("# claude-session-sync\n\nClaude Code セッション同期リポジトリ\n")
                try:
                    subprocess.run(
                        ["git", "remote", "add", "origin", remote_url],
                        cwd=sync_repo_dir,
                        check=True,
                        capture_output=True,
                    )
                except subprocess.CalledProcessError as e:
                    print(f"Gitリモートの追加に失敗しました: {e.stderr or e}")
                    sys.exit(1)
                git_add(sync_repo_dir, ["README.md"])
                git_commit(sync_repo_dir, "initial commit")
                git_push(sync_repo_dir)

    else:
        # 4b. カスタム Git URL フロー
        if cli_url:
            remote_url = cli_url
        else:
            remote_url = input("リポジトリのクローンURLを入力: ").strip()
            if not remote_url:
                print("URLが入力されませんでした。セットアップを中断します。")
                sys.exit(1)

        # Fix 4: 基本的なURLスキームの検証
        if not (remote_url.startswith("https://") or remote_url.startswith("http://")
                or remote_url.startswith("git@") or remote_url.startswith("ssh://")
                or remote_url.startswith("git://")):
            print("警告: 認識できないURLスキームです。https://, git@, ssh:// 等を使用してください。")
            answer = input("このURLで続行しますか？ [y/N]: ").strip().lower()
            if answer not in ("y", "yes"):
                sys.exit(1)

        print("")
        print("リポジトリは既に存在しますか？")
        print("  1) はい (クローンする)")
        print("  2) いいえ (空リポジトリを初期化してプッシュする)")
        exists_choice = input("選択 [1]: ").strip() or "1"

        if exists_choice == "1":
            # 既存リポジトリをクローン
            # Fix 1: .git が既にあればスキップ
            if not os.path.isdir(os.path.join(sync_repo_dir, ".git")):
                print(f"リポジトリをクローンしています: {remote_url}")
                os.makedirs(os.path.dirname(sync_repo_dir), exist_ok=True)
                try:
                    git_clone(remote_url, sync_repo_dir)
                except Exception as e:
                    print(f"リポジトリのクローンに失敗しました: {e}")
                    sys.exit(1)
        else:
            # 空リポジトリを初期化してプッシュ
            if not os.path.isdir(os.path.join(sync_repo_dir, ".git")):
                os.makedirs(sync_repo_dir, exist_ok=True)
                git_init(sync_repo_dir)
                readme_path = os.path.join(sync_repo_dir, "README.md")
                with open(readme_path, "w", encoding="utf-8") as f:
                    f.write("# claude-session-sync\n\nClaude Code セッション同期リポジトリ\n")
                try:
                    subprocess.run(
                        ["git", "remote", "add", "origin", remote_url],
                        cwd=sync_repo_dir,
                        check=True,
                        capture_output=True,
                    )
                except subprocess.CalledProcessError as e:
                    print(f"Gitリモートの追加に失敗しました: {e.stderr or e}")
                    sys.exit(1)
                git_add(sync_repo_dir, ["README.md"])
                git_commit(sync_repo_dir, "initial commit")
                git_push(sync_repo_dir)
                print(f"リポジトリを初期化してプッシュしました: {remote_url}")

        owner = ""
        repo_name = ""

    # 5. 共有プレースホルダの処理
    print("")
    print("共有プレースホルダを設定しています...")

    # --add-placeholder 引数を解析 (例: PROJECTS=/home/tubome/projects)
    extra_placeholders: dict[str, str] = {}
    add_placeholder_args = getattr(args, "add_placeholder", None) or []
    for item in add_placeholder_args:
        if "=" in item:
            name, _, path = item.partition("=")
            name = name.strip()
            path = path.strip()
            if name and path:
                extra_placeholders[name] = path

    shared_ph_path = os.path.join(sync_repo_dir, SHARED_PLACEHOLDERS_FILENAME)
    files_to_commit: list[str] = []
    custom_placeholders: dict[str, str] = {}  # name -> local path (no {{ }})

    if os.path.exists(shared_ph_path):
        # 既存の shared_placeholders.json がある
        shared_data = load_shared_placeholders(sync_repo_dir)
        ph_dict = shared_data.get("placeholders", {})

        if ph_dict:
            print("既存の共有プレースホルダが見つかりました:")
            for name, machines in ph_dict.items():
                print(f"  {name}:")
                for mid, p in machines.items():
                    marker = " (このマシン)" if mid == machine_id else ""
                    print(f"    {mid}: {p}{marker}")

            # このマシンのパスが設定済みか確認
            my_paths = get_machine_placeholders(sync_repo_dir, machine_id)

            if my_paths:
                print(f"\nこのマシン ({machine_id}) のパスが既に設定されています:")
                for name, path in my_paths.items():
                    print(f"  {name}: {path}")
                answer = input("パスは合っていますか？ [Y/n]: ").strip().lower()
                if answer in ("n", "no"):
                    # 再入力: インメモリの shared_data を直接変更し、ループ後に一度だけ保存する
                    placeholders = shared_data.setdefault("placeholders", {})
                    for name in ph_dict.keys():
                        current = my_paths.get(name, "")
                        new_path = input(f"  {name} のパス [{current}]: ").strip() or current
                        placeholders.setdefault(name, {})[machine_id] = new_path
                        custom_placeholders[name] = new_path
                else:
                    custom_placeholders.update(my_paths)
            else:
                print(f"\nこのマシン ({machine_id}) のパスを入力してください:")
                placeholders = shared_data.setdefault("placeholders", {})
                for name in ph_dict.keys():
                    path = input(f"  {name}: ").strip()
                    if path:
                        placeholders.setdefault(name, {})[machine_id] = path
                        custom_placeholders[name] = path

            # コマンドライン引数で追加されたプレースホルダも処理
            placeholders = shared_data.setdefault("placeholders", {})
            for name, path in extra_placeholders.items():
                if name not in ph_dict:
                    placeholders.setdefault(name, {})[machine_id] = path
                    custom_placeholders[name] = path

            save_shared_placeholders(sync_repo_dir, shared_data)
            files_to_commit.append(SHARED_PLACEHOLDERS_FILENAME)
        else:
            # ファイルはあるが placeholders が空
            shared_data, files_to_commit, custom_placeholders = _setup_first_machine(
                sync_repo_dir, machine_id, extra_placeholders
            )
    else:
        # 初めてのマシン: shared_placeholders.json を新規作成
        shared_data, files_to_commit, custom_placeholders = _setup_first_machine(
            sync_repo_dir, machine_id, extra_placeholders
        )

    # 6. shared_placeholders.json を commit & push
    if files_to_commit and os.path.isdir(os.path.join(sync_repo_dir, ".git")):
        try:
            git_add(sync_repo_dir, files_to_commit)
            git_commit(sync_repo_dir, f"config: add shared placeholders for {machine_id}")
            git_push(sync_repo_dir)
            print("共有プレースホルダをリポジトリにプッシュしました。")
        except Exception as e:
            print(f"共有プレースホルダのプッシュに失敗しました (後で再試行できます): {e}")

    # プレースホルダ構築: custom_placeholders のみ使用（{{HOME}} は自動追加しない）
    all_placeholders: dict[str, str] = {}
    for name, path in custom_placeholders.items():
        key = f"{{{{{name}}}}}" if not (name.startswith("{{") and name.endswith("}}")) else name
        all_placeholders[key] = path

    # sync_directories: custom_placeholders のパスを自動追加
    sync_directories: list[str] = list(custom_placeholders.values())

    # 7. Config を作成して保存
    config = Config(
        machine_id=machine_id,
        github_owner=owner,
        github_repo=repo_name,
        github_remote_url=remote_url,
        sync_repo_dir=sync_repo_dir,
        claude_projects_dir=os.path.expanduser("~/.claude/projects"),
        claude_history_file=os.path.expanduser("~/.claude/history.jsonl"),
        placeholders=all_placeholders,
        custom_placeholders={name: path for name, path in custom_placeholders.items()},
        sync_directories=sync_directories,
        last_push_at=None,
        last_pull_at=None,
        git_backend=git_backend,
    )
    config.save()

    # 8. 完了メッセージ
    print("")
    print("セットアップが完了しました。")
    print(f"  マシンID        : {machine_id}")
    if git_backend == "github":
        print(f"  GitHubリポジトリ: {owner}/{repo_name}")
    else:
        print(f"  リモートURL     : {remote_url}")
    print(f"  同期ディレクトリ: {sync_repo_dir}")
    if all_placeholders:
        print("  プレースホルダ  :")
        for k, v in all_placeholders.items():
            print(f"    {k} = {v}")
    if sync_directories:
        print("  同期対象ディレクトリ:")
        for d in sync_directories:
            print(f"    {d}")
    else:
        print("  警告: sync_directories が未設定のため全セッションが共有されます。")
    print("")
    print("次のコマンドでセッションを同期できます:")
    print("  claude-session-sync push   # ローカルセッションをプッシュ")
    print("  claude-session-sync pull   # 他マシンのセッションをプル")


def _setup_first_machine(
    sync_repo_dir: str,
    machine_id: str,
    extra_placeholders: dict[str, str],
) -> tuple[dict, list[str], dict[str, str]]:
    """Interactive setup for the first machine (no existing shared_placeholders.json).

    Returns (shared_data, files_to_commit, custom_placeholders).
    custom_placeholders maps plain name -> local path (no {{ }}).
    """
    from claude_session_sync.shared_placeholders import (
        save_shared_placeholders,
        SHARED_PLACEHOLDERS_FILENAME,
    )
    from pathlib import Path

    # Build up the shared_data dict in memory from scratch; mutate
    # directly and call save_shared_placeholders once at the end.
    shared_data: dict = {"placeholders": {}}
    custom_placeholders: dict[str, str] = {}

    def _add_to_shared(data: dict, ph_name: str, mid: str, ph_path: str) -> dict:
        """Add an entry directly into the in-memory shared_data dict."""
        ph = data.setdefault("placeholders", {})
        if ph_name not in ph:
            ph[ph_name] = {}
        ph[ph_name][mid] = ph_path
        return data

    # HOME は自動検出
    home = str(Path.home())
    _add_to_shared(shared_data, "HOME", machine_id, home)

    # コマンドライン引数で追加されたプレースホルダ
    for name, path in extra_placeholders.items():
        _add_to_shared(shared_data, name, machine_id, path)
        custom_placeholders[name] = path

    # プロジェクトディレクトリの追加を促す
    if not extra_placeholders:
        answer = input("プロジェクトディレクトリを追加しますか？ [Y/n]: ").strip().lower()
        if answer not in ("n", "no"):
            path = input("  プロジェクトディレクトリのパス: ").strip()
            if path:
                name = input("  プレースホルダ名 [PROJECTS]: ").strip() or "PROJECTS"
                _add_to_shared(shared_data, name, machine_id, path)
                custom_placeholders[name] = path

                # 他マシンのパスも設定するか確認
                _ask_other_machines_in_memory(shared_data, name)

    # 追加のカスタムプレースホルダを対話的に追加
    while True:
        answer = input("他のプレースホルダを追加しますか？ [y/N]: ").strip().lower()
        if answer not in ("y", "yes"):
            break
        path = input("  パス: ").strip()
        if not path:
            break
        name = input("  プレースホルダ名: ").strip()
        if not name:
            break
        _add_to_shared(shared_data, name, machine_id, path)
        custom_placeholders[name] = path
        _ask_other_machines_in_memory(shared_data, name)

    save_shared_placeholders(sync_repo_dir, shared_data)
    files_to_commit = [SHARED_PLACEHOLDERS_FILENAME]

    return shared_data, files_to_commit, custom_placeholders


def _ask_other_machines_in_memory(shared_data: dict, placeholder_name: str) -> None:
    """Ask user to set paths for other machines for the given placeholder.

    Modifies shared_data in place.
    """
    while True:
        answer = input(f"  他のマシンの {placeholder_name} のパスも設定しますか？ [y/N]: ").strip().lower()
        if answer not in ("y", "yes"):
            break
        mid = input("    マシンID: ").strip()
        if not mid:
            break
        path = input(f"    {placeholder_name} のパス: ").strip()
        if not path:
            break
        ph = shared_data.setdefault("placeholders", {})
        if placeholder_name not in ph:
            ph[placeholder_name] = {}
        ph[placeholder_name][mid] = path
