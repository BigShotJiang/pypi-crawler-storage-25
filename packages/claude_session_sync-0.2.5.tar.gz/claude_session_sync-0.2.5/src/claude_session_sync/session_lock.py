"""
セッションロック管理モジュール

ロックファイル: {sync_repo_dir}/locks/{session_id}.lock.json
git 操作なし。ファイルの読み書きのみ。
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


def _locks_dir(sync_repo_dir: str) -> Path:
    return Path(sync_repo_dir) / "locks"


def _lock_file(sync_repo_dir: str, session_id: str) -> Path:
    return _locks_dir(sync_repo_dir) / f"{session_id}.lock.json"


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _parse_dt(s: str) -> datetime:
    """ISO 8601 文字列を aware datetime に変換する。"""
    # Python 3.11+ は fromisoformat で Z を扱えるが、3.10 以下対応のため手動処理
    s = s.replace("Z", "+00:00")
    return datetime.fromisoformat(s)


def _fmt_dt(dt: datetime) -> str:
    """UTC aware datetime を ISO 8601 文字列（Zサフィックス）に変換する。"""
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _read_lock(path: Path) -> Optional[dict]:
    """ロックファイルを読み込む。失敗したら None を返す。"""
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _write_lock(path: Path, data: dict) -> None:
    """ロックファイルを書き込む。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def _is_expired(lock_data: dict) -> bool:
    """ロックが期限切れかどうかを判定する。"""
    try:
        expires_at = _parse_dt(lock_data["expires_at"])
        return _now_utc() >= expires_at
    except (KeyError, ValueError):
        return True  # パースできない場合は期限切れとみなす


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def acquire_lock(
    sync_repo_dir: str,
    session_id: str,
    machine_id: str,
    ttl_minutes: int = 10,
    verify_callback=None,
) -> bool:
    """
    ロックを取得する。

    - 他マシンのロックがあり期限内 → False
    - 他マシンのロックが期限切れ → 上書きして True
    - 自マシンのロック → TTL 更新して True
    - ロックなし → 作成して True

    Parameters
    ----------
    verify_callback : callable or None
        ロックファイル書き込み後に呼び出されるコールバック。
        指定された場合、書き込み後に verify_callback() を呼び出す。
        False を返した場合はロックを削除して False を返す。
        指定しない場合は従来通りの動作。
    """
    path = _lock_file(sync_repo_dir, session_id)
    now = _now_utc()

    if path.exists():
        existing = _read_lock(path)
        if existing is not None:
            existing_machine = existing.get("machine_id", "")
            if existing_machine != machine_id:
                # 他マシンのロック
                if not _is_expired(existing):
                    return False
                # 期限切れなので奪取する

    # 新規作成または上書き
    from datetime import timedelta
    expires_at = now + timedelta(minutes=ttl_minutes)
    lock_data = {
        "session_id": session_id,
        "machine_id": machine_id,
        "locked_at": _fmt_dt(now),
        "expires_at": _fmt_dt(expires_at),
    }
    _write_lock(path, lock_data)

    # verify_callback が指定されていれば呼び出す
    if verify_callback is not None:
        if not verify_callback():
            # 検証失敗: 他マシンが先にロックを取ったと判断してロックを削除
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
            return False

    return True


def release_lock(
    sync_repo_dir: str,
    session_id: str,
    machine_id: str,
) -> bool:
    """
    ロックを解放する。

    - 自マシンのロックファイルを削除。
    - 他マシンのロック → False を返す（削除しない）。
    - ロックなし → True を返す（既に解放済み）。
    """
    path = _lock_file(sync_repo_dir, session_id)

    if not path.exists():
        return True  # 既に解放済み

    existing = _read_lock(path)
    if existing is None:
        # 読み込めない壊れたファイルは削除
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        return True

    if existing.get("machine_id") != machine_id:
        return False  # 他マシンのロック

    try:
        path.unlink(missing_ok=True)
    except OSError:
        return False
    return True


def check_lock(
    sync_repo_dir: str,
    session_id: str,
) -> Optional[dict]:
    """
    ロック情報を返す。

    - ロックなし、または期限切れ → None
    - 期限内のロック → lock dict を返す
    """
    path = _lock_file(sync_repo_dir, session_id)

    if not path.exists():
        return None

    data = _read_lock(path)
    if data is None:
        return None

    if _is_expired(data):
        return None

    return data


def release_all_locks(
    sync_repo_dir: str,
    machine_id: str,
) -> list[str]:
    """
    このマシンの全ロックを解放する。

    Returns
    -------
    list[str]
        解放した session_id のリスト。
    """
    locks_dir = _locks_dir(sync_repo_dir)
    released: list[str] = []

    if not locks_dir.exists():
        return released

    for lock_path in locks_dir.glob("*.lock.json"):
        data = _read_lock(lock_path)
        if data is None:
            continue
        if data.get("machine_id") != machine_id:
            continue
        session_id = data.get("session_id", lock_path.stem.replace(".lock", ""))
        try:
            lock_path.unlink(missing_ok=True)
            released.append(session_id)
        except OSError:
            pass

    return released


def cleanup_expired_locks(sync_repo_dir: str) -> list[str]:
    """
    期限切れのロックを全て削除する。

    Returns
    -------
    list[str]
        削除した session_id のリスト。
    """
    locks_dir = _locks_dir(sync_repo_dir)
    cleaned: list[str] = []

    if not locks_dir.exists():
        return cleaned

    for lock_path in locks_dir.glob("*.lock.json"):
        data = _read_lock(lock_path)
        if data is None:
            # 読み込めない壊れたファイルは削除
            try:
                lock_path.unlink(missing_ok=True)
                cleaned.append(lock_path.stem.replace(".lock", ""))
            except OSError:
                pass
            continue

        if _is_expired(data):
            session_id = data.get("session_id", lock_path.stem.replace(".lock", ""))
            try:
                lock_path.unlink(missing_ok=True)
                cleaned.append(session_id)
            except OSError:
                pass

    return cleaned


def renew_locks(
    sync_repo_dir: str,
    machine_id: str,
    ttl_minutes: int = 10,
) -> int:
    """
    このマシンの全ロックの TTL を延長する。

    Returns
    -------
    int
        延長したロック数。
    """
    locks_dir = _locks_dir(sync_repo_dir)
    renewed = 0

    if not locks_dir.exists():
        return renewed

    from datetime import timedelta
    now = _now_utc()
    expires_at = now + timedelta(minutes=ttl_minutes)

    for lock_path in locks_dir.glob("*.lock.json"):
        data = _read_lock(lock_path)
        if data is None:
            continue
        if data.get("machine_id") != machine_id:
            continue

        data["expires_at"] = _fmt_dt(expires_at)
        _write_lock(lock_path, data)
        renewed += 1

    return renewed


def get_active_session_ids() -> list[str]:
    """
    ~/.claude/sessions/*.json を読んでアクティブなセッション ID を取得する。

    Returns
    -------
    list[str]
        アクティブなセッション ID のリスト。
    """
    sessions_dir = Path.home() / ".claude" / "sessions"
    if not sessions_dir.exists():
        return []

    session_ids: list[str] = []
    for f in sessions_dir.glob("*.json"):
        session_id = f.stem
        if session_id:
            session_ids.append(session_id)

    return session_ids
