"""
メモリファイルと CLAUDE.md の同期モジュール。

push_shared_config: ローカルのメモリファイルと CLAUDE.md を sync_repo_dir に書き出す。
pull_shared_config: sync_repo_dir からメモリファイルと CLAUDE.md をローカルに復元する。

共有メモリ方式: 全マシンが同じ1セットのメモリファイルを共有する。
マシンごとの別コピー・manifest.json・mtime 比較・per-machine ディレクトリは使わない。
"""
from __future__ import annotations

import difflib
import json
import os
import re
import shutil
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from claude_session_sync.config import Config

from claude_session_sync.path_mapper import PathMapper


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _in_sync_dirs(project_path: str, sync_dirs: list) -> bool:
    """project_path が sync_dirs のいずれかのサブパスかどうかを返す。"""
    if not sync_dirs:
        return True
    # Windows バックスラッシュを正規化し、連続スラッシュを1つに統一
    project_path = re.sub(r"/+", "/", project_path.replace("\\", "/"))
    for sd in sync_dirs:
        sd = re.sub(r"/+", "/", sd.replace("\\", "/")).rstrip("/")
        if project_path == sd or project_path.startswith(sd + "/"):
            return True
    return False


def _show_diff(local_file: str, remote_file: str, label: str) -> None:
    """既存ファイルと新しいファイルの差分をログ出力する（.bak は作らない）。"""
    try:
        with open(local_file, "r", encoding="utf-8") as f:
            local_lines = f.readlines()
        with open(remote_file, "r", encoding="utf-8") as f:
            remote_lines = f.readlines()
    except (OSError, UnicodeDecodeError):
        return

    if local_lines == remote_lines:
        return

    diff = list(difflib.unified_diff(
        local_lines,
        remote_lines,
        fromfile=f"ローカル ({label})",
        tofile=f"shared ({label})",
        lineterm="",
    ))

    if diff:
        print(f"\n{'='*60}")
        print(f"変更を検出: {label}")
        print(f"{'='*60}")
        for line in diff:
            line = line.rstrip("\n")
            if line.startswith("+++"):
                print(f"\033[1;32m{line}\033[0m")
            elif line.startswith("---"):
                print(f"\033[1;31m{line}\033[0m")
            elif line.startswith("+"):
                print(f"\033[32m{line}\033[0m")
            elif line.startswith("-"):
                print(f"\033[31m{line}\033[0m")
            elif line.startswith("@@"):
                print(f"\033[36m{line}\033[0m")
            else:
                print(line)
        print(f"{'='*60}\n")


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------

def push_shared_config(config: "Config", mapper: PathMapper) -> list[str]:
    """ローカルのメモリファイルと CLAUDE.md を sync_repo_dir に書き出す。

    全マシン共有の1セットとして上書きする。マシンIDディレクトリは使わない。

    Parameters
    ----------
    config : Config
    mapper : PathMapper

    Returns
    -------
    list[str]
        書き出したファイルの相対パスリスト（sync_repo_dir からの相対）。
    """
    files_written: list[str] = []
    shared_config_dir = os.path.join(config.sync_repo_dir, "shared_config")

    # ------------------------------------------------------------------
    # CLAUDE.md
    # ------------------------------------------------------------------
    claude_md_src = str(Path.home() / ".claude" / "CLAUDE.md")
    if os.path.isfile(claude_md_src):
        claude_md_dest = os.path.join(shared_config_dir, "CLAUDE.md")
        os.makedirs(os.path.dirname(claude_md_dest), exist_ok=True)
        try:
            shutil.copy2(claude_md_src, claude_md_dest)
            files_written.append(
                os.path.relpath(claude_md_dest, config.sync_repo_dir).replace("\\", "/")
            )
        except OSError as e:
            print(f"CLAUDE.md のコピーに失敗しました: {e}")
    else:
        print(f"CLAUDE.md が見つかりません: {claude_md_src}")

    # ------------------------------------------------------------------
    # メモリファイル
    # ------------------------------------------------------------------
    sync_dirs = getattr(config, "sync_directories", []) or []
    projects_base = Path(config.claude_projects_dir)
    memory_dest_base = os.path.join(shared_config_dir, "memory")
    paths: dict[str, str] = {}  # {placeholder_project_dir: placeholder_path}

    if not projects_base.is_dir():
        print(f"claude_projects_dir が見つかりません: {config.claude_projects_dir}")
    else:
        for project_dir_path in projects_base.iterdir():
            if not project_dir_path.is_dir():
                continue

            memory_dir = project_dir_path / "memory"
            if not memory_dir.is_dir():
                continue

            project_dir_name = project_dir_path.name

            # sync_directories フィルタリング
            # HD()エンコーディングは不可逆（C:\projects → C--projects だが逆変換で C//projects になる）。
            # そのため sync_dirs 側を HD() エンコードして project_dir_name と直接比較する。
            if sync_dirs:
                encoded_sync_dirs = [PathMapper.path_to_project_dir(sd) for sd in sync_dirs]
                match = any(
                    project_dir_name == esd or project_dir_name.startswith(esd)
                    for esd in encoded_sync_dirs
                )
                if not match:
                    # スキップ表示用に概算パスを作成（正確でなくてもよい）
                    raw_path_for_display = PathMapper.dir_name_to_path(project_dir_name)
                    display_path = mapper.to_local(raw_path_for_display)
                    print(f"  スキップ: {display_path} (sync_directories 対象外)")
                    continue

            # project_path（ローカルパス）を計算する。
            # dir_name_to_path は不可逆なので、プレースホルダー経由で正確なパスを復元する。
            # 具体的には: HD(実パス) prefix → HD(プレースホルダー) prefix に置換して
            # dir_name_to_path → to_local の順で変換する。
            project_path = None
            for ph, real_path in mapper._placeholders.items():
                encoded_real = PathMapper.path_to_project_dir(real_path)
                if project_dir_name == encoded_real or project_dir_name.startswith(encoded_real):
                    suffix = project_dir_name[len(encoded_real):]
                    encoded_ph = PathMapper.path_to_project_dir(ph)
                    reconstructed_dir = encoded_ph + suffix
                    reconstructed_path = PathMapper.dir_name_to_path(reconstructed_dir)
                    project_path = mapper.to_local(reconstructed_path)
                    break
            if project_path is None:
                # プレースホルダーにマッチしない場合は従来の変換にフォールバック
                raw_path = PathMapper.dir_name_to_path(project_dir_name)
                project_path = mapper.to_local(raw_path)

            # プレースホルダ化したディレクトリ名を計算
            placeholder_path = mapper.to_placeholder(project_path)
            placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

            # paths マッピングに記録
            paths[placeholder_project_dir] = placeholder_path

            # 既存ディレクトリを丸ごと削除してから再作成
            dest_project_dir = os.path.join(memory_dest_base, placeholder_project_dir)
            if os.path.isdir(dest_project_dir):
                try:
                    shutil.rmtree(dest_project_dir)
                except OSError as e:
                    print(f"既存ディレクトリの削除に失敗しました ({dest_project_dir}): {e}")
                    continue

            # memory/ を再帰的にコピー
            try:
                shutil.copytree(str(memory_dir), dest_project_dir)
                # コピーしたファイルの相対パスを収集
                for root, _dirs, filenames in os.walk(dest_project_dir):
                    for filename in filenames:
                        full_path = os.path.join(root, filename)
                        files_written.append(
                            os.path.relpath(full_path, config.sync_repo_dir).replace("\\", "/")
                        )
            except OSError as e:
                print(f"メモリディレクトリのコピーに失敗しました ({memory_dir}): {e}")

    # _paths.json 書き出し
    paths_json_path = os.path.join(memory_dest_base, "_paths.json")
    os.makedirs(os.path.dirname(paths_json_path), exist_ok=True)
    try:
        with open(paths_json_path, "w", encoding="utf-8") as f:
            json.dump(paths, f, ensure_ascii=False, indent=2)
            f.write("\n")
        files_written.append(
            os.path.relpath(paths_json_path, config.sync_repo_dir).replace("\\", "/")
        )
    except OSError as e:
        print(f"_paths.json の書き出しに失敗しました: {e}")

    return files_written


# ---------------------------------------------------------------------------
# pull
# ---------------------------------------------------------------------------

def pull_shared_config(config: "Config", mapper: PathMapper) -> int:
    """sync_repo_dir からメモリファイルと CLAUDE.md をローカルに復元する。

    共有の1セットをそのままローカルに展開する。mtime 比較・.bak 作成なし。

    Parameters
    ----------
    config : Config
    mapper : PathMapper

    Returns
    -------
    int
        コピーしたファイル数。
    """
    copied = 0
    shared_config_dir = os.path.join(config.sync_repo_dir, "shared_config")

    # ------------------------------------------------------------------
    # CLAUDE.md
    # ------------------------------------------------------------------
    claude_md_src = os.path.join(shared_config_dir, "CLAUDE.md")
    if os.path.isfile(claude_md_src):
        claude_md_dest = str(Path.home() / ".claude" / "CLAUDE.md")
        os.makedirs(os.path.dirname(claude_md_dest), exist_ok=True)
        try:
            if os.path.isfile(claude_md_dest):
                _show_diff(claude_md_dest, claude_md_src, "CLAUDE.md")
            shutil.copy2(claude_md_src, claude_md_dest)
            copied += 1
        except OSError as e:
            print(f"CLAUDE.md の復元に失敗しました: {e}")

    # ------------------------------------------------------------------
    # メモリファイル
    # ------------------------------------------------------------------
    memory_root = os.path.join(shared_config_dir, "memory")
    if not os.path.isdir(memory_root):
        return copied

    # _paths.json を読み込む
    paths_json_path = os.path.join(memory_root, "_paths.json")
    if not os.path.isfile(paths_json_path):
        # 旧形式（per-machine）と判断してスキップ（後方互換）
        print("_paths.json が見つかりません。旧形式のためメモリ復元をスキップします。")
        return copied

    try:
        with open(paths_json_path, "r", encoding="utf-8") as f:
            paths: dict[str, str] = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        print(f"_paths.json の読み込みに失敗しました: {e}")
        return copied

    for placeholder_project_dir, placeholder_path in paths.items():
        # placeholder_path → ローカルパスに変換
        local_path = mapper.to_local(placeholder_path)
        local_project_dir = PathMapper.path_to_project_dir(local_path)

        src_dir = os.path.join(memory_root, placeholder_project_dir)
        if not os.path.isdir(src_dir):
            print(f"共有メモリディレクトリが見つかりません: {src_dir}")
            continue

        dest_memory_dir = os.path.join(
            config.claude_projects_dir, local_project_dir, "memory"
        )

        # ローカルの memory/ を丸ごと削除してから再作成
        if os.path.isdir(dest_memory_dir):
            try:
                shutil.rmtree(dest_memory_dir)
            except OSError as e:
                print(f"既存ディレクトリの削除に失敗しました ({dest_memory_dir}): {e}")
                continue

        try:
            shutil.copytree(src_dir, dest_memory_dir)
            # コピーしたファイル数を計上
            for _root, _dirs, filenames in os.walk(dest_memory_dir):
                copied += len(filenames)
            print(f"  メモリ復元: {local_project_dir}/memory/")
        except OSError as e:
            print(f"メモリディレクトリの復元に失敗しました ({src_dir} -> {dest_memory_dir}): {e}")

    return copied
