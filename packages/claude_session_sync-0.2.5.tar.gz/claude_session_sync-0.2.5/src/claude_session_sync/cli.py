import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="claude-session-sync",
        description="Sync Claude Code sessions across Windows, macOS, and Linux",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")

    # init
    init_parser = subparsers.add_parser("init", help="Initialize claude-session-sync")
    init_parser.add_argument("--machine-id", help="Unique identifier for this machine")
    init_parser.add_argument("--repo", help="GitHub repository name")
    init_parser.add_argument("--owner", help="GitHub owner (user or organization)")
    init_parser.add_argument(
        "--add-placeholder",
        metavar="NAME=PATH",
        action="append",
        help="Add a custom placeholder (e.g. PROJECTS=/home/tubome/projects). Can be specified multiple times.",
    )
    init_parser.add_argument(
        "--url",
        metavar="GIT_URL",
        help="Git repository clone URL (skip GitHub and use custom backend)",
    )

    # push
    push_parser = subparsers.add_parser("push", help="Push local sessions to remote")
    push_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be pushed without actually pushing",
    )

    # pull
    pull_parser = subparsers.add_parser("pull", help="Pull sessions from remote")
    pull_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be pulled without actually pulling",
    )
    pull_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite local sessions with remote versions",
    )

    # status
    subparsers.add_parser("status", help="Show sync status")

    # list
    list_parser = subparsers.add_parser("list", help="List sessions")
    list_parser.add_argument(
        "--remote",
        action="store_true",
        help="List remote sessions instead of local",
    )
    list_parser.add_argument(
        "--format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # setup-hooks
    subparsers.add_parser("setup-hooks", help="Add SessionStart/Stop hooks to ~/.claude/settings.json")

    # daemon
    daemon_parser = subparsers.add_parser("daemon", help="Run background sync daemon")
    daemon_parser.add_argument(
        "--interval",
        type=int,
        default=300,
        metavar="SECONDS",
        help="Polling interval in seconds (default: 300 = 5 minutes)",
    )
    daemon_parser.add_argument(
        "--once",
        action="store_true",
        help="Run one sync cycle and exit (for testing)",
    )
    daemon_parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress normal log output; only show errors",
    )
    daemon_parser.add_argument(
        "--stop",
        action="store_true",
        help="Send SIGTERM to the running daemon and exit",
    )
    daemon_parser.add_argument(
        "--push-only",
        dest="push_only",
        action="store_true",
        help="Skip pull; only run push in each sync cycle (used by resume command)",
    )

    # start
    start_parser = subparsers.add_parser(
        "start",
        help="Start a new Claude Code session with background sync",
    )
    start_parser.add_argument(
        "--cwd",
        metavar="DIR",
        help="Working directory for the new session",
    )

    # update
    subparsers.add_parser(
        "update",
        help="Push sessions and release locks left after Claude Code exited",
    )

    # resume
    resume_parser = subparsers.add_parser(
        "resume",
        help="Pull sessions, select one interactively, and resume it with Claude Code",
    )
    resume_parser.add_argument(
        "session_id",
        nargs="?",
        default=None,
        metavar="SESSION_ID",
        help="Session ID to resume directly (skips interactive list)",
    )
    resume_parser.add_argument(
        "--latest",
        action="store_true",
        help="Automatically select the most recently updated session",
    )
    resume_parser.add_argument(
        "--from",
        dest="from_machine",
        metavar="MACHINE_ID",
        help="Only show sessions from this machine",
    )
    resume_parser.add_argument(
        "--all",
        dest="show_all",
        action="store_true",
        help="Show all sessions including those outside sync_directories",
    )

    # lock
    lock_parser = subparsers.add_parser("lock", help="Manage session locks")
    lock_subparsers = lock_parser.add_subparsers(dest="lock_subcommand", metavar="SUBCOMMAND")

    # lock show
    lock_subparsers.add_parser("show", help="Show all current locks")

    # lock release [SESSION_ID]
    lock_release_parser = lock_subparsers.add_parser(
        "release",
        help="Release lock (SESSION_ID optional; omit to release all locks on this machine)",
    )
    lock_release_parser.add_argument(
        "session_id",
        nargs="?",
        default=None,
        metavar="SESSION_ID",
        help="Session ID to release (omit to release all locks on this machine)",
    )

    # lock cleanup
    lock_subparsers.add_parser("cleanup", help="Delete all expired locks")

    # config
    config_parser = subparsers.add_parser("config", help="Manage configuration and placeholders")
    config_subparsers = config_parser.add_subparsers(dest="config_subcommand", metavar="SUBCOMMAND")

    # config add-placeholder NAME=PATH
    config_add_parser = config_subparsers.add_parser(
        "add-placeholder",
        help="Add a custom placeholder mapping",
    )
    config_add_parser.add_argument(
        "name_path",
        metavar="NAME=PATH",
        help="Placeholder name and local path (e.g. PROJECTS=/home/tubome/projects)",
    )

    # config show
    config_subparsers.add_parser("show", help="Show current configuration")

    # config set-path PLACEHOLDER_NAME MACHINE_ID PATH
    config_set_parser = config_subparsers.add_parser(
        "set-path",
        help="Set a path for a specific machine in shared_placeholders.json",
    )
    config_set_parser.add_argument("placeholder_name", metavar="PLACEHOLDER_NAME")
    config_set_parser.add_argument("target_machine", metavar="MACHINE_ID")
    config_set_parser.add_argument("path", metavar="PATH")

    # config set-remote URL
    config_remote_parser = config_subparsers.add_parser(
        "set-remote",
        help="Change the remote Git repository URL",
    )
    config_remote_parser.add_argument(
        "url",
        metavar="URL",
        help="New Git remote URL (e.g. https://gitea.example.com/user/repo.git)",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.command == "init":
        _run_init(args)
    elif args.command == "push":
        _run_push(args)
    elif args.command == "pull":
        _run_pull(args)
    elif args.command == "status":
        _run_status(args)
    elif args.command == "list":
        _run_list(args)
    elif args.command == "config":
        _run_config(args)
    elif args.command == "setup-hooks":
        _run_setup_hooks(args)
    elif args.command == "daemon":
        _run_daemon(args)
    elif args.command == "lock":
        _run_lock(args)
    elif args.command == "start":
        _run_start(args)
    elif args.command == "resume":
        _run_resume(args)
    elif args.command == "update":
        _run_update(args)
    else:
        print(f"Unknown command: {args.command}")
        sys.exit(1)


def _run_init(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import init as init_cmd
        init_cmd.run(args)
    except (ImportError, AttributeError):
        print("init: 未実装です")
        sys.exit(1)


def _run_push(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import push as push_cmd
        push_cmd.run(args)
    except (ImportError, AttributeError):
        print("push: 未実装です")
        sys.exit(1)


def _run_pull(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import pull as pull_cmd
        pull_cmd.run(args)
    except (ImportError, AttributeError):
        print("pull: 未実装です")
        sys.exit(1)


def _run_status(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import status as status_cmd
        status_cmd.run(args)
    except (ImportError, AttributeError):
        print("status: 未実装です")
        sys.exit(1)


def _run_list(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import list as list_cmd
        list_cmd.run(args)
    except (ImportError, AttributeError):
        print("list: 未実装です")
        sys.exit(1)


def _run_config(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import config_cmd
        config_cmd.run(args)
    except (ImportError, AttributeError):
        print("config: 未実装です")
        sys.exit(1)


def _run_setup_hooks(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import setup_hooks as setup_hooks_cmd
        setup_hooks_cmd.run(args)
    except (ImportError, AttributeError):
        print("setup-hooks: 未実装です")
        sys.exit(1)


def _run_daemon(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import daemon as daemon_cmd
        daemon_cmd.run(args)
    except (ImportError, AttributeError):
        print("daemon: 未実装です")
        sys.exit(1)


def _run_lock(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import lock_cmd
        lock_cmd.run(args)
    except (ImportError, AttributeError):
        print("lock: 未実装です")
        sys.exit(1)


def _run_start(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import start as start_cmd
        start_cmd.run(args)
    except (ImportError, AttributeError):
        print("start: 未実装です")
        sys.exit(1)


def _run_resume(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import resume as resume_cmd
        resume_cmd.run(args)
    except (ImportError, AttributeError):
        print("resume: 未実装です")
        sys.exit(1)


def _run_update(args: argparse.Namespace) -> None:
    try:
        from claude_session_sync.commands import update as update_cmd
        update_cmd.run(args)
    except (ImportError, AttributeError):
        print("update: 未実装です")
        sys.exit(1)
