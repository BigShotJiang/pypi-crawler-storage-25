from __future__ import annotations

import json
import subprocess


def _run_gh(args: list[str]) -> subprocess.CompletedProcess:
    """Run a ``gh`` command and return the completed process.  Raises on failure."""
    return subprocess.run(
        ["gh"] + args,
        check=True,
        capture_output=True,
        text=True,
    )


def create_repo(name: str, private: bool = True) -> str:
    """Create a GitHub repository and return its clone URL.

    Args:
        name: Repository name (without owner prefix).
        private: Whether to create as a private repository.

    Returns:
        The HTTPS clone URL of the newly created repository.
    """
    cmd = ["repo", "create", name, "--confirm"]
    if private:
        cmd.append("--private")
    else:
        cmd.append("--public")

    result = _run_gh(cmd)
    # ``gh repo create`` prints the URL to stdout
    url = result.stdout.strip()
    return url


def repo_exists(owner: str, name: str) -> bool:
    """Return True if the GitHub repository *owner*/*name* exists and is accessible."""
    try:
        _run_gh(["repo", "view", f"{owner}/{name}"])
        return True
    except subprocess.CalledProcessError:
        return False


def get_authenticated_user() -> str:
    """Return the GitHub username of the currently authenticated user.

    Uses ``gh api user`` and parses the JSON response.
    """
    result = _run_gh(["api", "user"])
    data = json.loads(result.stdout)
    return data.get("login", "")
