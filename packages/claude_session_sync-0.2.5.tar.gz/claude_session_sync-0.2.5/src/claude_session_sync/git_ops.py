from __future__ import annotations

import subprocess
from pathlib import Path
from typing import List


def _run(args: List[str], cwd: str | None = None) -> subprocess.CompletedProcess:
    """Run a command and return the completed process.  Raises on non-zero exit."""
    return subprocess.run(
        args,
        cwd=cwd,
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",  # Windows CP932対策
    )


def git_clone(url: str, dest: str) -> None:
    """Clone *url* into *dest*."""
    _run(["git", "clone", url, dest])


def git_pull(repo_dir: str) -> None:
    """Pull the latest changes in *repo_dir*."""
    _heal_repo(repo_dir)
    _run(["git", "pull"], cwd=repo_dir)


def git_push(repo_dir: str, max_retries: int = 3) -> None:
    """git push with retry on non-fast-forward rejection."""
    _heal_repo(repo_dir)
    for attempt in range(max_retries):
        try:
            _run(["git", "push"], cwd=repo_dir)
            return  # 成功
        except subprocess.CalledProcessError:
            if attempt == 0:
                # 初回失敗: upstream未設定かもしれない
                try:
                    _run(["git", "push", "-u", "origin", "main"], cwd=repo_dir)
                    return  # 成功
                except subprocess.CalledProcessError:
                    pass  # リトライへ

            if attempt < max_retries - 1:
                # pull してからリトライ
                print(f"push が拒否されました。pull してリトライします... ({attempt + 1}/{max_retries})")
                try:
                    _run(["git", "pull", "--rebase"], cwd=repo_dir)
                except subprocess.CalledProcessError:
                    # rebase 失敗なら通常の pull
                    try:
                        _run(["git", "pull", "--no-rebase"], cwd=repo_dir)
                    except subprocess.CalledProcessError:
                        pass
            else:
                raise  # 最終リトライも失敗


def git_add(repo_dir: str, files: List[str]) -> None:
    """Stage *files* in *repo_dir*.

    Pass ``["."]`` to stage all changes.
    """
    _heal_repo(repo_dir)
    _run(["git", "add"] + files, cwd=repo_dir)


def git_commit(repo_dir: str, message: str) -> None:
    """Create a commit with *message* in *repo_dir*."""
    _heal_repo(repo_dir)
    _run(["git", "commit", "-m", message], cwd=repo_dir)


def git_status(repo_dir: str) -> str:
    """Return the output of ``git status`` in *repo_dir*."""
    result = _run(["git", "status"], cwd=repo_dir)
    return result.stdout


def git_init(repo_dir: str) -> None:
    """Initialize a new git repository at *repo_dir*."""
    Path(repo_dir).mkdir(parents=True, exist_ok=True)
    _run(["git", "init", "-b", "main"], cwd=repo_dir)


def is_git_repo(path: str) -> bool:
    """Return True if *path* is inside a git repository."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=path,
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",  # Windows CP932対策
        )
        return result.stdout.strip() == "true"
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return False


def _abort_rebase(repo_dir: str) -> None:
    """進行中の rebase を中止し、残骸ディレクトリを除去する。"""
    try:
        _run(["git", "rebase", "--abort"], cwd=repo_dir)
    except subprocess.CalledProcessError:
        pass
    # git rebase --abort が効かない場合に備えて手動で除去
    import shutil
    for d in ("rebase-merge", "rebase-apply"):
        p = Path(repo_dir) / ".git" / d
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)


def _ensure_on_main(repo_dir: str) -> None:
    """detached HEAD の場合に main ブランチに戻す。"""
    try:
        _run(["git", "checkout", "-B", "main", "origin/main"], cwd=repo_dir)
    except subprocess.CalledProcessError:
        pass


def _heal_repo(repo_dir: str) -> None:
    """壊れた rebase 状態や detached HEAD を検知し、自動修復する。

    git_commit / git_push / git_pull など全操作の冒頭で呼ぶことで、
    どのコードパスからでも壊れた状態からの自動回復を保証する。
    """
    git_dir = Path(repo_dir) / ".git"
    if not git_dir.is_dir():
        return
    # rebase 残骸があれば除去
    has_rebase = (git_dir / "rebase-merge").is_dir() or (git_dir / "rebase-apply").is_dir()
    if has_rebase:
        _abort_rebase(repo_dir)
    # detached HEAD を検知して main に復帰
    head_file = git_dir / "HEAD"
    if head_file.is_file():
        head_content = head_file.read_text(encoding="utf-8", errors="replace").strip()
        if not head_content.startswith("ref:"):
            # detached HEAD — main ブランチに戻す
            _ensure_on_main(repo_dir)


def git_pull_safe(repo_dir: str) -> bool:
    """
    競合を自動解決する pull を試みる。

    試行順序:
    1. git pull（通常）
    2. git pull --rebase
    3. git stash → git pull → git stash pop
    4. （最終手段）git reset --hard origin/main（ローカル変更を破棄しリモートを優先）

    Returns
    -------
    bool
        成功したら True。最終手段を使った場合も True を返すが、警告を表示する。
    """
    # 1. 通常の pull
    try:
        _run(["git", "pull"], cwd=repo_dir)
        return True
    except subprocess.CalledProcessError:
        pass

    # 2. rebase を試みる
    try:
        _run(["git", "pull", "--rebase"], cwd=repo_dir)
        return True
    except subprocess.CalledProcessError:
        # rebase が中途半端に残る場合があるので必ずクリーンアップ
        _abort_rebase(repo_dir)

    # 3. stash → pull → stash pop
    try:
        _run(["git", "stash"], cwd=repo_dir)
        try:
            _run(["git", "pull"], cwd=repo_dir)
        except subprocess.CalledProcessError:
            # pull 失敗でも stash pop を試みる
            try:
                _run(["git", "stash", "pop"], cwd=repo_dir)
            except subprocess.CalledProcessError:
                pass
            # ここまで来たら次の手段へ
        else:
            # pull 成功 → stash pop を試みる
            try:
                _run(["git", "stash", "pop"], cwd=repo_dir)
            except subprocess.CalledProcessError:
                pass
            return True
    except subprocess.CalledProcessError:
        pass

    # 4. 最終手段: リモートを優先（ローカルの変更を破棄）
    _abort_rebase(repo_dir)  # reset 前に rebase 残骸を必ず除去
    try:
        _run(["git", "fetch", "origin"], cwd=repo_dir)
        _ensure_on_main(repo_dir)
        _run(["git", "reset", "--hard", "origin/main"], cwd=repo_dir)
        print(
            "警告: git の競合を解決できなかったため、ローカルの変更を破棄してリモートを優先しました。"
        )
        return True
    except subprocess.CalledProcessError:
        return False
