"""
Utilities for reading and writing shared_placeholders.json in the sync repository.

The file lives at <sync_repo_dir>/shared_placeholders.json and has the structure:

{
  "placeholders": {
    "HOME": {
      "ubuntu-pc": "/home/tubome",
      "macbook": "/Users/tubome",
      "windows-pc": "C:\\Users\\tubome"
    },
    "PROJECTS": {
      "ubuntu-pc": "/home/tubome/projects",
      "macbook": "/Users/tubome/projects"
    }
  }
}

Keys in "placeholders" are plain names without {{ }}.
"""
from __future__ import annotations

import json
import os
from pathlib import Path


SHARED_PLACEHOLDERS_FILENAME = "shared_placeholders.json"


def get_shared_placeholders_path(sync_repo_dir: str) -> str:
    """Return the absolute path to shared_placeholders.json."""
    return os.path.join(sync_repo_dir, SHARED_PLACEHOLDERS_FILENAME)


def load_shared_placeholders(sync_repo_dir: str) -> dict:
    """Load shared_placeholders.json and return the full dict.

    Returns an empty structure if the file does not exist.

    Structure:
        {
          "placeholders": {
            "NAME": {"machine-id": "path", ...},
            ...
          }
        }
    """
    path = get_shared_placeholders_path(sync_repo_dir)
    if not os.path.exists(path):
        return {"placeholders": {}}
    with open(path, encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            print(f"警告: shared_placeholders.json が壊れています。空の状態で再作成します。")
            return {"placeholders": {}}
    if "placeholders" not in data:
        data["placeholders"] = {}
    return data


def save_shared_placeholders(sync_repo_dir: str, data: dict) -> None:
    """Write shared_placeholders.json to disk.

    Creates the sync_repo_dir if it does not exist.
    """
    os.makedirs(sync_repo_dir, exist_ok=True)
    path = get_shared_placeholders_path(sync_repo_dir)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def get_machine_placeholders(sync_repo_dir: str, machine_id: str) -> dict[str, str]:
    """Return a dict of {placeholder_name: path} for the given machine.

    Only entries where the specified machine_id has a path are included.
    Keys are plain names (without {{ }}).

    Example return value:
        {"HOME": "/home/tubome", "PROJECTS": "/home/tubome/projects"}
    """
    data = load_shared_placeholders(sync_repo_dir)
    result: dict[str, str] = {}
    for name, machine_map in data.get("placeholders", {}).items():
        if machine_id in machine_map:
            result[name] = machine_map[machine_id]
    return result


def get_machine_placeholders_as_mapper_dict(sync_repo_dir: str, machine_id: str) -> dict[str, str]:
    """Return a dict suitable for PathMapper: {"{{NAME}}": "path", ...}."""
    raw = get_machine_placeholders(sync_repo_dir, machine_id)
    return {f"{{{{{name}}}}}": path for name, path in raw.items()}


def set_machine_path(
    sync_repo_dir: str,
    placeholder_name: str,
    machine_id: str,
    path: str,
) -> dict:
    """Set a machine's path for a given placeholder name.

    Creates or updates the entry.  Returns the full updated data dict.
    """
    data = load_shared_placeholders(sync_repo_dir)
    placeholders = data.setdefault("placeholders", {})
    if placeholder_name not in placeholders:
        placeholders[placeholder_name] = {}
    placeholders[placeholder_name][machine_id] = path
    return data


def machine_has_all_paths(sync_repo_dir: str, machine_id: str) -> bool:
    """Return True if the machine has a path set for every placeholder."""
    data = load_shared_placeholders(sync_repo_dir)
    for name, machine_map in data.get("placeholders", {}).items():
        if machine_id not in machine_map:
            return False
    return True
