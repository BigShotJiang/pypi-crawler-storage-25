from __future__ import annotations

import json
import os
import platform
import tempfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


CONFIG_DIR = Path.home() / ".claude-session-sync"
CONFIG_FILE = CONFIG_DIR / "config.json"


@dataclass
class Config:
    machine_id: str = ""
    github_owner: str = ""
    github_repo: str = "claude-sessions"
    github_remote_url: str = ""
    git_backend: str = "github"
    sync_repo_dir: str = str(Path.home() / ".claude-session-sync" / "repo")
    claude_projects_dir: str = str(Path.home() / ".claude" / "projects")
    claude_history_file: str = str(Path.home() / ".claude" / "history.jsonl")
    placeholders: dict = field(default_factory=dict)
    custom_placeholders: dict = field(default_factory=dict)
    sync_directories: list = field(default_factory=list)
    last_push_at: Optional[str] = None
    last_pull_at: Optional[str] = None

    @property
    def remote_url(self) -> str:
        """Canonical remote URL regardless of backend."""
        return self.github_remote_url

    @property
    def remote_display_name(self) -> str:
        """Human-readable remote identifier."""
        if self.git_backend == "github":
            return f"{self.github_owner}/{self.github_repo}"
        return self.github_remote_url

    @classmethod
    def load(cls) -> "Config":
        """Load config from ~/.claude-session-sync/config.json and return a Config instance.

        Can be called as ``Config.load()`` (classmethod) or on an instance
        as ``Config().load()`` — both return a populated Config.
        """
        instance = cls()
        if not CONFIG_FILE.exists():
            return instance
        with CONFIG_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
        for key, value in data.items():
            if hasattr(instance, key):
                setattr(instance, key, value)
        return instance

    def save(self) -> None:
        """Save config to ~/.claude-session-sync/config.json."""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(dir=str(CONFIG_DIR), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(asdict(self), f, indent=2, ensure_ascii=False)
                f.write("\n")
            os.replace(tmp_path, str(CONFIG_FILE))
        except:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    @classmethod
    def exists(cls) -> bool:
        """Return True if the config file exists."""
        return CONFIG_FILE.exists()

    def detect_placeholders(self=None) -> dict:
        """Detect placeholder mappings from the current OS environment.

        Returns a dict mapping placeholder strings to actual local paths.
        Only includes custom_placeholders explicitly added by the user.
        {{HOME}} and {{USERNAME}} are NOT auto-detected here; they are used
        internally as fallbacks during path conversion and for backward
        compatibility when pulling data that was pushed with those placeholders.

        When called on an instance (not the class), includes the instance's
        custom_placeholders in the returned mapping.
        """
        placeholders: dict = {}

        system = platform.system()
        if system == "Windows":
            # Windows-specific placeholders (APPDATA is non-home, keep it)
            appdata = os.environ.get("APPDATA", "")
            if appdata:
                placeholders["{{APPDATA}}"] = appdata

        # When called on an instance, merge custom_placeholders as well.
        # custom_placeholders keys are plain names (e.g. "PROJECTS"),
        # so wrap them in {{...}} for the final mapping.
        if isinstance(self, Config) and self.custom_placeholders:
            for name, path in self.custom_placeholders.items():
                key = f"{{{{{name}}}}}" if not (name.startswith("{{") and name.endswith("}}")) else name
                placeholders[key] = path

        return placeholders

    @staticmethod
    def fallback_placeholders() -> dict:
        """Return {{HOME}} and {{USERNAME}} placeholders for backward compatibility.

        These are used internally during path conversion (to_local) so that
        data pushed with the old auto-detected placeholders can still be read.
        They are NOT added to the push path-mapping so that new sessions are
        not tagged with overly broad home-directory placeholders.
        """
        home = str(Path.home())
        placeholders: dict = {"{{HOME}}": home}

        system = platform.system()
        if system == "Windows":
            username = os.environ.get("USERNAME", "")
        else:
            username = os.environ.get("USER", "")
        if username:
            placeholders["{{USERNAME}}"] = username

        return placeholders


def load_config() -> Config:
    """Convenience function to load and return the global config."""
    return Config.load()
