日本語 | [English](../README.md)

# claude-session-sync

Claude Code のセッション履歴を Windows / macOS / Linux 間で同期する CLI ツール

> **短縮コマンド**: `ccsync` は `claude-session-sync` の短縮形です。どちらでも使えます。

---

## これは何？

Claude Code の会話履歴を複数マシン間で共有できるツールです。

- Ubuntu で作業 → Mac に移動 → そのまま会話の続きができる
- GitHub プライベートリポジトリを同期バックエンドとして使用
- OS ごとに異なるパスを自動変換（`/home/user` → `/Users/user` → `C:\Users\user`）

---

## 仕組み

```
Ubuntu                          GitHub                         Mac
claude-session-sync push  →  プライベートリポジトリ  →  claude-session-sync pull
/home/user/projects        →      {{PROJECTS}}        →  /Users/user/projects
```

セッションファイルをリポジトリに保存する際、絶対パスをプレースホルダ（例: `{{PROJECTS}}`）に変換します。
別マシンで pull したときは、そのマシンの設定に従って元のパスに戻します。

メモリファイル（`~/.claude/projects/*/memory/`）も自動同期されます。
全マシンが同じ1セットのメモリファイルを共有し、最後に push した状態が全マシンの正となります。
pull 時にローカルのメモリは完全に置換され、変更履歴は git のコミット履歴で追跡できます。

---

## 機能一覧

| 機能 | 説明 |
|---|---|
| マシン間セッション引き継ぎ | `resume` コマンド一発で別マシンのセッションを再開 |
| カスタムプレースホルダ | プロジェクトディレクトリなど任意のパスを変換ルールとして登録 |
| セッションロック | 同じセッションを複数マシンから同時編集することを防止 |
| バックグラウンド daemon | Claude Code 作業中に定期的に push を実行（5分ごと） |
| 選択的同期 | `sync_directories` に登録したディレクトリのセッションのみ共有 |
| クロスプラットフォーム | Windows / macOS / Linux 全対応 |
| メモリ・CLAUDE.md 同期 | プロジェクトメモリと CLAUDE.md を全マシン間で自動同期 |
| 共有メモリモデル | 全マシンが同じ1セットのメモリを共有。最後に push した状態が正となる |
| 最終編集マシン表示 | セッション一覧で「最後に触ったマシン」を表示 |
| 同時作業対応 | 異なるセッションなら複数マシンで同時作業可能。git push 自動リトライ付き |

---

## クイックスタート

### インストール

```bash
pip install claude-session-sync
```

または開発版:

```bash
git clone https://github.com/tsubome/claude-session-sync.git
cd claude-session-sync
pip install -e .
```

### 初回セットアップ（各マシンで実行）

```bash
# GitHub CLI で認証しておく
gh auth login

# 初期化（GitHub リポジトリの作成とマシン登録）
claude-session-sync init
```

対話形式でマシンID・プロジェクトディレクトリ・プレースホルダを設定します。

2台目以降のマシンでは、同じリポジトリ名を指定すると既存の設定を引き継ぎます。

### 日常の使い方

```bash
# 別マシンのセッションを引き継いで作業を再開（最もよく使うコマンド）
ccsync resume  # または claude-session-sync resume

# 最新のセッションを自動選択して再開
claude-session-sync resume --latest

# 手動でプッシュ・プル
claude-session-sync push
claude-session-sync pull

# 同期状態を確認
claude-session-sync status
```

---

## コマンド一覧

### メインコマンド

| コマンド | 説明 |
|---|---|
| `resume` | pull → セッション選択 → Claude Code 起動 → 終了後 push を一括実行 |
| `push` | ローカルセッションをリモートへ手動プッシュ |
| `pull` | リモートセッションをローカルへ手動プル |
| `status` | 同期状態（最終 push/pull 日時など）を表示 |
| `list` | セッション一覧を表示（`--remote` でリモートのみ表示） |
| `update` | push とロック解放をまとめて実行（異常終了後の復旧用） |
| `init` | マシン登録と GitHub リポジトリの作成・接続 |

### resume オプション

```bash
claude-session-sync resume                         # インタラクティブに選択
claude-session-sync resume <SESSION_ID>            # セッションIDを直接指定
claude-session-sync resume --latest                # 最新のセッションを自動選択
claude-session-sync resume --from ubuntu-machine   # 特定マシンのセッションのみ表示
claude-session-sync resume --all                   # sync_directories 外のセッションも表示
```

### ロック管理

```bash
claude-session-sync lock show        # 現在のロック一覧を表示
claude-session-sync lock release     # このマシンのロックをすべて解放
claude-session-sync lock release <SESSION_ID>  # 特定セッションのロックを解放
claude-session-sync lock cleanup     # 有効期限切れのロックを削除
```

### 設定管理

```bash
claude-session-sync config show                              # 現在の設定を表示
claude-session-sync config add-placeholder PROJECTS=/path   # プレースホルダを追加
claude-session-sync config set-path PROJECTS mac-m1 /Users/user/projects  # 他マシンのパスを設定
```

### バックグラウンド同期

```bash
claude-session-sync daemon                  # フォアグラウンドで起動（5分ごとに push/pull）
claude-session-sync daemon --interval 120   # 2分ごとに同期
claude-session-sync daemon --stop           # 動作中の daemon を停止（Linux/macOS）
claude-session-sync daemon --once           # 1回だけ実行して終了（テスト用）
```

---

## 設定

設定ファイルは `~/.claude-session-sync/config.json` に保存されます。

```json
{
  "machine_id": "ubuntu-main",
  "github_owner": "yourname",
  "github_repo": "claude-sessions",
  "sync_repo_dir": "/home/user/.claude-session-sync/repo",
  "claude_projects_dir": "/home/user/.claude/projects",
  "placeholders": {
    "{{PROJECTS}}": "/home/user/projects"
  },
  "custom_placeholders": {
    "PROJECTS": "/home/user/projects"
  },
  "sync_directories": [
    "/home/user/projects"
  ]
}
```

### sync_directories

`sync_directories` に登録したディレクトリ配下のセッションのみ共有されます。
未設定の場合はすべてのセッションが対象になります。

---

## カスタムプレースホルダ

パスの変換ルールをプレースホルダとして登録することで、OS やユーザー名が異なるマシン間でもセッションを正しく引き継げます。

### 登録方法

初期化時に対話形式で設定する:

```bash
claude-session-sync init
```

または後から追加する:

```bash
claude-session-sync config add-placeholder PROJECTS=/home/user/projects
```

### 具体例

| マシン | マシンID | PROJECTS の実パス |
|---|---|---|
| Ubuntu | ubuntu-main | `/home/tubome/projects` |
| Mac | mac-m1 | `/Users/tubome/projects` |
| Windows | win-desktop | `C:\Users\tubome\projects` |

リポジトリ内では `{{PROJECTS}}` として保存され、各マシンで pull するときに対応するパスに変換されます。

他マシンのパスは `config set-path` で登録できます:

```bash
claude-session-sync config set-path PROJECTS mac-m1 /Users/tubome/projects
claude-session-sync config set-path PROJECTS win-desktop "C:\Users\tubome\projects"
```

### 登録ディレクトリ以下のセッションのみ共有

プレースホルダに登録したディレクトリは自動的に `sync_directories` に追加されます。
そのディレクトリ配下のプロジェクトのセッションのみが共有対象になります。

---

## セッションロック

同じセッションを複数マシンから同時に編集することを防ぐ仕組みです。

- **TTL ベース**: デフォルト10分。ロック取得から10分が経過すると自動失効
- **Heartbeat によるロック延長**: `resume` 実行中は daemon が定期的にロックを更新し、有効期限を延長し続ける
- **クラッシュ時の自動失効**: Claude Code が異常終了した場合、TTL が切れると自動的にロックが解放される
- **手動解放**: `lock release` コマンドでいつでも解放できる

```bash
# ロック状態を確認
claude-session-sync lock show

# 手動でロックを解放
claude-session-sync lock release
claude-session-sync lock release <SESSION_ID>
```

---

## 同時作業

異なるセッションであれば、複数マシンで同時に作業できます。
例えば Linux で CrossClip、Windows で WhisperApp を同時に作業可能です。

- ロックはセッション単位（異なるセッション間で干渉しない）
- git push の競合時は自動で pull → リトライ（最大3回）
- daemon の二重起動を自動検出して防止

---

## よくある質問 / トラブルシューティング

### 「セッションがロックされている」と表示される

別マシンで作業中か、前回のセッションが正常に終了しなかった場合に表示されます。

- 他マシンで実際に作業中の場合 → `N` を選択してキャンセル
- 前回クラッシュした場合 → `y` を選択して続行（ロックが自マシンに引き継がれます）

### 「セッションが見つからない」

リモートのセッションがまだ pull されていない可能性があります。

```bash
claude-session-sync pull
claude-session-sync resume
```

### 異常終了後の復旧

Claude Code が強制終了するなどして push とロック解放が行われなかった場合:

```bash
claude-session-sync update
```

このコマンドで push とこのマシンのロック全解放をまとめて実行できます。

### Windows で daemon が止まらない

Linux/macOS では `daemon --stop` が SIGTERM を送信しますが、Windows では `~/.claude-session-sync/` ディレクトリに stop ファイルを作成することで daemon に停止を通知します。

```powershell
# Windows での daemon 停止
claude-session-sync daemon --stop
```

### push/pull の --dry-run でテスト

実際に同期する前に何が起きるかを確認できます:

```bash
claude-session-sync push --dry-run
claude-session-sync pull --dry-run
```

---

## 動作環境

| 要件 | バージョン |
|---|---|
| Python | 3.9 以上 |
| Git | 任意の安定版 |
| GitHub CLI (`gh`) | 認証済みであること |
| Claude Code | インストール済みであること |

---

## ライセンス

MIT
