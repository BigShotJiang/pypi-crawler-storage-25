"""
Tests for the shared_placeholders feature.

Covers:
1. shared_placeholders.json の読み書き
2. init で共有プレースホルダが正しく作成されるか（input をモック）
3. 異なるマシン間でのプレースホルダ変換（Ubuntu→Mac、Ubuntu→Win）
4. add-placeholder で正しく追加されるか
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from unittest.mock import patch, call, MagicMock

import pytest

import claude_session_sync.config as config_module
from claude_session_sync.config import Config
from claude_session_sync.path_mapper import PathMapper
from claude_session_sync.shared_placeholders import (
    load_shared_placeholders,
    save_shared_placeholders,
    get_machine_placeholders,
    get_machine_placeholders_as_mapper_dict,
    set_machine_path,
    machine_has_all_paths,
    get_shared_placeholders_path,
    SHARED_PLACEHOLDERS_FILENAME,
)
from claude_session_sync.sync import (
    _apply_placeholder_to_record,
    _apply_local_to_record,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _patch_config_paths(monkeypatch, tmp_path):
    config_dir = tmp_path / ".claude-session-sync"
    config_file = config_dir / "config.json"
    monkeypatch.setattr(config_module, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)
    return config_dir, config_file


SAMPLE_SHARED = {
    "placeholders": {
        "HOME": {
            "ubuntu-pc": "/home/tubome",
            "macbook": "/Users/tubome",
            "windows-pc": "C:\\Users\\tubome",
        },
        "PROJECTS": {
            "ubuntu-pc": "/home/tubome/projects",
            "macbook": "/Users/tubome/projects",
            "windows-pc": "C:\\projects",
        },
    }
}


# ---------------------------------------------------------------------------
# 1. shared_placeholders.json の読み書き
# ---------------------------------------------------------------------------


class TestSharedPlaceholdersIO:
    def test_save_and_load_round_trip(self, tmp_path):
        """save してから load したら同じデータが返る。"""
        repo = str(tmp_path / "repo")
        os.makedirs(repo)

        save_shared_placeholders(repo, SAMPLE_SHARED)
        loaded = load_shared_placeholders(repo)

        assert loaded == SAMPLE_SHARED

    def test_load_returns_empty_structure_when_file_missing(self, tmp_path):
        """ファイルが無い場合は空の構造が返る。"""
        repo = str(tmp_path / "repo")
        os.makedirs(repo)

        result = load_shared_placeholders(repo)
        assert result == {"placeholders": {}}

    def test_save_creates_directory(self, tmp_path):
        """sync_repo_dir が存在しなくても save できる。"""
        repo = str(tmp_path / "new-repo")
        assert not os.path.exists(repo)

        save_shared_placeholders(repo, {"placeholders": {}})

        assert os.path.exists(os.path.join(repo, SHARED_PLACEHOLDERS_FILENAME))

    def test_save_writes_valid_json(self, tmp_path):
        """保存されるファイルは有効な JSON である。"""
        repo = str(tmp_path / "repo")
        save_shared_placeholders(repo, SAMPLE_SHARED)

        path = get_shared_placeholders_path(repo)
        with open(path, encoding="utf-8") as f:
            parsed = json.load(f)
        assert parsed == SAMPLE_SHARED

    def test_set_machine_path_creates_entry(self, tmp_path):
        """set_machine_path で新しいエントリを追加できる。"""
        repo = str(tmp_path / "repo")
        data = set_machine_path(repo, "PROJECTS", "ubuntu-pc", "/home/tubome/projects")
        assert data["placeholders"]["PROJECTS"]["ubuntu-pc"] == "/home/tubome/projects"

    def test_set_machine_path_updates_existing(self, tmp_path):
        """set_machine_path で既存エントリを更新できる。"""
        repo = str(tmp_path / "repo")
        # 最初に保存
        save_shared_placeholders(repo, SAMPLE_SHARED)
        # 更新
        data = set_machine_path(repo, "PROJECTS", "ubuntu-pc", "/home/new/projects")
        assert data["placeholders"]["PROJECTS"]["ubuntu-pc"] == "/home/new/projects"
        # 他のマシンのエントリは変わらない
        assert data["placeholders"]["PROJECTS"]["macbook"] == "/Users/tubome/projects"

    def test_get_machine_placeholders_returns_correct_mapping(self, tmp_path):
        """get_machine_placeholders が指定マシンのパス一覧を返す。"""
        repo = str(tmp_path / "repo")
        save_shared_placeholders(repo, SAMPLE_SHARED)

        result = get_machine_placeholders(repo, "ubuntu-pc")
        assert result == {
            "HOME": "/home/tubome",
            "PROJECTS": "/home/tubome/projects",
        }

    def test_get_machine_placeholders_returns_empty_for_unknown_machine(self, tmp_path):
        """存在しないマシン ID に対しては空の dict が返る。"""
        repo = str(tmp_path / "repo")
        save_shared_placeholders(repo, SAMPLE_SHARED)

        result = get_machine_placeholders(repo, "unknown-machine")
        assert result == {}

    def test_get_machine_placeholders_as_mapper_dict_wraps_braces(self, tmp_path):
        """get_machine_placeholders_as_mapper_dict が {{NAME}} 形式のキーを返す。"""
        repo = str(tmp_path / "repo")
        save_shared_placeholders(repo, SAMPLE_SHARED)

        result = get_machine_placeholders_as_mapper_dict(repo, "ubuntu-pc")
        assert result == {
            "{{HOME}}": "/home/tubome",
            "{{PROJECTS}}": "/home/tubome/projects",
        }

    def test_machine_has_all_paths_true(self, tmp_path):
        """全プレースホルダにパスが設定されているマシンは True。"""
        repo = str(tmp_path / "repo")
        save_shared_placeholders(repo, SAMPLE_SHARED)
        assert machine_has_all_paths(repo, "ubuntu-pc") is True

    def test_machine_has_all_paths_false_partial(self, tmp_path):
        """一部のプレースホルダにパスが設定されていないマシンは False。"""
        repo = str(tmp_path / "repo")
        data = {
            "placeholders": {
                "HOME": {"ubuntu-pc": "/home/tubome"},
                "PROJECTS": {},  # ubuntu-pc のパスなし
            }
        }
        save_shared_placeholders(repo, data)
        assert machine_has_all_paths(repo, "ubuntu-pc") is False


# ---------------------------------------------------------------------------
# 2. init で共有プレースホルダが正しく作成されるか（input をモック）
# ---------------------------------------------------------------------------


class TestInitSharedPlaceholders:
    """init コマンドが shared_placeholders.json を正しく作成する。"""

    def _make_args(self, machine_id=None, owner=None, repo=None, add_placeholder=None):
        args = argparse.Namespace()
        args.machine_id = machine_id
        args.owner = owner
        args.repo = repo
        args.add_placeholder = add_placeholder or []
        return args

    def _mock_init_externals(self, monkeypatch, tmp_path, sync_repo_dir):
        """Set up common mocks for init tests."""
        import claude_session_sync.github_ops as github_ops
        monkeypatch.setattr(github_ops, "get_authenticated_user", lambda: "testuser")
        monkeypatch.setattr(github_ops, "repo_exists", lambda owner, repo: True)

        import claude_session_sync.git_ops as git_ops
        monkeypatch.setattr(
            git_ops, "git_clone",
            lambda url, dest: os.makedirs(os.path.join(dest, ".git"), exist_ok=True),
        )
        monkeypatch.setattr(git_ops, "git_add", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_commit", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_push", lambda *a, **kw: None)

        # Redirect expanduser for the specific paths used in init.run(),
        # but still handle bare "~" for Path.home() compatibility.
        real_expanduser = os.path.expanduser

        def fake_expanduser(p):
            if p == "~/.claude-session-sync/repo":
                return sync_repo_dir
            if p == "~/.claude/projects":
                return str(tmp_path / "claude" / "projects")
            if p == "~/.claude/history.jsonl":
                return str(tmp_path / "claude" / "history.jsonl")
            return real_expanduser(p)

        monkeypatch.setattr("os.path.expanduser", fake_expanduser)

    def test_init_creates_shared_placeholders_with_add_placeholder_flag(
        self, monkeypatch, tmp_path
    ):
        """--add-placeholder フラグで shared_placeholders.json が作成される。"""
        _patch_config_paths(monkeypatch, tmp_path)

        sync_repo_dir = str(tmp_path / "repo")
        os.makedirs(sync_repo_dir)

        self._mock_init_externals(monkeypatch, tmp_path, sync_repo_dir)

        # input() が呼ばれないようにモック
        with patch("builtins.input", return_value=""):
            from claude_session_sync.commands import init as init_cmd
            args = self._make_args(
                machine_id="ubuntu-pc",
                add_placeholder=["PROJECTS=/home/tubome/projects"],
            )
            init_cmd.run(args)

        # shared_placeholders.json が作成されている
        ph_path = os.path.join(sync_repo_dir, SHARED_PLACEHOLDERS_FILENAME)
        assert os.path.exists(ph_path), "shared_placeholders.json が作成されていない"

        with open(ph_path, encoding="utf-8") as f:
            data = json.load(f)

        ph = data.get("placeholders", {})
        # HOME は自動的に追加される
        assert "HOME" in ph
        assert "ubuntu-pc" in ph["HOME"]
        # PROJECTS も追加されている
        assert "PROJECTS" in ph
        assert ph["PROJECTS"]["ubuntu-pc"] == "/home/tubome/projects"

    def test_init_detects_home_automatically(self, monkeypatch, tmp_path):
        """init で HOME が自動検出されて shared_placeholders に記録される。"""
        _patch_config_paths(monkeypatch, tmp_path)

        sync_repo_dir = str(tmp_path / "repo")
        os.makedirs(sync_repo_dir)

        self._mock_init_externals(monkeypatch, tmp_path, sync_repo_dir)

        # input() はすべて "n" (= プロジェクトや他マシン追加しない)
        with patch("builtins.input", return_value="n"):
            from claude_session_sync.commands import init as init_cmd
            args = self._make_args(machine_id="ubuntu-pc")
            init_cmd.run(args)

        ph_path = os.path.join(sync_repo_dir, SHARED_PLACEHOLDERS_FILENAME)
        assert os.path.exists(ph_path)
        data = json.load(open(ph_path, encoding="utf-8"))
        ph = data.get("placeholders", {})
        assert "HOME" in ph
        assert "ubuntu-pc" in ph["HOME"]
        assert ph["HOME"]["ubuntu-pc"] == str(Path.home())

    def test_init_already_setup_returns_early(self, monkeypatch, tmp_path):
        """既にセットアップ済みの場合は早期リターンする。"""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        config_dir.mkdir(parents=True, exist_ok=True)
        config_file.write_text('{"machine_id": "existing"}', encoding="utf-8")

        from claude_session_sync.commands import init as init_cmd
        args = self._make_args(machine_id="ubuntu-pc")

        # github 系が呼ばれないことを確認 (呼ばれたら例外になる)
        with patch("builtins.print") as mock_print:
            init_cmd.run(args)
        output = " ".join(str(c) for c in mock_print.call_args_list)
        assert "既にセットアップ済み" in output

    def test_multiple_add_placeholder_args_all_persisted(self, monkeypatch, tmp_path):
        """複数の --add-placeholder 引数を渡したとき全エントリが保存される（ループバグ回帰テスト）。

        以前は set_machine_path() がループ内でディスクから再読み込みするため
        最後のプレースホルダしか保存されなかった。
        """
        _patch_config_paths(monkeypatch, tmp_path)

        sync_repo_dir = str(tmp_path / "repo")
        os.makedirs(sync_repo_dir)

        self._mock_init_externals(monkeypatch, tmp_path, sync_repo_dir)

        with patch("builtins.input", return_value=""):
            from claude_session_sync.commands import init as init_cmd
            args = self._make_args(
                machine_id="ubuntu-pc",
                add_placeholder=[
                    "PROJECTS=/home/tubome/projects",
                    "WORK=/home/tubome/work",
                    "DATA=/data/store",
                ],
            )
            init_cmd.run(args)

        ph_path = os.path.join(sync_repo_dir, SHARED_PLACEHOLDERS_FILENAME)
        assert os.path.exists(ph_path)
        data = json.load(open(ph_path, encoding="utf-8"))
        ph = data.get("placeholders", {})

        # 全プレースホルダがすべて保存されていること（最後の1件だけでないこと）
        assert ph.get("PROJECTS", {}).get("ubuntu-pc") == "/home/tubome/projects"
        assert ph.get("WORK", {}).get("ubuntu-pc") == "/home/tubome/work"
        assert ph.get("DATA", {}).get("ubuntu-pc") == "/data/store"

    def test_second_machine_new_paths_all_persisted(self, monkeypatch, tmp_path):
        """2台目のマシンが既存 shared_placeholders.json に複数パスを登録するとき全エントリが保存される。

        既存ファイルにあるプレースホルダに対してループでパスを入力するシナリオ。
        """
        _patch_config_paths(monkeypatch, tmp_path)

        sync_repo_dir = str(tmp_path / "repo")
        os.makedirs(sync_repo_dir)

        self._mock_init_externals(monkeypatch, tmp_path, sync_repo_dir)

        # 1台目 (ubuntu-pc) のデータが既にある状態を作る
        existing_data = {
            "placeholders": {
                "HOME": {"ubuntu-pc": "/home/tubome"},
                "PROJECTS": {"ubuntu-pc": "/home/tubome/projects"},
                "WORK": {"ubuntu-pc": "/home/tubome/work"},
            }
        }
        save_shared_placeholders(sync_repo_dir, existing_data)

        # 2台目 (macbook) として init: 各プレースホルダのパスを順に入力
        input_responses = iter([
            # マシンID（machine_id は args で指定するので呼ばれない）
            "/Users/tubome",           # HOME
            "/Users/tubome/projects",  # PROJECTS
            "/Users/tubome/work",      # WORK
        ])
        with patch("builtins.input", side_effect=input_responses):
            from claude_session_sync.commands import init as init_cmd
            args = self._make_args(machine_id="macbook")
            init_cmd.run(args)

        data = load_shared_placeholders(sync_repo_dir)
        ph = data.get("placeholders", {})

        # 全プレースホルダに macbook のパスが保存されていること
        assert ph.get("HOME", {}).get("macbook") == "/Users/tubome"
        assert ph.get("PROJECTS", {}).get("macbook") == "/Users/tubome/projects"
        assert ph.get("WORK", {}).get("macbook") == "/Users/tubome/work"
        # 既存の ubuntu-pc のデータが消えていないこと
        assert ph.get("HOME", {}).get("ubuntu-pc") == "/home/tubome"
        assert ph.get("PROJECTS", {}).get("ubuntu-pc") == "/home/tubome/projects"
        assert ph.get("WORK", {}).get("ubuntu-pc") == "/home/tubome/work"


# ---------------------------------------------------------------------------
# 3. 異なるマシン間でのプレースホルダ変換（Ubuntu→Mac、Ubuntu→Win）
# ---------------------------------------------------------------------------


class TestCrossMachinePlaceholderConversion:
    """shared_placeholders.json を利用したマシン間変換テスト。"""

    def _make_mapper_for_machine(self, shared_data: dict, machine_id: str) -> PathMapper:
        """指定マシンのプレースホルダを使って PathMapper を構築する。"""
        ph = {}
        for name, machines in shared_data.get("placeholders", {}).items():
            if machine_id in machines:
                ph[f"{{{{{name}}}}}"] = machines[machine_id]
        return PathMapper(ph)

    def test_ubuntu_to_mac_session_path(self):
        """Ubuntu の実パスを Ubuntu mapper でプレースホルダ化 → Mac mapper で復元。"""
        shared = SAMPLE_SHARED

        ubuntu_mapper = self._make_mapper_for_machine(shared, "ubuntu-pc")
        mac_mapper = self._make_mapper_for_machine(shared, "macbook")

        original = "/home/tubome/projects/myapp/session.jsonl"
        placeholder_form = ubuntu_mapper.to_placeholder(original)
        assert "{{PROJECTS}}" in placeholder_form

        restored = mac_mapper.to_local(placeholder_form)
        assert restored == "/Users/tubome/projects/myapp/session.jsonl"
        assert "/home/tubome" not in restored

    def test_ubuntu_to_windows_session_path(self):
        """Ubuntu の実パスを Ubuntu mapper でプレースホルダ化 → Windows mapper で復元。"""
        shared = SAMPLE_SHARED

        ubuntu_mapper = self._make_mapper_for_machine(shared, "ubuntu-pc")
        win_mapper = self._make_mapper_for_machine(shared, "windows-pc")

        original = "/home/tubome/projects/myapp/session.jsonl"
        placeholder_form = ubuntu_mapper.to_placeholder(original)

        restored = win_mapper.to_local(placeholder_form)
        assert restored == "C:\\projects/myapp/session.jsonl"
        assert "/home/tubome" not in restored

    def test_mac_to_ubuntu_home_path(self):
        """Mac の HOME パスを Mac mapper でプレースホルダ化 → Ubuntu mapper で復元。"""
        shared = SAMPLE_SHARED

        mac_mapper = self._make_mapper_for_machine(shared, "macbook")
        ubuntu_mapper = self._make_mapper_for_machine(shared, "ubuntu-pc")

        original = "/Users/tubome/.config/app.json"
        placeholder_form = mac_mapper.to_placeholder(original)
        assert "{{HOME}}" in placeholder_form

        restored = ubuntu_mapper.to_local(placeholder_form)
        assert restored == "/home/tubome/.config/app.json"

    def test_record_conversion_ubuntu_to_mac(self):
        """セッションレコード全体のプレースホルダ変換テスト（Ubuntu → Mac）。"""
        shared = SAMPLE_SHARED
        ubuntu_mapper = self._make_mapper_for_machine(shared, "ubuntu-pc")
        mac_mapper = self._make_mapper_for_machine(shared, "macbook")

        records = [
            {"type": "system", "cwd": "/home/tubome/projects", "sessionId": "s1"},
            {
                "type": "user",
                "message": {"role": "user", "content": "Hello from /home/tubome/projects!"},
                "cwd": "/home/tubome/projects",
            },
        ]

        # Ubuntu → placeholder
        ph_records = [_apply_placeholder_to_record(r, ubuntu_mapper) for r in records]
        ph_str = json.dumps(ph_records)
        assert "/home/tubome" not in ph_str
        assert "{{PROJECTS}}" in ph_str

        # placeholder → Mac
        mac_records = [_apply_local_to_record(r, mac_mapper) for r in ph_records]
        mac_str = json.dumps(mac_records)
        assert "{{PROJECTS}}" not in mac_str
        assert "/Users/tubome/projects" in mac_str
        assert "/home/tubome" not in mac_str

    def test_longer_placeholder_takes_priority(self):
        """PROJECTS (長いパス) が HOME (短いパス) より先に変換される。"""
        shared = SAMPLE_SHARED
        ubuntu_mapper = self._make_mapper_for_machine(shared, "ubuntu-pc")

        text = "/home/tubome/projects/foo"
        result = ubuntu_mapper.to_placeholder(text)
        # {{PROJECTS}} が使われる ({{HOME}}/projects/foo ではない)
        assert result == "{{PROJECTS}}/foo"
        assert "{{HOME}}" not in result


# ---------------------------------------------------------------------------
# 4. add-placeholder で正しく追加されるか
# ---------------------------------------------------------------------------


class TestConfigAddPlaceholder:
    def _make_config(self, tmp_path, machine_id="ubuntu-pc") -> Config:
        sync_repo_dir = str(tmp_path / "repo")
        os.makedirs(sync_repo_dir)
        cfg = Config(
            machine_id=machine_id,
            sync_repo_dir=sync_repo_dir,
            github_owner="testuser",
            github_repo="claude-session-sync",
            github_remote_url="https://github.com/testuser/claude-session-sync.git",
        )
        return cfg

    def test_add_placeholder_updates_local_config(self, monkeypatch, tmp_path):
        """add-placeholder がローカル config.json の placeholders と custom_placeholders を更新する。"""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        cfg = self._make_config(tmp_path)
        cfg.save()

        # git 操作をスタブ化 (git_ops モジュール側をモック)
        import claude_session_sync.git_ops as git_ops
        monkeypatch.setattr(git_ops, "git_add", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_commit", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_push", lambda *a, **kw: None)

        args = argparse.Namespace(
            config_subcommand="add-placeholder",
            name_path="PROJECTS=/home/tubome/projects",
        )

        from claude_session_sync.commands import config_cmd
        config_cmd.run(args)

        loaded = Config.load()
        assert loaded.placeholders.get("{{PROJECTS}}") == "/home/tubome/projects"
        assert loaded.custom_placeholders.get("PROJECTS") == "/home/tubome/projects"

    def test_add_placeholder_updates_shared_placeholders_json(self, monkeypatch, tmp_path):
        """add-placeholder が shared_placeholders.json を更新する。"""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        cfg = self._make_config(tmp_path)
        cfg.save()

        import claude_session_sync.git_ops as git_ops
        monkeypatch.setattr(git_ops, "git_add", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_commit", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_push", lambda *a, **kw: None)

        args = argparse.Namespace(
            config_subcommand="add-placeholder",
            name_path="WORK=/home/tubome/work",
        )

        from claude_session_sync.commands import config_cmd
        config_cmd.run(args)

        data = load_shared_placeholders(cfg.sync_repo_dir)
        assert "WORK" in data["placeholders"]
        assert data["placeholders"]["WORK"]["ubuntu-pc"] == "/home/tubome/work"

    def test_add_placeholder_invalid_format_exits(self, monkeypatch, tmp_path):
        """NAME=PATH 形式でない引数を渡すと sys.exit する。"""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        cfg = self._make_config(tmp_path)
        cfg.save()

        args = argparse.Namespace(
            config_subcommand="add-placeholder",
            name_path="INVALID_NO_EQUALS",
        )

        from claude_session_sync.commands import config_cmd
        with pytest.raises(SystemExit):
            config_cmd.run(args)

    def test_set_path_updates_shared_placeholders(self, monkeypatch, tmp_path):
        """set-path が指定マシンのパスを shared_placeholders.json に書き込む。"""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        cfg = self._make_config(tmp_path)
        cfg.save()

        # 事前に shared_placeholders.json に PROJECTS を作成
        save_shared_placeholders(cfg.sync_repo_dir, {
            "placeholders": {
                "PROJECTS": {"ubuntu-pc": "/home/tubome/projects"},
            }
        })

        import claude_session_sync.git_ops as git_ops
        monkeypatch.setattr(git_ops, "git_add", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_commit", lambda *a, **kw: None)
        monkeypatch.setattr(git_ops, "git_push", lambda *a, **kw: None)

        args = argparse.Namespace(
            config_subcommand="set-path",
            placeholder_name="PROJECTS",
            target_machine="macbook",
            path="/Users/tubome/projects",
        )

        from claude_session_sync.commands import config_cmd
        config_cmd.run(args)

        data = load_shared_placeholders(cfg.sync_repo_dir)
        assert data["placeholders"]["PROJECTS"]["macbook"] == "/Users/tubome/projects"
        # 既存のエントリは変わらない
        assert data["placeholders"]["PROJECTS"]["ubuntu-pc"] == "/home/tubome/projects"

    def test_show_prints_configuration(self, monkeypatch, tmp_path, capsys):
        """show サブコマンドが設定情報を出力する。"""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        cfg = self._make_config(tmp_path)
        cfg.placeholders = {"{{HOME}}": "/home/tubome"}
        cfg.custom_placeholders = {"PROJECTS": "/home/tubome/projects"}
        cfg.save()

        # shared_placeholders.json も作成
        save_shared_placeholders(cfg.sync_repo_dir, {
            "placeholders": {
                "HOME": {"ubuntu-pc": "/home/tubome"},
            }
        })

        args = argparse.Namespace(config_subcommand="show")

        from claude_session_sync.commands import config_cmd
        config_cmd.run(args)

        captured = capsys.readouterr()
        assert "ubuntu-pc" in captured.out
        assert "{{HOME}}" in captured.out


# ---------------------------------------------------------------------------
# 5. Config.detect_placeholders インスタンスメソッドのテスト
# ---------------------------------------------------------------------------


class TestDetectPlaceholdersWithCustom:
    def test_instance_includes_custom_placeholders(self):
        """インスタンスメソッドとして呼ぶと custom_placeholders が含まれる。"""
        cfg = Config()
        cfg.custom_placeholders = {"PROJECTS": "/home/tubome/projects"}

        result = cfg.detect_placeholders()

        # {{HOME}} は自動検出しない（sync_directories 外のセッション共有防止）
        # custom_placeholders が反映されていることを確認
        assert "{{PROJECTS}}" in result
        assert result["{{PROJECTS}}"] == "/home/tubome/projects"

    def test_classmethod_does_not_include_custom_placeholders(self):
        """クラスメソッドとして呼ぶと custom_placeholders は含まれない。"""
        result = Config.detect_placeholders()

        # {{HOME}} は自動検出しない（後方互換は fallback_placeholders() で提供）
        assert "{{HOME}}" not in result
        # custom_placeholders は反映されない
        assert "{{PROJECTS}}" not in result

    def test_custom_placeholder_key_already_wrapped(self):
        """custom_placeholders のキーが既に {{...}} 形式でも二重ラップされない。"""
        cfg = Config()
        cfg.custom_placeholders = {"{{WORK}}": "/home/tubome/work"}

        result = cfg.detect_placeholders()

        assert "{{WORK}}" in result
        assert "{{{{WORK}}}}" not in result

    def test_custom_placeholder_saved_and_loaded(self, monkeypatch, tmp_path):
        """custom_placeholders が save/load を経て保持される。"""
        _patch_config_paths(monkeypatch, tmp_path)

        cfg = Config(machine_id="test")
        cfg.custom_placeholders = {"PROJECTS": "/home/tubome/projects"}
        cfg.save()

        loaded = Config.load()
        assert loaded.custom_placeholders == {"PROJECTS": "/home/tubome/projects"}
