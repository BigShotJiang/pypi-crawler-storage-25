#!/usr/bin/env python3
# Claude Code session file project directory name conversion test
#
# Claude Code converts cwd to a directory name with these rules:
#   /home/tubome/projects      -> -home-tubome-projects
#   /Users/tubome/projects     -> -Users-tubome-projects
#   C:\Users\tubome\projects   -> C:-Users-tubome-projects
#
# Rule: replace all path separators (/ or \) with hyphens.
# For Unix paths the leading / becomes a leading hyphen.
# For Windows paths the backslash after the drive letter becomes a hyphen.

import re
import sys


def path_to_project_dir(path: str) -> str:
    """Reproduce the path->project-dir-name conversion used by Claude Code."""
    # Windows path: C:\... form
    if re.match(r'^[A-Za-z]:\\', path):
        return path.replace('\\', '-')

    # Unix path: /home/... form
    if path.startswith('/'):
        # Replace every slash with a hyphen (leading / becomes leading -)
        return path.replace('/', '-')

    # Relative paths: return as-is
    return path


def run_tests():
    windows_path_1 = 'C:\\Users\\tubome\\projects'
    windows_path_2 = 'C:\\Users\\tubome\\projects\\baz'

    test_cases = [
        ("/home/tubome/projects",     "-home-tubome-projects"),
        ("/home/tubome/projects/foo", "-home-tubome-projects-foo"),
        ("/Users/tubome/projects",    "-Users-tubome-projects"),
        ("/Users/tubome/projects/bar","-Users-tubome-projects-bar"),
        (windows_path_1,              "C:-Users-tubome-projects"),
        (windows_path_2,              "C:-Users-tubome-projects-baz"),
    ]

    passed = 0
    failed = 0

    print("=" * 60)
    print("Claude Code path -> project directory name conversion test")
    print("=" * 60)

    for input_path, expected in test_cases:
        result = path_to_project_dir(input_path)
        ok = result == expected
        status = "PASS" if ok else "FAIL"

        if ok:
            passed += 1
        else:
            failed += 1

        print(f"\n[{status}]")
        print(f"  Input   : {input_path}")
        print(f"  Expected: {expected}")
        print(f"  Got     : {result}")

    print("\n" + "=" * 60)
    print(f"Result: {passed} passed, {failed} failed")
    print("=" * 60)

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    run_tests()
