"""
tests/test_update.py

update コマンドのテスト:
1. push が呼ばれるか
2. release_all_locks が呼ばれるか
3. push結果が0件の場合のメッセージ
4. ロック解放結果が0件の場合のメッセージ
"""
from __future__ import annotations

import argparse
from pathlib import Path
from unittest.mock import patch

import pytest


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _import_update():
    from claude_session_sync.commands import update
    return update


def _make_config(tmp_path: Path):
    from claude_session_sync.config import Config
    cfg = Config()
    cfg.machine_id = "test-machine"
    cfg.claude_projects_dir = str(tmp_path / "claude_projects")
    cfg.claude_history_file = str(tmp_path / ".claude" / "history.jsonl")
    cfg.sync_repo_dir = str(tmp_path / "sync_repo")
    cfg.placeholders = {}
    return cfg


def _make_args() -> argparse.Namespace:
    return argparse.Namespace()


# ---------------------------------------------------------------------------
# テスト 1: push が呼ばれるか
# ---------------------------------------------------------------------------

class TestUpdatePushCalled:
    def test_push_is_called(self, tmp_path, capsys):
        """update コマンド実行時に push_sessions が呼ばれる。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        push_called = []

        def mock_push(config, dry_run=False):
            push_called.append(True)
            return ["session-001", "session-002"]

        def mock_release_all(sync_repo_dir, machine_id):
            return []

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        assert len(push_called) == 1, "push_sessions が呼ばれていない"

    def test_push_result_shown_in_message(self, tmp_path, capsys):
        """push が成功した件数がメッセージに表示される。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        def mock_push(config, dry_run=False):
            return ["session-001", "session-002"]

        def mock_release_all(sync_repo_dir, machine_id):
            return []

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        captured = capsys.readouterr()
        assert "2件のセッションをプッシュしました" in captured.out, \
            f"push件数がメッセージに含まれていない: {captured.out}"


# ---------------------------------------------------------------------------
# テスト 2: release_all_locks が呼ばれるか
# ---------------------------------------------------------------------------

class TestUpdateReleaseAllLocksCalled:
    def test_release_all_locks_is_called(self, tmp_path, capsys):
        """update コマンド実行時に release_all_locks が呼ばれる。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        release_called = []

        def mock_push(config, dry_run=False):
            return []

        def mock_release_all(sync_repo_dir, machine_id):
            release_called.append((sync_repo_dir, machine_id))
            return ["session-001"]

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        assert len(release_called) == 1, "release_all_locks が呼ばれていない"
        # 正しい引数で呼ばれているか
        sync_repo_dir, machine_id = release_called[0]
        assert sync_repo_dir == cfg.sync_repo_dir
        assert machine_id == cfg.machine_id

    def test_lock_release_result_shown_in_message(self, tmp_path, capsys):
        """解放されたロック件数がメッセージに表示される。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        def mock_push(config, dry_run=False):
            return []

        def mock_release_all(sync_repo_dir, machine_id):
            return ["session-001", "session-002", "session-003"]

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        captured = capsys.readouterr()
        assert "3件" in captured.out, \
            f"ロック解放件数がメッセージに含まれていない: {captured.out}"
        assert "ロックを解放しました" in captured.out, \
            f"ロック解放メッセージが含まれていない: {captured.out}"


# ---------------------------------------------------------------------------
# テスト 3: push結果が0件の場合のメッセージ
# ---------------------------------------------------------------------------

class TestUpdateNoPush:
    def test_no_push_no_specific_push_message(self, tmp_path, capsys):
        """push が0件の場合はプッシュメッセージが表示されない。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        def mock_push(config, dry_run=False):
            return []

        def mock_release_all(sync_repo_dir, machine_id):
            return []

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        captured = capsys.readouterr()
        assert "セッションをプッシュしました" not in captured.out, \
            "0件なのにプッシュメッセージが表示された"

    def test_no_push_and_no_lock_shows_no_change_message(self, tmp_path, capsys):
        """push も lock解放も0件の場合は「変更はありませんでした」が表示される。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        def mock_push(config, dry_run=False):
            return []

        def mock_release_all(sync_repo_dir, machine_id):
            return []

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        captured = capsys.readouterr()
        assert "変更はありませんでした" in captured.out, \
            f"変更なしの場合のメッセージが表示されていない: {captured.out}"


# ---------------------------------------------------------------------------
# テスト 4: ロック解放結果が0件の場合のメッセージ
# ---------------------------------------------------------------------------

class TestUpdateNoLockRelease:
    def test_no_lock_release_no_specific_lock_message(self, tmp_path, capsys):
        """ロック解放が0件の場合はロック解放メッセージが表示されない。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        def mock_push(config, dry_run=False):
            return ["session-001"]

        def mock_release_all(sync_repo_dir, machine_id):
            return []

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        captured = capsys.readouterr()
        assert "ロックを解放しました" not in captured.out, \
            "0件なのにロック解放メッセージが表示された"

    def test_push_with_no_lock_shows_only_push_message(self, tmp_path, capsys):
        """push あり・lock解放なしの場合はプッシュメッセージのみ表示される。"""
        update = _import_update()
        cfg = _make_config(tmp_path)

        def mock_push(config, dry_run=False):
            return ["session-001"]

        def mock_release_all(sync_repo_dir, machine_id):
            return []

        args = _make_args()

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.release_all_locks", mock_release_all),
        ):
            update.run(args)

        captured = capsys.readouterr()
        assert "1件のセッションをプッシュしました" in captured.out
        assert "変更はありませんでした" not in captured.out
