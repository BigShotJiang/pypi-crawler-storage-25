"""
tests/test_resume.py

resume コマンドのテスト:
1. セッション一覧が正しく構築されるか（ローカル + リモート、重複排除）
2. ロック中のセッション表示に 🔒 が含まれるか
3. --latest で最新セッションが選択されるか
4. --from でマシンフィルタが効くか
5. Claude Code 終了後に push とロック解放が呼ばれるか
6. ロック中セッション選択時に警告が出るか
"""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _import_resume():
    from claude_session_sync.commands import resume
    return resume


def _make_config(tmp_path: Path):
    from claude_session_sync.config import Config
    cfg = Config()
    cfg.machine_id = "local-machine"
    cfg.claude_projects_dir = str(tmp_path / "claude_projects")
    cfg.claude_history_file = str(tmp_path / ".claude" / "history.jsonl")
    cfg.sync_repo_dir = str(tmp_path / "sync_repo")
    cfg.placeholders = {"{{HOME}}": str(tmp_path)}
    return cfg


def _make_args(
    session_id=None,
    latest=False,
    from_machine=None,
) -> argparse.Namespace:
    return argparse.Namespace(
        session_id=session_id,
        latest=latest,
        from_machine=from_machine,
    )


def _write_jsonl(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def _write_remote_session(
    sync_repo_dir: Path,
    project_dir: str,
    session_id: str,
    records: list[dict],
    machine_id: str | None = None,
) -> Path:
    """新形式（共有1コピー方式）でリモートセッションファイルを作成する。

    sessions/{project_dir}/{session_id}.jsonl に配置し、
    sessions/_paths.json も更新する。
    machine_id が指定された場合は session_meta/{session_id}.json も作成する。
    """
    session_file = sync_repo_dir / "sessions" / project_dir / f"{session_id}.jsonl"
    _write_jsonl(session_file, records)

    # sessions/_paths.json を更新（新形式マーカー）
    paths_json_path = sync_repo_dir / "sessions" / "_paths.json"
    paths_data: dict = {}
    if paths_json_path.is_file():
        with paths_json_path.open(encoding="utf-8") as _f:
            paths_data = json.load(_f)
    paths_data[project_dir] = project_dir
    paths_json_path.parent.mkdir(parents=True, exist_ok=True)
    with paths_json_path.open("w", encoding="utf-8") as _f:
        json.dump(paths_data, _f, ensure_ascii=False, indent=2)

    # machine_id が指定された場合は session_meta を作成
    if machine_id is not None:
        meta_dir = sync_repo_dir / "session_meta"
        meta_dir.mkdir(parents=True, exist_ok=True)
        meta = {
            "session_id": session_id,
            "last_editor": machine_id,
            "last_edited_at": "2026-01-01T00:00:00Z",
        }
        meta_file = meta_dir / f"{session_id}.json"
        meta_file.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    return session_file


def _make_session_record(cwd: str = "/home/user/project", message: str = "テストメッセージ") -> list[dict]:
    return [
        {"type": "system", "cwd": cwd},
        {
            "type": "user",
            "message": {
                "role": "user",
                "content": message,
            }
        }
    ]


# ---------------------------------------------------------------------------
# テスト 1: セッション一覧の構築（ローカル + リモート、重複排除）
# ---------------------------------------------------------------------------

class TestBuildSessionList:
    def test_local_sessions_included(self, tmp_path):
        """ローカルセッションが一覧に含まれる。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # ローカルセッションを作成
        session_id = "local-session-001"
        local_file = Path(cfg.claude_projects_dir) / "-home-user-project" / f"{session_id}.jsonl"
        _write_jsonl(local_file, _make_session_record(message="ローカルのメッセージ"))

        sessions = resume.build_session_list(cfg)

        session_ids = [s["session_id"] for s in sessions]
        assert session_id in session_ids, "ローカルセッションが含まれていない"

    def test_remote_sessions_included(self, tmp_path):
        """リモートセッションが一覧に含まれる。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # リモートセッションをsync_repo_dirに作成（新形式: machine_id なし）
        session_id = "remote-session-001"
        _write_remote_session(
            Path(cfg.sync_repo_dir),
            project_dir="-home-user-project",
            session_id=session_id,
            records=_make_session_record(message="リモートのメッセージ"),
            machine_id="remote-machine",
        )

        sessions = resume.build_session_list(cfg)

        session_ids = [s["session_id"] for s in sessions]
        assert session_id in session_ids, "リモートセッションが含まれていない"

    def test_deduplication_local_priority(self, tmp_path):
        """同一 session_id のローカルとリモートが重複した場合、ローカルが優先される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_id = "shared-session-001"

        # ローカルに作成
        local_file = Path(cfg.claude_projects_dir) / "-home-user-project" / f"{session_id}.jsonl"
        _write_jsonl(local_file, _make_session_record(message="ローカルのメッセージ"))

        # リモートにも同じ session_id で作成（新形式）
        _write_remote_session(
            Path(cfg.sync_repo_dir),
            project_dir="-home-user-project",
            session_id=session_id,
            records=_make_session_record(message="リモートのメッセージ"),
            machine_id="remote-machine",
        )

        sessions = resume.build_session_list(cfg)

        # session_id の重複なし
        matched = [s for s in sessions if s["session_id"] == session_id]
        assert len(matched) == 1, "重複セッションが含まれている"

        # ローカル版が優先される
        assert matched[0]["machine_id"] == cfg.machine_id, "ローカル版が優先されていない"

    def test_sorted_by_last_modified_desc(self, tmp_path):
        """セッション一覧が最終更新日時の降順でソートされる。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # 異なる mtime でセッションを作成
        older_file = Path(cfg.claude_projects_dir) / "-proj" / "older-session.jsonl"
        newer_file = Path(cfg.claude_projects_dir) / "-proj" / "newer-session.jsonl"
        _write_jsonl(older_file, _make_session_record(message="古いセッション"))
        _write_jsonl(newer_file, _make_session_record(message="新しいセッション"))

        # mtime を明示的に設定
        old_time = time.time() - 3600  # 1時間前
        new_time = time.time()
        os.utime(str(older_file), (old_time, old_time))
        os.utime(str(newer_file), (new_time, new_time))

        sessions = resume.build_session_list(cfg)

        assert len(sessions) >= 2
        # 新しい方が先頭
        session_ids = [s["session_id"] for s in sessions]
        newer_idx = session_ids.index("newer-session")
        older_idx = session_ids.index("older-session")
        assert newer_idx < older_idx, "新しいセッションが先頭にない"

    def test_machine_id_assigned_correctly(self, tmp_path):
        """ローカルセッションには自マシンID、リモートには session_meta の last_editor が付く。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        local_sid = "local-only-session"
        remote_sid = "remote-only-session"

        local_file = Path(cfg.claude_projects_dir) / "-proj" / f"{local_sid}.jsonl"
        _write_jsonl(local_file, _make_session_record())

        # 新形式: machine_id は session_meta から取得
        _write_remote_session(
            Path(cfg.sync_repo_dir),
            project_dir="-proj",
            session_id=remote_sid,
            records=_make_session_record(),
            machine_id="other-machine",
        )

        sessions = resume.build_session_list(cfg)
        sid_to_machine = {s["session_id"]: s["machine_id"] for s in sessions}

        assert sid_to_machine[local_sid] == cfg.machine_id
        assert sid_to_machine[remote_sid] == "other-machine"

    def test_last_editor_from_session_meta(self, tmp_path):
        """session_meta がある場合、last_editor が machine_id として設定される"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # リモートセッションを作成（新形式）、session_meta の last_editor = "editor-machine"
        session_id = "session-with-meta"
        _write_remote_session(
            Path(cfg.sync_repo_dir),
            project_dir="-proj",
            session_id=session_id,
            records=_make_session_record(message="メタデータ付きセッション"),
            machine_id="editor-machine",
        )

        sessions = resume.build_session_list(cfg)
        matched = [s for s in sessions if s["session_id"] == session_id]

        assert len(matched) == 1, "セッションが見つからない"
        # 新形式では machine_id が session_meta の last_editor から取得される
        assert matched[0]["machine_id"] == "editor-machine", (
            f"machine_id が期待値と異なる: {matched[0]['machine_id']}"
        )


# ---------------------------------------------------------------------------
# テスト 2: ロック中のセッション表示に 🔒 が含まれるか
# ---------------------------------------------------------------------------

class TestLockDisplay:
    def test_locked_session_shows_lock_mark(self, tmp_path, capsys):
        """ロック中のセッションの表示行に 🔒 が含まれる。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_id = "locked-session-001"
        sessions = [{
            "session_id": session_id,
            "machine_id": "other-machine",
            "project_path": "/home/user/project",
            "first_message": "テストメッセージ",
            "last_modified": time.time(),
            "file_path": "/fake/path.jsonl",
        }]

        lock_info_cache = {
            session_id: {
                "session_id": session_id,
                "machine_id": "other-machine",
                "locked_at": "2026-01-01T00:00:00Z",
                "expires_at": "2099-01-01T00:00:00Z",
            }
        }

        resume.print_session_list(sessions, cfg, lock_info_cache)

        captured = capsys.readouterr()
        assert "🔒" in captured.out, "ロック中セッションに 🔒 マークがない"

    def test_unlocked_session_no_lock_mark(self, tmp_path, capsys):
        """ロックされていないセッションの表示行に 🔒 がない。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_id = "unlocked-session-001"
        sessions = [{
            "session_id": session_id,
            "machine_id": cfg.machine_id,
            "project_path": "/home/user/project",
            "first_message": "テストメッセージ",
            "last_modified": time.time(),
            "file_path": "/fake/path.jsonl",
        }]

        lock_info_cache = {session_id: None}

        resume.print_session_list(sessions, cfg, lock_info_cache)

        captured = capsys.readouterr()
        assert "🔒" not in captured.out, "ロックなしセッションに 🔒 マークが表示された"

    def test_lock_mark_shows_locking_machine(self, tmp_path, capsys):
        """🔒 マークがロック中のセッション行の先頭に表示される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_id = "locked-session-002"
        locking_machine = "mac-workstation"
        sessions = [{
            "session_id": session_id,
            "machine_id": "some-machine",
            "project_path": "/home/user/project",
            "first_message": "テスト",
            "last_modified": time.time(),
            "file_path": "/fake/path.jsonl",
        }]

        lock_info_cache = {
            session_id: {
                "session_id": session_id,
                "machine_id": locking_machine,
                "locked_at": "2026-01-01T00:00:00Z",
                "expires_at": "2099-01-01T00:00:00Z",
            }
        }

        resume.print_session_list(sessions, cfg, lock_info_cache)

        captured = capsys.readouterr()
        # 🔒 マークが行の先頭付近（番号直後）に表示されることを確認
        assert "🔒" in captured.out, "🔒 マークが表示されていない"
        # 行の先頭付近に 🔒 が来ていることを確認（番号の直後）
        lines = [line for line in captured.out.splitlines() if "locked-s" in line]
        assert lines, "ロックセッションの行が見つからない"
        assert "🔒" in lines[0], "🔒 マークが行内にない"


# ---------------------------------------------------------------------------
# テスト 3: --latest で最新セッションが選択されるか
# ---------------------------------------------------------------------------

class TestLatestOption:
    def test_latest_selects_first_session(self, tmp_path):
        """--latest で最新（先頭）セッションが自動選択される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # 2つのセッションを作成（新旧）
        older_file = Path(cfg.claude_projects_dir) / "-proj" / "older-session.jsonl"
        newer_file = Path(cfg.claude_projects_dir) / "-proj" / "newer-session.jsonl"
        _write_jsonl(older_file, _make_session_record(message="古い"))
        _write_jsonl(newer_file, _make_session_record(message="新しい"))

        old_time = time.time() - 7200
        new_time = time.time()
        os.utime(str(older_file), (old_time, old_time))
        os.utime(str(newer_file), (new_time, new_time))

        args = _make_args(latest=True)
        selected_ids = []

        def mock_pull(config, dry_run=False, force=False):
            return []

        def mock_push(config, dry_run=False):
            return []

        def mock_acquire(sync_repo_dir, session_id, machine_id, ttl_minutes=10):
            selected_ids.append(session_id)
            return True

        def mock_release(sync_repo_dir, session_id, machine_id):
            return True

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", mock_pull),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.acquire_lock", mock_acquire),
            patch("claude_session_sync.session_lock.release_lock", mock_release),
            patch("claude_session_sync.session_lock.check_lock", return_value=None),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
        ):
            resume.run(args)

        assert len(selected_ids) == 1
        # 最新（新しい）セッションが選択される
        assert selected_ids[0] == "newer-session", \
            f"最新セッションが選択されていない: {selected_ids[0]}"


# ---------------------------------------------------------------------------
# テスト 4: --from でマシンフィルタが効くか
# ---------------------------------------------------------------------------

class TestFromMachineFilter:
    def test_from_filter_restricts_to_machine(self, tmp_path):
        """--from MACHINE_ID でそのマシンのセッションのみ返る（新形式: session_meta で machine_id 判定）。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # machine-a のセッション（新形式: session_meta に last_editor を記録）
        _write_remote_session(
            Path(cfg.sync_repo_dir),
            project_dir="-proj",
            session_id="session-a",
            records=_make_session_record(message="machine-aのメッセージ"),
            machine_id="machine-a",
        )

        # machine-b のセッション（新形式）
        _write_remote_session(
            Path(cfg.sync_repo_dir),
            project_dir="-proj",
            session_id="session-b",
            records=_make_session_record(message="machine-bのメッセージ"),
            machine_id="machine-b",
        )

        sessions = resume.build_session_list(cfg, from_machine="machine-a")

        machine_ids = [s["machine_id"] for s in sessions]
        assert all(m == "machine-a" for m in machine_ids), \
            f"machine-a 以外のセッションが含まれている: {machine_ids}"
        assert "machine-a" in machine_ids or len(sessions) == 0  # フィルタが効いている

    def test_from_filter_returns_empty_if_no_match(self, tmp_path):
        """--from で指定マシンのセッションがない場合は空リストを返す。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # machine-a のみ（新形式）
        _write_remote_session(
            Path(cfg.sync_repo_dir),
            project_dir="-proj",
            session_id="session-a",
            records=_make_session_record(),
            machine_id="machine-a",
        )

        sessions = resume.build_session_list(cfg, from_machine="nonexistent-machine")
        assert sessions == [], "存在しないマシンのセッションが返された"

    def test_from_filter_includes_local_when_machine_matches(self, tmp_path):
        """--from にローカルマシンIDを指定するとローカルセッションが含まれる。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # ローカルセッション
        local_file = Path(cfg.claude_projects_dir) / "-proj" / "local-session.jsonl"
        _write_jsonl(local_file, _make_session_record(message="ローカル"))

        sessions = resume.build_session_list(cfg, from_machine=cfg.machine_id)
        machine_ids = [s["machine_id"] for s in sessions]
        assert cfg.machine_id in machine_ids, "ローカルセッションが含まれていない"


# ---------------------------------------------------------------------------
# テスト 5: Claude Code 終了後に push とロック解放が呼ばれるか
# ---------------------------------------------------------------------------

class TestPostResumeCleanup:
    def test_push_called_after_claude_exits(self, tmp_path):
        """Claude Code 終了後に push_sessions が呼ばれる。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        # セッションを1つ作成
        session_file = Path(cfg.claude_projects_dir) / "-proj" / "test-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="テスト"))

        args = _make_args(latest=True)
        push_called = []

        def mock_pull(config, dry_run=False, force=False):
            return []

        def mock_push(config, dry_run=False, skip_pull=False):
            push_called.append(True)
            return []

        def mock_acquire(sync_repo_dir, session_id, machine_id, ttl_minutes=10):
            return True

        def mock_release(sync_repo_dir, session_id, machine_id):
            return True

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", mock_pull),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.acquire_lock", mock_acquire),
            patch("claude_session_sync.session_lock.release_lock", mock_release),
            patch("claude_session_sync.session_lock.check_lock", return_value=None),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
        ):
            resume.run(args)

        assert len(push_called) >= 1, "Claude Code 終了後に push が呼ばれていない"

    def test_lock_released_after_claude_exits(self, tmp_path):
        """Claude Code 終了後にロックが解放される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "test-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="テスト"))

        args = _make_args(latest=True)
        released_sessions = []

        def mock_pull(config, dry_run=False, force=False):
            return []

        def mock_push(config, dry_run=False):
            return []

        def mock_acquire(sync_repo_dir, session_id, machine_id, ttl_minutes=10):
            return True

        def mock_release(sync_repo_dir, session_id, machine_id):
            released_sessions.append(session_id)
            return True

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", mock_pull),
            patch("claude_session_sync.sync.push_sessions", mock_push),
            patch("claude_session_sync.session_lock.acquire_lock", mock_acquire),
            patch("claude_session_sync.session_lock.release_lock", mock_release),
            patch("claude_session_sync.session_lock.check_lock", return_value=None),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
        ):
            resume.run(args)

        assert len(released_sessions) >= 1, "Claude Code 終了後にロックが解放されていない"
        assert released_sessions[0] == "test-session", \
            f"期待したセッションIDが解放されていない: {released_sessions}"

    def test_daemon_stopped_after_claude_exits(self, tmp_path):
        """Claude Code 終了後に daemon が停止される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "test-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="テスト"))

        args = _make_args(latest=True)
        stop_called = []

        def mock_stop_daemon():
            stop_called.append(True)

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=None),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon", mock_stop_daemon),
        ):
            resume.run(args)

        assert len(stop_called) >= 1, "Claude Code 終了後に daemon が停止されていない"


# ---------------------------------------------------------------------------
# テスト 6: ロック中セッション選択時に警告が出るか
# ---------------------------------------------------------------------------

class TestLockedSessionWarning:
    def test_locked_session_warning_shown(self, tmp_path, capsys):
        """ロック中のセッションを --latest で選択した場合に警告が表示される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "locked-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="ロック中"))

        args = _make_args(latest=True)

        # 他マシンがロック中
        lock_info = {
            "session_id": "locked-session",
            "machine_id": "other-machine",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", return_value="y"),
        ):
            resume.run(args)

        captured = capsys.readouterr()
        assert "⚠" in captured.out or "作業中" in captured.out, \
            "ロック中セッション選択時に警告が表示されていない"

    def test_locked_session_cancel_on_no(self, tmp_path):
        """ロック中のセッションで [y/N] に N を入力するとキャンセルされる。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "locked-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="ロック中"))

        args = _make_args(latest=True)

        lock_info = {
            "session_id": "locked-session",
            "machine_id": "other-machine",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        subprocess_called = []

        def mock_subprocess_run(cmd, **kwargs):
            subprocess_called.append(cmd)
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", return_value="n"),
        ):
            with pytest.raises(SystemExit) as exc:
                resume.run(args)

        assert exc.value.code == 0, "N を入力した場合に正常終了していない"
        assert not subprocess_called, "キャンセル後に claude コマンドが実行された"

    def test_direct_session_id_with_lock_warning(self, tmp_path, capsys):
        """SESSION_ID 直接指定時もロック警告が出て、y で続行する。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_id = "direct-locked-session"
        session_file = Path(cfg.claude_projects_dir) / "-proj" / f"{session_id}.jsonl"
        _write_jsonl(session_file, _make_session_record(message="直接指定"))

        args = _make_args(session_id=session_id)

        lock_info = {
            "session_id": session_id,
            "machine_id": "other-machine",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        subprocess_called = []

        def mock_subprocess_run(cmd, **kwargs):
            subprocess_called.append(cmd)
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", return_value="y"),
            patch("claude_session_sync.git_ops.git_add"),
            patch("claude_session_sync.git_ops.git_commit"),
            patch("claude_session_sync.git_ops.git_push"),
        ):
            resume.run(args)

        captured = capsys.readouterr()
        assert "⚠" in captured.out or "作業中" in captured.out
        claude_calls = [c for c in subprocess_called if c[0] == "claude"]
        assert len(claude_calls) == 1, "claude コマンドが実行されなかった"


# ---------------------------------------------------------------------------
# テスト 7: --push-only オプション (daemon.py)
# ---------------------------------------------------------------------------

class TestDaemonPushOnly:
    def test_push_only_skips_pull(self, tmp_path):
        """--push-only モードで pull がスキップされ、push のみ呼ばれる。"""
        from claude_session_sync.commands import daemon
        from claude_session_sync.config import Config

        cfg = Config()
        cfg.machine_id = "test-machine"
        cfg.claude_projects_dir = str(tmp_path / "projects")
        cfg.claude_history_file = str(tmp_path / "history.jsonl")
        cfg.sync_repo_dir = str(tmp_path / "repo")
        cfg.placeholders = {}

        pull_called = []
        push_called = []

        def mock_pull(config, dry_run=False, force=False):
            pull_called.append(True)
            return []

        def mock_push(config, dry_run=False, skip_pull=False):
            push_called.append(True)
            return []

        args = argparse.Namespace(
            once=True,
            interval=300,
            quiet=True,
            stop=False,
            push_only=True,
        )

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", mock_pull),
            patch("claude_session_sync.sync.push_sessions", mock_push),
        ):
            daemon.run(args)

        assert len(pull_called) == 0, "--push-only で pull が呼ばれた"
        assert len(push_called) == 1, "--push-only で push が呼ばれていない"

    def test_normal_mode_calls_both_pull_and_push(self, tmp_path):
        """通常モード（push_only=False）では pull と push が両方呼ばれる。"""
        from claude_session_sync.commands import daemon
        from claude_session_sync.config import Config

        cfg = Config()
        cfg.machine_id = "test-machine"
        cfg.claude_projects_dir = str(tmp_path / "projects")
        cfg.claude_history_file = str(tmp_path / "history.jsonl")
        cfg.sync_repo_dir = str(tmp_path / "repo")
        cfg.placeholders = {}

        pull_called = []
        push_called = []

        def mock_pull(config, dry_run=False, force=False):
            pull_called.append(True)
            return []

        def mock_push(config, dry_run=False, skip_pull=False):
            push_called.append(True)
            return []

        args = argparse.Namespace(
            once=True,
            interval=300,
            quiet=True,
            stop=False,
            push_only=False,
        )

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", mock_pull),
            patch("claude_session_sync.sync.push_sessions", mock_push),
        ):
            daemon.run(args)

        assert len(pull_called) == 1, "通常モードで pull が呼ばれていない"
        assert len(push_called) == 1, "通常モードで push が呼ばれていない"


# ---------------------------------------------------------------------------
# テスト 8: helper 関数のユニットテスト
# ---------------------------------------------------------------------------

class TestHelpers:
    def test_relative_time_minutes(self):
        """数分前の相対時間表示。"""
        resume = _import_resume()
        ts = time.time() - 300  # 5分前
        result = resume._relative_time(ts)
        assert "分前" in result

    def test_relative_time_hours(self):
        """数時間前の相対時間表示。"""
        resume = _import_resume()
        ts = time.time() - 7200  # 2時間前
        result = resume._relative_time(ts)
        assert "時間前" in result

    def test_relative_time_days(self):
        """数日前の相対時間表示。"""
        resume = _import_resume()
        ts = time.time() - 86400 * 3  # 3日前
        result = resume._relative_time(ts)
        assert "日前" in result

    def test_shorten_path_replaces_home(self):
        """HOME パスの短縮動作を確認する。
        Unix: HOME を ~ に短縮する。
        Windows: フルパス（バックスラッシュ形式）をそのまま返す（意図的な動作）。
        """
        import sys
        resume = _import_resume()
        home = str(Path.home())
        input_path = f"{home}/projects/myapp"
        result = resume._shorten_path(input_path)

        if sys.platform == "win32":
            # Windows ではフルパスをそのまま返す（バックスラッシュ形式）
            expected = input_path.replace("/", "\\")
            assert result == expected, \
                f"Windows: フルパスが期待値と異なる: {result!r} != {expected!r}"
        else:
            assert result.startswith("~"), f"HOME が短縮されていない: {result}"

    def test_shorten_path_no_home(self):
        """HOME を含まないパスはそのまま返る。"""
        import sys
        resume = _import_resume()
        path = "/tmp/some/path"
        result = resume._shorten_path(path)

        if sys.platform == "win32":
            # Windows では Path() がバックスラッシュに変換する
            expected = path.replace("/", "\\")
            assert result == expected, \
                f"Windows: パス変換が期待値と異なる: {result!r} != {expected!r}"
        else:
            assert result == path

    def test_truncate_short_string(self):
        """短い文字列はそのまま返る。"""
        resume = _import_resume()
        result = resume._truncate("short", 40)
        assert result == "short"

    def test_truncate_long_string(self):
        """長い文字列は切り詰められ ... で終わる。"""
        resume = _import_resume()
        result = resume._truncate("a" * 50, 40)
        assert len(result) <= 40
        assert result.endswith("...")


# ---------------------------------------------------------------------------
# テスト 9: _extract_first_message と _extract_project_path のヘルパー関数テスト
# ---------------------------------------------------------------------------

class TestExtractHelpers:
    """_extract_first_message と _extract_project_path のテスト。"""

    def test_extract_first_message_from_string_content(self, tmp_path):
        records = [
            {"type": "system", "cwd": "/tmp"},
            {"type": "user", "message": {"role": "user", "content": "Hello world"}},
        ]
        f = tmp_path / "test.jsonl"
        f.write_text("\n".join(json.dumps(r) for r in records), encoding="utf-8")

        from claude_session_sync.commands.resume import _extract_first_message
        assert _extract_first_message(str(f)) == "Hello world"

    def test_extract_first_message_from_list_content(self, tmp_path):
        records = [
            {"type": "user", "message": {"role": "user", "content": [{"type": "text", "text": "Hello list"}]}},
        ]
        f = tmp_path / "test.jsonl"
        f.write_text(json.dumps(records[0]), encoding="utf-8")

        from claude_session_sync.commands.resume import _extract_first_message
        assert _extract_first_message(str(f)) == "Hello list"

    def test_extract_first_message_missing_file(self):
        from claude_session_sync.commands.resume import _extract_first_message
        assert _extract_first_message("/nonexistent/path.jsonl") == ""

    def test_extract_project_path(self, tmp_path):
        records = [
            {"type": "system", "cwd": "/home/alice/projects"},
        ]
        f = tmp_path / "test.jsonl"
        f.write_text(json.dumps(records[0]), encoding="utf-8")

        from claude_session_sync.commands.resume import _extract_project_path
        assert _extract_project_path(str(f)) == "/home/alice/projects"

    def test_extract_project_path_missing_file(self):
        from claude_session_sync.commands.resume import _extract_project_path
        assert _extract_project_path("/nonexistent/path.jsonl") == ""


# ---------------------------------------------------------------------------
# テスト 9: ロック中セッション選択時に改善されたメッセージが表示されるか
# ---------------------------------------------------------------------------

class TestImprovedLockWarningMessage:
    def test_improved_message_contains_situation_description(self, tmp_path, capsys):
        """ロック中セッション選択時に「考えられる状況」が含まれるメッセージが表示される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "locked-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="ロック中"))

        args = _make_args(latest=True)

        lock_info = {
            "session_id": "locked-session",
            "machine_id": "ubuntu-pc",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", return_value="y"),
            patch("claude_session_sync.commands.resume._force_takeover_lock"),
        ):
            resume.run(args)

        captured = capsys.readouterr()
        assert "考えられる状況" in captured.out, \
            f"改善されたメッセージ「考えられる状況」が含まれていない: {captured.out}"
        assert "ubuntu-pc" in captured.out, \
            f"ロック中マシン名が表示されていない: {captured.out}"

    def test_improved_message_shown_in_interactive_selection(self, tmp_path, capsys):
        """インタラクティブ選択でロック中セッションを選んだ場合も改善メッセージが出る。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "locked-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="ロック中"))

        args = _make_args()  # latest=False でインタラクティブ選択

        lock_info = {
            "session_id": "locked-session",
            "machine_id": "remote-pc",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        input_responses = iter(["1", "y"])

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", side_effect=input_responses),
            patch("claude_session_sync.commands.resume._force_takeover_lock"),
        ):
            resume.run(args)

        captured = capsys.readouterr()
        assert "考えられる状況" in captured.out, \
            f"インタラクティブ選択でも「考えられる状況」メッセージが出ていない: {captured.out}"


# ---------------------------------------------------------------------------
# テスト 10: y を選んだ後にロックが引き継がれるか
# ---------------------------------------------------------------------------

class TestLockTakeover:
    def test_lock_takeover_called_on_yes(self, tmp_path):
        """y を選んだ後に _force_takeover_lock が呼ばれる（--latest 経由）。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "locked-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="ロック中"))

        args = _make_args(latest=True)

        lock_info = {
            "session_id": "locked-session",
            "machine_id": "other-machine",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        takeover_calls = []

        def mock_takeover(sync_repo_dir, session_id, machine_id):
            takeover_calls.append((session_id, machine_id))

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", return_value="y"),
            patch("claude_session_sync.commands.resume._force_takeover_lock", mock_takeover),
        ):
            resume.run(args)

        assert len(takeover_calls) >= 1, "y を選んだ後に _force_takeover_lock が呼ばれていない"
        session_id, machine_id = takeover_calls[0]
        assert session_id == "locked-session"
        assert machine_id == cfg.machine_id

    def test_lock_takeover_message_shown(self, tmp_path, capsys):
        """y を選んだ後に「ロックを引き継ぎました」が表示される。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "locked-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="ロック中"))

        args = _make_args(latest=True)

        lock_info = {
            "session_id": "locked-session",
            "machine_id": "other-machine",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        def mock_subprocess_run(cmd, **kwargs):
            return MagicMock(returncode=0)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch("subprocess.run", mock_subprocess_run),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", return_value="y"),
            patch("claude_session_sync.commands.resume._force_takeover_lock"),
        ):
            resume.run(args)

        captured = capsys.readouterr()
        assert "ロックを引き継ぎました" in captured.out, \
            f"ロック引き継ぎメッセージが表示されていない: {captured.out}"

    def test_lock_not_taken_over_on_no(self, tmp_path):
        """N を選んだ場合は _force_takeover_lock が呼ばれない。"""
        resume = _import_resume()
        cfg = _make_config(tmp_path)

        session_file = Path(cfg.claude_projects_dir) / "-proj" / "locked-session.jsonl"
        _write_jsonl(session_file, _make_session_record(message="ロック中"))

        args = _make_args(latest=True)

        lock_info = {
            "session_id": "locked-session",
            "machine_id": "other-machine",
            "locked_at": "2026-01-01T00:00:00Z",
            "expires_at": "2099-01-01T00:00:00Z",
        }

        takeover_calls = []

        def mock_takeover(sync_repo_dir, session_id, machine_id):
            takeover_calls.append((session_id, machine_id))

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_lock", return_value=True),
            patch("claude_session_sync.session_lock.check_lock", return_value=lock_info),
            patch.object(resume, "_start_push_daemon", return_value=None),
            patch.object(resume, "_stop_push_daemon"),
            patch("builtins.input", return_value="n"),
            patch("claude_session_sync.commands.resume._force_takeover_lock", mock_takeover),
        ):
            with pytest.raises(SystemExit) as exc:
                resume.run(args)

        assert exc.value.code == 0
        assert len(takeover_calls) == 0, "N を選んだのに _force_takeover_lock が呼ばれた"
