"""Tests for claude_session_sync.session module."""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

import pytest

from claude_session_sync.session import discover_sessions, Session


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

FIXTURES_DIR = Path(__file__).parent / "fixtures"
MINIMAL_SESSION = FIXTURES_DIR / "minimal_session.jsonl"


def _make_session_file(project_dir: Path, session_id: str, content: str | None = None) -> Path:
    """Write a .jsonl session file into project_dir and return its path."""
    project_dir.mkdir(parents=True, exist_ok=True)
    dest = project_dir / f"{session_id}.jsonl"
    if content is None:
        shutil.copy2(MINIMAL_SESSION, dest)
    else:
        dest.write_text(content, encoding="utf-8")
    return dest


# ---------------------------------------------------------------------------
# discover_sessions tests
# ---------------------------------------------------------------------------


class TestDiscoverSessions:
    def test_empty_directory_returns_empty_list(self, tmp_path):
        """空のディレクトリ → 空リスト"""
        result = discover_sessions(str(tmp_path))
        assert result == []

    def test_single_jsonl_file_returns_one_session(self, tmp_path):
        """1つの .jsonl ファイルがある → Session オブジェクト1つ"""
        project_dir = tmp_path / "-home-user-projects"
        _make_session_file(project_dir, "session-abc123")

        result = discover_sessions(str(tmp_path))

        assert len(result) == 1
        assert isinstance(result[0], Session)

    def test_multiple_project_dirs_are_all_discovered(self, tmp_path):
        """複数プロジェクトディレクトリにセッションがある場合 → 全て検出"""
        project_a = tmp_path / "-home-user-project-a"
        project_b = tmp_path / "-home-user-project-b"

        _make_session_file(project_a, "session-111")
        _make_session_file(project_a, "session-222")
        _make_session_file(project_b, "session-333")

        result = discover_sessions(str(tmp_path))

        assert len(result) == 3
        ids = {s.session_id for s in result}
        assert ids == {"session-111", "session-222", "session-333"}

    def test_non_jsonl_files_are_ignored(self, tmp_path):
        """.jsonl 以外のファイルは無視される"""
        project_dir = tmp_path / "-home-user-projects"
        project_dir.mkdir(parents=True)

        # 無視されるべきファイル
        (project_dir / "README.md").write_text("hello", encoding="utf-8")
        (project_dir / "data.json").write_text("{}", encoding="utf-8")
        (project_dir / "notes.txt").write_text("notes", encoding="utf-8")

        # 検出されるべきファイル
        _make_session_file(project_dir, "session-valid")

        result = discover_sessions(str(tmp_path))

        assert len(result) == 1
        assert result[0].session_id == "session-valid"

    def test_session_fields_are_populated_correctly(self, tmp_path):
        """Session のフィールドが正しく埋まっている"""
        project_dir_name = "-home-testuser-myproject"
        project_dir = tmp_path / project_dir_name
        session_id = "test-session-id-xyz"
        _make_session_file(project_dir, session_id)

        result = discover_sessions(str(tmp_path))

        assert len(result) == 1
        s = result[0]

        # session_id はファイル名のステム
        assert s.session_id == session_id

        # project_dir はディレクトリ名
        assert s.project_dir == project_dir_name

        # project_path は minimal_session.jsonl の cwd フィールドから
        # minimal_session.jsonl の1行目には cwd があるはず
        assert isinstance(s.project_path, str)

        # first_message は文字列 (空でも可)
        assert isinstance(s.first_message, str)

        # file_path は .jsonl ファイルの絶対パス
        assert s.file_path.endswith(f"{session_id}.jsonl")

        # last_modified と size は数値
        assert s.last_modified > 0
        assert s.size > 0

    def test_session_project_path_extracted_from_cwd(self, tmp_path):
        """cwd フィールドから project_path が正しく抽出される"""
        project_dir = tmp_path / "-home-alice-code"
        project_dir.mkdir(parents=True)

        expected_cwd = "/home/alice/code"
        session_file = project_dir / "my-session.jsonl"
        # cwd を含む最小限の JSONL
        record = {"type": "system", "cwd": expected_cwd, "sessionId": "my-session"}
        session_file.write_text(json.dumps(record) + "\n", encoding="utf-8")

        result = discover_sessions(str(tmp_path))

        assert len(result) == 1
        assert result[0].project_path == expected_cwd

    def test_first_message_extracted_from_user_entry(self, tmp_path):
        """type=user エントリから first_message が抽出される"""
        project_dir = tmp_path / "-home-bob-work"
        project_dir.mkdir(parents=True)

        session_file = project_dir / "s1.jsonl"
        lines = [
            json.dumps({"type": "system", "cwd": "/home/bob/work"}),
            json.dumps({
                "type": "user",
                "message": {"role": "user", "content": "Hello, Claude!"},
            }),
        ]
        session_file.write_text("\n".join(lines) + "\n", encoding="utf-8")

        result = discover_sessions(str(tmp_path))

        assert len(result) == 1
        assert result[0].first_message == "Hello, Claude!"

    def test_results_sorted_newest_first(self, tmp_path):
        """最終更新時刻の新しい順にソートされる"""
        import time

        project_dir = tmp_path / "-home-user-proj"
        project_dir.mkdir(parents=True)

        s1 = _make_session_file(project_dir, "old-session")
        s2 = _make_session_file(project_dir, "new-session")

        # os.utime で明示的に mtime を設定して確実に差をつける
        now = time.time()
        os.utime(str(s1), (now - 100, now - 100))  # old-session は 100 秒前
        os.utime(str(s2), (now, now))               # new-session は現在

        result = discover_sessions(str(tmp_path))

        assert len(result) == 2
        assert result[0].session_id == "new-session"
        assert result[1].session_id == "old-session"
