"""Tests for claude_session_sync.config_sync module.

Tests cover push_shared_config and pull_shared_config — the functions that
sync CLAUDE.md and per-project memory files between local and shared_config/
in the sync repository.

New "shared memory" architecture:
  shared_config/memory/{placeholder_project_dir}/files...
  shared_config/memory/_paths.json
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from claude_session_sync.config import Config
from claude_session_sync.config_sync import push_shared_config, pull_shared_config
from claude_session_sync.path_mapper import PathMapper


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_config(tmp_path: Path, machine_id: str = "test-linux") -> Config:
    cfg = Config()
    cfg.machine_id = machine_id
    cfg.claude_projects_dir = str(tmp_path / "claude_projects")
    cfg.sync_repo_dir = str(tmp_path / "sync_repo")
    cfg.placeholders = {"{{PROJECTS}}": "/home/alice/projects"}
    cfg.sync_directories = ["/home/alice/projects"]
    return cfg


def make_mapper(cfg: Config) -> PathMapper:
    return PathMapper(cfg.placeholders)


def _project_dir_name(path: str) -> str:
    """Convert an absolute path to a Claude project directory name."""
    return PathMapper.path_to_project_dir(path)


def _setup_shared_memory(
    tmp_path: Path,
    cfg: Config,
    placeholder_project_dir: str,
    files: dict[str, str],
    paths_json: dict[str, str] | None = None,
) -> None:
    """shared_config/memory/ 配下にメモリファイルと _paths.json を作成する。

    Args:
        tmp_path: テスト用一時ディレクトリ（未使用、シグネチャの一貫性のため保持）
        cfg: テスト用設定
        placeholder_project_dir: shared_config/memory/ 配下のディレクトリ名
        files: {ファイル名: 内容} の辞書（サブパスも可: "docs/file.md"）
        paths_json: _paths.json に書き込む {placeholder_project_dir: placeholder_path}
                    None の場合 _paths.json を作成しない（旧形式互換テスト用）
    """
    memory_base = (
        Path(cfg.sync_repo_dir)
        / "shared_config"
        / "memory"
    )
    file_dir = memory_base / placeholder_project_dir
    file_dir.mkdir(parents=True, exist_ok=True)
    for fname, content in files.items():
        dest = file_dir / fname
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")

    if paths_json is not None:
        existing: dict[str, str] = {}
        paths_file = memory_base / "_paths.json"
        if paths_file.is_file():
            with paths_file.open(encoding="utf-8") as f:
                existing = json.load(f)
        existing.update(paths_json)
        with paths_file.open("w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
            f.write("\n")


# ---------------------------------------------------------------------------
# TestPushSharedConfig
# ---------------------------------------------------------------------------


class TestPushSharedConfig:
    def test_claude_md_is_copied(self, tmp_path: Path, monkeypatch) -> None:
        """CLAUDE.md が shared_config/ にコピーされる。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        # ローカルの CLAUDE.md を用意
        claude_dir = tmp_path / "fake_home" / ".claude"
        claude_dir.mkdir(parents=True)
        (claude_dir / "CLAUDE.md").write_text("# Global config\n", encoding="utf-8")

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        result = push_shared_config(cfg, mapper)

        dest = Path(cfg.sync_repo_dir) / "shared_config" / "CLAUDE.md"
        assert dest.is_file(), "CLAUDE.md が shared_config/ にコピーされていない"
        assert dest.read_text(encoding="utf-8") == "# Global config\n"
        assert any("CLAUDE.md" in r for r in result)

    def test_memory_files_are_copied_with_placeholder_dir(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """メモリファイルが shared_config/memory/{placeholder_project_dir}/ に直接コピーされる（machine_id なし）。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        # ローカルのメモリファイルを配置
        project_dir = _project_dir_name("/home/alice/projects")
        memory_dir = Path(cfg.claude_projects_dir) / project_dir / "memory"
        memory_dir.mkdir(parents=True)
        (memory_dir / "MEMORY.md").write_text("# Memory Index\n", encoding="utf-8")
        (memory_dir / "user_profile.md").write_text("name: alice\n", encoding="utf-8")

        result = push_shared_config(cfg, mapper)

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

        # machine_id ディレクトリを挟まず直接 memory/{placeholder_project_dir}/
        dest_base = (
            Path(cfg.sync_repo_dir)
            / "shared_config"
            / "memory"
            / placeholder_project_dir
        )
        assert (dest_base / "MEMORY.md").is_file(), "MEMORY.md がコピーされていない"
        assert (dest_base / "user_profile.md").is_file(), "user_profile.md がコピーされていない"
        assert (dest_base / "MEMORY.md").read_text(encoding="utf-8") == "# Memory Index\n"

        # machine_id ディレクトリが作られていないことを確認
        machine_dir = Path(cfg.sync_repo_dir) / "shared_config" / "memory" / cfg.machine_id
        assert not machine_dir.is_dir(), "machine_id ディレクトリが作成されてしまっている"

    def test_subdirectory_copied_recursively(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """memory/docs/ 配下のファイルも再帰的にコピーされる。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        project_dir = _project_dir_name("/home/alice/projects")
        memory_dir = Path(cfg.claude_projects_dir) / project_dir / "memory"
        docs_dir = memory_dir / "docs"
        docs_dir.mkdir(parents=True)
        (memory_dir / "MEMORY.md").write_text("# Root\n", encoding="utf-8")
        (docs_dir / "design.md").write_text("# Design doc\n", encoding="utf-8")
        (docs_dir / "api.md").write_text("# API doc\n", encoding="utf-8")

        push_shared_config(cfg, mapper)

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)
        dest_base = (
            Path(cfg.sync_repo_dir)
            / "shared_config"
            / "memory"
            / placeholder_project_dir
        )

        assert (dest_base / "MEMORY.md").is_file(), "ルートのファイルがコピーされていない"
        assert (dest_base / "docs" / "design.md").is_file(), "docs/design.md がコピーされていない"
        assert (dest_base / "docs" / "api.md").is_file(), "docs/api.md がコピーされていない"
        assert (dest_base / "docs" / "design.md").read_text(encoding="utf-8") == "# Design doc\n"

    def test_paths_json_is_created(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """_paths.json が正しく作成される（manifest ではなく _paths.json）。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        project_dir = _project_dir_name("/home/alice/projects")
        memory_dir = Path(cfg.claude_projects_dir) / project_dir / "memory"
        memory_dir.mkdir(parents=True)
        (memory_dir / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")

        push_shared_config(cfg, mapper)

        paths_json_path = (
            Path(cfg.sync_repo_dir)
            / "shared_config"
            / "memory"
            / "_paths.json"
        )
        assert paths_json_path.is_file(), "_paths.json が作成されていない"

        with paths_json_path.open(encoding="utf-8") as f:
            paths_data = json.load(f)

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

        assert placeholder_project_dir in paths_data, (
            f"_paths.json にキー {placeholder_project_dir!r} が存在しない"
        )
        assert paths_data[placeholder_project_dir] == placeholder_path

        # _manifest.json は作成されていないことを確認
        manifest_path = (
            Path(cfg.sync_repo_dir)
            / "shared_config"
            / "memory"
            / "_manifest.json"
        )
        assert not manifest_path.is_file(), "_manifest.json が作成されてしまっている（旧形式）"

    def test_sync_directories_filter(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """sync_directories 外のプロジェクトはスキップされる。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        cfg.sync_directories = ["/home/alice/projects"]
        mapper = make_mapper(cfg)

        # 対象内: /home/alice/projects
        in_dir = _project_dir_name("/home/alice/projects")
        mem_in = Path(cfg.claude_projects_dir) / in_dir / "memory"
        mem_in.mkdir(parents=True)
        (mem_in / "MEMORY.md").write_text("# In\n", encoding="utf-8")

        # 対象外: /home/alice
        out_dir = _project_dir_name("/home/alice")
        mem_out = Path(cfg.claude_projects_dir) / out_dir / "memory"
        mem_out.mkdir(parents=True)
        (mem_out / "MEMORY.md").write_text("# Out\n", encoding="utf-8")

        push_shared_config(cfg, mapper)

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

        dest_in = (
            Path(cfg.sync_repo_dir)
            / "shared_config"
            / "memory"
            / placeholder_project_dir
            / "MEMORY.md"
        )
        assert dest_in.is_file(), "対象内のメモリがコピーされていない"

        # 対象外はコピーされない
        out_placeholder_path = mapper.to_placeholder("/home/alice")
        out_placeholder = PathMapper.path_to_project_dir(out_placeholder_path)
        dest_out = (
            Path(cfg.sync_repo_dir)
            / "shared_config"
            / "memory"
            / out_placeholder
            / "MEMORY.md"
        )
        assert not dest_out.is_file(), "対象外のメモリがコピーされてしまっている"

    def test_returns_relative_paths(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """返り値が sync_repo_dir からの相対パスリスト。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        claude_dir = tmp_path / "fake_home" / ".claude"
        claude_dir.mkdir(parents=True)
        (claude_dir / "CLAUDE.md").write_text("# CLAUDE\n", encoding="utf-8")

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        project_dir = _project_dir_name("/home/alice/projects")
        memory_dir = Path(cfg.claude_projects_dir) / project_dir / "memory"
        memory_dir.mkdir(parents=True)
        (memory_dir / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")

        result = push_shared_config(cfg, mapper)

        assert len(result) > 0, "返り値が空"
        for rel in result:
            assert not os.path.isabs(rel), f"絶対パスが含まれている: {rel!r}"
            assert cfg.sync_repo_dir not in rel, f"sync_repo_dir が含まれている: {rel!r}"

        # shared_config/CLAUDE.md が含まれている
        assert any("CLAUDE.md" in r for r in result)
        # _paths.json が含まれている（_manifest.json ではない）
        assert any("_paths.json" in r for r in result)
        assert not any("_manifest.json" in r for r in result), "_manifest.json が含まれてしまっている"

    def test_push_replaces_old_files(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """push 時に古いファイルが削除されて新しいファイルで置換される（ローカルで削除したファイルがリモートにも反映される）。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        project_dir = _project_dir_name("/home/alice/projects")
        memory_dir = Path(cfg.claude_projects_dir) / project_dir / "memory"
        memory_dir.mkdir(parents=True)

        # 1回目 push: 2つのファイルをコピー
        (memory_dir / "MEMORY.md").write_text("# Memory\n", encoding="utf-8")
        (memory_dir / "old_notes.md").write_text("# Old notes\n", encoding="utf-8")
        push_shared_config(cfg, mapper)

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)
        dest_base = (
            Path(cfg.sync_repo_dir)
            / "shared_config"
            / "memory"
            / placeholder_project_dir
        )
        assert (dest_base / "old_notes.md").is_file(), "1回目 push でファイルが存在するはず"

        # ローカルで old_notes.md を削除
        (memory_dir / "old_notes.md").unlink()
        (memory_dir / "new_notes.md").write_text("# New notes\n", encoding="utf-8")

        # 2回目 push: 古いファイルが消えて新しいファイルで置換される
        push_shared_config(cfg, mapper)

        assert not (dest_base / "old_notes.md").is_file(), (
            "ローカルで削除したファイルがリモートにまだ残っている"
        )
        assert (dest_base / "new_notes.md").is_file(), "新しいファイルがリモートにコピーされていない"
        assert (dest_base / "MEMORY.md").is_file(), "既存ファイルが消えてしまっている"


# ---------------------------------------------------------------------------
# TestPullSharedConfig
# ---------------------------------------------------------------------------


class TestPullSharedConfig:
    def test_claude_md_is_restored(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """CLAUDE.md がローカルに復元される。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        # shared_config に CLAUDE.md を用意
        shared_config = Path(cfg.sync_repo_dir) / "shared_config"
        shared_config.mkdir(parents=True)
        (shared_config / "CLAUDE.md").write_text("# Synced config\n", encoding="utf-8")

        result = pull_shared_config(cfg, mapper)

        dest = tmp_path / "fake_home" / ".claude" / "CLAUDE.md"
        assert dest.is_file(), "CLAUDE.md がローカルに復元されていない"
        assert dest.read_text(encoding="utf-8") == "# Synced config\n"
        assert result >= 1

    def test_memory_files_are_restored(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """メモリファイルがローカルの正しいパスに配置される。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

        _setup_shared_memory(
            tmp_path, cfg,
            placeholder_project_dir=placeholder_project_dir,
            files={
                "MEMORY.md": "# Memory Index\n",
                "user_profile.md": "name: alice\n",
            },
            paths_json={placeholder_project_dir: placeholder_path},
        )

        result = pull_shared_config(cfg, mapper)

        local_project_dir = PathMapper.path_to_project_dir("/home/alice/projects")
        dest_base = Path(cfg.claude_projects_dir) / local_project_dir / "memory"

        assert (dest_base / "MEMORY.md").is_file(), "MEMORY.md がローカルに復元されていない"
        assert (dest_base / "user_profile.md").is_file(), "user_profile.md がローカルに復元されていない"
        assert (dest_base / "MEMORY.md").read_text(encoding="utf-8") == "# Memory Index\n"
        assert result >= 2

    def test_subdirectory_restored_recursively(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """docs/ 配下も再帰的に復元される。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

        _setup_shared_memory(
            tmp_path, cfg,
            placeholder_project_dir=placeholder_project_dir,
            files={
                "MEMORY.md": "# Root\n",
                "docs/design.md": "# Design doc\n",
                "docs/api.md": "# API doc\n",
            },
            paths_json={placeholder_project_dir: placeholder_path},
        )

        pull_shared_config(cfg, mapper)

        local_project_dir = PathMapper.path_to_project_dir("/home/alice/projects")
        dest_base = Path(cfg.claude_projects_dir) / local_project_dir / "memory"

        assert (dest_base / "MEMORY.md").is_file(), "ルートファイルが復元されていない"
        assert (dest_base / "docs" / "design.md").is_file(), "docs/design.md が復元されていない"
        assert (dest_base / "docs" / "api.md").is_file(), "docs/api.md が復元されていない"
        assert (dest_base / "docs" / "design.md").read_text(encoding="utf-8") == "# Design doc\n"

    def test_local_memory_replaced_entirely(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """ローカルにあった古いファイルが消えて、リモートの内容で完全置換される（ローカルに余分なファイルがあっても消える）。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        local_project_dir = PathMapper.path_to_project_dir("/home/alice/projects")
        local_mem_dir = Path(cfg.claude_projects_dir) / local_project_dir / "memory"
        local_mem_dir.mkdir(parents=True)

        # ローカルに余分なファイルを作成
        (local_mem_dir / "stale_file.md").write_text("# Should be removed\n", encoding="utf-8")
        (local_mem_dir / "another_old.md").write_text("# Also old\n", encoding="utf-8")

        placeholder_path = mapper.to_placeholder("/home/alice/projects")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

        # リモートには別のファイルだけ存在
        _setup_shared_memory(
            tmp_path, cfg,
            placeholder_project_dir=placeholder_project_dir,
            files={"MEMORY.md": "# New remote\n"},
            paths_json={placeholder_project_dir: placeholder_path},
        )

        pull_shared_config(cfg, mapper)

        # リモートのファイルが配置されている
        assert (local_mem_dir / "MEMORY.md").is_file(), "リモートのファイルが配置されていない"
        assert (local_mem_dir / "MEMORY.md").read_text(encoding="utf-8") == "# New remote\n"

        # ローカルの余分なファイルが削除されている
        assert not (local_mem_dir / "stale_file.md").is_file(), (
            "ローカルの余分ファイル stale_file.md が削除されていない"
        )
        assert not (local_mem_dir / "another_old.md").is_file(), (
            "ローカルの余分ファイル another_old.md が削除されていない"
        )

    def test_placeholder_dir_conversion(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """プレースホルダがローカルパスに正しく変換される。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        # リモートのプレースホルダ化ディレクトリ
        placeholder_path = "{{PROJECTS}}"
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)

        _setup_shared_memory(
            tmp_path, cfg,
            placeholder_project_dir=placeholder_project_dir,
            files={"MEMORY.md": "# Memory from remote\n"},
            paths_json={placeholder_project_dir: placeholder_path},
        )

        pull_shared_config(cfg, mapper)

        # {{PROJECTS}} -> /home/alice/projects
        local_project_dir = PathMapper.path_to_project_dir("/home/alice/projects")
        dest = (
            Path(cfg.claude_projects_dir)
            / local_project_dir
            / "memory"
            / "MEMORY.md"
        )
        assert dest.is_file(), (
            f"プレースホルダが正しくローカルパスに変換されていない: "
            f"期待={dest}, 存在={dest.is_file()}"
        )
        assert dest.read_text(encoding="utf-8") == "# Memory from remote\n"

    def test_no_paths_json_skips_gracefully(
        self, tmp_path: Path, monkeypatch
    ) -> None:
        """_paths.json がない場合はスキップ（旧形式互換）。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        cfg = make_config(tmp_path)
        mapper = make_mapper(cfg)

        # shared_config/memory/ を作成するが _paths.json は置かない
        memory_base = Path(cfg.sync_repo_dir) / "shared_config" / "memory"
        memory_base.mkdir(parents=True, exist_ok=True)

        # CLAUDE.md のみ用意（カウントのため）
        shared_config = Path(cfg.sync_repo_dir) / "shared_config"
        (shared_config / "CLAUDE.md").write_text("# Config\n", encoding="utf-8")

        # _paths.json がなくてもエラーにならず終了する
        result = pull_shared_config(cfg, mapper)

        # CLAUDE.md はコピーされる（memory スキップは CLAUDE.md には影響しない）
        dest = tmp_path / "fake_home" / ".claude" / "CLAUDE.md"
        assert dest.is_file(), "CLAUDE.md が復元されていない"

        # メモリファイルはコピーされない（_paths.json がないのでスキップ）
        local_project_dir = PathMapper.path_to_project_dir("/home/alice/projects")
        mem_dir = Path(cfg.claude_projects_dir) / local_project_dir / "memory"
        assert not mem_dir.is_dir() or not any(mem_dir.iterdir()), (
            "_paths.json がないのにメモリファイルがコピーされてしまっている"
        )

    def test_push_pull_roundtrip(self, tmp_path, monkeypatch) -> None:
        """マシンA で push → マシンB で pull → 正しく配置される。"""
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "fake_home"))

        # マシンA: push
        cfg_a = make_config(tmp_path, machine_id="linux-pc")
        mapper_a = PathMapper({"{{PROJECTS}}": "/home/alice/projects"})

        project_dir_a = _project_dir_name("/home/alice/projects")
        memory_dir_a = Path(cfg_a.claude_projects_dir) / project_dir_a / "memory"
        memory_dir_a.mkdir(parents=True)
        (memory_dir_a / "user_profile.md").write_text("# Alice on Linux\n", encoding="utf-8")
        (memory_dir_a / "docs" / "notes.md").parent.mkdir(parents=True, exist_ok=True)
        (memory_dir_a / "docs" / "notes.md").write_text("# Notes\n", encoding="utf-8")

        push_shared_config(cfg_a, mapper_a)

        # マシンB: pull（異なるplaceholder値）
        cfg_b = make_config(tmp_path, machine_id="mac-mini")
        cfg_b.placeholders = {"{{PROJECTS}}": "/Users/bob/projects"}
        cfg_b.sync_directories = ["/Users/bob/projects"]
        mapper_b = PathMapper({"{{PROJECTS}}": "/Users/bob/projects"})

        result = pull_shared_config(cfg_b, mapper_b)
        assert result >= 1

        # マシンBのローカルディレクトリに配置されているか
        local_project_dir_b = PathMapper.path_to_project_dir("/Users/bob/projects")
        dest_base = Path(cfg_b.claude_projects_dir) / local_project_dir_b / "memory"

        assert (dest_base / "user_profile.md").is_file(), "user_profile.md が配置されていない"
        assert (dest_base / "user_profile.md").read_text(encoding="utf-8") == "# Alice on Linux\n"
        assert (dest_base / "docs" / "notes.md").is_file(), "docs/notes.md が配置されていない"
        assert (dest_base / "docs" / "notes.md").read_text(encoding="utf-8") == "# Notes\n"
