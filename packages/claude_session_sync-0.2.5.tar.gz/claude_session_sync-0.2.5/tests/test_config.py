"""Comprehensive tests for claude_session_sync.config.Config."""
from __future__ import annotations

import json
import platform
from pathlib import Path

import pytest

import claude_session_sync.config as config_module
from claude_session_sync.config import Config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _patch_config_paths(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> tuple[Path, Path]:
    """Redirect CONFIG_DIR and CONFIG_FILE to a temporary directory."""
    config_dir = tmp_path / ".claude-session-sync"
    config_file = config_dir / "config.json"
    monkeypatch.setattr(config_module, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)
    return config_dir, config_file


# ---------------------------------------------------------------------------
# save / load round-trip
# ---------------------------------------------------------------------------

class TestRoundTrip:
    def test_all_fields_preserved(self, monkeypatch, tmp_path):
        """Config → save → load → all fields match."""
        _patch_config_paths(monkeypatch, tmp_path)

        original = Config(
            machine_id="my-machine",
            github_owner="octocat",
            github_repo="my-sessions",
            github_remote_url="git@github.com:octocat/my-sessions.git",
            sync_repo_dir="/tmp/sync-repo",
            claude_projects_dir="/tmp/claude/projects",
            claude_history_file="/tmp/claude/history.jsonl",
            placeholders={"{{HOME}}": "/home/octocat"},
            last_push_at="2026-03-23T12:00:00Z",
            last_pull_at="2026-03-22T08:30:00Z",
        )
        original.save()

        loaded = Config.load()

        assert loaded.machine_id == original.machine_id
        assert loaded.github_owner == original.github_owner
        assert loaded.github_repo == original.github_repo
        assert loaded.github_remote_url == original.github_remote_url
        assert loaded.sync_repo_dir == original.sync_repo_dir
        assert loaded.claude_projects_dir == original.claude_projects_dir
        assert loaded.claude_history_file == original.claude_history_file
        assert loaded.placeholders == original.placeholders
        assert loaded.last_push_at == original.last_push_at
        assert loaded.last_pull_at == original.last_pull_at

    def test_japanese_machine_id(self, monkeypatch, tmp_path):
        """machine_id containing Japanese characters survives the round-trip."""
        _patch_config_paths(monkeypatch, tmp_path)

        original = Config(machine_id="東京ラップトップ")
        original.save()

        loaded = Config.load()
        assert loaded.machine_id == "東京ラップトップ"

    def test_last_push_at_none(self, monkeypatch, tmp_path):
        """A Config with last_push_at=None round-trips correctly."""
        _patch_config_paths(monkeypatch, tmp_path)

        original = Config(
            machine_id="no-push-yet",
            last_push_at=None,
            last_pull_at=None,
        )
        original.save()

        loaded = Config.load()
        assert loaded.last_push_at is None
        assert loaded.last_pull_at is None


# ---------------------------------------------------------------------------
# exists
# ---------------------------------------------------------------------------

class TestExists:
    def test_returns_false_when_file_missing(self, monkeypatch, tmp_path):
        """exists() returns False when config.json does not exist."""
        _patch_config_paths(monkeypatch, tmp_path)
        assert Config.exists() is False

    def test_returns_true_when_file_present(self, monkeypatch, tmp_path):
        """exists() returns True after saving a config."""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        config_dir.mkdir(parents=True, exist_ok=True)
        config_file.write_text("{}", encoding="utf-8")

        assert Config.exists() is True


# ---------------------------------------------------------------------------
# detect_placeholders
# ---------------------------------------------------------------------------

class TestDetectPlaceholders:
    def test_returns_dict(self):
        """detect_placeholders() returns a dict."""
        result = Config.detect_placeholders()
        assert isinstance(result, dict)

    def test_home_key_not_auto_detected_on_linux(self, monkeypatch):
        """On Linux, {{HOME}} is no longer auto-detected (use fallback_placeholders instead)."""
        monkeypatch.setattr(platform, "system", lambda: "Linux")
        result = Config.detect_placeholders()
        # {{HOME}} is intentionally removed from auto-detection to avoid sharing
        # home-directory sessions. Use fallback_placeholders() for backward compat.
        assert "{{HOME}}" not in result

    def test_fallback_placeholders_contains_home(self, monkeypatch):
        """fallback_placeholders() provides {{HOME}} for backward compatibility."""
        monkeypatch.setattr(platform, "system", lambda: "Linux")
        result = Config.fallback_placeholders()
        assert "{{HOME}}" in result
        assert result["{{HOME}}"] == str(Path.home())


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_corrupted_json_raises(self, monkeypatch, tmp_path):
        """Loading a config.json with invalid JSON raises json.JSONDecodeError."""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)
        config_dir.mkdir(parents=True, exist_ok=True)
        config_file.write_text("{ NOT VALID JSON !!!", encoding="utf-8")

        with pytest.raises(json.JSONDecodeError):
            Config.load()

    def test_save_creates_directory_automatically(self, monkeypatch, tmp_path):
        """save() creates the config directory if it does not yet exist."""
        config_dir, config_file = _patch_config_paths(monkeypatch, tmp_path)

        # Ensure the directory does NOT exist before saving.
        assert not config_dir.exists()

        cfg = Config(machine_id="auto-mkdir")
        cfg.save()

        assert config_dir.exists()
        assert config_file.exists()
