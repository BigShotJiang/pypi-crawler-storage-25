{
  description = "Log utils for observes packages";

  inputs = {
    observes_flake_builder = {
      url = "git+ssh://git@gitlab.com/fluidattacks/universe?shallow=1&rev=ad927cc6545df64a7d622696a43bcee225b9867b&dir=observes/common/std_flake_2";
    };
  };

  outputs =
    { self, ... }@inputs:
    let
      build_args =
        {
          system,
          python_version,
          nixpkgs,
          builders,
          scripts,
        }:
        import ./build {
          inherit nixpkgs builders scripts;
          src = import ./build/filter.nix nixpkgs.nix-filter self;
        };
    in
    {
      packages = inputs.observes_flake_builder.outputs.build build_args;
    };
}
