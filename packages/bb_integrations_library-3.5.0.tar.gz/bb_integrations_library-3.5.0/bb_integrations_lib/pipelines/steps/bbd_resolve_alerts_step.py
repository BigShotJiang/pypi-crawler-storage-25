from datetime import datetime, UTC
from typing import Any

from loguru import logger
from pymongo.asynchronous.database import AsyncDatabase

from bb_integrations_lib.protocols.pipelines import Step


class ResolveAlertsStep(Step):
    def __init__(self, mongo_db: AsyncDatabase):
        super().__init__()
        self.mongo_db = mongo_db

    def describe(self) -> str:
        return "Resolve all open alerts in alert_v2"

    async def execute(self, data: Any) -> Any:
        collection = self.mongo_db["alert_v2"]
        res = await collection.update_many(
            {"resolved_by": {"$exists": False}},
            {
                "$set": {
                    "resolved_by": "integrations",
                    "resolved_date": datetime.now(UTC),
                }
            },
        )
        logger.info(f"Resolved {res.modified_count} alerts")
        return res.modified_count
