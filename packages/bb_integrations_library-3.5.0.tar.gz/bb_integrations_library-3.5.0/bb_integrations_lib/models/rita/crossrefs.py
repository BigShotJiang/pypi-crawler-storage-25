from datetime import datetime

from pydantic import BaseModel, TypeAdapter


class CrossrefV2(BaseModel):
    """Model that describes CrossrefV2 objects returned by RITA."""

    id: str  # Document _id
    source_id: str | int
    gravitate_id: str | int
    type_id: str | None = None  # ObjectId reference to MappingTypes
    source_system_id: str | None = None
    is_active: bool = True
    group_id: str | None = None
    updated_by: str | None = None
    updated_on: datetime | None = None
    flags: list[dict] = []


crossref_v2_list_adapter = TypeAdapter(list[CrossrefV2])
