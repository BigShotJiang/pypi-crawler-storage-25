from typing import Optional
from pydantic import BaseModel

from bb_integrations_lib.models.pe.common import EntityQueryConfig, MiddlewareAttribute


class CounterpartyQueryConfig(EntityQueryConfig):
    category_meanings: list[str] = []

    def to_payload(self) -> dict:
        p = super().to_payload()
        if self.category_meanings:
            p["CategoryMeanings"] = self.category_meanings
        return p


class CounterPartyCreditDto(BaseModel):
    CreditLimit: Optional[float] = None
    ARBalance: Optional[float] = None
    CreditWatchPercentage: Optional[float] = None
    CreditHoldPercentage: Optional[float] = None
    CreditStatusMeaning: Optional[str] = None
    CreditStatusOverrideMeaning: Optional[str] = None
    IsActive: Optional[bool] = None


class CounterPartyExtractDto(BaseModel):
    CounterPartyId: Optional[int] = None
    Name: Optional[str] = None
    Abbreviation: Optional[str] = None
    IsActive: Optional[bool] = None
    CategoryMeaning: Optional[str] = None
    SourceSystemId: Optional[int] = None
    SourceSystemName: Optional[str] = None
    SourceId: Optional[int] = None
    SourceIdString: Optional[str] = None
    Credit: Optional[CounterPartyCreditDto] = None
    MiddlewareAttributes: list[MiddlewareAttribute] = []
