from typing import Optional
from pydantic import BaseModel

from bb_integrations_lib.models.pe.common import EntityQueryConfig, MiddlewareAttribute


class LocationQueryConfig(EntityQueryConfig):
    location_type_meanings: list[str] = []
    address_type_priority: list[str] = ["Shipping"]

    def to_payload(self) -> dict:
        p = super().to_payload()
        if self.location_type_meanings:
            p["LocationTypeMeanings"] = self.location_type_meanings
        return p


class PhoneDto(BaseModel):
    PhoneTypeMeaning: Optional[str] = None
    PhoneNumber: Optional[str] = None


class AddressDto(BaseModel):
    AddressTypeMeaning: Optional[str] = None
    AddressLine1: Optional[str] = None
    AddressLine2: Optional[str] = None
    City: Optional[str] = None
    StateCode: Optional[str] = None
    PostalCode: Optional[str] = None
    CountryCode: Optional[str] = None
    CountryName: Optional[str] = None


class LocationContactInfo(BaseModel):
    ContactName: Optional[str] = None
    Phones: list[PhoneDto] = []
    Addresses: list[AddressDto] = []


class LocationExtractDto(BaseModel):
    LocationId: Optional[int] = None
    Name: Optional[str] = None
    Abbreviation: Optional[str] = None
    IsActive: Optional[bool] = None
    CountryCode: Optional[str] = None
    StateProvince: Optional[str] = None
    Latitude: Optional[float] = None
    Longitude: Optional[float] = None
    TimeZoneCode: Optional[str] = None
    TerminalControlNumber: Optional[str] = None
    LocationTypeMeaning: Optional[str] = None
    SourceSystemId: Optional[int] = None
    SourceSystemName: Optional[str] = None
    SourceId: Optional[int] = None
    SourceIdString: Optional[str] = None
    MiddlewareAttributes: list[MiddlewareAttribute] = []
    ContactInfo: Optional[LocationContactInfo] = None
