from typing import Optional
from pydantic import BaseModel

from bb_integrations_lib.models.pe.common import EntityQueryConfig, MiddlewareAttribute


class ProductQueryConfig(EntityQueryConfig):
    product_type_meanings: list[str] = []

    def to_payload(self) -> dict:
        p = super().to_payload()
        if self.product_type_meanings:
            p["ProductTypeMeanings"] = self.product_type_meanings
        return p


class ProductExtractDto(BaseModel):
    ProductId: Optional[int] = None
    Name: Optional[str] = None
    Abbreviation: Optional[str] = None
    IsActive: Optional[bool] = None
    SortOrder: Optional[int] = None
    ProductTypeMeaning: Optional[str] = None
    SourceSystemId: Optional[int] = None
    SourceSystemName: Optional[str] = None
    SourceId: Optional[int] = None
    SourceIdString: Optional[str] = None
    MiddlewareAttributes: list[MiddlewareAttribute] = []
