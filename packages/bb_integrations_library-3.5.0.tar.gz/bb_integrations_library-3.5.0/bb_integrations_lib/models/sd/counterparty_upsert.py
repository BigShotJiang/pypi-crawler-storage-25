from typing import Optional
from pydantic import BaseModel


class SDCounterpartyUpsert(BaseModel):
    source_id: Optional[str] = None
    source_system_id: Optional[str] = None
    name: Optional[str] = None
    type: Optional[str] = None
    properties: Optional[dict] = None
