from typing import Optional
from pydantic import BaseModel


class SDProductUpsert(BaseModel):
    source_id: Optional[str] = None
    source_system_id: Optional[str] = None
    name: Optional[str] = None
    group: Optional[str] = None
    enabled: Optional[bool] = None
    weight_group: Optional[str] = None
    properties: Optional[dict] = None
