from typing import Optional
from pydantic import BaseModel


class SDLocationUpsert(BaseModel):
    source_id: Optional[str] = None
    source_system_id: Optional[str] = None
    name: Optional[str] = None
    short_name: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    type: Optional[str] = None
    market: Optional[str] = None
    include_in_backhaul: Optional[bool] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    active: Optional[bool] = None
    properties: Optional[dict] = None
