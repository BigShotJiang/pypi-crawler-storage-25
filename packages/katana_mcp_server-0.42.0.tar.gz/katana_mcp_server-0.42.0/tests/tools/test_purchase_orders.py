"""Tests for purchase order MCP tools."""

import json
import os
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from katana_mcp.tools.foundation.purchase_orders import (
    DiscrepancyType,
    DocumentItem,
    GetPurchaseOrderRequest,
    ReceiveItemRequest,
    ReceivePurchaseOrderRequest,
    ReceivePurchaseOrderResponse,
    VerifyOrderDocumentRequest,
    _get_purchase_order_impl,
    _receive_purchase_order_impl,
    _verify_order_document_impl,
    get_purchase_order,
    list_purchase_orders,
    verify_order_document,
)

from katana_public_api_client.api.purchase_order import (
    get_purchase_order as api_get_purchase_order,
)
from katana_public_api_client.client_types import UNSET
from katana_public_api_client.models import (
    PurchaseOrderReceiveRow,
    RegularPurchaseOrder,
)
from katana_public_api_client.utils import APIError
from tests.conftest import create_mock_context

# ============================================================================
# Test Helpers
# ============================================================================


# After #346, get_purchase_order and verify_order_document fetch additional
# cost rows and accounting metadata via extra HTTP calls. Every test in this
# module that exercises those impls would otherwise need to patch those
# helpers individually — instead, autouse-default them to empty and let the
# specific tests that care override via their own patch.
_FETCH_PO_ADDITIONAL_COSTS = (
    "katana_mcp.tools.foundation.purchase_orders._fetch_po_additional_cost_rows"
)
_FETCH_PO_ACCOUNTING_META = (
    "katana_mcp.tools.foundation.purchase_orders._fetch_po_accounting_metadata"
)


@pytest.fixture(autouse=True)
def _auto_mock_po_side_data_fetches():
    """Default the #346 side-data fetches to empty lists for every test.

    Tests that want to verify these are called override the patch locally.
    """
    with (
        patch(_FETCH_PO_ADDITIONAL_COSTS, AsyncMock(return_value=[])),
        patch(_FETCH_PO_ACCOUNTING_META, AsyncMock(return_value=[])),
    ):
        yield


def create_mock_po_row(variant_id: int, quantity: float, price: float):
    """Create a mock PO row.

    Exhaustive response model (#346) reads many more row fields than the
    old shape. Default them all to UNSET so Pydantic validation sees
    ``None`` rather than a stray ``MagicMock`` instance.
    """
    row = MagicMock()
    row.variant_id = variant_id
    row.quantity = quantity
    row.price_per_unit = price
    # id is required on PurchaseOrderRowInfo — give it a stable default that
    # callers can ignore.
    row.id = 1
    # Fields touched by _po_row_info() but not set by callers — UNSET so
    # unwrap_unset() collapses them to None.
    for field in (
        "created_at",
        "updated_at",
        "deleted_at",
        "tax_rate_id",
        "price_per_unit_in_base_currency",
        "purchase_uom_conversion_rate",
        "purchase_uom",
        "currency",
        "conversion_rate",
        "total",
        "total_in_base_currency",
        "conversion_date",
        "received_date",
        "arrival_date",
        "purchase_order_id",
        "landed_cost",
        "group_id",
        "batch_transactions",
    ):
        setattr(row, field, UNSET)
    return row


def create_mock_variant(variant_id: int, sku: str):
    """Create a mock variant."""
    variant = MagicMock()
    variant.id = variant_id
    variant.sku = sku
    return variant


def create_mock_po(order_id: int, order_no: str, rows: list):
    """Create a mock RegularPurchaseOrder.

    Exhaustive get_purchase_order (#346) reads every PurchaseOrder field.
    Default optional ones to UNSET so Pydantic sees ``None`` rather than a
    stray ``MagicMock`` when the response is built during verification.
    """
    po = MagicMock(spec=RegularPurchaseOrder)
    po.id = order_id
    po.order_no = order_no
    po.purchase_order_rows = rows
    for field in (
        "created_at",
        "updated_at",
        "deleted_at",
        "status",
        "entity_type",
        "default_group_id",
        "supplier_id",
        "currency",
        "expected_arrival_date",
        "order_created_date",
        "additional_info",
        "location_id",
        "total",
        "total_in_base_currency",
        "billing_status",
        "last_document_status",
        "tracking_location_id",
        "supplier",
    ):
        setattr(po, field, UNSET)
    return po


# ============================================================================
# Unit Tests - verify_order_document
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_perfect_match():
    """Test verification with all items matching perfectly."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO with 2 rows
    po_rows = [
        create_mock_po_row(variant_id=1, quantity=100.0, price=25.50),
        create_mock_po_row(variant_id=2, quantity=50.0, price=30.00),
    ]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    # Mock API response
    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    # Mock variants
    mock_variants = [
        create_mock_variant(variant_id=1, sku="WIDGET-001"),
        create_mock_variant(variant_id=2, sku="WIDGET-002"),
    ]

    # Setup mocks

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document items matching PO perfectly
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
            DocumentItem(sku="WIDGET-002", quantity=50.0, unit_price=30.00),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions
    assert result.order_id == 1234
    assert result.overall_status == "match"
    assert len(result.matches) == 2
    assert len(result.discrepancies) == 0
    assert result.matches[0].sku == "WIDGET-001"
    assert result.matches[0].quantity == 100.0
    assert result.matches[0].unit_price == 25.50
    assert result.matches[0].status == "perfect"
    assert result.matches[1].sku == "WIDGET-002"
    assert result.matches[1].quantity == 50.0
    assert result.matches[1].unit_price == 30.00
    assert result.matches[1].status == "perfect"
    assert "All items verified successfully" in result.suggested_actions[0]


# ============================================================================
# Unit Tests - Quantity Discrepancies
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_quantity_mismatch():
    """Test verification with quantity discrepancies."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO
    po_rows = [create_mock_po_row(variant_id=1, quantity=100.0, price=25.50)]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document with different quantity
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=90.0, unit_price=25.50),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions
    assert result.order_id == 1234
    assert result.overall_status == "partial_match"
    assert len(result.matches) == 1
    assert len(result.discrepancies) == 1

    # Check discrepancy
    discrepancy = result.discrepancies[0]
    assert discrepancy.sku == "WIDGET-001"
    assert discrepancy.type == DiscrepancyType.QUANTITY_MISMATCH
    assert discrepancy.expected == 100.0
    assert discrepancy.actual == 90.0
    assert "Quantity mismatch" in discrepancy.message

    # Check match with quantity_diff status
    match = result.matches[0]
    assert match.sku == "WIDGET-001"
    assert match.status == "quantity_diff"

    assert any("Review discrepancies" in action for action in result.suggested_actions)


# ============================================================================
# Unit Tests - Price Discrepancies
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_price_mismatch():
    """Test verification with price discrepancies."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO
    po_rows = [create_mock_po_row(variant_id=1, quantity=100.0, price=25.50)]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document with different price
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=30.00),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions
    assert result.order_id == 1234
    assert result.overall_status == "partial_match"
    assert len(result.matches) == 1
    assert len(result.discrepancies) == 1

    # Check discrepancy
    discrepancy = result.discrepancies[0]
    assert discrepancy.sku == "WIDGET-001"
    assert discrepancy.type == DiscrepancyType.PRICE_MISMATCH
    assert discrepancy.expected == 25.50
    assert discrepancy.actual == 30.00
    assert "Price mismatch" in discrepancy.message

    # Check match with price_diff status
    match = result.matches[0]
    assert match.sku == "WIDGET-001"
    assert match.status == "price_diff"


# ============================================================================
# Unit Tests - Missing Items
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_missing_in_po():
    """Test verification with items in document but not in PO."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO with only WIDGET-001
    po_rows = [create_mock_po_row(variant_id=1, quantity=100.0, price=25.50)]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document includes WIDGET-002 which is not in PO
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
            DocumentItem(sku="WIDGET-002", quantity=50.0, unit_price=30.00),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions
    assert result.order_id == 1234
    assert result.overall_status == "partial_match"
    assert len(result.matches) == 1
    assert len(result.discrepancies) == 1

    # Check discrepancy
    discrepancy = result.discrepancies[0]
    assert discrepancy.sku == "WIDGET-002"
    assert discrepancy.type == DiscrepancyType.MISSING_IN_PO
    assert discrepancy.expected is None
    assert discrepancy.actual == 50.0
    assert "Not found in purchase order" in discrepancy.message


# ============================================================================
# Unit Tests - Extra Items in PO
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_extra_in_document():
    """Test that we don't report PO items missing from document (only check document items)."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO with 2 items
    po_rows = [
        create_mock_po_row(variant_id=1, quantity=100.0, price=25.50),
        create_mock_po_row(variant_id=2, quantity=50.0, price=30.00),
    ]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [
        create_mock_variant(variant_id=1, sku="WIDGET-001"),
        create_mock_variant(variant_id=2, sku="WIDGET-002"),
    ]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document only has WIDGET-001 (missing WIDGET-002 from PO)
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions - should only verify what's in document, not flag missing PO items
    assert result.order_id == 1234
    assert result.overall_status == "match"
    assert len(result.matches) == 1
    assert len(result.discrepancies) == 0


# ============================================================================
# Unit Tests - Mixed Scenarios
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_mixed_discrepancies():
    """Test verification with multiple types of discrepancies."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO with 2 items
    po_rows = [
        create_mock_po_row(variant_id=1, quantity=100.0, price=25.50),
        create_mock_po_row(variant_id=2, quantity=50.0, price=30.00),
    ]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [
        create_mock_variant(variant_id=1, sku="WIDGET-001"),
        create_mock_variant(variant_id=2, sku="WIDGET-002"),
    ]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document with: perfect match, quantity mismatch, missing item
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(
                sku="WIDGET-001", quantity=100.0, unit_price=25.50
            ),  # Perfect match
            DocumentItem(
                sku="WIDGET-002", quantity=45.0, unit_price=30.00
            ),  # Quantity mismatch
            DocumentItem(
                sku="WIDGET-003", quantity=25.0, unit_price=15.00
            ),  # Not in PO
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions
    assert result.order_id == 1234
    assert result.overall_status == "partial_match"
    assert len(result.matches) == 2
    assert len(result.discrepancies) == 2

    # Check perfect match
    perfect_match = next(m for m in result.matches if m.sku == "WIDGET-001")
    assert perfect_match.status == "perfect"

    # Check quantity mismatch
    qty_match = next(m for m in result.matches if m.sku == "WIDGET-002")
    assert qty_match.status == "quantity_diff"

    qty_discrepancy = next(
        d for d in result.discrepancies if d.type == DiscrepancyType.QUANTITY_MISMATCH
    )
    assert qty_discrepancy.sku == "WIDGET-002"
    assert qty_discrepancy.expected == 50.0
    assert qty_discrepancy.actual == 45.0

    # Check missing item
    missing_discrepancy = next(
        d for d in result.discrepancies if d.type == DiscrepancyType.MISSING_IN_PO
    )
    assert missing_discrepancy.sku == "WIDGET-003"
    assert missing_discrepancy.actual == 25.0


# ============================================================================
# Unit Tests - Edge Cases
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_empty_po():
    """Test verification when PO has no line items."""
    context, _lifespan_ctx = create_mock_context()

    # Mock PO with no rows
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=[])

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)

    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions
    assert result.order_id == 1234
    assert result.overall_status == "no_match"
    assert len(result.matches) == 0
    assert len(result.discrepancies) == 0
    assert "has no line items" in result.message
    assert any(
        "Verify purchase order data" in action for action in result.suggested_actions
    )


@pytest.mark.asyncio
async def test_verify_order_document_po_not_found():
    """Test verification when PO doesn't exist."""
    context, _lifespan_ctx = create_mock_context()

    # Mock 404 response
    mock_po_response = MagicMock()
    mock_po_response.status_code = 404
    mock_po_response.parsed = None

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)

    request = VerifyOrderDocumentRequest(
        order_id=9999,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
        ],
    )

    with pytest.raises(APIError):
        await _verify_order_document_impl(request, context)


@pytest.mark.asyncio
async def test_verify_order_document_unset_values():
    """Test verification with UNSET values in PO data."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO row with UNSET values — start from create_mock_po_row so the
    # exhaustive response builder (#346) doesn't trip on stray MagicMocks.
    po_row = create_mock_po_row(variant_id=1, quantity=UNSET, price=UNSET)
    po_row.quantity = UNSET
    po_row.price_per_unit = UNSET

    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=[po_row])

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Should handle UNSET by defaulting to 0
    assert result.order_id == 1234
    # Quantity mismatch because PO has 0 (from UNSET)
    assert len(result.discrepancies) >= 1
    qty_disc = [
        d for d in result.discrepancies if d.type == DiscrepancyType.QUANTITY_MISMATCH
    ]
    if qty_disc:
        assert qty_disc[0].expected == 0.0


@pytest.mark.asyncio
async def test_verify_order_document_no_price_in_document():
    """Test verification when document doesn't include prices."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO
    po_rows = [create_mock_po_row(variant_id=1, quantity=100.0, price=25.50)]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document without price
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=None),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions - should not create price discrepancy
    assert result.order_id == 1234
    assert result.overall_status == "match"
    assert len(result.matches) == 1
    price_discrepancies = [
        d for d in result.discrepancies if d.type == DiscrepancyType.PRICE_MISMATCH
    ]
    assert len(price_discrepancies) == 0


@pytest.mark.asyncio
async def test_verify_order_document_variant_not_found():
    """Test verification when variant lookup fails."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO
    po_rows = [create_mock_po_row(variant_id=1, quantity=100.0, price=25.50)]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    # Variants list doesn't include variant_id=1
    mock_variants = []

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Should handle gracefully - SKU won't be found in mapping
    assert result.order_id == 1234
    # WIDGET-001 won't be in sku_to_row map, so it will be marked as missing
    assert len(result.discrepancies) >= 1
    missing_disc = [
        d for d in result.discrepancies if d.type == DiscrepancyType.MISSING_IN_PO
    ]
    assert len(missing_disc) == 1
    assert missing_disc[0].sku == "WIDGET-001"


@pytest.mark.asyncio
async def test_verify_order_document_unset_order_no():
    """Test verification when order_no is UNSET."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO with UNSET order_no — build via create_mock_po so every
    # exhaustive-response field defaults to UNSET instead of leaking a
    # stray MagicMock into Pydantic validation.
    po_rows = [create_mock_po_row(variant_id=1, quantity=100.0, price=25.50)]
    mock_po = create_mock_po(order_id=1234, order_no="ignored", rows=po_rows)
    mock_po.order_no = UNSET  # UNSET value under test

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=100.0, unit_price=25.50),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Should handle UNSET order_no by using default "PO-{id}"
    assert result.order_id == 1234
    assert "PO-1234" in result.message or result.overall_status is not None


# ============================================================================
# Integration Tests (require KATANA_API_KEY)
# ============================================================================


@pytest.mark.integration
@pytest.mark.asyncio
async def test_verify_order_document_integration(katana_context):
    """Integration test with real Katana API.

    This test requires:
    - KATANA_API_KEY environment variable
    - A real purchase order in the Katana account
    - Known SKUs in the PO

    Note: This test may fail if the PO doesn't exist or has different data.
    It's mainly for manual verification during development.
    """
    # This is a placeholder integration test
    # Real implementation would need actual PO IDs and SKUs from the test account
    pytest.skip("Integration test requires specific PO data - implement as needed")


# ============================================================================
# Unit Tests - No Match Scenario
# ============================================================================


@pytest.mark.asyncio
async def test_verify_order_document_no_match():
    """Test verification with no matching items."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO with different items
    po_rows = [create_mock_po_row(variant_id=1, quantity=100.0, price=25.50)]
    mock_po = create_mock_po(order_id=1234, order_no="PO-001", rows=po_rows)

    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po

    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    # Document with completely different items
    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-999", quantity=100.0, unit_price=25.50),
            DocumentItem(sku="WIDGET-888", quantity=50.0, unit_price=30.00),
        ],
    )

    result = await _verify_order_document_impl(request, context)

    # Assertions
    assert result.order_id == 1234
    assert result.overall_status == "no_match"
    assert len(result.matches) == 0
    assert len(result.discrepancies) == 2

    # All should be missing
    for disc in result.discrepancies:
        assert disc.type == DiscrepancyType.MISSING_IN_PO


# ============================================================================
# Unit Tests - receive_purchase_order
# ============================================================================


@pytest.mark.asyncio
async def test_receive_purchase_order_preview():
    """Test receive_purchase_order in preview mode (confirm=false)."""
    context, lifespan_ctx = create_mock_context()

    # Mock the get_purchase_order API response
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = "PO-2024-001"
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    lifespan_ctx.client = MagicMock()

    # Mock get_purchase_order API call
    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)

    # Create request with confirm=false (preview mode)
    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[
            ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0),
            ReceiveItemRequest(purchase_order_row_id=502, quantity=50.0),
        ],
        confirm=False,
    )

    result = await _receive_purchase_order_impl(request, context)

    # Verify preview response
    assert isinstance(result, ReceivePurchaseOrderResponse)
    assert result.order_id == 1234
    assert result.order_number == "PO-2024-001"
    assert result.items_received == 2
    assert result.is_preview is True
    assert "Review the items to receive" in result.next_actions
    assert "confirm=true" in result.next_actions[1]
    assert "Preview" in result.message


@pytest.mark.asyncio
async def test_receive_purchase_order_confirm_success():
    """Test receive_purchase_order in confirm mode with successful API call."""
    context, lifespan_ctx = create_mock_context()

    # Mock the get_purchase_order API response
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = "PO-2024-001"
    mock_po.status = MagicMock()
    mock_po.status.value = "PARTIALLY_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    # Mock the receive_purchase_order API response (204 No Content)
    mock_receive_response = MagicMock()
    mock_receive_response.status_code = 204

    lifespan_ctx.client = MagicMock()

    # Mock both API calls
    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
        receive_purchase_order as api_receive_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)
    api_receive_purchase_order.asyncio_detailed = AsyncMock(
        return_value=mock_receive_response
    )

    # Create request with confirm=true
    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[
            ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0),
            ReceiveItemRequest(purchase_order_row_id=502, quantity=50.0),
        ],
        confirm=True,
    )

    result = await _receive_purchase_order_impl(request, context)

    # Verify success response
    assert isinstance(result, ReceivePurchaseOrderResponse)
    assert result.order_id == 1234
    assert result.order_number == "PO-2024-001"
    assert result.items_received == 2
    assert result.is_preview is False
    assert "Successfully received" in result.message
    assert "Inventory has been updated" in result.next_actions

    # Verify API was called with correct data
    api_receive_purchase_order.asyncio_detailed.assert_called_once()
    call_args = api_receive_purchase_order.asyncio_detailed.call_args
    body = call_args.kwargs["body"]

    # Verify the body contains correct receive rows
    assert len(body) == 2
    assert all(isinstance(row, PurchaseOrderReceiveRow) for row in body)
    assert body[0].purchase_order_row_id == 501
    assert body[0].quantity == 100.0
    assert body[1].purchase_order_row_id == 502
    assert body[1].quantity == 50.0


@pytest.mark.asyncio
async def test_receive_purchase_order_single_item():
    """Test receive_purchase_order with a single item."""
    context, lifespan_ctx = create_mock_context()

    # Mock the get_purchase_order API response
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 5678
    mock_po.order_no = "PO-2024-002"
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    # Mock the receive_purchase_order API response
    mock_receive_response = MagicMock()
    mock_receive_response.status_code = 204

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
        receive_purchase_order as api_receive_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)
    api_receive_purchase_order.asyncio_detailed = AsyncMock(
        return_value=mock_receive_response
    )

    # Create request with single item
    request = ReceivePurchaseOrderRequest(
        order_id=5678,
        items=[ReceiveItemRequest(purchase_order_row_id=601, quantity=25.5)],
        confirm=True,
    )

    result = await _receive_purchase_order_impl(request, context)

    assert result.order_id == 5678
    assert result.items_received == 1
    assert result.is_preview is False


@pytest.mark.asyncio
async def test_receive_purchase_order_get_po_fails():
    """Test receive_purchase_order when get_purchase_order API fails."""
    context, lifespan_ctx = create_mock_context()

    # Mock failed get_purchase_order response
    mock_get_response = MagicMock()
    mock_get_response.status_code = 404
    mock_get_response.parsed = None

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)

    request = ReceivePurchaseOrderRequest(
        order_id=9999,
        items=[ReceiveItemRequest(purchase_order_row_id=701, quantity=10.0)],
        confirm=False,
    )

    # Should raise an APIError (404 with parsed=None)
    with pytest.raises(APIError):
        await _receive_purchase_order_impl(request, context)


@pytest.mark.asyncio
async def test_receive_purchase_order_receive_api_fails():
    """Test receive_purchase_order when receive API returns non-204 status."""
    context, lifespan_ctx = create_mock_context()

    # Mock successful get_purchase_order
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = "PO-2024-001"
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    # Mock failed receive_purchase_order response
    mock_receive_response = MagicMock()
    mock_receive_response.status_code = 422
    mock_receive_response.parsed = None  # Explicit None so unwrap raises APIError

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
        receive_purchase_order as api_receive_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)
    api_receive_purchase_order.asyncio_detailed = AsyncMock(
        return_value=mock_receive_response
    )

    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0)],
        confirm=True,
    )

    # Should raise a ValidationError (422 is validation error)
    with pytest.raises(
        APIError
    ):  # Could be ValidationError but parsed=None so falls back to APIError
        await _receive_purchase_order_impl(request, context)


@pytest.mark.asyncio
async def test_receive_purchase_order_order_no_unset():
    """Test receive_purchase_order when order_no is UNSET."""
    context, lifespan_ctx = create_mock_context()

    # Mock PO with UNSET order_no
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = UNSET
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)

    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0)],
        confirm=False,
    )

    result = await _receive_purchase_order_impl(request, context)

    # Should use fallback order number
    assert result.order_number == "PO-1234"
    assert result.is_preview is True


@pytest.mark.asyncio
async def test_receive_purchase_order_received_date_set():
    """Test that received_date is set correctly when receiving items."""
    context, lifespan_ctx = create_mock_context()

    # Mock successful get and receive
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = "PO-2024-001"
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    mock_receive_response = MagicMock()
    mock_receive_response.status_code = 204

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
        receive_purchase_order as api_receive_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)
    api_receive_purchase_order.asyncio_detailed = AsyncMock(
        return_value=mock_receive_response
    )

    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0)],
        confirm=True,
    )

    # Record time before call
    before_time = datetime.now(UTC)

    await _receive_purchase_order_impl(request, context)

    # Record time after call
    after_time = datetime.now(UTC)

    # Verify received_date was set
    call_args = api_receive_purchase_order.asyncio_detailed.call_args
    body = call_args.kwargs["body"]
    received_date = body[0].received_date

    # Verify it's a datetime in UTC and within reasonable bounds
    assert isinstance(received_date, datetime)
    assert received_date.tzinfo == UTC
    assert before_time <= received_date <= after_time


# ============================================================================
# Integration Tests (require KATANA_API_KEY)
# ============================================================================


@pytest.mark.integration
@pytest.mark.skipif(not os.getenv("KATANA_API_KEY"), reason="No API key")
@pytest.mark.asyncio
async def test_receive_purchase_order_integration_preview(katana_context):
    """Integration test: Preview mode with real API."""
    # This test requires a real PO ID that exists in the test environment
    # For now, we'll skip if we don't have a test PO ID
    test_po_id = os.getenv("TEST_PO_ID")
    if not test_po_id:
        pytest.skip("TEST_PO_ID not set - cannot run integration test")

    request = ReceivePurchaseOrderRequest(
        order_id=int(test_po_id),
        items=[ReceiveItemRequest(purchase_order_row_id=1, quantity=1.0)],
        confirm=False,
    )

    # This should not fail even if the row ID doesn't exist
    # because preview mode just fetches the PO
    result = await _receive_purchase_order_impl(request, katana_context)

    assert result.is_preview is True
    assert result.order_id == int(test_po_id)
    assert result.items_received == 1


# ============================================================================
# Tests for public wrapper function
# ============================================================================


@pytest.mark.asyncio
async def test_receive_purchase_order_wrapper():
    """Test the public receive_purchase_order wrapper function."""
    context, lifespan_ctx = create_mock_context()

    # Mock the get_purchase_order API response
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = "PO-2024-001"
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)

    # Create request
    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0)],
        confirm=False,
    )

    # Call the implementation function directly (wrapper expects unpacked args from FastMCP)
    result = await _receive_purchase_order_impl(request, context)

    # Verify it returns the same type as the implementation
    assert isinstance(result, ReceivePurchaseOrderResponse)
    assert result.order_id == 1234
    assert result.is_preview is True


@pytest.mark.asyncio
async def test_receive_purchase_order_multiple_items_various_quantities():
    """Test receiving multiple items with various quantities including decimals."""
    context, lifespan_ctx = create_mock_context()

    # Mock successful get and receive
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = "PO-2024-003"
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    mock_receive_response = MagicMock()
    mock_receive_response.status_code = 204

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
        receive_purchase_order as api_receive_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)
    api_receive_purchase_order.asyncio_detailed = AsyncMock(
        return_value=mock_receive_response
    )

    # Test with various quantities: integers, decimals, large numbers
    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[
            ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0),
            ReceiveItemRequest(purchase_order_row_id=502, quantity=25.5),
            ReceiveItemRequest(purchase_order_row_id=503, quantity=0.75),
            ReceiveItemRequest(purchase_order_row_id=504, quantity=1000.0),
        ],
        confirm=True,
    )

    result = await _receive_purchase_order_impl(request, context)

    assert result.items_received == 4
    assert result.is_preview is False

    # Verify all items were sent to API
    call_args = api_receive_purchase_order.asyncio_detailed.call_args
    body = call_args.kwargs["body"]
    assert len(body) == 4
    assert body[0].quantity == 100.0
    assert body[1].quantity == 25.5
    assert body[2].quantity == 0.75
    assert body[3].quantity == 1000.0


@pytest.mark.asyncio
async def test_receive_purchase_order_validates_positive_quantity():
    """Test that ReceiveItemRequest validates quantity > 0."""
    # Pydantic should validate this at model creation time
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        ReceiveItemRequest(purchase_order_row_id=501, quantity=0.0)

    with pytest.raises(ValidationError):
        ReceiveItemRequest(purchase_order_row_id=501, quantity=-10.0)


@pytest.mark.asyncio
async def test_receive_purchase_order_validates_min_items():
    """Test that ReceivePurchaseOrderRequest requires at least one item."""
    # Pydantic should validate min_length=1
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        ReceivePurchaseOrderRequest(order_id=1234, items=[], confirm=False)


@pytest.mark.asyncio
async def test_receive_purchase_order_exception_handling():
    """Test proper exception handling and logging."""
    context, lifespan_ctx = create_mock_context()

    # Mock get_purchase_order to raise an exception
    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(
        side_effect=Exception("Network error")
    )

    lifespan_ctx.client = MagicMock()

    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0)],
        confirm=False,
    )

    # Should raise and propagate the exception
    with pytest.raises(Exception) as exc_info:
        await _receive_purchase_order_impl(request, context)

    assert "Network error" in str(exc_info.value)


@pytest.mark.asyncio
async def test_receive_purchase_order_builds_correct_api_payload():
    """Test that the API payload is built correctly with all fields."""
    context, lifespan_ctx = create_mock_context()

    # Mock successful get and receive
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 1234
    mock_po.order_no = "PO-2024-TEST"
    mock_po.status = MagicMock()
    mock_po.status.value = "NOT_RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    mock_receive_response = MagicMock()
    mock_receive_response.status_code = 204

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
        receive_purchase_order as api_receive_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)
    api_receive_purchase_order.asyncio_detailed = AsyncMock(
        return_value=mock_receive_response
    )

    # Create request with multiple items
    request = ReceivePurchaseOrderRequest(
        order_id=1234,
        items=[
            ReceiveItemRequest(purchase_order_row_id=501, quantity=100.0),
            ReceiveItemRequest(purchase_order_row_id=502, quantity=50.5),
        ],
        confirm=True,
    )

    await _receive_purchase_order_impl(request, context)

    # Verify the API was called with correct parameters
    api_receive_purchase_order.asyncio_detailed.assert_called_once()
    call_args = api_receive_purchase_order.asyncio_detailed.call_args

    # Check client parameter
    assert "client" in call_args.kwargs
    assert call_args.kwargs["client"] == lifespan_ctx.client

    # Check body parameter (list of PurchaseOrderReceiveRow)
    body = call_args.kwargs["body"]
    assert isinstance(body, list)
    assert len(body) == 2

    # Verify first row
    assert isinstance(body[0], PurchaseOrderReceiveRow)
    assert body[0].purchase_order_row_id == 501
    assert body[0].quantity == 100.0
    assert isinstance(body[0].received_date, datetime)

    # Verify second row
    assert isinstance(body[1], PurchaseOrderReceiveRow)
    assert body[1].purchase_order_row_id == 502
    assert body[1].quantity == 50.5
    assert isinstance(body[1].received_date, datetime)


@pytest.mark.asyncio
async def test_receive_purchase_order_response_structure():
    """Test that response contains all expected fields."""
    context, lifespan_ctx = create_mock_context()

    # Mock successful response
    mock_po = MagicMock(spec=RegularPurchaseOrder)
    mock_po.id = 9999
    mock_po.order_no = "PO-RESPONSE-TEST"
    mock_po.status = MagicMock()
    mock_po.status.value = "RECEIVED"

    mock_get_response = MagicMock()
    mock_get_response.status_code = 200
    mock_get_response.parsed = mock_po

    mock_receive_response = MagicMock()
    mock_receive_response.status_code = 204

    lifespan_ctx.client = MagicMock()

    from katana_public_api_client.api.purchase_order import (
        get_purchase_order as api_get_purchase_order,
        receive_purchase_order as api_receive_purchase_order,
    )

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_get_response)
    api_receive_purchase_order.asyncio_detailed = AsyncMock(
        return_value=mock_receive_response
    )

    request = ReceivePurchaseOrderRequest(
        order_id=9999,
        items=[ReceiveItemRequest(purchase_order_row_id=701, quantity=25.0)],
        confirm=True,
    )

    result = await _receive_purchase_order_impl(request, context)

    # Verify all response fields are populated correctly
    assert result.order_id == 9999
    assert result.order_number == "PO-RESPONSE-TEST"
    assert result.items_received == 1
    assert result.is_preview is False
    assert isinstance(result.warnings, list)
    assert isinstance(result.next_actions, list)
    assert len(result.next_actions) > 0
    assert isinstance(result.message, str)
    assert "Successfully received" in result.message


# ============================================================================
# get_purchase_order tests
# ============================================================================

_PO_FIND = "katana_public_api_client.api.purchase_order.find_purchase_orders"
_PO_GET = "katana_public_api_client.api.purchase_order.get_purchase_order"
_UNWRAP_DATA = "katana_public_api_client.utils.unwrap_data"
_UNWRAP = "katana_mcp.tools.foundation.purchase_orders.unwrap"


def _make_mock_po(order_no: str = "PO-TEST") -> MagicMock:
    """Create a mock PO with rows.

    After #346 every PurchaseOrder / PurchaseOrderRow field is surfaced on
    the exhaustive response, so un-set attributes must be UNSET (not bare
    MagicMocks) to keep Pydantic validation happy.
    """

    def _mock_row(row_id: int, variant_id: int, qty: float, price: float, total: float):
        row = MagicMock()
        row.id = row_id
        row.variant_id = variant_id
        row.quantity = qty
        row.price_per_unit = price
        row.arrival_date = datetime(2026, 4, 15, tzinfo=UTC)
        row.received_date = UNSET
        row.total = total
        for field in (
            "created_at",
            "updated_at",
            "deleted_at",
            "tax_rate_id",
            "price_per_unit_in_base_currency",
            "purchase_uom_conversion_rate",
            "purchase_uom",
            "currency",
            "conversion_rate",
            "total_in_base_currency",
            "conversion_date",
            "purchase_order_id",
            "landed_cost",
            "group_id",
            "batch_transactions",
        ):
            setattr(row, field, UNSET)
        return row

    row1 = _mock_row(7001, 100, 3.0, 250.0, 750.0)
    row2 = _mock_row(7002, 101, 3.0, 50.0, 150.0)

    po = MagicMock()
    po.id = 12345
    po.order_no = order_no
    po.status = UNSET
    po.supplier_id = 999
    po.location_id = 160411
    po.currency = "USD"
    po.expected_arrival_date = datetime(2026, 4, 15, tzinfo=UTC)
    po.total = 900.0
    po.purchase_order_rows = [row1, row2]
    for field in (
        "created_at",
        "updated_at",
        "deleted_at",
        "entity_type",
        "default_group_id",
        "order_created_date",
        "additional_info",
        "total_in_base_currency",
        "billing_status",
        "last_document_status",
        "tracking_location_id",
        "supplier",
    ):
        setattr(po, field, UNSET)
    return po


@pytest.mark.asyncio
async def test_get_purchase_order_by_number():
    """Look up a PO by order_no via find_purchase_orders."""
    context, _ = create_mock_context()
    mock_po = _make_mock_po("PO-1022")

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP_DATA, return_value=[mock_po]),
    ):
        request = GetPurchaseOrderRequest(order_no="PO-1022")
        result = await _get_purchase_order_impl(request, context)

    assert result.id == 12345
    assert result.order_no == "PO-1022"
    assert result.supplier_id == 999
    assert result.location_id == 160411
    assert result.total == 900.0
    assert len(result.purchase_order_rows) == 2
    assert result.purchase_order_rows[0].id == 7001
    assert result.purchase_order_rows[0].variant_id == 100
    assert result.purchase_order_rows[1].variant_id == 101


@pytest.mark.asyncio
async def test_get_purchase_order_not_found():
    """Looking up a non-existent PO raises."""
    context, _ = create_mock_context()

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP_DATA, return_value=[]),
    ):
        request = GetPurchaseOrderRequest(order_no="PO-NONE")
        with pytest.raises(ValueError, match="Purchase order 'PO-NONE' not found"):
            await _get_purchase_order_impl(request, context)


@pytest.mark.asyncio
async def test_get_purchase_order_requires_identifier():
    """Must provide order_no or order_id."""
    context, _ = create_mock_context()

    request = GetPurchaseOrderRequest()
    with pytest.raises(ValueError, match="order_no or order_id"):
        await _get_purchase_order_impl(request, context)


@pytest.mark.asyncio
async def test_get_purchase_order_by_id():
    """Look up a PO by ID via get_purchase_order."""
    context, _ = create_mock_context()
    mock_po = _make_mock_po("PO-BYID")

    with (
        patch(f"{_PO_GET}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP, return_value=mock_po),
    ):
        request = GetPurchaseOrderRequest(order_id=12345)
        result = await _get_purchase_order_impl(request, context)

    assert result.id == 12345
    assert result.order_no == "PO-BYID"
    assert len(result.purchase_order_rows) == 2


# ============================================================================
# get_purchase_order exhaustive detail (#346)
# ============================================================================


def _make_exhaustive_mock_po_row() -> MagicMock:
    """Build a mock PurchaseOrderRow with every field set.

    Mirrors the shape ``_po_row_info`` consumes, so asserting on the
    resulting ``PurchaseOrderRowInfo`` covers every field surfaced by
    the exhaustive get_purchase_order response.
    """
    row = MagicMock()
    row.id = 7001
    row.created_at = datetime(2026, 1, 10, 9, 0, tzinfo=UTC)
    row.updated_at = datetime(2026, 1, 15, 14, 30, tzinfo=UTC)
    row.deleted_at = UNSET
    row.quantity = 3.0
    row.variant_id = 100
    row.tax_rate_id = 42
    row.price_per_unit = 250.0
    row.price_per_unit_in_base_currency = 260.0
    row.purchase_uom_conversion_rate = 1.0
    row.purchase_uom = "kg"
    row.currency = "USD"
    row.conversion_rate = 1.0
    row.total = 750.0
    row.total_in_base_currency = 780.0
    row.conversion_date = datetime(2026, 1, 10, tzinfo=UTC)
    row.received_date = UNSET
    row.arrival_date = datetime(2026, 4, 15, tzinfo=UTC)
    row.purchase_order_id = 12345
    row.landed_cost = 795.0
    row.group_id = 8080
    row.batch_transactions = UNSET
    return row


def _make_exhaustive_mock_po() -> MagicMock:
    """Build a mock RegularPurchaseOrder with every field set."""
    po = MagicMock()
    po.id = 12345
    po.created_at = datetime(2026, 1, 10, 9, 0, tzinfo=UTC)
    po.updated_at = datetime(2026, 1, 15, 14, 30, tzinfo=UTC)
    po.deleted_at = UNSET
    po.status = "NOT_RECEIVED"
    po.order_no = "PO-1022"
    po.entity_type = "regular"
    po.default_group_id = 8080
    po.supplier_id = 999
    po.currency = "USD"
    po.expected_arrival_date = datetime(2026, 4, 15, tzinfo=UTC)
    po.order_created_date = datetime(2026, 1, 10, 9, 0, tzinfo=UTC)
    po.additional_info = "urgent delivery"
    po.location_id = 160411
    po.total = 900.0
    po.total_in_base_currency = 930.0
    po.billing_status = "NOT_BILLED"
    po.last_document_status = "SENT"
    po.tracking_location_id = UNSET
    po.supplier = UNSET
    po.purchase_order_rows = [_make_exhaustive_mock_po_row()]
    return po


def _make_mock_supplier(
    *,
    id: int = 999,
    name: str = "Acme Supplies",
    email: str = "orders@acme.example",
    phone: str = "+1-555-0100",
    currency: str = "USD",
    comment: str = "Preferred supplier",
    default_address_id: int = 7001,
) -> MagicMock:
    """Build a mock embedded ``Supplier`` with every exposed field set."""
    s = MagicMock()
    s.id = id
    s.name = name
    s.email = email
    s.phone = phone
    s.currency = currency
    s.comment = comment
    s.default_address_id = default_address_id
    s.addresses = UNSET
    s.created_at = datetime(2026, 1, 1, tzinfo=UTC)
    s.updated_at = datetime(2026, 1, 15, tzinfo=UTC)
    s.deleted_at = UNSET
    return s


@pytest.mark.asyncio
async def test_get_purchase_order_full_field_coverage():
    """Every PurchaseOrder / PurchaseOrderRow field the cache carries
    surfaces on the exhaustive response (#346)."""
    context, _ = create_mock_context()
    mock_po = _make_exhaustive_mock_po()

    with (
        patch(f"{_PO_GET}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP, return_value=mock_po),
    ):
        request = GetPurchaseOrderRequest(order_id=12345)
        result = await _get_purchase_order_impl(request, context)

    # PO-scope scalar fields — every one Katana exposes on RegularPurchaseOrder
    assert result.id == 12345
    assert result.order_no == "PO-1022"
    assert result.status == "NOT_RECEIVED"
    assert result.entity_type == "regular"
    assert result.default_group_id == 8080
    assert result.supplier_id == 999
    assert result.currency == "USD"
    assert result.location_id == 160411
    assert result.total == 900.0
    assert result.total_in_base_currency == 930.0
    assert result.billing_status == "NOT_BILLED"
    assert result.last_document_status == "SENT"
    assert result.additional_info == "urgent delivery"
    assert result.expected_arrival_date == "2026-04-15T00:00:00+00:00"
    assert result.order_created_date == "2026-01-10T09:00:00+00:00"
    assert result.created_at == "2026-01-10T09:00:00+00:00"
    assert result.updated_at == "2026-01-15T14:30:00+00:00"

    # Row-scope — every PurchaseOrderRow field
    assert len(result.purchase_order_rows) == 1
    row = result.purchase_order_rows[0]
    assert row.id == 7001
    assert row.variant_id == 100
    assert row.tax_rate_id == 42
    assert row.quantity == 3.0
    assert row.price_per_unit == 250.0
    assert row.price_per_unit_in_base_currency == 260.0
    assert row.purchase_uom == "kg"
    assert row.purchase_uom_conversion_rate == 1.0
    assert row.currency == "USD"
    assert row.conversion_rate == 1.0
    assert row.total == 750.0
    assert row.total_in_base_currency == 780.0
    assert row.arrival_date == "2026-04-15T00:00:00+00:00"
    assert row.conversion_date == "2026-01-10T00:00:00+00:00"
    assert row.purchase_order_id == 12345
    assert row.landed_cost == 795.0
    assert row.group_id == 8080
    assert row.created_at == "2026-01-10T09:00:00+00:00"
    assert row.updated_at == "2026-01-15T14:30:00+00:00"

    # Side-data default (autouse fixture returns [])
    assert result.additional_cost_rows == []
    assert result.accounting_metadata == []


@pytest.mark.asyncio
async def test_get_purchase_order_fetches_additional_costs_and_accounting_metadata():
    """Side-data fetches run on the PO's default_group_id / id and surface
    into the exhaustive response (#346)."""
    from katana_mcp.tools.foundation.purchase_orders import (
        PurchaseOrderAccountingMetadataInfo,
        PurchaseOrderAdditionalCostRowInfo,
    )

    context, _ = create_mock_context()
    mock_po = _make_exhaustive_mock_po()

    cost_row = PurchaseOrderAdditionalCostRowInfo(
        id=201,
        additional_cost_id=1,
        group_id=8080,
        name="International Shipping",
        distribution_method="BY_VALUE",
        tax_rate_id=1,
        tax_rate=8.5,
        price=125.0,
        price_in_base=125.0,
        currency="USD",
        currency_conversion_rate=1.0,
        currency_conversion_rate_fix_date="2026-01-10T09:00:00+00:00",
    )
    acc_meta = PurchaseOrderAccountingMetadataInfo(
        id=301,
        purchase_order_id=12345,
        received_items_group_id=2001,
        integration_type="quickBooks",
        bill_id="BILL-2026-001",
        created_at="2026-01-15T11:30:00+00:00",
    )

    with (
        patch(f"{_PO_GET}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP, return_value=mock_po),
        # Override the module-level autouse fixture so this test can
        # assert the fetched values flow through.
        patch(
            _FETCH_PO_ADDITIONAL_COSTS, AsyncMock(return_value=[cost_row])
        ) as mock_fetch_costs,
        patch(
            _FETCH_PO_ACCOUNTING_META, AsyncMock(return_value=[acc_meta])
        ) as mock_fetch_meta,
    ):
        request = GetPurchaseOrderRequest(order_id=12345)
        result = await _get_purchase_order_impl(request, context)

    # Side-data helpers called with the right PO-scope identifiers
    mock_fetch_costs.assert_awaited_once()
    assert mock_fetch_costs.await_args.args[1] == 8080  # default_group_id
    mock_fetch_meta.assert_awaited_once()
    assert mock_fetch_meta.await_args.args[1] == 12345  # PO id

    # Fetched values flow through to the response
    assert len(result.additional_cost_rows) == 1
    assert result.additional_cost_rows[0].id == 201
    assert result.additional_cost_rows[0].name == "International Shipping"
    assert result.additional_cost_rows[0].price == 125.0
    assert result.additional_cost_rows[0].distribution_method == "BY_VALUE"

    assert len(result.accounting_metadata) == 1
    assert result.accounting_metadata[0].id == 301
    assert result.accounting_metadata[0].integration_type == "quickBooks"
    assert result.accounting_metadata[0].bill_id == "BILL-2026-001"


@pytest.mark.asyncio
async def test_get_purchase_order_markdown_uses_canonical_field_names():
    """Markdown labels use Pydantic field names (not prettified headers)
    so LLM consumers can't misread a section label as a different field
    (motivation: #346 follow-on, supplier_item_codes misread)."""
    from katana_mcp.tools.foundation.purchase_orders import (
        GetPurchaseOrderResponse,
        PurchaseOrderAccountingMetadataInfo,
        PurchaseOrderAdditionalCostRowInfo,
        PurchaseOrderRowInfo,
    )

    context, _ = create_mock_context()

    response = GetPurchaseOrderResponse(
        id=12345,
        order_no="PO-1022",
        status="NOT_RECEIVED",
        supplier_id=999,
        location_id=160411,
        entity_type="regular",
        default_group_id=8080,
        currency="USD",
        total=900.0,
        expected_arrival_date="2026-04-15T00:00:00+00:00",
        purchase_order_rows=[
            PurchaseOrderRowInfo(
                id=7001,
                variant_id=100,
                quantity=3.0,
                price_per_unit=250.0,
                total=750.0,
                arrival_date="2026-04-15T00:00:00+00:00",
            )
        ],
        additional_cost_rows=[
            PurchaseOrderAdditionalCostRowInfo(
                id=201,
                name="Shipping",
                price=125.0,
            )
        ],
        accounting_metadata=[
            PurchaseOrderAccountingMetadataInfo(
                id=301,
                purchase_order_id=12345,
                bill_id="BILL-2026-001",
            )
        ],
    )

    with patch(
        "katana_mcp.tools.foundation.purchase_orders._get_purchase_order_impl",
        new_callable=AsyncMock,
        return_value=response,
    ):
        result = await get_purchase_order(order_id=12345, context=context)

    text = _content_text(result)

    # Scalar PO fields — canonical names appear as labels
    assert "**order_no**: PO-1022" in text
    assert "**status**: NOT_RECEIVED" in text
    assert "**supplier_id**: 999" in text
    assert "**default_group_id**: 8080" in text
    assert "**billing_status**" not in text  # unset, should not appear

    # List-shaped fields — count-labeled header, canonical key
    assert "**purchase_order_rows** (1):" in text
    assert "**variant_id**: 100" in text
    assert "**additional_cost_rows** (1):" in text
    assert "**name**: Shipping" in text
    assert "**accounting_metadata** (1):" in text
    assert "**bill_id**: BILL-2026-001" in text

    # The canonical-name convention rules out these prettified labels:
    assert "**Supplier ID**" not in text
    assert "### Line Items" not in text


@pytest.mark.asyncio
async def test_get_purchase_order_surfaces_embedded_supplier():
    """When the PO payload embeds a ``Supplier``, every supplier field is
    surfaced under ``response.supplier`` and rendered inline in markdown
    (copilot feedback on #357 — supplier was dropped from the exhaustive
    shape)."""
    from katana_mcp.tools.foundation.purchase_orders import SupplierInfo

    context, _ = create_mock_context()
    mock_po = _make_exhaustive_mock_po()
    mock_po.supplier = _make_mock_supplier()

    with (
        patch(f"{_PO_GET}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP, return_value=mock_po),
    ):
        request = GetPurchaseOrderRequest(order_id=12345)
        result = await _get_purchase_order_impl(request, context)

    assert isinstance(result.supplier, SupplierInfo)
    assert result.supplier.id == 999
    assert result.supplier.name == "Acme Supplies"
    assert result.supplier.email == "orders@acme.example"
    assert result.supplier.phone == "+1-555-0100"
    assert result.supplier.currency == "USD"
    assert result.supplier.comment == "Preferred supplier"
    assert result.supplier.default_address_id == 7001
    assert result.supplier.created_at == "2026-01-01T00:00:00+00:00"
    assert result.supplier.updated_at == "2026-01-15T00:00:00+00:00"


@pytest.mark.asyncio
async def test_get_purchase_order_markdown_renders_supplier_inline():
    """Embedded supplier renders under a canonical ``**supplier**:`` block
    with per-field labels, matching the convention used for rows and
    accounting metadata."""
    from katana_mcp.tools.foundation.purchase_orders import (
        GetPurchaseOrderResponse,
        SupplierInfo,
    )

    context, _ = create_mock_context()
    response = GetPurchaseOrderResponse(
        id=12345,
        order_no="PO-1022",
        supplier=SupplierInfo(
            id=999,
            name="Acme Supplies",
            email="orders@acme.example",
            default_address_id=7001,
        ),
    )

    with patch(
        "katana_mcp.tools.foundation.purchase_orders._get_purchase_order_impl",
        new_callable=AsyncMock,
        return_value=response,
    ):
        result = await get_purchase_order(order_id=12345, context=context)
    text = _content_text(result)

    assert "**supplier**:" in text
    assert "**name**: Acme Supplies" in text
    assert "**email**: orders@acme.example" in text
    assert "**default_address_id**: 7001" in text


@pytest.mark.asyncio
async def test_get_purchase_order_markdown_renders_null_supplier_explicitly():
    """When the PO payload does not embed a supplier the canonical key
    still appears as ``**supplier**: null`` so an LLM consumer sees a
    concrete field value rather than a missing section."""
    from katana_mcp.tools.foundation.purchase_orders import GetPurchaseOrderResponse

    context, _ = create_mock_context()
    response = GetPurchaseOrderResponse(id=12345, order_no="PO-1022")

    with patch(
        "katana_mcp.tools.foundation.purchase_orders._get_purchase_order_impl",
        new_callable=AsyncMock,
        return_value=response,
    ):
        result = await get_purchase_order(order_id=12345, context=context)

    assert "**supplier**: null" in _content_text(result)


@pytest.mark.asyncio
async def test_get_purchase_order_rejects_empty_order_no():
    """Empty-string ``order_no`` is rejected up front rather than silently
    routing to the list-by-order_no branch (copilot feedback on #357 —
    truthiness checks misclassify valid-but-falsy inputs)."""
    context, _ = create_mock_context()
    request = GetPurchaseOrderRequest(order_no="")
    with pytest.raises(ValueError, match="order_no must not be empty"):
        await _get_purchase_order_impl(request, context)


@pytest.mark.asyncio
async def test_get_purchase_order_accepts_zero_order_id_via_is_none_check():
    """``order_id=0`` is a valid-but-falsy identifier. Explicit ``is None``
    branch selection (not truthiness) must route it to the get-by-id
    branch (copilot feedback on #357)."""
    context, _ = create_mock_context()
    mock_po = _make_exhaustive_mock_po()
    mock_po.id = 0  # the identifier under test

    with (
        patch(f"{_PO_GET}.asyncio_detailed", new_callable=AsyncMock) as mock_detailed,
        patch(_UNWRAP, return_value=mock_po),
    ):
        request = GetPurchaseOrderRequest(order_id=0)
        result = await _get_purchase_order_impl(request, context)

    mock_detailed.assert_awaited_once()
    # ``find_purchase_orders`` (the list-by-order_no branch) must NOT have
    # been exercised — the get-by-id path was taken.
    assert mock_detailed.await_args.kwargs["id"] == 0
    assert result.id == 0


@pytest.mark.asyncio
async def test_get_purchase_order_runs_side_data_fetches_concurrently():
    """The two side-data fetches are awaited via ``asyncio.gather`` rather
    than sequentially (copilot feedback on #357 — independent network
    calls shouldn't double latency)."""
    import asyncio as _asyncio

    fetch_additional = AsyncMock(return_value=[])
    fetch_accounting = AsyncMock(return_value=[])

    context, _ = create_mock_context()
    mock_po = _make_exhaustive_mock_po()

    with (
        patch(f"{_PO_GET}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP, return_value=mock_po),
        patch(_FETCH_PO_ADDITIONAL_COSTS, fetch_additional),
        patch(_FETCH_PO_ACCOUNTING_META, fetch_accounting),
        patch.object(_asyncio, "gather", wraps=_asyncio.gather) as spy_gather,
    ):
        request = GetPurchaseOrderRequest(order_id=12345)
        await _get_purchase_order_impl(request, context)

    # gather called with two awaitables — the two side-data coroutines.
    spy_gather.assert_called_once()
    assert len(spy_gather.call_args.args) == 2


@pytest.mark.asyncio
async def test_verify_order_document_embeds_po_without_nested_heading():
    """When the exhaustive PO is embedded under ``**purchase_order**:`` in
    the verify response the ``## PO …`` heading must be omitted — Markdown
    treats up-to-3-leading-spaces headings as top-level, which would break
    intended nesting (copilot feedback on #357)."""
    context, lifespan_ctx = create_mock_context()

    po_rows = [create_mock_po_row(variant_id=1, quantity=10.0, price=5.0)]
    mock_po = create_mock_po(order_id=1234, order_no="PO-VERIFY-001", rows=po_rows)
    mock_po_response = MagicMock()
    mock_po_response.status_code = 200
    mock_po_response.parsed = mock_po
    mock_variants = [create_mock_variant(variant_id=1, sku="WIDGET-001")]

    api_get_purchase_order.asyncio_detailed = AsyncMock(return_value=mock_po_response)
    lifespan_ctx.client.variants.list = AsyncMock(return_value=mock_variants)

    request = VerifyOrderDocumentRequest(
        order_id=1234,
        document_items=[
            DocumentItem(sku="WIDGET-001", quantity=10.0, unit_price=5.0),
        ],
    )

    result = await verify_order_document(
        order_id=request.order_id,
        document_items=[i.model_dump() for i in request.document_items],
        context=context,
    )
    text = _content_text(result)

    # The verify-level heading is present...
    assert "## Verification — PO 1234" in text
    # ...but the nested PO block does NOT reintroduce a PO heading
    # (indented or not). No ``## PO …`` anywhere in the output.
    assert "## PO " not in text
    # The canonical nesting label is present.
    assert "**purchase_order**:" in text


# ============================================================================
# list_purchase_orders — pattern v2
# ============================================================================


def _make_mock_list_po(
    *,
    id: int = 1,
    order_no: str | None = "PO-1",
    status: str | None = "NOT_RECEIVED",
    billing_status: str | None = "NOT_BILLED",
    entity_type: str | None = "regular",
    supplier_id: int | None = 10,
    location_id: int | None = 1,
    currency: str | None = "USD",
    order_created_date: datetime | None = None,
    expected_arrival_date: datetime | None = None,
    total: float | None = 999.0,
    rows: list | None = None,
) -> MagicMock:
    """Build a mock purchase order attrs object for list-tool tests."""
    po = MagicMock()
    po.id = id
    po.order_no = order_no if order_no is not None else UNSET
    po.status = status if status is not None else UNSET
    po.billing_status = billing_status if billing_status is not None else UNSET
    po.entity_type = entity_type if entity_type is not None else UNSET
    po.supplier_id = supplier_id if supplier_id is not None else UNSET
    po.location_id = location_id if location_id is not None else UNSET
    po.currency = currency if currency is not None else UNSET
    po.order_created_date = (
        order_created_date if order_created_date is not None else UNSET
    )
    po.expected_arrival_date = (
        expected_arrival_date if expected_arrival_date is not None else UNSET
    )
    po.total = total if total is not None else UNSET
    po.purchase_order_rows = rows if rows is not None else UNSET
    return po


def _make_mock_po_row(
    *,
    id: int = 1,
    variant_id: int = 100,
    quantity: float = 2.0,
    price_per_unit: float = 50.0,
    arrival_date: datetime | None = None,
) -> MagicMock:
    """Build a mock purchase order row."""
    r = MagicMock()
    r.id = id
    r.variant_id = variant_id
    r.quantity = quantity
    r.price_per_unit = price_per_unit
    r.arrival_date = arrival_date if arrival_date is not None else UNSET
    r.received_date = UNSET
    r.total = quantity * price_per_unit
    return r


@pytest.mark.asyncio
async def test_list_purchase_orders_server_side_filters_pass_through():
    """Server-side filters forward to find_purchase_orders kwargs."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    from katana_public_api_client.models import (
        FindPurchaseOrdersBillingStatus,
        FindPurchaseOrdersStatus,
        PurchaseOrderEntityType,
    )

    context, _ = create_mock_context()
    captured: dict = {}

    async def fake(**kwargs):
        captured.update(kwargs)
        return MagicMock()

    request = ListPurchaseOrdersRequest(
        ids=[1, 2, 3],
        order_no="PO-42",
        entity_type=PurchaseOrderEntityType.REGULAR,
        status=FindPurchaseOrdersStatus.NOT_RECEIVED,
        billing_status=FindPurchaseOrdersBillingStatus.NOT_BILLED,
        currency="USD",
        location_id=5,
        supplier_id=99,
        include_deleted=False,
        limit=25,
    )

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", side_effect=fake),
        patch(_UNWRAP_DATA, return_value=[]),
    ):
        await _list_purchase_orders_impl(request, context)

    assert captured["ids"] == [1, 2, 3]
    assert captured["order_no"] == "PO-42"
    assert captured["entity_type"] == PurchaseOrderEntityType.REGULAR
    assert captured["status"] == FindPurchaseOrdersStatus.NOT_RECEIVED
    assert captured["billing_status"] == FindPurchaseOrdersBillingStatus.NOT_BILLED
    assert captured["currency"] == "USD"
    assert captured["location_id"] == 5
    # supplier_id cast to float at the API boundary (generated-client signature
    # uses `float` historically); the tool-facing field is `int`.
    assert captured["supplier_id"] == 99.0
    assert isinstance(captured["supplier_id"], float)
    assert captured["include_deleted"] is False
    assert captured["limit"] == 25


@pytest.mark.asyncio
async def test_list_purchase_orders_page_short_circuit_single_page():
    """limit <= 250 with no client-side filter adds page=1."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()
    captured: dict = {}

    async def fake(**kwargs):
        captured.update(kwargs)
        return MagicMock()

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", side_effect=fake),
        patch(_UNWRAP_DATA, return_value=[]),
    ):
        await _list_purchase_orders_impl(ListPurchaseOrdersRequest(limit=10), context)

    assert captured["page"] == 1
    assert captured["limit"] == 10


@pytest.mark.asyncio
async def test_list_purchase_orders_caller_page_preserved():
    """Explicit page overrides the short-circuit."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()
    captured: dict = {}

    async def fake(**kwargs):
        captured.update(kwargs)
        return MagicMock()

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", side_effect=fake),
        patch(_UNWRAP_DATA, return_value=[]),
    ):
        await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(limit=50, page=2), context
        )

    assert captured["page"] == 2
    assert captured["limit"] == 50


@pytest.mark.asyncio
async def test_list_purchase_orders_skips_short_circuit_when_client_filter_set():
    """expected_arrival filter suppresses the page=1 short-circuit."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()
    captured: dict = {}

    async def fake(**kwargs):
        captured.update(kwargs)
        return MagicMock()

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", side_effect=fake),
        patch(_UNWRAP_DATA, return_value=[]),
    ):
        await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(
                limit=10, expected_arrival_after="2026-04-01T00:00:00Z"
            ),
            context,
        )

    assert "page" not in captured
    assert captured["limit"] == 10


@pytest.mark.asyncio
async def test_list_purchase_orders_pagination_meta_from_header():
    """x-pagination header populates PaginationMeta when page is set."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()

    mock_response = MagicMock()
    mock_response.headers = {
        "x-pagination": (
            '{"total_records":"200","total_pages":"4","offset":"0","page":"2",'
            '"first_page":"false","last_page":"false"}'
        )
    }

    async def fake(**kwargs):
        return mock_response

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", side_effect=fake),
        patch(_UNWRAP_DATA, return_value=[]),
    ):
        result = await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(page=2, limit=50), context
        )

    assert result.pagination is not None
    assert result.pagination.total_records == 200
    assert result.pagination.total_pages == 4
    assert result.pagination.page == 2
    assert result.pagination.first_page is False


@pytest.mark.asyncio
async def test_list_purchase_orders_caps_to_limit():
    """Safety net: slice results to request.limit."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()
    over_fetched = [_make_mock_list_po(id=i, order_no=f"PO-{i}") for i in range(100)]

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP_DATA, return_value=over_fetched),
    ):
        result = await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(limit=25), context
        )

    assert len(result.orders) == 25
    assert result.total_count == 25


@pytest.mark.asyncio
async def test_list_purchase_orders_limit_le_250_validation():
    """limit > 250 is rejected at the schema boundary."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
    )
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        ListPurchaseOrdersRequest(limit=500)


@pytest.mark.asyncio
async def test_list_purchase_orders_invalid_date_raises():
    """Malformed ISO-8601 surfaces as ValueError."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP_DATA, return_value=[]),
        pytest.raises(ValueError, match=r"Invalid ISO-8601.*created_after"),
    ):
        await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(created_after="not-a-date"), context
        )


@pytest.mark.asyncio
async def test_list_purchase_orders_date_z_normalization():
    """Trailing Z/z normalize to +00:00 and forward as datetimes."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()
    captured: dict = {}

    async def fake(**kwargs):
        captured.update(kwargs)
        return MagicMock()

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", side_effect=fake),
        patch(_UNWRAP_DATA, return_value=[]),
    ):
        await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(
                created_after="2026-01-01T00:00:00Z",
                updated_before="2026-04-01T00:00:00z",
            ),
            context,
        )

    assert isinstance(captured["created_at_min"], datetime)
    assert isinstance(captured["updated_at_max"], datetime)


@pytest.mark.asyncio
async def test_list_purchase_orders_expected_arrival_client_side_filter():
    """expected_arrival_after/before filters post-fetch."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()
    pos = [
        _make_mock_list_po(
            id=1,
            order_no="PO-1",
            expected_arrival_date=datetime(2026, 4, 15, tzinfo=UTC),
        ),
        _make_mock_list_po(
            id=2,
            order_no="PO-2",
            expected_arrival_date=datetime(2027, 1, 1, tzinfo=UTC),
        ),
    ]

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP_DATA, return_value=pos),
    ):
        result = await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(
                expected_arrival_after="2026-04-01T00:00:00Z",
                expected_arrival_before="2026-04-30T00:00:00Z",
            ),
            context,
        )

    assert result.total_count == 1
    assert result.orders[0].id == 1


@pytest.mark.asyncio
async def test_list_purchase_orders_include_rows_populates_details():
    """include_rows=True exposes per-PO line item detail."""
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersRequest,
        _list_purchase_orders_impl,
    )

    context, _ = create_mock_context()
    mock_po = _make_mock_list_po(
        id=7,
        rows=[
            _make_mock_po_row(id=1, variant_id=100, quantity=5, price_per_unit=10.0),
            _make_mock_po_row(id=2, variant_id=200, quantity=2, price_per_unit=25.0),
        ],
    )

    with (
        patch(f"{_PO_FIND}.asyncio_detailed", new_callable=AsyncMock),
        patch(_UNWRAP_DATA, return_value=[mock_po]),
    ):
        result_with = await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(include_rows=True), context
        )
        result_without = await _list_purchase_orders_impl(
            ListPurchaseOrdersRequest(include_rows=False), context
        )

    assert result_with.orders[0].rows is not None
    assert len(result_with.orders[0].rows) == 2
    assert result_with.orders[0].row_count == 2
    assert result_without.orders[0].rows is None
    # row_count should still reflect the true count regardless of include_rows
    assert result_without.orders[0].row_count == 2


# ============================================================================
# format=json (purchase_orders tools)
# ============================================================================


def _content_text(result) -> str:
    return result.content[0].text


@pytest.mark.asyncio
async def test_list_purchase_orders_format_json_returns_json():
    from katana_mcp.tools.foundation.purchase_orders import (
        ListPurchaseOrdersResponse,
    )

    context, _ = create_mock_context()

    with patch(
        "katana_mcp.tools.foundation.purchase_orders._list_purchase_orders_impl",
        new_callable=AsyncMock,
    ) as mock_impl:
        mock_impl.return_value = ListPurchaseOrdersResponse(
            orders=[], total_count=0, pagination=None
        )
        result = await list_purchase_orders(format="json", context=context)

    data = json.loads(_content_text(result))
    assert data["total_count"] == 0


@pytest.mark.asyncio
async def test_get_purchase_order_format_json_returns_json():
    from katana_mcp.tools.foundation.purchase_orders import GetPurchaseOrderResponse

    context, _ = create_mock_context()

    with patch(
        "katana_mcp.tools.foundation.purchase_orders._get_purchase_order_impl",
        new_callable=AsyncMock,
    ) as mock_impl:
        mock_impl.return_value = GetPurchaseOrderResponse(
            id=5,
            order_no="PO-5",
            supplier_id=1,
            location_id=1,
            currency="USD",
            status="NOT_RECEIVED",
            entity_type="regular",
            expected_arrival_date=None,
            total=100.0,
            purchase_order_rows=[],
            additional_cost_rows=[],
            accounting_metadata=[],
        )
        result = await get_purchase_order(order_id=5, format="json", context=context)

    data = json.loads(_content_text(result))
    assert data["id"] == 5
    assert data["order_no"] == "PO-5"


@pytest.mark.asyncio
async def test_verify_order_document_format_json_returns_json():
    from katana_mcp.tools.foundation.purchase_orders import (
        VerifyOrderDocumentResponse,
    )

    context, _ = create_mock_context()

    with patch(
        "katana_mcp.tools.foundation.purchase_orders._verify_order_document_impl",
        new_callable=AsyncMock,
    ) as mock_impl:
        mock_impl.return_value = VerifyOrderDocumentResponse(
            order_id=5,
            matches=[],
            discrepancies=[],
            suggested_actions=[],
            overall_status="match",
            message="All items match",
        )
        result = await verify_order_document(
            order_id=5,
            document_items=[DocumentItem(sku="A", quantity=1, unit_price=1.0)],
            format="json",
            context=context,
        )

    data = json.loads(_content_text(result))
    assert data["order_id"] == 5
    assert data["overall_status"] == "match"
