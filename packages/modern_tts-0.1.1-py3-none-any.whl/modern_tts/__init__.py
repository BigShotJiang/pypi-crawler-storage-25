"""Modern TTS: A unified, extensible toolkit for LLM-based Text-to-Speech synthesis."""

from modern_tts.core.base import TTSModel
from modern_tts.core.config import ModelConfig, BackendConfig
from modern_tts.core.pipeline import TTSPipeline
from modern_tts.core.registry import register_model, list_models
from modern_tts.core.types import (
    AudioOutput,
    Language,
    SynthesisMode,
    TextInput,
    TTSResult,
)

# Trigger auto-discovery and registration of all built-in model adapters
import modern_tts.models as _models_module  # noqa: F401

__version__ = "0.1.0"

__all__ = [
    "TTSModel",
    "TTSPipeline",
    "TTSResult",
    "TextInput",
    "AudioOutput",
    "BackendConfig",
    "Language",
    "ModelConfig",
    "SynthesisMode",
    "list_models",
    "register_model",
]
