"""Modern TTS utilities."""
