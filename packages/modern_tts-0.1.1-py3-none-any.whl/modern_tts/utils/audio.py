"""Audio saving and loading utilities."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from modern_tts.core.types import AudioOutput


def load_audio(
    path: str | Path,
    target_sr: int = 24000,
    mono: bool = True,
    dtype: str = "float32",
) -> "AudioOutput":
    """Load an audio file and normalize to the target format.

    Tries multiple backends in order: ``torchaudio``, ``librosa``,
    ``soundfile``, and falls back to ``wave`` for raw WAV.
    """
    from modern_tts.core.types import AudioOutput

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {path}")

    arr, sr = _load_with_best_backend(str(path), target_sr, mono)
    return AudioOutput(
        waveform=arr.astype(dtype),
        sample_rate=sr,
        channels=1 if mono else (arr.ndim if arr.ndim > 1 else 1),
    )


def save_audio(audio: "AudioOutput", path: str | Path) -> None:
    """Save an AudioOutput to a file.

    Tries ``soundfile`` first, then ``scipy.io.wavfile``.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import soundfile as sf

        sf.write(path, audio.waveform, audio.sample_rate)
        return
    except Exception:
        pass

    try:
        from scipy.io import wavfile

        # Normalize to int16
        arr = audio.waveform
        if arr.max() <= 1.0:
            arr = (arr * 32767).astype(np.int16)
        wavfile.write(path, audio.sample_rate, arr)
        return
    except Exception:
        pass

    raise RuntimeError(
        f"Could not save audio to {path}. "
        "Install 'soundfile' or 'scipy' for audio I/O."
    )


def _load_with_best_backend(
    path: str,
    target_sr: int,
    mono: bool,
) -> tuple[np.ndarray, int]:
    """Attempt loading with available libraries."""
    # Prefer torchaudio
    try:
        import torchaudio

        waveform, sr = torchaudio.load(path)
        if mono and waveform.ndim > 1:
            waveform = waveform.mean(dim=0)
        if sr != target_sr:
            resampler = torchaudio.transforms.Resample(sr, target_sr)
            waveform = resampler(waveform.unsqueeze(0)).squeeze(0)
            sr = target_sr
        return waveform.numpy(), sr
    except Exception:
        pass

    # Fallback to librosa
    try:
        import librosa

        arr, sr = librosa.load(path, sr=target_sr, mono=mono)
        return arr, sr
    except Exception:
        pass

    # Fallback to soundfile
    try:
        import soundfile as sf

        arr, sr = sf.read(path, dtype="float32")
        if mono and arr.ndim > 1:
            arr = arr.mean(axis=1)
        if sr != target_sr:
            arr = _resample_simple(arr, sr, target_sr)
            sr = target_sr
        return arr, sr
    except Exception:
        pass

    # Last resort: built-in wave
    import struct
    import wave

    with wave.open(path, "rb") as w:
        sr = w.getframerate()
        n_channels = w.getnchannels()
        n_frames = w.getnframes()
        raw = w.readframes(n_frames)
        fmt = f"{n_frames * n_channels}h"
        samples = struct.unpack(fmt, raw)
        arr = np.array(samples, dtype=np.float32) / 32768.0
        if n_channels > 1 and mono:
            arr = arr.reshape(-1, n_channels).mean(axis=1)
        if sr != target_sr:
            arr = _resample_simple(arr, sr, target_sr)
            sr = target_sr
        return arr, sr


def _resample_simple(arr: np.ndarray, orig_sr: int, target_sr: int) -> np.ndarray:
    """Simple 1D linear resampling."""
    if orig_sr == target_sr:
        return arr
    ratio = target_sr / orig_sr
    n = int(len(arr) * ratio)
    idx = np.linspace(0, len(arr) - 1, n)
    idx_l = np.floor(idx).astype(int)
    idx_r = np.minimum(idx_l + 1, len(arr) - 1)
    frac = idx - idx_l
    return arr[idx_l] * (1 - frac) + arr[idx_r] * frac
