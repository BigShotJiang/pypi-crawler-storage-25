"""Entry point for ``python -m modern_tts``."""

from modern_tts.cli import main
import sys

sys.exit(main())
