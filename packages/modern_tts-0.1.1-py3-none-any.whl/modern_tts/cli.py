"""Command-line interface for Modern TTS.

Usage::

    mtts list                          # List all models
    mtts synthesize <model> <text>     # Synthesize text to audio
    mtts clone <model> <text> <ref>    # Voice cloning
    mtts batch <model> <dir>           # Batch synthesize text files
    mtts bench <text>                  # Benchmark models
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

from modern_tts.core.config import BackendConfig
from modern_tts.core.pipeline import TTSPipeline
from modern_tts.core.registry import list_models


def _print_models(args: argparse.Namespace) -> int:
    """List registered models."""
    models = list_models(
        language=args.language,
        mode=args.mode,
    )
    if args.json:
        print(json.dumps(models, indent=2, ensure_ascii=False))
        return 0

    from rich.console import Console
    from rich.table import Table

    console = Console()
    table = Table(title="Registered TTS Models")
    table.add_column("Model ID", style="cyan", no_wrap=True)
    table.add_column("Languages")
    table.add_column("Modes")
    table.add_column("Module")

    for m in models:
        table.add_row(
            m["model_id"],
            ", ".join(sorted(m["supported_languages"]))[:40],
            ", ".join(sorted(m["supported_modes"])),
            m["module"],
        )
    console.print(table)
    return 0


def _synthesize(args: argparse.Namespace) -> int:
    """Synthesize text to audio."""
    from rich.console import Console

    console = Console()

    # Read text from file or argument
    if args.text_file:
        text_path = Path(args.text_file)
        if not text_path.exists():
            console.print(f"[red]Error:[/red] File not found: {text_path}")
            return 1
        text = text_path.read_text(encoding="utf-8")
    else:
        text = args.text

    backend = BackendConfig(
        device=args.device,
        dtype=args.dtype,
    )

    console.print(f"Loading [bold cyan]{args.model}[/bold cyan]...")
    pipe = TTSPipeline(model_id=args.model, backend=backend)

    console.print(f"Synthesizing [bold]{len(text)} chars[/bold]...")
    t0 = time.time()
    result = pipe(
        text=text,
        task=args.task,
        language=args.language,
        speaker_id=args.speaker_id,
    )
    elapsed = time.time() - t0

    console.print(f"\n[green]Done in {elapsed:.2f}s[/green] "
                  f"({result.audio.duration:.2f}s audio)")

    if args.output:
        result.save(args.output)
        console.print(f"Saved to [bold]{args.output}[/bold]")
    else:
        # Print metadata
        console.print(f"Audio: {result.audio.sample_rate}Hz, "
                      f"{result.audio.duration:.2f}s")

    return 0


def _clone(args: argparse.Namespace) -> int:
    """Clone a voice and synthesize text."""
    from rich.console import Console

    console = Console()

    if args.text_file:
        text_path = Path(args.text_file)
        if not text_path.exists():
            console.print(f"[red]Error:[/red] File not found: {text_path}")
            return 1
        text = text_path.read_text(encoding="utf-8")
    else:
        text = args.text

    ref_path = Path(args.reference)
    if not ref_path.exists():
        console.print(f"[red]Error:[/red] Reference audio not found: {ref_path}")
        return 1

    backend = BackendConfig(device=args.device, dtype=args.dtype)
    pipe = TTSPipeline(model_id=args.model, backend=backend)

    console.print(f"Cloning voice from [bold]{ref_path.name}[/bold]...")
    t0 = time.time()
    result = pipe(
        text=text,
        task="clone",
        language=args.language,
        reference_audio=str(ref_path),
    )
    elapsed = time.time() - t0

    console.print(f"\n[green]Done in {elapsed:.2f}s[/green]")

    if args.output:
        result.save(args.output)
        console.print(f"Saved to [bold]{args.output}[/bold]")

    return 0


def _batch(args: argparse.Namespace) -> int:
    """Batch synthesize text files in a directory."""
    from rich.console import Console
    from rich.progress import Progress, TextColumn, BarColumn, TaskProgressColumn

    console = Console()
    src_dir = Path(args.source)
    if not src_dir.is_dir():
        console.print(f"[red]Error:[/red] Not a directory: {src_dir}")
        return 1

    exts = {e.strip().lower() for e in args.ext.split(",")}
    files = sorted(
        f for f in src_dir.iterdir()
        if f.is_file() and f.suffix.lower() in exts
    )
    if not files:
        console.print(f"[yellow]Warning:[/yellow] No text files found in {src_dir}")
        return 0

    backend = BackendConfig(device=args.device, dtype=args.dtype)
    pipe = TTSPipeline(model_id=args.model, backend=backend)

    out_dir = Path(args.output) if args.output else src_dir / "audio"
    out_dir.mkdir(exist_ok=True)

    console.print(f"Processing {len(files)} files with [bold cyan]{args.model}[/bold cyan]...")

    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Synthesizing...", total=len(files))
        for f in files:
            try:
                text = f.read_text(encoding="utf-8")
                result = pipe(text, task=args.task, language=args.language)
                out_path = out_dir / f"{f.stem}.wav"
                result.save(out_path)
            except Exception as exc:
                console.print(f"[red]Failed on {f.name}:[/red] {exc}")
            progress.advance(task)

    console.print(f"\n[green]Saved to {out_dir}[/green]")
    return 0


def _benchmark(args: argparse.Namespace) -> int:
    """Benchmark multiple models on the same text."""
    from rich.console import Console
    from rich.table import Table

    console = Console()

    if args.text_file:
        text_path = Path(args.text_file)
        if not text_path.exists():
            console.print(f"[red]Error:[/red] File not found: {text_path}")
            return 1
        text = text_path.read_text(encoding="utf-8")
    else:
        text = args.text

    models = [m.strip() for m in args.models.split(",")]
    backend = BackendConfig(device=args.device, dtype=args.dtype)

    console.print(f"Benchmarking {len(models)} models on [bold]{len(text)} chars[/bold]\n")

    results: list[dict[str, Any]] = []
    for model_id in models:
        console.print(f"Running [cyan]{model_id}[/cyan]...", end=" ")
        try:
            pipe = TTSPipeline(model_id=model_id, backend=backend)
            t0 = time.time()
            result = pipe(text, language=args.language)
            elapsed = time.time() - t0
            console.print(f"[green]{elapsed:.2f}s[/green] "
                          f"({result.audio.duration:.2f}s audio)")
            results.append({
                "model": model_id,
                "time": elapsed,
                "duration": result.audio.duration,
            })
            pipe.unload()
        except Exception as exc:
            console.print(f"[red]FAILED: {exc}[/red]")
            results.append({"model": model_id, "time": None, "duration": None})

    table = Table(title="Benchmark Results")
    table.add_column("Model", style="cyan")
    table.add_column("Time", justify="right")
    table.add_column("Audio Duration", justify="right")
    for r in results:
        time_str = f"{r['time']:.2f}s" if r["time"] is not None else "N/A"
        dur_str = f"{r['duration']:.2f}s" if r["duration"] is not None else "N/A"
        table.add_row(r["model"], time_str, dur_str)
    console.print()
    console.print(table)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="mtts",
        description="Unified CLI for LLM-based Text-to-Speech synthesis.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # ------------------------------------------------------------------ #
    # list
    # ------------------------------------------------------------------ #
    list_parser = subparsers.add_parser("list", help="List registered models")
    list_parser.add_argument("--language", default=None, help="Filter by language code")
    list_parser.add_argument("--mode", default=None, help="Filter by mode (speak, clone, emotion, style)")
    list_parser.add_argument("--json", action="store_true", help="Output as JSON")
    list_parser.set_defaults(func=_print_models)

    # ------------------------------------------------------------------ #
    # synthesize
    # ------------------------------------------------------------------ #
    synth_parser = subparsers.add_parser("synthesize", help="Synthesize text to audio")
    synth_parser.add_argument("model", help="Model ID (e.g. melotts-zh)")
    synth_parser.add_argument("text", nargs="?", default=None, help="Text to synthesize")
    synth_parser.add_argument("--text-file", "-f", default=None, help="Path to text file")
    synth_parser.add_argument("-t", "--task", default="speak", help="Task: speak, emotion, style")
    synth_parser.add_argument("-l", "--language", default="auto", help="Language code")
    synth_parser.add_argument("--speaker-id", default=None, help="Speaker ID for multi-speaker models")
    synth_parser.add_argument("-o", "--output", default=None, help="Output audio file path")
    synth_parser.add_argument("--device", default="auto", help="Device: auto, cuda, cpu")
    synth_parser.add_argument("--dtype", default="auto", help="Dtype: auto, float16, bfloat16, float32")
    synth_parser.set_defaults(func=_synthesize)

    # ------------------------------------------------------------------ #
    # clone
    # ------------------------------------------------------------------ #
    clone_parser = subparsers.add_parser("clone", help="Clone a voice and synthesize")
    clone_parser.add_argument("model", help="Model ID")
    clone_parser.add_argument("text", nargs="?", default=None, help="Text to synthesize")
    clone_parser.add_argument("--text-file", "-f", default=None, help="Path to text file")
    clone_parser.add_argument("reference", help="Path to reference audio file")
    clone_parser.add_argument("-l", "--language", default="auto", help="Language code")
    clone_parser.add_argument("-o", "--output", default=None, help="Output audio file path")
    clone_parser.add_argument("--device", default="auto", help="Device")
    clone_parser.add_argument("--dtype", default="auto", help="Dtype")
    clone_parser.set_defaults(func=_clone)

    # ------------------------------------------------------------------ #
    # batch
    # ------------------------------------------------------------------ #
    batch_parser = subparsers.add_parser("batch", help="Batch synthesize text files")
    batch_parser.add_argument("model", help="Model ID")
    batch_parser.add_argument("source", help="Source directory containing text files")
    batch_parser.add_argument("-o", "--output", default=None, help="Output directory (default: <source>/audio/)")
    batch_parser.add_argument("--ext", default=".txt,.md", help="Comma-separated file extensions")
    batch_parser.add_argument("-t", "--task", default="speak", help="Task")
    batch_parser.add_argument("-l", "--language", default="auto", help="Language code")
    batch_parser.add_argument("--device", default="auto", help="Device")
    batch_parser.add_argument("--dtype", default="auto", help="Dtype")
    batch_parser.set_defaults(func=_batch)

    # ------------------------------------------------------------------ #
    # bench
    # ------------------------------------------------------------------ #
    bench_parser = subparsers.add_parser("bench", help="Benchmark multiple models")
    bench_parser.add_argument("text", nargs="?", default="Hello, this is a test of text to speech synthesis.", help="Text to benchmark")
    bench_parser.add_argument("--text-file", default=None, help="Path to text file")
    bench_parser.add_argument("--models", default="melotts-zh,chattts,cosyvoice-300m", help="Comma-separated model IDs")
    bench_parser.add_argument("-l", "--language", default="auto", help="Language code")
    bench_parser.add_argument("--device", default="auto", help="Device")
    bench_parser.add_argument("--dtype", default="auto", help="Dtype")
    bench_parser.set_defaults(func=_benchmark)

    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 1

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
