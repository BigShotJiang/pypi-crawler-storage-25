"""Abstract base class for all TTS models."""

from __future__ import annotations

import gc
import os
import tempfile
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

from modern_tts.core.types import TextInput

if TYPE_CHECKING:
    from modern_tts.core.config import BackendConfig, ModelConfig
    from modern_tts.core.types import AudioOutput, TTSResult


class TTSModel(ABC):
    """Abstract base class for all TTS model adapters.

    To add a new model, subclass ``TTSModel``, implement the required methods,
    and decorate the class with ``@register_model("model_id")``.

    The base class provides shared utilities for device resolution, audio I/O,
    and lifecycle management so that subclasses stay focused on model-specific logic.
    """

    # Override in subclass -------------------------------------------------
    MODEL_CARD: str = ""
    SUPPORTED_LANGUAGES: set[str] = set()
    SUPPORTED_MODES: set[str] = {"speak"}
    REQUIREMENTS: list[str] = []

    # Audio output defaults
    DEFAULT_SAMPLE_RATE: int = 24000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        self.config = config
        self.backend = backend
        self._model: Any = None
        self._processor: Any = None
        self._vocoder: Any = None
        self._is_loaded = False

    @property
    @abstractmethod
    def model_id(self) -> str:
        """Return the canonical model identifier."""
        ...

    @property
    def is_loaded(self) -> bool:
        return self._is_loaded

    @abstractmethod
    def load(self) -> None:
        """Load model weights and processor into memory.

        Implementations should set ``self._is_loaded = True`` on success.
        """
        ...

    @abstractmethod
    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        """Synthesize speech from ``text``.

        Args:
            text: Normalized text input.
            **kwargs: Additional per-call overrides.

        Returns:
            A unified ``TTSResult``.
        """
        ...

    # ------------------------------------------------------------------ #
    # Optional task methods with default implementations
    # ------------------------------------------------------------------ #

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> "TTSResult":
        """Clone a voice from reference audio and synthesize text."""
        raise NotImplementedError(
            f"Model '{self.model_id}' does not support voice cloning."
        )

    def speak_with_emotion(
        self,
        text: TextInput,
        emotion: str = "neutral",
        **kwargs: Any,
    ) -> "TTSResult":
        """Synthesize speech with a specific emotion."""
        text.emotion = emotion
        return self.synthesize(text, **kwargs)

    def stream(
        self,
        text: TextInput,
        chunk_size: int = 512,
        **kwargs: Any,
    ) -> "TTSResult":
        """Stream synthesis for low-latency playback."""
        raise NotImplementedError(
            f"Model '{self.model_id}' does not support streaming synthesis."
        )

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    def unload(self) -> None:
        """Release model weights from memory."""
        self._model = None
        self._processor = None
        self._vocoder = None
        self._is_loaded = False
        gc.collect()

    def _ensure_loaded(self) -> None:
        if not self._is_loaded:
            self.load()

    def __enter__(self) -> TTSModel:
        self._ensure_loaded()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.unload()

    # ------------------------------------------------------------------ #
    # Shared utilities (device / dtype)
    # ------------------------------------------------------------------ #

    def _resolve_device(self, device: str | None = None) -> str:
        """Resolve device string to a concrete device identifier."""
        import torch

        d = device or (self.backend.device if self.backend else "auto")
        if d == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        return d

    def _resolve_dtype(self, dtype: str | None = None) -> Any:
        """Resolve dtype string to a concrete ``torch.dtype``."""
        import torch

        dt = dtype or (self.backend.dtype if self.backend else "auto")
        if dt in ("auto", "float16"):
            return torch.float16
        if dt == "bfloat16" and torch.cuda.is_available():
            return torch.bfloat16
        if dt == "float32":
            return torch.float32
        return torch.float32

    # ------------------------------------------------------------------ #
    # Shared utilities (audio I/O)
    # ------------------------------------------------------------------ #

    def _load_reference_audio(
        self,
        audio: "AudioOutput | str | Path",
        target_sr: int | None = None,
    ) -> np.ndarray:
        """Load a reference audio waveform from various sources."""
        if isinstance(audio, np.ndarray):
            return audio
        from modern_tts.utils.audio import load_audio

        target_sr = target_sr or self.DEFAULT_SAMPLE_RATE
        if isinstance(audio, (str, Path)):
            loaded = load_audio(str(audio), target_sr=target_sr)
            return loaded.waveform  # type: ignore[return-value]
        return audio.waveform  # type: ignore[return-value]

    def _save_temp_audio(
        self,
        audio: "AudioOutput",
        suffix: str = ".wav",
    ) -> str:
        """Write an ``AudioOutput`` to a temporary file."""
        import soundfile as sf

        fd, path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        sf.write(path, audio.waveform, audio.sample_rate)
        return path

    # ------------------------------------------------------------------ #
    # Shared utilities (text splitting)
    # ------------------------------------------------------------------ #

    def _split_text(
        self,
        text: "TextInput",
        max_chars: int = 500,
    ) -> list["TextInput"]:
        """Split long text into chunks for batch synthesis.

        Args:
            text: Input text.
            max_chars: Maximum characters per chunk.

        Returns:
            List of ``TextInput`` chunks.
        """
        raw = text.get_text()
        if len(raw) <= max_chars:
            return [text]

        # Simple sentence-based splitting (supports CJK and Latin punctuation)
        import re

        sentences = re.split(r"(?<=[.!?。！？])\s*", raw)
        sentences = [s.strip() for s in sentences if s.strip()]
        chunks: list[TextInput] = []
        current = ""

        for sentence in sentences:
            if len(current) + len(sentence) > max_chars and current:
                chunks.append(
                    TextInput(
                        data=current.strip(),
                        language=text.language,
                        speaker_id=text.speaker_id,
                        emotion=text.emotion,
                        style=text.style,
                        speed=text.speed,
                    )
                )
                current = sentence
            else:
                current = current + sentence if current else sentence

        if current.strip():
            chunks.append(
                TextInput(
                    data=current.strip(),
                    language=text.language,
                    speaker_id=text.speaker_id,
                    emotion=text.emotion,
                    style=text.style,
                    speed=text.speed,
                )
            )

        return chunks

    def _batch_synthesize(
        self,
        text: "TextInput",
        max_chars: int = 500,
        **kwargs: Any,
    ) -> "TTSResult":
        """Synthesize long text by splitting into chunks and concatenating audio.

        This is a generic fallback. Subclasses with smarter internal batching
        should override ``synthesize`` directly.
        """
        from modern_tts.core.types import AudioOutput, TTSResult

        chunks = self._split_text(text, max_chars=max_chars)
        waveforms: list[np.ndarray] = []

        for chunk in chunks:
            result = self.synthesize(chunk, **kwargs)
            waveforms.append(result.audio.waveform)

        if not waveforms:
            empty = np.zeros(0, dtype=np.float32)
            return TTSResult(
                audio=AudioOutput(
                    waveform=empty,
                    sample_rate=self.DEFAULT_SAMPLE_RATE,
                ),
                text=text.get_text(),
                model_id=self.model_id,
            )

        full_waveform = np.concatenate(waveforms)
        return TTSResult(
            audio=AudioOutput(
                waveform=full_waveform,
                sample_rate=result.audio.sample_rate,
            ),
            text=text.get_text(),
            model_id=self.model_id,
        )
