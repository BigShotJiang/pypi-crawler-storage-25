"""Generic base class for Text-to-Audio LLM style TTS models.

This module provides ``TextToAudioLLMModel`` — a reusable abstraction for
models that follow the "text encoder + audio decoder / vocoder" pattern
used by models such as Parler-TTS, VALL-E, and many future releases.

Design goals
------------
* **Minimal boilerplate** for new models — often just a few class attrs.
* **Pluggable loading** — works with ``transformers`` Auto classes,
  custom modelling files (``trust_remote_code``), or subclass overrides.
* **Future-proof** — new Text-to-Audio architectures only need to override
  ``_tokenize`` and/or ``_decode_audio`` if they deviate from the standard
  flow.
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

import numpy as np

from modern_tts.core.base import TTSModel

if TYPE_CHECKING:
    from modern_tts.core.config import BackendConfig, ModelConfig
    from modern_tts.core.types import AudioOutput, TTSResult, TextInput


class TextToAudioLLMModel(TTSModel):
    """Reusable base for Text-to-Audio LLM TTS models.

    Subclasses configure behaviour through **class attributes** and only
    need to implement ``model_id`` (property). Everything else has
    sensible defaults.
    """

    # --- Class-level configuration --------------------------------------

    HF_PATH: str = ""
    """Default HuggingFace hub ID (or local path)."""

    PROCESSOR_CLS: str = "transformers.AutoTokenizer"
    """Dotted import path for the tokenizer class."""

    MODEL_CLS: str = "transformers.AutoModelForTextToWaveform"
    """Dotted import path for the model class.

    Common choices:
    * ``"transformers.AutoModelForTextToWaveform"``
    * ``"transformers.AutoModelForCausalLM"``
    * ``"transformers.AutoModel"``
    """

    VOCODER_CLS: str = ""
    """Optional dotted import path for a vocoder class."""

    TRUST_REMOTE_CODE: bool = True
    """Passed to ``from_pretrained`` for both processor and model."""

    LOW_CPU_MEM_USAGE: bool = True
    """Passed to ``from_pretrained`` for the model."""

    LANGUAGE_MAP: dict[str, str | None] = {}
    """Map from short language codes to model-specific tags."""

    DEFAULT_MAX_NEW_TOKENS: int = 256
    """Fallback ``max_new_tokens`` when not provided by user or config."""

    DEFAULT_GENERATION_KWARGS: dict[str, Any] = {}
    """Extra kwargs forwarded to ``model.generate()`` — subclass defaults."""

    # --- Construction ---------------------------------------------------

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._hf_path = self._resolve_hf_path()

    def _resolve_hf_path(self) -> str:
        if self.config.model_path:
            return str(self.config.model_path)
        return self.HF_PATH

    # --- Loading --------------------------------------------------------

    def load(self) -> None:
        """Load processor and model using the configured class paths.

        Subclasses that need custom loading logic (e.g. composite models
        or custom PyTorch weights) should override this method.
        """
        if not self.PROCESSOR_CLS and not self.MODEL_CLS:
            raise NotImplementedError(
                f"{self.__class__.__name__} does not set PROCESSOR_CLS / MODEL_CLS. "
                f"Override load() to implement custom loading logic."
            )

        device = self._resolve_device()
        dtype = self._resolve_dtype()

        if self.PROCESSOR_CLS:
            processor_cls = self._import_cls(self.PROCESSOR_CLS)
            self._processor = processor_cls.from_pretrained(
                self._hf_path,
                trust_remote_code=self.TRUST_REMOTE_CODE,
            )

        if self.MODEL_CLS:
            model_cls = self._import_cls(self.MODEL_CLS)
            load_kwargs: dict[str, Any] = {
                "trust_remote_code": self.TRUST_REMOTE_CODE,
                "low_cpu_mem_usage": self.LOW_CPU_MEM_USAGE,
            }
            if dtype is not None:
                load_kwargs["torch_dtype"] = dtype
            if device != "cpu":
                load_kwargs["device_map"] = device
            else:
                load_kwargs["device_map"] = None

            self._model = model_cls.from_pretrained(self._hf_path, **load_kwargs)

        if self.VOCODER_CLS:
            vocoder_cls = self._import_cls(self.VOCODER_CLS)
            self._vocoder = vocoder_cls.from_pretrained(self._hf_path)

        self._is_loaded = True

    # --- Inference ------------------------------------------------------

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        """Synthesize ``text`` into speech.

        Subclasses may override this method for smarter strategies
        (streaming, chunked generation, etc.).
        """
        self._ensure_loaded()
        return self._synthesize_single(text, **kwargs)

    def _synthesize_single(self, text: TextInput, **kwargs: Any) -> TTSResult:
        """Run a single forward pass on ``text``."""
        import torch

        inputs = self._tokenize(text, **kwargs)
        inputs = {
            k: v.to(self._model.device) if hasattr(v, "to") else v
            for k, v in inputs.items()
        }

        gen_kwargs = {
            "max_new_tokens": kwargs.get(
                "max_new_tokens",
                self.config.max_new_tokens or self.DEFAULT_MAX_NEW_TOKENS,
            ),
            "do_sample": kwargs.get("do_sample", False),
            "temperature": kwargs.get(
                "temperature", self.config.temperature or 0.7
            ),
            "top_p": kwargs.get("top_p", self.config.top_p or 0.9),
            "top_k": kwargs.get("top_k", self.config.top_k or 50),
        }
        gen_kwargs.update(self.DEFAULT_GENERATION_KWARGS)
        gen_kwargs.update(
            {k: v for k, v in kwargs.items() if k not in ("language", "task")}
        )

        with torch.no_grad():
            outputs = self._model.generate(**inputs, **gen_kwargs)

        waveform = self._decode_audio(outputs, **kwargs)
        return self._build_result(waveform, text, **kwargs)

    # --- Input / output builders (override points) ----------------------

    def _tokenize(self, text: TextInput, **kwargs: Any) -> dict[str, Any]:
        """Convert ``text`` into the dict expected by ``model.generate()``.

        The default implementation uses the tokenizer to encode text::

            tokenizer(text, return_tensors="pt")

        Subclasses may override for:
        * Speaker token injection
        * Emotion / style tokens
        * Multi-turn context
        """
        raw_text = text.get_text()
        return self._processor(
            raw_text,
            return_tensors="pt",
        )

    def _decode_audio(self, outputs: Any, **kwargs: Any) -> np.ndarray:
        """Decode model outputs to a waveform.

        Default assumes the model outputs audio tokens that can be decoded
        to a waveform. Subclasses should override for custom vocoders.
        """
        # If model returns raw waveform directly
        if hasattr(outputs, "cpu") and outputs.ndim >= 2:
            arr = outputs.cpu().numpy()
            if arr.ndim > 1:
                arr = arr.squeeze()
            return arr.astype(np.float32)

        # Try to use vocoder if available
        if self._vocoder is not None:
            return self._vocoder.decode(outputs).cpu().numpy().astype(np.float32)

        # Fallback: return zeros (subclass must override)
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement _decode_audio"
        )

    def _build_result(self, waveform: np.ndarray, text: TextInput, **kwargs: Any) -> TTSResult:
        """Build the final ``TTSResult`` from decoded waveform."""
        from modern_tts.core.types import AudioOutput, TTSResult

        sample_rate = kwargs.get("sample_rate", self.config.sample_rate or self.DEFAULT_SAMPLE_RATE)
        return TTSResult(
            audio=AudioOutput(
                waveform=waveform.astype(np.float32),
                sample_rate=sample_rate,
            ),
            text=text.get_text(),
            language=text.language,
            speaker_id=text.speaker_id,
            model_id=self.model_id,
        )

    # --- Language helpers -----------------------------------------------

    def _map_language(self, lang: str | None) -> str | None:
        """Map a short language code to the model-specific tag."""
        if lang is None:
            return None
        return self.LANGUAGE_MAP.get(lang, lang)

    # --- Internal utilities ---------------------------------------------

    @staticmethod
    def _import_cls(dotted_path: str) -> Any:
        """Dynamically import a class from a dotted module path."""
        module_path, _, class_name = dotted_path.rpartition(".")
        if not module_path:
            raise ValueError(
                f"Invalid dotted class path: {dotted_path!r}. "
                f"Expected 'module.submodule.ClassName'."
            )
        module = importlib.import_module(module_path)
        try:
            return getattr(module, class_name)
        except AttributeError as exc:
            raise ImportError(
                f"Class '{class_name}' not found in module '{module_path}'."
            ) from exc
