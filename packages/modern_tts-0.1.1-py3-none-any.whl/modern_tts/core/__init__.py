"""Modern TTS core modules."""
