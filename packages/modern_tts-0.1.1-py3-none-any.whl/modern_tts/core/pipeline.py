"""High-level TTS pipeline for end-to-end speech synthesis."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig, PipelineConfig
from modern_tts.core.registry import create_model, get_model_class
from modern_tts.core.types import AudioOutput, TextInput, TTSResult


class TTSPipeline:
    """Unified TTS pipeline with automatic model loading and text preprocessing.

    Usage::

        pipe = TTSPipeline("melotts-zh")
        result = pipe("你好世界，这是语音合成测试。")
        result.save("output.wav")
    """

    def __init__(
        self,
        model_id: str | None = None,
        model_config: ModelConfig | None = None,
        backend: BackendConfig | None = None,
        config_path: str | Path | None = None,
    ) -> None:
        """Initialize the pipeline.

        Args:
            model_id: Canonical model identifier (e.g. ``"melotts-zh"``).
            model_config: Optional per-model configuration override.
            backend: Optional global backend configuration.
            config_path: Path to a YAML pipeline config file.
        """
        self._model: TTSModel | None = None
        self._backend = backend or BackendConfig()
        self._model_config = model_config
        self._config_path = config_path
        self._pipeline_config: PipelineConfig | None = None

        if config_path:
            self._pipeline_config = PipelineConfig.from_yaml(config_path)
            self._backend = self._pipeline_config.default_backend

        if model_id:
            self._init_model(model_id)

    def _init_model(self, model_id: str) -> None:
        if self._pipeline_config and model_id in self._pipeline_config.models:
            cfg = self._pipeline_config.models[model_id]
        else:
            cfg = self._model_config or ModelConfig(model_id=model_id)

        backend = cfg.backend or self._backend
        self._model = create_model(model_id, config=cfg, backend=backend)
        self._model.load()

    def __call__(
        self,
        text: str | Path | TextInput,
        task: str = "speak",
        language: str | None = None,
        speaker_id: str | None = None,
        **kwargs: Any,
    ) -> TTSResult:
        """Run TTS on text.

        Args:
            text: Raw text string, file path, or pre-wrapped ``TextInput``.
            task: Task type (``"speak"``, ``"clone"``, ``"emotion"``, ``"style"``).
            language: Target language code (``"zh"``, ``"en"``, ``"auto"``).
            speaker_id: Speaker identifier for multi-speaker models.
            **kwargs: Additional per-call arguments passed to the model.

        Returns:
            Unified ``TTSResult``.
        """
        if self._model is None:
            raise RuntimeError("No model has been initialized. Provide a model_id at construction.")

        if isinstance(text, TextInput):
            text_input = text
        elif isinstance(text, (str, Path)):
            text_input = TextInput(data=text)
        else:
            text_input = TextInput(data=str(text))

        if language:
            text_input.language = language
        if speaker_id:
            text_input.speaker_id = speaker_id

        if task == "speak":
            return self._model.synthesize(text_input, **kwargs)
        elif task == "clone":
            reference = kwargs.pop("reference_audio", None)
            if reference is None:
                raise ValueError("Voice cloning requires 'reference_audio' kwarg.")
            return self._model.clone(text_input, reference_audio=reference, **kwargs)
        elif task == "emotion":
            emotion = kwargs.pop("emotion", text_input.emotion or "neutral")
            return self._model.speak_with_emotion(text_input, emotion=emotion, **kwargs)
        elif task == "streaming":
            return self._model.stream(text_input, **kwargs)
        else:
            return self._model.synthesize(text_input, task=task, **kwargs)

    @property
    def model(self) -> TTSModel | None:
        return self._model

    def switch_model(self, model_id: str) -> None:
        """Hot-swap to another registered model."""
        if self._model is not None:
            self._model.unload()
        self._init_model(model_id)

    def unload(self) -> None:
        if self._model is not None:
            self._model.unload()

    def __enter__(self) -> TTSPipeline:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.unload()
