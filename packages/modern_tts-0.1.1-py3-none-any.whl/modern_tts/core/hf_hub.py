"""HuggingFace Hub utilities for Modern TTS.

Provides helpers to download model weights and configs from the HuggingFace
Hub so that custom-code adapters do not have to re-implement caching logic.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any


def download_hf_model(
    repo_id: str,
    local_dir: str | Path | None = None,
    cache_dir: str | Path | None = None,
    revision: str | None = None,
    allow_patterns: list[str] | None = None,
    ignore_patterns: list[str] | None = None,
    **kwargs: Any,
) -> Path:
    """Download a model repository from the HuggingFace Hub.

    This is a thin wrapper around ``huggingface_hub.snapshot_download`` that
    returns a ``Path`` and provides sensible defaults for TTS models.

    Args:
        repo_id: HuggingFace repository ID (e.g. ``"IndexTeam/Index-TTS"``).
        local_dir: Optional local directory to download files into. If
            provided, files are downloaded *into* this directory (no cache
            sub-directory). Mutually exclusive with ``cache_dir``.
        cache_dir: Optional HuggingFace cache directory. If ``None``, uses the
            default HF cache (``~/.cache/huggingface/hub``).
        revision: Specific git revision to download (branch, tag, or commit).
        allow_patterns: Only download files matching these glob patterns.
        ignore_patterns: Skip files matching these glob patterns.
        **kwargs: Additional arguments forwarded to ``snapshot_download``.

    Returns:
        Path to the downloaded model directory.

    Raises:
        RuntimeError: If the model cannot be downloaded (network issue,
            repo not found, etc.).
    """
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise RuntimeError(
            "huggingface_hub is required to download models. "
            "Install with: pip install huggingface_hub"
        ) from exc

    download_kwargs: dict[str, Any] = {
        "repo_id": repo_id,
        "local_dir": local_dir,
        "cache_dir": cache_dir,
        "revision": revision,
        "allow_patterns": allow_patterns,
        "ignore_patterns": ignore_patterns,
    }
    # Remove None values so snapshot_download uses its own defaults
    download_kwargs = {k: v for k, v in download_kwargs.items() if v is not None}
    download_kwargs.update(kwargs)

    try:
        path = snapshot_download(**download_kwargs)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to download model '{repo_id}' from HuggingFace Hub. "
            f"Please check the repository exists and you have network access."
        ) from exc

    return Path(path)


def get_hf_model_path(
    repo_id: str,
    model_path: str | Path | None = None,
    cache_dir: str | Path | None = None,
) -> Path:
    """Resolve a model path, downloading from HF Hub if necessary.

    If ``model_path`` is provided and exists locally, it is returned as-is.
    Otherwise the model is downloaded from the HuggingFace Hub.

    Args:
        repo_id: HuggingFace repository ID.
        model_path: Optional local path override.
        cache_dir: Optional HF cache directory.

    Returns:
        Path to the model directory.
    """
    if model_path is not None:
        p = Path(model_path)
        if p.exists():
            return p.resolve()

    return download_hf_model(repo_id, cache_dir=cache_dir)
