"""Repository manager for downloading and caching official TTS code repositories.

This module provides helpers to automatically clone git repositories that contain
model-specific code (e.g. ``indextts``, ``GLM-TTS``) so users do not have to
manually set ``PYTHONPATH``.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


DEFAULT_REPO_CACHE = Path.home() / ".cache" / "modern-tts" / "repos"


def ensure_repo(
    repo_url: str,
    repo_name: str | None = None,
    cache_dir: str | Path | None = None,
    branch: str | None = None,
    depth: int = 1,
) -> Path:
    """Ensure a git repository is cloned locally, cloning if necessary.

    Args:
        repo_url: Git repository URL (e.g. ``https://github.com/zai-org/GLM-TTS.git``).
        repo_name: Local directory name inside ``cache_dir``. Defaults to the URL
            basename with ``.git`` stripped.
        cache_dir: Base cache directory. Defaults to ``~/.cache/modern-tts/repos``.
        branch: Specific git branch/tag to clone. If ``None``, uses the default
            branch.
        depth: ``--depth`` value for shallow clones. Set to ``0`` for a full clone.

    Returns:
        Absolute path to the local repository root.

    Raises:
        RuntimeError: If ``git`` is not installed or the clone fails.
    """
    if repo_name is None:
        repo_name = repo_url.rstrip("/").split("/")[-1].replace(".git", "")

    cache = Path(cache_dir) if cache_dir else DEFAULT_REPO_CACHE
    repo_path = cache / repo_name

    if repo_path.exists():
        return repo_path.resolve()

    cache.mkdir(parents=True, exist_ok=True)

    cmd = ["git", "clone"]
    if depth > 0:
        cmd.extend(["--depth", str(depth)])
    if branch:
        cmd.extend(["--branch", branch])
    cmd.extend([repo_url, str(repo_path)])

    try:
        result = subprocess.run(
            cmd, check=True, capture_output=True, text=True, timeout=300
        )
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"Failed to clone repository '{repo_url}' into {repo_path}.\n"
            f"stdout: {exc.stdout}\nstderr: {exc.stderr}\n"
            f"Please ensure 'git' is installed and you have network access."
        ) from exc
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"Git command not found. Please install git to automatically download '{repo_name}'.\n"
            f"On Ubuntu/Debian: sudo apt-get install git\n"
            f"On macOS: brew install git"
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"Cloning '{repo_url}' timed out after 300 seconds.\n"
            f"You can manually clone it and set the environment variable or config.extra path."
        ) from exc

    return repo_path.resolve()


def inject_repo_path(repo_path: str | Path) -> None:
    """Add a repository path to the front of ``sys.path`` if not already present."""
    p = str(Path(repo_path).resolve())
    if p not in sys.path:
        sys.path.insert(0, p)
