"""Unified data types for Modern TTS."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Literal

import numpy as np


class SynthesisMode(str, Enum):
    """Synthesis mode presets."""

    SPEAK = "speak"
    CLONE = "clone"
    EMOTION = "emotion"
    STYLE = "style"
    STREAMING = "streaming"


class Language(str, Enum):
    """Common language codes."""

    AUTO = "auto"
    ZH = "zh"
    EN = "en"
    YUE = "yue"  # Cantonese
    JA = "ja"
    KO = "ko"
    FR = "fr"
    DE = "de"
    ES = "es"
    RU = "ru"
    AR = "ar"
    HI = "hi"
    PT = "pt"
    IT = "it"
    NL = "nl"
    PL = "pl"
    TR = "tr"
    VI = "vi"
    TH = "th"
    ID = "id"
    MULTI = "multi"


@dataclass
class TextInput:
    """Normalized text input wrapper.

    Accepts raw strings, file paths (for long text files), or structured content.
    """

    data: str | Path
    language: str = "auto"
    speaker_id: str | None = None
    emotion: str | None = None
    style: str | None = None
    speed: float = 1.0  # speaking rate multiplier

    # Optional metadata
    source: str | None = None

    def is_file(self) -> bool:
        if isinstance(self.data, Path):
            return True
        if isinstance(self.data, str):
            # Only treat as file path if it's reasonably short and looks like a path
            if len(self.data) > 1024 or "\n" in self.data:
                return False
            try:
                return Path(self.data).exists()
            except OSError:
                return False
        return False

    def get_text(self) -> str:
        """Resolve to a plain text string."""
        if self.is_file():
            return Path(self.data).read_text(encoding="utf-8")
        return str(self.data)


@dataclass
class AudioOutput:
    """Audio output container."""

    waveform: np.ndarray
    sample_rate: int = 24000
    channels: int = 1
    dtype: str = "float32"

    # Metadata
    duration: float | None = None
    model_id: str | None = None

    def __post_init__(self) -> None:
        if self.duration is None and self.waveform is not None:
            self.duration = len(self.waveform) / self.sample_rate

    def save(self, path: str | Path) -> None:
        """Save waveform to an audio file."""
        from modern_tts.utils.audio import save_audio

        save_audio(self, path)


@dataclass
class TTSResult:
    """Unified TTS result container."""

    audio: AudioOutput
    text: str | None = None
    language: str | None = None
    speaker_id: str | None = None
    duration: float | None = None
    model_id: str | None = None

    # Model-specific extra outputs (phonemes, latencies, etc.)
    extra: dict[str, Any] = field(default_factory=dict)

    def save(self, path: str | Path) -> None:
        """Convenience alias for saving the audio."""
        self.audio.save(path)
