"""BERT-VITS2 adapter.

Models:
    - bertvits2-jp: Japanese-centric TTS with BERT phoneme guidance
    - bertvits2-zh: Chinese variant
    - bertvits2-en: English variant

References:
    - https://github.com/fishaudio/Bert-VITS2
    - https://github.com/Stardust-minus/Bert-VITS2

Note:
    Real inference requires manual setup (git clone + model weights).
    This adapter is registered for API compatibility.
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


class _BertVITS2Base(TTSModel):
    """Shared base for BERT-VITS2 variants."""

    MODEL_CARD = "https://github.com/fishaudio/Bert-VITS2"
    SUPPORTED_MODES = {"speak", "emotion"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 44100

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    def load(self) -> None:
        raise RuntimeError(
            f"{self.model_id} requires manual setup. "
            "Clone https://github.com/fishaudio/Bert-VITS2 and download model weights. "
            "No pip-installable package is currently available."
        )

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        raise RuntimeError("Unreachable — load() must be called first.")

    def speak_with_emotion(
        self,
        text: TextInput,
        emotion: str = "neutral",
        **kwargs: Any,
    ) -> TTSResult:
        text.emotion = emotion
        return self.synthesize(text, **kwargs)

    def _default_language(self) -> str:
        return "auto"


@register_model("bertvits2-jp")
class BertVITS2JP(_BertVITS2Base):
    """BERT-VITS2 Japanese: BERT-guided VITS for high-quality Japanese TTS.

    Uses Japanese BERT for precise phoneme and prosody control.
    """

    SUPPORTED_LANGUAGES = {"ja", "en", "auto", "multi"}

    @property
    def model_id(self) -> str:
        return "bertvits2-jp"

    def _default_language(self) -> str:
        return "ja"


@register_model("bertvits2-zh")
class BertVITS2ZH(_BertVITS2Base):
    """BERT-VITS2 Chinese: BERT-guided VITS for Chinese TTS."""

    SUPPORTED_LANGUAGES = {"zh", "en", "auto", "multi"}

    @property
    def model_id(self) -> str:
        return "bertvits2-zh"

    def _default_language(self) -> str:
        return "zh"


@register_model("bertvits2-en")
class BertVITS2EN(_BertVITS2Base):
    """BERT-VITS2 English: BERT-guided VITS for English TTS."""

    SUPPORTED_LANGUAGES = {"en", "auto", "multi"}

    @property
    def model_id(self) -> str:
        return "bertvits2-en"

    def _default_language(self) -> str:
        return "en"
