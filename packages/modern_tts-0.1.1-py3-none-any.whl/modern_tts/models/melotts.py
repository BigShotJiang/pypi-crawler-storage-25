"""MeloTTS adapter.

Models:
    - melotts-zh: Chinese TTS
    - melotts-en: English TTS

References:
    - https://github.com/myshell-ai/MeloTTS
"""

from __future__ import annotations

import os
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


def _check_deps() -> None:
    try:
        from melo.api import TTS  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "MeloTTS requires 'melotts' and its dependencies. "
            "Install with: uv pip install git+https://github.com/myshell-ai/MeloTTS.git --no-deps "
            "cn2an pypinyin jieba mecab-python3 unidic-lite pykakasi eng-to-ipa g2p-en fugashi jamo gruut"
        ) from exc


@register_model("melotts-zh")
class MeloTTSZH(TTSModel):
    """MeloTTS Chinese: fast, lightweight neural TTS."""

    MODEL_CARD = "https://github.com/myshell-ai/MeloTTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "emotion"}
    REQUIREMENTS = ["melotts", "torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 44100

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._model: Any = None
        self._speaker_id: Any = None

    @property
    def model_id(self) -> str:
        return "melotts-zh"

    def load(self) -> None:
        _check_deps()
        from melo.api import TTS

        os.environ.setdefault("HF_HOME", "/mnt/hdd/modern-tts-models/hf_cache")
        os.environ.setdefault("MELO_MODELS_DIR", "/mnt/hdd/modern-tts-models/melo_models")

        self._model = TTS(language="ZH", device="cpu")
        self._speaker_id = self._model.hps.data.spk2id["ZH"]
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        import numpy as np

        gen_text = text.get_text()
        audio = self._model.tts_to_file(gen_text, self._speaker_id, output_path=None)

        if not isinstance(audio, np.ndarray):
            audio = np.array(audio)

        return TTSResult(
            audio=AudioOutput(
                waveform=audio.astype(np.float32),
                sample_rate=self._model.hps.data.sampling_rate,
            ),
            text=gen_text,
            language=text.language or "zh",
            model_id=self.model_id,
        )


@register_model("melotts-en")
class MeloTTSEN(MeloTTSZH):
    """MeloTTS English variant."""

    def load(self) -> None:
        _check_deps()
        from melo.api import TTS

        os.environ.setdefault("HF_HOME", "/mnt/hdd/modern-tts-models/hf_cache")
        os.environ.setdefault("MELO_MODELS_DIR", "/mnt/hdd/modern-tts-models/melo_models")

        self._model = TTS(language="EN", device="cpu")
        self._speaker_id = self._model.hps.data.spk2id["EN"]
        self._is_loaded = True

    @property
    def model_id(self) -> str:
        return "melotts-en"

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        result = super().synthesize(text, **kwargs)
        result.language = "en"
        return result
