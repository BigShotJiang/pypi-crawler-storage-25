"""GLM-TTS adapter (Zhipu AI / 智谱AI).

Models:
    - glm-tts: zero-shot voice cloning TTS with LLM + Flow Matching

References:
    - https://github.com/zai-org/GLM-TTS
    - https://huggingface.co/zai-org/GLM-TTS

Note:
    GLM-TTS is a zero-shot voice-cloning model. It always requires a
    reference audio prompt. Use ``task="clone"`` (or ``clone()``) and
    provide ``reference_audio``.

    The official repository is **not** on PyPI. You must clone it and add it
    to your ``PYTHONPATH``.

Requirements:
    - Official GLM-TTS repository:
      ``git clone https://github.com/zai-org/GLM-TTS.git``
    - Set environment variable:
      ``export GLM_TTS_REPO_PATH=/path/to/GLM-TTS``
    - Install its dependencies (see upstream ``requirements.txt``).
"""

from __future__ import annotations

import importlib.util
import os
import shutil
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import numpy as np
import torch

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.hf_hub import get_hf_model_path
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@contextmanager
def _chdir(path: str | Path) -> Any:
    """Temporarily change the working directory."""
    old = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old)


@register_model("glm-tts")
class GLMTTS(TTSModel):
    """GLM-TTS: controllable & emotion-expressive zero-shot TTS.

    Uses a Llama-based LLM for speech-token generation and a Flow Matching
    model for waveform synthesis.
    """

    MODEL_CARD = "https://huggingface.co/zai-org/GLM-TTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = [
        "torch", "torchaudio", "transformers", "onnxruntime",
        "sentencepiece", "safetensors", "hyperpyyaml", "peft",
    ]
    DEFAULT_SAMPLE_RATE = 24000

    HF_PATH = "zai-org/GLM-TTS"

    # Upstream modules that must be importable
    _REQUIRED_MODULES = [
        "cosyvoice.cli.frontend",
        "llm.glmtts",
        "utils.yaml_util",
        "utils.tts_model_util",
        "utils.audio",
        "utils.file_utils",
        "utils.seed_util",
    ]

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._work_dir: Path | None = None
        self._repo_path: Path | None = None
        self._model_path: Path | None = None

        # Components (populated in load())
        self._frontend: Any = None
        self._text_frontend: Any = None
        self._speech_tokenizer: Any = None
        self._llm: Any = None
        self._token2wav: Any = None
        self._device: torch.device | None = None

        # Generation settings
        self._sample_rate = config.extra.get("sample_rate", self.DEFAULT_SAMPLE_RATE)
        self._use_phoneme = config.extra.get("use_phoneme", False)
        self._sample_method = config.extra.get("sample_method", "ras")
        self._seed = config.extra.get("seed", 42)
        self._use_cache = config.extra.get("use_cache", True)

    @property
    def model_id(self) -> str:
        return "glm-tts"

    def _check_deps(self) -> None:
        """Verify that the upstream GLM-TTS repository modules are importable.

        If the modules are not found, this method will automatically clone
        the official repository into ``~/.cache/modern-tts/repos/GLM-TTS``
        and add it to ``sys.path`` so the user does not need to set any
        environment variables.
        """
        import sys

        def _try_find_spec(mod: str) -> bool:
            try:
                return importlib.util.find_spec(mod) is not None
            except (ModuleNotFoundError, ImportError):
                return False

        # Quick pass: all modules already available
        if all(_try_find_spec(mod) for mod in self._REQUIRED_MODULES):
            return

        # 1. Try manual override (config.extra or env var)
        repo_path = (
            self.config.extra.get("glm_tts_repo_path")
            or os.environ.get("GLM_TTS_REPO_PATH")
        )
        if repo_path:
            p = str(Path(repo_path).resolve())
            if p not in sys.path:
                sys.path.insert(0, p)
            missing = [m for m in self._REQUIRED_MODULES if not _try_find_spec(m)]
            if not missing:
                return

        # 2. Auto-download the official repository
        try:
            from modern_tts.core.repo_manager import ensure_repo, inject_repo_path

            repo_path = ensure_repo(
                "https://github.com/zai-org/GLM-TTS.git",
                repo_name="GLM-TTS",
            )
            inject_repo_path(repo_path)
            missing = [m for m in self._REQUIRED_MODULES if not _try_find_spec(m)]
            if missing:
                raise ImportError(
                    f"GLM-TTS repository downloaded to {repo_path} but some modules are still missing.\n"
                    f"Missing modules: {', '.join(missing)}\n"
                    f"Please install dependencies:\n"
                    f"  pip install -r {repo_path}/requirements.txt"
                )
        except RuntimeError as exc:
            raise ImportError(
                f"GLM-TTS requires the official repository but auto-download failed: {exc}\n"
                "Steps:\n"
                "  1. git clone https://github.com/zai-org/GLM-TTS.git\n"
                "  2. cd GLM-TTS && pip install -r requirements.txt\n"
                "  3. export PYTHONPATH=/absolute/path/to/GLM-TTS:$PYTHONPATH\n"
                "  4. export GLM_TTS_REPO_PATH=/absolute/path/to/GLM-TTS"
            ) from exc

    def _resolve_repo_path(self) -> Path:
        """Resolve the path to the official GLM-TTS repository.

        Checks (in order):
        1. ``config.extra["glm_tts_repo_path"]``
        2. ``GLM_TTS_REPO_PATH`` environment variable
        3. Inferred from ``llm.glmtts`` module location (set by auto-download or PYTHONPATH)
        4. Auto-download the repository
        """
        # 1. Manual override
        repo_path = (
            self.config.extra.get("glm_tts_repo_path")
            or os.environ.get("GLM_TTS_REPO_PATH")
        )
        if repo_path:
            p = Path(repo_path)
            if p.exists():
                return p.resolve()

        # 2. Infer from module location (works when auto-downloaded or PYTHONPATH is set)
        spec = importlib.util.find_spec("llm.glmtts")
        if spec and spec.origin:
            # spec.origin is .../GLM-TTS/llm/glmtts.py
            return Path(spec.origin).parent.parent.resolve()

        # 3. Auto-download
        from modern_tts.core.repo_manager import ensure_repo

        return ensure_repo(
            "https://github.com/zai-org/GLM-TTS.git",
            repo_name="GLM-TTS",
        )

    def _prepare_work_dir(self, model_path: Path, repo_path: Path) -> Path:
        """Create a working directory with the ckpt/ layout expected by upstream."""
        cache_root = Path.home() / ".cache" / "modern-tts" / "glm-tts-work"
        work_dir = cache_root / f"sr{self._sample_rate}"
        work_dir.mkdir(parents=True, exist_ok=True)

        ckpt_dir = work_dir / "ckpt"
        ckpt_dir.mkdir(exist_ok=True)

        # Map HF repo subdirs to ckpt/ subdirs
        subdirs = {
            "llm": "llm",
            "speech_tokenizer": "speech_tokenizer",
            "flow": "flow",
            "hift": "hift",
            "vocos2d": "vocos2d",
            "vq32k-phoneme-tokenizer": "vq32k-phoneme-tokenizer",
        }
        for src_name, dst_name in subdirs.items():
            src = model_path / src_name
            dst = ckpt_dir / dst_name
            if dst.exists() or dst.is_symlink():
                dst.unlink() if dst.is_symlink() else shutil.rmtree(dst)
            if src.exists():
                # Prefer symlink for space efficiency, fall back to copy
                try:
                    dst.symlink_to(src, target_is_directory=src.is_dir())
                except OSError:
                    if src.is_dir():
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)

        # Copy frontend artifacts from the official repo (not on HF Hub)
        frontend_src = repo_path / "frontend"
        frontend_dst = work_dir / "frontend"
        if frontend_src.exists() and not frontend_dst.exists():
            if frontend_src.is_dir():
                shutil.copytree(frontend_src, frontend_dst)
            else:
                frontend_dst.mkdir(parents=True, exist_ok=True)
                shutil.copy2(frontend_src, frontend_dst)
        elif not frontend_dst.exists():
            frontend_dst.mkdir(parents=True, exist_ok=True)

        # Copy configs from the official repo (needed by llm.glmtts)
        configs_src = repo_path / "configs"
        configs_dst = work_dir / "configs"
        if configs_src.exists() and not configs_dst.exists():
            if configs_src.is_dir():
                shutil.copytree(configs_src, configs_dst)
            else:
                configs_dst.mkdir(parents=True, exist_ok=True)
                shutil.copy2(configs_src, configs_dst)
        elif not configs_dst.exists():
            configs_dst.mkdir(parents=True, exist_ok=True)

        return work_dir

    def load(self) -> None:
        self._check_deps()

        # Resolve paths
        self._repo_path = self._resolve_repo_path()
        self._model_path = get_hf_model_path(
            self.HF_PATH,
            model_path=self.config.model_path,
        )
        self._work_dir = self._prepare_work_dir(self._model_path, self._repo_path)

        device_str = self._resolve_device()
        self._device = torch.device(device_str if device_str != "auto" else ("cuda" if torch.cuda.is_available() else "cpu"))

        # Upstream imports (safe because _check_deps passed)
        from cosyvoice.cli.frontend import SpeechTokenizer, TTSFrontEnd, TextFrontEnd
        from llm.glmtts import GLMTTS as _GLMTTS
        from transformers import AutoTokenizer, LlamaForCausalLM
        from utils import tts_model_util, yaml_util
        from utils.audio import mel_spectrogram
        from functools import partial

        with _chdir(self._work_dir):
            # ---- Speech Tokenizer ----
            speech_tokenizer_path = self._work_dir / "ckpt" / "speech_tokenizer"
            _model, _feature_extractor = yaml_util.load_speech_tokenizer(str(speech_tokenizer_path))
            self._speech_tokenizer = SpeechTokenizer(_model, _feature_extractor)

            # ---- Frontends ----
            if self._sample_rate == 32000:
                feat_extractor = partial(
                    mel_spectrogram, sampling_rate=32000, hop_size=640,
                    n_fft=2560, num_mels=80, win_size=2560, fmin=0, fmax=8000, center=False,
                )
            else:
                feat_extractor = partial(
                    mel_spectrogram, sampling_rate=24000, hop_size=480,
                    n_fft=1920, num_mels=80, win_size=1920, fmin=0, fmax=8000, center=False,
                )

            glm_tokenizer = AutoTokenizer.from_pretrained(
                str(self._work_dir / "ckpt" / "vq32k-phoneme-tokenizer"),
                trust_remote_code=True,
            )
            tokenize_fn = lambda text: glm_tokenizer.encode(text)  # noqa: E731

            self._frontend = TTSFrontEnd(
                tokenize_fn,
                self._speech_tokenizer,
                feat_extractor,
                str(self._work_dir / "frontend" / "campplus.onnx"),
                "",  # spk2info.pt is optional
                self._device,
            )
            self._text_frontend = TextFrontEnd(use_phoneme=self._use_phoneme)

            # ---- LLM ----
            llama_path = self._work_dir / "ckpt" / "llm"
            self._llm = _GLMTTS(
                llama_cfg_path=str(llama_path / "config.json"),
                mode="PRETRAIN",
            )
            self._llm.llama = LlamaForCausalLM.from_pretrained(
                str(llama_path),
                torch_dtype=torch.float32,
            ).to(self._device)
            self._llm.llama_embedding = self._llm.llama.model.embed_tokens

            # Special tokens
            from glmtts_inference import get_special_token_ids  # type: ignore[import-not-found]
            special_token_ids = get_special_token_ids(self._frontend.tokenize_fn)
            self._llm.set_runtime_vars(special_token_ids=special_token_ids)

            # ---- Flow + Vocoder ----
            flow_ckpt = self._work_dir / "ckpt" / "flow" / "flow.pt"
            flow_config = self._work_dir / "ckpt" / "flow" / "config.yaml"
            flow = yaml_util.load_flow_model(str(flow_ckpt), str(flow_config), self._device)
            self._token2wav = tts_model_util.Token2Wav(
                flow, sample_rate=self._sample_rate, device=str(self._device)
            )

        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        """Synthesize speech.

        GLM-TTS is a zero-shot cloning model; for ``task="speak"`` we
        fall back to cloning if a default reference audio is configured,
        otherwise raise an error directing the user to ``clone()``.
        """
        default_ref = self.config.extra.get("default_reference_audio")
        ref = kwargs.pop("reference_audio", default_ref)
        if ref is None:
            raise RuntimeError(
                "GLM-TTS is a zero-shot voice-cloning model and requires "
                "a reference audio. Use TTSPipeline with task='clone' and "
                "reference_audio=..., or set 'default_reference_audio' in "
                "ModelConfig.extra."
            )
        return self.clone(text, reference_audio=ref, **kwargs)

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        """Clone a voice from reference audio and synthesize text."""
        self._ensure_loaded()

        # Resolve reference audio to a file path
        if isinstance(reference_audio, (str, Path)):
            ref_path = str(reference_audio)
        else:
            ref_path = self._save_temp_audio(reference_audio)

        if not os.path.exists(ref_path):
            raise FileNotFoundError(f"Reference audio not found: {ref_path}")

        # Upstream imports
        from glmtts_inference import generate_long  # type: ignore[import-not-found]
        from utils import seed_util  # type: ignore[import-not-found]

        # Monkey-patch: upstream code uses torch.npu (Ascend) without guarding
        if not hasattr(torch, "npu"):
            class _FakeNPU:
                @staticmethod
                def is_available() -> bool:
                    return False
            torch.npu = _FakeNPU()  # type: ignore[attr-defined]

        with _chdir(self._work_dir):
            # Normalize text
            prompt_text = kwargs.pop("prompt_text", "")
            norm_prompt_text = self._text_frontend.text_normalize(prompt_text) + " " if prompt_text else ""
            syn_text = self._text_frontend.text_normalize(text.get_text())

            if self._use_phoneme:
                syn_text = self._text_frontend.g2p_infer(syn_text)

            # Extract features from reference audio
            prompt_text_token = self._frontend._extract_text_token(norm_prompt_text)
            prompt_speech_token = self._frontend._extract_speech_token([ref_path])
            speech_feat = self._frontend._extract_speech_feat(ref_path, sample_rate=self._sample_rate)
            embedding = self._frontend._extract_spk_embedding(ref_path)

            cache_speech_token = [prompt_speech_token.squeeze().tolist()]
            flow_prompt_token = torch.tensor(cache_speech_token, dtype=torch.int32).to(self._device)

            # Cache for generation
            cache = {
                "cache_text": [norm_prompt_text],
                "cache_text_token": [prompt_text_token],
                "cache_speech_token": cache_speech_token,
                "use_cache": self._use_cache,
            }

            seed_util.set_seed(self._seed)

            tts_speech, _, _, _ = generate_long(
                frontend=self._frontend,
                text_frontend=self._text_frontend,
                llm=self._llm,
                flow=self._token2wav,
                text_info=["", syn_text],
                cache=cache,
                device=self._device,
                embedding=embedding,
                seed=self._seed,
                sample_method=self._sample_method,
                flow_prompt_token=flow_prompt_token,
                speech_feat=speech_feat,
                use_phoneme=self._use_phoneme,
            )

        # Post-process audio
        audio_data = tts_speech.squeeze().cpu().numpy()
        audio_data = np.clip(audio_data, -1.0, 1.0)
        waveform = audio_data.astype(np.float32)

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=self._sample_rate,
            ),
            text=text.get_text(),
            language=text.language,
            model_id=self.model_id,
        )

    def unload(self) -> None:
        """Release model weights and clear caches."""
        self._frontend = None
        self._text_frontend = None
        self._speech_tokenizer = None
        self._llm = None
        self._token2wav = None
        self._device = None
        super().unload()
