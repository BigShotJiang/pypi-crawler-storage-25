"""Fish Speech adapter.

Models:
    - fishspeech-1.5: multilingual TTS with voice cloning

References:
    - https://github.com/fishaudio/fish-speech

Note:
    Real inference requires manual setup (git clone + model weights).
    The fish-speech pip package has build dependencies that are not satisfied
    in this environment (pyaudio requires system headers).
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("fishspeech-1.5")
class FishSpeech15(TTSModel):
    """Fish Speech 1.5: multilingual TTS with high-quality voice cloning."""

    MODEL_CARD = "https://github.com/fishaudio/fish-speech"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "ko", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone", "emotion"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 44100

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "fishspeech-1.5"

    def load(self) -> None:
        raise RuntimeError(
            "fishspeech-1.5 requires manual setup. "
            "Clone https://github.com/fishaudio/fish-speech and download model weights. "
            "The pip package has build dependencies (pyaudio) that require system headers."
        )

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        raise RuntimeError("Unreachable — load() must be called first.")

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()
        self._load_reference_audio(reference_audio)
        return self.synthesize(text, **kwargs)
