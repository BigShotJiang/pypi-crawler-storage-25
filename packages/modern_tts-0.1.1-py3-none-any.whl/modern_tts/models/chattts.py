"""ChatTTS adapter.

Models:
    - chattts: conversational TTS with natural prosody

References:
    - https://github.com/2noise/ChatTTS
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


def _check_deps() -> None:
    try:
        import ChatTTS  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "ChatTTS requires 'chattts'. Install with: uv pip install chattts"
        ) from exc


@register_model("chattts")
class ChatTTS(TTSModel):
    """ChatTTS: conversational TTS with natural prosody and emotion control."""

    MODEL_CARD = "https://github.com/2noise/ChatTTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone", "emotion"}
    REQUIREMENTS = ["chattts", "torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 24000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._model: Any = None

    @property
    def model_id(self) -> str:
        return "chattts"

    def load(self) -> None:
        _check_deps()
        import ChatTTS as _ChatTTS

        # Ensure HF cache goes to /mnt/hdd
        os.environ.setdefault("HF_HOME", "/mnt/hdd/modern-tts-models/hf_cache")

        self._model = _ChatTTS.Chat()
        self._model.load(source="huggingface", force_redownload=False)
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        import numpy as np

        gen_text = text.get_text()

        # ChatTTS returns List[List[np.ndarray]]
        wavs = self._model.infer([gen_text])

        # Extract waveform from nested structure
        audio = wavs[0]
        if isinstance(audio, list):
            audio = audio[0]
        if not isinstance(audio, np.ndarray):
            audio = np.array(audio)

        return TTSResult(
            audio=AudioOutput(
                waveform=audio.astype(np.float32),
                sample_rate=self.DEFAULT_SAMPLE_RATE,
            ),
            text=gen_text,
            language=text.language or "zh",
            model_id=self.model_id,
        )

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        """Clone voice from reference audio."""
        self._ensure_loaded()
        # ChatTTS can do voice cloning with reference audio via do_text_normalization
        # and do_homophone_replacement options; full clone requires more setup.
        # For now, fall back to standard synthesis.
        return self.synthesize(text, **kwargs)

    def speak_with_emotion(
        self,
        text: TextInput,
        emotion: str = "neutral",
        **kwargs: Any,
    ) -> TTSResult:
        """Synthesize with emotion control."""
        text.emotion = emotion
        return self.synthesize(text, **kwargs)
