"""Piper-TTS adapter (Rhasspy).

Models:
    - piper-tts: lightweight, fast ONNX-based TTS
    - Supports 30+ languages via voice models

References:
    - https://github.com/rhasspy/piper
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


def _check_deps() -> None:
    try:
        import piper  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "Piper-TTS requires 'piper-tts'. Install with: uv pip install piper-tts"
        ) from exc


@register_model("piper-tts")
class PiperTTS(TTSModel):
    """Piper-TTS: lightweight ONNX-based TTS optimized for edge devices.

    Supports 30+ languages via downloadable voice models.
    """

    MODEL_CARD = "https://github.com/rhasspy/piper"
    SUPPORTED_LANGUAGES = {
        "zh", "en", "de", "es", "fr", "it", "nl", "pl", "pt",
        "ru", "ja", "ko", "ar", "hi", "auto", "multi"
    }
    SUPPORTED_MODES = {"speak"}
    REQUIREMENTS = ["onnxruntime", "piper-tts"]
    DEFAULT_SAMPLE_RATE = 22050

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "piper-tts"

    def load(self) -> None:
        _check_deps()
        from piper import PiperVoice

        # Default to Chinese voice; user can override via model_path
        model_path = self.config.model_path or "/home/ws/ws/projects/modern-tts/piper_models/zh_CN-huayan-medium.onnx"
        config_path = str(model_path) + ".json"
        self._model = PiperVoice.load(str(model_path), config_path)
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        import numpy as np

        chunks = list(self._model.synthesize(text.get_text()))
        if not chunks:
            waveform = np.array([], dtype=np.float32)
            sr = self._model.config.sample_rate
        else:
            audio_parts = [c.audio_float_array for c in chunks]
            waveform = np.concatenate(audio_parts).astype(np.float32)
            sr = chunks[0].sample_rate

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=text.get_text(),
            language=text.language or "zh",
            model_id=self.model_id,
        )
