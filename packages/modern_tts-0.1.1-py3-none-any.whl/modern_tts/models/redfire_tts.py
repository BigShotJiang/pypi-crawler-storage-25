"""RedFire-TTS adapter (Xiaohongshu / FireRedTeam).

Models:
    - redfire-tts: high-quality Chinese/English neural TTS

References:
    - https://github.com/FireRedTeam/FireRedTTS
    - https://huggingface.co/FireRedTeam/FireRedTTS-1S

Note:
    Real inference requires fairseq which needs system C++ build headers
    (python3-dev) that are not available in this environment. The model
    weights also require manual download from the HuggingFace Hub.
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("redfire-tts")
class RedFireTTS(TTSModel):
    """RedFire-TTS: high-quality Chinese/English neural TTS from FireRedTeam."""

    MODEL_CARD = "https://github.com/FireRedTeam/FireRedTTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "yue", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone", "emotion"}
    REQUIREMENTS = ["torch", "torchaudio", "fairseq", "sentencex", "lingua"]
    DEFAULT_SAMPLE_RATE = 24000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "redfire-tts"

    def load(self) -> None:
        raise RuntimeError(
            "redfire-tts requires fairseq which needs system C++ build headers "
            "(python3-dev) not available in this environment. "
            "Additionally, model weights must be manually downloaded from "
            "https://huggingface.co/FireRedTeam/FireRedTTS-1S. "
            "Clone https://github.com/FireRedTeam/FireRedTTS and follow the setup instructions."
        )

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        raise RuntimeError("Unreachable — load() must be called first.")

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()
        self._load_reference_audio(reference_audio)
        return self.synthesize(text, **kwargs)
