"""Pocket-TTS adapter.

Models:
    - pocket-tts: ultra-lightweight TTS for edge and mobile devices

References:
    - https://github.com/PocketTTS/Pocket-TTS

Note:
    No public repository or model weights were found for "Pocket-TTS".
    This model ID is reserved for future implementation.
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("pocket-tts")
class PocketTTS(TTSModel):
    """Pocket-TTS: ultra-lightweight TTS optimized for edge and mobile devices.

    Runs on CPU with minimal memory footprint, suitable for IoT and embedded systems.
    """

    MODEL_CARD = "https://github.com/PocketTTS/Pocket-TTS"
    SUPPORTED_LANGUAGES = {"zh", "en", "auto", "multi"}
    SUPPORTED_MODES = {"speak"}
    REQUIREMENTS = []
    DEFAULT_SAMPLE_RATE = 16000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "pocket-tts"

    def load(self) -> None:
        raise RuntimeError(
            "pocket-tts is not available. No public repository or model weights "
            "were found for this model ID. It is reserved for future implementation."
        )

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        raise RuntimeError("Unreachable — load() must be called first.")
