"""MOSS-TTS adapter (OpenMOSS).

Models:
    - moss-tts: multilingual TTS from OpenMOSS team

References:
    - https://github.com/OpenMOSS/MOSS-TTS-Nano
    - https://huggingface.co/OpenMOSS-Team/MOSS-TTS-Nano

Note:
    This adapter uses the MOSS-TTS-Nano model (0.1B parameters) which is
    compatible with the inference pipeline from the MOSS-TTS-Nano repository.
    The full MOSS-TTS model uses a different architecture (MossTTSDelayModel)
    that requires a dedicated inference pipeline.
"""

from __future__ import annotations

import os
from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


def _check_deps() -> None:
    try:
        from transformers import AutoModelForCausalLM  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "MOSS-TTS requires 'transformers'. Install with: uv pip install transformers"
        ) from exc


@register_model("moss-tts")
class MossTTS(TTSModel):
    """MOSS-TTS: multilingual TTS from OpenMOSS team.

    Uses the MOSS-TTS-Nano model (0.1B parameters) for fast, lightweight
    multilingual speech synthesis.
    """

    MODEL_CARD = "https://huggingface.co/OpenMOSS-Team/MOSS-TTS-Nano"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "ko", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "emotion"}
    REQUIREMENTS = ["torch", "transformers"]
    DEFAULT_SAMPLE_RATE = 48000

    HF_PATH = "OpenMOSS-Team/MOSS-TTS-Nano"
    AUDIO_TOKENIZER_PATH = "OpenMOSS-Team/MOSS-Audio-Tokenizer-Nano"
    LOCAL_PATH = "/mnt/hdd/modern-tts-models/moss-tts-nano"

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)
        self._model: Any = None
        self._tokenizer: Any = None

    @property
    def model_id(self) -> str:
        return "moss-tts"

    def load(self) -> None:
        _check_deps()
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import torch

        os.environ.setdefault("HF_HOME", "/mnt/hdd/modern-tts-models/hf_cache")

        # Use local path if available, otherwise download from HF
        model_path = self.LOCAL_PATH if os.path.exists(self.LOCAL_PATH) else self.HF_PATH

        self._tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            trust_remote_code=True,
        )
        self._model = AutoModelForCausalLM.from_pretrained(
            model_path,
            trust_remote_code=True,
            torch_dtype="auto",
            device_map="cpu",
        )
        # Use SDPA instead of flash_attention_2 (flash-attn not installed)
        self._model._set_attention_implementation("sdpa")
        self._model.eval()
        self._is_loaded = True

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        import torch
        import soundfile as sf

        gen_text = text.get_text()
        output_path = kwargs.get("output_path", "/tmp/moss-tts-output.wav")

        result = self._model.inference(
            text=gen_text,
            output_audio_path=output_path,
            mode="continuation",
            text_tokenizer_path=self.LOCAL_PATH if os.path.exists(self.LOCAL_PATH) else self.HF_PATH,
            audio_tokenizer_type="moss-audio-tokenizer-nano",
            audio_tokenizer_pretrained_name_or_path=self.AUDIO_TOKENIZER_PATH,
            device=torch.device("cpu"),
            max_new_frames=kwargs.get("max_new_frames", 375),
            do_sample=kwargs.get("do_sample", False),
        )

        # Read generated audio
        waveform, sr = sf.read(result["audio_path"], dtype="float32")

        return TTSResult(
            audio=AudioOutput(
                waveform=waveform,
                sample_rate=sr,
            ),
            text=gen_text,
            language=text.language or "auto",
            model_id=self.model_id,
        )

    def speak_with_emotion(
        self,
        text: TextInput,
        emotion: str = "neutral",
        **kwargs: Any,
    ) -> TTSResult:
        text.emotion = emotion
        return self.synthesize(text, **kwargs)
