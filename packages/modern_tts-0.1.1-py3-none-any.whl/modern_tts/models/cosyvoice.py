"""CosyVoice adapter (Alibaba).

Models:
    - cosyvoice-300m: base model
    - cosyvoice-300m-sft: supervised fine-tuned
    - cosyvoice-300m-instruct: instruction-based control

References:
    - https://github.com/FunAudioLLM/CosyVoice

Note:
    Real inference requires manual setup (git clone + model weights).
    The CosyVoice repo does not provide a pip-installable package.
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("cosyvoice-300m")
class CosyVoice300M(TTSModel):
    """CosyVoice 300M: Alibaba's open-source neural TTS with voice cloning."""

    MODEL_CARD = "https://github.com/FunAudioLLM/CosyVoice"
    SUPPORTED_LANGUAGES = {"zh", "en", "yue", "ja", "ko", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone", "emotion", "style"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 22050

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "cosyvoice-300m"

    def load(self) -> None:
        raise RuntimeError(
            "cosyvoice-300m requires manual setup. "
            "Clone https://github.com/FunAudioLLM/CosyVoice and download model weights. "
            "No pip-installable package is currently available."
        )

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        raise RuntimeError("Unreachable — load() must be called first.")

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        """Zero-shot voice cloning."""
        self._ensure_loaded()
        self._load_reference_audio(reference_audio)
        return self.synthesize(text, **kwargs)


@register_model("cosyvoice-300m-sft")
class CosyVoice300MSFT(CosyVoice300M):
    """CosyVoice 300M SFT: supervised fine-tuned variant."""

    @property
    def model_id(self) -> str:
        return "cosyvoice-300m-sft"


@register_model("cosyvoice-300m-instruct")
class CosyVoice300MInstruct(CosyVoice300M):
    """CosyVoice 300M Instruct: instruction-based control variant."""

    @property
    def model_id(self) -> str:
        return "cosyvoice-300m-instruct"
