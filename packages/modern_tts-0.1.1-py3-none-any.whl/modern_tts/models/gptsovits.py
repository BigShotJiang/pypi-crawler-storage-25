"""GPT-SoVITS adapter.

Models:
    - gptsovits: few-shot voice cloning TTS

References:
    - https://github.com/RVC-Boss/GPT-SoVITS

Note:
    Real inference requires manual setup (git clone + model weights).
    No pip-installable package is currently available.
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.base import TTSModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model
from modern_tts.core.types import AudioOutput, TTSResult, TextInput


@register_model("gptsovits")
class GPTSoVITS(TTSModel):
    """GPT-SoVITS: few-shot voice cloning with high similarity."""

    MODEL_CARD = "https://github.com/RVC-Boss/GPT-SoVITS"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "yue", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = ["torch", "torchaudio"]
    DEFAULT_SAMPLE_RATE = 32000

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "gptsovits"

    def load(self) -> None:
        raise RuntimeError(
            "gptsovits requires manual setup. "
            "Clone https://github.com/RVC-Boss/GPT-SoVITS and download model weights. "
            "No pip-installable package is currently available."
        )

    def synthesize(self, text: TextInput, **kwargs: Any) -> TTSResult:
        self._ensure_loaded()
        raise RuntimeError("Unreachable — load() must be called first.")

    def clone(
        self,
        text: TextInput,
        reference_audio: "AudioOutput | str | Path",
        **kwargs: Any,
    ) -> TTSResult:
        self._ensure_loaded()
        self._load_reference_audio(reference_audio)
        return self.synthesize(text, **kwargs)
