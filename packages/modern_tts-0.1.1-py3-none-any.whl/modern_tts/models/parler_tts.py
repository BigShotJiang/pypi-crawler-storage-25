"""Parler-TTS adapter (HuggingFace).

Models:
    - parler-tts-mini: lightweight TTS with speaker description
    - parler-tts-large: larger variant

References:
    - https://github.com/huggingface/parler-tts

Note:
    The parler-tts package (v0.2.x) is incompatible with transformers >= 4.50
    which is required by qwen-tts. Loading is temporarily disabled until a
    compatible version is available.
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.audio_llm import TextToAudioLLMModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model


@register_model("parler-tts-mini")
class ParlerTTSMini(TextToAudioLLMModel):
    """Parler-TTS Mini: lightweight neural TTS with natural speaker descriptions."""

    MODEL_CARD = "https://huggingface.co/parler-tts/parler-tts-mini-v1"
    SUPPORTED_LANGUAGES = {"en", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "style"}
    REQUIREMENTS = ["torch", "transformers"]
    DEFAULT_SAMPLE_RATE = 24000

    HF_PATH = "parler-tts/parler-tts-mini-v1"
    PROCESSOR_CLS = "transformers.AutoTokenizer"
    MODEL_CLS = "transformers.AutoModelForTextToWaveform"
    DEFAULT_MAX_NEW_TOKENS = 512

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "parler-tts-mini"

    def load(self) -> None:
        raise RuntimeError(
            "parler-tts-mini loading is temporarily disabled. "
            "The parler-tts package is incompatible with the installed transformers version. "
            "Please downgrade transformers to ~4.46 or wait for an updated parler-tts release."
        )

    def _tokenize(self, text, **kwargs: Any) -> dict[str, Any]:
        """Parler-TTS requires a description + text prompt."""
        raw_text = text.get_text()
        description = kwargs.get(
            "description",
            "A female speaker delivers a slightly expressive and animated speech."
        )
        return self._processor(
            description,
            raw_text,
            return_tensors="pt",
        )

    def _decode_audio(self, outputs: Any, **kwargs: Any) -> Any:
        """Parler-TTS returns audio arrays directly."""
        import numpy as np
        if hasattr(outputs, "cpu"):
            arr = outputs.cpu().numpy()
            if arr.ndim > 1:
                arr = arr.squeeze()
            return arr.astype(np.float32)
        return np.array(outputs).astype(np.float32)


@register_model("parler-tts-large")
class ParlerTTSLarge(ParlerTTSMini):
    """Parler-TTS Large: higher quality variant."""

    MODEL_CARD = "https://huggingface.co/parler-tts/parler-tts-large-v1"
    HF_PATH = "parler-tts/parler-tts-large-v1"

    @property
    def model_id(self) -> str:
        return "parler-tts-large"
