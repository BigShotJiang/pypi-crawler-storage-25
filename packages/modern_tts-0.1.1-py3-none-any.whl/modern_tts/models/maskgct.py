"""MaskGCT adapter.

Models:
    - maskgct: masked generative codec TTS

References:
    - https://github.com/open-mmlab/Amphion/tree/main/models/tts/maskgct

Note:
    MaskGCT exists on the HuggingFace Hub but uses a custom tokenizer setup
    that is incompatible with the generic TextToAudioLLMModel loader.
    Loading is disabled until a dedicated adapter is implemented.
"""

from __future__ import annotations

from typing import Any

from modern_tts.core.audio_llm import TextToAudioLLMModel
from modern_tts.core.config import BackendConfig, ModelConfig
from modern_tts.core.registry import register_model


@register_model("maskgct")
class MaskGCT(TextToAudioLLMModel):
    """MaskGCT: masked generative codec transformer for TTS."""

    MODEL_CARD = "https://github.com/open-mmlab/Amphion"
    SUPPORTED_LANGUAGES = {"zh", "en", "ja", "ko", "auto", "multi"}
    SUPPORTED_MODES = {"speak", "clone"}
    REQUIREMENTS = ["torch", "transformers"]
    DEFAULT_SAMPLE_RATE = 24000

    HF_PATH = "amphion/maskgct"
    PROCESSOR_CLS = "transformers.AutoTokenizer"
    MODEL_CLS = "transformers.AutoModel"
    DEFAULT_MAX_NEW_TOKENS = 1024

    def __init__(
        self,
        config: ModelConfig,
        backend: BackendConfig | None = None,
    ) -> None:
        super().__init__(config, backend)

    @property
    def model_id(self) -> str:
        return "maskgct"

    def load(self) -> None:
        raise RuntimeError(
            "maskgct loading is temporarily disabled. "
            "The model uses a custom tokenizer setup that is not supported by the generic loader. "
            "A dedicated adapter is needed. See https://github.com/open-mmlab/Amphion for setup instructions."
        )
