"""Modern TTS model adapters.

Each submodule implements one or more `TTSModel` subclasses and registers them
via `@register_model`. Importing this package triggers auto-discovery.
"""

from modern_tts.core.registry import auto_discover_models

# Trigger registration of all model adapters
auto_discover_models("modern_tts.models")
