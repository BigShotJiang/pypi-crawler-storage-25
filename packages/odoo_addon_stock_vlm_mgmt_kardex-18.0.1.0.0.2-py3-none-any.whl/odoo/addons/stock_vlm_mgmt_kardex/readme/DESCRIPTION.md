Integration with Kardex VLMs
