from typing import Any, Protocol, Sequence, runtime_checkable

from langchain_ai_skills_framework.executors.my_script_execution_result import (
    MyScriptExecutionResult,
)
from langchain_ai_skills_framework.models.plugin_definition import PluginDefinition
from langchain_ai_skills_framework.models.plugin_mcp_config import PluginMcpServerEntry
from langchain_ai_skills_framework.models.skills_model import SkillDetails, SkillSummary


@runtime_checkable
class SkillLoaderProtocol(Protocol):
    def list_skill_summaries(self, allowed_skills: set[str]) -> Sequence[SkillSummary]: ...

    async def list_all_summaries(self, *, user_id: str, allowed_skills: set[str]) -> Sequence[SkillSummary]: ...

    def get_skill_details(self, skill_name: str, *, plugin_name: str = "") -> SkillDetails: ...

    async def get_skill_details_for_user(self, *, user_id: str, plugin_name: str, skill_name: str) -> SkillDetails: ...

    def refresh(self) -> None: ...

    async def refresh_async(self) -> None: ...

    async def get_instructions(self) -> str: ...

    def read_skill_resource(self, skill_name: str, resource_name: str, *, plugin_name: str = "") -> str: ...

    async def read_skill_resource_for_user(
        self, *, user_id: str, plugin_name: str, skill_name: str, resource_name: str
    ) -> str: ...

    async def run_skill_script(
        self, skill_name: str, script_name: str, arguments: dict[str, Any] | None, *, plugin_name: str = ""
    ) -> MyScriptExecutionResult: ...

    async def run_skill_script_for_user(
        self,
        *,
        user_id: str,
        plugin_name: str,
        skill_name: str,
        script_name: str,
        arguments: dict[str, Any] | None,
    ) -> MyScriptExecutionResult: ...

    def list_skill_script_names(self, skill_name: str, *, plugin_name: str = "") -> Sequence[str]: ...

    async def list_skill_script_names_for_user(
        self, *, user_id: str, plugin_name: str, skill_name: str
    ) -> Sequence[str]: ...

    def list_skill_resource_names(self, skill_name: str, *, plugin_name: str = "") -> Sequence[str]: ...

    async def list_skill_resource_names_for_user(
        self, *, user_id: str, plugin_name: str, skill_name: str
    ) -> Sequence[str]: ...

    async def get_plugin_mcp_configs(self) -> Sequence[PluginMcpServerEntry]: ...

    async def list_plugin_definitions(self) -> Sequence[PluginDefinition]: ...
