"""Entry point for running pencheff as a module: python -m pencheff

Usage:
  python -m pencheff                    # Start MCP server (stdio)
  python -m pencheff scan --target URL  # Headless CI/CD scan
  python -m pencheff scan --target URL --profile cicd --fail-on high
  python -m pencheff history --target URL
  python -m pencheff compare SESSION_A SESSION_B
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import Any


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pencheff",
        description="Pencheff — AI-native penetration testing agent (MCP + CLI)",
    )
    sub = parser.add_subparsers(dest="command")

    # ── MCP server (default) ─────────────────────────────────────────
    sub.add_parser("serve", help="Start MCP server (default when no command given)")

    # ── Headless scan ────────────────────────────────────────────────
    scan_p = sub.add_parser("scan", help="Run a headless pentest scan")
    scan_p.add_argument("--target", required=True, help="Target URL")
    scan_p.add_argument(
        "--profile",
        default="standard",
        choices=["quick", "standard", "deep", "api-only", "compliance", "cicd"],
        help="Scan profile (default: standard)",
    )
    scan_p.add_argument(
        "--fail-on",
        default=None,
        choices=["info", "low", "medium", "high", "critical"],
        dest="fail_on",
        help="Exit non-zero if any finding meets or exceeds this severity",
    )
    scan_p.add_argument("--username", default=None, help="Target username")
    scan_p.add_argument("--password", default=None, help="Target password")
    scan_p.add_argument("--token", default=None, help="Bearer token for auth")
    scan_p.add_argument("--output", default=None, help="Output dir for reports")
    scan_p.add_argument(
        "--format",
        default="json",
        choices=["json", "markdown", "docx", "csv"],
        help="Report format",
    )
    scan_p.add_argument("--save-history", action="store_true", help="Save scan to history")

    # ── History ──────────────────────────────────────────────────────
    hist_p = sub.add_parser("history", help="List saved scan history")
    hist_p.add_argument("--target", default=None, help="Filter by target URL")

    # ── Compare ──────────────────────────────────────────────────────
    cmp_p = sub.add_parser("compare", help="Compare two saved scans")
    cmp_p.add_argument("session_a", help="Baseline session ID")
    cmp_p.add_argument("session_b", help="Current session ID")

    return parser


async def _run_scan(args: argparse.Namespace) -> int:
    """Execute a headless scan and return exit code."""
    from pencheff.config import SCAN_PROFILES, Severity
    from pencheff.core.session import create_session
    from pencheff.core.http_client import PencheffHTTPClient

    profile = SCAN_PROFILES.get(args.profile, SCAN_PROFILES["standard"])
    fail_on = args.fail_on or profile.get("fail_on")

    creds: dict[str, Any] = {}
    if args.username:
        creds["username"] = args.username
    if args.password:
        creds["password"] = args.password
    if args.token:
        creds["token"] = args.token

    session = create_session(
        target_url=args.target,
        credentials=creds or None,
        depth=profile["depth"],
    )

    print(f"[pencheff] scan started  target={args.target}  profile={args.profile}  session={session.id}")

    # Import all scan functions from server lazily to avoid circular imports
    from pencheff import server as _srv  # noqa: F401 — registers tools on mcp

    _MODULE_FN_MAP = {
        "recon_passive": _srv.recon_passive,
        "recon_active": _srv.recon_active,
        "recon_api_discovery": _srv.recon_api_discovery,
        "scan_waf": _srv.scan_waf,
        "scan_injection": _srv.scan_injection,
        "scan_client_side": _srv.scan_client_side,
        "scan_auth": _srv.scan_auth,
        "scan_mfa_bypass": _srv.scan_mfa_bypass,
        "scan_oauth": _srv.scan_oauth,
        "scan_authz": _srv.scan_authz,
        "scan_infrastructure": _srv.scan_infrastructure,
        "scan_api": _srv.scan_api,
        "scan_business_logic": _srv.scan_business_logic,
        "scan_cloud": _srv.scan_cloud,
        "scan_file_handling": _srv.scan_file_handling,
        "scan_advanced": _srv.scan_advanced,
        "scan_websocket": _srv.scan_websocket,
        "scan_subdomain_takeover": _srv.scan_subdomain_takeover,
        "exploit_chain_suggest": _srv.exploit_chain_suggest,
        "generate_report": _srv.generate_report,
    }

    for module_name in profile["modules"]:
        fn = _MODULE_FN_MAP.get(module_name)
        if not fn:
            continue
        print(f"[pencheff] running {module_name}...")
        try:
            result = await fn(session_id=session.id)
            new = result.get("new_findings", 0)
            total = result.get("total_findings", 0)
            if new:
                print(f"[pencheff]   {module_name}: +{new} new findings (total: {total})")
        except Exception as e:
            print(f"[pencheff]   {module_name}: ERROR — {e}", file=sys.stderr)

    # Save history if requested
    if getattr(args, "save_history", False):
        from pencheff.core.scan_history import save_scan
        path = save_scan(session)
        print(f"[pencheff] scan saved to {path}")

    # Export report
    summary = session.findings.summary()
    findings_list = [f.to_dict() for f in session.findings.get_all()]

    if args.output or args.format in ("docx", "csv"):
        try:
            from pencheff.reporting.exporter import export_docx, export_csv, export_json
            if args.format == "docx":
                export_docx(session, output_dir=args.output)
            elif args.format == "csv":
                export_csv(session, output_dir=args.output)
            else:
                export_json(session, output_dir=args.output)
        except Exception as e:
            print(f"[pencheff] export error: {e}", file=sys.stderr)
    else:
        # Print JSON summary to stdout
        output = {
            "session_id": session.id,
            "target": args.target,
            "profile": args.profile,
            "summary": summary,
            "total_findings": session.findings.count,
            "findings": findings_list,
        }
        print(json.dumps(output, indent=2))

    print(f"\n[pencheff] scan complete — {session.findings.count} findings")
    for sev, count in sorted(summary.items(), key=lambda x: x[0]):
        if count:
            print(f"  {sev}: {count}")

    # Fail-on logic
    if fail_on:
        _SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
        threshold = _SEVERITY_ORDER.get(fail_on, 0)
        for f in session.findings.get_all():
            if _SEVERITY_ORDER.get(f.severity.value, 0) >= threshold:
                print(
                    f"\n[pencheff] FAIL — found {f.severity.value} severity finding: {f.title}",
                    file=sys.stderr,
                )
                return 1

    return 0


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command in (None, "serve"):
        from pencheff.server import mcp
        mcp.run(transport="stdio")
        return

    if args.command == "scan":
        exit_code = asyncio.run(_run_scan(args))
        sys.exit(exit_code)

    if args.command == "history":
        from pencheff.core.scan_history import list_scans
        scans = list_scans(args.target)
        print(json.dumps(scans, indent=2))
        return

    if args.command == "compare":
        from pencheff.core.scan_history import compare_scans
        result = compare_scans(args.session_a, args.session_b)
        print(json.dumps(result, indent=2))
        return

    parser.print_help()


if __name__ == "__main__":
    main()
