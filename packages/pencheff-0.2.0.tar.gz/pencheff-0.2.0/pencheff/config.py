"""Global configuration, constants, and mappings."""

from enum import Enum

# CVSS v3.1 severity thresholds
CVSS_SEVERITY = {
    "NONE": (0.0, 0.0),
    "LOW": (0.1, 3.9),
    "MEDIUM": (4.0, 6.9),
    "HIGH": (7.0, 8.9),
    "CRITICAL": (9.0, 10.0),
}


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class VerificationStatus(str, Enum):
    UNVERIFIED = "unverified"
    TRUE_POSITIVE = "true_positive"
    FALSE_POSITIVE = "false_positive"
    TRUE_NEGATIVE = "true_negative"
    FALSE_NEGATIVE = "false_negative"


class TestDepth(str, Enum):
    QUICK = "quick"
    STANDARD = "standard"
    DEEP = "deep"


# OWASP Top 10 2021 mapping
OWASP_TOP_10 = {
    "A01": "Broken Access Control",
    "A02": "Cryptographic Failures",
    "A03": "Injection",
    "A04": "Insecure Design",
    "A05": "Security Misconfiguration",
    "A06": "Vulnerable and Outdated Components",
    "A07": "Identification and Authentication Failures",
    "A08": "Software and Data Integrity Failures",
    "A09": "Security Logging and Monitoring Failures",
    "A10": "Server-Side Request Forgery (SSRF)",
}

# PCI-DSS requirement mapping for common vulnerability categories
PCI_DSS_MAP = {
    "injection": ["6.5.1"],
    "xss": ["6.5.7"],
    "auth": ["6.5.10", "8.1", "8.2"],
    "authz": ["6.5.8", "7.1", "7.2"],
    "crypto": ["4.1", "6.5.3"],
    "misconfiguration": ["2.2", "6.2"],
    "ssrf": ["6.5.1"],
    "file_handling": ["6.5.1", "6.5.8"],
    "deserialization": ["6.5.1"],
    "smuggling": ["6.5.10"],
    "cache_poisoning": ["6.5.10"],
    "mfa_bypass": ["8.3"],
    "oauth": ["6.5.10"],
    "subdomain_takeover": ["6.5.8"],
    "waf_bypass": ["6.6"],
    "prototype_pollution": ["6.5.1"],
    "ldap": ["6.5.1"],
    "open_redirect": ["6.5.10"],
    "header_injection": ["6.5.1"],
    "websocket": ["6.5.10"],
    "mass_assignment": ["6.5.1", "6.5.8"],
}

# NIST 800-53 mapping
NIST_MAP = {
    "injection": ["SI-10", "SI-16"],
    "xss": ["SI-10"],
    "auth": ["IA-2", "IA-5", "IA-8"],
    "authz": ["AC-3", "AC-6"],
    "crypto": ["SC-8", "SC-12", "SC-13"],
    "misconfiguration": ["CM-6", "CM-7"],
    "ssrf": ["SI-10", "SC-7"],
    "logging": ["AU-2", "AU-3", "AU-6"],
    "deserialization": ["SI-10", "SI-16"],
    "smuggling": ["SC-7", "SI-10"],
    "cache_poisoning": ["SC-7"],
    "mfa_bypass": ["IA-2", "IA-11"],
    "oauth": ["IA-2", "IA-8"],
    "subdomain_takeover": ["CM-8", "SC-20"],
    "waf_bypass": ["SC-7", "SI-4"],
    "prototype_pollution": ["SI-10"],
    "ldap": ["SI-10", "AC-3"],
    "open_redirect": ["SI-10"],
    "header_injection": ["SI-10", "SC-7"],
    "websocket": ["SC-8", "SC-23"],
    "mass_assignment": ["AC-3", "AC-6"],
}

# SOC 2 Trust Services Criteria mapping
SOC2_MAP = {
    "injection": ["CC6.1", "CC6.6"],
    "xss": ["CC6.1", "CC6.6"],
    "auth": ["CC6.1", "CC6.2", "CC6.3"],
    "authz": ["CC6.1", "CC6.3"],
    "crypto": ["CC6.1", "CC6.7"],
    "misconfiguration": ["CC6.1", "CC7.1"],
    "ssrf": ["CC6.1", "CC6.6"],
    "logging": ["CC7.2", "CC7.3"],
    "deserialization": ["CC6.1", "CC6.6"],
    "mfa_bypass": ["CC6.1", "CC6.2"],
    "oauth": ["CC6.1", "CC6.3"],
    "subdomain_takeover": ["CC6.1", "CC9.2"],
    "cloud": ["CC6.1", "CC6.6", "A1.1"],
    "file_handling": ["CC6.1", "CC6.6"],
    "mass_assignment": ["CC6.1", "CC6.3"],
}

# ISO 27001:2022 Annex A control mapping
ISO27001_MAP = {
    "injection": ["A.8.24", "A.8.28"],
    "xss": ["A.8.28"],
    "auth": ["A.5.15", "A.8.2", "A.5.16"],
    "authz": ["A.5.15", "A.5.18"],
    "crypto": ["A.8.24", "A.8.7"],
    "misconfiguration": ["A.8.8", "A.8.9"],
    "ssrf": ["A.8.22", "A.8.28"],
    "logging": ["A.8.15", "A.8.16"],
    "deserialization": ["A.8.28"],
    "smuggling": ["A.8.22", "A.8.28"],
    "mfa_bypass": ["A.5.17", "A.8.2"],
    "oauth": ["A.5.15", "A.8.2"],
    "subdomain_takeover": ["A.8.22", "A.5.19"],
    "cloud": ["A.8.23", "A.5.19"],
    "file_handling": ["A.8.28", "A.8.22"],
    "mass_assignment": ["A.5.18", "A.8.28"],
    "waf_bypass": ["A.8.22", "A.8.28"],
}

# HIPAA Security Rule mapping
HIPAA_MAP = {
    "injection": ["164.312(a)(2)(iv)", "164.312(c)(1)"],
    "xss": ["164.312(a)(2)(iv)", "164.312(c)(1)"],
    "auth": ["164.312(a)(2)(i)", "164.312(d)"],
    "authz": ["164.312(a)(1)", "164.308(a)(4)"],
    "crypto": ["164.312(a)(2)(iv)", "164.312(e)(2)(ii)"],
    "misconfiguration": ["164.312(a)(1)", "164.308(a)(1)"],
    "ssrf": ["164.312(c)(1)", "164.312(e)(1)"],
    "logging": ["164.312(b)", "164.308(a)(1)(ii)(D)"],
    "deserialization": ["164.312(c)(1)", "164.312(a)(2)(iv)"],
    "mfa_bypass": ["164.312(d)", "164.312(a)(2)(i)"],
    "cloud": ["164.312(c)(1)", "164.308(a)(7)"],
    "file_handling": ["164.312(c)(1)", "164.312(a)(2)(iv)"],
    "mass_assignment": ["164.312(a)(1)", "164.308(a)(4)"],
}

# ─── Scan Profiles ────────────────────────────────────────────────────

SCAN_PROFILES: dict[str, dict] = {
    "quick": {
        "description": "Fast surface-level scan — recon + top injection checks + auth. ~5 min.",
        "modules": ["recon_passive", "recon_active", "scan_waf", "scan_injection", "scan_auth"],
        "depth": "quick",
        "crawl_depth": 1,
        "max_pages": 20,
    },
    "standard": {
        "description": "Balanced scan covering OWASP Top 10. ~15 min.",
        "modules": [
            "recon_passive", "recon_active", "recon_api_discovery",
            "scan_waf", "scan_injection", "scan_client_side",
            "scan_auth", "scan_authz", "scan_infrastructure",
            "scan_api", "scan_business_logic",
            "exploit_chain_suggest", "generate_report",
        ],
        "depth": "standard",
        "crawl_depth": 3,
        "max_pages": 100,
    },
    "deep": {
        "description": "Exhaustive pentest — all modules + advanced attacks. ~45 min+.",
        "modules": [
            "recon_passive", "recon_active", "recon_api_discovery",
            "scan_waf", "scan_injection", "scan_client_side",
            "scan_auth", "scan_mfa_bypass", "scan_oauth", "scan_authz",
            "scan_infrastructure", "scan_api", "scan_business_logic",
            "scan_cloud", "scan_file_handling", "scan_advanced",
            "scan_websocket", "scan_subdomain_takeover",
            "exploit_chain_suggest", "generate_report",
        ],
        "depth": "deep",
        "crawl_depth": 5,
        "max_pages": 500,
    },
    "api-only": {
        "description": "REST/GraphQL API security — no browser crawl, auth + injection + IDOR.",
        "modules": [
            "recon_api_discovery", "scan_waf",
            "scan_injection", "scan_auth", "scan_authz",
            "scan_api", "scan_business_logic",
            "exploit_chain_suggest", "generate_report",
        ],
        "depth": "standard",
        "crawl_depth": 0,
        "max_pages": 0,
    },
    "compliance": {
        "description": "Compliance-focused scan mapped to PCI-DSS, NIST, SOC 2, ISO 27001.",
        "modules": [
            "recon_passive", "recon_active",
            "scan_infrastructure", "scan_injection", "scan_client_side",
            "scan_auth", "scan_authz", "scan_cloud",
            "generate_report",
        ],
        "depth": "standard",
        "crawl_depth": 2,
        "max_pages": 50,
        "compliance_frameworks": ["owasp", "pci-dss", "nist", "soc2", "iso27001"],
    },
    "cicd": {
        "description": "Lightweight CI/CD gate — fast, non-destructive, fail on critical/high.",
        "modules": [
            "recon_active", "scan_waf", "scan_injection",
            "scan_auth", "scan_infrastructure",
        ],
        "depth": "quick",
        "crawl_depth": 1,
        "max_pages": 10,
        "fail_on": "high",
    },
}

# Default timeouts
DEFAULT_REQUEST_TIMEOUT = 30.0
DEFAULT_SCAN_TIMEOUT = 300.0
MAX_REQUESTS_PER_SECOND = 10
MAX_CRAWL_DEPTH = 5
MAX_RESPONSE_SIZE = 1024 * 1024 * 5  # 5MB

# Common ports
TOP_100_PORTS = [
    21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995,
    1723, 3306, 3389, 5432, 5900, 8080, 8443, 8888, 27017,
]

TOP_1000_PORTS = list(range(1, 1001)) + [
    1433, 1521, 1723, 2049, 2082, 2083, 2086, 2087, 3306, 3389,
    5432, 5900, 5985, 5986, 6379, 8080, 8443, 8888, 9090, 9200,
    9300, 11211, 27017, 27018, 50000,
]
