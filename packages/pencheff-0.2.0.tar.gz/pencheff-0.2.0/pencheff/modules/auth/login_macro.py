"""Authenticated crawl via Playwright login macro.

Supports two approaches:
1. Credential-based auto-login: fills username/password fields automatically
2. Macro replay: execute a stored list of steps (click, fill, navigate)
   to handle SSO, SAML, OAuth, MFA, and custom login flows.

After a successful login, cookies/tokens are extracted and injected
into the session for subsequent HTTP-based module testing.
"""

from __future__ import annotations

import json
from typing import Any

from pencheff.config import Severity
from pencheff.core.findings import Finding
from pencheff.core.http_client import PencheffHTTPClient
from pencheff.core.session import PentestSession
from pencheff.modules.base import BaseTestModule

from playwright.async_api import async_playwright, Page, Browser

_PLAYWRIGHT_AVAILABLE = True

# Macro step types:
# {"action": "navigate", "url": "https://..."}
# {"action": "fill",     "selector": "#username", "value": "admin"}
# {"action": "click",    "selector": "button[type=submit]"}
# {"action": "wait",     "ms": 1000}
# {"action": "wait_for", "selector": ".dashboard"}
# {"action": "screenshot"}


class LoginMacroModule(BaseTestModule):
    name = "login_macro"
    category = "auth"
    owasp_categories = ["A07"]
    description = "Automated authenticated crawl via Playwright login macro"

    def get_techniques(self) -> list[str]:
        return ["auto_login", "macro_replay", "sso_handling", "cookie_extraction"]

    async def run(
        self,
        session: PentestSession,
        http: PencheffHTTPClient,
        targets: list[str] | None = None,
        config: dict[str, Any] | None = None,
    ) -> list[Finding]:
        config = config or {}
        macro_steps = config.get("steps", [])
        headless = config.get("headless", True)
        login_url = config.get("login_url", session.target.base_url)

        creds = session.credentials.get("default")

        # If no macro steps provided, try auto-login via credential form detection
        if not macro_steps and creds and creds.username and creds.password:
            macro_steps = _build_auto_login_steps(
                login_url,
                creds.username.get(),
                creds.password.get(),
            )

        if not macro_steps:
            return [Finding(
                title="No Login Macro Configured",
                severity=Severity.INFO,
                category="auth",
                owasp_category="A07",
                description=(
                    "No login macro steps were provided and no username/password credentials "
                    "are configured. Provide credentials via pentest_init or supply macro "
                    "steps via pentest_configure."
                ),
                remediation="Configure credentials or provide macro steps via pentest_configure.",
                endpoint=session.target.base_url,
            )]

        findings: list[Finding] = []

        async with async_playwright() as pw:
            browser: Browser = await pw.chromium.launch(headless=headless)
            context = await browser.new_context(ignore_https_errors=True)
            page: Page = await context.new_page()

            try:
                success, cookies, local_storage = await _execute_macro(page, macro_steps)

                if success:
                    # Inject extracted cookies into the session
                    cookie_header = "; ".join(f"{c['name']}={c['value']}" for c in cookies)
                    if cookie_header:
                        from pencheff.core.credentials import MaskedSecret
                        cred_set = session.credentials.get("default")
                        if cred_set:
                            cred_set.cookie = MaskedSecret(cookie_header)
                        else:
                            session.credentials.add_from_dict("browser_auth", {
                                "cookie": cookie_header,
                            })

                    # Look for JWT/Bearer tokens in localStorage
                    token_found = None
                    for key, value in local_storage.items():
                        if any(tok in key.lower() for tok in ("token", "jwt", "auth", "access")):
                            token_found = value
                            break

                    if token_found:
                        from pencheff.core.credentials import MaskedSecret
                        cred_set = session.credentials.get("default")
                        if cred_set:
                            cred_set.token = MaskedSecret(token_found)

                    findings.append(Finding(
                        title="Authenticated Session Established via Login Macro",
                        severity=Severity.INFO,
                        category="auth",
                        owasp_category="A07",
                        description=(
                            f"Login macro executed successfully. "
                            f"Extracted {len(cookies)} cookies"
                            + (f" and 1 auth token from localStorage." if token_found else ".")
                            + " Session credentials updated for subsequent module testing."
                        ),
                        remediation="Verify the authenticated session is being used in subsequent scans.",
                        endpoint=login_url,
                    ))
                else:
                    findings.append(Finding(
                        title="Login Macro Failed — Unauthenticated Testing Only",
                        severity=Severity.MEDIUM,
                        category="auth",
                        owasp_category="A07",
                        description=(
                            "The login macro did not complete successfully. Subsequent scans "
                            "will run without authentication and may miss authenticated endpoints."
                        ),
                        remediation="Review macro steps. Check for CAPTCHA, SSO redirects, or MFA requirements.",
                        endpoint=login_url,
                    ))

            except Exception as e:
                findings.append(Finding(
                    title="Login Macro Error",
                    severity=Severity.INFO,
                    category="auth",
                    owasp_category="A07",
                    description=f"Login macro raised an exception: {e}",
                    remediation="Review macro steps and target URL.",
                    endpoint=login_url,
                ))
            finally:
                await browser.close()

        return findings


def _build_auto_login_steps(login_url: str, username: str, password: str) -> list[dict]:
    """Construct auto-login steps by trying common selectors."""
    return [
        {"action": "navigate", "url": login_url},
        {"action": "wait", "ms": 1000},
        # Try common username selectors
        {"action": "fill_first", "selectors": [
            "input[name='username']", "input[name='email']",
            "input[id='username']", "input[id='email']",
            "input[type='email']", "input[autocomplete='username']",
            "input[autocomplete='email']",
        ], "value": username},
        # Try common password selectors
        {"action": "fill_first", "selectors": [
            "input[name='password']", "input[type='password']",
            "input[id='password']",
        ], "value": password},
        # Try common submit selectors
        {"action": "click_first", "selectors": [
            "button[type='submit']", "input[type='submit']",
            "button:has-text('Login')", "button:has-text('Sign in')",
            "button:has-text('Log in')",
        ]},
        {"action": "wait", "ms": 2000},
    ]


async def _execute_macro(
    page: "Page",
    steps: list[dict],
) -> tuple[bool, list[dict], dict]:
    """Execute macro steps. Returns (success, cookies, local_storage)."""
    success = False

    for step in steps:
        action = step.get("action", "")
        try:
            if action == "navigate":
                await page.goto(step["url"], wait_until="networkidle", timeout=15000)

            elif action == "fill":
                await page.fill(step["selector"], step["value"])

            elif action == "fill_first":
                for sel in step.get("selectors", []):
                    try:
                        el = await page.query_selector(sel)
                        if el and await el.is_visible():
                            await el.fill(step["value"])
                            break
                    except Exception:
                        continue

            elif action == "click":
                await page.click(step["selector"])

            elif action == "click_first":
                for sel in step.get("selectors", []):
                    try:
                        el = await page.query_selector(sel)
                        if el and await el.is_visible():
                            await el.click()
                            break
                    except Exception:
                        continue

            elif action == "wait":
                await page.wait_for_timeout(step.get("ms", 1000))

            elif action == "wait_for":
                await page.wait_for_selector(step["selector"], timeout=10000)

            elif action == "screenshot":
                # Capture for evidence (returns base64 but we just mark it)
                await page.screenshot()

        except Exception:
            continue

    # Determine success: check we're not still on login page
    current_url = page.url
    if "login" not in current_url.lower() and "signin" not in current_url.lower():
        success = True

    # Also check if login form is gone (more reliable)
    try:
        password_field = await page.query_selector("input[type='password']")
        if not password_field:
            success = True
    except Exception:
        pass

    # Extract cookies
    cookies = []
    try:
        cookies = await page.context.cookies()
    except Exception:
        pass

    # Extract localStorage
    local_storage: dict[str, str] = {}
    try:
        local_storage = await page.evaluate("""() => {
            const result = {};
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                result[key] = localStorage.getItem(key);
            }
            return result;
        }""")
    except Exception:
        pass

    return success, cookies, local_storage or {}
