# 5bb-task

> **task** – a task runner / simpler Make alternative from [Taskfile.dev](https://taskfile.dev), distributed via PyPI/uv.

This package downloads and installs the [`task`](https://github.com/go-task/task) binary for your platform on first use. No compilation required.

## Installation

```bash
uv tool install 5bb-task
# or
pip install 5bb-task
```

## Usage

```bash
task --list        # list all available tasks
task build         # run the 'build' task
task test          # run the 'test' task
```

The binary is downloaded from the official GitHub releases on first run and cached in `~/.cache/5bb-task/`.

## Configuration

Set `BB_CACHE_DIR` to override the cache location:

```bash
BB_CACHE_DIR=/opt/tools task build
```

## License

MIT – see the [LICENSE](../../LICENSE) file for details.
