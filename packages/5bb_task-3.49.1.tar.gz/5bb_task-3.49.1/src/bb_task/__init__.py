"""
bb_task – thin Python wrapper around ``task``, the task runner from
Taskfile.dev (a simpler Make alternative written in Go).

On first use the appropriate pre-built binary is downloaded from the
official GitHub release page and cached in ``~/.cache/5bb-task/``.
"""

from __future__ import annotations

import os
import platform
import stat
import subprocess
import sys
import tarfile
import urllib.request
from pathlib import Path

__version__ = "3.49.1"
_TASK_VERSION = __version__

# ---------------------------------------------------------------------------
# Platform detection helpers
# ---------------------------------------------------------------------------

def _arch() -> str:
    machine = platform.machine().lower()
    if machine in ("x86_64", "amd64"):
        return "amd64"
    if machine in ("i386", "i686"):
        return "386"
    if machine in ("aarch64", "arm64"):
        return "arm64"
    if machine.startswith("arm"):
        return "arm"
    return machine


def _os_name() -> str:
    system = platform.system().lower()
    if system == "darwin":
        return "darwin"
    if system == "windows":
        return "windows"
    return "linux"


def _binary_name() -> str:
    return "task.exe" if platform.system().lower() == "windows" else "task"


def _asset_name() -> str:
    ext = "zip" if platform.system().lower() == "windows" else "tar.gz"
    return f"task_{_os_name()}_{_arch()}.{ext}"


def _download_url() -> str:
    return (
        f"https://github.com/go-task/task/releases/download"
        f"/v{_TASK_VERSION}/{_asset_name()}"
    )


# ---------------------------------------------------------------------------
# Binary management
# ---------------------------------------------------------------------------

def _cache_dir() -> Path:
    return Path(os.environ.get("BB_CACHE_DIR", Path.home() / ".cache")) / "5bb-task"


def _binary_path() -> Path:
    return _cache_dir() / _binary_name()


def ensure_binary() -> Path:
    """Return the path to the task binary, downloading it if necessary."""
    binary = _binary_path()
    if binary.exists():
        return binary

    binary.parent.mkdir(parents=True, exist_ok=True)
    url = _download_url()
    asset_name = _asset_name()
    tmp_archive = binary.parent / asset_name

    print(f"[5bb-task] Downloading task v{_TASK_VERSION} …", file=sys.stderr)
    try:
        urllib.request.urlretrieve(url, tmp_archive)  # noqa: S310
    except Exception as exc:  # pragma: no cover
        raise SystemExit(
            f"[5bb-task] Failed to download {url}: {exc}"
        ) from exc

    if asset_name.endswith(".tar.gz"):
        with tarfile.open(tmp_archive, "r:gz") as tar:
            for member in tar.getmembers():
                if member.name == _binary_name() or member.name.endswith(
                    f"/{_binary_name()}"
                ):
                    member.name = _binary_name()
                    tar.extract(member, binary.parent)  # noqa: S202
                    break
    else:
        # Windows .zip
        import zipfile

        with zipfile.ZipFile(tmp_archive, "r") as zf:
            zf.extract(_binary_name(), binary.parent)

    tmp_archive.unlink(missing_ok=True)

    # Ensure the binary is executable.
    binary.chmod(binary.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    return binary


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run() -> None:
    """CLI entry point – delegates all arguments to the task binary."""
    binary = ensure_binary()
    args = [str(binary)] + sys.argv[1:]
    if platform.system().lower() == "windows":
        sys.exit(subprocess.call(args))
    os.execv(str(binary), args)
