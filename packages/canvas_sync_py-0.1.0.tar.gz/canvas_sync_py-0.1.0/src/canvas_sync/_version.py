"""
Canvas-Sync package version

Loading by setup.py and imported by __init__.py
"""

__version__ = "0.1.0"
