# ruff: noqa: PLR2004
"""Tests for LTreeTreebeardMixin."""

import pytest

from .models import TreebeardCategory


@pytest.fixture
def tree(db):
    """Create a sample tree:

    world
    ├── africa
    │   ├── kenya
    │   └── nigeria
    └── asia
        ├── japan
        │   └── tokyo
        └── india
    """
    world = TreebeardCategory.add_root(name="World", slug="world")
    africa = world.add_child(name="Africa", slug="africa")
    kenya = africa.add_child(name="Kenya", slug="kenya")
    nigeria = africa.add_child(name="Nigeria", slug="nigeria")
    asia = world.add_child(name="Asia", slug="asia")
    japan = asia.add_child(name="Japan", slug="japan")
    tokyo = japan.add_child(name="Tokyo", slug="tokyo")
    india = asia.add_child(name="India", slug="india")
    return {
        "world": world,
        "africa": africa,
        "kenya": kenya,
        "nigeria": nigeria,
        "asia": asia,
        "japan": japan,
        "tokyo": tokyo,
        "india": india,
    }


# =========================================================================
# Path computation
# =========================================================================


class TestPathComputation:
    def test_root_path_is_pk(self, tree):
        world = tree["world"]
        assert world.path == str(world.pk)

    def test_child_path(self, tree):
        world = tree["world"]
        asia = tree["asia"]
        assert asia.path == f"{world.pk}.{asia.pk}"

    def test_deep_path(self, tree):
        world = tree["world"]
        asia = tree["asia"]
        japan = tree["japan"]
        tokyo = tree["tokyo"]
        assert tokyo.path == f"{world.pk}.{asia.pk}.{japan.pk}.{tokyo.pk}"

    def test_path_updates_on_parent_change(self, tree):
        kenya = tree["kenya"]
        asia = tree["asia"]
        kenya.parent = asia
        kenya.save()
        assert kenya.path == f"{tree['world'].pk}.{asia.pk}.{kenya.pk}"

    def test_descendant_paths_update_on_move(self, tree):
        japan = tree["japan"]
        africa = tree["africa"]
        japan.parent = africa
        japan.save()
        tokyo = TreebeardCategory.objects.get(pk=tree["tokyo"].pk)
        expected = f"{tree['world'].pk}.{africa.pk}.{japan.pk}.{tokyo.pk}"
        assert tokyo.path == expected


# =========================================================================
# Tree construction
# =========================================================================


class TestTreeConstruction:
    def test_add_root(self, db):
        root = TreebeardCategory.add_root(name="Root", slug="root")
        assert root.parent is None
        assert root.is_root()
        assert root.path == str(root.pk)

    def test_add_child(self, tree):
        asia = tree["asia"]
        china = asia.add_child(name="China", slug="china")
        assert china.parent_id == asia.pk
        assert china.path == f"{tree['world'].pk}.{asia.pk}.{china.pk}"

    def test_add_sibling(self, tree):
        japan = tree["japan"]
        china = japan.add_sibling(name="China", slug="china")
        assert china.parent_id == japan.parent_id

    def test_move_to_child(self, tree):
        kenya = tree["kenya"]
        asia = tree["asia"]
        kenya.move(asia, position="child")
        assert kenya.parent_id == asia.pk

    def test_move_to_sibling(self, tree):
        kenya = tree["kenya"]
        japan = tree["japan"]
        kenya.move(japan, position="sibling")
        assert kenya.parent_id == japan.parent_id

    def test_move_to_root(self, tree):
        kenya = tree["kenya"]
        kenya.move(None, position="root")
        assert kenya.parent_id is None
        assert kenya.is_root()
        assert kenya.path == str(kenya.pk)

    def test_move_invalid_position(self, tree):
        with pytest.raises(ValueError, match="Invalid position"):
            tree["kenya"].move(tree["asia"], position="invalid")


# =========================================================================
# Navigation — querysets
# =========================================================================


class TestNavigation:
    def test_get_ancestors(self, tree):
        tokyo = tree["tokyo"]
        ancestors = list(tokyo.get_ancestors().values_list("name", flat=True))
        assert ancestors == ["World", "Asia", "Japan"]

    def test_get_ancestors_include_self(self, tree):
        tokyo = tree["tokyo"]
        ancestors = list(
            tokyo.get_ancestors(include_self=True).values_list("name", flat=True),
        )
        assert ancestors == ["World", "Asia", "Japan", "Tokyo"]

    def test_get_ancestors_of_root(self, tree):
        assert list(tree["world"].get_ancestors()) == []

    def test_get_descendants(self, tree):
        world = tree["world"]
        names = set(world.get_descendants().values_list("name", flat=True))
        assert names == {
            "Africa", "Kenya", "Nigeria", "Asia", "Japan", "Tokyo", "India",
        }

    def test_get_descendants_include_self(self, tree):
        asia = tree["asia"]
        names = set(
            asia.get_descendants(include_self=True).values_list("name", flat=True),
        )
        assert names == {"Asia", "Japan", "Tokyo", "India"}

    def test_get_children(self, tree):
        names = set(tree["world"].get_children().values_list("name", flat=True))
        assert names == {"Africa", "Asia"}

    def test_get_children_of_leaf(self, tree):
        assert list(tree["tokyo"].get_children()) == []

    def test_get_siblings(self, tree):
        names = set(tree["japan"].get_siblings().values_list("name", flat=True))
        assert names == {"India"}

    def test_get_siblings_include_self(self, tree):
        names = set(
            tree["japan"].get_siblings(include_self=True).values_list(
                "name", flat=True,
            ),
        )
        assert names == {"Japan", "India"}


# =========================================================================
# Navigation — single objects
# =========================================================================


class TestNavigationSingle:
    def test_get_parent(self, tree):
        assert tree["japan"].get_parent() == tree["asia"]

    def test_get_parent_of_root(self, tree):
        assert tree["world"].get_parent() is None

    def test_get_root(self, tree):
        assert tree["tokyo"].get_root() == tree["world"]

    def test_get_root_of_root(self, tree):
        assert tree["world"].get_root() == tree["world"]

    def test_get_first_child(self, tree):
        first = tree["world"].get_first_child()
        assert first is not None
        assert first.name in ("Africa", "Asia")

    def test_get_last_child(self, tree):
        last = tree["world"].get_last_child()
        assert last is not None
        assert last.name in ("Africa", "Asia")

    def test_get_first_child_of_leaf(self, tree):
        assert tree["tokyo"].get_first_child() is None

    def test_get_last_child_of_leaf(self, tree):
        assert tree["tokyo"].get_last_child() is None

    def test_get_prev_sibling(self, tree):
        asia_children = list(
            TreebeardCategory.objects.filter(
                parent=tree["asia"],
            ).order_by("path"),
        )
        if len(asia_children) >= 2:
            assert asia_children[1].get_prev_sibling() == asia_children[0]

    def test_get_next_sibling(self, tree):
        asia_children = list(
            TreebeardCategory.objects.filter(
                parent=tree["asia"],
            ).order_by("path"),
        )
        if len(asia_children) >= 2:
            assert asia_children[0].get_next_sibling() == asia_children[1]

    def test_get_prev_sibling_of_first(self, tree):
        asia_children = list(
            TreebeardCategory.objects.filter(
                parent=tree["asia"],
            ).order_by("path"),
        )
        assert asia_children[0].get_prev_sibling() is None

    def test_get_next_sibling_of_last(self, tree):
        asia_children = list(
            TreebeardCategory.objects.filter(
                parent=tree["asia"],
            ).order_by("path"),
        )
        assert asia_children[-1].get_next_sibling() is None


# =========================================================================
# Properties
# =========================================================================


class TestProperties:
    def test_label_is_pk_string(self, tree):
        assert tree["world"].label == str(tree["world"].pk)

    def test_depth_root(self, tree):
        assert tree["world"].get_depth() == 0

    def test_depth_child(self, tree):
        assert tree["asia"].get_depth() == 1

    def test_depth_grandchild(self, tree):
        assert tree["japan"].get_depth() == 2

    def test_depth_great_grandchild(self, tree):
        assert tree["tokyo"].get_depth() == 3

    def test_descendant_count(self, tree):
        assert tree["world"].get_descendant_count() == 7

    def test_children_count(self, tree):
        assert tree["world"].get_children_count() == 2

    def test_children_count_leaf(self, tree):
        assert tree["tokyo"].get_children_count() == 0


# =========================================================================
# Boolean checks
# =========================================================================


class TestBooleanChecks:
    def test_is_root(self, tree):
        assert tree["world"].is_root() is True
        assert tree["asia"].is_root() is False

    def test_is_leaf(self, tree):
        assert tree["tokyo"].is_leaf() is True
        assert tree["japan"].is_leaf() is False

    def test_is_ancestor_of(self, tree):
        assert tree["world"].is_ancestor_of(tree["tokyo"]) is True
        assert tree["asia"].is_ancestor_of(tree["tokyo"]) is True
        assert tree["africa"].is_ancestor_of(tree["tokyo"]) is False

    def test_is_ancestor_of_self(self, tree):
        assert tree["world"].is_ancestor_of(tree["world"]) is True

    def test_is_descendant_of(self, tree):
        assert tree["tokyo"].is_descendant_of(tree["world"]) is True
        assert tree["tokyo"].is_descendant_of(tree["asia"]) is True
        assert tree["tokyo"].is_descendant_of(tree["africa"]) is False

    def test_is_descendant_of_self(self, tree):
        assert tree["world"].is_descendant_of(tree["world"]) is True

    def test_is_child_of(self, tree):
        assert tree["japan"].is_child_of(tree["asia"]) is True
        assert tree["tokyo"].is_child_of(tree["asia"]) is False

    def test_is_sibling_of(self, tree):
        assert tree["japan"].is_sibling_of(tree["india"]) is True
        assert tree["japan"].is_sibling_of(tree["kenya"]) is False

    def test_is_sibling_of_self(self, tree):
        assert tree["japan"].is_sibling_of(tree["japan"]) is False


# =========================================================================
# Treebeard class methods
# =========================================================================


class TestTreebeardClassMethods:
    def test_get_root_nodes(self, tree):
        roots = TreebeardCategory.get_root_nodes()
        assert list(roots) == [tree["world"]]

    def test_get_first_root_node(self, tree):
        assert TreebeardCategory.get_first_root_node() == tree["world"]

    def test_get_last_root_node(self, tree):
        assert TreebeardCategory.get_last_root_node() == tree["world"]

    def test_get_first_root_node_empty(self, db):
        assert TreebeardCategory.get_first_root_node() is None

    def test_get_tree_full(self, tree):
        nodes = list(TreebeardCategory.get_tree().values_list("name", flat=True))
        assert nodes[0] == "World"
        assert len(nodes) == 8

    def test_get_tree_subtree(self, tree):
        nodes = list(
            TreebeardCategory.get_tree(parent=tree["asia"]).values_list(
                "name", flat=True,
            ),
        )
        assert "Asia" in nodes
        assert "Japan" in nodes
        assert "Tokyo" in nodes
        assert "Africa" not in nodes

    def test_get_annotated_list(self, tree):
        annotated = TreebeardCategory.get_annotated_list()
        assert len(annotated) == 8
        node, info = annotated[0]
        assert node.name == "World"
        assert info["level"] == 0
        assert info["open"] is True

    def test_get_annotated_list_max_depth(self, tree):
        annotated = TreebeardCategory.get_annotated_list(max_depth=1)
        for _, info in annotated:
            assert info["level"] <= 1

    def test_dump_bulk(self, tree):
        data = TreebeardCategory.dump_bulk()
        assert len(data) == 1
        assert data[0]["data"]["name"] == "World"
        assert "children" in data[0]
        child_names = {c["data"]["name"] for c in data[0]["children"]}
        assert child_names == {"Africa", "Asia"}

    def test_dump_bulk_no_ids(self, tree):
        data = TreebeardCategory.dump_bulk(keep_ids=False)
        assert "id" not in data[0]["data"]

    def test_load_bulk(self, db):
        bulk = [
            {
                "data": {"name": "Root", "slug": "root"},
                "children": [
                    {"data": {"name": "Child1", "slug": "child1"}},
                    {
                        "data": {"name": "Child2", "slug": "child2"},
                        "children": [
                            {"data": {"name": "Grandchild", "slug": "grandchild"}},
                        ],
                    },
                ],
            },
        ]
        ids = TreebeardCategory.load_bulk(bulk)
        assert len(ids) == 4
        root = TreebeardCategory.objects.get(name="Root")
        assert root.is_root()
        grandchild = TreebeardCategory.objects.get(name="Grandchild")
        assert grandchild.get_depth() == 2

    def test_load_bulk_under_parent(self, tree):
        bulk = [
            {
                "data": {"name": "China", "slug": "china"},
                "children": [
                    {"data": {"name": "Beijing", "slug": "beijing"}},
                ],
            },
        ]
        ids = TreebeardCategory.load_bulk(bulk, parent=tree["asia"])
        assert len(ids) == 2
        china = TreebeardCategory.objects.get(name="China")
        assert china.parent_id == tree["asia"].pk

    def test_get_descendants_group_count(self, tree):
        qs = TreebeardCategory.get_descendants_group_count()
        world = qs.get(name="World")
        assert world.descendants_count == 2


# =========================================================================
# QuerySet methods
# =========================================================================


class TestQuerySet:
    def test_roots(self, tree):
        roots = TreebeardCategory.objects.roots()
        assert list(roots) == [tree["world"]]

    def test_ancestors_of(self, tree):
        ancestors = TreebeardCategory.objects.ancestors_of(tree["tokyo"])
        names = list(ancestors.values_list("name", flat=True))
        assert names == ["World", "Asia", "Japan"]

    def test_descendants_of(self, tree):
        descendants = TreebeardCategory.objects.descendants_of(tree["asia"])
        names = set(descendants.values_list("name", flat=True))
        assert names == {"Japan", "Tokyo", "India"}

    def test_children_of(self, tree):
        children = TreebeardCategory.objects.children_of(tree["world"])
        names = set(children.values_list("name", flat=True))
        assert names == {"Africa", "Asia"}

    def test_siblings_of(self, tree):
        siblings = TreebeardCategory.objects.siblings_of(tree["japan"])
        names = set(siblings.values_list("name", flat=True))
        assert names == {"India"}


# =========================================================================
# Edge cases
# =========================================================================


class TestEdgeCases:
    def test_empty_tree(self, db):
        assert TreebeardCategory.objects.count() == 0
        assert TreebeardCategory.get_first_root_node() is None
        assert list(TreebeardCategory.get_tree()) == []

    def test_single_node_tree(self, db):
        root = TreebeardCategory.add_root(name="Only", slug="only")
        assert root.is_root() is True
        assert root.is_leaf() is True
        assert root.get_depth() == 0
        assert root.get_descendant_count() == 0
        assert root.get_children_count() == 0
        assert root.get_root() == root

    def test_multiple_roots(self, db):
        r1 = TreebeardCategory.add_root(name="Root1", slug="root1")
        r2 = TreebeardCategory.add_root(name="Root2", slug="root2")
        roots = TreebeardCategory.get_root_nodes()
        assert set(roots) == {r1, r2}

    def test_no_path_node(self, db):
        node = TreebeardCategory(name="NoPath", slug="nopath")
        assert node.label == ""
        assert node.get_depth() == 0
        assert list(node.get_ancestors()) == []
        assert list(node.get_descendants()) == []
        assert node.get_ancestor_paths() == []
