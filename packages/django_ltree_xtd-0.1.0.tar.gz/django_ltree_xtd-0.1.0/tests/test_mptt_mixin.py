# ruff: noqa: PLR2004
"""Tests for LTreeMPTTMixin."""

import pytest

from ltree.exceptions import InvalidMove

from .models import MPTTTag


@pytest.fixture
def tree(db):
    """Create a sample tree:

    root
    ├── child1
    │   ├── grandchild1
    │   └── grandchild2
    └── child2
        └── grandchild3
            └── great_grandchild
    """
    root = MPTTTag.objects.create(name="Root", parent=None)
    child1 = MPTTTag.objects.create(name="Child1", parent=root)
    grandchild1 = MPTTTag.objects.create(name="Grandchild1", parent=child1)
    grandchild2 = MPTTTag.objects.create(name="Grandchild2", parent=child1)
    child2 = MPTTTag.objects.create(name="Child2", parent=root)
    grandchild3 = MPTTTag.objects.create(name="Grandchild3", parent=child2)
    great_grandchild = MPTTTag.objects.create(
        name="GreatGrandchild", parent=grandchild3,
    )
    return {
        "root": root,
        "child1": child1,
        "grandchild1": grandchild1,
        "grandchild2": grandchild2,
        "child2": child2,
        "grandchild3": grandchild3,
        "great_grandchild": great_grandchild,
    }


# =========================================================================
# get_ancestors
# =========================================================================


class TestGetAncestors:
    def test_ancestors_default_order(self, tree):
        """Default: root-first order."""
        names = list(
            tree["great_grandchild"]
            .get_ancestors()
            .values_list("name", flat=True),
        )
        assert names == ["Root", "Child2", "Grandchild3"]

    def test_ancestors_ascending(self, tree):
        """ascending=True: parent-first order."""
        names = list(
            tree["great_grandchild"]
            .get_ancestors(ascending=True)
            .values_list("name", flat=True),
        )
        assert names == ["Grandchild3", "Child2", "Root"]

    def test_ancestors_include_self(self, tree):
        names = list(
            tree["grandchild1"]
            .get_ancestors(include_self=True)
            .values_list("name", flat=True),
        )
        assert names == ["Root", "Child1", "Grandchild1"]

    def test_ancestors_of_root(self, tree):
        assert list(tree["root"].get_ancestors()) == []


# =========================================================================
# get_children / get_descendants
# =========================================================================


class TestChildrenDescendants:
    def test_get_children(self, tree):
        names = set(tree["root"].get_children().values_list("name", flat=True))
        assert names == {"Child1", "Child2"}

    def test_get_children_of_leaf(self, tree):
        assert list(tree["great_grandchild"].get_children()) == []

    def test_get_descendants(self, tree):
        names = set(tree["root"].get_descendants().values_list("name", flat=True))
        assert names == {
            "Child1", "Grandchild1", "Grandchild2",
            "Child2", "Grandchild3", "GreatGrandchild",
        }

    def test_get_descendants_include_self(self, tree):
        names = set(
            tree["child2"]
            .get_descendants(include_self=True)
            .values_list("name", flat=True),
        )
        assert names == {"Child2", "Grandchild3", "GreatGrandchild"}

    def test_get_descendant_count(self, tree):
        assert tree["root"].get_descendant_count() == 6
        assert tree["child1"].get_descendant_count() == 2
        assert tree["great_grandchild"].get_descendant_count() == 0


# =========================================================================
# get_family / get_leafnodes
# =========================================================================


class TestFamilyAndLeaves:
    def test_get_family(self, tree):
        family = tree["child2"].get_family()
        names = set(family.values_list("name", flat=True))
        assert names == {"Root", "Child2", "Grandchild3", "GreatGrandchild"}

    def test_get_leafnodes(self, tree):
        leaves = tree["root"].get_leafnodes()
        names = set(leaves.values_list("name", flat=True))
        assert names == {"Grandchild1", "Grandchild2", "GreatGrandchild"}

    def test_get_leafnodes_include_self_on_leaf(self, tree):
        leaves = tree["grandchild1"].get_leafnodes(include_self=True)
        names = set(leaves.values_list("name", flat=True))
        assert "Grandchild1" in names

    def test_get_leafnodes_subtree(self, tree):
        leaves = tree["child2"].get_leafnodes()
        names = set(leaves.values_list("name", flat=True))
        assert names == {"GreatGrandchild"}


# =========================================================================
# get_level
# =========================================================================


class TestGetLevel:
    def test_root_level(self, tree):
        assert tree["root"].get_level() == 0

    def test_child_level(self, tree):
        assert tree["child1"].get_level() == 1

    def test_grandchild_level(self, tree):
        assert tree["grandchild1"].get_level() == 2

    def test_great_grandchild_level(self, tree):
        assert tree["great_grandchild"].get_level() == 3

    def test_level_property(self, tree):
        assert tree["child1"].level == 1
        assert tree["great_grandchild"].level == 3


# =========================================================================
# get_siblings
# =========================================================================


class TestGetSiblings:
    def test_siblings(self, tree):
        names = set(tree["child1"].get_siblings().values_list("name", flat=True))
        assert names == {"Child2"}

    def test_siblings_include_self(self, tree):
        names = set(
            tree["child1"]
            .get_siblings(include_self=True)
            .values_list("name", flat=True),
        )
        assert names == {"Child1", "Child2"}

    def test_siblings_of_only_child(self, tree):
        assert list(tree["great_grandchild"].get_siblings()) == []


# =========================================================================
# get_next_sibling / get_previous_sibling
# =========================================================================


class TestSiblingNavigation:
    def test_next_sibling(self, tree):
        children = list(
            MPTTTag.objects.filter(parent=tree["root"]).order_by("path"),
        )
        assert children[0].get_next_sibling() == children[1]

    def test_previous_sibling(self, tree):
        children = list(
            MPTTTag.objects.filter(parent=tree["root"]).order_by("path"),
        )
        assert children[1].get_previous_sibling() == children[0]

    def test_next_sibling_of_last(self, tree):
        children = list(
            MPTTTag.objects.filter(parent=tree["root"]).order_by("path"),
        )
        assert children[-1].get_next_sibling() is None

    def test_previous_sibling_of_first(self, tree):
        children = list(
            MPTTTag.objects.filter(parent=tree["root"]).order_by("path"),
        )
        assert children[0].get_previous_sibling() is None

    def test_next_sibling_of_only_child(self, tree):
        assert tree["great_grandchild"].get_next_sibling() is None

    def test_previous_sibling_of_only_child(self, tree):
        assert tree["great_grandchild"].get_previous_sibling() is None


# =========================================================================
# get_root
# =========================================================================


class TestGetRoot:
    def test_get_root_from_deep(self, tree):
        assert tree["great_grandchild"].get_root() == tree["root"]

    def test_get_root_from_root(self, tree):
        assert tree["root"].get_root() == tree["root"]


# =========================================================================
# Boolean checks
# =========================================================================


class TestBooleanChecks:
    def test_is_root_node(self, tree):
        assert tree["root"].is_root_node() is True
        assert tree["child1"].is_root_node() is False

    def test_is_child_node(self, tree):
        assert tree["root"].is_child_node() is False
        assert tree["child1"].is_child_node() is True
        assert tree["great_grandchild"].is_child_node() is True

    def test_is_leaf_node(self, tree):
        assert tree["great_grandchild"].is_leaf_node() is True
        assert tree["grandchild1"].is_leaf_node() is True
        assert tree["child1"].is_leaf_node() is False
        assert tree["root"].is_leaf_node() is False

    def test_is_ancestor_of(self, tree):
        assert tree["root"].is_ancestor_of(tree["great_grandchild"]) is True
        assert tree["child2"].is_ancestor_of(tree["great_grandchild"]) is True
        assert tree["child1"].is_ancestor_of(tree["great_grandchild"]) is False

    def test_is_ancestor_of_include_self(self, tree):
        assert tree["root"].is_ancestor_of(tree["root"], include_self=True) is True
        assert tree["root"].is_ancestor_of(tree["root"], include_self=False) is False

    def test_is_descendant_of(self, tree):
        assert tree["great_grandchild"].is_descendant_of(tree["root"]) is True
        assert tree["great_grandchild"].is_descendant_of(tree["child2"]) is True
        assert tree["great_grandchild"].is_descendant_of(tree["child1"]) is False

    def test_is_descendant_of_include_self(self, tree):
        assert (
            tree["root"].is_descendant_of(tree["root"], include_self=True) is True
        )
        assert (
            tree["root"].is_descendant_of(tree["root"], include_self=False) is False
        )


# =========================================================================
# move_to
# =========================================================================


class TestMoveTo:
    def test_move_to_first_child(self, tree):
        tree["grandchild1"].move_to(tree["child2"], position="first-child")
        assert tree["grandchild1"].parent_id == tree["child2"].pk

    def test_move_to_last_child(self, tree):
        tree["grandchild1"].move_to(tree["child2"], position="last-child")
        assert tree["grandchild1"].parent_id == tree["child2"].pk

    def test_move_to_left(self, tree):
        tree["grandchild3"].move_to(tree["child1"], position="left")
        assert tree["grandchild3"].parent_id == tree["root"].pk

    def test_move_to_right(self, tree):
        tree["grandchild3"].move_to(tree["child1"], position="right")
        assert tree["grandchild3"].parent_id == tree["root"].pk

    def test_move_to_root(self, tree):
        tree["child1"].move_to(None, position="first-child")
        assert tree["child1"].parent_id is None
        assert tree["child1"].is_root_node()

    def test_move_to_self_raises(self, tree):
        with pytest.raises(InvalidMove):
            tree["root"].move_to(tree["root"], position="first-child")

    def test_move_to_descendant_raises(self, tree):
        with pytest.raises(InvalidMove):
            tree["root"].move_to(tree["great_grandchild"], position="first-child")

    def test_move_invalid_position(self, tree):
        with pytest.raises(ValueError, match="Invalid position"):
            tree["child1"].move_to(tree["child2"], position="invalid")

    def test_move_cascades_descendants(self, tree):
        tree["child2"].move_to(tree["child1"], position="first-child")
        # Refresh from DB
        gc3 = MPTTTag.objects.get(pk=tree["grandchild3"].pk)
        ggc = MPTTTag.objects.get(pk=tree["great_grandchild"].pk)
        # grandchild3 should now be under child1 -> child2
        ancestors = list(gc3.get_ancestors().values_list("name", flat=True))
        assert "Child1" in ancestors
        assert "Child2" in ancestors
        # great_grandchild should have full ancestry
        assert ggc.get_level() == 4


# =========================================================================
# insert_at
# =========================================================================


class TestInsertAt:
    def test_insert_at_first_child(self, tree):
        node = MPTTTag(name="New")
        node.insert_at(tree["root"], position="first-child")
        assert node.parent_id == tree["root"].pk
        assert node.pk is None  # not saved

    def test_insert_at_with_save(self, tree):
        node = MPTTTag(name="New")
        node.insert_at(tree["root"], position="first-child", save=True)
        assert node.pk is not None
        assert node.parent_id == tree["root"].pk

    def test_insert_at_left(self, tree):
        node = MPTTTag(name="New")
        node.insert_at(tree["child1"], position="left")
        assert node.parent_id == tree["root"].pk

    def test_insert_at_invalid_position(self, tree):
        node = MPTTTag(name="New")
        with pytest.raises(ValueError, match="Invalid position"):
            node.insert_at(tree["root"], position="invalid")


# =========================================================================
# Manager methods
# =========================================================================


class TestManagerMethods:
    def test_root_nodes(self, tree):
        roots = MPTTTag.objects.root_nodes()
        assert list(roots) == [tree["root"]]

    def test_get_queryset_descendants(self, tree):
        qs = MPTTTag.objects.filter(name__in=["Child1", "Child2"])
        descendants = MPTTTag.objects.get_queryset_descendants(qs)
        names = set(descendants.values_list("name", flat=True))
        assert names == {
            "Grandchild1", "Grandchild2", "Grandchild3", "GreatGrandchild",
        }

    def test_get_queryset_descendants_include_self(self, tree):
        qs = MPTTTag.objects.filter(name="Child1")
        descendants = MPTTTag.objects.get_queryset_descendants(
            qs, include_self=True,
        )
        names = set(descendants.values_list("name", flat=True))
        assert names == {"Child1", "Grandchild1", "Grandchild2"}

    def test_get_queryset_ancestors(self, tree):
        qs = MPTTTag.objects.filter(name__in=["Grandchild1", "Grandchild3"])
        ancestors = MPTTTag.objects.get_queryset_ancestors(qs)
        names = set(ancestors.values_list("name", flat=True))
        assert names == {"Root", "Child1", "Child2"}

    def test_get_queryset_ancestors_include_self(self, tree):
        qs = MPTTTag.objects.filter(name="Grandchild1")
        ancestors = MPTTTag.objects.get_queryset_ancestors(
            qs, include_self=True,
        )
        names = set(ancestors.values_list("name", flat=True))
        assert names == {"Root", "Child1", "Grandchild1"}


# =========================================================================
# Edge cases
# =========================================================================


class TestEdgeCases:
    def test_empty_tree(self, db):
        assert MPTTTag.objects.count() == 0
        assert MPTTTag.objects.root_nodes().count() == 0

    def test_single_node(self, db):
        root = MPTTTag.objects.create(name="Only", parent=None)
        assert root.is_root_node() is True
        assert root.is_leaf_node() is True
        assert root.get_level() == 0
        assert root.get_descendant_count() == 0
        assert root.get_root() == root
        assert list(root.get_leafnodes()) == []
        assert list(root.get_leafnodes(include_self=True)) == [root]

    def test_multiple_roots(self, db):
        r1 = MPTTTag.objects.create(name="Root1", parent=None)
        r2 = MPTTTag.objects.create(name="Root2", parent=None)
        roots = MPTTTag.objects.root_nodes()
        assert set(roots) == {r1, r2}

    def test_unsaved_node(self, db):
        node = MPTTTag(name="Unsaved")
        assert node.label == ""
        assert node.get_level() == 0
        assert list(node.get_ancestors()) == []
        assert list(node.get_descendants()) == []
