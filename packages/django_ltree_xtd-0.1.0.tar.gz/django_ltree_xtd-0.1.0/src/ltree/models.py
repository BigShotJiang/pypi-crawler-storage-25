import pgtrigger
from django.db import models
from django.db.models import Count

from .exceptions import InvalidMove
from .fields import LTreeField
from .managers import LTreeManager


class LTreeBaseMixin(models.Model):
    """Base abstract mixin providing ltree fields and triggers.

    This is the shared foundation for both the Treebeard and MPTT mixins.
    It provides the parent FK, path field, triggers, and core navigation.
    """

    parent = models.ForeignKey(
        "self",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="children_set",
        db_index=True,
    )
    path = LTreeField(null=True, blank=True, db_index=True)

    objects = LTreeManager()

    class Meta:
        abstract = True
        ordering = ["path"]
        triggers = [
            pgtrigger.Trigger(
                name="compute_path",
                when=pgtrigger.Before,
                operation=pgtrigger.Insert | pgtrigger.UpdateOf("parent_id"),
                declare=[("parent_path", "ltree")],
                func="""
                    IF NEW.parent_id IS NOT NULL THEN
                        EXECUTE format(
                            'SELECT path FROM %I WHERE id = $1',
                            TG_TABLE_NAME
                        ) INTO parent_path USING NEW.parent_id;
                        NEW.path = parent_path || NEW.id::text::ltree;
                    ELSE
                        NEW.path = NEW.id::text::ltree;
                    END IF;
                    RETURN NEW;
                """,
            ),
            pgtrigger.Trigger(
                name="update_descendants",
                when=pgtrigger.After,
                operation=pgtrigger.UpdateOf("path"),
                condition=pgtrigger.Q(old__path__df=pgtrigger.F("new__path")),
                func="""
                    EXECUTE format(
                        'UPDATE %I SET path = $1 || subpath(path, nlevel($2))'
                        || ' WHERE path <@ $2 AND id != $3',
                        TG_TABLE_NAME
                    ) USING NEW.path, OLD.path, NEW.id;
                    RETURN NULL;
                """,
            ),
        ]

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Refresh path from database (set by trigger)
        self.refresh_from_db(fields=["path"])

    # =========================================================================
    # Core navigation — shared by both mixins
    # =========================================================================

    def _get_ancestors_qs(self, include_self=False):
        """Return a queryset of ancestors, ordered from root to parent."""
        if not self.path:
            return self.__class__.objects.none()
        qs = self.__class__.objects.filter(path__ancestor_of=self.path)
        if not include_self:
            qs = qs.exclude(pk=self.pk)
        return qs

    def _get_descendants_qs(self, include_self=False):
        """Return a queryset of all descendants."""
        if not self.path:
            return self.__class__.objects.none()
        qs = self.__class__.objects.filter(path__descendant_of=self.path)
        if not include_self:
            qs = qs.exclude(pk=self.pk)
        return qs

    def _get_children_qs(self):
        """Return a queryset of direct children."""
        return self.__class__.objects.filter(parent=self)

    def _get_siblings_qs(self, include_self=False):
        """Return a queryset of siblings."""
        qs = self.__class__.objects.filter(parent=self.parent)
        if not include_self:
            qs = qs.exclude(pk=self.pk)
        return qs

    @property
    def label(self):
        """Return the last segment of the path (this node's label)."""
        if not self.path:
            return ""
        return self.path.rsplit(".", 1)[-1]

    def get_ancestor_paths(self):
        """Return a list of ancestor path strings."""
        if not self.path:
            return []
        parts = self.path.split(".")
        return [".".join(parts[: i + 1]) for i in range(len(parts) - 1)]


# =============================================================================
# Treebeard-compatible Mixin
# =============================================================================


class LTreeTreebeardMixin(LTreeBaseMixin):
    """Abstract model providing a django-treebeard MP_Node compatible API.

    Paths are maintained by database triggers using PK-based labels.

    Example usage::

        class Category(LTreeTreebeardMixin):
            name = models.CharField(max_length=255)

        root = Category.add_root(name='Root')
        child = root.add_child(name='Child')
        grandchild = child.add_child(name='Grandchild')
    """

    class Meta(LTreeBaseMixin.Meta):
        abstract = True

    # =========================================================================
    # Class methods for tree construction
    # =========================================================================

    @classmethod
    def add_root(cls, **kwargs):
        """Add a root node to the tree.

        Returns:
            The newly created root node.
        """
        return cls.objects.create(parent=None, **kwargs)

    @classmethod
    def get_root_nodes(cls):
        """Return a queryset of all root nodes."""
        return cls.objects.filter(parent__isnull=True)

    @classmethod
    def get_first_root_node(cls):
        """Return the first root node, or None if the tree is empty."""
        return cls.get_root_nodes().first()

    @classmethod
    def get_last_root_node(cls):
        """Return the last root node, or None if the tree is empty."""
        return cls.get_root_nodes().last()

    @classmethod
    def get_tree(cls, parent=None):
        """Return a queryset of nodes in depth-first order.

        If parent is given, returns the subtree rooted at that node
        (including the parent). Otherwise returns the entire tree.
        """
        if parent is None:
            return cls.objects.all()
        return cls.objects.filter(path__descendant_of=parent.path)

    @classmethod
    def get_annotated_list(cls, parent=None, max_depth=None):
        """Return a list of (node, info) tuples for rendering nested trees.

        Each info dict contains:
        - 'open': True if this node opens a new level deeper than the previous
        - 'close': list of levels being closed after this node
        - 'level': the depth of this node (0-based relative to parent)
        """
        qs = cls.get_tree(parent)
        base_depth = parent.get_depth() if parent is not None else -1

        if max_depth is not None:
            qs = [n for n in qs if n.get_depth() - base_depth - 1 <= max_depth]
        else:
            qs = list(qs)

        result = []
        prev_depth = -1
        for node in qs:
            level = node.get_depth() - base_depth - 1
            if parent is None:
                level = node.get_depth()

            info = {
                "open": level > prev_depth,
                "close": list(range(prev_depth, level, -1))
                if level < prev_depth
                else [],
                "level": level,
            }
            result.append((node, info))
            prev_depth = level

        # Close remaining levels at the end
        if result:
            last_level = result[-1][1]["level"]
            result[-1][1]["close"] = list(range(last_level, -1, -1))

        return result

    @classmethod
    def dump_bulk(cls, parent=None, *, keep_ids=True):
        """Dump the tree (or subtree) as a nested Python data structure.

        Returns:
            List of dicts with 'data' and optional 'children' keys.
        """
        qs = cls.get_tree(parent)
        if parent is not None:
            qs = qs.exclude(pk=parent.pk)

        nodes_by_parent = {}
        for node in qs:
            nodes_by_parent.setdefault(node.parent_id, []).append(node)

        def _build(parent_id):
            children = nodes_by_parent.get(parent_id, [])
            result = []
            for node in children:
                data = {}
                for field in node._meta.get_fields():
                    if not field.concrete or field.is_relation:
                        continue
                    if field.name in ("path", "parent"):
                        continue
                    if field.name == "id" and not keep_ids:
                        continue
                    data[field.name] = getattr(node, field.name)
                entry = {"data": data}
                sub = _build(node.pk)
                if sub:
                    entry["children"] = sub
                result.append(entry)
            return result

        root_parent = parent.pk if parent else None
        return _build(root_parent)

    @classmethod
    def load_bulk(cls, bulk_data, parent=None):
        """Load a tree from a nested Python data structure.

        Returns:
            List of created node PKs.
        """
        created_ids = []

        def _load(data_list, parent_node):
            for item in data_list:
                data = item["data"]
                if parent_node:
                    node = parent_node.add_child(**data)
                else:
                    node = cls.add_root(**data)
                created_ids.append(node.pk)
                children = item.get("children", [])
                if children:
                    _load(children, node)

        _load(bulk_data, parent)
        return created_ids

    @classmethod
    def get_descendants_group_count(cls, parent=None):
        """Return root/child nodes annotated with a descendants_count attribute."""
        if parent is None:
            qs = cls.get_root_nodes()
        else:
            qs = cls.objects.filter(parent=parent)
        return qs.annotate(descendants_count=Count("children_set"))

    # =========================================================================
    # Instance methods for tree construction
    # =========================================================================

    def add_child(self, **kwargs):
        """Add a child node to this node.

        Returns:
            The newly created child node.
        """
        return self.__class__.objects.create(parent=self, **kwargs)

    def add_sibling(self, **kwargs):
        """Add a sibling node (same parent as this node).

        Returns:
            The newly created sibling node.
        """
        return self.__class__.objects.create(parent=self.parent, **kwargs)

    def move(self, target, position="child"):
        """Move this node to a new position in the tree.

        Args:
            target: The target node to move relative to.
            position: One of 'child', 'sibling', or 'root'.
        """
        if position == "child":
            self.parent = target
        elif position == "sibling":
            self.parent = target.parent if target else None
        elif position == "root":
            self.parent = None
        else:
            msg = (
                f"Invalid position: {position}. "
                "Use 'child', 'sibling', or 'root'."
            )
            raise ValueError(msg)
        self.save()

    # =========================================================================
    # Navigation methods — return querysets
    # =========================================================================

    def get_ancestors(self, *, include_self=False):
        """Return a queryset of ancestors, ordered from root to parent."""
        return self._get_ancestors_qs(include_self=include_self)

    def get_descendants(self, *, include_self=False):
        """Return a queryset of all descendants."""
        return self._get_descendants_qs(include_self=include_self)

    def get_children(self):
        """Return a queryset of direct children."""
        return self._get_children_qs()

    def get_siblings(self, *, include_self=False):
        """Return a queryset of siblings."""
        return self._get_siblings_qs(include_self=include_self)

    # =========================================================================
    # Navigation methods — return single objects
    # =========================================================================

    def get_parent(self):
        """Return the parent node, or None if this is a root."""
        return self.parent

    def get_root(self):
        """Return the root node of this tree."""
        if self.is_root():
            return self
        return self.get_ancestors().first()

    def get_first_child(self):
        """Return the first child node, or None."""
        return self.get_children().first()

    def get_last_child(self):
        """Return the last child node, or None."""
        return self.get_children().last()

    def get_first_sibling(self):
        """Return the first sibling (may be self)."""
        return self.get_siblings(include_self=True).first()

    def get_last_sibling(self):
        """Return the last sibling (may be self)."""
        return self.get_siblings(include_self=True).last()

    def get_prev_sibling(self):
        """Return the previous sibling, or None if this is first."""
        siblings = list(self.get_siblings(include_self=True))
        try:
            idx = siblings.index(self)
            if idx > 0:
                return siblings[idx - 1]
        except (ValueError, IndexError):
            pass
        return None

    def get_next_sibling(self):
        """Return the next sibling, or None if this is last."""
        siblings = list(self.get_siblings(include_self=True))
        try:
            idx = siblings.index(self)
            if idx < len(siblings) - 1:
                return siblings[idx + 1]
        except (ValueError, IndexError):
            pass
        return None

    # =========================================================================
    # Properties
    # =========================================================================

    def get_depth(self):
        """Return the depth of this node (0 for root nodes)."""
        if not self.path:
            return 0
        return self.path.count(".")

    def get_descendant_count(self):
        """Return the number of descendants."""
        return self.get_descendants().count()

    def get_children_count(self):
        """Return the number of direct children."""
        return self.get_children().count()

    # =========================================================================
    # Boolean checks
    # =========================================================================

    def is_root(self):
        """Return True if this is a root node (no parent)."""
        return self.parent_id is None

    def is_leaf(self):
        """Return True if this is a leaf node (no children)."""
        return not self.get_children().exists()

    def is_ancestor_of(self, node):
        """Return True if this node is an ancestor of the given node."""
        if not self.path or not node.path:
            return False
        return node.path.startswith(self.path + ".") or node.path == self.path

    def is_descendant_of(self, node):
        """Return True if this node is a descendant of the given node."""
        if not self.path or not node.path:
            return False
        return self.path.startswith(node.path + ".") or self.path == node.path

    def is_child_of(self, node):
        """Return True if this node is a direct child of the given node."""
        return self.parent_id == node.pk

    def is_sibling_of(self, node):
        """Return True if this node is a sibling of the given node."""
        return self.parent_id == node.parent_id and self.pk != node.pk


# =============================================================================
# MPTT-compatible Mixin
# =============================================================================


class LTreeMPTTMixin(LTreeBaseMixin):
    """Abstract model providing a django-mptt MPTTModel compatible API.

    Paths are maintained by database triggers using PK-based labels.
    Provides the same instance methods as django-mptt's MPTTModel.

    Example usage::

        class Tag(LTreeMPTTMixin):
            name = models.CharField(max_length=255)

        root = Tag.objects.create(name='Root', parent=None)
        child = Tag.objects.create(name='Child', parent=root)
        grandchild = Tag.objects.create(name='Grandchild', parent=child)
    """

    class Meta(LTreeBaseMixin.Meta):
        abstract = True

    # =========================================================================
    # MPTT instance methods — tree traversal / query
    # =========================================================================

    def get_ancestors(self, ascending=False, include_self=False):
        """Return a queryset of ancestor nodes.

        Args:
            ascending: If True, order from immediate parent to root.
                       If False (default), order from root to immediate parent.
            include_self: If True, include this node.
        """
        qs = self._get_ancestors_qs(include_self=include_self)
        if ascending:
            qs = qs.order_by("-path")
        return qs

    def get_children(self):
        """Return a queryset of immediate children in tree order."""
        return self._get_children_qs()

    def get_descendants(self, include_self=False):
        """Return a queryset of all descendants in tree (depth-first) order."""
        return self._get_descendants_qs(include_self=include_self)

    def get_descendant_count(self):
        """Return the number of descendants."""
        return self.get_descendants().count()

    def get_family(self):
        """Return a queryset containing ancestors, self, and all descendants."""
        if not self.path:
            return self.__class__.objects.none()
        return (
            self.__class__.objects.filter(path__ancestor_of=self.path)
            | self.__class__.objects.filter(path__descendant_of=self.path)
        ).distinct()

    def get_leafnodes(self, include_self=False):
        """Return a queryset of leaf nodes within this node's subtree."""
        descendants = self.get_descendants(include_self=include_self)
        # Leaf nodes are those that have no children
        return descendants.filter(
            ~models.Exists(
                self.__class__.objects.filter(parent=models.OuterRef("pk"))
            )
        )

    def get_level(self):
        """Return the depth of this node (0 for root)."""
        if not self.path:
            return 0
        return self.path.count(".")

    def get_next_sibling(self, **kwargs):
        """Return the next sibling node, or None."""
        siblings = list(self._get_siblings_qs(include_self=True))
        if kwargs:
            siblings = [
                s
                for s in siblings
                if all(getattr(s, k) == v for k, v in kwargs.items())
            ]
        try:
            idx = [s.pk for s in siblings].index(self.pk)
            if idx < len(siblings) - 1:
                return siblings[idx + 1]
        except (ValueError, IndexError):
            pass
        return None

    def get_previous_sibling(self, **kwargs):
        """Return the previous sibling node, or None."""
        siblings = list(self._get_siblings_qs(include_self=True))
        if kwargs:
            siblings = [
                s
                for s in siblings
                if all(getattr(s, k) == v for k, v in kwargs.items())
            ]
        try:
            idx = [s.pk for s in siblings].index(self.pk)
            if idx > 0:
                return siblings[idx - 1]
        except (ValueError, IndexError):
            pass
        return None

    def get_root(self):
        """Return the root node of this node's tree."""
        if self.is_root_node():
            return self
        return self._get_ancestors_qs().first()

    def get_siblings(self, include_self=False):
        """Return a queryset of sibling nodes."""
        return self._get_siblings_qs(include_self=include_self)

    # =========================================================================
    # MPTT boolean checks
    # =========================================================================

    def is_ancestor_of(self, other, include_self=False):
        """Return True if this node is an ancestor of other."""
        if not self.path or not other.path:
            return False
        if include_self and self.pk == other.pk:
            return True
        return other.path.startswith(self.path + ".")

    def is_descendant_of(self, other, include_self=False):
        """Return True if this node is a descendant of other."""
        if not self.path or not other.path:
            return False
        if include_self and self.pk == other.pk:
            return True
        return self.path.startswith(other.path + ".")

    def is_child_node(self):
        """Return True if the node has a parent."""
        return self.parent_id is not None

    def is_leaf_node(self):
        """Return True if the node has no children."""
        return not self.__class__.objects.filter(parent=self).exists()

    def is_root_node(self):
        """Return True if the node is a root node (no parent)."""
        return self.parent_id is None

    # =========================================================================
    # MPTT tree mutation
    # =========================================================================

    def move_to(self, target, position="first-child"):
        """Move this node relative to target.

        Args:
            target: Target node, or None to make this a root node.
            position: One of 'first-child', 'last-child', 'left', 'right'.

        Raises:
            InvalidMove: If the move would create a cycle.
        """
        if target is not None and self.path and target.path:
            if target.path.startswith(self.path + ".") or target.pk == self.pk:
                raise InvalidMove(
                    "Cannot move a node to be a child of itself or its descendants."
                )

        if position in ("first-child", "last-child"):
            self.parent = target
        elif position == "left":
            self.parent = target.parent if target else None
        elif position == "right":
            self.parent = target.parent if target else None
        else:
            msg = (
                f"Invalid position: {position}. "
                "Use 'first-child', 'last-child', 'left', or 'right'."
            )
            raise ValueError(msg)
        self.save()

    def insert_at(self, target, position="first-child", save=False):
        """Set the parent for an unsaved node relative to target.

        Args:
            target: Target node, or None for root.
            position: One of 'first-child', 'last-child', 'left', 'right'.
            save: If True, save immediately.
        """
        if position in ("first-child", "last-child"):
            self.parent = target
        elif position in ("left", "right"):
            self.parent = target.parent if target else None
        else:
            msg = (
                f"Invalid position: {position}. "
                "Use 'first-child', 'last-child', 'left', or 'right'."
            )
            raise ValueError(msg)
        if save:
            self.save()

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def level(self):
        """Return the depth level of this node (MPTT compatibility)."""
        return self.get_level()
