from django.db import models


class AncestorLookup(models.Lookup):
    """Check if the left side is an ancestor of (or equal to) the right side.

    Uses the @> operator: 'a.b' @> 'a.b.c' returns true.
    """

    lookup_name = "ancestor_of"

    def as_sql(self, compiler, connection):
        lhs, lhs_params = self.process_lhs(compiler, connection)
        rhs, rhs_params = self.process_rhs(compiler, connection)
        params = lhs_params + rhs_params
        return f"{lhs} @> {rhs}", params


class DescendantLookup(models.Lookup):
    """Check if the left side is a descendant of (or equal to) the right side.

    Uses the <@ operator: 'a.b.c' <@ 'a.b' returns true.
    """

    lookup_name = "descendant_of"

    def as_sql(self, compiler, connection):
        lhs, lhs_params = self.process_lhs(compiler, connection)
        rhs, rhs_params = self.process_rhs(compiler, connection)
        params = lhs_params + rhs_params
        return f"{lhs} <@ {rhs}", params


class MatchLookup(models.Lookup):
    """Match against an lquery pattern.

    Uses the ~ operator for lquery matching.
    Example: 'a.b.c' ~ 'a.*' returns true.
    """

    lookup_name = "match"

    def as_sql(self, compiler, connection):
        lhs, lhs_params = self.process_lhs(compiler, connection)
        rhs, rhs_params = self.process_rhs(compiler, connection)
        params = lhs_params + rhs_params
        return f"{lhs} ~ {rhs}::lquery", params


class DepthTransform(models.Transform):
    """Transform that returns the depth (number of labels) of an ltree path.

    Uses PostgreSQL's nlevel() function.
    Usage: MyModel.objects.filter(path__depth=2)
    """

    lookup_name = "depth"
    function = "nlevel"
    output_field = models.IntegerField()


class LTreeField(models.TextField):
    """A Django field for PostgreSQL's ltree data type.

    Stores labels in a hierarchical tree-like structure.
    Labels are sequences of alphanumeric characters and underscores
    separated by dots.

    Example paths: '1', '1.42', '1.42.103'
    """

    description = "PostgreSQL ltree"

    def db_type(self, connection):
        return "ltree"

    def from_db_value(self, value, expression, connection):
        return value

    def to_python(self, value):
        return value

    def get_prep_value(self, value):
        return value


# Register lookups
LTreeField.register_lookup(AncestorLookup)
LTreeField.register_lookup(DescendantLookup)
LTreeField.register_lookup(MatchLookup)
LTreeField.register_lookup(DepthTransform)
