from django.apps import AppConfig


class LtreeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "ltree"
    verbose_name = "PostgreSQL Ltree Support"

    def ready(self):
        # Fix django-pgtrigger compatibility with Django 5.2+
        #
        # pgtrigger patches makemigrations.MigrationAutodetector at the module
        # level, but Django 5.2 added Command.autodetector as a class attribute
        # that imports directly from django.db.migrations.autodetector, bypassing
        # pgtrigger's monkey-patch. Additionally Django 5.2 checks that both
        # makemigrations and migrate use the same autodetector class.
        try:
            from django.core.management.commands import makemigrations
            from django.core.management.commands import migrate

            patched = makemigrations.MigrationAutodetector
            if hasattr(makemigrations.Command, "autodetector"):
                makemigrations.Command.autodetector = patched
                migrate.Command.autodetector = patched
                migrate.MigrationAutodetector = patched
        except (ImportError, AttributeError):
            pass
