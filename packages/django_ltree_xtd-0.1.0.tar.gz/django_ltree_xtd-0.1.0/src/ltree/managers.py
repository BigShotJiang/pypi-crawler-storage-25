from django.db import models

from .querysets import LTreeQuerySet


class LTreeManager(models.Manager):
    """Custom manager that uses LTreeQuerySet."""

    def get_queryset(self):
        return LTreeQuerySet(self.model, using=self._db)

    def roots(self):
        """Return only root nodes."""
        return self.get_queryset().roots()

    def ancestors_of(self, node, *, include_self=False):
        """Return ancestors of the given node."""
        return self.get_queryset().ancestors_of(node, include_self=include_self)

    def descendants_of(self, node, *, include_self=False):
        """Return descendants of the given node."""
        return self.get_queryset().descendants_of(node, include_self=include_self)

    def children_of(self, node):
        """Return direct children of the given node."""
        return self.get_queryset().children_of(node)

    def siblings_of(self, node, *, include_self=False):
        """Return siblings of the given node."""
        return self.get_queryset().siblings_of(node, include_self=include_self)

    # MPTT-compatible manager methods

    def root_nodes(self):
        """Return a queryset of all root nodes (MPTT-compatible)."""
        return self.roots()

    def get_queryset_ancestors(self, queryset, include_self=False):
        """Given a queryset of nodes, return all their ancestors.

        Args:
            queryset: QuerySet of nodes.
            include_self: If True, include the original nodes.

        Returns:
            QuerySet of ancestor nodes.
        """
        from django.db.models import Q

        q = Q()
        for node in queryset:
            if node.path:
                q |= Q(path__ancestor_of=node.path)
        if not q:
            return self.none()
        qs = self.get_queryset().filter(q)
        if not include_self:
            qs = qs.exclude(pk__in=queryset.values_list("pk", flat=True))
        return qs.distinct()

    def get_queryset_descendants(self, queryset, include_self=False):
        """Given a queryset of nodes, return all their descendants.

        Args:
            queryset: QuerySet of nodes.
            include_self: If True, include the original nodes.

        Returns:
            QuerySet of descendant nodes.
        """
        from django.db.models import Q

        q = Q()
        for node in queryset:
            if node.path:
                q |= Q(path__descendant_of=node.path)
        if not q:
            return self.none()
        qs = self.get_queryset().filter(q)
        if not include_self:
            qs = qs.exclude(pk__in=queryset.values_list("pk", flat=True))
        return qs.distinct()
