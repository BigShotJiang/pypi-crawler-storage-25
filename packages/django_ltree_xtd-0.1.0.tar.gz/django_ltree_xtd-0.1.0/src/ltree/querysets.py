from django.db.models import QuerySet


class LTreeQuerySet(QuerySet):
    """Custom QuerySet with tree-specific query methods."""

    def roots(self):
        """Return only root nodes (nodes without a parent)."""
        return self.filter(parent__isnull=True)

    def ancestors_of(self, node, *, include_self=False):
        """Return ancestors of the given node."""
        if not node.path:
            return self.none()
        qs = self.filter(path__ancestor_of=node.path)
        if not include_self:
            qs = qs.exclude(pk=node.pk)
        return qs

    def descendants_of(self, node, *, include_self=False):
        """Return descendants of the given node."""
        if not node.path:
            return self.none()
        qs = self.filter(path__descendant_of=node.path)
        if not include_self:
            qs = qs.exclude(pk=node.pk)
        return qs

    def children_of(self, node):
        """Return direct children of the given node."""
        return self.filter(parent=node)

    def siblings_of(self, node, *, include_self=False):
        """Return siblings of the given node."""
        qs = self.filter(parent=node.parent)
        if not include_self:
            qs = qs.exclude(pk=node.pk)
        return qs
