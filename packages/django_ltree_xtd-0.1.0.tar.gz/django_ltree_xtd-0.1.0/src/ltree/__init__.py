from .fields import LTreeField

# Note: Import model mixins from ltree.models to avoid AppRegistryNotReady errors:
#   from ltree.models import LTreeTreebeardMixin, LTreeMPTTMixin

__all__ = [
    "LTreeField",
]
