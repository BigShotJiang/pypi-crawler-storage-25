class InvalidMove(Exception):
    """Raised when an invalid tree move is attempted."""
