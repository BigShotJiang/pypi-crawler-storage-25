"""Tests for unified sessions across daemon adapters."""

import threading
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from tsugite.daemon.adapters.base import BaseAdapter, ChannelContext
from tsugite.daemon.config import AgentConfig, DaemonConfig
from tsugite.daemon.session_store import SessionStore


class _StubAdapter(BaseAdapter):
    async def start(self):
        pass

    async def stop(self):
        pass


@pytest.fixture
def workspace_dir(tmp_path):
    return tmp_path / "workspace"


@pytest.fixture
def session_store(tmp_path):
    return SessionStore(tmp_path / "session_store.json", context_limits={"test-agent": 128000})


@pytest.fixture
def identity_map():
    return {
        "discord:123456789": "justyn",
        "http:justyn": "justyn",
        "http:web-anonymous": "justyn",
    }


def _make_adapter(workspace_dir, session_store, identity_map=None):
    agent_config = AgentConfig(workspace_dir=workspace_dir, agent_file="default")
    return _StubAdapter("test-agent", agent_config, session_store, identity_map=identity_map)


class TestIdentityResolution:
    """Tests for identity map lookup in BaseAdapter.resolve_user."""

    def test_linked_user_resolves_to_canonical(self, workspace_dir, session_store, identity_map):
        adapter = _make_adapter(workspace_dir, session_store, identity_map)

        ctx = ChannelContext(source="discord", channel_id="dm-chan", user_id="123456789", reply_to="discord:dm-chan")
        assert adapter.resolve_user("123456789", ctx) == "justyn"

        ctx_http = ChannelContext(source="http", channel_id=None, user_id="justyn", reply_to="http:justyn")
        assert adapter.resolve_user("justyn", ctx_http) == "justyn"

    def test_unlinked_user_gets_bare_id(self, workspace_dir, session_store, identity_map):
        adapter = _make_adapter(workspace_dir, session_store, identity_map)

        ctx = ChannelContext(source="discord", channel_id="dm-chan", user_id="999999", reply_to="discord:dm-chan")
        assert adapter.resolve_user("999999", ctx) == "999999"

    def test_empty_identity_map_passthrough(self, workspace_dir, session_store):
        adapter = _make_adapter(workspace_dir, session_store)

        ctx = ChannelContext(source="discord", channel_id="dm-chan", user_id="123456789", reply_to="discord:dm-chan")
        assert adapter.resolve_user("123456789", ctx) == "123456789"


class TestGroupIsolation:
    """Group chats produce composite keys, not unified identities."""

    def test_group_chat_isolated(self, workspace_dir, session_store, identity_map):
        adapter = _make_adapter(workspace_dir, session_store, identity_map)

        ctx = ChannelContext(
            source="discord",
            channel_id="guild-channel-42",
            user_id="123456789",
            reply_to="discord:guild-channel-42",
            metadata={"guild_id": "777"},
        )
        resolved = adapter.resolve_user("123456789", ctx)
        assert resolved == "discord:guild-channel-42:123456789"
        assert resolved != "justyn"

    def test_same_user_dm_vs_group_different(self, workspace_dir, session_store, identity_map):
        adapter = _make_adapter(workspace_dir, session_store, identity_map)

        dm_ctx = ChannelContext(source="discord", channel_id="dm-chan", user_id="123456789", reply_to="discord:dm-chan")
        group_ctx = ChannelContext(
            source="discord",
            channel_id="guild-chan",
            user_id="123456789",
            reply_to="discord:guild-chan",
            metadata={"guild_id": "777"},
        )
        assert adapter.resolve_user("123456789", dm_ctx) != adapter.resolve_user("123456789", group_ctx)


class TestSharedSessionStore:
    """Two adapters sharing a SessionStore get the same conversation_id for linked users."""

    def test_shared_session_same_conv_id(self, workspace_dir, tmp_path, identity_map):
        shared_store = SessionStore(tmp_path / "session_store.json", context_limits={"test-agent": 128000})

        discord_adapter = _make_adapter(workspace_dir, shared_store, identity_map)
        http_adapter = _make_adapter(workspace_dir, shared_store, identity_map)

        discord_ctx = ChannelContext(
            source="discord", channel_id="dm-chan", user_id="123456789", reply_to="discord:dm-chan"
        )
        http_ctx = ChannelContext(source="http", channel_id=None, user_id="justyn", reply_to="http:justyn")

        discord_user = discord_adapter.resolve_user("123456789", discord_ctx)
        http_user = http_adapter.resolve_user("justyn", http_ctx)

        assert discord_user == http_user == "justyn"

        session1 = shared_store.get_or_create_interactive(discord_user, "test-agent")
        session2 = shared_store.get_or_create_interactive(http_user, "test-agent")
        assert session1.id == session2.id


class TestSessionStoreInteractive:
    """Tests for interactive session management in SessionStore."""

    def test_get_or_create_interactive(self, tmp_path):
        store = SessionStore(tmp_path / "session_store.json")
        session = store.get_or_create_interactive("user1", "agent1")
        assert session.id == "daemon_agent1_user1"
        assert session.source == "interactive"
        assert session.user_id == "user1"

    def test_get_or_create_interactive_idempotent(self, tmp_path):
        store = SessionStore(tmp_path / "session_store.json")
        s1 = store.get_or_create_interactive("user1", "agent1")
        s2 = store.get_or_create_interactive("user1", "agent1")
        assert s1.id == s2.id

    def test_different_agents_different_sessions(self, tmp_path):
        store = SessionStore(tmp_path / "session_store.json")
        s1 = store.get_or_create_interactive("user1", "agent1")
        s2 = store.get_or_create_interactive("user1", "agent2")
        assert s1.id != s2.id


class TestSessionStoreThreadSafety:
    """SessionStore operations are thread-safe."""

    def test_concurrent_get_or_create(self, tmp_path):
        import threading

        store = SessionStore(tmp_path / "session_store.json")
        results = {}

        def get_session(user_id):
            session = store.get_or_create_interactive(user_id, "test-agent")
            results[user_id] = session.id

        threads = [threading.Thread(target=get_session, args=(f"user-{i}",)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(results) == 10
        assert len(set(results.values())) == 10


class TestNoIdentityLinksBackwardCompat:
    """Empty identity_links = current behavior."""

    def test_default_empty(self):
        config = DaemonConfig(
            agents={"test": AgentConfig(workspace_dir=Path("/tmp/ws"), agent_file="default")},
        )
        assert config.identity_links == {}

    def test_identity_links_parsed(self):
        config = DaemonConfig(
            agents={"test": AgentConfig(workspace_dir=Path("/tmp/ws"), agent_file="default")},
            identity_links={"justyn": ["discord:123", "http:justyn"]},
        )
        assert config.identity_links["justyn"] == ["discord:123", "http:justyn"]


try:
    import cronsim  # noqa: F401

    _has_cronsim = True
except ImportError:
    _has_cronsim = False


@pytest.mark.skipif(not _has_cronsim, reason="cronsim not installed (required by http adapter)")
class TestHTTPAdapterResolveUser:
    """HTTPAgentAdapter.resolve_http_user resolves identity for direct session store calls."""

    def test_resolve_linked(self, workspace_dir, tmp_path, identity_map):
        from tsugite.daemon.adapters.http import HTTPAgentAdapter

        agent_config = AgentConfig(workspace_dir=workspace_dir, agent_file="default")
        store = SessionStore(tmp_path / "session_store.json")
        adapter = HTTPAgentAdapter("test-agent", agent_config, store, identity_map=identity_map)

        assert adapter.resolve_http_user("justyn") == "justyn"
        assert adapter.resolve_http_user("web-anonymous") == "justyn"

    def test_resolve_unlinked(self, workspace_dir, tmp_path, identity_map):
        from tsugite.daemon.adapters.http import HTTPAgentAdapter

        agent_config = AgentConfig(workspace_dir=workspace_dir, agent_file="default")
        store = SessionStore(tmp_path / "session_store.json")
        adapter = HTTPAgentAdapter("test-agent", agent_config, store, identity_map=identity_map)

        assert adapter.resolve_http_user("someone-else") == "someone-else"

    def test_resolve_no_map(self, workspace_dir, tmp_path):
        from tsugite.daemon.adapters.http import HTTPAgentAdapter

        agent_config = AgentConfig(workspace_dir=workspace_dir, agent_file="default")
        store = SessionStore(tmp_path / "session_store.json")
        adapter = HTTPAgentAdapter("test-agent", agent_config, store)

        assert adapter.resolve_http_user("web-anonymous") == "web-anonymous"


class TestCompactSessionClearsSkills:
    """Compaction should clear loaded skills so they get re-loaded in the new session."""

    @pytest.mark.asyncio
    async def test_compact_session_clears_loaded_skills(self, workspace_dir, tmp_path):
        from tsugite.history import SessionStorage
        from tsugite.history.models import Turn

        history_dir = tmp_path / "history"
        history_dir.mkdir()

        store = SessionStore(tmp_path / "session_store.json", context_limits={"test-agent": 128000})
        session = store.get_or_create_interactive("test-user", "test-agent")
        conv_id = session.id

        session_path = history_dir / f"{conv_id}.jsonl"
        storage = SessionStorage.create(
            agent_name="test-agent",
            model="openai:gpt-4o-mini",
            session_path=session_path,
        )
        for i in range(5):
            storage.record_turn(
                messages=[
                    {"role": "user", "content": f"message {i}"},
                    {"role": "assistant", "content": f"reply {i}"},
                ],
                final_answer=f"reply {i}",
            )

        adapter = _make_adapter(workspace_dir, store)

        from tsugite.tools.skills import get_skill_manager

        manager = get_skill_manager()
        manager._loaded_skills["test-skill"] = "skill content"

        with (
            patch("tsugite.daemon.memory.get_context_limit", return_value=128_000),
            patch("tsugite.daemon.memory.infer_compaction_model", return_value="openai:gpt-4o-mini"),
            patch("tsugite.daemon.memory.split_turns_for_compaction") as mock_split,
            patch("tsugite.daemon.memory.summarize_session", new_callable=AsyncMock, return_value="Summary"),
            patch("tsugite.history.get_history_dir", return_value=history_dir),
            patch("tsugite.history.storage.get_history_dir", return_value=history_dir),
            patch("tsugite.history.storage.get_machine_name", return_value="test"),
            patch("tsugite.hooks.fire_compact_hooks", new_callable=AsyncMock),
        ):
            old_turns = [
                Turn(
                    timestamp=datetime.now(timezone.utc),
                    messages=[{"role": "user", "content": "old"}],
                )
            ]
            recent_turns = [
                Turn(
                    timestamp=datetime.now(timezone.utc),
                    messages=[{"role": "user", "content": "recent"}],
                )
            ]
            mock_split.return_value = (old_turns, recent_turns)

            await adapter._compact_session(conv_id)

        assert manager._loaded_skills == {}


class TestCompactionLocking:
    """Tests for session compaction lock/queue mechanism."""

    def test_begin_compaction_returns_true_first_time(self, session_store):
        assert session_store.begin_compaction("user1", "test-agent") is True

    def test_begin_compaction_returns_false_if_already_compacting(self, session_store):
        session_store.begin_compaction("user1", "test-agent")
        assert session_store.begin_compaction("user1", "test-agent") is False

    def test_end_compaction_allows_new_begin(self, session_store):
        session_store.begin_compaction("user1", "test-agent")
        session_store.end_compaction("user1", "test-agent")
        assert session_store.begin_compaction("user1", "test-agent") is True

    def test_is_compacting(self, session_store):
        assert session_store.is_compacting("user1", "test-agent") is False
        session_store.begin_compaction("user1", "test-agent")
        assert session_store.is_compacting("user1", "test-agent") is True
        session_store.end_compaction("user1", "test-agent")
        assert session_store.is_compacting("user1", "test-agent") is False

    def test_wait_for_compaction_returns_immediately_if_not_compacting(self, session_store):
        assert session_store.wait_for_compaction("user1", "test-agent", timeout=0.1) is True

    def test_wait_for_compaction_blocks_until_done(self, session_store):
        session_store.begin_compaction("user1", "test-agent")
        result = [None]

        def waiter():
            result[0] = session_store.wait_for_compaction("user1", "test-agent", timeout=5)

        t = threading.Thread(target=waiter)
        t.start()
        session_store.end_compaction("user1", "test-agent")
        t.join(timeout=2)
        assert not t.is_alive()
        assert result[0] is True

    def test_wait_for_compaction_times_out(self, session_store):
        session_store.begin_compaction("user1", "test-agent")
        assert session_store.wait_for_compaction("user1", "test-agent", timeout=0.05) is False
        # Clean up
        session_store.end_compaction("user1", "test-agent")

    def test_different_users_independent(self, session_store):
        session_store.begin_compaction("user1", "test-agent")
        assert session_store.begin_compaction("user2", "test-agent") is True
        assert session_store.is_compacting("user1", "test-agent") is True
        assert session_store.is_compacting("user2", "test-agent") is True

    def test_end_compaction_idempotent(self, session_store):
        """end_compaction on a non-compacting session is a no-op."""
        session_store.end_compaction("user1", "test-agent")  # Should not raise
