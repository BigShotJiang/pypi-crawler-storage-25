import httpx


class Service:
    """服务基类"""

    SERVICE_URL = None
    DESCRIPTION = "服务基类"
    ABBREVIATIONS = ["service", "s"]

    @staticmethod
    def redirect(httpx_client: httpx.Client, url: str) -> dict:
        response = httpx_client.get(url=url, follow_redirects=True)
        res_status_code = response.status_code
        if res_status_code == 200:
            # 获取cookies
            cookies = httpx_client.cookies
            url = response.url.__str__()
            if cookies:
                return {"url": url, "cookies": cookies}
            else:
                raise ValueError("登录失败,未获取cookies")
        else:
            raise ValueError("登录失败")

    @staticmethod
    async def redirect_async(httpx_client: httpx.AsyncClient, url: str) -> dict:
        response = await httpx_client.get(url=url, follow_redirects=True)
        res_status_code = response.status_code
        if res_status_code == 200:
            # 获取cookies
            cookies = httpx_client.cookies
            url = response.url.__str__()
            if cookies:
                return {"url": url, "cookies": cookies}
            else:
                raise ValueError("登录失败,未获取cookies")
        else:
            raise ValueError("登录失败")


# fine_auth_token
class BigData(Service):
    """数据中台"""

    SERVICE_URL = "https://idaas-cas.yonghui.cn/cas/login?service=http://cas-prod.bigdata.yonghui.cn:7070/redirect?redirectUrl=https://bigdata.yonghui.cn"
    DESCRIPTION = "数据中台"
    ABBREVIATIONS = ["bigdata", "bd"]

    @staticmethod
    def redirect(httpx_client: httpx.Client, url: str) -> dict:
        response = httpx_client.get(url=url, follow_redirects=True)
        res_status_code = response.status_code
        if res_status_code == 200:
            # 获取cookies
            cookies = httpx_client.cookies
            url = response.url.__str__()
            if cookies:
                jsessionid = httpx_client.cookies.get("JSESSIONID")
                return {"url": url, "cookies": cookies, "JSESSIONID": jsessionid}
            else:
                raise ValueError("登录失败,未获取cookies")
        else:
            raise ValueError("登录失败")

    @staticmethod
    async def redirect_async(httpx_client: httpx.AsyncClient, url: str) -> dict:
        response = await httpx_client.get(url=url, follow_redirects=True)
        res_status_code = response.status_code
        if res_status_code == 200:
            # 获取cookies
            cookies = httpx_client.cookies
            url = response.url.__str__()
            if cookies:
                jsessionid = httpx_client.cookies.get("JSESSIONID")
                return {"url": url, "cookies": cookies, "JSESSIONID": jsessionid}
            else:
                raise ValueError("登录失败,未获取cookies")
        else:
            raise ValueError("登录失败")


class YhBi(Service):
    """YHBI"""

    SERVICE_URL = "https://idaas-cas.yonghui.cn/cas/login?service=http://cas-prod.bigdata.yonghui.cn:7070/redirect?redirectUrl=https://bigdata.yonghui.cn"
    DESCRIPTION = "YHBI"
    ABBREVIATIONS = ["yhbi", "bi"]

    @staticmethod
    def redirect(httpx_client: httpx.Client, url: str) -> dict:
        response = httpx_client.get(url=url, follow_redirects=True)
        res_status_code = response.status_code
        if res_status_code == 200:
            # 获取cookies
            cookies = httpx_client.cookies
            url = response.url.__str__()
            if cookies:
                fine_auth_token = httpx_client.cookies.get("fine_auth_token")
                return {
                    "url": url,
                    "cookies": cookies,
                    "fine_auth_token": fine_auth_token,
                }
            else:
                raise ValueError("登录失败,未获取cookies")
        else:
            raise ValueError("登录失败")

    @staticmethod
    async def redirect_async(httpx_client: httpx.AsyncClient, url: str) -> dict:
        response = await httpx_client.get(url=url, follow_redirects=True)
        res_status_code = response.status_code
        if res_status_code == 200:
            # 获取cookies
            cookies = httpx_client.cookies
            url = response.url.__str__()
            if cookies:
                fine_auth_token = httpx_client.cookies.get("fine_auth_token")
                return {
                    "url": url,
                    "cookies": cookies,
                    "fine_auth_token": fine_auth_token,
                }
            else:
                raise ValueError("登录失败,未获取cookies")
        else:
            raise ValueError("登录失败")


class Olap(BigData):
    """OLAP"""

    SERVICE_URL = "https://idaas-cas.yonghui.cn/cas/login?service=http://cas-prod.bigdata.yonghui.cn:7070/redirect?redirectUrl=https://bigdata.yonghui.cn/#/olap/main"
    DESCRIPTION = "OLAP"
    ABBREVIATIONS = ["olap", "o"]