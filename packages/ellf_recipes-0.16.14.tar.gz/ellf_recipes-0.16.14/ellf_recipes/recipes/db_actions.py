from typing import Optional, Union

from prodigy.components.db import connect
from prodigy.util import log, set_hashes

from ellf_recipes_sdk import (
    ChoiceProps,
    Dataset,
    Input,
    InputDataset,
    ListProps,
    Props,
    action_recipe,
    save_examples,
    teams_type,
)


@teams_type(
    "merge",
    title="Merge multiple datasets",
    field_props={
        "in_sets": Props(title="Datasets to merge", exists=True),
        "out_set": Props(title="New dataset", exists=False),
    },
)
class DatasetMerge:
    in_sets: list[InputDataset]
    out_set: Dataset

    def merge(self) -> None:
        """Merge all examples from ``in_sets`` into a new dataset.

        Contract:
            Raises:
                Database errors from ``save_examples()`` (not caught).
                Errors from ``dataset.load()`` if any source dataset
                    is inaccessible (not caught).
        """
        data = []
        for dataset in self.in_sets:
            data.extend(dataset.load())
        save_examples(str(self.out_set.id), data)


@teams_type(
    "copy",
    title="Copy a dataset",
    field_props={
        # fmt: off
        "in_data": Props(
            title="Input data", description="Name of the resource to copy", exists=True
        ),
        "out_set": Props(
            title="New dataset",
            description="Name of the new dataset to copy to",
            exists=False,
        ),
        # fmt: on
    },
)
class DatasetCopy:
    in_data: Union[InputDataset, Input]
    out_set: Dataset

    def copy(self) -> None:
        """Copy examples from an asset or dataset into a new dataset.

        When the source is an ``Input`` (asset), each example is hashed
        and given ``"answer": "accept"`` if the key is absent.

        Contract:
            Raises:
                Database errors from ``save_examples()`` (not caught).
                Errors from ``self.in_data.load()`` if the source
                    is inaccessible (not caught).
        """
        if isinstance(self.in_data, Input):
            data = []
            for eg in self.in_data.load():
                eg = set_hashes(eg)
                if "answer" not in eg:
                    eg["answer"] = "accept"
                data.append(eg)
        else:
            data = list(self.in_data.load())
        save_examples(str(self.out_set.id), data)


@action_recipe(
    title="Dataset operations",
    description="Merge, copy and export annotated data",
    field_props={"mode": ChoiceProps(title="Operation")},
    cli_names={
        "mode-copy.in-data-input-dataset": "copy.in-dataset",
        "mode-copy.in-data-input": "copy.in-asset",
        "mode-copy.out-set": "copy.out-set",
        "mode-merge.in-sets": "merge.in-sets",
        "mode-merge.out-sets": "merge.out-sets",
    },
)
def db_actions(*, mode: Union[DatasetCopy, DatasetMerge]) -> None:
    if isinstance(mode, DatasetCopy):
        mode.copy()
    elif isinstance(mode, DatasetMerge):
        mode.merge()


@action_recipe(
    title="Migrate dataset to structured",
    description="Convert an unstructured dataset to the structured format",
    field_props={
        "dataset": Props(
            title="Dataset to migrate",
            description="The unstructured dataset to convert",
            exists=True,
        ),
        "input_keys": ListProps(
            title="Input keys",
            description="Keys from each example that form the input (e.g. text, image)",
        ),
        "session_id": Props(
            title="Session ID",
            description="Session ID to assign to migrated examples",
        ),
    },
)
def migrate_to_structured(
    *,
    dataset: InputDataset,
    input_keys: list[str],
    user_ann_keys: Optional[list[str]] = None,
    session_id: str = "migrated",
) -> None:
    """Migrate an unstructured dataset to structured format.

    Reads all examples from the unstructured table, converts each to a
    structured Example via ``from_unst_user()``, and writes them to the
    same dataset after marking it as structured. The original unstructured
    examples are left intact.

    Contract:
        Raises:
            DatasetNotFound: If the source dataset does not exist.
            Database errors from ``add_st_examples()`` (not caught).
    """
    if user_ann_keys is None:
        user_ann_keys = []
    db = connect()
    dataset_name = dataset.name
    ds = db.get_dataset_by_name(dataset_name)
    if ds.structured:
        log(
            f"RECIPE: Dataset '{dataset_name}' is already structured, skipping migration"
        )
        return
    st_examples = db.get_st_dataset_examples_from_unst(
        dataset_name, input_keys=input_keys, user_ann_keys=user_ann_keys
    )
    log(
        f"RECIPE: Migrating dataset '{dataset_name}' "
        f"({len(st_examples)} examples) to structured format"
    )
    db.mark_dataset_structured(dataset_name)
    db.add_st_examples(st_examples, dataset_name=dataset_name, session_id=session_id)
    log(f"RECIPE: Migration complete for '{dataset_name}'")
