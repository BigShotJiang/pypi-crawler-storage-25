"""Smoke tests for the ``halton-meter bodies …`` and ``halton-meter project …``
CLI commands.

PR1 ships these as inert plumbing: the table is created by the migration
but the proxy hot path doesn't write to it yet (PR2 wires that). Tests
here cover the empty-table happy path, the basic round-trip of an
on/off project setting, and the parse_duration helper.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from click.testing import CliRunner

from halton_meter.bodies import (
    BodyStats,
    fetch_body,
    fetch_stats,
    parse_duration,
    purge_old_bodies,
)
from halton_meter.cli import cli
from halton_meter.project_settings_cli import fetch_settings, set_body_capture

# --------------------------------------------------------------------------- #
# Fixture: an initialised SQLite db with the v0.1.13 schema (PR1 migrations). #
# --------------------------------------------------------------------------- #


@pytest.fixture
def init_db(tmp_path: Path) -> Path:
    """Spin up the daemon's storage init against tmp_path/db.sqlite.

    Goes through the real SQLAlchemy create_all + migration step so the
    PRAGMA user_version stamping is exercised in tests.
    """
    import asyncio

    from halton_meter.storage import StorageManager

    db_path = tmp_path / "db.sqlite"

    async def _init() -> None:
        async with StorageManager(db_path):
            pass

    asyncio.run(_init())
    return db_path


# --------------------------------------------------------------------------- #
# Migration / schema                                                          #
# --------------------------------------------------------------------------- #


def test_migration_creates_request_bodies_and_project_settings(init_db: Path):
    """Both new tables exist and PRAGMA user_version is stamped to 2."""
    conn = sqlite3.connect(str(init_db))
    try:
        names = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        assert "request_bodies" in names
        assert "project_settings" in names
        # captured_at index exists
        idx_names = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='index'"
            )
        }
        assert "idx_request_bodies_captured_at" in idx_names

        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 2
    finally:
        conn.close()


def test_migration_is_idempotent_on_second_init(init_db: Path):
    """Re-initialising the same DB twice is a no-op (no errors, no double-create)."""
    import asyncio

    from halton_meter.storage import StorageManager

    async def _init() -> None:
        async with StorageManager(init_db):
            pass

    # First init was via fixture; this is the second.
    asyncio.run(_init())

    conn = sqlite3.connect(str(init_db))
    try:
        names = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        assert "request_bodies" in names
        assert "project_settings" in names
        version = conn.execute("PRAGMA user_version").fetchone()[0]
        assert version >= 2
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# parse_duration                                                              #
# --------------------------------------------------------------------------- #


def test_parse_duration_days():
    assert parse_duration("30d") == timedelta(days=30)


def test_parse_duration_hours():
    assert parse_duration("12h") == timedelta(hours=12)


def test_parse_duration_minutes():
    assert parse_duration("45m") == timedelta(minutes=45)


def test_parse_duration_plain_int_means_days():
    assert parse_duration("7") == timedelta(days=7)


def test_parse_duration_invalid_raises():
    with pytest.raises(ValueError):
        parse_duration("forever")
    with pytest.raises(ValueError):
        parse_duration("")


# --------------------------------------------------------------------------- #
# bodies show / stats / purge — empty table                                   #
# --------------------------------------------------------------------------- #


def test_bodies_show_no_row(init_db: Path):
    """Showing a request id that doesn't have a body row is graceful."""
    body = fetch_body(init_db, str(uuid.uuid4()))
    assert body is None


def test_bodies_show_cli_smoke(init_db: Path):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["bodies", "show", str(uuid.uuid4()), "--db", str(init_db)],
    )
    assert result.exit_code == 0
    assert "No body captured" in result.output


def test_bodies_stats_empty_returns_zero_counts(init_db: Path):
    stats = fetch_stats(init_db)
    assert isinstance(stats, BodyStats)
    assert stats.row_count == 0
    assert stats.total_captured_bytes == 0
    assert stats.redaction_summary_totals == {}


def test_bodies_stats_cli_smoke(init_db: Path):
    runner = CliRunner()
    result = runner.invoke(cli, ["bodies", "stats", "--db", str(init_db)])
    assert result.exit_code == 0
    assert "No body rows captured yet" in result.output


def test_bodies_stats_cli_json_format(init_db: Path):
    runner = CliRunner()
    result = runner.invoke(
        cli, ["bodies", "stats", "--db", str(init_db), "--format", "json"]
    )
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["row_count"] == 0
    assert payload["redaction_summary_totals"] == {}


def test_bodies_purge_dry_run_empty(init_db: Path):
    result = purge_old_bodies(init_db, older_than=timedelta(days=30), dry_run=True)
    assert result.rows_deleted == 0
    assert result.dry_run is True
    assert result.vacuumed is False


def test_bodies_purge_cli_dry_run_smoke(init_db: Path):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["bodies", "purge", "--db", str(init_db), "--older-than", "30d", "--dry-run"],
    )
    assert result.exit_code == 0
    assert "Dry-run" in result.output


# --------------------------------------------------------------------------- #
# Body row round-trip via direct SQL                                           #
# --------------------------------------------------------------------------- #


def _insert_request_and_body(
    db_path: Path,
    *,
    captured_at: datetime,
    request_body: str = "{}",
    response_body: str = "{}",
    redaction_summary: str | None = None,
) -> str:
    """Insert a paired requests + request_bodies row for testing.

    Returns the request id. Used to seed body fixtures without depending on
    the (PR2) hot-path writer.
    """
    request_id = str(uuid.uuid4())
    project_id = str(uuid.uuid4())
    # Unique slug per insert so multiple calls in the same test don't
    # collide on the projects.slug UNIQUE constraint.
    project_slug = f"test-proj-{project_id[:8]}"
    now_iso = datetime.now(tz=UTC).isoformat()
    captured_iso = captured_at.replace(tzinfo=UTC).astimezone(UTC).isoformat()

    with sqlite3.connect(str(db_path)) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute(
            "INSERT INTO projects (id, name, slug, created_at) VALUES (?, ?, ?, ?)",
            (project_id, project_slug, project_slug, now_iso),
        )
        conn.execute(
            "INSERT INTO requests "
            "(id, project_id, provider, model, mode, "
            " input_tokens, output_tokens, thinking_tokens, "
            " cache_read_tokens, cache_write_tokens, "
            " latency_ms, tokens_complete, requested_at, recorded_at, "
            " status) "
            "VALUES (?, ?, 'anthropic', 'claude-x', 'standard', "
            " 0, 0, 0, 0, 0, 0.0, 1, ?, ?, 'success')",
            (request_id, project_id, now_iso, now_iso),
        )
        conn.execute(
            "INSERT INTO request_bodies "
            "(request_id, request_body, response_body, "
            " request_body_bytes, response_body_bytes, "
            " request_truncated, response_truncated, "
            " streaming_incomplete, redaction_applied, "
            " redaction_summary, captured_at) "
            "VALUES (?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?)",
            (
                request_id,
                request_body,
                response_body,
                len(request_body),
                len(response_body),
                1 if redaction_summary else 0,
                redaction_summary,
                captured_iso,
            ),
        )
        conn.commit()
    return request_id


def test_fetch_body_round_trip(init_db: Path):
    """Insert a body row via raw SQL and read it back via fetch_body."""
    request_id = _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        request_body='{"hello":"world"}',
        response_body='{"ok":true}',
        redaction_summary='{"openai_key": 1}',
    )
    body = fetch_body(init_db, request_id)
    assert body is not None
    assert body.request_body == '{"hello":"world"}'
    assert body.response_body == '{"ok":true}'
    assert body.redaction_applied is True
    assert body.redaction_summary == '{"openai_key": 1}'


def test_purge_deletes_old_rows_only(init_db: Path):
    """Old body rows go; recent ones stay."""
    old_id = _insert_request_and_body(
        init_db, captured_at=datetime.now(tz=UTC) - timedelta(days=120)
    )
    new_id = _insert_request_and_body(
        init_db, captured_at=datetime.now(tz=UTC) - timedelta(days=10)
    )

    result = purge_old_bodies(init_db, older_than=timedelta(days=90))
    assert result.rows_deleted == 1
    assert result.dry_run is False

    assert fetch_body(init_db, old_id) is None
    assert fetch_body(init_db, new_id) is not None


def test_stats_after_inserts(init_db: Path):
    _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        redaction_summary='{"openai_key": 2, "jwt": 1}',
    )
    _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        redaction_summary='{"openai_key": 1}',
    )
    stats = fetch_stats(init_db)
    assert stats.row_count == 2
    assert stats.redaction_summary_totals == {"openai_key": 3, "jwt": 1}


# --------------------------------------------------------------------------- #
# project show / set                                                           #
# --------------------------------------------------------------------------- #


def test_project_show_no_project(init_db: Path):
    """Querying a slug with no project row returns None and the CLI is quiet."""
    settings = fetch_settings(init_db, "does-not-exist")
    assert settings is None

    runner = CliRunner()
    result = runner.invoke(
        cli, ["project", "show", "does-not-exist", "--db", str(init_db)]
    )
    assert result.exit_code == 0
    assert "No project with slug" in result.output


def test_project_set_creates_project_and_setting(init_db: Path):
    """Setting body-capture for a brand-new slug auto-creates the project row."""
    result = set_body_capture(init_db, "demo-proj", enabled=False)
    assert result.project_existed is False
    assert result.project_created is True
    assert result.previous_value is None
    assert result.new_value is False

    settings = fetch_settings(init_db, "demo-proj")
    assert settings is not None
    assert settings.body_capture_enabled is False
    assert settings.updated_at is not None


def test_project_set_idempotent_round_trip(init_db: Path):
    """Flipping a value twice produces a stable end state."""
    set_body_capture(init_db, "demo", enabled=False)
    second = set_body_capture(init_db, "demo", enabled=False)
    assert second.previous_value is False
    assert second.new_value is False

    third = set_body_capture(init_db, "demo", enabled=True)
    assert third.previous_value is False
    assert third.new_value is True

    settings = fetch_settings(init_db, "demo")
    assert settings is not None
    assert settings.body_capture_enabled is True


def test_project_set_cli_smoke(init_db: Path):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["project", "set", "cli-demo", "body-capture", "off", "--db", str(init_db)],
    )
    assert result.exit_code == 0
    assert "off" in result.output

    # Verify via direct fetch.
    settings = fetch_settings(init_db, "cli-demo")
    assert settings is not None
    assert settings.body_capture_enabled is False


def test_project_set_cli_rejects_unknown_setting(init_db: Path):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["project", "set", "cli-demo", "made-up", "yes", "--db", str(init_db)],
    )
    assert result.exit_code == 2
    assert "Unknown setting" in result.output


def test_project_set_cli_rejects_bad_value(init_db: Path):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["project", "set", "cli-demo", "body-capture", "maybe", "--db", str(init_db)],
    )
    assert result.exit_code == 2
    assert "Invalid value" in result.output


# --------------------------------------------------------------------------- #
# BodiesConfig is wired                                                       #
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
# v0.1.13 PR3 — polished `bodies show` panels + `bodies stats` per-project    #
# --------------------------------------------------------------------------- #


def test_bodies_show_renders_panels(init_db: Path):
    """The polished show output includes a header panel and body panels.

    String-contains assertions: rich panels print their titles inline so
    we look for those, plus the request id, the `Captured body` header
    title, and the body content.
    """
    request_id = _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        request_body='{"hello":"world"}',
        response_body='{"ok":true}',
        redaction_summary='{"openai_key": 1}',
    )

    runner = CliRunner()
    result = runner.invoke(
        cli, ["bodies", "show", request_id, "--db", str(init_db)]
    )
    assert result.exit_code == 0, result.output
    # Header panel
    assert "Captured body" in result.output
    assert request_id in result.output
    # Provider/model/project columns came from the joined requests row.
    assert "anthropic" in result.output
    assert "claude-x" in result.output
    # Redaction badge fired.
    assert "openai_key" in result.output
    # Body panels.
    assert "Request body" in result.output
    assert "Response body" in result.output
    assert '"hello":"world"' in result.output
    assert '"ok":true' in result.output


def test_bodies_show_truncated_badge(init_db: Path):
    """``request_truncated`` / ``response_truncated`` flags surface as badges."""
    request_id = str(uuid.uuid4())
    project_id = str(uuid.uuid4())
    project_slug = f"trunc-proj-{project_id[:8]}"
    now_iso = datetime.now(tz=UTC).isoformat()
    captured_iso = now_iso
    with sqlite3.connect(str(init_db)) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute(
            "INSERT INTO projects (id, name, slug, created_at) VALUES (?, ?, ?, ?)",
            (project_id, project_slug, project_slug, now_iso),
        )
        conn.execute(
            "INSERT INTO requests "
            "(id, project_id, provider, model, mode, "
            " input_tokens, output_tokens, thinking_tokens, "
            " cache_read_tokens, cache_write_tokens, "
            " latency_ms, tokens_complete, requested_at, recorded_at, status) "
            "VALUES (?, ?, 'anthropic', 'claude-x', 'standard', "
            " 0, 0, 0, 0, 0, 0.0, 1, ?, ?, 'success')",
            (request_id, project_id, now_iso, now_iso),
        )
        conn.execute(
            "INSERT INTO request_bodies "
            "(request_id, request_body, response_body, "
            " request_body_bytes, response_body_bytes, "
            " request_truncated, response_truncated, "
            " streaming_incomplete, redaction_applied, "
            " redaction_summary, captured_at) "
            "VALUES (?, ?, ?, ?, ?, 1, 1, 0, 0, NULL, ?)",
            (
                request_id,
                "{}",
                "{}",
                999_999,  # original size much larger than stored
                999_999,
                captured_iso,
            ),
        )
        conn.commit()

    runner = CliRunner()
    result = runner.invoke(
        cli, ["bodies", "show", request_id, "--db", str(init_db)]
    )
    assert result.exit_code == 0, result.output
    assert "TRUNCATED" in result.output
    # Both sides should be flagged.
    assert "request truncated" in result.output
    assert "response truncated" in result.output


def test_bodies_stats_per_project_breakdown(init_db: Path):
    """``stats`` includes per-project rollup + redaction-applied %."""
    # Seed two projects, three rows total (2 + 1).
    _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        redaction_summary='{"openai_key": 1}',
    )
    _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        redaction_summary='{"openai_key": 2}',
    )
    _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        redaction_summary=None,  # no redaction
    )

    stats = fetch_stats(init_db)
    assert stats.row_count == 3
    assert stats.redaction_applied_count == 2
    # 2 / 3 = 66.67%
    assert stats.redaction_applied_pct == pytest.approx(66.67, abs=0.01)
    # Each `_insert_request_and_body` invents a unique slug, so we expect
    # three project rollup rows; each with row_count == 1.
    assert len(stats.per_project) == 3
    for p in stats.per_project:
        assert p.row_count == 1


def test_bodies_stats_cli_renders_per_project_and_retention(init_db: Path):
    """The CLI stats output names the new sections + the retention horizon."""
    _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        redaction_summary='{"openai_key": 1}',
    )
    runner = CliRunner()
    result = runner.invoke(cli, ["bodies", "stats", "--db", str(init_db)])
    assert result.exit_code == 0, result.output
    assert "Per-project breakdown" in result.output
    assert "Retention horizon" in result.output
    assert "Redaction applied" in result.output


def test_bodies_stats_cli_json_includes_new_fields(init_db: Path):
    """``--format json`` exposes the new pct + per-project + retention fields."""
    _insert_request_and_body(
        init_db,
        captured_at=datetime.now(tz=UTC),
        redaction_summary='{"openai_key": 1}',
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["bodies", "stats", "--db", str(init_db), "--format", "json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["row_count"] == 1
    assert payload["redaction_applied_count"] == 1
    assert payload["redaction_applied_pct"] == 100.0
    assert "retention_days" in payload
    assert isinstance(payload["per_project"], list)
    assert len(payload["per_project"]) == 1
    assert payload["per_project"][0]["row_count"] == 1


def test_bodies_config_defaults():
    """The new master switch + retention defaults look right."""
    from halton_meter.config import HaltonConfig

    cfg = HaltonConfig()
    assert cfg.bodies.enabled is True
    assert cfg.bodies.max_body_bytes == 512 * 1024
    assert cfg.bodies.retention_days == 90
    assert cfg.bodies.cache_ttl_seconds == 300
