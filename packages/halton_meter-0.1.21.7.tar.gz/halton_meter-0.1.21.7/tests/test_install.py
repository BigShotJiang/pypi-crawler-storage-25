"""Tests for ``halton_meter.install`` (OS-level supervisor setup).

Layer 1 of the three-layer connectivity-on-crash fix. See
``memory/decisions.md`` 2026-04-29.
"""

from __future__ import annotations

import plistlib
import shutil
import subprocess
import sys as _sys
from pathlib import Path
from typing import Any

import pytest

from halton_meter import install as install_module

# --------------------------------------------------------------------------- #
# Pure-builder tests                                                           #
# --------------------------------------------------------------------------- #


def test_build_macos_plist_round_trip(tmp_path: Path) -> None:
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"
    work_dir = tmp_path / "work"

    raw = install_module.build_macos_plist(halton, log_dir, work_dir)
    parsed = plistlib.loads(raw)

    assert parsed["Label"] == "com.haltonlabs.meter"
    # v0.1.21.1 (2026-05-05): NO KeepAlive key at all. Any KeepAlive
    # value implies ``RunAtLoad=True`` per ``man launchd.plist``,
    # which silently overrode our explicit RunAtLoad=False in v0.1.21
    # and kept auto-loading the daemon at login. Drop the key entirely.
    # See ``decisions.md`` 2026-05-05 -- "v0.1.21.1 KeepAlive removal".
    assert "KeepAlive" not in parsed, (
        "daemon plist must NOT have a KeepAlive key (v0.1.21.1) — any "
        "value implies RunAtLoad=True and breaks manual-start"
    )
    assert parsed["RunAtLoad"] is False
    assert parsed["ThrottleInterval"] == 1
    assert parsed["ProgramArguments"][0] == str(halton)
    assert parsed["ProgramArguments"][1] == "daemon"
    assert parsed["StandardOutPath"].endswith("daemon.out.log")
    assert parsed["StandardErrorPath"].endswith("daemon.err.log")
    assert parsed["WorkingDirectory"] == str(work_dir)
    assert parsed["ProcessType"] == "Background"
    assert "PATH" in parsed["EnvironmentVariables"]


def test_build_systemd_unit_contains_required_directives(tmp_path: Path) -> None:
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"

    text = install_module.build_systemd_unit(halton, log_dir)

    assert "Restart=always" in text
    assert "RestartSec=1" in text
    assert f"ExecStart={halton} daemon" in text
    assert "WantedBy=default.target" in text
    assert "After=network.target" in text


# --------------------------------------------------------------------------- #
# Subprocess + filesystem fixtures                                             #
# --------------------------------------------------------------------------- #


class _RunRecorder:
    """Captures every subprocess.run call so tests can assert argv lists."""

    def __init__(self, fail_on: tuple[str, ...] = ()) -> None:
        self.calls: list[list[str]] = []
        self.fail_on = fail_on

    def __call__(self, argv: list[str], *args: Any, **kwargs: Any) -> Any:
        self.calls.append(list(argv))
        rc = 0
        for token in self.fail_on:
            if token in argv:
                rc = 1
                break
        return subprocess.CompletedProcess(argv, rc, stdout="", stderr="")


@pytest.fixture(autouse=True)
def _redirect_install_mode_path(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """v0.1.3 P0-3: redirect ``INSTALL_MODE_PATH`` to a tmp dir so the
    uninstall path's ``read_install_mode()`` / ``remove_install_mode()``
    never touch the developer's real ``~/.halton-meter/install-mode``."""
    from halton_meter import init as init_module

    target = tmp_path / "halton-install-mode-shadow" / "install-mode"
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", target)


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))  # type: ignore[arg-type]
    return tmp_path


@pytest.fixture
def fake_halton_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    binary = tmp_path / "bin" / "halton-meter"
    binary.parent.mkdir(parents=True, exist_ok=True)
    binary.write_text("#!/bin/sh\nexit 0\n")
    binary.chmod(0o755)
    monkeypatch.setattr(install_module.shutil, "which", lambda _name: str(binary))
    return binary


# --------------------------------------------------------------------------- #
# Platform dispatch                                                            #
# --------------------------------------------------------------------------- #


def test_install_macos_writes_plist_and_calls_launchctl(
    fake_home: Path,
    fake_halton_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.install()
    assert rc == 0

    plist_path = fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.plist"
    assert plist_path.exists()
    parsed = plistlib.loads(plist_path.read_bytes())
    # v0.1.21.1: NO KeepAlive on the daemon plist (manual-start).
    assert "KeepAlive" not in parsed

    watchdog_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.watchdog.plist"
    )
    assert watchdog_plist_path.exists()
    watchdog_parsed = plistlib.loads(watchdog_plist_path.read_bytes())
    # v0.1.21.1: NO KeepAlive on the watchdog plist either — same
    # ``man launchd.plist`` rule (KeepAlive => RunAtLoad=True) that
    # broke the daemon's manual-start applies here too. Watchdog now
    # follows the daemon: starts only on ``halton-meter start``.
    assert "KeepAlive" not in watchdog_parsed
    assert watchdog_parsed["Label"] == "com.haltonlabs.meter.watchdog"
    assert watchdog_parsed["ProgramArguments"][1] == "watchdog"

    # 2C.2 (v0.1.6): edge plist installed alongside daemon + watchdog.
    edge_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.edge.plist"
    )
    assert edge_plist_path.exists()
    edge_parsed = plistlib.loads(edge_plist_path.read_bytes())
    assert edge_parsed["KeepAlive"] is True
    assert edge_parsed["Label"] == "com.haltonlabs.meter.edge"
    assert edge_parsed["ProgramArguments"][1] == "edge"

    # v0.1.21.2: modern launchctl verb sequence. Daemon + watchdog use
    # bootout + bootstrap + kickstart (RunAtLoad=False — kickstart is
    # required to actually start them). Edge + userenv have
    # RunAtLoad=True so bootstrap alone starts them; we still bootout
    # first for idempotency.
    bootouts = [c for c in rec.calls if len(c) >= 2 and c[1] == "bootout"]
    bootstraps = [c for c in rec.calls if len(c) >= 2 and c[1] == "bootstrap"]
    kickstarts = [c for c in rec.calls if len(c) >= 2 and c[1] == "kickstart"]
    # 4 plists each get bootout+bootstrap; 2 (daemon, watchdog) also kickstart.
    assert len(bootouts) == 4
    assert len(bootstraps) == 4
    assert len(kickstarts) == 2
    # Bootstrap calls carry the plist path as the last arg.
    bootstrap_paths = {c[-1] for c in bootstraps}
    assert str(plist_path) in bootstrap_paths
    assert str(watchdog_plist_path) in bootstrap_paths
    assert str(edge_plist_path) in bootstrap_paths


def test_install_macos_skips_plist_write_when_unchanged(
    fake_home: Path,
    fake_halton_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P0-2 idempotency: re-running install with identical plist content
    must not rewrite the plist file (no mtime churn). launchctl unload+load
    is still issued because that pair is itself idempotent."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")

    # First run: writes the plist files.
    rec1 = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec1)
    assert install_module.install() == 0

    plist_path = fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.plist"
    watchdog_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.watchdog.plist"
    )
    edge_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.edge.plist"
    )
    mtime_before = plist_path.stat().st_mtime_ns
    watchdog_mtime_before = watchdog_plist_path.stat().st_mtime_ns
    edge_mtime_before = edge_plist_path.stat().st_mtime_ns

    # Second run: identical builder output -> no write should happen.
    rec2 = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec2)
    assert install_module.install() == 0

    # mtimes are stable iff the file was not rewritten.
    assert plist_path.stat().st_mtime_ns == mtime_before
    assert watchdog_plist_path.stat().st_mtime_ns == watchdog_mtime_before
    assert edge_plist_path.stat().st_mtime_ns == edge_mtime_before

    # v0.1.21.4: launchctl ran with the modern verb sequence. Per
    # label, the order is bootout → poll-for-disappearance via
    # ``launchctl print`` (until rc != 0 or ~2s ceiling) → bootstrap.
    # daemon + watchdog also kickstart afterwards. With a fake
    # ``subprocess.run`` that always returns rc=0, the print poll
    # never sees the label disappear and runs to its 20-iteration
    # ceiling — so the count is dominated by print polls. Validate
    # the verb-shape, not the inflated total.
    bootout_calls = [c for c in rec2.calls if len(c) >= 2 and c[1] == "bootout"]
    bootstrap_calls = [c for c in rec2.calls if len(c) >= 2 and c[1] == "bootstrap"]
    kickstart_calls = [c for c in rec2.calls if len(c) >= 2 and c[1] == "kickstart"]
    assert len(bootout_calls) == 4
    assert len(bootstrap_calls) == 4
    assert len(kickstart_calls) == 2


def test_install_macos_rewrites_plist_when_content_drifts(
    fake_home: Path,
    fake_halton_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """P0-2 idempotency contract: when the existing plist on disk does NOT
    byte-match what the builder produces (e.g. the builder grew a new key),
    the file must be rewritten so the new shape lands."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")

    rec1 = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec1)
    assert install_module.install() == 0

    plist_path = fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.plist"
    # Mutate on-disk plist to simulate drift / older shape.
    plist_path.write_bytes(b"<plist><dict><key>Stale</key><true/></dict></plist>")
    drifted_size = plist_path.stat().st_size

    rec2 = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec2)
    assert install_module.install() == 0

    # File rewritten -> contents differ from drifted state.
    assert plist_path.stat().st_size != drifted_size
    parsed = plistlib.loads(plist_path.read_bytes())
    assert parsed["Label"] == "com.haltonlabs.meter"


def test_build_watchdog_plist_round_trip(tmp_path: Path) -> None:
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"
    work_dir = tmp_path / "work"

    raw = install_module.build_watchdog_plist(halton, log_dir, work_dir)
    parsed = plistlib.loads(raw)

    assert parsed["Label"] == "com.haltonlabs.meter.watchdog"
    # v0.1.21.1 (2026-05-05): NO KeepAlive key. Any KeepAlive value
    # implies ``RunAtLoad=True`` per ``man launchd.plist``; that
    # override kept the watchdog auto-loading at login in v0.1.21
    # despite our explicit RunAtLoad=False. Manual-start parity with
    # the daemon plist: starts only on ``halton-meter start``. See
    # ``decisions.md`` 2026-05-05 -- "v0.1.21.1 KeepAlive removal"
    # for the trade-off (we lose layer-2 revival on the empty-snapshot
    # exit path; deliberate, see install.py docstring).
    assert "KeepAlive" not in parsed
    # v0.1.21: watchdog follows daemon lifecycle.
    assert parsed["RunAtLoad"] is False
    assert parsed["ProgramArguments"][0] == str(halton)
    assert parsed["ProgramArguments"][1] == "watchdog"
    assert parsed["StandardOutPath"].endswith("watchdog.out.log")
    assert parsed["StandardErrorPath"].endswith("watchdog.err.log")


def test_build_macos_plist_edge_round_trip(tmp_path: Path) -> None:
    """2C.2 (v0.1.6): edge plist must use unconditional KeepAlive=True
    (NOT {SuccessfulExit: False}), point at ``halton-meter edge``, and
    have a 5s ExitTimeOut (no SQLite to flush)."""
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"
    work_dir = tmp_path / "work"

    raw = install_module.build_macos_plist_edge(halton, log_dir, work_dir)
    parsed = plistlib.loads(raw)

    assert parsed["Label"] == "com.haltonlabs.meter.edge"
    # KeepAlive=True is THE load-bearing assertion: the edge owns the
    # user-facing port and must respawn on any exit including clean ones.
    # Anything else (SuccessfulExit semantics) lets a clean exit strand
    # every running app.
    assert parsed["KeepAlive"] is True
    assert parsed["RunAtLoad"] is True
    assert parsed["ProgramArguments"][0] == str(halton)
    assert parsed["ProgramArguments"][1] == "edge"
    assert parsed["ThrottleInterval"] == 1
    # No SQLite flush, no in-process system-proxy cleanup -> short timeout.
    assert parsed["ExitTimeOut"] == 5
    assert parsed["StandardOutPath"].endswith("edge.out.log")
    assert parsed["StandardErrorPath"].endswith("edge.err.log")
    # PATH should match the daemon's so the spawned `halton-meter edge`
    # can find its dependencies.
    assert "/usr/local/bin" in parsed["EnvironmentVariables"]["PATH"]
    assert "/opt/homebrew/bin" in parsed["EnvironmentVariables"]["PATH"]


def test_build_macos_plist_userenv_round_trip(tmp_path: Path) -> None:
    """v0.1.19 Task 0.1: userenv login agent must be one-shot (RunAtLoad
    + KeepAlive=False), point at ``halton-meter _apply-user-env``, and
    write to userenv.{out,err}.log.

    THE load-bearing assertions: ``RunAtLoad=True`` (fires at every
    login) and ``KeepAlive=False`` literal (NOT the dict form
    ``{SuccessfulExit: False}`` — we want a one-shot, NOT respawn-on-
    crash). Anything else lets a setenv failure tarpit launchd in a
    respawn loop.
    """
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"
    work_dir = tmp_path / "work"

    raw = install_module.build_macos_plist_userenv(halton, log_dir, work_dir)
    parsed = plistlib.loads(raw)

    assert parsed["Label"] == "com.haltonlabs.meter.userenv"
    # One-shot at login, NOT respawn-on-crash.
    assert parsed["RunAtLoad"] is True
    assert parsed["KeepAlive"] is False
    assert parsed["ProgramArguments"] == [str(halton), "_apply-user-env"]
    assert parsed["StandardOutPath"].endswith("userenv.out.log")
    assert parsed["StandardErrorPath"].endswith("userenv.err.log")
    assert parsed["WorkingDirectory"] == str(work_dir)
    assert parsed["ProcessType"] == "Background"
    assert parsed["ExitTimeOut"] == 5
    assert "/usr/local/bin" in parsed["EnvironmentVariables"]["PATH"]
    assert "/opt/homebrew/bin" in parsed["EnvironmentVariables"]["PATH"]
    # No SoftResourceLimits / HardResourceLimits — the login agent is
    # not a long-running socket-holding process.
    assert "SoftResourceLimits" not in parsed
    assert "HardResourceLimits" not in parsed


def test_build_macos_plist_userenv_is_deterministic(tmp_path: Path) -> None:
    """Idempotent install pattern depends on byte-stable builder output."""
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"
    work_dir = tmp_path / "work"

    raw1 = install_module.build_macos_plist_userenv(halton, log_dir, work_dir)
    raw2 = install_module.build_macos_plist_userenv(halton, log_dir, work_dir)
    assert raw1 == raw2


def test_v0_1_21_run_at_load_matrix(tmp_path: Path) -> None:
    """v0.1.21 manual-start: edge + userenv stay True; daemon + watchdog
    flip to False.

    This matrix is the load-bearing assertion for the v0.1.21 cold-boot
    fix. If anything in this table regresses, cold boot will either
    silently re-introduce the daemon zombie (daemon=True) or break
    fail-open pass-through (edge=False). See ``decisions.md``
    2026-05-05 — "Manual-start architecture (v0.1.21)".
    """
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"
    work_dir = tmp_path / "work"

    daemon = plistlib.loads(install_module.build_macos_plist(halton, log_dir, work_dir))
    watchdog = plistlib.loads(install_module.build_watchdog_plist(halton, log_dir, work_dir))
    edge = plistlib.loads(install_module.build_macos_plist_edge(halton, log_dir, work_dir))
    userenv = plistlib.loads(install_module.build_macos_plist_userenv(halton, log_dir, work_dir))

    # Manual-start: opt-in.
    assert daemon["RunAtLoad"] is False, "daemon must NOT auto-load (v0.1.21)"
    assert watchdog["RunAtLoad"] is False, "watchdog must NOT auto-load (v0.1.21)"
    # Always-on: fail-open + env publication.
    assert edge["RunAtLoad"] is True, "edge MUST auto-load (fail-open pass-through)"
    assert userenv["RunAtLoad"] is True, "userenv MUST auto-load (env publication)"


def test_install_macos_writes_userenv_plist(
    fake_home: Path,
    fake_halton_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.19 Task 0.1: ``halton-meter install`` writes the userenv plist
    alongside daemon + watchdog + edge."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.install()
    assert rc == 0

    userenv_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.userenv.plist"
    )
    assert userenv_plist_path.exists()
    parsed = plistlib.loads(userenv_plist_path.read_bytes())
    assert parsed["Label"] == "com.haltonlabs.meter.userenv"
    assert parsed["KeepAlive"] is False
    assert parsed["ProgramArguments"][1] == "_apply-user-env"

    # v0.1.21.2: launchctl bootstrap should target the userenv plist.
    bootstraps = [c for c in rec.calls if len(c) >= 2 and c[1] == "bootstrap"]
    assert any(c[-1] == str(userenv_plist_path) for c in bootstraps)


def test_uninstall_macos_removes_userenv_plist(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.19 Task 0.1: regular uninstall removes the userenv plist
    file and runs ``launchctl unload`` against its label."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )

    userenv_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.userenv.plist"
    )
    userenv_plist_path.parent.mkdir(parents=True, exist_ok=True)
    userenv_plist_path.write_bytes(b"<plist><dict/></plist>")

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    assert not userenv_plist_path.exists()
    launchctl_unloads = [
        c for c in rec.calls if c[:2] == ["launchctl", "unload"]
    ]
    unload_targets = {call[-1] for call in launchctl_unloads}
    assert str(userenv_plist_path) in unload_targets


def test_uninstall_macos_removes_three_plists_in_order(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2C.2 (v0.1.6): uninstall removes daemon, watchdog, edge — in that
    order. Edge MUST be last so the user-facing port stays bound through
    the daemon's teardown; once the edge unloads the port goes dead.
    """
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )

    plist_path = fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.plist"
    watchdog_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.watchdog.plist"
    )
    edge_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.edge.plist"
    )
    for p in (plist_path, watchdog_plist_path, edge_plist_path):
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"<plist><dict/></plist>")

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    # All three plists removed from disk.
    assert not plist_path.exists()
    assert not watchdog_plist_path.exists()
    assert not edge_plist_path.exists()

    # launchctl unload order: daemon, watchdog, edge, userenv.
    # v0.1.19 Task 0.1 added the userenv login agent (last — no
    # port-keeping role).
    launchctl_unloads = [c for c in rec.calls if c[:2] == ["launchctl", "unload"]]
    assert len(launchctl_unloads) == 4
    assert launchctl_unloads[0][-1] == str(plist_path)
    assert launchctl_unloads[1][-1] == str(watchdog_plist_path)
    assert launchctl_unloads[2][-1] == str(edge_plist_path)
    userenv_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.userenv.plist"
    )
    assert launchctl_unloads[3][-1] == str(userenv_plist_path)


def test_uninstall_macos_prints_restart_warning(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """2C.2 (v0.1.6): uninstall must print an explicit warning that
    apps holding HTTPS_PROXY=http://127.0.0.1:<edge_port> in their
    process environ will lose connectivity until restarted. macOS does
    not let us mutate a running process's environ; the warning is the
    only fix."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    captured = capsys.readouterr().err
    assert "removed edge proxy" in captured
    assert "WARNING" in captured
    assert "HTTPS_PROXY" in captured
    assert "lose connectivity until restarted" in captured
    # Specific apps to consider — operators read this and act.
    assert "IDE" in captured or "terminal" in captured or "browser" in captured


def test_build_systemd_watchdog_unit_contains_required_directives(tmp_path: Path) -> None:
    halton = tmp_path / "bin" / "halton-meter"
    log_dir = tmp_path / "logs"

    text = install_module.build_systemd_watchdog_unit(halton, log_dir)

    assert "Restart=always" in text
    assert "RestartSec=1" in text
    assert f"ExecStart={halton} watchdog" in text


def test_uninstall_macos_removes_sentinel_first(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    # Preset the dynamic-enumeration cache (2B.7.2) so the test exercises
    # the 4-interface fallback deterministically, with no extra
    # ``networksetup -listallnetworkservices`` call inflating counts.
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()
    assert sentinel.exists()

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0
    assert not sentinel.exists(), "sentinel must be removed on uninstall"

    # Sanity: networksetup still ran after sentinel removal.
    # 4 fallback interfaces x 2 variants = 8 calls.
    networksetup_calls = [c for c in rec.calls if c[0] == "networksetup"]
    assert len(networksetup_calls) == 8


def test_uninstall_macos_continues_when_sentinel_unlink_raises(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the sentinel removal raises a non-FileNotFound OSError, the
    rest of uninstall (especially the system-proxy reset) must still
    run. The sentinel-removal step is best-effort."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    real_unlink = Path.unlink
    sentinel_str = str(sentinel)

    def fake_unlink(self: Path, *args: Any, **kwargs: Any) -> None:
        if str(self) == sentinel_str:
            raise OSError("simulated sentinel removal failure")
        return real_unlink(self, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", fake_unlink)

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0
    # System-proxy reset still ran.
    # 4 fallback interfaces x 2 variants = 8 calls.
    networksetup_calls = [c for c in rec.calls if c[0] == "networksetup"]
    assert len(networksetup_calls) == 8


def test_uninstall_macos_resets_proxy_even_if_unload_fails(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The load-bearing branch: networksetup MUST run even when launchctl fails."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    # Simulate a plist that doesn't exist + launchctl unload returning non-zero.
    rec = _RunRecorder(fail_on=("unload",))
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    # 2C.2 (v0.1.6): launchctl unload runs for daemon, watchdog, edge in
    # that order. All three are best-effort; each one's failure does not
    # block the others or the load-bearing networksetup reset.
    # v0.1.19 Task 0.1: userenv login agent is unloaded last.
    launchctl_unloads = [c for c in rec.calls if c[:2] == ["launchctl", "unload"]]
    assert len(launchctl_unloads) == 4

    # Subsequent calls: networksetup invoked for every fallback interface
    # and both variants (4 ifaces x 2 variants = 8).
    networksetup_calls = [c for c in rec.calls if c[0] == "networksetup"]
    assert len(networksetup_calls) == 8
    expected = {
        ("networksetup", variant, iface, "off")
        for iface in install_module.system_proxy._MACOS_INTERFACE_FALLBACK
        for variant in ("-setsecurewebproxystate", "-setwebproxystate")
    }
    assert {tuple(c) for c in networksetup_calls} == expected


def test_uninstall_macos_runs_networksetup_when_launchctl_raises(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Even a hard exception from launchctl must not skip the proxy reset."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        if argv[0] == "launchctl":
            raise OSError("simulated launchctl failure")
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(install_module.subprocess, "run", fake_run)

    rc = install_module.uninstall()
    assert rc == 0
    assert any(c[0] == "networksetup" for c in calls)


def test_uninstall_macos_resets_proxy_on_vikrants_mac_shape(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: uninstall on a Mac whose `networksetup
    -listallnetworkservices` returns Wi-Fi / Thunderbolt Bridge / iPhone
    USB (Vikrant's MacBook) must reset the proxy on those three
    interfaces and MUST NOT shell out to a non-existent ``Ethernet``."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi", "Thunderbolt Bridge", "iPhone USB"),
    )
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    networksetup_calls = [c for c in rec.calls if c[0] == "networksetup"]
    # 3 interfaces x 2 variants = 6.
    assert len(networksetup_calls) == 6
    seen_ifaces = {c[2] for c in networksetup_calls}
    assert seen_ifaces == {"Wi-Fi", "Thunderbolt Bridge", "iPhone USB"}
    # Crucially, no call ever references "Ethernet" — that service does
    # not exist on this hardware.
    assert "Ethernet" not in seen_ifaces


def test_uninstall_macos_no_networksetup_calls_when_enum_empty(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: if dynamic enumeration returns an empty
    tuple (e.g. networksetup unavailable in a sandbox), uninstall must
    skip the per-interface loop entirely rather than shelling out with
    bad arguments. Graceful degradation, not crash."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy, "_MACOS_INTERFACES_CACHE", ()
    )
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    networksetup_calls = [c for c in rec.calls if c[0] == "networksetup"]
    assert networksetup_calls == []


def test_install_linux_writes_unit_and_calls_systemctl(
    fake_home: Path,
    fake_halton_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.install()
    assert rc == 0

    unit = fake_home / ".config" / "systemd" / "user" / "halton-meter.service"
    assert unit.exists()
    assert "Restart=always" in unit.read_text()

    watchdog_unit = (
        fake_home / ".config" / "systemd" / "user" / "halton-meter-watchdog.service"
    )
    assert watchdog_unit.exists()
    assert "Restart=always" in watchdog_unit.read_text()
    assert "watchdog" in watchdog_unit.read_text()

    assert rec.calls[0] == ["systemctl", "--user", "daemon-reload"]
    assert rec.calls[1] == [
        "systemctl",
        "--user",
        "enable",
        "--now",
        "halton-meter.service",
    ]
    assert rec.calls[2] == [
        "systemctl",
        "--user",
        "enable",
        "--now",
        "halton-meter-watchdog.service",
    ]


def test_install_linux_no_user_systemd_returns_zero(
    fake_home: Path,
    fake_halton_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If user systemd isn't available, we exit cleanly with a manual hint."""
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    rec = _RunRecorder(fail_on=("daemon-reload",))
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.install()
    assert rc == 0


def test_uninstall_linux_disables_unit(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0
    # Watchdog disabled first, then daemon.
    assert rec.calls[0] == [
        "systemctl",
        "--user",
        "disable",
        "--now",
        "halton-meter-watchdog.service",
    ]
    assert rec.calls[1] == [
        "systemctl",
        "--user",
        "disable",
        "--now",
        "halton-meter.service",
    ]


# --------------------------------------------------------------------------- #
# v0.1.10 Gap 17 — Linux/systemd `--graceful` parity                          #
# --------------------------------------------------------------------------- #
#
# Documented systemd behaviour (verified against `man systemctl(1)` —
# Anchor: "disable UNIT…" section): a bare `systemctl disable` removes
# enable symlinks and does NOT stop the running unit. `disable --now`
# is the variant that stops it. Graceful uninstall on Linux relies on
# this contract: skip `--now` so the running daemon + watchdog stay
# alive until the next reboot, when the now-disabled units do not
# come back. Mocked-subprocess tests below assert the contract from
# our side. A linux-only integration test wrapper sits at the bottom
# of this section for execution against a real systemd box.


def test_uninstall_linux_graceful_does_not_pass_now(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.10 Gap 17: bare `disable` (NO `--now`) is what keeps the
    running daemon + watchdog alive. Regression guard against someone
    'simplifying' the path by re-adding `--now`."""
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall(graceful=True)
    assert rc == 0

    # First two calls are the disables (watchdog then daemon).
    assert rec.calls[0] == [
        "systemctl", "--user", "disable", "halton-meter-watchdog.service",
    ]
    assert rec.calls[1] == [
        "systemctl", "--user", "disable", "halton-meter.service",
    ]
    # Critical: NO `--now` anywhere on the disable calls.
    for call in rec.calls:
        if call[:3] == ["systemctl", "--user", "disable"]:
            assert "--now" not in call, (
                f"graceful uninstall must not pass --now to disable; got {call}"
            )
    # Critical: `stop` must never be called either.
    for call in rec.calls:
        assert "stop" not in call, (
            f"graceful uninstall must not invoke systemctl stop; got {call}"
        )


def test_uninstall_linux_graceful_runs_daemon_reload_and_reset_failed(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Cleanup tail: daemon-reload drops cached unit defs, reset-failed
    clears any RestartCounter state so a future `init` starts clean."""
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    install_module.uninstall(graceful=True)

    assert ["systemctl", "--user", "daemon-reload"] in rec.calls
    assert [
        "systemctl", "--user", "reset-failed", "halton-meter-watchdog.service",
    ] in rec.calls
    assert [
        "systemctl", "--user", "reset-failed", "halton-meter.service",
    ] in rec.calls


def test_uninstall_linux_graceful_removes_unit_files(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Unit files must still be removed in graceful mode — at next
    reboot the unit map is empty so nothing comes back."""
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    monkeypatch.setattr(
        install_module.subprocess, "run", _RunRecorder()
    )
    daemon_unit = (
        fake_home / ".config" / "systemd" / "user" / "halton-meter.service"
    )
    watchdog_unit = (
        fake_home / ".config" / "systemd" / "user"
        / "halton-meter-watchdog.service"
    )
    daemon_unit.parent.mkdir(parents=True, exist_ok=True)
    daemon_unit.write_text("# fake")
    watchdog_unit.write_text("# fake")

    install_module.uninstall(graceful=True)

    assert not daemon_unit.exists()
    assert not watchdog_unit.exists()


def test_uninstall_linux_default_still_passes_now(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression: the existing non-graceful Linux path (the v0.1.9
    behaviour) must keep using `disable --now` to SIGTERM the daemon."""
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    install_module.uninstall()  # graceful=False by default

    # Disable calls must include --now in the default path.
    disable_calls = [
        c for c in rec.calls if c[:3] == ["systemctl", "--user", "disable"]
    ]
    assert disable_calls, "expected at least one disable call"
    for call in disable_calls:
        assert "--now" in call, (
            f"non-graceful uninstall must pass --now; got {call}"
        )
    # No daemon-reload / reset-failed in default mode (kept tight).
    assert ["systemctl", "--user", "daemon-reload"] not in rec.calls


def test_uninstall_linux_graceful_print_message(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Operator-facing summary explains the new contract — running
    processes survive until reboot."""
    monkeypatch.setattr(install_module.sys, "platform", "linux")
    monkeypatch.setattr(install_module.subprocess, "run", _RunRecorder())

    install_module.uninstall(graceful=True)
    captured = capsys.readouterr().err
    assert "graceful uninstall" in captured
    assert "next reboot" in captured


@pytest.mark.skipif(
    not _sys.platform.startswith("linux"),
    reason="Linux-only integration test — requires systemd user manager.",
)
def test_uninstall_linux_graceful_real_systemd_leaves_process_alive(
    tmp_path: Path,
) -> None:
    """Linux-only integration test stub for engineers running on a real
    systemd box. Skipped on macOS dev. The mocked tests above assert
    our argv contract; this test would assert the contracted systemd
    behaviour: bare `disable` does NOT SIGTERM the running unit.

    Implementation requires a sacrificial user unit that runs `sleep
    infinity` so we can confirm its PID survives the disable. Out of
    scope for this PR (no real-systemd CI yet); leaving the skip
    marker in place so a future Linux operator can fill it in.
    """
    pytest.skip(
        "systemd integration probe deferred — argv contract proven by "
        "mocked tests above; documented systemd behaviour confirms bare "
        "`disable` is non-stopping."
    )


def test_install_windows_returns_zero_with_friendly_message(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(install_module.sys, "platform", "win32")
    rc = install_module.install()
    assert rc == 0
    captured = capsys.readouterr()
    assert "not yet supported on Windows" in captured.err


def test_uninstall_windows_returns_zero(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(install_module.sys, "platform", "win32")
    assert install_module.uninstall() == 0


# --------------------------------------------------------------------------- #
# Path resolution fallback                                                     #
# --------------------------------------------------------------------------- #


def test_resolve_falls_back_to_argv0_when_which_returns_none(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(install_module.shutil, "which", lambda _name: None)
    fake = tmp_path / "halton-meter"
    fake.write_text("x")
    monkeypatch.setattr(install_module.sys, "argv", [str(fake)])

    resolved = install_module._resolve_halton_path()
    assert resolved == fake.resolve()


def test_install_macos_errors_when_binary_unresolvable(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(install_module.shutil, "which", lambda _name: None)
    monkeypatch.setattr(install_module.sys, "argv", ["/nonexistent/path/that/does/not/exist"])
    # belt and braces: don't touch real subprocess.run from this test
    monkeypatch.setattr(install_module.subprocess, "run", _RunRecorder())

    rc = install_module.install()
    assert rc == 1
    captured = capsys.readouterr()
    assert "could not locate halton-meter binary" in captured.err


# --------------------------------------------------------------------------- #
# Optional integration test (skipped if launchctl is absent)                   #
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
# TCC-protected-path guard (bug fix 2026-04-29)                                #
# --------------------------------------------------------------------------- #


def test_is_tcc_protected_documents(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: Path("/Users/foo")))  # type: ignore[arg-type]
    assert (
        install_module._is_tcc_protected(Path("/Users/foo/Documents/x/halton-meter"))
        == "Documents"
    )


def test_is_tcc_protected_desktop_and_downloads(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: Path("/Users/foo")))  # type: ignore[arg-type]
    assert (
        install_module._is_tcc_protected(Path("/Users/foo/Desktop/halton-meter"))
        == "Desktop"
    )
    assert (
        install_module._is_tcc_protected(
            Path("/Users/foo/Downloads/repo/.venv/bin/halton-meter")
        )
        == "Downloads"
    )


def test_is_tcc_protected_outside(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: Path("/Users/foo")))  # type: ignore[arg-type]
    assert install_module._is_tcc_protected(Path("/Users/foo/.local/bin/halton-meter")) is None
    assert install_module._is_tcc_protected(Path("/usr/local/bin/halton-meter")) is None


def test_install_macos_aborts_on_tcc_protected_path(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A halton-meter binary under ~/Documents must abort install non-zero
    without writing the plists or invoking launchctl. Otherwise the user
    gets a successful-looking install whose plist silently fails to spawn
    under launchd's TCC sandbox."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")

    fake_binary = fake_home / "Documents" / "repo" / ".venv" / "bin" / "halton-meter"
    fake_binary.parent.mkdir(parents=True, exist_ok=True)
    fake_binary.write_text("#!/Users/stack/.venv/bin/python\n")
    fake_binary.chmod(0o755)
    monkeypatch.setattr(install_module.shutil, "which", lambda _name: str(fake_binary))

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.install()
    assert rc == 1

    captured = capsys.readouterr()
    assert "Documents" in captured.err
    assert "TCC" in captured.err
    # Mentions both recommended install routes.
    assert "uv tool install" in captured.err
    assert "pipx install" in captured.err
    # Shebang interpreter parsed -> Full Disk Access alternative shown.
    assert "Full Disk Access" in captured.err

    # Plists must not have been written.
    plist_path = fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.plist"
    watchdog_plist = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.watchdog.plist"
    )
    assert not plist_path.exists()
    assert not watchdog_plist.exists()

    # launchctl must NEVER have been invoked when we abort early.
    assert not any(c[0] == "launchctl" for c in rec.calls)


def test_install_macos_writes_plist_on_unprotected_path(
    fake_home: Path,
    fake_halton_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Sanity-check the happy path: the TCC guard does not false-positive on
    a binary under ~/.local/bin (or any other non-protected location)."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    # fake_halton_path is under tmp_path/bin which is outside any of the
    # TCC-protected dirs relative to fake_home (= tmp_path).
    assert install_module._is_tcc_protected(fake_halton_path) is None

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.install()
    assert rc == 0

    plist_path = fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.plist"
    assert plist_path.exists()


@pytest.mark.skipif(
    shutil.which("launchctl") is None,
    reason="launchctl unavailable — integration test only meaningful on macOS",
)
def test_real_launchctl_smoke_disabled() -> None:
    """Placeholder.

    A real install/list/uninstall cycle would pollute the user's launchd
    config with the production label. Keeping this as a hard skip until
    launchd accepts a relocatable label or we wire a tmp-path plist
    directory; the mocked tests above cover the contract.
    """
    pytest.skip("real launchctl integration disabled to avoid polluting user config")


# --------------------------------------------------------------------------- #
# Q1 layer-4 (2B.10): launchd ExitTimeOut + systemd ExecStop                   #
# --------------------------------------------------------------------------- #


def test_macos_plist_has_exit_timeout_30(tmp_path: Path) -> None:
    """Acceptance criterion #2: daemon plist gives the SIGTERM handler 30s."""
    raw = install_module.build_macos_plist(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    parsed = plistlib.loads(raw)
    assert parsed["ExitTimeOut"] == 30


def test_watchdog_plist_has_exit_timeout_30(tmp_path: Path) -> None:
    """Acceptance criterion #2: watchdog plist gets the same grace window."""
    raw = install_module.build_watchdog_plist(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    parsed = plistlib.loads(raw)
    assert parsed["ExitTimeOut"] == 30


def test_systemd_unit_has_exec_stop_reset_proxy(tmp_path: Path) -> None:
    """Acceptance criterion #3: daemon systemd unit invokes reset-proxy on stop."""
    halton = tmp_path / "bin" / "halton-meter"
    text = install_module.build_systemd_unit(halton, tmp_path / "logs")
    assert f"ExecStop={halton} reset-proxy" in text


def test_systemd_watchdog_unit_has_exec_stop_reset_proxy(tmp_path: Path) -> None:
    """Acceptance criterion #3: watchdog systemd unit invokes reset-proxy on stop."""
    halton = tmp_path / "bin" / "halton-meter"
    text = install_module.build_systemd_watchdog_unit(halton, tmp_path / "logs")
    assert f"ExecStop={halton} reset-proxy" in text


# --------------------------------------------------------------------------- #
# 2B.11: snapshot/restore + three-tier purge                                   #
# --------------------------------------------------------------------------- #


def test_uninstall_macos_restores_from_snapshot(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When ``system_state.json`` exists, uninstall delegates to
    ``system_proxy.restore_system_proxy`` rather than running the
    unconditional disable loop."""
    import json as _json

    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi",),
    )
    state_path = fake_home / ".halton-meter" / "system_state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        _json.dumps(
            {
                "version": 1,
                "platform": "darwin",
                "services": {
                    "Wi-Fi": {
                        "web_proxy_enabled": True,
                        "secure_web_proxy_enabled": True,
                        "host": "proxy.example.com",
                        "port": "8888",
                        "bypass_domains": [],
                    }
                },
            }
        )
    )
    monkeypatch.setattr(install_module.system_proxy, "_SYSTEM_STATE_PATH", state_path)
    monkeypatch.setattr(
        install_module.system_proxy.shutil,
        "which",
        lambda _name: "/usr/sbin/networksetup",
    )

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)
    monkeypatch.setattr(install_module.system_proxy.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    # Restored: at least one set-address with the captured host:port.
    set_calls = [
        c for c in rec.calls
        if c[:2] == ["networksetup", "-setsecurewebproxy"]
    ]
    assert any(c[3] == "proxy.example.com" and c[4] == "8888" for c in set_calls)
    # Snapshot file removed.
    assert not state_path.exists()


def test_uninstall_macos_self_guard_when_snapshot_targets_us(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the snapshot's host:port matches our daemon listener, we DISABLE
    the service rather than restoring."""
    import json as _json

    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi",),
    )
    state_path = fake_home / ".halton-meter" / "system_state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        _json.dumps(
            {
                "version": 1,
                "platform": "darwin",
                "services": {
                    "Wi-Fi": {
                        "web_proxy_enabled": True,
                        "secure_web_proxy_enabled": True,
                        "host": "127.0.0.1",
                        "port": "8080",
                        "bypass_domains": [],
                    }
                },
            }
        )
    )
    monkeypatch.setattr(install_module.system_proxy, "_SYSTEM_STATE_PATH", state_path)
    monkeypatch.setattr(
        install_module.system_proxy.shutil,
        "which",
        lambda _name: "/usr/sbin/networksetup",
    )
    # Force the listener resolver to return the matching host:port without
    # depending on a config.toml on this dev box.
    monkeypatch.setattr(
        install_module, "_resolve_daemon_listener", lambda: ("127.0.0.1", 8080)
    )

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)
    monkeypatch.setattr(install_module.system_proxy.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    # Self-guard: NO -setsecurewebproxy / -setwebproxy address-set call.
    addr_sets = [
        c for c in rec.calls
        if c[:2] in (
            ["networksetup", "-setsecurewebproxy"],
            ["networksetup", "-setwebproxy"],
        )
    ]
    assert addr_sets == []
    # Disable pair did fire.
    state_offs = [
        c for c in rec.calls
        if len(c) >= 4 and c[0] == "networksetup"
        and c[1] in ("-setsecurewebproxystate", "-setwebproxystate")
        and c[3] == "off"
    ]
    assert len(state_offs) >= 2


def test_uninstall_macos_falls_back_to_disable_when_no_snapshot(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """No ``system_state.json`` → run the original unconditional disable
    loop. Backwards-compat for older installs that never ran ``init``."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    monkeypatch.setattr(
        install_module.system_proxy,
        "_SYSTEM_STATE_PATH",
        fake_home / ".halton-meter" / "system_state.json",
    )

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)
    monkeypatch.setattr(install_module.system_proxy.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    # 4 ifaces x 2 variants = 8 disable calls.
    networksetup_calls = [c for c in rec.calls if c[0] == "networksetup"]
    assert len(networksetup_calls) == 8
    assert all(c[-1] == "off" for c in networksetup_calls)


def test_purge_preserves_db_sqlite_with_wal_siblings(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default ``--purge`` (without ``--include-logs``) wipes
    ~/.halton-meter/ but preserves db.sqlite + WAL siblings as a unit."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi",),
    )
    monkeypatch.setattr(
        install_module.system_proxy,
        "_SYSTEM_STATE_PATH",
        fake_home / ".halton-meter" / "system_state.json",
    )
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)
    monkeypatch.setattr(install_module.system_proxy.subprocess, "run", rec)

    data = fake_home / ".halton-meter"
    data.mkdir(parents=True, exist_ok=True)
    (data / "config.toml").write_text("# config")
    (data / "daemon.log").write_text("log line")
    (data / "db.sqlite").write_bytes(b"SQLITE_DATA")
    (data / "db.sqlite-wal").write_bytes(b"WAL")
    (data / "db.sqlite-shm").write_bytes(b"SHM")
    (data / "logs.db").write_bytes(b"LEGACY_DB")
    (data / "subdir").mkdir()
    (data / "subdir" / "x").write_text("x")

    rc = install_module.uninstall(purge=True, include_logs=False)
    assert rc == 0

    # Database files preserved (canonical + legacy).
    assert (data / "db.sqlite").read_bytes() == b"SQLITE_DATA"
    assert (data / "db.sqlite-wal").read_bytes() == b"WAL"
    assert (data / "db.sqlite-shm").read_bytes() == b"SHM"
    assert (data / "logs.db").read_bytes() == b"LEGACY_DB"
    # Everything else removed.
    assert not (data / "config.toml").exists()
    assert not (data / "daemon.log").exists()
    assert not (data / "subdir").exists()


def test_purge_with_include_logs_removes_db_sqlite(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``--purge --include-logs`` removes the entire ~/.halton-meter/
    including db.sqlite + WAL siblings + legacy logs.db."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi",),
    )
    monkeypatch.setattr(
        install_module.system_proxy,
        "_SYSTEM_STATE_PATH",
        fake_home / ".halton-meter" / "system_state.json",
    )
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)
    monkeypatch.setattr(install_module.system_proxy.subprocess, "run", rec)

    data = fake_home / ".halton-meter"
    data.mkdir(parents=True, exist_ok=True)
    (data / "db.sqlite").write_bytes(b"X")
    (data / "db.sqlite-wal").write_bytes(b"Y")
    (data / "logs.db").write_bytes(b"Z")
    (data / "config.toml").write_text("c")

    rc = install_module.uninstall(purge=True, include_logs=True)
    assert rc == 0

    assert not data.exists()


def test_purge_no_op_when_data_dir_missing(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``--purge`` is safe to run when ~/.halton-meter/ never existed."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi",),
    )
    monkeypatch.setattr(
        install_module.system_proxy,
        "_SYSTEM_STATE_PATH",
        fake_home / ".halton-meter" / "system_state.json",
    )
    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)
    monkeypatch.setattr(install_module.system_proxy.subprocess, "run", rec)

    rc = install_module.uninstall(purge=True, include_logs=False)
    assert rc == 0


def test_count_request_records_returns_zeros_when_db_missing(
    tmp_path: Path,
) -> None:
    assert install_module.count_request_records(tmp_path / "missing.sqlite") == (0, 0)


def test_count_request_records_reads_from_real_sqlite(
    tmp_path: Path,
) -> None:
    """Build a tiny SQLite db with the ``requests`` table shape and verify
    the count helper returns ``(records, distinct_projects)``."""
    import sqlite3

    db = tmp_path / "db.sqlite"
    conn = sqlite3.connect(str(db))
    try:
        conn.execute(
            "CREATE TABLE requests (id TEXT PRIMARY KEY, project_id TEXT NOT NULL)"
        )
        conn.executemany(
            "INSERT INTO requests (id, project_id) VALUES (?, ?)",
            [
                ("r1", "p1"),
                ("r2", "p1"),
                ("r3", "p2"),
                ("r4", "p3"),
                ("r5", "p3"),
            ],
        )
        conn.commit()
    finally:
        conn.close()

    records, projects = install_module.count_request_records(db)
    assert records == 5
    assert projects == 3


# --------------------------------------------------------------------------- #
# v0.1.21.1: no KeepAlive on daemon + watchdog (manual-start)                  #
# --------------------------------------------------------------------------- #


def test_daemon_plist_has_no_keepalive_key(tmp_path: Path) -> None:
    """v0.1.21.1: daemon plist MUST NOT carry a ``KeepAlive`` key.

    From ``man launchd.plist`` under ``KeepAlive`` -> ``SuccessfulExit``:
    "This key implies that 'RunAtLoad' is set to true, since the job
    needs to run at least once before we can get an exit status."
    Any KeepAlive value (bool True, ``{"SuccessfulExit": False}``,
    ``{"Crashed": True}``, etc.) therefore silently overrides our
    explicit ``RunAtLoad=False`` and re-introduces the v0.1.21 cold-
    boot auto-load regression. The only safe shape is to omit the key
    entirely. See ``decisions.md`` 2026-05-05 -- "v0.1.21.1 KeepAlive
    removal".
    """
    raw = install_module.build_macos_plist(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    parsed = plistlib.loads(raw)
    assert "KeepAlive" not in parsed, (
        "daemon plist must NOT define KeepAlive (any value implies "
        "RunAtLoad=True per man launchd.plist); got "
        f"KeepAlive={parsed.get('KeepAlive')!r}"
    )
    assert parsed["RunAtLoad"] is False


def test_watchdog_plist_has_no_keepalive_key(tmp_path: Path) -> None:
    """v0.1.21.1: watchdog plist MUST NOT carry a ``KeepAlive`` key.

    Same ``man launchd.plist`` rule as the daemon plist — any KeepAlive
    value implies ``RunAtLoad=True`` and would override our explicit
    False, putting the watchdog back on the cold-boot auto-load path
    that v0.1.21 was meant to remove. Manual-start parity with the
    daemon: watchdog now starts only on ``halton-meter start``.
    Trade-off (deliberate, see install.py docstring): we lose the
    always-respawn revival on the empty-snapshot exit path that
    layer-2 (2B.10.9) used to rely on.
    """
    raw = install_module.build_watchdog_plist(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    parsed = plistlib.loads(raw)
    assert "KeepAlive" not in parsed, (
        "watchdog plist must NOT define KeepAlive (any value implies "
        "RunAtLoad=True per man launchd.plist); got "
        f"KeepAlive={parsed.get('KeepAlive')!r}"
    )
    assert parsed["RunAtLoad"] is False


def test_edge_plist_still_has_keepalive_true(tmp_path: Path) -> None:
    """v0.1.21.1 regression guard: the edge plist MUST keep
    ``KeepAlive=True`` and ``RunAtLoad=True``. The edge owns the
    user-facing port and is load-bearing for fail-open pass-through —
    it must auto-start at login and revive on any exit so apps with a
    cached HTTPS_PROXY env var keep finding a listener. The
    KeepAlive-implies-RunAtLoad coupling is HELPFUL here, not harmful.
    """
    raw = install_module.build_macos_plist_edge(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    parsed = plistlib.loads(raw)
    assert parsed["KeepAlive"] is True
    assert parsed["RunAtLoad"] is True


# --------------------------------------------------------------------------- #
# v0.1.3 P0-3 — uninstall reverses --gui side effects                          #
# --------------------------------------------------------------------------- #


def test_uninstall_macos_gui_mode_unsetenvs_launchctl_and_removes_rc_block(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """In a --gui-mode install (install-mode sentinel = 'gui'), uninstall
    must call launchctl unsetenv for the managed env keys AND remove the
    marker block from the user's shell rc."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    monkeypatch.setattr(install_module.shutil, "which", lambda _name: "/bin/launchctl")

    # Set install-mode sentinel = gui.
    from halton_meter import init as init_module

    install_mode_path = fake_home / ".halton-meter" / "install-mode"
    install_mode_path.parent.mkdir(parents=True, exist_ok=True)
    install_mode_path.write_text("gui\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", install_mode_path)

    # Pre-seed the user's .zshrc with our marker block.
    rc_path = fake_home / ".zshrc"
    rc_path.write_text(
        "# my zshrc\n\n"
        f"{init_module.SHELL_RC_BLOCK_BEGIN}\n"
        "export HTTPS_PROXY=http://127.0.0.1:8080\n"
        "export HTTP_PROXY=http://127.0.0.1:8080\n"
        f"{init_module.SHELL_RC_BLOCK_END}\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(init_module, "detect_shell_rc", lambda: rc_path)

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    # launchctl unsetenv called for each GUI env key.
    unsetenv_keys = {
        c[2] for c in rec.calls if c[:2] == ["launchctl", "unsetenv"]
    }
    from halton_meter.system_proxy import GUI_LAUNCHCTL_ENV_KEYS

    assert set(GUI_LAUNCHCTL_ENV_KEYS) <= unsetenv_keys

    # Shell-rc block removed.
    rc_body = rc_path.read_text(encoding="utf-8")
    assert init_module.SHELL_RC_BLOCK_BEGIN not in rc_body
    # Surrounding content survives.
    assert "# my zshrc" in rc_body

    # install-mode sentinel removed.
    assert not install_mode_path.exists()


def test_uninstall_macos_env_only_mode_does_not_unsetenv(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Wait — actually we DO want to defensively unsetenv even in env-only
    mode: the user could have switched modes mid-install, or the install-
    mode sentinel could be missing on an older install. Per install.py
    `treat_as_gui = (install_mode is None) or (install_mode == MODE_GUI)`,
    only an EXPLICIT env-only sentinel skips the unsetenv pass."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    monkeypatch.setattr(install_module.shutil, "which", lambda _name: "/bin/launchctl")

    from halton_meter import init as init_module

    install_mode_path = fake_home / ".halton-meter" / "install-mode"
    install_mode_path.parent.mkdir(parents=True, exist_ok=True)
    install_mode_path.write_text("env-only\n", encoding="utf-8")
    monkeypatch.setattr(init_module, "INSTALL_MODE_PATH", install_mode_path)

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall()
    assert rc == 0

    # No launchctl unsetenv calls in env-only mode.
    assert not any(c[:2] == ["launchctl", "unsetenv"] for c in rec.calls)
    # install-mode sentinel removed.
    assert not install_mode_path.exists()


# --------------------------------------------------------------------------- #
# v0.1.9 Gap 11 — graceful uninstall                                          #
# --------------------------------------------------------------------------- #


def test_uninstall_macos_graceful_skips_edge_unload(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Graceful mode MUST NOT issue ``launchctl unload`` against the
    edge label. Daemon + watchdog still get unloaded normally — graceful
    is about app connectivity, not preserving metering."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    # Stub the lifecycle PID lookup so the graceful warning has a number.
    from halton_meter import lifecycle as _lifecycle_module

    monkeypatch.setattr(
        _lifecycle_module, "_launchctl_label_pid", lambda label: 42424
    )

    plist_path = fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.plist"
    watchdog_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.watchdog.plist"
    )
    edge_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.edge.plist"
    )
    for p in (plist_path, watchdog_plist_path, edge_plist_path):
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"<plist><dict/></plist>")

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall(graceful=True)
    assert rc == 0

    # Daemon + watchdog plists removed; edge plist also removed (so
    # next reboot doesn't relaunch).
    assert not plist_path.exists()
    assert not watchdog_plist_path.exists()
    assert not edge_plist_path.exists()

    # launchctl unload was called for daemon + watchdog + userenv (NOT edge).
    # v0.1.19 Task 0.1: userenv has no port-keeping role so graceful uninstall
    # still tears it down — only the edge is spared.
    launchctl_unloads = [c for c in rec.calls if c[:2] == ["launchctl", "unload"]]
    assert len(launchctl_unloads) == 3, launchctl_unloads
    unload_targets = {call[-1] for call in launchctl_unloads}
    assert str(plist_path) in unload_targets
    assert str(watchdog_plist_path) in unload_targets
    assert str(edge_plist_path) not in unload_targets


def test_uninstall_macos_graceful_prints_passthrough_message(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Graceful mode prints a clear note that the edge stays in
    pure-passthrough until reboot, including the captured PID."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )
    from halton_meter import lifecycle as _lifecycle_module

    monkeypatch.setattr(
        _lifecycle_module, "_launchctl_label_pid", lambda label: 99123
    )

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    rc = install_module.uninstall(graceful=True)
    assert rc == 0

    err = capsys.readouterr().err
    # PID surfaced.
    assert "99123" in err
    assert "pure-passthrough" in err
    # The destructive WARNING block from non-graceful mode must NOT
    # appear — graceful mode replaces it.
    assert "lose connectivity until restarted" not in err


def test_uninstall_macos_default_still_unloads_edge(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression: the default (non-graceful) path must keep its
    existing behaviour of unloading the edge label."""
    monkeypatch.setattr(install_module.sys, "platform", "darwin")
    monkeypatch.setattr(
        install_module.system_proxy,
        "_MACOS_INTERFACES_CACHE",
        install_module.system_proxy._MACOS_INTERFACE_FALLBACK,
    )

    edge_plist_path = (
        fake_home / "Library" / "LaunchAgents" / "com.haltonlabs.meter.edge.plist"
    )
    edge_plist_path.parent.mkdir(parents=True, exist_ok=True)
    edge_plist_path.write_bytes(b"<plist><dict/></plist>")

    rec = _RunRecorder()
    monkeypatch.setattr(install_module.subprocess, "run", rec)

    install_module.uninstall()
    unload_targets = {
        c[-1] for c in rec.calls if c[:2] == ["launchctl", "unload"]
    }
    assert str(edge_plist_path) in unload_targets


def test_uninstall_cli_threads_graceful_flag(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """End-to-end: ``halton-meter uninstall --graceful`` reaches the
    install_module.uninstall(graceful=True) call site."""
    seen: dict[str, object] = {}

    def fake_uninstall(
        *, purge: bool = False, include_logs: bool = False, graceful: bool = False
    ) -> int:
        seen["graceful"] = graceful
        seen["purge"] = purge
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    from click.testing import CliRunner

    from halton_meter.cli import cli

    runner = CliRunner()
    result = runner.invoke(cli, ["uninstall", "--graceful"])
    assert result.exit_code == 0, result.output
    assert seen.get("graceful") is True
    assert seen.get("purge") is False


# --------------------------------------------------------------------------- #
# P0.1 (v0.1.16, Bug 4): launchd plists must request 10240 FD limits          #
# --------------------------------------------------------------------------- #


def _assert_fd_limits_10240(parsed: dict[str, Any]) -> None:
    """Assert both Soft and Hard ResourceLimits set NumberOfFiles to 10240."""
    soft = parsed.get("SoftResourceLimits")
    hard = parsed.get("HardResourceLimits")
    assert isinstance(soft, dict), f"SoftResourceLimits missing or not a dict: {soft!r}"
    assert isinstance(hard, dict), f"HardResourceLimits missing or not a dict: {hard!r}"
    assert soft.get("NumberOfFiles") == 10240, (
        f"SoftResourceLimits.NumberOfFiles must be 10240, got {soft.get('NumberOfFiles')!r}"
    )
    assert hard.get("NumberOfFiles") == 10240, (
        f"HardResourceLimits.NumberOfFiles must be 10240, got {hard.get('NumberOfFiles')!r}"
    )


def test_macos_plist_has_fd_limits_10240(tmp_path: Path) -> None:
    """P0.1: daemon plist must bump NumberOfFiles soft+hard to 10240."""
    raw = install_module.build_macos_plist(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    # Regression: round-trip must succeed (XML well-formed, plistlib-readable).
    parsed = plistlib.loads(raw)
    _assert_fd_limits_10240(parsed)
    # Also check the rendered XML contains both keys (defence-in-depth in case
    # plistlib ever round-trips differently).
    xml = raw.decode("utf-8")
    assert "SoftResourceLimits" in xml
    assert "HardResourceLimits" in xml
    assert "NumberOfFiles" in xml


def test_edge_plist_has_fd_limits_10240(tmp_path: Path) -> None:
    """P0.1: edge plist (the FD-pressure source) must bump NumberOfFiles to 10240."""
    raw = install_module.build_macos_plist_edge(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    parsed = plistlib.loads(raw)
    _assert_fd_limits_10240(parsed)
    xml = raw.decode("utf-8")
    assert "SoftResourceLimits" in xml
    assert "HardResourceLimits" in xml
    assert "NumberOfFiles" in xml


def test_watchdog_plist_has_fd_limits_10240(tmp_path: Path) -> None:
    """P0.1: watchdog plist bumped for consistency with the daemon + edge."""
    raw = install_module.build_watchdog_plist(
        tmp_path / "bin" / "halton-meter",
        tmp_path / "logs",
        tmp_path / "work",
    )
    parsed = plistlib.loads(raw)
    _assert_fd_limits_10240(parsed)
    xml = raw.decode("utf-8")
    assert "SoftResourceLimits" in xml
    assert "HardResourceLimits" in xml
    assert "NumberOfFiles" in xml


# --------------------------------------------------------------------------- #
# v0.1.21.5: install.err.log persistence                                       #
# --------------------------------------------------------------------------- #


def test_record_install_error_appends_structured_entry(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``_record_install_error`` appends a timestamped entry to install.err.log."""
    err_log = tmp_path / ".halton-meter" / "install.err.log"
    monkeypatch.setattr(install_module, "_INSTALL_ERR_LOG", err_log)

    install_module._record_install_error(
        label="com.haltonlabs.meter",
        kind="bootstrap",
        rc=5,
        err="Input/output error",
        plist=tmp_path / "fake.plist",
    )

    text = err_log.read_text(encoding="utf-8")
    assert "launchctl bootstrap failed for com.haltonlabs.meter (rc=5)" in text
    assert "stderr: Input/output error" in text
    assert "plist:" in text
    # ISO-8601 timestamp leads each header line.
    first_line = text.splitlines()[0]
    assert first_line.split(" ", 1)[0].endswith("+00:00") or "T" in first_line


def test_record_install_error_appends_multiple_entries(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    err_log = tmp_path / ".halton-meter" / "install.err.log"
    monkeypatch.setattr(install_module, "_INSTALL_ERR_LOG", err_log)

    install_module._record_install_error("a", "bootstrap", 5, "first", plist=None)
    install_module._record_install_error("b", "kickstart", 3, "second", plist=None)

    text = err_log.read_text(encoding="utf-8")
    assert "first" in text
    assert "second" in text
    assert text.count("launchctl") == 2


def test_record_install_error_swallows_oserror(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Diagnostics must never raise — write failures are swallowed."""
    # Point at an unwritable path (a regular file used as a "directory").
    blocker = tmp_path / "notadir"
    blocker.write_text("blocking")
    err_log = blocker / "install.err.log"
    monkeypatch.setattr(install_module, "_INSTALL_ERR_LOG", err_log)

    # Must not raise.
    install_module._record_install_error("x", "bootstrap", 5, "boom", plist=None)
