"""
Pure-function tests for ``halton_meter.attribution.layers``.

PR2 (2026-05-02) — covers the new layers landed by the Smart
Attribution v0.3 PR2: layer 4 (git), layer 6 (container), layer 6.5
(macOS sandbox), and the extended slug normaliser. Pre-existing
layers 1, 2, 7 are exercised by ``test_tagging.py`` and
``test_edge_attribution.py``; this module focuses on the per-layer
contract independent of the resolver wiring.

The wiring tests (precedence pinning, edge-vs-daemon parity) live
in ``test_tagging.py`` and ``test_edge_attribution.py`` so the
new behaviour is exercised end-to-end against both resolvers.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from halton_meter.attribution import layers

# --------------------------------------------------------------------------- #
# Slug normaliser (v0.3 rules)                                                #
# --------------------------------------------------------------------------- #


class TestNormaliseProjectSlug:
    def test_lower_cases(self) -> None:
        assert layers.normalise_project_slug("Foo") == "foo"

    def test_replaces_disallowed_chars_with_dash(self) -> None:
        assert layers.normalise_project_slug("foo bar") == "foo-bar"
        assert layers.normalise_project_slug("foo!bar") == "foo-bar"
        # ``.`` IS allowed (reverse-DNS bundle ids need it); ``@`` is not.
        assert layers.normalise_project_slug("foo@bar.baz") == "foo-bar.baz"

    def test_dot_is_preserved_for_reverse_dns(self) -> None:
        """Brief D's mac sandbox layer emits ``mac:ai.perplexity.mac``;
        the dots must survive normalisation."""
        assert layers.normalise_project_slug("mac:ai.perplexity.mac") == "mac:ai.perplexity.mac"
        assert layers.normalise_project_slug("mac:com.openai.chat") == "mac:com.openai.chat"

    def test_collapses_repeated_dashes(self) -> None:
        assert layers.normalise_project_slug("foo   bar") == "foo-bar"
        assert layers.normalise_project_slug("foo--bar") == "foo-bar"
        assert layers.normalise_project_slug("foo!!!bar") == "foo-bar"

    def test_strips_leading_and_trailing_dashes(self) -> None:
        assert layers.normalise_project_slug("-foo-") == "foo"
        assert layers.normalise_project_slug("---foo---") == "foo"
        # Disallowed chars at the edges become dashes then strip.
        assert layers.normalise_project_slug("@@foo@@") == "foo"

    def test_preserves_colon_slash_underscore_dash(self) -> None:
        assert layers.normalise_project_slug("k8s:checkout-pod-abc") == "k8s:checkout-pod-abc"
        assert layers.normalise_project_slug("docker:a1b2c3d4") == "docker:a1b2c3d4"
        assert layers.normalise_project_slug("a/b") == "a/b"
        assert layers.normalise_project_slug("a_b") == "a_b"

    def test_truncates_to_64_chars(self) -> None:
        long_name = "a" * 200
        result = layers.normalise_project_slug(long_name)
        assert len(result) == 64
        assert result == "a" * 64

    def test_truncate_strips_trailing_dash_if_cut_mid_run(self) -> None:
        # 63 'a's, then a '-' at position 64; truncation to 64 chops
        # at the dash and the trailing-strip removes it.
        name = "a" * 63 + "-" + "b" * 10
        result = layers.normalise_project_slug(name)
        assert result == "a" * 63
        assert not result.endswith("-")

    def test_empty_falls_through_to_unattributed(self) -> None:
        assert layers.normalise_project_slug("") == "unattributed"
        assert layers.normalise_project_slug("   ") == "unattributed"
        assert layers.normalise_project_slug("@@@") == "unattributed"
        assert layers.normalise_project_slug("...") == "unattributed"
        assert layers.normalise_project_slug("---") == "unattributed"

    def test_leading_dot_strip_preserved_from_v018_gap6(self) -> None:
        assert layers.normalise_project_slug(".halton-meter") == "halton-meter"
        assert layers.normalise_project_slug("...halton") == "halton"
        assert layers.normalise_project_slug(".") == "unattributed"
        assert layers.normalise_project_slug(".....") == "unattributed"

    def test_existing_known_slugs_unchanged(self) -> None:
        # PR2 audit: every project name we already use stays valid
        # under the new rules. Pin them so a future normaliser change
        # can't silently rename live projects.
        for s in (
            "halton-meter",
            "halton-meter-cloud",
            "halton-meter-landing",
            "haltonlabs-meter",
            "unattributed",
            "claude-code",
        ):
            assert layers.normalise_project_slug(s) == s


# --------------------------------------------------------------------------- #
# Layer 4 — git repo basename                                                 #
# --------------------------------------------------------------------------- #


@pytest.fixture(autouse=True)
def _clear_git_cache() -> None:
    """The git cache lives module-level; clear between tests to keep them
    independent."""
    layers._GIT_CACHE.clear()
    yield
    layers._GIT_CACHE.clear()


class TestResolveViaGit:
    def test_git_dir_at_cwd(self, tmp_path: Path) -> None:
        repo = tmp_path / "myrepo"
        repo.mkdir()
        (repo / ".git").mkdir()
        assert layers.resolve_via_git(str(repo)) == "myrepo"

    def test_git_dir_walked_from_subdirectory(self, tmp_path: Path) -> None:
        repo = tmp_path / "myrepo"
        repo.mkdir()
        (repo / ".git").mkdir()
        nested = repo / "src" / "module"
        nested.mkdir(parents=True)
        assert layers.resolve_via_git(str(nested)) == "myrepo"

    def test_git_file_worktree_form(self, tmp_path: Path) -> None:
        # ``.git`` is a FILE in worktrees (``gitdir: ...`` pointer).
        repo = tmp_path / "worktree-repo"
        repo.mkdir()
        (repo / ".git").write_text("gitdir: /some/other/path\n")
        assert layers.resolve_via_git(str(repo)) == "worktree-repo"

    def test_outside_any_git_repo_returns_none(self, tmp_path: Path) -> None:
        # Use a deep subdirectory under tmp_path so there's no .git
        # accidentally inherited from a parent of the test runner cwd.
        d = tmp_path / "no-git-here" / "deep"
        d.mkdir(parents=True)
        # Walk all the way up — but tmp_path ancestors might include
        # .git elsewhere on dev machines. We assert by checking the
        # *value*: it should be the basename of whatever git root is
        # found, OR None. The contract is "returns None when no .git
        # is found before the filesystem root"; we can't guarantee
        # that on every dev machine. A bullet-proof negative test:
        # walk under a directory we know is outside any git repo by
        # constructing a path under /private/var/folders (macOS tmp)
        # which is never under a .git tree.
        result = layers.resolve_via_git(str(d))
        # result is either None (clean negative) or some ancestor
        # repo basename (CI in a container with /tmp under a mount
        # not inside any repo). Either is acceptable; what we MUST
        # NOT see is the basename of ``d`` itself.
        assert result != "deep"
        assert result != "no-git-here"

    def test_branch_info_never_concatenated(self, tmp_path: Path) -> None:
        """Option A LOCKED — even if the repo has a branch, output is
        repo basename only. No ``:`` separator, no branch substring."""
        repo = tmp_path / "myrepo"
        repo.mkdir()
        (repo / ".git").mkdir()
        # Simulate a branch checkout — ``HEAD`` exists with a ref.
        (repo / ".git" / "HEAD").write_text(
            "ref: refs/heads/feature/auth-v2\n"
        )
        result = layers.resolve_via_git(str(repo))
        assert result == "myrepo"
        assert ":" not in result
        assert "feature" not in result
        assert "auth" not in result

    def test_caches_result_per_cwd(self, tmp_path: Path) -> None:
        repo = tmp_path / "cached-repo"
        repo.mkdir()
        (repo / ".git").mkdir()
        result1 = layers.resolve_via_git(str(repo))
        # Cached value present.
        assert str(repo) in layers._GIT_CACHE
        # Removing .git should NOT affect the cached lookup.
        (repo / ".git").rmdir()
        result2 = layers.resolve_via_git(str(repo))
        assert result1 == result2 == "cached-repo"

    def test_caches_negative_result(self, tmp_path: Path) -> None:
        d = tmp_path / "nope"
        d.mkdir()
        # First call walks the filesystem.
        layers.resolve_via_git(str(d))
        # Cache populated either way (None or a parent's basename).
        assert str(d) in layers._GIT_CACHE

    def test_empty_cwd_returns_none(self) -> None:
        assert layers.resolve_via_git("") is None

    def test_basename_run_through_normaliser(self, tmp_path: Path) -> None:
        """A repo dir with disallowed chars is normalised."""
        repo = tmp_path / "Weird Repo Name"
        repo.mkdir()
        (repo / ".git").mkdir()
        assert layers.resolve_via_git(str(repo)) == "weird-repo-name"


# --------------------------------------------------------------------------- #
# Layer 6 — container detection                                               #
# --------------------------------------------------------------------------- #


def _fs_probe_factory(present: set[str]):
    """Build a deterministic fs_probe that returns True only for ``present``."""

    def probe(path: str) -> bool:
        return path in present

    return probe


class TestResolveViaContainer:
    def test_dev_laptop_returns_none(self) -> None:
        """REGRESSION (the bug from the v0.3 draft).

        On a developer laptop:
        - No /.dockerenv
        - No KUBERNETES_SERVICE_HOST
        - No /proc/1/cgroup (or it has no docker/k8s/containerd)

        Container detection MUST return None even though HOSTNAME is
        set (every macOS/Linux box has one). Without this case the
        draft's bug recurs — every dev's local traffic gets tagged
        ``k8s:<machinename>``.
        """
        result = layers.resolve_via_container(
            env={"HOSTNAME": "vikrants-mbp"},
            fs_probe=_fs_probe_factory(set()),
        )
        assert result is None

    def test_kubernetes_pod(self) -> None:
        result = layers.resolve_via_container(
            env={
                "KUBERNETES_SERVICE_HOST": "10.0.0.1",
                "HOSTNAME": "checkout-pod-abc",
            },
            fs_probe=_fs_probe_factory(set()),
        )
        assert result == "k8s:checkout-pod-abc"

    def test_docker_container(self) -> None:
        result = layers.resolve_via_container(
            env={"HOSTNAME": "a1b2c3d4"},
            fs_probe=_fs_probe_factory({"/.dockerenv"}),
        )
        assert result == "docker:a1b2c3d4"

    def test_kubernetes_takes_precedence_over_docker_marker(self) -> None:
        """If both signals present, k8s wins (the more specific case)."""
        result = layers.resolve_via_container(
            env={
                "KUBERNETES_SERVICE_HOST": "10.0.0.1",
                "HOSTNAME": "podlike",
            },
            fs_probe=_fs_probe_factory({"/.dockerenv"}),
        )
        assert result == "k8s:podlike"

    def test_containerd_via_cgroup(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """``/proc/1/cgroup`` containing ``containerd`` triggers docker shape."""
        cgroup_path = tmp_path / "cgroup"
        cgroup_path.write_text("0::/system.slice/containerd.service\n")

        # Inject a probe + a fake open that reads our temp file when
        # asked for /proc/1/cgroup.
        present = {"/proc/1/cgroup"}

        def probe(p: str) -> bool:
            return p in present

        real_open = open

        def fake_open(path, *args, **kwargs):  # type: ignore[no-untyped-def]
            if path == "/proc/1/cgroup":
                return real_open(cgroup_path, *args, **kwargs)
            return real_open(path, *args, **kwargs)

        monkeypatch.setattr("builtins.open", fake_open)
        result = layers.resolve_via_container(
            env={"HOSTNAME": "host123"},
            fs_probe=probe,
        )
        assert result == "docker:host123"

    def test_kubepods_via_cgroup(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        cgroup_path = tmp_path / "cgroup"
        cgroup_path.write_text(
            "0::/kubepods.slice/kubepods-burstable-pod123\n"
        )

        present = {"/proc/1/cgroup"}

        def probe(p: str) -> bool:
            return p in present

        real_open = open

        def fake_open(path, *args, **kwargs):  # type: ignore[no-untyped-def]
            if path == "/proc/1/cgroup":
                return real_open(cgroup_path, *args, **kwargs)
            return real_open(path, *args, **kwargs)

        monkeypatch.setattr("builtins.open", fake_open)
        result = layers.resolve_via_container(
            env={"HOSTNAME": "node-host"},
            fs_probe=probe,
        )
        # cgroup gate fires (kubepods marker) but no
        # KUBERNETES_SERVICE_HOST — emits docker shape per the rule.
        assert result == "docker:node-host"

    def test_clean_cgroup_does_not_fire(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A real-host /proc/1/cgroup (no docker/k8s/containerd marker)
        must NOT trigger the gate."""
        cgroup_path = tmp_path / "cgroup"
        cgroup_path.write_text("0::/init.scope\n")

        present = {"/proc/1/cgroup"}

        def probe(p: str) -> bool:
            return p in present

        real_open = open

        def fake_open(path, *args, **kwargs):  # type: ignore[no-untyped-def]
            if path == "/proc/1/cgroup":
                return real_open(cgroup_path, *args, **kwargs)
            return real_open(path, *args, **kwargs)

        monkeypatch.setattr("builtins.open", fake_open)
        result = layers.resolve_via_container(
            env={"HOSTNAME": "real-host"},
            fs_probe=probe,
        )
        assert result is None

    def test_k8s_with_empty_hostname_returns_none(self) -> None:
        """KUBERNETES_SERVICE_HOST set but HOSTNAME empty → don't emit
        ``k8s:`` with empty suffix."""
        result = layers.resolve_via_container(
            env={"KUBERNETES_SERVICE_HOST": "10.0.0.1", "HOSTNAME": ""},
            fs_probe=_fs_probe_factory(set()),
        )
        assert result is None

    def test_docker_with_empty_hostname_returns_none(self) -> None:
        result = layers.resolve_via_container(
            env={"HOSTNAME": ""},
            fs_probe=_fs_probe_factory({"/.dockerenv"}),
        )
        assert result is None

    def test_default_fs_probe_used_when_none_passed(self) -> None:
        """Production code path passes no fs_probe; ensure default works
        and (on a dev laptop) returns None."""
        # On the dev laptop running the test suite, /.dockerenv is
        # absent, KUBERNETES_SERVICE_HOST should not be set in our
        # test env. We pass a clean env to be defensive.
        result = layers.resolve_via_container(env={"HOSTNAME": "host"})
        # CI containers might trip the gate — assertion is "either
        # None or a properly-prefixed slug". Critically: never crashes.
        assert result is None or result.startswith(("k8s:", "docker:"))


# --------------------------------------------------------------------------- #
# Layer 6.5 — macOS sandbox bundle id                                         #
# --------------------------------------------------------------------------- #


class TestResolveViaMacSandbox:
    def test_perplexity_data_dir(self) -> None:
        result = layers.resolve_via_mac_sandbox(
            "/Users/stack/Library/Containers/ai.perplexity.mac/Data"
        )
        assert result == "mac:ai.perplexity.mac"

    def test_subpath_inside_data_accepted(self) -> None:
        """Sandboxed apps frequently chdir into ``Data/Documents`` etc."""
        result = layers.resolve_via_mac_sandbox(
            "/Users/stack/Library/Containers/ai.perplexity.mac/Data/Documents"
        )
        assert result == "mac:ai.perplexity.mac"

    def test_user_folder_named_data_does_not_match(self) -> None:
        """REGRESSION (Brief D over-eager guard).

        ``/Users/stack/code/Data`` is a user folder that happens to be
        named ``Data`` — NOT under ``Library/Containers``. Layer 6.5
        must return ``None`` so Layer 7 can emit ``Data`` as before.
        """
        assert layers.resolve_via_mac_sandbox("/Users/stack/code/Data") is None

    def test_bundle_without_dot_rejected(self) -> None:
        """Bundle ids are reverse-DNS — no dot means it isn't one.
        Fixture or test path; fall through to Layer 7."""
        assert (
            layers.resolve_via_mac_sandbox(
                "/Users/stack/Library/Containers/random-no-dots/Data"
            )
            is None
        )

    def test_bare_bundle_directory_without_data_segment_rejected(self) -> None:
        """The ``/Data`` segment is the canonical sandbox cwd. The bare
        bundle directory is a different shape — fall through."""
        assert (
            layers.resolve_via_mac_sandbox(
                "/Users/stack/Library/Containers/ai.perplexity.mac"
            )
            is None
        )

    def test_linux_path_rejected(self) -> None:
        """Layer 6.5 is macOS-scoped; Linux containers belong to Layer 6."""
        assert (
            layers.resolve_via_mac_sandbox(
                "/home/stack/Library/Containers/foo.bar/Data"
            )
            is None
        )

    def test_empty_cwd_returns_none(self) -> None:
        assert layers.resolve_via_mac_sandbox("") is None

    def test_chatgpt_desktop_shape(self) -> None:
        """A second realistic bundle id — ChatGPT desktop."""
        result = layers.resolve_via_mac_sandbox(
            "/Users/stack/Library/Containers/com.openai.chat/Data"
        )
        assert result == "mac:com.openai.chat"
