"""Hot-path tests for v0.1.13 body capture.

Round-trips synthetic Anthropic-shape flows through HaltonAddon (the same
synthetic-flow pattern test_capture_integration.py uses) and asserts:

  * Bodies land in request_bodies, FK'd to the corresponding requests row.
  * Truncation: > max_body_bytes triggers ``response_truncated=True`` and
    the original byte count is preserved.
  * Redaction: a body containing a credential lands with a placeholder and
    populates redaction_summary.
  * Per-project opt-out: a project flagged off in project_settings produces
    a counts row but no body row.
  * Master switch: bodies.enabled=False short-circuits everything (no body
    row, counts row preserved).
  * Fail-open: a redaction failure (monkeypatched to raise) drops the body
    row, leaves the counts row, and logs the failure — the request is
    forwarded normally.
  * SSE: an accumulated SSE response body lands verbatim.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import uuid
from pathlib import Path

import pytest
from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.body_capture import BodyCaptureCache
from halton_meter.proxy import HaltonAddon
from halton_meter.storage import StorageManager

# --------------------------------------------------------------------------- #
# Flow construction helpers                                                   #
# --------------------------------------------------------------------------- #


def _make_flow(
    *,
    request_body: str | bytes | None = None,
    response_body: str | bytes | None = None,
    response_status: int = 200,
    response_content_type: str = "application/json",
) -> http.HTTPFlow:
    """Construct a synthetic /v1/messages flow with custom bodies."""
    if request_body is None:
        request_body = json.dumps(
            {
                "model": "claude-haiku-4-5",
                "max_tokens": 64,
                "messages": [{"role": "user", "content": "hi"}],
            }
        )
    if response_body is None:
        response_body = json.dumps(
            {
                "id": "msg_test_001",
                "type": "message",
                "role": "assistant",
                "content": [{"type": "text", "text": "hello"}],
                "model": "claude-haiku-4-5",
                "stop_reason": "end_turn",
                "stop_sequence": None,
                "usage": {"input_tokens": 18, "output_tokens": 7},
            }
        )

    if isinstance(request_body, str):
        request_body = request_body.encode("utf-8")
    if isinstance(response_body, str):
        response_body = response_body.encode("utf-8")

    req = tutils.treq(host="api.anthropic.com", port=443, path="/v1/messages")
    req.content = request_body
    req.headers["content-type"] = "application/json"
    flow = tflow.tflow(req=req)
    flow.id = str(uuid.uuid4())
    flow.response = http.Response.make(
        response_status,
        response_body,
        {"Content-Type": response_content_type},
    )
    return flow


async def _drain_pending() -> None:
    for _ in range(20):
        pending = [
            t
            for t in asyncio.all_tasks()
            if not t.done() and t is not asyncio.current_task()
        ]
        if not pending:
            break
        await asyncio.gather(*pending, return_exceptions=True)
        await asyncio.sleep(0)


def _read_body_row(db_path: Path, request_id: str) -> dict | None:
    """Direct SQL fetch of a request_bodies row."""
    with sqlite3.connect(str(db_path)) as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute(
            "SELECT * FROM request_bodies WHERE request_id = ?",
            (request_id,),
        )
        row = cur.fetchone()
        if row is None:
            return None
        return dict(row)


def _request_id_in_db(db_path: Path) -> str:
    """Return the single request id present (asserts exactly one)."""
    with sqlite3.connect(str(db_path)) as conn:
        rows = conn.execute("SELECT id FROM requests").fetchall()
    assert len(rows) == 1, f"expected 1 request row, got {len(rows)}"
    return rows[0][0]


# --------------------------------------------------------------------------- #
# Happy path: body lands, FK linked, redaction fields populated               #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_capture_round_trip_writes_body_row(tmp_path: Path) -> None:
    db_path = tmp_path / "happy.sqlite"

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        await addon.request(flow)
        assert flow.id in addon._pending
        # PendingCapture should carry a captured request body for an
        # opted-in (default-on) project.
        pending = addon._pending[flow.id]
        assert pending.request_body is not None
        assert pending.request_body.text is not None
        assert "messages" in pending.request_body.text

        await addon.response(flow)
        await _drain_pending()

    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    assert body_row is not None
    assert body_row["request_body"] is not None
    assert body_row["response_body"] is not None
    assert body_row["request_body_bytes"] > 0
    assert body_row["response_body_bytes"] > 0
    assert body_row["request_truncated"] == 0
    assert body_row["response_truncated"] == 0
    assert body_row["redaction_applied"] == 0  # no creds in fixture
    assert body_row["capture_error"] is None
    assert body_row["request_content_type"] == "application/json"


@pytest.mark.asyncio
async def test_redaction_landed_in_body_row_when_credential_present(
    tmp_path: Path,
) -> None:
    db_path = tmp_path / "red.sqlite"

    bad_request = json.dumps(
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 8,
            "messages": [
                {
                    "role": "user",
                    "content": "leaked OPENAI_API_KEY=sk-proj-AbCdEf0123456789AbCdEf01",
                }
            ],
        }
    )

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow(request_body=bad_request)
        await addon.request(flow)
        await addon.response(flow)
        await _drain_pending()

    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    assert body_row is not None
    assert body_row["redaction_applied"] == 1
    # Stored body has the placeholder; original key is gone.
    assert "[REDACTED:openai_key]" in body_row["request_body"]
    assert "sk-proj-AbCdEf0123456789AbCdEf01" not in body_row["request_body"]
    # Summary JSON has openai_key counted.
    summary = json.loads(body_row["redaction_summary"])
    assert summary.get("openai_key", 0) >= 1


# --------------------------------------------------------------------------- #
# Truncation                                                                  #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_oversize_response_body_is_truncated(tmp_path: Path) -> None:
    db_path = tmp_path / "trunc.sqlite"

    # Build a response body that is well over the cap. Use a small cap to
    # keep the test fast. The body is pure JSON: a "pad" key with N x's.
    cap = 4096
    pad = "x" * (cap * 4)  # 4x the cap
    big_response = json.dumps(
        {
            "id": "msg_big",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": "hello"}],
            "model": "claude-haiku-4-5",
            "stop_reason": "end_turn",
            "stop_sequence": None,
            "usage": {"input_tokens": 1, "output_tokens": 1},
            "pad": pad,
        }
    )
    original_size = len(big_response.encode("utf-8"))

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=cap,
        )

        flow = _make_flow(response_body=big_response)
        await addon.request(flow)
        await addon.response(flow)
        await _drain_pending()

    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    assert body_row is not None
    assert body_row["response_truncated"] == 1
    # Stored body length is at most the cap.
    assert len(body_row["response_body"]) <= cap
    # Original size is preserved.
    assert int(body_row["response_body_bytes"]) == original_size


# --------------------------------------------------------------------------- #
# Per-project opt-out                                                         #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_project_opted_out_skips_body_row(tmp_path: Path) -> None:
    """A project with body_capture_enabled=False produces a counts row
    but no body row."""
    db_path = tmp_path / "optout.sqlite"

    async with StorageManager(db_path) as storage:
        # First, pre-create the project + opt it out via a synchronous
        # SQL insert (matches what `halton-meter project … set` does).
        # We need the project's slug to match what the daemon's
        # tagger resolves to. With no edge attribution and no rcfile,
        # the daemon's resolver falls back through smart_default to
        # ``"misc"`` (config: ``tagging.default_project``) — so we opt
        # out *that* slug.
        from halton_meter.project_settings_cli import set_body_capture

        set_body_capture(db_path, "misc", enabled=False)

        cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        await addon.request(flow)
        # PendingCapture has request_body=None for opted-out projects.
        pending = addon._pending[flow.id]
        assert pending.request_body is None

        await addon.response(flow)
        await _drain_pending()

    # Counts row landed.
    request_id = _request_id_in_db(db_path)
    # Body row absent.
    body_row = _read_body_row(db_path, request_id)
    assert body_row is None


@pytest.mark.asyncio
async def test_master_switch_disables_capture(tmp_path: Path) -> None:
    """master_enabled=False short-circuits regardless of project_settings."""
    db_path = tmp_path / "master_off.sqlite"

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(db_path=db_path, master_enabled=False, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        await addon.request(flow)
        # Cache returned False on every is_enabled_for, so request_body
        # is None.
        pending = addon._pending[flow.id]
        assert pending.request_body is None

        await addon.response(flow)
        await _drain_pending()

    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    assert body_row is None


# --------------------------------------------------------------------------- #
# attribution_log fallback (B2 — rcfile body_capture plumbed via edge)        #
# --------------------------------------------------------------------------- #


def _seed_attribution_log_row(
    db_path: Path,
    *,
    project_name: str,
    body_capture_enabled: bool,
    edge_src_port: int = 50001,
    created_at: float | None = None,
) -> None:
    """Insert a row into ``attribution_log`` directly.

    Mirrors what the edge process does after resolving a CONNECT to a
    project + rcfile flag. Creates the table if it doesn't exist (the
    daemon's storage layer normally handles the migration; for tests
    that don't go through ``StorageManager`` we run the same DDL the
    edge writer would).
    """
    import time as _time

    bce = 1 if body_capture_enabled else 0
    ts = float(created_at) if created_at is not None else _time.time()
    with sqlite3.connect(str(db_path)) as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS attribution_log ("
            "edge_src_port INTEGER PRIMARY KEY, "
            "project_name TEXT NOT NULL, "
            "created_at REAL NOT NULL, "
            "body_capture_enabled BOOLEAN NOT NULL DEFAULT 1)"
        )
        conn.execute(
            "INSERT OR REPLACE INTO attribution_log "
            "(edge_src_port, project_name, created_at, body_capture_enabled) "
            "VALUES (?, ?, ?, ?)",
            (edge_src_port, project_name, ts, bce),
        )
        conn.commit()


@pytest.mark.asyncio
async def test_attribution_log_optout_skips_body_row(tmp_path: Path) -> None:
    """rcfile-driven opt-out lands in ``attribution_log`` (no
    project_settings row). BodyCaptureCache should consult it as
    fallback and the addon should skip the body row + emit
    ``addon.body_capture.skip reason=opt_out``.
    """
    db_path = tmp_path / "rcfile_optout.sqlite"

    async with StorageManager(db_path) as storage:
        # Edge wrote: project=misc (the slug the tagger's smart_default
        # branch resolves to in the synthetic-flow test fixture, where
        # there's no env var, no rcfile, and no client cwd to walk),
        # body capture explicitly off via .haltonrc.
        _seed_attribution_log_row(
            db_path, project_name="misc", body_capture_enabled=False
        )

        cache = BodyCaptureCache(
            db_path=db_path, master_enabled=True, ttl_seconds=300
        )
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        await addon.request(flow)
        # Opted out via attribution_log — no captured body in the
        # PendingCapture.
        pending = addon._pending[flow.id]
        assert pending.request_body is None

        await addon.response(flow)
        await _drain_pending()

    # Counts row landed.
    request_id = _request_id_in_db(db_path)
    # Body row absent.
    body_row = _read_body_row(db_path, request_id)
    assert body_row is None


@pytest.mark.asyncio
async def test_attribution_log_default_on_when_flag_true(
    tmp_path: Path,
) -> None:
    """rcfile present without ``body_capture`` (or with ``body_capture
    = on``) writes ``body_capture_enabled=1``. Body row should land
    normally — equivalent to the no-rcfile default.
    """
    db_path = tmp_path / "rcfile_on.sqlite"

    async with StorageManager(db_path) as storage:
        _seed_attribution_log_row(
            db_path, project_name="unattributed", body_capture_enabled=True
        )

        cache = BodyCaptureCache(
            db_path=db_path, master_enabled=True, ttl_seconds=300
        )
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        await addon.request(flow)
        await addon.response(flow)
        await _drain_pending()

    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    assert body_row is not None  # default-ON behaviour preserved


@pytest.mark.asyncio
async def test_project_settings_wins_over_attribution_log(
    tmp_path: Path,
) -> None:
    """When both ``project_settings`` AND ``attribution_log`` carry a
    flag, ``project_settings`` wins (the CLI is the canonical surface).
    """
    db_path = tmp_path / "ps_vs_attr.sqlite"

    async with StorageManager(db_path) as storage:
        from halton_meter.project_settings_cli import set_body_capture

        # CLI says ON for this slug.
        set_body_capture(db_path, "unattributed", enabled=True)
        # Edge says OFF for the same slug (e.g. user toggled rcfile
        # after CLI-pinning it on). CLI wins.
        _seed_attribution_log_row(
            db_path, project_name="unattributed", body_capture_enabled=False
        )

        cache = BodyCaptureCache(
            db_path=db_path, master_enabled=True, ttl_seconds=300
        )
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        await addon.request(flow)
        await addon.response(flow)
        await _drain_pending()

    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    assert body_row is not None  # project_settings ON wins


@pytest.mark.asyncio
async def test_attribution_log_freshest_row_wins(tmp_path: Path) -> None:
    """Multiple ``attribution_log`` rows for the same project: the
    most recent ``created_at`` wins (matches the ORDER BY DESC LIMIT 1
    contract).
    """
    db_path = tmp_path / "freshest.sqlite"

    async with StorageManager(db_path):
        # Older row says OFF, newer row says ON. Newer should win.
        _seed_attribution_log_row(
            db_path,
            project_name="unattributed",
            body_capture_enabled=False,
            edge_src_port=40001,
            created_at=1000.0,
        )
        _seed_attribution_log_row(
            db_path,
            project_name="unattributed",
            body_capture_enabled=True,
            edge_src_port=40002,
            created_at=2000.0,
        )

        cache = BodyCaptureCache(
            db_path=db_path, master_enabled=True, ttl_seconds=300
        )
        # Direct probe of the cache — clearer than re-running the
        # whole addon for the freshest-wins assertion.
        assert cache.is_enabled_for("unattributed") is True


# --------------------------------------------------------------------------- #
# Fail-open                                                                   #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_redaction_failure_drops_body_keeps_counts(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """If redaction explodes, no body row is written, counts row IS written,
    and the request is forwarded normally (fail-open).
    """
    db_path = tmp_path / "redact_fail.sqlite"

    def boom(_text: str) -> tuple[str, list]:
        raise RuntimeError("synthetic redaction failure")

    # Patch where the body_capture module calls into the redaction module.
    monkeypatch.setattr(
        "halton_meter.body_capture.redact_credentials", boom
    )

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        # Must not raise.
        await addon.request(flow)
        await addon.response(flow)
        await _drain_pending()

        # Counts row landed.
        records = await storage.read_records()
        assert len(records) == 1

    # A body row exists *only* if the response side captured successfully;
    # in this test redaction is killed for both sides, so build_body_record
    # decides whether to write at all. Either:
    #   - both sides have capture_error="redaction_failed" → no text, no
    #     summary, but a row is written so the operator sees "we tried";
    #   - or no row at all if the request side returned None.
    # Either way: no leaked credentials, no exception. Confirm that:
    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    if body_row is not None:
        # capture_error must be set (redaction_failed) and bodies must be NULL.
        assert body_row["redaction_applied"] == 0
        # We dropped the body when redaction failed.
        # request_body / response_body should be None.
        assert body_row["request_body"] is None or body_row["request_body"] == ""
        assert body_row["response_body"] is None or body_row["response_body"] == ""


@pytest.mark.asyncio
async def test_request_hook_does_not_raise_on_capture_failure(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Defence-in-depth: even if capture_body itself raises, request() does
    not raise out of the hot path."""
    db_path = tmp_path / "hook_fail.sqlite"

    def boom(_msg, *, max_bytes, side):
        raise RuntimeError("synthetic capture explosion")

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow()
        # Patch only the proxy module's reference to capture_body so the
        # request hook's wrapper around it fires.
        monkeypatch.setattr("halton_meter.proxy.capture_body", boom)

        # Must not raise.
        await addon.request(flow)
        # _pending still has the flow (with request_body=None — the
        # capture try/except swallowed the error).
        assert flow.id in addon._pending
        assert addon._pending[flow.id].request_body is None


# --------------------------------------------------------------------------- #
# SSE                                                                         #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_sse_response_body_lands_verbatim(tmp_path: Path) -> None:
    """An accumulated SSE response body lands verbatim under the pure-buffer
    assumption (mitmproxy delivers the full body to ``flow.response.content``
    by the time response() fires).
    """
    db_path = tmp_path / "sse.sqlite"

    sse_body = (
        "event: message_start\n"
        'data: {"type":"message_start","message":{"id":"msg_001","model":"claude-haiku-4-5",'
        '"usage":{"input_tokens":1,"output_tokens":0}}}\n\n'
        "event: content_block_delta\n"
        'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"hello"}}\n\n'
        "event: message_delta\n"
        'data: {"type":"message_delta","delta":{},"usage":{"output_tokens":2}}\n\n'
        "event: message_stop\n"
        'data: {"type":"message_stop"}\n\n'
    )

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        flow = _make_flow(
            response_body=sse_body,
            response_content_type="text/event-stream",
        )
        await addon.request(flow)
        await addon.response(flow)
        await _drain_pending()

    request_id = _request_id_in_db(db_path)
    body_row = _read_body_row(db_path, request_id)
    assert body_row is not None
    # Verbatim — no parsing, no reserialisation.
    assert body_row["response_body"] == sse_body
    assert body_row["response_content_type"] == "text/event-stream"
    assert body_row["response_truncated"] == 0


# --------------------------------------------------------------------------- #
# Cache TTL & invalidation                                                    #
# --------------------------------------------------------------------------- #


def test_body_capture_cache_default_on_for_new_project(tmp_path: Path) -> None:
    """A project with no settings row should resolve to enabled=True."""
    import asyncio

    from halton_meter.storage import StorageManager

    db_path = tmp_path / "cache.sqlite"

    async def _init() -> None:
        async with StorageManager(db_path):
            pass

    asyncio.run(_init())

    cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)
    assert cache.is_enabled_for("never-seen") is True


def test_body_capture_cache_master_off_overrides_project(tmp_path: Path) -> None:
    """master_enabled=False makes is_enabled_for return False unconditionally."""
    import asyncio

    from halton_meter.project_settings_cli import set_body_capture
    from halton_meter.storage import StorageManager

    db_path = tmp_path / "master.sqlite"

    async def _init() -> None:
        async with StorageManager(db_path):
            pass

    asyncio.run(_init())

    # Project has body-capture explicitly ON.
    set_body_capture(db_path, "demo", enabled=True)

    cache = BodyCaptureCache(db_path=db_path, master_enabled=False, ttl_seconds=300)
    # Master switch wins.
    assert cache.is_enabled_for("demo") is False


# --------------------------------------------------------------------------- #
# Regression: write_record / write_body_record race (v0.1.13.dev1)            #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_two_consecutive_requests_each_persist_body_row(tmp_path: Path) -> None:
    """Reproduces the v0.1.13 trial-run silent-skip-after-first bug.

    Symptom: of N consecutive requests through the addon, only the first
    persists a ``request_bodies`` row. Subsequent flows write the counts
    row but the body insert silently fails the FK constraint and the
    IntegrityError branch swallows the rollback without logging.

    Root cause: ``write_record`` and ``write_body_record`` were two
    parallel ``asyncio.create_task`` calls. They raced for the SQLite
    write lock; when the body task won, the parent ``requests`` row
    didn't exist yet, FK fired, ``IntegrityError`` was caught and
    rolled back silently. On the very first request the
    ``_get_or_create_project`` insert added enough latency to the
    counts task that it usually still won; on every subsequent flow
    the project already existed, the counts task got faster, and the
    race tipped the other way.

    Fix: chain the two writes in a single task so the body insert
    happens AFTER the counts insert commits. This test exercises
    three requests in a row through one addon and asserts each one
    lands a body row.
    """
    db_path = tmp_path / "race.sqlite"

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(
            db_path=db_path, master_enabled=True, ttl_seconds=300
        )
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        record_ids: list[str] = []
        for _ in range(3):
            flow = _make_flow()
            await addon.request(flow)
            await addon.response(flow)
            await _drain_pending()

        # Verify after the run finishes: count rows in both tables.
        with sqlite3.connect(str(db_path)) as conn:
            req_rows = conn.execute("SELECT id FROM requests").fetchall()
            body_rows = conn.execute(
                "SELECT request_id FROM request_bodies"
            ).fetchall()

        record_ids = [r[0] for r in req_rows]

    assert len(record_ids) == 3, (
        f"expected 3 counts rows, got {len(record_ids)}"
    )
    assert len(body_rows) == 3, (
        f"regression: only {len(body_rows)} body rows for 3 requests "
        f"(silent-skip-after-first bug). request ids: {record_ids}, "
        f"body request_ids: {[r[0] for r in body_rows]}"
    )
    body_ids = {r[0] for r in body_rows}
    assert body_ids == set(record_ids), (
        "every counts row must have a matching body row; "
        f"missing: {set(record_ids) - body_ids}"
    )


@pytest.mark.asyncio
async def test_request_bodies_FK_holds_when_body_task_runs_after_counts(
    tmp_path: Path,
) -> None:
    """Defence-in-depth: the body row must FK-link to the counts row.

    Asserts the FK target is present and joinable after the chained
    write completes. Catches any future regression that decouples
    the two tables (e.g. a refactor that drops the FK constraint
    or stops calling write_record before write_body_record).
    """
    db_path = tmp_path / "fk.sqlite"

    async with StorageManager(db_path) as storage:
        cache = BodyCaptureCache(
            db_path=db_path, master_enabled=True, ttl_seconds=300
        )
        addon = HaltonAddon(
            storage=storage,
            body_capture_cache=cache,
            max_body_bytes=512 * 1024,
        )

        for _ in range(2):
            flow = _make_flow()
            await addon.request(flow)
            await addon.response(flow)
            await _drain_pending()

    with sqlite3.connect(str(db_path)) as conn:
        # Pragma must be re-enabled per connection; assert FK is enforced
        # at read-time too.
        conn.execute("PRAGMA foreign_keys = ON")
        joined = conn.execute(
            "SELECT r.id, b.request_id "
            "FROM requests r LEFT JOIN request_bodies b "
            "ON r.id = b.request_id"
        ).fetchall()
    assert len(joined) == 2
    for req_id, body_req_id in joined:
        assert body_req_id == req_id, (
            f"counts row {req_id} has no matching body row"
        )


def test_body_capture_cache_invalidate(tmp_path: Path) -> None:
    """Explicit invalidate() forces a re-read on the next call."""
    import asyncio

    from halton_meter.project_settings_cli import set_body_capture
    from halton_meter.storage import StorageManager

    db_path = tmp_path / "inv.sqlite"

    async def _init() -> None:
        async with StorageManager(db_path):
            pass

    asyncio.run(_init())

    cache = BodyCaptureCache(db_path=db_path, master_enabled=True, ttl_seconds=300)

    # Default ON for a never-seen project.
    assert cache.is_enabled_for("ttl-demo") is True

    # Flip to OFF in the DB but the cache still says True until invalidated.
    set_body_capture(db_path, "ttl-demo", enabled=False)
    assert cache.is_enabled_for("ttl-demo") is True  # cached pre-flip

    cache.invalidate("ttl-demo")
    assert cache.is_enabled_for("ttl-demo") is False  # re-read after invalidate
