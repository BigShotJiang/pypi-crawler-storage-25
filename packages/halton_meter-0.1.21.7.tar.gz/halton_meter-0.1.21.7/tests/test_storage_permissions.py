"""
Tests for ~/.halton-meter/db.sqlite + dir + WAL/SHM permission hardening.

Multi-user Linux is a Phase-0 audit blocker: a default umask leaves the DB
world-readable. This test pins the contract that ``create_engine_for()``
tightens db.sqlite to 0o600, the parent dir to 0o700, and the WAL/SHM
sidecars to 0o600 when present.
"""

from __future__ import annotations

import os
import stat
import sys
from pathlib import Path

import pytest

from halton_meter.storage.engine import (
    _tighten_db_permissions,
    create_engine_for,
    dispose_engines,
)

pytestmark = pytest.mark.skipif(
    sys.platform == "win32",
    reason="POSIX file-mode bits don't apply on Windows",
)


@pytest.mark.asyncio
async def test_create_engine_tightens_db_and_dir_permissions(tmp_path: Path) -> None:
    """create_engine_for chmods the parent dir to 0o700 and creates the db at 0o600."""
    # Start the parent dir intentionally world-readable to prove we tighten it.
    db_dir = tmp_path / "halton-meter"
    db_dir.mkdir()
    db_dir.chmod(0o755)

    db_path = db_dir / "db.sqlite"
    # Pre-create the file at a too-permissive mode to prove we fix existing files.
    db_path.touch()
    db_path.chmod(0o644)

    try:
        create_engine_for(db_path)
    finally:
        await dispose_engines()

    dir_mode = stat.S_IMODE(db_dir.stat().st_mode)
    file_mode = stat.S_IMODE(db_path.stat().st_mode)
    assert dir_mode == 0o700, f"expected dir 0o700, got {oct(dir_mode)}"
    assert file_mode == 0o600, f"expected db 0o600, got {oct(file_mode)}"


def test_tighten_db_permissions_handles_sidecars(tmp_path: Path) -> None:
    """WAL + SHM sidecars are tightened to 0o600 when present."""
    db_path = tmp_path / "db.sqlite"
    db_path.touch()
    db_path.chmod(0o644)

    wal = tmp_path / "db.sqlite-wal"
    shm = tmp_path / "db.sqlite-shm"
    wal.touch()
    shm.touch()
    wal.chmod(0o644)
    shm.chmod(0o644)

    _tighten_db_permissions(db_path)

    assert stat.S_IMODE(db_path.stat().st_mode) == 0o600
    assert stat.S_IMODE(wal.stat().st_mode) == 0o600
    assert stat.S_IMODE(shm.stat().st_mode) == 0o600
    assert stat.S_IMODE(tmp_path.stat().st_mode) == 0o700


def test_tighten_db_permissions_idempotent_when_already_correct(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """Already-correct perms produce no chmod log entry (cheap path)."""
    db_path = tmp_path / "db.sqlite"
    db_path.touch()
    db_path.chmod(0o600)
    tmp_path.chmod(0o700)

    _tighten_db_permissions(db_path)

    # Still correct.
    assert stat.S_IMODE(db_path.stat().st_mode) == 0o600
    assert stat.S_IMODE(tmp_path.stat().st_mode) == 0o700


def test_tighten_db_permissions_missing_file_is_noop(tmp_path: Path) -> None:
    """No file → no error, no chmod attempt."""
    db_path = tmp_path / "absent.sqlite"
    # Should not raise.
    _tighten_db_permissions(db_path)
    assert not db_path.exists()


def test_tighten_db_permissions_swallows_chmod_errors(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A chmod failure logs but does not propagate (storage init must not block)."""
    db_path = tmp_path / "db.sqlite"
    db_path.touch()
    db_path.chmod(0o644)

    real_chmod = os.chmod

    def boom(path, mode, *args, **kwargs):  # type: ignore[no-untyped-def]
        if str(path).endswith("db.sqlite"):
            raise OSError("simulated chmod failure")
        return real_chmod(path, mode, *args, **kwargs)

    monkeypatch.setattr(os, "chmod", boom)
    # Path.chmod calls os.chmod under the hood; should not raise.
    _tighten_db_permissions(db_path)
