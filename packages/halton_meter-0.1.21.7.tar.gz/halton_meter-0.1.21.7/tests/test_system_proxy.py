"""Tests for ``halton_meter.system_proxy``.

Focused on the Layer-2 ``enable_system_proxy_if_managed`` helper and the
public ``read_proxy_target`` alias added in 2B.6.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

import pytest
import structlog
from structlog.testing import capture_logs

from halton_meter import system_proxy

# --------------------------------------------------------------------------- #
# enable_system_proxy_if_managed                                               #
# --------------------------------------------------------------------------- #


@pytest.fixture(autouse=True)
def _reset_macos_interfaces_cache() -> Any:
    """Reset the per-process cache of :func:`_macos_interfaces` between tests.

    The function memoises its result for the lifetime of the daemon
    process; tests need a clean slate so monkeypatched ``subprocess.run``
    fixtures actually take effect.
    """
    system_proxy._MACOS_INTERFACES_CACHE = None
    yield
    system_proxy._MACOS_INTERFACES_CACHE = None


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))  # type: ignore[arg-type]
    # The sentinel constant is captured at import time. Repoint it at the
    # tmp_path equivalent so the function under test reads the new home.
    monkeypatch.setattr(
        system_proxy,
        "_PROXY_MANAGED_SENTINEL",
        tmp_path / ".halton-meter" / "proxy-managed",
    )
    return tmp_path


def test_enable_no_op_when_sentinel_absent(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    system_proxy.enable_system_proxy_if_managed("127.0.0.1", 8080)
    assert calls == []


def test_enable_no_op_on_non_macos(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")
    # Even with sentinel present, non-macOS must not call subprocess.
    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    system_proxy.enable_system_proxy_if_managed("127.0.0.1", 8080)
    assert calls == []


def test_enable_no_op_when_networksetup_missing(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: None)

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    system_proxy.enable_system_proxy_if_managed("127.0.0.1", 8080)
    assert calls == []


def test_enable_with_sentinel_calls_networksetup_for_each_combo(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    system_proxy.enable_system_proxy_if_managed("127.0.0.1", 8080)

    # Per interface (4) x variant (2: secure/regular) x call (3: read+target+state) = 24
    # The pre-read is the bug-3 fix that lets us skip the address-set
    # call when the proxy already targets us.
    _set_flags = (
        "-setsecurewebproxy",
        "-setwebproxy",
        "-setsecurewebproxystate",
        "-setwebproxystate",
    )
    set_calls = [c for c in calls if c[1] in _set_flags]
    assert len(set_calls) == 16

    # Verify exact argv shape for Wi-Fi secure variant.
    assert [
        "networksetup",
        "-setsecurewebproxy",
        "Wi-Fi",
        "127.0.0.1",
        "8080",
    ] in calls
    assert [
        "networksetup",
        "-setsecurewebproxystate",
        "Wi-Fi",
        "on",
    ] in calls
    # And for the HTTP (non-secure) variant.
    assert [
        "networksetup",
        "-setwebproxy",
        "Wi-Fi",
        "127.0.0.1",
        "8080",
    ] in calls
    assert [
        "networksetup",
        "-setwebproxystate",
        "Wi-Fi",
        "on",
    ] in calls

    # All four interfaces appear at least once.
    for iface in ("Wi-Fi", "Ethernet", "USB 10/100/1000 LAN", "Thunderbolt Bridge"):
        assert any(iface in c for c in calls), f"missing iface {iface}"


def test_enable_swallows_per_interface_errors(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A failure on one interface must not stop the rest from running."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    calls: list[list[str]] = []

    def flaky_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        if "Wi-Fi" in argv:
            raise OSError("simulated failure")
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", flaky_run)

    # Must not raise.
    system_proxy.enable_system_proxy_if_managed("127.0.0.1", 8080)

    # Other interfaces still attempted.
    assert any("Ethernet" in c for c in calls)


# --------------------------------------------------------------------------- #
# Bug-3 fix: address-already-correct skip + structlog observability            #
# --------------------------------------------------------------------------- #


@pytest.fixture(autouse=True)
def _structlog_default_config() -> None:
    """Ensure capture_logs sees emissions from system_proxy's logger.

    capture_logs works against structlog's default configuration; module-
    level loggers obtained before configuration are bound to the default
    pipeline, so this is a no-op in practice but documents intent.
    """
    structlog.reset_defaults()


def test_enable_when_address_already_correct_skips_set_address(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the system proxy already points at us, skip ``-setsecurewebproxy``
    (which requires admin) and only toggle state on. This is the
    no-admin success path under launchd."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    # Pretend every interface already has the correct address.
    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (True, "127.0.0.1", "9080")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    system_proxy.enable_system_proxy_if_managed("127.0.0.1", 9080)

    # No -setsecurewebproxy / -setwebproxy calls (those need admin).
    address_set_calls = [
        c for c in calls if c[1] in ("-setsecurewebproxy", "-setwebproxy")
    ]
    assert address_set_calls == [], (
        "must not invoke -setsecurewebproxy when address already matches"
    )

    # Only state-toggles, one per (iface, variant).
    state_calls = [
        c for c in calls if c[1] in ("-setsecurewebproxystate", "-setwebproxystate")
    ]
    # 4 interfaces x 2 variants = 8 state-toggle calls.
    assert len(state_calls) == 8
    for c in state_calls:
        assert c[-1] == "on"


def test_enable_when_address_wrong_attempts_set_then_logs_on_failure(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the proxy address points elsewhere and -setsecurewebproxy fails
    (returncode != 0, e.g. requires admin), log a structured warning and
    skip the state-toggle for that (iface, variant)."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    # Pretend the address is wrong (different proxy).
    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (False, "10.0.0.1", "1234")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        if argv[1] in ("-setsecurewebproxy", "-setwebproxy"):
            return subprocess.CompletedProcess(
                argv, 1, stdout=b"", stderr=b"requires admin"
            )
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with capture_logs() as logs:
        system_proxy.enable_system_proxy_if_managed("127.0.0.1", 9080)

    # Address-set was attempted, then logged failure.
    address_set_calls = [
        c for c in calls if c[1] in ("-setsecurewebproxy", "-setwebproxy")
    ]
    assert len(address_set_calls) == 8  # 4 ifaces x 2 variants

    # State-toggle must NOT have run on any (iface, variant) where address-set failed.
    state_calls = [
        c for c in calls if c[1] in ("-setsecurewebproxystate", "-setwebproxystate")
    ]
    assert state_calls == [], (
        "state-toggle must be skipped when address-set fails"
    )

    # Each failure should produce a structlog warning.
    warning_events = [
        rec for rec in logs if rec.get("event") == "system_proxy.set_address_failed"
    ]
    assert len(warning_events) == 8
    sample = warning_events[0]
    assert "iface" in sample
    assert "stderr" in sample
    assert sample.get("returncode") == 1
    assert "requires admin" in sample.get("stderr", "")


def test_enable_logs_state_toggle_failure(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Address already correct, but state-toggle fails — emit
    ``system_proxy.set_state_failed`` so the user can diagnose."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (True, "127.0.0.1", "9080")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        if argv[1] in ("-setsecurewebproxystate", "-setwebproxystate"):
            return subprocess.CompletedProcess(
                argv, 1, stdout=b"", stderr=b"toggle failed"
            )
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with capture_logs() as logs:
        system_proxy.enable_system_proxy_if_managed("127.0.0.1", 9080)

    state_failure_events = [
        rec for rec in logs if rec.get("event") == "system_proxy.set_state_failed"
    ]
    assert len(state_failure_events) == 8
    sample = state_failure_events[0]
    assert sample.get("returncode") == 1
    assert "toggle failed" in sample.get("stderr", "")


# --------------------------------------------------------------------------- #
# read_proxy_target                                                            #
# --------------------------------------------------------------------------- #


def test_read_proxy_target_non_macos_returns_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")
    enabled, host, port = system_proxy.read_proxy_target("Wi-Fi")
    assert (enabled, host, port) == (False, None, None)


def test_read_proxy_target_parses_int_port(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (True, "127.0.0.1", "8080")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    enabled, host, port = system_proxy.read_proxy_target("Wi-Fi")
    assert enabled is True
    assert host == "127.0.0.1"
    assert port == 8080


def test_read_proxy_target_handles_garbage_port(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (True, "127.0.0.1", "not-a-number")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    enabled, host, port = system_proxy.read_proxy_target("Wi-Fi")
    assert enabled is True
    assert host == "127.0.0.1"
    assert port is None


# --------------------------------------------------------------------------- #
# enable_system_proxy_if_managed — eager=True (Phase 2B.7)                     #
# --------------------------------------------------------------------------- #


def test_enable_eager_raises_on_set_address_failure(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """With ``eager=True`` and a wrong proxy address, a non-zero return
    from ``-setsecurewebproxy`` aborts immediately with a RuntimeError
    that names the iface, the argv, and the stderr."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (False, "10.0.0.1", "1234")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        if argv[1] in ("-setsecurewebproxy", "-setwebproxy"):
            return subprocess.CompletedProcess(
                argv, 1, stdout=b"", stderr=b"requires admin"
            )
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with pytest.raises(RuntimeError) as exc_info:
        system_proxy.enable_system_proxy_if_managed(
            "127.0.0.1", 9080, eager=True
        )

    msg = str(exc_info.value)
    # First failure aborts: must reference the first iface (Wi-Fi).
    assert "Wi-Fi" in msg
    assert "-setsecurewebproxy" in msg
    assert "requires admin" in msg


def test_enable_eager_raises_on_state_toggle_failure(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Address already correct, state-toggle returns non-zero → eager
    mode raises rather than continuing through the rest of the matrix."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (True, "127.0.0.1", "9080")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        if argv[1] in ("-setsecurewebproxystate", "-setwebproxystate"):
            return subprocess.CompletedProcess(
                argv, 1, stdout=b"", stderr=b"toggle blew up"
            )
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with pytest.raises(RuntimeError) as exc_info:
        system_proxy.enable_system_proxy_if_managed(
            "127.0.0.1", 9080, eager=True
        )

    msg = str(exc_info.value)
    assert "Wi-Fi" in msg
    assert "-setsecurewebproxystate" in msg
    assert "toggle blew up" in msg


def test_enable_eager_no_raise_when_address_already_correct_and_state_succeeds(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The no-admin success path: address is correct, state-toggle
    succeeds, eager flag does not change behaviour vs the default mode."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (True, "127.0.0.1", "9080")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    # Should not raise.
    system_proxy.enable_system_proxy_if_managed(
        "127.0.0.1", 9080, eager=True
    )

    # No -setsecurewebproxy / -setwebproxy calls (those need admin).
    address_set_calls = [
        c for c in calls if c[1] in ("-setsecurewebproxy", "-setwebproxy")
    ]
    assert address_set_calls == []
    state_calls = [
        c for c in calls if c[1] in ("-setsecurewebproxystate", "-setwebproxystate")
    ]
    assert len(state_calls) == 8


def test_enable_default_swallows_when_eager_false(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Same scenario as ``test_enable_eager_raises_on_set_address_failure``
    but with the default ``eager=False``: must not raise; must emit the
    structured warning."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")

    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()

    def fake_read(_iface: str, secure: bool) -> tuple[bool, str | None, str | None]:
        return (False, "10.0.0.1", "1234")

    monkeypatch.setattr(system_proxy, "_read_macos_proxy", fake_read)

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        if argv[1] in ("-setsecurewebproxy", "-setwebproxy"):
            return subprocess.CompletedProcess(
                argv, 1, stdout=b"", stderr=b"requires admin"
            )
        return subprocess.CompletedProcess(argv, 0, stdout=b"", stderr=b"")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with capture_logs() as logs:
        # Default: must not raise.
        system_proxy.enable_system_proxy_if_managed("127.0.0.1", 9080)

    warning_events = [
        rec for rec in logs if rec.get("event") == "system_proxy.set_address_failed"
    ]
    assert len(warning_events) >= 1


# --------------------------------------------------------------------------- #
# run_with_admin (Phase 2B.7)                                                  #
# --------------------------------------------------------------------------- #


def test_run_with_admin_builds_correct_osascript(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The osascript wrapper must pass a single ``-e`` argument with the
    inner command embedded inside ``do shell script "..." with prompt
    "..." with administrator privileges``."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    seen: dict[str, Any] = {}

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        seen["argv"] = list(argv)
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    system_proxy.run_with_admin(
        ["networksetup", "-setsecurewebproxy", "Wi-Fi", "127.0.0.1", "9080"],
        prompt_reason="halton-meter wants to configure the system proxy",
    )

    argv = seen["argv"]
    assert argv[0] == "osascript"
    assert argv[1] == "-e"
    script = argv[2]
    assert "do shell script" in script
    assert "with administrator privileges" in script
    # Inner command appears, shell-quoted.
    assert "networksetup" in script
    assert "-setsecurewebproxy" in script
    assert "Wi-Fi" in script
    assert "127.0.0.1" in script
    # Prompt appears.
    assert "halton-meter wants to configure the system proxy" in script


def test_run_with_admin_handles_user_cancel(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_run(_argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(
            _argv,
            1,
            stdout="",
            stderr="-128:1:1: execution error: User canceled. (-128)",
        )

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with pytest.raises(RuntimeError) as exc_info:
        system_proxy.run_with_admin(
            ["echo", "hi"], prompt_reason="test"
        )

    assert "cancel" in str(exc_info.value).lower()


def test_run_with_admin_quotes_argv_correctly(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Argv elements with spaces and quotes must be properly escaped."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    seen: dict[str, Any] = {}

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        seen["argv"] = list(argv)
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    system_proxy.run_with_admin(
        ["echo", "hello world", 'has"quote'],
        prompt_reason="test",
    )

    script = seen["argv"][2]
    # The inner command must contain the original tokens. shlex.quote
    # uses single-quotes for tokens containing whitespace.
    assert "'hello world'" in script
    # The double-quote in argv must survive — either single-quoted by
    # shlex (preferred) or backslash-escaped in the AppleScript layer.
    assert 'has"quote' in script or 'has\\"quote' in script


def test_run_with_admin_non_macos_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")
    with pytest.raises(NotImplementedError):
        system_proxy.run_with_admin(["echo", "hi"], prompt_reason="test")


def test_run_with_admin_other_failure_raises_runtime_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_run(_argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(
            _argv, 2, stdout="", stderr="osascript exploded"
        )

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with pytest.raises(RuntimeError) as exc_info:
        system_proxy.run_with_admin(["echo", "hi"], prompt_reason="test")

    assert "osascript" in str(exc_info.value)
    assert "exploded" in str(exc_info.value)


def test_run_with_admin_user_cancel_raises_admin_cancelled_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.5 (2B.16) P1-AUDIT-4: user-cancel surfaces a typed
    AdminCancelledError so callers can distinguish without grepping
    error message text."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_run(_argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(
            _argv, 1,
            stdout="",
            stderr="-128:1:1: execution error: User canceled. (-128)",
        )

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)
    with pytest.raises(system_proxy.AdminCancelledError):
        system_proxy.run_with_admin(["echo", "hi"], prompt_reason="test")


def test_run_with_admin_inner_failure_raises_admin_inner_command_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.5 (2B.16) P1-AUDIT-4: wrapped command non-zero rc surfaces a
    typed AdminInnerCommandError carrying ``returncode`` + ``stderr``."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_run(_argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(
            _argv, 7, stdout="", stderr="some inner failure"
        )

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)
    with pytest.raises(system_proxy.AdminInnerCommandError) as exc_info:
        system_proxy.run_with_admin(["echo", "hi"], prompt_reason="test")
    assert exc_info.value.returncode == 7
    assert "some inner failure" in exc_info.value.stderr


def test_run_with_admin_missing_osascript_raises_admin_infrastructure_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.5 (2B.16) P1-AUDIT-4: a missing osascript binary surfaces a
    typed AdminInfrastructureError (not the generic RuntimeError)."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_run(*_a: Any, **_kw: Any) -> Any:
        raise FileNotFoundError("osascript not found")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)
    with pytest.raises(system_proxy.AdminInfrastructureError):
        system_proxy.run_with_admin(["echo", "hi"], prompt_reason="test")


def test_admin_elevation_errors_subclass_runtime_error() -> None:
    """v0.1.5 (2B.16) P1-AUDIT-4: back-compat — every typed elevation
    error MUST subclass RuntimeError so v0.1.4-era ``except
    RuntimeError`` blocks continue to catch the union."""
    assert issubclass(system_proxy.AdminCancelledError, RuntimeError)
    assert issubclass(system_proxy.AdminInnerCommandError, RuntimeError)
    assert issubclass(system_proxy.AdminInfrastructureError, RuntimeError)
    assert issubclass(system_proxy.AdminElevationError, RuntimeError)
    assert issubclass(
        system_proxy.AdminCancelledError, system_proxy.AdminElevationError
    )
    assert issubclass(
        system_proxy.AdminInnerCommandError, system_proxy.AdminElevationError
    )


# --------------------------------------------------------------------------- #
# reset_proxy_minimal — Q1 layer-4 (2B.10)                                     #
# --------------------------------------------------------------------------- #


def test_reset_proxy_minimal_macos_runs_networksetup_for_all_interfaces(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """On macOS we shell out to ``networksetup`` once per (iface, variant) pair."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")
    # Preset the dynamic-enumeration cache so we exercise the original
    # 4-interface fallback without an extra ``-listallnetworkservices``
    # call inflating the assertion count.
    monkeypatch.setattr(
        system_proxy, "_MACOS_INTERFACES_CACHE", system_proxy._MACOS_INTERFACE_FALLBACK
    )

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    rc = system_proxy.reset_proxy_minimal()
    assert rc == 0

    # 4 ifaces x 2 variants = 8 calls; both flags appear; both Wi-Fi and
    # Ethernet appear; every call ends in ``off``.
    assert len(calls) == 8
    flags = {argv[1] for argv in calls}
    assert flags == {"-setsecurewebproxystate", "-setwebproxystate"}
    ifaces_seen = {argv[2] for argv in calls}
    assert "Wi-Fi" in ifaces_seen
    assert "Ethernet" in ifaces_seen
    for argv in calls:
        assert argv[0] == "networksetup"
        assert argv[-1] == "off"


def test_reset_proxy_minimal_macos_no_networksetup_is_no_op(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: None)

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    rc = system_proxy.reset_proxy_minimal()
    assert rc == 0
    assert calls == []


def test_reset_proxy_minimal_linux_returns_zero_no_subprocess(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    rc = system_proxy.reset_proxy_minimal()
    assert rc == 0
    # Linux path is a documented no-op; must NOT shell out.
    assert calls == []


def test_reset_proxy_minimal_windows_returns_zero(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "win32")

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    rc = system_proxy.reset_proxy_minimal()
    assert rc == 0
    assert calls == []


def test_reset_proxy_minimal_does_not_load_config(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Acceptance criterion #5: works even with no config.toml."""
    # Fresh tmp_path home means ~/.halton-meter/config.toml does not
    # exist. The function must not raise / must not call load_config.
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")
    monkeypatch.setattr(
        system_proxy.subprocess,
        "run",
        lambda argv, *a, **kw: subprocess.CompletedProcess(argv, 0, stdout="", stderr=""),
    )

    # Belt-and-braces: prove it doesn't even import config. If a future
    # refactor accidentally pulls config into the call path this assertion
    # would fail because load_config raises on a missing file.
    assert not (fake_home / ".halton-meter" / "config.toml").exists()
    rc = system_proxy.reset_proxy_minimal()
    assert rc == 0


def test_reset_proxy_minimal_is_idempotent(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Acceptance criterion #6: running twice produces no errors."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")
    monkeypatch.setattr(
        system_proxy.subprocess,
        "run",
        lambda argv, *a, **kw: subprocess.CompletedProcess(argv, 0, stdout="", stderr=""),
    )

    assert system_proxy.reset_proxy_minimal() == 0
    assert system_proxy.reset_proxy_minimal() == 0


def test_reset_proxy_minimal_ignores_sentinel(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Sentinel-blind: present sentinel does not change behaviour, absent does not skip work."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")
    # Preset cache to avoid the dynamic-enumeration call inflating count.
    monkeypatch.setattr(
        system_proxy, "_MACOS_INTERFACES_CACHE", system_proxy._MACOS_INTERFACE_FALLBACK
    )

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    # Without sentinel:
    n_without = len(calls)
    system_proxy.reset_proxy_minimal()
    n_after_without = len(calls)

    # Now create the sentinel and run again; call count must increase by
    # the same amount (i.e. the sentinel does not gate the function).
    sentinel = fake_home / ".halton-meter" / "proxy-managed"
    sentinel.parent.mkdir(parents=True, exist_ok=True)
    sentinel.touch()
    system_proxy.reset_proxy_minimal()
    n_after_with = len(calls)

    assert n_after_without - n_without == 8
    assert n_after_with - n_after_without == 8


# --------------------------------------------------------------------------- #
# _macos_interfaces — dynamic enumeration via networksetup (2B.7.2)           #
# --------------------------------------------------------------------------- #


def test_macos_interfaces_parses_well_formed_output(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression test for Vikrant's Mac (2B.7.2): no "Ethernet" service.

    A modern MacBook over Thunderbolt enumerates only Wi-Fi, Thunderbolt
    Bridge, iPhone USB. The hardcoded tuple's "Ethernet" entry was the
    direct cause of the rc=4 failure that 2B.7.1 widened to but could
    not rescue.
    """
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    stdout = (
        "An asterisk (*) denotes that a network service is disabled.\n"
        "Wi-Fi\n"
        "Thunderbolt Bridge\n"
        "iPhone USB\n"
    )

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        assert argv == ["networksetup", "-listallnetworkservices"]
        return subprocess.CompletedProcess(argv, 0, stdout=stdout, stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    assert system_proxy._macos_interfaces() == (
        "Wi-Fi",
        "Thunderbolt Bridge",
        "iPhone USB",
    )


def test_macos_interfaces_strips_asterisk_from_disabled_services(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Disabled services are real services prefixed with ``*``.

    ``networksetup -setsecurewebproxy`` works on disabled services too,
    so we strip the asterisk and include them — matches scrub.sh.
    """
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    stdout = (
        "An asterisk (*) denotes that a network service is disabled.\n"
        "Wi-Fi\n"
        "*Thunderbolt Bridge\n"
        "iPhone USB\n"
    )

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(argv, 0, stdout=stdout, stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    assert system_proxy._macos_interfaces() == (
        "Wi-Fi",
        "Thunderbolt Bridge",
        "iPhone USB",
    )


def test_macos_interfaces_falls_back_when_subprocess_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_run(*_a: Any, **_kw: Any) -> Any:
        raise FileNotFoundError("networksetup")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with capture_logs() as logs:
        result = system_proxy._macos_interfaces()

    assert result == system_proxy._MACOS_INTERFACE_FALLBACK
    assert any(
        log.get("event") == "system_proxy.interface_enumeration_failed"
        for log in logs
    ), f"missing warning event; logs={logs}"


def test_macos_interfaces_falls_back_when_subprocess_returns_nonzero(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(
            argv, 1, stdout="", stderr="something went wrong"
        )

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with capture_logs() as logs:
        result = system_proxy._macos_interfaces()

    assert result == system_proxy._MACOS_INTERFACE_FALLBACK
    matching = [
        log for log in logs
        if log.get("event") == "system_proxy.interface_enumeration_failed"
    ]
    assert matching, f"missing warning event; logs={logs}"
    assert matching[0].get("returncode") == 1
    assert "something went wrong" in matching[0].get("stderr", "")


def test_macos_interfaces_returns_empty_on_linux(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Linux has no networksetup; the function never shells out."""
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")

    def fake_run(*_a: Any, **_kw: Any) -> Any:  # pragma: no cover - must not run
        raise AssertionError("subprocess.run should not be called on Linux")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    assert system_proxy._macos_interfaces() == ()


# --------------------------------------------------------------------------- #
# Snapshot / restore (2B.11)                                                   #
# --------------------------------------------------------------------------- #


def _make_fake_networksetup(
    iface_state: dict[str, dict[str, Any]],
) -> Any:
    """Return a ``subprocess.run`` stand-in driven by ``iface_state``.

    ``iface_state`` maps iface -> {
        "web_enabled": bool, "web_host": str|None, "web_port": str|None,
        "secure_enabled": bool, "secure_host": str|None, "secure_port": str|None,
        "bypass": list[str],
    }
    """

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        if argv[:2] == ["networksetup", "-listallnetworkservices"]:
            stdout = "An asterisk (*) denotes that a network service is disabled.\n" + "\n".join(
                iface_state.keys()
            )
            return subprocess.CompletedProcess(argv, 0, stdout=stdout, stderr="")
        if len(argv) >= 3 and argv[0] == "networksetup":
            flag = argv[1]
            iface = argv[2]
            state = iface_state.get(iface, {})
            if flag == "-getwebproxy":
                enabled = "Yes" if state.get("web_enabled") else "No"
                host = state.get("web_host") or ""
                port = state.get("web_port") or ""
                stdout = f"Enabled: {enabled}\nServer: {host}\nPort: {port}\n"
                return subprocess.CompletedProcess(argv, 0, stdout=stdout, stderr="")
            if flag == "-getsecurewebproxy":
                enabled = "Yes" if state.get("secure_enabled") else "No"
                host = state.get("secure_host") or ""
                port = state.get("secure_port") or ""
                stdout = f"Enabled: {enabled}\nServer: {host}\nPort: {port}\n"
                return subprocess.CompletedProcess(argv, 0, stdout=stdout, stderr="")
            if flag == "-getproxybypassdomains":
                bypass = state.get("bypass") or []
                stdout = (
                    "\n".join(bypass)
                    if bypass
                    else f"There aren't any bypass domains set on {iface}."
                )
                return subprocess.CompletedProcess(argv, 0, stdout=stdout, stderr="")
        # Mutating commands: just succeed.
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    return fake_run


def test_snapshot_captures_per_service_state(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    monkeypatch.setattr(
        system_proxy, "_SYSTEM_STATE_PATH", fake_home / ".halton-meter" / "system_state.json"
    )

    iface_state: dict[str, dict[str, Any]] = {
        "Wi-Fi": {
            "web_enabled": True,
            "web_host": "proxy.example.com",
            "web_port": "8888",
            "secure_enabled": True,
            "secure_host": "proxy.example.com",
            "secure_port": "8888",
            "bypass": ["*.local", "169.254/16"],
        },
        "Thunderbolt Bridge": {
            "web_enabled": False,
            "secure_enabled": False,
            "secure_host": None,
            "secure_port": None,
            "bypass": [],
        },
    }
    monkeypatch.setattr(
        system_proxy.subprocess, "run", _make_fake_networksetup(iface_state)
    )

    system_proxy.snapshot_system_proxy()

    state_path = fake_home / ".halton-meter" / "system_state.json"
    assert state_path.exists()
    payload = json.loads(state_path.read_text())
    assert payload["version"] == 1
    assert payload["platform"] == "darwin"
    assert set(payload["services"].keys()) == {"Wi-Fi", "Thunderbolt Bridge"}
    wifi = payload["services"]["Wi-Fi"]
    assert wifi["web_proxy_enabled"] is True
    assert wifi["secure_web_proxy_enabled"] is True
    assert wifi["host"] == "proxy.example.com"
    assert wifi["port"] == "8888"
    assert wifi["bypass_domains"] == ["*.local", "169.254/16"]
    tb = payload["services"]["Thunderbolt Bridge"]
    assert tb["web_proxy_enabled"] is False
    assert tb["secure_web_proxy_enabled"] is False
    assert tb["bypass_domains"] == []


def test_snapshot_skipped_when_file_already_exists(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    state_path = fake_home / ".halton-meter" / "system_state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    sentinel_payload = '{"version": 1, "platform": "darwin", "services": {}}'
    state_path.write_text(sentinel_payload)
    monkeypatch.setattr(system_proxy, "_SYSTEM_STATE_PATH", state_path)

    def must_not_run(*_a: Any, **_kw: Any) -> Any:  # pragma: no cover
        raise AssertionError("subprocess.run must not be called when state exists")

    monkeypatch.setattr(system_proxy.subprocess, "run", must_not_run)

    system_proxy.snapshot_system_proxy()

    # Untouched.
    assert state_path.read_text() == sentinel_payload


def test_snapshot_silent_no_op_on_linux(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")
    monkeypatch.setattr(
        system_proxy, "_SYSTEM_STATE_PATH", fake_home / ".halton-meter" / "system_state.json"
    )

    def must_not_run(*_a: Any, **_kw: Any) -> Any:  # pragma: no cover
        raise AssertionError("subprocess.run must not be called on Linux")

    monkeypatch.setattr(system_proxy.subprocess, "run", must_not_run)

    system_proxy.snapshot_system_proxy()
    assert not (fake_home / ".halton-meter" / "system_state.json").exists()


def test_atomic_write_uses_rename_and_mode_0600(
    fake_home: Path,
) -> None:
    target = fake_home / "halton" / "system_state.json"
    system_proxy._atomic_write_json(target, {"version": 1, "x": 42})
    assert target.exists()
    parsed = json.loads(target.read_text())
    assert parsed["x"] == 42
    # Mode 0600.
    mode = target.stat().st_mode & 0o777
    assert mode == 0o600


def test_restore_applies_captured_state(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    state_path = fake_home / ".halton-meter" / "system_state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        json.dumps(
            {
                "version": 1,
                "platform": "darwin",
                "services": {
                    "Wi-Fi": {
                        "web_proxy_enabled": True,
                        "secure_web_proxy_enabled": True,
                        "host": "proxy.example.com",
                        "port": "8888",
                        "bypass_domains": ["*.local"],
                    }
                },
            }
        )
    )
    monkeypatch.setattr(system_proxy, "_SYSTEM_STATE_PATH", state_path)

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    result = system_proxy.restore_system_proxy("127.0.0.1", 8080)
    assert result is True

    # The captured proxy.example.com:8888 does NOT match our daemon at
    # 127.0.0.1:8080, so we restore it (set address + bypass + state on).
    set_secure = [c for c in calls if c[:2] == ["networksetup", "-setsecurewebproxy"]]
    set_web = [c for c in calls if c[:2] == ["networksetup", "-setwebproxy"]]
    set_bypass = [c for c in calls if c[:2] == ["networksetup", "-setproxybypassdomains"]]
    assert any(c[3] == "proxy.example.com" and c[4] == "8888" for c in set_secure)
    assert any(c[3] == "proxy.example.com" and c[4] == "8888" for c in set_web)
    assert any("*.local" in c for c in set_bypass)

    # State file is removed after a successful restore.
    assert not state_path.exists()


def test_restore_self_guards_when_captured_targets_us(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the captured host:port matches our daemon listener we DISABLE the
    service rather than restore — never re-point the user at a dead proxy."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    state_path = fake_home / ".halton-meter" / "system_state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        json.dumps(
            {
                "version": 1,
                "platform": "darwin",
                "services": {
                    "Wi-Fi": {
                        "web_proxy_enabled": True,
                        "secure_web_proxy_enabled": True,
                        "host": "127.0.0.1",
                        "port": "8080",
                        "bypass_domains": [],
                    }
                },
            }
        )
    )
    monkeypatch.setattr(system_proxy, "_SYSTEM_STATE_PATH", state_path)

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    with capture_logs() as logs:
        result = system_proxy.restore_system_proxy("127.0.0.1", 8080)
    assert result is True

    # Self-guard disable: no -setsecurewebproxy / -setwebproxy address-set,
    # only the disable pair.
    address_sets = [
        c for c in calls
        if c[:2] in (["networksetup", "-setsecurewebproxy"], ["networksetup", "-setwebproxy"])
    ]
    assert address_sets == [], f"self-guard must skip address-set; got {address_sets}"
    state_offs = [
        c for c in calls
        if len(c) >= 4 and c[0] == "networksetup"
        and c[1] in ("-setsecurewebproxystate", "-setwebproxystate")
        and c[3] == "off"
    ]
    assert len(state_offs) >= 2, f"self-guard must disable; got {state_offs}"

    self_guard_logs = [
        log for log in logs
        if log.get("event") == "system_proxy.restore_self_guard_disabled"
    ]
    assert self_guard_logs, f"self-guard event missing; logs={logs}"
    assert not state_path.exists()


def test_restore_returns_false_when_no_snapshot(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    monkeypatch.setattr(
        system_proxy, "_SYSTEM_STATE_PATH", fake_home / ".halton-meter" / "system_state.json"
    )
    assert system_proxy.restore_system_proxy("127.0.0.1", 8080) is False


# --------------------------------------------------------------------------- #
# 2B.11.1 — discard stale host:port when service was already disabled         #
# --------------------------------------------------------------------------- #


def test_snapshot_discards_stale_host_port_when_secure_disabled(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``networksetup -setsecurewebproxystate <iface> off`` does not clear
    the stored host/port — only the enabled bit. So ``_read_macos_proxy``
    on a disabled service can still return stale leftovers (often pointing
    at our daemon from a prior session). The snapshot must treat
    ``secure_enabled=False`` as ``no prior config`` and store empty
    host/port, so a future restore doesn't re-point the user at the stale
    target. Regression for 2B.11.1.
    """
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    monkeypatch.setattr(
        system_proxy, "_SYSTEM_STATE_PATH", fake_home / ".halton-meter" / "system_state.json"
    )

    # Simulate the exact bug shape observed on hardware 2026-04-30: every
    # service is disabled, but networksetup still echoes back a stale
    # 127.0.0.1:8080 (our own daemon's listener from a prior session).
    iface_state: dict[str, dict[str, Any]] = {
        "Wi-Fi": {
            "web_enabled": False,
            "web_host": "127.0.0.1",
            "web_port": "8080",
            "secure_enabled": False,
            "secure_host": "127.0.0.1",
            "secure_port": "8080",
            "bypass": [],
        },
    }
    monkeypatch.setattr(
        system_proxy.subprocess, "run", _make_fake_networksetup(iface_state)
    )

    system_proxy.snapshot_system_proxy()

    state_path = fake_home / ".halton-meter" / "system_state.json"
    payload = json.loads(state_path.read_text())
    wifi = payload["services"]["Wi-Fi"]
    assert wifi["secure_web_proxy_enabled"] is False
    # The fix: empty host/port instead of the stale 127.0.0.1:8080.
    assert wifi["host"] == ""
    assert wifi["port"] == ""


def test_snapshot_preserves_corp_proxy_when_enabled(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Counterpoint to the discard-when-disabled test: when the service is
    actually enabled (e.g. a corp proxy at corp.example.com:8080), the
    snapshot must capture the real host/port so uninstall can restore it.
    Regression test for the load-bearing user scenario behind 2B.11.1.
    """
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    monkeypatch.setattr(
        system_proxy, "_SYSTEM_STATE_PATH", fake_home / ".halton-meter" / "system_state.json"
    )

    iface_state: dict[str, dict[str, Any]] = {
        "Wi-Fi": {
            "web_enabled": True,
            "web_host": "corp.example.com",
            "web_port": "8080",
            "secure_enabled": True,
            "secure_host": "corp.example.com",
            "secure_port": "8080",
            "bypass": ["*.corp.example.com"],
        },
    }
    monkeypatch.setattr(
        system_proxy.subprocess, "run", _make_fake_networksetup(iface_state)
    )

    system_proxy.snapshot_system_proxy()

    payload = json.loads(
        (fake_home / ".halton-meter" / "system_state.json").read_text()
    )
    wifi = payload["services"]["Wi-Fi"]
    assert wifi["secure_web_proxy_enabled"] is True
    assert wifi["host"] == "corp.example.com"
    assert wifi["port"] == "8080"
    assert wifi["bypass_domains"] == ["*.corp.example.com"]


def test_restore_skips_address_set_when_captured_host_empty(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An empty captured host:port means ``no prior config`` (the service
    was disabled at snapshot time). Restore must NOT shell out to
    ``networksetup -setsecurewebproxy`` / ``-setwebproxy`` for that
    service — there's nothing to restore — and must leave the service in
    its captured (disabled) state. Companion to the discard-stale test.
    """
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    state_path = fake_home / ".halton-meter" / "system_state.json"
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        json.dumps(
            {
                "version": 1,
                "platform": "darwin",
                "services": {
                    "Wi-Fi": {
                        "web_proxy_enabled": False,
                        "secure_web_proxy_enabled": False,
                        "host": "",
                        "port": "",
                        "bypass_domains": [],
                    }
                },
            }
        )
    )
    monkeypatch.setattr(system_proxy, "_SYSTEM_STATE_PATH", state_path)

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    result = system_proxy.restore_system_proxy("127.0.0.1", 8080)
    assert result is True

    # No address-set calls — nothing to restore.
    address_sets = [
        c for c in calls
        if c[:2] in (
            ["networksetup", "-setsecurewebproxy"],
            ["networksetup", "-setwebproxy"],
        )
    ]
    assert address_sets == [], f"empty captured host must skip address-set; got {address_sets}"

    # State toggle proceeds (captured False -> apply ``off``).
    state_offs = [
        c for c in calls
        if len(c) >= 4 and c[0] == "networksetup"
        and c[1] in ("-setsecurewebproxystate", "-setwebproxystate")
        and c[3] == "off"
    ]
    assert len(state_offs) == 2, f"both state toggles must apply off; got {state_offs}"

    # Snapshot file removed after a successful pass.
    assert not state_path.exists()


# --------------------------------------------------------------------------- #
# v0.1.20.1: install_proxy_cleanup MUST NOT install synchronous signal         #
# handlers — that race vs. uvicorn's capture_signals re-raise was the          #
# cold-boot zombie root cause. Signal ownership lives in the asyncio runner    #
# in cli._run_daemon.                                                          #
# --------------------------------------------------------------------------- #


def test_install_proxy_cleanup_does_not_install_signal_handlers(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.20.1: ``install_proxy_cleanup`` must register only ``atexit``.

    The previous implementation installed a synchronous
    ``signal.signal(SIGTERM, _chained)`` handler that called
    ``sys.exit(0)`` from within a running asyncio loop. uvicorn's
    ``capture_signals`` ``__exit__`` re-raised the captured signal mid-
    way through ``asyncio.runners._cancel_all_tasks``; the bare
    ``sys.exit`` bailed cleanup with sockets half-closed. Witnessed in
    ``daemon.err.log`` lines 3526-3599 on 2026-05-04 (v0.1.20).

    Asyncio-native handlers now live in ``cli._run_daemon`` via
    ``loop.add_signal_handler``. This module owns only the atexit
    fallback for hard exits.
    """
    import signal as _signal

    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup")
    monkeypatch.setattr(system_proxy, "_macos_interfaces", lambda: ["Wi-Fi"])
    monkeypatch.setattr(
        system_proxy,
        "_read_macos_proxy",
        lambda iface, secure: (True, "127.0.0.1", 8080),
    )

    disabled: list[str] = []
    monkeypatch.setattr(
        system_proxy,
        "_disable_macos_proxy",
        lambda iface: disabled.append(iface),
    )

    # Spy on signal.signal at the module level (we do NOT import it in
    # system_proxy any more; spy on the global module).
    sig_calls: list[tuple[int, object]] = []

    def _spy(sig: int, handler: object) -> object:
        sig_calls.append((sig, handler))
        return _signal.SIG_DFL

    monkeypatch.setattr(_signal, "signal", _spy)

    atexit_calls: list[object] = []
    monkeypatch.setattr(
        system_proxy.atexit,
        "register",
        lambda fn: atexit_calls.append(fn) or fn,
    )

    cleanup = system_proxy.install_proxy_cleanup("127.0.0.1", 8080)
    assert cleanup is not None
    assert sig_calls == [], (
        "install_proxy_cleanup must NOT install signal handlers — that "
        "races uvicorn's capture_signals re-raise during loop teardown"
    )
    assert len(atexit_calls) == 1, "atexit fallback is the only handler we own"

    # The cleanup callable still does the right thing when invoked.
    cleanup()
    assert disabled == ["Wi-Fi"]


# --------------------------------------------------------------------------- #
# v0.1.3 P0-3 — launchctl setenv / unsetenv user-domain                        #
# --------------------------------------------------------------------------- #


class TestSetenvUserDomain:
    def test_calls_launchctl_setenv_for_each_var(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
        monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/bin/launchctl")
        calls: list[list[str]] = []

        def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
            calls.append(list(argv))
            return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

        monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

        env_vars = {
            "HTTPS_PROXY": "http://127.0.0.1:8080",
            "HTTP_PROXY": "http://127.0.0.1:8080",
        }
        rcs = system_proxy.setenv_user_domain(env_vars)

        # Two calls, both rc=0.
        assert len(calls) == 2
        assert all(rc == 0 for rc in rcs.values())
        # Each call is launchctl setenv KEY VALUE.
        for argv in calls:
            assert argv[:2] == ["launchctl", "setenv"]
            assert argv[2] in env_vars
            assert argv[3] == env_vars[argv[2]]

    def test_no_op_on_non_macos(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "linux")
        rcs = system_proxy.setenv_user_domain({"HTTPS_PROXY": "http://x:1"})
        assert rcs == {}

    def test_no_op_when_launchctl_missing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
        monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: None)
        rcs = system_proxy.setenv_user_domain({"HTTPS_PROXY": "http://x:1"})
        assert rcs == {}

    def test_records_failure_rcs(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
        monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/bin/launchctl")

        def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
            return subprocess.CompletedProcess(argv, 1, stdout="", stderr="permission")

        monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)
        rcs = system_proxy.setenv_user_domain({"HTTPS_PROXY": "http://x:1"})
        assert rcs == {"HTTPS_PROXY": 1}

    def test_records_minus_one_on_subprocess_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
        monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/bin/launchctl")
        monkeypatch.setattr(
            system_proxy.subprocess, "run",
            lambda *_a, **_kw: (_ for _ in ()).throw(OSError("boom")),
        )
        rcs = system_proxy.setenv_user_domain({"HTTPS_PROXY": "http://x:1"})
        assert rcs == {"HTTPS_PROXY": -1}


class TestUnsetenvUserDomain:
    def test_calls_launchctl_unsetenv_for_each_key(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
        monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/bin/launchctl")
        calls: list[list[str]] = []
        monkeypatch.setattr(
            system_proxy.subprocess, "run",
            lambda argv, *_a, **_kw: (
                calls.append(list(argv))
                or subprocess.CompletedProcess(argv, 0, stdout="", stderr="")
            ),
        )

        rcs = system_proxy.unsetenv_user_domain(
            ["HTTPS_PROXY", "HTTP_PROXY"]
        )
        assert len(calls) == 2
        assert all(rc == 0 for rc in rcs.values())
        for argv in calls:
            assert argv[:2] == ["launchctl", "unsetenv"]

    def test_no_op_on_non_macos(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "linux")
        rcs = system_proxy.unsetenv_user_domain(["HTTPS_PROXY"])
        assert rcs == {}


class TestGetenvUserDomain:
    def test_returns_value_on_success(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
        monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/bin/launchctl")
        monkeypatch.setattr(
            system_proxy.subprocess, "run",
            lambda *_a, **_kw: subprocess.CompletedProcess(
                _a[0], 0, stdout="http://127.0.0.1:8080\n", stderr=""
            ),
        )
        assert system_proxy.getenv_user_domain("HTTPS_PROXY") == "http://127.0.0.1:8080"

    def test_returns_none_when_unset(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
        monkeypatch.setattr(system_proxy.shutil, "which", lambda _name: "/bin/launchctl")
        monkeypatch.setattr(
            system_proxy.subprocess, "run",
            lambda *_a, **_kw: subprocess.CompletedProcess(
                _a[0], 0, stdout="\n", stderr=""
            ),
        )
        assert system_proxy.getenv_user_domain("HTTPS_PROXY") is None

    def test_returns_none_on_non_macos(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(system_proxy.sys, "platform", "linux")
        assert system_proxy.getenv_user_domain("HTTPS_PROXY") is None


# --------------------------------------------------------------------------- #
# v0.1.7 Gap 1: 60s TTL on the macOS interface enumeration cache              #
# --------------------------------------------------------------------------- #


class TestMacosInterfacesTTL:
    """Pre-Gap-1 the cache was process-lifetime, so a long-running
    daemon never picked up newly-attached interfaces (Thunderbolt
    plug-in, Wi-Fi switch). The TTL fixes that without us having to
    pull in PyObjC for SCDynamicStore notifications."""

    def test_cache_serves_within_ttl(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Within the 60s TTL window, repeat callers do NOT re-probe
        ``networksetup``."""
        calls = {"n": 0}

        def fake_uncached() -> tuple[str, ...]:
            calls["n"] += 1
            return ("Wi-Fi",)

        clock = {"t": 1000.0}
        monkeypatch.setattr(system_proxy, "_macos_interfaces_uncached", fake_uncached)
        monkeypatch.setattr(system_proxy.time, "monotonic", lambda: clock["t"])

        assert system_proxy._macos_interfaces() == ("Wi-Fi",)
        assert calls["n"] == 1

        clock["t"] = 1059.0  # 59s later — still within TTL
        assert system_proxy._macos_interfaces() == ("Wi-Fi",)
        assert calls["n"] == 1, "should not re-probe within TTL"

    def test_cache_refreshes_after_ttl(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Past the 60s TTL the cache re-probes and picks up changes —
        e.g. a Thunderbolt dock attached after process start."""
        results = [("Wi-Fi",), ("Wi-Fi", "Thunderbolt Bridge")]
        idx = {"i": 0}

        def fake_uncached() -> tuple[str, ...]:
            value = results[idx["i"]]
            idx["i"] = min(idx["i"] + 1, len(results) - 1)
            return value

        clock = {"t": 1000.0}
        monkeypatch.setattr(system_proxy, "_macos_interfaces_uncached", fake_uncached)
        monkeypatch.setattr(system_proxy.time, "monotonic", lambda: clock["t"])

        assert system_proxy._macos_interfaces() == ("Wi-Fi",)

        clock["t"] = 1061.0  # 61s later — past TTL
        assert system_proxy._macos_interfaces() == ("Wi-Fi", "Thunderbolt Bridge")

    def test_legacy_test_seed_still_honoured(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Backward-compat: tests that monkeypatch the cache to a raw
        tuple-of-strings (pre-Gap-1 shape) still work — the getter
        treats the legacy shape as fresh forever. This protects ~12
        existing test sites from churn."""
        monkeypatch.setattr(
            system_proxy,
            "_MACOS_INTERFACES_CACHE",
            ("Legacy-Wi-Fi", "Legacy-Ethernet"),
        )
        # Even with a clock that says we're decades past any TTL.
        monkeypatch.setattr(system_proxy.time, "monotonic", lambda: 1e12)

        def boom() -> tuple[str, ...]:  # pragma: no cover - must not run
            raise AssertionError("uncached probe should not fire on legacy seed")

        monkeypatch.setattr(system_proxy, "_macos_interfaces_uncached", boom)
        assert system_proxy._macos_interfaces() == ("Legacy-Wi-Fi", "Legacy-Ethernet")

    def test_uncached_helper_has_failure_fallback(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When ``networksetup`` rc != 0, the uncached helper returns
        the static fallback and emits a warning log."""
        monkeypatch.setattr(system_proxy.sys, "platform", "darwin")

        def fake_run(_argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            return subprocess.CompletedProcess(
                ["networksetup"], 1, stdout="", stderr="boom"
            )

        monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)
        with capture_logs() as logs:
            services = system_proxy._macos_interfaces_uncached()

        assert services == system_proxy._MACOS_INTERFACE_FALLBACK
        assert any(
            log.get("event") == "system_proxy.interface_enumeration_failed"
            for log in logs
        )
