"""
Daemon-import smoke test.

Why this test exists
--------------------
Between v0.1.20 and v0.1.21.5 we burned five release cycles chasing a "cold-boot
zombie" symptom (daemon process spawned by launchd, neither :8090 nor :8765
bound, no entries in our own structlog stream). The actual root cause was a
plain ImportError at process start: ``pydantic_core`` and ``rich`` did not have
working wheels for Python 3.14 (early-access on macOS 26), so
``import halton_meter.cli`` raised before our own ``daemon.startup.phase``
instrumentation could fire. The fix that worked was pinning
``requires-python <3.14`` in pyproject.toml (v0.1.21.6).

This test guards against that whole class of failure: a dependency regression
that breaks a top-level import of one of the daemon's entry-point modules.
Runs in <5s on the standard suite — no markers, no opt-in.
"""

from __future__ import annotations

import subprocess
import sys

import pytest

# Every module that the halton-meter binary or its supervisors import at
# process start. If any of these raise during ``import``, the daemon dies
# before our instrumentation runs and the user sees a black-box failure.
DAEMON_ENTRY_MODULES = [
    "halton_meter.cli",
    "halton_meter.proxy",
    "halton_meter.lifecycle",
    "halton_meter.install",
    "halton_meter.watchdog",
    "halton_meter.run",
    "halton_meter.edge_main",
]


@pytest.mark.parametrize("module", DAEMON_ENTRY_MODULES)
def test_daemon_module_imports_cleanly(module: str) -> None:
    """Each entry-point module imports without error and emits no stderr."""
    result = subprocess.run(
        [sys.executable, "-c", f"import {module}"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    assert result.returncode == 0, (
        f"import {module} failed (rc={result.returncode}):\n"
        f"stdout={result.stdout!r}\nstderr={result.stderr!r}"
    )
    # Nothing well-behaved writes to stderr on a bare ``import`` — and the
    # specific failure modes we're guarding (ImportError, ModuleNotFoundError,
    # DLL load failure) all surface there.
    forbidden = (
        "ImportError",
        "ModuleNotFoundError",
        "DLL load failed",
        "Symbol not found",
        "Library not loaded",
        "undefined symbol",
    )
    for marker in forbidden:
        assert marker not in result.stderr, (
            f"import {module} produced suspect stderr containing {marker!r}:\n"
            f"{result.stderr}"
        )


@pytest.mark.slow
@pytest.mark.skipif(
    "HALTON_RUN_SLOW" not in __import__("os").environ,
    reason="slow integration test; set HALTON_RUN_SLOW=1 to run",
)
def test_daemon_binary_reaches_startup_phase() -> None:
    """
    End-to-end: spawn the daemon entry-point, send SIGTERM, assert we saw the
    first ``daemon.startup.phase phase=entered`` log line. Catches the case
    where the binary spawns but never reaches our code (the v0.1.20-v0.1.21.5
    failure mode).

    Gated behind ``slow`` — opt-in via ``pytest -m slow``.
    """
    import os
    import signal
    import time

    # Spawn ``python -m halton_meter.cli daemon`` so we don't depend on the
    # entry-point script being on PATH. If the ``daemon`` subcommand grows
    # required args, update accordingly.
    proc = subprocess.Popen(
        [sys.executable, "-m", "halton_meter.cli", "daemon"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, "HALTON_NO_WELCOME": "1"},
    )
    try:
        time.sleep(1.0)
        proc.send_signal(signal.SIGTERM)
        try:
            stdout, stderr = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
        combined = (stdout or b"").decode("utf-8", "replace") + (stderr or b"").decode(
            "utf-8", "replace"
        )
        assert "daemon.startup.phase" in combined and "entered" in combined, (
            f"daemon never logged startup.phase entered:\n{combined[-2000:]}"
        )
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=5)
