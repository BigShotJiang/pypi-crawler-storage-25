"""
Regression tests for v0.1.7 Gap 0 — edge re-resolves ``internal_port``
on chain failure.

Background: the v0.1.6 edge cached ``internal_port`` once at startup.
On a port-fallback race (default port busy → daemon falls back to a
neighbour and rewrites runtime.toml), the edge's chain probe to the
old port locks into ConnectionRefused, the health cache stays unhealthy,
and every subsequent request silently falls through to passthrough.
Captures vanish, status reports HEALTHY. See
``memory/plans/2026-05-01-edge-passthrough-lockin-bug.md``.

These tests would have caught that bug.
"""

from __future__ import annotations

import asyncio
import contextlib

from halton_meter.edge import EdgeConfig, EdgeProxy
from halton_meter.port_alloc import (
    _write_runtime_toml,
    read_edge_state_toml,
    write_edge_state_toml,
)
from tests.test_edge import FakeDaemon, FakeUpstream, _send_through_edge

# --------------------------------------------------------------------------- #
# Re-resolution behaviour                                                     #
# --------------------------------------------------------------------------- #


async def test_edge_re_resolves_internal_port_on_chain_failure(tmp_path) -> None:
    """The Gap 0 P0: edge picks up a new ``internal_port`` after a
    runtime.toml rewrite. Without the fix the edge stays bound to the
    old port and every chain attempt locks into ConnectionRefused.
    """
    daemon_a = FakeDaemon()
    daemon_b = FakeDaemon()
    port_a = await daemon_a.start()
    port_b = await daemon_b.start()
    runtime_path = tmp_path / "runtime.toml"
    state_path = tmp_path / "edge-state.toml"
    # Initial runtime.toml points at daemon A.
    _write_runtime_toml(
        runtime_path,
        edge_port=8081,
        internal_port=port_a,
        api_port=8765,
    )
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=port_a,
        healthy_ttl_s=0.05,
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.5,
        runtime_path=runtime_path,
        state_path=state_path,
    )
    edge = EdgeProxy(config)
    edge_port = await edge.start()
    serve_task = asyncio.create_task(edge.serve_forever())
    try:
        # Warm the cache: daemon A is healthy on port_a.
        assert await edge.health_cache.is_healthy() is True

        # Simulate the port-fallback race: daemon A dies, daemon B is
        # the new live target on a different port, runtime.toml rewritten.
        await daemon_a.stop()
        _write_runtime_toml(
            runtime_path,
            edge_port=8081,
            internal_port=port_b,
            api_port=8765,
        )

        # First request after the rewrite triggers the chain attempt.
        # v0.1.21.2: per-request reresolve runs BEFORE the chain attempt
        # so the very first request after a port change chains
        # successfully through the new target. Pre-v0.1.21.2 this
        # request fell through to passthrough and only the second
        # chained — now both chain.
        upstream = FakeUpstream()
        upstream_port = await upstream.start()
        try:
            await _send_through_edge(
                edge_port,
                f"CONNECT 127.0.0.1:{upstream_port} HTTP/1.1\r\n"
                f"Host: 127.0.0.1:{upstream_port}\r\n\r\n".encode("ascii"),
                extra_payload=b"x",
            )
        finally:
            await upstream.stop()

        assert edge._config.internal_port == port_b
        assert edge.health_cache.internal_port == port_b
        # Sidecar must reflect the new chain target.
        sidecar = read_edge_state_toml(state_path)
        assert sidecar.get("chain_port") == port_b

        # Second request must now chain through daemon B.
        response = await _send_through_edge(
            edge_port,
            b"CONNECT api.anthropic.com:443 HTTP/1.1\r\n"
            b"Host: api.anthropic.com:443\r\n\r\n",
            extra_payload=b"hi",
        )
        assert b"DAEMON_CHAINED" in response
        # v0.1.21.2: both requests chain through daemon B (the per-
        # request reresolve picks up the new port before the first
        # chain attempt). Previously the first one passthrough'd.
        assert daemon_b.connect_targets[-1] == "api.anthropic.com:443"
        assert any(
            t.startswith("127.0.0.1:")
            for t in daemon_b.connect_targets[:-1]
        )
    finally:
        await edge.stop()
        serve_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await serve_task
        await daemon_a.stop()
        await daemon_b.stop()


async def test_edge_does_not_re_resolve_when_runtime_unchanged(tmp_path) -> None:
    """When runtime.toml's internal_port matches the cached config,
    chain failure must not flip the chain target — that would cause
    flapping if the daemon restarts on the same port.
    """
    daemon = FakeDaemon()
    port = await daemon.start()
    runtime_path = tmp_path / "runtime.toml"
    state_path = tmp_path / "edge-state.toml"
    _write_runtime_toml(
        runtime_path,
        edge_port=8081,
        internal_port=port,
        api_port=8765,
    )
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=port,
        healthy_ttl_s=0.05,
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.5,
        runtime_path=runtime_path,
        state_path=state_path,
    )
    edge = EdgeProxy(config)
    edge_port = await edge.start()
    serve_task = asyncio.create_task(edge.serve_forever())
    try:
        assert await edge.health_cache.is_healthy() is True
        await daemon.stop()
        # Trigger chain failure; runtime.toml still says `port`.
        upstream = FakeUpstream()
        up_port = await upstream.start()
        try:
            await _send_through_edge(
                edge_port,
                f"CONNECT 127.0.0.1:{up_port} HTTP/1.1\r\n"
                f"Host: 127.0.0.1:{up_port}\r\n\r\n".encode("ascii"),
                extra_payload=b"x",
            )
        finally:
            await upstream.stop()

        # Re-resolve should be a no-op — port unchanged.
        assert edge._config.internal_port == port
    finally:
        await edge.stop()
        serve_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await serve_task
        await daemon.stop()


async def test_edge_re_resolve_no_op_without_runtime_path(tmp_path) -> None:
    """Without a runtime_path on the config, _maybe_reresolve_chain_target
    is a no-op. This protects existing tests that construct EdgeConfig
    with literal ports.
    """
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=12345,
        healthy_ttl_s=0.05,
        unhealthy_ttl_s=0.05,
        probe_timeout_s=0.2,
    )
    edge = EdgeProxy(config)
    assert edge._maybe_reresolve_chain_target() is False
    assert edge._config.internal_port == 12345


async def test_edge_re_resolve_handles_missing_runtime_file(tmp_path) -> None:
    runtime_path = tmp_path / "runtime.toml"  # never created
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=12345,
        runtime_path=runtime_path,
        state_path=tmp_path / "edge-state.toml",
    )
    edge = EdgeProxy(config)
    assert edge._maybe_reresolve_chain_target() is False
    assert edge._config.internal_port == 12345


async def test_edge_re_resolve_handles_corrupt_runtime_file(tmp_path) -> None:
    runtime_path = tmp_path / "runtime.toml"
    runtime_path.write_text("this is not valid toml [[[")
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=12345,
        runtime_path=runtime_path,
        state_path=tmp_path / "edge-state.toml",
    )
    edge = EdgeProxy(config)
    assert edge._maybe_reresolve_chain_target() is False
    assert edge._config.internal_port == 12345


async def test_write_initial_state_records_bound_edge_port(tmp_path) -> None:
    """After bind, the sidecar carries the actually-bound edge_port (not
    the placeholder 0 used when the kernel picks a port for tests)."""
    state_path = tmp_path / "edge-state.toml"
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,  # kernel chooses
        internal_host="127.0.0.1",
        internal_port=12345,
        runtime_path=tmp_path / "runtime.toml",
        state_path=state_path,
    )
    edge = EdgeProxy(config)
    bound_port = await edge.start()
    try:
        edge.write_initial_state(bound_edge_port=bound_port)
        sidecar = read_edge_state_toml(state_path)
        assert sidecar.get("edge_port") == bound_port
        assert sidecar.get("chain_port") == 12345
        assert isinstance(sidecar.get("pid"), int)
    finally:
        await edge.stop()


# --------------------------------------------------------------------------- #
# Sidecar helpers                                                             #
# --------------------------------------------------------------------------- #


def test_edge_state_round_trip(tmp_path) -> None:
    path = tmp_path / "edge-state.toml"
    write_edge_state_toml(path, edge_port=8082, chain_port=8090, pid=4242)
    out = read_edge_state_toml(path)
    assert out == {"edge_port": 8082, "chain_port": 8090, "pid": 4242}


def test_edge_state_read_missing_returns_empty(tmp_path) -> None:
    assert read_edge_state_toml(tmp_path / "missing.toml") == {}


def test_edge_state_read_corrupt_returns_empty(tmp_path) -> None:
    path = tmp_path / "edge-state.toml"
    path.write_text("not toml [[[\n")
    assert read_edge_state_toml(path) == {}


# --------------------------------------------------------------------------- #
# v0.1.21.2: edge prefers effective-ports.json + per-request reresolve         #
# --------------------------------------------------------------------------- #


async def test_edge_reads_effective_ports_json_in_preference_to_runtime_toml(
    tmp_path,
) -> None:
    """v0.1.21.2: ``effective-ports.json`` is the kernel-confirmed
    post-bind tuple — preferred over ``runtime.toml`` (which is
    rewritten only on port-fallback).
    """
    import json as _json

    runtime_path = tmp_path / "runtime.toml"
    eff_path = tmp_path / "effective-ports.json"
    _write_runtime_toml(
        runtime_path, edge_port=8081, internal_port=8090, api_port=8765
    )
    eff_path.write_text(
        _json.dumps(
            {
                "schema_version": 1,
                "pid": 1234,
                "bound_at": "2026-05-05T00:00:00.000Z",
                "edge_port": None,
                "internal_port": 9999,
                "api_port": 8765,
            }
        )
    )
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=8090,
        runtime_path=runtime_path,
        state_path=tmp_path / "edge-state.toml",
        effective_ports_path=eff_path,
    )
    edge = EdgeProxy(config)
    # Authoritative read should pick 9999 (from effective-ports.json),
    # not 8090 (from runtime.toml).
    assert edge._read_authoritative_internal_port() == 9999


async def test_edge_falls_back_to_runtime_toml_when_effective_ports_missing(
    tmp_path,
) -> None:
    """v0.1.21.2: when effective-ports.json doesn't exist (older
    install, fresh daemon, etc.), fall back to runtime.toml.
    """
    runtime_path = tmp_path / "runtime.toml"
    eff_path = tmp_path / "effective-ports.json"  # never created
    _write_runtime_toml(
        runtime_path, edge_port=8081, internal_port=7777, api_port=8765
    )
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=8090,
        runtime_path=runtime_path,
        state_path=tmp_path / "edge-state.toml",
        effective_ports_path=eff_path,
    )
    edge = EdgeProxy(config)
    assert edge._read_authoritative_internal_port() == 7777


async def test_edge_authoritative_port_cache_caps_fs_reads(tmp_path) -> None:
    """v0.1.21.2: 1-second TTL on the authoritative-port read so per-
    CONNECT calls don't FS-thrash effective-ports.json. Within the TTL
    window, repeated calls return the cached value even if the file
    changes underneath.
    """
    import json as _json

    eff_path = tmp_path / "effective-ports.json"
    eff_path.write_text(
        _json.dumps(
            {
                "schema_version": 1,
                "internal_port": 5555,
                "api_port": 8765,
                "edge_port": None,
            }
        )
    )
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=8090,
        effective_ports_path=eff_path,
    )
    edge = EdgeProxy(config)
    assert edge._read_authoritative_internal_port() == 5555
    # Mutate the file. Within the 1s TTL, the cache must be served.
    eff_path.write_text(
        _json.dumps(
            {
                "schema_version": 1,
                "internal_port": 6666,
                "api_port": 8765,
                "edge_port": None,
            }
        )
    )
    assert edge._read_authoritative_internal_port() == 5555
    # Force-expire the cache.
    edge._auth_port_cache_expires_at = 0.0
    assert edge._read_authoritative_internal_port() == 6666


def test_edge_state_atomic_replace(tmp_path) -> None:
    """Repeated writes overwrite atomically — no .tmp leftover."""
    path = tmp_path / "edge-state.toml"
    write_edge_state_toml(path, edge_port=8082, chain_port=8090, pid=1)
    write_edge_state_toml(path, edge_port=8082, chain_port=8091, pid=2)
    assert read_edge_state_toml(path) == {
        "edge_port": 8082,
        "chain_port": 8091,
        "pid": 2,
    }
    assert not (tmp_path / "edge-state.toml.tmp").exists()


