"""Tests for halton_meter.redaction.credentials.

Coverage targets (from memory/plans/2026-05-01-body-capture.md):
  * One positive + one negative test per credential category.
  * Ordering test (anthropic_key wins over openai_key).
  * Empty input.
  * Multi-pattern in one body.
  * AWS-secret-key only fires when paired with AKIA in the same body.
  * Bearer-token catch-all does not double-redact tokens already redacted
    by a more-specific pattern.
"""

from __future__ import annotations

from halton_meter.redaction import RedactionHit, redact_credentials
from halton_meter.redaction.credentials import summarise_hits

# ---------------------------------------------------------------------------
# Smoke / edge cases
# ---------------------------------------------------------------------------


def test_empty_input_returns_empty():
    text, hits = redact_credentials("")
    assert text == ""
    assert hits == []


def test_no_matches_returns_input_unchanged():
    src = "This is a perfectly normal English sentence with no secrets."
    text, hits = redact_credentials(src)
    assert text == src
    assert hits == []


# ---------------------------------------------------------------------------
# Per-category positive + negative
# ---------------------------------------------------------------------------


def test_anthropic_key_positive():
    src = 'X-Api-Key: sk-ant-api03-AbCdEf0123456789AbCdEf01234567 ok'
    text, hits = redact_credentials(src)
    assert "sk-ant-api03" not in text
    assert "[REDACTED:anthropic_key]" in text
    cats = [h.category for h in hits]
    assert "anthropic_key" in cats


def test_anthropic_key_negative_normal_prose():
    src = "send the package to ant key west via the post office"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "anthropic_key" for h in hits)


def test_openai_key_positive():
    src = "OPENAI_API_KEY=sk-proj-1234567890abcdefghijklmnop and more text"
    text, hits = redact_credentials(src)
    assert "[REDACTED:openai_key]" in text
    assert "sk-proj-1234567890" not in text
    assert any(h.category == "openai_key" for h in hits)


def test_openai_standard_key_positive():
    """Modern OpenAI standard keys: 'sk-' followed by ~48+ alphanumerics.

    Realistic shape is ``sk-`` + ~48 mixed-case alphanumerics. Asserts the
    key bytes are gone and the surrounding payload is intact.
    """
    key = "sk-AbCdEf0123456789AbCdEf0123456789AbCdEf01234567"
    src = f'{{"OPENAI_API_KEY": "{key}", "model": "gpt-4o"}}'
    text, hits = redact_credentials(src)
    assert key not in text
    assert "[REDACTED:openai_key]" in text
    # Surrounding JSON payload intact (model field survives).
    assert '"model": "gpt-4o"' in text
    assert any(h.category == "openai_key" for h in hits)


def test_openai_project_key_positive():
    """OpenAI project keys: 'sk-proj-' followed by 100+ alphanumerics + _ + -.

    Project keys are notably longer than the standard form and contain a
    wider character set (underscores, hyphens). Assert key bytes gone and
    payload intact.
    """
    key = (
        "sk-proj-"
        + "Abc_Def-0123456789" * 6  # 108 chars after the prefix
    )
    src = f'header: foo\nOPENAI_API_KEY={key}\nfooter: bar'
    text, hits = redact_credentials(src)
    assert key not in text
    assert "sk-proj-" not in text
    assert "[REDACTED:openai_key]" in text
    # Surrounding lines intact.
    assert "header: foo" in text
    assert "footer: bar" in text
    assert any(h.category == "openai_key" for h in hits)


def test_xai_key_positive():
    """xAI (Grok) keys: 'xai-' followed by 40+ alphanumerics."""
    key = "xai-" + "AbCdEf0123456789" * 5  # 80 chars after the prefix
    src = f'{{"XAI_API_KEY": "{key}", "endpoint": "api.x.ai"}}'
    text, hits = redact_credentials(src)
    assert key not in text
    assert "[REDACTED:xai_key]" in text
    # Surrounding payload intact.
    assert '"endpoint": "api.x.ai"' in text
    assert any(h.category == "xai_key" for h in hits)


def test_xai_key_negative_short_prose():
    """Don't redact short ``xai-`` prefixed prose like 'xai-team' or 'xai-roadmap'."""
    src = "see the xai-team page or the xai-roadmap doc — neither is a key"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "xai_key" for h in hits)


def test_openai_key_negative():
    src = "the seasoning is salt, kale, and pepper — sk?"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "openai_key" for h in hits)


def test_aws_access_key_positive():
    src = 'aws_access_key_id = "AKIAIOSFODNN7EXAMPLE"'
    text, hits = redact_credentials(src)
    assert "AKIAIOSFODNN7EXAMPLE" not in text
    assert "[REDACTED:aws_access_key]" in text
    assert any(h.category == "aws_access_key" for h in hits)


def test_aws_access_key_negative_too_short():
    # Plain 'AKIA' followed by lowercase / wrong length must not match.
    src = "send AKIA letters to the warehouse and AKIASHORT123 was rejected"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "aws_access_key" for h in hits)


def test_jwt_positive():
    src = (
        "Authorization: Bearer "
        "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyIn0.SflKxwRJSMeKKF2QT4fwpMeJf36"
    )
    text, hits = redact_credentials(src)
    assert "[REDACTED:jwt]" in text
    assert any(h.category == "jwt" for h in hits)


def test_jwt_negative():
    src = "version is 2.eye.something_lower not a JWT"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "jwt" for h in hits)


def test_github_pat_positive():
    src = "GITHUB_TOKEN=ghp_AbCdEf0123456789AbCdEf0123456789abcd done"
    text, hits = redact_credentials(src)
    assert "[REDACTED:github_pat]" in text
    assert any(h.category == "github_pat" for h in hits)


def test_github_pat_negative():
    # Missing _ → not a PAT.
    src = "the ghpAbcDef and gh_oauth values are unrelated to PATs"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "github_pat" for h in hits)


def test_stripe_secret_positive():
    src = "STRIPE_KEY=sk_live_AbCdEf0123456789AbCdEf01"
    text, hits = redact_credentials(src)
    assert "[REDACTED:stripe_secret]" in text
    assert any(h.category == "stripe_secret" for h in hits)


def test_stripe_secret_negative():
    src = "sk_active_test was an internal codename, not a key"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "stripe_secret" for h in hits)


def test_stripe_publishable_positive():
    # Operator confirmed: redact for defensive consistency (open Q#3).
    src = "STRIPE_PK=pk_live_AbCdEf0123456789AbCdEf01"
    text, hits = redact_credentials(src)
    assert "[REDACTED:stripe_publishable]" in text
    assert any(h.category == "stripe_publishable" for h in hits)


def test_stripe_publishable_negative():
    src = "pk_dev was the placeholder; not a real key"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "stripe_publishable" for h in hits)


def test_google_api_key_positive():
    src = "key=AIzaSyAbCdEf0123456789_AbCdEf0123456789xyz and more"
    text, hits = redact_credentials(src)
    assert "[REDACTED:google_api_key]" in text
    assert any(h.category == "google_api_key" for h in hits)


def test_google_api_key_negative():
    src = "the AIza nightclub on aiza street has no key"
    text, hits = redact_credentials(src)
    assert text == src
    assert not any(h.category == "google_api_key" for h in hits)


def test_bearer_token_positive():
    src = "Authorization: Bearer abcDEF1234567890abcDEF1234567890"
    text, hits = redact_credentials(src)
    assert "[REDACTED:bearer_token]" in text
    # Prefix preserved.
    assert "Bearer" in text or "Authorization" in text
    assert any(h.category == "bearer_token" for h in hits)


def test_bearer_token_negative_too_short():
    # 19 chars after Bearer — below the 20-char threshold.
    src = "Bearer abc1234567890abc123"
    text, hits = redact_credentials(src)
    assert "[REDACTED:bearer_token]" not in text
    assert not any(h.category == "bearer_token" for h in hits)


# ---------------------------------------------------------------------------
# Ordering and overlap
# ---------------------------------------------------------------------------


def test_anthropic_beats_openai_when_both_could_match():
    """sk-ant- is a strict prefix of sk- so the more specific category must win."""
    src = "key=sk-ant-api03-AbCdEf0123456789AbCdEf01234567"
    _, hits = redact_credentials(src)
    cats = [h.category for h in hits]
    assert "anthropic_key" in cats
    # The openai_key catch-all may also report a hit for the same span via
    # the original text walk; what matters is that the placeholder in the
    # output is the more specific one.
    text, _ = redact_credentials(src)
    assert "[REDACTED:anthropic_key]" in text
    # No leftover sk-ant- chars.
    assert "sk-ant-" not in text


def test_bearer_token_does_not_double_redact_specific_match():
    # A bearer-wrapped Anthropic key: the anthropic_key pattern wins; the
    # bearer catch-all should not fire on the placeholder afterwards.
    src = "Authorization: Bearer sk-ant-api03-AbCdEf0123456789AbCdEf01234567"
    text, hits = redact_credentials(src)
    cats = [h.category for h in hits]
    assert "anthropic_key" in cats
    # The bearer pattern won't match because the placeholder
    # "[REDACTED:anthropic_key]" doesn't satisfy the [A-Za-z0-9._-]{20,} body.
    # Confirm the literal placeholder lands and Bearer prefix survives.
    assert "[REDACTED:anthropic_key]" in text
    assert "Bearer" in text


def test_stripe_secret_beats_openai():
    src = "stripe=sk_live_AbCdEf0123456789AbCdEf01"
    text, _ = redact_credentials(src)
    assert "[REDACTED:stripe_secret]" in text
    assert "[REDACTED:openai_key]" not in text


# ---------------------------------------------------------------------------
# AWS secret-key paired-only behaviour
# ---------------------------------------------------------------------------


def test_aws_secret_key_NOT_redacted_without_access_key():
    """Without an AKIA in the same body, the high-FP-risk 40-char base64
    pattern must not fire. A SHA256 hash is the canonical false-positive
    we must avoid.
    """
    sha256_hex = "a" * 40  # 40 hex chars — same length as an AWS secret.
    src = f"checksum: {sha256_hex} (no aws access keys here)"
    text, hits = redact_credentials(src)
    assert "[REDACTED:aws_secret_key]" not in text
    assert text == src
    assert not any(h.category == "aws_secret_key" for h in hits)


def test_aws_secret_key_redacted_when_access_key_present():
    """With an AKIA, the secret-key pattern fires — we accept some FP
    risk inside that body because access+secret pairs are the credentials
    we're really trying to scrub.
    """
    src = (
        "aws_access_key_id=AKIAIOSFODNN7EXAMPLE\n"
        "aws_secret_access_key=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n"
    )
    text, hits = redact_credentials(src)
    assert "AKIAIOSFODNN7EXAMPLE" not in text
    assert "wJalrXUtnFEMI" not in text
    assert "[REDACTED:aws_access_key]" in text
    assert "[REDACTED:aws_secret_key]" in text
    cats = {h.category for h in hits}
    assert "aws_access_key" in cats
    assert "aws_secret_key" in cats


# ---------------------------------------------------------------------------
# Multi-pattern body
# ---------------------------------------------------------------------------


def test_multi_pattern_body_redacts_all():
    src = (
        "OPENAI_API_KEY=sk-proj-AbCdEf0123456789AbCdEf01\n"
        "ANTHROPIC=sk-ant-api03-XyZaBcDe0123456789XyZaBc\n"
        "GITHUB=ghp_AbCdEf0123456789AbCdEf0123456789abcd\n"
        "GOOGLE=AIzaSyAbCdEf0123456789_AbCdEf0123456789xyz\n"
        "STRIPE=sk_live_AbCdEf0123456789AbCdEf01\n"
        "Authorization: Bearer abcDEF1234567890abcDEF1234567890\n"
    )
    text, hits = redact_credentials(src)

    cats = [h.category for h in hits]
    assert "openai_key" in cats
    assert "anthropic_key" in cats
    assert "github_pat" in cats
    assert "google_api_key" in cats
    assert "stripe_secret" in cats
    assert "bearer_token" in cats

    for placeholder in (
        "[REDACTED:openai_key]",
        "[REDACTED:anthropic_key]",
        "[REDACTED:github_pat]",
        "[REDACTED:google_api_key]",
        "[REDACTED:stripe_secret]",
        "[REDACTED:bearer_token]",
    ):
        assert placeholder in text


def test_summarise_hits_counts_categories():
    hits = [
        RedactionHit(category="openai_key", span=(0, 5), placeholder="x"),
        RedactionHit(category="openai_key", span=(10, 15), placeholder="x"),
        RedactionHit(category="jwt", span=(20, 25), placeholder="x"),
    ]
    summary = summarise_hits(hits)
    assert summary == {"openai_key": 2, "jwt": 1}


def test_summarise_hits_empty():
    assert summarise_hits([]) == {}
