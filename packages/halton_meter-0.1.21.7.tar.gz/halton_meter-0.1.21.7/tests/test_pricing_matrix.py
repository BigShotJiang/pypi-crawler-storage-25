"""Tests for the bundled Anthropic pricing matrix in halton_meter.pricing.matrix.

Specifically asserts the seeded ``cache_write`` rate equals 1.25x the
``input`` rate (the documented Anthropic 5m-default ephemeral cache-write
rate) for representative models. See decisions.md 2026-04-30
("Cache token accounting…") for the rationale behind a single
``cache_write`` rate at 1.25x input.
"""

from __future__ import annotations

import pytest

from halton_meter.pricing import compute_cost_millicents
from halton_meter.pricing.matrix import ANTHROPIC_RATES, GEMINI_RATES, OPENAI_RATES, _usd


@pytest.mark.parametrize(
    "model",
    [
        "claude-opus-4-7",
        "claude-sonnet-4-6",
        "claude-haiku-4-5",
        "claude-opus-4-5",
        "claude-sonnet-4-5",
    ],
)
def test_cache_write_rate_is_125_percent_of_input(model: str) -> None:
    """``cache_write`` must equal 1.25x ``input`` for every seeded model.

    Tolerates ±1 millicent rounding from the ``round(dollars * 100_000)``
    conversion in ``_usd``: e.g. input=$3.00 → 300_000; cache_write at
    1.25x = 375_000 (exact). For input=$1 → 100_000; 1.25x = 125_000.
    For input=$5 → 500_000; 1.25x = 625_000.
    """
    rates = ANTHROPIC_RATES[model]
    expected = round(rates.input * 1.25)
    assert rates.cache_write == expected, (
        f"{model}: cache_write={rates.cache_write} expected {expected} "
        f"(1.25x input={rates.input})"
    )


def test_cache_write_present_for_every_seeded_model() -> None:
    """Every seeded model must carry a non-zero cache_write rate.

    Guards against future entries forgetting to seed cache_write.
    """
    for model, rates in ANTHROPIC_RATES.items():
        assert rates.cache_write > 0, f"{model} has zero cache_write rate"


def test_cache_write_above_cache_read_for_every_model() -> None:
    """Cache writes are billed higher than cache reads — fail-loud invariant.

    Anthropic prices cache writes at 1.25x input (5m) vs cache reads at
    0.10x input. If a model entry inverts this, the matrix is wrong.
    """
    for model, rates in ANTHROPIC_RATES.items():
        assert rates.cache_write > rates.cache_read, (
            f"{model}: cache_write ({rates.cache_write}) "
            f"must exceed cache_read ({rates.cache_read})"
        )


# ---------------------------------------------------------------------------
# Anthropic published-list regression (v0.1.11).
#
# The data below is hand-typed from the Anthropic pricing page the operator
# pasted on 2026-05-01 (claude.com/pricing). If a model is added to or
# renamed on that page, this list must be updated to match — the test will
# fail loudly when the bundled matrix drifts. Catches the v0.1.5+ silent
# 3x undercount of Opus 4.1 ($5/$25 vs the actual $15/$75).
# ---------------------------------------------------------------------------
ANTHROPIC_PUBLISHED_2026_05_01: dict[str, tuple[float, float]] = {
    # Current models (input $/MTok, output $/MTok).
    "claude-opus-4-7": (5.00, 25.00),
    "claude-opus-4-6": (5.00, 25.00),
    "claude-opus-4-5": (5.00, 25.00),
    "claude-opus-4-1": (15.00, 75.00),  # 3x undercount fixed in v0.1.11
    "claude-sonnet-4-6": (3.00, 15.00),
    "claude-sonnet-4-5": (3.00, 15.00),
    "claude-sonnet-4-0": (3.00, 15.00),
    "claude-haiku-4-5": (1.00, 5.00),
    # Deprecated / legacy models still in use.
    "claude-opus-4-0": (15.00, 75.00),
    "claude-3-7-sonnet-latest": (3.00, 15.00),
    "claude-3-5-haiku-latest": (0.80, 4.00),
    "claude-3-opus-latest": (15.00, 75.00),
    "claude-3-haiku-20240307": (0.25, 1.25),
}


@pytest.mark.parametrize("model", sorted(ANTHROPIC_PUBLISHED_2026_05_01.keys()))
def test_anthropic_published_model_present_with_correct_rates(model: str) -> None:
    """Every model on Anthropic's published 2026-05-01 list must exist
    in ``ANTHROPIC_RATES`` with input/output rates matching the published
    USD values to the millicent.
    """
    assert model in ANTHROPIC_RATES, (
        f"{model} is published by Anthropic 2026-05-01 but missing from "
        "ANTHROPIC_RATES — refresh the bundled matrix."
    )
    expected_in, expected_out = ANTHROPIC_PUBLISHED_2026_05_01[model]
    rates = ANTHROPIC_RATES[model]
    assert rates.input == _usd(expected_in), (
        f"{model}: input rate {rates.input} != published ${expected_in}/MTok "
        f"({_usd(expected_in)} millicents)"
    )
    assert rates.output == _usd(expected_out), (
        f"{model}: output rate {rates.output} != published ${expected_out}/MTok "
        f"({_usd(expected_out)} millicents)"
    )


# ---------------------------------------------------------------------------
# Gemini rate matrix (v0.1.11).
# ---------------------------------------------------------------------------
GEMINI_PUBLISHED_2026_05_01: dict[str, tuple[float, float]] = {
    # Lower-tier (≤200k) defaults match what's seeded; the >200k surcharge
    # is intentionally NOT seeded yet (see TODO in matrix.py). Matched
    # against ai.google.dev/gemini-api/docs/pricing 2026-05-01.
    "gemini-3.1-pro-preview": (2.00, 12.00),
    "gemini-3.1-flash-lite-preview": (0.25, 1.50),
    "gemini-3.1-flash-live-preview": (0.75, 4.50),
    "gemini-3.1-flash-image-preview": (0.50, 3.00),
    "gemini-2.5-pro": (1.25, 10.00),
}


# ---------------------------------------------------------------------------
# Gemini Code Assist SKUs (v0.1.19.dev4). Canonical SKU id
# ``gemini-3-flash-preview`` confirmed via real-traffic
# ``adapter.gemini_code_assist.model_observed`` log lines from the dev3
# wheel. Mapped to the closest comparable seeded tier
# (``gemini-3.1-flash-lite-preview`` $0.25 / $1.50) — Google does not
# publish API rates for this Code Assist preview alias as of 2026-05-04;
# the rationale is documented in matrix.py.
# ---------------------------------------------------------------------------
GEMINI_CODEASSIST_SKUS: tuple[str, ...] = (
    "gemini-3-flash-preview",
    "gemini-code-assist-unknown",
)


@pytest.mark.parametrize("model", GEMINI_CODEASSIST_SKUS)
def test_codeassist_sku_priced_at_flash_lite_tier(model: str) -> None:
    """Code Assist SKUs must mirror gemini-3.1-flash-lite-preview rates
    ($0.25 in / $1.50 out / $0.025 cache_read) until Google publishes
    a tier-specific API rate for the Code Assist preview alias."""
    assert model in GEMINI_RATES, f"{model} missing from GEMINI_RATES"
    rates = GEMINI_RATES[model]
    assert rates.input == _usd(0.25), (
        f"{model}: input rate drifted from flash-lite mapping ($0.25/MTok)"
    )
    assert rates.output == _usd(1.50), (
        f"{model}: output rate drifted from flash-lite mapping ($1.50/MTok)"
    )
    assert rates.cache_read == _usd(0.025), (
        f"{model}: cache_read drifted from flash-lite mapping ($0.025/MTok)"
    )


def test_codeassist_unknown_fallback_is_not_zero() -> None:
    """The Code Assist adapter fallback row must never silently
    underprice — guards against a novel SKU we haven't seeded
    landing at $0."""
    rates = GEMINI_RATES["gemini-code-assist-unknown"]
    assert rates.input > 0
    assert rates.output > 0


# ---------------------------------------------------------------------------
# OpenAI Codex backend SKUs (v0.1.19.dev4). The 6 SKUs below were observed
# in the user's ``GET chatgpt.com/backend-api/codex/models`` response when
# running ``@openai/codex`` v0.128.0. None are listed on the public OpenAI
# API pricing page as of 2026-05-04, so each is mapped to the closest
# comparable public-API tier (see the comment block in matrix.py). When
# OpenAI publishes API rates for these SKUs (or reconciliation gives
# ground truth) each tuple here becomes a one-line rate update.
#
# Rationale for mapping (mirrored from matrix.py):
#   gpt-5.5, gpt-5.4, gpt-5.3-codex, gpt-5.2  → gpt-4.1 tier ($2 / $8 / $0.50)
#   gpt-5.4-mini, codex-auto-review           → gpt-4.1-mini ($0.40 / $1.60 / $0.10)
#   codex-unknown (adapter fallback)          → gpt-4.1 tier (defensive default)
# ---------------------------------------------------------------------------
OPENAI_CODEX_FLAGSHIP_SKUS: tuple[str, ...] = (
    "gpt-5.5",
    "gpt-5.4",
    "gpt-5.3-codex",
    "gpt-5.2",
    "codex-unknown",
)
OPENAI_CODEX_MINI_SKUS: tuple[str, ...] = (
    "gpt-5.4-mini",
    "codex-auto-review",
)


@pytest.mark.parametrize("model", OPENAI_CODEX_FLAGSHIP_SKUS)
def test_codex_flagship_sku_priced_at_gpt_4_1_tier(model: str) -> None:
    """Codex flagship SKUs must mirror gpt-4.1 ($2.00 in / $8.00 out /
    $0.50 cache_read) until OpenAI publishes API rates for them."""
    assert model in OPENAI_RATES, f"{model} missing from OPENAI_RATES"
    rates = OPENAI_RATES[model]
    assert rates.input == _usd(2.00), (
        f"{model}: input rate drifted from gpt-4.1 mapping ($2.00/MTok)"
    )
    assert rates.output == _usd(8.00), (
        f"{model}: output rate drifted from gpt-4.1 mapping ($8.00/MTok)"
    )
    assert rates.cache_read == _usd(0.50), (
        f"{model}: cache_read drifted from gpt-4.1 mapping ($0.50/MTok)"
    )


@pytest.mark.parametrize("model", OPENAI_CODEX_MINI_SKUS)
def test_codex_mini_sku_priced_at_gpt_4_1_mini_tier(model: str) -> None:
    """Codex mini-tier SKUs must mirror gpt-4.1-mini ($0.40 in /
    $1.60 out / $0.10 cache_read)."""
    assert model in OPENAI_RATES, f"{model} missing from OPENAI_RATES"
    rates = OPENAI_RATES[model]
    assert rates.input == _usd(0.40), (
        f"{model}: input rate drifted from gpt-4.1-mini mapping ($0.40/MTok)"
    )
    assert rates.output == _usd(1.60), (
        f"{model}: output rate drifted from gpt-4.1-mini mapping ($1.60/MTok)"
    )
    assert rates.cache_read == _usd(0.10), (
        f"{model}: cache_read drifted from gpt-4.1-mini mapping ($0.10/MTok)"
    )


def test_codex_unknown_fallback_is_not_zero() -> None:
    """The adapter fallback row must never silently underprice — guards
    against a novel SKU we haven't seeded landing at $0."""
    rates = OPENAI_RATES["codex-unknown"]
    assert rates.input > 0
    assert rates.output > 0


@pytest.mark.parametrize("model", sorted(GEMINI_PUBLISHED_2026_05_01.keys()))
def test_gemini_published_model_present_with_correct_rates(model: str) -> None:
    """Every Gemini model on Google's published 2026-05-01 list must exist
    in ``GEMINI_RATES`` with the lower-tier (≤200k) rates seeded.
    """
    assert model in GEMINI_RATES, f"{model} missing from GEMINI_RATES"
    expected_in, expected_out = GEMINI_PUBLISHED_2026_05_01[model]
    rates = GEMINI_RATES[model]
    assert rates.input == _usd(expected_in), (
        f"{model}: input rate {rates.input} != published ${expected_in}/MTok"
    )
    assert rates.output == _usd(expected_out), (
        f"{model}: output rate {rates.output} != published ${expected_out}/MTok"
    )


@pytest.mark.parametrize(
    "model,input_tokens,output_tokens,expected_millicents",
    [
        # gemini-3.1-pro-preview — standard tier (≤200k input).
        # Rate sheet (millicents/MTok): input=200_000 ($2), output=1_200_000 ($12).
        # Numerator = 100_000 * 200_000 + 1_000_000 * 1_200_000
        #           = 20_000_000_000 + 1_200_000_000_000 = 1_220_000_000_000
        # Cost = 1_220_000_000_000 // 1_000_000 = 1_220_000 millicents.
        # Uses 100k input (≤200k threshold) to exercise the standard tier.
        ("gemini-3.1-pro-preview", 100_000, 1_000_000, 1_220_000),
        # gemini-3.1-flash-lite-preview — single tier.
        # Rate sheet (millicents/MTok): input=25_000 ($0.25), output=150_000 ($1.50).
        # Numerator = 1_000_000 * 25_000 + 1_000_000 * 150_000
        #           = 25_000_000_000 + 150_000_000_000 = 175_000_000_000
        # Cost = 175_000_000_000 // 1_000_000 = 175_000 millicents.
        ("gemini-3.1-flash-lite-preview", 1_000_000, 1_000_000, 175_000),
        # gemini-3.1-flash-live-preview — single tier.
        # Rate sheet (millicents/MTok): input=75_000 ($0.75), output=450_000 ($4.50).
        # Numerator = 1_000_000 * 75_000 + 1_000_000 * 450_000
        #           = 75_000_000_000 + 450_000_000_000 = 525_000_000_000
        # Cost = 525_000_000_000 // 1_000_000 = 525_000 millicents.
        ("gemini-3.1-flash-live-preview", 1_000_000, 1_000_000, 525_000),
        # gemini-3.1-flash-image-preview — single tier.
        # Rate sheet (millicents/MTok): input=50_000 ($0.50), output=300_000 ($3.00).
        # Numerator = 1_000_000 * 50_000 + 1_000_000 * 300_000
        #           = 50_000_000_000 + 300_000_000_000 = 350_000_000_000
        # Cost = 350_000_000_000 // 1_000_000 = 350_000 millicents.
        ("gemini-3.1-flash-image-preview", 1_000_000, 1_000_000, 350_000),
        # gemini-2.5-pro — standard tier (≤200k input).
        # Rate sheet (millicents/MTok): input=125_000 ($1.25), output=1_000_000 ($10).
        # Numerator = 100_000 * 125_000 + 1_000_000 * 1_000_000
        #           = 12_500_000_000 + 1_000_000_000_000 = 1_012_500_000_000
        # Cost = 1_012_500_000_000 // 1_000_000 = 1_012_500 millicents.
        # Uses 100k input (≤200k threshold) to exercise the standard tier.
        ("gemini-2.5-pro", 100_000, 1_000_000, 1_012_500),
    ],
)
def test_gemini_cost_computation(
    model: str, input_tokens: int, output_tokens: int, expected_millicents: int
) -> None:
    """End-to-end check: ``compute_cost_millicents`` must resolve Gemini
    models from the bundled matrix and return hand-computed totals.

    Guards against:
      * GEMINI_RATES not being routed through the bundled-matrix lookup.
      * Rate-table drift on the lower-tier defaults.

    Updated in v0.1.12: the resolver now handles Gemini, so all cases assert
    unconditionally. Tiered models (gemini-3.1-pro-preview, gemini-2.5-pro)
    use 100k input tokens to exercise the standard (≤200k) tier — see the
    dedicated tier tests in test_pricing.py for the high-context path.
    """
    cost = compute_cost_millicents(
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    assert cost is not None, f"{model}: expected a cost, got None"
    assert cost == expected_millicents, (
        f"{model}: bundled-matrix cost {cost} != expected {expected_millicents}"
    )


def test_opus_4_1_rates_are_15_75_not_5_25() -> None:
    """Direct regression for the v0.1.5 → v0.1.10 silent 3x undercount
    on Opus 4.1. Anthropic publishes $15/$75; the matrix shipped $5/$25
    until v0.1.11 fixed it. Test fails loudly if anyone reverts.
    """
    for model in ("claude-opus-4-1", "claude-opus-4-1-20250805"):
        rates = ANTHROPIC_RATES[model]
        assert rates.input == _usd(15.00), f"{model} input regressed"
        assert rates.output == _usd(75.00), f"{model} output regressed"


# ---------------------------------------------------------------------------
# Gemini tiered and multimodal rate tests (v0.1.12).
# ---------------------------------------------------------------------------


def test_gemini_tiered_high_context_rates_correct() -> None:
    """gemini-3.1-pro-preview high_context rates are $4/$18 input/output."""
    from halton_meter.pricing.matrix import GEMINI_TIERED_RATES

    tiered = GEMINI_TIERED_RATES["gemini-3.1-pro-preview"]
    assert tiered.high_context.input == _usd(4.00), (
        f"high_context input {tiered.high_context.input} != {_usd(4.00)}"
    )
    assert tiered.high_context.output == _usd(18.00), (
        f"high_context output {tiered.high_context.output} != {_usd(18.00)}"
    )


def test_gemini_tiered_threshold_is_200k() -> None:
    """Both tiered Gemini models must have threshold_tokens == 200_000."""
    from halton_meter.pricing.matrix import GEMINI_TIERED_RATES

    for model in ("gemini-3.1-pro-preview", "gemini-2.5-pro"):
        assert GEMINI_TIERED_RATES[model].threshold_tokens == 200_000, (
            f"{model} threshold_tokens != 200_000"
        )


def test_gemini_modal_rates_image_generation() -> None:
    """gemini-3.1-flash-image-preview image_generation rate is $60/MTok."""
    from halton_meter.pricing.matrix import GEMINI_MODAL_RATES

    rates = GEMINI_MODAL_RATES["gemini-3.1-flash-image-preview"]
    assert rates.image_generation == _usd(60.00), (
        f"image_generation {rates.image_generation} != {_usd(60.00)}"
    )


def test_gemini_modal_rates_audio() -> None:
    """gemini-3.1-flash-live-preview audio rates are $3 in / $12 out."""
    from halton_meter.pricing.matrix import GEMINI_MODAL_RATES

    rates = GEMINI_MODAL_RATES["gemini-3.1-flash-live-preview"]
    assert rates.audio_input == _usd(3.00), (
        f"audio_input {rates.audio_input} != {_usd(3.00)}"
    )
    assert rates.audio_output == _usd(12.00), (
        f"audio_output {rates.audio_output} != {_usd(12.00)}"
    )
