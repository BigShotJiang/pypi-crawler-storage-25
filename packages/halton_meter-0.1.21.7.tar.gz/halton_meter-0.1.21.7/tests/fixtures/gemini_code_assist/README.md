# Gemini Code Assist fixtures — SYNTHETIC (not real-traffic)

These fixtures were hand-constructed for the v0.1.19.dev2 sibling-adapter
landing (2026-05-04). The user's gemini-cli session that triggered the
investigation showed `host=cloudcode-pa.googleapis.com` with paths
`/v1internal:generateContent` and `/v1internal:streamGenerateContent?alt=sse`,
but the daemon dropped the requests at adapter dispatch and never persisted
the bodies, so we have no real captured request/response to use.

The fixtures here are based on the public Gemini API's documented response
shape (the Code Assist surface tunnels the same API server-side per the
investigation note in `memory/plans/2026-05-04-gemini-capture-gap-investigation.md`),
plus a defensive `response.usageMetadata` wrapper that some Code Assist
client builds have been observed to use.

**These need real-traffic confirmation in dev3** — once the dev2 wheel is
in the user's hands and the next gemini-cli session captures a real
`generateContent` body, replace these fixtures with the captured ones and
adjust the test expectations to match.

Files:
- `generate_content_basic.json` — non-streaming, top-level usageMetadata
- `generate_content_wrapped.json` — non-streaming, response.usageMetadata wrapper
- `stream_generate_content.txt` — SSE with usageMetadata on the final chunk
- `stream_generate_content_no_usage.txt` — SSE that never carries usageMetadata
  (client-closed-early scenario)
- `request_body_with_model.json` — request body shape (top-level "model")
- `request_body_no_model.json` — request body lacking a model field
