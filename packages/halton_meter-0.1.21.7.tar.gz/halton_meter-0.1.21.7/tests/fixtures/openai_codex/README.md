# OpenAI Codex backend fixtures — SYNTHETIC (not real-traffic)

These fixtures were hand-constructed for the v0.1.19.dev3 sibling-adapter
landing (2026-05-04). The user's `@openai/codex` v0.128.0 session that
triggered the investigation showed `host=chatgpt.com` with path
`/backend-api/codex/responses`, but the daemon dropped the requests at
adapter dispatch (`addon.no_adapter_match` log line) and never persisted
the bodies, so we have no real captured request/response to use.

The fixtures here are based on the public OpenAI Responses API's
documented response shape under the assumption that the Codex backend
tunnels the same wire shape server-side (the path action name
`responses` and the `@openai/codex` SDK lineage both point this way).

**These need real-traffic confirmation in dev4** — once the dev3 wheel
is in the user's hands and the next Codex session captures a real
`/backend-api/codex/responses` body, replace these fixtures with the
captured ones and adjust the test expectations to match.

Files:
- `responses_basic.json` — non-streaming, top-level `usage` (Responses-API shape)
- `responses_wrapped.json` — non-streaming, `response.usage` wrapper
- `stream_responses.txt` — SSE with `response.completed` event carrying usage
- `stream_responses_no_usage.txt` — SSE that never carries usage
  (client-closed-early scenario)
- `request_body_with_model.json` — request body shape (top-level "model")
- `request_body_no_model.json` — request body lacking a model field
