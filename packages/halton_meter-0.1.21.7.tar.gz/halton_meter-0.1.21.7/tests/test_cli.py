"""Tests for the ``halton-meter`` Click CLI surface.

Currently scoped to the Q1 layer-4 (2B.10) ``reset-proxy`` subcommand;
broader CLI smoke lives in ``test_lifecycle.py`` and ``test_init.py``.
"""

from __future__ import annotations

import subprocess
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import cli as cli_module
from halton_meter import system_proxy


def test_reset_proxy_command_exits_zero_on_macos(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Acceptance criterion #1: ``halton-meter reset-proxy`` exits 0."""
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )
    # Preset the dynamic-enumeration cache (2B.7.2) so we exercise the
    # original 4-interface fallback list and the call-count assertion
    # remains valid.
    monkeypatch.setattr(
        system_proxy, "_MACOS_INTERFACES_CACHE", system_proxy._MACOS_INTERFACE_FALLBACK
    )

    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["reset-proxy"])
    assert result.exit_code == 0
    # The networksetup loop ran (4 ifaces x 2 variants).
    assert len(calls) == 8


def test_reset_proxy_command_exits_zero_on_linux(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(system_proxy.sys, "platform", "linux")
    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["reset-proxy"])
    assert result.exit_code == 0


def test_reset_proxy_command_succeeds_without_admin_or_plists(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Acceptance criterion #1 corollary: works on a system without our plists.

    Simulates CI / a fresh machine: ``networksetup`` may exist but every
    invocation returns non-zero (no admin / no privileges). The command
    must still exit 0 — every per-interface failure is swallowed
    inside ``_disable_macos_proxy``.
    """
    monkeypatch.setattr(system_proxy.sys, "platform", "darwin")
    monkeypatch.setattr(
        system_proxy.shutil, "which", lambda _name: "/usr/sbin/networksetup"
    )

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        return subprocess.CompletedProcess(
            argv, 1, stdout="", stderr="needs admin"
        )

    monkeypatch.setattr(system_proxy.subprocess, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["reset-proxy"])
    assert result.exit_code == 0


# --------------------------------------------------------------------------- #
# 2B.11: uninstall purge tier flow                                             #
# --------------------------------------------------------------------------- #


def test_uninstall_default_no_purge_runs_without_prompt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Plain ``halton-meter uninstall`` does not prompt; just runs."""
    from halton_meter import install as install_module

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool, graceful: bool = False) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall"])
    assert result.exit_code == 0
    assert captured == {"purge": False, "include_logs": False}


def test_uninstall_purge_prompts_and_aborts_on_no(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    called: dict[str, bool] = {"called": False}

    def fake_uninstall(*, purge: bool, include_logs: bool, graceful: bool = False) -> int:
        called["called"] = True
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall", "--purge"], input="no\n")
    assert result.exit_code == 1
    assert called["called"] is False
    assert "Aborted" in result.output


def test_uninstall_purge_proceeds_on_yes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool, graceful: bool = False) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall", "--purge"], input="yes\n")
    assert result.exit_code == 0
    assert captured == {"purge": True, "include_logs": False}


def test_uninstall_include_logs_prompt_shows_record_count(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``--purge --include-logs`` prompt displays the request and project counts."""
    from halton_meter import install as install_module

    monkeypatch.setattr(
        install_module, "count_request_records", lambda _path: (1234, 7)
    )

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool, graceful: bool = False) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["uninstall", "--purge", "--include-logs"],
        input="delete\n",
    )
    assert result.exit_code == 0
    assert "1,234 requests" in result.output
    assert "7 projects" in result.output
    assert captured == {"purge": True, "include_logs": True}


def test_uninstall_include_logs_aborts_when_response_not_delete(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    monkeypatch.setattr(
        install_module, "count_request_records", lambda _path: (10, 2)
    )
    called: dict[str, bool] = {"called": False}
    monkeypatch.setattr(
        install_module,
        "uninstall",
        lambda **_kw: (called.__setitem__("called", True) or 0),
    )

    runner = CliRunner()
    # User types 'yes' (the wrong word for include-logs); must abort.
    result = runner.invoke(
        cli_module.cli,
        ["uninstall", "--purge", "--include-logs"],
        input="yes\n",
    )
    assert result.exit_code == 1
    assert called["called"] is False


def test_uninstall_include_logs_without_purge_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from halton_meter import install as install_module

    called: dict[str, bool] = {"called": False}
    monkeypatch.setattr(
        install_module,
        "uninstall",
        lambda **_kw: (called.__setitem__("called", True) or 0),
    )

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["uninstall", "--include-logs"])
    assert result.exit_code == 2
    assert called["called"] is False


# --------------------------------------------------------------------------- #
# 2B.12: daemon preflight refuses second instance                              #
# --------------------------------------------------------------------------- #


class _StubDaemonCfg:
    """Minimal duck-typed config for daemon preflight tests.

    v0.1.6 (2C.2): the user-facing proxy port is now ``edge_port`` (was
    ``listen_port``) and a new ``internal_port`` field exists. Both are
    exposed here so callers reading either name keep working.
    """

    def __init__(
        self,
        api_host: str = "127.0.0.1",
        api_port: int = 8765,
        listen_host: str = "127.0.0.1",
        edge_port: int = 8081,
        internal_port: int = 8090,
    ) -> None:
        from types import SimpleNamespace

        self.daemon = SimpleNamespace(
            api_host=api_host,
            api_port=api_port,
            listen_host=listen_host,
            edge_port=edge_port,
            internal_port=internal_port,
            edge_health_ttl_ms=1000,
            log_path="/tmp/halton-meter.log",
        )
        self.storage = SimpleNamespace(db_path="/tmp/halton-test.db")
        self.sync = SimpleNamespace()


def _patch_daemon_cfg(monkeypatch: pytest.MonkeyPatch) -> None:
    """Patch load_config + load_effective_config + discover_and_persist_ports
    so the daemon command sees a deterministic ``8080/8765`` config
    regardless of which ports are actually bound on the host.

    v0.1.5 (2B.16) P1-AUDIT-flake fix: the v0.1.4 form patched only
    ``load_config`` and was flaky when the developer's real daemon
    held 8765 (port_alloc would auto-fallback to 8766 → assertions
    looking for ``8765`` in stderr broke). The cli's ``daemon``
    command uses ``load_effective_config`` from port_alloc, not
    ``load_config`` — so the prior patch was a no-op on the hot path.
    """
    monkeypatch.setattr(cli_module, "load_config", lambda *_a, **_kw: _StubDaemonCfg())
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc, "load_effective_config",
        lambda *_a, **_kw: _StubDaemonCfg(),
    )
    monkeypatch.setattr(
        _port_alloc, "discover_and_persist_ports", lambda *_a, **_kw: None,
    )


def test_daemon_refuses_when_launchctl_reports_live_pid(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Bug A: launchctl-managed daemon already running → exit 1, no asyncio.run."""
    _patch_daemon_cfg(monkeypatch)
    monkeypatch.setattr(cli_module, "_launchctl_managed_pid", lambda *_a, **_k: 12654)
    monkeypatch.setattr(cli_module, "_api_port_is_bound", lambda *_a, **_k: False)

    asyncio_called: dict[str, bool] = {"called": False}

    def fake_run(*_a: Any, **_kw: Any) -> None:
        asyncio_called["called"] = True

    monkeypatch.setattr(cli_module.asyncio, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["daemon"])
    assert result.exit_code == 1
    # Pre-flight ran BEFORE asyncio.run.
    assert asyncio_called["called"] is False
    # Stderr (mix_stderr defaults vary) — assert via combined output.
    # CliRunner default mix_stderr=True merges stderr into result.output.
    combined = result.output or ""
    assert "another instance is already running" in combined
    assert "PID 12654" in combined
    assert "com.haltonlabs.meter" in combined
    # NEVER recommend `halton-meter daemon` to the user (Bug B sister fix);
    # it's mentioned here only as the offending command's name.
    assert "halton-meter status" in combined
    assert "halton-meter stop" in combined


def test_daemon_refuses_when_api_port_already_bound(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Bug A: another process holds api_port (no launchctl entry) → exit 1."""
    _patch_daemon_cfg(monkeypatch)
    monkeypatch.setattr(cli_module, "_launchctl_managed_pid", lambda *_a, **_k: None)
    monkeypatch.setattr(cli_module, "_api_port_is_bound", lambda *_a, **_k: True)

    asyncio_called: dict[str, bool] = {"called": False}
    monkeypatch.setattr(
        cli_module.asyncio,
        "run",
        lambda *_a, **_kw: asyncio_called.__setitem__("called", True),
    )

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["daemon"])
    assert result.exit_code == 1
    assert asyncio_called["called"] is False
    # CliRunner default mix_stderr=True merges stderr into result.output.
    combined = result.output or ""
    assert "another instance is already running" in combined
    assert "8765" in combined
    assert "halton-meter status" in combined


def test_daemon_proceeds_when_nothing_running(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Pre-flight regression: clear field → asyncio.run is invoked normally."""
    _patch_daemon_cfg(monkeypatch)
    monkeypatch.setattr(cli_module, "_launchctl_managed_pid", lambda *_a, **_k: None)
    monkeypatch.setattr(cli_module, "_api_port_is_bound", lambda *_a, **_k: False)

    captured: dict[str, Any] = {"ran": False}

    def fake_run(coro: Any) -> None:
        # Click expects a sync return; we don't actually run the coroutine.
        # Close it to avoid "coroutine never awaited" warnings.
        try:
            coro.close()
        except Exception:
            pass
        captured["ran"] = True

    monkeypatch.setattr(cli_module.asyncio, "run", fake_run)

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["daemon"])
    assert result.exit_code == 0
    assert captured["ran"] is True


# --------------------------------------------------------------------------- #
# 2B.12.1: empty-records messages do not recommend `halton-meter daemon`      #
# --------------------------------------------------------------------------- #


@pytest.mark.parametrize(
    ("daemon_up", "proxy_on", "expected_phrase", "forbidden_phrase"),
    [
        (
            True,
            True,
            "system proxy is enabled",
            "halton-meter daemon",
        ),
        (
            True,
            False,
            "system proxy is disabled",
            "halton-meter daemon",
        ),
        (
            False,
            False,
            "daemon is not running",
            "halton-meter daemon",
        ),
    ],
    ids=["healthy_proxy_on", "healthy_proxy_off", "daemon_down"],
)
def test_empty_records_hint_branches(
    monkeypatch: pytest.MonkeyPatch,
    daemon_up: bool,
    proxy_on: bool,
    expected_phrase: str,
    forbidden_phrase: str,
) -> None:
    """Each daemon-state branch yields the right user-facing message."""
    monkeypatch.setattr(cli_module, "_health_ok", lambda *_a, **_kw: daemon_up)
    monkeypatch.setattr(
        cli_module, "_system_proxy_enabled", lambda *_a, **_kw: proxy_on
    )

    cfg = _StubDaemonCfg()
    hint = cli_module._empty_records_hint(cfg)
    assert expected_phrase in hint
    # The dev-mode foreground command must never appear in any
    # empty-records hint we ship to end users.
    assert forbidden_phrase not in hint
    # The two non-healthy branches should recommend `halton-meter start`.
    # The fully-healthy branch needs no command — just tells the user to
    # make an API call.
    if not (daemon_up and proxy_on):
        assert "halton-meter start" in hint


def test_uninstall_yes_flag_skips_prompt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``--yes`` skips interactive confirmation entirely (CI/scripted use)."""
    from halton_meter import install as install_module

    captured: dict[str, Any] = {}

    def fake_uninstall(*, purge: bool, include_logs: bool, graceful: bool = False) -> int:
        captured["purge"] = purge
        captured["include_logs"] = include_logs
        return 0

    monkeypatch.setattr(install_module, "uninstall", fake_uninstall)
    monkeypatch.setattr(
        install_module, "count_request_records", lambda _path: (0, 0)
    )

    runner = CliRunner()
    result = runner.invoke(
        cli_module.cli,
        ["uninstall", "--purge", "--include-logs", "--yes"],
    )
    assert result.exit_code == 0
    assert captured == {"purge": True, "include_logs": True}


# --------------------------------------------------------------------------- #
# Gap 8 — `--version` flag (v0.1.8)                                            #
# --------------------------------------------------------------------------- #


def test_version_flag_prints_package_version() -> None:
    """`halton-meter --version` must print the installed version.

    Convention says both `--version` and the legacy `version` subcommand work.
    Regression guard for v0.1.7 smoke-test finding.
    """
    from halton_meter import __version__

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["--version"])
    assert result.exit_code == 0
    assert f"halton-meter, version {__version__}" in result.output


def test_version_subcommand_still_works() -> None:
    """The pre-existing `version` subcommand must keep working (back-compat)."""
    from halton_meter import __version__

    runner = CliRunner()
    result = runner.invoke(cli_module.cli, ["version"])
    assert result.exit_code == 0
    assert __version__ in result.output


# --------------------------------------------------------------------------- #
# v0.1.20.1: asyncio-native signal handling + post-bind health probe          #
# --------------------------------------------------------------------------- #


def test_probe_listeners_post_bind_success(monkeypatch: pytest.MonkeyPatch) -> None:
    """Both probes succeed → event NOT set, no failure flag.

    v0.1.21.3: api-port probe is now HTTP GET ``/health`` instead of
    TCP-connect. We monkeypatch ``_http_probe_health`` to return True
    (a stub HTTP origin keeps the test focused on probe orchestration,
    not on FastAPI routing).
    """
    import asyncio
    import socket

    # Bind a loopback socket for the mitm-port TCP probe.
    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s2.bind(("127.0.0.1", 0))
    s2.listen(1)

    async def _fake_http(*_a: Any, **_kw: Any) -> bool:
        return True

    monkeypatch.setattr(cli_module, "_http_probe_health", _fake_http)

    try:
        api_port = 65000  # not bound — HTTP probe is stubbed True
        mitm_port = s2.getsockname()[1]

        async def _run() -> None:
            event = asyncio.Event()
            await cli_module._probe_listeners_post_bind(
                api_host="127.0.0.1",
                api_port=api_port,
                mitm_host="127.0.0.1",
                mitm_port=mitm_port,
                shutdown_event=event,
                delay_s=0.0,
            )
            assert not event.is_set()
            assert not getattr(event, "_halton_probe_failed", False)

        asyncio.run(_run())
    finally:
        s2.close()


@pytest.fixture
def _reset_structlog() -> Any:
    """Reset structlog defaults after a test that calls
    :func:`_configure_daemon_logging`. The production config binds
    ``sys.stderr`` at config time; pytest's ``capsys`` swaps stderr
    back after the test, leaving the cached PrintLogger pointing at
    a closed file and breaking subsequent tests.
    """
    import structlog as _sl

    yield
    _sl.reset_defaults()


def test_probe_listeners_post_bind_emits_ready_on_success(
    capsys: pytest.CaptureFixture[str],
    _reset_structlog: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.1: on successful probe, the function must emit a
    ``daemon.startup.ready`` event with ``total_startup_ms`` so the
    err log carries an unambiguous "fully up" line.
    """
    import asyncio
    import socket
    import time

    cli_module._configure_daemon_logging()

    async def _fake_http(*_a: Any, **_kw: Any) -> bool:
        return True

    monkeypatch.setattr(cli_module, "_http_probe_health", _fake_http)

    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s2.bind(("127.0.0.1", 0))
    s2.listen(1)

    try:
        api_port = 65001  # HTTP probe is stubbed; only mitm port needs to bind
        mitm_port = s2.getsockname()[1]

        async def _run() -> None:
            event = asyncio.Event()
            await cli_module._probe_listeners_post_bind(
                api_host="127.0.0.1",
                api_port=api_port,
                mitm_host="127.0.0.1",
                mitm_port=mitm_port,
                shutdown_event=event,
                delay_s=0.0,
                startup_t0=time.perf_counter(),
            )

        asyncio.run(_run())

        captured = capsys.readouterr().err
        assert "daemon.startup.ready" in captured
        assert f"mitm_port={mitm_port}" in captured
        assert "total_startup_ms" in captured
    finally:
        s2.close()


def test_probe_listeners_post_bind_failure_sets_event_and_flag() -> None:
    """When neither port is bound, probe flags failure + sets event."""
    import asyncio

    async def _run() -> None:
        event = asyncio.Event()
        # Use ports we know are not bound (high range, unlikely collision).
        await cli_module._probe_listeners_post_bind(
            api_host="127.0.0.1",
            api_port=1,  # privileged, refused / unreachable as a regular user
            mitm_host="127.0.0.1",
            mitm_port=2,
            shutdown_event=event,
            delay_s=0.0,
        )
        assert event.is_set()
        assert getattr(event, "_halton_probe_failed", False) is True

    asyncio.run(_run())


def test_probe_waits_for_mitm_ready_event_before_firing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.2: when ``mitm_ready_event`` is supplied, the probe must
    wait for it to be set before TCP-connecting. Without this gate the
    probe could race mitmproxy on cold boot and false-kill a healthy
    startup.
    """
    import asyncio
    import socket

    async def _fake_http(*_a: Any, **_kw: Any) -> bool:
        return True

    monkeypatch.setattr(cli_module, "_http_probe_health", _fake_http)

    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s2.bind(("127.0.0.1", 0))
    s2.listen(1)
    try:
        api_port = 65002  # HTTP probe stubbed
        mitm_port = s2.getsockname()[1]

        async def _run() -> None:
            event = asyncio.Event()
            ready = asyncio.Event()
            probe_task = asyncio.create_task(
                cli_module._probe_listeners_post_bind(
                    api_host="127.0.0.1",
                    api_port=api_port,
                    mitm_host="127.0.0.1",
                    mitm_port=mitm_port,
                    shutdown_event=event,
                    delay_s=0.0,
                    mitm_ready_event=ready,
                    mitm_ready_timeout_s=5.0,
                )
            )
            # Probe must NOT have completed yet — it's awaiting ready.
            await asyncio.sleep(0.1)
            assert not probe_task.done(), (
                "probe must wait for mitm_ready_event before TCP-connecting"
            )
            # Set the ready event; probe should now complete successfully.
            ready.set()
            await asyncio.wait_for(probe_task, timeout=2.0)
            assert not event.is_set()
            assert not getattr(event, "_halton_probe_failed", False)

        asyncio.run(_run())
    finally:
        s2.close()


def test_probe_times_out_cleanly_when_mitm_ready_never_fires() -> None:
    """v0.1.21.2: if ``mitm_ready_event`` is never set, the probe must
    time out at ``mitm_ready_timeout_s`` and trigger orderly shutdown
    (set the failure flag + the shutdown event) — never hang silently.
    """
    import asyncio

    async def _run() -> None:
        event = asyncio.Event()
        ready = asyncio.Event()  # intentionally never set
        await cli_module._probe_listeners_post_bind(
            api_host="127.0.0.1",
            api_port=1,
            mitm_host="127.0.0.1",
            mitm_port=2,
            shutdown_event=event,
            delay_s=0.0,
            mitm_ready_event=ready,
            mitm_ready_timeout_s=0.05,
        )
        assert event.is_set()
        assert getattr(event, "_halton_probe_failed", False) is True

    asyncio.run(_run())


def test_run_daemon_signal_handler_uses_loop_add_signal_handler() -> None:
    """v0.1.20.1: regression guard via static inspection.

    A synchronous ``signal.signal(SIGTERM, _chained)`` handler that
    called ``sys.exit`` raced uvicorn's ``capture_signals`` re-raise
    during loop teardown — the cold-boot zombie. The asyncio-native
    path uses ``loop.add_signal_handler``; we assert the handler
    registration site exists in source and that no synchronous
    ``signal.signal(SIGTERM`` install survives in cli or system_proxy.
    """
    from pathlib import Path

    cli_src = Path(cli_module.__file__).read_text()
    sp_src = Path(system_proxy.__file__).read_text()

    # The good registration must be present in cli._run_daemon.
    assert "loop.add_signal_handler" in cli_src, (
        "_run_daemon must register signal handlers via "
        "loop.add_signal_handler (asyncio-native path)"
    )
    # The bad registration must NOT survive in either module.
    assert "signal.signal(sig, _chained)" not in sp_src, (
        "system_proxy must not install synchronous signal handlers — "
        "they race uvicorn capture_signals re-raise during loop teardown"
    )
    assert "signal.signal(_signal.SIGTERM" not in cli_src
    # And sys.exit MUST NOT live inside a signal callback in cli.
    # (handler is _on_signal which only calls shutdown_requested.set())
    assert "shutdown_requested.set()" in cli_src


# --------------------------------------------------------------------------- #
# v0.1.21.1 — startup instrumentation + exit-reason capture                    #
# --------------------------------------------------------------------------- #


def test_configure_daemon_logging_emits_iso_timestamp(
    capsys: pytest.CaptureFixture[str],
    _reset_structlog: Any,
) -> None:
    """v0.1.21.1: every event emitted by the daemon process must carry
    an ISO-8601 timestamp so ``daemon.err.log`` is diagnosable.

    Drives :func:`_configure_daemon_logging` (the production config
    used inside ``_run_daemon``) and asserts the rendered line carries
    a parseable ISO-8601 ``timestamp=...`` field. We don't pin the exact
    format string — structlog's ``TimeStamper(fmt='iso')`` is the
    contract; we only assert the shape.
    """
    import datetime as _dt
    import re

    import structlog

    cli_module._configure_daemon_logging()
    log = structlog.get_logger("halton_meter.tests.startup")
    log.info("daemon.startup.phase", phase="entered")

    captured = capsys.readouterr()
    line = captured.err.strip().splitlines()[-1]
    # ConsoleRenderer prints ``timestamp`` as a leading bracketed field;
    # the format is stable: ISO-8601 with 'T' separator and trailing 'Z'
    # under utc=True. Find an ISO-shaped substring and parse it.
    match = re.search(
        r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?", line
    )
    assert match is not None, f"no ISO-8601 timestamp in {line!r}"
    iso = match.group(0)
    # Round-trip parse to assert the format is valid, not just shape.
    _dt.datetime.fromisoformat(iso.replace("Z", "+00:00"))
    assert "daemon.startup.phase" in line
    assert "phase=entered" in line


def test_run_daemon_source_emits_required_startup_phases() -> None:
    """v0.1.21.1: ``_run_daemon`` must emit the documented sequence of
    ``daemon.startup.phase`` events. Source-grep is the right tool here
    — driving the actual coroutine is heavy (mitmproxy DumpMaster +
    uvicorn) and a behavioural test would only assert what a static
    grep already tells us. If the contract changes, this test needs
    updating (intentional).
    """
    from pathlib import Path

    from halton_meter import proxy as proxy_module

    cli_src = Path(cli_module.__file__).read_text()
    proxy_src = Path(proxy_module.__file__).read_text()

    # cli._run_daemon emits these:
    for phase in ("entered", "storage_initialised", "fastapi_serve_begin"):
        assert f'phase="{phase}"' in cli_src, (
            f"_run_daemon must emit daemon.startup.phase phase={phase!r}"
        )
    # proxy.run_proxy emits these around DumpMaster construction:
    for phase in ("mitm_construct_begin", "mitm_construct_end"):
        assert f'phase="{phase}"' in proxy_src, (
            f"run_proxy must emit daemon.startup.phase phase={phase!r}"
        )
    # The ready event lives in _probe_listeners_post_bind on the success
    # path so it fires only after BOTH listeners are confirmed bound.
    assert '"daemon.startup.ready"' in cli_src


def test_run_daemon_registers_atexit_exit_logger() -> None:
    """v0.1.21.1: the daemon must register an ``atexit`` hook at the
    TOP of ``_run_daemon`` (before any setup that can raise) so we get
    exit telemetry no matter how the process dies.
    """
    from pathlib import Path

    cli_src = Path(cli_module.__file__).read_text()
    assert "atexit.register(_log_exit_reason)" in cli_src
    # And the hook must emit ``daemon.exit`` with reason + uptime.
    assert '"daemon.exit"' in cli_src
    assert "uptime_s" in cli_src


def test_run_daemon_signal_handler_logs_shutdown_signal_event() -> None:
    """v0.1.21.1: ``_on_signal`` must emit ``daemon.shutdown.signal``
    BEFORE ``shutdown_requested.set()`` so the err log shows the
    trigger ahead of teardown chatter.
    """
    from pathlib import Path

    cli_src = Path(cli_module.__file__).read_text()
    # The two source events must appear in this order inside _on_signal.
    sig_idx = cli_src.find('"daemon.shutdown.signal"')
    set_idx = cli_src.find("shutdown_requested.set()", sig_idx)
    assert sig_idx != -1, "_on_signal must log daemon.shutdown.signal"
    assert set_idx != -1 and set_idx > sig_idx, (
        "daemon.shutdown.signal must be logged BEFORE "
        "shutdown_requested.set()"
    )


def test_run_daemon_catches_system_exit_and_base_exception() -> None:
    """v0.1.21.1: the daemon body wraps its main wait in handlers for
    SystemExit (warning) and BaseException (error) so we know if a
    code path ever calls sys.exit() or raises something exotic. Both
    handlers re-raise after logging.
    """
    from pathlib import Path

    cli_src = Path(cli_module.__file__).read_text()
    assert "except SystemExit" in cli_src
    assert 'reason="system_exit"' in cli_src
    assert "except BaseException" in cli_src
    assert 'reason="exception"' in cli_src


# --------------------------------------------------------------------------- #
# v0.1.21.3: HTTP /health probe + 5x retry                                     #
# --------------------------------------------------------------------------- #


def test_http_probe_health_returns_true_on_200(monkeypatch: pytest.MonkeyPatch) -> None:
    """The HTTP probe returns True iff GET /health responds 200."""
    import asyncio

    monkeypatch.setattr(
        cli_module, "_http_get_returns_200",
        lambda url, timeout: True,
    )

    async def _run() -> bool:
        return await cli_module._http_probe_health("127.0.0.1", 9999, timeout=0.1)

    assert asyncio.run(_run()) is True


def test_http_probe_health_returns_false_on_connection_refused() -> None:
    """Real connection-refused → False, never raises."""
    import asyncio

    async def _run() -> bool:
        # Port 1 is privileged + unbound for a regular user → refused.
        return await cli_module._http_probe_health("127.0.0.1", 1, timeout=0.2)

    assert asyncio.run(_run()) is False


def test_http_probe_health_returns_false_on_non_200(monkeypatch: pytest.MonkeyPatch) -> None:
    """Non-200 status → False."""
    import asyncio

    monkeypatch.setattr(
        cli_module, "_http_get_returns_200",
        lambda url, timeout: False,
    )

    async def _run() -> bool:
        return await cli_module._http_probe_health("127.0.0.1", 9999, timeout=0.1)

    assert asyncio.run(_run()) is False


def test_probe_retries_api_health_up_to_5_times_before_failing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.3: the api-port HTTP probe retries up to 5 times with
    200ms backoff so a cold-start FastAPI route registration window
    (~1s after uvicorn bind) doesn't false-fail the probe.
    """
    import asyncio
    import socket

    # Bind an mitm socket — that probe must succeed.
    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s2.bind(("127.0.0.1", 0))
    s2.listen(1)

    call_count = {"n": 0}

    async def _flaky_http(*_a: Any, **_kw: Any) -> bool:
        call_count["n"] += 1
        return False  # always fails

    monkeypatch.setattr(cli_module, "_http_probe_health", _flaky_http)

    try:
        mitm_port = s2.getsockname()[1]

        async def _run() -> None:
            event = asyncio.Event()
            await cli_module._probe_listeners_post_bind(
                api_host="127.0.0.1",
                api_port=65003,
                mitm_host="127.0.0.1",
                mitm_port=mitm_port,
                shutdown_event=event,
                delay_s=0.0,
            )
            assert event.is_set()
            assert getattr(event, "_halton_probe_failed", False) is True

        asyncio.run(_run())
        # Exactly 5 retries.
        assert call_count["n"] == 5
    finally:
        s2.close()


def test_probe_retries_then_succeeds(monkeypatch: pytest.MonkeyPatch) -> None:
    """The 3rd retry returning 200 lets a slow-cold-start succeed."""
    import asyncio
    import socket

    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s2.bind(("127.0.0.1", 0))
    s2.listen(1)

    state = {"n": 0}

    async def _slow_to_warm(*_a: Any, **_kw: Any) -> bool:
        state["n"] += 1
        return state["n"] >= 3

    monkeypatch.setattr(cli_module, "_http_probe_health", _slow_to_warm)

    try:
        mitm_port = s2.getsockname()[1]

        async def _run() -> None:
            event = asyncio.Event()
            await cli_module._probe_listeners_post_bind(
                api_host="127.0.0.1",
                api_port=65004,
                mitm_host="127.0.0.1",
                mitm_port=mitm_port,
                shutdown_event=event,
                delay_s=0.0,
            )
            assert not event.is_set()
            assert not getattr(event, "_halton_probe_failed", False)

        asyncio.run(_run())
        assert state["n"] == 3
    finally:
        s2.close()
