"""Tests for ``halton_meter.observability`` (v0.1.16 Q4.1 + Q4.2).

Heartbeat dispatch + asyncio task crash hook. The heartbeat is exercised
with mocked probes so we never bind real ports or read a real DB; the
crash hook is exercised against a real asyncio loop with a task that
raises.
"""

from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path

import pytest
from structlog.testing import capture_logs

from halton_meter import observability

# --------------------------------------------------------------------------- #
# emit_heartbeat                                                              #
# --------------------------------------------------------------------------- #


def test_emit_heartbeat_logs_payload_with_all_probes_passing(
    tmp_path: Path,
) -> None:
    """Happy path: every probe returns truthy; one ``daemon.heartbeat``
    log line is emitted carrying all five fields."""
    db = tmp_path / "db.sqlite"
    with capture_logs() as logs:
        payload = observability.emit_heartbeat(
            mitm_port=8090,
            api_port=8765,
            db_path=db,
            probe_mitm=lambda port: True,
            probe_api=lambda port: True,
            probe_db=lambda path: True,
            probe_fds=lambda: 42,
        )

    assert payload == {
        "mitm_port": 8090,
        "mitm_listening": True,
        "api_port": 8765,
        "api_listening": True,
        "db_writeable": True,
        "open_fds": 42,
    }
    heartbeats = [r for r in logs if r["event"] == "daemon.heartbeat"]
    assert len(heartbeats) == 1
    rec = heartbeats[0]
    assert rec["mitm_port"] == 8090
    assert rec["mitm_listening"] is True
    assert rec["api_port"] == 8765
    assert rec["api_listening"] is True
    assert rec["db_writeable"] is True
    assert rec["open_fds"] == 42


def test_emit_heartbeat_still_emits_when_db_probe_raises(
    tmp_path: Path,
) -> None:
    """Q4.1 invariant: a probe failure flips THAT field to False but the
    heartbeat MUST still emit. Other fields keep their real values."""
    db = tmp_path / "db.sqlite"

    def _boom(_path: Path) -> bool:
        raise sqlite3.OperationalError("disk I/O error")

    with capture_logs() as logs:
        payload = observability.emit_heartbeat(
            mitm_port=8090,
            api_port=8765,
            db_path=db,
            probe_mitm=lambda port: True,
            probe_api=lambda port: True,
            probe_db=_boom,
            probe_fds=lambda: 7,
        )

    assert payload["db_writeable"] is False
    assert payload["mitm_listening"] is True
    assert payload["api_listening"] is True
    assert payload["open_fds"] == 7

    heartbeats = [r for r in logs if r["event"] == "daemon.heartbeat"]
    assert len(heartbeats) == 1
    assert heartbeats[0]["db_writeable"] is False


def test_emit_heartbeat_handles_fd_probe_failure(tmp_path: Path) -> None:
    """When the FD probe explodes the heartbeat reports -1 (sentinel) and
    keeps emitting. Asserts no exception escapes."""
    db = tmp_path / "db.sqlite"

    def _fd_boom() -> int:
        raise RuntimeError("psutil unavailable")

    with capture_logs() as logs:
        payload = observability.emit_heartbeat(
            mitm_port=8090,
            api_port=8765,
            db_path=db,
            probe_mitm=lambda port: False,
            probe_api=lambda port: False,
            probe_db=lambda path: False,
            probe_fds=_fd_boom,
        )

    assert payload["open_fds"] == -1
    assert payload["mitm_listening"] is False
    heartbeats = [r for r in logs if r["event"] == "daemon.heartbeat"]
    assert len(heartbeats) == 1


# --------------------------------------------------------------------------- #
# heartbeat_loop                                                              #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_heartbeat_loop_emits_then_cancels(tmp_path: Path) -> None:
    """A short-interval heartbeat task fires at least once when given
    time to tick, then cancels cleanly on shutdown."""
    db = tmp_path / "db.sqlite"
    with capture_logs() as logs:
        task = asyncio.create_task(
            observability.heartbeat_loop(
                mitm_port=1,
                api_port=2,
                db_path=db,
                interval=0.01,
                probe_mitm=lambda port: True,
                probe_api=lambda port: True,
                probe_db=lambda path: True,
                probe_fds=lambda: 5,
            ),
            name="test-heartbeat",
        )
        # Yield enough times for the loop to tick at least once.
        await asyncio.sleep(0.05)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task

    heartbeats = [r for r in logs if r["event"] == "daemon.heartbeat"]
    assert len(heartbeats) >= 1


# --------------------------------------------------------------------------- #
# install_task_crash_handler                                                  #
# --------------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_task_crash_handler_logs_task_name_and_exception() -> None:
    """A task that raises produces a ``daemon.task_crashed`` log line
    carrying the task's name and the exception type. Drives
    ``call_exception_handler`` with a real Task context for determinism
    (the natural unretrieved-exception path is GC-driven and flakey
    inside pytest-asyncio)."""
    loop = asyncio.get_running_loop()
    observability.install_task_crash_handler(loop)

    # Build a real Task so the handler can pull the task name via
    # ``get_name()`` exactly as it does in production.
    async def _noop() -> None:
        return None

    task = asyncio.create_task(_noop(), name="mitm-acceptor")
    await task  # let it complete cleanly
    exc = ValueError("boom from doomed task")

    with capture_logs() as logs:
        loop.call_exception_handler(
            {
                "message": "Task exception was never retrieved",
                "exception": exc,
                "task": task,
            }
        )

    crash_records = [r for r in logs if r["event"] == "daemon.task_crashed"]
    assert crash_records, f"expected daemon.task_crashed log line; got {logs!r}"
    rec = crash_records[0]
    assert rec["exception_type"] == "ValueError"
    assert "boom from doomed task" in (rec.get("exception_message") or "")
    assert rec["task"] == "mitm-acceptor"
    # Restore default to keep teardown clean.
    loop.set_exception_handler(None)


@pytest.mark.asyncio
async def test_task_crash_handler_chains_to_previous_handler() -> None:
    """The new handler must call the previously installed handler so
    nothing downstream loses visibility."""
    loop = asyncio.get_running_loop()

    seen_by_previous: list[dict[str, object]] = []

    def _previous(
        _loop: asyncio.AbstractEventLoop, context: dict[str, object]
    ) -> None:
        seen_by_previous.append(context)

    loop.set_exception_handler(_previous)
    observability.install_task_crash_handler(loop)

    # Drive a fake call_exception_handler invocation. This is the
    # cleanest way to assert the chaining contract without depending
    # on GC timing.
    fake_context: dict[str, object] = {
        "message": "Task exception was never retrieved",
        "exception": RuntimeError("synthetic"),
    }
    loop.call_exception_handler(fake_context)
    # Restore default to keep teardown clean.
    loop.set_exception_handler(None)

    assert len(seen_by_previous) == 1
    assert seen_by_previous[0]["message"] == "Task exception was never retrieved"


@pytest.mark.asyncio
async def test_task_crash_handler_does_not_raise_on_malformed_context() -> None:
    """The handler MUST swallow its own internal failures — a handler
    that raises trips the loop into an unrecoverable state."""
    loop = asyncio.get_running_loop()
    observability.install_task_crash_handler(loop)

    # Context with an exception that has no useful repr; handler must
    # cope without raising.
    class _NastyExc(Exception):
        def __str__(self) -> str:
            raise RuntimeError("repr-time failure")

    # capture_logs prevents the chained default handler from spamming
    # stderr in test output.
    with capture_logs():
        # Should not raise — the handler eats internal failures.
        loop.call_exception_handler(
            {"message": "synthetic", "exception": _NastyExc()}
        )
    loop.set_exception_handler(None)
