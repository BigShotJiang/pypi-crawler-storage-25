"""
Unit tests for XAIAdapter.

xAI exposes BOTH OpenAI- and Anthropic-shape APIs on the same host
(``api.x.ai``). The adapter URL-dispatches to sibling parsers (held as
private module-level instances of OpenAIAdapter / AnthropicAdapter) and
relabels ``RequestMetadata.provider`` to ``"xai"`` regardless of which
sibling parsed the body.

All tests use recorded fixtures — no live network calls.

Fixture files in tests/fixtures/xai/:
  chat_completion_basic.json     — non-streaming OpenAI-shape Grok response
  chat_completion_streaming.txt  — SSE OpenAI-shape Grok response (with usage)
  messages_basic.json            — non-streaming Anthropic-shape Grok response
  messages_streaming.txt         — SSE Anthropic-shape Grok response
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters import xai as xai_module
from halton_meter.adapters.anthropic import AnthropicAdapter
from halton_meter.adapters.base import ProviderAdapter, RequestMetadata
from halton_meter.adapters.gemini import GeminiAdapter
from halton_meter.adapters.openai import OpenAIAdapter
from halton_meter.adapters.xai import XAIAdapter
from halton_meter.pricing import compute_cost_millicents
from halton_meter.proxy import ADAPTER_REGISTRY

FIXTURES = Path(__file__).parent.parent / "fixtures" / "xai"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_flow(
    path: str = "/v1/chat/completions",
    request_body: dict | None = None,
    response_body: str | bytes | None = None,
    content_type: str = "application/json",
) -> http.HTTPFlow:
    req_content = (
        json.dumps(request_body or {}).encode()
        if request_body is not None
        else b""
    )
    req = tutils.treq(host="api.x.ai", port=443, path=path)
    req.content = req_content

    flow = tflow.tflow(req=req)

    if response_body is not None:
        body_bytes = (
            response_body.encode() if isinstance(response_body, str) else response_body
        )
        flow.response = http.Response.make(
            200,
            body_bytes,
            {"Content-Type": content_type},
        )

    return flow


def _make_request_meta(model: str = "grok-4-mini", stream: bool = False) -> RequestMetadata:
    return RequestMetadata(
        provider="xai",
        model=model,
        stream=stream,
        started_at=time.monotonic() - 0.5,
    )


# ---------------------------------------------------------------------------
# matches() / matches_url()
# ---------------------------------------------------------------------------


class TestMatches:
    def test_matches_exact_host(self) -> None:
        assert XAIAdapter().matches("api.x.ai") is True

    def test_matches_host_with_port(self) -> None:
        assert XAIAdapter().matches("api.x.ai:443") is True

    def test_does_not_match_other_host(self) -> None:
        assert XAIAdapter().matches("api.openai.com") is False

    def test_rejects_trailing_suffix_injection(self) -> None:
        assert XAIAdapter().matches("api.x.ai.evil.com") is False

    def test_rejects_leading_subdomain_injection(self) -> None:
        assert XAIAdapter().matches("evil.api.x.ai") is False


class TestMatchesUrl:
    def test_accepts_chat_completions(self) -> None:
        assert XAIAdapter().matches_url("api.x.ai", "/v1/chat/completions") is True

    def test_accepts_messages(self) -> None:
        assert XAIAdapter().matches_url("api.x.ai", "/v1/messages") is True

    def test_accepts_chat_completions_with_query(self) -> None:
        assert (
            XAIAdapter().matches_url("api.x.ai", "/v1/chat/completions?foo=bar")
            is True
        )

    def test_rejects_unknown_path(self) -> None:
        assert XAIAdapter().matches_url("api.x.ai", "/v1/embeddings") is False
        assert XAIAdapter().matches_url("api.x.ai", "/v1/moderations") is False
        assert XAIAdapter().matches_url("api.x.ai", "/") is False

    def test_rejects_other_host(self) -> None:
        assert XAIAdapter().matches_url("api.openai.com", "/v1/chat/completions") is False


# ---------------------------------------------------------------------------
# parse_request() — URL dispatch + provider override
# ---------------------------------------------------------------------------


class TestParseRequest:
    def test_chat_completions_provider_is_xai(self) -> None:
        flow = _make_flow(
            path="/v1/chat/completions",
            request_body={"model": "grok-4-mini", "messages": []},
        )
        meta = XAIAdapter().parse_request(flow)
        assert meta.provider == "xai"
        assert meta.model == "grok-4-mini"
        assert meta.stream is False

    def test_messages_provider_is_xai(self) -> None:
        flow = _make_flow(
            path="/v1/messages",
            request_body={"model": "grok-4", "messages": []},
        )
        meta = XAIAdapter().parse_request(flow)
        assert meta.provider == "xai"
        assert meta.model == "grok-4"
        assert meta.stream is False

    def test_chat_completions_stream_true(self) -> None:
        flow = _make_flow(
            path="/v1/chat/completions",
            request_body={"model": "grok-4", "stream": True, "messages": []},
        )
        meta = XAIAdapter().parse_request(flow)
        assert meta.stream is True
        assert meta.provider == "xai"

    def test_messages_stream_true(self) -> None:
        flow = _make_flow(
            path="/v1/messages",
            request_body={"model": "grok-4", "stream": True, "messages": []},
        )
        meta = XAIAdapter().parse_request(flow)
        assert meta.stream is True
        assert meta.provider == "xai"

    def test_unknown_path_returns_defaults_no_raise(self) -> None:
        # Defensive default: matches_url should filter this, but parse_request
        # MUST NOT raise even if it slips through.
        flow = _make_flow(path="/v1/embeddings", request_body={"model": "grok-x"})
        meta = XAIAdapter().parse_request(flow)
        assert meta.provider == "xai"
        assert meta.model == "unknown"


# ---------------------------------------------------------------------------
# parse_response() — URL dispatch into the matching sibling parser
# ---------------------------------------------------------------------------


class TestParseResponseChatCompletions:
    def test_non_streaming_chat_completion(self) -> None:
        body = (FIXTURES / "chat_completion_basic.json").read_text()
        flow = _make_flow(path="/v1/chat/completions", response_body=body)
        meta = XAIAdapter().parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 41
        assert meta.output_tokens == 18
        assert meta.thinking_tokens == 0
        assert meta.cache_read_tokens == 0
        assert meta.cache_write_tokens == 0
        assert meta.tokens_complete is True
        assert meta.latency_ms > 0

    def test_streaming_chat_completion(self) -> None:
        body = (FIXTURES / "chat_completion_streaming.txt").read_text()
        flow = _make_flow(
            path="/v1/chat/completions",
            response_body=body,
            content_type="text/event-stream",
        )
        meta = XAIAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        assert meta.input_tokens == 29
        assert meta.output_tokens == 11
        assert meta.tokens_complete is True


class TestParseResponseMessages:
    def test_non_streaming_messages(self) -> None:
        body = (FIXTURES / "messages_basic.json").read_text()
        flow = _make_flow(path="/v1/messages", response_body=body)
        meta = XAIAdapter().parse_response(
            flow, _make_request_meta(model="grok-4")
        )
        assert meta.input_tokens == 53
        assert meta.output_tokens == 21
        assert meta.thinking_tokens == 0
        assert meta.cache_read_tokens == 0
        assert meta.cache_write_tokens == 0
        assert meta.tokens_complete is True

    def test_streaming_messages(self) -> None:
        body = (FIXTURES / "messages_streaming.txt").read_text()
        flow = _make_flow(
            path="/v1/messages",
            response_body=body,
            content_type="text/event-stream",
        )
        meta = XAIAdapter().parse_response(
            flow, _make_request_meta(model="grok-4", stream=True)
        )
        # Anthropic SSE shape: input_tokens come from message_start; output
        # tokens are read ONLY from message_delta (the message_start's
        # placeholder output_tokens=1 is intentionally ignored by the
        # Anthropic adapter we delegate to).
        assert meta.input_tokens == 37
        assert meta.output_tokens == 14
        assert meta.tokens_complete is True


# ---------------------------------------------------------------------------
# URL-dispatch correctness — verify which sibling fired
# ---------------------------------------------------------------------------


class TestURLDispatch:
    def test_chat_completions_routes_to_openai_sibling(self, monkeypatch) -> None:
        called: dict[str, bool] = {}

        original = xai_module._OPENAI_SIBLING.parse_request

        def spy(flow):
            called["openai"] = True
            return original(flow)

        monkeypatch.setattr(xai_module._OPENAI_SIBLING, "parse_request", spy)

        flow = _make_flow(
            path="/v1/chat/completions",
            request_body={"model": "grok-4-mini"},
        )
        XAIAdapter().parse_request(flow)
        assert called.get("openai") is True

    def test_messages_routes_to_anthropic_sibling(self, monkeypatch) -> None:
        called: dict[str, bool] = {}

        original = xai_module._ANTHROPIC_SIBLING.parse_request

        def spy(flow):
            called["anthropic"] = True
            return original(flow)

        monkeypatch.setattr(xai_module._ANTHROPIC_SIBLING, "parse_request", spy)

        flow = _make_flow(
            path="/v1/messages",
            request_body={"model": "grok-4"},
        )
        XAIAdapter().parse_request(flow)
        assert called.get("anthropic") is True


# ---------------------------------------------------------------------------
# Provider override is the load-bearing fix — covers (a) chat path and
# (b) messages path so a future change to either delegation can't silently
# leak the sibling's provider name into DB rows.
# ---------------------------------------------------------------------------


class TestProviderOverride:
    def test_provider_override_chat_completions(self) -> None:
        flow = _make_flow(
            path="/v1/chat/completions",
            request_body={"model": "grok-4-mini"},
        )
        meta = XAIAdapter().parse_request(flow)
        assert meta.provider == "xai"
        # Sanity: the sibling alone would return "openai".
        assert OpenAIAdapter().parse_request(flow).provider == "openai"

    def test_provider_override_messages(self) -> None:
        flow = _make_flow(
            path="/v1/messages",
            request_body={"model": "grok-4"},
        )
        meta = XAIAdapter().parse_request(flow)
        assert meta.provider == "xai"
        # Sanity: the sibling alone would return "anthropic".
        assert AnthropicAdapter().parse_request(flow).provider == "anthropic"


# ---------------------------------------------------------------------------
# Pricing integration
# ---------------------------------------------------------------------------


class TestPricingIntegration:
    def test_chat_completion_cost_positive(self) -> None:
        cost = compute_cost_millicents(
            model="grok-4-mini",
            input_tokens=41,
            output_tokens=18,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        assert cost is not None
        assert cost > 0

    def test_messages_cost_positive(self) -> None:
        cost = compute_cost_millicents(
            model="grok-4",
            input_tokens=53,
            output_tokens=21,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        assert cost is not None
        assert cost > 0

    def test_unknown_grok_model_returns_none(self) -> None:
        cost = compute_cost_millicents(
            model="grok-imaginary",
            input_tokens=10,
            output_tokens=10,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        assert cost is None


# ---------------------------------------------------------------------------
# Wiring
# ---------------------------------------------------------------------------


class TestWiring:
    def test_adapter_in_registry(self) -> None:
        assert any(isinstance(a, XAIAdapter) for a in ADAPTER_REGISTRY)

    def test_adapter_satisfies_protocol(self) -> None:
        assert isinstance(XAIAdapter(), ProviderAdapter)

    def test_registered_after_gemini(self) -> None:
        # Host is unique so ordering is not load-bearing for correctness, but
        # the per-PR rollout pattern keeps xAI after Gemini. Pin it here so a
        # future re-order is a deliberate edit, not an accident.
        gemini_idx = next(
            i for i, a in enumerate(ADAPTER_REGISTRY) if isinstance(a, GeminiAdapter)
        )
        xai_idx = next(
            i for i, a in enumerate(ADAPTER_REGISTRY) if isinstance(a, XAIAdapter)
        )
        assert xai_idx > gemini_idx
