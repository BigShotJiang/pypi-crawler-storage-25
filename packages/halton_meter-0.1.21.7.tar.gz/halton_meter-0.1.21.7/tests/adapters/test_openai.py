"""
Unit tests for OpenAIAdapter.

All tests use recorded fixtures — no live network calls. Flows are constructed
with mitmproxy's tflow/tutils helpers, which produce fully typed HTTPFlow
objects without touching the network.

Fixture files in tests/fixtures/openai/:
  chat_completion_basic.json                  — non-streaming chat with cached_tokens > 0
  chat_completion_streaming_with_usage.txt    — SSE with final usage chunk
  chat_completion_streaming_no_usage.txt      — SSE WITHOUT usage chunk (common case)
  o1_response.json                            — non-streaming with reasoning_tokens
  responses_streaming.txt                     — Responses API SSE with response.completed
  embeddings_response.json                    — embeddings (input-only billing)
  tool_call_response.json                     — chat completion with tool call
  truncated_body.txt                          — partial SSE bytes
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters.base import ProviderAdapter, RequestMetadata
from halton_meter.adapters.openai import OpenAIAdapter
from halton_meter.pricing import compute_cost_millicents
from halton_meter.proxy import ADAPTER_REGISTRY

FIXTURES = Path(__file__).parent.parent / "fixtures" / "openai"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_flow(
    path: str = "/v1/chat/completions",
    request_body: dict | None = None,
    response_body: str | bytes | None = None,
    content_type: str = "application/json",
) -> http.HTTPFlow:
    req_content = (
        json.dumps(request_body or {}).encode()
        if request_body is not None
        else b""
    )
    req = tutils.treq(host="api.openai.com", port=443, path=path)
    req.content = req_content

    flow = tflow.tflow(req=req)

    if response_body is not None:
        body_bytes = (
            response_body.encode() if isinstance(response_body, str) else response_body
        )
        flow.response = http.Response.make(
            200,
            body_bytes,
            {"Content-Type": content_type},
        )

    return flow


def _make_request_meta(model: str = "gpt-4o-mini", stream: bool = False) -> RequestMetadata:
    return RequestMetadata(
        provider="openai",
        model=model,
        stream=stream,
        started_at=time.monotonic() - 0.5,
    )


# ---------------------------------------------------------------------------
# matches() / matches_url()
# ---------------------------------------------------------------------------


class TestMatches:
    def test_matches_exact_host(self) -> None:
        assert OpenAIAdapter().matches("api.openai.com") is True

    def test_matches_host_with_port(self) -> None:
        assert OpenAIAdapter().matches("api.openai.com:443") is True

    def test_does_not_match_other_host(self) -> None:
        assert OpenAIAdapter().matches("api.anthropic.com") is False

    def test_rejects_trailing_suffix_injection(self) -> None:
        assert OpenAIAdapter().matches("api.openai.com.evil.com") is False

    def test_rejects_leading_subdomain_injection(self) -> None:
        assert OpenAIAdapter().matches("evil.api.openai.com") is False


class TestMatchesUrl:
    def test_accepts_chat_completions(self) -> None:
        assert OpenAIAdapter().matches_url("api.openai.com", "/v1/chat/completions") is True

    def test_accepts_responses(self) -> None:
        assert OpenAIAdapter().matches_url("api.openai.com", "/v1/responses") is True

    def test_accepts_embeddings(self) -> None:
        assert OpenAIAdapter().matches_url("api.openai.com", "/v1/embeddings") is True

    def test_rejects_moderations(self) -> None:
        # /v1/moderations is free — opt out so it doesn't clutter the DB with $0 rows.
        assert OpenAIAdapter().matches_url("api.openai.com", "/v1/moderations") is False

    def test_rejects_moderations_with_query_string(self) -> None:
        assert (
            OpenAIAdapter().matches_url(
                "api.openai.com", "/v1/moderations?model=text-mod-001"
            )
            is False
        )

    def test_rejects_other_host(self) -> None:
        assert (
            OpenAIAdapter().matches_url("api.anthropic.com", "/v1/chat/completions") is False
        )


# ---------------------------------------------------------------------------
# parse_request()
# ---------------------------------------------------------------------------


class TestParseRequest:
    def test_extracts_model_and_stream_false(self) -> None:
        flow = _make_flow(request_body={"model": "gpt-4o-mini", "messages": []})
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.provider == "openai"
        assert meta.model == "gpt-4o-mini"
        assert meta.stream is False

    def test_extracts_stream_true(self) -> None:
        flow = _make_flow(
            request_body={"model": "gpt-4o", "stream": True, "messages": []}
        )
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.stream is True

    def test_embeddings_request_no_stream(self) -> None:
        flow = _make_flow(
            path="/v1/embeddings",
            request_body={"model": "text-embedding-3-small", "input": "hi"},
        )
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.model == "text-embedding-3-small"
        assert meta.stream is False

    def test_empty_body_returns_unknown_model(self) -> None:
        req = tutils.treq(host="api.openai.com", port=443, path="/v1/models")
        req.content = b""
        flow = tflow.tflow(req=req)
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.model == "unknown"
        assert meta.stream is False

    def test_non_json_body_returns_unknown_model(self) -> None:
        req = tutils.treq(host="api.openai.com", port=443, path="/v1/chat/completions")
        req.content = b"not-json"
        flow = tflow.tflow(req=req)
        meta = OpenAIAdapter().parse_request(flow)
        assert meta.model == "unknown"


# ---------------------------------------------------------------------------
# parse_response() — non-streaming
# ---------------------------------------------------------------------------


class TestParseResponseNonStreaming:
    def test_chat_completion_basic_with_cache(self) -> None:
        body = (FIXTURES / "chat_completion_basic.json").read_text()
        flow = _make_flow(response_body=body)
        meta = OpenAIAdapter().parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 47
        assert meta.output_tokens == 12
        assert meta.thinking_tokens == 0
        assert meta.cache_read_tokens == 32
        assert meta.cache_write_tokens == 0
        assert meta.tokens_complete is True
        assert meta.latency_ms > 0

    def test_o1_response_carries_reasoning_tokens(self) -> None:
        body = (FIXTURES / "o1_response.json").read_text()
        flow = _make_flow(response_body=body)
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(model="o1")
        )
        assert meta.input_tokens == 120
        assert meta.output_tokens == 1486
        assert meta.thinking_tokens == 1408
        assert meta.cache_read_tokens == 0
        assert meta.tokens_complete is True

    def test_embeddings_only_input_tokens(self) -> None:
        body = (FIXTURES / "embeddings_response.json").read_text()
        flow = _make_flow(path="/v1/embeddings", response_body=body)
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(model="text-embedding-3-small")
        )
        assert meta.input_tokens == 35
        assert meta.output_tokens == 0
        assert meta.thinking_tokens == 0
        assert meta.cache_read_tokens == 0
        assert meta.tokens_complete is True

    def test_tool_call_tokens_roll_into_completion(self) -> None:
        body = (FIXTURES / "tool_call_response.json").read_text()
        flow = _make_flow(response_body=body)
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(model="gpt-4o")
        )
        # Tool-call serialised arguments are counted in completion_tokens by OpenAI.
        assert meta.input_tokens == 88
        assert meta.output_tokens == 27
        assert meta.tokens_complete is True

    def test_empty_body_marks_incomplete(self) -> None:
        flow = _make_flow(response_body="")
        meta = OpenAIAdapter().parse_response(flow, _make_request_meta())
        assert meta.tokens_complete is False

    def test_truncated_json_marks_incomplete(self) -> None:
        flow = _make_flow(response_body='{"usage": {"prompt_tokens":')
        meta = OpenAIAdapter().parse_response(flow, _make_request_meta())
        assert meta.tokens_complete is False


# ---------------------------------------------------------------------------
# parse_response() — streaming SSE
# ---------------------------------------------------------------------------


class TestParseResponseStreaming:
    def test_chat_completion_streaming_with_usage(self) -> None:
        body = (FIXTURES / "chat_completion_streaming_with_usage.txt").read_text()
        flow = _make_flow(response_body=body, content_type="text/event-stream")
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        assert meta.input_tokens == 23
        assert meta.output_tokens == 8
        assert meta.tokens_complete is True

    def test_chat_completion_streaming_without_usage(self) -> None:
        # Common case: client did NOT set stream_options.include_usage=true.
        body = (FIXTURES / "chat_completion_streaming_no_usage.txt").read_text()
        flow = _make_flow(response_body=body, content_type="text/event-stream")
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        assert meta.input_tokens == 0
        assert meta.output_tokens == 0
        assert meta.tokens_complete is False

    def test_responses_api_streaming(self) -> None:
        body = (FIXTURES / "responses_streaming.txt").read_text()
        flow = _make_flow(
            path="/v1/responses",
            response_body=body,
            content_type="text/event-stream",
        )
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(model="gpt-4.1-mini", stream=True)
        )
        assert meta.input_tokens == 56
        assert meta.output_tokens == 18
        assert meta.cache_read_tokens == 24
        assert meta.tokens_complete is True

    def test_truncated_sse_does_not_crash(self) -> None:
        body = (FIXTURES / "truncated_body.txt").read_text()
        flow = _make_flow(response_body=body, content_type="text/event-stream")
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        # No usage block in the truncated stream; tokens_complete must be False.
        assert meta.input_tokens == 0
        assert meta.output_tokens == 0
        assert meta.tokens_complete is False

    def test_empty_sse_marks_incomplete(self) -> None:
        flow = _make_flow(response_body="", content_type="text/event-stream")
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        assert meta.tokens_complete is False

    def test_sse_with_malformed_data_lines_skipped(self) -> None:
        body = (
            "data: {invalid json}\n"
            "\n"
            'data: {"choices":[],"usage":{"prompt_tokens":5,"completion_tokens":3}}\n'
            "\n"
            "data: [DONE]\n"
        )
        flow = _make_flow(response_body=body, content_type="text/event-stream")
        meta = OpenAIAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        assert meta.input_tokens == 5
        assert meta.output_tokens == 3
        assert meta.tokens_complete is True


# ---------------------------------------------------------------------------
# Pricing integration
# ---------------------------------------------------------------------------


class TestPricingIntegration:
    def test_compute_cost_millicents_positive_for_known_model(self) -> None:
        # gpt-4o-mini @ 47 prompt + 12 completion + 32 cached should be > 0.
        cost = compute_cost_millicents(
            model="gpt-4o-mini",
            input_tokens=47,
            output_tokens=12,
            thinking_tokens=0,
            cache_read_tokens=32,
            cache_write_tokens=0,
        )
        assert cost is not None
        assert cost > 0

    def test_compute_cost_millicents_routes_reasoning_to_output_rate(self) -> None:
        # o1 reasoning_tokens are billed at the output rate. Verify by computing
        # cost two ways: (a) reasoning in thinking_tokens, (b) the same count
        # added to output_tokens — the totals must match exactly.
        cost_via_thinking = compute_cost_millicents(
            model="o1",
            input_tokens=120,
            output_tokens=78,  # visible completion only (1486 - 1408 reasoning)
            thinking_tokens=1408,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        cost_via_output = compute_cost_millicents(
            model="o1",
            input_tokens=120,
            output_tokens=78 + 1408,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        assert cost_via_thinking is not None
        assert cost_via_thinking == cost_via_output

    def test_compute_cost_millicents_for_embeddings(self) -> None:
        cost = compute_cost_millicents(
            model="text-embedding-3-small",
            input_tokens=35,
            output_tokens=0,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        assert cost is not None
        assert cost >= 0


# ---------------------------------------------------------------------------
# Wiring
# ---------------------------------------------------------------------------


class TestWiring:
    def test_adapter_in_registry(self) -> None:
        assert any(isinstance(a, OpenAIAdapter) for a in ADAPTER_REGISTRY)

    def test_adapter_satisfies_protocol(self) -> None:
        assert isinstance(OpenAIAdapter(), ProviderAdapter)

    def test_openai_adapter_matches_valid_paths(self) -> None:
        # Issue #2: path filtering moved into adapter.matches_url()
        adapter = OpenAIAdapter()
        # Valid paths the adapter should match
        for path in (
            "/v1/chat/completions",
            "/v1/responses",
            "/v1/embeddings",
        ):
            assert adapter.matches_url("api.openai.com", path), f"should match {path}"
        # Invalid paths should not match
        assert not adapter.matches_url("api.openai.com", "/v1/moderations")
        assert not adapter.matches_url("api.openai.com", "/invalid/path")
