"""
Tests for the ProviderAdapter Protocol shape.

Covers the additive ``matches_url(host, path)`` bump landed 2026-05-02
alongside multi-provider PR2. Asserts:

  * Existing adapters satisfy ``isinstance(adapter, ProviderAdapter)``.
  * The Anthropic adapter's ``matches_url`` enforces strict path matching
    for /v1/messages (Issue #2 path-filtering fix to avoid cross-provider
    collisions in system-proxy mode).
  * A toy adapter can override ``matches_url`` to opt OUT of specific
    paths while still passing the Protocol check — this is the contract
    the OpenAI adapter uses to skip ``/v1/moderations``.
"""

from __future__ import annotations

import time
from typing import ClassVar

from halton_meter.adapters.anthropic import AnthropicAdapter
from halton_meter.adapters.base import (
    ProviderAdapter,
    RequestMetadata,
    ResponseMetadata,
)

# ---------------------------------------------------------------------------
# Protocol satisfaction
# ---------------------------------------------------------------------------


def test_anthropic_adapter_satisfies_protocol():
    adapter = AnthropicAdapter()
    assert isinstance(adapter, ProviderAdapter)


# ---------------------------------------------------------------------------
# Anthropic matches_url — strict path matching for /v1/messages (Issue #2)
# ---------------------------------------------------------------------------


def test_anthropic_matches_url_accepts_inference_paths():
    """Anthropic matches_url accepts /v1/messages paths only (Issue #2).

    Regression guard for the Issue #2 path-filtering fix: Anthropic adapter
    now enforces strict path matching for /v1/messages. This prevents
    cross-provider collisions in system-proxy mode.
    """
    adapter = AnthropicAdapter()
    for host in ("api.anthropic.com", "api.anthropic.com:443"):
        assert adapter.matches(host) is True
        # Inference paths should match
        for path in ("/v1/messages", "/v1/messages/batches"):
            assert adapter.matches_url(host, path) is True, (
                f"should match {path!r} for {host!r}"
            )
        # Non-inference paths should not match
        for path in ("/", "/v1/models"):
            assert adapter.matches_url(host, path) is False, (
                f"should reject {path!r} for {host!r}"
            )


def test_anthropic_matches_url_rejects_what_matches_rejects():
    adapter = AnthropicAdapter()
    for host in (
        "evil.com",
        "evil.api.anthropic.com",
        "api.anthropic.com.evil.com",
    ):
        assert adapter.matches(host) is False
        assert adapter.matches_url(host, "/v1/messages") is False


# ---------------------------------------------------------------------------
# Toy adapter exercising the path-level opt-out — the contract PR1 (OpenAI)
# will use to skip /v1/moderations.
# ---------------------------------------------------------------------------


class _ToyOptOutAdapter:
    """Minimal adapter that opts out of one specific path."""

    name: ClassVar[str] = "toy"
    domains: ClassVar[list[str]] = ["api.toy.example"]

    def matches(self, host: str) -> bool:
        return host == "api.toy.example" or host.startswith("api.toy.example:")

    def matches_url(self, host: str, path: str) -> bool:
        if not self.matches(host):
            return False
        # Opt out of the moderations-style free endpoint.
        if path.startswith("/v1/moderations"):
            return False
        return True

    def parse_request(self, flow: object) -> RequestMetadata:  # pragma: no cover
        return RequestMetadata(
            provider=self.name,
            model="unknown",
            stream=False,
            started_at=time.monotonic(),
        )

    def parse_response(  # pragma: no cover
        self,
        flow: object,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata:
        return ResponseMetadata()


def test_toy_optout_adapter_satisfies_protocol():
    """The opt-out shape is a valid ProviderAdapter — proves the Protocol
    accommodates the contract PR1 will lean on.
    """
    assert isinstance(_ToyOptOutAdapter(), ProviderAdapter)


def test_toy_optout_adapter_skips_optout_path():
    adapter = _ToyOptOutAdapter()
    assert adapter.matches("api.toy.example") is True
    assert adapter.matches_url("api.toy.example", "/v1/chat/completions") is True
    # Opted-out path returns False even though host matches.
    assert adapter.matches_url("api.toy.example", "/v1/moderations") is False
    assert adapter.matches_url(
        "api.toy.example", "/v1/moderations?foo=bar"
    ) is False


def test_find_adapter_respects_matches_url_optout(monkeypatch):
    """proxy.find_adapter must dispatch via matches_url(host, path), not
    just matches(host). Without this, an opted-out path would still hit
    the adapter's parse_request — defeating the whole point of the bump.
    """
    from halton_meter import proxy

    toy = _ToyOptOutAdapter()
    monkeypatch.setattr(proxy, "ADAPTER_REGISTRY", [toy])

    # In-scope path → adapter found.
    assert proxy.find_adapter("api.toy.example", "/v1/chat/completions") is toy
    # Opted-out path → no adapter.
    assert proxy.find_adapter("api.toy.example", "/v1/moderations") is None
    # Empty path (response-side caller) → adapter still found because the
    # toy's opt-out is path-specific. This documents the response-side
    # contract: pending entries already filtered the path at request time;
    # the response-side host-only lookup remains valid.
    assert proxy.find_adapter("api.toy.example", "") is toy
